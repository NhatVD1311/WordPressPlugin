<?php return array('dependencies' => array(), 'version' => 'dd289e23165547aa797f');
