=== OMGF Pro ===
Contributors: DaanvandenBergh
Tags: OMGF Pro, Google Fonts, Host Fonts Locally
Requires at least: 6.2
Tested up to: 7.1
Stable tag: 5.3.2
Requires PHP: 7.2

== Description ==

Replace all Google Fonts in your webpages with locally hosted versions. Also removes preconnect, dns-prefetch and preload headers.

== Changelog ==

= 5.3.2 =
* Improved: Smart Optimize purges a page from LiteSpeed Cache silently, instead of adding a LiteSpeed Cache "Purge url" admin notice for every page it analyzed.
* Fixed: Smart Optimize decided whether a visitor was on mobile by the window's width when storing results, but by user agent when applying them. So tablets wider than 768px and narrow desktop windows analyzed pages on every visit, tablets could get the results meant for phones, and a narrow desktop window could store a page's desktop results as mobile. Results are now stored by user agent too, like most page caches separate mobile and desktop.
* Fixed: Smart Optimize no longer analyzes WooCommerce's endpoints, e.g. order received pages (/checkout/order-received/<order_id>/) or My Account's orders, and doesn't apply the results of the page they belong to (e.g. the checkout form) to them, because their contents are different.
* Fixed: Smart Optimize no longer analyzes pages which shouldn't be page cached, i.e. pages defining the DONOTCACHEPAGE constant (e.g. WooCommerce's cart, checkout and account pages), and doesn't apply results to them.
* Fixed: local stylesheets loaded through a URL containing ../ (e.g. Super Speedy Search's stylesheet) couldn't be cached, because their cache path contained ../ as well.
* Added: the omgf_pro_smart_optimize_excluded filter, to exclude pages from Smart Optimize.
* Fixed: when the license server couldn't be reached, requesting OMGF Pro's plugin information caused a fatal error ("Attempt to assign property "plugin" on false"), e.g. in Plugin Report or during Wordfence's update check.
* Fixed: license keys which can't be decrypted (e.g. after migrating a site) no longer cause a PHP warning on every page load, and license keys are no longer written to the license manager's debug log.
* Fixed: Magic Fallbacks had no effect unless Smart Optimize, a Detection Setting or a manual Fallback Font Stack was enabled too, and inline styles didn't get its fallbacks unless a manual Fallback Font Stack was configured. Stylesheets processed before Magic Fallbacks was enabled (or disabled) are now processed again.
* Fixed: pages served from a page cache for longer than 12 to 24 hours couldn't be analyzed by Smart Optimize, because their (expired) nonce made WordPress reject the request. Logged-out visitors no longer get a nonce, because it's the same for everyone and doesn't protect anything. Requires OMGF v6.3.13 for the Google Fonts Checker's request.
* Fixed: unused fonts were still removed after disabling Smart Optimize (only its preloads stopped). Its results are now only applied while it's enabled, and kept for when it's enabled again.
* Fixed: with plain permalinks, all pages shared the same Smart Optimize results, so fonts used on one page could be removed from another. Pages are now identified by their query vars, e.g. /?p=123 (search terms aren't stored).
* Improved: the Dashboard notice no longer suggests Magic Fallbacks are generated per page; they're added for the fonts OMGF hosts locally.
* Added: when automatic updates are disabled (e.g. because the license isn't activated for this site, or its key can't be read), the Plugins screen shows why, with a link to the Manage Licenses screen. License manager v2.2.6.
* Added: Dutch (nl_NL) translations for the license manager. License manager v2.2.7.
* Added: an error message on the Manage Licenses screen when the license server can't be reached, instead of nothing happening. License manager v2.2.8.
* Improved: when the license status couldn't be checked, the license manager checks it again after 24 hours instead of 84. License manager v2.2.8.
* Fixed: the license manager's Manage License tab on OMGF's settings screen is now translated. License manager v2.2.8.
* Added: Dutch (nl_NL) translation, and OMGF Pro now loads its bundled translations.

= 5.3.1 =
* Fixed: Smart Optimize stored its results for every URL visitors browsed to, so variations of the same page were analyzed and stored separately, e.g. AffiliateWP's referral URLs (/ref/<affiliate>/), which may contain an affiliate's email address. Results are now stored for the canonical path of the page. Existing results are removed once, so pages are analyzed again.
* Fixed: Smart Optimize results weren't found on sites installed in a subdirectory, or for paths containing percent-encoded characters.
* Fixed: Smart Optimize no longer analyzes 404 pages for administrators either.
* Added: the omgf_pro_smart_optimize_path filter, to normalize the path Smart Optimize stores its results for.
* Security: Smart Optimize only stores results for paths signed by your site, i.e. pages it actually rendered, so its table can't be filled with made-up paths.

= 5.3.0 =
* Added: compatibility with Thrive Leads (and other Thrive products loading forms through Thrive Dashboard): Google Fonts @imported by forms which are loaded asynchronously are now replaced with locally hosted copies.
* Added: Smart Optimize results reported by visitors can only preload font files hosted on this site, OMGF's upload URL, a host the site already loads stylesheets, scripts or fonts from, or a whitelisted host: hosts of preloads reported during an administrator's visit are whitelisted automatically, other hosts are listed on the Dashboard for approval (the stoplight in the admin bar turns blue), and the whitelisted and ignored hosts can be managed below the Smart Optimize option. 
* Improved: preloads' and unloads' paths are validated and the number of stored preloads and unused fonts is now limited.
* Improved: font files OMGF couldn't download correctly are reported as an alert (red) in the admin bar, instead of a warning, because OMGF Pro can't fix those. Requires OMGF v6.3.12.
* Security: external stylesheets are fetched over a safe request that rejects internal/private hosts.
* Security: asynchronously loaded Google Fonts stylesheets are only processed during an authorized Auto-Config run.
* Security: only the query string of a Google Fonts stylesheet URL is decoded before it's requested.
* Tested with WP 7.1.

= 5.2.11 =
* Note: this release requires OMGF v6.3.11 or higher. On older versions the clean up below is postponed until OMGF is updated, and Material Icons stylesheets aren't processed until then.
* Security: hardened the detection of Material Icons stylesheets, in line with OMGF v6.3.11.
* Fixed: Magic Fallbacks kept asking to contact support about fonts which never existed, e.g. 'Arial,Helvetica,sans-serif !important', 'var(--tve-font-family,Mulish)' and 'inherit'. Whenever the Google Fonts API returned no fonts for a font family found in a local or inline stylesheet — which is always the case for a font installed with WordPress' Font Library — OMGF Pro < v5.2.9 ran the optimization again with the entire document, instead of that font's @font-face statements. Every font-family declaration in that document was then stored as a font family. This release removes those entries from the Optimized Fonts table, and Magic Fallbacks now ignores any value which can't be the name of a font, instead of reporting it.

= 5.2.10 =
* Note: this release detects stylesheets which were skipped before, so optionally run Save & Optimize once after updating to add them to your cache. Nothing breaks if you don't.
* Fixed: Optimize Local/External Stylesheets skipped any link element written over multiple lines (or with a line break inside its href attribute), while browsers load those just fine. The pattern used to find them couldn't match line breaks, but could run past the > which ends an element. Both are fixed, and line breaks are now stripped from the URL before it's requested, just like browsers do.
* Improved: the classes which collect @import statements (and the one which adds the Material Icons subset) registered their filters once per instance, while they're constructed on every processing run. Because nothing ever removed those filters, they stacked up within a single request, which meant the same @import could be optimized several times over, and the Material Icons subset could be added to the subset list more than once.
* Fixed: @import statements spread over multiple lines weren't detected. CSS allows whitespace (incl. line breaks) after @import and inside url(), and a backslash followed by a line break is a line continuation inside a string, but none of those were matched. A raw line break inside the URL is still ignored, because that's an unterminated string, which browsers don't load either.
* Fixed: Smart Optimize (Unused Fonts) could return a blank page when an inline @import statement was fully unloaded. The pattern used to remove that statement removed everything between the first @import and the last occurrence of the stylesheet's URL, and exceeded PCRE's runtime limits on documents larger than ~100KB, in which case the entire document was replaced with nothing (accompanied by a 'preg_replace_callback(): Passing null to parameter #3 ($subject)' deprecation notice). Matching is now confined to a single @import statement, and a failed search/replace leaves the document untouched.
* Fixed: Smart Optimize (Unused Fonts) didn't remove any @font-face rules from stylesheets whose fonts are split into subsets. The subset was matched against the font file's URL using a pattern which
  couldn't match the hyphen separating the subset from the font-weight (e.g., source-sans-pro-normal-latin-400.woff2), so no rule ever matched. The subset is now matched against the @font-face rule's
  unicode-range, and only falls back to the filename for rules which don't define one.
* Fixed: Smart Optimize (Unused Fonts) now removes a stylesheet's link element from the HTML entirely when all of its @font-face rules are unloaded, instead of leaving behind a request for an empty stylesheet. Generated stylesheets always start with a header comment, which meant they were never detected as empty. This also fixes the deregistration of fully unloaded Async Stylesheets.
* Fixed: an unused Material Icons stylesheet wasn't removed from the HTML. Its cached URL was looked up in the wrong list, so it was never recognized, and clearing the link element's href attribute left behind a request for the page itself. Its link element is now removed entirely.

= 5.2.9 =
* Fixed: with Magic Fallbacks enabled, the first click on a Replace checkbox checked all corresponding "Don't Load" checkboxes, but left the Replace checkbox itself unchecked.
* Fixed: with Magic Fallbacks enabled, a Replace checkbox stayed disabled after unchecking the Preload checkbox(es) of the corresponding font family.
* Fixed: A corrupted (non-array) Fallback Font Stack option no longer causes a fatal error ('Cannot access offset of type string on string') when opening the Optimize Fonts settings screen.
* Fixed: Magic Fallback aliases were incorrectly stored as font families during Save & Optimize, causing a 'could not find a matching fallback font' notice.
* Fixed: Magic Fallbacks no longer tries to find a fallback for icon fonts (e.g., Material Icons/Symbols) and no longer shows a 'could not find a matching fallback font' notice for them.
* Fixed: Smart Optimize now purges the page cache on taxonomy archives, the homepage and WooCommerce product pages by switching supported caching plugins (LiteSpeed, W3 Total Cache, WP-Optimize, WP Rocket, WP Super Cache) to URL-based purging, so the detection script no longer re-runs on every page load for URLs without a single post-ID.

= 5.2.8 =
* Security: Hardened Smart Optimize and local stylesheet processing to prevent a path traversal vulnerability. Props Patchstack.
* Fixed: Muli was renamed to Mooli. This fix provides an alias for it.

= 5.2.7 | June 25th, 2026 =
* URGENT!: This release patches an exploit currently being actively exploited in the wild.
* Fixed: Neuton and Oxygen didn't receive proper Magic Fallbacks due to missing values in the dataset. This fix provides fallbacks for these cases.

= 5.2.6 | June 17th, 2026 =
* Added: Courier New as a Magic Fallback for monospace Google Fonts.
* Fixed: Magic Fallbacks now works with inline font-face statements.
* Fixed: font-family declarations inside inline font-face statements should not receive fallbacks.
* Improved: always inline Magic Fallbacks to make sure they're used before anything else.
* Improved: BunnyCDN compatibility.
* Improved: Smart Optimize now removes import statements if all font-face statements in the corresponding stylesheet are marked for unloading.

= 5.2.5 | June 4th, 2026 =
* Fixed: Smart Optimize would append a (or replace an existing) ver parameter to URLs not cached by OMGF Pro.
* Tested with WP 7.0.

= 5.2.4 | June 3rd, 2026 =
* Fixed: Local Stylesheets would attempt to optimize core's load-styles.php script.
* Updated License manager to v2.2.4.

= 5.2.3 | May 18th. 2026 =
* Fix in license manager: some systems would throw an uncaught error: class "Daan\LicenseManager\stdClass" not found.

= 5.2.2 | May 13th, 2026 =
* Fixed: use omgf_do_not_load_frontend_js filter to make sure Smart Optimize runs in OMGF v6.3.5
* Improved: decoupled Magic Fallback from Smart Optimize
* Added: Mobile Support for Smart Optimize
* Upgrade license manager to v2.2.2

= 5.2.1 | April 13th, 2026 =
* Fixed: undefined array key warning when theme uses WordPress Local Fonts.
* Fixed: replaced base64 encoding with hex escapes in the block async script, to improve WP 7.0 compatibility.
* Added: provisioning for TranslatePress compatibility.

= 5.2.0 | April 10th, 2026 =
* Added: Magic Fallbacks, which generates mathematically tuned system font fallbacks that match your Google Fonts\' exact proportions to eliminate Cumulative Layout Shifting!
* Several minor code improvements.

= 5.1.1 =
* Added: Smart Optimize compatibility with the official Cloudflare plugin.

= 5.1.0 | March 30th, 2026 =
* Improved: when Smart Optimize is enabled, and has finished detecting its optimizations, it will now automatically refresh the cache of that page for the most popular caching plugins:
  - FlyingPress
  - Kinsta Cache
  - LiteSpeed Cache
  - SiteGround Optimizer
  - W3 Total Cache
  - WP Fastest Cache
  - WP-Optimize
  - WP Rocket
  - WP Super Cache
* Improved: clarified copy in the Performance Checker dialog.

= 5.0.0 | March 23rd, 2026 =
* Added: Smart Optimize, which automatically optimizes your Google Fonts by automatically removing unused subsets and font styles/weights and preloading ones above the fold.
* Removed: Run Google Fonts Checker in the Background option, because it's superseded by Smart Optimize.

= 4.1.7 | March 1st, 2026 =
* Fixed: if Local Stylesheets processing was still off (before running initial optimization), External Stylesheets Processing would pick up fonts.googleapis.com URLs, causing confusion in the
optimization process.
* Added: Fonts added by Block Themes and Core Themes (TwentyTwenty*) are now fully supported, including subsetting.

= 4.1.6 | December 1st, 2025 =
* Tested with WP 6.9
* Updated license manager to v2.2.0

= 4.1.5 | October 10th, 2025 =
* Improved: added support for Google Fonts kits in (inline) stylesheets.
* Several code improvements to clear the way for future features.

= 4.1.4 | October 1st, 2025 =
* Improved: Refactored code for WebfontConfig detection to provide improved compatibility with several (if not all) themes and plugins using asynchronously loaded Google Fonts.
* Several minor fixes and improvements.
* Updated license manager to v2.1.1, which introduces several fixes for license validity checks.

= 4.1.3 | July 30th, 2025 =
* Fixed: unloading all fonts in an async stylesheet would result in the stylesheet still being loaded.
* Fixed: when an inline stylesheet containing @import statements loading Google Fonts was loaded asynchronously, the entire stylesheet would be blocked.

= 4.1.2 | July 4th, 2025 =
* Improved: Onboarding for Smart Preload in the Dashboard.
* Fixed: Smart Preload didn't work with Variable Fonts and/or Static Fonts loaded in a different font-weight than they were actually used.
* Improved: added compatibility for themes/plugins using the WPTT webfont loader.
* Improved: Smart Preload now also scans stylesheets loaded using @import rules for fonts to preload.

= 4.1.1 | June 27th, 2025 =
* Improved: added "Auto-configure Preload Settings for [post-type/taxonomy]" to the Admin Bar menu.
* Improved: when Smart Preload is enabled, all set Preloads are disabled to make sure one replaces the other.

= 4.1.0 | June 24th, 2025 =
* Added: Smart Preload automatically configures which fonts to preload i.e., load early. Even at page level!
* Fixed: WP Font Manager compatibility.

= 4.0.4 | June 12th, 2025 =
* Fixed: WPML and Multisite compatibility
* Improved: when the WPML plugin is active or the current site is a Multisite, the Developer Mode function will be automatically enabled.
* Minor refactors to comply with OMGF v6.0.2.

= 4.0.3 | June 4th, 2025 =
* Fixed: file paths containing spaces would send OMGF Pro's auto config into a tailspin.

= 4.0.2 | May 30th, 2025 =
* Fixed: Minor glitch in license manager would prevent users who just upgraded to a lifetime license to get the proper "never expires" status for their license.

= 4.0.1 | May 27th, 2025 =
* Updated license manager to v2.0.2
* Improved: re-factored Google Fonts checker related code to align with OMGF v6.0.1 (Enfold compatibitily)

= 4.0.0 - The 2000 IQ edition! | May 26th, 2025 =
* Improved: All Detection Settings are now configured automatically!
* Improved: the Remove Async Google Fonts option is removed, and asynchronously loaded Google Fonts are now processed and replaced automatically.
* Fixed: BunnyCDN compatibility.
* Added: Requires Plugin header, so OMGF Pro can only be activated if OMGF is installed and active.
* Several code improvements and bugfixes.
* Updated license manager to v2.0.1.

= 3.12.5 | February 20th, 2025 =
* Updated license manager to v1.16.2
* Added compatibility for Porto theme.

= 3.12.4 | November 7th, 2024 =
* Updated Unicode Ranges for Cyrillic-ext, Hebrew, Latin-ext, Math and Symbol.
* Updated license manager to v1.16.0, which activates the license directly from the browser, instead of through the server, avoiding firewall IP blocking issues.

= 3.12.3 | October 1st, 2024 =
* Fixed: Jupiter (child) theme compatibility.
* Updated license manager to v1.15.6.

= 3.12.2 | July 31st, 2024 =
* Updated license manager to v1.15.5.

= 3.12.1 | July 17th, 2024 =
* Tested with WP 6.6
* Updated license manager to v1.15.4.
* Fixed: improved code for enrolling new users.
* Fixed: Jupiter compatibility would break when Smart Slider 3 was active.
* Minor code improvements.

= 3.12.0 | April 9th, 2024 =
* Tested with WP 6.5
* Fixed: parenthesis () and spaces in filenames would break styling when Local Stylesheets processing was enabled.
* Removed: Early Access detection, because it's considered "obsolete and unsupported" by Google for over a year.
* Added: support for the Font Manager introduced in WP 6.5. Simply enable Process Inline Styles, or enable Auto-config Detection Settings to enable it.
* Fixed: compatibility fixes for specific themes wouldn't run if a child theme was being used.
* Updated license manager to v1.15.2.
* Several code improvements.

[ Changelog shortened ... ]

= 3.0.0 | September 29th, 2021 =
* Added: Scan Posts/Pages Optimization Mode is completely revamped!
  1. It now runs by cron schedule, instead of upon page request. I.e. no more slow downs upon first pageload!
  2. The Optimize Fonts-tab now features a full-fledged management panel, allowing you to manually trigger cron-tasks, manage batch size, etc.
  3. AOM now updates you about its progress thru notices within the Admin area.
* Improved: reduced the amount of code running in the frontend by ~60%!
* Fixed: when Advanced Processing is disabled, OMGF Pro's other features are still properly processed by the OMGF API (e.g. Combine & Dedupe)
* Improved: several code refactors, optimizations and UX tweaks.

[ Changelog shortened ... ]

= 2.0.0 | September 30th, 2020 =
* OMGF Pro now detects and caches Google Fonts automatically, no more auto detect required. Even if you use different fonts on different pages, they'll be cached and served properly.
* OMGF Pro can now be temporarily disabled by disabling the Advanced Processing option under Settings > Optimize Google Fonts > Basic Settings.
* Using Subset Forcing, you can now force your theme/plugins to load all Google Fonts in a certain subset, further reducing Page Size and Load Time.
* All promotion for OMGF Pro is now removed after activating this plugin.
* Some Pro options are moved to Basic Settings and Advanced Settings, since Extensions tab is removed in OMGF 4.0.0.
* Increased compatibility with CSS Minify/Combine and Caching plugins, e.g. WP Fastest Cache, WP Rocket, WP Super Cache and Autoptimize plugins.

[ Changelog shortened ... ]

= 1.0.0 | June 6th, 2020 =
* First Release!