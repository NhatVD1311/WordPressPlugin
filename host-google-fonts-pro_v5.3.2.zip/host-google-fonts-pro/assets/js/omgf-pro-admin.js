/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2025 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

jQuery(document).ready(function ($) {
    var omgf_pro_admin = {
        /**
         * Bind events
         */
        init: function () {
            this.inject_smart_optimize_overlay();
            $('#smart_optimize').on('change', this.toggle_optimization_options);
            $('#magic_fallbacks').on('change', this.toggle_fallback_options);
            $('.omgf-optimize-fonts-manage .load-all').on('click', this.reset_load_all);
            $('.omgf-optimize-fonts-manage .preload').on('change', this.maybe_disable_replace);
            $('.omgf-optimize-fonts-manage .unload, .omgf-optimize-fonts-manage .fallback-font-stack select').on('change', this.maybe_check_replace);
            $('.omgf-optimize-fonts-manage input.replace').on('change', this.maybe_unload_all);
            $('.fallback-font-stack select').on('change', this.toggle_replace);

            const developer_mode = document.getElementById('dtap');

            if (developer_mode !== null) {
                developer_mode.addEventListener('change', this.toggle_src_url);
            }
        },

        /**
         * Inject an overlay over the Preload and Unload columns when Smart Optimize is enabled.
         */
        inject_smart_optimize_overlay: function () {
            let $container = $('.omgf-optimize-fonts-manage');

            if ($container.length === 0) {
                return;
            }

            if ($container.find('.omgf-smart-optimize-overlay').length === 0) {
                $container.append('<div class="omgf-smart-optimize-overlay"><span>These options are disabled, because they are managed by Smart Optimize.</span></div>');
            }

            if ($('#smart_optimize').is(':checked')) {
                $container.addClass('omgf-smart-optimize-active');
            }
        },

        toggle_optimization_options: function (e) {
            let preloads = document.getElementsByClassName('preload');
            let unloads = document.getElementsByClassName('unload');

            if (e.target.checked === true) {
                $('.omgf-optimize-fonts-manage').addClass('omgf-smart-optimize-active');

                for (let item of preloads) {
                    item.checked = false;
                    item.disabled = true;
                }

                for (let item of unloads) {
                    item.checked = false;
                    item.disabled = true;
                }
            } else {
                $('.omgf-optimize-fonts-manage').removeClass('omgf-smart-optimize-active');

                for (let item of preloads) {
                    item.disabled = false;
                }

                for (let item of unloads) {
                    item.disabled = false;
                }
            }
        },

        toggle_fallback_options: function (e) {
            let fallback_pulldowns = document.querySelectorAll('.fallback-font-stack select');
            let magic_fallbacks = document.querySelectorAll('.fallback-font-stack input');
            let replaces = document.getElementsByClassName('replace');

            if (e.target.checked === true) {
                for (let item of replaces) {
                    item.disabled = false;
                }

                for (let item of fallback_pulldowns) {
                    item.style.display = 'none';
                }

                for (let item of magic_fallbacks) {
                    item.style.display = 'block';
                }
            } else {
                for (let item of replaces) {
                    item.disabled = true;
                    item.checked = false;
                }

                for (let item of fallback_pulldowns) {
                    item.style.display = 'block';
                    item.value = '';
                }

                for (let item of magic_fallbacks) {
                    item.style.display = 'none';
                }
            }
        },

        /**
         * When Magic Fallbacks is enabled, the Fallback Font Stack pulldown is hidden and its value
         * is empty, because the stack is auto-generated. In that case a fallback font stack IS
         * available, so the Replace checkbox should be considered usable.
         *
         * @param $fallback_box
         *
         * @returns {boolean}
         */
        has_fallback_font_stack: function ($fallback_box) {
            if ($('#magic_fallbacks').is(':checked')) {
                return true;
            }

            return !!$fallback_box.val();
        },

        reset_load_all: function () {
            let $replace_box = $(this).parents('tr.font-family').find('input.replace');

            $replace_box.attr('checked', false);
        },

        maybe_disable_replace: function () {
            var font_id = $(this).data('font-id'),
                $replace_box = $('tr[data-id="' + font_id + '"]').find('input.replace'),
                $fallback_box = $('tr[data-id="' + font_id + '"]').find('.fallback-font-stack select'),
                checked = $('input[data-font-id="' + font_id + '"].preload:checked').length;

            if (checked > 0) {
                $replace_box.attr('checked', false);
                $replace_box.attr('disabled', true);
            } else if (checked === 0 && omgf_pro_admin.has_fallback_font_stack($fallback_box)) {
                $replace_box.attr('disabled', false);
            }
        },

        maybe_check_replace: function () {
            var font_id = $(this).data('font-id'),
                $unloads = $('input[data-font-id="' + font_id + '"].unload'),
                checked = $('input[data-font-id="' + font_id + '"].unload:checked').length,
                total = $unloads.length,
                $replace_box = $('tr[data-id="' + font_id + '"]').find('input.replace'),
                $fallback_box = $('tr[data-id="' + font_id + '"]').find('.fallback-font-stack select');

            if (checked === total && omgf_pro_admin.has_fallback_font_stack($fallback_box)) {
                $replace_box[0].checked = true;
            } else {
                $replace_box[0].checked = false;
            }
        },

        maybe_unload_all: function (e) {
            let smart_optimize = document.getElementById('smart_optimize'),
                id = e.target.closest('tbody').id;

            if (this.checked === true) {
                /**
                 * If Smart Optimize is enabled, we have to append the stylesheet ID to the Unload Stylesheet option.
                 */
                if (smart_optimize.checked === true) {
                    omgf_unload_stylesheet(id);

                    return;
                }

                /**
                 * Otherwise, we unload all fonts first.
                 */
                omgf_unload_all(e, this);

                return;
            }

            if (smart_optimize.checked === true) {
                /**
                 * If Smart Optimize is enabled, we have to remove the stylesheet from the Unload Stylesheet option.
                 */
                omgf_load_stylesheet(id);
            }
        },

        toggle_replace: function () {
            var $this = $(this),
                $parent_row = $this.parents('tr.font-family'),
                $replace_box = $parent_row.find('input.replace'),
                $preloads = $('input[data-font-id="' + $parent_row.data('id') + '"].preload'),
                preload_checked = false;

            $preloads.each(function (index, elem) {
                if (elem.checked === true) {
                    preload_checked = true;

                    return false;
                }
            });

            if (this.value !== '' && preload_checked !== true) {
                $replace_box.attr('disabled', false);
            } else {
                $replace_box.attr('disabled', true);
                $replace_box[0].checked = false;
            }
        },

        /**
         * Toggle the Modify Source URL option, based on the value of Developer Mode.
         *
         * @param e
         */
        toggle_src_url: function (e) {
            const src_url = document.querySelector('.source-url');
            const disabled_notice = document.getElementById('src-url-disabled-notice');
            const description = document.getElementById('src-url-description');

            if (!src_url || !disabled_notice || !description) {
                return;
            }

            const developer_mode_enabled = e.target.checked === true;
            src_url.disabled = developer_mode_enabled;
            disabled_notice.style.display = developer_mode_enabled ? 'block' : 'none';
            description.style.display = developer_mode_enabled ? 'none' : 'block';
        },
    };

    omgf_pro_admin.init();
});
