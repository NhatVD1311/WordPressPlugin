/**
 * @package OMGF Pro | Remove Async Google Fonts
 * @author Daan van den Bergh
 * @copyright © 2017 - 2025 Daan.dev
 */
const head = document.head;
const insertBefore = head.insertBefore;
const appendChild = head.appendChild;
const append = typeof head.append === 'function' ? head.append : null;
const originals = {insertBefore, appendChild, append};

head.insertBefore = function (newNode, refNode) {
    return runInterception.call(this, newNode, refNode, 'insertBefore');
}

head.appendChild = function (node) {
    return runInterception.call(this, node, undefined, 'appendChild');
}

if (originals.append) {
    head.append = function (...nodes) {
        const self = this;

        nodes.forEach(function (node) {
            runInterception.call(self, node, undefined, 'append');
        });
    }
}

function runInterception(newElem, refElem, callback) {
    if (typeof newElem.href !== 'undefined') {
        const href = (newElem.getAttribute && newElem.getAttribute('href')) || newElem.href;

        if (href.includes('//fonts.googleapis.com/css') || href.includes('//fonts.gstatic.com/s/') || href.includes('//fonts.googleapis.com/icon')) {
            console.log('OMGF Pro blocked async request to ' + href + ' and enqueued it automatically.');

            return;
        }
    }

    const src = (newElem.getAttribute && newElem.getAttribute('src')) || newElem.src || '';

    if (src.includes('//ajax.googleapis.com/ajax/libs/webfont')) {
        console.log('OMGF Pro blocked async request to externally hosted WebFont loader.');

        return;
    }

    if (typeof newElem.tagName !== 'undefined' && newElem.tagName === 'STYLE' && typeof newElem.textContent !== 'undefined' && (newElem.textContent.includes('//fonts.googleapis.com/css') || newElem.textContent.includes('//fonts.googleapis.com/icon'))) {
        console.log('OMGF Pro removed Google Fonts @import statement from async inline style block.');

        const pattern = new RegExp('@import\\s?(?:url\\()?[\'"]?(https?:)?\\/\\/fonts.googleapis.com\\/(css2?|icon)\\?[^\'"' + ';)]*[\'"]?\\)?[^;]*;?', 'gi');
        newElem.textContent = newElem.textContent.replace(pattern, '');
    }

    if (typeof newElem.tagName !== 'undefined' && newElem.tagName === 'STYLE' && typeof newElem.textContent !== 'undefined' && (newElem.textContent.includes('//fonts.gstatic.com/s/'))) {
        // TODO: Add support for async inline @font-face statements.
    }

    let fn = originals[callback] || originals.appendChild;

    if (callback === 'insertBefore') {
        return fn.call(this, newElem, refElem);
    }

    // If append() is unavailable and we fell back to appendChild, ensure strings don’t explode.
    if (callback === 'append' && fn === originals.appendChild && typeof newElem === 'string') {
        newElem = document.createTextNode(newElem);
    }

    return fn.call(this, newElem);
}
