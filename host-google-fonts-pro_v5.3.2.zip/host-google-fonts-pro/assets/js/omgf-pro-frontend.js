/**
 * @package OMGF Pro
 * @author Daan van den Bergh
 */

document.addEventListener('omgf_frontend_loaded', (e) => {
    const detail = e && e.detail ? e.detail : {};
    let missing_preloads = Array.isArray(detail.missing_preloads) ? detail.missing_preloads : [];
    let unused_fonts = Array.isArray(detail.unused_fonts) ? detail.unused_fonts : [];
    let status = detail.status || null;

    let omgf_pro_frontend = {
        menu_item: document.getElementById('wp-admin-bar-omgf'),
        sub_menu_item: document.getElementById('wp-admin-bar-omgf-pro-smart-optimize'),
        sub_menu_item_link: document.querySelector('#wp-admin-bar-omgf-pro-smart-optimize a'),

        /**
         * Run observer.
         */
        init: function () {
            if (status === 'warning' && this.sub_menu_item_link !== null) {
                this.sub_menu_item_link.classList.add('omgf-pro-warning');
            }

            if (status === 'info' && this.sub_menu_item_link !== null) {
                this.sub_menu_item_link.classList.add('info');
            }

            // Turn the stoplight blue if 3rd party font hosts await approval, unless there's something more important to report.
            // Only the stoplight changes: status itself stays untouched, so Smart Optimize still runs.
            if (status === 'success' && omgf_pro_frontend_i18n.pending_hosts > 0 && this.menu_item !== null) {
                this.menu_item.classList.remove('success');
                this.menu_item.classList.add('info');
            }

            // The reload class is used to trigger a page reload when Async Google Fonts are processed.
            if (status === 'reload') {
                document.location.reload();
            }

            // Run Smart Optimize if conditions are met.
            if (omgf_pro_frontend_i18n.smart_optimize_enabled === '1' && status === 'success') {
                this.runSmartOptimize(missing_preloads, unused_fonts);
            }

            // Display countdown before starting optimization.
            this.sub_menu_item_link?.addEventListener('click', this.showModal);
        },

        /**
         * Run Smart Optimize.
         */
        runSmartOptimize: function (missing_preloads, unused_fonts) {
            /**
             * Use the server's verdict (by user agent), because results are looked up (and pages are cached) that way.
             * The window's width is only a fallback for pages cached before it was added.
             */
            const is_mobile = typeof omgf_pro_frontend_i18n.smart_optimize_is_mobile !== 'undefined'
                ? omgf_pro_frontend_i18n.smart_optimize_is_mobile
                : (window.innerWidth <= 768 ? 1 : 0);

            fetch(omgf_pro_frontend_i18n.smart_optimize_endpoint, {
                method: 'POST',
                // Logged-out visitors don't get a nonce. An (expired) nonce would make WordPress reject the request.
                headers: Object.assign(
                    {'Content-Type': 'application/json'},
                    omgf_pro_frontend_i18n.nonce ? {'X-WP-Nonce': omgf_pro_frontend_i18n.nonce} : {}
                ),
                body: JSON.stringify({
                    // Signed canonical path, e.g. referral URLs (/ref/<affiliate>/) share the path of the page they show.
                    path: omgf_pro_frontend_i18n.smart_optimize_path,
                    signature: omgf_pro_frontend_i18n.smart_optimize_signature,
                    is_mobile: is_mobile,
                    missing_preloads: missing_preloads,
                    unused_fonts: unused_fonts
                })
            }).then(async (response) => {
                const data = await response.json().catch(() => null);

                if (!response.ok || data?.code) {
                    throw new Error(data?.message || `Smart Optimize failed with status ${response.status}`);
                }

                if (data?.first_run) {
                    // Keep the dot gray/blinking during reload
                    if (omgf_pro_frontend.menu_item !== null) {
                        omgf_pro_frontend.menu_item.classList.remove('success', 'info', 'warning', 'alert');

                        document.location.reload();
                    }
                }
            }).catch(error => console.error('OMGF Pro - Smart Optimize error:', error));
        },

        /**
         * Display a modal before starting the optimization.
         *
         * @param e
         */
        showModal: function (e) {
            e.preventDefault();

            let href = this.href;
            let head_element = document.getElementsByTagName('head')[0];
            let link_element = document.createElement('link');
            link_element.rel = 'stylesheet';
            link_element.href = omgf_pro_frontend_i18n.smart_optimize_stylesheet_url;
            head_element.appendChild(link_element);

            let notice = document.createElement('div');
            notice.id = 'omgf-pro-optimize-notice';
            const box = document.createElement('div');
            box.id = 'omgf-pro-optimize-notice-box';
            const title = document.createElement('h2');
            title.textContent = omgf_pro_frontend_i18n.optimize_notice_title || '';
            const text = document.createElement('p');
            text.textContent = omgf_pro_frontend_i18n.optimize_notice_text || '';
            const button = document.createElement('button');
            button.id = "omgf-pro-optimize-notice-button";
            button.textContent = omgf_pro_frontend_i18n.optimize_notice_button_text || '';

            box.appendChild(title);
            box.appendChild(text);
            box.appendChild(button);
            notice.appendChild(box);
            document.body.appendChild(notice);

            notice.addEventListener('click', (e) => {
                if (e.target === notice) {
                    notice.classList.add('fade-out');
                    setTimeout(() => notice.remove(), 300);
                }
            });

            document.getElementById('omgf-pro-optimize-notice-button').addEventListener('click', () => {
                window.location.href = href;
            });
        }
    }

    omgf_pro_frontend.init();
});
