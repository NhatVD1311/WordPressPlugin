<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\API;

use OMGF\Pro\Helper;

class AdminBarMenu {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_filter( 'omgf_api_adminbar_menu_permission', [ $this, 'maybe_filter_api_permission' ] );
	}
	
	/**
	 * Filter the API permission if Smart Optimize should run.
	 *
	 * @param $is_allowed
	 *
	 * @return mixed|true
	 */
	public function maybe_filter_api_permission( $is_allowed ) {
		if ( Helper::should_smart_optimize_run() ) {
			return true;
		}
		
		return $is_allowed;
	}
}
