<?php
/**
 * @since     v5.0.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\API;

use OMGF\Pro\Frontend\SmartOptimize\TrustedHosts;
use OMGF\Pro\Helper;
use OMGF\Pro\UnicodeRanges;
use OMGF\Pro\Wrapper;

class SmartOptimize {
	public const ID = 'omgf_pro_smart_optimize';
	
	public static $namespace = 'omgf-pro/v1';
	
	public static $base = 'smart-optimize';
	
	public static $endpoint = 'store-results';
	
	/**
	 * Maximum number of missing preloads stored per path.
	 */
	const MAX_PRELOADS = 25;
	
	/**
	 * Maximum number of unused fonts stored per path.
	 */
	const MAX_UNUSED_FONTS = 1000;
	
	/**
	 * Maximum length of a path, i.e. the length of the url column.
	 */
	const MAX_PATH_LENGTH = 191;
	
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}
	
	/**
	 * Permission callback.
	 *
	 * @since v5.3.2 Logged-out visitors don't need a nonce: it's the same for everyone and public, so it doesn't protect
	 *               anything, but it does expire in pages served from a page cache. Results are only stored for signed
	 *               paths, and visitors' preloads are limited to trusted hosts. Without a (valid) nonce, WordPress treats
	 *               a request as logged out, so logged-in users (whose results approve font hosts) still need one.
	 *
	 * @return bool
	 */
	public function get_permission( \WP_REST_Request $request ) {
		if ( is_user_logged_in() && ! wp_verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return false;
		}
		
		return Helper::should_smart_optimize_run();
	}
	
	/**
	 * Register the API routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::$namespace,
			'/' . self::$base . '/' . self::$endpoint,
			[
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'store_results' ],
					'permission_callback' => [ $this, 'get_permission' ],
				],
			]
		);
	}
	
	/**
	 * Store results in the database.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_REST_Response
	 */
	public function store_results( $request ) {
		$params           = $request->get_json_params();
		$path             = $params['path'] ?? '';
		$signature        = $params['signature'] ?? '';
		$is_mobile        = isset( $params['is_mobile'] ) && $params['is_mobile'] ? 1 : 0;
		$missing_preloads = $params['missing_preloads'] ?? [];
		$unused_fonts     = $params['unused_fonts'] ?? [];
		
		/**
		 * Make sure that the request is valid.
		 *
		 * @since v5.3.0 The path must be a (root-relative) path which fits in the url column.
		 * @since v5.3.1 The path must be signed by this site, i.e. it's the canonical path of a page it rendered. Because
		 *               it's signed, it isn't sanitized: that would change paths containing percent-encoded characters.
		 */
		if (
			! $this->is_valid_path( $path ) ||
			! $this->is_signed_path( $path, $signature ) ||
			! is_array( $missing_preloads ) ||
			! is_array( $unused_fonts )
		) {
			return new \WP_REST_Response( [], 400 );
		}
		
		/**
		 * @since v5.3.0 Limit the number of stored items. Missing preloads are limited after untrusted ones are removed.
		 */
		$unused_fonts = array_slice( $unused_fonts, 0, self::MAX_UNUSED_FONTS );
		
		/**
		 * Validate missing preloads items.
		 */
		foreach ( $missing_preloads as $font ) {
			if ( empty( $font['family'] ) || empty( $font['weight'] ) || empty( $font['style'] ) || empty( $font['url'] ) ) {
				return new \WP_REST_Response( [], 400 );
			}
		}
		
		/**
		 * Validate unused fonts items.
		 */
		foreach ( $unused_fonts as $font ) {
			if ( empty( $font['family'] ) || empty( $font['weight'] ) || empty( $font['style'] ) || empty( $font['url'] ) ) {
				return new \WP_REST_Response( [], 400 );
			}
		}
		
		/**
		 * If no Missing Preloads or Unused Fonts are found, return early, because we should check this page again later.
		 */
		if ( empty( $missing_preloads ) && empty( $unused_fonts ) ) {
			return new \WP_REST_Response( [], 200 );
		}
		
		/**
		 * @since v5.3.0 Results submitted by visitors may only preload font files from trusted hosts, because these
		 *                preloads are added to the page for every visitor.
		 */
		if ( current_user_can( 'manage_options' ) ) {
			$this->approve_preload_hosts( $missing_preloads );
		} else {
			$missing_preloads = $this->filter_untrusted_preloads( $missing_preloads );
		}
		
		$missing_preloads = array_slice( $missing_preloads, 0, self::MAX_PRELOADS );
		
		$labels           = $this->generate_labels( $missing_preloads, $unused_fonts );
		$missing_preloads = $this->normalize_preloads( $missing_preloads );
		/**
		 * @since v5.2.8 Reindex $missing_preloads to prevent attacker-supplied string keys.
		 */
		$missing_preloads = array_values( $missing_preloads );
		$unload           = $this->normalize_unloads( $unused_fonts );
		$stored_results   = $this->persist_results( $path, $is_mobile, $missing_preloads, $unload, $labels, $unused_fonts );
		
		return new \WP_REST_Response(
			[
				'first_run' => empty( $stored_results ),
			],
			200
		);
	}
	
	/**
	 * Checks if $path is a root-relative path which fits in the url column.
	 *
	 * @param string $path
	 *
	 * @return bool
	 */
	private function is_valid_path( $path ) {
		if ( ! is_string( $path ) || $path === '' || $path[0] !== '/' || str_starts_with( $path, '//' ) ) {
			return false;
		}
		
		/**
		 * The url column's length is in characters, not bytes. preg_match_all() returns false for invalid UTF-8.
		 */
		$length = preg_match_all( '/./us', Helper::normalize_smart_optimize_path( $path ) );
		
		return $length !== false && $length <= self::MAX_PATH_LENGTH;
	}
	
	/**
	 * Checks if $signature is this site's signature of $path.
	 *
	 * @see Helper::sign_smart_optimize_path()
	 *
	 * @param string $path
	 * @param mixed  $signature
	 *
	 * @return bool
	 */
	private function is_signed_path( $path, $signature ) {
		return is_string( $signature ) && hash_equals( Helper::sign_smart_optimize_path( $path ), $signature );
	}
	
	/**
	 * Removes preloads which aren't font files, or aren't hosted on a trusted host, i.e. this site, OMGF's upload URL
	 * (which might be a CDN), a host this site already loads stylesheets, scripts or fonts from, or a host approved by
	 * an administrator. Untrusted hosts are added to the hosts awaiting approval.
	 *
	 * @see TrustedHosts
	 *
	 * @param array $missing_preloads
	 *
	 * @return array
	 */
	private function filter_untrusted_preloads( $missing_preloads ) {
		return array_values(
			array_filter(
				$missing_preloads,
				function ( $preload ) {
					$host = $this->get_preload_host( $preload );
					
					if ( $host === false ) {
						return false;
					}
					
					// Root-relative URLs point to this site.
					if ( $host === '' ) {
						return true;
					}
					
					if ( TrustedHosts::is_trusted( $host ) ) {
						return true;
					}
					
					TrustedHosts::add_pending( $host );
					
					return false;
				}
			)
		);
	}
	
	/**
	 * Preloads reported by an administrator's visit are trusted, so their hosts are approved automatically.
	 *
	 * @param array $missing_preloads
	 *
	 * @return void
	 */
	private function approve_preload_hosts( $missing_preloads ) {
		foreach ( $missing_preloads as $preload ) {
			$host = $this->get_preload_host( $preload );
			
			if ( $host && ! TrustedHosts::is_trusted( $host ) ) {
				TrustedHosts::approve( $host, 'admin' );
			}
		}
	}
	
	/**
	 * Returns the (lowercase) host of a preload's URL, an empty string for a root-relative URL (i.e. this site), or false
	 * if it isn't an (absolute or root-relative) http(s) URL of a font file.
	 *
	 * @param array $preload
	 *
	 * @return string|false
	 */
	private function get_preload_host( $preload ) {
		if ( ! is_string( $preload['url'] ?? null ) ) {
			return false; // @codeCoverageIgnore
		}
		
		$url = trim( $preload['url'] );

		/**
		 * Browsers (and esc_url()) strip tabs and newlines anywhere in a URL and treat a backslash as a slash, so PHP and
		 * the browser could disagree on the host, e.g. for "/\t/example.com" or "https://example.com\@example.org".
		 */
		if ( preg_match( '/[\x00-\x20\x7f\\\\]/', $url ) ) {
			return false;
		}

		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		
		if ( ! in_array( strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ), array_values( Wrapper::mime_map() ), true ) ) {
			return false;
		}
		
		// Browsers treat a backslash as a slash, i.e. /\ is protocol-relative.
		if ( preg_match( '#^/(?![/\\\\])#', $url ) ) {
			return '';
		}
		
		if ( str_starts_with( $url, '//' ) ) {
			$url = set_url_scheme( $url );
		}
		
		$host = wp_parse_url( $url, PHP_URL_HOST );
		
		if ( ! in_array( wp_parse_url( $url, PHP_URL_SCHEME ), [ 'http', 'https' ], true ) || ! is_string( $host ) || $host === '' ) {
			return false; // @codeCoverageIgnore
		}

		// A font is never loaded using credentials, so userinfo (e.g. "https://example.com@example.org") is rejected.
		if ( wp_parse_url( $url, PHP_URL_USER ) !== null || wp_parse_url( $url, PHP_URL_PASS ) !== null ) {
			return false;
		}
		
		return strtolower( $host );
	}
	
	/**
	 * Generate human-readable labels for the Admin Bar.
	 *
	 * @param array $missing_preloads
	 * @param array $unused_fonts
	 *
	 * @return array
	 */
	private function generate_labels( $missing_preloads, $unused_fonts ) {
		return [
			'preloaded' => array_map(
				function ( $font ) {
					$style  = ( $font['style'] ?? 'normal' ) !== 'normal' ? ' ' . ( $font['style'] ?? '' ) : '';
					$family = $font['family'] ?? '';
					$weight = $font['weight'] ?? '';
					
					return $family . ' ' . $weight . $style;
				},
				$missing_preloads
			),
			'unloaded'  => ( function () use ( $unused_fonts ) {
				$grouped = [];
				
				foreach ( $unused_fonts as $font ) {
					$family = $font['family'];
					$style  = $font['style'] !== 'normal' ? ' ' . $font['style'] : '';
					$subset = '';
					
					if ( ! empty( $font['unicode_range'] ) ) {
						$normalized_range = strtoupper( preg_replace( '/\s+/', '', UnicodeRanges::pad( $font['unicode_range'] ) ) );
						$found_subset     = array_search( $normalized_range, UnicodeRanges::MAP, true );
						
						if ( ! empty( $found_subset ) ) {
							$subset = ' (' . ucwords( str_replace( '-', ' ', $found_subset ) ) . ')';
						}
					}
					
					$grouped[ $family ][] = $font['weight'] . $style . $subset;
				}
				
				return $grouped;
			} )(),
		];
	}
	
	/**
	 * Remove 'ver' query arg from missing preloads for OMGF-cached fonts only.
	 * External fonts (e.g., Font Awesome) have their own versioning via the 'ver' parameter
	 * and should not be modified — otherwise the preload URL won't match the @font-face URL.
	 *
	 * @param array $missing_preloads
	 *
	 * @return array
	 */
	private function normalize_preloads( $missing_preloads ) {
		$upload_url = Wrapper::get_upload_url();
		
		foreach ( $missing_preloads as &$missing_preload ) {
			$url = trim( (string) ( $missing_preload['url'] ?? '' ) );
			
			if ( $url === '' ) {
				continue;
			}
			
			if ( ! str_contains( $missing_preload['url'], $upload_url ) ) {
				continue;
			}
			
			$missing_preload['url'] = remove_query_arg( 'ver', $missing_preload['url'] );
		}
		
		return $missing_preloads;
	}
	
	/**
	 * Group the unused fonts by stylesheet-handle.
	 *
	 * @param array $unused_fonts
	 *
	 * @return array
	 */
	private function normalize_unloads( $unused_fonts ) {
		$unload = [];
		
		foreach ( $unused_fonts as $font ) {
			$url    = $font['url'] ?? '';
			$family = $font['family'] ?? '';
			$weight = $font['weight'] ?? '';
			$style  = $font['style'] ?? 'normal';
			
			if ( empty( $url ) ) {
				continue;
			}
			
			$url_path          = wp_parse_url( $url, PHP_URL_PATH ) ?: '';
			$stylesheet_handle = sanitize_file_name( basename( dirname( $url_path ) ) );
			
			if ( $stylesheet_handle === '' || $stylesheet_handle === '.' || $stylesheet_handle === '..' ) {
				continue;
			}
			$subset = '';
			
			if ( ! empty( $font['unicode_range'] ) ) {
				$normalized_range = strtoupper( preg_replace( '/\s+/', '', UnicodeRanges::pad( $font['unicode_range'] ) ) );
				$subset           = array_search( $normalized_range, UnicodeRanges::MAP, true );
				$subset           = $subset ?: '';
			}
			
			$unload[ $stylesheet_handle ][] = [
				'family' => $family,
				'weight' => $weight,
				'style'  => $style,
				'subset' => $subset,
			];
		}
		
		return $unload;
	}
	
	/**
	 * Persist results in the database.
	 *
	 * @param string $path
	 * @param int    $is_mobile
	 * @param array  $missing_preloads
	 * @param array  $unload
	 * @param array  $labels
	 * @param array  $unused_fonts
	 *
	 * @return object|false
	 */
	private function persist_results( $path, $is_mobile, $missing_preloads, $unload, $labels, $unused_fonts ) {
		global $wpdb;
		
		$path           = Helper::normalize_smart_optimize_path( $path );
		$stored_results = Helper::get_smart_optimize_results( $path, $is_mobile );
		$table_name     = $wpdb->prefix . self::ID;
		
		if ( empty( $stored_results ) ) {
			$results = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO $table_name (url, is_mobile, preload, unload, labels, stylesheet_hash, detected_at) VALUES (%s, %d, %s, %s, %s, %s, %s)",
					$path,
					$is_mobile,
					wp_json_encode( $missing_preloads ),
					wp_json_encode( $unload ),
					wp_json_encode( $labels ),
					md5( wp_json_encode( $unused_fonts ) ),
					current_time( 'mysql' )
				)
			);
			
			/**
			 * Should only be fired when results are persisted. The row is deleted from the DB to trigger a refresh.
			 *
			 * @action omgf_pro_smart_optimize_results_stored
			 *
			 * @see    \OMGF\Pro\Frontend\SmartOptimize::maybe_delete_db_entry()
			 * @since  v5.1.0
			 *
			 * @param string $path      The normalized path of the URL for which the results are stored.
			 * @param int    $is_mobile Whether the results are for mobile or desktop.
			 *
			 */
			if ( $results !== false ) {
				do_action( 'omgf_pro_smart_optimize_results_stored', $path, $is_mobile );
			}
		}
		
		return $stored_results;
	}
}
