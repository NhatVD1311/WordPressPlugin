<?php
/**
 *
 */

namespace OMGF\Pro\Admin\Settings;

use OMGF\Helper as OMGF;
use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\MagicFallbacks\FallbackFontStack;
use OMGF\Pro\Helper;
use OMGF\Pro\Wrapper;

/**
 * @codeCoverageIgnore Because it's all UI/Visual logic.
 */
class Optimize {
    /**
     * Build class.
     */
    public function __construct() {
        $this->init();
    }

    /**
     * Action/filter hooks.
     *
     * @return void
     */
    private function init() {
        add_filter( 'omgf_local_fonts_disable_preload', [ $this, 'maybe_disable_optimization_options' ] );
        add_filter( 'omgf_local_fonts_disable_unload', [ $this, 'maybe_disable_optimization_options' ] );
        add_filter( 'omgf_local_fonts_hide_fallback_font_stacks', [ $this, 'maybe_hide_fallback_font_stacks' ] );
        add_filter( 'omgf_local_fonts_selected_fallback_font_stack', [ $this, 'maybe_select_fallback_font_stack_option' ], 10, 4 );
        add_filter( 'omgf_local_fonts_check_replace', [ $this, 'maybe_check_replace_option' ], 10, 3 );
        add_filter( 'omgf_local_fonts_disable_replace', [ $this, 'maybe_disable_replace_options' ], 10, 3 );
        add_action( 'omgf_optimize_local_fonts_fallback_font_stacks', [ $this, 'maybe_display_magic_fallbacks' ] );
    }

    /**
     * Extends the logic in @see \OMGF\Admin\Settings\Optimize to check the Replace checkboxes if it's enabled for the current $handle and $font_id.
     *
     * @filter omgf_local_fonts_check_replace
     *
     * @param $checked
     * @param $handle
     * @param $font_id
     *
     * @return string
     */
    public function maybe_check_replace_option( $checked, $handle, $font_id ) {
        $replace = Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT );
        $value   = is_array( $replace ) ? ( $replace[ $handle ][ $font_id ] ?? null ) : null;

        return $value === 'on' ? 'checked' : '';
    }

    /**
     * Disable the option if Smart Optimize is enabled.
     *
     * @return bool
     */
    public function maybe_disable_optimization_options() {
        return ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) );
    }

    /**
     * Extends the logic in @see \OMGF\Admin\Settings\Optimize to disable the Replace checkboxes if Magic Fallbacks is disabled and no Fallback Font Stack is defined.
     *
     * @filter omgf_local_fonts_disable_replace
     *
     * @return bool
     */
    public function maybe_disable_replace_options( $disabled, $handle, $font_id ) {
        $stacks = Wrapper::get_option( 'omgf_pro_fallback_font_stack' );
        $stack  = is_array( $stacks ) ? ( $stacks[ $handle ][ $font_id ] ?? null ) : null;

        return ! Helper::is_magic_fallbacks_enabled() && empty( $stack );
    }

    /**
     * Render an input field containing our auto-generated fallback font stack if Magic Fallbacks is enabled.
     *
     * @param $font_family
     *
     * @return void
     */
    public function maybe_display_magic_fallbacks( $font_family ) {
        $value  = $this->get_magic_fallback_font_stack( $font_family );
        $hidden = ! Helper::is_magic_fallbacks_enabled() ? 'style="display:none;"' : '';

        ?>
        <input <?php echo $hidden; ?> title="<?php echo esc_attr( $value ); ?>" type="text" disabled value="<?php echo esc_attr( $value ); ?>"/>
        <?php
    }

    /**
     * Get the magic fallback font stack.
     *
     * @param $font_family
     *
     * @return string|null
     */
    private function get_magic_fallback_font_stack( $font_family ) {
        $matches = FallbackFontStack::find_best_match( $font_family );

        if ( empty( $matches ) ) {
            return __( 'No match', 'omgf-pro' );
        }

        return FallbackFontStack::format_fallback_stack( $font_family, $matches, true );
    }

    public function maybe_hide_fallback_font_stacks() {
        return Helper::is_magic_fallbacks_enabled();
    }

    /**
     * Extends the logic in @see \OMGF\Admin\Settings\Optimize to select the current Fallback Font Stack if it's set.
     *
     * @filter omgf_local_fonts_selected_fallback_font_stack
     *
     * @param $selected
     * @param $handle
     * @param $font_id
     * @param $current_value
     *
     * @return string
     */
    public function maybe_select_fallback_font_stack_option( $selected, $handle, $font_id, $current_value ) {
        $stacks = Wrapper::get_option( 'omgf_pro_fallback_font_stack' );

        if ( ! is_array( $stacks ) || ! isset( $stacks[ $handle ][ $font_id ] ) ) {
            return $selected;
        }

        return $stacks[ $handle ][ $font_id ] === $current_value ? 'selected' : '';
    }
}
