<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Admin;

use OMGF\Pro\Admin;
use OMGF\Pro\Helper;
use OMGF\Pro\Plugin;
use OMGF\Pro\Wrapper;

class Actions {
    /**
     * Executes all Actions required in the Admin area.
     *
     * @return void
     */
    public function __construct() {
        /**
         * Priorities are set to 8 and 9, because register_settings runs at default priority (10).
         *
         * @see   \OMGF\Admin\Settings create_menu()
         * @since v3.0.5
         */
        add_action( '_admin_menu', [ $this, 'do_enrollment' ], 8 );
        add_action( '_admin_menu', [ $this, 'init_admin' ], 9 );
        add_action( 'admin_notices', [ $this, 'print_notices' ] );
        add_action( 'update_option_omgf_settings', [ $this, 'maybe_flush_global_optimizations' ], 10, 2 );
        add_filter( 'omgf_dashboard_success_message', [ $this, 'append_to_success_message' ] );
        add_action( 'omgf_dashboard_after_success_message', [ $this, 'explain_detection_settings' ] );
        add_action( 'omgf_optimize_local_fonts_replace', [ $this, 'add_hidden_fields' ], 10, 2 );
        add_filter( 'omgf_settings_array_options', [ $this, 'add_array_options' ] );
        add_filter( 'omgf_performance_checker_notice', [ $this, 'maybe_show_performance_checker_notice' ] );
        add_filter( 'omgf_performance_checker_general_text', [ $this, 'maybe_modify_performance_checker_general_text' ] );
        add_action( 'omgf_optimize_settings_content', [ $this, 'maybe_add_smart_optimize_notice' ], 24 );
    }

    /**
     * Register Pro's nested-array options with OMGF's settings save handler, so a malformed (scalar)
     * value is never persisted for them. Keeps free unaware of Pro's option names.
     *
     * @see   \OMGF\Admin\Actions::update_settings()
     * @filter omgf_settings_array_options
     *
     * @param array $option_names
     *
     * @return array
     */
    public function add_array_options( $option_names ) {
        $option_names[] = Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK;
        $option_names[] = Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT;

        return $option_names;
    }

    /**
     * This will make the option always show up in POST, even when no boxes are checked.
     *
     * @return void
     */
    public function add_hidden_fields( $handle, $font_id ) {
        ?>
        <input type="hidden" name="<?php echo esc_attr( Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT ); ?>[<?php echo esc_attr( $handle ); ?>][<?php echo esc_attr( $font_id ); ?>]" value="0"/>
        <?php
    }

    /**
     * Appends additional information to the success message.
     *
     * @param string $message The original success message to be modified.
     *
     * @return string The modified success message with appended information.
     */
    public function append_to_success_message( $message ) {
        return substr_replace( $message, ', ' . __( 'and detected the following:', 'omgf-pro' ), - 1 );
    }

    /**
     * OMGF Pro depends on License Manager and OMGF to function properly.
     *
     * @since v3.0.1 Changed required_plugins to static array. Let's count on it that people don't rename the folder on
     *        purpose.
     * @since v3.7.2 OMGF Pro (and its license manager) requires at least PHP 7.2
     *
     * @codeCoverageIgnore
     */
    public function do_enrollment() {
        if ( version_compare( phpversion(), '7.2.0', '<' ) ) {
            // Clear all previously set notices.
            delete_transient( Notice::OMGF_PRO_ADMIN_NOTICE_TRANSIENT );

            Notice::set_notice(
                    __(
                            'OMGF Pro requires at least PHP 7.2 to run properly. Please upgrade your PHP version to at least PHP 7.2 and re-activate this plugin.',
                            'omgf-pro'
                    ),
                    'error',
                    'omgf_pro_outdated_php_version'
            );

            deactivate_plugins( OMGF_PRO_PLUGIN_BASENAME );

            Plugin::$halt = true;
        }

        $plugin_name = get_plugin_data( OMGF_PRO_PLUGIN_FILE )['Name'];

        if ( class_exists( 'OMGF\Pro\Admin\Notice' ) && (bool) Wrapper::get_option( Notice::OMGF_PRO_ENROLLMENT_TRANSIENT ) !== true ) {
            add_filter(
                    'wp_admin_notice_markup',
                    function ( $markup, $message ) {
                        $replace_message = sprintf(
                                __(
                                        '<strong>Thank you for purchasing OMGF Pro!</strong> Head on over to the <a href="%s">settings screen</a> to take advantage of all the new, fancy features you\'ve just unlocked!',
                                        'omgf-pro'
                                ),
                                admin_url( Admin::OMGF_PRO_SETTINGS_PAGE )
                        );

                        return str_replace( $message, '<p>' . $replace_message . '</p>', $markup );
                    },
                    10,
                    2
            );

            Wrapper::update_option( Notice::OMGF_PRO_ENROLLMENT_TRANSIENT, true );
        }

        /**
         * Deactivate legacy FFW.Press License Manager if it's still active. Throw a notice in admin.
         */
        $legacy_license_manager_active = defined( 'FFWP_LICENSE_MANAGER_PLUGIN_FILE' ) && is_plugin_active( plugin_basename( FFWP_LICENSE_MANAGER_PLUGIN_FILE ) );

        if ( $legacy_license_manager_active ) {
            $license_manager_name = get_plugin_data( FFWP_LICENSE_MANAGER_PLUGIN_FILE )['Name'];

            Notice::set_notice(
                    sprintf(
                            __(
                                    '%1$s has been deactivated. You can safely delete that plugin, since it now comes packaged with %2$s.',
                                    'omgf-pro'
                            ),
                            $license_manager_name,
                            $plugin_name
                    )
            );

            deactivate_plugins( plugin_basename( FFWP_LICENSE_MANAGER_PLUGIN_FILE ) );
        }
    }

    /**
     * Renders a list based on the enabled detection settings.
     *
     * @return void
     */
    public function explain_detection_settings() {
        if ( ! $this->detection_settings_enabled() ) {
            return;
        }
        ?>
        <p>
            <?php _e( 'OMGF Pro detected the following:', 'omgf-pro' ); ?>
        </p>
        <ol>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES ) == 'on' ): ?>
                <li>
                    <?php _e( '@import or @font-face statements containing Google Fonts in one or more inline stylesheets.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS ) == 'on' ): ?>
                <li>
                    <?php _e( '@import or @font-face statements containing Google Fonts in one or more local stylesheets.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS ) == 'on' ): ?>
                <li>
                    <?php _e( '@import or @font-face statements containing Google Fonts in one or more external stylesheets.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS ) == 'on' ): ?>
                <li>
                    <?php _e( 'Asynchronously loaded Google Fonts.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER ) == 'on' ): ?>
                <li>
                    <?php _e( 'Google Fonts using the WebFont Loader JS library.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
            <?php if ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_MATERIAL_ICONS ) == 'on' ): ?>
                <li>
                    <?php _e( 'Material Icons.', 'omgf-pro' ); ?>
                </li>
            <?php endif; ?>
        </ol>
        <?php
    }

    /**
     * Check if any of the detection settings are enabled.
     *
     * @return bool Returns true if any of the detection settings are set to 'on', otherwise false.
     */
    private function detection_settings_enabled() {
        return Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES ) == 'on' ||
               Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS ) == 'on' ||
               Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS ) == 'on' ||
               Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS ) == 'on' ||
               Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER ) == 'on' ||
               Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_MATERIAL_ICONS ) == 'on';
    }

    /**
     * Initialize all Admin related tasks.
     *
     * @return void
     */
    public function init_admin() {
        if ( Plugin::$halt ) {
            return;
        }

        new Settings();
        new Admin();
    }

    /**
     * Add a notice when Smart Preload is enabled.
     *
     * @return void
     */
    public function maybe_add_smart_optimize_notice() {
        if ( empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) || wp_doing_ajax() ) {
            return;
        }

        $heading = esc_html__( 'Smart Optimize is enabled', 'omgf-pro' );
        $message = esc_html__( 'OMGF Pro will analyze each page on its first visit. Smart Optimize results will appear in the admin bar as pages are analyzed.', 'omgf-pro' );

        if ( Helper::is_magic_fallbacks_enabled() ) {
            $heading = esc_html__( 'Smart Optimize and Magic Fallbacks are enabled', 'omgf-pro' );
            $message .= ' ' . esc_html__( 'Mathematically tuned fallback font stacks are added for the fonts OMGF hosts locally.', 'omgf-pro' );
        }

        $this->render_dashboard_notice(
                'dashboard-notice-smart-optimize-enabled',
                $heading,
                $message,
                'success'
        );
    }

    /**
     * Render a dashboard notice.
     *
     * @param        $id
     * @param        $heading
     * @param        $message
     * @param string $type
     *
     * @return void
     */
    private function render_dashboard_notice( $id, $heading, $message, $type = 'info' ) {
        ?>
        <tr valign="top" id="<?php echo esc_attr( $id ); ?>">
            <td colspan="2" class="task-manager-row">
                <div class="task-manager-notice <?php echo esc_attr( $type ); ?>">
                    <h4><?php echo $heading; ?></h4>
                    <p>
                        <?php echo wp_kses( $message, 'post' ); ?>
                    </p>
                </div>
            </td>
        </tr>
        <?php
    }

    /**
     * Flushes OMGF's global optimizations (preloads/unloads) if the Smart Optimize setting is enabled.
     *
     * @param $old_settings
     * @param $settings
     *
     * @return void
     */
    public function maybe_flush_global_optimizations( $old_settings, $settings ) {
        $old_smart_optimize = $old_settings[ Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ] ?? '';
        $new_smart_optimize = $settings[ Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ] ?? '';

        // It's either turned off, or the setting hasn't changed.
        if ( $new_smart_optimize !== 'on' ||
             ( $old_smart_optimize === 'on' && $new_smart_optimize === $old_smart_optimize ) ) {
            return;
        }

        Wrapper::update_option( 'omgf_preload_fonts', [] );
        Wrapper::update_option( 'omgf_unload_fonts', [] );
    }

    /**
     * @param $text
     *
     * @return mixed|string
     */
    public function maybe_modify_performance_checker_general_text( $text ) {
        if ( empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) ) {
            return $text . ' ' . __( '<a href="#omgf-manage-optimized-fonts">Enable Smart Optimize</a> to fix them automatically.', 'omgf-pro' );
        }

        return $text;
    }

    /**
     * Remove Smart Optimize promo if it's enabled.
     *
     * @return bool
     */
    public function maybe_show_performance_checker_notice() {
        return empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) );
    }

    /**
     * Add a notice to the admin screen.
     */
    public function print_notices() {
        Notice::print_notice();
    }
}
