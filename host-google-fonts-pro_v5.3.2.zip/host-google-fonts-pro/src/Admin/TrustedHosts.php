<?php
/**
 * @since     v5.3.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2026 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\Admin;

use OMGF\Pro\Frontend\SmartOptimize\TrustedHosts as Hosts;
use OMGF\Pro\Wrapper;

/**
 * Shows the font hosts reported by visitors which await approval, and the approved font hosts, on the Dashboard.
 */
class TrustedHosts {
	const ACTION = 'omgf_pro_trusted_hosts';

	/**
	 * Query parameter which keeps the Whitelisted Font Hosts table expanded.
	 */
	const OPEN_PARAM = 'omgf_pro_font_hosts';

	/**
	 * ID of the Whitelisted Font Hosts row.
	 */
	const ANCHOR = 'omgf-pro-whitelisted-font-hosts';

	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'omgf_optimize_settings_content', [ $this, 'maybe_render_pending_hosts' ], 24 );
		/**
		 * Right below the Smart Optimize (Pro) option (80).
		 */
		add_action( 'omgf_optimize_settings_content', [ $this, 'maybe_render_font_hosts' ], 85 );
		add_action( 'admin_post_' . self::ACTION, [ $this, 'handle_action' ] );
	}

	/**
	 * Render a Dashboard notice listing the hosts awaiting approval.
	 *
	 * @action omgf_optimize_settings_content
	 *
	 * @return void
	 */
	public function maybe_render_pending_hosts() {
		$pending = Hosts::get_pending_hosts();

		if ( empty( $pending ) || ! $this->is_smart_optimize_enabled() ) {
			return;
		}

		uasort(
			$pending,
			function ( $a, $b ) {
				return ( $b['last_seen'] ?? 0 ) <=> ( $a['last_seen'] ?? 0 );
			}
		);
		?>
		<tr valign="top" id="dashboard-notice-smart-optimize-pending-hosts">
			<td colspan="2" class="task-manager-row">
				<div class="task-manager-notice info">
					<h4><?php echo esc_html__( 'Smart Optimize needs your approval', 'omgf-pro' ); ?></h4>
					<p>
						<?php echo esc_html__(
							'Smart Optimize found 3rd party fonts which should be loaded early. Only trust hosts you recognize, e.g. icon packs and/or font providers. Until explicitly trusted, these fonts aren\'t preloaded.',
							'omgf-pro'
						); ?>
					</p>
					<ul class="omgf-pro-trusted-hosts">
						<?php foreach ( $pending as $host => $meta ) : ?>
							<li>
								<code><?php echo esc_html( $host ); ?></code>
								<em><?php echo esc_html(
										sprintf(
										/* translators: %s: human-readable time difference, e.g. 2 hours */
											__( 'last reported %s ago', 'omgf-pro' ),
											human_time_diff( (int) ( $meta['last_seen'] ?? time() ) )
										)
									); ?></em>
								<a class="button button-small button-primary"
								   href="<?php echo esc_url( $this->get_action_url( 'trust', $host ) ); ?>"><?php echo esc_html__( 'Trust', 'omgf-pro' ); ?></a>
								<a class="button button-small"
								   href="<?php echo esc_url( $this->get_action_url( 'ignore', $host ) ); ?>"><?php echo esc_html__( 'Ignore', 'omgf-pro' ); ?></a>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</td>
		</tr>
		<?php
	}

	/**
	 * Render a collapsible table listing the whitelisted and ignored hosts, below the Smart Optimize option.
	 *
	 * @action omgf_optimize_settings_content
	 *
	 * @return void
	 */
	public function maybe_render_font_hosts() {
		if ( ! $this->is_smart_optimize_enabled() ) {
			return; // @codeCoverageIgnore
		}

		$approved = Hosts::get_approved_hosts();
		$ignored  = Hosts::get_ignored_hosts();

		ksort( $approved );
		ksort( $ignored );

		// Keep the table expanded after trusting or removing a host from it.
		$is_open = isset( $_GET[ self::OPEN_PARAM ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<tr valign="top" id="<?php echo esc_attr( self::ANCHOR ); ?>">
			<?php // No visible label: this row belongs to the Smart Optimize (Pro) option right above it. ?>
			<th scope="row"><span class="screen-reader-text"><?php echo esc_html__( 'Smart Optimize Whitelist', 'omgf-pro' ); ?></span></th>
			<td>
				<?php if ( empty( $approved ) && empty( $ignored ) ) : ?>
					<p class="description omgf-pro-font-hosts-empty"><?php echo esc_html__( 'No whitelisted hosts', 'omgf-pro' ); ?></p>
				<?php else : ?>
					<details class="omgf-pro-font-hosts" <?php echo $is_open ? 'open' : ''; ?>>
						<summary><?php echo esc_html( $this->get_summary( count( $approved ), count( $ignored ) ) ); ?></summary>
						<p class="description">
							<?php echo esc_html__(
								'Smart Optimize only preloads 3rd party fonts if they\'re hosted on a whitelisted host.',
								'omgf-pro'
							); ?>
						</p>
						<?php if ( ! empty( $approved ) ) : ?>
							<?php $this->render_hosts_table( $approved, 'revoke' ); ?>
						<?php endif; ?>
						<?php if ( ! empty( $ignored ) ) : ?>
							<h4><?php echo esc_html__( 'Ignored Hosts', 'omgf-pro' ); ?></h4>
							<?php $this->render_hosts_table( $ignored, 'trust' ); ?>
						<?php endif; ?>
					</details>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * The text of the link expanding the whitelisted (and ignored) hosts.
	 *
	 * @param int $approved Number of whitelisted hosts.
	 * @param int $ignored  Number of ignored hosts.
	 *
	 * @return string
	 */
	private function get_summary( $approved, $ignored ) {
		if ( $approved > 0 ) {
			/* translators: %d: number of whitelisted hosts */
			return sprintf( _n( 'Show %d whitelisted host', 'Show %d whitelisted hosts', $approved, 'omgf-pro' ), $approved );
		}

		/* translators: %d: number of ignored hosts */
		return sprintf( _n( 'No whitelisted hosts. Show %d ignored host', 'No whitelisted hosts. Show %d ignored hosts', $ignored, 'omgf-pro' ), $ignored );
	}

	/**
	 * @param array  $hosts
	 * @param string $action revoke|trust
	 *
	 * @return void
	 */
	private function render_hosts_table( $hosts, $action ) {
		?>
		<table class="widefat striped omgf-pro-font-hosts-table">
			<tbody>
			<?php foreach ( $hosts as $host => $meta ) : ?>
				<tr>
					<td><code><?php echo esc_html( $host ); ?></code></td>
					<td><em><?php echo esc_html( $this->get_status_label( $action, $meta ) ); ?></em></td>
					<td class="omgf-pro-font-hosts-action">
						<?php if ( $action === 'trust' ) : ?>
							<a class="button button-small"
							   href="<?php echo esc_url( $this->get_action_url( 'trust', $host, true ) ); ?>"><?php echo esc_html__( 'Trust', 'omgf-pro' ); ?></a>
						<?php else : ?>
							<a href="<?php echo esc_url( $this->get_action_url( 'revoke', $host, true ) ); ?>"><?php echo esc_html__( 'Remove', 'omgf-pro' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * @param string $action revoke|trust
	 * @param array  $meta
	 *
	 * @return string
	 */
	private function get_status_label( $action, $meta ) {
		if ( $action === 'trust' ) {
			return __( 'marked as ignored', 'omgf-pro' );
		}

		return ( $meta['source'] ?? '' ) === 'admin' ?
			__( 'automatically marked as trusted', 'omgf-pro' ) :
			__( 'marked as trusted', 'omgf-pro' );
	}

	/**
	 * Trust, ignore or revoke a host.
	 *
	 * @action admin_post_omgf_pro_trusted_hosts
	 *
	 * @return void
	 */
	public function handle_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'omgf-pro' ), 403 );
		}

		check_admin_referer( self::ACTION );

		$this->do_action(
			sanitize_key( wp_unslash( $_GET['do'] ?? '' ) ),
			sanitize_text_field( wp_unslash( $_GET['host'] ?? '' ) )
		);

		$redirect = admin_url( \OMGF\Admin\Settings::OMGF_OPTIONS_GENERAL_PAGE_OPTIMIZE_WEBFONTS );

		if ( ! empty( $_GET[ self::OPEN_PARAM ] ) ) {
			$redirect = add_query_arg( self::OPEN_PARAM, 1, $redirect ) . '#' . self::ANCHOR;
		}

		// @codeCoverageIgnoreStart
		if ( ! defined( 'DAAN_DOING_TESTS' ) ) {
			wp_safe_redirect( $redirect );
			exit;
		}
		// @codeCoverageIgnoreEnd
	}

	/**
	 * @param string $action trust|ignore|revoke
	 * @param string $host
	 *
	 * @return bool
	 */
	public function do_action( $action, $host ) {
		switch ( $action ) {
			case 'trust':
				return Hosts::approve( $host );
			case 'ignore':
				return Hosts::ignore( $host );
			case 'revoke':
				return Hosts::revoke( $host );
		}

		return false;
	}

	/**
	 * @param string $action
	 * @param string $host
	 * @param bool   $keep_open Whether to keep the Whitelisted Font Hosts table expanded after redirecting back.
	 *
	 * @return string
	 */
	private function get_action_url( $action, $host, $keep_open = false ) {
		$args = [
			'action' => self::ACTION,
			'do'     => $action,
			'host'   => rawurlencode( $host ),
		];

		if ( $keep_open ) {
			$args[ self::OPEN_PARAM ] = 1;
		}

		return wp_nonce_url( add_query_arg( $args, admin_url( 'admin-post.php' ) ), self::ACTION );
	}

	/**
	 * @return bool
	 */
	private function is_smart_optimize_enabled() {
		return ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) && ! wp_doing_ajax();
	}
}
