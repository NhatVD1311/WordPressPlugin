<?php
/**
 * @since     v5.2.11
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Wrapper;

/**
 * Removes entries from the Optimized Fonts table whose family isn't the name of an actual font,
 * e.g. 'Arial,Helvetica,sans-serif !important', 'var(--tve-font-family,Mulish)' or 'inherit'.
 *
 * Whenever the Google Fonts API returned no fonts for a family found in a local or inline
 * stylesheet, OMGF Pro < v5.2.9 ran the optimization again with the entire document. OMGF's
 * parser then captured every font-family declaration in that document — not just the ones
 * inside @font-face statements — and stored each of them as a font family.
 *
 * These entries can't be downloaded, generate no CSS, and are the reason Magic Fallbacks kept
 * asking users to contact support about fonts which never existed.
 *
 * @see \OMGF\Pro\Frontend\Optimize::build_font_face_search_replace() Fixed in v5.2.9.
 * @see \OMGF\Pro\Frontend\MagicFallbacks::process_font_families()    Ignores them since v5.2.11.
 */
class V5211 {
	/** @var $version string The version number this migration script was introduced with. */
	private $version = '5.2.11';
	
	/** @var array $options_to_clean */
	private $options_to_clean = [
		'omgf_optimized_fonts',
		'omgf_optimized_fonts_frontend',
	];
	
	/**
	 * Build
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		/**
		 * OMGF decides what is (and isn't) a font family name. Without it, there's nothing to
		 * clean up, so we bail without storing the version number, and try again on the next
		 * load, i.e., once OMGF has been updated too.
		 */
		if ( ! Wrapper::has_font_family_validation() ) {
			return; // @codeCoverageIgnore
		}
		
		foreach ( $this->options_to_clean as $option_name ) {
			$this->clean_option( $option_name );
		}
		
		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}
	
	/**
	 * Remove invalid font families from the given option.
	 *
	 * @param string $option_name
	 *
	 * @return void
	 */
	private function clean_option( $option_name ) {
		$fonts = Wrapper::get_option( $option_name, [] );
		
		if ( empty( $fonts ) || ! is_array( $fonts ) ) {
			return;
		}
		
		$cleaned = false;
		
		foreach ( $fonts as $handle => $font_families ) {
			if ( ! is_array( $font_families ) ) {
				continue;
			}
			
			foreach ( $font_families as $key => $font ) {
				/**
				 * Anything but an object with a string family is malformed data, which we leave
				 * alone. This also keeps it away from urldecode(), which throws a TypeError when
				 * it's handed an array.
				 */
				if ( ! is_string( $font->family ?? null ) ) {
					continue;
				}
				
				/**
				 * Font families are stored URL encoded, because they may contain spaces.
				 */
				if ( Wrapper::is_valid_font_family( urldecode( $font->family ) ) ) {
					continue;
				}
				
				unset( $fonts[ $handle ][ $key ] );
				
				$cleaned = true;
			}
			
			// If the handle has no fonts left, remove it.
			if ( empty( $fonts[ $handle ] ) ) {
				unset( $fonts[ $handle ] );
				
				$cleaned = true;
			}
		}
		
		if ( $cleaned ) {
			Wrapper::update_option( $option_name, $fonts );
		}
	}
}
