<?php
/**
 * @since     v5.2.9
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\MagicFallbacks\FallbackFontStack;
use OMGF\Pro\Wrapper;

class V529 {
	/** @var $version string The version number this migration script was introduced with. */
	private $version = '5.2.9';
	
	/** @var array $options_to_clean */
	private $options_to_clean = [
		'omgf_optimized_fonts',
		'omgf_optimized_fonts_frontend',
	];
	
	/**
	 * Build
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		foreach ( $this->options_to_clean as $option_name ) {
			$this->clean_option( $option_name );
		}
		
		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}
	
	/**
	 * Clean Magic Fallback aliases from the given option.
	 *
	 * @param string $option_name
	 *
	 * @return void
	 */
	private function clean_option( $option_name ) {
		$fonts = Wrapper::get_option( $option_name, [] );
		
		if ( empty( $fonts ) || ! is_array( $fonts ) ) {
			return; // @codeCoverageIgnore
		}
		
		$cleaned = false;
		
		foreach ( $fonts as $handle => $font_families ) {
			if ( ! is_array( $font_families ) ) {
				continue; // @codeCoverageIgnore
			}
			
			foreach ( $font_families as $key => $font ) {
				if ( ! isset( $font->family ) ) {
					continue; // @codeCoverageIgnore
				}
				
				$family = urldecode( $font->family );
				
				if ( FallbackFontStack::is_alias( $family ) ) {
					$has_downloadable_source = false;
					
					if ( isset( $font->variants ) && is_array( $font->variants ) ) {
						foreach ( $font->variants as $variant ) {
							if ( ! empty( $variant->woff2 ) ) {
								$has_downloadable_source = true;
								break;
							}
						}
					}
					
					if ( ! $has_downloadable_source ) {
						unset( $fonts[ $handle ][ $key ] );
						$cleaned = true;
					}
				}
			}
			
			// If the handle has no fonts left, remove it.
			if ( empty( $fonts[ $handle ] ) ) {
				unset( $fonts[ $handle ] );
				$cleaned = true;
			}
		}
		
		if ( $cleaned ) {
			Wrapper::update_option( $option_name, $fonts );
		}
	}
}
