<?php
/**
 * @since     v5.2.2
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize;
use OMGF\Pro\Wrapper;

/**
 * @codeCoverageIgnore
 */
class V522 {
	/** @var $version string The version number this migration script was introduced with. */
	private $version = '5.2.2';
	
	/**
	 * Build
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		if ( ! $this->update_db_table() ) {
			return;
		}
		
		if ( ! $this->drop_old_unique_key() ) {
			return;
		}
		
		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}
	
	/**
	 * Update the Smart Optimize table.
	 *
	 * @return bool
	 */
	private function update_db_table() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . SmartOptimize::ID;
		$sql        = "CREATE TABLE $table_name (
			    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			    url varchar(191) NOT NULL DEFAULT '',
			    is_mobile tinyint(1) NOT NULL DEFAULT 0,
			    preload longtext,
			    unload longtext,
			    labels longtext,
			    stylesheet_hash varchar(32),
			    detected_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			    PRIMARY KEY (id),
			    UNIQUE KEY url_mobile (url, is_mobile)
			) {$wpdb->get_charset_collate()}";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		dbDelta( $sql );
		
		return ! empty( $wpdb->get_var( "SHOW COLUMNS FROM $table_name LIKE 'is_mobile'" ) );
	}
	
	/**
	 * @return bool
	 */
	private function drop_old_unique_key() {
		global $wpdb;
		
		$table_name   = $wpdb->prefix . SmartOptimize::ID;
		$index_exists = $wpdb->get_var( "SHOW INDEX FROM $table_name WHERE Key_name = 'url'" );
		
		if ( ! $index_exists ) {
			return true;
		}
		
		return $wpdb->query( "ALTER TABLE $table_name DROP INDEX `url`" ) !== false;
	}
}
