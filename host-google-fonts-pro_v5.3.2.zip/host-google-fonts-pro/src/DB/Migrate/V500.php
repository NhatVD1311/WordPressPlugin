<?php
/**
 * `@since`     v5.0.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize;
use OMGF\Pro\Helper;
use OMGF\Pro\Wrapper;

/**
 * @codeCoverageIgnore
 */
class V500 {
	/** @var $version string The version number this migration script was introduced with. */
	private $version = '5.0.0';
	
	/**
	 * Build
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		if ( ! $this->create_db_table() ) {
			return;
		}
		
		$this->migrate_smart_preload();
		$this->remove_google_fonts_checker();
		
		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}
	
	/**
	 * Create the Smart Optimize table.
	 *
	 * @return bool
	 */
	private function create_db_table() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . SmartOptimize::ID;
		$sql        = "CREATE TABLE $table_name (
			    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			    url varchar(191) NOT NULL DEFAULT '',
			    preload longtext,
			    unload longtext,
			    labels longtext,
			    stylesheet_hash varchar(32),
			    detected_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			    PRIMARY KEY (id)
			) {$wpdb->get_charset_collate()}";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
		
		return $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name;
	}
	
	/**
	 * Delete Smart Preload Data, because Smart Optimize should run again to detect font unloads and used subsets.
	 *
	 * @return void
	 */
	private function migrate_smart_preload() {
		if ( Wrapper::get_option( 'auto_preload' ) ) {
			// Enable Smart Optimize
			Wrapper::update_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE, true );
			
			// Delete Smart Preload option and data
			Wrapper::delete_option( 'omgf_pro_preload_fonts' );
			Wrapper::delete_option( 'auto_preload' );
			
			// Delete global optimizations from OMGF.
			Wrapper::update_option( 'omgf_preload_fonts', [] );
			Wrapper::update_option( 'omgf_unload_fonts', [] );
		}
	}
	
	/**
	 * Since Run Google Fonts Checker in the Background is superseded by the Smart Optimize feature,
	 * we can remove the Google Fonts Checker data.
	 *
	 * @return void
	 */
	private function remove_google_fonts_checker() {
		delete_transient( 'omgf_pro_run_google_fonts_checker' );
		
		Wrapper::delete_option( 'google_fonts_checker' );
		Wrapper::delete_option( 'checker_timeout' );
	}
}
