<?php
/**
 * @since     v4.0.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin;
use OMGF\Pro\Admin\Notice;
use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Wrapper;

/**
 * @codeCoverageIgnore
 */
class V400 {
	/** @var $current_version false|string The version that initially triggered the migration scripts. */
	private $current_version;

	/** @var $version string The version number this migration script was introduced with. */
	private $version = '4.0.0';

	/**
	 * Buid
	 *
	 * @return void
	 */
	public function __construct( $current_version ) {
		$this->current_version = $current_version;

		$this->init();
	}

	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		// Don't run this migration script if it's a fresh install.
		if ( $this->current_version === false ) {
			return;
		}

		add_action( 'init', [ $this, 'add_info_notice' ] );

		// Remove this because we're no longer using it, and the new option (process_async_fonts) will be automatically enabled when needed.
		Wrapper::delete_option( 'remove_async_fonts' );
		// Remove Auto Config because it runs on Save & Optimize now.
		Wrapper::delete_option( 'auto_config' );
		// Should've removed this a looong time ago!
		Wrapper::delete_option( 'process_early_access' );

		/**
		 * Delete all detection settings to make sure every user gets them automatically configured after upgrading.
		 */
		Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS );
		Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES );
		Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER );
		Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS );

		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}

	/**
	 * Add an informational notice to prompt users for auto-optimization.
	 *
	 * @return void
	 */
	public function add_info_notice() {
		Notice::set_notice(
			sprintf(
				__( 'Welcome to OMGF Pro v4! 🎉 <a href="%s" target="_blank">Click here to read about all the new, exciting features</a>!', 'omgf-pro' ),
				'https://daan.dev/blog/wordpress/omgf-v6-omgf-pro-v4/'
			)
		);

		$admin = new Admin();

		add_filter( 'omgf_optimize_run_args', [ $admin, 'add_auto_config_arg' ] );

		Notice::set_notice(
			sprintf(
				__( 'To take advantage of all of OMGF Pro\'s cool, new features, <a href="%s">click here</a> to run a quick auto-optimization.', 'omgf-pro' ),
				Wrapper::no_cache_optimize_url()
			),
			'info'
		);
	}
}
