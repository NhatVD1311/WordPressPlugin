<?php
/**
 * @since     v5.3.1
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2026 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\DB\Migrate;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize;
use OMGF\Pro\Wrapper;

/**
 * Empties the Smart Optimize table, so pages are analyzed again.
 *
 * OMGF Pro < v5.3.1 stored results for every path visitors browsed to, so each variation of a page got its own row,
 * e.g. AffiliateWP's referral URLs (/ref/<affiliate>/), which may contain an affiliate's email address. Since v5.3.1,
 * results are stored for the canonical path of the page, so these rows will never be used again. Emptying the table
 * (instead of removing specific paths) cleans up such rows for any plugin's URLs.
 *
 * The stylesheets generated for these results are kept, because pages served from a (page) cache may still use them,
 * just like when the table is emptied after a font host is approved.
 *
 * @see \OMGF\Pro\Helper::get_smart_optimize_path()
 * @see \OMGF\Pro\Cache::clean_up_smart_optimize_results()
 */
class V531 {
	/** @var $version string The version number this migration script was introduced with. */
	private $version = '5.3.1';
	
	/**
	 * Build
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Initialize
	 *
	 * @return void
	 */
	private function init() {
		/**
		 * If the table couldn't be emptied, we bail without storing the version number, so we try again on the next
		 * load, because its rows may contain personal data.
		 */
		if ( ! $this->empty_smart_optimize_table() ) {
			return;
		}
		
		/**
		 * Update stored version number.
		 */
		Wrapper::update_option( Settings::OMGF_PRO_DB_VERSION, $this->version );
	}
	
	/**
	 * Empties the Smart Optimize table.
	 *
	 * @return bool False if the table exists, but couldn't be emptied.
	 */
	private function empty_smart_optimize_table() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . SmartOptimize::ID;
		
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) ) ) !== $table_name ) {
			return true; // @codeCoverageIgnore
		}
		
		return $wpdb->query( "TRUNCATE TABLE `$table_name`" ) !== false;
	}
}
