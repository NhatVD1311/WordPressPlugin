<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro;

use OMGF\Pro\Admin\Settings;

class Helper {
	
	/** @var array $smart_optimize_results */
	private static $smart_optimize_results = [];
	
	/** @var ?bool $is_mobile_column_exists */
	private static $is_mobile_column_exists = null;
	
	/**
	 * Cleans a given variable by sanitizing its value.
	 *
	 * @param mixed $var The variable to be cleaned. Can be a scalar value or an array of values.
	 *
	 * @return mixed Returns the cleaned variable. If the input is scalar, it will be sanitized accordingly.
	 *               If an array is passed, the method is applied recursively to each element.
	 */
	public static function clean( $var ) {
		// If the variable is an array, recursively apply the function to each element of the array.
		if ( is_array( $var ) ) {
			return array_map( [ '\OMGF\Pro\Helper', 'clean' ], $var );
		}
		
		// If the variable is a scalar value (string, integer, float, boolean).
		if ( is_scalar( $var ) ) {
			// Parse the variable using the wp_parse_url function.
			$parsed = wp_parse_url( $var );
			// If the variable has a scheme (e.g. http:// or https://), sanitize the variable using the esc_url_raw function.
			if ( isset( $parsed['scheme'] ) ) {
				return esc_url_raw( wp_unslash( $var ), wp_allowed_protocols() );
			}
			
			// If the variable does not have a scheme, sanitize the variable using the sanitize_text_field function.
			return sanitize_text_field( wp_unslash( $var ) );
		}
		
		// If the variable is not an array or a scalar value, return the variable unchanged.
		return $var; // @codeCoverageIgnore
	}
	
	/**
	 * Is Magic Fallbacks enabled?
	 *
	 * @return bool
	 */
	public static function is_magic_fallbacks_enabled() {
		return Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_MAGIC_FALLBACKS );
	}
	
	/**
	 * @since v5.2.7 Added nonce and capability check to prevent unauthenticated exploitation.
	 *
	 * @param array $post
	 *
	 * @return bool
	 */
	public static function is_running_auto_config( $post = [] ) {
		$has_param = array_key_exists( 'omgf_pro_auto_config', $_GET ) || array_key_exists( 'omgf_pro_auto_config', $post );
		
		if ( ! $has_param ) {
			return false; // @codeCoverageIgnore
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			return false; // @codeCoverageIgnore
		}
		
		$nonce = $_GET['omgf_optimize'] ?? $post['omgf_optimize'] ?? '';
		
		// Normalize the nonce before verification.
		if ( ! is_string( $nonce ) ) {
			return false; // @codeCoverageIgnore
		}
		
		$nonce = sanitize_text_field( wp_unslash( $nonce ) );
		
		return wp_verify_nonce( $nonce, 'omgf_optimize' ) !== false;
	}
	
	/**
	 * @return mixed
	 */
	public static function replaced_stylesheets() {
		static $replaced_stylesheets;
		
		if ( $replaced_stylesheets === null ) {
			$replaced_stylesheets = Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT, [] );
		}
		
		/** @see \get_option() should take care of this, but sometimes it doesn't. */
		if ( is_string( $replaced_stylesheets ) ) {
			return maybe_unserialize( $replaced_stylesheets );
		}
		
		return Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT, [] );
	}
	
	/**
	 * Should we run Auto Config?
	 * @since v3.7.2 Allow manually triggering Auto Config by appending ?omgf_optimize=1&omgf_pro_auto_config=1 to an URL.
	 * @return bool
	 */
	public static function run_auto_config() {
		return Wrapper::is_running_optimize() || defined( 'OMGF_PRO_TESTS_ROOT' );
	}
	
	/**
	 * Only run Smart Optimize if the current page is not a 404 page, and:
	 * - The current user is a logged-in administrator, or:
	 *   - Smart Optimize is enabled, and
	 *   - Smart Optimize results are not available for the current URL.
	 *
	 * @since v5.3.1 Not for administrators on 404 pages either, because a 404's path may share its canonical path with an
	 *               existing page, e.g. /blog/page/2/ref/<affiliate>/ (a 404) and /blog/page/2/.
	 *
	 * @since v5.3.2 Not on pages excluded from Smart Optimize either, e.g. WooCommerce's order received pages.
	 *
	 * @see   Helper::is_smart_optimize_excluded()
	 *
	 * @return bool
	 */
	public static function should_smart_optimize_run() {
		if ( is_404() || self::is_smart_optimize_excluded() ) {
			return false;
		}
		
		return current_user_can( 'manage_options' ) || ( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) && empty( self::get_smart_optimize_results() ) );
	}
	
	/**
	 * Whether Smart Optimize should leave the current page alone, i.e. it's not analyzed and no results are applied to it.
	 *
	 * Pages are excluded by compatibility fixes hooking into the omgf_pro_smart_optimize_excluded filter, e.g. pages which
	 * shouldn't be page cached (@see \OMGF\Pro\Frontend\SmartOptimize\Compatibility::exclude_non_cacheable_pages()) and
	 * WooCommerce's endpoints (@see \OMGF\Pro\Compatibility\WooCommerce::exclude_endpoints()): personal pages, which
	 * may share their canonical path with another page, while their contents (and the fonts they use) are different.
	 *
	 * @since v5.3.2
	 *
	 * @return bool
	 */
	public static function is_smart_optimize_excluded() {
		/**
		 * Allows excluding (or including) the current page from Smart Optimize. Conditional tags, e.g. is_page() or
		 * is_checkout(), can be used.
		 *
		 * @since v5.3.2
		 *
		 * @param bool $excluded Whether the current page is excluded from Smart Optimize.
		 */
		return (bool) apply_filters( 'omgf_pro_smart_optimize_excluded', false );
	}
	
	/**
	 * Query the database for Smart Optimize results for the current URL.
	 *
	 * @since v5.3.2 No results are returned for the current URL if it's excluded from Smart Optimize.
	 *
	 * @param string $path
	 * @param ?int   $is_mobile
	 *
	 * @return ?object
	 */
	public static function get_smart_optimize_results( $path = '', $is_mobile = null ) {
		global $wpdb;
		
		if ( $path === '' && self::is_smart_optimize_excluded() ) {
			return null;
		}
		
		$path      = self::normalize_smart_optimize_path( $path );
		$is_mobile = $is_mobile ?? ( wp_is_mobile() ? 1 : 0 );
		$key       = "$path$is_mobile";
		
		if ( ! isset( self::$smart_optimize_results[ $key ] ) ) {
			$table_name = $wpdb->prefix . API\SmartOptimize::ID;
			
			if ( ! self::is_mobile_column_exists( $table_name ) ) {
				self::$smart_optimize_results[ $key ] = $wpdb->get_row(
					$wpdb->prepare( "SELECT * FROM $table_name WHERE url = %s", $path )
				);
			} else {
				self::$smart_optimize_results[ $key ] = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT * FROM $table_name WHERE url = %s AND is_mobile = %d",
						$path,
						$is_mobile
					)
				);
			}
		}
		
		return self::$smart_optimize_results[ $key ];
	}
	
	/**
	 * Get a trailing slashed version of the current request or $path.
	 *
	 * @param string $path
	 *
	 * @return string
	 */
	public static function normalize_smart_optimize_path( $path = '' ) {
		if ( $path === '/' ) {
			return $path;
		}
		
		if ( ! $path ) {
			return self::get_smart_optimize_path();
		}
		
		// With plain permalinks, the path is a query string, e.g. /?p=123.
		if ( str_contains( $path, '?' ) ) {
			return $path;
		}
		
		return trailingslashit( $path );
	}
	
	/**
	 * The (trailing slashed) path Smart Optimize stores and looks up the results for the current request with.
	 *
	 * Variations of the same post, page or front page share its canonical path, e.g. AffiliateWP's referral URLs
	 * (/ref/<affiliate>/), so they're analyzed once and whatever's in their path (e.g. an email address) isn't stored.
	 *
	 * @since v5.3.1
	 *
	 * @return string
	 */
	public static function get_smart_optimize_path() {
		global $wp;
		
		$path = empty( $wp->request ) ? self::get_query_path() : '/' . trailingslashit( $wp->request );
		
		/**
		 * Conditional tags only work once the main query has run.
		 *
		 * The front page isn't simply /, because multilingual plugins (e.g. Polylang or WPML) may serve a front page
		 * per language, e.g. /nl/, which might use different fonts (or subsets).
		 */
		if ( did_action( 'wp' ) ) {
			if ( is_singular() ) {
				$path = self::get_permalink_path( get_queried_object_id() ) ?: self::remove_rewrite_endpoints( $path );
			} else {
				$path = self::remove_rewrite_endpoints( $path );
			}
		}
		
		/**
		 * Allows normalizing the path Smart Optimize stores its results for, e.g. to remove (personal) data from it.
		 *
		 * @since v5.3.1
		 *
		 * @param string $path A root-relative path, e.g. /blog/hello-world/.
		 */
		$filtered_path = apply_filters( 'omgf_pro_smart_optimize_path', $path );
		
		if ( ! is_string( $filtered_path ) || $filtered_path === '' || $filtered_path[0] !== '/' ) {
			return $path;
		}
		
		return self::normalize_smart_optimize_path( $filtered_path );
	}
	
	/**
	 * With plain permalinks, every request's path is /, so the query vars identify the page instead, e.g. /?p=123 or
	 * /?cat=4&paged=2. Only query vars which determine the content are used, because plugins may register query vars
	 * containing personal data (e.g. a referral code or email address). Search terms are left out too (the search
	 * results page is analyzed once), because they're entered by visitors.
	 *
	 * With pretty permalinks, a request without a path is the front page (or a page which only uses query vars),
	 * which keeps /.
	 *
	 * @since v5.3.2
	 *
	 * @return string
	 */
	private static function get_query_path() {
		global $wp;
		
		if ( get_option( 'permalink_structure' ) ) {
			return '/';
		}
		
		$query_vars = [];
		
		foreach ( (array) $wp->query_vars as $key => $value ) {
			if ( ! in_array( $key, self::get_content_query_vars(), true ) ) {
				continue;
			}
			
			// E.g. post_type can be an array. Its order doesn't matter.
			if ( is_array( $value ) ) {
				$value = array_filter( $value, 'is_scalar' );
				
				sort( $value );
				
				$value = implode( ',', $value );
			}
			
			if ( ! is_scalar( $value ) || (string) $value === '' ) {
				continue;
			}
			
			$query_vars[ $key ] = $key === 's' ? '' : (string) $value;
		}
		
		if ( empty( $query_vars ) ) {
			return '/';
		}
		
		ksort( $query_vars );
		
		return '/?' . http_build_query( $query_vars );
	}
	
	/**
	 * Query vars which determine which content is shown: WordPress' own, and those of public post types and taxonomies.
	 *
	 * @since v5.3.2
	 *
	 * @return string[]
	 */
	private static function get_content_query_vars() {
		$query_vars = [
			'p', 'page_id', 'name', 'pagename', 'attachment', 'attachment_id', 'subpost', 'subpost_id', 'preview',
			'cat', 'category_name', 'tag', 'tag_id', 'taxonomy', 'term', 'author', 'author_name', 'post_type',
			'year', 'monthnum', 'day', 'w', 'm', 'hour', 'minute', 'second', 'paged', 'page', 'cpage', 's',
		];
		
		foreach ( [ get_post_types( [ 'public' => true ], 'objects' ), get_taxonomies( [ 'public' => true ], 'objects' ) ] as $objects ) {
			foreach ( $objects as $object ) {
				if ( is_string( $object->query_var ?? null ) && $object->query_var !== '' ) {
					$query_vars[] = $object->query_var;
				}
			}
		}
		
		return $query_vars;
	}
	
	/**
	 * The path of a post's permalink, relative to the home URL (just like $wp->request), so it doesn't include the
	 * subdirectory WordPress might be installed in.
	 *
	 * @param int $post_id
	 *
	 * @return string An empty string if the permalink doesn't have a usable path, e.g. when using plain permalinks.
	 */
	private static function get_permalink_path( $post_id ) {
		$permalink = get_permalink( $post_id );
		
		if ( ! is_string( $permalink ) || wp_parse_url( $permalink, PHP_URL_QUERY ) !== null ) {
			return '';
		}
		
		$path      = (string) wp_parse_url( $permalink, PHP_URL_PATH );
		$home_path = untrailingslashit( (string) wp_parse_url( home_url(), PHP_URL_PATH ) );
		
		if ( $home_path !== '' && str_starts_with( $path, $home_path . '/' ) ) {
			$path = substr( $path, strlen( $home_path ) );
		}
		
		return trailingslashit( '/' . ltrim( $path, '/' ) );
	}
	
	/**
	 * Removes the rewrite endpoint (e.g. /ref/<affiliate>/) the current request matched from $path.
	 *
	 * The endpoint is determined using the rewrite rule WordPress matched instead of the query vars, because plugins may
	 * register an endpoint without a query var, or remove it from the query vars before the page is rendered, like
	 * AffiliateWP does.
	 *
	 * @param string $path A trailing slashed path, i.e. the current request.
	 *
	 * @return string
	 */
	private static function remove_rewrite_endpoints( $path ) {
		global $wp, $wp_rewrite;
		
		$rule = $wp->matched_rule ?? '';
		
		if ( ! is_string( $rule ) || $rule === '' ) {
			return $path;
		}
		
		foreach ( (array) ( $wp_rewrite->endpoints ?? [] ) as $endpoint ) {
			$name = $endpoint[1] ?? '';
			
			// WordPress adds this pattern to rules for endpoints. Its value is everything after its name, e.g. jane/extra.
			$pattern = $name . '(/(.*))?/?$';
			
			if ( ! is_string( $name ) || $name === '' || ! str_ends_with( $rule, $pattern ) ) {
				continue;
			}
			
			$prefix = self::get_rule_prefix( substr( $rule, 0, -strlen( $pattern ) ), $pattern, trim( $path, '/' ) );
			
			if ( $prefix !== null ) {
				return $prefix;
			}
		}
		
		return $path;
	}
	
	/**
	 * Gets the part of $request matched by the rule's $base, i.e. everything before the endpoint matched by $pattern.
	 *
	 * @param string $base    The rule without the endpoint's pattern, e.g. category/(.+?)/
	 * @param string $pattern The endpoint's pattern, e.g. ref(/(.*))?/?$
	 * @param string $request The request, without leading and trailing slashes.
	 *
	 * @return ?string A trailing slashed path, or null if the rule doesn't match $request.
	 */
	private static function get_rule_prefix( $base, $pattern, $request ) {
		// Like WordPress, try the request and its URL decoded version.
		foreach ( array_unique( [ $request, urldecode( $request ) ] ) as $subject ) {
			if ( ! preg_match( "#^(?P<omgf_prefix>$base)$pattern#", $subject, $matches ) ) {
				continue;
			}
			
			$prefix = trim( $matches['omgf_prefix'], '/' );
			
			if ( $prefix === '' ) {
				return '/';
			}
			
			// Take as many segments from the (not decoded) request, so the path's encoding stays the same.
			$segments = array_slice( explode( '/', $request ), 0, count( explode( '/', $prefix ) ) );
			
			return '/' . implode( '/', $segments ) . '/';
		}
		
		return null;
	}
	
	/**
	 * Signs a path, so the Smart Optimize API only stores results for paths generated by this site.
	 *
	 * @since v5.3.1
	 *
	 * @param string $path
	 *
	 * @return string
	 */
	public static function sign_smart_optimize_path( $path ) {
		return wp_hash( 'omgf_pro_smart_optimize_path|' . $path );
	}
	
	/**
	 * Check if the is_mobile column exists in the Smart Optimize table.
	 *
	 * @param string $table_name
	 *
	 * @return bool
	 */
	private static function is_mobile_column_exists( $table_name ) {
		global $wpdb;
		
		if ( self::$is_mobile_column_exists === null ) {
			self::$is_mobile_column_exists = ! empty(
			$wpdb->get_var( "SHOW COLUMNS FROM $table_name LIKE 'is_mobile'" )
			);
		}
		
		return self::$is_mobile_column_exists;
	}
}
