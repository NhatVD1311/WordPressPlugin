<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize;

class Cache {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Actions & Filters.
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'update_option_omgf_settings', [ $this, 'maybe_flush_smart_optimize_cache' ], 10, 2 );
		add_filter( 'omgf_clean_up_instructions', [ $this, 'set_clean_up' ] );
		add_action( 'omgf_after_clean_up', [ $this, 'clean_up_smart_optimize_entries' ] );
		/**
		 * @since v5.3.0 Analyze pages again when the trusted font hosts change, so their preloads are updated.
		 */
		add_action( 'omgf_pro_smart_optimize_host_approved', [ $this, 'clean_up_smart_optimize_results' ] );
		add_action( 'omgf_pro_smart_optimize_host_revoked', [ $this, 'clean_up_smart_optimize_results' ] );
	}
	
	/**
	 * Flush Smart Optimize cache when Magic Fallbacks setting changes.
	 *
	 * @since v5.3.2 The lists of processed local and external stylesheets are emptied too, because processed
	 *               stylesheets are skipped (or their cached copy is reused), so their font-family declarations would
	 *               never (or always) get Magic Fallbacks' fallbacks.
	 * @see   \OMGF\Pro\Frontend\Optimize::should_optimize_stylesheet()
	 *
	 * @param $old_settings
	 * @param $new_settings
	 *
	 * @return void
	 */
	public function maybe_flush_smart_optimize_cache( $old_settings, $new_settings ) {
		$old_magic_fallbacks = $old_settings[ Settings::OMGF_OPTIMIZE_SETTING_MAGIC_FALLBACKS ] ?? '';
		$new_magic_fallbacks = $new_settings[ Settings::OMGF_OPTIMIZE_SETTING_MAGIC_FALLBACKS ] ?? '';
		
		// Nothing to do if the setting hasn't changed.
		if ( $old_magic_fallbacks === $new_magic_fallbacks ) {
			return;
		}
		
		$this->delete_cached_smart_optimize_stylesheets();
		$this->clean_up_smart_optimize_entries();
		
		Wrapper::delete_option( Settings::OMGF_PRO_PROCESSED_STYLESHEETS );
		Wrapper::delete_option( Settings::OMGF_PRO_PROCESSED_EXT_STYLESHEETS );
	}
	
	/**
	 * Remove all directories in the /smart-optimize directory.
	 *
	 * @return void
	 */
	private function delete_cached_smart_optimize_stylesheets() {
		$smart_optimize_dir = OMGF_UPLOAD_DIR . '/smart-optimize';
		
		if ( file_exists( $smart_optimize_dir ) ) {
			Wrapper::delete( $smart_optimize_dir );
		}
	}
	
	/**
	 * Empty Smart Optimize table and the trusted hosts when the cache is emptied.
	 *
	 * @return void
	 */
	public function clean_up_smart_optimize_entries() {
		$this->clean_up_smart_optimize_results();
		
		/**
		 * @since v5.3.0 The trusted hosts are collected again as pages are processed.
		 * @see   \OMGF\Pro\Frontend\SmartOptimize\TrustedHosts::record()
		 */
		delete_option( Settings::OMGF_PRO_SMART_OPTIMIZE_TRUSTED_HOSTS );
	}
	
	/**
	 * Empty Smart Optimize table, so pages are analyzed again.
	 *
	 * @since v5.3.0 The trusted hosts collected from pages are kept, because pages served from a (page) cache won't
	 *                report them again until they're processed again.
	 *
	 * @return void
	 */
	public function clean_up_smart_optimize_results() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . SmartOptimize::ID;
		$exists     = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );
		
		if ( $exists !== $table_name ) {
			return; // @codeCoverageIgnore
		}
		
		$wpdb->query( "TRUNCATE TABLE `{$table_name}`" );
	}
	
	/**
	 * Add Pro DB caches to clean up instructions before emptying the cache directory.
	 *
	 * @since v2.5.0
	 *
	 * @param mixed $instructions
	 *
	 * @return array containing a 'init', 'exclude' and 'queue'.
	 */
	public function set_clean_up( $instructions ) {
		array_push(
			$instructions['queue'],
			Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK,
			Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT,
			Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES,
			Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS,
			Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS,
			Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS,
			Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER,
			Settings::OMGF_PRO_PROCESSED_STYLESHEETS,
			Settings::OMGF_PRO_PROCESSED_EXT_STYLESHEETS,
			Settings::OMGF_PRO_PROCESSED_ASYNC_STYLESHEETS,
		);
		
		return $instructions;
	}
}
