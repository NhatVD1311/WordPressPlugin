<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *         https://daan.dev
 * @copyright © 2020 - 2025 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager\Admin;

use Daan\LicenseManager\Admin as Admin;
use Daan\LicenseManager\Plugin as LicenseManager;

class Licensing {
	/**
	 * This transient simply holds a boolean value to determine whether we should refresh the license status.
	 */
	const OPTION_LAST_CHECKED = 'daan_license_manager_last_checked';

	/**
	 * How often the license statuses are refreshed: twice a week.
	 */
	const CHECK_INTERVAL = 84 * HOUR_IN_SECONDS;

	/**
	 * When the license server couldn't be reached for one of the licenses, try again after this period instead.
	 */
	const RETRY_INTERVAL = 24 * HOUR_IN_SECONDS;

	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Action & Filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		// This class should only run in admin.
		add_action( 'admin_init', [ $this, 'maybe_update_valid_licenses' ] );
	}

	/**
	 * Activate the license key. Don't use this function in wp_ajax as it might lead to blocked IP issues on shared IPs.
	 *
	 * @param string $key     A valid license key provided by EDD.
	 * @param string $item_id The unique ID provided by EDD.
	 *
	 * @return object
	 */
	public static function activate_license( $key, $item_id ) {
		if ( ! $key ) {
			return (object) [];
		}

		$params = [
			'edd_action' => 'activate_license',
			'license'    => $key,
			'item_id'    => $item_id,
			'url'        => home_url(),
		];

		$response = wp_remote_post(
			apply_filters( 'ffwp_license_manager_api_url', 'https://daan.dev' ),
			[
				'timeout'   => 15,
				'sslverify' => true,
				'body'      => $params,
			]
		);

		$message = '';

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			$message = ( is_wp_error( $response ) && ! empty( $response->get_error_message() ) ) ? $response->get_error_message() : sprintf(
				__( 'An error occurred, contact support and include the following message: %1$s - %2$s', 'daan-license-manager' ),
				wp_remote_retrieve_response_code( $response ),
				wp_remote_retrieve_body( $response )
			);

			if ( defined( 'WP_CLI' ) && WP_CLI ) {
				\WP_CLI::error( $message );
			}

			Notice::set_notice( $message, 'error' );

			return (object) [];
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( $license_data !== null && $license_data->success === false ) {
			if ( $license_data->error === 'expired' ) {
				$message = Functions::generate_message( $license_data->error, $license_data->item_name, $license_data->expires, $item_id, $key );
			} else {
				$message = Functions::generate_message( $license_data->error, $license_data->item_name );
			}
		}

		if ( ! empty( $message ) ) {
			if ( defined( 'WP_CLI' ) && WP_CLI ) {
				\WP_CLI::error( $message );
			}

			Notice::set_notice( $message, 'error' );
		}

		return $license_data;
	}

	/**
	 * Loops through all entered (and validated) licenses and updates their status if they're either expired or will almost expire.
	 *
	 * Uses an option to keep track of the last time this process ran.
	 *
	 * @return void
	 */
	public function maybe_update_valid_licenses() {
		$last_checked = get_option( self::OPTION_LAST_CHECKED, 0 );

		// Current time() minus $last_checked tells us how long ago the last check was.
		if ( time() - $last_checked <= self::CHECK_INTERVAL ) {
			return;
		}

		$valid_licenses = LicenseManager::valid_licenses();
		$failed         = false;

		foreach ( $valid_licenses as $id => &$license_data ) {
			$key           = $license_data[ 'license' ];
			$decrypted_key = LicenseManager::decrypt( $key, $id );

			if ( ! $decrypted_key ) {
				continue;
			}

			$new_data = $this->retrieve_license_status( $id, $decrypted_key );

			// Couldn't check this license: keep its stored status and try again sooner.
			if ( ! $new_data ) {
				$failed = true;

				continue;
			}

			if ( ! empty( $new_data->license ) && $new_data->license !== $license_data[ 'license_status' ] ) {
				$license_data[ 'license_status' ] = $new_data->license;
			}

			if ( ! empty( $new_data->expires ) && $new_data->expires !== $license_data[ 'expires' ] ) {
				$license_data[ 'expires' ] = $new_data->expires;
			}

			if ( ! empty( $new_data->subscription_status ) && ( empty( $license_data[ 'subscription_status' ] ) || $new_data->subscription_status !== $license_data[ 'subscription_status' ] ) ) {
				$license_data[ 'subscription_status' ] = $new_data->subscription_status;
			}
		}

		/**
		 * After a failed check, pretend the last check was longer ago, so the next one runs after RETRY_INTERVAL
		 * instead of CHECK_INTERVAL.
		 */
		update_option( self::OPTION_LAST_CHECKED, $failed ? time() - ( self::CHECK_INTERVAL - self::RETRY_INTERVAL ) : time() );

		update_option( Admin::OPTION_VALID_LICENSES, $valid_licenses );
	}

	/**
	 * Checks a single license.
	 *
	 * @param int|string $id  An EDD product ID.
	 * @param string     $key A valid license key.
	 *
	 * @return object|null The license data, or null if the license server couldn't be reached or didn't return any.
	 */
	private function retrieve_license_status( $id, $key ) {
		$params   = [
			'edd_action' => 'check_license',
			'license'    => $key,
			'item_id'    => $id,
			'url'        => home_url(),
		];
		$url      = apply_filters( 'ffwp_license_manager_api_url', 'https://daan.dev' );
		$response = wp_remote_post(
			$url,
			[
				'timeout'   => 15,
				'sslverify' => true,
				'body'      => $params,
			]
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			LicenseManager::debug( "License check for $id failed: " . ( is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_response_code( $response ) ) . '.' );

			return null;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// E.g. an HTML page instead of the API's JSON.
		if ( ! is_object( $license_data ) || empty( $license_data->license ) ) {
			LicenseManager::debug( "License check for $id failed: unexpected response." );

			return null;
		}

		return $license_data;
	}
}
