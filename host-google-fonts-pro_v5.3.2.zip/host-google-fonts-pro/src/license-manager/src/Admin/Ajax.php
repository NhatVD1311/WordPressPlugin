<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2020 - 2026 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager\Admin;

use Daan\LicenseManager\Admin;
use Daan\LicenseManager\Plugin as LicenseManager;

class Ajax {
	/**
	 * Actions & Hooks
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_ajax_ffwp_license_manager_activate', [ $this, 'activate_license' ] );
		add_action( 'wp_ajax_ffwp_license_manager_deactivate', [ $this, 'deactivate_license' ] );
		add_action( 'wp_ajax_ffwp_license_manager_check', [ $this, 'check_license' ] );
		add_action( 'wp_ajax_ffwp_license_manager_decrypt', [ $this, 'decrypt_license_key' ] );
	}
	
	/**
	 * Saves a license as activated in the database. This function does NOT "call home" to activate the license. This is done using JS in the browser
	 * to avoid blocked IP issues as described in [DLM-19].
	 *
	 * @return void
	 */
	public function activate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'You are not allowed to manage licenses.', 'daan-license-manager' ), 403 );
		}

		check_ajax_referer( Admin::SETTINGS_NONCE, Admin::SETTINGS_NONCE );
		
		if ( ! isset( $_POST['item_id'] ) || ! isset( $_POST['license'] ) || ! isset( $_POST['license_data'] ) || ! is_array( $_POST['license_data'] ) || ! isset( $_POST['plugin_file'] ) ) {
			Notice::set_notice( __( 'Malformed request. License activation failed.', 'daan-license-manager' ) );
			
			return;
		}
		
		$license_data = $_POST['license_data'];
		$id           = absint( sanitize_text_field( $_POST['item_id'] ) );
		$license_key  = sanitize_text_field( $_POST['license'] );
		
		if ( ! empty( $license_data['error'] ) ) {
			$error     = sanitize_text_field( $license_data['error'] );
			$item_name = sanitize_text_field( $license_data['item_name'] ?? '' );

			if ( $error === 'expired' ) {
				// License expired error.
				$message = Functions::generate_message( $error, $item_name, sanitize_text_field( $license_data['expires'] ?? '' ), $id, $license_key );
			} else {
				// Other errors.
				$message = Functions::generate_message( $error, $item_name );
			}
			
			Notice::set_notice( $message );
			
			return;
		}
		
		/**
		 * If no license data was returned or license activation failed, skip out early.
		 */
		$success = $license_data['success'] ?? null;
		
		if ( ! $success || $success === "false" ) {
			Notice::set_notice( __( 'License activation failed. Please check if the key you entered is correct.', 'daan-license-manager' ) );
			
			return;
		}
		
		/**
		 * Filter all $_POST data before storing it to the database.
		 *
		 * @since v2.0.0
		 */
		$license_status = isset( $license_data['license'] ) ? sanitize_text_field( $license_data['license'] ) : '';
		$license_status = $license_status ?: '';
		$license_expiry = isset( $license_data['expires'] ) ? sanitize_text_field( $license_data['expires'] ) : '';
		$license_expiry = strtotime( $license_expiry ) !== false || $license_expiry === 'lifetime' ? $license_expiry : '';
		$plugin_file    = sanitize_text_field( $_POST['plugin_file'] );
		$plugin_file    = file_exists( $plugin_file ) ? $plugin_file : '';
		
		if ( ! $id || ! $license_key || ! $license_status || ! $license_expiry || ! $plugin_file ) {
			Notice::set_notice( __( 'Malformed request. License activation failed.', 'daan-license-manager' ) );
			
			return;
		}
		
		/**
		 * Contains all required data for automatic updates.
		 *
		 * @var array $valid_license
		 */
		$valid_license[ $id ] = Functions::generate_valid_license_data(
			$license_status,
			$license_key, // License Key
			$license_expiry, // Expires,
			$plugin_file // Full Path to plugin
		);
		
		$valid_licenses        = get_option( Admin::OPTION_VALID_LICENSES );
		$valid_licenses[ $id ] = $valid_license[ $id ];
		
		update_option( Admin::OPTION_VALID_LICENSES, $valid_licenses );
		
		Notice::set_notice( __( 'License activated successfully.', 'daan-license-manager' ) );
		
		// Reset Admin Notice transient.
		delete_transient( Admin::NOTICE_COUNT );
	}
	
	/**
	 * Validates a license and overwrites the current data in the DB. This function does not call home, as JS does that as described in DLM-19.
	 *
	 * @return void
	 */
	public function check_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'You are not allowed to manage licenses.', 'daan-license-manager' ), 403 );
		}

		if ( ! isset( $_POST['item_id'] ) ) {
			wp_send_json_error( __( 'Plugin ID not set.', 'daan-license-manager' ) );
		}
		
		check_ajax_referer( Admin::SETTINGS_NONCE, Admin::SETTINGS_NONCE );
		
		$item_id = sanitize_text_field( $_POST['item_id'] );
		
		if ( ! isset( $_POST['license_data'] ) || ! isset( $_POST['license_data']['item_name'] ) || ! isset( $_POST['license_data']['license'] ) ) {
			wp_send_json_error( __( 'No proper response received from licensing API.', 'daan-license-manager' ) );
		}
		
		$license_data = $_POST['license_data'];
		
		if ( empty( $license_data ) ) {
			Notice::set_notice( __( 'No proper response received from licensing API.', 'daan-license-manager' ) );
			
			wp_send_json_error();
		}
		
		$item_name      = sanitize_text_field( $license_data['item_name'] );
		$valid_licenses = LicenseManager::valid_licenses();
		
		if ( ! isset( $valid_licenses[ $item_id ] ) ) {
			$message = sprintf( __( 'No license exists for %s.', 'daan-license-manager' ), $item_name );
			
			Notice::set_notice( $message, 'error' );
			
			wp_send_json_error();
		}
		
		$license_status = sanitize_text_field( $license_data['license'] ?? '' );
		
		if ( $license_status !== "valid" ) {
			if ( $license_status === 'expired' ) {
				// License is expired.
				$message = Functions::generate_message(
					'expired',
					$item_name,
					$valid_licenses[ $item_id ]['expires'],
					$item_id,
					LicenseManager::decrypt( $valid_licenses[ $item_id ]['license'], $item_id )
				);
			} else {
				// Other errors.
				$message = Functions::generate_message(
					$license_status,
					$item_name
				);
			}
			
			Notice::set_notice( $message );
			
			wp_send_json_error();
		}
		
		/**
		 * If the 'success' element turns out false, something odd is going on. If the 'license' element is still invalid. User didn't renew the license and has nothing to do here.
		 */
		if ( ! $license_data || empty( $license_data['success'] ) || empty( $license_status ) || $license_status === 'invalid' ) {
			return;
		}
		
		$license_expires = $license_data['expires'] ?? '';
		$license_expires = strtotime( $license_expires ) !== false || $license_expires === 'lifetime' ? $license_expires : '';
		
		if ( ! $license_expires ) {
			Notice::set_notice( __( 'Invalid request. License check failed.', 'daan-license-manager' ) );
			
			wp_send_json_error();
		}
		
		$sub_status          = sanitize_text_field( $license_data['subscription_status'] ?? '' );
		$updated_information = [
			'license_status'      => $license_status,
			'expires'             => $license_expires,
			'subscription_status' => $sub_status,
		];
		
		$valid_licenses[ $item_id ] = array_replace( $valid_licenses[ $item_id ], $updated_information );
		
		update_option( Admin::OPTION_VALID_LICENSES, $valid_licenses );
		
		Notice::set_notice( __( 'License data successfully refreshed.', 'daan-license-manager' ) );
		
		delete_transient( Admin::NOTICE_COUNT );
	}
	
	/**
	 * Deletes an activated license from the DB. This function does not call home, as that is done by JS as described in DLM-19.
	 */
	public function deactivate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'You are not allowed to manage licenses.', 'daan-license-manager' ), 403 );
		}

		if ( ! isset( $_POST['item_id'] ) ) {
			wp_send_json_error( __( 'Plugin ID not set.', 'daan-license-manager' ) );
		}
		
		check_ajax_referer( Admin::SETTINGS_NONCE, Admin::SETTINGS_NONCE );
		
		/**
		 * First remove the entry from the DB.
		 */
		$item_id        = sanitize_text_field( $_POST['item_id'] );
		$valid_licenses = LicenseManager::valid_licenses();
		
		unset( $valid_licenses[ $item_id ] );
		
		update_option( Admin::OPTION_VALID_LICENSES, $valid_licenses );
		
		Notice::set_notice( __( 'License deactivated successfully.', 'daan-license-manager' ) );
		
		delete_transient( Admin::NOTICE_COUNT );
		
		wp_send_json_success();
	}
	
	/**
	 * @return void
	 */
	public function decrypt_license_key() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'You are not allowed to manage licenses.', 'daan-license-manager' ), 403 );
		}

		if ( ! isset( $_POST['item_id'] ) || ! isset( $_POST['license_key'] ) ) {
			wp_send_json_error( __( 'Required parameters missing.', 'daan-license-manager' ) );
		}
		
		check_ajax_referer( Admin::SETTINGS_NONCE );
		
		$item_id       = sanitize_text_field( $_POST['item_id'] );
		$license_key   = sanitize_text_field( $_POST['license_key'] );
		$decrypted_key = LicenseManager::decrypt( $license_key, $item_id );
		
		if ( ! $decrypted_key ) {
			Notice::set_notice( __( 'License key decryption failed.', 'daan-license-manager' ), 'error' );
			
			wp_send_json_error();
		}
		
		wp_send_json_success( [ 'key' => $decrypted_key ] );
	}
}
