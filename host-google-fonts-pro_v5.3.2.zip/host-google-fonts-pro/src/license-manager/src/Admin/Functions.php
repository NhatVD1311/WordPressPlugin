<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2020 - 2026 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager\Admin;

use Daan\LicenseManager\Plugin as LicenseManager;

class Functions {
	/**
	 * Generate error message.
	 *
	 * @param mixed      $error_code
	 * @param mixed      $plugin_name
	 * @param mixed|null $expires
	 * @param string     $item_id
	 * @param string     $key
	 *
	 * @return string
	 */
	public static function generate_message( $error_code, $plugin_name, $expires = null, $item_id = '', $key = '' ) {
		switch ( $error_code ) {
			case 'expired':
				$message = sprintf(
					__( 'Your license key expired %1$s.', 'daan-license-manager' ),
					date_i18n( get_option( 'date_format' ), strtotime( $expires, current_time( 'timestamp' ) ) ),
				);
				
				if ( $item_id && $key ) {
					$url     = sprintf( LicenseManager::DAAN_DEV_URL_RENEW_LICENSE, $item_id, $key );
					$message .= ' ';
					$message .= sprintf(
						__( '<a href="%1$s" target="_blank">Click here to renew</a>.', 'daan-license-manager' ),
						esc_url( $url )
					);
				}
				
				break;
			case 'revoked':
				$message = __( 'Your license key has been disabled.', 'daan-license-manager' );
				break;
			case 'missing':
				$message = sprintf(
					__(
						'License key doesn\'t exist. Purchase a license key on <a href="%s" target="_blank">Daan.dev</a>.',
						'daan-license-manager'
					),
					LicenseManager::DAAN_DEV_URL_WORDPRESS_PLUGINS
				);
				break;
			case 'site_inactive':
				$message = __( 'Your license is not active for this URL.', 'daan-license-manager' );
				break;
			case 'invalid':
			case 'item_name_mismatch':
				$message = sprintf( __( 'This appears to be an invalid license key for %s.', 'daan-license-manager' ), $plugin_name );
				break;
			case 'no_activations_left':
				$message = sprintf(
					__(
						'You\'ve reached your limit for your license. Visit <a href="%s" target="_blank">your Account area</a> to upgrade your license or click on Manage Sites next to the corresponding license and free up a site activation slot for this license key.',
						'daan-license-manager'
					),
					LicenseManager::DAAN_DEV_URL_LICENSE_KEYS
				);
				break;
			case 'invalid_item_id':
				$message = sprintf(
					__( 'The license you entered doesn\'t seem to be for %s. Check <a href="%s">your license keys</a> to make sure you\'re using the correct one.', 'daan-license-manager' ),
					$plugin_name,
					LicenseManager::DAAN_DEV_URL_LICENSE_KEYS
				);
				break;
			default:
				$message = sprintf(
					__( 'An unexpected error occurred. Please <a href="%s">contact me</a>.', 'daan-license-manager' ),
					LicenseManager::DAAN_DEV_URL_CONTACT
				);
				break;
		}
		
		return $message;
	}
	
	/**
	 * Generate a data array for storage of a validated license.
	 *
	 * @param string $status      'valid' | 'invalid'
	 * @param string $key         Entered key
	 * @param string $expires     Not present when request failed. Is either data formatted as string or 'lifetime'.
	 * @param string $plugin_file Added by plugin.
	 *
	 * @return string[]
	 */
	public static function generate_valid_license_data( $status = '', $key = '', $expires = '', $plugin_file = '' ) {
		return [
			'license_status' => $status,
			'license'        => LicenseManager::encrypt( $key ),
			'expires'        => $expires,
			'plugin_file'    => $plugin_file,
		];
	}
}
