<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2020 - 2026 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager\DB\Migration;

use Daan\LicenseManager\Admin;
use Daan\LicenseManager\Plugin as LicenseManager;


class V221 {
	
	private $version = '2.2.1';
	
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Deletes the legacy ffwp_license_key option from the db.
	 *
	 * Since there's no way to know whether it existed or not before deletion or if the deletion failed, we'll update the DB version regardless.
	 */
	public function init() {
		delete_option( 'ffwp_license_key' );
		
		update_option( Admin::OPTION_DB_VERSION, $this->version );
	}
}
