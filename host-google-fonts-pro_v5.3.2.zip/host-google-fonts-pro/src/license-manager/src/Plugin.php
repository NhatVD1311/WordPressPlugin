<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2020 - 2026 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager;

use Daan\LicenseManager\Setup\EncryptionKey;

class Plugin {
	const DAAN_DEV_URL_WORDPRESS_PLUGINS = 'https://daan.dev/wordpress-plugins';
	
	const DAAN_DEV_URL_LICENSE_KEYS = 'https://daan.dev/account/license-keys/';
	
	const DAAN_DEV_URL_RENEW_LICENSE = 'https://daan.dev/checkout/?nocache=true&download_id=%s&edd_license_key=%s';
	
	const DAAN_DEV_URL_CONTACT = 'https://daan.dev/contact';
	
	const DAAN_LM_ENC_KEY_LABEL = 'DAAN_LICENSE_ENC_KEY';
	
	const DAAN_DEV_ENCRYPTION_METHOD = 'AES-128-CTR';
	
	/**
	 * Reason for skipping the updater when a (valid) license key couldn't be decrypted.
	 */
	const UPDATER_SKIPPED_UNDECRYPTABLE = 'undecryptable';
	
	/**
	 * @var array $skipped_updaters [ plugin basename => reason ]
	 */
	private static $skipped_updaters = [];
	
	/**
	 * Plugin constructor.
	 */
	public function __construct() {
		$this->generate_cipher();
		
		if ( did_action( 'init' ) ) {
			$this->load_textdomain();
		} else {
			add_action( 'init', [ $this, 'load_textdomain' ] );
		}
		
		add_action( 'cli_init', [ $this, 'register_cli_commands' ] );
		add_filter( 'edd_sl_api_request_verify_ssl', '__return_true' );
		add_filter( 'daan_active_premium_plugins', [ $this, 'do_backward_compatibility' ], 5 );
		add_action( 'wp_loaded', [ $this, 'do_updater' ] );
		
		if ( ! is_admin() ) {
			return;
		}
		
		$this->init();
	}
	
	/**
	 * Loads the bundled translations from the languages folder.
	 *
	 * This is a submodule, not a standalone plugin, so load_plugin_textdomain() can't be used.
	 */
	public function load_textdomain() {
		load_textdomain(
			'daan-license-manager',
			DAAN_LICENSE_MANAGER_PLUGIN_DIR . 'languages/daan-license-manager-' . determine_locale() . '.mo'
		);
	}
	
	/**
	 * Generates a cipher used for encryption and stores it into the database.
	 */
	private function generate_cipher() {
		/**
		 * @since v1.10.3 No need to go through all that when the cipher is
		 *                already defined.
		 */
		if ( defined( 'CIPHER' ) ) {
			return;
		}
		
		$cipher = get_option( Admin::OPTION_CIPHER );
		
		if ( ! $cipher ) {
			$cipher = bin2hex( random_bytes( 8 ) );
			
			update_option( Admin::OPTION_CIPHER, $cipher );
		}
		
		define( 'CIPHER', $cipher );
	}
	
	/**
	 * Initiate Daan.dev License Manager
	 */
	private function init() {
		$db = get_option( Admin::OPTION_DB_VERSION );
		
		if ( version_compare( $db, DAAN_LICENSE_MANAGER_DB_VERSION ) < 0 ) {
			new DB\Migration();
		}
		
		new Admin();
		new Admin\Ajax();
		new Admin\Licensing();
		
		add_action( 'current_screen', [ new EncryptionKey(), 'install' ] );
		add_action( 'current_screen', [ new EncryptionKey(), 'check_health' ] );
	}
	
	/**
	 * Encrypt key for storage.
	 *
	 * @param mixed $key
	 *
	 * @return string
	 */
	public static function encrypt( $key ) {
		if ( ! defined( self::DAAN_LM_ENC_KEY_LABEL ) ) {
			return '';
		}
		
		return openssl_encrypt( $key, self::DAAN_DEV_ENCRYPTION_METHOD, DAAN_LICENSE_ENC_KEY, 0, CIPHER );
	}
	
	/**
	 * Checks if the license associated with $plugin_id has an active subscription. Return false if subscription_status isn't set.
	 *
	 * @since v2.2.0
	 *
	 * @param $plugin_id
	 *
	 * @return bool
	 */
	public static function license_has_active_subscription( $plugin_id ) {
		$valid_licenses      = self::valid_licenses();
		$active_subscription = $valid_licenses[ $plugin_id ]['subscription_status'] ?? '';
		
		return $active_subscription === 'active';
	}
	
	/**
	 * Fetches all previously validated licenses from the database.
	 *
	 * @return array
	 */
	public static function valid_licenses() {
		static $valid_licenses = [];
		
		if ( empty( $valid_licenses ) ) {
			$valid_licenses = get_option( Admin::OPTION_VALID_LICENSES, [] );
		}
		
		if ( empty( $valid_licenses ) || ! is_array( $valid_licenses ) ) {
			return [];
		}
		
		return $valid_licenses;
	}
	
	/**
	 * Check if $expiry_date of the license has passed.
	 *
	 * @param int $plugin_id
	 *
	 * @return bool
	 */
	public static function license_is_expired( $plugin_id ) {
		$valid_licenses = self::valid_licenses();
		
		if ( ! isset( $valid_licenses[ $plugin_id ] ) ) {
			return false;
		}
		
		$expiry_date = self::get_expiry_date( $plugin_id );
		
		if ( $expiry_date === 'lifetime' ) {
			return false;
		}
		
		$license_status = $valid_licenses[ $plugin_id ]['license_status'] ?? '';
		
		return ( $license_status === 'valid' && is_int( $expiry_date ) && $expiry_date < time() ) || $license_status === 'expired';
	}
	
	/**
	 * Gets the expiry date for $plugin_id from @see self::valid_licenses()
	 *
	 * @param int $plugin_id
	 *
	 * @return string|int|false
	 */
	private static function get_expiry_date( $plugin_id ) {
		$valid_licenses = self::valid_licenses();
		$expires        = $valid_licenses[ $plugin_id ]['expires'] ?? '';
		
		if ( empty( $expires ) || $expires === 'lifetime' ) {
			$expiry_date = 'lifetime';
		} else {
			$expiry_date = strtotime( $expires );
		}
		
		if ( $expiry_date === 'lifetime' || $expiry_date === false ) {
			$expiry_date = 'lifetime';
		}
		
		return $expiry_date;
	}
	
	/**
	 * Check if $expiry_date of the license will expire within 7 days.
	 *
	 * @param int $plugin_id
	 *
	 * @return bool
	 */
	public static function license_will_expire_soon( $plugin_id ) {
		$valid_licenses = self::valid_licenses();
		$expiry_date    = self::get_expiry_date( $plugin_id );
		
		if ( $expiry_date === 'lifetime' ) {
			return false;
		}
		
		return ( isset( $valid_licenses[ $plugin_id ] ) && is_int( $expiry_date ) && $expiry_date > time() && $expiry_date < strtotime( '+7 days' ) );
	}
	
	/**
	 * Check if a license is entered.
	 *
	 * @param int $plugin_id
	 *
	 * @return bool
	 */
	public static function no_license_entered( $plugin_id ) {
		$valid_licenses = self::valid_licenses();
		
		return ! isset( $valid_licenses[ $plugin_id ] );
	}
	
	/**
	 * Checks if anyone is still using the old filter and adds a deprecation notice to the debug log.
	 *
	 * @since v2.2.0
	 *
	 * @param $plugins
	 *
	 * @return mixed|null
	 */
	public function do_backward_compatibility( $plugins ) {
		// Check if anyone is still using the old filter
		if ( has_filter( 'ffwp_license_manager_licenses' ) ) {
			// Apply the deprecated filter with a deprecation notice
			$plugins = apply_filters_deprecated(
				'ffwp_license_manager_licenses',
				[ $plugins ],
				'2.2.0',
				'daan_active_premium_plugins',
				'The filter hook has been renamed. Please update all your Daan.dev premium plugins to use the new filter hook.'
			);
		}
		
		return $plugins;
	}
	
	/**
	 * Check for updates for all installed plugins, incl. this (free) plugin.
	 */
	public function do_updater() {
		foreach ( self::valid_licenses() as $id => $license_data ) {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			
			$plugin_file = $license_data['plugin_file'] ?? '';
			
			if ( ! is_string( $plugin_file ) || $plugin_file === '' ) {
				continue;
			}
			
			$plugin_basename = plugin_basename( $plugin_file );
			
			/**
			 * @see is_plugin_active() returns the DB entry. If a plugin was deleted by SSH/FTP or anything, that will still return true.
			 * That's why we explicitly check if the file exists.
			 */
			if ( ! is_plugin_active( $plugin_basename ) || ! file_exists( $plugin_file ) ) {
				continue;
			}
			
			$license_status = $license_data['license_status'] ?? '';
			
			if ( $license_status !== 'valid' ) {
				$this->skip_updater( $plugin_basename, $license_status, $id );
				
				continue;
			}
			
			$plugin_data = get_plugin_data( $plugin_file, false, false );
			
			if ( ! isset( $plugin_data['Version'] ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$license_key = self::decrypt( $license_data['license'], $id );
			
			/**
			 * No need to continue if $license_key doesn't exist.
			 */
			if ( ! $license_key ) {
				$this->skip_updater( $plugin_basename, self::UPDATER_SKIPPED_UNDECRYPTABLE, $id );
				
				continue;
			}
			
			$plugin_version = $plugin_data['Version'];
			
			new Updater(
				apply_filters( 'ffwp_license_manager_api_url', 'https://daan.dev' ), $plugin_file, [
					'license'     => $license_key,
					'item_id'     => $id,
					'version'     => $plugin_version,
					'author'      => 'Daan van den Bergh',
					'url'         => home_url(),
					'beta'        => false,
					'wp_override' => true,
				]
			);
		}
	}
	
	/**
	 * Without an updater, WordPress shows "Automatic update is unavailable for this plugin" (if it knows about a new
	 * version) and "Plugin not found" on the details screen, without saying why. So we tell why on the Plugins screen.
	 *
	 * @since v2.2.6
	 *
	 * The row isn't shown for expired licenses, because Admin::add_license_notices() already shows one for those.
	 *
	 * @param string $plugin_basename
	 * @param string $reason          The license status, or self::UPDATER_SKIPPED_UNDECRYPTABLE.
	 * @param int    $plugin_id
	 *
	 * @return void
	 */
	private function skip_updater( $plugin_basename, $reason, $plugin_id ) {
		self::debug( "Automatic updates are disabled for $plugin_basename: " . ( $reason ?: 'unknown license status' ) . '.' );
		
		if ( self::license_is_expired( $plugin_id ) ) {
			return;
		}
		
		self::$skipped_updaters[ $plugin_basename ] = (string) $reason;
		
		add_action( "after_plugin_row_$plugin_basename", [ $this, 'render_updates_disabled_row' ], 10, 1 );
	}
	
	/**
	 * Renders a row below the plugin on the Plugins screen, explaining why automatic updates are disabled.
	 *
	 * @since v2.2.6
	 *
	 * @param string $plugin_basename
	 *
	 * @return void
	 */
	public function render_updates_disabled_row( $plugin_basename ) {
		if ( ! current_user_can( 'update_plugins' ) || ! isset( self::$skipped_updaters[ $plugin_basename ] ) ) {
			return;
		}
		
		$message = self::get_updates_disabled_message( self::$skipped_updaters[ $plugin_basename ] );
		$columns = isset( $GLOBALS['wp_list_table'] ) && method_exists( $GLOBALS['wp_list_table'], 'get_column_count' ) ? $GLOBALS['wp_list_table']->get_column_count() : 4;
		
		printf(
			'<tr class="plugin-update-tr active daan-updates-disabled"><td colspan="%d" class="plugin-update colspanchange"><div class="update-message notice inline notice-warning notice-alt"><p>%s</p></div></td></tr>',
			(int) $columns,
			wp_kses( $message, [ 'a' => [ 'href' => [] ] ] )
		);
	}
	
	/**
	 * @since v2.2.6
	 *
	 * @param string $reason The license status, or self::UPDATER_SKIPPED_UNDECRYPTABLE.
	 *
	 * @return string HTML.
	 */
	public static function get_updates_disabled_message( $reason ) {
		$manage_licenses = esc_url( admin_url( 'options-general.php?page=ffwp-license-manager' ) );
		
		switch ( $reason ) {
			case self::UPDATER_SKIPPED_UNDECRYPTABLE:
				/* translators: %s: URL of the Manage Licenses screen */
				$message = __( 'Automatic updates are disabled, because the license key can\'t be read, e.g. after migrating your site. <a href="%s">Re-enter your license key</a> to enable automatic updates.', 'daan-license-manager' );
				break;
			case 'expired':
				/* translators: %s: URL of the Manage Licenses screen */
				$message = __( 'Automatic updates are disabled, because the license has expired. <a href="%s">Renew your license</a> to enable automatic updates.', 'daan-license-manager' );
				break;
			case 'site_inactive':
			case 'inactive':
				/* translators: %s: URL of the Manage Licenses screen */
				$message = __( 'Automatic updates are disabled, because the license isn\'t (or is no longer) activated for this site. <a href="%s">Activate your license</a> to enable automatic updates.', 'daan-license-manager' );
				break;
			default:
				/* translators: %s: URL of the Manage Licenses screen */
				$message = __( 'Automatic updates are disabled, because the license isn\'t valid. <a href="%s">Check your license</a> to enable automatic updates.', 'daan-license-manager' );
		}
		
		return sprintf( $message, $manage_licenses );
	}
	
	/**
	 * Decrypt $key (and validate) before returning the result.
	 *
	 * @param string $key Encrypted string.
	 * @param int    $id  Download ID.
	 *
	 * @return string
	 */
	public static function decrypt( $key, $id ) {
		/**
		 * @since v1.10.3 Store decrypted keys in a static array to prevent duplicate decrypts.
		 * @since v2.2.5  Failed decrypts are stored as an empty string, so they aren't attempted (and logged) again.
		 */
		static $decrypted_keys = [];
		
		if ( isset( $decrypted_keys[ $id ] ) ) {
			return $decrypted_keys[ $id ];
		}
		
		if ( ! defined( self::DAAN_LM_ENC_KEY_LABEL ) ) {
			return '';
		}
		
		$decrypted_key = openssl_decrypt( $key, self::DAAN_DEV_ENCRYPTION_METHOD, DAAN_LICENSE_ENC_KEY, 0, CIPHER );
		
		/**
		 * Run a quick validation before returning the result and adding it to the static array.
		 *
		 * @since v2.2.5 License keys aren't written to the debug log, because it's usually publicly accessible.
		 */
		if ( is_string( $decrypted_key ) && self::validate( $decrypted_key ) ) {
			$decrypted_keys[ $id ] = $decrypted_key;
			
			self::debug( "Validation succeeded for $id and key ending in: " . substr( trim( $decrypted_key ), -4 ) . '.' );
			
			return $decrypted_keys[ $id ];
		}
		
		$decrypted_keys[ $id ] = '';
		
		self::debug(
			"Validation failed for $id: the stored license key couldn't be decrypted using DAAN_LICENSE_ENC_KEY, e.g. because the site was migrated."
		);
		
		return '';
	}
	
	/**
	 * Global debug logging function.
	 *
	 * @param mixed $message
	 *
	 * @return void
	 */
	public static function debug( $message ) {
		if ( ! defined( 'DEBUG_MODE' ) || DEBUG_MODE === false ) {
			return;
		}
		
		error_log( current_time( 'Y-m-d H:i:s' ) . ": $message\n", 3, trailingslashit( WP_CONTENT_DIR ) . 'daan-debug.log' );
	}
	
	/**
	 * Check if $key contains only letters and numbers and is 32 characters long.
	 */
	public static function validate( $key ) {
		$trim_key = trim( $key );
		
		return preg_match( '/^[A-Za-z0-9]{32}$/', $trim_key ) === 1;
	}
	
	/**
	 * Register CLI commands, which allow license (de-)activation through WP CLI.
	 *
	 * @return void
	 */
	public function register_cli_commands() {
		\WP_CLI::add_command( 'daan', '\Daan\LicenseManager\CLI' );
	}
}
