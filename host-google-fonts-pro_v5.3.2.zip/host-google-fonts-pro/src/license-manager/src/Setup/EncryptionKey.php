<?php
/**
 * @package   Daan.dev License Manager
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2020 - 2026 Daan van den Bergh. All Rights Reserved.
 */

namespace Daan\LicenseManager\Setup;

use Daan\LicenseManager\Admin;
use Daan\LicenseManager\Admin\Notice;
use Daan\LicenseManager\Plugin;

class EncryptionKey {
	/**
	 * @return void
	 */
	public function check_health() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		if ( ! defined( Plugin::DAAN_LM_ENC_KEY_LABEL ) ) {
			Notice::set_notice(
				sprintf(
					__(
						'Your Daan.dev license(s) failed to validate, because required encryption keys are missing. If this message reappears on the next page load, <a href="%s">try fixing it manually</a>.',
						'daan-license-manager'
					),
					'https://daan.dev/docs/getting-started/activate-license/#encryption-key'
				),
				'error',
				'daan-encryption-key-missing'
			);
			
			return;
		}
		
		$valid_licenses = Plugin::valid_licenses();
		$should_update  = false;
		
		foreach ( $valid_licenses as $id => $license ) {
			$license_key = $license['license'] ?? '';
			
			if ( ! $license_key ) {
				continue;
			}
			
			$plugin_file_path = $license['plugin_file'] ?? '';
			
			/**
			 * 1. If a plugin file doesn't exist -> mark for cleanup, continue.
			 */
			if ( ! $plugin_file_path || ! file_exists( $plugin_file_path ) ) {
				unset( $valid_licenses[ $id ] );
				
				$should_update = true;
				
				continue;
			}
			
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			
			$plugin_file = plugin_basename( $plugin_file_path );
			
			/**
			 * 2. If the plugin is not active -> continue (leave entry untouched).
			 */
			if ( ! is_plugin_active( $plugin_file ) ) {
				continue;
			}
			
			/**
			 * 3. Otherwise -> attempt decrypt + validate, set notice and return if invalid.
			 */
			$decrypted = Plugin::decrypt( $license_key, $id );
			
			if ( ! Plugin::validate( $decrypted ) ) {
				Notice::set_notice(
					sprintf(
						__(
							'Your Daan.dev license(s) failed to validate, likely because the encryption key has changed. Visit the <a href="%s">Manage Licenses</a> page and re-enter your license keys.',
							'daan-license-manager'
						),
						admin_url( 'options-general.php?page=ffwp-license-manager' )
					),
					'error',
					'daan-license-key-corrupt'
				);
				
				return;
			}
		}
		
		if ( $should_update ) {
			update_option( Admin::OPTION_VALID_LICENSES, $valid_licenses );
		}
	}
	
	/**
	 * Hooked into admin_init in Plugin constructor.
	 *
	 * @return void
	 */
	public function install() {
		// If it's already defined, consider the installation successful.
		if ( defined( Plugin::DAAN_LM_ENC_KEY_LABEL ) || apply_filters( 'daan_do_not_install_encryption_key', false ) ) {
			return;
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		$config_files = [
			ABSPATH . 'wp-config.php',
			dirname( ABSPATH ) . '/wp-config.php',
		];
		
		$enc_key = '';
		
		/**
		 * First, check if the key already exists in any of the candidate files.
		 */
		foreach ( $config_files as $path ) {
			if ( file_exists( $path ) ) {
				$contents = file_get_contents( $path );
				
				if ( $contents && preg_match( "/define\(\s*['\"]" . preg_quote( Plugin::DAAN_LM_ENC_KEY_LABEL, '/' ) . "['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)\s*;?/", $contents, $matches ) ) {
					$enc_key = $matches[1];
					break;
				}
			}
		}
		
		/**
		 * If no existing key is found, generate a new one.
		 */
		if ( ! $enc_key ) {
			$enc_key = bin2hex( random_bytes( 32 ) );
		}
		
		foreach ( $config_files as $path ) {
			if ( file_exists( $path ) && is_writable( $path ) ) {
				$this->write_to_config_file( $path, $enc_key );
			}
		}
	}
	
	/**
	 * Generates a cipher of 64 characters and writes it to wp-config.php.
	 *
	 * @var string $path The absolute path to the wp-config.php file.
	 *
	 * @since v1.10.2
	 * @return int|false The length of the added define statement, or false on failure.
	 */
	private function write_to_config_file( $path, $enc_key ) {
		$wp_config = file_get_contents( $path );
		
		if ( $wp_config === false ) {
			return false;
		}
		
		$label = Plugin::DAAN_LM_ENC_KEY_LABEL;
		
		// Check if the constant already exists in the file
		if ( preg_match( "/define\(\s*['\"]" . preg_quote( $label, '/' ) . "['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)\s*;?/", $wp_config, $matches ) && ! empty( $matches[0] ) ) {
			// If it exists but has a different value, we should update it.
			if ( $matches[1] !== $enc_key ) {
				$wp_config = str_replace( $matches[0], "define('$label', '$enc_key');", $wp_config );
			} else {
				return strlen( $matches[0] ); // Return the length of the matched define statement
			}
		} else {
			$wp_config = preg_replace(
				"/^([\r\n\t ]*)(\<\?)(php)?/i",
				"<?php\n// Added by Daan.dev License Manager. Do not change/remove this.\ndefine('$label', '$enc_key');",
				$wp_config
			);
		}
		
		if ( $wp_config === null ) {
			return false;
		}
		
		$tmp_path = $path . '.tmp';
		$result   = file_put_contents( $tmp_path, $wp_config );
		
		if ( $result === false ) {
			return false;
		}
		
		$renamed = rename( $tmp_path, $path );
		
		if ( ! $renamed ) {
			if ( file_exists( $tmp_path ) ) {
				unlink( $tmp_path );
			}
			
			return false;
		}
		
		return $result;
	}
}
