<?php

/**
 * Developers (or me) can add extra license registration fields using the below filter.
 *
 * The result should be an array element containing the following information:
 * - 'id': The ID the plugin has in EDD.
 * - 'label': Will be displayed beside the license input field.
 * - 'version': The current version of the plugin.
 * - 'plugin_file': The path to the plugin file, required for EDD updates.
 */

use Daan\LicenseManager\Admin;
use Daan\LicenseManager\Plugin;

$installed_plugins = apply_filters( 'daan_active_premium_plugins', [] );
?>
<div class="wrap">
    <h1><img class="daan-dev-logo" alt="Daan.dev logo" src="<?php echo DAAN_LICENSE_MANAGER_PLUGIN_URL; ?>assets/images/daan-dev-logo-color@2x.png"> <?php echo __(
                'License Manager',
                'daan-license-manager'
        ); ?></h1>
    <h2 class="daan-nav-tab-wrapper nav-tab-wrapper">
        <a class="nav-tab daan-nav-tab daan-nav-tab-active dashicons-before dashicons-arrow-left" href="" onclick="history.back()"><?php _e( 'Go Back', 'daan-license-manager' ); ?></a>
    </h2>
    <div class="daan-license-form-container">
        <p>
            <?php echo __( 'Activate your license key to start using your Daan.dev products on this site.', 'daan-license-manager' ); ?>
        </p>
        <?php
        settings_fields( Admin::SETTINGS_SECTION );
        do_settings_sections( Admin::SETTINGS_SECTION );
        wp_nonce_field( Admin::SETTINGS_NONCE, Admin::SETTINGS_NONCE );
        ?>

        <table class="form-table">
            <?php if ( ! empty( $installed_plugins ) ) : ?>
                <?php $just_renewed = __( '<em><a href="#" data-key="%1$s" data-item-id="%2$s" class="check-license">Just renewed</a>?</em>', 'daan-license-manager' ); ?>
                <?php foreach ( $installed_plugins as $plugin_data ) : ?>
                    <tr>
                        <th scope="row">
                            <label for="<?php echo esc_attr( $plugin_data['id'] ); ?>">
                                <?php echo esc_html( $plugin_data['label'] ); ?>
                            </label>
                        </th>
                        <td>
                            <?php
                            $valid_licenses      = Plugin::valid_licenses();
                            $license_data        = $valid_licenses[ $plugin_data['id'] ] ?? null;
                            $encrypted_key       = $license_data['license'] ?? '';
                            $expiry_date         = $license_data['expires'] ?? '';
                            $expiry_date_seconds = strtotime( $expiry_date );
                            $decrypted_key       = '';

                            if ( $encrypted_key ) {
                                $decrypted_key = Plugin::decrypt( $encrypted_key, $plugin_data['id'] );
                            }
                            ?>
                            <?php if ( ! $decrypted_key ) : ?>
                                <!-- License Key failed to decrypt -->
                                <i class="daan-dev-icon daan-dev-invalid dashicons-before dashicons-no"></i>
                            <?php elseif ( Plugin::license_will_expire_soon( $plugin_data['id'] ) && ! Plugin::license_has_active_subscription( $plugin_data['id'] ) ) : ?>
                                <!-- License will expire soon -->
                                <i class="daan-dev-icon daan-dev-valid daan-dev-warning">!</i>
                            <?php elseif ( Plugin::license_is_expired( $plugin_data['id'] ) ) : ?>
                                <!-- License is expired -->
                                <i class="daan-dev-icon daan-dev-valid daan-dev-warning">!</i>
                            <?php elseif ( isset( $license_data['license_status'] ) && $license_data['license_status'] == 'valid' ) : ?>
                                <!-- License Key is valid -->
                                <i class="daan-dev-icon daan-dev-valid dashicons-before dashicons-yes"></i>
                            <?php else : ?>
                                <!-- Something's wrong -->
                                <i class="daan-dev-icon daan-dev-invalid dashicons-before dashicons-no"></i>
                            <?php endif; ?>
                            <?php if ( $license_data !== null && $decrypted_key ) : ?>
                                <?php
                                $key_length = strlen( $decrypted_key );
                                $masked_key = substr_replace( $decrypted_key, str_repeat( '*', $key_length - 10 ), 5, $key_length - 10 );
                                ?>
                                <input disabled class="ffwp-input-field" type="text" id="<?php echo esc_attr( $plugin_data['id'] ); ?>" value="<?php echo esc_attr( $masked_key ); ?>"/>
                                <input type="hidden" class="ffwp-plugin-file"
                                       value="<?php echo esc_attr( $plugin_data['plugin_file'] ); ?>"/>
                                <input type="button" class="button button-secondary ffwp-deactivate-license"
                                       data-key="<?php echo esc_attr( $encrypted_key ); ?>"
                                       data-item-id="<?php echo esc_attr( $plugin_data['id'] ); ?>"
                                       value="<?php echo __( 'Deactivate License', 'daan-license-manager' ); ?>"/>
                            <?php else : ?>
                                <input class="ffwp-license-key" type="text" id="<?php echo esc_attr( $plugin_data['id'] ); ?>"/>
                                <input type="hidden" class="ffwp-plugin-file" value="<?php echo esc_attr( $plugin_data['plugin_file'] ); ?>"/>
                                <input type="button" class="button button-primary ffwp-activate-license"
                                       data-item-id="<?php echo esc_attr( $plugin_data['id'] ); ?>"
                                       value="<?php echo __( 'Activate License', 'daan-license-manager' ); ?>"/>
                            <?php endif; ?>
                            <p class="description">
                                <?php if ( ! $decrypted_key ) : ?>
                                    <?php
                                    echo wp_kses_post(
                                            sprintf(
                                                    __( 'Enter the license key you received upon purchase to validate %s.', 'daan-license-manager' ),
                                                    esc_html( $plugin_data['label'] )
                                            )
                                    );
                                    ?>
                                <?php elseif ( $expiry_date == 'lifetime' ) : ?>
                                    <?php
                                    echo wp_kses_post( sprintf( __( 'Your license for %s will never expire.', 'daan-license-manager' ), esc_html( $plugin_data['label'] ) ) );
                                    ?>
                                <?php elseif ( Plugin::license_will_expire_soon( $plugin_data['id'] ) && ! Plugin::license_has_active_subscription( $plugin_data['id'] ) ) : ?>
                                    <?php
                                    echo wp_kses_post( // Licenses expiring within 7 days.
                                            sprintf(
                                                    __(
                                                            'Your license for %1$s will expire on %2$s. <a target="_blank" href="%3$s">Click here</a> to extend your license.',
                                                            'daan-license-manager'
                                                    ),
                                                    esc_html( $plugin_data['label'] ),
                                                    date_i18n( get_option( 'date_format' ), $expiry_date_seconds ),
                                                    esc_url( sprintf( Plugin::DAAN_DEV_URL_RENEW_LICENSE, $plugin_data['id'], $decrypted_key ) )
                                            ) . ' ' . sprintf( $just_renewed, esc_attr( $encrypted_key ), esc_attr( $plugin_data['id'] ) )
                                    );
                                    ?>
                                <?php elseif ( Plugin::license_is_expired( $plugin_data['id'] ) ) : ?>
                                    <?php
                                    echo wp_kses_post( // Expired licenses.
                                            sprintf(
                                                    __(
                                                            'Your license for %1$s expired on %2$s. <a target="_blank" href="%3$s">Click here</a> to renew your license.',
                                                            'daan-license-manager'
                                                    ),
                                                    esc_html( $plugin_data['label'] ),
                                                    date_i18n( get_option( 'date_format' ), $expiry_date_seconds ),
                                                    esc_url( sprintf( Plugin::DAAN_DEV_URL_RENEW_LICENSE, $plugin_data['id'], $decrypted_key ) )
                                            ) . ' ' . sprintf( $just_renewed, esc_attr( $encrypted_key ), esc_attr( $plugin_data['id'] ) )
                                    );
                                    ?>
                                <?php elseif ( $expiry_date ) : ?>
                                    <?php
                                    echo wp_kses_post(
                                            sprintf(
                                                    __( 'Your license for %1$s will expire on %2$s.', 'daan-license-manager' ),
                                                    esc_html( $plugin_data['label'] ),
                                                    date_i18n( get_option( 'date_format' ), $expiry_date_seconds )
                                            )
                                    );
                                    ?>
                                    <?php if ( Plugin::license_has_active_subscription( $plugin_data['id'] ) ) : ?>
                                        <?php echo __( 'It will be automatically renewed on that same date.', 'daan-license-manager' ); ?>
                                    <?php endif; ?>
                                <?php else : ?>
                                    <?php
                                    echo wp_kses_post(
                                            sprintf(
                                                    __( 'Enter the license key you received upon purchase to validate %s.', 'daan-license-manager' ),
                                                    esc_html( $plugin_data['label'] )
                                            )
                                    );
                                    ?>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <th scope="row">
                        <?php echo __( 'No licenses found. Are your Daan.dev plugins installed and activated?', 'daan-license-manager' ); ?>
                    </th>
                    <td></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
    <h2>
        <?php echo __( 'Don\'t have a License Key?', 'daan-license-manager' ); ?>
    </h2>
    <p>
        <?php echo wp_kses_post(
                sprintf(
                        __(
                                'Daan.dev products require a valid license key to function properly. If somehow you came across this plugin before acquiring one, you can purchase a license at <a href="%s" target="_blank">Daan.dev</a>.',
                                'daan-license-manager'
                        ),
                        'https://daan.dev/'
                )
        ); ?>
    </p>
    <h2>
        <?php echo __( 'Where can I find my License Key(s)?', 'daan-license-manager' ); ?>
    </h2>
    <p>
        <?php
        echo sprintf(
                _n(
                        'Your license key was sent to the email address you entered upon purchase. Can\'t find the email? Simply <a href="%1$s">login to your account</a> to retrieve your license key.',
                        'Your license keys were sent to the email address(es) you entered upon purchase. Can\'t find the email? Simply <a href="%1$s">login to your account</a> to retrieve your license keys.',
                        count( $installed_plugins ),
                        'daan-license-manager'
                ),
                Plugin::DAAN_DEV_URL_LICENSE_KEYS
        );
        ?>
    </p>
</div>
