<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro;

use OMGF\Download;
use OMGF\Frontend\Process;
use OMGF\Helper as OMGF;
use OMGF\Pro\Admin\Notice;
use stdClass;

/**
 * @codeCoverageIgnore Because it's a wrapper around OMGF's Helper class, which is tested extensively.
 */
class Wrapper {
	/**
	 * A safety wrapper around OMGF's @see OMGF::admin_optimized_fonts method, to prevent fatal errors during updates.
	 *
	 * @param array $maybe_add An array of fonts to potentially add to the optimized list.
	 * @param bool  $force_add Whether to force adding the fonts to the optimized list.
	 *
	 * @return array
	 */
	public static function admin_optimized_fonts( $maybe_add = [], $force_add = false ) {
		if ( ! method_exists( '\OMGF\Helper', 'admin_optimized_fonts' ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return OMGF::admin_optimized_fonts( $maybe_add, $force_add );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::cache_keys() method, to prevent fatal errors during updates.
	 *
	 * @since 4.0.0
	 *
	 * @return array
	 */
	public static function cache_keys() {
		if ( ! method_exists( '\OMGF\Helper', 'cache_keys' ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return OMGF::cache_keys();
	}
	
	/**
	 * A safety wrapper around OMGF's debug method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param $message
	 *
	 * @return void
	 */
	public static function debug( $message ) {
		if ( ! method_exists( '\OMGF\Helper', 'debug' ) ) {
			return; // @codeCoverageIgnore
		}
		
		OMGF::debug( $message );
	}
	
	/**
	 * A safety wrapper around OMGF's debug_array method to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param $array
	 *
	 * @param $name
	 *
	 * @return void
	 */
	public static function debug_array( $name, $array ) {
		if ( ! method_exists( '\OMGF\Helper', 'debug_array' ) ) {
			return; // @codeCoverageIgnore
		}
		
		OMGF::debug_array( $name, $array );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::delete() method to prevent fatal errors during updates.'
	 *
	 * @param $dir
	 *
	 * @return void
	 */
	public static function delete( $dir ) {
		if ( ! method_exists( '\OMGF\Helper', 'delete' ) ) {
			return; // @codeCoverageIgnore
		}
		
		OMGF::delete( $dir );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::delete_option method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param mixed $option_name
	 *
	 * @return bool
	 */
	public static function delete_option( $option_name ) {
		if ( ! method_exists( '\OMGF\Helper', 'delete_option' ) ) {
			return false; // @codeCoverageIgnore
		}
		
		return OMGF::delete_option( $option_name );
	}
	
	/**
	 * Safety wrapper for OMGF's @see OMGF::generate_stylesheet method to prevent fatal errors during updates.
	 *
	 * @param $fonts
	 *
	 * @return string
	 */
	public static function generate_stylesheet( $fonts ) {
		if ( ! method_exists( '\OMGF\Helper', 'generate_stylesheet' ) ) {
			return ''; // @codeCoverageIgnore
		}
		
		return OMGF::generate_stylesheet( $fonts, 'OMGF Pro' );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::get_cache_key() method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param $handle
	 *
	 * @return string
	 */
	public static function get_cache_key( $handle ) {
		if ( ! method_exists( '\OMGF\Helper', 'get_cache_key' ) ) {
			return ''; // @codeCoverageIgnore
		}
		
		return OMGF::get_cache_key( $handle );
	}
	
	/**
	 * A safety wrapper for OMGF's Process-class. To minimize dependency and prevent fatal errors during updates.
	 *
	 * @return stdClass|Process
	 */
	public static function get_frontend_processor() {
		if ( ! class_exists( '\OMGF\Frontend\Process' ) ) {
			// @codeCoverageIgnoreStart
			Notice::set_notice(
				__( 'OMGFs frontend processor couldn\'t be fetched. Is OMGF installed and/or activated?', 'omgf-pro' )
			);
			
			return new stdClass();
			// @codeCoverageIgnoreEnd
		}
		
		return new Process();
	}
	
	/**
	 * A safety wrapper for OMGF's @see OMGF::get_option method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param mixed $default (optional)
	 *
	 * @param mixed $option_name
	 *
	 * @return mixed
	 */
	public static function get_option( $option_name, $default = null ) {
		if ( ! method_exists( '\OMGF\Helper', 'get_option' ) ) {
			return $default; // @codeCoverageIgnore
		}
		
		return OMGF::get_option( $option_name, $default );
	}
	
	/**
	 * A safety wrapper for OMGF's @see OMGF_UPLOAD_DIR constant.
	 *
	 * @return string Absolute path to OMGF's uploads dir.
	 */
	public static function get_upload_dir() {
		if ( ! defined( 'OMGF_UPLOAD_DIR' ) ) {
			return WP_CONTENT_DIR . '/uploads/omgf'; // @codeCoverageIgnore
		}
		
		return OMGF_UPLOAD_DIR;
	}
	
	/**
	 * A safety wrapper for OMGF's @see OMGF_UPLOAD_URL constant.
	 *
	 * @return string protocol relative URL to OMGF's uploads dir.
	 */
	public static function get_upload_url() {
		if ( ! defined( 'OMGF_UPLOAD_URL' ) ) {
			return str_replace( [ 'http:', 'https:' ], '', WP_CONTENT_URL . '/uploads/omgf' ); // @codeCoverageIgnore
		}
		
		return OMGF_UPLOAD_URL;
	}
	
	/**
	 * Since this is a relatively simple function, we fall back to the default (Pro) behavior if OMGF currently can't be found.
	 *
	 * @since v5.2.7 Added capabilities and nonce checks to prevent unauthenticated exploitation.
	 *
	 * @return bool
	 */
	public static function is_running_optimize( $post = [] ) {
		if ( ! method_exists( '\OMGF\Helper', 'is_running_optimize' ) ) {
			$has_params = ( array_key_exists( 'omgf_optimize', $_GET ) || array_key_exists( 'omgf_optimize', $post ) ) &&
			              ( array_key_exists( 'omgf_pro_auto_config', $_GET ) || array_key_exists( 'omgf_pro_auto_config', $post ) );
			
			if ( ! $has_params ) {
				return false;
			}
			
			if ( ! current_user_can( 'manage_options' ) ) {
				return false;
			}
			
			$nonce = $_GET['omgf_optimize'] ?? $post['omgf_optimize'] ?? '';
			
			return wp_verify_nonce( $nonce, 'omgf_optimize' ) !== false;
		}
		
		return OMGF::is_running_optimize( $post );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::is_valid_font_family() method, to prevent fatal
	 * errors during updates.
	 *
	 * Falls back to true, i.e. every value is considered a font family, which is how OMGF Pro
	 * behaved before this check existed. Use @see self::has_font_family_validation() to find out
	 * whether the installed version of OMGF actually validates.
	 *
	 * @since v5.2.11
	 *
	 * @param string $family
	 *
	 * @return bool
	 */
	public static function is_valid_font_family( $family ) {
		if ( ! self::has_font_family_validation() ) {
			return true;
		}

		return OMGF::is_valid_font_family( $family );
	}

	/**
	 * Whether the installed version of OMGF (v6.3.11 and up) can tell a font family name from a
	 * font-family declaration value.
	 *
	 * @since v5.2.11
	 *
	 * @return bool
	 */
	public static function has_font_family_validation() {
		return method_exists( '\OMGF\Helper', 'is_valid_font_family' );
	}

	/**
	 * Safety wrapper for OMGF's @see Download::MIME_MAP constant to prevent fatal errors during updates.
	 *
	 * @return array|string[]
	 */
	public static function mime_map() {
		if ( ! class_exists( '\OMGF\Download' ) || ! defined( '\OMGF\Download::MIME_MAP' ) ) {
			return [];
		}
		
		return Download::MIME_MAP;
	}
	
	/**
	 * Provides a fallback mechanism for OMGF's no_cache_optimize_url method, ensuring compatibility and preventing errors during updates or if OMGF is not loaded.
	 *
	 * @param string $url The URL to be processed. Defaults to an empty string, which returns the home URL if OMGF is not available.
	 *
	 * @return string The optimized URL or the fallback URL.
	 */
	public static function no_cache_optimize_url( $url = '' ) {
		if ( ! method_exists( '\OMGF\Helper', 'no_cache_optimize_url' ) ) {
			if ( ! $url ) {
				return get_home_url();
			}
			
			return $url;
		}
		
		return OMGF::no_cache_optimize_url( $url );
	}
	
	/**
	 * Safety wrapper for OMGF's @see OMGF::optimize_succeeded() method to prevent fatal errors during updates.
	 *
	 * @return bool
	 */
	public static function optimize_succeeded() {
		if ( ! method_exists( '\OMGF\Helper', 'optimize_succeeded' ) ) {
			return false; // @codeCoverageIgnore
		}
		
		return apply_filters( 'omgf_pro_optimize_succeeded', OMGF::optimize_succeeded() );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::optimized_fonts method, to prevent fatal errors during updates.
	 *
	 * @since 3.11.0
	 * @return array
	 */
	public static function optimized_fonts( $maybe_add = [], $force_add = false ) {
		if ( ! method_exists( '\OMGF\Helper', 'optimized_fonts' ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return OMGF::optimized_fonts( $maybe_add, $force_add );
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::unloaded_fonts() method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 * @return array
	 */
	public static function unloaded_fonts() {
		if ( ! method_exists( '\OMGF\Helper', 'unloaded_fonts' ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return OMGF::unloaded_fonts();
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::unloaded_stylesheets() method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 * @return array
	 */
	public static function unloaded_stylesheets() {
		if ( ! method_exists( '\OMGF\Helper', 'unloaded_stylesheets' ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return OMGF::unloaded_stylesheets();
	}
	
	/**
	 * A safety wrapper around OMGF's @see OMGF::update_option_method, to prevent fatal errors during updates.
	 *
	 * @since 3.8.2
	 *
	 * @param mixed $value
	 *
	 * @param mixed $option_name
	 *
	 * @return bool
	 */
	public static function update_option( $option_name, $value ) {
		if ( ! method_exists( '\OMGF\Helper', 'update_option' ) ) {
			return false; // @codeCoverageIgnore
		}
		
		return OMGF::update_option( $option_name, $value );
	}
}
