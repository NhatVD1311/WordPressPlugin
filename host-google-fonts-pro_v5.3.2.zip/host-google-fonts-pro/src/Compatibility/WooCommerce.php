<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2026 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Compatibility;

/**
 * WooCommerce's endpoints, e.g. /checkout/order-received/<order_id>/ or /my-account/view-order/<order_id>/, are personal
 * pages, which are never page cached. Their canonical path is the path of the page they're an endpoint of (e.g.
 * /checkout/), but their contents (and the fonts they use) are different. So, results for the checkout form would be
 * applied to the order received page, or vice versa.
 *
 * @since v5.3.2
 */
class WooCommerce {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_filter( 'omgf_pro_smart_optimize_excluded', [ $this, 'exclude_endpoints' ] );
	}

	/**
	 * Exclude WooCommerce's endpoints from Smart Optimize.
	 *
	 * @filter omgf_pro_smart_optimize_excluded
	 *
	 * @see    \OMGF\Pro\Helper::is_smart_optimize_excluded()
	 *
	 * @param bool $excluded
	 *
	 * @return bool
	 */
	public function exclude_endpoints( $excluded ) {
		// WooCommerce's endpoints are only known once the request is parsed into query vars.
		if ( $excluded || ! did_action( 'parse_request' ) ) {
			return $excluded;
		}

		return \is_wc_endpoint_url();
	}
}
