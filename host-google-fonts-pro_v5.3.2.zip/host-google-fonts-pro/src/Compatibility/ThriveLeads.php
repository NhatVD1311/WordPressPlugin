<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2026 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Compatibility;

use OMGF\Pro\Frontend\Optimize;
use OMGF\Pro\Wrapper;

/**
 * Thrive Leads (and other Thrive products) load forms asynchronously using an AJAX request. Their HTML contains inline
 * stylesheets which @import Google Fonts stylesheets, which is inserted into the page using JavaScript. Because this
 * HTML isn't part of the page, OMGF's output buffer never processes it.
 *
 * @since v5.3.0
 */
class ThriveLeads {
	/**
	 * AJAX actions returning the forms' HTML: Thrive Leads' own, and Thrive Dashboard's, which batches the requests of
	 * all Thrive products (if Thrive Dashboard is active).
	 */
	const AJAX_ACTIONS = [
		'tve_leads_ajax_load_forms',
		'tve_dash_front_ajax',
	];

	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		foreach ( self::AJAX_ACTIONS as $action ) {
			// Run before Thrive's own handler (default priority), so its output is buffered.
			add_action( "wp_ajax_$action", [ $this, 'start_buffer' ], 0 );
			add_action( "wp_ajax_nopriv_$action", [ $this, 'start_buffer' ], 0 );
		}
	}

	/**
	 * Buffer the AJAX response, so the Google Fonts it @imports can be replaced by locally hosted copies.
	 *
	 * @action wp_ajax_(nopriv_)tve_leads_ajax_load_forms
	 * @action wp_ajax_(nopriv_)tve_dash_front_ajax
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore Because output buffers can't be tested reliably.
	 */
	public function start_buffer() {
		if ( ! $this->should_process() ) {
			return;
		}

		ob_start( [ $this, 'process_response' ] );
	}

	/**
	 * In Test Mode, optimizations are only visible to administrators.
	 *
	 * @return bool
	 */
	public function should_process() {
		return empty( Wrapper::get_option( \OMGF\Admin\Settings::OMGF_OPTIMIZE_SETTING_TEST_MODE ) ) || current_user_can( 'manage_options' );
	}

	/**
	 * Replaces Google Fonts @import statements in the (JSON) response by locally hosted copies.
	 *
	 * @param string $output
	 *
	 * @return string
	 */
	public function process_response( $output ) {
		if ( ! is_string( $output ) || strpos( $output, 'fonts.googleapis.com' ) === false ) {
			return $output;
		}

		$data = json_decode( $output, true );

		if ( ! is_array( $data ) ) {
			return $output;
		}

		$optimize = new Optimize( false );
		$modified = false;

		array_walk_recursive(
			$data,
			function ( &$value ) use ( $optimize, &$modified ) {
				if ( ! is_string( $value ) || strpos( $value, 'fonts.googleapis.com' ) === false ) {
					return;
				}

				$processed = $optimize->process_imports( $value );

				if ( $processed !== $value ) {
					$value    = $processed;
					$modified = true;
				}
			}
		);

		if ( ! $modified ) {
			return $output;
		}

		$json = wp_json_encode( $data );

		return $json === false ? $output : $json;
	}
}
