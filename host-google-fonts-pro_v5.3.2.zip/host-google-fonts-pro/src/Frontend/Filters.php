<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2025 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend;

use OMGF\Pro\Helper;

class Filters {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_filter( 'omgf_do_not_load_frontend_js', [ $this, 'maybe_load_frontend_assets' ], 11 );
	}
	
	/**
	 * Conditionally load OMGF (free) frontend assets based on specific options.
	 *
	 * @filter             omgf_do_not_load_frontend_js
	 *
	 * @return bool The transient value if the condition is true, or the original input value otherwise.
	 *
	 * @codeCoverageIgnore because it returns a bool based on a setting.
	 */
	public function maybe_load_frontend_assets() {
		if ( Helper::should_smart_optimize_run() ) {
			return false; // Do NOT NOT load. Double negative, so this means the assets should be loaded.
		}
		
		return true; // Do NOT load.
	}
}
