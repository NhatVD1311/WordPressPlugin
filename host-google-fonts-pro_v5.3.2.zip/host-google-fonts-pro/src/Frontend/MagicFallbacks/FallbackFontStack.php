<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\MagicFallbacks;

use OMGF\Pro\FontMetrics;
use OMGF\StylesheetGenerator;

class FallbackFontStack {
	/**
	 * If a Google Font is renamed, it's added here, so we can map it to the new name.
	 *
	 * Format: [ 'Old Name' => 'New Name' ]
	 *
	 * @since v5.2.0
	 */
	const ALIASES = [
		'Droid Serif'         => 'PT Serif',
		'Fredoka One'         => 'Fredoka',
		'Gentium Basic'       => 'Gentium Plus',
		'Google Sans Display' => 'Google Sans',
		'Google Sans Text'    => 'Google Sans',
		'Muli'                => 'Mooli',
		'Noto Sans JP'        => 'Noto Sans Japanese',
		'Source Sans Pro'     => 'Source Sans 3',
		'Source Serif Pro'    => 'Source Serif 4',
	];

	/**
	 * @var array
	 */
	private static $googleFonts;
	
	/**
	 * @var array
	 */
	private static $systemFonts;
	
	/**
	 * @var array
	 */
	private static $systemFontsPerOs;
	
	/**
	 * Find the best matching system font(s) for a given Google Font family.
	 *
	 * Returns an empty array if:
	 * - No matching system fonts are found for any OS
	 * - The font is not found in the dataset
	 *
	 * Returns null if the font's category is 'display' or 'handwriting' (unsupported by design).
	 *
	 * @since v5.2.0
	 *
	 * @param string $family The Google Font family name, e.g. 'Roboto'
	 *
	 * @return array|null
	 */
	public static function find_best_match( $family ) {
		/**
		 * @since v5.2.9 If the family name is an alias, return an empty array to prevent notices.
		 */
		if ( self::is_alias( $family ) ) {
			return []; // @codeCoverageIgnore
		}
		
		self::initialize_metrics();
		
		$google_fonts = self::$googleFonts;
		$aliases      = apply_filters( 'omgf_pro_fallback_font_aliases', self::ALIASES );
		
		if ( isset( $aliases[ $family ] ) ) {
			$family = $aliases[ $family ]; // @codeCoverageIgnore
		}
		
		if ( ! isset( $google_fonts[ $family ] ) ) {
			return []; // @codeCoverageIgnore
		}
		
		if ( ! self::is_supported_family( $family ) ) {
			return null; // @codeCoverageIgnore
		}
		
		$webfont             = $google_fonts[ $family ];
		$system_fonts        = self::$systemFonts;
		$system_fonts_per_os = self::$systemFontsPerOs;
		$result              = [];
		
		foreach ( $system_fonts_per_os as $os => $font_keys ) {
			$best_score = PHP_FLOAT_MAX;
			$best_key   = null;
			
			foreach ( $font_keys as $key ) {
				if ( ! isset( $system_fonts[ $key ] ) ) {
					continue;
				}
				
				// Only match system fonts of the same category as the web font.
				if ( ( $system_fonts[ $key ]['category'] ?? '' ) !== ( $webfont['category'] ?? '' ) ) {
					continue;
				}
				
				$score = self::calculate_score( $webfont, $system_fonts[ $key ] );
				
				if ( $score !== null && $score < $best_score ) {
					$best_score = $score;
					$best_key   = $key;
				}
			}
			
			if ( $best_key ) {
				$overrides = self::calculate_overrides( $webfont, $system_fonts[ $best_key ] );
				
				if ( ! $overrides ) {
					continue; // @codeCoverageIgnore
				}
				
				$result[ $os ] = [
					'key'        => $best_key,
					'familyName' => $system_fonts[ $best_key ]['familyName'],
					'overrides'  => $overrides,
				];
			}
		}
		
		return $result;
	}
	
	/**
	 * Check if a font family name is a Magic Fallback alias.
	 *
	 * @since v5.2.9
	 *
	 * @param string $family
	 *
	 * @return bool
	 */
	public static function is_alias( $family ) {
		if ( ! str_contains( $family, '-' ) ) {
			return false;
		}
		
		self::initialize_metrics();
		
		$parts = explode( '-', $family );
		
		if ( count( $parts ) < 2 ) {
			return false; // @codeCoverageIgnore
		}
		
		$system_font_part = end( $parts );
		
		return isset( self::$systemFonts[ lcfirst( $system_font_part ) ] );
	}
	
	/**
	 * Initialize font metrics datasets once.
	 *
	 * @return void
	 */
	private static function initialize_metrics() {
		if ( self::$googleFonts !== null ) {
			return;
		}
		
		self::$googleFonts      = FontMetrics::google_fonts();
		self::$systemFonts      = FontMetrics::system_fonts();
		self::$systemFontsPerOs = FontMetrics::system_fonts_per_os();
	}
	
	/**
	 * Find the best matching system font per OS for a given Google Font family name,
	 * using a weighted score across font metrics.
	 *
	 * Returns an array keyed by OS (android, macOS, windows), or an empty array if:
	 * - The font is not found in the dataset
	 *
	 * Returns null if the font's category is 'display' or 'handwriting' (unsupported by design).
	 *
	 * @since v5.2.0
	 *
	 * @param string $family The Google Font family name, e.g. 'Roboto'
	 *
	 * @return bool
	 */
	public static function is_supported_family( $family ) {
		self::initialize_metrics();
		
		$google_fonts = self::$googleFonts;
		
		if ( ! isset( $google_fonts[ $family ] ) ) {
			return false; // @codeCoverageIgnore
		}
		
		$webfont = $google_fonts[ $family ];
		
		return ! in_array( $webfont['category'] ?? '', [ 'display', 'handwriting' ], true );
	}
	
	/**
	 * Calculate a weighted match score between a web font and a system font.
	 * All values are normalized to unitsPerEm before comparison. Lower = better match.
	 *
	 * @since v5.2.7 Fall back to an ascent/descent/lineGap-only score when capHeight is missing or,
	 *               zero for either font, to support fonts without reliable capHeight metrics.
	 *
	 * @param array $webfont
	 * @param array $system
	 *
	 * @return float|null
	 */
	private static function calculate_score( $webfont, $system ) {
		if ( empty( $webfont['unitsPerEm'] ) || empty( $system['unitsPerEm'] ) || ! is_numeric( $webfont['unitsPerEm'] ) || ! is_numeric( $system['unitsPerEm'] ) ) {
			return null; // @codeCoverageIgnore
		}
		
		$has_cap_height = ! empty( $webfont['capHeight'] ) && ! empty( $system['capHeight'] );
		
		if ( $has_cap_height ) {
			return (
				abs( $webfont['capHeight'] / $webfont['unitsPerEm'] - $system['capHeight'] / $system['unitsPerEm'] ) * 0.50 +
				abs( $webfont['ascent'] / $webfont['unitsPerEm'] - $system['ascent'] / $system['unitsPerEm'] ) * 0.25 +
				abs( $webfont['descent'] / $webfont['unitsPerEm'] - $system['descent'] / $system['unitsPerEm'] ) * 0.15 +
				abs( $webfont['lineGap'] / $webfont['unitsPerEm'] - $system['lineGap'] / $system['unitsPerEm'] ) * 0.10
			);
		}
		
		/**
		 * @since v5.2.7 capHeight is missing or zero for one of the fonts (e.g., Neuton, Oxygen).
		 *               Redistribute the capHeight weight proportionally across the remaining metrics.
		 */
		return (
			abs( $webfont['ascent'] / $webfont['unitsPerEm'] - $system['ascent'] / $system['unitsPerEm'] ) * 0.50 +
			abs( $webfont['descent'] / $webfont['unitsPerEm'] - $system['descent'] / $system['unitsPerEm'] ) * 0.30 +
			abs( $webfont['lineGap'] / $webfont['unitsPerEm'] - $system['lineGap'] / $system['unitsPerEm'] ) * 0.20
		);
	}
	
	/**
	 * Calculate CSS font metric override values to make a system font match a web font.
	 *
	 * @param array $webfont
	 * @param array $system
	 *
	 * @return array|null
	 */
	private static function calculate_overrides( array $webfont, array $system ) {
		if ( empty( $webfont['unitsPerEm'] ) || empty( $system['unitsPerEm'] ) || ! is_numeric( $webfont['unitsPerEm'] ) || ! is_numeric( $system['unitsPerEm'] ) ) {
			return null; // @codeCoverageIgnore
		}
		
		// Use xWidthAvg-based size-adjust if available for both fonts, as this better
		// matches horizontal character widths and reduces text reflow (CLS).
		if ( ! empty( $webfont['xWidthAvg'] ) && ! empty( $system['xWidthAvg'] ) ) {
			$size_adjust = ( $webfont['xWidthAvg'] / $webfont['unitsPerEm'] )
			               / ( $system['xWidthAvg'] / $system['unitsPerEm'] );
		} else {
			// Fall back to capHeight-based size-adjust.
			$size_adjust = ( ( $webfont['capHeight'] ?? 0 ) / $webfont['unitsPerEm'] ) / ( ( ( $system['capHeight'] ?? 0 ) ?: 1 ) / $system['unitsPerEm'] );
		}
		
		if ( empty( $size_adjust ) || ! is_numeric( $size_adjust ) ) {
			return null; // @codeCoverageIgnore
		}
		
		$ascent_override   = ( $webfont['ascent'] / $webfont['unitsPerEm'] ) / $size_adjust;
		$descent_override  = ( abs( $webfont['descent'] ) / $webfont['unitsPerEm'] ) / $size_adjust;
		$line_gap_override = ( $webfont['lineGap'] / $webfont['unitsPerEm'] ) / $size_adjust;
		
		return [
			'size_adjust'       => round( $size_adjust * 100, 4 ) . '%',
			'ascent_override'   => round( $ascent_override * 100, 4 ) . '%',
			'descent_override'  => round( $descent_override * 100, 4 ) . '%',
			'line_gap_override' => round( $line_gap_override * 100, 4 ) . '%',
		];
	}
	
	/**
	 * Format a fallback font stack for use in CSS or admin preview.
	 *
	 * @since v5.13.0
	 *
	 * @param string $family  The Google Font family name, e.g. 'Roboto'
	 * @param array  $matches Result of find_best_match()
	 * @param bool   $admin   Whether to format for admin preview.
	 *
	 * @return string
	 */
	public static function format_fallback_stack( $family, $matches, $admin = false ) {
		if ( empty( $matches ) ) {
			return $admin ? __( 'No match', 'omgf-pro' ) : "'" . self::escape_css_string( $family ) . "'"; // @codeCoverageIgnore
		}
		
		$aliases = self::get_font_family_aliases( $family, $matches );
		
		if ( $admin ) {
			$families = array_map(
				function ( $alias ) use ( $family ) {
					$alias = str_replace( $family . '-', '', $alias );
					
					return trim( $alias, "'" );
				},
				$aliases
			);
			
			return implode( ', ', $families ) . ' ' . esc_html__( '(optimized)', 'omgf-pro' );
		}
		
		$first_match      = reset( $matches );
		$system_fonts     = FontMetrics::system_fonts();
		$category         = $system_fonts[ $first_match['key'] ]['category'] ?? 'sans-serif';
		$generic_fallback = 'sans-serif';
		
		if ( $category === 'serif' ) {
			$generic_fallback = 'serif';
		} elseif ( $category === 'monospace' ) {
			$generic_fallback = 'monospace'; // @codeCoverageIgnore
		}
		
		return implode( ', ', $aliases ) . ', ' . $generic_fallback;
	}
	
	/**
	 * Escape a string for use in CSS, specifically for font-family names.
	 *
	 * @since v5.13.0
	 *
	 * @param string $string
	 *
	 * @return string
	 */
	private static function escape_css_string( $string ) {
		return addcslashes( $string, "'\\" );
	}
	
	/**
	 * Generate the unique font-family aliases for a given web font family and its OS matches.
	 * These are meant to be appended to the existing font-family stack.
	 *
	 * E.g. [ "'Roboto-Roboto'", "'Roboto-HelveticaNeue'", "'Roboto-Arial'" ]
	 *
	 * @since v5.2.0
	 *
	 * @param string $family  The Google Font family name, e.g. 'Roboto'
	 * @param array  $matches Result of find_best_match()
	 *
	 * @return array
	 */
	public static function get_font_family_aliases( $family, $matches ) {
		$aliases = [];
		
		foreach ( $matches as $match ) {
			$alias = self::build_alias( $family, $match );
			
			if ( empty( $alias ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$alias = self::escape_css_string( $alias );
			$alias = "'$alias'";
			
			if ( ! in_array( $alias, $aliases, true ) ) {
				$aliases[] = $alias;
			}
		}
		
		return $aliases;
	}
	
	/**
	 * Build a font-family alias based on the Google Font family name and the matched system font.
	 *
	 * @since v5.13.0
	 *
	 * @param string $family
	 * @param array  $match
	 *
	 * @return string
	 */
	private static function build_alias( $family, $match ) {
		if ( empty( $match['familyName'] ) ) {
			return ''; // @codeCoverageIgnore
		}
		
		return $family . '-' . str_replace( ' ', '', $match['familyName'] );
	}
	
	/**
	 * Generate @font-face CSS declarations for a given web font family and its OS matches.
	 *
	 * @since v5.2.0
	 *
	 * @param string $family  The Google Font family name, e.g. 'Roboto'
	 * @param array  $matches Result of find_best_match()
	 *
	 * @return string CSS
	 */
	public static function generate_font_face_css( $family, $matches ) {
		$css     = '';
		$aliases = [];
		
		foreach ( $matches as $match ) {
			$alias = self::build_alias( $family, $match );
			
			if ( empty( $alias ) ) {
				continue; // @codeCoverageIgnore
			}
			
			// Avoid duplicate @font-face declarations for the same alias.
			if ( in_array( $alias, $aliases, true ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$aliases[] = $alias;
			$overrides = $match['overrides'] ?? [];
			
			$alias = self::escape_css_string( $alias );
			
			$properties = [
				'font-family'       => "'$alias'",
				'src'               => StylesheetGenerator::build_source_string( [ $match['familyName'] ], 'local' ),
				'size-adjust'       => $overrides['size_adjust'] ?? '',
				'ascent-override'   => $overrides['ascent_override'] ?? '',
				'descent-override'  => $overrides['descent_override'] ?? '',
				'line-gap-override' => $overrides['line_gap_override'] ?? '',
			];
			
			$css .= StylesheetGenerator::generate_font_face( $properties );
		}
		
		return $css;
	}
	
	/**
	 * Check if a font family is an icon font (e.g. Material Icons/Symbols).
	 *
	 * Icon fonts have no meaningful text fallback, so Magic Fallbacks skips them
	 * entirely. They're identified by the dedicated 'icons' category assigned to
	 * them in the generated FontMetrics dataset (see scripts/generate-font-metrics.js).
	 *
	 * @since v5.2.9
	 *
	 * @param string $family
	 *
	 * @return bool
	 */
	public static function is_icon_font( $family ) {
		self::initialize_metrics();

		return ( self::$googleFonts[ $family ]['category'] ?? '' ) === 'icons';
	}
}
