<?php
/**
 * @since     v5.3.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2026 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\Frontend\SmartOptimize;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Wrapper;

/**
 * Keeps track of the hosts the site's pages load stylesheets, scripts and fonts from.
 *
 * Smart Optimize results are reported by visitors, so their preloads can't be trusted blindly: preloads are added to
 * the page for every visitor. By only accepting preloads from hosts the site itself already loads resources from, a
 * preload never adds a (3rd party) host the page didn't already contact.
 */
class TrustedHosts {
	/**
	 * Maximum number of stored hosts.
	 */
	const MAX_HOSTS = 50;
	
	/**
	 * Maximum number of approved and ignored hosts.
	 */
	const MAX_APPROVED_HOSTS = 100;
	
	/**
	 * Maximum number of hosts awaiting approval.
	 */
	const MAX_PENDING_HOSTS = 20;

	/**
	 * Domains on which anyone can get their own subdomain. For these, only an exact host match is trusted.
	 */
	const MULTI_TENANT_DOMAINS = [
		'akamaized.net',
		'amazonaws.com',
		'appspot.com',
		'azureedge.net',
		'azurewebsites.net',
		'b-cdn.net',
		'bitbucket.io',
		'blogspot.com',
		'cloudfront.net',
		'digitaloceanspaces.com',
		'fastly.net',
		'firebaseapp.com',
		'github.io',
		'githubusercontent.com',
		'gitlab.io',
		'googleapis.com',
		'googleusercontent.com',
		'herokuapp.com',
		'netlify.app',
		'ngrok-free.app',
		'ngrok.io',
		'onrender.com',
		'pages.dev',
		'r2.dev',
		'surge.sh',
		'vercel.app',
		'web.app',
		'windows.net',
		'wordpress.com',
		'workers.dev',
		'wpengine.com',
		'wpenginepowered.com',
	];

	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		/**
		 * Runs before OMGF Pro (10) rewrites stylesheets, i.e. while the HTML still contains the original URLs.
		 */
		add_filter( 'omgf_processed_html', [ $this, 'record' ], 5 );
	}

	/**
	 * Store the hosts of all stylesheets, scripts and fonts found in $html.
	 *
	 * @filter omgf_processed_html
	 *
	 * @param string $html
	 *
	 * @return string
	 */
	public function record( $html ) {
		if ( ! is_string( $html ) || ! Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) {
			return $html;
		}

		$stored = self::get_stored_hosts();
		$hosts  = array_diff( self::extract_hosts( $html ), $stored );

		if ( empty( $hosts ) || count( $stored ) >= self::MAX_HOSTS ) {
			return $html; // @codeCoverageIgnore
		}

		$stored = array_slice( array_merge( $stored, array_values( $hosts ) ), 0, self::MAX_HOSTS );

		update_option( Settings::OMGF_PRO_SMART_OPTIMIZE_TRUSTED_HOSTS, $stored );

		return $html;
	}

	/**
	 * Extracts the (lowercase) hosts of stylesheets, scripts and fonts loaded by $html.
	 *
	 * Only <link href>, <script src> and url() values inside <style> elements are taken into account. Links and style
	 * attributes aren't, because these can be part of e.g. comments or posts written by lower privileged users.
	 *
	 * @param string $html
	 *
	 * @return array
	 */
	public static function extract_hosts( $html ) {
		$urls = [];

		/**
		 * Ignore the preloads added by Smart Optimize itself, otherwise a preloaded host would trust itself, e.g. after it
		 * was removed from the whitelist.
		 *
		 * @see \OMGF\Pro\Frontend\SmartOptimize::maybe_add_smart_preloads()
		 */
		$html = preg_replace( '/<link\b[^>]*\bid\s*=\s*["\']?omgf-pro-smart-preload-[^>]*>/i', '', $html );

		preg_match_all( '/<link\b[^>]*?\shref\s*=\s*["\']?([^"\'\s>]+)/i', $html, $matches );
		$urls = array_merge( $urls, $matches[1] );

		preg_match_all( '/<script\b[^>]*?\ssrc\s*=\s*["\']?([^"\'\s>]+)/i', $html, $matches );
		$urls = array_merge( $urls, $matches[1] );

		preg_match_all( '/<style\b[^>]*>(.*?)<\/style>/is', $html, $styles );

		foreach ( $styles[1] as $style ) {
			preg_match_all( '/url\(\s*["\']?([^"\')\s]+)/i', $style, $matches );
			$urls = array_merge( $urls, $matches[1] );
		}

		$hosts = [];

		foreach ( $urls as $url ) {
			$url = html_entity_decode( $url, ENT_QUOTES );

			if ( ! preg_match( '#^(https?:)?//#i', $url ) ) {
				continue;
			}

			$host = wp_parse_url( set_url_scheme( $url ), PHP_URL_HOST );

			if ( is_string( $host ) && $host !== '' ) {
				$hosts[] = strtolower( $host );
			}
		}

		return array_values( array_unique( $hosts ) );
	}

	/**
	 * @return array
	 */
	public static function get_stored_hosts() {
		$hosts = get_option( Settings::OMGF_PRO_SMART_OPTIMIZE_TRUSTED_HOSTS, [] );

		return is_array( $hosts ) ? array_values( array_filter( $hosts, 'is_string' ) ) : [];
	}

	/**
	 * Hosts approved by an administrator, either by trusting them on the Dashboard, or automatically, because an
	 * administrator's visit reported a preload from it.
	 *
	 * @return array [ host => [ 'source' => 'admin'|'manual', 'time' => int ] ]
	 */
	public static function get_approved_hosts() {
		return self::get_host_option( Settings::OMGF_PRO_SMART_OPTIMIZE_APPROVED_HOSTS );
	}
	
	/**
	 * Hosts of preloads reported by visitors, which aren't trusted and await an administrator's approval.
	 *
	 * @return array [ host => [ 'first_seen' => int, 'last_seen' => int ] ]
	 */
	public static function get_pending_hosts() {
		return self::get_host_option( Settings::OMGF_PRO_SMART_OPTIMIZE_PENDING_HOSTS );
	}
	
	/**
	 * @return array [ host => [ 'time' => int ] ]
	 */
	public static function get_ignored_hosts() {
		return self::get_host_option( Settings::OMGF_PRO_SMART_OPTIMIZE_IGNORED_HOSTS );
	}
	
	/**
	 * Approve $host, i.e. trust preloads reported by visitors from it.
	 *
	 * @action omgf_pro_smart_optimize_host_approved Existing results are deleted, so pages are analyzed again.
	 *
	 * @param string $host
	 * @param string $source 'admin' (reported by an administrator's visit) or 'manual' (trusted on the Dashboard).
	 *
	 * @return bool Whether $host was approved.
	 */
	public static function approve( $host, $source = 'manual' ) {
		$host     = self::normalize_host( $host );
		$approved = self::get_approved_hosts();
		
		if ( ! self::is_valid_host( $host ) || isset( $approved[ $host ] ) || count( $approved ) >= self::MAX_APPROVED_HOSTS ) {
			return false;
		}

		// A host ignored by an administrator is only approved when it's explicitly trusted.
		if ( $source === 'admin' && isset( self::get_ignored_hosts()[ $host ] ) ) {
			return false;
		}
		
		$approved[ $host ] = [ 'source' => $source === 'admin' ? 'admin' : 'manual', 'time' => time() ];
		
		update_option( Settings::OMGF_PRO_SMART_OPTIMIZE_APPROVED_HOSTS, $approved, false );
		self::remove_from( Settings::OMGF_PRO_SMART_OPTIMIZE_PENDING_HOSTS, $host );
		self::remove_from( Settings::OMGF_PRO_SMART_OPTIMIZE_IGNORED_HOSTS, $host );
		
		do_action( 'omgf_pro_smart_optimize_host_approved', $host );
		
		return true;
	}
	
	/**
	 * Remove $host from the approved hosts.
	 *
	 * @action omgf_pro_smart_optimize_host_revoked Existing results are deleted, so pages are analyzed again.
	 *
	 * @param string $host
	 *
	 * @return bool
	 */
	public static function revoke( $host ) {
		$host = self::normalize_host( $host );
		
		if ( ! self::remove_from( Settings::OMGF_PRO_SMART_OPTIMIZE_APPROVED_HOSTS, $host ) ) {
			return false;
		}
		
		do_action( 'omgf_pro_smart_optimize_host_revoked', $host );
		
		return true;
	}
	
	/**
	 * Ignore $host, i.e. don't ask for approval of it again.
	 *
	 * @param string $host
	 *
	 * @return bool
	 */
	public static function ignore( $host ) {
		$host    = self::normalize_host( $host );
		$ignored = self::get_ignored_hosts();
		
		if ( ! self::is_valid_host( $host ) ) {
			return false; // @codeCoverageIgnore
		}
		
		if ( ! isset( $ignored[ $host ] ) ) {
			/**
			 * Ignoring a host should always work, so if the limit is reached, the host ignored the longest ago makes room.
			 */
			if ( count( $ignored ) >= self::MAX_APPROVED_HOSTS ) {
				uasort(
					$ignored,
					function ( $a, $b ) {
						return ( $a['time'] ?? 0 ) <=> ( $b['time'] ?? 0 );
					}
				);
				
				$ignored = array_slice( $ignored, count( $ignored ) - self::MAX_APPROVED_HOSTS + 1, null, true );
			}
			
			$ignored[ $host ] = [ 'time' => time() ];
			
			update_option( Settings::OMGF_PRO_SMART_OPTIMIZE_IGNORED_HOSTS, $ignored, false );
		}
		
		// Only once the host is recorded as ignored, so it can't be queued again.
		self::remove_from( Settings::OMGF_PRO_SMART_OPTIMIZE_PENDING_HOSTS, $host );
		
		return true;
	}
	
	/**
	 * Add $host to the hosts awaiting approval, unless it's trusted or ignored. To limit writes to the database, a
	 * host is updated at most once per hour.
	 *
	 * @param string $host
	 *
	 * @return void
	 */
	public static function add_pending( $host ) {
		$host = self::normalize_host( $host );
		
		if ( ! self::is_valid_host( $host ) || self::is_trusted( $host ) || isset( self::get_ignored_hosts()[ $host ] ) ) {
			return;
		}
		
		$pending = self::get_pending_hosts();
		$now     = time();
		
		if ( isset( $pending[ $host ] ) ) {
			if ( $now - (int) ( $pending[ $host ]['last_seen'] ?? 0 ) < HOUR_IN_SECONDS ) {
				return;
			}
			
			$pending[ $host ]['last_seen'] = $now;
		} elseif ( count( $pending ) < self::MAX_PENDING_HOSTS ) {
			$pending[ $host ] = [ 'first_seen' => $now, 'last_seen' => $now ];
		} else {
			return;
		}
		
		update_option( Settings::OMGF_PRO_SMART_OPTIMIZE_PENDING_HOSTS, $pending, false );
	}
	
	/**
	 * Checks if $host is a syntactically valid (lowercase) domain name.
	 *
	 * @param string $host
	 *
	 * @return bool
	 */
	public static function is_valid_host( $host ) {
		return is_string( $host ) &&
		       (bool) preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/', $host );
	}
	
	/**
	 * @param string $host
	 *
	 * @return string
	 */
	private static function normalize_host( $host ) {
		return is_string( $host ) ? strtolower( rtrim( trim( $host ), '.' ) ) : '';
	}
	
	/**
	 * @param string $option_name
	 *
	 * @return array
	 */
	private static function get_host_option( $option_name ) {
		$hosts = get_option( $option_name, [] );
		
		if ( ! is_array( $hosts ) ) {
			return []; // @codeCoverageIgnore
		}
		
		return array_filter(
			$hosts,
			function ( $meta, $host ) {
				return is_array( $meta ) && self::is_valid_host( $host );
			},
			ARRAY_FILTER_USE_BOTH
		);
	}
	
	/**
	 * @param string $option_name
	 * @param string $host
	 *
	 * @return bool Whether $host was removed.
	 */
	private static function remove_from( $option_name, $host ) {
		$hosts = self::get_host_option( $option_name );
		
		if ( ! isset( $hosts[ $host ] ) ) {
			return false;
		}
		
		unset( $hosts[ $host ] );
		
		update_option( $option_name, $hosts, false );
		
		return true;
	}
	
	/**
	 * All trusted hosts: this site's hosts, OMGF's upload URL's host (which might be a CDN), the stored hosts and the
	 * approved hosts.
	 *
	 * @filter omgf_pro_smart_optimize_trusted_preload_hosts
	 *
	 * @return array
	 */
	public static function get_hosts() {
		$hosts = array_merge(
			[
				wp_parse_url( home_url(), PHP_URL_HOST ),
				wp_parse_url( site_url(), PHP_URL_HOST ),
				wp_parse_url( content_url(), PHP_URL_HOST ),
				wp_parse_url( set_url_scheme( Wrapper::get_upload_url() ), PHP_URL_HOST ),
			],
			self::get_stored_hosts(),
			array_keys( self::get_approved_hosts() )
		);

		/**
		 * Hosts of fonts which visitors are allowed to report as missing preloads.
		 */
		$hosts = apply_filters( 'omgf_pro_smart_optimize_trusted_preload_hosts', $hosts );

		return array_values( array_unique( array_map( 'strtolower', array_filter( (array) $hosts, 'is_string' ) ) ) );
	}

	/**
	 * Checks if $host is a trusted host, or shares its registrable domain with one, e.g. a font loaded from
	 * ka-f.fontawesome.com by a stylesheet loaded from kit.fontawesome.com. On domains where anyone can get their own
	 * subdomain (e.g. cloudfront.net), only an exact match is trusted.
	 *
	 * @param string $host
	 *
	 * @return bool
	 */
	public static function is_trusted( $host ) {
		if ( ! is_string( $host ) || $host === '' ) {
			return false;
		}

		$host  = strtolower( rtrim( $host, '.' ) );
		$hosts = self::get_hosts();

		if ( in_array( $host, $hosts, true ) ) {
			return true;
		}

		$domain = self::get_registrable_domain( $host );

		/**
		 * @filter omgf_pro_smart_optimize_multi_tenant_domains
		 */
		if ( in_array( $domain, (array) apply_filters( 'omgf_pro_smart_optimize_multi_tenant_domains', self::MULTI_TENANT_DOMAINS ), true ) ) {
			return false;
		}

		foreach ( $hosts as $trusted_host ) {
			if ( $domain === self::get_registrable_domain( $trusted_host ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A (conservative) approximation of the registrable domain of $host, e.g. fontawesome.com for
	 * ka-f.fontawesome.com and example.co.uk for www.example.co.uk. IP addresses are returned as-is.
	 *
	 * @param string $host
	 *
	 * @return string
	 */
	public static function get_registrable_domain( $host ) {
		$host = strtolower( rtrim( $host, '.' ) );

		if ( filter_var( trim( $host, '[]' ), FILTER_VALIDATE_IP ) ) {
			return $host;
		}

		$labels = explode( '.', $host );
		$count  = count( $labels );

		if ( $count <= 2 ) {
			return $host;
		}

		/**
		 * Second-level labels commonly used under country code TLDs, e.g. co.uk, com.au, gov.br.
		 */
		$is_cc_sld = strlen( $labels[ $count - 1 ] ) === 2 &&
		             in_array( $labels[ $count - 2 ], [ 'co', 'com', 'net', 'org', 'gov', 'ac', 'edu', 'or', 'ne', 'go' ], true );

		return implode( '.', array_slice( $labels, $is_cc_sld ? -3 : -2 ) );
	}
}
