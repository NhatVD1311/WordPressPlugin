<?php
/**
 * @since     v5.0.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\Frontend\SmartOptimize;

class Compatibility {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'omgf_pro_smart_optimize_results_stored', [ $this, 'flush_page_cache' ] );
		add_action( 'omgf_pro_smart_optimize_entry_deleted', [ $this, 'flush_page_cache' ] );
		add_filter( 'omgf_pro_smart_optimize_excluded', [ $this, 'exclude_non_cacheable_pages' ] );
	}
	
	/**
	 * Exclude pages which shouldn't be page cached from Smart Optimize, i.e. pages defining DONOTCACHEPAGE: the constant
	 * (most) caching plugins respect, which plugins define for personal pages, e.g. WooCommerce's cart, checkout and
	 * account pages (and their endpoints, e.g. order received pages), or LifterLMS' and SureCart's pages.
	 *
	 * Smart Optimize's decisions are made at different moments: whether the page is analyzed, and its preloads and
	 * Async stylesheets, are decided while enqueueing scripts/styles in wp_head(), while the rest of its results are
	 * applied when the output buffer is processed, after the page is rendered. So, DONOTCACHEPAGE must be defined before
	 * wp_head(), e.g. in the wp or template_redirect action, like WooCommerce does (@see \WC_Cache_Helper::prevent_caching()).
	 * If it's only defined while the content is rendered (e.g. by a shortcode), the page might still be analyzed and get
	 * its preloads and Async stylesheets, but no unused fonts are unloaded from its other stylesheets.
	 *
	 * @since  v5.3.2
	 *
	 * @filter omgf_pro_smart_optimize_excluded
	 *
	 * @see    \OMGF\Pro\Helper::is_smart_optimize_excluded()
	 *
	 * @param bool $excluded
	 *
	 * @return bool
	 */
	public function exclude_non_cacheable_pages( $excluded ) {
		return $excluded || $this->is_donotcachepage();
	}
	
	/**
	 * @since v5.3.2
	 *
	 * @return bool
	 */
	protected function is_donotcachepage() {
		return defined( 'DONOTCACHEPAGE' ) && DONOTCACHEPAGE;
	}
	
	/**
	 * Flush the page cache for the given path in the most popular caching plugins.
	 *
	 * Wherever the caching plugin exposes a URL-based purge mechanism, we key the purge on
	 * $url (built directly from $path) rather than on a resolved post-ID. @see url_to_postid()
	 * returns 0 for anything not backed by a single post/page object - taxonomy archives,
	 * the blog homepage, WooCommerce product/category pages, plain permalinks, etc. - which
	 * previously caused those purges to silently no-op and let Smart Optimize's detection
	 * script re-run on every page load. A $post_id is only computed and used for the two
	 * plugins (Cloudflare, WP Fastest Cache) that offer no URL-based purge in their installed
	 * source; those branches remain gated on $post_id, so they degrade to a no-op (rather than
	 * being called with 0) when the path doesn't resolve to a single post.
	 *
	 * @since              v5.2.9 Switched every plugin with a verified URL-based purge to key on $url.
	 *
	 * @codeCoverageIgnore Because it depends on 3rd party plugins.
	 *
	 * @param string $path
	 *
	 * @return void
	 */
	public function flush_page_cache( string $path ) {
		$url     = home_url( $path );
		$post_id = url_to_postid( $url );
		
		// Cloudflare: requires OMGF 6.3.1 or higher.
		if ( defined( 'CLOUDFLARE_PLUGIN_DIR' ) && $post_id ) {
			do_action( 'omgf_cloudflare_purge_url', $post_id );
		}
		
		// FlyingPress
		if ( has_action( 'flying_press_purge_url' ) ) {
			do_action( 'flying_press_purge_url', $url );
		}
		
		// Kinsta
		if ( defined( 'KINSTAMU_VERSION' ) ) {
			wp_remote_get(
				home_url() . '/kinsta-clear-cache/' . ltrim( $path, '/' ),
				[
					'timeout'  => 5,
					'blocking' => false,
				]
			);
		}
		
		// LiteSpeed Cache
		if ( class_exists( '\LiteSpeed\Purge' ) ) {
			$this->purge_litespeed_url( $url );
		}
		
		// SiteGround Optimizer
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache( $url );
		}
		
		// W3 Total Cache
		if ( function_exists( 'w3tc_flush_url' ) ) {
			w3tc_flush_url( $url );
		}
		
		// WP Fastest Cache
		if ( function_exists( 'wpfc_clear_post_cache_by_id' ) && $post_id ) {
			wpfc_clear_post_cache_by_id( $post_id );
		}
		
		// WP-Optimize
		if ( class_exists( 'WPO_Page_Cache' ) && method_exists( 'WPO_Page_Cache', 'delete_cache_by_url' ) ) {
			\WPO_Page_Cache::delete_cache_by_url( $url );
		}
		
		// WP Rocket
		if ( function_exists( 'rocket_clean_files' ) ) {
			rocket_clean_files( $url );
		}
		
		// WP Super Cache
		if ( function_exists( 'wpsc_delete_url_cache' ) ) {
			wpsc_delete_url_cache( $url );
		}
	}
	
	/**
	 * Purge $url from LiteSpeed Cache, without adding an admin notice.
	 *
	 * LiteSpeed Cache's litespeed_purge_url action adds a one-time "Purge url <path>" admin notice for each purged URL.
	 * Because Smart Optimize purges every page it analyzes, those notices piled up to one per page (e.g. after Smart
	 * Optimize's results were emptied and the whole site was analyzed again), suggesting the user had to purge each
	 * page manually. Purge::purge_url()'s third parameter ($quite) purges the URL silently instead.
	 *
	 * @since v5.3.2
	 *
	 * @param string $url
	 *
	 * @return void
	 */
	public function purge_litespeed_url( $url ) {
		if ( method_exists( '\LiteSpeed\Purge', 'cls' ) && method_exists( '\LiteSpeed\Purge', 'purge_url' ) ) {
			\LiteSpeed\Purge::cls()->purge_url( $url, false, true );
			
			return;
		}
		
		// Fallback for LiteSpeed Cache versions without Purge::cls() (< v4.0). @codeCoverageIgnore
		do_action( 'litespeed_purge_url', $url ); // @codeCoverageIgnore
	}
}
