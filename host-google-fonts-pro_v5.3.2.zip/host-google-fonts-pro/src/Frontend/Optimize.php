<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend;

use OMGF\Pro\Admin\Notice;
use OMGF\Pro\Admin\Settings;
use OMGF\Pro\FallbackFontStacks;
use OMGF\Pro\Frontend\MagicFallbacks\FallbackFontStack;
use OMGF\Pro\Helper;
use OMGF\Pro\Helper as OMGF_Pro;
use OMGF\Pro\UnicodeRanges;
use OMGF\Pro\Wrapper;

class Optimize {
	const FONT_DISPLAY_ATTRIBUTE = 'font-display: %s;';
	
	/**
	 * Is the omgf_optimize GET-parameter set?
	 *
	 * @var bool
	 */
	public $force_optimize = false;
	
	/**
	 * @var bool
	 * @since v3.7.0 Is Auto Config enabled?
	 */
	public $auto_config = false;
	
	/**
	 * @var Optimize\MaterialIcons $material_icons
	 */
	private $material_icons;
	
	/**
	 * Build Class.
	 */
	public function __construct( $init = true ) {
		$this->force_optimize = Wrapper::is_running_optimize();
		$this->auto_config    = OMGF_Pro::run_auto_config();
		
		if ( $init ) {
			$this->init();
		}
	}
	
	/**
	 * Actions & Hooks
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'omgf_frontend_process_before_ob_start', [ $this, 'maybe_init' ] );
		add_filter( 'omgf_processed_html', [ $this, 'process' ], 10, 2 );
	}
	
	/**
	 * Load JS snippet inline to block Async Google Fonts.
	 *
	 * @codeCoverageIgnore Since this is all Frontend stuff.
	 */
	public function block_async_google_fonts() {
		$cache_keys = $this->get_async_cache_keys( true );
		
		if ( empty( $cache_keys ) ) {
			return;
		}
		
		$suffix = $this->get_script_suffix();
		$script = file_get_contents( OMGF_PRO_PLUGIN_DIR . "assets/js/remove-async-gfonts$suffix.js" );
		
		if ( $script === false ) {
			$script = '';
		}
		
		// If there's no suffix, that means Debug Mode is enabled, and we want the unencoded script.
		if ( ! $suffix ) {
			wp_print_inline_script_tag( $script, [ 'id' => 'omgf-pro-remove-async-google-fonts' ] );
			
			return;
		}
		
		/**
		 * Obfuscate mentions of the Google fonts API in the HTML using hex escapes to avoid scrapers.
		 *
		 * @since v6.3.4 because the base64 "trick" no longer works in WP 7.0.
		 */
		$script = str_replace(
			[
				'fonts.googleapis.com',
				'fonts.gstatic.com',
				'ajax.googleapis.com',
			],
			[
				'\x66\x6f\x6e\x74\x73\x2e\x67\x6f\x6f\x67\x6c\x65\x61\x70\x69\x73\x2e\x63\x6f\x6d',
				'\x66\x6f\x6e\x74\x73\x2e\x67\x73\x74\x61\x74\x69\x63\x2e\x63\x6f\x6d',
				'\x61\x6a\x61\x78\x2e\x67\x6f\x6f\x67\x6c\x65\x61\x70\x69\x73\x2e\x63\x6f\x6d',
			],
			$script
		);
		
		wp_print_inline_script_tag( $script, [ 'id' => 'omgf-pro-remove-async-google-fonts-obfuscated' ] );
	}
	
	/**
	 * @since              v4.2.0
	 *
	 * @return array
	 *
	 * @codeCoverageIgnore Since this all Frontend stuff.
	 */
	private function get_async_cache_keys( $include_replaced = false ) {
		$replaces             = Helper::replaced_stylesheets();
		$unloaded_stylesheets = Wrapper::unloaded_stylesheets();
		$cache_keys           = [];
		
		foreach ( Wrapper::cache_keys() as $key ) {
			$is_replaced = ! empty( array_filter( $replaces[ $key ] ?? [], function ( $value ) {
				return $value === 'on';
			} ) );
			
			if ( ! str_starts_with( $key, 'omgf-pro-async-fonts' ) ) {
				continue;
			}
			
			if ( in_array( $key, $unloaded_stylesheets, true ) && ! ( $include_replaced && $is_replaced ) ) {
				continue;
			}
			
			$cache_keys[] = $key;
		}
		
		return $cache_keys;
	}
	
	/**
	 * Checks if debugging is enabled for local machines.
	 *
	 * @return string .min | ''
	 *
	 * @codeCoverageIgnore
	 */
	public function get_script_suffix() {
		return Wrapper::get_option( 'debug' ) === 'on' ? '' : '.min';
	}
	
	/**
	 * Invokes OMGF's default HTML processor. Used in Pro for Material Icons support.
	 *
	 * @since v5.2.11 Elements matched by $regex are validated by $validate before they're processed, so only
	 *                elements which actually point at the API are processed. Requires OMGF v6.3.11, which parses
	 *                an element's attribute values. On older versions nothing is processed.
	 *
	 * @param string                 $html      Valid HTML
	 * @param \OMGF\Frontend\Process $processor
	 * @param string                 $regex     Matches the elements to be processed.
	 * @param callable|null          $validate  Receives the (sanitized) attribute values of a matched element and
	 *                                          returns true if the element should be processed.
	 */
	public function invoke_processor( $html, $processor, $regex, $validate = null ) {
		preg_match_all( $regex, $html, $links );

		if ( empty( $links[0] ) ) {
			return $html; // @codeCoverageIgnore
		}

		if ( is_callable( $validate ) ) {
			if ( ! method_exists( $processor, 'get_element_urls' ) ) {
				return $html; // @codeCoverageIgnore
			}

			$links[0] = array_values(
				array_filter(
					$links[0],
					function ( $link ) use ( $processor, $validate ) {
						return (bool) $validate( $processor->get_element_urls( $link ) );
					}
				)
			);

			if ( empty( $links[0] ) ) {
				return $html;
			}
		}

		$google_fonts   = $processor->build_fonts_set( $links[0] );
		$search_replace = $processor->build_search_replace( $google_fonts );
		
		if ( empty( $search_replace['search'] ) || empty( $search_replace['replace'] ) ) {
			return $html; // @codeCoverageIgnore
		}
		
		return str_replace( $search_replace['search'], $search_replace['replace'], $html );
	}
	
	/**
	 * Conditionally enqueues Google Fonts stylesheets, blocked by the 'Remove Async Google Fonts' setting.
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore Since this is all frontend stuff.
	 */
	public function maybe_enqueue_async_fonts() {
		$cache_keys = $this->get_async_cache_keys();
		
		if ( empty( $cache_keys ) ) {
			return;
		}
		
		$timestamp = Wrapper::get_option( 'omgf_cache_timestamp' );
		
		foreach ( $cache_keys as $cache_key ) {
			wp_enqueue_style( $cache_key, Wrapper::get_upload_url() . '/' . $cache_key . '/' . $cache_key . '.css', [], $timestamp );
		}
	}
	
	/**
	 * All listed methods are hooked to actions/filters, which should only be triggered if OMGF
	 * is actually allowed to run.
	 *
	 * @since  v3.6.6
	 * @action omgf_frontend_process_before_ob_start
	 * @return void
	 *
	 * @codeCoverageIgnore
	 */
	public function maybe_init() {
		add_action( 'wp_head', [ $this, 'block_async_google_fonts' ], 1 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_async_fonts' ] );
		
		new Optimize\Compatibility();
		$this->material_icons = new Optimize\MaterialIcons();
	}
	
	/**
	 * Normalize $url.
	 *
	 * @since v4.2.0
	 *
	 * @param string $url
	 *
	 * @return string
	 */
	protected function normalize_url( string $url ) {
		/**
		 * Fix for protocol-relative URLs.
		 */
		if ( str_starts_with( $url, '//' ) ) {
			$url = ( is_ssl() ? 'https:' : 'http:' ) . $url; // @codeCoverageIgnore
		}
		
		/**
		 * Check if the URL is relative and fix it.
		 */
		if ( str_starts_with( $url, '/' ) && ! str_starts_with( $url, '//' ) ) {
			$url = get_home_url() . $url; // @codeCoverageIgnore
		}
		
		return $url;
	}

	/**
	 * Resolves dot segments (i.e., "./" and "../") in the path of $url, just like browsers do before requesting it.
	 *
	 * E.g., plugins_url( '../assets/css/style.css', __FILE__ ) results in https://example.com/wp-content/plugins/plugin/includes/../assets/css/style.css,
	 * which browsers request as https://example.com/wp-content/plugins/plugin/assets/css/style.css. Left as-is, the dot segments
	 * end up in the path of the cached copy, and wp_mkdir_p() refuses to create any directory containing "../".
	 *
	 * The query string and fragment (if any) are left untouched. A path can never be resolved beyond its root.
	 *
	 * @see   https://www.rfc-editor.org/rfc/rfc3986#section-5.2.4
	 * @since v5.3.2
	 *
	 * @param string $url
	 *
	 * @return string
	 */
	protected function remove_dot_segments( $url ) {
		$length = strcspn( $url, '?#' );
		$base   = substr( $url, 0, $length );
		$suffix = substr( $url, $length );
		
		if ( ! str_contains( $base, '/.' ) ) {
			return $url;
		}
		
		$path = wp_parse_url( $base, PHP_URL_PATH );
		
		if ( ! is_string( $path ) || $path === '' || ! str_ends_with( $base, $path ) ) {
			return $url; // @codeCoverageIgnore
		}
		
		$segments = explode( '/', $path );
		$last     = end( $segments );
		$output   = [];
		
		foreach ( $segments as $segment ) {
			if ( $segment === '.' ) {
				continue;
			}
			
			if ( $segment === '..' ) {
				// The first (empty) segment represents the root, which we can't go beyond.
				if ( count( $output ) > 1 ) {
					array_pop( $output );
				}
				
				continue;
			}
			
			$output[] = $segment;
		}
		
		// A path ending in a dot segment refers to a directory, so it should keep its trailing slash.
		if ( $last === '.' || $last === '..' ) {
			$output[] = '';
		}
		
		return substr( $base, 0, strlen( $base ) - strlen( $path ) ) . implode( '/', $output ) . $suffix;
	}

	/**
	 * Strips characters from a URL which browsers ignore when requesting it.
	 *
	 * HTML allows line breaks (and tabs) inside attribute values, e.g., to keep a long URL readable in the
	 * editor. Browsers remove those characters before requesting the URL, which means the stylesheet loads
	 * just fine, while the same URL would be rejected when used as-is in a HTTP request or file path.
	 *
	 * Note that a form feed is deliberately NOT stripped here, even though @see self::sanitize_css_url() does
	 * treat it as a line break. That's not an inconsistency: the two follow different specs. The URL parser
	 * removes tabs, carriage returns and line feeds and nothing else, so a form feed is part of the URL as far
	 * as a browser is concerned, and stripping it would mean we request a different URL than the browser does.
	 * CSS is the one which treats a form feed as a line break, and that's handled where CSS is parsed.
	 *
	 * @see   https://url.spec.whatwg.org/#concept-basic-url-parser (tab/newline removal)
	 * @since v5.2.10
	 *
	 * @param string $url
	 *
	 * @return string
	 */
	protected function sanitize_url( $url ) {
		return trim( str_replace( [ "\r", "\n", "\t" ], '', $url ) );
	}

	/**
	 * Same as @see self::sanitize_url(), for URLs found in CSS.
	 *
	 * A backslash followed by a line break is a line continuation inside a CSS string: it's valid CSS, and
	 * represents nothing at all, i.e., it's how a long @import statement can be spread over multiple lines.
	 * Those are removed first, i.e., before sanitize_url() removes the line breaks it knows about, because
	 * doing it the other way around leaves a stray backslash in the middle of the URL.
	 *
	 * CSS normalizes a carriage return, a form feed and a CRLF pair to a single line feed before it starts
	 * tokenizing, which means all of them are a line break as far as a stylesheet is concerned.
	 *
	 * An unescaped line break is an unterminated string, which browsers don't load, so the @import matchers
	 * end a URL at any of them, form feed included. That's why sanitize_url() not stripping a form feed isn't
	 * a problem here: one can never reach this method to begin with.
	 *
	 * @see   https://drafts.csswg.org/css-syntax/#input-preprocessing (line break normalization)
	 * @see   https://drafts.csswg.org/css-syntax/#consume-string-token (escaped newlines)
	 * @since v5.2.10
	 *
	 * @param string $url
	 *
	 * @return string
	 */
	protected function sanitize_css_url( $url ) {
		return $this->sanitize_url( preg_replace( '/\\\\(?:\r\n|[\r\n\f])/', '', $url ) );
	}

	/**
	 * Core logic for optimizing stylesheet contents.
	 *
	 * @since v4.2.0
	 *
	 * @param string $url
	 * @param string $handle_prefix
	 * @param string $detection_setting
	 *
	 * @param string $contents
	 *
	 * @return string
	 */
	protected function optimize_stylesheet_contents( string $contents, string $url, string $handle_prefix, string $detection_setting ) {
		if ( $this->auto_config || ! empty( Wrapper::get_option( $detection_setting ) ) ) {
			$contents = $this->process_imports( $contents, "$handle_prefix-import" );
			$contents = $this->process_font_faces( $contents, "$handle_prefix-font-face" );
		}
		
		if ( $this->force_optimize || ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK ) ) || Helper::is_magic_fallbacks_enabled() ) {
			$contents = $this->process_fallback_font_stacks( $contents );
		}
		
		if ( $this->force_optimize || ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FORCE_FONT_DISPLAY ) ) ) {
			$contents = $this->process_force_font_display( $contents );
		}
		
		$contents = $this->maybe_convert_rel_url_to_abs( $contents, str_replace( [ 'http:', 'https:' ], '', $url ) );
		
		return apply_filters( 'omgf_pro_process_stylesheet_contents', $contents, $handle_prefix, $url );
	}
	
	/**
	 * Replaces all Google Fonts stylesheets found in @import statements with local copies.
	 *
	 * @param string $contents    A string of either valid HTML or CSS.
	 * @param string $handle_base The base to be used for building file cache and DB archive.
	 *
	 * @return string
	 * @throws \TypeError
	 */
	public function process_imports( $contents, $handle_base = 'inline-import' ) {
		/**
		 * @see          https://stackoverflow.com/a/27396794/4949411
		 * @since        v3.7.0 This matches with SSL, non-SSL and relative references to the Google Fonts API in the following syntax's:
		 *               - @import url('');
		 *               - @import url();
		 *               - @import '';
		 *               This does NOT match e.g. @import https://fonts.googleapis.com/css?etc; (i.e. no quotes) simply because I
		 *               can't imagine that that's valid CSS. If it is, we'll find out soon enough.
		 * @since v5.2.10 Allow whitespace (incl. line breaks) after @import and inside url(), and line continuations
		 *                (a backslash followed by a line break) inside the URL. All of those are valid CSS and loaded
		 *                by browsers, but weren't matched. A raw line break inside the URL is still not matched,
		 *                because that's an unterminated string, which browsers don't load either. CSS normalizes a
		 *                carriage return, a form feed and a CRLF pair to a single line feed, so all of them count
		 *                as a line break.
		 *                The URL can't contain a quote, a closing parenthesis or a raw line break, which is what
		 *                keeps the match confined to a single @import statement.
		 */
		preg_match_all(
			'/@import\s*(?:url\(\s*[\'"]?|[\'"])(?P<urls>(?:https?:)?\/\/fonts\.googleapis\.com\/(?:icon|css)(?:\\\\(?:\r\n|[\r\n\f])|[^\'")\r\n\f])*)[\'"]?\s*\)?\s*;/',
			$contents,
			$imports
		);
		
		$full_matches = apply_filters( 'omgf_pro_process_import_full_matches', $imports[0], $contents );
		$import_urls  = apply_filters( 'omgf_pro_process_import_urls', $imports['urls'], $contents );
		
		if ( empty( $import_urls ) ) {
			return $contents;
		}
		
		$search_replace = $this->build_import_search_replace( $full_matches, $import_urls, $handle_base );
		
		return str_replace( $search_replace['search'], $search_replace['replace'], $contents );
	}
	
	/**
	 * Build a processable Search/Replace array from @import statements.
	 *
	 * @param array  $full_matches Array of full matches.
	 * @param array  $url_matches  Array of partial matches.
	 * @param string $handle_base  The stylesheet handle.
	 *
	 * @return array
	 * @throws \TypeError
	 */
	private function build_import_search_replace( $full_matches, $url_matches, $handle_base = 'inline-import' ) {
		$search  = [];
		$replace = [];
		
		foreach ( $url_matches as $i => $url ) {
			/**
			 * $url is used for search/replace and should match the stylesheet verbatim, while the sanitized copy
			 * is used to request it, and to generate the handle, so insignificant whitespace doesn't change it.
			 *
			 * @since v5.2.10
			 */
			$request_url = $this->sanitize_css_url( $url );

			/**
			 * @since v3.6.0 Use string length to generate a unique-ish identifier for @import-ed stylesheets.
			 */
			$original_handle = "$handle_base-" . strlen( $request_url );
			$handle          = ! empty( Wrapper::get_cache_key( $original_handle ) ) ? Wrapper::get_cache_key( $original_handle ) : $original_handle;
			$cached_file     = Wrapper::get_upload_dir() . "/$handle/$handle.css";
			
			/**
			 * @since v3.6.0 Check if stylesheet is marked for unloading, before we do anything else.
			 */
			if ( in_array( $original_handle, Wrapper::unloaded_stylesheets(), true ) ) {
				$search[ $i ]  = $full_matches[ $i ];
				$replace[ $i ] = '';
				
				continue;
			}
			
			$cached_url = $this->run_optimization( $request_url, $handle, $original_handle, 'url', ! $this->force_optimize && file_exists( $cached_file ) );
			
			if ( is_wp_error( $cached_url ) || ! $cached_url ) {
				continue; // @codeCoverageIgnore
			}
			
			$search[ $i ]  = $url;
			$replace[ $i ] = $cached_url;
		}
		
		return [
			'search'  => $search,
			'replace' => $replace,
		];
	}
	
	/**
	 * Try-catch wrapper for the OMGF_Optimize class.
	 *
	 * @param mixed $url             Full Google Fonts API request, e.g. https://fonts.googleapis.com/css?family=Open+Sans:100,200,300,etc.
	 * @param mixed $cache_handle    Cache handle used for storing the fonts and generated stylesheet in OMGF's cache directory.
	 * @param mixed $original_handle Original cache handle (usually the stylesheet's ID)
	 * @param mixed $to_return
	 *
	 * @return string|array
	 * @throws \TypeError
	 *
	 * @codeCoverageIgnore
	 */
	public function run_optimization( $url, $cache_handle, $original_handle, $to_return = 'url', $return_early = false, $document = '' ) {
		if ( ! class_exists( '\OMGF\Optimize' ) ) {
			Notice::set_notice( __( 'OMGF not installed and/or activated.', 'omgf-pro' ) );
			
			return '';
		}
		
		try {
			$optimize = new \OMGF\Optimize( $url, $cache_handle, $original_handle, $to_return, $return_early, $document );
			$fonts    = $optimize->process();
		} catch ( \WpOrg\Requests\Exception $e ) {
			Notice::set_notice( $e );
			
			return '';
		}
		
		if ( is_wp_error( $fonts ) ) {
			/** @var \WP_Error $fonts */
			Notice::set_notice(
				__( 'Something went wrong while trying to fetch fonts', 'omgf-pro' ) . ' - ' . $fonts->get_error_code() . ': ' . $fonts->get_error_message(),
				'error',
				'omgf-pro-optimization-failed'
			);
		}
		
		return $fonts;
	}
	
	/**
	 * Process each Advanced Processing option.
	 *
	 * @param string                 $html      Valid HTML.
	 * @param \OMGF\Frontend\Process $processor No need to check dependencies here, because this function is only triggered if
	 *                                          OMGF is active.
	 *
	 * @filter omgf_processed_html
	 * @return string
	 *
	 * @throws \TypeError
	 */
	public function process( $html, $processor ) {
		$compare = $html;
		
		// Inline Styles
		if ( $this->should_run( Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES ) ) {
			$inline_styles = new Optimize\InlineStyles();
			$html          = $inline_styles->optimize( $html );
			
			if ( $this->auto_config && $compare !== $html ) {
				$compare = $html;
				
				Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES, 'on' );
			}
		}
		
		// Local Stylesheets
		if ( $this->should_run( Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS ) ) {
			$local_stylesheets = new Optimize\LocalStylesheets();
			$html              = $local_stylesheets->optimize( $html );
			
			if ( $this->auto_config && $compare !== $html ) {
				$compare = $html;
				
				Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS, 'on' );
			}
		}
		
		// WebFont Loader
		if ( $this->auto_config || ! empty( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER ) ) ) {
			$webfont_loader = new Optimize\WebfontLoader();
			$html           = $webfont_loader->optimize( $html );
			
			if ( $this->auto_config && $compare !== $html ) {
				$compare = $html;
				
				Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER, 'on' );
			}
		}
		
		/**
		 * Material Icons detection must always run to ensure both inline and link patterns are detected.
		 *
		 * This prevents false negatives and ensures other stylesheet optimizers that depend on these
		 * patterns function correctly. If any changes are made to the HTML during this process, the
		 * detection setting is automatically toggled to 'on' to ensure consistent behavior.
		 *
		 * @see   Optimize\MaterialIcons::optimize()
		 *
		 * If ${html} is modified, this triggers Wrapper::update_option() with
		 * Settings::OMF_DETECTION_SETTING_PROCESS_MATERIAL_ICONS.
		 *
		 * @since v4.0.0
		 */
		if ( ! $this->material_icons ) {
			$this->material_icons = new Optimize\MaterialIcons();
		}
		
		$html = $this->material_icons->optimize( $html, $processor );
		
		if ( $compare !== $html ) {
			$compare = $html;
			
			Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_MATERIAL_ICONS, 'on' );
		}
		
		// External Stylesheets
		if ( $this->should_run( Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS ) ) {
			$external_stylesheets = new Optimize\ExternalStylesheets();
			$html                 = $external_stylesheets->optimize( $html );
			
			if ( $this->auto_config && $compare !== $html ) {
				Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS, 'on' );
			}
		}
		
		/**
		 * Async Stylesheets
		 *
		 * This doesn't follow the same logic as the others, mostly because it can't be parsed server-side.
		 * So, this part only runs when Auto Config is enabled for this request.
		 *
		 * This option is enabled by @see Filters::process_async_google_fonts() when the frontend JS script detects Google Fonts.
		 */
		if ( $this->auto_config && ! empty ( Wrapper::get_option( Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS ) ) ) {
			$async_stylesheets = new Optimize\AsyncStylesheets();
			$async_stylesheets->optimize();
		}
		
		return $html;
	}
	
	/**
	 * Detection Settings that involve editing/caching non-Google Fonts stylesheets, i.e. stylesheets that
	 * contain other CSS than just Google Fonts, should also run if Fallback Font Stacks or Force Font Display
	 * are selected. This is a shorthand.
	 *
	 * @since v5.3.2 Also if Magic Fallbacks is enabled, because it works without Smart Optimize since v5.2.2, and its
	 *               fallbacks are added to the font-family declarations in these stylesheets.
	 *
	 * @param string $detection_setting The setting used to detect whether the process should run.
	 *
	 * @return bool True if the process should run, false otherwise.
	 */
	private function should_run( $detection_setting ) {
		return $this->auto_config ||
		       ! empty( Wrapper::get_option( $detection_setting ) ) ||
		       ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FORCE_FONT_DISPLAY ) ) ||
		       ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK ) ) ||
		       ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) ||
		       Helper::is_magic_fallbacks_enabled();
	}
	
	/**
	 * Process inline @font-face statements.
	 *
	 * @param string $contents    A string of either valid HTML or CSS.
	 * @param string $base_handle Default: 'inline-font-face'
	 *
	 * @return string
	 * @throws \TypeError
	 */
	public function process_font_faces( $contents, $base_handle = 'inline-font-face' ) {
		/**
		 * TODO: [OP-52] Figure out a regex (without catastrophic backtracking) which only retrieves @font-face
		 *       statements containing fonts.gstatic.com.
		 */
		preg_match_all( '/@font-face[\s]*?{.*?}/si', $contents, $font_faces );
		
		// No @font-face statements found.
		if ( empty( $font_faces[0] ) ) {
			return $contents;
		}
		
		$wp_font_manager_fonts = $this->get_theme_local_fonts( $contents );
		
		/**
		 * @since v3.7.1 Make sure we're hitting the domain (not a subfolder generated by some plugins)
		 */
		$font_faces = array_filter(
			$font_faces[0],
			function ( $value ) use ( $wp_font_manager_fonts ) {
				$value = trim( $value );
				
				return str_contains( $value, 'fonts.gstatic.com' ) ||
				       str_contains( $value, 'fonts.wp.com' ) ||
				       str_contains( $value, 'fonts.bunny.net' ) ||
				       ( ! empty( $wp_font_manager_fonts ) && str_contains( $wp_font_manager_fonts, $value ) );
			}
		);
		
		if ( empty( $font_faces ) ) {
			return $contents;
		}
		
		$families       = $this->convert_font_faces( $font_faces );
		$search_replace = $this->build_font_face_search_replace( $contents, $font_faces, $families, $base_handle );
		
		return str_replace( $search_replace['search'], $search_replace['replace'], $contents );
	}
	
	/**
	 * Some themes add unoptimized versions of local fonts, this method extracts them, so OMGF Pro can handle them either way.
	 *
	 * @param string $contents
	 *
	 * @return string
	 */
	public function get_theme_local_fonts( $contents ) {
		preg_match_all( '/<style[^>]+(?:id|class)=[\'"](wp-fonts-local|kirki-inline-styles)[\'"][^>]*>.*?<\/style>/is', $contents, $wp_font_manager_fonts );
		
		if ( ! empty( $wp_font_manager_fonts[0] ) ) {
			$wp_font_manager_fonts = $wp_font_manager_fonts[0];
			
			return implode( '', $wp_font_manager_fonts );
		}
		
		return '';
	}
	
	/**
	 * Converts @font-face statements to Array. If a unicode-range is defined, it will map it to an identifier, e.g. "latin-ext"
	 *
	 * @param array $font_faces
	 *
	 * @return array [ font_family ] [ variants => [ variant_id => font_src ] , subsets ]
	 */
	private function convert_font_faces( $font_faces ) {
		$families = [];
		
		$font_faces = $this->validate_font_weights( $font_faces );
		
		/**
		 * Build variants object.
		 */
		foreach ( $font_faces as $i => $font_face ) {
			preg_match( '/font-family:[\s]*[\'"]?(?P<font_family>[^\'"]*?)[\'"]?[\s]*;/', $font_face, $font_family );
			preg_match( '/font-style:[\s]*[\'"]?(?P<font_style>[^\'"]*?)[\'"]?[\s]*;/', $font_face, $font_style );
			preg_match( '/font-weight:[\s]*[\'"]?(?P<font_weight>[^\'"]*?)[\'"]?[\s]*;/', $font_face, $font_weight );
			preg_match( '/src:.*?url\([\'"]?(?P<url>[^\'"]*?)[\'"]?[\s]*\)/', $font_face, $font_src );
			preg_match( '/unicode-range:[\s]*(?P<range>.*?)?[\s]*;/', $font_face, $range );
			
			$font_family = trim( $font_family['font_family'] ?? '', '"\'' );
			$font_style  = isset( $font_style['font_style'] ) && $font_style['font_style'] !== 'normal' ? $font_style['font_style'] : '';
			$font_weight = $font_weight['font_weight'] ?? '400';
			$font_src    = $font_src['url'] ?? '';
			$range       = $range['range'] ?? '';
			$subset      = array_search( str_replace( ' ', '', $range ), UnicodeRanges::MAP, true );
			
			/**
			 * @since v3.11.0 Improved the way the array is built. We no longer use a comma-separated list, and instead we build an array
			 *                with each subset containing a sub-array of weight/style => src mappings.
			 */
			if ( ! $subset ) {
				$families[ $font_family ]['variants']['default'][ (string) $font_weight . $font_style ] = $font_src;
			} else {
				$families[ $font_family ]['variants'][ $subset ][ (string) $font_weight . $font_style ] = $font_src;
			}
			
			if ( $subset && ! in_array( $subset, $families[ $font_family ]['subsets'] ?? [], true ) ) {
				$families[ $font_family ]['subsets'][] = $subset;
			}
		}
		
		return $families;
	}
	
	/**
	 * Check if an @font-face statement contains multiple font-weights and corrects the font-faces array.
	 *
	 * @param $font_faces
	 *
	 * @return mixed
	 */
	private function validate_font_weights( $font_faces, $rewrite = true ) {
		$result = [];
		
		foreach ( $font_faces as $font_face ) {
			preg_match( '/font-weight:[\s]*[\'\"]?(?P<font_weight>[^\'\"]*?)[\'\"]?[\s]*;/', $font_face, $match );
			$font_weight = $match['font_weight'] ?? '400';
			
			// If the font weight attribute value contains spaces, this means it's a variable font
			if ( str_contains( $font_weight, ' ' ) ) {
				$font_weights = preg_split( '/\s+/', trim( $font_weight ) );
				
				if ( $rewrite ) {
					// Expand into separate @font-face rules with individual weights
					foreach ( $font_weights as $single_font_weight ) {
						$result[] = str_replace( $font_weight, $single_font_weight, $font_face );
					}
				} else {
					// Preserve original content but duplicate entries to match the number of weights
					foreach ( $font_weights as $ignored ) {
						$result[] = $font_face;
					}
				}
			} else {
				$result[] = $font_face;
			}
		}
		
		return $result;
	}
	
	/**
	 * Build a Search/Replace array from converted font faces.
	 *
	 * @param string $document    The document to process. Either a valid CSS stylesheet or HTML document.
	 * @param array  $font_faces  Array of strings containing full regex matched @font-face statements. Used for unloading.
	 * @param array  $families    Array of detected font-families.
	 * @param string $handle_base Base of the stylesheet handle. Default: 'inline-font-face'
	 *
	 * @return array
	 * @throws \TypeError
	 */
	private function build_font_face_search_replace( $document, $font_faces, $families, $handle_base = 'inline-font-face' ) {
		$search         = [];
		$replace        = [];
		$used_subsets   = Wrapper::get_option( 'subsets', [] );
		$unloaded_fonts = Wrapper::unloaded_fonts();
		
		foreach ( $families as $font_family => $properties ) {
			$family          = $font_family . ':' . implode( ',', $this->get_font_variants( $properties['variants'] ) );
			$original_handle = "$handle_base-" . str_replace( ' ', '-', strtolower( $font_family ) );
			$font_id         = str_replace( ' ', '-', strtolower( $font_family ) );
			
			/**
			 * @since v3.3.0 There's no need to proceed if the entire stylesheet is marked for unloading.
			 * BUG: [OP-63] If two local stylesheets contain the same @font-face statements, checking don't load for one, unloads the other as well.
			 */
			if ( in_array( $original_handle, Wrapper::unloaded_stylesheets(), true ) || in_array( sanitize_title_with_dashes( $original_handle ), Wrapper::unloaded_stylesheets(), true ) ) {
				foreach ( $font_faces as $key => $font_face ) {
					if ( str_contains( $font_face, $font_family ) ) {
						$search[]  = $font_face;
						$replace[] = '';
						
						unset( $font_faces[ $key ] );
					}
				}
				
				// Skip to the next Font Family.
				continue;
			}
			
			/**
			 * @font-face statements for unused subsets can be safely unloaded.
			 * 'default' is used for @font-face statements without defined unicode-ranges and will always pass.
			 */
			foreach ( $properties['variants'] as $subset => $variants ) {
				if ( ! in_array( $subset, array_merge( [ 'default' ], $used_subsets ) ) ) {
					$range = UnicodeRanges::MAP[ $subset ];
					
					$to_unload = array_filter(
						$font_faces,
						function ( $font_face ) use ( $range ) {
							$range_with_spaces = str_replace( ',', ', ', $range );
							
							return str_contains( $font_face, $range ) || str_contains( $font_face, $range_with_spaces );
						}
					);
					
					foreach ( $to_unload as $key => $unload ) {
						$search[]  = $unload;
						$replace[] = '';
						
						unset( $font_faces[ $key ] );
					}
				}
			}
			
			/**
			 * @since v3.3.0 Do a quick check to see which @font-face statements should be removed entirely.
			 */
			foreach ( $properties['variants'] as $variants ) {
				// The stylesheet has no relevant fonts marked for unloading.
				if ( ! isset( $unloaded_fonts[ $original_handle ][ $font_id ] ) ) {
					break;
				}
				
				foreach ( $variants as $variant => $external_url ) {
					if ( in_array( (string) $variant, $unloaded_fonts[ $original_handle ][ $font_id ], true ) ) {
						/** Fetch the string to be removed from the stylesheet. */
						$to_unload = array_filter(
							$font_faces,
							function ( $font_face ) use ( $external_url, $variant ) {
								$font_weight = (string) $variant;
								$font_style  = '';
								
								if ( str_contains( $font_weight, 'italic' ) ) {
									$font_weight = str_replace( 'italic', '', $font_weight );
									$font_style  = 'italic';
								}
								
								return str_contains( $font_face, $external_url ) && str_contains( $font_face, $font_weight ) && str_contains( $font_face, $font_style );
							}
						);
						
						if ( empty( $to_unload ) ) {
							// @codeCoverageIgnoreStart
							Wrapper::debug( __( 'No @font-face matched.', 'omgf-pro' ) );
							
							continue;
							// @codeCoverageIgnoreEnd
						}
						
						foreach ( $to_unload as $key => $single_to_unload ) {
							$search[]  = $single_to_unload;
							$replace[] = '';
							
							unset( $font_faces[ $key ] );
						}
					}
				}
			}
			
			$handle = ! empty( Wrapper::get_cache_key( $original_handle ) ) ? Wrapper::get_cache_key( $original_handle ) : $original_handle;
			
			/**
			 * Whether the optimization bails early depends on the presence of the $_GET parameter.
			 */
			$fonts = $this->run_optimization(
				'https://fonts.googleapis.com/css?family=' . $family,
				$handle,
				$original_handle,
				'object', ! $this->force_optimize && ! defined( 'DAAN_DOING_TESTS' )
			);
			
			/**
			 * If $fonts returns empty, try again with $document's contents.
			 */
			if ( empty( $fonts ) && ! empty ( $document ) ) {
				/**
				 * @since v5.2.9 Filter $font_faces to only include the current font-family, to prevent
				 *               the entire $document from being parsed.
				 */
				$current_font_faces = array_filter(
					$font_faces,
					function ( $font_face ) use ( $font_family ) {
						return preg_match( '/font-family:[\s]*[\'"]?' . preg_quote( $font_family, '/' ) . '[\'"]?[\s]*;/', $font_face );
					}
				);
				
				/**
				 * Whether the optimization bails early depends on the presence of the $_GET parameter.
				 */
				$fonts = $this->run_optimization(
					'', // This is intentionally empty, to make sure OMGF's Optimize-class uses the stylesheet provided in $contents.
					$handle,
					$original_handle,
					'object',
					! $this->force_optimize && ! defined( 'DAAN_DOING_TESTS' ),
					implode( "\n", $current_font_faces )
				);
			}
			
			if ( is_wp_error( $fonts ) || ! is_iterable( $fonts ) ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * @since v3.3.0 $fonts has already filtered unloaded fonts. If the stylesheet is marked for unloading i.e. no
			 *               fonts are loaded, it'll skip the foreach() entirely.
			 */
			// We want to replace each original @font-face match with potentially multiple subset-specific rules.
			// To do this safely, aggregate replacements per matched original block and emit a single concatenated replacement per original.
			$replacement_map = [];
			
			foreach ( $fonts as $contents ) {
				foreach ( $contents as $content ) {
					foreach ( $content->variants as $variant ) {
						$variant->id    = $variant->id === 'regular' ? '400' : ( $variant->id === 'italic' ? '400italic' : $variant->id );
						$subset         = $variant->subset ?? 'default';
						$search_variant = $properties['variants'][ $subset ][ $variant->id ] ?? $properties['variants']['default'][ $variant->id ] ?? '';
						
						// If variant doesn't exist, skip.
						if ( empty( $search_variant ) ) {
							continue; // @codeCoverageIgnore
						}
						
						$matched_font_faces = array_filter(
							$font_faces,
							function ( $font_face ) use ( $search_variant ) {
								return str_contains( $font_face, $search_variant );
							}
						);
						
						// Correct the array if it contains variable fonts with multiple values in the font-weight attribute.
						$matched_font_faces = $this->validate_font_weights( $matched_font_faces, false );
						
						foreach ( $matched_font_faces as $matched_font_face ) {
							// Build the subset-specific URL (with version timestamp if available)
							$url = $variant->woff2 ?? '';
							if ( $url ) {
								$url       = urldecode( $variant->woff2 );
								$timestamp = Wrapper::get_option( 'omgf_cache_timestamp', '' );
								if ( $timestamp ) {
									$url = add_query_arg( 'ver', $timestamp, $url );
								}
							}
							
							$rendered                                = str_replace( $search_variant, $url, $matched_font_face );
							$replacement_map[ $matched_font_face ][] = $rendered;
						}
					}
				}
			}
			
			// Emit concatenated replacements for each unique matched original block.
			foreach ( $replacement_map as $original => $rendered_list ) {
				$search[] = $original;
				// Avoid duplicate concatenations (e.g., from validate_font_weights(false)).
				$replace[] = implode( "\n", array_unique( $rendered_list ) );
			}
		}
		
		return [
			'search'  => $search,
			'replace' => $replace,
		];
	}
	
	/**
	 * Build an array of
	 *
	 * @param $variants
	 *
	 * @return mixed
	 */
	private function get_font_variants( $variants ) {
		$font_variants = [];
		
		foreach ( $variants as $available_variants ) {
			$font_variants[] = array_keys( $available_variants );
		}
		
		return array_unique( array_merge( ...$font_variants ) );
	}
	
	/**
	 * Process Fallback Font Stacks in local stylesheets.
	 *
	 * @param string $contents Valid HTML/CSS.
	 *
	 * @return string
	 */
	public function process_fallback_font_stacks( $contents ) {
		$has_fallback_font_stacks = ! empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK ) );
		
		if ( ! Helper::is_magic_fallbacks_enabled() && ! $has_fallback_font_stacks ) {
			return $contents; // @codeCoverageIgnore
		}
		
		$font_stacks = [];
		
		Wrapper::debug( __( 'Processing Fallback Font Stacks', 'omgf-pro' ) );
		
		$contents_without_font_faces = preg_replace( '/@font-face\s*\{[^}]*}/i', '', $contents );
		
		foreach ( Wrapper::admin_optimized_fonts() as $fonts ) {
			foreach ( $fonts as $font ) {
				$font_family = urldecode( $font->family );
				
				Wrapper::debug( __( 'Searching for font-family declarations for: ', 'omgf-pro' ) . $font_family );
				
				/**
				 * Matches with font-family: [ '"]?Font Family[ '"]?[;}]
				 *
				 * @since v3.7.0 This regex now also matches with font-family: "Font Family"}
				 * @since v4.0.0 A more generic approach. We filter it down the line.
				 * @since v5.2.6 Filter out @font-face statements, before matching font-family declarations.
				 */
				preg_match_all( "/font-family[\s]*?:[\s]?(?P<font_stack>.+?)[;}]/i", $contents_without_font_faces, $matches );
				
				if ( empty( $matches['font_stack'] ) ) {
					continue; // @codeCoverageIgnore
				}
				
				$matches['font_stack'] = array_filter(
					$matches['font_stack'],
					function ( $font_stack ) use ( $font_family ) {
						return str_contains( $font_stack, $font_family );
					}
				);
				
				Wrapper::debug_array( 'Found matching font stacks', $matches['font_stack'] );
				
				$font_stacks = array_merge( $matches['font_stack'], $font_stacks );
			}
		}
		
		if ( empty( $font_stacks ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		$searches = [];
		$replaces = [];
		
		foreach ( $font_stacks as $font_stack ) {
			$current_font_stack = $font_stack;
			
			// If a fallback is already set, lose it.
			if ( str_contains( $font_stack, ',' ) ) {
				$font_stack = explode( ',', $font_stack )[0];
			}
			
			// Make sure !important statements are stripped, too.
			if ( str_contains( $font_stack, '!important' ) ) {
				$font_stack = str_replace( [ '!important', ' !important' ], '', $font_stack );
			}
			
			// Trim spaces and single and double quotes.
			$font_stack = trim( $font_stack, '\'" ' );
			$font_id    = str_replace( ' ', '-', strtolower( $font_stack ) );
			$fallback   = $this->load_fallback_font_stack( $font_stack, $font_id );
			
			// No fallback was found. Skip out.
			if ( ! $fallback ) {
				continue; // @codeCoverageIgnore
			}
			
			$searches[] = $current_font_stack;
			$replaces[] = $fallback;
		}
		
		Wrapper::debug_array( 'Font family attributes to search for', $searches );
		Wrapper::debug_array( 'Fallback font stacks to replace the found font family attributes with', $replaces );
		
		$position    = 0;
		$prev_search = '';
		
		foreach ( $searches as $key => $search ) {
			$next_position = $position !== false ? $position + strlen( $search ) : 0;
			
			if ( $prev_search !== $search ) {
				$next_position = 0;
			}
			
			$position    = strpos( $contents, $search, $next_position );
			$prev_search = $search;
			
			if ( $position !== false && isset( $replaces[ $key ] ) ) {
				$contents = substr_replace( $contents, $replaces[ $key ], $position, strlen( $search ) );
			}
		}
		
		return $contents;
	}
	
	/**
	 * Map fallback font stack option to actual fallback font stack.
	 *
	 * @param string $font_id    Current font stack's ID in CSS/HTML
	 * @param string $font_stack Current font stack in CSS/HTML
	 *
	 * @return bool|string
	 * @since v2.5
	 *
	 */
	public function load_fallback_font_stack( $font_stack, $font_id ) {
		$fallback = '';
		
		if ( Helper::is_magic_fallbacks_enabled() ) {
			$matches = FallbackFontStack::find_best_match( $font_stack );
			
			if ( ! empty( $matches ) ) {
				$fallback = FallbackFontStack::format_fallback_stack( $font_stack, $matches );
			}
		}
		
		if ( ! $fallback ) {
			// Existing logic for manual Fallback Font Stack.
			foreach ( (array) Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK, [] ) as $font_families ) {
				foreach ( (array) $font_families as $font_family => $selected_fallback ) {
					if ( $font_family !== $font_id || ! $selected_fallback ) {
						continue; // @codeCoverageIgnore
					}
					
					$font_stacks = apply_filters( 'omgf_pro_fallback_font_stacks', FallbackFontStacks::MAP );
					$fallback    = $font_stacks[ $selected_fallback ] ?? '';
					
					break;
				}
			}
		}
		
		if ( ! $fallback ) {
			return false; // @codeCoverageIgnore
		}
		
		$replaces = Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT, [] ) ?: [];
		
		foreach ( $replaces as $font_families ) {
			if ( ! empty( $font_families[ $font_id ] ) ) {
				return $fallback;
			}
		}
		
		if ( str_contains( $font_stack, ' ' ) ) {
			return '"' . $font_stack . '"' . ', ' . $fallback;
		}
		
		return $font_stack . ', ' . $fallback;
	}
	
	/**
	 * Replaces existing font-display attribute values, and inserts it where its missing.
	 *
	 * @param string $contents Valid CSS/HTML.
	 *
	 * @return string valid CSS/HTML
	 */
	public function process_force_font_display( $contents ) {
		// Nothing to do here.
		if ( empty( Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_FORCE_FONT_DISPLAY ) ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		/**
		 * If Font Display attribute is present, somewhere in the document, replace it with the set value.
		 * Matches either font-display: swap; and font-display: swap}.
		 */
		$contents = preg_replace(
			'/(font-display:[\s]*).*?([;}])/si',
			'$1' . Wrapper::get_option( \OMGF\Admin\Settings::OMGF_OPTIMIZE_SETTING_DISPLAY_OPTION ) . '$2',
			$contents
		);
		
		/**
		 * Match all @font-face statements.
		 * TODO: [OP-54] Create a regex to match all @font-face statements NOT containing a font-display attribute.
		 */
		preg_match_all( '/@font-face[\s]*{(.*?)}/s', $contents, $font_faces );
		
		if ( empty( $font_faces[0] ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		$replace = [];
		$search  = [];
		$attr    = sprintf( self::FONT_DISPLAY_ATTRIBUTE, Wrapper::get_option( \OMGF\Admin\Settings::OMGF_OPTIMIZE_SETTING_DISPLAY_OPTION ) );
		
		foreach ( $font_faces[0] as $key => $font_face ) {
			// If a font-display attribute is already present. Skip it.
			if ( str_contains( $font_face, 'font-display' ) ) {
				continue;
			}
			
			$search[ $key ]  = $font_faces[0][ $key ];
			$replace[ $key ] = substr_replace( $font_faces[0][ $key ], $attr, strpos( $font_faces[0][ $key ], ';' ) + 1, 0 );
		}
		
		// No need to continue if no work was done.
		if ( empty( $search ) || empty( $replace ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		// Rewrite the contents of the stylesheet to include the font-display attribute.
		return str_replace( $search, $replace, $contents );
	}
	
	/**
	 * Convert relative URLS in $contents to Absolute URLs using $url to decide the base.
	 *
	 * @see   convert_rel_url_to_abs()
	 *
	 * @since v3.7.2 [OP-79] Re-factored code to optimize performance and to take a uniform approach for detecting
	 *                       Relative URLs.
	 *
	 * @param string $contents Valid CSS
	 *
	 * @param string $url
	 *
	 * @return string Valid CSS
	 */
	public function maybe_convert_rel_url_to_abs( $contents, $url ) {
		preg_match_all( '/url\([\s\'"]{0,2}(?P<src>.*?)[\s"\']{0,2}\)/i', $contents, $srcs );
		
		if ( empty( $srcs['src'] ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		$rel_urls = [];
		
		foreach ( $srcs['src'] as $src ) {
			$src = trim( $src, '\'\" ' );
			
			if ( $this->is_rel_url( $src ) ) {
				$rel_urls[] = $src;
			}
		}
		
		if ( empty( $rel_urls ) ) {
			return $contents;
		}
		
		return $this->convert_rel_url_to_abs( $contents, $url, $rel_urls );
	}
	
	/**
	 * Checks if $source contain mentions of '../' or doesn't begin with either 'http' or '../'.
	 *
	 * @param string $source
	 *
	 * @return bool  false for absolute or root-relative URLs || true for e.g. "../fonts/file.woff2" or "fonts/file.woff2"
	 */
	private function is_rel_url( string $source ) {
		/**
		 * Don't rewrite, if:
		 *
		 * @since v3.6.3 this is either a protocol relative URL or,
		 * @since v3.6.4 this is a Base64 encoded datatype.
		 * @since v6.0.0 this is any absolute URI scheme (case-insensitive) or a root-relative URI.
		 */
		if ( str_starts_with( $source, '/' ) || preg_match( '/^[a-z][a-z0-9+.-]*:/i', $source ) === 1 ) {
			return false;
		}
		
		$is_http = str_starts_with( $source, 'http://' ) || str_starts_with( $source, 'https://' );
		
		return str_starts_with( $source, '../' ) // true: ../fonts/file.woff2
		       || ( ! $is_http && ! str_contains( $source, '../' ) && strpos( $source, '/' ) > 0 ) // true: fonts/file.woff2
		       || ( ! $is_http && ! str_contains( $source, '../' ) && ! str_contains( $source, '/' ) && preg_match( '/^[a-zA-Z]/', $source ) === 1 ); // true: file.woff2
	}
	
	/**
	 * Convert any relative URLs in $stylesheet to absolute URLs in using $source.
	 *
	 * @see   maybe_convert_rel_url_to_abs()
	 *
	 * @since v3.7.2 [OP-79] Re-factored code to optimize performance and to take a uniform approach for detecting
	 *                       Relative URLs.
	 *
	 * @param string $stylesheet
	 * @param string $source
	 * @param array  $urls_to_convert
	 *
	 * @return string
	 */
	private function convert_rel_url_to_abs( string $stylesheet, string $source, array $urls_to_convert = [] ) {
		$search  = [];
		$replace = [];
		
		foreach ( $urls_to_convert as $key => $rel ) {
			if ( ! $this->is_rel_url( $rel ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$folder_depth  = substr_count( $rel, '../' );
			$url_to_insert = $source;
			
			/**
			 * Remove everything after the last occurrence of a forward slash ('/');
			 * $i = 0: Filename (current directory)
			 *      1: First level parent directory, i.e. '../'
			 *      2: 2nd level parent directory, i.e. '../../'
			 *      3: Etc.
			 */
			for ( $i = 0; $i <= $folder_depth; $i ++ ) {
				$url_to_insert = substr( $source, 0, strrpos( $url_to_insert, '/' ) );
			}
			
			$path            = ltrim( $rel, './' );
			$search[ $key ]  = $rel;
			$replace[ $key ] = $url_to_insert . '/' . $path;
		}
		
		/**
		 * @since v3.4.2 Filter out duplicate values to prevent repeated search-replace madness.
		 */
		foreach ( $search as $key => $to_search ) {
			/**
			 * @since v3.5.1 We're using tildes (~) as delimiters, so we don't have to escape slashes in URLs.
			 *               Noice, roight?
			 */
			$to_search  = preg_quote( $to_search, '~' );
			$stylesheet = preg_replace( "~(url\([\s'\"]{0,2})$to_search([\s'\"]{0,2}\))~si", '$1' . $replace[ $key ] . '$2', $stylesheet );
		}
		
		return $stylesheet;
	}
	
	/**
	 * Save the optimized stylesheet to disk and return the cache-busting URL.
	 *
	 * @since v4.2.0
	 *
	 * @param string $cache_path
	 * @param string $cache_url
	 *
	 * @param string $contents
	 *
	 * @return string
	 *
	 */
	protected function save_optimized_stylesheet( string $contents, string $cache_path, string $cache_url ) {
		if ( str_contains( $cache_path, '?' ) ) {
			$parsed_path = wp_parse_url( $cache_path, PHP_URL_PATH );
			$cache_path  = $parsed_path ?: strtok( $cache_path, '?' );
		}
		
		/**
		 * @since v5.2.7 Only allow writing .css files to prevent arbitrary file upload.
		 */
		if ( strtolower( pathinfo( $cache_path, PATHINFO_EXTENSION ) ) !== 'css' ) {
			return ''; // @codeCoverageIgnore
		}
		
		/**
		 * @since v5.2.7 Block directory traversal.
		 */
		$upload_dir  = Wrapper::get_upload_dir();
		$real_upload = realpath( $upload_dir );
		$target_dir  = dirname( $cache_path );
		
		// Resolve what we can — walk up until we hit an existing ancestor.
		while ( ! empty( $target_dir ) && $target_dir !== '.' && ! file_exists( $target_dir ) ) {
			$target_dir = dirname( $target_dir );
		}
		
		$real_target = realpath( $target_dir );
		
		if ( $real_upload ) {
			$real_upload = wp_normalize_path( $real_upload );
		}
		
		if ( $real_target ) {
			$real_target = wp_normalize_path( $real_target );
		}
		
		if ( ! $real_upload || ! $real_target || ( $real_target !== $real_upload && strpos( $real_target, trailingslashit( $real_upload ) ) !== 0 ) ) {
			return ''; // @codeCoverageIgnore
		}
		
		// Safe to create the directory now.
		wp_mkdir_p( dirname( $cache_path ) );
		
		$filename  = basename( $cache_path );
		$cache_dir = str_replace( $filename, '', $cache_path );
		
		if ( ! file_exists( $cache_dir ) ) {
			wp_mkdir_p( $cache_dir ); // @codeCoverageIgnore
		}
		
		$tmp_path = $cache_path . '.' . wp_rand() . '.tmp';
		$written  = file_put_contents( $tmp_path, $contents, LOCK_EX );
		
		if ( $written === false || $written < strlen( $contents ) ) {
			@unlink( $tmp_path ); // @codeCoverageIgnore
			
			return ''; // @codeCoverageIgnore
		}
		
		if ( ! @rename( $tmp_path, $cache_path ) ) {
			@unlink( $tmp_path ); // @codeCoverageIgnore
			
			return ''; // @codeCoverageIgnore
		}
		
		return $this->generate_cache_url( $cache_path, $cache_url );
	}
	
	/**
	 * Generate a URL appended with a ver and cached parameter to indicate it's cached.
	 *
	 * @param $file_path
	 * @param $file_url
	 *
	 * @return string
	 */
	protected function generate_cache_url( $file_path, $file_url ) {
		$mod_time = filemtime( $file_path );
		
		if ( $mod_time === false ) {
			$mod_time = time();
		}
		
		return add_query_arg( [ 'ver' => $mod_time, 'cached' => true ], $file_url );
	}
	
	/**
	 * Shorthand to check if a stylesheet should be optimized.
	 *
	 * @since v4.2.0
	 *
	 * @param string $cache_path
	 * @param array  $processed_stylesheets
	 *
	 * @param string $url
	 *
	 * @return bool
	 *
	 */
	protected function should_optimize_stylesheet( $url, $cache_path, $processed_stylesheets ) {
		if ( $this->force_optimize ) {
			return true;
		}
		
		if ( ! file_exists( $cache_path ) ) {
			return true;
		}
		
		if ( ! in_array( $url, $processed_stylesheets, true ) ) {
			return true;
		}
		
		return false;
	}
}
