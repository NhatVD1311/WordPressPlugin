<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\Optimize;
use OMGF\Pro\Wrapper;

class AsyncStylesheets extends Optimize {
	/**
	 * Processes and optimizes the list of asynchronously loaded stylesheets.
	 *
	 * This method retrieves processed async stylesheets and iterates over them to initiate
	 * the optimization process for each stylesheet.
	 *
	 * @return void
	 */
	public function optimize() {
		$processed_stylesheets = Wrapper::get_option( Settings::OMGF_PRO_PROCESSED_ASYNC_STYLESHEETS, [] );

		foreach ( $processed_stylesheets as $cache_handle => $stylesheet_url ) {
			$cache_key = empty( Wrapper::get_cache_key( $cache_handle ) ) ? $cache_handle : Wrapper::get_cache_key( $cache_handle );
			$optimize  = new \OMGF\Optimize( $stylesheet_url, $cache_key, $cache_handle );
			$optimize->process();
		}
	}
}
