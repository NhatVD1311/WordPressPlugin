<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize\Compatibility;

use OMGF\Pro\Wrapper;

class BunnyCDN {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @since v5.2.10 Registered as static callbacks, because this class is constructed on every
	 *                @see \OMGF\Pro\Frontend\Optimize::process() call, and WordPress identifies a callback
	 *                on an object by its instance hash. Each instance would add its own copy of these filters,
	 *                and nothing ever removes them, so the same @import ends up being collected (and
	 *                optimized) once per instance which was ever constructed.
	 *
	 * @return void
	 */
	private function init() {
		add_filter( 'omgf_pro_process_import_full_matches', [ self::class, 'add_import_full_matches' ], 10, 2 );
		add_filter( 'omgf_pro_process_import_urls', [ self::class, 'add_import_urls' ], 10, 2 );
	}
	
	/**
	 * @param $full_matches
	 * @param $contents
	 *
	 * @return mixed
	 */
	public static function add_import_full_matches( $full_matches, $contents ) {
		$imports = self::match_imports( $contents );
		
		if ( ! empty( $imports[0] ) ) {
			$full_matches = array_merge( $full_matches, $imports[0] );
		}
		
		Wrapper::debug_array( 'added import full matches to filter', $full_matches );
		
		return $full_matches;
	}
	
	/**
	 * Match all @import statements in $contents.
	 *
	 * @param $contents
	 *
	 * @return array
	 */
	private static function match_imports( $contents ) {
		/**
		 * @since v5.2.10 Allow whitespace (incl. line breaks) after @import and inside url(), and line continuations
		 *                (a backslash followed by a line break) inside the URL. CSS normalizes a carriage return,
		 *                a form feed and a CRLF pair to a single line feed, so all of them count as a line break.
		 * @see   \OMGF\Pro\Frontend\Optimize::process_imports()
		 */
		preg_match_all( '/@import\s*(?:url\(\s*[\'"]?|[\'"])(?P<urls>(?:https?:)?\/\/fonts\.bunny\.net\/css(?:\\\\(?:\r\n|[\r\n\f])|[^\'")\r\n\f])*)[\'"]?\s*\)?\s*;/', $contents, $imports );
		
		Wrapper::debug_array( 'matched imports', $imports );
		
		return $imports;
	}
	
	/**
	 * Add Bunny CDN @imports to $urls.
	 *
	 * @param $urls
	 * @param $contents
	 *
	 * @return array
	 */
	public static function add_import_urls( $urls, $contents ) {
		$imports = self::match_imports( $contents );
		
		if ( ! empty( $imports['urls'] ) ) {
			$urls = array_merge( $urls, $imports['urls'] );
		}
		
		Wrapper::debug_array( 'added import url matches to filter', $urls );
		
		return $urls;
	}
}
