<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Frontend\Optimize;

/**
 * This class contains compatibility fixes needed in the frontend only.
 *
 * @see                \OMGF\Pro\Compatibility for global fixes!
 *
 * @codeCoverageIgnore Because all it does is load classes.
 */
class Compatibility extends Optimize {
	/**
	 * Build class.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	private function init() {
		/**
		 * BunnyCDN compatibility.
		 * This is different from the BunnyCDN compatibility in the @see \OMGF\Pro\Compatibility class, because this checks for entries in (inline) stylesheets.
		 * The BunnyCDN plugin is NOT required here.
		 */
		new Compatibility\BunnyCDN();
		
		/** Themes that use WPTT webfont loader */
		if ( function_exists( 'wptt_get_webfont_url' ) ) {
			new Compatibility\WPTT();
		}
	}
	
}
