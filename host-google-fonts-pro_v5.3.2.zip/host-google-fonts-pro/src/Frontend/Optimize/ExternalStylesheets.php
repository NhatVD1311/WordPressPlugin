<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\Optimize;
use OMGF\Pro\Wrapper;

class ExternalStylesheets extends Optimize {
	/**
	 * @var array $processed_external_stylesheets
	 * @since v3.3.0 Contains an array of processed stylesheets to speed up processing on pageload.
	 */
	private $processed_external_stylesheets = [];
	
	/**
	 * Build properties.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->processed_external_stylesheets = Wrapper::get_option( Settings::OMGF_PRO_PROCESSED_EXT_STYLESHEETS, [] ) ?: [];
		
		parent::__construct( false );
		
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @since v5.2.10 Registered as static callbacks, because this class is constructed on every
	 *                @see \OMGF\Pro\Frontend\Optimize::process() call, and WordPress identifies a callback
	 *                on an object by its instance hash. Each instance would add its own copy of these filters,
	 *                and nothing ever removes them, so the same @import ends up being collected (and
	 *                optimized) once per instance which was ever constructed.
	 *
	 * @return void
	 */
	private function init() {
		add_filter( 'omgf_pro_process_import_full_matches', [ self::class, 'add_import_full_matches' ], 10, 2 );
		add_filter( 'omgf_pro_process_import_urls', [ self::class, 'add_import_urls' ], 10, 2 );
	}
	
	/**
	 * @param $full_matches
	 * @param $contents
	 *
	 * @return mixed
	 */
	public static function add_import_full_matches( $full_matches, $contents ) {
		$imports = self::match_imports( $contents );
		
		if ( ! empty( $imports[0] ) ) {
			$full_matches = array_merge( $full_matches, $imports[0] );
		}
		
		Wrapper::debug_array( 'added import full matches to filter', $full_matches );
		
		return $full_matches;
	}
	
	/**
	 * Match all @import statements in $contents.
	 *
	 * @param $contents
	 *
	 * @return array
	 */
	private static function match_imports( $contents ) {
		/**
		 * @since v5.2.10 Allow whitespace (incl. line breaks) after @import and inside url(), and line continuations
		 *                (a backslash followed by a line break) inside the URL. CSS normalizes a carriage return,
		 *                a form feed and a CRLF pair to a single line feed, so all of them count as a line break.
		 * @see   \OMGF\Pro\Frontend\Optimize::process_imports()
		 */
		preg_match_all( '/@import\s*(?:url\(\s*[\'"]?|[\'"])(?P<urls>(?:\\\\(?:\r\n|[\r\n\f])|[^\'")\r\n\f])+)[\'")]{1,2}/', $contents, $imports );
		
		Wrapper::debug_array( 'matched imports', $imports );
		
		return $imports;
	}
	
	/**
	 * @param $urls
	 * @param $contents
	 *
	 * @return array
	 */
	public static function add_import_urls( $urls, $contents ) {
		$imports = self::match_imports( $contents );
		
		if ( ! empty( $imports['urls'] ) ) {
			$urls = array_merge( $urls, $imports['urls'] );
		}
		
		Wrapper::debug_array( 'added import url matches to filter', $urls );
		
		return $urls;
	}
	
	/**
	 * Check for @import and @font-face statements inside external stylesheets.
	 * Rewrite them to use local copies and cache them.
	 *
	 * @param string $html
	 *
	 * @return string
	 * @throws \TypeError
	 */
	public function optimize( $html ) {
		$search  = [];
		$replace = [];
		
		/**
		 * @since v3.7.6 Prevent unnecessary writes to the database, by having something to compare to.
		 */
		$processed_ext_stylesheets = $this->processed_external_stylesheets;
		
		/**
		 * @since v3.4.5  Use lookaround for stricter matches.
		 * @since v5.2.10 Use [^>] instead of . to confine the match to a single element, because . also matches
		 *                the > which ends it, while it doesn't match the line breaks HTML allows inside (and
		 *                between) attribute values. Line breaks are stripped from the URL further down, just
		 *                like browsers do before requesting it.
		 */
		preg_match_all( '/(?=<link)[^>]+?href=[\'"](?P<urls>[a-zA-Z0-9;,\/?:@&=+$\-_.!~*\'()#\s]+?)[\'"][^>]*>/', $html, $links );
		
		/**
		 * @see          https://stackoverflow.com/a/27396794/4949411
		 * @since        v3.7.0 This matches with SSL, non-SSL and relative references in the following syntax's:
		 *               - @import url('');
		 *               - @import url();
		 *               - @import '';
		 *               This does NOT match e.g. @import https://domain.com/example; (i.e., no quotes) simply because I can't imagine that that's
		 *               valid CSS. If it is, we'll find out soon enough.
		 *               The "(?:(?!@import).)" part is a negative lookahead assertion, and makes sure the match is as short as possible (from the
		 *               end) i.e., match @import as long as it's not followed by another @import statement.
		 */
		$imports = self::match_imports( $html );
		
		if ( empty( $links['urls'] ) && empty ( $imports['urls'] ) ) {
			return $html;
		}
		
		$full_matches = array_merge( $links[0], $imports[0] );
		$urls         = array_merge( $links['urls'], $imports['urls'] );
		
		foreach ( $urls as $i => $url ) {
			$is_import = str_contains( $full_matches[ $i ], '@import' );

			/**
			 * Check if full match is a stylesheet or an @import statement.
			 */
			if ( ! preg_match( '/\brel\s*=\s*["\'][^"\']*\bstylesheet\b[^"\']*["\']/i', $full_matches[ $i ] ) && ! $is_import ) {
				continue;
			}

			/**
			 * $full_url is only used for the eventual search/replace and should match the source code verbatim.
			 * Everything else uses the sanitized copy. URLs found in CSS can contain line continuations, which
			 * aren't a thing in HTML attributes.
			 *
			 * @since v5.2.10
			 */
			$full_url = $url;
			$url      = $is_import ? $this->sanitize_css_url( $url ) : $this->sanitize_url( $url );

			/**
			 * Retained, because $url is reduced to a cache key (i.e., without its query parameters) further down,
			 * while the request should be made to the complete URL.
			 *
			 * @since v5.2.10
			 */
			$request_url = $url;

			/**
			 * Double-check if this is a (protocol relative) URL.
			 */
			if ( ! str_starts_with( $url, '//' ) && ! str_starts_with( $url, 'http' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$fixed_url = $this->normalize_url( $url );
			
			/**
			 * This class only processes external stylesheets (not local, and not Google Fonts API requests).
			 */
			if ( str_contains( $fixed_url, get_home_url() ) || str_contains( $fixed_url, 'fonts.googleapis.com' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$url_parts = parse_url( $fixed_url );
			
			if ( ! $url_parts || empty( $url_parts['scheme'] ) || empty( $url_parts['host'] ) || empty( $url_parts['path'] ) ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * @since v5.2.7 Only process CSS files to prevent arbitrary file upload.
			 */
			if ( strtolower( pathinfo( $url_parts['path'], PATHINFO_EXTENSION ) ) !== 'css' ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * @since v3.7.6 Fixes [OP-84]: Remove any query parameters from $url. To make sure no duplicate entries are saved in
			 *                              processed_external_stylesheets.
			 */
			$url = $url_parts['scheme'] . '://' . $url_parts['host'] . $url_parts['path'];
			
			/**
			 * To avoid collisions on servers that have allow_url_fopen disabled, we fetch the contents using absolute paths.
			 *
			 * @since v3.4.4 using content_url is warranted because we need to insert the path to OMGF (Pro)'s upload dir.
			 * @since v3.6.0 Use a preg_replace() to remove any present query parameters from local paths ($local_path and $cache_path)
			 *               Query parameters are allowed in URLs.
			 * @since v3.7.6 Fixes [OP-84]: Query parameters are removed from $cached_file_path, because we also remove it from $url.
			 *                              It's not like we remove them from the source code, so any present parameters will remain intact.
			 */
			$cached_file_path = trailingslashit( Wrapper::get_upload_dir() ) . $url_parts['host'] . $url_parts['path'];
			$cached_file_url  = trailingslashit( Wrapper::get_upload_url() ) . $url_parts['host'] . $url_parts['path'];
			
			/**
			 * If this stylesheet has been cached previously, assume nothing has changed and continue to the next.
			 */
			if ( ! $this->should_optimize_stylesheet( $url, $cached_file_path, $processed_ext_stylesheets ) ) {
				$search[ $i ]  = $full_url;
				$replace[ $i ] = $this->generate_cache_url( $cached_file_path, $cached_file_url );
				
				continue;
			}
			
			/**
			 * @since v3.6.0 If the file wasn't cached, but the original file does exist, and it was processed before, bail!
			 */
			if ( ! $this->force_optimize && ! file_exists( $cached_file_path ) && in_array( $url, $processed_ext_stylesheets, true ) ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * @since v5.2.10 Request the sanitized URL, because $full_url is the verbatim (possibly multi-line)
			 *                value from the source code.
			 */
			$response      = wp_safe_remote_get( $this->normalize_url( $request_url ) );
			$contents      = wp_remote_retrieve_body( ( $response ) );
			$response_code = wp_remote_retrieve_response_code( $response );
			$comparison    = $contents;
			
			if ( is_wp_error( $response ) || $response_code !== 200 ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * @since v3.6.0 Mark it as processed, before going through it all.
			 */
			if ( ! in_array( $url, $processed_ext_stylesheets, true ) && ! is_dir( $cached_file_path ) ) {
				$processed_ext_stylesheets[] = $url;
			}
			
			if ( ! $contents ) {
				continue; // @codeCoverageIgnore
			}
			
			$contents = $this->optimize_stylesheet_contents( $contents, $fixed_url, 'ext-stylesheet', Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS );
			
			/**
			 * No need to cache it if we didn't change anything.
			 */
			if ( $comparison === $contents ) {
				continue; // @codeCoverageIgnore
			}
			
			$cached_file_url = $this->save_optimized_stylesheet( $contents, $cached_file_path, $cached_file_url );
			
			$search[ $i ]  = $full_url;
			$replace[ $i ] = $cached_file_url;
		}
		
		/**
		 * @since v3.7.6 Prevent unnecessary writes to the database by comparing the updated array with the original copy from the database.
		 */
		if ( ! empty( array_diff( $processed_ext_stylesheets, $this->processed_external_stylesheets ) ) ) {
			Wrapper::update_option( Settings::OMGF_PRO_PROCESSED_EXT_STYLESHEETS, $processed_ext_stylesheets );
		}
		
		if ( empty( $search ) || empty( $replace ) ) {
			return $html; // @codeCoverageIgnore
		}
		
		return str_replace( $search, $replace, $html );
	}
}
