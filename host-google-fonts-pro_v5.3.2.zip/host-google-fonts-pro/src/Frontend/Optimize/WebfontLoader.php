<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Frontend\Optimize;

class WebfontLoader extends Optimize {
	/**
	 * @param string $html Valid HTML
	 *
	 * @return string
	 */
	public function optimize( $html ) {
		// Replace any (external!) webfont.js libraries with the one included in OMGF Pro.
		$local_lib = OMGF_PRO_PLUGIN_URL . 'assets/js/lib/webfont.js';
		$home_url  = get_home_url();
		$html      = preg_replace( "~(src\s?=\s?['\"])(?!$home_url).*?(webfont\.js|webfont\.min\.js)~", '$1' . $local_lib, $html );
		
		return $html;
	}
}
