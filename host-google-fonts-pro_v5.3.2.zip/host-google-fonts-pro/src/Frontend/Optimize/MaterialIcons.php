<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Frontend\Optimize;

class MaterialIcons extends Optimize {
	/**
	 * Filter/Action hooks.
	 *
	 * @return void
	 */
	public function __construct() {
		/**
		 * Material Icons compatibility.
		 *
		 * @since v5.2.10 Registered as a static callback, because this class is constructed more than once
		 *                per request (@see \OMGF\Pro\Filters::parse_vc_grid_data() and
		 *                @see \OMGF\Pro\Frontend\Optimize::process()) and WordPress identifies a callback on
		 *                an object by its instance hash. Each instance would add its own copy of this filter,
		 *                which would prepend 'fallback' to the subsets once per instance. A callback on a
		 *                class name is identified by that name, so registering it again is a no-op.
		 */
		add_filter( 'omgf_setting_subsets', [ self::class, 'add_material_icons_subset' ] );
	}

	/**
	 * The Material Icons stylesheet defines a subset, named 'fallback', so we're adding it here.
	 *
	 * @param array $subsets
	 *
	 * @return array
	 */
	public static function add_material_icons_subset( $subsets ) {
		return array_merge( [ 'fallback' ], $subsets );
	}

	/**
	 * Process Material Icons in $html. Multiple occurrences are replaced with the same stylesheet.
	 *
	 * @param string                 $html      Valid HTML
	 * @param \OMGF\Frontend\Process $processor No need to check dependencies here, because this function
	 *                                          is only executed if OMGF is installed/activated.
	 *
	 * @filter omgf_processed_html
	 *
	 * @return string Valid HTML
	 *
	 * @throws SodiumException
	 * @throws SodiumException
	 * @throws TypeError
	 * @throws TypeError
	 * @throws TypeError
	 */
	public function optimize( $html, $processor ) {
		if ( ! method_exists( $processor, 'is_font_api_url' ) ) {
			return $html; // @codeCoverageIgnore
		}

		/**
		 * OMGF itself only processes the API's stylesheet endpoint (/css), so the endpoint is swapped for the
		 * duration of this run. It's not added, because the stylesheet endpoint is already processed by OMGF.
		 * The swap is done once, around the entire run, instead of once per element.
		 */
		add_filter( 'omgf_font_api_hosts', [ self::class, 'material_icons_endpoint' ], PHP_INT_MAX );

		try {
			/**
			 * @since v5.2.11 Match every link element and validate its attribute values, instead of matching
			 *                the API's URL anywhere in the element's markup, so only elements which actually
			 *                point at the API are processed.
			 */
			return $this->invoke_processor(
				$html,
				$processor,
				'/<link.*?[\/]?>/s',
				function ( $urls ) use ( $processor ) {
					return self::contains_material_icons_url( $urls, $processor );
				}
			);
		} finally {
			remove_filter( 'omgf_font_api_hosts', [ self::class, 'material_icons_endpoint' ], PHP_INT_MAX );
		}
	}

	/**
	 * Does any of $urls point to the Material Icons endpoint of the Google Fonts API?
	 *
	 * Only meaningful while @see self::material_icons_endpoint() is hooked, which @see self::optimize() does.
	 *
	 * @since v5.2.11
	 *
	 * @param array                  $urls      An element's (sanitized) attribute values.
	 * @param \OMGF\Frontend\Process $processor
	 *
	 * @return bool
	 */
	public static function contains_material_icons_url( $urls, $processor ) {
		foreach ( (array) $urls as $url ) {
			if ( $processor->is_font_api_url( $url ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Limits the endpoints accepted by @see \OMGF\Frontend\Process::is_font_api_url() to Material Icons.
	 *
	 * @filter omgf_font_api_hosts
	 * @since  v5.2.11
	 *
	 * @return array
	 */
	public static function material_icons_endpoint() {
		return [ 'fonts.googleapis.com' => [ '/icon' ] ];
	}
}
