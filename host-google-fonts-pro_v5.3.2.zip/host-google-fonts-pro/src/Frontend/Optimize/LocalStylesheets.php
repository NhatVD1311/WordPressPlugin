<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend\Optimize;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\Optimize;
use OMGF\Pro\Wrapper;

class LocalStylesheets extends Optimize {
	/**
	 * @var array $processed_local_stylesheets
	 * @since v3.3.0 Contains an array of processed stylesheets to speed up processing on pageload.
	 */
	private $processed_local_stylesheets = [];
	
	/**
	 * @var array $dynamic_css_handles
	 * @since  v3.6.2 Provides an easy interface to add additional handles used by themes/plugins to generate dynamic CSS.
	 * @filter omgf_pro_optimize_dynamic_css_handles
	 */
	private $dynamic_css_handles = [];
	
	/**
	 * Build properties.
	 *
	 * @return void
	 */
	public function __construct() {
		// phpcs:ignore
		$this->processed_local_stylesheets = Wrapper::get_option( Settings::OMGF_PRO_PROCESSED_STYLESHEETS, [] ) ?: [];
		// TODO: [OP-65] Write documentation about how to use this handle.
		$this->dynamic_css_handles = apply_filters( 'omgf_pro_optimize_dynamic_css_handles', [ 'load', 'action', 'custom-css' ] );
		
		parent::__construct( false );
	}
	
	/**
	 * Check for @import and @font-face statements inside local stylesheets.
	 * Rewrite them to use local copies and cache them.
	 *
	 * @param string $html
	 *
	 * @return string
	 * @throws \TypeError
	 */
	public function optimize( $html ) {
		$search  = [];
		$replace = [];
		
		/**
		 * @since v3.7.6 Prevent unnecessary writes to the database, by having something to compare to.
		 */
		$processed_local_stylesheets = $this->processed_local_stylesheets;
		
		/**
		 * @since v3.4.5  Use lookaround for stricter matches.
		 * @since v5.2.10 Use [^>] instead of . to confine the match to a single element, because . also matches
		 *                the > which ends it, while it doesn't match the line breaks HTML allows inside (and
		 *                between) attribute values. Line breaks are stripped from the URL further down, just
		 *                like browsers do before requesting it.
		 */
		preg_match_all( '/(?=<link)[^>]+?href=[\'"](?P<urls>[^\'"]+?)[\'"][^>]*>/', $html, $links );
		
		if ( empty( $links['urls'] ) ) {
			return $html; // @codeCoverageIgnore
		}
		
		foreach ( $links['urls'] as $i => $url ) {
			/**
			 * Check if the full match is a stylesheet.
			 */
			if ( ! preg_match( '/\brel\s*=\s*["\'][^"\']*\bstylesheet\b[^"\']*["\']/i', $links[0][ $i ] ) ) {
				continue;
			}

			/**
			 * $full_url is only used for the eventual search/replace and should match the source code verbatim.
			 * Everything else uses the sanitized copy.
			 *
			 * @since v5.2.10
			 */
			$full_url = $url;
			$url      = $this->sanitize_url( $url );

			/**
			 * There's no need to check inside either core or stylesheets we generated ourselves.
			 */
			if ( ( ! str_contains( $url, get_home_url() ) && ! str_starts_with( $url, '/' ) ) ||
			     str_contains( $url, 'wp-includes' ) ||
			     str_contains( $url, Wrapper::get_upload_url() ) ||
			     str_contains( $url, 'omgf-pro-frontend' ) ||
			     str_contains( $url, 'omgf-frontend' ) ) {
				continue;
			}
			
			/**
			 * Fix for protocol-relative URLs.
			 */
			$fixed_url = $this->normalize_url( $url );
			
			/**
			 * @since v5.3.2 Resolve "./" and "../" in the path, e.g., plugins_url( '../assets/style.css', __FILE__ ), like browsers do.
			 *               Otherwise they end up in $cache_path and wp_mkdir_p() refuses to create the cache directory.
			 */
			$fixed_url = $this->remove_dot_segments( $fixed_url );
			
			/**
			 * @since v3.7.6 Fixes [OP-84]: Remove any query parameters from $url. To make sure no duplicate entries are saved in
			 *                              processed_local_stylesheets.
			 * @since v5.3.2 Resolve dot segments in $url as well, so entries saved before v5.3.2 (whose cached copy could never be
			 *               written) don't match anymore, and those stylesheets are processed again.
			 */
			$url = preg_replace( '/\?.*$/', '', $this->remove_dot_segments( $url ) );
			
			/**
			 * To avoid collisions on servers that have allow_url_fopen disabled, we fetch the
			 * contents using absolute paths.
			 *
			 * @since v3.4.4 using content_url is warranted because we need to insert the path to OMGF (Pro)'s upload dir.
			 * @since v3.6.0 Use a preg_replace() to remove any present query parameters from local paths ($local_path and $cache_path)
			 *               Query parameters are allowed in URLs.
			 * @since v3.7.6 Fixes [OP-84]: Query parameters are removed from $cache_url, because we also remove it from $url.
			 *                              It's not like we remove them from the source code, so any present parameters will remain intact.
			 */
			$stripped_url = preg_replace( '/\?.*$/', '', $fixed_url );
			$content_url  = apply_filters( 'omgf_pro_local_stylesheet_content_url', content_url() );
			$local_path   = apply_filters( 'omgf_pro_local_stylesheet_local_path', str_replace( $content_url, WP_CONTENT_DIR, $stripped_url ) );
			$cache_path   = str_replace( $content_url, Wrapper::get_upload_dir(), $stripped_url );
			$cache_url    = str_replace( $content_url, Wrapper::get_upload_url(), $stripped_url );
			
			/**
			 * @since v3.3.2 Add compatibility for themes/plugins using dynamic CSS generator scripts.
			 */
			if ( str_contains( $fixed_url, '?' ) ) {
				$path  = wp_parse_url( $fixed_url, PHP_URL_PATH );
				$query = wp_parse_url( $fixed_url, PHP_URL_QUERY );
				
				foreach ( $this->dynamic_css_handles as $handle ) {
					if ( str_contains( $query, $handle ) && ! str_ends_with( $path, '.css' ) ) {
						/**
						 * If this is a (known) dynamic CSS generator, reset $local_path to URL, because we can't convert that to a local path.
						 */
						$local_path = $fixed_url;
						$cache_path = $this->convert_dynamic_css( $fixed_url, $handle );
						$cache_url  = $this->convert_dynamic_css( $fixed_url, $handle, 'url' );
					}
				}
			}
			
			/**
			 * @since v3.6.2 If we failed to generate a proper cache path, after all our tricks. Let's just bail.
			 *               Prevents "HTTP wrapper does not support writeable connections" errors.
			 */
			if ( str_starts_with( $cache_path, 'http' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * If this stylesheet has been cached previously, assume nothing has changed and continue to the next.
			 */
			if ( ! $this->should_optimize_stylesheet( $url, $cache_path, $processed_local_stylesheets ) ) {
				$search[ $i ]  = $full_url;
				$replace[ $i ] = $this->generate_cache_url( $cache_path, $cache_url );
				
				continue;
			}
			
			/**
			 * @since v3.6.0 If the file isn't cached, but the original file does exist, and it was processed before, bail!
			 */
			if ( ! $this->force_optimize && ! file_exists( $cache_path ) && file_exists( $local_path ) && in_array( $url, $processed_local_stylesheets, true ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$contents   = '';
			$comparison = '';
			
			/**
			 * Encoded characters, e.g., %20 (space), aren't allowed in file paths. Let's decode it.
			 *
			 * @since v4.0.3
			 */
			if ( str_contains( $local_path, '%' ) ) {
				$local_path = urldecode( $local_path ); // @codeCoverageIgnore
			}
			
			/**
			 * @since v5.2.8 Enforce path containment and .css extension for local files to prevent arbitrary file read path traversal.
			 */
			if ( ! str_starts_with( $local_path, 'http' ) ) {
				if ( ! str_ends_with( strtolower( $local_path ), '.css' ) ) {
					continue;
				}
				
				$real_path        = realpath( $local_path );
				$real_content_dir = realpath( WP_CONTENT_DIR );
				
				if ( ! $real_path || ! $real_content_dir ) {
					continue; // @codeCoverageIgnore
				}
				
				$normalized_path        = wp_normalize_path( $real_path );
				$normalized_content_dir = wp_normalize_path( $real_content_dir );
				
				if ( ! str_starts_with( $normalized_path, $normalized_content_dir . '/' ) && $normalized_path !== $normalized_content_dir ) {
					continue;
				}
				
				$local_path = $real_path;
			}
			
			/**
			 * @since v3.4.6 Some themes/plugins insert non-existent files in the HTML, so let's check
			 *               if it exists first, before attempting to fetch the contents.
			 * @since v3.6.0 URLs will always be fetched.
			 */
			if ( str_starts_with( $local_path, 'http' ) || ( ! is_dir( $local_path ) && @file_exists( $local_path ) ) ) {
				$contents   = apply_filters( 'omgf_pro_local_stylesheet_contents', @file_get_contents( $local_path ), $local_path, $url );
				$comparison = $contents;
			}
			
			/**
			 * @since v3.6.0 Mark it as processed before going through it all.
			 */
			if ( ! in_array( $url, $processed_local_stylesheets, true ) && ! is_dir( $local_path ) ) {
				$processed_local_stylesheets[] = $url;
			}
			
			if ( ! $contents ) {
				continue; // @codeCoverageIgnore
			}
			
			$contents = $this->optimize_stylesheet_contents( $contents, $fixed_url, 'local-stylesheet', Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS );
			
			/**
			 * No need to cache it if we didn't change anything.
			 */
			if ( $comparison === $contents ) {
				continue; // @codeCoverageIgnore
			}
			
			$cache_url = $this->save_optimized_stylesheet( $contents, $cache_path, $cache_url );
			
			if ( $cache_url === '' ) {
				continue;
			}
			
			$search[ $i ]  = $full_url;
			$replace[ $i ] = $cache_url;
		}
		
		/**
		 * @since v3.7.6 Prevent unnecessary writes to the database by comparing the updated array with the original copy from the database.
		 */
		if ( ! empty( array_diff( $processed_local_stylesheets, $this->processed_local_stylesheets ) ) ) {
			Wrapper::update_option( Settings::OMGF_PRO_PROCESSED_STYLESHEETS, $processed_local_stylesheets );
		}
		
		if ( empty( $search ) || empty( $replace ) ) {
			return $html;
		}
		
		return str_replace( $search, $replace, $html );
	}
	
	/**
	 * Converts e.g., ./wp-admin/admin-ajax.php?action=kirky-styles to ./wp-content/uploads/omgf/kirky-styles/kirky-styles.css
	 *
	 * @since v3.3.2 Adds (limited) compatibility for themes (e.g., Kirki) and plugins using Dynamic CSS generator scripts.
	 * @since v3.6.0 Added $handle parameter to apply this method with other present params used for dynamic CSS generation, e.g., custom-css
	 *
	 * @param string $url    The requested URL.
	 * @param string $handle The parameter used for storing the stylesheet on the server.
	 * @param string $return path|url
	 *
	 * @return string
	 */
	private function convert_dynamic_css( $url, $handle = 'action', $return = 'path' ) {
		$query = wp_parse_url( html_entity_decode( $url ), PHP_URL_QUERY );
		
		if ( ! $query ) {
			return ''; // @codeCoverageIgnore
		}
		
		parse_str( $query, $params );
		
		$action = $params[ $handle ] ?? '';
		
		if ( ! is_string( $action ) || $action === '' ) {
			return ''; // @codeCoverageIgnore
		}
		
		$action = sanitize_title_with_dashes( $action );
		
		if ( $action === '' ) {
			return '';
		}
		
		if ( $return === 'url' ) {
			return Wrapper::get_upload_url() . '/' . $action . '/' . $action . '.css';
		}
		
		return Wrapper::get_upload_dir() . '/' . $action . '/' . $action . '.css';
	}
}
