<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend;

use OMGF\Pro\Admin\Notice;
use OMGF\Pro\Frontend\MagicFallbacks\FallbackFontStack;
use OMGF\Pro\Helper;
use OMGF\Pro\Wrapper;

class MagicFallbacks {
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action & filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		add_action( 'wp_head', [ $this, 'inject_fallback_fonts_inline' ], 2 );
	}
	
	
	/**
	 * Inject auto-generated @font-face fallback declarations into the <head> of the page.
	 *
	 * @since v5.2.6
	 *
	 * @return void
	 */
	public function inject_fallback_fonts_inline() {
		if ( ! Helper::is_magic_fallbacks_enabled() ) {
			return;
		}
		
		$optimized_fonts = Wrapper::optimized_fonts();
		
		if ( empty( $optimized_fonts ) ) {
			return; // @codeCoverageIgnore
		}
		
		$families = [];
		
		foreach ( $optimized_fonts as $fonts ) {
			foreach ( $fonts as $font ) {
				$families[] = urldecode( $font->family );
			}
		}
		
		$families = array_unique( $families );
		
		if ( empty( $families ) ) {
			return; // @codeCoverageIgnore
		}
		
		$font_face_css = $this->process_font_families( $families );
		
		if ( ! $font_face_css ) {
			return;
		}
		
		echo "<style id='omgf-pro-magic-fallbacks'>\n" . $font_face_css . "\n</style>\n";
	}
	
	/**
	 * Process a list of font families and return the generated @font-face CSS.
	 *
	 * @since v5.2.6
	 *
	 * @param array $families
	 *
	 * @return string
	 */
	private function process_font_families( $families ) {
		$font_face_css      = '';
		$incompatible       = [];
		$no_match           = [];
		$processed_families = [];
		
		foreach ( $families as $family ) {
			/**
			 * @since v5.2.11 Skip values which aren't a font family name, e.g. a complete font
			 *                stack, a var() reference or a generic family. They're leftovers of
			 *                entire documents being parsed for font-family declarations by
			 *                OMGF Pro < v5.2.9, and there's nothing support can do about them.
			 *
			 * @see \OMGF\Helper::is_valid_font_family() Requires OMGF v6.3.11 or higher.
			 * @see \OMGF\Pro\DB\Migrate\V5211           Removes them from the Optimized Fonts table.
			 */
			if ( ! Wrapper::is_valid_font_family( $family ) ) {
				continue;
			}

			/**
			 * @since v5.2.9 Skip Magic Fallback aliases.
			 */
			if ( FallbackFontStack::is_alias( $family ) ) {
				continue;
			}

			/**
			 * @since v5.2.9 Skip icon fonts (e.g. Material Icons/Symbols). They have no
			 *               meaningful text fallback, so no fallback is generated and no
			 *               notice is shown.
			 */
			if ( FallbackFontStack::is_icon_font( $family ) ) {
				continue;
			}

			if ( in_array( $family, $processed_families, true ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$processed_families[] = $family;
			$matches              = FallbackFontStack::find_best_match( $family );
			
			if ( $matches === null ) {
				$incompatible[] = $family;
				
				continue; // @codeCoverageIgnore
			}
			
			if ( empty( $matches ) ) {
				$no_match[] = $family;
				
				continue;
			}
			
			$font_face_css .= FallbackFontStack::generate_font_face_css( $family, $matches );
		}
		
		$this->handle_notices( $incompatible, $no_match );
		
		return $font_face_css;
	}
	
	/**
	 * Handle notices for incompatible or no-match fonts.
	 *
	 * @since v5.2.6
	 *
	 * @param array $incompatible
	 * @param array $no_match
	 *
	 * @return void
	 *
	 * @codeCoverageIgnore
	 */
	private function handle_notices( $incompatible, $no_match ) {
		if ( ! empty( $incompatible ) ) {
			Notice::set_notice(
				sprintf(
					_n( 'Magic Fallbacks didn\'t apply a fallback to <strong>%s</strong> because it\'s a display/handwriting font and it\'s too different from System Fonts to provide a meaningful fallback.',
						'Magic Fallbacks didn\'t apply a fallback to <strong>%s</strong> because they\'re display/handwriting fonts and they\'re too different from System Fonts to provide meaningful fallbacks.',
						count( $incompatible ),
						'omgf-pro'
					),
					esc_html( $this->implode_human_readable( $incompatible ) )
				),
				'info'
			);
		}
		
		if ( ! empty( $no_match ) ) {
			Notice::set_notice(
				sprintf(
					__( 'OMGF Pro could not find a matching fallback font for <strong>%s</strong>. Please <a href="%s" target="_blank" rel="noopener noreferrer">contact support</a> and include this message.', 'omgf-pro' ),
					esc_html( $this->implode_human_readable( $no_match ) ),
					esc_url( 'https://daan.dev/contact/' )
				),
				'info'
			);
		}
	}
	
	/**
	 * Implode an array into a human-readable sentence.
	 * E.g. ['Foo', 'Bar', 'Baz'] => 'Foo, Bar and Baz'
	 *
	 * @param array  $items
	 * @param string $conjunction
	 *
	 * @return string
	 */
	private function implode_human_readable( $items, $conjunction = '' ) {
		if ( empty( $items ) ) {
			return ''; // @codeCoverageIgnore
		}
		
		if ( count( $items ) === 1 ) {
			return $items[0];
		}
		
		$last        = array_pop( $items );
		$conjunction = $conjunction ?: _x( 'and', 'list_conjunction', 'omgf-pro' );
		
		return implode( ', ', $items ) . ' ' . $conjunction . ' ' . $last;
	}
}
