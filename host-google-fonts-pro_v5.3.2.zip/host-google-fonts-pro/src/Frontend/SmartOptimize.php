<?php
/**
 * @since     v5.0.0
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh. All Rights Reserved.
 * @package   OMGF Pro
 */

namespace OMGF\Pro\Frontend;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize as SmartOptimizeAPI;
use OMGF\Pro\Helper;
use OMGF\Pro\UnicodeRanges;
use OMGF\Pro\Wrapper;

class SmartOptimize {
	/**
	 * Paths of stylesheets which have nothing left to load, either because all their @font-face rules
	 * were filtered out, or because the entire stylesheet is unused. Their <link> elements are removed
	 * from the HTML entirely.
	 *
	 * @var array $empty_stylesheets
	 * @see   SmartOptimize::remove_empty_stylesheets()
	 * @since v5.2.9
	 *
	 */
	private $empty_stylesheets = [];
	
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action/filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		/**
		 * Logged-in Admin users only.
		 */
		add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_items' ], 100 );
		add_action( 'template_redirect', [ $this, 'maybe_delete_db_entry' ] );
		
		/**
		 * All users.
		 */
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_replace_async_stylesheet' ], 100 );
		add_filter( 'omgf_process_search_replace', [ $this, 'inject_stylesheet' ] );
		add_filter( 'omgf_pro_process_inline_stylesheet', [ $this, 'inject_inline_stylesheet' ] );
		add_filter( 'omgf_pro_process_stylesheet_contents', [ $this, 'inject_stylesheet_contents' ], 10, 3 );
		add_action( 'omgf_frontend_process_preloads', [ $this, 'maybe_add_smart_preloads' ], 2 );
		/**
		 * Runs after OMGF (10) processed the HTML, i.e. after all search/replaces are applied.
		 *
		 * @see SmartOptimize::inject_stylesheet()
		 */
		add_filter( 'omgf_processed_html', [ $this, 'remove_empty_stylesheets' ], 20 );
	}
	
	/**
	 * Add Smart Optimize results to the Admin Bar.
	 *
	 * @param \WP_Admin_Bar $wp_admin_bar
	 *
	 * @return void
	 */
	public function add_admin_bar_items( $wp_admin_bar ) {
		if ( ! $this->is_enabled() ) {
			return;
		}
		
		$devices = [
			'desktop' => [
				'title'     => __( 'Desktop', 'omgf-pro' ),
				'is_mobile' => 0,
			],
			'mobile'  => [
				'title'     => __( 'Mobile', 'omgf-pro' ),
				'is_mobile' => 1,
			],
		];
		
		foreach ( $devices as $id => $device ) {
			$results = Helper::get_smart_optimize_results( '', $device['is_mobile'] );
			
			if ( ! $results ) {
				continue; // @codeCoverageIgnore
			}
			
			$labels = json_decode( $results->labels, true );
			
			if ( empty( $labels ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$wp_admin_bar->add_node(
				[
					'id'     => 'omgf-' . $id,
					'parent' => 'omgf',
					'title'  => $device['title'],
				]
			);
			
			if ( ! empty( $labels['preloaded'] ) ) {
				$wp_admin_bar->add_node(
					[
						'id'     => "omgf-$id-smart-preloaded",
						'parent' => "omgf-$id",
						'title'  => __( 'Preloaded', 'omgf-pro' ),
					]
				);
				
				foreach ( $labels['preloaded'] as $font ) {
					$wp_admin_bar->add_node(
						[
							'id'     => "omgf-$id-smart-preloaded-" . sanitize_title( $font ),
							'parent' => "omgf-$id-smart-preloaded",
							'title'  => esc_html( $font ),
						]
					);
				}
			}
			
			if ( ! empty( $labels['unloaded'] ) ) {
				$wp_admin_bar->add_node(
					[
						'id'     => "omgf-$id-smart-unloaded",
						'parent' => "omgf-$id",
						'title'  => __( 'Unloaded', 'omgf-pro' ),
					]
				);
				
				foreach ( $labels['unloaded'] as $family => $variants ) {
					$family_id = sanitize_title( $family );
					
					$wp_admin_bar->add_node(
						[
							'id'     => "omgf-$id-smart-unloaded-" . $family_id,
							'parent' => "omgf-$id-smart-unloaded",
							'title'  => esc_html( $family ),
						]
					);
					
					foreach ( $variants as $variant ) {
						$wp_admin_bar->add_node(
							[
								'id'     => "omgf-$id-smart-unloaded-" . $family_id . '-' . sanitize_title( $variant ),
								'parent' => "omgf-$id-smart-unloaded-" . $family_id,
								'title'  => esc_html( $variant ),
							]
						);
					}
				}
			}
		}
	}
	
	/**
	 * Filters unused @font-face rules from inline stylesheets.
	 *
	 * @param string $html
	 *
	 * @return string
	 */
	public function inject_inline_stylesheet( $html ) {
		/**
		 * Other plugins can hook into this filter, too, so we can't assume we're handed a string.
		 *
		 * @since v5.2.10
		 */
		if ( ! is_string( $html ) || $html === '' ) {
			return $html; // @codeCoverageIgnore
		}
		
		$unloaded = $this->get_unloaded_fonts();
		
		if ( ! $unloaded ) {
			return $html; // @codeCoverageIgnore
		}
		
		$inline_handles = array_filter(
			$unloaded,
			function ( $key ) {
				return str_starts_with( $key, 'inline-font-face' ) || str_starts_with( $key, 'inline-import' );
			},
			ARRAY_FILTER_USE_KEY
		);
		
		if ( empty( $inline_handles ) ) {
			return $html; // @codeCoverageIgnore
		}
		
		/**
		 * Clean up @import statements, if all the font-face statements in the corresponding stylesheet are marked for unloading.
		 */
		$optimized_fonts = Wrapper::optimized_fonts();
		
		foreach ( $inline_handles as $handle => $fonts ) {
			if ( ! str_starts_with( $handle, 'inline-import' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			/**
			 * We normalize the handle because it might contain characters that are not allowed in a handle.
			 */
			$sanitized_handle = $this->normalize_stylesheet_handle( $handle );
			
			if ( ! $sanitized_handle ) {
				continue; // @codeCoverageIgnore
			}
			
			if ( ! isset( $optimized_fonts[ $handle ] ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$total_variants = 0;
			$unloaded_count = count( $fonts );
			
			foreach ( $optimized_fonts[ $handle ] as $font ) {
				$total_variants += count( $font->variants );
			}
			
			if ( $unloaded_count < $total_variants ) {
				continue; // @codeCoverageIgnore
			}
			
			$url = Wrapper::get_upload_url() . '/' . $sanitized_handle;
			
			/**
			 * [^;{}] can't cross a statement (;) or a block ({}) boundary, which confines the match to
			 * a single @import statement, even when the entire document is minified into one line.
			 *
			 * Its predecessor combined a greedy dot with a negative lookahead. Because that lookahead
			 * was accidentally written as (?!`@import`) — with backticks — it never asserted anything,
			 * so on minified HTML the match ran from the first @import all the way to the last
			 * occurrence of $url, removing every byte in between. On documents larger than ~100KB it
			 * also exceeded PCRE's runtime limits, in which case preg_replace() returns null and the
			 * whole document is lost.
			 *
			 * @since v5.2.10
			 */
			$html = $this->maybe_replaced(
				preg_replace(
					'/@import[^;{}]*?([\'"]|url\([\'"]?)' . preg_quote( $url, '/' ) . '[^\'")]*[\'")]{1,2};/i',
					'',
					$html
				),
				$html
			);
		}
		
		return $this->filter_font_faces( $html, $inline_handles );
	}
	
	/**
	 * @return array|false
	 */
	private function get_unloaded_fonts() {
		$results = $this->get_results();
		
		if ( ! $results ) {
			return false; // @codeCoverageIgnore
		}
		
		$unloaded = json_decode( $results->unload, true );
		
		if ( ! is_array( $unloaded ) ) {
			return false; // @codeCoverageIgnore
		}
		
		return $unloaded;
	}
	
	/**
	 * @return object|false
	 */
	private function get_results() {
		/**
		 * @since v5.3.2 Stored results (i.e. unloads, too) are only applied while Smart Optimize is enabled, so they're
		 *               kept for when it's enabled again.
		 */
		if ( ! $this->is_enabled() ) {
			return false;
		}
		
		$is_mobile = wp_is_mobile() ? 1 : 0;
		$results   = Helper::get_smart_optimize_results( '', $is_mobile );
		
		if ( ! $results ) {
			return false; // @codeCoverageIgnore
		}
		
		return $results;
	}
	
	/**
	 * @since v5.3.2
	 *
	 * @return bool
	 */
	private function is_enabled() {
		return (bool) Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE );
	}
	
	/**
	 * Prevents CSRF and XSS attacks by making sure the stylesheet handle doesn't contain malicious code.
	 *
	 * @param $stylesheet_handle
	 *
	 * @return string
	 */
	private function normalize_stylesheet_handle( $stylesheet_handle ) {
		$normalized = sanitize_key( $stylesheet_handle );
		
		return $normalized === $stylesheet_handle && $normalized !== '' ? $normalized : '';
	}
	
	/**
	 * PCRE aborts a match (and preg_* returns null) when a pattern exceeds one of its runtime limits,
	 * e.g. pcre.backtrack_limit or the JIT stack size. Since the return value is assigned to the
	 * variable holding the stylesheet — or, for inline styles, the entire HTML document — a null
	 * return would wipe its contents, and every subsequent preg_* call would raise
	 * 'Passing null to parameter #3 ($subject)'.
	 *
	 * Leaving a font loaded is a cosmetic issue. Emptying the document isn't. So, whenever a
	 * search/replace fails, we hand back the untouched subject.
	 *
	 * @since v5.2.10
	 *
	 * @param string|null $result  Return value of a preg_replace()/preg_replace_callback() call.
	 * @param string      $subject The subject that was passed to that same call.
	 *
	 * @return string The replaced string, or the untouched subject if the replacement failed.
	 */
	private function maybe_replaced( $result, $subject ) {
		if ( is_string( $result ) ) {
			return $result;
		}
		
		
		Wrapper::debug( sprintf( 'Smart Optimize: search/replace skipped, because PCRE returned error code %s.', preg_last_error() ) ); // @codeCoverageIgnore
		
		return $subject; // @codeCoverageIgnore
	}
	
	/**
	 * Filters unused @font-face rules from the provided CSS contents.
	 *
	 * @param string $contents
	 * @param array  $unloaded_fonts
	 *
	 * @return string
	 */
	private function filter_font_faces( $contents, $unloaded_fonts ) {
		if ( ! is_string( $contents ) || trim( $contents ) === '' ) {
			return ''; // @codeCoverageIgnore
		}
		
		foreach ( $unloaded_fonts as $fonts ) {
			foreach ( $fonts as $font ) {
				$family = $font['family'];
				$weight = $font['weight'];
				$style  = $font['style'];
				$subset = $font['subset'] ?? '';
				
				$filtered = preg_replace_callback(
					'/@font-face\s*(\{(?:[^{}]++|(?1))*\})/si',
					function ( $match ) use ( $family, $weight, $style, $subset ) {
						$font_face    = $match[0];
						$family_match = preg_match( '/font-family\s*:\s*[\'"]?' . preg_quote( $family, '/' ) . '[\'"]?\s*;/i', $font_face );
						$weight_match = preg_match( '/font-weight\s*:\s*' . preg_quote( $weight, '/' ) . '\s*;/i', $font_face );
						$style_match  = preg_match( '/font-style\s*:\s*' . preg_quote( $style, '/' ) . '\s*;/i', $font_face );
						$subset_match = $this->subset_matches( $font_face, $subset );
						
						if ( $family_match && $weight_match && $style_match && $subset_match ) {
							return '';
						}
						
						return $font_face;
					},
					$contents
				);
				
				/**
				 * Bail out on the content we have, instead of retrying a pattern that just failed for
				 * every remaining variant.
				 *
				 * @since v5.2.10
				 */
				if ( $filtered === null ) {
					return $this->maybe_replaced( $filtered, $contents ); // @codeCoverageIgnore
				}
				
				$contents = $filtered;
			}
		}
		
		$contents = $this->maybe_replaced( preg_replace( '/\n{3,}/', "\n\n", $contents ), $contents );
		
		return trim( $contents ) === '' ? '' : $contents;
	}
	
	/**
	 * Checks if the provided @font-face rule belongs to the provided subset.
	 *
	 * The rule's unicode-range is the authoritative identifier of its subset, and it's the exact same
	 * value @see \OMGF\Pro\API\SmartOptimize::normalize_unloads() derived $subset from. So, if a known
	 * subset defines one, its verdict is final: a mismatch means the rule belongs to a different subset
	 * and must be left alone. Inline @font-face rules don't always define a unicode-range, so for those
	 * we match the subset in the font file's URL instead, e.g. jost-normal-latin-400.woff2.
	 *
	 * @since v5.2.9
	 *
	 * @param string $font_face A single @font-face rule.
	 * @param string $subset    e.g. 'latin', 'latin-ext' or '' if the subset couldn't be determined.
	 *
	 * @return bool
	 */
	private function subset_matches( $font_face, $subset ) {
		if ( empty( $subset ) ) {
			return true;
		}
		
		if ( isset( UnicodeRanges::MAP[ $subset ] ) && preg_match( '/unicode-range\s*:\s*([^;}]+)/i', $font_face, $match ) ) {
			$range = strtoupper( preg_replace( '/\s+/', '', UnicodeRanges::pad( $match[1] ) ) );
			
			return $range === strtoupper( UnicodeRanges::MAP[ $subset ] );
		}
		
		/**
		 * The negative lookahead prevents 'latin' from matching 'latin-ext' (and likewise for
		 * 'cyrillic' and 'greek') while still allowing the hyphen which separates the subset from
		 * the font-weight in OMGF's filenames.
		 */
		return (bool) preg_match(
			'/(?:^|[-_\/\s])' . preg_quote( $subset, '/' ) . '(?!-ext)(?=[-_.\/\s]|$)/i',
			$font_face
		);
	}
	
	/**
	 * Generate filtered Smart Optimize stylesheets.
	 *
	 * @param array $search_replace
	 *
	 * @return array
	 */
	public function inject_stylesheet( $search_replace ) {
		$results = $this->get_results();
		
		if ( ! $results || empty( $results->stylesheet_hash ) ) {
			return $search_replace; // @codeCoverageIgnore
		}
		
		$unloaded_fonts = $this->get_unloaded_fonts();
		
		if ( ! $unloaded_fonts ) {
			return $search_replace; // @codeCoverageIgnore
		}
		
		foreach ( $unloaded_fonts as $stylesheet_handle => $fonts ) {
			$stylesheet_handle = $this->normalize_stylesheet_handle( $stylesheet_handle );
			
			if ( ! $stylesheet_handle ) {
				continue;
			}
			
			/**
			 * The Material Icons stylesheet should be removed entirely if it's not used.
			 *
			 * We iterate the replace array, because the search array holds the URL as it appears in the
			 * HTML, i.e. the original Google Fonts URL, which never matches the stylesheet's handle.
			 *
			 * @since v5.2.10
			 */
			if ( str_starts_with( $stylesheet_handle, 'material-icons' ) ) {
				foreach ( $search_replace['replace'] as $key => $url ) {
					if ( $this->is_stylesheet_match( $url, $stylesheet_handle ) ) {
						$this->empty_stylesheets[] = wp_parse_url( $url, PHP_URL_PATH ) ?: $url;
						
						break;
					}
				}
				
				continue;
			}
			
			$output_path = Wrapper::get_upload_dir() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
			$output_url  = Wrapper::get_upload_url() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
			
			if ( ! file_exists( $output_path ) ) {
				$optimized_fonts = Wrapper::optimized_fonts();
				
				if ( ! isset( $optimized_fonts[ $stylesheet_handle ] ) ) {
					continue; // @codeCoverageIgnore
				}
				
				$stylesheet = Wrapper::generate_stylesheet( $optimized_fonts[ $stylesheet_handle ] );
				$stylesheet = $this->filter_font_faces( $stylesheet, [ $stylesheet_handle => $fonts ] );
				
				/**
				 * A generated stylesheet always starts with a header comment, so its @font-face rules
				 * (and not its length) determine whether there's anything left to load. Truncating it
				 * allows all consumers to simply check the file's size.
				 *
				 * @see   \OMGF\StylesheetGenerator::generate()
				 * @see   SmartOptimize::maybe_replace_async_stylesheet()
				 * @since v5.2.9
				 */
				if ( ! str_contains( $stylesheet, '@font-face' ) ) {
					$stylesheet = '';
				}
				
				wp_mkdir_p( dirname( $output_path ) );
				
				$written = file_put_contents( $output_path, $stylesheet );
				
				if ( $written === false ) {
					continue; // @codeCoverageIgnore
				}
				
				$is_empty = $stylesheet === '';
			} else {
				$is_empty = filesize( $output_path ) === 0;
			}
			
			/**
			 * If every @font-face rule was filtered out, there's nothing left to load, so the entire
			 * element is removed from the HTML instead of requesting an empty stylesheet.
			 *
			 * @since v5.2.9
			 */
			if ( $is_empty ) {
				$this->empty_stylesheets[] = wp_parse_url( $output_url, PHP_URL_PATH ) ?: $output_url;
			}
			
			$timestamp = Wrapper::get_option( 'omgf_cache_timestamp' );
			
			foreach ( $search_replace['replace'] as $key => $url ) {
				if ( $this->is_stylesheet_match( $url, $stylesheet_handle ) ) {
					$search_replace['replace'][ $key ] = $output_url . '?ver=' . $timestamp;
					break;
				}
			}
		}
		
		return $search_replace;
	}
	
	/**
	 * Checks if the provided URL matches the stylesheet handle.
	 *
	 * @param string $url
	 * @param string $stylesheet_handle
	 *
	 * @return bool
	 */
	private function is_stylesheet_match( $url, $stylesheet_handle ) {
		$expected_segment = "/{$stylesheet_handle}/{$stylesheet_handle}.css";
		$basename         = "{$stylesheet_handle}.css";
		
		return str_contains( $url, $expected_segment ) || basename( parse_url( $url, PHP_URL_PATH ) ) === $basename;
	}
	
	/**
	 * @param string $contents
	 * @param string $handle_prefix
	 * @param string $url
	 *
	 * @return string
	 */
	public function inject_stylesheet_contents( $contents, $handle_prefix, $url ) {
		$results = $this->get_results();
		
		if ( ! $results || empty( $results->stylesheet_hash ) ) {
			return $contents; // @codeCoverageIgnore
		}
		
		$unloaded = $this->get_unloaded_fonts();
		
		if ( ! $unloaded ) {
			return $contents; // @codeCoverageIgnore
		}
		
		foreach ( array_keys( $unloaded ) as $stylesheet_handle ) {
			$stylesheet_handle = $this->normalize_stylesheet_handle( $stylesheet_handle );
			
			if ( ! $stylesheet_handle || ! str_starts_with( $stylesheet_handle, $handle_prefix ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$output_path = Wrapper::get_upload_dir() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
			$output_url  = Wrapper::get_upload_url() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
			
			if ( ! file_exists( $output_path ) ) {
				$filtered = $this->filter_font_faces( $contents, [ $stylesheet_handle => $unloaded[ $stylesheet_handle ] ] );
				
				wp_mkdir_p( dirname( $output_path ) );
				
				$written = file_put_contents( $output_path, $filtered );
				
				if ( $written === false ) {
					continue; // @codeCoverageIgnore
				}
			}
			
			$contents = str_replace(
				Wrapper::get_upload_url() . '/' . $stylesheet_handle . '/' . $stylesheet_handle . '.css',
				$output_url,
				$contents
			);
		}
		
		return $contents;
	}
	
	/**
	 * Inject Smart Preloads into wp_head.
	 *
	 * For future reference: we use our own logic to add Smart Preloads, and not OMGF's @filter omgf_filter_preloaded_fonts because we
	 * want to support all fonts, e.g., Icon Packs and not just Google Fonts.
	 *
	 * @return void
	 */
	public function maybe_add_smart_preloads() {
		if ( ! Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) {
			return; // @codeCoverageIgnore
		}
		
		$results = $this->get_results();
		
		if ( ! $results || empty( $results->preload ) ) {
			return; // @codeCoverageIgnore
		}
		
		$preloads = json_decode( $results->preload, true );
		
		if ( ! is_array( $preloads ) ) {
			return; // @codeCoverageIgnore
		}
		
		$unloaded_stylesheets = Wrapper::unloaded_stylesheets();
		$upload_url           = Wrapper::get_upload_url();
		
		$count = 0;
		
		foreach ( $preloads as $preload ) {
			if ( empty( $preload['url'] ) ) {
				continue; // @codeCoverageIgnore
			}
			
			$url = $preload['url'];
			
			/**
			 * Only add the timestamp to font files cached by us.
			 */
			if ( str_contains( $url, $upload_url ) ) {
				$url = add_query_arg( 'ver', Wrapper::get_option( 'omgf_cache_timestamp' ), $url );
			}
			
			$url         = esc_url( $url );
			$should_load = true;
			
			foreach ( $unloaded_stylesheets as $stylesheet_handle ) {
				if ( str_contains( $preload['url'], $stylesheet_handle ) ) {
					$should_load = false;
					
					break;
				}
			}
			
			if ( ! $should_load ) {
				continue;
			}
			
			$path = wp_parse_url( $preload['url'], PHP_URL_PATH ) ?: '';
			$ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
			$mime = array_search( $ext, Wrapper::mime_map(), true );
			$type = $mime !== false ? "type='" . $mime . "'" : '';
			
			echo wp_kses(
				"<link id='omgf-pro-smart-preload-$count' rel='preload' href='{$url}' as='font' {$type} crossorigin />\n",
				[ 'link' => [ 'id' => true, 'rel' => true, 'href' => true, 'as' => true, 'type' => true, 'crossorigin' => true ] ]
			);
			
			$count ++;
		}
	}
	
	/**
	 * Deletes the Smart Optimize results for the current URL.
	 *
	 * @return void
	 */
	public function maybe_delete_db_entry() {
		if ( ! isset( $_GET[ SmartOptimizeAPI::ID ] ) || ! Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) {
			return; // @codeCoverageIgnore
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			return; // @codeCoverageIgnore
		}
		
		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), SmartOptimizeAPI::ID ) ) {
			return; // @codeCoverageIgnore
		}
		
		global $wpdb;
		
		$table_name     = $wpdb->prefix . SmartOptimizeAPI::ID;
		$path           = Helper::normalize_smart_optimize_path();
		$stored_results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE url = %s", $path ) );
		
		if ( $stored_results ) {
			foreach ( $stored_results as $row ) {
				$unloaded = json_decode( $row->unload ?? '', true );
				$hash     = $row->stylesheet_hash;
				
				if ( is_array( $unloaded ) && $hash ) {
					foreach ( array_keys( $unloaded ) as $stylesheet_handle ) {
						$stylesheet_handle = $this->normalize_stylesheet_handle( $stylesheet_handle );
						
						if ( ! $stylesheet_handle ) {
							continue; // @codeCoverageIgnore
						}
						
						$hash_dir = Wrapper::get_upload_dir() . '/smart-optimize/' . $stylesheet_handle . '/' . $hash;
						
						if ( is_dir( $hash_dir ) ) {
							$files = glob( $hash_dir . '/*' );
							if ( is_array( $files ) ) {
								foreach ( $files as $file ) {
									if ( is_file( $file ) ) {
										@unlink( $file );
									}
								}
							}
							@rmdir( $hash_dir );
						}
					}
				}
			}
		}
		
		$wpdb->delete( $table_name, [ 'url' => $path ] );
		
		do_action( 'omgf_pro_smart_optimize_entry_deleted', $path );
		
		/** @codingStandardsIgnoreStart */
		if ( ! defined( 'DAAN_DOING_TESTS' ) ) {
			wp_safe_redirect( remove_query_arg( [ SmartOptimizeAPI::ID, '_wpnonce' ] ) );
			
			exit;
		}
		/** @codingStandardsIgnoreEnd */
	}
	
	/**
	 * Replace Async Stylesheets with Smart Optimize Stylesheets.
	 *
	 * @return void
	 */
	public function maybe_replace_async_stylesheet() {
		global $wp_styles;
		
		$results = $this->get_results();
		
		if ( ! $results || empty( $results->stylesheet_hash ) ) {
			return; // @codeCoverageIgnore
		}
		
		$unloaded = $this->get_unloaded_fonts();
		
		if ( ! $unloaded ) {
			return; // @codeCoverageIgnore
		}
		
		foreach ( array_keys( $unloaded ) as $stylesheet_handle ) {
			$stylesheet_handle = $this->normalize_stylesheet_handle( $stylesheet_handle );
			
			if ( ! $stylesheet_handle ) {
				continue; // @codeCoverageIgnore
			}
			
			// Only process Async Stylesheets.
			if ( ! str_starts_with( $stylesheet_handle, 'omgf-pro-async-fonts' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			if ( isset( $wp_styles->registered[ $stylesheet_handle ] ) ) {
				$output_path = Wrapper::get_upload_dir() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
				
				if ( ! file_exists( $output_path ) ) {
					continue; // @codeCoverageIgnore
				}
				
				// If the stylesheet is empty, deregister it.
				if ( filesize( $output_path ) === 0 ) {
					wp_deregister_style( $stylesheet_handle );
					
					continue;
				}
				
				$output_url                                       = Wrapper::get_upload_url() . '/smart-optimize/' . $stylesheet_handle . '/' . $results->stylesheet_hash . '/' . $results->stylesheet_hash . '.css';
				$wp_styles->registered[ $stylesheet_handle ]->src = $output_url;
			}
		}
	}
	
	/**
	 * Removes the <link> elements of stylesheets which have nothing left to load, because all of their
	 * @font-face rules were filtered out, or because the entire stylesheet is unused.
	 *
	 * @filter    omgf_processed_html
	 * @see       SmartOptimize::inject_stylesheet()
	 * @since     v5.2.9
	 *
	 * @param string $html Valid HTML.
	 *
	 * @return string Valid HTML.
	 */
	public function remove_empty_stylesheets( $html ) {
		if ( empty( $this->empty_stylesheets ) ) {
			return $html;
		}
		
		foreach ( array_unique( $this->empty_stylesheets ) as $path ) {
			/**
			 * We match on the path, because OMGF can be configured to write either absolute or
			 * root relative URLs to the HTML. The path must be followed by nothing but an optional
			 * query string or fragment, to prevent matching a longer, different filename.
			 */
			$html = $this->maybe_replaced(
				preg_replace(
					'/<link[^>]+href=([\'"])[^\'"]*' . preg_quote( $path, '/' ) . '(?:[?#][^\'"]*)?\1[^>]*>/i',
					'',
					$html
				),
				$html
			);
		}
		
		return $html;
	}
}
