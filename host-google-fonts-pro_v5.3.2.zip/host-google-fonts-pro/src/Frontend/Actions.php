<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro\Frontend;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\API\SmartOptimize;
use OMGF\Pro\Frontend\SmartOptimize\TrustedHosts;
use OMGF\Pro\Helper;
use OMGF\Pro\Plugin;
use OMGF\Pro\Wrapper;

class Actions {
	const FRONTEND_ASSET_HANDLE = 'omgf-pro-frontend';
	
	/**
	 * Execute all actions required in the frontend.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'do_frontend_optimize' ], 49 );
		add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_item' ], 1001 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_add_google_fonts_checker_assets' ], 11 );
	}
	
	/**
	 * @param \WP_Admin_Bar $admin_bar
	 *
	 * @return void
	 */
	public function add_admin_bar_item( \WP_Admin_Bar $admin_bar ) {
		/**
		 * Display only in the frontend, for logged-in admins.
		 */
		if ( ! defined( 'DAAN_DOING_TESTS' ) && ( ! current_user_can( 'manage_options' ) || is_admin() ) ) {
			return; // @codeCoverageIgnore
		}
		
		global $wp;
		
		$permalink_structure = get_option( 'permalink_structure' );
		$site_url            = home_url( $wp->request );
		
		if ( ! $permalink_structure ) {
			foreach ( $wp->query_vars as $query_var_key => $query_var_value ) {
				$site_url = add_query_arg( $query_var_key, $query_var_value, $site_url );
			}
		}
		
		$nonce    = wp_create_nonce( SmartOptimize::ID );
		$site_url = add_query_arg( [ 'omgf_optimize' => wp_create_nonce( 'omgf_optimize' ), 'omgf_pro_auto_config' => 1, SmartOptimize::ID => 1, '_wpnonce' => $nonce ], $site_url );
		
		$admin_bar->remove_menu( 'omgf-optimize-this' );
		
		$admin_bar->add_menu(
			[
				'id'     => 'omgf-pro-smart-optimize',
				'parent' => 'omgf',
				'title'  => __( 'Re-scan & optimize this page', 'omgf-pro' ),
				'href'   => $site_url,
			]
		);

		$pending_hosts = $this->get_pending_hosts_count();

		/**
		 * @since v5.3.0 Notify the administrator of 3rd party font hosts awaiting approval.
		 * @see   \OMGF\Pro\Admin\TrustedHosts::maybe_render_pending_hosts()
		 */
		if ( $pending_hosts > 0 ) {
			$admin_bar->add_menu(
				[
					'id'     => 'omgf-pro-pending-hosts',
					'parent' => 'omgf',
					'title'  => esc_html(
						sprintf(
						/* translators: %d: number of font hosts */
							_n(
								'Smart Optimize needs your approval for %d font host',
								'Smart Optimize needs your approval for %d font hosts',
								$pending_hosts,
								'omgf-pro'
							),
							$pending_hosts
						)
					),
					'href'   => admin_url( \OMGF\Admin\Settings::OMGF_OPTIONS_GENERAL_PAGE_OPTIMIZE_WEBFONTS ) . '#dashboard-notice-smart-optimize-pending-hosts',
					'meta'   => [ 'class' => 'info' ],
				]
			);
		}
	}

	/**
	 * Number of 3rd party font hosts awaiting approval, for administrators only (and if Smart Optimize is enabled).
	 *
	 * @return int
	 */
	private function get_pending_hosts_count() {
		if ( ! current_user_can( 'manage_options' ) || ! Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ) ) {
			return 0;
		}

		return count( TrustedHosts::get_pending_hosts() );
	}
	
	/**
	 * Run frontend Optimization logic.
	 */
	public function do_frontend_optimize() {
		if ( Plugin::$halt ) {
			return; // @codeCoverageIgnore
		}
		
		new Optimize();
	}
	
	/**
	 * Add Frontend JS if user is admin, or when option is enabled.
	 *
	 * @return void
	 */
	public function maybe_add_google_fonts_checker_assets() {
		if ( ! wp_script_is( 'omgf-frontend', 'registered' ) ) {
			return;
		}
		
		wp_localize_script( 'omgf-frontend', 'omgf_frontend_results', [
			'skip' => (bool) Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ),
		] );
		
		$file_ext = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$js_url   = OMGF_PRO_PLUGIN_URL . "assets/js/omgf-pro-frontend$file_ext.js";
		$js_path  = OMGF_PRO_PLUGIN_DIR . "assets/js/omgf-pro-frontend$file_ext.js";
		
		$smart_optimize_path = Helper::get_smart_optimize_path();
		
		wp_register_script( self::FRONTEND_ASSET_HANDLE, $js_url, [ 'omgf-frontend' ], filemtime( $js_path ) );
		wp_localize_script(
			self::FRONTEND_ASSET_HANDLE,
			'omgf_pro_frontend_i18n',
			[
				/**
				 * @since v5.3.2 No nonce for logged-out visitors: it's the same for everyone and public (in the HTML), so
				 *               it doesn't protect anything, but it does expire in pages served from a page cache.
				 * @see   \OMGF\Pro\API\SmartOptimize::get_permission()
				 */
				'nonce'                         => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
				'optimize_notice_title'         => __( 'Re-scan & optimize this page', 'omgf-pro' ),
				'optimize_notice_text'          => __( 'This page will reload a few times while OMGF Pro scans and optimizes your fonts. Please wait until the stoplight in the admin bar turns green.', 'omgf-pro' ),
				'optimize_notice_button_text'   => __( 'Optimize now', 'omgf-pro' ),
				'smart_optimize_endpoint'       => get_rest_url( null, SmartOptimize::$namespace . '/' . SmartOptimize::$base . '/' . SmartOptimize::$endpoint ),
				// The page's canonical path, signed, because the API only stores results for paths generated by this site.
				'smart_optimize_path'           => $smart_optimize_path,
				'smart_optimize_signature'      => Helper::sign_smart_optimize_path( $smart_optimize_path ),
				// Results are stored for the same device type they're looked up with, i.e. by user agent.
				'smart_optimize_is_mobile'      => wp_is_mobile() ? 1 : 0,
				'smart_optimize_stylesheet_url' => OMGF_PRO_PLUGIN_URL . 'assets/css/omgf-pro-frontend-google-fonts.min.css',
				'smart_optimize_enabled'        => (bool) Wrapper::get_option( Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ),
				// Used to turn the stoplight blue. Always 0 for visitors.
				'pending_hosts'                 => $this->get_pending_hosts_count(),
			]
		);
		wp_enqueue_script( self::FRONTEND_ASSET_HANDLE );
		
		// CSS is only needed if OMGF loads its own CSS.
		if ( ! wp_style_is( 'omgf-frontend', 'registered' ) ) {
			return;
		}
		
		$css_url  = OMGF_PRO_PLUGIN_URL . "assets/css/omgf-pro-frontend$file_ext.css";
		$css_path = OMGF_PRO_PLUGIN_DIR . "assets/css/omgf-pro-frontend$file_ext.css";
		
		wp_enqueue_style( self::FRONTEND_ASSET_HANDLE, $css_url, [ 'omgf-frontend' ], filemtime( $css_path ) );
	}
}
