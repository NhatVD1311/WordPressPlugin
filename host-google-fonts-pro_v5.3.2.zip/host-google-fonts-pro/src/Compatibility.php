<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro;

/**
 * This class contains compatibility fixes needed in frontend and admin.
 * For frontend only fixes, @see Frontend\Optimize\Compatibility!
 *
 * @codeCoverageIgnore because it depends on 3rd party code.
 */
class Compatibility {
	const USER_AGENT_AVADA_COMPATIBILITY = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36';
	
	/**
	 * Build class.
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Action and filter hooks.
	 *
	 * @return void
	 */
	private function init() {
		/** Avada */
		add_filter( 'omgf_optimize_user_agent', [ $this, 'avada_compatibility' ] );
		
		/** BunnyCDN */
		add_filter( 'omgf_pro_modify_source_url', [ $this, 'bunnycdn_compatibility' ] );
		
		/**
		 * Multisite
		 * TranslatePress
		 * WPML
		 */
		add_filter( 'omgf_setting_dtap', [ $this, 'maybe_force_dev_mode' ] );
		add_filter( 'omgf_developer_mode_description', [ $this, 'maybe_modify_dev_mode_description' ] );
		
		/**
		 * Plugins loaded after OMGF Pro, e.g. WooCommerce.
		 */
		add_action( 'plugins_loaded', [ $this, 'load_plugin_compatibility_fixes' ] );
	}
	
	/**
	 * Load compatibility fixes for 3rd party plugins, once all plugins are loaded.
	 *
	 * @since  v5.3.2
	 *
	 * @action plugins_loaded
	 *
	 * @return void
	 */
	public function load_plugin_compatibility_fixes() {
		if ( class_exists( 'WooCommerce' ) ) {
			new Compatibility\WooCommerce();
		}
	}
	
	/**
	 * Compatibility with Avada, to make sure we both use the same user agents.
	 *
	 * @filter omgf_optimize_user_agent
	 *
	 * @return string
	 */
	public function avada_compatibility( $user_agent ) {
		$theme  = wp_get_theme();
		$parent = $theme->parent();
		
		if ( ( $theme instanceof \WP_Theme && $theme->get_template() !== 'Avada' ) || ( $parent instanceof \WP_Theme && $parent->get( 'Name' ) !== 'Avada' ) ) {
			return $user_agent; // @codeCoverageIgnore
		}
		
		return self::USER_AGENT_AVADA_COMPATIBILITY;
	}
	
	/**
	 * Provides compatibility fixes with Bunny CDN. Uses content_url() to determine the correct wp-content directory.
	 * Makes any rewrites needed to be compatible with Bunny CDN.
	 *
	 * @since  v3.4.6 Added compatibility with Bunny CDN.
	 *
	 * @filter omgf_pro_modify_source_url
	 *
	 * @return string An absolute URL pointing to OMGF's uploads directory, e.g. https://yoursite.com/wp-content/uploads/omgf
	 */
	public function bunnycdn_compatibility( $source_url ) {
		if ( apply_filters( 'omgf_pro_bunnycdn_compatibility', ! defined( 'BUNNYCDN_WP_VERSION' ) ) ) {
			return $source_url;
		}
		
		$bunny_cdn_hostname = get_option( 'bunnycdn_cdn_hostname' );
		
		if ( ! $bunny_cdn_hostname ) {
			return $source_url; // @codeCoverageIgnore
		}
		
		$is_ssl = str_starts_with( get_home_url(), 'https://' );
		
		// This is a relative URL. Fix it.
		if ( str_starts_with( $source_url, '/' ) && ! str_starts_with( $source_url, '//' ) ) {
			$source_url = ( $is_ssl ? 'https://' : 'http://' ) . $bunny_cdn_hostname . $source_url;
		}
		
		$cdn_url = $is_ssl ? 'https://' . $bunny_cdn_hostname : 'http://' . $bunny_cdn_hostname;
		
		return str_replace( get_home_url(), $cdn_url, $source_url );
	}
	
	/**
	 * Force enable Developer Mode if WPML is activated or this is a multisite.
	 *
	 * @filter omgf_setting_dtap
	 *
	 * @see    \OMGF\Helper::get_option()
	 *
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function maybe_force_dev_mode( $value ) {
		if ( is_multisite() || $this->is_wpml_active() || $this->is_translate_press_active() ) {
			return 'on';
		}
		
		return $value;
	}
	
	/**
	 * @return bool
	 */
	private function is_wpml_active() {
		return function_exists( 'wpml_loaded' );
	}
	
	/**
	 * @return bool
	 */
	private function is_translate_press_active() {
		return class_exists( '\TRP_Translate_Press' );
	}
	
	/**
	 * Rewrite Developer Mode's description when a compatible plugin is active.
	 *
	 * @filter omgf_developer_mode_description
	 *
	 * @param $description
	 *
	 * @return mixed|string|null
	 */
	public function maybe_modify_dev_mode_description( $description ) {
		if ( is_multisite() ) {
			return __( 'This option is enabled for <strong>Multisite compatibility</strong> and can\'t be disabled.', 'omgf-pro' );
		}
		
		if ( $this->is_translate_press_active() ) {
			return __( 'This option is enabled for <strong>TranslatePress compatibility</strong> and can\'t be disabled.', 'omgf-pro' );
		}
		
		if ( $this->is_wpml_active() ) {
			return __( 'This option is enabled for <strong>WPML compatibility</strong> and can\'t be disabled.', 'omgf-pro' );
		}
		
		return $description;
	}
}