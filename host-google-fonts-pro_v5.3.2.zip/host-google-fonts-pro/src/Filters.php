<?php
/**
 * @package   OMGF Pro
 * @author    Daan van den Bergh
 *            https://daan.dev
 * @copyright © 2017 - 2024 Daan van den Bergh
 * @license   BY-NC-ND-4.0
 *            http://creativecommons.org/licenses/by-nc-nd/4.0/
 */

namespace OMGF\Pro;

use OMGF\Pro\Admin\Settings;
use OMGF\Pro\Frontend\Optimize as Frontend_Optimize;
use OMGF\Pro\Helper as OMGFPro;

class Filters {
	/**
	 * Build class.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}
	
	/**
	 * Filter & action hooks.
	 *
	 * @return void
	 */
	private function init() {
		// OMGF Filters
		add_filter( 'omgf_ajax_admin_bar_status', [ $this, 'maybe_modify_status' ] );
		add_filter( 'omgf_ajax_results', [ $this, 'process_async_google_fonts' ], 10, 2 );
		add_filter( 'omgf_upload_dir', [ $this, 'rewrite_upload_dir' ] );
		add_filter( 'omgf_upload_url', [ $this, 'rewrite_upload_url' ] );
		add_filter( 'omgf_settings_defaults', [ $this, 'add_default_settings' ] );
		add_filter( 'omgf_frontend_process_url', [ $this, 'maybe_rewrite_url' ] );
		add_filter( 'omgf_is_running_optimize', [ $this, 'add_auto_config' ] );
		add_filter( 'omgf_optimize_url', [ $this, 'remove_excessive_spacing' ], 9 );
		add_filter( 'omgf_optimize_fonts_object', [ $this, 'optimize_additional_css' ], 10, 2 );
		add_filter( 'omgf_generate_stylesheet_after', [ $this, 'append_additional_css' ], 10, 2 );
		add_filter( 'omgf_generate_stylesheet_after', [ $this, 'maybe_white_label_css' ], 11 );
		add_filter( 'omgf_uninstall_db_entries', [ $this, 'add_db_entries' ] );
		
		
		/** Add Auto-Config query arg if the option is enabled. */
		add_filter( 'omgf_optimize_run_args', [ $this, 'add_auto_config_arg' ] );
		
		// This is loaded globally, so the entry in the topmenu bar is also modified.
		add_filter( 'omgf_settings_page_title', [ $this, 'modify_page_title' ] );
		
		// 3rd Party (Compatibility Fixes)
		add_filter( 'vc_get_vc_grid_data_response', [ $this, 'parse_vc_grid_data' ], 11 );
	}
	
	/**
	 * Make sure we also check if auto config is running.
	 *
	 * @filter omgf_is_running_optimize
	 * @see    \OMGF\Helper::is_running_optimize()
	 *
	 * @param $is_running_optimize
	 *
	 * @return bool
	 */
	public function add_auto_config( $is_running_optimize ) {
		$post   = Helper::clean( $_POST );
		$params = $post['params'] ?? [];
		$params = $this->validate_params( $params );
		
		return $is_running_optimize && OMGFPro::is_running_auto_config( $params );
	}
	
	/**
	 * Normalize $params to an array when a JSON string is provided.
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function validate_params( $params ) {
		if ( is_string( $params ) ) {
			$decoded = json_decode( $params, true );
			
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
				$params = $decoded;
			}
		}
		
		if ( ! is_array( $params ) ) {
			$params = [];
		}
		
		return $params;
	}
	
	/**
	 * @since v3.7.3 Add the omgf_pro_auto_config query argument if Auto-Config Adv. Processing is enabled.
	 * @since v4.0.0 Always add omgf_pro_auto_config parameter.
	 *
	 * @param array $args
	 *
	 * @return array
	 *
	 * @codeCoverageIgnore
	 */
	public function add_auto_config_arg( $args ) {
		$args['omgf_pro_auto_config'] = 1;
		
		return $args;
	}
	
	/**
	 * Add OMGF Pro's DB entries to the queue for removal upon uninstall.
	 *
	 * @filter omgf_uninstall_db_entries
	 * @see    \OMGF\Uninstall::remove_db_entries()
	 *
	 * @param mixed $db_entries
	 *
	 * @return array
	 */
	public function add_db_entries( $db_entries ) {
		$add_entries = [
			Settings::OMGF_PRO_DB_VERSION,
			Settings::OMGF_PRO_PROCESSED_STYLESHEETS,
			Settings::OMGF_PRO_PROCESSED_EXT_STYLESHEETS,
			Settings::OMGF_PRO_PROCESSED_ASYNC_STYLESHEETS,
			Settings::OMGF_PRO_SMART_OPTIMIZE_TRUSTED_HOSTS,
			Settings::OMGF_PRO_SMART_OPTIMIZE_APPROVED_HOSTS,
			Settings::OMGF_PRO_SMART_OPTIMIZE_PENDING_HOSTS,
			Settings::OMGF_PRO_SMART_OPTIMIZE_IGNORED_HOSTS,
			Settings::OMGF_OPTIMIZE_SETTING_FALLBACK_FONT_STACK,
			Settings::OMGF_OPTIMIZE_SETTING_REPLACE_FONT,
		];
		
		return array_merge( $db_entries, $add_entries );
	}
	
	/**
	 * Append OMGF Pro's defaults to OMGF's $defaults array.
	 *
	 * @filter omgf_settings_defaults
	 * @see    \OMGF\Admin\Actions::update_settings()
	 *
	 * @param array $defaults
	 *
	 * @return string[]
	 */
	public function add_default_settings( $defaults = [] ) {
		$defaults[ Settings::OMGF_OPTIMIZE_SETTING_FORCE_FONT_DISPLAY ]            = 'on';
		$defaults[ Settings::OMGF_OPTIMIZE_SETTING_SMART_OPTIMIZE ]                = '';
		$defaults[ Settings::OMGF_OPTIMIZE_SETTING_MAGIC_FALLBACKS ]               = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_INLINE_STYLES ]        = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_LOCAL_STYLESHEETS ]    = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_EXTERNAL_STYLESHEETS ] = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS ]    = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_WEBFONT_LOADER ]       = '';
		$defaults[ Settings::OMGF_DETECTION_SETTING_PROCESS_MATERIAL_ICONS ]       = '';
		$defaults[ Settings::OMGF_ADV_SETTING_WHITE_LABEL ]                        = 'on';
		$defaults[ Settings::OMGF_ADV_SETTING_DEV_MODE ]                           = 'on';
		$defaults[ Settings::OMGF_ADV_SETTING_SOURCE_URL ]                         = '';
		
		return $defaults;
	}
	
	/**
	 * @filter omgf_generate_stylesheet_after
	 * @see    \OMGF\StylesheetGenerator::generate()
	 *
	 * @since  v3.6.5 Appends any additional CSS classes found in $fonts to $stylesheet.
	 *
	 * @param string $stylesheet
	 *
	 * @param object $fonts
	 *
	 * @return string A valid CSS stylesheet.
	 */
	public function append_additional_css( $stylesheet, $fonts ) {
		$stylesheet_generator = new StylesheetGenerator();
		
		return $stylesheet_generator->append_additional_css( $stylesheet, $fonts );
	}
	
	/**
	 * Show alerts reported by the Google Fonts Checker as warnings in OMGF Pro, because it can handle those.
	 *
	 * @since v5.3.0 Font files which couldn't be downloaded correctly remain an alert, because OMGF Pro can't fix those.
	 *
	 * @filter omgf_ajax_admin_bar_status
	 * @see    \OMGF\API\AdminbarMenu::get_admin_bar_status()
	 *
	 * @param string $status The current status to potentially modify.
	 *
	 * @return string Returns 'warning' if $status equals 'alert', unless downloads failed.
	 */
	public function maybe_modify_status( $status ) {
		if ( $status === 'alert' && ! $this->has_download_failures() ) {
			return 'warning';
		}
		
		// If OMGF reports an info status, and optimize has run, change it to success.
		if ( $status === 'info' && Wrapper::optimize_succeeded() ) {
			return 'success';
		}
		
		return $status;
	}
	
	/**
	 * Checks if OMGF reports font files which couldn't be downloaded correctly to administrators.
	 *
	 * @since v5.3.0 Requires OMGF v6.3.12 or higher.
	 * @see   \OMGF\Download::get_failures()
	 *
	 * @codeCoverageIgnore Because it wraps OMGF, which may not provide this method yet.
	 *
	 * @return bool
	 */
	private function has_download_failures() {
		if ( ! current_user_can( 'manage_options' ) || ! method_exists( '\OMGF\Download', 'get_failures' ) ) {
			return false;
		}

		return ! empty( \OMGF\Download::get_failures() );
	}

	/**
	 * @filter omgf_frontend_process_url
	 * @see    \OMGF\Frontend\Process::add_preloads()
	 *
	 * @param $url
	 *
	 * @return array|mixed|string|string[]
	 */
	public function maybe_rewrite_url( $url ) {
		$is_relative_dir = Wrapper::get_upload_url()[0] === '/' && Wrapper::get_upload_url()[1] !== '/';
		
		if ( apply_filters( 'omgf_pro_rewrite_url', ! $is_relative_dir ) ) {
			return $url; // @codeCoverageIgnore
		}
		
		$rel_home_url = str_replace( [ 'https:', 'http:' ], '', get_home_url() );
		
		return str_replace( $rel_home_url, '', $url );
	}
	
	/**
	 * @filter maybe_white_label_css
	 * @see    \OMGF\StylesheetGenerator::generate()
	 *
	 * @since  v3.9.0 Removes the OMGF Pro branding from the stylesheet.
	 *
	 * @param string $stylesheet A valid CSS stylesheet.
	 *
	 * @return string A valid CSS stylesheet.
	 */
	public function maybe_white_label_css( $stylesheet ) {
		if ( empty( Wrapper::get_option( Settings::OMGF_ADV_SETTING_WHITE_LABEL ) ) ) {
			return $stylesheet; // @codeCoverageIgnore
		}
		
		$stripped = preg_replace( '/\A\/\*.*?\*\/\R?/s', '', $stylesheet, 1 );
		
		return is_string( $stripped ) ? $stripped : $stylesheet;
	}
	
	/**
	 * Changes OMGF to OMGF Pro anywhere in the admin settings screen.
	 *
	 * @filter omgf_settings_page_title
	 *
	 * @return string
	 */
	public function modify_page_title() {
		return __( 'OMGF <span class="pro">Pro</span>', 'omgf-pro' );
	}
	
	/**
	 * @filter omgf_optimize_fonts_object
	 * @see    \OMGF\Optimize::convert_to_fonts_object()
	 *
	 * @since  v3.6.5 Processes any additional CSS classes found in stylesheets delivered by the Variable Fonts (CSS2) API.
	 *
	 * @param string $stylesheet
	 *
	 * @param object $fonts
	 *
	 * @return object
	 */
	public function optimize_additional_css( $fonts, $stylesheet ) {
		$optimize = new Optimize();
		
		return $optimize->additional_css( $fonts, $stylesheet );
	}
	
	/**
	 * @filter vc_get_vc_grid_data_response
	 *
	 * @since  v3.7.2 Parse HTML generated by Visual Composer's Grid elements for Material Icons, which is loaded async using AJAX.
	 *
	 * @return string Valid HTML generated by Visual Composer.
	 */
	public function parse_vc_grid_data( $data ) {
		$processor = Wrapper::get_frontend_processor();
		$optimize  = new \OMGF\Pro\Frontend\Optimize\MaterialIcons();
		$data      = $optimize->optimize( $data, $processor );
		
		return $data;
	}
	
	/**
	 * We assume that all URLs sent to this method are asynchronous because it's triggered at a point where OMGF Pro has processed all other Google Fonts requests.
	 *
	 * @filter omgf_ajax_results
	 * @see    \OMGF\API\AdminbarMenu::update_results()
	 *
	 * @param array        $urls   List of Google Fonts URLs to be processed and optimized.
	 * @param array|string $params Optional. Params from the AJAX caller (array or JSON string). Default [].
	 *
	 * @return array Filtered list of URLs after processing. (empty if all are processed successfully)
	 */
	public function process_async_google_fonts( $urls, $params = [] ) {
		$params = $this->validate_params( $params );

		/**
		 * @since v5.3.0 Verify the nonce and capability, instead of only checking if the parameters are present, because
		 *                this filter also runs for requests which aren't made by administrators.
		 */
		if ( empty( $urls ) || ! OMGFPro::is_running_auto_config( $params ) ) {
			return $urls; // @codeCoverageIgnore
		}
		
		// Enable Process Async Google Fonts (previously Remove Async Google Fonts)
		Wrapper::update_option( Settings::OMGF_DETECTION_SETTING_PROCESS_ASYNC_STYLESHEETS, 'on' );
		
		$processed_stylesheets = Wrapper::get_option( Settings::OMGF_PRO_PROCESSED_ASYNC_STYLESHEETS, [] );
		$optimizer             = new Frontend_Optimize( false );
		
		foreach ( $urls as $key => $url ) {
			$original_handle = "omgf-pro-async-fonts-$key";
			$handle          = ! empty( Wrapper::get_cache_key( $original_handle ) ) ? Wrapper::get_cache_key( $original_handle ) : $original_handle;
			$local_url       = $optimizer->run_optimization( $url, $handle, $original_handle );
			
			/**
			 * Static Fonts URLs will always return empty. That's on purpose.
			 */
			if ( empty( $local_url ) && ! str_contains( $url, 'fonts.gstatic.com' ) ) {
				continue; // @codeCoverageIgnore
			}
			
			if ( ! in_array( $url, $processed_stylesheets, true ) ) {
				$processed_stylesheets[ $original_handle ] = $url;
			}
			
			unset( $urls[ $key ] );
		}
		
		Wrapper::update_option( Settings::OMGF_PRO_PROCESSED_ASYNC_STYLESHEETS, $processed_stylesheets );
		
		// Set the admin bar status to "reload" to trigger a document reload, which should make the stoplight turn green.
		if ( empty( $urls ) && ! has_filter( 'omgf_ajax_admin_bar_status', [ $this, 'set_status_reload' ] ) ) {
			add_filter( 'omgf_ajax_admin_bar_status', [ $this, 'set_status_reload' ], 9 );
		}
		
		return $urls;
	}
	
	/**
	 * Removes excessive spacing in $url's query string.
	 *
	 * @since v5.3.0 Only the query string is decoded, because this filter runs after OMGF validated the URL. Decoding
	 *                the entire URL could decode e.g. %2F or %3F into delimiters, changing the host it points to.
	 *
	 * @filter omgf_optimize_url
	 * @see    \OMGF\Optimize::__construct()
	 *
	 * @param string $url
	 *
	 * @return string
	 */
	public function remove_excessive_spacing( $url ) {
		$parts = explode( '?', $url, 2 );

		if ( ! isset( $parts[1] ) ) {
			return $url;
		}

		$query = preg_replace( '/\s{2,}/', ' ', urldecode( $parts[1] ) );
		$query = str_replace( ', ', ',', $query );

		return $parts[0] . '?' . $query;
	}
	
	/**
	 * @filter omgf_upload_dir
	 * @see    \OMGF\Plugin::define_constants()
	 *
	 * @since  v3.4.0 Use native wp_upload_dir() to add Multisite support.
	 *
	 * @return string
	 *
	 * @codeCoverageIgnore
	 */
	public function rewrite_upload_dir() {
		return wp_upload_dir()['basedir'] . '/omgf';
	}
	
	/**
	 * @filter omgf_upload_url
	 * @see    \OMGF\Plugin::define_constants()
	 *
	 * @since  v3.7.3 Make Upload URL protocol relative to avoid Mixed Content warnings in some configurations.
	 *
	 * @since  v3.4.0 Use native wp_upload_dir() to add Multisite support.
	 * @return string
	 */
	public function rewrite_upload_url() {
		$developer_mode = Wrapper::get_option( Settings::OMGF_ADV_SETTING_DEV_MODE );
		$source_url     = Wrapper::get_option( Settings::OMGF_ADV_SETTING_SOURCE_URL );
		
		if ( $developer_mode === 'on' ) {
			$source_url = wp_make_link_relative( wp_upload_dir()['baseurl'] . '/omgf' );
		} elseif ( ! $source_url && ! $developer_mode ) {
			// Protocol relative to avoid Mixed Content warnings.
			$source_url = str_replace( [ 'http:', 'https:' ], '', wp_upload_dir()['baseurl'] . '/omgf' );
		}
		
		return apply_filters( 'omgf_pro_modify_source_url', $source_url );
	}
	
	/**
	 * When Remove Async Google Fonts has been enabled, and its URLs are processed. Set the reload class.
	 *
	 * @filter omgf_ajax_admin_bar_status
	 * @see    self::process_async_google_fonts()
	 *
	 * @return string
	 *
	 * @codeCoverageIgnore
	 */
	public function set_status_reload() {
		return 'reload';
	}
}
