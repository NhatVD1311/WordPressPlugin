<?php
/**
 * Bricks listing item settings manager.
 */

namespace Jet_Engine\Bricks_Views\Listing\Item_Settings;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Manager {

	const META_KEY = '_jet_engine_bricks_listing_settings';

	const VERSION = 1;

	const NONCE_ACTION = 'jet-engine-bricks-listing-item-settings';

	const ACTION_LOAD = 'jet_engine_bricks_listing_item_settings_load';

	const ACTION_SAVE = 'jet_engine_bricks_listing_item_settings_save';

	protected $registry = null;

	protected $settings_cache = array();

	public function __construct() {

		$this->registry = new Registry();

		add_action( 'wp_ajax_' . self::ACTION_LOAD, array( $this, 'ajax_load_settings' ) );
		add_action( 'wp_ajax_' . self::ACTION_SAVE, array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_editor_assets' ) );

	}

	public function get_registry() {
		return $this->registry;
	}

	public function ajax_load_settings() {

		$post_id = $this->validate_ajax_request();

		wp_send_json_success( $this->get_editor_payload( $post_id ) );

	}

	public function ajax_save_settings() {

		$post_id  = $this->validate_ajax_request();
		$settings = $this->get_settings_from_request();

		if ( false === $settings ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid settings payload.', 'jet-engine' ),
				),
				400
			);
		}

		$this->save_settings( $post_id, $settings );

		$payload            = $this->get_editor_payload( $post_id );
		$payload['message'] = __( 'Settings saved.', 'jet-engine' );

		wp_send_json_success( $payload );

	}

	public function get_settings( $post_id, $force = false ) {

		$post_id = absint( $post_id );

		if ( ! $post_id ) {
			return $this->registry->get_defaults();
		}

		if ( ! $force && isset( $this->settings_cache[ $post_id ] ) ) {
			return $this->settings_cache[ $post_id ];
		}

		$envelope = get_post_meta( $post_id, self::META_KEY, true );
		$settings = array();

		if ( is_array( $envelope ) && ! empty( $envelope['settings'] ) && is_array( $envelope['settings'] ) ) {
			$settings = $envelope['settings'];
		}

		$settings = array_merge( $this->registry->get_defaults(), $settings );
		$settings = $this->registry->sanitize_settings( $settings );

		$this->settings_cache[ $post_id ] = $settings;

		return $settings;

	}

	public function save_settings( $post_id, $settings ) {

		$post_id  = absint( $post_id );
		$previous = get_post_meta( $post_id, self::META_KEY, true );
		$settings = array_merge( $this->registry->get_defaults(), is_array( $settings ) ? $settings : array() );
		$settings = $this->registry->sanitize_settings( $settings );

		$envelope = array(
			'version'  => self::VERSION,
			'settings' => $settings,
		);

		update_post_meta( $post_id, self::META_KEY, $envelope );

		$this->settings_cache[ $post_id ] = $settings;

		do_action( 'jet-engine/bricks-views/listing-item-settings/saved', $post_id, $settings, $previous );

		return $settings;

	}

	public function get_editor_payload( $post_id ) {

		$post_id = absint( $post_id );

		$payload = array(
			'postId'        => $post_id,
			'version'       => self::VERSION,
			'settings'      => $this->get_settings( $post_id ),
			'controlGroups' => $this->registry->get_control_groups(),
			'controls'      => $this->registry->get_controls(),
			'labels'        => $this->get_labels(),
		);

		return apply_filters( 'jet-engine/bricks-views/listing-item-settings/editor-data', $payload, $post_id, $this );

	}

	public function get_options_payload() {

		$options = array();

		foreach ( $this->registry->get_settings() as $key => $setting ) {
			$field_options = $this->registry->get_options( $key );

			if ( ! empty( $field_options ) ) {
				$options[ $key ] = $field_options;
			}
		}

		return $options;

	}

	public function get_labels() {

		return array(
			'entryTitle'       => __( 'Listing Item Settings', 'jet-engine' ),
			'panelTitle'       => __( 'Listing Item Settings', 'jet-engine' ),
			'listingLinkGroup' => __( 'Listing Link', 'jet-engine' ),
			'save'             => __( 'Save', 'jet-engine' ),
			'saving'           => __( 'Saving...', 'jet-engine' ),
			'saved'            => __( 'Settings saved.', 'jet-engine' ),
			'back'             => __( 'Back', 'jet-engine' ),
			'loading'          => __( 'Loading...', 'jet-engine' ),
			'loadError'        => __( 'Unable to load listing settings.', 'jet-engine' ),
			'saveError'        => __( 'Unable to save listing settings.', 'jet-engine' ),
		);

	}

	public function get_nonce() {
		return wp_create_nonce( self::NONCE_ACTION );
	}

	public function get_ajax_actions() {

		return array(
			'load' => self::ACTION_LOAD,
			'save' => self::ACTION_SAVE,
		);

	}

	public function enqueue_editor_assets() {

		$post_id = $this->get_builder_post_id();

		if ( ! $this->should_enqueue_editor_assets( $post_id ) ) {
			return;
		}

		$handle = 'jet-engine-bricks-listing-item-settings';

		wp_enqueue_style(
			$handle,
			jet_engine()->plugin_url( 'assets/css/admin/bricks-listing-item-settings.css' ),
			array(),
			jet_engine()->get_version()
		);

		wp_enqueue_script(
			$handle,
			jet_engine()->plugin_url( 'assets/js/admin/bricks-listing-item-settings.js' ),
			array(),
			jet_engine()->get_version(),
			true
		);

		$payload = $this->get_editor_payload( $post_id );

		$payload['transport'] = 'ajax';
		$payload['ajaxUrl']   = admin_url( 'admin-ajax.php' );
		$payload['nonce']     = $this->get_nonce();
		$payload['actions']   = $this->get_ajax_actions();
		$payload['selectors'] = array(
			'panel'         => '#bricks-panel',
			'settingsPanel' => '#bricks-panel-settings',
			'controls'      => '.bricks-panel-controls',
			'controlGroups' => 'ul.control-groups',
		);

		wp_localize_script(
			$handle,
			'JetEngineBricksListingItemSettings',
			$payload
		);

	}

	public function add_listing_link_to_content( $content, $listing_id ) {

		$settings = $this->get_settings( $listing_id );

		if ( empty( $settings ) || empty( $settings['listing_link'] ) ) {
			return $content;
		}

		$dynamic_settings = array(
			'listing_link_aria_label',
		);

		foreach ( $dynamic_settings as $dynamic_setting ) {
			if ( empty( $settings[ $dynamic_setting ] ) ) {
				continue;
			}

			$settings[ $dynamic_setting ] = jet_engine()->listings->macros->do_macros( $settings[ $dynamic_setting ] );
			$settings[ $dynamic_setting ] = do_shortcode( $settings[ $dynamic_setting ] );
		}

		return jet_engine()->frontend->add_listing_link_to_content( $content, $settings );

	}

	protected function should_enqueue_editor_assets( $post_id ) {

		if ( ! $post_id || ! $this->is_bricks_listing( $post_id ) ) {
			return false;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}

		if ( function_exists( 'bricks_is_builder_main' ) ) {
			return bricks_is_builder_main();
		}

		if ( function_exists( 'bricks_is_builder' ) && bricks_is_builder() ) {
			if ( function_exists( 'bricks_is_builder_iframe' ) && bricks_is_builder_iframe() ) {
				return false;
			}

			return true;
		}

		return false;

	}

	protected function get_builder_post_id() {

		$post_id = get_the_ID();

		if ( ! $post_id ) {
			$post_id = get_queried_object_id();
		}

		return absint( $post_id );

	}

	protected function validate_ajax_request() {

		$nonce = $this->get_request_nonce();

		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'The page is expired. Please reload it and try again.', 'jet-engine' ),
				),
				403
			);
		}

		$post_id = $this->get_request_post_id();

		if ( ! $post_id || ! get_post( $post_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Listing item was not found in the request.', 'jet-engine' ),
				),
				404
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You don`t have permissions to edit this Listing item.', 'jet-engine' ),
				),
				403
			);
		}

		if ( ! $this->is_bricks_listing( $post_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Requested item is not a Bricks listing.', 'jet-engine' ),
				),
				400
			);
		}

		return $post_id;

	}

	protected function get_request_nonce() {

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_REQUEST['_nonce'] ) ) {
			return sanitize_text_field( wp_unslash( $_REQUEST['_nonce'] ) );
		}

		if ( ! empty( $_REQUEST['nonce'] ) ) {
			return sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return false;

	}

	protected function get_request_post_id() {

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_REQUEST['post_id'] ) ) {
			return absint( $_REQUEST['post_id'] );
		}

		if ( ! empty( $_REQUEST['postId'] ) ) {
			return absint( $_REQUEST['postId'] );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return 0;

	}

	protected function get_settings_from_request() {

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_REQUEST['settings'] ) ) {
			return array();
		}

		$settings = wp_unslash( $_REQUEST['settings'] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( is_string( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		return is_array( $settings ) ? $settings : false;

	}

	protected function is_bricks_listing( $post_id ) {

		if ( get_post_type( $post_id ) !== jet_engine()->post_type->slug() ) {
			return false;
		}

		return 'bricks' === jet_engine()->listings->data->get_listing_type( $post_id );

	}

}
