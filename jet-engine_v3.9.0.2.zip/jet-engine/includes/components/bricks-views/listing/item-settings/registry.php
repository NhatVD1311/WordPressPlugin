<?php
/**
 * Bricks listing item settings registry.
 */

namespace Jet_Engine\Bricks_Views\Listing\Item_Settings;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Registry {

	protected $groups = array();

	protected $settings = array();

	public function __construct() {
		$this->register_defaults();

		do_action( 'jet-engine/bricks-views/listing-item-settings/register', $this );
	}

	public function register_group( $key, $args = array() ) {

		if ( empty( $args['title'] ) && ! empty( $args['label'] ) ) {
			$args['title'] = $args['label'];
		}

		unset( $args['label'] );

		$this->groups[ $key ] = array_merge(
			array(
				'title' => $key,
			),
			$args
		);

	}

	public function register_setting( $key, $args = array() ) {

		$defaults = array(
			'key'       => $key,
			'group'     => '',
			'label'     => $key,
			'type'      => 'text',
			'default'   => '',
			'options'   => array(),
			'required'  => array(),
			'frontend'  => true,
			'sanitize'  => array( $this, 'sanitize_text' ),
		);

		$this->settings[ $key ] = array_merge( $defaults, $args, array( 'key' => $key ) );

	}

	public function get_groups() {

		$groups = array();

		foreach ( $this->groups as $key => $group ) {
			$groups[] = array_merge(
				array(
					'key'   => $key,
					'label' => ! empty( $group['title'] ) ? $group['title'] : $key,
				),
				$group
			);
		}

		return $groups;

	}

	public function get_settings() {
		return $this->settings;
	}

	public function get_control_groups() {

		return $this->groups;

	}

	public function get_controls() {

		$controls = array();

		foreach ( $this->settings as $key => $setting ) {
			$control = array(
				'group'    => $setting['group'],
				'label'    => $setting['label'],
				'type'     => $setting['type'],
				'default'  => $setting['default'],
				'required' => $setting['required'],
				'frontend' => $setting['frontend'],
			);

			if ( ! empty( $setting['description'] ) ) {
				$control['description'] = $setting['description'];
			}

			$options = $this->get_options( $key );

			if ( ! empty( $options ) ) {
				$control['options'] = $options;
			}

			$controls[ $key ] = $control;
		}

		return $controls;

	}

	public function get_schema() {

		$schema = array();

		foreach ( $this->settings as $key => $setting ) {
			$schema[ $key ] = array(
				'key'       => $key,
				'group'     => $setting['group'],
				'label'     => $setting['label'],
				'type'      => $setting['type'],
				'default'   => $setting['default'],
				'required'  => $setting['required'],
				'frontend'  => $setting['frontend'],
			);

			if ( ! empty( $setting['description'] ) ) {
				$schema[ $key ]['description'] = $setting['description'];
			}

			$options = $this->get_options( $key );

			if ( ! empty( $options ) ) {
				$schema[ $key ]['options'] = $options;
			}
		}

		return array_values( $schema );

	}

	public function get_defaults() {

		$defaults = array();

		foreach ( $this->settings as $key => $setting ) {
			$defaults[ $key ] = $setting['default'];
		}

		return apply_filters( 'jet-engine/bricks-views/listing-item-settings/defaults', $defaults, $this );

	}

	public function get_options( $key ) {

		if ( empty( $this->settings[ $key ] ) ) {
			return array();
		}

		$options = $this->settings[ $key ]['options'];

		if ( is_callable( $options ) ) {
			$options = call_user_func( $options );
		}

		return is_array( $options ) ? $options : array();

	}

	public function sanitize_settings( $settings ) {

		$sanitized = array();
		$settings  = is_array( $settings ) ? $settings : array();
		$defaults  = $this->get_defaults();

		foreach ( $this->settings as $key => $setting ) {
			$value     = array_key_exists( $key, $settings ) ? $settings[ $key ] : $defaults[ $key ];
			$callback  = ! empty( $setting['sanitize'] ) ? $setting['sanitize'] : array( $this, 'sanitize_text' );
			$sanitized[ $key ] = is_callable( $callback ) ? call_user_func( $callback, $value, $key, $setting, $this ) : $this->sanitize_text( $value );
		}

		return apply_filters( 'jet-engine/bricks-views/listing-item-settings/sanitize', $sanitized, $settings, $this );

	}

	public function sanitize_switch( $value ) {
		return ! empty( $value ) && 'false' !== $value ? 'yes' : '';
	}

	public function sanitize_text( $value ) {
		if ( ! is_scalar( $value ) ) {
			return '';
		}

		return sanitize_text_field( $value );
	}

	public function sanitize_textarea( $value ) {
		if ( ! is_scalar( $value ) ) {
			return '';
		}

		return sanitize_textarea_field( $value );
	}

	public function sanitize_link_source( $value, $key ) {

		$value   = $this->sanitize_text( $value );
		$allowed = $this->flatten_options( $this->get_options( $key ) );

		return in_array( $value, $allowed, true ) ? $value : '_permalink';

	}

	public function sanitize_rel_attr( $value, $key ) {

		$value   = $this->sanitize_text( $value );
		$allowed = $this->flatten_options( $this->get_options( $key ) );

		if ( '' === $value ) {
			return '';
		}

		return in_array( $value, $allowed, true ) ? $value : '';

	}

	public function sanitize_option_value( $value, $key ) {

		$value = $this->sanitize_text( $value );

		if ( '' === $value ) {
			return '';
		}

		$options = $this->get_options( $key );

		if ( empty( $options ) ) {
			return '';
		}

		$allowed = $this->flatten_options( $options );

		return in_array( $value, $allowed, true ) ? $value : '';

	}

	public function sanitize_map_zoom( $value ) {
		if ( '' === $value || null === $value ) {
			return '';
		}

		return $this->sanitize_text( $value );
	}

	public function flatten_options( $options ) {

		$result = array();

		if ( ! is_array( $options ) ) {
			return $result;
		}

		foreach ( $options as $value => $option ) {
			if ( is_array( $option ) && isset( $option['options'] ) && is_array( $option['options'] ) ) {
				$result = array_merge( $result, $this->flatten_options( $option['options'] ) );
				continue;
			}

			if ( is_array( $option ) && isset( $option['values'] ) && is_array( $option['values'] ) ) {
				$result = array_merge( $result, $this->flatten_options( $option['values'] ) );
				continue;
			}

			if ( is_array( $option ) && isset( $option['value'] ) ) {
				$result[] = (string) $option['value'];
				continue;
			}

			$result[] = (string) $value;
		}

		return array_values( array_unique( $result ) );

	}

	protected function register_defaults() {

		$this->register_group(
			'listing_settings',
			array(
				'title' => __( 'Listing Settings', 'jet-engine' ),
			)
		);

		$this->register_setting(
			'listing_link',
			array(
				'group'    => 'listing_settings',
				'label'    => __( 'Make listing item clickable', 'jet-engine' ),
				'type'     => 'checkbox',
				'default'  => '',
				'sanitize' => array( $this, 'sanitize_switch' ),
			)
		);

		$this->register_setting(
			'listing_link_source',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Link source', 'jet-engine' ),
				'type'      => 'select',
				'default'   => '_permalink',
				'options'   => array( $this, 'get_link_sources' ),
				'required'  => array( 'listing_link', '=', 'yes' ),
				'sanitize'  => array( $this, 'sanitize_link_source' ),
			)
		);

		$this->register_setting(
			'listing_link_object_prop',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Object property', 'jet-engine' ),
				'type'      => 'select',
				'default'   => '',
				'options'   => array( $this, 'get_object_fields' ),
				'required'  => array(
					array( 'listing_link', '=', 'yes' ),
					array( 'listing_link_source', '=', 'object_prop' ),
				),
				'sanitize'  => array( $this, 'sanitize_text' ),
			)
		);

		$this->register_setting(
			'listing_link_custom_url',
			array(
				'group'       => 'listing_settings',
				'label'       => __( 'Custom URL', 'jet-engine' ),
				'type'        => 'text',
				'default'     => '',
				'description' => __( 'Shortcodes and JetEngine macros supported. Overrides Link source.', 'jet-engine' ),
				'required'    => array( 'listing_link', '=', 'yes' ),
				'sanitize'    => array( $this, 'sanitize_text' ),
			)
		);

		$this->register_setting(
			'listing_link_option',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Option', 'jet-engine' ),
				'type'      => 'select',
				'default'   => '',
				'options'   => array( $this, 'get_options_pages' ),
				'required'  => array(
					array( 'listing_link', '=', 'yes' ),
					array( 'listing_link_source', '=', 'options_page' ),
				),
				'sanitize'  => array( $this, 'sanitize_option_value' ),
			)
		);

		if ( $this->has_map_link_sources() ) {
			$this->register_setting(
				'listing_link_map_zoom',
				array(
					'group'     => 'listing_settings',
					'label'     => __( 'Zoom', 'jet-engine' ),
					'type'      => 'number',
					'default'   => '',
					'required'  => array(
						array( 'listing_link', '=', 'yes' ),
						array( 'listing_link_source', '=', $this->get_map_link_source_keys() ),
					),
					'sanitize'  => array( $this, 'sanitize_map_zoom' ),
				)
			);

			$this->register_setting(
				'listing_link_scroll_to_map',
				array(
					'group'    => 'listing_settings',
					'label'    => __( 'Scroll to map', 'jet-engine' ),
					'type'     => 'select',
					'default'  => '',
					'options'  => array(
						''    => esc_html__( 'Default', 'jet-engine' ),
						'yes' => esc_html__( 'Yes', 'jet-engine' ),
					),
					'required' => array(
						array( 'listing_link', '=', 'yes' ),
						array( 'listing_link_source', '=', $this->get_map_link_source_keys() ),
					),
					'sanitize' => array( $this, 'sanitize_option_value' ),
				)
			);
		}

		$this->register_setting(
			'listing_link_open_in_new',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Open in new window', 'jet-engine' ),
				'type'      => 'checkbox',
				'default'   => '',
				'required'  => $this->get_external_link_attrs_required(),
				'sanitize'  => array( $this, 'sanitize_switch' ),
			)
		);

		$this->register_setting(
			'listing_link_rel_attr',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Add "rel" attr', 'jet-engine' ),
				'type'      => 'select',
				'default'   => '',
				'options'   => array( $this, 'get_rel_attr_options' ),
				'required'  => $this->get_external_link_attrs_required(),
				'sanitize'  => array( $this, 'sanitize_rel_attr' ),
			)
		);

		$this->register_setting(
			'listing_link_aria_label',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Aria label attr / Link text', 'jet-engine' ),
				'type'      => 'text',
				'default'   => '',
				'required'  => array( 'listing_link', '=', 'yes' ),
				'sanitize'  => array( $this, 'sanitize_text' ),
			)
		);

		$this->register_setting(
			'listing_link_prefix',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Link prefix', 'jet-engine' ),
				'type'      => 'text',
				'default'   => '',
				'required'  => array( 'listing_link', '=', 'yes' ),
				'sanitize'  => array( $this, 'sanitize_text' ),
			)
		);

		$this->register_setting(
			'listing_link_add_query_args',
			array(
				'group'     => 'listing_settings',
				'label'     => __( 'Add Query Arguments', 'jet-engine' ),
				'type'      => 'checkbox',
				'default'   => '',
				'required'  => array( 'listing_link', '=', 'yes' ),
				'sanitize'  => array( $this, 'sanitize_switch' ),
			)
		);

		$this->register_setting(
			'listing_link_query_args',
			array(
				'group'       => 'listing_settings',
				'label'       => __( 'Query Arguments', 'jet-engine' ),
				'type'        => 'textarea',
				'default'     => '_post_id=%current_id%',
				'description' => __( 'One argument per line. Separate key and value with "="', 'jet-engine' ),
				'required'    => array(
					array( 'listing_link', '=', 'yes' ),
					array( 'listing_link_add_query_args', '=', 'yes' ),
				),
				'sanitize'    => array( $this, 'sanitize_textarea' ),
			)
		);

		$this->register_setting(
			'listing_link_url_anchor',
			array(
				'group'       => 'listing_settings',
				'label'       => __( 'URL Anchor', 'jet-engine' ),
				'type'        => 'text',
				'default'     => '',
				'description' => __( 'Add anchor to the URL. Without #.', 'jet-engine' ),
				'required'    => array( 'listing_link', '=', 'yes' ),
				'sanitize'    => array( $this, 'sanitize_text' ),
			)
		);

	}

	public function get_link_sources() {
		return jet_engine()->listings->get_listing_link_sources();
	}

	public function get_object_fields() {
		return jet_engine()->listings->data->get_object_fields();
	}

	public function get_options_pages() {

		if ( ! jet_engine()->options_pages ) {
			return array();
		}

		return jet_engine()->options_pages->get_options_for_select( 'plain' );

	}

	public function get_rel_attr_options() {
		return \Jet_Engine_Tools::get_rel_attr_options();
	}

	public function get_external_link_attrs_required() {

		$required = array(
			array( 'listing_link', '=', 'yes' ),
		);

		if ( $this->has_map_link_sources() ) {
			$required[] = array( 'listing_link_source', '!=', $this->get_map_link_source_keys() );
		}

		return $required;

	}

	public function get_map_link_source_keys() {
		return array(
			'open_map_listing_popup',
			'open_map_listing_popup_hover',
		);
	}

	public function has_map_link_sources() {

		$link_sources = $this->flatten_options( $this->get_link_sources() );

		return ! array_diff( $this->get_map_link_source_keys(), $link_sources );

	}

}
