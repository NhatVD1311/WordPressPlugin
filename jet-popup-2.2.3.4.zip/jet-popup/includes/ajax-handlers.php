<?php
/**
 * Class description
 *
 * @package   package_name
 * @author    Cherry Team
 * @license   GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Popup_Ajax_Handlers' ) ) {

	/**
	 * Define Jet_Popup_Admin_Ajax_Handlers class
	 */
	class Jet_Popup_Ajax_Handlers {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		/**
		 * System message.
		 *
		 * @var array
		 */
		public $sys_messages = [];

		/**
		 * MailChimp API server
		 *
		 * @var string
		 */
		private $api_server = 'https://%s.api.mailchimp.com/3.0/';

		/**
		 * Init Handler
		 */
		public function __construct() {

			$this->sys_messages = [
				'invalid_mail'      => esc_html__( 'Please, provide valid mail', 'jet-popup' ),
				'mailchimp'         => esc_html__( 'Please, set up MailChimp API key and List ID', 'jet-popup' ),
				'internal'          => esc_html__( 'Internal error. Please, try again later', 'jet-popup' ),
				'server_error'      => esc_html__( 'Server error. Please, try again later', 'jet-popup' ),
				'subscribe_success' => esc_html__( 'E-mail %s has been subscribed', 'jet-popup' ),
				'no_data'           => esc_html__( 'No Data Found', 'jet-popup' ),
			];

			if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
				add_action( 'wp_ajax_jet_popup_mailchimp_ajax', [ $this, 'jet_popup_mailchimp_ajax' ] );
				add_action( 'wp_ajax_nopriv_jet_popup_mailchimp_ajax', [ $this, 'jet_popup_mailchimp_ajax' ] );

				add_action( 'wp_ajax_jet_popup_get_content', [ $this, 'jet_popup_get_content' ] );
				add_action( 'wp_ajax_nopriv_jet_popup_get_content', [ $this, 'jet_popup_get_content' ] );
			}
		}

		/**
		 * Proccesing subscribe form ajax
		 *
		 * @return void
		 */
		public function jet_popup_mailchimp_ajax() {
			// phpcs:ignore
			$data = ( ! empty( $_POST['data'] ) ) ? $_POST['data'] : false;
			
			if ( ! $data ) {
				wp_send_json_error( array( 'type' => 'error', 'message' => $this->sys_messages['server_error'] ) );
			}

			$api_key = jet_popup()->settings->get( 'apikey' );

			if ( ! $api_key ) {
				wp_send_json( array( 'type' => 'error', 'message' => $this->sys_messages['mailchimp'] ) );
			}

			$list_id = $data['target_list_id'];

			if ( ! $list_id ) {
				wp_send_json( array( 'type' => 'error', 'message' => $this->sys_messages['mailchimp'] ) );
			}

			$mail = $data['email'];

			if ( empty( $mail ) || ! is_email( $mail ) ) {
				wp_send_json( array( 'type' => 'error', 'message' => $this->sys_messages['invalid_mail'] ) );
			}

			$double_opt_in = false;

			$user_lists = jet_popup()->settings->get_user_lists();

			if ( array_key_exists( $list_id, $user_lists ) ) {
				$double_opt_in = $user_lists[ $list_id ][ 'info' ]['double_optin'];
			}

			$args = [
				'email_address' => $mail,
				'status'        => $double_opt_in ? 'pending' : 'subscribed',
			];

			if ( ! empty( $data['additional'] ) ) {

				$additional = $data['additional'];

				foreach ( $additional as $key => $value ) {
					$field_key = strtoupper( $key );

					if ( 'BIRTHDAY' == $field_key ) {
						$date = new DateTime( $value );
						$value = $date->format( 'm/d' );
					}

					$merge_fields[ $field_key ] = $value;
				}

				$args['merge_fields'] = $merge_fields;

			}

			$response = $this->api_call( $api_key, $list_id, $args );

			if ( false === $response ) {
				wp_send_json( array( 'type' => 'error', 'message' => $this->sys_messages['mailchimp'] ) );
			}

			$response = json_decode( $response, true );

			if ( empty( $response ) ) {
				wp_send_json( array( 'type' => 'error', 'message' => $this->sys_messages['internal'] ) );
			}

			if ( isset( $response['status'] ) && 400 == $response['status'] ) {

				$message = esc_html( $response['detail'] );

				if ( is_array( $response['errors'] ) && ! empty( $response['errors'] ) ) {
					foreach ( $response['errors'] as $key => $error ) {
						$message .= sprintf( ' <b>%s</b> %s', $error['field'], $error['message'] );
					}
				}

				wp_send_json( array( 'type' => 'error', 'message' => $message ) );
			}

			$subscribe_success = sprintf( $this->sys_messages['subscribe_success'], $response['email_address'] );

			wp_send_json( array( 'type' => 'success', 'message' => $subscribe_success ) );
		}

		/**
		 * Make remote request to mailchimp API
		 *
		 * @param  string $method API method to call.
		 * @param  array  $args   API call arguments.
		 * @return array|bool
		 */
		public function api_call( $api_key, $list_id, $args = [] ) {

			$key_data = explode( '-', $api_key );

			if ( empty( $key_data ) || ! isset( $key_data[1] ) ) {
				return false;
			}

			$this->api_server = sprintf( 'https://%s.api.mailchimp.com/3.0/', $key_data[1] );

			$url = esc_url( trailingslashit( $this->api_server . 'lists/' . $list_id . '/members/' ) );

			$data = json_encode( $args );

			$request_args = [
				'method'      => 'POST',
				'timeout'     => 20,
				'headers'     => [
					'Content-Type'  => 'application/json',
					'Authorization' => 'apikey ' . $api_key
				],
				'body'        => $data,
			];

			$request = wp_remote_post( $url, $request_args );

			return wp_remote_retrieve_body( $request );
		}

		/**
		 * [jet_popup_get_content description]
		 * @return [type] [description]
		 */
		public function jet_popup_get_content() {
			
			$data = ( ! empty( $_POST['data'] ) ) ? $_POST['data'] : false; // phpcs:ignore

			if ( ! $data ) {
				wp_send_json_error( [ 'type' => 'error', 'message' => $this->sys_messages['server_error'] ] );
			}

			$popup_data = apply_filters( 'jet-popup/ajax-request/post-data', $data );

			if ( ! is_array( $popup_data ) ) {
				wp_send_json_error( [ 'type' => 'error', 'message' => $this->sys_messages['server_error'] ] );
			}

			// CCT listing overlays may not expose cctSlug in their HTML. Resolve
			// it from the Query Builder so JetEngine can load the CCT item.
			if ( empty( $popup_data['cctSlug'] ) && ! empty( $popup_data['listingId'] ) && class_exists( '\Jet_Engine\Modules\Custom_Content_Types\Module' ) ) {
				$cct_slug = \Jet_Engine\Modules\Custom_Content_Types\Module::instance()->manager->get_content_type_by_listing(
					absint( $popup_data['listingId'] )
				);

				if ( $cct_slug ) {
					$popup_data['cctSlug'] = sanitize_key( $cct_slug );
				}
			}

			if ( empty( $popup_data['cctSlug'] ) && ! empty( $popup_data['queryId'] ) && class_exists( '\Jet_Engine\Query_Builder\Manager' ) ) {
				$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

				if ( $query && 'custom-content-type' === $query->query_type ) {
					$query->setup_query();
					$cct_slug = ! empty( $query->final_query['content_type'] ) ? sanitize_key( $query->final_query['content_type'] ) : '';

					if ( $cct_slug ) {
						$popup_data['cctSlug'] = $cct_slug;
					}
				}
			}

			// A listing switched away from a repeater query can retain its old
			// query ID. Direct listing sources use numeric object IDs, not composite
			// repeater query IDs. Normalize before validation and JetEngine rendering.
			if (
				! empty( $popup_data['isJetEngine'] )
				&& ! empty( $popup_data['postId'] )
				&& is_numeric( $popup_data['postId'] )
				&& isset( $popup_data['listingSource'] )
				&& in_array( $popup_data['listingSource'], [ 'terms', 'WP_Term', 'users', 'WP_User', 'comments', 'WP_Comment', 'repeater', 'custom-content-type', 'custom_content_type', 'custom-content-types' ], true )
				&& ! empty( $popup_data['queryId'] )
				&& class_exists( '\Jet_Engine\Query_Builder\Manager' )
			) {
				$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

				if ( $query && 'repeater' === $query->query_type ) {
					unset( $popup_data['queryId'] );
				}
			}

			// For regular post listings the item ID is the authoritative context.
			// Passing a Query Builder ID makes JetEngine resolve the query item
			// again and can leave dynamic fields empty when the query is paginated
			// or filtered. Keep query metadata for non-post listing object types.
			if (
				! empty( $popup_data['postId'] )
				&& is_numeric( $popup_data['postId'] )
				&& ( empty( $popup_data['listingSource'] ) || 'posts' === $popup_data['listingSource'] )
			) {
				unset( $popup_data['queryId'] );
			}

			$popup_id = ! empty( $popup_data['popup_id'] ) ? absint( $popup_data['popup_id'] ) : 0;
			$context_id = ! empty( $popup_data['postId'] ) ? $popup_data['postId'] : 0;
			$post_id    = is_numeric( $context_id ) ? absint( $context_id ) : 0;

			if ( ! $this->is_public_popup( $popup_id ) ) {
				wp_send_json_error( [
					'type'    => 'error',
					'message' => 'The requested popup is not available.',
				] );
			}

			$context_source = $this->get_render_context_source( $popup_data );
			$listing_object = false;
			if ( ! empty( $popup_data['isJetEngine'] ) && class_exists( '\Jet_Popup\Compatibility\Listing_Context' )
				&& \Jet_Popup\Compatibility\Listing_Context::supports( $popup_data['listingSource'] ?? '' ) ) {
				$context_source = $popup_data['listingSource'];
				$listing_object = \Jet_Popup\Compatibility\Listing_Context::resolve( $popup_data );
				if ( ! $listing_object ) {
					wp_send_json_error( [ 'type' => 'error', 'message' => 'The requested content is not available.' ] );
				}
				unset( $popup_data['queryId'] );
				$post_id = 0;
			}


			if ( ! $listing_object && $context_id && ! $this->is_allowed_render_context( $context_id, $context_source, $popup_data ) ) {
				wp_send_json_error( [
					'type'    => 'error',
					'message' => 'The requested content is not available.',
				] );
			}

			$content_type = jet_popup()->post_type->get_popup_content_type( $popup_id );

			// Elementor may print inline CSS while a compatibility filter renders content.
			// Keep that output inside the popup instead of before the JSON response.
			$this->prepare_cct_render_context( $popup_data );
			ob_start();

			try {
				$content = $listing_object ? false : apply_filters( "jet-popup/ajax-request/get-{$content_type}-content", false, $popup_data );
			} finally {
				$inline_content = ob_get_clean();
			}

			// Deprecated filter
			$popup_data   = apply_filters( 'jet-popup/ajax-request/after-content-define/post-data', $popup_data );

			switch ( $content_type ) {
				case 'default':
					$render_instance = new \Jet_Popup\Render\Block_Editor_Content_Render( [
						'popup_id'       => $popup_id,
						'with_css'       => true,
						'is_style_deps'  => false,
						'is_script_deps' => false,
					] );
					break;
				case 'elementor':
					$render_instance = new \Jet_Popup\Render\Elementor_Content_Render( [
						'popup_id'       => $popup_id,
						'post_id'        => in_array( $context_source, [ 'terms', 'WP_Term', 'users', 'WP_User', 'comments', 'WP_Comment', 'custom-content-type', 'custom_content_type', 'custom-content-types', 'jet-booking-query' ], true ) ? 0 : $post_id,
						'is_style_deps'  => false,
						'is_script_deps' => false,
						'jet_engine_current_object' => $listing_object ?: ( ( in_array( $context_source, [ 'terms', 'WP_Term', 'users', 'WP_User', 'comments', 'WP_Comment', 'repeater', 'custom-content-type', 'custom_content_type', 'custom-content-types', 'jet-booking-query' ], true ) && function_exists( 'jet_engine' ) )
							? jet_engine()->listings->data->get_current_object()
							: false ),
					] );
					break;
			}

			if ( $listing_object ) {
				$previous_object = jet_engine()->listings->data->get_current_object();
				jet_engine()->listings->data->set_current_object( $listing_object, true );
			}
			try {
				$content_data = $render_instance->get_render_data();
			} finally {
				if ( $listing_object ) {
					jet_engine()->listings->data->set_current_object( $previous_object );
				}
			}

			if ( ! empty( $content )  ) {
				$content_data['content'] = $content;
			}

			$content_data['content'] = $inline_content . $content_data['content'];

			$content_data = apply_filters( 'jet-popup/ajax-request/content-data', $content_data, $popup_data, $content_type, $content );

			if ( empty( $content_data ) ) {
				wp_send_json( [
					'type'    => 'error',
					'message' => $this->sys_messages['no_data']
				] );
			}

			$popup_data = ( ! empty( $popup_data ) ) ? $popup_data : false;

			wp_send_json( [
				'type'    => 'success',
				'content' => $content_data,
				'data'    => $popup_data
			] );
		}

		/**
		 * Set the JetEngine CCT item as the current listing object before Elementor
		 * renders the popup. This also covers installations where the JetEngine
		 * popup compatibility filter is loaded after the AJAX handler.
		 *
		 * @param array $popup_data Popup request data.
		 * @return void
		 */
		private function prepare_cct_render_context( $popup_data ) {
			if (
				empty( $popup_data['isJetEngine'] )
				|| empty( $popup_data['postId'] )
				|| empty( $popup_data['cctSlug'] )
				|| ! class_exists( '\Jet_Engine\Modules\Custom_Content_Types\Module' )
				|| ! function_exists( 'jet_engine' )
			) {
				return;
			}

			$type = \Jet_Engine\Modules\Custom_Content_Types\Module::instance()->manager->get_content_types(
				sanitize_key( $popup_data['cctSlug'] )
			);

			if ( ! $type || ! isset( $type->db ) ) {
				return;
			}

			$type->db->set_format_flag( 'OBJECT' );

			$item = $type->db->get_item( absint( $popup_data['postId'] ) );

			if ( empty( $item ) ) {
				return;
			}

			jet_engine()->listings->data->set_current_object( $item, true );

			if ( isset( jet_engine()->listings->objects_stack ) ) {
				jet_engine()->listings->objects_stack->set_root_object( $item );
			}

			if ( isset( $GLOBALS['wp_query'] ) && $GLOBALS['wp_query'] instanceof WP_Query ) {
				jet_engine()->listings->data->set_queried_object( $item, $GLOBALS['wp_query'] );
			}

			$type->db->set_queried_item_id( absint( $popup_data['postId'] ) );
			$type->db->set_queried_item( $item );
		}

		/**
		 * Check that the requested popup is a published JetPopup post.
		 *
		 * @param int $popup_id Popup post ID.
		 *
		 * @return bool
		 */
		private function is_public_popup( $popup_id ) {
			$popup = $popup_id ? get_post( $popup_id ) : false;

			return $popup instanceof WP_Post
				&& 'jet-popup' === $popup->post_type
				&& 'publish' === $popup->post_status;
		}

		/**
		 * Check that a request supplied render context may be exposed.
		 *
			 * Anonymous visitors may render only published posts from public or
			 * publicly queryable post types. Authenticated users still need read access for
		 * non-public content.
		 *
		 * @param int|string $post_id Render context object ID.
		 *
		 * @return bool
		 */
		private function is_allowed_render_context( $post_id, $source = 'posts', $popup_data = [] ) {
			if ( 'jet-booking-query' === $source ) {
				if (
					empty( $popup_data['isJetEngine'] )
					|| empty( $popup_data['queryId'] )
					|| 'query' !== ( $popup_data['listingSource'] ?? '' )
					|| ! is_scalar( $post_id )
					|| ! preg_match( '/^[1-9][0-9]*$/D', (string) $post_id )
					|| ! class_exists( '\Jet_Engine\Query_Builder\Manager' )
				) {
					return false;
				}

				$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

				if ( ! $query || 'jet-booking-query' !== $query->query_type || ! is_callable( [ $query, 'get_booking_items' ] ) ) {
					return false;
				}

				// Booking IDs belong to JetBooking, not wp_posts. Keep the saved
				// query restrictions (including the current user), but allow items
				// from any page without changing the shared query used for rendering.
				$query = clone $query;
				$query->setup_query();
				unset( $query->final_query['offset'] );

				foreach ( $query->get_booking_items( false ) as $booking ) {
					if ( $booking instanceof \JET_ABAF\Resources\Booking && (string) $booking->get_id() === (string) $post_id ) {
						return true;
					}
				}

				return false;
			}

			if ( 'repeater' === $source ) {
				// Direct Repeater Field listings pass the parent post ID. Only
				// Query Builder repeaters use a composite query-parent-index ID.
				if ( empty( $popup_data['queryId'] ) && is_numeric( $post_id ) ) {
					return $this->is_allowed_render_context( absint( $post_id ) );
				}

				// Repeater IDs are query-parent-index (or query-index for options),
				// not post IDs. Check the parent without changing JetEngine's item ID.
				if (
					! is_string( $post_id )
					|| ! preg_match( '/^([0-9]+)-(?:([0-9]+)-)?([0-9]+)$/D', $post_id, $id_parts )
					|| empty( $popup_data['isJetEngine'] )
					|| empty( $popup_data['queryId'] )
					|| (string) $popup_data['queryId'] !== $id_parts[1]
					|| ! class_exists( '\\Jet_Engine\\Query_Builder\\Manager' )
				) {
					return false;
				}

				$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

				if ( ! $query || 'repeater' !== $query->query_type ) {
					return false;
				}

				if ( ! empty( $id_parts[2] ) ) {
					return $this->is_allowed_render_context( absint( $id_parts[2] ) );
				}

				$query->setup_query();

				return isset( $query->final_query['source'] ) && 'jet_engine_option' === $query->final_query['source'];
			}

			if ( in_array( $source, [ 'terms', 'WP_Term' ], true ) ) {
				$term = get_term( $post_id );

				if ( ! $term instanceof WP_Term ) {
					return false;
				}

				return is_taxonomy_viewable( $term->taxonomy )
					|| ( is_user_logged_in() && current_user_can( 'edit_term', $term->term_id ) );
			}

			if ( in_array( $source, [ 'comments', 'WP_Comment' ], true ) ) {
				$comment = get_comment( $post_id );

				return $comment instanceof WP_Comment
					&& $this->is_allowed_render_context( $comment->comment_post_ID )
					&& ( '1' === (string) $comment->comment_approved
						|| ( is_user_logged_in() && current_user_can( 'edit_comment', $comment->comment_ID ) ) );
			}

			// JetEngine passes the listing object ID as postId, including users.
			if ( in_array( $source, [ 'users', 'WP_User' ], true ) ) {
				return get_user_by( 'ID', $post_id ) instanceof WP_User;
			}

			if ( in_array( $source, [ 'custom-content-type', 'custom_content_type', 'custom-content-types' ], true ) ) {
				$cct_slug = ! empty( $popup_data['cctSlug'] ) ? sanitize_key( $popup_data['cctSlug'] ) : '';

				if ( ! $cct_slug && ! empty( $popup_data['queryId'] ) && class_exists( '\Jet_Engine\Query_Builder\Manager' ) ) {
					$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

					if ( $query && 'custom-content-type' === $query->query_type ) {
						$query->setup_query();
						$cct_slug = ! empty( $query->final_query['content_type'] ) ? sanitize_key( $query->final_query['content_type'] ) : '';
					}
				}

				if ( $cct_slug && class_exists( '\Jet_Engine\Modules\Custom_Content_Types\Module' ) ) {
					$type = \Jet_Engine\Modules\Custom_Content_Types\Module::instance()->manager->get_content_types( $cct_slug );

					// Do not reject individual CCT IDs here. Some CCT database
					// drivers return an empty value before JetEngine applies its
					// listing/query context, even though the item is renderable.
					return (bool) $type;
				}

				return false;
			}

			$post = get_post( $post_id );

			if ( ! $post instanceof WP_Post ) {
				return false;
			}

			$post_type = get_post_type_object( $post->post_type );
			// Public types can disable direct front-end queries while still
			// exposing published posts through listings and their popups.
			$is_public = 'publish' === $post->post_status
				&& $post_type
				&& ( ! empty( $post_type->public ) || ! empty( $post_type->publicly_queryable ) );

			if ( $is_public ) {
				return true;
			}

			return is_user_logged_in() && current_user_can( 'read_post', $post_id );
		}

		/**
		 * Resolve the object source using the same precedence as JetEngine.
		 *
		 * @param array $popup_data Popup request data.
		 * @return string
		 */
		private function get_render_context_source( $popup_data ) {
			if ( empty( $popup_data['isJetEngine'] ) || ! function_exists( 'jet_engine' ) ) {
				return 'posts';
			}

			$source = ! empty( $popup_data['listingSource'] ) ? $popup_data['listingSource'] : 'posts';

			if ( ! empty( $popup_data['queryId'] ) && class_exists( '\Jet_Engine\Query_Builder\Manager' ) ) {
				$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $popup_data['queryId'] );

				if ( $query ) {
					$source = $query->query_type;

					if ( 'sql' === $source && ! empty( $query->query['cast_object_to'] ) ) {
						$source = $query->query['cast_object_to'];
					}
				}
			}

			return $source;
		}

		/**
		 * [jet_popup_get_content description]
		 * @return [type] [description]
		 */
		public function get_popup_content( $popup_data ) {

			$popup_id = $popup_data['popup_id'];

			if ( empty( $popup_id ) ) {
				return false;
			}

			$plugin = Elementor\Plugin::instance();

			$content = $plugin->frontend->get_builder_content( $popup_id );

			return $content;
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}
}
