<?php
namespace Jet_Popup\Compatibility;

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** Resolve non-WordPress objects through their original, signed listing query. */
class Listing_Context {

	public static function supports( $source ) {
		return in_array( $source, [ 'jet_apb_list', 'rest_api_endpoint', 'jet_reviews' ], true );
	}

	public static function add_query_data( $enabled ) {
		return $enabled || self::supports( jet_engine()->listings->data->get_listing_source() );
	}

	public static function sign_settings( $nav_settings, $settings, $renderer = null ) {
		$source = jet_engine()->listings->data->get_listing_source();

		if ( ! self::supports( $source ) ) {
			return $nav_settings;
		}

		// Sign the navigation settings already exposed by the source integration.
		unset( $nav_settings['jet_popup_context'] );
		if ( isset( $settings['jet_rest_query'] ) ) {
			$nav_settings['jet_rest_query'] = $settings['jet_rest_query'];
		}

		$payload = base64_encode( wp_json_encode( [
			'source'   => $source,
			'settings' => $nav_settings,
			'user_id'  => get_current_user_id(),
			'page'     => $renderer && ! empty( $renderer->query_vars['page'] ) ? absint( $renderer->query_vars['page'] ) : 1,
		] ) );

		$nav_settings['jet_popup_context'] = $payload . '.' . wp_hash( 'jet-popup-listing:' . $payload );
		return $nav_settings;
	}

	public static function resolve( $popup_data ) {
		if ( empty( $popup_data['listingContext'] ) || ! is_string( $popup_data['listingContext'] ) ) {
			return false;
		}

		$parts = explode( '.', $popup_data['listingContext'], 2 );
		if ( count( $parts ) !== 2 || ! hash_equals( wp_hash( 'jet-popup-listing:' . $parts[0] ), $parts[1] ) ) {
			return false;
		}

		$context = json_decode( base64_decode( $parts[0], true ), true );
		if (
			! is_array( $context )
			|| ! isset( $context['source'], $context['settings'], $context['user_id'] )
			|| ! self::supports( $context['source'] )
			|| (int) $context['user_id'] !== get_current_user_id()
			|| $context['source'] !== ( $popup_data['listingSource'] ?? '' )
			|| empty( $context['settings']['lisitng_id'] )
			|| (int) $context['settings']['lisitng_id'] !== (int) ( $popup_data['listingId'] ?? 0 )
			|| ! isset( $popup_data['postId'] ) || ! is_scalar( $popup_data['postId'] )
		) {
			return false;
		}

		$settings = $context['settings'];
		$data = jet_engine()->listings->data;
		$previous_listing = $data->get_listing();
		$previous_object = $data->get_current_object();
		$previous_request = $_REQUEST;

		try {
			$data->set_listing_by_id( $settings['lisitng_id'] );
			if ( $data->get_listing_source() !== $context['source'] ) {
				return false;
			}

			$renderer = jet_engine()->listings->get_render_instance( 'listing-grid', $settings );
			if ( ! $renderer ) {
				return false;
			}

			// Call the actual source, not an obsolete Query Builder ID left on the listing.
			// Source integrations read pagination from the listing AJAX request.
			// Expose only the signed page, never arbitrary popup request arguments.
			$_REQUEST = [ 'action' => 'jet_engine_ajax', 'page' => max( 1, (int) ( $context['page'] ?? 1 ) ) ];
			$items = apply_filters( 'jet-engine/listing/grid/query/' . $context['source'], [], $settings, $renderer );
			foreach ( (array) $items as $item ) {
				if ( is_object( $item ) && (string) $data->get_current_object_id( $item ) === (string) $popup_data['postId'] ) {
					return $item;
				}
			}
		} finally {
			$_REQUEST = $previous_request;
			$data->set_listing( $previous_listing );
			$data->set_current_object( $previous_object );
		}

		return false;
	}
}
