<?php
/**
 * Tools Class
 *
 * @package   package_name
 * @author    Cherry Team
 * @license   GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Tricks_Tools' ) ) {

	/**
	 * Define Jet_Tricks_Tools class
	 */
	class Jet_Tricks_Tools {

		public static $new_icon_prefix  = 'selected_';

		/**
		 * Keep static SVG icon geometry, excluding active content and external references.
		 */
		public static function sanitize_svg( $svg ) {
			if ( ! class_exists( 'DOMDocument' ) || stripos( $svg, '<!DOCTYPE' ) !== false || stripos( $svg, '<!ENTITY' ) !== false ) {
				return '';
			}

			$document = new DOMDocument();
			$previous = libxml_use_internal_errors( true );
			$loaded   = $document->loadXML( $svg, LIBXML_NONET );
			libxml_clear_errors();
			libxml_use_internal_errors( $previous );

			if ( ! $loaded || ! $document->documentElement || 'svg' !== $document->documentElement->tagName ) {
				return '';
			}

			$tags = array( 'svg', 'g', 'defs', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'title', 'desc', 'linearGradient', 'radialGradient', 'stop', 'clipPath' );
			$attributes = array( 'id', 'class', 'viewBox', 'width', 'height', 'preserveAspectRatio', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'd', 'points', 'transform', 'fill', 'fill-rule', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-opacity', 'opacity', 'color', 'clip-path', 'clip-rule', 'clipPathUnits', 'gradientUnits', 'gradientTransform', 'spreadMethod', 'offset', 'stop-color', 'stop-opacity', 'fx', 'fy', 'fr', 'role', 'aria-hidden', 'aria-label', 'focusable' );
			$clean = function ( $element ) use ( &$clean, $tags, $attributes ) {
				foreach ( iterator_to_array( $element->attributes ) as $attribute ) {
					$name  = $attribute->nodeName;
					$value = $attribute->nodeValue;
					if ( ! in_array( $name, $attributes, true ) || $attribute->namespaceURI || ( false !== stripos( $value, 'url' ) && ! preg_match( '/^url\(\s*#[a-zA-Z0-9_-]+\s*\)$/D', $value ) ) ) {
						$element->removeAttributeNode( $attribute );
					}
				}
				foreach ( iterator_to_array( $element->childNodes ) as $child ) {
					if ( XML_ELEMENT_NODE === $child->nodeType ) {
						if ( ! in_array( $child->tagName, $tags, true ) || ( $child->namespaceURI && 'http://www.w3.org/2000/svg' !== $child->namespaceURI ) ) {
							$element->removeChild( $child );
						} else {
							$clean( $child );
						}
					} elseif ( XML_TEXT_NODE !== $child->nodeType ) {
						$element->removeChild( $child );
					}
				}
			};
			$clean( $document->documentElement );

			return $document->saveXML( $document->documentElement );
		}

		/**
		 * Returns HTML icon markup
		 *
		 * @param  array  $setting
		 * @param  array  $settings
		 * @param  string $format
		 * @param  string $icon_class
		 * @return string
		 */
		public static function get_icon( $setting = null, $settings = null, $format = '%s', $icon_class = '' ) {
			return self::render_icon( $setting, $settings, $format, $icon_class, false );
		}

		/**
		 * Print HTML icon template
		 *
		 * @param  array  $setting
		 * @param  array  $settings
		 * @param  string $format
		 * @param  string $icon_class
		 * @param  bool   $echo
		 *
		 * @return void|string
		 */
		public static function render_icon( $setting = null, $settings = null, $format = '%s', $icon_class = '', $echo = true ) {

			if ( null === $settings ) {
				return;
			}

			$new_setting = self::$new_icon_prefix . $setting;

			$migrated = isset( $settings['__fa4_migrated'][ $new_setting ] );
			$is_new = ( empty( $settings[ $setting ] ) || 'false' === $settings[ $setting ] )
			          && class_exists( 'Elementor\Icons_Manager' ) && Elementor\Icons_Manager::is_migration_allowed();

			$icon_html = '';

			if ( $is_new || $migrated ) {

				$attr = array( 'aria-hidden' => 'true' );

				if ( ! empty( $icon_class ) ) {
					$attr['class'] = $icon_class;
				}

				if ( isset( $settings[ $new_setting ] ) ) {
					ob_start();
					Elementor\Icons_Manager::render_icon( $settings[ $new_setting ], $attr );

					$icon_html = ob_get_clean();
				}

			} else if ( ! empty( $settings[ $setting ] ) ) {

				if ( empty( $icon_class ) ) {
					$icon_class = $settings[ $setting ];
				} else {
					$icon_class .= ' ' . $settings[ $setting ];
				}

				$icon_html = sprintf( '<i class="%s" aria-hidden="true"></i>', esc_attr( $icon_class ) );
			}

			if ( empty( $icon_html ) ) {
				return;
			}

			if ( ! $echo ) {
				return sprintf( $format, $icon_html );
			}
			
			printf( $format, $icon_html ); // phpcs:ignore
		}

	}

}
