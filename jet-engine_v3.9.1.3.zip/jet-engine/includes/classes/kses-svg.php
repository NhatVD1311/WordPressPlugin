<?php
/**
 * Scoped KSES support for static inline SVG.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Validate standalone SVG fragments for use in HTML text positions.
 */
final class Jet_Engine_KSES_SVG {

	public const CONTEXT = 'jet-engine/static-svg';
	public const MAX_BYTES = 32768;
	private const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
	private const ELEMENT_ATTRIBUTES = array(
		'svg'      => array( 'viewBox', 'width', 'height' ),
		'g'        => array(),
		'path'     => array( 'd' ),
		'circle'   => array( 'cx', 'cy', 'r' ),
		'ellipse'  => array( 'cx', 'cy', 'rx', 'ry' ),
		'line'     => array( 'x1', 'x2', 'y1', 'y2' ),
		'rect'     => array( 'x', 'y', 'rx', 'ry', 'width', 'height' ),
		'polygon'  => array( 'points' ),
		'polyline' => array( 'points' ),
		'title'    => array(),
		'desc'     => array(),
	);
	private const COMMON_ATTRIBUTES = array(
		'class', 'fill', 'fill-rule', 'fill-opacity', 'stroke', 'stroke-width',
		'stroke-opacity', 'stroke-linecap', 'stroke-linejoin', 'opacity', 'transform',
	);

	private const CACHE_SIZE = 64;

	/** @var string[] Sanitized results keyed by source hash, for this request only. */
	private static $cache = array();
	/** @var int Number of active SVG scopes. */
	private static $depth = 0;
	/** @var Closure|null Callback for the context's allowlist. */
	private static $allowed_html = null;
	/** @var Closure|null Callback for validating the standalone fragment. */
	private static $pre_kses = null;

	/**
	 * Install the SVG policy for wp_kses() calls using self::CONTEXT.
	 *
	 * Pair each call with remove_svg_support() in a finally block. Nested scopes
	 * share the hooks. The SVG context returns empty for invalid input.
	 *
	 * @return void
	 */
	public static function add_svg_support() {
		if ( self::$depth++ ) {
			return;
		}

		if ( null === self::$allowed_html ) {
			$allowlist = array();
			foreach ( self::ELEMENT_ATTRIBUTES as $tag => $attributes ) {
				$allowlist[ $tag ] = array_fill_keys( array_map( 'strtolower', array_merge( $attributes, self::COMMON_ATTRIBUTES ) ), true );
			}
			$allowlist['svg']['xmlns'] = true;

			self::$allowed_html = static function ( $allowed, $context ) use ( $allowlist ) {
				return self::CONTEXT === $context ? $allowlist : $allowed;
			};
			self::$pre_kses = static function ( $content, $context ) {
				return self::CONTEXT === $context ? self::validate_fragment( $content ) : $content;
			};
		}

		add_filter( 'wp_kses_allowed_html', self::$allowed_html, PHP_INT_MAX, 2 );
		add_filter( 'pre_kses', self::$pre_kses, PHP_INT_MAX, 2 );
	}

	/**
	 * Release one SVG scope and detach both filters when the last scope ends.
	 *
	 * @return void
	 */
	public static function remove_svg_support() {
		if ( ! self::$depth || --self::$depth ) {
			return;
		}

		remove_filter( 'pre_kses', self::$pre_kses, PHP_INT_MAX );
		remove_filter( 'wp_kses_allowed_html', self::$allowed_html, PHP_INT_MAX );
	}

	/**
	 * Sanitize standalone SVG markup with this policy, reusing earlier results in the request.
	 *
	 * The result is cached by source content, so a repeated icon is parsed once and a
	 * changed file is parsed again. A failed render (exception) is not cached.
	 *
	 * @param mixed $source    SVG markup.
	 * @param int   $max_bytes Byte limit for the result, at most self::MAX_BYTES.
	 * @return string Sanitized SVG, or an empty string when unsupported or over the limit.
	 */
	public static function sanitize_markup( $source, $max_bytes ) {
		if ( $max_bytes < 1 || ! is_string( $source ) || '' === $source || strlen( $source ) > self::MAX_BYTES || ! class_exists( 'DOMDocument' ) ) {
			return '';
		}

		$key = hash( 'sha256', $source );
		if ( ! isset( self::$cache[ $key ] ) ) {
			self::add_svg_support();
			try {
				$svg = wp_kses( $source, self::CONTEXT );
			} finally {
				self::remove_svg_support();
			}

			if ( count( self::$cache ) >= self::CACHE_SIZE ) {
				array_shift( self::$cache );
			}
			self::$cache[ $key ] = strlen( $svg ) <= self::MAX_BYTES ? $svg : '';
		}

		return strlen( self::$cache[ $key ] ) <= $max_bytes ? self::$cache[ $key ] : '';
	}

	/**
	 * Read and sanitize a publicly viewable SVG attachment from the local uploads directory.
	 *
	 * @param int $attachment_id WordPress SVG attachment ID.
	 * @param int $max_bytes     Byte limit for the result.
	 * @return string Sanitized SVG, or an empty string so the caller can use its fallback.
	 */
	public static function read_attachment( $attachment_id, $max_bytes ) {
		if ( $max_bytes < 1 || ! class_exists( 'DOMDocument' ) ) {
			return '';
		}

		$attachment = get_post( $attachment_id );
		if ( ! $attachment || 'attachment' !== $attachment->post_type || ! empty( $attachment->post_password )
			|| ! in_array( $attachment->post_status, array( 'publish', 'inherit' ), true ) ) {
			return '';
		}
		if ( $attachment->post_parent ) {
			$parent = get_post( $attachment->post_parent );
			if ( ! $parent || ! empty( $parent->post_password ) || ! is_post_publicly_viewable( $parent ) ) {
				return '';
			}
		}

		$uploads = wp_get_upload_dir();
		$attached_file = get_attached_file( $attachment_id, true );
		$directory = empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) ? @realpath( $uploads['basedir'] ) : false;
		$file = $attached_file ? @realpath( $attached_file ) : false;
		if ( ! $directory || ! $file || 0 !== strpos( $file, $directory . DIRECTORY_SEPARATOR ) || ! is_file( $file ) ) {
			return '';
		}

		// A replaced or unreadable file should fall back without exposing paths in the response.
		$source = @file_get_contents( $file, false, null, 0, self::MAX_BYTES + 1 );
		return self::sanitize_markup( $source, $max_bytes );
	}

	/**
	 * Parse and validate one bounded SVG tree with no external XML resources.
	 *
	 * @param string $content Attachment markup.
	 * @return string Validated fragment or an empty string when unsupported.
	 */
	private static function validate_fragment( $content ) {
		if ( ! class_exists( 'DOMDocument' ) || '' === $content || strlen( $content ) > self::MAX_BYTES
			|| false !== strpos( $content, "\0" ) || false !== strpos( $content, '<!DOCTYPE' ) || 1 !== preg_match( '//u', $content ) ) {
			return '';
		}

		// The fragment is UTF-8. Do not let a declaration select another encoding.
		$content = preg_replace( '/\A(?:\xEF\xBB\xBF)?<\?xml[ \t\r\n]+[^?]*\?>/', '', $content, 1 );
		if ( ! $content ) {
			return '';
		}

		$flags = LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING;
		if ( defined( 'LIBXML_NO_XXE' ) ) {
			$flags |= LIBXML_NO_XXE;
		}

		$document = new DOMDocument();
		if ( ! $document->loadXML( $content, $flags )
			|| $document->doctype || ! $document->documentElement || 'svg' !== $document->documentElement->localName ) {
			return '';
		}

		foreach ( $document->childNodes as $node ) {
			if ( $node instanceof DOMProcessingInstruction ) {
				return '';
			}
		}

		$remaining = 256;
		if ( ! self::validate_element( $document->documentElement, $remaining, 1 ) ) {
			return '';
		}

		return (string) $document->saveXML( $document->documentElement, LIBXML_NOEMPTYTAG );
	}

	/**
	 * Check element namespaces, paint values, child types and complexity limits.
	 *
	 * @param DOMElement $element   Current SVG element.
	 * @param int        $remaining Remaining element budget, decremented for every visited element.
	 * @param int        $depth     Current depth, starting at one for the root.
	 * @return bool Whether the subtree can be embedded as HTML.
	 */
	private static function validate_element( $element, &$remaining, $depth ) {
		$tag = $element->localName;
		if ( --$remaining < 0 || $depth > 16 || ! empty( $element->prefix )
			|| self::SVG_NAMESPACE !== $element->namespaceURI || ! isset( self::ELEMENT_ATTRIBUTES[ $tag ] ) ) {
			return false;
		}

		$attributes = array_merge( self::ELEMENT_ATTRIBUTES[ $tag ], self::COMMON_ATTRIBUTES );
		foreach ( $element->attributes as $attribute ) {
			if ( $attribute->namespaceURI || ! in_array( $attribute->name, $attributes, true )
				|| ! self::validate_attribute( $attribute->name, $attribute->value ) ) {
				return false;
			}
		}

		$accepts_elements = 'svg' === $tag || 'g' === $tag;
		$accepts_text = 'title' === $tag || 'desc' === $tag;
		foreach ( $element->childNodes as $child ) {
			if ( $child instanceof DOMElement ) {
				if ( ! $accepts_elements || 'svg' === $child->localName || ! self::validate_element( $child, $remaining, $depth + 1 ) ) {
					return false;
				}
			} elseif ( $child instanceof DOMText && XML_TEXT_NODE === $child->nodeType ) {
				if ( $accepts_text ? false !== strpos( $child->nodeValue, '[' ) : '' !== trim( $child->nodeValue ) ) {
					return false;
				}
			} else {
				return false;
			}
		}

		return true;
	}

	/**
	 * Validate decoded SVG attribute values before serializing the fragment.
	 *
	 * @param string $name  Case-sensitive attribute name.
	 * @param string $value Decoded XML attribute value.
	 * @return bool Whether the value belongs to the static SVG subset.
	 */
	private static function validate_attribute( $name, $value ) {
		switch ( $name ) {
			case 'class':
				return 1 === preg_match( '/\A[A-Za-z0-9_\-\s]{1,256}\z/D', $value );
			case 'fill':
			case 'stroke':
				return 1 === preg_match( '/\A(?:[a-z]+|#(?:[a-f0-9]{3,4}|[a-f0-9]{6}|[a-f0-9]{8}))\z/iD', $value );
			case 'fill-rule':
				return in_array( $value, array( 'nonzero', 'evenodd' ), true );
			case 'stroke-linecap':
				return in_array( $value, array( 'butt', 'round', 'square' ), true );
			case 'stroke-linejoin':
				return in_array( $value, array( 'miter', 'round', 'bevel' ), true );
			case 'd':
				return 1 === preg_match( '/\A[MmZzLlHhVvCcSsQqTtAaEe0-9.,+\-\s]+\z/D', $value );
			case 'points':
			case 'viewBox':
				return 1 === preg_match( '/\A[0-9Ee.,+\-\s]+\z/D', $value );
			case 'transform':
				return strlen( $value ) <= 512 && 1 === preg_match( '/\A\s*+(?:(?:matrix|translate|scale|rotate|skewX|skewY)\([0-9Ee.,+\-\s]++\)\s*+,?\s*+)+\z/D', $value );
			default:
				return 1 === preg_match( '/\A[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?(?:%|px|em|rem)?\z/D', $value );
		}
	}
}
