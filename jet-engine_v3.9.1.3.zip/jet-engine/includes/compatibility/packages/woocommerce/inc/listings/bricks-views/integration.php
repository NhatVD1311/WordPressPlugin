<?php
namespace Jet_Engine\Compatibility\Packages\Jet_Engine_Woo_Package\Listings\Bricks_Views;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/** Submit Woo Data through the shared JetEngine Bricks registration lifecycle. */
class Integration {

	/**
	 * Submit the element now; the manager defers inclusion until dependencies load.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->register_elements();
	}

	/**
	 * Load Woo's renderer class and submit its element when compatibility is active.
	 *
	 * Does not instantiate the renderer. Bricks/element loading errors propagate.
	 *
	 * @return void
	 */
	public function register_elements() {

		$manager = jet_engine()->bricks_views;

		if ( ! $manager || ! $manager->has_bricks() ) {
			return;
		}

		// Bricks can load controls before the Query Builder integrations initialize.
		require_once dirname( __DIR__ ) . '/data-render.php';

		$woo_el_file = __DIR__ . '/elements/woo-data.php';
		$manager->register_custom_bricks_element( $woo_el_file );
	}
}
