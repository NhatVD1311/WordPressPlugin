<?php
/**
 * Preserve the legacy Woo Data include path without defining a second integration.
 */
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once dirname( __DIR__, 2 ) . '/listings/bricks-views/integration.php';
