<?php

namespace KaliForms\Inc\Utils\EmailUtilities;

/**
 * Email logger
 */
class Email_Logger
{
    /**
     * Plugin slug
     *
     * @var string
     */
    public $slug = 'kaliforms';
    /**
     * Filename
     *
     * @var string
     */
    public $filename = '';
    /**
     * Path
     *
     * @var string
     */
    public $path = '';
    /**
     * Is it enabled
     *
     * @var boolean
     */
    public $enabled = false;
    public $mailer;
    /**
     * Class constructor
     */
    public function __construct()
    {
        $enabled =    get_option($this->slug . '_email_log', "");
        $this->enabled = !empty($enabled);
        $this->path     = get_temp_dir();

        $this->filename = $this->slug . '-' . sanitize_file_name(get_home_url()) . '-mail.log';
        $this->mailer   = get_option($this->slug . '_smtp_provider', '');

        add_action('kali_mail_failed', [$this, 'error'], 10, 1);
        add_action('wp_mail_failed', [$this, 'error'], 10, 1);
        add_action('kali_mail_success', [$this, 'ok'], 10, 1);
    }
    /**
     * Get instance
     *
     * @return void
     */
    public static function get_instance()
    {
        static $inst;
        if (!$inst) {
            $inst = new self();
        }

        return $inst;
    }
    /**
     * Error occured
     *
     * @return void
     */
    public function error($wp_error)
    {
        if (!$this->enabled) {
            return;
        }

        $this->append_to_log($this->_template([
            'type'    => 'ERROR',
            'message' => $wp_error->get_error_message(),
        ]));
    }
    /**
     * Ok function
     *
     * @return void
     */
    public function ok($message)
    {
        if (!$this->enabled) {
            return;
        }

        $this->append_to_log($this->_template([
            'type'    => 'INFO',
            'message' => $message,
        ]));
    }
    /**
     * Template
     *
     * @param [type] $data
     * @return void
     */
    public function _template($data)
    {
        $data['message'] = str_replace(["\r", "\n"], ' ', $data['message']);
        $str             = $this->mailer . "|" . gmdate('Y-m-d H:i:s') . "|" . $data['type'] . "|" . $data['message'];
        return $str;
    }

    /**
     * Append a line to the email log file.
     *
     * @param string $line Log line.
     * @return void
     */
    private function append_to_log($line)
    {
        global $wp_filesystem;

        if (empty($wp_filesystem)) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            WP_Filesystem();
        }

        $file     = $this->path . $this->filename;
        $existing = $wp_filesystem->exists($file) ? $wp_filesystem->get_contents($file) : '';
        $wp_filesystem->put_contents($file, $existing . $line . "\n", FS_CHMOD_FILE);
    }
    /**
     * Gets the user log
     *
     * @return void
     */
    public function get_log()
    {
        if (!current_user_can('administrator')) {
            wp_die(wp_json_encode([
                'success' => false,
                'message' => esc_html__('Denied', 'kali-forms'),
            ]));
        }

        if (!isset($_POST['args'], $_POST['args']['nonce'])) {
            wp_die(wp_json_encode([
                'success' => false,
                'message' => esc_html__('Denied', 'kali-forms'),
            ]));
        }

        if (!wp_verify_nonce(sanitize_key(wp_unslash($_POST['args']['nonce'])), $this->slug . '_nonce')) {
            wp_die(wp_json_encode([
                'success' => false,
                'message' => esc_html__('Denied', 'kali-forms'),
            ]));
        }

        if (!file_exists($this->path . $this->filename)) {
            return wp_die(wp_json_encode(['success' => false, 'content' => __('No email sent yet', 'kali-forms')]));
        }

        $content  = file_get_contents($this->path . $this->filename);
        $exploded = explode("\n", $content);
        $data     = [];
        $i        = 0;

        foreach ($exploded as $data_entry) {
            if (empty($data_entry)) {
                continue;
            }

            $parts  = explode('|', $data_entry);
            $data[] = [
                'id'      => $i,
                'mailer'  => isset($parts[0]) ? $parts[0] : '-',
                'date'    => isset($parts[1]) ? $parts[1] : '-',
                'type'    => isset($parts[2]) ? $parts[2] : '-',
                'message' => isset($parts[3]) ? $parts[3] : '-',
                'info'    => $parts[2] === 'ERROR' ? 'https://kaliforms.com/docs/faq/' : 'ok',
            ];
            $i++;
        }
        return wp_die(wp_json_encode(['success' => true, 'content' => array_reverse($data)]));
    }
    /**
     * If the user is not authorized, deny action
     */
    public function denied()
    {
        wp_die(esc_html__('Denied', 'kali-forms'));
    }
}
