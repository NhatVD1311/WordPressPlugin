<?php
/**
 * Non render-blocking stylesheet loading.
 *
 * @package Fusion-Library
 * @since 3.16
 */

/**
 * Rewrites flagged stylesheet tags so they do not block the first paint.
 *
 * Rewriting the tag is the only dependable way to do this: where a stylesheet gets
 * printed is not ours to control - core hoists late-printed styles into the head -
 * but its markup is, and a tag that is non-blocking is non-blocking anywhere.
 *
 * @since 3.16
 */
class AWB_Deferred_Styles {

	/**
	 * Handles that should be loaded without blocking rendering.
	 *
	 * @static
	 * @access private
	 * @since 3.16
	 * @var array
	 */
	private static $handles = [];

	/**
	 * Flags one or more handles as non render-blocking.
	 *
	 * @static
	 * @access public
	 * @since 3.16
	 * @param string|array $handle The style handle, or an array of handles.
	 * @return void
	 */
	public static function add( $handle ) {
		if ( empty( self::$handles ) ) {
			// Run last so we rewrite the final markup.
			add_filter( 'style_loader_tag', [ __CLASS__, 'filter_style_tag' ], PHP_INT_MAX - 10, 4 );
		}

		foreach ( (array) $handle as $single ) {
			self::$handles[ $single ] = true;
		}
	}

	/**
	 * Rewrites the link tag of a flagged stylesheet.
	 *
	 * @static
	 * @access public
	 * @since 3.16
	 * @param string $tag    The link tag for the enqueued style.
	 * @param string $handle The style's registered handle.
	 * @param string $href   The stylesheet's source URL.
	 * @param string $media  The stylesheet's media attribute.
	 * @return string
	 */
	public static function filter_style_tag( $tag, $handle, $href, $media ) {

		if ( ! isset( self::$handles[ $handle ] ) ) {
			return $tag;
		}

		// Already out of the critical path, and swapping the media back would be wrong.
		if ( 'print' === $media ) {
			return $tag;
		}

		// AMP does not allow the inline event handler this relies on.
		if ( class_exists( 'Fusion_AMP' ) && Fusion_AMP::is_amp_endpoint() ) {
			return $tag;
		}

		$strategy = self::get_strategy( $handle, $media );

		if ( 'print' === $strategy ) {
			$async = self::to_print_media_swap( $tag, $media );
		} elseif ( 'preload' === $strategy ) {
			$async = self::to_preload_swap( $tag );
		} else {
			return $tag;
		}

		// Another filter has changed the markup beyond what we can safely rewrite.
		if ( ! $async || $async === $tag ) {
			return $tag;
		}

		return $async . '<noscript>' . self::to_noscript_fallback( $tag ) . "</noscript>\n";
	}

	/**
	 * Determines how a stylesheet should be loaded.
	 *
	 * @static
	 * @access public
	 * @since 3.16
	 * @param string $handle The style's registered handle.
	 * @param string $media  The stylesheet's media attribute.
	 * @return string|false 'print', 'preload', or false to leave the tag alone.
	 */
	public static function get_strategy( $handle, $media = 'all' ) {

		// With critical CSS the initial render is covered, so stay out of the LCP image's
		// way. Without it the page is unstyled until this lands, so fetch it eagerly.
		$strategy = awb_has_critical_css() ? 'print' : 'preload';

		// A non-matching rel=preload is skipped by the browser, which would leave us
		// without the stylesheet if the viewport later changes to match it.
		if ( 'all' !== $media ) {
			$strategy = 'print';
		}

		/**
		 * Filters the strategy used to load a deferred stylesheet.
		 *
		 * @since 3.16
		 * @param string|false $strategy 'print' for a non-matching-media swap, 'preload'
		 *                               for a rel=preload swap, or false to leave the tag as-is.
		 * @param string       $handle   The style's registered handle.
		 * @param string       $media    The stylesheet's media attribute.
		 */
		return apply_filters( 'awb_deferred_stylesheet_strategy', $strategy, $handle, $media );
	}

	/**
	 * Swaps the media attribute out for "print" and restores it once loaded.
	 *
	 * Downloads at the lowest network priority and, not applying to the current
	 * media, does not block rendering.
	 *
	 * @static
	 * @access private
	 * @since 3.16
	 * @param string $tag   The link tag.
	 * @param string $media The stylesheet's media attribute.
	 * @return string
	 */
	private static function to_print_media_swap( $tag, $media ) {
		$onload = ' media="print" onload="this.media=\'' . esc_attr( $media ) . '\';this.onload=null;"';

		if ( preg_match( '/\smedia=([\'"]).*?\1/', $tag, $matches ) ) {
			return str_replace( $matches[0], $onload, $tag );
		}

		return preg_replace( '/^<link\b/', '<link' . $onload, $tag, 1 );
	}

	/**
	 * Turns the stylesheet into a preload that promotes itself once loaded.
	 *
	 * @static
	 * @access private
	 * @since 3.16
	 * @param string $tag The link tag.
	 * @return string
	 */
	private static function to_preload_swap( $tag ) {
		$preload = preg_replace( '/(\srel=)([\'"])stylesheet\2/', '$1$2preload$2 as=$2style$2', $tag, 1 );

		if ( null === $preload || $preload === $tag ) {
			return '';
		}

		$trailing = ( substr( $tag, -1 ) === "\n" ) ? "\n" : '';

		return preg_replace(
			'/\s*\/?>\s*$/',
			' onload="this.rel=\'stylesheet\';this.onload=null;" />' . $trailing,
			$preload,
			1
		);
	}

	/**
	 * Builds the no-JS fallback copy of the tag, without the id so the two never collide.
	 *
	 * @static
	 * @access private
	 * @since 3.16
	 * @param string $tag The original link tag.
	 * @return string
	 */
	private static function to_noscript_fallback( $tag ) {
		return trim( preg_replace( '/\sid=([\'"]).*?\1/', '', $tag, 1 ) );
	}
}

/* Omit closing PHP tag to avoid "Headers already sent" issues. */
