<?php
/**
 * Custom Icons helper functions.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://classic.avada.com
 * @package    Fusion-Library
 * @since      2.2
 */

/**
 * Get Icon Set CSS URL.
 *
 * @since 6.2
 * @param int $post_id Post ID.
 * @return string URL.
 */
function fusion_get_custom_icons_css_url( $post_id = 0 ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$icon_set = fusion_data()->post_meta( $post_id )->get( 'custom_icon_set' );

	return ! empty( $icon_set['icon_set_dir_name'] ) ? FUSION_ICONS_BASE_URL . $icon_set['icon_set_dir_name'] . '/style.css' : '';
}

/**
 * WIP.
 *
 * @since 6.2
 * @param array $args Optional WP_Query arguments.
 * @return array Icon array.
 */
function fusion_get_custom_icons_array( $args = [] ) {

	$upload_dir         = wp_upload_dir();
	$icons_base_dir_url = trailingslashit( $upload_dir['baseurl'] ) . 'fusion-icons/';

	$custom_icons = [];
	$default_args = [
		'post_type'      => 'fusion_icons',
		'post_status'    => 'publish',
		'posts_per_page' => -1, // phpcs:ignore WPThemeReview.CoreFunctionality.PostsPerPage.posts_per_page_posts_per_page
	];

	$args = wp_parse_args(
		$args,
		$default_args
	);

	$posts = get_posts( $args );
	foreach ( $posts as $post ) {
		$meta = fusion_data()->post_meta( $post->ID )->get( 'custom_icon_set' );

		if ( '' !== $meta ) {

			// Sets saved before names were checked on upload get the same check here.
			$custom_icons[ $post->post_name ]            = awb_sanitize_icon_set_data( $meta );
			$custom_icons[ $post->post_name ]['name']    = get_the_title( $post->ID );
			$custom_icons[ $post->post_name ]['post_id'] = $post->ID;
			$custom_icons[ $post->post_name ]['css_url'] = fusion_get_custom_icons_css_url( $post->ID );
		}
	}

	return apply_filters( 'fusion_custom_icons', $custom_icons );
}

/**
 * Gets preload tags for custom icons.
 *
 * @since 7.2
 * @return string.
 */
function fusion_get_custom_icons_preload_tags() {

	// Renamed when the font path check was added, so tags cached before it are not used.
	$transient_name = 'awb_custom_icons_preload_tags';
	$tags           = get_transient( $transient_name );

	if ( ! $tags ) {
		$icons         = fusion_get_custom_icons_array();
		$wp_filesystem = Fusion_Helper::init_filesystem();
		foreach ( $icons as $icon ) {

			if ( ! isset( $icon['icon_set_dir_name'] ) || ! file_exists( FUSION_ICONS_BASE_DIR . $icon['icon_set_dir_name'] . '/style.css' ) ) {
				continue;
			}

			// Get the file contents.
			$file_contents = $wp_filesystem->get_contents( $icon['css_url'] );

			// If it failed, try wp_remote_get().
			if ( ! $file_contents ) {
				$response = wp_remote_get( $icon['css_url'] );
				if ( is_array( $response ) ) {
					$file_contents = wp_remote_retrieve_body( $response );
				}
			}

			if ( $file_contents ) {
				// Get font files. The stylesheet comes from an uploaded package, so a match is only a plain path and query.
				preg_match_all( '/fonts\/[^\'"()<>\\\\\s?#]+\.ttf(?:\?[^\'"()<>\\\\\s#]*)?(?=[\'")\s])/', $file_contents, $matches );
				$matches = array_shift( $matches );

				foreach ( $matches as $match ) {
					$path = ! empty( $icon['icon_set_dir_name'] ) ? FUSION_ICONS_BASE_URL . $icon['icon_set_dir_name'] . '/' . $match : false;

					if ( $path ) {
						$tags .= '<link rel="preload" href="' . esc_url( $path ) . '" as="font" type="font/ttf" crossorigin>';
					}
				}
			}
		}

		set_transient( $transient_name, $tags );
	}

	return $tags;
}

/**
 * Checks an icon name or CSS prefix from an icon set package. Both end up in class names and
 * in the icon pickers' markup, so only letters, digits, underscores and hyphens are kept.
 *
 * @since 3.16.3
 * @param mixed $value The icon name or prefix.
 * @return string The value, or an empty string if it is not usable.
 */
function awb_sanitize_icon_class_part( $value ) {
	$value = is_scalar( $value ) ? trim( (string) $value ) : '';

	return 1 === preg_match( '/^[\p{L}\p{N}_-]+$/u', $value ) ? $value : '';
}

/**
 * Keeps only the usable icon names and prefix of an icon set.
 *
 * @since 3.16.3
 * @param mixed $icon_set The icon set data, as stored in the custom_icon_set post meta.
 * @return mixed The icon set data.
 */
function awb_sanitize_icon_set_data( $icon_set ) {
	if ( ! is_array( $icon_set ) ) {
		return $icon_set;
	}

	if ( isset( $icon_set['css_prefix'] ) ) {
		$icon_set['css_prefix'] = awb_sanitize_icon_class_part( $icon_set['css_prefix'] );
	}

	if ( isset( $icon_set['icons'] ) ) {
		$icon_set['icons'] = is_array( $icon_set['icons'] ) ? array_values( array_filter( array_map( 'awb_sanitize_icon_class_part', $icon_set['icons'] ), 'strlen' ) ) : [];

		if ( isset( $icon_set['icon_count'] ) ) {
			$icon_set['icon_count'] = count( $icon_set['icons'] );
		}
	}

	return $icon_set;
}

/* Omit closing PHP tag to avoid "Headers already sent" issues. */
