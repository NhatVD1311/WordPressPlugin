<?php
/* THIS_FILE_IS_PRO */
/**
 * Dependency Checker for Kirki Pro
 * 
 * Handles automatic installation and activation of required dependencies.
 *
 * @package kirki
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KirkiProDependencyChecker {

	/**
	 * The required free plugin slug
	 */
	const KIRKI_FREE_PLUGIN_SLUG = 'kirki/kirki.php';

	/**
	 * Initialize dependency checker
	 */
	public static function init() {
		if ( ! self::is_free_active() ) {
			// Try automatic installation on first admin page load after activation
			add_action( 'admin_init', [ __CLASS__, 'auto_install_handler' ], 5 );
			
			// Handle manual installation request
			add_action( 'admin_init', [ __CLASS__, 'handle_manual_install' ], 1 );
			
			// Show notice with install button
			add_action( 'admin_notices', [ __CLASS__, 'dependency_notice' ] );
			add_action( 'network_admin_notices', [ __CLASS__, 'dependency_notice' ] );
		}
	}

	/**
	 * Determine if the free plugin is active.
	 *
	 * @return bool
	 */
	public static function is_free_active() {
		if ( class_exists( 'KirkiMain' ) ) {
			return true;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return function_exists( 'is_plugin_active' ) && is_plugin_active( self::KIRKI_FREE_PLUGIN_SLUG );
	}

	/**
	 * Check if free plugin is installed.
	 *
	 * @return bool
	 */
	public static function is_free_installed() {
		$plugin_path = WP_PLUGIN_DIR . '/' . self::KIRKI_FREE_PLUGIN_SLUG;
		return file_exists( $plugin_path );
	}

	/**
	 * Install and activate free plugin automatically.
	 *
	 * @return bool
	 */
	public static function install_and_activate_free() {
		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
			return false;
		}

		// Include required WordPress files
		if ( ! function_exists( 'plugins_api' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		}
		if ( ! class_exists( 'WP_Upgrader' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}
		if ( ! function_exists( 'activate_plugin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		// Check if already installed but not activated
		if ( self::is_free_installed() ) {
			$result = activate_plugin( self::KIRKI_FREE_PLUGIN_SLUG );
			if ( is_wp_error( $result ) ) {
				return false;
			}
			return true;
		}

		// Install the plugin
		$plugin_slug = dirname( self::KIRKI_FREE_PLUGIN_SLUG );
		
		$api = plugins_api( 'plugin_information', array(
			'slug'   => $plugin_slug,
			'fields' => array( 'sections' => false ),
		) );

		if ( is_wp_error( $api ) ) {
			return false;
		}

		$upgrader = new \Plugin_Upgrader( new \WP_Ajax_Upgrader_Skin() );
		$install_result = $upgrader->install( $api->download_link );

		if ( is_wp_error( $install_result ) || ! $install_result ) {
			return false;
		}

		// Activate the plugin
		$activate_result = activate_plugin( self::KIRKI_FREE_PLUGIN_SLUG );
		
		return ! is_wp_error( $activate_result );
	}

	/**
	 * Handle automatic installation on plugin activation.
	 */
	public static function auto_install_handler() {
		// Only run once after activation
		if ( ! get_transient( 'kirki_pro_needs_free_install' ) ) {
			return;
		}

		delete_transient( 'kirki_pro_needs_free_install' );

		// Try to install and activate automatically
		$success = self::install_and_activate_free();
		
		if ( $success ) {
			// Set success flag
			set_transient( 'kirki_free_auto_installed', 1, 30 );
			// Redirect to refresh the page after successful installation
			wp_safe_redirect( admin_url( 'plugins.php?kirki-free-installed=1' ) );
			exit;
		}
	}

	/**
	 * Display dependency admin notice when automatic installation fails.
	 */
	public static function dependency_notice() {
		if ( isset( $_GET['kirki-free-installed'] ) || get_transient( 'kirki_free_auto_installed' ) ) {
			delete_transient( 'kirki_free_auto_installed' );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Kirki free plugin has been automatically installed and activated!', 'kirki' ) . '</p></div>';
			return;
		}

		if ( isset( $_GET['kirki-free-install-failed'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Failed to automatically install Kirki free plugin. Please install it manually.', 'kirki' ) . '</p></div>';
		}

		$install_url = wp_nonce_url( 
			add_query_arg( array( 'action' => 'kirki_pro_install_free' ), admin_url( 'admin.php' ) ),
			'kirki_pro_install_free'
		);

		echo '<div class="notice notice-warning"><p>';
		echo esc_html__( 'Kirki Pro requires the Kirki free plugin to be installed and activated.', 'kirki' );
		echo ' <a href="' . esc_url( $install_url ) . '" class="button button-primary">' . esc_html__( 'Install Kirki Free Now', 'kirki' ) . '</a>';
		echo '</p></div>';
	}

	/**
	 * Handle manual installation request via admin link.
	 */
	public static function handle_manual_install() {
		if ( ! isset( $_GET['action'] ) || $_GET['action'] !== 'kirki_pro_install_free' ) {
			return;
		}

		if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'kirki_pro_install_free' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'kirki' ) );
		}

		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to install plugins.', 'kirki' ) );
		}

		$success = self::install_and_activate_free();

		if ( $success ) {
			wp_safe_redirect( admin_url( 'plugins.php?kirki-free-installed=1' ) );
		} else {
			wp_safe_redirect( admin_url( 'plugins.php?kirki-free-install-failed=1' ) );
		}
		exit;
	}

	/**
	 * Set flag on plugin activation to trigger automatic installation.
	 */
	public static function on_activation() {
		set_transient( 'kirki_pro_needs_free_install', 1, 60 );
	}
}
