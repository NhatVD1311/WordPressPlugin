<?php
/* THIS_FILE_IS_PRO */
/**
 * Plugin update events handler
 *
 * IMPORTANT: This custom update mechanism is for self-hosted/premium installations only.
 * It is NOT compatible with WordPress.org plugin directory requirements.
 * The update logic uses custom API endpoints to check for and deliver plugin updates.
 *
 * @package kirki
 */

use Kirki\Ajax\WpAdmin;
use Kirki\HelperFunctions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Custom plugin update handler for self-hosted installations.
 * 
 * Note: This class is currently commented out in kirki-pro.php (line 116).
 * Uncomment to enable custom updates for self-hosted deployments.
 */
class KirkiProPluginUpdateEvents {

	/**
	 * Product slug
	 *
	 * @var string
	 */
	private $product_slug = 'kirki-pro';

	/**
	 * Product basename
	 *
	 * @var string
	 */
	private $product_basename = 'kirki-pro/kirki-pro.php';

	/**
	 * API end point
	 *
	 * @var string
	 */
	private $api_end_point = 'https://kirki.com/wp-json/themeum-products/v1/';

	/**
	 * Themeum response data
	 *
	 * @var array
	 */
	private $themeum_response_data = array();

	public function __construct() {
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
		add_filter( 'upgrader_pre_download', array( $this, 'check_plugin_license_before_update' ), 10, 3 );

		add_action(
			'current_screen',
			function ( $screen ) {
				if ( 'plugins' === $screen->id ) {
					delete_site_transient( 'update_plugins' );
					wp_update_plugins();
				}
			}
		);
	}

	/**
	 * Hook into update_plugins transient
	 *
	 * @param object $transient Transient data.
	 * @return object
	 */
	public function check_for_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$request_body = $this->check_for_update_api();
		
		if ( is_object( $request_body ) && property_exists( $request_body, 'status' ) && 200 === $request_body->status ) {
			$is_free_updated = version_compare( KIRKI_VERSION, $request_body->body_response->version, '>=' );
			if ($is_free_updated && version_compare( KIRKI_PRO_VERSION, $request_body->body_response->version, '<' ) ) {
				$update_info = array(
					'new_version' => $request_body->body_response->version,
					'package'     => $request_body->body_response->download_url,
					'tested'      => $request_body->body_response->tested_wp_version ?? '',
					'slug'        => $this->product_basename,
					'url'         => $request_body->body_response->download_url ?? '',
				);
				$transient->response[ $this->product_basename ] = (object) $update_info;
			}
		}
		return $transient;
	}

	/**
	 * Get update information
	 *
	 * @param string $license_key License key.
	 * @return array|bool|mixed|object
	 */
	public function check_for_update_api( ) {
		if ( $this->themeum_response_data ) {
			return $this->themeum_response_data;
		}

		$common_data = WpAdmin::get_common_data( true );
		$license_key = isset( $common_data['license_key']['key'] ) ? $common_data['license_key']['key'] : '';

		$kirki_free_version = defined( 'KIRKI_VERSION' ) ? KIRKI_VERSION : '';
		$params = array(
			'body'    => array(
				'license_key'  => $license_key,
				'kirki-free-version' => $kirki_free_version,
				'product_slug' => $this->product_slug,
				'website_url'  => get_site_url(),
			),
			'headers' => array(
				'Secret-Key' => 't344d5d71sae7dcb546b8cf55e594808',
			),
		);

		$request = wp_remote_post( $this->api_end_point . 'check-update', $params );

		$response_data = array();

		if ( ! is_wp_error( $request ) && wp_remote_retrieve_response_code( $request ) === 200 ) {
			$response_data = json_decode( $request['body'] );
		}

		$this->themeum_response_data = $response_data;
		return $this->themeum_response_data;
	}

	/**
	 * Get plugin info from server.
	 *
	 * @param mixed  $res response.
	 * @param string $action action name.
	 * @param mixed  $args args.
	 *
	 * @return bool|\stdClass
	 */
	public function plugin_info( $res, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return false;
		}

		if ( $this->product_slug !== $args->slug && $this->product_basename !== $args->slug ) {
			return $res;
		}

		$remote = $this->check_for_update_api( );

		if ( ! is_wp_error( $remote ) && is_object( $remote ) && isset( $remote->body_response ) ) {
			$res               = new \stdClass();
			$res->name         = $remote->body_response->plugin_name ?? 'Kirki Pro';
			$res->slug         = $this->product_slug;
			$res->version      = $remote->body_response->version ?? '';
			$res->last_updated = $remote->body_response->updated_at ?? '';
			$res->sections     = array(
				'changelog' => $remote->body_response->change_log ?? '',
			);
			return $res;
		}
		return false;
	}

	/**
	 * Check plugin license before update
	 *
	 * @param bool   $reply    Reply.
	 * @param string $package  Download uri.
	 * @param object $upgrader The WP_Upgrader instance.
	 *
	 * @return  mixed
	 */
	public function check_plugin_license_before_update( $reply, $package, $upgrader ) {
		if ( is_object( $upgrader ) && property_exists( $upgrader->skin, 'plugin_info' ) ) {
			if ( false === strpos( $upgrader->skin->plugin_info['Name'] ?? '', 'Kirki Pro' ) ) {
				return $reply;
			}

			if ( ! HelperFunctions::is_pro_user() ) {
				return new \WP_Error(
					'license_required',
					__( 'A valid license key is required to update Kirki Pro. Please enter your license key in the plugin settings.', 'kirki' )
				);
			}

			$common_data = WpAdmin::get_common_data( true );
			$license_key = isset( $common_data['license_key']['key'] ) ? $common_data['license_key']['key'] : '';

			if ( empty( $license_key ) ) {
				return new \WP_Error(
					'license_required',
					__( 'A valid license key is required to update Kirki Pro. Please enter your license key in the plugin settings.', 'kirki' )
				);
			}

			$response = $this->check_for_update_api( );
			if ( ! is_object( $response ) || ! isset( $response->status ) || 200 !== $response->status ) {
				return new \WP_Error(
					'license_required',
					__( 'A valid license key is required to update Kirki Pro. Please enter your license key in the plugin settings.', 'kirki' )
				);
			}
		}
		return $reply;
	}
}