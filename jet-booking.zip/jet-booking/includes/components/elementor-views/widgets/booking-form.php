<?php
namespace JET_ABAF\Components\Elementor_Views\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use JET_ABAF\Components\Elementor_Views\Date_Range_Picker_Controls;
use JET_ABAF\Render\Booking_Form as Booking_Form_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Booking_Form extends Widget_Base {

	public function get_name() {
		return 'jet-booking-booking-form';
	}

	public function get_title() {
		return __( 'Booking Form', 'jet-booking' );
	}

	public function get_icon() {
		return 'jet-booking-icon-booking-form';
	}

	public function get_categories() {
		return [ 'jet-booking' ];
	}

	public function get_style_depends() {
		return [ 'jet-booking-widget-booking-form' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'jet-booking' ),
			]
		);

		$this->add_control(
			'booking_instance_id',
			[
				'type'        => Controls_Manager::TEXT,
				'label'       => __( 'Booking Instance ID', 'jet-booking' ),
				'description' => __( 'Optional. Leave empty to resolve the booking instance from the current page or popup context.', 'jet-booking' ),
				'label_block' => true,
				'dynamic'     => [ 'active' => true ],
			]
		);

		$this->add_control(
			'disable_email_field',
			[
				'type'        => Controls_Manager::SWITCHER,
				'label'       => __( 'Disable Email Field', 'jet-booking' ),
				'description' => __( 'Removes the email input field from the booking form.', 'jet-booking' ),
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'heading_field_config',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Date Picker Field', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'field_layout',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => __( 'Layout', 'jet-booking' ),
				'options' => [
					'single'   => __( 'Single Field', 'jet-booking' ),
					'separate' => __( 'Separate Fields', 'jet-booking' ),
				],
				'default' => 'single',
			]
		);

		$this->add_control(
			'field_position',
			[
				'type'      => Controls_Manager::SELECT,
				'label'     => __( 'Position', 'jet-booking' ),
				'options'   => [
					'inline' => __( 'Inline', 'jet-booking' ),
					'list'   => __( 'List', 'jet-booking' ),
				],
				'default'   => 'inline',
				'condition' => [
					'field_layout' => 'separate',
				],
			]
		);

		$this->add_control(
			'field_label',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Label', 'jet-booking' ),
				'condition' => [
					'field_layout' => 'single',
				],
			]
		);

		$this->add_control(
			'field_placeholder',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Placeholder', 'jet-booking' ),
				'default'   => 'YYYY-MM-DD',
				'condition' => [
					'field_layout' => 'single',
				],
			]
		);

		$this->add_control(
			'check_in_field_label',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Check in Label', 'jet-booking' ),
				'condition' => [
					'field_layout' => 'separate',
				],
			]
		);

		$this->add_control(
			'check_in_field_placeholder',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Check in Placeholder', 'jet-booking' ),
				'default'   => 'YYYY-MM-DD',
				'condition' => [
					'field_layout' => 'separate',
				],
			]
		);

		$this->add_control(
			'check_out_field_label',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Check out Label', 'jet-booking' ),
				'condition' => [
					'field_layout' => 'separate',
				],
			]
		);

		$this->add_control(
			'check_out_field_placeholder',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Check out Placeholder', 'jet-booking' ),
				'default'   => 'YYYY-MM-DD',
				'condition' => [
					'field_layout' => 'separate',
				],
			]
		);

		$this->add_control(
			'field_description',
			[
				'type'  => Controls_Manager::TEXTAREA,
				'label' => __( 'Description', 'jet-booking' ),
			]
		);

		$this->add_control(
			'field_date_format',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => __( 'Date Format', 'jet-booking' ),
				'options' => [
					'YYYY-MM-DD' => __( 'YYYY-MM-DD', 'jet-booking' ),
					'MM-DD-YYYY' => __( 'MM-DD-YYYY', 'jet-booking' ),
					'DD-MM-YYYY' => __( 'DD-MM-YYYY', 'jet-booking' ),
				],
				'default' => 'YYYY-MM-DD',
			]
		);

		$this->add_control(
			'field_separator',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => __( 'Separator', 'jet-booking' ),
				'options' => [
					'-'     => __( '-', 'jet-booking' ),
					'.'     => __( '.', 'jet-booking' ),
					'/'     => __( '/', 'jet-booking' ),
					'space' => __( 'Space', 'jet-booking' ),
				],
				'default' => '-',
			]
		);

		$this->add_control(
			'field_start_of_week',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => __( 'First Day of the Week', 'jet-booking' ),
				'options' => [
					'monday' => __( 'Monday', 'jet-booking' ),
					'sunday' => __( 'Sunday', 'jet-booking' ),
				],
				'default' => 'monday',
			]
		);

		$this->add_control(
			'heading_submit_button',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Submit Button', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'submit_button_label',
			[
				'type'    => Controls_Manager::TEXT,
				'label'   => __( 'Label', 'jet-booking' ),
				'default' => __( 'Book', 'jet-booking' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_form_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Form', 'jet-booking' ),
			]
		);

		$this->add_control(
			'heading_labels_style',
			[
				'type'  => Controls_Manager::HEADING,
				'label' => __( 'Labels', 'jet-booking' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'labels_typography',
				'selector' => $this->get_labels_selector(),
			]
		);

		$this->add_control(
			'labels_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					$this->get_labels_selector() => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_desc_style',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Descriptions', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'descriptions_typography',
				'selector' => '{{WRAPPER}} .jet-booking-form .jet-abaf-field__desc',
			]
		);

		$this->add_control(
			'descriptions_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-booking-form .jet-abaf-field__desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_fields_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Fields', 'jet-booking' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'fields_typography',
				'selector' => $this->get_fields_selector(),
			]
		);

		$this->add_control(
			'fields_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					$this->get_fields_selector() => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fields_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					$this->get_fields_selector() => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fields_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					$this->get_fields_selector() => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'fields_border_width',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Width', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					$this->get_fields_selector() => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'fields_border_radius',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Radius', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					$this->get_fields_selector() => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		Date_Range_Picker_Controls::register( $this );

		$this->start_controls_section(
			'section_submit_button_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Submit Button', 'jet-booking' ),
			]
		);

		$this->add_responsive_control(
			'submit_button_align',
			[
				'label'     => esc_html__( 'Position', 'elementor-pro' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'   => [
						'title' => esc_html__( 'Left', 'elementor-pro' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'elementor-pro' ),
						'icon'  => 'eicon-h-align-center',
					],
					'end'     => [
						'title' => esc_html__( 'Right', 'elementor-pro' ),
						'icon'  => 'eicon-h-align-right',
					],
					'stretch' => [
						'title' => esc_html__( 'Stretch', 'elementor-pro' ),
						'icon'  => 'eicon-h-align-stretch',
					],
				],
				'default'   => 'stretch',
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'align-self: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'submit_button_content_align',
			[
				'label'     => esc_html__( 'Alignment', 'elementor-pro' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'start'         => [
						'title' => esc_html__( 'Start', 'elementor-pro' ),
						'icon'  => "eicon-text-align-left",
					],
					'center'        => [
						'title' => esc_html__( 'Center', 'elementor-pro' ),
						'icon'  => 'eicon-text-align-center',
					],
					'end'           => [
						'title' => esc_html__( 'End', 'elementor-pro' ),
						'icon'  => "eicon-text-align-right",
					],
					'space-between' => [
						'title' => esc_html__( 'Space between', 'elementor-pro' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'   => '',
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'justify-content: {{VALUE}};',
				],
				'condition' => [ 'submit_button_align' => 'stretch' ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'submit_button_typography',
				'selector' => '{{WRAPPER}} .jet-abaf-booking-form__submit',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'submit_button_border',
				'exclude'  => [ 'color' ],
				'selector' => '{{WRAPPER}} .jet-abaf-booking-form__submit',
			]
		);

		$this->start_controls_tabs( 'tabs_submit_button_style' );

		$this->start_controls_tab(
			'tab_submit_button_normal',
			[
				'label' => __( 'Normal', 'jet-booking' ),
			]
		);

		$this->add_control(
			'submit_button_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submit_button_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submit_button_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_submit_button_hover',
			[
				'label' => __( 'Hover', 'jet-booking' ),
			]
		);

		$this->add_control(
			'submit_button_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submit_button_background_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submit_button_border_color_hover',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'submit_button_border_radius',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Radius', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'submit_button_padding',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Padding', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_notice_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Notice Messages', 'jet-booking' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'notices_typography',
				'selector' => '{{WRAPPER}} .jet-abaf-booking-form__notice',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'notices_border',
				'exclude'  => [ 'color' ],
				'selector' => '{{WRAPPER}} .jet-abaf-booking-form__notice',
			]
		);

		$this->start_controls_tabs( 'tabs_notices_style' );

		$this->start_controls_tab(
			'tab_notice_warning',
			[
				'label' => __( 'Warning', 'jet-booking' ),
			]
		);

		$this->add_control(
			'notice_warning_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_warning_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_warning_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_notice_success',
			[
				'label' => __( 'Success', 'jet-booking' ),
			]
		);

		$this->add_control(
			'notice_success_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_success_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_success_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_notice_error',
			[
				'label' => __( 'Error', 'jet-booking' ),
			]
		);

		$this->add_control(
			'notice_error_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_error_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'notice_error_border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Border Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'notices_border_radius',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Radius', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'notices_padding',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Padding', 'jet-booking' ),
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-booking-form__notice' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Retrieves a string selector for label elements used within the booking form.
	 *
	 * @since 4.1.0
	 *
	 * @return string A comma-separated string of CSS selectors.
	 */
	private function get_labels_selector() {
		return implode( ', ', [
			'{{WRAPPER}} .jet-booking-form .jet-abaf-field__label label',
			'{{WRAPPER}} .jet-booking-form .jet-abaf-separate-field__label',
			'{{WRAPPER}} .jet-booking-form .form-field > label',
			'{{WRAPPER}} .jet-booking-form .jet-abaf-timepicker label',
		] );
	}

	/**
	 * Retrieves a string selector for input and select fields used within the booking form.
	 *
	 * @since 4.1.0
	 *
	 * @return string A comma-separated string of CSS selectors.
	 */
	private function get_fields_selector() {
		return implode( ', ', [
			'{{WRAPPER}} .jet-booking-form input',
			'{{WRAPPER}} .jet-booking-form select',
		] );
	}

	protected function render() {

		$settings               = $this->get_settings_for_display();
		$settings['is_preview'] = \Elementor\Plugin::$instance->editor->is_edit_mode();

		$renderer = new Booking_Form_Renderer( $settings );
		$renderer->render();

	}

}
