<?php
namespace JET_ABAF\Components\Elementor_Views\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use JET_ABAF\Render\Price_Breakdown as Price_Breakdown_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Price_Breakdown extends Widget_Base {

	public function get_name() {
		return 'jet-booking-price-breakdown';
	}

	public function get_title() {
		return __( 'Price Breakdown', 'jet-booking' );
	}

	public function get_icon() {
		return 'jet-booking-icon-price-breakdown';
	}

	public function get_categories() {
		return [ 'jet-booking' ];
	}

	public function get_style_depends(): array {
		return [ 'jet-booking-widget-price-breakdown' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'jet-booking' ),
			]
		);

		$this->add_control(
			'price_breakdown_note',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Subtotal is calculated from price settings only and may not include extra charges or other adjustments applied elsewhere.', 'jet-booking' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Content', 'jet-booking' ),
			]
		);

		$this->add_control(
			'content_gap',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Items Gap', 'jet-booking' ),
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px'  => [
						'max' => 50,
					],
					'em'  => [
						'max' => 5,
					],
					'rem' => [
						'max' => 5,
					],
				],
				'separator'  => 'after',
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-price-breakdown__content' => 'gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'margin: 0;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .jet-abaf-price-breakdown__row, {{WRAPPER}} .jet-abaf-price-breakdown__placeholder',
			]
		);

		$this->add_control(
			'content_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-price-breakdown__row'         => 'color: {{VALUE}};',
					'{{WRAPPER}} .jet-abaf-price-breakdown__placeholder' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_total_style',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Subtotal', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'total_typography',
				'selector' => '{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__label, {{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__value',
			]
		);

		$this->add_control(
			'total_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__label' => 'color: {{VALUE}};',
					'{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__value' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_divider_style',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Divider', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'divider_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_spacing',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Spacing', 'jet-booking' ),
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px'  => [
						'max' => 100,
					],
					'em'  => [
						'max' => 10,
					],
					'rem' => [
						'max' => 10,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings               = $this->get_settings_for_display();
		$settings['is_preview'] = \Elementor\Plugin::$instance->editor->is_edit_mode();

		$renderer = new Price_Breakdown_Renderer( $settings );
		$renderer->render();

	}

}
