<?php
namespace JET_ABAF\Components\Elementor_Views;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Date_Range_Picker_Controls {

	/**
	 * Register date range picker style controls.
	 *
	 * @since 4.1.0
	 *
	 * @param \Elementor\Controls_Stack $element The element instance.
	 *
	 * @return void
	 */
	public static function register( $element ) {

		$element->start_controls_section(
			'date_range_picker_section',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Date Range Picker', 'jet-booking' ),
			]
		);

		$element->add_control(
			'date_range_picker_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper' => 'color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper' => 'background-color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_days_heading',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => __( 'Days', 'jet-booking' ),
				'separator' => 'before',
			]
		);

		$element->add_control(
			'date_range_picker_days_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody .day.valid' => 'color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_days_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody .day.toMonth' => 'background-color: {{VALUE}}',
				],
			]
		);

		$element->start_controls_tabs( 'tabs_date_range_picker_days_styles' );

		$element->start_controls_tab(
			'date_range_picker_inactive_days',
			[
				'label' => __( 'Inactive', 'jet-booking' ),
			]
		);

		$element->add_control(
			'date_range_picker_inactive_days_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.invalid' => 'color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_inactive_days_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.invalid' => 'background-color: {{VALUE}}',
				],
			]
		);

		$element->end_controls_tab();

		$element->start_controls_tab(
			'date_range_picker_current_day',
			[
				'label' => __( 'Current', 'jet-booking' ),
			]
		);

		$element->add_control(
			'date_range_picker_current_day_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody .day.real-today:not(.invalid)' => 'color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_current_day_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody .day.real-today:not(.invalid)' => 'background-color: {{VALUE}}',
				],
			]
		);

		$element->end_controls_tab();

		$element->start_controls_tab(
			'date_range_picker_edges',
			[
				'label' => __( 'Edges', 'jet-booking' ),
			]
		);

		$element->add_control(
			'date_range_picker_edges_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.first-date-selected' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.last-date-selected'  => 'color: {{VALUE}} !important;',
				],
			]
		);

		$element->add_control(
			'date_range_picker_edges_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.first-date-selected' => 'background-color: {{VALUE}} !important;',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.last-date-selected'  => 'background-color: {{VALUE}} !important;',
				],
			]
		);

		$element->end_controls_tab();

		$element->start_controls_tab(
			'date_range_picker_trace',
			[
				'label' => __( 'Trace', 'jet-booking' ),
			]
		);

		$element->add_control(
			'date_range_picker_trace_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.checked'           => 'color: {{VALUE}}',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.hovering'          => 'color: {{VALUE}}',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.has-tooltip:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$element->add_control(
			'date_range_picker_trace_bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-booking' ),
				'selectors' => [
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.checked'           => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.hovering'          => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .date-picker-wrapper tbody div.day.has-tooltip:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$element->end_controls_tab();

		$element->end_controls_tabs();

		$element->end_controls_section();

	}

}
