<?php
namespace JET_ABAF\Components\Elementor_Views;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Manager {

	public function __construct() {

		if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			return;
		}

		// Register widgets category.
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_category' ] );

		// Register widgets.
		if ( version_compare( ELEMENTOR_VERSION, '3.5.0', '>=' ) ) {
			add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		} else {
			add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		}

		// Enqueue preview scripts.
		add_action( 'elementor/preview/enqueue_scripts', [ $this, 'preview_scripts' ] );

		// Enqueue widgets icons styles.
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_icons_styles' ] );
		add_action( 'elementor/preview/enqueue_styles', [ $this, 'enqueue_icons_styles' ] );

		$init_action = 'elementor/init';

		// Init a module early on Elementor Data Updater
		if ( is_admin() && ( isset( $_GET['elementor_updater'] ) || isset( $_GET['elementor_pro_updater'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$init_action = 'elementor/documents/register';
		}
		// Initialize custom dynamic tags functionality.
		add_action( $init_action, [ $this, 'init_module' ] );

		if ( 'plain' === jet_abaf()->settings->get( 'booking_mode' ) ) {
			// Inject date range picker style controls for JetFormBuilder plugin forms widget.
			add_action( 'elementor/element/jet-form-builder-form/section_repeater_style/after_section_end', [ $this, 'inject_date_range_picker_style_controls' ], 10, 2 );
		}

	}

	/**
	 * Register category.
	 *
	 * Register plugin category for elementor if not exists.
	 *
	 * @since 3.2.0
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor element manager instance.
	 */
	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'jet-booking',
			[
				'title' => __( 'JetBooking', 'jet-booking' ),
				'icon'  => 'font',
			]
		);
	}

	/**
	 * Register widgets.
	 *
	 * Register new Elementor widgets.
	 *
	 * @since  2.1.0
	 * @since  4.0.0 Registered new `Settings_Configuration` and `Settings_Schedule` widgets.
	 * @since  4.1.0 Registered new `Price_Breakdown`, `Booking_Form` widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public function register_widgets( $widgets_manager ) {
		if ( method_exists( $widgets_manager, 'register' ) ) {
			$widgets_manager->register( new Widgets\Booking_Form() );
			$widgets_manager->register( new Widgets\Calendar() );
			$widgets_manager->register( new Widgets\Price_Breakdown() );
			$widgets_manager->register( new Widgets\Settings_Configuration() );
			$widgets_manager->register( new Widgets\Settings_Schedule() );
		} else {
			$widgets_manager->register_widget_type( new Widgets\Booking_Form() );
			$widgets_manager->register_widget_type( new Widgets\Calendar() );
			$widgets_manager->register_widget_type( new Widgets\Price_Breakdown() );
			$widgets_manager->register_widget_type( new Widgets\Settings_Configuration() );
			$widgets_manager->register_widget_type( new Widgets\Settings_Schedule() );
		}
	}

	/**
	 * Preview scripts.
	 *
	 * Enqueue preview scripts.
	 *
	 * @since  2.1.0
	 */
	public function preview_scripts() {
		jet_abaf()->assets->enqueue_deps( get_the_ID() );
	}

	/**
	 * Enqueue icons styles.
	 *
	 * Enqueue Elementor editor widgets icon styles.
	 *
	 * @since 2.1.0
	 */
	public function enqueue_icons_styles() {
		wp_enqueue_style(
			'jet-booking-icons',
			JET_ABAF_URL . 'assets/lib/jet-booking-icons/icons.css',
			[],
			JET_ABAF_VERSION
		);
	}

	/**
	 * Init module.
	 *
	 * Initialize custom dynamic tags module functionality.
	 *
	 * @since 3.2.0
	 */
	public function init_module() {
		new Dynamic_Tags\Module();
	}

	/**
	 * Inject date range picker style controls.
	 *
	 * Inject date range picker style controls for JetFormBuilder plugin forms widget.
	 *
	 * @since 3.2.0
	 * @since 4.1.0 Refactored.
	 *
	 * @param \Elementor\Controls_Stack $element The element type.
	 * @param array                     $args    Section arguments.
	 */
	public function inject_date_range_picker_style_controls( $element, $args ) {
		Date_Range_Picker_Controls::register( $element );
	}

}
