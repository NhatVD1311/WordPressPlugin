<?php
namespace JET_ABAF\Components\Blocks_Views\Block_Types;

use JET_ABAF\Render\Price_Breakdown as Price_Breakdown_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Price_Breakdown extends Base {

	/**
	 * Get name.
	 *
	 * Retrieves the name of the block.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_name() {
		return 'price-breakdown';
	}

	/**
	 * Get arguments.
	 *
	 * Retrieves the arguments of the block.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return array[]
	 */
	public function get_args() {
		return [ 'render_callback' => [ $this, 'render_callback' ] ];
	}

	/**
	 * Add style manager options.
	 *
	 * Handles the addition of options specific to the style manager.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return void
	 */
	public function add_style_manager_options() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_content_style',
				'title' => __( 'Content', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'content_gap',
			'type'         => 'range',
			'label'        => __( 'Items Gap', 'jet-booking' ),
			'separator'    => 'after',
			'units'        => [
				[
					'value'     => 'px',
					'intervals' => [
						'step' => 1,
						'min'  => 0,
						'max'  => 50,
					],
				],
				[
					'value'     => 'em',
					'intervals' => [
						'step' => 0.1,
						'min'  => 0,
						'max'  => 5,
					],
				],
				[
					'value'     => 'rem',
					'intervals' => [
						'step' => 0.1,
						'min'  => 0,
						'max'  => 5,
					],
				],
			],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__content' => 'gap: {{VALUE}}{{UNIT}};',
				'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'margin: 0;',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'content_typography',
			'type'         => 'typography',
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__row, {{WRAPPER}} .jet-abaf-price-breakdown__placeholder' => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'content_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__row'         => 'color: {{VALUE}};',
				'{{WRAPPER}} .jet-abaf-price-breakdown__placeholder' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'        => 'heading_total_style',
			'type'      => 'text',
			'content'   => __( 'Subtotal', 'jet-booking' ),
			'separator' => 'before',
		] );

		$this->controls_manager->add_control( [
			'id'           => 'total_typography',
			'type'         => 'typography',
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__label, {{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__value' => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'total_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__label' => 'color: {{VALUE}};',
				'{{WRAPPER}} .jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__value' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'        => 'heading_divider_style',
			'type'      => 'text',
			'content'   => __( 'Divider', 'jet-booking' ),
			'separator' => 'before',
		] );

		$this->controls_manager->add_control( [
			'id'           => 'divider_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'divider_spacing',
			'type'         => 'range',
			'label'        => __( 'Spacing', 'jet-booking' ),
			'units'        => [
				[
					'value'     => 'px',
					'intervals' => [
						'step' => 1,
						'min'  => 0,
						'max'  => 100,
					],
				],
				[
					'value'     => 'em',
					'intervals' => [
						'step' => 0.1,
						'min'  => 0,
						'max'  => 10,
					],
				],
				[
					'value'     => 'rem',
					'intervals' => [
						'step' => 0.1,
						'min'  => 0,
						'max'  => 10,
					],
				],
			],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-price-breakdown__divider' => 'margin-left: {{VALUE}}{{UNIT}}; margin-right: {{VALUE}}{{UNIT}};',
			],
		] );

		$this->controls_manager->end_section();

	}

	/**
	 * Render block callback.
	 *
	 * @param array $attributes Block attributes.
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function render_callback( $attributes = [] ) {

		ob_start();

		echo '<div class="wp-block-jet-booking-price-breakdown" data-is-block="jet-booking/price-breakdown">';

		$renderer = new Price_Breakdown_Renderer();
		$renderer->render();

		echo '</div>';

		$output = ob_get_contents();
		ob_end_clean();

		return $output;

	}

}
