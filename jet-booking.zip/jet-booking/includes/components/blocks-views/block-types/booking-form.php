<?php
namespace JET_ABAF\Components\Blocks_Views\Block_Types;

use JET_ABAF\Render\Booking_Form as Booking_Form_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Booking_Form extends Base {

	/**
	 * Get name.
	 *
	 * Retrieves the name of the block.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_name() {
		return 'booking-form';
	}

	/**
	 * Get arguments.
	 *
	 * Retrieves the arguments of the block.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return array[]
	 */
	public function get_args() {
		return [ 'render_callback' => [ $this, 'render_callback' ] ];
	}

	/**
	 * Add style manager options.
	 *
	 * @since  4.1.0
	 * @access public
	 *
	 * @return void
	 */
	public function add_style_manager_options() {
		$this->register_form_style_section();
		$this->register_fields_style_section();
		$this->register_date_range_picker_style_section();
		$this->register_submit_button_style_section();
		$this->register_notice_style_section();
	}

	/**
	 * Register form style section controls.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function register_form_style_section() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_form_style',
				'title' => __( 'Form', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'      => 'heading_labels_style',
			'type'    => 'text',
			'content' => __( 'Labels', 'jet-booking' ),
		] );

		$this->controls_manager->add_control( [
			'id'           => 'labels_typography',
			'type'         => 'typography',
			'css_selector' => [
				$this->get_labels_selector() => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'labels_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				$this->get_labels_selector() => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'        => 'heading_desc_style',
			'type'      => 'text',
			'content'   => __( 'Descriptions', 'jet-booking' ),
			'separator' => 'before',
		] );

		$this->controls_manager->add_control( [
			'id'           => 'descriptions_typography',
			'type'         => 'typography',
			'css_selector' => [
				'{{WRAPPER}} .jet-booking-form .jet-abaf-field__desc' => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'descriptions_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-booking-form .jet-abaf-field__desc' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_section();

	}

	/**
	 * Register fields style section controls.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function register_fields_style_section() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_fields_style',
				'title' => __( 'Fields', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'fields_typography',
			'type'         => 'typography',
			'css_selector' => [
				$this->get_fields_selector() => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'fields_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				$this->get_fields_selector() => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'fields_background_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				$this->get_fields_selector() => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'            => 'fields_border',
			'type'          => 'border',
			'label'         => __( 'Border', 'jet-booking' ),
			'disable_style' => true,
			'css_selector'  => [
				$this->get_fields_selector() => 'border-width: {{WIDTH}}; border-radius: {{RADIUS}}; border-color: {{COLOR}};',
			],
		] );

		$this->controls_manager->end_section();

	}

	/**
	 * Register date range picker style section controls.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function register_date_range_picker_style_section() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_date_range_picker_style',
				'title' => __( 'Date Range Picker', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'        => 'date_range_picker_days_heading',
			'type'      => 'text',
			'content'   => __( 'Days', 'jet-booking' ),
			'separator' => 'before',
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_days_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody .day.valid' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_days_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody .day.toMonth' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->start_tabs(
			'style_controls',
			[
				'id'        => 'tabs_date_range_picker_style',
				'separator' => 'both',
			]
		);

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'date_range_picker_inactive_days',
				'title' => __( 'Inactive', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_inactive_days_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.invalid' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_inactive_days_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.invalid' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'date_range_picker_current_day',
				'title' => __( 'Current', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_current_day_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody .day.real-today:not(.invalid)' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_current_day_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody .day.real-today:not(.invalid)' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'date_range_picker_edges',
				'title' => __( 'Edges', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_edges_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.first-date-selected' => 'color: {{VALUE}} !important;',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.last-date-selected'  => 'color: {{VALUE}} !important;',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_edges_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.first-date-selected' => 'background-color: {{VALUE}} !important;',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.last-date-selected'  => 'background-color: {{VALUE}} !important;',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'date_range_picker_trace',
				'title' => __( 'Trace', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_trace_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.checked'           => 'color: {{VALUE}};',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.hovering'          => 'color: {{VALUE}};',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.has-tooltip:hover' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'date_range_picker_trace_bg_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.checked'           => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.hovering'          => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .date-picker-wrapper tbody div.day.has-tooltip:hover' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->end_tabs();
		$this->controls_manager->end_section();

	}

	/**
	 * Register the submit button style section controls.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function register_submit_button_style_section() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_submit_button_style',
				'title' => __( 'Submit Button', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_position',
			'type'         => 'choose',
			'label'        => __( 'Position', 'jet-booking' ),
			'options'      => [
				'flex-start' => [
					'shortcut' => __( 'Left', 'jet-booking' ),
					'icon'     => 'dashicons-editor-alignleft',
				],
				'center'     => [
					'shortcut' => __( 'Center', 'jet-booking' ),
					'icon'     => 'dashicons-editor-aligncenter',
				],
				'flex-end'   => [
					'shortcut' => __( 'Right', 'jet-booking' ),
					'icon'     => 'dashicons-editor-alignright',
				],
				'stretch'    => [
					'shortcut' => __( 'Stretch', 'jet-booking' ),
					'icon'     => 'dashicons-editor-justify',
				],
			],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'align-self: {{VALUE}};',
			],
			'attributes'   => [
				'default' => [
					'value' => 'stretch',
				],
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_content_align',
			'type'         => 'choose',
			'label'        => __( 'Alignment', 'jet-booking' ),
			'separator'    => 'after',
			'condition'    => [
				'submit_button_position' => 'stretch',
			],
			'options'      => [
				'flex-start'    => [
					'shortcut' => __( 'Start', 'jet-booking' ),
					'icon'     => 'dashicons-editor-alignleft',
				],
				'center'        => [
					'shortcut' => __( 'Center', 'jet-booking' ),
					'icon'     => 'dashicons-editor-aligncenter',
				],
				'flex-end'      => [
					'shortcut' => __( 'End', 'jet-booking' ),
					'icon'     => 'dashicons-editor-alignright',
				],
				'space-between' => [
					'shortcut' => __( 'Space Between', 'jet-booking' ),
					'icon'     => 'dashicons-editor-justify',
				],
			],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'justify-content: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_typography',
			'type'         => 'typography',
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'            => 'submit_button_border',
			'type'          => 'border',
			'label'         => __( 'Border', 'jet-booking' ),
			'disable_color' => true,
			'css_selector'  => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'border-style: {{STYLE}}; border-width: {{WIDTH}}; border-radius: {{RADIUS}};',
			],
		] );

		$this->controls_manager->start_tabs(
			'style_controls',
			[
				'id'        => 'tabs_submit_button_style',
				'separator' => 'both',
			]
		);

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'tab_submit_button_normal',
				'title' => __( 'Normal', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_background_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_border_color',
			'type'         => 'color-picker',
			'label'        => __( 'Border Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'border-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'tab_submit_button_hover',
				'title' => __( 'Hover', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_color_hover',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_background_color_hover',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'submit_button_border_color_hover',
			'type'         => 'color-picker',
			'label'        => __( 'Border Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit:hover' => 'border-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->end_tabs();

		$this->controls_manager->add_responsive_control( [
			'id'           => 'submit_button_padding',
			'type'         => 'dimensions',
			'label'        => __( 'Padding', 'jet-booking' ),
			'units'        => [ 'px', '%', 'em', 'rem' ],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__submit' => 'padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}};',
			],
		] );

		$this->controls_manager->end_section();

	}

	/**
	 * Register notice style section controls.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function register_notice_style_section() {

		$this->controls_manager->start_section(
			'style_controls',
			[
				'id'    => 'section_notice_style',
				'title' => __( 'Notice Messages', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'notices_typography',
			'type'         => 'typography',
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice' => 'font-family: {{FAMILY}}; font-weight: {{WEIGHT}}; text-transform: {{TRANSFORM}}; font-style: {{STYLE}}; text-decoration: {{DECORATION}}; line-height: {{LINEHEIGHT}}{{LH_UNIT}}; letter-spacing: {{LETTERSPACING}}{{LS_UNIT}}; font-size: {{SIZE}}{{S_UNIT}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'            => 'notices_border',
			'type'          => 'border',
			'label'         => __( 'Border', 'jet-booking' ),
			'disable_color' => true,
			'css_selector'  => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice' => 'border-style: {{STYLE}}; border-width: {{WIDTH}}; border-radius: {{RADIUS}};',
			],
		] );

		$this->controls_manager->start_tabs(
			'style_controls',
			[
				'id'        => 'tabs_notice_style',
				'separator' => 'both',
			]
		);

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'tab_notice_warning',
				'title' => __( 'Warning', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'notice_warning_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_warning_background_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_warning_border_color',
			'type'         => 'color-picker',
			'label'        => __( 'Border Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning' => 'border-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'tab_notice_success',
				'title' => __( 'Success', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'notice_success_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_success_background_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_success_border_color',
			'type'         => 'color-picker',
			'label'        => __( 'Border Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success' => 'border-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->start_tab(
			'style_controls',
			[
				'id'    => 'tab_notice_error',
				'title' => __( 'Error', 'jet-booking' ),
			]
		);

		$this->controls_manager->add_control( [
			'id'           => 'notice_error_color',
			'type'         => 'color-picker',
			'label'        => __( 'Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_error_background_color',
			'type'         => 'color-picker',
			'label'        => __( 'Background Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'background-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->add_control( [
			'id'           => 'notice_error_border_color',
			'type'         => 'color-picker',
			'label'        => __( 'Border Color', 'jet-booking' ),
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error' => 'border-color: {{VALUE}};',
			],
		] );

		$this->controls_manager->end_tab();

		$this->controls_manager->end_tabs();

		$this->controls_manager->add_responsive_control( [
			'id'           => 'notices_padding',
			'type'         => 'dimensions',
			'label'        => __( 'Padding', 'jet-booking' ),
			'units'        => [ 'px', '%', 'em', 'rem' ],
			'css_selector' => [
				'{{WRAPPER}} .jet-abaf-booking-form__notice' => 'padding: {{TOP}} {{RIGHT}} {{BOTTOM}} {{LEFT}};',
			],
		] );

		$this->controls_manager->end_section();

	}

	public function render_callback( $attributes = [] ) {

		ob_start();

		echo '<div class="wp-block-jet-booking-booking-form" data-is-block="jet-booking/booking-form">';

		$renderer = new Booking_Form_Renderer( $attributes );
		$renderer->render();

		echo '</div>';

		$output = ob_get_contents();
		ob_end_clean();

		return $output;

	}

	/**
	 * Get the combined selector for label elements.
	 *
	 * @since 4.1.0
	 *
	 * @return string
	 */
	private function get_labels_selector() {
		return implode( ', ', [
			'{{WRAPPER}} .jet-booking-form .jet-abaf-field__label label',
			'{{WRAPPER}} .jet-booking-form .jet-abaf-separate-field__label',
			'{{WRAPPER}} .jet-booking-form .form-field > label',
			'{{WRAPPER}} .jet-booking-form .jet-abaf-timepicker label',
		] );
	}

	/**
	 * Get the combined selector for form fields.
	 *
	 * @since 4.1.0
	 *
	 * @return string
	 */
	private function get_fields_selector() {
		return implode( ', ', [
			'{{WRAPPER}} .jet-booking-form input',
			'{{WRAPPER}} .jet-booking-form select',
		] );
	}

}
