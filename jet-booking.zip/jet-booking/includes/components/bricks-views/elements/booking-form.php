<?php
namespace JET_ABAF\Components\Bricks_Views\Elements;

use Bricks\Element;
use JET_ABAF\Components\Bricks_Views\Date_Range_Picker_Controls;
use JET_ABAF\Render\Booking_Form as Booking_Form_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Booking_Form extends Element {

	// Element properties
	public $category = 'jetbooking';
	public $name = 'jet-booking-booking-form';
	public $icon = 'jet-booking-icon-booking-form';
	public $css_selector = '';
	public $scripts = [ 'jetBookingBricks' ];
	public $nestable = false;

	public function get_label() {
		return __( 'Booking Form', 'jet-booking' );
	}

	public function set_control_groups() {

		$this->control_groups['section_booking_form_content'] = [
			'title' => __( 'Content', 'jet-booking' ),
			'tab'   => 'content',
		];

		$this->control_groups['section_booking_form_field_config'] = [
			'title' => __( 'Date Picker Field', 'jet-booking' ),
			'tab'   => 'content',
		];

		$this->control_groups['section_booking_form_submit_button'] = [
			'title' => __( 'Submit Button', 'jet-booking' ),
			'tab'   => 'content',
		];

		$this->control_groups['section_booking_form_styles'] = [
			'title' => __( 'Form', 'jet-booking' ),
			'tab'   => 'style',
		];

		$this->control_groups['section_booking_form_fields_styles'] = [
			'title' => __( 'Fields', 'jet-booking' ),
			'tab'   => 'style',
		];

		$this->load_date_range_picker_controls();

		$this->control_groups = Date_Range_Picker_Controls::register_control_groups( $this->control_groups );

		$this->control_groups['section_booking_form_submit_button_styles'] = [
			'title' => __( 'Submit Button', 'jet-booking' ),
			'tab'   => 'style',
		];

		$this->control_groups['section_booking_form_notice_styles'] = [
			'title' => __( 'Notice Messages', 'jet-booking' ),
			'tab'   => 'style',
		];

	}

	public function set_controls() {

		$this->load_date_range_picker_controls();

		$this->controls['booking_instance_id'] = [
			'tab'            => 'content',
			'group'          => 'section_booking_form_content',
			'type'           => 'text',
			'label'          => __( 'Booking Instance ID', 'jet-booking' ),
			'description'    => __( 'Optional. Leave empty to resolve the booking instance from the current page or popup context.', 'jet-booking' ),
			'hasDynamicData' => true,
		];

		$this->controls['disable_email_field'] = [
			'tab'         => 'content',
			'group'       => 'section_booking_form_content',
			'label'       => __( 'Disable Email Field', 'jet-booking' ),
			'type'        => 'checkbox',
			'description' => __( 'Removes the email input field from the booking form.', 'jet-booking' ),
		];

		$this->controls['field_layout'] = [
			'tab'     => 'content',
			'group'   => 'section_booking_form_field_config',
			'label'   => __( 'Layout', 'jet-booking' ),
			'type'    => 'select',
			'options' => [
				'single'   => __( 'Single Field', 'jet-booking' ),
				'separate' => __( 'Separate Fields', 'jet-booking' ),
			],
			'default' => 'single',
		];

		$this->controls['field_position'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Position', 'jet-booking' ),
			'type'     => 'select',
			'options'  => [
				'inline' => __( 'Inline', 'jet-booking' ),
				'list'   => __( 'List', 'jet-booking' ),
			],
			'default'  => 'inline',
			'required' => [
				[ 'field_layout', '=', 'separate' ],
			],
		];

		$this->controls['field_label'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Label', 'jet-booking' ),
			'type'     => 'text',
			'required' => [
				[ 'field_layout', '=', 'single' ],
			],
		];

		$this->controls['field_placeholder'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Placeholder', 'jet-booking' ),
			'type'     => 'text',
			'default'  => 'YYYY-MM-DD',
			'required' => [
				[ 'field_layout', '=', 'single' ],
			],
		];

		$this->controls['check_in_field_label'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Check in Label', 'jet-booking' ),
			'type'     => 'text',
			'required' => [
				[ 'field_layout', '=', 'separate' ],
			],
		];

		$this->controls['check_in_field_placeholder'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Check in Placeholder', 'jet-booking' ),
			'type'     => 'text',
			'default'  => 'YYYY-MM-DD',
			'required' => [
				[ 'field_layout', '=', 'separate' ],
			],
		];

		$this->controls['check_out_field_label'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Check out Label', 'jet-booking' ),
			'type'     => 'text',
			'required' => [
				[ 'field_layout', '=', 'separate' ],
			],
		];

		$this->controls['check_out_field_placeholder'] = [
			'tab'      => 'content',
			'group'    => 'section_booking_form_field_config',
			'label'    => __( 'Check out Placeholder', 'jet-booking' ),
			'type'     => 'text',
			'default'  => 'YYYY-MM-DD',
			'required' => [
				[ 'field_layout', '=', 'separate' ],
			],
		];

		$this->controls['field_description'] = [
			'tab'   => 'content',
			'group' => 'section_booking_form_field_config',
			'label' => __( 'Description', 'jet-booking' ),
			'type'  => 'textarea',
		];

		$this->controls['field_date_format'] = [
			'tab'     => 'content',
			'group'   => 'section_booking_form_field_config',
			'label'   => __( 'Date Format', 'jet-booking' ),
			'type'    => 'select',
			'options' => [
				'YYYY-MM-DD' => __( 'YYYY-MM-DD', 'jet-booking' ),
				'MM-DD-YYYY' => __( 'MM-DD-YYYY', 'jet-booking' ),
				'DD-MM-YYYY' => __( 'DD-MM-YYYY', 'jet-booking' ),
			],
			'default' => 'YYYY-MM-DD',
		];

		$this->controls['field_separator'] = [
			'tab'     => 'content',
			'group'   => 'section_booking_form_field_config',
			'label'   => __( 'Separator', 'jet-booking' ),
			'type'    => 'select',
			'options' => [
				'-'     => __( '-', 'jet-booking' ),
				'.'     => __( '.', 'jet-booking' ),
				'/'     => __( '/', 'jet-booking' ),
				'space' => __( 'Space', 'jet-booking' ),
			],
			'default' => '-',
		];

		$this->controls['field_start_of_week'] = [
			'tab'     => 'content',
			'group'   => 'section_booking_form_field_config',
			'label'   => __( 'First Day of the Week', 'jet-booking' ),
			'type'    => 'select',
			'options' => [
				'monday' => __( 'Monday', 'jet-booking' ),
				'sunday' => __( 'Sunday', 'jet-booking' ),
			],
			'default' => 'monday',
		];

		$this->controls['submit_button_label'] = [
			'tab'     => 'content',
			'group'   => 'section_booking_form_submit_button',
			'label'   => __( 'Label', 'jet-booking' ),
			'type'    => 'text',
			'default' => __( 'Book', 'jet-booking' ),
		];

		$this->controls['labels_heading'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_styles',
			'label' => __( 'Labels', 'jet-booking' ),
			'type'  => 'separator',
		];

		$this->controls['labels_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_styles',
			'label'   => __( 'Typography', 'jet-booking' ),
			'type'    => 'typography',
			'css'     => $this->get_css_rules( $this->get_labels_selectors(), 'typography' ),
			'exclude' => [ 'text-align' ],
		];

		$this->controls['descriptions_heading'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_styles',
			'label' => __( 'Descriptions', 'jet-booking' ),
			'type'  => 'separator',
		];

		$this->controls['descriptions_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_styles',
			'label'   => __( 'Typography', 'jet-booking' ),
			'type'    => 'typography',
			'css'     => [
				[
					'property' => 'typography',
					'selector' => '.jet-booking-form .jet-abaf-field__desc',
				],
			],
			'exclude' => [ 'text-align' ],
		];

		$this->controls['fields_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_fields_styles',
			'label'   => __( 'Typography', 'jet-booking' ),
			'type'    => 'typography',
			'css'     => $this->get_css_rules( $this->get_fields_selectors(), 'typography' ),
			'exclude' => [ 'text-align' ],
		];

		$this->controls['fields_background_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_fields_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => $this->get_css_rules( $this->get_fields_selectors(), 'background-color' ),
		];

		$this->controls['fields_border'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_fields_styles',
			'label'   => __( 'Border', 'bricks' ),
			'type'    => 'border',
			'css'     => $this->get_css_rules( $this->get_fields_selectors(), 'border' ),
			'exclude' => [ 'style' ],
		];

		$this->controls = Date_Range_Picker_Controls::register_controls( $this->controls );

		$this->controls['submit_button_position'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_submit_button_styles',
			'label'   => __( 'Position', 'jet-booking' ),
			'type'    => 'align-items',
			'default' => 'stretch',
			'css'     => [
				[
					'property' => 'align-self',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
		];

		$this->controls['submit_button_content_align'] = [
			'tab'      => 'style',
			'group'    => 'section_booking_form_submit_button_styles',
			'label'    => __( 'Alignment', 'jet-booking' ),
			'type'     => 'justify-content',
			'default'  => 'center',
			'css'      => [
				[
					'property' => 'justify-content',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
			'required' => [
				[ 'submit_button_position', '=', 'stretch' ],
			],
		];

		$this->controls['submit_button_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_submit_button_styles',
			'label'   => __( 'Typography', 'jet-booking' ),
			'type'    => 'typography',
			'css'     => [
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
			'exclude' => [ 'text-align' ],
		];

		$this->controls['submit_button_background_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_submit_button_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
		];

		$this->controls['submit_button_border'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_submit_button_styles',
			'label' => __( 'Border', 'bricks' ),
			'type'  => 'border',
			'css'   => [
				[
					'property' => 'border',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
		];

		$this->controls['submit_button_padding'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_submit_button_styles',
			'label' => __( 'Padding', 'bricks' ),
			'type'  => 'dimensions',
			'units' => true,
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.jet-abaf-booking-form__submit',
				],
			],
		];

		$this->controls['notices_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_notice_styles',
			'label'   => __( 'Typography', 'jet-booking' ),
			'type'    => 'typography',
			'css'     => [
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-booking-form__notice',
				],
			],
			'exclude' => [ 'color', 'text-align' ],
		];

		$this->controls['notices_border'] = [
			'tab'     => 'style',
			'group'   => 'section_booking_form_notice_styles',
			'label'   => __( 'Border', 'bricks' ),
			'type'    => 'border',
			'css'     => [
				[
					'property' => 'border',
					'selector' => '.jet-abaf-booking-form__notice',
				],
			],
			'exclude' => [ 'color' ],
		];

		$this->controls['notice_warning_heading'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Warning', 'jet-booking' ),
			'type'  => 'separator',
		];

		$this->controls['notice_warning_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning',
				],
			],
		];

		$this->controls['notice_warning_background_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning',
				],
			],
		];

		$this->controls['notice_warning_border_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Border color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'border-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--warning',
				],
			],
		];

		$this->controls['notice_success_heading'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Success', 'jet-booking' ),
			'type'  => 'separator',
		];

		$this->controls['notice_success_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success',
				],
			],
		];

		$this->controls['notice_success_background_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success',
				],
			],
		];

		$this->controls['notice_success_border_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Border color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'border-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--success',
				],
			],
		];

		$this->controls['notice_error_heading'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Error', 'jet-booking' ),
			'type'  => 'separator',
		];

		$this->controls['notice_error_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error',
				],
			],
		];

		$this->controls['notice_error_background_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error',
				],
			],
		];

		$this->controls['notice_error_border_color'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Border color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'border-color',
					'selector' => '.jet-abaf-booking-form__notice.jet-abaf-booking-form__notice--error',
				],
			],
		];

		$this->controls['notices_padding'] = [
			'tab'   => 'style',
			'group' => 'section_booking_form_notice_styles',
			'label' => __( 'Padding', 'bricks' ),
			'type'  => 'dimensions',
			'units' => true,
			'css'   => [
				[
					'property' => 'padding',
					'selector' => '.jet-abaf-booking-form__notice',
				],
			],
		];

	}

	public function render() {

		$settings               = $this->settings;
		$settings['is_preview'] = bricks_is_builder() || bricks_is_builder_call();

		$this->set_attribute( '_root', 'data-is-block', 'jet-booking/booking-form' );

		echo "<div {$this->render_attributes( '_root' )}>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$renderer = new Booking_Form_Renderer( $settings );
		$renderer->render();

		echo '</div>';

	}

	/**
	 * Build CSS rules for a control from the selectors list.
	 *
	 * @since 4.1.0
	 *
	 * @param array  $selectors CSS selectors.
	 * @param string $property  CSS property.
	 *
	 * @return array
	 */
	private function get_css_rules( $selectors, $property ) {

		$rules = [];

		foreach ( $selectors as $selector ) {
			$rules[] = [
				'property' => $property,
				'selector' => $selector,
			];
		}

		return $rules;

	}

	/**
	 * Booking form label selectors.
	 *
	 * @since 4.1.0
	 *
	 * @return array
	 */
	private function get_labels_selectors() {
		return [
			'.jet-booking-form .jet-abaf-field__label label',
			'.jet-booking-form .jet-abaf-separate-field__label',
			'.jet-booking-form .form-field > label',
			'.jet-booking-form .jet-abaf-timepicker label',
		];
	}

	/**
	 * Booking form field selectors.
	 *
	 * @since 4.1.0
	 *
	 * @return array
	 */
	private function get_fields_selectors() {
		return [
			'.jet-booking-form input',
			'.jet-booking-form select',
		];
	}

	/**
	 * Load shared date range picker controls helper.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function load_date_range_picker_controls() {
		require_once JET_ABAF_PATH . 'includes/components/bricks-views/date-range-picker-controls.php';
	}

}
