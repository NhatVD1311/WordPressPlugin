<?php
namespace JET_ABAF\Components\Bricks_Views\Elements;

use Bricks\Element;
use JET_ABAF\Render\Price_Breakdown as Price_Breakdown_Renderer;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Price_Breakdown extends Element {

	// Element properties
	public $category = 'jetbooking';
	public $name = 'jet-booking-price-breakdown';
	public $icon = 'jet-booking-icon-price-breakdown';
	public $css_selector = '';
	public $scripts = [ 'jetBookingBricks' ];
	public $nestable = false;

	public function get_label() {
		return __( 'Price Breakdown', 'jet-booking' );
	}

	public function set_control_groups() {
		$this->control_groups['section_content_styles'] = [
			'title' => __( 'Content', 'jet-booking' ),
			'tab'   => 'style',
		];
	}

	public function set_controls() {
		$this->controls['price_breakdown_note'] = [
			'tab'     => 'content',
			'type'    => 'info',
			'content' => esc_html__( 'Subtotal is calculated from price settings only and may not include extra charges or other adjustments applied elsewhere.', 'jet-booking' ),
		];

		$this->controls['content_gap'] = [
			'tab'   => 'style',
			'group' => 'section_content_styles',
			'type'  => 'slider',
			'label' => __( 'Items Gap', 'jet-booking' ),
			'units' => [
				'px'  => [
					'min'  => 0,
					'max'  => 50,
					'step' => 1,
				],
				'em'  => [
					'min'  => 0,
					'max'  => 5,
					'step' => '0.1'
				],
				'rem' => [
					'min'  => 0,
					'max'  => 5,
					'step' => '0.1'
				],
			],
			'css'   => [
				[
					'property' => 'gap',
					'selector' => '.jet-abaf-price-breakdown__content',
				],
				[
					'property' => 'margin',
					'selector' => '.jet-abaf-price-breakdown__divider',
					'value'    => '0',
				],
			],
		];

		$this->controls['content_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_content_styles',
			'type'    => 'typography',
			'label'   => __( 'Typography', 'jet-booking' ),
			'css'     => [
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-price-breakdown__row',
				],
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-price-breakdown__placeholder',
				],
			],
			'exclude' => [ 'text-align' ],
		];

		$this->controls['heading_total'] = [
			'tab'   => 'style',
			'group' => 'section_content_styles',
			'type'  => 'separator',
			'label' => __( 'Subtotal', 'jet-booking' ),
		];

		$this->controls['total_typography'] = [
			'tab'     => 'style',
			'group'   => 'section_content_styles',
			'type'    => 'typography',
			'label'   => __( 'Typography', 'jet-booking' ),
			'css'     => [
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__label',
				],
				[
					'property' => 'typography',
					'selector' => '.jet-abaf-price-breakdown__row--total .jet-abaf-price-breakdown__value',
				],
			],
			'exclude' => [ 'text-align' ],
		];

		$this->controls['heading_divider'] = [
			'tab'   => 'style',
			'group' => 'section_content_styles',
			'type'  => 'separator',
			'label' => __( 'Divider', 'jet-booking' ),
		];

		$this->controls['divider_color'] = [
			'tab'   => 'style',
			'group' => 'section_content_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.jet-abaf-price-breakdown__divider',
				],
			],
		];

		$this->controls['divider_spacing'] = [
			'tab'   => 'style',
			'group' => 'section_content_styles',
			'label' => __( 'Spacing', 'jet-booking' ),
			'type'  => 'slider',
			'units' => [
				'px'  => [
					'min'  => 0,
					'max'  => 100,
					'step' => 1,
				],
				'em'  => [
					'min'  => 0,
					'max'  => 10,
					'step' => 0.1,
				],
				'rem' => [
					'min'  => 0,
					'max'  => 10,
					'step' => 0.1,
				],
			],
			'css'   => [
				[
					'property' => 'margin-left',
					'selector' => '.jet-abaf-price-breakdown__divider',
				],
				[
					'property' => 'margin-right',
					'selector' => '.jet-abaf-price-breakdown__divider',
				],
			],
		];
	}

	public function enqueue_scripts() {
		jet_abaf()->assets->enqueue_deps( get_the_ID() );
	}

	public function render() {

		$settings               = $this->settings;
		$settings['is_preview'] = bricks_is_builder() || bricks_is_builder_call();

		$this->set_attribute( '_root', 'data-is-block', 'jet-booking/price-breakdown' );

		echo "<div {$this->render_attributes( '_root' )}>"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$renderer = new Price_Breakdown_Renderer( $settings );
		$renderer->render();

		echo '</div>';

	}

}
