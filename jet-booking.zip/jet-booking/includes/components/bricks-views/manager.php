<?php
namespace JET_ABAF\Components\Bricks_Views;

use Bricks\Elements;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Manager {

	public function __construct() {

		if ( ! defined( 'BRICKS_VERSION' ) ) {
			return;
		}

		// Register custom elements.
		add_action( 'init', [ $this, 'register_elements' ], 11 );
		add_action( 'init', [ $this, 'register_providers' ], 90 );

		// Provide a translatable category string for the builder.
		add_filter( 'bricks/builder/i18n', function ( $i18n ) {
			$i18n['jetbooking'] = __( 'JetBooking', 'jet-booking' );

			return $i18n;
		} );

		// Add JetBooking icons font.
		add_action( 'wp_enqueue_scripts', function () {
			if ( bricks_is_builder() ) {
				wp_enqueue_style(
					'jet-booking-icons',
					JET_ABAF_URL . 'assets/lib/jet-booking-icons/icons.css',
					[],
					JET_ABAF_VERSION
				);

				wp_add_inline_style(
					'jet-booking-icons',
					'.jet-booking-calendar-builder-disabled .jet-booking-calendar{ pointer-events:none; }'
				);
			}
		} );

		// Inject control group and controls to JetForms element.
		add_action( 'bricks/elements/jet-form-builder-form/control_groups', [ $this, 'inject_date_range_picker_control_groups' ] );
		add_action( 'bricks/elements/jet-form-builder-form/controls', [ $this, 'inject_date_range_picker_controls' ] );

		new Conditions();

	}

	/**
	 * Register dynamic data providers.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	public function register_providers() {

		require_once JET_ABAF_PATH . 'includes/components/bricks-views/dynamic-data/providers.php';
		require_once JET_ABAF_PATH . 'includes/components/bricks-views/dynamic-data/provider-jet-booking.php';

		$dynamic_data_providers = apply_filters( 'jet-booking/bricks-views/dynamic_data/register_providers', [
			'jet-booking' => '\JET_ABAF\Components\Bricks_Views\Dynamic_Data',
		] );

		Dynamic_Data\Providers::register( $dynamic_data_providers );

	}

	/**
	 * Register elements.
	 *
	 * Load and register custom elements.
	 *
	 * @since 3.1.0
	 * @since 4.0.0 Registered new elements: `settings-configuration`, `settings-schedule`.
	 * @since 4.0.0 Registered new element `price-breakdown`.
	 * @since 4.1.0 Registered new element `booking-form`.
	 */
	public function register_elements() {

		$element_files = [
			[
				'file'  => JET_ABAF_PATH . 'includes/components/bricks-views/elements/booking-form.php',
				'name'  => 'jet-booking-booking-form',
				'class' => '\JET_ABAF\Components\Bricks_Views\Elements\Booking_Form',
			],
			[
				'file'  => JET_ABAF_PATH . 'includes/components/bricks-views/elements/calendar.php',
				'name'  => 'jet-booking-calendar',
				'class' => '\JET_ABAF\Components\Bricks_Views\Elements\Calendar',
			],
			[
				'file'  => JET_ABAF_PATH . 'includes/components/bricks-views/elements/price-breakdown.php',
				'name'  => 'jet-booking-price-breakdown',
				'class' => '\JET_ABAF\Components\Bricks_Views\Elements\Price_Breakdown',
			],
			[
				'file'  => JET_ABAF_PATH . 'includes/components/bricks-views/elements/settings-configuration.php',
				'name'  => 'jet-booking-settings-configuration',
				'class' => '\JET_ABAF\Components\Bricks_Views\Elements\Settings_Configuration',
			],
			[
				'file'  => JET_ABAF_PATH . 'includes/components/bricks-views/elements/settings-schedule.php',
				'name'  => 'jet-booking-settings-schedule',
				'class' => '\JET_ABAF\Components\Bricks_Views\Elements\Settings_Schedule',
			],
		];

		foreach ( $element_files as $element ) {
			Elements::register_element( $element['file'], $element['name'], $element['class'] );
		}

	}

	/**
	 * Inject date range picker control groups.
	 *
	 * Add custom control groups to a specific element.
	 *
	 * @since 3.2.0
	 * @since 4.1.0 Refactored.
	 *
	 * @param array $control_groups List of control groups.
	 *
	 * @return mixed
	 */
	public function inject_date_range_picker_control_groups( $control_groups ) {

		$this->load_date_range_picker_controls();

		return Date_Range_Picker_Controls::register_control_groups( $control_groups );

	}

	/**
	 * Inject date range picker controls.
	 *
	 * Add custom controls to any element.
	 *
	 * @since 3.2.0
	 * @since 4.1.0 Refactored.
	 *
	 * @param array $controls List of controls.
	 *
	 * @return mixed
	 */
	public function inject_date_range_picker_controls( $controls ) {

		$this->load_date_range_picker_controls();

		return Date_Range_Picker_Controls::register_controls( $controls );

	}

	/**
	 * Load shared date range picker controls helper.
	 *
	 * @since 4.1.0
	 *
	 * @return void
	 */
	private function load_date_range_picker_controls() {
		require_once JET_ABAF_PATH . 'includes/components/bricks-views/date-range-picker-controls.php';
	}

}
