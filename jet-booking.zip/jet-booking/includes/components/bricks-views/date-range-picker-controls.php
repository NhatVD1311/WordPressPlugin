<?php
namespace JET_ABAF\Components\Bricks_Views;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

class Date_Range_Picker_Controls {

	/**
	 * Register the date range picker style control group.
	 *
	 * @since 4.1.0
	 *
	 * @param array $control_groups Existing control groups.
	 *
	 * @return array
	 */
	public static function register_control_groups( $control_groups ) {

		$control_groups['section_date_range_picker_styles'] = [
			'tab'   => 'style',
			'title' => __( 'Date Range Picker', 'jet-booking' ),
		];

		return $control_groups;

	}

	/**
	 * Register date range picker style controls.
	 *
	 * @since 4.1.0
	 *
	 * @param array $controls Existing controls.
	 *
	 * @return array
	 */
	public static function register_controls( $controls ) {

		$controls['date_range_picker_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper',
				]
			],
		];

		$controls['date_range_picker_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper',
				]
			],
		];

		$controls['date_range_picker_days_heading'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Days', 'jet-booking' ),
			'type'  => 'separator',
		];

		$controls['date_range_picker_days_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper tbody .day',
				]
			],
		];

		$controls['date_range_picker_days_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper tbody .day',
				]
			],
		];

		$controls['date_range_picker_inactive_days_heading'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Inactive days', 'jet-booking' ),
			'type'  => 'separator',
		];

		$controls['date_range_picker_inactive_days_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper div.day.invalid',
				]
			],
		];

		$controls['date_range_picker_inactive_days_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper div.day.invalid',
				]
			],
		];

		$controls['date_range_picker_current_day_heading'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Current day', 'jet-booking' ),
			'type'  => 'separator',
		];

		$controls['date_range_picker_current_day_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper tbody .day.real-today:not(.invalid)',
				]
			],
		];

		$controls['date_range_picker_current_day_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper tbody .day.real-today:not(.invalid)',
				]
			],
		];

		$controls['date_range_picker_edges_heading'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Days range edges', 'jet-booking' ),
			'type'  => 'separator',
		];

		$controls['date_range_picker_edges_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property'  => 'color',
					'selector'  => '.date-picker-wrapper div.day.first-date-selected',
					'important' => true,
				],
				[
					'property'  => 'color',
					'selector'  => '.date-picker-wrapper div.day.last-date-selected',
					'important' => true,
				]
			],
		];

		$controls['date_range_picker_edges_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property'  => 'background-color',
					'selector'  => '.date-picker-wrapper div.day.first-date-selected',
					'important' => true,
				],
				[
					'property'  => 'background-color',
					'selector'  => '.date-picker-wrapper div.day.last-date-selected',
					'important' => true,
				]
			],
		];

		$controls['date_range_picker_trace_heading'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Days range trace', 'jet-booking' ),
			'type'  => 'separator',
		];

		$controls['date_range_picker_trace_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper tbody div.day.checked',
				],
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper tbody div.day.hovering',
				],
				[
					'property' => 'color',
					'selector' => '.date-picker-wrapper tbody div.day.has-tooltip:hover',
				]
			],
		];

		$controls['date_range_picker_trace_bg_color'] = [
			'tab'   => 'style',
			'group' => 'section_date_range_picker_styles',
			'label' => __( 'Background color', 'jet-booking' ),
			'type'  => 'color',
			'css'   => [
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper tbody div.day.checked',
				],
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper tbody div.day.hovering',
				],
				[
					'property' => 'background-color',
					'selector' => '.date-picker-wrapper tbody div.day.hovering.has-tooltip:hover',
				]
			]
		];

		return $controls;

	}

}
