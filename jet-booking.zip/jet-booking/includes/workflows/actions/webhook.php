<?php
namespace JET_ABAF\Workflows\Actions;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Webhook extends Base {

	/**
	 * Get action ID.
	 *
	 * Returns the unique identifier for this action.
	 *
	 * @since 3.7.0
	 *
	 * @return string Action ID.
	 */
	public function get_id() {
		return 'webhook';
	}

	/**
	 * Get action name.
	 *
	 * Returns the human-readable name for this action.
	 *
	 * @since 3.7.0
	 *
	 * @return string Action name.
	 */
	public function get_name() {
		return __( 'Call a Webhook', 'jet-booking' );
	}

	/**
	 * Performs the action.
	 *
	 * @since  3.7.0
	 * @since  4.0.0 Refactored. Added booking vendor data handling.
	 * @since  4.1.1 Added `prepare_booking_data` method to enhance booking data for webhook payload.
	 * @access public
	 *
	 * @return void
	 */
	public function do_action() {

		$webhook_url = $this->get_settings( 'webhook_url' );

		if ( $webhook_url ) {
			if ( ! empty( $this->booking ) && ! isset( $this->booking['booking_id'] ) ) {
				$this->booking = array_map( [ $this, 'prepare_booking_data' ], $this->get_bookings() );
			} else {
				$this->booking = $this->prepare_booking_data( $this->booking );
			}

			$args     = apply_filters( 'jet-booking/workflows/webhook/args', [ 'body' => $this->booking ], $this );
			$response = wp_remote_post( $webhook_url, $args );

			do_action( 'jet-booking/workflows/webhook/after-response', $response, $args, $this );
		}

	}

	/**
	 * Prepare booking data for webhook payload.
	 *
	 * @since 4.1.1
	 *
	 * @param mixed $booking Booking data.
	 *
	 * @return mixed
	 */
	public function prepare_booking_data( $booking = [] ) {

		if ( ! empty( $booking['booking_vendor'] ) ) {
			$user_data = get_userdata( $booking['booking_vendor'] );

			if ( $user_data ) {
				$booking['booking_vendor_email'] = $user_data->user_email;
			}
		}

		return $booking;

	}

	/**
	 * Registers action controls for the workflow.
	 *
	 * This method is responsible for adding controls to the webhook action.
	 *
	 * @since 3.7.0
	 *
	 * @return void
	 */
	public function register_action_controls() {
		include JET_ABAF_PATH . 'includes/workflows/templates/actions/webhook-controls.php';
	}

}
