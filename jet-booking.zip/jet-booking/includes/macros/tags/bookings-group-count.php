<?php
namespace JET_ABAF\Macros\Tags;

use \Crocoblock\Base_Macros;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Bookings_Group_Count extends Base_Macros {

	/**
	 * Macros tag.
	 *
	 * Returns macros tag.
	 *
	 * @since 4.1.1
	 *
	 * @return string
	 */
	public function macros_tag() {
		return 'bookings_group_count';
	}

	/**
	 * Macros name.
	 *
	 * Returns macros name.
	 *
	 * @since 4.1.1
	 *
	 * @return string
	 */
	public function macros_name() {
		return __( 'Bookings Group Count', 'jet-booking' );
	}

	/**
	 * Macros callback.
	 *
	 * Callback function to return macros value.
	 *
	 * @since 4.1.1
	 *
	 * @param array                       $args    Macros arguments list.
	 * @param \JET_ABAF\Resources\Booking $booking Booking instance.
	 *
	 * @return int
	 */
	public function macros_callback( $args = [], $booking = null ) {
		return apply_filters( 'jet-booking/macros/bookings-group-count', 1, $booking );
	}

}
