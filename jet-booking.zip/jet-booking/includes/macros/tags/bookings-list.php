<?php
namespace JET_ABAF\Macros\Tags;

use \Crocoblock\Base_Macros;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Bookings_List extends Base_Macros {

	/**
	 * Macros tag.
	 *
	 * Returns macros tag.
	 *
	 * @since 4.1.1
	 *
	 * @return string
	 */
	public function macros_tag() {
		return 'bookings_list';
	}

	/**
	 * Macros name.
	 *
	 * Returns macros name.
	 *
	 * @since 4.1.1
	 *
	 * @return string
	 */
	public function macros_name() {
		return __( 'Bookings List', 'jet-booking' );
	}

	/**
	 * Macros callback.
	 *
	 * Callback function to return macros value.
	 *
	 * @since 4.1.1
	 *
	 * @return string
	 */
	public function macros_callback( $args = [] ) {
		return '';
	}

}
