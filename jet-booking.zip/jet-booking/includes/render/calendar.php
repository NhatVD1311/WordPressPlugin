<?php
namespace JET_ABAF\Render;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Calendar extends Base {

	/**
	 * Calendar instance ID.
	 *
	 * @var bool|string
	 */
	private $instance_id = false;

	/**
	 * Render.
	 *
	 * Render calendar element content.
	 *
	 * @since 2.1.0
	 * @since 3.6.5 Added post ID check.
	 * @since 4.1.0 Refactored.
	 *
	 * @return void
	 * @throws \Exception
	 */
	public function render() {

		if ( ! $this->instance_id ) {
			$this->instance_id = 'calendar_' . rand( 1000, 9999 );
		}

		$this->setup_post_context( get_the_ID() );

		$settings        = $this->get_settings();
		$select_dates    = filter_var( $settings['select_dates'] ?? false, FILTER_VALIDATE_BOOLEAN );
		$scroll_to_form  = filter_var( $settings['scroll_to_form'] ?? false, FILTER_VALIDATE_BOOLEAN );
		$wrapper_classes = [ 'jet-booking-calendar' ];

		if ( ! $select_dates ) {
			$wrapper_classes[] = 'disable-dates-select';
		}

		printf(
			'<div class="%s"><input type="hidden" class="jet-booking-calendar__input"/><div id="%s" class="jet-booking-calendar__container" data-scroll-to-form="%s"></div></div>',
			esc_attr( implode( ' ', $wrapper_classes ) ),
			esc_attr( $this->instance_id ),
			esc_attr( $scroll_to_form )
		);

		jet_abaf()->assets->ensure_ajax_js();

	}

}
