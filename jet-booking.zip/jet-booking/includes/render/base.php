<?php
namespace JET_ABAF\Render;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

abstract class Base {

	/**
	 * Settings list.
	 *
	 * @var array
	 */
	protected $settings = [];

	public function __construct( $settings = [] ) {
		$this->settings = is_array( $settings ) ? $settings : [];
	}

	/**
	 * Get settings.
	 *
	 * @since 4.1.0
	 *
	 * @param null|string $setting Setting name.
	 *
	 * @return mixed
	 */
	public function get_settings( $setting = null ) {

		if ( ! $setting ) {
			return $this->settings;
		}

		return $this->settings[ $setting ] ?? false;

	}

	/**
	 * Set up current booking context and enqueue renderer dependencies.
	 *
	 * @since 4.1.0
	 *
	 * @param int|false $post_id Current post ID.
	 *
	 * @return void
	 * @throws \Exception
	 */
	protected function setup_post_context( $post_id ) {

		wp_cache_delete( jet_abaf()->settings::CONTEXT_KEY, 'jet-booking' );
		wp_cache_set( jet_abaf()->settings::CONTEXT_KEY, $post_id, 'jet-booking', 60 );

		jet_abaf()->assets->enqueue_deps( $post_id );

	}

}
