<?php
namespace JET_ABAF;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Advanced_Price_Rates {

	/**
	 * Post meta key
	 */
	private $meta_key = 'jet_abaf_price';

	private $post_meta = null;

	private $rates = false;

	public function __construct( $post_id, $post_meta = false ) {
		$this->set_meta( $post_id, $post_meta );
	}

	/**
	 * Sets the post meta data for a given post.
	 *
	 * @since 2.2.5
	 * @since 4.1.0 Refactored.
	 *
	 * @param int   $post_id   The ID of the post.
	 * @param mixed $post_meta The meta data to set.
	 *
	 * @return void
	 */
	public function set_meta( $post_id, $post_meta ) {
		$this->post_meta = $post_meta ?: get_post_meta( $post_id, $this->meta_key, true );
	}

	/**
	 * Retrieves the pricing rates associated with the current instance.
	 *
	 * @since 2.2.5
	 * @since 4.1.0 Refactored. Added `jet-booking/price/rates` hook.
	 *
	 * @return array The sorted and filtered list of pricing rates.
	 */
	public function get_rates() {

		if ( false === $this->rates ) {
			$pricing_rates = ! empty( $this->post_meta['_pricing_rates'] ) ? $this->post_meta['_pricing_rates'] : [];

			usort( $pricing_rates, function ( $a, $b ) {
				$a_duration = floatval( $a['duration'] );
				$b_duration = floatval( $b['duration'] );

				if ( $a_duration === $b_duration ) {
					return 0;
				}

				return ( $a_duration < $b_duration ) ? - 1 : 1;
			} );

			$this->rates = apply_filters( 'jet-booking/price/rates', $pricing_rates, $this->post_meta, $this );
		}

		return $this->rates;

	}

}
