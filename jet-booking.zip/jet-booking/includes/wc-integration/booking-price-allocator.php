<?php

namespace JET_ABAF\WC_Integration;

use JET_ABAF\Price;

defined( 'ABSPATH' ) || exit;

/**
 * Builds an immutable WooCommerce price allocation for a booking action.
 *
 * @since 4.1.3
 */
class Booking_Price_Allocator {

	/**
	 * Allocate a trusted target total across automatic booking line prices.
	 *
	 * @since 4.1.3
	 *
	 * @param array     $booking      Prepared booking data.
	 * @param int       $capacity     Number of booking lines to create.
	 * @param float|int $target_total Server-resolved booking subtotal.
	 * @param array     $context      Form and WooCommerce cart-item context.
	 *
	 * @return array
	 * @throws \InvalidArgumentException
	 */
	public function allocate( $booking, $capacity, $target_total, $context = [] ) {
		$capacity          = max( 1, absint( $capacity ) );
		$decimals          = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$target_minor      = $this->to_minor_units( $target_total, $decimals, __( 'WooCommerce Total Price field', 'jet-booking' ) );
		$line_prices       = [];
		$line_total_minor  = 0;
		$group_id          = wp_generate_uuid4();
		$cart_item_context = is_array( $context['cart_item_data'] ?? null ) ? $context['cart_item_data'] : [];

		for ( $index = 0; $index < $capacity; $index ++ ) {
			$line_context = $cart_item_context;

			if ( isset( $line_context['data'] ) && is_object( $line_context['data'] ) ) {
				$line_context['data'] = clone $line_context['data'];
			}

			$line_context['jet_booking_price_allocation'] = [
				'group_id'   => $group_id,
				'line_index' => $index,
				'line_count' => $capacity,
			];

			try {
				$price      = new Price( absint( $booking['apartment_id'] ?? 0 ) );
				$line_price = $price->get_booking_price( $booking );
			} catch ( \Exception $exception ) {
				throw new \InvalidArgumentException(
					esc_html__( 'Unable to calculate the automatic price for the selected booking.', 'jet-booking' )
				);
			}

			$line_price = apply_filters( 'jet-booking/wc-integration/booking-price', $line_price, $booking, $line_context );
			$line_minor = $this->to_minor_units( $line_price, $decimals, __( 'Automatic booking price', 'jet-booking' ) );

			$line_prices[]     = $this->from_minor_units( $line_minor, $decimals );
			$line_total_minor += $line_minor;
		}

		if ( $target_minor < $line_total_minor ) {
			throw new \InvalidArgumentException(
				esc_html__( 'The WooCommerce total price cannot be lower than the combined automatic booking prices.', 'jet-booking' )
			);
		}

		return [
			'group_id'     => $group_id,
			'target_total' => $this->from_minor_units( $target_minor, $decimals ),
			'line_prices'  => $line_prices,
			'adjustment'   => $this->from_minor_units( $target_minor - $line_total_minor, $decimals ),
			'label'        => __( 'Booking price adjustment', 'jet-booking' ),
		];
	}

	/**
	 * Normalize a price to WooCommerce currency minor units.
	 *
	 * @param mixed  $amount   Price value.
	 * @param int    $decimals WooCommerce currency decimals.
	 * @param string $source   Human-readable value source.
	 *
	 * @return int
	 * @throws \InvalidArgumentException
	 */
	private function to_minor_units( $amount, $decimals, $source ) {
		if ( ! is_numeric( $amount ) || ! is_finite( floatval( $amount ) ) || 0 > floatval( $amount ) ) {
			throw new \InvalidArgumentException(
				sprintf(
					/* translators: %s: booking price source */
					esc_html__( '%s must resolve to a finite, non-negative number.', 'jet-booking' ),
					esc_html( $source )
				)
			);
		}

		$normalized = function_exists( 'wc_format_decimal' )
			? wc_format_decimal( $amount, $decimals )
			: number_format( floatval( $amount ), $decimals, '.', '' );
		$precision  = 10 ** $decimals;

		return (int) round( floatval( $normalized ) * $precision );
	}

	/**
	 * Convert currency minor units to a normalized price.
	 *
	 * @param int $amount   Minor-unit amount.
	 * @param int $decimals WooCommerce currency decimals.
	 *
	 * @return float
	 */
	private function from_minor_units( $amount, $decimals ) {
		return round( $amount / ( 10 ** $decimals ), $decimals );
	}
}
