<?php

namespace JET_ABAF\Formbuilder_Plugin\Actions\Types;

use JET_ABAF\Apartment_Booking_Trait;
use JET_ABAF\Vendor\Actions_Core\Base_Handler_Exception;
use JET_ABAF\Vendor\Actions_Core\Smart_Action_Trait;
use JET_ABAF\WC_Integration\Booking_Price_Allocator;
use Jet_Form_Builder\Exceptions\Gateway_Exception;
use Jet_Form_Builder\Actions\Types\Base;
use JFB_Modules\Gateways\Trusted_Price_Resolver;

class Insert_Booking extends Base {

	use Apartment_Booking_Trait, Smart_Action_Trait {
		Apartment_Booking_Trait::run_action as private run_booking_action;
		Apartment_Booking_Trait::run_action insteadof Smart_Action_Trait;
	}

	/**
	 * Server-resolved WooCommerce price for the current action execution.
	 *
	 * @var float|null
	 */
	private $trusted_wc_price;

	/**
	 * Prepared WooCommerce price allocation for the current action execution.
	 *
	 * @var array|null
	 */
	private $wc_price_allocation;

	/**
	 * Run the booking action with secure WooCommerce price resolution attached
	 * to the last pre-insert stage.
	 *
	 * @return array|void
	 * @throws Base_Handler_Exception
	 */
	public function run_action() {
		$this->trusted_wc_price    = null;
		$this->wc_price_allocation = null;

		add_filter( 'jet-booking/form-action/pre-process', [ $this, 'resolve_trusted_wc_price' ], 0, 3 );

		try {
			return $this->run_booking_action();
		} finally {
			remove_filter( 'jet-booking/form-action/pre-process', [ $this, 'resolve_trusted_wc_price' ], 0 );
		}
	}

	/**
	 * Resolve the configured price from saved form structure and trusted
	 * server-side data before any booking is inserted.
	 *
	 * @param mixed  $pre_processed Value supplied by other pre-process filters.
	 * @param array  $booking       Prepared booking data.
	 * @param object $action        Current booking action.
	 *
	 * @return mixed
	 * @throws Base_Handler_Exception
	 */
	public function resolve_trusted_wc_price( $pre_processed, $booking, $action ) {

		if ( $this !== $action || ! jet_abaf()->settings->wc_integration_enabled() || filter_var( $this->getSettings( 'disable_wc_integration' ), FILTER_VALIDATE_BOOLEAN ) ) {
			return $pre_processed;
		}

		$field_name = $this->getSettings( 'booking_wc_price' );

		if ( ! is_string( $field_name ) || '' === trim( $field_name ) ) {
			return $pre_processed;
		}

		if ( ! class_exists( Trusted_Price_Resolver::class ) ) {
			throw new Base_Handler_Exception(
				esc_html__( 'Unable to calculate a secure WooCommerce price. Please update JetFormBuilder.', 'jet-booking' ),
				'error'
			);
		}

		try {
			$trusted_price = ( new Trusted_Price_Resolver( (int) $this->getFormId() ) )->resolve( trim( $field_name ) );
			$capacity      = $this->get_booking_capacity( $booking );
			$product       = wc_get_product( jet_abaf()->wc->mode->get_product_id() );
			$cart_context = [
				'data'                        => $product,
				jet_abaf()->wc->data_key          => $booking,
				jet_abaf()->wc->form_data_key     => $this->getRequest(),
				jet_abaf()->wc->form_id_key       => $this->getFormId(),
			];

			$this->wc_price_allocation = ( new Booking_Price_Allocator() )->allocate(
				$booking,
				$capacity,
				$trusted_price,
				[
					'cart_item_data' => $cart_context,
				]
			);
			$this->trusted_wc_price    = $trusted_price;
		} catch ( Gateway_Exception | \InvalidArgumentException $exception ) {
			throw new Base_Handler_Exception(
				sprintf(
					/* translators: %s: secure price validation error */
					esc_html__( 'Unable to calculate a secure WooCommerce price: %s', 'jet-booking' ),
					esc_html( $exception->getMessage() )
				),
				'error'
			);
		}

		return $pre_processed;

	}

	/**
	 * Get the trusted WooCommerce price resolved for the current request.
	 *
	 * @return float|null
	 */
	public function get_trusted_wc_price() {
		return $this->trusted_wc_price;
	}

	/**
	 * Get the prepared WooCommerce price allocation for the current request.
	 *
	 * @return array|null
	 */
	public function get_wc_price_allocation() {
		return $this->wc_price_allocation;
	}

	public function get_id() {
		return 'apartment_booking';
	}

	public function get_name() {
		return __( 'Apartment Booking', 'jet-booking' );
	}

	public function visible_attributes_for_gateway_editor() {
		return [ 'booking_apartment_field' ];
	}

	public function self_script_name() {
		return 'JetBookingActionData';
	}

	/**
	 * Action data.
	 *
	 * @since  2.8.0 Refactored. Added initial select type.
	 * @access public
	 *
	 * @return array
	 */
	public function action_data() {

		$wc_integration = jet_abaf()->settings->wc_integration_enabled();
		$post_id        = get_the_ID();
		$wc_fields      = [];
		$details        = [];
		$nonce          = '';

		if ( $wc_integration ) {
			$nonce     = wp_create_nonce( jet_abaf()->wc->mode->details->meta_key );
			$wc_fields = jet_abaf()->wc->mode->get_checkout_fields();
			$details   = jet_abaf()->wc->mode->details->get_details_schema( $post_id );
		}

		return [
			'columns'        => jet_abaf()->db->get_additional_db_columns(),
			'wc_integration' => $wc_integration,
			'apartment'      => $post_id,
			'wc_fields'      => $wc_fields,
			'details'        => $details,
			'nonce'          => $nonce,
			'details_types'  => [
				[
					'value' => '',
					'label' => __( 'Select type...', 'jet-booking' ),
				],
				[
					'value' => 'booked-inst',
					'label' => __( 'Booked instance name', 'jet-booking' ),
				],
				[
					'value' => 'check-in',
					'label' => __( 'Check in', 'jet-booking' ),
				],
				[
					'value' => 'check-out',
					'label' => __( 'Check out', 'jet-booking' ),
				],
				[
					'value' => 'unit',
					'label' => __( 'Booking unit', 'jet-booking' ),
				],
				[
					'value' => 'field',
					'label' => __( 'Form field', 'jet-booking' ),
				],
				[
					'value' => 'add_to_calendar',
					'label' => __( 'Add to Google calendar link', 'jet-booking' ),
				],
				[
					'value' => 'price-breakdown',
					'label' => __( 'Price breakdown', 'jet-booking' ),
				],
			],
		];

	}

	public function editor_labels() {
		return [
			'booking_apartment_field'          => __( 'Apartment ID field:', 'jet-booking' ),
			'booking_dates_field'              => __( 'Check-in/Check-out date field:', 'jet-booking' ),
			'booking_email_field'              => __( 'E-mail field:', 'jet-booking' ),
			'db_columns_map'                   => __( 'DB columns map:', 'jet-booking' ),
			'disable_wc_integration'           => __( 'Disable WooCommerce integration:', 'jet-booking' ),
			'booking_wc_price'                 => __( 'WooCommerce Total Price field:', 'jet-booking' ),
			'wc_order_details'                 => __( 'WooCommerce order details:', 'jet-booking' ),
			'wc_fields_map'                    => __( 'WooCommerce checkout fields map:', 'jet-booking' ),
			'wc_details__type'                 => __( 'Type', 'jet-booking' ),
			'wc_details__label'                => __( 'Label', 'jet-booking' ),
			'wc_details__format'               => __( 'Date format', 'jet-booking' ),
			'wc_details__field'                => __( 'Select form field', 'jet-booking' ),
			'wc_details__link_label'           => __( 'Link text', 'jet-booking' ),
		];
	}

	public function editor_labels_help() {
		return [
			'db_columns_map'                    => __( 'Set up connection between form fields and additional database table columns. This allows you to save entered field data in the corresponding DB column.', 'jet-booking' ),
			'disable_wc_integration'            => __( 'Check to disable WooCommerce integration and disconnect the booking system with WooCommerce checkout for current form.', 'jet-booking' ),
			'booking_wc_price'                  => __( 'Select a form field that represents the total booking subtotal before WooCommerce taxes and discounts. Each booking keeps its server-calculated automatic line price, and any positive difference is added once as a booking price adjustment. Leave empty to calculate checkout prices directly from JetBooking booking data.', 'jet-booking' ),
			'wc_order_details'                  => __( 'Set up booking-related info you want to add to the WooCommerce orders and e-mails.', 'jet-booking' ),
			'wc_fields_map'                     => __( 'Connect WooCommerce checkout fields to appropriate form fields. This allows you to pre-fill WooCommerce checkout fields after redirect to checkout.', 'jet-booking' ),
		];
	}

}
