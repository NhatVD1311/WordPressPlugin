<?php
namespace JET_ABAF;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Seasonal_Price {

	/**
	 * Post meta
	 */
	private $post_meta;

	public function __construct( $post_meta = [] ) {
		$this->post_meta = $post_meta;
	}

	/**
	 * Retrieves the seasonal prices configured for the current context.
	 *
	 * @since 2.2.5
	 * @since 4.1.0 Added `jet-booking/price/seasonal-prices` hook.
	 *
	 * @return array An array of seasonal pricing data.
	 */
	public function get_price() {

		$output = [];

		if ( empty( $this->post_meta['_seasonal_prices'] ) ) {
			return $output;
		}

		foreach ( $this->post_meta['_seasonal_prices'] as $value ) {
			$rates_price   = new Advanced_Price_Rates( $this->post_meta['ID'] ?? 0, $value );
			$weekend_price = new Weekend_Price( $value );

			$output_value = [
				'start'         => $value['startTimestamp'],
				'end'           => $value['endTimestamp'],
				'price'         => $value['price'],
				'price_rates'   => $rates_price->get_rates(),
				'weekend_price' => $weekend_price->get_price(),
			];

			if ( isset( $value['enable_config'] ) && $value['enable_config'] ) {
				$output_value += [
					'enable_config'    => $value['enable_config'],
					'start_day_offset' => $value['start_day_offset'] ?? 0,
					'min_days'         => $value['min_days'] ?? 0,
					'max_days'         => $value['max_days'] ?? 0,
				];
			}

			$output[ $value['startTimestamp'] . $value['endTimestamp'] ] = $output_value;
		}

		return apply_filters( 'jet-booking/price/seasonal-prices', $output, $this->post_meta, $this );

	}

}
