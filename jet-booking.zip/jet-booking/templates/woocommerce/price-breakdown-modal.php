<?php
/**
 * WooCommerce price breakdown modal.
 *
 * This template can be overridden by copying it to yourtheme/jet-booking/woocommerce/price-breakdown-modal.php.
 *
 * @since 4.1.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.
?>

<div class="jet-abaf-wc-price-breakdown-modal" hidden>
	<div class="jet-abaf-wc-price-breakdown-modal__overlay" data-jet-abaf-close="true"></div>
	<div class="jet-abaf-wc-price-breakdown-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="jet-abaf-wc-price-breakdown-modal-title">
		<button type="button" class="jet-abaf-wc-price-breakdown-modal__close" aria-label="<?php esc_attr_e( 'Close price breakdown', 'jet-booking' ); ?>" data-jet-abaf-close="true">
			<span class="dashicons dashicons-no-alt"></span>
		</button>
		<div class="jet-abaf-wc-price-breakdown-modal__header">
			<h4 class="jet-abaf-wc-price-breakdown-modal__title" id="jet-abaf-wc-price-breakdown-modal-title">
				<?php esc_html_e( 'Price breakdown', 'jet-booking' ); ?>
			</h4>
		</div>
		<div class="jet-abaf-wc-price-breakdown-modal__body">
			<div class="jet-abaf-price-breakdown">
				<div class="jet-abaf-price-breakdown__content"></div>
			</div>
		</div>
	</div>
</div>
