
/**
 * ACPT Back-end Live conditional rendering
 */
class ACPTConditionalRules
{
    /**
     * Single shared debounced call to #applyIsVisible(), so rapid edits across
     * *different* fields coalesce into one AJAX call instead of one per field.
     */
    #debouncedApplyIsVisible;

    /**
     * Every change/keyup listener the current pass registered, so the next re-init can
     * remove them instead of stacking a second copy on top.
     *
     * @type {Array<{element: Element, type: string, handler: Function}>}
     */
    #changeListeners = [];

    constructor(page, action, belongsTo, elementId)
    {
        this.#init();
        this.action = action;
        this.page = page;
        this.belongsTo = belongsTo;
        this.elementId = elementId;
        this.#debouncedApplyIsVisible = this.#debounce(() => this.#applyIsVisible(), 300);
        this.#hideBoxesIfNotVisible();
    }

    /**
     * Init the values
     */
    #init()
    {
        this.metaBoxes = document.body.querySelectorAll('.acpt-metabox');
        this.elements = document.body.querySelectorAll('[data-conditional-rules-id]');
        this.values = [];
        this.checks = [];

        this.elements.forEach((element) => {

            const value = this.#getValue(element);
            const id = element.name;
            const formId = element.getAttribute("data-conditional-rules-id");
            const forgedBy = element.getAttribute("data-conditional-rules-field-forged-by");
            const fieldIndex = element.getAttribute("data-conditional-rules-field-index");
            const blockIndex = element.getAttribute("data-conditional-rules-block-index");
            const blockName = element.getAttribute("data-conditional-rules-block-name");

            // if is checkbox
            if(element.type === 'checkbox' && id.includes("[]")){
                if(element.checked){
                    this.values.push({
                        id: id.replace("[]", ""),
                        formId: formId,
                        value: value,
                        forgedBy: forgedBy,
                        fieldIndex: fieldIndex,
                        blockIndex: blockIndex,
                        blockName: blockName
                    });
                }
            } else {
                this.values.push({
                    id: id,
                    formId: formId,
                    value: value,
                    forgedBy: forgedBy,
                    fieldIndex: fieldIndex,
                    blockIndex: blockIndex,
                    blockName: blockName
                });
            }
        });

        // boxes: a box marker has no "own value" to track (only fields do) — its mere
        // presence tells the backend "please also check this box's visibility". Collected
        // separately from the [data-conditional-rules-id] pass above, since a box marker
        // never carries that attribute.
        this.boxElements = document.body.querySelectorAll('[data-conditional-rules-box-id]');

        this.boxElements.forEach((element) => {
            const formId = element.getAttribute("data-conditional-rules-box-id");

            if (this.values.some((el) => el.formId === formId)) {
                return;
            }

            this.values.push({
                id: null,
                formId: formId,
                value: null,
                forgedBy: null,
                fieldIndex: null,
                blockIndex: null,
                blockName: null
            });
        });
    }

    /**
     * Change input value handler
     * @param event
     */
    #changeValueHandler(event){

        if(!this.#isValidKey(event)){
            return;
        }

        const element = event.target;
        const id = element.name;
        const formId = element.getAttribute("data-conditional-rules-id");
        const forgedBy = element.getAttribute("data-conditional-rules-field-forged-by");
        const fieldIndex = element.getAttribute("data-conditional-rules-field-index");
        const blockIndex = element.getAttribute("data-conditional-rules-block-index");
        const blockName = element.getAttribute("data-conditional-rules-block-name");

        const value = this.#getValue(element);

        let elementIndex = this.values.findIndex((el) => {
            return el.id === id && el.formId === formId;
        });

        // Assigning this.values[-1] would set a property literally named "-1": the
        // array length never grows and JSON.stringify drops it, so an untracked control
        // (e.g. one whose name changed after the last re-init) silently never reached
        // the server and its rule never fired.
        const record = {
            id: id,
            formId: formId,
            value: value,
            forgedBy: forgedBy,
            fieldIndex: fieldIndex,
            blockIndex: blockIndex,
            blockName: blockName
        };

        // radio fields
        if(element.type === 'radio') {
            if (element.checked) {
                if(elementIndex === -1){
                    this.values.push(record);
                } else {
                    this.values[elementIndex] = record;
                }
            }
        }

        // checkbox fields (only Back-end)
        else if(element.type === 'checkbox' && id.includes("[]")) {
            if (element.checked) {
                this.values.push({
                    id: id.replace("[]", ""),
                    formId: formId,
                    value: value,
                    forgedBy: forgedBy,
                    fieldIndex: fieldIndex,
                    blockIndex: blockIndex,
                    blockName: blockName
                });
            } else {

                // remove from this.values
                let newValues = [];

                this.values.map((el) => {
                    if(el.formId !== formId){
                        newValues.push(el);
                    } else {
                        if(value !== el.value){
                            newValues.push(el);
                        }
                    }
                });

                this.values = newValues;
            }
        } else {
            if(elementIndex === -1){
                this.values.push(record);
            } else {
                this.values[elementIndex] = record;
            }
        }

        this.#debouncedApplyIsVisible();
    }

    /**
     *
     * @param event
     * @return {boolean}
     */
    #isValidKey(event) {

        if (event.ctrlKey) {
            return false;
        }

        if (event.shiftKey) {
            return false;
        }

        const key = event.key;

        // Only keys that cannot alter the field's value belong here. "Delete" used to be
        // in this list even though it clears the value exactly as Backspace does, so
        // clearing a field with it left the stale value in the payload while the field
        // read empty -- and the same user action behaved differently per key.
        const keysToSkip = [
            "ArrowUp",
            "ArrowDown",
            "Enter",
        ];

        return !keysToSkip.includes(key);
    };

    /**
     * Run the checks
     */
    run()
    {
        // listen to those events in order to re-init props and values
        const events = [
            'acpt_flexible_element_added',
            'acpt_grouped_element_added',
            'acpt_grouped_element_removed',
            'acpt_grouped_element_sorted',
            'acpt_media_added',
        ];

        events.map((event) => {
            document.addEventListener(event, (e) => {
                this.#init();
                this.#listenForChangeEvents();
            });
        });

        this.#listenForChangeEvents();
    }

    /**
     * Loop form elements and listen for change/keyup events
     */
    #listenForChangeEvents()
    {
        // Detach the previous pass first. run() re-inits on five repeater/flexible/media
        // events, and this method used to add another change+keyup pair to every element
        // it already knew about -- so N added rows left every original field carrying
        // N+1 duplicate pairs and one keystroke ran #changeValueHandler N+1 times, with
        // no removeEventListener anywhere to unwind them.
        this.#changeListeners.forEach((listener) => {
            listener.element.removeEventListener(listener.type, listener.handler);
        });

        this.#changeListeners = [];

        this.elements.forEach((element) => {
            const handler = (e) => {
                this.#changeValueHandler(e);
            };

            ["change", "keyup"].map((ev)=>{
                element.addEventListener(ev, handler);
                this.#changeListeners.push({element: element, type: ev, handler: handler});
            });
        });
    }

    /**
     * Hide meta boxes if no element inside is visible
     */
    #hideBoxesIfNotVisible()
    {
        let visibleBoxCount = 0;

        // hide meta boxes if no element is visible
        this.metaBoxes.forEach((metaBox) => {

            let visibleFieldsTotalCount = 0;
            const rows = metaBox.querySelectorAll(".acpt-admin-meta-row");

            rows.forEach((row) => {

                let visibleFieldsRowCount = 0;

                // NOTE: a row is judged empty purely by counting non-hidden wrappers, so
                // a field renderer that early-returns markup without going through
                // AbstractField::renderField() produces zero wrappers and reads as a
                // blank row -- that was ticket #1233. See
                // tests/generators/PostFieldAdminRenderTest.php for the PHP-side contract.
                const fields = row.querySelectorAll(".acpt-admin-meta-wrapper");

                fields.forEach((field) => {
                    if(!field.classList.contains("hidden")){
                        visibleFieldsTotalCount++;
                        visibleFieldsRowCount++;
                    }
                });

                if(visibleFieldsRowCount === 0){
                    row.classList.add("hidden");
                } else {
                    row.classList.remove("hidden");
                }
            });

            // Toggle the whole postbox (title bar included) exactly as #applyConditions
            // does for a box marker, instead of calling metaBox.remove(): a removed box
            // takes its marker with it, so no later response could ever bring it back
            // and the field stayed invisible until a full page reload.
            //
            // A box can be hidden for two independent reasons -- an explicit box-level
            // verdict from #applyConditions, or having no visible field left -- and this
            // pass runs straight after that one. So only ever un-hide a box *this* method
            // hid, tracked with its own marker attribute; otherwise a box with a visible
            // field would immediately undo the box-level verdict applied a moment earlier.
            const target = metaBox.closest('.postbox') || metaBox;

            if(visibleFieldsTotalCount === 0){
                target.classList.add("hidden");
                target.setAttribute("data-acpt-hidden-when-empty", "1");
            } else {
                if(target.hasAttribute("data-acpt-hidden-when-empty")){
                    target.classList.remove("hidden");
                    target.removeAttribute("data-acpt-hidden-when-empty");
                }

                if(!target.classList.contains("hidden")){
                    visibleBoxCount++;
                }
            }
        });

        // Option pages: only stand the save controls down when there is genuinely
        // nothing left to save. This used to sit inside the loop above and .remove() the
        // buttons, so a single empty box deleted the page's only Save button while other
        // boxes were still perfectly visible -- irreversibly.
        const optionPageButtons = document.getElementById("acpt-option-page-buttons");

        if(optionPageButtons && this.metaBoxes.length > 0){
            if(visibleBoxCount === 0){
                optionPageButtons.classList.add("hidden");
            } else {
                optionPageButtons.classList.remove("hidden");
            }
        }
    }

    /**
     *
     * @return {Promise<void>}
     */
    async #applyIsVisible()
    {
        const baseAjaxUrl = (typeof ajaxurl === 'string') ? ajaxurl : '/wp-admin/admin-ajax.php';

        const formData = new FormData();
        formData.append('action', 'checkIsVisibleAction');
        formData.append('data', JSON.stringify({
            values: this.values,
            elementId: this.elementId,
            belongsTo: this.belongsTo,
        }));

        // The chain used to be a bare .then(r => r.json()) with no status check and no
        // .catch(), so a transport failure -- or the very common WordPress case of a PHP
        // notice prepended to the AJAX body, which makes json() reject -- produced an
        // unhandled rejection and silently stopped every later visibility update.
        return fetch(baseAjaxUrl, {
            method: 'POST',
            body: formData
        })
        .then((response) => {
            if(!response.ok){
                throw new Error(`checkIsVisibleAction responded with HTTP ${response.status}`);
            }

            return response.json();
        })
        .then((data) => {
            this.#applyConditions(data);
            this.checks = data;

            return data;
        })
        .catch((error) => {
            console.error('ACPTConditionalRules: could not refresh field visibility', error);
        });
    }

    /**
     *
     * @param func
     * @param timeout
     * @return {function(...[*]=)}
     */
    #debounce(func, timeout = 300){
        let timer;

        return (...args) => {
            clearTimeout(timer);
            timer = setTimeout(() => { func.apply(this, args); }, timeout);
        };
    }

    /**
     *
     * @param element
     * @return {number}
     */
    #getValue = (element) => {

        // is toggle element
        if(element.type === 'checkbox' && element.value === "1"){
            return element.checked ? 1 : 0;
        }

        return element.value;
    };

    /**
     * Apply conditions
     * @param data
     */
    #applyConditions = (data) => {
        for (const [key, value] of Object.entries(data)) {

            // boxes: a box can be one DOM fragment (Option Page/Taxonomy/User wrapper divs,
            // which carry the marker attribute directly) or two (horizontal/vertical tabs'
            // separate tab-button + panel), or the marker can be nested a level or two inside
            // the real toggle target (CPT's WP-native postbox, where the marker is an inline
            // span since add_meta_box()'s wrapper attributes aren't otherwise reachable) —
            // so every match is toggled via its own nearest .postbox ancestor, falling back
            // to the marker itself when there isn't one.
            const boxElements = document.body.querySelectorAll(`[data-conditional-rules-box-id="${key}"]`);

            if (boxElements.length > 0 && typeof value === 'boolean') {
                boxElements.forEach((marker) => {
                    const target = marker.closest('.postbox') || marker;

                    if (value === false) {
                        target.classList.add('hidden');
                    } else {
                        target.classList.remove('hidden');
                    }
                });

                continue;
            }

            switch (typeof value) {
                case "boolean": {

                    // Resolved once. These used to be arrow functions re-invoked up to
                    // three times per key (and the object branch below ran its
                    // querySelectorAll twice inside its own guard), so a response with
                    // many keys meant ~6 full-document queries each where one would do.
                    // back-end element first, then the front-end form handle
                    const el = document.getElementById(key)
                        || document.querySelector(`[data-field-id="${key}"]`);

                    if(el){
                        if(value === false){
                            el.classList.add("hidden");
                        } else {
                            el.classList.remove("hidden");
                        }
                    }
                    break;
                }

                case "object": {

                    let elmts = document.querySelectorAll(`[data-id="${key}"]`);

                    if(elmts.length === 0){
                        elmts = document.querySelectorAll(`[data-field-id="${key}"]`);
                    }

                    elmts.forEach((element, index) => {

                        // repeater fields
                        if(typeof value[index] !== 'undefined'){
                            if(value[index] === false){
                                element.classList.add("hidden");
                            } else {
                                element.classList.remove("hidden");
                            }

                            return;
                        }

                        // flexible fields
                        const field = element.querySelector(".acpt-admin-meta-field-input");

                        if(!field){
                            return;
                        }

                        const fieldIndex = field.getAttribute("data-conditional-rules-field-index");
                        const blockIndex = field.getAttribute("data-conditional-rules-block-index");
                        const blockName = field.getAttribute("data-conditional-rules-block-name");

                        // Every hop needs guarding, not just the first: `value[blockName]`
                        // was checked but `value[blockName][blockIndex]` was not, so a
                        // response missing that block index threw and aborted this whole
                        // loop -- every later key in the same response went unapplied.
                        const block = value[blockName];
                        const blockValues = block ? block[blockIndex] : undefined;

                        if(blockValues && typeof blockValues[fieldIndex] !== 'undefined'){
                            if(blockValues[fieldIndex] === false){
                                element.classList.add("hidden");
                            } else {
                                element.classList.remove("hidden");
                            }
                        }
                    });

                    break;
                }
            }
        }

        this.#hideBoxesIfNotVisible();
    };

}
