import {$$, tinyMCEWordpressDefaultSettings} from "./_admin_commons.js";
import {gutenbergIsEnabled} from "./_admin_helpers.js";

var $ = jQuery.noConflict();
const { __ } = wp.i18n;

/**
 * init TinyMCE on dynamic generated children fields
 *
 * @param id
 * @param rows
 * @param toolbar
 */
export const initTinyMCE = (id, rows = 8, toolbar = 'full') => {
    // declared here (not inside the try) so the catch below can safely reference it
    let buttons = $();

    try {
        if(typeof tinyMCE === 'undefined'){
            console.error("tinyMCE is not defined. Include it here");
            return;
        }

        const textarea = $(`#${id}`);
        const media = textarea.data("media");
        const loading = $(`#loading_${id}`);
        buttons = $(`#buttons_${id}`);
        const chCounter = $(`#ch_counter_${id}`);
        const max = parseInt(chCounter.data("max"));
        const min = parseInt(chCounter.data("min"));
        const tabs = buttons.data("tabs") ?? 'full';

        tinyMCE.init(tinyMCEWordpressDefaultSettings(id, rows, toolbar));
        tinyMCE.execCommand('mceToggleEditor', false, id);
        // reassigned by restartEditor() below
        let ed = tinyMCE.get(id) || tinyMCE.activeEditor;

        const bindChangeEvent = () => {
            ed.on('change', function(e) {
                const wcSaveVariationChangesButton = $(".save-variation-changes");

                if(wcSaveVariationChangesButton){
                    wcSaveVariationChangesButton.removeAttr('disabled');
                }
            });
        };

        bindChangeEvent();

        loading.remove();
        textarea.removeClass("hidden");

        // Add media and editor tabs buttons
        let html = '';

        if(media !== 1){
            html += `<div id="wp-${id}-media-buttons" class="wp-media-buttons">
                    <button type="button" id="insert-media-button" class="button insert-media add_media" data-editor="${id}">
                        <span class="wp-media-buttons-icon"></span> 
                        ${__("Add Media")}
                    </button>
                </div>`;
        }

        // tabs
        html += `<div class="wp-editor-tabs">`;

        if(tabs === 'full' || tabs === 'visual'){
            html += `
                    <button type="button" id="${id}-tmce" aria-pressed="true" class="wp-switch-editor switch-tmce" data-wp-editor-id="${id}">
                        ${__("Visual")}
                    </button>
                `;
        }

        if(tabs === 'full' || tabs === 'text'){
            html += `
                    <button type="button" id="${id}-html" class="wp-switch-editor switch-html" data-wp-editor-id="${id}">
                        ${__("Text")}
                    </button>
                `;
        }

        html += `</div>`;
        buttons.html(html);

        // Add character counter if max or min are defined
        const initCharacterCounter = () => {
            if(max || min){

                /**
                 *
                 * @return {number}
                 */
                const charCount = () => {

                    const text = ed.contentDocument.body.innerText;

                    if(text.trim()  === ""){
                        return 0;
                    }

                    return text.length;
                };

                /**
                 *
                 * @return {string}
                 */
                const renderCharCounter = () => {

                    const value = charCount();
                    let css = '';

                    if(value < min || value >= max){
                        css += 'danger';
                    } else if(value >= max-5){
                        css += 'warning';
                    } else {
                        css = '';
                    }

                    const limit = max ? max : "∞";

                    return `<span class="count ${css}">${charCount()}</span>/<span class="max">${limit}</span> `;
                };

                const handleMinValue = () => {

                    let button;

                    if(gutenbergIsEnabled()){
                        button = $(".editor-post-publish-button__button"); // gutenberg
                    } else if($("#publish").length > 0) {
                        button = $("#publish"); // classic editor (post types)
                    } else if($("#save-option-page").length > 0) {
                        button = $("#save-option-page"); // option pages
                    } else if($("#submit").length > 0) {
                        button = $("#submit"); // create new taxonomy
                    } else if($(`input[type="submit"]`).length > 0) {
                        button = $(`input[type="submit"]`); // edit taxonomy
                    }

                    const value = charCount();
                    const errors = chCounter.next(".acpt-error-list");
                    const editor = chCounter.prev(".acpt-wp-editor-wrapper");

                    // min
                    if(value < min){
                        const error = `Min length ${min}`;
                        textarea[0].setCustomValidity(error);
                        textarea[0].reportValidity();
                        errors.html(`<li>${error}</li>`);
                        editor.addClass(`has-errors`);

                        if(button){
                            button.attr('disabled', 'disabled');
                        }
                    } else {
                        textarea[0].setCustomValidity("");
                        textarea[0].reportValidity();
                        errors.html("");
                        editor.removeClass(`has-errors`);

                        if(button){
                            button.removeAttr('disabled');
                        }
                    }
                };

                /**
                 * On load, render the character counter and listen for handling min value
                 */
                ed.on('load', function(e) {
                    chCounter.html(renderCharCounter());
                    handleMinValue();
                });

                /**
                 * Update counter
                 * Set validation error if MIN value is not reached
                 */
                ed.on('keyup', function(e) {

                    const value = charCount();
                    const count = chCounter.find(".count");

                    if(value < min || value >= max){
                        count.removeClass("warning");
                        count.addClass('danger');
                    } else if(value >= max-5){
                        count.removeClass("danger");
                        count.addClass('warning');
                    } else {
                        count.removeClass("warning");
                        count.removeClass("danger");
                    }

                    count.text(value);
                    handleMinValue();
                });

                /**
                 * Return false is MAX value is exceeded
                 */
                ed.on('keydown', function(e) {

                    const allowedKeys = [
                        "Backspace",
                        "Delete",
                        "Shift",
                        "Control",
                        "ArrowLeft",
                        "ArrowRight",
                    ];

                    if(allowedKeys.includes(e.key)){
                        return true;
                    }

                    const value = charCount();

                    // max
                    if(value >= max){
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    }

                    return true;
                });
            }
        };

        /**
         * If tabs is equals to only Textual, switch to HTML tab
         */
        const applyTabs = () => {
            if(tabs !== 'text'){
                return;
            }

            ed.on('load', function(e) {
                const switchEditors = window.switchEditors;
                switchEditors.go(id, 'html');
            });
        };

        initCharacterCounter();
        applyTabs();

        /**
         * Re-create the editor, keeping its content.
         */
        const restartEditor = () => {
            const current = tinyMCE.get(id);

            if(current){
                current.save(); // the stale instance still holds the content: write it back to the textarea
            }

            tinyMCE.execCommand('mceRemoveEditor', false, id);
            tinyMCE.init(tinyMCEWordpressDefaultSettings(id, rows, toolbar));
            tinyMCE.execCommand('mceToggleEditor', false, id);

            ed = tinyMCE.get(id) || tinyMCE.activeEditor;
            bindChangeEvent();
            initCharacterCounter();
            applyTabs();
            watchIframeReset();
        };

        /**
         * The block editor moves the meta boxes around the DOM: on load, and again whenever
         * it re-mounts its layout (e.g. toggling distraction-free mode). Moving an <iframe>
         * resets its document, leaving TinyMCE with a blank, non-editable body (#1395).
         * The reset iframe fires "load" again: re-create the editor when that happens.
         */
        const watchIframeReset = () => {
            const editor = ed;

            const attach = () => {
                const iframe = editor.iframeElement;

                if(!iframe || iframe.dataset.acptResetWatcher){
                    return;
                }

                iframe.dataset.acptResetWatcher = "1";
                iframe.addEventListener("load", () => {
                    if(tinyMCE.get(id) !== editor || !editor.initialized){
                        return;
                    }

                    let body = null;

                    try {
                        body = iframe.contentDocument ? iframe.contentDocument.body : null;
                    } catch (e) {}

                    if(body && body !== editor.getBody()){
                        restartEditor();
                    }
                });
            };

            if(editor.initialized){
                attach();
            } else {
                editor.on('init', attach);
            }
        };

        watchIframeReset();

        // restart tinyMCE if it has not properly started (e.g. the meta boxes were moved
        // while it was still initializing, so the "init" event above never fired)
        if(gutenbergIsEnabled()){
            setTimeout(function (){

                const iframe = textarea.prev(".mce-tinymce").find("iframe");
                const iframeBody = iframe.contents().find("body");

                if(!iframeBody.attr("contenteditable")){
                    console.log("tinyMCE was not properly initialized, I am trying to restart it once again...");
                    restartEditor();
                }
            }, 4000);
        }

    } catch (e) {
        console.error(e);
        buttons.remove();
    }
};

/**
 * Destry TinyMCE instance
 * @param id
 */
export const destroyTinyMCE = (id) => {
    try {
        if(typeof tinyMCE === 'undefined'){
            console.error("tinymce is not defined. Include it here");
            return;
        }

        tinyMCE.execCommand('mceRemoveEditor', false, id);
    } catch (e) {
        console.error(e);
    }
};

/**
 * Init editor fields
 *
 * @param idSelector
 * @param wrapper
 */
export function initEditorFields(idSelector = null, wrapper = null) {

    let selector = `${wrapper ? wrapper : ""} textarea.acpt-wp-editor`;
    if(idSelector){
        selector = `${wrapper ? wrapper : ""} #${idSelector}`;
    }

    const editorFields = $$(selector);

    if(editorFields && editorFields.length > 0){
        editorFields.each(function(i, editorField) {
            initTinyMCE(editorField.id, editorField.getAttribute("rows"), editorField.dataset.toolbar);
        });
    }
}