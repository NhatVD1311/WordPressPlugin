
export function init_admin_cct() {
    const $ = jQuery;

    // ── Shared helpers ────────────────────────────────────────────────────────

    function destroySelectize($el) {
        if ($el[0] && $el[0].selectize) {
            $el[0].selectize.destroy();
        }
    }

    function showLoader($row) {
        $row.find('.acpt-location-value-loader').remove();
        $('<div class="acpt-location-value-loader"><div class="acpt-location-value-loader-bar"></div></div>')
            .insertAfter($row.find('.acpt-location-value-select'));
    }

    function removeLoader($row) {
        $row.find('.acpt-location-value-loader').remove();
    }

    function getTable() {
        const params = new URLSearchParams(window.location.search);
        return (params.get('page') || '').replace('acpt-table-', '');
    }

    function getRecordId() {
        return new URLSearchParams(window.location.search).get('record_id') ?? null;
    }

    /**
     * Populate and Selectize an entity select after an AJAX response.
     * Restores the pre-selected value via data-preselected on the select element.
     */
    function populateEntitySelect($select, items) {
        destroySelectize($select);
        $select.empty();

        // data-preselected is a JSON array of strings set by PHP
        let preselected = [];
        try {
            const raw = $select.data('preselected');
            preselected = Array.isArray(raw) ? raw : JSON.parse(raw || '[]');
        } catch (e) {
            preselected = [];
        }
        preselected = preselected.map(String).filter(Boolean);

        if (Array.isArray(items)) {
            items.forEach(function(item) {
                $select.append($('<option>', { value: item.value, text: item.label }));
            });
        }

        $select.selectize({
            plugins:      ['remove_button'],
            maxItems:     1,
            placeholder:  '-- Select a value --',
            onInitialize: function() {
                const self = this;
                preselected.forEach(function(v) { self.addItem(v, true); });
            }
        });
        // Do NOT call $select.show() — Selectize creates its own widget and keeps the
        // raw <select> hidden. Calling show() would render it visibly alongside the widget.
    }

    // ── POST context ──────────────────────────────────────────────────────────

    function initPostContextRows() {
        $(document).off('change.acpt-post', '.acpt-location-post-type-select')
            .on('change.acpt-post', '.acpt-location-post-type-select', function() {
                const $row      = $(this).closest('.acpt-location-row');
                const $entity   = $row.find('.acpt-location-value-select');
                const postType  = $(this).val();

                destroySelectize($entity);
                removeLoader($row);

                if (!postType) {
                    $entity.hide();
                    return;
                }

                const table    = getTable();
                const recordId = getRecordId();
                if (!table) return;

                showLoader($row);

                $.ajax({
                    url:    ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'fetchPostTypePostsAction',
                        data:   JSON.stringify({
                            table,
                            recordId,
                            postType,
                            locationContext: $row.data('settings') || []
                        })
                    },
                    success: function(response) {
                        removeLoader($row);
                        populateEntitySelect($entity, response);
                    }
                });
            });

        // Edit mode: trigger for already-selected dimension
        $('.acpt-location-context-post .acpt-location-post-type-select').each(function() {
            if ($(this).val()) {
                $(this).trigger('change.acpt-post');
            }
        });
    }

    // ── TERM context ──────────────────────────────────────────────────────────

    function initTermContextRows() {
        $(document).off('change.acpt-term', '.acpt-location-taxonomy-select')
            .on('change.acpt-term', '.acpt-location-taxonomy-select', function() {
                const $row    = $(this).closest('.acpt-location-row');
                const $entity = $row.find('.acpt-location-value-select');
                const taxonomy = $(this).val();

                destroySelectize($entity);
                removeLoader($row);

                if (!taxonomy) {
                    $entity.hide();
                    return;
                }

                const table    = getTable();
                const recordId = getRecordId();
                if (!table) return;

                showLoader($row);

                $.ajax({
                    url:    ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'fetchTermsAction',
                        data:   JSON.stringify({
                            table,
                            recordId,
                            taxonomy,
                            format: 'short',
                            locationContext: $row.data('settings') || []
                        })
                    },
                    success: function(response) {
                        removeLoader($row);
                        populateEntitySelect($entity, response);
                    }
                });
            });

        $('.acpt-location-context-term .acpt-location-taxonomy-select').each(function() {
            if ($(this).val()) {
                $(this).trigger('change.acpt-term');
            }
        });
    }

    // ── COMMENT context ───────────────────────────────────────────────────────

    function initCommentContextRows() {
        $('.acpt-location-context-comment').each(function() {
            const $row    = $(this);
            const $entity = $row.find('.acpt-location-value-select');
            const table    = getTable();
            const recordId = getRecordId();
            if (!table) return;

            showLoader($row);

            $.ajax({
                url:    ajaxurl,
                method: 'POST',
                data: {
                    action: 'fetchCommentsAction',
                    data:   JSON.stringify({ table, recordId })
                },
                success: function(response) {
                    removeLoader($row);
                    populateEntitySelect($entity, response);
                }
            });
        });
    }

    // ── USER context ──────────────────────────────────────────────────────────

    function initUserContextRows() {
        $('.acpt-location-context-user').each(function() {
            const $row    = $(this);
            const $entity = $row.find('.acpt-location-value-select');
            const table    = getTable();
            const recordId = getRecordId();
            if (!table) return;

            const userIds = $entity.data('user-ids') || '';

            showLoader($row);

            $.ajax({
                url:    ajaxurl,
                method: 'POST',
                data: {
                    action: 'fetchUsersAction',
                    data:   JSON.stringify({ table, recordId, userIds })
                },
                success: function(response) {
                    removeLoader($row);
                    populateEntitySelect($entity, response);
                }
            });
        });
    }

    // ── MEDIA context ─────────────────────────────────────────────────────────

    function initMediaContextRows() {
        $(document).off('change.acpt-media', '.acpt-location-mime-type-select')
            .on('change.acpt-media', '.acpt-location-mime-type-select', function() {
                const $row    = $(this).closest('.acpt-location-row');
                const $entity = $row.find('.acpt-location-value-select');
                const mimeType = $(this).val();

                destroySelectize($entity);
                removeLoader($row);

                if (!mimeType) {
                    $entity.hide();
                    return;
                }

                const table    = getTable();
                const recordId = getRecordId();
                if (!table) return;

                showLoader($row);

                $.ajax({
                    url:    ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'fetchAttachmentsAction',
                        data:   JSON.stringify({ table, recordId, mimeType })
                    },
                    success: function(response) {
                        removeLoader($row);
                        populateEntitySelect($entity, response);
                    }
                });
            });

        $('.acpt-location-context-media .acpt-location-mime-type-select').each(function() {
            if ($(this).val()) {
                $(this).trigger('change.acpt-media');
            }
        });
    }

    // ── PAGE context (static — no AJAX needed) ────────────────────────────────
    // The option page select is fully PHP-rendered with static options.
    // No JS handler required.

    // ── Boot ──────────────────────────────────────────────────────────────────

    initPostContextRows();
    initTermContextRows();
    initCommentContextRows();
    initUserContextRows();
    initMediaContextRows();
}
