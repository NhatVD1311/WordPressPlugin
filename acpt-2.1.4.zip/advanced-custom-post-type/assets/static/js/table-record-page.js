(function($) {
    'use strict';

    $(function() {
        // Initialize tom-select on the location multi-select
        var locationSelect = document.getElementById('acpt-location-selector');
        if (locationSelect && typeof TomSelect === 'function') {
            new TomSelect(locationSelect, {
                plugins: ['remove_button'],
                maxItems: null,
            });
        }

        // Toggle export dropdown
        $('.acpt-export-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $menu = $(this).siblings('.acpt-export-menu');

            if($menu.length > 0){
                if ($menu.css('display') === 'none') {
                    $menu.hide();
                } else {
                    $menu.show();
                }
            }
        });

        // Close dropdown when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.acpt-export-dropdown').length) {
                $('.acpt-export-menu').hide();
            }
        });

        // Prevent dropdown from closing when clicking inside
        $('.acpt-export-menu').on('click', function(e) {
            e.stopPropagation();
        });

        // Function to update bulk actions button state
        function updateBulkActionsState() {
            var anyChecked = $('input[name="record_ids[]"]:checked').length > 0;
            $('#bulk-action-selector-top').prop('disabled', !anyChecked);
            $('#doaction').prop('disabled', !anyChecked);
        }

        // Select/deselect all checkboxes
        $('#cb-select-all-1').on('click', function() {
            var isChecked = $(this).prop('checked');
            $('input[name="record_ids[]"]').prop('checked', isChecked);
            updateBulkActionsState();
        });

        // If any checkbox is unchecked, uncheck the "select all" checkbox
        $('input[name="record_ids[]"]').on('click', function() {
            if (!$(this).prop('checked')) {
                $('#cb-select-all-1').prop('checked', false);
            } else {
                // Check if all are checked, if so check the "select all"
                var allChecked = true;
                $('input[name="record_ids[]"]').each(function() {
                    if (!$(this).prop('checked')) {
                        allChecked = false;
                        return false;
                    }
                });
                $('#cb-select-all-1').prop('checked', allChecked);
            }
            updateBulkActionsState();
        });

        // Initial state - disable bulk actions
        updateBulkActionsState();

        // Ensure the apply filters button also triggers the search/filter logic correctly
        // This is already covered by the #acpt-search-submit, #acpt-apply-filters listener below

        // Handle bulk action form submission
        $('#acpt-table-bulk-form').on('submit', function(e) {
            var action = $('#bulk-action-selector-top').val();
            var selectedIds = [];

            $('input[name="record_ids[]"]:checked').each(function() {
                selectedIds.push($(this).val());
            });

            if (action === '-1') {
                e.preventDefault();
                alert('Please select an action.');
                return false;
            }

            if (selectedIds.length === 0) {
                e.preventDefault();
                alert('Please select at least one record.');
                return false;
            }

            // Intercept "edit" — show bulk edit panel instead of submitting
            if (action === 'edit') {
                e.preventDefault();
                var $idsContainer = $('#acpt-bulk-edit-ids');
                $idsContainer.empty();
                selectedIds.forEach(function(id) {
                    $idsContainer.append(
                        $('<input>').attr({ type: 'hidden', name: 'record_ids[]', value: id })
                    );
                });
                $('#acpt-bulk-edit-count').text(selectedIds.length);
                var $panel = $('#acpt-bulk-edit-panel');
                $panel.slideDown();
                $panel[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
                return false;
            }

            // Confirm delete action
            if (action === 'delete') {
                if (!confirm('Are you sure you want to delete ' + selectedIds.length + ' record(s)?')) {
                    e.preventDefault();
                    return false;
                }
            }

            // Let the form submit normally, but rename the bulk action selector field to match what PHP expects
            $('#bulk-action-selector-top').attr('name', 'bulk_action');
        });

        // Cancel bulk edit
        $(document).on('click', '#acpt-bulk-edit-cancel', function() {
            $('#acpt-bulk-edit-panel').slideUp();
        });

        // ── Bulk Edit Location Selector ────────────────────────────────────────

        function destroyBulkTomSelect($el) {
            if ($el[0] && $el[0]._tomSelect) {
                $el[0]._tomSelect.destroy();
            }
        }

        function updateBulkLocationRowIndices() {
            $('#acpt-bulk-edit-location-container .acpt-bulk-location-row').each(function(index) {
                $(this).find('select').each(function() {
                    var name = $(this).attr('name');
                    if (name) {
                        $(this).attr('name', name.replace(/locations\[(\d+|__INDEX__)\]/, 'locations[' + index + ']'));
                    }
                });
            });
        }

        function handleBulkLocationRuleChange($row) {
            var $ruleSelect  = $row.find('.acpt-bulk-location-rule-selector');
            var $valueSelect = $row.find('.acpt-bulk-location-value-selector');
            var val          = $ruleSelect.val();

            destroyBulkTomSelect($valueSelect);
            $valueSelect.hide().prop('disabled', true).empty()
                .append($('<option>').val('').text('Select values'));

            if (!val) return;

            var parts     = val.split(':');
            var ruleInt   = parseInt(parts[0]);
            var ruleValue = parts.slice(1).join(':'); // handle values that contain ':'

            // Option pages encode their value in the rule key — no value select needed
            if (ruleInt === 4) return;

            var action = '', ajaxData = {};
            switch (ruleInt) {
                case 1:  // RULE_CUSTOM_POST_TYPE
                case 6:  // RULE_POST_ID
                case 9:  // RULE_PARENT_POST_ID
                case 10: // RULE_POST_CAT
                case 11: // RULE_POST_TAX
                case 12: // RULE_POST_TEMPLATE
                    action   = 'fetchPostTypePostsAction';
                    ajaxData = { postType: ruleValue };
                    break;
                case 2:  // RULE_TAXONOMY
                case 7:  // RULE_TERM_ID
                    action   = 'fetchTermsAction';
                    ajaxData = { taxonomy: ruleValue, format: 'short' };
                    break;
                case 3:  // RULE_USER
                    action   = 'fetchUsersAction';
                    ajaxData = {};
                    break;
                case 8:  // RULE_USER_ID
                    action   = 'fetchUsersAction';
                    ajaxData = { userIds: ruleValue };
                    break;
                case 5:  // RULE_POST_STATUS
                    action   = 'fetchPostStatusesAction';
                    ajaxData = {};
                    break;
                case 13: // RULE_MEDIA
                    action   = 'fetchAttachmentsAction';
                    ajaxData = { mimeType: ruleValue };
                    break;
                case 14: // RULE_COMMENT
                    action   = 'fetchCommentsAction';
                    ajaxData = {};
                    break;
            }

            if (!action) return;

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: { action: action, data: JSON.stringify(ajaxData) },
                success: function(response) {
                    $valueSelect.empty();
                    if (Array.isArray(response)) {
                        response.forEach(function(item) {
                            $valueSelect.append($('<option>').val(item.value).text(item.label));
                        });
                    }
                    $valueSelect.prop('disabled', false);
                    new TomSelect($valueSelect[0], {
                        plugins: ['remove_button'],
                        maxItems: null,
                        placeholder: '-- Select values --',
                    });
                }
            });
        }

        // Add location row to bulk edit panel
        $(document).on('click', '#acpt-bulk-edit-add-location-row', function() {
            var $container = $('#acpt-bulk-edit-location-container');
            var template   = document.getElementById('acpt-bulk-edit-location-row-template');
            if (!template) return;
            var index  = $container.find('.acpt-bulk-location-row').length;
            var $newRow = $(template.innerHTML.replace(/__INDEX__/g, index));
            $container.append($newRow);
            handleBulkLocationRuleChange($newRow);
        });

        // Remove location row from bulk edit panel
        $(document).on('click', '.acpt-bulk-remove-location', function() {
            var $row = $(this).closest('.acpt-bulk-location-row');
            destroyBulkTomSelect($row.find('.acpt-bulk-location-value-selector'));
            $row.remove();
            updateBulkLocationRowIndices();
        });

        // Handle rule change in bulk edit location selector
        $(document).on('change', '.acpt-bulk-location-rule-selector', function() {
            handleBulkLocationRuleChange($(this).closest('.acpt-bulk-location-row'));
        });

        var $filterPanel = $('#acpt-adv-panel');
        var $conditionsContainer = $('#acpt-filter-conditions');
        var conditionTemplate = $('#acpt-filter-condition-template').html();

        function updateLogicVisibility() {
            var $conditions = $conditionsContainer.find('.acpt-filter-condition');
            $conditions.each(function(index) {
                var $logicGroup = $(this).find('.acpt-logic-group');
                if (index < $conditions.length - 1) {
                    $logicGroup.show();
                } else {
                    $logicGroup.hide();
                }
            });
            
            // Update filter count
            var count = $conditions.length;
            if (count > 0) {
                $('#acpt-filter-count').text(count).show();
            } else {
                $('#acpt-filter-count').hide();
            }
        }

        function updateValue(el){

            if(el.length === 0){
                return;
            }

            const id = el.val();
            let valueTemplate;

            // check if template with id select-value-template-${id} and apply it
            const template = document.getElementById(`select-value-template-${id}`);

            if(template){
                valueTemplate = template.innerHTML;
            } else {
                // default
                valueTemplate = '<input type="text" class="acpt-f-val" placeholder="Value...">';
            }

            el.closest('.acpt-filter-condition').find('.acpt-f-val').replaceWith(valueTemplate);
        }

        function updateOperator(el) {
            if (el.length === 0) return;

            var dataType = el.find('option:selected').attr('data-type');
            var $opSelect = el.closest('.acpt-filter-condition').find('.acpt-f-op');

            // Snapshot original options on first call so we can restore them later
            if (!$opSelect.data('original-html')) {
                $opSelect.data('original-html', $opSelect.html());
            }

            var originalHtml = $opSelect.data('original-html');

            // Columns only support equality matching
            const columnsOnlySupportEquality = ['location', 'Toggle'];

            if (columnsOnlySupportEquality.includes(dataType)) {
                var equalsHtml = $('<select>').html(originalHtml).find('option[value="equals"]').prop('outerHTML')
                    || '<option value="equals">equals</option>';
                $opSelect.html(equalsHtml).val('equals');
            } else {
                $opSelect.html(originalHtml);
            }
        }

        // Initial state - populate filters from URL if present
        (function() {
            var url = new URL(window.location.href);
            var filtersJson = url.searchParams.get('filters');
            if (filtersJson) {
                try {
                    var filters = JSON.parse(filtersJson);
                    if (Array.isArray(filters) && filters.length > 0) {
                        $conditionsContainer.empty(); // Clear any initial/placeholder condition
                        filters.forEach(function(f) {
                            var $newCondition = $(conditionTemplate);
                            $newCondition.find('.acpt-f-col').val(f.column);
                            $conditionsContainer.append($newCondition);
                            var $col = $newCondition.find('.acpt-f-col');
                            updateOperator($col);
                            $newCondition.find('.acpt-f-op').val(f.operator);
                            $newCondition.find('.acpt-f-logic').val(f.logic);
                            updateValue($col);
                            var $restoredVal = $newCondition.find('.acpt-f-val');
                            if ($restoredVal.is(':checkbox')) {
                                $restoredVal.prop('checked', f.value === '1');
                            } else {
                                $restoredVal.val(f.value);
                            }
                        });
                        updateLogicVisibility();
                        $filterPanel.show();
                    }
                } catch (e) {
                    // Invalid JSON, ignore
                }
            }
        })();

        function addCondition() {
            var $newCondition = $(conditionTemplate);
            $conditionsContainer.append($newCondition);
            updateLogicVisibility();
        }

        // Toggle filter panel
        $('#acpt-adv-toggle').on('click', function() {
            $filterPanel.slideToggle();
            if ($conditionsContainer.find('.acpt-filter-condition').length === 0) {
                addCondition();
            }
        });

        // Close panel
        $('#acpt-close-advanced').on('click', function() {
            $filterPanel.slideUp();
        });

        // Add condition button
        $('#acpt-add-condition').on('click', function() {
            addCondition();
        });

        // Remove condition
        $conditionsContainer.on('click', '.acpt-remove-condition', function() {
            $(this).closest('.acpt-filter-condition').remove();
            updateLogicVisibility();
        });

        // Search submit (placeholder for actual search logic)
        $('#acpt-search-submit, #acpt-apply-filters').on('click', function() {
            var searchQuery = $('#acpt-search-input').val();
            var filters = [];
            
            $conditionsContainer.find('.acpt-filter-condition').each(function() {
                var col = $(this).find('.acpt-f-col').val();
                var op = $(this).find('.acpt-f-op').val();
                var $valEl = $(this).find('.acpt-f-val');
                var val = $valEl.is(':checkbox') ? ($valEl.is(':checked') ? '1' : '0') : $valEl.val();
                var logic = $(this).find('.acpt-f-logic').val();
                
                if (col) {
                    filters.push({
                        column: col,
                        operator: op,
                        value: val,
                        logic: logic
                    });
                }
            });

            var url = new URL(window.location.href);
            if (searchQuery) {
                url.searchParams.set('s', searchQuery);
            } else {
                url.searchParams.delete('s');
            }

            if (filters.length > 0) {
                url.searchParams.set('filters', JSON.stringify(filters));
            } else {
                url.searchParams.delete('filters');
            }

            // Reset paged parameter when searching
            url.searchParams.delete('paged');

            window.location.href = url.toString();
        });

        // Reset
        $('#acpt-search-reset').on('click', function(e) {
            e.preventDefault();
            var url = new URL(window.location.href);
            url.searchParams.delete('s');
            url.searchParams.delete('filters');
            url.searchParams.delete('paged');
            window.location.href = url.toString();
        });

        // Update logic visibility on change
        $conditionsContainer.on('change', '.acpt-f-col, .acpt-f-op, .acpt-f-val, .acpt-f-logic', function() {
            updateLogicVisibility();
        });

        // Update operator and value input when the column selection changes
        $conditionsContainer.on('change', '.acpt-f-col', function() {
            updateOperator($(this));
            updateValue($(this));
        });
    });

})(jQuery);
