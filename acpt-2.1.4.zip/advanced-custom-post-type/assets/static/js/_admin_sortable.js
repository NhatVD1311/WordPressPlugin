import {destroyTinyMCE, initTinyMCE} from "./_admin_editor.js";

/**
 * Sortable functions
 * @see https://github.com/lukasoppermann/html5sortable
 */

var $ = jQuery.noConflict();

/**
 * After a repeater sort, walk every sortable-li in its new visual order
 * and rewrite the field-index that appears in input/select/textarea names
 * and in the data-conditional-rules-field-index attribute.
 *
 * Name pattern: …[fieldName][INDEX][value]  →  the INDEX must match the
 * new position of the parent sortable-li inside the list.
 *
 * @param {string} listElementId  – the id of the <ul>/<table> container
 */
const reindexRepeaterFields = (listElementId) => {
    const list = document.getElementById(listElementId);
    if (!list) return;

    const items = list.querySelectorAll(':scope > .sortable-li');

    items.forEach((item, newIndex) => {
        // Every form control whose name carries a numeric index
        const controls = item.querySelectorAll('input[name], select[name], textarea[name]');

        controls.forEach((control) => {
            const oldName = control.getAttribute('name');
            if (!oldName) return;

            // Pattern: prefix[fieldName][OLD_INDEX][value]  →  prefix[fieldName][NEW_INDEX][value]
            // We target the last occurrence of [digits] that is followed by [value] or [attachment_id] etc.
            const newName = oldName.replace(
                /^(.*\[[^\]]+\])\[(\d+)\]((?:\[.+\]|_\w+)?)$/,
                `$1[${newIndex}]$3`
            );

            if (newName !== oldName) {
                control.setAttribute('name', newName);
            }
        });

        // Also update all data-conditional-rules-field-index attributes inside this item
        const conditionalElements = item.querySelectorAll('[data-conditional-rules-field-index]');
        conditionalElements.forEach((el) => {
            el.setAttribute('data-conditional-rules-field-index', String(newIndex));
        });
    });
};

/**
 * After a Flexible-Content block-instance sort, walk every block in its new visual
 * order and rewrite the block index that appears in every descendant control name.
 *
 * A block-instance list carries the class `acpt_blocks_list` and its item names look
 * like `…[blocks][INDEX][blockName]…` (arbitrarily deep after the block name).
 * `reindexRepeaterFields` above is written for flat `field[INDEX][value]` names and
 * would rewrite the *inner sub-field* index instead of the block index, so a block
 * list must be reindexed with this function instead — otherwise the block's outer
 * hidden input (`…[blocks][INDEX][blockName]`) and its sub-fields end up pointing at
 * different indexes and the block's data is dropped on save (uneditable-post fatal).
 *
 * @param {string} listElementId – the id of the block-instance <ul>
 */
const reindexFlexibleBlocks = (listElementId) => {
    const list = document.getElementById(listElementId);
    if (!list) return;

    const items = list.querySelectorAll(':scope > .sortable-li');

    items.forEach((item, newIndex) => {
        const controls = item.querySelectorAll('input[name], select[name], textarea[name]');

        controls.forEach((control) => {
            const oldName = control.getAttribute('name');
            if (!oldName) return;

            // prefix[blocks][OLD_INDEX]rest  →  prefix[blocks][NEW_INDEX]rest
            // non-greedy prefix so the *first* [blocks] segment is targeted.
            const newName = oldName.replace(
                /^(.*?\[blocks\])\[(\d+)\](.*)$/,
                `$1[${newIndex}]$3`
            );

            if (newName !== oldName) {
                control.setAttribute('name', newName);
            }
        });

        const conditionalElements = item.querySelectorAll('[data-conditional-rules-field-index]');
        conditionalElements.forEach((el) => {
            el.setAttribute('data-conditional-rules-field-index', String(newIndex));
        });
    });
};

export const initSortable = () => {

    try {
        if(typeof sortable !== 'undefined'){

            // playlist
            if($('.playlist-preview').length){
                sortable('.playlist-preview', {
                    acceptFrom: '.playlist-preview',
                    forcePlaceholderSize: true,
                    items: '.audio',
                    hoverClass: 'hover',
                    copy: false
                });

                // sortable playlist items feature
                $('.playlist-preview').each(function(index) {

                    let i = index;

                    if(sortable('.playlist-preview')[index]){
                        sortable('.playlist-preview')[index].addEventListener('sortupdate', function(e) {

                            const sortedItems = e.detail.destination.items;
                            let sortedIndexArray = [];

                            sortedItems.map((sortedItem)=>{
                                sortedIndexArray.push($(sortedItem).data('index'));
                            });

                            const $imageWrapper = $(this);
                            const $target = $imageWrapper.data('target');
                            const $placeholder = $('#'+$target+'_copy');
                            let $placeholderIds;

                            if($('#'+$target+'_attachment_id').length > 0){
                                $placeholderIds = $('#'+$target+'_attachment_id');
                            } else {
                                $placeholderIds = $("#"+$target+"\\[attachment_id\\]\\["+i+"\\]");
                            }

                            const $inputWrapper = $placeholder.next( '.inputs-wrapper' );

                            // update input readonly && update input hidden
                            const $savedIds = $placeholderIds.val().split(',');
                            const $savedValues = $placeholder.val().split(',');
                            const $savedInputs = $inputWrapper.children('input');

                            let $sortedIds = [];
                            let $sortedValues = [];
                            let $sortedInputs = [];

                            sortedItems.map((sortedItem)=>{

                                const sortedIndex = $(sortedItem).data('index');
                                const audio = $(sortedItem).find("audio");
                                const audioURL = audio.attr('src');
                                const audioId = audio.data('id');

                                $sortedIds.push(audioId);
                                $sortedValues.push(audioURL);
                                $savedInputs.each(function () {
                                    if($(this).data('index') === sortedIndex){
                                        $sortedInputs.push($(this));
                                    }
                                });
                            });

                            $placeholderIds.val($sortedIds.join(','));
                            $placeholder.val($sortedValues.join(','));

                            if($placeholder.length > 0){
                                $placeholder[0].dispatchEvent(new Event("change")); // dispatch change Event for ACPTConditionalRules
                            }

                            $inputWrapper.html($sortedInputs);
                        });
                    }
                });

                sortable('.playlist-preview', 'reload');
            }

            // video gallery
            if($('.video-gallery-preview').length){

                sortable('.video-gallery-preview', {
                    acceptFrom: '.video-gallery-preview',
                    forcePlaceholderSize: true,
                    items: '.image',
                    hoverClass: 'hover',
                    copy: false
                });

                // sortable video gallery items feature
                $('.video-gallery-preview').each(function(index) {

                    let i = index;

                    if(sortable('.video-gallery-preview')[index]){
                        sortable('.video-gallery-preview')[index].addEventListener('sortupdate', function(e) {

                            const sortedItems = e.detail.destination.items;
                            let sortedIndexArray = [];

                            const $videoWrapper = $(this);
                            const $target = $videoWrapper.data('target');
                            const $placeholder = $('#'+$target+'_copy');
                            let $placeholderIds;

                            if($('#'+$target+'_attachment_id').length > 0){
                                $placeholderIds = $('#'+$target+'_attachment_id');
                            } else {
                                $placeholderIds = $("#"+$target+"\\[attachment_id\\]\\["+i+"\\]");
                            }

                            const $inputWrapper = $placeholder.next( '.inputs-wrapper' );

                            const $savedIds = $placeholderIds.val().split(',');
                            const $savedValues = $placeholder.val().split(',');
                            const $savedInputs = $inputWrapper.children('input');

                            let $sortedIds = [];
                            let $sortedValues = [];
                            let $sortedInputs = [];

                            sortedItems.map((sortedItem)=>{

                                const sortedIndex = $(sortedItem).data('index');
                                const video = $(sortedItem).find("video source");
                                const videoURL = video.attr('src');
                                const videoId = $(sortedItem).find("video").data('id');

                                $sortedIds.push(videoId);
                                $sortedValues.push(videoURL);
                                $savedInputs.each(function () {
                                    if($(this).data('index') === sortedIndex){
                                        $sortedInputs.push($(this));
                                    }
                                });
                            });

                            $placeholderIds.val($sortedIds.join(','));
                            $placeholder.val($sortedValues.join(','));

                            if($placeholder.length > 0){
                                $placeholder[0].dispatchEvent(new Event("change")); // dispatch change Event for ACPTConditionalRules
                            }

                            $inputWrapper.html($sortedInputs);
                        });
                    }
                });

                sortable('.video-gallery-preview', 'reload');
            }

            // gallery
            if($('.gallery-preview').length){

                sortable('.gallery-preview', {
                    acceptFrom: '.gallery-preview',
                    forcePlaceholderSize: true,
                    items: '.image',
                    hoverClass: 'hover',
                    copy: false
                });

                // sortable gallery items feature
                $('.gallery-preview').each(function(index) {

                    if(sortable('.gallery-preview')[index]){
                        sortable('.gallery-preview')[index].addEventListener('sortupdate', function(e) {

                            const sortedItems = e.detail.destination.items;
                            let sortedIndexArray = [];

                            const $imageWrapper = $(this);
                            const $target = $imageWrapper.data('target');
                            const $placeholder = $('#'+$target+'_copy');
                            let $placeholderIds;

                            if($('#'+$target+'_attachment_id').length > 0){
                                $placeholderIds = $('#'+$target+'_attachment_id');
                            } else {
                                // use the field's own render-time index (baked into the DOM), not the
                                // page-wide DOM position of .gallery-preview elements — the latter drifts
                                // as soon as there's more than one gallery on the page or repeater rows
                                // are added/removed, and ends up targeting the wrong field's inputs
                                const parentIndex = $imageWrapper.data('parent-index');
                                $placeholderIds = $("#"+$target+"\\[attachment_id\\]\\["+parentIndex+"\\]");
                            }

                            if($placeholderIds.length === 0 || $placeholder.length === 0){
                                console.warn('ACPT: unable to resolve gallery inputs for reorder, skipping update', $target);
                                return;
                            }

                            const $inputWrapper = $placeholder.next( '.inputs-wrapper' );

                            // update input readonly && update input hidden
                            const $savedIds = $placeholderIds.val().split(',');
                            const $savedValues = $placeholder.val().split(',');
                            const $savedInputs = $inputWrapper.children('input');

                            let $sortedIds = [];
                            let $sortedValues = [];
                            let $sortedInputs = [];

                            sortedItems.map((sortedItem)=>{

                                const sortedIndex = $(sortedItem).data('index');
                                const img = $(sortedItem).find("img");
                                const imgURL = img.attr('src');
                                const imgId = img.data('id');

                                $sortedIds.push(imgId);
                                $sortedValues.push(imgURL);
                                $savedInputs.each(function () {
                                    if($(this).data('index') === sortedIndex){
                                        $sortedInputs.push($(this));
                                    }
                                });
                            });

                            $placeholderIds.val($sortedIds.join(','));
                            $placeholder.val($sortedValues.join(','));

                            if($placeholder.length > 0){
                                $placeholder[0].dispatchEvent(new Event("change")); // dispatch change Event for ACPTConditionalRules
                            }

                            $inputWrapper.html($sortedInputs);
                        });
                    }
                });

                sortable('.gallery-preview', 'reload');
            }

            // repeater fields
            if($('.acpt-sortable').length > 0){

                $('.acpt-sortable').each(function(index) {

                    const elementId = $(this).attr('id');
                    let id = elementId.replace("acpt-sortable-", "");
                    
                    // relational fields
                    if(elementId.includes("selected_items_")){
                        id = elementId.replace("selected_items_", "");
                    }

                    sortable(`#${elementId}`, {
                        acceptFrom: `#${elementId}`,
                        forcePlaceholderSize: true,
                        items: `.sortable-li-${id}`,
                        handle: '.handle',
                        hoverClass: 'hover',
                        copy: false
                    })[0].addEventListener('sortupdate', function(e) {
                        // A Flexible-Content block-instance list needs the block index
                        // rewritten, not the flat repeater-row index.
                        if($(this).hasClass('acpt_blocks_list')){
                            reindexFlexibleBlocks(elementId);
                        } else {
                            reindexRepeaterFields(elementId);
                        }
                        const evt = new CustomEvent("acpt_grouped_element_sorted", { detail: { 'elementId': elementId }});
                        document.dispatchEvent(evt);
                    });

                    sortable(`#${elementId}`, 'reload');

                    // handle tinyMCE fields
                    if(sortable(`#${elementId}`)[index]){
                        sortable(`#${elementId}`)[index].addEventListener('sortupdate', function(e) {
                            if(e.detail.item.id){
                                const editorField = $(`#${e.detail.item.id}`).find("textarea.acpt-wp-editor");

                                // a jQuery object is always truthy even with zero matches —
                                // guard on .length so a repeater row with no WYSIWYG child
                                // doesn't call (destroy|init)TinyMCE with an undefined id.
                                if(editorField.length){
                                    destroyTinyMCE(editorField.attr("id"));
                                    initTinyMCE(editorField.attr("id"), editorField.attr("rows"), editorField.data("toolbar"));
                                }
                            }
                        });
                    }
                });
            }

            // nested flexible fields
            if($('.acpt-nested-sortable').length > 0){

                $('.acpt-nested-sortable').each(function(index) {
                    const elementId = $(this).attr('id');
                    const id = elementId.replace("block-elements-", "");

                    sortable('#'+elementId, {
                        acceptFrom: '#'+elementId,
                        forcePlaceholderSize: true,
                        items: `.sortable-li-${id}`,
                        handle: '.handle',
                        hoverClass: 'hover',
                        copy: false
                    })[0].addEventListener('sortupdate', function(e) {
                        const evt = new Event("acpt_grouped_element_sorted");
                        document.dispatchEvent(evt);
                    });

                    sortable('#'+elementId, 'reload');

                    // handle tinyMCE fields
                    if(sortable(`#${elementId}`)[index]){
                        sortable(`#${elementId}`)[index].addEventListener('sortupdate', function(e) {
                            if(e.detail.item.id){
                                const editorField = $(`#${e.detail.item.id}`).find("textarea.acpt-wp-editor");

                                if(editorField.length){
                                    destroyTinyMCE(editorField.attr("id"));
                                    initTinyMCE(editorField.attr("id"), editorField.attr("rows"), editorField.data("toolbar"));
                                }
                            }
                        });
                    }
                });
            }
        }
    } catch (e) {
        console.error(e);
    }
};