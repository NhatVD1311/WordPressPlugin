
/**
 * ACPT Form Validator
 */
class ACPTFormValidator
{
    /**
     * Every listener this instance registered, so `destroy()` can unwind them.
     *
     * @type {Array<{target: EventTarget, type: string, handler: Function}>}
     */
    #listeners = [];

    /**
     *
     * @param action
     */
    constructor(action) {

        // `_admin_misc.js`'s initValidator() builds a brand-new validator on every
        // repeater row and every flexible block added (_admin_repeater.js:269,
        // _admin_flexible.js:201/455), on top of the one the inline PHP script already
        // created. Nothing used to tear the old ones down, so N added rows left N+1 live
        // instances: N+1 click handlers on the submit button, 2(N+1) listeners per field,
        // and the whole getErrors()/displayErrors() sweep running N+1 times per keystroke.
        // It was a correctness bug too -- each instance kept its own `errors` array, so
        // several partial views raced to set `button.disabled` and the last one won.
        if(ACPTFormValidator.activeInstance){
            ACPTFormValidator.activeInstance.destroy();
        }

        ACPTFormValidator.activeInstance = this;

        /**
         *
         * @return {[]}
         */
        function getElements() {

            let elements = [];
            const els = document.body.querySelectorAll('[data-acpt-validate]');

            for (var i = 0, max = els.length; i < max; i++) {
                if (els[i].offsetParent !== null){
                    elements.push(els[i]);
                }
            }

            return elements;
        }

        this.elements = getElements();
        this.errors = [];
        this.action = action;
        this.form = (this.elements.length > 0 && this.elements[0].form)  ? this.elements[0].form : null;

        // set button
        switch (this.action){
            case "save-option-page":
                this.button = document.getElementById('save-option-page');
                break;

            case "add-tax":
            case "save-user":
                this.button = document.getElementById('submit');
                break;

            case "edit-tax":
                this.button = document.querySelector('.button-primary');
                break;

            case "save-cpt":
                this.button = document.querySelector('.editor-post-publish-button');
                break;
        }

        // Collect *every* matching control rather than the first one. A multi-step form
        // renders one "next" button per step, so a single querySelector() guarded step 1
        // and let every later step submit values this validator had already rejected.
        this.buttons = this.button ? [this.button] : [];

        if(this.buttons.length === 0){
            this.buttons = Array.prototype.slice.call(document.body.querySelectorAll('[data-acpt-action="goToNextStep"]'));
        }

        if(this.buttons.length === 0){
            this.buttons = Array.prototype.slice.call(document.body.querySelectorAll('[data-acpt-submit]'));
        }

        this.button = (this.buttons.length > 0) ? this.buttons[0] : null;
    }

    /**
     * Register a listener and remember it for `destroy()`.
     *
     * @param target
     * @param type
     * @param handler
     */
    #addListener(target, type, handler)
    {
        target.addEventListener(type, handler);
        this.#listeners.push({target: target, type: type, handler: handler});
    }

    /**
     * Detach every listener this instance registered.
     */
    destroy()
    {
        this.#listeners.forEach(function(listener){
            listener.target.removeEventListener(listener.type, listener.handler);
        });

        this.#listeners = [];

        if(ACPTFormValidator.activeInstance === this){
            ACPTFormValidator.activeInstance = null;
        }
    }

    run()
    {
        this.elements.forEach((element) => {

            if(!this.form){
                this.#changeValueHandler(element);
            }

            const handler = (e) => {
                this.#changeValueHandler(e.target);
            };

            this.#addListener(element, "change", handler);
            this.#addListener(element, "keyup", handler);
        });

        this.#handleOnButtonClick();
    }

    /**
     *
     * @return {boolean}
     */
    #formIsValid()
    {
        return this.errors.filter((err) => err.errors.length > 0).length === 0;
    }

    #handleOnButtonClick()
    {
        this.buttons.forEach((button) => {
            this.#addListener(button, "click", (e) => {

                this.elements.forEach((element) => {
                    this.#changeValueHandler(element);
                });

                if(!this.#formIsValid()){
                    e.stopPropagation();
                    e.preventDefault();
                }
            });
        });
    }

    /**
     * True when a blank value should skip every format/length/comparison rule: the
     * field is NOT required and its value is the empty string. Mirrors
     * ValidationRulesChecker::isRequiredGate() on the server so the two layers agree
     * that leaving an optional field empty is valid regardless of the rules on it.
     * The is-required / is-blank / is-not-blank checks are deliberately NOT gated.
     *
     * @param {string} value
     * @param {boolean} isRequired
     * @return {boolean}
     */
    #isRequiredGate(value, isRequired)
    {
        return !isRequired && value === '';
    }

    #changeValueHandler(element)
    {
        const value = element.value;
        const id = element.id;

        /**
         *
         * @return {[]}
         */
        const getErrors = () => {

            const errors = [];

            // all possible rules
            const isRequired = element.required;
            const isRequiredMessage = element.getAttribute("data-acpt-validate-required");
            const isBlank = element.getAttribute("data-acpt-validate-blank");
            const isBlankMessage = element.getAttribute("data-acpt-validate-blank-message");
            const isNotBlank = element.getAttribute("data-acpt-validate-not-blank");
            const isNotBlankMessage = element.getAttribute("data-acpt-validate-not-blank-message");
            const isEquals = element.getAttribute("data-acpt-validate-equals");
            const isEqualsMessage = element.getAttribute("data-acpt-validate-equals-message");
            const isNotEquals = element.getAttribute("data-acpt-validate-not-equals");
            const isNotEqualsMessage = element.getAttribute("data-acpt-validate-not-equals-message");
            const gt = element.getAttribute("data-acpt-validate-gt");
            const gtMessage = element.getAttribute("data-acpt-validate-gt-message");
            const gte = element.getAttribute("data-acpt-validate-gte");
            const gteMessage = element.getAttribute("data-acpt-validate-gte-message");
            const lt = element.getAttribute("data-acpt-validate-lt");
            const ltMessage = element.getAttribute("data-acpt-validate-lt-message");
            const lte = element.getAttribute("data-acpt-validate-lte");
            const lteMessage = element.getAttribute("data-acpt-validate-lte-message");
            const max = element.getAttribute("data-acpt-validate-max");
            const maxMessage = element.getAttribute("data-acpt-validate-max-message");
            const min = element.getAttribute("data-acpt-validate-min");
            const minMessage = element.getAttribute("data-acpt-validate-min-message");
            const maxLength = element.getAttribute("data-acpt-validate-maxlength");
            const maxLengthMessage = element.getAttribute("data-acpt-validate-maxlength-message");
            const minLength = element.getAttribute("data-acpt-validate-minlength");
            const minLengthMessage = element.getAttribute("data-acpt-validate-minlength-message");
            const regex = element.getAttribute("data-acpt-validate-regex");
            const regexMessage = element.getAttribute("data-acpt-validate-regex-message");
            const minAttr = element.getAttribute('min');
            const maxAttr = element.getAttribute('max');
            const minLengthAttr = element.getAttribute('minlength');
            const maxLengthAttr = element.getAttribute('maxlength');

            // A blank optional field is valid against every format/length/comparison
            // rule below — only "required", "blank" and "not blank" still apply.
            const skipEmptyOptional = this.#isRequiredGate(value, isRequired);

            if(isRequired){
                if((element.type === "checkbox" && !element.checked) || value === ''){
                    errors.push(isRequiredMessage);
                }
            }

            if(isBlank){
                if(value !== ''){
                    errors.push(isBlankMessage);
                }
            }

            if(isNotBlank){
                if(value === ''){
                    errors.push(isNotBlankMessage);
                }
            }

            if(isEquals && !skipEmptyOptional){
                if(value !== isEquals){
                    errors.push(isEqualsMessage);
                }
            }

            if(isNotEquals && !skipEmptyOptional){
                if(value === isNotEquals){
                    errors.push(isNotEqualsMessage);
                }
            }

            // Each comparison below is the negation of the matching branch of
            // ValidationRulesChecker::validateAgainstSingleRule() (which returns
            // "valid when"), so the browser and the save path agree at the boundary:
            //   LOWER_THAN          valid when value <  x  => error when value >= x
            //   LOWER_THAN_EQUALS   valid when value <= x  => error when value >  x
            //   GREATER_THAN        valid when value >  x  => error when value <= x
            //   GREATER_THAN_EQUALS valid when value >= x  => error when value <  x
            // They used to be shifted by one in every case -- lt/lte and gt/gte were
            // each other's implementations -- so `>= 10` rejected exactly 10 (which the
            // server accepts) while `> 10` accepted exactly 10 (which it rejects).
            if(lt && !skipEmptyOptional){
                if(parseInt(value) >= parseInt(lt)){
                    errors.push(ltMessage);
                }
            }

            if(lte && !skipEmptyOptional){
                if(parseInt(value) > parseInt(lte)){
                    errors.push(lteMessage);
                }
            }

            if(gt && !skipEmptyOptional){
                if(parseInt(value) <= parseInt(gt)){
                    errors.push(gtMessage);
                }
            }

            if(gte && !skipEmptyOptional){
                if(parseInt(value) < parseInt(gte)){
                    errors.push(gteMessage);
                }
            }

            if(max && !skipEmptyOptional){
                if(parseInt(value) > parseInt(max)){
                    errors.push(maxMessage);
                }
            }

            if(min && !skipEmptyOptional){
                if(parseInt(value) < parseInt(min)){
                    errors.push(minMessage);
                }
            }

            // the native min/max attributes bound the value, not its length
            if(maxAttr && !skipEmptyOptional){
                if(parseInt(value) > parseInt(maxAttr)){
                    errors.push(`Max value ${maxAttr}`);
                }
            }

            if(minAttr && !skipEmptyOptional){
                if(parseInt(value) < parseInt(minAttr)){
                    errors.push(`Min value ${minAttr}`);
                }
            }

            // Count characters the way PHP's mb_strlen() does, not UTF-16 code units:
            // `'\u{1F600}\u{1F600}'.length` is 4 surrogate halves but 2 characters, so
            // plain `.length` rejected emoji input the server happily accepted.
            const valueLength = [...String(value)].length;

            if(maxLength && !skipEmptyOptional){
                if(valueLength > parseInt(maxLength)){
                    errors.push(maxLengthMessage);
                }
            }

            if(minLength && !skipEmptyOptional){
                if(valueLength < parseInt(minLength)){
                    errors.push(minLengthMessage);
                }
            }

            if(maxLengthAttr && !skipEmptyOptional){
                if(valueLength > parseInt(maxLengthAttr)){
                    errors.push(`Max length ${maxLengthAttr}`);
                }
            }

            if(minLengthAttr && !skipEmptyOptional){
                if(valueLength < parseInt(minLengthAttr)){
                    errors.push(`Min length ${minLengthAttr}`);
                }
            }

            if(regex && !skipEmptyOptional){
                // A rule is stored exactly as the author typed it, and PHP accepts both
                // forms: ValidationRulesChecker wraps a delimiter-less pattern in `/.../`
                // before preg_match(). `new RegExp('/^[a-z]+$/')` instead treats those
                // slashes as literal characters, so a PHP-style pattern matched nothing
                // and the field could never be filled in. Strip a delimiter pair (with
                // its flags) when one is present, and tolerate an unparseable pattern
                // rather than throwing out of this whole function -- PHP's @preg_match()
                // is equally forgiving, and a SyntaxError here meant no rule on the field
                // was recorded and the button state was never updated.
                const delimited = regex.match(/^\/(.*)\/([gimsuy]*)$/);

                try {
                    const re = delimited
                        ? new RegExp(delimited[1], delimited[2])
                        : new RegExp(regex);

                    if (!re.test(String(value))) {
                        errors.push(regexMessage);
                    }
                } catch (e) {
                    console.error(`ACPTFormValidator: skipping unparseable regex rule "${regex}"`, e);
                }
            }

            function onlyUnique(value, index, array) {
                return array.indexOf(value) === index;
            }

            return errors.filter(onlyUnique);
        };

        const errors = getErrors();

        // Key the record by something actually unique to this control. It used to key on
        // `element.id` alone, so every control rendered without an id shared the single
        // record `{id: ""}` and overwrote each other -- a valid field could mask an
        // invalid sibling and leave the submit button enabled. The element reference is
        // kept alongside so #displayErrors() no longer has to look it up by id (which
        // also could not work for the id-less case).
        const key = element.id || element.name || null;
        const errorIndex = (key === null)
            ? this.errors.findIndex(err => err.element === element)
            : this.errors.findIndex(err => err.key === key);

        const record = {
            key: key,
            id: id,
            element: element,
            errors: errors
        };

        if(errorIndex === -1){
            this.errors.push(record);
        } else {
            this.errors[errorIndex] = record;
        }

        // set the element validity -- only form controls implement the constraint
        // validation API, so a marker on a repeater <ul>/<tbody> would throw a TypeError
        // here and abort the rest of the run
        if(typeof element.setCustomValidity === "function"){
            element.setCustomValidity(errors.length > 0 ? errors[0] : "");
        }

        this.#displayErrors();
        this.#disableButton();
    }

    #displayErrors()
    {
        this.errors.forEach((error) => {

            const id = error.id;
            const errors = error.errors;
            const element = error.element;

            // an id is what ties a control to its server-rendered list; without one
            // there is nowhere to render, though the record above still counts towards
            // the button state
            if(!element || !id){
                return;
            }

            const errorListId = `acpt-error-list-${id}`;
            let errorsList = document.getElementById(errorListId);

            if(!errorsList){
                errorsList = document.createElement("ul");
                errorsList.id = errorListId;
                errorsList.classList.add("acpt-error-list");

                // Actually put it in the document. The list used to be built detached
                // and then dropped, so this only ever worked when PHP had pre-rendered a
                // container with a matching id (renderErrors(), Meta/Form AbstractField).
                // Wherever the ids diverge -- nested form fields, and every meta field
                // whose validated element has a derived id (_copy proxies, values_*,
                // per-option radio/checkbox) -- the messages were computed, the button
                // was disabled, and the user was never told why.
                element.insertAdjacentElement("afterend", errorsList);
            }

            errorsList.innerHTML = '';

            if(errors.length === 0){
                element.classList.remove("has-errors");

                return;
            }

            element.classList.add("has-errors");

            // getErrors() already de-duplicates via filter(onlyUnique). The extra guard
            // that used to sit here compared `err.id` on an error *string* (the arrow
            // parameter shadowed the outer one), so it matched on the second pass and
            // silently dropped every message after the first.
            errors.forEach((err) => {
                const errorLi = document.createElement("li");
                errorLi.textContent = err;
                errorsList.appendChild(errorLi);
            });
        });
    }

    #disableButton()
    {
        const isValid = this.#formIsValid();

        this.buttons.forEach((button) => {
            button.disabled = !isValid;
        });
    }
}
