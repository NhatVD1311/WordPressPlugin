import {useTranslation, wpAjaxRequest, debounce} from "./_admin_commons.js";
import {ACPTTabulator} from "./ACPTTabulator.js";
import {initSortable} from "./_admin_sortable.js";

var $ = jQuery.noConflict();

jQuery(document).ready(function($){

    // load the table after the translations are available
    document.addEventListener("fetchLanguages", (e) => {

        /**
         * Run the tabulator
         */
        function runTabulator(){

            // loop all acpt-tabulator elements
            $('.acpt-tabulator').each(function () {

                let savedTemplates = [];
                const $this = $(this);
                const id = $this.attr('id');
                const targetId = $this.data("target-id");

                if(!id){
                    return;
                }

                // `runTabulator()` runs again on every `acpt_grouped_element_added` /
                // `acpt_flexible_element_added` event (i.e. every repeater or flexible
                // row the editor adds), and this loop re-registers every handler below
                // for every element it sees. Without this guard an already-wired field
                // accumulates one extra copy of each handler per run — so a single
                // keystroke ends up firing N identical AJAX calls, one click imports N
                // times, and `flashMessage` stacks. Wire each field exactly once; newly
                // inserted `.acpt-tabulator` elements are still picked up on the next run.
                if($this.data("acptTabulatorInitialised") === true){
                    return;
                }

                $this.data("acptTabulatorInitialised", true);

                let input = $(`input[name='${id}']`);

                if(input.length === 0){
                    input = $(`input[name='${targetId}']`);
                }

                const modal = $(`#acpt-create-table-${id}`);
                const btnWrapper = $this.next('.btn-wrapper');
                const outcome = btnWrapper.next('.outcome');
                const btnModal = btnWrapper.find('.acpt-open-table-settings');
                const btnImportCSV = btnWrapper.find('.acpt-open-import-csv');
                const btnImportSheet = btnWrapper.find('.acpt-import-google-sheet');
                const btnImportTemplate = btnWrapper.find('.acpt-open-import-template');
                const btnSaveTemplate = `<a class="acpt-open-save-template button button-secondary" href="#acpt-save-template-${id}" rel="modal:open" >${useTranslation("Save as template")}</a>`;

                /**
                 * Destroy the active modal
                 */
                function destroyModal()
                {
                    $('.jquery-modal.blocker.current').remove();
                    $('body').css('overflow', 'auto');
                }

                /**
                 * Flash the message
                 *
                 * @param message
                 * @param level
                 */
                function flashMessage(message, level = 'success')
                {
                    let color = '#02c39a';

                    if(level === 'danger'){
                        color = '#b02828';
                    }

                    outcome.css("color", color);
                    outcome.css("marginTop", "10px");
                    outcome.text(useTranslation(message));

                    setTimeout(function(){
                        outcome.css("color", "#777");
                        outcome.css("marginTop", "0");
                        outcome.text("");
                    }, 5000);
                }

                // init tabulator
                const tabulator = new ACPTTabulator(id);

                const savedValue = input.val();

                // listen for table changes — registered BEFORE the initial
                // createTable() call below, so that on a fresh page reload the
                // synchronous acpt-tabulator-change event fired by that first
                // render is handled here and the button label is corrected to
                // "Edit table settings" instead of staying on "Create table".
                document.addEventListener("acpt-tabulator-change", function(e){
                    // `e.detail` is absent when the event is dispatched as a bare
                    // Event (or with no detail), and `json`/`id` may individually
                    // be missing — never dereference them unguarded.
                    const json = (e.detail && e.detail.json) ? e.detail.json : {};
                    const tableSelector = e.detail ? e.detail.id : undefined;

                    // One of these listeners exists per table field, and every event
                    // belongs to exactly one field (ACPTTabulator dispatches with its own
                    // selector as `id`) — so every other field's listener has to ignore
                    // it. It used to run the whole body regardless, meaning a change in
                    // one table rewrote every other table field's settings modal and
                    // button label, and re-ran ~20 id lookups per field per keystroke.
                    if(tableSelector !== id){
                        return;
                    }

                    // change modal values
                    if(json.data && json.data.length > 0){
                        modal.find("h3").text(useTranslation("Edit table settings"));
                        modal.find(".acpt-create-table").text(useTranslation("Edit"));

                        // a change event can legitimately carry partial settings
                        // (see ACPTTabulator#dispatchChangeEvent from the cell-input
                        // path), so every nested read has to tolerate a missing key
                        const settings = json.settings || {};
                        const border = settings.border || {};
                        const background = settings.background || {};

                        $(`#acpt-create-table-layout-${id}`).val(settings.layout);
                        $(`#acpt-create-table-alignment-${id}`).val(settings.alignment);
                        $(`#acpt-create-table-border-thickness-${id}`).val(border.thickness);
                        $(`#acpt-create-table-border-style-${id}`).val(border.style);
                        $(`#acpt-create-table-border-color-${id}`).val(border.color);
                        $(`#acpt-create-table-background-color-${id}`).val(background.color);
                        $(`#acpt-create-table-zebra-background-${id}`).val(background.zebra);
                        $(`#acpt-create-table-color-${id}`).val(settings.color);
                        $(`#acpt-create-table-css-${id}`).val(settings.css);
                        $(`#acpt-create-table-header-${id}`).prop( "checked", settings.header);
                        $(`#acpt-create-table-footer-${id}`).prop( "checked", settings.footer);
                        $(`#acpt-create-table-columns-${id}`).val(settings.columns);
                        $(`#acpt-create-table-rows-${id}`).val(settings.rows);

                        btnModal.text(useTranslation("Edit table settings"));

                        if(btnWrapper.find('.acpt-open-save-template').length === 0){
                            $(btnSaveTemplate).insertAfter(btnModal);
                        }

                    } else {
                        modal.find("h3").text(useTranslation("Create table"));
                        modal.find(".acpt-create-table").text(useTranslation("Create"));

                        $(`#acpt-create-table-layout-${id}`).val('horizontal');
                        $(`#acpt-create-table-alignment-${id}`).val('left');
                        $(`#acpt-create-table-border-thickness-${id}`).val(1);
                        $(`#acpt-create-table-border-style-${id}`).val('solid');
                        $(`#acpt-create-table-border-color-${id}`).val('#cccccc');
                        $(`#acpt-create-table-background-color-${id}`).val('#ffffff');
                        $(`#acpt-create-table-zebra-background-${id}`).val('#ffffff');
                        $(`#acpt-create-table-color-${id}`).val('#777777');
                        $(`#acpt-create-table-css-${id}`).val('');
                        $(`#acpt-create-table-header-${id}`).prop( "checked", true);
                        $(`#acpt-create-table-header-${id}`).show();
                        $(`label[for="acpt-create-table-header-${id}"]`).show();
                        $(`#acpt-create-table-footer-${id}`).prop( "checked", false);
                        $(`#acpt-create-table-columns-${id}`).val(2);
                        $(`#acpt-create-table-rows-${id}`).val(2);

                        btnModal.text(useTranslation("Create table"));
                        btnWrapper.find('.acpt-open-save-template').remove();
                    }

                    input.val(JSON.stringify(json));
                });

                // create table from saved values
                if(typeof savedValue === "string" && savedValue !== "" && savedValue !== "{}"){
                    try {
                        const json = JSON.parse(savedValue);
                        tabulator.createTable(json);
                    } catch (e) {
                        console.error(e);
                    }
                }

                // Import Google Sheets
                // scoped to this field's own trigger + outcome: the selector used to be
                // the bare `.acpt-import-google-sheet` / `.acpt-import-sheet-outcome`
                // class, so every field's handler bound to every field's button (O(n²))
                // and each click wiped every field's outcome message
                $('body').on("click", `.acpt-import-google-sheet[href="#acpt-import-sheet-${id}"]`, function(){
                    $(`#acpt-import-sheet-outcome-${id}`).html("");
                });

                $('body').on('keyup', `.acpt-import-sheet`, debounce((e) => {

                    const sheetId = e.target.value;
                    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/?key=${document.globals.google_sheets_key}`;

                    // This handler is delegated on `body` and `runTabulator()` registers
                    // one copy per table field, so every field's copy sees every field's
                    // keyup. It used to read the field id off `$(this)` — which, in an
                    // arrow function, is the `.acpt-tabulator` element of the *registering*
                    // field, not the input that was typed in — so with more than one table
                    // field on the page a keystroke in one filled in another one's modal
                    // and imported into another one's tabulator. Only the field that owns
                    // the typed input may act on the event. (`.acpt-import-sheet` is also on
                    // the modal's submit button, so an exact id match is required here.)
                    if($(e.target).attr("id") !== `acpt-import-sheet-id-${id}`){
                        return;
                    }

                    const outcome = $(`#acpt-import-sheet-outcome-${id}`);
                    const sheetSelector = $(`#acpt-import-sheet-sheet-${id}`);
                    const formatSelector = $(`#acpt-import-sheet-format-${id}`);
                    const submitButton = $(`#acpt-import-sheet-submit-${id}`);
                    const modal = $(`#acpt-import-sheet-${id}`);
                    const closeModalLink = modal.find(".close-modal");

                    const clearForm = () => {
                        sheetSelector.children().remove();
                        formatSelector.children().remove();
                        submitButton.attr("disabled", "disabled");
                    };

                    $.ajax({
                        type: 'GET',
                        url: sheetUrl,
                        success: function(data) {

                            // clear errors
                            outcome.html(``);

                            if(sheetSelector.length > 0){

                                // clear all fields
                                clearForm();

                                data.sheets.map((sheet)=>{
                                    sheetSelector.append($('<option>', {
                                        value: sheet.properties.title,
                                        text: sheet.properties.title
                                    }));
                                });

                                formatSelector.append($('<option>', {value: "FORMATTED_VALUE", text: "Formatted value"}));
                                formatSelector.append($('<option>', {value: "UNFORMATTED_VALUE", text: "Unformatted value"}));
                                formatSelector.append($('<option>', {value: "FORMULA", text: "Formula"}));

                                submitButton.removeAttr('disabled');
                                submitButton.on("click", function(){
                                    const sheetValuesUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetSelector.val()}?key=${document.globals.google_sheets_key}&valueRenderOption=${formatSelector.val()}`;

                                    $.ajax({
                                        type: 'GET',
                                        url: sheetValuesUrl,
                                        success: function(data) {
                                            try {
                                                tabulator.importData(data.values);
                                                $(`#acpt-import-sheet-id-${id}`).val("");
                                                outcome.html("");
                                                sheetSelector.children().remove();
                                                formatSelector.children().remove();
                                                submitButton.attr("disabled", "disabled");
                                                flashMessage("The sheet was successfully imported!");
                                                destroyModal();
                                            } catch (e){
                                                console.error(e);
                                                outcome.html(`<span class="error">${e.message}</span>`);
                                            }
                                        },
                                        error: function(xhr, status, error) {
                                            outcome.html(`<span class="error">Error while fetching sheet data</span>`);
                                            console.error(xhr);
                                        }
                                    });
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            const code = xhr.responseJSON.error && xhr.responseJSON.error.code ? xhr.responseJSON.error.code : 0;
                            const err = xhr.responseJSON.error && xhr.responseJSON.error.message ? xhr.responseJSON.error.message : "Unknown error";
                            outcome.html(`<span class="error">${err}</span>`);
                            clearForm();
                            console.error(xhr);
                        }
                    });
                }, 1000));

                // Import JSON
                $('body').on('click', `.acpt-open-import-json[href="#acpt-import-json-${id}"]`, function(){
                    $(`#acpt-import-json-${id}`).find(".acpt-import-json-outcome").html("");
                });

                $('body').on('change', `#acpt-import-json-button-${id}.acpt-import-json-file`, function(e){
                    e.preventDefault();

                    const file = e.target.files[0];

                    if(!file){
                        return;
                    }

                    const filename = file.name;
                    const extension = file.type;

                    if(extension !== "application/json"){
                        return;
                    }

                    const outcome = $(this).next(".acpt-import-json-outcome");
                    const closeModalLink = $(this).parent().next(".close-modal");

                    const reader = new FileReader();
                    reader.readAsText(file);

                    reader.addEventListener("load", () => {

                        outcome.html("");

                        try {
                            tabulator.importJSON(reader.result);
                            flashMessage(`${filename} was successfully imported!`);
                            destroyModal();
                        } catch (e) {
                            console.error(e);
                            outcome.html(`<span class="error">${e.message}</span>`);
                        }
                    });

                    $(this).val("");
                });

                // Import CSV
                $('body').on('click', `.acpt-open-import-csv[href="#acpt-import-csv-${id}"]`, function(){
                    $(`#acpt-import-csv-${id}`).find(".acpt-import-csv-outcome").html("");
                });

                $('body').on('change', `#acpt-import-csv-button-${id}.acpt-import-csv-file`, function(e){

                    e.preventDefault();

                    const file = e.target.files[0];

                    if(!file){
                        return;
                    }

                    const filename = file.name;
                    const extension = file.type;

                    if(extension !== "text/csv"){
                        return;
                    }

                    const outcome = $(this).next(".acpt-import-csv-outcome");
                    const closeModalLink = $(this).parent().next(".close-modal");

                    const reader = new FileReader();
                    reader.readAsText(file);

                    reader.addEventListener("load", () => {

                        outcome.html("");

                        try {
                            tabulator.importCSV(reader.result);
                            flashMessage(`${filename} was successfully imported!`);
                            destroyModal();
                        } catch (e) {
                            console.error(e);
                            outcome.html(`<span class="error">${e.message}</span>`);
                        }
                    });

                    $(this).val("");
                });

                // import template modal
                $('body').on('click', `.acpt-open-import-template[href="#acpt-import-template-${id}"]`, function(e){
                    wpAjaxRequest('fetchTableTemplatesAction', {})
                        .then((response) => {
                            return response.json();
                        })
                        .then((templates) => {

                            savedTemplates = templates;
                            const templateNameSelector = $(`#acpt-import-template-name-${id}`);

                            const templateElement = (template) => {
                                return `
                                    <li>
                                        <p class="label" title="${template.name}">
                                            ${template.name}
                                        </p>
                                        <span class="buttons">
                                            <a class="button button-secondary acpt-apply-template" id="acpt-apply-template-${tabulator.getId()}" data-target-id="${template.id}" title="${useTranslation("Apply")}" rel="modal:close" href="#">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="1.2rem" height="1.2rem" viewBox="0 0 24 24"><path fill="#007cba" d="M11 15h2V9h3l-4-5l-4 5h3z"/><path fill="#007cba" d="M20 18H4v-7H2v7c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2v-7h-2z"/></svg>
                                            </a>
                                            <a class="button button-danger acpt-delete-template" data-target-id="${template.id}" title="${useTranslation("Delete")}" rel="modal:close" href="#">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="1.2rem" height="1.2rem" viewBox="0 0 24 24"><path fill="#b02828" d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"/><path fill="#b02828" d="M9 10h2v8H9zm4 0h2v8h-2z"/></svg>
                                            </a>
                                        </span>
                                    </li>
                                `;
                            };

                            templateNameSelector
                                .find('li')
                                .remove()
                                .end()
                            ;

                            if(templates.length > 0){
                                templates.map((template) => {
                                    templateNameSelector.append($(templateElement(template)));
                                });
                            } else {
                                templateNameSelector.append($(`<li>${useTranslation("No templates found.")}</li>`));
                            }
                        });
                });

                // import template
                $('body').on('click', `#acpt-apply-template-${tabulator.getId()}`, function(e){

                    const selectedTemplateId = $(this).data("target-id");
                    const filterTemplate = savedTemplates.filter((template) => Number(template.id) === Number(selectedTemplateId));

                    if(filterTemplate.length === 1){
                        const selectedTemplate = filterTemplate[0];

                        try {
                            tabulator.createTable(selectedTemplate.json);
                            destroyModal();
                            flashMessage("The template was successfully imported!");
                        } catch (e){
                            console.error(e);
                            outcome.html(`<span class="error">${e.message}</span>`);
                        }

                    } else {
                        $(`#acpt-import-template-${id}`).find('.errors').css("marginBottom", "10px");
                        $(`#acpt-import-template-${id}`).find('.errors').text("There was an error during the import of the template");
                    }
                });

                // delete template
                $('body').on('click', `#acpt-import-template-name-${id} .acpt-delete-template`, function(e){

                    const selectedTemplateId = $(this).data("target-id");

                    wpAjaxRequest('deleteTableTemplateAction', {id: selectedTemplateId})
                        .then((response) => {
                            return response.json();
                        })
                        .then((res) => {
                            if(res.success){
                                destroyModal();
                                flashMessage("The template was successfully deleted!");
                            } else if(res.error) {
                                destroyModal();
                                flashMessage(res.error, 'danger');
                            }
                        })
                    ;
                });

                // save template
                $('body').on('keyup', `#acpt-save-template-name-${id}`, function(e){
                    if(e.target.value !== ''){
                        $(`#acpt-save-template-${id}`).find('.acpt-save-template-name').removeClass("disabled");
                    } else {
                        $(`#acpt-save-template-${id}`).find('.acpt-save-template-name').addClass("disabled");
                    }
                });

                $('body').on('click', `.acpt-save-template-name[data-target-id="${id}"]`, function(e){
                    e.preventDefault();

                    wpAjaxRequest('saveTableTemplate', {
                        name: $(`#acpt-save-template-name-${id}`).val(),
                        json: tabulator.json
                    })
                        .then((response) => {
                            return response.json();
                        })
                        .then((response) => {
                            if(response.success === true){
                                $(`#acpt-save-template-name-${id}`).val('');
                                $(`#acpt-save-template-${id}`).find('.acpt-save-template-name').addClass("disabled");
                                destroyModal();
                                flashMessage("The template was successfully saved!");
                            } else {
                                $(`#acpt-save-template-${id}`).find('.errors').css("marginBottom", "10px");
                                $(`#acpt-save-template-${id}`).find('.errors').text(response.error);
                                console.error(response.error);
                            }
                        });
                });

                // create project modal
                $('body').on('click', `#acpt-create-table-layout-${id}`, function(e){
                    if(e.target.value === 'horizontal'){
                        $(`#acpt-create-table-header-${id}`).prop( "checked", true);
                        $(`#acpt-create-table-header-${id}`).show();
                        $(`label[for="acpt-create-table-header-${id}"]`).show();
                    } else if(e.target.value === 'vertical'){
                        $(`#acpt-create-table-header-${id}`).prop( "checked", false);
                        $(`#acpt-create-table-header-${id}`).hide();
                        $(`label[for="acpt-create-table-header-${id}"]`).hide();
                    }
                });

                // clear table
                $('body').on('click', `.acpt-clear-table[data-target-id="${id}"]`, function(e){
                    e.preventDefault();
                    tabulator.destroyTable();
                });

                // create a new table or edit current settings
                $('body').on('click', `.acpt-create-table[data-target-id="${id}"]`, function(e){

                    e.preventDefault();

                    // form values
                    const layout = $(`#acpt-create-table-layout-${id}`).val();
                    const alignment = $(`#acpt-create-table-alignment-${id}`).val();
                    const borderThickness = $(`#acpt-create-table-border-thickness-${id}`).val();
                    const borderStyle = $(`#acpt-create-table-border-style-${id}`).val();
                    const borderColor = $(`#acpt-create-table-border-color-${id}`).val();
                    const backgroundColor = $(`#acpt-create-table-background-color-${id}`).val();
                    const zebraBackgroundColor = $(`#acpt-create-table-zebra-background-${id}`).val();
                    const color = $(`#acpt-create-table-color-${id}`).val();
                    const css = $(`#acpt-create-table-css-${id}`).val();
                    const header = $(`#acpt-create-table-header-${id}`).is(':checked');
                    const footer = $(`#acpt-create-table-footer-${id}`).is(':checked');
                    const columns = $(`#acpt-create-table-columns-${id}`).val();
                    const rows = $(`#acpt-create-table-rows-${id}`).val();

                    /**
                     * @return {[]}
                     */
                    const obtainData = () => {

                        const defaultValue = tabulator.defaultCellValue;
                        let index = 0;
                        let data = [];

                        /**
                         *
                         * @param i
                         * @param k
                         */
                        const cellItem = (i, k) => {
                            return (
                                tabulator.json.data &&
                                tabulator.json.data.length > 0 &&
                                tabulator.json.data[i] &&
                                tabulator.json.data[i][k]
                            ) ? tabulator.json.data[i][k] : {value: defaultValue, settings: {}};
                        };

                        // header
                        if(header){
                            for (let k = 0; k < Number(columns); k++) {
                                if(!data[index]){
                                    data[index] = [];
                                }

                                data[index].push(cellItem(index, k));
                            }

                            index++;
                        }

                        // body
                        for (let i = 0; i < Number(rows); i++) {
                            for (let k = 0; k < Number(columns); k++) {
                                if(!data[index]){
                                    data[index] = [];
                                }

                                data[index].push(cellItem(index, k));
                            }

                            index++;
                        }

                        // footer
                        if(footer){
                            for (let k = 0; k < Number(columns); k++) {
                                if(!data[index]){
                                    data[index] = [];
                                }

                                data[index].push(cellItem(index, k));
                            }

                            index++;
                        }

                        return data;
                    };

                    const json = {
                        settings: {
                            layout: layout,
                            css: css,
                            alignment: alignment,
                            border: {
                                thickness: borderThickness,
                                style: borderStyle,
                                color: borderColor
                            },
                            background: {
                                color: backgroundColor,
                                zebra: zebraBackgroundColor,
                            },
                            color: color,
                            header: header,
                            footer: footer,
                            columns: columns,
                            rows: rows,
                        },
                        data: obtainData()
                    };

                    tabulator.createTable(json);
                });

                // add row
                $('body').on('click', `#${id} .acpt-editable-table .add-row`, function(e){
                    e.preventDefault();
                    const $this = $(this);
                    const rowId = $this.data("row-id");

                    if(typeof rowId === 'number'){
                        tabulator.addRow(rowId);
                    }
                });

                // delete row
                $('body').on('click', `#${id} .acpt-editable-table .delete-row`, function(e){
                    e.preventDefault();
                    const $this = $(this);
                    const rowId = $this.data("row-id");

                    if(typeof rowId === 'number'){
                        tabulator.deleteRow(rowId);
                    }
                });

                // add column
                $('body').on('click', `#${id} .acpt-editable-table .add-col`, function(e){
                    e.preventDefault();
                    const $this = $(this);
                    const colId = $this.data("col-id");

                    if(typeof colId === 'number'){
                        tabulator.addColumn(colId);
                    }
                });

                // delete column
                $('body').on('click', `#${id} .acpt-editable-table .delete-col`, function(e){
                    e.preventDefault();
                    const $this = $(this);
                    const colId = $this.data("col-id");

                    if(typeof colId === 'number'){
                        tabulator.deleteColumn(colId);
                    }
                });
            });
        }

        // run tabulator on init
        runTabulator();

        // run tabulator when a repeater element is added
        document.addEventListener("acpt_grouped_element_added", (e) => {
            runTabulator();
        });

        // run tabulator when a flexible element is added
        document.addEventListener("acpt_flexible_element_added", (e) => {
            runTabulator();
        });
    });
});
