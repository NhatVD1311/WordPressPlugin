window.addEventListener('load', function () {
    const carousels = document.querySelectorAll('.acpt-gallery.carousel');

    carousels.forEach(function(carousel) {

        const inputs = Array.from(carousel.querySelectorAll('input[type="radio"]'));
        const speed = parseInt(carousel.dataset.speed, 10) || 3000;
        let current = 0;
        let interval;

        function next() {
            current = (current + 1) % inputs.length;
            inputs[current].checked = true;
        }

        function start() {
            interval = setInterval(next, speed);
        }

        function stop() {
            clearInterval(interval);
        }

        carousel.addEventListener('mouseenter', stop);
        carousel.addEventListener('mouseleave', start);

        start();
    });

    // Initialize GLightbox if available and lightbox links exist
    if (typeof GLightbox !== 'undefined' && document.querySelectorAll('.glightbox').length > 0) {
        GLightbox({
            selector: '.glightbox',
            touchNavigation: true,
            loop: true,
            closeOnOutsideClick: true
        });
    }
});
