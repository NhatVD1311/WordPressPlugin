<?php

use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\CQRS\Command\AppendMetaFieldRowCommand;
use ACPT\Core\CQRS\Command\DeleteMetaFieldValueCommand;
use ACPT\Core\CQRS\Command\SaveMetaFieldValueCommand;
use ACPT\Core\Helper\Id;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Validators\ArgumentsArrayValidator;
use ACPT\Utils\Checker\ValidationRulesChecker;
use ACPT\Utils\Data\TableRecord;

if (!function_exists('save_acpt_meta_field_value')) {
    /**
     * Add or update a field value. This function replaces:
     *
     * - add_acpt_meta_field_value
     * - edit_acpt_meta_field_value
     *
     * @param array<string, mixed> $args
     *
     * @return bool
     */
    function save_acpt_meta_field_value(array $args = []): bool
    {
        try {
            // validate array
            $mandatory_keys = [
                'post_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'term_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'user_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'comment_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'wc_product_attribute' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'option_page' => [
                    'required' => false,
                    'type' => 'string',
                ],
                'box_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'field_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'forged_by' => [
                    'required' => false,
                    'type' => 'array',
                ],
                // `value` is intentionally NOT required: a value-less save is legitimate
                // (a Message field stores nothing; passing null clears the field). The
                // #1249 ArgumentsArrayValidator guard now rejects a `required` key sent as
                // explicit null, which would otherwise break those callers.
                'value' => [
                    'required' => false,
                    'type' => 'boolean|float|double|string|integer|array|object',
                ],
                'skip_validation' => [
                    'required' => false,
                    'type' => 'boolean',
                ],
            ];

            $validator = new ArgumentsArrayValidator();

            if (!$validator->validate($mandatory_keys, $args)) {
                return false;
            }

            $forged_by = $args['forged_by'] ?? $args['forgedBy'] ?? [];

            // a value read with get_acpt_field() can be saved back as is (#1371)
            if (array_key_exists('value', $args)) {
                $args['value'] = SaveMetaFieldValueCommand::objectsToIds($args['value']);
            }

            $meta_field_model = MetaRepository::getMetaFieldByName([
                'boxName' => $args['box_name'] ?? $args['boxName'],
                'fieldName' => $args['field_name'] ?? $args['fieldName'],
                'forgedBy' => $forged_by,
            ]);

            if ($meta_field_model === null) {
                return _acpt_save_cct_field_value($args);
            }

            if (isset($args['wc_product_attribute'])) {
                $meta_field_model->setIsAWooCommerceProductAttribute(true);
            }

            // Enforce the field's own validation rules, matching AbstractSaveMetaCommand
            // (classic edit screen) and HandleFormSubmissionCommand (forms). Without this,
            // a rule-violating value written through this programmatic path — the REST v1
            // field-value endpoints, the acpt/save-meta-field-value ability, the AJAX
            // MetaController — was silently persisted. Callers that legitimately restore
            // pre-existing data (the importer) pass skip_validation => true.
            $skip_validation = ($args['skip_validation'] ?? $args['skipValidation'] ?? false) === true;

            if (!$skip_validation && !empty($meta_field_model->getValidationRules())) {
                $checker = new ValidationRulesChecker(
                    $args['value'] ?? null,
                    $meta_field_model->getValidationRules(),
                    $meta_field_model->isTextual(),
                    $meta_field_model->isRequired()
                );
                $checker->validate();

                if (!$checker->isValid()) {
                    do_action('acpt/error', new \DomainException(
                        'Validation failed for field "' . ($args['field_name'] ?? $args['fieldName'] ?? '?') . '": '
                        . implode('; ', $checker->getErrors())
                    ));

                    return false;
                }
            }

            // ID fields carry an intrinsic format contract — AbstractSaveMetaCommand
            // (classic edit screen) rejects a value that doesn't match the configured
            // id_strategy. save_post's generateIdFieldValueIfMissing() self-heals a bad
            // value, but only for CUSTOM_POST_TYPE posts — a malformed ID written through
            // this path to a term / user / comment / option page is never corrected.
            // Enforce the same check here, honouring skip_validation like the rules block.
            if (!$skip_validation && $meta_field_model->getType() === MetaFieldModel::ID_TYPE) {
                $idStrategy = $meta_field_model->getAdvancedOption('id_strategy') ?? Id::UUID_V1;

                if (!Id::isValid($args['value'] ?? null, $idStrategy)) {
                    do_action('acpt/error', new \DomainException(
                        'ID format is not valid for field "'
                        . ($args['field_name'] ?? $args['fieldName'] ?? '?') . '"'
                    ));

                    return false;
                }
            }

            // save data
            try {
                $command = new SaveMetaFieldValueCommand($meta_field_model, $args);

                return $command->execute();
            } catch (\Throwable $exception) {
                // \Throwable, not just \Exception: a PHP Error (e.g. a value that
                // can't be converted to a string) used to escape as a fatal error (#1371)
                do_action('acpt/error', $exception);

                return false;
            }
        } catch (\Throwable $exception) {
            do_action('acpt/error', $exception);

            return false;
        }
    }
}

if (!function_exists('append_acpt_meta_field_value')) {
    /**
     * Append a new row to a REPEATER field's value, without having to re-send the
     * existing rows.
     *
     * @param array<string, mixed> $args
     *
     * @return bool
     */
    function append_acpt_meta_field_value(array $args = []): bool
    {
        try {
            // validate array
            $mandatory_keys = [
                'post_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'term_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'user_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'comment_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'wc_product_attribute' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'option_page' => [
                    'required' => false,
                    'type' => 'string',
                ],
                'box_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'field_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'forged_by' => [
                    'required' => false,
                    'type' => 'array',
                ],
                'value' => [
                    'required' => true,
                    'type' => 'array',
                ],
            ];

            $validator = new ArgumentsArrayValidator();

            if (!$validator->validate($mandatory_keys, $args)) {
                return false;
            }

            $forged_by = $args['forged_by'] ?? $args['forgedBy'] ?? [];

            $meta_field_model = MetaRepository::getMetaFieldByName([
                'boxName' => $args['box_name'] ?? $args['boxName'],
                'fieldName' => $args['field_name'] ?? $args['fieldName'],
                'forgedBy' => $forged_by,
            ]);

            if ($meta_field_model === null) {
                return _acpt_append_cct_field_value($args);
            }

            if ($meta_field_model->getType() !== MetaFieldModel::REPEATER_TYPE) {
                return false;
            }

            if (isset($args['wc_product_attribute'])) {
                $meta_field_model->setIsAWooCommerceProductAttribute(true);
            }

            // append data
            try {
                $command = new AppendMetaFieldRowCommand($meta_field_model, $args);

                return $command->execute();
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                return false;
            }
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_meta_field_value')) {
    /**
     * Delete a meta value
     *
     * @param array<string, mixed> $args
     *
     * @return bool
     */
    function delete_acpt_meta_field_value(array $args = []): bool
    {
        try {
            // validate array
            $mandatory_keys = [
                'post_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'term_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'user_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'comment_id' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'wc_product_attribute' => [
                    'required' => false,
                    'type' => 'integer',
                ],
                'option_page' => [
                    'required' => false,
                    'type' => 'string',
                ],
                'box_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'field_name' => [
                    'required' => true,
                    'type' => 'string',
                ],
                'forged_by' => [
                    'required' => false,
                    'type' => 'array',
                ],
            ];

            $validator = new ArgumentsArrayValidator();

            if (!$validator->validate($mandatory_keys, $args)) {
                return false;
            }

            $forged_by = $args['forged_by'] ?? $args['forgedBy'] ?? [];

            $meta_field_model = MetaRepository::getMetaFieldByName([
                'boxName' => $args['box_name'] ?? $args['boxName'],
                'fieldName' => $args['field_name'] ?? $args['fieldName'],
                'forgedBy' => $forged_by
            ]);

            if ($meta_field_model === null) {
                return _acpt_delete_cct_field_value($args);
            }

            if (isset($args['wc_product_attribute'])) {
                $meta_field_model->setIsAWooCommerceProductAttribute(true);
            }

            // delete data
            try {
                $command = new DeleteMetaFieldValueCommand($meta_field_model, $args);
                $command->execute();

                return true;
            } catch (\Exception $exception) {
                return false;
            }
        } catch (\Exception $exception) {
            return false;
        }
    }
}

// ── CCT helpers (internal — not part of the public API) ──────────────────────

/**
 * Builds a context array based on the provided arguments.
 *
 * @param array<string, mixed> $args An associative array of arguments that may include 'post_id', 'term_id',
 *                    'user_id', 'comment_id', or 'option_page', used to build the context.
 *
 * @return array<string, int|string> An associative array representing the context, where keys are mapped to
 *               specific identifiers (e.g., 'postId', 'termId', etc.). Returns an empty array
 *               if no known keys are provided.
 */
function _acpt_cct_build_context(array $args): array
{
    if (isset($args['post_id'])) {
        return ['postId'    => (int)$args['post_id']];
    }
    if (isset($args['term_id'])) {
        return ['termId'    => (int)$args['term_id']];
    }
    if (isset($args['user_id'])) {
        return ['userId'    => (int)$args['user_id']];
    }
    if (isset($args['comment_id'])) {
        return ['commentId' => (int)$args['comment_id']];
    }
    if (isset($args['option_page'])) {
        return ['page'      => $args['option_page']];
    }
    return [];
}

/**
 * @param array<string, mixed> $args
 */
function _acpt_save_cct_field_value(array $args): bool
{
    $boxName   = $args['box_name']   ?? $args['boxName']   ?? null;
    $fieldName = $args['field_name'] ?? $args['fieldName'] ?? null;
    $value     = $args['value'] ?? null;

    if (!$boxName || !$fieldName) {
        return false;
    }

    $tableModel = TableRepository::getByName($boxName);
    if ($tableModel === null) {
        return false;
    }

    $column = null;
    foreach ($tableModel->getColumns() as $col) {
        if ($col->getName() === $fieldName) {
            $column = $col;
            break;
        }
    }
    if ($column === null) {
        return false;
    }

    $context = _acpt_cct_build_context($args);
    if (empty($context)) {
        return false;
    }

    $resolvedContext = TableRecord::resolveContext($context);
    if (empty($resolvedContext)) {
        return false;
    }

    $row = TableRecord::fetchRow($tableModel, $resolvedContext['locationRule'], $resolvedContext['locationValue']);

    // Route through the same validated pipeline the REST API uses — sanitization,
    // JSON Schema validation, password hashing, date normalization, and bidirectional
    // relation sync all happen inside create()/update(). Passing the raw $value lets
    // that pipeline coerce it, so behavior matches the REST API exactly.
    $data = [$fieldName => $value];

    try {
        $controller = new TableRecordController();

        if ($row === null) {
            $controller->create($boxName, array_merge($data, [
                'locations' => [
                    [
                        'location_rule'  => $resolvedContext['locationRule'],
                        'location_value' => (string)$resolvedContext['locationValue'],
                    ],
                ],
            ]), null);
        } else {
            $controller->update($boxName, $row->id, $data, null);
        }

        // TableRecordController::evictCache() only clears the ACPT_DB cache tag; it does
        // not touch TableRecord::$rowCache (the request-scoped cache fetchRow() populates
        // above). Without this call a stale row could survive within the same request.
        TableRecord::invalidate($boxName);
        return true;
    } catch (\Exception $e) {
        do_action('acpt/error', $e);
        return false;
    }
}

/**
 * @param array<string, mixed> $args
 */
function _acpt_delete_cct_field_value(array $args): bool
{
    $boxName   = $args['box_name']   ?? $args['boxName']   ?? null;
    $fieldName = $args['field_name'] ?? $args['fieldName'] ?? null;

    if (!$boxName || !$fieldName) {
        return false;
    }

    $tableModel = TableRepository::getByName($boxName);
    if ($tableModel === null) {
        return false;
    }

    $context = _acpt_cct_build_context($args);
    if (empty($context)) {
        return false;
    }

    $resolvedContext = TableRecord::resolveContext($context);
    if (empty($resolvedContext)) {
        return false;
    }

    $row = TableRecord::fetchRow($tableModel, $resolvedContext['locationRule'], $resolvedContext['locationValue']);
    if ($row === null) {
        return true;
    }

    try {
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . $boxName,
            [$fieldName => null],
            ['id' => (int)$row->id]
        );

        TableRecord::invalidate($boxName);
        return true;
    } catch (\Exception $e) {
        do_action('acpt/error', $e);
        return false;
    }
}

/**
 * Appends a single row to a CCT Repeater column's JSON array value, without
 * resending the existing rows — the CCT counterpart of AppendMetaFieldRowCommand.
 *
 * A CCT repeater column stores its whole value as one JSON-encoded array of row
 * objects, so "append" fetches the current record, decodes that array, pushes
 * the new row, and writes the merged array back through the same validated
 * TableRecordController pipeline _acpt_save_cct_field_value() uses.
 *
 * @param array<string, mixed> $args
 */
function _acpt_append_cct_field_value(array $args): bool
{
    $boxName   = $args['box_name']   ?? $args['boxName']   ?? null;
    $fieldName = $args['field_name'] ?? $args['fieldName'] ?? null;
    $row       = $args['value']      ?? null;

    if (!$boxName || !$fieldName || !is_array($row)) {
        return false;
    }

    $tableModel = TableRepository::getByName($boxName);
    if ($tableModel === null) {
        return false;
    }

    $column = null;
    foreach ($tableModel->getColumns() as $col) {
        if ($col->getName() === $fieldName) {
            $column = $col;
            break;
        }
    }
    if ($column === null || $column->getUiField()->type !== MetaFieldModel::REPEATER_TYPE) {
        return false;
    }

    $context = _acpt_cct_build_context($args);
    if (empty($context)) {
        return false;
    }

    $resolvedContext = TableRecord::resolveContext($context);
    if (empty($resolvedContext)) {
        return false;
    }

    $existingRecord = TableRecord::fetchRow($tableModel, $resolvedContext['locationRule'], $resolvedContext['locationValue']);

    $existingValue = [];
    if ($existingRecord !== null) {
        $decoded = TableRecord::formatColumnValue($existingRecord->{$fieldName} ?? null);
        if (is_array($decoded)) {
            $existingValue = $decoded;
        }
    }

    $existingValue[] = $row;

    $data = [$fieldName => $existingValue];

    try {
        $controller = new TableRecordController();

        if ($existingRecord === null) {
            $controller->create($boxName, array_merge($data, [
                'locations' => [
                    [
                        'location_rule'  => $resolvedContext['locationRule'],
                        'location_value' => (string)$resolvedContext['locationValue'],
                    ],
                ],
            ]), null);
        } else {
            $controller->update($boxName, $existingRecord->id, $data, null);
        }

        TableRecord::invalidate($boxName);
        return true;
    } catch (\Exception $e) {
        do_action('acpt/error', $e);
        return false;
    }
}
