<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\Helper\Features;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;
use ACPT\Integrations\WPAllExport\Helper\WPAETableRecordXmlFormatter;

if (!function_exists('wpae_acpt_export_all_table_records')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_table_records({ID})]
     *
     * Exports every record of every CCT table attached to this post via location
     * rules (one record per host). wpae_acpt_export_all_fields() omits the `cct`
     * arg to FetchMetaGroupsQuery, so CCT tables are never flattened there —
     * this is the exclusive export path for CCT data.
     *
     * @param int $postId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_table_records(int $postId): ?string
    {
        if (!Features::hasCct()) {
            return null;
        }

        $postType = get_post_type($postId);

        if (empty($postType)) {
            return null;
        }

        $tables = [];

        foreach (TableGroupRepository::get(['belongsTo' => MetaTypes::CUSTOM_POST_TYPE, 'find' => $postType]) as $group) {
            foreach ($group->getTables() as $table) {
                $tables[] = $table;
            }
        }

        if (empty($tables)) {
            return null;
        }

        $xml = WPAETableRecordXmlFormatter::format($tables, MetaTypes::CUSTOM_POST_TYPE, $postId);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
