<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Query\FetchMetaGroupsQuery;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;

if (!function_exists('wpae_acpt_export_all_fields')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_fields({ID})]
     *
     * CCT tables are never included here — they're handled exclusively by
     * wpae_acpt_export_all_table_records() (one record per host).
     *
     * @param int $postId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_fields(int $postId): ?string
    {
        $postType = get_post_type($postId);

        if (empty($postType)) {
            return null;
        }

        $metaGroups = (new FetchMetaGroupsQuery([
            'belongsTo' => MetaTypes::CUSTOM_POST_TYPE,
            'find' => $postType,
        ]))->execute() ;

        $xml = WPAEXmlFormatter::formatMetadata($postId, MetaTypes::CUSTOM_POST_TYPE, $postType, $metaGroups);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
