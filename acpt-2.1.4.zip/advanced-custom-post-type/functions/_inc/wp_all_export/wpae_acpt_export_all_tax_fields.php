<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Query\FetchMetaGroupsQuery;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;

if (!function_exists('wpae_acpt_export_all_tax_fields')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_tax_fields({Term ID})]
     *
     * CCT tables are never included here — they're handled exclusively by
     * wpae_acpt_export_all_tax_table_records() (one record per host).
     *
     * @param int $termId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_tax_fields(int $termId): ?string
    {
        $taxonomyObject = get_term($termId);

        if ($taxonomyObject === null) {
            return null;
        }

        if ($taxonomyObject instanceof \WP_Error) {
            return null;
        }

        $taxonomy = $taxonomyObject->taxonomy;

        $metaGroups = (new FetchMetaGroupsQuery([
            'belongsTo' => MetaTypes::TAXONOMY,
            'find' => $taxonomy,
        ]))->execute() ;

        $xml = WPAEXmlFormatter::formatMetadata($termId, MetaTypes::TAXONOMY, $taxonomy, $metaGroups);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
