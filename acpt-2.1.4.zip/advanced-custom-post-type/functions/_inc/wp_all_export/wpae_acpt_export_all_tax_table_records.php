<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\Helper\Features;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;
use ACPT\Integrations\WPAllExport\Helper\WPAETableRecordXmlFormatter;

if (!function_exists('wpae_acpt_export_all_tax_table_records')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_tax_table_records({Term ID})]
     *
     * Exports every record of every CCT table attached to this term via location
     * rules (one record per host). wpae_acpt_export_all_tax_fields() omits the
     * `cct` arg to FetchMetaGroupsQuery, so CCT tables are never flattened
     * there — this is the exclusive export path for CCT data.
     *
     * @param int $termId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_tax_table_records(int $termId): ?string
    {
        if (!Features::hasCct()) {
            return null;
        }

        $taxonomyObject = get_term($termId);

        if ($taxonomyObject === null) {
            return null;
        }

        if ($taxonomyObject instanceof \WP_Error) {
            return null;
        }

        $taxonomy = $taxonomyObject->taxonomy;

        $tables = [];

        foreach (TableGroupRepository::get(['belongsTo' => MetaTypes::TAXONOMY, 'find' => $taxonomy]) as $group) {
            foreach ($group->getTables() as $table) {
                $tables[] = $table;
            }
        }

        if (empty($tables)) {
            return null;
        }

        $xml = WPAETableRecordXmlFormatter::format($tables, MetaTypes::TAXONOMY, $termId);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
