<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\Helper\Features;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;
use ACPT\Integrations\WPAllExport\Helper\WPAETableRecordXmlFormatter;

if (!function_exists('wpae_acpt_export_all_user_table_records')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_user_table_records({ID})]
     *
     * Exports every record of every CCT table attached to this user via location
     * rules (one record per host). wpae_acpt_export_all_user_fields() omits the
     * `cct` arg to FetchMetaGroupsQuery, so CCT tables are never flattened
     * there — this is the exclusive export path for CCT data.
     *
     * @param int $userId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_user_table_records(int $userId): ?string
    {
        if (!Features::hasCct()) {
            return null;
        }

        $tables = [];

        foreach (TableGroupRepository::get(['belongsTo' => MetaTypes::USER]) as $group) {
            foreach ($group->getTables() as $table) {
                $tables[] = $table;
            }
        }

        if (empty($tables)) {
            return null;
        }

        $xml = WPAETableRecordXmlFormatter::format($tables, MetaTypes::USER, $userId);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
