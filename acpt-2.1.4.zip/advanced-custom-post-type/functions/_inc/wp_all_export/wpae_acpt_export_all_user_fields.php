<?php

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Query\FetchMetaGroupsQuery;
use ACPT\Integrations\WPAllExport\Helper\WPAEXmlFormatter;

if (!function_exists('wpae_acpt_export_all_user_fields')) {
    /**
     * Usage in WP All Export:
     * [wpae_acpt_export_all_user_fields({ID})]
     *
     * CCT tables are never included here — they're handled exclusively by
     * wpae_acpt_export_all_user_table_records() (one record per host).
     *
     * @param int $userId
     *
     * @return string|null
     * @throws Exception
     */
    function wpae_acpt_export_all_user_fields(int $userId): ?string
    {
        $metaGroups = (new FetchMetaGroupsQuery([
            'belongsTo' => MetaTypes::USER,
        ]))->execute() ;

        if (empty($metaGroups)) {
            return null;
        }

        $xml = WPAEXmlFormatter::formatMetadata($userId, MetaTypes::USER, null, $metaGroups);

        return WPAEXmlFormatter::removeCDATA($xml);
    }
}
