<?php

use ACPT\Core\CQRS\Command\DeleteFormCommand;
use ACPT\Core\CQRS\Command\SaveFormCommand;
use ACPT\Core\CQRS\Command\SaveFormFieldsCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Repository\FormRepository;

if (!function_exists('_acpt_flatten_form_field')) {
    /**
     * Converts an existing FormFieldModel (and its children, recursively) into
     * the flat array shape SaveFormFieldsCommand::hydrateFormField() expects —
     * a DIFFERENT shape than FormFieldModel::jsonSerialize() produces (that one
     * uses `validationRules`/`parentTabIndex`/nested `children`; this command
     * reads `rules`/`parentTab` and expects children as flat sibling entries
     * linked by `parentId` => parent's `key`).
     *
     * @param FormFieldModel $field
     * @param array<int, array<string, mixed>> &$flat
     * @return void
     */
    function _acpt_flatten_form_field(FormFieldModel $field, array &$flat): void
    {
        $rules = [];
        foreach ($field->getValidationRules() as $rule) {
            $rules[] = [
                'id' => $rule->getId(),
                'condition' => $rule->getCondition(),
                'value' => $rule->getValue(),
                'message' => $rule->getMessage(),
            ];
        }

        $flat[] = [
            'id' => $field->getId(),
            'metaFieldId' => $field->getMetaField() ? $field->getMetaField()->getId() : null,
            'group' => $field->getGroup(),
            'key' => $field->getKey(),
            'name' => $field->getName(),
            'label' => $field->getLabel(),
            'type' => $field->getType(),
            'description' => $field->getDescription(),
            'isRequired' => $field->isRequired(),
            'extra' => $field->getExtra(),
            'settings' => $field->getSettings(),
            'rules' => $rules,
            'parentId' => $field->getParentId(),
            'parentTab' => $field->getParentTabIndex(),
        ];

        foreach ($field->getChildren() as $child) {
            _acpt_flatten_form_field($child, $flat);
        }
    }
}

if (!function_exists('save_acpt_form')) {
    /**
     * Saves an ACPT form based on the provided arguments.
     *
     * @param array<string, mixed> $args The associative array of arguments required for saving the form.
     *                    Must include 'name' and optionally 'id'. If 'id' is not provided,
     *                    it will attempt to fetch it using 'name'.
     * @return bool Returns true if the form is successfully saved; otherwise, returns false.
     */
    function save_acpt_form(array $args): bool
    {
        if (!isset($args['name'])) {
            return false;
        }

        try {
            if (!isset($args['id'])) {
                $form = FormRepository::get([
                    'formName' => $args['name']
                ]);

                if (count($form) === 1) {
                    $args['id'] = $form[0]->getId();
                }
            }

            $command = new SaveFormCommand($args);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_form')) {
    /**
     * Deletes an acceptance form based on the provided form name.
     *
     * @param string $formName The name of the form to be deleted.
     * @return bool Returns true if the form is successfully deleted, or false if an error occurs or the form is not found.
     */
    function delete_acpt_form(string $formName): bool
    {
        try {
            $form = FormRepository::get([
                'formName' => $formName
            ]);

            if (count($form) !== 1) {
                return false;
            }

            $command = new DeleteFormCommand($form[0]->getId());
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('get_acpt_form_object')) {
    /**
     * Retrieves a form object based on the provided form name.
     *
     * @param string $formName The name of the form to retrieve.
     * @return \stdClass|null Returns the form object as a standard object if exactly one form is found.
     *                     Returns null if no form is found, more than one form is found, or an exception occurs.
     */
    function get_acpt_form_object(string $formName): ?\stdClass
    {
        try {
            $form = FormRepository::get([
                'formName' => $formName,
            ]);

            if (count($form) !== 1) {
                return null;
            }

            return $form[0]->toStdObject();
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return null;
        }
    }
}

if (!function_exists('save_acpt_form_field')) {
    /**
     * Saves a form field to the specified form using the provided arguments.
     *
     * @param array<string, mixed> $args An associative array of field details. Required keys include:
     *                    - 'formName' or 'form_name': The name of the form.
     *                    - 'name': The name of the field.
     *                    Optional keys include:
     *                    - 'key': The key identifier for the field.
     *                    - 'metaFieldId': Meta field ID associated with the field.
     *                    - 'group': The group this field belongs to.
     *                    - 'label': Display label for the field.
     *                    - 'type': The type of the field.
     *                    - 'description': A description for the field.
     *                    - 'isRequired' or 'is_required': Whether the field is required (boolean).
     *                    - 'extra': Additional data or metadata for the field.
     *                    - 'settings': Configuration settings for the field.
     * @return bool Returns true if the field was successfully saved.
     *              Returns false if validation fails, the form is not found, or an exception occurs.
     */
    function save_acpt_form_field(array $args): bool
    {
        if (!isset($args['formName']) && !isset($args['form_name'])) {
            return false;
        }

        try {
            $form = FormRepository::get([
                'formName' => $args['formName'] ?? $args['form_name'],
            ]);

            if (count($form) !== 1) {
                return false;
            }

            $formModel = $form[0];
            $fieldModel = $formModel->getAField($args['name']);
            $newId = ($fieldModel !== null) ? $fieldModel->getId() : Uuid::v4();
            $isRequired = $args['isRequired'] ?? $args['is_required'];

            $fieldPayload = [
                'key' => @$args['key'],
                'id' => $newId,
                'metaFieldId' => @$args['metaFieldId'],
                'group' => @$args['group'],
                'name' => @$args['name'],
                'label' => @$args['label'],
                'type' => @$args['type'],
                'description' => @$args['description'],
                'isRequired' => (bool)$isRequired,
                'extra' => @$args['extra'],
                'settings' => @$args['settings'],
            ];

            // SaveFormFieldsCommand::execute() always resets and rebuilds the
            // form's ENTIRE field set from exactly what it's given — passing only
            // the one field being saved (as this used to do) silently deleted
            // every other field on the form. Build the full existing flat field
            // list first and splice the target field into it.
            $allFields = [];
            foreach ($formModel->getFields() as $existingField) {
                _acpt_flatten_form_field($existingField, $allFields);
            }

            $targetIndex = null;
            foreach ($allFields as $index => $existingFieldData) {
                if ($existingFieldData['name'] === $args['name']) {
                    $targetIndex = $index;
                    break;
                }
            }

            if ($targetIndex !== null) {
                $allFields[$targetIndex] = $fieldPayload;
            } else {
                $allFields[] = $fieldPayload;
            }

            $command = new SaveFormFieldsCommand($formModel->getId(), $allFields);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_form_field')) {
    /**
     * Deletes a specified field from a form based on the provided arguments.
     *
     * @param array<string ,mixed> $args An associative array containing the following keys:
     *                    - 'formName': string The name of the form from which the field will be deleted.
     *                    - 'fieldName': string The name of the field to delete.
     * @return bool Returns true if the field was successfully deleted.
     *              Returns false if the required arguments are missing, the form is not found,
     *              multiple forms are found, or an exception occurs.
     */
    function delete_acpt_form_field(array $args): bool
    {
        if (!isset($args['formName'])) {
            return false;
        }

        if (!isset($args['fieldName'])) {
            return false;
        }

        try {
            $form = FormRepository::get([
                'formName' => $args['formName'],
            ]);

            if (count($form) !== 1) {
                return false;
            }

            $formModel = $form[0];
            $formModel->removeAField($args['fieldName']);

            $data = $formModel->toArray();

            $command = new SaveFormCommand($data, true);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('get_acpt_form_field_object')) {
    /**
     * Retrieves a form field object based on the provided form and field names.
     *
     * @param array<string, mixed> $args An associative array containing the following keys:
     *                    - formName: string, the name of the form to retrieve (required).
     *                    - fieldName: string, the name of the field to retrieve within the form (required).
     * @return object|false|null Returns the form field object as a standard object if found.
     *                           Returns false if required arguments are missing.
     *                           Returns null if no form or field is found, or an exception occurs.
     */
    function get_acpt_form_field_object(array $args)
    {
        if (!isset($args['formName'])) {
            return false;
        }

        if (!isset($args['fieldName'])) {
            return false;
        }

        try {
            $form = FormRepository::get([
                'formName' => $args['formName'],
            ]);

            if (count($form) !== 1) {
                return null;
            }

            $formModel = $form[0];
            $fieldModel = $formModel->getAField($args['fieldName']);

            if ($fieldModel === null) {
                return null;
            }

            return $fieldModel->toStdObject();
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return null;
        }
    }
}
