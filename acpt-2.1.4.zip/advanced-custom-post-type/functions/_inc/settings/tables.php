<?php

use ACPT\Core\CQRS\Command\DeleteTableCommand;
use ACPT\Core\CQRS\Command\ExecuteTableSchemaAction;
use ACPT\Core\CQRS\Command\SaveTableCommand;
use ACPT\Core\Helper\UITypeToColumnMapper;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;

// ── Metadata functions ────────────────────────────────────────────────────────

if (! function_exists('save_acpt_table')) {
    /**
     * Create or update a custom table definition (metadata only — does not
     * touch the physical database table).
     *
     * Performs an upsert: if a table with the given name already exists its
     * id is reused, so calling this function twice with the same name is safe.
     *
     * Column definitions accept an optional `uiType` key. When present the
     * MySQL `type` and `length` are derived automatically from the UI type
     * mapping. Explicit `type` and `length` values always override the defaults.
     *
     * @param array<string, mixed> $args {
     *     @type string $name          Required. Machine name of the table.
     *     @type string $label         Human-readable label.
     *     @type string $idStrategy    ID strategy: none|auto_increment|UUID|ULID.
     *     @type array  $restApi       Allowed REST operations: read|create|update|delete.
     *     @type string $icon          Dashicon slug.
     *     @type int    $menuPosition  Admin menu position.
     *     @type string $capability    WordPress capability required to access the table.
     *     @type bool   $timestamps    Whether to add created_at/updated_at columns.
     *     @type bool   $softDelete    Whether to add a deleted_at column.
     *     @type array  $columns       Column definitions. Each entry may contain:
     *                                   - uiType (string): UI type — drives type/length automatically.
     *                                   - type   (string): Overrides the MySQL column type.
     *                                   - length (string): Overrides the MySQL column length.
     *     @type array  $indexes       Index definitions.
     *     @type array  $foreignKeys   Foreign key definitions.
     *     @type array  $location      Location rule definitions.
     * }
     * @return bool True on success, false on failure or unrecognised uiType.
     */
    function save_acpt_table(array $args): bool
    {
        if (! isset($args['name'])) {
            return false;
        }

        try {
            // No id supplied: resolve identity by name and merge onto the existing
            // table's full definition before anything else. TableRepository::save()
            // actively DELETEs any column/index/foreign-key row not present in the
            // submitted set (and every other top-level field defaults via `??` in
            // SaveTableCommand) — so a partial-update payload that omits `columns`
            // used to silently destroy every column definition (and their physical
            // data on the next sync-table call), not just the metadata.
            if (! isset($args['id'])) {
                $existing = TableRepository::get(['name' => $args['name']]);

                if (count($existing) === 1) {
                    $existingArgs = $existing[0]->toArray();

                    // getColumnValues() serializes as a flat scalar array (['a','b']),
                    // but SaveTableCommand expects the {value: ...} shape it was
                    // originally submitted in (array_column($column['columnValues'], 'value')).
                    foreach ($existingArgs['columns'] ?? [] as &$existingColumn) {
                        if (! empty($existingColumn['columnValues'])) {
                            $existingColumn['columnValues'] = array_map(
                                fn ($value) => ['value' => $value],
                                $existingColumn['columnValues']
                            );
                        }
                    }
                    unset($existingColumn);

                    $args = array_merge($existingArgs, $args);
                }
            }
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }

        if (!isset($args['options'])) {
            $args['options'] = [];
        }

        // Detect an already-present ENGINE option before injecting the default.
        // $args['options'] can be either a plain key=>value map (raw caller input)
        // or a numerically-indexed list of {key, value} objects (what the merge
        // above pulls in from an existing table's toArray()) — SaveTableCommand's
        // own options loop accepts both shapes, so check both here too. Without
        // this, `$args['options']["ENGINE"] = ...` only ever added a *new* entry
        // when options was already in the list shape, never overwriting the
        // existing one, producing two ENGINE options for the same table.
        $hasEngineOption = false;
        foreach ($args['options'] as $optionKey => $optionValue) {
            if ($optionKey === 'ENGINE') {
                $hasEngineOption = true;
                break;
            }
            if (is_array($optionValue) && ($optionValue['key'] ?? null) === 'ENGINE') {
                $hasEngineOption = true;
                break;
            }
        }

        // inject default engine if not set
        if (! isset($args['engine']) && ! $hasEngineOption) {
            $args['options']["ENGINE"] = "InnoDB";
        }

        // Resolve column types from uiType before passing to the command.
        if (! empty($args['columns']) && is_array($args['columns'])) {
            foreach ($args['columns'] as &$column) {
                if (isset($column['uiType'])) {
                    $resolved = UITypeToColumnMapper::resolve(
                        $column['uiType'],
                        $column  // explicit type/length in $column take precedence
                    );

                    if ($resolved === null) {
                        do_action('acpt/error', new \InvalidArgumentException(
                            "Unrecognised uiType `{$column['uiType']}` for column `{$column['name']}`."
                        ));

                        return false;
                    }

                    $column['type']   = $resolved['type'];
                    $column['length'] = $resolved['length'];

                    // Build the ui object expected by SaveTableCommand.
                    $column['ui'] = array_merge(
                        ['type' => $column['uiType'], 'options' => [], 'advancedOptions' => []],
                        $column['ui'] ?? []
                    );
                }
            }
            unset($column);
        }

        try {
            // Legacy shim: this function has always documented a flat `location`
            // key, but TableModel::getLocation() now requires a linked
            // TableGroupModel (the two-tier Group/Table architecture) — a table
            // saved with only `location` and no `tableGroupId` would silently
            // have that location dropped. Auto-create/update the implicit group
            // so the documented `location` arg keeps working. Delegates to
            // save_acpt_table_group() (rather than calling SaveTableGroupCommand
            // directly) so the implicit group also gets the merge-with-existing
            // fix — otherwise every call here would reset the group's
            // label/display/context/priority/sort to defaults.
            if (! empty($args['location']) && empty($args['tableGroupId'])) {
                $groupName = $args['name'] . '_group';

                save_acpt_table_group([
                    'name'     => $groupName,
                    'label'    => $args['label'] ?? $groupName,
                    'location' => $args['location'],
                ]);

                $group = TableGroupRepository::getByName($groupName);
                $args['tableGroupId'] = $group !== null ? $group->getId() : Uuid::v4();
            }

            $command = new SaveTableCommand($args);
            $command->execute();

            return true;
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }
    }
}

if (! function_exists('delete_acpt_table')) {
    /**
     * Delete a custom table definition (metadata only — does not drop the
     * physical database table).
     *
     * To also remove the physical table call drop_acpt_table() first.
     *
     * @param string $tableName Machine name of the table.
     * @return bool True on success, false when the table was not found or on error.
     */
    function delete_acpt_table(string $tableName): bool
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return false;
            }

            $command = new DeleteTableCommand($existing[0]->getId());
            $command->execute();

            return true;
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }
    }
}

if (! function_exists('get_acpt_table_object')) {
    /**
     * Retrieve a custom table definition as a plain object.
     *
     * @param string $tableName Machine name of the table.
     * @return \stdClass|null The table object, or null when not found.
     */
    function get_acpt_table_object(string $tableName): ?\stdClass
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return null;
            }

            return $existing[0]->toStdObject();
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return null;
        }
    }
}

// ── Schema / DDL functions ────────────────────────────────────────────────────

if (! function_exists('get_acpt_table_status')) {
    /**
     * Retrieve the synchronisation status of a custom table.
     *
     * Returns a plain object with two properties:
     *   - status (string): one of 'not_created', 'synced', 'not_synced'.
     *   - diff   (array):  SQL statements needed to align the physical table
     *                      with the stored definition, or the CREATE statement
     *                      when the table has not been created yet.
     *
     * @param string $tableName Machine name of the table.
     * @return \stdClass|null Status object, or null when the definition was not found.
     */
    function get_acpt_table_status(string $tableName): ?\stdClass
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return null;
            }

            return (object) $existing[0]->getTableStatus();
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return null;
        }
    }
}

if (! function_exists('sync_acpt_table')) {
    /**
     * Synchronise the physical database table with the stored definition.
     *
     * Handles both cases automatically:
     *   - 'not_created' → creates the table from scratch.
     *   - 'not_synced'  → applies the diff (ALTER / ADD / DROP statements).
     *   - 'synced'      → no-op, returns true immediately.
     *
     * @param string $tableName Machine name of the table.
     * @return bool True on success or when already in sync, false on error.
     */
    function sync_acpt_table(string $tableName): bool
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return false;
            }

            $tableModel = $existing[0];
            $status     = $tableModel->getTableStatus();

            if ($status['status'] === $tableModel::TABLE_STATUS_SYNCED) {
                return true;
            }

            $action = $status['status'] === $tableModel::TABLE_STATUS_NOT_CREATED
                ? 'create'
                : 'sync';

            $command = new ExecuteTableSchemaAction($tableModel->getId(), $action);
            $command->execute();

            return true;
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }
    }
}

if (! function_exists('create_acpt_table')) {
    /**
     * Explicitly create the physical database table from the stored definition.
     *
     * Prefer sync_acpt_table() in most cases — it handles both the
     * 'not_created' and 'not_synced' states automatically.
     *
     * @param string $tableName Machine name of the table.
     * @return bool True on success, false on error or when not found.
     */
    function create_acpt_table(string $tableName): bool
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return false;
            }

            $command = new ExecuteTableSchemaAction($existing[0]->getId(), 'create');
            $command->execute();

            return true;
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }
    }
}

if (! function_exists('drop_acpt_table')) {
    /**
     * Drop the physical database table.
     *
     * This does NOT remove the table definition from ACPT metadata — call
     * delete_acpt_table() afterwards if you want to remove the definition too.
     *
     * @param string $tableName Machine name of the table.
     * @return bool True on success, false on error or when not found.
     */
    function drop_acpt_table(string $tableName): bool
    {
        try {
            $existing = TableRepository::get(['name' => $tableName]);

            if (count($existing) !== 1) {
                return false;
            }

            $command = new ExecuteTableSchemaAction($existing[0]->getId(), 'drop');
            $command->execute();

            return true;
        } catch (\Exception $e) {
            do_action('acpt/error', $e);

            return false;
        }
    }
}
