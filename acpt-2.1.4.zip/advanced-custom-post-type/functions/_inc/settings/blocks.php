<?php

use ACPT\Core\CQRS\Command\DeleteBlockCommand;
use ACPT\Core\CQRS\Command\SaveBlockCommand;
use ACPT\Core\Repository\DynamicBlockRepository;

if (!function_exists('save_acpt_block')) {
    /**
     * Saves or updates an ACPT block based on the provided arguments.
     *
     * This method checks if the 'name' parameter is provided in the arguments and
     * retrieves the corresponding block's ID if not explicitly specified. It then
     * executes a command to save or update the block. In the event of an error,
     * it triggers an action and returns false.
     *
     * @param array<string ,mixed> $args An associative array of data for saving the block.
     *                    Must include:
     *                    - string 'name': The name of the block (required).
     *                    Optional:
     *                    - int 'id': The ID of the block to be updated.
     * @return bool Returns true if the block is successfully saved, false otherwise.
     */
    function save_acpt_block(array $args = []): bool
    {
        if (!isset($args['name'])) {
            return false;
        }

        try {
            if (!isset($args['id'])) {
                $block = DynamicBlockRepository::getByName($args['name']);

                // Merge onto the existing block's full state before delegating to
                // SaveBlockCommand — the command builds a brand-new model from
                // only the keys present in $data, with `keywords`/`postTypes`/
                // `supports` all defaulting to [] when omitted (not merely falsy),
                // and `controls` populated only `if(isset(...) and !empty(...))`.
                // A partial-update payload (e.g. just changing the `title`) used
                // to silently reset keywords/supports to empty and delete every
                // control the block had.
                if (!empty($block)) {
                    $args['id'] = $block->getId();
                    $args = array_merge($block->toArray(), $args);
                }
            }

            $command = new SaveBlockCommand($args);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_block')) {
    /**
     * Deletes a dynamic block by its name.
     *
     * @param string $blockName The name of the block to be deleted.
     * @return bool Returns true if the block is successfully deleted, false otherwise.
     */
    function delete_acpt_block(string $blockName): bool
    {
        try {
            $block = DynamicBlockRepository::getByName($blockName);

            if (empty($block)) {
                return false;
            }

            $command = new DeleteBlockCommand($block->getId());
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('get_acpt_block_object')) {
    /**
     * Retrieves a block object by its name from the DynamicBlockRepository.
     *
     * @param string $blockName The name of the block to retrieve.
     * @return object|false|null Returns the block object as a standard object if found,
     *                           false if the block is empty, or null in case of an exception.
     */
    function get_acpt_block_object(string $blockName)
    {
        try {
            $block = DynamicBlockRepository::getByName($blockName);

            if (empty($block)) {
                return false;
            }

            return $block->toStdObject();
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return null;
        }
    }
}
