<?php

use ACPT\Core\CQRS\Command\SaveOptionPageCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Repository\OptionPageRepository;

if (!function_exists('register_acpt_option_page')) {

    /**
     * Registers an option page for the ACPT feature.
     *
     * This method is used to create or update an option page using the provided arguments.
     * It ensures that the option page is properly saved and associated with a parent if specified.
     *
     * @param array<string, mixed> $args {
     *     An array of arguments to define the option page.
     *
     * @type string $menu_slug The unique slug for the menu.
     * @type string $menuSlug Alias for `menu_slug`.
     * @type string $page_title The title displayed on the page.
     * @type string $pageTitle Alias for `page_title`.
     * @type string $menu_title The title displayed in the menu.
     * @type string $menuTitle Alias for `menu_title`.
     * @type string $capability The capability required to access the page.
     * @type string $parent The parent menu slug for hierarchical organization.
     * @type int $position The position in the menu where the page should appear.
     * @type string $icon The icon for the menu (optional).
     * @type string $description The description of the page.
     * @type array $permissions List of additional permissions required (optional).
     * }
     *
     * @return bool True on successful registration, false on failure.
     */
    function register_acpt_option_page(array $args = []): bool
    {
        try {
            $parentId = null;
            $menuSlug = $args["menu_slug"] ?? $args["menuSlug"];
            $pageTitle = $args["page_title"] ?? $args["pageTitle"];
            $menuTitle = $args["menu_title"] ?? $args["menuTitle"];

            $existing = OptionPageRepository::exists($menuSlug) ? OptionPageRepository::getByMenuSlug($menuSlug) : null;
            $id = ($existing !== null) ? $existing->getId() : Uuid::v4();

            // Partial-update preservation. SaveOptionPageCommand builds a brand-new model
            // from only the keys it is handed — it does no read-then-merge of its own —
            // so a partial payload (the natural way to call the save-option-page ability
            // when you only mean to touch one field) used to silently reset icon /
            // description / parent to null. Backfill each omitted optional field from the
            // existing record first, matching save_acpt_table_group() / save_acpt_meta_group().
            // `permissions` is deliberately NOT backfilled: an omitted/empty permissions
            // array already leaves the stored acpt_permission rows untouched (SaveOptionPageCommand
            // only rebuilds them when the array is non-empty), and re-feeding them would
            // needlessly re-run SavePermissionCommand.
            if ($existing !== null) {
                if (!array_key_exists('icon', $args)) {
                    $args['icon'] = $existing->getIcon();
                }

                if (!array_key_exists('description', $args)) {
                    $args['description'] = $existing->getDescription();
                }
            }

            if (isset($args['parent'])) {
                $parentId = (OptionPageRepository::exists($args["parent"])) ? OptionPageRepository::getByMenuSlug($args["parent"])->getId() : null;

                if (!$parentId) {
                    return false;
                }
            } elseif ($existing !== null) {
                $parentId = $existing->getParentId();
            }

            $command = new SaveOptionPageCommand([
                'id' => $id,
                'parentId' => $parentId,
                'pageTitle' => @$pageTitle,
                'menuTitle' => @$menuTitle,
                'capability' => $args["capability"],
                'menuSlug' => @$menuSlug,
                'position' => $args["position"],
                'icon' => (isset($args["icon"]) ? $args["icon"] : null),
                'description' => $args["description"] ?? null,
                'children' => [],
                'permissions' => $args["permissions"] ?? [],
                'sort' => ($existing !== null ? $existing->getSort() : count(OptionPageRepository::getAllIds()) + 1)
            ]);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_option_page')) {

    /**
     * Deletes an ACPT (Advanced Custom Post Type) option page if it exists.
     *
     * @param string $page_slug The slug of the option page to delete.
     * @param bool $delete_options Optional. Whether to delete associated options. Defaults to false.
     * @return bool Returns true if the option page was successfully deleted, otherwise false.
     */
    function delete_acpt_option_page(string $page_slug, bool $delete_options = false): bool
    {
        if (!OptionPageRepository::exists($page_slug)) {
            return false;
        }

        try {
            $option_page = OptionPageRepository::getByMenuSlug($page_slug);
            OptionPageRepository::delete($option_page, $delete_options);

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}
