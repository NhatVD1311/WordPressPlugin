<?php

use ACPT\Core\CQRS\Command\SaveTableGroupCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Repository\TableGroupRepository;

if (!function_exists('save_acpt_table_group')) {

    /**
     * Registers a table group (location/visibility rules for a set of CCT tables).
     *
     * @param array<string, mixed> $args {
     *     An array of arguments to define the table group.
     *
     * @type string $id       Optional. Existing group id (upsert).
     * @type string $name     Required. Machine name.
     * @type string $label    Optional.
     * @type string $display  Optional. standard|accordion|verticalTabs|horizontalTabs.
     * @type string $context  Optional.
     * @type string $priority Optional.
     * @type int    $sort     Optional.
     * @type array  $location Optional. Array of raw location-rule arrays (rule/value/operator/logic).
     * @type array  $tableIds Optional. IDs of existing tables to attach to this group.
     * }
     *
     * @return bool True on successful registration, false on failure.
     */
    function save_acpt_table_group(array $args): bool
    {
        try {
            if (!isset($args['name'])) {
                return false;
            }

            if (!isset($args['id'])) {
                $existing = TableGroupRepository::getByName($args['name']);

                // Merge onto the existing group's full state before delegating to
                // SaveTableGroupCommand — the command builds a brand-new model from
                // only the keys present in $data (no read-then-merge of its own), so
                // a partial-update payload (e.g. just {name, priority}) used to
                // silently reset label/display/context/sort and wipe every location
                // rule. Built explicitly (not via arrayRepresentation()/toArray())
                // because both use mismatched key names/shapes against what
                // SaveTableGroupCommand actually reads ('location', not
                // 'locationRules'; flat 'tableIds' strings, not Table model objects).
                if ($existing !== null) {
                    $args['id'] = $existing->getId();

                    $existingArgs = [
                        'label'    => $existing->getLabel(),
                        'display'  => $existing->getDisplay(),
                        'context'  => $existing->getContext(),
                        'priority' => $existing->getPriority(),
                        'sort'     => $existing->getSort(),
                        'location' => array_map(
                            fn ($rule) => $rule->jsonSerialize(),
                            $existing->getLocationRules()
                        ),
                        'tableIds' => array_map(
                            fn ($table) => $table->getId(),
                            $existing->getTables()
                        ),
                    ];

                    $args = array_merge($existingArgs, $args);
                }
            }

            if (!isset($args['id'])) {
                $args['id'] = Uuid::v4();
            }

            $command = new SaveTableGroupCommand($args);
            $command->execute();

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('delete_acpt_table_group')) {

    /**
     * Deletes a table group by its machine name.
     *
     * @param string $name The machine name of the table group.
     * @return bool True on successful deletion, otherwise false.
     */
    function delete_acpt_table_group(string $name): bool
    {
        try {
            $group = TableGroupRepository::getByName($name);

            if ($group === null) {
                return false;
            }

            TableGroupRepository::delete($group->getId());

            return true;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }
}

if (!function_exists('get_acpt_table_group_object')) {

    /**
     * Returns a table group as a plain object, by its machine name.
     *
     * @param string $name The machine name of the table group.
     * @return \stdClass|null
     */
    function get_acpt_table_group_object(string $name): ?\stdClass
    {
        try {
            $group = TableGroupRepository::getByName($name);

            return $group !== null ? $group->toStdObject() : null;
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return null;
        }
    }
}
