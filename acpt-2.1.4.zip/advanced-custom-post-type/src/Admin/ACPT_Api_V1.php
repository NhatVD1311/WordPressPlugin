<?php

namespace ACPT\Admin;

use ACPT\Core\API\V1\Controllers\BlocksController;
use ACPT\Core\API\V1\Controllers\CustomPostTypeController;
use ACPT\Core\API\V1\Controllers\FilterQueryController;
use ACPT\Core\API\V1\Controllers\FormController;
use ACPT\Core\API\V1\Controllers\FormSubmissionController;
use ACPT\Core\API\V1\Controllers\LicenseController;
use ACPT\Core\API\V1\Controllers\MetaController;
use ACPT\Core\API\V1\Controllers\OptionPageController;
use ACPT\Core\API\V1\Controllers\SchemaController;
use ACPT\Core\API\V1\Controllers\TableController;
use ACPT\Core\API\V1\Controllers\TableRecordHttpAdapter;
use ACPT\Core\API\V1\Controllers\TaxonomyController;
use ACPT\Core\API\V1\Controllers\WooCommerceController;
use ACPT\Core\Helper\Features;
use ACPT\Integrations\WooCommerce\ACPT_WooCommerce;
use ACPT\Utils\PHP\Request;

class ACPT_Api_V1
{
    public const BASE_V1 = 'acpt/v1';

    private Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    public function registerRestRoutes(): void
    {
        // License
        $this->registerRestRoute('/license/deactivate', 'POST', [new LicenseController($this->request), 'deactivate'], false);

        // Schema (Swagger UI)
        $this->registerRestRoute('/schema', 'GET', [new SchemaController($this->request), 'schema'], false);

        // Filter
        $this->registerRestRoute('/(?P<slug>[a-zA-Z0-9-_]+)/filter/query', 'POST', [new FilterQueryController($this->request), 'search']);

        // Custom Post Types
        if (Features::hasCpt()) {
            $controller = new CustomPostTypeController($this->request);
            $this->registerRestRoute('/cpt', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/cpt/(?P<slug>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/cpt', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/cpt/(?P<slug>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/cpt/(?P<slug>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
        }

        // Option page
        if (Features::hasPages()) {
            $controller = new OptionPageController($this->request);
            $this->registerRestRoute('/option-page', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/option-page/(?P<slug>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/option-page', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/option-page/(?P<slug>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/option-page/(?P<slug>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
        }

        // Taxonomy
        if (Features::hasTax()) {
            $controller = new TaxonomyController($this->request);
            $this->registerRestRoute('/taxonomy', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/taxonomy/(?P<slug>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/taxonomy', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/taxonomy/(?P<slug>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/taxonomy/(?P<slug>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
            $this->registerRestRoute('/taxonomy/assoc/(?P<slug>[a-zA-Z0-9_\-]+)/(?P<cpt>[a-zA-Z0-9_\-]+)', 'POST', [$controller, 'assocToPostType']);
        }

        // Meta
        if (Features::hasMeta()) {
            $controller = new MetaController($this->request);
            $this->registerRestRoute('/meta', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/meta', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/meta/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/meta/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/meta/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
        }

        // Form
        if (Features::hasForms()) {
            $controller = new FormController($this->request);
            $this->registerRestRoute('/form', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/form', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/form/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/form/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/form/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
            $this->registerRestRoute('/form/submission/(?P<key>[a-zA-Z0-9_\-]+)', 'POST', [new FormSubmissionController($this->request), 'submit'], false);
        }

        // Dynamic blocks
        if (Features::hasBlocks()) {
            $controller = new BlocksController($this->request);
            $this->registerRestRoute('/block', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/block', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/block/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/block/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/block/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
        }

        // WooCommerce
        if (ACPT_WooCommerce::active()) {
            $controller = new WooCommerceController($this->request);
            $this->registerRestRoute('/woocommerce/product-data', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/woocommerce/product-data', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields', 'GET', [$controller, 'getFields']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields', 'POST', [$controller, 'createFields']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields', 'PUT', [$controller, 'updateFields']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields', 'DELETE', [$controller, 'deleteFields']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields/(?P<field>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'getField']);
            $this->registerRestRoute('/woocommerce/product-data/(?P<id>[a-zA-Z0-9_\-]+)/fields/(?P<field>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'deleteField']);
        }

        // Custom Content Types (table definitions + record CRUD)
        if (Features::hasCct()) {
            // Table definition management
            $controller = new TableController($this->request);
            $this->registerRestRoute('/table', 'GET', [$controller, 'getAll']);
            $this->registerRestRoute('/table', 'POST', [$controller, 'create']);
            $this->registerRestRoute('/table/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$controller, 'get']);
            $this->registerRestRoute('/table/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$controller, 'delete']);
            $this->registerRestRoute('/table/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$controller, 'update']);
            $this->registerRestRoute('/table/(?P<id>[a-zA-Z0-9_\-]+)/sync', 'POST', [$controller, 'sync']);
            $this->registerRestRoute('/table/(?P<id>[a-zA-Z0-9_\-]+)/status', 'GET', [$controller, 'status']);

            // Table record CRUD — dynamic routes driven by table name.
            // These are registered AFTER all static routes so the generic
            // /{tableName} pattern never shadows /table, /form, /meta, etc.
            $adapter = new TableRecordHttpAdapter($this->request);

            $this->registerRestRoute('/(?P<tableName>[a-zA-Z0-9_]+)', 'GET', [$adapter, 'list'], true, 'read');
            $this->registerRestRoute('/(?P<tableName>[a-zA-Z0-9_]+)', 'POST', [$adapter, 'create'], true, 'create');
            $this->registerRestRoute('/(?P<tableName>[a-zA-Z0-9_]+)/(?P<id>[a-zA-Z0-9_\-]+)', 'GET', [$adapter, 'get'], true, 'read');
            $this->registerRestRoute('/(?P<tableName>[a-zA-Z0-9_]+)/(?P<id>[a-zA-Z0-9_\-]+)', 'PUT', [$adapter, 'update'], true, 'update');
            $this->registerRestRoute('/(?P<tableName>[a-zA-Z0-9_]+)/(?P<id>[a-zA-Z0-9_\-]+)', 'DELETE', [$adapter, 'delete'], true, 'delete');
        }
    }

    /**
     * @param string                       $route
     * @param string                       $methods
     * @param callable|array<int, mixed>   $callback
     * @param bool                         $isASecuredRoute
     * @param string|null                  $tableCapability One of TableModel::capabilities()
     *                                                       ('read'/'create'/'update'/'delete') for
     *                                                       table-record routes -- lets a non-admin
     *                                                       WP user through when their role has been
     *                                                       granted that capability on the requested
     *                                                       table, instead of requiring manage_options.
     *                                                       null (default) preserves the original
     *                                                       admin-only behavior for every other route.
     */
    private function registerRestRoute(string $route, string $methods, $callback, bool $isASecuredRoute = true, ?string $tableCapability = null): void
    {
        register_rest_route(self::BASE_V1, $route, [
            'methods'             => $methods,
            'callback'            => $callback,
            'permission_callback' => $this->permissionCallback($isASecuredRoute, $tableCapability)
        ]);
    }

    /**
     * Determines the appropriate callback for route permissions based on the nature of the route and execution context.
     *
     * @param bool        $isASecuredRoute  Indicates whether the route requires authentication.
     *                                      `true` for secured routes, `false` for unsecured routes.
     * @param string|null $tableCapability  See registerRestRoute().
     * @return callable|string The callback function for permission validation.
     *                         Returns `__return_true` if the request is from WP-CLI or if the route is unsecured,
     *                         otherwise returns an authentication callback.
     */
    private function permissionCallback(bool $isASecuredRoute = true, ?string $tableCapability = null)
    {
        // Trust only real `wp` CLI command execution (the WP_CLI constant, defined
        // exclusively by WP-CLI itself) -- NOT php_sapi_name() === 'cli', which is
        // true for any CLI-invoked PHP process and would bypass REST auth entirely
        // for such a process (including this project's own PHPUnit suite).
        if (defined('WP_CLI') && WP_CLI) {
            return '__return_true';
        }

        if (!$isASecuredRoute) {
            return '__return_true';
        }

        $auth = new ACPT_Api_Auth($this->request);

        if ($tableCapability !== null) {
            return function (\WP_REST_Request $request) use ($auth, $tableCapability) {
                return $auth->authenticate($request, $tableCapability);
            };
        }

        return [$auth, 'authenticate'];
    }
}
