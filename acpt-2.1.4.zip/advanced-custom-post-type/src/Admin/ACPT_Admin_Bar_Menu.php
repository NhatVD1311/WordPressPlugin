<?php

namespace ACPT\Admin;

use ACPT\Core\Helper\Features;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\DynamicBlockRepository;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Utils\Wordpress\Translator;

class ACPT_Admin_Bar_Menu
{
    /**
     * @param \WP_Admin_Bar $wpAdminBar
     * @return void
     */
    public static function generate(\WP_Admin_Bar $wpAdminBar): void
    {
        if (! is_admin()) {
            return;
        }

        if (!current_user_can('manage_options')) {
            return;
        }

        foreach (self::getMenuTree() as $menuItem) {
            self::addNodeToAdminBar($wpAdminBar, $menuItem);
        }
    }

    /**
     * @param \WP_Admin_Bar $wpAdminBar
     * @param ACPT_Admin_Bar_Menu_Item $menuItem
     * @param string|null $parentId
     * @return void
     */
    private static function addNodeToAdminBar(\WP_Admin_Bar $wpAdminBar, ACPT_Admin_Bar_Menu_Item $menuItem, ?string $parentId = null): void
    {
        $args = [
            'id'     => $menuItem->id,
            'title'  => $menuItem->title,
            'href'   => $menuItem->href,
        ];

        if ($parentId !== null) {
            $args['parent'] = $parentId;
        }

        $wpAdminBar->add_node($args);

        if (!empty($menuItem->children)) {
            foreach ($menuItem->children as $child) {
                self::addNodeToAdminBar($wpAdminBar, $child, $menuItem->id);
            }
        }
    }

    /**
     * @return ACPT_Admin_Bar_Menu_Item[]
     */
    public static function getMenuTree(): array
    {
        $tree = [];

        // Parent node
        $mainNode = new ACPT_Admin_Bar_Menu_Item("main", self::ACPTLogo());

        // Custom post types
        if (Features::hasCpt()) {
            $cptNode = new ACPT_Admin_Bar_Menu_Item("custom-post-types", "Custom Post Types");
            $cptNode->addChild(new ACPT_Admin_Bar_Menu_Item("create-custom-post-type", "Create new Custom Post Type", "register"));

            try {
                foreach (CustomPostTypeRepository::get() as $postTypeModel) {
                    if (!$postTypeModel->isNative()) {
                        $cptNode->addChild(new ACPT_Admin_Bar_Menu_Item($postTypeModel->getName(), $postTypeModel->getSingular(), "view/".$postTypeModel->getName()));
                    }
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($cptNode);
        }

        // Taxonomies
        if (Features::hasTax()) {
            $taxNode = new ACPT_Admin_Bar_Menu_Item("taxonomies", "Taxonomies", "taxonomies");
            $taxNode->addChild(new ACPT_Admin_Bar_Menu_Item("register-taxonomy", "Create new Taxonomy", "register_taxonomy"));

            try {
                foreach (TaxonomyRepository::get() as $taxonomyModel) {
                    if (!$taxonomyModel->isNative()) {
                        $taxNode->addChild(new ACPT_Admin_Bar_Menu_Item($taxonomyModel->getSlug(), $taxonomyModel->getSingular(), "view_taxonomy/".$taxonomyModel->getSlug()));
                    }
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($taxNode);
        }

        // Option Pages
        if (Features::hasPages()) {
            $pagesNode = new ACPT_Admin_Bar_Menu_Item("option-pages", "Option pages", "option-pages");
            $pagesNode->addChild(new ACPT_Admin_Bar_Menu_Item("option-pages-manage", "Manage pages", "option-pages-manage"));
            $mainNode->addChild($pagesNode);
        }

        // Field groups
        if (Features::hasMeta()) {
            $metaNode = new ACPT_Admin_Bar_Menu_Item("meta", "Field groups", "meta");
            $metaNode->addChild(new ACPT_Admin_Bar_Menu_Item("register-meta", "Create new Meta group", "register_meta"));

            try {
                foreach (MetaRepository::get([]) as $metaGroupModel) {
                    $metaNode->addChild(new ACPT_Admin_Bar_Menu_Item("meta-".$metaGroupModel->getId(), Translator::translate("Edit") . " ". $metaGroupModel->getUIName(), "edit_meta/".$metaGroupModel->getId()));
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($metaNode);
        }

        // Forms
        if (Features::hasForms()) {
            $formsNode = new ACPT_Admin_Bar_Menu_Item("forms", "Forms", "forms");
            $formsNode->addChild(new ACPT_Admin_Bar_Menu_Item("register-form", "Create form", "form-settings"));

            try {
                foreach (FormRepository::get([]) as $formModel) {
                    $formsNode->addChild(new ACPT_Admin_Bar_Menu_Item("form-".$formModel->getId(), Translator::translate("Manage fields") . " ". $formModel->getLabel(), "form/".$formModel->getId()));
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($formsNode);
        }

        // CCT
        if (Features::hasCct()) {
            try {
                //table-groups
                $tableGroupsNode = new ACPT_Admin_Bar_Menu_Item("table-groups", "Table groups", "table-groups");
                $tableGroupsNode->addChild(new ACPT_Admin_Bar_Menu_Item("register_table_group", "Create new group", "register_table_group"));

                foreach (TableGroupRepository::get([]) as $tableGroupModel) {
                    $tableGroupsNode->addChild(new ACPT_Admin_Bar_Menu_Item("table-group-".$tableGroupModel->getId(), $tableGroupModel->getLabelOrName(), "view_table_group/".$tableGroupModel->getId()));
                }

                // tables
                $cctNode = new ACPT_Admin_Bar_Menu_Item("cct", "All tables", "cct");
                $cctNode->addChild(new ACPT_Admin_Bar_Menu_Item("register_table", "Create new table", "register_table"));

                foreach (TableRepository::get([]) as $tableModel) {
                    $cctNode->addChild(new ACPT_Admin_Bar_Menu_Item("view-".$tableModel->getId(), $tableModel->getLabelOrName(), "view_table/".$tableModel->getId()));
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($tableGroupsNode);
            $mainNode->addChild($cctNode);
        }

        // Blocks
        if (Features::hasBlocks()) {
            $blocksNode = new ACPT_Admin_Bar_Menu_Item("blocks", "Dynamic blocks", "blocks");
            $blocksNode->addChild(new ACPT_Admin_Bar_Menu_Item("register-block", "Create new block", "block"));

            try {
                foreach (DynamicBlockRepository::get([]) as $blockModel) {
                    $blocksNode->addChild(new ACPT_Admin_Bar_Menu_Item("block-".$blockModel->getId(), $blockModel->getName(), "view_block/".$blockModel->getId()));
                }
            } catch (\Exception $exception) {
            }

            $mainNode->addChild($blocksNode);
        }

        // Settings
        $mainNode->addChild(new ACPT_Admin_Bar_Menu_Item("settings", "Settings", "settings"));

        $tree[] = $mainNode;

        return $tree;
    }

    /**
     * @return string
     */
    private static function ACPTLogo(): string
    {
        return '
            <span class="ab-icon">
                <svg width="18" height="18" viewBox="0 0 637 695" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path opacity="0.5" fill-rule="evenodd" clip-rule="evenodd" d="M302.676 417.485C302.676 381.758 283.616 348.746 252.676 330.882L30 202.32C16.6667 194.622 0 204.245 0 219.641V476.765C0 512.491 19.0599 545.504 50 563.367L272.676 691.929C286.009 699.627 302.676 690.005 302.676 674.609V417.485ZM237.676 596.667V417.485C237.676 404.981 231.005 393.426 220.176 387.174L65 297.583V476.765C65 489.269 71.671 500.824 82.5 507.076L237.676 596.667Z" fill="#fff"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M383.338 330.882C352.398 348.746 333.338 381.758 333.338 417.485L333.338 674.609C333.338 690.005 350.005 699.627 363.338 691.929L586.014 563.367C616.954 545.504 636.014 512.491 636.014 476.765L636.014 219.641C636.014 204.245 619.347 194.622 606.014 202.32L383.338 330.882ZM571.014 297.583L415.838 387.174C405.009 393.426 398.338 404.981 398.338 417.485L398.338 596.667L553.514 507.076C564.343 500.824 571.014 489.269 571.014 476.765L571.014 297.583Z" fill="#fff"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M367.676 14.2424C336.736 -3.62085 298.616 -3.62085 267.676 14.2424L45 142.804C31.6667 150.502 31.6667 169.747 45 177.445L267.676 306.007C298.616 323.871 336.736 323.871 367.676 306.007L590.352 177.445C603.685 169.747 603.685 150.502 590.352 142.804L367.676 14.2424ZM490.352 160.125L335.176 70.5341C324.347 64.2819 311.005 64.2819 300.176 70.5341L145 160.125L300.176 249.716C311.005 255.968 324.347 255.968 335.176 249.716L490.352 160.125Z" fill="#fff"></path>
                </svg>
            </span>
            <span class="ab-label">
                ACPT
            </span>
        ';
    }
}
