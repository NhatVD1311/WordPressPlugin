<?php

namespace ACPT\Admin;

use ACPT\Core\Helper\Features;
use ACPT\Core\Models\OptionPage\OptionPageModel;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Utils\Wordpress\Roles;

class ACPT_Permissions
{
    /**
     * @return void
     */
    public function setPermissions(): void
    {
        try {
            $allTheRoles = Roles::get('objects');
            $this->setPostPermissions($allTheRoles);
            $this->setOptionPagesPermissions($allTheRoles);
            $this->setTaxonomyPermissions($allTheRoles);
            $this->setMetaFieldsPermissions($allTheRoles);
            $this->setTablePermissions($allTheRoles);
            $this->setTableGroupPermissions($allTheRoles);

            // WordPress builds $user->allcaps during init (before admin_init fires).
            // After add_cap() updates $wp_roles in memory, we must rebuild allcaps
            // so that current_user_can() checks in admin_menu see the new capabilities.
            $currentUser = wp_get_current_user();
            if ($currentUser->exists()) {
                $currentUser->get_role_caps();
            }
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);
            // do nothing
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     * @throws \Exception
     */
    private function setPostPermissions(array $allTheRoles): void
    {
        if (!Features::hasCpt()) {
            return;
        }

        $customPostTypes = CustomPostTypeRepository::get([]);

        foreach ($customPostTypes as $customPostType) {
            if (!$customPostType->isNative() && $customPostType->hasPermissions()) {
                $capabilityType = $customPostType->capabilityType();
                $customPostTypeRoleNames = [];

                // Set specific user roles
                foreach ($customPostType->getPermissions() as $permission) {
                    $customPostTypeRoleNames[] = $permission->getUserRole();
                    $role = get_role($permission->getUserRole());

                    if ($role !== null) {
                        $permissions = $permission->getPermissions();

                        $edit = $permissions['edit_s'];
                        $editPrivate = $permissions['edit_private_s'];
                        $editPublished = $permissions['edit_published_s'];
                        $editOthers = $permissions['edit_others_s'];
                        $publish = $permissions['publish_s'];
                        $readPrivate = $permissions['read_private_s'];
                        $delete = $permissions['delete_s'];
                        $deletePrivate = $permissions['delete_private_s'];
                        $deletePublished = $permissions['delete_published_s'];
                        $deleteOther = $permissions['delete_others_s'];

                        // edit
                        if ($edit === true) {
                            $role->add_cap('edit_'.$capabilityType);
                            $role->add_cap('edit_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('edit_'.$capabilityType);
                            $role->remove_cap('edit_'.$capabilityType.'s');
                        }

                        if ($editPrivate === true) {
                            $role->add_cap('edit_private_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('edit_private_'.$capabilityType.'s');
                        }

                        if ($editPublished === true) {
                            $role->add_cap('edit_published_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('edit_published_'.$capabilityType.'s');
                        }

                        if ($editOthers === true) {
                            $role->add_cap('edit_others_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('edit_others_'.$capabilityType.'s');
                        }

                        // publish
                        if ($publish === true) {
                            $role->add_cap('publish_'.$capabilityType.'s');
                            $role->add_cap('publish_'.$capabilityType);
                        } else {
                            $role->remove_cap('publish_'.$capabilityType.'s');
                            $role->remove_cap('publish_'.$capabilityType);
                        }

                        // read (read_private) — independent of edit; must not touch
                        // edit_<type>/edit_<type>s, which the "edit" block above
                        // already set correctly. Previously this block unconditionally
                        // stripped both edit caps whenever read_private was off (silently
                        // undoing "Edit" whenever "Read private" wasn't also checked) and
                        // granted blanket edit when read_private was on regardless of the
                        // edit checkbox (an unintended escalation) — see ticket for detail.
                        if ($readPrivate === true) {
                            $role->add_cap('read_private_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('read_private_'.$capabilityType.'s');
                        }

                        // delete
                        if ($delete === true) {
                            $role->add_cap('delete_'.$capabilityType);
                            $role->add_cap('delete_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('delete_'.$capabilityType);
                            $role->remove_cap('delete_'.$capabilityType.'s');
                        }

                        if ($deletePrivate === true) {
                            $role->add_cap('delete_private_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('delete_private_'.$capabilityType.'s');
                        }

                        if ($deletePublished === true) {
                            $role->add_cap('delete_published_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('delete_published_'.$capabilityType.'s');
                        }

                        if ($deleteOther === true) {
                            $role->add_cap('delete_others_'.$capabilityType.'s');
                        } else {
                            $role->remove_cap('delete_others_'.$capabilityType.'s');
                        }
                    }
                }

                // Reset the permissions for the other *canonical* roles only.
                // A role name outside WP's 5 canonical roles is a genuinely custom
                // role (the Permissions UI's own role picker offers every registered
                // role, not just these 5 — see Roles::get()) with no explicit
                // permission row for this CPT: it must stay fully untouched here,
                // matching the "unconfigured role stays fully open" convention used
                // by Table/TableGroup/OptionPage/MetaField elsewhere in this codebase.
                // Previously any non-canonical role name fell through to the same
                // lockout as "subscriber", silently stripping every custom role's
                // access the moment *any* role got a permission row on this CPT.
                foreach ($allTheRoles as $role) {
                    if (in_array($role->name, $customPostTypeRoleNames)) {
                        continue;
                    }

                    switch ($role->name) {
                        case "super_admin":
                        case "administrator":
                        case "editor":
                            $role->add_cap('edit_'.$capabilityType);
                            $role->add_cap('edit_'.$capabilityType.'s');
                            $role->add_cap('edit_private_'.$capabilityType.'s');
                            $role->add_cap('edit_published_'.$capabilityType.'s');
                            $role->add_cap('edit_others_'.$capabilityType.'s');
                            $role->add_cap('publish_'.$capabilityType);
                            $role->add_cap('publish_'.$capabilityType.'s');
                            $role->add_cap('read_private_'.$capabilityType.'s');
                            $role->add_cap('delete_'.$capabilityType);
                            $role->add_cap('delete_'.$capabilityType.'s');
                            $role->add_cap('delete_private_'.$capabilityType.'s');
                            $role->add_cap('delete_published_'.$capabilityType.'s');
                            $role->add_cap('delete_others_'.$capabilityType.'s');
                            break;

                        case "author":
                            $role->add_cap('edit_'.$capabilityType);
                            $role->add_cap('edit_'.$capabilityType.'s');
                            $role->remove_cap('edit_private_'.$capabilityType.'s');
                            $role->add_cap('edit_published_'.$capabilityType.'s');
                            $role->remove_cap('edit_others_'.$capabilityType.'s');
                            $role->add_cap('publish_'.$capabilityType);
                            $role->add_cap('publish_'.$capabilityType.'s');
                            $role->remove_cap('read_private_'.$capabilityType.'s');
                            $role->add_cap('delete_'.$capabilityType);
                            $role->add_cap('delete_'.$capabilityType.'s');
                            $role->remove_cap('delete_private_'.$capabilityType.'s');
                            $role->add_cap('delete_published_'.$capabilityType.'s');
                            $role->remove_cap('delete_others_'.$capabilityType.'s');
                            break;

                        case "contributor":
                            $role->add_cap('edit_'.$capabilityType);
                            $role->add_cap('edit_'.$capabilityType.'s');
                            $role->remove_cap('edit_private_'.$capabilityType.'s');
                            $role->remove_cap('edit_published_'.$capabilityType.'s');
                            $role->remove_cap('edit_others_'.$capabilityType.'s');
                            $role->remove_cap('publish_'.$capabilityType);
                            $role->remove_cap('publish_'.$capabilityType.'s');
                            $role->remove_cap('read_private_'.$capabilityType.'s');
                            $role->add_cap('delete_'.$capabilityType);
                            $role->add_cap('delete_'.$capabilityType.'s');
                            $role->remove_cap('delete_private_'.$capabilityType.'s');
                            $role->remove_cap('delete_published_'.$capabilityType.'s');
                            $role->remove_cap('delete_others_'.$capabilityType.'s');
                            break;

                        case "subscriber":
                            $role->remove_cap('edit_'.$capabilityType);
                            $role->remove_cap('edit_'.$capabilityType.'s');
                            $role->remove_cap('edit_private_'.$capabilityType.'s');
                            $role->remove_cap('edit_published_'.$capabilityType.'s');
                            $role->remove_cap('edit_others_'.$capabilityType.'s');
                            $role->remove_cap('publish_'.$capabilityType);
                            $role->remove_cap('publish_'.$capabilityType.'s');
                            $role->remove_cap('read_private_'.$capabilityType.'s');
                            $role->remove_cap('delete_'.$capabilityType);
                            $role->remove_cap('delete_'.$capabilityType.'s');
                            $role->remove_cap('delete_private_'.$capabilityType.'s');
                            $role->remove_cap('delete_published_'.$capabilityType.'s');
                            $role->remove_cap('delete_others_'.$capabilityType.'s');
                            break;

                        default:
                            // Genuinely custom role, not explicitly configured for
                            // this CPT — leave it completely untouched (see comment
                            // above the loop).
                            break;
                    }
                }

                Roles::refresh();
            }
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     * @throws \Exception
     */
    private function setOptionPagesPermissions(array $allTheRoles): void
    {
        if (!Features::hasPages()) {
            return;
        }

        $optionPages = OptionPageRepository::get([]);

        foreach ($optionPages as $optionPage) {
            $this->setOptionPagePermissions($optionPage, $allTheRoles);

            foreach ($optionPage->getChildren() as $childOptionPage) {
                $this->setOptionPagePermissions($childOptionPage, $allTheRoles);
            }
        }
    }

    /**
     * @param OptionPageModel $optionPage
     * @param \WP_Role[]      $allTheRoles
     */
    private function setOptionPagePermissions(OptionPageModel $optionPage, array $allTheRoles): void
    {
        if ($optionPage->hasPermissions()) {
            $optionPageRoleNames = [];
            $capabilityType = $optionPage->capabilityType();

            // Set specific user roles
            foreach ($optionPage->getPermissions() as $permission) {
                $optionPageRoleNames[] = $permission->getUserRole();
                $role = get_role($permission->getUserRole());

                if ($role !== null) {
                    $permissions = $permission->getPermissions();
                    $edit = $permissions['edit'];
                    $read = $permissions['read'];

                    // edit
                    if ($edit === true) {
                        $role->add_cap('edit_'.$capabilityType);
                    } else {
                        $role->remove_cap('edit_'.$capabilityType);
                    }

                    // read
                    if ($read === true) {
                        $role->add_cap('read_'.$capabilityType);
                    } else {
                        $role->remove_cap('read_'.$capabilityType);
                    }
                }
            }

            // Reset the permissions for the other roles
            foreach ($allTheRoles as $role) {
                if (!in_array($role->name, $optionPageRoleNames)) {
                    switch ($role->name) {
                        case "super_admin":
                        case "administrator":
                        case "editor":
                        case "author":
                            $role->add_cap('edit_'.$capabilityType);
                            $role->add_cap('read_'.$capabilityType);
                            break;

                        case "contributor":
                            $role->remove_cap('edit_'.$capabilityType);
                            $role->add_cap('read_'.$capabilityType);
                            break;

                        case "subscriber":
                            $role->remove_cap('edit_'.$capabilityType);
                            $role->remove_cap('read_'.$capabilityType);
                            break;

                        default:
                            // Genuinely custom role, not explicitly configured
                            // for this option page — leave it completely
                            // untouched, matching the "no cascade" convention
                            // used elsewhere in this file.
                            break;
                    }
                }
            }

            Roles::refresh();
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     * @throws \Exception
     */
    private function setTaxonomyPermissions(array $allTheRoles): void
    {
        if (!Features::hasTax()) {
            return;
        }

        $taxonomies = TaxonomyRepository::get([]);

        foreach ($taxonomies as $taxonomy) {
            if (!$taxonomy->isNative() && $taxonomy->hasPermissions()) {
                $capabilityType = $taxonomy->capabilityType();
                $taxonomyRoleNames = [];

                // Set specific user roles
                foreach ($taxonomy->getPermissions() as $permission) {
                    $taxonomyRoleNames[] = $permission->getUserRole();
                    $role = get_role($permission->getUserRole());

                    if ($role !== null) {
                        $permissions = $permission->getPermissions();
                        $edit        = $permissions['edit'];
                        $assign      = $permissions['assign'];
                        $manage      = $permissions['manage'];
                        $delete      = $permissions['delete'];

                        // edit
                        if ($edit === true) {
                            $role->add_cap('edit_'.$capabilityType);
                        } else {
                            $role->remove_cap('edit_'.$capabilityType);
                        }

                        // assign
                        if ($assign === true) {
                            $role->add_cap('assign_'.$capabilityType);
                        } else {
                            $role->remove_cap('assign_'.$capabilityType);
                        }

                        // manage
                        if ($manage === true) {
                            $role->add_cap('manage_'.$capabilityType);
                        } else {
                            $role->remove_cap('manage_'.$capabilityType);
                        }

                        // delete
                        if ($delete === true) {
                            $role->add_cap('delete_'.$capabilityType);
                        } else {
                            $role->remove_cap('delete_'.$capabilityType);
                        }
                    }
                }

                // Reset the permissions for the other roles
                foreach ($allTheRoles as $role) {
                    if (!in_array($role->name, $taxonomyRoleNames)) {
                        switch ($role->name) {
                            case "super_admin":
                            case "administrator":
                            case "editor":
                            case "author":
                                $role->add_cap('edit_'.$capabilityType);
                                $role->add_cap('assign_'.$capabilityType);
                                $role->add_cap('manage_'.$capabilityType);
                                $role->add_cap('delete_'.$capabilityType);
                                break;

                            case "contributor":
                                $role->add_cap('edit_'.$capabilityType);
                                $role->add_cap('assign_'.$capabilityType);
                                $role->add_cap('manage_'.$capabilityType);
                                $role->remove_cap('delete_'.$capabilityType);
                                break;

                            case "subscriber":
                                $role->remove_cap('edit_'.$capabilityType);
                                $role->remove_cap('assign_'.$capabilityType);
                                $role->remove_cap('manage_'.$capabilityType);
                                $role->remove_cap('delete_'.$capabilityType);
                                break;

                            default:
                                // Genuinely custom role, not explicitly configured
                                // for this taxonomy — leave it completely
                                // untouched, matching the "no cascade" convention
                                // used elsewhere in this file.
                                break;
                        }
                    }
                }

                Roles::refresh();
            }
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     * @throws \Exception
     */
    private function setMetaFieldsPermissions(array $allTheRoles): void
    {
        // @phpstan-ignore-next-line booleanNot.alwaysFalse
        if (!ACPT_ENABLE_META) {
            return;
        }

        $metaFields = MetaRepository::getMetaFields([]);

        foreach ($metaFields as $metaField) {
            if ($metaField->hasPermissions()) {
                $capabilityType = $metaField->capabilityType();
                $fieldRoleNames = [];

                // Set specific user roles
                foreach ($metaField->getPermissions() as $permission) {
                    $fieldRoleNames[] = $permission->getUserRole();
                    $role = get_role($permission->getUserRole());

                    if ($role !== null) {
                        $permissions = $permission->getPermissions();
                        $edit = $permissions['edit'];
                        $read = $permissions['read'];

                        // edit
                        if ($edit === true) {
                            $role->add_cap('edit_'.$capabilityType);
                        } else {
                            $role->remove_cap('edit_'.$capabilityType);
                        }

                        // read
                        if ($read === true) {
                            $role->add_cap('read_'.$capabilityType);
                        } else {
                            $role->remove_cap('read_'.$capabilityType);
                        }
                    }
                }

                // Reset the permissions for the other roles
                foreach ($allTheRoles as $role) {
                    if (!in_array($role->name, $fieldRoleNames)) {
                        switch ($role->name) {
                            case "super_admin":
                            case "administrator":
                            case "editor":
                            case "author":
                                $role->add_cap('edit_'.$capabilityType);
                                $role->add_cap('read_'.$capabilityType);
                                break;

                            case "contributor":
                                $role->remove_cap('edit_'.$capabilityType);
                                $role->add_cap('read_'.$capabilityType);
                                break;

                            case "subscriber":
                                $role->remove_cap('edit_'.$capabilityType);
                                $role->remove_cap('read_'.$capabilityType);
                                break;

                            default:
                                // Genuinely custom role, not explicitly configured
                                // for this field — leave it completely untouched,
                                // matching the "no cascade" convention used
                                // elsewhere in this file.
                                break;
                        }
                    }
                }

                Roles::refresh();
            }
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     */
    private function setTablePermissions($allTheRoles): void
    {
        $tables = TableRepository::get([]);

        foreach ($tables as $table) {
            if ($table->hasPermissions()) {
                $capabilityType = $table->capabilityType();
                $tableRoleNames = [];

                foreach ($table->getPermissions() as $permission) {
                    $tableRoleNames[] = $permission->getUserRole();
                    $role = get_role($permission->getUserRole());

                    if ($role !== null) {
                        $perms = $permission->getPermissions();

                        $perms['read'] ? $role->add_cap('read_'   . $capabilityType) : $role->remove_cap('read_'   . $capabilityType);
                        $perms['create'] ? $role->add_cap('create_' . $capabilityType) : $role->remove_cap('create_' . $capabilityType);
                        $perms['update'] ? $role->add_cap('update_' . $capabilityType) : $role->remove_cap('update_' . $capabilityType);
                        $perms['delete'] ? $role->add_cap('delete_' . $capabilityType) : $role->remove_cap('delete_' . $capabilityType);
                    }
                }

                foreach ($allTheRoles as $role) {
                    if (!in_array($role->name, $tableRoleNames)) {
                        switch ($role->name) {
                            case 'super_admin':
                            case 'administrator':
                            case 'editor':
                                $role->add_cap('read_'   . $capabilityType);
                                $role->add_cap('create_' . $capabilityType);
                                $role->add_cap('update_' . $capabilityType);
                                $role->add_cap('delete_' . $capabilityType);
                                break;

                            case 'author':
                            case 'contributor':
                                $role->add_cap('read_'    . $capabilityType);
                                $role->remove_cap('create_' . $capabilityType);
                                $role->remove_cap('update_' . $capabilityType);
                                $role->remove_cap('delete_' . $capabilityType);
                                break;

                            case 'subscriber':
                                $role->remove_cap('read_'   . $capabilityType);
                                $role->remove_cap('create_' . $capabilityType);
                                $role->remove_cap('update_' . $capabilityType);
                                $role->remove_cap('delete_' . $capabilityType);
                                break;

                            default:
                                // Genuinely custom role, not explicitly configured
                                // for this table — leave it completely untouched,
                                // matching the "no cascade" convention used
                                // elsewhere in this file.
                                break;
                        }
                    }
                }

                Roles::refresh();
            }
        }
    }

    /**
     * @param \WP_Role[] $allTheRoles
     */
    private function setTableGroupPermissions($allTheRoles): void
    {
        $groups = TableGroupRepository::get([]);

        foreach ($groups as $group) {
            if ($group->hasPermissions()) {
                $capabilityType = $group->capabilityType();
                $groupRoleNames = [];

                foreach ($group->getPermissions() as $permission) {
                    $groupRoleNames[] = $permission->getUserRole();
                    $role = get_role($permission->getUserRole());

                    if ($role !== null) {
                        $perms = $permission->getPermissions();

                        $perms['edit'] ? $role->add_cap('edit_' . $capabilityType) : $role->remove_cap('edit_' . $capabilityType);
                        $perms['read'] ? $role->add_cap('read_' . $capabilityType) : $role->remove_cap('read_' . $capabilityType);
                    }
                }

                foreach ($allTheRoles as $role) {
                    if (!in_array($role->name, $groupRoleNames)) {
                        switch ($role->name) {
                            case 'super_admin':
                            case 'administrator':
                            case 'editor':
                            case 'author':
                                $role->add_cap('edit_' . $capabilityType);
                                $role->add_cap('read_' . $capabilityType);
                                break;

                            case 'contributor':
                                $role->remove_cap('edit_' . $capabilityType);
                                $role->add_cap('read_'   . $capabilityType);
                                break;

                            case 'subscriber':
                                $role->remove_cap('edit_' . $capabilityType);
                                $role->remove_cap('read_' . $capabilityType);
                                break;

                            default:
                                // Genuinely custom role, not explicitly configured
                                // for this table group — leave it completely
                                // untouched, matching the "no cascade" convention
                                // used elsewhere in this file.
                                break;
                        }
                    }
                }

                Roles::refresh();
            }
        }
    }
}
