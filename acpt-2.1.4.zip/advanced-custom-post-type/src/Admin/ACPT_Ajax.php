<?php

namespace ACPT\Admin;

use ACPT\Core\API\AJAX\Controllers\AbstractController;
use ACPT\Core\API\AJAX\Controllers\ApiKeysController;
use ACPT\Core\API\AJAX\Controllers\BulkActionController;
use ACPT\Core\API\AJAX\Controllers\CacheController;
use ACPT\Core\API\AJAX\Controllers\CustomPostTypeController;
use ACPT\Core\API\AJAX\Controllers\DatasetController;
use ACPT\Core\API\AJAX\Controllers\FileController;
use ACPT\Core\API\AJAX\Controllers\FormController;
use ACPT\Core\API\AJAX\Controllers\GlobalsController;
use ACPT\Core\API\AJAX\Controllers\IntegrationController;
use ACPT\Core\API\AJAX\Controllers\LicenseController;
use ACPT\Core\API\AJAX\Controllers\MetaController;
use ACPT\Core\API\AJAX\Controllers\OptionPageController;
use ACPT\Core\API\AJAX\Controllers\PermissionController;
use ACPT\Core\API\AJAX\Controllers\TableController;
use ACPT\Core\API\AJAX\Controllers\TableGroupController;
use ACPT\Core\API\AJAX\Controllers\TaxonomyController;
use ACPT\Core\API\AJAX\Controllers\WordPressController;
use ACPT\Core\API\AJAX\Middleware\AdminPermissionsMiddleware;
use ACPT\Core\API\AJAX\Middleware\AjaxNonceVerifierMiddleware;
use ACPT\Core\API\AJAX\Middleware\EditorPermissionsMiddleware;
use ACPT\Utils\PHP\Request;

/**
 * The admin ajax handler
 *
 * @since      1.0.0
 * @package    advanced-custom-post-type
 * @subpackage advanced-custom-post-type/admin
 * @author     Mauro Cassani <maurocassani1978@gmail.com>
 */
class ACPT_Ajax
{
    public const ACTION_PREFIX = 'wp_ajax_';
    public const ACTION_PREFIX_NO_PRIV = 'wp_ajax_nopriv_';

    /**
     * @var Request
     */
    protected Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * @return array<int, mixed>
     */
    public function routes(): array
    {
        $adminAuth = [new AdminPermissionsMiddleware()];
        $editorAuth = [new EditorPermissionsMiddleware()];
        $authWithNonce = [new AdminPermissionsMiddleware(), new AjaxNonceVerifierMiddleware()];
        $public = [];

        return [
            // A
            $this->route('analyzeFileAction', FileController::class, $adminAuth),
            $this->route('assocPostTypeToTaxonomyAction', CustomPostTypeController::class, $adminAuth),
            $this->route('assocTaxonomyToPostTypeAction', CustomPostTypeController::class, $adminAuth),

            // B
            $this->route('bulkActionsAction', BulkActionController::class, $adminAuth),

            // C
            $this->route('cacheConnectionTestAction', CacheController::class, $adminAuth),
            $this->route('cacheStatsAction', CacheController::class, $adminAuth),
            $this->route('checkBlockNameAction', WordPressController::class, $adminAuth),
            $this->route('checkIsVisibleAction', MetaController::class, $public, true),
            $this->route('checkIsVisibleAction', MetaController::class, $adminAuth),
            $this->route('checkMetaBoxFieldNameAction', MetaController::class, $adminAuth),
            $this->route('checkMetaBoxNameAction', MetaController::class, $adminAuth),
            $this->route('checkPostTypeNameAction', WordPressController::class, $adminAuth),
            $this->route('checkTableNameAction', TableController::class, $adminAuth),
            $this->route('checkTaxonomySlugAction', TaxonomyController::class, $adminAuth),
            $this->route('checkTwigCodeAction', WordPressController::class, $adminAuth),
            $this->route('copyMetaBlockAction', MetaController::class, $adminAuth),
            $this->route('copyMetaBlocksAction', MetaController::class, $adminAuth),
            $this->route('copyMetaBoxAction', MetaController::class, $adminAuth),
            $this->route('copyMetaBoxesAction', MetaController::class, $adminAuth),
            $this->route('copyMetaFieldAction', MetaController::class, $adminAuth),
            $this->route('copyMetaFieldsAction', MetaController::class, $adminAuth),
            $this->route('copyOptionPageAction', OptionPageController::class, $adminAuth),
            $this->route('copyOptionPagesAction', OptionPageController::class, $adminAuth),
            $this->route('copyTableColumnAction', TableController::class, $adminAuth),
            $this->route('createPostAndLinkItAction', CustomPostTypeController::class, $editorAuth),

            // D
            $this->route('deactivateLicenseAction', LicenseController::class, $adminAuth),
            $this->route('deleteApiKeyAction', ApiKeysController::class, $adminAuth),
            $this->route('deleteBlockAction', WordPressController::class, $adminAuth),
            $this->route('deleteCacheItemAction', CacheController::class, $adminAuth),
            $this->route('deleteCustomPostTypeAction', CustomPostTypeController::class, $adminAuth),
            $this->route('deleteDatasetAction', DatasetController::class, $adminAuth),
            $this->route('deleteFormAction', FormController::class, $adminAuth),
            $this->route('deleteMetaAction', MetaController::class, $adminAuth),
            $this->route('deleteMetaFieldValueAction', MetaController::class, $adminAuth),
            $this->route('deleteOptionPagesAction', OptionPageController::class, $adminAuth),
            $this->route('deletePageAction', OptionPageController::class, $adminAuth),
            $this->route('deleteTableAction', TableController::class, $adminAuth),
            $this->route('deleteTableGroupAction', TableGroupController::class, $adminAuth),
            $this->route('deleteTableRecordAction', TableController::class, $adminAuth),
            $this->route('deleteTableTemplateAction', TableController::class, $adminAuth),
            $this->route('deleteTaxonomyAction', TaxonomyController::class, $adminAuth),
            $this->route('deleteWPMLConfigAction', IntegrationController::class, $adminAuth),
            $this->route('doShortcodeAction', MetaController::class, $editorAuth),
            $this->route('duplicateAction', BulkActionController::class, $adminAuth),

            // E
            $this->route('emailTemplatePreviewAction', FormController::class, $adminAuth),
            $this->route('evaluateCodeAction', MetaController::class, $public, true),
            $this->route('evaluateCodeAction', MetaController::class, $adminAuth),
            $this->route('exportCodeAction', MetaController::class, $adminAuth),
            $this->route('exportFileAction', FileController::class, $adminAuth),

            // F
            $this->route('fetchAllFindBelongsAction', MetaController::class, $editorAuth),
            $this->route('fetchAllMetaAction', MetaController::class, $editorAuth),
            $this->route('fetchApiKeysAction', ApiKeysController::class, $adminAuth),
            $this->route('fetchApiKeysCountAction', ApiKeysController::class, $adminAuth),
            $this->route('fetchAttachmentsAction', WordPressController::class, $adminAuth),
            $this->route('fetchBlockBindingValuesAction', MetaController::class, $editorAuth),
            $this->route('fetchBlocksAction', WordPressController::class, $adminAuth),
            $this->route('fetchChangelogAction', LicenseController::class, $adminAuth),
            $this->route('fetchCommentsAction', WordPressController::class, $adminAuth),
            $this->route('fetchCustomPostTypesAction', CustomPostTypeController::class, $adminAuth),
            $this->route('fetchDatasetsAction', DatasetController::class, $adminAuth),
            $this->route('fetchElementsAction', MetaController::class, $editorAuth),
            $this->route('fetchFindAction', MetaController::class, $editorAuth),
            $this->route('fetchFindFromBelongsToAction', MetaController::class, $editorAuth),
            $this->route('fetchFormFieldsAction', FormController::class, $adminAuth),
            $this->route('fetchFormPreviewElementAction', FormController::class, $adminAuth),
            $this->route('fetchFormSubmissionsAction', FormController::class, $adminAuth),
            $this->route('fetchFormsAction', FormController::class, $adminAuth),
            $this->route('fetchHeadersAndFootersAction', FormController::class, $adminAuth),
            $this->route('fetchTableColumnsForFormAction', FormController::class, $adminAuth),
            $this->route('fetchLicenseAction', LicenseController::class, $adminAuth),
            $this->route('fetchLogsAction', LicenseController::class, $adminAuth),
            $this->route('fetchMetaAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldsFlatMapAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaFieldsFromBelongsToAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaKeysAction', MetaController::class, $adminAuth),
            $this->route('fetchCCTColumnValueAction', MetaController::class, $editorAuth),
            $this->route('fetchMetaValueAction', MetaController::class, $editorAuth),
            $this->route('fetchOptionPageAction', OptionPageController::class, $adminAuth),
            $this->route('fetchOptionPagesAction', OptionPageController::class, $adminAuth),
            $this->route('fetchOptionPagesMetaAction', OptionPageController::class, $adminAuth),
            $this->route('fetchPageTemplatesAction', WordPressController::class, $adminAuth),
            $this->route('fetchPermissionAction', PermissionController::class, $adminAuth),
            $this->route('fetchPostStatusesAction', WordPressController::class, $adminAuth),
            $this->route('fetchPostTypeTaxonomiesAction', CustomPostTypeController::class, $editorAuth),
            $this->route('fetchPostTypePostsAction', WordPressController::class, $editorAuth),
            $this->route('fetchPostTypesAction', WordPressController::class, $editorAuth),
            $this->route('fetchPreviewLinkAction', MetaController::class, $adminAuth),
            $this->route('fetchRegisteredTaxonomiesAction', TaxonomyController::class, $editorAuth),
            $this->route('fetchSettingsAction', PermissionController::class, $adminAuth),
            $this->route('fetchTableRecordsAction', TableController::class, $adminAuth),
            $this->route('fetchTableStatsAction', TableController::class, $adminAuth),
            $this->route('fetchTablesAction', TableController::class, $adminAuth),
            $this->route('fetchTableGroupsAction', TableGroupController::class, $adminAuth),
            $this->route('fetchTableTemplatesAction', TableController::class, $adminAuth),
            $this->route('fetchTaxonomiesAction', TaxonomyController::class, $adminAuth),
            $this->route('fetchTermsAction', TaxonomyController::class, $editorAuth),
            $this->route('fetchUsersAction', WordPressController::class, $editorAuth),
            $this->route('flushCacheAction', CacheController::class, $adminAuth),

            // G
            $this->route('generateApiKeyAction', ApiKeysController::class, $adminAuth),
            $this->route('generateEmbedAction', MetaController::class, $editorAuth),
            $this->route('generateFlexibleBlockAction', MetaController::class, $editorAuth),
            $this->route('generateFlexibleGroupedFieldsAction', MetaController::class, $editorAuth),
            $this->route('generateGroupedFieldsAction', MetaController::class, $public, true),
            $this->route('generateGroupedFieldsAction', MetaController::class, $adminAuth),
            $this->route('generateGutenbergTemplateAction', MetaController::class, $adminAuth),
            $this->route('generateIdAction', MetaController::class, $public, true),
            $this->route('generateIdAction', MetaController::class, $adminAuth),
            $this->route('generateRelationalFieldOptionsAction', MetaController::class, $adminAuth),
            $this->route('getRepeaterDataAction', MetaController::class, $editorAuth),
            $this->route('globalSettingsAction', GlobalsController::class, $adminAuth),

            // H
            $this->route('healthCheckAction', GlobalsController::class, $adminAuth),

            // I
            $this->route('importDatasetAction', DatasetController::class, $adminAuth),
            $this->route('importSettingsAction', FileController::class, $adminAuth),
            $this->route('installMissingDependenciesAction', LicenseController::class, $adminAuth),
            $this->route('isBBThemeBuilderActiveAction', IntegrationController::class, $adminAuth),
            $this->route('isOxygenBuilderActiveAction', IntegrationController::class, $adminAuth),
            $this->route('isWPGraphQLActiveAction', IntegrationController::class, $adminAuth),

            // L
            $this->route('languagesAction', LicenseController::class, $adminAuth),

            // M
            $this->route('mathEvalAction', MetaController::class, $editorAuth),

            // R
            $this->route('regeneratePostLabelsAction', CustomPostTypeController::class, $adminAuth),
            $this->route('regenerateTaxonomyLabelsAction', TaxonomyController::class, $adminAuth),
            $this->route('resetCustomPostTypesAction', CustomPostTypeController::class, $adminAuth),
            $this->route('resetTaxonomiesAction', TaxonomyController::class, $adminAuth),
            $this->route('runRepairAction', GlobalsController::class, $adminAuth),

            // S
            $this->route('saveBlockAction', WordPressController::class, $adminAuth),
            $this->route('saveBlockBindingValuesAction', MetaController::class, $authWithNonce),
            $this->route('saveCustomPostTypeAction', CustomPostTypeController::class, $adminAuth),
            $this->route('saveDatasetAction', DatasetController::class, $adminAuth),
            $this->route('saveFormAction', FormController::class, $adminAuth),
            $this->route('saveFormFieldsAction', FormController::class, $adminAuth),
            $this->route('saveFormSubmissionAction', FormController::class, $adminAuth),
            $this->route('saveMetaAction', MetaController::class, $adminAuth),
            $this->route('saveMetaFieldValueAction', MetaController::class, $adminAuth),
            $this->route('saveOptionPagesAction', OptionPageController::class, $adminAuth),
            $this->route('savePermissionAction', PermissionController::class, $adminAuth),
            $this->route('saveSettingsAction', PermissionController::class, $authWithNonce),
            $this->route('saveTableAction', TableController::class, $adminAuth),
            $this->route('saveTableGroupAction', TableGroupController::class, $adminAuth),
            $this->route('saveTableRecordAction', TableController::class, $adminAuth),
            $this->route('saveTableTemplate', TableController::class, $adminAuth),
            $this->route('saveTaxonomyAction', TaxonomyController::class, $adminAuth),
            $this->route('saveWPMLConfigAction', IntegrationController::class, $adminAuth),
            $this->route('sluggifyAction', WordPressController::class, $editorAuth),
            $this->route('syncPostsAction', CustomPostTypeController::class, $adminAuth),
            $this->route('syncTaxonomiesAction', TaxonomyController::class, $adminAuth),

            // T
            $this->route('tableSchemaAction', TableController::class, $adminAuth),

            // W
            $this->route('wpmlConfigAction', IntegrationController::class, $adminAuth),
        ];
    }

    /**
     * @param string                           $action
     * @param class-string<AbstractController> $controllerClass
     * @param array<int, mixed>                $middlewares
     * @param bool                             $isNoPriv
     * @return array{0: string, 1: class-string<AbstractController>, 2: string, 3: array<int, mixed>}
     */
    protected function route(string $action, string $controllerClass, array $middlewares = [], bool $isNoPriv = false): array
    {
        return [$this->prefixAction($action, $isNoPriv), $controllerClass, $action, $middlewares];
    }

    /**
     * Prefixes the given action with a predefined constant based on the privilege flag.
     *
     * @param string $action
     * @param bool $isNoPriv
     * @return string
     */
    protected function prefixAction(string $action, bool $isNoPriv = false): string
    {
        if ($isNoPriv) {
            return self::ACTION_PREFIX_NO_PRIV . $action;
        }

        return self::ACTION_PREFIX . $action;
    }
}
