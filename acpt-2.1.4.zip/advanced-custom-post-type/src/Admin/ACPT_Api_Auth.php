<?php

namespace ACPT\Admin;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Repository\ApiRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\Request;

class ACPT_Api_Auth
{
    private Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Authorization process.
     *
     * $tableCapability, when passed, is one of TableModel::capabilities()
     * ('read'/'create'/'update'/'delete') for a table-record REST route. A
     * non-admin Basic-Auth user is allowed through when their WP role has
     * been granted that capability on the requested table (via the Table
     * Permission System), instead of the blanket manage_options gate below.
     * Routes that don't pass it (every non-table-record route) keep the
     * exact original manage_options-only behavior.
     *
     * @return bool
     * @throws \Exception
     */
    public function authenticate(\WP_REST_Request $request, ?string $tableCapability = null)
    {
        // Basic
        if (!empty($this->request->httpAuthorization())) {
            $basicAuthorization = $this->request->httpAuthorization();
            if (Strings::contains('Basic ', $basicAuthorization)) {
                $basic = base64_decode(str_replace('Basic ', '', $basicAuthorization));
                $basic = explode(':', $basic);
                $check = wp_authenticate_username_password(null, $basic[0], $basic[1]);

                if (!($check instanceof \WP_User)) {
                    return false;
                }

                // Make the authenticated user available to the rest of this
                // request's lifecycle (e.g. PermissionTrait::userPermissions(),
                // which reads wp_get_current_user()) -- authenticate() previously
                // discarded this entirely, returning only a bare bool.
                wp_set_current_user($check->ID);

                if (user_can($check, 'manage_options')) {
                    return true;
                }

                return $tableCapability !== null && $this->userHasTableCapability($request, $tableCapability);
            }
        }

        // API keys pair
        $credentials = $this->getTheCredentials($request);

        if (empty($credentials) || Arrays::count($credentials) !== 2) {
            return false;
        }

        $key = $credentials[0];
        $secret = $credentials[1];

        $apiKeyModel = ApiRepository::get([
            'key' => $key,
            'secret' => $secret,
        ]);

        return $apiKeyModel !== null && user_can($apiKeyModel->getUid(), 'manage_options');
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return array<int, string>
     */
    private function getTheCredentials(\WP_REST_Request $request): array
    {
        if (!empty($this->request->server('HTTP_ACPT_API_KEY'))) {
            return explode('-', $this->request->server('HTTP_ACPT_API_KEY'));
        }

        $headers = $request->get_headers();

        if (isset($headers['acpt_api_key'])) {
            $credentials = (is_array($headers['acpt_api_key'])) ? $headers['acpt_api_key'][0] : $headers['acpt_api_key'];

            return explode('-', $credentials);
        }

        return [];
    }

    /**
     * Resolves the requested table by its {tableName} route param and checks
     * whether the current WP user's role has been granted $capability on it,
     * via the existing Table Permission System (PermissionTrait::userPermissions()).
     */
    private function userHasTableCapability(\WP_REST_Request $request, string $capability): bool
    {
        $tableName = $request->get_param('tableName');

        if (empty($tableName) || !is_string($tableName)) {
            return false;
        }

        $table = TableRepository::getByName($tableName);

        if ($table === null) {
            return false;
        }

        return $table->userPermissions()[$capability] ?? false;
    }
}
