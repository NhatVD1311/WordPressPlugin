<?php

namespace ACPT\Admin;

use ACPT\Constants\Cookies;
use ACPT\Constants\MetaTypes;
use ACPT\Core\API\AJAX\Controllers\AbstractController;
use ACPT\Core\CQRS\Query\FetchMetaGroupsQuery;
use ACPT\Core\Generators\Comment\CommentAdminColumnsGenerator;
use ACPT\Core\Generators\Comment\CommentMetaGroupsGenerator;
use ACPT\Core\Generators\CustomPostType\CustomPostTypeAdminColumnsGenerator;
use ACPT\Core\Generators\CustomPostType\CustomPostTypeGenerator;
use ACPT\Core\Generators\CustomPostType\CustomPostTypeMetaBoxGenerator;
use ACPT\Core\Generators\CustomPostType\CustomPostTypeMetaGroupsGenerator;
use ACPT\Core\Generators\Meta\TableFieldGenerator;
use ACPT\Core\Generators\OptionPage\OptionPageGenerator;
use ACPT\Core\Generators\Table\TableRecordPageGenerator;
use ACPT\Core\Generators\Taxonomy\TaxonomyAdminColumnsGenerator;
use ACPT\Core\Generators\Taxonomy\TaxonomyMetaGroupsGenerator;
use ACPT\Core\Generators\User\UserAdminColumnsGenerator;
use ACPT\Core\Generators\User\UserMetaGroupsGenerator;
use ACPT\Core\Helper\Features;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Core\Shortcodes\ACPT\AttachmentMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\CctMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\CommentMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\OptionPageMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\PostMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\TaxonomyMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\UserMetaShortcode;
use ACPT\Core\Shortcodes\ACPT\WooCommerceProductAttributeShortcode;
use ACPT\Core\Shortcodes\Form\FormShortcode;
use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Loader;
use ACPT\Integrations\AbilitiesAPI\ACPT_AbilitiesAPI;
use ACPT\Includes\ACPT_Plugin;
use ACPT\Integrations\ACFW\ACPT_ACFW;
use ACPT\Integrations\AbstractIntegration;
use ACPT\Integrations\Breakdance\ACPT_Breakdance;
use ACPT\Integrations\Bricks\ACPT_Bricks;
use ACPT\Integrations\Divi\ACPT_Divi;
use ACPT\Integrations\Elementor\ACPT_Elementor;
use ACPT\Integrations\ElementorPro\ACPT_Elementor_Pro;
use ACPT\Integrations\Etch\ACPT_Etch;
use ACPT\Integrations\FacetWP\ACPT_FacetWP;
use ACPT\Integrations\GenerateBlocks\ACPT_GenerateBlocks;
use ACPT\Integrations\Gutenberg\ACPT_Gutenberg;
use ACPT\Integrations\Oxygen\ACPT_Oxygen;
use ACPT\Integrations\Polylang\ACPT_Polylang;
use ACPT\Integrations\Polylang\Helper\PolylangChecker;
use ACPT\Integrations\RankMath\ACPT_RankMath;
use ACPT\Integrations\SeoPress\ACPT_SeoPress;
use ACPT\Integrations\SlimSeo\ACPT_SlimSeo;
use ACPT\Integrations\WooCommerce\ACPT_WooCommerce;
use ACPT\Integrations\WPAllExport\ACPT_WPAllExport;
use ACPT\Integrations\WPAllImport\ACPT_WPAllImport;
use ACPT\Integrations\WPGraphQL\ACPT_WPGraphQL;
use ACPT\Integrations\WPGridBuilder\ACPT_WPGridBuilder;
use ACPT\Integrations\WPML\ACPT_WPML;
use ACPT\Integrations\WPML\Helper\WPMLChecker;
use ACPT\Integrations\Yoast\ACPT_Yoast;
use ACPT\Integrations\Zion\ACPT_Zion;
use ACPT\Utils\PHP\Cookie;
use ACPT\Utils\PHP\Maps;
use ACPT\Utils\PHP\Profiler;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\PHP\Server;
use ACPT\Utils\PHP\Session;
use ACPT\Utils\PHP\Url;
use ACPT\Utils\Vite\Assets;
use ACPT\Utils\Wordpress\Comments;
use ACPT\Utils\Wordpress\Nonce;
use ACPT\Utils\Wordpress\Posts;
use ACPT\Utils\Wordpress\Translator;
use ACPT\Utils\Wordpress\WPAttachment;
use ACPT\Utils\Wordpress\WPUtils;

/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    advanced-custom-post-type
 * @subpackage advanced-custom-post-type/admin
 * @author     Mauro Cassani <maurocassani1978@gmail.com>
 */
class ACPT_Admin
{
    /**
     * @var ACPT_Loader
     */
    private ACPT_Loader $loader;

    /**
     * @var ACPT_Ajax
     */
    private ACPT_Ajax $ajax;

    /**
     * @var array<int, array<string, mixed>>
     */
    private array $pages = [];

    /**
     * @var array<string, string>
     */
    private array $staticCssAssets = [];

    /**
     * @var array<string, mixed>
     */
    private array $staticJsAssets = [];

    /**
     * @var string|null
     */
    private ?string $googleMapsApiKey = null;

    /**
     * @var string|null
     */
    private ?string $googleSheetsKey = null;

    /**
     * @var string
     */
    private string $pagenow;

    /**
     * @var array<string, mixed>
     */
    private array $postTypeAndTaxonomyNamesArray = [];

    /**
     * @var Request
     */
    private Request $request;

    /**
     * @param ACPT_Loader $loader
     * @param Request $request
     * @throws \Exception
     */
    public function __construct(ACPT_Loader $loader, Request $request)
    {
        $this->request = $request;
        $this->ajax = new ACPT_Ajax($request);
        $this->loader = $loader;
        $this->pagenow = Url::pagenow();
        $this->googleMapsApiKey = Maps::googleMapsKey();
        $this->googleSheetsKey = TableFieldGenerator::googleSheetsKey();
        $this->postTypeAndTaxonomyNamesArray = MetaRepository::getAllAssociatedPostTypesAndTaxonomies();

        add_action('init', function () {
            $this->setPages();
        });
    }

    /**
     * @throws \Exception
     */
    private function setPages(): void
    {
        $pages = [
            [
                'pageTitle' => 'Advanced Custom Post Types',
                'menuTitle' => 'ACPT',
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME,
                'template' => 'app',
                'iconUrl' => plugins_url('advanced-custom-post-type/assets/static/img/advanced-custom-post-type-icon.svg'),
                'position' => 50,
            ]
        ];

        if (Features::hasCpt()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Custom Post Types', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Custom Post Types', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME,
                'template' => 'app',
                'position' => 51,
            ];
        }

        if (Features::hasTax()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Taxonomies', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Taxonomies', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/taxonomies',
                'template' => 'app',
                'position' => 52,
            ];
        }

        if (Features::hasPages()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Option pages', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Option pages', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/option-pages',
                'template' => 'app',
                'position' => 53,
            ];
        }

        if (Features::hasMeta()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Field groups', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Field groups', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/meta',
                'template' => 'app',
                'position' => 54,
            ];
        }

        if (Features::hasForms()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Forms', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Forms', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/forms',
                'template' => 'app',
                'position' => 55,
            ];
        }

        if (Features::hasBlocks()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Dynamic blocks', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Dynamic blocks', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/blocks',
                'template' => 'app',
                'position' => 56,
            ];
        }

        if (Features::hasCct()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Table Groups', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Table Groups', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/table-groups',
                'template' => 'app',
                'position' => 57,
            ];
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('All Tables', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('All Tables', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/cct',
                'template' => 'app',
                'position' => 58,
            ];
        }


        if (WPMLChecker::isActive()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('WPML', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('WPML', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/wpml',
                'template' => 'app',
                'position' => 58,
            ];
        }

        if (PolylangChecker::isActive()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Polylang', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Polylang', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/polylang',
                'template' => 'app',
                'position' => 59,
            ];
        }

        if (Features::hasLogs()) {
            $pages[] = [
                'parentSlug' => ACPT_PLUGIN_NAME,
                'pageTitle' => translate('Logs', ACPT_PLUGIN_NAME),
                'menuTitle' => translate('Logs', ACPT_PLUGIN_NAME),
                'capability' => 'manage_options',
                'menuSlug' => ACPT_PLUGIN_NAME . '#/logs',
                'template' => 'app',
                'position' => 60,
            ];
        }

        $pages[] = [
            'parentSlug' => ACPT_PLUGIN_NAME,
            'pageTitle' => translate('Tools', ACPT_PLUGIN_NAME),
            'menuTitle' => translate('Tools', ACPT_PLUGIN_NAME),
            'capability' => 'manage_options',
            'menuSlug' => ACPT_PLUGIN_NAME . '#/tools',
            'template' => 'app',
            'position' => 61,
        ];

        $pages[] = [
            'parentSlug' => ACPT_PLUGIN_NAME,
            'pageTitle' => translate('Settings', ACPT_PLUGIN_NAME),
            'menuTitle' => translate('Settings', ACPT_PLUGIN_NAME),
            'capability' => 'manage_options',
            'menuSlug' => ACPT_PLUGIN_NAME . '#/settings',
            'template' => 'app',
            'position' => 62,
        ];

        $pages[] = [
            'parentSlug' => ACPT_PLUGIN_NAME,
            'pageTitle' => translate('License', ACPT_PLUGIN_NAME),
            'menuTitle' => translate('License', ACPT_PLUGIN_NAME),
            'capability' => 'manage_options',
            'menuSlug' => ACPT_PLUGIN_NAME . '#/license',
            'template' => 'app',
            'position' => 63,
        ];

        $this->pages = $pages;
    }

    public function addPages(): void
    {
        foreach ($this->pages as $page) {
            $this->addPage(
                $page['pageTitle'],
                $page['menuTitle'],
                $page['capability'],
                $page['menuSlug'],
                $page['template'],
                (isset($page['iconUrl'])) ? $page['iconUrl'] : null,
                (isset($page['position'])) ? $page['position'] : null,
                (isset($page['parentSlug'])) ? $page['parentSlug'] : null
            );
        }
    }

    /**
     * @param string      $pageTitle
     * @param string      $menuTitle
     * @param string      $capability
     * @param string      $menuSlug
     * @param string      $template
     * @param string|null $iconUrl
     * @param int|null    $position
     * @param string|null $parentSlug
     */
    private function addPage(string $pageTitle, string $menuTitle, string $capability, string $menuSlug, string $template, ?string $iconUrl = '', ?int $position = null, ?string $parentSlug = null): void
    {
        if ($parentSlug !== null) {
            add_submenu_page(
                $parentSlug,
                $pageTitle,
                $menuTitle,
                $capability,
                $menuSlug,
                function () use ($template) {
                    require_once plugin_dir_path(dirname(__FILE__)) . '../admin/templates/'.$template.'.php';
                },
                $position
            );
        } else {
            add_menu_page(
                $pageTitle,
                $menuTitle,
                $capability,
                $menuSlug,
                function () use ($template) {
                    require_once plugin_dir_path(dirname(__FILE__)) . '../admin/templates/'.$template.'.php';
                },
                $iconUrl,
                $position
            );
        }
    }

    public function enqueueAssets(): void
    {
        // Register assets
        $this->setApplicationAssets();
        $this->setGutenbergBlockAssets();
        $this->setAdminAssets();

        // Nothing above registered any ACPT asset for this screen, so there's
        // nothing here that needs the media picker either. Skips wp_enqueue_media()
        // (and the DB query it triggers) on unrelated wp-admin screens.
        if ( empty( $this->staticCssAssets ) && empty( $this->staticJsAssets ) && ! $this->isACPTAppPage() ) {
            return;
        }

        // Register media
        if (! function_exists('wp_enqueue_media')) {
            require ABSPATH . 'wp-admin/includes/media.php';
        }

        wp_enqueue_media();

        // Enqueue registered CSS assets
        foreach ($this->staticCssAssets as $key => $asset) {
            wp_enqueue_style(ACPT_PLUGIN_NAME.'__'.$key, $asset, [], ACPT_PLUGIN_VERSION, 'all');
        }

        // Enqueue registered JS assets
        foreach ($this->staticJsAssets as $key => $asset) {
            if ($asset['module'] === true) {

                // modules
                if (isset($asset['modules']) && is_array($asset['modules'])) {
                    foreach ($asset['modules'] as $module) {
                        wp_register_script_module($module['id'], $module['path']);
                    }
                }

                wp_enqueue_script_module(ACPT_PLUGIN_NAME.'__'.$key, $asset['path'], isset($asset['dep']) ? $asset['dep'] : [], ACPT_PLUGIN_VERSION);
            } else {
                wp_enqueue_script(ACPT_PLUGIN_NAME.'__'.$key, $asset['path'], isset($asset['dep']) ? $asset['dep'] : [], ACPT_PLUGIN_VERSION, true);
            }
        }

        // Validator
        if ($this->pagenow === 'post-new.php' || $this->pagenow === 'post.php') {
            $customPostTypeMetaBoxGenerator = new CustomPostTypeMetaBoxGenerator();
            $customPostTypeMetaBoxGenerator->enqueueScripts('save-cpt');
        }
    }

    /**
     * WP core's wp_enqueue_media() runs an uncached "SELECT DISTINCT YEAR/MONTH ...
     * WHERE post_type = 'attachment'" query on every single call to populate the
     * media library's date-filter dropdown (see the `media_library_months_with_files`
     * filter doc in wp-includes/media.php, and https://core.trac.wordpress.org/ticket/31071).
     * Core provides this filter specifically so plugins can bypass that query; we
     * serve a transient instead and only recompute it when the media library changes.
     *
     * @param array<array<string, int>>|null $months
     * @return array<array<string, int>>
     */
    public function getCachedMediaLibraryMonths(?array $months): array
    {
        if (is_array($months)) {
            return $months;
        }

        $cached = get_transient('acpt_media_library_months');

        if ($cached !== false) {
            return $cached;
        }

        global $wpdb;

        $months = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT YEAR( post_date ) AS year, MONTH( post_date ) AS month
                FROM $wpdb->posts
                WHERE post_type = %s
                ORDER BY post_date DESC",
                'attachment'
            )
        );

        set_transient('acpt_media_library_months', $months, DAY_IN_SECONDS);

        return $months;
    }

    /**
     * Invalidate the media library months cache whenever an attachment is added, edited or deleted
     */
    public function invalidateMediaLibraryMonthsCache(): void
    {
        delete_transient('acpt_media_library_months');
    }

    private function setApplicationAssets(): void
    {
        if ($this->isACPTAppPage()) {
            $viteAssets = Assets::load('assets/src/App/index.jsx', 'acpt_app');

            foreach ($viteAssets['css'] as $viteCssAssetKey => $viteCssAsset) {
                $this->staticCssAssets[$viteCssAssetKey] = $viteCssAsset;
            }

            foreach ($viteAssets['js'] as $viteJsAssetKey => $viteJsAsset) {
                wp_localize_script(ACPT_PLUGIN_NAME.'__'.$viteJsAssetKey, 'acpt', ['pluginsUrl' => plugins_url()]);
                $this->staticJsAssets[$viteJsAssetKey] = [
                        'path' => $viteJsAsset,
                        'module' => true,
                        'dep'  => [],
                ];
            }
        }
    }

    private function setGutenbergBlockAssets(): void
    {
        $screen = get_current_screen();

        if ($screen !== null && $screen->is_block_editor === true) {
            $viteAssets = Assets::load('assets/src/Gutenberg/index.jsx', 'block_js');

            foreach ($viteAssets['css'] as $viteCssAssetKey => $viteCssAsset) {
                $this->staticCssAssets[$viteCssAssetKey] = $viteCssAsset;
            }

            foreach ($viteAssets['js'] as $viteJsAssetKey => $viteJsAsset) {
                $this->staticJsAssets[$viteJsAssetKey] = [
                        'path' => $viteJsAsset,
                        'module' => true,
                        'dep'  => [],
                ];
            }
        }
    }

    private function setAdminAssets(): void
    {
        // check option pages
        if ($this->pagenow === 'admin.php' && isset($_GET['page']) && !in_array($_GET['page'], OptionPageRepository::getAllSlugs())) {
            // Exclude table record pages when action is 'list' (only load for edit/new)
            $pageParam = (string)$_GET['page'];
            $actionParam = $_GET['action'] ?? 'list';

            if (strpos($pageParam, 'acpt-table-') === 0 && $actionParam === 'list') {
                return;
            }

            // Skip for non-option, non-table pages
            if (strpos($pageParam, 'acpt-table-') !== 0) {
                return;
            }
        }

        // allowed pages
        $allowedPages = [
            'site-editor.php',
            'post-new.php',
            'edit.php',
            'post.php',
            'profile.php',
            'user-edit.php',
            'edit-tags.php',
            'term.php',
            'upload.php',
            'admin.php',
            'comment.php',
            'edit-comments.php',
        ];

        // Option pages can be parented under any native WP admin page (options-general.php,
        // themes.php, users.php, tools.php, etc.) via the "Parent WP admin menu" select, so a
        // fixed $allowedPages list can never cover every possible parent. Detect this case
        // generically by checking the requested page slug against every registered option page,
        // regardless of which native file hosts it.
        $isOptionPageRequest = isset($_GET['page']) && in_array($_GET['page'], OptionPageRepository::getAllSlugs());

        if (
            (in_array($this->pagenow, $allowedPages) || $isOptionPageRequest) &&
            !$this->isACPTAppPage()
        ) {
            // CSS
            $this->staticCssAssets = [
                'admin_selectize_css' => plugins_url('advanced-custom-post-type/assets/vendor/selectize/selectize.default.min.css'),
                'admin_css' => $this->assetPath("admin.css"),
            ];

            // JS
            $this->staticJsAssets['admin_selectize_js'] = [
                'path' => plugins_url('advanced-custom-post-type/assets/vendor/selectize/selectize.min.js'),
                'module' => false,
                'dep'  => [],
            ];

            $this->staticJsAssets['admin_js'] = [
                'path' => $this->assetPath("admin.js"),
                'module' => true,
                'modules' => [
                    [
                            'id' => 'admin_cct_js',
                            'path' => $this->assetPath("_admin_cct.js"),
                    ],
                    [
                        'id' => 'admin_colorpicker_js',
                        'path' => $this->assetPath("_admin_colorpicker.js"),
                    ],
                    [
                        'id' => 'admin_commons_js',
                        'path' => $this->assetPath("_admin_commons.js"),
                    ],
                    [
                        'id' => 'admin_datepicker_js',
                        'path' => $this->assetPath("_admin_datepicker.js"),
                    ],
                    [
                        'id' => 'admin_editor_js',
                        'path' => $this->assetPath("_admin_editor.js"),
                    ],
                    [
                        'id' => 'admin_file_js',
                        'path' => $this->assetPath("_admin_file.js"),
                    ],
                    [
                        'id' => 'admin_flexible_js',
                        'path' => $this->assetPath("_admin_flexible.js"),
                    ],
                    [
                        'id' => 'admin_helpers_js',
                        'path' => $this->assetPath("_admin_helpers.js"),
                    ],
                    [
                        'id' => 'admin_iconpicker_js',
                        'path' => $this->assetPath("_admin_iconpicker.js"),
                    ],
                    [
                        'id' => 'admin_list_js',
                        'path' => $this->assetPath("_admin_list.js"),
                    ],
                    [
                        'id' => 'admin_media_js',
                        'path' => $this->assetPath("_admin_media.js"),
                    ],
                    [
                        'id' => 'admin_misc_js',
                        'path' => $this->assetPath("_admin_misc.js"),
                    ],
                    [
                        'id' => 'admin_relational_js',
                        'path' => $this->assetPath("_admin_relational.js"),
                    ],
                    [
                        'id' => 'admin_repeater_js',
                        'path' => $this->assetPath("_admin_repeater.js"),
                    ],
                    [
                        'id' => 'admin_sortable_js',
                        'path' => $this->assetPath("_admin_sortable.js"),
                    ],
                    [
                        'id' => 'admin_woocommerce_js',
                        'path' => $this->assetPath("_admin_woocommerce.js"),
                    ],
                ],
                'dep'  => [
                    'admin_colorpicker_js',
                    'admin_commons_js',
                    'admin_datepicker_js',
                    'admin_editor_js',
                    'admin_file_js',
                    'admin_flexible_js',
                    'admin_helpers_js',
                    'admin_iconpicker_js',
                    'admin_list_js',
                    'admin_media_js',
                    'admin_misc_js',
                    'admin_relational_js',
                    'admin_repeater_js',
                    'admin_sortable_js',
                    'admin_woocommerce_js',
                ],
            ];

            if ($this->pagenow === "edit-comments.php") {
                $this->staticJsAssets['comment_quick_edit_js'] = [
                    'path' => $this->assetPath("comment-quick-edit.js"),
                    'module' => false,
                    'dep'  => [],
                ];
            }

            if ($this->pagenow === 'edit.php') {
                $this->staticJsAssets['quick_edit_js'] = [
                    'path' => $this->assetPath('quick_edit.js'),
                    'module' => false,
                    'dep'  => [],
                ];
            }

            //
            // =================================
            // WP DEFAULT UTILITIES
            // =================================
            //

            // color picker
            wp_enqueue_style('wp-color-picker');
            wp_enqueue_script('wp-color-picker');

            // codemirror
            $cm_settings['codeEditor'] = wp_enqueue_code_editor(array('type' => 'text/html'));
            wp_localize_script('jquery', 'cm_settings', $cm_settings);
            wp_enqueue_script('wp-theme-plugin-editor');
            wp_enqueue_style('wp-codemirror');

            //
            // =================================
            // ICONIFY
            // =================================
            //
            wp_register_script('iconify', plugins_url('advanced-custom-post-type/assets/vendor/iconify/iconify.min.js'));
            wp_enqueue_script('iconify');
        }
    }

    /**
     * @param string $asset
     * @return string
     */
    private function assetPath(string $asset): string
    {
        $pathinfo = pathinfo($asset);
        $extension = isset($pathinfo['extension']) ? $pathinfo['extension'] : '' ;
        $filename = $pathinfo['filename'];
        $baseDir = 'advanced-custom-post-type/assets/static/';

        // @phpstan-ignore-next-line ternary.alwaysFalse
        return plugins_url(ACPT_DEV_MODE ? $baseDir.$extension.'/'.$filename.'.'.$extension : $baseDir.$extension.'/'.$filename.'.min.'.$extension);
    }

    /**
     * @param string   $new_status
     * @param string   $old_status
     * @param \WP_Post $post
     */
    public function invalidPostIdsCache(string $new_status, string $old_status, \WP_Post $post): void
    {
        $allowedStatus = [
            'draft',
            'publish',
            'private',
            'auto-draft',
            'inherit'
        ];

        if (
            in_array($new_status, $allowedStatus) &&
            in_array($old_status, $allowedStatus)
        ) {
            ACPT_DB::invalidateCacheTag(CustomPostTypeMetaGroupsGenerator::class);
        }
    }

    /**
     * @return void
     */
    public function addFilters(): void
    {
        add_filter('plugin_action_links', [ $this, 'addPluginLinks' ], PHP_INT_MAX, 2);
        add_filter('script_loader_tag', [$this, 'addAsyncDeferAttribute'], 10, 2);
        add_filter('block_categories_all', [$this, 'addGutenbergBlocks'], 10, 2);
        add_filter('safe_style_css', [$this, 'allowCSSAttributes'], 10, 1);
        add_filter('kses_allowed_protocols', [$this, 'addDataProtocol'], 10, 1);
    }

    /**
     * @see https://wordpress.stackexchange.com/questions/173526/why-is-wp-kses-not-keeping-style-attributes-as-expected/195433#195433
     *
     * @param array<int, string> $styles
     * @return array<int, string>
     */
    public function allowCSSAttributes(array $styles): array
    {
        $styles[] = 'fill';
        $styles[] = 'transform';

        return $styles;
    }

    /**
     * @param array<int, string> $protocols
     * @return array<int, string>
     */
    public function addDataProtocol(array $protocols): array
    {
        $protocols[] = 'data';

        return $protocols;
    }

    /**
     * @param array<string, string> $actions
     * @param string                $plugin_file
     * @return array<string, string>
     */
    public function addPluginLinks(array $actions, string $plugin_file): array
    {
        $actionLinks = [];

        if ('advanced-custom-post-type/advanced-custom-post-type.php' === $plugin_file) {
            $actionLinks['settings'] = '<a href="'.admin_url('admin.php?page='.ACPT_PLUGIN_NAME.'#/settings').'">'.Translator::translate('Settings').'</a>';
            $actionLinks['documentation'] = '<a target="_blank" href="https://docs.acpt.io/">'.Translator::translate('Documentation').'</a>';
        }

        return array_merge($actionLinks, $actions);
    }

    /**
     * @param array<int, mixed>             $block_categories
     * @param \WP_Block_Editor_Context|null $block_editor_context
     * @return array<int, mixed>
     */
    public function addGutenbergBlocks(array $block_categories, ?\WP_Block_Editor_Context $block_editor_context = null): array
    {
        if (empty($block_editor_context)) {
            return $block_categories;
        }

        $category_slugs = wp_list_pluck($block_categories, 'slug');

        return in_array('advanced-custom-post-type-blocks', $category_slugs, true) ? $block_categories : array_merge(
            $block_categories,
            [
                [
                    'slug'  => 'advanced-custom-post-type-blocks',
                    'title' => __('ACPT Blocks', 'advanced-custom-post-type-blocks'),
                    'icon'  => null,
                ]
            ]
        );
    }

    /**
     * @param string $tag
     * @param string $handle
     * @return string
     */
    public function addAsyncDeferAttribute(string $tag, string $handle): string
    {
        if ('google-maps' !== $handle) {
            return $tag;
        }

        return str_replace(' src', ' async defer src', $tag);
    }

    /**
     * Add shortcodes
     *
     * @return void
     */
    private function addShortcodes(): void
    {
        add_shortcode('acpt', [new PostMetaShortcode(), 'render']);
        add_shortcode('acpt_user', [new UserMetaShortcode(), 'render']);
        add_shortcode('acpt_tax', [new TaxonomyMetaShortcode(), 'render']);
        add_shortcode('acpt_media', [new AttachmentMetaShortcode(), 'render']);
        add_shortcode('acpt_comm', [new CommentMetaShortcode(), 'render']);
        add_shortcode('acpt_wc_pa', [new WooCommerceProductAttributeShortcode(), 'render']);

        // @phpstan-ignore-next-line if.alwaysTrue
        if (ACPT_IS_LICENSE_VALID) {
            add_shortcode('acpt_form', [new FormShortcode(), 'render']);
            add_shortcode('acpt_cct', [new CctMetaShortcode(), 'render']);
            add_shortcode('acpt_option', [new OptionPageMetaShortcode(), 'render']);
        }
    }

    /**
     * @param bool $isACPTAppPage
     * @return void
     */
    private function addACTPClassToBody(bool $isACPTAppPage = false): void
    {
        if ($isACPTAppPage) {
            add_filter('admin_body_class', function ($classes) {
                $classes .= " acpt";

                if (Features::skin() === 'dark') {
                    $classes .= "-dark";
                }

                return $classes;
            });
        }
    }

    /**
     * @param bool $lazy
     * @throws \Exception
     */
    private function registerCustomPostTypesAndTaxonomies(bool $lazy = false): void
    {
        // run this code after all plugins are loaded
        try {
            $postTypeMetaGroups = [];

            // prevents any orphan meta box/field
            MetaRepository::removeOrphanBoxesAndFields();

            // generate meta groups
            if ($lazy === false) {

                // enable savePost function only on post and quick edit pages
                $allowedPages = [
                    'admin.php',
                    'admin-ajax.php',
                    'edit.php',
                    'post.php',
                    'post-new.php',
                    'upload.php',
                ];

                // enable rendering of meta fields only on post (or new post) page
                $metaRendering = in_array($this->pagenow, [
                    'post.php',
                    'post-new.php',
                    'upload.php',
                ]);

                $postTypeAssociatedWithGroup = $this->postTypeAndTaxonomyNamesArray['postTypeNames'] ?? [];
                $registeredACPTPostTypeNames = CustomPostTypeRepository::getNames();
                $postTypeNames = array_unique(array_merge($postTypeAssociatedWithGroup, $registeredACPTPostTypeNames));

                foreach ($postTypeNames as $postTypeName) {
                    if (is_string($postTypeName)) {
                        $metaGroupModels = (new FetchMetaGroupsQuery([
                            'belongsTo' => MetaTypes::CUSTOM_POST_TYPE,
                            'find' => $postTypeName,
                            'clonedFields' => true,
                            'cct' => true
                        ]))->execute();

                        if (!empty($metaGroupModels) && Features::hasMeta()) {
                            $postTypeMetaGroupsGenerator = new CustomPostTypeMetaGroupsGenerator($postTypeName, $metaGroupModels);
                            $postTypeMetaGroups[$postTypeName] = $postTypeMetaGroupsGenerator->generate($metaRendering);
                        }

                        // register the "save_post" hook for all custom post types
                        if (in_array($this->pagenow, $allowedPages)) {

                            // Handle save post functions
                            $metaGroups = $postTypeMetaGroups[$postTypeName] ?? [];

                            // can't use a filter here, because integration are not yet running
                            if (ACPT_WooCommerce::active() && $postTypeName === 'shop_order') {
                                $hookName = 'woocommerce_process_shop_order_meta';
                            } else {
                                $hookName = 'save_post_'.$postTypeName;
                            }

                            add_action($hookName, function ($postId) use ($metaGroups, $postTypeName) {
                                WPUtils::handleSavePost((int)$postId, $postTypeName, $metaGroups);
                            });
                        }
                    }
                }

                // Single transition_post_status listener replaces the 7 × N nested
                // admin_init → {status}_{posttype} loop that previously registered
                // one hook per (post type, status) pair.
                if (in_array($this->pagenow, $allowedPages) && !empty($postTypeNames)) {
                    $managedPostTypes = array_fill_keys(array_filter($postTypeNames, 'is_string'), true);
                    $statusesToFlush = ['trash', 'publish', 'pending', 'draft', 'delete', 'future', 'private'];

                    add_action('transition_post_status', function ($new_status, $old_status, $post) use ($managedPostTypes, $statusesToFlush) {
                        if (!$post || !isset($managedPostTypes[$post->post_type])) {
                            return;
                        }
                        if (in_array($new_status, $statusesToFlush, true) || in_array($old_status, $statusesToFlush, true)) {
                            Posts::invalidPostsByTypeQueryCache($post->post_type);
                            Posts::invalidCache();
                        }
                    }, 10, 3);
                }
            }

            // register here ACTP CPTs and Taxonomies
            foreach (CustomPostTypeRepository::get() as $postTypeModel) {
                $postTypeName = $postTypeModel->getName();
                $customPostType = new CustomPostTypeGenerator($postTypeModel);
            }

            // invalid attachments cache
            add_action("attachment_updated", function ($postId, $post_after, $post_before) {
                $attachment = WPAttachment::fromId($postId);

                WPAttachment::invalidCache($attachment->getId());
                WPAttachment::invalidCache($attachment->getSrc());
            }, 10, 3);

            // invalid comments cache on create, update, delete
            add_action('comment_post', function () {
                Comments::invalidCache();
            }, 10, 0);
            add_action('edit_comment', function () {
                Comments::invalidCache();
            }, 10, 0);
            add_action('deleted_comment', function () {
                Comments::invalidCache();
            }, 10, 0);
            add_action('wp_set_comment_status', function () {
                Comments::invalidCache();
            }, 10, 0);
        } catch (\Exception $exception) {
            // do nothing
            do_action("acpt/error", $exception);
        }
    }

    private function registerCommentMeta(): void
    {
        (new CommentMetaGroupsGenerator())->generate();
    }

    private function addCommentColumnsToAdminPanel(): void
    {
        CommentAdminColumnsGenerator::addColumns();
    }

    /**
     * @throws \Exception
     */
    private function registerTaxonomyMeta(): void
    {
        (new TaxonomyMetaGroupsGenerator())->generate();
    }

    /**
     * @throws \Exception
     */
    private function addCustomPostTypeColumnsToAdminPanel(): void
    {
        $acptPostTypes = CustomPostTypeRepository::get();
        $postTypesAssociatedWithGroup = $this->postTypeAndTaxonomyNamesArray['postTypeNames'] ?? [];
        $notACPTPostTypes = $postTypesAssociatedWithGroup;

        foreach ($acptPostTypes as $postTypeModel) {
            CustomPostTypeAdminColumnsGenerator::addColumns($postTypeModel);

            if (($key = array_search($postTypeModel->getName(), $notACPTPostTypes)) !== false) {
                unset($notACPTPostTypes[$key]);
            }
        }

        foreach ($notACPTPostTypes as $notACPTPostType) {
            if (is_string($notACPTPostType)) {
                CustomPostTypeAdminColumnsGenerator::addColumns($notACPTPostType);
            }
        }
    }

    /**
     * @throws \Exception
     */
    private function addTaxonomyColumnsToAdminPanel(): void
    {
        $acptTaxonomies = TaxonomyRepository::get();
        $taxonomiesAssociatedWithGroup = $this->postTypeAndTaxonomyNamesArray['taxonomyNames'] ?? [];
        $notACPTTaxonomies = $taxonomiesAssociatedWithGroup;

        foreach ($acptTaxonomies as $taxonomyModel) {
            TaxonomyAdminColumnsGenerator::addColumns($taxonomyModel);

            if (($key = array_search($taxonomyModel->getSlug(), $notACPTTaxonomies)) !== false) {
                unset($notACPTTaxonomies[$key]);
            }
        }

        foreach ($notACPTTaxonomies as $notACPTTaxonomy) {
            if (is_string($notACPTTaxonomy)) {
                TaxonomyAdminColumnsGenerator::addColumns($notACPTTaxonomy);
            }
        }
    }

    /**
     * @throws \Exception
     */
    private function registerUserMeta(): void
    {
        (new UserMetaGroupsGenerator())->generate();
    }

    private function addUserMetaColumnsToShow(): void
    {
        UserAdminColumnsGenerator::addColumns();
    }

    /**
     * @param bool $lazy
     * @throws \Exception
     */
    private function registerOptionPages(bool $lazy = false): void
    {
        $optionPages = OptionPageRepository::get([]);

        foreach ($optionPages as $optionPage) {
            $optionPageGenerator = new OptionPageGenerator($this->loader, $optionPage, $lazy);
            $optionPageGenerator->registerPage();
        }
    }

    /**
     * @return void
     * @throws \Exception
     */
    private function registerTableAdminPages(): void
    {
        // Menu registration must see newly-created tables immediately — a
        // stale cache here would leave the table's admin page unregistered
        // until the TTL expires, and wp-admin 500s on it. Freshness is
        // guaranteed by TableRepository's own reliable, key-based cache
        // invalidation on save()/delete() (see invalidateUnfilteredCache()),
        // not by bypassing the cache here.
        $tables = TableRepository::get([]);

        foreach ($tables as $table) {
            $generator = new TableRecordPageGenerator($this->loader, $this->request, $table, $this->isACPTAppPage());
            $generator->registerPage();
        }
    }

    /**
     * @return void
     */
    private function registerRestFields(): void
    {
        $this->loader->addAction('rest_api_init', new ACPT_Api_Rest_Fields($this->request), 'registerRestFields');
    }

    /**
     * @return void
     */
    private function registerRestEndpoint(): void
    {
        $this->loader->addAction('rest_api_init', new ACPT_Api_V1($this->request), 'registerRestRoutes');
    }

    /**
     * @return void
     */
    private function registerRolesAndSetPermissions(): void
    {
        $this->loader->addAction('admin_init', new ACPT_Permissions(), 'setPermissions', 999);
    }

    /**
     * @return void
     */
    private function includeFunctions(): void
    {
        require_once ACPT_PLUGIN_DIR_PATH.'/functions/acpt_functions.php';
    }

    /**
     * @return void
     */
    private function runIntegrations(): void
    {
        $integrations = [
            ACPT_AbilitiesAPI::class,
            ACPT_ACFW::class,
            ACPT_Breakdance::class,
            ACPT_Bricks::class,
            ACPT_Divi::class,
            ACPT_Etch::class,
            ACPT_Elementor::class,
            ACPT_Elementor_Pro::class,
            ACPT_FacetWP::class,
            ACPT_GenerateBlocks::class,
            ACPT_Gutenberg::class,
            ACPT_Oxygen::class,
            ACPT_Polylang::class,
            ACPT_RankMath::class,
            ACPT_SeoPress::class,
            ACPT_SlimSeo::class,
            ACPT_WooCommerce::class,
            ACPT_WPAllExport::class,
            ACPT_WPAllImport::class,
            ACPT_WPGraphQL::class,
            ACPT_WPGridBuilder::class,
            ACPT_WPML::class,
            ACPT_Yoast::class,
            ACPT_Zion::class,
        ];

        foreach ($integrations as $integration) {
            $instance = new $integration();

            $instance->run(ACPT_Plugin::getRequest());

            Profiler::lap('runIntegrations');
        }
    }

    /**
     * @param resource $curlhandle
     */
    public function curlBeforeRequest($curlhandle): void
    {
        Session::close();
    }

    /**
     * @param int $timeout
     * @return int
     */
    public function extendHttpRequestTimeout(int $timeout): int
    {
        return 30; // seconds
    }

    public function fetchAdminMenu(): void
    {
        $home = get_option('home');
        $pluginsUrl = plugins_url();

        if (Server::isSecure()) {
            $home = Url::secureUrl($home);
            $pluginsUrl = Url::secureUrl($pluginsUrl);
        }

        wp_register_script('globals-menu-run', '', [], '', true);
        wp_enqueue_script('globals-menu-run');

        $menuJson = json_encode($GLOBALS['menu']);
        $menuJsonString = is_string($menuJson) ? $menuJson : '[]';

        wp_add_inline_script('globals-menu-run', '
            document.globals = {
                site_url: "'.$home.'", 
                plugins_url: "'.$pluginsUrl.'", 
                menu: '. $menuJsonString .', 
                google_maps_key: "'.($this->googleMapsApiKey !== null ? $this->googleMapsApiKey : "").'",
                google_sheets_key: "'.($this->googleSheetsKey  !== null ? $this->googleSheetsKey : "").'",
                nonce: "'.Nonce::create().'"
            };
		');
    }

    /**
     * @return bool
     */
    private function isACPTAppPage(): bool
    {
        return (
            $this->pagenow === 'admin.php' &&
            isset($_GET['page']) &&
            $_GET['page'] === ACPT_PLUGIN_NAME
        );
    }

    public function displayNotice(): void
    {
        $messages = Cookie::get(Cookies::ACPT_ERRORS);

        if (!empty($messages)) {
            foreach ($messages as $message) {
                add_action('admin_notices', function () use ($message) {
                    ?>
                    <div id="acpt-message-<?php echo Strings::generateRandomId(); ?>" class="notice notice-<?php echo $message['level']; ?> is-dismissible">
                        <p><?php echo $message['message']; ?></p>
                    </div>
                    <?php
                });
            }

            Cookie::delete(Cookies::ACPT_ERRORS);
        }
    }

    /**
     * @throws \Exception
     */
    public function run(): void
    {
        $isACPTAppPage  = $this->isACPTAppPage();

        $this->displayNotice();

        // filters
        Profiler::start('addFilters');
        $this->addFilters();
        Profiler::stop('addFilters');

        // pages and assets
        Profiler::start('addPages');
        $this->loader->addAction('admin_menu', $this, 'addPages');
        Profiler::stop('addPages');

        Profiler::start('enqueueAssets');
        $this->loader->addAction('admin_enqueue_scripts', $this, 'enqueueAssets');
        Profiler::stop('enqueueAssets');

        // cache the media library "date filter" dropdown data that wp_enqueue_media()
        // otherwise recomputes with an uncached DB query on every call
        Profiler::start('cacheMediaLibraryMonths');
        add_filter('media_library_months_with_files', [$this, 'getCachedMediaLibraryMonths']);
        $this->loader->addAction('add_attachment', $this, 'invalidateMediaLibraryMonthsCache');
        $this->loader->addAction('edit_attachment', $this, 'invalidateMediaLibraryMonthsCache');
        $this->loader->addAction('delete_attachment', $this, 'invalidateMediaLibraryMonthsCache');
        Profiler::stop('cacheMediaLibraryMonths');

        // admin menu
        if (Features::hasAdminMenu()) {
            Profiler::start('generateAdminBarMenu');
            $this->loader->addAction('admin_bar_menu', new ACPT_Admin_Bar_Menu(), 'generate', 100);
            Profiler::stop('generateAdminBarMenu');
        }

        // admin_bar_menu
        Profiler::start('fetchAdminMenu');
        $this->loader->addAction('admin_menu', $this, 'fetchAdminMenu');
        Profiler::start('fetchAdminMenu');

        // register block bindings
        Profiler::start('addGutenbergBlockBindings');
        $this->loader->addAction('init', new ACPT_Block_Bindings(), 'register');
        Profiler::stop('addGutenbergBlockBindings');

        // register roles and set permissions
        Profiler::start('registerRolesAndSetPermissions');
        $this->registerRolesAndSetPermissions();
        Profiler::stop('registerRolesAndSetPermissions');

        // run the application
        Profiler::start('transitionPostStatus');
        $this->loader->addAction('transition_post_status', $this, 'invalidPostIdsCache', 10, 3);
        Profiler::stop('transitionPostStatus');

        Profiler::start('siteHealth');
        $this->loader->addAction('requests-curl.before_request', $this, 'curlBeforeRequest', 9999);
        $this->loader->addAction('http_request_timeout', $this, 'extendHttpRequestTimeout');
        Profiler::stop('siteHealth');

        // ajax calls
        Profiler::start('ajaxCalls');

        foreach ($this->ajax->routes() as [$action, $controllerClass, $method, $middlewares]) {

            /** @var AbstractController $controller */
            $controller = new $controllerClass($this->request);

            if (is_callable([$controller, $method])) {
                $controller->setAction($action);
                $controller->setMethod($method);

                foreach ($middlewares as $middleware) {
                    $controller->addMiddleware($middleware);
                }

                $this->loader->addAction($action, $controller, 'handleRequest');
                Profiler::lap('ajaxCalls');
            }
        }

        Profiler::stop('ajaxCalls');

        // register custom post types and taxonomies. Lazy load custom post type metas
        Profiler::start('registerCustomPostTypesAndTaxonomies');
        $this->registerCustomPostTypesAndTaxonomies($isACPTAppPage);
        Profiler::stop('registerCustomPostTypesAndTaxonomies');

        // Resister custom admin pages
        if(is_admin()) {

            // add option pages
            if (Features::hasPages()) {

                Profiler::start('registerOptionPages');
                $this->registerOptionPages($this->isACPTAppPage());
                Profiler::stop('registerOptionPages');
            }

            // add table admin pages
            if (Features::hasCct()) {

                Profiler::start('registerTableAdminPages');
                $this->registerTableAdminPages();
                Profiler::stop('registerTableAdminPages');
            }
        }

        // API REST
        Profiler::start('RestFieldsAndEndpoints');
        $this->registerRestFields();
        $this->registerRestEndpoint();
        Profiler::stop('RestFieldsAndEndpoints');

        // add ACPT class body
        if (is_admin()) {
            Profiler::start('addACTPClassToBody');
            $this->addACTPClassToBody($isACPTAppPage);
            Profiler::stop('addACTPClassToBody');
        }

        // lazy load, these functions are not needed in App page
        if (!$isACPTAppPage) {

            // shortcodes
            Profiler::start('addShortcodes');
            $this->addShortcodes();
            Profiler::stop('addShortcodes');

            if (Features::hasMeta()) {

                // register comments meta
                Profiler::start('registerCommentMeta');
                $this->registerCommentMeta();
                Profiler::stop('registerCommentMeta');

                // add columns to show in the list panel
                if (is_admin()) {
                    Profiler::start('addCommentColumnsToAdminPanel');
                    $this->addCommentColumnsToAdminPanel();
                    Profiler::stop('addCommentColumnsToAdminPanel');
                }

                // register taxonomy meta
                Profiler::start('registerTaxonomyMeta');
                $this->registerTaxonomyMeta();
                Profiler::stop('registerTaxonomyMeta');

                // add columns to show in the CPT list panel
                if (is_admin()) {
                    Profiler::start('addCustomPostTypeColumnsToAdminPanel');
                    $this->addCustomPostTypeColumnsToAdminPanel();
                    Profiler::stop('addCustomPostTypeColumnsToAdminPanel');

                    // add columns to show in the taxonomy list panel
                    Profiler::start('addTaxonomyColumnsToAdminPanel');
                    $this->addTaxonomyColumnsToAdminPanel();
                    Profiler::stop('addTaxonomyColumnsToAdminPanel');
                }

                // register user meta
                Profiler::start('registerUserMeta');
                $this->registerUserMeta();
                Profiler::stop('registerUserMeta');

                // add user meta columns to show in the admin panel
                if (is_admin()) {
                    Profiler::start('addUserMetaColumnsToShow');
                    $this->addUserMetaColumnsToShow();
                    Profiler::stop('addUserMetaColumnsToShow');
                }
            }

            // functions and hooks
            Profiler::start('includeFunctions');
            $this->includeFunctions();
            Profiler::stop('includeFunctions');

            // run integrations
            Profiler::start('runIntegrations');
            $this->runIntegrations();
            Profiler::stop('runIntegrations');
        }
    }
}
