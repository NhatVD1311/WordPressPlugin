<?php

namespace ACPT\Admin;

use ACPT\Core\Helper\Features;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\DatasetRepository;
use ACPT\Core\Repository\DynamicBlockRepository;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Core\Repository\WooCommerceProductDataRepository;
use ACPT\Integrations\WooCommerce\ACPT_WooCommerce;
use ACPT\Utils\Http\ACPTApiClient;
use ACPT\Utils\Wordpress\Transient;

class ACPT_Updater
{
    /**
     * @var string
     */
    private string $file;

    /**
     * @var array<string, mixed>
     */
    private array $plugin = [];

    /**
     * @var string|null
     */
    private ?string $basename = null;

    /**
     * @var bool
     */
    private bool $active = true;

    public function __construct(string $file)
    {
        $this->file = $file;
        add_action('admin_init', [ $this, 'setPluginProperties' ]);
    }

    /**
     * @return void
     */
    public function setPluginProperties(): void
    {
        $this->plugin   = get_plugin_data($this->file);
        $this->basename = plugin_basename($this->file);
        $this->active   = is_plugin_active($this->basename);
    }

    /**
     * @return void
     */
    public function initialize(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [ $this, 'modifyTransient' ], 10, 1);
        add_filter('plugins_api', [ $this, 'pluginPopup' ], 10, 3);
        add_filter('upgrader_post_install', [ $this, 'afterInstall' ], 10, 3);
        add_filter('http_request_args', [ $this, 'boostAcptIoTimeout' ], 10, 2);

        // Schedule daily insights via WP-Cron (jitter spreads installs across a 30-min window).
        if (! wp_next_scheduled('acpt_send_insights')) {
            wp_schedule_event(time() + rand(0, 1800), 'daily', 'acpt_send_insights');
        }
        add_action('acpt_send_insights', [ $this, 'sendInsights' ]);
    }

    /**
     * Wraps the ACPT_IS_LICENSE_VALID constant behind a filter so PHPUnit can
     * exercise both the valid- and invalid-license branches of modifyTransient()/
     * pluginPopup() without redefining the constant itself (which is fixed once
     * at plugin boot for the whole process).
     *
     * @return bool
     */
    private function licenseIsValid(): bool
    {
        // @phpstan-ignore-next-line booleanNot.alwaysFalse
        return (bool) apply_filters('acpt/license/is_valid', ACPT_IS_LICENSE_VALID);
    }

    /**
     * @param object $transient
     *
     * @return object
     * @throws \Exception
     */
    public function modifyTransient(object $transient): object
    {
        if (!$this->licenseIsValid()) {
            return $transient;
        }

        if (
            property_exists($transient, 'checked') &&
            property_exists($transient, 'response')
        ) {
            if ($checked = $transient->checked) {
                $pluginInfo = $this->getPluginInfo();

                if (empty($this->plugin)) {
                    $this->plugin = get_plugin_data($this->file);
                }

                if (is_array($pluginInfo) && isset($pluginInfo['version'])) {
                    $version = $pluginInfo['version'];
                    $version = str_replace(['v.', 'v'], '', $version);

                    $outOfDate = version_compare($version, $this->plugin["Version"], 'gt');
                    if ($outOfDate) {
                        $newFiles = ACPT_License_Manager::getDownloadLink($version);
                        $slug = !empty($this->basename) ? current(explode('/', $this->basename)) : "";

                        $plugin = [
                            'url' => $this->plugin["PluginURI"],
                            'slug' => $slug,
                            'package' => $newFiles,
                            'new_version' => $version,
                            'plugin' => $this->basename,
                        ];

                        $transient->response[ $this->basename ] = (object) $plugin;
                    }
                }
            }
        }

        return $transient;
    }

    /**
     * @param mixed  $result
     * @param string $action
     * @param object $args
     * @return mixed
     * @throws \Exception
     */
    public function pluginPopup($result, string $action, object $args)
    {
        if ($this->licenseIsValid() && ! empty($args->slug)) {
            if ($args->slug == current(explode('/', $this->basename))) {
                if (empty($this->plugin)) {
                    $this->plugin = get_plugin_data($this->file);
                }

                $pluginInfo = $this->getPluginInfo();

                if (empty($pluginInfo)) {
                    return $result;
                }

                $version = $pluginInfo['version'];
                $version = str_replace(['v.', 'v'], '', $version);
                $downloadLink = ACPT_License_Manager::getDownloadLink($version);
                $updates = '<div><h3>ACPT v'.$version.'</h3><p>If you can\'t automatically update the plugin, you can download it here and manually load it on your website.</p> <a href="'
                        .$downloadLink.'">Download here</a></div>';

                $plugin = [
                    'name'              => $this->plugin["Name"],
                    'slug'              => $this->basename,
                    'version'           => $version,
                    'author'            => $this->plugin["AuthorName"],
                    'author_profile'    => $this->plugin["AuthorURI"],
                    'last_updated'      => $pluginInfo['published_at'],
                    'homepage'          => $this->plugin["PluginURI"],
                    'short_description' => $this->plugin["Description"],
                    'sections'          => [
                        'Description'   => $this->plugin["Description"],
                        'Updates'       => $updates,
                    ],
                    'download_link'     => $downloadLink
                ];

                return (object)$plugin;
            }
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $args
     * @param string               $url
     * @return array<string, mixed>
     */
    public function boostAcptIoTimeout(array $args, string $url): array
    {
        if (strpos($url, 'acpt.io') !== false) {
            $floor = defined('ACPT_DOWNLOAD_TIMEOUT') ? (int) ACPT_DOWNLOAD_TIMEOUT : 120;
            if (empty($args['timeout']) || $args['timeout'] < $floor) {
                $args['timeout'] = $floor;
            }
        }

        return $args;
    }

    /**
     * @param mixed                $response
     * @param array<string, mixed> $hook_extra
     * @param array<string, mixed> $result
     * @return array<string, mixed>
     */
    public function afterInstall($response, array $hook_extra, array $result): array
    {
        global $wp_filesystem;

        $install_directory = plugin_dir_path($this->file);
        $wp_filesystem->move($result['destination'], $install_directory);
        $result['destination'] = $install_directory;

        if ($this->active) {
            activate_plugin($this->basename);
        }

        return $result;
    }

    /**
     * @return mixed
     */
    private function getPluginInfo()
    {
        $transientKey = 'advanced-custom-post-type-info';
        $cachedPluginInfo = get_transient($transientKey);
        $licenseActivation = ACPT_License_Manager::getLicense();
        $pluginInfo = [];

        if (false === $cachedPluginInfo || '' === $cachedPluginInfo) {
            try {
                $payload = [];
                if (!empty($licenseActivation) && isset($licenseActivation['user_id'])) {
                    $payload = [
                        'user_id' => $licenseActivation['user_id'],
                        'enable_beta' => Features::enableBeta(),
                    ];
                }

                $pluginInfo = ACPTApiClient::call('/plugin/fetch', $payload);
                Transient::set($transientKey, $pluginInfo, 3600);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
                Transient::set($transientKey, 'error', 60); // retry after 60s
            }

            return $pluginInfo;
        }

        return $cachedPluginInfo;
    }

    public function sendInsights(): void
    {
        $transientKey = 'advanced-custom-post-type-insights';
        $lockKey      = 'advanced-custom-post-type-insights-lock';

        if (false !== get_transient($transientKey)) {
            return;
        }

        // wp_cache_add is atomic: returns false if the key already exists.
        if (wp_cache_add($lockKey, 1, '', 30) === false) {
            return;
        }

        $licenseActivation = ACPT_License_Manager::getLicense();

        if (empty($licenseActivation)) {
            Transient::set($transientKey, [], 86400 + rand(0, 3600));
            wp_cache_delete($lockKey);
            return;
        }

        try {
            $insights = ACPTApiClient::call('/license/insights/send', [
                'id'       => $licenseActivation['activation_id'],
                'insights' => self::buildInsightsPayload(),
            ]);
            // Jitter: spread expiry times across installs to avoid synchronized floods.
            Transient::set($transientKey, $insights ?: [], 86400 + rand(0, 3600));
        } catch (\Exception $exception) {
            do_action('acpt/error', $exception);
            Transient::set($transientKey, [], 3600); // retry after 1 h on connection error
        } finally {
            wp_cache_delete($lockKey);
        }
    }

    /**
     * @return array<int, array<string, string>>
     */
    public static function buildInsightsPayload(): array
    {
        global $wpdb, $wp_version;

        $dbServerInfo = $wpdb->db_server_info();
        $dbEngine     = (stripos($dbServerInfo, 'mariadb') !== false) ? 'mariadb' : 'mysql';

        $payload = [
            [ 'key' => 'TIMESTAMP',        'value' => time() ],
            [ 'key' => 'WP_VERSION',       'value' => $wp_version ],
            [ 'key' => 'PHP_VERSION',      'value' => phpversion() ],
            [ 'key' => 'MYSQL_VERSION',    'value' => $wpdb->db_version() ],
            [ 'key' => 'DB_ENGINE',        'value' => $dbEngine ],
            [ 'key' => 'PLUGIN_VERSION',   'value' => ACPT_PLUGIN_VERSION ],
            [ 'key' => 'MULTISITE',        'value' => is_multisite() ? 'yes' : 'no' ],
            [ 'key' => 'ACTIVE_THEME',     'value' => get_stylesheet() ],
            [ 'key' => 'SERVER_SOFTWARE',  'value' => isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field($_SERVER['SERVER_SOFTWARE']) : '' ],
            [ 'key' => 'PHP_MEMORY_LIMIT', 'value' => ini_get('memory_limit') ],
        ];

        if (ACPT_WooCommerce::active() && defined('WC_VERSION')) {
            $payload[] = [ 'key' => 'WOOCOMMERCE_VERSION', 'value' => WC_VERSION ];
        }

        return array_merge($payload, self::buildFeatureUsagePayload());
    }

    /**
     * Feature-usage counters, isolated from buildInsightsPayload() so that
     * method stays focused on environment facts rather than product analytics.
     *
     * @return array<int, array<string, int|string>>
     */
    private static function buildFeatureUsagePayload(): array
    {
        $restEnabledCptCount = 0;
        foreach (CustomPostTypeRepository::get() as $cpt) {
            if (! empty($cpt->getSettings()['show_in_rest'])) {
                $restEnabledCptCount++;
            }
        }

        $restEnabledTaxonomyCount = 0;
        foreach (TaxonomyRepository::get() as $taxonomy) {
            if (! empty($taxonomy->getSettings()['show_in_rest'])) {
                $restEnabledTaxonomyCount++;
            }
        }

        $usage = [
            [ 'key' => 'CPT_COUNT',                   'value' => CustomPostTypeRepository::count() ],
            [ 'key' => 'TAXONOMY_COUNT',              'value' => TaxonomyRepository::count() ],
            [ 'key' => 'FIELD_GROUP_COUNT',           'value' => MetaRepository::count() ],
            [ 'key' => 'FORM_COUNT',                  'value' => FormRepository::count() ],
            [ 'key' => 'OPTION_PAGE_COUNT',           'value' => OptionPageRepository::count() ],
            [ 'key' => 'DATASET_COUNT',               'value' => DatasetRepository::count() ],
            [ 'key' => 'DYNAMIC_BLOCK_COUNT',         'value' => DynamicBlockRepository::count() ],
            [ 'key' => 'REST_ENABLED_CPT_COUNT',      'value' => $restEnabledCptCount ],
            [ 'key' => 'REST_ENABLED_TAXONOMY_COUNT', 'value' => $restEnabledTaxonomyCount ],
            [ 'key' => 'CCT_ENABLED',                 'value' => Features::hasCct() ? 'yes' : 'no' ],
        ];

        if (ACPT_WooCommerce::active()) {
            $usage[] = [ 'key' => 'WOOCOMMERCE_PRODUCT_DATA_COUNT', 'value' => WooCommerceProductDataRepository::count() ];
        }

        if (Features::hasCct()) {
            $usage[] = [ 'key' => 'TABLE_COUNT',       'value' => TableRepository::count() ];
            $usage[] = [ 'key' => 'TABLE_GROUP_COUNT', 'value' => TableGroupRepository::count() ];
        }

        return $usage;
    }

    /**
     * Fire-and-forget ping sent on plugin deactivation so the server can
     * distinguish "actively reporting" from "silently churned" installs.
     * Synchronous, short timeout, errors swallowed — must never block or
     * fatal the deactivation hook.
     */
    public static function sendDeactivationPing(): void
    {
        $licenseActivation = ACPT_License_Manager::getLicense();

        if (empty($licenseActivation) || empty($licenseActivation['activation_id'])) {
            return;
        }

        try {
            $insights   = self::buildInsightsPayload();
            $insights[] = [ 'key' => 'EVENT', 'value' => 'deactivated' ];

            ACPTApiClient::call('/license/insights/send', [
                'id'       => $licenseActivation['activation_id'],
                'insights' => $insights,
            ], 5);
        } catch (\Exception $exception) {
            do_action('acpt/error', $exception);
        }
    }
}
