<?php

namespace ACPT\Admin;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Utils\Wordpress\WPAttachment;

class ACPT_Block_Bindings
{
    /**
     * Registers block bindings for the 'acpt/field' block type.
     *
     * @return void
     */
    public function register(): void
    {
        if(!function_exists('register_block_bindings_source')){
            return;
        }

        register_block_bindings_source(
            'acpt/field',
            [
                'label'               => __( 'ACPT Custom Fields', ACPT_PLUGIN_NAME ),
                'get_value_callback'  => [$this, 'getValueCallback'],
                'uses_context'        => ['postId', 'termId']
            ]
        );
    }

    /**
     * Retrieves the value of a custom field from a specified source and context.
     *
     * Not restricted to any particular attribute name -- previously hardcoded to
     * only resolve an attribute literally named "content" (Paragraph/Heading's
     * text attribute), which meant this could only ever bind to that one
     * attribute anywhere in the editor. WP core's own bindings UI already only
     * offers a field for an attribute whose declared type matches the field's
     * getFieldsList() type, so there's no need to additionally gate by name here.
     *
     * @param array<string> $source_args The arguments specifying the source of the field,
     *                               including 'box', 'field' and 'belongsTo'/'find' keys.
     * @param \WP_Block $block_instance The block instance, including contextual data.
     * @param string $attributeName The name of the attribute being resolved. Ex. 'content'
     *
     * @return mixed|null Returns the value of the custom field if found; otherwise, null.
     */
    public function getValueCallback( array $source_args, \WP_Block $block_instance, string $attributeName )
    {
        $fieldModel = MetaRepository::getMetaFieldByName([
            'boxName' => $source_args['box'] ?? '',
            'fieldName' => $source_args['field'] ?? '',
        ]);

        if ($fieldModel === null || !self::isFieldBindingAllowed($fieldModel)) {
            return null;
        }

        $postId = $block_instance->context['postId'] ?? get_the_ID();
        $postId = !empty($postId) ? (int) $postId : null;

        $termId = $block_instance->context['termId'] ?? null;

        if ($termId === null) {
            $queriedObject = get_queried_object();

            if ($queriedObject instanceof \WP_Term) {
                $termId = $queriedObject->term_id;
            }
        }

        $termId = !empty($termId) ? (int) $termId : null;

        $args = self::resolveGetAcptFieldArgs($source_args, $postId, $termId);

        if ($args === null) {
            return null;
        }

        $value = get_acpt_field($args);

        return self::extractAttributeValue($value, $fieldModel->getType(), $attributeName);
    }

    /**
     * Whether a field can be resolved as a binding value at all: its type must
     * be one of MetaFieldModel::BINDABLE_FIELD_TYPES, AND its "Allow in block
     * bindings" advanced option must not be explicitly disallowed. Absence of
     * the option (or any value other than the literal disallow string "0")
     * means allowed -- only an explicit, deliberate "0" (set via the Advanced
     * options toggle) disallows an otherwise-bindable field.
     *
     * This is the real enforcement point, called from every place a binding's
     * value can be read (getValueCallback() below, and
     * MetaController::fetchBlockBindingValuesAction()) or written
     * (MetaController::saveBlockBindingValuesAction()). Hiding a field from
     * the JS editor picker (isFieldBindingAllowed() in
     * assets/src/Gutenberg/utils/isFieldBindingAllowed.jsx, same
     * allow-option semantics, but no type check of its own) doesn't by
     * itself stop hand-edited block markup, a field disallowed *after* it
     * was already bound elsewhere, or a request crafted directly against
     * the AJAX action, from still reading or writing a value here.
     *
     * @param MetaFieldModel $field
     * @return bool
     */
    public static function isFieldBindingAllowed(MetaFieldModel $field): bool
    {
        if (!in_array($field->getType(), MetaFieldModel::BINDABLE_FIELD_TYPES, true)) {
            return false;
        }

        return $field->getAdvancedOption('allow_block_bindings') !== '0';
    }

    /**
     * Pulls the right scalar sub-value out of a structured get_acpt_field()
     * result for the specific attribute being resolved -- URL/IMAGE/FILE/
     * DATE_RANGE/DATE/TIME are declared 'string'/'array' types (resolveBindingType.jsx's
     * BINDING_TYPE_MAP) even though their raw PHP value is a structured
     * shape, so this is what actually makes them reachable. DATE/TIME's raw
     * shape ({format, object, value}) previously reached the block-bindings
     * field-list menu unextracted, crashing WP core's <Truncate>/ItemHelpText
     * (an object isn't a valid React child) the moment the menu tried to
     * preview either field's value. Mirrors
     * extractBoundAttributeValue() (JS, coerceBindingValue.jsx) exactly --
     * same field types, same attribute-name branching, same raw shapes
     * (get_acpt_field()'s default 'object' return + Meta::format()'s
     * 'only_value' default; WPAttachment::jsonSerialize() for the getters
     * used below). Update both together.
     *
     * @param mixed $value
     * @param string $fieldType
     * @param string $attributeName
     * @return mixed
     */
    public static function extractAttributeValue($value, string $fieldType, string $attributeName)
    {
        if (($fieldType === MetaFieldModel::DATE_TYPE || $fieldType === MetaFieldModel::TIME_TYPE) && is_array($value) && array_key_exists('value', $value)) {
            return $value['value'];
        }

        if ($fieldType === MetaFieldModel::IMAGE_TYPE && $value instanceof WPAttachment) {
            if ($attributeName === 'alt') {
                return $value->getAlt() ?? '';
            }
            if ($attributeName === 'title') {
                return $value->getTitle() ?? '';
            }
            return $value->getSrc() ?? '';
        }

        if ($fieldType === MetaFieldModel::FILE_TYPE && is_array($value) && array_key_exists('file', $value)) {
            $file = $value['file'];

            if (!$file instanceof WPAttachment) {
                return '';
            }

            if ($attributeName === 'alt') {
                return $file->getAlt() ?? '';
            }
            if ($attributeName === 'title') {
                return $file->getTitle() ?? '';
            }
            return $file->getSrc() ?? '';
        }

        if ($fieldType === MetaFieldModel::URL_TYPE && is_array($value) && array_key_exists('url', $value)) {
            return $value['url'];
        }

        if ($fieldType === MetaFieldModel::DATE_RANGE_TYPE && is_array($value) && array_key_exists('value', $value)) {
            return $value['value'];
        }

        return $value;
    }

    /**
     * Builds the get_acpt_field() args for a given source (box/field/belongsTo/find),
     * routing to the right location key (post_id/term_id/option_page) based on the
     * field's belongsTo. Shared between getValueCallback() (real block render, front-end
     * and ServerSideRender) and the JS-facing AJAX resolver, so the routing logic lives
     * in exactly one place.
     *
     * @param array<string, mixed> $source_args
     * @param int|null $postId
     * @param int|null $termId
     * @return array<string, mixed>|null
     */
    public static function resolveGetAcptFieldArgs(array $source_args, ?int $postId, ?int $termId): ?array
    {
        if (empty($source_args['box']) || empty($source_args['field'])) {
            return null;
        }

        $args = [
            'box_name' => $source_args['box'],
            'field_name' => $source_args['field'],
        ];

        $belongsTo = $source_args['belongsTo'] ?? MetaTypes::CUSTOM_POST_TYPE;

        switch ($belongsTo) {
            case MetaTypes::OPTION_PAGE:
                if (empty($source_args['find'])) {
                    return null;
                }

                $args['option_page'] = $source_args['find'];

                return $args;

            case MetaTypes::TAXONOMY:
                if (empty($termId)) {
                    return null;
                }

                $args['term_id'] = $termId;

                return $args;

            case MetaTypes::CUSTOM_POST_TYPE:
            default:
                if (empty($postId)) {
                    return null;
                }

                $args['post_id'] = $postId;

                return $args;
        }
    }
}
