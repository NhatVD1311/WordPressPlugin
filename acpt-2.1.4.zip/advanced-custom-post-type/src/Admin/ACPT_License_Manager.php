<?php

namespace ACPT\Admin;

use ACPT\Core\Helper\Features;
use ACPT\Utils\Http\ACPTApiClient;
use ACPT\Utils\PHP\IP;
use ACPT\Utils\PHP\Url;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class ACPT_License_Manager
{
    public const PRIVATE_KEY_NAME = 'acpt_license_active';
    public const BACKOFF_TRANSIENT = 'acpt_license_check_backoff';
    public const BACKOFF_SECONDS = 1800; // 30 minutes

    /**
     * @see https://github.com/googleapis/google-api-php-client/issues/1630
     * @param string $token
     * @return bool
     */
    public static function activateLicenseFromToken(string $token): bool
    {
        $jwt = new JWT();
        $jwt::$leeway = 120;
        $decoded = $jwt::decode($token, new Key(ACPT_PLUGIN_NAME, 'HS256'));

        return ACPT_License_Manager::activateLicense(
            $decoded->data->id,
            $decoded->data->license,
            $decoded->data->siteName,
            $decoded->data->site,
            $decoded->data->email,
            $decoded->data->userId,
        );
    }

    /**
     * @param string $id
     * @param string $license
     * @param string $siteName
     * @param string $siteUrl
     * @param string $email
     * @param string $userId
     * @return bool
     */
    public static function activateLicense(
        string $id,
        string $license,
        string $siteName,
        string $siteUrl,
        string $email,
        string $userId
    ): bool {
        return ACPT_Key_Value_Storage::set(
            self::PRIVATE_KEY_NAME,
            [
                'activation_id' => $id,
                'license' => md5($license),
                'site_name' => $siteName,
                'site_url' => $siteUrl,
                'user_email' => $email,
                'user_id' => $userId,
                'ip' => IP::getClientIP()
            ]
        );
    }

    /**
     * @param array<string, mixed> $postData
     * @return bool
     * @throws \Exception
     */
    public static function activate(array $postData = []): bool
    {
        if (wp_verify_nonce($postData['activation'])) {
            return false;
        }

        try {
            $activation = self::tryToActivate($postData);

            if (isset($activation['error'])) {
                return false;
            }

            if (!isset($activation['id'])) {
                return false;
            }

            self::sendInsights($activation['id']);

            $siteName = get_bloginfo('name');
            $siteUrl = get_bloginfo('url');

            return self::activateLicense(
                $activation['id'],
                $activation['license'],
                $siteName,
                $siteUrl,
                $activation['user_email'],
                $activation['user_id']
            );
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return false;
        }
    }

    /**
     * @param array<string, mixed> $postData
     * @return mixed
     * @throws \Exception
     */
    private static function tryToActivate(array $postData)
    {
        $code = sanitize_text_field($postData['code']);
        $email = sanitize_email($postData['email']);
        $siteName = sanitize_text_field($postData['siteName']);
        $siteUrl = sanitize_url($postData['siteUrl']);
        $ip = IP::getClientIP();

        return ACPTApiClient::call('/license/activate', [
            'license' => $code,
            'email' => $email,
            'siteName' => $siteName,
            'siteUrl' => $siteUrl,
            'ip' => $ip,
        ]);
    }

    /**
     * @param string $activationId
     * @return mixed
     * @throws \Exception
     */
    private static function sendInsights(string $activationId)
    {
        return ACPTApiClient::call('/license/insights/send', [
            'id'       => $activationId,
            'insights' => ACPT_Updater::buildInsightsPayload(),
        ]);
    }

    /**
     * Deactivates the stored license against the ACPT server and clears the
     * local record. Called unguarded from boot-time code (isLicenseValid()),
     * so a failed/unreachable acpt.io call must never throw here.
     *
     * @return bool
     */
    public static function destroy(): bool
    {
        $licenseActivation = ACPT_License_Manager::getLicense();

        if (!is_array($licenseActivation)) {
            return true;
        }

        try {
            ACPTApiClient::call('/license/deactivate', [
                'id' => $licenseActivation['activation_id']
            ]);
        } catch (\Exception $exception) {
            // Network/API failure (unreachable acpt.io, blocked cURL/SSL, etc.) —
            // we don't know if the activation is still valid server-side, so leave
            // the local record alone rather than fataling the whole site on every
            // request while the box can't reach acpt.io.
            do_action("acpt/error", $exception);

            return false;
        }

        // acpt.io responded — whether it confirms deactivation (has 'id') or no
        // longer recognizes this activation at all (e.g. already deactivated,
        // migrated elsewhere), there's nothing left to reconcile, so clear the
        // local record either way. Keeping a stale record here is what used to
        // leave sites stuck retrying a dead activation on every request.
        return ACPT_Key_Value_Storage::delete(self::PRIVATE_KEY_NAME);
    }

    /**
     * @return mixed
     */
    public static function getLicense()
    {
        return ACPT_Key_Value_Storage::get(self::PRIVATE_KEY_NAME);
    }

    /**
     * Validates if the stored license is valid based on the required parameters
     * and the current site URL.
     *
     * @return bool True if the license is valid, false otherwise.
     */
    public static function isLicenseValid(): bool
    {
        $storedKey = self::getLicense();

        if (empty($storedKey)) {
            return false;
        }

        if (!is_array($storedKey)) {
            return false;
        }

        $requiredKeys = ['activation_id', 'site_name', 'license', 'user_email', 'user_id'];

        foreach ($requiredKeys as $key) {
            if (!isset($storedKey[$key])) {
                return false;
            }
        }

        // No site_url stored yet — treat as migrated/unknown state
        if (empty($storedKey['site_url'])) {
            self::reconcileMismatch();
            return false;
        }

        $currentUrl = get_site_url();
        $licensedUrl = $storedKey['site_url'];

        if (Url::normalizeDomain($currentUrl) !== Url::normalizeDomain($licensedUrl)) {
            self::reconcileMismatch();
            return false;
        }

        return true;
    }

    /**
     * Deactivates a stale/mismatched license record on acpt.io. Only called
     * from isLicenseValid() as a side effect of a read, so it must never
     * block every request if acpt.io is unreachable (destroy() only clears
     * the stale record on success, so a persistent failure would otherwise
     * retry — and block — on every single page load, front-end included).
     *
     * @return void
     */
    private static function reconcileMismatch(): void
    {
        if (defined('ACPT_DEV_MODE') && ACPT_DEV_MODE) {
            return;
        }

        if (self::isInLicenseCheckBackoff()) {
            return;
        }

        self::startLicenseCheckBackoff();
        self::destroy();
    }

    /**
     * @return bool
     */
    public static function isInLicenseCheckBackoff(): bool
    {
        return (bool) get_transient(self::BACKOFF_TRANSIENT);
    }

    /**
     * @return void
     */
    public static function startLicenseCheckBackoff(): void
    {
        set_transient(self::BACKOFF_TRANSIENT, time(), self::BACKOFF_SECONDS);
    }

    /**
     * @param string|null $version The version being offered. It makes the URL unique per
     *                             release, so a cache in front of acpt.io (LiteSpeed caches
     *                             this endpoint for 7 days) can never serve the previous zip.
     *
     * @return string
     */
    public static function getDownloadLink(?string $version = null): string
    {
        $license = self::getLicense();
        $userid = $license['user_id'];
        $license  = $license['license'];
        $enableBeta = Features::enableBeta();

        $link = sprintf(ACPTApiClient::BASE_ACPT_URL.'/plugin/download/%s/%d?b=%d', $license, $userid, $enableBeta);

        if (!empty($version)) {
            $link .= '&v='.rawurlencode($version);
        }

        return $link;
    }
}
