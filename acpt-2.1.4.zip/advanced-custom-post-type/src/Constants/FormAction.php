<?php

namespace ACPT\Constants;

class FormAction
{
    public const NONE = 'NONE';
    public const EMAIL = 'EMAIL';
    public const PHP = 'PHP';
    public const AJAX = 'AJAX';
    public const CUSTOM = 'CUSTOM';
    public const FILL_META = 'FILL_META';
    public const FILL_TABLE = 'FILL_TABLE';

    public const ALLOWED_VALUES = [
        self::NONE,
        self::EMAIL,
        self::PHP,
        self::AJAX,
        self::CUSTOM,
        self::FILL_META,
        self::FILL_TABLE,
    ];
}
