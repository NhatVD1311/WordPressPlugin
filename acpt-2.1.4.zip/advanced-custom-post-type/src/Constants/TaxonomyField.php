<?php

namespace ACPT\Constants;

class TaxonomyField
{
    public const SEPARATOR = '::::';
}
