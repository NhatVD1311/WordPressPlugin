<?php

namespace ACPT\Constants;

class FormatterFormat
{
    public const ACPT_FORMAT = 'acpt';
    public const CSV_FORMAT = 'csv';
    public const JSON_FORMAT = 'json';
    public const XML_FORMAT = 'xml';
    public const YAML_FORMAT = 'yaml';

    public const ALLOWED_FORMATS = [
        self::ACPT_FORMAT,
        self::CSV_FORMAT,
        self::JSON_FORMAT,
        self::XML_FORMAT,
        self::YAML_FORMAT,
    ];
}
