<?php

namespace ACPT\Constants;

class Relationships
{
    public const ONE_TO_ONE_UNI   = 'OneToOneUni';
    public const ONE_TO_ONE_BI    = 'OneToOneBi';
    public const ONE_TO_MANY_UNI  = 'OneToManyUni';
    public const ONE_TO_MANY_BI   = 'OneToManyBi';
    public const MANY_TO_ONE_UNI  = 'ManyToOneUni';
    public const MANY_TO_ONE_BI   = 'ManyToOneBi';
    public const MANY_TO_MANY_UNI = 'ManyToManyUni';
    public const MANY_TO_MANY_BI  = 'ManyToManyBi';
}
