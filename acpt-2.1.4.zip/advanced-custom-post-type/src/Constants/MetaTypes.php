<?php

namespace ACPT\Constants;

class MetaTypes
{
    public const COMMENT = 'comment';
    public const MEDIA = 'media';
    public const META = 'meta';
    public const FIELDS = 'fields';
    public const CUSTOM_POST_TYPE = 'customPostType';
    public const OPTION_PAGE = 'optionPage';
    public const TAXONOMY = 'taxonomy';
    public const TABLE = 'table';
    public const TABLE_GROUP = 'tableGroup';
    public const DYNAMIC_BLOCK = 'dynamicBlock';
    public const USER = 'user';

    /**
     * @param string $value
     *
     * @return string|null
     */
    public static function label(string $value): ?string
    {
        $map = [
            self::COMMENT => 'Comment',
            self::MEDIA => 'Media',
            self::META => 'Meta',
            self::FIELDS => 'Fields',
            self::CUSTOM_POST_TYPE => 'CPT',
            self::OPTION_PAGE => 'OP',
            self::TAXONOMY => 'TAX',
            self::TABLE => 'TABLE',
            self::USER => 'USER',
        ];

        if (!isset($map[$value])) {
            return null;
        }

        return $map[$value];
    }
}
