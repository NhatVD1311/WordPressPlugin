<?php

namespace ACPT\Constants;

class Logic
{
    public const BLANK = '';
    public const AND = 'AND';
    public const OR = 'OR';

    public const ALLOWED_VALUES = [
        self::BLANK,
        self::AND,
        self::OR,
    ];
}
