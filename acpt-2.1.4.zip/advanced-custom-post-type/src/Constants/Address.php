<?php

namespace ACPT\Constants;

class Address
{
    public const MULTI_STRING_SEPARATOR = '___###___';
}
