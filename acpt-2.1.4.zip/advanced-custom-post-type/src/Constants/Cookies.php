<?php

namespace ACPT\Constants;

class Cookies
{
    public const ACPT_ERRORS = 'acpt_errors';
}
