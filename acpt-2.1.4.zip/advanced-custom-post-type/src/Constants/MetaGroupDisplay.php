<?php

namespace ACPT\Constants;

class MetaGroupDisplay
{
    public const STANDARD = 'standard';
    public const ACCORDION = 'accordion';
    public const VERTICAL_TABS = 'verticalTabs';
    public const HORIZONTAL_TABS = 'horizontalTabs';
}
