<?php

namespace ACPT\Constants;

class TableField
{
    public const DB_KEY = 'acpt_table_templates';
}
