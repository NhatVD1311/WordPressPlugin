<?php

namespace ACPT\Constants;

class Visibility
{
    public const IS_BACKEND = 'backEnd';
    public const IS_FRONTEND = 'frontEnd';
}
