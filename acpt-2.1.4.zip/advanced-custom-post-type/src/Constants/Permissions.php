<?php

namespace ACPT\Constants;

class Permissions
{
    public const READ_ONLY = '1:readOnly';
    public const NO_SHOW = '0:noShow';
    public const EDIT = '2:edit';
}
