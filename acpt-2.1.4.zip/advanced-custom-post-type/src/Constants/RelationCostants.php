<?php

namespace ACPT\Constants;

class RelationCostants
{
    public const RELATION_KEY = '_######RELATION######';
    public const LABEL_SEPARATOR = '<-------->';
    public const SEPARATOR = '_######SEP######';
}
