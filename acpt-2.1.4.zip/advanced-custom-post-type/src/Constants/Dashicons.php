<?php

namespace ACPT\Constants;

class Dashicons
{
    public const ADMIN_APPEARANCE = 'admin-appearance';
    public const ADMIN_COLLAPSE = 'admin-collapse';
    public const ADMIN_COMMENTS = 'admin-comments';
    public const ADMIN_CUSTOMIZER = 'admin-customizer';
    public const ADMIN_GENERIC = 'admin-generic';
    public const ADMIN_HOME = 'admin-home';
    public const ADMIN_LINKS = 'admin-links';
    public const ADMIN_MEDIA = 'admin-media';
    public const ADMIN_MULTISITE = 'admin-multisite';
    public const ADMIN_NETWORK = 'admin-network';
    public const ADMIN_PAGE = 'admin-page';
    public const ADMIN_PLUGINS = 'admin-plugins';
    public const ADMIN_POST = 'admin-post';
    public const ADMIN_SETTINGS = 'admin-settings';
    public const ADMIN_SITE_ALT = 'admin-site-alt';
    public const ADMIN_SITE_ALT2 = 'admin-site-alt2';
    public const ADMIN_SITE_ALT3 = 'admin-site-alt3';
    public const ADMIN_SITE = 'admin-site';
    public const ADMIN_TOOLS = 'admin-tools';
    public const ADMIN_USERS = 'admin-users';
    public const AIRPLANE = 'airplane';
    public const ALBUM = 'album';
    public const ALIGN_CENTER = 'align-center';
    public const ALIGN_FULL_WIDTH = 'align-full-width';
    public const ALIGN_LEFT = 'align-left';
    public const ALIGN_NONE = 'align-none';
    public const ALIGN_PULL_LEFT = 'align-pull-left';
    public const ALIGN_PULL_RIGHT = 'align-pull-right';
    public const ALIGN_RIGHT = 'align-right';
    public const ALIGN_WIDE = 'align-wide';
    public const AMAZON = 'amazon';
    public const ANALYTICS = 'analytics';
    public const ARCHIVE = 'archive';
    public const ARROW_DOWN_ALT = 'arrow-down-alt';
    public const ARROW_DOWN_ALT2 = 'arrow-down-alt2';
    public const ARROW_DOWN = 'arrow-down';
    public const ARROW_LEFT_ALT = 'arrow-left-alt';
    public const ARROW_LEFT_ALT2 = 'arrow-left-alt2';
    public const ARROW_LEFT = 'arrow-left';
    public const ARROW_RIGHT_ALT = 'arrow-right-alt';
    public const ARROW_RIGHT_ALT2 = 'arrow-right-alt2';
    public const ARROW_RIGHT = 'arrow-right';
    public const ARROW_UP_ALT = 'arrow-up-alt';
    public const ARROW_UP_ALT2 = 'arrow-up-alt2';
    public const ARROW_UP_DUPLICATE = 'arrow-up-duplicate';
    public const ARROW_UP = 'arrow-up';
    public const ART = 'art';
    public const AWARDS = 'awards';
    public const BACKUP = 'backup';
    public const BANK = 'bank';
    public const BEER = 'beer';
    public const BELL = 'bell';
    public const BLOCK_DEFAULT = 'block-default';
    public const BOOK_ALT = 'book-alt';
    public const BOOK = 'book';
    public const BUDDICONS_ACTIVITY = 'buddicons-activity';
    public const BUDDICONS_BBPRESS_LOGO = 'buddicons-bbpress-logo';
    public const BUDDICONS_BUDDYPRESS_LOGO = 'buddicons-buddypress-logo';
    public const BUDDICONS_COMMUNITY = 'buddicons-community';
    public const BUDDICONS_FORUMS = 'buddicons-forums';
    public const BUDDICONS_FRIENDS = 'buddicons-friends';
    public const BUDDICONS_GROUPS = 'buddicons-groups';
    public const BUDDICONS_PM = 'buddicons-pm';
    public const BUDDICONS_REPLIES = 'buddicons-replies';
    public const BUDDICONS_TOPICS = 'buddicons-topics';
    public const BUDDICONS_TRACKING = 'buddicons-tracking';
    public const BUILDING = 'building';
    public const BUSINESSMAN = 'businessman';
    public const BUSINESSPERSON = 'businessperson';
    public const BUSINESSWOMAN = 'businesswoman';
    public const BUTTON = 'button';
    public const CALCULATOR = 'calculator';
    public const CALENDAR_ALT = 'calendar-alt';
    public const CALENDAR = 'calendar';
    public const CAMERA_ALT = 'camera-alt';
    public const CAMERA = 'camera';
    public const CAR = 'car';
    public const CARROT = 'carrot';
    public const CART = 'cart';
    public const CATEGORY = 'category';
    public const CHART_AREA = 'chart-area';
    public const CHART_BAR = 'chart-bar';
    public const CHART_LINE = 'chart-line';
    public const CHART_PIE = 'chart-pie';
    public const CLIPBOARD = 'clipboard';
    public const CLOCK = 'clock';
    public const CLOUD_SAVED = 'cloud-saved';
    public const CLOUD_UPLOAD = 'cloud-upload';
    public const CLOUD = 'cloud';
    public const CODE_STANDARDS = 'code-standards';
    public const COFFEE = 'coffee';
    public const COLOR_PICKER = 'color-picker';
    public const COLUMNS = 'columns';
    public const CONTROLS_BACK = 'controls-back';
    public const CONTROLS_FORWARD = 'controls-forward';
    public const CONTROLS_PAUSE = 'controls-pause';
    public const CONTROLS_PLAY = 'controls-play';
    public const CONTROLS_REPEAT = 'controls-repeat';
    public const CONTROLS_SKIPBACK = 'controls-skipback';
    public const CONTROLS_SKIPFORWARD = 'controls-skipforward';
    public const CONTROLS_VOLUMEOFF = 'controls-volumeoff';
    public const CONTROLS_VOLUMEON = 'controls-volumeon';
    public const COVER_IMAGE = 'cover-image';
    public const DASHBOARD = 'dashboard';
    public const DATABASE_ADD = 'database-add';
    public const DATABASE_EXPORT = 'database-export';
    public const DATABASE_IMPORT = 'database-import';
    public const DATABASE_REMOVE = 'database-remove';
    public const DATABASE_VIEW = 'database-view';
    public const DATABASE = 'database';
    public const DESKTOP = 'desktop';
    public const DISMISS = 'dismiss';
    public const DOWNLOAD = 'download';
    public const DRUMSTICK = 'drumstick';
    public const EDIT_LARGE = 'edit-large';
    public const EDIT_PAGE = 'edit-page';
    public const EDIT = 'edit';
    public const EDITOR_ALIGNCENTER = 'editor-aligncenter';
    public const EDITOR_ALIGNLEFT = 'editor-alignleft';
    public const EDITOR_ALIGNRIGHT = 'editor-alignright';
    public const EDITOR_BOLD = 'editor-bold';
    public const EDITOR_BREAK = 'editor-break';
    public const EDITOR_CODE_DUPLICATE = 'editor-code-duplicate';
    public const EDITOR_CODE = 'editor-code';
    public const EDITOR_CONTRACT = 'editor-contract';
    public const EDITOR_CUSTOMCHAR = 'editor-customchar';
    public const EDITOR_EXPAND = 'editor-expand';
    public const EDITOR_HELP = 'editor-help';
    public const EDITOR_INDENT = 'editor-indent';
    public const EDITOR_INSERTMORE = 'editor-insertmore';
    public const EDITOR_ITALIC = 'editor-italic';
    public const EDITOR_JUSTIFY = 'editor-justify';
    public const EDITOR_KITCHENSINK = 'editor-kitchensink';
    public const EDITOR_LTR = 'editor-ltr';
    public const EDITOR_OL_RTL = 'editor-ol-rtl';
    public const EDITOR_OL = 'editor-ol';
    public const EDITOR_OUTDENT = 'editor-outdent';
    public const EDITOR_PARAGRAPH = 'editor-paragraph';
    public const EDITOR_PASTE_TEXT = 'editor-paste-text';
    public const EDITOR_PASTE_WORD = 'editor-paste-word';
    public const EDITOR_QUOTE = 'editor-quote';
    public const EDITOR_REMOVEFORMATTING = 'editor-removeformatting';
    public const EDITOR_RTL = 'editor-rtl';
    public const EDITOR_SPELLCHECK = 'editor-spellcheck';
    public const EDITOR_STRIKETHROUGH = 'editor-strikethrough';
    public const EDITOR_TABLE = 'editor-table';
    public const EDITOR_TEXTCOLOR = 'editor-textcolor';
    public const EDITOR_UL = 'editor-ul';
    public const EDITOR_UNDERLINE = 'editor-underline';
    public const EDITOR_UNLINK = 'editor-unlink';
    public const EDITOR_VIDEO = 'editor-video';
    public const ELLIPSIS = 'ellipsis';
    public const EMAIL_ALT = 'email-alt';
    public const EMAIL_ALT2 = 'email-alt2';
    public const EMAIL = 'email';
    public const EMBED_AUDIO = 'embed-audio';
    public const EMBED_GENERIC = 'embed-generic';
    public const EMBED_PHOTO = 'embed-photo';
    public const EMBED_POST = 'embed-post';
    public const EMBED_VIDEO = 'embed-video';
    public const EXCERPT_VIEW = 'excerpt-view';
    public const EXIT = 'exit';
    public const EXTERNAL = 'external';
    public const FACEBOOK_ALT = 'facebook-alt';
    public const FACEBOOK = 'facebook';
    public const FEEDBACK = 'feedback';
    public const FILTER = 'filter';
    public const FLAG = 'flag';
    public const FOOD = 'food';
    public const FORMAT_ASIDE = 'format-aside';
    public const FORMAT_AUDIO = 'format-audio';
    public const FORMAT_CHAT = 'format-chat';
    public const FORMAT_GALLERY = 'format-gallery';
    public const FORMAT_IMAGE = 'format-image';
    public const FORMAT_QUOTE = 'format-quote';
    public const FORMAT_STATUS = 'format-status';
    public const FORMAT_VIDEO = 'format-video';
    public const FORMS = 'forms';
    public const FULLSCREEN_ALT = 'fullscreen-alt';
    public const FULLSCREEN_EXIT_ALT = 'fullscreen-exit-alt';
    public const GAMES = 'games';
    public const GOOGLE = 'google';
    public const GOOGLEPLUS = 'googleplus';
    public const GRID_VIEW = 'grid-view';
    public const GROUPS = 'groups';
    public const HAMMER = 'hammer';
    public const HEADING = 'heading';
    public const HEART = 'heart';
    public const HIDDEN = 'hidden';
    public const HOURGLASS = 'hourglass';
    public const HTML = 'html';
    public const ID_ALT = 'id-alt';
    public const ID = 'id';
    public const IMAGE_CROP = 'image-crop';
    public const IMAGE_FILTER = 'image-filter';
    public const IMAGE_FLIP_HORIZONTAL = 'image-flip-horizontal';
    public const IMAGE_FLIP_VERTICAL = 'image-flip-vertical';
    public const IMAGE_ROTATE_LEFT = 'image-rotate-left';
    public const IMAGE_ROTATE_RIGHT = 'image-rotate-right';
    public const IMAGE_ROTATE = 'image-rotate';
    public const IMAGES_ALT = 'images-alt';
    public const IMAGES_ALT2 = 'images-alt2';
    public const INDEX_CARD = 'index-card';
    public const INFO_OUTLINE = 'info-outline';
    public const INFO = 'info';
    public const INSERT_AFTER = 'insert-after';
    public const INSERT_BEFORE = 'insert-before';
    public const INSERT = 'insert';
    public const INSTAGRAM = 'instagram';
    public const LAPTOP = 'laptop';
    public const LAYOUT = 'layout';
    public const LEFTRIGHT = 'leftright';
    public const LIGHTBULB = 'lightbulb';
    public const LINKEDIN = 'linkedin';
    public const LIST_VIEW = 'list-view';
    public const LOCATION_ALT = 'location-alt';
    public const LOCATION = 'location';
    public const LOCK_DUPLICATE = 'lock-duplicate';
    public const LOCK = 'lock';
    public const MARKER = 'marker';
    public const MEDIA_ARCHIVE = 'media-archive';
    public const MEDIA_AUDIO = 'media-audio';
    public const MEDIA_CODE = 'media-code';
    public const MEDIA_DEFAULT = 'media-default';
    public const MEDIA_DOCUMENT = 'media-document';
    public const MEDIA_INTERACTIVE = 'media-interactive';
    public const MEDIA_SPREADSHEET = 'media-spreadsheet';
    public const MEDIA_TEXT = 'media-text';
    public const MEDIA_VIDEO = 'media-video';
    public const MEGAPHONE = 'megaphone';
    public const MENU_ALT = 'menu-alt';
    public const MENU_ALT2 = 'menu-alt2';
    public const MENU_ALT3 = 'menu-alt3';
    public const MENU = 'menu';
    public const MICROPHONE = 'microphone';
    public const MIGRATE = 'migrate';
    public const MINUS = 'minus';
    public const MONEY_ALT = 'money-alt';
    public const MONEY = 'money';
    public const MOVE = 'move';
    public const NAMETAG = 'nametag';
    public const NETWORKING = 'networking';
    public const NO_ALT = 'no-alt';
    public const NO = 'no';
    public const OPEN_FOLDER = 'open-folder';
    public const PALMTREE = 'palmtree';
    public const PAPERCLIP = 'paperclip';
    public const PDF = 'pdf';
    public const PERFORMANCE = 'performance';
    public const PETS = 'pets';
    public const PHONE = 'phone';
    public const PINTEREST = 'pinterest';
    public const PLAYLIST_AUDIO = 'playlist-audio';
    public const PLAYLIST_VIDEO = 'playlist-video';
    public const PLUGINS_CHECKED = 'plugins-checked';
    public const PLUS_ALT = 'plus-alt';
    public const PLUS_ALT2 = 'plus-alt2';
    public const PLUS = 'plus';
    public const PODIO = 'podio';
    public const PORTFOLIO = 'portfolio';
    public const POST_STATUS = 'post-status';
    public const PRESSTHIS = 'pressthis';
    public const PRINTER = 'printer';
    public const PRIVACY = 'privacy';
    public const PRODUCTS = 'products';
    public const RANDOMIZE = 'randomize';
    public const REDDIT = 'reddit';
    public const REDO = 'redo';
    public const REMOVE = 'remove';
    public const REST_API = 'rest-api';
    public const RSS = 'rss';
    public const SAVED = 'saved';
    public const SCHEDULE = 'schedule';
    public const SCREENOPTIONS = 'screenoptions';
    public const SEARCH = 'search';
    public const SHARE_ALT = 'share-alt';
    public const SHARE_ALT2 = 'share-alt2';
    public const SHARE = 'share';
    public const SHIELD_ALT = 'shield-alt';
    public const SHIELD = 'shield';
    public const SHORTCODE = 'shortcode';
    public const SLIDES = 'slides';
    public const SMARTPHONE = 'smartphone';
    public const SMILEY = 'smiley';
    public const SORT = 'sort';
    public const SOS = 'sos';
    public const SPOTIFY = 'spotify';
    public const STAR_EMPTY = 'star-empty';
    public const STAR_FILLED = 'star-filled';
    public const STAR_HALF = 'star-half';
    public const STICKY = 'sticky';
    public const STORE = 'store';
    public const SUPERHERO_ALT = 'superhero-alt';
    public const SUPERHERO = 'superhero';
    public const TABLE_COL_AFTER = 'table-col-after';
    public const TABLE_COL_BEFORE = 'table-col-before';
    public const TABLE_COL_DELETE = 'table-col-delete';
    public const TABLE_ROW_AFTER = 'table-row-after';
    public const TABLE_ROW_BEFORE = 'table-row-before';
    public const TABLE_ROW_DELETE = 'table-row-delete';
    public const TABLET = 'tablet';
    public const TAG = 'tag';
    public const TAGCLOUD = 'tagcloud';
    public const TESTIMONIAL = 'testimonial';
    public const TEXT_PAGE = 'text-page';
    public const TEXT = 'text';
    public const THUMBS_DOWN = 'thumbs-down';
    public const THUMBS_UP = 'thumbs-up';
    public const TICKETS_ALT = 'tickets-alt';
    public const TICKETS = 'tickets';
    public const TIDE = 'tide';
    public const TRANSLATION = 'translation';
    public const TRASH = 'trash';
    public const TWITCH = 'twitch';
    public const TWITTER_ALT = 'twitter-alt';
    public const TWITTER = 'twitter';
    public const UNDO = 'undo';
    public const UNIVERSAL_ACCESS_ALT = 'universal-access-alt';
    public const UNIVERSAL_ACCESS = 'universal-access';
    public const UNLOCK = 'unlock';
    public const UPDATE_ALT = 'update-alt';
    public const UPDATE = 'update';
    public const UPLOAD = 'upload';
    public const VAULT = 'vault';
    public const VIDEO_ALT = 'video-alt';
    public const VIDEO_ALT2 = 'video-alt2';
    public const VIDEO_ALT3 = 'video-alt3';
    public const VISIBILITY = 'visibility';
    public const WARNING = 'warning';
    public const WELCOME_ADD_PAGE = 'welcome-add-page';
    public const WELCOME_COMMENTS = 'welcome-comments';
    public const WELCOME_LEARN_MORE = 'welcome-learn-more';
    public const WELCOME_VIEW_SITE = 'welcome-view-site';
    public const WELCOME_WIDGETS_MENUS = 'welcome-widgets-menus';
    public const WELCOME_WRITE_BLOG = 'welcome-write-blog';
    public const WHATSAPP = 'whatsapp';
    public const WORDPRESS_ALT = 'wordpress-alt';
    public const WORDPRESS = 'wordpress';
    public const XING = 'xing';
    public const YES_ALT = 'yes-alt';
    public const YES = 'yes';
    public const YOUTUBE = 'youtube';

    public const ALLOWED_VALUES = [
        self::ADMIN_APPEARANCE,
        self::ADMIN_COLLAPSE,
        self::ADMIN_COMMENTS,
        self::ADMIN_CUSTOMIZER,
        self::ADMIN_GENERIC,
        self::ADMIN_HOME,
        self::ADMIN_LINKS,
        self::ADMIN_MEDIA,
        self::ADMIN_MULTISITE,
        self::ADMIN_NETWORK,
        self::ADMIN_PAGE,
        self::ADMIN_PLUGINS,
        self::ADMIN_POST,
        self::ADMIN_SETTINGS,
        self::ADMIN_SITE_ALT,
        self::ADMIN_SITE_ALT2,
        self::ADMIN_SITE_ALT3,
        self::ADMIN_SITE,
        self::ADMIN_TOOLS,
        self::ADMIN_USERS,
        self::AIRPLANE,
        self::ALBUM,
        self::ALIGN_CENTER,
        self::ALIGN_FULL_WIDTH,
        self::ALIGN_LEFT,
        self::ALIGN_NONE,
        self::ALIGN_PULL_LEFT,
        self::ALIGN_PULL_RIGHT,
        self::ALIGN_RIGHT,
        self::ALIGN_WIDE,
        self::AMAZON,
        self::ANALYTICS,
        self::ARCHIVE,
        self::ARROW_DOWN_ALT,
        self::ARROW_DOWN_ALT2,
        self::ARROW_DOWN,
        self::ARROW_LEFT_ALT,
        self::ARROW_LEFT_ALT2,
        self::ARROW_LEFT,
        self::ARROW_RIGHT_ALT,
        self::ARROW_RIGHT_ALT2,
        self::ARROW_RIGHT,
        self::ARROW_UP_ALT,
        self::ARROW_UP_ALT2,
        self::ARROW_UP_DUPLICATE,
        self::ARROW_UP,
        self::ART,
        self::AWARDS,
        self::BACKUP,
        self::BANK,
        self::BEER,
        self::BELL,
        self::BLOCK_DEFAULT,
        self::BOOK_ALT,
        self::BOOK,
        self::BUDDICONS_ACTIVITY,
        self::BUDDICONS_BBPRESS_LOGO,
        self::BUDDICONS_BUDDYPRESS_LOGO,
        self::BUDDICONS_COMMUNITY,
        self::BUDDICONS_FORUMS,
        self::BUDDICONS_FRIENDS,
        self::BUDDICONS_GROUPS,
        self::BUDDICONS_PM,
        self::BUDDICONS_REPLIES,
        self::BUDDICONS_TOPICS,
        self::BUDDICONS_TRACKING,
        self::BUILDING,
        self::BUSINESSMAN,
        self::BUSINESSPERSON,
        self::BUSINESSWOMAN,
        self::BUTTON,
        self::CALCULATOR,
        self::CALENDAR_ALT,
        self::CALENDAR,
        self::CAMERA_ALT,
        self::CAMERA,
        self::CAR,
        self::CARROT,
        self::CART,
        self::CATEGORY,
        self::CHART_AREA,
        self::CHART_BAR,
        self::CHART_LINE,
        self::CHART_PIE,
        self::CLIPBOARD,
        self::CLOCK,
        self::CLOUD_SAVED,
        self::CLOUD_UPLOAD,
        self::CLOUD,
        self::CODE_STANDARDS,
        self::COFFEE,
        self::COLOR_PICKER,
        self::COLUMNS,
        self::CONTROLS_BACK,
        self::CONTROLS_FORWARD,
        self::CONTROLS_PAUSE,
        self::CONTROLS_PLAY,
        self::CONTROLS_REPEAT,
        self::CONTROLS_SKIPBACK,
        self::CONTROLS_SKIPFORWARD,
        self::CONTROLS_VOLUMEOFF,
        self::CONTROLS_VOLUMEON,
        self::COVER_IMAGE,
        self::DASHBOARD,
        self::DATABASE_ADD,
        self::DATABASE_EXPORT,
        self::DATABASE_IMPORT,
        self::DATABASE_REMOVE,
        self::DATABASE_VIEW,
        self::DATABASE,
        self::DESKTOP,
        self::DISMISS,
        self::DOWNLOAD,
        self::DRUMSTICK,
        self::EDIT_LARGE,
        self::EDIT_PAGE,
        self::EDIT,
        self::EDITOR_ALIGNCENTER,
        self::EDITOR_ALIGNLEFT,
        self::EDITOR_ALIGNRIGHT,
        self::EDITOR_BOLD,
        self::EDITOR_BREAK,
        self::EDITOR_CODE_DUPLICATE,
        self::EDITOR_CODE,
        self::EDITOR_CONTRACT,
        self::EDITOR_CUSTOMCHAR,
        self::EDITOR_EXPAND,
        self::EDITOR_HELP,
        self::EDITOR_INDENT,
        self::EDITOR_INSERTMORE,
        self::EDITOR_ITALIC,
        self::EDITOR_JUSTIFY,
        self::EDITOR_KITCHENSINK,
        self::EDITOR_LTR,
        self::EDITOR_OL_RTL,
        self::EDITOR_OL,
        self::EDITOR_OUTDENT,
        self::EDITOR_PARAGRAPH,
        self::EDITOR_PASTE_TEXT,
        self::EDITOR_PASTE_WORD,
        self::EDITOR_QUOTE,
        self::EDITOR_REMOVEFORMATTING,
        self::EDITOR_RTL,
        self::EDITOR_SPELLCHECK,
        self::EDITOR_STRIKETHROUGH,
        self::EDITOR_TABLE,
        self::EDITOR_TEXTCOLOR,
        self::EDITOR_UL,
        self::EDITOR_UNDERLINE,
        self::EDITOR_UNLINK,
        self::EDITOR_VIDEO,
        self::ELLIPSIS,
        self::EMAIL_ALT,
        self::EMAIL_ALT2,
        self::EMAIL,
        self::EMBED_AUDIO,
        self::EMBED_GENERIC,
        self::EMBED_PHOTO,
        self::EMBED_POST,
        self::EMBED_VIDEO,
        self::EXCERPT_VIEW,
        self::EXIT,
        self::EXTERNAL,
        self::FACEBOOK_ALT,
        self::FACEBOOK,
        self::FEEDBACK,
        self::FILTER,
        self::FLAG,
        self::FOOD,
        self::FORMAT_ASIDE,
        self::FORMAT_AUDIO,
        self::FORMAT_CHAT,
        self::FORMAT_GALLERY,
        self::FORMAT_IMAGE,
        self::FORMAT_QUOTE,
        self::FORMAT_STATUS,
        self::FORMAT_VIDEO,
        self::FORMS,
        self::FULLSCREEN_ALT,
        self::FULLSCREEN_EXIT_ALT,
        self::GAMES,
        self::GOOGLE,
        self::GOOGLEPLUS,
        self::GRID_VIEW,
        self::GROUPS,
        self::HAMMER,
        self::HEADING,
        self::HEART,
        self::HIDDEN,
        self::HOURGLASS,
        self::HTML,
        self::ID_ALT,
        self::ID,
        self::IMAGE_CROP,
        self::IMAGE_FILTER,
        self::IMAGE_FLIP_HORIZONTAL,
        self::IMAGE_FLIP_VERTICAL,
        self::IMAGE_ROTATE_LEFT,
        self::IMAGE_ROTATE_RIGHT,
        self::IMAGE_ROTATE,
        self::IMAGES_ALT,
        self::IMAGES_ALT2,
        self::INDEX_CARD,
        self::INFO_OUTLINE,
        self::INFO,
        self::INSERT_AFTER,
        self::INSERT_BEFORE,
        self::INSERT,
        self::INSTAGRAM,
        self::LAPTOP,
        self::LAYOUT,
        self::LEFTRIGHT,
        self::LIGHTBULB,
        self::LINKEDIN,
        self::LIST_VIEW,
        self::LOCATION_ALT,
        self::LOCATION,
        self::LOCK_DUPLICATE,
        self::LOCK,
        self::MARKER,
        self::MEDIA_ARCHIVE,
        self::MEDIA_AUDIO,
        self::MEDIA_CODE,
        self::MEDIA_DEFAULT,
        self::MEDIA_DOCUMENT,
        self::MEDIA_INTERACTIVE,
        self::MEDIA_SPREADSHEET,
        self::MEDIA_TEXT,
        self::MEDIA_VIDEO,
        self::MEGAPHONE,
        self::MENU_ALT,
        self::MENU_ALT2,
        self::MENU_ALT3,
        self::MENU,
        self::MICROPHONE,
        self::MIGRATE,
        self::MINUS,
        self::MONEY_ALT,
        self::MONEY,
        self::MOVE,
        self::NAMETAG,
        self::NETWORKING,
        self::NO_ALT,
        self::NO,
        self::OPEN_FOLDER,
        self::PALMTREE,
        self::PAPERCLIP,
        self::PDF,
        self::PERFORMANCE,
        self::PETS,
        self::PHONE,
        self::PINTEREST,
        self::PLAYLIST_AUDIO,
        self::PLAYLIST_VIDEO,
        self::PLUGINS_CHECKED,
        self::PLUS_ALT,
        self::PLUS_ALT2,
        self::PLUS,
        self::PODIO,
        self::PORTFOLIO,
        self::POST_STATUS,
        self::PRESSTHIS,
        self::PRINTER,
        self::PRIVACY,
        self::PRODUCTS,
        self::RANDOMIZE,
        self::REDDIT,
        self::REDO,
        self::REMOVE,
        self::REST_API,
        self::RSS,
        self::SAVED,
        self::SCHEDULE,
        self::SCREENOPTIONS,
        self::SEARCH,
        self::SHARE_ALT,
        self::SHARE_ALT2,
        self::SHARE,
        self::SHIELD_ALT,
        self::SHIELD,
        self::SHORTCODE,
        self::SLIDES,
        self::SMARTPHONE,
        self::SMILEY,
        self::SORT,
        self::SOS,
        self::SPOTIFY,
        self::STAR_EMPTY,
        self::STAR_FILLED,
        self::STAR_HALF,
        self::STICKY,
        self::STORE,
        self::SUPERHERO_ALT,
        self::SUPERHERO,
        self::TABLE_COL_AFTER,
        self::TABLE_COL_BEFORE,
        self::TABLE_COL_DELETE,
        self::TABLE_ROW_AFTER,
        self::TABLE_ROW_BEFORE,
        self::TABLE_ROW_DELETE,
        self::TABLET,
        self::TAG,
        self::TAGCLOUD,
        self::TESTIMONIAL,
        self::TEXT_PAGE,
        self::TEXT,
        self::THUMBS_DOWN,
        self::THUMBS_UP,
        self::TICKETS_ALT,
        self::TICKETS,
        self::TIDE,
        self::TRANSLATION,
        self::TRASH,
        self::TWITCH,
        self::TWITTER_ALT,
        self::TWITTER,
        self::UNDO,
        self::UNIVERSAL_ACCESS_ALT,
        self::UNIVERSAL_ACCESS,
        self::UNLOCK,
        self::UPDATE_ALT,
        self::UPDATE,
        self::UPLOAD,
        self::VAULT,
        self::VIDEO_ALT,
        self::VIDEO_ALT2,
        self::VIDEO_ALT3,
        self::VISIBILITY,
        self::WARNING,
        self::WELCOME_ADD_PAGE,
        self::WELCOME_COMMENTS,
        self::WELCOME_LEARN_MORE,
        self::WELCOME_VIEW_SITE,
        self::WELCOME_WIDGETS_MENUS,
        self::WELCOME_WRITE_BLOG,
        self::WHATSAPP,
        self::WORDPRESS_ALT,
        self::WORDPRESS,
        self::XING,
        self::YES_ALT,
        self::YES,
        self::YOUTUBE,
    ];
}
