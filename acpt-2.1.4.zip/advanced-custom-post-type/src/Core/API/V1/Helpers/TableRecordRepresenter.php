<?php

namespace ACPT\Core\API\V1\Helpers;

use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Core\Models\Table\TableModel;

/**
 * Transforms raw DB rows (\stdClass) into typed PHP values
 * according to each column's UI field type and SQL type.
 *
 * Responsibilities:
 *  - Decode JSON-encoded object/array values back to PHP structures
 *  - Cast integers, floats, and booleans to their native PHP types
 *  - Leave scalars (strings, dates, etc.) untouched
 *
 * Called by TableRecordController after DB reads (list / get) so that
 * callers always receive properly typed values, not raw DB strings.
 */
class TableRecordRepresenter
{
    // UI field types whose values are stored as JSON-encoded objects
    private const OBJECT_UI_TYPES = [
        MetaFieldModel::ADDRESS_TYPE,
        MetaFieldModel::AUDIO_TYPE,
        MetaFieldModel::BARCODE_TYPE,
        MetaFieldModel::CURRENCY_TYPE,
        MetaFieldModel::DATE_RANGE_TYPE,
        MetaFieldModel::FILE_TYPE,
        MetaFieldModel::IMAGE_TYPE,
        MetaFieldModel::LENGTH_TYPE,
        MetaFieldModel::QR_CODE_TYPE,
        MetaFieldModel::TABLE_TYPE,
        MetaFieldModel::URL_TYPE,
        MetaFieldModel::VIDEO_TYPE,
        MetaFieldModel::WEIGHT_TYPE,
    ];

    // UI field types whose values are stored as JSON-encoded arrays
    private const ARRAY_UI_TYPES = [
        MetaFieldModel::ADDRESS_MULTI_TYPE,
        MetaFieldModel::AUDIO_MULTI_TYPE,
        MetaFieldModel::CHECKBOX_TYPE,
        MetaFieldModel::FLEXIBLE_CONTENT_TYPE,
        MetaFieldModel::GALLERY_TYPE,
        MetaFieldModel::IMAGE_SLIDER_TYPE,
        MetaFieldModel::LIST_TYPE,
        MetaFieldModel::POST_OBJECT_MULTI_TYPE,
        MetaFieldModel::POST_TYPE,
        MetaFieldModel::REPEATER_TYPE,
        MetaFieldModel::SELECT_MULTI_TYPE,
        MetaFieldModel::TERM_OBJECT_MULTI_TYPE,
        MetaFieldModel::USER_MULTI_TYPE,
        MetaFieldModel::VIDEO_MULTI_TYPE,
    ];

    /**
     * Apply typed representation to every record in a list.
     *
     * @param TableModel  $table
     * @param \stdClass[] $records  Raw rows from ACPT_DB::getResults().
     * @return \stdClass[]
     */
    public static function representMany(TableModel $table, array $records): array
    {
        return array_map(
            static fn (\stdClass $record) => self::represent($table, $record),
            $records
        );
    }

    /**
     * Apply typed representation to a single raw DB row.
     *
     * @param TableModel $table
     * @param \stdClass  $record
     * @return \stdClass
     */
    public static function represent(TableModel $table, \stdClass $record): \stdClass
    {
        foreach ($table->getColumns() as $column) {
            $name = $column->getName();

            if (!property_exists($record, $name) || $record->$name === null) {
                continue;
            }

            $record->$name = self::castValue($column, $record->$name);
        }

        return $record;
    }

    /**
     * Cast a single raw DB value to its PHP type based on the column definition.
     *
     * @param TableColumnModel $column
     * @param mixed            $value
     * @return mixed
     */
    private static function castValue(TableColumnModel $column, $value)
    {
        $uiType = $column->getUiField()->type;

        // File columns are returned as {url, attachment_id} — not as WPAttachment objects.
        // The full WPAttachment shape would cause N+1 queries on list endpoints, break
        // existing clients, and expose internal filesystem paths. Consumers who need
        // full attachment metadata should call /wp/v2/media/{attachment_id}.

        if (in_array($uiType, self::OBJECT_UI_TYPES, true)) {
            return is_string($value) ? json_decode($value) : $value;
        }

        if (in_array($uiType, self::ARRAY_UI_TYPES, true)) {
            return is_string($value) ? (json_decode($value, true) ?? []) : $value;
        }

        if ($uiType === MetaFieldModel::TOGGLE_TYPE || $column->isBoolean()) {
            return (bool) $value;
        }

        if ($column->isInteger()) {
            return (int) $value;
        }

        if ($column->isFloat()) {
            return (float) $value;
        }

        return $value;
    }

    // ── UI / HTML representation ───────────────────────────────────────────────

    /**
     * Apply HTML representation to every record in a list for admin UI display.
     *
     * @param TableModel  $table
     * @param \stdClass[] $records  Raw rows from ACPT_DB::getResults().
     * @return \stdClass[]
     */
    public static function representManyForUI(TableModel $table, array $records): array
    {
        return array_map(
            static fn (\stdClass $record) => self::representForUI($table, $record),
            $records
        );
    }

    /**
     * Apply HTML representation to a single raw DB row for admin UI display.
     * Every column value becomes a safe HTML string suitable for rendering in a table cell.
     *
     * @param TableModel $table
     * @param \stdClass  $record
     * @return \stdClass
     */
    public static function representForUI(TableModel $table, \stdClass $record): \stdClass
    {
        foreach ($table->getColumns() as $column) {
            $name = $column->getName();

            if (!property_exists($record, $name) || $record->$name === null) {
                $record->$name = '';
                continue;
            }

            $record->$name = self::castValueForUI($column, $record->$name);
        }

        return $record;
    }

    /**
     * Convert a single raw DB value to a safe HTML string for admin UI display.
     * JSON-encoded complex types are decoded first, then formatted per field type.
     *
     * @param TableColumnModel $column
     * @param mixed            $value
     *
     * @return string
     */
    private static function castValueForUI(TableColumnModel $column, $value): string
    {
        $uiType = $column->getUiField()->type;

        // ── Object types ──────────────────────────────────────────────────────
        if (in_array($uiType, self::OBJECT_UI_TYPES, true)) {
            $decoded = is_string($value) ? (json_decode($value, true) ?? []) : (array) $value;

            switch ($uiType) {
                case MetaFieldModel::URL_TYPE:
                    $url   = $decoded['url']      ?? '';
                    $label = $decoded['label']  ?? $url;
                    if (empty($url)) {
                        return '';
                    }
                    return '<a href="' . esc_url($url) . '" target="_blank">' . esc_html($label ?: $url) . '</a>';

                case MetaFieldModel::IMAGE_TYPE:
                    $src = $decoded['url'] ?? (is_string($value) ? $value : '');
                    if (empty($src)) {
                        return '';
                    }
                    return '<img src="' . esc_url($src) . '" style="max-height:60px" alt="">';

                case MetaFieldModel::AUDIO_TYPE:
                    $src = $decoded['url'] ?? (is_string($value) ? $value : '');
                    if (empty($src)) {
                        return '';
                    }
                    return '<audio controls src="' . esc_url($src) . '"></audio>';

                case MetaFieldModel::VIDEO_TYPE:
                    $src = $decoded['url'] ?? (is_string($value) ? $value : '');
                    if (empty($src)) {
                        return '';
                    }

                    return '<video width="80" height="60" controls><source src="'.esc_url($src).'" type="video/mp4"></video>';

                case MetaFieldModel::FILE_TYPE:
                    $url   = $decoded['url']   ?? (is_string($value) ? $value : '');
                    $label = $decoded['label'] ?? $url;
                    if (empty($url)) {
                        return '';
                    }
                    return '<a href="' . esc_url($url) . '" target="_blank">' . esc_html($label) . '</a>';

                case MetaFieldModel::CURRENCY_TYPE:
                case MetaFieldModel::LENGTH_TYPE:
                case MetaFieldModel::WEIGHT_TYPE:
                    // Canonical CCT shape is {value, unit} — see CCTFieldShape.
                    $val  = $decoded['value'] ?? '';
                    $unit = $decoded['unit']  ?? '';
                    return esc_html(trim("{$val} {$unit}"));

                case MetaFieldModel::ADDRESS_TYPE:
                    $address = $decoded['value'] ?? (is_string($value) ? $value : '');
                    return esc_html($address);

                case MetaFieldModel::DATE_RANGE_TYPE:
                    $from = $decoded['from'] ?? '';
                    $to   = $decoded['to']   ?? '';
                    if (empty($from) && empty($to)) {
                        return '';
                    }
                    return esc_html("{$from} – {$to}");

                case MetaFieldModel::BARCODE_TYPE:
                    if (!empty($decoded['svg'])) {
                        return $decoded['svg'];
                    }
                    return esc_html($decoded['value'] ?? (string) $value);

                case MetaFieldModel::QR_CODE_TYPE:
                    if (!empty($decoded['img'])) {
                        return '<img src="' . esc_attr($decoded['img']) . '" style="max-height:60px" alt="QR Code">';
                    }
                    return esc_html($decoded['value'] ?? (string) $value);

                case MetaFieldModel::TABLE_TYPE:
                    return esc_html('(' . __('table', ACPT_PLUGIN_NAME) . ')');

                default:
                    return esc_html(is_array($decoded) ? (json_encode($decoded) !== false) ? json_encode($decoded) : "" : (string) $decoded);
            }
        }

        // ── Array types ───────────────────────────────────────────────────────
        if (in_array($uiType, self::ARRAY_UI_TYPES, true)) {
            $decoded = is_string($value) ? (json_decode($value, true) ?? []) : (array) $value;

            switch ($uiType) {
                case MetaFieldModel::GALLERY_TYPE:
                case MetaFieldModel::IMAGE_SLIDER_TYPE:
                    $html = '';
                    foreach ($decoded as $image) {
                        $url = $image['url'] ?? (is_string($value) ? $value : '');

                        if (is_string($url) && !empty($url)) {
                            $html .= '<img src="' . esc_url($url) . '" style="max-height:40px;margin-right:4px" alt="">';
                        }
                    }
                    return $html;


                case MetaFieldModel::VIDEO_MULTI_TYPE:
                    $links = [];
                    foreach ($decoded as $item) {
                        $src = $item['url'] ?? (is_string($value) ? $value : '');

                        if (is_string($src) && !empty($src)) {
                            $links[] = '<video width="80" height="60" controls><source src="'.esc_url($src).'" type="video/mp4"></video>';
                        }
                    }

                    return implode(', ', $links);

                case MetaFieldModel::AUDIO_MULTI_TYPE:
                    $links = [];
                    foreach ($decoded as $item) {
                        $src = $item['url'] ?? (is_string($value) ? $value : '');

                        if (is_string($src) && !empty($src)) {
                            $links[] = '<audio controls src="' . esc_url($src) . '"></audio>';
                        }
                    }
                    return implode(', ', $links);

                case MetaFieldModel::REPEATER_TYPE:
                case MetaFieldModel::FLEXIBLE_CONTENT_TYPE:
                    $count = count($decoded);
                    /* translators: %d: number of items */
                    return esc_html(sprintf(_n('(%d item)', '(%d items)', $count, ACPT_PLUGIN_NAME), $count));

                case MetaFieldModel::POST_OBJECT_MULTI_TYPE:
                case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:
                case MetaFieldModel::USER_MULTI_TYPE:
                    $labels = [];
                    foreach ($decoded as $item) {
                        if (is_integer($item) || is_string($item)) {
                            $labels[] = $item;
                        } elseif (is_array($item)) {
                            $labels[] = $item['label'] ?? $item['title'] ?? $item['name'] ?? '';
                        }
                    }
                    return esc_html(implode(', ', array_filter($labels)));

                default:
                    // Checkbox, SelectMulti, List, Post, AddressMulti, etc.
                    $items = [];
                    foreach ($decoded as $item) {
                        $items[] = is_string($item) ? $item : (string) ($item['value'] ?? json_encode($item));
                    }
                    return esc_html(implode(', ', array_filter($items)));
            }
        }

        // ── Scalar types ──────────────────────────────────────────────────────
        if ($uiType === MetaFieldModel::TOGGLE_TYPE || $column->isBoolean()) {
            if ($value == "1" || $value == "true" || $value === true) {
                return esc_html(__('Yes', ACPT_PLUGIN_NAME));
            }

            return esc_html(__('No', ACPT_PLUGIN_NAME));
        }

        return esc_html((string) $value);
    }
}
