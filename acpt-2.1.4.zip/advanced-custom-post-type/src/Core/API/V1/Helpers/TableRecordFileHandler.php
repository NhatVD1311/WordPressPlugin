<?php

namespace ACPT\Core\API\V1\Helpers;

/**
 * Handles file upload resolution for custom table record payloads.
 *
 * Uses the $files map from TableModel::validationSchema()['files'] as the
 * authoritative source for:
 *   - which columns are file fields
 *   - validation constraints (accepts, min_size, max_size, min_width,
 *     max_width, min_height, max_height)
 *
 * Supports three input shapes per file column:
 *   1. $_FILES['files'][$columnName]       → raw upload  (REST multipart)
 *   2. $data[$columnName] = "https://..."  → pre-uploaded URL (pass through)
 *   3. $data[$columnName] = null/missing   → no file (null)
 *
 * Multi-file columns follow the same shapes but with arrays:
 *   $_FILES['files'][$col][0..n] and $data[$col] = ["url",...]
 *
 * Nested file columns (inside Repeater / FlexibleContent) use dotted wildcard
 * paths in the files map (e.g. "gallery.*.image") and are NOT handled here —
 * those are resolved when the parent structure is processed recursively.
 */
class TableRecordFileHandler
{
    /**
     * Resolves all top-level file columns in $data.
     *
     * Only processes entries whose key exists in $filesSchema AND has no dot
     * (dotted paths = nested columns inside Repeater/FlexibleContent, handled
     * elsewhere).
     *
     * @param array<string, mixed>      $filesSchema  $table->validationSchema()['files']
     * @param array<string, mixed>      $data         Inbound field data.
     * @param array<string, mixed>|null $files        Contents of $_FILES['files'], or null.
     * @return array<string, mixed>  $data with file columns resolved to URLs or arrays of URLs.
     * @throws \InvalidArgumentException  On constraint violation.
     * @throws \RuntimeException          On wp_handle_upload failure.
     */
    public static function resolve(array $filesSchema, array $data, ?array $files): array
    {
        foreach ($filesSchema as $path => $constraints) {
            // Skip nested paths (e.g. "gallery.*.image") — not top-level columns
            if (str_contains($path, '.')) {
                continue;
            }

            // Neither an explicit value nor an upload was provided for this
            // column — leave it out of $data entirely rather than force-writing
            // null, mirroring how TableRecordController::update() already treats
            // an absent `locations` key as "caller didn't touch this, leave it
            // alone". Previously this always set $data[$path], so any update()
            // call that simply didn't mention a file/image/gallery column
            // silently overwrote it to NULL, clobbering the existing file.
            if (!array_key_exists($path, $data) && empty($files[$path])) {
                continue;
            }

            $isMulti = self::isMultiFile($constraints);

            if ($isMulti) {
                $data[$path] = self::resolveMulti(
                    $path,
                    $constraints,
                    $data[$path] ?? [],
                    $files[$path] ?? null
                );
            } else {
                $data[$path] = self::resolveSingle(
                    $path,
                    $constraints,
                    $data[$path] ?? null,
                    $files[$path] ?? null
                );
            }
        }

        return $data;
    }

    // ── Single file ───────────────────────────────────────────────────────────

    /**
     * @param string               $columnName
     * @param array<string, mixed> $constraints
     * @param mixed                $existing
     * @param array<string, mixed>|null $upload
     * @return array<string, mixed>|null
     */
    private static function resolveSingle(
        string $columnName,
        array  $constraints,
        $existing,
        ?array $upload
    ): ?array {
        // Raw upload — sideload path has no attachment_id or label
        if (!empty($upload['tmp_name'])) {
            self::validateFile($columnName, $constraints, $upload);
            $url = self::handleUpload($upload, $columnName);
            return ['url' => $url, 'attachment_id' => null, 'label' => null];
        }

        // Pre-uploaded: accept either a plain URL string (legacy) or
        // a {url, attachment_id, label} object (new canonical shape)
        if (is_array($existing) && isset($existing['url'])) {
            $url = sanitize_url($existing['url']);
            if (empty($url)) {
                return null;
            }
            $id  = isset($existing['attachment_id']) && $existing['attachment_id'] !== ''
                ? (int) $existing['attachment_id']
                : self::lookupAttachmentId($url);
            return ['url' => $url, 'attachment_id' => $id, 'label' => $existing['label'] ?? null];
        }

        // Old FILE_TYPE meta shape: {'file' => attachmentId, 'label' => ...}
        if (is_array($existing) && isset($existing['file']) && is_numeric($existing['file'])) {
            $url = wp_get_attachment_url((int) $existing['file']);
            if (!$url) {
                return null;
            }
            return ['url' => sanitize_url($url), 'attachment_id' => (int) $existing['file'], 'label' => $existing['label'] ?? null];
        }

        if (is_string($existing) && $existing !== '') {
            $url = sanitize_url($existing);
            return ['url' => $url, 'attachment_id' => self::lookupAttachmentId($url), 'label' => null];
        }

        // Raw attachment ID — convenience input for IMAGE/AUDIO/VIDEO columns
        if (is_numeric($existing)) {
            $url = wp_get_attachment_url((int) $existing);
            if (!$url) {
                return null;
            }
            return ['url' => sanitize_url($url), 'attachment_id' => (int) $existing, 'label' => null];
        }

        return null;
    }

    // ── Multi file ────────────────────────────────────────────────────────────

    /**
     * @param string                         $columnName
     * @param array<string, mixed>           $constraints
     * @param mixed                          $existing
     * @param array<string, mixed>|null  $uploads
     * @return array<int, array<string, mixed>>
     */
    private static function resolveMulti(
        string $columnName,
        array  $constraints,
        $existing,
        ?array $uploads
    ): array {
        // Raw uploads — sideload path has no attachment_id
        if (!empty($uploads)) {
            $normalized = self::normalizeMultipleFiles($uploads);
            $items = [];

            foreach ($normalized as $file) {
                if (!empty($file['tmp_name'])) {
                    self::validateFile($columnName, $constraints, $file);
                    $items[] = [
                        'url'           => self::handleUpload($file, $columnName),
                        'attachment_id' => null,
                    ];
                }
            }

            return $items;
        }

        // Pre-uploaded: accept array of plain URLs (legacy), {url, attachment_id}
        // objects (new canonical shape), or a JSON-encoded string of either
        if (is_string($existing) && $existing !== '') {
            $decoded = json_decode($existing, true);
            $existing = is_array($decoded) ? $decoded : [];
        }

        if (is_array($existing)) {
            return array_values(array_filter(array_map(static function ($item) {
                if (is_array($item) && isset($item['url'])) {
                    $url = sanitize_url($item['url']);
                    $id  = isset($item['attachment_id'])
                        ? (int) $item['attachment_id']
                        : self::lookupAttachmentId($url);
                    return ['url' => $url, 'attachment_id' => $id];
                }
                if (is_string($item) && $item !== '') {
                    $url = sanitize_url($item);
                    return ['url' => $url, 'attachment_id' => self::lookupAttachmentId($url)];
                }
                // Raw attachment ID — convenience input for GALLERY/IMAGE_SLIDER/AUDIO_MULTI columns
                if (is_numeric($item)) {
                    $url = wp_get_attachment_url((int) $item);
                    return $url ? ['url' => sanitize_url($url), 'attachment_id' => (int) $item] : null;
                }
                return null;
            }, $existing)));
        }

        return [];
    }

    // ── Validation ────────────────────────────────────────────────────────────

    /**
     * Validates a file against the constraints from the files schema.
     *
     * Constraint keys (from validationSchema()['files'][$column]):
     *   accepts    (string[])  e.g. ['jpeg','png','pdf']
     *   min_size   (int)       minimum file size in bytes
     *   max_size   (int)       maximum file size in bytes
     *   min_width  (int)       minimum image width in px
     *   max_width  (int)       maximum image width in px
     *   min_height (int)       minimum image height in px
     *   max_height (int)       maximum image height in px
     *
     * @param string               $columnName
     * @param array<string, mixed> $constraints
     * @param array<string, mixed> $file
     * @throws \InvalidArgumentException
     */
    private static function validateFile(string $columnName, array $constraints, array $file): void
    {
        // Extension / MIME check
        if (!empty($constraints['accepts'])) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, (array) $constraints['accepts'], true)) {
                throw new \InvalidArgumentException(
                    "File extension '{$ext}' is not allowed for column `{$columnName}`. " .
                    "Accepted: " . implode(', ', $constraints['accepts'])
                );
            }
        }

        // File size
        if (!empty($constraints['min_size']) && $file['size'] < (int) $constraints['min_size']) {
            throw new \InvalidArgumentException(
                "File for column `{$columnName}` is smaller than the minimum allowed size " .
                "of {$constraints['min_size']} bytes."
            );
        }

        if (!empty($constraints['max_size']) && $file['size'] > (int) $constraints['max_size']) {
            throw new \InvalidArgumentException(
                "File for column `{$columnName}` exceeds the maximum allowed size " .
                "of {$constraints['max_size']} bytes."
            );
        }

        // Image dimensions — only check when the file is an image
        $imageSizeConstraints = ['min_width', 'max_width', 'min_height', 'max_height'];
        $hasDimensionConstraint = array_intersect(array_keys($constraints), $imageSizeConstraints);

        if (!empty($hasDimensionConstraint)) {
            $size = @getimagesize($file['tmp_name']);

            if ($size !== false) {
                [$width, $height] = $size;

                if (!empty($constraints['min_width']) && $width < (int) $constraints['min_width']) {
                    throw new \InvalidArgumentException(
                        "Image for column `{$columnName}` is {$width}px wide, " .
                        "below the minimum of {$constraints['min_width']}px."
                    );
                }

                if (!empty($constraints['max_width']) && $width > (int) $constraints['max_width']) {
                    throw new \InvalidArgumentException(
                        "Image for column `{$columnName}` is {$width}px wide, " .
                        "above the maximum of {$constraints['max_width']}px."
                    );
                }

                if (!empty($constraints['min_height']) && $height < (int) $constraints['min_height']) {
                    throw new \InvalidArgumentException(
                        "Image for column `{$columnName}` is {$height}px tall, " .
                        "below the minimum of {$constraints['min_height']}px."
                    );
                }

                if (!empty($constraints['max_height']) && $height > (int) $constraints['max_height']) {
                    throw new \InvalidArgumentException(
                        "Image for column `{$columnName}` is {$height}px tall, " .
                        "above the maximum of {$constraints['max_height']}px."
                    );
                }
            }
        }
    }

    // ── wp_handle_upload wrapper ──────────────────────────────────────────────

    /**
     * Moves a file to wp-content/uploads and returns its public URL.
     * Does NOT register the file in the WordPress media library.
     *
     * Uses wp_handle_sideload() rather than wp_handle_upload() so it works
     * both in production (where the file may already be on the filesystem
     * from a multipart parse) and in tests (where is_uploaded_file() returns
     * false because the file was not transmitted via a real HTTP upload).
     *
     * @throws \RuntimeException
     */
    /**
     * @param array<string, mixed> $file
     * @param string $columnName
     * @return string
     * @throws \RuntimeException
     */
    private static function handleUpload(array $file, string $columnName): string
    {
        if (!function_exists('wp_handle_sideload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $result = wp_handle_sideload($file, ['test_form' => false]);

        if (isset($result['error'])) {
            throw new \RuntimeException(
                "Failed to upload file for column `{$columnName}`: {$result['error']}"
            );
        }

        return $result['url'];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Determines whether a file column stores multiple files.
     * The files schema does not distinguish single vs multi explicitly —
     * we infer it from the `multiple` key if present, otherwise default to single.
     */
    /**
     * @param array<string, mixed> $constraints
     */
    private static function isMultiFile(array $constraints): bool
    {
        return !empty($constraints['multiple']);
    }

    /**
     * Looks up the WordPress attachment post ID for a given URL.
     * Returns null when the URL is not registered in the WP media library
     * (external URLs, sideloaded files, etc.).
     */
    private static function lookupAttachmentId(string $url): ?int
    {
        if (empty($url)) {
            return null;
        }
        $id = (int) attachment_url_to_postid($url);
        return $id > 0 ? $id : null;
    }

    /**
     * Normalises PHP's multi-file $_FILES format into an array of
     * standard single-file arrays.
     *
     * Input:  ['name'=>['a.jpg','b.jpg'], 'tmp_name'=>['/tmp/x','/tmp/y'],...]
     * Output: [['name'=>'a.jpg','tmp_name'=>'/tmp/x',...], ...]
     */
    /**
     * @param array<string, mixed> $files
     * @return array<int, array<string, mixed>>
     */
    private static function normalizeMultipleFiles(array $files): array
    {
        if (isset($files['tmp_name']) && is_string($files['tmp_name'])) {
            return [$files];
        }

        if (isset($files['tmp_name']) && is_array($files['tmp_name'])) {
            $normalized = [];

            foreach (array_keys($files['tmp_name']) as $i) {
                $normalized[] = [
                    'name'     => $files['name'][$i]     ?? '',
                    'type'     => $files['type'][$i]     ?? '',
                    'tmp_name' => $files['tmp_name'][$i] ?? '',
                    'error'    => $files['error'][$i]    ?? UPLOAD_ERR_NO_FILE,
                    'size'     => $files['size'][$i]     ?? 0,
                ];
            }

            return $normalized;
        }

        return [];
    }
}
