<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\CQRS\Command\DeleteTableCommand;
use ACPT\Core\CQRS\Command\ExecuteTableSchemaAction;
use ACPT\Core\CQRS\Command\SaveTableCommand;
use ACPT\Core\Helper\UITypeToColumnMapper;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\JSON\TableSchema;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\Data\ValidationException;

class TableController extends AbstractController
{
    // ── GET /table ────────────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function getAll(\WP_REST_Request $request): \WP_REST_Response
    {
        try {
            $page    = isset($request['page']) ? (int)$request['page'] : 1;
            $perPage = isset($request['per_page']) ? (int)$request['per_page'] : 20;
            $perPage = min($perPage, 100);
            $search  = isset($request['search']) ? sanitize_text_field($request['search']) : null;

            $records = TableRepository::get([
                'page'    => $page,
                'perPage' => $perPage,
                'search'  => $search,
            ]);

            $count    = TableRepository::count(['search' => $search]);
            $maxPages = $count > 0 ? (int) ceil($count / $perPage) : 1;

            return $this->jsonPaginatedResponse($page, $maxPages, $perPage, $count, $records);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    // ── GET /table/{id} ───────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function get(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        if (! $this->isValidUuid($id)) {
            return $this->jsonBadRequestResponse('Invalid table id format.');
        }

        try {
            $table = TableRepository::getById($id);

            if ($table === null) {
                return $this->jsonNotFoundResponse('Table not found.');
            }

            return $this->jsonResponse($table);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    // ── POST /table ───────────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function create(\WP_REST_Request $request): \WP_REST_Response
    {
        if (! $this->currentUserCan('manage_options')) {
            return $this->jsonForbiddenResponse();
        }

        return $this->createOrUpdate($request, 201);
    }

    // ── PUT /table/{id} ───────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function update(\WP_REST_Request $request): \WP_REST_Response
    {
        if (! $this->currentUserCan('manage_options')) {
            return $this->jsonForbiddenResponse();
        }

        $id = $request['id'];

        if (! $this->isValidUuid($id)) {
            return $this->jsonBadRequestResponse('Invalid table id format.');
        }

        return $this->createOrUpdate($request, 200, $id);
    }

    // ── DELETE /table/{id} ────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function delete(\WP_REST_Request $request): \WP_REST_Response
    {
        if (! $this->currentUserCan('manage_options')) {
            return $this->jsonForbiddenResponse();
        }

        $id = $request['id'];

        if (! $this->isValidUuid($id)) {
            return $this->jsonBadRequestResponse('Invalid table id format.');
        }

        try {
            $table = TableRepository::getById($id);

            if ($table === null) {
                return $this->jsonNotFoundResponse('Table not found.');
            }

            $command = new DeleteTableCommand($id);
            $command->execute();

            return $this->jsonResponse(['id' => $id], 200);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    // ── POST /table/{id}/sync ─────────────────────────────────────────────────

    /**
     * Synchronises the physical MySQL table with the stored definition.
     * Creates the table if it does not exist yet, applies the diff otherwise.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function sync(\WP_REST_Request $request): \WP_REST_Response
    {
        if (! $this->currentUserCan('manage_options')) {
            return $this->jsonForbiddenResponse();
        }

        $id = $request['id'];

        if (! $this->isValidUuid($id)) {
            return $this->jsonBadRequestResponse('Invalid table id format.');
        }

        try {
            $table = TableRepository::getById($id);

            if ($table === null) {
                return $this->jsonNotFoundResponse('Table not found.');
            }

            $status = $table->getTableStatus();

            if ($status['status'] === $table::TABLE_STATUS_SYNCED) {
                return $this->jsonResponse([
                    'id'     => $id,
                    'status' => $status['status'],
                    'message' => 'Table is already in sync.',
                ], 200);
            }

            $action  = $status['status'] === $table::TABLE_STATUS_NOT_CREATED ? 'create' : 'sync';
            $command = new ExecuteTableSchemaAction($id, $action);
            $command->execute();

            return $this->jsonResponse([
                'id'     => $id,
                'status' => $table::TABLE_STATUS_SYNCED,
            ], 200);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    // ── GET /table/{id}/status ────────────────────────────────────────────────

    /**
     * Returns the synchronisation status of the table schema.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function status(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        if (! $this->isValidUuid($id)) {
            return $this->jsonBadRequestResponse('Invalid table id format.');
        }

        try {
            $table = TableRepository::getById($id);

            if ($table === null) {
                return $this->jsonNotFoundResponse('Table not found.');
            }

            return $this->jsonResponse($table->getTableStatus(), 200);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @param int              $httpStatus
     * @param string|null      $id
     * @return \WP_REST_Response
     */
    private function createOrUpdate(\WP_REST_Request $request, int $httpStatus, ?string $id = null): \WP_REST_Response
    {
        $data = $this->getDecodedRequest($request);

        if (empty($data)) {
            return $this->jsonBadRequestResponse('Empty request body.');
        }

        if (! is_array($data)) {
            return $this->jsonBadRequestResponse('Request body must be a JSON object.');
        }

        try {
            $id = $this->saveTable($data, $id);

            return $this->jsonResponse(['id' => $id], $httpStatus);
        } catch (ValidationException $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonBadRequestResponse($exception->getFormattedErrors());
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    /**
     * Validates, sanitizes and persists a table definition.
     * Resolves uiType → MySQL type mapping for each column.
     *
     * @param array<string, mixed> $data
     * @param string|null          $id
     * @return string The saved table id.
     * @throws \Exception
     */
    private function saveTable(array $data, ?string $id = null): string
    {
        // Validate against JSON schema
        $this->validateJSONSchema($data, new TableSchema());

        // Sanitize
        $data = Sanitizer::recursiveSanitizeRawData($data);

        // Resolve uiType → MySQL type for each column
        if (! empty($data['columns']) && is_array($data['columns'])) {
            foreach ($data['columns'] as &$column) {
                if (isset($column['uiType'])) {
                    $resolved = UITypeToColumnMapper::resolve($column['uiType'], $column);

                    if ($resolved === null) {
                        throw new \InvalidArgumentException(
                            "Unrecognised uiType `{$column['uiType']}` for column `{$column['name']}`."
                        );
                    }

                    $column['type']   = $resolved['type'];
                    $column['length'] = $resolved['length'];
                    $column['ui']     = array_merge(
                        ['type' => $column['uiType'], 'options' => [], 'advancedOptions' => []],
                        $column['ui'] ?? []
                    );
                }
            }
            unset($column);
        }

        $data['id'] = $id ?? Uuid::v4();

        $command = new SaveTableCommand($data);
        $command->execute();

        return $data['id'];
    }
}
