<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\API\Exceptions\NotFoundException;
use ACPT\Core\API\Exceptions\UnauthorizedException;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Utils\Data\ValidationException;
use ACPT\Utils\PHP\Request;

/**
 * HTTP adapter for TableRecordController.
 *
 * Extracts parameters and files from WP_REST_Request,
 * enforces the table's restApi capability list, and
 * wraps plain-array results in WP_REST_Response.
 */
class TableRecordHttpAdapter extends AbstractController
{
    private TableRecordController $controller;

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->controller = new TableRecordController();
    }

    // ── HTTP entry points ─────────────────────────────────────────────────────

    /** GET /acpt/v1/{tableName} */
    public function list(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->run('read', $request, function (TableModel $table, \WP_REST_Request $req) {
            $result = $this->controller->list($table->getName(), $req->get_params());

            return $this->jsonPaginatedResponse(
                $result['currentPage'],
                $result['maxPages'],
                $result['perPage'],
                $result['total'],
                $result['records']
            );
        });
    }

    /** GET /acpt/v1/{tableName}/{id} */
    public function get(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->run('read', $request, function (TableModel $table, \WP_REST_Request $req) {
            $record = $this->controller->get($table->getName(), $req->get_param('id'));
            return $this->jsonResponse($record);
        });
    }

    /** POST /acpt/v1/{tableName} */
    public function create(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->run('create', $request, function (TableModel $table, \WP_REST_Request $req) {
            $data   = $this->getDecodedRequest($req) ?? $req->get_body_params();
            $files  = $this->extractFiles($req);
            $result = $this->controller->create($table->getName(), $data, $files);

            return $this->jsonResponse($result, 201);
        });
    }

    /** PUT /acpt/v1/{tableName}/{id} */
    public function update(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->run('update', $request, function (TableModel $table, \WP_REST_Request $req) {
            try {
                $data   = $this->getDecodedRequest($req) ?? $req->get_body_params();
                $files  = $this->extractFiles($req);
                $result = $this->controller->update($table->getName(), $req->get_param('id'), $data, $files);

                return $this->jsonResponse($result);
            } catch (ValidationException $ve) {
                return $this->jsonErrorResponse($ve, 422);
            }
        });
    }

    /** DELETE /acpt/v1/{tableName}/{id} */
    public function delete(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->run('delete', $request, function (TableModel $table, \WP_REST_Request $req) {
            $result = $this->controller->delete($table->getName(), $req->get_param('id'));
            return $this->jsonResponse($result);
        });
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Shared pipeline:
     *   1. Resolve table (404 if missing / no id strategy)
     *   2. Check REST API capability (403 if not allowed)
     *   3. Execute callback
     *   4. Map exceptions to HTTP responses
     */
    private function run(
        string $action,
        \WP_REST_Request $request,
        callable $callback
    ): \WP_REST_Response {
        try {
            $table = $this->controller->resolveTable($request->get_param('tableName'));
            $this->checkSupports($table, $action);
            return $callback($table, $request);
        } catch (NotFoundException $e) {
            do_action('acpt/error', $e);
            return $this->jsonNotFoundResponse($e->getMessage());
        } catch (UnauthorizedException $e) {
            do_action('acpt/error', $e);
            return $this->jsonForbiddenResponse();
        } catch (\InvalidArgumentException $e) {
            // MIME type / file size / column validation failures
            do_action('acpt/error', $e);
            return $this->jsonBadRequestResponse($e->getMessage());
        } catch (ValidationException $exception) {
            do_action('acpt/error', $exception);

            return $this->jsonBadRequestResponse($exception->getFormattedErrors());
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            return $this->jsonErrorResponse($e);
        }
    }

    /**
     * Returns the uploaded files indexed under the 'files' key, or null when absent.
     *
     * Reads from WP_REST_Request::get_file_params() so it works for both standard
     * multipart/form-data requests (cURL) and unit-testable contexts.
     * Falls back to $_FILES['files'] for environments where WP does not populate
     * the request file params (e.g. non-standard setups).
     *
     * Expected structure: ['columnName' => [...upload array...]] or
     *                     ['columnName' => [[...], [...]]] for multi-file columns.
     */
    /**
     * @return array<string, mixed>|null
     */
    private function extractFiles(\WP_REST_Request $request): ?array
    {
        // Column-first shape ($files['photo']['tmp_name'], as
        // TableRecordFileHandler::resolve() expects, matching a plain
        // <input type="file" name="photo"> field / $_FILES['photo']) —
        // NOT wrapped under a 'files' key. WP_REST_Server sets file params
        // directly from the raw, unwrapped $_FILES superglobal, and no
        // multipart encoding a real client can send ever nests uploads
        // under wrapper[column][tmp_name] the way a 'files' key here would
        // require — only wrapper[tmp_name][column] (PHP's native bracketed
        // field-name shape), which is a different, incompatible layout.
        $fileParams = $request->get_file_params();

        return !empty($fileParams) ? $fileParams : null;
    }

    /**
     * Verifies that the table exposes the requested action through its REST API.
     *
     * @throws UnauthorizedException
     * @throws \Exception
     */
    private function checkSupports(TableModel $table, string $action): void
    {
        $allowed = ['read', 'create', 'update', 'delete'];

        if (!in_array($action, $allowed, true)) {
            throw new \Exception("`{$action}` is not a valid REST action");
        }

        if (!$table->hasRestAPiSupportFor($action)) {
            throw new UnauthorizedException(
                "Table {$table->getName()} does not support the {$action} action via REST API"
            );
        }
    }
}
