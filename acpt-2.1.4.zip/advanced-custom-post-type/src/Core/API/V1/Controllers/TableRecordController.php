<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Constants\Address;
use ACPT\Constants\MetaTypes;
use ACPT\Core\API\Exceptions\NotFoundException;
use ACPT\Core\API\V1\Helpers\TableRecordFileHandler;
use ACPT\Core\API\V1\Helpers\TableRecordRepresenter;
use ACPT\Core\Helper\CCTFieldShape;
use ACPT\Core\Helper\Strings;
use ACPT\Core\JSON\TableRecordSchema;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Models\Validation\ValidationRuleModel;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Includes\ACPT_DB;
use ACPT\Utils\Checker\ValidationRulesChecker;
use ACPT\Utils\Data\JSONSchemaValidator;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\Data\ValidationException;
use ACPT\Utils\PHP\DateNormalizer;

/**
 * Standalone controller for custom table record CRUD.
 *
 * Returns plain PHP arrays — no HTTP concern.
 * Use TableRecordHttpAdapter for WP_REST_Response wrapping.
 *
 * Write pipeline (create / update):
 *   1. resolveFiles()  — uploads raw files, resolves to URLs
 *   2. sanitize()      — per-column sanitization via Sanitizer::sanitizeRawData()
 *   3. validate()      — JSON Schema validation via TableRecordSchema (strict)
 *   4. upsertQuery()   — persists to MySQL
 */
class TableRecordController
{
    /**
     * UI types stored as a single compound JSON object whose write schema requires
     * a specific key shape (e.g. {value, unit}) that convenience input — a bare
     * scalar, or the legacy meta shape — doesn't match. These are run through
     * {@see CCTFieldShape::coerce()} before sanitization/validation.
     *
     * Media types (IMAGE/AUDIO/VIDEO/FILE/GALLERY/...) are excluded — they are
     * already coerced by TableRecordFileHandler, which also handles real uploads.
     */
    private const COERCIBLE_COMPOUND_TYPES = [
        MetaFieldModel::ADDRESS_TYPE,
        MetaFieldModel::ADDRESS_MULTI_TYPE,
        MetaFieldModel::CURRENCY_TYPE,
        MetaFieldModel::WEIGHT_TYPE,
        MetaFieldModel::LENGTH_TYPE,
        MetaFieldModel::URL_TYPE,
        MetaFieldModel::COUNTRY_TYPE,
    ];

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * @param string               $tableName
     * @param array<string, mixed> $params  page, per_page, where, order_by, record_status ('active' default, or 'trash' for soft-deleted rows)
     * @param string               $format  'api' (default) returns typed PHP values; 'ui' returns HTML strings for admin display
     * @return array<string, mixed>
     * @throws NotFoundException
     */
    public function list(string $tableName, array $params = [], string $format = 'api'): array
    {
        $table   = $this->resolveTable($tableName);
        $page    = (int) ($params['page']     ?? 1);
        $onlyIds = $params['only_ids'] ?? false;
        $perPage = $onlyIds
            ? min((int) ($params['per_page'] ?? 1000), 10000)
            : min((int) ($params['per_page'] ?? 20), 100);
        $where   = $params['where']    ?? [];
        $s       = $params['s']        ?? '';
        $filters = $params['filters']  ?? '';
        $orderBy = $params['order_by'] ?? [];
        $offset  = ($page - 1) * $perPage;
        $locationFilter = [];

        if (!empty($s)) {
            $searchableColumns = array_filter(
                $table->getColumns(),
                fn ($c) => $c->isConcrete() && $c->getUiField()->showInArchive
            );

            foreach ($searchableColumns as $column) {
                $where[$column->getName()] = [
                    'operator' => 'LIKE',
                    'value'    => '%' . $s . '%',
                    'logic'    => 'OR'
                ];
            }

            if (!empty($where)) {
                $lastCol = array_key_last($where);
                $where[$lastCol]['logic'] = 'AND';
            }
        }

        if (!empty($filters)) {
            $decodedFilters = is_string($filters) ? json_decode(stripslashes($filters), true) : $filters;
            if (is_array($decodedFilters)) {
                foreach ($decodedFilters as $filter) {
                    $column   = $filter['column']   ?? '';
                    $operator = $filter['operator'] ?? 'equals';
                    $value    = $filter['value']    ?? '';
                    $logic    = $filter['logic']    ?? 'AND';

                    if (empty($column)) {
                        continue;
                    }

                    $sqlOperator = '=';
                    switch ($operator) {
                        case 'contains':
                            $sqlOperator = 'LIKE';
                            $value = '%' . $value . '%';
                            break;
                        case 'starts_with':
                            $sqlOperator = 'LIKE';
                            $value = $value . '%';
                            break;
                        case 'is_empty':
                            $sqlOperator = 'IS NULL';
                            break;
                        case 'is_not_empty':
                            $sqlOperator = 'IS NOT NULL';
                            break;
                        case 'greater_than':
                            $sqlOperator = '>';
                            break;
                        case 'less_than':
                            $sqlOperator = '<';
                            break;
                        case 'not_equals':
                            $sqlOperator = '!=';
                            break;
                        case 'equals':
                        default:
                            $sqlOperator = '=';
                            break;
                    }

                    // Location filter columns are encoded as "loc:RULE_INT:RULE_VALUE"
                    if (Strings::startsWith($column, 'loc:')) {
                        $parts   = explode(':', $column, 3);
                        $ruleInt = (int)($parts[1] ?? 0);
                        if ($ruleInt > 0) {
                            $entry = ['location_rule' => $ruleInt];
                            // Valueless rules (user, comment, media) carry no location_value
                            if (!in_array($sqlOperator, ['IS NULL', 'IS NOT NULL'], true) && $value !== '') {
                                $entry['location_value'] = ['value' => $value, 'operator' => $sqlOperator];
                            }
                            $locationFilter[] = $entry;
                            continue;
                        }
                    }

                    $where[$column][] = [
                        'operator' => $sqlOperator,
                        'value'    => $value,
                        'logic'    => $logic
                    ];
                }
            }
        }

        if ($table->withSoftDelete()) {
            $recordStatus = $params['record_status'] ?? 'active';
            $where['deleted_at'] = $recordStatus === 'trash'
                ? ['operator' => 'IS NOT NULL']
                : ['operator' => 'IS NULL'];
        }

        $countSql = $table->selectQuery([
            'columns'        => [['name' => ACPT_DB::prefixedTableName($tableName).'.'.$table->getPrimaryKey(), 'count' => true, 'alias' => 'total']],
            'where'          => $where,
            'locationFilter' => $locationFilter,
        ]);

        $count    = (int) (ACPT_DB::getResults($countSql['sql'], $countSql['values'], 0, $tableName)[0]->total ?? 0);
        $maxPages = $count > 0 ? (int) ceil($count / $perPage) : 1;

        $baseQueryArgs = [
            'where'          => $where,
            'orderBy'        => $orderBy,
            'limit'          => $perPage,
            'offset'         => $offset,
            'locationFilter' => $locationFilter,
        ];

        if ($onlyIds === true) {
            // 'id' is kept as the outward-facing alias for API-contract stability,
            // even when the underlying column is a differently-named custom primary key.
            $baseQueryArgs['columns'] = [['name' => ACPT_DB::prefixedTableName($tableName).'.'.$table->getPrimaryKey(), 'alias' => 'id']];
        }

        $sql = $table->selectQuery($baseQueryArgs);

        $records = ACPT_DB::getResults($sql['sql'], $sql['values'], 7200, $tableName);

        $represented = $format === 'ui'
            ? TableRecordRepresenter::representManyForUI($table, $records)
            : TableRecordRepresenter::representMany($table, $records);

        if ($format !== 'ui') {
            $represented = array_map(
                fn ($row) => $this->filterUnreadableColumns($table, $row),
                $represented
            );
        }

        return [
            'currentPage' => $page,
            'total'       => $count,
            'maxPages'    => $maxPages,
            'perPage'     => $perPage,
            'records'     => $represented,
        ];
    }

    /**
     * @param string     $tableName
     * @param int|string $id
     * @param string     $format  'api' (default) returns typed PHP values; 'ui' returns HTML strings for admin display
     * @return \stdClass  Single record row.
     * @throws NotFoundException
     */
    public function get(string $tableName, $id, string $format = 'api'): \stdClass
    {
        $table  = $this->resolveTable($tableName);
        $record = $this->fetchRecord($table, $id);

        if ($format === 'ui') {
            return TableRecordRepresenter::representForUI($table, $record);
        }

        return $this->filterUnreadableColumns($table, TableRecordRepresenter::represent($table, $record));
    }

    /**
     * @param string                    $tableName
     * @param array<string, mixed>      $data   Scalar / JSON field values.
     * @param array<string, mixed>|null $files  Contents of $_FILES['files'], or null.
     * @return array<string, mixed>
     * @throws NotFoundException|\InvalidArgumentException|\RuntimeException|\Exception
     */
    public function create(string $tableName, array $data, ?array $files = null): array
    {
        $table     = $this->resolveTable($tableName);
        $locations = $data['locations'] ?? [];
        unset($data['locations']);

        $data = $this->prepare($table, $data, $files);

        $sql = $table->upsertQuery($data);
        ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

        // getTheLastInsertedId() (wpdb::$insert_id) is only meaningful for an
        // auto-increment primary key. A custom, non-auto-increment PK's value
        // comes from the caller-supplied data instead.
        $pkColumn = $table->getColumn($table->getPrimaryKey());
        $id = ($pkColumn !== null && !$pkColumn->isAutoIncrement())
            ? ($data[$table->getPrimaryKey()] ?? null)
            : ACPT_DB::getTheLastInsertedId();

        if (!empty($table->getLocation())) {
            TableRecordRepository::syncLocations($tableName, $id, $locations);
        }

        $this->syncBidirectionalRelations($table, $id, $data, null);
        $this->evictCache($tableName);

        return ['id' => $id];
    }

    /**
     * @param string                    $tableName
     * @param int|string                $id
     * @param array<string, mixed>      $data
     * @param array<string, mixed>|null $files
     * @return array<string, mixed>
     * @throws NotFoundException|\InvalidArgumentException|\RuntimeException|\Exception
     */
    public function update(string $tableName, $id, array $data, ?array $files = null): array
    {
        $table     = $this->resolveTable($tableName);
        $oldRecord = $this->fetchRecord($table, $id); // 404 if missing

        $hasLocations   = array_key_exists('locations', $data);
        $locations      = $data['locations'] ?? [];
        $pkColumn       = $table->getPrimaryKey();
        $pkIsRealColumn = $table->getColumn($pkColumn) !== null;
        unset($data['locations'], $data[$pkColumn]); // caller-submitted id is discarded — URL id is authoritative

        // A custom primary key is a genuine TableColumnModel with its own schema
        // entry (often required) — it must already be present, with the
        // URL-authoritative value, before prepare()/validate() runs, so it goes
        // through the column's own sanitizer and satisfies the schema.
        if ($pkIsRealColumn) {
            $data[$pkColumn] = $id;
        }

        $data = $this->prepare($table, $data, $files);

        // The implicit `id` column (auto_increment/UUID/ULID) has no
        // TableColumnModel and is deliberately excluded from the schema's
        // required set — its declared schema type is stricter than the raw URL
        // param, so it must stay out of validation entirely and only be
        // attached after prepare() runs, exactly as before custom PKs existed.
        if (!$pkIsRealColumn) {
            $data[$pkColumn] = $id;
        }

        $sql = $table->upsertQuery($data);
        ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

        // Only sync locations when the key was explicitly provided.
        // Absent key = caller did not touch locations → leave existing ones intact.
        if (!empty($table->getLocation()) && $hasLocations) {
            TableRecordRepository::syncLocations($tableName, $id, $locations);
        }

        $this->syncBidirectionalRelations($table, $id, $data, $oldRecord);
        $this->evictCache($tableName);

        return ['id' => $id, 'data' => $data];
    }

    /**
     * @param string     $tableName
     * @param int|string $id
     * @return array{id:int|string}
     * @throws NotFoundException
     */
    public function delete(string $tableName, $id): array
    {
        $table     = $this->resolveTable($tableName);
        $oldRecord = $this->fetchRecord($table, $id); // 404 if missing

        $sql = $table->deleteQuery($id);

        ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

        if (!empty($table->getLocation())) {
            TableRecordRepository::deleteLocations($tableName, $id);
        }

        // create()/update() both keep bidirectional relation inverse columns in
        // sync, but delete() never did — leaving this record's id sitting in the
        // inverse relationship column of every other table's row that pointed to
        // it, a silent orphan reference with no DB-level FK to catch it. Passing
        // an empty value for every bidirectional column (with the just-deleted
        // row as $oldRecord) makes syncBidirectionalRelations() treat every id
        // that used to be there as "removed".
        $emptyRelationData = [];
        foreach ($table->getColumns() as $column) {
            $rel = $column->getUiField()->relationship;
            if ($rel && $rel->bidirectional) {
                $emptyRelationData[$column->getName()] = [];
            }
        }
        $this->syncBidirectionalRelations($table, $id, $emptyRelationData, $oldRecord);

        $this->evictCache($tableName);

        return ['id' => $id];
    }

    /**
     * Restores a soft-deleted record by clearing its `deleted_at` column.
     * Only applicable to tables with soft delete enabled.
     *
     * @param string     $tableName
     * @param int|string $id
     * @return array{id:int|string}
     * @throws NotFoundException
     */
    public function restore(string $tableName, $id): array
    {
        $table = $this->resolveTable($tableName);

        if (!$table->withSoftDelete()) {
            throw new NotFoundException("Table {$tableName} does not support soft delete");
        }

        $this->fetchRecord($table, $id, true); // 404 if the record doesn't exist at all

        $sql = $table->restoreQuery($id);
        ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

        $this->evictCache($tableName);

        return ['id' => $id];
    }

    /**
     * Permanently deletes a record, bypassing soft delete.
     *
     * On a table without soft delete this simply behaves like delete(). On a table with soft
     * delete, it refuses to act on a record that hasn't been moved to the Trash yet — location
     * junction rows and bidirectional relation inverse columns were already cleaned up when the
     * record was originally soft-deleted (delete() does that unconditionally), so there's
     * nothing further to clean up here beyond the row itself.
     *
     * @param string     $tableName
     * @param int|string $id
     * @return array{id:int|string}
     * @throws NotFoundException
     * @throws \InvalidArgumentException  If the table has soft delete but the record isn't trashed yet.
     */
    public function forceDelete(string $tableName, $id): array
    {
        $table = $this->resolveTable($tableName);

        if (!$table->withSoftDelete()) {
            return $this->delete($tableName, $id);
        }

        $record = $this->fetchRecord($table, $id, true); // 404 if the record doesn't exist at all

        if (empty($record->deleted_at)) {
            throw new \InvalidArgumentException(
                "Record with id {$id} is not in the Trash; move it to Trash before permanently deleting it."
            );
        }

        $sql = $table->deleteQuery($id, true);
        ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

        $this->evictCache($tableName);

        return ['id' => $id];
    }

    /**
     * Permanently deletes every soft-deleted record currently in the Trash for a table.
     *
     * @param string $tableName
     * @return array{count:int}
     * @throws NotFoundException
     */
    public function emptyTrash(string $tableName): array
    {
        $table = $this->resolveTable($tableName);

        if (!$table->withSoftDelete()) {
            return ['count' => 0];
        }

        $sql = $table->selectQuery([
            'columns' => [['name' => ACPT_DB::prefixedTableName($tableName) . '.' . $table->getPrimaryKey(), 'alias' => 'id']],
            'where'   => ['deleted_at' => ['operator' => 'IS NOT NULL']],
        ]);

        $trashedIds = array_column(ACPT_DB::getResults($sql['sql'], $sql['values'], 0, $tableName), 'id');

        $count = 0;
        foreach ($trashedIds as $trashedId) {
            try {
                $this->forceDelete($tableName, $trashedId);
                $count++;
            } catch (\Exception $e) {
                // Continue emptying the rest of the Trash
            }
        }

        return ['count' => $count];
    }

    // ── Bidirectional relation sync ───────────────────────────────────────────

    /**
     * After a create or update, keep the inverse column of every bidirectional
     * CCT relation in sync with the values just written.
     *
     * @param TableModel        $table
     * @param int|string        $recordId   ID of the record that was just saved
     * @param array<string,mixed> $newData  Column data after prepare() (arrays for POST_TYPE)
     * @param \stdClass|null    $oldRecord  Raw DB row before the update, null on create
     */
    private function syncBidirectionalRelations(
        TableModel $table,
        $recordId,
        array $newData,
        ?\stdClass $oldRecord
    ): void {
        foreach ($table->getColumns() as $column) {
            $rel = $column->getUiField()->relationship;

            if (!$rel || !$rel->bidirectional) {
                continue;
            }

            $colName      = $column->getName();
            $targetTable  = $rel->getTargetTable();
            $inverseField = $rel->getInverseField();

            if (!$targetTable || !$inverseField) {
                continue;
            }

            // Skip columns not explicitly submitted to avoid clearing relations on partial updates
            if (!array_key_exists($colName, $newData)) {
                continue;
            }

            $newIds = $this->normalizeRelIds($newData[$colName]);
            $oldIds = $oldRecord !== null
                ? $this->normalizeRelIds($oldRecord->{$colName} ?? [])
                : [];

            $added   = array_diff($newIds, $oldIds);
            $removed = array_diff($oldIds, $newIds);
            $touched = false;

            foreach ($added as $targetId) {
                $metaId   = $targetTable . ':' . $targetId;
                $existing = Meta::fetch($metaId, MetaTypes::TABLE, $inverseField);
                $existing = is_array($existing) ? $existing : [];
                if (!in_array((string)$recordId, array_map('strval', $existing), true)) {
                    $existing[] = $recordId;
                    Meta::save($metaId, MetaTypes::TABLE, $inverseField, $existing);
                    $touched = true;
                }
            }

            foreach ($removed as $targetId) {
                $metaId   = $targetTable . ':' . $targetId;
                $existing = Meta::fetch($metaId, MetaTypes::TABLE, $inverseField);
                $existing = is_array($existing) ? $existing : [];
                $updated  = array_values(array_filter($existing, fn ($v) => (string)$v !== (string)$recordId));
                if (count($updated) < count($existing)) {
                    if (empty($updated)) {
                        Meta::delete($metaId, MetaTypes::TABLE, $inverseField);
                    } else {
                        Meta::save($metaId, MetaTypes::TABLE, $inverseField, $updated);
                    }
                    $touched = true;
                }
            }

            if ($touched) {
                $this->evictCache($targetTable);
            }
        }
    }

    /**
     * Normalises a relational column value (PHP array, JSON string, or comma-separated
     * string) to a plain array of non-empty string IDs.
     *
     * A Relationship column's real, schema-declared value shape is an array of
     * {id, type} objects (TableColumnModel::JSONItems()), not scalar ids — each
     * element is extracted to its `id` below. The legacy comma-separated-string
     * path (TableRecordController::sanitize()'s POST_TYPE handling) can still
     * produce plain scalar ids, so scalar elements are passed through as-is.
     *
     * @param mixed $value
     * @return array<int, string>
     */
    private function normalizeRelIds($value): array
    {
        $items = null;

        if (is_array($value)) {
            $items = $value;
        } elseif (is_string($value) && $value !== '') {
            $decoded = json_decode($value, true);
            $items = is_array($decoded) ? $decoded : array_map('trim', explode(',', $value));
        }

        if ($items === null) {
            return [];
        }

        $ids = array_map(function ($item) {
            if (is_array($item) && array_key_exists('id', $item)) {
                return (string) $item['id'];
            }
            if (is_object($item) && isset($item->id)) {
                return (string) $item->id;
            }
            return is_scalar($item) ? (string) $item : '';
        }, $items);

        return array_values(array_filter($ids, fn ($v) => $v !== ''));
    }

    // ── Cache ─────────────────────────────────────────────────────────────────

    /**
     * Evicts all cached record reads for this controller.
     *
     * ACPT_DB tags every cached query with md5(CallingClass::get()), which
     * resolves to the calling class — TableRecordController in all cases here.
     * invalidateCacheTag(self::class) therefore evicts exactly the record-level
     * cache without touching the table-definition cache (tagged with TableRepository).
     *
     * Per-table granularity is not possible without extending ACPT_DB, because
     * the cache tag is derived from the calling class, not from the query content.
     * Evicting the whole controller cache on any write is the correct tradeoff:
     * it prevents stale reads while keeping the implementation simple.
     */
    private function evictCache(string $tableName): void
    {
        ACPT_DB::invalidateCacheTag($tableName);
    }

    // ── Write pipeline ────────────────────────────────────────────────────────

    /**
     * Full prepare pipeline for create and update:
     *   0. Normalize repeater/flexible fields from UI (legacy blocks) format to API format
     *   1. Resolve file uploads / pass-through URLs
     *   2. Sanitize each value by its UI column type
     *   3. Validate against the strict record JSON Schema
     *
     * @param TableModel                $table
     * @param array<string, mixed>      $data
     * @param array<string, mixed>|null $files
     * @return array<string, mixed>
     * @throws \Exception On validation failure (message from swaggest).
     */
    private function prepare(TableModel $table, array $data, ?array $files): array
    {
        // 0a. Drop any column the current user is not allowed to write, per that
        //     column's own Permissions rules (ticket #1242). Partial-update safe:
        //     a stripped column is simply left untouched, exactly as if the caller
        //     had omitted it. Covers the V1 REST path and the admin record form
        //     (TableRecordPageGenerator::handleUpdateOrCreate() delegates here).
        $data = $this->stripUnwritableColumns($table, $data);

        // 0. Normalize complex field types from UI (legacy blocks) format to API format
        $data = $this->normalizeRepeaterFields($table, $data);
        $data = $this->normalizeFlexibleContentFields($table, $data);

        $validationSchema = $table->writeModelSchema();

        // 1. Resolve file uploads / pass-through URLs using the files schema
        //    as the authoritative source of file columns and their constraints
        $data = TableRecordFileHandler::resolve($validationSchema['files'], $data, $files);

        // 2. Sanitize each value by the column's UI type
        $data = $this->sanitize($table, $data);

        // 2b. Hash password fields before they reach the DB
        $data = $this->hashPasswordFields($table, $data);

        // 2c. Normalize date/time values to canonical ISO formats before schema validation.
        //     Any supported display format (e.g. 'June 18, 2026', '4:00 PM') is converted
        //     to the format the JSON Schema expects: Y-m-d, Y-m-d\TH:i:s, H:i:s.
        $data = $this->normalizeDateFields($table, $data);

        // 3. Validate the json part — additionalProperties: false rejects unknown fields
        $validator = new JSONSchemaValidator(new TableRecordSchema($table));
        $validator->validate($data);

        // 4. Enforce each column's own validation rules, matching what the admin
        //    record form does client-side (DataValidateAttributes / ACPTFormValidator)
        //    and what AbstractSaveMetaCommand does for meta fields. Ticket #1238.
        $this->validateColumnRules($table, $data);

        return $data;
    }

    /**
     * Remove from the write payload every column the current user has no `edit`
     * verdict on (per the column's own PermissionObject rules). A column not in
     * the payload is left untouched by the upsert, so a restricted caller's
     * partial update just silently ignores the columns they cannot write —
     * matching how omitting a column already behaves. Ticket #1242.
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function stripUnwritableColumns(TableModel $table, array $data): array
    {
        foreach ($table->getColumns() as $column) {
            if (!$column->hasPermissions()) {
                continue;
            }

            $name = $column->getName();

            if (array_key_exists($name, $data) && !$column->userColumnPermissions()['edit']) {
                unset($data[$name]);
            }
        }

        return $data;
    }

    /**
     * Remove from an API-format response every column the current user has no
     * `read` verdict on. Ticket #1242. Only applied to the 'api' format —
     * admin ('ui') surfaces render through their own path.
     *
     * @param TableModel $table
     * @param \stdClass  $row
     * @return \stdClass
     */
    private function filterUnreadableColumns(TableModel $table, \stdClass $row): \stdClass
    {
        foreach ($table->getColumns() as $column) {
            if (!$column->hasPermissions()) {
                continue;
            }

            $name = $column->getName();

            if (property_exists($row, $name) && !$column->userColumnPermissions()['read']) {
                unset($row->{$name});
            }
        }

        return $row;
    }

    /**
     * @param TableModel           $table
     * @param array<string, mixed> $data
     *
     * @throws ValidationException
     */
    private function validateColumnRules(TableModel $table, array $data): void
    {
        $flat  = [];
        $keyed = [];

        foreach ($table->getColumns() as $column) {
            $name = $column->getName();

            // Partial-update safe: a column not present in this payload is not
            // re-validated (mirrors AbstractSaveMetaCommand::validateField()).
            if (!array_key_exists($name, $data) || empty($column->getValidationRules())) {
                continue;
            }

            // "required" for a column = a blank value is not acceptable, i.e. it is
            // NOT (nullable and not UI-required) — mirrors TableColumnModel's own
            // "null is an accepted value" test.
            $columnIsRequired = !($column->isNullable() && !$column->getUiField()->isRequired);

            $checker = new ValidationRulesChecker(
                $data[$name],
                ValidationRuleModel::fromValueObjects($column->getValidationRules()),
                $column->isTextual(),
                $columnIsRequired
            );
            $checker->validate();

            if (!$checker->isValid()) {
                $keyed[$name] = $checker->getErrors();
                $flat        = array_merge($flat, $checker->getErrors());
            }
        }

        if (!empty($flat)) {
            throw new ValidationException($flat, $keyed);
        }
    }

    /**
     * Normalizes repeater fields that arrive in the UI (original_name) format
     * to the canonical API format expected by the JSON Schema.
     *
     * UI format:  { fieldName: [{original_name: X, value: Y}, ...], ... }
     * API format: [{fieldName: Y, ...}, ...]
     *
     * Detection: UI format has string keys at the top level of the repeater value;
     * API format has integer keys (row indices). Non-repeater columns are left untouched.
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeRepeaterFields(TableModel $table, array $data): array
    {
        foreach ($table->getColumns() as $column) {
            if ($column->getUiField()->type !== MetaFieldModel::REPEATER_TYPE) {
                continue;
            }

            $name = $column->getName();

            if (!array_key_exists($name, $data) || !is_array($data[$name]) || empty($data[$name])) {
                continue;
            }

            // UI format has string keys (field names); API format has integer keys (row indices)
            if (is_string(array_key_first($data[$name]))) {
                $data[$name] = $this->pivotRepeaterFromUIFormat($data[$name]);
            }
        }

        return $data;
    }

    /**
     * Pivots the UI repeater structure into an array of row objects.
     *
     * Input:  ['fieldA' => [['original_name'=>'fieldA','value'=>'x'], ...], 'fieldB' => [...], ...]
     * Output: [['fieldA' => 'x', 'fieldB' => ...], ...]
     *
     * @param array<string, mixed> $uiValue
     * @return array<int, array<string, mixed>>
     */
    private function pivotRepeaterFromUIFormat(array $uiValue): array
    {
        $rows = [];

        foreach ($uiValue as $fieldName => $entries) {
            if (!is_array($entries)) {
                continue;
            }

            foreach ($entries as $i => $entry) {
                $value = is_array($entry) && array_key_exists('value', $entry)
                    ? $entry['value']
                    : $entry;

                $rows[$i][$fieldName] = $value;
            }
        }

        return array_values($rows);
    }

    /**
     * Converts flexible content fields that arrive in the admin UI's legacy blocks format
     * into the canonical CCT native flat-row format expected by the JSON Schema.
     *
     * Admin form format: {'blocks': {'0': {'blockNormalName': {'fieldName': {'0': value}}}}}
     * API / schema format: [{'_block': 'blockNormalName', 'fieldName': value}, ...]
     *
     * The conversion is the inverse of CCTValueNormalizer::toFlexibleContentLegacyFormat().
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeFlexibleContentFields(TableModel $table, array $data): array
    {
        foreach ($table->getColumns() as $column) {
            if ($column->getUiField()->type !== MetaFieldModel::FLEXIBLE_CONTENT_TYPE) {
                continue;
            }

            $name = $column->getName();

            if (!array_key_exists($name, $data) || !is_array($data[$name])) {
                continue;
            }

            $value = $data[$name];

            // CCT: _flex_marker + no blocks = user cleared all blocks → save empty array.
            if (isset($value['_flex_marker']) && (!isset($value['blocks']) || !is_array($value['blocks']))) {
                $data[$name] = [];
                continue;
            }

            // Only convert if it looks like the legacy blocks envelope.
            // Already-native arrays (numeric keys, each entry has '_block') pass through.
            if (!isset($value['blocks']) || !is_array($value['blocks'])) {
                continue;
            }

            $native = [];
            foreach ($value['blocks'] as $blockGroup) {
                if (!is_array($blockGroup)) {
                    continue;
                }
                foreach ($blockGroup as $blockNormalName => $fields) {
                    if (!is_array($fields)) {
                        // '[]' is the placeholder from the hidden input (block with no sub-fields).
                        // Record the block row with only the _block discriminator.
                        if ($fields === '[]') {
                            $native[] = ['_block' => $blockNormalName];
                        }
                        continue;
                    }
                    // Each field is keyed by element index [0], [1], [2]...
                    // Determine how many element rows this block has.
                    $elementCount = 1;
                    foreach ($fields as $fieldValues) {
                        if (is_array($fieldValues)) {
                            $elementCount = max($elementCount, count($fieldValues));
                        }
                    }
                    for ($elementIdx = 0; $elementIdx < $elementCount; $elementIdx++) {
                        $row = ['_block' => $blockNormalName];
                        foreach ($fields as $fieldName => $fieldValues) {
                            if (!is_array($fieldValues)) {
                                $row[$fieldName] = $fieldValues;
                                continue;
                            }
                            $val = $fieldValues[$elementIdx] ?? $fieldValues[(string)$elementIdx] ?? null;
                            // Some field types nest under a 'value' key.
                            if (is_array($val) && array_key_exists('value', $val)) {
                                $val = $val['value'];
                            }
                            $row[$fieldName] = $val;
                        }
                        $native[] = $row;
                    }
                }
            }

            $data[$name] = $native;
        }

        return $data;
    }

    /**
     * Sanitizes each present field using the column's UI type as the policy.
     * Columns without a UI type fall back to TEXT_TYPE.
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function sanitize(TableModel $table, array $data): array
    {
        // Strip only CCT meta-field keys (tableName[fieldName] format) that WordPress
        // injects into form submissions. All other keys reach the schema validator so
        // that additionalProperties: false can reject genuinely unknown fields with 400.
        $allowed = array_flip(array_merge(
            [$table->getPrimaryKey(), 'locations'],
            array_map(fn (TableColumnModel $c) => $c->getName(), $table->getColumns())
        ));
        $data = array_filter($data, fn ($key) => isset($allowed[$key]) || strpos($key, '[') === false, ARRAY_FILTER_USE_KEY);

        foreach ($table->getColumns() as $column) {
            $name = $column->getName();

            if (!array_key_exists($name, $data)) {
                continue;
            }

            // File columns are already resolved to {url, attachment_id} arrays by
            // TableRecordFileHandler::resolve(); calling sanitize_url() on an array
            // would corrupt the value to an empty string.
            if ($column->isFile()) {
                continue;
            }

            $uiType = $column->getUiField()->type ?: MetaFieldModel::TEXT_TYPE;

            // POST_TYPE columns are submitted by PostField as comma-separated IDs ("1,2,3").
            // Convert to a plain integer/string array so it matches the write schema.
            if ($uiType === MetaFieldModel::POST_TYPE) {
                if (is_string($data[$name]) && $data[$name] !== '') {
                    $ids = array_filter(array_map('trim', explode(',', $data[$name])));
                    $data[$name] = array_values(array_map(
                        fn ($id) => is_numeric($id) ? (int) $id : $id,
                        $ids
                    ));
                } elseif ($data[$name] === '' || $data[$name] === null) {
                    $data[$name] = [];
                }
                // already an array — leave as-is
                continue;
            }

            // Compound-object columns accept convenience input (a bare string, or the
            // legacy meta shape with keys like 'amount'/'weight'/'length'/'country') in
            // addition to the canonical CCT shape. Coerce to canonical before the schema
            // validator runs — it enforces additionalProperties: false and would otherwise
            // reject anything that isn't already in {value: ..., unit: ...} form.
            // CCTFieldShape::coerce() passes already-canonical values through unchanged and
            // returns null when it can't make sense of the input, in which case the original
            // value is left as-is so schema validation reports the real error.
            if (in_array($uiType, self::COERCIBLE_COMPOUND_TYPES, true)) {
                $coerced = CCTFieldShape::coerce($data[$name], $uiType);
                if ($coerced !== null) {
                    $data[$name] = $coerced;
                }
            }

            $data[$name] = Sanitizer::sanitizeRawData($uiType, $data[$name]);
        }

        return $data;
    }

    /**
     * Hash password columns before persistence, mirroring AbstractSaveMetaCommand.
     * Skips absent keys (partial updates) and empty values to avoid overwriting good hashes.
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function hashPasswordFields(TableModel $table, array $data): array
    {
        foreach ($table->getColumns() as $column) {
            if ($column->getUiField()->type !== MetaFieldModel::PASSWORD_TYPE) {
                continue;
            }

            $name = $column->getName();

            if (!array_key_exists($name, $data) || $data[$name] === '' || $data[$name] === null) {
                continue;
            }

            $algo         = $column->getUiField()->getAdvancedOption('algorithm') ?? PASSWORD_DEFAULT;
            $data[$name]  = Strings::hashPassword((string)$data[$name], (string)$algo);
        }

        return $data;
    }

    /**
     * Normalises date/time column values to canonical ISO formats so they satisfy
     * the JSON Schema format constraints and are stored correctly in MySQL.
     *
     * DATE_TYPE      → Y-m-d            (format: 'date')
     * DATE_TIME_TYPE → Y-m-d\TH:i:s    (format: 'date-time', T separator required by Opis)
     * TIME_TYPE      → H:i:s            (format: 'time')
     * DATE_RANGE_TYPE → {from:Y-m-d, to:Y-m-d}
     *
     * Unknown formats are left untouched; the JSON Schema validator will then
     * reject them with a descriptive 400 error.
     *
     * @param TableModel           $table
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeDateFields(TableModel $table, array $data): array
    {
        foreach ($table->getColumns() as $column) {
            $name   = $column->getName();
            $uiType = $column->getUiField()->type;

            if (!array_key_exists($name, $data)) {
                continue;
            }

            switch ($uiType) {

                case MetaFieldModel::ADDRESS_MULTI_TYPE:
                    if (is_array($data[$name])) {
                        if (isset($data[$name]['value'])) {
                            // CCT UI form: {value: 'a1___###___a2', lat: 'l1___###___l2', ...}
                            $vals      = array_values(array_filter(explode(Address::MULTI_STRING_SEPARATOR, (string)$data[$name]['value'])));
                            $lats      = explode(Address::MULTI_STRING_SEPARATOR, (string)($data[$name]['lat']     ?? ''));
                            $lngs      = explode(Address::MULTI_STRING_SEPARATOR, (string)($data[$name]['lng']     ?? ''));
                            $cities    = explode(Address::MULTI_STRING_SEPARATOR, (string)($data[$name]['city']    ?? ''));
                            $countries = explode(Address::MULTI_STRING_SEPARATOR, (string)($data[$name]['country'] ?? ''));
                            $result    = [];
                            foreach ($vals as $i => $addr) {
                                $result[] = [
                                    'value'   => trim($addr),
                                    'lat'     => trim($lats[$i]      ?? ''),
                                    'lng'     => trim($lngs[$i]      ?? ''),
                                    'city'    => trim($cities[$i]    ?? ''),
                                    'country' => trim($countries[$i] ?? ''),
                                ];
                            }
                            $data[$name] = $result;
                        } else {
                            // REST API: sequential array of strings or already-structured objects
                            $data[$name] = array_values(array_map(static function ($item) {
                                if (is_string($item)) {
                                    return ['value' => $item, 'lat' => '', 'lng' => '', 'city' => '', 'country' => ''];
                                }
                                return (array) $item;
                            }, $data[$name]));
                        }
                    } elseif (is_string($data[$name]) && $data[$name] !== '') {
                        // Legacy fallback: separator-joined string without coordinate metadata
                        $data[$name] = array_values(array_map(
                            static fn ($a) => ['value' => trim($a), 'lat' => '', 'lng' => '', 'city' => '', 'country' => ''],
                            array_filter(explode(Address::MULTI_STRING_SEPARATOR, $data[$name]))
                        ));
                    }
                    break;


                case MetaFieldModel::DATE_TYPE:
                    if (is_string($data[$name]) && $data[$name] !== '') {
                        $normalized = DateNormalizer::toDate($data[$name]);
                        if ($normalized !== null) {
                            $data[$name] = $normalized;
                        }
                    }
                    break;

                case MetaFieldModel::DATE_TIME_TYPE:
                    if (is_string($data[$name]) && $data[$name] !== '') {
                        $normalized = DateNormalizer::toDateTime($data[$name]);
                        if ($normalized !== null) {
                            $data[$name] = $normalized;
                        }
                    }
                    break;

                case MetaFieldModel::TIME_TYPE:
                    if (is_string($data[$name]) && $data[$name] !== '') {
                        $normalized = DateNormalizer::toTime($data[$name]);
                        if ($normalized !== null) {
                            $data[$name] = $normalized;
                        }
                    }
                    break;

                case MetaFieldModel::DATE_RANGE_TYPE:
                    // String path: UI sends "25.06.2026 - 20.07.2026"
                    if (is_string($data[$name]) && $data[$name] !== '') {
                        $parsed = DateNormalizer::toDateRange($data[$name]);
                        if ($parsed !== null) {
                            $data[$name] = $parsed;
                        }
                        break;
                    }
                    // Array path: already ['from' => ..., 'to' => ...]
                    if (is_array($data[$name])) {
                        foreach (['from', 'to'] as $key) {
                            if (isset($data[$name][$key]) && is_string($data[$name][$key]) && $data[$name][$key] !== '') {
                                $normalized = DateNormalizer::toDate($data[$name][$key]);
                                if ($normalized !== null) {
                                    $data[$name][$key] = $normalized;
                                }
                            }
                        }
                    }
                    break;

                case MetaFieldModel::USER_MULTI_TYPE:
                case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:
                case MetaFieldModel::POST_OBJECT_MULTI_TYPE:
                    if (is_string($data[$name]) && !empty($data[$name])) {
                        $postIds = explode(",", $data[$name]);

                        // return array of post IDs as int
                        $data[$name] = array_map(fn ($postId) => (int)$postId, $postIds);
                    }
                    break;
            }
        }

        return $data;
    }

    // ── Protected helpers (used by TableRecordHttpAdapter) ────────────────────

    /**
     * @param string $tableName
     *
     * @return TableModel
     *
     * @throws NotFoundException
     */
    public function resolveTable(string $tableName): TableModel
    {
        $table = TableRepository::getByName($tableName);

        if (empty($table)) {
            throw new NotFoundException("Table {$tableName} was not found");
        }

        if (!$table->hasAPrimaryKey()) {
            throw new NotFoundException("Table {$tableName} does not have an id strategy of a primary key");
        }

        return $table;
    }

    /**
     * Fetches a single record by id, excluding soft-deleted rows unless $includeTrashed is true.
     *
     * @param TableModel $table
     * @param int|string $id
     * @param bool       $includeTrashed  When true, a soft-deleted row is also matched (needed by restore()).
     *
     * @return \stdClass|null
     *
     * @throws NotFoundException
     */
    public function fetchRecord(TableModel $table, $id, bool $includeTrashed = false): ?\stdClass
    {
        $where = [$table->getPrimaryKey() => $id];

        if ($table->withSoftDelete() && !$includeTrashed) {
            $where['deleted_at'] = ['operator' => 'IS NULL'];
        }

        $sql    = $table->selectQuery(['where' => $where, 'limit' => 1]);
        $result = ACPT_DB::getResults($sql['sql'], $sql['values'], 7200, $table->getName());

        if (empty($result)) {
            throw new NotFoundException(
                "Record with id {$id} was not found in table {$table->getName()}"
            );
        }

        // invoke $table->JSONRepresentation
        return $result[0];
    }
}
