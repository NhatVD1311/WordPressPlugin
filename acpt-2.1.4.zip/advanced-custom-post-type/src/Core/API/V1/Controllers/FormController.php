<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\CQRS\Command\DeleteFormCommand;
use ACPT\Core\CQRS\Command\SaveFormCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\JSON\FormSchema;
use ACPT\Core\Repository\FormRepository;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\Data\ValidationException;

class FormController extends AbstractController
{
    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function getAll(\WP_REST_Request $request): \WP_REST_Response
    {
        try {
            $page = isset($request['page']) ? $request['page'] : 1;
            $perPage = isset($request['per_page']) ? $request['per_page'] : 20;
            $search = isset($request['search']) ? sanitize_text_field($request['search']) : null;

            if ($perPage > 100) {
                $perPage = 100;
            }

            $count = FormRepository::count(['search' => $search]);
            $maxPages = ceil($count / $perPage);

            $records = FormRepository::get([
                'page' => $page,
                'perPage' => $perPage,
                'search' => $search,
            ]);

            return $this->jsonPaginatedResponse($page, (int)$maxPages, $perPage, $count, $records);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function get(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        try {
            $form = FormRepository::getById($id);

            if (empty($form)) {
                return $this->jsonNotFoundResponse('Not records found');
            }

            return $this->jsonResponse($form);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function create(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->createOrSaveForm($request, 201);
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function update(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->createOrSaveForm($request, 200, $request['id']);
    }

    /**
     * @param \WP_REST_Request $request
     * @param int $httpStatus
     * @param string|null $id
     *
     * @return \WP_REST_Response
     */
    private function createOrSaveForm(\WP_REST_Request $request, int $httpStatus = 200, ?string $id = null): \WP_REST_Response
    {
        $data = $this->getDecodedRequest($request);

        if ($data === null) {
            return $this->jsonResponse([
                'message' => 'empty request body'
            ], 500);
        }

        if (!is_array($data)) {
            return $this->jsonResponse([
                'message' => 'data is not an array'
            ], 500);
        }

        if ($id !== null) {
            $form = FormRepository::getById($id);
            if (empty($form)) {
                return $this->jsonNotFoundResponse('Form not found');
            }
        }

        try {
            $id = $this->saveForm($data, $id);

            return $this->jsonResponse([
                'id' => $id
            ], $httpStatus);
        } catch (ValidationException $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonBadRequestResponse($exception->getFormattedErrors());
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param array<string, mixed> $data
     * @param string|null $id
     *
     * @return string
     * @throws \Exception
     */
    private function saveForm(array $data, ?string $id = null): string
    {
        // validate data
        $this->validateJSONSchema($data, new FormSchema());

        // sanitize data
        $data = Sanitizer::recursiveSanitizeRawData($data);

        $data['id'] = $id ? $id : Uuid::v4();
        $command = new SaveFormCommand($data);

        return $command->execute();
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function delete(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        try {
            $command = new DeleteFormCommand($id);
            $command->execute();

            return $this->jsonResponse([
                'id' => $id
            ], 200);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }
}
