<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\Helper\Uuid;
use ACPT\Core\JSON\AbstractJSONSchema;
use ACPT\Utils\Data\JSONSchemaValidator;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\PHP\Url;
use ACPT\Utils\Wordpress\Nonce;

abstract class AbstractController
{
    protected string $nonce;

    protected Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
        $this->nonce = Nonce::generate();
    }

    // ── Request helpers ───────────────────────────────────────────────────────

    /**
     * @param \WP_REST_Request $request
     * @return mixed|null
     */
    protected function getDecodedRequest(\WP_REST_Request $request)
    {
        $body = $request->get_body();

        if (empty($body)) {
            return null;
        }

        return json_decode($body, true);
    }

    // ── Response helpers ──────────────────────────────────────────────────────

    /**
     * @param mixed $data
     * @param int   $code
     * @return \WP_REST_Response
     */
    protected function jsonResponse($data, $code = 200): \WP_REST_Response
    {
        return new \WP_REST_Response($data, $code);
    }

    /**
     * @param int    $page
     * @param int    $maxPages
     * @param int    $perPage
     * @param int    $count
     * @param mixed  $records
     * @return \WP_REST_Response
     */
    protected function jsonPaginatedResponse(int $page, int $maxPages, int $perPage, int $count, $records): \WP_REST_Response
    {
        return $this->jsonResponse([
            'currentPage' => $page,
            'prev'        => ($page > 1) ? Url::baseUri(['page' => $page - 1, 'per_page' => $perPage]) : null,
            'next'        => ($page < $maxPages) ? Url::baseUri(['page' => $page + 1, 'per_page' => $perPage]) : null,
            'total'       => $count,
            'records'     => $records,
        ]);
    }

    /**
     * @param \Exception $exception
     * @param int        $code
     * @return \WP_REST_Response
     */
    protected function jsonErrorResponse(\Exception $exception, $code = 500): \WP_REST_Response
    {
        return $this->jsonResponse([
            'message' => $exception->getMessage(),
            'code'    => ($exception->getCode() !== 0 ? $exception->getCode() : $code),
        ], $code);
    }

    /**
     * @param string $message
     * @return \WP_REST_Response
     */
    protected function jsonNotFoundResponse($message): \WP_REST_Response
    {
        return $this->jsonResponse([
            'message' => $message,
            'code' => 404
        ], 404);
    }

    /**
     * @return \WP_REST_Response
     */
    protected function jsonForbiddenResponse(): \WP_REST_Response
    {
        return $this->jsonResponse([
            'message' => 'Forbidden',
            'code' => 403
        ], 403);
    }

    /**
     * @param mixed $message
     * @return \WP_REST_Response
     */
    protected function jsonUnauthorizedResponse($message): \WP_REST_Response
    {
        return $this->jsonResponse([
            'message' => $message,
            'code' => 401
        ], 401);
    }

    /**
     * @param mixed $message
     * @return \WP_REST_Response
     */
    protected function jsonBadRequestResponse($message): \WP_REST_Response
    {
        return $this->jsonResponse([
            'message' => $message,
            'code' => 400
        ], 400);
    }

    // ── Validation helpers ────────────────────────────────────────────────────

    /**
     * Validates request data against a JSON schema.
     * Throws on failure — callers must catch \Exception.
     *
     * @param array<string, mixed> $data
     * @param AbstractJSONSchema   $jsonSchema
     * @throws \Exception
     */
    protected function validateJSONSchema(array $data, AbstractJSONSchema $jsonSchema): void
    {
        (new JSONSchemaValidator($jsonSchema))->validate($data);
    }

    /**
     * Returns true when the value is a syntactically valid UUID v4.
     *
     * @param string $value
     * @return bool
     */
    protected function isValidUuid(string $value): bool
    {
        return Uuid::isV4Valid($value);
    }

    // ── Authorization helpers ─────────────────────────────────────────────────

    /**
     * Returns true when the current user has the given capability.
     *
     * @param string $capability
     * @return bool
     */
    protected function currentUserCan(string $capability): bool
    {
        return current_user_can($capability);
    }
}
