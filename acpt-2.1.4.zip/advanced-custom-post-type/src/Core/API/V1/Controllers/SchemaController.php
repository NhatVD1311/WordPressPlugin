<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\Helper\Features;
use ACPT\Core\Helper\Strings;
use ACPT\Core\JSON\CustomPostTypeSchema;
use ACPT\Core\JSON\DynamicBlockSchema;
use ACPT\Core\JSON\FormSchema;
use ACPT\Core\JSON\MetaGroupSchema;
use ACPT\Core\JSON\OptionPageSchema;
use ACPT\Core\JSON\QueryFilterSchema;
use ACPT\Core\JSON\QueryResultSchema;
use ACPT\Core\JSON\TableColumnSchema;
use ACPT\Core\JSON\TableRecordSchema;
use ACPT\Core\JSON\TableSchema;
use ACPT\Core\JSON\TableStatusSchema;
use ACPT\Core\JSON\TableSyncResponseSchema;
use ACPT\Core\JSON\TaxonomySchema;
use ACPT\Core\JSON\WooCommerceProductDataFieldSchema;
use ACPT\Core\JSON\WooCommerceProductDataSchema;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Integrations\WooCommerce\ACPT_WooCommerce;
use ACPT\Utils\PHP\Request;

class SchemaController extends AbstractController
{
    public const SWAGGER_VERSION = '2.0';

    /**
     * @var \ACPT\Core\Models\Table\TableModel[]
     */
    private array $tables = [];

    public function __construct(Request $request)
    {
        parent::__construct($request);

        if (Features::hasCct()) {
            $this->tables = TableRepository::get();
        }
    }

    /**
     * @return string
     */
    private function getBasePath()
    {
        $restUrl = get_rest_url();

        if (Strings::contains('?rest_route=', $restUrl)) {
            return '/?rest_route=/acpt/v1';
        }

        return '/wp-json/acpt/v1';
    }

    /**
     * @return array<string, mixed>
     * @throws \Exception
     */
    public function schema(): array
    {
        return [
            'swagger' => self::SWAGGER_VERSION,
            'host' => $this->request->server('HTTP_HOST', 'http://localhost:83'),
            'basePath' => $this->getBasePath(),
            'tags' => $this->getTags(),
            'schemes' => $this->getSchemas(),
            'paths' => $this->getPaths(),
            'definitions' => $this->getModelDefinitions(),
            'securityDefinitions' => $this->getSecurityDefinitions(),
            'security' => $this->getSecurity(),
            'externalDocs' => $this->getExternalDocs(),
        ];
    }

    /**
     * Tag definitions
     *
     * @return mixed[]
     */
    private function getTags(): array
    {
        $tags = [];

        if (Features::hasCpt()) {
            $tags[] = [
                'name' => 'cpt',
                'description' => 'Manage ACPT custom post types',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add taxonomy tag if enabled
        if (Features::hasTax()) {
            $tags[] = [
                'name' => 'taxonomy',
                'description' => 'Manage taxonomies',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add option page tag if enabled
        if (Features::hasPages()) {
            $tags[] = [
                'name' => 'option-page',
                'description' => 'Manage option pages',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add meta tag if enabled
        if (Features::hasMeta()) {
            $tags[] = [
                'name' => 'meta',
                'description' => 'Manage custom post types meta',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add block tag if enabled
        if (Features::hasBlocks()) {
            $tags[] = [
                'name' => 'block',
                'description' => 'Manage dynamic blocks',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add form tag if enabled
        if (Features::hasForms()) {
            $tags[] = [
                'name' => 'form',
                'description' => 'Manage forms',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add table tag if enabled
        if (Features::hasCct()) {
            $tags[] = [
                'name' => 'table',
                'description' => 'Manage custom database tables',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add woocommerce tag if WooCommerce is active
        if (ACPT_WooCommerce::active()) {
            $tags[] = [
                'name' => 'woocommerce',
                'description' => 'WooCommerce product data',
                'externalDocs' => $this->getExternalDocs(),
            ];
        }

        // Add filter tag - always available
        $tags[] = [
            'name' => 'filter',
            'description' => 'Filter posts by query',
            'externalDocs' => $this->getExternalDocs(),
        ];

        return $tags;
    }

    /**
     * http schemas
     *
     * @return list<string>
     */
    private function getSchemas(): array
    {
        return [
            'http',
            'https',
        ];
    }

    /**
     * Path definitions
     *
     * @return array<string, mixed>
     * @throws \Exception
     */
    private function getPaths(): array
    {
        $paths = [];

        if (Features::hasCpt()) {
            $paths['/cpt'] = [
                'get' => [
                    'tags' => [
                        'cpt',
                    ],
                    'summary' => 'Get all custom post types',
                    'description' => 'Use this endpoint to fetch all the registered custom post types',
                    'operationId' => 'getAllCpt',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/CustomPostType'),
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'cpt',
                    ],
                    'summary' => 'Create a cpt',
                    'description' => 'Use this endpoint to create a new cpt',
                    'operationId' => 'createCpt',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The cpt model',
                            'schema' => [
                                '$ref' => '#/definitions/CustomPostType',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/cpt/{slug}'] = [
                'get' => [
                    'tags' => [
                        'cpt',
                    ],
                    'summary' => 'Get a single cpt',
                    'description' => 'Use this endpoint to fetch a single registered cpt',
                    'operationId' => 'getCpt',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of cpt',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CustomPostType',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'cpt',
                    ],
                    'summary' => 'Update a single cpt',
                    'description' => 'Use this endpoint to update a single registered cpt',
                    'operationId' => 'updateCpt',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of cpt',
                            'required' => true,
                            'type' => 'string',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The cpt model',
                            'schema' => [
                                '$ref' => '#/definitions/CustomPostType',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CustomPostType',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'cpt',
                    ],
                    'summary' => 'Delete a single cpt',
                    'description' => 'Use this endpoint to delete a single registered cpt',
                    'operationId' => 'deleteCpt',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of cpt',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasTax()) {
            $paths['/taxonomy'] = [
                'get' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Get all taxonomies',
                    'description' => 'Use this endpoint to fetch all the registered taxonomies',
                    'operationId' => 'getAllTaxonomies',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/Taxonomy'),
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Create a taxonomy',
                    'description' => 'Use this endpoint to create a new taxonomy',
                    'operationId' => 'createTaxonomy',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The taxonomy model',
                            'schema' => [
                                '$ref' => '#/definitions/Taxonomy',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/taxonomy/{slug}'] = [
                'get' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Get a single taxonomy',
                    'description' => 'Use this endpoint to fetch a single registered taxonomy',
                    'operationId' => 'getTaxonomy',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of taxonomy',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/Taxonomy',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Update a single taxonomy',
                    'description' => 'Use this endpoint to update a single registered taxonomy',
                    'operationId' => 'updateTaxonomy',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of taxonomy',
                            'required' => true,
                            'type' => 'string',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The taxonomy model',
                            'schema' => [
                                '$ref' => '#/definitions/Taxonomy',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/Taxonomy',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Delete a single taxonomy',
                    'description' => 'Use this endpoint to delete a single registered taxonomy',
                    'operationId' => 'deleteTaxonomy',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of taxonomy',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/taxonomy/assoc/{slug}/{cpt}'] = [
                'post' => [
                    'tags' => [
                        'taxonomy',
                    ],
                    'summary' => 'Associate a taxonomy to a cpt',
                    'description' => 'Use this endpoint to associate a registered taxonomy to a cpt',
                    'operationId' => 'assocTaxonomy',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of taxonomy',
                            'required' => true,
                            'type' => 'string',
                        ],
                        [
                            'name' => 'cpt',
                            'in' => 'path',
                            'description' => 'the slug of custom post type',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                'type' => 'object',
                                'properties' => [
                                    'cptId' => [
                                        'type' => 'string',
                                        'format' => 'uuid',
                                    ],
                                    'taxonomyId' => [
                                        'type' => 'string',
                                        'format' => 'uuid',
                                    ],
                                ],
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ]
            ];
        }

        if (Features::hasPages()) {
            $paths['/option-page'] = [
                'get' => [
                    'tags' => [
                        'option-page',
                    ],
                    'summary' => 'Get all option pages',
                    'description' => 'Use this endpoint to fetch all the registered option pages',
                    'operationId' => 'getAllOptionPages',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/OptionPage'),
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'option-page',
                    ],
                    'summary' => 'Create a option page',
                    'description' => 'Use this endpoint to create a new option page',
                    'operationId' => 'createOptionPage',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The taxonomy model',
                            'schema' => [
                                '$ref' => '#/definitions/OptionPage',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/option-page/{slug}'] = [
                'get' => [
                    'tags' => [
                        'option-page',
                    ],
                    'summary' => 'Get a single option page',
                    'description' => 'Use this endpoint to fetch a single registered option page',
                    'operationId' => 'getOptionPage',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of the option page',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/OptionPage',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'option-page',
                    ],
                    'summary' => 'Update a single option page',
                    'description' => 'Use this endpoint to update a single registered option page',
                    'operationId' => 'updateOptionPage',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of option page',
                            'required' => true,
                            'type' => 'string',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The option page model',
                            'schema' => [
                                '$ref' => '#/definitions/Taxonomy',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/OptionPage',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'option-page',
                    ],
                    'summary' => 'Delete a single option page',
                    'description' => 'Use this endpoint to delete a single registered option page',
                    'operationId' => 'deleteOptionPage',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'slug',
                            'in' => 'path',
                            'description' => 'the slug of option page',
                            'required' => true,
                            'type' => 'string',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasMeta()) {
            $paths['/meta'] = [
                'get' => [
                    'tags' => [
                        'meta',
                    ],
                    'summary' => 'Get the meta groups',
                    'description' => 'Use this endpoint to fetch the meta groups',
                    'operationId' => 'getAllMetaGroups',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/MetaGroup'),
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'meta',
                    ],
                    'summary' => 'Create meta groups',
                    'description' => 'Use this endpoint to create a meta group',
                    'operationId' => 'createMetaGroup',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The meta group model',
                            'schema' => [
                                '$ref' => '#/definitions/MetaGroup',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/meta/{id}'] = [
                'get' => [
                    'tags' => [
                        'meta',
                    ],
                    'summary' => 'Get a single meta group',
                    'description' => 'Use this endpoint to fetch a single meta group',
                    'operationId' => 'getSingleMetaGroup',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of meta group',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/MetaGroup',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'meta',
                    ],
                    'summary' => 'Update meta groups',
                    'description' => 'Use this endpoint to update meta groups',
                    'operationId' => 'updateMetaGroup',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of meta group',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The meta group model',
                            'schema' => [
                                '$ref' => '#/definitions/MetaGroup',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'meta',
                    ],
                    'summary' => 'Delete a single meta group',
                    'description' => 'Use this endpoint to delete a single meta group',
                    'operationId' => 'deleteMetaGroup',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of meta group',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasBlocks()) {
            $paths['/block'] = [
                'get' => [
                    'tags' => [
                        'block',
                    ],
                    'summary' => 'Get the dynamic blocks',
                    'description' => 'Use this endpoint to fetch the dynamic blocks',
                    'operationId' => 'getAllBlocks',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/Block'),
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'block',
                    ],
                    'summary' => 'Create new dynamic block',
                    'description' => 'Use this endpoint to create a block',
                    'operationId' => 'createBlock',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The meta group model',
                            'schema' => [
                                '$ref' => '#/definitions/Block',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/block/{id}'] = [
                'get' => [
                    'tags' => [
                        'block',
                    ],
                    'summary' => 'Get a single block',
                    'description' => 'Use this endpoint to fetch a single dynamic block',
                    'operationId' => 'getSingleBlock',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of block',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/Block',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'block',
                    ],
                    'summary' => 'Update dynamic block',
                    'description' => 'Use this endpoint to update dynamic blocks',
                    'operationId' => 'updateBlock',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of block',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The meta group model',
                            'schema' => [
                                '$ref' => '#/definitions/Block',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'block',
                    ],
                    'summary' => 'Delete a single block',
                    'description' => 'Use this endpoint to delete a single dynamic block',
                    'operationId' => 'deleteBlock',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of block',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/Block',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasForms()) {
            $paths['/form'] = [
                'get' => [
                    'tags' => [
                        'form',
                    ],
                    'summary' => 'Get the forms',
                    'description' => 'Use this endpoint to fetch the forms',
                    'operationId' => 'getAllForms',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/Form'),
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'form',
                    ],
                    'summary' => 'Create forms',
                    'description' => 'Use this endpoint to create a form',
                    'operationId' => 'createForm',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The form model',
                            'schema' => [
                                '$ref' => '#/definitions/Form',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/form/{id}'] = [
                'get' => [
                    'tags' => [
                        'form',
                    ],
                    'summary' => 'Get a single form',
                    'description' => 'Use this endpoint to fetch a single form',
                    'operationId' => 'getSingleForm',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of form',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/Form',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'form',
                    ],
                    'summary' => 'Update form',
                    'description' => 'Use this endpoint to update forms',
                    'operationId' => 'updateForm',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of form',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The form model',
                            'schema' => [
                                '$ref' => '#/definitions/Form',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'form',
                    ],
                    'summary' => 'Delete a single form',
                    'description' => 'Use this endpoint to delete a single form',
                    'operationId' => 'deleteForm',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of form',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasCct()) {
            $paths['/table'] = [
                'get' => [
                    'tags'        => ['table'],
                    'summary'     => 'Get all custom tables',
                    'description' => 'Fetch all registered custom table definitions.',
                    'operationId' => 'getAllTables',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'page',
                            'in'          => 'query',
                            'description' => 'Current page',
                            'required'    => false,
                            'type'        => 'integer',
                        ],
                        [
                            'name'        => 'per_page',
                            'in'          => 'query',
                            'description' => 'Pagination size (max 100)',
                            'required'    => false,
                            'type'        => 'integer',
                            'minimum'     => 1,
                            'maximum'     => 100,
                            'default'     => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => $this->getPaginatedResponse('#/definitions/Table'),
                        ],
                    ],
                ],
                'post' => [
                    'tags'        => ['table'],
                    'summary'     => 'Create a custom table',
                    'description' => 'Create a new custom table definition. Does not create the physical MySQL table — call POST /table/{id}/sync to do that.',
                    'operationId' => 'createTable',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'body',
                            'in'          => 'body',
                            'description' => 'The table model',
                            'schema'      => ['$ref' => '#/definitions/Table'],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/CreateResponse'],
                        ],
                        400 => [
                            'description' => 'Bad request',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        403 => [
                            'description' => 'Forbidden',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        500 => [
                            'description' => 'Error',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                    ],
                ],
            ];
            $paths['/table/{id}'] =  [
                'get' => [
                    'tags'        => ['table'],
                    'summary'     => 'Get a single custom table',
                    'description' => 'Fetch a single custom table definition by id.',
                    'operationId' => 'getTable',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'id',
                            'in'          => 'path',
                            'description' => 'Table id (UUID)',
                            'required'    => true,
                            'type'        => 'string',
                            'format'      => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/Table'],
                        ],
                        400 => [
                            'description' => 'Invalid id format',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        404 => [
                            'description' => 'Not found',
                            'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                        ],
                    ],
                ],
                'put' => [
                    'tags'        => ['table'],
                    'summary'     => 'Update a custom table',
                    'description' => 'Update a custom table definition. Does not alter the physical MySQL table — call POST /table/{id}/sync afterwards.',
                    'operationId' => 'updateTable',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'id',
                            'in'          => 'path',
                            'description' => 'Table id (UUID)',
                            'required'    => true,
                            'type'        => 'string',
                            'format'      => 'uuid',
                        ],
                        [
                            'name'        => 'body',
                            'in'          => 'body',
                            'description' => 'The table model',
                            'schema'      => ['$ref' => '#/definitions/Table'],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/CreateResponse'],
                        ],
                        400 => [
                            'description' => 'Invalid id format or bad request',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        403 => [
                            'description' => 'Forbidden',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        404 => [
                            'description' => 'Not found',
                            'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                        ],
                        500 => [
                            'description' => 'Error',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                    ],
                ],
                'delete' => [
                    'tags'        => ['table'],
                    'summary'     => 'Delete a custom table definition',
                    'description' => 'Delete a custom table definition. Does not drop the physical MySQL table — call POST /table/{id}/sync with a drop action or use drop_acpt_table().',
                    'operationId' => 'deleteTable',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'id',
                            'in'          => 'path',
                            'description' => 'Table id (UUID)',
                            'required'    => true,
                            'type'        => 'string',
                            'format'      => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/DeleteResponse'],
                        ],
                        400 => [
                            'description' => 'Invalid id format',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        403 => [
                            'description' => 'Forbidden',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        404 => [
                            'description' => 'Not found',
                            'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                        ],
                        500 => [
                            'description' => 'Error',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                    ],
                ],
            ];
            $paths['/table/{id}/status'] = [
                'get' => [
                    'tags'        => ['table'],
                    'summary'     => 'Get table schema status',
                    'description' => 'Returns the synchronisation status between the stored definition and the physical MySQL table. Status values: not_created | synced | not_synced.',
                    'operationId' => 'getTableStatus',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'id',
                            'in'          => 'path',
                            'description' => 'Table id (UUID)',
                            'required'    => true,
                            'type'        => 'string',
                            'format'      => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/TableStatus'],
                        ],
                        400 => [
                            'description' => 'Invalid id format',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        404 => [
                            'description' => 'Not found',
                            'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                        ],
                    ],
                ],
            ];
            $paths['/table/{id}/sync'] = [
                'post' => [
                    'tags'        => ['table'],
                    'summary'     => 'Sync table schema',
                    'description' => 'Synchronises the physical MySQL table with the stored definition. Creates the table if it does not exist yet; applies the diff if it is out of sync; no-op if already synced.',
                    'operationId' => 'syncTable',
                    'consumes'    => ['application/json'],
                    'produces'    => ['application/json'],
                    'parameters'  => [
                        [
                            'name'        => 'id',
                            'in'          => 'path',
                            'description' => 'Table id (UUID)',
                            'required'    => true,
                            'type'        => 'string',
                            'format'      => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'Successful operation',
                            'schema'      => ['$ref' => '#/definitions/TableSyncResponse'],
                        ],
                        400 => [
                            'description' => 'Invalid id format',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        403 => [
                            'description' => 'Forbidden',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                        404 => [
                            'description' => 'Not found',
                            'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                        ],
                        500 => [
                            'description' => 'Error',
                            'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                        ],
                    ],
                ],
            ];

            // ── CRUD Routes ──────────────────────────────────────────────────────────
            foreach ($this->tables as $table) {
                $basePath = "/{$table->getName()}";

                if ($table->hasAPrimaryKey() && $table->hasRestAPiSupportFor("read")) {

                    // GET /movies
                    $paths[$basePath]['get'] = [
                        'tags'        => [$table->getName()],
                        'summary'     => 'Get all '.$table->getName().' records',
                        'operationId' => 'getAll' . $table->getName(),
                        'consumes'    => ['application/json'],
                        'produces'    => ['application/json'],
                        'parameters'  => [
                            [
                                'name'        => 'page',
                                'in'          => 'query',
                                'description' => 'Current page',
                                'required'    => false,
                                'type'        => 'integer',
                            ],
                            [
                                'name'        => 'per_page',
                                'in'          => 'query',
                                'description' => 'Pagination size (max 100)',
                                'required'    => false,
                                'type'        => 'integer',
                                'minimum'     => 1,
                                'maximum'     => 100,
                                'default'     => 20,
                            ],
                        ],
                        'responses' => [
                            200 => [
                                'description' => 'Successful operation',
                                'schema'      => $this->getPaginatedResponse('#/definitions/Table'.$table->getName().'ReadModel'),
                            ],
                        ],
                    ];

                    // GET /movies/{id}
                    $paths[$basePath.'/{id}']['get'] = [
                        'tags'        => [$table->getName()],
                        'summary'     => 'Get '.$table->getName().' record',
                        'operationId' => 'get' . $table->getName(),
                        'consumes'    => ['application/json'],
                        'produces'    => ['application/json'],
                        'parameters'  => [
                            [
                                'name'        => 'id',
                                'in'          => 'path',
                                'description' => 'Record id',
                                'required'    => true,
                                'type'        => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'integer' : 'string',
                                'format'      => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'int64' : 'uuid',
                            ],
                        ],
                        'responses' => [
                            200 => [
                                'description' => 'Successful operation',
                                'schema'      => ['$ref' => '#/definitions/Table'.$table->getName().'ReadModel'],
                            ],
                            400 => [
                                'description' => 'Invalid id format',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                            404 => [
                                'description' => 'Not found',
                                'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                            ],
                        ],
                    ];
                }

                // POST /movies
                if ($table->hasRestAPiSupportFor("create")) {
                    $paths[$basePath]['post'] = [
                        'tags'        => [$table->getName()],
                        'summary'     => 'Create a '.$table->getName().' record',
                        'operationId' => 'create' . $table->getName(),
                        'consumes'    => ['form-data'],
                        'produces'    => ['application/json'],
                        'parameters' => [
                            [
                                'name' => 'body',
                                'in' => 'body',
                                'description' => 'The '.$table->getName().' record data model',
                                'schema' => [
                                    '$ref' => '#/definitions/Table'.$table->getName().'WriteModel',
                                ],
                            ],
                        ],
                        'responses' => [
                            201 => [
                                'description' => 'successful operation',
                                'schema' => [
                                    '$ref' => '#/definitions/CreateResponse',
                                ],
                            ],
                            400 => [
                                'description' => 'Invalid id format',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                            500 => [
                                'description' => 'error',
                                'schema' => [
                                    '$ref' => '#/definitions/ErrorResponse',
                                ],
                            ],
                        ],
                    ];
                }

                // PUT /movies/{id}
                if ($table->hasRestAPiSupportFor("update")) {
                    $paths[$basePath.'/{id}']['put'] = [
                        'tags'        => [$table->getName()],
                        'summary'     => 'Update a '.$table->getName().' record',
                        'operationId' => 'update' . $table->getName(),
                        'consumes'    => ['form-data'],
                        'produces'    => ['application/json'],
                        'parameters' => [
                            [
                                'name'        => 'id',
                                'in'          => 'path',
                                'description' => 'Record id',
                                'required'    => true,
                                'type'        => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'integer' : 'string',
                                'format'      => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'int64' : 'uuid',
                            ],
                            [
                                'name' => 'body',
                                'in' => 'body',
                                'description' => 'The '.$table->getName().' record data model',
                                'schema' => [
                                    '$ref' => '#/definitions/Table'.$table->getName().'WriteModel',
                                ],
                            ],
                        ],
                        'responses' => [
                            200 => [
                                'description' => 'successful operation',
                                'schema' => [
                                    '$ref' => '#/definitions/Table'.$table->getName().'ReadModel',
                                ],
                            ],
                            400 => [
                                'description' => 'Invalid id format',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                            500 => [
                                'description' => 'error',
                                'schema' => [
                                    '$ref' => '#/definitions/ErrorResponse',
                                ],
                            ],
                        ],
                    ];
                }

                // DELETE /movies/{id}
                if ($table->hasRestAPiSupportFor("delete")) {
                    $paths[$basePath.'/{id}']['delete'] = [
                        'tags'        => [$table->getName()],
                        'summary'     => 'Delete a '.$table->getName().' record',
                        'operationId' => 'delete' . $table->getName(),
                        'consumes'    => ['application/json'],
                        'produces'    => ['application/json'],
                        'parameters'  => [
                            [
                                'name'        => 'id',
                                'in'          => 'path',
                                'description' => 'Record id',
                                'required'    => true,
                                'type'        => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'integer' : 'string',
                                'format'      => $table->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 'int64' : 'uuid',
                            ],
                        ],
                        'responses' => [
                            200 => [
                                'description' => 'Successful operation',
                                'schema'      => ['$ref' => '#/definitions/DeleteResponse'],
                            ],
                            400 => [
                                'description' => 'Invalid id format',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                            403 => [
                                'description' => 'Forbidden',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                            404 => [
                                'description' => 'Not found',
                                'schema'      => ['$ref' => '#/definitions/NotFoundResponse'],
                            ],
                            500 => [
                                'description' => 'Error',
                                'schema'      => ['$ref' => '#/definitions/ErrorResponse'],
                            ],
                        ],
                    ];
                }
            }
        }

        if (ACPT_WooCommerce::active()) {
            $paths['/woocommerce/product-data'] = [
                'get' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Get all WooCommerce product data',
                    'description' => 'Use this endpoint to fetch all the registered WooCommerce product data',
                    'operationId' => 'getAllWooCommerceProductData',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'page',
                            'in' => 'query',
                            'description' => 'current page',
                            'required' => false,
                            'type' => 'integer',
                        ],
                        [
                            'name' => 'per_page',
                            'in' => 'query',
                            'description' => 'choose pagination size (Max 100)',
                            'required' => false,
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                            'default' => 20,
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => $this->getPaginatedResponse('#/definitions/WooCommerceProductData'),
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Create a WooCommerce product data',
                    'description' => 'Use this endpoint to create a new WooCommerce product data',
                    'operationId' => 'createWooCommerceProductData',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The WooCommerce product data model',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceProductData',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/CreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/woocommerce/product-data/{id}'] = [
                'get' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Get a single WooCommerce product data',
                    'description' => 'Use this endpoint to fetch a single registered WooCommerce product data',
                    'operationId' => 'getWooCommerceProductData',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceProductData',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Update a single WooCommerce product data',
                    'description' => 'Use this endpoint to update a single registered WooCommerce product data',
                    'operationId' => 'updateWooCommerceProductData',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'The WooCommerce product data model',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceProductData',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceProductData',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Delete a single WooCommerce product data',
                    'description' => 'Use this endpoint to delete a single registered WooCommerce product data',
                    'operationId' => 'deleteWooCommerceProductData',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/woocommerce/product-data/{id}/fields'] = [
                'get' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Get the WooCommerce product data fields',
                    'description' => 'Use this endpoint to fetch the product data associated to a single WooCommerce product data',
                    'operationId' => 'getWooCommerceProductDataFields',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                'type' => 'array',
                                'items' => [
                                    '$ref' => '#/definitions/WooCommerceProductDataField'
                                ]
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'post' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Create WooCommerce product data fields',
                    'description' => 'Use this endpoint to create WooCommerce product data fields',
                    'operationId' => 'createWooCommerceProductDataFields',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'Array ofWooCommerce product data fields models',
                            'type' => 'array',
                            'items' => [
                                '$ref' => '#/definitions/WooCommerceProductDataField',
                            ],
                        ],
                    ],
                    'responses' => [
                        201 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceFieldsCreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'put' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Update WooCommerce product data fields',
                    'description' => 'Use this endpoint to update WooCommerce product data fields',
                    'operationId' => 'updateWooCommerceProductDataFields',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'body',
                            'in' => 'body',
                            'description' => 'Array ofWooCommerce product data fields models',
                            'type' => 'array',
                            'items' => [
                                '$ref' => '#/definitions/WooCommerceProductDataField',
                            ],
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceFieldsCreateResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Delete all WooCommerce product data fields',
                    'description' => 'Use this endpoint to delete all fields associated to single WooCommerce product data',
                    'operationId' => 'deleteWooCommerceProductDataFields',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
            $paths['/woocommerce/product-data/{id}/fields/{field}'] = [
                'get' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Get a single WooCommerce product data field',
                    'description' => 'Use this endpoint to fetch a single registered WooCommerce product data field',
                    'operationId' => 'getWooCommerceProductDataField',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the id of WooCommerce product data field',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/WooCommerceProductDataField',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                    ],
                ],
                'delete' => [
                    'tags' => [
                        'woocommerce',
                    ],
                    'summary' => 'Delete a single WooCommerce product data field',
                    'description' => 'Use this endpoint to delete a single registered WooCommerce product data field',
                    'operationId' => 'deleteWooCommerceProductFataField',
                    'consumes' => [
                        'application/json',
                    ],
                    'produces' => [
                        'application/json',
                    ],
                    'parameters' => [
                        [
                            'name' => 'id',
                            'in' => 'path',
                            'description' => 'the slug of cpt',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                        [
                            'name' => 'field',
                            'in' => 'path',
                            'description' => 'the slug of cpt',
                            'required' => true,
                            'type' => 'string',
                            'format' => 'uuid',
                        ],
                    ],
                    'responses' => [
                        200 => [
                            'description' => 'successful operation',
                            'schema' => [
                                '$ref' => '#/definitions/DeleteResponse',
                            ],
                        ],
                        404 => [
                            'description' => 'record not found',
                            'schema' => [
                                '$ref' => '#/definitions/NotFoundResponse',
                            ],
                        ],
                        500 => [
                            'description' => 'error',
                            'schema' => [
                                '$ref' => '#/definitions/ErrorResponse',
                            ],
                        ],
                    ],
                ],
            ];
        }

        if (Features::hasCpt()) {
            $cpts = CustomPostTypeRepository::get([]);

            foreach ($cpts as $cpt) {
                $path = '/' . $cpt->getName() . '/filter/query';

                $paths[ $path ] = [
                    'post' => [
                        'tags' => [
                            'filter',
                        ],
                        'summary' => 'Advanced posts search',
                        'description' => 'Use this endpoint to search post',
                        'operationId' => 'queryFilter',
                        'consumes' => [
                            'application/json',
                        ],
                        'produces' => [
                            'application/json',
                        ],
                        'parameters' => [
                            [
                                'name' => 'body',
                                'in' => 'body',
                                'description' => 'The filters array',
                                'type' => 'object',
                                'schema' => [
                                    '$ref' => '#/definitions/QueryFilter',
                                ],
                            ],
                            [
                                'name' => 'page',
                                'in' => 'query',
                                'description' => 'current page',
                                'required' => false,
                                'type' => 'integer',
                                'default' => 1,
                            ],
                            [
                                'name' => 'per_page',
                                'in' => 'query',
                                'description' => 'choose pagination size (Max 100)',
                                'required' => false,
                                'type' => 'integer',
                                'minimum' => 1,
                                'maximum' => 100,
                                'default' => 20,
                            ],
                        ],
                        'responses' => [
                            200 => [
                                'description' => 'successful operation',
                                'schema' => $this->getPaginatedResponse('#/definitions/QueryResult'),
                            ],
                        ],
                    ],
                ];
            }
        }

        return $paths;
    }

    /**
     * Model definitions
     *
     * @return array<string, mixed>
     */
    private function getModelDefinitions(): array
    {
        $definitions = [];

        if (Features::hasCpt()) {
            $definitions['CustomPostType'] = (new CustomPostTypeSchema())->toArray();
        }

        if (Features::hasBlocks()) {
            $definitions['Block'] = (new DynamicBlockSchema())->toArray();
        }

        if (Features::hasMeta()) {
            $definitions['MetaGroup'] = (new MetaGroupSchema())->toArray();
        }

        if (Features::hasForms()) {
            $definitions['Form'] = (new FormSchema())->toArray();
        }

        if (Features::hasPages()) {
            $definitions['OptionPage'] = (new OptionPageSchema())->toArray();
        }

        if (Features::hasTax()) {
            $definitions['Taxonomy'] = (new TaxonomySchema())->toArray();
        }

        $definitions['QueryFilter'] = (new QueryFilterSchema())->toArray();

        if (ACPT_WooCommerce::active()) {
            $definitions['WooCommerceProductData'] = (new WooCommerceProductDataSchema())->toArray();
            $definitions['WooCommerceProductDataField'] = (new WooCommerceProductDataFieldSchema())->toArray();
        }

        if (Features::hasCct()) {
            $definitions['Table']            = (new TableSchema())->toArray();
            $definitions['TableColumn']      = (new TableColumnSchema())->toArray();
            $definitions['TableStatus']      = (new TableStatusSchema())->toArray();
            $definitions['TableSyncResponse'] = (new TableSyncResponseSchema())->toArray();

            foreach ($this->tables as $table) {
                $definitions['Table'.$table->getName().'ReadModel'] = (new TableRecordSchema($table, "read"))->toArray();
                $definitions['Table'.$table->getName().'WriteModel'] = (new TableRecordSchema($table, "write"))->toArray();
            }
        }

        return array_merge([
            'QueryResult' => (new QueryResultSchema())->toArray(),
            'CreateResponse' => $this->getCreateResponse(),
            'CreateMetaGroupResponse' => $this->getCreateMetaGroupResponse(),
            'DeleteResponse' => $this->getDeleteResponse(),
            'DeleteMultiResponse' => $this->getDeleteMultiResponse(),
            'NotFoundResponse' => $this->getNotFoundResponse(),
            'ErrorResponse' => $this->getErrorResponse(),
        ], $definitions);
    }

    /**
     * Security definitions
     *
     * @return array<string, mixed>
     */
    private function getSecurityDefinitions(): array
    {
        return [
            'ApiKeyAuth' => [
                'type' => 'apiKey',
                'in' => 'header',
                'name' => 'acpt-api-key',
            ],
            'BasicAuth' => [
                'type' => 'basic'
            ],
        ];
    }

    /**
     * Security
     *
     * @return list<array<string, array<string, string[]>>>
     */
    private function getSecurity(): array
    {
        return [
            [
                'ApiKeyAuth' => []
            ],
            [
                'BasicAuth' => []
            ],
        ];
    }

    /**
     * Paginated response
     *
     * @param string $ref
     *
     * @return array<string, mixed>
     */
    private function getPaginatedResponse(string $ref): array
    {
        return [
                'type' => 'object',
                'properties' => [
                        'currentPage' => [
                            'type' => 'integer',
                            'example' => 1,
                        ],
                        'prev' => [
                                'type' => 'string',
                                'nullable' => true,
                        ],
                        'next' => [
                                'type' => 'string',
                                'nullable' => true,
                        ],
                        'total' => [
                                'type' => 'integer',
                        ],
                        'records' => [
                                'type' => 'array',
                                'items' => [
                                        '$ref' => $ref
                                ],
                        ],
                ],
        ];
    }

    /** @return array<string, mixed> */
    private function getCreateResponse(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'id' => $this->idDefinition(),
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function getCreateMetaGroupResponse(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'ids' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'slug' => [
                                'type' => 'array',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        "boxes" => [
                                            'type' => 'array',
                                            'items' => [
                                                'type' => 'string',
                                                'format' => 'uuid',
                                            ]
                                        ],
                                        "fields" => [
                                            'type' => 'array',
                                            'items' => [
                                                'type' => 'string',
                                                'format' => 'uuid',
                                            ]
                                        ],
                                        "options" => [
                                            'type' => 'array',
                                            'items' => [
                                                'type' => 'string',
                                                'format' => 'uuid',
                                            ]
                                        ],
                                    ]
                                ]
                            ]
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     * @phpstan-ignore-next-line method.unused
     */
    private function getWooCommerceFieldsCreateResponse()
    {
        return [
            'type' => 'object',
            'properties' => [
                'ids' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                              "product_data_id" => [
                                  'type' => 'string',
                                  'format' => 'uuid',
                              ],
                              "field" => [
                                  'type' => 'string',
                                  'format' => 'uuid',
                              ],
                              "options" => [
                                    'type' => 'array',
                                    'items' => [
                                        'type' => 'string',
                                        'format' => 'uuid',
                                    ]
                              ],
                        ],
                    ],
                ]
            ]
        ];
    }

    /** @return array<string, mixed> */
    private function getDeleteResponse(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'id' =>  $this->idDefinition(),
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function getDeleteMultiResponse(): array
    {
        return [
                'type' => 'object',
                'properties' => [
                    'ids' => [
                        'type' => 'array',
                        'items' => $this->idDefinition(),
                    ],
                ],
        ];
    }

    /** @return array<string, mixed> */
    private function getNotFoundResponse(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'message' => [
                    'type' => 'string',
                ],
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function getErrorResponse(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'message' => [
                    'type' => 'string',
                ],
                'code' => [
                    'type' => 'integer',
                ],
                'line' => [
                    'type' => 'integer',
                ],
                'trace' => [
                    'type' => 'string',
                ],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function idDefinition(): array
    {
        return [
            'oneOf' => [
                [
                    'type' => 'string',
                    'format' => 'uuid',
                ],
                [
                    'type' => 'integer',
                    'format' => 'int64',
                ],
            ],
        ];
    }

    /**
     * External docs links
     *
     * @return array<string, mixed>
     */
    private function getExternalDocs(): array
    {
        return [
            'description' => 'Find out more about ACPT',
            'url' => $this->documentationLink(),
        ];
    }

    /**
     * @return string
     */
    private function documentationLink()
    {
        return 'https://docs.acpt.io';
    }
}
