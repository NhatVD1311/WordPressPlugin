<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\CQRS\Command\HandleFormSubmissionCommand;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Form\FormModel;
use ACPT\Core\Repository\FormRepository;
use ACPT\Utils\PHP\Serializer;

class FormSubmissionController extends AbstractController
{
    public function submit(\WP_REST_Request $request): \WP_REST_Response
    {
        try {
            $key = $request['key'];
            $formModel = FormRepository::getByKey($key);

            if ($formModel === null) {
                throw new \Exception('Form not found');
            }

            if (
                $this->request->post('acpt_form_submission') == 1 &&
                $this->request->post('acpt_form_id') === $formModel->getId()
            ) {
                // verify X_WP_Nonce
                $nonce = $request->get_header('X_WP_Nonce');

                if (!wp_verify_nonce($nonce, 'wp_rest')) {
                    return $this->jsonResponse(['message' => 'Invalid nonce', 'code' => 403], 403);
                }

                $postId   = (!empty($this->request->post('acpt_form_post_id'))) ? (int)filter_var($this->request->post('acpt_form_post_id'), FILTER_SANITIZE_NUMBER_INT) : null;
                $termId   = (!empty($this->request->post('acpt_form_term_id'))) ? (int)filter_var($this->request->post('acpt_form_term_id'), FILTER_SANITIZE_NUMBER_INT) : null;
                $userId   = (!empty($this->request->post('acpt_form_user_id'))) ? (int)filter_var($this->request->post('acpt_form_user_id'), FILTER_SANITIZE_NUMBER_INT) : null;
                $recordId = (!empty($this->request->post('acpt_form_record_id'))) ?
                    is_numeric($this->request->post('acpt_form_record_id')) ?
                        (int)filter_var($this->request->post('acpt_form_record_id'), FILTER_SANITIZE_NUMBER_INT) :
                        (string)filter_var($this->request->post('acpt_form_record_id'), FILTER_UNSAFE_RAW)
                    :
                    null;

                $this->request->unsetPost('acpt_form_submission');
                $this->request->unsetPost('acpt_form_id');
                $this->request->unsetPost('acpt_form_post_id');
                $this->request->unsetPost('acpt_form_term_id');
                $this->request->unsetPost('acpt_form_user_id');
                $this->request->unsetPost('acpt_form_record_id');
                $this->request->unsetPost('_wp_http_referer');

                $command = new HandleFormSubmissionCommand($formModel, $this->request, $postId, $termId, $userId, $recordId);
                $submission = $command->execute();

                if (!empty($submission['errors'])) {
                    return $this->jsonResponse([
                        'outcome' => 'An error(s) occurred',
                        'errors' => $submission['errors'],
                        'redirectTo' => '',
                        'redirectTimeout' => null,
                    ], 400);
                }

                $outcomeMessage = ($formModel->getMetaDatum('outcome_message') !== null) ? $formModel->getMetaDatum('outcome_message')->getValue() : "The form was successfully submitted. Redirect in 4 seconds...";
                $redirectTimeout = ($formModel->getMetaDatum('redirect_timeout') !== null) ? $formModel->getMetaDatum('redirect_timeout')->getValue() : 4;

                return $this->jsonResponse([
                    'outcome' => $outcomeMessage,
                    'errors' => [],
                    'redirectTo' => $this->redirectUrl($formModel),
                    'redirectTimeout' => $redirectTimeout
                ]);
            }

            throw new \Exception('Form not submitted');
        } catch (\Exception $exception) {
            $errCode = $exception->getCode() >= 400 ? $exception->getCode() : 500;

            do_action("acpt/error", $exception);

            return $this->jsonResponse([
                'outcome' => 'ko',
                'errors' => [$exception->getMessage()],
                'redirectTo' => null,
                'redirectTimeout' => null,
            ], $errCode);
        }
    }

    /**
     * @param FormModel $formModel
     * @return string
     */
    private function redirectUrl(FormModel $formModel)
    {
        $savedRedirectTo = $formModel->getMetaDatum('redirect_to');
        $savedRedirectToType = $formModel->getMetaDatum('redirect_to_type');
        $savedRedirectToTypeValue = (!empty($savedRedirectToType)) ? $savedRedirectToType->getValue() : "url";
        $redirectTo = (!empty($savedRedirectTo)) ? $savedRedirectTo->getValue() : $this->request->post('_wp_http_referer');

        if (is_serialized($redirectTo)) {
            $redirectTo = Serializer::unserialize($redirectTo);
        }

        if (is_array($redirectTo)) {
            $redirectTo = $redirectTo[0] ?? null;
        }

        // Serializer::unserialize() downgrades any embedded object to a harmless
        // __PHP_Incomplete_Class (PHP Object Injection hardening) rather than to null/''.
        // empty() treats objects as always non-empty, so without this guard such a value
        // would sail past the empty() check below and fatal a moment later against the
        // strictly-typed `string`/`?string` params downstream (Strings::contains(),
        // str_replace(), etc.) — turning a stored-object payload (however it got there:
        // legacy pre-fix data, or a legitimate save-form call) into a hard crash on every
        // future submission instead of the safe empty-value fallback this was meant to be.
        if (!is_string($redirectTo)) {
            $redirectTo = '';
        }

        // if redirectTo is empty, redirect to the referer page
        if (empty($redirectTo)) {
            return $this->request->httpReferer();
        }

        switch ($savedRedirectToTypeValue) {
            default:
            case "url":
                $theURLContainsSiteUrl = Strings::contains(site_url(), $redirectTo);

                // In case of external redirect, like https://google.com,
                // flush the cache and then redirect
                if (!$theURLContainsSiteUrl) {
                    return $redirectTo;
                }

                $redirectTo = str_replace(site_url(), "", $redirectTo);

                return esc_url(site_url($redirectTo));

            case "post":
                $permalink = get_permalink((int)$redirectTo);

                if ($permalink === false) {
                    return "";
                }

                return $permalink;

            case "post_archive":
                $archiveLink = get_post_type_archive_link($redirectTo);

                if ($archiveLink === false) {
                    return "";
                }

                return $archiveLink;

            case "tax_archive":

                $term = get_term((int)$redirectTo);

                if ($term instanceof \WP_Term) {
                    $link = get_term_link($redirectTo, $term->taxonomy);

                    if ($link instanceof \WP_Error) {
                        return "";
                    }

                    return $link;
                }

                return "";
        }
    }
}
