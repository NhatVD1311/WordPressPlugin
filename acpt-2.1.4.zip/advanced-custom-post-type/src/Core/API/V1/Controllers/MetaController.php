<?php

namespace ACPT\Core\API\V1\Controllers;

use ACPT\Core\CQRS\Command\DeleteMetaGroupCommand;
use ACPT\Core\CQRS\Command\SaveMetaGroupCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\JSON\MetaGroupSchema;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\Data\ValidationException;

class MetaController extends AbstractController
{
    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function getAll(\WP_REST_Request $request): \WP_REST_Response
    {
        try {
            $page = isset($request['page']) ? $request['page'] : 1;
            $perPage = isset($request['per_page']) ? $request['per_page'] : 20;
            $search = isset($request['search']) ? sanitize_text_field($request['search']) : null;

            if ($perPage > 100) {
                $perPage = 100;
            }

            $count = MetaRepository::count(['search' => $search]);
            $maxPages = (int)ceil($count / $perPage);

            $records = MetaRepository::get([
                'page' => $page,
                'perPage' => $perPage,
                'search' => $search,
            ]);

            return $this->jsonPaginatedResponse($page, $maxPages, $perPage, $count, $records);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function get(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        try {
            $meta = MetaRepository::get([
                'id' => $id,
            ]);

            if (empty($meta)) {
                return $this->jsonNotFoundResponse('Not records found');
            }

            return $this->jsonResponse($meta[0]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * Create meta boxes
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function create(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->createOrUpdateMetaGroup($request, 201);
    }

    /**
     * Save meta boxes
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public function update(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->createOrUpdateMetaGroup($request, 200, $request['id']);
    }

    /**
     * @param \WP_REST_Request $request
     * @param int $httpStatus
     * @param string|null $groupId
     *
     * @return \WP_REST_Response
     */
    private function createOrUpdateMetaGroup(\WP_REST_Request $request, int $httpStatus = 200, ?string $groupId = null): \WP_REST_Response
    {
        $data = $this->getDecodedRequest($request);

        if (empty($data)) {
            return $this->jsonResponse([
                'message' => 'empty request body'
            ], 400);
        }

        if (!is_array($data)) {
            return $this->jsonResponse([
                'message' => 'data is not an array'
            ], 400);
        }

        try {
            $id = $this->saveMetaGroup($data, $groupId);

            return $this->jsonResponse([
                'id' => $id
            ], $httpStatus);
        } catch (ValidationException $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonBadRequestResponse($exception->getFormattedErrors());
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function delete(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = $request['id'];

        try {
            $command = new DeleteMetaGroupCommand($id);
            $command->execute();

            return $this->jsonResponse([
                'id' => $id
            ], 200);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $this->jsonErrorResponse($exception);
        }
    }

    /**
     * @param array<string, mixed> $data
     * @param string|null $groupId
     *
     * @return string
     * @throws \Exception
     */
    private function saveMetaGroup(array $data, ?string $groupId = null): string
    {
        // validate data
        $this->validateJSONSchema($data, new MetaGroupSchema());

        // sanitize data
        $data = Sanitizer::recursiveSanitizeRawData($data);

        $data['id'] = $groupId ? $groupId : Uuid::v4();
        $command = new SaveMetaGroupCommand($data);

        return $command->execute();
    }
}
