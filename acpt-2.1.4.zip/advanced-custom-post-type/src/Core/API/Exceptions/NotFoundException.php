<?php

namespace ACPT\Core\API\Exceptions;

class NotFoundException extends \Exception
{
}
