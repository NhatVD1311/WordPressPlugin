<?php

namespace ACPT\Core\API\Exceptions;

class UnauthorizedException extends \Exception
{
}
