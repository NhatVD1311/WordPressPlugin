<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Admin\ACPT_License_Manager;
use ACPT\Core\CQRS\Command\InstallDepencencyCommand;
use ACPT\Core\CQRS\Query\FetchChangelogQuery;
use ACPT\Core\CQRS\Query\FetchLanguagesQuery;
use ACPT\Core\CQRS\Query\FetchLicenseQuery;
use ACPT\Core\Helper\Features;
use ACPT\Utils\Http\ACPTApiClient;
use ACPT\Utils\PHP\IP;

class LicenseController extends AbstractController
{
    /**
     * @throws \Exception
     *
     * @return void
     */
    public function deactivateLicenseAction(): void
    {
        try {
            // @phpstan-ignore-next-line booleanNot.alwaysFalse
            if (!ACPT_IS_LICENSE_VALID) {
                throw new \Exception('License is not valid');
            }

            $licenseActivation = ACPT_License_Manager::getLicense();
            $deactivation = ACPTApiClient::call('/license/deactivate', [
                'id' => $licenseActivation['activation_id'],
            ]);

            if (!isset($deactivation['id'])) {
                $message = 'An unexpected error has occurred while connecting to the ACPT servers. You must deactivate this license on your ACPT dashboard.';
            } else {
                $message = 'License successfully deactivated.';
            }

            ACPT_License_Manager::destroy();

            wp_send_json([
                'success' => true,
                'message' => $message
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'error' => $exception->getMessage()
            ], 500);
        }
    }

    /**
     * @return void
     */
    public function fetchChangelogAction(): void
    {
        try {
            $query = new FetchChangelogQuery();

            wp_send_json($query->execute());
        } catch (\Exception $exception) {
            wp_send_json([]);
        }
    }

    /**
     * @throws \Exception
     *
     * @return void
     */
    public function fetchLicenseAction(): void
    {
        // @phpstan-ignore-next-line booleanNot.alwaysFalse
        if (!ACPT_IS_LICENSE_VALID) {
            $referer = json_encode([
                'site' => site_url(),
                'siteName' => get_bloginfo('name'),
                'ip' => IP::getClientIP(),
            ]);

            if (empty($referer)) {
                $referer = 'unknown';
            }

            $link = "https://acpt.io/activation?referer=".base64_encode($referer);

            wp_send_json([
                "code" => null,
                "expiring_date" => null,
                "is_valid" => false,
                "max_activations" => null,
                "activations_count" => null,
                "is_dev" => false,
                "is_multiuser" => false,
                "currentVersion" => ACPT_PLUGIN_VERSION,
                "licenseActivation" => null,
                'activationLink' => $link,
            ]);
        }

        try {
            $query = new FetchLicenseQuery();

            wp_send_json($query->execute());
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'error' => $exception->getMessage()
            ], 500);
        }
    }

    /**
     * @throws \Exception
     *
     * @return void
     */
    public function fetchLogsAction(): void
    {
        if (!Features::hasLogs()) {
            wp_send_json([]);
        }

        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $date = $data['date'] ?? (new \DateTime())->format("Y-m-d");

            $logsFile = WP_CONTENT_DIR . "/acpt-logs/log-{$date}.json";

            if (!file_exists($logsFile)) {
                wp_send_json([]);
            }

            $content = file_get_contents($logsFile);

            if (empty($content)) {
                wp_send_json([]);
            }

            $decoded = json_decode($content);

            if (empty($decoded)) {
                wp_send_json([]);
            }

            wp_send_json($decoded);
        }

        wp_send_json([]);
    }

    /**
     * @return void
     */
    public function installMissingDependenciesAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['dependency'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'No dependency sent'
                ], 500);
            }

            try {
                $dependency = $data['dependency'];
                $command = new InstallDepencencyCommand($dependency);
                $command->execute();

                wp_send_json([
                    'success' => true,
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'error' => (!empty($exception->getMessage())) ? $exception->getMessage() : 'Error during install occurred'
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * Return the string translations
     * @throws \Exception
     *
     * @return void
     */
    public function languagesAction(): void
    {
        $query = new FetchLanguagesQuery();

        wp_send_json($query->execute());
    }
}
