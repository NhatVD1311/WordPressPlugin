<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\CQRS\Command\DeleteTableGroupCommand;
use ACPT\Core\CQRS\Command\SaveTableGroupCommand;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Repository\TableGroupRepository;

class TableGroupController extends AbstractController
{
    public function fetchTableGroupsAction(): void
    {
        $id = null;
        $name = null;
        $page = 1;
        $perPage = 20;
        $search = null;

        if (!empty($this->request->post('data'))) {
            $data    = $this->sanitizeJsonData($this->request->post('data'));
            $id      = $data['id']      ?? null;
            $name    = $data['name']    ?? null;
            $page    = $data['page']    ?? 1;
            $perPage = $data['perPage'] ?? 20;
            $search  = isset($data['search']) ? $data['search'] : null;
        }

        if (!empty($id)) {
            $group = TableGroupRepository::getById($id);
            if ($group !== null && !($group->userPermissions()['read'] ?? false)) {
                wp_send_json(['success' => false, 'error' => 'You do not have permission to read this table group'], 403);
            }
            wp_send_json($group);
        }

        if (!empty($name)) {
            $group = TableGroupRepository::getByName($name);
            if ($group !== null && !($group->userPermissions()['read'] ?? false)) {
                wp_send_json(['success' => false, 'error' => 'You do not have permission to read this table group'], 403);
            }
            wp_send_json($group);
        }

        $queryArgs = [
            'page'    => $page,
            'perPage' => $perPage,
        ];

        if ($search !== null) {
            $queryArgs['search'] = $search;
        }

        wp_send_json([
            'count'   => TableGroupRepository::count($search !== null ? ['search' => $search] : []),
            'records' => TableGroupRepository::get($queryArgs),
        ]);
    }

    public function saveTableGroupAction(): void
    {
        if (empty($this->request->post('data'))) {
            wp_send_json(['success' => false, 'error' => 'No data was sent']);
        }

        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!empty($data['id'])) {
            $existing = TableGroupRepository::getById($data['id']);
            if ($existing !== null && !($existing->userPermissions()['edit'] ?? false)) {
                wp_send_json(['success' => false, 'error' => 'You do not have permission to edit this table group'], 403);
            }
        }

        try {
            $d = [
                'id'            => $data['id']            ?? Uuid::v4(),
                'name'          => $data['name']          ?? null,
                'label'         => $data['label']         ?? null,
                'display'       => $data['display']       ?? null,
                'context'       => $data['context']       ?? null,
                'priority'      => $data['priority']      ?? null,
                'sort'          => $data['sort']          ?? 0,
                'location'      => $data['location']      ?? [],
                'tableIds'      => $data['tableIds']      ?? [],
            ];

            $command = new SaveTableGroupCommand($d);
            $command->execute();

            wp_send_json(['success' => true]);
        } catch (\Exception $exception) {
            do_action('acpt/error', $exception);
            wp_send_json(['success' => false, 'error' => $exception->getMessage()], 500);
        }
    }

    public function deleteTableGroupAction(): void
    {
        if (empty($this->request->post('data'))) {
            wp_send_json(['success' => false, 'error' => 'No data was sent']);
        }

        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (empty($data['id'])) {
            wp_send_json(['success' => false, 'error' => 'Missing group id']);
        }

        $existing = TableGroupRepository::getById($data['id']);
        if ($existing !== null && !($existing->userPermissions()['edit'] ?? false)) {
            wp_send_json(['success' => false, 'error' => 'You do not have permission to delete this table group'], 403);
        }

        try {
            $command = new DeleteTableGroupCommand($data['id']);
            $command->execute();
            wp_send_json(['success' => true]);
        } catch (\Exception $exception) {
            do_action('acpt/error', $exception);
            wp_send_json(['success' => false, 'error' => $exception->getMessage()], 500);
        }
    }
}
