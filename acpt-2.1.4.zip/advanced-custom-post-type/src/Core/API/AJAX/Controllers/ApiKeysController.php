<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\CQRS\Command\GenerateApiKeyCommand;
use ACPT\Core\Repository\ApiRepository;

class ApiKeysController extends AbstractController
{
    /**
     * Delete API key
     */
    public function deleteApiKeyAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                        'success' => false,
                        'error' => 'Missing id'
                ]);
            }

            $id = $data['id'];

            try {
                ApiRepository::delete($id);

                $return = [
                        'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                        'success' => false,
                        'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
                'success' => false,
                'error' => 'no data was sent'
        ]);
    }

    /**
     * Fetch Api keys
     *
     * @throws \Exception
     */
    public function fetchApiKeysAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $page = isset($data['page']) ? $data['page'] : null;
            $perPage = isset($data['perPage']) ? $data['perPage'] : null;
        }

        $count = ApiRepository::count([
            'uid' => get_current_user_id(),
        ]);

        $keys = ApiRepository::getPaginated([
            'uid' => get_current_user_id(),
            'page' => isset($page) ? $page : 1,
            'perPage' => isset($perPage) ? $perPage : 20,
        ]);

        wp_send_json([
            'count' => $count,
            'records' => $keys,
        ]);
    }

    /**
     * Fetch API key count (by uid)
     */
    public function fetchApiKeysCountAction(): void
    {
        wp_send_json(ApiRepository::count([
                'uid' => get_current_user_id(),
        ]));
    }

    /**
     * Generate an API key
     *
     * @throws \Exception
     */
    public function generateApiKeyAction(): void
    {
        try {
            $command = new GenerateApiKeyCommand(get_current_user_id());
            $apiKeyModel = $command->execute();

            wp_send_json([
                'success' => true,
                'data' => [
                    'key' => $apiKeyModel->getKey(),
                    'secret' => $apiKeyModel->getSecret(),
                ]
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                    'error' => $exception->getMessage()
            ], 500);
        }
    }
}
