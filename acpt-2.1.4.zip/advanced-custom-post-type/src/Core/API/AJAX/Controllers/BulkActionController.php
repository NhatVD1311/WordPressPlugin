<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Constants\MetaTypes;
use ACPT\Core\API\Exceptions\NotFoundException;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\CQRS\Command\DeleteBlockCommand;
use ACPT\Core\CQRS\Command\DeleteCustomPostTypeCommand;
use ACPT\Core\CQRS\Command\DeleteDatasetCommand;
use ACPT\Core\CQRS\Command\DeleteFormCommand;
use ACPT\Core\CQRS\Command\DeleteMetaGroupCommand;
use ACPT\Core\CQRS\Command\DeleteOptionPageCommand;
use ACPT\Core\CQRS\Command\DeleteTaxonomyCommand;
use ACPT\Core\CQRS\Command\DeleteWooCommerceProductDataCommand;
use ACPT\Core\CQRS\Command\DuplicateBlockCommand;
use ACPT\Core\CQRS\Command\DuplicateCustomPostTypeCommand;
use ACPT\Core\CQRS\Command\DuplicateDatasetCommand;
use ACPT\Core\CQRS\Command\DuplicateFormCommand;
use ACPT\Core\CQRS\Command\DuplicateMetaGroupCommand;
use ACPT\Core\CQRS\Command\DuplicateOptionPageCommand;
use ACPT\Core\CQRS\Command\DuplicateTaxonomyCommand;
use ACPT\Core\CQRS\Command\DuplicateWooCommerceProductDataCommand;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\Formatter\Driver\CSVFormatter;
use ACPT\Utils\Data\Formatter\Driver\JSONFormatter;

class BulkActionController extends AbstractController
{
    public function bulkActionsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['action'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing action'
                ]);
            }

            if (!isset($data['belongsTo'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing belongsTo'
                ]);
            }

            if (!isset($data['elements'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing elements'
                ]);
            }

            $action = $data['action'];
            $elements = $data['elements'];
            $belongsTo = $data['belongsTo'];
            $command = null;

            /** @var string[] $failedDeletes elements whose delete returned false (ticket #1246) */
            $failedDeletes = [];

            try {
                switch ($action) {

                    case "export_csv":
                    case "export_json":
                        $rows = [];

                        foreach ($elements as $element => $toExport) {
                            if (!$toExport) {
                                continue;
                            }

                            $parts = explode('::', $element, 4);
                            if (count($parts) !== 4) {
                                continue;
                            }

                            [$rawValue, $ctx, $box, $field] = $parts;

                            $getArgs = ['box_name' => $box, 'field_name' => $field, 'return' => 'raw'];
                            $row     = [
                                'context'     => $ctx,
                                'post_id'     => '',
                                'term_id'     => '',
                                'user_id'     => '',
                                'comment_id'  => '',
                                'option_page' => '',
                                'box_name'    => $box,
                                'field_name'  => $field,
                                'value'       => null,
                            ];

                            switch ($ctx) {
                                case 'cpt': case 'media':
                                    $getArgs['post_id'] = (int)$rawValue;
                                    $row['post_id']     = (int)$rawValue;
                                    break;
                                case 'tax':
                                    $getArgs['term_id'] = (int)$rawValue;
                                    $row['term_id']     = (int)$rawValue;
                                    break;
                                case 'op':
                                    $getArgs['option_page'] = $rawValue;
                                    $row['option_page']     = $rawValue;
                                    break;
                                case 'user':
                                    $getArgs['user_id'] = (int)$rawValue;
                                    $row['user_id']     = (int)$rawValue;
                                    break;
                                case 'comment':
                                    $getArgs['comment_id'] = (int)$rawValue;
                                    $row['comment_id']     = (int)$rawValue;
                                    break;
                            }

                            $row['value'] = get_acpt_field($getArgs);
                            $rows[]       = $row;
                        }

                        $timestamp = date('Ymd-His');

                        if ($action === 'export_json') {
                            $content  = JSONFormatter::format($rows);
                            $filename = 'acpt-meta-keys-' . $timestamp . '.json';
                            $mimeType = 'application/json';
                        } else {
                            $csvRows = [['context', 'post_id', 'term_id', 'user_id', 'comment_id', 'option_page', 'box_name', 'field_name', 'value']];
                            foreach ($rows as $row) {
                                $row['value'] = is_array($row['value']) ? json_encode($row['value'], JSON_UNESCAPED_UNICODE) : $row['value'];
                                $csvRows[]    = array_values($row);
                            }
                            $content  = CSVFormatter::format($csvRows);
                            $filename = 'acpt-meta-keys-' . $timestamp . '.csv';
                            $mimeType = 'text/csv';
                        }

                        wp_send_json([
                            'success'  => true,
                            'data'     => $content,
                            'filename' => $filename,
                            'mimeType' => $mimeType,
                        ]);

                        // delete
                        // no break
                    case "delete":
                        foreach ($elements as $element => $toDelete) {
                            if ($toDelete) {
                                switch ($belongsTo) {

                                    case "meta_key":
                                        $parts = explode('::', $element, 4);
                                        if (count($parts) === 4) {
                                            [$rawValue, $ctx, $box, $field] = $parts;
                                            $deleteArgs = ['box_name' => $box, 'field_name' => $field];
                                            switch ($ctx) {
                                                case 'cpt':
                                                case 'media':
                                                    $deleteArgs['post_id'] = (int)$rawValue;
                                                    break;
                                                case 'tax':
                                                    $deleteArgs['term_id'] = (int)$rawValue;
                                                    break;
                                                case 'op':
                                                    $deleteArgs['option_page'] = $rawValue;
                                                    break;
                                                case 'user':
                                                    $deleteArgs['user_id'] = (int)$rawValue;
                                                    break;
                                                case 'comment':
                                                    $deleteArgs['comment_id'] = (int)$rawValue;
                                                    break;
                                            }
                                            if (!delete_acpt_meta_field_value($deleteArgs)) {
                                                $failedDeletes[] = (string)$element;
                                            }
                                        }
                                        continue 2;

                                    default:
                                    case MetaTypes::CUSTOM_POST_TYPE:
                                        $command = new DeleteCustomPostTypeCommand($element);
                                        break;

                                    case MetaTypes::TAXONOMY:
                                        $command = new DeleteTaxonomyCommand($element);
                                        break;

                                    case MetaTypes::TABLE:
                                        TableRepository::delete($element);
                                        break;

                                    case MetaTypes::TABLE_GROUP:
                                        TableGroupRepository::delete($element);
                                        break;

                                    case 'tableRecord':
                                        $tableName = $data['tableName'] ?? null;
                                        if (!empty($tableName)) {
                                            $table = TableRepository::getByName($tableName, true);
                                            if ($table !== null && !($table->userPermissions()['delete'] ?? false)) {
                                                continue 2;
                                            }

                                            $controller = new TableRecordController();
                                            try {
                                                $controller->delete($tableName, $element);
                                            } catch (NotFoundException $e) {
                                                // record already gone — skip
                                            }
                                        }
                                        break;

                                    case MetaTypes::META:
                                        $command = new DeleteMetaGroupCommand($element);
                                        break;

                                    case MetaTypes::OPTION_PAGE:
                                        $command = new DeleteOptionPageCommand($element);
                                        break;

                                    case "block":
                                        $command = new DeleteBlockCommand($element);
                                        break;

                                    case "form":
                                        $command = new DeleteFormCommand($element);
                                        break;

                                    case "dataset":
                                        $command = new DeleteDatasetCommand($element);
                                        break;

                                    case "woo_product_data":
                                        $command = new DeleteWooCommerceProductDataCommand($element);
                                        break;
                                }

                                if ($command !== null) {
                                    $command->execute();
                                }
                            }
                        }

                        break;

                        // duplicate
                    case "duplicate":
                        foreach ($elements as $element => $toDuplicate) {
                            if ($toDuplicate) {
                                switch ($belongsTo) {

                                    default:
                                    case MetaTypes::CUSTOM_POST_TYPE:
                                        $command = new DuplicateCustomPostTypeCommand($element);
                                        break;

                                    case MetaTypes::TAXONOMY:
                                        $command = new DuplicateTaxonomyCommand($element);
                                        break;

                                    case MetaTypes::META:
                                        $command = new DuplicateMetaGroupCommand($element);
                                        break;

                                    case MetaTypes::OPTION_PAGE:
                                        $command = new DuplicateOptionPageCommand($element);
                                        break;

                                    case "form":
                                        $command = new DuplicateFormCommand($element);
                                        break;

                                    case "dataset":
                                        $command = new DuplicateDatasetCommand($element);
                                        break;

                                    case "woo_product_data":
                                        $command = new DuplicateWooCommerceProductDataCommand($element);
                                        break;
                                }

                                $command->execute();
                            }
                        }

                        break;
                }

                if (!empty($failedDeletes)) {
                    wp_send_json([
                        'success' => false,
                        'error'   => sprintf(
                            '%d of the selected items could not be deleted.',
                            count($failedDeletes)
                        ),
                        'failed'  => $failedDeletes,
                    ]);
                }

                wp_send_json([
                    'success' => true,
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ]);
            }
        }
    }

    public function duplicateAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['find'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing `find`'
            ]);
        }

        if (!isset($data['belongsTo'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing `belongsTo`'
            ]);
        }

        try {
            $belongsTo = $data['belongsTo'];
            $element = $data['find'];

            switch ($belongsTo) {

                default:
                case MetaTypes::CUSTOM_POST_TYPE:
                    $command = new DuplicateCustomPostTypeCommand($element);
                    break;

                case MetaTypes::TAXONOMY:
                    $command = new DuplicateTaxonomyCommand($element);
                    break;

                case MetaTypes::META:
                    $command = new DuplicateMetaGroupCommand($element);
                    break;

                case MetaTypes::OPTION_PAGE:
                    $command = new DuplicateOptionPageCommand($element);
                    break;

                case "block":
                    $command = new DuplicateBlockCommand($element);
                    break;

                case "form":
                    $command = new DuplicateFormCommand($element);
                    break;

                case "dataset":
                    $command = new DuplicateDatasetCommand($element);
                    break;

                case "woo_product_data":
                    $command = new DuplicateWooCommerceProductDataCommand($element);
                    break;
            }

            $command->execute();

            $return = [
                'success' => true,
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return);
    }
}
