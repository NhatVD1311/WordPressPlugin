<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Constants\FormAction;
use ACPT\Core\CQRS\Command\DeleteFormCommand;
use ACPT\Core\CQRS\Command\SaveFormCommand;
use ACPT\Core\CQRS\Command\SaveFormFieldsCommand;
use ACPT\Core\CQRS\Query\FetchFormFieldsQuery;
use ACPT\Core\CQRS\Query\FetchFormPreviewElementQuery;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Form\FormSubmissionModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\ValueObjects\FormSubmissionDatumObject;
use ACPT\Utils\PHP\JSON;
use ACPT\Utils\PHP\Twig;
use ACPT\Utils\Wordpress\Email\EmailTemplateFactory;

class FormController extends AbstractController
{
    /**
     * Delete custom post type
     */
    public function deleteFormAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing id'
                ]);
            }

            $id = $data['id'];

            try {
                $command = new DeleteFormCommand($id);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no postType was sent'
        ]);
    }

    public function emailTemplatePreviewAction(): void
    {
        if (!empty($this->request->post('data'))) {

            // @TODO improve sanitizeJsonData
            if (JSON::isValid($this->request->post('data'))) {
                $data = json_decode($this->request->post('data'), true);
            } else {
                $data = $this->sanitizeJsonData($this->request->post('data'));
            }

            if (!isset($data['subject']) && !isset($data['body']) && !isset($data['template'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing params (`subject`, `body`, `template`)'
                ], 500);
            }

            $subject = $data['subject'];
            $body = $data['body'];
            $header = isset($data['header']) && is_string($data['header']) ? $data['header'] : null;
            $footer = isset($data['footer']) && is_string($data['footer']) ? $data['footer'] : null;
            $template = $data['template'];

            $emailTemplate = EmailTemplateFactory::create($template);

            if (!empty($header)) {
                // Convert newlines to <br> tags BEFORE Twig rendering to handle them properly
                $header = Strings::convertNewlinesToBr($header);
                $header = Twig::render($header, []);
            }

            if (!empty($footer)) {
                // Convert newlines to <br> tags BEFORE Twig rendering to handle them properly
                $footer = Strings::convertNewlinesToBr($footer);
                $footer = Twig::render($footer, []);
            }

            $html = $emailTemplate->render($subject, $body, $header, $footer);
            // Don't minify email templates - preserves formatting and prevents newline artifacts
            // $html = Strings::minifyHtml($html);

            wp_send_json([
                'html' => $html
            ]);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * Fetch form fields
     */
    public function fetchFormFieldsAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        try {
            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing params (`id`)'
                ]);
            }

            $id = $data['id'];
            $command = new FetchFormFieldsQuery($id);

            wp_send_json($command->execute());
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => $exception->getMessage(),
            ]);
        }
    }

    public function fetchFormPreviewElementAction(): void
    {
        if (!empty($this->request->post('data'))) {
            try {
                $data = $this->sanitizeJsonData($this->request->post('data'));

                if (!isset($data['field'])) {
                    wp_send_json([
                        'value' => null,
                    ]);
                }

                $field = $data['field'];
                $previewElement = $data['previewElement'] ?? null;
                $query = new FetchFormPreviewElementQuery($field, $previewElement);

                wp_send_json([
                    'value' => $query->execute()
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'value' => null,
                ]);
            }
        }

        wp_send_json([
            'value' => null,
        ]);
    }

    public function fetchFormSubmissionsAction(): void
    {
        try {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing form id'
                ], 500);
            }

            $formId = $data['id'];
            $page = isset($data['page']) ? (int)$data['page'] : 1;
            $perPage = isset($data['perPage']) ? (int)$data['perPage'] : 20;
            $dateFrom = isset($data['dateFrom']) ? $data['dateFrom'] : null;
            $dateTo = isset($data['dateTo']) ? $data['dateTo'] : null;
            $action = isset($data['action']) ? $data['action'] : null;

            wp_send_json([
                'count' => FormRepository::getSubmissionsCount($formId, $dateFrom, $dateTo, $action),
                'records' => FormRepository::getSubmissions($formId, $page, $perPage, $dateFrom, $dateTo, $action),
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => $exception->getMessage()
            ], 500);
        }
    }

    /**
     * Fetch paginated forms
     *
     * @throws \Exception
     */
    public function fetchFormsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $page = isset($data['page']) ? $data['page'] : null;
            $perPage = isset($data['perPage']) ? $data['perPage'] : null;
            $sort = isset($data['sort']) ? $data['sort'] : null;
            $order = isset($data['order']) ? $data['order'] : null;
            $search = isset($data['search']) ? $data['search'] : null;
        }

        // The Forms list is the page a user lands on right after
        // creating/editing/deleting a form — it must reflect the current
        // DB state immediately. FormRepository's own cache (and
        // ACPT_DB::getResults()'s underlying one) rely on
        // invalidateCacheTag() staying in sync after every save()/
        // delete(), which doesn't reliably hold up under sustained real
        // usage (reproduced directly: a deleted form kept appearing here
        // for hours, a freshly created one didn't, until the whole cache
        // was flushed) — skipCache bypasses both layers for this read.
        wp_send_json([
            'count' => FormRepository::count([
                'search' => isset($search) ? $search : null,
                'skipCache' => true,
            ]),
            'records' => FormRepository::get([
                'page' => isset($page) ? $page : 1,
                'perPage' => isset($perPage) ? $perPage : 20,
                'sort' => isset($sort) ? $sort : 'id',
                'order' => isset($order) ? $order : 'desc',
                'search' => isset($search) ? $search : null,
                'skipCache' => true,
            ]),
        ]);
    }

    /**
     * Returns table column definitions for a given table name,
     * used by FillTableAction to build the column selector.
     *
     * Expects POST data: { tableName: "my_table" }
     *
     * Returns: [{ id: columnName, groupName: tableName, name: columnLabel, type: uiFieldType }]
     */
    public function fetchTableColumnsForFormAction(): void
    {
        $data = !empty($this->request->post('data')) ? $this->sanitizeJsonData($this->request->post('data')) : [];
        $tableName = isset($data['tableName']) ? (string)$data['tableName'] : null;

        if (empty($tableName)) {
            wp_send_json([]);
        }

        $columns = [];

        try {
            $tables = TableRepository::get(['name' => $tableName]);

            if (!empty($tables)) {
                /** @var \ACPT\Core\Models\Table\TableModel $table */
                $table = $tables[0];

                foreach ($table->getColumns() as $column) {
                    if ($column->getType() === TableColumnModel::TABLE_FIELD_VIRTUAL) {
                        continue;
                    }

                    $columns[] = [
                        'id'        => $column->getName(),
                        'groupName' => $tableName,
                        'name'      => $column->getLabel() ?: $column->getName(),
                        'type'      => $column->getUiField()->type,
                    ];
                }
            }
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
        }

        wp_send_json($columns);
    }

    public function fetchHeadersAndFootersAction(): void
    {
        $directory = get_template_directory();

        $headers = array_merge(glob($directory."/header.php") ?: [], glob($directory."/header-*.php") ?: []);
        $footers = array_merge(glob($directory."/footer.php") ?: [], glob($directory."/footer-*.php") ?: []);

        foreach ($headers as $index => $header) {
            $headers[$index] = $this->cleanHeadersAndFootersName($header);
        }

        foreach ($footers as $index => $footer) {
            $footers[$index] = $this->cleanHeadersAndFootersName($footer);
        }

        wp_send_json([
                'headers' => $headers,
                'footers' => $footers,
        ]);
    }

    /**
     * Saves form
     */
    public function saveFormAction(): void
    {
        // allow HTML in the description field
        $data = $this->sanitizeJsonData($this->request->post('data'), ['description' => MetaFieldModel::MESSAGE_TYPE]);

        // covert data from UI
        $convertedMeta = [];
        $convertedFields = [];

        if (isset($data['meta'])) {
            $metadata = $data['meta'];

            foreach ($metadata as $metadatum) {
                foreach ($metadatum as $key => $value) {
                    if (is_array($value)) {
                        $value = serialize($value);
                    }

                    $convertedMeta[] = [
                        'key' => $key,
                        'value' => $value
                    ];
                }
            }
        }

        $data['meta'] = $convertedMeta;

        if (isset($data['fields'])) {
            foreach ($data['fields'] as $field) {
                $convertedFields[] = $this->convertFormFieldFromUI($field);
            }
        }

        $data['fields'] = $convertedFields;

        try {
            $httpStatus = 200;
            $command = new SaveFormCommand($data);
            $return = [
                'id' => $command->execute(),
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }

    /**
     * Saves form
     */
    public function saveFormFieldsAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));
        $convertedFields = [];

        if (
            !isset($data['id']) ||
            !isset($data['data'])
        ) {
            wp_send_json([
                'success' => false,
                'error' => 'No data sent'
            ], 500);
        }

        try {
            $id = $data['id'];
            $data = $data['data'];
            $httpStatus = 200;

            foreach ($data as $datum) {
                $convertedFields[] = $this->convertFormFieldFromUI($datum);
            }

            $command = new SaveFormFieldsCommand($id, $convertedFields);

            $return = [
                'id' => $command->execute(),
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }

    /**
     * Used to save AJAX or CUSTOM form submissions
     */
    public function saveFormSubmissionAction(): void
    {
        try {
            $currentUser = wp_get_current_user();
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $formModel = FormRepository::getById($data['acpt_form_id']);

            if ($formModel === null) {
                throw new \Exception("Not found form");
            }

            $callbackKey = ($formModel->getAction() === FormAction::AJAX) ? "ajax_action" : "custom_action"; //custom_method
            $callbackMetadatum = $formModel->getMetaDatum($callbackKey);

            // getMetaDatum() returns null if this key was never saved (e.g. the form's
            // `meta` was omitted on a later save) — mirrors the guard already used in
            // HandleFormSubmissionCommand::saveFormSubmissionCallback() for the same
            // key. Without it, calling getValue() on null used to fatal with an
            // uncaught Error that the surrounding catch (\Exception) can't catch.
            if ($callbackMetadatum === null) {
                throw new \Exception("Form is missing its {$callbackKey} configuration");
            }

            $formSubmission = FormSubmissionModel::hydrateFromArray([
                'formId' => $data['acpt_form_id'],
                'action' => $formModel->getAction(),
                'callback' => $callbackMetadatum->getValue(),
                'uid' => ($currentUser->ID > 0 ? $currentUser->ID : null),
                'createdAt' => new \DateTime(),
            ]);

            foreach ($formModel->getFields() as $field) {
                $datumObject = new FormSubmissionDatumObject($field->getName(), $field->getType(), $data[$field->getName()]);
                $formSubmission->addDatum($datumObject);
            }

            FormRepository::saveSubmission($formSubmission);

            $httpStatus = 200;
            $return = [
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }
}
