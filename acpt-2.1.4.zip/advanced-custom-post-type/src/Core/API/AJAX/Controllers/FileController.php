<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\CQRS\Command\AnalyzeImportFileCommand;
use ACPT\Core\CQRS\Command\ExportDataCommand;
use ACPT\Core\CQRS\Command\ImportSettingsCommand;
use ACPT\Core\Validators\ImportFileValidator;
use ACPT\Utils\Wordpress\Translator;

class FileController extends AbstractController
{
    /**
     * Handles the action of exporting data to a specified format.
     *
     * Validates the request payload to ensure both format and data keys are provided.
     * If any required field is missing, responds with an error message.
     * Executes the export data command using the provided format and data, and returns the result upon successful execution.
     *
     * @return void
     */
    public function exportFileAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['format'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing format'
            ]);
        }

        if (!isset($data['data'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing data to export'
            ]);
        }

        $format = $data['format'];
        $data = $data['data'];

        $command = new ExportDataCommand($format, $data);

        wp_send_json([
            'success' => true,
            'data' => $command->execute()
        ]);
    }

    /**
     * Handles the file analysis action triggered by a request.
     *
     * This method processes the uploaded file(s) and responds with the result of the file analysis.
     * If no files are provided in the request, an error response is sent with an appropriate message.
     * In the event of an exception during the file analysis process, the exception is logged,
     * and an error response is returned with the exception message (if available).
     *
     * @return void
     */
    public function analyzeFileAction(): void
    {
        if (empty($this->request->files())) {
            wp_send_json([
                'error' => Translator::translate('No files uploaded')
            ], 500);
        }

        try {
            $command = new AnalyzeImportFileCommand($this->request->file('file'));

            wp_send_json([
                'success' => true,
                'data' => $command->execute()
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => (!empty($exception->getMessage())) ? $exception->getMessage() : 'Error during import occurred',
                'data' => []
            ]);
        }
    }

    public function importSettingsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!ImportFileValidator::validate($data)) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Data provided is invalid'
                ]);
            }

            try {
                $command = new ImportSettingsCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ]);
    }
}
