<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Admin\ACPT_Block_Bindings;
use ACPT\Constants\MetaTypes;
use ACPT\Constants\Visibility;
use ACPT\Core\CQRS\Command\CopyMetaBlockCommand;
use ACPT\Core\CQRS\Command\CopyMetaBoxCommand;
use ACPT\Core\CQRS\Command\CopyMetaFieldCommand;
use ACPT\Core\CQRS\Command\DeleteMetaGroupCommand;
use ACPT\Core\CQRS\Command\SaveMetaGroupCommand;
use ACPT\Core\CQRS\Query\FetchAllFindBelongsQuery;
use ACPT\Core\CQRS\Query\FetchElementsQuery;
use ACPT\Core\CQRS\Query\FetchFindQuery;
use ACPT\Core\CQRS\Query\FetchMetaFieldsFromBelongsQuery;
use ACPT\Core\CQRS\Query\FetchMetaGroupsQuery;
use ACPT\Core\CQRS\Query\FetchMetaKeysQuery;
use ACPT\Core\CQRS\Query\FetchPreviewLinkQuery;
use ACPT\Core\CQRS\Query\GenerateGutenbergTemplateQuery;
use ACPT\Core\CQRS\Query\GenerateRelationalFieldOptionsQuery;
use ACPT\Core\Generators\Meta\FieldBlockGenerator;
use ACPT\Core\Generators\Meta\RepeaterFieldGenerator;
use ACPT\Core\Helper\Features;
use ACPT\Core\Helper\Id;
use ACPT\Core\Models\Meta\MetaFieldBlockModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Meta\MetaFieldModelFactory;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Integrations\Gutenberg\Generators\ACPTBlocks\Blocks\RepeaterLoopBlockRenderer;
use ACPT\Utils\Cache\FlexibleFieldCache;
use ACPT\Utils\Cache\RepeaterFieldCache;
use ACPT\Utils\Checker\ConditionalVisibilityLiveChecker;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\TableRecord;
use ACPT\Core\Helper\Strings;
use ACPT\Utils\ExportCode\ExportCodeStrings;
use ACPT\Utils\PHP\Maths;
use ACPT\Utils\PHP\PHPEval\PhpEval;
use ACPT\Utils\PHP\Url;
use ACPT\Utils\Wordpress\WPUtils;

class MetaController extends AbstractController
{
    public function checkIsVisibleAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        try {
            wp_send_json(
                ConditionalVisibilityLiveChecker::check(
                    Visibility::IS_BACKEND,
                    $data['elementId'],
                    $data['belongsTo'],
                    $data['values']
                )
            );
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([]);
        }
    }

    /**
     * @throws \Exception
     */
    public function checkMetaBoxFieldNameAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['fieldName'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing fieldName'
            ]);
        }

        $fieldName = $data['fieldName'];

        wp_send_json([
            'exists' => MetaRepository::existsMetaField([
                'fieldName' => $fieldName,
            ])
        ]);
    }

    /**
     * @throws \Exception
     */
    public function checkMetaBoxNameAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['boxName'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing boxName'
            ]);
        }

        $boxName = $data['boxName'];

        wp_send_json([
            'exists' => MetaRepository::existsMetaBox([
                'boxName' => $boxName
            ])
        ]);
    }

    public function copyMetaBlockAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                $command = new CopyMetaBlockCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyMetaBlocksAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $return = [
                'success' => false,
                'error' => 'Unknown error'
            ];

            if (!isset($data['blockIds'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing blockIds'
                ]);
            }

            try {
                foreach ($data['blockIds'] as $blockId) {
                    $command = new CopyMetaBlockCommand([
                        'blockId' => $blockId,
                        'targetFieldId' => $data['targetFieldId'],
                        'delete' => $data['delete'],
                    ]);
                    $command->execute();

                    $return = [
                        'success' => true,
                    ];
                }
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyMetaBoxAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                $command = new CopyMetaBoxCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyMetaBoxesAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['boxIds'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing boxIds'
                ]);
            }

            try {
                foreach ($data['boxIds'] as $boxId) {
                    $command = new CopyMetaBoxCommand([
                        'boxId' => $boxId,
                        'targetGroupId' => $data['targetGroupId'],
                        'delete' => $data['delete'],
                    ]);
                    $command->execute();
                }


                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyMetaFieldAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                $command = new CopyMetaFieldCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyMetaFieldsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $return = [
                'success' => false,
                'error' => 'Unknown error'
            ];

            if (!isset($data['fieldIds'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing fieldIds'
                ]);
            }

            try {
                foreach ($data['fieldIds'] as $fieldId) {
                    $command = new CopyMetaFieldCommand([
                        'fieldId' => $fieldId,
                        'targetEntityId' => $data['targetEntityId'],
                        'targetEntityType' => $data['targetEntityType'],
                        'delete' => $data['delete'],
                    ]);
                    $command->execute();

                    $return = [
                        'success' => true,
                    ];
                }
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    /**
     * Delete a meta group
     */
    public function deleteMetaAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing group `id`'
                ]);
            }

            $id = $data['id'];

            try {
                $command = new DeleteMetaGroupCommand($id);
                $command->execute();

                $return = [
                        'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                        'success' => false,
                        'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
                'success' => false,
                'error' => 'no postType was sent'
        ]);
    }

    /**
     * Delete a single meta field
     */
    public function deleteMetaFieldValueAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        $box = $data['acpt_box'] ?? null;
        $field = $data['acpt_field'] ?? null;
        $context = $this->resolveFieldContext($data);
        $context['box_name'] = $box;
        $context['field_name'] = $field;

        $save = delete_acpt_meta_field_value($context);

        $response = [
            'success' => $save,
        ];

        if (!$save) {
            $response['error'] = 'Could not delete meta field value';
        }

        wp_send_json($response);
    }

    /**
     * Execute a shortcode
     */
    public function doShortcodeAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['shortcode'])) {
            wp_send_json([
                    'success' => false,
                    'error' => 'Missing taxonomy'
            ]);
        }

        $shortcode = $data['shortcode'];

        wp_send_json([
                'success' => true,
                'data' => WPUtils::renderShortCode($shortcode)
        ]);
    }

    /**
     * @throws \Exception
     */
    public function evaluateCodeAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['code'])) {
            wp_send_json([
                    'success' => false,
                    'error' => 'Missing code'
            ]);
        }

        $code = $data['code'];

        wp_send_json([
            'errors' => PhpEval::getInstance()->getErrors($code)
        ]);
    }

    /**
     * @throws \Exception
     */
    public function exportCodeAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['find']) && !isset($data['belongsTo'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing params (`find`, `belongsTo`)'
                ], 500);
            }

            wp_send_json(ExportCodeStrings::export($data['belongsTo'], $data['find']));
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * @throws \Exception
     */
    public function fetchAllFindBelongsAction(): void
    {
        $query = new FetchAllFindBelongsQuery();

        wp_send_json($query->execute());
    }

    /**
     * Batched value resolver for the block bindings editor preview (index.jsx's
     * getValues()). The editor canvas can't call PHP synchronously the way the
     * real render_block bindings resolution does (ACPT_Block_Bindings::getValueCallback()),
     * so this fetches real values up front instead, keyed by "box:field" rather
     * than by attribute name -- a field's value doesn't depend on which
     * attribute it happens to be bound to. Both this and getValueCallback()
     * share the same belongsTo -> get_acpt_field() routing via
     * resolveGetAcptFieldArgs(), so a field unresolvable here (e.g. a taxonomy
     * field with no termId known client-side) is unresolvable there too, by
     * construction.
     *
     * @throws \Exception
     */
    public function fetchBlockBindingValuesAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['bindings']) || !is_array($data['bindings'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing bindings'
            ], 500);
        }

        $postId = isset($data['postId']) ? (int) $data['postId'] : null;
        $termId = isset($data['termId']) ? (int) $data['termId'] : null;
        $values = [];

        foreach ($data['bindings'] as $binding) {
            if (!isset($binding['box']) || !isset($binding['field'])) {
                continue;
            }

            $key = $binding['box'] . ':' . $binding['field'];
            $fieldModel = MetaRepository::getMetaFieldByName([
                'boxName' => $binding['box'],
                'fieldName' => $binding['field'],
            ]);

            if ($fieldModel === null || !ACPT_Block_Bindings::isFieldBindingAllowed($fieldModel)) {
                $values[$key] = null;
                continue;
            }

            $args = ACPT_Block_Bindings::resolveGetAcptFieldArgs($binding, $postId, $termId);

            $values[$key] = ($args !== null) ? get_acpt_field($args) : null;
        }

        wp_send_json([
            'success' => true,
            'data' => $values,
        ]);
    }

    /**
     * Fetch OP meta fields
     * Used by FSE
     */
    public function fetchAllMetaAction(): void
    {
        try {
            $groups = [];
            $allMetaGroups = MetaRepository::get([
                'clonedFields' => true,
            ]);

            foreach ($allMetaGroups as $group) {
                foreach ($group->getBelongs() as $belong) {
                    $belongsTo = $belong->getBelongsTo();
                    $find = $belong->getFind() ?? $belongsTo;
                    $findLabel = $belong->getFindAsSting() ?? $find;

                    if (!isset($groups[$belongsTo])) {
                        $groups[$belongsTo] = [];
                    }

                    if (!isset($groups[$belongsTo][$find])) {
                        $groups[$belongsTo][$find] = [
                            'label' => $findLabel,
                            'records' => [],
                        ];
                    }

                    // avoid duplicating the same group under the same key
                    $alreadyAdded = false;
                    foreach ($groups[$belongsTo][$find]['records'] as $existing) {
                        if ($existing->getId() === $group->getId()) {
                            $alreadyAdded = true;
                            break;
                        }
                    }

                    if (!$alreadyAdded) {
                        $groups[$belongsTo][$find]['records'][] = $group;
                    }
                }
            }

            wp_send_json($groups);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => $exception->getMessage()
            ], 500);
        }
    }

    /**
     * fetch CPTs or Taxonomies
     * (used by copy meta box/field UI)
     *
     * @throws \Exception
     */
    public function fetchElementsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['belongsTo'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing belongsTo'
                ], 500);
            }

            $belongsTo = $data['belongsTo'];
            $exclude = (isset($data['exclude'])) ? $data['exclude'] : null;

            $query = new FetchElementsQuery($belongsTo, $exclude);

            wp_send_json($query->execute());
        }

        wp_send_json([
            'success' => false,
            'error' => 'no params were sent'
        ], 500);
    }

    /**
     * @throws \Exception
     */
    public function fetchFindAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['belongsTo']) && !isset($data['id'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing params (`id, belongsTo`)'
            ]);
        }

        $id = $data['id'];
        $belongsTo = $data['belongsTo'];

        $command = new FetchFindQuery((int)$id, $belongsTo);

        wp_send_json($command->execute());
    }

    /**
     * @throws \Exception
     */
    public function fetchFindFromBelongsToAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['belongsTo'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing params (`belongsTo`)'
            ]);
        }

        $belongsTo = $data['belongsTo'];
        $command = new FetchMetaFieldsFromBelongsQuery($belongsTo);

        wp_send_json($command->execute());
    }

    /**
     * Fetch custom post type meta
     *
     * @throws \Exception
     */
    public function fetchMetaAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (empty($data)) {
            $data = [];
        }

        // Single field fetch
        if (isset($data['id'])) {
            $query = new FetchMetaGroupsQuery([
                'id' => $data['id'],
                'formBuilder' => $data['formBuilder'] ?? false,
                'cct' => $data['cct'] ?? true,
                'excludeField' => ((isset($data['excludeField'])) ? $data['excludeField'] : null),
            ]);

            $record = $query->execute();

            if (!empty($record)) {
                wp_send_json($record[0]);
            }

            wp_send_json([]);
        }

        // user fields
        if (isset($data['belongsTo']) && $data['belongsTo'] === MetaTypes::USER) {
            unset($data['find']);
        }

        // media fields
        if (isset($data['find']) && $data['find'] === 'attachment') {
            $data['belongsTo'] = MetaTypes::MEDIA;
            unset($data['find']);
        }

        // include cct
        if (!isset($data['cct'])) {
            $data['cct'] = true;
        }

        // count
        $count = MetaRepository::count([
            'search'    => $data['search'] ?? null,
            'groupName' => $data['groupName'] ?? null,
        ]);

        if ($data['cct'] === true) {
            $count += TableRepository::count([
                'search'       => $data['search'] ?? null,
                'requireGroup' => true,
            ]);
        }

        // fetch groups
        $query = new FetchMetaGroupsQuery($data);

        wp_send_json([
            'count' => $count,
            'records' => $query->execute(),
        ]);
    }

    /**
     * Fetch meta field by id
     *
     * @throws \Exception
     */
    public function fetchMetaFieldAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['id'])) {
            wp_send_json([
                    'success' => false,
                    'error' => 'Missing id'
            ]);
        }

        $id = $data['id'];
        $lazy = isset($data ['lazy']) ? $data ['lazy'] : false;

        wp_send_json(MetaRepository::getMetaFieldById($id, $lazy));
    }

    public function fetchMetaFieldsFlatMapAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['excludeField'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing `excludeField`'
            ]);
        }

        wp_send_json(MetaRepository::metaFieldsFlatArray($data['excludeField']));
    }

    /**
     * @throws \Exception
     */
    public function fetchMetaFieldsFromBelongsToAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['belongsTo']) && !isset($data['find'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing params (`belongsTo`)'
            ]);
        }

        $belongsTo = $data['belongsTo'];
        $query = new FetchMetaFieldsFromBelongsQuery($belongsTo);

        wp_send_json($query->execute());
    }

    /**
     * Fetch data for meta keys manager
     */
    public function fetchMetaKeysAction(): void
    {
        $args = [];
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            $page = isset($data['page']) ? $data['page'] : 1;
            $perPage = isset($data['perPage']) ? $data['perPage'] : 20;
            $search = isset($data['search']) ? $data['search'] : null;
            $context = isset($data['context']) ? $data['context'] : null;
            $orderBy = isset($data['order']) ? $data['order'] : null;
            $sortBy = isset($data['sort']) ? $data['sort'] : null;

            $args['page'] = $page;
            $args['perPage'] = $perPage;

            if (!empty($search)) {
                $args['search'] = $search;
            }

            if (!empty($context)) {
                $args['context'] = $context;
            }

            if (!empty($orderBy)) {
                $args['order'] = $orderBy;
            }

            if (!empty($sortBy)) {
                $args['sort'] = $sortBy;
            }
        }

        $query = new FetchMetaKeysQuery($args);

        wp_send_json($query->execute());
    }

    /**
     * Fetch meta value
     */
    public function fetchMetaValueAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['fieldName'])) {
                wp_send_json([
                    'success' => false,
                    'error' => "Missing `fieldName` field"
                ]);
            }

            if (!isset($data['objectType'])) {
                wp_send_json([
                    'success' => false,
                    'error' => "Missing `objectType` field"
                ]);
            }

            if (!isset($data['objectId'])) {
                wp_send_json([
                    'success' => false,
                    'error' => "Missing `objectId` field"
                ]);
            }

            $fieldName = $data['fieldName'];
            $objectId = $data['objectId'];
            $objectType = $data['objectType'];

            wp_send_json([
                'value' => Meta::fetch($objectId, $objectType, $fieldName)
            ]);
        }
    }

    /**
     * Fetch a single CCT column value for the quick-edit JS population.
     * Expects JSON body: { tableName, columnName, postId }
     */
    public function fetchCCTColumnValueAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['tableName'], $data['columnName'], $data['postId'])) {
                wp_send_json(['success' => false, 'error' => 'Missing required fields']);
            }

            $tableName  = sanitize_key((string) $data['tableName']);
            $columnName = sanitize_key((string) $data['columnName']);
            $postId     = (int) $data['postId'];

            $table = TableRepository::getByName($tableName);

            if ($table === null) {
                wp_send_json(['value' => null]);
            }

            wp_send_json([
                'value' => TableRecord::fetch($table, ['postId' => $postId], $columnName),
            ]);
        }
    }

    /**
     * Fetch preview link
     */
    public function fetchPreviewLinkAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        try {
            $query = new FetchPreviewLinkQuery($data);

            wp_send_json([
                'success' => true,
                'link' => $query->execute(),
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => $exception->getMessage(),
            ]);
        }
    }

    public function generateEmbedAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['value'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing `value` params'
                ], 500);
            }

            $value = $data['value'];

            if (!Url::isValid($value)) {
                wp_send_json([
                    'success' => false,
                    'error' => '`value` is not a valid URL'
                ], 500);
            }

            $embed = (new \WP_Embed())->shortcode([
                'width' => 180,
                'height' => 135,
            ], Url::sanitize($value));

            wp_send_json([
                'success' => true,
                'embed' => $embed
            ]);
        }
    }

    public function generateFlexibleBlockAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['blockId']) &&
               !isset($data['parentName']) &&
               !isset($data['mediaType']) &&
               !isset($data['index']) &&
               !isset($data['blockListId'])
            ) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing `blockListId` or `blockId` or `parentName` or `index` or `mediaType` params'
                ], 500);
            }

            $fieldId = $data['fieldId'] ?? null;
            $blockListId = $data['blockListId'];
            $blockId = $data['blockId'];
            $blockName = $data['blockName'] ?? null;
            $mediaType = $data['mediaType'];
            $parentName = $data['parentName'];
            $index = $data['index'];
            $layout = $data['layout'];
            $minBlocks = isset($data['minBlocks']) ? (int)$data['minBlocks'] : null;
            $maxBlocks = isset($data['maxBlocks']) ? (int)$data['maxBlocks'] : null;
            $addLabel = isset($data['addLabel']) ? $data['addLabel'] : null;
            $deleteLabel = isset($data['deleteLabel']) ? $data['deleteLabel'] : null;
            $leadingField = isset($data['leadingField']) ? $data['leadingField'] : null;

            try {
                $metaBlock = $this->fetchBlock($blockId, $mediaType, $fieldId, $blockName);

                if (null === $metaBlock) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'No meta block found'
                    ], 500);
                }

                $repeaterFieldGenerator = new FieldBlockGenerator(
                    $metaBlock,
                    $parentName,
                    $mediaType,
                    $layout,
                    $leadingField,
                    $minBlocks,
                    $maxBlocks,
                    $addLabel,
                    $deleteLabel
                );

                wp_send_json([
                    'block' => $repeaterFieldGenerator->generate($blockListId, $index)
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * @throws \Exception
     */
    public function generateFlexibleGroupedFieldsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['blockId']) && !isset($data['mediaType']) && !isset($data['elementIndex']) && !isset($data['blockIndex'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing `fieldId` or `blockId` or `index` or `mediaType` params'
                ], 500);
            }

            $fieldId = $data['fieldId'] ?? null;
            $blockName = $data['blockName'] ?? null;
            $blockId = $data['blockId'];
            $mediaType = $data['mediaType'];
            $parentName = $data['parentName'];
            $elementIndex = $data['elementIndex'];
            $blockIndex = isset($data['blockIndex']) ? (int)$data['blockIndex'] : null;
            $realBlockId = 'block-elements-'.$blockId.'-'.$blockIndex;
            $layout = $data['layout'];
            $minBlocks = isset($data['minBlocks']) ? (int)$data['minBlocks'] : null;
            $maxBlocks = isset($data['maxBlocks']) ? (int)$data['maxBlocks'] : null;
            $addLabel = isset($data['addLabel']) ? $data['addLabel'] : null;
            $deleteLabel = isset($data['deleteLabel']) ? $data['deleteLabel'] : null;
            $leadingField = isset($data['leadingField']) ? $data['leadingField'] : null;

            $cache = new FlexibleFieldCache();

            // Check for a cached version
            $cachedTemplate = $cache->get(
                $blockId,
                $mediaType,
                $parentName,
                $elementIndex,
                $blockIndex,
                $realBlockId
            );

            if ($cachedTemplate !== null) {
                wp_send_json([
                    'fields' => $cachedTemplate
                ]);
            }

            try {
                $metaBlock = $this->fetchBlock($blockId, $mediaType, $fieldId, $blockName);

                if (null === $metaBlock) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'No meta block found'
                    ], 500);
                }

                $repeaterFieldGenerator = new FieldBlockGenerator(
                    $metaBlock,
                    $parentName,
                    $mediaType,
                    $layout,
                    $leadingField,
                    $minBlocks,
                    $maxBlocks,
                    $addLabel,
                    $deleteLabel
                );

                $fields = $repeaterFieldGenerator->generateElement($elementIndex, $realBlockId, $blockIndex);
                $cache->save(
                    $fields,
                    $blockId,
                    $mediaType,
                    $parentName,
                    $elementIndex,
                    $blockIndex,
                    $realBlockId
                );

                wp_send_json([
                    'fields' => $repeaterFieldGenerator->generateElement($elementIndex, $realBlockId, $blockIndex)
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * @param string $blockId
     * @param string $mediaType
     * @param string|null $fieldId
     * @param string|null $blockName
     * @return MetaFieldBlockModel|null
     * @throws \Exception
     */
    private function fetchBlock(string $blockId, string $mediaType, ?string $fieldId, ?string $blockName): ?MetaFieldBlockModel
    {
        $metaBlock = MetaRepository::getMetaBlockById($blockId);

        if ($metaBlock !== null) {
            return $metaBlock;
        }

        // fallback on CCT
        if (
            Features::hasCct() &&
            $mediaType === MetaTypes::TABLE &&
            !empty($fieldId) &&
            !empty($blockName)
        ) {
            $column = TableRepository::getColumnById($fieldId);

            return MetaFieldModelFactory::createBlockFromTableColumn($column, $blockName);
        }

        return null;
    }

    /**
     * @throws \Exception
     */
    public function generateGroupedFieldsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id']) && !isset($data['mediaType'])) {
                wp_send_json([
                        'success' => false,
                        'error' => 'Missing `id` or `mediaType` params'
                ]);
            }

            $id = $data['id'];
            $mediaType = $data['mediaType'];
            $parentIndex = $data['parentIndex'];
            $parentName = $data['parentName'];
            $index = $data['index'];
            $formId = $data['formId'] ?? null;

            $cache = new RepeaterFieldCache();

            // Check for a cached version
            $cachedFields = $cache->get(
                $id,
                $mediaType,
                $parentIndex,
                $parentName,
                $index,
                $formId
            );

            $cachedTemplate = $cache->getById(
                $id,
                $mediaType,
                $formId
            );

            if ($cachedTemplate !== null) {
                wp_send_json([
                    'fields' => $cachedFields,
                    'template' => $cachedTemplate,
                ]);
            }

            try {
                $metaField = MetaFieldModelFactory::resolveFromId($id);

                if (null === $metaField) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'No meta field found'
                    ], 500);
                }

                $layout = $data['layout'] ?? $metaField->getAdvancedOption('layout') ?? 'row';
                $leadingFieldId = $metaField->getAdvancedOption('leading_field');

                $repeaterFieldGenerator = new RepeaterFieldGenerator(
                    $metaField,
                    $parentName,
                    $parentIndex,
                    $mediaType,
                    $layout,
                    $leadingFieldId,
                    null,
                    $formId
                );

                $fields = $repeaterFieldGenerator->generate($index);
                $cache->save(
                    $fields,
                    $id,
                    $mediaType,
                    $parentIndex,
                    $parentName,
                    $index,
                    $formId
                );

                $cachedTemplate = $cache->getById(
                    $id,
                    $mediaType,
                    $formId
                );

                wp_send_json([
                    'fields' => $fields,
                    'template' => $cachedTemplate,
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                        'success' => false,
                        'error' => $exception->getMessage()
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * Generate a template for Gutenberg inner blocks
     */
    public function generateGutenbergTemplateAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['field'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing `field`'
                ], 500);
            }

            $attributes = $data['attributes'] ?? [];

            try {
                $query = new GenerateGutenbergTemplateQuery($data['field'], $attributes);
                $template = $query->execute();

                wp_send_json($template);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    public function generateIdAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['strategy'])) {
                wp_send_json([
                        'success' => false,
                        'error' => 'Missing `strategy` params'
                ], 500);
            }

            $strategy = $data['strategy'];
            $index    = $data['index'] ?? null;

            try {
                wp_send_json([
                    'id' => Id::generate($strategy, $index)
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'error' => $exception->getMessage()
                ], 500);
            }
        }
    }

    /**
     * User by relational fields
     */
    public function generateRelationalFieldOptionsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $args = [];

            $id = $data['id'] ?? null;
            $fieldType = $data['fieldType'] ?? null;
            $defaultValues = $data['defaultValues'] ?? [];
            $layout = $data['layout'] ?? null;
            $format = $data['format'] ?? 'html';
            $restrictLoggedUserPosts = $data['restrictLoggedUserPosts'] ?? false;

            if (isset($data['toType'])) {
                $args['toType'] = $data['toType'];
            }

            if (isset($data['toValue'])) {
                $args['toValue'] = $data['toValue'];
            }

            if (isset($data['postType'])) {
                $args['post_type'] = $data['postType'];
            }

            if (isset($data['postStatus'])) {
                $args['post_status'] = $data['postStatus'];
            }

            if (isset($data['postTaxonomy'])) {
                $args['post_taxonomy'] = $data['postTaxonomy'];
            }

            if (isset($data['termTaxonomy'])) {
                $args['term_taxonomy'] = $data['termTaxonomy'];
            }

            if (isset($data['userRole'])) {
                $args['user_role'] = $data['userRole'];
            }

            if (!empty($data['labelColumn'])) {
                $args['labelColumn'] = $data['labelColumn'];
            }

            if ($restrictLoggedUserPosts) {
                $args['restrict_logged_user_posts'] = true;
            }

            if (empty($fieldType)) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing `fieldType` param'
                ], 500);
            }

            $query = new GenerateRelationalFieldOptionsQuery($fieldType, $args, $format, $defaultValues, $layout, $id);

            wp_send_json([
                'fields' => $query->execute(),
            ]);
        }

        wp_send_json([
                'success' => false,
                'error' => 'no data was sent'
        ], 500);
    }

    public function getRepeaterDataAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['field'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing field'
                ], 500);
            }

            if (!isset($data['postId'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing postId'
                ], 500);
            }

            try {
                $field = $data['field'];
                $postId = $data['postId'];
                $values = $data['values'];

                $render = [];
                $pos = new RepeaterLoopBlockRenderer();
                $render[] = $pos->render([
                    'field' => json_encode($field),
                    'postId' => $postId,
                ], $values);

                wp_send_json(json_encode($render));
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ], 500);
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ], 500);
    }

    /**
     * Evaluate math expression
     */
    public function mathEvalAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['data'])) {
            wp_send_json([
                'success' => false,
                'error' => 'Missing params (`data`)'
            ]);
        }

        $math = Maths::getInstance($data['data']);

        // evaluate single value
        if (isset($data['value'])) {
            wp_send_json([
                'value' => $math->eval($data['value'])
            ]);
        }

        // evaluate table values
        if (isset($data['values'])) {
            $values = [];

            foreach ($data['values'] as $value) {
                $values[] = [
                    'id' => $value['id'],
                    'value' => $math->eval($value['value']),
                ];
            }

            wp_send_json([
                'values' => $values
            ]);
        }

        wp_send_json([
            'success' => false,
            'error' => 'Missing params (`value` | `values`)'
        ]);
    }

    /**
     * Saves meta
     */
    public function saveMetaAction(): void
    {
        // allow HTML in the description field
        $data = $this->sanitizeJsonData($this->request->post('data'), ['description' => MetaFieldModel::MESSAGE_TYPE]);

        if (
            !isset($data['id']) ||
            !isset($data['name'])
        ) {
            wp_send_json([
                'success' => false,
                'error' => 'No data sent'
            ], 500);
        }

        try {
            $httpStatus = 200;
            $command = new SaveMetaGroupCommand($data);
            $return = [
                'id' => $command->execute(),
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }

    /**
     * Save a single meta field
     */
    public function saveMetaFieldValueAction(): void
    {
        // allow HTML in the description field
        $data = $this->sanitizeJsonData($this->request->post('data'), ['description' => MetaFieldModel::MESSAGE_TYPE]);

        $box = $data['acpt_box'] ?? null;
        $field = $data['acpt_field'] ?? null;
        $value = $data['value'] ?? null;
        ;
        $context = $this->resolveFieldContext($data);
        $context['box_name'] = $box;
        $context['field_name'] = $field;
        $context['value'] = $value;

        $save = save_acpt_meta_field_value($context);

        $response = [
            'success' => $save,
        ];

        if (!$save) {
            $response['error'] = 'Could not save meta field value';
        }

        wp_send_json($response);
    }

    /**
     * Resolves a context array to a specific mapped structure based on predefined rules.
     *
     * @param array<string, mixed> $context The input context array which must contain 'id' and 'associated_to_raw_value' keys.
     * @return array<string, mixed>|null An associative array mapping the resolved context key to its value, or null if input is invalid or unmapped.
     */
    private function resolveFieldContext(array $context = []): ?array
    {
        if (!isset($context['id'])) {
            return null;
        }

        if (!isset($context['associated_to_raw_value'])) {
            return null;
        }

        $parts = explode('::', $context['id'], 4);

        if (count($parts) === 4) {
            [$rawValue, $ctx] = $parts;
            switch ($ctx) {
                case 'cpt':
                case 'media':
                    return ['post_id' => (int)$rawValue];

                case 'tax':
                    return ['term_id' => (int)$rawValue];

                case 'op':
                    return ['option_page' => $rawValue];

                case 'user':
                    return ['user_id' => (int)$rawValue];

                case 'comment':
                    return ['comment_id' => (int)$rawValue];
            }
        }

        return null;
    }

    public function saveBlockBindingValuesAction(): void
    {
        // allow HTML in the description field, and in the field's own value --
        // this may be an EDITOR-type field's rich text; the type-aware sanitizer
        // inside SaveMetaFieldValueCommand (via save_acpt_meta_field_value()
        // below) is the authoritative one, this is just Layer 1 not destroying
        // HTML before Layer 2 ever gets a chance to apply the correct policy.
        $data = $this->sanitizeJsonData($this->request->post('data'), [
            'description' => MetaFieldModel::MESSAGE_TYPE,
            'value' => MetaFieldModel::EDITOR_TYPE,
        ]);
        $args = $data['args'] ?? [];
        $value = $data['value'] ?? null;

        if (empty($args['box']) || empty($args['field']) || empty($value)) {
            wp_send_json([
                'success' => false,
                'error' => 'Invalid box, field, or value',
            ], 400);
        }

        // Same eligibility gate the read path (ACPT_Block_Bindings::getValueCallback()/
        // fetchBlockBindingValuesAction) already enforces -- a field disallowed via
        // "Allow in block bindings", or whose type was never bindable in the first
        // place (MetaFieldModel::BINDABLE_FIELD_TYPES), can't be read back through
        // block bindings; it shouldn't be writable through them either. Without this,
        // a request crafted directly against this action (bypassing canUserEditValue(),
        // a client-side-only UI gate) could still overwrite such a field's value.
        $fieldModel = MetaRepository::getMetaFieldByName([
            'boxName' => $args['box'],
            'fieldName' => $args['field'],
        ]);

        if ($fieldModel === null || !ACPT_Block_Bindings::isFieldBindingAllowed($fieldModel)) {
            wp_send_json([
                'success' => false,
                'error' => 'This field is not editable via block bindings',
            ], 403);
        }

        $postId = isset($data['postId']) ? (int)$data['postId'] : null;

        // Routes on belongsTo (customPostType/optionPage/taxonomy) exactly like
        // the read path (ACPT_Block_Bindings::getValueCallback()) does, instead
        // of always writing post_id regardless of the field's real location --
        // an optionPage-bound field used to silently fail to save (post_id was
        // never what it needed). No termId is resolved client-side yet --
        // Gutenberg/index.jsx's computeBindableFields()/canUserEditValue()
        // already exclude taxonomy fields from being offered as editable
        // bindings for that reason -- so passing null here means a taxonomy
        // field reaching this endpoint anyway (e.g. hand-edited block markup)
        // fails closed instead of silently writing to whatever post happens to
        // be open in the editor.
        $context = ACPT_Block_Bindings::resolveGetAcptFieldArgs($args, $postId, null);

        if ($context === null) {
            wp_send_json([
                'success' => false,
                'error' => 'Invalid or unsupported field location',
            ], 400);
        }

        $context['value'] = $value;

        $save = save_acpt_meta_field_value($context);

        $response = [
            'success' => $save,
        ];

        if (!$save) {
            $response['error'] = 'Could not save meta field value';
        }

        wp_send_json($response);
    }
}
