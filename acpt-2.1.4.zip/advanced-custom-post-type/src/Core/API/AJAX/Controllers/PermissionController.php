<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\CQRS\Command\SavePermissionCommand;
use ACPT\Core\CQRS\Command\SaveSettingsCommand;
use ACPT\Core\Repository\PermissionRepository;
use ACPT\Core\Repository\SettingsRepository;

class PermissionController extends AbstractController
{
    public function fetchPermissionAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing id'
                ], 500);
            }

            $id = $data['id'];

            wp_send_json(PermissionRepository::getByEntityId($id));
        }
    }

    /**
     * @throws \Exception
     */
    public function fetchSettingsAction(): void
    {
        wp_send_json(SettingsRepository::get());
    }

    public function savePermissionAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (empty($data)) {
            wp_send_json([
                'success' => false,
                'error' => 'No data sent'
            ], 500);
        }

        try {
            $httpStatus = 200;
            $command = new SavePermissionCommand($data);
            $command->execute();

            $return = [
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }

    /**
     * Save settings
     */
    public function saveSettingsAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        // persist $model on DB
        try {
            $command = new SaveSettingsCommand($data);
            $command->execute();
            $httpStatus = 200;

            $return = [
                    'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }
}
