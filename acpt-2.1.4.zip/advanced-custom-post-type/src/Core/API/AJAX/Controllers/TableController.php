<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\API\Exceptions\NotFoundException;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\CQRS\Command\CopyTableColumnCommand;
use ACPT\Core\CQRS\Command\DeleteTableCommand;
use ACPT\Core\CQRS\Command\DeleteTableTemplateCommand;
use ACPT\Core\CQRS\Command\ExecuteTableSchemaAction;
use ACPT\Core\CQRS\Command\SaveTableCommand;
use ACPT\Core\CQRS\Command\SaveTableTemplateCommand;
use ACPT\Core\CQRS\Query\FetchTableStatsQuery;
use ACPT\Core\CQRS\Query\FetchTableTemplatesQuery;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Repository\TableRepository;

class TableController extends AbstractController
{
    /**
     * Check if a table exists
     */
    public function checkTableNameAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['name'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing name'
                ]);
            }

            $name = $data['name'];

            wp_send_json([
                'exists' => TableRepository::exists($name)
            ]);
        }
    }

    /**
     * Delete a table
     */
    public function deleteTableAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing table id'
                ]);
            }

            $id = $data['id'];

            try {
                $command = new DeleteTableCommand($id);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no table id was sent'
        ]);
    }

    /**
     * Copy a single concrete column into another (or the same) table.
     * Metadata only — the target still needs a "Sync table" run afterwards.
     */
    public function copyTableColumnAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                $command = new CopyTableColumnCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                    'needsSync' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ]);
    }

    /**
     * Delete a single custom table record.
     * Params: tableName, id.
     */
    public function deleteTableRecordAction(): void
    {
        $data = [];
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
        }

        $tableName = $data['tableName'] ?? null;
        $id        = $data['id']        ?? null;

        if (empty($tableName) || empty($id)) {
            wp_send_json(['success' => false, 'error' => 'Missing tableName or id']);
        }

        try {
            $controller = new TableRecordController();
            $result = $controller->delete($tableName, $id);
            wp_send_json(['success' => true] + $result);
        } catch (NotFoundException $e) {
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function deleteTableTemplateAction(): void
    {
        if (!empty($this->request->post('data'))) {
            try {
                $data = $this->sanitizeJsonData($this->request->post('data'));
                $id = $data['id'];
                $command = new DeleteTableTemplateCommand($id);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ]);
    }

    /**
     * Fetch paginated records for a custom table.
     * Params: tableName, page, perPage, (optional) id for single-record fetch.
     */
    public function fetchTableRecordsAction(): void
    {
        $data = [];
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
        }

        $tableName = $data['tableName'] ?? null;
        $id        = $data['id']        ?? null;

        if (empty($tableName)) {
            wp_send_json(['success' => false, 'error' => 'Missing tableName']);
        }

        try {
            $controller = new TableRecordController();

            if (!empty($id)) {
                $record = $controller->get($tableName, $id);
                wp_send_json(['record' => $record]);
            }

            $result = $controller->list($tableName, [
                'page'     => $data['page']    ?? 1,
                'per_page' => $data['perPage'] ?? 20,
                'only_ids' => $data['onlyIds'] ?? false,
                'where'    => $data['where']   ?? [],
                'order_by' => $data['orderBy'] ?? [],
            ]);

            wp_send_json($result);
        } catch (NotFoundException $e) {
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Fetch tables
     *
     * @throws \Exception
     *
     * @return void
     */
    public function fetchTablesAction(): void
    {
        $id = null;
        $name = null;
        $page = 1;
        $perPage = 20;
        $groupId = null;
        $search = null;

        if (!empty($this->request->post('data'))) {
            $data    = $this->sanitizeJsonData($this->request->post('data'));
            $id      = $data['id']      ?? null;
            $name    = $data['name']    ?? null;
            $page    = $data['page']    ?? 1;
            $perPage = $data['perPage'] ?? 20;
            $groupId = $data['groupId'] ?? null;
            $search  = isset($data['search']) ? $data['search'] : null;
        }

        if (!empty($id)) {
            wp_send_json(TableRepository::getById($id));
        }

        if (!empty($name)) {
            wp_send_json(TableRepository::getByName($name));
        }

        $queryArgs = [
            'page'    => $page,
            'perPage' => $perPage,
        ];

        if (!empty($groupId)) {
            $queryArgs['tableGroupId'] = $groupId;
        }

        if ($search !== null) {
            $queryArgs['search'] = $search;
        }

        $countArgs = [];
        if (!empty($groupId)) {
            $countArgs['tableGroupId'] = $groupId;
        }
        if ($search !== null) {
            $countArgs['search'] = $search;
        }

        wp_send_json([
            'count'   => TableRepository::count($countArgs),
            'records' => TableRepository::get($queryArgs),
        ]);
    }

    /**
     * Fetch tables
     *
     * @throws \Exception
     */
    public function fetchTableStatsAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (!isset($data['table'])) {
            wp_send_json(['success' => false, 'error' => 'Missing table name']);
        }

        $command = new FetchTableStatsQuery($data['table']);

        wp_send_json(
            $command->execute()
        );
    }

    public function fetchTableTemplatesAction(): void
    {
        $query = new FetchTableTemplatesQuery();

        wp_send_json($query->execute());
    }

    public function saveTableAction(): void
    {
        // allow HTML in the description field
        $data = $this->sanitizeJsonData($this->request->post('data'), ['description' => MetaFieldModel::MESSAGE_TYPE]);

        // persist $model on DB
        try {
            $d = [
                'id' => $data[1]['id'] ?? Uuid::v4(),
                'label' => $data[1]['label'] ?? null,
                'name' => $data[1]['name'],
                'capability' => $data[1]['capability'],
                'charsetCollate' => $data[1]['charsetCollate'],
                'idStrategy' => $data[1]['idStrategy'],
                'restAPI' => $data[1]['restAPI'] ?? [],
                'location' => $data[1]['location'] ?? [],
                'options' => $data[1]['options'] ?? [],
                'timestamps' => $data[1]['timestamps'] ?? false,
                'softDelete' => $data[1]['soft_delete'] ?? false,
                'menuPosition' => $data[1]['position'] ?? 99,
                'icon' => (is_array($data[1]['icon']) ? [
                    'src' => $data[1]['icon']['src'],
                    'background' => $data[1]['icon']['background'],
                    'foreground' => $data[1]['icon']['foreground'],
                ] : $data[1]['icon']) ,
                'columns' => isset($data[2]['columns']) && is_array($data[2]['columns']) ? $data[2]['columns'] : [],
                'indexes' => isset($data[3]['indexes']) && is_array($data[3]['indexes']) ? $data[3]['indexes'] : [],
                'foreignKeys' => isset($data[4]['foreignKeys']) &&  is_array($data[4]['foreignKeys']) ? $data[4]['foreignKeys'] : [],
                'tableGroupId' => $data[1]['tableGroupId'] ?? null,
                'uiSettings' => $data[1]['uiSettings'] ?? [],
            ];

            $command = new SaveTableCommand($d);
            $httpStatus = 200;

            $return = [
                'id' => $command->execute(),
                'success' => true,
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }

    /**
     * Create or update a custom table record.
     * Params: tableName, (optional) id for update, + field values.
     */
    public function saveTableRecordAction(): void
    {
        $data = [];
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
        }

        $tableName = $data['tableName'] ?? null;
        $id        = $data['id']        ?? null;

        if (empty($tableName)) {
            wp_send_json(['success' => false, 'error' => 'Missing tableName']);
        }

        // strip non-field keys from the record payload
        $fieldData = array_diff_key($data, array_flip(['tableName', 'id']));

        try {
            $controller = new TableRecordController();

            if (!empty($id)) {
                $result = $controller->update($tableName, $id, $fieldData);
            } else {
                $result = $controller->create($tableName, $fieldData);
            }

            wp_send_json(['success' => true] + $result);
        } catch (NotFoundException $e) {
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        } catch (\InvalidArgumentException | \RuntimeException $e) {
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
            wp_send_json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function saveTableTemplate(): void
    {
        if (!empty($this->request->post('data'))) {
            try {
                $data = $this->sanitizeJsonData($this->request->post('data'));

                if (!isset($data['name'])) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'Missing `name` param'
                    ], 500);
                }

                if (!isset($data['json'])) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'Missing `json` param'
                    ], 500);
                }

                $query = new SaveTableTemplateCommand($data['name'], $data['json']);
                $query->execute();

                wp_send_json([
                    'success' => true,
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ], 500);
            }
        }
    }

    /**
     * Execute a table schema action
     */
    public function tableSchemaAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                if (!isset($data['id'])) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'Missing id'
                    ]);
                }

                if (!isset($data['action'])) {
                    wp_send_json([
                        'success' => false,
                        'error' => 'Missing action'
                    ]);
                }

                $id = $data['id'];
                $action = $data['action'];

                $command = new ExecuteTableSchemaAction($id, $action);
                $command->execute();

                wp_send_json([
                    'success' => true,
                ]);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
                wp_send_json([
                    'success' => false,
                    'error' => $exception->getMessage()
                ]);
            }
        }
    }
}
