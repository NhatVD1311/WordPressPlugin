<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Command\CopyOptionPageCommand;
use ACPT\Core\CQRS\Command\DeleteOptionPageCommand;
use ACPT\Core\CQRS\Command\SaveOptionPagesCommand;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;

class OptionPageController extends AbstractController
{
    public function copyOptionPageAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            try {
                $command = new CopyOptionPageCommand($data);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function copyOptionPagesAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['pageIds'])) {
                wp_send_json([
                    'success' => false,
                    'error' => '`pageIds` is missing'
                ]);
            }

            if (!is_array($data['pageIds'])) {
                wp_send_json([
                    'success' => false,
                    'error' => '`pageIds` is not an array'
                ]);
            }

            try {
                foreach ($data['pageIds'] as $pageId) {
                    $command = new CopyOptionPageCommand([
                        'targetPageId' => $data['targetPageId'],
                        'pageId' => $pageId,
                        'deletePage' => $data['deletePage']
                    ]);
                    $command->execute();
                }

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }
    }

    public function deleteOptionPagesAction(): void
    {
        try {
            OptionPageRepository::deleteAll();

            $return = [
                'success' => true,
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return);
    }

    public function deletePageAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing id'
                ]);
            }

            try {
                $command = new DeleteOptionPageCommand($data['id']);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no data was sent'
        ]);
    }

    /**
     * Fetch option page
     *
     * @throws \Exception
     */
    public function fetchOptionPageAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['slug'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'no slug were sent'
                ], 500);
            }

            wp_send_json(OptionPageRepository::getByMenuSlug($data['slug']));
        }

        wp_send_json([
            'success' => false,
            'error' => 'no params were sent'
        ], 500);
    }

    /**
     * Fetch paginated option pages
     *
     * @throws \Exception
     */
    public function fetchOptionPagesAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $page = isset($data['page']) ? $data['page'] : null;
            $perPage = isset($data['perPage']) ? $data['perPage'] : null;
            $search = isset($data['search']) ? $data['search'] : null;
            $sort = isset($data['sort']) ? $data['sort'] : null;
            $order = isset($data['order']) ? $data['order'] : null;
        }

        wp_send_json([
            'count' => OptionPageRepository::count([
                'search' => isset($search) ? $search : null,
            ]),
            'records' => OptionPageRepository::get([
                'page' => isset($page) ? $page : 1,
                'perPage' => isset($perPage) ? $perPage : 20,
                'search' => isset($search) ? $search : null,
                'sort' => isset($sort) ? $sort : null,
                'order' => isset($order) ? $order : null,
            ]),
        ]);
    }

    /**
     * Fetch OP meta fields
     */
    public function fetchOptionPagesMetaAction(): void
    {
        try {
            $groups = [];
            $optionPageSlugs = OptionPageRepository::getAllSlugs();

            foreach ($optionPageSlugs as $optionPageSlug) {
                $groups[$optionPageSlug] = MetaRepository::get([
                    'belongsTo' => MetaTypes::OPTION_PAGE,
                    'find' => $optionPageSlug
                ]);
            }

            wp_send_json($groups);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'success' => false,
                'error' => $exception->getMessage()
            ], 500);
        }
    }

    /**
     * Save option page
     */
    public function saveOptionPagesAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'), [
            'description' => MetaFieldModel::EDITOR_TYPE,
        ]);

        try {
            $pages = (isset($data['pages']) && is_array($data['pages'])) ? $data['pages'] : [];
            $pages = array_filter($pages, function ($page) {
                return (
                    isset($page['menuTitle']) &&
                    isset($page['pageTitle']) &&
                    isset($page['menuTitle'])
                );
            });

            $command = new SaveOptionPagesCommand($pages);
            $httpStatus = 200;

            $return = [
                'ids' => $command->execute(),
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }
}
