<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\CQRS\Command\DeleteDatasetCommand;
use ACPT\Core\CQRS\Command\ImportDatasetCommand;
use ACPT\Core\CQRS\Command\SaveDatasetCommand;
use ACPT\Core\Repository\DatasetRepository;
use ACPT\Utils\Wordpress\Translator;

class DatasetController extends AbstractController
{
    /**
     * Delete custom post type
     */
    public function deleteDatasetAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));

            if (!isset($data['id'])) {
                wp_send_json([
                    'success' => false,
                    'error' => 'Missing id'
                ]);
            }

            $id = $data['id'];

            try {
                $command = new DeleteDatasetCommand($id);
                $command->execute();

                $return = [
                    'success' => true,
                ];
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);

                $return = [
                    'success' => false,
                    'error' => $exception->getMessage()
                ];
            }

            wp_send_json($return);
        }

        wp_send_json([
            'success' => false,
            'error' => 'no postType was sent'
        ]);
    }

    public function fetchDatasetsAction(): void
    {
        if (!empty($this->request->post('data'))) {
            $data = $this->sanitizeJsonData($this->request->post('data'));
            $page = isset($data['page']) ? $data['page'] : null;
            $perPage = isset($data['perPage']) ? $data['perPage'] : null;
            $search = isset($data['search']) ? $data['search'] : null;
            $sort = isset($data['sort']) ? $data['sort'] : null;
            $order = isset($data['order']) ? $data['order'] : null;
        }

        if (isset($data['id'])) {
            wp_send_json(
                DatasetRepository::getById($data['id'])
            );
        }

        wp_send_json([
            'count' => DatasetRepository::count([
                'search' => isset($search) ? $search : null,
            ]),
            'records' => DatasetRepository::get([
                'page' => isset($page) ? $page : 1,
                'perPage' => isset($perPage) ? $perPage : 20,
                'search' => isset($search) ? $search : null,
                'sort' => isset($sort) ? $sort : null,
                'order' => isset($order) ? $order : null,
            ]),
        ]);
    }

    public function importDatasetAction(): void
    {
        if (empty($this->request->files())) {
            wp_send_json([
                'error' => Translator::translate('No files uploaded')
            ], 500);
        }

        try {
            $file = $this->request->file('file');

            if (empty($this->request->post('id'))) {
                wp_send_json([
                    'success' => false,
                    'error' => 'No data sent'
                ], 500);
            }

            $id = $this->request->post('id');
            $command = new ImportDatasetCommand(sanitize_text_field(is_scalar($id) ? (string)$id : ''), $file);
            $outcome = $command->execute();

            if(empty($outcome->getItems())){
                wp_send_json([
                    'success' => false,
                    'error' => Translator::translate('No items imported')
                ], 500);
            }

            wp_send_json([
                'success' => true,
                'data' => $outcome
            ]);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            wp_send_json([
                'error' => (!empty($exception->getMessage())) ? $exception->getMessage() : 'Error during import occurred'
            ], 500);
        }
    }

    public function saveDatasetAction(): void
    {
        $data = $this->sanitizeJsonData($this->request->post('data'));

        if (
            !isset($data['name'])
        ) {
            wp_send_json([
                'success' => false,
                'error' => 'No data sent'
            ], 500);
        }

        $emptyItems = (!empty($data['emptyItems'])) ? $data['emptyItems'] : false;
        unset($data['emptyItems']);

        try {
            $httpStatus = 200;
            $command = new SaveDatasetCommand($data, $emptyItems);
            $return = [
                'id' => $command->execute(),
                'success' => true
            ];
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            $httpStatus = 500;
            $return = [
                'success' => false,
                'error' => $exception->getMessage()
            ];
        }

        wp_send_json($return, $httpStatus);
    }
}
