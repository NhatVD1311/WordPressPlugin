<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Core\API\AJAX\Middleware\AbstractMiddleware;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\ValueObjects\TableLocationObject;
use ACPT\Utils\Data\JsonSanitizer;
use ACPT\Utils\PHP\Request;

class AbstractController
{
    protected ?string $action = null;

    protected ?string $method = null;

    /** @var AbstractMiddleware[] */
    protected array $middlewares = [];

    protected Request $request;

    /**
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * @param string $action
     */
    public function setAction(string $action): void
    {
        $this->action = $action;
    }

    /**
     * @param string $method
     */
    public function setMethod(string $method): void
    {
        $this->method = $method;
    }

    /**
     * @param AbstractMiddleware $middleware
     */
    public function addMiddleware(AbstractMiddleware $middleware): void
    {
        // check if middleware of the same class already exists to avoid duplicates
        if (in_array($middleware, $this->middlewares, true)) {
            return;
        }

        $this->middlewares[] = $middleware;
    }

    /**
     * Handles the incoming request by executing the method specified in the `method` property,
     * if it exists. Iterates through any middlewares defined in the `middlewares` property and
     * invokes their `handle` method prior to calling the main method.
     *
     * If the specified method does not exist, the magic `__call` method is used as a fallback.
     *
     * Performs no operation if either the `action` or `method` property is empty.
     */
    public function handleRequest(): void
    {
        if (empty($this->action) || empty($this->method)) {
            wp_send_json(['success' => false, 'error' => 'No `action` or `method` provided'], 400);
        }

        if ($this->request->post('action') !== $this->method) {
            wp_send_json(['success' => false, 'error' => 'Wrong method called'], 404);
        }

        $m = $this->method;

        if (method_exists($this, $m)) {
            foreach ($this->middlewares as $middleware) {
                $middleware->handle($this->request);
            }

            $this->$m();
            return;
        }

        $this->$m();
    }

    /**
     * @param string               $name
     * @param array<int, mixed>    $arguments
     * @return void
     * @throws \Exception
     */
    public function __call(string $name, array $arguments)
    {
        wp_send_json(['success' => false, 'error' => 'Method not found'], 404);
    }

    /**
     * @param mixed $data
     * @param array<string, mixed> $fieldTypes Optional map of JSON key names to MetaFieldModel type constants.
     *                                         Keys listed here use the specified sanitization policy; all others
     *                                         default to TEXT_TYPE (strips all HTML). Applied at every nesting level.
     *                                         Example: ['description' => MetaFieldModel::EDITOR_TYPE]
     *
     * @return array<array-key, mixed>
     */
    protected function sanitizeJsonData($data, array $fieldTypes = []): array
    {
        return JsonSanitizer::sanitize($data, $fieldTypes);
    }

    /**
     * @param string $string
     *
     * @return string
     */
    protected function cleanHeadersAndFootersName(string $string): string
    {
        $directory = get_template_directory();

        return str_replace([$directory, '/', '.php'], '', $string);
    }

    /**
     * Parse a locationContext payload sent from the JS location selector.
     * Returns a map of ruleInt => string[] values.
     *
     * @param array<string, mixed> $data
     * @return array<int, string[]>
     */
    protected function parseLocationContext(array $data): array
    {
        $context = [];

        if (!isset($data['locationContext']) || !is_array($data['locationContext'])) {
            return $context;
        }

        foreach ($data['locationContext'] as $item) {
            $rule   = (int)($item['rule'] ?? 0);
            $values = [];

            foreach ($item['values'] ?? [] as $v) {
                $value = $v['value'] ?? null;
                $operator = $v['operator'] ?? "=";

                switch ($operator) {
                    default:
                    case "=":
                        switch ($rule) {
                            case TableLocationObject::RULE_POST_TAX:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                     INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                     WHERE tt.term_id = %d",
                                    (int)$value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_POST_CAT:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                     INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                     WHERE tt.term_id = %d AND tt.taxonomy = 'category'",
                                    (int)$value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_POST_TEMPLATE:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT post_id FROM {$wpdb->prefix}postmeta
                                     WHERE meta_key = '_wp_page_template' AND meta_value = %s",
                                    $value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;
                            default:
                                $values[] = $value;
                                break;
                        }
                        break;

                    case "IN":
                        switch ($rule) {
                            case TableLocationObject::RULE_POST_TAX:
                                global $wpdb;
                                $termIntIds   = array_map('intval', $value);
                                $placeholders = implode(',', array_fill(0, count($termIntIds), '%d'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                     INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                     WHERE tt.term_id IN ($placeholders)",
                                    $termIntIds
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_POST_CAT:
                                global $wpdb;
                                $termIntIds   = array_map('intval', $value);
                                $placeholders = implode(',', array_fill(0, count($termIntIds), '%d'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                     INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                     WHERE tt.term_id IN ($placeholders) AND tt.taxonomy = 'category'",
                                    $termIntIds
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_POST_TEMPLATE:
                                global $wpdb;
                                $placeholders = implode(',', array_fill(0, count($value), '%s'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT DISTINCT post_id FROM {$wpdb->prefix}postmeta
                                     WHERE meta_key = '_wp_page_template' AND meta_value IN ($placeholders)",
                                    $value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;
                            default:
                                $values = array_merge($values, $value);
                                break;
                        }
                        break;

                    case "NOT_IN":
                        switch ($rule) {
                            case TableLocationObject::RULE_PARENT_POST_ID:
                            case TableLocationObject::RULE_POST_ID:
                            case TableLocationObject::RULE_CUSTOM_POST_TYPE:
                                $args = [
                                    'post_type'      => 'any',
                                    'post_status'    => 'publish',
                                    'posts_per_page' => -1,
                                    'fields'         => 'ids',
                                    'post__not_in'   => $value,
                                ];

                                $values = array_merge($values, get_posts($args));
                                break;

                            case TableLocationObject::RULE_POST_TAX:
                                global $wpdb;
                                $termIntIds   = array_map('intval', $value);
                                $placeholders = implode(',', array_fill(0, count($termIntIds), '%d'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                         INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                         WHERE tt.term_id IN ($placeholders)
                                     )",
                                    $termIntIds
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_TERM_ID:
                            case TableLocationObject::RULE_TAXONOMY:
                                $taxonomies = get_taxonomies();
                                $args = [
                                    'taxonomy' => $taxonomies,
                                    'hide_empty' => false,
                                    'fields' => 'ids',
                                    'exclude' => $value,
                                ];
                                $terms = get_terms($args);
                                if (!is_wp_error($terms)) {
                                    $values = array_merge($values, $terms);
                                }
                                break;

                            case TableLocationObject::RULE_POST_CAT:
                                global $wpdb;
                                $termIntIds   = array_map('intval', $value);
                                $placeholders = implode(',', array_fill(0, count($termIntIds), '%d'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                         INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                         WHERE tt.term_id IN ($placeholders) AND tt.taxonomy = 'category'
                                     )",
                                    $termIntIds
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_POST_TEMPLATE:
                                global $wpdb;
                                $placeholders = implode(',', array_fill(0, count($value), '%s'));
                                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT post_id FROM {$wpdb->prefix}postmeta
                                         WHERE meta_key = '_wp_page_template' AND meta_value IN ($placeholders)
                                     )",
                                    $value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_USER_ID:
                            case TableLocationObject::RULE_USER:
                                $args = [
                                    'fields' => 'ID',
                                    'exclude' => $value,
                                ];
                                $users = get_users($args);
                                $values = array_merge($values, $users);
                                break;

                            case TableLocationObject::RULE_MEDIA:
                                $args = [
                                    'post_type' => 'attachment',
                                    'post_status'    => 'inherit',
                                    'posts_per_page' => -1,
                                    'fields'         => 'ids',
                                    'post__not_in'   => $value,
                                ];

                                $values = array_merge($values, get_posts($args));
                                break;

                            case TableLocationObject::RULE_COMMENT:
                                $args = [
                                    'fields' => 'ids',
                                    'comment__not_in' => $value,
                                ];
                                $comments = get_comments($args);
                                $values = array_merge($values, is_array($comments) ? $comments : []);
                                break;

                            case TableLocationObject::RULE_POST_STATUS:
                                break;
                        }
                        break;

                    case "!=":
                        switch ($rule) {
                            case TableLocationObject::RULE_PARENT_POST_ID:
                            case TableLocationObject::RULE_POST_ID:
                            case TableLocationObject::RULE_CUSTOM_POST_TYPE:
                                $args = [
                                    'post_type' => 'any',
                                    'post_status'    => 'publish',
                                    'posts_per_page' => -1,
                                    'fields'         => 'ids',
                                    'post__not_in'   => [$value],
                                ];

                                $values = array_merge($values, get_posts($args));
                                break;

                            case TableLocationObject::RULE_POST_TAX:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                         INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                         WHERE tt.term_id = %d
                                     )",
                                    (int)$value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;

                            case TableLocationObject::RULE_TERM_ID:
                            case TableLocationObject::RULE_TAXONOMY:
                                $taxonomies = get_taxonomies();
                                $args = [
                                    'taxonomy' => $taxonomies,
                                    'hide_empty' => false,
                                    'fields' => 'ids',
                                    'exclude' => [$value],
                                ];
                                $terms = get_terms($args);
                                if (!is_wp_error($terms)) {
                                    $values = array_merge($values, $terms);
                                }
                                break;
                            case TableLocationObject::RULE_POST_CAT:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT r.object_id FROM {$wpdb->prefix}term_relationships r
                                         INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tt.term_taxonomy_id = r.term_taxonomy_id
                                         WHERE tt.term_id = %d AND tt.taxonomy = 'category'
                                     )",
                                    (int)$value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;
                            case TableLocationObject::RULE_POST_TEMPLATE:
                                global $wpdb;
                                $postIds = $wpdb->get_col($wpdb->prepare(
                                    "SELECT ID FROM {$wpdb->prefix}posts
                                     WHERE post_status != 'trash'
                                     AND ID NOT IN (
                                         SELECT DISTINCT post_id FROM {$wpdb->prefix}postmeta
                                         WHERE meta_key = '_wp_page_template' AND meta_value = %s
                                     )",
                                    $value
                                ));
                                $values = array_merge($values, array_map('intval', $postIds));
                                break;
                            case TableLocationObject::RULE_USER_ID:
                            case TableLocationObject::RULE_USER:
                                $args = [
                                    'fields' => 'ID',
                                    'exclude' => [$value],
                                ];
                                $users = get_users($args);
                                $values = array_merge($values, $users);
                                break;
                            case TableLocationObject::RULE_MEDIA:
                                $args = [
                                    'post_type' => 'attachment',
                                    'post_status'    => 'inherit',
                                    'posts_per_page' => -1,
                                    'fields'         => 'ids',
                                    'post__not_in'   => [$value],
                                ];

                                $values = array_merge($values, get_posts($args));
                                break;
                            case TableLocationObject::RULE_COMMENT:
                                $args = [
                                    'fields' => 'ids',
                                    'comment__not_in' => [$value],
                                ];
                                $comments = get_comments($args);
                                $values = array_merge($values, is_array($comments) ? $comments : []);
                                break;
                            case TableLocationObject::RULE_POST_STATUS:
                                break;
                        }
                        break;
                }
            }

            if ($rule > 0 && !empty($values)) {
                $context[$rule] = $values;
            }
        }
        return $context;
    }

    /**
     * Processes location context rules to retrieve excluded IDs based on the provided data.
     *
     * @param array<string, mixed> $data An associative array containing the following:
     *                                   - 'table': The name of the database table (string).
     *                                   - 'recordId': The ID of the record being processed (string|int, optional).
     *                                   - 'locationContext': An array of location context rules (array, optional).
     *
     * @return array<int, mixed> An array of excluded IDs resulting from processing the location context rules.
     */
    protected function fetchedLocationValuesToBeExcluded(array $data = []): array
    {
        // Values to be excluded from results (e.g. already selected in other location rules)
        $table = $data['table'] ?? null;
        $recordId = isset($data['recordId']) ? (int)$data['recordId'] : null;
        $locationContext = $data['locationContext'] ?? [];
        $excludedIds = [];

        if (empty($table)) {
            return $excludedIds;
        }

        if (empty($locationContext) || !is_array($locationContext)) {
            return $excludedIds;
        }

        foreach ($locationContext as $rule) {
            $ruleInt = TableLocationObject::RULE_MAP[$rule['rule'] ?? ''] ?? null;

            if ($ruleInt === null) {
                continue;
            }

            $excludedIds = array_merge($excludedIds, TableRecordRepository::locationValuesForAGivenRule(
                $table,
                $ruleInt,
                $recordId
            ));
        }

        return $excludedIds;
    }

    /**
     * @param mixed $field
     *
     * @return array<string, mixed>
     */
    protected function convertFormFieldFromUI($field): array
    {
        // `isReusable` has no dedicated column/constructor param on FormFieldModel — it
        // rides inside `extra` (already a free-form bag that round-trips through save/
        // load) so CCT-bound fields (whose metaFieldId is always null, unlike legacy
        // meta fields) still have a persisted signal to lock their name field on.
        $extra = @$field['field']['extra'];
        $extra = is_array($extra) ? $extra : [];
        $extra['isReusable'] = @$field['field']['isReusable'];

        return [
            'id' => @$field['field']['id'],
            'metaFieldId' => @$field['field']['metaFieldId'],
            'group' => @$field['field']['group'],
            'key' => @$field['id'],
            'name' => @$field['field']['name'],
            'label' => @$field['field']['label'],
            'type' => @$field['field']['type'],
            'description' => @$field['field']['description'],
            'required' => (bool)@$field['field']['isRequired'],
            'extra' => $extra,
            'settings' => @$field['settings'],
            'rules' => @$field['validationRules'],
            'parentTab' => @$field['field']['parentTab'],
            'parentId' => @$field['field']['parentId'],
            'children' => [],
        ];
    }
}
