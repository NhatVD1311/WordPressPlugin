<?php

namespace ACPT\Core\API\AJAX\Controllers;

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Command\SaveWPMLConfigCommand;
use ACPT\Integrations\Polylang\Helper\PolylangChecker;
use ACPT\Integrations\WPML\Helper\WPMLChecker;
use ACPT\Integrations\WPML\Helper\WPMLConfig;
use ACPT\Integrations\WPML\Provider\MetaFieldsProvider;
use ACPT\Utils\Data\Meta;

class IntegrationController extends AbstractController
{
    public function deleteWPMLConfigAction(): void
    {
        WPMLConfig::destroy();

        wp_send_json([
            'success' => true,
        ]);
    }

    /**
     * Checks is BBThemeBuilder is active
     */
    public function isBBThemeBuilderActiveAction(): void
    {
        wp_send_json([
                'status' => is_plugin_active('bb-theme-builder/bb-theme-builder.php')
        ]);
    }

    /**
     * Checks is Oxygen builder is active
     */
    public function isOxygenBuilderActiveAction(): void
    {
        wp_send_json([
                'status' => is_plugin_active('oxygen/functions.php')
        ]);
    }

    /**
     * Checks is WPGraphQL is active
     */
    public function isWPGraphQLActiveAction(): void
    {
        wp_send_json([
            'status' => is_plugin_active('wp-graphql/wp-graphql.php'),
        ]);
    }

    /**
     * Save WPML Config file with custom settings
     */
    public function saveWPMLConfigAction(): void
    {
        if (WPMLChecker::isActive() || PolylangChecker::isActive()) {
            if (!empty($this->request->post('data'))) {
                try {
                    $data = $this->sanitizeJsonData($this->request->post('data'));
                    $query = new SaveWPMLConfigCommand($data);
                    $query->execute();

                    wp_send_json([
                        'success' => true,
                        'file' => WPMLConfig::fileExists(),
                        'fields' => MetaFieldsProvider::getInstance()->getFields(),
                        'xml' => Meta::fetch(WPMLConfig::ACPT_WPML_CONFIG_KEY, MetaTypes::OPTION_PAGE, WPMLConfig::ACPT_WPML_CONFIG_KEY)
                    ]);
                } catch (\Exception $exception) {
                    do_action("acpt/error", $exception);

                    wp_send_json([
                        'success' => false,
                        'error' => $exception->getMessage()
                    ], 500);
                }
            }
        }

        wp_send_json([
            'success' => false,
            'error' => 'Polylang or WPML are not active'
        ], 500);
    }

    public function wpmlConfigAction(): void
    {
        if (WPMLChecker::isActive() || PolylangChecker::isActive()) {
            $fields = MetaFieldsProvider::getInstance()->getFields();

            wp_send_json([
                'file' => WPMLConfig::fileExists(),
                'fields' => $fields,
                'xml' => Meta::fetch(WPMLConfig::ACPT_WPML_CONFIG_KEY, MetaTypes::OPTION_PAGE, WPMLConfig::ACPT_WPML_CONFIG_KEY)
            ]);
        }

        wp_send_json([
            'file' => false,
            'fields' => [],
            'xml' => null
        ]);
    }
}
