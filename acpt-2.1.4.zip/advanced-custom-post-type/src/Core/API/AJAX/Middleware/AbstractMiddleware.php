<?php

namespace ACPT\Core\API\AJAX\Middleware;

use ACPT\Utils\PHP\Request;

abstract class AbstractMiddleware
{
    abstract public function handle(Request $request): void;
}
