<?php

namespace ACPT\Core\Generators\Meta;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Generators\AbstractGenerator;
use ACPT\Core\Generators\Meta\Fields\AbstractField;
use ACPT\Core\Helper\Fields;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldBlockModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Utils\Data\DataAggregator;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\Wordpress\Translator;

class FieldBlockGenerator extends AbstractGenerator
{
    /**
     * @var MetaFieldBlockModel
     */
    private MetaFieldBlockModel $fieldBlockModel;

    /**
     * @var array<mixed>
     */
    private array $data = [];

    /**
     * @var string|null
     */
    private ?string $dataId = null;

    /**
     * @var string
     */
    private string $belongsTo;

    /**
     * @var string
     */
    private string $parentName;

    /**
     * @var string
     */
    private string $layout;

    /**
     * @var MetaFieldModel|null
     */
    private ?MetaFieldModel $leadingField = null;

    /**
     * @var int|null
     */
    private ?int $minimumBlocks = null;

    /**
     * @var int|null
     */
    private ?int $maximumBlocks = null;

    /**
     * @var string
     */
    private string $addLabel;

    /**
     * @var string
     */
    private string $deleteLabel;

    /**
     * FieldBlockGenerator constructor.
     *
     * @param MetaFieldBlockModel $fieldBlockModel
     * @param string $parentName
     * @param string $belongsTo
     * @param string $layout
     * @param string|null $leadingFieldId
     * @param int|null $minimumBlocks
     * @param int|null $maximumBlocks
     * @param string|null $addLabel
     * @param string|null $deleteLabel
     */
    public function __construct(
        MetaFieldBlockModel $fieldBlockModel,
        string $parentName,
        string $belongsTo,
        string $layout = 'row',
        ?string $leadingFieldId = null,
        ?int $minimumBlocks = null,
        ?int $maximumBlocks = null,
        ?string $addLabel = null,
        ?string $deleteLabel = null
    ) {
        $this->fieldBlockModel = $fieldBlockModel;
        $this->data = [];
        $this->belongsTo = $belongsTo;
        $this->parentName = $parentName;
        $this->layout = $layout;
        $this->minimumBlocks = $minimumBlocks;
        $this->maximumBlocks = $maximumBlocks;
        $this->addLabel = (!empty($addLabel)) ? $addLabel : Translator::translate('Add').' '.$this->fieldBlockModel->getLabelOrName();
        $this->deleteLabel = (!empty($deleteLabel)) ? $deleteLabel : Translator::translate('Delete all').' '.$this->fieldBlockModel->getLabelOrName();

        if ($leadingFieldId !== null) {
            try {
                $this->leadingField = MetaRepository::getMetaFieldById($leadingFieldId, true);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
            }
        }
    }

    /**
     * @param array<mixed> $data
     */
    public function setData(array $data): void
    {
        $this->data = $data;
    }

    /**
     * @param string|null $dataId
     */
    public function setDataId(?string $dataId): void
    {
        $this->dataId = $dataId;
    }

    /**
     * @param string $blocksListId
     * @param int|null $blockIndex
     *
     * @return string
     */
    public function generate(string $blocksListId, ?int $blockIndex = null): string
    {
        $label = (!empty($this->fieldBlockModel->getLabel())) ? $this->fieldBlockModel->getLabel() : $this->fieldBlockModel->getName();
        $id = 'block-'.rand(111111, 999999);

        $block = '<li id="'.$id.'" class="sortable-li sortable-li-'.$blocksListId.' acpt_blocks_list_item">';
        $block .= '<input type="hidden" name="'. Strings::esc_attr($this->parentName) . '[blocks][' . $blockIndex . '][' . $this->fieldBlockModel->getNormalizedName() . ']" value="[]">';
        $block .= '<div class="handle">.<br/>.<br/>.</div>';
        $block .= '<div class="sortable-content block-content">';
        $block .= '<div class="acpt_blocks_list_item_title">';
        $block .= '<h3><span>'.$label.'</span> <span class="acpt-badge acpt-badge-danger">BLOCK</span></h3>';
        $block .= '<div class="acpt_blocks_list_item_icons">';
        $block .= '<a title="'.Translator::translate("Remove this block").'" class="acpt_blocks_list_item_delete" data-target-id="'.$id.'" href="#">
						<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
							<path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"></path><path d="M9 10h2v8H9zm4 0h2v8h-2z"></path>
						</svg>
					</a>';
        $block .= '<a title="'.Translator::translate("Show/hide elements in this block").'" class="acpt_blocks_list_item_toggle_visibility" data-target-id="'.$id.'" href="#">
						<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="18" height="18" class="components-panel__arrow" aria-hidden="true" focusable="false">
							<path d="M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z"></path>
						</svg>
					</a>';
        $block .= '</div>';
        $block .= '</div>';
        $block .= '<div class="acpt_blocks_list_item_fields" data-parent-id="'.$id.'">';
        $block .= $this->generateBlockElements($blockIndex);
        $block .= '</div>';
        $block .= '<a 
			style="margin-right: 5px" 
			data-min-blocks="'.$this->minimumBlocks.'"
			data-max-blocks="'.$this->maximumBlocks.'"
			data-add-label="'.$this->addLabel.'"
			data-delete-label="'.$this->deleteLabel.'"
			data-layout="'.$this->layout.'" 
			data-index="'.$blockIndex.'" 
			data-media-type="'.$this->belongsTo.'" 
			data-parent-name="'.$this->parentName.'" 
			data-field-id="'.$this->fieldBlockModel->getMetaField()->getId().'" 
			data-block-name="'.$this->fieldBlockModel->getName().'"
			data-block-id="'.$id.'" 
			data-group-id="'.$this->fieldBlockModel->getId().'" 
			href="#" 
			class="acpt_add_flexible_element_btn button small"
		>
			'.$this->addLabel.'
		</a>';
        $block .= '<a 
			data-layout="'.$this->layout.'" 
			data-min-blocks="'.$this->minimumBlocks.'"
			data-max-blocks="'.$this->maximumBlocks.'"
			data-add-label="'.$this->addLabel.'"
			data-delete-label="'.$this->deleteLabel.'"
			data-index="'.$blockIndex.'" 
			data-media-type="'.$this->belongsTo.'" 
			data-parent-name="'.$this->parentName.'" 
			data-block-id="'.$id.'" 
			data-group-id="'.$this->fieldBlockModel->getId().'" 
			data-element="'.$this->fieldBlockModel->getLabelOrName().'"
			href="#" 
			class="acpt_delete_all_flexible_element_btn button button-danger small"
		>
			'.$this->deleteLabel.'
		</a>';

        $block .= '</div>';
        $block .= '</li>';

        return $block;
    }

    /**
     * @param int|null $blockIndex
     *
     * @return string
     */
    private function generateBlockElements(?int $blockIndex): string
    {
        $id = 'block-elements-'.$this->fieldBlockModel->getId(). '-'. $blockIndex;
        $aggregateData = DataAggregator::aggregateNestedFieldsData($this->data);

        if ($this->layout === 'table') {
            return $this->generateBlockElementsWithTableLayout($id, $blockIndex, $aggregateData);
        }

        return $this->generateBlockElementsWithRowLayout($id, $blockIndex, $aggregateData);
    }

    /**
     * @param string $id
     * @param int|null $blockIndex
     * @param array<mixed> $aggregateData
     *
     * @return string
     */
    private function generateBlockElementsWithTableLayout(string $id, ?int $blockIndex, array $aggregateData): string
    {
        $list = '<div class="acpt-table-responsive">';
        $list .= '<table class="acpt-table">';
        $list .= '<tbody id="'.$id.'" class="acpt-nested-sortable"';

        if ($this->minimumBlocks) {
            $list .= ' data-min-blocks="'.$this->minimumBlocks.'"';
        }

        if ($this->maximumBlocks) {
            $list .= ' data-max-blocks="'.$this->maximumBlocks.'"';
        }

        $list .= '>';
        $list .= '<tr>';
        $list .= '<th width="30"></th>';

        foreach ($this->fieldBlockModel->getFields() as $child) {
            $list .= '<th>'.$child->getLabelOrName().'</th>';
        }

        $list .= '<th></th>';
        $list .= '</tr>';

        if (!empty($aggregateData)) {
            foreach ($aggregateData as $elementIndex => $aggregateDatum) {
                $list .= $this->generateElement($elementIndex, $id, $blockIndex, $aggregateDatum);
            }
        } else {
            $list .= '<tr><td colspan="'.(Arrays::count($this->fieldBlockModel->getFields())+2).'"><p data-message-id="'.$id.'" class="update-nag notice notice-warning inline no-records">'.Translator::translate('No elements saved, generate the first one clicking on "Add element" button').'</p></td></tr>';
        }

        $list .= '</tbody>';
        $list .= '</table>';
        $list .= '</div>';

        return $list;
    }

    /**
     * @param string $id
     * @param int|null $blockIndex
     * @param array<mixed> $aggregateData
     *
     * @return string
     */
    private function generateBlockElementsWithRowLayout(string $id, ?int $blockIndex, array $aggregateData): string
    {
        $list = '<ul id="'.$id.'" class="acpt_nested_fields_list acpt-nested-sortable">';

        if (!empty($aggregateData)) {
            foreach ($aggregateData as $elementIndex => $aggregateDatum) {
                $list .= $this->generateElement($elementIndex, $id, $blockIndex, $aggregateDatum);
            }
        } else {
            $list .= '<p data-message-id="'.$id.'" class="update-nag notice notice-warning inline no-records">'.Translator::translate('No elements saved, generate the first one clicking on "Add element" button').'</p>';
        }

        $list .= '</ul>';

        return $list;
    }


    /**
     * @param int $elementIndex
     * @param string $blockId
     * @param int|null $blockIndex
     * @param array<mixed> $data
     *
     * @return string
     */
    public function generateElement(int $elementIndex, string $blockId, ?int $blockIndex, array $data = []): string
    {
        $id = 'element-'.rand(111111, 999999);

        if ($this->layout === 'table') {
            return $this->generateElementWithTableLayout($id, $blockId, $blockIndex, $elementIndex, $data);
        }

        if ($this->layout === 'block') {
            return $this->generateElementWithBlockLayout($id, $blockId, $blockIndex, $elementIndex, $data);
        }

        return $this->generateElementWithRowLayout($id, $blockId, $blockIndex, $elementIndex, $data);
    }

    /**
     * @param string $id
     * @param string $blockId
     * @param int|null $blockIndex
     * @param int $elementIndex
     * @param array<mixed> $data
     *
     * @return string
     */
    private function generateElementWithTableLayout(string $id, string $blockId, ?int $blockIndex, int $elementIndex, array $data): string
    {
        $element = '<tr id="'.$id.'" class="sortable-li sortable-li-'.$this->fieldBlockModel->getId(). '-'. $blockIndex.'">';
        $element .= '<td width="30">';
        $element .= '<div class="handle">.<br/>.<br/>.</div>';
        $element .= '</td>';

        foreach ($this->fieldBlockModel->getFields() as $fieldModel) {
            $value = $this->getDafaultNestedFieldValue($data, $fieldModel->getNormalizedName());
            $flexibleField = $this->getFlexibleField($fieldModel, $elementIndex, $blockIndex, $value);

            $element .= '<td>';
            $element .= $flexibleField->render();
            $element .= '</td>';
        }

        $element .= '<td width="120">';
        $element .= '<div class="acpt-flex gap-5">
            <a 
                class="button small button-danger remove-grouped-element" 
                data-parent-id="'.$blockId.'"
                data-layout="table" 
                data-element="element" 
                data-elements="elements" 
                data-target-id="'.$id.'" 
                data-index="'.$elementIndex.'"
                href="#"
                title="'.Translator::translate('Remove').' '.$this->fieldBlockModel->getLabelOrName().'"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
                    <path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"></path><path d="M9 10h2v8H9zm4 0h2v8h-2z"></path>
                </svg>
            </a>
        </div>';
        $element .= '</td>';
        $element .= '</tr>';

        return $element;
    }

    /**
     * @param string $id
     * @param string $blockId
     * @param int|null $blockIndex
     * @param int $elementIndex
     * @param array<mixed> $data
     *
     * @return string
     */
    private function generateElementWithBlockLayout(string $id, string $blockId, ?int $blockIndex, int $elementIndex, array $data): string
    {
        $element = '<li id="'.$id.'" class="sortable-li sortable-li-'.$this->fieldBlockModel->getId(). '-'. $blockIndex.'">';
        $element .= '<div class="handle">.<br/>.<br/>.</div>';
        $element .= '<span class="sortable-li_collapsed_placeholder">'.$this->collapsedPlaceholder($elementIndex, $data).'</span>';
        $element .= '<div class="sortable-content">';

        $element .= '<div class="acpt-table-responsive">';
        $element .= '<table class="acpt-table acpt-vertical-table">';
        $element .= '<tbody>';
        $element .= '</tbody>';

        foreach ($this->fieldBlockModel->getFields() as $fieldModel) {
            $value = $this->getDafaultNestedFieldValue($data, $fieldModel->getNormalizedName());
            $flexibleField = $this->getFlexibleField($fieldModel, $elementIndex, $blockIndex, $value);

            $element .= '<tr>';
            $element .= '<th><span class="text-ellipsis">'.$fieldModel->getLabelOrName().'</span></th>';
            $element .= '<td>'.$flexibleField->render().'</td>';
            $element .= '</tr>';
        }

        $element .= '</table>';
        $element .= '</div>';
        $element .= '</div>';
        $element .= '
            <div class="acpt-flex gap-5">
                <a 
                    class="button small button-danger remove-grouped-element" 
                    data-parent-id="'.$blockId.'"
                    data-layout="row" 
                    data-element="element" 
                    data-elements="elements" 
                    data-target-id="'.$id.'"
                    data-index="'.$elementIndex.'"
                    href="#"
                    title="'.Translator::translate('Remove').' '.$this->fieldBlockModel->getLabelOrName().'"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
                        <path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"></path><path d="M9 10h2v8H9zm4 0h2v8h-2z"></path>
                    </svg>
                </a>
                <a title="'.Translator::translate("Show/hide elements").'" class="button small sortable-li_toggle_visibility" data-target-id="'.$id.'" href="#">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="18" height="18" class="components-panel__arrow" aria-hidden="true" focusable="false">
                        <path d="M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z"></path>
                    </svg>
                </a>
            </div>';
        $element .= '</li>';

        return $element;
    }

    /**
     * @param string $id
     * @param string $blockId
     * @param int|null $blockIndex
     * @param int $elementIndex
     * @param array<mixed> $data
     *
     * @return string
     */
    private function generateElementWithRowLayout(string $id, string $blockId, ?int $blockIndex, int $elementIndex, array $data): string
    {
        $element = '<li id="'.$id.'" class="sortable-li sortable-li-'.$this->fieldBlockModel->getId(). '-'. $blockIndex.'">';
        $element .= '<div class="handle">.<br/>.<br/>.</div>';
        $element .= '<span class="sortable-li_collapsed_placeholder">'.$this->collapsedPlaceholder($elementIndex, $data).'</span>';
        $element .= '<div class="sortable-content">';

        $rows = Fields::extractFieldRows($this->fieldBlockModel->getFields());

        foreach ($rows as $row) {
            $randomId = Strings::generateRandomId();
            $element .= "<div class='acpt-admin-meta-row' id='".$randomId."'>";
            $visibleFieldsCount = 0;

            foreach ($row as $index => $fieldModel) {
                $value = $this->getDafaultNestedFieldValue($data, $fieldModel->getNormalizedName());
                $flexibleField = $this->getFlexibleField($fieldModel, $elementIndex, $blockIndex, $value);

                if ($flexibleField->isVisible()) {
                    $visibleFieldsCount++;
                }

                $element .= $flexibleField->render();
            }

            // hidden row containing only not visible fields
            if ($visibleFieldsCount == 0) {
                $element = str_replace("<div class='acpt-admin-meta-row' id='".$randomId."'>", "<div class='acpt-admin-meta-row hidden' id='".$randomId."'>", $element);
            }

            $element .= "</div>";
        }

        $element .= '</div>';
        $element .= '
		    <div class="acpt-flex gap-5">
                <a 
                    class="button small button-danger remove-grouped-element" 
                    data-parent-id="'.$blockId.'"
                    data-layout="row" 
                    data-element="element" 
                    data-elements="elements" 
                    data-target-id="'.$id.'"
                    data-index="'.$elementIndex.'"
                    href="#"
                    title="'.Translator::translate('Remove').' '.$this->fieldBlockModel->getLabelOrName(). '"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
                        <path d="M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"></path><path d="M9 10h2v8H9zm4 0h2v8h-2z"></path>
                    </svg>
                </a>
                <a title="'.Translator::translate("Show/hide elements").'" class="button small sortable-li_toggle_visibility" data-target-id="'.$id.'" href="#">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="18" height="18" class="components-panel__arrow" aria-hidden="true" focusable="false">
                        <path d="M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z"></path>
                    </svg>
                </a>
            </div>';
        $element .= '</li>';

        return $element;
    }

    /**
     * @param int $elementIndex
     * @param array<mixed> $data
     *
     * @return string
     */
    private function collapsedPlaceholder(int $elementIndex, array $data = []): string
    {
        if ($this->leadingField === null) {
            return Translator::translate("Collapsed element").' #'.$elementIndex;
        }

        $value = $this->getDafaultNestedFieldValue($data, $this->leadingField->getNormalizedName());

        if (is_array($value)) {
            $value = implode(", ", $value);
        }

        return '<span class="label">'.$this->leadingField->getLabelOrName().'</span>' . ': <span class="value">' . $value . '</span>';
    }

    /**
     * @param array<mixed> $data
     * @param string $key
     *
     * @return mixed
     */
    private function getDafaultNestedFieldValue(array $data, string $key)
    {
        if (empty($data)) {
            return null;
        }

        foreach ($data as $datum) {
            if ($key === $datum['key']) {
                return $datum['value'];
            }
        }

        return null;
    }

    /**
     * @param MetaFieldModel $fieldModel
     * @param int $elementIndex
     * @param int|null $blockIndex
     * @param mixed $value
     *
     * @return AbstractField|null
     */
    private function getFlexibleField(MetaFieldModel $fieldModel, int $elementIndex, ?int $blockIndex, $value = null): ?AbstractField
    {
        $className = 'ACPT\\Core\\Generators\\Meta\\Fields\\'.$fieldModel->getType().'Field';

        if (class_exists($className)) {
            $field = new $className($fieldModel, $this->belongsTo, $this->dataId, $elementIndex, $value, $this->parentName, $blockIndex);

            if ($field instanceof AbstractField) {
                // CCT sub-field models have no blockId (they are synthetic), so
                // isNestedInABlock() returns false without this injection.
                if ($this->belongsTo === MetaTypes::TABLE) {
                    $field->setParentBlock($this->fieldBlockModel);
                }
                return $field;
            }
        }

        return null;
    }
}
