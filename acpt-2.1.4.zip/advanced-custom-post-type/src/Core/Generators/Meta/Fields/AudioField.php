<?php

namespace ACPT\Core\Generators\Meta\Fields;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\Wordpress\Translator;
use ACPT\Utils\Wordpress\WPAttachment;

class AudioField extends AbstractField
{
    /**
     * @return string
     */
    public function render(): string
    {
        $this->enqueueAssets();
        $minSize = $this->getAdvancedOption('min_size') ? $this->getAdvancedOption('min_size') : null;
        $maxSize = $this->getAdvancedOption('max_size') ? $this->getAdvancedOption('max_size') : null;
        $attachmentId = (isset($this->getAttachments()[0])) ? $this->getAttachments()[0]->getId() : '';
        $preview = $this->preview();

        if ($this->isChild() || $this->isNestedInABlock()) {
            $id = "audio_".Strings::generateRandomId();
            $field = '<input type="hidden" name="'. Strings::esc_attr($this->getIdName()).'[type]" value="'.MetaFieldModel::AUDIO_TYPE.'">';
            $field .= '<input type="hidden" name="'. Strings::esc_attr($this->getIdName()).'[original_name]" value="'.$this->metaField->getName().'">';
        } else {
            $id = Strings::esc_attr($this->getIdName());
            $field = '<input type="hidden" name="'. Strings::esc_attr($this->getIdName()).'_type" value="'.MetaFieldModel::AUDIO_TYPE.'">';
        }

        $field .= '<div class="file-upload-wrapper">';
        $field .= '<div class="audio-preview">'. $preview .'</div>';
        $field .= '<div class="btn-wrapper">';

        if ($this->isChild() || $this->isNestedInABlock()) {
            $field .= '<input id="'.$id.'[attachment_id]['.$this->getIndex().']" name="'. esc_html($this->getIdName()).'[attachment_id]" type="hidden" value="' .$attachmentId.'">';
            $field .= '<input readonly '.$this->required().' id="'.$id.'" name="'. Strings::esc_attr($this->getIdName()).'[value]" type="text" class="hidden" value="' .Strings::esc_attr($this->getDefaultValue()) .'" '.$this->appendDataValidateAndLogicAttributes().'>';
        } else {
            $field .= '<input id="'.$id.'_attachment_id" name="'. esc_html($this->getIdName()).'_attachment_id" type="hidden" value="' .$attachmentId.'">';
            $field .= '<input readonly '.$this->required().' id="'.$id.'" name="'. Strings::esc_attr($this->getIdName()).'" type="text" class="hidden" value="' .Strings::esc_attr($this->getDefaultValue()) .'" '.$this->appendDataValidateAndLogicAttributes().'>';
        }

        $field .= '<a data-max-size="'.$maxSize.'" data-min-size="'.$minSize.'" class="upload-audio-btn button button-primary">'.Translator::translate("Upload").'</a>';
        $field .= '<button data-target-id="'.$id.'" class="upload-delete-btn delete-audio-btn button button-secondary">'.Translator::translate("Delete").'</button>';

        $field .= '</div>';
        $field .= '</div>';


        return $this->renderField($field);
    }

    /**
     * @return string|null
     */
    private function preview(): ?string
    {
        if (!empty($this->getDefaultValue()) && is_string($this->getDefaultValue())) {
            $attachment = (isset($this->getAttachments()[0])) ? $this->getAttachments()[0] : null;

            if (empty($attachment)) {
                $attachment = WPAttachment::fromUrl($this->getDefaultValue());
            }

            if ($attachment->isEmpty()) {
                return null;
            }

            return "<div class='audio'>".$this->formatAudio($attachment)."</div>";
        }

        return '<span class="placeholder">'.Translator::translate("No audio selected").'</span>';
    }

    /**
     * @param WPAttachment $attachment
     * @return string
     */
    protected function formatAudio(WPAttachment $attachment): string
    {
        if (!$attachment->isAudio()) {
            return '<span class="placeholder">Wrong audio data</span>';
        }

        $src = esc_url($attachment->getSrc());
        $title = $attachment->getTitle() ?: 'Unknown title';
        $album = (isset($attachment->getMetadata()['album']) && !empty($attachment->getMetadata()['album'])) ? $attachment->getMetadata()['album'] : 'Unknown album';
        $artist = (isset($attachment->getMetadata()['artist']) && !empty($attachment->getMetadata()['artist'])) ? $attachment->getMetadata()['artist'] : 'Unknown artist';

        $audio  = '<div class="acpt-audio-meta-wrapper">';
        $audio .= '<div class="acpt-audio-meta">';
        $audio .= '<h5 class="title">'.$title.'</h5>';
        $audio .= '<div class="meta">';

        $audio .= '<span class="artist">'.$artist.'</span>';
        $audio .= '<span class="album">- '.$album.'</span>';

        $audio .= '</div>';
        $audio .= '</div>';
        $audio .= '<audio class="acpt-audio-player" controls src="'.$src.'"></audio>';
        $audio .= '</div>';

        return $audio;
    }

    /**
     * @return void
     */
    private function enqueueAssets(): void
    {
        wp_enqueue_script('audio-player-js', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/audio-player.js' : 'advanced-custom-post-type/assets/static/js/audio-player.min.js'), [], '1.0.0', true);
    }
}
