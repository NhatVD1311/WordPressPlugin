<?php

namespace ACPT\Core\Generators\Meta\Fields;

abstract class AbstractUnitOfMeasureField extends AbstractField
{
    /**
     * Attribute name used both as the legacy array unit key and as the
     * getDefaultAttributeValue() attribute (e.g. 'currency', 'weight', 'length').
     *
     * @return string
     */
    abstract protected function unitAttribute(): string;

    /**
     * Legacy WP-meta amount key (e.g. 'currencyValue', 'weightValue', 'lengthValue').
     *
     * @return string
     */
    abstract protected function legacyValueKey(): string;

    /**
     * Fallback unit when nothing else resolves it (e.g. 'USD', 'KILOGRAM', 'METER').
     *
     * @return string
     */
    abstract protected function defaultUnit(): string;

    /**
     * @return string|null
     */
    protected function defaultValue(): ?string
    {
        $defaultValue = $this->getDefaultValue();

        // case 1: value is numeric (123)
        if (is_numeric($defaultValue)) {
            return (string)$defaultValue;
        }

        // case 2:
        // value is in the format:
        // array(
        //  "unit" => "EUR",
        //  "value" => 123
        // )
        if (is_array($defaultValue)) {
            // CCT shape: {value, unit}
            if (isset($defaultValue['value'])) {
                return (string)$defaultValue['value'];
            }
            // Legacy WP-meta shape: {<type>Value, ...}
            if (isset($defaultValue[$this->legacyValueKey()])) {
                return (string)$defaultValue[$this->legacyValueKey()];
            }
        }

        // case 3: value is object:
        // {"unit": "EUR", "value": 123}
        if (is_object($this->getValue()) && isset($this->getValue()->value)) {
            return (string)$this->getValue()->value;
        }

        // case 4: value is array:
        // {"unit": "EUR", "value": 123}
        if (is_array($this->getValue()) && isset($this->getValue()['value'])) {
            return (string)$this->getValue()['value'];
        }

        // case 5: value is a string (e.g. '1234 EUR')
        // an array reaching this point has no amount (e.g. {"currencyValue":null,"currency":"EUR"})
        if (!is_string($defaultValue)) {
            return null;
        }

        $v = explode(" ", $defaultValue);

        if (count($v) === 2) {
            return $v[0];
        }

        return null;
    }

    /**
     * @return string
     */
    protected function getDefaultUnitValue(): string
    {
        // a unit saved without an amount: getDefaultValue() falls back to the field's
        // default value, whose unit must not override the saved one (#1355)
        $savedUnit = $this->getDefaultAttributeValue($this->unitAttribute());

        if (is_string($savedUnit) && $savedUnit !== '') {
            return $savedUnit;
        }

        $defaultValue = $this->getDefaultValue();

        if (is_array($defaultValue)) {
            // CCT shape: {value, unit}
            if (isset($defaultValue['unit'])) {
                return (string)$defaultValue['unit'];
            }
            // Legacy WP-meta shape: {<type>Value, <type>}
            if (isset($defaultValue[$this->unitAttribute()])) {
                return (string)$defaultValue[$this->unitAttribute()];
            }
        }

        // decode raw json
        // {"unit": "EUR", "value": 123}
        if (is_object($this->getValue()) && isset($this->getValue()->unit)) {
            return (string)$this->getValue()->unit;
        }

        // case 4: value is array:
        // {"unit": "EUR", "value": 123}
        if (is_array($this->getValue()) && isset($this->getValue()['unit'])) {
            return (string)$this->getValue()['unit'];
        }

        // case 5: value is a string (e.g. '1234 EUR')
        if (is_string($defaultValue)) {
            $v = explode(" ", $defaultValue);

            if (count($v) === 2) {
                return $v[1];
            }
        }

        $uomDefaultValue = $this->getAdvancedOption('uom_default_value') ? $this->getAdvancedOption('uom_default_value') : $this->defaultUnit();

        return $this->getDefaultAttributeValue($this->unitAttribute(), $uomDefaultValue);
    }
}
