<?php

namespace ACPT\Core\Generators\CustomPostType;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Generators\Meta\Fields\AbstractField;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\TableRecord;

class CustomPostTypeMetaBoxFieldGenerator
{
    /**
     * @param int    $postId
     * @param MetaFieldModel $metaField
     *
     * @return AbstractField
     * @throws \Exception
     */
    public static function generate(MetaFieldModel $metaField, $postId = null)
    {
        return self::getCustomPostTypeField($metaField, $postId);
    }

    /**
     * @param int    $postId
     * @param MetaFieldModel $metaField
     *
     * @return AbstractField|null
     */
    private static function getCustomPostTypeField(MetaFieldModel $metaField, $postId = null): ?AbstractField
    {
        $className = 'ACPT\\Core\\Generators\\Meta\\Fields\\'.$metaField->getType().'Field';
        $value = null;

        if (class_exists($className)) {
            $isCCTCopy = $metaField->getBox()->getGroup()->isCCTCopy();
            $belongs = $isCCTCopy ? MetaTypes::TABLE : MetaTypes::CUSTOM_POST_TYPE;
            $find = $isCCTCopy ? $metaField->getBox()->getGroup()->getName() : $postId;

            if (!empty($postId)) {
                if ($isCCTCopy) {
                    $tableName  = $metaField->getBox()->getGroup()->getName();
                    $tableModel = TableRepository::getByName($tableName);

                    if ($tableModel instanceof TableModel) {
                        $value = TableRecord::fetch($tableModel, ['postId' => $postId], $metaField->getName());
                    }
                } else {
                    $value = Meta::fetch($postId, $belongs, $metaField->getDbName());
                }
            }

            /** @var AbstractField $instance */
            $instance = new $className($metaField, $belongs, $find);

            if ($value !== '' && $value !== null) {
                $instance->setValue($value);
            }

            if ($postId !== null && get_post_type($postId) === 'attachment') {
                $instance->setNoShowLabel(true);
            }

            return $instance;
        }

        return null;
    }
}
