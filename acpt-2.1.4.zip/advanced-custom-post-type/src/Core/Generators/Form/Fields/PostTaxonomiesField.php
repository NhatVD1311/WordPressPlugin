<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Constants\TaxonomyField;
use ACPT\Core\Helper\Strings;
use ACPT\Utils\Wordpress\Terms;
use ACPT\Utils\Wordpress\Translator;

class PostTaxonomiesField extends AbstractField
{
    /**
     * @inheritDoc
     */
    public function render(): string
    {
        $taxonomy = (!empty($this->fieldModel->getExtra()['taxonomy'])) ? $this->fieldModel->getExtra()['taxonomy'] : "all";
        $selector = (!empty($this->fieldModel->getExtra()['selector'])) ? $this->fieldModel->getExtra()['selector'] : "select";
        $empty = (!empty($this->fieldModel->getExtra()['empty'])) ? $this->fieldModel->getExtra()['empty'] : false;
        // getFind() is nullable on FormFieldModel (only set once a target post type is
        // configured); Terms::getForPostType() requires a non-null string, so fall back to
        // "post" rather than fataling the whole form render for an unconfigured field.
        $options = Terms::getForPostType($this->fieldModel->getFind() ?? 'post', $taxonomy);
        $isMulti = (!empty($this->fieldModel->getExtra()['isMulti'])) ? $this->fieldModel->getExtra()['isMulti'] : false;
        $name = Strings::esc_attr($this->getIdName());

        if ($selector === "checkbox-radio") {
            return $this->renderCheckboxes($name, $isMulti, $empty, $options);
        }

        return $this->renderSelect($name, $isMulti, $empty, $options);
    }

    /**
     * @param string $name
     * @param bool $isMulti
     * @param bool $empty
     * @param array<string, array<string, string>> $options
     *
     * @return string
     */
    private function renderCheckboxes(string $name, bool $isMulti, bool $empty, array $options): string
    {
        $field = "<div class='acpt-term-selector-wrapper'>";
        $name = $isMulti ? $name."[]" : $name;
        $inputType = $isMulti ? "checkbox" : "radio";

        foreach ($options as $taxonomy => $terms) {
            $field .= "<fieldset class='acpt-term-selector'>";
            $field .= "<legend>".$taxonomy."</legend>";
            $field .= "<ul class='acpt-term-selector-list'>";

            if (!$isMulti && $empty) {
                $fieldId = Strings::generateRandomId();
                $field .= '<li>';
                $field .= '<input id="'.$fieldId.'" type="'.$inputType.'" name="'.$name.'" value="" />';
                $field .= '<label for="'.$fieldId.'">'.Translator::translate("Select").'</label>';
                $field .= '</li>';
            }

            $savedTerms = $this->savedTerms($taxonomy);

            foreach ($terms as $id => $term) {
                $realId = explode(TaxonomyField::SEPARATOR, $id);
                $fieldId = Strings::generateRandomId();

                $field .= '<li>';
                $field .= '<input '.(in_array($realId[1], $savedTerms) ? "checked" : "").' id="'.$fieldId.'" type="'.$inputType.'" name="'.$name.'" value="'.Strings::esc_attr($id).'" />';
                $field .= '<label for="'.$fieldId.'">'.Strings::esc_attr($term).'</label>';
                $field .= '</li>';
            }

            $field .= "</ul>";
            $field .= "</fieldset>";
        }

        $field .= "</div>";

        return $field;
    }

    /**
     * @param string $name
     * @param bool $isMulti
     * @param bool $empty
     * @param array<string, array<string, string>> $options
     *
     * @return string
     */
    private function renderSelect(string $name, bool $isMulti, bool $empty, array $options): string
    {
        $name = $isMulti ? $name."[]" : $name;

        $field = "<select
		    ".$this->disabled()."
			".($isMulti ? "multiple" : "")."
			id='".Strings::esc_attr($this->getIdName())."'
			name='".$name."'
			placeholder='".$this->placeholder()."'
			class='".$this->cssClass()."'
			".$this->required()."
		>";

        if ($empty) {
            $field .= '
				<option value="">
			        '.Translator::translate("Select").'
				</option>';
        }

        foreach ($options as $taxonomy => $terms) {
            $savedTerms = $this->savedTerms($taxonomy);
            $field .= '<optgroup label="'.$taxonomy.'">';

            foreach ($terms as $id => $term) {
                $realId = explode(TaxonomyField::SEPARATOR, $id);

                $field .= '
					<option
				        value="'.Strings::esc_attr($id).'"
				        '.(in_array($realId[1], $savedTerms) ? "selected" : "").'
			        >
				        '.Strings::esc_attr($term).'
					</option>';
            }

            $field .= '</optgroup>';
        }

        $field .= '</select>';

        return $field;
    }

    /**
     * @param string $taxonomy
     *
     * @return array<int, int>
     */
    private function savedTerms(string $taxonomy): array
    {
        $savedTerms = [];
        $postId = $this->postId;

        if ($postId === null && (is_single() || is_page())) {
            $page = get_post();
            $postId = $page->ID;
        }

        if ($postId !== null) {
            $postTerms = get_the_terms($postId, $taxonomy);

            if (is_array($postTerms)) {
                foreach ($postTerms as $t) {
                    $savedTerms[] = $t->term_id;
                }
            }
        }

        return $savedTerms;
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
