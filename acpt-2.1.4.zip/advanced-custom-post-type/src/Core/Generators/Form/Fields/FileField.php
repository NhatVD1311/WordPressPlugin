<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\PHP\JSON;
use ACPT\Utils\Wordpress\WPAttachment;
use ACPT\Utils\Wordpress\WPAttachmentFactory;

class FileField extends AbstractField
{
    /**
     * @inheritDoc
     */
    public function render(): string
    {
        $randomId = Strings::generateRandomId();
        $accept = (!empty($this->fieldModel->getExtra()['accept'])) ? $this->fieldModel->getExtra()['accept'] : $this->accept();
        $multiple = (!empty($this->fieldModel->getExtra()['multiple'])) ? $this->fieldModel->getExtra()['multiple'] : $this->multiple();
        $name = ($multiple) ? Strings::esc_attr($this->getIdName()).'[]' : Strings::esc_attr($this->getIdName());

        return "
			<input
			    ".$this->disabled()."
				id='".Strings::esc_attr($this->getIdName())."'
				data-target-id='".$randomId."'
				name='".$name."'
				placeholder='".$this->placeholder()."'
				type='file'
				".($multiple ? 'multiple' : '')."
				accept='".$accept."'
				class='acpt-file ".$this->cssClass()."'
				".$this->required()."
				".$this->appendDataValidateAndConditionalRenderingAttributes()."
			/>
			<input
			    id='".$randomId."'
				name='".$name."'
				type='hidden'
				value='".(is_array($this->defaultValue()) ? esc_attr((string) json_encode(array_values($this->defaultValue()))) : Strings::esc_attr($this->defaultValue()))."'
			/>
			" . $this->preview($randomId);
    }

    /**
     * @return bool
     */
    private function multiple(): bool
    {
        if (!empty($this->fieldModel->getMetaField())) {
            switch ($this->fieldModel->getMetaField()->getType()) {
                case MetaFieldModel::IMAGE_SLIDER_TYPE:
                case MetaFieldModel::AUDIO_MULTI_TYPE:
                case MetaFieldModel::GALLERY_TYPE:
                case MetaFieldModel::VIDEO_MULTI_TYPE:
                    return true;
            }
        }

        return false;
    }

    /**
     * @return string
     */
    private function accept(): string
    {
        if (!empty($this->fieldModel->getMetaField())) {
            switch ($this->fieldModel->getMetaField()->getType()) {
                case MetaFieldModel::AUDIO_TYPE:
                case MetaFieldModel::AUDIO_MULTI_TYPE:
                    return 'audio/*';

                case MetaFieldModel::IMAGE_TYPE:
                case MetaFieldModel::GALLERY_TYPE:
                    return 'image/*';

                case MetaFieldModel::VIDEO_TYPE:
                    return 'video/*';
            }
        }

        return '*';
    }

    /**
     * @param string $randomId
     * @return string|null
     */
    private function preview(string $randomId): ?string
    {
        if (empty($this->defaultValue())) {
            return null;
        }

        $defaultValue = $this->defaultValue();

        // decode JSON
        if (JSON::isValid($this->defaultValue())) {
            $defaultValue = json_decode($this->defaultValue(), true);
        }

        if (empty($defaultValue)) {
            return null;
        }

        // render gallery
        if (is_array($defaultValue) && $this->fieldModel->isAMultipleFileField()) {
            $preview  = "<div class='acpt-file-preview'>";
            $preview  .= "<div class='gallery'>";

            foreach ($defaultValue as $value) {
                $wpAttachment = WPAttachmentFactory::create($value);

                if (!$wpAttachment->isEmpty()) {
                    $preview  .= $this->renderAttachment($randomId, $wpAttachment);
                }
            }

            $preview .= "</div>";
            $preview .= "</div>";

            return $preview;
        }

        // render single file (CCT format)
        elseif (is_array($defaultValue) && isset($defaultValue['url']) && isset($defaultValue['attachment_id'])) {
            $wpAttachment = WPAttachmentFactory::create($defaultValue);

            if ($wpAttachment->isEmpty()) {
                return null;
            }

            $preview  = "<div class='acpt-file-preview'>";
            $preview  .= "<div class='gallery'>";
            $preview  .= $this->renderAttachment($randomId, $wpAttachment);
            $preview  .= "</div>";
            $preview  .= "</div>";

            return $preview;
        }

        // render single file (URL/Legacy format)
        elseif (is_string($defaultValue)) {
            $wpAttachment = WPAttachment::fromUrl($defaultValue);

            if ($wpAttachment->isEmpty()) {
                return null;
            }

            return $this->renderAttachment($randomId, $wpAttachment);
        }

        return null;
    }

    /**
     * Renders the attachment preview block.
     *
     * @param string $randomId A unique identifier for the attachment block.
     * @param WPAttachment $wpAttachment An instance of WPAttachment representing the attachment to render.
     * @param int $w the width of the attachment preview.
     * @param int $h the height of the attachment preview.
     * @return string The rendered HTML for the attachment preview.
     */
    private function renderAttachment(string $randomId, WPAttachment $wpAttachment, int $w = 80, int $h = 60): string
    {
        $preview = "";

        if (!$wpAttachment->isEmpty()) {
            $preview  .= "<div class='file'>";
            $preview  .= $wpAttachment->render([
                'w' => $w,
                'h' => $h,
            ]);
            $preview .= "<a data-value='".$wpAttachment->getSrc()."' data-attachment-id='".((int)$wpAttachment->getId())."' data-target='".$randomId."' class='acpt-delete-file' href='#'>Delete</a>";
            $preview .= "</div>";
        }

        return $preview;
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
