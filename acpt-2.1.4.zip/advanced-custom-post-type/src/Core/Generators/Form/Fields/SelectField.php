<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Core\Generators\Meta\AfterAndBeforeFieldGenerator;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\Wordpress\Translator;

class SelectField extends AbstractField
{
    /**
     * @inheritDoc
     */
    public function render(): string
    {
        $empty = (!empty($this->fieldModel->getExtra()['empty'])) ? $this->fieldModel->getExtra()['empty'] : false;
        $value = $this->defaultValue();
        $options = (!empty($this->fieldModel->getExtra()['options'])) ? $this->fieldModel->getExtra()['options'] : [];
        $isMulti = $this->isMulti();

        $multiple = '';
        $fieldName = Strings::esc_attr($this->getIdName());

        if ($isMulti) {
            $fieldName .= "[]";
            $multiple = "multiple";
        }

        $field = "<select
		    ".$this->disabled()."
			".$multiple."
			id='".Strings::esc_attr($this->getIdName())."'
			name='".$fieldName."'
			placeholder='".$this->placeholder()."'
			class='".$this->cssClass()."'
			".$this->required()."
			".$this->appendDataValidateAndConditionalRenderingAttributes()."
		>";

        if ($empty) {
            $field .= '
				<option value="">
			        '.Translator::translate("Select").'
				</option>';
        }

        foreach ($options as $option) {
            $field .= '
				<option 
			        value="'.Strings::esc_attr($option['value']).'"
			        '.($option['value'] == $value ? "selected" : "").'
		        >
			        '.Strings::esc_attr($option['label']).'
				</option>';
        }

        $field .= '</select>';

        if ($this->fieldModel->getMetaField() !== null) {
            return (new AfterAndBeforeFieldGenerator())->generate($this->fieldModel->getMetaField(), $field);
        }

        return $field;
    }

    /**
     * @return bool
     */
    private function isMulti(): bool
    {
        return $this->fieldModel->getMetaField() !== null ? $this->fieldModel->getMetaField()->getType() === MetaFieldModel::SELECT_MULTI_TYPE : false;
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
