<?php

namespace ACPT\Core\Generators\Form\Fields;

class MessageField extends AbstractField
{
    /**
     * @return string
     */
    public function render(): string
    {
        $label   = esc_html($this->fieldModel->getLabel() ?? '');
        $content = wp_kses_post((string)$this->defaultValue());
        $html    = '<div class="acpt-message-field">';
        if ($label !== '') {
            $html .= '<strong class="acpt-message-field__heading">' . $label . '</strong>';
        }
        if ($content !== '') {
            $html .= '<p class="acpt-message-field__body">' . $content . '</p>';
        }
        $html .= '</div>';

        return $html;
    }

    /**
     * @return void
     */
    public function enqueueFieldAssets(): void
    {
    }
}
