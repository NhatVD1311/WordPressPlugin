<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Core\Generators\Meta\AfterAndBeforeFieldGenerator;
use ACPT\Core\Helper\Strings;

class NumberField extends AbstractField
{
    /**
     * @inheritDoc
     */
    public function render(): string
    {
        if ($this->isNested && $this->fieldModel->getMetaField() !== null) {
            $options = [
                'min'  => $this->fieldModel->getMetaField()->getAdvancedOption("min"),
                'max'  => $this->fieldModel->getMetaField()->getAdvancedOption("max"),
                'step' => $this->fieldModel->getMetaField()->getAdvancedOption("step"),
            ];
        } else {
            $options = $this->fieldModel->getExtra();
        }

        // no min/max unless configured (a configured 0 counts): defaulting to 1..100
        // rejected 0 and anything above 100 in the browser (#1354)
        $min = $this->numericOption($options['min'] ?? null);
        $max = $this->numericOption($options['max'] ?? null);
        $step = $this->numericOption($options['step'] ?? null) ?: 1;

        $field = "
			<input
			    ".$this->disabled()."
				id='".Strings::esc_attr($this->getIdName())."'
				name='".Strings::esc_attr($this->getIdName())."'
				placeholder='".$this->placeholder()."'
				value='".$this->defaultValue()."'
				type='number'
				class='".$this->cssClass()."'
				".$this->required()."
				".$this->appendDataValidateAndConditionalRenderingAttributes()."
				".$this->appendMaxMinAndStep($max, $min, $step)."
			/>";

        if ($this->fieldModel->getMetaField() !== null) {
            return (new AfterAndBeforeFieldGenerator())->generate($this->fieldModel->getMetaField(), $field);
        }

        return $field;
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
