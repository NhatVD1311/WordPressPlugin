<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Core\Generators\Meta\AfterAndBeforeFieldGenerator;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\Weights;

class WeightField extends AbstractField
{
    /**
     * @return string
     */
    public function render(): string
    {
        if ($this->isNested && $this->fieldModel->getMetaField() !== null) {
            $options = [
                'min'  => $this->fieldModel->getMetaField()->getAdvancedOption("min"),
                'max'  => $this->fieldModel->getMetaField()->getAdvancedOption("max"),
                'step' => $this->fieldModel->getMetaField()->getAdvancedOption("step"),
            ];
        } else {
            $options = $this->fieldModel->getExtra();
        }

        // no min/max unless configured (a configured 0 counts): the old 0.01 default rejected 0 (#1354)
        $min = $this->numericOption($options['min'] ?? null);
        $max = $this->numericOption($options['max'] ?? null);
        $step = $this->numericOption($options['step'] ?? null) ?: 0.01;

        $field = '
			<div class="acpt-uom">
				<input 
				    '.$this->disabled().'
					placeholder="'.$this->placeholder().'"
					value="'.$this->defaultWeightValue().'"
					type="number"
					id="'.$this->getIdName().'"
					name="'.$this->getIdName().'"
					class="'.$this->cssClass().'"
					'.$this->required().'
					'.$this->appendDataValidateAndConditionalRenderingAttributes().'
					'.$this->appendMaxMinAndStep($max, $min, $step).'
				/>
				'.$this->renderUom($this->defaultWeight(), 'weight', Weights::getList()).'
			</div>
		';

        if ($this->fieldModel->getMetaField() !== null) {
            return (new AfterAndBeforeFieldGenerator())->generate($this->fieldModel->getMetaField(), $field);
        }

        return $field;
    }

    /**
     * @return string|null
     */
    private function defaultWeightValue(): ?string
    {
        $defaultValue = $this->defaultValue();

        if (is_numeric($defaultValue)) {
            return (string)$defaultValue;
        }

        if (is_array($defaultValue) && isset($defaultValue['weightValue'])) {
            return (string)$defaultValue['weightValue'];
        }

        // decode json
        // {"unit": "KILOGRAM", "value": 123}
        $decoded = json_decode($defaultValue, true);

        if (is_array($decoded) && isset($decoded['value'])) {
            return (string)$decoded['value'];
        }

        return null;
    }

    /**
     * @return string
     */
    private function defaultWeight(): string
    {
        $savedWeight = $this->defaultExtraValue("weight");

        if (!empty($savedWeight)) {
            return $savedWeight;
        }

        $defaultValue = $this->defaultValue();

        // decode json
        // {"unit": "KILOGRAM", "value": 123}
        $decoded = json_decode($defaultValue, true);

        if (is_array($decoded) && isset($decoded['unit'])) {
            return (string)$decoded['unit'];
        }

        if (isset($this->fieldModel->getExtra()['defaultValue']) && isset($this->fieldModel->getExtra()['defaultValue']['weight'])) {
            return $this->fieldModel->getExtra()['defaultValue']['weight'];
        }

        return (isset($this->fieldModel->getExtra()['uom'])) ? Strings::esc_attr($this->fieldModel->getExtra()['uom']) : 'KILOGRAM';
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
