<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Core\Generators\Meta\AfterAndBeforeFieldGenerator;
use ACPT\Core\Helper\Lengths;
use ACPT\Core\Helper\Strings;

class LengthField extends AbstractField
{
    /**
     * @inheritDoc
     */
    public function render(): string
    {
        if ($this->isNested && $this->fieldModel->getMetaField() !== null) {
            $options = [
                'min'  => $this->fieldModel->getMetaField()->getAdvancedOption("min"),
                'max'  => $this->fieldModel->getMetaField()->getAdvancedOption("max"),
                'step' => $this->fieldModel->getMetaField()->getAdvancedOption("step"),
            ];
        } else {
            $options = $this->fieldModel->getExtra();
        }

        // no min/max unless configured (a configured 0 counts): the old 0.01 default rejected 0 (#1354)
        $min = $this->numericOption($options['min'] ?? null);
        $max = $this->numericOption($options['max'] ?? null);
        $step = $this->numericOption($options['step'] ?? null) ?: 0.01;

        $field = '
			<div class="acpt-uom">
				<input 
				    '.$this->disabled().'
					placeholder="'.$this->placeholder().'"
					value="'.$this->defaultLengthValue().'"
					type="number"
					id="'.$this->getIdName().'"
					name="'.$this->getIdName().'"
					class="'.$this->cssClass().'"
					'.$this->required().'
					'.$this->appendDataValidateAndConditionalRenderingAttributes().'
					'.$this->appendMaxMinAndStep($max, $min, $step).'
				/>
				'.$this->renderUom($this->defaultLength(), 'length', Lengths::getList()).'
			</div>
		';

        if ($this->fieldModel->getMetaField() !== null) {
            return (new AfterAndBeforeFieldGenerator())->generate($this->fieldModel->getMetaField(), $field);
        }

        return $field;
    }

    /**
     * @return string|null
     */
    private function defaultLengthValue(): ?string
    {
        $defaultValue = $this->defaultValue();

        if (is_numeric($defaultValue)) {
            return (string)$defaultValue;
        }

        if (is_array($defaultValue) && isset($defaultValue['lengthValue'])) {
            return (string)$defaultValue['lengthValue'];
        }

        // decode json
        // {"unit": "METER", "value": 123}
        $decoded = json_decode($defaultValue, true);

        if (is_array($decoded) && isset($decoded['value'])) {
            return (string)$decoded['value'];
        }

        return null;
    }

    /**
     * @return string
     */
    private function defaultLength(): string
    {
        $savedLength = $this->defaultExtraValue("length");

        if (!empty($savedLength)) {
            return $savedLength;
        }

        $defaultValue = $this->defaultValue();

        // decode json
        // {"unit": "METER", "value": 123}
        $decoded = json_decode($defaultValue, true);

        if (is_array($decoded) && isset($decoded['unit'])) {
            return (string)$decoded['unit'];
        }

        if (isset($this->fieldModel->getExtra()['defaultValue']) && isset($this->fieldModel->getExtra()['defaultValue']['length'])) {
            return $this->fieldModel->getExtra()['defaultValue']['length'];
        }

        return (isset($this->fieldModel->getExtra()['uom'])) ? Strings::esc_attr($this->fieldModel->getExtra()['uom']) : 'KILOMETER';
    }

    /**
     * @inheritDoc
     */
    public function enqueueFieldAssets(): void
    {
        // TODO: Implement enqueueFieldAssets() method.
    }
}
