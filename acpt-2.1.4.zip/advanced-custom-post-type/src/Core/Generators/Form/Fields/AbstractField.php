<?php

namespace ACPT\Core\Generators\Form\Fields;

use ACPT\Constants\FormAction;
use ACPT\Constants\MetaTypes;
use ACPT\Constants\Visibility;
use ACPT\Core\Generators\Form\FormGenerator;
use ACPT\Core\Generators\Validation\DataValidateAttributes;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Models\Form\FormModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\Checker\FieldVisibilityChecker;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\PHP\Session;
use ACPT\Utils\Wordpress\Translator;

abstract class AbstractField
{
    /**
     * @var FormFieldModel
     */
    protected FormFieldModel $fieldModel;

    /**
     * @var FormModel
     */
    protected FormModel $formModel;

    /**
     * @var int|null
     */
    protected ?int $postId = null;

    /**
     * @var int|null
     */
    protected ?int $userId = null;

    /**
     * @var int|null
     */
    protected ?int $termId = null;

    /**
     * @var int|string|null
     */
    protected $recordId = null;

    /**
     * @var bool
     */
    protected bool $isNested = false;

    /**
     * @var mixed
     */
    protected $index;

    /**
     * @var MetaFieldModel|null
     */
    protected ?MetaFieldModel $parentField;

    /**
     * @var mixed
     */
    protected $value;

    /**
     * @var array<string, mixed>
     */
    protected array $extra = [];

    /**
     * AbstractField constructor.
     *
     * @param FormModel $formModel
     * @param FormFieldModel $fieldModel
     * @param int|null $postId
     * @param int|null $termId
     * @param int|null $userId
     * @param int|string|null $recordId
     */
    public function __construct(FormModel $formModel, FormFieldModel $fieldModel, ?int $postId = null, ?int $termId = null, ?int $userId = null, $recordId = null)
    {
        $this->fieldModel = $fieldModel;
        $this->formModel = $formModel;
        $this->postId = $postId;
        $this->termId = $termId;
        $this->userId = $userId;
        $this->recordId = $recordId;

        $locationBelong = ($this->formModel->getMetaDatum('fill_meta_location_belong') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_belong')->getValue() : null; // ---> customPostType
        $locationItem = ($this->formModel->getMetaDatum('fill_meta_location_item') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_item')->getValue() : null;

        if ($this->postId === null && $locationBelong === MetaTypes::CUSTOM_POST_TYPE) {
            $this->postId = (int)$locationItem;
        }

        if ($this->termId === null && $locationBelong === MetaTypes::TAXONOMY) {
            $this->termId = (int)$locationItem;
        }

        if ($this->userId === null && $locationBelong === MetaTypes::USER) {
            $this->userId = (int)$locationItem;
        }

        if (
            $this->recordId === null &&
            $formModel->getAction() === FormAction::FILL_TABLE &&
            $formModel->getMetaDatum('fill_table_name') !== null &&
            $formModel->getMetaDatum('fill_table_record') !== null
        ) {
            $tableRecordId  = $this->formModel->getMetaDatum('fill_table_record');
            $this->recordId = $tableRecordId->getValue();
        }

        $this->isNested = false;
    }

    /**
     * @param mixed $value
     */
    public function setValue($value): void
    {
        $this->value = $value;
    }

    /**
     * @param array<string, mixed> $extra
     */
    public function setExtra(array $extra): void
    {
        $this->extra = $extra;
    }

    /**
     * @return MetaFieldModel|null
     */
    public function getParentField(): ?MetaFieldModel
    {
        return $this->parentField;
    }

    /**
     * @param MetaFieldModel|null $parentField
     */
    public function setParentField(?MetaFieldModel $parentField): void
    {
        $this->parentField = $parentField;
    }

    /**
     * @return bool
     */
    public function isNested(): bool
    {
        return $this->isNested;
    }

    /**
     * @param bool $isNested
     */
    public function setIsNested(bool $isNested): void
    {
        $this->isNested = $isNested;
    }

    /**
     * @return mixed
     */
    public function getIndex()
    {
        return $this->index;
    }

    /**
     * @param mixed $index
     */
    public function setIndex($index): void
    {
        $this->index = $index;
    }

    /**
     * @return bool
     */
    public function isVisible(): bool
    {
        if (empty($this->fieldModel->getMetaField())) {
            return true;
        }

        if (empty($this->formModel->getMetaDatum("fill_meta_location_find"))) {
            return true;
        }

        if (empty($this->formModel->getMetaDatum("fill_meta_location_belong"))) {
            return true;
        }

        return FieldVisibilityChecker::check(
            Visibility::IS_BACKEND,
            $this->postId ?? $this->termId ?? $this->userId,
            $this->formModel->getMetaDatum("fill_meta_location_belong")->getValue(),
            $this->fieldModel->getMetaField(),
            [],
            $this->index ?? null,
            null,
            null
        );
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function renderElement(): string
    {
        if (!$this->isDisabled()) {
            $this->enqueueFieldAssets();
            $select2 = (!empty($this->fieldModel->getExtra()['select2'])) ? $this->fieldModel->getExtra()['select2'] : false;

            // Automatically include tom-select is select2 option is enabled
            if ($select2) {
                wp_enqueue_script('tom-select-js', plugins_url('advanced-custom-post-type/assets/vendor/tom-select/tom-select.complete.min.js'), [], '2.4.3', true);
                wp_enqueue_style('tom-select-css', plugins_url('advanced-custom-post-type/assets/vendor/tom-select/tom-select.default.min.css'), [], '2.4.3', 'all');
            }
        }

        $fontSize = $this->fieldModel->getExtra()['fontSize'] ?? "m";
        $isVisible = !$this->isVisible() ? "hidden" : "";
        $fieldId = $this->fieldModel->getMetaField() !== null ? $this->fieldModel->getMetaField()->getId() : null;
        $settings = $this->fieldModel->getSettings();
        $layout = isset($settings['layout']) ? $settings['layout'] : "block";
        $cols = isset($settings['cols']) ? $settings['cols'] : 12;
        $label = $this->fieldModel->getLabel();
        $description = $this->fieldModel->getDescription();
        $required = ($this->fieldModel->isRequired()) ? ' <span class="acpt-required">*</span>' : '';
        $textAlign = $this->fieldModel->getSettings()['alignment'] ?? "left";
        $element = "<div class='col-".$cols."'>";
        $element .= "<div id='".$this->fieldModel->getId()."' data-field-id='".$fieldId."' class='acpt-form-element text-".$textAlign." font-size-".$fontSize." acpt-form-".$layout." ".$isVisible."'>";

        if ($this->isTypographic() || $this->isLayout()) {
            $element .= $this->render();
            $element .= "</div>";
            $element .= "</div>";

            return $element;
        }

        if (!empty($label)) {
            $element .= '<label aria-label="'.$label.'" class="acpt-form-label" for="'.Strings::esc_attr($this->getIdName()).'">'.$label.$required.'</label>';
        }

        $element .= "<input type='hidden' name='".Strings::esc_attr($this->getIdName("type"))."' value='".$this->fieldModel->getType()."' />";
        $element .= "<input type='hidden' name='".Strings::esc_attr($this->getIdName("key"))."' value='".$this->fieldModel->getKey()."' />";

        if ($this->fieldModel->getMetaField() !== null) {
            $element .= "<input type='hidden' name='".Strings::esc_attr($this->getIdName("id"))."' value='".$fieldId."' />";
        }

        $element .= $this->render();
        $element .= $this->renderErrors();

        if (!empty($description)) {
            $element .= '<div id="'.Strings::esc_attr($this->getIdName("description")).'" class="acpt-form-description">'.wp_kses_post($description).'</div>';
        }

        $element .= "</div>";
        $element .= "</div>";

        return $element;
    }

    /**
     * @return string
     */
    protected function required(): string
    {
        return ($this->fieldModel->isRequired()) ? 'required="required"' : '';
    }

    /**
     * @param string|null $label
     * @return string
     */
    protected function getIdName(?string $label = null): string
    {
        // ex: test_repeater[testo][0][value]
        if ($this->isNested && !empty($this->fieldModel->getMetaField()) && !empty($this->fieldModel->getMetaField()->getParentField())) {
            $base = $this->fieldModel->getMetaField()->getParentField()->getDbName().'['.$this->fieldModel->getName().']['.$this->index.']';

            if (!empty($label)) {
                return $base.'['.$label.']';
            }

            return $base.'[value]';
        }

        $base = $this->fieldModel->getName();

        if (!empty($label)) {
            return $base.'_'.$label;
        }

        return $base;
    }

    /**
     * @return string
     */
    protected function cssClass(): string
    {
        $base = (!empty($this->fieldModel->getSettings()['css'])) ? Strings::esc_attr($this->fieldModel->getSettings()['css']) : 'acpt-form-control';

        if ($this->hasErrors()) {
            $base .= ' has-errors';
        }

        if ($this->isDisabled()) {
            $base .= ' disabled';
        }

        $select2 = (!empty($this->fieldModel->getExtra()['select2'])) ? $this->fieldModel->getExtra()['select2'] : false;

        if ($select2) {
            $base .= ' acpt-select2';
        }

        return $base;
    }

    /**
     * @return string|null
     */
    protected function placeholder(): ?string
    {
        return (!empty($this->fieldModel->getExtra()['placeholder'])) ? Strings::esc_attr($this->fieldModel->getExtra()['placeholder']) : null;
    }

    /**
     * @return string
     */
    protected function disabled(): string
    {
        return $this->isDisabled() ? 'disabled="disabled"' : "";
    }

    /**
     * @return bool
     */
    protected function isDisabled(): bool
    {
        return (!empty($this->fieldModel->getExtra()['disabled'])) ? $this->fieldModel->getExtra()['disabled'] : false;
    }

    /**
     * @return bool
     */
    protected function isLayout(): bool
    {
        return $this->fieldModel->getGroup() === "Layout elements";
    }

    /**
     * @return bool
     */
    protected function isTypographic(): bool
    {
        return $this->fieldModel->getGroup() === "Typography elements";
    }

    /**
     * @return mixed|null
     */
    protected function defaultValue()
    {
        if ($this->value) {
            return $this->value;
        }

        // is an ACPT field
        if ($this->fieldModel->getMetaField()) {
            $value = null;
            $belong = $this->fieldModel->getBelong();
            $find = $this->fieldModel->getFind();

            if ($belong !== null && $belong === MetaTypes::OPTION_PAGE && $find !== null) {
                $value = Meta::fetch($find, MetaTypes::OPTION_PAGE, $find.'_'.$this->fieldModel->getMetaField()->getDbName(), true);
            }

            if ($this->postId) {
                $value = Meta::fetch($this->postId, MetaTypes::CUSTOM_POST_TYPE, $this->fieldModel->getMetaField()->getDbName(), true);
            }

            if ($this->termId) {
                $value = Meta::fetch($this->termId, MetaTypes::TAXONOMY, $this->fieldModel->getMetaField()->getDbName(), true);
            }

            if ($this->userId) {
                $value = Meta::fetch($this->userId, MetaTypes::USER, $this->fieldModel->getMetaField()->getDbName(), true);
            }

            if ($value === null && !empty($this->fieldModel->getExtra()['defaultValue'])) {
                $value = $this->fieldModel->getExtra()['defaultValue'];
            }

            return $value;
        }

        return $this->WordPressFieldCurrentValue();
    }

    /**
     * @param string $label
     * @return mixed|null
     */
    protected function defaultExtraValue(string $label)
    {
        if ($this->fieldModel->getMetaField()) {
            $belong = $this->fieldModel->getBelong();
            $find = $this->fieldModel->getFind();

            // get nested fields values
            if ($this->isNested) {
                if (isset($this->extra[$label])) {
                    return $this->extra[$label];
                }

                $data = $this->getParentData();
                $key = Strings::toDBFormat($this->fieldModel->getMetaField()->getName());

                // Field nested in a repeater
                if (
                    isset($data[$key]) &&
                    isset($data[$key][$this->index]) &&
                    isset($data[$key][$this->index][$label])
                ) {
                    return $data[$key][$this->index][$label];
                }

                return null;
            }

            if ($belong !== null && $belong === MetaTypes::OPTION_PAGE && $find !== null) {
                return Meta::fetch($find, MetaTypes::OPTION_PAGE, $find.'_'.$this->fieldModel->getMetaField()->getDbName()."_".$label, true);
            }

            if ($this->postId) {
                return Meta::fetch($this->postId, MetaTypes::CUSTOM_POST_TYPE, $this->fieldModel->getMetaField()->getDbName()."_".$label, true);
            }

            if ($this->termId) {
                return Meta::fetch($this->termId, MetaTypes::TAXONOMY, $this->fieldModel->getMetaField()->getDbName()."_".$label, true);
            }

            if ($this->userId) {
                return Meta::fetch($this->userId, MetaTypes::USER, $this->fieldModel->getMetaField()->getDbName()."_".$label, true);
            }
        }

        return null;
    }

    /**
     * This function fetches the current value of a WP field
     * (ex. Post title, Post content, User email, etc...)
     *
     * @return mixed
     */
    private function WordPressFieldCurrentValue()
    {
        // post field current value
        if (!empty($this->postId)) {
            switch ($this->fieldModel->getType()) {

                // WORDPRESS_POST_THUMBNAIL
                case FormFieldModel::WORDPRESS_POST_THUMBNAIL:
                    return get_the_post_thumbnail_url($this->postId);

                    // WORDPRESS_POST_TITLE
                case FormFieldModel::WORDPRESS_POST_TITLE:
                    return get_the_title($this->postId);

                    // WORDPRESS_POST_CONTENT
                case FormFieldModel::WORDPRESS_POST_CONTENT:
                    return get_the_content(null, false, $this->postId);

                    // WORDPRESS_POST_EXCERPT
                case FormFieldModel::WORDPRESS_POST_EXCERPT:
                    return get_the_excerpt($this->postId);

                    // WORDPRESS_POST_DATE
                case FormFieldModel::WORDPRESS_POST_DATE:
                    return get_the_date('Y-m-d', $this->postId);

                    // WORDPRESS_POST_AUTHOR
                case FormFieldModel::WORDPRESS_POST_AUTHOR:
                    return get_post_field('post_author', $this->postId);
            }
        }

        if (!empty($this->termId)) {
            $term = get_term($this->termId);

            if ($term instanceof \WP_Term) {
                switch ($this->fieldModel->getType()) {
                    case FormFieldModel::WORDPRESS_TERM_NAME:
                        return $term->name;

                    case FormFieldModel::WORDPRESS_TERM_DESCRIPTION:
                        return $term->description;

                    case FormFieldModel::WORDPRESS_TERM_SLUG:
                        return $term->slug;
                }
            }
        }

        // user field current value
        if (!empty($this->userId)) {
            $userData = get_userdata($this->userId);

            if ($userData) {
                switch ($this->fieldModel->getType()) {

                    // WORDPRESS_USER_EMAIL
                    case FormFieldModel::WORDPRESS_USER_EMAIL:
                        return $userData->user_email;

                        // WORDPRESS_USER_FIRST_NAME
                    case FormFieldModel::WORDPRESS_USER_FIRST_NAME:
                        return $userData->first_name;

                        // WORDPRESS_USER_LAST_NAME
                    case FormFieldModel::WORDPRESS_USER_LAST_NAME:
                        return $userData->last_name;

                        // WORDPRESS_USER_USERNAME
                    case FormFieldModel::WORDPRESS_USER_USERNAME:
                        return $userData->display_name;

                        // WORDPRESS_USER_BIO
                    case FormFieldModel::WORDPRESS_USER_BIO:
                        return $userData->description;
                }
            }
        }

        if (!empty($this->fieldModel->getExtra()['defaultValue'])) {
            $defaultValue = $this->fieldModel->getExtra()['defaultValue'];

            // ListField (and any other field whose defaultValue is legitimately an array,
            // not a scalar) would otherwise TypeError here — esc_attr() only accepts ?string.
            return is_array($defaultValue) ? $defaultValue : Strings::esc_attr($defaultValue);
        }

        return null;
    }

    /**
     * @param string $defaultValue
     * @param string $uom
     * @param array<string, array<string, mixed>> $options
     *
     * @return string
     */
    protected function renderUom(string $defaultValue, string $uom, array $options): string
    {
        $defaultValueUom = $defaultValue;
        $render = '<select
				id="'.$this->getIdName().'_'.$uom.'"
				name="'.$this->getIdName().'_'.$uom.'"
				aria-label="'.esc_attr(Translator::translate("Unit of measurement")).'"
				class="'.$this->cssClass().'"
			>';

        foreach ($options as $symbol => $data) {
            $render .= '<option 
				value="'.Strings::esc_attr($symbol).'" 
				'.selected($symbol, $defaultValueUom, false).'
				data-symbol="'.Strings::esc_attr($data['symbol']).'" 
				data-placeholder="0.00" 
				>
					'.esc_html($symbol).'
				</option>';
        }

        $render .= '</select>';

        return $render;
    }

    /**
     * @return mixed
     */
    protected function getParentData()
    {
        // field nested in a repeater
        if ($this->parentField !== null) {
            $key = '';
            $belong = $this->fieldModel->getBelong();
            $find = $this->fieldModel->getFind();

            if ($belong === MetaTypes::OPTION_PAGE) {
                $key .= $find.'_';
            }

            if ($this->parentField->hasParent()) {
                $key .= $this->parentField->getParentField()->getDbName();
            } elseif ($this->parentField->hasParentBlock()) {
                $key .= $this->parentField->getParentBlock()->getMetaField()->getDbName();
            } else {
                $key .= $this->parentField->getDbName();
            }

            if ($belong !== null && $belong === MetaTypes::OPTION_PAGE && $find !== null) {
                return Meta::fetch($find, MetaTypes::OPTION_PAGE, $key, true);
            }

            if ($this->postId) {
                return Meta::fetch($this->postId, MetaTypes::CUSTOM_POST_TYPE, $key, true);
            }

            if ($this->termId) {
                return Meta::fetch($this->termId, MetaTypes::TAXONOMY, $key, true);
            }

            if ($this->userId) {
                return Meta::fetch($this->userId, MetaTypes::USER, $key, true);
            }
        }

        return null;
    }

    /**
     * A numeric field option (min/max/step) as a float, or null when it isn't set.
     * A configured 0 is a real value, unlike with empty().
     *
     * @param mixed $value
     *
     * @return float|null
     */
    protected function numericOption($value): ?float
    {
        return is_numeric($value) ? (float)$value : null;
    }

    /**
     * @param int|float|null $max
     * @param int|float|null $min
     * @param int|float|null $step
     * @return string
     */
    protected function appendMaxMinAndStep($max = null, $min = null, $step = null): string
    {
        $attr = '';

        // compare with null: a 0 limit is a real limit
        if ($min !== null) {
            $attr .= ' min="'.$min.'"';
        }

        if ($max !== null) {
            $attr .= ' max="'.$max.'"';
        }

        if ($step) {
            $attr .= ' step="'.$step.'"';
        }

        return $attr;
    }

    /**
     * @param string|int|null $max
     * @param string|int|null $min
     * @return string
     */
    protected function appendMaxLengthAndMinLength($max = null, $min = null): string
    {
        $attr = '';

        if ($min) {
            $attr .= ' minlength="'.$min.'"';
        }

        if ($max) {
            $attr .= ' maxlength="'.$max.'"';
        }

        return $attr;
    }

    /**
     * @return string|null
     */
    protected function appendDataValidateAndConditionalRenderingAttributes(): ?string
    {
        $attr = '';

        // conditional rules
        if ($this->fieldModel->getMetaField() !== null) {
            $attr .= ' data-conditional-rules-id="'.$this->fieldModel->getMetaField()->getId().'"';

            if ($this->fieldModel->getMetaField()->hasParent()) {
                $attr .= ' data-conditional-rules-field-index="'.$this->getIndex().'"';
            }

            if ($this->fieldModel->getMetaField()->hasParentBlock()) {
                $attr .= ' data-conditional-rules-field-index="'.$this->getIndex().'"';
            }
        }

        // validation rules
        if ($this->fieldModel->canFieldHaveValidationAndLogicRules()) {
            $attr .= DataValidateAttributes::generate(
                $this->fieldModel->getValidationRules(),
                $this->fieldModel->isTextualField(),
                $this->fieldModel->isRequired()
            );
        }

        return $attr;
    }

    /**
     * @return bool
     */
    private function hasErrors(): bool
    {
        if (Session::has(FormGenerator::ERRORS_SESSION_KEY)) {
            return array_key_exists($this->fieldModel->getId(), Session::get(FormGenerator::ERRORS_SESSION_KEY));
        }

        return false;
    }

    /**
     * @return string
     */
    private function renderErrors(): string
    {
        $errorsList = '<ul class="acpt-error-list" id="acpt-error-list-'.$this->fieldModel->getName().'">';

        if (Session::has(FormGenerator::ERRORS_SESSION_KEY)) {
            foreach (Session::get(FormGenerator::ERRORS_SESSION_KEY) as $id => $errors) {
                if ($id === $this->fieldModel->getId()) {
                    if (is_array($errors)) {
                        foreach ($errors as $error) {
                            $errorsList .= '<li>'.$error.'</li>';
                        }
                    }
                }
            }
        }

        $errorsList .= '</ul>';

        return $errorsList;
    }

    /**
     * @param FormFieldModel $fieldModel
     *
     * @return string|null
     * @throws \Exception
     */
    protected function renderSubField(FormFieldModel $fieldModel): ?string
    {
        $class = 'ACPT\\Core\\Generators\\Form\\Fields\\'.$fieldModel->getType().'Field';
        $value = null;

        if (class_exists($class)) {
            /** @var AbstractField $field */
            $field = new $class($this->formModel, $fieldModel, $this->postId, $this->termId, $this->userId);

            if ($fieldModel->getMetaField() !== null) {
                if (!empty($this->postId)) {
                    $value = Meta::fetch($this->postId, MetaTypes::CUSTOM_POST_TYPE, $fieldModel->getMetaField()->getDbName());
                }

                if (!empty($this->termId)) {
                    $value = Meta::fetch($this->termId, MetaTypes::TAXONOMY, $fieldModel->getMetaField()->getDbName());
                }

                if (!empty($this->userId)) {
                    $value = Meta::fetch($this->userId, MetaTypes::USER, $fieldModel->getMetaField()->getDbName());
                }
            }

            if ($value !== '' && $value !== null) {
                $field->setValue($value);
            }

            return $field->renderElement();
        }

        return null;
    }

    /**
     * @return string
     */
    abstract public function render(): string;

    /**
     * @return void
     */
    abstract public function enqueueFieldAssets(): void;
}
