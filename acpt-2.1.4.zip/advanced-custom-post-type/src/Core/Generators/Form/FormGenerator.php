<?php

namespace ACPT\Core\Generators\Form;

use ACPT\Constants\FormAction;
use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Command\HandleFormSubmissionCommand;
use ACPT\Core\Generators\Form\Fields\AbstractField;
use ACPT\Core\Helper\CCTValueNormalizer;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Models\Form\FormModel;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\TableRecord;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\PHP\Serializer;
use ACPT\Utils\PHP\Server;
use ACPT\Utils\PHP\Session;
use ACPT\Utils\PHP\Url;
use ACPT\Utils\Wordpress\Nonce;

class FormGenerator
{
    public const SUCCESS_SESSION_KEY = 'acpt_form_success';
    public const ERRORS_SESSION_KEY = 'acpt_form_errors';

    /**
     * @var FormModel
     */
    private FormModel $formModel;

    /**
     * @var int|null
     */
    private ?int $postId;

    /**
     * @var int|null
     */
    private ?int $userId;

    /**
     * @var int|null
     */
    private ?int $termId;

    /**
     * @var int|string|null
     */
    private $recordId;

    private Request $request;

    /**
     * FormGenerator constructor.
     *
     * @param FormModel $formModel
     * @param Request $request
     * @param int|null $postId
     * @param int|null $termId
     * @param int|null $userId
     * @param int|string|null $recordId
     */
    public function __construct(FormModel $formModel, Request $request, ?int $postId = null, ?int $termId = null, ?int $userId = null, $recordId = null)
    {
        $this->request   = $request;
        $this->formModel = $formModel;
        $this->postId    = $postId;
        $this->userId    = $userId;
        $this->termId    = $termId;
        $this->recordId  = $recordId;

        $locationBelong = ($formModel->getMetaDatum('fill_meta_location_belong') !== null) ? $formModel->getMetaDatum('fill_meta_location_belong')->getValue() : null; // ---> customPostType
        $locationItem = ($formModel->getMetaDatum('fill_meta_location_item') !== null) ? $formModel->getMetaDatum('fill_meta_location_item')->getValue() : null;

        // Autowire the postId, termId and userId
        if ($this->postId === null && $locationBelong === MetaTypes::CUSTOM_POST_TYPE) {
            if ($locationItem === "{current_post}") {
                $locationItem = get_the_ID();
            }

            if (is_numeric($locationItem)) {
                $this->postId = (int)$locationItem;
            }
        }

        if ($this->termId === null && $locationBelong === MetaTypes::TAXONOMY && is_numeric($locationItem)) {
            $this->termId = (int)$locationItem;
        }

        if ($this->userId === null && $locationBelong === MetaTypes::USER && is_numeric($locationItem)) {
            $this->userId = (int)$locationItem;
        }

        if (
            $this->recordId === null &&
            $formModel->getAction() === FormAction::FILL_TABLE &&
            $formModel->getMetaDatum('fill_table_name') !== null &&
            $formModel->getMetaDatum('fill_table_record') !== null
        ) {
            $tableRecordId  = $this->formModel->getMetaDatum('fill_table_record');
            $this->recordId = $tableRecordId->getValue();
        }

        $this->request = $request;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function render(): string
    {
        ob_start();
        Session::start();

        $formSubmission = $this->request->post('acpt_form_submission');
        $formId = $this->request->post('acpt_form_id');

        if (
            $formSubmission === '1' &&
            $formId === $this->formModel->getId()
        ) {
            $savedRedirectTo = $this->formModel->getMetaDatum('redirect_to');
            $savedRedirectToType = $this->formModel->getMetaDatum('redirect_to_type');
            $redirectTo = (!empty($savedRedirectTo)) ? $savedRedirectTo->getValue() : $this->request->post('_wp_http_referer');

            $this->request->unsetPost('acpt_form_submission');
            $this->request->unsetPost('acpt_form_id');
            $this->request->unsetPost('_wp_http_referer');

            $command = new HandleFormSubmissionCommand($this->formModel, $this->request, $this->postId, $this->termId, $this->userId, $this->recordId);
            $submission = $command->execute();

            if ($submission['success']) {
                $outcomeMessage = ($this->formModel->getMetaDatum('outcome_message') !== null) ? $this->formModel->getMetaDatum('outcome_message')->getValue() : "The form was successfully submitted";
                Session::set(self::SUCCESS_SESSION_KEY, [$outcomeMessage]);
            } else {
                $indexedErrors = [];
                foreach ($submission['errors'] as $error) {
                    $errId  = $error['id'];
                    $errMsg = $error['message'];
                    if (!isset($indexedErrors[$errId])) {
                        $indexedErrors[$errId] = $errMsg;
                    } elseif (is_array($indexedErrors[$errId])) {
                        $indexedErrors[$errId][] = $errMsg;
                    } else {
                        $indexedErrors[$errId] = [$indexedErrors[$errId], $errMsg];
                    }
                }
                Session::set(self::ERRORS_SESSION_KEY, $indexedErrors);
            }

            $this->safeRedirect($redirectTo);
        }

        $this->enqueueAssets();

        $form = $this->showGenericFormErrors();
        $form .= $this->renderOpeningFormTag();
        $form .= Nonce::field($this->formModel->getId());
        $form .= '<input type="hidden" name="acpt_form_submission" value="1" />';
        $form .= '<input type="hidden" name="acpt_form_id" value="'.$this->formModel->getId().'" />';
        $form .= '<input type="hidden" name="acpt_form_post_id" value="'.$this->postId.'" />';
        $form .= '<input type="hidden" name="acpt_form_term_id" value="'.$this->termId.'" />';
        $form .= '<input type="hidden" name="acpt_form_user_id" value="'.$this->userId.'" />';
        $form .= '<input type="hidden" name="acpt_form_record_id" value="'.$this->recordId.'" />';
        $form .= '<input type="hidden" name="redirect_to" value="'.$this->formModel->getId().'" />';
        $form .= '<div class="acpt-form">';
        $form .= '<div class="acpt-container">';
        $form .= '<div class="acpt-form-spinner"></div>';

        foreach ($this->formModel->getFields() as $field) {
            $form .= $this->renderField($field);
        }

        $form .= '</div>';
        $form .= '</div>';
        $form .= '</form>';

        $this->flushSession();

        ob_end_clean();

        return $form;
    }

    /**
     * Manage the redirect
     *
     * @param mixed $redirectTo
     */
    private function safeRedirect($redirectTo): void
    {
        if (php_sapi_name() === 'cli') {
            return;
        }

        // if redirectTo is empty, redirect to the referer page
        if (empty($redirectTo)) {
            wp_safe_redirect($this->request->httpReferer());
            exit();
        }

        $theURLContainsSiteUrl = Strings::contains(site_url(), $redirectTo);

        // In case of external redirect, like https://google.com,
        // flush the cache and then redirect
        if (!$theURLContainsSiteUrl) {
            Session::flush(self::SUCCESS_SESSION_KEY);
            Session::flush(self::ERRORS_SESSION_KEY);
            $this->redirectToExternalUrl($redirectTo);
        }

        $redirectTo = str_replace(site_url(), "", (string)$redirectTo);

        // If the redirection is not on the same page,
        // flush the cache and then redirect
        if ($redirectTo !== "") {
            Session::flush(self::SUCCESS_SESSION_KEY);
            Session::flush(self::ERRORS_SESSION_KEY);
        }

        wp_safe_redirect(esc_url(site_url($redirectTo)));
        exit();
    }

    /**
     * @param mixed $redirectTo
     */
    private function redirectToExternalUrl($redirectTo): void
    {
        if (php_sapi_name() === 'cli') {
            return;
        }

        wp_redirect($redirectTo);
        exit();
    }

    /**
     * Display general errors and success messages
     *
     * @return string
     */
    private function showGenericFormErrors()
    {
        $messages = '<div class="acpt-form-messages">';

        if (Session::has(self::SUCCESS_SESSION_KEY)) {
            foreach (Session::get(self::SUCCESS_SESSION_KEY) as $successMessage) {
                $messages .= '<div class="acpt-message acpt-success-message">' .$successMessage. '</div>';
            }
        }

        if (Session::has(self::ERRORS_SESSION_KEY)) {
            foreach (Session::get(self::ERRORS_SESSION_KEY) as $id => $errorMessages) {

                // generic form messages
                if ($id === $this->formModel->getId()) {
                    if (is_array($errorMessages)) {
                        foreach ($errorMessages as $errorMessage) {
                            $messages .= '<div id="'.$id.'" class="acpt-message acpt-error-message">' .$errorMessage. '</div>';
                        }
                    } elseif (is_string($errorMessages)) {
                        $messages .= '<div id="'.$id.'" class="acpt-message acpt-error-message">' .$errorMessages. '</div>';
                    }
                } elseif (Uuid::isV4Valid($id) && is_string($errorMessages)) { // single field messages
                    $messages .= '<div id="'.$id.'" class="acpt-message acpt-error-message">' .$errorMessages. '</div>';
                }
            }
        }

        $messages .= '</div>';

        return $messages;
    }

    /**
     * Flush the session
     */
    private function flushSession(): void
    {
        Session::flush(self::SUCCESS_SESSION_KEY);
        Session::flush(self::ERRORS_SESSION_KEY);
    }

    /**
     * Render the opening form html tag <form>
     *
     * @return string|void
     */
    private function renderOpeningFormTag()
    {
        switch ($this->formModel->getAction()) {
            case FormAction::NONE:
            case FormAction::EMAIL:
            case FormAction::FILL_TABLE:
            case FormAction::FILL_META:
            case FormAction::PHP:
                return '<form id="'.$this->formModel->getKey().'" data-id="'.$this->formModel->getId().'" data-acpt-sync-form action="" method="post" enctype="multipart/form-data">';

            case FormAction::CUSTOM:
                $action = $this->formModel->getMetaDatum('custom_action') !== null ? $this->formModel->getMetaDatum('custom_action')->getValue() : '';
                $method = $this->formModel->getMetaDatum('custom_method') !== null ? $this->formModel->getMetaDatum('custom_method')->getValue() : 'POST';

                return '<form id="'.$this->formModel->getKey().'" data-id="'.$this->formModel->getId().'" data-acpt-custom-form action="'.$action.'" method="'.$method.'" enctype="multipart/form-data">';

            case FormAction::AJAX:
                return '<form id="'.$this->formModel->getKey().'" data-id="'.$this->formModel->getId().'" data-acpt-ajax-form action="">';
        }
    }

    /**
     * @param FormFieldModel $fieldModel
     *
     * @return string|void
     * @throws \Exception
     */
    private function renderField(FormFieldModel $fieldModel)
    {
        $class = 'ACPT\\Core\\Generators\\Form\\Fields\\'.$fieldModel->getType().'Field';
        $value = null;

        if (class_exists($class)) {
            /** @var AbstractField $field */
            $field = new $class($this->formModel, $fieldModel, $this->postId, $this->termId, $this->userId);

            if ($fieldModel->getMetaField() !== null) {
                if (!empty($this->postId)) {
                    $value = Meta::fetch($this->postId, MetaTypes::CUSTOM_POST_TYPE, $fieldModel->getMetaField()->getDbName());
                }

                if (!empty($this->termId)) {
                    $value = Meta::fetch($this->termId, MetaTypes::TAXONOMY, $fieldModel->getMetaField()->getDbName());
                }

                if (!empty($this->userId)) {
                    $value = Meta::fetch($this->userId, MetaTypes::USER, $fieldModel->getMetaField()->getDbName());
                }
            }

            // CCT column canvas fields have metaFieldId = null; fetch existing record value here.
            // Uses FormFieldModel::getType() directly when no backing MetaFieldModel is present.
            if (($value === '' || $value === null) && str_starts_with($fieldModel->getName(), '_acpt_cct_')) {
                $uiType = $fieldModel->getMetaField() !== null
                    ? $fieldModel->getMetaField()->getType()
                    : $fieldModel->getType();
                $value = $this->fetchCCTColumnValue($fieldModel->getName(), $uiType);
            }

            // standalone CCT fields
            if (($value === '' || $value === null) && !empty($this->recordId)) {
                $tableRecordTableValue = $this->formModel->getMetaDatum('fill_table_name');

                if ($tableRecordTableValue !== null) {
                    $tableRecordTableName =  $tableRecordTableValue->getValue();
                    $rawData = TableRecordRepository::fetch($tableRecordTableName, $this->recordId);

                    if (isset($rawData[$fieldModel->getName()])) {
                        $value = CCTValueNormalizer::defaultValue($rawData[$fieldModel->getName()], $fieldModel->getType());
                    }
                }
            }

            if ($value !== '' && $value !== null) {
                $field->setValue($value);
            }

            return $field->renderElement();
        }
    }

    /**
     * Enqueue necessary assets
     *
     * @param mixed $action
     */
    private function enqueueAssets($action = null): void
    {
        $home = get_option('home');
        $pluginsUrl = plugins_url();

        if (Server::isSecure()) {
            $home = Url::secureUrl($home);
            $pluginsUrl = Url::secureUrl($pluginsUrl);
        }

        $belongsTo = $this->formModel->getMetaDatum("fill_meta_location_belong") ? $this->formModel->getMetaDatum("fill_meta_location_belong")->getValue() : null;
        $elementId = $this->postId ?? $this->termId ?? $this->userId ?? $this->recordId ?? null;

        wp_register_script('globals-acpt-run', '', [], '', true);
        wp_enqueue_script('globals-acpt-run');
        wp_add_inline_script('globals-acpt-run', '
            document.globals = {site_url: "'.$home.'", plugins_url: "'.$pluginsUrl.'", rest_nonce: "'.wp_create_nonce('wp_rest').'", rest_url: "'.get_rest_url().'",ajax_url: "'. esc_js(admin_url('admin-ajax.php', 'relative')) .'" };
		');

        // front-end CSS
        // @phpstan-ignore-next-line ternary.alwaysFalse
        wp_register_style('front-end-css', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/css/front-end.css' : 'advanced-custom-post-type/assets/static/css/front-end.min.css'), [], ACPT_PLUGIN_VERSION);
        wp_enqueue_style('front-end-css');
        $this->injectCSSVariables();

        // front-end JS
        // @phpstan-ignore-next-line ternary.alwaysFalse
        wp_register_script('front-end-js', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/front-end.js' : 'advanced-custom-post-type/assets/static/js/front-end.min.js'), ['jquery']);
        wp_enqueue_script('front-end-js');
        wp_scripts()->add_data('front-end-js', 'type', 'module');

        // validation
        // @phpstan-ignore-next-line ternary.alwaysFalse
        wp_register_script('ACPTFormValidator', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/ACPTFormValidator.js' : 'advanced-custom-post-type/assets/static/js/ACPTFormValidator.min.js'));
        wp_enqueue_script('ACPTFormValidator');

        wp_register_script('ACPTFormValidator-run', '', [], '', true);
        wp_enqueue_script('ACPTFormValidator-run');
        wp_add_inline_script('ACPTFormValidator-run', '
			window.addEventListener("load", () => {
			    if(typeof validator === "undefined"){
                  const validator = new ACPTFormValidator("'.$action.'");
                  validator.run();
                }
			});
		');

        // conditional rendering
        if ($elementId !== null && $belongsTo !== null) {

            // @phpstan-ignore-next-line ternary.alwaysFalse
            wp_register_script('ACPTConditionalRules', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/ACPTConditionalRules.js' : 'advanced-custom-post-type/assets/static/js/ACPTConditionalRules.min.js'));
            wp_enqueue_script('ACPTConditionalRules');

            wp_register_script('ACPTConditionalRules-run', '', [], '', true);
            wp_enqueue_script('ACPTConditionalRules-run');
            wp_add_inline_script('ACPTConditionalRules-run', '
			    if(typeof conditionalRules === "undefined"){
				    const conditionalRules = new ACPTConditionalRules("'.Url::fullUrl().'", "'.$action.'", "'.$belongsTo.'", "'.$elementId.'");
				    conditionalRules.run();
				}
			');
        }

        // Custom action form handling
        if ($this->formModel->getAction() === FormAction::CUSTOM) {
            wp_register_script('custom-form-handling', '', [], '', true);
            wp_enqueue_script('custom-form-handling');
            wp_add_inline_script('custom-form-handling', '
					 '.$this->wpAjaxRequest().'
				
					// Custom form submission
					const forms = document.body.querySelectorAll("[data-acpt-custom-form]");
					forms.forEach((form) => {
						form.addEventListener("submit", (e) => {
							e.preventDefault();
							e.stopPropagation();
							
							const formData = new FormData(e.target);
							const dataObject = Object.fromEntries(formData.entries());
							
							// save form submission
							wpAjaxRequest("saveFormSubmissionAction", dataObject);
							
							form.submit();
						});
					});
				');
        }

        // Ajax form handling
        if ($this->formModel->getAction() === FormAction::AJAX) {
            $ajaxAction = $this->formModel->getMetaDatum("ajax_action") !== null ? $this->formModel->getMetaDatum("ajax_action")->getValue() : null;
            $ajaxHandling = $this->formModel->getMetaDatum("ajax_handling") !== null ? $this->formModel->getMetaDatum("ajax_handling")->getValue() : null;

            if ($ajaxAction !== null && $ajaxHandling !== null) {
                wp_register_script('ajax-form-handling', '', [], '', true);
                wp_enqueue_script('ajax-form-handling');
                wp_add_inline_script('ajax-form-handling', '
					 '.$this->wpAjaxRequest().'
				
					// AJAX form submission
					const forms = document.body.querySelectorAll("[data-acpt-ajax-form]");
					forms.forEach((form) => {
						form.addEventListener("submit", (e) => {
							e.preventDefault();
							e.stopPropagation();
							
							const formData = new FormData(e.target);
							const dataObject = Object.fromEntries(formData.entries());
							
							// save form submission
							wpAjaxRequest("saveFormSubmissionAction", dataObject);
							
							// call custom AJAX route
							wpAjaxRequest("'.$ajaxAction.'", dataObject)
				                .then(data => {
				                    '.$ajaxHandling.'
				                })
				            ;
						});
					});
				');
            }
        }
    }

    /**
     * Inject CSS variables
     */
    private function injectCSSVariables(): void
    {
        $id = "css_variables_".$this->formModel->getName();
        $css = (!empty($this->formModel->getMetaDatum("css_variables"))) ? $this->formModel->getMetaDatum("css_variables")->getValue() : null;

        if ($css !== null) {
            $css = Serializer::unserialize($css);
        }

        if (!is_array($css)) {
            return;
        }

        $props = [
            'border_radius',
            'border_thickness',
            'border_color',
            'button_color',
            'error_color',
            'gray_color',
            'input_bg',
            'input_color',
            'label_color',
            'label_font_weight',
            'light_gray_color',
            'primary_color',
            'primary_hover_color',
            'success_color',
            'warning_color',
            'half_gap',
            'gap',
            'font_size_m',
            'font_size_s',
            'font_size_xs',
            'font_size_l',
            'font_size_xl',
        ];

        if (!empty(array_diff(array_keys($css), $props))) {
            return;
        }

        wp_register_style($id, '', [], ACPT_PLUGIN_VERSION, 'all');
        wp_enqueue_style($id);
        wp_add_inline_style($id, "
            :root {
                /* spacing */
                --acpt-half-gap: ".$css['half_gap']['light'].";
                --acpt-gap: ".$css['gap']['light'].";
            
                /* border */
                --acpt-border-thickness: ".$css['border_thickness']['light'].";
                --acpt-border-radius: ".$css['border_radius']['light'].";
            
                /* typography */
                --acpt-label-font-weight: ".$css['label_font_weight']['light'].";
                
                /* font size */
                --acpt-font-size-m: ".$css['font_size_m']['light'].";
                --acpt-font-size-s: ".$css['font_size_s']['light'].";
                --acpt-font-size-xs: ".$css['font_size_xs']['light'].";
                --acpt-font-size-l: ".$css['font_size_l']['light'].";
                --acpt-font-size-xl: ".$css['font_size_xl']['light'].";
            
                /* colors */
                --acpt-primary-color: ".$css['primary_color']['light'].";
                --acpt-primary-hover-color: ".$css['primary_hover_color']['light'].";
                --acpt-success-color: ".$css['success_color']['light'].";
                --acpt-warning-color: ".$css['warning_color']['light'].";
                --acpt-error-color: ".$css['error_color']['light'].";
                --acpt-border-color: ".$css['border_color']['light'].";
                --acpt-input-bg: ".$css['input_bg']['light'].";
                --acpt-label-color: ".$css['label_color']['light'].";
                --acpt-input-color: ".$css['input_color']['light'].";
                --acpt-gray-color: ".$css['gray_color']['light'].";
                --acpt-light-gray-color: ".$css['light_gray_color']['light'].";
                --acpt-button-color: ".$css['button_color']['light'].";
            }
            
            @media (prefers-color-scheme: dark) {
                :root {
                    /* spacing */
                    --acpt-half-gap: ".$css['half_gap']['dark'].";
                    --acpt-gap: ".$css['gap']['dark'].";
                    
                    /* border */
                    --acpt-border-thickness: ".$css['border_thickness']['dark'].";
                    --acpt-border-radius: ".$css['border_radius']['dark'].";
                    
                    /* typography */
                    --acpt-label-font-weight: ".$css['label_font_weight']['dark'].";
                    
                    /* font size */
                    --acpt-font-size-m: ".$css['font_size_m']['dark'].";
                    --acpt-font-size-s: ".$css['font_size_s']['dark'].";
                    --acpt-font-size-xs: ".$css['font_size_xs']['dark'].";
                    --acpt-font-size-l: ".$css['font_size_l']['dark'].";
                    --acpt-font-size-xl: ".$css['font_size_xl']['dark'].";
                
                    /* colors */
                    --acpt-primary-color: ".$css['primary_color']['dark'].";
                    --acpt-primary-hover-color: ".$css['primary_hover_color']['dark'].";
                    --acpt-success-color: ".$css['success_color']['dark'].";
                    --acpt-warning-color: ".$css['warning_color']['dark'].";
                    --acpt-error-color: ".$css['error_color']['dark'].";
                    --acpt-border-color: ".$css['border_color']['dark'].";
                    --acpt-input-bg: ".$css['input_bg']['dark'].";
                    --acpt-label-color: ".$css['label_color']['dark'].";
                    --acpt-input-color: ".$css['input_color']['dark'].";
                    --acpt-gray-color: ".$css['gray_color']['dark'].";
                    --acpt-light-gray-color: ".$css['light_gray_color']['dark'].";
                    --acpt-button-color: ".$css['button_color']['dark'].";
                }
            }
        ");
    }

    /**
     * Resolve a CCT column value for a FILL_META form field whose name encodes
     * the table and column: `_acpt_cct_{tableName}_{columnName}`.
     *
     * Looks up the record linked to the current post/term/user via the junction
     * table, then normalises the raw value to the shape the field renderer expects.
     *
     * @param string $fieldName  FormFieldModel::getName() — must start with `_acpt_cct_`.
     * @param string $uiType     MetaFieldModel::*_TYPE constant (from the backing metaField).
     * @return mixed
     */
    private function fetchCCTColumnValue(string $fieldName, string $uiType)
    {
        $withoutPrefix = substr($fieldName, strlen('_acpt_cct_'));

        try {
            $tables = TableRepository::get();

            foreach ($tables as $table) {
                $tableName = $table->getName();
                if (!str_starts_with($withoutPrefix, $tableName . '_')) {
                    continue;
                }
                $columnName = substr($withoutPrefix, strlen($tableName) + 1);
                if (!$table->hasColumn($columnName)) {
                    break;
                }

                $locationRule  = null;
                $locationValue = null;

                if (!empty($this->postId)) {
                    $locationRule  = TableRecord::CONTEXT_POST;
                    $locationValue = (string)$this->postId;
                } elseif (!empty($this->termId)) {
                    $locationRule  = TableRecord::CONTEXT_TERM;
                    $locationValue = (string)$this->termId;
                } elseif (!empty($this->userId)) {
                    $locationRule  = TableRecord::CONTEXT_USER;
                    $locationValue = (string)$this->userId;
                }

                if ($locationRule !== null) {
                    $recordId = TableRecordRepository::getRecordIdByLocation($tableName, $locationRule, $locationValue);
                    if ($recordId !== null) {
                        $rawData = TableRecordRepository::fetch($tableName, $recordId);
                        if (isset($rawData[$columnName])) {
                            return CCTValueNormalizer::defaultValue($rawData[$columnName], $uiType);
                        }
                    }
                }
                break;
            }
        } catch (\Exception $e) {
            do_action('acpt/error', $e);
        }

        return null;
    }

    /**
     * @return string
     */
    private function wpAjaxRequest()
    {
        return '
			/**
		     *
		     * @param action
		     * @param data
		     * @return {Promise<any>}
		     */
		    const wpAjaxRequest = async (action, data) => {
		
		        let formData;
		        formData = (data instanceof FormData) ? data : new FormData();
		        formData.append("action", action);
		        formData.append("data", JSON.stringify(data));
		
		        const baseAjaxUrl = (typeof ajaxurl === "string") ? ajaxurl : "/wp-admin/admin-ajax.php";
		
		        let response = await fetch(baseAjaxUrl, {
		            method: "POST",
		            body: formData
		        });
		
		        return await response.json();
		    };
		';
    }
}
