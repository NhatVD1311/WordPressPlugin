<?php

namespace ACPT\Core\Generators;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Models\Meta\MetaBoxModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Utils\PHP\Url;
use ACPT\Utils\Wordpress\Posts;
use ACPT\Utils\Wordpress\Terms;
use ACPT\Utils\Wordpress\Translator;
use ACPT\Utils\Wordpress\Users;

/**
 * *************************************************
 * AbstractGenerator class
 * *************************************************
 *
 * @author Mauro Cassani
 * @link https://github.com/mauretto78/
 */
abstract class AbstractGenerator
{
    public const NONCE_FIELD_NAME = 'acpt_nonce';

    /**
     * Helper method, that attaches a passed function to the 'init' WP action
     * @param callable $cb callback function.
     */
    protected function init(callable $cb): void
    {
        add_action("init", $cb);
    }

    /**
     * @param callable $cb
     */
    protected function postTypeLink(callable $cb): void
    {
        add_filter("post_type_link", $cb, 10, 2);
    }

    /**
     * Helper method, that attaches a passed function to the 'admin_init' WP action
     * @param callable $cb callback function.
     */
    protected function adminInit(callable $cb): void
    {
        add_action("admin_init", $cb);
    }

    /**
     * @param callable $cb
     */
    protected function woocommerceProductDataTabs(callable $cb): void
    {
        add_filter('woocommerce_product_data_tabs', $cb);
    }

    /**
     * @param callable $cb
     */
    protected function woocommerceProductDataPanels(callable $cb): void
    {
        add_filter('woocommerce_product_data_panels', $cb);
    }

    /**
     * @param callable $cb
     */
    protected function woocommerceProcessProductMeta(callable $cb): void
    {
        add_filter('woocommerce_process_product_meta', $cb);
    }

    /**
     * @param callable $cb
     */
    protected function woocommerceProductTabs(callable $cb): void
    {
        add_filter('woocommerce_product_tabs', $cb);
    }

    /**
     * @param callable $cb
     */
    protected function adminHead(callable $cb): void
    {
        add_action('admin_head', $cb);
    }

    /**
     * Enqueue JS scripts
     *
     * @param string $action
     */
    public function enqueueScripts(string $action): void
    {
        $pagenow = Url::pagenow();

        $belongsTo = null;
        $elementId = null;

        switch ($pagenow) {
            case "profile.php":
                if (function_exists('wp_get_current_user')) {
                    $elementId = wp_get_current_user()->ID;
                }
                $belongsTo = MetaTypes::USER;
                break;

            case "user-edit.php":
                $elementId = $_GET['user_id'] ?? null;
                $belongsTo = MetaTypes::USER;
                break;

            case "comment.php":
                $elementId = $_GET['c'] ?? null;
                $belongsTo = MetaTypes::COMMENT;
                break;

            case "admin.php":
                $elementId = $_GET['page'] ?? null;
                $belongsTo = MetaTypes::OPTION_PAGE;
                break;

            case "post-new.php":
            case "post.php":
                $elementId = $_GET['post'] ?? 'post-new';
                $belongsTo = MetaTypes::CUSTOM_POST_TYPE;
                break;

            case "edit-tags.php":
                $elementId = $_GET['taxonomy'] ?? null;
                $belongsTo = MetaTypes::TAXONOMY;
                break;

            case "term.php":
                $elementId = $_GET['tag_ID'] ?? null;
                $belongsTo = MetaTypes::TAXONOMY;
                break;

        }

        // validation
        // @phpstan-ignore-next-line ternary.alwaysFalse
        wp_register_script('ACPTFormValidator', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/ACPTFormValidator.js' : 'advanced-custom-post-type/assets/static/js/ACPTFormValidator.min.js'));
        wp_enqueue_script('ACPTFormValidator');

        wp_register_script('ACPTFormValidator-run', '', [], '', true);
        wp_enqueue_script('ACPTFormValidator-run');
        wp_add_inline_script('ACPTFormValidator-run', '
			window.addEventListener("load", () => {
			    if(typeof validator === "undefined"){
                  const validator = new ACPTFormValidator("'.$action.'");
                  validator.run();
                }
			});
		');

        // conditional rendering
        if ($elementId !== null && $belongsTo !== null) {

            // @phpstan-ignore-next-line ternary.alwaysFalse
            wp_register_script('ACPTConditionalRules', plugins_url(ACPT_DEV_MODE ? 'advanced-custom-post-type/assets/static/js/ACPTConditionalRules.js' : 'advanced-custom-post-type/assets/static/js/ACPTConditionalRules.min.js'));
            wp_enqueue_script('ACPTConditionalRules');

            wp_register_script('ACPTConditionalRules-run', '', [], '', true);
            wp_enqueue_script('ACPTConditionalRules-run');
            wp_add_inline_script('ACPTConditionalRules-run', '
			    if(typeof conditionalRules === "undefined"){
				    const conditionalRules = new ACPTConditionalRules("'.Url::fullUrl().'", "'.$action.'", "'.$belongsTo.'", "'.$elementId.'");
				    conditionalRules.run();
				}
			');
        }
    }

    /**
     * This method is used by CPT and Comment meta field generators
     *
     * @param MetaFieldModel $fieldModel
     *
     * @return array<string, mixed>
     */
    protected function generateMetaBoxFieldArray(MetaFieldModel $fieldModel): array
    {
        $options = [];

        foreach ($fieldModel->getOptions() as $optionModel) {
            $options[] = [
                'label' => $optionModel->getLabel(),
                'value' => $optionModel->getValue(),
            ];
        }

        $relations = [];
        $children = [];

        if ($fieldModel->hasChildren()) {
            foreach ($fieldModel->getChildren() as $childFieldModel) {
                $children[] = $this->generateMetaBoxFieldArray($childFieldModel);
            }
        }

        $advancedOptions = [];

        foreach ($fieldModel->getAdvancedOptions() as $advancedOptionModel) {
            if ($advancedOptionModel->isPlaceholder()) {
                continue;
            }

            $advancedOptions[] = [
                'key' => $advancedOptionModel->getKey(),
                'value' => $advancedOptionModel->getValue(),
            ];
        }

        $validationRules = [];

        foreach ($fieldModel->getValidationRules() as $validationRuleModel) {
            $validationRules[] = [
                'condition' => $validationRuleModel->getCondition(),
                'value' => $validationRuleModel->getValue(),
            ];
        }

        $blocks = [];

        foreach ($fieldModel->getBlocks() as $blockModel) {
            $nestedFields = [];

            foreach ($blockModel->getFields() as $nestedFieldModel) {
                $nestedFields[] = $this->generateMetaBoxFieldArray($nestedFieldModel);
            }

            $blocks[] = [
                'id' => $blockModel->getId(),
                'name' => $blockModel->getName(),
                'label' => $blockModel->getLabel(),
                'fields' => $nestedFields
            ];
        }

        return [
            'id' => $fieldModel->getId(),
            'type' => $fieldModel->getType(),
            'name' => $fieldModel->getName(),
            'defaultValue' => $fieldModel->getDefaultValue(),
            'description' => $fieldModel->getDescription(),
            'isRequired' => $fieldModel->isRequired(),
            'isShowInArchive' => $fieldModel->isShowInArchive(),
            'sort' => $fieldModel->getSort(),
            'options' => $options,
            'relations' => $relations,
            'children' => $children,
            'advancedOptions' => $advancedOptions,
            'validationRules' => $validationRules,
            'blocks' => $blocks,
        ];
    }

    /**
     * This method is used to generate quick edit fields
     *
     * @param string $key
     * @param string $label
     * @param mixed $value
     * @param MetaFieldModel $metaBoxFieldModel
     *
     * @return string
     */
    protected static function generateQuickEditField(string $key, string $label, $value, MetaFieldModel $metaBoxFieldModel): string
    {
        $return = '<fieldset class="inline-edit-col-right" id="#edit-'. $key.'">';
        $return .= '<input type="hidden" name="meta_fields[]" value="'. $key.'">';
        $return .= '<input type="hidden" name="meta_fields[]" value="'. $key.'_type">';
        $return .= '<input type="hidden" name="meta_fields[]" value="'. $key.'_id">';
        $return .= '<input type="hidden" name="'. $key.'_type" value="'. $metaBoxFieldModel->getType().'">';
        $return .= '<input type="hidden" name="'. $key.'_required" value="'. $metaBoxFieldModel->isRequired() .'">';
        $return .= '<input type="hidden" name="'. $key.'_id" value="'. $metaBoxFieldModel->getId() .'">';
        $return .= '<div class="inline-edit-col">';
        $return .= '<label>';
        $return .= '<span class="title">'.$label.'</span>';
        $return .= '<span class="input-text-wrap">';

        switch ($metaBoxFieldModel->getType()) {

            // TOOGLE
            case MetaFieldModel::TOGGLE_TYPE:
                $return .= '<div style="position: relative; top: 6px;">';
                $return .= '<label class="acpt-switch">';
                $return .= '<input type="checkbox" name="'.$key.'" value="1" '.checked(1, $value, false).'>';
                $return .= '<span class="slider round"></span>';
                $return .= '</label>';
                $return .= '</div>';
                break;

                // CHECKBOX
            case MetaFieldModel::CHECKBOX_TYPE:
                $checkbox = '<div data-acpt-column="column-'. $key. '">';

                foreach ($metaBoxFieldModel->getOptions() as $index => $option) {
                    $id = $key . "_" . $index;
                    $checked = (is_array($value) && in_array($option->getValue(), $value)) ? "checked='checked'" : "";
                    $checkbox .= '<div style="display: flex; gap: 5px; align-content: center; align-items: center; flex-wrap: wrap;">';
                    $checkbox .= '<input id="'.$id.'" name="'. $key. '[]" value="'.$option->getValue().'" type="checkbox" '.$checked.'>';
                    $checkbox .= '<label for="'.$id.'">'.$option->getLabel().'</label>';
                    $checkbox .= '</div>';
                }

                $checkbox .= '</div>';
                $return .= $checkbox;
                break;

                // COLOR
            case MetaFieldModel::COLOR_TYPE:
                $return .= '<input type="color" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // DATE_TYPE
            case MetaFieldModel::DATE_TYPE:
                $return .= '<input type="date" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // DATE_TIME_TYPE
            case MetaFieldModel::DATE_TIME_TYPE:
                $return .= '<input type="datetime-local" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // EMAIL_TYPE
            case MetaFieldModel::EMAIL_TYPE:
                $return .= '<input type="email" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // NUMBER_TYPE
            case MetaFieldModel::NUMBER_TYPE:
                $return .= '<input type="number" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // PASSWORD
            case MetaFieldModel::PASSWORD_TYPE:
                $return .= '<input type="password" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" >';
                break;

                // POST_OBJECT
            case MetaFieldModel::POST_OBJECT_TYPE:
            case MetaFieldModel::POST_OBJECT_MULTI_TYPE:

                if ($metaBoxFieldModel->getType() === MetaFieldModel::POST_OBJECT_TYPE) {
                    $fieldName = $key;
                } else {
                    $fieldName = $key."[]";
                }

                $postList = self::postTypeList($metaBoxFieldModel);

                // @phpstan-ignore-next-line function.alreadyNarrowedType
                if (is_array($postList)) {
                    $multiple = ($metaBoxFieldModel->getType() === MetaFieldModel::POST_OBJECT_MULTI_TYPE) ? 'multiple' : '';
                    $style = ($metaBoxFieldModel->getType() === MetaFieldModel::POST_OBJECT_MULTI_TYPE) ? 'width: 100%;' : '';
                    $select = '<select name="'. $fieldName. '" data-acpt-column="column-'. $key. '" class="" '.$multiple.' style="'.$style.'">';
                    $selected = '';

                    foreach ($postList as $element) {
                        $select .= '<optgroup label="'.$element['postType'].'">';

                        foreach ($element['posts'] as $id => $post) {
                            if ($metaBoxFieldModel->getType() === MetaFieldModel::POST_OBJECT_TYPE) {
                                $selected = selected($value, $id, false);
                            } else {
                                if (is_array($value)) {
                                    $selected = selected(in_array($id, $value), true, false);
                                }
                            }

                            $select .= '<option '.$selected.' value="'.$id.'">'.esc_html($post).'</option>';
                        }

                        $select .= '</optgroup>';
                    }

                    $select .= '</select>';
                    $return .= $select;
                }

                break;

                // RADIO_TYPE
            case MetaFieldModel::RADIO_TYPE:

                $radio = '<div data-acpt-column="column-'. $key. '">';

                foreach ($metaBoxFieldModel->getOptions() as $index => $option) {
                    $id = $key . "_" . $index;
                    $radio .= '<div style="display: flex; gap: 5px; align-content: center; align-items: center; flex-wrap: wrap;">';
                    $radio .= '<input id="'.$id.'" name="'. $key. '" value="'.$option->getValue().'" type="radio" '.checked($value, $option->getValue(), false).'>';
                    $radio .= '<label for="'.$id.'">'.$option->getLabel().'</label>';
                    $radio .= '</div>';
                }

                $radio .= '</div>';
                $return .= $radio;
                break;

                // SELECT_TYPE
                // SELECT_MULTI_TYPE
            case MetaFieldModel::SELECT_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:

                if ($metaBoxFieldModel->getType() === MetaFieldModel::SELECT_TYPE) {
                    $fieldName = $key;
                } else {
                    $fieldName = $key."[]";
                }

                $multiple = ($metaBoxFieldModel->getType() === MetaFieldModel::SELECT_MULTI_TYPE) ? 'multiple' : '';
                $style = ($metaBoxFieldModel->getType() === MetaFieldModel::SELECT_MULTI_TYPE) ? 'width: 100%;' : '';
                $select = '<select name="'. $fieldName. '" data-acpt-column="column-'. $key. '" class="" '.$multiple.' style="'.$style.'">';

                if (!$multiple) {
                    $select .= '<option value="">'.Translator::translate("--Select--").'</option>';
                }

                $selected = '';

                foreach ($metaBoxFieldModel->getOptions() as $option) {
                    if ($metaBoxFieldModel->getType() === MetaFieldModel::SELECT_TYPE) {
                        $selected = selected($value, $option->getValue(), false);
                    } else {
                        if (is_array($value)) {
                            $selected = selected(in_array($option->getValue(), $value), true, false);
                        }
                    }

                    $select .= '<option '.$selected.' value="'.$option->getValue().'">'.$option->getLabel().'</option>';
                }

                $select .= '</select>';
                $return .= $select;
                break;

                // TERM_OBJECT
            case MetaFieldModel::TERM_OBJECT_TYPE:
            case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:

                if ($metaBoxFieldModel->getType() === MetaFieldModel::TERM_OBJECT_TYPE) {
                    $fieldName = $key;
                } else {
                    $fieldName = $key."[]";
                }

                $postList = self::termList($metaBoxFieldModel);

                // @phpstan-ignore-next-line function.alreadyNarrowedType
                if (is_array($postList)) {
                    $multiple = ($metaBoxFieldModel->getType() === MetaFieldModel::TERM_OBJECT_MULTI_TYPE) ? 'multiple' : '';
                    $style = ($metaBoxFieldModel->getType() === MetaFieldModel::TERM_OBJECT_MULTI_TYPE) ? 'width: 100%;' : '';
                    $select = '<select name="'. $fieldName. '" data-acpt-column="column-'. $key. '" class="" '.$multiple.' style="'.$style.'">';

                    if (!$multiple) {
                        $select .= '<option value="">'.Translator::translate("--Select--").'</option>';
                    }

                    $selected = '';

                    foreach ($postList as $element) {
                        $select .= '<optgroup label="'.$element['taxonomy'].'">';

                        foreach ($element['terms'] as $id => $post) {
                            if ($metaBoxFieldModel->getType() === MetaFieldModel::TERM_OBJECT_TYPE) {
                                $selected = selected($value, $id, false);
                            } else {
                                if (is_array($value)) {
                                    $selected = selected(in_array($id, $value), true, false);
                                }
                            }

                            $select .= '<option '.$selected.' value="'.$id.'">'.esc_html($post).'</option>';
                        }

                        $select .= '</optgroup>';
                    }

                    $select .= '</select>';
                    $return .= $select;
                }

                break;

                // TEXTAREA_TYPE
            case MetaFieldModel::TEXTAREA_TYPE:
                $return .= '<textarea name="'. $key. '" data-acpt-column="column-'. $key. '" class="" rows="5">'. $value.'</textarea>';
                break;

                // TIME_TYPE
            case MetaFieldModel::TIME_TYPE:
                $return .= '<input type="time" name="'. $key. '" data-acpt-column="column-'. $key. '" class="" value="'. $value.'">';
                break;

                // USER
            case MetaFieldModel::USER_TYPE:
            case MetaFieldModel::USER_MULTI_TYPE:

                if ($metaBoxFieldModel->getType() === MetaFieldModel::USER_TYPE) {
                    $fieldName = $key;
                } else {
                    $fieldName = $key."[]";
                }

                $userList = self::userList($metaBoxFieldModel);

                // @phpstan-ignore-next-line function.alreadyNarrowedType
                if (is_array($userList)) {
                    $multiple = ($metaBoxFieldModel->getType() === MetaFieldModel::USER_MULTI_TYPE) ? 'multiple' : '';
                    $style = ($metaBoxFieldModel->getType() === MetaFieldModel::USER_MULTI_TYPE) ? 'width: 100%;' : '';
                    $select = '<select name="'. $fieldName. '" data-acpt-column="column-'. $key. '" class="" '.$multiple.' style="'.$style.'">';

                    if (!$multiple) {
                        $select .= '<option value="">'.Translator::translate("--Select--").'</option>';
                    }

                    $selected = '';

                    foreach ($userList as $id => $user) {
                        if ($metaBoxFieldModel->getType() === MetaFieldModel::USER_TYPE) {
                            $selected = selected($value, $id, false);
                        } else {
                            if (is_array($value)) {
                                $selected = selected(in_array($id, $value), true, false);
                            }
                        }

                        $select .= '<option '.$selected.' value="'.$id.'">'.esc_html($user).'</option>';
                    }

                    $select .= '</select>';

                    $return .= $select;
                }

                break;

            default:
                if (!is_string($value)) {
                    $value = null;
                }

                $return .= '<input type="text" name="'. $key .'" data-acpt-column="column-'. $key.'" class="" value="'. $value .'">';
        }

        $return .= '</span>';
        $return .= '</label>';
        $return .= '</div>';
        $return .= '</fieldset>';

        return $return;
    }

    /**
     * Generates a quick-edit fieldset for a single CCT column.
     *
     * @param string           $tableName
     * @param TableColumnModel $column
     * @param mixed            $value
     *
     * @return string
     */
    protected static function generateQuickEditCCTField(string $tableName, TableColumnModel $column, $value): string
    {
        $columnName = $column->getName();
        $label      = $column->getLabel();
        $fieldName  = 'cct_fields[' . $tableName . '][' . $columnName . ']';
        $dataAttr   = 'data-acpt-cct-column="' . esc_attr($tableName . '::' . $columnName) . '"';

        $return  = '<fieldset class="inline-edit-col-right" id="#cct-edit-' . esc_attr($tableName . '-' . $columnName) . '">';
        $return .= '<input type="hidden" name="cct_column_map[]" value="' . esc_attr($tableName . '::' . $columnName) . '">';
        $return .= '<div class="inline-edit-col">';
        $return .= '<label>';
        $return .= '<span class="title">' . esc_html($label) . '</span>';
        $return .= '<span class="input-text-wrap">';

        switch ($column->getUiField()->type) {

            case MetaFieldModel::TOGGLE_TYPE:
                $return .= '<div style="position: relative; top: 6px;">';
                $return .= '<label class="acpt-switch">';
                $return .= '<input type="checkbox" name="' . $fieldName . '" ' . $dataAttr . ' value="1" ' . checked(1, $value, false) . '>';
                $return .= '<span class="slider round"></span>';
                $return .= '</label>';
                $return .= '</div>';
                break;

            case MetaFieldModel::CHECKBOX_TYPE:
                $checkbox = '<div ' . $dataAttr . '>';
                foreach ($column->getUiField()->options as $index => $option) {
                    $id       = esc_attr($tableName . '_' . $columnName . '_' . $index);
                    $checked  = (is_array($value) && in_array($option->value, $value)) ? "checked='checked'" : "";
                    $checkbox .= '<div style="display: flex; gap: 5px; align-content: center; align-items: center; flex-wrap: wrap;">';
                    $checkbox .= '<input id="' . $id . '" name="' . $fieldName . '[]" value="' . esc_attr((string)$option->value) . '" type="checkbox" ' . $checked . '>';
                    $checkbox .= '<label for="' . $id . '">' . esc_html((string)$option->label) . '</label>';
                    $checkbox .= '</div>';
                }
                $checkbox .= '</div>';
                $return   .= $checkbox;
                break;

            case MetaFieldModel::COLOR_TYPE:
                $return .= '<input type="color" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            case MetaFieldModel::DATE_TYPE:
                $return .= '<input type="date" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            case MetaFieldModel::DATE_TIME_TYPE:
                $return .= '<input type="datetime-local" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            case MetaFieldModel::EMAIL_TYPE:
                $return .= '<input type="email" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            case MetaFieldModel::NUMBER_TYPE:
            case MetaFieldModel::RANGE_TYPE:
                $return .= '<input type="number" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            case MetaFieldModel::PASSWORD_TYPE:
                $return .= '<input type="password" name="' . $fieldName . '" ' . $dataAttr . '>';
                break;

            case MetaFieldModel::RADIO_TYPE:
                $radio = '<div ' . $dataAttr . '>';
                foreach ($column->getUiField()->options as $index => $option) {
                    $id     = esc_attr($tableName . '_' . $columnName . '_' . $index);
                    $radio .= '<div style="display: flex; gap: 5px; align-content: center; align-items: center; flex-wrap: wrap;">';
                    $radio .= '<input id="' . $id . '" name="' . $fieldName . '" value="' . esc_attr((string)$option->value) . '" type="radio" ' . checked($value, $option->value, false) . '>';
                    $radio .= '<label for="' . $id . '">' . esc_html((string)$option->label) . '</label>';
                    $radio .= '</div>';
                }
                $radio  .= '</div>';
                $return .= $radio;
                break;

            case MetaFieldModel::SELECT_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:
                $isMulti   = $column->getUiField()->type === MetaFieldModel::SELECT_MULTI_TYPE;
                $inputName = $isMulti ? $fieldName . '[]' : $fieldName;
                $multiple  = $isMulti ? 'multiple' : '';
                $style     = $isMulti ? 'width: 100%;' : '';
                $select    = '<select name="' . $inputName . '" ' . $dataAttr . ' ' . $multiple . ' style="' . $style . '">';
                if (!$isMulti) {
                    $select .= '<option value="">' . Translator::translate('--Select--') . '</option>';
                }
                foreach ($column->getUiField()->options as $option) {
                    if ($isMulti) {
                        $selected = (is_array($value) && in_array($option->value, $value)) ? 'selected="selected"' : '';
                    } else {
                        $selected = selected($value, $option->value, false);
                    }
                    $select .= '<option ' . $selected . ' value="' . esc_attr((string)$option->value) . '">' . esc_html((string)$option->label) . '</option>';
                }
                $select  .= '</select>';
                $return  .= $select;
                break;

            case MetaFieldModel::TEXTAREA_TYPE:
                $return .= '<textarea name="' . $fieldName . '" ' . $dataAttr . ' rows="5">' . esc_textarea((string)$value) . '</textarea>';
                break;

            case MetaFieldModel::TIME_TYPE:
                $return .= '<input type="time" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr((string)$value) . '">';
                break;

            default:
                if (!is_string($value)) {
                    $value = '';
                }
                $return .= '<input type="text" name="' . $fieldName . '" ' . $dataAttr . ' value="' . esc_attr($value) . '">';
        }

        $return .= '</span>';
        $return .= '</label>';
        $return .= '</div>';
        $return .= '</fieldset>';

        return $return;
    }

    /**
     * @param MetaFieldModel $fieldModel
     *
     * @return array<mixed>
     */
    private static function postTypeList(MetaFieldModel $fieldModel): array
    {
        $postQuery = [];

        if ($fieldModel->getAdvancedOption('filter_post_type')) {
            $postQuery['post_type'] = $fieldModel->getAdvancedOption('filter_post_type');
        }

        if ($fieldModel->getAdvancedOption('filter_post_status')) {
            $postQuery['post_status'] = $fieldModel->getAdvancedOption('filter_post_status');
        }

        if ($fieldModel->getAdvancedOption('filter_taxonomy')) {
            $postQuery['taxonomy'] = $fieldModel->getAdvancedOption('filter_taxonomy');
        }

        return Posts::getList($postQuery);
    }

    /**
     * @param MetaFieldModel $fieldModel
     *
     * @return array<mixed>
     */
    private static function termList(MetaFieldModel $fieldModel): array
    {
        $termQuery = [];

        if ($fieldModel->getAdvancedOption('filter_taxonomy')) {
            $termQuery['taxonomy'] = $fieldModel->getAdvancedOption('filter_taxonomy');
        }

        return Terms::getList($termQuery);
    }

    /**
     * @param MetaFieldModel $fieldModel
     *
     * @return array<mixed>
     */
    private static function userList(MetaFieldModel $fieldModel): array
    {
        $userQuery = [];

        if ($fieldModel->getAdvancedOption('filter_role')) {
            $userQuery['role'] = $fieldModel->getAdvancedOption('filter_role');
        }

        return Users::getList($userQuery);
    }

    /**
     * @param string $postTypeName
     * @return string
     */
    protected function getPostTypeName(string $postTypeName): string
    {
        try {
            return apply_filters("modify_post_type_name", $postTypeName);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return $postTypeName;
        }
    }

    /**
     * @param MetaBoxModel $metaBoxModel
     * @return string
     */
    protected function metaBoxEditLinkButton(MetaBoxModel $metaBoxModel): string
    {
        // check admin permission
        if (!current_user_can('manage_options')) {
            return "";
        }

        $url = $this->generateEditMetaBoxLink($metaBoxModel);

        return "<a class='acpt-edit-field-group' target='_blank' href='".$url."'>".Translator::translate("Edit meta box")."</a>";
    }

    /**
     * Same as metaBoxEditLinkButton(), but tolerates a null box — the tab-display
     * generators resolve the "active" box via getBoxById(...) ?? getBoxes()[0],
     * both of which can be null (no/stale active-tab cookie, or a group with zero
     * boxes) — render nothing instead of fataling on the non-nullable param above.
     *
     * @param MetaBoxModel|null $metaBoxModel
     * @return string
     */
    protected function metaBoxEditLinkButtonOrEmpty(?MetaBoxModel $metaBoxModel): string
    {
        return $metaBoxModel !== null ? $this->metaBoxEditLinkButton($metaBoxModel) : '';
    }

    /**
     * @param MetaBoxModel $metaBoxModel
     * @return string
     */
    protected function metaBoxLabel(MetaBoxModel $metaBoxModel): string
    {
        return (!empty($metaBoxModel->getLabel())) ? $metaBoxModel->getLabel() : $metaBoxModel->getName();
    }

    /**
     * Returns a hidden element containing the edit URL for the meta box.
     * JS will pick this up and inject the edit button into the appropriate header.
     *
     * @param MetaBoxModel $metaBoxModel
     * @return string
     */
    protected function metaBoxEditButtonPlaceholder(MetaBoxModel $metaBoxModel): string
    {
        if (!current_user_can('manage_options')) {
            return "";
        }

        $url = $this->generateEditMetaBoxLink($metaBoxModel);
        $label = Translator::translate("Edit meta box");

        return "<span class='acpt-edit-button-placeholder' data-acpt-edit-url='".$url."' data-acpt-edit-label='".$label."' style='display:none;'></span>";
    }

    /**
     * @param MetaBoxModel $metaBoxModel
     * @return string
     */
    protected function metaBoxHeading(MetaBoxModel $metaBoxModel): string
    {
        $boxLabel = "<div class='acpt-heading-wrapper'>";
        $boxLabel .= "<span class='acpt-heading-text'>";
        $boxLabel .= $this->metaBoxLabel($metaBoxModel);
        $boxLabel .= "</span>";
        $boxLabel .= $this->metaBoxEditLinkButton($metaBoxModel);
        $boxLabel .= "</div>";

        return $boxLabel;
    }

    /**
        * Generates an admin URL link for editing a meta box based on its group association.
     *
     * @param MetaBoxModel $metaBoxModel The model representing the meta box.
     * @return string The generated admin URL link.
     */
    private function generateEditMetaBoxLink(MetaBoxModel $metaBoxModel): string
    {
        if ($metaBoxModel->getGroup()->isCCTCopy()) {
            return admin_url('admin.php?page='.ACPT_PLUGIN_NAME.'#/edit_table/'.$metaBoxModel->getGroup()->getId().'/1#'.$metaBoxModel->getId());
        }

        return admin_url('admin.php?page='.ACPT_PLUGIN_NAME.'#/edit_meta/'.$metaBoxModel->getGroup()->getId().'#'.$metaBoxModel->getId());
    }
}
