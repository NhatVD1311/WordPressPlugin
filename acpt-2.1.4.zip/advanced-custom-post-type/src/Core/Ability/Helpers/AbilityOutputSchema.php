<?php

namespace ACPT\Core\Ability\Helpers;

class AbilityOutputSchema
{
    /**
     * @param array<string, mixed>|null $dataSchema
     *
     * @return array<string, mixed>
     */
    public static function envelope(?array $dataSchema = null): array
    {
        $properties = [
            'success' => ['type' => 'boolean'],
            'message' => ['type' => 'string'],
        ];

        if ($dataSchema !== null) {
            $properties['data'] = $dataSchema;
        }

        return [
            'type' => 'object',
            'properties' => $properties,
            'required' => ['success'],
        ];
    }

    /**
     * @param array<string, mixed> $itemSchema
     *
     * @return array<string, mixed>
     */
    public static function single(array $itemSchema): array
    {
        return self::envelope(self::relaxForOutput($itemSchema));
    }

    /**
     * @param array<string, mixed> $itemSchema
     *
     * @return array<string, mixed>
     */
    public static function collection(array $itemSchema): array
    {
        return self::envelope([
            'type' => 'array',
            'items' => self::relaxForOutput($itemSchema),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public static function deleted(): array
    {
        return self::envelope();
    }

    /**
     * The provider schemas (e.g. CustomPostTypeSchema, FormSchema, ...) are hand-authored to
     * describe REST *input* payloads - field names, `required`, `additionalProperties: false`,
     * `enum`, and `format` all describe what a caller may legitimately submit. They're reused
     * as-is for `output_schema`, but the data a callback actually returns comes from each
     * model's jsonSerialize(), which: uses different field names and emits extra fields the
     * input schema never declared; renders values that no longer match an input-facing `enum`
     * (e.g. CustomPostTypeModel::renderIcon() prefixes the stored Dashicon with "dashicons-",
     * which will never match CustomPostTypeSchema's bare-name icon enum); leaves optional
     * fields as `null` where the input schema never allowed `null` (e.g. an unset field
     * `description`); or produces strings like `""` for "no value" where a `format` check
     * (e.g. `uuid`) then rejects it. None of that is a real bug in the data - it's the
     * consequence of reusing an input-shaped schema for output. WP core's
     * rest_validate_value_from_schema() enforces all of the above strictly, so that drift
     * throws a hard ability_invalid_output error on otherwise-successful calls. Rather than
     * hand-chasing every one of these across every schema (the reason it drifted in the first
     * place), relax a schema before using it for output: keep `type`/`oneOf` at the top level
     * (still catches a callback returning the wrong shape entirely, e.g. a bool instead of an
     * object), but drop `required`, `additionalProperties: false`, `enum`, and `format`, and
     * make every nested property/item implicitly nullable (via its `type`, or by adding a
     * `null` branch to its `oneOf`), recursively through `properties`/`items`.
     *
     * @param array<string, mixed> $schema
     * @param bool                 $isRoot Whether this is the operation's own top-level return
     *                                      value (kept non-nullable) vs. a nested property/item.
     *
     * @return array<string, mixed>
     */
    protected static function relaxForOutput(array $schema, bool $isRoot = true): array
    {
        unset($schema['required'], $schema['enum'], $schema['format']);

        if (isset($schema['additionalProperties']) && $schema['additionalProperties'] === false) {
            unset($schema['additionalProperties']);
        }

        if (isset($schema['properties']) && is_array($schema['properties'])) {
            foreach ($schema['properties'] as $name => $propertySchema) {
                if (is_array($propertySchema)) {
                    $schema['properties'][$name] = self::relaxForOutput($propertySchema, false);
                }
            }
        }

        if (isset($schema['items']) && is_array($schema['items'])) {
            $schema['items'] = self::relaxForOutput($schema['items'], false);
        }

        if (!$isRoot && isset($schema['type']) && $schema['type'] !== 'null') {
            $schema['type'] = array_values(array_unique(array_merge((array) $schema['type'], ['null'])));
        }

        // A handful of properties (e.g. has_archive, rewrite, query_var) are declared via
        // `oneOf` rather than a plain `type`, since register_post_type()/register_taxonomy()
        // accept more than one shape for them - none of those branches allow `null` either, so
        // they need the same nullable treatment as plain-`type` properties above.
        if (!$isRoot && isset($schema['oneOf']) && is_array($schema['oneOf'])) {
            $hasNullBranch = false;

            foreach ($schema['oneOf'] as $branch) {
                if (is_array($branch) && ($branch['type'] ?? null) === 'null') {
                    $hasNullBranch = true;
                    break;
                }
            }

            if (!$hasNullBranch) {
                $schema['oneOf'][] = ['type' => 'null'];
            }
        }

        return $schema;
    }
}
