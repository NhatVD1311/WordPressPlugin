<?php

namespace ACPT\Core\Ability\TableGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TableGroupSchema;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetTableGroupAbility extends AbstractAbility
{
    protected static $schema = TableGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-table-group';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a custom table group', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT custom table group by name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $group = TableGroupRepository::getByName($input['name'] ?? '');

            return $group !== null ? $group->toStdObject() : null;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
