<?php

namespace ACPT\Core\Ability\TableGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TableGroupSchema;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListTableGroupsAbility extends AbstractAbility
{
    protected static $schema = TableGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-table-groups';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List custom table groups', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all ACPT custom table groups (location/visibility rules and their member tables).', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, TableGroupRepository::get([]));
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
