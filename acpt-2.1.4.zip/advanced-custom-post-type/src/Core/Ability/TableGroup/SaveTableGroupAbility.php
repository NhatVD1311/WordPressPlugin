<?php

namespace ACPT\Core\Ability\TableGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TableGroupSchema;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveTableGroupAbility extends AbstractAbility
{
    protected static $schema = TableGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-table-group';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a custom table group', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT custom table group, or updates the existing one if a group with the same name already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (save_acpt_table_group($input) !== true) {
                return null;
            }

            $group = TableGroupRepository::getByName($input['name'] ?? '');

            return $group !== null ? $group->toStdObject() : null;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return self::schema();
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the table group.', ACPT_PLUGIN_NAME);
    }
}
