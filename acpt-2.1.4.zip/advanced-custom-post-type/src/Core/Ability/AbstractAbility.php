<?php

namespace ACPT\Core\Ability;

use ACPT\Core\JSON\AbstractJSONSchema;
use ACPT\Utils\PHP\JSON;

abstract class AbstractAbility
{
    public const NAMESPACE = 'acpt';
    public const DEFAULT_CAPABILITY = 'manage_options';

    /**
     * @var class-string<AbstractJSONSchema>|null
     */
    protected static $schema = null;

    /**
     * @return string
     */
    abstract public static function name(): string;

    /**
     * @return string
     */
    abstract public static function label(): string;

    /**
     * @return string
     */
    abstract public static function description(): string;

    /**
     * @return string
     */
    abstract public static function category(): string;

    /**
     * The raw business logic for this ability, invoked with the ability's array input.
     *
     * @return callable
     */
    abstract public static function callback(): callable;

    /**
     * @return array<string, mixed>
     */
    abstract public static function input_schema(): array;

    /**
     * @return array<string, mixed>
     */
    abstract public static function output_schema(): array;

    /**
     * @return string
     */
    public static function capability(): string
    {
        return self::DEFAULT_CAPABILITY;
    }

    /**
     * @return string
     */
    protected static function successMessage(): string
    {
        return __('Operation completed successfully.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('The operation failed.', ACPT_PLUGIN_NAME);
    }

    /**
     * @param mixed $result
     *
     * @return bool
     */
    protected static function isFailure($result): bool
    {
        return $result === false || $result === null;
    }

    /**
     * Normalizes ACPT models/stdClass/arrays/WP_Post_Type into plain JSON-friendly data.
     *
     * @param mixed $result
     *
     * @return mixed
     */
    protected static function normalizeData($result)
    {
        if ($result === true || $result === null) {
            return null;
        }

        if (is_array($result) || is_object($result)) {
            $encoded = wp_json_encode($result);

            return $encoded === false ? null : json_decode($encoded, true);
        }

        return $result;
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return false;
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return false;
    }

    /**
     * @return bool
     */
    protected static function idempotent(): bool
    {
        return true;
    }

    /**
     * @return string
     */
    public static function qualifiedNamespace(): string
    {
        return self::NAMESPACE . '/' . static::name();
    }

    /**
     * Wraps static::callback(): captures the exception message swallowed by ACPT helper
     * functions (fired via the "acpt/error" action instead of thrown outward), and normalizes
     * the heterogeneous helper return values into either a WP_Error or a
     * {success, message, data} envelope.
     *
     * @return callable
     */
    public static function execute_callback(): ?callable
    {
        return static function ($input = null) {
            $input = is_array($input) ? $input : [];
            $captured = null;

            $listener = function ($exception) use (&$captured): void {
                $captured = ($exception instanceof \Throwable) ? $exception->getMessage() : (string) $exception;
            };

            add_action('acpt/error', $listener);

            try {
                $result = call_user_func(static::callback(), $input);
            } finally {
                remove_action('acpt/error', $listener);
            }

            if (static::isFailure($result)) {
                return new \WP_Error(
                    'acpt_ability_failed',
                    $captured !== null ? $captured : static::failureMessage(),
                    ['status' => 400]
                );
            }

            return [
                'success' => true,
                'message' => static::successMessage(),
                'data'    => static::normalizeData($result),
            ];
        };
    }

    /**
     * @return callable
     */
    public static function permission_callback(): ?callable
    {
        return static function ($input = null) {
            $capability = apply_filters(
                'acpt/abilities-api/capability',
                static::capability(),
                static::qualifiedNamespace(),
                $input
            );

            if (current_user_can($capability)) {
                return true;
            }

            return new \WP_Error(
                'acpt_ability_forbidden',
                __('You are not allowed to perform this action.', ACPT_PLUGIN_NAME),
                ['status' => 403]
            );
        };
    }

    /**
     * 'mcp' => ['public' => true] is what the official wordpress/mcp-adapter package (bundled
     * by agent-connector-for-wp and other MCP host plugins) requires on an ability's meta
     * before its default MCP server will discover/execute it - without it,
     * McpAbilityHelperTrait::is_ability_mcp_public() rejects every call with "not exposed via
     * MCP (mcp.public!=true)", even though the ability registered fine with
     * wp_register_ability(). Every ability shares this default so plain AbilitiesAPI
     * registration (wp_register_ability() with no other MCP host involved) is enough on its
     * own; ACFW's agent_connector_for_wp_register_ability() force-merges the same flag on top
     * when it reclaims an ability, so this is a no-op there, not a conflict.
     *
     * @return array<string, mixed>
     */
    public static function meta(): ?array
    {
        return [
            'annotations'  => [
                'readonly'    => static::readonly(),
                'destructive' => static::destructive(),
                'idempotent'  => static::idempotent(),
            ],
            'show_in_rest' => true,
            'mcp'          => [
                'public' => true,
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected static function schema(): array
    {
        if (static::$schema === null) {
            return [];
        }

        $instance = new static::$schema();

        return $instance->toArray();
    }

    /**
     * The ability body, as expected by wp_register_ability()/agent_connector_for_wp_register_ability().
     *
     * @return array<string, mixed>
     */
    public static function body(): array
    {
        return [
            'label'               => static::label(),
            'description'         => static::description(),
            'category'            => static::category(),
            'input_schema'        => static::input_schema(),
            'output_schema'       => static::output_schema(),
            'execute_callback'    => static::execute_callback(),
            'permission_callback' => static::permission_callback(),
            'meta'                => static::meta(),
        ];
    }
}
