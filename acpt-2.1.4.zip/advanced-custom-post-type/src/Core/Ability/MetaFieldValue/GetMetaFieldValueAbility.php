<?php

namespace ACPT\Core\Ability\MetaFieldValue;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetMetaFieldValueAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-meta-field-value';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a meta field value', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns the value of a single field for a location. ', ACPT_PLUGIN_NAME) . LocationSchema::note();
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return 'get_acpt_field';
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => array_merge(LocationSchema::properties(), [
                'box_name'   => ['type' => 'string'],
                'field_name' => ['type' => 'string'],
                'format'     => ['type' => 'string', 'enum' => ['complete', 'only_value']],
                'return'     => ['type' => 'string', 'enum' => ['raw', 'string', 'object']],
            ]),
            'required'   => ['box_name', 'field_name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'        => ['string', 'number', 'integer', 'boolean', 'array', 'object', 'null'],
            'description' => __('The requested field value; shape depends on the field type and the format/return options.', ACPT_PLUGIN_NAME),
        ]);
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }

    /**
     * A legitimate field value can itself be false, 0 or "" (e.g. an unchecked toggle field) -
     * only a genuine null means "not found / invalid request".
     *
     * @param mixed $result
     *
     * @return bool
     */
    protected static function isFailure($result): bool
    {
        return $result === null;
    }
}
