<?php

namespace ACPT\Core\Ability\MetaFieldValue;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class AppendMetaFieldValueAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'append-meta-field-value';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Append a row to a repeater field value', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Appends a single row to a REPEATER field for a location, without needing to re-send the existing rows. ', ACPT_PLUGIN_NAME) . LocationSchema::note();
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return 'append_acpt_meta_field_value';
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => array_merge(LocationSchema::properties(), [
                'box_name'   => ['type' => 'string'],
                'field_name' => ['type' => 'string'],
                'value'      => ['type' => 'object', 'description' => __('The row to append, keyed by each child field name.', ACPT_PLUGIN_NAME)],
                'forged_by'  => ['type' => 'array'],
            ]),
            'required'   => ['box_name', 'field_name', 'value'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to append the row. Make sure field_name refers to a REPEATER field.', ACPT_PLUGIN_NAME);
    }
}
