<?php

namespace ACPT\Core\Ability\MetaFieldValue;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListMetaFieldValuesAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-meta-field-values';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List meta field values', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns field values for a location. ', ACPT_PLUGIN_NAME) . LocationSchema::note() . ' ' . __('If box_name is omitted, values from every visible box are returned.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return 'get_acpt_fields';
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => array_merge(LocationSchema::properties(), [
                'box_name' => ['type' => 'string'],
                'format'   => ['type' => 'string', 'enum' => ['complete', 'only_value']],
                'assoc'    => ['type' => 'boolean'],
                'return'   => ['type' => 'string', 'enum' => ['raw', 'object']],
            ]),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'        => ['string', 'number', 'integer', 'boolean', 'array', 'object', 'null'],
            'description' => __('The requested field values; shape depends on the box/field(s) requested and the format/return options.', ACPT_PLUGIN_NAME),
        ]);
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
