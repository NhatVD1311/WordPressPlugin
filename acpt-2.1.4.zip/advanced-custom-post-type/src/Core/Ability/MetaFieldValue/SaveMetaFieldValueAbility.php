<?php

namespace ACPT\Core\Ability\MetaFieldValue;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveMetaFieldValueAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-meta-field-value';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Set a meta field value', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates or updates the value of a single field for a location. ', ACPT_PLUGIN_NAME) . LocationSchema::note();
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return 'save_acpt_meta_field_value';
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => array_merge(LocationSchema::properties(), [
                'box_name'   => ['type' => 'string'],
                'field_name' => ['type' => 'string'],
                'value'      => ['description' => __('The value to store. Its shape depends on the field type.', ACPT_PLUGIN_NAME)],
                'forged_by'  => ['type' => 'array'],
            ]),
            'required'   => ['box_name', 'field_name', 'value'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the field value.', ACPT_PLUGIN_NAME);
    }
}
