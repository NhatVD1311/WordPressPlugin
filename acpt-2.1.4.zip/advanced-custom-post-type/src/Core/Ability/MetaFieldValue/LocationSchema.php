<?php

namespace ACPT\Core\Ability\MetaFieldValue;

/**
 * Shared input-schema fragment for every meta-field-value ability: exactly one of these
 * location keys identifies where the value lives (post, term, user, comment, option page or
 * WooCommerce product attribute).
 */
class LocationSchema
{
    /**
     * @return array<string, mixed>
     */
    public static function properties(): array
    {
        return [
            'post_id'              => ['type' => 'integer', 'description' => __('Post ID (use when reading/writing a value stored on a post).', ACPT_PLUGIN_NAME)],
            'term_id'              => ['type' => 'integer', 'description' => __('Term ID (use when reading/writing a value stored on a taxonomy term).', ACPT_PLUGIN_NAME)],
            'user_id'              => ['type' => 'integer', 'description' => __('User ID.', ACPT_PLUGIN_NAME)],
            'comment_id'           => ['type' => 'integer', 'description' => __('Comment ID.', ACPT_PLUGIN_NAME)],
            'option_page'          => ['type' => 'string', 'description' => __('Option page menu slug.', ACPT_PLUGIN_NAME)],
            'wc_product_attribute' => ['type' => 'integer', 'description' => __('WooCommerce product attribute ID.', ACPT_PLUGIN_NAME)],
        ];
    }

    public static function note(): string
    {
        return __('Exactly one location key must be provided: post_id, term_id, user_id, comment_id, option_page, or wc_product_attribute.', ACPT_PLUGIN_NAME);
    }
}
