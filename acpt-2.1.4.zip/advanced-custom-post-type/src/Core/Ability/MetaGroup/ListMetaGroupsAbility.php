<?php

namespace ACPT\Core\Ability\MetaGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaGroupSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListMetaGroupsAbility extends AbstractAbility
{
    protected static $schema = MetaGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-meta-groups';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List meta field groups', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns ACPT meta field groups (field group definitions), including their boxes and fields.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): array {
            return get_acpt_meta_group_objects($input);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'groupName' => ['type' => 'string', 'description' => __('Optional: filter by group name.', ACPT_PLUGIN_NAME)],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
