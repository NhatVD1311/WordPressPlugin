<?php

namespace ACPT\Core\Ability\MetaGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaGroupSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetMetaGroupAbility extends AbstractAbility
{
    protected static $schema = MetaGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-meta-group';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a meta field group', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT meta field group by name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            return get_acpt_meta_group_object($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
