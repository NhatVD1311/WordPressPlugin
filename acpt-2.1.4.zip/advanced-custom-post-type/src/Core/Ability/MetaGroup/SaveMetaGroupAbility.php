<?php

namespace ACPT\Core\Ability\MetaGroup;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaGroupSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveMetaGroupAbility extends AbstractAbility
{
    protected static $schema = MetaGroupSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-meta-group';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a meta field group', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT meta field group (with its boxes and fields), or updates the existing one if a group with the same name already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (save_acpt_meta_group($input) !== true) {
                return null;
            }

            return get_acpt_meta_group_object($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return self::schema();
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the meta field group.', ACPT_PLUGIN_NAME);
    }
}
