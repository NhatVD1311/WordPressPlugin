<?php

namespace ACPT\Core\Ability\MetaField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaFieldSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetMetaFieldAbility extends AbstractAbility
{
    protected static $schema = MetaFieldSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-meta-field';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a meta field', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT meta field definition by box name and field name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            return get_acpt_meta_field_object($input['box_name'] ?? null, $input['field_name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'box_name'   => ['type' => 'string'],
                'field_name' => ['type' => 'string'],
            ],
            'required'   => ['box_name', 'field_name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
