<?php

namespace ACPT\Core\Ability\MetaField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaFieldSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListMetaFieldsAbility extends AbstractAbility
{
    protected static $schema = MetaFieldSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-meta-fields';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List meta fields for a location', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns the ACPT meta field definitions attached to a given location (e.g. a custom post type, taxonomy, user, option page). belongsTo identifies the location type and find optionally scopes it to a specific slug/id.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): array {
            return get_acpt_meta_field_objects(
                $input['belongsTo'] ?? null,
                $input['clonedFields'] ?? false,
                $input['find'] ?? null
            );
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'belongsTo'    => [
                    'type'        => 'string',
                    'description' => __('The location type these fields belong to (e.g. a custom post type, taxonomy, user or option page identifier).', ACPT_PLUGIN_NAME),
                ],
                'find'         => [
                    'type'        => 'string',
                    'description' => __('Optional: restrict to a specific location slug/id within belongsTo.', ACPT_PLUGIN_NAME),
                ],
                'clonedFields' => ['type' => 'boolean'],
            ],
            'required'   => ['belongsTo'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
