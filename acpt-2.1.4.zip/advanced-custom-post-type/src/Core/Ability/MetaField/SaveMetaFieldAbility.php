<?php

namespace ACPT\Core\Ability\MetaField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaFieldSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveMetaFieldAbility extends AbstractAbility
{
    protected static $schema = MetaFieldSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-meta-field';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a meta field', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new meta field inside an existing meta box, or updates it if a field with the same name already exists in that box.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (save_acpt_meta_field($input) !== true) {
                return null;
            }

            return get_acpt_meta_field_object($input['boxName'] ?? null, $input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        $schema = self::schema();

        return array_merge($schema, [
            'properties' => array_merge($schema['properties'], [
                'groupName'  => ['type' => 'string', 'description' => __('The name of the meta field group this field belongs to.', ACPT_PLUGIN_NAME)],
                'boxName'    => ['type' => 'string', 'description' => __('The name of the meta box this field belongs to.', ACPT_PLUGIN_NAME)],
                'boxId'      => ['type' => 'string', 'format' => 'uuid', 'description' => __('The id of the meta box this field belongs to. Optional; provide it to disambiguate when two boxes in the group share the same name.', ACPT_PLUGIN_NAME)],
                'new_name'   => ['type' => 'string'],
                'parentName' => ['type' => 'string'],
            ]),
            'required' => ['groupName', 'boxName', 'name', 'type'],
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the meta field.', ACPT_PLUGIN_NAME);
    }
}
