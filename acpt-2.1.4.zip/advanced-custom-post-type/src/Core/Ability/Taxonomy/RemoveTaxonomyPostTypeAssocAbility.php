<?php

namespace ACPT\Core\Ability\Taxonomy;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class RemoveTaxonomyPostTypeAssocAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'remove-taxonomy-post-type-assoc';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Remove a taxonomy from a post type', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Detaches an ACPT taxonomy from a custom post type.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            $result = remove_assoc_acpt_taxonomy_from_acpt_post($input['taxonomy'] ?? null, $input['post_type'] ?? null);

            return $result === false ? false : true;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'taxonomy'  => ['type' => 'string'],
                'post_type' => ['type' => 'string'],
            ],
            'required'   => ['taxonomy', 'post_type'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to remove the association between the taxonomy and the post type.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
