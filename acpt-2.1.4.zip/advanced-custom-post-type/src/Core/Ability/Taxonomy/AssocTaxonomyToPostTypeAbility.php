<?php

namespace ACPT\Core\Ability\Taxonomy;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class AssocTaxonomyToPostTypeAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'assoc-taxonomy-post-type';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Associate a taxonomy to a post type', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Attaches an existing ACPT taxonomy to an existing custom post type.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            $result = assoc_acpt_taxonomy_to_acpt_post($input['taxonomy'] ?? null, $input['post_type'] ?? null);

            return $result === false ? false : true;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'taxonomy'  => ['type' => 'string'],
                'post_type' => ['type' => 'string'],
            ],
            'required'   => ['taxonomy', 'post_type'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to associate the taxonomy to the post type.', ACPT_PLUGIN_NAME);
    }
}
