<?php

namespace ACPT\Core\Ability\Taxonomy;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TaxonomySchema;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveTaxonomyAbility extends AbstractAbility
{
    protected static $schema = TaxonomySchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-taxonomy';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a taxonomy', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT taxonomy, or updates the existing one if a taxonomy with the same slug already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (register_acpt_taxonomy($input) !== true) {
                return null;
            }

            $slug = $input['slug'] ?? null;

            if (empty($slug) || !TaxonomyRepository::exists($slug)) {
                return null;
            }

            $models = TaxonomyRepository::get(['id' => TaxonomyRepository::getId($slug)]);

            return count($models) === 1 ? $models[0]->toStdObject() : null;
        };
    }

    /**
     * TaxonomySchema describes the stored/returned model shape (singular/plural) which is
     * correct for output, but register_acpt_taxonomy() expects a different, more verbose set of
     * argument names (singular_label/plural_label, plus post_types/permissions that
     * TaxonomySchema doesn't describe at all) - so this is a dedicated input schema rather than
     * a reuse of the shared TaxonomySchema (which is also used by the REST API and its OpenAPI
     * doc, and shouldn't change shape here).
     *
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        $outputSchema = self::schema();

        return [
            'type'       => 'object',
            'properties' => [
                'slug'           => $outputSchema['properties']['slug'],
                'singular_label' => ['type' => 'string', 'example' => 'Year'],
                'plural_label'   => ['type' => 'string', 'example' => 'Years'],
                'labels'         => $outputSchema['properties']['labels'],
                'settings'       => $outputSchema['properties']['settings'],
                'post_types'     => [
                    'type'        => 'array',
                    'items'       => ['type' => 'string'],
                    'description' => __('Slugs of the post types this taxonomy should be attached to.', ACPT_PLUGIN_NAME),
                ],
                'permissions'    => ['type' => 'array'],
            ],
            'required'   => ['slug', 'singular_label', 'plural_label'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the taxonomy.', ACPT_PLUGIN_NAME);
    }
}
