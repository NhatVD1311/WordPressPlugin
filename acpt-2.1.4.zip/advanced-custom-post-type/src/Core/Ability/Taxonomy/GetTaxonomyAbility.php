<?php

namespace ACPT\Core\Ability\Taxonomy;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TaxonomySchema;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetTaxonomyAbility extends AbstractAbility
{
    protected static $schema = TaxonomySchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-taxonomy';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a taxonomy', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT taxonomy definition by its slug.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $slug = $input['slug'] ?? null;

            if (empty($slug) || !TaxonomyRepository::exists($slug)) {
                return null;
            }

            $models = TaxonomyRepository::get(['id' => TaxonomyRepository::getId($slug)]);

            return count($models) === 1 ? $models[0]->toStdObject() : null;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'slug' => ['type' => 'string'],
            ],
            'required'   => ['slug'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
