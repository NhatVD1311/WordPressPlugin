<?php

namespace ACPT\Core\Ability\Taxonomy;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\TaxonomySchema;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListTaxonomiesAbility extends AbstractAbility
{
    protected static $schema = TaxonomySchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-taxonomies';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List taxonomies', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all custom taxonomies registered via ACPT.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, TaxonomyRepository::get());
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
