<?php

namespace ACPT\Core\Ability\TableRecord;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Ability\Categories\AbilityCategories;

class CreateTableRecordAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'create-table-record';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create a custom table record', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a record. Requires "create" enabled in Expose via REST API.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?array {
            $tableName = $input['table_name'] ?? '';
            $data      = $input['data'] ?? [];

            return GuardedTableRecordCallback::run($tableName, 'create', function (TableModel $table) use ($data) {
                return (new TableRecordController())->create($table->getName(), $data);
            });
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'table_name' => ['type' => 'string'],
                'data'       => ['type' => 'object'],
            ],
            'required'   => ['table_name', 'data'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'       => 'object',
            'properties' => ['id' => ['type' => ['string', 'integer']]],
        ]);
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to create the record.', ACPT_PLUGIN_NAME);
    }
}
