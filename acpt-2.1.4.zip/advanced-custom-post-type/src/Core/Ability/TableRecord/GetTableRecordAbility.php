<?php

namespace ACPT\Core\Ability\TableRecord;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetTableRecordAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-table-record';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a custom table record', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single record by id. Requires "read" enabled in Expose via REST API.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $tableName = $input['table_name'] ?? '';

            return GuardedTableRecordCallback::run($tableName, 'read', function (TableModel $table) use ($input) {
                return (new TableRecordController())->get($table->getName(), $input['id'] ?? null);
            });
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'table_name' => ['type' => 'string'],
                'id'         => ['type' => ['string', 'integer']],
            ],
            'required'   => ['table_name', 'id'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope(GuardedTableRecordCallback::anyTypeSchema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
