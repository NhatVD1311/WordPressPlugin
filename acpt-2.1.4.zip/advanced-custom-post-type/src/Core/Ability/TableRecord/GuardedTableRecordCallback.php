<?php

namespace ACPT\Core\Ability\TableRecord;

use ACPT\Core\API\Exceptions\UnauthorizedException;
use ACPT\Core\API\V1\Controllers\TableRecordController;

/**
 * Shared execution path for every table-record ability: resolves the table, enforces its
 * restApi exposure flag for the action (the exact same check TableRecordHttpAdapter::checkSupports()
 * applies to the REST API, so an ability call can never reach data the REST API itself would
 * refuse), runs $fn, and normalizes every failure mode to the catch-and-signal convention
 * AbstractAbility::execute_callback() expects. TableRecordController's methods throw rather
 * than returning false, and execute_callback() has no surrounding try/catch of its own - this
 * catch is load-bearing, not decorative.
 */
class GuardedTableRecordCallback
{
    /**
     * @return mixed
     */
    public static function run(string $tableName, string $action, callable $fn)
    {
        try {
            $table = (new TableRecordController())->resolveTable($tableName);

            if (!$table->hasRestAPiSupportFor($action)) {
                throw new UnauthorizedException(
                    "Table {$tableName} does not support the {$action} action via REST API."
                );
            }

            return $fn($table);
        } catch (\Exception $exception) {
            do_action('acpt/error', $exception);

            return null;
        }
    }

    /**
     * Row shape varies per table (columns are user-defined), so it can't be described by a
     * fixed schema at registration time - accept/return any JSON-representable shape, same
     * treatment as the meta-field-value abilities.
     *
     * @return array<string, mixed>
     */
    public static function anyTypeSchema(): array
    {
        return [
            'type'        => ['string', 'number', 'integer', 'boolean', 'array', 'object', 'null'],
            'description' => __('Row data; shape depends on the target table\'s columns.', ACPT_PLUGIN_NAME),
        ];
    }
}
