<?php

namespace ACPT\Core\Ability\TableRecord;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListTableRecordsAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-table-records';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List custom table records', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns paginated records for a custom table. Requires the table to have "read" enabled in its Expose via REST API setting.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?array {
            $tableName = $input['table_name'] ?? '';
            unset($input['table_name']);

            return GuardedTableRecordCallback::run($tableName, 'read', function (TableModel $table) use ($input) {
                return (new TableRecordController())->list($table->getName(), $input);
            });
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'table_name' => ['type' => 'string'],
                'page'       => ['type' => 'integer'],
                'per_page'   => ['type' => 'integer'],
                'order_by'   => ['type' => 'object'],
                'where'      => ['type' => 'object'],
                's'          => ['type' => 'string'],
                'only_ids'   => ['type' => 'boolean'],
            ],
            'required'   => ['table_name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'       => 'object',
            'properties' => [
                'currentPage' => ['type' => 'integer'],
                'total'       => ['type' => 'integer'],
                'maxPages'    => ['type' => 'integer'],
                'perPage'     => ['type' => 'integer'],
                'records'     => ['type' => 'array', 'items' => GuardedTableRecordCallback::anyTypeSchema()],
            ],
        ]);
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
