<?php

namespace ACPT\Core\Ability\TableRecord;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Ability\Categories\AbilityCategories;

class UpdateTableRecordAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'update-table-record';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Update a custom table record', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Updates a record. Requires "update" enabled in Expose via REST API.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_DATA;
    }

    /**
     * @return string
     */
    public static function capability(): string
    {
        return 'edit_posts';
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?array {
            $tableName = $input['table_name'] ?? '';
            $data      = $input['data'] ?? [];

            return GuardedTableRecordCallback::run($tableName, 'update', function (TableModel $table) use ($input, $data) {
                return (new TableRecordController())->update($table->getName(), $input['id'] ?? null, $data);
            });
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'table_name' => ['type' => 'string'],
                'id'         => ['type' => ['string', 'integer']],
                'data'       => ['type' => 'object'],
            ],
            'required'   => ['table_name', 'id', 'data'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'       => 'object',
            'properties' => [
                'id'   => ['type' => ['string', 'integer']],
                'data' => GuardedTableRecordCallback::anyTypeSchema(),
            ],
        ]);
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to update the record.', ACPT_PLUGIN_NAME);
    }
}
