<?php

namespace ACPT\Core\Ability;

use ACPT\Core\Ability\CustomPostType\DeleteCustomPostTypeAbility;
use ACPT\Core\Ability\CustomPostType\GetCustomPostTypeAbility;
use ACPT\Core\Ability\CustomPostType\ListCustomPostTypesAbility;
use ACPT\Core\Ability\CustomPostType\SaveCustomPostTypeAbility;
use ACPT\Core\Ability\DynamicBlock\DeleteDynamicBlockAbility;
use ACPT\Core\Ability\DynamicBlock\GetDynamicBlockAbility;
use ACPT\Core\Ability\DynamicBlock\ListDynamicBlocksAbility;
use ACPT\Core\Ability\DynamicBlock\SaveDynamicBlockAbility;
use ACPT\Core\Ability\Form\DeleteFormAbility;
use ACPT\Core\Ability\Form\GetFormAbility;
use ACPT\Core\Ability\Form\ListFormsAbility;
use ACPT\Core\Ability\Form\SaveFormAbility;
use ACPT\Core\Ability\FormField\DeleteFormFieldAbility;
use ACPT\Core\Ability\FormField\GetFormFieldAbility;
use ACPT\Core\Ability\FormField\SaveFormFieldAbility;
use ACPT\Core\Ability\MetaBox\DeleteMetaBoxAbility;
use ACPT\Core\Ability\MetaBox\GetMetaBoxAbility;
use ACPT\Core\Ability\MetaBox\ListMetaBoxesAbility;
use ACPT\Core\Ability\MetaBox\SaveMetaBoxAbility;
use ACPT\Core\Ability\MetaField\DeleteMetaFieldAbility;
use ACPT\Core\Ability\MetaField\GetMetaFieldAbility;
use ACPT\Core\Ability\MetaField\ListMetaFieldsAbility;
use ACPT\Core\Ability\MetaField\SaveMetaFieldAbility;
use ACPT\Core\Ability\MetaFieldValue\AppendMetaFieldValueAbility;
use ACPT\Core\Ability\MetaFieldValue\DeleteMetaFieldValueAbility;
use ACPT\Core\Ability\MetaFieldValue\GetMetaFieldValueAbility;
use ACPT\Core\Ability\MetaFieldValue\ListMetaFieldValuesAbility;
use ACPT\Core\Ability\MetaFieldValue\SaveMetaFieldValueAbility;
use ACPT\Core\Ability\MetaGroup\DeleteMetaGroupAbility;
use ACPT\Core\Ability\MetaGroup\GetMetaGroupAbility;
use ACPT\Core\Ability\MetaGroup\ListMetaGroupsAbility;
use ACPT\Core\Ability\MetaGroup\SaveMetaGroupAbility;
use ACPT\Core\Ability\OptionPage\DeleteOptionPageAbility;
use ACPT\Core\Ability\OptionPage\GetOptionPageAbility;
use ACPT\Core\Ability\OptionPage\ListOptionPagesAbility;
use ACPT\Core\Ability\OptionPage\SaveOptionPageAbility;
use ACPT\Core\Ability\Table\DeleteTableAbility;
use ACPT\Core\Ability\Table\GetTableAbility;
use ACPT\Core\Ability\Table\GetTableStatusAbility;
use ACPT\Core\Ability\Table\ListTablesAbility;
use ACPT\Core\Ability\Table\SaveTableAbility;
use ACPT\Core\Ability\Table\SyncTableAbility;
use ACPT\Core\Ability\TableGroup\DeleteTableGroupAbility;
use ACPT\Core\Ability\TableGroup\GetTableGroupAbility;
use ACPT\Core\Ability\TableGroup\ListTableGroupsAbility;
use ACPT\Core\Ability\TableGroup\SaveTableGroupAbility;
use ACPT\Core\Ability\TableRecord\CreateTableRecordAbility;
use ACPT\Core\Ability\TableRecord\DeleteTableRecordAbility;
use ACPT\Core\Ability\TableRecord\GetTableRecordAbility;
use ACPT\Core\Ability\TableRecord\ListTableRecordsAbility;
use ACPT\Core\Ability\TableRecord\UpdateTableRecordAbility;
use ACPT\Core\Ability\Taxonomy\AssocTaxonomyToPostTypeAbility;
use ACPT\Core\Ability\Taxonomy\DeleteTaxonomyAbility;
use ACPT\Core\Ability\Taxonomy\GetTaxonomyAbility;
use ACPT\Core\Ability\Taxonomy\ListTaxonomiesAbility;
use ACPT\Core\Ability\Taxonomy\RemoveTaxonomyPostTypeAssocAbility;
use ACPT\Core\Ability\Taxonomy\SaveTaxonomyAbility;

/**
 * Single source of truth for every ACPT ability class. Consumed by both AbilitiesAPI
 * (registers each via wp_register_ability()) and ACFW (registers each via
 * agent_connector_for_wp_register_ability(), with its own audit-log wrapping applied on top)
 * so the two integrations never redefine the same ability twice.
 */
class AbilityRegistry
{
    /**
     * @return array<class-string<AbstractAbility>>
     */
    public static function all(): array
    {
        return [
            ListCustomPostTypesAbility::class,
            GetCustomPostTypeAbility::class,
            SaveCustomPostTypeAbility::class,
            DeleteCustomPostTypeAbility::class,
            ListTaxonomiesAbility::class,
            GetTaxonomyAbility::class,
            SaveTaxonomyAbility::class,
            DeleteTaxonomyAbility::class,
            AssocTaxonomyToPostTypeAbility::class,
            RemoveTaxonomyPostTypeAssocAbility::class,
            ListMetaGroupsAbility::class,
            GetMetaGroupAbility::class,
            SaveMetaGroupAbility::class,
            DeleteMetaGroupAbility::class,
            ListMetaBoxesAbility::class,
            GetMetaBoxAbility::class,
            SaveMetaBoxAbility::class,
            DeleteMetaBoxAbility::class,
            ListMetaFieldsAbility::class,
            GetMetaFieldAbility::class,
            SaveMetaFieldAbility::class,
            DeleteMetaFieldAbility::class,
            ListMetaFieldValuesAbility::class,
            GetMetaFieldValueAbility::class,
            SaveMetaFieldValueAbility::class,
            AppendMetaFieldValueAbility::class,
            DeleteMetaFieldValueAbility::class,
            ListOptionPagesAbility::class,
            GetOptionPageAbility::class,
            SaveOptionPageAbility::class,
            DeleteOptionPageAbility::class,
            ListFormsAbility::class,
            GetFormAbility::class,
            SaveFormAbility::class,
            DeleteFormAbility::class,
            GetFormFieldAbility::class,
            SaveFormFieldAbility::class,
            DeleteFormFieldAbility::class,
            ListDynamicBlocksAbility::class,
            GetDynamicBlockAbility::class,
            SaveDynamicBlockAbility::class,
            DeleteDynamicBlockAbility::class,
            ListTableGroupsAbility::class,
            GetTableGroupAbility::class,
            SaveTableGroupAbility::class,
            DeleteTableGroupAbility::class,
            ListTablesAbility::class,
            GetTableAbility::class,
            SaveTableAbility::class,
            DeleteTableAbility::class,
            GetTableStatusAbility::class,
            SyncTableAbility::class,
            ListTableRecordsAbility::class,
            GetTableRecordAbility::class,
            CreateTableRecordAbility::class,
            UpdateTableRecordAbility::class,
            DeleteTableRecordAbility::class,
        ];
    }
}
