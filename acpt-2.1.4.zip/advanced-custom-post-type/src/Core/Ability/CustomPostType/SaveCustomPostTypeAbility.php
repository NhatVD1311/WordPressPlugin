<?php

namespace ACPT\Core\Ability\CustomPostType;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\CustomPostTypeSchema;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveCustomPostTypeAbility extends AbstractAbility
{
    protected static $schema = CustomPostTypeSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-post-type';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a custom post type', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT custom post type, or updates the existing one if a post type with the same post_name already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            // icon/supports/labels/settings default handling (omitted -> UI-matching defaults,
            // explicit empty -> respected as-is) lives in register_acpt_post_type() itself, so
            // every caller of that helper gets the same behavior - don't duplicate defaults here.
            if (register_acpt_post_type($input) === false) {
                return null;
            }

            $postType = $input['post_name'] ?? null;

            if (empty($postType) || !CustomPostTypeRepository::exists($postType)) {
                return null;
            }

            $models = CustomPostTypeRepository::get(['id' => CustomPostTypeRepository::getId($postType)]);

            return count($models) === 1 ? $models[0]->toStdObject() : null;
        };
    }

    /**
     * post_name/singular_label/plural_label have no sensible default and stay required;
     * icon/supports/labels/settings get safe defaults in the save callback, so callers aren't
     * forced to pass them explicitly.
     *
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        $schema = self::schema();
        $schema['required'] = ['post_name', 'singular_label', 'plural_label'];

        return $schema;
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the custom post type.', ACPT_PLUGIN_NAME);
    }
}
