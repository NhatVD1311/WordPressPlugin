<?php

namespace ACPT\Core\Ability\CustomPostType;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\CustomPostTypeSchema;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListCustomPostTypesAbility extends AbstractAbility
{
    protected static $schema = CustomPostTypeSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-post-types';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List custom post types', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all custom post types registered via ACPT, including labels, settings and taxonomies.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, CustomPostTypeRepository::get());
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
