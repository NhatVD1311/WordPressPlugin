<?php

namespace ACPT\Core\Ability\CustomPostType;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\CustomPostTypeSchema;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetCustomPostTypeAbility extends AbstractAbility
{
    protected static $schema = CustomPostTypeSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-post-type';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a custom post type', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT custom post type definition by its post type slug (post_name).', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $postType = $input['post_type'] ?? null;

            if (empty($postType) || !CustomPostTypeRepository::exists($postType)) {
                return null;
            }

            $models = CustomPostTypeRepository::get(['id' => CustomPostTypeRepository::getId($postType)]);

            return count($models) === 1 ? $models[0]->toStdObject() : null;
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'post_type' => [
                    'type'        => 'string',
                    'description' => __('The post type technical name (slug).', ACPT_PLUGIN_NAME),
                ],
            ],
            'required'   => ['post_type'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
