<?php

namespace ACPT\Core\Ability\CustomPostType;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class DeleteCustomPostTypeAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'delete-post-type';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Delete a custom post type', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Deletes an ACPT custom post type definition. Optionally deletes all posts of that type too.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return delete_acpt_post_type($input['post_type'] ?? null, $input['delete_posts'] ?? false);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'post_type'    => ['type' => 'string'],
                'delete_posts' => ['type' => 'boolean', 'default' => false],
            ],
            'required'   => ['post_type'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to delete the custom post type.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
