<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListTablesAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-tables';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List custom tables', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all ACPT custom table definitions (schema metadata only, not physical sync status).', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, TableRepository::get([]));
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(TableSchemas::output());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
