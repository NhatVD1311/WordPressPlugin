<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\JSON\TableSchema;

/**
 * Shared schema fragments for table abilities.
 */
class TableSchemas
{
    /**
     * @var class-string<TableSchema>
     */
    protected static $schema = TableSchema::class;

    /**
     * @return array<string, mixed>
     */
    public static function input(): array
    {
        $schema = new static::$schema();

        return $schema->toArray();
    }

    /**
     * TableSchema's `options` is a oneOf(object, array) to accept either input shape
     * (SaveTableCommand tolerates both a flat key/value map and a list of {key,value} objects)
     * - but TableModel::getOptions() always *returns* a plain list of {key,value} objects, so
     * the oneOf is ambiguous for real output (an empty list satisfies both branches) and WP
     * core's validator rejects it as "matches more than one of the expected formats". Narrow it
     * to `array` for the output-only copy of the schema.
     *
     * @return array<string, mixed>
     */
    public static function output(): array
    {
        $schema = self::input();
        $schema['properties']['options'] = [
            'type'  => 'array',
            'items' => ['type' => 'object'],
        ];

        return $schema;
    }
}
