<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetTableAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-table';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a custom table', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT custom table definition by name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            return get_acpt_table_object($input['name'] ?? '');
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(TableSchemas::output());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
