<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SyncTableAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'sync-table';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Synchronise a custom table', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates or alters the physical database table to match its stored definition. No-op if already in sync.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return sync_acpt_table($input['name'] ?? '');
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to synchronise the table schema.', ACPT_PLUGIN_NAME);
    }

    /**
     * An ALTER that drops a column (because the stored definition was edited to
     * remove it) destroys that column's physical data — this runs live DDL, not
     * a safe no-op, despite the ability's generic "sync" naming.
     *
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
