<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetTableStatusAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-table-status';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a custom table status', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns whether the physical database table is in sync with its stored definition (not_created, synced, or not_synced), plus the pending SQL diff.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            return get_acpt_table_status($input['name'] ?? '');
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::envelope([
            'type'       => 'object',
            'properties' => [
                'status'       => ['type' => 'string', 'enum' => ['not_created', 'synced', 'not_synced']],
                'create_query' => ['type' => ['string', 'null'], 'nullable' => true],
                'diff'         => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        ]);
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to retrieve the table status.', ACPT_PLUGIN_NAME);
    }
}
