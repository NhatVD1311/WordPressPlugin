<?php

namespace ACPT\Core\Ability\Table;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveTableAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-table';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a custom table', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT custom table definition, or updates the existing one if a table with the same name already exists. This only saves the definition - call sync-table afterwards to create/alter the physical database table. Prefer setting tableGroupId (create the group first via acpt/save-table-group) over the deprecated flat `location` shim.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            // SaveTableCommand reads the capital-API spelling; TableSchema declares the
            // lowercase-api one. Alias so schema-valid input isn't silently dropped.
            if (isset($input['restApi']) && !isset($input['restAPI'])) {
                $input['restAPI'] = $input['restApi'];
            }

            if (save_acpt_table($input) !== true) {
                return null;
            }

            return get_acpt_table_object($input['name'] ?? '');
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return TableSchemas::input();
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(TableSchemas::output());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the table.', ACPT_PLUGIN_NAME);
    }
}
