<?php

namespace ACPT\Core\Ability\Form;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\FormSchema;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListFormsAbility extends AbstractAbility
{
    protected static $schema = FormSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-forms';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List forms', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all ACPT forms.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, FormRepository::get([]));
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
