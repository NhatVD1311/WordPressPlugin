<?php

namespace ACPT\Core\Ability\Form;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class DeleteFormAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'delete-form';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Delete a form', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Deletes an ACPT form and its fields.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return delete_acpt_form($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to delete the form.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
