<?php

namespace ACPT\Core\Ability\Form;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\FormSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetFormAbility extends AbstractAbility
{
    protected static $schema = FormSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-form';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a form', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT form by name, including its fields. Use this instead of a separate list-form-fields ability.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            return get_acpt_form_object($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
