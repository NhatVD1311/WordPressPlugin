<?php

namespace ACPT\Core\Ability\Categories;

class AbilityCategories
{
    public const CONTENT_MODEL = 'acpt-content-model';
    public const CONTENT_DATA = 'acpt-content-data';

    /**
     * @return array<string, array{label: string, description: string}>
     */
    public static function definitions(): array
    {
        return [
            self::CONTENT_MODEL => [
                'label'       => __('ACPT Content Model', ACPT_PLUGIN_NAME),
                'description' => __('Manage ACPT custom post types, taxonomies, meta field definitions, option pages, forms, and dynamic blocks.', ACPT_PLUGIN_NAME),
            ],
            self::CONTENT_DATA => [
                'label'       => __('ACPT Content Data', ACPT_PLUGIN_NAME),
                'description' => __('Read and write ACPT custom field values on posts, terms, users, comments, and option pages.', ACPT_PLUGIN_NAME),
            ],
        ];
    }

    /**
     * Registers ACPT's ability categories. Must run on the wp_abilities_api_categories_init
     * hook. Guards each registration with wp_has_ability_category() so both AbilitiesAPI and
     * ACFW can safely hook this same method without tripping the categories registry's
     * "already registered" _doing_it_wrong when both integrations are active.
     *
     * @return void
     */
    public static function register(): void
    {
        foreach (self::definitions() as $slug => $args) {
            if (!wp_has_ability_category($slug)) {
                wp_register_ability_category($slug, $args);
            }
        }
    }
}
