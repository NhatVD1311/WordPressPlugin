<?php

namespace ACPT\Core\Ability\MetaBox;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaBoxSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetMetaBoxAbility extends AbstractAbility
{
    protected static $schema = MetaBoxSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-meta-box';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a meta box', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT meta box by name, including its fields.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        // get_acpt_box_object() actually returns \stdClass|null despite its docblock
        // (functions/_inc/settings/meta.php) - a ?array-typed closure here throws an
        // uncaught TypeError on every successful lookup.
        return function (array $input): ?\stdClass {
            return get_acpt_box_object($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
