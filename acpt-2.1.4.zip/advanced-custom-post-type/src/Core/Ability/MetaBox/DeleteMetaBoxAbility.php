<?php

namespace ACPT\Core\Ability\MetaBox;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class DeleteMetaBoxAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'delete-meta-box';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Delete a meta box', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Deletes a meta box (and its fields) from a meta field group.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return delete_acpt_meta_box($input['group_name'] ?? null, $input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'group_name' => ['type' => 'string'],
                'name'       => ['type' => 'string'],
            ],
            'required'   => ['group_name', 'name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to delete the meta box.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
