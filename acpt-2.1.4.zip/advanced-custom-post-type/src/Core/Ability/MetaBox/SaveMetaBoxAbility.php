<?php

namespace ACPT\Core\Ability\MetaBox;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaBoxSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveMetaBoxAbility extends AbstractAbility
{
    protected static $schema = MetaBoxSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-meta-box';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a meta box', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new meta box inside an existing meta field group, or updates it if a box with the same name already exists in that group.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (save_acpt_meta_box($input) !== true) {
                return null;
            }

            return get_acpt_box_object($input['name'] ?? null);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'groupName' => ['type' => 'string', 'description' => __('The name of the meta field group this box belongs to.', ACPT_PLUGIN_NAME)],
                'name'      => ['type' => 'string'],
                'new_name'  => ['type' => 'string'],
                'label'     => ['type' => 'string'],
                'fields'    => ['type' => 'array', 'items' => self::schema()['properties']['fields']['items']],
            ],
            'required'   => ['groupName', 'name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the meta box.', ACPT_PLUGIN_NAME);
    }
}
