<?php

namespace ACPT\Core\Ability\MetaBox;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\MetaBoxSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListMetaBoxesAbility extends AbstractAbility
{
    protected static $schema = MetaBoxSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-meta-boxes';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List meta boxes in a group', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns the meta boxes that belong to a given ACPT meta field group. There is no ungrouped/global box listing; a group_name is required.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): array {
            $group = get_acpt_meta_group_object($input['group_name'] ?? null);

            return $group !== null ? $group->boxes : [];
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['group_name' => ['type' => 'string']],
            'required'   => ['group_name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
