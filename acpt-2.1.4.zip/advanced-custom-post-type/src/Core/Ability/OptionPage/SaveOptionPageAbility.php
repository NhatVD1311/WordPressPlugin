<?php

namespace ACPT\Core\Ability\OptionPage;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\OptionPageSchema;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveOptionPageAbility extends AbstractAbility
{
    protected static $schema = OptionPageSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-option-page';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update an option page', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT option page, or updates the existing one if a page with the same menu_slug already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (register_acpt_option_page($input) !== true) {
                return null;
            }

            $slug = $input['menu_slug'] ?? null;

            if (empty($slug) || !OptionPageRepository::exists($slug)) {
                return null;
            }

            return OptionPageRepository::getByMenuSlug($slug)->toStdObject();
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        $outputSchema = self::schema();

        return [
            'type'       => 'object',
            'properties' => [
                'menu_slug'   => $outputSchema['properties']['menuSlug'],
                'page_title'  => $outputSchema['properties']['pageTitle'],
                'menu_title'  => $outputSchema['properties']['menuTitle'],
                'capability'  => $outputSchema['properties']['capability'],
                'position'    => $outputSchema['properties']['position'],
                'icon'        => $outputSchema['properties']['icon'],
                'description' => $outputSchema['properties']['description'],
                'parent'      => ['type' => 'string', 'description' => __('menu_slug of the parent option page, if this page should be a submenu item.', ACPT_PLUGIN_NAME)],
                'permissions' => ['type' => 'array'],
            ],
            'required'   => ['menu_slug', 'page_title', 'menu_title', 'capability', 'position'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the option page.', ACPT_PLUGIN_NAME);
    }
}
