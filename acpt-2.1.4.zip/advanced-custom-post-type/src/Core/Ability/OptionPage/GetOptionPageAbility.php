<?php

namespace ACPT\Core\Ability\OptionPage;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\OptionPageSchema;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetOptionPageAbility extends AbstractAbility
{
    protected static $schema = OptionPageSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-option-page';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get an option page', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT option page by its menu slug.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $slug = $input['menu_slug'] ?? null;

            if (empty($slug) || !OptionPageRepository::exists($slug)) {
                return null;
            }

            return OptionPageRepository::getByMenuSlug($slug)->toStdObject();
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['menu_slug' => ['type' => 'string']],
            'required'   => ['menu_slug'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
