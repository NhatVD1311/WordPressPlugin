<?php

namespace ACPT\Core\Ability\DynamicBlock;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\DynamicBlockSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;
use ACPT\Utils\PHP\Objects;

class GetDynamicBlockAbility extends AbstractAbility
{
    protected static $schema = DynamicBlockSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-block';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a dynamic block', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single ACPT dynamic block by name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            $block = get_acpt_block_object($input['name'] ?? null);

            return $block === false ? null : Objects::cast(\stdClass::class, $block);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => ['name' => ['type' => 'string']],
            'required'   => ['name'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
