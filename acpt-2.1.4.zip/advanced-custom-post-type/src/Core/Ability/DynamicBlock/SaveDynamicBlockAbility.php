<?php

namespace ACPT\Core\Ability\DynamicBlock;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\DynamicBlockSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;
use ACPT\Utils\PHP\Objects;

class SaveDynamicBlockAbility extends AbstractAbility
{
    protected static $schema = DynamicBlockSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-block';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a dynamic block', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new ACPT dynamic block, or updates the existing one if a block with the same name already exists.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): ?\stdClass {
            if (save_acpt_block($input) !== true) {
                return null;
            }

            $block = get_acpt_block_object($input['name'] ?? null);

            return $block === false ? null : Objects::cast(\stdClass::class, $block);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return self::schema();
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the dynamic block.', ACPT_PLUGIN_NAME);
    }
}
