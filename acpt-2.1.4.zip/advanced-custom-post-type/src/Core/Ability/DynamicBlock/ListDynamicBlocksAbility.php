<?php

namespace ACPT\Core\Ability\DynamicBlock;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\DynamicBlockSchema;
use ACPT\Core\Repository\DynamicBlockRepository;
use ACPT\Core\Ability\Categories\AbilityCategories;

class ListDynamicBlocksAbility extends AbstractAbility
{
    protected static $schema = DynamicBlockSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'list-blocks';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('List dynamic blocks', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns all ACPT dynamic blocks.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (): array {
            return array_map(function ($model): \stdClass {
                return $model->toStdObject();
            }, DynamicBlockRepository::get([]));
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::collection(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
