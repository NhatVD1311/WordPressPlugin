<?php

namespace ACPT\Core\Ability\FormField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\FormFieldSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class SaveFormFieldAbility extends AbstractAbility
{
    protected static $schema = FormFieldSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'save-form-field';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Create or update a form field', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Creates a new field on an ACPT form, or updates it if a field with the same name already exists on that form.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return save_acpt_form_field($input);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        $schema = self::schema();

        return array_merge($schema, [
            'properties' => array_merge($schema['properties'], [
                'formName' => ['type' => 'string', 'description' => __('The name of the form this field belongs to.', ACPT_PLUGIN_NAME)],
            ]),
            'required'   => array_merge($schema['required'], ['formName']),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to save the form field.', ACPT_PLUGIN_NAME);
    }
}
