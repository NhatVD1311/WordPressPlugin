<?php

namespace ACPT\Core\Ability\FormField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\JSON\FormFieldSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class GetFormFieldAbility extends AbstractAbility
{
    protected static $schema = FormFieldSchema::class;

    /**
     * @return string
     */
    public static function name(): string
    {
        return 'get-form-field';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Get a form field', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Returns a single field of an ACPT form by field name.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        // get_acpt_form_field_object() can return bool|null|\stdClass (false when required args
        // are missing, null when not found) - a genuine union PHP 7.4 can't express as a return
        // type, so this closure is left untyped.
        return function (array $input) {
            return get_acpt_form_field_object($input);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'formName'  => ['type' => 'string'],
                'fieldName' => ['type' => 'string'],
            ],
            'required'   => ['formName', 'fieldName'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::single(self::schema());
    }

    /**
     * @return bool
     */
    protected static function readonly(): bool
    {
        return true;
    }
}
