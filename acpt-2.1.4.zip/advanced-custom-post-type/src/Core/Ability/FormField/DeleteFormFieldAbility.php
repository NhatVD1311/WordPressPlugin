<?php

namespace ACPT\Core\Ability\FormField;

use ACPT\Core\Ability\AbstractAbility;
use ACPT\Core\Ability\Helpers\AbilityOutputSchema;
use ACPT\Core\Ability\Categories\AbilityCategories;

class DeleteFormFieldAbility extends AbstractAbility
{
    /**
     * @return string
     */
    public static function name(): string
    {
        return 'delete-form-field';
    }

    /**
     * @return string
     */
    public static function label(): string
    {
        return __('Delete a form field', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function description(): string
    {
        return __('Deletes a field from an ACPT form.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return string
     */
    public static function category(): string
    {
        return AbilityCategories::CONTENT_MODEL;
    }

    /**
     * @return callable
     */
    public static function callback(): callable
    {
        return function (array $input): bool {
            return delete_acpt_form_field($input);
        };
    }

    /**
     * @return array<string, mixed>
     */
    public static function input_schema(): array
    {
        return [
            'type'       => 'object',
            'properties' => [
                'formName'  => ['type' => 'string'],
                'fieldName' => ['type' => 'string'],
            ],
            'required'   => ['formName', 'fieldName'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function output_schema(): array
    {
        return AbilityOutputSchema::deleted();
    }

    /**
     * @return string
     */
    protected static function failureMessage(): string
    {
        return __('Unable to delete the form field.', ACPT_PLUGIN_NAME);
    }

    /**
     * @return bool
     */
    protected static function destructive(): bool
    {
        return true;
    }
}
