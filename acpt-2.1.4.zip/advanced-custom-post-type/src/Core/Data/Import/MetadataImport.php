<?php

namespace ACPT\Core\Data\Import;

use ACPT\Constants\FormatterFormat;
use ACPT\Core\Data\Import\Importer\MetadataJsonImporter;
use ACPT\Core\Data\Import\Importer\MetadataXMLImporter;
use ACPT\Core\Data\Import\Importer\MetadataYamlImporter;

class MetadataImport
{
    /**
     * @param mixed $newItemId
     * @param string $format
     * @param string $data
     *
     * @throws \Exception
     *
     * @return void
     */
    public static function import($newItemId, string $format, string $data): void
    {
        if (!in_array($format, FormatterFormat::ALLOWED_FORMATS)) {
            throw new \Exception($format . ' is not supported format');
        }

        $importer = self::getImporterInstance($format);
        $importer->importItem($newItemId, $data);
    }

    /**
     * Returns an instance of the appropriate importer based on the specified format.
     *
     * @param string $format The format string (e.g., JSON, XML, YAML) used to determine the importer instance.
     *
     * @return MetadataJsonImporter|MetadataXMLImporter|MetadataYamlImporter|void The importer instance corresponding to the specified format.
     */
    private static function getImporterInstance(string $format)
    {
        switch ($format) {
            case FormatterFormat::JSON_FORMAT:
                return new MetadataJsonImporter();

            case FormatterFormat::XML_FORMAT:
            return new MetadataXMLImporter();

            case FormatterFormat::YAML_FORMAT:
                return new MetadataYamlImporter();
        }
    }
}
