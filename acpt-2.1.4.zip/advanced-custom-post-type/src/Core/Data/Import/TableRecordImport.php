<?php

namespace ACPT\Core\Data\Import;

use ACPT\Core\Data\Import\Importer\TableRecordXMLImporter;

/**
 * Thin static entry point mirroring MetadataImport, for the `acpt_table_records`
 * WPAI addon field. XML-only — unlike MetadataImport, no other caller needs
 * JSON/YAML variants for this data shape, so there is no format-switching here.
 */
class TableRecordImport
{
    /**
     * @param mixed $newItemId
     * @throws \Exception
     */
    public static function import($newItemId, string $data): void
    {
        (new TableRecordXMLImporter())->importItem($newItemId, $data);
    }
}
