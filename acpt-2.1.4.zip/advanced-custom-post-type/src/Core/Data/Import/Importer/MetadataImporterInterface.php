<?php

namespace ACPT\Core\Data\Import\Importer;

interface MetadataImporterInterface
{
    /**
     * This function import a single metadata item
     *
     * @param mixed $newItemId
     * @param string $data
     *
     * @return void
     */
    public function importItem($newItemId, string $data): void;
}
