<?php

namespace ACPT\Core\Data\Import\Importer;

use ACPT\Core\API\V1\Controllers\TableRecordController;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\TableRecord;
use ACPT\Utils\Wordpress\Translator;

/**
 * Imports the XML produced by WPAETableRecordXmlFormatter (see
 * src/Integrations/WPAllExport/Helper/WPAETableRecordXmlFormatter.php) back
 * into CCT tables flagged `allow_multiple_records_per_host`, via the same
 * validated TableRecordController::create()/update() pipeline the REST API uses.
 *
 * Matching strategy — v1 limitation: the exported `<record id="X">` is the
 * source environment's ID, meaningless on a different install. Records are
 * matched by ORDINAL POSITION (Nth XML record <-> Nth existing record, both
 * ordered id ASC via TableRecordRepository::getAllForLocation()):
 *   - fewer existing records than the XML supplies -> extra incoming records are created
 *   - more existing records than the XML supplies  -> extras are left untouched, never deleted
 *   - reordering/partial deletions between two exports will misalign the mapping
 * This is an explicit, accepted tradeoff: the alternative is no multi-record
 * import at all, or unbounded duplicate growth on every re-run.
 */
class TableRecordXMLImporter
{
    /**
     * @param mixed $newItemId
     * @throws \Exception
     */
    public function importItem($newItemId, string $data): void
    {
        $previousSetting = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($data);
        libxml_clear_errors();
        libxml_use_internal_errors($previousSetting);

        if (!$xml) {
            throw new \Exception(Translator::translate('Wrong XML provided, exit'));
        }

        if ($xml->getName() !== 'acpt_table_records') {
            throw new \Exception(Translator::translate('Malformed XML provided, no <acpt_table_records> tag found'));
        }

        $belongsTo    = (string) $xml['belongsTo'];
        $locationRule = TableRecord::RULE_MAP[$belongsTo] ?? null;

        if ($locationRule === null) {
            return;
        }

        foreach ($xml->table as $tableXml) {
            $this->importTable((string) $tableXml['name'], $tableXml, $locationRule, $newItemId);
        }
    }

    /**
     * @param string $tableName
     * @param \SimpleXMLElement $tableXml
     * @param int $locationRule
     * @param mixed $newItemId
     * @return void
     * @throws \Exception
     */
    private function importTable(string $tableName, \SimpleXMLElement $tableXml, int $locationRule, $newItemId): void
    {
        $table = TableRepository::getByName($tableName);

        if ($table === null) {
            return;
        }

        $existingRecords = array_values(TableRecordRepository::getAllForLocation($table, $locationRule, (string) $newItemId));
        $controller       = new TableRecordController();
        $ordinal          = 0;

        foreach ($tableXml->record as $recordXml) {
            $columnData = $this->extractColumnData($recordXml);

            try {
                if (isset($existingRecords[$ordinal])) {
                    $controller->update($tableName, $existingRecords[$ordinal]->id, $columnData);
                } else {
                    $controller->create($tableName, array_merge($columnData, [
                        'locations' => [
                            ['location_rule' => $locationRule, 'location_value' => (string) $newItemId],
                        ],
                    ]));
                }
            } catch (\Exception $e) {
                do_action('acpt/error', $e);
            }

            $ordinal++;
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function extractColumnData(\SimpleXMLElement $recordXml): array
    {
        $data = [];

        foreach ($recordXml->column as $columnXml) {
            $name = (string) $columnXml['name'];
            $type = (string) $columnXml['type'];
            $raw  = (string) $columnXml;

            $data[$name] = $type === 'json' ? json_decode($raw, true) : $raw;
        }

        return $data;
    }
}
