<?php

namespace ACPT\Core\Data\Import\Importer;

use ACPT\Constants\FormatterFormat;
use ACPT\Constants\MetaTypes;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\Wordpress\Files;

abstract class AbstractImporter
{
    /**
     * @param string $groupName
     * @param string $groupLabel
     * @param array<string|int, mixed> $belongs
     *
     * @return void
     */
    protected function importGroupSettings(string $groupName, string $groupLabel, array $belongs = []): void
    {
        save_acpt_meta_group([
            'name' => $groupName,
            'label' => $groupLabel,
            'belongs' => $belongs,
        ]);
    }

    /**
     * @param string $groupName
     * @param string $boxName
     * @param string|null $boxLabel
     *
     * @return void
     */
    protected function importBoxSettings(string $groupName, string $boxName, ?string $boxLabel = null): void
    {
        save_acpt_meta_box([
            'groupName' => $groupName,
            'name' => $boxName,
            'label' => $boxLabel,
            'fields' => [],
        ]);
    }

    /**
     * @param string $format
     * @param callable|null $xmlAccessor
     * @param mixed $defaultValue
     * @return mixed|null
     */
    private function evaluateProp(string $format, ?callable $xmlAccessor = null, $defaultValue = null)
    {
        if ($format === FormatterFormat::XML_FORMAT) {
            $value = $xmlAccessor !== null ? $xmlAccessor() : null;
            return $value !== null ? $value->__toString() : null;
        }

        return $defaultValue;
    }

    /**
     * @param string $format
     * @param string $groupName
     * @param string $boxName
     * @param string $fieldName
     * @param string $fieldType
     * @param array<string, mixed>|\SimpleXMLElement|null $props
     * @param array<string, mixed>|\SimpleXMLElement|null $advancedOptions
     * @param array<string, mixed>|\SimpleXMLElement|null $visibilityConditions
     * @param array<string, mixed>|\SimpleXMLElement|null $relations
     * @param array<string, mixed>|\SimpleXMLElement|null $options
     * @param array<string, mixed>|\SimpleXMLElement|null $children
     * @param array<string, mixed>|\SimpleXMLElement|null $blocks
     *
     * @return void
     */
    protected function importFieldSettings(
        string $format,
        string $groupName,
        string $boxName,
        string $fieldName,
        string $fieldType,
        $props = null,
        $advancedOptions = null,
        $visibilityConditions = null,
        $relations = null,
        $options = null,
        $children = null,
        $blocks = null
    ): void {
        $payload = [
            'groupName' => $groupName,
            'box_name' => $boxName,
            'name' => $fieldName,
            'type' => $fieldType,
            'showInArchive' => ($this->evaluateProp($format, fn () => $props[0]->show_in_archive[0] ?? null, $props['show_in_archive'] ?? null) == '1'),
            'isRequired' => ($this->evaluateProp($format, fn () => $props[0]->required[0] ?? null, $props['required'] ?? null) == '1'),
            'defaultValue' => $this->evaluateProp($format, fn () => $props[0]->default_value[0] ?? null, $props['default_value'] ?? null),
            'description' => $this->evaluateProp($format, fn () => $props[0]->description[0] ?? null, $props['description'] ?? null),
            'advancedOptions' => [],
            'options' => [],
            'visibilityConditions' => [],
        ];

        if (!empty($options)) {
            foreach ($options as $option) {
                $payload['options'][] = [
                    'value' => $this->evaluateProp($format, fn () => $option->value[0] ?? null, $option['value'] ?? null),
                    'label' => $this->evaluateProp($format, fn () => $option->label[0] ?? null, $option['label'] ?? null),
                ];
            }
        }

        if (!empty($advancedOptions)) {
            foreach ($advancedOptions as $option) {
                $payload['advancedOptions'][] = [
                    'value' => $this->evaluateProp($format, fn () => $option->value[0] ?? null, $option['value'] ?? null),
                    'label' => $this->evaluateProp($format, fn () => $option->label[0] ?? null, $option['label'] ?? null),
                ];
            }
        }

        if (!empty($visibilityConditions)) {
            foreach ($visibilityConditions as $condition) {
                $payload['visibilityConditions'][] = [
                    'type' => $this->evaluateProp($format, fn () => $condition->type[0]->type[0] ?? null, $condition['type']['type'] ?? null),
                    'value' => $this->evaluateProp($format, fn () => $condition->value[0] ?? null, $condition['value'] ?? null),
                    'operator' => $this->evaluateProp($format, fn () => $condition->operator[0] ?? null, $condition['operator'] ?? null),
                    'logic' => $this->evaluateProp($format, fn () => $condition->logic[0] ?? null, $condition['logic'] ?? null),
                    'backEnd' => ($this->evaluateProp($format, fn () => $condition->backEnd[0] ?? null, $condition['backEnd'] ?? null) == 1),
                    'frontEnd' => ($this->evaluateProp($format, fn () => $condition->frontEnd[0] ?? null, $condition['frontEnd'] ?? null) == 1),
                ];
            }
        }

        $payload['quickEdit'] = ($this->evaluateProp($format, fn () => $props[0]->quick_edit[0] ?? null, $props['quick_edit'] ?? null) == '1');
        $payload['isFilterable'] = ($this->evaluateProp($format, fn () => $props[0]->is_filterable[0] ?? null, $props['is_filterable'] ?? null) == '1');
        $payload['children'] = [];
        $payload['relations'] = [];
        $payload['blocks'] = [];

        if (!empty($relations)) {
            foreach ($relations as $relation) { // @TODO questo non funziona, da rivedere
                $payload['relations'][] = [
                    'related_to' => [
                        'post_type' => $this->evaluateProp($format, fn () => $relation[0]->related_to[0]->post_type[0] ?? null, $relation['related_to']['post_type'] ?? null),
                        'box_name' => $this->evaluateProp($format, fn () => $relation[0]->related_to[0]->box_name[0] ?? null, $relation['related_to']['box_name'] ?? null),
                        'field_name' => $this->evaluateProp($format, fn () => $relation[0]->related_to[0]->field_name[0] ?? null, $relation['related_to']['field_name'] ?? null),
                    ],
                    'relation' => $this->evaluateProp($format, fn () => $relation[0]->relationship[0] ?? null, $relation['relationship'] ?? null),
                ];
            }
        }

        if (!empty($children)) {
            $payload['children'] = $this->formatChildrenFieldsSettings($format, $children);
        }

        if (!empty($blocks)) {
            foreach ($blocks as $block) {
                $blockName = $this->evaluateProp($format, fn () => $block->attributes()['name'][0] ?? null, $block['name'] ?? null);
                $blockLabel = $this->evaluateProp($format, fn () => $block->attributes()['label'][0] ?? null, $block['label'] ?? null);

                if (
                    !empty($blockName) &&
                    !empty($blockLabel)
                ) {
                    $payload['blocks'][] = [
                        'name' => $blockName,
                        'label' => $blockLabel,
                        'fields' => $this->formatChildrenFieldsSettings($format, $block)
                    ];
                }
            }
        }

        if (null === get_acpt_meta_field_object($boxName, $fieldName)) {
            save_acpt_meta_field($payload);
        }
    }

    /**
     * @param string $format
     * @param array<int|string, mixed>|\SimpleXMLElement $children
     *
     * @return array<int|string, mixed>
     */
    private function formatChildrenFieldsSettings(string $format, $children): array
    {
        $arrayOfChildrenFields = [];

        foreach ($children as $child) {
            $childFieldName = $this->evaluateProp($format, fn () => $child->attributes()['name'][0] ?? null, $child['name'] ?? null);
            $childFieldType = $this->evaluateProp($format, fn () => $child->attributes()['type'][0] ?? null, $child['type'] ?? null);

            if (
                empty($childFieldName) ||
                empty($childFieldType)
            ) {
                return [];
            }

            $childFieldProps = ($format === FormatterFormat::XML_FORMAT) ? $child->props[0] : $child['props'];
            $childFieldAdvancedOptions = ($format === FormatterFormat::XML_FORMAT) ? $child->advanced_options[0] : $child['advanced_options'];
            $childFieldVisibilityConditions = ($format === FormatterFormat::XML_FORMAT) ? $child->visibility_conditions[0] : $child['visibility_conditions'];
            $childFieldOptions = ($format === FormatterFormat::XML_FORMAT) ? $child->options[0] : $child['options'];

            $payloadOptions = [];
            $payloadAdvancedOptions = [];
            $payloadVisibilityConditions = [];

            if (!empty($childFieldOptions)) {
                foreach ($childFieldOptions as $option) {
                    $payloadOptions[] = [
                        'value' => $this->evaluateProp($format, fn () => $option->value[0] ?? null, $option['value'] ?? null),
                        'label' => $this->evaluateProp($format, fn () => $option->label[0] ?? null, $option['label'] ?? null),
                    ];
                }
            }

            if (!empty($childFieldAdvancedOptions)) {
                foreach ($childFieldAdvancedOptions as $option) {
                    $payloadAdvancedOptions[] = [
                        'value' => $this->evaluateProp($format, fn () => $option->value[0] ?? null, $option['value'] ?? null),
                        'key' => $this->evaluateProp($format, fn () => $option->key[0] ?? null, $option['key'] ?? null),
                    ];
                }
            }

            if (!empty($childFieldVisibilityConditions)) {
                foreach ($childFieldVisibilityConditions as $condition) {
                    $payloadVisibilityConditions[] = [
                        'type' => $this->evaluateProp($format, fn () => $condition->type[0]->type[0] ?? null, $condition['type']['type'] ?? null),
                        'value' => $this->evaluateProp($format, fn () => $condition->value[0] ?? null, $condition['value'] ?? null),
                        'operator' => $this->evaluateProp($format, fn () => $condition->operator[0] ?? null, $condition['operator'] ?? null),
                        'logic' => $this->evaluateProp($format, fn () => $condition->logic[0] ?? null, $condition['logic'] ?? null),
                    ];
                }
            }

            $arrayOfChildrenFields[] = [
                'name' => $childFieldName,
                'type' => $childFieldType,
                'isRequired' => ($this->evaluateProp($format, fn () => $childFieldProps[0]->required[0] ?? null, $childFieldProps['required'] ?? null) == 1),
                'defaultValue' => $this->evaluateProp($format, fn () => $childFieldProps[0]->default_value[0] ?? null, $childFieldProps['default_value'] ?? null),
                'description' => $this->evaluateProp($format, fn () => $childFieldProps[0]->description[0] ?? null, $childFieldProps['description'] ?? null),
                'options' => $payloadOptions,
                'advancedOptions' => $payloadAdvancedOptions,
                'visibilityConditions' => $payloadVisibilityConditions,
            ];
        }

        return $arrayOfChildrenFields;
    }

    /**
     * @param string $format
     * @param string $belongsTo
     * @param mixed $newItemId
     * @param string $boxName
     * @param string $fieldName
     * @param array<string, mixed>|\SimpleXMLElement $values
     */
    protected function importFieldMetadata(string $format, string $belongsTo, $newItemId, string $boxName, string $fieldName, $values): void
    {
        $value = $this->extractValues($format, $values);
        $key = null;

        switch ($belongsTo) {
            case MetaTypes::CUSTOM_POST_TYPE:
                $key = 'post_id';

                break;

            case MetaTypes::TAXONOMY:
                $key = 'term_id';

                break;

            case MetaTypes::USER:
                $key = 'user_id';
                break;
        }

        if ($key !== null) {
            save_acpt_meta_field_value([
                $key  => $newItemId,
                'box_name' => $boxName,
                'field_name' => $fieldName,
                'value' => $value,
                // an import restores data that was valid when it was written; a
                // validation rule added to the field afterwards must not block the restore.
                'skip_validation' => true,
            ]);
        }
    }

    /**
     * @param string $format
     * @param array<int|string, mixed>|\SimpleXMLElement $values
     *
     * @return mixed
     */
    private function extractValues(string $format, $values)
    {
        $fieldType = $this->evaluateProp($format, fn () => ($values instanceof \SimpleXMLElement) ? ($values->attributes()['type'][0] ?? null) : null, $values['type'] ?? null);

        switch ($fieldType) {

            case MetaFieldModel::ADDRESS_TYPE:
                return $this->evaluateProp($format, fn () => $values->value->address[0] ?? null, $values['value']['address'] ?? null);

            case MetaFieldModel::CHECKBOX_TYPE:
            case MetaFieldModel::LIST_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:

                $arrayOfValues = [];

                foreach ($values as $value) {
                    $arrayOfValues[] = $this->evaluateProp($format, fn () => $value[0] ?? null, $value);
                }

                return $arrayOfValues;

            case MetaFieldModel::CURRENCY_TYPE:

                $amount = $this->evaluateProp($format, fn () => $values->value->amount[0] ?? null, $values['value']['amount'] ?? null);
                $unit = $this->evaluateProp($format, fn () => $values->value->unit[0] ?? null, $values['value']['unit'] ?? null);

                return [
                    'amount' => (int)$amount,
                    'unit' => $unit,
                ];

            case MetaFieldModel::DATE_RANGE_TYPE:

                $from = $this->evaluateProp($format, fn () => $values->value->from[0] ?? null, $values['value']['from'] ?? null);
                $to = $this->evaluateProp($format, fn () => $values->value->to[0] ?? null, $values['value']['to'] ?? null);

                return [
                    $from,
                    $to
                ];

            case MetaFieldModel::FLEXIBLE_CONTENT_TYPE:

                $blocks = ($values instanceof \SimpleXMLElement) ? $values->blocks[0] : ($values['blocks'] ?? []);
                $blocksValues = [];
                $blockIndex = 0;

                foreach ($blocks as $block) {
                    $blockName = $this->evaluateProp($format, fn () => $block->attributes()['name'][0] ?? null, $block['name'] ?? null);
                    $fieldIndex = 0;

                    foreach ($block->values as $nestedValue) {
                        $nestedFieldName = $this->evaluateProp($format, fn () => $nestedValue->attributes()['name'][0] ?? null, $nestedValue['name'] ?? null);
                        $blocksValues[$blockIndex][$blockName][$fieldIndex][$nestedFieldName] = self::extractValues($format, $nestedValue);
                        $fieldIndex++;
                    }

                    $blockIndex++;
                }

                return [
                    'blocks' => $blocksValues
                ];

            case MetaFieldModel::FILE_TYPE:
                $src = $this->evaluateProp($format, fn () => $values->value->src[0] ?? null, $values['value']['src'] ?? null);
                $label = $this->evaluateProp($format, fn () => $values->value->label[0] ?? null, $values['value']['label'] ?? null);
                $file = Files::downloadFromUrl($src);

                if ($file) {
                    return [
                        'label' => $label,
                        'url' => $file['url'],
                    ];
                }

                return null;

            case MetaFieldModel::POST_TYPE:

                $arrayOfValues = [];

                foreach ($values as $postId) {
                    $arrayOfValues[] = $postId;
                }

                return $arrayOfValues;

            case MetaFieldModel::GALLERY_TYPE:

                $arrayOfValues = [];

                foreach ($values as $value) {
                    $src = $this->evaluateProp($format, fn () => $value[0]->src[0] ?? null, $value['src'] ?? null);
                    $file = Files::downloadFromUrl($src);

                    if ($file) {
                        $arrayOfValues[] = $file['url'];
                    } else {
                        $arrayOfValues[] = $src;
                    }
                }

                return $arrayOfValues;

            case MetaFieldModel::IMAGE_TYPE:
            case MetaFieldModel::VIDEO_TYPE:

                $src = $this->evaluateProp($format, fn () => $values->value->src[0] ?? null, $values['value']['src'] ?? null);
                $file = Files::downloadFromUrl($src);

                if ($file) {
                    return $file['url'];
                }

                return $src;

            case MetaFieldModel::LENGTH_TYPE:

                $length = $this->evaluateProp($format, fn () => $values->value->length[0] ?? null, $values['value']['length'] ?? null);
                $unit = $this->evaluateProp($format, fn () => $values->value->unit[0] ?? null, $values['value']['unit'] ?? null);

                return [
                    'length' => (int)$length,
                    'unit' => $unit,
                ];

            case MetaFieldModel::REPEATER_TYPE:

                $childrenValues = [];

                foreach ($values as $value) {
                    $arrayOfNestedValues = [];

                    if (is_array($value)) {
                        foreach ($value as $nestedValue) {
                            if ($nestedValue !== null) {
                                $nestedFieldName = $this->evaluateProp($format, fn () => $nestedValue->attributes()['name'][0] ?? null, $nestedValue['name'] ?? null);

                                if (!empty($nestedFieldName)) {
                                    $arrayOfNestedValues[$nestedFieldName] = self::extractValues($format, $nestedValue);
                                }
                            }
                        }
                    }

                    $childrenValues[] = $arrayOfNestedValues;
                }

                return $childrenValues;

            case MetaFieldModel::WEIGHT_TYPE:

                $weight = $this->evaluateProp($format, fn () => $values->value->weight[0] ?? null, $values['value']['weight'] ?? null);
                $unit = $this->evaluateProp($format, fn () => $values->value->unit[0] ?? null, $values['value']['unit'] ?? null);

                return [
                    'weight' => (int)$weight,
                    'unit' => $unit,
                ];

            case MetaFieldModel::URL_TYPE:

                $url = $this->evaluateProp($format, fn () => $values->value->url[0] ?? null, $values['value']['url'] ?? null);
                $label = $this->evaluateProp($format, fn () => $values->value->label[0] ?? null, $values['value']['label'] ?? null);

                return [
                    'url' => $url,
                    'label' => $label,
                ];

            default:
                return $this->evaluateProp($format, fn () => $values->value[0] ?? null, $values['value'][0] ?? null);
        }
    }
}
