<?php

namespace ACPT\Core\Data\Import\Importer;

use Symfony\Component\Yaml\Yaml;

class MetadataYamlImporter extends MetadataJsonImporter implements MetadataImporterInterface
{
    /**
     * @param mixed $newItemId
     * @param string $data
     *
     * @return void
     * @throws \Exception
     */
    public function importItem($newItemId, string $data): void
    {
        $parsed = Yaml::parse($data);

        $this->importParserItem($newItemId, $parsed);
    }
}
