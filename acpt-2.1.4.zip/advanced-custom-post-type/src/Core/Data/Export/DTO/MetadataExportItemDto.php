<?php

namespace ACPT\Core\Data\Export\DTO;

use ACPT\Core\Models\Meta\MetaGroupModel;

class MetadataExportItemDto
{
    /**
     * @var mixed
     */
    public $id;

    /**
     * @var string
     */
    public string $belongsTo;

    /**
     * @var string
     */
    public string $find;

    /**
     * @var MetaGroupModel[]
     */
    public array $metaGroups = [];
}
