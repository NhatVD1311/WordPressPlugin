<?php

namespace ACPT\Core\Data\Export\Generator;

use ACPT\Core\Data\Export\DTO\MetadataExportItemDto;
use ACPT\Core\Data\Export\Formatter\MetadataExportFormatterInterface;

interface MetadataExportGeneratorInterface
{
    /**
     * @return MetadataExportFormatterInterface
     */
    public function getFormatter(): MetadataExportFormatterInterface;

    /**
     * @param MetadataExportItemDto[] $items
     *
     * @return string
     */
    public function generate(array $items = []): string;
}
