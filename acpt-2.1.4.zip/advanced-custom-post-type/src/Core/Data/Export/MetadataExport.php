<?php

namespace ACPT\Core\Data\Export;

use ACPT\Constants\FormatterFormat;
use ACPT\Core\Data\Export\DTO\MetadataExportItemDto;
use ACPT\Core\Data\Export\Generator\MetadataExportJsonGenerator;
use ACPT\Core\Data\Export\Generator\MetadataExportXMLGenerator;
use ACPT\Core\Data\Export\Generator\MetadataExportYamlGenerator;

class MetadataExport
{
    /**
     * This function exports the metadata items into a file
     *
     * @param string $format
     * @param MetadataExportItemDto[] $items $items
     *
     * @return string
     * @throws \Exception
     */
    public static function export(string $format, array $items = []): string
    {
        if (!in_array($format, FormatterFormat::ALLOWED_FORMATS)) {
            throw new \Exception($format . ' is not supported format');
        }

        $generator = self::getGeneratorInstance($format);

        return $generator->generate($items);
    }

    /**
     * Creates and returns an instance of the appropriate generator based on the given format.
     *
     * @param string $format The format for which the generator instance is required. Supported formats are defined in FormatterFormat.
     *
     * @return MetadataExportJsonGenerator|MetadataExportXMLGenerator|MetadataExportYamlGenerator|void The generator instance specific to the provided format.
     */
    private static function getGeneratorInstance(string $format)
    {
        switch ($format) {
            case FormatterFormat::JSON_FORMAT:
                return new MetadataExportJsonGenerator();

            case FormatterFormat::XML_FORMAT:
            return new MetadataExportXMLGenerator();

            case FormatterFormat::YAML_FORMAT:
                return new MetadataExportYamlGenerator();
        }
    }
}
