<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Models\Permission\PermissionModel;
use ACPT\Core\Repository\PermissionRepository;

class SavePermissionCommand implements CommandInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * SavePermissionCommand constructor.
     *
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * Executes the command to update permissions for a specific entity.
     *
     * Deletes existing permissions associated with the entity, and if
     * new permissions are provided, iterates over them to create and
     * save new permission models.
     *
     * @return void
     */
    public function execute()
    {
        if (empty($this->data['entityId'])) {
            return;
        }

        PermissionRepository::deleteByEntityId($this->data['entityId']);

        if (empty($this->data['items'])) {
            return;
        }

        if (!is_array($this->data['items'])) {
            return;
        }

        foreach ($this->data['items'] as $index => $item) {
            if (!$this->validatePermission($item)) {
                continue;
            }

            $permissionModel = new PermissionModel(
                $item['id'],
                $this->data['entityId'],
                $item['userRole'],
                $item['permissions'],
                ($index+1)
            );

            PermissionRepository::save($permissionModel);
        }
    }

    /**
     * Validates the given permission data.
     *
     * @param array<string, mixed> $permission An associative array containing the permission details
     * with keys 'id', 'userRole', and 'permissions'.
     * @return bool Returns true if the permission data is valid, otherwise false.
     */
    protected function validatePermission(array $permission): bool
    {
        if (empty($permission['id'])) {
            return false;
        }

        if (empty($permission['userRole'])) {
            return false;
        }

        if (empty($permission['permissions'])) {
            return false;
        }

        return true;
    }
}
