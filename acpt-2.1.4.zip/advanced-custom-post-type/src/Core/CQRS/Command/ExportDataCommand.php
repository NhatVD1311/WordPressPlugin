<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\DatasetRepository;
use ACPT\Core\Repository\DynamicBlockRepository;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Utils\Data\Formatter\Formatter;

class ExportDataCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $format;

    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * ExportDataCommand constructor.
     *
     * @param string $format
     * @param array<string, mixed> $data
     */
    public function __construct(string $format, array $data)
    {
        $this->format = $format;
        $this->data = $data;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function execute(): string
    {
        $items = [
            MetaTypes::CUSTOM_POST_TYPE => [],
            MetaTypes::TAXONOMY => [],
            MetaTypes::OPTION_PAGE => [],
            MetaTypes::META => [],
            MetaTypes::TABLE => [],
            MetaTypes::TABLE_GROUP => [],
            MetaTypes::DYNAMIC_BLOCK => [],
            'form' => [],
            'dataset' => [],
        ];

        $format = $this->format;
        $dataToExport = $this->data;

        foreach ($dataToExport as $type => $data) {
            foreach ($data as $datum) {

                if ($datum['type'] === 'dataset' && $datum['checked'] === true) {
                    $datasetModel = DatasetRepository::getById($datum['id']);

                    if ($datasetModel !== null) {
                        $items['dataset'][] = $datasetModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === 'form' && $datum['checked'] === true) {
                    $formModel = FormRepository::getById($datum['id']);

                    if ($formModel !== null) {
                        $items['form'][] = $formModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::META && $datum['checked'] === true) {
                    $metaGroupModel = MetaRepository::get([
                        'id' => $datum['id']
                    ])[0] ?? null;

                    if ($metaGroupModel !== null) {
                        $items[MetaTypes::META][] = $metaGroupModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::CUSTOM_POST_TYPE && $datum['checked'] === true) {
                    $customPostTypeModel = CustomPostTypeRepository::get([
                        'id' => $datum['id']
                    ])[0] ?? null;

                    if ($customPostTypeModel !== null) {
                        $items[MetaTypes::CUSTOM_POST_TYPE][] = $customPostTypeModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::TAXONOMY && $datum['checked'] === true) {
                    $taxonomyModel = TaxonomyRepository::get([
                        'id' => $datum['id']
                    ])[0] ?? null;

                    if ($taxonomyModel !== null) {
                        $items[MetaTypes::TAXONOMY][] = $taxonomyModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::OPTION_PAGE && $datum['checked'] === true) {
                    $optionPageModel = OptionPageRepository::getById($datum['id']);

                    if ($optionPageModel !== null) {
                        $items[MetaTypes::OPTION_PAGE][] = $optionPageModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::TABLE && $datum['checked'] === true) {
                    $tableModel = TableRepository::getById($datum['id']);

                    if ($tableModel !== null) {
                        $items[MetaTypes::TABLE][] = $tableModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::TABLE_GROUP && $datum['checked'] === true) {
                    $tableGroupModel = TableGroupRepository::getById($datum['id']);

                    if ($tableGroupModel !== null) {
                        $items[MetaTypes::TABLE_GROUP][] = $tableGroupModel->arrayRepresentation();
                    }
                }

                if ($datum['type'] === MetaTypes::DYNAMIC_BLOCK && $datum['checked'] === true) {
                    $blockModel = DynamicBlockRepository::getById($datum['id']);

                    if ($blockModel !== null) {
                        $items[MetaTypes::DYNAMIC_BLOCK][] = $blockModel->arrayRepresentation();
                    }
                }
            }
        }

        return Formatter::format($format, $items);
    }
}
