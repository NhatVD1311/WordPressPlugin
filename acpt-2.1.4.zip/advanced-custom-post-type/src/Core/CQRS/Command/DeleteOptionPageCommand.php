<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\OptionPageRepository;

class DeleteOptionPageCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DeleteMetaGroupCommand constructor.
     *
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $optionPage = OptionPageRepository::getById($this->id);

        if (!empty($optionPage)) {
            OptionPageRepository::delete($optionPage);
        }
    }
}
