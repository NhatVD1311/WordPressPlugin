<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Integrations\WooCommerce\ACPT_WooCommerce;
use ACPT\Utils\PHP\Request;

class SaveWooCommerceProductAttributeMetaCommand extends AbstractSaveMetaCommand implements CommandInterface
{
    /**
     * @var int
     */
    private int $attributeId;

    /**
     * @var string
     */
    private string $attributeName;

    /**
     * SaveWooCommerceProductAttributeMetaCommand constructor.
     *
     * @param int     $attributeId
     * @param Request $request
     */
    public function __construct(int $attributeId, Request $request)
    {
        parent::__construct($request);
        $this->attributeId = $attributeId;
        $this->attributeName = ACPT_WooCommerce::getWooCommerceProductAttributeName($attributeId);
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $metaGroups = MetaRepository::get([
            'belongsTo' => MetaTypes::TAXONOMY,
            'find' => $this->attributeName,
            'clonedFields' => true,
        ]);

        $fieldEntries = [];

        foreach ($metaGroups as $metaGroup) {
            foreach ($metaGroup->getBoxes() as $boxModel) {
                foreach ($boxModel->getFields() as $fieldModel) {
                    if ($this->hasField($fieldModel)) {
                        $fieldModel->setBelongsToLabel(MetaTypes::OPTION_PAGE);
                        $fieldModel->setFindLabel($this->attributeName);
                        $fieldModel->setIsAWooCommerceProductAttribute(true);
                        $elementId = "wc_attribute_" . Strings::toDBFormat($fieldModel->getBox()->getName()) . '_' . Strings::toDBFormat($fieldModel->getName()) . "_" . $this->attributeId;

                        $fieldEntries[] = [
                            'field'     => $fieldModel,
                            'elementId' => $elementId,
                            'belongsTo' => MetaTypes::OPTION_PAGE,
                        ];
                    }
                }
            }
        }

        $this->validateAndSaveFields($fieldEntries);
    }
}
