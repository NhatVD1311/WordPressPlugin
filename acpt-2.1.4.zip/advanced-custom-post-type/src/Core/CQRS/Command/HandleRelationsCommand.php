<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\MetaTypes;
use ACPT\Constants\Relationships;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Meta\MetaFieldRelationshipModel;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Includes\ACPT_DB;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\Serializer;

class HandleRelationsCommand implements CommandInterface
{
    /**
     * @var MetaFieldModel
     */
    private MetaFieldModel $fieldModel;

    /**
     * @var mixed
     */
    private $rawValue;

    /**
     * @var mixed
     */
    private $entityId;

    /**
     * @var string
     */
    private string $entityType;

    /**
     * HandleRelationsCommand constructor.
     *
     * @param MetaFieldModel $fieldModel
     * @param mixed          $rawValue
     * @param mixed          $entityId
     * @param string         $entityType
     */
    public function __construct(MetaFieldModel $fieldModel, $rawValue, $entityId, string $entityType)
    {
        $this->fieldModel = $fieldModel;
        $this->rawValue = $rawValue;
        $this->entityId = $entityId;
        $this->entityType = $entityType;
    }

    /**
     * @inheritDoc
     * @throws \Exception
     */
    public function execute()
    {
        if (empty($this->fieldModel->getRelations())) {
            do_action("acpt/error", new \Exception(
                "Value discarded for POST_TYPE field '{$this->fieldModel->getName()}': no relation is configured, so there is nothing to save it against"
            ));

            return;
        }

        ACPT_DB::flushCache();

        $fieldType = $this->fieldModel->getType();
        $idName = $this->fieldModel->getDbName();
        $relation = $this->fieldModel->getRelations()[0];
        $rawValues = is_array($this->rawValue) ? $this->rawValue : explode(",", $this->rawValue);

        // For CCT entities, encode as "{tableName}:{recordId}" so Meta can route correctly.
        $entityId = ($this->entityType === MetaTypes::TABLE)
            ? $relation->from()->getValue() . ':' . $this->entityId
            : $this->entityId;

        if (empty($this->rawValue)) {
            Meta::delete($entityId, $this->entityType, $idName);
            Meta::delete($entityId, $this->entityType, $idName.'_id');
            Meta::delete($entityId, $this->entityType, $idName.'_type');
        } else {
            Meta::save($entityId, $this->entityType, $idName, Sanitizer::sanitizeRawData($fieldType, $rawValues));
            Meta::save($entityId, $this->entityType, $idName.'_id', $this->fieldModel->getId());
            Meta::save($entityId, $this->entityType, $idName.'_type', MetaFieldModel::POST_TYPE);
        }

        // Handle bidirectional relations
        if ($relation->getInversedBy()) {
            $this->handleInversedRelation($relation, $rawValues);
        }
    }

    /**
     * Handle bidirectional relations
     *
     * @param MetaFieldRelationshipModel $relation
     * @param mixed $rawValues
     *
     * @throws \Exception
     */
    private function handleInversedRelation(MetaFieldRelationshipModel $relation, $rawValues): void
    {
        try {
            $belongsTo = $relation->to()->getType();
            $inversedTableName = ($belongsTo === MetaTypes::TABLE) ? $relation->to()->getValue() : null;
            $fieldName = $relation->getMetaField()->getDbName();
            $inversedFieldModel = $relation->getInversedBy();
            $inversedIdName = $inversedFieldModel->getDbName();
            $inversedFieldRelationship = $relation->getOppositeRelationship();
            $savedValues = [];

            // save values on other fields
            foreach ($rawValues as $id) {
                if (!empty($id)) {
                    $id = (is_numeric($id)) ? (int)$id : $id;

                    // For CCT entities on the "to" side, encode as "{tableName}:{id}" for Meta routing.
                    $metaId = ($belongsTo === MetaTypes::TABLE)
                        ? $relation->to()->getValue() . ':' . $id
                        : $id;

                    // append values if the opposite is MULTI, otherwise override
                    $getValue = Meta::fetch($metaId, $belongsTo, $inversedIdName);
                    $savedValues = (!empty($getValue) && is_array($getValue)) ? $getValue : [];

                    // is a post ID, term ID or user ID
                    if (is_numeric($this->entityId) || $this->entityType === MetaTypes::TABLE) {
                        $savedValues[] = $this->entityId;
                    } elseif (isset($this->optionPageModel)) { // is an option page
                        $savedValues[] = $this->optionPageModel->getId();
                    }

                    $savedValues = array_unique($savedValues);

                    // If $belongsTo is OPTION_PAGE, then $inversedIdName needs to be prefixed
                    if ($belongsTo === MetaTypes::OPTION_PAGE) {
                        $page = OptionPageRepository::getById($id, true);

                        if ($page !== null) {
                            $inversedIdName = $page->getMenuSlug().'_'.$inversedIdName;
                        }
                    }

                    if (!empty($savedValues)) {
                        Meta::save($metaId, $belongsTo, $inversedIdName, Sanitizer::sanitizeRawData($inversedFieldModel->getType(), $savedValues));
                        Meta::save($metaId, $belongsTo, $inversedIdName.'_id', $inversedFieldModel->getId());
                        Meta::save($metaId, $belongsTo, $inversedIdName.'_type', $inversedFieldModel->getType());
                    }
                }
            }

            // If we are adding elements...
            if ($belongsTo === MetaTypes::TABLE && $inversedTableName !== null) {
                $this->cleanupCCTInversedRelations($inversedTableName, $inversedIdName, $rawValues);
            } elseif (Arrays::count($savedValues) <= Arrays::count($rawValues)) {
                $this->handleRelatedEntities(
                    $inversedFieldRelationship,
                    $belongsTo,
                    $fieldName,
                    $inversedIdName,
                    $rawValues,
                    $savedValues
                );
            }
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);
        }
    }

    /**
     * @param string $inversedFieldRelationship
     * @param string $inversedFieldMetaType
     * @param string $fieldName
     * @param string $inversedFieldName
     * @param array<int, mixed> $rawValues
     * @param array<int, mixed> $savedValues
     *
     * @throws \Exception
     */
    private function handleRelatedEntities(
        string $inversedFieldRelationship,
        string $inversedFieldMetaType,
        string $fieldName,
        string $inversedFieldName,
        array $rawValues = [],
        array $savedValues = []
    ): void {
        switch ($inversedFieldRelationship) {

            // 1<-->1 BI
            case Relationships::ONE_TO_ONE_BI:
                $this->handleOneToOneInversedRelation($fieldName, $inversedFieldMetaType, $inversedFieldName, $savedValues, $rawValues);
                break;

                // M<-->1 BI
            case Relationships::MANY_TO_ONE_BI:
                $this->handleManyToOneOneInversedRelation($fieldName, $inversedFieldMetaType, $inversedFieldName, $savedValues, $rawValues);
                break;

                // 1<-->M BI
            case Relationships::ONE_TO_MANY_BI:
                $this->handleOneToManyInversedRelation($fieldName, $inversedFieldMetaType, $inversedFieldName, $savedValues, $rawValues);
                break;

                // M<-->M BI
            case Relationships::MANY_TO_MANY_BI:
                $this->handleManyToManyInversedRelation($fieldName, $inversedFieldMetaType, $inversedFieldName, $savedValues, $rawValues);
                break;

        }
    }

    /**
     * @param string $fieldName
     * @param string $inversedFieldMetaType
     * @param string $inversedFieldName
     * @param mixed  $savedValues
     * @param mixed  $rawValues
     *
     * @throws \Exception
     */
    private function handleOneToOneInversedRelation(
        string $fieldName,
        string $inversedFieldMetaType,
        string $inversedFieldName,
        $savedValues,
        $rawValues
    ): void {
        if (empty($savedValues)) {
            Meta::deleteBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
                'value' => serialize([$this->entityId])
            ]);

            Meta::deleteBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
                'value' => serialize([(string)$this->entityId])
            ]);
        } else {
            $this->checkAndRemoveDuplicates($this->fieldModel->getType(), $fieldName, $rawValues);
            $this->checkAndRemoveDuplicates($inversedFieldMetaType, $inversedFieldName, $savedValues);
        }
    }

    /**
     * @param string $fieldName
     * @param string $inversedFieldMetaType
     * @param string $inversedFieldName
     * @param mixed  $savedValues
     * @param mixed  $rawValues
     *
     * @throws \Exception
     */
    private function handleOneToManyInversedRelation(
        string $fieldName,
        string $inversedFieldMetaType,
        string $inversedFieldName,
        $savedValues,
        $rawValues
    ): void {
        if (empty($savedValues)) {
            $relationsToBeUpdated = Meta::fetchBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
            ]);

            if (!empty($relationsToBeUpdated)) {
                foreach ($relationsToBeUpdated as $relationsToBeUpdate) {
                    $value = $relationsToBeUpdate->meta_value ?? $relationsToBeUpdate->option_value;
                    $value = Serializer::unserialize($value);

                    if (is_array($value)) {
                        $value = array_filter($value, function ($item) {
                            return $item != $this->entityId;
                        });

                        if (empty($value)) {
                            Meta::deleteByMetaId($inversedFieldMetaType, ($relationsToBeUpdate->meta_id ?? $relationsToBeUpdate->option_id));
                        } else {
                            $id = $relationsToBeUpdate->post_id ?? $relationsToBeUpdate->term_id ?? $relationsToBeUpdate->user_id ?? $relationsToBeUpdate->option_name;
                            Meta::save($id, $inversedFieldMetaType, $inversedFieldName, $value);
                        }
                    }
                }
            }
        } else {
            $id = ($inversedFieldMetaType !== MetaTypes::OPTION_PAGE) ? (int)$rawValues[0] : $rawValues[0];
            $relationsToBeUpdated = Meta::fetchBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
                'id'  => $id,
            ]);

            if (!empty($relationsToBeUpdated)) {
                foreach ($relationsToBeUpdated as $relationsToBeUpdate) {

                    // append $value here
                    $value = $relationsToBeUpdate->meta_value ?? $relationsToBeUpdate->option_value;
                    $value = Serializer::unserialize($value);
                    $value = array_merge($value, $savedValues);
                    $value = array_unique($value);

                    $id = $relationsToBeUpdate->post_id ?? $relationsToBeUpdate->term_id ?? $relationsToBeUpdate->user_id ?? $relationsToBeUpdate->option_name;
                    Meta::save($id, $inversedFieldMetaType, $inversedFieldName, $value);
                }
            }
        }
    }

    /**
     * @param string $fieldName
     * @param string $inversedFieldMetaType
     * @param string $inversedFieldName
     * @param mixed  $savedValues
     * @param mixed  $rawValues
     *
     * @throws \Exception
     */
    private function handleManyToOneOneInversedRelation(
        string $fieldName,
        string $inversedFieldMetaType,
        string $inversedFieldName,
        $savedValues,
        $rawValues
    ): void {
        if (empty($savedValues)) {
            Meta::deleteBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
                'value' => serialize([$this->entityId])
            ]);

            Meta::deleteBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
                'value' => serialize([(string)$this->entityId])
            ]);
        } else {
            $relationsToBeDeleted = Meta::fetchBy($inversedFieldMetaType, [
                'meta_id_not_in' => $rawValues,
                'key' => $inversedFieldName,
                'value' => serialize([$this->entityId])
            ]);

            if (empty($relationsToBeDeleted)) {
                $relationsToBeDeleted = Meta::fetchBy($inversedFieldMetaType, [
                    'meta_id_not_in' => $rawValues,
                    'key' => $inversedFieldName,
                    'value' => serialize([(string)$this->entityId])
                ]);
            }

            foreach ($relationsToBeDeleted as $item) {
                Meta::deleteByMetaId($inversedFieldMetaType, ($item->meta_id ?? $item->option_id));
            }
        }
    }

    /**
     * @param string $fieldName
     * @param string $inversedFieldMetaType
     * @param string $inversedFieldName
     * @param mixed  $savedValues
     * @param mixed  $rawValues
     *
     * @throws \Exception
     */
    private function handleManyToManyInversedRelation(
        string $fieldName,
        string $inversedFieldMetaType,
        string $inversedFieldName,
        $savedValues,
        $rawValues
    ): void {
        if (empty($savedValues)) {
            $relationsToBeUpdated = Meta::fetchBy($inversedFieldMetaType, [
                'key' => $inversedFieldName,
            ]);

            if (!empty($relationsToBeUpdated)) {
                foreach ($relationsToBeUpdated as $relationsToBeUpdate) {
                    $value = $relationsToBeUpdate->meta_value ?? $relationsToBeUpdate->option_value;
                    $value = Serializer::unserialize($value);

                    if (is_array($value)) {
                        $value = array_filter($value, function ($item) {
                            return $item != $this->entityId;
                        });

                        if (empty($value)) {
                            Meta::deleteByMetaId($inversedFieldMetaType, ($relationsToBeUpdate->meta_id ?? $relationsToBeUpdate->option_id));
                        } else {
                            $id = $relationsToBeUpdate->post_id ?? $relationsToBeUpdate->term_id ?? $relationsToBeUpdate->user_id ?? $relationsToBeUpdate->option_name;
                            Meta::save($id, $inversedFieldMetaType, $inversedFieldName, $value);
                        }
                    }
                }
            }
        } else {
            $rawValues = (is_array($rawValues)) ? $rawValues : explode(",", $rawValues);

            $relationsToBeUpdated = Meta::fetchBy($inversedFieldMetaType, [
                'meta_id_not_in' => $rawValues,
                'key' => $inversedFieldName,
            ]);

            if (!empty($relationsToBeUpdated)) {
                foreach ($relationsToBeUpdated as $relationsToBeUpdate) {

                    // append $value here
                    $value = $relationsToBeUpdate->meta_value ?? $relationsToBeUpdate->option_value;
                    $value = Serializer::unserialize($value);

                    if (is_array($value)) {
                        $value = array_filter($value, function ($item) {
                            return $item != $this->entityId;
                        });

                        $id = $relationsToBeUpdate->post_id ?? $relationsToBeUpdate->term_id ?? $relationsToBeUpdate->user_id ?? $relationsToBeUpdate->option_name;
                        if (in_array($id, $rawValues)) {
                            $rawValue = ($relationsToBeUpdate->meta_value ?? $relationsToBeUpdate->option_value);
                            $rawValue = Serializer::unserialize($rawValue);
                            $value = array_merge($value, $rawValue);
                        }

                        if (empty($value)) {
                            Meta::deleteByMetaId($inversedFieldMetaType, ($relationsToBeUpdate->meta_id ?? $relationsToBeUpdate->option_id));
                        } else {
                            Meta::save($id, $inversedFieldMetaType, $inversedFieldName, $value);
                        }
                    }
                }
            }
        }
    }

    /**
     * Remove stale back-references from CCT records after a bidirectional relation save.
     * Finds all records in $tableName whose $columnName JSON array contains $this->entityId
     * but whose id is NOT in the newly-selected $rawValues, then strips the entity ID from them.
     *
     * @param string $tableName
     * @param string $columnName
     * @param array<int, mixed> $rawValues
     */
    private function cleanupCCTInversedRelations(string $tableName, string $columnName, array $rawValues): void
    {
        global $wpdb;
        $table    = ACPT_DB::prefixedTableName($tableName);
        $entityId = (string)$this->entityId;
        $args     = ['%' . $wpdb->esc_like('"' . $entityId . '"') . '%'];

        $sql = "SELECT `id`, `{$columnName}` FROM `{$table}` WHERE `{$columnName}` LIKE %s";

        if (!empty($rawValues)) {
            $placeholders = implode(',', array_fill(0, count($rawValues), '%s'));
            $sql .= " AND `id` NOT IN ({$placeholders})";
            $args = array_merge($args, array_values($rawValues));
        }

        $records = ACPT_DB::getResults($sql, $args);

        foreach ($records as $record) {
            /** @var \stdClass $record */
            $current = json_decode((string)($record->{$columnName} ?? ''), true);
            $current = is_array($current) ? $current : [];
            $updated = array_values(array_filter($current, fn ($v) => $v != $entityId));
            $metaId  = $tableName . ':' . $record->id;

            if (empty($updated)) {
                Meta::delete($metaId, MetaTypes::TABLE, $columnName);
            } else {
                Meta::save($metaId, MetaTypes::TABLE, $columnName, $updated);
            }
        }
    }

    /**
     * @param string $fieldType
     * @param string $fieldName
     * @param mixed  $values
     *
     * @throws \Exception
     */
    private function checkAndRemoveDuplicates(string $fieldType, string $fieldName, $values): void
    {
        $results = Meta::fetchBy($fieldType, [
            'key' => $fieldName
        ]);

        if (!empty($results)) {
            $duplicates = [];

            foreach ($results as $result) {
                $savedMetaValue = Serializer::unserialize($result->meta_value);
                if ($savedMetaValue == $values) {
                    $duplicates[] = (isset($result->meta_id)) ? (int)$result->meta_id : (int)$result->option_id;
                }
            }

            if (Arrays::count($duplicates) > 1) {
                Meta::deleteByMetaId($fieldType, $duplicates[0]);
            }
        }
    }
}
