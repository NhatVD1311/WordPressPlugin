<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\MetaTypes;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaGroupModel;
use ACPT\Core\Models\OptionPage\OptionPageModel;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\PHP\Session;
use ACPT\Utils\Wordpress\Translator;

class SaveOptionPageMetaCommand extends AbstractSaveMetaCommand implements CommandInterface
{
    /**
     * @var string
     */
    protected string $sessionKey;

    /**
     * @var OptionPageModel
     */
    protected OptionPageModel $optionPageModel;

    /**
     * @var MetaGroupModel[]
     */
    private array $metaGroups;

    /**
     * SaveOptionPageMetaCommand constructor.
     *
     * @param string $sessionKey
     * @param OptionPageModel $optionPageModel
     * @param array<int, mixed> $metaGroups
     * @param Request $request
     */
    public function __construct(string $sessionKey, OptionPageModel $optionPageModel, Request $request, array $metaGroups = [])
    {
        parent::__construct($request);
        $this->sessionKey      = $sessionKey;
        $this->optionPageModel = $optionPageModel;
        $this->metaGroups      = $metaGroups;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $fieldEntries = [];

        foreach ($this->metaGroups as $metaGroup) {

            // CCT
            if ($metaGroup->isCCTCopy()) {
                $this->saveCCTData($metaGroup, [
                    'page' => $this->optionPageModel->getMenuSlug(),
                ]);
            } else {
                foreach ($metaGroup->getBoxes() as $boxModel) {
                    foreach ($boxModel->getFields() as $fieldModel) {
                        if (!$this->hasField($fieldModel)) {
                            continue;
                        }

                        $fieldModel->setBelongsToLabel(MetaTypes::OPTION_PAGE);
                        $fieldModel->setFindLabel($this->optionPageModel->getMenuSlug());

                        $elementId = Strings::toDBFormat($this->optionPageModel->getMenuSlug());

                        $fieldEntries[] = [
                            'field'     => $fieldModel,
                            'elementId' => $elementId,
                            'belongsTo' => MetaTypes::OPTION_PAGE,
                        ];
                    }
                }
            }
        }

        $this->validateAndSaveFields($fieldEntries);
        $sessionData = Session::get($this->sessionKey) ?? [];

        Session::set($this->sessionKey, [
            ...$sessionData,
            'success' => [...$sessionData['success'] ?? [], Translator::translate('Data saved correctly')],
        ]);
    }
}
