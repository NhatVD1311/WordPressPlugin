<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Validators\ArgumentsArrayValidator;

class CopyOptionPageCommand
{
    /**
     * @var string
     */
    private string $targetPageId;

    /**
     * @var string
     */
    private string $pageId;

    /**
     * @var bool
     */
    private bool $deletePage;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $validationRules = [
            'targetPageId' => [
                'required' => true,
                'type' => 'string',
            ],
            'pageId' => [
                'required' => true,
                'type' => 'string',
            ],
            'deletePage' => [
                'required' => false,
                'type' => 'boolean',
            ],
        ];

        $validator = new ArgumentsArrayValidator();

        if (!$validator->validate($validationRules, $data)) {
            throw new \InvalidArgumentException($validator->errorMessage());
        }

        $this->targetPageId = (string)$data['targetPageId'];
        $this->pageId       = (string)$data['pageId'];
        $this->deletePage   = isset($data['deletePage']) && (bool)$data['deletePage'];
    }
    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $targetPage = OptionPageRepository::getById($this->targetPageId);
        $page = OptionPageRepository::getById($this->pageId);

        if ($targetPage === null) {
            throw new \Exception("Parent page not found");
        }

        if ($page === null) {
            throw new \Exception("Target page not found");
        }

        // don't copy first level pages
        if ($page->hasChildren()) {
            return;
        }

        $newPage = $page->duplicate();
        $newPage->changeParentId($this->targetPageId);
        $targetPage->addChild($newPage);

        OptionPageRepository::save($targetPage);

        if ($this->deletePage) {
            OptionPageRepository::delete($page);
        }
    }
}
