<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\DatasetRepository;

class DuplicateDatasetCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DuplicateDatasetCommand constructor.
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $datasetModel = DatasetRepository::getById($this->id);

        if (empty($datasetModel)) {
            throw new \Exception("Dataset not found");
        }

        $newDatasetModel = $datasetModel->duplicate();

        DatasetRepository::save($newDatasetModel);
    }
}
