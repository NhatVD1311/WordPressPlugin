<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\MetaTypes;
use ACPT\Constants\TableField;
use ACPT\Utils\Data\Meta;

class SaveTableTemplateCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $name;

    /**
     * @var array<string, mixed>
     */
    private array $json;

    /**
     * SaveTableTemplateCommand constructor.
     *
     * @param string $name
     * @param array<string, mixed> $json
     */
    public function __construct(string $name, array $json)
    {
        $this->name = $name;
        $this->json = $json;
    }

    /**
     * @return bool
     */
    public function execute(): bool
    {
        $key = TableField::DB_KEY . "_" . $this->name;

        return Meta::save($key, MetaTypes::OPTION_PAGE, $key, $this->json);
    }
}
