<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\ApiKey\ApiKeyModel;
use ACPT\Core\Repository\ApiRepository;

class GenerateApiKeyCommand implements CommandInterface
{
    /**
     * @var int
     */
    private int $uid;

    /**
     * GenerateApiKeyCommand constructor.
     *
     * @param int $uid
     */
    public function __construct(int $uid)
    {
        $this->uid = $uid;
    }

    /**
     * @return ApiKeyModel
     * @throws \Exception
     */
    public function execute(): ApiKeyModel
    {
        $apiKey = Strings::randomString();
        $apiSecret = Strings::randomString();
        $now = new \DateTime();

        $apiKeyModel = ApiKeyModel::hydrateFromArray([
            'uid' => $this->uid,
            'key' => $apiKey,
            'secret' => $apiSecret,
            'createdAt' => $now,
        ]);

        ApiRepository::save($apiKeyModel);

        return $apiKeyModel;
    }
}
