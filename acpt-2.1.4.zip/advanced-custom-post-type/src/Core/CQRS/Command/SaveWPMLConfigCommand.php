<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Integrations\WPML\Helper\WPMLConfig;
use ACPT\Integrations\WPML\Provider\MetaFieldsProvider;

class SaveWPMLConfigCommand implements CommandInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data = [];

    /**
     * SaveWPMLConfigCommand constructor.
     *
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $data = (isset($this->data['resetDefault']) && $this->data['resetDefault'] === true) ? MetaFieldsProvider::getInstance(true)->getFields() : $this->data;

        WPMLConfig::generate($data);
    }
}
