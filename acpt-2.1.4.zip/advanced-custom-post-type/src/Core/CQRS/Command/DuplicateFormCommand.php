<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\FormRepository;

class DuplicateFormCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DuplicateFormCommand constructor.
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $formModel = FormRepository::getById($this->id);

        if (empty($formModel)) {
            throw new \Exception("Form not found");
        }

        $newDatasetModel = $formModel->duplicate();

        FormRepository::save($newDatasetModel);
    }
}
