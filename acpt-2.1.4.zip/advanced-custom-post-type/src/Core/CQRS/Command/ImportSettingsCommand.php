<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\ImportRepository;

class ImportSettingsCommand implements CommandInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data = [];

    /**
     * ImportSettingsCommand constructor.
     *
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * Executes the import process for the provided data.
     *
     * @return void
     */
    public function execute(): void
    {
        ImportRepository::import($this->data);
    }
}
