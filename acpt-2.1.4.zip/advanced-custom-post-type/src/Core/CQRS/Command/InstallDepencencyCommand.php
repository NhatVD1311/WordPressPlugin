<?php

namespace ACPT\Core\CQRS\Command;

class InstallDepencencyCommand implements CommandInterface
{
    private string $dependency;

    /**
     * @param string $dependency
     */
    public function __construct(string $dependency)
    {
        $this->dependency = $dependency;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public function execute(): bool
    {
        $downloadUrl = null;
        $deleteFile = true;

        switch ($this->dependency) {
            case "predis":
                $downloadUrl = "https://github.com/predis/predis/archive/refs/tags/v2.4.0.zip";
                break;
        }

        if (empty($downloadUrl)) {
            throw new \Exception("Unknown dependency and download url");
        }

        $zipFile = ACPT_PLUGIN_DIR_PATH . "/dependencies/" . $this->dependency . "/" . $this->dependency . ".zip";

        if (!is_dir(ACPT_PLUGIN_DIR_PATH . "/dependencies/")) {
            mkdir(ACPT_PLUGIN_DIR_PATH . "/dependencies/");

            if (!is_dir(ACPT_PLUGIN_DIR_PATH . "/dependencies/")) {
                throw new \Exception("Can't create directory " . ACPT_PLUGIN_DIR_PATH . "/dependencies/");
            }
        }

        if (!is_dir(ACPT_PLUGIN_DIR_PATH . "/dependencies/". $this->dependency . "/")) {
            mkdir(ACPT_PLUGIN_DIR_PATH . "/dependencies/". $this->dependency . "/");

            if (!is_dir(ACPT_PLUGIN_DIR_PATH . "/dependencies/". $this->dependency . "/")) {
                throw new \Exception("Can't create directory " . ACPT_PLUGIN_DIR_PATH . "/dependencies/". $this->dependency . "/");
            }
        }

        if (!is_file($zipFile)) {
            touch($zipFile);
        }

        $write = file_put_contents($zipFile, fopen($downloadUrl, 'r'));

        if (!$write) {
            throw new \Exception("Failed to write to $downloadUrl");
        }

        $realpath = realpath($zipFile);

        if ($realpath === false) {
            throw new \Exception("Failed to get realpath for $downloadUrl");
        }

        $path = pathinfo($realpath, PATHINFO_DIRNAME);

        $zip = new \ZipArchive();
        $res = $zip->open($zipFile);

        if ($res === true) {
            $zip->extractTo($path);
            $zip->close();
            unlink($zipFile);

            return true;
        }

        throw new \Exception("Failed to extract zip file");
    }
}
