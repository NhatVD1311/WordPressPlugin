<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\TableRepository;
use ACPT\Includes\ACPT_DB;
use ACPT\Utils\MySQL\Schema;

class ExecuteTableSchemaAction implements CommandInterface
{
    private string $action;
    private string $id;

    /**
     * Constructor method to initialize the class with the given parameters.
     *
     * @param string $id The identifier for the instance.
     * @param string $action The action associated with the instance.
     * @return void
     */
    public function __construct(string $id, string $action)
    {
        $this->action = $action;
        $this->id = $id;
    }

    /**
     * Executes the specified action on the database table associated with the instance.
     *
     * The method performs different operations depending on the value of the action property:
     * - "drop": Drops the table from the database.
     * - "sync": Synchronizes the table schema with the expected definition by analyzing differences and executing queries to align them.
     * - "create": Creates a new table in the database based on the predefined schema.
     *
     * If the table corresponding to the given ID is not found, an exception is thrown.
     * For "sync", the method compares the generated table creation query against the current schema and applies the differences.
     *
     * @return void
     *
     * @throws \Exception If the table is not found or if any database query fails.
     */
    public function execute(): void
    {
        // The stored table definition drives every DDL statement below. Its
        // hydrated form is cached by TableRepository across two cache layers,
        // tagged only by class, and a schema action is a rare admin operation --
        // so flush the pool first to guarantee we diff/create against the
        // committed metadata, never a stale entry left by an earlier request.
        ACPT_DB::flushCache();

        $table = TableRepository::getById($this->id);

        if (empty($table)) {
            throw new \Exception('Table not found');
        }

        try {
            switch ($this->action) {

                // Drop table
                case "drop":
                    $this->dropTable($table);
                    break;

                    // Sync table
                case "sync":
                    $this->syncTable($table);
                    break;

                    // Create table
                case "create":
                    $this->createTable($table);
                    break;
            }
        } finally {
            // A schema action changes the physical table (and, on failure, may
            // have changed it partially). Any cached hydrated definition,
            // column list or "table exists" assumption is now suspect -- flush
            // so the next request rebuilds from the real database.
            ACPT_DB::flushCache();
        }
    }

    /**
     * Creates a database table based on the provided table model, including its indexes and constraints.
     *
     * @param TableModel $table The model representing the table structure, indexes, and constraints.
     * @return void
     * @throws \Exception
     */
    private function createTable(TableModel $table)
    {
        $tableCreated = false;

        try {
            ACPT_DB::executeQueryOrThrowException($table->createTableQuery(false));
            $tableCreated = true;

            foreach ($table->getIndexes() as $index) {
                ACPT_DB::executeQueryOrThrowException($index->addTableElementExpression(false));
            }

            foreach ($table->getConstraints() as $constraint) {
                ACPT_DB::executeQueryOrThrowException($constraint->addTableElementExpression(false));
            }
        } catch (\Exception $e) {
            // MySQL implicitly commits DDL, so CREATE TABLE and its follow-up
            // ADD INDEX / ADD CONSTRAINT statements are not one atomic unit -- a
            // START TRANSACTION / ROLLBACK wrapper would be a no-op here. If the
            // table itself was created, drop it so a retry starts from a clean
            // slate instead of hitting "table already exists".
            if ($tableCreated) {
                try {
                    ACPT_DB::executeQueryOrThrowException($table->dropTableQuery());
                } catch (\Exception $cleanupError) {
                    // Leave the partially-created table for manual inspection.
                    do_action("acpt/error", $cleanupError);
                }
            }

            throw $e;
        }
    }

    /**
     * Drops the specified database table using the provided table model.
     *
     * @param TableModel $table The table model representing the table to be dropped.
     * @return void
     * @throws \Exception
     */
    private function dropTable(TableModel $table)
    {
        ACPT_DB::executeQueryOrThrowException($table->dropTableQuery());
    }

    /**
     * Synchronizes the database table schema with the given table model.
     *
     * @param TableModel $table The table model instance to synchronize with the database schema.
     * @return void
     * @throws \Exception
     */
    private function syncTable(TableModel $table)
    {
        // check if the table exists
        if (!ACPT_DB::tableExists($table->getName())) {
            throw new \Exception('Table not found');
        }

        $query = $table->createTableQuery();
        $query2 = ACPT_DB::showCreate($table->getName());

        $query = Strings::removeAllExtraSpaces($query);
        $query2 = Strings::removeAllExtraSpaces((string)$query2);

        $queries = Schema::diffQueries($query2, $query);
        $total = count($queries);

        // MySQL implicitly commits every DDL statement, so ALTER TABLE is not
        // transactional: the old START TRANSACTION / ROLLBACK wrapper here could
        // never undo a statement, and if statement N of a multi-statement diff
        // failed the earlier ones were already permanently applied -- leaving
        // the table half-migrated and, because the next diff would regenerate
        // the same failing set, permanently un-syncable, with a bare MySQL error
        // that implied nothing had happened.
        //
        // Run the statements one by one and, on failure, report exactly what was
        // applied and what failed so the table can be finished or reverted by
        // hand.
        $applied = [];

        foreach ($queries as $singleQuery) {
            try {
                ACPT_DB::executeQueryOrThrowException($singleQuery);
                $applied[] = $singleQuery;
            } catch (\Exception $e) {
                $message = sprintf(
                    'Table sync failed on statement %d of %d ("%s"): %s.',
                    count($applied) + 1,
                    $total,
                    $singleQuery,
                    $e->getMessage()
                );

                if (!empty($applied)) {
                    $message .= ' These statements were already applied to the live table and cannot be rolled back automatically: '
                        . implode('; ', $applied) . '.';
                } else {
                    $message .= ' No changes were applied to the live table.';
                }

                throw new \Exception($message, (int)$e->getCode(), $e);
            }
        }
    }
}
