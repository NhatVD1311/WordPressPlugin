<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\DynamicBlock\DynamicBlockControlModel;
use ACPT\Core\Models\DynamicBlock\DynamicBlockModel;
use ACPT\Core\Repository\DynamicBlockRepository;

class SaveBlockCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * @return string|null
     * @throws \Exception
     */
    public function execute(): ?string
    {
        $data = $this->data;

        if (empty($data)) {
            return null;
        }

        $blockModel = DynamicBlockModel::hydrateFromArray([
            'id' => $data['id'] ?? Uuid::v4(),
            'title' => $data['title'],
            'name' => $data['name'],
            'category' => $data['category'],
            'icon' => (is_array($data['icon']) ? [
                'src' => $data['icon']['src'],
                'background' => $data['icon']['background'],
                'foreground' => $data['icon']['foreground'],
            ] : $data['icon']) ,
            'css' => $data['css'] ?? null,
            'callback' => $data['callback'] ?? null,
            'keywords' => (isset($data['keywords']) && is_array($data['keywords'])) ? $data['keywords'] : [],
            'postTypes' => (isset($data['postTypes']) && is_array($data['postTypes'])) ? $data['postTypes'] : [],
            'supports' => (isset($data['supports']) && is_array($data['supports'])) ? $data['supports'] : [],
        ]);

        if (isset($data['controls']) && !empty($data['controls'])) {
            foreach ($data['controls'] as $index => $control) {
                try {
                    $controlModel = DynamicBlockControlModel::hydrateFromArray([
                        'id' => $control['id'] ?? Uuid::v4(),
                        'block' => $blockModel,
                        'name' => $control['name'],
                        'label' => $control['label'],
                        'type' => $control['type'],
                        'default' => $control['default'] ?? null,
                        'description' => $control['description'] ?? null,
                        'settings' => $control['settings'] ?? [],
                        'sort' => ($index+1),
                    ]);

                    if (isset($control['options']) && !empty($control['options'])) {
                        $controlModel->setOptions($control['options']);
                    }

                    $blockModel->addControl($controlModel);
                } catch (\Exception $exception) {
                    // One malformed control (e.g. a bad enum `type`) must not
                    // abort the entire block save and lose every other control.
                    do_action('acpt/error', $exception);
                }
            }
        }

        DynamicBlockRepository::save($blockModel);

        do_action("acpt/dynamic_block/save", $this, $blockModel);

        return $blockModel->getId();
    }

    /**
     * @inheritDoc
     */
    public function logFormat(): array
    {
        return [
            "class"  => SaveBlockCommand::class,
            'data' => $this->data
        ];
    }
}
