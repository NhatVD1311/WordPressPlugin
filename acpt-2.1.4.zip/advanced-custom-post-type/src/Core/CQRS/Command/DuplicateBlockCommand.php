<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\DynamicBlockRepository;

class DuplicateBlockCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DuplicateFormCommand constructor.
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        $blockModel = DynamicBlockRepository::getById($this->id);

        if (empty($blockModel)) {
            throw new \Exception("Block not found");
        }

        $newBlockModel = $blockModel->duplicate();

        DynamicBlockRepository::save($newBlockModel);
    }
}
