<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\TableGroupRepository;

class DeleteTableGroupCommand implements CommandInterface
{
    private string $id;

    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @throws \Exception
     */
    public function execute(): void
    {
        TableGroupRepository::delete($this->id);
    }
}
