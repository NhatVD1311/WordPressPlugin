<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\FormRepository;

class DeleteFormCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DeleteFormCommand constructor.
     *
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        FormRepository::delete($this->id);
    }
}
