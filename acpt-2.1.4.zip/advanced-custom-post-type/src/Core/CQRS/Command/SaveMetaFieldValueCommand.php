<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Generators\Meta\TableFieldGenerator;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Validators\ArgumentsArrayValidator;
use ACPT\Utils\Data\NestedValues;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\GeoLocation;
use ACPT\Utils\Wordpress\WPAttachment;
use ACPT\Utils\Wordpress\WPAttachmentFactory;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelLow;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use Picqer\Barcode\BarcodeGeneratorSVG;

class SaveMetaFieldValueCommand extends AbstractMetaFieldValueCommand implements CommandInterface
{
    /**
     * Relational values come back from get_acpt_field() as WP_Post / WP_User /
     * WP_Term objects, but are stored as IDs: turn the objects into their IDs so
     * a value that was read can be saved back (#1371). Re-indexes lists, so a
     * value with a gap left by unset() is saved as a plain list.
     *
     * @param mixed $value
     *
     * @return mixed
     */
    public static function objectsToIds($value)
    {
        if ($value instanceof \WP_Post || $value instanceof \WP_User) {
            return $value->ID;
        }

        if ($value instanceof \WP_Term) {
            return $value->term_id;
        }

        if (!is_array($value)) {
            return $value;
        }

        $isList = array_keys($value) === array_filter(array_keys($value), 'is_int');
        $hasObjects = false;

        foreach ($value as $item) {
            if ($item instanceof \WP_Post || $item instanceof \WP_User || $item instanceof \WP_Term) {
                $hasObjects = true;
                break;
            }
        }

        if (!$hasObjects) {
            return $value;
        }

        $ids = array_map([self::class, 'objectsToIds'], $value);

        return $isList ? array_values($ids) : $ids;
    }

    /**
     * @throws \Exception
     *
     * @return bool
     */
    public function execute(): bool
    {
        $metaFieldModelType = $this->fieldModel->getType();
        $savedFieldValue = $this->get($this->fieldModel->getDbName());
        $savedFieldType = $this->get($this->fieldModel->getDbName().'_type');
        $savedFieldId = $this->get($this->fieldModel->getDbName().'_id');
        $value = self::objectsToIds($this->args['value'] ?? null);

        // check is value is changed, if not, do nothing and return true
        if ($savedFieldValue == $value) {
            return true;
        }

        // save _type
        if ($metaFieldModelType != $savedFieldType) {
            if (!$this->set($this->fieldModel->getDbName().'_type', $metaFieldModelType)) {
                return false;
            }
        }

        // save _id
        if ($savedFieldId != $this->fieldModel->getId()) {
            if (!$this->set($this->fieldModel->getDbName().'_id', $this->fieldModel->getId())) {
                return false;
            }
        }

        switch ($metaFieldModelType) {

            // PASSWORD_TYPE
            case MetaFieldModel::PASSWORD_TYPE:

                $algo = $this->fieldModel->getAdvancedOption("algorithm") ?? PASSWORD_DEFAULT;
                $value = Strings::hashPassword((string)$value, $algo);

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData(MetaFieldModel::PASSWORD_TYPE, $value))) {
                    return false;
                }

                break;

                // ADDRESS_TYPE
            case MetaFieldModel::ADDRESS_TYPE:

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData(MetaFieldModel::ADDRESS_TYPE, $value))) {
                    return false;
                }

                $coordinates = GeoLocation::getCoordinates($value);

                if (
                    !empty($coordinates) &&
                    $coordinates['lat'] !== null &&
                    $coordinates['lng'] !== null
                ) {
                    $savedFieldLat = $this->get($this->fieldModel->getDbName().'_lat');
                    $savedFieldLng = $this->get($this->fieldModel->getDbName().'_lng');
                    $savedFieldCity = $this->get($this->fieldModel->getDbName().'_city');
                    $savedFieldCountry = $this->get($this->fieldModel->getDbName().'_country');

                    if ($savedFieldLat !== $coordinates['lat'] && !$this->set($this->fieldModel->getDbName().'_lat', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $coordinates['lat']))) {
                        return false;
                    }

                    if ($savedFieldLng !== $coordinates['lng'] && !$this->set($this->fieldModel->getDbName().'_lng', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $coordinates['lng']))) {
                        return false;
                    }

                    $city = GeoLocation::getCity($coordinates['lat'], $coordinates['lng']);
                    $country = GeoLocation::getCountry($coordinates['lat'], $coordinates['lng']);

                    if (!empty($city) && $savedFieldCity !== $city) {
                        if (!$this->set($this->fieldModel->getDbName().'_city', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $city))) {
                            return false;
                        }
                    }

                    if (!empty($country) && $savedFieldCountry !== $country) {
                        if (!$this->set($this->fieldModel->getDbName().'_country', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $country))) {
                            return false;
                        }
                    }
                }

                break;

                // AUDIO_TYPE
            case MetaFieldModel::AUDIO_TYPE:

                $wpAttachment = WPAttachmentFactory::create($value);
                $isAudio = $wpAttachment->isAudio();
                $idFile = $wpAttachment->getId();
                $urlFile = $wpAttachment->getSrc();

                if (!$isAudio) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_file_id = $this->get($this->fieldModel->getDbName().'_attachment_id');

                if ($saved_file_id !== $idFile) {
                    if (!$this->set($this->fieldModel->getDbName().'_attachment_id', $idFile)) {
                        return false;
                    }
                }

                if ($savedFieldValue != $urlFile) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $urlFile))) {
                        return false;
                    }
                }

                break;

                // CURRENCY_TYPE
            case MetaFieldModel::CURRENCY_TYPE:

                $mandatory_keys = [
                    'amount' => [
                        'required' => true,
                        'type' => 'float|double|integer',
                    ],
                    'unit' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $amount = $value['amount'];
                $unit = $value['unit'];

                $saved_field_unit = $this->get($this->fieldModel->getDbName().'_currency');

                if ($savedFieldValue == $amount) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData(MetaFieldModel::CURRENCY_TYPE, $amount))) {
                    return false;
                }

                if ($saved_field_unit !== $unit) {
                    if (!$this->set($this->fieldModel->getDbName().'_currency', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $unit))) {
                        return false;
                    }
                }

                break;

                // DATE_RANGE_TYPE
            case MetaFieldModel::DATE_RANGE_TYPE:

                $savedFieldValue = explode(" - ", $savedFieldValue);

                if ($savedFieldValue == $value) {
                    return true;
                }

                if (!is_array($value)) {
                    return false;
                }

                if (Arrays::count($value) !== 2) {
                    return false;
                }

                $from = $value[0];
                $to = $value[1];

                $date1 = new \DateTime($from);
                $date2 = new \DateTime($to);

                if ($date1 > $date2) {
                    return false;
                }

                $value = implode(" - ", $value);

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                    return false;
                }

                break;

                // EMBED_TYPE
            case MetaFieldModel::EMBED_TYPE:

                $embed = (new \WP_Embed())->shortcode([
                    'width' => 180,
                    'height' => 135,
                ], $value);

                if ($embed === false) {
                    return false;
                }

                if (!Strings::contains('<iframe', $embed)) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }

                break;

                // FILE_TYPE
            case MetaFieldModel::FILE_TYPE:

                $mandatory_keys = [
                    'url' => [
                        'required' => false,
                        'type' => 'string',
                    ],
                    'id' => [
                        'required' => false,
                        'type' => 'string',
                    ],
                    'label' => [
                        'required' => false,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $url = $value['url'] ?? null;
                $id = $value['id'] ?? null;

                if (!$url && !$id) {
                    return false;
                }

                if ($url !== null) {
                    $wpAttachment = WPAttachment::fromUrl($url);
                }

                if ($id !== null) {
                    $wpAttachment = WPAttachment::fromId($id);
                }

                if ($wpAttachment->isEmpty()) {
                    return false;
                }

                $idFile = $wpAttachment->getId();
                $urlFile = $wpAttachment->getSrc();
                $isImage = $wpAttachment->isImage();
                $isVideo = $wpAttachment->isVideo();
                $isAudio = $wpAttachment->isAudio();

                $label = (isset($value['label']) && !empty($value['label'])) ? $value['label'] : $urlFile;

                if ($isImage || $isVideo || $isAudio) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_field_label = $this->get($this->fieldModel->getDbName().'_label');
                $saved_file_id = $this->get($this->fieldModel->getDbName().'_attachment_id');

                if ($idFile !== $saved_file_id) {
                    if (!$this->set($this->fieldModel->getDbName().'_attachment_id', $idFile)) {
                        return false;
                    }
                }

                if ($savedFieldValue !== $urlFile) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $urlFile))) {
                        return false;
                    }
                }

                if ($saved_field_label !== $label) {
                    if (!$this->set($this->fieldModel->getDbName().'_label', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $label))) {
                        return false;
                    }
                }

                break;

                // GALLERY_TYPE
            case MetaFieldModel::IMAGE_SLIDER_TYPE:
            case MetaFieldModel::AUDIO_MULTI_TYPE:
            case MetaFieldModel::GALLERY_TYPE:
            case MetaFieldModel::VIDEO_MULTI_TYPE:

                if (!is_array($value)) {
                    return false;
                }

                // Max 2 images allowed for image slider
                if ($metaFieldModelType === MetaFieldModel::IMAGE_SLIDER_TYPE && Arrays::count($value) > 2) {
                    return false;
                }

                $idFiles = [];
                $files = [];

                foreach ($value as $file) {
                    $wpAttachment = WPAttachmentFactory::create($file);

                    $isImage = $wpAttachment->isImage();
                    $isAudio = $wpAttachment->isAudio();
                    $isVideo = $wpAttachment->isVideo();
                    $idFile = $wpAttachment->getId();
                    $urlFile = $wpAttachment->getSrc();

                    if (
                        ($isAudio && $metaFieldModelType === MetaFieldModel::AUDIO_MULTI_TYPE) ||
                        ($isImage && $metaFieldModelType === MetaFieldModel::GALLERY_TYPE) ||
                        ($isImage && $metaFieldModelType === MetaFieldModel::IMAGE_SLIDER_TYPE) ||
                        ($isVideo && $metaFieldModelType === MetaFieldModel::VIDEO_MULTI_TYPE)
                    ) {
                        // The canonical stored shape for a multi-media field is a flat
                        // array of URL strings (this is what the classic meta-box save
                        // in AbstractSaveMetaCommand persists, and what GalleryField /
                        // FetchMetaFieldValueQuery read back). Storing an
                        // ['url' => ..., 'attachment_id' => ...] object here instead
                        // produced "Array to string conversion" warnings and an empty
                        // preview on the post-edit screen (#1289). The attachment ids
                        // are already tracked separately in the _attachment_id sidecar.
                        $idFiles[] = $idFile;
                        $files[] = $urlFile;
                    }
                }

                if (empty($idFiles)) {
                    return false;
                }

                $idFiles = implode(",", $idFiles);
                $savedFileIds = $this->get($this->fieldModel->getDbName().'_attachment_id');

                if ($savedFileIds !== $idFiles) {
                    if (!$this->set($this->fieldModel->getDbName().'_attachment_id', $idFiles)) {
                        return false;
                    }
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());

                if ($savedFieldValue != $files) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $files))) {
                        return false;
                    }
                }

                break;

                // IMAGE_TYPE
            case MetaFieldModel::IMAGE_TYPE:

                $wpAttachment = WPAttachmentFactory::create($value);
                $isImage = $wpAttachment->isImage();
                $idFile = $wpAttachment->getId();
                $urlFile = $wpAttachment->getSrc();

                if (!$isImage) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_file_id = $this->get($this->fieldModel->getDbName().'_attachment_id');

                if ($saved_file_id !== $idFile) {
                    if (!$this->set($this->fieldModel->getDbName().'_attachment_id', $idFile)) {
                        return false;
                    }
                }

                if ($savedFieldValue != $urlFile) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $urlFile))) {
                        return false;
                    }
                }

                break;

                // LENGTH_TYPE
            case MetaFieldModel::LENGTH_TYPE:

                $mandatory_keys = [
                    'length' => [
                        'required' => true,
                        'type' => 'float|double|integer',
                    ],
                    'unit' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $length = $value['length'];
                $unit = $value['unit'];

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_field_unit = $this->get($this->fieldModel->getDbName().'_length');

                if ($savedFieldValue == $length) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData(MetaFieldModel::WEIGHT_TYPE, $length))) {
                    return false;
                }

                if ($saved_field_unit !== $unit) {
                    if (!$this->set($this->fieldModel->getDbName().'_length', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $unit))) {
                        return false;
                    }
                }

                break;

            case MetaFieldModel::NUMBER_TYPE:
            case MetaFieldModel::RANGE_TYPE:

                $min = $this->fieldModel->getAdvancedOption('min');
                $max = $this->fieldModel->getAdvancedOption('max');

                if ($min !== null && (int)$value < (int)$min) {
                    return false;
                }

                if ($max !== null && (int)$value > (int)$max) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());

                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }

                break;

                // LIST_TYPE
            case MetaFieldModel::LIST_TYPE:
                if (!is_array($value)) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }

                break;

                // BARCODE_TYPE
            case MetaFieldModel::BARCODE_TYPE:

                if (!isset($value['value'])) {
                    return false;
                }

                if (!is_string($value['value'])) {
                    return false;
                }

                $val = $value['value'];
                $savedBarcodeValue = $this->get($this->fieldModel->getDbName().'_barcode_value');

                if ($savedFieldValue == $val) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $val))) {
                    return false;
                }

                // Generate Barcode
                try {
                    $format = $value['format'] ?? "code128";
                    $color = $value['color'] ?? "#000000";

                    $allowedFormats = [
                        "code128",
                        "ean13",
                        "ean8",
                        "ean5",
                        "ean2",
                        "upc",
                        "code39",
                        "itf14",
                        "msi",
                        "pharmacode",
                    ];

                    if (!in_array($format, $allowedFormats)) {
                        return false;
                    }

                    $generator = new BarcodeGeneratorSVG();
                    $f = $generator::TYPE_CODE_128;

                    switch ($format) {
                        case "code128":
                            $f = $generator::TYPE_CODE_128;
                            break;

                        case "ean13":
                            $f = $generator::TYPE_EAN_13;
                            break;

                        case "ean8":
                            $f = $generator::TYPE_EAN_8;
                            break;

                        case "ean5":
                            $f = $generator::TYPE_EAN_5;
                            break;

                        case "ean2":
                            $f = $generator::TYPE_EAN_2;
                            break;

                        case "upc":
                            $f = $generator::TYPE_UPC_A;
                            break;

                        case "code39":
                            $f = $generator::TYPE_CODE_39;
                            break;

                        case "itf14":
                            $f = $generator::TYPE_ITF_14;
                            break;

                        case "msi":
                            $f = $generator::TYPE_MSI;
                            break;

                        case "pharmacode":
                            $f = $generator::TYPE_PHARMA_CODE;
                            break;
                    }

                    $svg = $generator->getBarcode($val, $f, 3, 100, $color);
                    $barcodeValueObject = json_encode([
                        'svg' => htmlentities($svg),
                        'format' => $format,
                        'color' => $color,
                        'bgColor' => '#ffffff',
                    ]);

                    // barcode_value
                    if ($savedBarcodeValue == $barcodeValueObject) {
                        return true;
                    }

                    if (!$this->set($this->fieldModel->getDbName().'_barcode_value', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $barcodeValueObject))) {
                        return false;
                    }
                } catch (\Exception $exception) {
                    do_action("acpt/error", $exception);

                    return false;
                }

                break;

                // QR_CODE_TYPE
            case MetaFieldModel::QR_CODE_TYPE:

                if (!Strings::isUrl($value)) {
                    return false;
                }

                $savedQRCodeValue = $this->get($this->fieldModel->getDbName().'_qr_code_value');

                if ($savedFieldValue == $value) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                    return false;
                }

                // Generate QR Code
                try {
                    $writer = new PngWriter();
                    $qrCode = new QrCode(
                        $value,
                        new Encoding('UTF-8'),
                        new ErrorCorrectionLevelLow(),
                        200,
                        0,
                        new RoundBlockSizeModeMargin(),
                        new Color(0, 0, 0),
                        new Color(255, 255, 255)
                    );

                    $qrCodeObject = $writer->write($qrCode);

                    $QRCodeValueObject = json_encode([
                        'img' => $qrCodeObject->getDataUri(),
                        'resolution' => 200,
                        'colorLight' => '#ffffff',
                        'colorDark' => '#000000',
                    ]);

                    // qr_code_value
                    if ($savedQRCodeValue == $QRCodeValueObject) {
                        return true;
                    }

                    if (!$this->set($this->fieldModel->getDbName().'_qr_code_value', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $QRCodeValueObject))) {
                        return false;
                    }
                } catch (\Exception $exception) {
                    do_action("acpt/error", $exception);

                    return false;
                }

                break;

                // REPEATER_TYPE
            case MetaFieldModel::REPEATER_TYPE:

                if (!is_array($value)) {
                    return false;
                }

                $values = NestedValues::addOrUpdateRawValue(
                    $this->fieldModel,
                    (empty($savedFieldValue) || !is_array($savedFieldValue)) ? [] : $savedFieldValue,
                    $value
                );

                if ($savedFieldValue == $values) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $values))) {
                    return false;
                }

                break;

                // FLEXIBLE_CONTENT_TYPE
            case MetaFieldModel::FLEXIBLE_CONTENT_TYPE:

                if (!is_array($value)) {
                    return false;
                }

                if (!isset($value['blocks'])) {
                    return false;
                }

                $values = [
                    'blocks' => []
                ];

                foreach ($value['blocks'] as $block_index => $block) {
                    if (is_array($block)) {
                        foreach ($block as $block_name => $block_values) {
                            if (is_array($block_values)) {
                                $values['blocks'][(int)$block_index] = NestedValues::formatBlockValues(
                                    $this->fieldModel,
                                    $block_name,
                                    $block_values
                                );
                            }
                        }
                    }
                }

                if ($savedFieldValue == $values) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $values))) {
                    return false;
                }

                break;

                // POST_TYPE
            case MetaFieldModel::POST_TYPE:

                try {
                    $rawValue = Sanitizer::sanitizeRawData($metaFieldModelType, $value);

                    if (!is_array($rawValue)) {
                        $rawValue = [$rawValue];
                    }

                    $rawValue = implode(",", $rawValue);

                    $command = new HandleRelationsCommand($this->fieldModel, $rawValue, $this->location, $this->belongsTo);
                    $command->execute();

                    return true;
                } catch (\Exception $exception) {
                    do_action("acpt/error", $exception);

                    return false;
                }

                // SELECT_TYPE
            case MetaFieldModel::RADIO_TYPE:
            case MetaFieldModel::SELECT_TYPE:

                if (in_array($value, $this->fieldModel->getOptionValues())) {
                    $savedFieldValue = $this->get($this->fieldModel->getDbName());
                    if ($savedFieldValue != $value) {
                        if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                            return false;
                        }
                    }

                    return true;
                }

                return false;

                // SELECT_MULTI_TYPE
            case MetaFieldModel::CHECKBOX_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:

                if (!is_array($value)) {
                    return false;
                }

                $optionValues = $this->fieldModel->getOptionValues();

                foreach ($value as $item) {
                    if (!in_array($item, $optionValues)) {
                        return false;
                    }
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }

                break;

                // TABLE_TYPE
            case MetaFieldModel::TABLE_TYPE:

                if (!is_array($value)) {
                    return false;
                }

                $generator = new TableFieldGenerator(json_encode($value));

                if (!$generator->theJSONIsValid()) {
                    return false;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                    return false;
                }

                break;

                // VIDEO_TYPE
            case MetaFieldModel::VIDEO_TYPE:

                $wpAttachment = WPAttachmentFactory::create($value);
                $isVideo = $wpAttachment->isVideo();
                $idFile = $wpAttachment->getId();
                $urlFile = $wpAttachment->getSrc();

                if (!$isVideo) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_file_id = $this->get($this->fieldModel->getDbName().'_attachment_id');

                if ($saved_file_id !== $idFile) {
                    if (!$this->set($this->fieldModel->getDbName().'_attachment_id', $idFile)) {
                        return false;
                    }
                }

                if ($savedFieldValue != $urlFile) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $urlFile))) {
                        return false;
                    }
                }

                break;

                // WEIGHT_TYPE
            case MetaFieldModel::WEIGHT_TYPE:

                $mandatory_keys = [
                    'weight' => [
                        'required' => true,
                        'type' => 'float|double|integer',
                    ],
                    'unit' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $weight = $value['weight'];
                $unit = $value['unit'];

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $saved_field_unit = $this->get($this->fieldModel->getDbName().'_weight');

                if ($savedFieldValue == $weight) {
                    return true;
                }

                if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData(MetaFieldModel::WEIGHT_TYPE, $weight))) {
                    return false;
                }

                if ($saved_field_unit !== $unit) {
                    if (!$this->set($this->fieldModel->getDbName().'_weight', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $unit))) {
                        return false;
                    }
                }

                break;

                // COUNTRY_TYPE
            case MetaFieldModel::COUNTRY_TYPE:
                $mandatory_keys = [
                    'value' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                    'country' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $countryValue = $value['value'];
                $countryCode = $value['country'];

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                $savedFieldCountry = $this->get($this->fieldModel->getDbName().'_country');

                if ($savedFieldValue !== $countryValue) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $countryValue))) {
                        return false;
                    }
                }

                if ($savedFieldCountry !== $countryCode) {
                    if (!$this->set($this->fieldModel->getDbName().'_country', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $countryCode))) {
                        return false;
                    }
                }

                break;

                // URL_TYPE
            case MetaFieldModel::URL_TYPE:

                if (is_string($value)) {
                    $value = [
                        'url' => $value,
                        'label' => $value,
                    ];
                }

                $mandatory_keys = [
                    'url' => [
                        'required' => true,
                        'type' => 'string',
                    ],
                    'label' => [
                        'required' => false,
                        'type' => 'string',
                    ],
                ];

                $validator = new ArgumentsArrayValidator();

                if (!$validator->validate($mandatory_keys, $value)) {
                    return false;
                }

                $url = $value['url'];
                $label = (isset($value['label']) && !empty($value['label'])) ? $value['label'] : $url;

                if ($savedFieldValue !== $url) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $url))) {
                        return false;
                    }
                }

                $savedFieldLabel = $this->get($this->fieldModel->getDbName().'_label');

                if ($savedFieldLabel !== $label) {
                    if (!$this->set($this->fieldModel->getDbName().'_label', Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $label))) {
                        return false;
                    }
                }

                break;

                // RATING_TYPE
            case MetaFieldModel::RATING_TYPE:
                if (!is_numeric($value)) {
                    return false;
                }

                if ($value < 1) {
                    return false;
                }

                if ($value > 10) {
                    return false;
                }

                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }
                break;

                // Default behaviour
            default:
                $savedFieldValue = $this->get($this->fieldModel->getDbName());
                if ($savedFieldValue != $value) {
                    if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($metaFieldModelType, $value))) {
                        return false;
                    }
                }
        }

        return true;
    }
}
