<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Repository\DatasetRepository;

class DeleteDatasetCommand implements CommandInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * DeleteFormCommand constructor.
     *
     * @param string $id
     */
    public function __construct(string $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        DatasetRepository::delete($this->id);
    }
}
