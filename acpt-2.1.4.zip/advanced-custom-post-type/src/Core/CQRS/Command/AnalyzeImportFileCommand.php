<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\FormatterFormat;
use ACPT\Constants\MetaTypes;
use ACPT\Core\Models\CustomPostType\CustomPostTypeModel;
use ACPT\Core\Models\Taxonomy\TaxonomyModel;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Core\Repository\DatasetRepository;
use ACPT\Core\Repository\DynamicBlockRepository;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Repository\TaxonomyRepository;
use ACPT\Utils\Data\Formatter\Formatter;
use ACPT\Utils\Wordpress\Translator;

class AnalyzeImportFileCommand implements CommandInterface
{
    public const MAX_SIZE = 2097152;

    /**
     * @var array<string, mixed>
     */
    private array $file = [];

    /**
     * AnalyzeImportFileCommand constructor.
     *
     * @param array<string, mixed> $file
     */
    public function __construct(array $file)
    {
        $this->file = $file;
    }

    /**
     * @return array<string, mixed>
     * @throws \Exception
     */
    public function execute(): array
    {
        $file = $this->file;

        if ($file['size'] > self::MAX_SIZE) {
            throw new \Exception(Translator::translate('File too large. Max size: 2Mb'));
        }

        // validate extension
        $path_parts = pathinfo($file["name"]);

        if (!isset($path_parts['extension'])) {
            throw new \Exception('File extension is required');
        }

        $extension = $path_parts['extension'];

        $allowedExtensions = [
            FormatterFormat::ACPT_FORMAT,
            FormatterFormat::JSON_FORMAT,
            FormatterFormat::XML_FORMAT,
            FormatterFormat::YAML_FORMAT,
        ];

        if (!in_array($extension, $allowedExtensions)) {
            throw new \Exception($extension . ' format is not allowed');
        }

        // upload file
        $contentFileInfo = wp_handle_upload($file, [
            'test_form' => false,
            'test_type' => false,
        ]);

        $filePath = $contentFileInfo['file'] ?? $file['tmp_name'] ?? "";
        $contentFile = file_get_contents($filePath);

        if ($contentFile === false) {
            throw new \Exception('File is empty');
        }

        $data = [];
        $arrayData = Formatter::toArray($extension, $contentFile);

        if (empty($arrayData)) {
            return $data;
        }

        foreach ($arrayData as  $context => $d) {
            foreach ($d as $datum) {
                $data[$context][] = $this->format($context, $datum);
            }
        }

        return $data;
    }

    /**
     * Decorates the provided entity data with `exists`/`isNative` flags, keeping every
     * original field intact so the result can be round-tripped straight into
     * ImportSettingsCommand without any reshaping.
     *
     * @param string $context The context to determine which existence check applies.
     * @param array<string, mixed> $data The full raw entity data parsed from the file.
     * @return array<string, mixed> The original entity data, decorated with `exists`/`isNative`.
     */
    private function format(string $context, array $data): array
    {
        switch ($context) {
            case MetaTypes::CUSTOM_POST_TYPE:
                return array_merge($data, [
                    'isNative' => CustomPostTypeModel::isPostTypeNative($data['name'] ?? ''),
                    'exists' => CustomPostTypeRepository::exists($data['name'] ?? ''),
                ]);

            case MetaTypes::TAXONOMY:
                return array_merge($data, [
                    'isNative' => TaxonomyModel::isTaxonomyNative($data['slug'] ?? ''),
                    'exists' => TaxonomyRepository::exists($data['slug'] ?? ''),
                ]);

            case MetaTypes::META:
                return array_merge($data, [
                    'exists' => count(MetaRepository::get(['id' => $data['id'] ?? ''])) > 0,
                ]);

            case MetaTypes::OPTION_PAGE:

                $children = [];

                foreach ($data['children'] ?? [] as $child) {
                    $children[] = $this->format(MetaTypes::OPTION_PAGE, $child);
                }

                return array_merge($data, [
                    'exists' => count(OptionPageRepository::get(['id' => $data['id'] ?? ''])) > 0,
                    'children' => $children,
                ]);

            case "form":
                return array_merge($data, [
                    'exists' => count(FormRepository::get(['id' => $data['id'] ?? ''])) > 0,
                ]);

            case MetaTypes::TABLE:
                return array_merge($data, [
                    'exists' => count(TableRepository::get(['id' => $data['id'] ?? ''])) > 0,
                ]);

            case MetaTypes::TABLE_GROUP:
                return array_merge($data, [
                    'exists' => count(TableGroupRepository::get(['id' => $data['id'] ?? ''])) > 0,
                ]);

            case MetaTypes::DYNAMIC_BLOCK:
                return array_merge($data, [
                    'exists' => DynamicBlockRepository::getById($data['id'] ?? '') !== null,
                ]);

            case 'dataset':
                return array_merge($data, [
                    'exists' => DatasetRepository::getById($data['id'] ?? '') !== null,
                ]);
        }

        return $data;
    }
}
