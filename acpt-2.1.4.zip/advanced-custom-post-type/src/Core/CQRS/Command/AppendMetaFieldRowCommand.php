<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Utils\Data\NestedValues;
use ACPT\Utils\Data\Sanitizer;

class AppendMetaFieldRowCommand extends AbstractMetaFieldValueCommand implements CommandInterface
{
    /**
     * @inheritDoc
     * @throws \Exception
     */
    public function execute(): bool
    {
        if ($this->fieldModel->getType() !== MetaFieldModel::REPEATER_TYPE) {
            return false;
        }

        $row = $this->args['value'];

        if (!is_array($row)) {
            return false;
        }

        $savedFieldType = $this->get($this->fieldModel->getDbName().'_type');
        $savedFieldId = $this->get($this->fieldModel->getDbName().'_id');
        $savedFieldValue = $this->get($this->fieldModel->getDbName());

        if (empty($savedFieldValue) || !is_array($savedFieldValue)) {
            $savedFieldValue = [];
        }

        // save _type
        if ($this->fieldModel->getType() != $savedFieldType) {
            if (!$this->set($this->fieldModel->getDbName().'_type', $this->fieldModel->getType())) {
                return false;
            }
        }

        // save _id
        if ($savedFieldId != $this->fieldModel->getId()) {
            if (!$this->set($this->fieldModel->getDbName().'_id', $this->fieldModel->getId())) {
                return false;
            }
        }

        $nextIndex = $this->getNextRowIndex($savedFieldValue);

        $values = NestedValues::addOrUpdateRawValue(
            $this->fieldModel,
            $savedFieldValue,
            [$row],
            $nextIndex
        );

        if (!$this->set($this->fieldModel->getDbName(), Sanitizer::sanitizeRawData($this->fieldModel->getType(), $values))) {
            return false;
        }

        return true;
    }

    /**
     * The repeater is stored column-major (one array per child field, indexed by row).
     * Columns can end up with different lengths if rows were written by something other
     * than this command, so the next row always goes after the longest column rather
     * than trusting any single child's count - that guarantees an append never clobbers
     * an existing row.
     *
     * @param array<int, mixed> $savedFieldValue
     *
     * @return int
     */
    private function getNextRowIndex(array $savedFieldValue = []): int
    {
        if (empty($savedFieldValue)) {
            return 0;
        }

        $counts = array_map(function ($column) {
            return is_array($column) ? count($column) : 0;
        }, $savedFieldValue);

        return max($counts);
    }
}
