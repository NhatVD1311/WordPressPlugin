<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Includes\ACPT_DB;

class DeleteTableTemplateCommand implements CommandInterface
{
    /**
     * @var int
     */
    private int $id;

    /**
     * DeleteMetaGroupCommand constructor.
     *
     * @param int $id
     */
    public function __construct(int $id)
    {
        $this->id = $id;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function execute(): void
    {
        global $wpdb;

        $query = "DELETE FROM `{$wpdb->prefix}options` where option_id = %d;";
        ACPT_DB::executeQueryOrThrowException($query, [$this->id]);
    }
}
