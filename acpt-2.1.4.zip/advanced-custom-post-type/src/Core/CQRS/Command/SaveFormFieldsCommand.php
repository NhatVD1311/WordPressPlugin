<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Models\Validation\ValidationRuleModel;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Utils\PHP\Arrays;

class SaveFormFieldsCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var string
     */
    private string $id;

    /**
     * @var array<int, array<string, mixed>>
     */
    private array $data;

    /**
     * SaveFormFieldsCommand constructor.
     *
     * @param string $id
     * @param array<int, array<string, mixed>> $data
     */
    public function __construct($id, array $data)
    {
        $this->id = $id;
        $this->data = $data;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function execute(): string
    {
        $formModel = FormRepository::getById($this->id);

        if ($formModel === null) {
            throw new \Exception("Form with id ".$this->id." does not exists");
        }

        $formModel->resetFields();

        $this->data = $this->normaliseFieldKeys($this->data);

        $fields = array_filter($this->data, function ($f) {

            // check if isset parentId and parentTab
            if (!isset($f['parentId'])) {
                return true;
            }

            if (!isset($f['parentTab'])) {
                return true;
            }

            return false;
        });

        if (!empty($fields)) {
            $fields = Arrays::reindex($fields);
        }

        foreach ($fields as $fieldIndex => $field) {
            $fieldModel = $this->hydrateFormField($field, $fieldIndex);
            $formModel->addField($fieldModel);
        }

        FormRepository::save($formModel);

        do_action("acpt/form_fields/save", $this, $formModel);

        return $formModel->getId();
    }

    /**
     * `wp_acpt_form_field.field_key` is varchar(12) with a global UNIQUE key. A
     * caller-supplied key (this command backs both the React Form Manager save and
     * the acpt/save-form-field ability) that is empty, longer than 12 chars, or
     * shares its first 12 chars with another field in the same payload would be
     * silently truncated by MySQL and collapse several fields onto one row
     * (INSERT ... ON DUPLICATE KEY UPDATE). Same guard as SaveFormCommand's
     * #1254 fix — normalise to a safe 8-char random key, remapping any child's
     * parentId that referenced a rewritten key.
     *
     * @param array<int, array<string, mixed>> $data
     * @return array<int, array<string, mixed>>
     */
    private function normaliseFieldKeys(array $data): array
    {
        $used = [];
        $remap = [];

        foreach ($data as $index => $field) {
            $key = isset($field['key']) ? (string)$field['key'] : '';

            if ($key === '' || mb_strlen($key) > 12 || in_array($key, $used, true)) {
                $newKey = $key;
                do {
                    $newKey = Strings::randomString(8);
                } while (in_array($newKey, $used, true));

                if ($key !== '') {
                    $remap[$key] = $newKey;
                }

                $key = $newKey;
            }

            $used[] = $key;
            $data[$index]['key'] = $key;
        }

        if (!empty($remap)) {
            foreach ($data as $index => $field) {
                if (isset($field['parentId']) && isset($remap[$field['parentId']])) {
                    $data[$index]['parentId'] = $remap[$field['parentId']];
                }
            }
        }

        return $data;
    }

    /**
     * @param array<string, mixed>         $field
     * @param int                          $fieldIndex
     * @param FormFieldModel|null $parentFieldModel
     *
     * @return FormFieldModel
     * @throws \Exception
     */
    private function hydrateFormField(array $field, int $fieldIndex, ?FormFieldModel $parentFieldModel = null)
    {
        $metaFieldModel = null;
        if (isset($field['metaFieldId'])) {
            $metaFieldModel = MetaRepository::getMetaFieldById($field['metaFieldId']);
        }

        $isRequired = $field['required'] ?? $field['is_required'] ?? $field['isRequired'];

        $fieldModel = FormFieldModel::hydrateFromArray([
                'id' => $field['id'],
                'metaField' => $metaFieldModel,
                'group' => $field['group'],
                'key' => $field['key'],
                'name' => $field['name'],
                'label' => $field['label'],
                'type' => $field['type'],
                'description' => $field['description'],
                'isRequired' => (bool)$isRequired,
                'extra' => $field['extra'],
                'settings' => $field['settings'],
                'sort' => ($fieldIndex+1),
        ]);

        if (isset($field['parentTab']) && !empty($field['parentTab'])) {
            $fieldModel->setParentTabIndex($field['parentTab']);
        }

        if ($parentFieldModel !== null) {
            $fieldModel->setParentField($parentFieldModel);
        }

        // rules
        if (isset($field['rules']) && !empty($field['rules'])) {
            foreach ($field['rules'] as $ruleIndex => $rule) {
                $validationRuleModel = ValidationRuleModel::hydrateFromArray([
                        'id' => $rule['id'],
                        'condition' => $rule['condition'],
                        'value' => $rule['value'],
                        'message' => $rule['message'],
                        'sort' => ($ruleIndex+1),
                ]);

                $fieldModel->addValidationRule($validationRuleModel);
            }
        }

        // children
        $children = array_filter($this->data, function ($c) use ($field) {
            if (!isset($c['parentId'])) {
                return false;
            }

            return $c['parentId'] === $field['key'];
        });

        if (!empty($children)) {
            $children = Arrays::reindex($children);
        }

        foreach ($children as $childIndex => $child) {
            $childFieldModel = $this->hydrateFormField($child, $childIndex, $fieldModel);
            $fieldModel->addChild($childFieldModel, $child['parentTab'] ?? null, );
        }

        return $fieldModel;
    }

    /**
     * @inheritDoc
     */
    public function logFormat(): array
    {
        return [
            "class"  => SaveFormFieldsCommand::class,
            'data' => $this->data
        ];
    }
}
