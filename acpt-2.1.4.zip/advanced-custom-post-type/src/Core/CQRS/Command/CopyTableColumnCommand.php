<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\Validators\ArgumentsArrayValidator;
use ACPT\Core\ValueObjects\UIFieldObject;
use Exception;

/**
 * Copies a single concrete column from one CCT table into another (or the same) table.
 *
 * Mirrors CopyMetaFieldCommand for the CCT side. Metadata only — it does NOT run the
 * physical `ALTER TABLE`; the caller/user runs the existing "Sync table" action on the
 * target afterwards (the returned payload flags `needsSync`).
 *
 * v1 scope: repeater / flexible-content parents and their VIRTUAL children are rejected —
 * their structure lives in separate flat rows with regenerated block ids, which is a
 * materially larger job left for a later pass.
 */
class CopyTableColumnCommand implements CommandInterface
{
    private string $sourceColumnId;
    private string $targetTableId;
    private bool $delete;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $validationRules = [
            'sourceColumnId' => [
                'required' => true,
                'type' => 'string',
            ],
            'targetTableId' => [
                'required' => true,
                'type' => 'string',
            ],
            'delete' => [
                'required' => false,
                'type' => 'boolean',
            ],
        ];

        $validator = new ArgumentsArrayValidator();

        if (!$validator->validate($validationRules, $data)) {
            throw new \InvalidArgumentException($validator->errorMessage());
        }

        $this->sourceColumnId = (string)$data['sourceColumnId'];
        $this->targetTableId = (string)$data['targetTableId'];
        $this->delete = isset($data['delete']) && (bool)$data['delete'];
    }

    /**
     * @throws Exception
     */
    public function execute()
    {
        $sourceColumn = TableRepository::getColumnById($this->sourceColumnId);

        if (empty($sourceColumn)) {
            throw new Exception('Source column was not found. If you haven\'t saved the table yet, please SAVE it and then try to copy the column.');
        }

        $sourceUi = $sourceColumn->getUiField();
        $virtualUiTypes = [
            MetaFieldModel::REPEATER_TYPE,
            MetaFieldModel::FLEXIBLE_CONTENT_TYPE,
            MetaFieldModel::CLONE_TYPE,
        ];

        if (
            $sourceColumn->isVirtual()
            || $sourceColumn->hasChildren()
            || $sourceColumn->hasBlocks()
            || in_array($sourceUi->type, $virtualUiTypes, true)
        ) {
            throw new \InvalidArgumentException('Repeater / flexible-content columns (and their nested children) cannot be copied across tables yet — copy the concrete columns individually.');
        }

        $sourceTableId = $sourceColumn->getTable()->getId();
        $sameTable = ($sourceTableId === $this->targetTableId);

        // Always work off a freshly-loaded, fully-hydrated TableModel — TableRepository::save()
        // rewrites the whole column set and hard-deletes any column not present, so a partially
        // populated model (e.g. the lightweight table hanging off getColumnById()) would wipe
        // every other column.
        $targetTable = TableRepository::getById($this->targetTableId);

        if (empty($targetTable)) {
            throw new Exception('Target table was not found');
        }

        $newColumn = $this->buildCopy($sourceColumn, $targetTable);
        $targetTable->addColumn($newColumn);

        if ($this->delete) {
            if ($sameTable) {
                // removeColumn matches by id — drop the original alongside adding the copy in one save.
                $targetTable->removeColumn($sourceColumn);
            } else {
                $sourceTable = TableRepository::getById($sourceTableId);

                if (!empty($sourceTable)) {
                    $sourceTable->removeColumn($sourceColumn);
                    TableRepository::save($sourceTable);
                }
            }
        }

        TableRepository::save($targetTable);
    }

    /**
     * Builds the copied column: fresh id, collision-safe name, relationship stripped,
     * parent pointers cleared, appended at the end of the target's column list.
     *
     * @throws Exception
     */
    private function buildCopy(TableColumnModel $source, TableModel $target): TableColumnModel
    {
        $existingNames = array_map(static fn (TableColumnModel $c) => $c->getName(), $target->getColumns());

        $name = Strings::getTheFirstAvailableName($source->getName(), $existingNames);

        if (strlen($name) > 64) {
            $name = substr($name, 0, 64);
        }

        // Clone the UI object, dropping the relationship (bidirectional bookkeeping is
        // keyed on table + column name — a naive copy would double-claim the inverse)
        // and any parent pointers (guarded against above, defensive here).
        $uiArray = $source->getUiField()->jsonSerialize();
        $uiArray['relationship'] = null;
        $uiArray['parentId'] = null;
        $uiArray['parentBlockId'] = null;
        $uiArray['blocks'] = [];

        $ui = new UIFieldObject();
        $ui->fromArray($uiArray);

        /** @var TableColumnModel $newColumn */
        $newColumn = TableColumnModel::hydrateFromArray([
            'id' => Uuid::v4(),
            'name' => $name,
            'label' => $source->getLabel(),
            'table' => $target,
            'type' => $source->getType(),
            'length' => $source->getLength(),
            'nullable' => $source->isNullable(),
            // a copied column must never inherit UNIQUE / PRIMARY KEY — that would
            // fight the original at sync time (duplicate PK, unique-index clash).
            'unique' => false,
            'primaryKey' => false,
            'sort' => count($target->getColumns()) + 1,
            'defaultValue' => $source->getDefaultValue(),
            'description' => $source->getDescription(),
            'columnValues' => $source->getColumnValues(),
            'uiField' => $ui,
        ]);

        $newColumn->setParentId(null);

        foreach ($source->getOptions() as $option) {
            // skip a standalone PRIMARY KEY / UNIQUE option — see the primaryKey/unique note above.
            $key = method_exists($option, 'getKey') ? $option->getKey() : null;
            if (in_array($key, ['PRIMARY KEY', 'UNIQUE'], true)) {
                continue;
            }
            $newColumn->addOption(clone $option);
        }

        foreach ($source->getValidationRules() as $rule) {
            $newColumn->addValidationRule(clone $rule);
        }

        foreach ($source->getVisibilityConditions() as $condition) {
            $newColumn->addVisibilityCondition(clone $condition);
        }

        foreach ($source->getPermissions() as $permission) {
            $newColumn->addPermission(clone $permission);
        }

        return $newColumn;
    }
}
