<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Models\Form\FormMetadataModel;
use ACPT\Core\Models\Form\FormModel;
use ACPT\Core\Models\Validation\ValidationRuleModel;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;

class SaveFormCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * @var bool
     */
    private bool $emptyItems;

    /**
     * SaveMetaGroupCommand constructor.
     *
     * @param array<string, mixed> $data
     * @param bool $emptyItems
     */
    public function __construct(array $data, $emptyItems = false)
    {
        $this->data = $data;
        $this->emptyItems = $emptyItems;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function execute(): string
    {
        $data = $this->data;
        $id = (isset($data['id'])) ? $data['id'] : Uuid::v4();
        $formNames = FormRepository::getNames();

        if (!isset($data['name'])) {
            throw new \Exception("Missing `name` property");
        }

        // form name
        if (isset($data['id'])) {
            $formNames = array_filter($formNames, function ($item) use ($data) {
                return $item !== $data['name'];
            });
        }

        $name = Strings::getTheFirstAvailableName($data['name'], $formNames);

        $formModel = FormModel::hydrateFromArray([
            'id'   => $id,
            'name' => $name,
            'action' => @$data['action'],
            'label' => !empty($data['label']) ? (string)$data['label'] : null,
            'key' => !empty($data['key']) ? (string)$data['key'] : Strings::randomString(8),
        ]);

        $savedForm = isset($data['id']) ? FormRepository::getById($id) : null;

        if (isset($data['meta'])) {
            $metadata = $data['meta'];

            foreach ($metadata as $metadatum) {
                $key = $metadatum['key'] ?? null;
                $value = $metadatum['value'] ?? null;

                if (is_bool($value)) {
                    $value = $value === true ? '1' : '0';
                }

                $formMetadataModel = FormMetadataModel::hydrateFromArray([
                    'formId' => $id,
                    'key' => (string)$key,
                    'value' => (string)$value
                ]);

                $formModel->addMetadata($formMetadataModel);
            }
        } elseif ($this->emptyItems === false && $savedForm !== null) {
            // `meta` is optional in FormSchema (required = name, key, action), so any
            // save that omits it — e.g. just renaming the form or changing its label —
            // used to silently delete ALL form metadata (fill_meta_location_belong/
            // find, submission_limits, redirect_to, ajax_action/custom_action,
            // email_settings, etc.), since FormRepository::save() unconditionally
            // replaces the whole metadata set with whatever's on $formModel.
            foreach ($savedForm->getMeta() as $metadatum) {
                $formModel->addMetadata($metadatum);
            }
        }

        // inject fields
        if (isset($data['fields']) && !empty($data['fields'])) {
            // When the form already exists, match each incoming field to its saved
            // record by name (then by key) and reuse the stored id/key. A caller
            // building a form programmatically legitimately omits `id` (it is
            // readOnly in the schema); without this, every re-save minted a fresh
            // UUID per field, `FormRepository::saveMetaField()`'s
            // `INSERT ... ON DUPLICATE KEY UPDATE` collided on the UNIQUE `field_key`
            // and updated the OLD row under its OLD id, and `removeOrphans()` — keyed
            // on the new ids — then deleted every field on the form.
            $savedFieldIdByName = [];
            $savedFieldIdByKey  = [];
            $savedKeyById       = [];

            if ($savedForm !== null) {
                foreach ($savedForm->getFields() as $savedField) {
                    $savedFieldIdByName[$savedField->getName()] = $savedField->getId();
                    $savedFieldIdByKey[$savedField->getKey()]   = $savedField->getId();
                    $savedKeyById[$savedField->getId()]         = $savedField->getKey();
                }
            }

            // `wp_acpt_form_field.field_key` is varchar(12) with a global UNIQUE key. A
            // caller-supplied key that is empty, longer than 12 chars, or shares its
            // first 12 chars with another field in the same payload would be silently
            // truncated by MySQL and collapse several fields onto one row (INSERT ...
            // ON DUPLICATE KEY UPDATE). Normalise to a safe 8-char random key in those
            // cases — field keys are internal identifiers (the admin UI already uses
            // Strings::randomString(8)); the rendered form and the submission handler
            // key off `field_name`, not `field_key`.
            $usedFieldKeys = [];
            foreach ($data['fields'] as $fieldIndex => $field) {
                $fieldName = @$field['name'];

                $fieldId = $field['id']
                    ?? $savedFieldIdByName[$fieldName] ?? null;

                if ($fieldId === null && isset($field['key'])) {
                    $fieldId = $savedFieldIdByKey[$field['key']] ?? null;
                }

                // an existing field with no explicit new key keeps the key it has
                $fieldKey = isset($field['key'])
                    ? (string)$field['key']
                    : ($fieldId !== null ? ($savedKeyById[$fieldId] ?? '') : '');

                if ($fieldKey === '' || mb_strlen($fieldKey) > 12 || in_array($fieldKey, $usedFieldKeys, true)) {
                    do {
                        $fieldKey = Strings::randomString(8);
                    } while (in_array($fieldKey, $usedFieldKeys, true));
                }

                $usedFieldKeys[] = $fieldKey;

                $metaFieldModel = null;
                if (isset($field['metaFieldId'])) {
                    $metaFieldModel = MetaRepository::getMetaFieldById($field['metaFieldId']);
                }

                if (isset($field['meta_field_id'])) {
                    $metaFieldModel = MetaRepository::getMetaFieldById($field['meta_field_id']);
                }

                $isRequired = $field['isRequired'] ?? $field['is_required'];

                $fieldModel = FormFieldModel::hydrateFromArray([
                    'id' => $fieldId,
                    'metaField' => $metaFieldModel,
                    'group' => @$field['group'],
                    'key' => $fieldKey,
                    'name' => @$field['name'],
                    'label' => @$field['label'],
                    'type' => @$field['type'],
                    'description' => @$field['description'],
                    'isRequired' => (bool)@$isRequired,
                    'extra' => $field['extra'] ?? [],
                    'settings' => $field['settings'] ?? [],
                    'sort' => ($fieldIndex+1),
                ]);

                if (isset($field['validationRules']) && !empty($field['validationRules'])) {
                    foreach ($field['validationRules'] as $ruleIndex => $rule) {
                        $validationRuleModel = ValidationRuleModel::hydrateFromArray([
                            'id' => @$rule['id'],
                            'condition' => @$rule['condition'],
                            'value' => @$rule['value'],
                            'message' => @$rule['message'],
                            'sort' => ($ruleIndex+1),
                        ]);

                        $fieldModel->addValidationRule($validationRuleModel);
                    }
                }

                $formModel->addField($fieldModel);
            }
        } elseif ($this->emptyItems === false) {
            // otherwise hydrate with saved fields. Previously gated on the new
            // `action` matching the form's existing action — but `fields` being
            // omitted has nothing to do with whether `action` also changed in the
            // same call, and a caller legitimately changing just the action (a
            // normal partial update, since `fields` isn't required by FormSchema)
            // had every field silently wiped as a side effect.
            if ($savedForm !== null && !empty($savedForm->getFields())) {
                foreach ($savedForm->getFields() as $field) {
                    $formModel->addField($field);
                }
            }
        }

        FormRepository::save($formModel);

        do_action("acpt/form/save", $this, $formModel);

        return $id;
    }

    /**
     * @inheritDoc
     */
    public function logFormat(): array
    {
        return [
            "class"  => SaveFormCommand::class,
            'data' => $this->data
        ];
    }
}
