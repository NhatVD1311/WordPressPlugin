<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Table\TableGroupModel;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\ValueObjects\TableLocationObject;

class SaveTableGroupCommand implements CommandInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * @throws \Exception
     */
    public function execute(): void
    {
        $data = $this->data;
        $id = $data['id'] ?? Uuid::v4();

        $group = new TableGroupModel(
            $id,
            $data['name'],
            $data['label'] ?? null,
            $data['display'] ?? null
        );

        if (!empty($data['context'])) {
            $group->setContext($data['context']);
        }

        if (!empty($data['priority'])) {
            $group->setPriority($data['priority']);
        }

        if (isset($data['sort'])) {
            $group->setSort((int)$data['sort']);
        }

        // location rules
        foreach ($data['location'] ?? [] as $ruleData) {
            if (is_array($ruleData)) {
                try {
                    $loc = new TableLocationObject();
                    $loc->fromArray($ruleData);

                    // fromArray() silently no-ops on a missing (not merely empty)
                    // operator/value for a rule type that requires one, and
                    // addLocationRule() silently drops an invalid rule below — log
                    // it here instead, so a caller isn't left wondering why their
                    // rule vanished with no error.
                    if (!$loc->isValid()) {
                        do_action('acpt/error', new \DomainException(
                            'Skipped invalid location rule for type "' . ($ruleData['rule'] ?? 'unknown')
                            . '": missing required operator/value.'
                        ));

                        continue;
                    }

                    $group->addLocationRule($loc);
                } catch (\Exception $exception) {
                    // A genuinely malformed rule (bad enum value) throws from
                    // fromArray() — skip just that item instead of aborting the
                    // whole group save and losing every other valid rule.
                    do_action('acpt/error', $exception);
                }
            }
        }

        // member tables -- presence of the key, not emptiness, signals intent:
        // an omitted 'tableIds' means "this save doesn't touch membership" (preserve
        // existing tables), while an explicit [] means "unlink every table".
        if (array_key_exists('tableIds', $data)) {
            $group->markTablesExplicitlySet();

            foreach ($data['tableIds'] as $tableId) {
                $table = TableRepository::getById($tableId);
                if ($table !== null) {
                    $group->addTable($table);
                }
            }
        }

        TableGroupRepository::save($group);
    }
}
