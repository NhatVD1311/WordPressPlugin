<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\UITypeToColumnMapper;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\Table\TableColumnModel;
use ACPT\Core\Models\Table\TableForeignKeyModel;
use ACPT\Core\Models\Table\TableIndexModel;
use ACPT\Core\Models\Table\TableModel;
use ACPT\Core\Repository\TableGroupRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\ValueObjects\ColumnOptionObject;
use ACPT\Core\ValueObjects\ConditionalRenderingObject;
use ACPT\Core\ValueObjects\IndexOptionObject;
use ACPT\Core\ValueObjects\KeyPartObject;
use ACPT\Core\ValueObjects\PermissionObject;
use ACPT\Core\ValueObjects\TableOptionObject;
use ACPT\Core\ValueObjects\TableUISettingsObject;
use ACPT\Core\ValueObjects\UIFieldObject;
use ACPT\Core\ValueObjects\ValidationRuleObject;

class SaveTableCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * SaveTaxonomyCommand constructor.
     *
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function execute(): string
    {
        $data = $this->data;

        $id = (isset($data['id'])) ? $data['id'] : Uuid::v4();
        $tableNames = TableRepository::getNames();

        // table name
        if (isset($data['id'])) {
            $tableNames = array_filter($tableNames, function ($item) use ($data) {
                return $item !== $data['name'];
            });
        }

        $name = TableModel::sanitizeName($data['name']);
        $name = Strings::getTheFirstAvailableName($name, $tableNames);

        // table model
        $tableModel = TableModel::hydrateFromArray([
            'id' => $id,
            'name' => $name,
            'label' => $data['label'],
            'idStrategy' => $data['idStrategy'] ?? TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT,
            'restApi' => $data['restAPI'] ?? [],
            'icon' => $data['icon'] ?? 'dashicons-admin-post',
            'menuPosition' => $data['menuPosition'] ?? 99,
            'capability' => $data['capability'] ?? 'manage_options',
            'sort' => $data['sort'] ?? 0,
            'charsetCollate' => $data['charsetCollate'] ?? null,
            'timestamps' => $data['timestamps'] ?? true,
            'softDelete' => $data['softDelete'] ?? false,
        ]);

        // group
        if (!empty($data['tableGroupId'])) {
            $group = TableGroupRepository::getById($data['tableGroupId'], true);
            $tableModel->setTableGroup($group);
        }

        // UI settings
        if (!empty($data['uiSettings']) && is_array($data['uiSettings'])) {
            $tableModel->setUISettings(TableUISettingsObject::fromArray($data['uiSettings']));
        }

        // options
        $hasEngineOption = false;
        foreach ($data['options'] ?? [] as $key => $option) {
            $obj = new TableOptionObject();

            // case 1: key/string pair
            if (is_string($key) && is_string($option)) {
                $obj->fromArray([
                    'key' => $key,
                    'value' => $option,
                ]);
                if ($key === 'ENGINE') {
                    $hasEngineOption = true;
                }

            // case 2: object
            } elseif (is_array($option) && isset($option['key'])) {
                $obj->fromArray($option);
                if ($option['key'] === 'ENGINE') {
                    $hasEngineOption = true;
                }

            // case 3: invalid value
            } else {
                continue;
            }

            $tableModel->addOption($obj);
        }

        // Default the storage engine when the caller omitted it. save_acpt_table()
        // already does this for the function/AJAX path, but the V1 REST controller
        // calls SaveTableCommand directly — without it, MySQL's SHOW CREATE always
        // reports `ENGINE=InnoDB` while createTableQuery() emits none, so the table
        // stays permanently "not synced" and every sync runs a full-table rebuild.
        if (!$hasEngineOption) {
            $engineOption = new TableOptionObject();
            $engineOption->fromArray(['key' => 'ENGINE', 'value' => 'InnoDB']);
            $tableModel->addOption($engineOption);
        }

        // columns
        $c = 0;
        foreach ($data['columns'] ?? [] as $column) {

            // get parent object if present from parent key
            $parent = null;
            if (isset($column['parent'])) {
                $parentObj = $data['columns'][$column['parent']] ?? null;

                if (!empty($parentObj)) {
                    $parent = $tableModel->getColumn($parentObj['name']);
                }
            }

            $idCol = (isset($column['id'])) ? $column['id'] : Uuid::v4();
            $ui = new UIFieldObject();
            $ui->fromArray($column['ui'] ?? []);

            // A submitted relationship config that fails ColumnRelationshipObject::isValid()
            // (e.g. a bidirectional relation on a brand-new, not-yet-saved table, where the
            // inverse-field picker can't populate until the table exists) is silently dropped
            // to null by UIFieldObject::fromArray() -- deliberately not made to throw there,
            // since that method also hydrates already-stored (possibly legacy-invalid) data on
            // read. Surface it here instead, at the write boundary, matching this loop's
            // existing log-and-skip pattern for validationRules/visibilityConditions/
            // permissions/options -- the column still saves (without the relationship), but the
            // silent data loss is no longer silent.
            if (!empty($column['ui']['relationship']) && $ui->relationship === null) {
                do_action('acpt/error', new \Exception(
                    'Column "' . ($column['name'] ?? '?') . '" has an incomplete relationship configuration — it was not saved. '
                    . 'If bidirectional, target and inverse (field, value, label) must all be set. This is commonly incomplete on '
                    . 'a brand-new, not-yet-saved table, since the inverse-field picker cannot populate until the table exists — '
                    . 'save the table once, then edit it again to complete the relationship.'
                ));
            }

            $isChild = !empty($parent) || !empty($ui->parentBlockId);

            // ── Server-authoritative physical-type resolution (#1218 / #1219) ──
            // For a top-level column the physical MySQL type is derived from the
            // UI type via UITypeToColumnMapper whenever the caller did NOT send
            // an explicit real MySQL type. This converges the three write paths
            // (wizard Simple mode, V1 REST, Import) on the same physical column
            // for a given field type. An explicit real MySQL type still wins
            // (Advanced mode / #1195), including the deliberately-divergent
            // {uiType: Select, type: VARCHAR} case. A bare VIRTUAL sentinel on a
            // top-level column is NOT treated as an explicit type — it is the
            // symptom of #1219 (a top-level repeater/flexible/clone container).
            if (!$isChild) {
                $explicitType = $column['type'] ?? null;
                $sentinel     = ($explicitType === TableColumnModel::TABLE_FIELD_VIRTUAL);
                // Only the caller-provided UI type counts — UIFieldObject
                // defaults an absent type to "Text", which must NOT be treated
                // as a signal to derive (a bare {name,label} column stays a
                // hard error, not a silent VARCHAR).
                $callerUiType = $column['ui']['type'] ?? $column['uiType'] ?? null;

                if ((empty($explicitType) || $sentinel) && !empty($callerUiType)) {
                    $resolved = UITypeToColumnMapper::resolve($callerUiType, [
                        'type'   => $sentinel ? null : $explicitType,
                        'length' => $column['length'] ?? null,
                    ]);

                    if ($resolved !== null) {
                        $column['type']   = $resolved['type'];
                        $column['length'] = $resolved['length'];
                    }
                }
            }

            if (!$isChild && (empty($column['type']) || $column['type'] === TableColumnModel::TABLE_FIELD_VIRTUAL)) {
                // Either no `type`/`uiType` was resolvable, or a top-level
                // repeater/flexible/clone container reached here still carrying
                // the VIRTUAL sentinel (VIRTUAL is not a real MySQL column type,
                // and a top-level column always needs a physical one).
                throw new \InvalidArgumentException(
                    'Column "' . ($column['name'] ?? '?') . '" does not resolve to a physical MySQL type '
                    . '(missing/unrecognised `type` / `uiType`) — required for a non-child column.'
                );
            }

            $type = $isChild
                ? TableColumnModel::TABLE_FIELD_VIRTUAL
                : $column['type'];

            $columnModel = TableColumnModel::hydrateFromArray([
                'id' => $idCol,
                'name' => $column['name'],
                'label' => $column['label'],
                'table' => $tableModel,
                'type' => $type,
                'length' => $column['length'] ?? null,
                'nullable' => $column['nullable'] ?? false,
                'unique' => $column['unique'] ?? false,
                'primaryKey' => $column['primaryKey'] ?? false,
                'sort' => $c,
                'defaultValue' => $column['defaultValue'] ?? null,
                'description' => $column['description'] ?? null,
                'columnValues' => (isset($column['columnValues']) && !empty($column['columnValues'])) ? array_column($column['columnValues'], 'value') : null,
                'uiField' => $ui,
            ]);

            if (!empty($parent)) {
                $columnModel->setParentId($parent->getId());
            } else {
                $columnModel->setParentId(null);
            }

            // validation rules — one malformed item (e.g. a bad enum `condition`)
            // must not abort the entire table save and lose every other column.
            foreach ($column['validationRules'] ?? [] as $rule) {
                try {
                    $ruleModel = new ValidationRuleObject();
                    $ruleModel->fromArray($rule);
                    $columnModel->addValidationRule($ruleModel);
                } catch (\Exception $exception) {
                    do_action('acpt/error', $exception);
                }
            }

            // conditional logic
            foreach ($column['visibilityConditions'] ?? [] as $condition) {
                try {
                    $obj = new ConditionalRenderingObject();
                    $obj->fromArray($condition);
                    $columnModel->addVisibilityCondition($obj);
                } catch (\Exception $exception) {
                    do_action('acpt/error', $exception);
                }
            }

            // permissions
            foreach ($column['permissions'] ?? [] as $permission) {
                try {
                    // PermissionObject::isValid() requires a non-empty entityId.
                    // The wizard always sends the column id; an API caller
                    // (ticket #1242 made these schema-writable) may legitimately
                    // omit it — default it to this column's id so the rule is
                    // not silently dropped.
                    if (empty($permission['entityId'])) {
                        $permission['entityId'] = $idCol;
                    }

                    $perm = new PermissionObject();
                    $perm->fromArray($permission);
                    $columnModel->addPermission($perm);
                } catch (\Exception $exception) {
                    do_action('acpt/error', $exception);
                }
            }

            // column options
            foreach ($column['options'] ?? [] as $option) {
                if (isset($option['key'])) {
                    // a column already flagged as the table's primary key does not
                    // need a redundant standalone `PRIMARY KEY` option — keeping both
                    // makes addTableElementExpression() emit `PRIMARY KEY` twice in the DDL.
                    if ($option['key'] === 'PRIMARY KEY' && !empty($column['primaryKey'])) {
                        continue;
                    }

                    try {
                        $obj = new ColumnOptionObject();
                        $obj->fromArray($option);
                        $columnModel->addOption($obj);
                    } catch (\Exception $exception) {
                        do_action('acpt/error', $exception);
                    }
                }
            }

            $tableModel->addColumn($columnModel);
            $c++;
        }

        // indexes — one malformed index (bad key part, missing column, invalid
        // option) must not abort the whole table save; log it and keep the rest,
        // mirroring the per-item handling in the columns loop above.
        $idx = 0;
        foreach ($data['indexes'] ?? [] as $index) {
            try {
                $idIdx = (isset($index['id'])) ? $index['id'] : Uuid::v4();

                $indexModel = TableIndexModel::hydrateFromArray([
                    'id' => $idIdx,
                    'table' => $tableModel,
                    'name' => $index['name'],
                    'lock' => $index['lock'] ?? null,
                    'algorithm' => $index['algorithm'] ?? TableIndexModel::TABLE_INDEX_ALGORITHM_OPTION_DEFAULT,
                    'type' => $index['type'] ?? TableIndexModel::TABLE_INDEX_TYPE_BREE,
                    'strategy' => !empty($index['strategy']) ? $index['strategy'] : null,
                    'sort' => $idx
                ]);

                foreach ($index['keyParts'] ?? [] as $keyPart) {
                    $obj = new KeyPartObject();
                    $obj->fromArray($keyPart);
                    $indexModel->addKeyPart($obj);
                }

                foreach ($index['options'] ?? [] as $option) {
                    $obj = new IndexOptionObject();
                    $obj->fromArray($option);
                    $indexModel->addIndexOption($obj);
                }

                $tableModel->addIndex($indexModel);
                $idx++;
            } catch (\Exception $exception) {
                do_action('acpt/error', $exception);
            }
        }

        $this->validatePrimaryKeyAndAutoIncrement($tableModel);

        // foreign keys — same per-item resilience as the indexes loop.
        $fk = 0;
        foreach ($data['foreignKeys'] ?? [] as $foreignKey) {
            try {
                $idFk = (isset($foreignKey['id'])) ? $foreignKey['id'] : Uuid::v4();
                $refTableName = $foreignKey['referenceTable'] ?? '';

                // A self-referencing FK points at the table currently being saved,
                // whose row may not be persisted yet (create flow) — resolve it to
                // the in-memory model rather than a DB lookup that would miss it.
                $refTable = ($refTableName === $name)
                    ? $tableModel
                    : TableRepository::getByName($refTableName);

                if (empty($refTable)) {
                    throw new \InvalidArgumentException(
                        'Foreign key "' . ($foreignKey['name'] ?? '?') . '" references table "'
                        . $refTableName . '" which does not exist.'
                    );
                }

                $foreignKeyModel = TableForeignKeyModel::hydrateFromArray([
                    'id' => $idFk,
                    'table' => $tableModel,
                    'name' => $foreignKey['name'],
                    'columns' => $foreignKey['columns'],
                    'referenceColumns' => $foreignKey['referenceColumns'],
                    'referenceTable' => $refTable,
                    'onDelete' => $foreignKey['onDelete'] ?? 'CASCADE',
                    'onUpdate' => $foreignKey['onUpdate'] ?? 'CASCADE',
                    'sort' => $fk
                ]);

                $tableModel->addConstraint($foreignKeyModel);
                $fk++;
            } catch (\Exception $exception) {
                do_action('acpt/error', $exception);
            }
        }

        TableRepository::save($tableModel);

        return $id;
    }

    /**
     * Rejects primary-key/auto-increment combinations that would produce invalid DDL
     * (MySQL allows exactly one PRIMARY KEY clause and exactly one AUTO_INCREMENT column
     * per table). The wizard UI tries to prevent these client-side, but this command is
     * also reachable directly via AJAX/REST/API-abilities, so the guard must live here too.
     *
     * @throws \InvalidArgumentException
     */
    private function validatePrimaryKeyAndAutoIncrement(TableModel $tableModel): void
    {
        $columns = $tableModel->getColumns();

        $primaryKeyColumns = array_values(array_filter($columns, function (TableColumnModel $column) {
            return $column->isPrimaryKey();
        }));

        if ($tableModel->hasIdStrategy() && !empty($primaryKeyColumns)) {
            throw new \InvalidArgumentException(
                'Column "'.$primaryKeyColumns[0]->getName().'" cannot be flagged as primary key while the table already has an `idStrategy` other than `none`.'
            );
        }

        if (count($primaryKeyColumns) > 1) {
            throw new \InvalidArgumentException(
                'Only one column can be flagged as the table primary key (composite primary keys are not supported); found: '
                . implode(', ', array_map(function (TableColumnModel $column) {
                    return $column->getName();
                }, $primaryKeyColumns))
            );
        }

        // MySQL silently forces a PRIMARY KEY column to NOT NULL regardless of what's
        // configured — without this guard, saving a column as both "primary key" and
        // "nullable" produces no error here, but the physical table it creates will never
        // match the stored (nullable=true) definition, leaving the table permanently
        // reported as "Not synced" with every "Sync table" action proposing the exact
        // same no-op ALTER statement forever, and no indication anywhere of why.
        foreach ($primaryKeyColumns as $column) {
            if ($column->isNullable()) {
                throw new \InvalidArgumentException(
                    'Column "'.$column->getName().'" cannot be both the primary key and nullable — a PRIMARY KEY column is always NOT NULL.'
                );
            }
        }

        $autoIncrementColumns = array_values(array_filter($columns, function (TableColumnModel $column) {
            return $column->isAutoIncrement();
        }));

        foreach ($autoIncrementColumns as $column) {
            if ($column->isPrimaryKey()) {
                continue;
            }

            $isCoveredByUniqueIndex = false;
            foreach ($tableModel->getIndexes() as $index) {
                if (!$index->isUnique()) {
                    continue;
                }
                foreach ($index->getKeyParts() as $keyPart) {
                    if ($keyPart->colName === $column->getName()) {
                        $isCoveredByUniqueIndex = true;
                        break 2;
                    }
                }
            }

            if (!$isCoveredByUniqueIndex) {
                throw new \InvalidArgumentException(
                    'Column "'.$column->getName().'" has AUTO_INCREMENT but is not the primary key and is not covered by a UNIQUE index — MySQL requires an AUTO_INCREMENT column to be a key.'
                );
            }
        }

        $autoIncrementSourceCount = count($autoIncrementColumns)
            + ($tableModel->getIdStrategy() === TableModel::TABLE_ID_STRATEGY_AUTO_INCREMENT ? 1 : 0);

        if ($autoIncrementSourceCount > 1) {
            throw new \InvalidArgumentException(
                'A table can only have one AUTO_INCREMENT column; found '.$autoIncrementSourceCount.'.'
            );
        }
    }

    public function logFormat(): array
    {
        return [
            "class"  => SaveTableCommand::class,
            'data' => $this->data
        ];
    }
}
