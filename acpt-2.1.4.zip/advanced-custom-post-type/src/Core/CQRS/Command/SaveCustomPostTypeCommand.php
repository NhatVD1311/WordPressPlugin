<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Core\Generators\CustomPostType\CustomPostTypeGenerator;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Helper\Uuid;
use ACPT\Core\Models\CustomPostType\CustomPostTypeModel;
use ACPT\Core\Models\Permission\PermissionModel;
use ACPT\Core\Repository\CustomPostTypeRepository;
use ACPT\Integrations\WPGraphQL\Utils\GraphQLValidator;
use ACPT\Utils\PHP\Image;
use ACPT\Utils\Wordpress\WPAttachment;

class SaveCustomPostTypeCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $data;

    /**
     * @param array<string, mixed> $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * @return string
     * @throws \Exception
     */
    public function execute(): string
    {
        $data = $this->data;

        // Custom icon image resize
        if (isset($data['icon']) && Strings::isUrl($data['icon'])) {
            $attachment = WPAttachment::fromUrl($data['icon']);

            if ($attachment->isImage()) {
                $data['icon'] = Image::resize($attachment, 20, 20);
            }
        }

        // GraphQL single/plural names are free text on the wizard - enforce GraphQL's
        // identifier grammar here, at the write boundary, instead of trusting the client
        if (isset($data['settings']) && is_array($data['settings'])) {
            foreach (['graphql_single_name', 'graphql_plural_name'] as $graphQLNameKey) {
                if (empty($data['settings'][$graphQLNameKey]) || !is_string($data['settings'][$graphQLNameKey])) {
                    continue;
                }

                try {
                    GraphQLValidator::validateName($data['settings'][$graphQLNameKey]);
                } catch (\Exception $exception) {
                    $data['settings'][$graphQLNameKey] = GraphQLValidator::sanitizeName($data['settings'][$graphQLNameKey]);
                }
            }
        }

        $postTypeModel = CustomPostTypeModel::hydrateFromArray([
            'id' => ($data['id'] ? $data['id'] : Uuid::v4()),
            'name' => @$data['name'],
            'singular' => @$data["singular_label"],
            'plural' => @$data["plural_label"],
            'icon' => @$data["icon"],
            'native' => false,
            'supports' => @$data['supports'],
            'labels' =>  @$data['labels'],
            'settings' =>  @$data['settings'],
        ]);

        CustomPostTypeRepository::save($postTypeModel);

        $permissions = $data['permissions'] ?? [];

        if (is_array($permissions) && !empty($permissions)) {
            foreach ($permissions as $permissionIndex => $permission) {
                $permissionModel = PermissionModel::hydrateFromArray([
                    'id' => (isset($permission["id"]) ? $permission["id"] : Uuid::v4()),
                    'entityId' => $postTypeModel->getId(),
                    'userRole' => $permission['userRole'] ?? $permission['user_role'],
                    'permissions' => $permission['permissions'] ?? [],
                    'sort' => ($permissionIndex+1),
                ]);

                $postTypeModel->addPermission($permissionModel);
            }
        }

        // generate CPT in WP tables
        $customPostTypeGenerator = new CustomPostTypeGenerator($postTypeModel);
        $customPostTypeGenerator->registerPostType();

        // save permissions
        if ($postTypeModel->hasPermissions()) {
            $command = new SavePermissionCommand([
                'entityId' => $postTypeModel->getId(),
                'items' => $postTypeModel->getPermissionsAsArray()
            ]);

            $command->execute();
        }

        $this->flushPermalinkRules();

        do_action("acpt/custom_post_type/save", $this, $postTypeModel);

        return $postTypeModel->getId();
    }

    /**
     * Reset the permalink structure
     */
    private function flushPermalinkRules(): void
    {
        flush_rewrite_rules();
    }

    /**
     * @inheritDoc
     */
    public function logFormat(): array
    {
        return [
            "class"  => SaveCustomPostTypeCommand::class,
            'data' => $this->data
        ];
    }
}
