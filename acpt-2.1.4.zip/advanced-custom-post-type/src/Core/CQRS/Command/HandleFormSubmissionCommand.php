<?php

namespace ACPT\Core\CQRS\Command;

use ACPT\Constants\ExtraFields;
use ACPT\Constants\FormAction;
use ACPT\Constants\MetaTypes;
use ACPT\Constants\TaxonomyField;
use ACPT\Core\Helper\CCTFieldShape;
use ACPT\Core\Helper\Strings;
use ACPT\Utils\Data\TableRecord;
use ACPT\Core\Models\Form\FormFieldModel;
use ACPT\Core\Models\Form\FormModel;
use ACPT\Core\Models\Form\FormSubmissionModel;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\Settings\SettingsModel;
use ACPT\Core\Models\Validation\ValidationRuleModel;
use ACPT\Core\Repository\FormRepository;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\TableRecordRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Core\ValueObjects\FormSubmissionDatumObject;
use ACPT\Core\ValueObjects\FormSubmissionErrorObject;
use ACPT\Core\ValueObjects\FormSubmissionLimitObject;
use ACPT\Includes\ACPT_DB;
use ACPT\Utils\Checker\ValidationRulesChecker;
use ACPT\Utils\Data\Meta;
use ACPT\Utils\Data\Sanitizer;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\PHPEval\PhpEval;
use ACPT\Utils\PHP\Request;
use ACPT\Utils\PHP\Twig;
use ACPT\Utils\Settings\Settings;
use ACPT\Utils\Wordpress\Email\EmailTemplateFactory;
use ACPT\Utils\Wordpress\Email\Envelope;
use ACPT\Utils\Wordpress\Email\EnvelopeBody;
use ACPT\Utils\Wordpress\Files;
use ACPT\Utils\Wordpress\Nonce;
use ACPT\Utils\Wordpress\WPAttachment;
use ACPT\Core\Validators\MetaDataValidator;

class HandleFormSubmissionCommand implements CommandInterface, LogFormatInterface
{
    /**
     * @var FormModel
     */
    private FormModel $formModel;

    /**
     * @var array<int|string, mixed>
     */
    private array $data;

    /**
     * Unsanitized POST params: the required check must see what was actually submitted,
     * since sanitizing a Number field turns '' into 0 (indistinguishable from a real 0).
     *
     * @var array<int|string, mixed>
     */
    private array $rawData;

    /**
     * @var array<int, mixed>
     */
    private array $errors = [];

    /**
     * @var int|null
     */
    private ?int $postId;

    /**
     * @var int|null
     */
    private ?int $userId;

    /**
     * @var int|null
     */
    private ?int $termId;

    /**
     * @var int|string|null
     */
    private $recordId;

    /**
     * Ids of the form fields the current user may not write (see authorize()).
     *
     * @var array<string, bool>
     */
    private array $deniedFieldIds = [];

    /**
     * HandleFormSubmissionCommand constructor.
     * @param FormModel $formModel
     * @param Request $request
     * @param int|null $postId
     * @param int|null $termId
     * @param int|null $userId
     * @param int|string|null $recordId
     * @throws \Exception
     */
    public function __construct(
        FormModel $formModel,
        Request $request,
        ?int $postId = null,
        ?int $termId = null,
        ?int $userId = null,
        $recordId = null
    ) {
        $this->formModel = $formModel;
        $this->rawData = $request->postParams();
        $this->data = $this->sanitizeData($this->rawData, $request->files());
        $this->postId = $postId;
        $this->termId = $termId;
        $this->userId = $userId;
        $this->recordId = $recordId;

        $this->checkTheNonce($request->post($this->formModel->getId()));

        // for PHP handling
        $_POST = $this->data;

        do_action('acpt/save_form', $this, $formModel);
    }

    private function addError(string $id, string $message): void
    {
        $this->errors[] = [
            "id" => $id,
            "message" => $message,
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $files
     * @return array<int|string, mixed>
     * @throws \Exception
     */
    private function sanitizeData(array $data = [], array $files = []): array
    {
        $sanitized = [];

        foreach ($this->formModel->getFields() as $fieldModel) {
            $this->recursiveSanitizeFieldValue($fieldModel, $data, $files, $sanitized);
        }

        // captcha
        if (isset($data['g-recaptcha-response'])) {
            $sanitized['g-recaptcha-response'] = [
                'type' => FormFieldModel::CAPTCHA_TYPE,
                'value' => Sanitizer::sanitizeRawData(FormFieldModel::CAPTCHA_TYPE, $data['g-recaptcha-response']),
            ];
        }

        // turnstile
        if (isset($data['cf-turnstile-response'])) {
            $sanitized['cf-turnstile-response'] = [
                'type' => FormFieldModel::TURNSTILE_TYPE,
                'value' => Sanitizer::sanitizeRawData(FormFieldModel::TURNSTILE_TYPE, $data['cf-turnstile-response']),
            ];
        }

        return $sanitized;
    }

    /**
     * @param FormFieldModel $fieldModel
     * @param array<int|string, mixed> $data
     * @param array<int|string, mixed> $files
     * @param array<int|string, mixed> $sanitized
     */
    private function recursiveSanitizeFieldValue(FormFieldModel $fieldModel, array $data = [], array $files = [], array &$sanitized = []): void
    {
        $sanitized[] = $this->sanitizeFieldValue($fieldModel, $data, $files);

        foreach ($fieldModel->getChildren() as $childFieldModel) {
            $this->recursiveSanitizeFieldValue($childFieldModel, $data, $files, $sanitized);
        }
    }

    /**
     * @param FormFieldModel $fieldModel
     * @param array<int|string, mixed> $data
     * @param array<int|string, mixed> $files
     *
     * @return array<int|string, mixed>
     */
    private function sanitizeFieldValue(FormFieldModel $fieldModel, array $data = [], array $files = []): array
    {
        // file handling
        $type = $data[$fieldModel->getName().'_type'] ?? '';
        $key = $data[$fieldModel->getName().'_key'] ?? '';
        $value = null;
        $extra = [];
        $allowHtml = false;
        $allowDangerousContent = false;

        if ($this->isARepeaterField($type)) {
            $this->handleRepeaterField($fieldModel, $data, $files, $value, $extra);
        } elseif ($this->isAFileField($type)) {
            $this->handleUploadFile($fieldModel, $data, $files, $value, $extra);
        } else {
            if (isset($data[$fieldModel->getName()])) {
                $rawData = $data[$fieldModel->getName()];

                if ($fieldModel->getMetaField() !== null) {
                    $fieldType = $fieldModel->getMetaField()->getType();

                    // Textual fields
                    if (
                        $fieldModel->getType() === MetaFieldModel::TEXT_TYPE ||
                        $fieldModel->getType() === MetaFieldModel::TEXTAREA_TYPE
                    ) {
                        $allowHtml = $fieldModel->getMetaField()->getAdvancedOption("allow_html") ?? false;
                    }

                    // HTML/Editor fields
                    if (
                        $fieldType === MetaFieldModel::HTML_TYPE ||
                        $fieldType === MetaFieldModel::EDITOR_TYPE
                    ) {
                        $allowHtml = true;
                        $allowDangerousContent = $fieldModel->getMetaField()->getAdvancedOption("allow_dangerous_content") ?? false;
                    }
                }

                // CCT HTML/Editor fields
                if ($fieldModel->getType() === MetaFieldModel::TEXTAREA_TYPE && !empty($fieldModel->getExtra()['wysiwyg'])) {
                    $allowHtml = true;
                }

                $value = Sanitizer::sanitizeRawData($type, $rawData, [
                    'allow_dangerous_content' => $allowDangerousContent,
                    'allow_html' => $allowHtml
                ]);
            }
        }

        foreach (ExtraFields::ALLOWED_VALUES as $e) {
            if (isset($data[$fieldModel->getName().'_'.$e]) && !isset($extra[$e])) {
                $extra[$e] = $data[$fieldModel->getName().'_'.$e];
            }
        }

        return [
            'id' => $fieldModel->getId(),
            'type' => $type,
            'key' => $key,
            'value' => $value,
            'name' => $fieldModel->getName(),
            'required' => $fieldModel->isRequired(),
            'isMeta' => $fieldModel->isACPTMetaField(),
            'isPost' => $fieldModel->isWordPressPostField(),
            'isTerm' => $fieldModel->isWordPressTermField(),
            'isUser' => $fieldModel->isWordPressUserField(),
            'extra' => $extra,
            'allowHtml' => $allowHtml,
            'allowDangerousContent' => $allowDangerousContent,
        ];
    }

    /**
     * @param string $type
     *
     * @return bool
     */
    private function isAFileField(string $type): bool
    {
        $fileTypes = [
            FormFieldModel::WORDPRESS_POST_THUMBNAIL,
            FormFieldModel::FILE_TYPE,
            MetaFieldModel::IMAGE_TYPE,
            MetaFieldModel::IMAGE_SLIDER_TYPE,
            MetaFieldModel::VIDEO_TYPE,
            MetaFieldModel::AUDIO_MULTI_TYPE,
            MetaFieldModel::AUDIO_TYPE,
            MetaFieldModel::GALLERY_TYPE,
        ];

        return in_array($type, $fileTypes);
    }

    /**
     * @param string $type
     *
     * @return bool
     */
    private function isARepeaterField(string $type): bool
    {
        $fileTypes = [
            FormFieldModel::REPEATER_TYPE,
        ];

        return in_array($type, $fileTypes);
    }

    /**
     * @param FormFieldModel $fieldModel
     * @param array<int|string, mixed> $data
     * @param array<int|string, mixed> $files
     * @param mixed|null $value
     * @param array<string, mixed> $extra
     * @return void
     */
    private function handleRepeaterField(FormFieldModel $fieldModel, array $data = [], array $files = [], &$value = null, array &$extra = []): void
    {
        $rawFiles = $files[$fieldModel->getName()];
        $rawData = $data[$fieldModel->getName()];

        if (!empty($rawFiles) && is_array($rawFiles)) {
            foreach ($rawFiles['tmp_name'] as $fieldName => $rawFile) {
                $urls = [];

                foreach ($rawFile as $i => $f) {
                    $tmpFile = $f["value"];
                    $size = $rawFiles['size'][$fieldName][$i]['value'];
                    $filename = $rawFiles['name'][$fieldName][$i]['value'];

                    if (!empty($tmpFile)) {

                        // gallery/audio playlist
                        if (is_array($tmpFile)) {
                            for ($k = 0; $k < Arrays::count($tmpFile); $k++) {
                                if (!empty($tmpFile[$k])) {
                                    $this->checkFileSize($size[$k], $fieldModel);
                                    $this->checkImageDimension($tmpFile[$k], $fieldModel);
                                    $this->checkImageMimeType($tmpFile[$k], $fieldModel);
                                    $file = Files::uploadFile($tmpFile[$k], $filename[$k]);

                                    if ($file === false) {
                                        $this->addError($fieldName, "File upload failed");
                                        continue;
                                    }

                                    $urls[$fieldName][$i]['value'][$k] = $file['url'];
                                    $urls[$fieldName][$i]['attachment_id'][$k] = $file['attachmentId'];
                                }
                            }
                        } else {
                            $this->checkFileSize($size, $fieldModel);
                            $this->checkImageDimension($tmpFile, $fieldModel);
                            $this->checkImageMimeType($tmpFile, $fieldModel);
                            $file = Files::uploadFile($tmpFile, $filename);

                            if ($file === false) {
                                $this->addError($fieldName, "File upload failed");
                            } else {
                                $urls[$fieldName][$i]['value'] = $file['url'];
                                $urls[$fieldName][$i]['attachment_id'] = $file['attachmentId'];
                            }
                        }
                    }
                }

                $value = $urls;
            }
        }

        if (!empty($rawData) && is_array($rawData)) {
            foreach ($rawData as $fieldName => $rawDatum) {
                foreach ($rawDatum as $i => $d) {
                    $rawData = $d["value"];

                    if (empty($value[$fieldName][$i]['value'])) {
                        $newValue = Sanitizer::sanitizeRawData($d["type"], $rawData);

                        if (!empty($newValue) && [0 => ""] !== $newValue) {
                            $value[$fieldName][$i]['value'] = $newValue;
                        }
                    }

                    // Extra info
                    foreach (ExtraFields::ALLOWED_VALUES as $e) {
                        if (isset($d[$e]) && !isset($value[$fieldName][$i][$e])) {
                            $value[$fieldName][$i][$e] = $d[$e];
                        }
                    }

                    // Fix attachment_id
                    if ($d["type"] === FormFieldModel::FILE_TYPE && empty($value[$fieldName][$i]['attachment_id'])) {
                        $attachment = WPAttachment::fromUrl($value[$fieldName][$i]['value']);
                        $value[$fieldName][$i]['attachment_id'] = $attachment->getId();
                    }
                }
            }
        }

        // sort $value
        if (is_array($value)) {
            foreach (array_keys($value) as $key) {
                ksort($value[$key]);
                $value[$key] = Arrays::reindex($value[$key]);

                foreach ($value[$key] as $index => $nestedField) {
                    if (is_array($value[$key][$index]['value'])) {
                        ksort($value[$key][$index]['value']);
                        $value[$key][$index]['value'] = Arrays::reindex($value[$key][$index]['value']);
                    }
                }
            }
        }
    }

    /**
     * @param FormFieldModel $fieldModel
     * @param mixed $data
     * @param mixed $files
     * @param mixed $value
     * @param array<string, mixed> $extra
     */
    private function handleUploadFile(FormFieldModel $fieldModel, $data, $files, &$value = null, array &$extra = []): void
    {
        $rawFile = $files[$fieldModel->getName()] ?? null;
        $rawData = $data[$fieldModel->getName()] ?? null;

        // Check image slider field (only 2 images are allowed)
        if (is_array($rawFile) && isset($rawFile['tmp_name']) && $fieldModel->getMetaField() !== null && $fieldModel->getMetaField()->getType() === MetaFieldModel::IMAGE_SLIDER_TYPE) {
            if (Arrays::count($rawFile['tmp_name']) > 2) {
                $this->addError($fieldModel->getId(), "A maximum of 2 files can be uploaded");
                return;
            }
        }

        // This means that the user didn't send any file and/or some gallery items were deleted
        if ($this->filesAreEmpty($rawFile)) {
            if (is_array($rawData)) {
                $raw = (string) ($rawData[0] ?? '');

                if ($raw === '') {
                    $value = [];
                } elseif (Strings::isJson($raw)) {
                    $decoded = json_decode($raw, true);
                    $value = [];
                    foreach (is_array($decoded) ? $decoded : [] as $item) {
                        if (is_array($item) && isset($item['url'])) {
                            $value[] = [
                                'url'           => $item['url'],
                                'attachment_id' => (string) ($item['attachment_id'] ?? ''),
                            ];
                        } elseif (is_string($item) && $item !== '') {
                            $attachment = WPAttachment::fromUrl($item);
                            $value[] = [
                                'url'           => $item,
                                'attachment_id' => (string) $attachment->getId(),
                            ];
                        }
                    }
                } else {
                    $existingUrls = explode(",", $raw);
                    $value = [];
                    foreach ($existingUrls as $url) {
                        $url = trim($url);
                        if ($url !== '') {
                            $attachment = WPAttachment::fromUrl($url);
                            $value[] = [
                                'url'           => $url,
                                'attachment_id' => (string) $attachment->getId(),
                            ];
                        }
                    }
                }
            } else {
                $value = $rawData;
            }
        }

        // Uploaded file from the user
        elseif (!empty($rawFile) && !empty($rawFile['tmp_name'])) {

            // gallery/playlist fields
            if (is_array($rawFile['tmp_name'])) {
                $items = [];
                $ids = [];

                foreach ($rawFile['tmp_name'] as $index => $tmpFile) {
                    if (!empty($tmpFile)) {
                        $this->checkFileSize($rawFile['size'][$index], $fieldModel);
                        $this->checkImageDimension($tmpFile, $fieldModel);
                        $this->checkImageMimeType($tmpFile, $fieldModel);
                        $file = Files::uploadFile($tmpFile, $rawFile['name'][$index]);

                        if ($file === false) {
                            $this->addError($fieldModel->getId(), "File upload failed");
                            continue;
                        }

                        $items[] = [
                            'url'           => $file['url'],
                            'attachment_id' => (string) $file['attachmentId'],
                        ];
                        $ids[] = $file['attachmentId'];
                    }
                }

                $value = $items;
                $extra['attachment_id'] = implode(",", $ids);
            } else {
                if (!empty($rawFile['tmp_name'])) {
                    $this->checkFileSize($rawFile['size'], $fieldModel);
                    $this->checkImageDimension($rawFile['tmp_name'], $fieldModel);
                    $this->checkImageMimeType($rawFile['tmp_name'], $fieldModel);
                    $file = Files::uploadFile($rawFile['tmp_name'], $rawFile['name']);

                    if ($file === false) {
                        $this->addError($fieldModel->getId(), "File upload failed");
                    } else {
                        $value = $file['url'];
                        $extra['attachment_id'] = $file['attachmentId'];
                    }
                }
            }
        }
    }

    /**
     * @param array<string, mixed>|null $rawFile
     * @return bool
     */
    private function filesAreEmpty(?array $rawFile): bool
    {
        if ($rawFile === null || !isset($rawFile['tmp_name'])) {
            return true;
        }

        if (is_array($rawFile['tmp_name'])) {
            return empty($rawFile['tmp_name'][0]);
        }

        return empty($rawFile['tmp_name']);
    }

    /**
     * Validates the MIME type of an uploaded image file against the criteria defined in the associated FormFieldModel.
     *
     * @param string $tmpFile The temporary file path of the uploaded image.
     * @param FormFieldModel $fieldModel The form field model containing metadata and validation rules for the file.
     * @return void
     */
    private function checkImageMimeType(string $tmpFile, FormFieldModel $fieldModel): void
    {
        if ($fieldModel->getMetaField() === null) {
            return;
        }

        try {
            $fieldModel->getMetaField()->validateFileMimeType($tmpFile);
        } catch (\Exception $exception) {
            $this->addError($fieldModel->getId(), $exception->getMessage());
        }
    }

    /**
     * Checks the dimensions of an uploaded image against the constraints defined in the field model.
     *
     * @param string $tmpFile The temporary file path of the uploaded image.
     * @param FormFieldModel $fieldModel The field model containing metadata and validation logic for the image.
     * @return void
     */
    private function checkImageDimension(string $tmpFile, FormFieldModel $fieldModel): void
    {
        if ($fieldModel->getMetaField() === null) {
            return;
        }

        try {
            $fieldModel->getMetaField()->validateImageDimension($tmpFile);
        } catch (\Exception $exception) {
            $this->addError($fieldModel->getId(), $exception->getMessage());
        }
    }

    /**
     * @param int $size
     * @param FormFieldModel $fieldModel
     */
    private function checkFileSize(int $size, FormFieldModel $fieldModel): void
    {
        // validate against validation rules
        foreach ($fieldModel->getValidationRules() as $rule) {
            switch ($rule->getCondition()) {
                case ValidationRuleModel::MAX_SIZE:
                    if ($size > Strings::convertToBytes($rule->getValue())) {
                        $this->addError($fieldModel->getId(), str_replace("{{v}}", $rule->getValue(), $rule->getMessage()));
                    }
                    break;

                case ValidationRuleModel::MIN_SIZE:
                    if ($size < Strings::convertToBytes($rule->getValue())) {
                        $this->addError($fieldModel->getId(), str_replace("{{v}}", $rule->getValue(), $rule->getMessage()));
                    }
            }
        }

        if ($fieldModel->getMetaField() === null) {
            return;
        }

        try {
            $fieldModel->getMetaField()->validateFileSize($size);
        } catch (\Exception $exception) {
            $this->addError($fieldModel->getId(), $exception->getMessage());
        }
    }

    /**
     * @inheritDoc
     * @throws \Exception
     *
     * @return array<string, mixed>
     */
    public function execute(): array
    {
        if (!$this->formModel->isAccessibleToCurrentUser()) {
            $this->addError($this->formModel->getId(), 'You do not have permission to submit this form');
        }

        if ($this->isValid()) {
            $this->checkCaptcha();
        }

        unset($this->data['g-recaptcha-response']);
        unset($this->data['cf-turnstile-response']);

        if ($this->isValid()) {
            $this->validate();
        }

        if ($this->isValid()) {
            $this->authorize();
        }

        if ($this->isValid()) {
            $this->doAction();
            $this->sendMail();
            $this->saveFormSubmission();
        }

        return [
            'success' => $this->isValid(),
            'errors' => $this->errors
        ];
    }

    /**
     * @return bool
     */
    private function isValid(): bool
    {
        return empty($this->errors);
    }

    /**
     * Verify nonce value
     *
     * @param string|null $nonce
     */
    private function checkTheNonce(?string $nonce): void
    {
        if ($nonce === null || !Nonce::verify($nonce)) {
            $this->addError($this->formModel->getId(), 'Nonce not valid');
        }
    }

    /**
     * @see https://suleymanozcan.medium.com/how-to-use-cloudflare-turnstile-with-vanilla-php-e409e5addb14
     * @see https://codeforgeek.com/google-recaptcha-tutorial/
     * @throws \Exception
     */
    private function checkCaptcha(): void
    {
        foreach ($this->formModel->getFields() as $fieldModel) {
            switch ($fieldModel->getType()) {

                // Google ReCaptcha
                case FormFieldModel::CAPTCHA_TYPE:

                    $googleRecaptchaSiteKey = (isset($fieldModel->getExtra()['googleSiteKey']) && !empty($fieldModel->getExtra()['googleSiteKey'])) ? $fieldModel->getExtra()['googleSiteKey'] : (Settings::get(SettingsModel::GOOGLE_RECAPTCHA_SITE_KEY));
                    $googleRecaptchaSecretKey = (isset($fieldModel->getExtra()['googleSecretKey']) && !empty($fieldModel->getExtra()['googleSecretKey'])) ? $fieldModel->getExtra()['googleSecretKey'] : (Settings::get(SettingsModel::GOOGLE_RECAPTCHA_SECRET_KEY));

                    if (empty($googleRecaptchaSiteKey) || empty($googleRecaptchaSecretKey)) {
                        $this->addError($fieldModel->getId(), 'ReCaptcha key and secret are not set');

                        return;
                    }

                    if (!isset($this->data['g-recaptcha-response'])) {
                        $this->addError($fieldModel->getId(), 'ReCaptcha response not found');

                        return;
                    }

                    $secretKey = $googleRecaptchaSecretKey;
                    $captcha = $this->data['g-recaptcha-response']['value'];

                    $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
                    $response = file_get_contents($url);

                    if (empty($response)) {
                        $this->addError($fieldModel->getId(), 'ReCaptcha validation failed');
                        return;
                    }

                    $responseKeys = json_decode($response, true);

                    if ($responseKeys === false || empty($responseKeys["success"])) {
                        $this->addError($fieldModel->getId(), 'ReCaptcha validation failed');
                    }

                    return;

                    // Cloudflare turnstile
                case FormFieldModel::TURNSTILE_TYPE:

                    $cloudflareTurnstileSiteKey = (isset($fieldModel->getExtra()['turnstileSiteKey']) && !empty($fieldModel->getExtra()['turnstileSiteKey'])) ? $fieldModel->getExtra()['turnstileSiteKey'] : (Settings::get(SettingsModel::CLOUDFLARE_TURNSTILE_SITE_KEY));
                    $cloudflareTurnstileSecretKey = (isset($fieldModel->getExtra()['turnstileSecretKey']) && !empty($fieldModel->getExtra()['turnstileSecretKey'])) ? $fieldModel->getExtra()['turnstileSecretKey'] : (Settings::get(SettingsModel::CLOUDFLARE_TURNSTILE_SECRET_KEY));

                    if (empty($cloudflareTurnstileSiteKey) || empty($cloudflareTurnstileSecretKey)) {
                        $this->addError($fieldModel->getId(), 'Cloudflare Turnstile key and secret are not set');
                        return;
                    }

                    if (!isset($this->data['cf-turnstile-response'])) {
                        $this->addError($fieldModel->getId(), 'Cloudflare Turnstile response not found');
                        return;
                    }

                    $secretKey         = $cloudflareTurnstileSecretKey;
                    $turnstileResponse = $this->data['cf-turnstile-response']['value'];
                    $url               = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
                    $post_fields       = "secret=$secretKey&response=$turnstileResponse";

                    $ch = curl_init($url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
                    $response = curl_exec($ch);
                    curl_close($ch);

                    if (!is_string($response) || empty($response)) {
                        $this->addError($fieldModel->getId(), 'Cloudflare Turnstile validation failed');
                        return;
                    }

                    $responseData = json_decode($response);

                    if ($responseData->success != 1) {
                        $this->addError($fieldModel->getId(), 'Cloudflare Turnstile validation failed');
                    }

                    return;
            }
        }
    }

    /**
     * BE validation
     * @throws \Exception
     *
     * @return void
     */
    private function validate(): void
    {
        foreach ($this->formModel->getFields() as $fieldModel) {
            try {
                $value = array_filter($this->data, function ($item) use ($fieldModel) {
                    return $fieldModel->getName() === $item['name'];
                });

                if (empty($value)) {
                    continue;
                }

                $value = array_values($value)[0]['value'];

                if (
                    $fieldModel->isRequired() &&
                    MetaDataValidator::isBlank($this->rawData[$fieldModel->getName()] ?? $value)
                ) {
                    throw new \Exception("The field is required");
                }

                if (!empty($fieldModel->getValidationRules())) {
                    if ($fieldModel->isTextualField()) {
                        // same predicate DataValidateAttributes was handed at render time,
                        // so MIN/MAX mean the same thing here as in the browser
                        $validationRulesChecker = new ValidationRulesChecker($value, $fieldModel->getValidationRules(), $fieldModel->isTextualField(), $fieldModel->isRequired());
                        $validationRulesChecker->validate();

                        if (!$validationRulesChecker->isValid()) {
                            $errors = [];

                            foreach ($validationRulesChecker->getErrors() as $error) {
                                $errors[] = $error;
                            }

                            foreach ($errors as $error) {
                                $this->addError($fieldModel->getId(), $error) ;
                            }

                            return;
                        }
                    }
                }

                $fieldModel->validateAgainstMaxAndMin($value);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
                $this->addError($fieldModel->getId(), $exception->getMessage());

                return;
            }
        }

        $this->checkSubmissionLimit();
    }

    /**
     * @throws \Exception
     */
    private function checkSubmissionLimit(): bool
    {
        $submissionLimits = ($this->formModel->getMetaDatum('submission_limits') !== null) ? $this->formModel->getMetaDatum('submission_limits')->getFormattedValue() : [];

        if (empty($submissionLimits)) {
            return false;
        }

        if (is_array($submissionLimits)) {
            foreach ($submissionLimits as $submissionLimit) {
                try {
                    $submissionLimitObject = FormSubmissionLimitObject::fromArray($submissionLimit);
                } catch (\Exception $e) {
                    do_action("acpt/error", $e);
                    continue;
                }

                if ($submissionLimitObject->hasRuleMatched()) {
                    if ($this->formModel->getSubmissionsCount($submissionLimitObject) >= $submissionLimitObject->getValue()) {
                        $this->addError($this->formModel->getId(), 'Submission limit reached');

                        return false;
                    }
                }
            }
        }

        return true;
    }

    /**
     * Pre-write authorization (ticket #1345). Runs after validation and before doAction(),
     * so a rejected submission never touches the database.
     *
     * - a field the current user may not edit (ACPT field / CCT column Permissions) is
     *   dropped from the write and logged, like the admin save path does (ticket #1243);
     * - writing a CCT record without the table's create/update permission rejects the submission;
     * - `acpt/form/authorize_field` and `acpt/form/authorize_submission` let other plugins
     *   drop a field (return false) or reject the whole submission (return a WP_Error).
     *
     * @return void
     */
    private function authorize(): void
    {
        foreach ($this->data as $datum) {
            if (!isset($datum['id'])) {
                continue;
            }

            $formField = $this->findFormField($datum['id']);

            if ($formField === null) {
                continue;
            }

            $allowed = apply_filters('acpt/form/authorize_field', $this->currentUserCanWriteField($datum), $datum, $formField, $this->formModel);

            if ($allowed instanceof \WP_Error) {
                $this->addError($datum['id'], $allowed->get_error_message());
                continue;
            }

            if ($allowed === false) {
                $this->deniedFieldIds[$datum['id']] = true;
                do_action("acpt/error", new \Exception(sprintf(
                    'Blocked a form write to field "%s": the current user is not allowed to edit it.',
                    $datum['name']
                )));
            }
        }

        foreach ($this->tablesToWrite() as $tableName => $isUpdate) {
            $table = TableRepository::getByName($tableName);

            if ($table === null) {
                continue;
            }

            $capability = $isUpdate ? 'update' : 'create';

            if (!($table->userPermissions()[$capability] ?? false)) {
                $this->addError($this->formModel->getId(), 'You do not have permission to ' . $capability . ' records in ' . $table->getName());
            }
        }

        $allowed = apply_filters('acpt/form/authorize_submission', true, $this->formModel, $this->data, [
            'action' => $this->formModel->getAction(),
            'postId' => $this->postId,
            'termId' => $this->termId,
            'userId' => $this->userId,
            'recordId' => $this->recordId,
        ]);

        if ($allowed instanceof \WP_Error) {
            $this->addError($this->formModel->getId(), $allowed->get_error_message());
        } elseif ($allowed === false) {
            $this->addError($this->formModel->getId(), 'You do not have permission to submit this form');
        }
    }

    /**
     * The submitted data minus the fields authorize() denied.
     *
     * @return array<int|string, mixed>
     */
    private function writableData(): array
    {
        return array_filter($this->data, function ($datum) {
            return !isset($datum['id']) || !isset($this->deniedFieldIds[$datum['id']]);
        });
    }

    /**
     * @param string $id
     *
     * @return FormFieldModel|null
     */
    private function findFormField(string $id): ?FormFieldModel
    {
        $fields = $this->formModel->getFields();

        while (!empty($fields)) {
            $field = array_shift($fields);

            if ($field->getId() === $id) {
                return $field;
            }

            foreach ($field->getChildren() as $child) {
                $fields[] = $child;
            }
        }

        return null;
    }

    /**
     * Whether ACPT's own Permissions let the current user write this submitted value.
     *
     * @param array<string, mixed> $datum
     *
     * @return bool
     */
    private function currentUserCanWriteField(array $datum): bool
    {
        $formField = $this->findFormField($datum['id']);

        if ($formField === null) {
            return true;
        }

        $action = $this->formModel->getAction();

        if ($action === FormAction::FILL_META) {
            if (strpos($datum['name'], '_acpt_cct_') === 0) {
                $cctColumn = $this->resolveCCTColumn($datum['name']);

                return $cctColumn === null || $cctColumn['column']->userColumnPermissions()['edit'];
            }

            $metaField = $formField->getMetaField();

            if ($datum['isMeta'] && $metaField !== null && $metaField->hasPermissions()) {
                return !empty($metaField->userPermissions()['edit']);
            }
        }

        if ($action === FormAction::FILL_TABLE) {
            $table = $this->fillTable();
            $column = ($table !== null) ? $table->getColumn($datum['name']) : null;

            return $column === null || $column->userColumnPermissions()['edit'];
        }

        return true;
    }

    /**
     * CCT tables this submission will write to, keyed by name => true when it updates an existing record.
     *
     * @return array<string, bool>
     */
    private function tablesToWrite(): array
    {
        $tables = [];
        $action = $this->formModel->getAction();

        if ($action === FormAction::FILL_TABLE) {
            $table = $this->fillTable();

            if ($table !== null) {
                $recordId = $this->fillTableRecordId();
                $tables[$table->getName()] = !empty($recordId) && TableRecordRepository::exists($table->getName(), $recordId);
            }
        }

        if ($action === FormAction::FILL_META) {
            $locationBelong = ($this->formModel->getMetaDatum('fill_meta_location_belong') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_belong')->getValue() : null;
            $locationItem = $this->postId ?? $this->termId ?? $this->userId;

            if ($locationItem === null && $this->formModel->getMetaDatum('fill_meta_location_item') !== null) {
                $locationItem = $this->formModel->getMetaDatum('fill_meta_location_item')->getValue();
            }

            $locationRule = [
                MetaTypes::CUSTOM_POST_TYPE => TableRecord::CONTEXT_POST,
                MetaTypes::TAXONOMY => TableRecord::CONTEXT_TERM,
                MetaTypes::USER => TableRecord::CONTEXT_USER,
            ][$locationBelong] ?? null;

            foreach ($this->data as $datum) {
                if (!isset($datum['id'], $datum['name']) || isset($this->deniedFieldIds[$datum['id']]) || strpos($datum['name'], '_acpt_cct_') !== 0) {
                    continue;
                }

                $cctColumn = $this->resolveCCTColumn($datum['name']);

                if ($cctColumn === null) {
                    continue;
                }

                $tableName = $cctColumn['table']->getName();
                $tables[$tableName] = $locationRule !== null && !empty($locationItem) && TableRecordRepository::getRecordIdByLocation($tableName, $locationRule, (string)$locationItem) !== null;
            }
        }

        return $tables;
    }

    /**
     * Maps a Fill-meta CCT datum name (`_acpt_cct_{table}_{column}`) to its table and column.
     *
     * @param string $name
     *
     * @return array{table: \ACPT\Core\Models\Table\TableModel, column: \ACPT\Core\Models\Table\TableColumnModel}|null
     */
    private function resolveCCTColumn(string $name): ?array
    {
        $withoutPrefix = substr($name, strlen('_acpt_cct_'));

        foreach (TableRepository::get([]) as $table) {
            if (!str_starts_with($withoutPrefix, $table->getName() . '_')) {
                continue;
            }

            $column = $table->getColumn(substr($withoutPrefix, strlen($table->getName()) + 1));

            return ($column !== null) ? ['table' => $table, 'column' => $column] : null;
        }

        return null;
    }

    /**
     * @return \ACPT\Core\Models\Table\TableModel|null
     */
    private function fillTable(): ?\ACPT\Core\Models\Table\TableModel
    {
        $tableNameDatum = $this->formModel->getMetaDatum('fill_table_name');

        if ($tableNameDatum === null) {
            return null;
        }

        $tables = TableRepository::get(['name' => $tableNameDatum->getValue()]);

        return $tables[0] ?? null;
    }

    /**
     * The record a Fill-table submission writes to: an ID field value, the form's
     * configured record, or the record id posted with the form (in this order).
     *
     * @return int|string|null
     */
    private function fillTableRecordId()
    {
        foreach ($this->data as $datum) {
            if (($datum['type'] ?? null) === FormFieldModel::ID_TYPE && !empty($datum['value'])) {
                return $datum['value'];
            }
        }

        $tableRecordId = $this->formModel->getMetaDatum('fill_table_record');

        if ($tableRecordId !== null && !empty($tableRecordId->getValue())) {
            return $tableRecordId->getValue();
        }

        return !empty($this->recordId) ? $this->recordId : null;
    }

    /**
     * Executes the form action
     *
     * @return void
     */
    private function doAction(): void
    {
        switch ($this->formModel->getAction()) {
            case FormAction::AJAX:
                // do nothing here
                break;

            case FormAction::PHP:
                $action = $this->formModel->getMetaDatum('php_action');

                if ($action !== null) {
                    PhpEval::getInstance()->evaluate($action->getValue());
                }

                break;

            case FormAction::FILL_META:
                $this->handleFillMetaAction();
                break;

            case FormAction::FILL_TABLE:
                $this->handleFillTableAction();
                break;
        }
    }

    /**
     * Handle fill meta action
     *
     * @return void
     */
    private function handleFillMetaAction(): void
    {
        $locationFind = ($this->formModel->getMetaDatum('fill_meta_location_find') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_find')->getValue() : null;
        $locationBelong = ($this->formModel->getMetaDatum('fill_meta_location_belong') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_belong')->getValue() : null;
        $locationItem = ($this->formModel->getMetaDatum('fill_meta_location_item') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_item')->getValue() : null;
        $locationStatus = ($this->formModel->getMetaDatum('fill_meta_location_status') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_status')->getValue() : null;

        if ($this->postId !== null) {
            $locationItem = (int)$this->postId;
        } elseif ($this->termId !== null) {
            $locationItem = (int)$this->termId;
        } elseif ($this->userId !== null) {
            $locationItem = (int)$this->userId;
        }

        // update is not always allowed
        if ($locationItem > 0) {
            if ($locationBelong === MetaTypes::CUSTOM_POST_TYPE) {
                if (!get_post((int)$locationItem) instanceof \WP_Post) {
                    $this->addError($this->formModel->getId(), 'Page object is empty');

                    return;
                }

                $postType = get_post_type((int)$locationItem);

                if ($postType === false) {
                    return;
                }

                if ($locationFind !== $postType) {
                    $this->addError($this->formModel->getId(), 'This page does not belongs to ' . $locationFind);

                    return;
                }

                if (!current_user_can('edit_post', $locationItem)) {
                    $this->addError($this->formModel->getId(), 'You do not have permission to edit this page');

                    return;
                }
            }

            if ($locationBelong === MetaTypes::TAXONOMY) {
                if (!get_term((int)$locationItem) instanceof \WP_Term) {
                    $this->addError($this->formModel->getId(), 'Term object is empty');

                    return;
                }

                if (!current_user_can('edit_term', $locationItem)) {
                    $this->addError($this->formModel->getId(), 'You do not have permission to edit this term');

                    return;
                }
            }

            if ($locationBelong === MetaTypes::USER) {
                if (!get_userdata((int)$locationItem)) {
                    $this->addError($this->formModel->getId(), 'User object is empty');

                    return;
                }

                if (!current_user_can('edit_user', $locationItem)) {
                    $this->addError($this->formModel->getId(), 'You do not have permission to edit this user');

                    return;
                }
            }
        }

        $postThumbnailId     = null;
        $postDataArray       = [];
        $termDataArray       = [];
        $userDataArray       = [];

        if ($locationBelong === MetaTypes::CUSTOM_POST_TYPE) {
            $locationItem = ($locationItem !== null && $locationItem !== '') ? (int)$locationItem : (get_post() !== null ? (int)get_post()->ID : 0);
            $postDataArray['ID'] = $locationItem;
        }

        if ($locationBelong === MetaTypes::TAXONOMY) {
            $locationItem = ($locationItem !== null && $locationItem !== '') ? (int)$locationItem : ((get_queried_object() instanceof \WP_Term) ? get_queried_object()->term_id : 0);
            $termDataArray['ID'] = $locationItem;
        }

        if ($locationBelong === MetaTypes::USER) {
            $locationItem = ($locationItem !== null && $locationItem !== '') ? (int)$locationItem : wp_get_current_user()->ID;
            $userDataArray['ID'] = $locationItem;
        }

        foreach ($this->writableData() as $datum) {
            if ($datum['isPost']) {
                $this->addPostData($postDataArray, $datum);

                // thumbnail ID
                if ($datum['type'] === FormFieldModel::WORDPRESS_POST_THUMBNAIL && isset($datum['extra']['attachment_id'])) {
                    $postThumbnailId = $datum['extra']['attachment_id'];
                }
            }

            if ($datum['isTerm']) {
                $termDataArray = array_merge($termDataArray, $this->addTermData($datum));
            }

            if ($datum['isUser']) {
                $userDataArray = array_merge($userDataArray, $this->addUserData($datum));
            }
        }

        // save posts
        if (!empty($postDataArray) && $locationItem !== null && $locationFind !== null) {
            $postDataArray['post_type'] = $locationFind;

            if (!empty($locationStatus)) {
                $postDataArray['post_status'] = $locationStatus;
            }

            $locationItem = $this->savePost($postDataArray);

            if ($locationItem == 0) {
                $this->addError($this->formModel->getId(), "There was an error during the saving of " . $locationFind . " post");
            } else {
                // Hydrate postId so get_permalink() works correctly in sendMail()
                $this->postId = $locationItem;
            }

            // save thumbnail
            if ($postThumbnailId !== null && $locationItem != 0) {
                set_post_thumbnail((int)$locationItem, (int)$postThumbnailId);
            }
        }

        // save terms
        if (!empty($termDataArray) && $locationItem !== null && $locationFind !== null) {
            if (isset($termDataArray['name'])) {
                $locationItem = $this->saveTerm($locationFind, $termDataArray);

                if ($locationItem == 0 || $locationItem instanceof \WP_Error) {
                    $this->addError($this->formModel->getId(), "There was an error during the saving of " . $locationFind . " term");
                }
            }
        }

        // save users
        if (!empty($userDataArray) && $locationItem !== null) {
            $locationItem = $this->saveUser($userDataArray);

            if ($locationItem == 0 || $locationItem instanceof \WP_Error) {
                $this->addError($this->formModel->getId(), "There was an error during the saving of the user");
            }
        }

        foreach ($this->writableData() as $datum) {
            if ($datum['isMeta']) {
                if (strpos($datum['name'], '_acpt_cct_') === 0) {
                    continue;
                }
                $this->saveMetaDatum($datum, $locationFind, $locationBelong, $locationItem);
            }
        }

        $this->saveCCTColumnsForMeta($locationItem, $locationBelong);
        ACPT_DB::flushCache();
    }

    /**
     * Composes the legacy meta shape (value + extra) into the canonical CCT JSON
     * shape for compound field types (Currency, Weight, Length, Address, Country, Url)
     * via {@see CCTFieldShape::coerce()}, mirroring TableRecordController::sanitize().
     *
     * Form submissions carry the unit/currency/country/coordinates in $datum['extra']
     * separately from $datum['value'] — this reassembles them into the single JSON
     * object the CCT column expects. Non-compound types are returned unchanged.
     *
     * @param array<string, mixed> $datum
     * @param string $uiType
     * @return mixed
     */
    private function composeCompoundFieldValue(array $datum, string $uiType)
    {
        $value = $datum['value'];
        $extra = $datum['extra'] ?? [];

        switch ($uiType) {
            case MetaFieldModel::CURRENCY_TYPE:
                $legacy = ['amount' => $value, 'unit' => $extra['currency'] ?? null];
                break;

            case MetaFieldModel::WEIGHT_TYPE:
                $legacy = ['weight' => $value, 'unit' => $extra['weight'] ?? null];
                break;

            case MetaFieldModel::LENGTH_TYPE:
                $legacy = ['length' => $value, 'unit' => $extra['length'] ?? null];
                break;

            case MetaFieldModel::ADDRESS_TYPE:
                $legacy = [
                    'address' => $value,
                    'lat' => $extra['lat'] ?? null,
                    'lng' => $extra['lng'] ?? null,
                    'city' => $extra['city'] ?? null,
                    'country' => $extra['country'] ?? null,
                ];
                break;

            case MetaFieldModel::COUNTRY_TYPE:
                $legacy = ['value' => $value, 'country' => $extra['country'] ?? null];
                break;

            case MetaFieldModel::URL_TYPE:
                $legacy = $value;
                break;

            default:
                return $value;
        }

        $coerced = CCTFieldShape::coerce($legacy, $uiType);

        return $coerced ?? $value;
    }

    /**
     * Handle fill table action — inserts or updates a CCT table record from submitted form data.
     *
     * @throws \Exception
     */
    private function handleFillTableAction(): void
    {
        $tableNameDatum = $this->formModel->getMetaDatum('fill_table_name');
        $tableRecordId  = $this->formModel->getMetaDatum('fill_table_record');

        if ($tableNameDatum === null) {
            $this->addError($this->formModel->getId(), 'No table name configured for FILL_TABLE action');
            return;
        }

        $tableName = $tableNameDatum->getValue();
        $tables = TableRepository::get(['name' => $tableName]);

        if (empty($tables)) {
            $this->addError($this->formModel->getId(), 'Table "' . $tableName . '" not found');
            return;
        }

        /** @var \ACPT\Core\Models\Table\TableModel $table */
        $table = $tables[0];

        $selectedColumnsDatum = $this->formModel->getMetaDatum('fill_table_fields');
        $selectedColumns = ($selectedColumnsDatum !== null) ? (array)$selectedColumnsDatum->getFormattedValue() : [];
        $selectedColumns = array_filter($selectedColumns, 'is_string');

        $recordId = null;

        foreach ($this->data as $datum) {
            if ($datum['type'] === FormFieldModel::ID_TYPE && !empty($datum['value'])) {
                $recordId = $datum['value'];
                break;
            }
        }

        $fields = [];

        foreach ($this->writableData() as $datum) {
            if ($datum['type'] === FormFieldModel::ID_TYPE) {
                continue;
            }

            $colName = $datum['name'];

            if (!$table->hasColumn($colName)) {
                continue;
            }

            if (!empty($selectedColumns) && !in_array($colName, $selectedColumns, true)) {
                continue;
            }

            $column = $table->getColumn($colName);
            $uiType = ($column !== null) ? $column->getUiField()->type : $datum['type'];

            $fields[$colName] = $this->composeCompoundFieldValue($datum, $uiType);
        }

        if (!empty($recordId)) {
            $fields['id'] = $recordId;
        }

        if (empty($fields)) {
            return;
        }

        try {
            if (!isset($fields['id']) && $tableRecordId && !empty($tableRecordId->getValue())) {
                $fields['id'] = $tableRecordId->getValue();
            }

            if (!isset($fields['id']) && !empty($this->recordId)) {
                $fields['id'] = $this->recordId;
            }

            $sql = $table->upsertQuery($fields);
            ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);
            ACPT_DB::flushCache();
        } catch (\Exception $e) {
            $this->addError($this->formModel->getId(), 'Error saving table record: ' . $e->getMessage());
        }
    }

    /**
     * Save CCT column values collected during a FILL_META submission.
     *
     * Scans `$this->data` for datums whose name starts with `_acpt_cct_`.
     * Groups them by table name (parsed from the prefix) and upserts each
     * table's columns as a single CCT record linked to the current post/term/user.
     *
     * @param int|string|null $locationItem  Post/term/user ID (already resolved).
     * @param string|null     $locationBelong MetaTypes constant.
     */
    private function saveCCTColumnsForMeta($locationItem = null, ?string $locationBelong = null): void
    {
        /** @var array<string, array<string, mixed>> $byTable */
        $byTable = [];
        $tables = TableRepository::get([]);

        foreach ($this->writableData() as $datum) {
            $name = $datum['name'];

            if (!str_starts_with($name, '_acpt_cct_')) {
                continue;
            }

            $withoutPrefix = substr($name, strlen('_acpt_cct_'));

            foreach ($tables as $table) {
                $tableName = $table->getName();

                if (!str_starts_with($withoutPrefix, $tableName . '_')) {
                    continue;
                }

                $columnName = substr($withoutPrefix, strlen($tableName) + 1);

                if ($table->hasColumn($columnName)) {
                    $column = $table->getColumn($columnName);
                    $uiType = ($column !== null) ? $column->getUiField()->type : $datum['type'];
                    $byTable[$tableName][$columnName] = $this->composeCompoundFieldValue($datum, $uiType);
                }

                break;
            }
        }

        foreach ($byTable as $tableName => $fields) {
            $this->saveCCTColumns($tableName, $fields, $locationItem, $locationBelong);
        }
    }

    /**
     * Upsert a CCT table record and sync its location to the current post/term/user.
     *
     * @param string          $tableName
     * @param array<string, mixed> $fields  Column name → value map.
     * @param int|string|null $locationItem Post/term/user ID.
     * @param string|null     $locationBelong MetaTypes constant.
     */
    private function saveCCTColumns(string $tableName, array $fields, $locationItem, ?string $locationBelong): void
    {
        $table = TableRepository::getByName($tableName);

        if (empty($table)) {
            return;
        }

        $locationRule = null;
        $locationValue = null;

        if ($locationBelong === MetaTypes::CUSTOM_POST_TYPE && !empty($locationItem)) {
            $locationRule = TableRecord::CONTEXT_POST;
            $locationValue = (string)$locationItem;
        } elseif ($locationBelong === MetaTypes::TAXONOMY && !empty($locationItem)) {
            $locationRule = TableRecord::CONTEXT_TERM;
            $locationValue = (string)$locationItem;
        } elseif ($locationBelong === MetaTypes::USER && !empty($locationItem)) {
            $locationRule = TableRecord::CONTEXT_USER;
            $locationValue = (string)$locationItem;
        }

        $existingRecordId = null;

        if ($locationRule !== null) {
            $existingRecordId = TableRecordRepository::getRecordIdByLocation($tableName, $locationRule, $locationValue);
        }

        if ($existingRecordId !== null) {
            $fields['id'] = $existingRecordId;
        }

        try {
            $sql = $table->upsertQuery($fields);
            ACPT_DB::executeQueryOrThrowException($sql['sql'], $sql['values']);

            if ($existingRecordId === null && $locationRule !== null) {
                $newId = ACPT_DB::getTheLastInsertedId();
                TableRecordRepository::syncLocations($tableName, $newId, [
                    ['location_rule' => $locationRule, 'location_value' => $locationValue]
                ]);
            }
        } catch (\Exception $e) {
            $this->addError($this->formModel->getId(), 'Error saving CCT table record: ' . $e->getMessage());
        }
    }

    /**
     * @param array<string, mixed> &$postDataArray
     * @param array<string, mixed>  $datum
     */
    private function addPostData(array &$postDataArray, array $datum = []): void
    {
        if (!empty($datum['value'])) {
            switch ($datum['type']) {
                case FormFieldModel::WORDPRESS_POST_TITLE:
                    $postDataArray['post_title'] = $datum['value'];
                    break;

                case FormFieldModel::WORDPRESS_POST_CONTENT:
                    $postDataArray['post_content'] = $datum['value'];
                    break;

                case FormFieldModel::WORDPRESS_POST_EXCERPT:
                    $postDataArray['post_excerpt'] = $datum['value'];
                    break;

                case FormFieldModel::WORDPRESS_POST_AUTHOR:
                    $postDataArray['post_author'] = $datum['value'];
                    break;

                case FormFieldModel::WORDPRESS_POST_DATE:
                    $postDataArray['post_date'] = $datum['value'];
                    break;

                case FormFieldModel::WORDPRESS_POST_TAXONOMIES:

                    // handle saving single or multiple terms
                    if (is_array($datum['value'])) {
                        $taxInputValue = [];

                        foreach ($datum['value'] as $item) {
                            $value = explode(TaxonomyField::SEPARATOR, $item);

                            if (Arrays::count($value) === 2) {
                                $taxonomy = (string)$value[0];
                                $termId = (int)$value[1];

                                if (!isset($taxInputValue[$taxonomy])) {
                                    $taxInputValue[$taxonomy] = [];
                                }

                                $postDataArray['tax_input'][$taxonomy][] = $termId;
                            }
                        }
                    } else {
                        $value = explode(TaxonomyField::SEPARATOR, $datum['value']);

                        if (Arrays::count($value) === 2) {
                            $taxonomy = (string)$value[0];
                            $termId = (int)$value[1];

                            $postDataArray['tax_input'][$taxonomy][] = $termId;
                        }
                    }

                    break;
            }
        } else {

            // reset all taxonomies
            if ($datum['type'] === FormFieldModel::WORDPRESS_POST_TAXONOMIES) {
                $data = [];
                $postType = get_post_type($this->postId);

                if ($postType === false) {
                    return;
                }

                $taxonomies = get_object_taxonomies($postType);

                foreach ($taxonomies as $taxonomy) {
                    $postDataArray['tax_input'][$taxonomy] = [];
                }
            }
        }
    }

    /**
     * @param array<string, mixed> $datum
     * @return array<string, mixed>
     */
    private function addTermData(array $datum = []): array
    {
        if (!empty($datum['value'])) {
            switch ($datum['type']) {
                case FormFieldModel::WORDPRESS_TERM_NAME:
                    return [
                        'name' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_TERM_DESCRIPTION:
                    return [
                        'description' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_TERM_SLUG:
                    return [
                        'slug' => $datum['value'],
                    ];
            }
        }

        return [];
    }

    /**
     * @param array<string, mixed> $datum
     * @return array<string, mixed>
     */
    private function addUserData(array $datum = []): array
    {
        if (!empty($datum['value'])) {
            switch ($datum['type']) {
                case FormFieldModel::WORDPRESS_USER_EMAIL:
                    return [
                        'user_email' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_USER_PASSWORD:
                    return [
                        'user_pass' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_USER_USERNAME:
                    return [
                        'user_login' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_USER_FIRST_NAME:
                    return [
                        'first_name' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_USER_LAST_NAME:
                    return [
                        'last_name' => $datum['value'],
                    ];

                case FormFieldModel::WORDPRESS_USER_BIO:
                    return [
                        'description' => $datum['value'],
                    ];
            }
        }

        return [];
    }

    /**
     * @param array<string, mixed> $data
     * @return int
     */
    private function savePost(array $data = []): int
    {
        if ($data['ID'] > 0) {
            $update = wp_update_post($data);

            if ($update > 0) {
                return $update;
            }

            return 0;
        }

        // if no title is provided, create one
        if (!isset($data['post_title'])) {
            $data['post_title'] = 'No title';
        }

        $insert = wp_insert_post($data);

        if ($insert > 0) {
            return $insert;
        }

        return 0;
    }

    /**
     * @param array<string, mixed> $data
     * @return int|\WP_Error
     */
    private function saveUser(array $data = [])
    {
        if ($data['ID'] > 0) {
            return wp_update_user($data);
        }

        if (!isset($data['user_login'])) {
            if (isset($data['first_name'])) {
                $data['user_login'] = Strings::generateUsername($data['first_name']);
            } else {
                $data['user_login'] = Strings::randomString();
            }
        }

        return wp_insert_user($data);
    }

    /**
     * @param string               $taxonomy
     * @param array<string, mixed> $data
     * @return mixed
     */
    private function saveTerm(string $taxonomy, array $data = [])
    {
        $array = [];

        if (isset($data['description'])) {
            $array['description'] = $data['description'];
        }

        if (isset($data['slug'])) {
            $array['slug'] = $data['slug'];
        }

        if ($data['ID'] > 0) {
            if (isset($data['name'])) {
                $array['name'] = $data['name'];
            }

            $term = wp_update_term($data['ID'], $taxonomy, $array);

            if (is_wp_error($term)) {
                throw new \Exception($term->get_error_message());
            }

            return $term['term_id'];
        }

        $term = wp_insert_term(
            $data['name'],
            $taxonomy,
            $array
        );

        if (is_wp_error($term)) {
            throw new \Exception($term->get_error_message());
        }

        return $term['term_id'];
    }

    /**
     * @param array<string, mixed> $datum
     * @param string|null            $locationFind
     * @param string|null            $locationBelong
     * @param mixed                  $locationItem
     */
    private function saveMetaDatum(array $datum = [], ?string $locationFind = null, ?string $locationBelong = null, $locationItem = null): void
    {
        $rawValue = $datum['value'] ?? null;
        $allowHtml = $datum['allowHtml'] ?? false;
        $allowDangerousContent = $datum['allowDangerousContent'] ?? false;
        $elementId = ($locationBelong === MetaTypes::OPTION_PAGE) ? $datum['name'] : $locationItem;

        // check if the value is different than the saved one
        $savedValue = Meta::fetch($elementId, $locationBelong, $datum['name']);
        $newValue = Sanitizer::sanitizeRawData($datum['type'], $rawValue, [
            'allow_dangerous_content' => $allowDangerousContent,
            'allow_html' => $allowHtml
        ]);

        // Repeater
        if ($datum['type'] === MetaFieldModel::REPEATER_TYPE) {
            foreach ($newValue as $key => $value) {
                $newValue[$key] = Arrays::reindex($value);
            }
        }

        // Password
        if ($datum['type'] === MetaFieldModel::PASSWORD_TYPE && isset($datum['extra']['id'])) {
            $fieldId = $datum['extra']['id'];

            try {
                $fieldModel = MetaRepository::getMetaFieldById($fieldId);
                $algo = $fieldModel->getAdvancedOption("algorithm") ?? PASSWORD_DEFAULT;
                $newValue = Strings::hashPassword((string)$newValue, $algo);
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
            }
        }

        // Relational
        if ($datum['type'] === MetaFieldModel::POST_TYPE && isset($datum['extra']['id'])) {
            $fieldId = $datum['extra']['id'];

            try {
                $fieldModel = MetaRepository::getMetaFieldById($fieldId);
                $command = new HandleRelationsCommand($fieldModel, $rawValue, $elementId, $locationBelong);
                $command->execute();
            } catch (\Exception $exception) {
                do_action("acpt/error", $exception);
            }

            return;
        }

        // is a button or another field to ignore
        if (empty($savedValue) && empty($newValue) && empty($rawValue)) {
            return;
        }

        // save the new value only if is different from saved value
        if ($savedValue !== $newValue) {
            if (
                Meta::save(
                    $elementId,
                    $locationBelong,
                    $datum['name'],
                    $newValue
                ) === false
            ) {
                $this->addError($datum['id'], "Error saving field " . $datum['name']);
            }
        }

        foreach ($datum['extra'] as $key => $value) {
            Meta::save(
                $elementId,
                $locationBelong,
                $datum['name'].'_'.$key,
                Sanitizer::sanitizeRawData(MetaFieldModel::TEXT_TYPE, $value)
            );
        }
    }

    /**
     * Save form submission
     */
    /** @return void */
    private function saveFormSubmission(): void
    {
        $currentUser = wp_get_current_user();

        try {
            $formSubmission = FormSubmissionModel::hydrateFromArray([
                'formId' => $this->formModel->getId(),
                'action' => $this->formModel->getAction(),
                'callback' => $this->saveFormSubmissionCallback(),
                'uid' => ($currentUser->ID > 0 ? $currentUser->ID : null),
                'createdAt' => new \DateTime(),
            ]);

            foreach ($this->data as $datum) {
                if (
                    isset($datum['name']) &&
                    isset($datum['type']) &&
                    isset($datum['value'])
                ) {
                    $datumObject = new FormSubmissionDatumObject($datum['name'], $datum['type'], $datum['value']);
                    $formSubmission->addDatum($datumObject);
                }
            }

            if (!empty($this->errors)) {
                foreach ($this->errors as $err) {
                    if (isset($err['id'], $err['message'])) {
                        $formSubmission->addError(
                            new FormSubmissionErrorObject($err['id'], $err['message'])
                        );
                    }
                }
            }

            FormRepository::saveSubmission($formSubmission);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);
            $this->addError($this->formModel->getId(), "Save form submission error: " . $exception->getMessage());
        }
    }

    /**
     * @return string|null
     */
    private function saveFormSubmissionCallback(): ?string
    {
        switch ($this->formModel->getAction()) {
            case FormAction::AJAX:
                if ($this->formModel->getMetaDatum('ajax_action') === null) {
                    return null;
                }

                return $this->formModel->getMetaDatum('ajax_action')->getValue();

            case FormAction::CUSTOM:
                if ($this->formModel->getMetaDatum('custom_action') === null) {
                    return null;
                }

                return $this->formModel->getMetaDatum('custom_action')->getValue();

            case FormAction::PHP:
                if ($this->formModel->getMetaDatum('php_action') === null) {
                    return null;
                }

                return $this->formModel->getMetaDatum('php_action')->getValue();

            case FormAction::FILL_TABLE:

                $tableNameMeta = $this->formModel->getMetaDatum('fill_table_name');
                $tableName = ($tableNameMeta !== null) ? $tableNameMeta->getValue() : 'unknown';

                if (!empty($this->recordId)) {
                    return 'Updating CCT table record with ID#'.$this->recordId . ' for table ' . $tableName;
                }

                return 'Creating CCT table record for table ' . $tableName;

            case FormAction::FILL_META:

                if (!empty($this->postId)) {
                    return 'Updating Post with ID#'.$this->postId;
                }

                if (!empty($this->termId)) {
                    return 'Updating Term with ID#'.$this->termId;
                }

                if (!empty($this->userId)) {
                    return 'Updating User with ID#'.$this->userId;
                }

                $locationFind = ($this->formModel->getMetaDatum('fill_meta_location_find') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_find')->getValue() : null; // ---> holiday
                $locationBelong = ($this->formModel->getMetaDatum('fill_meta_location_belong') !== null) ? $this->formModel->getMetaDatum('fill_meta_location_belong')->getValue() : null; // ---> customPostType

                if ($locationBelong === MetaTypes::CUSTOM_POST_TYPE) {
                    return 'Creating new '.$locationFind.' post';
                }

                if ($locationBelong === MetaTypes::TAXONOMY) {
                    return 'Creating new '.$locationFind.' term';
                }

                if ($locationBelong === MetaTypes::USER) {
                    return 'Creating new User';
                }

                return '';
        }

        return '';
    }

    /**
     * Sends an email based on the email settings provided in the form model's metadata.
     * This method retrieves email settings such as sender, recipient(s), subject, body, and other optional parameters,
     * processes the content using templates and attributes, and dispatches the email.
     * If specified, it also sends a confirmation email to the currently logged-in user.
     *
     * @return void
     */
    private function sendMail(): void
    {
        try {
            $emailSettings = $this->formModel->getMetaDatum('email_settings');
            $emailSettingsValues = $emailSettings !== null ? $emailSettings->getFormattedValue() : null;

            if (empty($emailSettingsValues)) {
                return;
            }

            $defaultHeader = "<div style='text-align: center'>{{site_logo}}</div>";
            $defaultFooter = "<div class='muted'>&copy; {{current_year}} <a href={{site_url}}>{{site_name}}</a>. All rights reserved.</div>";

            $from = $emailSettingsValues['from'] ?? null;
            $to = $emailSettingsValues['to'] ?? [];
            $cc = isset($emailSettingsValues['cc']) && is_array($emailSettingsValues['cc']) ? $emailSettingsValues['cc'] : [];
            $bcc = isset($emailSettingsValues['bcc']) && is_array($emailSettingsValues['bcc']) ? $emailSettingsValues['bcc'] : [];
            $replyTo = $emailSettingsValues['reply_to'] ?? null;
            $subject = $emailSettingsValues['subject'] ?? null;
            $body = $emailSettingsValues['body'] ?? "";
            $header = $emailSettingsValues['header'] ?? $defaultHeader;
            $footer = $emailSettingsValues['footer'] ?? $defaultFooter;
            $attachments = $emailSettingsValues['attachments'] ?? [];
            $template = EmailTemplateFactory::create($emailSettingsValues['template'] ?? null);

            if (empty($from)) {
                return;
            }

            if (empty($to)) {
                return;
            }

            if (empty($subject)) {
                return;
            }

            $attributes = [];

            foreach ($this->data as $value) {
                $attributes[$value['key']] = $value['value'];
            }

            // Inject the post URL so it can be referenced as {{post_url}} in email templates
            $attributes['post_url'] = $this->permalink();

            $header = Strings::convertNewlinesToBr($header);
            $footer = Strings::convertNewlinesToBr($footer);

            $body = Twig::render($body, $attributes);
            $header = Twig::render($header, $attributes);
            $footer = Twig::render($footer, $attributes);

            $attachmentPaths = [];

            foreach ($attachments as $attachment) {
                $object = array_filter($this->data, function ($value) use ($attachment) {
                    return $value['key'] === $attachment;
                });

                if (!empty($object)) {
                    $object = Arrays::reindex($object);
                    $attachmentIds = explode(",", $object[0]['extra']['attachment_id']);

                    // @phpstan-ignore-next-line greater.alwaysTrue
                    if (count($attachmentIds) > 0) {
                        foreach ($attachmentIds as $attachmentId) {
                            $attachment = WPAttachment::fromId((int)$attachmentId);

                            if (!$attachment->isEmpty()) {
                                $attachmentPaths[] = $attachment->getPath();
                            }
                        }
                    }
                }
            }

            $emailSent = $this->dispatchEnvelope($to, $from, $subject, $body, $header, $footer, $template, $attachmentPaths, $cc, $bcc, $replyTo);

            if (!$emailSent) {
                $this->addError($this->formModel->getId(), "Sending email to ".implode($to)." failed");
            }

            // Send same email to the logged-in user who submitted the form (Form Submission Confirmation Email)
            $sendToLoggedUser = $this->formModel->getMetaDatum('send_to_logged_user');
            if ($sendToLoggedUser !== null && (bool)$sendToLoggedUser->getValue()) {
                $currentUser = wp_get_current_user();
                if ($currentUser->ID > 0 && !empty($currentUser->user_email)) {
                    $this->dispatchEnvelope($currentUser->user_email, $from, $subject, $body, $header, $footer, $template);
                }
            }
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);
            $this->addError($this->formModel->getId(), "Error sending email: " . $exception->getMessage());
        }
    }

    /**
     * Generates a permalink for the specified post ID.
     *
     * @return string The HTML anchor element containing the permalink, or an empty string if the post ID is not set.
     */
    private function permalink(): string
    {
        if (empty($this->postId)) {
            return '';
        }

        $permalink = get_permalink($this->postId);

        if (empty($permalink)) {
            return '';
        }

        return $permalink;
    }

    /**
     * Builds and sends an Envelope with the given parameters.
     *
     * @param mixed                $to
     * @param string               $from
     * @param string               $subject
     * @param string               $body
     * @param string               $header
     * @param string               $footer
     * @param mixed                $template
     * @param array<int, string>   $attachmentPaths
     * @param array<int, string>   $cc
     * @param array<int, string>   $bcc
     * @param string|null          $replyTo
     * @return bool
     */
    private function dispatchEnvelope(
        $to,
        string $from,
        string $subject,
        string $body,
        string $header,
        string $footer,
        $template,
        array $attachmentPaths = [],
        array $cc = [],
        array $bcc = [],
        ?string $replyTo = null
    ): bool {
        $emailBody = new EnvelopeBody();
        $emailBody->body = $body;
        $emailBody->header = $header;
        $emailBody->footer = $footer;

        $email = new Envelope($from, $to, $subject, $emailBody);
        $email->setAttachments($attachmentPaths);
        $email->setCc($cc);
        $email->setBcc($bcc);
        $email->setReplyTo($replyTo);
        $email->setTemplate($template);

        return $email->send();
    }

    /**
     * @inheritDoc
     */
    public function logFormat(): array
    {
        $data = [];

        foreach ($this->data as $datum) {
            $data[$datum['name']] = $datum['value'];
        }

        return [
            "class"  => HandleFormSubmissionCommand::class,
            "data"   => $data,
            "errors" => $this->errors,
            "postId" => $this->postId,
            "userId" => $this->userId,
            "termId" => $this->termId,
        ];
    }
}
