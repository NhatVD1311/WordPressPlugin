<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Admin\ACPT_License_Manager;
use ACPT\Core\Helper\Features;
use ACPT\Utils\Http\ACPTApiClient;
use ACPT\Utils\PHP\IP;

class FetchLicenseQuery implements QueryInterface
{
    /**
     * @return array<string, mixed>
     * @throws \Exception
     */
    public function execute(): array
    {
        $currentVersion = ACPT_PLUGIN_VERSION;
        $licenseActivation = ACPT_License_Manager::getLicense();
        $activation = ACPTApiClient::call('/license/activation/fetch', [
            'id' => $licenseActivation['activation_id'],
            'enable_beta' => Features::enableBeta(),
        ]);

        if (empty($activation)) {
            throw new \Exception("No response from the server");
        }

        if (isset($activation['error'])) {
            throw new \Exception($activation['error']);
        }

        unset($licenseActivation['license']);

        $versionInfo = [
            'currentVersion' => $currentVersion,
            'licenseActivation' => $licenseActivation,
            'activationLink' => $this->getActivationLink(),
        ];

        return array_merge($activation, $versionInfo);
    }

    /**
     * @return string
     */
    private function getActivationLink(): string
    {
        $referer = json_encode([
            'site' => site_url(),
            'siteName' => get_bloginfo('name'),
            'ip' => IP::getClientIP(),
        ]);

        return "https://acpt.io/activation?referer=". base64_encode($referer !== false ? $referer : 'no referer');
    }
}
