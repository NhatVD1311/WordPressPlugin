<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Core\Repository\TableRecordRepository;

class FetchTableStatsQuery implements QueryInterface
{
    private string $table;

    public function __construct(string $table)
    {
        $this->table = $table;
    }
    public function execute()
    {
        $stats = TableRecordRepository::getStats($this->table);

        if (empty($stats)) {
            return [];
        }

        $ranked = $this->rankColumns($stats['columns']);
        $top = array_slice($ranked, 0, 5, true);

        return [
            'base' => $stats['base'],
            'columns' => $top,
        ];
    }

    /**
     * Ranks columns based on a computed score derived from their filled ratio, variance score,
     * and type score, then returns the ranked list of columns.
     *
     * @param array<string, mixed> $columnsStats
     * @return array<string, mixed>
     */
    private function rankColumns(array $columnsStats): array
    {
        $weights = [
            'filled' => 0.4,
            'variance' => 0.4,
            'type' => 0.2,
        ];

        $typeScoreMap = [
            'categorical' => 1.0,
            'numeric' => 0.9,
            'date' => 0.8,
            'text' => 0.5,
            'basic' => 0.3,
        ];

        foreach ($columnsStats as $name => &$col) {
            if (in_array($name, ['id', 'created_at', 'updated_at', 'deleted_at'])) {
                continue;
            }

            $total = $col['total'] ?? 0;
            $nulls = $col['nulls'] ?? 0;

            // 1. Filled
            $filledRatio = $total > 0 ? 1 - ($nulls / $total) : 0;

            // 2. Variance
            $varianceScore = $this->computeVarianceScore($col);

            if (isset($col['unique_count']) && $col['unique_count'] === 2) {
                $varianceScore += 0.2;
            }

            $total = $col['total'] ?? 0;
            $unique = $col['unique_count'] ?? 0;
            $uniqueRatio = $total > 0 ? $unique / $total : 0;

            if ($uniqueRatio > 0.95) {
                $varianceScore *= 0.2;
            }

            // 3. Type
            $typeScore = $typeScoreMap[$col['type']] ?? 0.2;

            // Final score
            $col['score'] =
                ($weights['filled'] * $filledRatio) +
                ($weights['variance'] * $varianceScore) +
                ($weights['type'] * $typeScore);
        }

        uasort($columnsStats, fn ($a, $b) => $b['score'] <=> $a['score']);

        return $columnsStats;
    }

    /**
     * Computes the variance score for a column based on its type and specific characteristics.
     *
     * @param array<string, mixed> $col
     * @return float
     */
    private function computeVarianceScore(array $col): float
    {
        switch ($col['type']) {

            case 'categorical':
                $total = $col['total'] ?? 0;
                $unique = $col['unique_count'] ?? 0;

                if ($total == 0) {
                    return 0;
                }

                $ratio = $unique / $total;

                // sweet spot centrale
                return 1 - abs($ratio - 0.5) * 2;

            case 'numeric':
                return ($col['max'] ?? 0) != ($col['min'] ?? 0) ? 1 : 0;

            case 'date':
                return ($col['max'] ?? null) !== ($col['min'] ?? null) ? 1 : 0;

            case 'text':
                return min(1, ($col['avg_length'] ?? 0) / 100);

            default:
                return 0.2;
        }
    }
}
