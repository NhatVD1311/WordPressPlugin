<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Constants\MetaTypes;
use ACPT\Core\CQRS\Command\AbstractMetaFieldValueCommand;
use ACPT\Core\Generators\Meta\TableFieldGenerator;
use ACPT\Core\Helper\CCTFieldShape;
use ACPT\Core\Helper\Strings;
use ACPT\Core\Models\Meta\MetaFieldModel;
use ACPT\Core\Models\OptionPage\OptionPageModel;
use ACPT\Core\Repository\OptionPageRepository;
use ACPT\Core\Repository\TableRepository;
use ACPT\Utils\Data\TableRecord;
use ACPT\Utils\PHP\Address;
use ACPT\Utils\PHP\Arrays;
use ACPT\Utils\PHP\Date;
use ACPT\Utils\PHP\DateNormalizer;
use ACPT\Utils\PHP\Maths;
use ACPT\Utils\PHP\Numbers;
use ACPT\Utils\Wordpress\WPAttachment;
use ACPT\Utils\Wordpress\WPUtils;

class FetchMetaFieldValueQuery extends AbstractMetaFieldValueCommand implements QueryInterface
{
    /**
     * @return mixed
     * @throws \Exception
     */
    public function execute()
    {
        // Prevent any error if one of those functions is undefined:
        if (!function_exists('get_user_by')) {
            include_once(ABSPATH . 'wp-includes/pluggable.php');
        }

        if (!function_exists('get_term')) {
            include_once(ABSPATH . 'wp-includes/taxonomy.php');
        }

        if ($this->fieldModel->getBox()->getGroup()->isCCTCopy()) {
            return $this->executeCCT();
        }

        $saved_field_type = $this->getData('_type') ?? $this->fieldModel->getType();
        $saved_field_value = $this->getData();

        if ($saved_field_value === null || $saved_field_value === '') {
            return null;
        }

        $before = null;
        $after  = null;

        $advanced_options = $this->fieldModel->getAdvancedOptions();

        // @phpstan-ignore-next-line function.alreadyNarrowedType
        if (is_array($advanced_options)) {
            foreach ($advanced_options as $advanced_option) {
                if ($advanced_option->getKey() === 'after') {
                    $after = $advanced_option->getValue();
                }

                if ($advanced_option->getKey() === 'before') {
                    $before = $advanced_option->getValue();
                }
            }
        }

        if ($this->return === "string") {
            return $before . Strings::intoString($saved_field_value) . $after;
        }

        switch ($saved_field_type) {

            // TABLE_TYPE
            case MetaFieldModel::TABLE_TYPE:

                switch ($this->return) {

                    // default return type
                    default:
                    case 'raw':
                        return $this->formatRawValue($saved_field_value, $after, $before);

                        // return the table HTML
                    case 'string':
                        $sortable = $this->fieldModel->getAdvancedOption("sortable") == 1;
                        $pagination = $this->fieldModel->getAdvancedOption("pagination");
                        $generator = new TableFieldGenerator($saved_field_value, $sortable, $pagination);
                        $value = $generator->generate();

                        return $before . $value . $after;

                        // return the table data
                    case 'object':
                        $data = is_string($saved_field_value) ? json_decode($saved_field_value, true) : $saved_field_value;

                        if (!is_array($data)) {
                            return null;
                        }

                        if (!isset($data['data'])) {
                            return null;
                        }

                        $data = Maths::getInstance($data['data']);

                        return $data->getData();
                }

                // ADDRESS_TYPE
                // no break
            case MetaFieldModel::ADDRESS_TYPE:

                $lat = $this->getData('_lat');
                $lng = $this->getData('_lng');
                $city = $this->getData('_city');
                $country = $this->getData('_country');

                return $this->formatRawValue([
                    'address' => $this->formatNestedRawValue($saved_field_value, $after, $before),
                    'city' => $city,
                    'country' => $country,
                    'lat'  => $lat,
                    'lng'  => $lng,
                ], $after, $before);

                // ADDRESS_MULTI_TYPE
            case MetaFieldModel::ADDRESS_MULTI_TYPE:

                $addresses = Address::fetchMulti($saved_field_value);
                $lat = Address::fetchMulti($this->getData('_lat'));
                $lng = Address::fetchMulti($this->getData('_lng'));
                $city = Address::fetchMulti($this->getData('_city'));
                $country = Address::fetchMulti($this->getData('_country'));

                $values = [];

                foreach ($addresses as $index => $address) {
                    $values[] = [
                        'address' => $this->formatNestedRawValue($address, $after, $before),
                        'city' => $city[$index] ?? null,
                        'country' => $country[$index] ?? null,
                        'lat'  => $lat[$index] ?? null,
                        'lng'  => $lng[$index] ?? null,
                    ];
                }

                return $this->formatRawValue($values, $after, $before);

                // CURRENCY_TYPE
            case MetaFieldModel::CURRENCY_TYPE:

                $unit = $this->getData('_currency');

                return $this->formatRawValue([
                    'amount' => $this->formatNestedRawValue($saved_field_value, $after, $before),
                    'unit' => $unit
                ], $after, $before);

                // DATE_TYPE
            case MetaFieldModel::DATE_TYPE:

                $defaultFormat = 'Y-m-d';
                $dateFormat = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $savedFormat =  $this->getData('_format') ?? $defaultFormat;
                $saved_date = \DateTime::createFromFormat($savedFormat, $saved_field_value);

                if (!$saved_date instanceof \DateTime) {
                    $saved_date = \DateTime::createFromFormat($dateFormat, $saved_field_value);
                }

                if (!$saved_date instanceof \DateTime) {
                    $saved_date = \DateTime::createFromFormat($defaultFormat, $saved_field_value);
                }

                if (!$saved_date instanceof \DateTime) {
                    return null;
                }

                $date = Date::format($dateFormat, $saved_date);

                return $this->formatRawValue([
                    'format' => $dateFormat,
                    'object' => $saved_date,
                    'value'  => $this->formatNestedRawValue($date, $after, $before),
                ], $after, $before);

                // DATE_TIME_TYPE
            case MetaFieldModel::DATE_TIME_TYPE:

                $defaultFormat = 'Y-m-d H:i:s';
                $dateFormat = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $timeFormat = $this->fieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $savedFormat = $this->getData('_format') ?? $defaultFormat;
                $saved_datetime = \DateTime::createFromFormat($savedFormat, $saved_field_value);

                if (!$saved_datetime instanceof \DateTime) {
                    $saved_datetime = \DateTime::createFromFormat($dateFormat, $saved_field_value);
                }

                if (!$saved_datetime instanceof \DateTime) {
                    $saved_datetime = \DateTime::createFromFormat($defaultFormat, $saved_field_value);
                }

                if (!$saved_datetime instanceof \DateTime) {
                    return null;
                }

                $datetime = Date::format($dateFormat . ' ' . $timeFormat, $saved_datetime);

                return $this->formatRawValue([
                    'format' => $dateFormat . ' ' . $timeFormat,
                    'object' => $saved_datetime,
                    'value'  => $this->formatNestedRawValue($datetime),
                ], $after, $before);

                // TIME_TYPE
            case MetaFieldModel::TIME_TYPE:

                $defaultFormat = 'H:i:s';
                $timeFormat = $this->fieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $savedFormat =  $this->getData('_format') ?? $defaultFormat;
                $saved_time = \DateTime::createFromFormat($savedFormat, $saved_field_value);

                if (!$saved_time instanceof \DateTime) {
                    $saved_time = \DateTime::createFromFormat($timeFormat, $saved_field_value);
                }

                if (!$saved_time instanceof \DateTime) {
                    $saved_time = \DateTime::createFromFormat($defaultFormat, $saved_field_value);
                }

                // the admin time picker submits the field's display format (e.g. "10:00"),
                // which matches none of the above when it differs from the site time_format (#1352)
                if (!$saved_time instanceof \DateTime && is_string($saved_field_value)) {
                    $canonical_time = DateNormalizer::toTime($saved_field_value);
                    $saved_time = $canonical_time !== null ? \DateTime::createFromFormat('H:i:s', $canonical_time) : false;
                }

                if (!$saved_time instanceof \DateTime) {
                    return null;
                }

                $time = Date::format($timeFormat, $saved_time);

                return $this->formatRawValue([
                    'format' => $timeFormat,
                    'object' => $saved_time,
                    'value'  => $this->formatNestedRawValue($time),
                ], $after, $before);

                // DATE_RANGE_TYPE
            case MetaFieldModel::DATE_RANGE_TYPE:

                if (!is_string($saved_field_value)) {
                    return [];
                }

                $saved_field_value = explode(" - ", $saved_field_value);

                if (Arrays::count($saved_field_value) !== 2) {
                    return [];
                }

                $defaultFormat = 'Y-m-d';
                $dateFormat = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $savedFormat = $this->getData('_format') ?? $defaultFormat;
                $saved_from = \DateTime::createFromFormat($savedFormat, $saved_field_value[0]);
                $saved_to = \DateTime::createFromFormat($savedFormat, $saved_field_value[1]);

                if (!$saved_from instanceof \DateTime) {
                    $saved_from = \DateTime::createFromFormat($dateFormat, $saved_field_value[0]);
                }

                if (!$saved_to instanceof \DateTime) {
                    $saved_to = \DateTime::createFromFormat($dateFormat, $saved_field_value[1]);
                }

                if (!$saved_from instanceof \DateTime) {
                    $saved_from = \DateTime::createFromFormat($defaultFormat, $saved_field_value[0]);
                }

                if (!$saved_to instanceof \DateTime) {
                    $saved_to = \DateTime::createFromFormat($defaultFormat, $saved_field_value[1]);
                }

                if (!$saved_from instanceof \DateTime) {
                    return null;
                }

                if (!$saved_to instanceof \DateTime) {
                    return null;
                }

                $from = Date::format($dateFormat, $saved_from);
                $to = Date::format($dateFormat, $saved_to);

                return $this->formatRawValue([
                    'format' => $dateFormat,
                    'object' => [
                        $saved_from,
                        $saved_to,
                    ],
                    'value' => [
                        $this->formatNestedRawValue($from, $after, $before),
                        $this->formatNestedRawValue($to, $after, $before),
                    ],
                ], $after, $before);

                // AUDIO_MULTI_TYPE
                // GALLERY_TYPE
                // VIDEO_MULTI_TYPE
            case MetaFieldModel::AUDIO_MULTI_TYPE:
            case MetaFieldModel::IMAGE_SLIDER_TYPE:
            case MetaFieldModel::GALLERY_TYPE:
            case MetaFieldModel::VIDEO_MULTI_TYPE:

                $id = $this->getAttachmentId();

                if (!empty($id)) {
                    $ids = explode(",", $id);
                    $gallery = [];

                    $numericIds = array_values(array_filter(array_map('intval', $ids)));
                    if (!empty($numericIds)) {
                        _prime_post_caches($numericIds, false, true);
                    }

                    foreach ($ids as $_id) {
                        $wpAttachment = $this->getAttachment($_id, $this->return);
                        $gallery[] = $wpAttachment;
                    }

                    return $this->formatRawValue($gallery, $after, $before);
                }

                if (is_array($saved_field_value)) {
                    $gallery = [];

                    foreach ($saved_field_value as $image) {
                        $wpAttachment = $this->getAttachment($image, $this->return);
                        $gallery[] = $wpAttachment;
                    }

                    return $this->formatRawValue($gallery, $after, $before);
                }

                $wpAttachment = $this->getAttachment($saved_field_value, $this->return);

                return $this->formatRawValue($wpAttachment, $after, $before);

                // FILE_TYPE
            case MetaFieldModel::FILE_TYPE:

                $label = $this->getData('_label');
                $id = $this->getAttachmentId();

                if (!empty($id)) {
                    $wpAttachment = $this->getAttachment($id, $this->return);
                } else {
                    $wpAttachment = $this->getAttachment($saved_field_value, $this->return);
                }

                return $this->formatRawValue([
                    'file' => $wpAttachment,
                    'label' => $this->formatNestedRawValue($label, $after, $before),
                ], $after, $before);

                // AUDIO_TYPE
                // IMAGE_TYPE
                // VIDEO_TYPE
            case MetaFieldModel::AUDIO_TYPE:
            case MetaFieldModel::IMAGE_TYPE:
            case MetaFieldModel::VIDEO_TYPE:

                $id = $this->getAttachmentId();
                if (!empty($id)) {
                    return $this->formatRawValue($this->getAttachment($id, $this->return), $after, $before);
                }

                return $this->formatRawValue($this->getAttachment($saved_field_value, $this->return), $after, $before);

                // LENGTH_TYPE
            case MetaFieldModel::LENGTH_TYPE:

                $unit = $this->getData('_length');

                return $this->formatRawValue([
                    'length' => $this->formatNestedRawValue($saved_field_value, $after, $before),
                    'unit' => $unit
                ], $after, $before);

                // EDITOR_TYPE
            case MetaFieldModel::EDITOR_TYPE:
                return ($this->formatRawValue(wpautop($saved_field_value), $after, $before));

                // CHECKBOX_TYPE
                // SELECT_MULTI_TYPE
            case MetaFieldModel::CHECKBOX_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:
            case MetaFieldModel::LIST_TYPE:

                $return = [];
                if (is_array($saved_field_value)) {
                    foreach ($saved_field_value as $value) {
                        $return[] = $this->formatNestedRawValue($value, $after, $before);
                    }
                }

                return $this->formatRawValue($return, $after, $before);

                // POST_TYPE
            case MetaFieldModel::POST_TYPE:

                if (empty($this->fieldModel->getRelations())) {
                    return [];
                }

                $relation = $this->fieldModel->getRelations()[0];
                $values = (is_string($saved_field_value)) ? explode(",", $saved_field_value) : $saved_field_value;
                $return_obj = [];

                switch ($relation->to()->getType()) {

                    case MetaTypes::CUSTOM_POST_TYPE:

                        if (is_array($values)) {
                            foreach ($values as $postId) {
                                if ($this->return === 'raw') {
                                    $obj = [
                                        'type' => MetaTypes::CUSTOM_POST_TYPE,
                                        'id' => $postId,
                                    ];
                                } else {
                                    $obj = $this->getPost($postId, $this->return);
                                }

                                $return_obj[] = $obj;
                            }
                        }

                        break;

                    case MetaTypes::TAXONOMY:

                        if (is_array($values)) {
                            foreach ($values as $termId) {
                                if ($this->return === 'raw') {
                                    $obj = [
                                        'type' => MetaTypes::TAXONOMY,
                                        'id' => $termId,
                                    ];
                                } else {
                                    $obj = $this->getTerm($termId, $this->return);
                                }

                                $return_obj[] = $obj;
                            }
                        }

                        break;

                    case MetaTypes::OPTION_PAGE:

                        if (is_array($values)) {
                            foreach ($values as $menuSlug) {
                                if ($this->return === 'raw') {
                                    $obj = [
                                        'type' => MetaTypes::OPTION_PAGE,
                                        'id' => $menuSlug,
                                    ];
                                } else {
                                    $obj = $this->getOptionPage($menuSlug, $this->return);
                                }

                                $return_obj[] = $obj;
                            }
                        }

                        break;

                    case MetaTypes::USER:

                        if (is_array($values)) {
                            foreach ($values as $userId) {
                                if ($this->return === 'raw') {
                                    $obj = [
                                        'type' => MetaTypes::USER,
                                        'id' => $userId,
                                    ];
                                } else {
                                    $obj = $this->getUser($userId, $this->return);
                                }

                                $return_obj[] = $obj;
                            }
                        }

                        break;
                }

                return $this->formatRawValue($return_obj, $after, $before);

                // POST_OBJECT
            case MetaFieldModel::POST_OBJECT_TYPE:
                $value = $this->getPost($saved_field_value, $this->return);

                return $this->formatRawValue($value, $after, $before);

                // POST_OBJECT_MULTI
            case MetaFieldModel::POST_OBJECT_MULTI_TYPE:

                $posts_obj = [];

                if (is_string($saved_field_value)) {
                    $saved_field_value = explode(",", $saved_field_value);
                }

                foreach ($saved_field_value as $post_id) {
                    $posts_obj[] = $this->getPost($post_id, $this->return);
                }

                return $this->formatRawValue($posts_obj, $after, $before);

                // QR_CODE_TYPE
            case MetaFieldModel::BARCODE_TYPE:

                $rawBarcodeValue = $this->getData('_barcode_value');

                if (!is_string($rawBarcodeValue)) {
                    return $saved_field_value;
                }

                if (empty($rawBarcodeValue)) {
                    return $saved_field_value;
                }

                $clean_json = trim($rawBarcodeValue, '"');
                $clean_json = stripslashes($clean_json);

                if (!Strings::isJson($clean_json)) {
                    return $saved_field_value;
                }

                $barcodeValue = json_decode($clean_json, true);

                if (!isset($barcodeValue['svg'])) {
                    return $saved_field_value;
                }

                $barcodeValue['svg'] = html_entity_decode($barcodeValue['svg']);

                if (!isset($barcodeValue['format'])) {
                    return $saved_field_value;
                }

                return $this->formatRawValue([
                    'text' => $saved_field_value,
                    'value' => $barcodeValue
                ], $after, $before);


                // QR_CODE_TYPE
            case MetaFieldModel::QR_CODE_TYPE:

                $rawQRCodeValue = $this->getData('_qr_code_value');

                if (!is_string($rawQRCodeValue)) {
                    return $saved_field_value;
                }

                if (empty($rawQRCodeValue)) {
                    return $saved_field_value;
                }

                $clean_json = trim($rawQRCodeValue, '"');
                $clean_json = stripslashes($clean_json);

                if (!Strings::isJson($clean_json)) {
                    return $saved_field_value;
                }

                $QRCodeValue = json_decode($clean_json, true);

                if (!isset($QRCodeValue['img'])) {
                    return $saved_field_value;
                }

                if (!isset($QRCodeValue['resolution'])) {
                    return $saved_field_value;
                }

                return $this->formatRawValue([
                    'url' => $saved_field_value,
                    'value' => $QRCodeValue
                ], $after, $before);

                // FLEXIBLE TYPE
            case MetaFieldModel::FLEXIBLE_CONTENT_TYPE:
                return $this->getNestedBlockValues($saved_field_value);

                // REPEATER_TYPE
            case MetaFieldModel::REPEATER_TYPE:
                return $this->getRepeaterValues($saved_field_value);

            case MetaFieldModel::PHONE_TYPE:

                $dial = $this->getData('_dial');

                return $this->formatRawValue([
                    'dial' => $dial ?? null,
                    'value' => $saved_field_value,
                ], $after, $before);

                // TERM_OBJECT
            case MetaFieldModel::TERM_OBJECT_TYPE:
                $value = $this->getTerm($saved_field_value, $this->return);

                return $this->formatRawValue($value, $after, $before);

                // TERM_OBJECT_MULTI
            case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:

                $terms_obj = [];

                if (is_string($saved_field_value)) {
                    $saved_field_value = explode(",", $saved_field_value);
                }

                foreach ($saved_field_value as $term_id) {
                    $terms_obj[] = $this->getTerm($term_id, $this->return);
                }

                return $this->formatRawValue($terms_obj, $after, $before);

                // WEIGHT_TYPE
            case MetaFieldModel::WEIGHT_TYPE:

                $unit = $this->getData('_weight');

                return $this->formatRawValue([
                    'weight' => $this->formatRawValue($saved_field_value, $after, $before),
                    'unit' => $unit
                ], $after, $before);

                // COUNTRY
            case MetaFieldModel::COUNTRY_TYPE:
                $country = $this->getData('_country');

                return $this->formatRawValue([
                    'value' => $this->formatNestedRawValue($saved_field_value, $after, $before),
                    'country' => $country
                ], $after, $before);

                // URL
            case MetaFieldModel::URL_TYPE:
                // always return the {url, label} shape (every integration reads $value['url']);
                // with no link text the label falls back to the URL
                $label = $this->getData('_label');

                return $this->formatRawValue([
                    'after' => $after,
                    'before' => $before,
                    'url' => $saved_field_value,
                    'label' => $this->formatNestedRawValue(!empty($label) ? $label : $saved_field_value, $after, $before),
                ], $after, $before);

                // USER
            case MetaFieldModel::USER_TYPE:
                $value = $this->getUser($saved_field_value, $this->return);

                return $this->formatRawValue($value, $after, $before);

                // USER_MULTI
            case MetaFieldModel::USER_MULTI_TYPE:

                $users_obj = [];

                if (is_string($saved_field_value)) {
                    $saved_field_value = explode(",", $saved_field_value);
                }

                foreach ($saved_field_value as $user_id) {
                    $users_obj[] = $this->getUser($user_id, $this->return);
                }

                return $this->formatRawValue($users_obj, $after, $before);

                // RATING_TYPE
                // NUMBER_TYPE
                // RANGE_TYPE
            case MetaFieldModel::RATING_TYPE:
            case MetaFieldModel::NUMBER_TYPE:
            case MetaFieldModel::RANGE_TYPE:

                if (is_numeric($saved_field_value)) {
                    if (strpos((string)$saved_field_value, '.') !== false) {
                        $numericValue = floatval($saved_field_value);
                    } else {
                        $numericValue = intval($saved_field_value);
                    }
                } else {
                    $numericValue = $saved_field_value;
                }

                return $this->formatRawValue($numericValue, $after, $before);

                // TOGGLE_TYPE
            case MetaFieldModel::TOGGLE_TYPE:
                return $this->formatRawValue($saved_field_value == 1, $after, $before);

                // DEFAULT VALUE
            default:

                $allowHtml = $this->fieldModel->getAdvancedOption("allow_html");

                if ($allowHtml == 1) {
                    $saved_field_value = html_entity_decode($saved_field_value);
                }

                if (!is_string($saved_field_value)) {
                    $saved_field_value = (string)$saved_field_value;
                }

                return $this->formatRawValue(WPUtils::renderShortCode($saved_field_value), $after, $before);
        }
    }

    /**
     * @return string|null
     */
    private function getAttachmentId(): ?string
    {
        // legacy format
        if (!empty($this->getData('_id')) && is_numeric($this->getData('_id'))) {
            return (string)$this->getData('_id');
        }

        // current format
        $attachmentId = $this->getData('_attachment_id');

        return $attachmentId ? (string)$attachmentId : null;
    }

    /**
     * @param mixed $value
     * @param mixed $after
     * @param mixed $before
     * @return array<string, mixed>|string
     */
    private function formatRawValue($value, $after = null, $before = null)
    {
        if ($this->withContext) {
            return [
                'before' => $before,
                'value' => $value,
                'after' => $after,
            ];
        }

        if (is_string($value)) {
            $value = $before.$value.$after;

            // @phpstan-ignore-next-line function.impossibleType
            if (is_int($value)) {
                return (int)$value;
            }

            // @phpstan-ignore-next-line function.impossibleType
            if (is_float($value)) {
                return (floatval($value));
            }

            return $value;
        }

        return $value;
    }

    /**
     * @param mixed $value
     * @param mixed $after
     * @param mixed $before
     * @return mixed
     */
    private function formatNestedRawValue($value, $after = null, $before = null)
    {
        if ($this->withContext) {
            return $value;
        }

        if (is_string($value)) {
            return $before.$value.$after;
        }

        return $value;
    }

    /**
     * @param mixed $saved_field_value
     * @return array<string, mixed>
     */
    private function getNestedBlockValues($saved_field_value): array
    {
        if (!is_array($saved_field_value) || !isset($saved_field_value['blocks'])) {
            return [];
        }

        $values = [];

        foreach ($saved_field_value['blocks'] as $block_index => $block) {
            if (!is_array($block)) {
                return [];
            }

            $i = 0;
            foreach ($block as $block_name => $block_fields) {
                foreach ($block_fields as $block_field_name => $block_field) {
                    foreach ($block_field as $block_field_index => $block_field_value) {
                        if (isset($block_field_value['blocks'])) {
                            // nested blocks in block
                            $nested_block_name = @array_keys($block_field_value['blocks'][0])[0];
                            $values['blocks'][$block_index][$block_name][$i]['blocks'][$block_field_index][$nested_block_name][] = $this->getNestedBlockValues($block_field_value);
                        } elseif (!isset($block_field_value['value'])) {
                            // nested repeaters in block
                            $values['blocks'][$block_index][$block_name][$block_field_name][$block_field_index] = $this->getRepeaterValues($block_field_value);
                        } else {
                            $values['blocks'][$block_index][$block_name][$block_field_value['original_name']][$block_field_index] = $this->getNestedRepeaterFieldValue($block_field_value);
                        }
                    }
                }

                $i++;
            }
        }

        return $values;
    }

    /**
     * @param mixed $saved_field_value
     * @return array<int, mixed>|bool
     */
    private function getRepeaterValues($saved_field_value)
    {
        if (!is_array($saved_field_value)) {
            return false;
        }

        $values = [];

        // this is needed for values nested inside a nested repeater
        unset($saved_field_value['original_name']);
        unset($saved_field_value['type']);

        $keys = array_keys($saved_field_value);

        if (empty($keys)) {
            return $values;
        }

        $firstKey = $keys[0];

        if (isset($saved_field_value[$firstKey]) && is_array($saved_field_value[$firstKey])) {
            $firstElement = $saved_field_value[$firstKey];

            for ($i=0; $i<Arrays::count($firstElement); $i++) {
                $element = [];

                foreach (array_keys($saved_field_value) as $index => $key) {
                    $nestedBefore = null;
                    $nestedAfter = null;
                    $nestedFieldModal = $this->fieldModel->getChild($key);

                    if ($nestedFieldModal !== null && $nestedFieldModal->canHaveAfterAndBefore()) {
                        $nestedBefore = $nestedFieldModal->getAdvancedOption("before");
                        $nestedAfter = $nestedFieldModal->getAdvancedOption("after");
                    }

                    if (isset($saved_field_value[$key]) && isset($saved_field_value[$key][$i])) {
                        $rawData = $saved_field_value[$key][$i];

                        if (isset($rawData['blocks'])) {
                            // block nested in repeater
                            $element[$key][] = $this->getNestedBlockValues($rawData);
                        } elseif (!isset($rawData['value'])) {
                            // repeater nested in repeater
                            $element[$key][] = $this->getRepeaterValues($rawData);
                        } else {
                            if (isset($rawData['original_name'])) {
                                $element[$rawData['original_name']] = $this->getNestedRepeaterFieldValue($rawData);
                            }
                        }
                    }
                }

                $values[] = $element;
            }
        }

        return $values;
    }

    /**
     * @param array<string, mixed> $rawData
     * @return WPAttachment|mixed|null
     */
    private function getNestedRepeaterFieldValue(array $rawData = [])
    {
        if (!isset($rawData['type'])) {
            return null;
        }

        if (!isset($rawData['original_name'])) {
            return null;
        }

        $type = is_array($rawData['type']) ? $rawData['type'][0] : $rawData['type'];
        $value = $rawData['value'];
        $id = (isset($rawData['id'])) ? $rawData['id'] : null;

        $before = null;
        $after = null;
        $nestedFieldModal = $this->fieldModel->getChild($rawData['original_name']);

        if ($nestedFieldModal !== null && $nestedFieldModal->canHaveAfterAndBefore()) {
            $before = $nestedFieldModal->getAdvancedOption("before");
            $after = $nestedFieldModal->getAdvancedOption("after");
        }

        // date/time display formats belong to the child field, not to the parent
        // repeater: reading the parent's (usually unset) option fell back to the site
        // format, so a child saved as e.g. "08/10/2026" (d/m/Y) never parsed (#1393)
        $formatFieldModel = $nestedFieldModal ?? $this->fieldModel;

        switch ($type) {

            // ADDRESS_TYPE
            case MetaFieldModel::ADDRESS_TYPE:
                return $this->formatRawValue([
                    'address' => $this->formatNestedRawValue($value, $after, $before),
                    'lat'     => $rawData['lat'] ?? null,
                    'lng'     => $rawData['lng'] ?? null,
                    'city'    => $rawData['city'] ?? null,
                    'country' => $rawData['country'] ?? null,
                ], $after, $before);

                // ADDRESS_MULTI_TYPE
            case MetaFieldModel::ADDRESS_MULTI_TYPE:

                $addresses = Address::fetchMulti($value);
                $lat = Address::fetchMulti($rawData['lat']);
                $lng = Address::fetchMulti($rawData['lng']);
                $city = Address::fetchMulti($rawData['city']);
                $country = Address::fetchMulti($rawData['country']);
                $values = [];

                foreach ($addresses as $index => $address) {
                    $values[] = [
                        'address' => $this->formatNestedRawValue($address, $after, $before),
                        'lat'     => $lat[$index] ?? null,
                        'lng'     => $lng[$index] ?? null,
                        'city'    => $city[$index] ?? null,
                        'country' => $country[$index] ?? null,
                    ];
                }

                return $this->formatRawValue($values, $after, $before);

                // CURRENCY_TYPE
            case MetaFieldModel::CURRENCY_TYPE:
                return $this->formatRawValue([
                    'amount' => $this->formatNestedRawValue($value, $after, $before),
                    'unit' => $rawData['currency'] ?? null,
                ], $after, $before);

                // GALLERY_TYPE
                // VIDEO_MULTI_TYPE
            case MetaFieldModel::GALLERY_TYPE:
            case MetaFieldModel::VIDEO_MULTI_TYPE:

                if (!empty($id)) {
                    $ids = explode(',', $id);

                    $gallery = [];

                    $numericIds = array_values(array_filter(array_map('intval', $ids)));
                    if (!empty($numericIds)) {
                        _prime_post_caches($numericIds, false, true);
                    }

                    foreach ($ids as $_id) {
                        $wpAttachment = $this->getAttachment($_id, $this->return);
                        if ($wpAttachment !== null) {
                            $gallery[] = $wpAttachment;
                        }
                    }

                    return $this->formatRawValue($gallery, $after, $before);
                }

                if (is_array($value)) {
                    $gallery = [];

                    foreach ($value as $image) {
                        $wpAttachment = $this->getAttachment($image, $this->return);
                        if ($wpAttachment !== null) {
                            $gallery[] = $wpAttachment;
                        }
                    }

                    return $this->formatRawValue($gallery, $after, $before);
                }

                $wpAttachment = $this->getAttachment($value, $this->return);

                if (empty($wpAttachment)) {
                    return null;
                }

                return $this->formatRawValue($wpAttachment, $after, $before);

                // FILE_TYPE
            case MetaFieldModel::FILE_TYPE:

                $label = (isset($rawData['label']) && !empty($rawData['label'])) ? $rawData['label'] : null;

                if (!empty($id)) {
                    $wpAttachment = $this->getAttachment($id, $this->return);
                } else {
                    $wpAttachment = $this->getAttachment($value, $this->return);
                }

                return $this->formatRawValue([
                    'file' => $wpAttachment,
                    'label' => $this->formatNestedRawValue($label, $after, $before)
                ], $after, $before);

                // IMAGE_TYPE
                // VIDEO_TYPE
            case MetaFieldModel::IMAGE_TYPE:
            case MetaFieldModel::VIDEO_TYPE:

                if (!empty($id)) {
                    return $this->getAttachment($id, $this->return);
                }

                $wpAttachment = $this->getAttachment($value, $this->return);

                if (empty($wpAttachment)) {
                    return null;
                }

                return $this->formatRawValue($wpAttachment, $after, $before);

                // DATE_RANGE_TYPE
            case MetaFieldModel::DATE_RANGE_TYPE:

                if (!is_string($value)) {
                    return [];
                }

                $saved_field_value = explode(" - ", $value);

                if (Arrays::count($saved_field_value) !== 2) {
                    return [];
                }

                $defaultFormat = 'Y-m-d';
                $dateFormat = $formatFieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $savedFormat = $this->getData('_format') ?? $defaultFormat;
                $saved_from = \DateTime::createFromFormat($savedFormat, $saved_field_value[0]);
                $saved_to = \DateTime::createFromFormat($savedFormat, $saved_field_value[1]);

                if (!$saved_from instanceof \DateTime) {
                    $saved_from = \DateTime::createFromFormat($dateFormat, $saved_field_value[0]);
                }

                if (!$saved_to instanceof \DateTime) {
                    $saved_to = \DateTime::createFromFormat($dateFormat, $saved_field_value[1]);
                }

                if (!$saved_from instanceof \DateTime) {
                    $saved_from = \DateTime::createFromFormat($defaultFormat, $saved_field_value[0]);
                }

                if (!$saved_to instanceof \DateTime) {
                    $saved_to = \DateTime::createFromFormat($defaultFormat, $saved_field_value[1]);
                }

                if (!$saved_from instanceof \DateTime) {
                    return null;
                }

                if (!$saved_to instanceof \DateTime) {
                    return null;
                }

                $from = Date::format($dateFormat, $saved_from);
                $to = Date::format($dateFormat, $saved_to);

                return $this->formatRawValue([
                        'format' => $dateFormat,
                        'object' => [
                                $saved_from,
                                $saved_to,
                        ],
                        'value' => [
                                $this->formatNestedRawValue($from, $after, $before),
                                $this->formatNestedRawValue($to, $after, $before),
                        ],
                ], $after, $before);

                // DATE_TIME_TYPE
            case MetaFieldModel::DATE_TIME_TYPE:

                $defaultFormat = 'Y-m-d H:i:s';
                $dateFormat = $formatFieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $timeFormat = $formatFieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $savedFormat = $this->getData('_format') ?? $defaultFormat;
                $saved_datetime = \DateTime::createFromFormat($savedFormat, $value);

                if (!$saved_datetime instanceof \DateTime) {
                    $saved_datetime = \DateTime::createFromFormat($dateFormat, $value);
                }

                if (!$saved_datetime instanceof \DateTime) {
                    $saved_datetime = \DateTime::createFromFormat($defaultFormat, $value);
                }

                if (!$saved_datetime instanceof \DateTime) {
                    return null;
                }

                $datetime = Date::format($dateFormat . ' ' . $timeFormat, $saved_datetime);

                return $this->formatRawValue([
                        'format' => $dateFormat . ' ' . $timeFormat,
                        'object' => $saved_datetime,
                        'value'  => $this->formatNestedRawValue($datetime),
                ], $after, $before);

                // TIME_TYPE
            case MetaFieldModel::TIME_TYPE:

                $defaultFormat = 'H:i:s';
                $timeFormat = $formatFieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $savedFormat =  $this->getData('_format') ?? $defaultFormat;
                $saved_time = \DateTime::createFromFormat($savedFormat, $value);

                if (!$saved_time instanceof \DateTime) {
                    $saved_time = \DateTime::createFromFormat($timeFormat, $value);
                }

                if (!$saved_time instanceof \DateTime) {
                    $saved_time = \DateTime::createFromFormat($defaultFormat, $value);
                }

                // the admin time picker submits the field's display format (e.g. "10:00"),
                // which matches none of the above when it differs from the site time_format (#1352)
                if (!$saved_time instanceof \DateTime && is_string($value)) {
                    $canonical_time = DateNormalizer::toTime($value);
                    $saved_time = $canonical_time !== null ? \DateTime::createFromFormat('H:i:s', $canonical_time) : false;
                }

                if (!$saved_time instanceof \DateTime) {
                    return null;
                }

                $time = Date::format($timeFormat, $saved_time);

                return $this->formatRawValue([
                        'format' => $timeFormat,
                        'object' => $saved_time,
                        'value'  => $this->formatNestedRawValue($time),
                ], $after, $before);

                // DATE_TYPE
            case MetaFieldModel::DATE_TYPE:

                $dateFormat = $formatFieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $savedFormat =  $rawData['format'] ?? 'Y-m-d';
                $saved_date = \DateTime::createFromFormat($savedFormat, $value);

                if (!$saved_date instanceof \DateTime) {
                    $saved_date = \DateTime::createFromFormat($dateFormat, $value);
                }

                if (!$saved_date instanceof \DateTime) {
                    $saved_date = \DateTime::createFromFormat("Y-m-d", $value);
                }

                if (!$saved_date instanceof \DateTime) {
                    return null;
                }

                $date = Date::format($dateFormat, $saved_date);

                return $this->formatRawValue([
                        'format' => $savedFormat,
                        'object' => $saved_date,
                        'value'  => $this->formatNestedRawValue($date, $after, $before),
                ], $after, $before);

                // LENGTH_TYPE
            case MetaFieldModel::LENGTH_TYPE:
                return $this->formatRawValue([
                    'length' => $this->formatNestedRawValue($value, $after, $before),
                    'unit' => $rawData['length'] ?? null,
                ], $after, $before);

                // QR_CODE_TYPE
            case MetaFieldModel::QR_CODE_TYPE:

                if (!isset($rawData['qr_code_value'])) {
                    return $rawData['value'];
                }

                $rawQRCodeValue = $rawData['qr_code_value'];

                if (!is_string($rawQRCodeValue)) {
                    return $rawData['value'];
                }

                if (empty($rawQRCodeValue)) {
                    return $rawData['value'];
                }

                if (!Strings::isJson($rawQRCodeValue)) {
                    return $rawData['value'];
                }

                $QRCodeValue = json_decode($rawQRCodeValue, true);

                if (!isset($QRCodeValue['img'])) {
                    return $rawData['value'];
                }

                if (!isset($QRCodeValue['resolution'])) {
                    return $rawData['value'];
                }

                return $this->formatRawValue([
                    'url'   => $rawData['value'],
                    'value' => $this->formatNestedRawValue($QRCodeValue, $after, $before),
                ], $after, $before);

                // WEIGHT_TYPE
            case MetaFieldModel::WEIGHT_TYPE:
                return $this->formatRawValue([
                    'weight' => $this->formatNestedRawValue($value, $after, $before),
                    'unit' => $rawData['weight'],
                ], $after, $before);

                // TABLE_TYPE
            case MetaFieldModel::TABLE_TYPE:
                $sortable = $this->fieldModel->getAdvancedOption('sortable') == 1;
                $pagination = $this->fieldModel->getAdvancedOption('pagination');
                $generator = new TableFieldGenerator($value, $sortable, $pagination);

                return $this->formatRawValue($generator->generate(), $after, $before);

                // PHONE_TYPE
            case MetaFieldModel::PHONE_TYPE:
                return $this->formatRawValue([
                    'dial' => $rawData['dial'] ?? null,
                    'value' => $this->formatNestedRawValue($value, $after, $before),
                ], $after, $before);

                // URL_TYPE
            case MetaFieldModel::URL_TYPE:
                $label = (isset($rawData['label']) && !empty($rawData['label'])) ? $rawData['label'] : $value;

                return $this->formatRawValue([
                    'after' => $after,
                    'before' => $before,
                    'url' => $value,
                    'label' => $this->formatNestedRawValue($label, $after, $before),
                ], $after, $before);

                // POST_TYPE (relational field)
            case MetaFieldModel::POST_TYPE:

                if ($nestedFieldModal === null || empty($nestedFieldModal->getRelations())) {
                    return [];
                }

                $relation = $nestedFieldModal->getRelations()[0];
                $values = (is_string($value)) ? explode(",", $value) : $value;
                $return_obj = [];

                switch ($relation->to()->getType()) {

                    case MetaTypes::CUSTOM_POST_TYPE:
                        if (is_array($values)) {
                            foreach ($values as $postId) {
                                $return_obj[] = ($this->return === 'raw')
                                    ? ['type' => MetaTypes::CUSTOM_POST_TYPE, 'id' => $postId]
                                    : $this->getPost($postId, $this->return);
                            }
                        }
                        break;

                    case MetaTypes::TAXONOMY:
                        if (is_array($values)) {
                            foreach ($values as $termId) {
                                $return_obj[] = ($this->return === 'raw')
                                    ? ['type' => MetaTypes::TAXONOMY, 'id' => $termId]
                                    : $this->getTerm($termId, $this->return);
                            }
                        }
                        break;

                    case MetaTypes::OPTION_PAGE:
                        if (is_array($values)) {
                            foreach ($values as $menuSlug) {
                                $return_obj[] = ($this->return === 'raw')
                                    ? ['type' => MetaTypes::OPTION_PAGE, 'id' => $menuSlug]
                                    : $this->getOptionPage($menuSlug, $this->return);
                            }
                        }
                        break;

                    case MetaTypes::USER:
                        if (is_array($values)) {
                            foreach ($values as $userId) {
                                $return_obj[] = ($this->return === 'raw')
                                    ? ['type' => MetaTypes::USER, 'id' => $userId]
                                    : $this->getUser($userId, $this->return);
                            }
                        }
                        break;
                }

                return $this->formatRawValue($return_obj, $after, $before);

                // POST_OBJECT
            case MetaFieldModel::POST_OBJECT_TYPE:
                return $this->formatRawValue($this->getPost($value, $this->return), $after, $before);

                // POST_OBJECT_MULTI
            case MetaFieldModel::POST_OBJECT_MULTI_TYPE:
                $posts_obj = [];
                $postIds = is_string($value) ? explode(",", $value) : $value;

                foreach ((array)$postIds as $post_id) {
                    $posts_obj[] = $this->getPost($post_id, $this->return);
                }

                return $this->formatRawValue($posts_obj, $after, $before);

                // TERM_OBJECT
            case MetaFieldModel::TERM_OBJECT_TYPE:
                return $this->formatRawValue($this->getTerm($value, $this->return), $after, $before);

                // TERM_OBJECT_MULTI
            case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:
                $terms_obj = [];
                $termIds = is_string($value) ? explode(",", $value) : $value;

                foreach ((array)$termIds as $term_id) {
                    $terms_obj[] = $this->getTerm($term_id, $this->return);
                }

                return $this->formatRawValue($terms_obj, $after, $before);

                // USER
            case MetaFieldModel::USER_TYPE:
                return $this->formatRawValue($this->getUser($value, $this->return), $after, $before);

                // USER_MULTI
            case MetaFieldModel::USER_MULTI_TYPE:
                $users_obj = [];
                $userIds = is_string($value) ? explode(",", $value) : $value;

                foreach ((array)$userIds as $user_id) {
                    $users_obj[] = $this->getUser($user_id, $this->return);
                }

                return $this->formatRawValue($users_obj, $after, $before);

            default:
                return $this->formatRawValue($value, $after, $before);
        }
    }

    /**
     * @param int    $postId
     * @param string $return
     * @return int|\WP_Post|null
     */
    private function getPost(int $postId, string $return = 'object')
    {
        if ($return === 'raw') {
            return (int)$postId;
        }

        return get_post($postId);
    }

    /**
     * @param int    $termId
     * @param string $return
     * @return int|\WP_Term|null
     */
    private function getTerm(int $termId, string $return = 'object')
    {
        if ($return === 'raw') {
            return (int)$termId;
        }

        $term = get_term($termId);

        if (empty($term)) {
            return null;
        }

        if ($term instanceof \WP_Term) {
            return $term;
        }

        return null;
    }

    /**
     * @param int    $userId
     * @param string $return
     * @return int|\WP_User
     */
    private function getUser(int $userId, string $return = 'object')
    {
        if ($return === 'raw') {
            return (int)$userId;
        }

        $user = get_user_by('id', $userId);

        if ($user instanceof \WP_User) {
            return $user;
        }

        return 0;
    }

    /**
     * @param string $optionPage
     * @param string $return
     * @return OptionPageModel|string|null
     */
    private function getOptionPage(string $optionPage, string $return = 'object')
    {
        if ($return === 'raw') {
            return (string)$optionPage;
        }

        try {
            return OptionPageRepository::getByMenuSlug($optionPage);
        } catch (\Exception $exception) {
            do_action("acpt/error", $exception);

            return null;
        }
    }

    /**
     * @param mixed  $id
     * @param string $return
     * @return WPAttachment|int|null
     */
    private function getAttachment($id, string $return = 'object')
    {
        // if $id is the media ID
        if (is_numeric($id)) {
            if ($return === 'raw') {
                return (int)$id;
            }

            $wpAttachment = WPAttachment::fromId((int)$id);

            if ($wpAttachment->isEmpty()) {
                return null;
            }

            return $wpAttachment;
        }

        // if $id is the media URL
        $wpAttachment = WPAttachment::fromUrl($id);

        if ($wpAttachment->isEmpty()) {
            return null;
        }

        if ($return === 'raw') {
            return (int)$wpAttachment->getId();
        }

        return $wpAttachment;
    }

    /**
     * @return array<string, mixed>
     */
    private function buildCCTContext(): array
    {
        switch ($this->belongsTo) {
            case MetaTypes::MEDIA:            return ['mediaId'   => $this->location];
            case MetaTypes::CUSTOM_POST_TYPE: return ['postId'    => $this->location];
            case MetaTypes::TAXONOMY:         return ['termId'    => $this->location];
            case MetaTypes::USER:             return ['userId'    => $this->location];
            case MetaTypes::COMMENT:          return ['commentId' => $this->location];
            case MetaTypes::OPTION_PAGE:      return ['page'      => $this->location];
            default:                          return [];
        }
    }

    /**
     * Execute the query for a CCT (custom table) field.
     *
     * All data lives in a single JSON column; this maps CCT shapes to the
     * same output format as the meta path so callers see identical structures.
     *
     * @return array<string, mixed>|string|null
     * @throws \Exception
     */
    private function executeCCT()
    {
        $tableName  = $this->fieldModel->getBox()->getGroup()->getName();
        $columnName = $this->fieldModel->getName();
        $context    = $this->buildCCTContext();

        if (empty($context)) {
            return null;
        }

        $tableModel = TableRepository::getByName($tableName);
        if ($tableModel === null) {
            return null;
        }

        $raw = TableRecord::fetch($tableModel, $context, $columnName);
        if ($raw === null || $raw === '' || $raw === []) {
            return null;
        }

        $before = null;
        $after  = null;
        $advanced_options = $this->fieldModel->getAdvancedOptions();
        // @phpstan-ignore-next-line function.alreadyNarrowedType
        if (is_array($advanced_options)) {
            foreach ($advanced_options as $opt) {
                if ($opt->getKey() === 'after') {
                    $after  = $opt->getValue();
                }
                if ($opt->getKey() === 'before') {
                    $before = $opt->getValue();
                }
            }
        }

        if ($this->return === 'string') {
            return $before . Strings::intoString($raw) . $after;
        }

        $type = $this->fieldModel->getType();

        switch ($type) {

            case MetaFieldModel::ADDRESS_TYPE:
                return $this->formatRawValue([
                    'address' => $this->formatNestedRawValue($raw[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                    'city'    => $raw[CCTFieldShape::KEY_CITY]    ?? null,
                    'country' => $raw[CCTFieldShape::KEY_COUNTRY] ?? null,
                    'lat'     => $raw[CCTFieldShape::KEY_LAT]     ?? null,
                    'lng'     => $raw[CCTFieldShape::KEY_LNG]     ?? null,
                ], $after, $before);

            case MetaFieldModel::ADDRESS_MULTI_TYPE:
                $values = [];
                if (is_array($raw)) {
                    foreach ($raw as $item) {
                        $values[] = [
                            'address' => $this->formatNestedRawValue($item[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                            'city'    => $item[CCTFieldShape::KEY_CITY]    ?? null,
                            'country' => $item[CCTFieldShape::KEY_COUNTRY] ?? null,
                            'lat'     => $item[CCTFieldShape::KEY_LAT]     ?? null,
                            'lng'     => $item[CCTFieldShape::KEY_LNG]     ?? null,
                        ];
                    }
                }
                return $this->formatRawValue($values, $after, $before);

            case MetaFieldModel::CURRENCY_TYPE:
                return $this->formatRawValue([
                    'amount' => $this->formatNestedRawValue($raw[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                    'unit'   => $raw[CCTFieldShape::KEY_UNIT] ?? null,
                ], $after, $before);

            case MetaFieldModel::WEIGHT_TYPE:
                return $this->formatRawValue([
                    'weight' => $this->formatNestedRawValue($raw[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                    'unit'   => $raw[CCTFieldShape::KEY_UNIT] ?? null,
                ], $after, $before);

            case MetaFieldModel::LENGTH_TYPE:
                return $this->formatRawValue([
                    'length' => $this->formatNestedRawValue($raw[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                    'unit'   => $raw[CCTFieldShape::KEY_UNIT] ?? null,
                ], $after, $before);

            case MetaFieldModel::PHONE_TYPE:
                if (is_string($raw)) {
                    // JSON column stores plain strings as JSON string scalars: '"333 567 56"'.
                    // JSON::isValid() only recognises objects/arrays, so formatValue() passes
                    // these through unchanged — decode here so callers get the bare string back.
                    if (isset($raw[0]) && $raw[0] === '"') {
                        $decoded = json_decode($raw);
                        if (is_string($decoded)) {
                            $raw = $decoded;
                        }
                    }
                    return $this->formatRawValue($raw, $after, $before);
                }
                $phoneResult = [
                    'dial'  => is_array($raw) ? ($raw[CCTFieldShape::KEY_DIAL]  ?? null) : null,
                    'value' => is_array($raw) ? ($raw[CCTFieldShape::KEY_VALUE] ?? null) : null,
                ];
                if (is_array($raw) && isset($raw[CCTFieldShape::KEY_COUNTRY])) {
                    $phoneResult['country'] = $raw[CCTFieldShape::KEY_COUNTRY];
                }
                return $this->formatRawValue($phoneResult, $after, $before);

                // CCT 'code' key maps to output 'country' key (matching meta output convention).
                // Stored lowercase to match Country::getIsoCodes(); surfaced uppercase to match
                // the conventional ISO 3166-1 alpha-2 format ("IT") callers expect back.
            case MetaFieldModel::COUNTRY_TYPE:
                $code = $raw[CCTFieldShape::KEY_CODE] ?? null;
                return $this->formatRawValue([
                    'value'   => $this->formatNestedRawValue($raw[CCTFieldShape::KEY_VALUE] ?? null, $after, $before),
                    'country' => is_string($code) ? strtoupper($code) : $code,
                ], $after, $before);

            case MetaFieldModel::URL_TYPE:
                $label = $raw['label'] ?? $raw[CCTFieldShape::KEY_URL] ?? null;
                return $this->formatRawValue([
                    'after'  => $after,
                    'before' => $before,
                    'url'    => $raw[CCTFieldShape::KEY_URL] ?? null,
                    'label'  => $this->formatNestedRawValue($label, $after, $before),
                ], $after, $before);

            case MetaFieldModel::DATE_TYPE:
                $dateFormat = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $saved_date = \DateTime::createFromFormat('Y-m-d', (string)$raw);
                if (!$saved_date instanceof \DateTime) {
                    return null;
                }
                return $this->formatRawValue([
                    'format' => $dateFormat,
                    'object' => $saved_date,
                    'value'  => $this->formatNestedRawValue(Date::format($dateFormat, $saved_date), $after, $before),
                ], $after, $before);

            case MetaFieldModel::DATE_TIME_TYPE:
                $dateFormat   = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $timeFormat   = $this->fieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $saved_datetime = \DateTime::createFromFormat('Y-m-d H:i:s', (string)$raw);
                if (!$saved_datetime instanceof \DateTime) {
                    return null;
                }
                return $this->formatRawValue([
                    'format' => $dateFormat . ' ' . $timeFormat,
                    'object' => $saved_datetime,
                    'value'  => $this->formatNestedRawValue(Date::format($dateFormat . ' ' . $timeFormat, $saved_datetime)),
                ], $after, $before);

            case MetaFieldModel::TIME_TYPE:
                $timeFormat = $this->fieldModel->getAdvancedOption('time_format') ?? get_option('time_format');
                $saved_time = \DateTime::createFromFormat('H:i:s', (string)$raw);
                if (!$saved_time instanceof \DateTime) {
                    return null;
                }
                return $this->formatRawValue([
                    'format' => $timeFormat,
                    'object' => $saved_time,
                    'value'  => $this->formatNestedRawValue(Date::format($timeFormat, $saved_time)),
                ], $after, $before);

            case MetaFieldModel::DATE_RANGE_TYPE:
                if (!is_array($raw) || !isset($raw[CCTFieldShape::KEY_FROM], $raw[CCTFieldShape::KEY_TO])) {
                    return null;
                }
                $dateFormat = $this->fieldModel->getAdvancedOption('date_format') ?? get_option('date_format');
                $saved_from = \DateTime::createFromFormat('Y-m-d', $raw[CCTFieldShape::KEY_FROM]);
                $saved_to   = \DateTime::createFromFormat('Y-m-d', $raw[CCTFieldShape::KEY_TO]);
                if (!$saved_from instanceof \DateTime || !$saved_to instanceof \DateTime) {
                    return null;
                }
                return $this->formatRawValue([
                    'format' => $dateFormat,
                    'object' => [$saved_from, $saved_to],
                    'value'  => [
                        $this->formatNestedRawValue(Date::format($dateFormat, $saved_from), $after, $before),
                        $this->formatNestedRawValue(Date::format($dateFormat, $saved_to), $after, $before),
                    ],
                ], $after, $before);

            case MetaFieldModel::IMAGE_TYPE:
            case MetaFieldModel::AUDIO_TYPE:
            case MetaFieldModel::VIDEO_TYPE:
                if (!is_array($raw) || !isset($raw[CCTFieldShape::KEY_URL])) {
                    return null;
                }
                $id = !empty($raw[CCTFieldShape::KEY_ATTACHMENT_ID]) ? $raw[CCTFieldShape::KEY_ATTACHMENT_ID] : $raw[CCTFieldShape::KEY_URL];
                return $this->formatRawValue($this->getAttachment($id, $this->return), $after, $before);

            case MetaFieldModel::FILE_TYPE:
                if (!is_array($raw) || !isset($raw[CCTFieldShape::KEY_URL])) {
                    return null;
                }
                $id = !empty($raw[CCTFieldShape::KEY_ATTACHMENT_ID]) ? $raw[CCTFieldShape::KEY_ATTACHMENT_ID] : $raw[CCTFieldShape::KEY_URL];
                return $this->formatRawValue([
                    'file'  => $this->getAttachment($id, $this->return),
                    'label' => $this->formatNestedRawValue($raw['label'] ?? null, $after, $before),
                ], $after, $before);

            case MetaFieldModel::AUDIO_MULTI_TYPE:
            case MetaFieldModel::IMAGE_SLIDER_TYPE:
            case MetaFieldModel::GALLERY_TYPE:
            case MetaFieldModel::VIDEO_MULTI_TYPE:
                if (!is_array($raw)) {
                    return null;
                }
                $gallery = [];
                foreach ($raw as $item) {
                    if (!is_array($item) || !isset($item[CCTFieldShape::KEY_URL])) {
                        continue;
                    }
                    $id  = !empty($item[CCTFieldShape::KEY_ATTACHMENT_ID]) ? $item[CCTFieldShape::KEY_ATTACHMENT_ID] : $item[CCTFieldShape::KEY_URL];
                    $att = $this->getAttachment($id, $this->return);
                    if ($att !== null) {
                        $gallery[] = $att;
                    }
                }
                return $this->formatRawValue($gallery, $after, $before);

                // CCT stores {url, barcode_value}; no rendered SVG available
            case MetaFieldModel::BARCODE_TYPE:
                if (!is_array($raw) || !isset($raw[CCTFieldShape::KEY_BARCODE_VALUE])) {
                    return null;
                }
                return $this->formatRawValue([
                    'text'  => $raw[CCTFieldShape::KEY_BARCODE_VALUE],
                    'value' => $raw,
                ], $after, $before);

                // CCT stores {url, qr_code_value}; no rendered img available
            case MetaFieldModel::QR_CODE_TYPE:
                if (!is_array($raw) || !isset($raw[CCTFieldShape::KEY_QR_CODE_VALUE])) {
                    return null;
                }
                return $this->formatRawValue([
                    'url'   => $raw[CCTFieldShape::KEY_URL] ?? null,
                    'value' => $raw,
                ], $after, $before);

            case MetaFieldModel::POST_OBJECT_TYPE:
                return $this->formatRawValue($this->getPost($raw, $this->return), $after, $before);

            case MetaFieldModel::POST_OBJECT_MULTI_TYPE:
                $result = [];
                foreach ((array)$raw as $pid) {
                    $result[] = $this->getPost($pid, $this->return);
                }
                return $this->formatRawValue($result, $after, $before);

            case MetaFieldModel::TERM_OBJECT_TYPE:
                return $this->formatRawValue($this->getTerm($raw, $this->return), $after, $before);

            case MetaFieldModel::TERM_OBJECT_MULTI_TYPE:
                $result = [];
                foreach ((array)$raw as $tid) {
                    $result[] = $this->getTerm($tid, $this->return);
                }
                return $this->formatRawValue($result, $after, $before);

            case MetaFieldModel::USER_TYPE:
                return $this->formatRawValue($this->getUser($raw, $this->return), $after, $before);

            case MetaFieldModel::USER_MULTI_TYPE:
                $result = [];
                foreach ((array)$raw as $uid) {
                    $result[] = $this->getUser($uid, $this->return);
                }
                return $this->formatRawValue($result, $after, $before);

            case MetaFieldModel::TABLE_TYPE:
                return $this->formatRawValue($raw, $after, $before);

            case MetaFieldModel::TOGGLE_TYPE:
                return $this->formatRawValue($raw == 1, $after, $before);

            case MetaFieldModel::NUMBER_TYPE:
            case MetaFieldModel::RANGE_TYPE:
            case MetaFieldModel::RATING_TYPE:
                if (Numbers::isFloat($raw)) {
                    return $this->formatRawValue(floatval($raw), $after, $before);
                }
                if (Numbers::isInt($raw)) {
                    return $this->formatRawValue(intval($raw), $after, $before);
                }
                return $this->formatRawValue($raw, $after, $before);

            case MetaFieldModel::EDITOR_TYPE:
                return $this->formatRawValue(wpautop($raw), $after, $before);

            case MetaFieldModel::CHECKBOX_TYPE:
            case MetaFieldModel::SELECT_MULTI_TYPE:
            case MetaFieldModel::LIST_TYPE:
                $result = [];
                if (is_array($raw)) {
                    foreach ($raw as $v) {
                        $result[] = $this->formatNestedRawValue($v, $after, $before);
                    }
                }
                return $this->formatRawValue($result, $after, $before);

            default:
                if (!is_string($raw)) {
                    $raw = (string)$raw;
                }
                $allowHtml = $this->fieldModel->getAdvancedOption('allow_html');
                if ($allowHtml == 1) {
                    $raw = html_entity_decode($raw);
                }
                return $this->formatRawValue(WPUtils::renderShortCode($raw), $after, $before);
        }
    }
}
