<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Core\Repository\MetaKeyRepository;

class FetchMetaKeysQuery implements QueryInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $args = [];

    /**
     * @param array<string, mixed> $args
     */
    public function __construct(array $args = [])
    {
        $this->args = $args;
    }

    /**
     * @return array{count: int, records: array<int, mixed>}
     */
    public function execute(): array
    {
        return MetaKeyRepository::getMetaKeys($this->args);
    }
}
