<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Core\Helper\Features;
use ACPT\Core\Helper\Strings;
use ACPT\Utils\PHP\Date;
use Parsedown;

class FetchChangelogQuery implements QueryInterface
{
    /**
     * @var string
     */
    private string $filePath;

    /**
     * @param string|null $filePath
     */
    public function __construct(?string $filePath = null)
    {
        $this->filePath = $filePath ?? plugin_dir_path(__FILE__) . "../../../../changelog.md";
    }

    /**
     * @return array<string, mixed>
     */
    public function execute(): array
    {
        if (!file_exists($this->filePath)) {
            return [];
        }

        $versions = [];
        $md = file_get_contents($this->filePath);
        $Parsedown = new Parsedown();
        $html = $Parsedown->text($md);

        $dom = new \DOMDocument();
        $dom->loadHTML($html);

        // Snapshot the live NodeList before iterating — removing a node shifts the list
        // and causes subsequent elements to be skipped.
        $h2NodeList = $dom->getElementsByTagName("h2");
        $h2Elements = [];
        for ($i = 0; $i < $h2NodeList->length; $i++) {
            $h2Elements[] = $h2NodeList->item($i);
        }

        /** @var \DOMElement $title */
        foreach ($h2Elements as $title) {
            $version = explode(" - ", $title->textContent);

            if (count($version) !== 2) {
                continue;
            }

            $v = $version[0];
            $date = $version[1];

            if ($this->isEnabled($v)) {
                $idVersion = "id-".$v;
                $versions[] = [
                    'label' => $v,
                    'value' => $idVersion,
                ];

                $title->setAttribute('class', "changelog-section-header");
                $title->setAttribute('id', $idVersion);

                $spanVersion = $dom->createElement("span");
                $spanVersion->setAttribute('class', 'version');
                $spanVersion->textContent = $v;

                $spanDate = $dom->createElement("span");
                $spanDate->setAttribute('class', 'date');

                $dateFormat =  get_option('date_format') ?? "Y-m-d";
                $spanDate->textContent = Date::format($dateFormat, $date);

                $title->textContent = "";
                $title->appendChild($spanVersion);
                $title->appendChild($spanDate);
            } else {
                $this->removeAllTheContentUntilTheNextH2($title);
            }
        }

        $h3 = $dom->getElementsByTagName("h3");

        /** @var \DOMElement $title */
        foreach ($h3 as $title) {
            switch ($title->textContent) {

                default:
                case "Added":
                    $className = "added";
                    break;

                case "Changed":
                    $className = "changed";
                    break;

                case "Removed":
                    $className = "removed";
                    break;

                case "Security":
                    $className = "security";
                    break;

                case "Fixed":
                    $className = "fixed";
                    break;
            }

            $title->setAttribute("class", $className);
            $sibling = $title->nextSibling !== null ? $title->nextSibling->nextSibling : null;
            if ($sibling instanceof \DOMElement) {
                $sibling->setAttribute("class", $className);
            }
        }

        return [
            'versions' => $versions,
            'changelog' => $dom->saveHTML(),
        ];
    }

    /**
     * Determines whether the version is enabled based on the provided version number.
     *
     * @param string $version The version string used to determine the feature's status.
     * @return bool Returns true if the feature is enabled, false otherwise.
     */
    protected function isEnabled(string $version): bool
    {
        if (!Strings::contains("beta", $version)) {
            return true;
        }

        return Features::enableBeta();
    }

    /**
     * Removes the provided element and all subsequent sibling nodes up to (but not including) the next <h2>.
     *
     * @param \DOMElement $title The h2 element to be removed along with its following content.
     * @return void
     */
    private function removeAllTheContentUntilTheNextH2(\DOMElement $title): void
    {
        $parent = $title->parentNode;

        if ($parent === null) {
            return;
        }

        // collect this h2 and every following sibling before the next h2
        $nodesToRemove = [];
        $node = $title;
        while ($node !== null && !($node !== $title && $node->nodeName === 'h2')) {
            $nodesToRemove[] = $node;
            $node = $node->nextSibling;
        }

        foreach ($nodesToRemove as $nodeToRemove) {
            $parent->removeChild($nodeToRemove);
        }
    }
}
