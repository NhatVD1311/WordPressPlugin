<?php

namespace ACPT\Core\CQRS\Query;

use ACPT\Core\Helper\Features;
use ACPT\Core\Models\Meta\MetaGroupModel;
use ACPT\Core\Models\Meta\MetaGroupModelFactory;
use ACPT\Core\Repository\MetaRepository;
use ACPT\Core\Repository\TableGroupRepository;

class FetchMetaGroupsQuery implements QueryInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $args = [];

    /**
     * Constructor method.
     *
     * @param array<string, mixed> $args An array of arguments to initialize the object.
     * @return void
     */
    public function __construct(array $args = [])
    {
        $this->args = $args;
    }

    /**
     * Executes the process of retrieving and constructing meta groups.
     *
     * This method fetches meta groups from the MetaRepository based on the provided arguments.
     * Additionally, if the CCT feature is enabled, it processes table group data to incorporate
     * meta groups derived from tables, which are then appended to the result.
     *
     * @return MetaGroupModel[] An array of meta groups constructed from repository data and, if applicable, table group data.
     */
    public function execute(): array
    {
        // Strip cct — MetaRepository validates its args against a whitelist and rejects unknown keys.
        $metaArgs = array_diff_key($this->args, ['cct' => null]);
        $metaGroups = MetaRepository::get($metaArgs);

        // add meta group from CCT
        if (
            isset($this->args['cct']) &&
            $this->args['cct'] === true &&
            Features::hasCct()
        ) {
            // Only forward args that TableGroupRepository understands.
            // Pagination (page/perPage), sorting, and meta-specific keys must not bleed in.
            $cctArgs = array_intersect_key($this->args, array_flip(['belongsTo', 'find', 'search', 'postId']));

            $tables = [];
            foreach (TableGroupRepository::get($cctArgs) as $group) {
                foreach ($group->getTables() as $t) {
                    $tables[] = $t;
                }
            }

            foreach ($tables as $table) {
                if ($table->allowsMultipleRecordsPerHost()) {
                    // Handled exclusively by the multi-record export/import path
                    // (wpae_acpt_export_all_table_records() and friends) — never
                    // flattened into a single-record meta group here.
                    continue;
                }
                $metaGroups[] = MetaGroupModelFactory::fromTable($table, true);
            }
        }

        return $metaGroups;
    }
}
