<?php

use ACPT\Admin\ACPT_License_Manager;
use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Plugin;
use ACPT\Utils\PHP\Ini;
use ACPT\Utils\PHP\IP;

/**
 * Run the application in dev mode
 *
 * @return bool
 */
function devACPTMode(): bool
{
	if(!is_plugin_active( 'query-monitor/query-monitor.php' )){
		return false;
	}

	$devSites = [
        'http://localhost:8000',
        'http://localhost:10003',
    ];

	return in_array(site_url(), $devSites);
}

/**
 * Activate the license from credentials
 *
 * @param string $license
 */
function activateLicenseFromCredentials(string $license): void
{
    if(ACPT_License_Manager::isLicenseValid()){
        return;
    }

    if(defined('ACPT_DEV_MODE') and ACPT_DEV_MODE){
        return;
    }

    if(ACPT_License_Manager::isInLicenseCheckBackoff()){
        return;
    }

    if( !function_exists('wp_redirect') ) {
        include_once( ABSPATH . 'wp-includes/pluggable.php' );
    }

    $url = 'https://acpt.io/wp-json/api/v1/license/activate';
    $siteUrl = site_url();
    $siteName = get_bloginfo('name');
    $ip = IP::getClientIP();

    // Runs unconditionally on every request (front-end included) whenever
    // ACPT_LICENSE_KEY is defined, so this must never block for long —
    // set the backoff before attempting, regardless of outcome, so a
    // persistent failure retries at most once per BACKOFF_SECONDS instead
    // of on every single page load.
    ACPT_License_Manager::startLicenseCheckBackoff();

    $request = wp_remote_post($url, [
        'method'      => 'POST',
        'timeout'     => 5,
        'redirection' => 5,
        'httpversion' => '1.0',
        'body'        => [
            'license'  => $license,
            'siteUrl'  => $siteUrl,
            'siteName' => $siteName,
            'ip'       => $ip,
        ],
    ]);

    if ( is_wp_error( $request ) or ( 200 !== wp_remote_retrieve_response_code( $request ) ) ) {
        $error = 'There was a problem during the activation of the plugin via cURL. Please retry, in case the error persist, contact support to receive assistance.';
        wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME.'&error=' . urlencode($error));
        exit();
    }

    $response = json_decode( wp_remote_retrieve_body( $request ) );

    if(!isset($response->id)){
        $error = 'The cURL response was empty. Please retry, in case the error persist, contact support to receive assistance.';
        wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME.'&error=' . urlencode($error));
        exit();
    }

    $activate = ACPT_License_Manager::activateLicense(
        $response->id,
        $license,
        $siteName,
        $siteUrl,
        $response->user_email,
        $response->user_id,
    );

    if(!$activate){
        $error = 'The license was not activated. Please retry, in case the error persist, contact support to receive assistance.';
        wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME.'&error=' . urlencode($error));
        exit();
    }

    wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME);
    exit();
}

/**
 * Activate the license from token
 *
 * @param string $token
 */
function activateLicenseFromToken(string $token): void
{
    if(ACPT_License_Manager::isLicenseValid()){
        return;
    }

	if( !function_exists('wp_redirect') ) {
		include_once( ABSPATH . 'wp-includes/pluggable.php' );
	}

	$token = filter_var($token, FILTER_UNSAFE_RAW, FILTER_NULL_ON_FAILURE);

	// Fix for Complianz
	// Try to activate only token with a minimum length
	if($token and strlen($token) >= 155){
		try {
			ACPT_License_Manager::activateLicenseFromToken($token);
			wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME);
			exit();
		} catch (Exception $exception){
			$error = "An unexpected error occurs: ";
			$error .= $exception->getMessage();
			$error .= ' Please retry, in case the error persist, contact support to receive assistance.';
			wp_redirect(get_admin_url().'admin.php?page='.ACPT_PLUGIN_NAME.'&error=' . urlencode($error));
			exit();
		}
	}
}

/**
 * This function get the old version from the filemtime value of main plugin file
 *
 * @param int|string|null $old_version
 *
 * @return string|null
 */
function oldACPTPluginVersion($old_version): ?string
{
	if(empty($old_version) or $old_version == 0){
		return null;
	}

	if(!is_numeric($old_version)){
		return null;
	}

	$date = date("Y-m-d", $old_version);

	if($date == "1970-01-01"){
		return null;
	}

	$config = Ini::read(__DIR__.'/../config.ini');
	$pluginVersions = $config['versions'];

	return (isset(array_flip($pluginVersions)[$date])) ? array_flip($pluginVersions)[$date] : null;
}

/**
 * Check for plugin upgrades
 */
function checkForACPTPluginUpgrades(): void
{
	try {
		// | =====================================================|
		// | LEGACY FORMAT | get_option('acpt_version')           |
		// | =====================================================|
		// | NEW FORMAT    | get_option('acpt_current_version')   |
		// | =====================================================|

		$old_version = get_option('acpt_current_version') ?? get_option('acpt_version', 0);
		$current_version = get_option('acpt_current_version') ? ACPT_PLUGIN_VERSION : filemtime(__FILE__);

		if ($old_version != $current_version) {

			// Initialize cache before flushing, since ACPT_DB::$cache
			// has not been injected yet at this point in the boot sequence.
			// Without this, flushCache() silently does nothing because
			// self::$cache is still null, leaving stale serialized objects
			// from the previous plugin version in phpfastcache.
			ACPT_Plugin::setCache();
			$cache = ACPT_Plugin::getCache();
			if($cache !== null){
				ACPT_DB::injectCache($cache);
			}

			ACPT_DB::flushCache();
			delete_option('acpt_settings_cache');
			ACPT_DB::createSchema(ACPT_PLUGIN_VERSION, get_option('acpt_current_version') ?? oldACPTPluginVersion($old_version));
			ACPT_DB::sync();

			update_option('acpt_version', $current_version, true);
			update_option('acpt_current_version', ACPT_PLUGIN_VERSION, true);
		}

		// One-time backfill for ticket #1181: ID-type meta fields never got a value
		// unless a post was manually saved through wp-admin. Tracked separately from
		// the version bump above so it isn't re-scheduled on every future update once
		// it has succeeded (ACPT_Plugin::backfillMissingIdFieldValues() sets this
		// option itself once it finishes). Scheduled as a WP-Cron event rather than
		// run inline here: this function runs on every request until the version
		// bump above catches up, so whichever real visitor's page load happens to
		// trigger it must not be blocked by scanning every post on the site.
		if (!get_option('acpt_id_field_backfill_done', false) && !wp_next_scheduled('acpt/backfill_id_field_values')) {
			wp_schedule_single_event(time(), 'acpt/backfill_id_field_values');
		}

		// One-time migration: these 3 options used to be written with autoload='no',
		// forcing a dedicated SELECT per option on every request instead of folding
		// into WP's single bulk alloptions query. New writes now use autoload='yes';
		// this backfills existing rows, since update_option()'s autoload param is
		// ignored for pre-existing rows on WP < 6.6 (only add_option() reliably sets
		// autoload, hence delete+re-add rather than a raw autoload UPDATE).
		if (!get_option('acpt_autoload_migration_done', false)) {
			$autoloadMigrationKeys = [
				\ACPT\Utils\PHP\KeyEcrypt::ecrypt(\ACPT\Admin\ACPT_License_Manager::PRIVATE_KEY_NAME),
				'acpt_current_version',
				'acpt_id_field_backfill_done',
			];

			foreach ($autoloadMigrationKeys as $autoloadMigrationKey) {
				$autoloadMigrationValue = get_option($autoloadMigrationKey, false);

				if ($autoloadMigrationValue === false) {
					continue;
				}

				delete_option($autoloadMigrationKey);
				add_option($autoloadMigrationKey, $autoloadMigrationValue, '', 'yes');
			}

			add_option('acpt_autoload_migration_done', true, '', 'yes');
		}
	} catch (\Exception $exception){
		// do nothing
	}
}

/**
 * Checks whether tests are currently being executed in the environment.
 *
 * Not spoofable from a production HTTP request: PHPUNIT_ACPT_TEST_SUITE is only
 * ever defined by tests/_inc/bootstrap.php (loaded solely by the WP PHPUnit test
 * scaffold), and php_sapi_name() can't be influenced by request data — a normal
 * web request never satisfies both conditions.
 *
 * @return bool Returns true if tests are running, false otherwise.
 */
function testsAreRunning(): bool
{
    return (
        defined('PHPUNIT_ACPT_TEST_SUITE') &&
        PHPUNIT_ACPT_TEST_SUITE &&
        php_sapi_name() === 'cli'
    );
}
