<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class MigrateLocationDataToJunction extends ACPT_Schema_Migration
{
	/**
	 * @inheritDoc
	 */
	public function up(): array
	{
		ACPT_DB::startTransaction();

		try {
			$this->migrateLocationData();
		} catch (\Exception $exception) {
			ACPT_DB::rollbackTransaction();

			return [];
		}

		ACPT_DB::commitTransaction();

		return [];
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
		return '2.1.0-beta-1';
	}

	/**
	 * Migrate existing location_rule/location_value flat columns
	 * into the shared junction table, then drop the flat columns.
	 *
	 * @throws \Exception
	 */
	private function migrateLocationData(): void
	{
		global $wpdb;

		$tableTable = ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE);
		$junctionTable = ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_RECORD_LOCATION);

		// `acpt_table` no longer has a `location` column (removed by the
		// later "Introducing table groups" migration) — on a fresh install
		// it never existed at all, so it can't be used to pre-filter here.
		// Every table is checked below; ones without flat location_rule/
		// location_value columns are skipped there instead.
		$tables = ACPT_DB::getResults("SELECT table_name FROM `{$tableTable}`");

		if (empty($tables)) {
			return;
		}

		foreach ($tables as $table) {
			$prefixedName = ACPT_DB::prefixedTableName($table->table_name);

			if (!ACPT_DB::tableExists($prefixedName)) {
				continue;
			}

			// Check if the flat columns exist before migrating
			$columns = $wpdb->get_results("SHOW COLUMNS FROM `{$prefixedName}` LIKE 'location_rule'");

			if (empty($columns)) {
				continue;
			}

			// Copy existing data to junction table
			ACPT_DB::executeQueryOrThrowException(
				"INSERT IGNORE INTO `{$junctionTable}` (table_name, record_id, location_rule, location_value)
				SELECT %s, id, location_rule, location_value
				FROM `{$prefixedName}`
				WHERE location_rule IS NOT NULL",
				[$table->table_name]
			);

			// Drop the old index and columns
			$wpdb->query("ALTER TABLE `{$prefixedName}` DROP INDEX `idx_location`");
			$wpdb->query("ALTER TABLE `{$prefixedName}` DROP COLUMN `location_rule`, DROP COLUMN `location_value`");
		}
	}
}
