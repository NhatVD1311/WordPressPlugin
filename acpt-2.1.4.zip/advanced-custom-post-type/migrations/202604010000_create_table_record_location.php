<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class CreateTableRecordLocation extends ACPT_Schema_Migration
{
	/**
	 * @return array
	 */
	public function up(): array
	{
		return [
			"CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_RECORD_LOCATION)."` (
	            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	            table_name VARCHAR(64) NOT NULL,
	            record_id VARCHAR(36) NOT NULL,
	            location_rule TINYINT NOT NULL,
	            location_value VARCHAR(255) NULL DEFAULT NULL,
	            INDEX idx_table_record (table_name, record_id),
	            INDEX idx_table_location (table_name, location_rule, location_value),
	            UNIQUE KEY uq_record_location (table_name, location_rule, location_value)
	        ) ".ACPT_DB::getCharsetCollation().";",
		];
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_RECORD_LOCATION)),
		];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
		return '2.1.0-beta-1';
	}
}
