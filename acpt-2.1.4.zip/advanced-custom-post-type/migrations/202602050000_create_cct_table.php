<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class CreateCustomContentTypeTables extends ACPT_Schema_Migration
{
	/**
	 * @return array
	 */
	public function up(): array
	{
		return [
            "CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_GROUP)."` (
	            id VARCHAR(36) UNIQUE NOT NULL,
	            group_name VARCHAR(64) UNIQUE NOT NULL,
	            group_label VARCHAR(255) NOT NULL,
	            display VARCHAR(55) DEFAULT NULL,
	            context VARCHAR(36) DEFAULT NULL,
	            priority VARCHAR(36) DEFAULT NULL,
	            location JSON DEFAULT NULL,
                sort INT(11),
	            PRIMARY KEY(id)
	        ) ".ACPT_DB::getCharsetCollation().";",
			"CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)."` (
	            id VARCHAR(36) UNIQUE NOT NULL,
	            table_group_id VARCHAR(64) NULL,
	            table_name VARCHAR(64) UNIQUE NOT NULL,
	            table_label VARCHAR(255) NOT NULL,
	            id_strategy VARCHAR(20) NOT NULL,
	            icon TEXT NOT NULL,
	            rest_api VARCHAR(64) DEFAULT NULL,
	            menu_position INT(11),
	            capability VARCHAR(64) NOT NULL,
	            charset_collate VARCHAR(64) NOT NULL,
	            timestamps TINYINT(1) NOT NULL,
	            soft_delete TINYINT(1) NOT NULL,
	            table_options TEXT DEFAULT NULL,
                sort INT(11),
	            PRIMARY KEY(id)
	        ) ".ACPT_DB::getCharsetCollation().";",
            "CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_COLUMN)."` (
	            id VARCHAR(36) UNIQUE NOT NULL,
	            table_id VARCHAR(36) NOT NULL,
	            column_name VARCHAR(64) NOT NULL,
	            column_label VARCHAR(255) NOT NULL,
	            column_type VARCHAR(36) DEFAULT NULL,
	            column_length VARCHAR(10) DEFAULT NULL,
	            default_value TEXT DEFAULT NULL,
	            description TEXT DEFAULT NULL,
	            is_nullable TINYINT(1) NOT NULL,
	            is_unique TINYINT(1) NOT NULL,
	            primary_key TINYINT(1) NOT NULL,
	            column_values TEXT DEFAULT NULL,
	            column_options TEXT DEFAULT NULL,
	            ui JSON DEFAULT NULL,
	            validation_rules JSON DEFAULT NULL,
	            visibility_rules JSON DEFAULT NULL,
	            permission_rules JSON DEFAULT NULL,
	            sort INT(11),
	            PRIMARY KEY(id)
	        ) ".ACPT_DB::getCharsetCollation().";",
            "CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_INDEX)."` (
	            id VARCHAR(36) UNIQUE NOT NULL,
	            table_id VARCHAR(36) NOT NULL,
	            index_name VARCHAR(64) NOT NULL,
	            index_strategy VARCHAR(36) NOT NULL,
	            index_type VARCHAR(5) DEFAULT NULL,
	            index_algorithm VARCHAR(10) DEFAULT NULL,
	            index_lock VARCHAR(10) DEFAULT NULL,
	            index_options TEXT DEFAULT NULL,
	            index_key_parts TEXT DEFAULT NULL,
	            sort INT(11),
	            PRIMARY KEY(id)
	        ) ".ACPT_DB::getCharsetCollation().";",
            "CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_KEY)."` (
	            id VARCHAR(36) UNIQUE NOT NULL,
	            table_id VARCHAR(36) NOT NULL,
	            key_name VARCHAR(64) NOT NULL,
	            key_columns TEXT DEFAULT NULL,
	            reference_table_id VARCHAR(36) NOT NULL,
	            reference_columns TEXT DEFAULT NULL,
	            on_update VARCHAR(12) DEFAULT NULL,
	            on_cascade VARCHAR(12) DEFAULT NULL,
	            sort INT(11),
	            PRIMARY KEY(id)
	        ) ".ACPT_DB::getCharsetCollation().";",
		];
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_GROUP)),
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)),
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_COLUMN)),
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_INDEX)),
			$this->deleteTableQuery(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_KEY)),
		];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
		return '2.1.0-beta-1';
	}
}




