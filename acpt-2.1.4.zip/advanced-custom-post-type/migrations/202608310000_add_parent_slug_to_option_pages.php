<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class AddParentSlugToOptionPages extends ACPT_Schema_Migration
{
	/**
	 * @inheritDoc
	 */
	public function up(): array
	{
        $queries = [];

        if(!ACPT_DB::checkIfColumnExistsInTable(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_OPTION_PAGE), 'parent_slug')){
            $queries[] = "ALTER TABLE `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_OPTION_PAGE)."` ADD `parent_slug` VARCHAR(255) DEFAULT NULL";
        }

        return $queries;
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [
            "ALTER TABLE `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_OPTION_PAGE)."` DROP COLUMN `parent_slug` ",
        ];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
        return '2.1.0';
	}
}
