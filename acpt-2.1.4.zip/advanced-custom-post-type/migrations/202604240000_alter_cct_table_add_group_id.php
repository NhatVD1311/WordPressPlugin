<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class AlterCctTableAddGroupId extends ACPT_Schema_Migration
{
	/**
	 * @inheritDoc
	 */
	public function up(): array
	{
		$queries = [];

		// Create the table_group table if it wasn't created by an earlier migration
		$queries[] = "CREATE TABLE IF NOT EXISTS `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_GROUP)."` (
		    id VARCHAR(36) UNIQUE NOT NULL,
		    group_name VARCHAR(64) UNIQUE NOT NULL,
		    group_label VARCHAR(255) NOT NULL,
		    display VARCHAR(55) DEFAULT NULL,
		    context VARCHAR(36) DEFAULT NULL,
		    priority VARCHAR(36) DEFAULT NULL,
		    location JSON DEFAULT NULL,
            sort INT(11),
		    PRIMARY KEY(id)
		) ".ACPT_DB::getCharsetCollation().";";

		// Add table_group_id to acpt_table if the column is missing
		if (
			ACPT_DB::tableExists(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)) &&
			!ACPT_DB::checkIfColumnExistsInTable(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE), 'table_group_id')
		) {
			$queries[] = "ALTER TABLE `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)."` ADD COLUMN `table_group_id` VARCHAR(64) NULL";
		}

		return $queries;
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
		return '2.1.0-beta-1';
	}
}
