<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

/**
 * Widens uq_record_location to include record_id, matching the 4-column
 * definition ACPT_Schema.php has declared since 2026-04-01 (commit 295310c58).
 *
 * The original CREATE TABLE migration (202604010000_create_table_record_location.php)
 * shipped with only the 3-column form `(table_name, location_rule, location_value)`.
 * Because `CREATE TABLE IF NOT EXISTS` never alters an already-existing table, every
 * install created before this fix is permanently stuck enforcing at most one record
 * per (table_name, location_rule, location_value) — which silently makes it impossible
 * for any CCT table flagged `allow_multiple_records_per_host` to ever hold more than
 * one record per host, regardless of the application-level flag.
 */
class AlterTableRecordLocationUniqueKey extends ACPT_Schema_Migration
{
    /**
     * @inheritDoc
     */
    public function up(): array
    {
        $table = ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_RECORD_LOCATION);

        if (!ACPT_DB::tableExists($table)) {
            return [];
        }

        if ($this->uniqueKeyAlreadyIncludesRecordId($table)) {
            return [];
        }

        return [
            "ALTER TABLE `{$table}` DROP INDEX `uq_record_location`, ADD UNIQUE KEY `uq_record_location` (table_name, record_id, location_rule, location_value)",
        ];
    }

    /**
     * @inheritDoc
     */
    public function down(): array
    {
        $table = ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE_RECORD_LOCATION);

        return [
            "ALTER TABLE `{$table}` DROP INDEX `uq_record_location`, ADD UNIQUE KEY `uq_record_location` (table_name, location_rule, location_value)",
        ];
    }

    /**
     * @inheritDoc
     */
    public function version(): string
    {
        return '2.1.0-beta-3';
    }

    private function uniqueKeyAlreadyIncludesRecordId(string $table): bool
    {
        global $wpdb;

        $columns = $wpdb->get_col($wpdb->prepare(
            "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = 'uq_record_location'",
            $table
        ));

        return in_array('record_id', $columns, true);
    }
}
