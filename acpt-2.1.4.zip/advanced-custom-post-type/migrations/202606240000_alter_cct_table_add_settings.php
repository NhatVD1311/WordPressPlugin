<?php

use ACPT\Includes\ACPT_DB;
use ACPT\Includes\ACPT_Schema_Migration;

class AlterCctTableAddSettings extends ACPT_Schema_Migration
{
	/**
	 * @inheritDoc
	 */
	public function up(): array
	{
        $queries = [];

        if(!ACPT_DB::checkIfColumnExistsInTable(ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE), 'settings')){
            $queries[] = "ALTER TABLE `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)."` ADD `settings` TEXT DEFAULT NULL";
        }

        return $queries;
	}

	/**
	 * @inheritDoc
	 */
	public function down(): array
	{
		return [
            "ALTER TABLE `".ACPT_DB::prefixedTableName(ACPT_DB::TABLE_TABLE)."` DROP COLUMN `settings` ",
        ];
	}

	/**
	 * @inheritDoc
	 */
	public function version(): string
	{
        return '2.1.0-beta-3';
	}
}
