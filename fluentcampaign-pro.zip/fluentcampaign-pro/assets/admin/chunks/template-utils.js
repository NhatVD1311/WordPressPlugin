function o(r){return[...r].sort((e,t)=>{const n=e.is_current_provider===!1?1:0,s=t.is_current_provider===!1?1:0;return n-s})}export{o as s};
