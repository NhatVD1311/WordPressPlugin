<?php defined('ABSPATH') or die;

/**
 * Plugin Name: FluentCRM Pro
 * Description: Pro Email Automation and Integration Addon for FluentCRM
 * Version: 3.2.0
 * Author: Fluent CRM
 * Author URI: https://fluentcrm.com
 * Plugin URI: https://fluentcrm.com
 * License: GPLv2 or later
 * Text Domain: fluentcampaign-pro
 * Domain Path: /language
 */

define('FLUENTCAMPAIGN_DIR_FILE', __FILE__);
define('FLUENTCAMPAIGN_PLUGIN_PATH', plugin_dir_path(__FILE__));

define('FLUENTCAMPAIGN', 'fluentcampaign');
define('FLUENTCAMPAIGN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FLUENTCAMPAIGN_PLUGIN_VERSION', '3.2.0');
define('FLUENTCAMPAIGN_CORE_MIN_VERSION', '3.2.0');
define('FLUENTCAMPAIGN_FRAMEWORK_VERSION', 3);

update_option('__fluentcrm_campaign_license', [
'license_key' => 'gpldo00000000005603B1EBE59708542',
    'status' => 'valid',
    'variation_id' => '1',
    'variation_title' => 'Lifetime',
    'expires' => '2099-12-31 23:59:59',
'activation_hash' => md5('gpldo00000000005603B1EBE59708542' . home_url())
], false);

add_filter('pre_http_request', function($preempt, $args, $url) {
    if (strpos($url, 'fluentapi.wpmanageninja.com') !== false && strpos($url, 'fluent-cart') !== false) {
        return [
            'response' => ['code' => 200, 'message' => 'OK'],
            'body' => json_encode([
                'status' => 'valid',
                'variation_id' => '1',
                'variation_title' => 'Lifetime',
                'expiration_date' => '2099-12-31 23:59:59',
'activation_hash' => md5('gpldo00000000005603B1EBE59708542' . home_url()),
                'is_expired' => false
            ])
        ];
    }
    return $preempt;
}, 10, 3);

/*
 * Defined by FluentCRM core (or by an MU plugin that overrides it). Redefined here only
 * as a safety net for the case where Pro gets loaded before/without an up to date core.
 */
if (!defined('FLUENTCRM_EXTERNAL_URL_PARAM')) {
    define('FLUENTCRM_EXTERNAL_URL_PARAM', 'fluentcrm');
}

require __DIR__ . '/vendor/autoload.php';

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
