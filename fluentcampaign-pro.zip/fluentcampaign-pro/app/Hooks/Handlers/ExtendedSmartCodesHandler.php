<?php

namespace FluentCampaign\App\Hooks\Handlers;


use FluentCrm\App\Models\Subscriber;

class ExtendedSmartCodesHandler
{
    public function register()
    {
        add_filter('fluent_crm/smartcode_groups', array($this, 'pushUserCodes'));
        add_filter('fluent_crm/smartcode_group_callback_wp_user', array($this, 'parseUserSmartCode'), 10, 4);
    }

    public function pushUserCodes($codes)
    {
        $codes[] = [
            'key'        => 'wp_user',
            'title'      => 'WP User',
            'shortcodes' => [
                '{{wp_user.display_name}}'        => __('User\'s Display Name', 'fluentcampaign-pro'),
                '{{wp_user.user_login}}'          => __('User Login (username)', 'fluentcampaign-pro'),
                '##wp_user.password_reset_url## ' => __('Password Reset URL (on button / link)', 'fluentcampaign-pro'),
                '{{wp_user.password_reset_url}} ' => __('Password Reset URL (as plain text)', 'fluentcampaign-pro'),
                '{{wp_user.meta.META_KEY}}'       => __('User Meta Data', 'fluentcampaign-pro'),
            ]
        ];

        return $codes;
    }

    public function parseUserSmartCode($code, $valueKey, $defaultValue, $subscriber)
    {
        $wpUser = $subscriber->getWpUser();

        if (!$wpUser || !$subscriber->email || strtolower($subscriber->email) !== strtolower($wpUser->user_email)) {
            return $defaultValue;
        }

        $userKeys = [
            'ID',
            'user_login',
            'user_nicename',
            'user_url',
            'user_registered',
            'display_name'
        ];

        if (in_array($valueKey, $userKeys)) {
            return $wpUser->{$valueKey};
        }

        if (strpos($valueKey, 'meta.') === 0) {
            $metaKey = substr($valueKey, 5);
            $blockedMetaKeys = [
                'application_passwords', 'capabilities', 'session_tokens',
                'user_activation_key', 'user_pass', 'user_level',
                'wp_capabilities', 'wp_user_level'
            ];

            if (!$metaKey
                || in_array(strtolower($metaKey), $blockedMetaKeys, true)
                || substr($metaKey, -13) === '_capabilities'
                || substr($metaKey, -11) === '_user_level'
            ) {
                return $defaultValue;
            }

            $metaValue = get_user_meta($wpUser->ID, $metaKey, true);
            return is_scalar($metaValue) && $metaValue !== '' ? $metaValue : $defaultValue;
        }

        if ($valueKey == 'password_reset_url') {

            if (defined('FLUENTCRM_PREVIEWING_EMAIL') || user_can($wpUser, 'manage_options')) {
                return '#password_reset_link_will_be_inserted_on_real_email';
            }

            static $linkCache = [];
            if (isset($linkCache[$wpUser->ID])) {
                return $linkCache[$wpUser->ID];
            }

            $key = get_password_reset_key($wpUser);
            if (is_wp_error($key)) {
                return wp_lostpassword_url();
            }

            $linkCache[$wpUser->ID] = network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($wpUser->user_login), 'login') . '&wp_lang=' . get_user_locale($wpUser);
            return $linkCache[$wpUser->ID];
        }

        return $defaultValue;
    }
}
