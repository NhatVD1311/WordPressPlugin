<?php

namespace FluentCampaign\App\Http\Policies;

use FluentCrm\App\Http\Policies\BasePolicy;
use FluentCrm\Framework\Http\Request\Request;

class SequencePolicy extends BasePolicy
{
    /**
     * Check user permission for any method
     * @param  Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        if($this->requestMethod($request) == 'GET') {
            return $this->currentUserCan('fcrm_read_emails');
        }

        return $this->currentUserCan('fcrm_manage_emails');
    }

    public function delete(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    public function deleteSubscribes(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    /**
     * Authorize recurring row deletion with the independent email delete capability.
     *
     * @param Request $request
     * @return bool
     */

    public function deleteBulk(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    /**
     * Authorize Sequence bulk deletion through its fixed delete capability.
     *
     * @param Request $request
     * @return bool
     */
    public function handleSequenceBulkDelete(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    /**
     * Authorize recurring bulk actions without changing the sequence bulk contract.
     *
     * @param Request $request
     * @return bool
     */
    public function handleRecurringBulkAction(Request $request)
    {
        $actionName = $request->getSafe('action_name', 'sanitize_text_field', '');

        if ($actionName === 'apply_labels') {
            return $this->currentUserCan('fcrm_manage_emails');
        }

        if ($actionName === 'delete_campaigns') {
            return $this->currentUserCan('fcrm_manage_email_delete');
        }

        return false;
    }
}
