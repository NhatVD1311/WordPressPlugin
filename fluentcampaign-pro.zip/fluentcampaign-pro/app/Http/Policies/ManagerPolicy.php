<?php

namespace FluentCampaign\App\Http\Policies;

use FluentCrm\App\Http\Policies\BasePolicy;
use FluentCrm\Framework\Http\Request\Request;

class ManagerPolicy extends BasePolicy
{
    /**
     * Restrict CRM manager administration to WordPress administrators.
     *
     * @param Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_settings') && current_user_can('manage_options');
    }
}
