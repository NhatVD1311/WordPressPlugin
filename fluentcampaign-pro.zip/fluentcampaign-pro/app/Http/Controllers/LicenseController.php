<?php

namespace FluentCampaign\App\Http\Controllers;

use FluentCampaign\App\Services\PluginManager\FluentLicensing;
use FluentCampaign\App\Http\Controllers\Controller;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Support\Arr;

/**
 * The three endpoints the license screen talks to.
 *
 * Everything the UI shows is resolved here rather than in JavaScript, for two
 * reasons: dates have to be formatted in the site's timezone and locale, which
 * only PHP knows, and the raw license key must never reach the browser.
 *
 * The license screen lives in FluentCRM core (free), which customers update on
 * a different schedule to Pro. So this response only ever gains fields, never
 * renames them: an older core screen reads `status`, `expires` and the masked
 * `license_key`, and all three are still here alongside the newer
 * `license_key_masked` / `expires_human` / `in_grace_period`.
 */
class LicenseController extends Controller
{
    /** Mask character, matching FluentLicensing::getMaskedLicenseKey(). */
    const MASK_CHAR = "\u{2022}";

    public function getStatus(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            return [
                'status'   => $data->get_error_code(),
                'error'    => true,
                'message'  => $data->get_error_message(),
                // Retained: older core screens read this misspelling.
                'mnessage' => $data->get_error_message(),
            ];
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    public function saveLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();
        $licenseKey = sanitize_text_field($request->get('license_key'));

        $response = $licenseManager->activate($licenseKey);
        if (is_wp_error($response)) {
            return $this->sendError([
                'message'         => $response->get_error_message(),
                'remote_response' => $response,
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully updated', 'fluentcampaign-pro')
        ];
    }

    public function deactivateLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();
        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully deactivated', 'fluentcampaign-pro')
        ];
    }

    /**
     * Shape the stored license data for the license screen: everything the UI
     * shows is resolved here so the Vue side only has to render it.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = Arr::get($data, 'status', 'unregistered');
        $expires = Arr::get($data, 'expires', '');
        $isLifetime = $expires === 'lifetime';

        if (empty($data['renew_url']) && in_array($status, ['expired', 'valid'], true)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');

        // Prefer the manager's mask so every plugin renders keys the same way,
        // but fall back to masking the key we were actually handed. The manager
        // re-reads the stored option, and the deactivate response is shaped from
        // data whose option has just been deleted - without the fallback that
        // response would carry an empty key field.
        $maskedKey = $licenseManager->getMaskedLicenseKey();

        if (!$maskedKey && !empty($data['license_key'])) {
            $maskedKey = $this->maskLicenseKey($data['license_key']);
        }

        $data['license_key_masked'] = $maskedKey;

        if (!empty($data['customer_email_masked'])) {
            $data['customer_email_masked'] = $this->maskEmailDomain($data['customer_email_masked']);
        }
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = (int)Arr::get($data, 'grace_period_days', 0);
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        if (!empty($data['last_checked']) && $lastChecked = strtotime($data['last_checked'])) {
            $data['last_checked_human'] = sprintf(
            /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluentcampaign-pro'),
                human_time_diff($lastChecked)
            );
        }

        // The activation hash is a credential of its own and has no business in
        // the browser. `license_key` stays, but masked: the license screen that
        // ships in older FluentCRM cores renders that field directly, so
        // dropping it would blank the key out for anyone who updates Pro first.
        unset($data['activation_hash']);

        if (!empty($data['license_key'])) {
            $data['license_key'] = $maskedKey;
        }

        return $data;
    }

    /**
     * The store masks the local part of the customer address but returns the
     * domain intact. Mask that too, here rather than in the screen, so the real
     * domain never reaches the browser at all.
     *
     * The TLD is kept so the address still reads as an address, and a domain the
     * store already masked is left alone rather than masked twice.
     *
     * @param string $maskedEmail address as the store reported it
     * @return string
     */
    protected function maskEmailDomain($maskedEmail)
    {
        $at = strrpos($maskedEmail, '@');

        if ($at === false) {
            return $maskedEmail;
        }

        $local = substr($maskedEmail, 0, $at + 1);
        $domain = substr($maskedEmail, $at + 1);
        $dot = strpos($domain, '.');

        // No dot means nothing to keep on the right, so there is no partial
        // mask worth building - leave whatever the store sent.
        if ($dot === false || $dot === 0) {
            return $maskedEmail;
        }

        $label = substr($domain, 0, $dot);
        $suffix = substr($domain, $dot);

        if (strlen($label) < 2 || strpos($label, self::MASK_CHAR) !== false) {
            return $maskedEmail;
        }

        return $local . substr($label, 0, 1) . str_repeat(self::MASK_CHAR, strlen($label) - 1) . $suffix;
    }

    /**
     * Mirrors FluentLicensing::getMaskedLicenseKey() for the case where the
     * stored option is already gone but the key is still in hand.
     *
     * @param string $licenseKey
     * @return string
     */
    protected function maskLicenseKey($licenseKey)
    {
        $length = strlen($licenseKey);

        if ($length <= 8) {
            return str_repeat('•', $length);
        }

        return substr($licenseKey, 0, 4) . str_repeat('•', min($length - 8, 20)) . substr($licenseKey, -4);
    }

    /**
     * The store keeps a license usable for a grace window after its expiry date,
     * so a renewal that lands a few days late never breaks a live site. It
     * reports that window as a plain "valid" status without saying why, which
     * reads as a contradiction on screen: an Active badge sitting next to an
     * expiry date that has already passed. Resolve the window here so the screen
     * can name it.
     *
     * Only the fact of the window is reported, never its end date: the length
     * below is our assumption about the store's default, so a date built on it
     * would be a promise we cannot keep if the store ever filters it.
     *
     * @param array $data
     * @param int $expiresAt
     * @param string $status
     * @param int $remoteGraceDays grace length the store reported, 0 when it reported none
     * @return array
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        // Prefer the store's own number when it reports one; the fallback below
        // only mirrors its current default, and the store may filter it.
        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            $graceDays = (int)apply_filters('fluent_crm/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data; // Window already closed - the store will report it expired.
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }
}
