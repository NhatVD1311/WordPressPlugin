<?php if (!apply_filters('fluent_crm/disable_newsletter_archive_css', false)): ?>
    <style type="text/css">
        .fc_newsletter_single .fc_newsletter_single_back_btn {
            margin-bottom: 10px;
        }
        .fc_newsletter_single .fc_newsletter_single_back_btn a {
            display: inline-block;
            position: relative;
            font-size: 14px;
            text-decoration: underline;
            transition: .3s;
            -webkit-transition: .3s;
        }
        .fc_newsletter_single .fc_newsletter_single_back_btn a:hover {
            padding-left: 16px;
        }
        .fc_newsletter_single .fc_newsletter_single_back_btn a:hover .icon {
            opacity: 1;
        }
        .fc_newsletter_single .fc_newsletter_single_back_btn a .icon {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            transition: .3s;
            -webkit-transition: .3s;
        }
        .fc_newsletter_single .fc_newsletter_body {
            overflow: hidden;
            display: block;
            width: 100%;
            clear: both;
        }

        .fc_newsletter_single .fc_newsletter_head {
            border-bottom: solid 10px #f5f5f5;
            padding-bottom: 10px;
            font-weight: 700;
            letter-spacing: -1px;
            margin-bottom: 20px;
        }

        .fc_newsletter_single h1.fc_newsletter_title {
            margin-bottom: 0;
            padding: 0;
        }

        .fc_newsletter_single .fc_newsletter_head time {
            font-size: 12px;
            color: #888;
        }
    </style>
<?php endif; ?>
<?php
/*
 * @var array $newsletter array of newsletters as formatted
 * @var collections $campaign Campaign Model
 */
do_action('fluent_crm/before_newsletter_single', $newsletter, $campaign);
?>
<div class="fc_newsletter_single">
    <div class="fc_newsletter_single_back_btn">
        <a href="<?php echo esc_url($newsletter['permalink']); ?>"><span class="icon">⭠</span> <?php esc_html_e('Back to Campaigns', 'fluentcampaign-pro'); ?></a>
    </div>
    <div class="fc_newsletter_head">
        <time datetime="<?php echo esc_attr($newsletter['date_time']); ?>"
              class="fc_email_time"><?php echo esc_html($newsletter['formatted_date']); ?></time>
        <h1 class="fc_newsletter_title" itemprop="headline"><?php echo esc_html($newsletter['title']); ?></h1>
    </div>
    <div id="fluent_email_body" class="fc_newsletter_body"></div>
</div>
<?php do_action('fluent_crm/after_newsletter_single', $newsletter, $campaign); ?>
<?php
$domPurifyAsset = FLUENTCRM_PLUGIN_PATH . 'assets/libs/purify/purify.min.js';
$domPurifyVersion = file_exists($domPurifyAsset) ? (string) filemtime($domPurifyAsset) : FLUENTCAMPAIGN_PLUGIN_VERSION;
wp_enqueue_script('fluentcrm_newsletter_archive_dompurify', fluentCrmMix('libs/purify/purify.min.js'), [], $domPurifyVersion, true);

$newsletterData = wp_json_encode(
    ['rendered' => $newsletter['content']],
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
wp_add_inline_script('fluentcrm_newsletter_archive_dompurify', 'window.fluentCrmNewsletter = ' . $newsletterData . ';', 'before');

$newsletterScript = <<<'JS'
(function () {
    var data = window.fluentCrmNewsletter;
    if (!data || !data.rendered) {
        return;
    }

    var host = document.getElementById('fluent_email_body');
    if (!host || typeof host.attachShadow !== 'function' || typeof window.DOMPurify === 'undefined') {
        return;
    }

    var parseDocument = function (html) {
        if (typeof window.DOMParser !== 'function') {
            return null;
        }
        return (new window.DOMParser()).parseFromString(html || '', 'text/html');
    };

    var hasRel = function (link, relName) {
        return (' ' + (link.getAttribute('rel') || '').toLowerCase() + ' ').indexOf(' ' + relName + ' ') !== -1;
    };

    var isSafeBunnyFontLink = function (link) {
        var href = link.getAttribute('href') || '';
        try {
            var url = new URL(href, window.location.href);
            if (url.protocol !== 'https:' || url.hostname !== 'fonts.bunny.net') {
                return false;
            }
            return (hasRel(link, 'stylesheet') && url.pathname.indexOf('/css') === 0) || hasRel(link, 'preconnect');
        } catch (e) {
            return false;
        }
    };

    var appendSafeFontLinks = function (sourceDocument) {
        if (!sourceDocument || !sourceDocument.head) {
            return;
        }
        Array.prototype.forEach.call(sourceDocument.head.querySelectorAll('link[href]'), function (link) {
            if (!isSafeBunnyFontLink(link)) {
                return;
            }
            var href = link.href;
            var rel = hasRel(link, 'preconnect') ? 'preconnect' : 'stylesheet';
            var alreadyLoaded = Array.prototype.some.call(
                document.head.querySelectorAll('link[data-fcrm-newsletter-font]'),
                function (existing) {
                    return existing.href === href && existing.rel === rel;
                }
            );
            if (alreadyLoaded) {
                return;
            }
            var fontLink = document.createElement('link');
            fontLink.setAttribute('data-fcrm-newsletter-font', '1');
            fontLink.rel = rel;
            fontLink.href = href;
            if (link.hasAttribute('crossorigin')) {
                fontLink.crossOrigin = 'anonymous';
            }
            document.head.appendChild(fontLink);
        });
    };

    var appendHeadStyles = function (sourceRoot, target) {
        var sourceHead = sourceRoot && sourceRoot.querySelector ? sourceRoot.querySelector('head') : null;
        if (!sourceHead) {
            return;
        }
        Array.prototype.forEach.call(sourceHead.querySelectorAll('style'), function (style) {
            target.appendChild(style.cloneNode(true));
        });
    };

    var appendBody = function (sourceRoot, target) {
        var sourceBody = sourceRoot && sourceRoot.querySelector ? sourceRoot.querySelector('body') : null;
        var body = document.createElement('body');
        body.className = 'fcrm_email_document' + (sourceBody && sourceBody.className ? ' ' + sourceBody.className : '');
        ['dir', 'lang', 'style'].forEach(function (attribute) {
            if (sourceBody && sourceBody.hasAttribute(attribute)) {
                body.setAttribute(attribute, sourceBody.getAttribute(attribute));
            }
        });
        Array.prototype.forEach.call(sourceBody ? sourceBody.childNodes : [], function (child) {
            body.appendChild(child.cloneNode(true));
        });
        target.appendChild(body);
    };

    appendSafeFontLinks(parseDocument(data.rendered));
    var cleanRoot = window.DOMPurify.sanitize(data.rendered, {
        WHOLE_DOCUMENT: true,
        RETURN_DOM: true,
        USE_PROFILES: { html: true, svg: true, svgFilters: true },
        ADD_TAGS: ['style'],
        ADD_ATTR: ['target']
    });
    if (!cleanRoot || cleanRoot.nodeType !== 1 || !cleanRoot.querySelector) {
        return;
    }

    var shadowDom = host.attachShadow({ mode: 'closed' });
    var wrapper = document.createElement('div');
    var reset = document.createElement('style');
    reset.textContent = 'body.fcrm_email_document{display:block;margin:0;}';
    wrapper.appendChild(reset);
    appendHeadStyles(cleanRoot, wrapper);
    appendBody(cleanRoot, wrapper);
    shadowDom.appendChild(wrapper);
})();
JS;

wp_add_inline_script('fluentcrm_newsletter_archive_dompurify', $newsletterScript);
