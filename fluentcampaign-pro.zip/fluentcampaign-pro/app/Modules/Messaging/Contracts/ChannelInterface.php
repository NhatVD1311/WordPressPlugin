<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * A messaging channel (SMS, WhatsApp, ...).
 *
 * The kernel — scheduler, campaign model, queue — never names a channel. It asks
 * the registry for the channel a message belongs to and then asks the channel
 * everything it needs to know: how to render a message body, and how to send it.
 *
 * Consent is deliberately not one of those questions. It lives on the
 * conversation thread, per number and per channel, so every channel answers it
 * the same way and the kernel asks MessageThread rather than the channel.
 *
 * @see \FluentCampaign\App\Modules\Messaging\Models\MessageThread::contactCanReceive()
 *
 * Channels are registered in MessageModule::register() and are always registered
 * regardless of whether they are active, so settings screens can configure a
 * channel before it is switched on. Use isActive() to gate behaviour, never the
 * presence of the channel in the registry.
 *
 * @see \FluentCampaign\App\Modules\Messaging\MessageModule::channel()
 */
interface ChannelInterface
{
    /**
     * Stable identifier, and the value stored in the `channel` column of
     * fc_sms_campaigns and fc_message_threads. e.g. 'sms', 'whatsapp'.
     */
    public function getSlug(): string;

    /**
     * Human-readable name, used in UI labels, debug logs and failure notes.
     */
    public function getLabel(): string;

    /**
     * Whether the site has this channel configured and switched on. Channels
     * activate independently of one another.
     */
    public function isActive(): bool;

    /**
     * Maximum body length the channel accepts, in characters.
     */
    public function getMaxLength(): int;

    /**
     * Render a stored message body for one subscriber, resolving smartcodes.
     *
     * @param string $content    Raw body as stored on the campaign or message
     * @param object $subscriber FluentCrm\App\Models\Subscriber
     */
    public function parseMessageContent(string $content, $subscriber): string;

    /**
     * Dispatch a message through this channel's configured provider.
     *
     * @param string      $to       E.164 formatted phone number
     * @param string      $message  Rendered body
     * @param string|null $provider Provider slug; null uses the configured one
     *
     * @return array {status: 'success'|'error', status_code: int,
     *                message: string, response: mixed,
     *                provider_message_id?: string}
     */
    public function send(string $to, string $message, ?string $provider = null): array;

    /**
     * Send one queued message row, choosing the channel's message form.
     *
     * This is what the scheduler calls. It exists so mode selection lives in
     * the channel rather than the kernel: SMS always renders the stored body
     * and sends it, while WhatsApp must decide between a pre-approved template
     * (required outside Meta's 24-hour customer-service window) and free-form
     * text. The kernel stays channel-agnostic either way.
     *
     * Implementations must not throw for an undeliverable message — return the
     * standard error shape with a human-readable `message` so the scheduler can
     * record it as the failure note.
     *
     * The message is a \FluentCampaign\App\Modules\Messaging\Models\Message — a row in fc_messages,
     * on the thread it belongs to. Anything identifying who it is for lives on
     * that thread, and anything the columns have no home for (template id,
     * template variables, provider error) lives in its serialized `meta`.
     *
     * @param object $message    fc_messages row (Message model), thread loaded
     * @param object $subscriber \FluentCrm\App\Models\Subscriber
     * @param string $to         Resolved destination phone number
     *
     * @return array {status: 'success'|'error', status_code: int,
     *                message: string, response: mixed,
     *                provider_message_id?: string}
     */
    public function sendQueued($message, $subscriber, string $to): array;

    /**
     * Admin menu entries contributed by this channel, in the shape
     * fluent_crm/core_menu_items expects (key, label, permalink, description,
     * icon).
     *
     * Only called for active channels, so implementations do not need to check
     * isActive() themselves.
     *
     * @param string $urlBase Admin URL prefix, e.g. ".../admin.php?page=fluentcrm-admin#/"
     * @return array<int, array<string, string>>
     */
    public function getMenuItems(string $urlBase): array;

    /**
     * Fire any channel-specific hooks after a successful send.
     *
     * The kernel already fires fluent_crm/{channel}_sent for every
     * channel; this is for actions that only exist on one channel.
     *
     * @param object $message fc_messages row (Message model)
     */
    public function onSent($message, array $result): void;

    /**
     * Fire any channel-specific hooks after a failed send.
     *
     * @param object $message fc_messages row (Message model)
     */
    public function onFailed($message, string $error): void;
}
