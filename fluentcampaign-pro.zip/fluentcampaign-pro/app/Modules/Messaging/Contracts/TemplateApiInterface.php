<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * Implemented by drivers whose provider has a server-side template catalogue that
 * must be submitted for approval before messages can be sent from it.
 *
 * This is deliberately separate from the driver base class: SMS providers have no
 * approval concept, so `instanceof TemplateApiInterface` is how the template
 * screens decide whether a channel has anything to show.
 *
 * Every method returns a normalised array rather than throwing, matching the
 * driver send() contract:
 *
 *   ['status' => 'success'|'error', 'message' => string, 'data' => mixed]
 *
 * @see \FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\MetaCloudDriver
 */
interface TemplateApiInterface
{
    /**
     * Fetch the provider's full template catalogue.
     *
     * Returns provider-shaped rows under `data`; mapping them onto
     * fc_message_templates is the caller's job, because the mapping is
     * channel-specific and this interface is not.
     *
     * @param array $settings Saved provider settings
     */
    public function fetchTemplates(array $settings): array;

    /**
     * Look up one template's current approval state.
     *
     * @param array $settings Saved provider settings
     */
    public function fetchTemplateStatus(string $name, array $settings): array;

    /**
     * Submit a new template for approval.
     *
     * @param array $template name, language, category, header, body, footer,
     *                        buttons[], variables[] with sample values
     * @param array $settings Saved provider settings
     */
    public function submitTemplate(array $template, array $settings): array;

    /**
     * Remove a template from the provider.
     *
     * @param array $settings Saved provider settings
     */
    public function deleteTemplate(string $name, array $settings, string $providerTemplateId = '', string $language = ''): array;

    /**
     * Send a message built from an approved template.
     *
     * Unlike send(), this works outside the 24-hour customer-service window —
     * which is the entire reason templates exist.
     *
     * @param string $to         E.164 phone number
     * @param array  $components Provider-shaped component array with resolved
     *                           variable values
     * @param array  $settings   Saved provider settings
     */
    public function sendTemplate(string $to, string $templateName, string $language, array $components, array $settings, string $providerTemplateId = ''): array;
}
