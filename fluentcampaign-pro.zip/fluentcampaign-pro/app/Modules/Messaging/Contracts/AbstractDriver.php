<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * Shared base for every provider driver, on every channel.
 *
 * Holds only what is genuinely channel-independent: the settings-field contract
 * and the cURL execution helper. Channel-specific driver bases
 * (AbstractSMSDriver, AbstractWhatsAppDriver) extend this and add their own
 * registration behaviour.
 *
 * Third-party drivers should extend the channel-specific base, not this class.
 */
abstract class AbstractDriver
{
    /**
     * Unique slug used as the option key prefix and provider identifier.
     * e.g. 'twilio', 'aws_end_user_message', 'meta_cloud'
     */
    abstract public function getSlug(): string;

    /**
     * Human-readable label shown in the Settings UI provider dropdown.
     */
    abstract public function getLabel(): string;

    /**
     * Settings fields for this provider.
     *
     * Return an associative array of field definitions, keyed by field slug.
     * Each definition supports: type (text|password|select|checkbox), label,
     * sub_label, required (bool), default, options (for select).
     *
     * Example:
     * [
     *   'api_key' => ['type' => 'password', 'label' => 'API Key', 'required' => true, 'default' => ''],
     * ]
     */
    abstract public function getFields(): array;

    /**
     * Send a message.
     *
     * @param string $to       E.164 formatted phone number (e.g. +12125551234)
     * @param string $message  Message body text
     * @param array  $settings Saved provider settings for this provider (from DB)
     *
     * @return array {
     *   status: 'success'|'error',
     *   status_code: int,
     *   message: string,
     *   response: mixed,
     *   provider_message_id?: string
     * }
     */
    abstract public function send(string $to, string $message, array $settings): array;

    /**
     * Whether this provider can receive incoming messages via webhook.
     * When true, a webhook URL is exposed in settings once credentials are saved.
     */
    public function hasWebhook(): bool
    {
        return false;
    }

    /**
     * Message returned on a successful send. Overridable so each channel can
     * keep its own wording in message notes.
     */
    protected function getSuccessMessage(): string
    {
        return 'Message sent successfully';
    }

    /**
     * Execute a cURL request and return a normalised response array.
     * Available to all providers as a convenience helper.
     *
     * Connect and total timeouts are always applied so a hung provider cannot
     * stall the sender; a driver may override them via $options.
     *
     * Thirty seconds is right for a queued send, where nothing is waiting and
     * giving up early would turn a slow success into a false failure. It is far
     * too long when the send is happening inside somebody's checkout, so the
     * filter below lets the caller bound it — see MessageScheduler::dispatch().
     *
     * @param array $options     cURL option constants → values
     * @param int   $successCode Expected HTTP success code
     * @return array
     */
    protected function executeCurl(array $options, int $successCode = 200): array
    {
        $ch = curl_init();
        $options = $options + [
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 30,
        ];

        $options[CURLOPT_TIMEOUT] = max(1, (int) apply_filters(
            'fluent_crm/message_send_timeout',
            $options[CURLOPT_TIMEOUT],
            $this->getSlug()
        ));

        // Waiting for a connection cannot outlast the request it belongs to.
        $options[CURLOPT_CONNECTTIMEOUT] = min(
            $options[CURLOPT_CONNECTTIMEOUT],
            $options[CURLOPT_TIMEOUT]
        );

        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'CURL error: ' . $error,
                'response'    => null,
            ];
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== $successCode) {
            return [
                'status'      => 'error',
                'status_code' => $httpCode,
                'message'     => 'Unexpected HTTP response',
                'response'    => $response,
            ];
        }

        return [
            'status'      => 'success',
            'status_code' => $httpCode,
            'message'     => $this->getSuccessMessage(),
            'response'    => $response,
        ];
    }
}
