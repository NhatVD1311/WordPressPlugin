<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCrm\App\Models\Model;

/**
 * Message — one message, inbound or outbound, belonging to a thread.
 *
 * There is deliberately no `channel` column: a thread is single-channel, so the
 * channel is read from the thread it belongs to.
 *
 * @package FluentCrm\App\Models
 */
class Message extends Model
{
    protected $table = 'fc_messages';

    protected $guarded = ['id'];

    protected $searchable = [
        'content'
    ];

    protected $casts = [
        'id'         => 'integer',
        'thread_id'  => 'integer',
        'ref_id'     => 'integer',
        'created_by' => 'integer'
    ];

    protected $dates = [
        'scheduled_at',
        'sent_at',
        'created_at',
        'updated_at'
    ];

    const DIRECTION_INBOUND = 'inbound';
    const DIRECTION_OUTBOUND = 'outbound';

    /**
     * `ref_type` values that point at a row in fc_sms_campaigns. Anything else
     * — a one-off send, an inbound message — has no referent and leaves both
     * `ref_type` and `ref_id` null.
     */
    const REF_CAMPAIGN = 'campaign';
    const REF_AUTOMATION = 'automation';

    /**
     * A message an operator composed in the inbox, as opposed to one a campaign
     * or an automation generated. MessageThreadController has written this
     * string literally since the inbox shipped; naming it here is what lets the
     * scheduler recognise the case.
     */
    const REF_INBOX = 'inbox';

    /**
     * Queue and delivery states.
     *
     * The first four are queue states, walked in order by the scheduler:
     * `scheduling` while a campaign is still generating rows, `scheduled` once
     * generation finished, `pending` for anything ready now, and `processing`
     * while a runner has claimed the row. The rest are terminal.
     *
     * These are the same strings the retired fc_sms_messages used, so migrated
     * history and newly queued rows read identically.
     */
    const STATUS_SCHEDULING = 'scheduling';
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_PENDING = 'pending';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SENT = 'sent';
    const STATUS_DELIVERED = 'delivered';
    const STATUS_READ = 'read';
    const STATUS_FAILED = 'failed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_RECEIVED = 'received';

    /**
     * How far along a delivery receipt is, so a late-arriving one cannot walk
     * the status backwards.
     *
     * Meta does not guarantee the order of its `statuses[]` callbacks: a `read`
     * receipt can arrive before the `delivered` one for the same message, and
     * applying them in arrival order would show a message the contact has
     * already read as merely delivered.
     */
    const DELIVERY_RANK = [
        self::STATUS_SENT      => 1,
        self::STATUS_DELIVERED => 2,
        self::STATUS_READ      => 3
    ];

    /**
     * Statuses a runner may claim. `pending` and `scheduled` are both ready to
     * go once `scheduled_at` has passed; the split only records how the row got
     * there.
     */
    const CLAIMABLE = [self::STATUS_PENDING, self::STATUS_SCHEDULED];

    /**
     * Statuses that mean a campaign still has work outstanding.
     */
    const UNFINISHED = [
        self::STATUS_SCHEDULING,
        self::STATUS_PENDING,
        self::STATUS_SCHEDULED,
        self::STATUS_PROCESSING
    ];

    /**
     * The queue rows belonging to one campaign or automation.
     *
     * `ref_id` holds the fc_sms_campaigns id and `ref_type` says which kind it
     * is. Both are needed: `ref_id` alone would also match a message pointing at
     * an unrelated object that happens to share the id.
     *
     * @param int $campaignId
     */
    public function scopeForCampaign($query, $campaignId)
    {
        return $query->where('ref_id', (int) $campaignId)
            ->whereIn('ref_type', [self::REF_CAMPAIGN, self::REF_AUTOMATION]);
    }

    /**
     * Messages that reference a message template.
     *
     * The template id lives in the serialized `meta`, so this is a LIKE over the
     * blob rather than an indexed lookup — serialized text cannot be indexed or
     * queried meaningfully. That is the accepted cost of not adding a
     * `template_id` column (plan §5, still un-agreed); it is only used by the
     * rare "is this template still referenced?" check before a delete, never on
     * a hot path.
     *
     * Matches the integer form our writers always produce. A hand-written row
     * storing the id as a string would be missed, which errs toward deleting a
     * template that looks unreferenced — so the caller should treat a false as
     * "probably unused", not as proof.
     *
     * @param int $templateId
     */
    public function scopeUsingTemplate($query, $templateId)
    {
        global $wpdb;

        $needle = 's:11:"template_id";i:' . (int) $templateId . ';';

        return $query->where('meta', 'LIKE', '%' . $wpdb->esc_like($needle) . '%');
    }

    /**
     * The stored value of a date column, rather than the DateTime the `$dates`
     * list turns it into on access.
     *
     * strtotime() and a `Y-m-d H:i:s` comparison both need the string. Reading
     * `$message->scheduled_at` straight gives a DateTime, which silently
     * produces nonsense in both — the same trap that put messages in the thread
     * with no timestamp during the read path.
     *
     * @param string $column
     * @return string|null
     */
    public function rawDate($column)
    {
        $value = $this->getAttributes()[$column] ?? null;

        return ($value === null || $value === '') ? null : (string) $value;
    }

    /**
     * Serialized, matching MessageThread::meta and the rest of the codebase.
     * See the note there on why this is an accessor rather than a cast.
     */
    public function setMetaAttribute($meta)
    {
        $this->attributes['meta'] = \maybe_serialize($meta);
    }

    public function getMetaAttribute($meta)
    {
        $meta = \maybe_unserialize($meta);

        return is_array($meta) ? $meta : [];
    }

    public function oneTimeRecipientContext()
    {
        $recipient = $this->meta['one_time_recipient'] ?? [];

        return is_array($recipient) ? $recipient : [];
    }

    public function thread()
    {
        return $this->belongsTo(MessageThread::class, 'thread_id', 'id');
    }

    public function scopeInbound($query)
    {
        return $query->where('direction', self::DIRECTION_INBOUND);
    }

    /**
     * Conversation order.
     *
     * `created_at` is when the row was made and `scheduled_at` is intent;
     * neither on its own is when the message entered the conversation. Ordering
     * on the coalesced value keeps a scheduled send at the end of the thread
     * where it belongs, and lets an inbound message fall back to its arrival
     * time. This must match how the rail sorts, or the two disagree about which
     * message is newest.
     */
    public function scopeConversationOrder($query, $direction = 'ASC')
    {
        return $query->orderByRaw('COALESCE(sent_at, scheduled_at, created_at) ' . ($direction === 'DESC' ? 'DESC' : 'ASC'));
    }
}
