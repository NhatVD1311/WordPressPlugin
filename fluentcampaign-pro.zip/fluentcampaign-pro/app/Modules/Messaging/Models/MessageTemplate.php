<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCrm\App\Models\Model;

/**
 * A message template for any channel.
 *
 * WhatsApp templates are mirrored from the provider and carry an approval status;
 * SMS rows are local-only and created APPROVED because there is nothing to review.
 * Channel-specific columns are nullable so an SMS row is just a name and a body.
 *
 * @property int $id
 * @property string $channel
 * @property string $name
 * @property string $language
 * @property string|null $category
 * @property string $status
 * @property string|null $header_text
 * @property string $body_text
 * @property string|null $footer_text
 * @property array|null $buttons
 * @property array|null $variables
 * @property string|null $provider
 * @property string|null $provider_template_id
 * @property string|null $rejection_reason
 */
class MessageTemplate extends Model
{
    protected $table = 'fc_message_templates';

    protected $fillable = [
        'channel',
        'name',
        'language',
        'category',
        'status',
        'header_text',
        'body_text',
        'footer_text',
        'buttons',
        'variables',
        'provider',
        'provider_template_id',
        'rejection_reason',
        'last_synced_at',
        'created_by',
    ];

    protected $casts = [
        'id'         => 'integer',
        'created_by' => 'integer',
    ];

    protected $dates = ['last_synced_at', 'created_at', 'updated_at'];

    const STATUS_PENDING  = 'PENDING';
    const STATUS_APPROVED = 'APPROVED';
    const STATUS_REJECTED = 'REJECTED';
    const STATUS_PAUSED   = 'PAUSED';
    const STATUS_DISABLED = 'DISABLED';

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->channel  = $model->channel ?: 'whatsapp';
            $model->language = $model->language ?: 'en_US';
            $model->status   = $model->status ?: self::STATUS_PENDING;
        });
    }

    public function setButtonsAttribute($value)
    {
        $this->attributes['buttons'] = is_array($value) ? wp_json_encode($value) : $value;
    }

    public function getButtonsAttribute($value)
    {
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function setVariablesAttribute($value)
    {
        $this->attributes['variables'] = is_array($value) ? wp_json_encode($value) : $value;
    }

    public function getVariablesAttribute($value)
    {
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function scopeForChannel($query, $channel)
    {
        return $query->where('channel', $channel);
    }

    /**
     * Only approved templates may be selected in a campaign — a PAUSED or
     * REJECTED template is rejected at send time, so offering it is a trap.
     */
    public function scopeApproved($query)
    {
        return $query->where('status', self::STATUS_APPROVED);
    }

    /**
     * Positions of the {{n}} placeholders in the body, in order.
     *
     * @return int[]
     */
    public function getVariablePositions(): array
    {
        preg_match_all('/\{\{(\d+)\}\}/', (string) $this->body_text, $matches);

        $positions = array_values(array_unique(array_map('intval', $matches[1] ?? [])));
        sort($positions);

        return $positions;
    }
}
