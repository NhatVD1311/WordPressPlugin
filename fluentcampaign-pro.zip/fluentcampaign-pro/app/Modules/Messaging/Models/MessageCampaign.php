<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCrm\App\Models\Label;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Meta;
use FluentCrm\App\Models\Model;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Models\TermRelation;
use FluentCrm\App\Services\ContactsQuery;
use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Modules\Messaging\MessageModule;

/**
 * @property int $id
 * @property int|null $parent_id
 * @property string $type
 * @property string $title
 * @property string $slug
 * @property string $status
 * @property string $message_content
 * @property string|null $sender_number
 * @property int $recipients_count
 * @property int $sent_count
 * @property int $failed_count
 * @property int|null $delay
 * @property string|null $scheduled_at
 * @property array|null $settings
 * @property int|null $created_by
 * @property string $created_at
 * @property string $updated_at
 */
class MessageCampaign extends Model
{
    protected $table = 'fc_sms_campaigns';

    protected $fillable = [
        'parent_id',
        'type', // [ 'campaign', 'custom-sms', 'automation' ..]
        'title',
        'slug',
        'status',  // [ 'draft', 'pending-scheduled', 'processing', 
        'message_content',
        'sender_number',
        'recipients_count',
        'sent_count',
        'failed_count',
        'delay',
        'scheduled_at',
        'settings',
        'channel',       // 'sms' | 'whatsapp'
        'created_by'
    ];

    protected $casts = [
        'id' => 'integer',
        'parent_id' => 'integer',
        'recipients_count' => 'integer',
        'sent_count' => 'integer',
        'failed_count' => 'integer',
        'delay' => 'integer',
        'created_by' => 'integer'
    ];

    protected $dates = [
        'scheduled_at',
        'created_at',
        'updated_at'
    ];

    // Type constants
    const TYPE_SMS = 'sms';

    // Channel constants
    const CHANNEL_SMS      = 'sms';
    const CHANNEL_WHATSAPP = 'whatsapp';

    /**
     * Discriminator written to the shared fc_meta, fc_term_relations and
     * fc_subscriber_pivot tables for rows belonging to this model.
     *
     * FROZEN at the original class name. This string is persisted data, not a
     * class reference — changing it orphans every existing meta row, label
     * relation and pivot row. It must therefore survive any rename of this
     * class. The free plugin hardcodes the same literal in
     * fluentcrm_get_sms_campaign_meta() and friends
     * (fluent-crm/app/Functions/helpers.php), and free/pro versions upgrade
     * independently, so the two must agree on the literal rather than on a
     * shared constant.
     *
     * Never replace usages of this constant with the magic __CLASS__ constant
     * or self::class — those follow the class name and would silently change
     * the stored value.
     */
    const OBJECT_TYPE = 'FluentCampaign\App\Modules\SMS\Models\SMSCampaign';

    /**
     * Where the generate and send loops resume from, keyed by campaign id.
     *
     * An option rather than a column: the value is read once per action and a
     * persistent object cache serves that from memory, where a campaign-row read
     * is a DB round trip every time. It also keeps the cursors out of the Action
     * Scheduler arguments, which is what lets every campaign action carry only
     * `[$campaignId]` and be cancelled by hook + args instead of by a
     * per-campaign group.
     *
     * autoload is 'no' — one autoloaded row per in-flight campaign would be read
     * into memory on every page load of the site.
     *
     * The cursor is an optimisation, never a correctness mechanism. The queries
     * it accompanies already filter on status, and every message is claimed with
     * a conditional UPDATE before its provider call, so a cursor that is lost,
     * stale, or rewound by two concurrent workers costs a re-scan of rows that
     * are no longer claimable — never a duplicate send.
     */
    const CURSOR_OPTION_PREFIX = '_fc_message_cursor_';


    /**
     * @return array{gen:int,send:int}
     */
    public static function getCursor($campaignId): array
    {
        $cursor = get_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId, []);

        if (!is_array($cursor)) {
            $cursor = [];
        }

        return [
            'gen'  => isset($cursor['gen']) ? (int) $cursor['gen'] : 0,
            'send' => isset($cursor['send']) ? (int) $cursor['send'] : 0,
        ];
    }

    /**
     * @param string $phase gen|send
     */
    public static function setCursor($campaignId, string $phase, $id): void
    {
        $cursor = self::getCursor($campaignId);
        $cursor[$phase] = (int) $id;

        update_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId, $cursor, 'no');
    }

    /**
     * Every terminal path owes this call, or the option row outlives the
     * campaign: archived, unscheduled back to draft, and deleted.
     */
    public static function clearCursor($campaignId): void
    {
        delete_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId);
    }



    protected static $type = 'campaign';

    /**
     * Resolve this campaign's channel from the registry.
     *
     * Recipient selection and consent checks are driven entirely by the returned
     * channel, so a campaign never queries the wrong consent column.
     *
     * Falls back to the SMS channel when `channel` is empty, which is how rows
     * created before the column existed behave. An unrecognised non-empty value
     * is a genuine error and throws rather than silently defaulting — sending a
     * WhatsApp campaign over SMS would breach per-channel consent.
     *
     * @return \FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface
     * @throws \InvalidArgumentException
     */
    public function resolveChannel()
    {
        $slug = $this->channel ?: self::CHANNEL_SMS;

        $channel = MessageModule::channel($slug);

        if (!$channel) {
            throw new \InvalidArgumentException(
                'Unknown message channel for campaign ' . $this->id . ': ' . $slug
            );
        }

        return $channel;
    }

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->status = $model->status ?: 'draft';
            $model->type = $model->type ?: self::$type;
            $model->slug = $model->slug ?: sanitize_title($model->title, '', 'preview');
            $model->created_by = $model->created_by ?: get_current_user_id();
            $model->settings = $model->settings ?: [
                'subscribers' => [
                    [
                        'list' => 'all',
                        'tag'  => 'all'
                    ]
                ],
                'excludedSubscribers' => [
                    [
                        'list' => null,
                        'tag'  => null
                    ]
                ],
                'sending_filter'    => 'list_tag',
                'dynamic_segment'  => [
                    'id'   => '',
                    'slug' => ''
                ],
                'advanced_filters' => [
                    []
                ],
                'sending_type'     => 'instant',
                'is_transactional' => 'no'
            ];
        });
    }

    /**
     * Relationship with SMS Messages
     */
    /**
     * This campaign's queued and sent messages, in fc_messages.
     *
     * `ref_id` holds the campaign id and `ref_type` says what kind of thing it
     * points at. Both are needed — `ref_id` alone would also match a message
     * referring to some other object that happens to share the number.
     */
    public function messages()
    {
        return $this->hasMany(Message::class, 'ref_id', 'id')
            ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
    }

    /**
     * The `ref_type` this campaign's messages carry.
     *
     * Campaign types other than 'automation' — including the throwaway
     * 'custom_sms' campaign a one-off send creates — are recorded as campaign
     * references, so the scheduler's campaign scope finds them.
     */
    public function messageRefType()
    {
        return $this->type === 'automation' ? Message::REF_AUTOMATION : Message::REF_CAMPAIGN;
    }

    /**
     * Scope for filtering by status
     */
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope for filtering by type
     */
    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope for filtering by date range
     */
    public function scopeByDateRange($query, $startDate, $endDate = null)
    {
        $query->where('created_at', '>=', $startDate);
        
        if ($endDate) {
            $query->where('created_at', '<=', $endDate);
        }

        return $query;
    }

    public function setSettingsAttribute($settings)
    {
        $this->attributes['settings'] = \maybe_serialize($settings);
    }

    public function getSettingsAttribute($settings)
    {
        return \maybe_unserialize($settings);
    }

    /**
     * Get success rate percentage
     */
    public function getSuccessRateAttribute()
    {
        if ($this->sent_count === 0) {
            return 0;
        }

        $successCount = $this->sent_count - $this->failed_count;
        return round(($successCount / $this->sent_count) * 100, 2);
    }

    /**
     * Get failure rate percentage
     */
    public function getFailureRateAttribute()
    {
        if ($this->sent_count === 0) {
            return 0;
        }

        return round(($this->failed_count / $this->sent_count) * 100, 2);
    }

    /**
     * Get progress percentage
     */
    public function getProgressAttribute()
    {
        if ($this->recipients_count === 0) {
            return 0;
        }

        return round(($this->sent_count / $this->recipients_count) * 100, 2);
    }

    /**
     * Get remaining recipients count
     */
    public function getRemainingCountAttribute()
    {
        return max(0, $this->recipients_count - $this->sent_count);
    }

    /**
     * Get truncated message content
     */
    public function getShortMessageAttribute($length = 100)
    {
        if (!$this->message_content) {
            return null;
        }

        if (strlen($this->message_content) <= $length) {
            return $this->message_content;
        }

        return substr($this->message_content, 0, $length) . '...';
    }

    /**
     * Get message character count
     */
    public function getMessageLengthAttribute()
    {
        return strlen($this->message_content ?? '');
    }

    /**
     * Get estimated SMS segments per message
     */
    public function getEstimatedSegmentsAttribute()
    {
        $length = $this->getMessageLengthAttribute();
        
        if ($length <= 160) {
            return 1;
        }

        // For multipart SMS, each segment can contain 153 characters
        return ceil($length / 153);
    }

    /**
     * Get total estimated segments for all recipients
     */
    public function getTotalEstimatedSegmentsAttribute()
    {
        return $this->getEstimatedSegmentsAttribute() * $this->recipients_count;
    }

    /**
     * Increment sent count
     */
    public function incrementSentCount($amount = 1)
    {
        $this->increment('sent_count', $amount);
        return $this;
    }

    /**
     * Increment failed count
     */
    public function incrementFailedCount($amount = 1)
    {
        $this->increment('failed_count', $amount);
        return $this;
    }

    /**
     * Update recipients count
     */
    public function updateRecipientsCount($count)
    {
        $this->update(['recipients_count' => $count]);
        return $this;
    }

    /**
     * Generate unique slug
     */
    public function generateSlug($title)
    {
        $slug = sanitize_title($title);
        $originalSlug = $slug;
        $counter = 1;

        while (static::where('slug', $slug)->where('id', '!=', $this->id ?? 0)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Static method to create SMS campaign
     */
    public static function createCampaign($data)
    {
        $campaign = new static();
        
        $slug = $campaign->generateSlug($data['title']);

        return static::create([
            'parent_id' => $data['parent_id'] ?? null,
            'type' => $data['type'] ?? self::TYPE_SMS,
            'title' => $data['title'],
            'slug' => $slug,
            'status' => $data['status'] ?? 'draft',
            'message_content' => $data['message_content'],
            'sender_number' => $data['sender_number'] ?? null,
            'recipients_count' => $data['recipients_count'] ?? 0,
            'delay' => $data['delay'] ?? 0,
            'scheduled_at' => $data['scheduled_at'] ?? null,
            'settings' => $data['settings'] ?? [],
            'created_by' => $data['created_by'] ?? get_current_user_id()
        ]);
    }

    /**
     * Get campaign statistics
     */
    public function getStatistics()
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'status' => $this->status,
            'recipients_count' => $this->recipients_count,
            'sent_count' => $this->sent_count,
            'failed_count' => $this->failed_count,
            'success_rate' => $this->getSuccessRateAttribute(),
            'failure_rate' => $this->getFailureRateAttribute(),
            'progress' => $this->getProgressAttribute(),
            'remaining_count' => $this->getRemainingCountAttribute(),
            'message_length' => $this->getMessageLengthAttribute(),
            'estimated_segments' => $this->getEstimatedSegmentsAttribute(),
            'total_estimated_segments' => $this->getTotalEstimatedSegmentsAttribute(),
            'created_at' => $this->created_at,
            'scheduled_at' => $this->scheduled_at
        ];
    }

    public function getSubscriberIdsCountBySegmentSettings($settings, $status = 'subscribed')
    {
        $model = $this->getSubscribersModel($settings);
        if ($model) {
            return $model->count();
        }

        return 0;
    }

    public function getSubscribersModel($settings = false)
    {
        if (!$settings) {
            $settings = $this->settings;
        }

        $filterType = Arr::get($settings, 'sending_filter', 'list_tag');

        if ($filterType == 'list_tag') {
            $channel = $this->resolveChannel();

            $subscriberModel = $this->getSubscribeIdsByListModel($settings['subscribers'], $channel->getSlug());
            if ($excludeItems = Arr::get($settings, 'excludedSubscribers')) {
                $formattedExcludedItems = [];
                foreach ($excludeItems as $item) {
                    if (empty($item['list']) && empty($item['tag'])) {
                        continue;
                    }
                    $formattedExcludedItems[] = $item;
                }

                if ($formattedExcludedItems) {
                    $excludedModel = $this->getSubscribeIdsByListModel($excludeItems, $channel->getSlug());
                    $excludedModel->select('id');
                    $subscriberModel->whereNotIn('id', $excludedModel->getQuery());
                }
            }

            return $subscriberModel;
        }

        if ($filterType == 'dynamic_segment') {
            $segmentSettings = Arr::get($settings, 'dynamic_segment', []);
            $segmentSettings['offset'] = 0;
            $segmentSettings['limit'] = false;

            /**
             * Filter the dynamic segment details based on the segment slug.
             *
             * This filter allows you to modify the details of a dynamic segment.
             *
             * @param array  The details of the dynamic segment.
             * @param int $segmentSettings ['id']      The ID of the segment.
             * @param array {
             *     Additional context for the segment.
             *
             * @type bool  Whether to include the model in the context.
             * }
             *
             * @return array Modified segment details.
             * @since 2.5.93
             *
             */
            $segmentDetails = apply_filters('fluentcrm_dynamic_segment_' . $segmentSettings['slug'], [], $segmentSettings['id'], [
                'model' => true
            ]);

            if (!empty($segmentDetails['model'])) {
                $model = $segmentDetails['model'];

                MessageThread::applyConsentFilter($model, $this->resolveChannel()->getSlug());

                return $model;
            }

            return null;
        }

        if ($filterType == 'advanced_filters') {
            $query = new ContactsQuery([
                'with'               => [],
                'filter_type'        => 'advanced',
                'contact_status'     => 'subscribed',
                'filters_groups_raw' => $settings['advanced_filters']
            ]);

            return MessageThread::applyConsentFilter($query->getModel(), $this->resolveChannel()->getSlug());
        }

        return null;
    }

    /**
     * @param array  $items   list/tag selection groups
     * @param string $channel channel slug the audience is being built for
     * @param int|false $limit
     * @param int    $offset
     */
    public function getSubscribeIdsByListModel($items, $channel = 'sms', $limit = false, $offset = 0)
    {
        $query = MessageThread::applyConsentFilter(Subscriber::query(), $channel);

        $queryGroups = [];

        $willSkip = false;

        $hasListFilter = false;
        $tagIds = [];
        foreach ($items as $item) {
            $listId = $item['list'];
            $tagId = $item['tag'];
            if (!$listId || !$tagId) {
                continue;
            }

            if ($listId == 'all' && $tagId == 'all') {
                $willSkip = true;
            } else if ($listId == 'all') {
                $queryGroups[] = ['tag_id' => $tagId];
                $tagIds[] = $tagId;
            } else if ($tagId == 'all') {
                $hasListFilter = true;
                $queryGroups[] = ['list_id' => $listId];
            } else {
                $hasListFilter = true;
                $tagIds[] = $tagId;
                $queryGroups[] = [
                    'list_id' => $listId,
                    'tag_id'  => $tagId
                ];
            }
        }

        if (!$willSkip && !$hasListFilter && $tagIds) {
            $query->filterByTags($tagIds);
        } else if (!$willSkip && $queryGroups) {
            $query->where(function ($innerQuery) use ($queryGroups) {
                $type = 'where';
                foreach ($queryGroups as $queryGroup) {
                    $innerQuery->{$type}(function ($q) use ($queryGroup, $innerQuery) {
                        foreach ($queryGroup as $type => $id) {
                            if ($type == 'tag_id') {
                                $q->whereIn('id', function ($query) use ($id) {
                                    return $this->getSubQueryForListOrTagFilter($query, [$id], 'tags', 'FluentCrm\App\Models\Tag');
                                });
                            } else if ($type == 'list_id') {
                                $q->whereIn('id', function ($query) use ($id) {
                                    return $this->getSubQueryForListOrTagFilter($query, [$id], 'lists', 'FluentCrm\App\Models\Lists');
                                });
                            }
                        }
                    });

                    $type = 'orWhere';
                }
            });
        }

        if ($limit) {
            $query->limit($limit)->offset($offset);
        }

        return $query;
    }

    private function getSubQueryForListOrTagFilter($query, $ids, $table, $objectType)
    {
        $prefix = 'fc_';

        return $query->from($prefix . $table)
                     ->join(
                         $prefix . 'subscriber_pivot',
                         $prefix . 'subscriber_pivot.object_id',
                         '=',
                         $prefix . $table . '.id'
                     )
                     ->where($prefix . 'subscriber_pivot.object_type', $objectType)
                     ->whereIn($prefix . $table . '.id', $ids)
                     ->groupBy($prefix . 'subscriber_pivot.subscriber_id')
                     ->select($prefix . 'subscriber_pivot.subscriber_id');
    }

    /**
     * Add one or more subscribers to the SMS campaign.
     *
     * Rows are written through MessageThread::recordMessages(), which resolves
     * the whole batch's conversations and inserts its messages in a handful of
     * queries — a per-subscriber create() makes campaign generation O(audience)
     * INSERTs, and it would also leave the thread caches stale.
     *
     * The returned ids come from what was actually written, not from what was
     * intended: a recipient whose number turns out to be unusable gets no row
     * and must not be counted as one.
     *
     * @param array $subscriberIds
     * @param array $smsArgs status, scheduled_at, settings
     * @param bool $isModel if the $subscriberIds is collection or not
     * @return array subscriber ids a message row was created for
     */
    public function subscribe($subscriberIds, $smsArgs = [], $isModel = false)
    {
        if ($isModel) {
            $subscribers = $subscriberIds;
        } else {
            $subscribers = \FluentCrm\App\Models\Subscriber::whereIn('id', $subscriberIds)->get();
        }

        $channelObject = $this->resolveChannel();
        $channel       = $channelObject->getSlug();

        $subscriberIdsInBatch = [];
        foreach ($subscribers as $subscriber) {
            $subscriberIdsInBatch[] = $subscriber->id;
        }

        // One query for the whole batch. Consent lives on the threads, so asking
        // per subscriber would put a SELECT between every recipient and the next.
        $blocked = MessageThread::blockedContactIds($channel, $subscriberIdsInBatch);

        // Anything the columns have no home for travels in `meta`, serialized by
        // the model's mutator — never JSON-encoded, which the 'array' cast would
        // do and then read back as null.
        $meta = [];
        if (isset($smsArgs['settings']) && is_array($smsArgs['settings'])) {
            $meta['settings'] = $smsArgs['settings'];
        }

        $refType = $this->messageRefType();

        // Keyed by subscriber id so the write can report back exactly which
        // contacts got a row.
        $items = [];

        foreach ($subscribers as $subscriber) {
            // Opted out on this channel — the thread is the only place that is
            // recorded, and it outranks whatever put them in the audience.
            if (isset($blocked[(int) $subscriber->id])) {
                continue;
            }

            // Skip if subscriber doesn't have a mobile number
            if (empty($subscriber->phone)) {
                continue;
            }

            $items[$subscriber->id] = [
                'channel'      => $channel,
                'phone'        => $subscriber->phone,
                'contact_id'   => $subscriber->id,
                'direction'    => Message::DIRECTION_OUTBOUND,
                'content'      => $this->message_content,
                'ref_id'       => $this->id,
                'ref_type'     => $refType,
                'status'       => isset($smsArgs['status']) ? $smsArgs['status'] : $this->status,
                'scheduled_at' => isset($smsArgs['scheduled_at']) ? $smsArgs['scheduled_at'] : null,
                'meta'         => $meta
            ];
        }

        $subscribedIds = $items ? MessageThread::recordMessages($items) : [];

        $messageCount = $this->getMessageCount();
        if ($messageCount != $this->recipients_count) {
            $this->recipients_count = $messageCount;
            $this->save();
        }

        return $subscribedIds;
    }

    /**
     * Remove one or more subscribers from the SMS campaign
     * @param array $subscriberIds
     * @return bool
     */
    public function unsubscribe($subscriberIds)
    {
        // Contacts are reached through their thread now, so the removal is
        // scoped by which conversation the message sits on.
        $threadIds = MessageThread::whereIn('contact_id', (array) $subscriberIds)
            ->pluck('id')
            ->toArray();

        if (!$threadIds) {
            return 0;
        }

        $result = $this->messages()->whereIn('thread_id', $threadIds)->delete();

        $this->recipients_count = $this->messages()->count();
        $this->save();

        return $result;
    }

    /**
     * Get the total count of SMS messages for this campaign
     * @return int
     */
    public function getMessageCount()
    {
        return $this->messages()->count();
    }

    public function deleteCampaignData()
    {
        // The resume cursors outlive the campaign otherwise — nothing else
        // deletes an option keyed by an id that no longer exists.
        self::clearCursor($this->id);

        $this->messages()->delete();

        Meta::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->delete();

        return $this;
    }

    public function labelsTerm()
    {
        return $this->belongsToMany(
            Label::class,
            'fc_term_relations',
            'object_id',
            'term_id'
        )->wherePivot('object_type', self::OBJECT_TYPE);
    }

    public function getFormattedLabels()
    {
        $labels = $this->labels();
        return $labels->map(function ($label) {
            return [
                'id'    => $label->id,
                'slug'  => $label->slug,
                'title' => $label->title,
                'color' => $label->settings['color'] ?? ''
            ];
        });
    }

    public function labels()
    {
        $labelIds = TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->pluck('term_id')
            ->toArray();

        if (empty($labelIds)) {
            return Label::whereRaw('1 = 0')->get();
        }

        return Label::whereIn('id', $labelIds)->get();
    }

    public function attachLabels($labelIds)
    {
        $labelIds = is_array($labelIds) ? $labelIds : [$labelIds];
        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (empty($labelIds)) {
            return $this;
        }

        $existingLabelIds = TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->pluck('term_id')
            ->map(function ($id) {
                return (int)$id;
            })
            ->toArray();

        $newLabelIds = array_diff($labelIds, $existingLabelIds);

        foreach ($newLabelIds as $labelId) {
            TermRelation::create([
                'object_id'   => $this->id,
                'object_type' => self::OBJECT_TYPE,
                'term_id'     => $labelId
            ]);
        }

        return $this;
    }

    public function detachLabels($labelIds)
    {
        $labelIds = is_array($labelIds) ? $labelIds : [$labelIds];
        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (empty($labelIds)) {
            return $this;
        }

        TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->whereIn('term_id', $labelIds)
            ->delete();

        return $this;
    }

    /**
     * When this campaign's messages are queued for.
     *
     * Every message shares the campaign's own scheduled_at. Range scheduling —
     * spreading a campaign randomly across a window — was withdrawn from the
     * controller pending more testing, so the branch that read it never ran; it
     * also carried a `static` cache that belonged to the function rather than
     * the model, which handed the second campaign in an Action Scheduler batch
     * the first campaign's send time.
     */
    public function getScheduledAt()
    {
        // The stored string, not $this->scheduled_at: `scheduled_at` is in
        // $dates, so reading it straight gives a DateTime. Every caller hands
        // the result to a write, and prepare('%s', $object) yields an empty
        // string — rejected outright under STRICT_TRANS_TABLES, stored as
        // 0000-00-00 without it, which satisfies `scheduled_at <= now` and
        // makes the row instantly due. Same reason finalizeGeneratedCampaign()
        // and finishOrRetryLater() read the raw attribute.
        return $this->getAttributes()['scheduled_at'] ?? null;
    }


    public function maybeDeleteDuplicates() // sms campaign duplicates messages
    {
        // One thread per contact per channel, so duplicates group by thread
        // rather than by subscriber — and this also catches two contacts that
        // share a number, which the subscriber grouping missed.
        // Every column selected is either grouped or aggregated, so this holds
        // under ONLY_FULL_GROUP_BY.
        $duplicates = fluentCrmDb()->table('fc_messages')
                                   ->where('ref_id', $this->id)
                                   ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION])
                                   ->select([fluentCrmDb()->raw('MIN(`id`) AS min_id'), 'thread_id', fluentCrmDb()->raw('COUNT(thread_id) as count')])
                                   ->groupBy('thread_id')
                                   ->havingRaw('COUNT(thread_id) > ?', [1])
                                   ->get();

        if ($duplicates->isEmpty()) {
            return $this;
        }

        $threadIds = [];
        $exceptIds = [];
        foreach ($duplicates as $duplicate) {
            $threadIds[] = $duplicate->thread_id;
            $exceptIds[] = $duplicate->min_id;
        }

        fluentCrmDb()->table('fc_messages')
                     ->where('ref_id', $this->id)
                     ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION])
                     ->whereIn('thread_id', $threadIds)
                     ->whereNotIn('id', $exceptIds)
                     ->delete();

        $messageCount = $this->getMessageCount();
        if ($messageCount != $this->recipients_count) {
            $this->recipients_count = $messageCount;
            $this->save();
        }

        return $this;
    }
}
