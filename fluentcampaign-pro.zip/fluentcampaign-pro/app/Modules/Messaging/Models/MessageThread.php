<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCrm\App\Models\Model;
use FluentCrm\App\Models\Subscriber;

/**
 * MessageThread — one conversation, keyed on a phone number and a channel.
 *
 * The thread owns the identity of a conversation. `contact_id` is nullable on
 * purpose: someone can message the business number before they exist as a
 * contact, and an admin can message a number directly, so a conversation has to
 * be able to exist without one and link up later.
 *
 * @package FluentCrm\App\Models
 */
class MessageThread extends Model
{
    /**
     * Consent vocabulary for `status`.
     *
     * Channel-neutral on purpose: the thread already knows its channel, so a
     * per-channel spelling (`sms_unsubscribed`) would only repeat it and force
     * every reader to translate.
     */
    const STATUS_SUBSCRIBED = 'subscribed';
    const STATUS_UNSUBSCRIBED = 'unsubscribed';
    const STATUS_PENDING = 'pending';
    const STATUS_BOUNCED = 'bounced';

    /**
     * `initiated_by` value for a thread nobody started — a consent record
     * carried over from the old contact column, with no conversation behind it.
     * The inbox rail hides these until a real message lands on them.
     */
    const INITIATED_BY_SYSTEM = 'system';

    protected $table = 'fc_message_threads';

    protected $guarded = ['id'];

    protected $searchable = [
        'phone_number'
    ];

    protected $casts = [
        'id'              => 'integer',
        'contact_id'      => 'integer',
        'last_seen_id'    => 'integer',
        'last_message_id' => 'integer',
        'has_unread'      => 'integer',
        'unread_count'    => 'integer'
    ];

    /**
     * `meta` is PHP-serialized, matching Campaign::settings and Company::meta.
     *
     * An accessor/mutator pair rather than a `$casts` entry, because the
     * framework's 'array' cast is JSON-backed — declaring it would double-encode
     * on write and return null on read.
     */
    public function setMetaAttribute($meta)
    {
        $this->attributes['meta'] = \maybe_serialize($meta);
    }

    /**
     * The is_array() guard is load-bearing: maybe_unserialize() returns false on
     * a malformed payload and passes a never-serialized string straight through,
     * so without it a caller doing $meta['x'] fatals.
     */
    public function getMetaAttribute($meta)
    {
        $meta = \maybe_unserialize($meta);

        return is_array($meta) ? $meta : [];
    }

    /**
     * The consent vocabulary, labelled for anything that shows it to a human.
     *
     * Keys are the stored values, so this doubles as the list of what may be
     * set — consentStatuses() reads them rather than restating the four.
     */
    public static function consentStatusLabels(): array
    {
        return [
            self::STATUS_SUBSCRIBED   => __('Subscribed', 'fluentcampaign-pro'),
            self::STATUS_UNSUBSCRIBED => __('Unsubscribed', 'fluentcampaign-pro'),
            self::STATUS_PENDING      => __('Pending', 'fluentcampaign-pro'),
            self::STATUS_BOUNCED      => __('Bounced', 'fluentcampaign-pro')
        ];
    }

    /**
     * The consent values an operator or a provider may set.
     */
    public static function consentStatuses(): array
    {
        return array_keys(self::consentStatusLabels());
    }

    /**
     * Whether a contact may be messaged on a channel.
     *
     * Consent belongs to the conversation, not the contact record — the thread
     * table is the only source of truth for it. A contact with no thread on the
     * channel has never said otherwise, so they are subscribed: absence is
     * consent, which is why a site with no threads at all can still run its
     * first campaign.
     *
     * Strictest wins. Any thread of theirs on this channel that is not
     * subscribed blocks the channel, including a thread on a number they no
     * longer use — matched by setConsent(), which applies a decision to every
     * thread the contact owns on that channel.
     */
    public static function contactCanReceive(string $channel, $contactId): bool
    {
        return static::contactStatus($channel, $contactId) === self::STATUS_SUBSCRIBED;
    }

    /**
     * The consent a contact holds on a channel, for display.
     *
     * The strictest thread wins, so this reports the status that is actually
     * blocking them rather than an arbitrary one — an operator needs to see
     * "bounced" and "unsubscribed" as the different problems they are.
     */
    public static function contactStatus(string $channel, $contactId): string
    {
        if (!$contactId) {
            return self::STATUS_SUBSCRIBED;
        }

        $blocking = static::where('contact_id', (int) $contactId)
            ->where('channel', $channel)
            ->where('status', '!=', self::STATUS_SUBSCRIBED)
            ->value('status');

        return $blocking ?: self::STATUS_SUBSCRIBED;
    }

    /**
     * The same question for a bare number — a direct send to someone who is not
     * a contact, or an import whose numbers have not been matched yet.
     *
     * An empty number is not a consent decision, so it is left to the caller's
     * own "no number" handling rather than answered here.
     */
    public static function numberCanReceive(string $channel, $phone): bool
    {
        $phone = trim((string) $phone);

        if ($phone === '') {
            return true;
        }

        $status = static::where('channel', $channel)
            ->where('phone_number', $phone)
            ->value('status');

        return $status === null || $status === self::STATUS_SUBSCRIBED;
    }

    /**
     * The subset of $contactIds that may NOT be messaged on a channel.
     *
     * One query for a whole page, so a recipient picker or an import batch does
     * not run contactCanReceive() per row.
     *
     * @return array<int, true> keyed by contact id, for isset() lookups
     */
    public static function blockedContactIds(string $channel, array $contactIds): array
    {
        $contactIds = array_values(array_unique(array_filter(array_map('intval', $contactIds))));

        if (!$contactIds) {
            return [];
        }

        $rows = static::whereIn('contact_id', $contactIds)
            ->where('channel', $channel)
            ->where('status', '!=', self::STATUS_SUBSCRIBED)
            ->get(['contact_id']);

        $blocked = [];

        foreach ($rows as $row) {
            $blocked[(int) $row->contact_id] = true;
        }

        return $blocked;
    }

    /**
     * Narrow a Subscriber query to the contacts a channel may message.
     *
     * @param mixed $query a Subscriber query/builder
     */
    public static function applyConsentFilter($query, string $channel)
    {
        return static::applyStatusFilter($query, $channel, [self::STATUS_SUBSCRIBED]);
    }

    /**
     * Narrow a Subscriber query to the contacts whose consent on a channel is
     * (or, negated, is not) one of $statuses.
     *
     * Reads consent the same way contactStatus() reports it: a contact holds a
     * non-subscribed status when any thread of theirs on the channel carries it,
     * and is subscribed when none does. That asymmetry is what "absence is
     * consent" costs — subscribed is an anti-join over every thread rather than
     * an equality, because the contacts a channel may message include everyone
     * who has no thread at all. `contact_idx (contact_id, channel)` covers both
     * lookups, and the non-subscribed rows they land on are a small minority.
     *
     * @param mixed $query    a Subscriber query/builder
     * @param array $statuses consent values from consentStatuses()
     * @param bool  $negate   match the contacts this would otherwise exclude
     */
    public static function applyStatusFilter($query, string $channel, array $statuses, bool $negate = false)
    {
        global $wpdb;

        $statuses = array_values(array_intersect(static::consentStatuses(), $statuses));

        // A selection that names nothing this model recognises cannot be
        // applied, so it matches nobody — negated too. Answering it as "not one
        // of nothing" would hand back every contact on the site, and a filter
        // nobody can satisfy must never be the one that widens an audience.
        if (!$statuses) {
            return $query->whereRaw('1 = 0');
        }

        $threads = $wpdb->prefix . 'fc_message_threads';
        $subscribers = $wpdb->prefix . 'fc_subscribers';

        $threadsOf = "SELECT 1 FROM `$threads` fc_consent
                      WHERE fc_consent.contact_id = `$subscribers`.`id`
                        AND fc_consent.channel = %s";

        $clauses = [];
        $args = [];

        $blocking = array_values(array_diff($statuses, [self::STATUS_SUBSCRIBED]));

        if ($blocking) {
            $placeholders = implode(', ', array_fill(0, count($blocking), '%s'));
            $clauses[] = "EXISTS ($threadsOf AND fc_consent.status IN ($placeholders))";
            $args = array_merge($args, [$channel], $blocking);
        }

        if (in_array(self::STATUS_SUBSCRIBED, $statuses, true)) {
            $clauses[] = "NOT EXISTS ($threadsOf AND fc_consent.status <> %s)";
            $args = array_merge($args, [$channel, self::STATUS_SUBSCRIBED]);
        }

        $sql = '(' . implode(' OR ', $clauses) . ')';

        return $query->whereRaw($wpdb->prepare($negate ? "NOT $sql" : $sql, $args));
    }

    /**
     * Record a consent decision for a number on a channel.
     *
     * A decision reached through one number applies to every thread the contact
     * owns on that channel. Without that, an opt-out on a second number would be
     * permanent: contactCanReceive() takes the strictest thread, so a later
     * opt-in on the first number could never clear it.
     *
     * The thread is created when the number has none, so an opt-out from someone
     * we have never messaged is still recorded rather than dropped.
     *
     * @return bool whether anything was stored
     */
    public static function setConsent(string $channel, $phone, string $status, $contactId = null): bool
    {
        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id' => $contactId,
            // Only applied when there is no thread yet, and then this row exists
            // solely to hold the consent — nobody has said anything on it. The
            // rail hides it on that basis, so recording an opt-out for a number
            // never messaged does not put an empty conversation in the inbox.
            'initiated_by' => self::INITIATED_BY_SYSTEM
        ]);

        if (!$thread) {
            return false;
        }

        $contactId = $contactId ?: $thread->contact_id;

        $query = $contactId
            ? static::where('contact_id', (int) $contactId)->where('channel', $channel)
            : static::where('id', $thread->id);

        // Consent is not conversation activity — the rail sorts on `updated_at`,
        // and a thread must not climb to the top of the inbox because someone
        // texted STOP to a different number of theirs.
        static::withoutTimestamps(function () use ($query, $status) {
            $query->update(['status' => $status]);
        });

        return true;
    }

    public function messages()
    {
        return $this->hasMany(Message::class, 'thread_id', 'id');
    }

    /**
     * The contact, when there is one. Null for a thread whose number is not in
     * the CRM — see the class docblock.
     */
    public function subscriber()
    {
        return $this->belongsTo(Subscriber::class, 'contact_id', 'id');
    }

    /**
     * Find the thread for a number on a channel, creating it if needed.
     *
     * The unique index on (channel, phone_number) is what makes this safe under
     * concurrency: two inbound webhooks arriving together both find nothing and
     * both insert, and the database rejects the loser rather than letting a
     * conversation split in two. The failed insert is recovered by reading the
     * row the winner created.
     *
     * `contact_id` is filled when known and never overwritten once set — a
     * later message from a number that has since become a contact should link
     * the thread, but must not relink a thread already attached to someone.
     *
     * @param string $channel
     * @param string $phone
     * @param array $attrs contact_id, initiated_by
     * @return static|null null only when the number is unusable
     */
    public static function findOrCreateFor($channel, $phone, array $attrs = [])
    {
        $channel = $channel ?: 'sms';
        $phone = trim((string) $phone);

        if ($phone === '') {
            return null;
        }

        $thread = static::where('channel', $channel)->where('phone_number', $phone)->first();

        if (!$thread) {
            try {
                $thread = static::create([
                    'contact_id'   => !empty($attrs['contact_id']) ? (int) $attrs['contact_id'] : null,
                    'channel'      => $channel,
                    'phone_number' => $phone,
                    'status'       => 'subscribed',
                    'initiated_by' => !empty($attrs['initiated_by']) ? $attrs['initiated_by'] : 'user',
                    'has_unread'   => 0,
                    'unread_count' => 0,
                    'created_at'   => current_time('mysql'),
                    'updated_at'   => current_time('mysql')
                ]);
            } catch (\Exception $e) {
                // Lost the race against a concurrent webhook; the winner's row
                // is the one to use.
                $thread = static::where('channel', $channel)->where('phone_number', $phone)->first();
            }
        }

        if ($thread && !$thread->contact_id && !empty($attrs['contact_id'])) {
            $thread->contact_id = (int) $attrs['contact_id'];

            // Linking a contact is bookkeeping, not activity. Saving normally
            // would stamp `updated_at`, and the rail sorts on it — a thread
            // would climb to the top of the inbox because someone was added to
            // the CRM, with no new message behind it.
            static::withoutTimestamps(function () use ($thread) {
                $thread->save();
            });
        }

        return $thread;
    }

    /**
     * Claim an unlinked or dangling thread for a contact, atomically.
     *
     * Linking is identity bookkeeping, not activity, so `updated_at` is carried
     * through unchanged and the conversation rail does not reorder.
     *
     * @param int $contactId
     * @param array $staleContactIds contact ids known to be deleted
     * @return bool true when this call performed the link
     */
    public function claimOrphanContact($contactId, array $staleContactIds = [])
    {
        $contactId = (int) $contactId;

        if (!$this->id || !$contactId) {
            return false;
        }

        $staleContactIds = array_values(array_filter(array_map('intval', $staleContactIds)));

        $affected = static::where('id', (int) $this->id)
            ->where(function ($query) use ($staleContactIds) {
                $query->whereNull('contact_id');

                if ($staleContactIds) {
                    $query->orWhereIn('contact_id', $staleContactIds);
                }
            })
            ->update([
                'contact_id' => $contactId,
                'updated_at' => $this->updated_at
            ]);

        if ($affected) {
            $this->contact_id = $contactId;
            $this->syncOriginalAttribute('contact_id');
        }

        return (bool) $affected;
    }

    /**
     * The thread for a contact on a channel, if one exists.
     *
     * A contact can have at most one thread per channel, because threads are
     * unique on (channel, phone_number) and a contact has one number per
     * channel. Returns null when the contact has never been messaged.
     *
     * @param int $contactId
     * @param string $channel
     * @return static|null
     */
    public static function forContact($contactId, $channel)
    {
        if (!$contactId) {
            return null;
        }

        return static::where('contact_id', (int) $contactId)
            ->where('channel', $channel)
            ->first();
    }

    /**
     * Append one message to this thread through the central bulk writer.
     *
     * Kept as the instance-friendly compatibility API for webhook and direct-send
     * callers. The actual insert and every cache invariant live in
     * recordMessages(), so the single and bulk paths cannot drift.
     *
     * @param array $attrs Message attributes; direction is required in practice
     * @return Message|null
     */
    public function recordMessage(array $attrs)
    {
        $messageIds = [];
        $written = static::recordMessages([
            array_merge($attrs, ['thread_id' => $this->id])
        ], $messageIds);

        if (!$written || empty($messageIds[0])) {
            return null;
        }

        $message = Message::find($messageIds[0]);

        // Preserve the instance method's existing contract: callers holding this
        // thread see the cache changes made by the central bulk writer.
        $this->refresh();

        return $message;
    }

    /**
     * Resolve a thread id for every (channel, phone) pair in one round trip.
     *
     * Campaign generation needs a thread per recipient, and doing that one
     * findOrCreateFor() at a time costs a SELECT plus an INSERT per contact —
     * O(audience) round trips on exactly the path that has to stay cheap.
     *
     * INSERT IGNORE carries the concurrency guarantee: the unique index on
     * (channel, phone_number) rejects both a duplicate inside this batch and a
     * thread another request created between the SELECT and the INSERT, so a
     * conversation can never split in two.
     *
     * @param array $pairs list of ['channel' => , 'phone' => , 'contact_id' => ,
     *                     'initiated_by' => ]
     * @return array map of "channel|phone" => thread id
     */
    public static function resolveThreadIds(array $pairs)
    {
        global $wpdb;

        $wanted = [];

        foreach ($pairs as $pair) {
            $phone = trim((string) ($pair['phone'] ?? ''));

            if ($phone === '') {
                continue;
            }

            $channel = !empty($pair['channel']) ? $pair['channel'] : 'sms';
            $key = $channel . '|' . $phone;

            if (!isset($wanted[$key])) {
                $wanted[$key] = [
                    'channel'      => $channel,
                    'phone'        => $phone,
                    'contact_id'   => !empty($pair['contact_id']) ? (int) $pair['contact_id'] : null,
                    'initiated_by' => !empty($pair['initiated_by']) ? $pair['initiated_by'] : 'admin'
                ];
            } elseif (!$wanted[$key]['contact_id'] && !empty($pair['contact_id'])) {
                $wanted[$key]['contact_id'] = (int) $pair['contact_id'];
            }
        }

        if (!$wanted) {
            return [];
        }

        $table = $wpdb->prefix . 'fc_message_threads';
        $now = current_time('mysql');

        $inserts = [];
        $lookups = [];

        foreach ($wanted as $item) {
            // prepare() has no NULL placeholder — it would write an empty string
            // into contact_id — so the contactless case is emitted as the literal
            // and everything else is still prepared.
            $contactId = $item['contact_id'] ? (string) $item['contact_id'] : 'NULL';

            $inserts[] = '(' . $contactId . ',' . $wpdb->prepare(
                '%s,%s,%s,%s,0,0,%s,%s',
                $item['channel'],
                $item['phone'],
                'subscribed',
                $item['initiated_by'],
                $now,
                $now
            ) . ')';

            $lookups[] = $wpdb->prepare('(%s,%s)', $item['channel'], $item['phone']);
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "INSERT IGNORE INTO `$table`
                (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`unread_count`,`created_at`,`updated_at`)
             VALUES " . implode(',', $inserts)
        );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $found = $wpdb->get_results(
            "SELECT id, channel, phone_number, contact_id FROM `$table`
             WHERE (channel, phone_number) IN (" . implode(',', $lookups) . ")"
        );

        $map = [];
        $backfill = [];

        foreach ($found as $thread) {
            $key = $thread->channel . '|' . $thread->phone_number;
            $map[$key] = (int) $thread->id;

            // A thread created before the number belonged to a contact links up
            // now that one is known — but an existing link is never rewritten.
            if ($thread->contact_id === null && !empty($wanted[$key]['contact_id'])) {
                $backfill[(int) $wanted[$key]['contact_id']][] = (int) $thread->id;
            }
        }

        foreach ($backfill as $contactId => $ids) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE `$table` SET contact_id = %d
                     WHERE contact_id IS NULL AND id IN (" . implode(',', array_map('intval', $ids)) . ")",
                    $contactId
                )
            );
        }

        return $map;
    }

    /**
     * Recompute the thread caches that a bulk write cannot maintain row by row.
     *
     * `updated_at` sorts the rail, `last_message_id` selects its preview, and
     * `unread_count` / `has_unread` draw the badge. Anything that inserts or
     * deletes messages in bulk, or stamps `sent_at` on a queued message, has to
     * call this afterwards or the inbox quietly drifts.
     *
     * `updated_at` uses the same COALESCE(sent_at, scheduled_at, created_at) the
     * thread and rail order by, so the two cannot disagree about which message
     * is newest. The read cursor is deliberately left alone — the central writer
     * advances it before this repair when an item represents a human reply.
     *
     * @param array $threadIds
     */
    public static function syncCaches(array $threadIds)
    {
        global $wpdb;

        $threadIds = array_values(array_unique(array_filter(array_map('intval', $threadIds))));

        if (!$threadIds) {
            return;
        }

        $ids = implode(',', $threadIds);
        $threads = $wpdb->prefix . 'fc_message_threads';
        $messages = $wpdb->prefix . 'fc_messages';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "UPDATE `$threads` t
             SET t.updated_at = COALESCE((
                     SELECT MAX(COALESCE(m.sent_at, m.scheduled_at, m.created_at))
                     FROM `$messages` m WHERE m.thread_id = t.id
                 ), t.updated_at),
                 t.last_message_id = (
                     SELECT m.id FROM `$messages` m
                     WHERE m.thread_id = t.id
                     ORDER BY COALESCE(m.sent_at, m.scheduled_at, m.created_at) DESC, m.id DESC
                     LIMIT 1
                 ),
                 t.unread_count = (
                     SELECT COUNT(*) FROM `$messages` m
                     WHERE m.thread_id = t.id
                       AND m.direction = 'inbound'
                       AND m.id > COALESCE(t.last_seen_id, 0)
                 ),
                 t.has_unread = (
                     SELECT COUNT(*) > 0 FROM `$messages` m
                     WHERE m.thread_id = t.id
                       AND m.direction = 'inbound'
                       AND m.id > COALESCE(t.last_seen_id, 0)
                 )
             WHERE t.id IN ($ids)"
        );
    }

    /**
     * Whether this thread already holds a message with the provider's id.
     *
     * Meta and Twilio retry a webhook they did not get a fast 200 for, so
     * without this a slow request turns one inbound message into two identical
     * rows — glaring in a chat thread in a way it never was in a flat log.
     *
     * @param string $providerMessageId
     * @return bool
     */
    public static function hasProviderMessage($providerMessageId, $channel = null)
    {
        if (!$providerMessageId) {
            return false;
        }

        $query = Message::where('provider_message_id', $providerMessageId);

        // Scoped by channel through the thread. The two providers mint ids from
        // independent spaces, so the same string can legitimately name a Twilio
        // SMS and a Meta WhatsApp message; without this the second one is read
        // as a retry of the first and silently dropped.
        //
        // Null means "any channel", which is only for callers that already know
        // the id is channel-unique.
        if ($channel) {
            $query->whereHas('thread', function ($thread) use ($channel) {
                $thread->where('channel', $channel);
            });
        }

        return $query->exists();
    }

    /**
     * Write many messages at once, threads and caches included.
     *
     * This is the only function that inserts into fc_messages. Single-message
     * helpers delegate here, while campaigns and migrations submit whole batches
     * so the hot path remains a handful of queries rather than O(audience).
     *
     * Items whose phone number is unusable are skipped rather than given a
     * conversation of their own, so the returned keys are the caller's authority
     * on what was actually queued — a campaign must not count a recipient it
     * never wrote a row for.
     *
     * An item may carry a pre-resolved `thread_id`, or the channel/phone/contact
     * fields needed to resolve one. `mark_read` advances the thread's read cursor
     * to that inserted row; human messages (`created_by`) do so automatically.
     *
     * @param array $items thread identity plus complete message attributes
     * @param array|null $messageIds receives a map of item key to inserted id
     * @return array the keys of $items a row was inserted for
     */
    public static function recordMessages(array $items, &$messageIds = null)
    {
        global $wpdb;

        $messageIds = [];

        if (!$items) {
            return [];
        }

        $unresolved = array_filter($items, function ($item) {
            return empty($item['thread_id']);
        });
        $threadIds = $unresolved ? static::resolveThreadIds($unresolved) : [];

        if (!$threadIds && count($unresolved) === count($items)) {
            return [];
        }

        $now = current_time('mysql');
        $values = [];
        $written = [];
        $writtenRows = [];
        $touched = [];

        foreach ($items as $key => $item) {
            $threadId = !empty($item['thread_id']) ? (int) $item['thread_id'] : 0;

            if (!$threadId) {
                $phone = trim((string) ($item['phone'] ?? ''));
                $channel = !empty($item['channel']) ? $item['channel'] : 'sms';
                $mapKey = $channel . '|' . $phone;

                if ($phone === '' || !isset($threadIds[$mapKey])) {
                    continue;
                }

                $threadId = $threadIds[$mapKey];
            }

            $touched[$threadId] = $threadId;

            $values[] = '(' . implode(',', [
                (string) $threadId,
                self::sqlValue(!empty($item['direction']) ? $item['direction'] : Message::DIRECTION_OUTBOUND),
                self::sqlValue(isset($item['content']) ? $item['content'] : ''),
                self::sqlValue(!empty($item['ref_id']) ? (int) $item['ref_id'] : null, 'int'),
                self::sqlValue(!empty($item['ref_type']) ? $item['ref_type'] : null),
                self::sqlValue(!empty($item['status']) ? $item['status'] : 'pending'),
                self::sqlValue(!empty($item['provider_message_id']) ? $item['provider_message_id'] : null),
                self::sqlValue(!empty($item['scheduled_at']) ? $item['scheduled_at'] : null),
                self::sqlValue(!empty($item['sent_at']) ? $item['sent_at'] : null),
                self::sqlValue(isset($item['meta']) ? \maybe_serialize($item['meta']) : null),
                self::sqlValue(!empty($item['created_by']) ? (int) $item['created_by'] : null, 'int'),
                self::sqlValue(array_key_exists('created_at', $item) ? $item['created_at'] : $now),
                self::sqlValue(array_key_exists('updated_at', $item) ? $item['updated_at'] : $now)
            ]) . ')';

            $written[] = $key;
            $writtenRows[] = [
                'key' => $key,
                'thread_id' => $threadId,
                'mark_read' => !empty($item['mark_read']) || !empty($item['created_by'])
            ];
        }

        if (!$values) {
            return [];
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $inserted = $wpdb->query(
            "INSERT INTO `{$wpdb->prefix}fc_messages`
                (`thread_id`,`direction`,`content`,`ref_id`,`ref_type`,`status`,
                 `provider_message_id`,`scheduled_at`,`sent_at`,`meta`,`created_by`,
                 `created_at`,`updated_at`)
             VALUES " . implode(',', $values)
        );

        if ($inserted === false) {
            return [];
        }

        $firstMessageId = (int) $wpdb->insert_id;
        $readCursors = [];

        foreach ($writtenRows as $offset => $row) {
            $messageId = $firstMessageId + $offset;
            $messageIds[$row['key']] = $messageId;

            if ($row['mark_read']) {
                $threadId = $row['thread_id'];
                $readCursors[$threadId] = max($readCursors[$threadId] ?? 0, $messageId);
            }
        }

        if ($readCursors) {
            $cases = [];

            foreach ($readCursors as $threadId => $messageId) {
                $cases[] = $wpdb->prepare(
                    'WHEN %d THEN GREATEST(COALESCE(last_seen_id, 0), %d)',
                    $threadId,
                    $messageId
                );
            }

            $readThreadIds = implode(',', array_map('intval', array_keys($readCursors)));

            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                "UPDATE `{$wpdb->prefix}fc_message_threads`
                 SET last_seen_id = CASE id " . implode(' ', $cases) . " ELSE last_seen_id END
                 WHERE id IN ($readThreadIds)"
            );
        }

        static::syncCaches(array_values($touched));

        return $written;
    }

    /**
     * One value for a bulk VALUES list.
     *
     * prepare() has no NULL placeholder — it writes an empty string, which turns
     * a null timestamp into an invalid zero date under strict SQL modes — so
     * nulls are emitted as the literal and everything else is still prepared.
     *
     * @param mixed $value
     * @param string $kind str|int
     * @return string
     */
    protected static function sqlValue($value, $kind = 'str')
    {
        global $wpdb;

        if ($value === null) {
            return 'NULL';
        }

        if ($kind === 'int') {
            return (string) (int) $value;
        }

        return $wpdb->prepare('%s', $value);
    }

    /**
     * Search a thread by its number, or by the name or email of the contact
     * attached to it.
     *
     * LIKE wildcards in the term are escaped so a search for "100%" matches that
     * text rather than everything.
     */
    public function scopeSearchBy($query, $search)
    {
        if (!$search) {
            return $query;
        }

        global $wpdb;
        $search = '%' . $wpdb->esc_like($search) . '%';

        return $query->where(function ($query) use ($search) {
            $query->where('phone_number', 'LIKE', $search)
                ->orWhereHas('subscriber', function ($q) use ($search) {
                    $q->where('first_name', 'LIKE', $search)
                        ->orWhere('last_name', 'LIKE', $search)
                        ->orWhere('email', 'LIKE', $search);
                });
        });
    }

    /**
     * Record the outcome of a direct send onto its conversation thread.
     *
     * fc_sms_messages is retired as a store, so every "send now" path — the
     * contact profile panel, opt-out confirmations, custom sends — writes here
     * instead. Going through MessageThread rather than inserting a row directly
     * is what keeps the rail order and the unread badge true; a bare insert
     * leaves both stale.
     *
     * @param string $channel  sms|whatsapp
     * @param string $phone    the number actually messaged
     * @param int|null $contactId
     * @param string $body     rendered message
     * @param array $result    the channel's send result
     * @param array $extra     ref_type, template_id, and anything for meta
     * @return Message|null
     */
    public static function recordOutbound(string $channel, string $phone, $contactId, string $body, array $result, array $extra = [])
    {
        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id' => $contactId,
            // The business reached out, so this conversation was admin-started
            // unless the contact had already written in — findOrCreateFor only
            // applies this when it creates the thread.
            'initiated_by' => 'admin'
        ]);

        if (!$thread) {
            return null;
        }

        $succeeded = ($result['status'] ?? '') === 'success';

        $meta = isset($extra['meta']) && is_array($extra['meta']) ? $extra['meta'] : [];

        if (!$succeeded) {
            // The provider's own words, kept where the thread can show them.
            $meta['error_message'] = $result['message'] ?? '';
        }

        if (!empty($extra['template_id'])) {
            $meta['template_id'] = (int) $extra['template_id'];
        }

        if (!empty($extra['template_name'])) {
            $meta['template_name'] = $extra['template_name'];
        }

        return $thread->recordMessage([
            'direction'           => 'outbound',
            'content'             => $body,
            'ref_type'            => isset($extra['ref_type']) ? $extra['ref_type'] : 'custom',
            'ref_id'              => isset($extra['ref_id']) ? $extra['ref_id'] : null,
            // Null, not '': an empty string is a value pretending to be an
            // id, and it hides these rows from `provider_message_id IS NULL`.
            'provider_message_id' => !empty($result['provider_message_id']) ? $result['provider_message_id'] : null,
            'status'              => $succeeded ? 'sent' : 'failed',
            'sent_at'             => $succeeded ? current_time('mysql') : null,
            'created_by'          => get_current_user_id() ?: null,
            'meta'                => $meta
        ]);
    }

    /**
     * Put one outbound message on the queue, on its conversation thread.
     *
     * The counterpart to recordOutbound() for everything that does not send
     * immediately: automation actions, opt-in/opt-out confirmations, and a
     * resend. All of them then hand the row's id to the
     * `fluentcrm_send_single_sms` action, which the scheduler picks up.
     *
     * This exists as one function because every caller of that action has to
     * agree with the scheduler about which table the id refers to. While they
     * disagreed, an id from the old table would resolve to an unrelated row in
     * the new one — the wrong message delivered to the wrong person.
     *
     * @param string $channel sms|whatsapp
     * @param string $phone the number to message
     * @param int|null $contactId
     * @param string $body rendered message body
     * @param array $extra ref_type, ref_id, scheduled_at, template_id, meta
     * @return Message|null null when the number is unusable
     */
    public static function queueOutbound(string $channel, string $phone, $contactId, string $body, array $extra = [])
    {
        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id'   => $contactId,
            'initiated_by' => 'admin'
        ]);

        if (!$thread) {
            return null;
        }

        $meta = isset($extra['meta']) && is_array($extra['meta']) ? $extra['meta'] : [];

        if (!empty($extra['template_id'])) {
            $meta['template_id'] = (int) $extra['template_id'];
        }

        return $thread->recordMessage([
            'direction'    => Message::DIRECTION_OUTBOUND,
            'content'      => $body,
            'ref_type'     => isset($extra['ref_type']) ? $extra['ref_type'] : null,
            'ref_id'       => isset($extra['ref_id']) ? $extra['ref_id'] : null,
            'status'       => isset($extra['status']) ? $extra['status'] : Message::STATUS_PENDING,
            'scheduled_at' => isset($extra['scheduled_at']) ? $extra['scheduled_at'] : current_time('mysql'),
            'meta'         => $meta
        ]);
    }
}
