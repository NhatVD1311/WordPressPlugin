<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Providers;

use FluentCampaign\App\Modules\Messaging\Contracts\TemplateApiInterface;

class TwilioWhatsAppDriver extends AbstractWhatsAppDriver implements TemplateApiInterface
{
    const CONTENT_API_BASE = 'https://content.twilio.com/v1';

    protected static array $templateSidCache = [];

    public function getSlug(): string
    {
        return 'twilio_whatsapp';
    }

    public function getLabel(): string
    {
        return __('Twilio WhatsApp', 'fluentcampaign-pro');
    }

    public function hasWebhook(): bool
    {
        return true;
    }

    public function getFields(): array
    {
        return [
            'account_sid'  => [
                'type'      => 'password',
                'label'     => __('Twilio Account SID', 'fluentcampaign-pro'),
                'sub_label' => __('Same Account SID used for your Twilio account', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'auth_token'   => [
                'type'      => 'password',
                'label'     => __('Twilio Auth Token', 'fluentcampaign-pro'),
                'sub_label' => __('Same Auth Token used for your Twilio account', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'from_number'  => [
                'type'      => 'text',
                'label'     => __('WhatsApp From Number', 'fluentcampaign-pro'),
                'sub_label' => __('Your approved Twilio WhatsApp sender number (e.g. +14155238886)', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'messaging_service_sid' => [
                'type'      => 'text',
                'label'     => __('Messaging Service SID', 'fluentcampaign-pro'),
                'sub_label' => __('Optional. Use a Messaging Service sender pool for template messages.', 'fluentcampaign-pro'),
                'required'  => false,
                'default'   => '',
            ],
        ];
    }

    public function send(string $to, string $message, array $settings): array
    {
        $accountSid = trim((string) ($settings['account_sid'] ?? ''));
        $authToken  = trim((string) ($settings['auth_token'] ?? ''));
        $fromNumber = trim((string) ($settings['from_number'] ?? ''));

        if (empty($accountSid) || empty($authToken) || empty($fromNumber)) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Missing Twilio WhatsApp credentials',
                'response'    => null,
            ];
        }

        $url     = "https://api.twilio.com/2010-04-01/Accounts/{$accountSid}/Messages.json";
        $options = [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERPWD        => "{$accountSid}:{$authToken}",
            CURLOPT_POSTFIELDS     => http_build_query([
                'To'   => 'whatsapp:' . $to,
                'From' => 'whatsapp:' . $fromNumber,
                'Body' => $message,
            ]),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        ];

        $result = $this->executeCurl($options, 201);

        if (($result['status'] ?? '') !== 'success') {
            return $result;
        }

        $decodedResponse = json_decode($result['response'], true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($decodedResponse)) {
            $result['response'] = $decodedResponse;

            if (!empty($decodedResponse['sid'])) {
                $result['provider_message_id'] = $decodedResponse['sid'];
            }
        }

        return $result;
    }

    public function fetchTemplates(array $settings): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        $templates = [];
        $url       = self::CONTENT_API_BASE . '/ContentAndApprovals?PageSize=250';
        $pages     = 0;

        do {
            $result = $this->contentRequest($url, $settings, ['method' => 'GET']);

            if ($result['status'] !== 'success') {
                return $result;
            }

            foreach ($result['data']['contents'] ?? [] as $row) {
                $templates[] = $this->normalizeContentRow($row);
            }

            $nextPage = $result['data']['meta']['next_page_url'] ?? '';
            if ($nextPage) {
                $url = $this->absoluteContentUrl($nextPage);

                if (!$url) {
                    return [
                        'status'  => 'error',
                        'message' => __('Twilio returned an unsafe pagination URL.', 'fluentcampaign-pro'),
                        'data'    => [],
                    ];
                }
            } else {
                $url = '';
            }
            $pages++;
        } while ($url && $pages < 20);

        return ['status' => 'success', 'message' => '', 'data' => $templates];
    }

    public function fetchTemplateStatus(string $name, array $settings): array
    {
        $result = $this->fetchTemplates($settings);

        if ($result['status'] !== 'success') {
            return $result;
        }

        foreach ($result['data'] as $template) {
            if (($template['name'] ?? '') === $name) {
                return ['status' => 'success', 'message' => '', 'data' => $template];
            }
        }

        return [
            'status'  => 'success',
            'message' => '',
            'data'    => ['name' => $name, 'status' => 'NOT_FOUND', 'category' => '', 'components' => []],
        ];
    }

    public function submitTemplate(array $template, array $settings): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        $name = sanitize_key($template['name'] ?? '');
        $body = trim((string) ($template['body'] ?? ''));

        if (!$name || !$body) {
            return [
                'status'  => 'error',
                'message' => __('A template needs a name and a body before it can be submitted.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        $language = $this->normalizeLanguage((string) ($template['language'] ?? 'en_US'));
        $content  = $this->contentRequest(self::CONTENT_API_BASE . '/Content', $settings, [
            'method' => 'POST',
            'body'   => wp_json_encode([
                'friendly_name' => $name,
                'language'      => $language,
                'variables'     => $this->buildVariables((array) ($template['variables'] ?? [])),
                'types'         => $this->buildContentTypes($template),
            ]),
        ]);

        if ($content['status'] !== 'success') {
            return $content;
        }

        $sid      = $content['data']['sid'] ?? '';
        $category = strtoupper(sanitize_text_field($template['category'] ?? 'MARKETING'));

        if (!$sid) {
            return [
                'status'  => 'error',
                'message' => __('Twilio did not return a Content SID for this template.', 'fluentcampaign-pro'),
                'data'    => $content['data'],
            ];
        }

        $approval = $this->contentRequest(
            self::CONTENT_API_BASE . '/Content/' . rawurlencode($sid) . '/ApprovalRequests/WhatsApp',
            $settings,
            [
                'method' => 'POST',
                'body'   => wp_json_encode([
                    'name'     => $name,
                    'category' => in_array($category, ['MARKETING', 'UTILITY', 'AUTHENTICATION'], true) ? $category : 'MARKETING',
                ]),
            ]
        );

        if ($approval['status'] !== 'success') {
            return $approval;
        }

        return [
            'status'  => 'success',
            'message' => '',
            'data'    => [
                'id'       => $sid,
                'language' => $language,
                'status'   => $this->normalizeStatus($approval['data']['status'] ?? 'PENDING'),
            ],
        ];
    }

    public function deleteTemplate(string $name, array $settings, string $providerTemplateId = '', string $language = ''): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        $sid = $this->resolveContentSid($name, $language, $settings, $providerTemplateId);

        if (!$sid) {
            return [
                'status'  => 'error',
                'message' => __('Template not found at Twilio.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        return $this->contentRequest(
            self::CONTENT_API_BASE . '/Content/' . rawurlencode($sid) . '?deleteInWaba=true',
            $settings,
            ['method' => 'DELETE']
        );
    }

    public function sendTemplate(string $to, string $templateName, string $language, array $components, array $settings, string $providerTemplateId = ''): array
    {
        $accountSid = trim((string) ($settings['account_sid'] ?? ''));
        $authToken  = trim((string) ($settings['auth_token'] ?? ''));
        $fromNumber = trim((string) ($settings['from_number'] ?? ''));

        if (empty($accountSid) || empty($authToken) || empty($fromNumber)) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Missing Twilio WhatsApp credentials',
                'response'    => null,
            ];
        }

        $contentSid = $this->resolveContentSid($templateName, $language, $settings, $providerTemplateId);

        if (!$contentSid) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Twilio Content template not found: ' . $templateName,
                'response'    => null,
            ];
        }

        $postFields = [
            'To'         => 'whatsapp:' . $to,
            'ContentSid' => $contentSid,
        ];

        $messagingServiceSid = trim((string) ($settings['messaging_service_sid'] ?? ''));
        if ($messagingServiceSid) {
            $postFields['MessagingServiceSid'] = $messagingServiceSid;
            if ($fromNumber) {
                $postFields['From'] = 'whatsapp:' . $fromNumber;
            }
        } else {
            $postFields['From'] = 'whatsapp:' . $fromNumber;
        }

        $variables = $this->contentVariablesFromComponents($components);
        if ($variables) {
            $postFields['ContentVariables'] = wp_json_encode($variables);
        }

        $options = [
            CURLOPT_URL            => "https://api.twilio.com/2010-04-01/Accounts/{$accountSid}/Messages.json",
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERPWD        => "{$accountSid}:{$authToken}",
            CURLOPT_POSTFIELDS     => http_build_query($postFields),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        ];

        $result = $this->executeCurl($options, 201);

        if (($result['status'] ?? '') !== 'success') {
            return $result;
        }

        $decodedResponse = json_decode($result['response'], true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($decodedResponse)) {
            $result['response'] = $decodedResponse;

            if (!empty($decodedResponse['sid'])) {
                $result['provider_message_id'] = $decodedResponse['sid'];
            }
        }

        return $result;
    }

    protected function assertTemplateCredentials(array $settings): ?array
    {
        if (empty(trim((string) ($settings['account_sid'] ?? '')))) {
            return [
                'status'  => 'error',
                'message' => __('Add your Twilio Account SID in settings before using templates.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        if (empty(trim((string) ($settings['auth_token'] ?? '')))) {
            return [
                'status'  => 'error',
                'message' => __('Add your Twilio Auth Token in settings before using templates.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        return null;
    }

    protected function contentRequest(string $url, array $settings, array $args = []): array
    {
        $accountSid = trim((string) ($settings['account_sid'] ?? ''));
        $authToken  = trim((string) ($settings['auth_token'] ?? ''));

        $args = array_merge([
            'timeout'     => 30,
            'redirection' => 0,
            'headers'     => [
                'Authorization' => 'Basic ' . base64_encode($accountSid . ':' . $authToken),
                'Content-Type'  => 'application/json',
            ],
        ], $args);

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return ['status' => 'error', 'message' => $response->get_error_message(), 'data' => []];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code < 200 || $code >= 300) {
            $message = $body['message'] ?? $body['error']['message'] ?? sprintf(
            /* translators: %d: HTTP status code returned by Twilio */
                __('Twilio returned HTTP %d', 'fluentcampaign-pro'),
                $code
            );

            return ['status' => 'error', 'message' => $message, 'data' => $body ?: []];
        }

        return ['status' => 'success', 'message' => '', 'data' => is_array($body) ? $body : []];
    }

    protected function normalizeContentRow(array $row): array
    {
        $approval = $row['approval_requests']['whatsapp']
            ?? $row['approval_request']['whatsapp']
            ?? $row['approvals']['whatsapp']
            ?? $row['whatsapp']
            ?? [];

        $components = $this->componentsFromContentTypes((array) ($row['types'] ?? []));

        return [
            'name'       => $approval['name'] ?? $row['friendly_name'] ?? '',
            'status'     => $this->normalizeStatus($approval['status'] ?? 'PENDING'),
            'category'   => $approval['category'] ?? '',
            'language'   => $row['language'] ?? 'en',
            'components' => $components,
            'id'         => $row['sid'] ?? '',
            'reason'     => $approval['rejection_reason'] ?? '',
        ];
    }

    protected function componentsFromContentTypes(array $types): array
    {
        $type = [];

        foreach (['twilio/text', 'twilio/quick-reply', 'twilio/card'] as $key) {
            if (!empty($types[$key]) && is_array($types[$key])) {
                $type = $types[$key];
                break;
            }
        }

        if (!$type && $types) {
            $type = (array) reset($types);
        }

        $components = [];

        if (!empty($type['title'])) {
            $components[] = ['type' => 'HEADER', 'format' => 'TEXT', 'text' => (string) $type['title']];
        }

        $body = (string) ($type['body'] ?? $type['subtitle'] ?? '');
        if ($body) {
            $components[] = ['type' => 'BODY', 'text' => $body];
        }

        if (!empty($type['subtitle']) && !empty($type['body'])) {
            $components[] = ['type' => 'FOOTER', 'text' => (string) $type['subtitle']];
        }

        $buttons = [];
        foreach ((array) ($type['actions'] ?? []) as $action) {
            $title = sanitize_text_field($action['title'] ?? $action['text'] ?? '');
            if (!$title) {
                continue;
            }

            $actionType = strtoupper((string) ($action['type'] ?? 'QUICK_REPLY'));
            if ($actionType === 'URL') {
                $buttons[] = ['type' => 'URL', 'text' => $title, 'url' => esc_url_raw($action['url'] ?? '')];
            } elseif ($actionType === 'PHONE_NUMBER') {
                $buttons[] = ['type' => 'PHONE_NUMBER', 'text' => $title, 'phone_number' => sanitize_text_field($action['phone'] ?? $action['phone_number'] ?? '')];
            } else {
                $buttons[] = ['type' => 'QUICK_REPLY', 'text' => $title];
            }
        }

        if ($buttons) {
            $components[] = ['type' => 'BUTTONS', 'buttons' => $buttons];
        }

        return $components;
    }

    protected function buildContentTypes(array $template): array
    {
        $body   = $this->combineBody($template);
        $buttons = array_slice((array) ($template['buttons'] ?? []), 0, 3);

        if (!$buttons) {
            return ['twilio/text' => ['body' => $body]];
        }

        $actions       = [];
        $requiresCard  = false;

        foreach ($buttons as $index => $button) {
            $text = sanitize_text_field($button['text'] ?? '');
            if (!$text) {
                continue;
            }

            $type = strtoupper((string) ($button['type'] ?? 'QUICK_REPLY'));
            if ($type === 'URL') {
                $requiresCard = true;
                $actions[] = ['type' => 'URL', 'title' => $text, 'url' => esc_url_raw($button['url'] ?? '')];
            } elseif ($type === 'PHONE_NUMBER') {
                $requiresCard = true;
                $actions[] = ['type' => 'PHONE_NUMBER', 'title' => $text, 'phone' => sanitize_text_field($button['phone_number'] ?? '')];
            } else {
                $actions[] = ['title' => $text, 'id' => sanitize_key($button['id'] ?? 'reply_' . ($index + 1))];
            }
        }

        if ($requiresCard) {
            return [
                'twilio/card' => [
                    'title'    => sanitize_text_field($template['header'] ?? $template['name'] ?? ''),
                    'subtitle' => trim((string) ($template['body'] ?? '')),
                    'actions'  => $actions,
                ],
            ];
        }

        return ['twilio/quick-reply' => ['body' => $body, 'actions' => $actions]];
    }

    protected function combineBody(array $template): string
    {
        return trim(implode("\n\n", array_filter([
            trim((string) ($template['header'] ?? '')),
            trim((string) ($template['body'] ?? '')),
            trim((string) ($template['footer'] ?? '')),
        ])));
    }

    protected function buildVariables(array $variables): array
    {
        $built = [];

        foreach (array_values($variables) as $index => $value) {
            $value = (string) $value;
            if ($value !== '') {
                $built[(string) ($index + 1)] = $value;
            }
        }

        return $built;
    }

    protected function contentVariablesFromComponents(array $components): array
    {
        $variables = [];

        foreach ($components as $component) {
            if (strtolower((string) ($component['type'] ?? '')) !== 'body') {
                continue;
            }

            foreach ((array) ($component['parameters'] ?? []) as $index => $parameter) {
                $value = (string) ($parameter['text'] ?? '');
                if ($value !== '') {
                    $variables[(string) ($index + 1)] = $value;
                }
            }
        }

        return $variables;
    }

    protected function resolveContentSid(string $templateName, string $language, array $settings, string $providerTemplateId = ''): string
    {
        $providerTemplateId = trim($providerTemplateId);

        if (preg_match('/^HX[0-9a-fA-F]{32}$/', $providerTemplateId)) {
            return $providerTemplateId;
        }

        if (preg_match('/^HX[0-9a-fA-F]{32}$/', $templateName)) {
            return $templateName;
        }

        $accountSid = trim((string) ($settings['account_sid'] ?? ''));
        $cacheKey   = $accountSid . '|' . $templateName . '|' . $this->normalizeLanguage($language ?: 'en');

        if (array_key_exists($cacheKey, self::$templateSidCache)) {
            return self::$templateSidCache[$cacheKey];
        }

        $result = $this->fetchTemplates($settings);
        if ($result['status'] !== 'success') {
            self::$templateSidCache[$cacheKey] = '';
            return '';
        }

        $normalizedLanguage = $this->normalizeLanguage($language ?: 'en');

        foreach ($result['data'] as $template) {
            $templateNameKey = (string) ($template['name'] ?? '');
            $templateLangKey = $this->normalizeLanguage((string) ($template['language'] ?? 'en'));
            $templateSid     = (string) ($template['id'] ?? '');

            if ($templateNameKey && $templateLangKey) {
                self::$templateSidCache[$accountSid . '|' . $templateNameKey . '|' . $templateLangKey] = $templateSid;
            }

            if ($templateNameKey !== $templateName) {
                continue;
            }

            if ($language && $templateLangKey !== $normalizedLanguage) {
                continue;
            }

            self::$templateSidCache[$cacheKey] = $templateSid;
            return self::$templateSidCache[$cacheKey];
        }

        self::$templateSidCache[$cacheKey] = '';
        return '';
    }

    protected function normalizeLanguage(string $language): string
    {
        $language = trim($language) ?: 'en';

        if (strpos($language, '_') !== false) {
            $language = substr($language, 0, strpos($language, '_'));
        }

        if (strpos($language, '-') !== false) {
            $language = substr($language, 0, strpos($language, '-'));
        }

        return strtolower($language ?: 'en');
    }

    protected function normalizeStatus(string $status): string
    {
        $status = strtoupper(trim($status));

        if ($status === 'APPROVED') {
            return 'APPROVED';
        }

        if ($status === 'REJECTED') {
            return 'REJECTED';
        }

        if ($status === 'PAUSED') {
            return 'PAUSED';
        }

        if ($status === 'DISABLED' || $status === 'NOT_FOUND') {
            return 'DISABLED';
        }

        return 'PENDING';
    }

    protected function absoluteContentUrl(string $url): string
    {
        $url = trim($url);

        if (!$url || strpos($url, '//') === 0) {
            return '';
        }

        $parts = parse_url($url);

        if (!empty($parts['scheme']) || !empty($parts['host'])) {
            $scheme = strtolower((string) ($parts['scheme'] ?? ''));
            $host   = strtolower((string) ($parts['host'] ?? ''));

            if ($scheme !== 'https' || $host !== 'content.twilio.com') {
                return '';
            }

            return $url;
        }

        if ($url[0] !== '/') {
            return '';
        }

        return 'https://content.twilio.com' . $url;
    }
}
