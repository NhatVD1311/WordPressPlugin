<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Providers;

class WhatsAppDriverManager
{
    /** @var AbstractWhatsAppDriver[] keyed by driver slug */
    private static array $drivers = [];

    /**
     * Register a driver. Built-in drivers are registered in MessageModule.
     * Third-party drivers hook into 'fluent_crm/register_whatsapp_providers':
     *
     *   add_action('fluent_crm/register_whatsapp_providers', function () {
     *       new MyCustomWhatsAppDriver();
     *   });
     */
    public static function register(AbstractWhatsAppDriver $driver): void
    {
        static::$drivers[$driver->getSlug()] = $driver;
    }

    /**
     * @param string $slug
     * @return AbstractWhatsAppDriver|null
     */
    public static function getDriver(string $slug): ?AbstractWhatsAppDriver
    {
        return static::$drivers[$slug] ?? null;
    }

    /**
     * @return AbstractWhatsAppDriver[]
     */
    public static function getAll(): array
    {
        return static::$drivers;
    }

    /**
     * @return string[]
     */
    public static function getSlugs(): array
    {
        return array_keys(static::$drivers);
    }
}
