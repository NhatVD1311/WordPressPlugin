<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Providers;

use FluentCampaign\App\Modules\Messaging\Contracts\TemplateApiInterface;

class MetaCloudDriver extends AbstractWhatsAppDriver implements TemplateApiInterface
{
    // Graph API version used for all Meta Cloud requests. Bump in one place when upgrading.
    // v21.0 matches the version the template endpoints were built and tested against.
    const GRAPH_API_VERSION = 'v21.0';

    public function getSlug(): string
    {
        return 'meta_cloud';
    }

    public function getLabel(): string
    {
        return __('Meta Cloud API (WhatsApp Business)', 'fluentcampaign-pro');
    }

    public function hasWebhook(): bool
    {
        return true;
    }

    public function getFields(): array
    {
        return [
            'waba_id'         => [
                'type'      => 'text',
                'label'     => __('WhatsApp Business Account ID', 'fluentcampaign-pro'),
                'sub_label' => __('Needed for message templates. Found in Meta Business Settings → WhatsApp Accounts', 'fluentcampaign-pro'),
                // Deliberately not required: free-form sending works without it, and
                // marking it required would block existing installs from saving their
                // own settings screen. The template calls fail with an actionable
                // message instead — see assertTemplateCredentials().
                'required'  => false,
                'default'   => '',
            ],
            'phone_number_id' => [
                'type'      => 'text',
                'label'     => __('Phone Number ID', 'fluentcampaign-pro'),
                'sub_label' => __('Found in Meta for Developers → WhatsApp → API Setup', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'access_token'    => [
                'type'      => 'password',
                'label'     => __('Permanent Access Token', 'fluentcampaign-pro'),
                'sub_label' => __('Generate a permanent token from your Meta System User', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'app_secret'      => [
                'type'      => 'password',
                'label'     => __('App Secret', 'fluentcampaign-pro'),
                'sub_label' => __('Used to verify Meta webhook signatures', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
            'verify_token'    => [
                'type'      => 'text',
                'label'     => __('Webhook Verify Token', 'fluentcampaign-pro'),
                'sub_label' => __('Any secret string you choose — must match what you enter in Meta webhook setup', 'fluentcampaign-pro'),
                'required'  => true,
                'default'   => '',
            ],
        ];
    }

    public function send(string $to, string $message, array $settings): array
    {
        $phoneNumberId = trim((string) ($settings['phone_number_id'] ?? ''));
        $accessToken   = trim((string) ($settings['access_token'] ?? ''));

        if (empty($phoneNumberId) || empty($accessToken)) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Missing Meta Cloud API credentials',
                'response'    => null,
            ];
        }

        // Meta expects E.164 without the leading '+' sign
        $payload = wp_json_encode([
            'messaging_product' => 'whatsapp',
            'to'                => ltrim($to, '+'),
            'type'              => 'text',
            'text'              => ['body' => $message],
        ]);

        return $this->dispatch($phoneNumberId, $accessToken, $payload);
    }

    /**
     * POST a composed message payload to the Cloud API messages endpoint.
     *
     * Shared by free-form send() and sendTemplate() so both get the same error
     * shape and the same provider_message_id extraction — the webhook matches
     * delivery receipts on that id, so it must be captured identically for both.
     */
    protected function dispatch(string $phoneNumberId, string $accessToken, string $payload): array
    {
        $options = [
            CURLOPT_URL            => 'https://graph.facebook.com/' . self::GRAPH_API_VERSION . "/{$phoneNumberId}/messages",
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $accessToken,
            ],
        ];

        $result = $this->executeCurl($options, 200);

        if (($result['status'] ?? '') !== 'success') {
            // Surface Meta's own error code and message instead of the generic
            // "Unexpected HTTP response" — the code (e.g. 131047 outside the
            // 24-hour window, 132000 param mismatch) is what makes a failure
            // note actionable, and later retry logic keys off it.
            $body = json_decode((string) ($result['response'] ?? ''), true);

            if (is_array($body) && !empty($body['error'])) {
                $code    = $body['error']['code'] ?? '';
                $detail  = $body['error']['error_data']['details'] ?? '';
                $message = $body['error']['message'] ?? $result['message'];

                $result['message']    = trim(($code !== '' ? "[{$code}] " : '') . $message . ($detail ? ' — ' . $detail : ''));
                $result['error_code'] = $code;
                $result['response']   = $body;
            }

            return $result;
        }

        $decodedResponse = json_decode($result['response'], true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($decodedResponse)) {
            $result['response'] = $decodedResponse;
            $messageId = $decodedResponse['messages'][0]['id'] ?? '';
            if ($messageId) {
                $result['provider_message_id'] = $messageId;
            }
        }

        return $result;
    }

    /* ---------------------------------------------------------------------
     | Template API
     |
     | Ported from Saikat's MetaCloudApiProvider (PR #303). Kept his use of
     | wp_remote_* over the base class's cURL helper: it honours WordPress HTTP
     | filters and proxy configuration, which matters for the template endpoints
     | because they run from admin requests rather than the sending cron.
     --------------------------------------------------------------------- */

    /**
     * Graph endpoint for the WhatsApp Business Account's template catalogue.
     */
    protected function templatesUrl(array $settings, string $suffix = ''): string
    {
        return sprintf(
            'https://graph.facebook.com/%s/%s/message_templates%s',
            self::GRAPH_API_VERSION,
            rawurlencode(trim((string) ($settings['waba_id'] ?? ''))),
            $suffix
        );
    }

    /**
     * Both a WABA id and a token are needed for every template call; fail with a
     * message an admin can act on rather than letting Meta return a 400.
     */
    protected function assertTemplateCredentials(array $settings): ?array
    {
        if (empty(trim((string) ($settings['waba_id'] ?? '')))) {
            return [
                'status'  => 'error',
                'message' => __('Add your WhatsApp Business Account ID in settings before using templates.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        if (empty(trim((string) ($settings['access_token'] ?? '')))) {
            return [
                'status'  => 'error',
                'message' => __('Add your Meta access token in settings before using templates.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        return null;
    }

    protected function templateRequest(string $url, array $settings, array $args = []): array
    {
        $args = array_merge([
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . trim((string) ($settings['access_token'] ?? '')),
                'Content-Type'  => 'application/json',
            ],
        ], $args);

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return ['status' => 'error', 'message' => $response->get_error_message(), 'data' => []];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code < 200 || $code >= 300) {
            $message = $body['error']['message'] ?? sprintf(
            /* translators: %d: HTTP status code returned by Meta */
                __('Meta returned HTTP %d', 'fluentcampaign-pro'),
                $code
            );
            return ['status' => 'error', 'message' => $message, 'data' => $body ?: []];
        }

        return ['status' => 'success', 'message' => '', 'data' => is_array($body) ? $body : []];
    }

    public function fetchTemplates(array $settings): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        $result = $this->templateRequest(
            $this->templatesUrl($settings, '?limit=250'),
            $settings,
            ['method' => 'GET']
        );

        if ($result['status'] !== 'success') {
            return $result;
        }

        $templates = [];
        foreach ($result['data']['data'] ?? [] as $row) {
            $templates[] = [
                'name'       => $row['name'] ?? '',
                'status'     => $row['status'] ?? '',
                'category'   => $row['category'] ?? '',
                'language'   => $row['language'] ?? '',
                'components' => $row['components'] ?? [],
                'id'         => $row['id'] ?? '',
                'reason'     => $row['rejected_reason'] ?? '',
            ];
        }

        return ['status' => 'success', 'message' => '', 'data' => $templates];
    }

    public function fetchTemplateStatus(string $name, array $settings): array
    {
        $result = $this->fetchTemplates($settings);

        if ($result['status'] !== 'success') {
            return $result;
        }

        foreach ($result['data'] as $template) {
            if (($template['name'] ?? '') === $name) {
                return ['status' => 'success', 'message' => '', 'data' => $template];
            }
        }

        // Deleted at Meta but still in our table — the caller marks it DISABLED.
        return [
            'status'  => 'success',
            'message' => '',
            'data'    => ['name' => $name, 'status' => 'NOT_FOUND', 'category' => '', 'components' => []],
        ];
    }

    public function submitTemplate(array $template, array $settings): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        $name = sanitize_key($template['name'] ?? '');
        $body = (string) ($template['body'] ?? '');

        if (!$name || !$body) {
            return [
                'status'  => 'error',
                'message' => __('A template needs a name and a body before it can be submitted.', 'fluentcampaign-pro'),
                'data'    => [],
            ];
        }

        $category = strtoupper(sanitize_text_field($template['category'] ?? 'MARKETING'));
        if (!in_array($category, ['MARKETING', 'UTILITY', 'AUTHENTICATION'], true)) {
            $category = 'MARKETING';
        }

        $result = $this->templateRequest($this->templatesUrl($settings), $settings, [
            'method' => 'POST',
            'body'   => wp_json_encode([
                'name'       => $name,
                'category'   => $category,
                'language'   => sanitize_text_field($template['language'] ?? 'en_US'),
                'components' => $this->buildSubmissionComponents($template),
            ]),
        ]);

        if ($result['status'] === 'success') {
            $result['data'] = [
                'id'     => $result['data']['id'] ?? '',
                'status' => $result['data']['status'] ?? 'PENDING',
            ];
        }

        return $result;
    }

    /**
     * Meta's component array for a submission.
     *
     * Variable sample values are mandatory — a submission without an `example`
     * for every {{n}} is rejected during review, which is the single most common
     * reason a template fails.
     */
    protected function buildSubmissionComponents(array $template): array
    {
        $components = [];

        if ($header = trim((string) ($template['header'] ?? ''))) {
            $components[] = ['type' => 'HEADER', 'format' => 'TEXT', 'text' => $header];
        }

        $body = ['type' => 'BODY', 'text' => (string) $template['body']];

        $samples = array_values(array_filter(array_map(
            'strval',
            (array) ($template['variables'] ?? [])
        ), function ($value) {
            return $value !== '';
        }));

        if ($samples) {
            $body['example'] = ['body_text' => [$samples]];
        }

        $components[] = $body;

        if ($footer = trim((string) ($template['footer'] ?? ''))) {
            $components[] = ['type' => 'FOOTER', 'text' => $footer];
        }

        $buttons = [];
        foreach (array_slice((array) ($template['buttons'] ?? []), 0, 3) as $button) {
            $type = strtoupper($button['type'] ?? 'QUICK_REPLY');
            $text = sanitize_text_field($button['text'] ?? '');

            if (!$text) {
                continue;
            }

            if ($type === 'URL') {
                $buttons[] = ['type' => 'URL', 'text' => $text, 'url' => esc_url_raw($button['url'] ?? '')];
            } elseif ($type === 'PHONE_NUMBER') {
                $buttons[] = ['type' => 'PHONE_NUMBER', 'text' => $text, 'phone_number' => sanitize_text_field($button['phone_number'] ?? '')];
            } else {
                $buttons[] = ['type' => 'QUICK_REPLY', 'text' => $text];
            }
        }

        if ($buttons) {
            $components[] = ['type' => 'BUTTONS', 'buttons' => $buttons];
        }

        return $components;
    }

    public function deleteTemplate(string $name, array $settings, string $providerTemplateId = '', string $language = ''): array
    {
        if ($error = $this->assertTemplateCredentials($settings)) {
            return $error;
        }

        return $this->templateRequest(
            $this->templatesUrl($settings, '?name=' . rawurlencode($name)),
            $settings,
            ['method' => 'DELETE']
        );
    }

    public function sendTemplate(string $to, string $templateName, string $language, array $components, array $settings, string $providerTemplateId = ''): array
    {
        $phoneNumberId = trim((string) ($settings['phone_number_id'] ?? ''));
        $accessToken   = trim((string) ($settings['access_token'] ?? ''));

        if (!$phoneNumberId || !$accessToken) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Missing Meta Cloud API credentials',
                'response'    => null,
            ];
        }

        $payload = [
            'messaging_product' => 'whatsapp',
            // Meta expects E.164 without the leading '+'
            'to'                => ltrim($to, '+'),
            'type'              => 'template',
            'template'          => [
                'name'     => sanitize_text_field($templateName),
                'language' => ['code' => sanitize_text_field($language ?: 'en_US')],
            ],
        ];

        if ($components) {
            $payload['template']['components'] = $components;
        }

        return $this->dispatch($phoneNumberId, $accessToken, wp_json_encode($payload));
    }
}
