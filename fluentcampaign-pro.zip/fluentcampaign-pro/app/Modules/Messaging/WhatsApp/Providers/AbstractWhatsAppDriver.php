<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Providers;

use FluentCampaign\App\Modules\Messaging\Contracts\AbstractDriver;

/**
 * Base class for WhatsApp provider drivers.
 *
 * The settings-field contract and the cURL helper live in AbstractDriver, which
 * is shared with SMS. This class adds WhatsApp-specific registration.
 *
 * Third-party usage:
 *
 *   add_action('fluent_crm/register_whatsapp_providers', function () {
 *       new MyCustomWhatsAppDriver();
 *   });
 *
 * @see AbstractDriver for the abstract methods a driver must implement.
 */
abstract class AbstractWhatsAppDriver extends AbstractDriver
{
    /**
     * Instantiating a driver automatically registers it with the WhatsApp manager.
     */
    public function __construct()
    {
        WhatsAppDriverManager::register($this);
    }

    /**
     * Whether this provider can receive incoming messages via webhook.
     * When true, a webhook URL is shown in settings after credentials are saved.
     */
    public function hasWebhook(): bool
    {
        return false;
    }
}
