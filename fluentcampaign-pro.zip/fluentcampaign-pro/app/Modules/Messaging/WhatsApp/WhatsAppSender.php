<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;

class WhatsAppSender
{
    public static function send(string $to, string $message, ?string $provider = null): array
    {
        if (!WhatsAppHelper::isActive()) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'WhatsApp module is not active',
                'response'    => null,
            ];
        }

        if (!$provider) {
            $provider = WhatsAppHelper::getCurrentProvider();
        }

        $settings         = WhatsAppHelper::getProviderSettings($provider);
        $providerInstance = WhatsAppDriverManager::getDriver($provider);

        if ($providerInstance) {
            return $providerInstance->send($to, $message, $settings);
        }

        return [
            'status'      => 'error',
            'status_code' => 0,
            'message'     => 'WhatsApp provider not registered: ' . $provider,
            'response'    => null,
        ];
    }

    /**
     * Send a pre-approved template message through the configured provider.
     *
     * Mirrors send(): resolves the provider and its settings here so callers
     * (the channel, funnel actions) never touch provider configuration. Fails
     * with the standard result shape when the provider cannot do templates.
     *
     * @param string $to           E.164 phone number
     * @param string $templateName Provider-side template name
     * @param string $language     Template language code, e.g. 'en_US'
     * @param array  $components   Meta components array (may be empty)
     */
    public static function sendTemplate(string $to, string $templateName, string $language, array $components, ?string $provider = null, string $providerTemplateId = ''): array
    {
        if (!WhatsAppHelper::isActive()) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'WhatsApp module is not active',
                'response'    => null,
            ];
        }

        if (!$provider) {
            $provider = WhatsAppHelper::getCurrentProvider();
        }

        $settings         = WhatsAppHelper::getProviderSettings($provider);
        $providerInstance = WhatsAppDriverManager::getDriver($provider);

        if (!$providerInstance) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'WhatsApp provider not registered: ' . $provider,
                'response'    => null,
            ];
        }

        if (!method_exists($providerInstance, 'sendTemplate')) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'Provider does not support template messages: ' . $provider,
                'response'    => null,
            ];
        }

        return $providerInstance->sendTemplate($to, $templateName, $language, $components, $settings, $providerTemplateId);
    }
}
