<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

/**
 * Meta's template rules, enforced before submission.
 *
 * The composer runs the same checks for immediate feedback, but this is the one
 * that counts — a template that reaches Meta malformed is rejected, and a
 * rejection costs a review cycle rather than an error message.
 *
 * Returns errors (block submission) separately from warnings (allow, but the
 * template is likely to be rejected on review).
 */
class TemplateValidator
{
    const MAX_BODY   = 1024;
    const MAX_HEADER = 60;
    const MAX_FOOTER = 60;
    const MAX_BUTTON = 20;
    const MAX_NAME   = 512;

    // Meta rejects bodies that are mostly placeholders. Roughly one variable per
    // 25 characters of body is the threshold reviewers apply in practice.
    const CHARS_PER_VARIABLE = 25;

    /**
     * @return array{errors: string[], warnings: string[]}
     */
    public static function validate(array $template): array
    {
        $errors   = [];
        $warnings = [];

        $name   = trim((string) ($template['name'] ?? ''));
        $body   = (string) ($template['body_text'] ?? $template['body'] ?? '');
        $header = (string) ($template['header_text'] ?? $template['header'] ?? '');
        $footer = (string) ($template['footer_text'] ?? $template['footer'] ?? '');

        if (!preg_match('/^[a-z0-9_]{1,' . self::MAX_NAME . '}$/', $name)) {
            $errors[] = __('Template name must use lowercase letters, numbers and underscores only.', 'fluentcampaign-pro');
        }

        if ($body === '') {
            $errors[] = __('Template body is required.', 'fluentcampaign-pro');
        }

        if (mb_strlen($body) > self::MAX_BODY) {
            $errors[] = sprintf(
            /* translators: 1: current length, 2: maximum length */
                __('Body is %1$d characters; the maximum is %2$d.', 'fluentcampaign-pro'),
                mb_strlen($body),
                self::MAX_BODY
            );
        }

        if (mb_strlen($header) > self::MAX_HEADER) {
            $errors[] = sprintf(
                __('Header is %1$d characters; the maximum is %2$d.', 'fluentcampaign-pro'),
                mb_strlen($header),
                self::MAX_HEADER
            );
        }

        if (mb_strlen($footer) > self::MAX_FOOTER) {
            $errors[] = sprintf(
                __('Footer is %1$d characters; the maximum is %2$d.', 'fluentcampaign-pro'),
                mb_strlen($footer),
                self::MAX_FOOTER
            );
        }

        foreach ((array) ($template['buttons'] ?? []) as $button) {
            $text = (string) ($button['text'] ?? '');
            if (mb_strlen($text) > self::MAX_BUTTON) {
                $errors[] = sprintf(
                    __('Button text "%1$s" is longer than %2$d characters.', 'fluentcampaign-pro'),
                    $text,
                    self::MAX_BUTTON
                );
            }
        }

        $positions = self::variablePositions($body);

        // Must run 1..n with no gaps — Meta maps parameters positionally.
        foreach ($positions as $i => $position) {
            if ($position !== $i + 1) {
                $errors[] = __('Variables must be numbered sequentially from {{1}} with no gaps.', 'fluentcampaign-pro');
                break;
            }
        }

        $trimmed = trim($body);

        if ($trimmed !== '' && preg_match('/^\{\{\d+\}\}/', $trimmed)) {
            $errors[] = __('The body cannot begin with a variable. Add text before it.', 'fluentcampaign-pro');
        }

        if ($trimmed !== '' && preg_match('/\{\{\d+\}\}$/', $trimmed)) {
            $errors[] = __('The body cannot end with a variable. Add text after it.', 'fluentcampaign-pro');
        }

        // Every variable needs a reviewer sample or Meta rejects the submission.
        $samples = (array) ($template['variables'] ?? []);
        foreach ($positions as $position) {
            $sample = $samples[$position] ?? ($samples[$position - 1] ?? '');
            if (trim((string) $sample) === '') {
                $errors[] = sprintf(
                    __('Add an example value for {{%d}} — Meta rejects submissions without one.', 'fluentcampaign-pro'),
                    $position
                );
            }
        }

        if ($positions && $trimmed !== '' && (mb_strlen($trimmed) / count($positions)) < self::CHARS_PER_VARIABLE) {
            $warnings[] = sprintf(
                __('%1$d variables in %2$d characters. Meta often rejects variable-heavy templates — add more fixed text.', 'fluentcampaign-pro'),
                count($positions),
                mb_strlen($trimmed)
            );
        }

        return ['errors' => $errors, 'warnings' => $warnings];
    }

    /**
     * @return int[] Sorted, de-duplicated {{n}} positions found in the body.
     */
    public static function variablePositions(string $body): array
    {
        preg_match_all('/\{\{(\d+)\}\}/', $body, $matches);

        $positions = array_values(array_unique(array_map('intval', $matches[1] ?? [])));
        sort($positions);

        return $positions;
    }
}
