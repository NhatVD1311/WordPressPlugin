<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;

/**
 * Renders a campaign's variable map into Meta's template `components` array.
 *
 * A campaign stores its mapping in settings JSON as
 * `template_variables: { "1": "{{contact.first_name|there}}", ... }` — each
 * value is a FluentCRM smartcode string (with native `|fallback` support), not a
 * second templating layer. This class resolves each mapped smartcode for one
 * subscriber and produces the body-parameter component Meta expects.
 *
 * It fails readably instead of letting Meta reject: a missing mapping, a
 * variable that renders empty with no fallback, a header variable, or a dynamic
 * URL button all produce an error string the failure note can carry. Meta's own
     * rejection for these cases is an opaque 132000 param-count error after the send
     * was already attempted.
 *
 * Scope: body parameters only. Header variables and dynamic (variable) URL
 * buttons are refused with an explanatory error until the composer UI grows a
 * way to map them — refusing is deliberate, because sending without their
 * parameters is a guaranteed Meta rejection.
 */
class TemplateRenderer
{
    /**
     * Build the components array for one subscriber.
     *
     * @param MessageTemplate $template    Approved WhatsApp template row
     * @param array           $variableMap Position => smartcode string, keys "1"..
     * @param object          $subscriber  \FluentCrm\App\Models\Subscriber
     *
     * @return array {components: array, error: string|null}
     */
    public static function render(MessageTemplate $template, array $variableMap, $subscriber, $message = null): array
    {
        // Unsupported variable placements fail before any rendering work.
        if ($unsupported = self::getUnsupportedReason($template)) {
            return self::error($unsupported);
        }

        $positions = $template->getVariablePositions();

        // A template without variables needs no components at all.
        if (!$positions) {
            return ['components' => [], 'error' => null];
        }

        $parameters = [];
        $missing    = [];
        $empty      = [];

        foreach ($positions as $position) {
            $smartcode = trim((string) ($variableMap[(string) $position] ?? $variableMap[$position] ?? ''));

            if ($smartcode === '') {
                $missing[] = '{{' . $position . '}}';
                continue;
            }

            $value = $message ? WhatsAppHelper::applyRecipientSmartCodes($smartcode, $message) : $smartcode;
            $value = $subscriber
                ? WhatsAppHelper::parseMessageContent($value, $subscriber)
                : WhatsAppHelper::stripUnresolvedSmartCodes(wp_strip_all_tags($value));

            // Meta rejects parameters containing newlines, tabs or 4+ consecutive
            // spaces; collapse rather than fail, since the data is otherwise fine.
            $value = trim(preg_replace('/\s+/u', ' ', $value));

            if ($value === '') {
                $empty[] = '{{' . $position . '}}';
                continue;
            }

            $parameters[] = ['type' => 'text', 'text' => $value];
        }

        if ($missing) {
            return self::error(sprintf(
            /* translators: 1: template name, 2: comma-separated variable placeholders */
                __('Template "%1$s" has unmapped variables: %2$s. Map every variable in the campaign composer.', 'fluentcampaign-pro'),
                $template->name,
                implode(', ', $missing)
            ));
        }

        if ($empty) {
            return self::error(sprintf(
            /* translators: 1: template name, 2: comma-separated variable placeholders */
                __('Template "%1$s" variables rendered empty for this contact: %2$s. Add a fallback, e.g. {{contact.first_name|there}}.', 'fluentcampaign-pro'),
                $template->name,
                implode(', ', $empty)
            ));
        }

        return [
            'components' => [
                ['type' => 'body', 'parameters' => $parameters],
            ],
            'error'      => null,
        ];
    }

    /**
     * Why this template cannot be rendered at all, or null when it can.
     *
     * Placement, not mapping: these are properties of the template itself, so
     * the answer is the same for every contact and every variable map. That is
     * what lets the composer and the automation editor ask the question up
     * front — offering a template here that render() will refuse is how a send
     * ends up failing only once it reaches the queue.
     *
     * Kept deliberately in step with render(): render() calls this first, so
     * the two can never disagree.
     */
    public static function getUnsupportedReason(MessageTemplate $template): ?string
    {
        if (preg_match('/\{\{\d+\}\}/', (string) $template->header_text)) {
            return sprintf(
            /* translators: %s: template name */
                __('Template "%s" uses a header variable, which campaigns cannot map yet. Choose a template with a static header.', 'fluentcampaign-pro'),
                $template->name
            );
        }

        foreach ((array) $template->buttons as $button) {
            if (strpos((string) ($button['url'] ?? ''), '{{') !== false) {
                return sprintf(
                /* translators: %s: template name */
                    __('Template "%s" uses a dynamic URL button, which campaigns cannot map yet. Choose a template with static buttons.', 'fluentcampaign-pro'),
                    $template->name
                );
            }
        }

        return null;
    }

    protected static function error(string $message): array
    {
        return ['components' => [], 'error' => $message];
    }
}
