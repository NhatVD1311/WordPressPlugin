<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Models\WhatsAppCampaign;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppSender;
use FluentCampaign\App\Modules\Messaging\Models\Message as CrmMessage;
use FluentCrm\Framework\Support\Arr;

/**
 * The WhatsApp channel. A thin adapter over WhatsAppHelper/WhatsAppSender,
 * plus the template-vs-free-form mode decision for queued sends.
 *
 * Meta only accepts free-form text inside the 24-hour customer-service window
 * (outside it, error 131047); campaigns to a cold list must therefore send
 * pre-approved templates. sendQueued() makes that choice per message — see
 * resolveSendMode() for the rule. docs/MESSAGING_MODULE_REFACTOR.md §6e/§8.
 */
class WhatsAppChannel implements ChannelInterface
{
    // Meta's documented maximum body length for a text message.
    const MAX_LENGTH = 4096;

    public function getSlug(): string
    {
        return LegacyMessage::CHANNEL_WHATSAPP;
    }

    public function getLabel(): string
    {
        return 'WhatsApp';
    }

    public function isActive(): bool
    {
        return WhatsAppHelper::isActive();
    }

    public function getMaxLength(): int
    {
        return self::MAX_LENGTH;
    }

    /**
     * Whether free-form text is allowed for this contact right now, or whether an
     * approved template is required. See SessionWindow for the rule.
     */
    public function isSessionOpen(int $subscriberId): bool
    {
        return SessionWindow::isOpenForContact($subscriberId);
    }

    public function parseMessageContent(string $content, $subscriber): string
    {
        return WhatsAppHelper::parseMessageContent($content, $subscriber);
    }

    public function send(string $to, string $message, ?string $provider = null): array
    {
        return WhatsAppSender::send($to, $message, $provider);
    }

    /**
     * Decide how a queued message should be sent, without sending it.
     *
     * Separated from sendQueued() so the decision is testable with no network:
     *
     *   1. A template is configured (message.template_id, else the campaign's
     *      settings.template_id) → template mode, with the mapped
     *      template_variables rendered into Meta components. The map comes from
     *      the campaign for campaign sends and from the message's own settings
     *      for automation sends. The template must exist and be APPROVED — Meta
     *      rejects PAUSED/REJECTED templates at send time, so we fail locally
     *      with the real reason.
     *   2. No template, but the contact messaged us within 24 hours → free-form.
     *   3. No template, window closed → fail readably here rather than letting
     *      Meta reject with 131047 after the send already burned daily capacity.
     *
     * @param object $message    fc_messages row (Message model)
     * @param object $subscriber \FluentCrm\App\Models\Subscriber
     *
     * @return array {mode: 'template'|'session'|'fail',
     *                template: MessageTemplate|null,
     *                components: array, error: string|null}
     */
    /**
     * Templates already resolved during this request, keyed by id. A campaign
     * batch reuses one or a handful of templates across ~30 messages, so this
     * collapses per-message lookups into one query per distinct template.
     * Null results are cached too, so a missing template costs one query.
     *
     * @var array<int, MessageTemplate|null>
     */
    protected static $templateCache = [];

    /**
     * Campaigns already resolved during this request, keyed by id, null included.
     *
     * A send batch is up to 30 messages from the same campaign; without this the
     * template source is looked up once per message.
     *
     * @var array<int, WhatsAppCampaign|null>
     */
    protected static $campaignCache = [];

    public function resolveSendMode($message, $subscriber): array
    {
        $meta = is_array($message->meta) ? $message->meta : [];
        $subscriber = self::hydrateAutomationSubscriberContext($subscriber, $message, $meta);

        $templateId   = (int) Arr::get($meta, 'template_id');
        $variableMap  = [];

        // The campaign is the usual template source. Read through the
        // channel-scoped model so an SMS campaign id can never resolve here.
        $campaign = null;
        if ($message->ref_id && $message->ref_type === CrmMessage::REF_CAMPAIGN) {
            $campaignId = (int) $message->ref_id;

            if (!array_key_exists($campaignId, self::$campaignCache)) {
                self::$campaignCache[$campaignId] = WhatsAppCampaign::find($campaignId);
            }

            $campaign = self::$campaignCache[$campaignId];
        }

        if ($campaign) {
            if (!$templateId) {
                $templateId = (int) Arr::get($campaign->settings, 'template_id');
            }
            $variableMap = (array) Arr::get($campaign->settings, 'template_variables', []);
        } else {
            // Automation sends have no campaign to carry the map, so the funnel
            // action stores it on the message itself in the same shape.
            $variableMap = self::readMessageVariableMap($message);
        }

        if (!$templateId) {
            // Keyed on the thread, not the contact: a conversation with someone
            // who is not a contact still has a 24-hour window, and it is exactly
            // those conversations that most need one.
            if (SessionWindow::isOpen((int) $message->thread_id)) {
                return ['mode' => 'session', 'template' => null, 'components' => [], 'error' => null];
            }

            return [
                'mode'       => 'fail',
                'template'   => null,
                'components' => [],
                'error'      => __('No template selected and the contact has not messaged within 24 hours — Meta only accepts template messages outside that window. Select an approved template for this campaign.', 'fluentcampaign-pro'),
            ];
        }

        if (!array_key_exists($templateId, self::$templateCache)) {
            self::$templateCache[$templateId] = MessageTemplate::forChannel(LegacyMessage::CHANNEL_WHATSAPP)->find($templateId);
        }

        $template = self::$templateCache[$templateId];

        if (!$template) {
            return [
                'mode'       => 'fail',
                'template'   => null,
                'components' => [],
                'error'      => sprintf(
                /* translators: %d: template id stored on the campaign */
                    __('The selected WhatsApp template (#%d) no longer exists. Pick another template for this campaign.', 'fluentcampaign-pro'),
                    $templateId
                ),
            ];
        }

        $currentProvider = WhatsAppHelper::getCurrentProvider();
        if (!TemplateProviderScope::isCurrentProvider((string) $template->provider, $currentProvider)) {
            $providerLabels = [];
            foreach (WhatsAppHelper::getApiOptions()['providers'] ?? [] as $provider => $definition) {
                $providerLabels[$provider] = $definition['label'] ?? ucwords(str_replace('_', ' ', $provider));
            }

            $scopeMeta = TemplateProviderScope::meta((string) $template->provider, $currentProvider, $providerLabels);

            return [
                'mode'       => 'fail',
                'template'   => $template,
                'components' => [],
                'error'      => sprintf(
                /* translators: 1: template name, 2: disabled reason */
                    __('Template "%1$s" cannot be sent with the current WhatsApp provider. %2$s', 'fluentcampaign-pro'),
                    $template->name,
                    $scopeMeta['disabled_reason']
                ),
            ];
        }

        if ($template->status !== MessageTemplate::STATUS_APPROVED) {
            return [
                'mode'       => 'fail',
                'template'   => $template,
                'components' => [],
                'error'      => sprintf(
                /* translators: 1: template name, 2: template status */
                    __('Template "%1$s" is %2$s, not APPROVED. Re-sync templates or pick an approved one.', 'fluentcampaign-pro'),
                    $template->name,
                    $template->status
                ),
            ];
        }

        $rendered = TemplateRenderer::render($template, $variableMap, $subscriber, $message);

        if ($rendered['error']) {
            return ['mode' => 'fail', 'template' => $template, 'components' => [], 'error' => $rendered['error']];
        }

        return ['mode' => 'template', 'template' => $template, 'components' => $rendered['components'], 'error' => null];
    }

    /**
     * The template variable map an automation stored on the message row.
     *
     * Lives under `meta.settings`, which is where the migration put the legacy
     * `settings` column and where the funnel action writes it now. Decoded
     * defensively — a legacy or hand-written row may hold anything, and a string
     * left over from the old JSON column is still possible.
     *
     * @return array<string, string>
     */
    protected static function readMessageVariableMap($message): array
    {
        $meta = is_array($message->meta) ? $message->meta : [];

        $settings = Arr::get($meta, 'settings');

        if (is_string($settings)) {
            $settings = json_decode($settings, true);
        }

        if (!is_array($settings)) {
            return [];
        }

        $map = Arr::get($settings, 'template_variables', []);

        return is_array($map) ? $map : [];
    }

    /**
     * Send one queued message, in the mode resolveSendMode() picked.
     *
     * When a template row was resolved its id is stamped on the message before
     * dispatch — success or failure — so reporting can break results down by
     * template.
     */
    public function sendQueued($message, $subscriber, string $to): array
    {
        $subscriber = self::hydrateAutomationSubscriberContext($subscriber, $message);
        $decision = $this->resolveSendMode($message, $subscriber);

        $meta = is_array($message->meta) ? $message->meta : [];

        // Stamp the resolved template on the row before dispatch, success or
        // failure, so reporting can break results down by template. It goes in
        // meta because fc_messages has no template_id column.
        if ($decision['template'] && (int) Arr::get($meta, 'template_id') !== (int) $decision['template']->id) {
            $meta['template_id'] = (int) $decision['template']->id;
            CrmMessage::where('id', $message->id)->update(['meta' => \maybe_serialize($meta)]);
        }

        if ($decision['mode'] === 'fail') {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => $decision['error'],
                'response'    => null,
            ];
        }

        if ($decision['mode'] === 'template') {
            return WhatsAppSender::sendTemplate(
                $to,
                $decision['template']->name,
                (string) $decision['template']->language,
                $decision['components'],
                null,
                (string) $decision['template']->provider_template_id
            );
        }

        // Session mode: free-form text inside the 24-hour window.
        $body = WhatsAppHelper::applyRecipientSmartCodes((string) $message->content, $message);
        $body = $subscriber
            ? $this->parseMessageContent($body, $subscriber)
            : WhatsAppHelper::stripUnresolvedSmartCodes(wp_strip_all_tags($body));

        return $this->send($to, $body);
    }

    /**
     * Restore the funnel subscriber context that automation smartcodes need.
     *
     * Messaging reloads the contact from the conversation thread before send, so
     * transient properties added by the funnel runner are gone here. Event-scoped
     * smartcodes such as {{cart_order.order_id}} read the funnel subscriber row to
     * find source_ref_id, so automation sends carry that id in message meta and
     * reattach it before parsing.
     */
    protected static function hydrateAutomationSubscriberContext($subscriber, $message, ?array $meta = null)
    {
        if (!$subscriber || !is_object($subscriber) || !is_object($message)) {
            return $subscriber;
        }

        if (($message->ref_type ?? null) !== CrmMessage::REF_AUTOMATION || !empty($subscriber->funnel_subscriber_id)) {
            return $subscriber;
        }

        $meta = $meta ?? (is_array($message->meta) ? $message->meta : []);
        $funnelSubscriberId = (int) Arr::get($meta, 'funnel_subscriber_id');

        if ($funnelSubscriberId > 0) {
            $subscriber->funnel_subscriber_id = $funnelSubscriberId;
        }

        return $subscriber;
    }

    public function getMenuItems(string $urlBase): array
    {
        return [
            [
                'key'         => 'whatsapp_campaigns',
                'label'       => __('WhatsApp Campaigns', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/whatsapp/campaigns',
                'description' => __('Send WhatsApp campaigns to contacts who have opted in to WhatsApp messaging', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.0016 2.5C5.85953 2.5 2.50156 5.85797 2.50156 10C2.50156 11.4148 2.89375 12.7387 3.57578 13.8695L2.5 17.5L6.25781 16.4602C7.35391 17.0961 8.63516 17.4609 10.0016 17.4609C14.1437 17.4609 17.5016 14.1029 17.5016 9.96094C17.5016 5.81898 14.1437 2.5 10.0016 2.5ZM10.0016 16.0859C8.74844 16.0859 7.57969 15.7211 6.59609 15.0945L4.53125 15.6641L5.11719 13.6602C4.41406 12.6367 4.00156 11.3652 4.00156 10C4.00156 6.68629 6.68789 4 10.0016 4C13.3153 4 16.0016 6.68629 16.0016 10C16.0016 13.3137 13.3153 16.0859 10.0016 16.0859ZM13.2891 11.8047C13.1094 11.7148 12.2266 11.2812 12.0625 11.2227C11.8984 11.1641 11.7789 11.1348 11.6594 11.3145C11.5398 11.4941 11.1961 11.8945 11.0914 12.0141C10.9867 12.1336 10.882 12.1484 10.7023 12.0586C10.5227 11.9688 9.94453 11.7793 9.25937 11.168C8.72656 10.6926 8.36719 10.1055 8.2625 9.92578C8.15781 9.74609 8.25156 9.64883 8.34141 9.55937C8.42227 9.47852 8.52109 9.34883 8.61094 9.24414C8.70078 9.13945 8.73047 9.06484 8.78906 8.94531C8.84766 8.82578 8.81797 8.72109 8.77305 8.63125C8.72812 8.54141 8.37031 7.65742 8.22109 7.29805C8.07578 6.94805 7.92852 6.99609 7.81875 6.99062C7.71484 6.98555 7.59531 6.98438 7.47578 6.98438C7.35625 6.98438 7.16172 7.02930 6.99766 7.20898C6.83359 7.38867 6.37109 7.82227 6.37109 8.70625C6.37109 9.59023 7.01250 10.4443 7.10234 10.5639C7.19219 10.6834 8.36445 12.4902 10.1594 13.2656C10.5863 13.4500 10.9195 13.5602 11.1793 13.6426C11.6078 13.7789 11.9977 13.7596 12.3059 13.7137C12.6496 13.6623 13.3668 13.2801 13.5160 12.8613C13.6652 12.4426 13.6652 12.0836 13.6203 12.0141C13.5754 11.9445 13.4559 11.8945 13.2891 11.8047Z" fill="#525866"/>
                            </svg>'
            ],
        ];
    }

    /**
     * Public WhatsApp-only hooks. These predate the channel abstraction and are
     * kept firing for backward compatibility with existing integrations.
     */
    public function onSent($message, array $result): void
    {
        do_action('fluent_crm/whatsapp_sent', $message, $result);
    }

    public function onFailed($message, string $error): void
    {
        do_action('fluent_crm/whatsapp_failed', $message, $error);
    }
}
