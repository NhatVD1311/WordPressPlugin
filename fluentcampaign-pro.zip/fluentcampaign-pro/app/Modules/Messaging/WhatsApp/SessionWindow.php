<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;


/**
 * WhatsApp's 24-hour customer-service window.
 *
 * Inside the window a business may reply with free-form text. Outside it, only an
 * approved template will be accepted — Meta rejects free-form sends with error
 * 131047. This class is what the channel asks before choosing between the two.
 *
 * Ported from Saikat's WhatsAppSessionManager (PR #303) with the backing store
 * swapped. His version kept a dedicated fc_whatsapp_sessions table with rows to
 * open, extend and expire. Here the window is *derived* from the messages table:
 *
 *   window is open  ⟺  an inbound message exists within the last 24 hours
 *
 * That has three advantages over a session table. It cannot drift out of sync
 * with reality, because the messages are the source of truth. It needs no expiry
 * cron, because expiry is just the timestamp comparison. And it is one indexed
 * lookup on (thread_id, direction).
 *
 * It is also more faithful to Meta's rule. His table opened a window when a
 * template was *delivered*, but delivery opens a billing conversation, not a
 * customer-service window — only a customer-initiated message does that. Deriving
 * from inbound messages models the rule that actually governs free-form sending.
 */
class SessionWindow
{
    const DURATION = 86400; // 24 hours, per Meta's customer-service window

    /**
     * Per-request memo of lastInboundAt() results, keyed by subscriber id. A
     * campaign batch checks the window once per template-less message; without
     * this each check is its own latest-row query. Inbound messages only arrive
     * via webhooks, which call forget() after storing the row, so a memoized
     * value cannot go stale within a request.
     *
     * @var array<int, string|null> keyed by thread id
     */
    protected static $lastInboundCache = [];

    /**
     * Drop the memoized timestamp for a thread. Called after storing a new
     * inbound message so a funnel send in the same request sees the open window.
     */
    public static function forget(int $threadId): void
    {
        unset(self::$lastInboundCache[$threadId]);
    }

    /**
     * Timestamp of the contact's most recent inbound WhatsApp message.
     */
    /**
     * Resolve a contact's WhatsApp thread id, or 0 when they have none.
     *
     * Exists so the contact-facing callers — the profile panel and the campaign
     * scheduler, which both know a subscriber and not a thread — keep working
     * now that the window is keyed on the thread. A contact who has never been
     * messaged has no thread and therefore no window, which is the correct
     * answer rather than an error.
     */
    protected static function threadIdForContact(int $contactId): int
    {
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::forContact($contactId, 'whatsapp');

        return $thread ? (int) $thread->id : 0;
    }

    public static function isOpenForContact(int $contactId): bool
    {
        return self::isOpen(self::threadIdForContact($contactId));
    }

    public static function getStatsForContact(int $contactId): array
    {
        return self::getStats(self::threadIdForContact($contactId));
    }

    public static function forgetContact(int $contactId): void
    {
        self::forget(self::threadIdForContact($contactId));
    }

    /**
     * Timestamp of the thread's most recent inbound message.
     *
     * Keyed on the thread, not the contact. A conversation can exist before its
     * number is a contact at all — someone messaging the business number for the
     * first time — and such a thread has no subscriber id to key on, so the old
     * signature could not express the question for exactly the conversations
     * that most need a window.
     *
     * @param int $threadId fc_message_threads row id
     */
    public static function lastInboundAt(int $threadId): ?string
    {
        if (!$threadId) {
            return null;
        }

        if (!array_key_exists($threadId, self::$lastInboundCache)) {
            $row = \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $threadId)
                ->where('direction', 'inbound')
                ->orderBy('created_at', 'DESC')
                ->first();

            self::$lastInboundCache[$threadId] = $row ? $row->created_at : null;
        }

        return self::$lastInboundCache[$threadId];
    }

    public static function isOpen(int $threadId): bool
    {
        $last = self::lastInboundAt($threadId);

        if (!$last) {
            return false;
        }

        // created_at is stored in the WP timezone, so the comparison must use
        // the WP-local clock too — time() would stretch or shrink the 24-hour
        // window by the site's UTC offset.
        return (strtotime($last) + self::DURATION) > current_time('timestamp');
    }

    /**
     * When the current window closes, or null when none is open.
     */
    public static function expiresAt(int $threadId): ?string
    {
        $last = self::lastInboundAt($threadId);

        if (!$last) {
            return null;
        }

        $expires = strtotime($last) + self::DURATION;

        // gmdate() formats the epoch as-is; the epoch here is already WP-local
        // because created_at is stored in the WP timezone.
        return $expires > current_time('timestamp') ? gmdate('Y-m-d H:i:s', $expires) : null;
    }

    /**
     * Which message form the channel should use for this contact right now.
     *
     * @return string 'session' (free-form) or 'template'
     */
    public static function getRecommendedMessageType(int $threadId): string
    {
        return self::isOpen($threadId) ? 'session' : 'template';
    }

    /**
     * Summary for the contact profile panel.
     */
    public static function getStats(int $threadId): array
    {
        $last = self::lastInboundAt($threadId);
        $open = $last && (strtotime($last) + self::DURATION) > current_time('timestamp');

        $expiresAt = $open ? gmdate('Y-m-d H:i:s', strtotime($last) + self::DURATION) : null;

        return [
            'has_active_session' => $open,
            'last_inbound_at'    => $last,
            'expires_at'         => $expiresAt,
            // Offset-qualified copies. The naive strings above are site-local
            // wall clock, which a browser in another timezone reads as its own —
            // enough to show an already-closed window as hours remaining.
            'last_inbound_at_iso' => WhatsAppHelper::toIso($last),
            'expires_at_iso'      => WhatsAppHelper::toIso($expiresAt),
            'inbound_count'      => $threadId
                ? (int) \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $threadId)
                    ->where('direction', 'inbound')
                    ->count()
                : 0,
        ];
    }
}
