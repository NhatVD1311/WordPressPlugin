<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

class TemplateProviderScope
{
    public static function isCurrentProvider(string $templateProvider, string $currentProvider): bool
    {
        return $templateProvider !== '' && $currentProvider !== '' && $templateProvider === $currentProvider;
    }

    public static function meta(string $templateProvider, string $currentProvider, array $providerLabels = []): array
    {
        $providerLabel = self::providerLabel($templateProvider, $providerLabels);
        $currentLabel  = self::providerLabel($currentProvider, $providerLabels);
        $isCurrent     = self::isCurrentProvider($templateProvider, $currentProvider);

        return [
            'provider_label'      => $providerLabel,
            'current_provider'    => $currentProvider,
            'current_provider_label' => $currentLabel,
            'is_current_provider' => $isCurrent,
            'is_selectable'       => $isCurrent,
            'disabled_reason'     => $isCurrent ? '' : self::disabledReason($providerLabel, $currentLabel),
        ];
    }

    protected static function providerLabel(string $provider, array $providerLabels): string
    {
        if ($provider && !empty($providerLabels[$provider])) {
            return (string) $providerLabels[$provider];
        }

        return $provider ? ucwords(str_replace('_', ' ', $provider)) : __('Unknown Provider', 'fluentcampaign-pro');
    }

    protected static function disabledReason(string $providerLabel, string $currentLabel): string
    {
        if (!$currentLabel || $currentLabel === __('Unknown Provider', 'fluentcampaign-pro')) {
            return __('Select and save a WhatsApp provider before using templates in campaigns.', 'fluentcampaign-pro');
        }

        return sprintf(
            /* translators: 1: template provider label, 2: current provider label */
            __('This template belongs to %1$s. Current provider is %2$s.', 'fluentcampaign-pro'),
            $providerLabel,
            $currentLabel
        );
    }
}
