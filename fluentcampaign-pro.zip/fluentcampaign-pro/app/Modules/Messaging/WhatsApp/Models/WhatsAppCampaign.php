<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Models;

use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;

/**
 * WhatsApp campaign model.
 *
 * A channel-scoped view of the shared `fc_sms_campaigns` table. It extends
 * MessageCampaign so every piece of shared campaign behaviour — recipient
 * selection, scheduling, labels, stats, message relations — is inherited
 * unchanged; this subclass only pins the `channel` discriminator.
 *
 * Storage stays shared (single-table inheritance), the same pattern CompanyNote
 * uses to disguise itself from SubscriberNote on `fc_subscriber_notes`:
 *
 *   - a global scope constrains every read to `channel = 'whatsapp'`, so a bare
 *     WhatsAppCampaign::get() never returns SMS rows;
 *   - a `creating` hook forces `channel = 'whatsapp'` on every insert, so a row
 *     can never be persisted against another channel's consent column.
 *
 * Global scopes are keyed per class in the ORM, so registering one here does not
 * affect MessageCampaign (which keeps seeing every channel) or the SMS side.
 *
 * The `object_type` discriminator written to the shared `fc_meta`,
 * `fc_term_relations` and `fc_subscriber_pivot` tables is intentionally NOT
 * overridden. MessageCampaign's meta/label/pivot methods reference the frozen
 * MessageCampaign::OBJECT_TYPE via `self::`, which binds to the parent constant
 * regardless of the calling subclass — so a WhatsApp campaign's meta, labels and
 * pivot rows live in the same namespace as SMS and remain readable by the free
 * plugin's fluentcrm_*_sms_campaign_meta() helpers. Campaign ids are unique
 * across the table, so nothing collides. Do NOT add an OBJECT_TYPE override
 * here — see the frozen-surface note on MessageCampaign::OBJECT_TYPE.
 */
class WhatsAppCampaign extends MessageCampaign
{
    public static function boot()
    {
        parent::boot();

        // Force the channel on write. Runs after the parent's creating hook, so
        // whatever a caller passed for `channel` is overridden — this model is
        // WhatsApp by definition.
        static::creating(function ($model) {
            $model->channel = self::CHANNEL_WHATSAPP;
        });

        // Constrain every read to the WhatsApp channel. Keyed to this class, so
        // MessageCampaign (all channels) and SMS reads are untouched.
        static::addGlobalScope('channel', function ($builder) {
            $builder->where('channel', self::CHANNEL_WHATSAPP);
        });
    }
}
