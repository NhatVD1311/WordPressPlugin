<?php

namespace FluentCampaign\App\Modules\Messaging\Services;

class PhoneNumberNormalizer
{
    public function normalize($value, $defaultCountry)
    {
        if (is_array($value) || is_object($value)) {
            throw new \InvalidArgumentException('Phone number must be a scalar value.');
        }

        $value = trim((string) $value);
        if ($value === '') {
            throw new \InvalidArgumentException('Phone number is required.');
        }

        $country = strtoupper(sanitize_key((string) $defaultCountry));
        if (!preg_match('/^[A-Z]{2}$/', $country)) {
            throw new \InvalidArgumentException('A valid default country is required.');
        }

        if (!class_exists('\libphonenumber\PhoneNumberUtil')) {
            return $this->normalizeE164Only($value);
        }

        $util = \libphonenumber\PhoneNumberUtil::getInstance();
        $number = $util->parse($value, $country);

        if ($number->hasExtension()) {
            throw new \InvalidArgumentException('Phone number extensions are not supported.');
        }

        if (!$util->isPossibleNumber($number) || !$util->isValidNumber($number)) {
            throw new \InvalidArgumentException('Phone number is not valid.');
        }

        $normalized = $util->format($number, \libphonenumber\PhoneNumberFormat::E164);

        if (strlen($normalized) > 20) {
            throw new \InvalidArgumentException('Phone number is too long.');
        }

        return $normalized;
    }

    protected function normalizeE164Only($value)
    {
        $normalized = preg_replace('/[\s().-]+/', '', (string) $value);

        if (!preg_match('/^\+[1-9]\d{7,14}$/', $normalized)) {
            throw new \RuntimeException('Phone normalization dependency is required for non-E.164 numbers.');
        }

        if (strlen($normalized) > 20) {
            throw new \InvalidArgumentException('Phone number is too long.');
        }

        return $normalized;
    }
}
