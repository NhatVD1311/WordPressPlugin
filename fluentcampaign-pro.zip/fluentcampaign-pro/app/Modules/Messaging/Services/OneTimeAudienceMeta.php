<?php

namespace FluentCampaign\App\Modules\Messaging\Services;

use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCrm\Framework\Support\Arr;

class OneTimeAudienceMeta
{
    const IMPORT_META_KEY = '_one_time_audience_import';

    public static function getImportSession($campaignId)
    {
        $session = fluentcrm_get_sms_campaign_meta((int) $campaignId, self::IMPORT_META_KEY, true);
        return is_array($session) ? $session : null;
    }

    public static function updateImportSession($campaignId, array $session)
    {
        return fluentcrm_update_sms_campaign_meta((int) $campaignId, self::IMPORT_META_KEY, $session);
    }

    public static function deleteImportSession($campaignId)
    {
        return fluentcrm_delete_sms_campaign_meta((int) $campaignId, self::IMPORT_META_KEY);
    }

    public static function messageBatchQuery($campaignId, $batchId = '')
    {
        global $wpdb;

        $query = Message::forCampaign((int) $campaignId)
            ->where('direction', Message::DIRECTION_OUTBOUND);

        $batchId = (string) $batchId;
        if ($batchId !== '') {
            $needle = 's:8:"batch_id";s:' . strlen($batchId) . ':"' . $batchId . '";';
        } else {
            $needle = 's:18:"one_time_recipient";';
        }

        return $query->where('meta', 'LIKE', '%' . $wpdb->esc_like($needle) . '%');
    }

    public static function deleteMessageBatch($campaignId, $batchId = '')
    {
        return self::messageBatchQuery($campaignId, $batchId)->delete();
    }

    public static function getAudienceSettings(MessageCampaign $campaign)
    {
        $settings = is_array($campaign->settings) ? $campaign->settings : [];
        $audience = Arr::get($settings, 'one_time_audience', []);
        return is_array($audience) ? $audience : [];
    }

    public static function getActiveBatchId(MessageCampaign $campaign)
    {
        return (string) Arr::get(self::getAudienceSettings($campaign), 'active_batch_id', '');
    }

    public static function hasConfirmedConsent(MessageCampaign $campaign)
    {
        $audience = self::getAudienceSettings($campaign);

        return !empty($audience['consent_user_id'])
            && !empty($audience['consent_confirmed'])
            && Arr::get($audience, 'consent_channel') === ($campaign->channel ?: MessageCampaign::CHANNEL_SMS)
            && Arr::get($audience, 'active_batch_id') === self::getActiveBatchId($campaign);
    }

    public static function clearAudienceSettings(MessageCampaign $campaign)
    {
        $settings = is_array($campaign->settings) ? $campaign->settings : [];
        unset($settings['one_time_audience']);
        if (Arr::get($settings, 'sending_filter') === 'one_time') {
            $settings['sending_filter'] = 'list_tag';
        }

        $campaign->settings = $settings;
        return $campaign->save();
    }

}
