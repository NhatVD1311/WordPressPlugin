<?php

namespace FluentCampaign\App\Modules\Messaging\Services;

use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Support\Arr;

class OneTimeAudienceImporter
{
    const TEMP_STORAGE_DIR = 'fluentcrm-private';
    const MAX_UPLOAD_BYTES = 20971520;
    const MAX_PASTE_BYTES = 5242880;
    const MAX_PARSED_VALUES = 100000;
    const CHUNK_SIZE = 500;

    protected $normalizer;

    public function __construct(?PhoneNumberNormalizer $normalizer = null)
    {
        $this->normalizer = $normalizer ?: new PhoneNumberNormalizer();
    }

    public function startUpload(MessageCampaign $campaign, $file)
    {
        if (!$file || is_array($file) || !method_exists($file, 'isValid') || !$file->isValid()) {
            throw new \InvalidArgumentException('Please upload a valid CSV file.');
        }

        if ((int) $file->getSize() > self::MAX_UPLOAD_BYTES) {
            throw new \LengthException('The selected CSV file is too large.');
        }

        $fileName = method_exists($file, 'getClientOriginalName') ? $file->getClientOriginalName() : $file->getFilename();
        $fileName = sanitize_file_name($fileName ?: 'recipients.csv');

        if (!function_exists('wp_check_filetype_and_ext')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $fileType = wp_check_filetype_and_ext($file->getPathname(), $fileName, [
            'csv' => 'text/csv',
            'txt' => 'text/plain'
        ]);

        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if (!in_array($extension, ['csv', 'txt'], true) || empty($fileType['ext'])) {
            throw new \InvalidArgumentException('Please upload a CSV file.');
        }

        $this->cleanupImportSession($campaign->id);

        $batchId = $this->newBatchId();
        $reference = $this->copyTempFileFromPath($campaign->id, $file->getPathname(), $fileName, $fileType['type'] ?: 'text/csv');
        $reference['batch_id'] = $batchId;
        $headers = $this->readCsvHeaders($reference['relative_path']);

        $session = $this->baseSession($campaign, $batchId, 'csv', $reference);
        $session['headers'] = $headers;
        $session['cursor'] = $headers ? 1 : 0;

        OneTimeAudienceMeta::updateImportSession($campaign->id, $this->sessionForStorage($session));

        return $this->sessionResponse($session);
    }

    public function startPaste(MessageCampaign $campaign, $content)
    {
        if (!is_string($content)) {
            throw new \InvalidArgumentException('Please provide pasted phone numbers.');
        }

        if (strlen($content) > self::MAX_PASTE_BYTES) {
            throw new \LengthException('The pasted audience is too large.');
        }

        $content = str_replace(["\r\n", "\r"], "\n", $content);
        if (trim($content) === '') {
            throw new \InvalidArgumentException('Please provide at least one phone number.');
        }

        $this->cleanupImportSession($campaign->id);

        $batchId = $this->newBatchId();
        $processing = preg_replace('/[;,]+/', "\n", $content);
        $reference = $this->putTempFile($campaign->id, 'pasted-recipients-processing.txt', $processing, 'text/plain');
        $reference['batch_id'] = $batchId;

        $session = $this->baseSession($campaign, $batchId, 'paste', $reference);

        OneTimeAudienceMeta::updateImportSession($campaign->id, $this->sessionForStorage($session));

        return $this->sessionResponse($session);
    }

    public function process(MessageCampaign $campaign, array $request)
    {
        $session = $this->requireSession($campaign->id, Arr::get($request, 'token'));
        $defaultCountry = strtoupper(sanitize_text_field((string) Arr::get($request, 'default_country', Arr::get($session, 'default_country', 'US'))));

        $mapping = Arr::get($request, 'mapping', Arr::get($session, 'mapping', []));
        $mapping = is_array($mapping) ? array_map('sanitize_text_field', $mapping) : [];

        if ($session['type'] === 'csv' && empty($mapping['phone_number'])) {
            $mapping = $this->guessMapping(Arr::get($session, 'headers', []));
        }

        if ($session['type'] === 'csv' && empty($mapping['phone_number'])) {
            throw new \InvalidArgumentException('Please map the phone number column.');
        }

        $rows = $this->readRows($session, $mapping, self::CHUNK_SIZE);
        $stats = Arr::get($session, 'counts', $this->emptyCounts());
        $accepted = [];
        $rejected = Arr::get($session, 'rejected_sample', []);
        $acceptedSample = Arr::get($session, 'accepted_sample', []);
        $seen = [];

        foreach ($rows['items'] as $item) {
            if ($stats['total_parsed'] >= self::MAX_PARSED_VALUES) {
                $rows['has_more'] = false;
                break;
            }

            $stats['total_parsed']++;

            try {
                $phone = $this->normalizer->normalize($item['phone_number'], $defaultCountry);
            } catch (\Exception $e) {
                $stats['invalid']++;
                $this->pushSample($rejected, [
                    'phone_number' => (string) $item['phone_number'],
                    'reason'       => $e->getMessage()
                ]);
                continue;
            }

            if (isset($seen[$phone])) {
                $stats['duplicate']++;
                continue;
            }

            $seen[$phone] = true;
            $accepted[$phone] = [
                'phone_number' => $phone,
                'full_name'    => sanitize_text_field((string) $item['full_name'])
            ];
        }

        $filtered = $this->filterEligible($campaign, $accepted, $stats);
        $inserted = $this->insertMessageRows($campaign, $session['batch_id'], $filtered['items'], $stats);

        foreach ($inserted as $item) {
            $this->pushSample($acceptedSample, [
                'phone_number' => $item['phone_number'],
                'full_name'    => $item['full_name']
            ]);
        }

        $stats['accepted'] += count($inserted);

        $session['cursor'] = $rows['cursor'];
        $session['has_more'] = $rows['has_more'];
        $session['counts'] = $stats;
        $session['mapping'] = $mapping;
        $session['default_country'] = $defaultCountry;
        $session['accepted_sample'] = $acceptedSample;
        $session['rejected_sample'] = $rejected;
        $session['completed'] = !$rows['has_more'];
        $session['updated_at'] = current_time('mysql');

        OneTimeAudienceMeta::updateImportSession($campaign->id, $this->sessionForStorage($session));

        return $this->sessionResponse($session);
    }

    public function activate(MessageCampaign $campaign, $token, $confirmConsent = false)
    {
        $session = $this->requireSession($campaign->id, $token);

        if (empty($session['completed'])) {
            throw new \InvalidArgumentException('Please finish processing the audience before activating it.');
        }

        $counts = Arr::get($session, 'counts', []);
        $accepted = (int) Arr::get($counts, 'accepted', 0);
        if ($accepted < 1) {
            throw new \InvalidArgumentException('A one-time audience needs at least one accepted recipient.');
        }

        $oldBatchId = OneTimeAudienceMeta::getActiveBatchId($campaign);
        $settings = is_array($campaign->settings) ? $campaign->settings : [];

        $settings['sending_filter'] = 'one_time';
        $settings['one_time_audience'] = [
            'active_batch_id'   => $session['batch_id'],
            'accepted_count'    => $accepted,
            'default_country'   => Arr::get($session, 'default_country', 'US'),
            'consent_user_id'   => $confirmConsent ? get_current_user_id() : null,
            'consent_channel'   => $confirmConsent ? ($campaign->channel ?: MessageCampaign::CHANNEL_SMS) : null,
            'consent_confirmed' => $confirmConsent ? current_time('mysql') : null
        ];

        $campaign->settings = $settings;
        $campaign->recipients_count = $accepted;
        $campaign->save();

        OneTimeAudienceMeta::deleteImportSession($campaign->id);
        $this->deleteSessionFiles($session);

        if ($oldBatchId && $oldBatchId !== $session['batch_id']) {
            OneTimeAudienceMeta::deleteMessageBatch($campaign->id, $oldBatchId);
        }

        return $this->audience(MessageCampaign::find($campaign->id));
    }

    public function audience(MessageCampaign $campaign)
    {
        $settings = OneTimeAudienceMeta::getAudienceSettings($campaign);
        $import = OneTimeAudienceMeta::getImportSession($campaign->id);

        return [
            'audience_type'  => Arr::get($campaign->settings, 'sending_filter') === 'one_time' ? 'one_time' : 'contacts',
            'active_batch_id' => (string) Arr::get($settings, 'active_batch_id', ''),
            'accepted_count' => (int) Arr::get($settings, 'accepted_count', 0),
            'default_country' => (string) Arr::get($settings, 'default_country', ''),
            'consent' => [
                'user_id'      => (int) Arr::get($settings, 'consent_user_id', 0),
                'channel'      => (string) Arr::get($settings, 'consent_channel', ''),
                'confirmed_at' => (string) Arr::get($settings, 'consent_confirmed', '')
            ],
            'import_session' => $import ? $this->sessionResponse($import) : null
        ];
    }

    public function clear(MessageCampaign $campaign)
    {
        $import = OneTimeAudienceMeta::getImportSession($campaign->id);

        if ($import) {
            $this->cleanupImportSession($campaign->id);
        }

        OneTimeAudienceMeta::deleteMessageBatch($campaign->id);
        OneTimeAudienceMeta::clearAudienceSettings($campaign);

        return $this->audience(MessageCampaign::find($campaign->id));
    }

    public function cleanupImportSession($campaignId)
    {
        $session = OneTimeAudienceMeta::getImportSession($campaignId);
        if (!$session) {
            return;
        }

        $this->deleteSessionFiles($session);

        if (!empty($session['batch_id'])) {
            OneTimeAudienceMeta::deleteMessageBatch($campaignId, $session['batch_id']);
        }

        OneTimeAudienceMeta::deleteImportSession($campaignId);
    }

    protected function baseSession(MessageCampaign $campaign, $batchId, $type, array $reference)
    {
        $token = bin2hex(random_bytes(32));

        return [
            'token_hash' => $this->hashToken($token),
            'token'      => $token,
            'campaign_id' => (int) $campaign->id,
            'channel'    => $campaign->channel ?: MessageCampaign::CHANNEL_SMS,
            'batch_id'   => $batchId,
            'type'       => $type,
            'reference'  => $reference,
            'cursor'     => 0,
            'has_more'   => true,
            'completed'  => false,
            'counts'     => $this->emptyCounts(),
            'accepted_sample' => [],
            'rejected_sample' => [],
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
    }

    protected function sessionResponse(array $session)
    {
        return [
            'token'      => Arr::get($session, 'token', ''),
            'batch_id'   => Arr::get($session, 'batch_id', ''),
            'type'       => Arr::get($session, 'type', ''),
            'headers'    => Arr::get($session, 'headers', []),
            'mapping'    => Arr::get($session, 'mapping', []),
            'cursor'     => (int) Arr::get($session, 'cursor', 0),
            'has_more'   => (bool) Arr::get($session, 'has_more', true),
            'completed'  => (bool) Arr::get($session, 'completed', false),
            'counts'     => Arr::get($session, 'counts', $this->emptyCounts()),
            'accepted_sample' => Arr::get($session, 'accepted_sample', []),
            'rejected_sample' => Arr::get($session, 'rejected_sample', [])
        ];
    }

    protected function sessionForStorage(array $session)
    {
        unset($session['token']);

        return $session;
    }

    protected function requireSession($campaignId, $token)
    {
        $session = OneTimeAudienceMeta::getImportSession($campaignId);
        if (!$session || !$token || empty($session['token_hash']) || !hash_equals($session['token_hash'], $this->hashToken($token))) {
            throw new \InvalidArgumentException('The audience import session is invalid or expired.');
        }

        return $session;
    }

    protected function readCsvHeaders($relativePath)
    {
        $path = $this->resolveTempFilePath($relativePath, true);
        $handle = fopen($path, 'r');
        $headers = $handle ? fgetcsv($handle, 0, ',', '"', '\\') : [];
        if ($handle) {
            fclose($handle);
        }

        return array_map('sanitize_text_field', array_filter((array) $headers, 'strlen'));
    }

    protected function readRows(array $session, array $mapping, $limit)
    {
        $relativePath = $session['type'] === 'paste'
            ? Arr::get($session, 'processing_relative_path', Arr::get($session, 'reference.relative_path'))
            : Arr::get($session, 'reference.relative_path');

        $path = $this->resolveTempFilePath($relativePath, true);
        $file = new \SplFileObject($path, 'r');
        $file->setFlags(\SplFileObject::DROP_NEW_LINE | \SplFileObject::SKIP_EMPTY);

        $cursor = (int) Arr::get($session, 'cursor', 0);
        $file->seek($cursor);
        $items = [];

        while (!$file->eof() && count($items) < $limit) {
            $lineNo = $file->key();

            if ($session['type'] === 'csv') {
                $row = $file->fgetcsv(',', '"', '\\');
                if (!$row || $row === [null] || $row === false) {
                    $cursor = $lineNo + 1;
                    continue;
                }

                $items[] = [
                    'phone_number' => $this->csvValue($row, $mapping['phone_number']),
                    'full_name'    => !empty($mapping['full_name']) ? $this->csvValue($row, $mapping['full_name']) : ''
                ];
            } else {
                $line = trim((string) $file->current());
                if ($line !== '') {
                    $items[] = [
                        'phone_number' => $line,
                        'full_name'    => ''
                    ];
                }
                $file->next();
            }

            $cursor = $lineNo + 1;
        }

        return [
            'items'    => $items,
            'cursor'   => $cursor,
            'has_more' => !$file->eof()
        ];
    }

    protected function csvValue(array $row, $column)
    {
        $index = is_numeric($column) ? (int) $column : null;
        return $index !== null && array_key_exists($index, $row) ? $row[$index] : '';
    }

    protected function guessMapping(array $headers)
    {
        $mapping = [];
        $aliases = ['phone', 'phone_number', 'mobile', 'mobile_number'];

        foreach ($headers as $index => $header) {
            $key = sanitize_key(strtolower((string) $header));
            if (in_array($key, $aliases, true) && empty($mapping['phone_number'])) {
                $mapping['phone_number'] = (string) $index;
            }
            if ($key === 'full_name' && empty($mapping['full_name'])) {
                $mapping['full_name'] = (string) $index;
            }
        }

        return $mapping;
    }

    protected function filterEligible(MessageCampaign $campaign, array $items, array &$stats)
    {
        if (!$items) {
            return ['items' => []];
        }

        $channel = $campaign->resolveChannel();
        $phones = array_keys($items);
        $digits = array_map([$this, 'digitsOnly'], $phones);
        $contacts = Subscriber::whereIn('phone', array_values(array_unique(array_merge($phones, $digits))))->get();
        $contactByPhone = [];
        $excludedPhones = [];

        foreach ($contacts as $contact) {
            $contactPhones = array_filter([$contact->phone, $this->digitsOnly($contact->phone)]);
            foreach ($contactPhones as $contactPhone) {
                $contactByPhone[$contactPhone] = $contact;
            }
        }

        $blocked = MessageThread::blockedContactIds($channel->getSlug(), array_map(function ($contact) {
            return $contact->id;
        }, $contacts->all()));

        foreach ($items as $phone => &$item) {
            $contact = $contactByPhone[$phone] ?? $contactByPhone[$this->digitsOnly($phone)] ?? null;
            if ($contact) {
                $stats['existing_contacts_matched']++;
                if (isset($blocked[(int) $contact->id])) {
                    $stats['existing_opted_out_contacts_excluded']++;
                    $excludedPhones[$phone] = true;
                    continue;
                }
                $item['contact_id'] = (int) $contact->id;
            }
        }
        unset($item);

        $threads = MessageThread::where('channel', $channel->getSlug())
            ->whereIn('phone_number', $phones)
            ->get();

        foreach ($threads as $thread) {
            if ($thread->status !== MessageThread::STATUS_SUBSCRIBED) {
                $excludedPhones[$thread->phone_number] = true;
                $stats['contactless_opted_out_conversations_excluded']++;
            }
        }

        foreach ($excludedPhones as $phone => $_) {
            unset($items[$phone]);
        }

        return ['items' => $items];
    }

    protected function insertMessageRows(MessageCampaign $campaign, $batchId, array $items, array &$stats)
    {
        if (!$items) {
            return [];
        }

        foreach ($this->existingMessagePhones($campaign, $batchId, array_keys($items)) as $phone) {
            unset($items[$phone]);
            $stats['duplicate']++;
        }

        if (!$items) {
            return [];
        }

        $channel = $campaign->resolveChannel();
        $channelSlug = $channel->getSlug();
        $messageItems = [];

        foreach ($items as $phone => $item) {
            $messageItems[$phone] = [
                'channel'      => $channelSlug,
                'phone'        => $phone,
                'contact_id'   => !empty($item['contact_id']) ? (int) $item['contact_id'] : null,
                'initiated_by' => 'admin',
                'direction'    => Message::DIRECTION_OUTBOUND,
                'content'      => $campaign->message_content,
                'ref_id'       => $campaign->id,
                'ref_type'     => $campaign->messageRefType(),
                'status'       => Message::STATUS_SCHEDULING,
                'scheduled_at' => null,
                'meta'         => [
                    'one_time_recipient' => [
                        'full_name'    => (string) $item['full_name'],
                        'phone_number' => (string) $phone,
                        'batch_id'     => (string) $batchId
                    ]
                ]
            ];
        }

        $written = MessageThread::recordMessages($messageItems);
        $written = array_flip($written);

        return array_values(array_filter($items, function ($phone) use ($written) {
            return isset($written[$phone]);
        }, ARRAY_FILTER_USE_KEY));
    }

    protected function existingMessagePhones(MessageCampaign $campaign, $batchId, array $phones)
    {
        if (!$phones) {
            return [];
        }

        $channel = $campaign->resolveChannel();
        $threadPhoneById = [];
        $threads = MessageThread::where('channel', $channel->getSlug())
            ->whereIn('phone_number', array_values($phones))
            ->get(['id', 'phone_number']);

        foreach ($threads as $thread) {
            $threadPhoneById[(int) $thread->id] = (string) $thread->phone_number;
        }

        if (!$threadPhoneById) {
            return [];
        }

        $existing = [];
        $messages = OneTimeAudienceMeta::messageBatchQuery($campaign->id, $batchId)
            ->whereIn('thread_id', array_keys($threadPhoneById))
            ->get(['thread_id']);

        foreach ($messages as $message) {
            $threadId = (int) $message->thread_id;
            if (isset($threadPhoneById[$threadId])) {
                $existing[] = $threadPhoneById[$threadId];
            }
        }

        return array_values(array_unique($existing));
    }

    protected function emptyCounts()
    {
        return [
            'total_parsed' => 0,
            'accepted' => 0,
            'duplicate' => 0,
            'invalid' => 0,
            'existing_contacts_matched' => 0,
            'existing_opted_out_contacts_excluded' => 0,
            'contactless_opted_out_conversations_excluded' => 0
        ];
    }

    protected function pushSample(array &$sample, array $item)
    {
        if (count($sample) < 20) {
            $sample[] = $item;
        }
    }

    protected function newBatchId()
    {
        return wp_generate_uuid4();
    }

    protected function hashToken($token)
    {
        return hash('sha256', (string) $token . wp_salt('auth'));
    }

    protected function deleteSessionFiles(array $session)
    {
        if (!empty($session['reference'])) {
            $this->deleteTempFileReference($session['reference']);
        }

        if (!empty($session['processing_relative_path'])) {
            $this->deleteTempFileReference(['relative_path' => $session['processing_relative_path']]);
        }
    }

    protected function putTempFile($campaignId, $originalName, $content, $mimeType = 'text/plain')
    {
        if (!is_string($content)) {
            throw new \InvalidArgumentException('One-time audience import content must be a string.');
        }

        $relativePath = $this->newTempRelativePath($campaignId, $originalName);
        $path = $this->resolveTempFilePath($relativePath);

        if (file_put_contents($path, $content, LOCK_EX) === false) {
            throw new \RuntimeException('Unable to write one-time audience import file.');
        }

        return $this->tempFileReference($relativePath, $originalName, $mimeType);
    }

    protected function copyTempFileFromPath($campaignId, $sourcePath, $originalName, $mimeType = 'application/octet-stream')
    {
        if (!is_readable($sourcePath)) {
            throw new \InvalidArgumentException('Audience source file is not readable.');
        }

        $relativePath = $this->newTempRelativePath($campaignId, $originalName);
        $path = $this->resolveTempFilePath($relativePath);

        if (!copy($sourcePath, $path)) {
            throw new \RuntimeException('Unable to copy one-time audience import file.');
        }

        return $this->tempFileReference($relativePath, $originalName, $mimeType);
    }

    protected function newTempRelativePath($campaignId, $originalName)
    {
        $relativeDir = 'audiences/' . (int) $campaignId;
        $this->resolveTempDirectory($relativeDir, true);
        $extension = preg_replace('/[^a-z0-9]/', '', strtolower(pathinfo((string) $originalName, PATHINFO_EXTENSION)));

        return $relativeDir . '/' . bin2hex(random_bytes(32)) . ($extension ? '.' . $extension : '');
    }

    protected function tempFileReference($relativePath, $originalName, $mimeType = 'application/octet-stream')
    {
        $path = $this->resolveTempFilePath($relativePath, true);

        return [
            'file_name'     => sanitize_file_name((string) $originalName),
            'relative_path' => ltrim(str_replace('\\', '/', sanitize_text_field((string) $relativePath)), '/'),
            'mime_type'     => sanitize_text_field((string) $mimeType),
            'file_size'     => (int) filesize($path),
            'sha256'        => hash_file('sha256', $path),
            'created_by'    => get_current_user_id(),
            'created_at'    => current_time('mysql')
        ];
    }

    protected function deleteTempFileReference($reference)
    {
        if (!is_array($reference) || empty($reference['relative_path'])) {
            return false;
        }

        try {
            $path = $this->resolveTempFilePath($reference['relative_path'], true);
        } catch (\Exception $e) {
            return false;
        }

        return is_file($path) ? @unlink($path) : false;
    }

    protected function resolveTempFilePath($relativePath, $mustExist = false)
    {
        $relativePath = ltrim(str_replace('\\', '/', (string) $relativePath), '/');

        if (!$relativePath || strpos($relativePath, "\0") !== false || preg_match('#(^|/)\.\.(?:/|$)#', $relativePath)) {
            throw new \InvalidArgumentException('Invalid one-time audience import path.');
        }

        $root = $this->tempStorageRoot();
        $path = $root . '/' . $relativePath;
        $resolvedRoot = realpath($root);
        $resolvedPath = $mustExist ? realpath($path) : realpath(dirname($path));

        if (!$resolvedRoot || !$resolvedPath || strpos(wp_normalize_path($resolvedPath), wp_normalize_path($resolvedRoot) . '/') !== 0 && wp_normalize_path($resolvedPath) !== wp_normalize_path($resolvedRoot)) {
            throw new \RuntimeException('One-time audience import path escapes the storage root.');
        }

        return $mustExist ? wp_normalize_path($resolvedPath) : wp_normalize_path($path);
    }

    protected function resolveTempDirectory($relativeDir, $create = false)
    {
        $root = $this->tempStorageRoot();
        $relativeDir = trim(str_replace('\\', '/', (string) $relativeDir), '/');

        if (!$relativeDir || preg_match('#(^|/)\.\.(?:/|$)#', $relativeDir)) {
            throw new \InvalidArgumentException('Invalid one-time audience import directory.');
        }

        $dir = $root . '/' . $relativeDir;
        if ($create && !wp_mkdir_p($dir)) {
            throw new \RuntimeException('Unable to create one-time audience import directory.');
        }

        $resolvedRoot = realpath($root);
        $resolvedDir = realpath($dir);

        if (!$resolvedRoot || !$resolvedDir || strpos(wp_normalize_path($resolvedDir), wp_normalize_path($resolvedRoot) . '/') !== 0) {
            throw new \RuntimeException('One-time audience import directory escapes the storage root.');
        }

        $this->writeStorageDenyFiles($dir);

        return wp_normalize_path($resolvedDir);
    }

    protected function tempStorageRoot()
    {
        $root = defined('FLUENTCRM_PRIVATE_STORAGE_PATH') ? FLUENTCRM_PRIVATE_STORAGE_PATH : '';

        if (!$root) {
            $upload = wp_upload_dir(null, false);
            $root = trailingslashit($upload['basedir']) . self::TEMP_STORAGE_DIR;
        }

        $root = apply_filters('fluent_crm/private_storage_path', $root);
        $root = rtrim(wp_normalize_path((string) $root), '/');

        if (!wp_mkdir_p($root)) {
            throw new \RuntimeException('Unable to create one-time audience import storage directory.');
        }

        $this->writeStorageDenyFiles($root);

        return $root;
    }

    protected function writeStorageDenyFiles($dir)
    {
        $files = [
            'index.php'  => "<?php\n// Silence is golden.\n",
            '.htaccess'  => "Deny from all\n",
            'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n"
        ];

        foreach ($files as $name => $content) {
            $path = trailingslashit($dir) . $name;
            if (!file_exists($path)) {
                file_put_contents($path, $content, LOCK_EX);
            }
        }
    }

    protected function digitsOnly($phone)
    {
        return preg_replace('/\D+/', '', (string) $phone);
    }
}
