<?php

namespace FluentCampaign\App\Modules\Messaging;

use FluentCampaign\App\Modules\Messaging\Models\MessageThread;

class MessageMigrator
{
    /**
     * Marks the one-shot consent backfill as done, so a migrate triggered by
     * a settings save does not rescan the contact table every time.
     */
    const CONSENT_BACKFILL_OPTION = '__fluentcrm_messaging_consent_backfilled';

    public static function migrate($isForced = false)
    {
        // The conversation tables belong to this Pro-only module. Keep their
        // creation here so Free neither creates nor upgrades unused tables.
        // Threads must exist first because every message points at one.
        self::migrateMessageThreadsTable();
        self::migrateMessagesTable();
        self::migrateSMSMessagesTable($isForced);
        self::migrateSMSCampaignsTable($isForced);
        self::migrateMessageTemplatesTable($isForced);
        self::backfillThreadConsent();
    }

    /**
     * One row per conversation: a phone number on a channel.
     */
    public static function migrateMessageThreadsTable()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_message_threads';
        $indexPrefix = $wpdb->prefix . 'fc_mt_';

        // This schema has not shipped, so it is created complete instead of
        // carrying an upgrade-time ALTER/backfill branch.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            // The unique identity prevents concurrent inbound webhooks from
            // splitting one phone/channel conversation into multiple threads.
            // rail_idx keeps the inbox rail ordered without scanning all rows.
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `contact_id` BIGINT UNSIGNED NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `phone_number` VARCHAR(20) NOT NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'subscribed',
                `initiated_by` VARCHAR(20) NOT NULL DEFAULT 'user',
                `last_seen_id` BIGINT UNSIGNED NULL,
                `last_message_id` BIGINT UNSIGNED NULL,
                `has_unread` TINYINT(1) NOT NULL DEFAULT 0,
                `unread_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `meta` LONGTEXT NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                UNIQUE KEY `{$indexPrefix}identity_idx` (`channel`, `phone_number`),
                INDEX `{$indexPrefix}contact_idx` (`contact_id`, `channel`),
                INDEX `{$indexPrefix}rail_idx` (`updated_at`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    /**
     * One row per inbound or outbound message on any channel.
     */
    public static function migrateMessagesTable()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_messages';
        $indexPrefix = $wpdb->prefix . 'fc_msg_';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            // activity_at materializes the activity-time expression used by
            // the global list and rail. queue_idx matches the campaign worker's
            // ref_id equality plus id-ordered cursor walk.
            //
            // DATETIME, and no nullability clause, are both load-bearing.
            // MariaDB's generated-column grammar has no `[NOT NULL | NULL]`
            // slot, so the `STORED NULL` MySQL accepts is a syntax error there
            // and the whole CREATE TABLE fails. Dropping the `NULL` alone is
            // not enough: a TIMESTAMP column with no explicit nullability is
            // promoted to NOT NULL, and the column would then reject any row
            // whose three source times are all null. DATETIME has no such
            // promotion, so it stays nullable on both engines with nothing
            // declared.
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `thread_id` BIGINT UNSIGNED NOT NULL,
                `direction` VARCHAR(20) NOT NULL DEFAULT 'outbound',
                `content` TEXT NULL,
                `ref_id` BIGINT UNSIGNED NULL,
                `ref_type` VARCHAR(50) NULL,
                `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
                `provider_message_id` VARCHAR(100) NULL,
                `scheduled_at` TIMESTAMP NULL,
                `sent_at` TIMESTAMP NULL,
                `meta` LONGTEXT NULL,
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                `activity_at` DATETIME GENERATED ALWAYS AS (COALESCE(`sent_at`, `scheduled_at`, `created_at`)) STORED,
                INDEX `{$indexPrefix}thread_idx` (`thread_id`, `id`),
                INDEX `{$indexPrefix}provider_idx` (`provider_message_id`),
                INDEX `{$indexPrefix}status_idx` (`status`, `scheduled_at`),
                INDEX `{$indexPrefix}ref_idx` (`ref_type`, `ref_id`),
                INDEX `{$indexPrefix}queue_idx` (`ref_id`, `id`),
                INDEX `{$indexPrefix}activity_idx` (`activity_at`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public static function migrateSMSMessagesTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_sms_messages';
        $indexPrefix = $wpdb->prefix . 'fc_sms_msg';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `campaign_id` BIGINT UNSIGNED NULL,
                `sms_type` VARCHAR(50) NULL DEFAULT 'campaign',
                `subscriber_id` BIGINT UNSIGNED NULL,
                `mobile_number` VARCHAR(20) NULL,
                `click_counter` INT UNSIGNED NULL DEFAULT 0,
                `message_content` TEXT,
                `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
                `delivery_status` VARCHAR(50) NULL DEFAULT 'queued',
                `notes` TEXT NULL,
                `provider_message_id` VARCHAR(100) NULL,
                `settings` LONGTEXT NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `scheduled_at` TIMESTAMP NULL,
                `sent_at` TIMESTAMP NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `{$indexPrefix}_campaign_id_idx` (`campaign_id`),
                INDEX `{$indexPrefix}_status_idx` (`status`),
                INDEX `{$indexPrefix}_scheduled_at_idx` (`scheduled_at`),
                INDEX `{$indexPrefix}_provider_msg_idx` (`provider_message_id`, `channel`)
            ) $charsetCollate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }

        // Add channel column to existing installs
        if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE 'channel'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD `channel` VARCHAR(20) NOT NULL DEFAULT 'sms' AFTER `settings`");
        }

        // Add composite index for webhook provider_message_id lookups if missing
        $indexName = $indexPrefix . '_provider_msg_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$indexName'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$indexName` (`provider_message_id`, `channel`)");
        }

        // Columns absorbed from the standalone WhatsApp module's own message table,
        // so one table serves both channels and both directions.
        //
        //  direction    - inbound messages are stored alongside outbound, which is
        //                 what makes the 24-hour service window a derived query
        //                 rather than a separate sessions table.
        //  delivered_at - delivery funnel and the "delivered" funnel benchmark.
        //  read_at      - read receipts and the "read" funnel benchmark.
        //  template_id  - FK into fc_message_templates for template sends.
        $newColumns = [
            'direction'    => "ALTER TABLE `$table` ADD `direction` VARCHAR(20) NOT NULL DEFAULT 'outbound' AFTER `channel`",
            'delivered_at' => "ALTER TABLE `$table` ADD `delivered_at` TIMESTAMP NULL AFTER `sent_at`",
            'read_at'      => "ALTER TABLE `$table` ADD `read_at` TIMESTAMP NULL AFTER `delivered_at`",
            'template_id'  => "ALTER TABLE `$table` ADD `template_id` BIGINT UNSIGNED NULL AFTER `campaign_id`",
        ];

        foreach ($newColumns as $column => $sql) {
            if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE '$column'") === null) {
                $wpdb->query($sql);
            }
        }

        // Serves the 24-hour window lookup: the most recent inbound message for a
        // contact on a channel. Replaces a dedicated sessions table. created_at is
        // included so the ORDER BY created_at DESC ... LIMIT 1 in SessionWindow
        // reads index order instead of sorting the matched rows.
        $oldWindowIndex = $indexPrefix . '_sub_channel_dir_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$oldWindowIndex'") !== null) {
            $wpdb->query("ALTER TABLE `$table` DROP INDEX `$oldWindowIndex`");
        }

        $windowIndex = $indexPrefix . '_session_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$windowIndex'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$windowIndex` (`subscriber_id`, `channel`, `direction`, `created_at`)");
        }
    }

    /**
     * Templates for any messaging channel.
     *
     * Named for messaging rather than WhatsApp so reusable SMS bodies and future
     * channels share one table, discriminated by `channel` exactly as
     * fc_sms_campaigns and fc_sms_messages are. Channel-specific columns are
     * nullable, so an SMS row is just a name and a body.
     */
    public static function migrateMessageTemplatesTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_message_templates';
        $indexPrefix = $wpdb->prefix . 'fc_msg_tpl';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'whatsapp',
                `name` VARCHAR(192) NOT NULL,
                `language` VARCHAR(20) NOT NULL DEFAULT 'en_US',
                `category` VARCHAR(50) NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'PENDING',
                `header_text` VARCHAR(255) NULL,
                `body_text` TEXT NOT NULL,
                `footer_text` VARCHAR(255) NULL,
                `buttons` LONGTEXT NULL,
                `variables` LONGTEXT NULL,
                `provider` VARCHAR(50) NULL,
                `provider_template_id` VARCHAR(192) NULL,
                `rejection_reason` TEXT NULL,
                `last_synced_at` TIMESTAMP NULL,
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                UNIQUE INDEX `{$indexPrefix}_identity_idx` (`channel`, `provider`, `name`, `language`),
                INDEX `{$indexPrefix}_channel_status_idx` (`channel`, `status`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public static function migrateSMSCampaignsTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_sms_campaigns';
        $indexPrefix = $wpdb->prefix . 'fc_sms_camp';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `parent_id` BIGINT UNSIGNED NULL,
                `type` VARCHAR(50) NOT NULL DEFAULT 'campaign',
                `title` VARCHAR(192) NOT NULL,
                `slug` VARCHAR(192) NOT NULL,
                `status` VARCHAR(50) NOT NULL DEFAULT 'draft',
                `message_content` TEXT NOT NULL,
                `sender_number` VARCHAR(20) NULL,
                `recipients_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `sent_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `failed_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `delay` INT UNSIGNED NULL DEFAULT 0,
                `scheduled_at` TIMESTAMP NULL,
                `settings` LONGTEXT NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `{$indexPrefix}_status_idx` (`status`),
                INDEX `{$indexPrefix}_scheduled_at_idx` (`scheduled_at`),
                INDEX `{$indexPrefix}_type_idx` (`type`),
                INDEX `{$indexPrefix}_type_channel_idx` (`type`, `channel`)
            ) $charsetCollate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }

        // Add channel column to existing installs
        if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE 'channel'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD `channel` VARCHAR(20) NOT NULL DEFAULT 'sms' AFTER `settings`");
        }

        // Add composite index for channel-filtered campaign list queries if missing
        $channelIndexName = $indexPrefix . '_type_channel_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$channelIndexName'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$channelIndexName` (`type`, `channel`)");
        }
    }

    /**
     * One-shot move of SMS consent from `fc_subscribers.sms_status` onto the
     * conversation threads that now own it.
     *
     * The thread table is the only source of truth for consent, and absence of
     * a thread means subscribed — so only the contacts who said otherwise need
     * a row. Everyone else is already correct by default, which is what keeps
     * this bounded to the opt-out minority instead of the whole contact table.
     *
     * WhatsApp is deliberately not migrated. Its column defaulted to
     * `whatsapp_unsubscribed`, so a genuine opt-out is indistinguishable from a
     * contact nobody ever touched; the channel had not shipped, so there is no
     * real consent in there to lose.
     *
     * Contacts with no phone number are skipped: a thread is identified by its
     * number, so there is nowhere to record their consent — and nowhere to send
     * to them either, so nothing can act on it.
     */
    public static function backfillThreadConsent()
    {
        global $wpdb;

        if (fluentcrm_get_option(self::CONSENT_BACKFILL_OPTION) === 'yes') {
            return;
        }

        $subscribers = $wpdb->prefix . 'fc_subscribers';
        $threads = $wpdb->prefix . 'fc_message_threads';

        // Nothing to migrate from on an install that never had the column.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW COLUMNS FROM `$subscribers` LIKE 'sms_status'") === null) {
            fluentcrm_update_option(self::CONSENT_BACKFILL_OPTION, 'yes');
            return;
        }

        // Channel-neutral: the thread knows it is SMS, so the status must not
        // repeat it. Anything unrecognised is treated as an opt-out rather than
        // silently becoming consent.
        $statusCase = $wpdb->prepare(
            "CASE s.sms_status WHEN 'sms_bounced' THEN %s WHEN 'sms_pending' THEN %s ELSE %s END",
            MessageThread::STATUS_BOUNCED,
            MessageThread::STATUS_PENDING,
            MessageThread::STATUS_UNSUBSCRIBED
        );

        $notSubscribed = "s.phone IS NOT NULL AND s.phone <> '' AND s.sms_status IS NOT NULL AND s.sms_status <> 'sms_subscribed'";

        // `fc_subscribers.phone` is wider than a thread's `phone_number`, and a
        // number that does not fit must be skipped rather than truncated: a
        // truncated number is a different number, and the unique key would file
        // this contact's opt-out under someone else's conversation. Such a
        // number cannot be messaged either, since every send path creates its
        // thread through the same column.
        $insertable = $notSubscribed . " AND CHAR_LENGTH(s.phone) <= 20";

        // A consent record for a number we have never messaged. `initiated_by`
        // says nobody started this conversation, which is what keeps these rows
        // out of the inbox rail until a real message lands on them.
        //
        // The timestamps come from the contact rather than from now: the rail
        // sorts on `updated_at`, and a migration must not reorder anyone's
        // inbox. INSERT IGNORE leaves a number that already has a thread to the
        // UPDATE below.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO `$threads`
                    (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`unread_count`,`created_at`,`updated_at`)
                 SELECT s.id, 'sms', s.phone, $statusCase, %s, 0, 0,
                        COALESCE(s.created_at, %s), COALESCE(s.created_at, %s)
                 FROM `$subscribers` s
                 WHERE $insertable",
                MessageThread::INITIATED_BY_SYSTEM,
                current_time('mysql'),
                current_time('mysql')
            )
        );

        // Threads that already existed for these numbers keep their history and
        // only take the consent. Two contacts can share a number and disagree,
        // so this never relaxes a status that is already an opt-out.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "UPDATE `$threads` t
             JOIN `$subscribers` s ON s.id = t.contact_id
             SET t.status = $statusCase
             WHERE t.channel = 'sms'
               AND t.status = '" . MessageThread::STATUS_SUBSCRIBED . "'
               AND $notSubscribed"
        );

        fluentcrm_update_option(self::CONSENT_BACKFILL_OPTION, 'yes');
    }

    public static function dropTable()
    {
        global $wpdb;

        $tables = [
            $wpdb->prefix . 'fc_sms_messages',
            $wpdb->prefix . 'fc_sms_campaigns'
        ];

        foreach ($tables as $table) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") == $table) {
                $wpdb->query("DROP TABLE IF EXISTS $table");
            }
        }
    }
}
