<?php

namespace FluentCampaign\App\Modules\Messaging\Handlers;

use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

/**
 * The outbound message queue.
 *
 * Queue rows live in `fc_messages` alongside the conversation they belong to,
 * not in the retired `fc_sms_messages`. That is what puts a campaign send in
 * the inbox thread with the contact's replies rather than in a separate log
 * nobody reads.
 *
 * Everything identifying *who* a message is for — the channel, the destination
 * number, the contact — comes from the thread, so every fetch eager-loads it.
 */
class MessageScheduler
{
    /**
     * Rows pulled per SELECT inside the send loop.
     *
     * The chunk is a window, not a work ceiling — memory and the time budget are
     * what end an action. 200 keeps the query cheap and keeps a fast channel fed;
     * a slow one simply leaves part of the chunk unsent, and the cursor means the
     * next action resumes from where sending actually stopped.
     */
    protected $sendingPerChunk = 200;

    /**
     * Wall clock an action may spend sending.
     *
     * Deliberately under Action Scheduler's own 30-second runner limit, so a
     * send action cannot consume an entire runner pass and leave nothing for its
     * bookkeeping.
     */
    protected $maximumProcessingTime = 20;

    /**
     * Seconds to wait before the continuation action becomes due.
     *
     * Zero on purpose. Action Scheduler's runner claims due actions, processes
     * them, then loops while more are due and time remains — a continuation due
     * now is picked up by the same pass. One due in five seconds is not, and the
     * async loopback runner that might otherwise catch it only fires in admin
     * requests behind a 60-second lock, so on a quiet site a delayed
     * continuation waits for the next cron minute. At 200 messages an action
     * that is the difference between minutes and hours on a large campaign.
     *
     * Raise it with `fluent_crm/message_next_action_delay` only when a site needs
     * extra queue breathing room. FluentCRM does not enforce provider rate limits.
     */
    const NEXT_ACTION_DELAY = 0;


    protected $sentCount = 0;
    protected $startingTimeStamp;

    public function __construct()
    {
        $sendingPerChunk = (int) $this->applyFilterWithOldName(
            'fluent_crm/message_scheduler_chunk_size',
            'fluent_crm/sms_scheduler_chunk_size',
            $this->sendingPerChunk
        );

        if ($sendingPerChunk > 0) {
            $this->sendingPerChunk = $sendingPerChunk;
        }

        $maximumProcessingTime = (int) $this->applyFilterWithOldName(
            'fluent_crm/message_scheduler_max_processing_seconds',
            'fluent_crm/sms_scheduler_max_processing_seconds',
            $this->maximumProcessingTime
        );

        if ($maximumProcessingTime > 0) {
            $this->maximumProcessingTime = $maximumProcessingTime;
        }
    }

    /**
     * Apply the current filter, then the retired one for anything still hooked
     * to it. apply_filters_deprecated() fires only when the old name actually
     * has listeners, so a site with none pays nothing and sees no notice.
     */
    protected function applyFilterWithOldName($current, $legacy, $value)
    {
        $value = apply_filters($current, $value, $this);

        return apply_filters_deprecated($legacy, [$value, $this], '3.2.0', $current);
    }



    /**
     * One Action Scheduler group for the whole module.
     *
     * Campaign actions used to get a group each (`fluent-crm-sms-{id}`) purely so
     * an unschedule could cancel the lot in one call. Now that an action carries
     * only its campaign id, hook + args identifies the same set, and the queue
     * stops accumulating a group per campaign ever created.
     */
    const ACTION_GROUP = 'fluent-crm-messaging';

    /**
     * Queue one campaign action, replacing any pending copy of it.
     *
     * Unique per campaign by construction: the pending duplicate is cancelled
     * first, so a health-check re-arm cannot leave two workers chained on the
     * same campaign. Action Scheduler's own uniqueness flag is hook/group-wide
     * and would reject a continuation queued from inside that same hook.
     */
    public static function scheduleCampaignAction($hook, $campaignId, $timestamp = null)
    {
        $campaignId = (int) $campaignId;

        if ($timestamp === null) {
            $timestamp = time() + max(0, (int) apply_filters('fluent_crm/message_next_action_delay', self::NEXT_ACTION_DELAY));
        }

        as_unschedule_all_actions($hook, [$campaignId], self::ACTION_GROUP);

        as_schedule_single_action($timestamp, $hook, [$campaignId], self::ACTION_GROUP);
    }

    /**
     * Cancel every queued generation and sending action for one campaign.
     *
     * The campaign's group holds nothing but its own generate and send batches,
     * so cancelling the group cancels them all whatever offset or message cursor
     * they carry. Enumerating the actions first only to hand their arguments
     * straight back was the same operation done the expensive way.
     *
     * The empty hook is required, not an oversight: as_unschedule_all_actions()
     * only takes its cancel-the-whole-group path when the hook is omitted. Given
     * both a hook and empty args it falls through to a matching loop that treats
     * `[]` as the arguments to look for, and campaign actions never carry those.
     */
    public static function clearPendingCampaignActions($campaignId) 
    {
        $campaignId = (int) $campaignId;

        foreach (['fluentcrm_generate_message_batch', 'fluentcrm_send_message_batch'] as $hook) {
            as_unschedule_all_actions($hook, [$campaignId], self::ACTION_GROUP);
        }

        // Anything queued before 3.2.0 still carries the old hook names and the
        // per-campaign group. Cancel those the way they were created, or an
        // unschedule during the upgrade window leaves a worker running.
        as_unschedule_all_actions('', [], 'fluent-crm-sms-' . $campaignId);

        // The cursors are meaningless once the queue is cleared, and a campaign
        // that is rescheduled must start from the beginning.
        MessageCampaign::clearCursor($campaignId);
    }

    /**
     * Atomically claim a queued message before contacting its provider.
     *
     * Overlapping workers may select the same row, but only the worker whose
     * conditional update succeeds may send it. This protects both SMS and
     * WhatsApp because they share this queue and provider-dispatch path.
     */
    public static function claimMessage($messageId)
    {
        return (bool) fluentCrmDb()->table('fc_messages')
            ->where('id', (int) $messageId)
            ->whereIn('status', Message::CLAIMABLE)
            ->update([
                'status'     => Message::STATUS_PROCESSING,
                'updated_at' => current_time('mysql')
            ]);
    }

    /**
     * Return messages abandoned mid-send to the queue.
     *
     * A worker that dies between claiming a row and recording its outcome leaves
     * it in `processing`, where nothing will ever pick it up again. Reverting it
     * to `pending` is the only recovery, and this is the one place that does it —
     * it used to live in three, on three different thresholds, one of which ran
     * from a polling GET and swept every campaign on the site while a user
     * happened to have a report screen open.
     *
     * @param int $maxAgeSeconds How long a claim may go unresolved.
     * @param int $campaignId    Limit to one campaign, or 0 to sweep all outbound.
     * @return int Rows returned to the queue.
     */
    public static function resetStuckProcessingMessages($maxAgeSeconds, $campaignId = 0)
    {
        $threshold = date('Y-m-d H:i:s', current_time('timestamp') - (int) $maxAgeSeconds);

        $query = $campaignId
            ? Message::forCampaign((int) $campaignId)
            : Message::where('direction', Message::DIRECTION_OUTBOUND);

        // Deliberately does not stamp updated_at. The column records when a row
        // was last claimed, and the health check reads it to decide whether a
        // campaign's send chain is alive. Refreshing it here would make every
        // campaign this method just rescued look busy, and the re-arm it needs
        // would be skipped until the rows went stale all over again.
        return (int) $query->where('status', Message::STATUS_PROCESSING)
            ->where('updated_at', '<', $threshold)
            ->update([
                'status' => Message::STATUS_PENDING
            ]);
    }

    /**
     * Register the module's Action Scheduler hooks.
     *
     * Two live job names — one to turn a campaign's audience into rows, one to
     * send them — plus the retired names kept only to drain what 3.1.x queued.
     */
    public function register()
    {
        add_action('fluentcrm_generate_message_batch', [(new MessageHandler()), 'handleGenerateBatch']);
        add_action('fluentcrm_send_message_batch', [$this, 'handleSendBatch']);

        /*
         * Retired job names, kept until 3.4.0.
         *
         * These are not extension points — they are rows in
         * wp_actionscheduler_actions. A site upgrading mid-campaign can hold
         * hundreds of pending actions under the old names, and without a listener
         * every one of those campaigns would stall silently. The forwarders
         * ignore the old cursor argument (the cursor lives on the campaign now)
         * and the work re-arms under the new names, so the queue converges within
         * one campaign's worth of chunks.
         *
         * No _deprecated_hook() notice: nothing third-party calls these, and a
         * notice would fire once per drained job.
         */
        add_action('fluentcrm_generate_sms_batch', function ($campaignId = 0) {
            (new MessageHandler())->handleGenerateBatch($campaignId);
        });

        add_action('fluentcrm_send_sms_batch', function ($campaignId = 0) {
            $this->handleSendBatch($campaignId);
        });

        // Single sends run inline now (see sendNow()), so nothing new is queued
        // under either name — but rows queued by 3.1.x still need draining.
        add_action('fluentcrm_send_single_sms', [$this, 'handleSendSingleMessage']);
        add_action('fluentcrm_send_single_message', [$this, 'handleSendSingleMessage']);

        // Health check piggybacks on the email plugin's existing 5-minute scheduler —
        // no separate AS action needed, rate-limited internally to once per 5 minutes
        add_action('fluentcrm_scheduled_five_minute_tasks', [$this, 'handleHealthCheck']);
        add_action('fluentcrm_scheduled_hourly_tasks', [$this, 'handleHealthCheck']);
    }

    /**
     * Handle sending a single SMS message by ID.
     * Called inline by dispatch(); also drains rows queued under
     * fluentcrm_send_single_sms by 3.1.x.
     *
     * @param int $messageId
     */
    public function handleSendSingleMessage($messageId)
    {
        if (!$this->isSystemOk()) {
            return;
        }

        $smsMessage = Message::with(['thread', 'thread.subscriber'])->find($messageId);

        if (!$smsMessage) {
            return;
        }

        if (!in_array($smsMessage->status, Message::CLAIMABLE)) {
            return;
        }

        if (!self::claimMessage($smsMessage->id)) {
            return; // Another runner already claimed this message
        }

        $this->deliverMessage($smsMessage);

        $this->logSentCount();
    }

    /**
     * Send one campaign's queued messages until the time or memory budget runs out.
     *
     * One action drains chunk after chunk rather than one chunk per action: the
     * per-message claim is what makes a send safe, not the action boundary, so
     * looping in-process costs nothing in safety and saves an Action Scheduler
     * round trip per chunk.
     *
     * The cursor lives on the campaign (an option), not in the action arguments,
     * so a continuation carries only the campaign id and can be cancelled by
     * hook + args.
     *
     * @param int $campaignId
     */
    public function handleSendBatch($campaignId)
    {
        if (!$this->isSystemOk()) {
            return;
        }

        $campaign = MessageCampaign::find($campaignId);

        if (!$campaign) {
            return;
        }

        // Abort if campaign is no longer in a sendable state
        if (in_array($campaign->status, ['paused', 'cancelled', 'draft', 'archived'])) {
            return;
        }

        // Transition from scheduled to working when it's time
        if ($campaign->status == 'scheduled' && strtotime($campaign->scheduled_at) <= current_time('timestamp')) {
            $campaign->status = 'working';
            $campaign->save();
        }

        if (!in_array($campaign->status, ['working', 'scheduled'])) {
            return;
        }

        // Reset stuck processing messages before fetching the first chunk
        self::resetStuckProcessingMessages($this->maximumProcessingTime + 30, $campaignId);

        $cursor         = MessageCampaign::getCursor($campaignId)['send'];
        $claimedThisRun = 0;
        $stoppedEarly   = false;

        while (true) {
            $messages = Message::forCampaign($campaignId)
                ->where('id', '>', $cursor)
                ->whereIn('status', Message::CLAIMABLE)
                ->where('scheduled_at', '<=', current_time('mysql'))
                ->with(['thread', 'thread.subscriber'])
                ->orderBy('id', 'ASC')
                ->limit($this->sendingPerChunk)
                ->get();

            if ($messages->isEmpty()) {
                break;
            }

            foreach ($messages as $message) {
                $cursor = $message->id;

                if (self::claimMessage($message->id)) {
                    $claimedThisRun++;
                    $this->deliverMessage($message);
                }

                if ($this->outOfTimeOrMemory()) {
                    $stoppedEarly = true;
                    break;
                }
            }

            // Persisted per chunk, not per message: a crash costs at most one
            // chunk of re-scanning, and those rows are no longer claimable.
            MessageCampaign::setCursor($campaignId, 'send', $cursor);

            if ($stoppedEarly) {
                break;
            }
        }

        $this->logSentCount();

        if ($stoppedEarly) {
            // More to do, but this worker is out of budget. Hand the campaign on;
            // the continuation re-reads the cursor.
            self::scheduleCampaignAction('fluentcrm_send_message_batch', $campaignId);
            return;
        }

        // The chunk query came back empty. Either everything claimable is done,
        // or what remains is scheduled for later.
        if (!$claimedThisRun) {
            // A full pass that claimed nothing means another worker owns these
            // rows and will finalize; rewind so this campaign is not left with a
            // cursor past rows that worker may yet release.
            MessageCampaign::setCursor($campaignId, 'send', 0);
        }

        $this->finishOrRetryLater($campaignId);
    }



    /**
     * Health check hooked to the email plugin's existing recurring schedulers
     * (fluentcrm_scheduled_five_minute_tasks / fluentcrm_scheduled_hourly_tasks).
     * Rescues stuck campaigns without creating any new background jobs.
     *
     * Covers two failure modes:
     * 1. Generation stuck: campaign in processing/pending-scheduled but AS action crashed
     * 2. Sending stuck: campaign in working/scheduled but send batch action disappeared
     */
    public function handleHealthCheck()
    {
        if (!MessageModule::isAnyChannelActive()) {
            return;
        }

        // Rate-limit: at most once every 5 minutes regardless of how often the hook fires
        $lastRun = fluentCrmGetOptionCache('_fcrm_sms_health_check_last', 360);
        if ($lastRun && (time() - $lastRun) < 300) {
            return;
        }
        fluentCrmSetOptionCache('_fcrm_sms_health_check_last', time(), 360);

        $now = current_time('timestamp');

        // Claims abandoned by a dead worker go back on the queue first, so the
        // stalled-campaign queries below see them as pending work.
        $recovered = self::resetStuckProcessingMessages(600);
        if ($recovered) {
            Helper::debugLog('SMS Health Check', 'Returned ' . $recovered . ' abandoned messages to the queue');
        }

        // --- Recovery 1: stuck generation ---
        // Campaigns still in pending-scheduled/processing whose scheduled_at is
        // >5 min in the past and whose row has not been touched for ten minutes.
        //
        // updated_at is the liveness test: every generation batch stamps it, so a
        // generator that is still working is never mistaken for a dead one and no
        // action-queue lookup is needed to tell them apart. Re-arming a campaign
        // that turns out to be alive is safe — the extra worker either finds the
        // status already advanced or inserts rows that maybeDeleteDuplicates()
        // removes when generation finalizes.
        $genStuckThreshold  = date('Y-m-d H:i:s', $now - 600);  // not updated for 10 min
        $pastScheduleTime   = date('Y-m-d H:i:s', $now - 300);  // scheduled_at >5 min ago

        $stuckGenCampaigns = MessageCampaign::whereIn('status', ['processing', 'pending-scheduled'])
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', $pastScheduleTime)
            ->where(function ($q) use ($genStuckThreshold) {
                // Only a campaign already in `processing` can have a live worker
                // to be mistaken for a dead one — generation claims the campaign
                // out of `pending-scheduled` in its first statement, so one still
                // sitting there five minutes past its send time never started.
                $q->where('status', 'pending-scheduled')
                    ->orWhere('updated_at', '<', $genStuckThreshold);
            })
            ->get(['id', 'status']);

        foreach ($stuckGenCampaigns as $campaign) {
            Helper::debugLog('SMS Health Check', 'Recovering stuck generation for campaign #' . $campaign->id . ' (status: ' . $campaign->status . ')');
            self::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaign->id);
        }

        // --- Recovery 2: stuck sending ---
        // Campaigns in working/scheduled that still hold messages which are ready
        // to go — scheduled_at already due — but where nothing has moved for ten
        // minutes.
        //
        // That last condition is the liveness test, and it reads the message rows
        // rather than the action queue. Claiming a message stamps updated_at, so a
        // send chain that is running at all keeps touching rows; a chain that died
        // stops. Asking Action Scheduler whether one of its own actions is
        // "in-progress" answered a slightly different question, and answered it by
        // hydrating action objects on a table that is far busier than this one.
        $sendStuckThreshold = date('Y-m-d H:i:s', $now - 600);
        $currentTime        = date('Y-m-d H:i:s', $now);

        $stuckSendCampaigns = MessageCampaign::whereIn('status', ['working', 'scheduled'])
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', $pastScheduleTime)
            ->whereHas('messages', function ($q) use ($currentTime) {
                $q->whereIn('status', [Message::STATUS_PENDING, Message::STATUS_SCHEDULED])
                    ->where('scheduled_at', '<=', $currentTime);
            })
            ->whereDoesntHave('messages', function ($q) use ($sendStuckThreshold) {
                $q->where('updated_at', '>', $sendStuckThreshold);
            })
            ->get(['id']);

        foreach ($stuckSendCampaigns as $campaign) {
            Helper::debugLog('SMS Health Check', 'Recovering stuck send for campaign #' . $campaign->id);
            self::scheduleCampaignAction('fluentcrm_send_message_batch', $campaign->id);
        }

        // Clean up any fully-sent campaigns still showing active statuses
        self::archiveCompletedCampaigns();
    }

    /**
     * Decide what happens to a campaign whose ready messages have run out.
     *
     * Three outcomes, and they are one decision: come back when the next
     * future-dated message is due, archive because nothing is left, or do
     * nothing because rows are still in flight elsewhere.
     */
    private function finishOrRetryLater($campaignId)
    {
        $nextMessage = Message::forCampaign($campaignId)
            ->whereIn('status', Message::CLAIMABLE)
            ->where('scheduled_at', '>', current_time('mysql'))
            ->orderBy('scheduled_at', 'ASC')
            ->first(['id', 'scheduled_at']);

        if ($nextMessage) {
            // rawDate(), not the cast attribute: get_gmt_from_date() expects the
            // original site-local database string, while the model casts
            // scheduled_at to a DateTime object. Never sooner than 30s, so a
            // clock skew cannot spin this into a tight loop.
            self::scheduleCampaignAction(
                'fluentcrm_send_message_batch',
                $campaignId,
                max(time() + 30, (int) get_gmt_from_date($nextMessage->rawDate('scheduled_at'), 'U'))
            );

            return;
        }

        if (Message::forCampaign($campaignId)->whereIn('status', Message::UNFINISHED)->count()) {
            // Still work in flight — another worker owns it and will finish.
            return;
        }

        $campaign = MessageCampaign::find($campaignId);

        if (!$campaign || !in_array($campaign->status, ['working', 'scheduled'])) {
            return;
        }

        MessageCampaign::where('id', $campaignId)->update([
            'status'     => 'archived',
            'updated_at' => current_time('mysql')
        ]);

        // Nothing left to resume from.
        MessageCampaign::clearCursor($campaignId);

        $campaign = MessageCampaign::find($campaignId);

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_archived', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_archived', $campaign);
        }
    }

    /**
     * Check if system is ready to process SMS.
     * Simplified: no option-based concurrency locks, Action Scheduler handles that.
     */
    private function isSystemOk()
    {
        // Any active channel keeps the queue running; per-message channel
        // resolution happens at send time.
        if (!MessageModule::isAnyChannelActive()) {
            return false;
        }

        $disabled = $this->applyFilterWithOldName(
            'fluent_crm/disable_message_processing',
            'fluent_crm/disable_sms_processing',
            false
        );

        if ($disabled) {
            return false;
        }

        $this->startingTimeStamp = time();

        if (memory_get_usage(true) >= (fluentCrmGetMemoryLimit() * 0.9)) {
            Helper::debugLog('SMS Scheduler Memory Exceeded', 'Memory Limit: ' . fluentCrmGetMemoryLimit() . ' | Current Usage: ' . memory_get_usage(true));
            return false;
        }

        return true;
    }

    /**
     * Send a single queued message.
     *
     * Identity comes from the thread, which is the point of the table: the
     * destination number is the conversation's number, so a message can no
     * longer be queued against one number and delivered to another.
     */
    protected function deliverMessage($smsMessage)
    {
        try {
            $thread = $smsMessage->thread;

            if (!$thread) {
                $this->markFailed($smsMessage, 'Message has no conversation thread');
                return;
            }

            $subscriber = $thread->subscriber;

            $phoneNumber = $thread->phone_number ?: ($subscriber ? $subscriber->phone : null);

            if (!$phoneNumber) {
                $this->markFailed($smsMessage, 'No valid phone number');
                return;
            }

            if (!$subscriber && !$this->isAuthorizedOneTimeMessage($smsMessage, $thread)) {
                $this->markFailed($smsMessage, 'Subscriber not found');
                return;
            }

            $channelSlug = $thread->channel ?: LegacyMessage::CHANNEL_SMS;
            $channel     = MessageModule::channel($channelSlug);

            // An unregistered channel must fail loudly rather than fall back to
            // SMS — a WhatsApp message delivered as an SMS is a consent breach.
            if (!$channel) {
                $this->markFailed($smsMessage, 'Unknown message channel: ' . $channelSlug);
                return;
            }

            // Prevent sending to the contact's own number when they are not subscribed
            // for the message channel. Custom target numbers remain intentional sends.
            // We only enforce this for the subscriber's saved phone number so custom target
            // numbers used in automation/manual flows can still be sent intentionally.
            if (
                $subscriber &&
                $subscriber->phone &&
                $phoneNumber === $subscriber->phone
            ) {
                if (!MessageThread::contactCanReceive($channelSlug, $subscriber->id)) {
                    $this->markFailed(
                        $smsMessage,
                        'Contact is not subscribed for ' . $channel->getLabel()
                    );
                    return;
                }
            }

            // The channel picks the message form (SMS: rendered body; WhatsApp:
            // template vs free-form per the 24-hour window) and dispatches it.
            $result = $channel->sendQueued($smsMessage, $subscriber, $phoneNumber);

            if ($result && isset($result['status']) && $result['status'] === 'success') {
                $this->markSent($smsMessage, $result);
                Helper::debugLog($channel->getLabel() . ' Sent', 'Phone: ' . $phoneNumber . ' | Message: ' . $smsMessage->id . ' | Result: ' . wp_json_encode($result));
                $this->sentCount++;
                $channel->onSent($smsMessage, $result);
            } else {
                Helper::debugLog($channel->getLabel() . ' Send Failed', 'Phone: ' . $phoneNumber . ' | Message: ' . $smsMessage->id . ' | Result: ' . wp_json_encode($result));
                $errorMessage = isset($result['message']) ? $result['message'] : 'Unknown error';
                $this->markFailed($smsMessage, $errorMessage);
                $channel->onFailed($smsMessage, $errorMessage);
            }

        } catch (\Exception $e) {
            $this->markFailed($smsMessage, $e->getMessage());
            Helper::debugLog('SMS Send Exception', $e->getMessage(), 'error');
        }
    }

    protected function isAuthorizedOneTimeMessage($smsMessage, MessageThread $thread)
    {
        $recipient = SMSHelper::oneTimeRecipientContext($smsMessage);
        if (!$recipient || !$smsMessage->ref_id || $smsMessage->ref_type !== Message::REF_CAMPAIGN) {
            return false;
        }

        if ($thread->status !== 'subscribed') {
            return false;
        }

        if ((string) ($recipient['phone_number'] ?? '') !== (string) $thread->phone_number) {
            return false;
        }

        $campaign = MessageCampaign::find((int) $smsMessage->ref_id);
        if (!$campaign || Arr::get($campaign->settings, 'sending_filter') !== 'one_time') {
            return false;
        }

        if (($thread->channel ?: LegacyMessage::CHANNEL_SMS) !== ($campaign->channel ?: LegacyMessage::CHANNEL_SMS)) {
            return false;
        }

        return OneTimeAudienceMeta::hasConfirmedConsent($campaign)
            && OneTimeAudienceMeta::getActiveBatchId($campaign) === (string) ($recipient['batch_id'] ?? '');
    }

    /**
     * Whether this worker should stop after the message it just handled.
     *
     * One check, because the two limits mean the same thing to the caller: hand
     * the rest to a continuation. Memory is measured against 90% of the limit so
     * the process still has room to finish the request it is in.
     */
    protected function outOfTimeOrMemory()
    {
        return (time() - $this->startingTimeStamp) >= $this->maximumProcessingTime
            || memory_get_usage(true) >= (fluentCrmGetMemoryLimit() * 0.9);
    }


    /**
     * Mark SMS as sent.
     */
    protected function markSent($smsMessage, $result)
    {
        $updateData = [
            'status'     => Message::STATUS_SENT,
            'sent_at'    => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];

        if (isset($result['provider_message_id'])) {
            $updateData['provider_message_id'] = $result['provider_message_id'];
        }

        Message::where('id', $smsMessage->id)->update($updateData);

        if ($smsMessage->ref_id) {
            MessageCampaign::where('id', $smsMessage->ref_id)
                ->increment('sent_count');
        }

        // The row was written through the query builder, which does not refresh
        // the model — so apply the outcome before the hook fires. A `sms_sent`
        // payload still reading `pending`, with no provider id on it, is no use
        // to a listener.
        foreach ($updateData as $field => $value) {
            $smsMessage->{$field} = $value;
        }

        // The thread carries the channel; a row whose thread has gone still
        // fires under a real name rather than fluent_crm/_sent.
        $channelSlug = ($smsMessage->thread ? $smsMessage->thread->channel : '') ?: LegacyMessage::CHANNEL_SMS;

        do_action('fluent_crm/' . $channelSlug . '_sent', $smsMessage, $result);
    }

    /**
     * Mark SMS as failed.
     */
    protected function markFailed($smsMessage, $errorMessage)
    {
        // fc_messages has no `notes` column — the provider's own words go in
        // `meta`, where the thread view already reads them from. Merged rather
        // than replaced so a template name or an attachment stored at queue
        // time survives the failure.
        $meta = is_array($smsMessage->meta) ? $smsMessage->meta : [];
        $meta['error_message'] = $errorMessage;

        Message::where('id', $smsMessage->id)->update([
            'status'     => Message::STATUS_FAILED,
            'meta'       => \maybe_serialize($meta),
            'updated_at' => current_time('mysql')
        ]);

        if ($smsMessage->ref_id) {
            MessageCampaign::where('id', $smsMessage->ref_id)
                ->increment('failed_count');
        }

        // As above: the model is stale until the outcome is applied to it.
        $smsMessage->status = Message::STATUS_FAILED;
        $smsMessage->meta = $meta;

        // The thread carries the channel; a row whose thread has gone still
        // fires under a real name rather than fluent_crm/_failed.
        $channelSlug = ($smsMessage->thread ? $smsMessage->thread->channel : '') ?: LegacyMessage::CHANNEL_SMS;

        do_action('fluent_crm/' . $channelSlug . '_failed', $smsMessage, $errorMessage);
    }

    /**
     * Parse message content with subscriber data.
     *
     * @deprecated Use SMSHelper::parseMessageContent() directly.
     */
    public function parseMessageContent($content, $subscriber)
    {
        return SMSHelper::parseMessageContent($content, $subscriber);
    }



    /**
     * Log sent count.
     */
    protected function logSentCount()
    {
        if ($this->sentCount > 0) {
            Helper::debugLog('SMS Sent Count', $this->sentCount . ' SMS messages sent');
        }
    }

    /**
     * Mark completed SMS campaigns as archived.
     */
    public static function archiveCompletedCampaigns()
    {
        $smsCampaigns = MessageCampaign::whereIn('status', ['working', 'scheduled'])
            ->whereDoesntHave('messages', function ($query) {
                $query->whereIn('status', array_merge(Message::UNFINISHED, ['draft']));
                return $query;
            })
            ->withoutGlobalScope('type')
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', date('Y-m-d H:i:s', current_time('timestamp') - 300))
            ->get();

        if (!$smsCampaigns->isEmpty()) {
            MessageCampaign::whereIn('id', array_unique($smsCampaigns->pluck('id')->toArray()))
                ->withoutGlobalScope('type')
                ->update([
                    'status' => 'archived'
                ]);

            foreach ($smsCampaigns as $smsCampaign) {
                MessageCampaign::clearCursor($smsCampaign->id);
                if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
                    do_action('fluent_crm/whatsapp_campaign_archived', $smsCampaign);
                } else {
                    do_action('fluent_crm/sms_campaign_archived', $smsCampaign);
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Seconds a provider call may take when it runs inline.
     *
     * Deliberately short. Whatever is on the other end of this request — an
     * admin screen or a customer's checkout — is held open for the duration.
     *
     * Note what a timeout means here: the row is marked failed, but the provider
     * may in fact have accepted the message. That ambiguity is not resolvable
     * from this side, and it is why a timed-out send is not retried
     * automatically — a duplicate is worse than a message reported as failed
     * that actually arrived. The provider's own timeout text is stored on the
     * row so the outcome reads as ambiguous rather than as a rejection.
     */
    const INLINE_SEND_TIMEOUT = 5;

    /**
     * Write a message and send it in this request, without going via the queue.
     *
     * For the paths where somebody is waiting on the answer — an operator who
     * just pressed Send, an automation step — the queue only bought a delay. The
     * row is still written first, so a request killed mid-send leaves a record
     * rather than nothing.
     *
     * Returns the row as it stands after the attempt: `sent`, `failed`, or still
     * pending when the send was deferred rather than attempted.
     *
     * @param string $channel sms|whatsapp
     * @param string $phone the number to message
     * @param int|null $contactId
     * @param string $body rendered message body
     * @param array $extra ref_type, ref_id, template_id, meta
     * @return Message|null null when the number is unusable
     */
    public static function sendNow(string $channel, string $phone, $contactId, string $body, array $extra = [])
    {
        $message = MessageThread::queueOutbound($channel, $phone, $contactId, $body, $extra);

        if (!$message) {
            return null;
        }

        static::dispatch($message->id);

        // Re-read: dispatch() writes the outcome to the row, not to this object.
        return Message::find($message->id) ?: $message;
    }

    /**
     * Send one already-written message in this request.
     *
     * Direct sends, automation steps and opt-in/opt-out confirmations all have
     * somebody waiting — an operator who pressed Send, a funnel worker, a
     * customer mid-checkout — so there is no queue here at all. The row is
     * written before the provider is called, so a request killed mid-send leaves
     * a record rather than nothing.
     *
     * The send runs through the same single-message handler the queue uses, so
     * an inline send applies exactly the same consent check, channel resolution,
     * hooks and failure recording as a campaign send. Only the timing differs.
     *
     * @param int $messageId
     */
    public static function dispatch($messageId): void
    {
        $messageId = (int) $messageId;

        if (!$messageId) {
            return;
        }

        // Somebody is waiting on this request, and a degraded provider endpoint
        // should cost seconds rather than the driver's full queued-send budget.
        // min(), not a flat set, so a site that has already lowered it keeps its
        // own value.
        $inlineTimeout = max(1, (int) apply_filters('fluent_crm/message_inline_send_timeout', self::INLINE_SEND_TIMEOUT));

        $capTimeout = function ($timeout) use ($inlineTimeout) {
            return min((int) $timeout, $inlineTimeout);
        };

        add_filter('fluent_crm/message_send_timeout', $capTimeout, 99);

        try {
            (new static())->handleSendSingleMessage($messageId);
        } finally {
            remove_filter('fluent_crm/message_send_timeout', $capTimeout, 99);
        }
    }
}
