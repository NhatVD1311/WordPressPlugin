<?php

namespace FluentCampaign\App\Modules\Messaging;

use FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface;
use FluentCampaign\App\Utils\Enqueuer\Enqueue;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageHandler;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\SMS\Providers\AWSDriver;
use FluentCampaign\App\Modules\Messaging\SMS\Providers\TwilioDriver;
use FluentCampaign\App\Modules\Messaging\SMS\SMSChannel;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\MetaCloudDriver;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\TwilioWhatsAppDriver;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppChannel;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

class MessageModule
{
    public function init($app)
    {
        // Before anything reads the switch. Every reader of the experimental
        // settings sits on a later hook than `fluentcrm_loaded`, and Helper
        // memoizes them per request, so adopting here is what keeps an upgraded
        // install from spending a request with its channels reported off.
        self::copySmsSwitchToModuleSwitch();

        // Registered before the gate below, because the request that turns the
        // module on is by definition one where it is still off. The switch is
        // saved by core, which cannot see this module's tables, so the module
        // creates them itself the moment it is switched on — the screens the
        // next page load opens would otherwise query tables that are not there.
        add_action('fluent_crm/experimental_settings_saved', function ($settings) {
            if (Arr::get($settings, 'messaging_module') === 'yes') {
                MessageMigrator::migrate();
            }
        });

        if (!self::isEnabled()) {
            return;
        }

        add_action('init', function () use ($app) {
            $this->register($app);
        });
    }

    /**
     * The one switch for the whole module.
     *
     * Messaging ships off. While it is off nothing in here loads — no drivers,
     * no channels, no routes, no menus — and both channels report themselves
     * inactive (see SMSHelper::isActive() and WhatsAppHelper::isActive()), so a
     * `_fc_sms_enable` left set from an earlier trial cannot quietly keep
     * sending. Turning the module on is what makes the per-channel switches
     * mean anything.
     */
    public static function isEnabled(): bool
    {
        return Helper::isExperimentalEnabled('messaging_module');
    }

    /**
     * The channels this module ships, keyed by slug.
     *
     * A literal, not a registry. Channels used to register themselves at boot,
     * which bought an extension point nobody used and cost a round of ceremony
     * — a register() call, a reset() seam, an action to hook — around a list
     * that has only ever held these two. Adding a third is a line here.
     *
     * Built once per request: the objects are stateless, but the send loop asks
     * for them per message.
     *
     * @return ChannelInterface[]
     */
    public static function channels(): array
    {
        static $channels = null;

        if ($channels === null) {
            $channels = [
                'sms'      => new SMSChannel(),
                'whatsapp' => new WhatsAppChannel(),
            ];
        }

        return $channels;
    }

    /**
     * Resolve a channel by slug.
     *
     * Returns null for an unknown slug — callers must treat that as an error
     * rather than silently falling back, so a message is never delivered over a
     * channel it was not composed for.
     */
    public static function channel(string $slug): ?ChannelInterface
    {
        return self::channels()[$slug] ?? null;
    }

    /**
     * @return ChannelInterface[] only the channels the site has switched on
     */
    public static function activeChannels(): array
    {
        return array_filter(self::channels(), function (ChannelInterface $channel) {
            return $channel->isActive();
        });
    }

    /**
     * Put this module's Vue screens into core's admin app.
     *
     * The module owns its whole UI — components, routes and build — and core
     * holds no list of them. Our entry registers routes on the
     * `fluentcrm_global_routes` JS filter that core applies in
     * createFluentCrmApp() before building the router; `vue` and
     * `element-plus` are externals in our bundle, resolved through the import
     * map core prints, so we render on core's single Vue instance rather than
     * a second copy of our own.
     *
     * Enqueued on `fluentcrm_loading_app`, which core fires one line before it
     * enqueues admin/app.js. Both are ES modules, so document order is
     * execution order: our filter is registered before core reads it.
     *
     * @return void
     */
    private function registerAdminApp()
    {
        // Core runs the CRM screens in no-conflict mode: on wp_print_scripts it
        // dequeues every script served out of wp-content/plugins whose URL does
        // not match an approved slug, and the only built-in slug is
        // 'fluent-crm'. Our bundle lives under fluentcampaign-pro, so without
        // this it is registered, then silently dropped before it prints.
        add_filter('fluent_crm_asset_listed_slugs', function ($slugs) {
            $slugs[] = 'fluentcampaign-pro';
            return $slugs;
        });

        add_action('fluentcrm_loading_app', function () {
            // A core older than the contract has no import map and no
            // shared/ui.js, so our bundle would fail to resolve its imports and
            // take the admin app down with it. Skip the UI instead; the REST
            // routes and menus above are unaffected.
            if (!defined('FLUENTCRM_MODULE_API') || FLUENTCRM_MODULE_API < 1) {
                return;
            }

            Enqueue::script(
                'fluentcampaign-messaging',
                'admin/messaging.js',
                ['fluentcrm_admin_app_boot'],
                FLUENTCAMPAIGN_PLUGIN_VERSION
            );
        });
    }

    public static function isAnyChannelActive(): bool
    {
        return (bool) self::activeChannels();
    }

    /**
     * Carry a pre-Messaging install's SMS switch onto the module switch.
     *
     * Up to 3.1.7 there was no module switch: SMS ran whenever `_fc_sms_enable`
     * said so, and the settings screen mirrored that into the experimental key
     * `sms_module`, which nothing ever read back. `messaging_module` defaults to
     * 'no', so without this an upgrade would take a site with working SMS and
     * silently stop it — isEnabled() false makes every channel report inactive.
     *
     * The channel options decide, not the old `sms_module` mirror: the mirror is
     * only as good as the last save through that one screen, whereas the option
     * is what actually decided whether SMS ran.
     *
     * Runs once — the key's presence is the guard, and a site that never had a
     * channel on records the 'no' it would have defaulted to anyway.
     */
    private static function copySmsSwitchToModuleSwitch(): void
    {
        $settings = get_option('_fluentcrm_experimental_settings', []);

        if (!is_array($settings)) {
            $settings = [];
        }

        if (array_key_exists('messaging_module', $settings)) {
            return;
        }

        $hadChannelOn = fluentcrm_get_option('_fc_sms_enable', 'no') === 'yes'
            || fluentcrm_get_option('_fc_whatsapp_enable', 'no') === 'yes';

        $settings['messaging_module'] = $hadChannelOn ? 'yes' : 'no';

        // The retired mirrors. Nothing reads them, and leaving them in place
        // invites the next reader into thinking there are three switches here.
        unset($settings['sms_module'], $settings['whatsapp_module']);

        update_option('_fluentcrm_experimental_settings', $settings, 'yes');
    }

    /**
     * Let a contact's consent per channel be segmented on.
     *
     * The rows go into core's "Contact Segment" group beside Status and Tags,
     * because that is what they are to an operator — another way this contact is
     * or is not reachable. Core cannot answer them: consent lives on the threads
     * in this module's table, so each row is claimed by the per-property action
     * core fires for segment rows it does not own, and MessageThread applies it.
     *
     * Not gated on a channel being active. Consent outlives a channel being
     * switched off — the opt-outs are still on record, and a segment saved while
     * the channel ran has to keep meaning what it meant.
     */
    private function registerConsentFilters()
    {
        add_filter('fluentcrm_advanced_filter_options', function ($groups) {
            if (empty($groups['segment']['children'])) {
                return $groups;
            }

            foreach (self::channels() as $slug => $channel) {
                $groups['segment']['children'][] = [
                    /* translators: %s: channel name, e.g. SMS or WhatsApp */
                    'label'             => sprintf(__('%s Status', 'fluentcampaign-pro'), $channel->getLabel()),
                    'value'             => $slug . '_status',
                    'type'              => 'selections',
                    'options'           => MessageThread::consentStatusLabels(),
                    'is_multiple'       => true,
                    // Keeps the operators to "includes in" / "not includes in":
                    // a contact holds one status per channel, so "includes all
                    // of" could only ever match nothing.
                    'is_singular_value' => true,
                    'help'              => __('A contact with no conversation on this channel counts as subscribed.', 'fluentcampaign-pro')
                ];
            }

            return $groups;
        });

        foreach (array_keys(self::channels()) as $slug) {
            // By value, like core's own contact filter handlers: the builder is
            // mutated in place, and the return of a do_action is discarded.
            add_action('fluent_crm/contacts_filter_segment_' . $slug . '_status', function ($query, $filter) use ($slug) {
                // Reading the operator the way buildSegmentFilterQuery reads it
                // for the rows core owns, so a row here cannot mean something
                // different from the Status row above it.
                $inclusive = in_array(Arr::get($filter, 'operator'), ['in', 'contains'], true);

                return MessageThread::applyStatusFilter(
                    $query,
                    $slug,
                    (array) Arr::get($filter, 'value', []),
                    !$inclusive
                );
            }, 10, 2);
        }
    }

    public function register($app)
    {
        // Register built-in drivers — constructor auto-registers via SMSDriverManager.
        // Runs before isActive() so the settings page always has driver options.
        new TwilioDriver();
        new AWSDriver();
        do_action('fluent_crm/register_sms_providers');

        // Register built-in WhatsApp drivers — same as SMS, before any isActive()
        // gate so the WhatsApp settings page always has provider options.
        new TwilioWhatsAppDriver();
        new MetaCloudDriver();
        do_action('fluent_crm/register_whatsapp_providers');

        // The module being on is the only gate on the routes: the screens behind
        // them are how a channel gets switched on in the first place, and thread
        // history stays readable while both channels are off.
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/messaging_api.php';
        });

        add_filter('fluent_crm/admin_vars', function ($adminVars) {
            // sms_enabled / whatsapp_enabled are kept as-is: existing screens read
            // them directly. `messaging` is the channel-agnostic view the new
            // routes and menus use, so adding a channel needs no Vue changes.
            $adminVars['sms_enabled'] = SMSHelper::isActive() ? 'yes' : 'no';
            $adminVars['whatsapp_enabled'] = WhatsAppHelper::isActive() ? 'yes' : 'no';
            $adminVars['messaging'] = [
                'active_channels' => array_keys(self::activeChannels()),
                'channels'        => array_map(function ($channel) {
                    return [
                        'slug'       => $channel->getSlug(),
                        'label'      => $channel->getLabel(),
                        'active'     => $channel->isActive(),
                        'max_length' => $channel->getMaxLength(),
                    ];
                }, array_values(self::channels())),
            ];
            return $adminVars;
        });

        $this->registerConsentFilters();

        /*
         * Everything above this line is what a site needs in order to turn a
         * channel on: the settings routes and the admin vars those screens read.
         * Everything below is the Messaging area itself, and with no channel
         * active there is nothing in it — no campaign can exist, no message can
         * arrive — so the menus stay away rather than leading to empty screens.
         *
         * Saving a channel's settings reloads the page (both save endpoints
         * return `reload` when the enabled state changed), which is what gets
         * these menus registered without the admin having to refresh by hand.
         */
        if (!self::isAnyChannelActive()) {
            return;
        }

        $this->registerAdminApp();

        /*
         * The contact-profile Message tab.
         *
         * The section is only the tab button; its route and Vue screen are
         * registered by resources/admin/messaging.js. Core drops any section
         * whose route the router does not have, so if this module's bundle is
         * ever skipped (see registerAdminApp) the tab disappears with it rather
         * than leading nowhere.
         *
         * Inserted straight after Emails so the contact's channels read
         * together, instead of being appended after Notes.
         */
        add_filter('fluentcrm_profile_sections', function ($sections) {
            $messages = [
                'subscriber_messages' => [
                    'name'    => 'subscriber_messages',
                    'title'   => __('Message', 'fluentcampaign-pro'),
                    'handler' => 'route'
                ]
            ];

            $offset = array_search('subscriber_emails', array_keys($sections), true);

            if ($offset === false) {
                return $sections + $messages;
            }

            return array_slice($sections, 0, $offset + 1, true)
                + $messages
                + array_slice($sections, $offset + 1, null, true);
        });

        // sidebar menu item
        add_action('fluent_crm/after_core_menu_items', function ($permissions, $isAdmin) {

            $canReadEmails = in_array('fcrm_read_emails', $permissions);
            $canManageTemplates = in_array('fcrm_manage_email_templates', $permissions);

            if (!$canReadEmails && !$canManageTemplates) {
                return;
            }

            $menuPath = $canReadEmails ? 'messaging/inbox' : 'messaging/whatsapp/templates';

            add_submenu_page(
                'fluentcrm-admin',
                __('Messaging', 'fluentcampaign-pro'),
                __('Messaging', 'fluentcampaign-pro'),
                ($isAdmin) ? 'manage_options' : ($canReadEmails ? 'fcrm_read_emails' : 'fcrm_manage_email_templates'),
                'fluentcrm-admin#/' . $menuPath,
                '__return_null'
            );
        }, 9, 2);

        // top menu item
        add_filter('fluent_crm/core_menu_items', function ($items, $permissions, $urlBase = null) {

            $canReadEmails = in_array('fcrm_read_emails', $permissions);
            $canManageTemplates = in_array('fcrm_manage_email_templates', $permissions);

            if (!$canReadEmails && !$canManageTemplates) {
                return $items;
            }

            if (!$urlBase) {
                $urlBase = fluentcrm_menu_url_base();
            }

            $messagingMenu = [
                'key'          => 'messaging',
                'label'        => __('Messaging', 'fluentcampaign-pro'),
                // Readers land in Inbox; template-only users land on the screen
                // their capability actually allows.
                'permalink'    => $urlBase . ($canReadEmails ? 'messaging/inbox' : 'messaging/whatsapp/templates'),
                'layout_class' => 'sms_menu',
            ];

            // The Inbox leads, ahead of the per-channel campaign entries: it is
            // the one screen that spans every channel, and it is where an
            // unanswered contact is waiting. Campaigns are outbound work and can
            // follow.
            $subItems = [
                [
                    'key'         => 'messaging_inbox',
                    'label'       => __('Inbox', 'fluentcampaign-pro'),
                    'permalink'   => $urlBase . 'messaging/inbox',
                    'description' => __('Read and reply to every conversation in one place', 'fluentcampaign-pro'),
                    'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.25 3.25H16.75C16.9489 3.25 17.1397 3.32902 17.2803 3.46967C17.421 3.61032 17.5 3.80109 17.5 4V16C17.5 16.1989 17.421 16.3897 17.2803 16.5303C17.1397 16.671 16.9489 16.75 16.75 16.75H3.25C3.05109 16.75 2.86032 16.671 2.71967 16.5303C2.57902 16.3897 2.5 16.1989 2.5 16V4C2.5 3.80109 2.57902 3.61032 2.71967 3.46967C2.86032 3.32902 3.05109 3.25 3.25 3.25ZM16 11.5H12.8703C12.2358 12.8482 10.8672 13.75 9.3125 13.75C7.75781 13.75 6.38922 12.8482 5.75469 11.5H4V15.25H16V11.5ZM4 10H6.875C6.875 11.3462 7.96625 12.25 9.3125 12.25C10.6588 12.25 11.75 11.3462 11.75 10H16V4.75H4V10Z" fill="#525866"/>
                            </svg>'
                ]
            ];

            // Each active channel contributes its own campaign entry, so a
            // WhatsApp-only install never shows an SMS menu and vice versa.
            foreach (self::activeChannels() as $channel) {
                foreach ($channel->getMenuItems($urlBase) as $item) {
                    $subItems[] = $item;
                }
            }

            $subItems[] = [
                'key'         => 'message_templates',
                'label'       => __('Templates', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/whatsapp/templates',
                'description' => __('Browse reusable SMS and WhatsApp message templates', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.375 2.5H15.625C15.9702 2.5 16.25 2.77982 16.25 3.125V16.875C16.25 17.2202 15.9702 17.5 15.625 17.5H4.375C4.02982 17.5 3.75 17.2202 3.75 16.875V3.125C3.75 2.77982 4.02982 2.5 4.375 2.5ZM5 3.75V16.25H15V3.75H5ZM6.875 6.25H13.125V7.5H6.875V6.25ZM6.875 9.375H13.125V10.625H6.875V9.375ZM6.875 12.5H10.625V13.75H6.875V12.5Z" fill="#525866"/>
                            </svg>'
            ];

            // Activities is shared across channels — one table, one screen, with
            // a channel filter. See docs/MESSAGING_MODULE_REFACTOR.md §6.
            $subItems[] = [
                'key'         => 'message_activities',
                'label'       => __('Activities', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/activities',
                'description' => __('View all messages that have been sent or are scheduled to be sent by FluentCRM', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.84125 15.25L2.5 17.875V4C2.5 3.80109 2.57902 3.61032 2.71967 3.46967C2.86032 3.32902 3.05109 3.25 3.25 3.25H16.75C16.9489 3.25 17.1397 3.32902 17.2803 3.46967C17.421 3.61032 17.5 3.80109 17.5 4V14.5C17.5 14.6989 17.421 14.8897 17.2803 15.0303C17.1397 15.171 16.9489 15.25 16.75 15.25H5.84125ZM5.32225 13.75H16V4.75H4V14.7887L5.32225 13.75ZM9.25 8.5H10.75V10H9.25V8.5ZM6.25 8.5H7.75V10H6.25V8.5ZM12.25 8.5H13.75V10H12.25V8.5Z" fill="#525866"/>
                            </svg>'
            ];

            if (!$canReadEmails) {
                $subItems = array_values(array_filter($subItems, function ($item) {
                    return $item['key'] === 'message_templates';
                }));
            }

            $messagingMenu['sub_items'] = $subItems;

            $items[] = $messagingMenu;

            return $items;

        }, 10, 3);

        (new MessageScheduler())->register();
        (new MessageHandler())->register();

    }

}
