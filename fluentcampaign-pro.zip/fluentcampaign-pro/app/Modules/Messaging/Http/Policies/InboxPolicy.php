<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Policies;

use FluentCrm\App\Http\Policies\BasePolicy;
use FluentCrm\Framework\Http\Request\Request;

/**
 * InboxPolicy — REST permissions for the conversation inbox.
 *
 * Mirrors CampaignPolicy: reading a conversation needs `fcrm_read_emails`, and
 * anything that writes needs `fcrm_manage_emails`. Marking a thread read is a
 * write, so it sits on the manage capability rather than the read one — someone
 * with read-only access should not be able to clear another manager's unread
 * badge.
 *
 * Deliberately does NOT gate on MessageModule::isAnyChannelActive(), unlike
 * MessagePolicy. Threads hold history that stays readable after every channel
 * has been switched off, which is the behavior these routes had while they
 * lived in core.
 *
 * @package FluentCampaign\App\Modules\Messaging\Http\Policies
 */
class InboxPolicy extends BasePolicy
{
    /**
     * @param Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        if ($this->requestMethod($request) == 'GET') {
            return $this->currentUserCan('fcrm_read_emails');
        }

        return $this->currentUserCan('fcrm_manage_emails');
    }

    /**
     * POST /messaging/threads/{id}/consent — MessageThreadController::updateConsent
     *
     * Consent is a contact decision wherever it is made, so it takes the same
     * capability from the inbox as it does from a contact profile rather than
     * the inbox's own write capability.
     *
     * @param Request $request
     * @return bool
     */
    public function updateConsent(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_contacts');
    }

    /**
     * POST /messaging/threads/{id}/contact — MessageThreadController::linkContact
     *
     * Attaching CRM identity to a conversation is both a contact decision and
     * an inbox write, so direct REST calls must pass both permission boundaries.
     *
     * @param Request $request
     * @return bool
     */
    public function linkContact(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_contacts') && $this->currentUserCan('fcrm_manage_emails');
    }

    /**
     * Recipient search exposes CRM contact data, so it follows the same
     * permission as starting a conversation rather than the read-only inbox.
     *
     * @param Request $request
     * @return bool
     */
    public function recipients(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_emails');
    }
}
