<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Policies;

use FluentCrm\App\Http\Policies\BasePolicy;
use FluentCrm\Framework\Http\Request\Request;
use FluentCampaign\App\Modules\Messaging\MessageModule;

class MessagePolicy extends BasePolicy
{
    protected function hasActiveMessagingChannel(): bool
    {
        return MessageModule::isAnyChannelActive();
    }

    /**
     * Allow read access to Messaging while reserving mutations for managers.
     *
     * @param  \FluentCrm\Framework\Http\Request\Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        // These routes serve every channel, so any active channel grants access.
        // Gating on SMS alone would 403 a WhatsApp-only install.
        if (!$this->hasActiveMessagingChannel()) {
            return false;
        }

        if ($this->requestMethod($request) === 'GET') {
            return $this->currentUserCan('fcrm_read_emails');
        }

        return $this->currentUserCan('fcrm_manage_emails');
    }

    /*
     * The framework resolves the policy method by CONTROLLER METHOD NAME
     * (Route appends it to the policy class, falling back to verifyRequest).
     * Each destructive controller method therefore needs its own entry here —
     * a single delete() only covers a controller method literally named delete.
     */

    public function delete(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    /** DELETE /messaging/messages — MessageController::deleteMessages */
    public function deleteMessages(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_email_delete');
    }

    /** POST /messaging/campaigns/do-bulk-action — MessageController::handleBulkAction */
    public function handleBulkAction(Request $request)
    {
        if ($request->getSafe('action_name', 'sanitize_key', '') == 'delete_campaigns') {
            return $this->currentUserCan('fcrm_manage_email_delete');
        }

        return $this->currentUserCan('fcrm_manage_emails');
    }

    /** GET /whatsapp/templates — WhatsAppTemplateController::index */
    public function index(Request $request)
    {
        return $this->hasActiveMessagingChannel() && (
            $this->currentUserCan('fcrm_read_emails') ||
            $this->currentUserCan('fcrm_manage_email_templates')
        );
    }

    /** POST /whatsapp/templates — WhatsAppTemplateController::store */
    public function store(Request $request)
    {
        return $this->hasActiveMessagingChannel() && $this->currentUserCan('fcrm_manage_email_templates');
    }

    /** POST /whatsapp/templates/sync — WhatsAppTemplateController::sync */
    public function sync(Request $request)
    {
        return $this->hasActiveMessagingChannel() && $this->currentUserCan('fcrm_manage_email_templates');
    }

    /** POST /whatsapp/templates/validate — WhatsAppTemplateController::validateTemplate */
    public function validateTemplate(Request $request)
    {
        return $this->hasActiveMessagingChannel() && $this->currentUserCan('fcrm_manage_email_templates');
    }

    /** DELETE /whatsapp/templates/{id} — WhatsAppTemplateController::destroy */
    public function destroy(Request $request)
    {
        return $this->hasActiveMessagingChannel() && $this->currentUserCan('fcrm_manage_email_delete');
    }

    /**
     * POST /messaging/subscribers/{id}/consent — MessageController::updateConsent
     *
     * Consent is a contact decision, so it keeps the capability core's contact
     * property editor used, not the messaging one.
     */
    public function updateConsent(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_contacts');
    }

    /** POST /whatsapp/subscribers/{id}/send — WhatsAppTemplateController::sendCustomMessage */
    public function sendCustomMessage(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_emails');
    }

}
