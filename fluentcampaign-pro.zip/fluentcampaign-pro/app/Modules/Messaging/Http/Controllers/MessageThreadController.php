<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Contracts\TemplateApiInterface;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Http\Request\Request;

/**
 * Read path for the Messaging Inbox.
 *
 * Shapes the conversation rail and the thread view. The payloads here match
 * what the Vue screens already consume from `Inbox/mock/inboxApi.js`, so
 * swapping the mock for these endpoints does not touch a component.
 *
 * @package FluentCrm\App\Http\Controllers
 */
class MessageThreadController extends Controller
{
    /**
     * Rows per page when the caller does not ask.
     */
    const PER_PAGE = 25;

    /**
     * Ceiling on what a caller may ask for. Each row costs a preview lookup and
     * a serialized subscriber, so this is a memory and response-time bound, not
     * a permission one.
     */
    const MAX_PER_PAGE = 100;

    /**
     * Ceiling on recipient search results. The dialog shows a short pick list,
     * not a browsable directory — a longer list is slower to scan, not more
     * useful.
     */
    const RECIPIENT_LIMIT = 20;

    /**
     * Minimum term length before the dialog searches CRM contact phone numbers.
     *
     * Direct phone sends still use directNumber(), so a valid fresh number can
     * be selected without broad contact-table scans for short fragments.
     */
    const RECIPIENT_PHONE_SEARCH_MIN_LENGTH = 3;

    /**
     * Conversations for the rail, newest activity first.
     *
     * `unread_count` and `last_message_id` are stored thread caches. That keeps
     * filtering paginatable and avoids a sorted correlated message lookup for
     * every row on every rail request.
     *
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $query = MessageThread::query()->with(['subscriber']);

        $channel = sanitize_text_field($request->get('channel', ''));
        if ($channel) {
            $query->where('channel', $channel);
        }

        $search = sanitize_text_field($request->get('search', ''));
        if ($search) {
            $query->searchBy($search);
        }

        // A consent-only thread is not a conversation: the migration records an
        // opt-out as a thread so the number owns its own consent, and an
        // operator must not find those in the inbox. They appear the moment a
        // real message lands on them.
        $query->where(function ($q) {
            $q->whereNotNull('last_message_id')
                ->orWhere('initiated_by', '!=', MessageThread::INITIATED_BY_SYSTEM);
        });

        // A real WHERE now that the count is stored. Filtering after pagination
        // — which is all a derived column allowed — returned short pages and
        // made the total meaningless.
        if ($request->get('unread_only')) {
            $query->where('unread_count', '>', 0);
        }

        // `updated_at` is maintained as the newest message time, so this is the
        // same order the thread view uses.
        $threadsPage = $query->orderBy('updated_at', 'DESC')
            ->paginate(self::perPage($request));

        $rows = $threadsPage->items();

        // One query for every preview on the page, rather than one per row.
        $lastIds = array_filter(array_map(function ($row) {
            return (int) $row->last_message_id;
        }, $rows));

        // A plain array rather than a Collection, so the empty case and the
        // populated case take exactly the same path. The framework has no
        // global collect() helper, and an empty rail — a site that has not
        // migrated yet — is the common first-run state, not an edge case.
        $previews = [];

        if ($lastIds) {
            foreach (Message::whereIn('id', $lastIds)->get() as $message) {
                $previews[(int) $message->id] = $message;
            }
        }

        // One grouped query for the whole page's WhatsApp windows, rather than
        // one per row.
        $lastInbound = $this->lastInboundMap($rows);

        $formatted = [];
        foreach ($rows as $row) {
            $previewId = (int) $row->last_message_id;
            $preview = isset($previews[$previewId]) ? $previews[$previewId] : null;
            $formatted[] = $this->formatThread($row, $preview, false, [
                'last_inbound_at' => isset($lastInbound[(int) $row->id]) ? $lastInbound[(int) $row->id] : null
            ]);
        }

        return [
            'conversations' => $formatted,
            'total'         => $threadsPage->total(),
            'per_page'      => $threadsPage->perPage(),
            'current_page'  => $threadsPage->currentPage()
        ];
    }

    /**
     * Messages in one thread, oldest first — the order the view renders in.
     *
     * `before` pages backwards through history: it returns the messages
     * immediately older than the given id, which is what the thread asks for
     * when the reader scrolls to the top.
     *
     * @param Request $request
     * @param int $id
     * @return array
     */
    public function messages(Request $request, $id)
    {
        $thread = MessageThread::with(['subscriber'])->findOrFail($id);

        $perPage = self::perPage($request);
        $before = $request->getSafe('before', 'intval', 0);

        $query = Message::where('thread_id', $thread->id);

        if ($before) {
            $query->where('id', '<', $before);
        }

        // Newest-first with a limit, then reversed: taking the *tail* of a
        // conversation is the point, and ordering ascending with a limit would
        // return its beginning.
        $messages = $query->conversationOrder('DESC')
            ->orderBy('id', 'DESC')
            ->limit($perPage)
            ->get()
            ->reverse()
            ->values();

        $oldest = $messages->first();

        return [
            'messages' => array_map([$this, 'formatMessage'], $messages->all()),
            'has_more' => $oldest ? Message::where('thread_id', $thread->id)
                ->where('id', '<', $oldest->id)->exists() : false,
            'thread'   => $this->formatThread($thread, null, true)
        ];
    }

    /**
     * Send a free-form message into a thread.
     *
     * The row is written before the send and updated with the outcome, so a
     * request that dies mid-flight leaves a record of the attempt rather than a
     * message that silently never existed.
     *
     * Dispatch itself belongs to FluentCampaign Pro — SMS and WhatsApp are Pro
     * features and core has no drivers — so this resolves the channel through
     * MessageModule::channel() and fails cleanly when it is absent.
     *
     * Named sendMessage rather than send: Controller::send() is the base
     * response helper, and overriding it with a different signature is a fatal
     * that php -l does not catch, because signature compatibility is checked at
     * runtime.
     *
     * @param Request $request
     * @param int $id
     * @return array|\WP_REST_Response
     */
    public function sendMessage(Request $request, $id)
    {
        $thread = MessageThread::findOrFail($id);

        if (sanitize_key($request->get('message_type', 'text')) === 'template') {
            return $this->sendThreadTemplateMessage($request, $thread);
        }

        $content = trim((string) $request->get('content', ''));

        if ($content === '') {
            return $this->sendError(['message' => __('Write a message first.', 'fluent-crm')], 422);
        }

        // WhatsApp only accepts free-form text inside the 24-hour window the
        // contact's own message opens. Outside it Meta rejects the send, so
        // refusing here is more honest than recording a failure the admin has
        // to go looking for.
        $session = $this->sessionState($thread);

        if ($thread->channel === 'whatsapp' && empty($session['has_active_session'])) {
            return $this->sendError([
                'message' => __('This WhatsApp conversation is outside its 24-hour window, so only an approved template can be sent.', 'fluent-crm')
            ], 409);
        }

        $channel = $this->resolveChannel($thread->channel);

        if (!$channel) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluent-crm')
            ], 409);
        }

        $message = $thread->recordMessage([
            'direction'  => Message::DIRECTION_OUTBOUND,
            'content'    => $content,
            'ref_type'   => 'inbox',
            'status'     => 'pending',
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ]);

        $result = $channel->send($thread->phone_number, $content);

        $succeeded = ($result['status'] ?? '') === 'success';

        $message->status = $succeeded ? 'sent' : 'failed';
        $message->sent_at = $succeeded ? current_time('mysql') : null;

        if (!empty($result['provider_message_id'])) {
            $message->provider_message_id = $result['provider_message_id'];
        }

        if (!$succeeded) {
            // The provider's own words, kept where the thread can show them
            // rather than discarded into a log.
            $message->meta = ['error_message' => $result['message'] ?? ''];
        }

        $message->save();
        MessageThread::syncCaches([$thread->id]);

        if (!$succeeded) {
            return $this->sendError([
                'message' => $result['message'] ?: __('The message could not be sent.', 'fluent-crm'),
                'sent_message' => $this->formatMessage($message)
            ], 422);
        }

        return [
            'sent_message' => $this->formatMessage($message),
            'message'      => __('Message sent.', 'fluent-crm')
        ];
    }

    /**
     * Send an approved WhatsApp template to an existing inbox thread.
     *
     * This mirrors the contact profile's template dialog, but keys the send to
     * the thread phone number so contactless WhatsApp conversations can send a
     * template too.
     *
     * @param Request $request
     * @param MessageThread $thread
     * @return array|\WP_REST_Response
     */
    protected function sendThreadTemplateMessage(Request $request, MessageThread $thread)
    {
        if ($thread->channel !== 'whatsapp') {
            return $this->sendError([
                'message' => __('Templates can only be sent to WhatsApp conversations.', 'fluentcampaign-pro')
            ], 422);
        }

        if (trim((string) $thread->phone_number) === '') {
            return $this->sendError([
                'message' => __('This conversation has no phone number.', 'fluentcampaign-pro')
            ], 422);
        }

        if (!$this->resolveChannel($thread->channel)) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $provider = WhatsAppHelper::getCurrentProvider();
        $templateName = sanitize_text_field($request->get('template_name', ''));
        $language = sanitize_text_field($request->get('template_language', ''));

        if ($language === '') {
            $language = sanitize_text_field($request->get('language', ''));
        }

        $templateQuery = MessageTemplate::forChannel('whatsapp')->approved()
            ->where('provider', $provider)
            ->where('name', $templateName);

        if ($language !== '') {
            $templateQuery->where('language', $language);
        }

        $template = $templateQuery->first();

        if (!$template) {
            return $this->sendError([
                'message' => __('Pick an approved template.', 'fluentcampaign-pro')
            ], 422);
        }

        $driver = WhatsAppDriverManager::getDriver($provider);

        if (!$driver instanceof TemplateApiInterface) {
            return $this->sendError([
                'message' => __('This provider does not support templates.', 'fluentcampaign-pro')
            ], 409);
        }

        $settings = WhatsAppHelper::getProviderSettings($provider);
        $result = $driver->sendTemplate(
            $thread->phone_number,
            $template->name,
            $template->language,
            [],
            $settings,
            (string) $template->provider_template_id
        );

        $succeeded = ($result['status'] ?? '') === 'success';
        $meta = [
            'template_id'   => (int) $template->id,
            'template_name' => $template->name,
        ];

        if (!$succeeded) {
            $meta['error_message'] = $result['message'] ?? '';
        }

        $message = $thread->recordMessage([
            'direction'           => Message::DIRECTION_OUTBOUND,
            'content'             => (string) $template->body_text,
            'ref_type'            => Message::REF_INBOX,
            'provider_message_id' => !empty($result['provider_message_id']) ? $result['provider_message_id'] : null,
            'status'              => $succeeded ? Message::STATUS_SENT : Message::STATUS_FAILED,
            'sent_at'             => $succeeded ? current_time('mysql') : null,
            'created_by'          => get_current_user_id(),
            'meta'                => $meta
        ]);

        if (!$succeeded) {
            return $this->sendError([
                'message'      => !empty($result['message']) ? $result['message'] : __('The message could not be sent.', 'fluentcampaign-pro'),
                'sent_message' => $this->formatMessage($message)
            ], 422);
        }

        return [
            'sent_message' => $this->formatMessage($message),
            'message'      => __('Message sent.', 'fluentcampaign-pro')
        ];
    }

    /**
     * The Pro channel for a slug, or null when Pro is absent or the channel is
     * switched off.
     */
    protected function resolveChannel($slug)
    {
        if (!class_exists('\FluentCampaign\App\Modules\Messaging\MessageModule')) {
            return null;
        }

        $channel = \FluentCampaign\App\Modules\Messaging\MessageModule::channel($slug);

        return ($channel && $channel->isActive()) ? $channel : null;
    }

    /**
     * Contacts and raw numbers a new conversation could be started with.
     *
     * Two kinds of answer. `contacts` are CRM records whose phone matches the
     * term. `direct` is the term itself when it is phone-shaped, so an operator
     * can message somebody who is not a contact -
     * fc_message_threads.contact_id is nullable for exactly that case.
     *
     * Both carry `existing_thread_id`, which is what lets the dialog offer to
     * open a conversation instead of starting a second one. The whole page is
     * resolved in one query rather than one lookup per row.
     *
     * @param Request $request
     * @return array|\WP_REST_Response
     */
    public function recipients(Request $request)
    {
        $channelSlug = sanitize_key($request->get('channel', ''));
        $channel = $this->resolveChannel($channelSlug);

        if (!$channel) {
            return $this->sendError([
                'message' => __('This channel is not available. Check that FluentCampaign Pro is active and the channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $search = trim(sanitize_text_field($request->get('search', '')));
        $searchDigits = preg_replace('/\D+/', '', $search);

        $direct = $this->directNumber($search);
        $phoneTerms = $this->phoneSearchTerms($search, $direct);

        global $wpdb;

        $phoneLikes = array_map(function ($term) use ($wpdb) {
            return '%' . $wpdb->esc_like($term) . '%';
        }, $phoneTerms);

        $query = Subscriber::whereNotNull('phone')
            ->where('phone', '!=', '');

        if ($search !== '') {
            // Phone-only search starts at three digits; shorter fragments match
            // too much to be useful in an interactive picker.
            if (strlen($searchDigits) < self::RECIPIENT_PHONE_SEARCH_MIN_LENGTH) {
                return ['contacts' => [], 'direct' => null];
            }

            $query->where(function ($subQuery) use ($phoneLikes) {
                foreach (array_values($phoneLikes) as $index => $phoneLike) {
                    if ($index === 0) {
                        $subQuery->where('phone', 'LIKE', $phoneLike);
                    } else {
                        $subQuery->orWhere('phone', 'LIKE', $phoneLike);
                    }
                }
            });
        }

        $subscribers = $query
            ->orderBy('id', 'DESC')
            ->limit(self::recipientLimit($request))
            ->get();

        $blocked = MessageThread::blockedContactIds($channelSlug, array_map(function ($subscriber) {
            return $subscriber->id;
        }, $subscribers->all()));

        $numbers = [];
        foreach ($subscribers as $subscriber) {
            $numbers[] = $subscriber->phone;
        }

        if ($direct) {
            $numbers[] = $direct;
        }

        $numbers = array_merge($numbers, $phoneTerms);

        $threadMap = $this->threadIdsForNumbers($channelSlug, $numbers);
        $directThreadId = 0;

        if ($direct) {
            foreach ($this->phoneSearchTerms($search, $direct) as $term) {
                if (isset($threadMap[$term])) {
                    $directThreadId = (int) $threadMap[$term];
                    break;
                }
            }
        }

        $contacts = [];
        foreach ($subscribers as $subscriber) {
            $contacts[] = [
                'id'                 => (int) $subscriber->id,
                'full_name'          => $subscriber->full_name,
                'email'              => $subscriber->email,
                'phone'              => $subscriber->phone,
                'photo'              => $subscriber->photo,
                // The scheduler refuses a send to a contact's own number unless
                // they are subscribed on this channel, so the dialog disables
                // those rows rather than letting an operator compose a message
                // that is going to be refused after the fact.
                'can_send'           => !isset($blocked[(int) $subscriber->id]),
                'consent_status'     => isset($blocked[(int) $subscriber->id])
                    ? MessageThread::STATUS_UNSUBSCRIBED
                    : MessageThread::STATUS_SUBSCRIBED,
                'existing_thread_id' => isset($threadMap[$subscriber->phone]) ? $threadMap[$subscriber->phone] : 0
            ];
        }

        return [
            'contacts' => $contacts,
            'direct'   => $direct ? [
                'phone_number'       => $direct,
                'existing_thread_id' => $directThreadId
            ] : null
        ];
    }

    /**
     * The search term as a phone number, or null when it is not one.
     *
     * Deliberately does not add or infer a country code. Contacts in FluentCRM
     * can store local numbers, and the inbox should preserve the operator's
     * typed number for a direct, contactless conversation.
     *
     * @param string $value
     * @return string|null
     */
    protected function directNumber($value)
    {
        $value = trim((string) $value);

        if ($value === '') {
            return null;
        }

        // Anything holding a letter is a name or an email, not a number, and is
        // not offered as a direct send option.
        if (!preg_match('/^[\d\s()+.\-]+$/', $value)) {
            return null;
        }

        $number = preg_replace('/[\s().-]+/', '', $value);

        return preg_match('/^\+?\d{6,20}$/', $number) ? $number : null;
    }

    /**
     * Search terms that can represent the same phone number.
     *
     * @param string $search
     * @param string|null $phoneNumber
     * @return array
     */
    protected function phoneSearchTerms($search, $phoneNumber = null)
    {
        $terms = [trim((string) $search)];
        $digits = preg_replace('/\D+/', '', (string) $search);

        if ($digits) {
            $terms[] = $digits;
        }

        if ($phoneNumber) {
            $terms[] = $phoneNumber;
            $terms[] = preg_replace('/\D+/', '', $phoneNumber);
        }

        return array_values(array_unique(array_filter($terms)));
    }

    /**
     * Existing thread ids for a set of numbers on one channel, in one query.
     *
     * @param string $channel
     * @param array $numbers
     * @return array phone number => thread id
     */
    protected function threadIdsForNumbers($channel, array $numbers)
    {
        $numbers = array_values(array_unique(array_filter($numbers)));

        if (!$numbers) {
            return [];
        }

        $map = [];

        $threads = MessageThread::where('channel', $channel)
            ->whereIn('phone_number', $numbers)
            ->get();

        foreach ($threads as $thread) {
            $map[$thread->phone_number] = (int) $thread->id;
        }

        return $map;
    }

    /**
     * Open or reserve a conversation without composing a message.
     *
     * Only for a number with no thread on this channel yet. When one exists the
     * dialog offers to open it instead, and this refuses rather than silently
     * appending to a conversation the operator has not seen.
     * It deliberately does not compose or send anything; the drawer only opens
     * the thread and lets the normal thread UI own follow-up actions.
     *
     * @param Request $request
     * @return array|\WP_REST_Response
     */
    public function store(Request $request)
    {
        $channelSlug = sanitize_key($request->get('channel', ''));

        if (!$this->resolveChannel($channelSlug)) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $contactId = $request->getSafe('contact_id', 'intval', 0);
        $subscriber = null;

        if ($contactId) {
            $subscriber = Subscriber::find($contactId);

            if (!$subscriber) {
                return $this->sendError(['message' => __('Contact not found.', 'fluentcampaign-pro')], 404);
            }

            // The number comes from the contact record, never from the request.
            // Trusting the pair the client sent would let a crafted call
            // attribute a message to one contact while delivering it to a
            // number of the caller's choosing.
            $phone = trim((string) $subscriber->phone);

            if ($phone === '') {
                return $this->sendError([
                    'message' => __('This contact has no phone number.', 'fluentcampaign-pro')
                ], 422);
            }
        } else {
            $phone = $this->directNumber(sanitize_text_field($request->get('phone_number', '')));

            if (!$phone) {
                return $this->sendError([
                    'message' => __('Enter a valid phone number.', 'fluentcampaign-pro')
                ], 422);
            }
        }

        $thread = $this->createNewThreadForConversation($channelSlug, $phone, $subscriber);

        if (is_array($thread)) {
            return $this->duplicateThreadError((int) $thread['thread_id']);
        }

        if (!$thread) {
            return $this->sendError([
                'message' => __('The conversation could not be started.', 'fluentcampaign-pro')
            ], 422);
        }

        return [
            'thread_id'   => (int) $thread->id,
            'thread'      => $this->formatThread($thread, null, true),
            'send_status' => 'not_sent',
            'message'     => __('Conversation opened.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Record a consent decision from the inbox, on the conversation itself.
     *
     * Thread-scoped rather than contact-scoped because the inbox can be looking
     * at a number that is not in the CRM at all — the profile endpoint has no
     * subscriber to address in that case, and the consent still has to land
     * somewhere. MessageThread::setConsent() is the same writer both use, so an
     * opt-out made here is identical to one made from a profile or by an
     * inbound STOP.
     *
     * @param Request $request
     * @param int $id thread id
     */
    public function updateConsent(Request $request, $id)
    {
        $thread = MessageThread::find((int) $id);

        if (!$thread) {
            return $this->sendError([
                'message' => __('Conversation not found.', 'fluentcampaign-pro')
            ], 404);
        }

        $status = $request->getSafe('status', 'sanitize_text_field', '');

        if (!in_array($status, MessageThread::consentStatuses(), true)) {
            return $this->sendError([
                'message' => __('Value is not valid', 'fluentcampaign-pro')
            ], 422);
        }

        if (!MessageThread::setConsent($thread->channel, $thread->phone_number, $status, $thread->contact_id)) {
            return $this->sendError([
                'message' => __('Consent could not be recorded for this number.', 'fluentcampaign-pro')
            ], 400);
        }

        if ($thread->contact_id) {
            $subscriber = Subscriber::find($thread->contact_id);

            if ($subscriber) {
                do_action('fluent_crm/contact_' . $thread->channel . '_' . ($status === MessageThread::STATUS_SUBSCRIBED ? 'subscribed' : 'unsubscribed'), $subscriber, [
                    'source' => 'admin'
                ]);
            }
        }

        return [
            'message' => __('Status updated', 'fluentcampaign-pro'),
            'status'  => $status
        ];
    }

    /**
     * Attach an existing contact to a conversation.
     *
     * The caller creates the contact through core's POST /subscribers endpoint
     * first, so this method only links an existing id and never creates.
     *
     * @param Request $request
     * @param int $id thread id
     * @return array|\WP_REST_Response
     */
    public function linkContact(Request $request, $id)
    {
        $thread = MessageThread::find((int) $id);

        if (!$thread) {
            return $this->sendError([
                'message' => __('Conversation not found.', 'fluentcampaign-pro')
            ], 404);
        }

        $contactId = $request->getSafe('contact_id', 'intval', 0);

        if (!$contactId) {
            return $this->sendError([
                'message' => __('Please provide a valid contact.', 'fluentcampaign-pro')
            ], 422);
        }

        $contact = Subscriber::find($contactId);

        if (!$contact) {
            return $this->sendError([
                'message' => __('Contact could not be found.', 'fluentcampaign-pro')
            ], 404);
        }

        $contactPhone = $this->directNumber($contact->phone);
        $threadPhone = $this->directNumber($thread->phone_number);

        if (!$contactPhone || !$threadPhone || $contactPhone !== $threadPhone) {
            return $this->sendError([
                'message' => __('This contact does not match the conversation phone number.', 'fluentcampaign-pro')
            ], 422);
        }

        $staleContactIds = [];

        if ($thread->contact_id) {
            $linkedContact = Subscriber::find((int) $thread->contact_id);

            if (!$linkedContact) {
                // A deleted contact leaves a dangling id; recover by claiming it.
                $staleContactIds[] = (int) $thread->contact_id;
            } elseif ((int) $linkedContact->id !== (int) $contact->id) {
                return $this->sendError([
                    'message' => __('This conversation is already linked to another contact.', 'fluentcampaign-pro')
                ], 409);
            }
        }

        if (!$thread->contact_id || $staleContactIds) {
            $linked = $thread->claimOrphanContact((int) $contact->id, $staleContactIds);

            if (!$linked) {
                $fresh = MessageThread::find((int) $id);

                if (!$fresh || (int) $fresh->contact_id !== (int) $contact->id) {
                    return $this->sendError([
                        'message' => __('This conversation is already linked to another contact.', 'fluentcampaign-pro')
                    ], 409);
                }
            }

            if ($linked) {
                /**
                 * A conversation has been attached to a CRM contact.
                 *
                 * @param MessageThread $thread
                 * @param Subscriber $contact
                 */
                do_action('fluent_crm/messaging_thread_contact_linked', $thread, $contact);
            }
        }

        $thread = MessageThread::with(['subscriber'])->find((int) $id);

        return [
            'thread'  => $this->formatThread($thread, null, true),
            'message' => __('Conversation linked to contact.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Reserve a brand-new thread, or report the existing
     * thread id when the number already has a conversation on this channel.
     *
     * This deliberately does not use MessageThread::findOrCreateFor(). That
     * helper recovers a unique-key race by returning the row another request
     * created, which is correct for webhooks and campaign queue generation. A
     * "new conversation" open is different: if another request created the row
     * first, this one must stop with a 409 so the operator opens the existing
     * conversation instead of creating a duplicate.
     *
     * @param string $channelSlug
     * @param string $phone
     * @param Subscriber|null $subscriber
     * @return MessageThread|array|null MessageThread on success, ['thread_id' => int] on duplicate
     */
    protected function createNewThreadForConversation($channelSlug, $phone, $subscriber)
    {
        $existing = MessageThread::where('channel', $channelSlug)
            ->where('phone_number', $phone)
            ->first();

        if ($existing) {
            return ['thread_id' => (int) $existing->id];
        }

        try {
            return MessageThread::create([
                'contact_id'   => $subscriber ? (int) $subscriber->id : null,
                'channel'      => $channelSlug,
                'phone_number' => $phone,
                'status'       => 'subscribed',
                'initiated_by' => 'admin',
                'has_unread'   => 0,
                'unread_count' => 0,
                'created_at'   => gmdate('Y-m-d H:i:s'),
                'updated_at'   => gmdate('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            $winner = MessageThread::where('channel', $channelSlug)
                ->where('phone_number', $phone)
                ->first();

            if ($winner) {
                return ['thread_id' => (int) $winner->id];
            }

            throw $e;
        }
    }

    /**
     * Standard duplicate-conversation refusal payload.
     *
     * @param int $threadId
     * @return \WP_REST_Response
     */
    protected function duplicateThreadError($threadId)
    {
        return $this->sendError([
            'message'   => __('This number already has a conversation on this channel. Open it from the list instead.', 'fluentcampaign-pro'),
            'thread_id' => (int) $threadId
        ], 409);
    }

    /**
     * Mark a thread read up to its newest message.
     *
     * Writes the cursor rather than a per-message flag, so this is one update
     * however long the conversation is.
     *
     * @param Request $request
     * @param int $id
     * @return array
     */
    public function markSeen(Request $request, $id)
    {
        $thread = MessageThread::findOrFail($id);

        $newestId = (int) Message::where('thread_id', $thread->id)->max('id');

        $thread->last_seen_id = $newestId;
        $thread->has_unread = 0;
        $thread->unread_count = 0;

        // Reading a conversation is not activity in it. The model stamps
        // `updated_at` on every save unless the attribute is already dirty, and
        // the rail sorts on `updated_at` — so without this, opening a year-old
        // thread jumps it to the top of the inbox as though the contact had just
        // written in, and the rail order becomes a history of what the admin
        // clicked rather than of what was said.
        MessageThread::withoutTimestamps(function () use ($thread) {
            $thread->save();
        });

        return [
            'thread_id'    => (int) $thread->id,
            'last_seen_id' => $newestId,
            'message'      => __('Conversation marked as read.', 'fluent-crm')
        ];
    }

    /**
     * Page size the caller asked for, bounded.
     *
     * The value is client-controlled, and each row costs a preview lookup and a
     * serialized subscriber. Unbounded, one request can ask the endpoint to
     * hydrate the whole table.
     *
     * @param Request $request
     * @return int
     */
    protected static function perPage(Request $request)
    {
        $perPage = $request->getSafe('per_page', 'intval', self::PER_PAGE);

        return max(1, min($perPage, self::MAX_PER_PAGE));
    }

    /**
     * Recipient picker page size, bounded to the short list the drawer shows.
     *
     * @param Request $request
     * @return int
     */
    protected static function recipientLimit(Request $request)
    {
        $perPage = $request->getSafe('per_page', 'intval', 15);

        return max(1, min($perPage, self::RECIPIENT_LIMIT));
    }

    /**
     * The 24-hour WhatsApp window for a page of threads, in one query.
     *
     * sessionState() answers for a single thread, which is a query per row —
     * 25 extra queries on every rail load, and the rail now reloads on a timer.
     * The window only depends on each thread's newest inbound message, so a
     * grouped lookup answers the whole page at once.
     *
     * Only `thread_id` is selected outside the aggregate and it is the grouping
     * key, so this holds under ONLY_FULL_GROUP_BY. Inbound messages never carry
     * `sent_at` or `scheduled_at`, so MAX(created_at) is the same value the
     * per-row COALESCE ordering picks.
     *
     * @param array $threads MessageThread rows
     * @return array thread id => last inbound timestamp
     */
    protected function lastInboundMap($threads)
    {
        $ids = [];
        foreach ($threads as $thread) {
            if ($thread->channel === 'whatsapp') {
                $ids[] = (int) $thread->id;
            }
        }

        if (!$ids) {
            return [];
        }

        $rows = Message::whereIn('thread_id', $ids)
            ->inbound()
            ->select('thread_id')
            ->selectRaw('MAX(created_at) AS last_inbound_at')
            ->groupBy('thread_id')
            ->get();

        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row->thread_id] = $row->last_inbound_at;
        }

        return $map;
    }

    /**
     * Rail/thread payload.
     *
     * @param MessageThread $thread
     * @param Message|null $preview last message, when the caller has one
     * @param bool $withContactDetail include lists and tags for the context panel
     * @return array
     */
    protected function formatThread($thread, $preview = null, $withContactDetail = false, array $resolved = [])
    {
        $subscriber = $thread->subscriber;
        $meta = $thread->meta;

        $payload = [
            'id'           => (int) $thread->id,
            'channel'      => $thread->channel,
            'phone_number' => $thread->phone_number,
            'profile_name' => isset($meta['profile_name']) ? $meta['profile_name'] : '',
            'wa_id'        => isset($meta['wa_id']) ? $meta['wa_id'] : '',
            'status'       => $thread->status,
            'unread_count' => isset($thread->unread_count) ? (int) $thread->unread_count : 0,
            'updated_at'   => $this->asDateString($thread->updated_at),
            'session'      => $this->sessionState($thread, $resolved),
            'subscriber'   => null,
            'last_message' => null
        ];

        if ($subscriber) {
            $payload['subscriber'] = [
                'id'         => (int) $subscriber->id,
                'full_name'  => $subscriber->full_name,
                'email'      => $subscriber->email,
                'phone'      => $subscriber->phone,
                'photo'      => $subscriber->photo,
                'status'     => $subscriber->status
            ];

            if ($withContactDetail) {
                $payload['subscriber']['lists'] = $subscriber->lists->pluck('title')->all();
                $payload['subscriber']['tags'] = $subscriber->tags->pluck('title')->all();
            }
        }

        if ($preview) {
            $payload['last_message'] = [
                'text'         => $this->previewText($preview),
                'direction'    => $preview->direction,
                'status'       => $preview->status,
                'message_type' => $this->messageType($preview),
                'created_at'   => $this->asDateString($preview->created_at)
            ];
        }

        return $payload;
    }

    /**
     * @param Message $message
     * @return array
     */
    protected function formatMessage($message)
    {
        $meta = $message->meta;

        return [
            'id'            => (int) $message->id,
            'thread_id'     => (int) $message->thread_id,
            'direction'     => $message->direction,
            'message_type'  => $this->messageType($message),
            'content'       => $message->content,
            'template_name' => isset($meta['template_name']) ? $meta['template_name'] : '',
            'media'         => isset($meta['attachments']) && is_array($meta['attachments']) ? $meta['attachments'] : [],
            'status'        => $message->status,
            // The provider's own words for a refusal. "Not delivered" alone
            // says something went wrong without saying what, and the reason is
            // usually the actionable part — an unverified number, a closed
            // session window, a spent quota.
            'error_message' => isset($meta['error_message']) ? $meta['error_message'] : '',
            'created_at'    => $this->asDateString($message->sent_at ?: ($message->scheduled_at ?: $message->created_at))
        ];
    }

    /**
     * Timestamps as plain `Y-m-d H:i:s` strings.
     *
     * The Message model lists its timestamps in $dates, so the ORM hands back
     * DateTime objects. Serialized to JSON those become
     * {date, timezone_type, timezone} — an object the browser's date parsing
     * cannot read, which shows up as messages with no time on them rather than
     * as an error. Every date leaving this controller goes through here.
     */
    protected function asDateString($value)
    {
        if (!$value) {
            return null;
        }

        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d H:i:s');
        }

        return (string) $value;
    }

    /**
     * Message shape, derived rather than stored — the agreed schema has no
     * `message_type` column. Attachments make it media; a template reference
     * makes it a template; everything else is text.
     */
    protected function messageType($message)
    {
        $meta = $message->meta;

        if (!empty($meta['attachments'])) {
            return 'media';
        }

        if (!empty($meta['template_id']) || !empty($meta['template_name'])) {
            return 'template';
        }

        return 'text';
    }

    /**
     * One-line preview for the rail.
     */
    protected function previewText($message)
    {
        $meta = $message->meta;

        if (empty($message->content) && !empty($meta['attachments'][0])) {
            $first = $meta['attachments'][0];

            return isset($first['caption']) && $first['caption']
                ? $first['caption']
                : (isset($first['filename']) ? $first['filename'] : '');
        }

        return (string) $message->content;
    }

    /**
     * WhatsApp's 24-hour service window, derived from the thread's most recent
     * inbound message.
     *
     * Derived rather than stored, for the reason the pro SessionWindow class
     * gives: the messages are the source of truth, so a derived answer cannot
     * drift out of sync and needs no expiry cron. SMS has no equivalent window
     * and is always open.
     */
    protected function sessionState($thread, array $resolved = [])
    {
        if ($thread->channel !== 'whatsapp') {
            return ['has_active_session' => true, 'expires_at' => null];
        }

        // The rail resolves a whole page in one grouped query and passes the
        // answer in; a caller with a single thread still queries for itself.
        // array_key_exists, not isset — a thread with no inbound message
        // resolves to null, which is an answer rather than a miss.
        if (array_key_exists('last_inbound_at', $resolved)) {
            $lastInbound = $resolved['last_inbound_at'];
        } else {
            $lastInbound = Message::where('thread_id', $thread->id)
                ->inbound()
                ->conversationOrder('DESC')
                ->value('created_at');
        }

        if (!$lastInbound) {
            return ['has_active_session' => false, 'expires_at' => null];
        }

        // created_at is stored in the WP timezone, so the comparison uses the
        // WP-local clock — time() would stretch the window by the UTC offset.
        $expires = strtotime($lastInbound) + DAY_IN_SECONDS;
        $open = $expires > current_time('timestamp');

        return [
            'has_active_session' => $open,
            'expires_at'         => $open ? gmdate('Y-m-d H:i:s', $expires) : gmdate('Y-m-d H:i:s', $expires)
        ];
    }
}
