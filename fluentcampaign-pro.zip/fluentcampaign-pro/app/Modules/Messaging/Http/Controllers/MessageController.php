<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceImporter;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCrm\App\Models\Label;
use FluentCrm\App\Models\Meta;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Models\TermRelation;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Support\Arr;

class MessageController extends Controller
{
    public function campaigns(Request $request)
    {
        $search = sanitize_text_field($request->get('searchBy'));
        $status = $request->get('statuses');
        $order = $request->get('sort_type') ?: 'DESC';
        // fc_sms_campaigns columns. Required because the framework rewrite made
        // orderBy() throw on names that don't match ^[a-zA-Z0-9_\.]+$.
        $allowedOrderBy = [
            'id', 'parent_id', 'type', 'title', 'slug', 'status', 'message_content',
            'sender_number', 'recipients_count', 'sent_count', 'failed_count', 'delay',
            'scheduled_at', 'settings', 'channel', 'created_by', 'created_at', 'updated_at',
        ];
        $orderBy = sanitize_key((string) ($request->get('sort_by') ?: 'id'));
        if (!in_array($orderBy, $allowedOrderBy, true)) {
            $orderBy = 'id';
        }
        $with = $request->get('with', []);
        $labels = $request->get('labels', []);
        $channel = sanitize_key($request->get('channel', ''));

        $campaignQuery = MessageCampaign::when($status, function ($query) use ($status) {
                    return $query->whereIn('status', $status);
                })->where('type', 'campaign')
                  ->when($search, function ($query) use ($search) {
                      return $query->where('title', 'LIKE', "%$search%");
                  })
                  ->when($channel, function ($query) use ($channel) {
                      return $query->where('channel', $channel);
                  })
                  ->orderBy($orderBy, ($order == 'ASC') ? 'ASC' : 'DESC');

        if (!empty($labels)) {
            $campaignQuery->whereHas('labelsTerm', function ($query) use ($labels) {
                $query->whereIn('term_id', $labels);
            });
        }

        $campaigns = $campaignQuery->paginate();

        if (in_array('stats', $with)) {
            // One meta query and one label pass for the whole page — a per-row
            // fluentcrm_get_sms_campaign_meta() + getFormattedLabels() loop is
            // 3 queries per campaign.
            $campaignIds = [];
            foreach ($campaigns as $campaign) {
                $campaignIds[] = $campaign->id;
            }

            $nextSteps = Meta::where('object_type', MessageCampaign::OBJECT_TYPE)
                ->where('key', '_next_config_step')
                ->whereIn('object_id', $campaignIds)
                ->get()
                ->keyBy('object_id');

            $termRelations = TermRelation::where('object_type', MessageCampaign::OBJECT_TYPE)
                ->whereIn('object_id', $campaignIds)
                ->get()
                ->groupBy('object_id');

            $termIds = $termRelations->flatten()->pluck('term_id')->unique()->values()->all();
            $labelsById = [];
            if ($termIds) {
                foreach (Label::whereIn('id', $termIds)->get() as $label) {
                    $labelsById[$label->id] = $label;
                }
            }

            foreach ($campaigns as $campaign) {
                $meta = $nextSteps->get($campaign->id);
                $campaign->next_step = $meta ? $meta->value : false;

                $campaignLabels = [];
                foreach ($termRelations->get($campaign->id, []) as $relation) {
                    if ($label = $labelsById[$relation->term_id] ?? null) {
                        $campaignLabels[] = [
                            'id'    => $label->id,
                            'slug'  => $label->slug,
                            'title' => $label->title,
                            'color' => $label->settings['color'] ?? ''
                        ];
                    }
                }
                $campaign->labels = $campaignLabels;
            }
        }

        return [
            'campaigns' => $campaigns
        ];
    }
    public function campaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        /**
         * Determine the sms campaign data in FluentCRM.
         *
         * This filter allows modification of the sms campaign data before it is used.
         *
         * @since 2.6.51
         *
         * @param array $campaign The sms campaign data.
         */

        $campaign->server_time = current_time('mysql');

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            $campaign = apply_filters('fluent_crm/whatsapp_campaign_data', $campaign);
        } else {
            $campaign = apply_filters('fluent_crm/sms_campaign_data', $campaign);
        }

        return $this->sendSuccess([
            'campaign' => $campaign
        ]);
    }
    public function create(Request $request)
    {
        $data = $this->validate($request->all(), [
            'title' => 'required',
            'message_content' => 'required'
        ]);

        $data['title'] = sanitize_text_field($data['title']);
        //Allow only links, no other HTML
        $data['message_content'] = wp_kses($data['message_content'], [
            'a' => [
                'href' => [],
                'title' => [],
                'target' => []
            ]
        ]);

        // Only user-editable columns; counters/status come from the model
        // defaults, and channel is validated rather than mass-assigned.
        $data = Arr::only($data, ['title', 'message_content', 'sender_number', 'delay', 'scheduled_at', 'settings']);
        $data['type'] = 'campaign';
        $data['channel'] = $this->resolveChannel($request);

        $campaign = MessageCampaign::create($data);

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_created', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_created', $campaign);
        }

        return $this->sendSuccess([
            'campaign' => $campaign,
            'message' => __('SMS Campaign created successfully', 'fluentcampaign-pro')
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $this->validate($request->all(), [
            "title" => "required",
            "message_content" => "required"
        ]);

        $data['title'] = sanitize_text_field($data['title']);
        //Allow only links, no other HTML
        $data['message_content'] = wp_kses($data['message_content'], [
            'a' => [
                'href' => [],
                'title' => [],
                'target' => []
            ]
        ]);

        $updateData = Arr::only($data, [
            'title',
            'message_content'
        ]);

        if (!empty($data['settings'])) {
            $updateData['settings'] = $data['settings'];
        }

        $campaign = MessageCampaign::findOrFail($id);

        $campaign->fill($updateData)->save();

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_updated', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_updated', $campaign);
        }

        $nextStep = Arr::get($data, 'next_step');

        if ($nextStep) {
            fluentcrm_update_sms_campaign_meta($id, '_next_config_step', $nextStep);
        }

        return $this->sendSuccess([
            'campaign' => $campaign,
            'message' => __('SMS Campaign Updated successfully', 'fluentcampaign-pro')
        ]);
    }

    /**
     * Get SMS logs for a specific subscriber
     *
     * @param Request $request
     * @param int $subscriberId
     */
    public function getLogs(Request $request, $subscriberId)
    {
        // Validate subscriber exists
        $subscriber = Subscriber::find($subscriberId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Subscriber not found', 'fluentcampaign-pro'), 
                'code' => 404
            ]);
        }

        $perPage = $request->get('per_page', 20);
        $page = $request->get('page', 1);
        $filter = $request->get('filter', 'all');
        $order = $request->get('order', 'asc');
        $channel = $this->resolveChannel($request);

        // Threads are the store now. A contact who has never been messaged on
        // this channel has no thread, and that is an empty history rather than
        // an error.
        $thread = MessageThread::forContact($subscriberId, $channel);

        $query = Message::where('thread_id', $thread ? $thread->id : 0);

        // Apply filter
        if ($filter !== 'all') {
            $query = $this->applyLogFilter($query, $filter);
        }

        // Order on the same expression the thread view sorts by, so a message
        // scheduled for later cannot appear ahead of one already sent. The id
        // keeps the order total — without a tie-break two rows sharing a second
        // swap places between requests and the list reshuffles as it is read.
        $direction = $order === 'desc' ? 'DESC' : 'ASC';
        $query->orderByRaw('COALESCE(sent_at, scheduled_at, created_at) ' . $direction)
            ->orderBy('id', $direction);

        // Get paginated results
        $logs = $query->paginate($perPage, ['*'], 'page', $page);

        // Mapped to the field names the profile tab already renders, so moving
        // the store does not require touching the component.
        $formattedLogs = [];
        foreach ($logs->items() as $log) {
            $when = $log->rawDate('sent_at') ?: ($log->rawDate('scheduled_at') ?: $log->rawDate('created_at'));

            $row = $log->toArray();

            // The model lists these in $dates, so toArray() renders them as
            // {date, timezone_type, timezone} objects the browser cannot parse.
            // Put the stored strings back — the component reads them as
            // fallbacks when _date_time is absent.
            $row['sent_at']    = $log->rawDate('sent_at');
            $row['scheduled_at'] = $log->rawDate('scheduled_at');
            $row['created_at'] = $log->rawDate('created_at');
            $row['updated_at'] = $log->rawDate('updated_at');

            $row['message']    = $log->content;
            $row['from']       = $thread ? $thread->phone_number : '';
            $row['date']       = $when ? date('m/d/Y', strtotime($when)) : '';
            $row['time']       = $when ? date('H:i', strtotime($when)) : '';
            $row['_date_time'] = $when;
            $row['type']       = $this->logType($log);

            $formattedLogs[] = $row;
        }

        return [
            'logs' => [
                'data' => $formattedLogs,
                'total' => $logs->total(),
                'per_page' => $logs->perPage(),
                'current_page' => $logs->currentPage(),
                'last_page' => $logs->lastPage()
            ]
        ];
    }

    /**
     * Send SMS to a subscriber
     *
     * @param Request $request
     * @param int $subscriberId
     */
    public function sendCustomSMS(Request $request, $contactId)
    {
        // Check if SMS module is enabled
        if (!SMSHelper::isActive()) {
            return $this->sendError([
                'message' => __('SMS module is not enabled', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // Validate subscriber exists
        $subscriber = Subscriber::find($contactId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Subscriber not found', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        // Validate required fields
        $message = $request->get('message');
        if (!$message) {
            return $this->sendError([
                'message' => __('Message is required', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // Get subscriber phone number
        $phoneNumber = $subscriber->phone;
        if (!$phoneNumber) {
            return $this->sendError([
                'message' => __('Subscriber does not have a phone number', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        if (!MessageThread::contactCanReceive('sms', $subscriber->id)) {
            return $this->sendError([
                'message' => __('This contact is not subscribed for SMS.', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // Validate message length (SMS limit is typically 160 characters for single SMS)
        if (strlen($message) > 1600) { // Allow up to 10 SMS segments
            return $this->sendError([
                'message' => __('Message is too long. Maximum 1600 characters allowed.', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // Get additional parameters
        $fromNumber = $request->get('from_number');
        $type = 'custom_sms'; // campaign, automation, custom_sms - this is custom sms

        // create sms campaign and it will do the rest of the work

        try { 

            $smsCampaign = MessageCampaign::create([
                'title' => 'Custom SMS to ' . $subscriber->full_name,
                'subscriber_id' => $contactId,
                'mobile_number' => $phoneNumber,
                'message_content' => $message,
                'type' => $type,
                'status' => LegacyMessage::STATUS_PENDING,
                'scheduled_at' => current_time('mysql'),
            ]);

            // Written directly rather than through subscribe(): this is one
            // message to one contact, and going via the audience path only to
            // read the single row back was a query for no reason. The campaign
            // row is still created above and still referenced, so the send keeps
            // its place in campaign reporting.
            $smsMessage = MessageScheduler::sendNow(
                LegacyMessage::CHANNEL_SMS,
                $phoneNumber,
                $contactId,
                $message,
                [
                    'ref_type' => $smsCampaign->messageRefType(),
                    'ref_id'   => $smsCampaign->id
                ]
            );

            if (!$smsMessage) {
                return $this->sendError([
                    'message' => __('Failed to prepare SMS for sending', 'fluentcampaign-pro')
                ]);
            }

            $smsCampaign->recipients_count = 1;
            $smsCampaign->save();

            return $this->sendMessageOutcome(
                $smsMessage,
                __('SMS has been sent.', 'fluentcampaign-pro')
            );
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Something went wrong while sending SMS', 'fluentcampaign-pro')
            ]);
        }

        

    }

    /**
     * Get SMS statistics for a subscriber
     *
     * @param Request $request
     * @param int $subscriberId
     */
    /**
     * A contact's consent on one channel, and whether we may message them.
     *
     * The profile tabs ask for this rather than reading it off the contact
     * record: consent lives on the conversation threads, so the contact object
     * no longer carries it.
     */
    public function getConsent(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);

        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Subscriber not found', 'fluentcampaign-pro')
            ], 404);
        }

        $channel = $this->resolveChannel($request);

        return [
            'consent' => [
                'status'   => MessageThread::contactStatus($channel, $subscriber->id),
                'can_send' => !empty($subscriber->phone)
                    && MessageThread::contactCanReceive($channel, $subscriber->id)
            ]
        ];
    }

    /**
     * Record an operator's consent decision for a contact on one channel.
     *
     * Writes through MessageThread::setConsent() so a decision made here is the
     * same one an inbound STOP would make — including applying to every thread
     * the contact owns on the channel.
     */
    public function updateConsent(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);

        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Subscriber not found', 'fluentcampaign-pro')
            ], 404);
        }

        if (empty($subscriber->phone)) {
            return $this->sendError([
                'message' => __('This contact has no phone number, so there is no conversation to record consent on.', 'fluentcampaign-pro')
            ], 400);
        }

        $status = $request->getSafe('status', 'sanitize_text_field', '');

        if (!in_array($status, MessageThread::consentStatuses(), true)) {
            return $this->sendError([
                'message' => __('Value is not valid', 'fluentcampaign-pro')
            ], 422);
        }

        $channel = $this->resolveChannel($request);

        if (!MessageThread::setConsent($channel, $subscriber->phone, $status, $subscriber->id)) {
            return $this->sendError([
                'message' => __('Consent could not be recorded for this number.', 'fluentcampaign-pro')
            ], 400);
        }

        do_action('fluent_crm/contact_' . $channel . '_' . ($status === MessageThread::STATUS_SUBSCRIBED ? 'subscribed' : 'unsubscribed'), $subscriber, [
            'source' => 'admin'
        ]);

        return [
            'message' => __('Status updated', 'fluentcampaign-pro'),
            'consent' => [
                'status'   => $status,
                'can_send' => $status === MessageThread::STATUS_SUBSCRIBED
            ]
        ];
    }

    public function getStats(Request $request, $subscriberId)
    {
        // Validate subscriber exists
        $subscriber = Subscriber::find($subscriberId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Subscriber not found', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        // Scope stats to the requested channel so the SMS tab counts only SMS
        // messages, not WhatsApp.
        $channel = $this->resolveChannel($request);

        $thread = MessageThread::forContact($subscriberId, $channel);

        // A thread id of 0 matches nothing, so a contact who has never been
        // messaged gets zeros rather than the whole table.
        $base = Message::where('thread_id', $thread ? $thread->id : 0);

        return [
            'stats' => [
                'total_messages' => (clone $base)->count(),
                'campaign_messages' => (clone $base)->where('ref_type', Message::REF_CAMPAIGN)->count(),
                'automation_messages' => (clone $base)->where('ref_type', Message::REF_AUTOMATION)->count(),
                // Everything outbound that is not a campaign or an automation:
                // one-off sends, resends and opt-in/opt-out confirmations.
                'custom_sms' => (clone $base)
                    ->where('direction', Message::DIRECTION_OUTBOUND)
                    ->where(function ($query) {
                        $query->whereNull('ref_type')
                            ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
                    })
                    ->count(),
                'sent_messages' => (clone $base)->where('status', Message::STATUS_SENT)->count(),
                'delivered_messages' => (clone $base)->where('status', Message::STATUS_DELIVERED)->count(),
                'failed_messages' => (clone $base)->where('status', Message::STATUS_FAILED)->count(),
                'pending_messages' => (clone $base)->whereIn('status', Message::UNFINISHED)->count(),
                'last_sent' => (clone $base)
                    ->whereNotNull('sent_at')
                    ->orderBy('sent_at', 'desc')
                    ->value('sent_at')
            ]
        ];
    }

    /**
     * The profile tab's filter chips, expressed against fc_messages.
     *
     * The chips are still labelled with the legacy sms_type vocabulary, so the
     * mapping lives here rather than leaking `ref_type` into the component.
     */
    protected function applyLogFilter($query, $filter)
    {
        if ($filter === LegacyMessage::TYPE_CAMPAIGN || $filter === LegacyMessage::TYPE_AUTOMATION) {
            return $query->where('ref_type', $filter);
        }

        if ($filter === 'incoming') {
            return $query->where('direction', Message::DIRECTION_INBOUND);
        }

        // custom_sms, and anything unrecognised, means "outbound with no
        // campaign behind it".
        return $query->where('direction', Message::DIRECTION_OUTBOUND)
            ->where(function ($query) {
                $query->whereNull('ref_type')
                    ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
            });
    }

    /**
     * The legacy `sms_type` a message would have had, for the profile tab's
     * filter chips and its group headings.
     */
    protected function logType($message)
    {
        if ($message->direction === Message::DIRECTION_INBOUND) {
            return 'incoming';
        }

        if (in_array($message->ref_type, [Message::REF_CAMPAIGN, Message::REF_AUTOMATION], true)) {
            return $message->ref_type;
        }

        return LegacyMessage::TYPE_CUSTOM_SMS;
    }

    /**
     * Resolve the message channel for contact-profile SMS endpoints.
     *
     * Defaults to the SMS channel so the existing "SMS" profile tab shows only
     * SMS history; accepts an optional ?channel= override (e.g. 'whatsapp') so the
     * same endpoints can back a future WhatsApp tab. Unknown values fall back to SMS.
     *
     * @param Request $request
     * @return string
     */
    private function resolveChannel(Request $request)
    {
        $channel = sanitize_key((string) $request->get('channel', ''));

        return in_array($channel, [LegacyMessage::CHANNEL_SMS, LegacyMessage::CHANNEL_WHATSAPP], true)
            ? $channel
            : LegacyMessage::CHANNEL_SMS;
    }


    public function getContactEstimation(Request $request)
    {
        $start_time = microtime(true);

        $filterType = $request->get('sending_filter', 'list_tag');

        $subscribersSettings = [
            'sending_filter' => $filterType
        ];

        if ($filterType == 'list_tag') {
            $subscribersSettings['subscribers'] = $request->get('subscribers', []);
            $subscribersSettings['excludedSubscribers'] = $request->get('excludedSubscribers', []);
        } else if ($filterType == 'dynamic_segment') {
            $subscribersSettings['dynamic_segment'] = $request->get('dynamic_segment', []);
        } else if ($filterType == 'advanced_filters') {
            $subscribersSettings['advanced_filters'] = Helper::parseArrayOrJson($request->get('advanced_filters'));
        } else {
            return [
                'count' => 0
            ];
        }

        // Estimate against the same channel the real send will use, so the
        // count honours the consent recorded on that channel's threads.
        $campaign = new MessageCampaign();
        $campaign->channel = $this->resolveChannel($request);

        $count = $campaign->getSubscriberIdsCountBySegmentSettings($subscribersSettings);

        return [
            'count'          => $count,
            'execution_time' => microtime(true) - $start_time
        ];
    }

    public function getRecipientsCount(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::withoutGlobalScope('type')->findOrFail($campaignId);
        $preProcessedStatuses = [
            'draft',
            'processing',
            'pending-scheduled'
        ];

        if (Arr::get($campaign->settings, 'sending_filter') === 'one_time') {
            return [
                'estimated_count' => (int) Arr::get($campaign->settings, 'one_time_audience.accepted_count', $campaign->recipients_count)
            ];
        }

        if (in_array($campaign->status, $preProcessedStatuses)) {
            $count = $campaign->getSubscribersModel()->count();
        } else {
            $count = $campaign->recipients_count;
        }

        return [
            'estimated_count' => $count
        ];
    }

    public function uploadOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be changed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->startUpload($campaign, $request->file('file'));
        } catch (\LengthException $e) {
            return $this->sendError(['message' => $e->getMessage()], 413);
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function pasteOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be changed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->startPaste($campaign, (string) $request->get('content', ''));
        } catch (\LengthException $e) {
            return $this->sendError(['message' => $e->getMessage()], 413);
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function processOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be processed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->process($campaign, $request->all());
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function activateOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be activated while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $audience = (new OneTimeAudienceImporter())->activate(
                $campaign,
                $request->getSafe('token', 'sanitize_text_field', ''),
                $request->get('confirm_consent') === true || $request->get('confirm_consent') === 'true'
            );
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'audience' => $audience,
            'campaign' => MessageCampaign::findOrFail($campaignId)
        ]);
    }

    public function getOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        return $this->sendSuccess([
            'audience' => (new OneTimeAudienceImporter())->audience($campaign)
        ]);
    }

    public function getOneTimeAudienceRecipients(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        $import = OneTimeAudienceMeta::getImportSession($campaign->id);
        $settings = OneTimeAudienceMeta::getAudienceSettings($campaign);
        $batchId = (string) (Arr::get($import, 'batch_id') ?: Arr::get($settings, 'active_batch_id', ''));

        if (!$batchId) {
            return $this->sendSuccess([
                'recipients' => [
                    'data'         => [],
                    'total'        => 0,
                    'per_page'     => 50,
                    'current_page' => 1,
                    'last_page'    => 1
                ]
            ]);
        }

        $page = max(1, (int) $request->get('page', 1));
        $perPage = min(100, max(10, (int) $request->get('per_page', 50)));
        $query = OneTimeAudienceMeta::messageBatchQuery($campaign->id, $batchId)
            ->orderBy('id', 'ASC');
        $total = (int) $query->count();
        $rows = $query->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get(['id', 'thread_id', 'meta']);

        $threadIds = [];
        foreach ($rows as $row) {
            $threadIds[] = (int) $row->thread_id;
        }

        $threads = $threadIds
            ? MessageThread::whereIn('id', array_values(array_unique($threadIds)))->get()->keyBy('id')
            : [];

        $items = [];
        foreach ($rows as $row) {
            $thread = $threads ? $threads->get((int) $row->thread_id) : null;
            $meta = is_array($row->meta) ? $row->meta : [];
            $recipient = Arr::get($meta, 'one_time_recipient', []);
            $recipient = is_array($recipient) ? $recipient : [];

            $items[] = [
                'id'           => (int) $row->id,
                'phone_number' => $thread ? (string) $thread->phone_number : (string) Arr::get($recipient, 'phone_number', ''),
                'full_name'    => (string) Arr::get($recipient, 'full_name', ''),
                'contact_id'   => $thread ? (int) $thread->contact_id : 0
            ];
        }

        return $this->sendSuccess([
            'recipients' => [
                'data'         => $items,
                'total'        => $total,
                'per_page'     => $perPage,
                'current_page' => $page,
                'last_page'    => max(1, (int) ceil($total / $perPage))
            ]
        ]);
    }

    public function clearOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be cleared while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        return $this->sendSuccess([
            'audience' => (new OneTimeAudienceImporter())->clear($campaign),
            'campaign' => MessageCampaign::findOrFail($campaignId)
        ]);
    }

    public function schedule(Request $request, $campaignId)
    {
        $scheduleAt = $request->get('scheduled_at');
        $smsCampaign = MessageCampaign::findOrFail($campaignId);

        if (Arr::get($smsCampaign->settings, 'sending_filter') === 'one_time') {
            if (!OneTimeAudienceMeta::hasConfirmedConsent($smsCampaign)) {
                return $this->sendError([
                    'message' => __('Please confirm consent for the one-time audience before scheduling.', 'fluentcampaign-pro')
                ], 422);
            }

            if (($smsCampaign->channel ?: LegacyMessage::CHANNEL_SMS) === LegacyMessage::CHANNEL_WHATSAPP && !(int) Arr::get($smsCampaign->settings, 'template_id')) {
                return $this->sendError([
                    'message' => __('One-time WhatsApp campaigns require an approved template.', 'fluentcampaign-pro')
                ], 422);
            }
        }

        if ($smsCampaign->status != 'draft') {
            return $this->sendError([
                'message' => __('Campaign status is not in draft status. Please reload the page', 'fluentcampaign-pro')
            ], 422);
        }

        if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_status_active', $smsCampaign);
        } else {
            do_action('fluent_crm/sms_campaign_status_active', $smsCampaign);
        }

        // A draft may still have actions from an earlier schedule. Clear them
        // before creating the one that represents this request.
        MessageScheduler::clearPendingCampaignActions($campaignId);

        if($scheduleAt) {
            $sendingType = $request->get('sending_type', 'schedule');

            // Range schedule was removed; it may return in a future release
            // after more testing. Only plain scheduling is supported — anything
            // else would fall through with no $data to apply.
            if ($sendingType != 'schedule') {
                return $this->sendError([
                    'message' => __('Unsupported sending type', 'fluentcampaign-pro')
                ], 422);
            }

            $scheduleAt = $this->normalizeScheduleDateTime($scheduleAt);
            if (!$scheduleAt) {
                return $this->sendError([
                    'message' => __('Invalid schedule date', 'fluentcampaign-pro')
                ], 422);
            }

            $settings = $smsCampaign->settings;
            $settings['sending_type'] = 'schedule';

            $data = [
                'status'           => 'pending-scheduled',
                'updated_at'       => fluentCrmTimestamp(),
                'scheduled_at'     => $scheduleAt,
                'recipients_count' => 0,
                'settings'         => maybe_serialize($settings)
            ];

            $message = __('Your sms campaign has been scheduled', 'fluentcampaign-pro');
            MessageCampaign::where('id', $campaignId)->update($data);

            // scheduled_at is stored in site-local time; Action Scheduler needs
            // an absolute UTC timestamp. Generate five minutes early, or now
            // when the requested time is already too close.
            $generateAt = max(time(), (int) get_gmt_from_date($scheduleAt, 'U') - 300);
            // clearPendingCampaignActions() above already removed anything left
            // from an earlier schedule, so this is the only action for the hook.
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId, $generateAt);

        } else {

            $message = __('Campaign is starting now', 'fluentcampaign-pro');

            $settings = $smsCampaign->settings;
            $settings['sending_type'] = 'instant';

            $data = [
                'status'           => 'pending-scheduled',
                'updated_at'       => fluentCrmTimestamp(),
                'scheduled_at'     => date('Y-m-d H:i:s', current_time('timestamp')), // send immediately
                'recipients_count' => 0,
                'settings'         => maybe_serialize($settings)
            ];

            MessageCampaign::where('id', $campaignId)->update($data);
        }

        fluentcrm_update_sms_campaign_meta($smsCampaign->id, '_sms_campaign_sent_by', get_current_user_id());

        $smsCampaign = MessageCampaign::findOrFail($campaignId);

        if ($scheduleAt) {
            if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
                do_action('fluent_crm/whatsapp_campaign_scheduled', $smsCampaign, $smsCampaign->scheduled_at);
            } else {
                do_action('fluent_crm/sms_campaign_scheduled', $smsCampaign, $smsCampaign->scheduled_at);
            }
        } else {
            // Trigger generation immediately — scheduled_at is now so messages are ready as soon as generated
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId);
        }

        return $this->sendSuccess([
            'campaign'          => $smsCampaign,
            'message'           => $message,
            'current_timestamp' => fluentCrmTimestamp()
        ]);
    }

    /**
     * Turn a finished send into an honest response.
     *
     * An inline send already knows whether it worked, so these endpoints no
     * longer answer "shortly" and leave the operator to discover a dead number
     * from the activity list some time later.
     *
     * @param \FluentCampaign\App\Modules\Messaging\Models\Message $message the row after the attempt
     * @param string $successMessage what to say when it went out
     * @param array $extra additional payload for either outcome
     */
    private function sendMessageOutcome($message, $successMessage, $extra = [])
    {
        if ($message->status === Message::STATUS_FAILED) {
            $meta = is_array($message->meta) ? $message->meta : [];

            return $this->sendError(array_merge($extra, [
                'message' => Arr::get($meta, 'error_message')
                    ?: __('The message could not be sent.', 'fluentcampaign-pro')
            ]), 422);
        }

        // Still claimable means another worker owns this message. The scheduler
        // left it on the queue, so this is a promise it can keep.
        if (in_array($message->status, Message::CLAIMABLE, true)) {
            return $this->sendSuccess(array_merge($extra, [
                'message' => __('Queued — it will be sent as soon as its queue worker runs.', 'fluentcampaign-pro')
            ]));
        }

        return $this->sendSuccess(array_merge($extra, [
            'message' => $successMessage
        ]));
    }

    /**
     * Normalize mixed datetime inputs into mysql datetime string.
     *
     * Accepts unix timestamps, mysql datetime strings, and ISO-8601 strings.
     *
     * @param mixed $value
     * @return string|null
     */
    private function normalizeScheduleDateTime($value)
    {
        if (is_numeric($value)) {
            $timestamp = (int)$value;
            return $timestamp ? wp_date('Y-m-d H:i:s', $timestamp, wp_timezone()) : null;
        }

        if (!is_string($value)) {
            return null;
        }

        $value = sanitize_text_field($value);
        if (!$value) {
            return null;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) {
            return $value;
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return null;
        }

        return wp_date('Y-m-d H:i:s', $timestamp, wp_timezone());
    }

    public function pauseCampaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        if ($campaign->status != 'working') {
            return $this->sendError([
                'message' => __('You can only pause a campaign if it is on "Working" state, Please reload this page', 'fluentcampaign-pro')
            ]);
        }

        $campaign->status = 'paused';
        $campaign->save();

        Message::forCampaign($campaign->id)
                     ->whereIn('status', [Message::STATUS_SCHEDULED, Message::STATUS_PENDING, Message::STATUS_SCHEDULING])
                     ->update([
                         'status' => 'paused'
                     ]);

        return [
            'message'  => __('Campaign has been successfully marked as paused', 'fluentcampaign-pro'),
            'campaign' => $campaign
        ];
    }

    public function resumeCampaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        if ($campaign->status != 'paused') {
            return $this->sendError([
                'message' => __('You can only resume a campaign if it is on "paused" state, Please reload this page', 'fluentcampaign-pro')
            ]);
        }

        $campaign->status = 'working';
        $campaign->save();

        Message::forCampaign($campaign->id)
                     ->where('status', 'paused')
                     ->update([
                         'status'       => Message::STATUS_SCHEDULED,
                         'scheduled_at' => current_time('mysql')
                     ]);

        // A paused campaign may still have an old pending cursor action. Clear
        // every cursor shape before starting one fresh send chain.
        MessageScheduler::clearPendingCampaignActions($campaign->id);

        MessageScheduler::scheduleCampaignAction('fluentcrm_send_message_batch', $campaign->id);

        return [
            'message'  => __('Campaign has been successfully resumed', 'fluentcampaign-pro'),
            'campaign' => $campaign
        ];
    }

    public function duplicateCampaign(Request $request, $id)
    {
        $oldCampaign = MessageCampaign::findOrFail($id);
        $settings = is_array($oldCampaign->settings) ? $oldCampaign->settings : [];
        $opensAtAudienceStep = Arr::get($settings, 'sending_filter') === 'one_time';

        if ($opensAtAudienceStep) {
            unset($settings['one_time_audience']);
            $settings['sending_filter'] = 'list_tag';
        }

        $newCampaign = [
            'title'            => __('[Duplicate] ', 'fluentcampaign-pro') . $oldCampaign->title,
            'message_content'  => $oldCampaign->message_content,
            'status'           => 'draft',
            'created_by'       => get_current_user_id(),
            'settings'         => $settings,
            'sender_number'    => $oldCampaign->sender_number,
            // Without this a WhatsApp duplicate falls back to the column default
            // 'sms' and would send over the wrong channel's consent.
            'channel'          => $oldCampaign->channel ?: LegacyMessage::CHANNEL_SMS
        ];
        $labelIds = $oldCampaign->getFormattedLabels()->pluck('id')->toArray();

        $campaign = MessageCampaign::create($newCampaign);
        $campaign->attachLabels($labelIds);

        if ($opensAtAudienceStep) {
            fluentcrm_update_sms_campaign_meta($campaign->id, '_next_config_step', 1);
            $campaign->next_step = 1;
        }

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_duplicated', $campaign, $oldCampaign);
        } else {
            do_action('fluent_crm/sms_campaign_duplicated', $campaign, $oldCampaign);
        }

        return [
            'campaign' => $campaign,
            'message'  => __('Campaign has been successfully duplicated', 'fluentcampaign-pro')
        ];

    }

    public function unSchedule(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        $validStatuses = [
            'scheduled',
            'pending-scheduled',
            'processing'
        ];

        if (!in_array($campaign->status, $validStatuses)) {
            return $this->sendError([
                'message' => __('You can only un-schedule a campaign if it is on "scheduled" state, Please reload this page', 'fluentcampaign-pro')
            ]);
        }

        if ($campaign->status == 'processing' && strtotime($campaign->scheduled_at) < current_time('timestamp')) {
            return $this->sendError([
                'message' => __('You can only un-schedule a campaign if it is on "scheduled" state, Please reload this page', 'fluentcampaign-pro')
            ]);
        }

        // Publish draft first so a running generator observes cancellation.
        // Clearing actions afterwards closes the opposite race where that
        // worker queues its continuation while this request is unscheduling.
        $campaign->status = 'draft';
        $campaign->save();
        MessageScheduler::clearPendingCampaignActions($campaign->id);

        // Delete only queued messages — sent/failed rows are audit history and
        // must survive un-scheduling a partially processed campaign.
        Message::forCampaign($campaign->id)
                     ->whereIn('status', [Message::STATUS_SCHEDULED, Message::STATUS_SCHEDULING, Message::STATUS_PENDING])
                     ->delete();

        return [
            'message' => __('SMS Campaign has been successfully un-scheduled', 'fluentcampaign-pro')
        ];
    }

    /**
     * Get all SMS messages with pagination and filtering
     *
     * @param  Request  $request
     *
     * @return array
     */
    public function getAllMessages(Request $request)
    {
        global $wpdb;

        $perPage = $request->get('per_page', 10);
        $page = $request->get('page', 1);
        $search = $request->getSafe('search', 'sanitize_text_field', '');
        $channel = sanitize_key($request->get('channel', ''));

        // The UI sends multi-selects comma-joined; unknown values are dropped
        // rather than silently matching nothing.
        $statusFilter = array_values(array_intersect(
            array_filter(array_map('sanitize_key', explode(',', (string) $request->get('status', '')))),
            [
                LegacyMessage::STATUS_PENDING,
                LegacyMessage::STATUS_SENT,
                LegacyMessage::STATUS_DELIVERED,
                LegacyMessage::STATUS_FAILED,
                LegacyMessage::STATUS_CANCELLED,
                LegacyMessage::STATUS_RECEIVED,
            ]
        ));

        $typeFilter = array_values(array_intersect(
            array_filter(array_map('sanitize_key', explode(',', (string) $request->get('sms_type', '')))),
            [
                LegacyMessage::TYPE_CAMPAIGN,
                LegacyMessage::TYPE_AUTOMATION,
                LegacyMessage::TYPE_CUSTOM_SMS,
                LegacyMessage::TYPE_BROADCAST,
                'incoming',
            ]
        ));

        $isRealChannel = in_array($channel, [LegacyMessage::CHANNEL_SMS, LegacyMessage::CHANNEL_WHATSAPP], true);

        // The channel lives on the thread now, so scoping the list to one
        // channel is a constraint on the conversation rather than on the row.
        $channelScope = function ($query) use ($channel) {
            $query->where('channel', $channel);
        };

        $query = Message::with(['thread', 'thread.subscriber'])
            // Same order as the thread view: a message scheduled for later must
            // not sit above one already sent. `activity_at` is the stored,
            // indexed form of that COALESCE — this is a global list across every
            // thread and channel, so ordering by the raw expression would force
            // a filesort over the whole table on every page request. The id
            // keeps the order total so a page boundary cannot drop or repeat a
            // row.
            ->orderBy('activity_at', 'DESC')
            ->orderBy('id', 'DESC');

        // Apply channel filter; only real channels are meaningful here.
        if ($isRealChannel) {
            $query->whereHas('thread', $channelScope);
        }

        if ($statusFilter) {
            $query->whereIn('status', $statusFilter);
        }

        if ($typeFilter) {
            $this->applyTypeFilter($query, $typeFilter);
        }

        if ($search) {
            // esc_like so a literal % or _ in the search box does not act as a
            // wildcard; the subscriber scope escapes its own input.
            $like = '%' . $wpdb->esc_like($search) . '%';
            $query->where(function ($q) use ($like, $search) {
                $q->where('content', 'LIKE', $like)
                    ->orWhereHas('thread', function ($threadQuery) use ($like, $search) {
                        $threadQuery->where('phone_number', 'LIKE', $like)
                            ->orWhereHas('subscriber', function ($subscriberQuery) use ($search) {
                                $subscriberQuery->searchBy($search);
                            });
                    });
            });
        }

        // Get paginated results
        $messages = $query->paginate($perPage, ['*'], 'page', $page);

        // Status counts for the filter dropdown — scoped to the same channel as
        // the list so a WhatsApp view doesn't show SMS counts.
        // Only `status` is selected and it is the grouping key, so this holds
        // under ONLY_FULL_GROUP_BY.
        $statusCountQuery = Message::selectRaw('status, COUNT(*) as count')
            ->whereNotNull('status');
        if ($isRealChannel) {
            $statusCountQuery->whereHas('thread', $channelScope);
        }
        $statusCounts = $statusCountQuery
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        $allowedStatuses = [
            LegacyMessage::STATUS_PENDING,
            LegacyMessage::STATUS_SENT,
            LegacyMessage::STATUS_DELIVERED,
            LegacyMessage::STATUS_FAILED,
            LegacyMessage::STATUS_CANCELLED,
            LegacyMessage::STATUS_RECEIVED
        ];

        $statuses = [];
        foreach ($allowedStatuses as $allowedStatus) {
            if (!isset($statusCounts[$allowedStatus])) {
                continue;
            }

            $statuses[] = [
                'value' => $allowedStatus,
                'label' => ucwords(str_replace('_', ' ', $allowedStatus)),
                'count' => (int)$statusCounts[$allowedStatus]
            ];
        }

        return [
            'sms' => [
                'data' => $this->formatActivityRows($messages->items()),
                'total' => $messages->total(),
                'per_page' => $messages->perPage(),
                'current_page' => $messages->currentPage(),
                'last_page' => $messages->lastPage(),
                'from' => $messages->firstItem(),
                'to' => $messages->lastItem(),
                'next_page_url' => $messages->nextPageUrl(),
                'prev_page_url' => $messages->previousPageUrl()
            ],
            'statuses' => $statuses
        ];
    }

    /**
     * Narrow the activity list to the type chips the UI offers.
     *
     * The chips still speak the legacy `sms_type` vocabulary; the mapping onto
     * direction and `ref_type` lives here so the component does not have to
     * learn the new columns.
     */
    protected function applyTypeFilter($query, array $typeFilter)
    {
        $refTypes = array_values(array_intersect(
            $typeFilter,
            [LegacyMessage::TYPE_CAMPAIGN, LegacyMessage::TYPE_AUTOMATION]
        ));

        $wantsIncoming = in_array('incoming', $typeFilter, true);

        // custom_sms and broadcast both mean "outbound with no campaign behind
        // it" — one-off sends from the contact panel, resends, and the
        // automated opt-in/opt-out confirmations.
        $wantsCustom = (bool) array_intersect(
            $typeFilter,
            [LegacyMessage::TYPE_CUSTOM_SMS, LegacyMessage::TYPE_BROADCAST]
        );

        return $query->where(function ($query) use ($refTypes, $wantsIncoming, $wantsCustom) {
            if ($refTypes) {
                $query->orWhereIn('ref_type', $refTypes);
            }

            if ($wantsIncoming) {
                $query->orWhere('direction', Message::DIRECTION_INBOUND);
            }

            if ($wantsCustom) {
                $query->orWhere(function ($query) {
                    $query->where('direction', Message::DIRECTION_OUTBOUND)
                        ->where(function ($query) {
                            $query->whereNull('ref_type')
                                ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
                        });
                });
            }
        });
    }

    /**
     * Shape one page of messages the way the activity table already reads them.
     *
     * The table renders `message_content`, `mobile_number`, `channel`,
     * `sms_type` and a `campaign` object. None of those are columns any more —
     * the first three come from the thread and the last two are derived — so
     * they are mapped here rather than changing the component.
     *
     * Campaign titles are resolved in one query for the whole page; a lookup
     * per row is what a `campaign` relation used to cost.
     *
     * @param array $rows Message models
     * @return array
     */
    protected function formatActivityRows($rows)
    {
        $campaignIds = [];
        foreach ($rows as $row) {
            if ($row->ref_id && in_array($row->ref_type, [Message::REF_CAMPAIGN, Message::REF_AUTOMATION], true)) {
                $campaignIds[(int) $row->ref_id] = (int) $row->ref_id;
            }
        }

        $campaigns = [];
        if ($campaignIds) {
            foreach (MessageCampaign::withoutGlobalScope('type')->whereIn('id', $campaignIds)->get(['id', 'title']) as $campaign) {
                $campaigns[(int) $campaign->id] = ['title' => $campaign->title];
            }
        }

        $formatted = [];

        foreach ($rows as $row) {
            $thread = $row->thread;

            $formatted[] = [
                'id'              => (int) $row->id,
                'message_content' => $row->content,
                'mobile_number'   => $thread ? $thread->phone_number : '',
                'channel'         => $thread ? $thread->channel : LegacyMessage::CHANNEL_SMS,
                'sms_type'        => $this->logType($row),
                'status'          => $row->status,
                'direction'       => $row->direction,
                // Raw strings, not the DateTime objects $dates would hand a
                // JSON encoder — the browser cannot parse those and the column
                // renders blank without raising anything.
                'sent_at'         => $row->rawDate('sent_at'),
                'scheduled_at'    => $row->rawDate('scheduled_at'),
                'created_at'      => $row->rawDate('created_at'),
                'subscriber_id'   => $thread && $thread->contact_id ? (int) $thread->contact_id : null,
                'subscriber'      => $thread && $thread->subscriber ? $thread->subscriber : null,
                'campaign'        => isset($campaigns[(int) $row->ref_id]) ? $campaigns[(int) $row->ref_id] : null
            ];
        }

        return $formatted;
    }

    /**
     * Delete multiple SMS messages
     *
     * @param Request $request
     */
    public function deleteMessages(Request $request)
    {
        $ids = $request->get('ids', []);
        
        if (empty($ids)) {
            return $this->sendError([
                'message' => 'No SMS messages selected for deletion',
                'code' => 400
            ]);
        }

        // The threads these belonged to have to be recomputed afterwards:
        // deleting the newest message changes where the conversation sorts, and
        // deleting an unread inbound one changes the badge.
        $threadIds = Message::whereIn('id', $ids)->pluck('thread_id')->toArray();

        $deleted = Message::whereIn('id', $ids)->delete();

        MessageThread::syncCaches($threadIds);

        return $this->sendSuccess([
            'message' => sprintf(__('%d SMS messages deleted successfully', 'fluentcampaign-pro'), $deleted),
            'deleted_count' => $deleted
        ]);
    }

    /**
     * Resend a specific SMS message
     *
     * @param Request $request
     * @param int $message_id
     */
    public function resendMessage(Request $request, $id)
    {
        // Find the original message
        $originalMessage = Message::with(['thread'])->find($id);

        if (!$originalMessage) {
            return $this->sendError([
                'message' => 'SMS message not found',
                'code' => 404
            ]);
        }

        $thread = $originalMessage->thread;

        if (!$thread) {
            return $this->sendError([
                'message' => 'Conversation not found',
                'code' => 404
            ]);
        }

        // The conversation's own number, not the contact's current one: resending
        // must go back to whoever the message was for, even if the contact has
        // since changed their number or was never a contact at all.
        $phoneNumber = $thread->phone_number;
        if (!$phoneNumber) {
            return $this->sendError([
                'message' => 'Subscriber does not have a phone number',
                'code' => 400
            ]);
        }

        // Validate message content length
        $messageContent = (string) $originalMessage->content;
        if (strlen($messageContent) > 1600) {
            return $this->sendError([
                'message' => 'Original message is too long to resend. Maximum 1600 characters allowed.',
                'code' => 400
            ]);
        }

        // The template a WhatsApp send resolved to has to travel with the copy,
        // or the resend falls back to free-form and is rejected outside the
        // 24-hour window.
        $copiedMetaKeys = ['template_id', 'settings'];

        // An automation send also carries the funnel subscriber it came from:
        // event-scoped smartcodes such as {{cart_order.order_id}} resolve through
        // that row, so without it the resent template variables render empty.
        // Scoped to automation so one-off and campaign resends do not grow
        // unrelated metadata.
        if ($originalMessage->ref_type === Message::REF_AUTOMATION) {
            $copiedMetaKeys[] = 'funnel_subscriber_id';
        }

        try {
            // A new row on the same thread — the resend is a second message in
            // the conversation, not an edit of the first.
            $newMessage = MessageThread::queueOutbound(
                $thread->channel ?: LegacyMessage::CHANNEL_SMS,
                $phoneNumber,
                $thread->contact_id,
                $messageContent,
                [
                    'ref_type' => $originalMessage->ref_type,
                    'ref_id'   => $originalMessage->ref_id,
                    'meta'     => array_intersect_key(
                        is_array($originalMessage->meta) ? $originalMessage->meta : [],
                        array_flip($copiedMetaKeys)
                    )
                ]
            );

            if (!$newMessage) {
                return $this->sendError([
                    'message' => __('Failed to queue SMS for resending', 'fluentcampaign-pro'),
                    'code' => 500
                ]);
            }

            MessageScheduler::dispatch($newMessage->id);

            $newMessage = Message::find($newMessage->id) ?: $newMessage;

            return $this->sendMessageOutcome(
                $newMessage,
                __('Message has been resent.', 'fluentcampaign-pro'),
                ['new_message_id' => $newMessage->id]
            );
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Failed to queue SMS for resending', 'fluentcampaign-pro'),
                'code' => 500
            ]);
        }
    }

    public function handleBulkAction(Request $request)
    {
        $actionName = $request->getSafe('action_name', 'sanitize_text_field', '');
        $requestedCampaignIds = $request->get('campaign_ids', []);
        $campaignIds = array_values(array_unique(array_filter(array_map(
            'intval',
            is_array($requestedCampaignIds) ? $requestedCampaignIds : []
        ))));

        $selectAllCampaigns = $request->getSafe('select_all', '');

        if ($selectAllCampaigns == 'true') {
            // Mirror the listing's channel scope — "select all" on the SMS
            // screen must never touch WhatsApp campaigns, and vice versa.
            $channel = sanitize_key($request->get('channel', ''));

            if (!in_array($channel, [LegacyMessage::CHANNEL_SMS, LegacyMessage::CHANNEL_WHATSAPP], true)) {
                return $this->sendError([
                    'message' => __('Please provide a valid messaging channel', 'fluentcampaign-pro')
                ], 422);
            }

            $campaignIds = MessageCampaign::where('type', 'campaign')
                ->where('channel', $channel)
                ->pluck('id')->toArray();
        }

        if (!$campaignIds) {
            return $this->sendError([
                'message' => __('Please provide campaign IDs', 'fluentcampaign-pro')
            ]);
        }

        if ($actionName == 'apply_labels') {
            // labels are coming as array of ids from request
            $newLabels = array_values(array_unique(array_filter(array_map(
                'intval',
                (array) $request->get('labels', [])
            ))));

            if (!$newLabels) {
                return $this->sendError([
                    'message' => __('Please provide labels', 'fluentcampaign-pro')
                ]);
            }

            $campaigns = MessageCampaign::whereIn('id', $campaignIds)->get();

            foreach ($campaigns as $campaign) {
                $campaign->attachLabels($newLabels);
            }

            return $this->sendSuccess([
                'message' => __('Labels has been applied successfully', 'fluentcampaign-pro'),
            ]);

        }

        if ($actionName == 'delete_campaigns') {
            $campaigns = MessageCampaign::whereIn('id', $campaignIds)->get();
            foreach ($campaigns as $campaign) {
                $campaignId = $campaign->id;
                // Remove orphaned generate/send jobs before their campaign row
                // disappears. Each handler still checks campaign state, but the
                // queue should not retain work that can never run.
                MessageScheduler::clearPendingCampaignActions($campaignId);
                // Read the channel before the row goes — the event is named after
                // it and there is nothing left to ask afterwards.
                $channel = $campaign->channel ?: MessageCampaign::CHANNEL_SMS;
                $campaign->deleteCampaignData();
                $campaign->delete();
                do_action('fluent_crm/' . $channel . '_campaign_deleted', $campaignId);
            }

            return $this->sendSuccess([
                'message' => __('Selected Campaigns has been deleted permanently', 'fluentcampaign-pro'),
            ]);
        }

        return $this->sendError([
            'message' => __('invalid bulk action', 'fluentcampaign-pro')
        ]);
    }

    public function updateLabels(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        // getSafe($key, $sanitizer, $default) — the sanitizer goes second, the
        // default third; passing the default second silently drops it.
        $action = $request->getSafe('action', 'sanitize_key', 'detach');
        $labelIds = $request->get('label_ids', []);

        if (!is_array($labelIds)) {
            $labelIds = [$labelIds];
        }

        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (!$labelIds) {
            return $this->sendError([
                'message' => __('Please provide labels', 'fluentcampaign-pro')
            ]);
        }

        if ($action === 'detach') {
            $campaign->detachLabels($labelIds);
        } else {
            $campaign->attachLabels($labelIds);
        }

        return $this->sendSuccess([
            'message' => __('Labels has been updated', 'fluentcampaign-pro')
        ]);
    }

    public function getCampaignStatus(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::whereIn('type', ['campaign', 'automation'])
            ->findOrFail($campaignId);

        if ($campaign->status == 'processing' || $campaign->status == 'pending-scheduled') {
            return [
                'current_timestamp' => fluentCrmTimestamp(),
                'stat'              => [],
                'campaign'          => $campaign,
                'sent_count'        => 0,
                'analytics'         => [],
                'subject_analytics' => []
            ];
        }
        if ($campaign->status == 'scheduled' && $campaign->scheduled_at) {
            if (strtotime($campaign->scheduled_at) < strtotime(current_time('mysql'))) {
                $campaign->status = 'working';
                $campaign->save();
            }
        }

        $analytics = [];

        $sentCount = Message::forCampaign($campaignId)
                                  ->where('status', Message::STATUS_SENT)
                                  ->count();


        if ($campaign->status == 'archived') {

            if (isset($analytics['open']) && $analytics['open']['total'] > $sentCount) {
                $analytics['open']['total'] = $sentCount;
            }

            if (isset($analytics['click']) && $analytics['click']['total'] > $sentCount) {
                $analytics['click']['total'] = $sentCount;
            }

        }

        // Only `status` is selected outside the aggregate and it is the grouping
        // key, so this holds under ONLY_FULL_GROUP_BY.
        $stat = Message::forCampaign($campaignId)
                             ->select('status', fluentCrmDb()->raw('count(*) as total'))
                             ->groupBy('status')
                             ->get();

        //attaching who sent the campaign
        $CampaignSentBy = $this->getCampaignSentData($campaign->id);
        $campaign->sent_by = $CampaignSentBy;

        return $this->sendSuccess([
            'current_timestamp' => fluentCrmTimestamp(),
            'stat'              => $stat,
            'campaign'          => $campaign,
            'sent_count'        => $sentCount,
            'analytics'         => $analytics,
        ], 200);


    }

    public function getCampaignRecipients(Request $request, $campaignId)
    {
        global $wpdb;

        $filterType = $request->get('filter_type');
        $search = $request->getSafe('search', 'sanitize_text_field');

        // The contact hangs off the thread now, so it is eager-loaded through it
        // and re-exposed as `subscriber` — the field the recipients table reads.
        $smsQuery = Message::with(['thread', 'thread.subscriber'])->forCampaign($campaignId);

        if ($search) {
            $searchLike = '%' . $wpdb->esc_like($search) . '%';
            $smsQuery->whereHas('thread', function ($threadQuery) use ($search, $searchLike) {
                $threadQuery->where('phone_number', 'LIKE', $searchLike)
                    ->orWhereHas('subscriber', function ($q) use ($search) {
                        $q->searchBy($search);
                    });
            });
        }

        $filterType = in_array($filterType, ['click', 'failed', 'sent', 'delivered']) ? $filterType : '';

        if ($filterType == 'failed') {
            $smsQuery = $smsQuery->where('status', Message::STATUS_FAILED);
        } else if ($filterType == 'sent') {
            $smsQuery = $smsQuery->where('status', Message::STATUS_SENT);
        } else if ($filterType == 'delivered') {
            // `delivery_status` merged into `status` — see the plan's §6 mapping.
            $smsQuery = $smsQuery->where('status', Message::STATUS_DELIVERED);
        }

        $smsQuery = $smsQuery->orderBy('created_at', 'DESC');

        $smsMessages = $smsQuery->paginate();

        foreach ($smsMessages->items() as $recipient) {
            $thread = $recipient->thread;
            $subscriber = $thread ? $thread->subscriber : null;
            $recipientMeta = is_array($recipient->meta) ? $recipient->meta : [];
            $oneTimeRecipient = Arr::get($recipientMeta, 'one_time_recipient', []);
            $oneTimeRecipient = is_array($oneTimeRecipient) ? $oneTimeRecipient : [];

            $recipient->subscriber = $subscriber;
            $recipient->subscriber_id = $subscriber ? (int) $subscriber->id : null;
            $recipient->recipient_name = $subscriber ? $subscriber->full_name : (string) Arr::get($oneTimeRecipient, 'full_name', '');
            $recipient->recipient_email = $subscriber ? $subscriber->email : '';
            $recipient->recipient_phone = $thread ? $thread->phone_number : (string) Arr::get($oneTimeRecipient, 'phone_number', '');
            $recipient->subscriber_photo = $subscriber ? $subscriber->photo : '';
            $recipient->one_time_recipient = $oneTimeRecipient ?: null;
            // Raw string rather than the DateTime $dates would serialize as an
            // unparseable object.
            $recipient->created_at = $recipient->rawDate('created_at');
        }

        return $this->sendSuccess([
            'recipients'  => $smsMessages,
            'failed_counts' => Message::forCampaign($campaignId)->where('status', Message::STATUS_FAILED)->count()
        ]);
    }

    private function getCampaignSentData($campaignId)
    {
        $campaignSentById = fluentcrm_get_sms_campaign_meta($campaignId, '_sms_campaign_sent_by', true);
        $user = get_userdata($campaignSentById);
        if($user) {
            return $user->display_name . ' (' . $user->user_email . ')';
        }
        return false;
    }

    public function processingStat(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::whereIn('type', fluentCrmAutoProcessSmsCampaignTypes())
            ->findOrFail($campaignId);

        if ($campaign->status != 'processing') {
//            if ($campaign->status == 'scheduled' && current_time('timestamp') - strtotime($campaign->scheduled_at) > 300) {
//                if (Scheduler::markArchiveCampaigns()) {
//                    $campaign = Campaign::withoutGlobalScope('type')
//                        ->findOrFail($campaignId);
//                }
//            }

            return [
                'reload'   => true,
                'campaign' => $campaign
            ];
        }

        $completedCount = Message::forCampaign($campaignId)
            ->whereIn('status', [Message::STATUS_SENT, Message::STATUS_DELIVERED, Message::STATUS_FAILED])
            ->count();

        if (!$campaign->recipients_count || $campaign->recipients_count < $completedCount) {
            $campaign->recipients_count = $completedCount;
        }

        $sendingType = '';
        if (!empty($campaign->settings) && is_array($campaign->settings)) {
            $sendingType = $campaign->settings['sending_type'] ?? '';
        }

        //will implement later for sms
        // This is the processing status
//        $processor = (new CampaignProcessor($campaign->id));
//        $processedCampaign = $processor->processEmails(30, 10);
//
//        $didRun = false;
//        if ($processedCampaign) {
//            $campaign = $processedCampaign;
//            $didRun = true;
//        }
//
//
//        return [
//            'campaign'          => $campaign,
//            'didRun'            => $didRun,
//            'scheduling_method' => $processor->getSchedulingMethod()
//        ];

        return [
            'reload'            => false,
            'campaign'          => $campaign,
            'didRun'            => false,
            'scheduling_method' => $sendingType
        ];
    }
    public function doTagActions(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status != 'archived') {
            return $this->sendError([
                'message' => __('You can do this action if campaign is in archived status only', 'fluentcampaign-pro')
            ]);
        }

        $this->validate($request->all(), [
            'action_type'     => 'required',
            'tags'            => 'required',
            'activity_type'   => 'required',
            'processing_page' => 'required|integer'
        ]);

        $actionType = $request->get('action_type');
        $tags = $request->get('tags');
        $activityType = $request->get('activity_type');

        $processingPage = intval($request->get('processing_page'));
        $limit = apply_filters('fluent_crm/sms_campaign_action_limit', 50);
        $offset = ($processingPage - 1) * $limit;
        $count = false;

        // Contacts are reached through their thread, so the campaign's audience
        // is the set of threads it messaged. Only `thread_id` is selected and it
        // is the grouping key, so this holds under ONLY_FULL_GROUP_BY.
        $smsQuery = Message::forCampaign($campaignId)
            ->select('thread_id')
            ->groupBy('thread_id');

        if ($activityType == 'sms_sent') {
            $smsQuery->where('status', Message::STATUS_SENT);
        } else if ($activityType == 'sms_failed') {
            $smsQuery->where('status', Message::STATUS_FAILED);
        } else if ($activityType == 'sms_delivered') {
            // `delivery_status` merged into `status` — see the plan's §6 mapping.
            $smsQuery->where('status', Message::STATUS_DELIVERED);
        } else if ($activityType != 'all_recipients') {
            return $this->sendError([
                'message' => __('Invalid activity type selection', 'fluentcampaign-pro')
            ]);
        }

        if ($processingPage == 1) {
            $countQuery = clone $smsQuery;
            $count = $countQuery->distinct()->count('thread_id');
        }

        $threadIds = $smsQuery->offset($offset)
            ->limit($limit)
            ->get()->pluck('thread_id')->toArray();

        // A contactless thread yields no contact to tag, which is correct — the
        // tag actions operate on the CRM, and there is nobody there yet.
        $subscriberIds = $threadIds
            ? MessageThread::whereIn('id', $threadIds)->whereNotNull('contact_id')->pluck('contact_id')->toArray()
            : [];

        $subscribers = Subscriber::whereIn('id', $subscriberIds)
            ->where('status', 'subscribed')
            ->get();

        if ($actionType == 'add_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->attachTags($tags);
            }
        } else if ($actionType == 'remove_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->detachTags($tags);
            }
        }

        $totalSubscribers = count($subscribers);

        return [
            'processed_page'     => $processingPage,
            'processed_contacts' => $totalSubscribers,
            'has_more'           => !!$totalSubscribers,
            'total_count'        => $count,
        ];
    }

    public function delete(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        // Delete pending Action Scheduler work before removing the campaign;
        // otherwise the queue keeps orphaned cursor actions until they execute.
        MessageScheduler::clearPendingCampaignActions($campaignId);
        $channel = $campaign->channel ?: MessageCampaign::CHANNEL_SMS;
        $campaign->deleteCampaignData();
        $campaign->delete();
        do_action('fluent_crm/' . $channel . '_campaign_deleted', $campaignId);

        return $this->send([
            'success' => true
        ]);
    }
}
