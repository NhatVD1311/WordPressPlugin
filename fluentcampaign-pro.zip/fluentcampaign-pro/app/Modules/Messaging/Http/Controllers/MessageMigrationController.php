<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\Framework\Http\Request\Request;

/**
 * One-shot migration of `fc_sms_messages` into `fc_message_threads` +
 * `fc_messages`, plus the two endpoints that drive it.
 *
 * ---------------------------------------------------------------------------
 * THIS IS TEMPORARY CODE. Once every install has migrated, delete it.
 *
 * The REST handlers and the migration logic sit in this one file deliberately,
 * rather than being split into a service and a thin controller. Nothing else
 * calls the migrator, and keeping it whole means retiring it is a deletion
 * rather than an excavation. Removing the feature means:
 *
 *   1. this file
 *   2. resources/v3app/src/Modules/Messaging/MigrationBanner.vue
 *   3. its two placements — Messaging/Inbox/Inbox.vue and
 *      Settings/_MessagingSettings.vue
 *   4. the `messaging/migration` route group in app/Modules/Messaging/Http/messaging_api.php
 *   5. three coverage contracts, which fail until updated:
 *      tests/smoke/routes.manifest.php, tests/smoke/mutating.manifest.php,
 *      and the route counts in tests/bin/run-permissions.php
 *   6. the banner styles at the end of resources/styles/modules/_inbox.scss
 * ---------------------------------------------------------------------------
 *
 * Batched and cursor-driven. The source table can hold years of campaign sends
 * and one request would time out long before finishing, so the browser calls
 * `migrate` repeatedly and each call commits its own batch. Closing the tab
 * pauses the work rather than losing it.
 *
 * The reshaping is small: everything identifying *who* a conversation is with
 * (`subscriber_id`, `mobile_number`, `channel`) moves up to the thread, and the
 * message keeps only what is specific to that one send.
 *
 * Gated by SettingsPolicy — `fcrm_manage_settings`, the highest FluentCRM
 * permission level.
 *
 * @see \FluentCampaign\App\Modules\Messaging\MessageMigrator::migrateMessageThreadsTable()
 * @see \FluentCampaign\App\Modules\Messaging\MessageMigrator::migrateMessagesTable()
 */
class MessageMigrationController extends Controller
{


    /**
     * Progress record, stored in fc_meta as an option.
     *
     * Shape: ['status' => pending|running|complete, 'last_id' => int,
     *         'migrated' => int, 'threads' => int, 'started_at' => string,
     *         'completed_at' => string]
     */
    const OPTION = '_fc_message_migration';

    /**
     * Rows per batch.
     *
     * A batch costs a handful of queries regardless of size now that threads
     * and messages are resolved in bulk, so this is sized against memory and
     * statement length rather than query count.
     */
    const BATCH_SIZE = 2000;

    /**
     * Seconds one HTTP request may keep migrating before answering.
     *
     * The browser drives the loop, so every batch would otherwise cost a full
     * round trip. Looping inside the request until the budget is spent turns
     * dozens of round trips into a handful, which is where the wall-clock time
     * actually goes — the queries themselves are bulk and cheap.
     *
     * 15 is a deliberate ceiling, not a target: it stays under the 30-second
     * default max_execution_time with room for a slow final batch, and under
     * the 60-second gateway timeouts most hosts run. The admin is watching a
     * progress bar, so a longer request costs nothing visible while removing
     * two thirds of the round trips.
     */
    const REQUEST_BUDGET = 15;

    /**
     * Legacy `sms_type` values that carry a campaign or automation reference.
     * Anything else — a one-off send, or an inbound message — has no referent
     * and leaves `ref_type` null.
     */
    protected static $refTypes = ['campaign', 'automation'];


    /**
     * Progress for the migration notice.
     */
    public function status()
    {
        return ['migration' => self::getStatus()];
    }

    /**
     * Move as much as one request safely can, then hand back to the browser.
     *
     * The admin drives this loop from the notice bar, which keeps calling until
     * the response reports done. Two admins running it at once is safe: each
     * batch advances a persisted cursor inside the transaction that writes its
     * rows, so the second request resumes from where the first got to rather
     * than repeating it.
     */
    public function migrate(Request $request)
    {
        // Bounded so a crafted request cannot ask for a batch large enough to
        // time out the very thing batching exists to prevent.
        $batchSize = (int) $request->get('batch_size', self::BATCH_SIZE);
        $batchSize = max(10, min($batchSize, 5000));

        $deadline = microtime(true) + self::REQUEST_BUDGET;

        do {
            $result = self::migrateBatch($batchSize);
        } while (empty($result['done']) && microtime(true) < $deadline);

        // The notice keeps calling while `done` is false and redraws from
        // `migration`. One status read per request, not one per batch.
        return [
            'done'      => !empty($result['done']),
            'migration' => self::getStatus(),
        ];
    }

    /**
     * The legacy table only exists where FluentCampaign Pro has created it, so
     * every entry point has to tolerate its absence rather than assume it.
     */
    public static function sourceTable()
    {
        global $wpdb;

        return $wpdb->prefix . 'fc_sms_messages';
    }

    public static function isAvailable()
    {
        global $wpdb;

        $table = self::sourceTable();

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    }

    /**
     * How much of the legacy table is left.
     *
     * Three numbers, because three are read: the notice shows a count, a
     * progress fraction, and stops when nothing remains.
     */
    public static function getStatus()
    {
        global $wpdb;

        if (!self::isAvailable()) {
            return ['total' => 0, 'migrated' => 0, 'remaining' => 0];
        }

        $state = self::getState();
        $table = self::sourceTable();

        return [
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            'total'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table`"),
            'migrated'  => (int) $state['migrated'],
            'remaining' => (int) $wpdb->get_var(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->prepare("SELECT COUNT(*) FROM `$table` WHERE id > %d", $state['last_id'])
            ),
        ];
    }

    /**
     * The one stored answer to "is this site done with the legacy table?".
     *
     * Kept as its own option rather than re-derived from a row count on every
     * render. The count is not a safe proxy: it says nothing about a site that
     * never had the legacy table, and it flips back to "pending" if anything
     * ever lands in that table again after a finished run.
     */
    const DONE_OPTION = '_fc_message_migration_done';

    /**
     * @return bool
     */
    public static function isMigrated()
    {
        return fluentcrm_get_option(self::DONE_OPTION) === 'yes';
    }

    /**
     * Record that this site has nothing left to move, and why.
     *
     * The reason is kept for support: "no-legacy-table" and "legacy-table-empty"
     * mean the site never had anything to migrate, which looks identical to a
     * finished run from the outside and is the first thing anyone asks about
     * when a banner does not appear.
     *
     * @param string $reason completed|no-legacy-table|legacy-table-empty
     */
    public static function markMigrated()
    {
        fluentcrm_update_option(self::DONE_OPTION, 'yes');

        $state = self::getState();
        $state['status'] = 'complete';
        $state['completed_at'] = $state['completed_at'] ?: gmdate('Y-m-d H:i:s');

        self::putState($state);
    }





    /**
     * Migrate one batch and return the resulting status.
     *
     * The inserts and the cursor advance share a transaction. That is what
     * makes a re-run safe: a request that dies half way rolls back both, so the
     * next call reprocesses the whole batch from a cursor that never saw it,
     * rather than resuming into the middle of a partially-written batch and
     * duplicating messages.
     *
     * @param int|null $batchSize
     * @return array
     */
    public static function migrateBatch($batchSize = null)
    {
        global $wpdb;

        if (!self::isAvailable()) {
            return ['done' => true, 'moved' => 0];
        }

        $batchSize = $batchSize ? (int) $batchSize : self::BATCH_SIZE;
        $state = self::getState();
        $table = self::sourceTable();

        $rows = $wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->prepare(
                "SELECT * FROM `$table` WHERE id > %d ORDER BY id ASC LIMIT %d",
                $state['last_id'],
                $batchSize
            )
        );

        if (!$rows) {
            self::markMigrated();

            return ['done' => true, 'moved' => 0];
        }

        if ($state['status'] !== 'running') {
            $state['status'] = 'running';
            $state['started_at'] = $state['started_at'] ?: gmdate('Y-m-d H:i:s');
        }

        fluentCrmDb()->beginTransaction();

        try {
            // Bulk, not row-by-row. The naive version cost a SELECT plus one or
            // two INSERTs for every source row, which is tens of thousands of
            // round trips on a real site. Resolving a whole batch's threads in
            // one query and inserting its messages in one statement makes the
            // per-batch cost a handful of queries regardless of batch size.
            $threadIds = self::resolveThreads($rows, $state);

            self::insertMessages($rows, $threadIds, $state);

            $last = end($rows);
            $state['last_id'] = (int) $last->id;

            // Completion is decided here, not on the next empty batch. A run
            // that consumes the final rows must finish as 'complete', or the
            // progress UI sits at 100% still reporting 'running' until someone
            // asks for a batch that does not exist.
            // One indexed row lookup, not a COUNT: all we need to know is
            // whether anything is left past the cursor.
            $finished = !$wpdb->get_var(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->prepare("SELECT id FROM `$table` WHERE id > %d LIMIT 1", $state['last_id'])
            );

            if ($finished) {
                $state['status'] = 'complete';
                $state['completed_at'] = $state['completed_at'] ?: gmdate('Y-m-d H:i:s');
            }

            self::putState($state);

            // Inside the transaction with the cursor it advanced: a run that
            // consumed the last rows must not be able to commit them and then
            // lose the record that it finished.
            if ($finished) {
                fluentcrm_update_option(self::DONE_OPTION, 'yes');
            }

            fluentCrmDb()->commit();
        } catch (\Exception $e) {
            fluentCrmDb()->rollBack();

            throw $e;
        }

        // Deliberately not getStatus(): that costs two COUNT(*) scans of the
        // source table, and paying for them after every batch dominated the
        // migration on a large site. $finished already came from that lookup,
        // which is a single indexed row lookup.
        return ['done' => $finished, 'moved' => count($rows)];
    }

    /**
     * Resolve every thread a batch needs, in three queries rather than one per
     * row.
     *
     * Threads are keyed on (channel, phone_number) — the number is the identity
     * of a conversation, and the contact is an attribute that may be absent or
     * arrive later.
     *
     * INSERT IGNORE carries the weight here: it collapses rows in this batch
     * that share a number, and it makes the insert safe against a thread that
     * appeared between the SELECT and the INSERT, because the unique index
     * rejects the duplicate instead of the statement failing.
     *
     * @return array map of "channel|phone" => thread id
     */
    protected static function resolveThreads(array $rows, array &$state)
    {
        global $wpdb;

        $threads = $wpdb->prefix . 'fc_message_threads';

        // Distinct conversations in this batch, and the first row that speaks
        // for each — used for the thread's channel, initiator and timestamps.
        $wanted = [];
        foreach ($rows as $row) {
            $phone = trim((string) $row->mobile_number);

            if ($phone === '') {
                continue;
            }

            $key = ($row->channel ? $row->channel : 'sms') . '|' . $phone;

            if (!isset($wanted[$key])) {
                $wanted[$key] = $row;
            }
        }

        if (!$wanted) {
            return [];
        }

        $pairs = [];
        foreach (array_keys($wanted) as $key) {
            list($channel, $phone) = explode('|', $key, 2);
            $pairs[] = $wpdb->prepare('(%s,%s)', $channel, $phone);
        }
        $pairsSql = implode(',', $pairs);

        $insertRows = [];
        foreach ($wanted as $key => $row) {
            list($channel, $phone) = explode('|', $key, 2);

            // 'user' means the person on the other end started it, which is what
            // an inbound first message means. Anything else is the business
            // reaching out.
            $initiatedBy = ($row->direction === 'inbound') ? 'user' : 'admin';

            $insertRows[] = '(' . implode(',', [
                self::sqlVal($row->subscriber_id, 'int'),
                self::sqlVal($channel, 'str'),
                self::sqlVal($phone, 'str'),
                self::sqlVal('subscribed', 'str'),
                self::sqlVal($initiatedBy, 'str'),
                '0',
                self::sqlVal($row->created_at, 'ts'),
                self::sqlVal($row->updated_at, 'ts')
            ]) . ')';
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "INSERT IGNORE INTO `$threads`
                (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`created_at`,`updated_at`)
             VALUES " . implode(',', $insertRows)
        );

        $state['threads'] += (int) $wpdb->rows_affected;

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $found = $wpdb->get_results(
            "SELECT id, channel, phone_number, contact_id FROM `$threads`
             WHERE (channel, phone_number) IN ($pairsSql)"
        );

        $map = [];
        $backfill = [];
        foreach ($found as $thread) {
            $key = $thread->channel . '|' . $thread->phone_number;
            $map[$key] = (int) $thread->id;

            // A later row may carry a contact where an earlier one did not — an
            // inbound message from an unknown number, then the contact being
            // created. Fill the gap, but never overwrite an existing link.
            if ($thread->contact_id === null && !empty($wanted[$key]->subscriber_id)) {
                $backfill[(int) $wanted[$key]->subscriber_id][] = (int) $thread->id;
            }
        }

        foreach ($backfill as $contactId => $ids) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE `$threads` SET contact_id = %d
                     WHERE contact_id IS NULL AND id IN (" . implode(',', array_map('intval', $ids)) . ")",
                    $contactId
                )
            );
        }

        return $map;
    }

    /**
     * Insert a whole batch's messages in one statement.
     *
     * Rows whose number was unusable have no thread and are skipped rather than
     * being given a conversation of their own; they are still counted past by
     * the cursor so the run cannot stall on them.
     */
    protected static function insertMessages(array $rows, array $threadIds, array &$state)
    {
        $items = [];

        foreach ($rows as $row) {
            $phone = trim((string) $row->mobile_number);

            if ($phone === '') {
                continue;
            }

            $key = ($row->channel ? $row->channel : 'sms') . '|' . $phone;

            if (!isset($threadIds[$key])) {
                continue;
            }

            $refType = in_array($row->sms_type, self::$refTypes, true) ? $row->sms_type : null;

            $items[] = [
                'thread_id'          => $threadIds[$key],
                'direction'          => $row->direction ? $row->direction : 'outbound',
                'content'            => $row->message_content,
                'ref_id'             => $row->campaign_id,
                'ref_type'           => $refType,
                'status'             => $row->status ? $row->status : 'pending',
                'provider_message_id' => $row->provider_message_id,
                'scheduled_at'       => $row->scheduled_at,
                'sent_at'            => $row->sent_at,
                'meta'               => self::buildMeta($row),
                'created_at'         => $row->created_at,
                'updated_at'         => $row->updated_at,
                // Legacy outbound rows represent replies the business already
                // made, so they advance the same read cursor as a live reply.
                'mark_read'          => $row->direction !== 'inbound'
            ];
        }

        if (!$items) {
            return;
        }

        $written = MessageThread::recordMessages($items);
        $state['migrated'] += count($written);
    }

    /**
     * Everything the new table has no column for, kept rather than dropped.
     */
    protected static function buildMeta($row)
    {
        return array_filter([
            'legacy_id'       => (int) $row->id,
            'legacy_sms_type' => $row->sms_type,
            'delivery_status' => $row->delivery_status,
            'notes'           => $row->notes,
            'click_counter'   => $row->click_counter ? (int) $row->click_counter : null,
            'template_id'     => $row->template_id ? (int) $row->template_id : null,
            'delivered_at'    => $row->delivered_at,
            'read_at'         => $row->read_at,
            'settings'        => $row->settings ? self::maybeJson($row->settings) : null
        ], function ($value) {
            return $value !== null && $value !== '';
        });
    }

    /**
     * One value for a bulk VALUES list.
     *
     * $wpdb->prepare() has no NULL placeholder — it would write an empty string
     * and turn a null timestamp into an invalid zero date under strict SQL
     * modes. Nulls are emitted as the literal instead; everything else is still
     * prepared.
     *
     * @param mixed  $value
     * @param string $kind int|str|ts
     * @return string
     */
    protected static function sqlVal($value, $kind = 'str')
    {
        global $wpdb;

        if ($value === null || ($kind !== 'str' && $value === '')) {
            return 'NULL';
        }

        if ($kind === 'int') {
            return $value ? (string) (int) $value : 'NULL';
        }

        return $wpdb->prepare('%s', $value);
    }

    /**
     * The legacy `settings` column is JSON. It is decoded here so the value
     * lands inside the new serialized `meta` as a real array rather than as a
     * JSON string buried in a serialized blob.
     */
    /**
     * Legacy settings were stored as JSON by some writers and as a plain string
     * by others. Decode when it parses, keep the original when it does not.
     */
    protected static function maybeJson($value)
    {
        $decoded = json_decode($value, true);

        return (json_last_error() === JSON_ERROR_NONE) ? $decoded : $value;
    }


    protected static function getState()
    {
        $stored = fluentcrm_get_option(self::OPTION, []);

        if (!is_array($stored)) {
            $stored = [];
        }

        return wp_parse_args($stored, [
            'status'       => 'pending',
            'last_id'      => 0,
            'migrated'     => 0,
            'threads'      => 0,
            'started_at'   => '',
            'completed_at' => ''
        ]);
    }

    protected static function putState(array $state)
    {
        fluentcrm_update_option(self::OPTION, $state);
    }

}
