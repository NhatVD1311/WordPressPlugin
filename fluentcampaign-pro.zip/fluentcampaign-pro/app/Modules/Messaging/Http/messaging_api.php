<?php
/**
 * Every Messaging route, registered as a whole when the Message module is on.
 *
 * The prefix says who the route serves, not who it was written for first.
 * Campaigns, the activity list and per-contact history all take a `channel`
 * parameter and always did — SMS and WhatsApp campaign screens call the very
 * same endpoints — so they sit under `messaging/`. Only what one channel alone
 * can answer keeps a channel prefix: `whatsapp/` for Meta's template catalogue
 * and the 24-hour session window. Nothing is SMS-only, so there is no `sms/`
 * group; an SMS-scoped read is `messaging/...?channel=sms`.
 *
 * @var $router FluentCrm\Framework\Http\Router
 */

use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageController;
use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageMigrationController;
use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageThreadController;
use FluentCampaign\App\Modules\Messaging\Http\Policies\InboxPolicy;
use FluentCampaign\App\Modules\Messaging\Http\Policies\MessagePolicy;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Http\Controllers\WhatsAppTemplateController;
use FluentCrm\App\Http\Policies\SettingsPolicy;

// Conversation inbox: threads and their messages.
$router->prefix('messaging/threads')->withPolicy(InboxPolicy::class)->group(function ($router) {
    $router->get('/', [MessageThreadController::class, 'index']);
    // Registered before the {id} routes so a literal segment is never read as
    // an id. Both are read-scoped by InboxPolicy::verifyRequest().
    $router->get('/recipients', [MessageThreadController::class, 'recipients']);
    // Mutates conversation state by reserving a thread. POST, never GET.
    // InboxPolicy::verifyRequest() requires fcrm_manage_emails for any
    // non-GET, which is the correct write capability here.
    $router->post('/', [MessageThreadController::class, 'store']);
    $router->get('/{id}/messages', [MessageThreadController::class, 'messages'])->int('id');
    $router->post('/{id}/messages', [MessageThreadController::class, 'sendMessage'])->int('id');
    $router->post('/{id}/seen', [MessageThreadController::class, 'markSeen'])->int('id');
    // Consent for the conversation's number on its channel. Thread-scoped so a
    // number with no CRM contact can be opted out from the inbox too.
    $router->post('/{id}/consent', [MessageThreadController::class, 'updateConsent'])->int('id');
    // Attaching a CRM contact to a conversation. POST, never GET — it mutates
    // thread identity.
    $router->post('/{id}/contact', [MessageThreadController::class, 'linkContact'])->int('id');
});

// Moving fc_sms_messages into fc_message_threads + fc_messages. Admin-driven:
// the notice bar polls the first route for progress and calls the second
// repeatedly until it reports done. Batched because the source table can hold
// years of sends, and each batch commits with its own cursor — so closing the
// tab pauses the move rather than losing it.
$router->prefix('messaging/migration')->withPolicy(SettingsPolicy::class)->group(function ($router) {
    $router->get('/', [MessageMigrationController::class, 'status']);
    $router->post('/migrate', [MessageMigrationController::class, 'migrate']);
});

/*
 * Campaigns, activities and per-contact history — every channel.
 *
 * Each of these resolves its channel from the request (`?channel=sms`,
 * `?channel=whatsapp`) or from the thread the row belongs to.
 */
$router->prefix('messaging')->withPolicy(MessagePolicy::class)->group(function ($router) {
    // Per-contact history and sending, scoped by ?channel=
    $router->get('/subscribers/{id}/logs', [MessageController::class, 'getLogs'])->int('id');
    $router->post('/subscribers/{id}/send', [MessageController::class, 'sendCustomSMS'])->int('id');
    $router->get('/subscribers/{id}/stats', [MessageController::class, 'getStats'])->int('id');
    // Consent now lives on the conversation threads, so the profile tabs read
    // and write it here instead of through core's contact-property endpoint.
    $router->get('/subscribers/{id}/consent', [MessageController::class, 'getConsent'])->int('id');
    $router->post('/subscribers/{id}/consent', [MessageController::class, 'updateConsent'])->int('id');

    // Campaign routes
    $router->get('/campaigns', [MessageController::class, 'campaigns']);
    $router->post('/campaigns', [MessageController::class, 'create']);
    $router->get('/campaigns/{id}', [MessageController::class, 'campaign'])->int('id');
    $router->put('/campaigns/{id}', [MessageController::class, 'update']);
    $router->put('/campaigns/{id}/update-labels', [MessageController::class, 'updateLabels'])->int('id');
    $router->post('/campaigns/estimated-contacts', [MessageController::class, 'getContactEstimation']);
    $router->get('/campaigns/{id}/estimated-recipients-count', [MessageController::class, 'getRecipientsCount'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/upload', [MessageController::class, 'uploadOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/paste', [MessageController::class, 'pasteOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/process', [MessageController::class, 'processOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/activate', [MessageController::class, 'activateOneTimeAudience'])->int('id');
    $router->get('/campaigns/{id}/one-time-audience/recipients', [MessageController::class, 'getOneTimeAudienceRecipients'])->int('id');
    $router->get('/campaigns/{id}/one-time-audience', [MessageController::class, 'getOneTimeAudience'])->int('id');
    $router->delete('/campaigns/{id}/one-time-audience', [MessageController::class, 'clearOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/schedule', [MessageController::class, 'schedule'])->int('id');
    $router->post('/campaigns/{id}/pause', [MessageController::class, 'pauseCampaign'])->int('id');
    $router->post('/campaigns/{id}/resume', [MessageController::class, 'resumeCampaign'])->int('id');
    $router->post('/campaigns/{id}/unschedule', [MessageController::class, 'unSchedule'])->int('id');
    $router->post('/campaigns/do-bulk-action', [MessageController::class, 'handleBulkAction']);
    $router->get('/campaigns/{id}/status', [MessageController::class, 'getCampaignStatus'])->int('id');
    $router->get('/campaigns/{id}/recipients', [MessageController::class, 'getCampaignRecipients'])->int('id');
    $router->post('/campaigns/{id}/tag-actions', [MessageController::class, 'doTagActions'])->int('id');
    $router->get('/campaigns/{id}/processing-stat', [MessageController::class, 'processingStat'])->int('id');
    $router->post('/campaigns/{id}/duplicate', [MessageController::class, 'duplicateCampaign'])->int('id');
    $router->delete('/campaigns/{id}', [MessageController::class, 'delete'])->int('id');

    // The Activities list: every message, any channel
    $router->get('/messages', [MessageController::class, 'getAllMessages']);
    $router->delete('/messages', [MessageController::class, 'deleteMessages']);
    $router->post('/messages/{id}/resend', [MessageController::class, 'resendMessage'])->int('id');
});

/*
 * WhatsApp template catalogue and per-contact history.
 *
 * Uses the same policy as the shared routes. The framework matches policy methods
 * by controller method name, so MessagePolicy defines methods for template writes,
 * sends, and deletes instead of letting mutating calls fall back to the
 * read-level verifyRequest permission.
 */
$router->prefix('whatsapp')->withPolicy(MessagePolicy::class)->group(function ($router) {
    $router->get('/templates', [WhatsAppTemplateController::class, 'index']);
    $router->post('/templates', [WhatsAppTemplateController::class, 'store']);
    $router->post('/templates/sync', [WhatsAppTemplateController::class, 'sync']);
    $router->post('/templates/validate', [WhatsAppTemplateController::class, 'validateTemplate']);
    $router->delete('/templates/{id}', [WhatsAppTemplateController::class, 'destroy'])->int('id');

    $router->get('/subscribers/{id}/messages', [WhatsAppTemplateController::class, 'subscriberMessages'])->int('id');
    $router->get('/subscribers/{id}/stats', [WhatsAppTemplateController::class, 'subscriberStats'])->int('id');
    $router->get('/subscribers/{id}/session', [WhatsAppTemplateController::class, 'subscriberSession'])->int('id');
    $router->post('/subscribers/{id}/send', [WhatsAppTemplateController::class, 'sendCustomMessage'])->int('id');
});
