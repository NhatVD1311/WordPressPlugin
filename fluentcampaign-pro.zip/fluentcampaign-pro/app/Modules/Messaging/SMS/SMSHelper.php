<?php

namespace FluentCampaign\App\Modules\Messaging\SMS;

use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Libs\Parser\Parser;
use FluentCrm\Framework\Support\Arr;

class SMSHelper
{
    const SMS_WEBHOOK_KEY_OPTION = '_fc_sms_webhook_key';

    /**
     * Per-request memo of getSettings(). Every send funnels through isActive()
     * and getProviderSettings(), each of which rebuilds the settings from
     * several uncached fc_meta reads — a 30-message batch was ~300 identical
     * SELECTs. Settings only change via SettingsController, which clears this.
     */
    protected static $settingsCache = null;

    public static function clearSettingsCache()
    {
        self::$settingsCache = null;
    }

    public static function getSettings()
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [];

        $is_enabled = fluentcrm_get_option('_fc_sms_enable', 'no');

        $current_provider = fluentcrm_get_option('_fc_sms_provider', '');

        $settings['enabled'] = $is_enabled;
        $settings['sms_provider'] = $current_provider;

        $provider_api_options = self::getApiOptions();

        // Callers that run before the drivers register (isActive() gates during
        // module boot) see an empty provider registry. Serve them the base
        // shape but do NOT memoize it — a cached provider-less array would
        // later reach the settings screen with no credential fields.
        if (empty($provider_api_options['providers'])) {
            return $settings;
        }

        foreach ($provider_api_options['providers'] as $provider_name => $options) {
            $current_settings = fluentcrm_get_option("_fc_sms_{$provider_name}_settings", []);
            if (is_array($current_settings) && !empty($current_settings)) {
                $settings[$provider_name] = $current_settings;
            } else {
                foreach ($options['fields'] as $key => $value) {
                    $settings[$provider_name][$key] = $value['default'] ?? '';
                }
            }
        }

        self::$settingsCache = $settings;

        return $settings;
    }

    public static function getCurrentProvider()
    {
        // Same value getSettings() stores; reading through it reuses the
        // per-request memo instead of another fc_meta round trip per send.
        return self::getSettings()['sms_provider'] ?? '';
    }

    public static function getAllowedProviders()
    {
        return Providers\SMSDriverManager::getSlugs();
    }

    public static function twilioSettings()
    {
        $settings = self::getSettings();
        return [
            'twilio_account_sid' => $settings['twilio']['account_sid'] ?? '',
            'twilio_auth_token' => $settings['twilio']['auth_token'] ?? '',
            'twilio_from_number' => $settings['twilio']['from_number'] ?? ''
        ];
    }

    public static function awsEumSettings()
    {
        $settings = self::getSettings();
        return [
            'aws_eum_access_key' => $settings['aws_end_user_message']['access_key_id'] ?? '',
            'aws_eum_secret_key' => $settings['aws_end_user_message']['secret_access_key'] ?? '',
            'aws_eum_region' => $settings['aws_end_user_message']['region'] ?? 'us-east-1',
            'aws_eum_sender_id' => $settings['aws_end_user_message']['sender_id'] ?? ''
        ];
    }

    public static function clickSendSettings()
    {
        $settings = self::getSettings();
        return [
            'clicksend_username' => $settings['click_send']['username'] ?? '',
            'clicksend_api_key' => $settings['click_send']['api_key'] ?? '',
            'clicksend_from_number' => $settings['click_send']['from_number'] ?? ''
        ];
    }

    public static function isActive()
    {
        if (!MessageModule::isEnabled()) {
            return false;
        }

        $settings = self::getSettings();

        return !empty($settings['enabled']) && $settings['enabled'] === 'yes';
    }

    public static function applyRecipientSmartCodes($content, $message)
    {
        $recipient = self::oneTimeRecipientContext($message);
        if (!$recipient) {
            return (string) $content;
        }

        return strtr((string) $content, [
            '{{recipient.full_name}}'      => (string) Arr::get($recipient, 'full_name', ''),
            '{{ recipient.full_name }}'    => (string) Arr::get($recipient, 'full_name', ''),
            '{{recipient.phone_number}}'   => (string) Arr::get($recipient, 'phone_number', ''),
            '{{ recipient.phone_number }}' => (string) Arr::get($recipient, 'phone_number', '')
        ]);
    }

    public static function stripUnresolvedSmartCodes($content)
    {
        return trim(preg_replace('/({{|##)\s*[^}#]+?\s*(}}|##)/', '', (string) $content));
    }

    public static function oneTimeRecipientContext($message)
    {
        if (is_object($message) && method_exists($message, 'oneTimeRecipientContext')) {
            return $message->oneTimeRecipientContext();
        }

        $meta = is_object($message) && is_array($message->meta) ? $message->meta : [];
        $recipient = Arr::get($meta, 'one_time_recipient', []);

        return is_array($recipient) ? $recipient : [];
    }

    // NEW: generic accessor to get saved settings for any provider (including custom ones)
    public static function getProviderSettings($provider)
    {
        $all = self::getSettings();
        return $all[$provider] ?? [];
    }

    public static function getApiOptions()
    {
        // Build definitions from registered providers
        $provider_definitions = [];
        foreach (Providers\SMSDriverManager::getAll() as $slug => $provider) {
            $provider_definitions[$slug] = [
                'label'  => $provider->getLabel(),
                'fields' => $provider->getFields(),
            ];
        }

        // Build select options
        $provider_options = [];
        foreach ($provider_definitions as $key => $def) {
            $provider_options[$key] = $def['label'] ?? ucfirst(str_replace('_', ' ', $key));
        }

        $provider_select = [
            'type'    => 'select',
            'label'   => __('SMS Provider', 'fluentcampaign-pro'),
            'options' => $provider_options,
            'default' => array_key_first($provider_options) ?: '',
        ];

        if (empty($provider_select['default']) || !isset($provider_select['options'][$provider_select['default']])) {
            $first = array_key_first($provider_select['options'] ?? []);
            if ($first) {
                $provider_select['default'] = $first;
            }
        }

        return [
            'sms_providers' => $provider_select,
            'providers'     => $provider_definitions,
        ];
    }


    public static function verifyWebhookHash($hash, $provider, $url)
    {
        if (!$hash || !is_string($hash) || strlen($hash) < 16 || !$provider) {
            return false;
        }

        $hashInDb = fluentcrm_get_option(self::SMS_WEBHOOK_KEY_OPTION, '');

        if (!$hashInDb || !is_string($hashInDb)) {
            return false;
        }

        return hash_equals($hashInDb, $hash);
    }

    public static function getSMSWebhookUrl($provider, $create = false)
    {
        if (!$provider) {
            return '';
        }

        $key = fluentcrm_get_option(self::SMS_WEBHOOK_KEY_OPTION, '');
        if (!$key && $create) {
            $key = wp_generate_uuid4();
            fluentcrm_update_option(self::SMS_WEBHOOK_KEY_OPTION, $key);
        }

        return $key && is_string($key) ? add_query_arg([
            FLUENTCRM_EXTERNAL_URL_PARAM => '1',
            'route'                      => 'webhook',
            'handler'                    => 'sms_webhook',
            'provider'                   => $provider,
            'hash'                       => $key,
        ], site_url('/')) : '';
    }

    /**
     * Record a STOP on the number's conversation.
     *
     * Consent belongs to the thread, so this no longer needs a contact to have
     * somewhere to put the decision: a STOP from a number that is not in the CRM
     * is honoured instead of dropped. The confirmation reply and the hooks still
     * need a contact and are skipped without one.
     */
    public static function optOut($phone, $data = [])
    {
        if (!$phone) {
            return false;
        }

        $subscriber = Subscriber::where('phone', $phone)->first();

        if (!MessageThread::setConsent('sms', $phone, MessageThread::STATUS_UNSUBSCRIBED, $subscriber ? $subscriber->id : null)) {
            return false;
        }

        if ($subscriber) {
            // Twilio already sends its own compliance reply for STOP/START keywords,
            // so we only queue an extra confirmation SMS for other providers.
            if (($data['provider'] ?? '') !== 'twilio') {
                self::queueStatusConfirmationMessage($subscriber, 'opt_out', $data);
            }

            do_action('fluent_crm/contact_sms_unsubscribed', $subscriber, $data);
        }

        return true;
    }

    public static function optIn($phone, $data = [])
    {
        if (!$phone) {
            return false;
        }

        $subscriber = Subscriber::where('phone', $phone)->first();

        if (!MessageThread::setConsent('sms', $phone, MessageThread::STATUS_SUBSCRIBED, $subscriber ? $subscriber->id : null)) {
            return false;
        }

        if ($subscriber) {
            // Twilio already sends its own compliance reply for STOP/START keywords,
            // so we only queue an extra confirmation SMS for other providers.
            if (($data['provider'] ?? '') !== 'twilio') {
                self::queueStatusConfirmationMessage($subscriber, 'opt_in', $data);
            }

            do_action('fluent_crm/contact_sms_subscribed', $subscriber, $data);
        }

        return true;
    }

    /**
     * `ref_type` for an automated opt-in/opt-out confirmation.
     *
     * A distinct value rather than 'custom' so the retry dedupe below can scope
     * its search to confirmations instead of scanning every outbound message the
     * contact has ever had.
     */
    const CONFIRMATION_REF_TYPE = 'status_confirmation';

    protected static function queueStatusConfirmationMessage($subscriber, $event, $data = [])
    {
        global $wpdb;

        /*
        * We are not doing this for Twilio because they already send their own compliance messages for STOP/START keywords,
        * so we don't want to duplicate them. For other providers, we send a confirmation message to the subscriber after they opt-in or opt-out.
        */
        if(($data['provider'] ?? '') === 'twilio') { // extra safety check to prevent duplicate messages in case the optIn/optOut methods are called directly without the provider context
            return false;
        }

        if (!$subscriber || !$subscriber->phone) {
            return false;
        }

        $incomingMessageSid = $data['MessageSid'] ?? $data['SmsSid'] ?? $data['SmsMessageSid'] ?? '';
        $note = $event === 'opt_out' ? 'sms opt-out confirmation' : 'sms opt-in confirmation';

        // Twilio can retry the same inbound webhook. The inbound MessageSid is
        // stored in the outgoing confirmation's meta below and matched here so a
        // retry does not queue a second confirmation.
        //
        // Still a LIKE over the serialized blob rather than an indexed lookup:
        // `provider_message_id` on the outgoing row belongs to the *outgoing*
        // message and is stamped by the provider at send time, so it cannot also
        // carry the inbound SID. A dedicated column would be the fix, and adding
        // one needs sign-off.
        if ($incomingMessageSid) {
            $existingMessage = Message::where('ref_type', self::CONFIRMATION_REF_TYPE)
                ->where('meta', 'like', '%' . $wpdb->esc_like($incomingMessageSid) . '%')
                ->whereHas('thread', function ($query) use ($subscriber) {
                    $query->where('contact_id', $subscriber->id);
                })
                ->first();

            if ($existingMessage) {
                return $existingMessage;
            }
        }

        if ($event === 'opt_out') {
            $messageContent = __('You have been unsubscribed. Reply START to resubscribe.', 'fluentcampaign-pro');
            $messageContent = apply_filters('fluent_crm/sms_opt_out_confirmation_message', $messageContent, $subscriber, $data);
        } else {
            $messageContent = __('You have been subscribed. Reply STOP to unsubscribe.', 'fluentcampaign-pro');
            $messageContent = apply_filters('fluent_crm/sms_opt_in_confirmation_message', $messageContent, $subscriber, $data);
        }

        if (!$messageContent) {
            return false;
        }

        $smsMessage = MessageThread::queueOutbound(
            LegacyMessage::CHANNEL_SMS,
            $subscriber->phone,
            $subscriber->id,
            $messageContent,
            [
                'ref_type' => self::CONFIRMATION_REF_TYPE,
                // Keep the inbound webhook metadata with the outgoing
                // confirmation so we can trace which STOP/START message
                // triggered this queued SMS — and so the retry dedupe above has
                // something to match on.
                'meta'     => [
                    'notes'                => $note,
                    'provider'             => $data['provider'] ?? (self::getCurrentProvider() ?: 'unknown'),
                    'event'                => $event,
                    'incoming_message_sid' => $incomingMessageSid,
                ]
            ]
        );

        if (!$smsMessage) {
            return false;
        }

        // Through the shared dispatcher, not a hand-rolled schedule: this used
        // to duplicate its queued branch, which meant an opt-out confirmation
        // skipped the inline path and the send-timeout cap that every other
        // caller gets.
        MessageScheduler::dispatch($smsMessage->id);

        return $smsMessage;
    }

    public static function processIncomingMessage($from, $to, $body, $data = [])
    {
        if (!$from || !$to || !$body) {
            return false;
        }

        // May be null: anyone can text the business number, and most of them are
        // not contacts yet. The message is stored either way — dropping it loses
        // the only record the conversation happened, and `subscriber_id` is
        // nullable precisely so this can be recorded.
        $subscriber = Subscriber::where('phone', $from)->first();

        $providerMessageId = $data['MessageSid'] ?? $data['SmsSid'] ?? $data['SmsMessageSid'] ?? '';

        // Twilio may retry inbound webhooks, so reuse the existing record when we already
        // saved this incoming message SID instead of creating a duplicate activity entry.
        // Scoped by channel: the SID spaces of the two channels are not shared.
        if ($providerMessageId && \FluentCampaign\App\Modules\Messaging\Models\MessageThread::hasProviderMessage($providerMessageId, 'sms')) {
            return true;
        }

        // Threads are the store now; fc_sms_messages is retired and kept only as
        // a migration source. The contact's number is the webhook's `From` —
        // `$to` is the business line and is identical on every inbound row.
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::findOrCreateFor('sms', $from, [
            'contact_id'   => $subscriber ? $subscriber->id : null,
            'initiated_by' => 'user'
        ]);

        if (!$thread) {
            return false;
        }

        // recordMessage, not a bare insert: the thread's rail order and unread
        // badge have to move with the message.
        $thread->recordMessage([
            'direction'           => 'inbound',
            'content'             => $body,
            'provider_message_id' => $providerMessageId ?: null,
            'ref_type'            => 'incoming',
            'status'              => 'received',
            'meta'                => [
                'settings' => [
                    'from'     => $from,
                    'to'       => $to,
                    'provider' => $data['provider'] ?? 'unknown',
                ]
            ]
        ]);

        return true;
    }

    /**
     * Parse SMS message content with subscriber data.
     *
     * SMS intentionally uses the same shared smartcode parser as email
     * content so contact fields, contact custom fields, CRM values, WP values,
     * and extension-provided smartcode groups resolve from one source of truth.
     * Do not reintroduce a separate SMS allowlist here unless the picker and
     * parser behavior are also updated together.
     *
     * Some CRM link smartcodes are deferred by the shared parser because email
     * templates replace them later in the email pipeline. SMS does not pass
     * through that email-only step, so this method resolves those deferred CRM
     * smartcodes and then converts the final output to plain text before send.
     *
     * @param string $content
     * @param \FluentCrm\App\Models\Subscriber $subscriber
     * @return string
     */
    public static function parseMessageContent($content, $subscriber)
    {
        // Keep SMS aligned with the shared parser instead of maintaining a separate allowlist.
        $content = Parser::parse((string)$content, $subscriber);
        $content = self::parseDeferredCrmSmartCodes($content, $subscriber);
        $content = apply_filters('fluent_crm/parse_sms_smartcode', $content, $subscriber);

        return self::sanitizeParsedMessageContent($content);
    }

    /**
     * Resolve CRM link smartcodes that are intentionally deferred by Parser::parse().
     *
     * The shared parser returns unsubscribe/manage-subscription smartcodes as
     * placeholders because email rendering handles those links at a later stage.
     * SMS messages are sent directly after SMSHelper::parseMessageContent(), so
     * without this pass a user could insert a CRM link smartcode from the SMS
     * picker and still send the raw placeholder to the contact.
     *
     * This method only targets the deferred CRM link codes and leaves all other
     * already-parsed content untouched.
     *
     * @param string $content
     * @param \FluentCrm\App\Models\Subscriber $subscriber
     * @return string
     */
    protected static function parseDeferredCrmSmartCodes($content, $subscriber)
    {
        if (!$subscriber instanceof Subscriber) {
            return $content;
        }

        return preg_replace_callback(
            '/({{|##)\s*crm\.(unsubscribe_url|manage_subscription_url|unsubscribe_html|manage_subscription_html)(.*?)\s*(}}|##)/',
            function ($matches) use ($subscriber) {
                // The shared parser defers these email link codes; SMS needs the resolved text/link.
                return Parser::parseCrmValue($matches[0], $subscriber);
            },
            $content
        );
    }

    /**
     * Normalize parsed smartcode output for plain-text SMS delivery.
     *
     * The shared parser may return HTML for some email-oriented smartcodes,
     * especially CRM hyperlink codes. SMS providers expect text, so links are
     * converted to "Label (url)", line-breaking HTML tags are preserved as
     * newlines, and remaining HTML is stripped. Any unresolved smartcode
     * placeholders are removed as a final safety net to avoid sending raw
     * merge-code syntax to contacts.
     *
     * @param string $content
     * @return string
     */
    protected static function sanitizeParsedMessageContent($content)
    {
        // Preserve link destinations after HTML is stripped for plain-text SMS delivery.
        $content = preg_replace_callback(
            '/<a[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is',
            function ($matches) {
                $url = trim($matches[1]);
                $label = trim(wp_strip_all_tags($matches[2]));

                if ($label === '' || $label === $url) {
                    return $url;
                }

                return $label . ' (' . $url . ')';
            },
            (string)$content
        );

        $content = preg_replace('/<\s*br\s*\/?>/i', "\n", $content);
        $content = preg_replace('/<\/(p|div|li|h[1-6]|tr)>/i', "\n", $content);
        $content = wp_strip_all_tags($content);
        $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
        $content = preg_replace('/({{|##).*?(}}|##)/', '', $content);
        $content = preg_replace('/[ \t\x{00A0}]+/u', ' ', $content);
        $content = preg_replace("/[ \t]*\n[ \t]*/", "\n", $content);
        $content = preg_replace("/\n{3,}/", "\n\n", $content);

        return trim($content);
    }
}
