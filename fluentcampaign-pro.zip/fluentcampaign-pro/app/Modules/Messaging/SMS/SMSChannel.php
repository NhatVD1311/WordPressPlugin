<?php

namespace FluentCampaign\App\Modules\Messaging\SMS;

use FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCampaign\App\Modules\Messaging\SMS\SMSSender;

/**
 * The SMS channel. A thin adapter over SMSHelper/SMSSender so the kernel can
 * treat SMS and WhatsApp uniformly; all behaviour still lives in those classes.
 */
class SMSChannel implements ChannelInterface
{
    // Longest body accepted before the composer stops the user. 1600 characters
    // is 10 concatenated GSM-7 segments, the practical carrier ceiling.
    const MAX_LENGTH = 1600;

    public function getSlug(): string
    {
        return LegacyMessage::CHANNEL_SMS;
    }

    public function getLabel(): string
    {
        return 'SMS';
    }

    public function isActive(): bool
    {
        return SMSHelper::isActive();
    }

    public function getMaxLength(): int
    {
        return self::MAX_LENGTH;
    }

    public function parseMessageContent(string $content, $subscriber): string
    {
        return SMSHelper::parseMessageContent($content, $subscriber);
    }

    public function send(string $to, string $message, ?string $provider = null): array
    {
        $result = SMSSender::send($to, $message, $provider);

        // SMSSender returns false when the channel is inactive; normalise so
        // callers only ever handle the array shape.
        if (!is_array($result)) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => 'SMS module is not active',
                'response'    => null,
            ];
        }

        return $result;
    }

    /**
     * SMS has exactly one message form, so a queued send is render + send.
     */
    public function sendQueued($message, $subscriber, string $to): array
    {
        $body = SMSHelper::applyRecipientSmartCodes((string) $message->content, $message);
        $body = $subscriber
            ? $this->parseMessageContent($body, $subscriber)
            : SMSHelper::stripUnresolvedSmartCodes(wp_strip_all_tags($body));

        return $this->send($to, $body);
    }

    public function getMenuItems(string $urlBase): array
    {
        return [
            [
                'key'         => 'sms_campaigns',
                'label'       => __('SMS Campaigns', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/sms/campaigns',
                'description' => __('Deliver SMS campaigns to specific subscribers based on tags, lists, or segments', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.125 13.125C8.125 13.125 12.5 13.75 14.375 15.625H15C15.3452 15.625 15.625 15.3452 15.625 15V11.2106C16.1641 11.0719 16.5625 10.5824 16.5625 10C16.5625 9.41756 16.1641 8.92812 15.625 8.78937V5C15.625 4.65482 15.3452 4.375 15 4.375H14.375C12.5 6.25 8.125 6.875 8.125 6.875H5.625C4.93464 6.875 4.375 7.43464 4.375 8.125V11.875C4.375 12.5654 4.93464 13.125 5.625 13.125H6.25L6.875 16.25H8.125V13.125ZM9.375 7.91325C9.80206 7.82162 10.3297 7.69496 10.8996 7.52733C11.9484 7.21884 13.2812 6.73289 14.375 5.98411V14.0159C13.2812 13.2671 11.9484 12.7812 10.8996 12.4727C10.3297 12.3051 9.80206 12.1784 9.375 12.0868V7.91325ZM5.625 8.125H8.125V11.875H5.625V8.125Z" fill="#525866"/>
                            </svg>'
            ],
        ];
    }

    /**
     * SMS has no channel-specific hooks; the fluent_crm/sms_sent action
     * is fired by the scheduler for every channel.
     */
    public function onSent($message, array $result): void
    {
    }

    public function onFailed($message, string $error): void
    {
    }
}
