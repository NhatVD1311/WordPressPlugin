<?php

namespace FluentCampaign\App\Modules\Messaging\SMS\Providers;

use FluentCampaign\App\Modules\Messaging\Contracts\AbstractDriver;

/**
 * Base class for SMS provider drivers.
 *
 * The settings-field contract and the cURL helper live in AbstractDriver, which
 * is shared with WhatsApp. This class adds SMS-specific registration.
 *
 * Third-party usage:
 *
 *   add_action('fluent_crm/register_sms_providers', function () {
 *       new MyCustomSMSDriver();
 *   });
 *
 * @see AbstractDriver for the abstract methods a driver must implement.
 */
abstract class AbstractSMSDriver extends AbstractDriver
{
    /**
     * Instantiating a driver automatically registers it with the SMS manager.
     */
    public function __construct()
    {
        SMSDriverManager::register($this);
    }

    /**
     * Whether this provider can receive incoming SMS via webhook.
     * When true, a webhook URL is auto-created when settings are saved.
     */
    public function hasWebhook(): bool
    {
        return false;
    }

    protected function getSuccessMessage(): string
    {
        return 'SMS sent successfully';
    }
}
