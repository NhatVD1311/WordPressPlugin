<?php

namespace FluentCampaign\App\Services\Funnel\Actions;

use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateProviderScope;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateRenderer;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;

class SendCustomWhatsAppAction extends BaseAction
{
    public function __construct()
    {
        $this->actionName = 'send_custom_whatsapp';
        $this->priority   = 21;
        parent::__construct();

        add_filter('fluentcrm_ajax_options_whatsapp_templates', [$this, 'getTemplateOptions'], 10, 3);
        add_filter('fluentcrm_funnel_sequence_saving_' . $this->actionName, [$this, 'savingAction'], 10, 2);
    }

    public function getBlock(): array
    {
        return [
            'category'    => __('Messaging', 'fluentcampaign-pro'),
            'title'       => __('Send a WhatsApp Message', 'fluentcampaign-pro'),
            'description' => __('Send a WhatsApp message to the subscriber or a custom number', 'fluentcampaign-pro'),
            'icon'        => 'el-icon-chat-dot-round',
            'settings'    => [
                'send_to_type'       => 'contact',
                'send_to_custom'     => '',
                'message_type'       => 'template',
                'template_id'        => '',
                'template_variables' => [
                    [
                        'data_key'   => '1',
                        'data_value' => ''
                    ]
                ],
                'message_body'       => '',
            ],
        ];
    }

    public function getBlockFields(): array
    {
        return [
            'title'     => __('Send a WhatsApp Message', 'fluentcampaign-pro'),
            'sub_title' => __('Configure the WhatsApp message to send', 'fluentcampaign-pro'),
            'fields'    => [
                'send_to_type'         => [
                    'type'          => 'radio',
                    'wrapper_class' => 'fc_half_field',
                    'label'         => __('Send WhatsApp to', 'fluentcampaign-pro'),
                    'options'       => [
                        [
                            'id'    => 'contact',
                            'title' => __("Send to the contact's phone number", 'fluentcampaign-pro'),
                        ],
                        [
                            'id'    => 'custom',
                            'title' => __('Send to a custom number', 'fluentcampaign-pro'),
                        ],
                    ],
                ],
                'send_to_custom'       => [
                    'wrapper_class' => 'fc_half_field',
                    'type'          => 'input-text',
                    'label'         => __('Custom Phone Number', 'fluentcampaign-pro'),
                    'placeholder'   => __('e.g. +12125551234', 'fluentcampaign-pro'),
                    'dependency'    => [
                        'depends_on' => 'send_to_type',
                        'operator'   => '=',
                        'value'      => 'custom',
                    ],
                ],
                'message_type'         => [
                    'type'    => 'radio',
                    'label'   => __('Message Type', 'fluentcampaign-pro'),
                    'options' => [
                        [
                            'id'    => 'template',
                            'title' => __('Use an approved template', 'fluentcampaign-pro'),
                        ],
                        [
                            'id'    => 'custom',
                            'title' => __('Write a custom message', 'fluentcampaign-pro'),
                        ],
                    ],
                ],
                'template_id'          => [
                    'type'        => 'rest_selector',
                    'option_key'  => 'whatsapp_templates',
                    'is_multiple' => false,
                    'clearable'   => true,
                    'label'       => __('Select Template', 'fluentcampaign-pro'),
                    'placeholder' => __('Select an approved WhatsApp template', 'fluentcampaign-pro'),
                    'inline_help' => __('Only templates this automation can actually send are listed: APPROVED, belonging to the current WhatsApp provider, and without a header variable or dynamic URL button.', 'fluentcampaign-pro'),
                    'dependency'  => [
                        'depends_on' => 'message_type',
                        'operator'   => '=',
                        'value'      => 'template',
                    ],
                ],
                'template_variables'   => [
                    'type'                   => 'text-value-multi-properties',
                    'label'                  => __('Template Variables', 'fluentcampaign-pro'),
                    'data_key_label'         => __('Position', 'fluentcampaign-pro'),
                    'data_value_label'       => __('Value', 'fluentcampaign-pro'),
                    'data_key_placeholder'   => __('e.g. 1', 'fluentcampaign-pro'),
                    'data_value_placeholder' => __('e.g. {{contact.first_name|there}}', 'fluentcampaign-pro'),
                    'value_input_type'       => 'text-popper',
                    'help'                   => __('Map each {{n}} placeholder in the template body to a smart tag. Every placeholder must be mapped and must render a non-empty value, so use a fallback like {{contact.first_name|there}}.', 'fluentcampaign-pro'),
                    'dependency'             => [
                        'depends_on' => 'message_type',
                        'operator'   => '=',
                        'value'      => 'template',
                    ],
                ],
                'message_body'         => [
                    'type'        => 'input-text-area',
                    'field_type'  => 'textarea',
                    'rows'        => 4,
                    'label'       => __('Message Body', 'fluentcampaign-pro'),
                    'placeholder' => __('Your WhatsApp message here...', 'fluentcampaign-pro'),
                    // '!= template' rather than '= custom' so blocks saved before
                    // message_type existed — where it is undefined — still show
                    // their body field. handle() defaults those to custom too.
                    'dependency'  => [
                        'depends_on' => 'message_type',
                        'operator'   => '!=',
                        'value'      => 'template',
                    ],
                ],
                'custom_message_note'  => [
                    'type'       => 'html',
                    'info'       => __('<b>WhatsApp 24-hour window:</b> a custom (free-form) message is only delivered if the contact has messaged you within the last 24 hours. Outside that window Meta rejects free-form sends (error 131047) and the message is marked failed — the first message to a contact must always be an approved template. Use a custom message only for replies inside an open conversation.', 'fluentcampaign-pro'),
                    'dependency' => [
                        'depends_on' => 'message_type',
                        'operator'   => '!=',
                        'value'      => 'template',
                    ],
                ],
                'template_note'        => [
                    'type'       => 'html',
                    'info'       => __('<b>Templates</b> are pre-approved by Meta and can be sent at any time, including as the first message to a contact. Sync and submit templates from FluentCRM &rarr; Messaging &rarr; WhatsApp Templates. Templates with header variables or dynamic URL buttons are not supported here yet.', 'fluentcampaign-pro'),
                    'dependency' => [
                        'depends_on' => 'message_type',
                        'operator'   => '=',
                        'value'      => 'template',
                    ],
                ],
            ],
        ];
    }

    /**
     * Options for the template selector.
     *
     * Every constraint the send path applies is applied here, so a template the
     * selector offers is a template resolveSendMode()/TemplateRenderer will
     * accept: current provider, APPROVED, and no header variable or dynamic URL
     * button. Anything looser turns the selector into a way to configure an
     * automation that can only fail once it reaches the queue.
     */
    public function getTemplateOptions($options, $search = '', $includedIds = [])
    {
        $currentProvider = WhatsAppHelper::getCurrentProvider();

        if (!$currentProvider) {
            return [];
        }

        $query = $this->sendableTemplateQuery($currentProvider);

        if ($search) {
            global $wpdb;
            // Escape LIKE wildcards so the term matches literally.
            $query->where('name', 'LIKE', '%' . $wpdb->esc_like($search) . '%');
        }

        $formatted = [];
        $pushedIds = [];

        foreach ($query->orderBy('name', 'ASC')->limit(50)->get() as $template) {
            if (TemplateRenderer::getUnsupportedReason($template)) {
                continue;
            }

            $formatted[] = $this->formatTemplateOption($template);
            $pushedIds[] = $template->id;
        }

        // The selector re-fetches on mount with the saved value, so a still-valid
        // template beyond the limit (or outside the search) must resolve, or the
        // field renders a bare id. It goes through the same constraints: a saved
        // template that has since been paused, had its provider switched, or
        // gained a header variable is no longer offered, which is what stops it
        // being re-confirmed on the next save.
        $includedIds = array_diff(array_filter(array_map('intval', (array) $includedIds)), $pushedIds);

        if ($includedIds) {
            $missing = $this->sendableTemplateQuery($currentProvider)
                ->whereIn('id', $includedIds)
                ->get();

            foreach ($missing as $template) {
                if (TemplateRenderer::getUnsupportedReason($template)) {
                    continue;
                }

                $formatted[] = $this->formatTemplateOption($template);
            }
        }

        return $formatted;
    }

    /**
     * The constraints resolveSendMode() enforces, as a query.
     *
     * The unsupported-placement rule cannot be expressed in SQL and is applied
     * to the results by callers via TemplateRenderer::getUnsupportedReason().
     */
    protected function sendableTemplateQuery(string $currentProvider)
    {
        return MessageTemplate::forChannel(LegacyMessage::CHANNEL_WHATSAPP)
            ->approved()
            ->where('provider', $currentProvider);
    }

    protected function formatTemplateOption($template): array
    {
        return [
            'id'    => (string) $template->id,
            'title' => $template->name . ' (' . $template->language . ')',
        ];
    }

    /**
     * Reject a template configuration the queue could only fail on.
     *
     * The selector already refuses to offer an unusable template, but that is UI
     * state: a template can be paused, re-provisioned or edited between being
     * picked and the automation being saved, and the settings arrive over REST
     * regardless of what the selector showed. This is the check that actually
     * holds — FunnelController::saveSequences() catches the exception and
     * returns it as a 422, so the admin sees the reason in the editor instead of
     * discovering it in a failed message row days later.
     *
     * A template that does not exist here at all is cleared rather than
     * rejected. That is the import case: template ids are site-local, so a
     * funnel exported from another install always carries ids that mean nothing
     * here, and createFunnelFromData() has no try/catch to turn a throw into a
     * readable error. Clearing lands the automation in the editor with an empty
     * selector — visibly unconfigured, which is the honest state — while a
     * template that does exist and is unusable still throws.
     *
     * @throws \Exception
     */
    public function savingAction($sequence, $funnel)
    {
        $settings = Arr::get($sequence, 'settings', []);

        if (Arr::get($settings, 'message_type') !== 'template') {
            return $sequence;
        }

        $templateId = (int) Arr::get($settings, 'template_id');

        // Nothing picked yet is a half-built block, not a broken one: handle()
        // queues nothing for it, so there is no failing message to prevent, and
        // refusing the save would stop an admin parking an automation to finish
        // later. It is reported as a skip at runtime instead.
        if (!$templateId) {
            return $sequence;
        }

        $template = MessageTemplate::forChannel(LegacyMessage::CHANNEL_WHATSAPP)->find($templateId);

        if (!$template) {
            $sequence['settings']['template_id'] = '';

            return $sequence;
        }

        $currentProvider = WhatsAppHelper::getCurrentProvider();

        if (!TemplateProviderScope::isCurrentProvider((string) $template->provider, $currentProvider)) {
            throw new \Exception(
                esc_html(
                    sprintf(
                    /* translators: %s: template name */
                        __('Template "%s" belongs to a different WhatsApp provider than the one configured, so it cannot be sent. Pick a template for the current provider.', 'fluentcampaign-pro'),
                        $template->name
                    )
                )
            );
        }

        if ($template->status !== MessageTemplate::STATUS_APPROVED) {
            throw new \Exception(
                esc_html(
                    sprintf(
                    /* translators: 1: template name, 2: template status */
                        __('Template "%1$s" is %2$s, not APPROVED, so Meta would reject it. Re-sync templates or pick an approved one.', 'fluentcampaign-pro'),
                        $template->name,
                        $template->status
                    )
                )
            );
        }

        if ($unsupported = TemplateRenderer::getUnsupportedReason($template)) {
            throw new \Exception(esc_html($unsupported));
        }

        // Every {{n}} in the body must have a mapping or TemplateRenderer refuses
        // the send for every contact. Only presence is checkable here — whether a
        // mapping renders non-empty depends on the contact.
        $mapped  = $this->formatTemplateVariables(Arr::get($settings, 'template_variables', []));
        $missing = [];

        foreach ($template->getVariablePositions() as $position) {
            if (!isset($mapped[(string) $position])) {
                $missing[] = '{{' . $position . '}}';
            }
        }

        if ($missing) {
            throw new \Exception(
                esc_html(
                    sprintf(
                    /* translators: 1: template name, 2: comma-separated variable placeholders */
                        __('Template "%1$s" has unmapped variables: %2$s. Map every variable before saving.', 'fluentcampaign-pro'),
                        $template->name,
                        implode(', ', $missing)
                    )
                )
            );
        }

        return $sequence;
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric): void
    {
        $data       = $sequence->settings;
        $sendToType = Arr::get($data, 'send_to_type');

        if ($sendToType === 'custom') {
            $phoneNumber = Arr::get($data, 'send_to_custom');
        } else {
            $phoneNumber = $subscriber->phone;
        }

        if (!$phoneNumber) {
            return;
        }

        // Skip non-custom sends if the contact has not opted in to WhatsApp
        if (
            $sendToType !== 'custom' &&
            !MessageThread::contactCanReceive('whatsapp', $subscriber->id)
        ) {
            return;
        }

        // Legacy automations created before the template option have no
        // message_type; they were always free-form, so default to that.
        $messageType = Arr::get($data, 'message_type', 'custom');
        $body        = (string) Arr::get($data, 'message_body', '');
        $templateId  = 0;
        $settings    = [];

        if ($messageType === 'template') {
            $templateId = (int) Arr::get($data, 'template_id');

            if (!$templateId) {
                $funnelMetric->notes = __('Skipped because no WhatsApp template is selected for this action.', 'fluentcampaign-pro');
                $funnelMetric->save();
                FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');

                return;
            }

            // The channel renders the map at send time, so it only needs to be
            // stored in the shape TemplateRenderer expects: position => smartcode.
            $variables = $this->formatTemplateVariables(Arr::get($data, 'template_variables', []));

            if ($variables) {
                $settings['template_variables'] = $variables;
            }

            // Cosmetic only: the message log shows message_content, and a blank
            // row is unreadable. The channel resolves and validates the template
            // itself at send time, so a miss here is not worth blocking on.
            $template = MessageTemplate::forChannel(LegacyMessage::CHANNEL_WHATSAPP)->find($templateId);
            $body     = $template ? (string) $template->body_text : '';
        } elseif (!$body) {
            return;
        }

        // Written to the contact's WhatsApp thread and sent in this request. The
        // template id and the variable map go in `meta` — fc_messages has no
        // column for either, and the channel reads them back from there when it
        // resolves the send mode.
        MessageScheduler::sendNow(
            LegacyMessage::CHANNEL_WHATSAPP,
            $phoneNumber,
            $subscriber->id,
            $body,
            [
                'ref_type'    => Message::REF_AUTOMATION,
                'template_id' => $templateId ?: null,
                'meta'        => array_filter([
                    'settings'             => $settings ?: null,
                    'funnel_subscriber_id' => (int) $funnelSubscriberId
                ])
            ]
        );
    }

    /**
     * Turn the editor's key/value rows into TemplateRenderer's position map.
     *
     * @return array<string, string>
     */
    protected function formatTemplateVariables($pairs): array
    {
        $map = [];

        foreach ((array) $pairs as $pair) {
            $position = (int) Arr::get($pair, 'data_key');
            $value    = trim((string) Arr::get($pair, 'data_value'));

            if ($position < 1 || $value === '') {
                continue;
            }

            $map[(string) $position] = $value;
        }

        return $map;
    }
}
