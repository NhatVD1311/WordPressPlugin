/**
 * Frontend scripts.
 */
