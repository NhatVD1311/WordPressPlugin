<?php
/**
 * SureForms Pro Save and Resume Database Table Class.
 *
 * @link       https://sureforms.com
 * @since      2.2.0
 * @package    sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Database\Tables;

use SRFM\Inc\Database\Base;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * SureForms Pro Save and Resume Database Table Class.
 *
 * @since 2.2.0
 */
class Save_Resume extends Base {
	use Get_Instance;

	/**
	 * Allowed trigger sources for a partial-entry save.
	 *
	 * @since 2.9.0
	 */
	public const ALLOWED_TRIGGERS = [ 'heartbeat', 'pagebreak', 'input', 'pagehide', 'saved', 'interval' ];

	/**
	 * `capture_source` of a row captured automatically while the visitor fills the form.
	 *
	 * @since 2.12.9
	 */
	public const SOURCE_AUTOMATIC = 'automatic';

	/**
	 * `capture_source` of a row the visitor saved deliberately through Save & Resume.
	 *
	 * @since 2.12.9
	 */
	public const SOURCE_SAVE_RESUME = 'save_resume';

	/**
	 * How many times a lifecycle merge re-reads and retries after losing its
	 * compare-and-set. Three covers a collision with an autosave and its immediate
	 * resend; beyond that the caller is better off reporting failure than looping.
	 *
	 * @since 2.12.9
	 */
	public const PATCH_LIFECYCLE_ATTEMPTS = 3;

	/**
	 * Rows classified per statement by the v13 backfill.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_BATCH_SIZE = 1000;

	/**
	 * Most statements one backfill pass will run. With BACKFILL_BATCH_SIZE it bounds
	 * the work a single upgrade request takes on; what is left is finished by the next
	 * pass, because the version is not recorded until the backfill reports done.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_MAX_BATCHES = 50;

	/**
	 * What one backfill pass achieved. Only BACKFILL_INCOMPLETE holds the stored table
	 * version back: a missing column means the ALTER failed, and a pass that keeps
	 * failing is not made better by running it on every request for ever.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_DONE       = 'done';
	public const BACKFILL_INCOMPLETE = 'incomplete';
	public const BACKFILL_NO_COLUMNS = 'missing_columns';
	public const BACKFILL_FAILED     = 'failed';

	/**
	 * Option holding the backfill's `partial_entry_id` cursor and consecutive failures.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_PROGRESS_OPTION = 'srfm_pe_backfill_progress';

	/**
	 * Option set once every row has been classified, and the hook that drives the pass
	 * until then. The table version is no longer held back for the backfill, so this is
	 * what says whether there is still work to do.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_DONE_OPTION = 'srfm_pe_backfill_done';
	public const BACKFILL_CRON_HOOK   = 'srfm_pe_backfill';

	/**
	 * Option used as the backfill's mutex, and how long a claim on it is honoured
	 * before another request may assume the holder died mid-pass.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_LOCK_OPTION = 'srfm_pe_backfill_lock';
	public const BACKFILL_LOCK_TTL    = 300;

	/**
	 * Consecutive failed passes after which the backfill stops holding the version.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_MAX_FAILURES = 5;

	/**
	 * Longest wait between passes after a failure, and the base the backoff doubles
	 * from. Failures are no longer a simple strike count: a lock-wait timeout during a
	 * traffic spike could reach five within a few admin clicks and strand the table for
	 * good. Five failures now have to be spread over roughly a day before the pass gives
	 * up, and each one buys the site some quiet first.
	 *
	 * @since 2.12.9
	 */
	public const BACKFILL_RETRY_BASE = 60;
	public const BACKFILL_RETRY_MAX  = 3600;

	/**
	 * Lifecycle states. A row with an empty state predates the lifecycle columns.
	 *
	 * @since 2.12.9
	 */
	public const STATE_IN_PROGRESS = 'in_progress';
	public const STATE_ABANDONED   = 'abandoned';
	public const STATE_SAVED       = 'saved';
	public const STATE_SUBMITTED   = 'submitted';

	/**
	 * States a visitor save may still write to. Every other state is terminal for writes.
	 *
	 * @since 2.12.9
	 */
	public const WRITABLE_STATES = [ self::STATE_IN_PROGRESS, self::STATE_ABANDONED, self::STATE_SAVED ];

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	protected $table_suffix = 'draft_submissions';

	/**
	 * {@inheritDoc}
	 *
	 * @var int
	 */
	protected $table_version = 14;

	/**
	 * Column names the table really has, read once per request.
	 *
	 * @var array<string,array<string,mixed>>|null
	 * @since 2.12.9
	 */
	private $live_columns = null;

	/**
	 * {@inheritDoc}
	 */
	public function get_schema() {
		return [
			// Unique identifier for each draft.
			'id'                 => [
				'type' => 'string',
			],
			// Sequential human-readable counter (1, 2, 3 …). Assigned by
			// MySQL via AUTO_INCREMENT — concurrent INSERTs never collide
			// (the previous MAX+1 read-then-write was racy). Acceptable
			// gap-on-delete tradeoff for an admin-facing display id.
			'partial_entry_id'   => [
				'type' => 'number',
			],
			// Email address if the user chooses to receive the resume link.
			'email'              => [
				'type' => 'string',
			],
			// When the draft was saved.
			'date_created'       => [
				'type' => 'datetime',
			],
			// IP address of the user.
			'ip'                 => [
				'type' => 'string',
			],
			// URL of the form.
			'source_url'         => [
				'type' => 'string',
			],
			// Identifier of the form.
			'form_id'            => [
				'type' => 'number',
			],
			// Serialized snapshot of form state.
			'form_data'          => [
				'type'    => 'array',
				'default' => [],
			],
			// Frontend session identifier (ties save+resume rows together).
			'session_id'         => [
				'type'    => 'string',
				'default' => '',
			],
			// Step/page the user was on when the entry was captured.
			'current_page'       => [
				'type'    => 'number',
				'default' => 0,
			],
			// 0-100 completion estimate shown in the admin list.
			'progress_percent'   => [
				'type'    => 'number',
				'default' => 0,
			],
			// What event caused the save (heartbeat, pagebreak, input, pagehide, saved).
			'last_trigger'       => [
				'type'    => 'string',
				'default' => 'saved',
			],
			// Admin notes stored as a JSON array.
			'notes'              => [
				'type'    => 'array',
				'default' => [],
			],
			// Last time the row was touched (auto-updated by MySQL).
			'updated_at'         => [
				'type' => 'datetime',
			],
			// When this row was last CLAIMED for a partial-entry notification.
			// NULL until the first claim. The notifier claims it conditionally —
			// either once ever, or once per throttle window — so this doubles as
			// the concurrency guard and the "last notified" record.
			'notified_at'        => [
				'type' => 'datetime',
			],
			// sha256( form_id | session_id ) for automatic captures; NULL for every row
			// written before v13 and for Save & Resume rows. UNIQUE, so two concurrent
			// first saves from one session cannot both insert.
			'capture_key'        => [
				'type' => 'string',
			],
			// SOURCE_AUTOMATIC or SOURCE_SAVE_RESUME.
			'capture_source'     => [
				'type'    => 'string',
				'default' => '',
			],
			// One of the STATE_* constants.
			'state'              => [
				'type'    => 'string',
				'default' => '',
			],
			// Last meaningful visitor activity (UTC). Admin work never touches it, unlike
			// updated_at, whose ON UPDATE clause moves on every write.
			'last_activity_at'   => [
				'type' => 'datetime',
			],
			// Server-side snapshot version, advanced by every accepted visitor write.
			'activity_version'   => [
				'type'    => 'number',
				'default' => 0,
			],
			// When an in-progress automatic capture becomes eligible to be marked abandoned (UTC).
			'abandon_after'      => [
				'type' => 'datetime',
			],
			'first_abandoned_at' => [
				'type' => 'datetime',
			],
			'abandoned_at'       => [
				'type' => 'datetime',
			],
			// Accepted entry this draft became. NULL on the no-store accepted path.
			'submitted_entry_id' => [
				'type' => 'number',
			],
			'submitted_at'       => [
				'type' => 'datetime',
			],
			// When the row is purged by the retention sweep (UTC). NULL = never swept.
			'expires_at'         => [
				'type' => 'datetime',
			],
			// Permission, recovery-link and failure metadata as JSON. See Lifecycle.
			'lifecycle'          => [
				'type'    => 'array',
				'default' => [],
			],
			// WP user who was logged in when the row was last written, 0 for a
			// logged-out visitor. Recorded from the session on the server, never
			// taken from the request body.
			//
			// Deliberately has no schema default. prepare_data() re-applies a default
			// for every key the caller left out, so declaring one here would reset the
			// user to 0 on any classic Save & Resume update that did not resend it.
			// The column's own DEFAULT 0 covers the insert.
			'user_id'            => [
				'type' => 'number',
			],
		];
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns_definition() {
		return [
			'id CHAR(36) NOT NULL',
			'partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT',
			'email VARCHAR(255)',
			'date_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP',
			'ip VARCHAR(45)',
			'source_url TEXT',
			'form_id BIGINT(20) UNSIGNED',
			'form_data LONGTEXT',
			'session_id VARCHAR(64) NOT NULL',
			'current_page SMALLINT UNSIGNED NOT NULL DEFAULT 0',
			'progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0',
			'last_trigger VARCHAR(20) NOT NULL',
			'notes LONGTEXT',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			// Nullable: NULL until the row is first claimed for notification.
			'notified_at DATETIME NULL DEFAULT NULL',
			'capture_key CHAR(64) NULL DEFAULT NULL',
			'capture_source VARCHAR(20) NULL DEFAULT NULL',
			'state VARCHAR(20) NULL DEFAULT NULL',
			'last_activity_at DATETIME NULL DEFAULT NULL',
			'activity_version INT UNSIGNED NOT NULL DEFAULT 0',
			'abandon_after DATETIME NULL DEFAULT NULL',
			'first_abandoned_at DATETIME NULL DEFAULT NULL',
			'abandoned_at DATETIME NULL DEFAULT NULL',
			'submitted_entry_id BIGINT(20) UNSIGNED NULL DEFAULT NULL',
			'submitted_at DATETIME NULL DEFAULT NULL',
			'expires_at DATETIME NULL DEFAULT NULL',
			'lifecycle LONGTEXT',
			'user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0',
			// AUTO_INCREMENT requires the column to be a key — make
			// partial_entry_id the PRIMARY KEY (so MySQL can mint sequential
			// values atomically) and demote `id` to a UNIQUE secondary key.
			'PRIMARY KEY (partial_entry_id)',
			'UNIQUE KEY uniq_id (id)',
			'UNIQUE KEY uniq_capture_key (capture_key)',
			'INDEX idx_session_form (session_id, form_id)',
			'INDEX idx_updated_at (updated_at)',
			'INDEX idx_trigger_updated (last_trigger, updated_at)',
			'INDEX idx_state_abandon (state, abandon_after)',
			'INDEX idx_expires (expires_at)',
		];
	}

	/**
	 * Column definitions for the DB upgrade path (ALTER TABLE ADD COLUMN).
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function get_new_columns_definition() {
		return [
			'session_id VARCHAR(64) NOT NULL AFTER form_data',
			'current_page SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER session_id',
			'progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER current_page',
			'last_trigger VARCHAR(20) NOT NULL AFTER progress_percent',
			'notes LONGTEXT AFTER last_trigger',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER notes',
			// v12: notification claim stamp for partial entries.
			// Plain ADD COLUMN (no accompanying index) so the ALTER converges on
			// every DB engine; the Base skips it when already present.
			'notified_at DATETIME NULL DEFAULT NULL AFTER updated_at',
			// v13: abandonment lifecycle. Every column is nullable or numerically
			// defaulted, so the ALTER is additive and existing rows keep working unchanged.
			// No definition may contain a quote: Base passes them through
			// $wpdb->prepare( '%1s' ), which escapes it into invalid SQL. capture_key is
			// NULL on every existing row, so its UNIQUE index cannot collide on upgrade.
			'capture_key CHAR(64) NULL DEFAULT NULL',
			'capture_source VARCHAR(20) NULL DEFAULT NULL',
			'state VARCHAR(20) NULL DEFAULT NULL',
			'last_activity_at DATETIME NULL DEFAULT NULL',
			'activity_version INT UNSIGNED NOT NULL DEFAULT 0',
			'abandon_after DATETIME NULL DEFAULT NULL',
			'first_abandoned_at DATETIME NULL DEFAULT NULL',
			'abandoned_at DATETIME NULL DEFAULT NULL',
			'submitted_entry_id BIGINT(20) UNSIGNED NULL DEFAULT NULL',
			'submitted_at DATETIME NULL DEFAULT NULL',
			'expires_at DATETIME NULL DEFAULT NULL',
			'lifecycle LONGTEXT',
			// v14: who was logged in. Defaulted rather than nullable so existing rows
			// read as 0 ("not recorded") instead of NULL, which the admin would have to
			// tell apart from a genuine logged-out capture.
			'user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0',
			'UNIQUE INDEX uniq_capture_key (capture_key)',
			'INDEX idx_state_abandon (state, abandon_after)',
			'INDEX idx_expires (expires_at)',
		];
	}

	/**
	 * {@inheritDoc}
	 *
	 * Migration to schema v10:
	 *   - Drop the legacy `partial_entry_id BIGINT DEFAULT 0` column
	 *     (added in v9 and never released) and re-add it as the
	 *     AUTO_INCREMENT primary key. The original MAX+1 read-then-
	 *     write pattern produced duplicate display IDs under
	 *     concurrent inserts; AUTO_INCREMENT eliminates the race.
	 *   - Demote `id` (UUID) to a UNIQUE secondary key.
	 *
	 * Idempotent — only runs if the column already exists with the
	 * old (non-AUTO_INCREMENT) shape.
	 *
	 * @param array<string> $new_columns Column / index definitions.
	 * @since 2.9.0
	 * @return int|bool
	 */
	public function maybe_add_new_columns( $new_columns = [] ) {
		$existing_columns = $this->get_columns();
		$table            = $this->get_tablename();

		if ( ! empty( $existing_columns ) ) {
			$pe_id_meta = $existing_columns['partial_entry_id'] ?? null;
			$extra_raw  = is_array( $pe_id_meta ) && isset( $pe_id_meta['Extra'] )
				? $pe_id_meta['Extra']
				: '';
			$is_auto    = is_string( $extra_raw ) && false !== stripos( $extra_raw, 'auto_increment' );

			// Internal table name — interpolation here is safe because
			// `$table` comes from `get_tablename()`, not user input.
			$table_safe = esc_sql( $table );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- one-shot schema migration with an esc_sql-escaped internal table name; no user input flows into these statements.
			if ( ! isset( $existing_columns['partial_entry_id'] ) ) {
				// Column was never present (fresh post-v10 install hitting
				// upgrade by accident) — backfill as AUTO_INCREMENT PK.
				$this->wpdb->query( "ALTER TABLE `{$table_safe}` DROP PRIMARY KEY, ADD COLUMN partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (partial_entry_id), ADD UNIQUE KEY uniq_id (id)" );
			} elseif ( ! $is_auto ) {
				// Column exists from v9 but lacks AUTO_INCREMENT.
				// Step 1 — backfill any existing rows whose
				// `partial_entry_id` is 0 / NULL (legacy default or
				// rows inserted before the MAX+1 logic existed) with
				// sequential values starting after the current MAX.
				// Without this, the AUTO_INCREMENT PRIMARY KEY ALTER
				// below fails with a duplicate-key error on duplicate
				// zeros and silently leaves the column unchanged —
				// the admin would keep seeing "Partial Entry #" with
				// no number after it.
				$max = (int) $this->wpdb->get_var( "SELECT COALESCE(MAX(partial_entry_id),0) FROM `{$table_safe}` WHERE partial_entry_id > 0" );

				// Initialise the rownum counter to the current MAX
				// so the backfill picks up where real values left off.
				$set_query = $this->wpdb->prepare( 'SET @srfm_pe_rownum := %d', $max );
				if ( is_string( $set_query ) ) {
					$this->wpdb->query( $set_query );
				}
				$this->wpdb->query( "UPDATE `{$table_safe}` SET partial_entry_id = ( @srfm_pe_rownum := @srfm_pe_rownum + 1 ) WHERE partial_entry_id = 0 OR partial_entry_id IS NULL ORDER BY date_created ASC, id ASC" );

				// Step 2 — drop the old PK on `id`, re-key on
				// `partial_entry_id`, and flip the column to
				// AUTO_INCREMENT. Now that every row has a unique
				// non-zero value the ALTER cannot collide.
				$this->wpdb->query( "ALTER TABLE `{$table_safe}` DROP PRIMARY KEY, MODIFY partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, ADD UNIQUE KEY uniq_id (id)" );
			}
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		}

		$result = parent::maybe_add_new_columns( $new_columns );

		// The ALTER above changes which columns exist, and a write later in this same
		// request would otherwise go on filtering against the pre-upgrade answer.
		$this->live_columns = null;

		// One pass now, then the scheduler takes over. The stored version is NOT held
		// back for the backfill any more: holding it meant every front-end request kept
		// re-running CREATE TABLE IF NOT EXISTS, three SHOW COLUMNS and a SHOW INDEX --
		// for ever, on a site with DISABLE_WP_CRON and few admin visits -- and the
		// 12-column ALTER still landed on whichever visitor arrived first. Every reader
		// already copes with an unclassified row (is_writable(), update_capture() and
		// mark_submitted() all handle a NULL state), so the classification can finish
		// in the background.
		$this->backfill_lifecycle_source();
		self::schedule_backfill();

		return $result;
	}

	/**
	 * Keep driving the v13 backfill until every legacy row is classified.
	 *
	 * Admin requests and an hourly cron event, never a visitor's page load. Called from
	 * the pro bootstrap, and again as soon as the ALTER lands.
	 *
	 * @since 2.12.9
	 * @return void
	 */
	public static function schedule_backfill() {
		if ( get_option( self::BACKFILL_DONE_OPTION ) ) {
			return;
		}

		add_action( 'admin_init', [ self::class, 'run_backfill_tick' ] );
		add_action( self::BACKFILL_CRON_HOOK, [ self::class, 'run_backfill_tick' ] );

		if ( ! wp_next_scheduled( self::BACKFILL_CRON_HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, 'hourly', self::BACKFILL_CRON_HOOK );
		}
	}

	/**
	 * Run one backfill pass and stop scheduling once there is nothing left to do.
	 *
	 * Returns nothing: this is an action callback, and WordPress discards whatever a
	 * callback hands back. Tests read the outcome from backfill_lifecycle_source() and
	 * from what this leaves behind -- the done flag and the cleared schedule.
	 *
	 * @since 2.12.9
	 * @return void
	 */
	public static function run_backfill_tick() {
		$status = self::get_instance()->backfill_lifecycle_source();

		if ( self::BACKFILL_DONE === $status || self::BACKFILL_FAILED === $status ) {
			wp_clear_scheduled_hook( self::BACKFILL_CRON_HOOK );
		}
	}

	/**
	 * Classify rows written before v13 so the lifecycle can tell them apart.
	 *
	 * Rows without a session are legacy Save & Resume drafts; rows the partial-entries
	 * button saved deliberately (`last_trigger = saved`) are saved drafts; the rest are
	 * automatic captures. Every classified row is left with `abandon_after` and
	 * `expires_at` NULL, so the inactivity scanner never picks it up (no reminder can be
	 * sent for data captured before visitor reminders existed) and the retention sweep
	 * never deletes it on upgrade.
	 *
	 * Restartable, and bounded three ways, because Register::init() reaches this on
	 * every request while the version is held back:
	 *
	 * - It runs in wp-admin and on cron only. A visitor's page load must not pay for a
	 *   migration, and both of those reach Register::init() often enough on a live site.
	 * - One pass at a time, through an option used as a mutex. Concurrent requests used
	 *   to run the same `ORDER BY … LIMIT` over the same first rows and wait on each
	 *   other's row locks -- and visitors' captures to this table waited with them.
	 * - It walks forward along the primary key from a stored cursor. `capture_source`
	 *   has no index, so a WHERE on it alone re-read every row already classified: about
	 *   N²/2000 row reads over a full migration, roughly 125M for 500k rows.
	 *
	 * A row left with a NULL state is invisible in the admin list (`state != 'submitted'`
	 * is never true for NULL), unwritable (the capture compare-and-set on `state = ''`
	 * cannot match NULL) and never purged by retention -- so the caller needs to know
	 * whether the pass finished, and the batches are small enough to make partial
	 * progress survivable.
	 *
	 * `state` is only ever filled in where it is still empty. Writing it unconditionally
	 * meant a legacy row that had been saved, then submitted, while the site was still
	 * held at v12 was matched again by this query and had its terminal `submitted`
	 * overwritten with `in_progress` -- an open draft that could be written to again and,
	 * with `expires_at` NULL, was never purged.
	 *
	 * @since 2.12.9
	 * @return string One of the BACKFILL_* statuses.
	 */
	public function backfill_lifecycle_source() {
		if ( get_option( self::BACKFILL_DONE_OPTION ) ) {
			return self::BACKFILL_DONE;
		}

		$columns = $this->get_columns();
		if ( empty( $columns['capture_source'] ) || empty( $columns['state'] ) ) {
			return self::BACKFILL_NO_COLUMNS;
		}

		if ( ! is_admin() && ! wp_doing_cron() ) {
			return self::BACKFILL_INCOMPLETE;
		}

		$progress = self::backfill_progress();

		// Five failures, but only once they are spread out: each one pushes the next
		// attempt further away, so a burst of lock-wait timeouts during a traffic spike
		// cannot spend the whole budget inside a minute and strand the table.
		if ( $progress['failures'] >= self::BACKFILL_MAX_FAILURES ) {
			return self::BACKFILL_FAILED;
		}
		if ( time() < $progress['next_try'] ) {
			return self::BACKFILL_INCOMPLETE;
		}

		$token = self::claim_backfill_lock();
		if ( '' === $token ) {
			return self::BACKFILL_INCOMPLETE;
		}

		$status = $this->run_backfill_batches( $progress['cursor'], $progress['failures'] );

		self::release_backfill_lock( $token );

		if ( self::BACKFILL_DONE === $status ) {
			update_option( self::BACKFILL_DONE_OPTION, 1, false );
			delete_option( self::BACKFILL_PROGRESS_OPTION );
		}

		return $status;
	}

	/**
	 * Add a new draft submission to the database.
	 *
	 * @param array<mixed> $data An associative array of data for the new draft submission. Must include 'id'.
	 * @since 2.2.0
	 * @return int|false The number of rows inserted, or false if the insertion fails.
	 */
	public static function add( $data ) {
		if ( ! is_array( $data ) || empty( $data['id'] ) ) {
			return false;
		}
		// Basic sanitisation of individual fields.
		$data['id'] = sanitize_text_field( $data['id'] );
		if ( isset( $data['email'] ) ) {
			$data['email'] = sanitize_email( $data['email'] );
		}
		if ( isset( $data['ip'] ) ) {
			$data['ip'] = sanitize_text_field( $data['ip'] );
		}
		if ( isset( $data['source_url'] ) ) {
			$data['source_url'] = esc_url_raw( $data['source_url'] );
		}
		if ( isset( $data['form_id'] ) ) {
			$data['form_id'] = absint( $data['form_id'] );
		}
		// Serialize form_data if it's an array.
		if ( isset( $data['form_data'] ) && is_array( $data['form_data'] ) ) {
			$data['form_data'] = wp_json_encode( $data['form_data'] );
		}
		// add() is the deliberate Save & Resume write path; automatic captures go
		// through save_snapshot(). Classify the row so the inactivity scanner skips it.
		$data['capture_source'] = $data['capture_source'] ?? self::SOURCE_SAVE_RESUME;
		$data['state']          = $data['state'] ?? self::STATE_SAVED;
		return self::get_instance()->use_insert( $data );
	}

	/**
	 * Retrieve a specific draft submission from the database.
	 *
	 * @param string $id The id of the draft submission to retrieve.
	 * @since 2.2.0
	 * @return array<mixed> An associative array representing the draft submission, or an empty array if not found.
	 */
	public static function get( $id ) {
		if ( empty( $id ) ) {
			return [];
		}

		return self::get_by( 'id', sanitize_text_field( $id ) );
	}

	/**
	 * Update a draft submission by id.
	 *
	 * @param string              $id Draft id.
	 * @param array<string,mixed> $data Data to update.
	 * @since 2.2.0
	 * @return int|false The number of rows updated, or false on error.
	 */
	public static function update( $id, $data = [] ) {
		if ( empty( $id ) ) {
			return false;
		}

		// Serialize form_data if it's an array.
		if ( isset( $data['form_data'] ) && is_array( $data['form_data'] ) ) {
			$data['form_data'] = wp_json_encode( $data['form_data'] );
		}

		return self::get_instance()->use_update( $data, [ 'id' => sanitize_text_field( $id ) ] );
	}

	/**
	 * Atomically claim a draft for notification.
	 *
	 * Sets notified_at in a single CONDITIONAL UPDATE and reports whether THIS caller won
	 * the claim, so two concurrent notifier runs (the hook is public, and Action Scheduler
	 * can replay) cannot both send: exactly one sees a row count of 1. The condition is
	 * "never claimed" by default, or "not claimed within $reclaim_after seconds" when a
	 * window is supplied — see below.
	 *
	 * Pair with release_notification_claim() so a failed send does not leave the row
	 * permanently marked as notified.
	 *
	 * Repeat notifications: pass $reclaim_after to make the claim time-windowed —
	 * the row becomes claimable again once its last stamp is older than that many
	 * seconds. This keeps one unambiguous meaning for `notified_at` ("when this row
	 * was last claimed for sending") and keeps the claim atomic, so a row that may
	 * be emailed more than once still cannot be double-sent by concurrent runs.
	 * Omit it (the default) for the send-once behaviour: NULL means never claimed,
	 * and a stamped row is never claimable again.
	 *
	 * @param string   $id            Draft id.
	 * @param string   $stamp         UTC mysql-format timestamp to write.
	 * @param int|null $reclaim_after Seconds after which a stamped row may be re-claimed.
	 *                                Null (default) = claim only once, ever.
	 * @since 2.12.3
	 * @return bool True when this caller claimed the row, false when it was already claimed.
	 */
	public static function claim_for_notification( $id, $stamp, $reclaim_after = null ) {
		global $wpdb;

		if ( empty( $id ) ) {
			return false;
		}

		$table = self::get_instance()->get_tablename();
		$stamp = sanitize_text_field( $stamp );
		$id    = sanitize_text_field( $id );

		if ( null === $reclaim_after ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Conditional UPDATE is the claim primitive; $table comes from get_tablename(), not from input.
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET notified_at = %s WHERE id = %s AND notified_at IS NULL", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
					$stamp,
					$id
				)
			);

			return 1 === (int) $claimed;
		}

		// Windowed claim. The cutoff is derived from the caller's own stamp rather than
		// the DB clock so the comparison uses one consistent time source (both are UTC
		// mysql strings written by current_time( 'mysql', true )).
		//
		// Fail CLOSED on a stamp we cannot parse. This is a public static entry point, so
		// a future caller could pass something malformed; silently falling back to epoch
		// would turn the predicate into "claim anything" and remove the throttle without
		// any signal.
		$stamp_ts = strtotime( $stamp . ' UTC' );
		if ( false === $stamp_ts ) {
			return false;
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', max( 0, $stamp_ts - absint( $reclaim_after ) ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET notified_at = %s WHERE id = %s AND ( notified_at IS NULL OR notified_at <= %s )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
				$stamp,
				$id,
				$cutoff
			)
		);

		return 1 === (int) $claimed;
	}

	/**
	 * Release a notification claim taken by claim_for_notification().
	 *
	 * Only clears the stamp this caller wrote, so a later successful run's stamp is never
	 * wiped by a straggler's failure path.
	 *
	 * @param string $id    Draft id.
	 * @param string $stamp The exact stamp this caller wrote.
	 * @since 2.12.3
	 * @return bool True when the claim was released.
	 */
	public static function release_notification_claim( $id, $stamp ) {
		global $wpdb;

		if ( empty( $id ) ) {
			return false;
		}

		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Mirror of the claim above.
		$released = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET notified_at = NULL WHERE id = %s AND notified_at = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
				sanitize_text_field( $id ),
				sanitize_text_field( $stamp )
			)
		);

		return 1 === (int) $released;
	}

	/**
	 * Delete a draft submission by id.
	 *
	 * @param string $id Draft id to delete.
	 * @since 2.2.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete( $id ) {
		if ( empty( $id ) ) {
			return false;
		}

		return self::get_instance()->use_delete( [ 'id' => sanitize_text_field( $id ) ], [ '%s' ] );
	}

	/**
	 * Delete draft submissions older than specified days.
	 *
	 * @since 2.2.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete_old_drafts() {
		global $wpdb;

		$instance = self::get_instance();

		// Number of days is filterable via 'srfm_delete_old_drafts_days' filter (default: 30 days).
		$days = apply_filters( 'srfm_delete_old_drafts_days', 30 );

		// If days is not a positive integer, use default of 30 days.
		if ( ! is_int( $days ) || $days <= 0 ) {
			$days = 30;
		}

		// Calculate the date threshold.
		$timestamp = strtotime( "-{$days} days" );
		if ( false === $timestamp ) {
			return false;
		}
		$threshold_date = gmdate( 'Y-m-d H:i:s', $timestamp );

		// Scope deletion to legacy Save & Resume rows (last_trigger
		// is empty or 'saved'). Partial-entries rows use other
		// triggers (heartbeat / pagebreak / input / pagehide) and
		// are swept by `Init::cleanup_stale_partials()` with its own
		// retention filter — running this query without the trigger
		// scope would cross-delete partial entries at the
		// save-resume retention window, ignoring the dedicated
		// `srfm_partial_entries_retention_days` filter.
		$table = $instance->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- scheduled maintenance, intentionally uncached; table name from internal config.
		return $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE date_created < %s AND ( last_trigger = %s OR last_trigger = '' OR last_trigger IS NULL )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is internal.
				$threshold_date,
				'saved'
			)
		);
	}

	/**
	 * The unique identity of an automatic capture: one logical draft per form + session.
	 *
	 * @param int    $form_id    Form post ID.
	 * @param string $session_id Capture session id.
	 * @since 2.12.9
	 * @return string 64-char hex digest.
	 */
	public static function capture_key( $form_id, $session_id ) {
		return hash( 'sha256', 'srfm_pe|' . absint( $form_id ) . '|' . Helper::get_string_value( $session_id ) );
	}

	/**
	 * Find the automatic capture for a form + session, adopting a pre-v13 row if needed.
	 *
	 * Rows written before v13 have no capture_key. The newest such row for the session is
	 * given the key with a conditional UPDATE, so it is adopted exactly once, and an older
	 * duplicate of it is left untouched rather than merged.
	 *
	 * @param int    $form_id    Form post ID.
	 * @param string $session_id Capture session id.
	 * @since 2.12.9
	 * @return array<string,mixed> Decoded row, or [] when there is none.
	 */
	public static function find_capture( $form_id, $session_id ) {
		$form_id    = absint( $form_id );
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		if ( 0 === $form_id || '' === $session_id ) {
			return [];
		}

		$row = self::get_by_capture_key( self::capture_key( $form_id, $session_id ) );
		if ( ! empty( $row ) ) {
			return $row;
		}

		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- conditional adoption on an internal table.
		$legacy_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE session_id = %s AND form_id = %d AND capture_key IS NULL ORDER BY updated_at DESC, partial_entry_id DESC LIMIT 1",
				$session_id,
				$form_id
			)
		);
		if ( is_string( $legacy_id ) && '' !== $legacy_id ) {
			$suppress = $wpdb->suppress_errors( true );
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET capture_key = %s WHERE id = %s AND capture_key IS NULL",
					self::capture_key( $form_id, $session_id ),
					$legacy_id
				)
			);
			$wpdb->suppress_errors( $suppress );
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return self::get_by_capture_key( self::capture_key( $form_id, $session_id ) );
	}

	/**
	 * Read one row by its capture key.
	 *
	 * @param string $capture_key Capture key.
	 * @since 2.12.9
	 * @return array<string,mixed> Decoded row, or [] when there is none.
	 */
	public static function get_by_capture_key( $capture_key ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- uncached on purpose: callers compare-and-set against this read.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE capture_key = %s LIMIT 1", Helper::get_string_value( $capture_key ) ), ARRAY_A );

		return is_array( $row ) ? self::decode_row( $row ) : [];
	}

	/**
	 * Insert the first snapshot of an automatic capture.
	 *
	 * The UNIQUE capture_key makes this the arbiter of concurrent first saves: exactly one
	 * insert succeeds, and the loser reads back the winner's row.
	 *
	 * @param int                 $form_id    Form post ID.
	 * @param string              $session_id Capture session id.
	 * @param array<string,mixed> $fields     Column values.
	 * @since 2.12.9
	 * @return array<string,mixed> The row now stored for this capture (the winner's on a lost race), or [] on failure.
	 */
	public static function insert_capture( $form_id, $session_id, array $fields ) {
		global $wpdb;

		$form_id    = absint( $form_id );
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		$key        = self::capture_key( $form_id, $session_id );

		unset( $fields['partial_entry_id'], $fields['date_created'], $fields['notes'] );
		$fields = array_merge(
			$fields,
			[
				'id'               => wp_generate_uuid4(),
				'form_id'          => $form_id,
				'session_id'       => $session_id,
				'capture_key'      => $key,
				'capture_source'   => self::SOURCE_AUTOMATIC,
				'activity_version' => 1,
			]
		);

		$suppress = $wpdb->suppress_errors( true );
		$wpdb->insert( self::get_instance()->get_tablename(), self::encode_fields( $fields ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- the unique key is the concurrency guard.
		$wpdb->suppress_errors( $suppress );

		return self::get_by_capture_key( $key );
	}

	/**
	 * Whether a draft row may still take a visitor write.
	 *
	 * A row written before v13 carries no state until the backfill reaches it, and
	 * testing that against WRITABLE_STATES answered "no" -- so every save from a
	 * visitor who still had such a draft open was refused as `gone` and the browser
	 * stopped trying. Those rows are stuck, not terminal: an unclassified row is by
	 * definition one the lifecycle has not judged, so it is treated as in progress and
	 * the write that follows classifies it. Only the states that really are terminal
	 * (submitted, and anything unrecognised) refuse.
	 *
	 * @param array<string,mixed> $row Draft row as read from the table.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function is_writable( array $row ) {
		$state = $row['state'] ?? null;

		if ( null === $state || '' === $state ) {
			return true;
		}

		return in_array( Helper::get_string_value( $state ), self::WRITABLE_STATES, true );
	}

	/**
	 * Compare-and-set update of an automatic capture.
	 *
	 * Applies only while the row is still at the version and state the caller read, and
	 * advances the version, so an older snapshot can never overwrite a newer one and a
	 * row that became terminal (submitted, deleted) cannot be revived by a late save.
	 *
	 * Note: this goes through $wpdb directly, as insert_capture() and patch_lifecycle()
	 * do. prepare_data()'s filtering against the live column list protects the Base
	 * query layer, so none of these three is covered by it -- on a site where the v13
	 * ALTER failed they address columns the table does not have and the write simply
	 * fails. That is the intended outcome (no capture is better than a half-written
	 * one), but it is not the graceful degradation classic Save & Resume gets.
	 *
	 * @param array<string,mixed> $row    Row as read by find_capture().
	 * @param array<string,mixed> $fields Column values to write.
	 * @since 2.12.9
	 * @return bool True when this write was applied.
	 */
	public static function update_capture( array $row, array $fields ) {
		global $wpdb;

		$version = absint( $row['activity_version'] ?? 0 );
		unset( $fields['id'], $fields['capture_key'], $fields['partial_entry_id'], $fields['date_created'], $fields['notes'] );
		$fields['activity_version'] = $version + 1;

		// Classify the row while writing to it. A legacy row this save reaches before
		// the backfill does keeps `capture_source` NULL, which is the backfill's own
		// WHERE clause -- so the backfill would still match the row later and its
		// `state = CASE …` would overwrite whatever terminal state had been reached in
		// the meantime. Setting it here takes the row out of that query for good.
		if ( empty( $row['capture_source'] ) ) {
			$fields['capture_source'] = self::SOURCE_AUTOMATIC;
		}

		// A row written before the lifecycle upgrade has state NULL until the backfill
		// reaches it, and `state = ''` never matches NULL -- so every save from that
		// visitor failed its compare-and-set and came back as `gone`. The state is left
		// out of the comparison for those rows: activity_version still guards against a
		// concurrent write, and a NULL state is by definition one the lifecycle has not
		// classified yet, so it cannot be a submitted row being revived.
		$where = [
			'id'               => Helper::get_string_value( $row['id'] ?? '' ),
			'activity_version' => $version,
		];
		if ( null !== ( $row['state'] ?? null ) ) {
			$where['state'] = Helper::get_string_value( $row['state'] );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- compare-and-set write.
		$updated = $wpdb->update(
			self::get_instance()->get_tablename(),
			self::encode_fields( $fields ),
			$where
		);

		return 1 === $updated;
	}

	/**
	 * Ids of automatic captures whose inactivity deadline has passed.
	 *
	 * @param string $now   UTC mysql datetime.
	 * @param int    $limit Batch size.
	 * @since 2.12.9
	 * @return array<int,string>
	 */
	public static function get_due_for_abandonment( $now, $limit ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- batched scan on idx_state_abandon.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE state = %s AND abandon_after IS NOT NULL AND abandon_after <= %s ORDER BY abandon_after ASC LIMIT %d",
				self::STATE_IN_PROGRESS,
				$now,
				absint( $limit )
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return is_array( $ids ) ? array_map( 'strval', $ids ) : [];
	}

	/**
	 * Mark an in-progress capture abandoned, if it is still due.
	 *
	 * Re-checks the deadline inside the UPDATE, so activity that landed after the scan
	 * read the row wins. first_abandoned_at is only ever set once.
	 *
	 * @param string $id  Row UUID.
	 * @param string $now UTC mysql datetime.
	 * @since 2.12.9
	 * @return bool True when this call made the transition.
	 */
	public static function mark_abandoned( $id, $now ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- conditional state transition.
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET state = %s, abandoned_at = %s, first_abandoned_at = COALESCE( first_abandoned_at, %s ) WHERE id = %s AND state = %s AND abandon_after IS NOT NULL AND abandon_after <= %s",
				self::STATE_ABANDONED,
				$now,
				$now,
				Helper::get_string_value( $id ),
				self::STATE_IN_PROGRESS,
				$now
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return 1 === (int) $updated;
	}

	/**
	 * Mark a capture submitted and drop its answers, keeping the outcome.
	 *
	 * The row stays as a terminal marker so a delayed autosave for the same session is
	 * rejected instead of starting a new draft; `$expires_at` bounds how long it stays.
	 *
	 * A row still carrying the pre-v13 NULL state is included. It was not: a legacy
	 * draft submitted without an autosave in between never reached `submitted`, and the
	 * backfill then classified it as an open draft for good.
	 *
	 * @param string $id         Row UUID.
	 * @param int    $entry_id   Accepted entry id, or 0 when the entry was not stored.
	 * @param string $now        UTC mysql datetime.
	 * @param string $expires_at UTC mysql datetime the marker is purged at.
	 * @since 2.12.9
	 * @return bool True when this call made the transition.
	 */
	public static function mark_submitted( $id, $entry_id, $now, $expires_at ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- conditional state transition.
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET state = %s, capture_source = COALESCE( NULLIF( capture_source, '' ), %s ), form_data = '[]', activity_version = activity_version + 1, submitted_entry_id = NULLIF( %d, 0 ), submitted_at = %s, abandon_after = NULL, expires_at = %s WHERE id = %s AND ( state IS NULL OR state IN ( %s, %s, %s ) )",
				self::STATE_SUBMITTED,
				self::SOURCE_AUTOMATIC,
				absint( $entry_id ),
				$now,
				$expires_at,
				Helper::get_string_value( $id ),
				self::STATE_IN_PROGRESS,
				self::STATE_ABANDONED,
				self::STATE_SAVED
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return 1 === (int) $updated;
	}

	/**
	 * Ids of rows whose retention window has ended.
	 *
	 * @param string $now   UTC mysql datetime.
	 * @param int    $limit Batch size.
	 * @since 2.12.9
	 * @return array<int,string>
	 */
	public static function get_expired( $now, $limit ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- batched scan on idx_expires.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE expires_at IS NOT NULL AND expires_at <= %s ORDER BY expires_at ASC LIMIT %d",
				$now,
				absint( $limit )
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return is_array( $ids ) ? array_map( 'strval', $ids ) : [];
	}

	/**
	 * Merge changes into a draft's lifecycle metadata under a compare-and-set.
	 *
	 * `$patch` should be a callable. It is handed the lifecycle and the row read on
	 * *this* attempt and returns the keys to write, so the change is re-derived from
	 * the current row every time the compare-and-set loses. A plain array is still
	 * accepted, but it carries values the caller computed from a row it read earlier:
	 * a worker that read `recovery.version = 1`, lost the race to an admin revoke that
	 * wrote version 2, and then wrote its stale copy back would hand the revoked links
	 * their validity again. Callers that touch a key an administrator can also change
	 * must pass a callable.
	 *
	 * Returning anything that is not an array from the callable vetoes the write and
	 * reports false, which is how a mutator says "the fresh row no longer needs this".
	 *
	 * A mutator is recognised by being a Closure, not by is_callable(): every two-element
	 * array of strings is callable, so an ordinary patch like
	 * `[ 'Capture_Policy', 'hash_recipient' ]` would have been *invoked* instead of
	 * stored.
	 *
	 * @param string                                                                      $id    Draft UUID.
	 * @param array<string,mixed>|\Closure(array<string,mixed>,array<string,mixed>):mixed $patch Changes, or a mutator returning them.
	 * @since 2.12.9
	 * @return bool True when the merge was stored.
	 */
	public static function patch_lifecycle( $id, $patch ) {
		global $wpdb;

		$table = self::get_instance()->get_tablename();

		for ( $attempt = 0; $attempt < self::PATCH_LIFECYCLE_ATTEMPTS; $attempt++ ) {
			$row = self::get( $id );
			if ( empty( $row ) ) {
				return false;
			}

			$version   = absint( $row['activity_version'] ?? 0 );
			$lifecycle = is_array( $row['lifecycle'] ?? null ) ? $row['lifecycle'] : [];

			$changes = $patch instanceof \Closure ? $patch( $lifecycle, $row ) : $patch;
			if ( ! is_array( $changes ) ) {
				return false;
			}

			foreach ( $changes as $key => $value ) {
				$lifecycle[ $key ] = $value;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- compare-and-set write.
			$updated = $wpdb->update(
				$table,
				[
					'lifecycle'        => wp_json_encode( $lifecycle ),
					'activity_version' => $version + 1,
				],
				[
					'id'               => Helper::get_string_value( $id ),
					'activity_version' => $version,
				]
			);

			if ( false === $updated ) {
				return false;
			}

			// The version always changes, so MySQL reporting no affected rows can only
			// mean the compare-and-set lost -- never that the values were identical.
			if ( 1 === $updated ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Retrieve the single row matching a session_id + form_id pair.
	 *
	 * @param string $session_id Session identifier (max 64 chars).
	 * @param int    $form_id    Form post ID.
	 * @since 2.9.0
	 * @return array<mixed> Row data or empty array if not found.
	 */
	public static function get_by_session( $session_id, $form_id ) {
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		$form_id    = absint( $form_id );
		if ( '' === $session_id || 0 === $form_id ) {
			return [];
		}
		$results = self::get_instance()->get_results(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			'*',
			[ 'LIMIT 1' ]
		);
		$row     = isset( $results[0] ) && is_array( $results[0] ) ? $results[0] : [];
		// Decode form_data JSON string so the restore endpoint gets an array.
		if ( ! empty( $row['form_data'] ) && is_string( $row['form_data'] ) ) {
			$decoded = json_decode( $row['form_data'], true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$row['form_data'] = $decoded;
			}
		}
		return $row;
	}

	/**
	 * Delete the row matching a session_id + form_id pair.
	 *
	 * @param string $session_id Session identifier.
	 * @param int    $form_id    Form post ID.
	 * @since 2.9.0
	 * @return int|false Number of rows deleted, or false on error.
	 */
	public static function delete_by_session( $session_id, $form_id ) {
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		$form_id    = absint( $form_id );
		if ( '' === $session_id || 0 === $form_id ) {
			return false;
		}
		return self::get_instance()->use_delete(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			[ '%s', '%d' ]
		);
	}

	/**
	 * Delete a single row by its UUID primary key.
	 *
	 * @param string $id Row UUID.
	 * @since 2.9.0
	 * @return int|false Number of rows deleted, or false on error.
	 */
	public static function delete_entry( $id ) {
		$id = sanitize_text_field( Helper::get_string_value( $id ) );
		if ( '' === $id ) {
			return false;
		}
		return self::get_instance()->use_delete( [ 'id' => $id ], [ '%s' ] );
	}

	/**
	 * Update a single row by its UUID primary key.
	 *
	 * @param string              $id   Row UUID.
	 * @param array<string,mixed> $data Column => value pairs to update.
	 * @since 2.9.0
	 * @return int|false Number of rows updated, or false on error.
	 */
	public static function update_entry( $id, $data = [] ) {
		$id = sanitize_text_field( Helper::get_string_value( $id ) );
		if ( '' === $id ) {
			return false;
		}
		return self::get_instance()->use_update( $data, [ 'id' => $id ] );
	}

	/**
	 * Return the UUIDs of the previous (older) and next (newer) rows
	 * relative to `$current_id`, ordered by `updated_at`.
	 *
	 * Optionally scoped to a single form when `$form_id > 0`.
	 *
	 * @param string $current_id UUID of the current row.
	 * @param int    $form_id    Optional form scope (0 = site-wide).
	 * @since 2.9.0
	 * @return array{previous_id: string|null, next_id: string|null}
	 */
	public static function get_adjacent_ids( $current_id, $form_id = 0 ) {
		$result     = [
			'previous_id' => null,
			'next_id'     => null,
		];
		$current_id = sanitize_text_field( Helper::get_string_value( $current_id ) );
		if ( '' === $current_id ) {
			return $result;
		}
		$form_id = absint( $form_id );

		global $wpdb;
		$table = self::get_instance()->get_tablename();

		$form_clause = '';
		if ( $form_id > 0 ) {
			$form_clause = $wpdb->prepare( ' AND form_id = %d', $form_id ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$current_ts = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT updated_at FROM {$table} WHERE id = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_id
			)
		);

		if ( ! is_string( $current_ts ) || '' === $current_ts ) {
			return $result;
		}

		// Previous = older.
		$previous_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE (( updated_at < %s ) OR ( updated_at = %s AND id < %s )){$form_clause} ORDER BY updated_at DESC, id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_ts,
				$current_ts,
				$current_id
			)
		);

		// Next = newer.
		$next_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE (( updated_at > %s ) OR ( updated_at = %s AND id > %s )){$form_clause} ORDER BY updated_at ASC, id ASC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_ts,
				$current_ts,
				$current_id
			)
		);

		return [
			'previous_id' => is_string( $previous_id ) && '' !== $previous_id ? $previous_id : null,
			'next_id'     => is_string( $next_id ) && '' !== $next_id ? $next_id : null,
		];
	}

	/**
	 * Allowed columns for ORDER BY clauses — guards against SQL injection.
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	protected function get_allowed_orderby_columns() {
		return [ 'id', 'form_id', 'date_created', 'progress_percent', 'updated_at' ];
	}

	/**
	 * Drop keys the table does not have before any insert or update.
	 *
	 * Every v13 write names `capture_source` and `state`, and the parent adds
	 * `activity_version` and `lifecycle` from the schema even when the caller left
	 * them out. On a site where the v13 ALTER could not run -- no ALTER privilege, a
	 * lock timeout -- that turns every Save & Resume write into an "Unknown column"
	 * error and takes the feature down with the upgrade. Writing the row without the
	 * new columns keeps Save & Resume working until the ALTER succeeds.
	 *
	 * @param array<string,mixed> $data          Values keyed by column.
	 * @param bool                $skip_defaults Whether to omit schema defaults.
	 * @since 2.12.9
	 * @return array{data:array<string,mixed>,format:array<string>}
	 */
	protected function prepare_data( $data, $skip_defaults = false ) {
		$prepared = parent::prepare_data( $data, $skip_defaults );

		/**
		 * Values keyed by column, as the parent built them.
		 *
		 * @var array<string,mixed> $prepared_data
		 */
		$prepared_data = is_array( $prepared['data'] ?? null ) ? $prepared['data'] : [];
		/**
		 * Format specifiers, positionally parallel to $prepared_data.
		 *
		 * @var array<int,mixed> $prepared_format
		 */
		$prepared_format = is_array( $prepared['format'] ?? null ) ? $prepared['format'] : [];

		$values  = [];
		$formats = [];
		$index   = 0;

		if ( null === $this->live_columns ) {
			$this->live_columns = $this->get_columns();
		}

		// An empty result means SHOW COLUMNS itself failed, not that the table has no
		// columns. Dropping every key then would turn a transient read error into a
		// silent empty write, so nothing is filtered and the real error surfaces.
		$known = $this->live_columns;

		foreach ( $prepared_data as $column => $value ) {
			if ( empty( $known ) || isset( $known[ $column ] ) ) {
				$values[ $column ] = $value;
				$formats[]         = Helper::get_string_value( $prepared_format[ $index ] ?? '%s' );
			}
			++$index;
		}

		return [
			'data'   => $values,
			'format' => $formats,
		];
	}

	/**
	 * Decode the JSON columns of a raw row.
	 *
	 * @param array<string,mixed> $row Raw row.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	private static function decode_row( array $row ) {
		foreach ( [ 'form_data', 'notes', 'lifecycle' ] as $column ) {
			if ( isset( $row[ $column ] ) && is_string( $row[ $column ] ) && '' !== $row[ $column ] ) {
				$decoded        = json_decode( $row[ $column ], true );
				$row[ $column ] = is_array( $decoded ) ? $decoded : [];
			} elseif ( ! isset( $row[ $column ] ) || ! is_array( $row[ $column ] ) ) {
				$row[ $column ] = [];
			}
		}
		return $row;
	}

	/**
	 * JSON-encode the array columns of a write.
	 *
	 * @param array<string,mixed> $fields Column values.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	private static function encode_fields( array $fields ) {
		foreach ( [ 'form_data', 'notes', 'lifecycle' ] as $column ) {
			if ( isset( $fields[ $column ] ) && is_array( $fields[ $column ] ) ) {
				$fields[ $column ] = wp_json_encode( $fields[ $column ] );
			}
		}
		return $fields;
	}

	/**
	 * Retrieve draft submission data by a given condition.
	 *
	 * @param string     $key Lookup key (e.g., 'id', 'form_id').
	 * @param int|string $value Lookup value.
	 * @return array<mixed> Draft submission data or empty array if not found.
	 */
	private static function get_by( $key, $value ) {
		if ( empty( $key ) || empty( $value ) ) {
			return [];
		}

		$results = self::get_instance()->get_results(
			[
				$key => $value,
			]
		);

		$draft = isset( $results[0] ) && is_array( $results[0] ) ? Helper::get_array_value( $results[0] ) : [];

		// Decode the JSON columns (form_data, notes, lifecycle) whichever way the
		// underlying query layer returned them.
		return empty( $draft ) ? [] : self::decode_row( $draft );
	}

	/**
	 * Where the backfill got to, how many passes have failed in a row, and the earliest
	 * time the next one may run.
	 *
	 * @since 2.12.9
	 * @return array{cursor:int,failures:int,next_try:int}
	 */
	private static function backfill_progress() {
		$stored = get_option( self::BACKFILL_PROGRESS_OPTION, [] );
		$stored = is_array( $stored ) ? $stored : [];

		return [
			'cursor'   => absint( $stored['cursor'] ?? 0 ),
			'failures' => absint( $stored['failures'] ?? 0 ),
			'next_try' => absint( $stored['next_try'] ?? 0 ),
		];
	}

	/**
	 * Record where the backfill got to.
	 *
	 * @param int $cursor   Highest partial_entry_id this pass has walked past.
	 * @param int $failures Consecutive failed passes; 0 resets the count.
	 * @since 2.12.9
	 * @return void
	 */
	private static function save_backfill_progress( $cursor, $failures ) {
		$failures = absint( $failures );
		// Exponential, capped: 1, 2, 4, 8 … minutes up to an hour, so five failures
		// cannot be spent in a burst.
		$wait = 0 === $failures
			? 0
			: (int) min( self::BACKFILL_RETRY_MAX, self::BACKFILL_RETRY_BASE * ( 2 ** ( $failures - 1 ) ) );

		update_option(
			self::BACKFILL_PROGRESS_OPTION,
			[
				'cursor'   => absint( $cursor ),
				'failures' => $failures,
				'next_try' => 0 === $wait ? 0 : time() + $wait,
			],
			false
		);
	}

	/**
	 * Take the backfill mutex, returning the token that proves ownership, or ''.
	 *
	 * Each claimant writes its own random token and then reads the option back: whoever
	 * reads their own token back holds the lock. add_option() alone was not enough --
	 * it is a check-then-insert, so two simultaneous requests can both be told they
	 * created it, and a persistent cache holding a stale `notoptions` can let a second
	 * one overwrite a live claim.
	 *
	 * A claim older than BACKFILL_LOCK_TTL is treated as abandoned, or a request that
	 * died mid-pass would stop the migration for good. Two requests stealing the same
	 * stale claim is harmless anyway: the pass is idempotent and the cursor only moves
	 * forward.
	 *
	 * @since 2.12.9
	 * @return string Ownership token, or '' when someone else holds the lock.
	 */
	private static function claim_backfill_lock() {
		$now   = time();
		$token = wp_generate_password( 20, false );
		$claim = $token . '|' . $now;

		if ( add_option( self::BACKFILL_LOCK_OPTION, $claim, '', false ) ) {
			// A concurrent add_option() may have been told the same thing.
			return self::backfill_lock_token() === $token ? $token : '';
		}

		$held = explode( '|', Helper::get_string_value( get_option( self::BACKFILL_LOCK_OPTION, '' ) ) );
		$age  = $now - absint( $held[1] ?? 0 );
		if ( $age < self::BACKFILL_LOCK_TTL ) {
			return '';
		}

		update_option( self::BACKFILL_LOCK_OPTION, $claim, false );

		return self::backfill_lock_token() === $token ? $token : '';
	}

	/**
	 * The token currently written into the lock option.
	 *
	 * @since 2.12.9
	 * @return string
	 */
	private static function backfill_lock_token() {
		$held = explode( '|', Helper::get_string_value( get_option( self::BACKFILL_LOCK_OPTION, '' ) ) );

		return Helper::get_string_value( $held[0] ?? '' );
	}

	/**
	 * Release the mutex, but only if it is still ours.
	 *
	 * Deleting it unconditionally let a slow request wipe the claim of whoever had
	 * already taken over from it.
	 *
	 * @param string $token Token returned by claim_backfill_lock().
	 * @since 2.12.9
	 * @return void
	 */
	private static function release_backfill_lock( $token ) {
		if ( '' !== $token && self::backfill_lock_token() === $token ) {
			delete_option( self::BACKFILL_LOCK_OPTION );
		}
	}

	/**
	 * Classify rows in batches, walking forward from `$cursor`.
	 *
	 * @param int $cursor   partial_entry_id to resume after.
	 * @param int $failures Consecutive failed passes so far.
	 * @since 2.12.9
	 * @return string One of the BACKFILL_* statuses.
	 */
	private function run_backfill_batches( $cursor, $failures ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- batched, idempotent migration; every value is a placeholder and the only interpolation is the internal table name, which prepare() cannot take.
		$table = $this->get_tablename();
		$limit = absint( self::BACKFILL_BATCH_SIZE );

		for ( $batch = 0; $batch < self::BACKFILL_MAX_BATCHES; $batch++ ) {
			// get_col() answers a dropped connection or a max_statement_time abort with
			// an empty array, which is indistinguishable from "no rows left" -- and
			// reporting DONE there recorded the backfill as finished and left every row
			// past the cursor NULL-state for good, which is the outcome this whole
			// mechanism exists to prevent. The error flag is the only thing that tells
			// the two apart.
			$wpdb->last_error = '';
			$ids              = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT partial_entry_id FROM {$table} WHERE partial_entry_id > %d ORDER BY partial_entry_id ASC LIMIT %d",
					absint( $cursor ),
					$limit
				)
			);

			if ( '' !== Helper::get_string_value( $wpdb->last_error ) ) {
				/** This action is documented in sureforms/inc/database/base.php */
				do_action( 'srfm_db_upgrade_query_failed', Helper::get_string_value( $wpdb->last_error ), 'partial entries lifecycle backfill (scan)', $table );
				self::save_backfill_progress( $cursor, $failures + 1 );
				return self::BACKFILL_INCOMPLETE;
			}

			if ( ! is_array( $ids ) || empty( $ids ) ) {
				self::save_backfill_progress( $cursor, 0 );
				return self::BACKFILL_DONE;
			}

			$first = absint( reset( $ids ) );
			$last  = absint( end( $ids ) );

			$affected = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET capture_source = CASE WHEN session_id = '' THEN %s ELSE %s END, state = COALESCE( NULLIF( state, '' ), CASE WHEN session_id = '' OR last_trigger = 'saved' OR last_trigger = '' THEN %s ELSE %s END ) WHERE partial_entry_id BETWEEN %d AND %d AND ( capture_source IS NULL OR capture_source = '' )",
					self::SOURCE_SAVE_RESUME,
					self::SOURCE_AUTOMATIC,
					self::STATE_SAVED,
					self::STATE_IN_PROGRESS,
					$first,
					$last
				)
			);

			if ( false === $affected ) {
				/** This action is documented in sureforms/inc/database/base.php */
				do_action( 'srfm_db_upgrade_query_failed', Helper::get_string_value( $wpdb->last_error ), 'partial entries lifecycle backfill', $table );
				self::save_backfill_progress( $cursor, $failures + 1 );
				return self::BACKFILL_INCOMPLETE;
			}

			$cursor = $last;
			self::save_backfill_progress( $cursor, 0 );

			// A short page is the end of the table.
			if ( count( $ids ) < $limit ) {
				return self::BACKFILL_DONE;
			}
		}

		// Still rows to go. stop_db_upgrade() keeps the stored version at v12 for this,
		// so the next pass resumes from the cursor rather than from the beginning.
		return self::BACKFILL_INCOMPLETE;
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
	}
}
