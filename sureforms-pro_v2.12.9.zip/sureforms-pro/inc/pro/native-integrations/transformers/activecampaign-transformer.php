<?php
/**
 * ActiveCampaign Transformer
 *
 * Custom transformer for ActiveCampaign integration.
 * Moves custom field values into the fieldValues array required by the
 * ActiveCampaign REST API (custom fields cannot be set as flat keys on the
 * contact object — they must use the fieldValues structure).
 *
 * @package SureForms
 * @since 2.12.9
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Transformers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Native_Integrations\Interfaces\Payload_Transformer;
use SRFM_Pro\Inc\Pro\Native_Integrations\Services\Workflow_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * ActiveCampaign Transformer class.
 *
 * @since 2.12.9
 */
class ActiveCampaign_Transformer implements Payload_Transformer {
	/**
	 * Integration name
	 *
	 * @var string
	 */
	private $integration_name = 'activecampaign';

	/**
	 * Standard contact properties sent as flat keys on the contact object.
	 * Everything else is a custom field and must go into fieldValues.
	 *
	 * @var array<int, string>
	 */
	private static $standard_fields = [ 'email', 'firstName', 'lastName', 'phone' ];

	/**
	 * Get integration name this transformer handles.
	 *
	 * @return string Integration name.
	 * @since 2.12.9
	 */
	public function get_integration_name() {
		return $this->integration_name;
	}

	/**
	 * Transform payload for ActiveCampaign integration.
	 *
	 * The nested_object payload transformation has already wrapped all fields
	 * inside a "contact" key by the time this method runs.  We pull out any
	 * non-standard keys (custom field IDs) and re-package them as the
	 * fieldValues array that the /api/3/contact/sync endpoint expects.
	 *
	 * @param array $form_data      Payload after generic transformations.
	 * @param array $field_mappings Field mappings configuration (unused).
	 * @param array $context        Additional context data.
	 * @return array Transformed payload.
	 * @since 2.12.9
	 */
	public function transform( $form_data, $field_mappings = [], $context = [] ) {
		unset( $field_mappings ); // Unused.

		$action_name = $context['action_name'] ?? '';

		if ( 'Add Contact' === $action_name ) {
			return $this->transform_add_contact( $form_data );
		}

		return $form_data;
	}

	/**
	 * Prepare test payload with sample data.
	 *
	 * Returns the flat contact fields (plus fieldValues). The action's
	 * nested_object step wraps them in "contact" afterwards, so wrapping here
	 * would send contact.contact.
	 *
	 * @param array $workflow_fields    Fields from the workflow configuration.
	 * @param array $field_definitions Field definitions from the action configuration.
	 * @return array Test payload.
	 * @since 2.12.9
	 */
	public function prepare_test_payload( $workflow_fields, $field_definitions ) {
		$payload   = [];
		$processed = [];

		foreach ( $field_definitions as $field_def ) {
			$field_key = $field_def['key'] ?? '';

			if ( empty( $field_key ) ) {
				continue;
			}

			$processed[ $field_key ] = true;

			if ( $field_def['exclude_from_payload'] ?? false ) {
				continue;
			}

			if ( isset( $workflow_fields[ $field_key ] ) && ! empty( $workflow_fields[ $field_key ] ) ) {
				$payload[ $field_key ] = $workflow_fields[ $field_key ];
			} else {
				$payload[ $field_key ] = Workflow_Processor::generate_test_value( $field_def );
			}
		}

		// Mapped custom fields are not in the action's field definitions.
		foreach ( $workflow_fields as $field_key => $field_value ) {
			if ( isset( $processed[ $field_key ] ) || empty( $field_value ) ) {
				continue;
			}
			$payload[ $field_key ] = $field_value;
		}

		return $this->transform_add_contact( [ 'contact' => $payload ] )['contact'] ?? $payload;
	}

	/**
	 * Restructure the Add Contact payload.
	 *
	 * Splits the flat contact object into standard properties (kept as-is) and
	 * custom field values (moved into the fieldValues array).
	 *
	 * @param array $form_data Payload keyed by "contact".
	 * @return array Restructured payload.
	 * @since 2.12.9
	 */
	private function transform_add_contact( $form_data ) {
		$contact = $form_data['contact'] ?? [];

		if ( empty( $contact ) || ! is_array( $contact ) ) {
			return $form_data;
		}

		$standard_contact = [];
		$field_values     = [];

		foreach ( $contact as $key => $value ) {
			if ( in_array( $key, self::$standard_fields, true ) ) {
				$standard_contact[ $key ] = $value;
				continue;
			}

			// Any remaining key is a custom field ID. Skip array values
			// (multi-select, checkbox group): ActiveCampaign list fields need
			// their own "||a||b||" format, which is not produced here.
			if ( is_array( $value ) ) {
				continue;
			}

			// Skip empty values so we do not overwrite existing data in
			// ActiveCampaign with a blank.
			$str_value = Helper::get_string_value( $value );
			if ( '' === $str_value ) {
				continue;
			}

			$field_values[] = [
				'field' => (string) $key,
				'value' => $str_value,
			];
		}

		if ( ! empty( $field_values ) ) {
			$standard_contact['fieldValues'] = $field_values;
		}

		return [ 'contact' => $standard_contact ];
	}
}
