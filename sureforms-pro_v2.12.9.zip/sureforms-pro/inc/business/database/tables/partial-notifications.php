<?php
/**
 * SureForms Pro Partial Notifications Database Table Class.
 *
 * Durable outbox for the notifications the abandonment lifecycle sends. One row is one
 * logical notification: the UNIQUE idempotency key makes "create it once" atomic, and the
 * claim lease makes "send it once" atomic across concurrent workers. A row records what
 * actually happened, because a completed Action Scheduler action only means the callback
 * ran.
 *
 * @link       https://sureforms.com
 * @since      2.12.9
 * @package    sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Database\Tables;

use SRFM\Inc\Database\Base;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Every query in this class interpolates only $table, which comes from get_tablename();
// all values go through $wpdb->prepare(). Direct, uncached queries are the point: the
// claims and idempotent inserts are concurrency guards and must see the current row.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

/**
 * SureForms Pro Partial Notifications Database Table Class.
 *
 * @since 2.12.9
 */
class Partial_Notifications extends Base {
	use Get_Instance;

	/**
	 * Notification types. `suppression` rows are recipient-level stop markers, not mail.
	 *
	 * @since 2.12.9
	 */
	public const TYPE_VISITOR_REMINDER  = 'visitor_reminder';
	public const TYPE_OWNER_ABANDONMENT = 'owner_abandonment';
	public const TYPE_SUPPRESSION       = 'suppression';

	/**
	 * Statuses. `handed_off` means wp_mail() accepted the message, not that it arrived;
	 * `unknown` means a worker died between claiming and recording the outcome, so the
	 * message may or may not have been handed off and is deliberately not resent.
	 *
	 * @since 2.12.9
	 */
	public const STATUS_QUEUED     = 'queued';
	public const STATUS_RETRYING   = 'retrying';
	public const STATUS_CLAIMED    = 'claimed';
	public const STATUS_HANDED_OFF = 'handed_off';
	public const STATUS_SUPPRESSED = 'suppressed';
	public const STATUS_FAILED     = 'failed';
	public const STATUS_UNKNOWN    = 'unknown';

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	protected $table_suffix = 'partial_notifications';

	/**
	 * {@inheritDoc}
	 *
	 * @var int
	 */
	protected $table_version = 2;

	/**
	 * {@inheritDoc}
	 */
	public function get_schema() {
		return [
			'id'              => [
				'type' => 'number',
			],
			'idempotency_key' => [
				'type' => 'string',
			],
			'type'            => [
				'type' => 'string',
			],
			'draft_id'        => [
				'type'    => 'string',
				'default' => '',
			],
			'form_id'         => [
				'type'    => 'number',
				'default' => 0,
			],
			'status'          => [
				'type' => 'string',
			],
			'reason'          => [
				'type'    => 'string',
				'default' => '',
			],
			// Masked address for display, never the full address.
			'recipient_hint'  => [
				'type'    => 'string',
				'default' => '',
			],
			// sha256 of the normalised address. Matches suppression rows to a recipient.
			'recipient_hash'  => [
				'type'    => 'string',
				'default' => '',
			],
			'attempts'        => [
				'type'    => 'number',
				'default' => 0,
			],
			'due_at'          => [
				'type' => 'datetime',
			],
			'claimed_until'   => [
				'type' => 'datetime',
			],
			'handed_off_at'   => [
				'type' => 'datetime',
			],
			'created_at'      => [
				'type' => 'datetime',
			],
			'updated_at'      => [
				'type' => 'datetime',
			],
		];
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns_definition() {
		// No definition may contain a quote: Base passes them through
		// $wpdb->prepare( '%1s' ), which escapes it into invalid SQL. Text columns
		// without a value are therefore NULL rather than DEFAULT ''.
		return [
			'id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT',
			'idempotency_key CHAR(64) NOT NULL',
			'type VARCHAR(32) NOT NULL',
			'draft_id CHAR(36) NULL DEFAULT NULL',
			'form_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0',
			'status VARCHAR(20) NOT NULL',
			'reason VARCHAR(64) NULL DEFAULT NULL',
			'recipient_hint VARCHAR(191) NULL DEFAULT NULL',
			'recipient_hash CHAR(64) NULL DEFAULT NULL',
			'attempts TINYINT UNSIGNED NOT NULL DEFAULT 0',
			'due_at DATETIME NOT NULL',
			'claimed_until DATETIME NULL DEFAULT NULL',
			'handed_off_at DATETIME NULL DEFAULT NULL',
			'created_at DATETIME NOT NULL',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			'PRIMARY KEY (id)',
			'UNIQUE KEY uniq_idempotency (idempotency_key)',
			'INDEX idx_status_due (status, due_at)',
			// get_due() runs one batch per type, and `type` is not in idx_status_due,
			// so that scan read every queued row of every other type to discard it.
			'INDEX idx_type_status_due (type, status, due_at)',
			'INDEX idx_draft (draft_id)',
			'INDEX idx_recipient (recipient_hash, type)',
		];
	}

	/**
	 * Column / index definitions for the DB upgrade path.
	 *
	 * @since 2.12.9
	 * @return array<int,string>
	 */
	public function get_new_columns_definition() {
		return [
			// v2: the per-type scan index. Additive, and the Base skips it when present.
			'INDEX idx_type_status_due (type, status, due_at)',
		];
	}

	/**
	 * Create a notification once per (type, draft).
	 *
	 * @param string $type           One of the TYPE_* constants.
	 * @param string $draft_id       Draft row UUID.
	 * @param int    $form_id        Form post ID.
	 * @param string $due_at         UTC mysql datetime the notification becomes due.
	 * @param string $now            UTC mysql datetime.
	 * @param string $recipient_hint Masked recipient for display.
	 * @param string $recipient_hash Hash of the normalised recipient.
	 * @since 2.12.9
	 * @return bool True when this call created it; false when it already existed.
	 */
	public static function enqueue( $type, $draft_id, $form_id, $due_at, $now, $recipient_hint = '', $recipient_hash = '' ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- INSERT IGNORE on the unique key is the once-only guard.
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} ( idempotency_key, type, draft_id, form_id, status, recipient_hint, recipient_hash, due_at, created_at ) VALUES ( %s, %s, %s, %d, %s, %s, %s, %s, %s )",
				self::key( $type, $draft_id ),
				$type,
				$draft_id,
				absint( $form_id ),
				self::STATUS_QUEUED,
				$recipient_hint,
				$recipient_hash,
				$due_at,
				$now
			)
		);

		return 1 === (int) $inserted;
	}

	/**
	 * Due notifications, oldest first.
	 *
	 * `$type` gives each kind its own batch budget. Sharing one meant a backlog of
	 * owner notices -- which any anonymous visitor can produce, one per abandoned
	 * draft -- filled the batch and pushed visitor reminders past the window in which
	 * they are still worth sending.
	 *
	 * @param string $now   UTC mysql datetime.
	 * @param int    $limit Batch size.
	 * @param string $type  One of the TYPE_* constants, or '' for every type.
	 * @since 2.12.9
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_due( $now, $limit, $type = '' ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		if ( '' !== $type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- batched scan on idx_status_due.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE type = %s AND status IN ( %s, %s ) AND due_at <= %s ORDER BY due_at ASC LIMIT %d",
					$type,
					self::STATUS_QUEUED,
					self::STATUS_RETRYING,
					$now,
					absint( $limit )
				),
				ARRAY_A
			);

			return is_array( $rows ) ? $rows : [];
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- batched scan on idx_status_due.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status IN ( %s, %s ) AND due_at <= %s ORDER BY due_at ASC LIMIT %d",
				self::STATUS_QUEUED,
				self::STATUS_RETRYING,
				$now,
				absint( $limit )
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * Claim a due notification for sending.
	 *
	 * Exactly one of several concurrent workers sees true.
	 *
	 * @param int    $id          Notification id.
	 * @param string $now         UTC mysql datetime.
	 * @param string $lease_until UTC mysql datetime after which an unfinished claim is stale.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function claim( $id, $now, $lease_until ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- atomic claim.
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, claimed_until = %s, attempts = attempts + 1 WHERE id = %d AND status IN ( %s, %s ) AND due_at <= %s",
				self::STATUS_CLAIMED,
				$lease_until,
				absint( $id ),
				self::STATUS_QUEUED,
				self::STATUS_RETRYING,
				$now
			)
		);

		return 1 === (int) $claimed;
	}

	/**
	 * Record the outcome of a claimed notification.
	 *
	 * @param int         $id     Notification id.
	 * @param string      $status Final or retry status.
	 * @param string      $reason Normalised reason code.
	 * @param string|null $due_at New due time for a retry; null to leave it.
	 * @param string|null $now    UTC mysql datetime, recorded as handed_off_at on a handoff.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function finish( $id, $status, $reason, $due_at = null, $now = null ) {
		global $wpdb;

		$fields = [
			'status'        => $status,
			'reason'        => substr( sanitize_key( $reason ), 0, 64 ),
			'claimed_until' => null,
		];
		if ( null !== $due_at ) {
			$fields['due_at'] = $due_at;
		}
		if ( self::STATUS_HANDED_OFF === $status && null !== $now ) {
			$fields['handed_off_at'] = $now;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- only the claim holder may record an outcome.
		return 1 === $wpdb->update(
			self::get_instance()->get_tablename(),
			$fields,
			[
				'id'     => absint( $id ),
				'status' => self::STATUS_CLAIMED,
			]
		);
	}

	/**
	 * Hand a claimed notification back to the queue without counting an attempt.
	 *
	 * Used when the draft is not due yet (the visitor came back) or when a daily
	 * ceiling is full, so the reminder is re-timed rather than dropped.
	 *
	 * @param int    $id     Notification id.
	 * @param string $due_at New due time.
	 * @param string $reason Why it is waiting, so one parked on a ceiling can be told
	 *                       apart from one that is simply not due yet.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function requeue( $id, $due_at, $reason = '' ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- claim-holder release.
		$released = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, due_at = %s, reason = %s, claimed_until = NULL, attempts = GREATEST( attempts, 1 ) - 1 WHERE id = %d AND status = %s",
				self::STATUS_QUEUED,
				$due_at,
				$reason,
				absint( $id ),
				self::STATUS_CLAIMED
			)
		);

		return 1 === (int) $released;
	}

	/**
	 * Resolve claims whose worker never recorded an outcome.
	 *
	 * Marked unknown, not re-queued: the worker may have died after wp_mail() handed the
	 * message off, and a blind resend would duplicate it.
	 *
	 * @param string $now UTC mysql datetime.
	 * @since 2.12.9
	 * @return int Rows resolved.
	 */
	public static function expire_stale_claims( $now ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- lease recovery.
		$resolved = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, reason = %s, claimed_until = NULL WHERE status = %s AND claimed_until IS NOT NULL AND claimed_until < %s",
				self::STATUS_UNKNOWN,
				'worker_lost',
				self::STATUS_CLAIMED,
				$now
			)
		);

		return absint( $resolved );
	}

	/**
	 * Suppress every pending notification of a draft.
	 *
	 * @param string $draft_id Draft row UUID.
	 * @param string $reason   Normalised reason code.
	 * @since 2.12.9
	 * @return int Rows suppressed.
	 */
	public static function suppress_pending_for_draft( $draft_id, $reason ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- bulk suppression.
		$suppressed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, reason = %s WHERE draft_id = %s AND status IN ( %s, %s )",
				self::STATUS_SUPPRESSED,
				substr( sanitize_key( $reason ), 0, 64 ),
				Helper::get_string_value( $draft_id ),
				self::STATUS_QUEUED,
				self::STATUS_RETRYING
			)
		);

		return absint( $suppressed );
	}

	/**
	 * Every notification row of a draft, newest first.
	 *
	 * @param string $draft_id Draft row UUID.
	 * @since 2.12.9
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_for_draft( $draft_id ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- admin detail read.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE draft_id = %s ORDER BY id DESC", Helper::get_string_value( $draft_id ) ),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * Latest status of one notification type for several drafts, in one query.
	 *
	 * @param array<int,mixed> $draft_ids Draft row UUIDs.
	 * @param string           $type      Notification type.
	 * @since 2.12.9
	 * @return array<string,string> draft UUID => status.
	 */
	public static function get_latest_status_for_drafts( array $draft_ids, $type ) {
		global $wpdb;
		$draft_ids = array_values( array_filter( array_map( [ Helper::class, 'get_string_value' ], $draft_ids ) ) );
		if ( empty( $draft_ids ) ) {
			return [];
		}
		$table        = self::get_instance()->get_tablename();
		$placeholders = implode( ', ', array_fill( 0, count( $draft_ids ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built from the id count.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT draft_id, status FROM {$table} WHERE type = %s AND draft_id IN ( {$placeholders} ) ORDER BY id ASC", array_merge( [ $type ], $draft_ids ) ), ARRAY_A );

		$map = [];
		foreach ( is_array( $rows ) ? $rows : [] as $row ) {
			$map[ Helper::get_string_value( $row['draft_id'] ) ] = Helper::get_string_value( $row['status'] );
		}
		return $map;
	}

	/**
	 * Delete the notification rows of the given drafts.
	 *
	 * @param array<int,string> $draft_ids Draft row UUIDs.
	 * @since 2.12.9
	 * @return void
	 */
	public static function delete_for_drafts( array $draft_ids ) {
		global $wpdb;
		$draft_ids = array_values( array_filter( array_map( 'strval', $draft_ids ) ) );
		if ( empty( $draft_ids ) ) {
			return;
		}
		$table        = self::get_instance()->get_tablename();
		$placeholders = implode( ', ', array_fill( 0, count( $draft_ids ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built from the id count.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE draft_id IN ( {$placeholders} )", $draft_ids ) );
	}

	/**
	 * Delete every notification row of a form. Recipient suppression rows carry no form
	 * and are kept, so a stop request outlives the form it was made from.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return void
	 */
	public static function delete_for_form( $form_id ) {
		global $wpdb;
		$form_id = absint( $form_id );
		if ( 0 === $form_id ) {
			return;
		}
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- cascade delete on one form id.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE form_id = %d", $form_id ) );
	}

	/**
	 * Stop every future reminder to a recipient.
	 *
	 * @param string $recipient_hash Hash of the normalised recipient.
	 * @param string $now            UTC mysql datetime.
	 * @since 2.12.9
	 * @return void
	 */
	public static function suppress_recipient( $recipient_hash, $now ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- idempotent marker insert.
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} ( idempotency_key, type, status, reason, recipient_hash, due_at, created_at ) VALUES ( %s, %s, %s, %s, %s, %s, %s )",
				self::key( self::TYPE_SUPPRESSION, $recipient_hash ),
				self::TYPE_SUPPRESSION,
				self::STATUS_SUPPRESSED,
				'stop_requested',
				$recipient_hash,
				$now,
				$now
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- bulk suppression.
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %s, reason = %s WHERE recipient_hash = %s AND type = %s AND status IN ( %s, %s )",
				self::STATUS_SUPPRESSED,
				'stop_requested',
				$recipient_hash,
				self::TYPE_VISITOR_REMINDER,
				self::STATUS_QUEUED,
				self::STATUS_RETRYING
			)
		);
	}

	/**
	 * Whether a recipient asked to stop reminders.
	 *
	 * @param string $recipient_hash Hash of the normalised recipient.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function is_recipient_suppressed( $recipient_hash ) {
		global $wpdb;
		if ( '' === $recipient_hash ) {
			return false;
		}
		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- must see the latest marker.
		return null !== $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE idempotency_key = %s LIMIT 1",
				self::key( self::TYPE_SUPPRESSION, $recipient_hash )
			)
		);
	}

	/**
	 * Visitor reminders this site has sent or is about to send since a point in time.
	 *
	 * Counts claimed rows as well as handed-off ones: a claim means the message is on
	 * its way out in this tick, so a ceiling that ignored them would let a single batch
	 * overshoot it. Used for the site-wide ceiling, which is what stops many forms each
	 * sitting under their own per-form cap from adding up to a flood.
	 *
	 * @param string $since          UTC mysql datetime.
	 * @param string $exclude_draft  Draft whose own notification should not count --
	 *                               the worker claims a row before deciding whether it
	 *                               may send, so without this a ceiling of N would stop
	 *                               the Nth send rather than the N+1th.
	 * @param string $type           Notification type to count. Each kind has its own
	 *                               ceiling, so they are counted apart.
	 * @since 2.12.9
	 * @return int
	 */
	public static function count_recent_site_sends( $since, $exclude_draft = '', $type = self::TYPE_VISITOR_REMINDER ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		if ( '' !== $exclude_draft ) {
			return absint(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$table} WHERE type = %s AND status IN ( %s, %s ) AND COALESCE( handed_off_at, created_at ) >= %s AND ( draft_id IS NULL OR draft_id != %s )",
						$type,
						self::STATUS_HANDED_OFF,
						self::STATUS_CLAIMED,
						$since,
						$exclude_draft
					)
				)
			);
		}

		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE type = %s AND status IN ( %s, %s ) AND COALESCE( handed_off_at, created_at ) >= %s",
					$type,
					self::STATUS_HANDED_OFF,
					self::STATUS_CLAIMED,
					$since
				)
			)
		);
	}

	/**
	 * Reminders already handed to the mail system, since a point in time.
	 *
	 * Counted per recipient (so many drafts naming one address cannot flood it) or, with
	 * an empty hash, per form.
	 *
	 * @param string $since          UTC mysql datetime.
	 * @param string $recipient_hash Recipient hash, or '' to count by form.
	 * @param int    $form_id        Form id when counting by form.
	 * @param string $type           Notification type to count.
	 * @since 2.12.9
	 * @return int
	 */
	public static function count_recent_handoffs( $since, $recipient_hash = '', $form_id = 0, $type = self::TYPE_VISITOR_REMINDER ) {
		global $wpdb;
		$table = self::get_instance()->get_tablename();

		if ( '' !== $recipient_hash ) {
			return absint(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$table} WHERE recipient_hash = %s AND type = %s AND status = %s AND handed_off_at >= %s",
						$recipient_hash,
						$type,
						self::STATUS_HANDED_OFF,
						$since
					)
				)
			);
		}

		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE form_id = %d AND type = %s AND status = %s AND handed_off_at >= %s",
					absint( $form_id ),
					$type,
					self::STATUS_HANDED_OFF,
					$since
				)
			)
		);
	}

	/**
	 * Idempotency key of a logical notification.
	 *
	 * @param string $type    Notification type.
	 * @param string $subject Draft UUID, or recipient hash for suppression rows.
	 * @since 2.12.9
	 * @return string
	 */
	private static function key( $type, $subject ) {
		return hash( 'sha256', Helper::get_string_value( $type ) . '|' . Helper::get_string_value( $subject ) );
	}
}
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
