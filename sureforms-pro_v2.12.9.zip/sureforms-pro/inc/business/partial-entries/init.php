<?php
/**
 * Partial Entries — Init.
 *
 * Wires up the Partial Entries surface: the per-form settings, the public
 * save / restore / discard endpoints, the admin list, detail, notes, export
 * and link endpoints, the admin submenu, and asset enqueue
 * (frontend capture + admin SPA). What happens to a capture over time —
 * inactivity, reminders, submission, retention — lives in Lifecycle; which
 * values may be captured lives in Capture_Policy.
 *
 * @package sureforms-pro
 * @since   2.9.0
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

use SRFM\Admin\Admin as Core_Admin;
use SRFM\Inc\Helper;
use SRFM\Inc\Submit_Token;
use SRFM_Pro\Inc\Business\Database\Tables\Partial_Notifications;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Save_Resume;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

/**
 * Partial Entries Init class.
 *
 * @since 2.9.0
 */
class Init {
	use Get_Instance;

	/**
	 * Admin submenu slug.
	 *
	 * @since 2.9.0
	 */
	public const PAGE_SLUG = 'sureforms_partial_entries';

	/**
	 * Maximum per-page for list endpoint — guards against heavy queries.
	 *
	 * @since 2.9.0
	 */
	public const MAX_PER_PAGE = 100;

	/**
	 * Allowed orderby columns for the list endpoint.
	 *
	 * @since 2.9.0
	 */
	public const ALLOWED_ORDERBY = [ 'id', 'form_id', 'date_created', 'updated_at', 'progress_percent' ];

	/**
	 * Field-name prefixes whose value identifies a person, best first.
	 *
	 * SureForms field names are `srfm-<type>-<blockId>-lbl-<label>-<slug>`, so the
	 * type is readable off the front of the key.
	 *
	 * @since x.x.x
	 */
	public const IDENTIFYING_FIELD_PREFIXES = [ 'srfm-email-', 'srfm-phone-', 'srfm-input-' ];

	/**
	 * Post meta key that stores the per-form feature toggle (JSON:
	 * `{"status":bool}`). Kept in sync with the JS settings module.
	 *
	 * @since 2.9.0
	 */
	public const META_KEY = '_srfm_partial_entries';

	/**
	 * Maximum accepted payload size (bytes) on the public save
	 * endpoint. Stops a runaway signature / base64 paste / huge
	 * textarea from blowing up a row. 64 KB is comfortable for a
	 * fully-filled form but refuses binary blobs.
	 *
	 * @since 2.9.0
	 */
	public const MAX_PAYLOAD_BYTES = 64 * 1024;

	/**
	 * Per-IP rate limit on the public save endpoint. Caps at
	 * `RATE_LIMIT_MAX` saves per `RATE_LIMIT_WINDOW` seconds per
	 * remote address. Sized around the expected normal cadence —
	 * one save per ~2.5 s (MIN_SAVE_INTERVAL on the client) plus
	 * headroom for multiple tabs and the occasional pagehide.
	 *
	 * @since 2.9.0
	 */
	public const RATE_LIMIT_MAX    = 60;
	public const RATE_LIMIT_WINDOW = 60; // seconds.

	/**
	 * Transient key caching the "is any form on this site enabled?"
	 * check. Saves the postmeta LIKE scan on every page load.
	 *
	 * @since 2.9.0
	 */
	public const ANY_ENABLED_TRANSIENT = 'srfm_partial_any_enabled';

	/**
	 * Lifecycle timing defaults and bounds. Delays are minutes, the rest are days.
	 * These are not form settings: each one is read through a filter in
	 * get_lifecycle_settings().
	 *
	 * @since 2.12.9
	 */
	public const DEFAULT_ABANDON_DELAY  = 30;
	public const MIN_ABANDON_DELAY      = 5;
	public const MAX_ABANDON_DELAY      = 1440;
	public const DEFAULT_REMINDER_DELAY = 45;
	public const MAX_REMINDER_DELAY     = 10080;
	public const DEFAULT_RETENTION_DAYS = 15;
	public const MAX_RETENTION_DAYS     = 365;
	public const DEFAULT_LINK_TTL_DAYS  = 15;
	public const MAX_LINK_TTL_DAYS      = 30;

	/**
	 * Constructor.
	 *
	 * @since 2.9.0
	 */
	public function __construct() {
		// Per-form enable/disable toggle, persisted as a JSON post_meta.
		// Hooked on the core "register additional meta" action so we
		// register at the same tick as Save & Resume / webhooks —
		// avoids any ordering edge cases with the post-type's own
		// meta registration pass.
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_form_meta' ] );

		// Gutenberg form-settings panel (sidebar toggle).
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ] );

		// Frontend capture asset — enqueued per rendered form, and only for forms
		// with capture on, so a page whose forms do not capture loads nothing.
		// Restoration is a no-store REST call made by that script: saved answers are
		// never printed into (cacheable) page HTML.
		add_action( 'srfm_enqueue_block_scripts', [ $this, 'enqueue_frontend_assets' ], 20 );

		// Admin screen — submenu + SPA asset.
		add_action( 'admin_menu', [ $this, 'register_menu' ], 30 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
		add_filter( 'srfm_is_dashboard_screen', [ $this, 'add_partial_entries_screen' ] );
		add_filter( 'srfm_admin_filter', [ $this, 'add_partial_entries_nav_item' ] );

		// REST endpoints.
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_rest_endpoints' ] );

		// Map partial-entries ZIP exports to a friendlier download name.
		add_filter( 'srfm_export_zip_filename', [ $this, 'filter_export_zip_filename' ], 10, 2 );

		// Accepted submissions, inactivity, reminders and retention are handled by
		// Lifecycle. A successful submit no longer deletes the capture outright: it is
		// marked submitted, its answers are dropped, and the row remains as the outcome
		// record and as a marker that rejects late autosaves. Rows captured before
		// the lifecycle existed have no expiry and are never swept automatically.
		Lifecycle::get_instance();

		// Bust the "any form enabled" transient whenever our toggle
		// meta changes — so flipping the switch takes effect on the
		// frontend without waiting for the 15-minute TTL.
		$bust = function ( $meta_id, $post_id, $meta_key ) {
			unset( $meta_id, $post_id );
			$this->bust_any_enabled_transient( $meta_key );
		};
		add_action( 'updated_post_meta', $bust, 10, 3 );
		add_action( 'added_post_meta', $bust, 10, 3 );
		add_action( 'deleted_post_meta', $bust, 10, 3 );

		// Cascade-delete partial rows when their parent form (post) is
		// removed. Without this, orphan rows accumulate indefinitely
		// on long-lived sites — listing endpoints would keep showing
		// entries for forms whose post no longer exists.
		add_action( 'before_delete_post', [ $this, 'delete_partials_for_form' ] );

		// Abandonment notifications — instantiate so its Action
		// Scheduler + submit-cancel hooks register.
		Partial_Entry_Notifier::get_instance();
	}

	/**
	 * Delete every partial row attached to a form when the form
	 * post is permanently removed. Hooked to `before_delete_post`
	 * so the cleanup runs while the post id is still valid.
	 *
	 * @since 2.9.0
	 * @param int $post_id Post id about to be deleted.
	 * @return void
	 */
	public function delete_partials_for_form( $post_id ) {
		$post_id = absint( $post_id );
		if ( 0 === $post_id ) {
			return;
		}
		if ( SRFM_FORMS_POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		global $wpdb;
		$table = Save_Resume::get_instance()->get_tablename();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- cascade delete on a single form id.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE form_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- internal table name.
				$post_id
			)
		);
		Partial_Notifications::delete_for_form( $post_id );
	}

	/**
	 * Delete the `any form enabled` transient when our toggle meta
	 * changes on any form. Called via closure from `updated_post_meta` /
	 * `added_post_meta` / `deleted_post_meta`.
	 *
	 * @param string $meta_key Meta key.
	 * @since 2.9.0
	 * @return void
	 */
	public function bust_any_enabled_transient( $meta_key ) {
		if ( self::META_KEY !== $meta_key ) {
			return;
		}
		delete_transient( self::ANY_ENABLED_TRANSIENT );
	}

	/**
	 * Register the `_srfm_partial_entries` post_meta so the form
	 * editor can read/write the toggle via useEntityProp.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function register_form_meta() {
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			self::META_KEY,
			[
				'type'              => 'string',
				'single'            => true,
				// 'edit' only — never 'view'. This blob holds the notification
				// recipient address; exposing it in the public 'view' REST context
				// would leak the address (and the admin fallback) to anonymous
				// callers of /wp/v2/sureforms_form. Mirrors the free plugin's
				// _srfm_email_notification, which is 'edit'-only for the same reason.
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'default'           => wp_json_encode( self::get_notify_defaults() ),
				'sanitize_callback' => static function ( $value ) {
					// Value may arrive as a JSON string (Gutenberg
					// useEntityProp path) or as an already-decoded
					// array (direct REST writes / CLI). Handle both.
					$decoded = $value;
					if ( is_string( $value ) ) {
						$parsed  = json_decode( $value, true );
						$decoded = is_array( $parsed ) ? $parsed : [];
					}
					if ( ! is_array( $decoded ) ) {
						$decoded = [];
					}

					return wp_json_encode( self::sanitize_settings( $decoded ) );
				},
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
			]
		);
	}

	/**
	 * Default values for the `_srfm_partial_entries` meta blob. Kept in
	 * one place so the meta `default`, the sanitize callback, and
	 * `get_notify_settings()` all agree on shape and fallbacks.
	 *
	 * @since 2.12.3
	 * @return array<string,mixed>
	 */
	public static function get_notify_defaults() {
		// `notify_recipient` intentionally defaults to '' (empty = "use the form's
		// notification email, then the site admin"), and the admin address is NOT baked
		// in here. A registered meta DEFAULT is world-readable regardless of the meta's
		// 'edit' REST context: WP_REST_Meta_Fields copies it into the meta field schema,
		// get_public_item_schema() only strips arg_options from TOP-LEVEL properties, and
		// rest_handle_options_request() runs on rest_pre_dispatch — before any
		// permission_callback. So an unauthenticated `OPTIONS /wp/v2/sureforms_form`
		// would echo the address back under
		// schema.properties.meta.properties._srfm_partial_entries.default.
		// The same value would also ride along in exported form JSON, which is meant to
		// be shared. The editor prefills the field from a localised placeholder instead
		// (see the partial-entries settings script), and resolve_recipient() applies the
		// real fallbacks at send time.
		//
		// The lifecycle keys (since 2.12.9) default to the behaviour a form had before they
		// existed: capture_mode '' behaves as "any meaningful value", no disclosure, and no
		// visitor reminder. The editor applies the newer defaults (contact
		// gate, disclosure on) only when an author turns capture on, so an upgrade never
		// changes what an existing form does.
		return [
			'status'               => false,
			'resume'               => false,
			'notify'               => false,
			'notify_recipient'     => '',
			'capture_mode'         => '',
			'disclosure'           => false,
			'excluded_fields'      => [],
			'reminder'             => false,
			'reminder_email_field' => '',
			'reminder_subject'     => '',
			'reminder_body'        => '',
			'reminder_from_name'   => '',
			'reminder_from_email'  => '',
			'reminder_reply_to'    => '',
		];
	}

	/**
	 * Normalise a decoded `_srfm_partial_entries` blob.
	 *
	 * Every key is rebuilt from the defaults, so unknown keys are dropped. Lifecycle
	 * timing is not stored here; see get_lifecycle_settings().
	 *
	 * @param array<string,mixed> $decoded Decoded blob.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public static function sanitize_settings( array $decoded ) {
		$defaults = self::get_notify_defaults();
		$bool     = static function ( $key ) use ( $decoded, $defaults ) {
			return isset( $decoded[ $key ] ) ? wp_validate_boolean( $decoded[ $key ] ) : (bool) $defaults[ $key ];
		};
		$block_id = static function ( $key ) use ( $decoded ) {
			return substr( sanitize_key( Helper::get_string_value( $decoded[ $key ] ?? '' ) ), 0, 64 );
		};

		// "Send to" override. Keep a valid submitted address; otherwise
		// store '' (meaning "use the form's notification email, then the
		// site admin" — resolved at send time). Never bake in admin_email:
		// this value is persisted and would otherwise leak, and an empty
		// field must mean "use default", not "mail the admin". Rewriting
		// '' to the admin address here would also silently re-route any
		// form that deliberately relied on the notification-email fallback,
		// the moment someone opened and saved this tab.
		$recipient = '';
		if ( isset( $decoded['notify_recipient'] ) ) {
			$candidate = sanitize_email( Helper::get_string_value( $decoded['notify_recipient'] ) );
			$recipient = is_email( $candidate ) ? $candidate : '';
		}

		$mode = Helper::get_string_value( $decoded['capture_mode'] ?? '' );

		$excluded = [];
		if ( isset( $decoded['excluded_fields'] ) && is_array( $decoded['excluded_fields'] ) ) {
			foreach ( array_slice( $decoded['excluded_fields'], 0, 100 ) as $id ) {
				$id = substr( sanitize_key( Helper::get_string_value( $id ) ), 0, 64 );
				if ( '' !== $id ) {
					$excluded[] = $id;
				}
			}
		}

		return [
			'status'               => $bool( 'status' ),
			'resume'               => $bool( 'resume' ),
			'notify'               => $bool( 'notify' ),
			'notify_recipient'     => $recipient,
			'capture_mode'         => in_array( $mode, [ 'contact', 'meaningful' ], true ) ? $mode : '',
			'disclosure'           => $bool( 'disclosure' ),
			'excluded_fields'      => array_values( array_unique( $excluded ) ),
			'reminder'             => $bool( 'reminder' ),
			'reminder_email_field' => $block_id( 'reminder_email_field' ),
			'reminder_subject'     => substr( sanitize_text_field( Helper::get_string_value( $decoded['reminder_subject'] ?? '' ) ), 0, 200 ),
			'reminder_body'        => substr( wp_kses_post( Helper::get_string_value( $decoded['reminder_body'] ?? '' ) ), 0, 5000 ),
			'reminder_from_name'   => substr( sanitize_text_field( Helper::get_string_value( $decoded['reminder_from_name'] ?? '' ) ), 0, 200 ),
			'reminder_from_email'  => self::sanitize_address_list( $decoded['reminder_from_email'] ?? '', 1 ),
			'reminder_reply_to'    => self::sanitize_address_list( $decoded['reminder_reply_to'] ?? '' ),
		];
	}

	/**
	 * Keep the valid entries of a comma-separated address list: real addresses and the
	 * `{admin_email}` tag. Anything else, including header-breaking input, is dropped.
	 *
	 * @param mixed $value Submitted list.
	 * @param int   $limit Most entries kept.
	 * @since 2.12.9
	 * @return string
	 */
	public static function sanitize_address_list( $value, $limit = 20 ) {
		$kept = [];
		foreach ( explode( ',', Helper::get_string_value( $value ) ) as $entry ) {
			$entry = trim( $entry );
			if ( '{admin_email}' === $entry ) {
				$kept[] = $entry;
				continue;
			}
			// Kept only when sanitising leaves it unchanged, so a malformed entry is
			// dropped rather than rewritten into some other address.
			if ( '' !== $entry && sanitize_email( $entry ) === $entry && is_email( $entry ) ) {
				$kept[] = $entry;
			}
		}
		return implode( ', ', array_slice( array_values( array_unique( $kept ) ), 0, $limit ) );
	}

	/**
	 * Read the abandonment-notification settings for a form, merged
	 * over the defaults so callers always get a complete array.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return array<string,mixed>
	 */
	public static function get_notify_settings( $form_id ) {
		$form_id  = absint( $form_id );
		$settings = self::get_notify_defaults();
		$raw      = 0 === $form_id ? '' : get_post_meta( $form_id, self::META_KEY, true );
		$decoded  = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : null;
		if ( is_array( $decoded ) ) {
			$settings = self::sanitize_settings( array_merge( $settings, $decoded ) );
		}
		return array_merge( $settings, self::get_lifecycle_settings( $form_id ) );
	}

	/**
	 * Lifecycle timing and the owner abandonment notice. These have no editor control;
	 * each is changed through its filter and clamped to its bounds here.
	 *
	 * An abandonment delay of 0 turns abandonment off for the form: drafts are never
	 * marked abandoned, so neither the owner notice nor the visitor reminder is sent.
	 * The reminder delay is raised to at least the abandonment delay, because it is
	 * measured from the same last activity.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return array{abandon_delay:int,reminder_delay:int,link_ttl_days:int,retention_days:int,owner_notice:bool}
	 */
	public static function get_lifecycle_settings( $form_id ) {
		$bounded = static function ( $value, $default, $min, $max ) {
			return max( $min, min( $max, is_numeric( $value ) ? intval( $value ) : $default ) );
		};

		$abandon_delay = $bounded( apply_filters( 'srfm_partial_abandon_delay', self::DEFAULT_ABANDON_DELAY, $form_id ), self::DEFAULT_ABANDON_DELAY, 0, self::MAX_ABANDON_DELAY );
		if ( 0 < $abandon_delay ) {
			$abandon_delay = max( self::MIN_ABANDON_DELAY, $abandon_delay );
		}
		$reminder_delay = $bounded( apply_filters( 'srfm_partial_reminder_delay', self::DEFAULT_REMINDER_DELAY, $form_id ), self::DEFAULT_REMINDER_DELAY, self::MIN_ABANDON_DELAY, self::MAX_REMINDER_DELAY );

		return [
			'abandon_delay'  => $abandon_delay,
			'reminder_delay' => max( $abandon_delay, $reminder_delay ),
			'link_ttl_days'  => $bounded( apply_filters( 'srfm_partial_link_ttl_days', self::DEFAULT_LINK_TTL_DAYS, $form_id ), self::DEFAULT_LINK_TTL_DAYS, 1, self::MAX_LINK_TTL_DAYS ),
			'retention_days' => $bounded( apply_filters( 'srfm_partial_retention_days', self::DEFAULT_RETENTION_DAYS, $form_id ), self::DEFAULT_RETENTION_DAYS, 1, self::MAX_RETENTION_DAYS ),
			/**
			 * Filter whether the site owner is emailed each time a draft is abandoned.
			 *
			 * Off by default. Abandonment is normal traffic, so a form that is left
			 * half-filled a few hundred times a day produces a few hundred emails a
			 * day, which is how the owner's inbox -- and the site's sending
			 * reputation -- get used up by anonymous visitors. The Partial Entries
			 * screen already lists every abandoned draft.
			 *
			 * @param bool $enabled Whether to email the owner on abandonment.
			 * @param int  $form_id Form post ID.
			 * @since 2.12.9
			 */
			'owner_notice'   => (bool) apply_filters( 'srfm_partial_owner_abandonment_notice', false, $form_id ),
		];
	}

	/**
	 * Whether per-entry abandonment notifications are active for a form.
	 * Requires capture (status) to also be on — notifying without
	 * capturing is a no-op.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return bool
	 */
	public static function is_notify_enabled( $form_id ) {
		$settings = self::get_notify_settings( $form_id );
		return ! empty( $settings['status'] ) && ! empty( $settings['notify'] );
	}

	/**
	 * Enqueue the Gutenberg sidebar settings panel (toggle tab).
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function enqueue_editor_assets() {
		// Only load on the SureForms form post-type editor.
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || SRFM_FORMS_POST_TYPE !== $screen->post_type ) {
			return;
		}

		$handle = 'package/business/srfmPartialEntriesSettings';
		$asset  = SRFM_PRO_DIR . 'dist/' . $handle . '.asset.php';
		$info   = file_exists( $asset )
			? include $asset
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-partial-entries-settings',
			SRFM_PRO_URL . 'dist/' . $handle . '.js',
			$info['dependencies'],
			$info['version'],
			true
		);

		// Surface where an empty "Send to" actually resolves, as editor HELP TEXT only —
		// never as the registered meta default, which WP publishes through the
		// unauthenticated OPTIONS schema and which rides along in exported form JSON
		// (see get_notify_defaults()).
		//
		// Resolved through the notifier's own chain rather than get_option('admin_email'):
		// a form with its own notification recipient does NOT fall back to the admin, so
		// showing the admin address here would misreport the common case.
		//
		// Gated explicitly rather than relying on the CPT's manage_options mapping — that
		// mapping lives in the free plugin and is reachable by third-party role filters,
		// and the whole point of this change is that the address should not leak.
		$default_recipient = Helper::current_user_can()
			? Partial_Entry_Notifier::get_instance()->get_default_recipient( absint( get_the_ID() ) )
			: '';

		wp_localize_script(
			SRFM_PRO_SLUG . '-partial-entries-settings',
			'srfmPartialEntriesSettings',
			[
				'defaultRecipient'       => is_email( $default_recipient ) ? $default_recipient : '',
				'defaultReminderSubject' => Lifecycle::default_reminder_subject(),
				'defaultReminderBody'    => Lifecycle::default_reminder_body(),
				'siteUrl'                => home_url(),
				// Whether the *form* has a captcha is NOT localised here: it was read
				// once when the editor loaded, so an owner who added one in the Security
				// tab and came straight back was still warned they had none. settings.js
				// reads `_srfm_captcha_security_type` from core/editor's edited meta.
				//
				// Whether a provider has a *site key* is localised, because that lives
				// in site-wide settings rather than post meta, so it cannot go stale as
				// the form is edited. Booleans only -- the keys themselves never leave
				// the server.
				'captchaKeys'            => self::configured_captcha_providers(),
			]
		);

		// The reminder message is edited in the classic (TinyMCE) editor.
		wp_enqueue_editor();

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-partial-entries-settings' );
	}

	/**
	 * Check whether partial entry capture is enabled for a given form.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.9.0
	 * @return bool
	 */
	public static function is_enabled_for_form( $form_id ) {
		$form_id = absint( $form_id );
		if ( 0 === $form_id ) {
			return false;
		}
		$raw = get_post_meta( $form_id, self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return false;
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) && ! empty( $decoded['status'] );
	}

	/**
	 * Check whether the "Resume from last step" toggle is on for a given form.
	 * Requires capture (status) to also be enabled — resume without capture
	 * is a no-op.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.9.0
	 * @return bool
	 */
	public static function is_resume_enabled_for_form( $form_id ) {
		if ( ! self::is_enabled_for_form( $form_id ) ) {
			return false;
		}
		$raw = get_post_meta( absint( $form_id ), self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return false;
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) && ! empty( $decoded['resume'] );
	}

	/**
	 * Cheap site-wide check: is any form's `_srfm_partial_entries`
	 * meta currently `status:true`? Cached for 15 minutes. Busted by
	 * the `update_post_meta` / `add_post_meta` hooks for our meta
	 * key so toggling a form takes effect immediately.
	 *
	 * Returning false short-circuits the frontend enqueue — no JS,
	 * no heartbeat, nothing — on sites that haven't turned the
	 * feature on for any form yet.
	 *
	 * @since 2.9.0
	 * @return bool
	 */
	public static function any_form_enabled() {
		$cached = get_transient( self::ANY_ENABLED_TRANSIENT );
		if ( false !== $cached ) {
			return 'yes' === $cached;
		}

		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- cached in transient for 15 min; cheap LIKE scan on postmeta indexed by meta_key.
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s LIMIT 1",
				self::META_KEY,
				'%"status":true%'
			)
		);

		$enabled = ! empty( $found );
		set_transient( self::ANY_ENABLED_TRANSIENT, $enabled ? 'yes' : 'no', 15 * MINUTE_IN_SECONDS );
		return $enabled;
	}

	/**
	 * Enqueue the frontend capture script for one rendered form.
	 *
	 * Hooked per form render, so the bundle and its REST traffic exist only on pages
	 * that render a form with capture on. Each form's public configuration is added as
	 * an inline script keyed by form id, which keeps several forms on one page apart.
	 *
	 * @param array<string,mixed> $args Block render args; `attr.formId` carries the form id.
	 * @since 2.9.0
	 * @since 2.12.9 Runs per rendered form instead of site-wide, and no longer uses Heartbeat.
	 * @return void
	 */
	public function enqueue_frontend_assets( $args = [] ) {
		$form_id = is_array( $args ) && isset( $args['attr'] ) && is_array( $args['attr'] ) && isset( $args['attr']['formId'] )
			? absint( $args['attr']['formId'] )
			: 0;
		if ( 0 === $form_id || ! self::is_enabled_for_form( $form_id ) || Capture_Policy::is_no_store_form( $form_id ) ) {
			return;
		}

		static $configured = [];
		$handle            = SRFM_PRO_SLUG . '-partialEntries';

		if ( ! wp_script_is( $handle, 'enqueued' ) ) {
			$script_asset_path = SRFM_PRO_DIR . 'dist/partialEntries.asset.php';
			$script_info       = file_exists( $script_asset_path )
				? include $script_asset_path
				: [
					'dependencies' => [],
					'version'      => SRFM_PRO_VER,
				];

			wp_enqueue_script(
				$handle,
				SRFM_PRO_URL . 'dist/partialEntries.js',
				array_unique( array_merge( (array) $script_info['dependencies'], [ 'srfm-form-submit' ] ) ),
				$script_info['version'],
				true
			);

			$privacy_url = get_privacy_policy_url();

			wp_localize_script(
				$handle,
				'srfm_partial_entries',
				[
					'rest_url'      => esc_url_raw( rest_url( 'sureforms/v1/partial-entries/save' ) ),
					'restore_url'   => esc_url_raw( rest_url( 'sureforms/v1/partial-entries/restore' ) ),
					'discard_url'   => esc_url_raw( rest_url( 'sureforms/v1/partial-entries/discard' ) ),
					'link_arg'      => Lifecycle::LINK_ARG,
					'cookie_prefix' => 'srfm_partial_resume_',
					'cookie_days'   => 7,
					'privacy_url'   => is_string( $privacy_url ) ? esc_url_raw( $privacy_url ) : '',
					'i18n'          => [
						'disclosure'                       => __( 'Your progress is saved as you fill out this form.', 'sureforms-pro' ),
						'reminder_consent'                 => __( 'Email me a link to finish this form later.', 'sureforms-pro' ),
						'reminder_consent_failed'          => __( 'We could not confirm the verification. Please tick the box again.', 'sureforms-pro' ),
						'reminder_consent_address_changed' => __( 'Your email address changed, so the reminder box was cleared. Tick it again to ask for a reminder.', 'sureforms-pro' ),
						'privacy_link'                     => __( 'See our privacy notice.', 'sureforms-pro' ),
						'link_invalid'                     => __( 'This link has expired or is no longer available. You can fill out the form again below.', 'sureforms-pro' ),
						'restored'                         => __( 'Welcome back — we restored what you had already filled in.', 'sureforms-pro' ),
						'start_over'                       => __( 'Start over', 'sureforms-pro' ),
						'restored_cleared'                 => __( 'Cleared. You are starting from a blank form.', 'sureforms-pro' ),
						'reminder_consent_invalid_email'   => __( 'Enter a valid email address to get a reminder link.', 'sureforms-pro' ),
					],
				]
			);

			Pro_Helper::register_script_translations( $handle );
		}

		if ( isset( $configured[ $form_id ] ) ) {
			return;
		}
		$configured[ $form_id ] = true;

		wp_add_inline_script(
			$handle,
			'window.srfmPartialForms = window.srfmPartialForms || {}; window.srfmPartialForms[' . $form_id . '] = ' . wp_json_encode( self::get_public_form_config( $form_id ) ) . ';',
			'before'
		);
	}

	/**
	 * Which captcha providers actually have a site key saved, as booleans.
	 *
	 * A form can name a provider whose keys were never filled in. Free then renders no
	 * widget at all, so there is nothing for the opt-in to mint from and nothing to
	 * challenge a visitor with -- but the form still *says* it has a captcha, so the
	 * editor's "no CAPTCHA" warning stayed hidden and the owner was told nothing.
	 *
	 * Presence only. The keys never leave the server.
	 *
	 * @since 2.12.9
	 * @return array<string,bool>
	 */
	public static function configured_captcha_providers() {
		$options = get_option( 'srfm_security_settings_options' );
		$options = is_array( $options ) ? $options : [];

		$filled = static function ( $key ) use ( $options ) {
			return '' !== trim( Helper::get_string_value( $options[ $key ] ?? '' ) );
		};

		return [
			'cf-turnstile' => $filled( 'srfm_cf_turnstile_site_key' ),
			'hcaptcha'     => $filled( 'srfm_hcaptcha_site_key' ),
			'v2-checkbox'  => $filled( 'srfm_v2_checkbox_site_key' ),
			'v2-invisible' => $filled( 'srfm_v2_invisible_site_key' ),
			'v3-reCAPTCHA' => $filled( 'srfm_v3_site_key' ),
		];
	}

	/**
	 * The capture rules the browser needs to apply before sending anything.
	 *
	 * Block ids and switches only — never recipients, templates or other settings. The
	 * server re-applies every rule (see Capture_Policy); this only stops the browser
	 * from transmitting data the server would refuse to keep.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public static function get_public_form_config( $form_id ) {
		$settings = self::get_notify_settings( $form_id );

		return [
			'resume'           => ! empty( $settings['resume'] ),
			'mode'             => 'contact' === $settings['capture_mode'] ? 'contact' : 'meaningful',
			'excluded_fields'  => $settings['excluded_fields'],
			'disclosure'       => ! empty( $settings['disclosure'] ),
			// Only where a reminder could actually be sent: asking for permission the
			// form can never act on is worse than not asking.
			'reminder_consent' => '' === Capture_Policy::get_reminder_config_error( $form_id, $settings ),
			// The block the consent belongs beside. Without it the box is appended to
			// the end of the form, which page-break and conversational visitors who
			// leave early never see.
			'reminder_field'   => Helper::get_string_value( $settings['reminder_email_field'] ?? '' ),
		];
	}

	/**
	 * Register the WP admin submenu under SureForms.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function register_menu() {
		if ( ! Helper::current_user_can() ) {
			return;
		}

		// Use the same capability filter the gate above uses, so a
		// site that overrides Helper::current_user_can() doesn't
		// land on the submenu showing then denying access — the
		// menu and the page must agree.
		$capability = apply_filters( 'srfm_partial_entries_admin_capability', 'manage_options' );

		add_submenu_page(
			'sureforms_menu',
			__( 'Partial Entries', 'sureforms-pro' ),
			__( 'Partial Entries', 'sureforms-pro' ),
			$capability,
			self::PAGE_SLUG,
			[ $this, 'render_page' ],
			6
		);
	}

	/**
	 * Render the admin page root — React SPA mounts here.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function render_page() {
		echo '<div id="srfm-partial-entries-root" class="srfm-admin-wrapper"></div>';
	}

	/**
	 * Flag this screen as a SureForms dashboard screen so core's
	 * admin chrome renders around it.
	 *
	 * @param bool $is_dashboard_screen Current state.
	 * @since 2.9.0
	 * @return bool
	 */
	public function add_partial_entries_screen( $is_dashboard_screen ) {
		if ( $is_dashboard_screen ) {
			return $is_dashboard_screen;
		}

		return Helper::validate_request_context( self::PAGE_SLUG, 'page' );
	}

	/**
	 * Append a Partial Entries nav item to the SureForms admin header.
	 *
	 * @param array<string,mixed> $localization_data Current localization data.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function add_partial_entries_nav_item( $localization_data ) {
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		if ( ! isset( $localization_data['additional_header_nav_items'] ) || ! is_array( $localization_data['additional_header_nav_items'] ) ) {
			$localization_data['additional_header_nav_items'] = [];
		}

		$localization_data['additional_header_nav_items'][] = [
			'slug' => self::PAGE_SLUG,
			'text' => __( 'Partial Entries', 'sureforms-pro' ),
			'link' => get_site_url() . '/wp-admin/admin.php?page=' . self::PAGE_SLUG,
		];

		return $localization_data;
	}

	/**
	 * Enqueue the admin SPA on the Partial Entries screen only.
	 *
	 * @param string $hook_prefix Current admin page hook.
	 * @since 2.9.0
	 * @return void
	 */
	public function enqueue_admin_assets( $hook_prefix ) {
		if ( 'sureforms_page_' . self::PAGE_SLUG !== $hook_prefix ) {
			return;
		}

		$asset_handle      = 'partialEntriesAdmin';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$script_info['dependencies'],
			$script_info['version'],
			true
		);

		$css_file = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.css';
		if ( file_exists( $css_file ) ) {
			wp_enqueue_style(
				SRFM_PRO_SLUG . '-' . $asset_handle,
				SRFM_PRO_URL . 'dist/' . $asset_handle . '.css',
				[],
				SRFM_PRO_VER
			);
		}

		// Mirrors the Quiz Entries enqueue pattern verbatim so the
		// shared `<Header />` component (which reads `srfm_admin`
		// globals at module-load) receives the same keys it does on
		// every other SureForms admin screen.
		$is_license_active = class_exists( '\\SRFM_Pro\\Admin\\Licensing' )
			? \SRFM_Pro\Admin\Licensing::is_license_active()
			: false;

		$localization_data = [
			'site_url'                   => get_site_url(),
			'sureforms_dashboard_url'    => admin_url( '/admin.php?page=sureforms_menu' ),
			'plugin_version'             => defined( 'SRFM_VER' ) ? SRFM_VER : '',
			'global_settings_nonce'      => Helper::current_user_can() ? wp_create_nonce( 'wp_rest' ) : '',
			'is_pro_active'              => Helper::has_pro(),
			'is_license_active'          => $is_license_active,
			'is_first_form_created'      => class_exists( Core_Admin::class ) ? Core_Admin::is_first_form_created() : false,
			'check_three_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold() : false,
			'check_eight_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold( 8 ) : false,
			'pro_plugin_version'         => Helper::has_pro() && defined( 'SRFM_PRO_VER' ) ? SRFM_PRO_VER : '',
			'pro_plugin_name'            => Helper::has_pro() && defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Pro',
			'sureforms_pricing_page'     => Helper::get_sureforms_website_url( 'pricing' ),
		];

		$localization_data = apply_filters( 'srfm_admin_filter', $localization_data );
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		wp_add_inline_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'var srfm_admin = window.srfm_admin || {};',
			'before'
		);

		wp_localize_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'srfm_admin',
			$localization_data
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $asset_handle );
	}

	/**
	 * Register REST endpoints via the core `srfm_rest_api_endpoints` filter.
	 *
	 * @param array<string,mixed> $endpoints Existing endpoints.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function register_rest_endpoints( $endpoints ) {
		// Public save endpoint — protected by the form's HMAC submit
		// token, never by a nonce. Matches the core form-submit pattern
		// and stays cache-safe.
		$endpoints['partial-entries/restore'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_restore_data' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'form_id'    => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
				'session_id' => [
					'sanitize_callback' => static function ( $v ) {
						return substr( sanitize_text_field( wp_unslash( Helper::get_string_value( $v ) ) ), 0, 64 );
					},
				],
				'srfm_token' => [
					'sanitize_callback' => 'sanitize_text_field',
				],
				'link'       => [
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		];

		$endpoints['partial-entries/save'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'save_partial_entry' ],
			'permission_callback' => '__return_true',
			'args'                => [
				// Declared rather than coerced in the handler: REST's own boolean
				// sanitiser is the one that agrees with what the browser sends for
				// an unticked box, whichever of false, "false", 0 or "0" that is.
				'reminder_opt_in' => [
					'type'              => 'boolean',
					'default'           => false,
					'sanitize_callback' => 'rest_sanitize_boolean',
				],
				// A captcha token the browser minted for this opt-in alone. Never the
				// one in the form's own captcha field: those are single-use, and
				// verifying the submit's token here made the submit itself fail.
				// Bounded because no provider's response comes near it and an
				// unbounded string is a free way to make the server hash and store work.
				'consent_token'   => [
					'type'              => 'string',
					'default'           => '',
					'maxLength'         => 4096,
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		];

		// Public, authenticated by the delete token bound to the session.
		$endpoints['partial-entries/discard'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'discard_partial_entry' ],
			'permission_callback' => '__return_true',
		];

		$endpoints['partial-entries/test-reminder'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'send_test_reminder' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id' => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
			],
		];

		$id_arg = [
			'id' => [
				'required'          => true,
				'sanitize_callback' => static function ( $v ) {
					return sanitize_text_field( Helper::get_string_value( $v ) );
				},
			],
		];

		$endpoints['partial-entries/(?P<id>[a-f0-9-]+)/link'] = [
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'create_entry_link' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => $id_arg,
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'revoke_entry_link' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => $id_arg,
			],
		];

		$endpoints['partial-entries/list'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_partial_entries_list' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'  => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
				'status'   => [
					'sanitize_callback' => [ $this, 'sanitize_status_filter' ],
					'default'           => 'active',
				],
				'orderby'  => [
					'sanitize_callback' => [ $this, 'sanitize_orderby' ],
					'default'           => 'updated_at',
				],
				'order'    => [
					'sanitize_callback' => [ $this, 'sanitize_order' ],
					'default'           => 'DESC',
				],
				'per_page' => [
					'sanitize_callback' => [ $this, 'sanitize_per_page' ],
					'default'           => 20,
				],
				'page'     => [
					'sanitize_callback' => 'absint',
					'default'           => 1,
				],
				'search'   => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
			],
		];

		$endpoints['partial-entries/forms'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_forms_with_partials' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
		];

		$endpoints['partial-entries/detail'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_partial_entry_detail' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id' => [
					'required'          => true,
					'sanitize_callback' => static function ( $v ) {
						return sanitize_text_field( Helper::get_string_value( $v ) );
					},
				],
			],
		];

		$endpoints['partial-entries/(?P<id>[a-f0-9-]+)/notes'] = [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_entry_notes' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'       => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'per_page' => [
						'sanitize_callback' => [ $this, 'sanitize_per_page' ],
						'default'           => 3,
					],
					'page'     => [
						'sanitize_callback' => 'absint',
						'default'           => 1,
					],
				],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'   => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'note' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_textarea_field',
					],
				],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'      => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'note_id' => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return substr( sanitize_text_field( Helper::get_string_value( $v ) ), 0, 64 );
						},
						'validate_callback' => static function ( $v ) {
							return is_string( $v ) && '' !== $v && strlen( $v ) <= 64;
						},
					],
				],
			],
		];

		$endpoints['partial-entries/delete'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'delete_partial_entries' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'ids' => [
					'required'          => true,
					'sanitize_callback' => [ $this, 'sanitize_ids' ],
				],
			],
		];

		$endpoints['partial-entries/export'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'export_partial_entries' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'entry_ids' => [
					'sanitize_callback' => [ $this, 'sanitize_ids' ],
					'default'           => [],
				],
				'form_id'   => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Save a snapshot from the frontend capture script.
	 *
	 * Authenticated via the form's HMAC submit token — see `SRFM\Inc\Submit_Token`. No
	 * nonce is used (nor expected) because the endpoint must work on fully cached pages
	 * where no session cookie is set. The submit token only proves the request came
	 * from a rendered copy of this form; ownership of an existing capture is the random
	 * session id the browser holds.
	 *
	 * The response carries the capture's version. A write based on an older version is
	 * refused with 409 so the client can re-base its newer snapshot; a write to a capture
	 * that was submitted or deleted is refused with 410 so it cannot be revived.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @since 2.12.9 Filters through Capture_Policy and writes via Lifecycle::save_capture().
	 * @return array<string,mixed>|WP_Error
	 */
	public function save_partial_entry( WP_REST_Request $request ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- HMAC token auth, not nonce. See Submit_Token.
		$raw_body = $request->get_body();

		// Per-IP rate limit. Comes BEFORE size check + sanitize so a
		// flood of tiny / oversize / malformed requests can't churn
		// CPU on parsing.
		$rate_check = $this->check_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		// Payload-size guard, measured in bytes. 413 is the correct RFC status.
		if ( is_string( $raw_body ) && strlen( $raw_body ) > self::MAX_PAYLOAD_BYTES ) {
			return new WP_Error(
				'srfm_partial_payload_too_large',
				__( 'Partial entry payload is too large.', 'sureforms-pro' ),
				[ 'status' => 413 ]
			);
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$form_id      = isset( $params['form_id'] ) ? absint( $params['form_id'] ) : 0;
		$submit_token = isset( $params['submit_token'] ) ? Helper::get_string_value( $params['submit_token'] ) : '';
		$session_id   = self::sanitize_session_id( $params['session_id'] ?? '' );
		$form_data    = isset( $params['form_data'] ) && is_array( $params['form_data'] ) ? $params['form_data'] : [];
		$base_version = isset( $params['version'] ) && is_numeric( $params['version'] ) ? absint( $params['version'] ) : null;

		if ( 0 === $form_id || '' === $session_id ) {
			return new WP_Error( 'srfm_partial_invalid', __( 'Missing form or session identifier.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		if ( ! Submit_Token::verify( $submit_token, $form_id ) ) {
			return new WP_Error( 'srfm_partial_auth', __( 'Invalid submission token.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		// Respect the per-form toggle. Silently succeed when disabled
		// so no-op traffic from stale cached scripts doesn't surface
		// as an error to users.
		if ( ! self::is_enabled_for_form( $form_id ) ) {
			return [
				'success' => true,
				'skipped' => true,
			];
		}

		$settings = self::get_notify_settings( $form_id );
		$clean    = Capture_Policy::filter_payload( $form_id, $form_data, $settings );
		$blocked  = Capture_Policy::get_capture_block_reason( $form_id, $clean, $settings );
		if ( '' !== $blocked ) {
			return [
				'success' => true,
				'skipped' => true,
				'reason'  => $blocked,
			];
		}

		$trigger = isset( $params['last_trigger'] ) ? sanitize_key( Helper::get_string_value( $params['last_trigger'] ) ) : 'input';
		if ( ! in_array( $trigger, Save_Resume::ALLOWED_TRIGGERS, true ) ) {
			$trigger = 'input';
		}

		$referer = wp_get_referer();
		$result  = Lifecycle::get_instance()->save_capture(
			$form_id,
			$session_id,
			$clean,
			[
				'current_page'     => isset( $params['current_page'] ) ? absint( $params['current_page'] ) : 0,
				'progress_percent' => isset( $params['progress_percent'] ) ? absint( $params['progress_percent'] ) : 0,
				'last_trigger'     => $trigger,
				'source_url'       => is_string( $referer ) ? $referer : '',
				// The visitor's own tick, never inferred from the address they typed.
				'reminder_opt_in'  => true === $request->get_param( 'reminder_opt_in' ),
				// Only read when the opt-in asks for a new grant; see
				// Capture_Policy::may_grant_reminder_permission().
				'consent_token'    => Helper::get_string_value( $request->get_param( 'consent_token' ) ),
			],
			$base_version
		);

		switch ( $result['status'] ) {
			case 'gone':
				return new WP_Error( 'srfm_partial_gone', __( 'This saved progress is no longer available.', 'sureforms-pro' ), [ 'status' => 410 ] );
			case 'conflict':
				return new WP_Error(
					'srfm_partial_conflict',
					__( 'A newer copy of this progress exists.', 'sureforms-pro' ),
					[
						'status'  => 409,
						'version' => absint( $result['version'] ?? 0 ),
					]
				);
			case 'error':
				return new WP_Error( 'srfm_partial_save_failed', __( 'Could not save partial entry.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		$row_id = Helper::get_string_value( $result['id'] ?? '' );

		// The existing immediate partial-entry notice keeps its own opt-in and send-once
		// claim. It is independent of the owner abandonment notice sent by Lifecycle.
		if ( 'unchanged' !== $result['status'] && self::is_notify_enabled( $form_id ) ) {
			Partial_Entry_Notifier::get_instance()->notify_on_save( $row_id );
		}

		// Mint a signed token bound to this (form_id, session_id) pair. The client echoes
		// it back as `srfm_partial_delete_token` on the real submission, which is how the
		// accepted entry is linked to this capture without trusting a bare session id.
		return [
			'success'         => true,
			'id'              => $row_id,
			'version'         => absint( $result['version'] ?? 0 ),
			'delete_token'    => Resume_Token::issue( 'delete', $form_id, $session_id, Lifecycle::DELETE_TOKEN_TTL ),
			// What the row actually holds, which is not always what was asked for: a
			// refused grant unticks the box in the browser instead of leaving the
			// visitor looking at a promise this site never made.
			'reminder_opt_in' => ! empty( $result['reminder_opt_in'] ),
			// '' unless a tick was refused; 'invalid_email' or 'verification'. Chooses
			// the wording under the box, nothing else.
			'reminder_reason' => Helper::get_string_value( $result['reminder_refusal'] ?? '' ),
		];
	}

	/**
	 * Return saved progress so the form can be refilled.
	 *
	 * Two ways in: a continuation link token (from a reminder email or an admin-issued
	 * link), or the session id this browser already holds together with the form's
	 * submit token (same-device continuation, only when "Resume from last step" is on).
	 *
	 * The response is marked no-store and every refusal is identical, so it can neither
	 * be served from a shared cache nor used to probe which links or sessions exist. Only
	 * fields the current form still defines and permits are returned.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @since 2.12.9 Accepts expiring continuation links; responses are no-store.
	 * @return \WP_REST_Response|WP_Error
	 */
	public function get_restore_data( WP_REST_Request $request ) {
		$rate_check = $this->check_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		$form_id     = absint( $request->get_param( 'form_id' ) );
		$link_token  = sanitize_text_field( Helper::get_string_value( $request->get_param( 'link' ) ) );
		$unavailable = self::no_store_response(
			[
				'success' => false,
				'reason'  => 'unavailable',
			]
		);

		if ( 0 === $form_id || ! self::is_enabled_for_form( $form_id ) ) {
			return $unavailable;
		}

		if ( '' !== $link_token ) {
			$row = Lifecycle::resolve_continuation_token( $link_token, $form_id, time() );
			if ( empty( $row ) || '' === Helper::get_string_value( $row['session_id'] ?? '' ) ) {
				return $unavailable;
			}
			Lifecycle::record_link_opened( $row, time() );
			// That write advances activity_version. Handing the browser the version we
			// read a moment ago made the visitor's first save after every link restore
			// a guaranteed 409, so the row is re-read for the number it will base on.
			$fresh = Save_Resume::get( Helper::get_string_value( $row['id'] ?? '' ) );
			$row   = empty( $fresh ) ? $row : $fresh;
		} else {
			$session_id = self::sanitize_session_id( $request->get_param( 'session_id' ) );
			$token      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'srfm_token' ) ) );
			if ( '' === $session_id || ! self::is_resume_enabled_for_form( $form_id ) || ! Submit_Token::verify( $token, $form_id ) ) {
				return $unavailable;
			}
			$row = Save_Resume::find_capture( $form_id, $session_id );
			if ( empty( $row ) || ! Save_Resume::is_writable( $row ) ) {
				return $unavailable;
			}
		}

		$session_id = Helper::get_string_value( $row['session_id'] );
		$settings   = self::get_notify_settings( $form_id );
		$form_data  = Capture_Policy::filter_payload( $form_id, Helper::get_array_value( $row['form_data'] ?? [] ), $settings );

		// Merge `current_page` under the step key SaveResumeFrontend.restoreFormStep()
		// reads, so multi-step forms reopen at the visitor's last position.
		$current_page = absint( $row['current_page'] ?? 0 );
		if ( $current_page > 0 ) {
			$cf_meta           = get_post_meta( $form_id, '_srfm_conversational_form', true );
			$is_conversational = is_array( $cf_meta )
				&& isset( $cf_meta['is_cf_enabled'] )
				&& filter_var( $cf_meta['is_cf_enabled'], FILTER_VALIDATE_BOOLEAN );

			$form_data[ $is_conversational ? 'conversational-current-step' : 'page-break-current-step' ] = $current_page;
		}

		// Audit hook — sites can listen to log redemption attempts
		// (IP, form, redeemed-from-link-yes/no) for compliance.
		do_action( 'srfm_partial_resume_redeemed', $session_id, $form_id, '' !== $link_token, $this->get_client_ip() );

		return self::no_store_response(
			[
				'success'         => true,
				'session_id'      => $session_id,
				'form_data'       => $form_data,
				'current_page'    => $current_page,
				'version'         => absint( $row['activity_version'] ?? 0 ),
				// So the consent box comes back the way the visitor left it. Without
				// this it rendered unticked on every resume, and the first edit after
				// a resume withdrew the permission they had just been emailed about.
				'reminder_opt_in' => ! empty( Helper::get_array_value( Helper::get_array_value( $row['lifecycle'] ?? [] )['reminder_permission'] ?? [] )['granted'] ),
				'delete_token'    => Resume_Token::issue( 'delete', $form_id, $session_id, Lifecycle::DELETE_TOKEN_TTL ),
			]
		);
	}

	/**
	 * Discard this browser's saved progress ("Start over", or a visitor deleting it).
	 *
	 * Requires the delete token bound to the session, so knowing a session id is not
	 * enough to delete someone's draft. Always answers the same way.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.12.9
	 * @return array<string,mixed>|WP_Error
	 */
	public function discard_partial_entry( WP_REST_Request $request ) {
		$rate_check = $this->check_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$form_id    = isset( $params['form_id'] ) ? absint( $params['form_id'] ) : 0;
		$session_id = self::sanitize_session_id( $params['session_id'] ?? '' );
		$token      = sanitize_text_field( Helper::get_string_value( $params['delete_token'] ?? '' ) );

		if ( $form_id > 0 && '' !== $session_id && Resume_Token::verify( $token, 'delete', $form_id, $session_id ) ) {
			$row = Save_Resume::find_capture( $form_id, $session_id );
			if ( ! empty( $row ) && Save_Resume::is_writable( $row ) ) {
				Save_Resume::delete_entry( Helper::get_string_value( $row['id'] ) );
				Partial_Notifications::delete_for_drafts( [ Helper::get_string_value( $row['id'] ) ] );
			}
		}

		return [ 'success' => true ];
	}

	/**
	 * A capture session id: 16–64 characters of letters, digits and dashes, or ''.
	 *
	 * @param mixed $value Raw value.
	 * @since 2.12.9
	 * @return string
	 */
	public static function sanitize_session_id( $value ) {
		return is_string( $value ) && preg_match( '/^[A-Za-z0-9-]{16,64}$/', $value ) ? $value : '';
	}

	/**
	 * List partial entries for the admin screen.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function get_partial_entries_list( WP_REST_Request $request ) {
		$per_page = $this->sanitize_per_page( $request->get_param( 'per_page' ) );
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );
		$form_id  = absint( $request->get_param( 'form_id' ) );

		$where = self::status_where( $this->sanitize_status_filter( $request->get_param( 'status' ) ) );
		if ( $form_id > 0 ) {
			$where['form_id'] = $form_id;
		}

		$search_group = self::search_where( Helper::get_string_value( $request->get_param( 'search' ) ) );
		if ( ! empty( $search_group ) ) {
			$where[] = $search_group;
		}

		$total   = Save_Resume::get_instance()->get_total_count( $where );
		$entries = Save_Resume::get_instance()->get_records_by_args(
			[
				'where'   => $where,
				'orderby' => $this->sanitize_orderby( $request->get_param( 'orderby' ) ),
				'order'   => $this->sanitize_order( $request->get_param( 'order' ) ),
				'limit'   => $per_page,
				'offset'  => ( $page - 1 ) * $per_page,
			]
		);

		$entries  = is_array( $entries ) ? $entries : [];
		$statuses = Partial_Notifications::get_latest_status_for_drafts( array_column( $entries, 'id' ), Partial_Notifications::TYPE_VISITOR_REMINDER );
		foreach ( $entries as $index => $entry ) {
			$entries[ $index ]['reminder_status'] = $statuses[ Helper::get_string_value( $entry['id'] ?? '' ) ] ?? '';
		}

		return [
			'entries'      => array_map( [ $this, 'format_entry_for_list' ], $entries ),
			'total'        => $total,
			'per_page'     => $per_page,
			'current_page' => $page,
			'total_pages'  => $per_page ? (int) ceil( $total / $per_page ) : 1,
		];
	}

	/**
	 * Fetch a single partial entry for the detail view.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	/**
	 * Get paginated notes for a partial entry. Mirrors the shape of
	 * the Quiz notes endpoint so the admin UI can reuse the same
	 * list / pagination component.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_entry_notes( WP_REST_Request $request ) {
		$id       = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$per_page = $this->sanitize_per_page( $request->get_param( 'per_page' ) );
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );

		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		usort(
			$notes,
			static function ( $a, $b ) {
				return ( $b['timestamp'] ?? 0 ) - ( $a['timestamp'] ?? 0 );
			}
		);

		$total       = count( $notes );
		$total_pages = $per_page ? (int) ceil( $total / $per_page ) : 1;
		$offset      = ( $page - 1 ) * $per_page;
		$slice       = array_slice( $notes, $offset, $per_page );

		$formatted = [];
		foreach ( $slice as $note ) {
			if ( ! is_array( $note ) ) {
				continue;
			}
			// Legacy notes pre-date the per-note id field. Synthesise a
			// deterministic id from the (note, timestamp) pair so the
			// admin's delete-by-id flow keeps working across pages —
			// the previous `legacy-{$offset+$i}` form mutated with
			// pagination and broke deletion of older notes.
			$fallback_id = 'legacy-' . md5(
				Helper::get_string_value( $note['note'] ?? '' ) . '|' . Helper::get_string_value( $note['timestamp'] ?? '' )
			);
			$formatted[] = [
				'id'          => $note['id'] ?? $fallback_id,
				'note'        => $note['note'] ?? '',
				'timestamp'   => $note['timestamp'] ?? 0,
				'author'      => $note['author'] ?? 0,
				'author_name' => $note['author_name'] ?? __( 'Unknown', 'sureforms-pro' ),
			];
		}

		return [
			'notes'        => $formatted,
			'current_page' => $page,
			'per_page'     => $per_page,
			'total'        => $total,
			'total_pages'  => $total_pages,
		];
	}

	/**
	 * Add a new note to a partial entry.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function add_entry_note( WP_REST_Request $request ) {
		$id      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$content = sanitize_textarea_field( Helper::get_string_value( $request->get_param( 'note' ) ) );

		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}
		if ( '' === $content ) {
			return new WP_Error( 'srfm_partial_note_empty', __( 'Note content is required.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes        = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$current_user = wp_get_current_user();

		$new_note = [
			'id'          => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'srfm-partial-note-', true ),
			'note'        => $content,
			'timestamp'   => time(),
			'author'      => $current_user->ID,
			'author_name' => $current_user->display_name,
		];

		array_unshift( $notes, $new_note );

		if ( false === Save_Resume::update_entry( $id, [ 'notes' => $notes ] ) ) {
			return new WP_Error( 'srfm_partial_note_save_failed', __( 'Could not save note.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		return [ 'success' => true ];
	}

	/**
	 * Delete a specific note by id from a partial entry.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function delete_entry_note( WP_REST_Request $request ) {
		$id      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$note_id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'note_id' ) ) );

		if ( '' === $id || '' === $note_id ) {
			return new WP_Error( 'srfm_partial_note_invalid', __( 'Entry ID and note ID are required.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		$found = false;
		foreach ( $notes as $index => $note ) {
			if ( isset( $note['id'] ) && Helper::get_string_value( $note['id'] ) === $note_id ) {
				array_splice( $notes, $index, 1 );
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_Error( 'srfm_partial_note_not_found', __( 'Note not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		if ( false === Save_Resume::update_entry( $id, [ 'notes' => $notes ] ) ) {
			return new WP_Error( 'srfm_partial_note_delete_failed', __( 'Could not delete note.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		return [ 'success' => true ];
	}

	/**
	 * Return a `{ form_id => form_title }` map limited to forms that
	 * currently have at least one partial entry row.
	 *
	 * Feeds the admin "form switcher" dropdown so users don't see
	 * every form on the site, only those with abandonment data.
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function get_forms_with_partials() {
		global $wpdb;

		$table = Save_Resume::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is from internal class config; admin-only listing endpoint, caching via HTTP layer is sufficient for POC.
		$form_ids = $wpdb->get_col( "SELECT DISTINCT form_id FROM {$table} WHERE form_id > 0 ORDER BY form_id DESC" );

		$map = [];
		if ( is_array( $form_ids ) ) {
			foreach ( $form_ids as $form_id ) {
				$id = absint( $form_id );
				if ( 0 === $id ) {
					continue;
				}
				// 'raw' + cast, deliberately: the default 'display' context runs the
				// post_title filter, which is a documented public filter that WPML, SEO
				// and product-title plugins do hook — any of them can reintroduce
				// entity-encoded punctuation or inject markup into this payload. The cast
				// is required because get_post_field() returns int|string|int[], while this
				// method declares array<int,string>.
				$title      = (string) get_post_field( 'post_title', $id, 'raw' );
				$map[ $id ] = $title
					? $title
					/* translators: %d: form post ID */
					: sprintf( __( 'SureForms Form #%d', 'sureforms-pro' ), $id );
			}
		}

		return $map;
	}

	/**
	 * Fetch a single partial entry for the detail view.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_partial_entry_detail( WP_REST_Request $request ) {
		$id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		// Adjacent IDs for Prev/Next navigation on the detail page.
		// Scoped to the same form so navigation stays inside one
		// form's partials — mirrors the Entries detail behaviour.
		$navigation = Save_Resume::get_adjacent_ids( $id, absint( $entry['form_id'] ?? 0 ) );

		return [
			'entry'      => $this->format_entry_for_detail( $entry ),
			'navigation' => [
				'previous_id' => $navigation['previous_id'] ?? null,
				'next_id'     => $navigation['next_id'] ?? null,
			],
		];
	}

	/**
	 * Delete one or more partial entries.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function delete_partial_entries( WP_REST_Request $request ) {
		$ids = (array) $request->get_param( 'ids' );
		if ( empty( $ids ) ) {
			return [
				'success' => false,
				'deleted' => 0,
			];
		}

		$deleted = 0;
		$removed = [];
		foreach ( $ids as $id ) {
			$id = sanitize_text_field( Helper::get_string_value( $id ) );
			if ( '' === $id ) {
				continue;
			}
			if ( false !== Save_Resume::delete_entry( $id ) ) {
				$deleted++;
				$removed[] = $id;
			}
		}
		Partial_Notifications::delete_for_drafts( $removed );

		return [
			'success' => $deleted > 0,
			'deleted' => $deleted,
		];
	}

	/**
	 * Shape a raw DB row into a list-friendly response.
	 *
	 * @param array<string,mixed> $entry Raw DB row.
	 * @since 2.9.0
	 * @since 2.12.9 Adds lifecycle state, activity, expiry and linked-entry fields.
	 * @return array<string,mixed>
	 */
	public function format_entry_for_list( $entry ) {
		$form_id = absint( $entry['form_id'] ?? 0 );
		// Matches Entries' `form_permalink` shape: the post permalink
		// of the form, which — when the form has "Instant Form"
		// enabled — is the instant form page URL (core's
		// `template_redirect` → `srfm_instant_form_redirect`
		// resolves it). An empty string when the form has been
		// deleted so the client can fall back to a plain span.
		$permalink  = $form_id ? get_permalink( $form_id ) : '';
		$lifecycle  = is_array( $entry['lifecycle'] ?? null ) ? $entry['lifecycle'] : [];
		$permission = is_array( $lifecycle['reminder_permission'] ?? null ) ? $lifecycle['reminder_permission'] : [];

		return [
			'id'                 => Helper::get_string_value( $entry['id'] ?? '' ),
			'partial_entry_id'   => absint( $entry['partial_entry_id'] ?? 0 ),
			'form_id'            => $form_id,
			'form_title'         => $form_id ? (string) get_post_field( 'post_title', $form_id, 'raw' ) : '',
			'form_permalink'     => is_string( $permalink ) ? $permalink : '',
			'current_page'       => absint( $entry['current_page'] ?? 0 ),
			'progress_percent'   => absint( $entry['progress_percent'] ?? 0 ),
			'last_trigger'       => Helper::get_string_value( $entry['last_trigger'] ?? '' ),
			'first_value'        => $this->extract_first_value( Helper::get_array_value( $entry['form_data'] ?? [] ) ),
			'date_created'       => Helper::get_string_value( $entry['date_created'] ?? '' ),
			'updated_at'         => Helper::get_string_value( $entry['updated_at'] ?? $entry['date_created'] ?? '' ),
			'state'              => self::display_state( $entry ),
			'capture_source'     => Helper::get_string_value( $entry['capture_source'] ?? '' ),
			'last_activity_at'   => Helper::get_string_value( $entry['last_activity_at'] ?? '' ),
			'first_abandoned_at' => Helper::get_string_value( $entry['first_abandoned_at'] ?? '' ),
			'expires_at'         => Helper::get_string_value( $entry['expires_at'] ?? '' ),
			'submitted_entry_id' => absint( $entry['submitted_entry_id'] ?? 0 ),
			'link_assisted'      => ! empty( $lifecycle['completion']['link_assisted'] ),
			'reminder_status'    => Helper::get_string_value( $entry['reminder_status'] ?? '' ),
			'contact_summary'    => Helper::get_string_value( $permission['recipient_hint'] ?? '' ),
			'user_id'            => absint( $entry['user_id'] ?? 0 ),
			'user_name'          => self::display_name_for( absint( $entry['user_id'] ?? 0 ) ),
		];
	}

	/**
	 * Shape a raw DB row into the detail-view response.
	 *
	 * `form_data` is returned as an array of `{label, value,
	 * field_name, block_name}` objects — the same shape core's
	 * `/entry/{id}/details` endpoint emits, so the admin SPA can
	 * render rows without any client-side key parsing.
	 *
	 * No continuation link is minted here: viewing an entry must not create a working
	 * credential. The admin generates one explicitly through the link endpoint.
	 *
	 * @param array<string,mixed> $entry Raw DB row.
	 * @since 2.9.0
	 * @since 2.12.9 Adds the notification history and lifecycle timeline; no longer mints a link.
	 * @return array<string,mixed>
	 */
	public function format_entry_for_detail( $entry ) {
		$id            = Helper::get_string_value( $entry['id'] ?? '' );
		$notifications = '' !== $id ? Partial_Notifications::get_for_draft( $id ) : [];

		$entry['reminder_status'] = self::latest_status( $notifications, Partial_Notifications::TYPE_VISITOR_REMINDER );

		$base              = $this->format_entry_for_list( $entry );
		$base['form_data'] = $this->build_labeled_form_data(
			Helper::get_array_value( $entry['form_data'] ?? [] )
		);

		$lifecycle = is_array( $entry['lifecycle'] ?? null ) ? $entry['lifecycle'] : [];
		$recovery  = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];

		$base['resume_enabled'] = self::is_resume_enabled_for_form( absint( $entry['form_id'] ?? 0 ) );
		$base['can_issue_link'] = Save_Resume::SOURCE_AUTOMATIC === ( $entry['capture_source'] ?? '' )
			&& '' !== Helper::get_string_value( $entry['session_id'] ?? '' )
			&& in_array( $entry['state'] ?? '', Save_Resume::WRITABLE_STATES, true );
		$base['link_expires']   = Helper::get_string_value( $recovery['link_expires'] ?? '' );
		$base['notifications']  = array_map(
			static function ( $row ) {
				return [
					'type'           => Helper::get_string_value( $row['type'] ?? '' ),
					'status'         => Helper::get_string_value( $row['status'] ?? '' ),
					'reason'         => Helper::get_string_value( $row['reason'] ?? '' ),
					'recipient_hint' => Helper::get_string_value( $row['recipient_hint'] ?? '' ),
					'attempts'       => absint( $row['attempts'] ?? 0 ),
					'due_at'         => Helper::get_string_value( $row['due_at'] ?? '' ),
					'handed_off_at'  => Helper::get_string_value( $row['handed_off_at'] ?? '' ),
					'created_at'     => Helper::get_string_value( $row['created_at'] ?? '' ),
				];
			},
			$notifications
		);
		$base['timeline']       = self::build_timeline( $entry, $notifications );

		return $base;
	}

	/**
	 * Normalise the list status filter.
	 *
	 * @param mixed $status Raw value.
	 * @since 2.12.9
	 * @return string
	 */
	public function sanitize_status_filter( $status ) {
		$status = sanitize_key( Helper::get_string_value( $status ) );
		return in_array( $status, [ 'active', 'all', 'in_progress', 'saved', 'abandoned', 'completed' ], true ) ? $status : 'active';
	}

	/**
	 * Issue a continuation link for a draft, for the owner to share.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.12.9
	 * @return array<string,mixed>|WP_Error
	 */
	public function create_entry_link( WP_REST_Request $request ) {
		$id  = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$row = Save_Resume::get( $id );
		if ( empty( $row ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}
		if ( Save_Resume::SOURCE_AUTOMATIC !== ( $row['capture_source'] ?? '' ) || '' === Helper::get_string_value( $row['session_id'] ?? '' ) || ! in_array( $row['state'] ?? '', Save_Resume::WRITABLE_STATES, true ) ) {
			return new WP_Error( 'srfm_partial_link_unavailable', __( 'A continuation link cannot be created for this entry.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		// Deliberate: an administrator pressing this is the one action allowed to
		// issue a link again after the draft's links were revoked.
		$link = Lifecycle::get_instance()->issue_continuation_link( $row, time(), true );
		if ( '' === $link['url'] ) {
			// Two different failures used to share one message. A window too short to
			// mint a link is permanent and worth saying; losing the compare-and-set to a
			// visitor's autosave, or having the write vetoed, is a race that succeeds on
			// the next press -- and telling the admin the entry was expiring was simply
			// wrong.
			if ( ! empty( $link['conflict'] ) ) {
				return new WP_Error( 'srfm_partial_link_conflict', __( 'This entry changed while the link was being created. Please try again.', 'sureforms-pro' ), [ 'status' => 409 ] );
			}
			return new WP_Error( 'srfm_partial_link_unavailable', __( 'This entry expires too soon to create a link.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		return [
			'success'    => true,
			'url'        => $link['url'],
			'expires_at' => Lifecycle::utc_datetime( $link['expires_ts'] ),
		];
	}

	/**
	 * Invalidate every continuation link of a draft.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.12.9
	 * @return array<string,mixed>|WP_Error
	 */
	public function revoke_entry_link( WP_REST_Request $request ) {
		$id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		if ( ! Lifecycle::revoke_links( $id ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}
		return [ 'success' => true ];
	}

	/**
	 * Send the form's reminder template to the current admin, filled with sample values.
	 *
	 * Never touches a real draft: the links in it point nowhere usable, and no reminder
	 * slot or suppression state is consumed.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.12.9
	 * @return array<string,mixed>|WP_Error
	 */
	public function send_test_reminder( WP_REST_Request $request ) {
		$form_id = absint( $request->get_param( 'form_id' ) );
		$user    = wp_get_current_user();
		$to      = $user instanceof \WP_User ? sanitize_email( $user->user_email ) : '';
		if ( 0 === $form_id || SRFM_FORMS_POST_TYPE !== get_post_type( $form_id ) || ! is_email( $to ) ) {
			return new WP_Error( 'srfm_partial_test_invalid', __( 'A test reminder could not be sent.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$sample   = home_url( '/' );
		$settings = self::get_notify_settings( $form_id );
		$message  = Lifecycle::render_reminder(
			$settings,
			[
				'form_title'   => (string) get_post_field( 'post_title', $form_id, 'raw' ),
				'continue_url' => $sample,
				'expiry_date'  => Helper::get_string_value( wp_date( Helper::get_string_value( get_option( 'date_format' ) ), time() + absint( $settings['link_ttl_days'] ) * DAY_IN_SECONDS ) ),
				'stop_url'     => $sample,
			]
		);

		/* translators: %s: reminder email subject. */
		$sent = Lifecycle::send_html_mail( $to, sprintf( __( '[Test] %s', 'sureforms-pro' ), $message['subject'] ), $message['body'], Lifecycle::mail_headers( $settings ) );

		return [
			'success'   => true === $sent,
			'recipient' => $to,
		];
	}

	/**
	 * Clamp per_page into a sane range.
	 *
	 * @param mixed $per_page Raw value.
	 * @since 2.9.0
	 * @return int
	 */
	public function sanitize_per_page( $per_page ) {
		$per_page = absint( $per_page );
		if ( 0 === $per_page ) {
			$per_page = 20;
		}
		return min( self::MAX_PER_PAGE, max( 1, $per_page ) );
	}

	/**
	 * Validate orderby against the allowlist.
	 *
	 * @param mixed $orderby Raw value.
	 * @since 2.9.0
	 * @return string
	 */
	public function sanitize_orderby( $orderby ) {
		$orderby = sanitize_text_field( Helper::get_string_value( $orderby ) );
		return in_array( $orderby, self::ALLOWED_ORDERBY, true ) ? $orderby : 'updated_at';
	}

	/**
	 * Normalize order direction.
	 *
	 * @param mixed $order Raw value.
	 * @since 2.9.0
	 * @return string
	 */
	public function sanitize_order( $order ) {
		return 'ASC' === strtoupper( sanitize_text_field( Helper::get_string_value( $order ) ) ) ? 'ASC' : 'DESC';
	}

	/**
	 * Accept ids as either JSON string or array, reduce to unique non-empty strings.
	 *
	 * @param mixed $ids Raw ids.
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function sanitize_ids( $ids ) {
		if ( is_string( $ids ) ) {
			$decoded = json_decode( $ids, true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$ids = $decoded;
			}
		}

		if ( ! is_array( $ids ) ) {
			return [];
		}

		$clean = [];
		foreach ( $ids as $id ) {
			$id = sanitize_text_field( Helper::get_string_value( $id ) );
			if ( '' !== $id ) {
				$clean[] = $id;
			}
		}
		return array_values( array_unique( $clean ) );
	}

	/**
	 * Map a partial-entries ZIP export to a friendlier download filename.
	 *
	 * Hooked to core's `srfm_export_zip_filename` filter so the AJAX
	 * downloader can serve both core entries and partial-entries
	 * archives without hardcoding either name.
	 *
	 * @param string              $filename  Default ZIP filename.
	 * @param array<string,mixed> $file_info pathinfo() result for the file being served.
	 * @since 2.9.0
	 * @return string
	 */
	public function filter_export_zip_filename( $filename, $file_info ) {
		$base = is_array( $file_info ) && isset( $file_info['filename'] ) ? Helper::get_string_value( $file_info['filename'] ) : '';
		if ( '' !== $base && str_contains( $base, 'partial' ) ) {
			return 'SureForms Partial Entries.zip';
		}
		return is_string( $filename ) ? $filename : 'SureForms Entries.zip';
	}

	/**
	 * Export partial entries as CSV (single form) or ZIP (multiple forms).
	 *
	 * Mirrors `SRFM\Inc\Rest_Api::export_entries` / `Entries_Class::export_entries`
	 * so the download UX and file-streaming path are identical. Reuses the
	 * existing `srfm_download_export` AJAX action.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return \WP_REST_Response|WP_Error
	 */
	public function export_partial_entries( WP_REST_Request $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Security verification failed. Please refresh the page and try again.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_ids = Helper::get_array_value( $request->get_param( 'entry_ids' ) );
		$form_id   = absint( $request->get_param( 'form_id' ) );

		// Fetch rows — either the selected subset or all rows for the given form filter.
		if ( ! empty( $entry_ids ) ) {
			$rows = Save_Resume::get_instance()->get_results( [ 'id' => $entry_ids ] );
		} else {
			$where = [];
			if ( $form_id > 0 ) {
				$where['form_id'] = $form_id;
			}
			$rows = Save_Resume::get_instance()->get_records_by_args(
				[
					'where'   => $where,
					'orderby' => 'updated_at',
					'order'   => 'DESC',
				],
				false
			);
		}

		$rows = is_array( $rows ) ? $rows : [];

		if ( empty( $rows ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'No partial entries found to export.', 'sureforms-pro' ) ],
				400
			);
		}

		// Group rows by form_id.
		$rows_by_form = [];
		foreach ( $rows as $row ) {
			$fid = absint( $row['form_id'] ?? 0 );
			if ( ! isset( $rows_by_form[ $fid ] ) ) {
				$rows_by_form[ $fid ] = [];
			}
			$rows_by_form[ $fid ][] = $row;
		}

		$is_single_form = count( $rows_by_form ) === 1;

		$temp_dir = wp_normalize_path( trailingslashit( get_temp_dir() ) );

		if ( ! wp_is_writable( $temp_dir ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Temporary directory is not writable.', 'sureforms-pro' ) ],
				500
			);
		}

		$zip       = null;
		$temp_zip  = '';
		$csv_files = [];

		if ( ! $is_single_form ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'ZipArchive class is not available.', 'sureforms-pro' ) ],
					500
				);
			}
			$temp_zip = $temp_dir . 'srfm-partial-entries-export-' . time() . '.zip';
			$zip      = new \ZipArchive();
			if ( ! $zip->open( $temp_zip, \ZipArchive::CREATE ) ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'Unable to create ZIP file.', 'sureforms-pro' ) ],
					500
				);
			}
		}

		$csv_filepath = '';

		foreach ( $rows_by_form as $fid => $form_rows ) {
			// 'raw' avoids the post_title filter (see get_forms_with_partials()), and the
			// cast keeps sanitize_title() below off a non-string return.
			$form_title           = $fid ? (string) get_post_field( 'post_title', $fid, 'raw' ) : '';
			$sanitized_form_title = sanitize_title( $form_title );
			$sanitized_form_title = ! empty( $sanitized_form_title ) ? $sanitized_form_title : "srfm-partial-entries-{$fid}";
			$csv_filename         = 'srfm-partial-entries-' . $sanitized_form_title . '.csv';
			$csv_filepath         = $temp_dir . $csv_filename;

			if ( file_exists( $csv_filepath ) ) {
				unlink( $csv_filepath ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			}

			$stream = fopen( $csv_filepath, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen
			if ( ! is_resource( $stream ) ) {
				continue;
			}
			$csv_files[] = $csv_filepath;

			// Build field label map from all rows for this form.
			$excluded      = Helper::get_excluded_fields();
			$block_key_map = [];
			$block_labels  = [];
			foreach ( $form_rows as $row ) {
				$form_data = is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [];
				foreach ( $form_data as $srfm_key => $value ) {
					if ( in_array( $srfm_key, $excluded, true ) ) {
						continue;
					}
					$block_id = Helper::get_block_id_from_key( $srfm_key );
					if ( empty( $block_id ) ) {
						continue;
					}
					$block_key_map[ $block_id ] = $srfm_key;
					$block_labels[ $block_id ]  = self::get_export_header_label( $srfm_key );
				}
			}

			// Header row.
			$header = array_merge(
				[
					__( 'Entry ID', 'sureforms-pro' ),
					__( 'Form', 'sureforms-pro' ),
					__( 'Date Created', 'sureforms-pro' ),
					__( 'Last Activity', 'sureforms-pro' ),
					__( 'Progress', 'sureforms-pro' ),
					__( 'Step', 'sureforms-pro' ),
					__( 'Last Trigger', 'sureforms-pro' ),
				],
				array_values( $block_labels )
			);
			fputcsv( $stream, $header ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fputcsv

			// Data rows.
			foreach ( $form_rows as $row ) {
				$form_data = is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [];
				$data_row  = [
					absint( $row['partial_entry_id'] ?? 0 ),
					self::csv_escape_formula( $form_title ),
					self::csv_escape_formula( Helper::get_string_value( $row['date_created'] ?? '' ) ),
					self::csv_escape_formula( Helper::get_string_value( $row['updated_at'] ?? $row['date_created'] ?? '' ) ),
					absint( $row['progress_percent'] ?? 0 ) . '%',
					absint( $row['current_page'] ?? 0 ),
					self::csv_escape_formula( Helper::get_string_value( $row['last_trigger'] ?? '' ) ),
				];

				foreach ( $block_key_map as $srfm_key ) {
					$raw      = $form_data[ $srfm_key ] ?? '';
					$filtered = apply_filters( 'srfm_normalize_csv_field_value', $raw, $srfm_key );
					if ( is_string( $filtered ) && $filtered !== $raw ) {
						$data_row[] = self::csv_escape_formula( $filtered );
					} elseif ( is_array( $raw ) ) {
						$data_row[] = self::csv_escape_formula( implode( ', ', array_map( 'sanitize_text_field', $raw ) ) );
					} else {
						$data_row[] = self::csv_escape_formula( sanitize_text_field( Helper::get_string_value( $raw ) ) );
					}
				}

				fputcsv( $stream, $data_row ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fputcsv
			}

			fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose

			if ( ! $is_single_form && $zip && filesize( $csv_filepath ) > 0 ) {
				$zip->addFile( $csv_filepath, $csv_filename );
			}
		}

		// Single form → return CSV directly.
		if ( $is_single_form && '' !== $csv_filepath && file_exists( $csv_filepath ) ) {
			return new \WP_REST_Response(
				[
					'success'      => true,
					'filename'     => basename( $csv_filepath ),
					'filepath'     => $csv_filepath,
					'type'         => 'csv',
					'download_url' => add_query_arg(
						'_wpnonce',
						wp_create_nonce( 'srfm_download_export' ),
						admin_url( 'admin-ajax.php?action=srfm_download_export&file=' . rawurlencode( basename( $csv_filepath ) ) )
					),
				],
				200
			);
		}

		// Multiple forms → return ZIP.
		if ( ! $is_single_form && $zip ) {
			$zip->close();
			foreach ( $csv_files as $csv_file ) {
				if ( file_exists( $csv_file ) ) {
					unlink( $csv_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				}
			}
			return new \WP_REST_Response(
				[
					'success'      => true,
					'filename'     => 'SureForms Partial Entries.zip',
					'filepath'     => $temp_zip,
					'type'         => 'zip',
					'download_url' => add_query_arg(
						'_wpnonce',
						wp_create_nonce( 'srfm_download_export' ),
						admin_url( 'admin-ajax.php?action=srfm_download_export&file=' . rawurlencode( basename( $temp_zip ) ) )
					),
				],
				200
			);
		}

		return new \WP_REST_Response(
			[ 'error' => __( 'Unable to generate export file.', 'sureforms-pro' ) ],
			400
		);
	}

	/**
	 * A REST response that no shared or browser cache may store.
	 *
	 * @param array<string,mixed> $data Response body.
	 * @since 2.12.9
	 * @return \WP_REST_Response
	 */
	private static function no_store_response( array $data ) {
		$response = new \WP_REST_Response( $data, 200 );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, private, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );
		return $response;
	}

	/**
	 * The state shown to the site owner, including the pre-lifecycle legacy rows.
	 *
	 * @param array<string,mixed> $entry Raw DB row.
	 * @since 2.12.9
	 * @return string in_progress|abandoned|saved|submitted.
	 */
	private static function display_state( array $entry ) {
		$state = Helper::get_string_value( $entry['state'] ?? '' );
		if ( '' !== $state ) {
			return $state;
		}
		return '' === Helper::get_string_value( $entry['session_id'] ?? '' ) || 'saved' === ( $entry['last_trigger'] ?? '' )
			? Save_Resume::STATE_SAVED
			: Save_Resume::STATE_IN_PROGRESS;
	}

	/**
	 * Status of the newest notification of a type in a list, or ''.
	 *
	 * @param array<int,array<string,mixed>> $notifications Rows, newest first.
	 * @param string                         $type          Notification type.
	 * @since 2.12.9
	 * @return string
	 */
	private static function latest_status( array $notifications, $type ) {
		foreach ( $notifications as $row ) {
			if ( ( $row['type'] ?? '' ) === $type ) {
				return Helper::get_string_value( $row['status'] ?? '' );
			}
		}
		return '';
	}

	/**
	 * Chronological lifecycle events for the detail view.
	 *
	 * @param array<string,mixed>            $entry         Raw DB row.
	 * @param array<int,array<string,mixed>> $notifications Notification rows.
	 * @since 2.12.9
	 * @return array<int,array{at:string,label:string}>
	 */
	private static function build_timeline( array $entry, array $notifications ) {
		$events    = [];
		$lifecycle = is_array( $entry['lifecycle'] ?? null ) ? $entry['lifecycle'] : [];
		$recovery  = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];
		$add       = static function ( $at, $label ) use ( &$events ) {
			$at = Helper::get_string_value( $at );
			if ( '' !== $at ) {
				$events[] = [
					'at'    => $at,
					'label' => $label,
				];
			}
		};

		// date_created is a TIMESTAMP, read back in the DB session's time zone; every
		// lifecycle column is UTC, so convert it before the events are compared.
		$add( self::db_time_to_utc( $entry['date_created'] ?? '' ), __( 'Progress saved', 'sureforms-pro' ) );
		$add( $lifecycle['explicit_save'] ?? '', __( 'Saved by the visitor to finish later', 'sureforms-pro' ) );
		$add( $entry['first_abandoned_at'] ?? '', __( 'Marked abandoned after inactivity', 'sureforms-pro' ) );

		$labels = [
			Partial_Notifications::TYPE_VISITOR_REMINDER  => __( 'Visitor reminder', 'sureforms-pro' ),
			Partial_Notifications::TYPE_OWNER_ABANDONMENT => __( 'Owner abandonment notice', 'sureforms-pro' ),
		];
		foreach ( array_reverse( $notifications ) as $row ) {
			$type = Helper::get_string_value( $row['type'] ?? '' );
			if ( ! isset( $labels[ $type ] ) ) {
				continue;
			}
			/* translators: %s: notification name. */
			$add( $row['created_at'] ?? '', sprintf( __( '%s queued', 'sureforms-pro' ), $labels[ $type ] ) );
			/* translators: %s: notification name. */
			$add( $row['handed_off_at'] ?? '', sprintf( __( '%s handed to the mail system', 'sureforms-pro' ), $labels[ $type ] ) );
		}

		$add( $recovery['opened_at'] ?? '', __( 'Continuation link opened', 'sureforms-pro' ) );
		$add( $recovery['continued_at'] ?? '', __( 'Visitor continued from the link', 'sureforms-pro' ) );

		$submitted = absint( $entry['submitted_entry_id'] ?? 0 );
		$add(
			$entry['submitted_at'] ?? '',
			$submitted
				/* translators: %d: entry ID. */
				? sprintf( __( 'Submitted as entry #%d', 'sureforms-pro' ), $submitted )
				: __( 'Submitted (entry not stored)', 'sureforms-pro' )
		);

		usort(
			$events,
			static function ( $a, $b ) {
				return strcmp( $a['at'], $b['at'] );
			}
		);

		return $events;
	}

	/**
	 * Convert a TIMESTAMP value read in the DB session's time zone to UTC.
	 *
	 * @param mixed $value `Y-m-d H:i:s` in the session time zone.
	 * @since 2.12.9
	 * @return string UTC `Y-m-d H:i:s`, or '' for an empty value.
	 */
	private static function db_time_to_utc( $value ) {
		static $offset = null;
		$value         = Helper::get_string_value( $value );
		$ts            = '' !== $value ? strtotime( $value . ' UTC' ) : false;
		if ( false === $ts ) {
			return '';
		}
		if ( null === $offset ) {
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one constant read per request.
			$offset = intval( $wpdb->get_var( 'SELECT TIMESTAMPDIFF( SECOND, UTC_TIMESTAMP(), NOW() )' ) );
		}
		return gmdate( 'Y-m-d H:i:s', $ts - $offset );
	}

	/**
	 * WHERE group for the admin list search box.
	 *
	 * Searches the display id, the form title, the stored snapshot and the Save &
	 * Resume address, so looking an abandoned lead up by their email works -- which
	 * is the whole point of the screen. Mirrors Entries' own search
	 * (SRFM\Inc\Entries::get_entries_where()) so the two boxes behave the same.
	 *
	 * Returns [] for an empty term, which leaves the listing unfiltered. A term that
	 * produces no usable condition returns an impossible one instead, so a search
	 * never silently widens into "everything".
	 *
	 * @param string $search Raw search term.
	 * @since x.x.x
	 * @return array<int|string,mixed>
	 */
	private static function search_where( $search ) {
		global $wpdb;

		// Explicit length test, not ! empty(): empty( '0' ) is true in PHP, so
		// searching "0" would drop the group and return every row while the box
		// still showed the term.
		$search = trim( Helper::get_string_value( $search ) );
		if ( '' === $search ) {
			return [];
		}

		$group = [ 'RELATION' => 'OR' ];

		// Numeric terms are the display id -- exact and indexed.
		if ( is_numeric( $search ) ) {
			$group[] = [
				'key'     => 'partial_entry_id',
				'compare' => '=',
				'value'   => absint( $search ),
			];
		}

		$form_ids = self::form_ids_by_title( $search );
		if ( ! empty( $form_ids ) ) {
			$group[] = [
				'key'     => 'form_id',
				'compare' => 'IN',
				'value'   => $form_ids,
			];
		}

		// form_data holds plain JSON (Helper::encode_json() passes
		// JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), so a LIKE matches the
		// captured values textually -- emails, URLs and non-ASCII alike. The query
		// compiler wraps the value in "%...%" itself; esc_like() makes a typed "%"
		// or "_" match literally.
		//
		// Three characters minimum: the LIKE is a full scan of a LONGTEXT column and
		// a one- or two-character term would match nearly every row for the highest
		// possible cost. Same floor Entries uses.
		if ( mb_strlen( $search ) >= 3 ) {
			$group[] = [
				'key'     => 'form_data',
				'compare' => 'LIKE',
				'value'   => $wpdb->esc_like( $search ),
			];
			$group[] = [
				'key'     => 'email',
				'compare' => 'LIKE',
				'value'   => $wpdb->esc_like( $search ),
			];
		}

		// Only RELATION left: nothing matched, so match nothing. An OR group with no
		// conditions is dropped by the compiler, which would return the full list.
		if ( 1 === count( $group ) ) {
			return [
				[
					'key'     => 'partial_entry_id',
					'compare' => '=',
					'value'   => 0,
				],
			];
		}

		return $group;
	}

	/**
	 * Form post IDs whose title matches the term.
	 *
	 * @param string $search Raw search term.
	 * @since x.x.x
	 * @return array<int,int>
	 */
	private static function form_ids_by_title( $search ) {
		$ids = get_posts(
			[
				'post_type'      => SRFM_FORMS_POST_TYPE,
				'post_status'    => 'any',
				's'              => $search,
				// Title only. Without this WP_Query also searches post_content, which
				// for a form is its serialised blocks -- so a term that happened to
				// appear in a block attribute would pull in every entry of that form.
				'search_columns' => [ 'post_title' ],
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);

		return is_array( $ids ) ? array_map( 'absint', $ids ) : [];
	}

	/**
	 * Where-clauses for a status filter.
	 *
	 * @param string $status Normalised filter.
	 * @since 2.12.9
	 * @return array<int|string,mixed>
	 */
	private static function status_where( $status ) {
		$clause = static function ( $key, $compare, $value ) {
			return [
				'key'     => $key,
				'compare' => $compare,
				'value'   => $value,
			];
		};

		switch ( $status ) {
			case 'in_progress':
			case 'saved':
			case 'abandoned':
				return [ [ $clause( 'state', '=', $status ) ] ];
			case 'completed':
				// Submitted after having been abandoned; first_abandoned_at is NULL otherwise.
				return [
					[
						$clause( 'state', '=', Save_Resume::STATE_SUBMITTED ),
						$clause( 'first_abandoned_at', '>=', '1970-01-02 00:00:00' ),
					],
				];
			case 'all':
				return [];
			default:
				return [ [ $clause( 'state', '!=', Save_Resume::STATE_SUBMITTED ) ] ];
		}
	}

	/**
	 * Transform a raw `field_name => value` map into the labeled
	 * `[{label, value, ...}]` shape expected by the admin UI. The
	 * label-extraction logic intentionally matches core Entries
	 * (`Rest_Api::get_entry_details`) so both screens parse field
	 * names identically.
	 *
	 * @param array<string,mixed> $raw_form_data Decoded form data.
	 * @since 2.9.0
	 * @return array<int,array<string,mixed>>
	 */
	private function build_labeled_form_data( $raw_form_data ) {
		$out = [];

		if ( empty( $raw_form_data ) || ! is_array( $raw_form_data ) ) {
			return $out;
		}

		// Same allowlist of internal keys Entries skips, plus our
		// own session-id hidden input which we never want to show.
		$excluded = [
			'srfm-honeypot-field',
			'g-recaptcha-response',
			'srfm-sender-email-field',
			'srfm_partial_session_id',
			'form-id',
		];

		foreach ( $raw_form_data as $field_name => $value ) {
			if ( ! is_string( $field_name ) || in_array( $field_name, $excluded, true ) ) {
				continue;
			}
			if ( false === strpos( $field_name, '-lbl-' ) ) {
				// Fields without the SureForms `-lbl-` marker are
				// either internal or third-party — skip to match
				// Entries' behaviour.
				continue;
			}

			// `srfm-email-<blockId>-lbl-<base64Label>-<slug>` →
			// base64Label is everything up to the next `-`.
			$label = $this->decode_field_label( $field_name );

			// Repeater rows arrive as a nested array —
			// `{0: {child_name: value, ...}, 1: {...}}` — because the
			// client unfolds `foo[0][bar]` bracket notation into real
			// nested structure. Flatten into one detail-page entry
			// per row, labeled `{Repeater Label} {n}`, with its
			// children listed underneath. Mirrors the rendering
			// Entries produces for real submissions.
			if ( is_array( $value ) && $this->is_repeater_value( $value ) ) {
				$row_index = 0;
				// Sort by numeric key so row order is stable.
				$rows = $value;
				ksort( $rows, SORT_NUMERIC );
				foreach ( $rows as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$row_index++;
					$children = [];
					foreach ( $row as $child_name => $child_value ) {
						if ( ! is_string( $child_name ) || false === strpos( $child_name, '-lbl-' ) ) {
							continue;
						}
						$decoded_child_label = $this->decode_field_label( $child_name );
						$children[]          = [
							'field_name' => $child_name,
							'label'      => $decoded_child_label ? $decoded_child_label : $child_name,
							'value'      => $child_value,
							'block_name' => Helper::get_block_name_from_field( $child_name ),
						];
					}
					$out[] = [
						'field_name' => $field_name . '[' . ( $row_index - 1 ) . ']',
						'label'      => sprintf( '%s %d', '' !== $label ? $label : 'Repeater', $row_index ),
						'value'      => $children,
						'block_name' => 'srfm/repeater-row',
					];
				}
				continue;
			}

			$out[] = [
				'field_name' => $field_name,
				'label'      => '' !== $label ? $label : $field_name,
				'value'      => $value,
				'block_name' => Helper::get_block_name_from_field( $field_name ),
			];
		}

		return $out;
	}

	/**
	 * Extract and decode the SureForms `-lbl-` label from a field
	 * name. Shared by the top-level loop and the repeater-row
	 * recursion.
	 *
	 * @param string $field_name Raw field name (`srfm-<type>-<id>-lbl-<b64>-<slug>`).
	 * @since 2.9.0
	 * @return string Decoded human label, or empty string when the
	 *                name has no `-lbl-` marker or the decode fails.
	 */
	private function decode_field_label( $field_name ) {
		if ( ! is_string( $field_name ) || false === strpos( $field_name, '-lbl-' ) ) {
			return '';
		}
		$parts      = explode( '-lbl-', $field_name );
		$label_part = isset( $parts[1] ) ? explode( '-', $parts[1] )[0] : '';
		$label      = $label_part ? Helper::decrypt( $label_part ) : '';
		return is_string( $label ) ? trim( wp_strip_all_tags( $label ) ) : '';
	}

	/**
	 * Detect a repeater-shaped value: an associative array whose
	 * keys are sequential integer indexes and whose leaves are
	 * themselves associative arrays of child fields. Exactly what
	 * PHP's $_POST parser produces for `foo[0][bar]=x` notation.
	 *
	 * Returns false for plain arrays (e.g. multi-select / checkbox
	 * groups) so those still render as a single comma-joined value.
	 *
	 * @param array<mixed> $value Candidate value.
	 * @since 2.9.0
	 * @return bool
	 */
	private function is_repeater_value( $value ) {
		if ( empty( $value ) ) {
			return false;
		}
		foreach ( $value as $k => $v ) {
			// Non-integer key → not a row-indexed repeater.
			if ( ! is_int( $k ) && ! ctype_digit( (string) $k ) ) {
				return false;
			}
			// Each row must itself be an array of children, not a scalar.
			if ( ! is_array( $v ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Pick the first visible string value out of `form_data` for the
	 * list-view "preview" column. Mirrors the Entries screen behaviour.
	 *
	 * @param array<string,mixed> $form_data Decoded form data.
	 * @since 2.9.0
	 * @return string
	 */
	private function extract_first_value( $form_data ) {
		$fallback = '';
		$best     = '';
		// Lower is better; count() means "no identifying field seen yet".
		$best_rank = count( self::IDENTIFYING_FIELD_PREFIXES );

		foreach ( $form_data as $key => $value ) {
			// Skip internal keys and non-SureForms fields.
			if ( ! is_string( $key ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}
			if ( ! is_scalar( $value ) || '' === trim( (string) $value ) ) {
				continue;
			}

			$clean = wp_strip_all_tags( (string) $value );

			if ( '' === $fallback ) {
				$fallback = $clean;
			}

			// Prefer something that identifies a person, email first. The column
			// exists so the owner knows who to follow up with, and the literally
			// first field is as likely to be a quantity or a dropdown -- "100"
			// names nobody.
			foreach ( self::IDENTIFYING_FIELD_PREFIXES as $rank => $prefix ) {
				if ( $rank < $best_rank && 0 === strpos( $key, $prefix ) ) {
					$best_rank = $rank;
					$best      = $clean;
				}
			}
		}

		return '' !== $best ? $best : $fallback;
	}

	/**
	 * Display name for the user a capture was made as, '' when logged out.
	 *
	 * @param int $user_id WP user ID, 0 for a visitor.
	 * @since x.x.x
	 * @return string
	 */
	private static function display_name_for( $user_id ) {
		if ( $user_id <= 0 ) {
			return '';
		}

		$user = get_userdata( $user_id );

		// A deleted user leaves the id behind on the row. Showing the bare id is more
		// honest than showing nothing, which would read as "logged out".
		return $user instanceof WP_User && '' !== $user->display_name
			? $user->display_name
			: sprintf( '#%d', $user_id );
	}

	/**
	 * Resolve the CSV header label for a submitted field key.
	 *
	 * The label is decoded out of the field key itself — and the key is accepted
	 * from the public save endpoint without being cross-checked against the form's
	 * block definitions, while `Helper::encrypt`/`decrypt` is unkeyed base64. So a
	 * label is submitter-controlled and must get the same formula neutralisation the
	 * data cells already receive; without it, `=cmd|'/c calc'!A1` lands unescaped in
	 * the header row of a CSV an admin later opens.
	 *
	 * @param string $srfm_key Submitted field key.
	 * @since 2.12.3
	 * @return string
	 */
	private static function get_export_header_label( $srfm_key ) {
		return self::csv_escape_formula( Helper::get_field_label_from_key( $srfm_key ) );
	}

	/**
	 * Prefix a string with a single apostrophe when its first
	 * character is one Excel/Sheets treats as a formula starter
	 * (`=`, `+`, `-`, `@`, tab, carriage return). Without this,
	 * an attacker who submits `=HYPERLINK(...)` into a free-text
	 * field gets formula execution when an admin opens the CSV.
	 *
	 * @param mixed $value Raw scalar to write to CSV.
	 * @since 2.9.0
	 * @return string
	 */
	private static function csv_escape_formula( $value ) {
		$str = Helper::get_string_value( $value );
		if ( '' === $str ) {
			return $str;
		}
		$first = substr( $str, 0, 1 );
		if ( in_array( $first, [ '=', '+', '-', '@', "\t", "\r" ], true ) ) {
			return "'" . $str;
		}
		return $str;
	}

	/**
	 * Enforce the per-IP rate limit on the public save endpoint.
	 *
	 * Returns a `WP_Error` with HTTP 429 when the current remote
	 * address has exceeded `RATE_LIMIT_MAX` saves within the last
	 * `RATE_LIMIT_WINDOW` seconds. Everyone else passes through.
	 *
	 * Sites fronted by a CDN / WAF that already rate-limits can set
	 * `srfm_partial_entries_rate_limit_enabled` to false to skip.
	 *
	 * @since 2.9.0
	 * @return WP_Error|true WP_Error on throttle, true otherwise.
	 */
	private function check_rate_limit() {
		/**
		 * Allow sites with upstream rate-limiting (CDN, WAF) to
		 * disable the transient-based counter.
		 *
		 * @param bool $enabled Whether to enforce the rate limit.
		 * @since 2.9.0
		 */
		if ( ! apply_filters( 'srfm_partial_entries_rate_limit_enabled', true ) ) {
			return true;
		}

		$ip = $this->get_client_ip();
		if ( '' === $ip ) {
			// Can't identify the client — skip rather than blanket-deny.
			return true;
		}

		$key = 'srfm_partial_rl_' . md5( $ip );

		// On sites with a real (persistent) object cache, atomically
		// increment via wp_cache_incr — eliminates the read-then-write
		// TOCTOU window between two concurrent requests. Falls back to
		// the transient pattern when no object cache is present.
		if ( wp_using_ext_object_cache() ) {
			$count = wp_cache_incr( $key, 1, 'srfm_partial_entries' );
			if ( false === $count || 1 === (int) $count ) {
				// First hit in this window — seed the TTL via add()
				// since wp_cache_incr cannot set expiry directly.
				wp_cache_add( $key, 1, 'srfm_partial_entries', self::RATE_LIMIT_WINDOW );
				$count = 1;
			}
			if ( (int) $count > self::RATE_LIMIT_MAX ) {
				return new WP_Error(
					'srfm_partial_rate_limited',
					__( 'Too many requests. Please slow down.', 'sureforms-pro' ),
					[ 'status' => 429 ]
				);
			}
			return true;
		}

		$raw_count = get_transient( $key );
		$count     = is_numeric( $raw_count ) ? (int) $raw_count : 0;

		if ( $count >= self::RATE_LIMIT_MAX ) {
			return new WP_Error(
				'srfm_partial_rate_limited',
				__( 'Too many requests. Please slow down.', 'sureforms-pro' ),
				[ 'status' => 429 ]
			);
		}

		// Re-set with the remaining TTL preserved — WP transients
		// don't expose read-then-touch, so we accept the window
		// sliding forward on each write. Good enough on no-object-cache
		// hosts where wp_cache_incr fall-through to the same transient.
		set_transient( $key, $count + 1, self::RATE_LIMIT_WINDOW );
		return true;
	}

	/**
	 * Best-effort remote-IP lookup. Respects the standard proxy
	 * headers WP already trusts in `WP_Http::is_forwarded` patterns
	 * — but NEVER blindly trusts `X-Forwarded-For` unless the site
	 * has opted in via the filter (trusting it by default lets a
	 * client spoof their way past the rate limit).
	 *
	 * @since 2.9.0
	 * @return string
	 */
	private function get_client_ip() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- IP address validated via filter_var below.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';

		/**
		 * Set to a trusted proxy header name (e.g. `HTTP_X_FORWARDED_FOR`)
		 * ONLY if the site runs behind a reverse proxy that overwrites it.
		 * Trusting it by default would let a client spoof their IP.
		 *
		 * @param string $header Empty = ignore proxy headers.
		 * @since 2.9.0
		 */
		$proxy_header = (string) apply_filters( 'srfm_partial_entries_trusted_proxy_header', '' );
		if ( '' !== $proxy_header && ! empty( $_SERVER[ $proxy_header ] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- IP address validated via filter_var below.
			$forwarded = sanitize_text_field( wp_unslash( (string) $_SERVER[ $proxy_header ] ) );
			// Take the first IP in the list — that's the client.
			$parts = explode( ',', $forwarded );
			$ip    = trim( (string) $parts[0] );
		}

		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		return is_string( $ip ) ? $ip : '';
	}

}
