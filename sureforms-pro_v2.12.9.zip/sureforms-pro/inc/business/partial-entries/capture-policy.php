<?php
/**
 * Partial Entries — Capture policy.
 *
 * Decides, from the form's stored schema and settings rather than from anything the
 * browser claims, which submitted values an automatic capture may store and whether the
 * capture may happen at all. The client applies the same rules to avoid sending data it
 * should not, but this is the enforcing copy: a payload posted directly to the endpoint
 * goes through exactly the same filter.
 *
 * @package sureforms-pro
 * @since   2.12.9
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

use SRFM\Inc\Form_Submit;
use SRFM\Inc\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Capture policy.
 *
 * @since 2.12.9
 */
class Capture_Policy {
	/**
	 * Field types never captured automatically: credentials, payment data, files, owner
	 * hidden values and GDPR consent boxes (consent is never stored as a restorable
	 * answer).
	 *
	 * @since 2.12.9
	 */
	public const EXCLUDED_TYPES = [ 'srfm-password', 'srfm-payment', 'srfm-upload', 'srfm-signature', 'srfm-hidden', 'srfm-gdpr' ];

	/**
	 * Most fields one snapshot may carry.
	 *
	 * @since 2.12.9
	 */
	public const MAX_FIELDS = 200;

	/**
	 * Longest stored value, in characters.
	 *
	 * @since 2.12.9
	 */
	public const MAX_VALUE_LENGTH = 10000;

	/**
	 * Deepest accepted nesting (repeater row → child → multi-value).
	 *
	 * @since 2.12.9
	 */
	public const MAX_DEPTH = 3;

	/**
	 * Block names that may act as the reminder email field.
	 *
	 * @since 2.12.9
	 */
	public const EMAIL_BLOCKS = [ 'srfm/email' ];

	/**
	 * The action an opt-in captcha token is minted under, by the browser and by the
	 * providers that report one back. Mirrored in partial-entries.js.
	 *
	 * @since 2.12.9
	 */
	public const CONSENT_ACTION = 'srfm_partial_optin';

	/**
	 * Longest consent token worth sending to a provider. No provider's response comes
	 * near it; the REST schema bounds the same value.
	 *
	 * @since 2.12.9
	 */
	public const MAX_CONSENT_TOKEN_LENGTH = 4096;

	/**
	 * The field type of a SureForms field key: `srfm-email-<id>-lbl-…` → `srfm-email`.
	 *
	 * @param string $key Field key.
	 * @since 2.12.9
	 * @return string
	 */
	public static function get_key_type( $key ) {
		$parts = explode( '-', explode( '-lbl-', Helper::get_string_value( $key ) )[0] );
		return count( $parts ) >= 2 ? $parts[0] . '-' . $parts[1] : '';
	}

	/**
	 * The block id of a SureForms field key: `srfm-email-<id>-lbl-…` → `<id>`.
	 *
	 * @param string $key Field key.
	 * @since 2.12.9
	 * @return string
	 */
	public static function get_key_block_id( $key ) {
		$head = explode( '-lbl-', Helper::get_string_value( $key ) )[0];
		$pos  = strrpos( $head, '-' );
		return false === $pos ? '' : substr( $head, $pos + 1 );
	}

	/**
	 * Map of block id → block name for every field block in a form.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return array<string,string>
	 */
	public static function get_form_fields( $form_id ) {
		static $cache = [];

		$form_id = absint( $form_id );
		if ( isset( $cache[ $form_id ] ) ) {
			return $cache[ $form_id ];
		}

		$post   = $form_id ? get_post( $form_id ) : null;
		$fields = [];
		if ( $post instanceof \WP_Post && '' !== $post->post_content ) {
			self::collect_fields( parse_blocks( $post->post_content ), $fields );
		}

		$cache[ $form_id ] = $fields;
		return $fields;
	}

	/**
	 * Whether a form's compliance settings forbid storing its data.
	 *
	 * Mirrors the branch in core's handle_form_entry() that accepts a submission without
	 * storing it. Partial capture must not become a way around that choice.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function is_no_store_form( $form_id ) {
		$compliance = get_post_meta( absint( $form_id ), '_srfm_compliance', true );
		if ( ! is_array( $compliance ) || ! isset( $compliance[0] ) || ! is_array( $compliance[0] ) ) {
			return false;
		}
		return ! empty( $compliance[0]['gdpr'] ) && ! empty( $compliance[0]['do_not_store_entries'] );
	}

	/**
	 * Reduce a raw payload to the values an automatic capture may store.
	 *
	 * Keeps only SureForms field keys (`-lbl-`), drops the ones core's
	 * Field_Validation::strip_unknown_field_keys() does not recognise as this form's (it
	 * keeps every key when it cannot derive the form's fields, so this is not a hard
	 * allowlist on its own), drops excluded field types — at every nesting level —,
	 * and owner-excluded fields, and bounds field count,
	 * nesting and value length. Non-field keys (session ids, tokens, internal inputs)
	 * never survive.
	 *
	 * @param int                 $form_id  Form post ID.
	 * @param array<mixed>        $raw      Raw `form_data` from the request.
	 * @param array<string,mixed> $settings Form partial-entries settings.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public static function filter_payload( $form_id, array $raw, array $settings ) {
		$fields = [];
		foreach ( $raw as $key => $value ) {
			if ( is_string( $key ) && false !== strpos( $key, '-lbl-' ) && 0 === strpos( $key, 'srfm-' ) ) {
				$fields[ $key ] = $value;
			}
		}

		// Drop keys this form does not define. Guarded so an older core without the
		// helper still gets every other rule below.
		$strip = [ 'SRFM\\Inc\\Field_Validation', 'strip_unknown_field_keys' ];
		if ( is_callable( $strip ) ) {
			$stripped = call_user_func( $strip, $fields, $form_id );
			$fields   = is_array( $stripped ) ? $stripped : $fields;
		}

		$blocked = self::get_excluded_block_ids( $settings );
		$clean   = [];
		foreach ( $fields as $key => $value ) {
			if ( count( $clean ) >= self::MAX_FIELDS ) {
				break;
			}
			if ( ! self::is_capturable_key( $key, $blocked ) ) {
				continue;
			}
			$value = self::clean_value( $value, 0, $blocked );
			if ( null !== $value ) {
				$clean[ sanitize_text_field( $key ) ] = $value;
			}
		}

		return $clean;
	}

	/**
	 * Whether this snapshot may be stored at all, and why not.
	 *
	 * @param int                 $form_id  Form post ID.
	 * @param array<string,mixed> $clean    Output of filter_payload().
	 * @param array<string,mixed> $settings Form partial-entries settings.
	 * @since 2.12.9
	 * @return string '' when allowed, otherwise a reason code.
	 */
	public static function get_capture_block_reason( $form_id, array $clean, array $settings ) {
		if ( self::is_no_store_form( $form_id ) ) {
			return 'no_store';
		}

		if ( ! self::has_value( $clean ) ) {
			return 'empty';
		}

		if ( 'contact' === ( $settings['capture_mode'] ?? '' ) && ! self::has_contact_value( $clean ) ) {
			return 'contact_required';
		}

		return '';
	}

	/**
	 * Whether this site may keep any record of the visitor's IP for this form.
	 *
	 * GDPR mode on the form, or IP logging off site-wide, means no. Both the address
	 * sent to a captcha provider and the keyed hash stored as grant evidence are covered:
	 * an HMAC of an IPv4 address is reversible by trying all four billion of them, so it
	 * is a record of the address, not an escape from being one.
	 *
	 * The per-IP ceiling is a deliberate exception. Its transients are keyed by the same
	 * hash whatever this returns, because a rate limit that switches itself off when a
	 * form enables GDPR is not a rate limit. They hold a counter rather than anything
	 * about the visitor, are keyed by a truncated digest, and expire after 24 hours --
	 * unlike the evidence on the row, which is kept for the life of the draft.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function may_record_ip( $form_id ) {
		$compliance = get_post_meta( absint( $form_id ), '_srfm_compliance', true );
		if ( is_array( $compliance ) && is_array( $compliance[0] ?? null ) && ! empty( $compliance[0]['gdpr'] ) ) {
			return false;
		}

		$general = get_option( 'srfm_general_settings_options' );

		return is_array( $general ) && ! empty( $general['srfm_ip_log'] );
	}

	/**
	 * How many reminder permissions one IP may grant in 24 hours.
	 *
	 * @since 2.12.9
	 * @return int At least 1.
	 */
	public static function ip_grant_daily_cap() {
		/**
		 * Filter how many reminder permissions a single IP may grant per 24 hours.
		 *
		 * The address is REMOTE_ADDR, so behind a CDN or reverse proxy that does not
		 * restore the visitor's real IP every visitor shares one bucket and the ceiling
		 * becomes a site-wide one. Raise it there, or restore the real IP.
		 *
		 * @param int $cap Grants per IP per 24 hours. Minimum 1.
		 * @since 2.12.9
		 */
		return max( 1, intval( apply_filters( 'srfm_partial_reminder_ip_daily_grant_cap', 5 ) ) );
	}

	/**
	 * How many refused grant attempts one IP may make in 24 hours.
	 *
	 * Counted separately from the grants themselves, and higher: a refusal is often an
	 * honest visitor whose token expired while they read the label, so it must not eat
	 * the day's grants -- but without any ceiling a failed verification costs the caller
	 * nothing and the captcha can simply be retried until one gets through.
	 *
	 * @since 2.12.9
	 * @return int At least 1.
	 */
	public static function ip_attempt_daily_cap() {
		// Derived from the grant ceiling, but guarded: a site that filters that to
		// PHP_INT_MAX would overflow the multiplication into a float, and intval() of an
		// out-of-range float is not the large number the filter asked for.
		$grants  = self::ip_grant_daily_cap();
		$default = $grants > intdiv( PHP_INT_MAX, 5 ) ? PHP_INT_MAX : $grants * 5;

		/**
		 * Filter how many refused reminder-permission attempts one IP may make per 24 hours.
		 *
		 * @param int $cap Refused attempts per IP per 24 hours. Minimum 1.
		 * @since 2.12.9
		 */
		return max( 1, intval( apply_filters( 'srfm_partial_reminder_ip_daily_attempt_cap', $default ) ) );
	}

	/**
	 * Keyed hash of the requesting IP, or '' when there is none to hash.
	 *
	 * Hashed rather than stored: the grant has to be countable and attributable, and
	 * neither needs the address itself.
	 *
	 * IPv6 is hashed per /64, not per address. A single connection is routinely handed a
	 * whole /64 to allocate from, so hashing the full address gave one host 2^64 buckets
	 * and a ceiling it could step straight past.
	 *
	 * @since 2.12.9
	 * @return string
	 */
	public static function request_ip_hash() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : false;

		if ( ! is_string( $ip ) || '' === $ip ) {
			return '';
		}

		if ( false !== strpos( $ip, ':' ) ) {
			$packed = inet_pton( $ip );
			if ( is_string( $packed ) && 16 === strlen( $packed ) ) {
				// An IPv4-mapped address (`::ffff:203.0.113.5`, what a dual-stack
				// socket or some proxies report) has ten zero bytes before the IPv4
				// part, so masking it to a /64 put *every* IPv4 visitor in `::/64` and
				// turned a ceiling of five per address into five for the whole site.
				// Hash the address it really is instead.
				if ( 0 === strpos( $packed, str_repeat( "\0", 10 ) . "\xff\xff" ) ) {
					$embedded = inet_ntop( substr( $packed, 12 ) );
					$ip       = is_string( $embedded ) ? $embedded : $ip;
				} else {
					$prefix = inet_ntop( substr( $packed, 0, 8 ) . str_repeat( "\0", 8 ) );
					$ip     = is_string( $prefix ) ? $prefix . '/64' : $ip;
				}
			}
		}

		return hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}

	/**
	 * Whether this request may record a *new* reminder permission.
	 *
	 * The opt-in arrives in the body of a public endpoint, so on its own it is a flag a
	 * script can set: the checkbox records a visitor's consent, it does not prove one
	 * was given. Two controls stand behind it, and a new grant has to clear both --
	 * re-asserting a grant the draft already holds for the same address does not, since
	 * that sends no new mail to any new address.
	 *
	 * 1. A per-IP daily ceiling, counted first. On a form with no captcha it is the only
	 *    control there is, which is why the editor says so -- and it is checked before
	 *    the remote verify because verifying a token spends it, and a grant the ceiling
	 *    was going to refuse anyway must not cost the visitor one.
	 * 2. The form's own captcha provider, when the form has one. A save carrying a new
	 *    opt-in has to carry a token minted *for the opt-in*, which the browser produces
	 *    from the form's provider and site key when the box is ticked. It is never the
	 *    token sitting in the form's own captcha field: those are single-use, so
	 *    verifying one here spent it and free then rejected the visitor's real Submit.
	 *
	 * @param int                 $form_id Form post ID.
	 * @param array<string,mixed> $meta    Save metadata, carrying any consent token.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function may_grant_reminder_permission( $form_id, array $meta ) {
		$ip_hash = self::request_ip_hash();

		// No address to attribute anything to, so neither ceiling can be applied and
		// the captcha is the only gate -- the same position a captcha-less form is in.
		if ( '' !== $ip_hash ) {
			if ( self::count_ip_grants( $ip_hash ) >= self::ip_grant_daily_cap() ) {
				return false;
			}
			if ( self::count_ip_attempts( $ip_hash ) >= self::ip_attempt_daily_cap() ) {
				return false;
			}
		}

		// A token that was never going to reach the provider is not a failed challenge,
		// and must not spend the attempt ceiling: a handful of junk POSTs from a shared
		// address -- CGNAT, an office, a CDN that does not restore the real IP -- would
		// otherwise lock every visitor behind it out of opting in for a day.
		$token = Helper::get_string_value( $meta['consent_token'] ?? '' );
		if ( '' === $token || self::MAX_CONSENT_TOKEN_LENGTH < strlen( $token ) ) {
			return self::verify_captcha( $form_id, $meta );
		}

		if ( self::verify_captcha( $form_id, $meta ) ) {
			return true;
		}

		// A refusal the provider actually issued is cheap for whoever caused it, so it
		// has to be counted: otherwise a rejected token can simply be retried until one
		// is accepted.
		self::record_ip_attempt( $ip_hash );

		return false;
	}

	/**
	 * Record that this IP granted a reminder permission.
	 *
	 * A transient rather than a column: the count only has to bound a day's worth of
	 * grants, and it expires itself. A lost increment under concurrency lets one extra
	 * grant through, which a ceiling of this size tolerates.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return void
	 */
	public static function record_ip_grant( $ip_hash ) {
		if ( '' === $ip_hash ) {
			return;
		}

		set_transient( self::ip_grant_key( $ip_hash ), self::count_ip_grants( $ip_hash ) + 1, DAY_IN_SECONDS );
	}

	/**
	 * Grants already recorded against an IP hash in the current window.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return int
	 */
	public static function count_ip_grants( $ip_hash ) {
		return '' === $ip_hash ? 0 : absint( get_transient( self::ip_grant_key( $ip_hash ) ) );
	}

	/**
	 * Record that this IP's grant attempt was refused.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return void
	 */
	public static function record_ip_attempt( $ip_hash ) {
		if ( '' === $ip_hash ) {
			return;
		}

		set_transient( self::ip_attempt_key( $ip_hash ), self::count_ip_attempts( $ip_hash ) + 1, DAY_IN_SECONDS );
	}

	/**
	 * Refused grant attempts already recorded against an IP hash in the current window.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return int
	 */
	public static function count_ip_attempts( $ip_hash ) {
		return '' === $ip_hash ? 0 : absint( get_transient( self::ip_attempt_key( $ip_hash ) ) );
	}

	/**
	 * Verify the token this save minted for the opt-in against the form's provider.
	 *
	 * The token is `consent_token`, never the form's own `cf-turnstile-response`,
	 * `h-captcha-response` or `g-recaptcha-response`. Every provider's response is
	 * single-use, so sending the submit's token here spent it and the visitor's real
	 * Submit was then rejected as a duplicate. The browser mints a second token from the
	 * same provider and site key when the box is ticked, which is also what makes the
	 * opt-in work on reCAPTCHA v3 and the invisible widgets: those produce nothing until
	 * Submit is pressed, and a visitor who abandons the form never presses it.
	 *
	 * True when the form has no captcha configured: there is then nothing to verify, and
	 * the per-IP ceiling is the control.
	 *
	 * @param int                 $form_id Form post ID.
	 * @param array<string,mixed> $meta    Save metadata, carrying any consent token.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function verify_captcha( $form_id, array $meta ) {
		$type = Helper::get_string_value( get_post_meta( absint( $form_id ), '_srfm_captcha_security_type', true ) );

		if ( '' === $type || 'none' === $type ) {
			return true;
		}

		$token   = Helper::get_string_value( $meta['consent_token'] ?? '' );
		$options = get_option( 'srfm_security_settings_options' );
		$options = is_array( $options ) ? $options : [];

		if ( '' === $token ) {
			return false;
		}

		// GDPR mode and a site with IP logging off both mean the address must not leave
		// the site, so the provider is asked without it.
		$remote_ip = self::captcha_remote_ip( $form_id );

		if ( 'cf-turnstile' === $type ) {
			$result = Form_Submit::validate_turnstile_token( Helper::get_string_value( $options['srfm_cf_turnstile_secret_key'] ?? '' ), $token, $remote_ip );
			// Turnstile echoes back the action the widget was rendered with, so a token
			// minted for some other purpose on this site is not one for this.
			return self::captcha_result_ok( is_array( $result ) ? $result : [], self::CONSENT_ACTION );
		}

		if ( 'hcaptcha' === $type ) {
			$result = Form_Submit::validate_hcaptcha_token( Helper::get_string_value( $options['srfm_hcaptcha_secret_key'] ?? '' ), $token, $remote_ip );
			// siteverify reports no action for hCaptcha, so hostname is all there is.
			return self::captcha_result_ok( is_array( $result ) ? $result : [], '' );
		}

		if ( 'g-recaptcha' === $type ) {
			return self::verify_recaptcha(
				self::recaptcha_secret( $form_id, $options ),
				$token,
				$remote_ip,
				Helper::get_string_value( get_post_meta( absint( $form_id ), '_srfm_form_recaptcha', true ) ),
				absint( $form_id )
			);
		}

		// An unrecognised provider is not a pass: the form was configured to challenge
		// visitors, and nothing here has established that this one was challenged.
		return false;
	}

	/**
	 * Whether a siteverify body describes a token minted here, for this.
	 *
	 * `success` alone says the token is well formed and unspent, not that it came from
	 * this site or from the opt-in. Without the hostname a token farmed on an attacker's
	 * own page, under their own site key, verifies here just as well.
	 *
	 * @param array<string,mixed> $body            Decoded siteverify body.
	 * @param string              $expected_action Action the token must report, or '' when the provider reports none.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function captcha_result_ok( array $body, $expected_action ) {
		if ( empty( $body['success'] ) ) {
			return false;
		}

		if ( ! self::hostname_allowed( Helper::get_string_value( $body['hostname'] ?? '' ) ) ) {
			return false;
		}

		return '' === $expected_action || Helper::get_string_value( $body['action'] ?? '' ) === $expected_action;
	}

	/**
	 * Whether a captcha provider's reported hostname is one of this site's.
	 *
	 * @param string $hostname Hostname from the siteverify body.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function hostname_allowed( $hostname ) {
		$home = Helper::get_string_value( wp_parse_url( Helper::get_string_value( home_url() ), PHP_URL_HOST ) );

		// `www.example.com` and `example.com` are one site to everybody except a string
		// comparison, and a visitor who reaches the other one would otherwise have
		// every opt-in refused with nothing on screen to explain it.
		$default = [ $home ];
		if ( '' !== $home ) {
			$default[] = 0 === strpos( $home, 'www.' ) ? substr( $home, 4 ) : 'www.' . $home;
		}

		/**
		 * Filter the hostnames an opt-in captcha token may have been solved on.
		 *
		 * Defaults to this site's own host, with and without `www.`. A site served on
		 * genuinely different domains -- one domain per language, a domain-mapped
		 * multisite, or a staging host sharing the production captcha keys -- has to add
		 * them here, or every opt-in on those domains is refused:
		 *
		 *     add_filter( 'srfm_partial_consent_captcha_hostnames', function ( $hosts ) {
		 *         $hosts[] = 'de.example.com';
		 *         return $hosts;
		 *     } );
		 *
		 * @param array<int,string> $hostnames Allowed hostnames.
		 * @since 2.12.9
		 */
		$allowed = apply_filters( 'srfm_partial_consent_captcha_hostnames', $default );
		$allowed = is_array( $allowed ) ? array_filter( array_map( [ Helper::class, 'get_string_value' ], $allowed ) ) : [];

		if ( empty( $allowed ) || '' === $hostname ) {
			return false;
		}

		return in_array( strtolower( $hostname ), array_map( 'strtolower', $allowed ), true );
	}

	/**
	 * The lowest reCAPTCHA v3 score an opt-in may be granted on.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return float Between 0 and 1.
	 */
	public static function recaptcha_min_score( $form_id ) {
		/**
		 * Filter the minimum reCAPTCHA v3 score an opt-in is accepted at.
		 *
		 * Version 3 never fails a request outright -- it returns a score -- so without a
		 * floor every automated caller passes, which on a v3 form leaves only the per-IP
		 * ceiling. Google's own suggested default is 0.5.
		 *
		 * @param float $score   Minimum score, 0 to 1.
		 * @param int   $form_id Form post ID.
		 * @since 2.12.9
		 */
		$score = (float) apply_filters( 'srfm_partial_recaptcha_min_score', 0.5, $form_id );

		return max( 0.0, min( 1.0, $score ) );
	}

	/**
	 * The visitor's reminder permission as expressed by this snapshot.
	 *
	 * Requires an affirmative opt-in from the visitor. Treating a filled-in email field
	 * as permission made the reminder a spam relay: the save endpoint is public, so
	 * anyone could post drafts carrying other people's addresses and have the site email
	 * each of them, signed by its own domain. The address is only ever a *recipient*;
	 * the consent has to be its own signal.
	 *
	 * The permission is bound to the address through its hash, so it does not follow the
	 * visitor to a different one.
	 *
	 * @param int                 $form_id  Form post ID.
	 * @param array<string,mixed> $clean    Output of filter_payload().
	 * @param array<string,mixed> $settings Form partial-entries settings.
	 * @param bool                $opted_in Whether this snapshot carries the visitor's
	 *                                      affirmative consent.
	 * @since 2.12.9
	 * @return array{granted:bool,recipient_hash:string,recipient_hint:string}
	 */
	public static function get_reminder_permission( $form_id, array $clean, array $settings, $opted_in = false ) {
		$denied = [
			'granted'        => false,
			'recipient_hash' => '',
			'recipient_hint' => '',
		];

		if ( true !== $opted_in ) {
			return $denied;
		}

		if ( '' !== self::get_reminder_config_error( $form_id, $settings ) ) {
			return $denied;
		}

		$email = self::get_reminder_email( $clean, $settings );
		if ( '' === $email ) {
			return $denied;
		}

		return [
			'granted'        => true,
			'recipient_hash' => self::hash_recipient( $email ),
			'recipient_hint' => self::mask_email( $email ),
		];
	}

	/**
	 * The mapped reminder address held in a stored snapshot, or ''.
	 *
	 * @param array<string,mixed> $form_data Stored snapshot.
	 * @param array<string,mixed> $settings  Form partial-entries settings.
	 * @since 2.12.9
	 * @return string
	 */
	public static function get_reminder_email( array $form_data, array $settings ) {
		$block = Helper::get_string_value( $settings['reminder_email_field'] ?? '' );
		if ( '' === $block ) {
			return '';
		}
		foreach ( $form_data as $key => $value ) {
			if ( is_string( $key ) && 'srfm-email' === self::get_key_type( $key ) && self::get_key_block_id( $key ) === $block && is_string( $value ) ) {
				$email = sanitize_email( $value );
				return is_email( $email ) ? $email : '';
			}
		}
		return '';
	}

	/**
	 * Why a form's reminder configuration cannot be used, or '' when it can.
	 *
	 * Reminders need abandonment to be on, and the email field must still exist in the
	 * form as an email field — a field deleted or retyped after the setting was saved
	 * disables reminders rather than silently mailing some other field.
	 *
	 * @param int                 $form_id  Form post ID.
	 * @param array<string,mixed> $settings Form partial-entries settings.
	 * @since 2.12.9
	 * @return string
	 */
	public static function get_reminder_config_error( $form_id, array $settings ) {
		if ( empty( $settings['status'] ) || empty( $settings['reminder'] ) ) {
			return 'reminder_disabled';
		}

		if ( empty( $settings['abandon_delay'] ) ) {
			return 'abandonment_disabled';
		}

		if ( self::blocks_consent_captcha( $form_id ) ) {
			return 'captcha_cannot_mint';
		}

		$fields      = self::get_form_fields( $form_id );
		$email_block = Helper::get_string_value( $settings['reminder_email_field'] ?? '' );

		if ( '' === $email_block || ! in_array( $fields[ $email_block ] ?? '', self::EMAIL_BLOCKS, true ) ) {
			return 'email_field_invalid';
		}
		if ( in_array( $email_block, self::get_excluded_block_ids( $settings ), true ) ) {
			return 'email_field_excluded';
		}

		return '';
	}

	/**
	 * Whether this form's captcha makes an opt-in impossible to earn.
	 *
	 * Google types its reCAPTCHA v2 site keys. A checkbox key cannot run an invisible widget --
	 * Google answers `render()` with "Invalid key type" and never calls back -- and the
	 * opt-in has no other way to mint a token of its own, because reading the token the
	 * form's own widget produced is what broke Submit. Every other provider SureForms
	 * supports can mint on demand: Turnstile through `execution: 'execute'`, hCaptcha
	 * through an invisible render, reCAPTCHA v3 through `grecaptcha.execute()`.
	 *
	 * So the box is not offered at all on these forms, rather than offered and then
	 * failing silently after a fifteen-second stall.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function blocks_consent_captcha( $form_id ) {
		$type = Helper::get_string_value( get_post_meta( absint( $form_id ), '_srfm_captcha_security_type', true ) );
		if ( 'g-recaptcha' !== $type ) {
			return false;
		}

		return 'v2-checkbox' === Helper::get_string_value( get_post_meta( absint( $form_id ), '_srfm_form_recaptcha', true ) );
	}

	/**
	 * Keyed hash of a normalised address. Stable per site, so a stop request made from
	 * one draft suppresses the same address on every later draft.
	 *
	 * @param string $email Address.
	 * @since 2.12.9
	 * @return string
	 */
	public static function hash_recipient( $email ) {
		return hash_hmac( 'sha256', strtolower( trim( Helper::get_string_value( $email ) ) ), wp_salt( 'auth' ) );
	}

	/**
	 * `jane@example.com` → `j***@example.com`, for display.
	 *
	 * @param string $email Address.
	 * @since 2.12.9
	 * @return string
	 */
	public static function mask_email( $email ) {
		$parts = explode( '@', Helper::get_string_value( $email ), 2 );
		if ( 2 !== count( $parts ) || '' === $parts[0] ) {
			return '';
		}
		return substr( $parts[0], 0, 1 ) . '***@' . $parts[1];
	}

	/**
	 * Whether a snapshot holds any non-empty value.
	 *
	 * @param array<mixed> $data Snapshot.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function has_value( array $data ) {
		foreach ( $data as $value ) {
			if ( is_array( $value ) ? self::has_value( $value ) : '' !== trim( Helper::get_string_value( $value ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Owner-excluded block ids.
	 *
	 * @param array<string,mixed> $settings Form partial-entries settings.
	 * @since 2.12.9
	 * @return array<int,string>
	 */
	private static function get_excluded_block_ids( array $settings ) {
		$ids = is_array( $settings['excluded_fields'] ?? null ) ? $settings['excluded_fields'] : [];
		return array_values( array_filter( array_map( [ Helper::class, 'get_string_value' ], $ids ) ) );
	}

	/**
	 * Whether a key names a field an automatic capture may store.
	 *
	 * @param string            $key     Field key.
	 * @param array<int,string> $blocked Blocked block ids.
	 * @since 2.12.9
	 * @return bool
	 */
	private static function is_capturable_key( $key, array $blocked ) {
		if ( ! is_string( $key ) || false === strpos( $key, '-lbl-' ) ) {
			return false;
		}
		if ( in_array( self::get_key_type( $key ), self::EXCLUDED_TYPES, true ) ) {
			return false;
		}
		return ! in_array( self::get_key_block_id( $key ), $blocked, true );
	}

	/**
	 * Sanitize one value, applying the depth, length and child-key rules.
	 *
	 * @param mixed             $value   Raw value.
	 * @param int               $depth   Current depth.
	 * @param array<int,string> $blocked Blocked block ids.
	 * @since 2.12.9
	 * @return mixed Clean value, or null to drop it.
	 */
	private static function clean_value( $value, $depth, array $blocked ) {
		if ( is_array( $value ) ) {
			if ( $depth >= self::MAX_DEPTH ) {
				return null;
			}
			$out = [];
			foreach ( $value as $k => $v ) {
				// A named child is a repeater sub-field and obeys the same key rules; an
				// integer key is a row index or a multi-value position.
				if ( is_string( $k ) && ! ctype_digit( $k ) && ! self::is_capturable_key( $k, $blocked ) ) {
					continue;
				}
				$clean_v = self::clean_value( $v, $depth + 1, $blocked );
				if ( null !== $clean_v ) {
					$out[ is_int( $k ) ? $k : sanitize_text_field( $k ) ] = $clean_v;
				}
			}
			return $out;
		}
		if ( is_bool( $value ) ) {
			return $value ? '1' : '';
		}
		if ( ! is_scalar( $value ) ) {
			return null;
		}
		return mb_substr( sanitize_textarea_field( (string) $value ), 0, self::MAX_VALUE_LENGTH );
	}

	/**
	 * Whether the snapshot carries a usable email address or phone number.
	 *
	 * @param array<string,mixed> $clean Snapshot.
	 * @since 2.12.9
	 * @return bool
	 */
	private static function has_contact_value( array $clean ) {
		foreach ( $clean as $key => $value ) {
			if ( ! is_string( $value ) ) {
				continue;
			}
			$type = self::get_key_type( $key );
			if ( 'srfm-email' === $type && is_email( $value ) ) {
				return true;
			}
			if ( 'srfm-phone' === $type && strlen( (string) preg_replace( '/\D/', '', $value ) ) >= 7 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Walk parsed blocks, collecting field blocks (those with a block_id).
	 *
	 * @param array<int,array<string,mixed>> $blocks Parsed blocks.
	 * @param array<string,string>           $out    Collected map, by reference.
	 * @param int                            $depth  Recursion depth.
	 * @since 2.12.9
	 * @return void
	 */
	private static function collect_fields( array $blocks, array &$out, $depth = 0 ) {
		if ( $depth > 10 ) {
			return;
		}
		foreach ( $blocks as $block ) {
			$name  = Helper::get_string_value( $block['blockName'] ?? '' );
			$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];
			if ( 0 === strpos( $name, 'srfm/' ) && ! empty( $attrs['block_id'] ) ) {
				$out[ Helper::get_string_value( $attrs['block_id'] ) ] = $name;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_fields( $block['innerBlocks'], $out, $depth + 1 );
			}
		}
	}

	/**
	 * Transient name holding one IP hash's grant count.
	 *
	 * Truncated because a transient name is capped at 172 characters, and a sha256 hex
	 * digest plus the prefix is comfortably inside that -- but the stored evidence uses
	 * the full digest, so this is only ever a bucket key.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return string
	 */
	private static function ip_grant_key( $ip_hash ) {
		return 'srfm_pe_grants_' . substr( $ip_hash, 0, 32 );
	}

	/**
	 * Transient name holding one IP hash's refused-attempt count.
	 *
	 * @param string $ip_hash Hash from request_ip_hash().
	 * @since 2.12.9
	 * @return string
	 */
	private static function ip_attempt_key( $ip_hash ) {
		return 'srfm_pe_tries_' . substr( $ip_hash, 0, 32 );
	}

	/**
	 * The IP to pass to a captcha provider, or '' when it must not leave the site.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.9
	 * @return string
	 */
	private static function captcha_remote_ip( $form_id ) {
		if ( ! self::may_record_ip( $form_id ) ) {
			return '';
		}

		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : false;

		return is_string( $ip ) ? $ip : '';
	}

	/**
	 * The reCAPTCHA secret for the variant this form uses.
	 *
	 * @param int                 $form_id Form post ID.
	 * @param array<string,mixed> $options Security settings.
	 * @since 2.12.9
	 * @return string
	 */
	private static function recaptcha_secret( $form_id, array $options ) {
		$variant = Helper::get_string_value( get_post_meta( absint( $form_id ), '_srfm_form_recaptcha', true ) );

		$keys = [
			'v2-checkbox'  => 'srfm_v2_checkbox_secret_key',
			'v2-invisible' => 'srfm_v2_invisible_secret_key',
			'v3-reCAPTCHA' => 'srfm_v3_secret_key',
		];

		$key = $keys[ $variant ] ?? '';

		return '' === $key ? '' : Helper::get_string_value( $options[ $key ] ?? '' );
	}

	/**
	 * Ask Google whether a reCAPTCHA token is good.
	 *
	 * Written here rather than reused because the free plugin's copy is inline in the
	 * submission handler and answers a failure by ending the request.
	 *
	 * @param string $secret    Secret key.
	 * @param string $token     Token from the browser.
	 * @param string $remote_ip Requesting IP, or ''.
	 * @param string $variant   v2-checkbox, v2-invisible or v3-reCAPTCHA.
	 * @param int    $form_id   Form post ID.
	 * @since 2.12.9
	 * @return bool
	 */
	private static function verify_recaptcha( $secret, $token, $remote_ip, $variant, $form_id ) {
		if ( '' === $secret ) {
			return false;
		}

		$response = wp_remote_post(
			'https://www.google.com/recaptcha/api/siteverify',
			[
				'timeout' => 10,
				'body'    => [
					'secret'   => $secret,
					'response' => $token,
					'remoteip' => $remote_ip,
				],
			]
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			return false;
		}

		// v3 is the only variant that reports the action its token was minted under.
		$is_v3 = 'v3-reCAPTCHA' === $variant;
		if ( ! self::captcha_result_ok( $body, $is_v3 ? self::CONSENT_ACTION : '' ) ) {
			return false;
		}

		if ( ! $is_v3 ) {
			return true;
		}

		// v3 answers every request with success -- the verdict is the score -- so a
		// missing or non-numeric one is a refusal, not a pass.
		if ( ! isset( $body['score'] ) || ! is_numeric( $body['score'] ) ) {
			return false;
		}

		return (float) $body['score'] >= self::recaptcha_min_score( $form_id );
	}
}
