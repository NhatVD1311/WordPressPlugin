<?php
/**
 * Partial Entries — Abandonment lifecycle.
 *
 * Owns everything that happens to an automatic capture after it is stored:
 *
 *   in progress ──(inactivity)──▶ abandoned ──(activity)──▶ in progress
 *        │                           │
 *        └──(explicit save)──▶ saved │──(accepted submission)──▶ submitted
 *
 * One recurring Action Scheduler action (TICK_HOOK, every five minutes) does the timed
 * work in bounded batches: it marks due captures abandoned, queues the optional owner
 * notice and visitor reminder in the notification outbox, sends due notifications, and
 * purges expired rows. Nothing is scheduled per field edit.
 *
 * Every send re-checks eligibility against the current row immediately before handing
 * the message to wp_mail(), so a submission, returning visitor, withdrawn permission or
 * disabled setting that lands after the notification was queued still stops it.
 *
 * @package sureforms-pro
 * @since   2.12.9
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

use SRFM\Inc\Email\Email_Template;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;
use SRFM_Pro\Inc\Business\Database\Tables\Partial_Notifications;
use SRFM_Pro\Inc\Pro\Database\Tables\Save_Resume;

defined( 'ABSPATH' ) || exit;

/**
 * Abandonment lifecycle.
 *
 * @since 2.12.9
 */
class Lifecycle {
	use Get_Instance;

	/**
	 * Recurring worker hook.
	 *
	 * @since 2.12.9
	 */
	public const TICK_HOOK = 'srfm_partial_lifecycle_tick';

	/**
	 * Worker cadence, in seconds. Timing is "after the configured delay", never exact.
	 *
	 * @since 2.12.9
	 */
	public const TICK_INTERVAL = 300;

	/**
	 * Option holding the last time the worker ran, for the overdue diagnostic.
	 *
	 * @since 2.12.9
	 */
	public const LAST_RUN_OPTION = 'srfm_partial_lifecycle_last_run';

	/**
	 * Lifetime of the delete (submission-correlation) token.
	 *
	 * @since 2.12.9
	 */
	public const DELETE_TOKEN_TTL = 7 * DAY_IN_SECONDS;

	/**
	 * Query argument carrying a continuation token.
	 *
	 * @since 2.12.9
	 */
	public const LINK_ARG = 'srfm_pe';

	/**
	 * Query argument carrying a stop-reminders token.
	 *
	 * @since 2.12.9
	 */
	public const STOP_ARG = 'srfm_pe_stop';

	/**
	 * Batch sizes per tick.
	 *
	 * @since 2.12.9
	 */
	private const ABANDON_BATCH = 200;
	private const SEND_BATCH    = 50;
	private const PURGE_BATCH   = 500;

	/**
	 * Claim lease for one send, in seconds.
	 *
	 * @since 2.12.9
	 */
	private const CLAIM_LEASE = 600;

	/**
	 * Handoff attempts before a notification is given up as failed.
	 *
	 * @since 2.12.9
	 */
	private const MAX_ATTEMPTS = 3;

	/**
	 * Base retry delay, in seconds; multiplied by the attempt number.
	 *
	 * @since 2.12.9
	 */
	private const RETRY_DELAY = 900;

	/**
	 * A reminder more than this far past its due time is dropped instead of sent, so a
	 * site whose worker was stopped (deactivation, broken cron) does not email every
	 * visitor from that period the moment it runs again.
	 *
	 * @since 2.12.9
	 */
	private const STALE_AFTER = DAY_IN_SECONDS;

	/**
	 * Block reasons that are a ceiling rather than a verdict. A notification blocked
	 * by one is re-timed, not finished: the budget refills, and the draft drops out on
	 * its own once it passes STALE_AFTER.
	 *
	 * @since 2.12.9
	 */
	private const CAP_REASONS = [ 'recipient_cap', 'form_cap', 'site_cap' ];

	/**
	 * How long a notification waits after hitting a cap before it is reconsidered.
	 *
	 * @since 2.12.9
	 */
	private const CAP_RETRY_DELAY = HOUR_IN_SECONDS;

	/**
	 * How long a submitted row that was never abandoned is kept as a terminal marker.
	 *
	 * @since 2.12.9
	 */
	private const TERMINAL_MARKER_TTL = DAY_IN_SECONDS;

	/**
	 * Captures accepted in this request, so the srfm_form_submit fallback does not act twice.
	 *
	 * @var array<string,bool>
	 */
	private $handled_submissions = [];

	/**
	 * Constructor.
	 *
	 * @since 2.12.9
	 */
	public function __construct() {
		add_action( self::TICK_HOOK, [ $this, 'run_tick' ] );
		add_action( 'init', [ $this, 'maybe_schedule_tick' ] );
		add_action( 'template_redirect', [ $this, 'handle_stop_request' ] );

		// Early, before mail: the accepted-submission hook core fires straight after the
		// entry is stored. srfm_form_submit is the fallback for a core without that hook.
		add_action( 'srfm_submission_accepted', [ $this, 'on_submission_accepted' ], 5, 3 );
		add_action( 'srfm_form_submit', [ $this, 'on_form_submit_fallback' ], 4 );

		add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ $this, 'register_eraser' ] );
	}

	/**
	 * Current UTC time as a mysql datetime.
	 *
	 * @param int|null $ts Unix timestamp; now when null.
	 * @since 2.12.9
	 * @return string
	 */
	public static function utc_datetime( $ts = null ) {
		return gmdate( 'Y-m-d H:i:s', null === $ts ? time() : (int) $ts );
	}

	/**
	 * Unix timestamp of a stored UTC mysql datetime, or 0.
	 *
	 * @param mixed $value Stored value.
	 * @since 2.12.9
	 * @return int
	 */
	public static function to_ts( $value ) {
		$value = Helper::get_string_value( $value );
		if ( '' === $value ) {
			return 0;
		}
		$ts = strtotime( $value . ' UTC' );
		return false === $ts ? 0 : $ts;
	}

	/**
	 * Keep the recurring worker scheduled while any form captures, and only then.
	 *
	 * @since 2.12.9
	 * @return void
	 */
	public function maybe_schedule_tick() {
		if ( ! function_exists( 'as_has_scheduled_action' ) || ! function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}
		if ( ! Init::any_form_enabled() ) {
			return;
		}
		if ( false === as_has_scheduled_action( self::TICK_HOOK, [], Partial_Entry_Notifier::GROUP ) ) {
			as_schedule_recurring_action( time() + self::TICK_INTERVAL, self::TICK_INTERVAL, self::TICK_HOOK, [], Partial_Entry_Notifier::GROUP );
		}
	}

	/**
	 * Stop the worker. Called on plugin deactivation.
	 *
	 * @since 2.12.9
	 * @return void
	 */
	public static function deactivate() {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::TICK_HOOK, [], Partial_Entry_Notifier::GROUP );
		}
	}

	/**
	 * Store a visitor snapshot for an automatic capture.
	 *
	 * The caller has authenticated the request and reduced the payload through
	 * Capture_Policy. This decides the lifecycle fields and performs a compare-and-set
	 * write, so it is the single place a visitor save changes a capture.
	 *
	 * @param int                 $form_id      Form post ID.
	 * @param string              $session_id   Capture session id.
	 * @param array<string,mixed> $clean        Filtered snapshot.
	 * @param array<string,mixed> $meta         current_page, progress_percent, last_trigger, source_url.
	 * @param int|null            $base_version Version the client last saw; null when unknown.
	 * @param int|null            $now_ts       Unix time; now when null.
	 * @since 2.12.9
	 * @return array<string,mixed> `status` is created|updated|unchanged|conflict|gone|error.
	 *                             Successful statuses also carry `reminder_opt_in`: the
	 *                             permission the row now holds, which is not always the
	 *                             opt-in that was asked for.
	 */
	public function save_capture( $form_id, $session_id, array $clean, array $meta, $base_version, $now_ts = null ) {
		$now_ts   = null === $now_ts ? time() : (int) $now_ts;
		$now      = self::utc_datetime( $now_ts );
		$settings = Init::get_notify_settings( $form_id );
		$row      = Save_Resume::find_capture( $form_id, $session_id );

		if ( ! empty( $row ) && ! Save_Resume::is_writable( $row ) ) {
			return [ 'status' => 'gone' ];
		}

		$trigger    = Helper::get_string_value( $meta['last_trigger'] ?? 'input' );
		$opted_in   = true === ( $meta['reminder_opt_in'] ?? false );
		$page       = absint( $meta['current_page'] ?? 0 );
		$permission = Capture_Policy::get_reminder_permission( $form_id, $clean, $settings, $opted_in );
		$stored     = self::part( is_array( $row ) ? $row : [], 'reminder_permission' );

		// The opt-in is a field in the body of a public endpoint, so by itself it is a
		// flag a script can set, not evidence that a person ticked a box. Only a *new*
		// grant has to be earned -- re-asserting the one this draft already holds for
		// the same address sends no mail anywhere new -- and what earns it is a ceiling
		// on how many one IP may hand out in a day plus, where the form has a captcha, a
		// token the browser minted for this opt-in alone.
		$ip_hash   = '';
		$new_grant = $permission['granted']
			&& ( empty( $stored['granted'] ) || Helper::get_string_value( $stored['recipient_hash'] ?? '' ) !== $permission['recipient_hash'] );

		// Why a tick was refused, for the message the browser puts under the box. The
		// two causes need different wording -- one is the visitor's to fix, the other
		// is not -- and the browser cannot tell them apart from `granted` alone.
		//
		// A form whose reminder setup is broken (no field chosen, or the chosen field
		// deleted since) also refuses, and that is nobody's address to correct, so it
		// is left unexplained rather than blamed on what the visitor typed.
		$refusal = $opted_in
			&& ! $permission['granted']
			&& '' === Capture_Policy::get_reminder_config_error( $form_id, $settings )
			? 'invalid_email'
			: '';

		if ( $new_grant ) {
			if ( Capture_Policy::may_grant_reminder_permission( $form_id, $meta ) ) {
				$ip_hash = Capture_Policy::request_ip_hash();
			} else {
				$permission = [
					'granted'        => false,
					'recipient_hash' => '',
					'recipient_hint' => '',
				];
				$new_grant  = false;
				$refusal    = 'verification';
			}
		}

		// A permission change counts even when the snapshot is identical (for example,
		// reminders were set up after this draft was captured), or the stored permission
		// would go stale and the reminder be sent or withheld on the wrong basis.
		$permission_changed = ! empty( $stored['granted'] ) !== $permission['granted']
			|| ( $permission['granted'] && Helper::get_string_value( $stored['recipient_hash'] ?? '' ) !== $permission['recipient_hash'] );

		$changed = empty( $row )
			|| $permission_changed
			|| wp_json_encode( $clean ) !== wp_json_encode( $row['form_data'] ?? [] )
			|| absint( $row['current_page'] ?? 0 ) !== $page;

		// An unchanged periodic or unload save is not visitor activity: it must not move
		// the inactivity clock, or an open idle tab would never be treated as abandoned.
		if ( ! empty( $row ) && ! $changed && 'saved' !== $trigger ) {
			return [
				'status'           => 'unchanged',
				'id'               => $row['id'],
				'version'          => absint( $row['activity_version'] ?? 0 ),
				'reminder_opt_in'  => (bool) $permission['granted'],
				'reminder_refusal' => $refusal,
			];
		}

		$lifecycle = is_array( $row['lifecycle'] ?? null ) ? $row['lifecycle'] : [];
		// The counting hash is still used -- the ceiling has to work either way -- but
		// nothing is kept on the row when the site has said it keeps no record of
		// visitors' addresses, and any hash already there is dropped on the next save.
		// A keyed hash of an IPv4 address is still a record of one.
		$may_record = Capture_Policy::may_record_ip( $form_id );
		$lifecycle  = self::apply_permission( $lifecycle, $permission, $now, $may_record ? $ip_hash : '', $may_record );
		$now_perm   = self::part( [ 'lifecycle' => $lifecycle ], 'reminder_permission' );
		$withdrawn  = ! empty( $now_perm['withdrawn_at'] ) && empty( $now_perm['granted'] );

		// A meaningful save after the visitor opened a continuation link is the evidence
		// that the link was used — opening it alone (or a mail scanner fetching it) is not.
		$recovery = self::part( [ 'lifecycle' => $lifecycle ], 'recovery' );
		if ( ! empty( $recovery['opened_at'] ) && empty( $recovery['continued_at'] ) ) {
			$recovery['continued_at'] = $now;
			$lifecycle['recovery']    = $recovery;
		}

		$state = Save_Resume::STATE_IN_PROGRESS;
		if ( 'saved' === $trigger ) {
			$state                      = Save_Resume::STATE_SAVED;
			$lifecycle['explicit_save'] = $now;
		}

		$fields = [
			'form_data'        => $clean,
			'current_page'     => $page,
			'progress_percent' => max( 0, min( 100, absint( $meta['progress_percent'] ?? 0 ) ) ),
			'last_trigger'     => $trigger,
			'source_url'       => self::clean_source_url( Helper::get_string_value( $meta['source_url'] ?? '' ) ),
			'state'            => $state,
			'last_activity_at' => $now,
			'abandon_after'    => Save_Resume::STATE_IN_PROGRESS === $state && 0 < absint( $settings['abandon_delay'] ) ? self::utc_datetime( $now_ts + absint( $settings['abandon_delay'] ) * MINUTE_IN_SECONDS ) : null,
			'expires_at'       => self::utc_datetime( $now_ts + absint( $settings['retention_days'] ) * DAY_IN_SECONDS ),
			'lifecycle'        => $lifecycle,
			// Read from the session on the server. The browser never sends this, so a
			// capture cannot be attributed to a user the request was not actually made as.
			'user_id'          => self::current_user_id(),
		];

		if ( empty( $row ) ) {
			$stored = Save_Resume::insert_capture( $form_id, $session_id, $fields );
			if ( empty( $stored ) ) {
				return [ 'status' => 'error' ];
			}
			// A concurrent first save won the unique key: this snapshot was not written.
			if ( absint( $stored['activity_version'] ?? 0 ) !== 1 || wp_json_encode( $stored['form_data'] ?? [] ) !== wp_json_encode( $clean ) ) {
				return [
					'status'  => 'conflict',
					'id'      => $stored['id'],
					'version' => absint( $stored['activity_version'] ?? 0 ),
				];
			}
			if ( $new_grant ) {
				Capture_Policy::record_ip_grant( $ip_hash );
			}

			return [
				'status'           => 'created',
				'id'               => $stored['id'],
				'version'          => 1,
				'reminder_opt_in'  => (bool) $permission['granted'],
				'reminder_refusal' => $refusal,
			];
		}

		$current = absint( $row['activity_version'] ?? 0 );
		if ( null === $base_version || absint( $base_version ) !== $current ) {
			return [
				'status'  => 'conflict',
				'id'      => $row['id'],
				'version' => $current,
			];
		}

		if ( ! Save_Resume::update_capture( $row, $fields ) ) {
			$fresh = Save_Resume::find_capture( $form_id, $session_id );
			if ( empty( $fresh ) || ! Save_Resume::is_writable( $fresh ) ) {
				return [ 'status' => 'gone' ];
			}
			return [
				'status'  => 'conflict',
				'id'      => $fresh['id'],
				'version' => absint( $fresh['activity_version'] ?? 0 ),
			];
		}

		if ( $new_grant ) {
			Capture_Policy::record_ip_grant( $ip_hash );
		}

		if ( $withdrawn ) {
			Partial_Notifications::suppress_pending_for_draft( Helper::get_string_value( $row['id'] ), 'permission_withdrawn' );
		}

		return [
			'status'           => 'updated',
			'id'               => $row['id'],
			'version'          => $current + 1,
			'reminder_opt_in'  => (bool) $permission['granted'],
			'reminder_refusal' => $refusal,
		];
	}

	/**
	 * Recurring worker: abandonment, notifications, retention.
	 *
	 * @param int|null $now_ts Unix time; now when null. Tests pass a fixed clock.
	 * @since 2.12.9
	 * @return void
	 */
	public function run_tick( $now_ts = null ) {
		$now_ts = null === $now_ts || ! is_numeric( $now_ts ) ? time() : (int) $now_ts;
		$now    = self::utc_datetime( $now_ts );

		update_option( self::LAST_RUN_OPTION, $now_ts, false );

		Partial_Notifications::expire_stale_claims( $now );

		foreach ( Save_Resume::get_due_for_abandonment( $now, self::ABANDON_BATCH ) as $id ) {
			if ( Save_Resume::mark_abandoned( $id, $now ) ) {
				$this->on_abandoned( $id, $now_ts );
			}
		}

		// One budget per type. Sharing a single batch let owner notices -- which any
		// anonymous visitor produces, one per abandoned draft -- crowd out visitor
		// reminders until they aged past STALE_AFTER and were dropped unsent.
		foreach ( [ Partial_Notifications::TYPE_VISITOR_REMINDER, Partial_Notifications::TYPE_OWNER_ABANDONMENT ] as $type ) {
			foreach ( Partial_Notifications::get_due( $now, self::SEND_BATCH, $type ) as $notification ) {
				$this->process_notification( $notification, $now_ts );
			}
		}

		$expired = Save_Resume::get_expired( $now, self::PURGE_BATCH );
		foreach ( $expired as $id ) {
			Save_Resume::delete_entry( $id );
		}
		Partial_Notifications::delete_for_drafts( $expired );
	}

	/**
	 * Why a visitor reminder may not be sent for this draft right now, or ''.
	 *
	 * Evaluated both when the reminder is queued and again immediately before it is
	 * handed to wp_mail().
	 *
	 * @param array<string,mixed> $row      Draft row.
	 * @param array<string,mixed> $settings Form settings.
	 * @param int                 $now_ts   Unix time.
	 * @since 2.12.9
	 * @return string
	 */
	public function get_reminder_block_reason( array $row, array $settings, $now_ts ) {
		$form_id = absint( $row['form_id'] ?? 0 );

		if ( 'publish' !== get_post_status( $form_id ) ) {
			return 'form_unavailable';
		}
		$config_error = Capture_Policy::get_reminder_config_error( $form_id, $settings );
		if ( '' !== $config_error ) {
			return $config_error;
		}
		if ( Capture_Policy::is_no_store_form( $form_id ) ) {
			return 'no_store';
		}
		if ( Save_Resume::SOURCE_AUTOMATIC !== ( $row['capture_source'] ?? '' ) ) {
			return 'not_automatic';
		}

		$lifecycle = is_array( $row['lifecycle'] ?? null ) ? $row['lifecycle'] : [];
		if ( ! empty( $lifecycle['explicit_save'] ) ) {
			return 'saved_draft';
		}

		$state = Helper::get_string_value( $row['state'] ?? '' );
		if ( Save_Resume::STATE_SUBMITTED === $state ) {
			return 'submitted';
		}
		if ( Save_Resume::STATE_SAVED === $state ) {
			return 'saved_draft';
		}
		if ( ! in_array( $state, [ Save_Resume::STATE_ABANDONED, Save_Resume::STATE_IN_PROGRESS ], true ) ) {
			return 'not_eligible';
		}

		$expires = self::to_ts( $row['expires_at'] ?? '' );
		if ( $expires > 0 && $expires <= $now_ts ) {
			return 'expired';
		}

		$permission = is_array( $lifecycle['reminder_permission'] ?? null ) ? $lifecycle['reminder_permission'] : [];
		if ( empty( $permission['granted'] ) ) {
			return empty( $permission['withdrawn_at'] ) ? 'no_permission' : 'permission_withdrawn';
		}

		$email = Capture_Policy::get_reminder_email( is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [], $settings );
		if ( '' === $email || ! hash_equals( Helper::get_string_value( $permission['recipient_hash'] ?? '' ), Capture_Policy::hash_recipient( $email ) ) ) {
			return 'recipient_changed';
		}
		$recipient_hash = Capture_Policy::hash_recipient( $email );
		if ( Partial_Notifications::is_recipient_suppressed( $recipient_hash ) ) {
			return 'recipient_suppressed';
		}

		$due = self::reminder_due_ts( $row, $settings );
		if ( $now_ts < $due || Save_Resume::STATE_ABANDONED !== $state ) {
			return 'not_due';
		}
		if ( $now_ts - $due > self::STALE_AFTER ) {
			return 'stale';
		}

		// Anyone can type any address into a public form, so bound what one address and
		// one form can receive: a draft already gets at most one reminder, but many drafts
		// naming the same address must not add up to a flood.
		$since = self::utc_datetime( $now_ts - DAY_IN_SECONDS );
		if ( Partial_Notifications::count_recent_handoffs( $since, $recipient_hash ) >= self::recipient_daily_cap() ) {
			return 'recipient_cap';
		}
		if ( Partial_Notifications::count_recent_handoffs( $since, '', $form_id ) >= self::form_daily_cap( $form_id ) ) {
			return 'form_cap';
		}
		// Each form has its own cap, so without a ceiling across all of them a site with
		// many forms has no bound at all.
		if ( Partial_Notifications::count_recent_site_sends( $since, Helper::get_string_value( $row['id'] ?? '' ) ) >= self::site_daily_cap() ) {
			return 'site_cap';
		}

		return '';
	}

	/**
	 * Build the reminder subject and body from the form's template.
	 *
	 * Only the tags listed here are resolved; the template never reaches the general
	 * smart-tag engine, so no answer, account or payment tag can be expanded into it.
	 *
	 * @param array<string,mixed>  $settings Form settings.
	 * @param array<string,string> $tags     Tag values.
	 * @since 2.12.9
	 * @return array{subject:string,body:string}
	 */
	public static function render_reminder( array $settings, array $tags ) {
		$subject = Helper::get_string_value( $settings['reminder_subject'] ?? '' );
		$body    = Helper::get_string_value( $settings['reminder_body'] ?? '' );
		if ( '' === trim( $subject ) ) {
			$subject = self::default_reminder_subject();
		}
		if ( '' === trim( wp_strip_all_tags( $body ) ) ) {
			$body = self::default_reminder_body();
		}

		$text_tags = [
			'{form_title}'  => $tags['form_title'] ?? '',
			'{expiry_date}' => $tags['expiry_date'] ?? '',
			'{site_title}'  => wp_specialchars_decode( Helper::get_string_value( get_bloginfo( 'name' ) ), ENT_QUOTES ),
		];
		$url_tags  = [
			'{continue_url}' => $tags['continue_url'] ?? '',
			'{stop_url}'     => $tags['stop_url'] ?? '',
		];

		$subject = strtr( $subject, $text_tags );
		$subject = strtr( $subject, array_fill_keys( array_keys( $url_tags ), '' ) );

		$body = strtr( wp_kses_post( $body ), array_map( 'esc_html', $text_tags ) );
		$body = strtr( $body, array_map( 'esc_url', $url_tags ) );

		return [
			'subject' => sanitize_text_field( $subject ),
			'body'    => $body,
		];
	}

	/**
	 * The reminder subject used when the form has none.
	 *
	 * @since 2.12.9
	 * @return string
	 */
	public static function default_reminder_subject() {
		return __( 'Continue your form', 'sureforms-pro' );
	}

	/**
	 * The reminder body used when the form has none.
	 *
	 * @since 2.12.9
	 * @return string
	 */
	public static function default_reminder_body() {
		$muted = 'margin: 0; font-size: 13px; line-height: 20px; color: #6b7280;';
		return '<p style="margin: 0 0 12px; font-size: 20px; line-height: 28px; font-weight: 600; color: #111827;">' . esc_html__( 'Pick up where you left off', 'sureforms-pro' ) . '</p><p style="margin: 0 0 24px; font-size: 14px; line-height: 22px; color: #384860;">' . esc_html__( 'You started filling out {form_title} but did not finish. Your progress has been saved, so you can continue right where you stopped.', 'sureforms-pro' ) . '</p><p style="margin: 0 0 24px;"><a href="{continue_url}" style="display: inline-block; padding: 12px 24px; background-color: #d54407; color: #ffffff; font-size: 14px; font-weight: 600; text-decoration: none; border-radius: 6px;">' . esc_html__( 'Continue form', 'sureforms-pro' ) . '</a></p><p style="' . $muted . '">' . esc_html__( 'This link expires on {expiry_date}.', 'sureforms-pro' ) . '</p><hr style="margin: 24px 0 16px; border: 0; border-top: 1px solid #e5e7eb;" /><p style="' . $muted . '">' . esc_html__( 'Do not want these emails?', 'sureforms-pro' ) . ' <a href="{stop_url}" style="color: #6b7280;">' . esc_html__( 'Stop reminders', 'sureforms-pro' ) . '</a></p>';
	}

	/**
	 * Hand an HTML message to wp_mail() without leaking state into other mail.
	 *
	 * The single send path for partial-entry mail. Parsed template headers already carry
	 * Content-Type: text/html, but an SMTP plugin filtering wp_mail_content_type can
	 * override them and the body would render as source, so the filter re-asserts it at
	 * priority 99. It is removed again, and stray output echoed by mail plugins is
	 * discarded, even when a pre_wp_mail/wp_mail callback throws — this runs inside the
	 * long-lived Action Scheduler queue runner, which goes on to send other plugins' mail
	 * and whose response stray output would corrupt.
	 *
	 * @param string                        $to      Recipient.
	 * @param string                        $subject Subject.
	 * @param string                        $body    HTML body.
	 * @param string|array<int,string>|null $headers Headers as wp_mail() takes them; null for SureForms' configured sender.
	 * @since 2.12.9
	 * @return bool|string True when wp_mail() accepted the message, false otherwise, 'invalid_recipient'.
	 */
	public static function send_html_mail( $to, $subject, $body, $headers = null ) {
		if ( ! is_email( $to ) ) {
			return 'invalid_recipient';
		}

		$content_type = static function () {
			return 'text/html';
		};
		add_filter( 'wp_mail_content_type', $content_type, 99 );
		// The same shell core's notification emails use, so every SureForms email looks alike.
		if ( class_exists( Email_Template::class ) ) {
			$template = new Email_Template();
			$body     = $template->get_header() . $body . $template->get_footer();
		}

		ob_start();
		try {
			$sent = wp_mail( $to, $subject, $body, null === $headers ? self::mail_headers() : $headers );
		} finally {
			ob_end_clean();
			remove_filter( 'wp_mail_content_type', $content_type, 99 );
		}

		return (bool) $sent;
	}

	/**
	 * Issue a continuation link for a draft.
	 *
	 * The token is HMAC-signed, purpose-bound and expiring. It names the draft and a link
	 * generation; revoking bumps the generation, which invalidates every earlier link. It
	 * never carries the session id or any answer. Expiry is the earlier of the form's link
	 * lifetime and the draft's own expiry.
	 *
	 * On failure `url` is '', and `conflict` says which kind: true when the lifecycle
	 * write lost its compare-and-set or was vetoed -- a race the next attempt usually
	 * wins -- and false when the draft's remaining window is simply too short.
	 *
	 * After a revoke nothing automated may mint again. `$deliberate` is how an
	 * administrator asking for a fresh link says so: it clears the revocation instead of
	 * being refused by it. The worker never passes it, so a reminder that was already
	 * claimed when the revoke landed -- which suppress_pending_for_draft() cannot reach,
	 * because it only moves queued and retrying rows -- cannot sign a new valid link.
	 *
	 * @param array<string,mixed> $row        Draft row.
	 * @param int                 $now_ts     Unix time.
	 * @param bool                $deliberate Whether an administrator asked for this.
	 * @since 2.12.9
	 * @return array{url:string,expires_ts:int,conflict:bool}
	 */
	public function issue_continuation_link( array $row, $now_ts, $deliberate = false ) {
		$form_id  = absint( $row['form_id'] ?? 0 );
		$settings = Init::get_notify_settings( $form_id );
		$expires  = $now_ts + absint( $settings['link_ttl_days'] ) * DAY_IN_SECONDS;
		$draft_ex = self::to_ts( $row['expires_at'] ?? '' );
		if ( $draft_ex > 0 ) {
			$expires = min( $expires, $draft_ex );
		}
		if ( $expires <= $now_ts + MINUTE_IN_SECONDS ) {
			return [
				'url'        => '',
				'expires_ts' => 0,
				'conflict'   => false,
			];
		}

		// The version has to come from the row as it stands when the write lands, not
		// from the copy this worker read: an administrator revoking in between bumps
		// it, and signing a token for the version we read would hand the revoked links
		// their validity back.
		$version = 0;
		$stored  = Save_Resume::patch_lifecycle(
			Helper::get_string_value( $row['id'] ),
			static function ( $lifecycle ) use ( &$version, $now_ts, $expires, $deliberate ) {
				$recovery = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];

				// A revoke stops every automated link until somebody decides otherwise.
				// The old guard let a draft through as soon as it had *ever* had a link
				// issued, so a reminder already claimed when the revoke landed went on
				// to sign and email a fresh, perfectly valid link.
				if ( ! empty( $recovery['revoked_at'] ) ) {
					if ( ! $deliberate ) {
						return false;
					}
					// The administrator is asking for a new link, which is the one
					// thing that is allowed to end the revocation.
					unset( $recovery['revoked_at'] );
				}

				$version                  = max( 1, absint( $recovery['version'] ?? 0 ) );
				$recovery['version']      = $version;
				$recovery['issued_at']    = self::utc_datetime( $now_ts );
				$recovery['link_expires'] = self::utc_datetime( $expires );

				return [ 'recovery' => $recovery ];
			}
		);

		// No link rather than a dead one: an unsent reminder is retried, an email
		// carrying a token for a version that was never stored is not.
		if ( ! $stored ) {
			return [
				'url'        => '',
				'expires_ts' => 0,
				'conflict'   => true,
			];
		}

		$token = Resume_Token::issue( 'recover', $form_id, Helper::get_string_value( $row['id'] ) . ':' . $version, $expires - $now_ts );

		return [
			'url'        => add_query_arg( self::LINK_ARG, rawurlencode( $token ), self::destination_url( $row ) ),
			'expires_ts' => $expires,
			'conflict'   => false,
		];
	}

	/**
	 * Invalidate every continuation link issued for a draft.
	 *
	 * Any reminder still queued for the draft is suppressed with it. The link in a
	 * reminder is minted at dispatch, under whatever recovery version the row holds
	 * then -- so a queued reminder left alone would have signed and sent a *new* valid
	 * link minutes after the owner revoked the old ones.
	 *
	 * @param string $id Draft UUID.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function revoke_links( $id ) {
		$now = self::utc_datetime();

		$revoked = Save_Resume::patch_lifecycle(
			$id,
			static function ( $lifecycle ) use ( $now ) {
				$recovery = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];

				$recovery['version']    = absint( $recovery['version'] ?? 0 ) + 1;
				$recovery['revoked_at'] = $now;
				unset( $recovery['link_expires'] );

				return [ 'recovery' => $recovery ];
			}
		);

		if ( $revoked ) {
			Partial_Notifications::suppress_pending_for_draft( Helper::get_string_value( $id ), 'links_revoked' );
		}

		return $revoked;
	}

	/**
	 * Resolve a continuation token to its draft, or [] when it cannot be used.
	 *
	 * Every failure — malformed, forged, expired, wrong form, revoked, submitted, deleted —
	 * returns the same empty result, so the endpoint answering it is not an oracle.
	 *
	 * @param string $token   Token from the link.
	 * @param int    $form_id Form the visitor is looking at.
	 * @param int    $now_ts  Unix time.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public static function resolve_continuation_token( $token, $form_id, $now_ts ) {
		$token = Helper::get_string_value( $token );
		// Never accept the non-expiring (exp = 0) form: continuation links always expire.
		if ( ! preg_match( '/^[1-9][0-9]*\./', $token ) ) {
			return [];
		}

		$subject = Resume_Token::decode( $token, 'recover', absint( $form_id ) );
		if ( false === $subject || false === strpos( $subject, ':' ) ) {
			return [];
		}
		[ $id, $version ] = explode( ':', $subject, 2 );

		$row = Save_Resume::get( $id );
		if ( empty( $row ) || absint( $row['form_id'] ?? 0 ) !== absint( $form_id ) ) {
			return [];
		}
		if ( ! Save_Resume::is_writable( $row ) ) {
			return [];
		}
		$expires = self::to_ts( $row['expires_at'] ?? '' );
		if ( $expires > 0 && $expires <= $now_ts ) {
			return [];
		}
		$recovery = self::part( $row, 'recovery' );
		if ( absint( $recovery['version'] ?? 0 ) !== absint( $version ) ) {
			return [];
		}

		return $row;
	}

	/**
	 * Record that a continuation link was opened. Not a recovery by itself.
	 *
	 * @param array<string,mixed> $row    Draft row.
	 * @param int                 $now_ts Unix time.
	 * @since 2.12.9
	 * @return void
	 */
	public static function record_link_opened( array $row, $now_ts ) {
		Save_Resume::patch_lifecycle(
			Helper::get_string_value( $row['id'] ),
			static function ( $lifecycle ) use ( $now_ts ) {
				$recovery = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];
				if ( ! empty( $recovery['opened_at'] ) ) {
					return false;
				}

				$recovery['opened_at'] = self::utc_datetime( $now_ts );

				return [ 'recovery' => $recovery ];
			}
		);
	}

	/**
	 * Show the stop-reminders confirmation, and apply it on POST.
	 *
	 * GET only renders a confirmation button: a link scanner fetching the URL must not
	 * unsubscribe anyone. The POST carries the same signed token.
	 *
	 * @since 2.12.9
	 * @return void
	 */
	public function handle_stop_request() {
		// phpcs:disable WordPress.Security.NonceVerification -- authenticated by the signed stop token, verified below.
		if ( empty( $_REQUEST[ self::STOP_ARG ] ) ) {
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_REQUEST[ self::STOP_ARG ] ) );
		$form  = isset( $_REQUEST['form'] ) ? absint( $_REQUEST['form'] ) : 0;
		$post  = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
		// phpcs:enable WordPress.Security.NonceVerification

		nocache_headers();

		if ( ! $post ) {
			$action = add_query_arg(
				[
					self::STOP_ARG => rawurlencode( $token ),
					'form'         => $form,
				],
				home_url( '/' )
			);
			wp_die(
				'<p>' . esc_html__( 'Stop receiving reminders about this unfinished form?', 'sureforms-pro' )
				. '</p><form method="post" action="' . esc_url( $action ) . '"><button type="submit" class="button">' . esc_html__( 'Stop reminders', 'sureforms-pro' ) . '</button></form>',
				esc_html__( 'Stop reminders', 'sureforms-pro' ),
				[ 'response' => 200 ]
			);
		}

		$this->apply_stop( $token, $form );

		// The same message whether or not the token was valid.
		wp_die(
			'<p>' . esc_html__( 'You will not receive further reminders about this form.', 'sureforms-pro' ) . '</p>',
			esc_html__( 'Reminders stopped', 'sureforms-pro' ),
			[ 'response' => 200 ]
		);
	}

	/**
	 * Apply a stop request: suppress the recipient and the draft's pending reminders.
	 *
	 * The address comes from the token's own signed subject, so a stop link only ever
	 * suppresses the address it was mailed to, and works whether or not the draft it
	 * came from still exists.
	 *
	 * @param string $token   Stop token.
	 * @param int    $form_id Form id carried beside the token.
	 * @since 2.12.9
	 * @return bool True when the token was valid.
	 */
	public function apply_stop( $token, $form_id ) {
		$subject = Resume_Token::decode( $token, 'stop', absint( $form_id ) );
		if ( false === $subject ) {
			return false;
		}

		[ $id, $signed_hash ] = self::parse_stop_subject( $subject );

		if ( '' === $signed_hash ) {
			return false;
		}

		$now = self::utc_datetime();

		// Suppress the address first, and never conditionally on the draft still being
		// there. The address is what the token is signed for, and a stop link used
		// after retention purged the draft has to keep working -- otherwise the page
		// says reminders have stopped while nothing was recorded, and the next draft
		// naming that address is reminded again.
		Partial_Notifications::suppress_recipient( $signed_hash, $now );
		Partial_Notifications::suppress_pending_for_draft( $id, 'stop_requested' );

		Save_Resume::patch_lifecycle(
			$id,
			static function ( $lifecycle ) use ( $now ) {
				$permission = is_array( $lifecycle['reminder_permission'] ?? null ) ? $lifecycle['reminder_permission'] : [];

				$permission['granted']      = false;
				$permission['withdrawn_at'] = $now;

				return [ 'reminder_permission' => $permission ];
			}
		);

		return true;
	}

	/**
	 * Link a capture to the accepted submission and stop everything pending for it.
	 *
	 * The session id arrives with the submission but is only trusted together with the
	 * server-issued delete token bound to it.
	 *
	 * @param int          $entry_id  Accepted entry id, 0 when not stored.
	 * @param int          $form_id   Form id.
	 * @param array<mixed> $form_data Parsed submission request data.
	 * @since 2.12.9
	 * @return void
	 */
	public function on_submission_accepted( $entry_id, $form_id, $form_data ) {
		$form_data  = is_array( $form_data ) ? $form_data : [];
		$session_id = substr( sanitize_text_field( Helper::get_string_value( $form_data['srfm_partial_session_id'] ?? '' ) ), 0, 64 );
		$token      = sanitize_text_field( Helper::get_string_value( $form_data['srfm_partial_delete_token'] ?? '' ) );

		$this->complete_capture( absint( $form_id ), $session_id, $token, absint( $entry_id ) );
	}

	/**
	 * Fallback for a core that does not fire srfm_submission_accepted.
	 *
	 * @param mixed $response srfm_form_submit payload.
	 * @since 2.12.9
	 * @return void
	 */
	public function on_form_submit_fallback( $response ) {
		if ( ! is_array( $response ) || empty( $response['success'] ) ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the submission is HMAC-token authenticated upstream; the session is re-verified against its delete token.
		$session_id = isset( $_POST['srfm_partial_session_id'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['srfm_partial_session_id'] ) ), 0, 64 ) : '';
		$token      = isset( $_POST['srfm_partial_delete_token'] ) ? sanitize_text_field( wp_unslash( $_POST['srfm_partial_delete_token'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$this->complete_capture( absint( $response['form_id'] ?? 0 ), $session_id, $token, absint( $response['entry_id'] ?? 0 ) );
	}

	/**
	 * Mark a verified capture submitted.
	 *
	 * @param int    $form_id    Form id.
	 * @param string $session_id Capture session id.
	 * @param string $token      Delete token bound to the session.
	 * @param int    $entry_id   Accepted entry id, 0 when not stored.
	 * @since 2.12.9
	 * @return bool True when a capture was completed by this call.
	 */
	public function complete_capture( $form_id, $session_id, $token, $entry_id ) {
		if ( 0 === $form_id || '' === $session_id || '' === $token ) {
			return false;
		}
		$handled_key = $form_id . '|' . $session_id;
		if ( isset( $this->handled_submissions[ $handled_key ] ) ) {
			return false;
		}
		if ( ! Resume_Token::verify( $token, 'delete', $form_id, $session_id ) ) {
			return false;
		}
		$this->handled_submissions[ $handled_key ] = true;

		$row = Save_Resume::find_capture( $form_id, $session_id );
		if ( empty( $row ) ) {
			return false;
		}

		$now_ts    = time();
		$settings  = Init::get_notify_settings( $form_id );
		$abandoned = ! empty( $row['first_abandoned_at'] );

		// Keep the outcome of a draft that was ever abandoned for the reporting window;
		// anything else only as a short-lived marker that rejects late autosaves.
		$expires = $abandoned
			? $now_ts + absint( $settings['retention_days'] ) * DAY_IN_SECONDS
			: $now_ts + self::TERMINAL_MARKER_TTL;

		Save_Resume::patch_lifecycle(
			Helper::get_string_value( $row['id'] ),
			static function ( $lifecycle ) use ( $abandoned ) {
				$recovery = is_array( $lifecycle['recovery'] ?? null ) ? $lifecycle['recovery'] : [];

				return [
					'completion' => [
						'after_abandonment' => $abandoned,
						// Opening the link, then submitting with this session, is the
						// continuation; a scanner that only fetched the link never
						// reaches an accepted submission.
						'link_assisted'     => $abandoned && ( ! empty( $recovery['opened_at'] ) || ! empty( $recovery['continued_at'] ) ),
					],
				];
			}
		);

		$done = Save_Resume::mark_submitted( Helper::get_string_value( $row['id'] ), $entry_id, self::utc_datetime( $now_ts ), self::utc_datetime( $expires ) );

		Partial_Notifications::suppress_pending_for_draft( Helper::get_string_value( $row['id'] ), 'submitted' );

		return $done;
	}

	/**
	 * Retire this browser's automatic capture after a deliberate Save & Resume save.
	 *
	 * The capture becomes a saved draft: it is excluded from reminders and the scanner,
	 * and anything already queued for it is suppressed. Needs the delete token bound to
	 * the session, like every other action taken on a capture from the public side.
	 *
	 * @param int    $form_id    Form id.
	 * @param string $session_id Capture session id sent with the save.
	 * @param string $token      Delete token sent with the save.
	 * @since 2.12.9
	 * @return bool
	 */
	public function hand_off_to_save_resume( $form_id, $session_id, $token ) {
		$form_id    = absint( $form_id );
		$session_id = Init::sanitize_session_id( $session_id );
		if ( 0 === $form_id || '' === $session_id || ! Resume_Token::verify( sanitize_text_field( $token ), 'delete', $form_id, $session_id ) ) {
			return false;
		}
		$row = Save_Resume::find_capture( $form_id, $session_id );
		if ( empty( $row ) || ! Save_Resume::is_writable( $row ) ) {
			return false;
		}

		$lifecycle                  = is_array( $row['lifecycle'] ?? null ) ? $row['lifecycle'] : [];
		$lifecycle['explicit_save'] = self::utc_datetime();
		$lifecycle['handed_off_to'] = 'save_resume';

		$done = Save_Resume::update_capture(
			$row,
			[
				'state'         => Save_Resume::STATE_SAVED,
				'abandon_after' => null,
				'lifecycle'     => $lifecycle,
			]
		);
		Partial_Notifications::suppress_pending_for_draft( Helper::get_string_value( $row['id'] ), 'saved_draft' );

		return $done;
	}

	/**
	 * Where a continuation link sends the visitor: the page they filled the form on when
	 * it is on this site, otherwise the form's own permalink.
	 *
	 * @param array<string,mixed> $row Draft row.
	 * @since 2.12.9
	 * @return string
	 */
	public static function destination_url( array $row ) {
		$source = self::clean_source_url( Helper::get_string_value( $row['source_url'] ?? '' ) );
		if ( '' !== $source ) {
			return $source;
		}
		$permalink = get_permalink( absint( $row['form_id'] ?? 0 ) );
		return is_string( $permalink ) ? $permalink : home_url( '/' );
	}

	/**
	 * Reduce a URL to a same-site destination with no credential query arguments.
	 *
	 * @param string $url Candidate URL.
	 * @since 2.12.9
	 * @return string '' when the URL is not on this site.
	 */
	public static function clean_source_url( $url ) {
		$url = esc_url_raw( $url );
		if ( '' === $url ) {
			return '';
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		$home = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! is_string( $host ) || ! is_string( $home ) || strtolower( $host ) !== strtolower( $home ) ) {
			return '';
		}
		// Keep only the query arguments that select a page. Anything else (a redirect_to,
		// a return URL, a token) would let a Referer header decide what a site-branded
		// email links to.
		$query = wp_parse_url( $url, PHP_URL_QUERY );
		if ( is_string( $query ) && '' !== $query ) {
			parse_str( $query, $args );
			$keep = array_intersect_key( $args, array_flip( [ 'p', 'page_id', 'lang' ] ) );
			$url  = add_query_arg( array_map( 'rawurlencode', array_map( [ Helper::class, 'get_string_value' ], $keep ) ), strtok( $url, '?' ) );
		}
		$without_fragment = strtok( $url, '#' );
		return false === $without_fragment ? '' : $without_fragment;
	}

	/**
	 * Register the personal-data exporter.
	 *
	 * @param array<string,mixed> $exporters Exporters.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public function register_exporter( $exporters ) {
		$exporters = is_array( $exporters ) ? $exporters : [];

		$exporters['sureforms-partial-entries'] = [
			'exporter_friendly_name' => __( 'SureForms Partial Entries', 'sureforms-pro' ),
			'callback'               => [ $this, 'export_personal_data' ],
		];
		return $exporters;
	}

	/**
	 * Register the personal-data eraser.
	 *
	 * @param array<string,mixed> $erasers Erasers.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	public function register_eraser( $erasers ) {
		$erasers = is_array( $erasers ) ? $erasers : [];

		$erasers['sureforms-partial-entries'] = [
			'eraser_friendly_name' => __( 'SureForms Partial Entries', 'sureforms-pro' ),
			'callback'             => [ $this, 'erase_personal_data' ],
		];
		return $erasers;
	}

	/**
	 * Export the unfinished submissions that contain an address.
	 *
	 * Core runs this only after the request's identity has been confirmed.
	 *
	 * @param string $email Address.
	 * @param int    $page  Page, from 1.
	 * @since 2.12.9
	 * @return array{data:array<int,array<string,mixed>>,done:bool}
	 */
	public function export_personal_data( $email, $page = 1 ) {
		$rows = self::find_rows_with_email( $email, absint( $page ) );
		$data = [];
		foreach ( $rows as $row ) {
			$items = [];
			foreach ( is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [] as $key => $value ) {
				$label   = Helper::get_field_label_from_key( Helper::get_string_value( $key ) );
				$items[] = [
					'name'  => '' !== $label ? $label : Helper::get_string_value( $key ),
					'value' => is_array( $value ) ? wp_json_encode( $value ) : Helper::get_string_value( $value ),
				];
			}
			$items[] = [
				'name'  => __( 'Last activity', 'sureforms-pro' ),
				'value' => Helper::get_string_value( $row['last_activity_at'] ?? $row['updated_at'] ?? '' ),
			];
			$data[]  = [
				'group_id'    => 'sureforms-partial-entries',
				'group_label' => __( 'SureForms Partial Entries', 'sureforms-pro' ),
				'item_id'     => 'srfm-partial-' . Helper::get_string_value( $row['id'] ?? '' ),
				'data'        => $items,
			];
		}

		return [
			'data' => $data,
			'done' => count( $rows ) < 50,
		];
	}

	/**
	 * Erase the unfinished submissions that contain an address, with their notifications.
	 *
	 * @param string $email Address.
	 * @param int    $page  Page (always the first: erased rows disappear).
	 * @since 2.12.9
	 * @return array{items_removed:bool,items_retained:bool,messages:array<int,string>,done:bool}
	 */
	public function erase_personal_data( $email, $page = 1 ) {
		unset( $page );
		$rows = self::find_rows_with_email( $email, 1 );
		$ids  = [];
		foreach ( $rows as $row ) {
			$id = Helper::get_string_value( $row['id'] ?? '' );
			if ( '' !== $id && false !== Save_Resume::delete_entry( $id ) ) {
				$ids[] = $id;
			}
		}
		Partial_Notifications::delete_for_drafts( $ids );

		return [
			'items_removed'  => ! empty( $ids ),
			'items_retained' => false,
			'messages'       => [],
			'done'           => count( $rows ) < 50,
		];
	}

	/**
	 * Headers for partial-entry mail.
	 *
	 * The sender is the reminder's own From Name / From Email when set, else the saved
	 * SureForms sender, else the defaults core's email notifications use ({site_title} /
	 * {admin_email}). Reply-To comes only from the reminder settings. Only
	 * those two tags are resolved, and every address must pass is_email().
	 *
	 * @param array<string,mixed> $settings Form settings; empty for mail that is not a reminder.
	 * @since 2.12.9
	 * @return array<int,string>
	 */
	public static function mail_headers( array $settings = [] ) {
		$saved = get_option( 'srfm_email_notification_settings_options', [] );
		$saved = is_array( $saved ) ? $saved : [];
		$tags  = [
			'{site_title}'  => wp_specialchars_decode( Helper::get_string_value( get_bloginfo( 'name' ) ), ENT_QUOTES ),
			'{admin_email}' => Helper::get_string_value( get_option( 'admin_email' ) ),
		];
		$pick  = static function ( $own, $global, $fallback ) {
			foreach ( [ $own, $global ] as $value ) {
				if ( is_string( $value ) && '' !== trim( $value ) ) {
					return $value;
				}
			}
			return $fallback;
		};
		$list  = static function ( $value ) use ( $tags ) {
			$out = [];
			foreach ( explode( ',', strtr( Helper::get_string_value( $value ), $tags ) ) as $entry ) {
				$email = trim( $entry );
				if ( '' !== $email && sanitize_email( $email ) === $email && is_email( $email ) ) {
					$out[] = $email;
				}
			}
			return $out;
		};

		$name  = $pick( $settings['reminder_from_name'] ?? '', $saved['from_name'] ?? '', '{site_title}' );
		$email = $pick( $settings['reminder_from_email'] ?? '', $saved['from_email'] ?? '', '{admin_email}' );
		$name  = trim( str_replace( [ "\r", "\n", '<', '>', '"' ], '', strtr( $name, $tags ) ) );
		$email = $list( $email )[0] ?? ( $list( '{admin_email}' )[0] ?? '' );
		if ( '' === $email ) {
			return [];
		}

		$headers  = [ 'From: ' . ( '' !== $name ? $name . ' <' . $email . '>' : $email ) ];
		$reply_to = $list( $settings['reminder_reply_to'] ?? '' );
		if ( ! empty( $reply_to ) ) {
			$headers[] = 'Reply-To: ' . implode( ', ', $reply_to );
		}
		return $headers;
	}

	/**
	 * Most reminders one address may receive in 24 hours, across every draft and form.
	 *
	 * @since 2.12.9
	 * @return int At least 1.
	 */
	private static function recipient_daily_cap() {
		/**
		 * Filter how many visitor reminders one email address may receive per 24 hours.
		 *
		 * @param int $cap Reminders per address per 24 hours. Minimum 1.
		 * @since 2.12.9
		 */
		return max( 1, intval( apply_filters( 'srfm_partial_reminder_recipient_daily_cap', 1 ) ) );
	}

	/**
	 * Most reminders this whole site may send in 24 hours.
	 *
	 * @since 2.12.9
	 * @return int At least 1.
	 */
	private static function site_daily_cap() {
		/**
		 * Filter how many visitor reminders this site may send per 24 hours, across
		 * every form.
		 *
		 * @param int $cap Reminders per site per 24 hours. Minimum 1.
		 * @since 2.12.9
		 */
		return max( 1, intval( apply_filters( 'srfm_partial_daily_site_cap', 500 ) ) );
	}

	/**
	 * Most reminders one form may send in 24 hours.
	 *
	 * @param int $form_id Form id.
	 * @since 2.12.9
	 * @return int
	 */
	private static function form_daily_cap( $form_id ) {
		/**
		 * Filter how many visitor reminders one form may send per 24 hours.
		 *
		 * @param int $cap     Reminders per form per 24 hours. Minimum 1.
		 * @param int $form_id Form id.
		 * @since 2.12.9
		 */
		return max( 1, intval( apply_filters( 'srfm_partial_reminder_form_daily_cap', 200, $form_id ) ) );
	}

	/**
	 * Most owner abandonment notices one form, and the whole site, may send in 24 hours.
	 *
	 * @param int $form_id Form id.
	 * @since 2.12.9
	 * @return array{form:int,site:int}
	 */
	private static function owner_notice_caps( $form_id ) {
		/**
		 * Filter how many owner abandonment notices one form may send per 24 hours.
		 *
		 * @param int $cap     Notices per form per 24 hours. Minimum 1.
		 * @param int $form_id Form id.
		 * @since 2.12.9
		 */
		$form = max( 1, intval( apply_filters( 'srfm_partial_owner_notice_form_daily_cap', 50, $form_id ) ) );

		/**
		 * Filter how many owner abandonment notices this site may send per 24 hours.
		 *
		 * @param int $cap Notices per site per 24 hours. Minimum 1.
		 * @since 2.12.9
		 */
		$site = max( 1, intval( apply_filters( 'srfm_partial_owner_notice_site_daily_cap', 200 ) ) );

		return [
			'form' => $form,
			'site' => $site,
		];
	}

	/**
	 * Why an owner abandonment notice may not go out right now, or ''.
	 *
	 * @param int    $form_id  Form id.
	 * @param string $draft_id Draft whose own claimed row must not count against it.
	 * @param int    $now_ts   Unix time.
	 * @since 2.12.9
	 * @return string '', 'owner_form_cap' or 'owner_site_cap'.
	 */
	private function owner_notice_cap_reason( $form_id, $draft_id, $now_ts ) {
		$since = self::utc_datetime( $now_ts - DAY_IN_SECONDS );
		$caps  = self::owner_notice_caps( $form_id );

		if ( Partial_Notifications::count_recent_handoffs( $since, '', $form_id, Partial_Notifications::TYPE_OWNER_ABANDONMENT ) >= $caps['form'] ) {
			return 'owner_form_cap';
		}
		if ( Partial_Notifications::count_recent_site_sends( $since, $draft_id, Partial_Notifications::TYPE_OWNER_ABANDONMENT ) >= $caps['site'] ) {
			return 'owner_site_cap';
		}

		return '';
	}

	/**
	 * The WP user this request is being made as, 0 for a logged-out visitor.
	 *
	 * The capture endpoint is public and carries no REST nonce, so WordPress
	 * resets the current user to 0 before the callback runs
	 * (`rest_cookie_check_errors()` in wp-includes/rest-api.php). The signed
	 * logged-in cookie still identifies the visitor, and
	 * `wp_validate_auth_cookie()` verifies that signature, so it is consulted
	 * only once the session has already come back empty — an authenticated
	 * request (admin-side, nonce or application password) keeps its own answer.
	 *
	 * Attribution only. Nothing reads this to decide what a request may do; the
	 * capture's own authorisation stays with the session id and delete token.
	 *
	 * @since x.x.x
	 * @return int
	 */
	private static function current_user_id() {
		$user_id = get_current_user_id();
		if ( 0 !== $user_id ) {
			return $user_id;
		}
		return absint( wp_validate_auth_cookie( '', 'logged_in' ) );
	}

	/**
	 * One section of a row's lifecycle metadata, always as an array.
	 *
	 * @param array<string,mixed> $row Draft row (or `[ 'lifecycle' => … ]`).
	 * @param string              $key Section name.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	private static function part( array $row, $key ) {
		$lifecycle = is_array( $row['lifecycle'] ?? null ) ? $row['lifecycle'] : [];
		$section   = $lifecycle[ $key ] ?? null;
		return is_array( $section ) ? $section : [];
	}

	/**
	 * Fold this snapshot's permission into the stored evidence.
	 *
	 * Keeps the original grant time while the same address stays permitted, records a
	 * fresh grant when the address changes, and records withdrawal when the box is
	 * cleared after having been ticked.
	 *
	 * @param array<string,mixed>                                             $lifecycle  Stored lifecycle metadata.
	 * @param array{granted:bool,recipient_hash:string,recipient_hint:string} $permission Permission from this snapshot.
	 * @param string                                                          $now        UTC mysql datetime.
	 * @param string                                                          $ip_hash    Hash of the IP that granted it, '' when unchanged.
	 * @param bool                                                            $may_record Whether this site keeps any record of visitors' addresses.
	 * @since 2.12.9
	 * @return array<string,mixed>
	 */
	private static function apply_permission( array $lifecycle, array $permission, $now, $ip_hash = '', $may_record = true ) {
		$previous = is_array( $lifecycle['reminder_permission'] ?? null ) ? $lifecycle['reminder_permission'] : [];

		if ( $permission['granted'] ) {
			$same = ! empty( $previous['granted'] ) && ( $previous['recipient_hash'] ?? '' ) === $permission['recipient_hash'];

			// Who asked for it, as a hash: enough to count grants per source without
			// keeping the address itself. Carried between saves so re-asserting a grant
			// does not lose it -- but dropped outright once the site says it keeps no
			// record of visitors' addresses. Only skipping the *write* left every hash
			// already on a row exactly where it was when GDPR was switched on.
			$stored_ip = '' !== $ip_hash ? $ip_hash : Helper::get_string_value( $previous['ip_hash'] ?? '' );

			$lifecycle['reminder_permission'] = [
				'granted'        => true,
				'granted_at'     => $same ? ( $previous['granted_at'] ?? $now ) : $now,
				'recipient_hash' => $permission['recipient_hash'],
				'recipient_hint' => $permission['recipient_hint'],
				'ip_hash'        => $may_record ? $stored_ip : '',
				'notice_version' => 1,
			];
			return $lifecycle;
		}

		if ( ! empty( $previous['granted'] ) ) {
			$previous['granted']              = false;
			$previous['withdrawn_at']         = $now;
			$lifecycle['reminder_permission'] = $previous;
		}

		return $lifecycle;
	}

	/**
	 * Queue the notifications a newly abandoned capture is eligible for.
	 *
	 * Each is created at most once per draft, so a visitor who leaves, returns and leaves
	 * again is not reminded twice.
	 *
	 * @param string $id     Draft UUID.
	 * @param int    $now_ts Unix time.
	 * @since 2.12.9
	 * @return void
	 */
	private function on_abandoned( $id, $now_ts ) {
		$row = Save_Resume::get( $id );
		if ( empty( $row ) ) {
			return;
		}
		$form_id  = absint( $row['form_id'] ?? 0 );
		$settings = Init::get_notify_settings( $form_id );
		$now      = self::utc_datetime( $now_ts );

		if ( ! empty( $settings['status'] ) && ! empty( $settings['owner_notice'] ) ) {
			Partial_Notifications::enqueue( Partial_Notifications::TYPE_OWNER_ABANDONMENT, $id, $form_id, $now, $now );
		}

		$reason = $this->get_reminder_block_reason( $row, $settings, $now_ts );
		if ( '' === $reason || 'not_due' === $reason ) {
			$permission = self::part( $row, 'reminder_permission' );
			Partial_Notifications::enqueue(
				Partial_Notifications::TYPE_VISITOR_REMINDER,
				$id,
				$form_id,
				self::utc_datetime( max( $now_ts, self::reminder_due_ts( $row, $settings ) ) ),
				$now,
				Helper::get_string_value( $permission['recipient_hint'] ?? '' ),
				Helper::get_string_value( $permission['recipient_hash'] ?? '' )
			);
		}
	}

	/**
	 * When a capture's reminder is due: the latest activity plus the reminder delay.
	 *
	 * @param array<string,mixed> $row      Draft row.
	 * @param array<string,mixed> $settings Form settings.
	 * @since 2.12.9
	 * @return int Unix time.
	 */
	private static function reminder_due_ts( array $row, array $settings ) {
		return self::to_ts( $row['last_activity_at'] ?? '' ) + absint( $settings['reminder_delay'] ) * MINUTE_IN_SECONDS;
	}

	/**
	 * Claim, re-check and send one due notification, recording what happened.
	 *
	 * @param array<string,mixed> $notification Outbox row.
	 * @param int                 $now_ts       Unix time.
	 * @since 2.12.9
	 * @return void
	 */
	private function process_notification( array $notification, $now_ts ) {
		$id  = absint( $notification['id'] ?? 0 );
		$now = self::utc_datetime( $now_ts );
		if ( ! Partial_Notifications::claim( $id, $now, self::utc_datetime( $now_ts + self::CLAIM_LEASE ) ) ) {
			return;
		}

		$row = Save_Resume::get( Helper::get_string_value( $notification['draft_id'] ?? '' ) );
		if ( empty( $row ) ) {
			Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, 'draft_deleted' );
			return;
		}
		$settings = Init::get_notify_settings( absint( $row['form_id'] ?? 0 ) );
		$type     = Helper::get_string_value( $notification['type'] ?? '' );

		if ( Partial_Notifications::TYPE_VISITOR_REMINDER === $type ) {
			$reason = $this->get_reminder_block_reason( $row, $settings, $now_ts );
			if ( 'not_due' === $reason ) {
				// The visitor came back: re-time rather than drop, so leaving again later
				// still produces the one reminder this draft is allowed.
				Partial_Notifications::requeue( $id, self::utc_datetime( max( $now_ts + self::TICK_INTERVAL, self::reminder_due_ts( $row, $settings ) ) ) );
				return;
			}
			// A cap says "not now", not "never". Suppressing on one meant anybody who
			// spent the day's budget destroyed every legitimate reminder behind it;
			// the draft keeps its place until it ages out through 'stale' instead.
			if ( in_array( $reason, self::CAP_REASONS, true ) ) {
				Partial_Notifications::requeue( $id, self::utc_datetime( $now_ts + self::CAP_RETRY_DELAY ), $reason );
				return;
			}
			if ( '' !== $reason ) {
				Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, $reason );
				return;
			}
			$result = $this->send_visitor_reminder( $row, $settings, $now_ts );
		} elseif ( Partial_Notifications::TYPE_OWNER_ABANDONMENT === $type ) {
			if ( empty( $settings['status'] ) || empty( $settings['owner_notice'] ) ) {
				Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, 'notice_disabled' );
				return;
			}
			if ( Save_Resume::STATE_SUBMITTED === ( $row['state'] ?? '' ) ) {
				Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, 'submitted' );
				return;
			}
			// Age it out before the cap is consulted, the same way a reminder drops out
			// through 'stale'. A cap requeues rather than suppresses, and with nothing
			// ageing these out a burst of abandonments -- exactly what the cap exists
			// for -- drained at 50 a day and owners read about drafts from last week,
			// while every tick claimed and requeued the same backlog.
			if ( $now_ts - self::to_ts( $notification['created_at'] ?? '' ) > self::STALE_AFTER ) {
				Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, 'stale' );
				return;
			}
			// Abandonment is ordinary traffic and needs no email address, so an owner
			// notice is the one message anonymous visitors can make the site send
			// without limit. Bound it per form and across the site, like the reminder.
			$owner_cap = $this->owner_notice_cap_reason( absint( $row['form_id'] ?? 0 ), Helper::get_string_value( $row['id'] ?? '' ), $now_ts );
			if ( '' !== $owner_cap ) {
				Partial_Notifications::requeue( $id, self::utc_datetime( $now_ts + self::CAP_RETRY_DELAY ), $owner_cap );
				return;
			}
			$result = $this->send_owner_notice( $row );
		} else {
			Partial_Notifications::finish( $id, Partial_Notifications::STATUS_SUPPRESSED, 'unknown_type' );
			return;
		}

		if ( true === $result ) {
			Partial_Notifications::finish( $id, Partial_Notifications::STATUS_HANDED_OFF, 'handed_off', null, $now );
			return;
		}
		if ( 'invalid_recipient' === $result ) {
			Partial_Notifications::finish( $id, Partial_Notifications::STATUS_FAILED, 'invalid_recipient' );
			return;
		}

		$attempts = absint( $notification['attempts'] ?? 0 ) + 1;
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			Partial_Notifications::finish( $id, Partial_Notifications::STATUS_FAILED, 'mail_failed' );
			return;
		}
		Partial_Notifications::finish( $id, Partial_Notifications::STATUS_RETRYING, 'mail_failed', self::utc_datetime( $now_ts + self::RETRY_DELAY * $attempts ) );
	}

	/**
	 * Send the visitor reminder for a draft.
	 *
	 * The continuation token is minted here, at dispatch, so its lifetime starts when the
	 * visitor can first use it.
	 *
	 * @param array<string,mixed> $row      Draft row.
	 * @param array<string,mixed> $settings Form settings.
	 * @param int                 $now_ts   Unix time.
	 * @since 2.12.9
	 * @return bool|string True on handoff, false on a transient failure, 'invalid_recipient'.
	 */
	private function send_visitor_reminder( array $row, array $settings, $now_ts ) {
		$email = Capture_Policy::get_reminder_email( is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [], $settings );
		if ( '' === $email ) {
			return 'invalid_recipient';
		}

		// Never $deliberate: this is the worker, and a revoke has to stop it.
		$link = $this->issue_continuation_link( $row, $now_ts );
		if ( '' === $link['url'] ) {
			return false;
		}

		$message = self::render_reminder(
			$settings,
			[
				'form_title'   => self::form_title( absint( $row['form_id'] ?? 0 ) ),
				'continue_url' => $link['url'],
				'expiry_date'  => Helper::get_string_value( wp_date( Helper::get_string_value( get_option( 'date_format' ) ), $link['expires_ts'] ) ),
				'stop_url'     => self::stop_url( $row, $now_ts ),
			]
		);

		return self::send_html_mail( $email, $message['subject'], $message['body'], self::mail_headers( $settings ) );
	}

	/**
	 * Send the owner abandonment notice for a draft. It never includes the answers.
	 *
	 * @param array<string,mixed> $row Draft row.
	 * @since 2.12.9
	 * @return bool|string
	 */
	private function send_owner_notice( array $row ) {
		$form_id   = absint( $row['form_id'] ?? 0 );
		$recipient = Partial_Entry_Notifier::get_instance()->get_default_recipient( $form_id );
		if ( ! is_email( $recipient ) ) {
			return 'invalid_recipient';
		}

		$title = self::form_title( $form_id );
		$link  = admin_url( 'admin.php?page=' . Init::PAGE_SLUG ) . '#/entry/' . rawurlencode( Helper::get_string_value( $row['id'] ?? '' ) );

		/* translators: %s: form title. */
		$subject = sprintf( __( '%s — a visitor left without submitting', 'sureforms-pro' ), $title );
		$body    = '<p>' . esc_html(
			sprintf(
				/* translators: 1: form title, 2: progress percentage. */
				__( 'A visitor stopped filling out "%1$s" at about %2$d%% and has not come back. The form was not submitted.', 'sureforms-pro' ),
				$title,
				absint( $row['progress_percent'] ?? 0 )
			)
		) . '</p><p><a href="' . esc_url( $link ) . '">' . esc_html__( 'View the partial entry', 'sureforms-pro' ) . '</a></p>';

		return self::send_html_mail( $recipient, $subject, $body );
	}

	/**
	 * Stop-reminders URL for a draft.
	 *
	 * @param array<string,mixed> $row    Draft row.
	 * @param int                 $now_ts Unix time.
	 * @since 2.12.9
	 * @return string
	 */
	private static function stop_url( array $row, $now_ts ) {
		unset( $now_ts );
		$form_id = absint( $row['form_id'] ?? 0 );
		return add_query_arg(
			[
				self::STOP_ARG => rawurlencode(
					Resume_Token::issue( 'stop', $form_id, self::stop_subject( $row ), 90 * DAY_IN_SECONDS )
				),
				'form'         => $form_id,
			],
			home_url( '/' )
		);
	}

	/**
	 * The draft and recipient a stop link is signed for.
	 *
	 * The hash travels inside the signature rather than being read from the row when the
	 * link is used. A token that named only the draft suppressed whatever address the
	 * draft happened to hold at that moment, and the draft's email field is visitor
	 * writable for 90 days -- so one received reminder could be turned into a suppression
	 * for any address its holder cared to type in.
	 *
	 * @param array<mixed> $row Draft row.
	 * @since 2.12.9
	 * @return string `<draft id>|<recipient hash>`, or the id alone when no permission
	 *                evidence is stored.
	 */
	private static function stop_subject( array $row ) {
		$id   = Helper::get_string_value( $row['id'] ?? '' );
		$hash = Helper::get_string_value( self::part( $row, 'reminder_permission' )['recipient_hash'] ?? '' );

		return '' === $hash ? $id : $id . '|' . $hash;
	}

	/**
	 * Split what stop_subject() signed back into a draft id and a recipient hash.
	 *
	 * @param string $subject Decoded token subject.
	 * @since 2.12.9
	 * @return array{0:string,1:string} Draft id, recipient hash ('' when the token
	 *                                  predates the binding).
	 */
	private static function parse_stop_subject( $subject ) {
		$parts = explode( '|', (string) $subject, 2 );

		return [ $parts[0], $parts[1] ?? '' ];
	}

	/**
	 * Raw form title, or a numbered fallback.
	 *
	 * @param int $form_id Form id.
	 * @since 2.12.9
	 * @return string
	 */
	private static function form_title( $form_id ) {
		$title = (string) get_post_field( 'post_title', $form_id, 'raw' );
		/* translators: %d: form ID. */
		return '' !== $title ? $title : sprintf( __( 'Form #%d', 'sureforms-pro' ), $form_id );
	}

	/**
	 * Rows whose stored answers contain an address.
	 *
	 * @param string $email Address.
	 * @param int    $page  Page, from 1.
	 * @since 2.12.9
	 * @return array<int,array<string,mixed>>
	 */
	private static function find_rows_with_email( $email, $page ) {
		$email = sanitize_email( Helper::get_string_value( $email ) );
		if ( ! is_email( $email ) ) {
			return [];
		}
		global $wpdb;
		$table = Save_Resume::get_instance()->get_tablename();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- privacy request lookup; $table is get_tablename().
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE ( form_data LIKE %s OR email = %s ) ORDER BY partial_entry_id ASC LIMIT 50 OFFSET %d",
				'%' . $wpdb->esc_like( '"' . $email . '"' ) . '%',
				$email,
				( max( 1, $page ) - 1 ) * 50
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$rows = [];
		foreach ( is_array( $ids ) ? $ids : [] as $id ) {
			$row = Save_Resume::get( Helper::get_string_value( $id ) );
			if ( ! empty( $row ) ) {
				$rows[] = $row;
			}
		}
		return $rows;
	}
}
