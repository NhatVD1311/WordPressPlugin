<?php
/**
 * PHP render form NPS Block.
 *
 * @package sureforms-pro.
 */

namespace SRFM_Pro\Inc\Blocks\Nps;

use SRFM_Pro\Inc\Blocks\Base;
use SRFM_Pro\Inc\Fields\Nps_Markup;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * NPS Block.
 */
class Block extends Base {
	/**
	 * Render the block
	 *
	 * @param array<mixed> $attributes Block attributes.
	 *
	 * @return string|bool
	 */
	public function render( $attributes ) {
		// Return before touching the output buffer. ob_get_clean() used to run even
		// when nothing had been started, which closes whatever buffer the CALLER
		// opened and hands back its contents - so a block with no attributes
		// silently swallowed the surrounding output instead of rendering nothing.
		if ( empty( $attributes ) ) {
			return '';
		}

		$markup_class = new Nps_Markup( $attributes );

		ob_start();
		// phpcs:ignore
		echo $markup_class->markup();

		$markup = ob_get_clean();

		return is_string( $markup ) ? $markup : '';
	}
}
