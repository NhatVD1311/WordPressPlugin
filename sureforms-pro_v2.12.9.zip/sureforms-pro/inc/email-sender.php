<?php
/**
 * Sends Pro's emails the way free sends notifications.
 *
 * @package sureforms-pro
 * @since   2.12.9
 */

namespace SRFM_Pro\Inc;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email_Sender
 *
 * Free owns the rules -- whether raw PHP mail() may be tried, how a rejection
 * is worded, and the site's recorded email delivery state (#3150). Every call
 * into free is guarded, so an older free release degrades to "no fallback, no
 * recorded state" rather than a fatal.
 *
 * @since 2.12.9
 */
class Email_Sender {
	/**
	 * Hand one email to wp_mail().
	 *
	 * Output is buffered because some mail plugins echo notices instead of
	 * throwing, which corrupts a JSON response. The wp_mail_failed listener is
	 * attached for this call only, so a later, unrelated wp_mail() in the same
	 * request cannot overwrite the reason recorded here.
	 *
	 * @param string               $to      Recipient(s).
	 * @param string               $subject Subject.
	 * @param string               $message Body.
	 * @param string|array<string> $headers Headers.
	 * @param int                  $form_id Form the email belongs to.
	 * @param string               $context What is being sent, e.g. 'save_resume'.
	 * @since 2.12.9
	 * @return array{sent:bool,via_php_mail:bool,error:string}
	 */
	public static function send( $to, $subject, $message, $headers, $form_id = 0, $context = 'notification' ) {
		$error   = '';
		$capture = static function ( $wp_error ) use ( &$error ) {
			if ( is_wp_error( $wp_error ) ) {
				$error = $wp_error->get_error_message();
			}
		};

		add_action( 'wp_mail_failed', $capture );
		ob_start();
		$output = '';

		// try/finally, as in the partial-entry notifier: a mailer that throws
		// must not leave the listener on or the output buffer open.
		try {
			$sent         = (bool) wp_mail( $to, $subject, $message, $headers );
			$via_php_mail = false;

			if ( ! $sent && self::allow_php_mail_fallback( $form_id, $context ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions -- Owner opted in via srfm_allow_php_mail_fallback.
				$sent         = mail( $to, $subject, $message, is_array( $headers ) ? implode( "\r\n", $headers ) : $headers );
				$via_php_mail = $sent;
			}
		} finally {
			$output = ob_get_clean();
			remove_action( 'wp_mail_failed', $capture );
		}

		return [
			'sent'         => $sent,
			'via_php_mail' => $via_php_mail,
			'error'        => '' !== $error ? $error : trim( is_string( $output ) ? $output : '' ),
		];
	}

	/**
	 * Whether a failed wp_mail() may be retried through PHP's mail().
	 *
	 * Free decides, so both plugins follow one rule: off by default, and never
	 * with a mail plugin active. A free release without the rule means no
	 * fallback -- the reasons for removing it do not depend on the version.
	 *
	 * @param int    $form_id Form the email belongs to.
	 * @param string $context What is being sent.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function allow_php_mail_fallback( $form_id, $context ) {
		$gate = [ '\SRFM\Inc\Email_Delivery\Mailer', 'allow_php_mail_fallback' ];

		return is_callable( $gate ) && (bool) call_user_func( $gate, (int) $form_id, (string) $context );
	}

	/**
	 * Why the active mailer did not accept an email, when it gave no reason.
	 *
	 * @since 2.12.9
	 * @return string Empty when free cannot say.
	 */
	public static function rejection_reason() {
		$reason = [ '\SRFM\Inc\Email_Delivery\Mailer', 'get_rejection_reason' ];

		if ( ! is_callable( $reason ) ) {
			return '';
		}

		$result = call_user_func( $reason );

		return is_array( $result ) && isset( $result['message'] ) && is_string( $result['message'] ) ? $result['message'] : '';
	}

	/**
	 * Whether a failed send is down only to an address a visitor typed, so it
	 * says nothing about the site's mail setup. Free decides; without it,
	 * every failure is the site's.
	 *
	 * Asked with no visitor addresses: nothing a resend is sent to was typed by
	 * a visitor at resend time. So every refusal counts, including the "554
	 * Relay access denied" and "530 Authentication required" that PHPMailer
	 * reports at the recipient step, which are the site's setup failing.
	 *
	 * @param string $message Error message from wp_mail_failed.
	 * @since 2.12.9
	 * @return bool
	 */
	public static function is_visitor_recipient_failure( $message ) {
		$check = [ '\SRFM\Inc\Email_Delivery\Mailer', 'is_visitor_recipient_failure' ];

		return is_callable( $check ) && (bool) call_user_func( $check, (string) $message, [], false );
	}

	/**
	 * Record a notification outcome in the site's email delivery state.
	 *
	 * @param bool   $accepted Whether wp_mail() accepted the email.
	 * @param int    $form_id  Form the email belongs to.
	 * @param string $reason   Short reason code for a failure.
	 * @since 2.12.9
	 * @return void
	 */
	public static function record_outcome( $accepted, $form_id, $reason = '' ) {
		$record = [ '\SRFM\Inc\Email_Delivery\Status', 'record_outcome' ];

		if ( is_callable( $record ) ) {
			call_user_func( $record, (bool) $accepted, (int) $form_id, (string) $reason );
		}
	}
}
