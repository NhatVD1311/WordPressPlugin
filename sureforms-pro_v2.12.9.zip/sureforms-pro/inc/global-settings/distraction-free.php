<?php
/**
 * Distraction Free mode.
 *
 * @package sureforms-pro
 * @since   2.12.8
 */

namespace SRFM_Pro\Inc\Global_Settings;

use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Hides SureForms promotional content in wp-admin while the setting is on.
 *
 * The free plugin decides where its promotions appear and asks
 * `srfm_hide_promotions` whether to show them; this class owns the setting
 * and answers that filter. It also reads logs (`srfm_enable_logs`) and
 * anonymous analytics (`sureforms_tracking_enabled`) as off while on, through
 * their filters, so their stored values are untouched and apply again once
 * the setting is off.
 *
 * @since 2.12.8
 */
class Distraction_Free {
	use Get_Instance;

	/**
	 * Option holding the setting.
	 *
	 * @since 2.12.8
	 */
	public const OPTION = 'srfm_pro_distraction_free';

	/**
	 * Constructor.
	 *
	 * @since 2.12.8
	 */
	public function __construct() {
		add_filter( 'srfm_hide_promotions', [ $this, 'hide_promotions' ] );
		add_filter( 'srfm_enable_logs', [ $this, 'off_while_enabled' ] );
		add_filter( 'sureforms_tracking_enabled', [ $this, 'off_while_enabled' ] );
	}

	/**
	 * Answer the free plugin's `srfm_hide_promotions` filter.
	 *
	 * @param bool $hide Whether promotions are already hidden.
	 * @since 2.12.8
	 * @return bool
	 */
	public function hide_promotions( $hide ) {
		return (bool) $hide || self::is_enabled();
	}

	/**
	 * Read a setting as off while Distraction Free is on, and as its stored
	 * value otherwise.
	 *
	 * @param bool $enabled The setting's current value.
	 * @since 2.12.8
	 * @return bool
	 */
	public function off_while_enabled( $enabled ) {
		return ! self::is_enabled() && (bool) $enabled;
	}

	/**
	 * Whether Distraction Free mode is on.
	 *
	 * @since 2.12.8
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) get_option( self::OPTION, false );
	}

	/**
	 * Save the setting from the Settings → General toggle.
	 *
	 * @param array<mixed> $settings Submitted settings; `enabled` is the toggle.
	 * @since 2.12.8
	 * @return bool Whether the stored value now matches the submitted one.
	 */
	public static function save( $settings ) {
		$enabled = wp_validate_boolean( $settings['enabled'] ?? false );

		update_option( self::OPTION, $enabled );

		// update_option() returns false when the value is unchanged, which is
		// still a successful save.
		return self::is_enabled() === $enabled;
	}
}
