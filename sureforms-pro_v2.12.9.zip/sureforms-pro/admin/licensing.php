<?php
/**
 * Licensing Class
 *
 * This class handles all licensing related stuff.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Admin;

use SRFM_Pro\Inc\Traits\Get_Instance;
use SRFM\Inc\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Licensing handler class.
 *
 * @since 0.0.1
 */

class Licensing {

	use Get_Instance;

	/**
	 * Transient key holding the cached result of the remote license check.
	 *
	 * @since 2.12.8
	 */
	const LICENSE_STATUS_TRANSIENT = 'srfm_pro_license_status_cache';

	/**
	 * Error messages.
	 *
	 * @var array
	 */
	public $error_messages = [];

	/**
	 * Class constructor
	 *
	 * @since 0.0.1
	 * @return void
	 */
	public function __construct() {
		// licensing_setup() loads the SDK itself, so there is no separate require here.
		self::licensing_setup();

		$this->set_error_messages();

		add_action( 'wp_ajax_sureforms_activate_license', [ $this, 'activate_license' ] );
		add_action( 'wp_ajax_sureforms_deactivate_license', [ $this, 'deactivate_license' ] );

		add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'add_sureforms_pro_logo']);
	}

	/**
	 * Licensing setup.
	 * Creates a client object for SureCart licensing.
	 *
	 * @since 0.0.1
	 * @return \SureCart\Licensing\Client
	 */
	public static function licensing_setup() {
		if ( ! class_exists( 'SureCart\Licensing\Client' ) ) {
			require_once SRFM_PRO_DIR . '/licensing/Client.php';
		}

		$client = new \SureCart\Licensing\Client(
			SRFM_PRO_PRODUCT, SRFM_PRO_PUBLIC_TOKEN, SRFM_PRO_FILE );

		return $client;
	}

	/**
	 * Set error messages.
	 *
	 * @since 0.0.1
	 * @return void
	 */
	private function set_error_messages() {
		$this->error_messages = [
			'nonce' => __( 'Invalid nonce.', 'sureforms-pro' ),
			'permission' => __( 'You do not have permission to activate license.', 'sureforms-pro' ),
			'invalid_license' => __( 'Please enter a valid license key', 'sureforms-pro' ),
		];

	}

	/**
	 * Activate license
	 *
	 * @hooked wp_ajax_sureforms_activate_license
	 * @since 0.0.1
	 * @return void
	 */
	public function activate_license() {
		if( ! check_ajax_referer( 'srfm_pro_licensing_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['nonce'] ] );
		}

		if( ! Helper::current_user_can() ) {
			wp_send_json_error( [ 'message' => $this->error_messages['permission'] ] );
		}

		$license_key = ! empty( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';

		if ( empty( $license_key ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['invalid_license'] ] );
		}

		$client = self::licensing_setup();

		$get_license = $client->license()->retrieve( $license_key );

		if( !empty( $get_license->product ) && $get_license->product !== SRFM_PRO_PRODUCT_ID ) {
			wp_send_json_error( [ 'message' => __( 'Incorrect License key for this product.', 'sureforms-pro' ) ] );
		}

		$response = $client->license()->activate( $license_key );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'message' => $response->get_error_message() ] );
		}

		// Update the license status in the database after activating the license.
		update_option( 'srfm_pro_license_status', 'licensed' );
		self::flush_license_status_cache();
		wp_send_json_success( [ 'message' => __( 'License activated successfully.', 'sureforms-pro' ) ] );
	}

	/**
	 * Deactivate license.
	 *
	 * @hooked wp_ajax_sureforms_deactivate_license
	 * @since 0.0.1
	 * @return void
	 */
	public function deactivate_license() {
		if( ! check_ajax_referer( 'srfm_pro_licensing_nonce', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => $this->error_messages['nonce'] ] );
		}

		if( ! Helper::current_user_can() ) {
			wp_send_json_error( [ 'message' => $this->error_messages['permission'] ] );
		}

		$client = self::licensing_setup();

		$response = $client->license()->deactivate();

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'message' => $response->get_error_message() ] );
		}

		// Update the license status in the database after deactivating the license.
		update_option( 'srfm_pro_license_status', 'unlicensed' );
		self::flush_license_status_cache();
		wp_send_json_success( [ 'message' => __( 'License deactivated successfully.', 'sureforms-pro' ) ] );
	}

	/**
	 * Checks if license is active.
	 *
	 * This is a read-through cache that writes: a *verified* answer is stored in a
	 * transient and mirrored into the `srfm_pro_license_status` option, so admin
	 * screens - which can call this on every page load - do not make two blocking
	 * API requests each time. The cache is flushed on activation and deactivation.
	 *
	 * A check that could not reach SureCart is never treated as a verdict. It neither
	 * writes the option nor takes the long cache window; it returns the last known
	 * status and retries shortly. Only a successful response, a real `not_found`, a
	 * wrong-product key or a missing key are allowed to persist a status.
	 *
	 * @param bool $allow_remote_check Whether a cache miss is allowed to hit the API.
	 *                                 Pass false from unattended contexts such as cron,
	 *                                 where a blocking request should never be made.
	 * @since 0.0.1
	 * @since 2.12.8 Added caching and the $allow_remote_check parameter.
	 * @return boolean
	 */
	public static function is_license_active( $allow_remote_check = true ) {
		$cached = get_transient( self::LICENSE_STATUS_TRANSIENT );

		if ( false !== $cached ) {
			return 'active' === $cached;
		}

		if ( ! $allow_remote_check ) {
			// Nothing cached and we must not block on the API, so fall back to the last known status.
			return self::get_stored_license_status();
		}

		$client = self::licensing_setup();

		// getting license key from settings.
		// We want to determine if the saved license key is valid for this product.
		$license_key = $client->settings()->license_key;

		/*
		 * No key stored is a verified "inactive", so it is cached like any other verdict.
		 * This also repairs sites damaged by SDK 1.0.1, whose clear_options() wiped the
		 * key while leaving srfm_pro_license_status on its stale 'licensed' value.
		 */
		if ( empty( $license_key ) ) {
			self::cache_license_status( false );
			return false;
		}

		$activation_id = $client->settings()->activation_id;

		// A key with no activation for this site is inactive without asking the API.
		if ( empty( $activation_id ) ) {
			self::cache_license_status( false );
			return false;
		}

		// retrieve the license from the server.
		$get_license = $client->license()->retrieve( $license_key );

		if ( is_wp_error( $get_license ) ) {
			// A 404 here means the key itself no longer exists - that is a verdict.
			if ( 'not_found' === $get_license->get_error_code() ) {
				self::cache_license_status( false );
				return false;
			}

			return self::hold_last_known_status();
		}

		// if the license is not valid for this product, return false.
		if ( ! empty( $get_license->product ) && $get_license->product !== SRFM_PRO_PRODUCT_ID ) {
			self::cache_license_status( false );
			return false;
		}

		$activation = $client->activation()->get( $activation_id );

		if ( is_wp_error( $activation ) ) {
			// A 404 is SureCart telling us the activation is gone - that is a verdict.
			if ( 'not_found' === $activation->get_error_code() ) {
				self::cache_license_status( false );
				return false;
			}

			// Anything else - timeout, 429, 5xx, 401 - proves nothing either way.
			return self::hold_last_known_status();
		}

		$is_active = ! empty( $activation->id );

		self::cache_license_status( $is_active );

		return $is_active;
	}

	/**
	 * Read the last status that was actually verified against SureCart.
	 *
	 * @since 2.12.8
	 * @return bool
	 */
	private static function get_stored_license_status() {
		return 'licensed' === get_option( 'srfm_pro_license_status' );
	}

	/**
	 * Handle a check that could not be completed.
	 *
	 * Keeps serving the last verified status and schedules a short retry. Deliberately
	 * does not touch `srfm_pro_license_status`: an unreachable API is not evidence that
	 * a license is valid, and that option is what unattended callers trust.
	 *
	 * @since 2.12.8
	 * @return bool
	 */
	private static function hold_last_known_status() {
		$last_known = self::get_stored_license_status();

		set_transient(
			self::LICENSE_STATUS_TRANSIENT,
			$last_known ? 'active' : 'inactive',
			15 * MINUTE_IN_SECONDS
		);

		return $last_known;
	}

	/**
	 * Cache a verified result of the remote license check.
	 *
	 * An active license is cached for longer than an inactive one so that a site
	 * recovers quickly once the license is fixed, without re-checking on every load.
	 *
	 * The stored status is kept in sync as well, since that is what unattended
	 * contexts fall back to when the cache has expired. Only call this with a status
	 * SureCart actually confirmed - see hold_last_known_status() for the other case.
	 *
	 * @param bool $is_active Whether the license is currently active.
	 * @since 2.12.8
	 * @return void
	 */
	private static function cache_license_status( $is_active ) {
		set_transient(
			self::LICENSE_STATUS_TRANSIENT,
			$is_active ? 'active' : 'inactive',
			$is_active ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS
		);

		update_option( 'srfm_pro_license_status', $is_active ? 'licensed' : 'unlicensed' );
	}

	/**
	 * Flush the cached license status.
	 *
	 * @since 2.12.8
	 * @return void
	 */
	public static function flush_license_status_cache() {
		delete_transient( self::LICENSE_STATUS_TRANSIENT );
	}

	/**
	 * Adds logo for SureForms Pro plugins on updater page
	 *
	 * @param object $transient
	 * @since 1.7.0
	 * @return object
	 */
	public function add_sureforms_pro_logo( $transient ) {
		$plugin_slug = 'sureforms-pro/sureforms-pro.php';

		if (isset($transient->response[$plugin_slug])) {
			$plugin_data = $transient->response[$plugin_slug];

			// Only update the icons
			$plugin_data->icons = [
				'1x' => SRFM_PRO_URL . 'assets/icons/icon-128x128.gif',
				'2x' => SRFM_PRO_URL . 'assets/icons/icon-256x256.gif',
			];

			$transient->response[$plugin_slug] = $plugin_data;
		}

		return $transient;
	}
}
