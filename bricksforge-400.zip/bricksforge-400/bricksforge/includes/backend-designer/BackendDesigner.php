<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Backend Designer Handler
 */
class BackendDesigner
{
    /** Whether at least one Menu Editor folder was created this request. */
    private $folder_styles_needed = false;

    public function __construct()
    {
        $this->init();
    }

    public function init()
    {
        if ($this->activated() === true) {
            // Snapshot of the untouched admin menu for the Menu Editor UI.
            // Registered before run() so it also works before the first save.
            add_action('admin_menu', [$this, 'capture_menu_snapshot'], PHP_INT_MAX - 5);

            $this->run();
        }
    }

    public function activated()
    {
        return get_option('brf_activated_tools') && in_array(9, get_option('brf_activated_tools'));
    }

    /**
     * Get a value from data - handles both object and array formats
     */
    private function get_value($data, $key, $default = null)
    {
        if (is_object($data) && isset($data->$key)) {
            return $data->$key;
        } elseif (is_array($data) && isset($data[$key])) {
            return $data[$key];
        }
        return $default;
    }

    /**
     * Get a nested value from data - handles both object and array formats
     */
    private function get_nested_value($data, $keys, $default = null)
    {
        foreach ($keys as $key) {
            if (is_object($data) && isset($data->$key)) {
                $data = $data->$key;
            } elseif (is_array($data) && isset($data[$key])) {
                $data = $data[$key];
            } else {
                return $default;
            }
        }
        return $data;
    }

    public function passed_exception_tests($settings)
    {
        $has_exceptions = $this->get_value($settings, 'hasExceptions', false);

        if (!$has_exceptions) {
            return true;
        }

        $exceptions = $this->get_value($settings, 'exceptions');

        if (!$exceptions || !is_array($exceptions)) {
            return true;
        }

        // Get Current Url
        $url = is_ssl() ? 'https://' : 'http://';
        $url .= $_SERVER['HTTP_HOST'];
        $url .= $_SERVER['REQUEST_URI'];

        foreach ($exceptions as $exception) {
            $exception_value = $this->get_value($exception, 'value');
            $exception_type = $this->get_value($exception, 'type');

            if (empty($exception_value)) {
                continue;
            }

            switch ($exception_type) {
                case 'url_contains':
                    if (strpos($url, $exception_value) !== false) {
                        return false;
                    }
                    break;
                case 'url_is_exactly':
                    if ($url == $exception_value) {
                        return false;
                    }
                    break;
                default:
                    break;
            }
        }

        return true;
    }

    public function run()
    {
        $settings = get_option('brf_backend_designer');

        if (!$settings) {
            return;
        }

        // If not pass the exception tests, return
        if (!$this->passed_exception_tests($settings)) {
            return;
        }

        $login_settings = $this->get_value($settings, 'loginSettings');
        $backend_settings = $this->get_value($settings, 'backendSettings');
        $dashboard_settings = $this->get_value($settings, 'dashboardSettings');
        $status = $this->get_value($settings, 'status');

        $status_login_page = $status ? $this->get_value($status, 'loginPage', false) : false;
        $status_dashboard = $status ? $this->get_value($status, 'dashboard', false) : false;

        if ($login_settings && $status_login_page == true) {
            $this->login_settings($login_settings);
        }

        if ($backend_settings) {
            $this->backend_settings($backend_settings, $status);
        }

        if ($dashboard_settings && $status_dashboard == true) {
            $this->dashboard_settings($dashboard_settings);
        }

        $menu_editor = $this->get_value($settings, 'menuEditor');
        $status_menu_editor = $status ? $this->get_value($status, 'menuEditor', false) : false;

        if ($menu_editor && $status_menu_editor == true) {
            $this->menu_editor_settings($menu_editor);
        }

        $custom_login = $login_settings ? $this->get_value($login_settings, 'customLogin') : null;

        if ($custom_login && $status_login_page == true) {
            add_action('parse_request', function () use ($custom_login) {
                $this->handler_custom_login($custom_login);
            });
            add_action('login_init', [$this, 'check_custom_login']);
        }
    }

    public function handler_custom_login($custom_login)
    {

        if (!$custom_login || !is_string($custom_login)) {
            return;
        }

        if (strpos($custom_login, '/') === true) {
            return;
        }

        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        if (basename($path) === $custom_login) {
            $nonce = wp_create_nonce('brf-custom-login');
            setcookie('brf_custom_login', $nonce);
            wp_redirect(wp_login_url());
            exit;
        }
    }

    public function check_custom_login()
    {
        $nonce = isset($_COOKIE['brf_custom_login']) ? $_COOKIE['brf_custom_login'] : '';
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        $previous_page_action = '';
        $loggedout = isset($_GET['loggedout']) ? $_GET['loggedout'] : '';

        $previous_page = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : false;

        if ($previous_page) {
            if ($previous_page) {
                // Check for ?action=resetpass in the previous page
                if (strpos($previous_page, '?action=resetpass') !== false) {
                    $previous_page_action = 'resetpass';
                }
            }
        }

        if (!wp_verify_nonce($nonce, 'brf-custom-login') && $action !== 'logout' && $action !== 'confirm_admin_email' && $action !== 'lostpassword' && $action !== 'rp' && $action !== 'resetpass' && $previous_page_action !== 'resetpass' && $loggedout !== 'true') {
            header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
            exit;
        }
    }

    /**
     * Summary of login_settings
     * @param mixed $settings
     * @return void
     */
    public function login_settings($settings)
    {
        add_action('login_enqueue_scripts', function () use ($settings) {
            wp_enqueue_style('brf-custom-login', BRICKSFORGE_ASSETS . '/css/backend-designer/login.css', array(), false, 'screen');
            $output = $this->generate_login_styles($settings);
            wp_add_inline_style('brf-custom-login', $output);
        });
    }

    private function generate_login_styles($settings)
    {
        // Ensure settings is an object
        if (is_array($settings)) {
            $settings = json_decode(json_encode($settings));
        }

        $css_rules = '';

        $forms_border_color = $this->get_value($settings, 'formsBorderColor', '');
        $link_color = $this->get_value($settings, 'linkColor', '');

        $css_rules .= 'body.login input:focus { box-shadow: none; border-color: ' . $forms_border_color . '; } ';

        $css_rules .= 'body.login .dashicons-visibility:before { color: ' . $link_color . '; } ';

        if (isset($settings->backgroundColor) && $settings->backgroundColor) {
            $css_rules .= 'body.login { background-color: ' . $settings->backgroundColor . '; } ';
        }

        if (isset($settings->backgroundColor2) && $settings->backgroundColor2) {
            $css_rules .= 'body.login { background: linear-gradient(to bottom, ' . $settings->backgroundColor . ' 0%, ' . $settings->backgroundColor2 . ' 100%)!important; } ';
        }

        if (isset($settings->backgroundImage) && $settings->backgroundImage) {
            $css_rules .= 'body.login { background-image: url(' . $settings->backgroundImage . ')!important; background-size: cover!important; } ';
        }

        if (isset($settings->backgroundImageOverlay) && $settings->backgroundImageOverlay) {
            $css_rules .= 'body.login::before { background-color: ' . $settings->backgroundImageOverlay . '!important; content: ""; position: fixed; left: 0; top: 0; right: 0; bottom: 0; z-index: -1; } ';
        }

        if (isset($settings->boxColor) && $settings->boxColor) {
            $css_rules .= 'body.login form, .login #login_error, .login .message, .login .success { background-color: ' . $settings->boxColor . '; border-color: ' . $settings->boxColor . '; } ';
        }

        if (isset($settings->textColor) && $settings->textColor) {
            $css_rules .= 'body.login { color: ' . $settings->textColor . '; } ';
        }

        if (isset($settings->linkColor) && $settings->linkColor) {
            $css_rules .= 'body.login a { color: ' . $settings->linkColor . '!important; } ';
        }

        if (isset($settings->linkHoverColor) && $settings->linkHoverColor) {
            $css_rules .= 'body.login a:hover { color: ' . $settings->linkHoverColor . '!important; } ';
        }

        if (isset($settings->backgroundColor) && $settings->backgroundColor) {
            $css_rules .= 'body.login { background-color: ' . $settings->backgroundColor . '; } ';
        }

        if (isset($settings->backgroundColor2) && $settings->backgroundColor2) {
            $css_rules .= 'body.login { background: linear-gradient(to bottom, ' . $settings->backgroundColor . ' 0%, ' . $settings->backgroundColor2 . ' 100%)!important; } ';
        }

        if (isset($settings->backgroundImage) && $settings->backgroundImage) {
            $css_rules .= 'body.login { background-image: url(' . $settings->backgroundImage . ')!important; background-size: cover!important; } ';
        }

        if (isset($settings->backgroundImageOverlay) && $settings->backgroundImageOverlay) {
            $css_rules .= 'body.login::before { background-color: ' . $settings->backgroundImageOverlay . '!important; content: ""; position: fixed; left: 0; top: 0; right: 0; bottom: 0; z-index: -1; } ';
        }

        if (isset($settings->boxColor) && $settings->boxColor) {
            $css_rules .= 'body.login form, .login #login_error, .login .message, .login .success { background-color: ' . $settings->boxColor . '; border-color: ' . $settings->boxColor . '; } ';
        }

        if (isset($settings->textColor) && $settings->textColor) {
            $css_rules .= 'body.login { color: ' . $settings->textColor . '; } ';
        }

        if (isset($settings->linkColor) && $settings->linkColor) {
            $css_rules .= 'body.login a { color: ' . $settings->linkColor . '!important; } ';
        }

        if (isset($settings->linkHoverColor) && $settings->linkHoverColor) {
            $css_rules .= 'body.login a:hover { color: ' . $settings->linkHoverColor . '!important; } ';
        }

        if (isset($settings->buttonColor) && $settings->buttonColor) {
            $css_rules .= 'body.login input[type=submit] { background-color: ' . $settings->buttonColor . '; border-color: ' . $settings->buttonColor . '; } ';
        }

        if (isset($settings->buttonHoverColor) && $settings->buttonHoverColor) {
            $css_rules .= 'body.login input[type=submit]:hover, body.login input[type=submit]:active, body.login input[type=submit]:focus { background-color: ' . $settings->buttonHoverColor . '; border-color: ' . $settings->buttonHoverColor . '; outline: none; box-shadow: none; } ';
        }

        if (isset($settings->buttonTextColor) && $settings->buttonTextColor) {
            $css_rules .= 'body.login input[type=submit] { color: ' . $settings->buttonTextColor . '!important; } ';
        }

        if (isset($settings->formsBackgroundColor) && $settings->formsBackgroundColor) {
            $css_rules .= 'body.login input[type=text], body.login input[type=password], select, body.login form input[type=checkbox] { background-color: ' . $settings->formsBackgroundColor . '!important; } ';
        }

        if (isset($settings->formsBorderColor) && $settings->formsBorderColor) {
            $css_rules .= 'body.login input[type=text], body.login input[type=password], select, body.login form input[type=checkbox] { border-color: ' . $settings->formsBorderColor . '!important; } ';
        }

        if (isset($settings->formsTextColor) && $settings->formsTextColor) {
            $css_rules .= 'body.login input[type=text], body.login input[type=password], select, body.login form input[type=checkbox] { color: ' . $settings->formsTextColor . '!important; } ';
        }

        if (isset($settings->formsFontSize) && $settings->formsFontSize) {
            $css_rules .= 'body.login input[type=text], body.login input[type=password] { font-size: ' . $settings->formsFontSize . '!important; } ';
        }

        /**
         * Forms Padding
         */
        if (isset($settings->formsPadding) && $settings->formsPadding) {
            $css_rules .= 'body.login input[type=text], body.login input[type=password] { padding: ' . $settings->formsPadding . '!important; }';
        }

        /**
         * Change Logo
         */
        if (isset($settings->logo) && $settings->logo) {
            $css_rules .= 'body.login h1 a { background-image: url(' . $settings->logo . ')!important; background-size: contain!important; width: 100%!important; }';
        }

        /**
         * Logo Height
         */
        if (isset($settings->logoHeight) && $settings->logoHeight) {
            $css_rules .= 'body.login h1 a { height: ' . $settings->logoHeight . '!important; }';
        }

        /**
         * Logo Negative Margin Top
         */
        if (isset($settings->negativeMarginTop) && $settings->negativeMarginTop) {
            $css_rules .= 'body.login h1 a { margin-top: -' . $settings->negativeMarginTop . '!important; }';
        }

        /**
         * Remove Logo Link
         */
        if (isset($settings->removeLogoLink) && $settings->removeLogoLink) {
            $css_rules .= 'body.login h1 a { pointer-events: none!important; }';
        }

        /**
         * Box Width
         */
        if (isset($settings->boxWidth) && $settings->boxWidth) {
            $css_rules .= 'body.login #login { width: ' . $settings->boxWidth . ' }';

            // We add a max-width for mobile devices
            $css_rules .= '@media (max-width: 1024px) { body.login #login { max-width: 90%; } }';
        }

        /**
         * Box Padding
         */
        if (isset($settings->boxPadding) && $settings->boxPadding) {
            $css_rules .= 'body.login #loginform { padding: ' . $settings->boxPadding . ' }';
        }

        /**
         * Box Border Radius
         */
        if (isset($settings->boxBorderRadius) && $settings->boxBorderRadius) {
            $css_rules .= 'body.login #loginform { border-radius: ' . $settings->boxBorderRadius . '!important }';
        }

        /**
         * Glassmorphism Effect
         *
         * The effect has its own toggle, so it must work on its own. When no
         * usable box colour is set (empty, or the "transparent" keyword), fall
         * back to a neutral white frost instead of silently doing nothing.
         */
        if (isset($settings->glassmorphism) && $settings->glassmorphism) {
            $glassBase = isset($settings->boxColor) ? trim($settings->boxColor) : '';

            if ($glassBase === '' || strtolower($glassBase) === 'transparent') {
                $glassBase = '#ffffff';
            }

            $boxColorWithOpacity = $this->modifyColorOpacity($glassBase, '20');
            $borderColorWithOpacity = $this->modifyColorOpacity($glassBase, '30');
            $css_rules .= 'body.login #loginform, body.login form, .login #login_error, body.login .message { background: ' . $boxColorWithOpacity . '; border-radius: 16px; box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1); backdrop-filter: blur(5px); -webkit-backdrop-filter: blur(5px); border: 1px solid ' . $borderColorWithOpacity . ';}';
        }

        /**
         * Remove Logo
         */
        if (isset($settings->removeLogo) && $settings->removeLogo) {
            $css_rules .= 'body.login h1 a { display: none!important; }';
        }

        /**
         * Center Box
         */
        if (isset($settings->centerBox) && $settings->centerBox) {
            $css_rules .= 'body.login { display: flex; justify-content: center; align-items: center; flex-direction: column; } #loginform {margin: 0!important} #login {padding: 0}';
        }

        /**
         * Remove Language Switcher
         */
        if (isset($settings->removeLanguageSwitcher) && $settings->removeLanguageSwitcher) {
            $css_rules .= 'body.login .language-switcher { display: none!important; }';
        }

        /**
         * Remove Back To Website
         */
        if (isset($settings->removeBackToWebsite) && $settings->removeBackToWebsite) {
            $css_rules .= 'body.login #backtoblog { display: none!important; }';
        }

        /**
         * Remove Password Reset
         */
        if (isset($settings->removePasswordReset) && $settings->removePasswordReset) {
            $css_rules .= 'body.login #nav { display: none!important; }';
        }

        /**
         * Remove Remember Me
         */
        if (isset($settings->removeRememberMe) && $settings->removeRememberMe) {
            $css_rules .= 'body.login .forgetmenot { display: none!important; }';
        }

        /**
         * Output
         */

        // Regular expression to match CSS variables
        $css_rules = $this->wrap_css_vars($css_rules);

        return $css_rules;
    }

    private function modifyColorOpacity($color, $opacity)
    {
        $opacity = $opacity / 100;

        if (strpos($color, 'rgba') !== false) {
            // RGBA Color
            $pattern = "/rgba\((\d+,\s*\d+,\s*\d+),\s*(\d(\.\d+)?)\)/";
            $replacement = "rgba($1, $opacity)";
            return preg_replace($pattern, $replacement, $color);
        } elseif (strpos($color, 'rgb') !== false) {
            // RGB Color, convert to RGBA
            $pattern = "/rgb\((\d+,\s*\d+,\s*\d+)\)/";
            $replacement = "rgba($1, $opacity)";
            return preg_replace($pattern, $replacement, $color);
        } elseif (strpos($color, 'hsla') !== false) {
            // HSLA Color
            $pattern = "/hsla\((\d+,\s*\d+%,\s*\d+%),\s*(\d(\.\d+)?)\)/";
            $replacement = "hsla($1, $opacity)";
            return preg_replace($pattern, $replacement, $color);
        } elseif (strpos($color, 'hsl') !== false) {
            // HSL Color, convert to HSLA
            $pattern = "/hsl\((\d+,\s*\d+%,\s*\d+%)\)/";
            $replacement = "hsla($1, $opacity)";
            return preg_replace($pattern, $replacement, $color);
        } else {
            // Assume HEX color, append the alpha as a two digit hex suffix
            $hex = ltrim($color, '#');

            if (strlen($hex) === 3 || strlen($hex) === 4) {
                // Expand the shorthand notation and drop a shorthand alpha
                $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
            } elseif (strlen($hex) === 8) {
                // Replace an existing alpha suffix
                $hex = substr($hex, 0, 6);
            }

            if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) {
                // Not a hex color (e.g. a CSS variable). Leave it untouched.
                return $color;
            }

            return '#' . $hex . str_pad(dechex((int) round(255 * $opacity)), 2, '0', STR_PAD_LEFT);
        }
    }

    /**
     * Add settings for the backend
     *
     * @param array $settings
     * @return void
     */
    public function backend_settings($settings, $status)
    {
        // Ensure settings and status are objects (recursively convert nested arrays)
        if (is_array($settings)) {
            $settings = json_decode(json_encode($settings));
        }
        if (is_array($status)) {
            $status = json_decode(json_encode($status));
        }

        // Add a <style> tag to the head with some styles in a wordpress hook
        add_action('admin_head', function () use ($settings, $status) {

            $styles = '';

            /**
             * Navigation Styles
             */
            if (isset($status->navigation) && $status->navigation == true) {
                $styles .= "
                    #adminmenu a:focus, #adminmenu a:hover, .folded #adminmenu .wp-submenu-head:hover { box-shadow: none !important; }
                    #adminmenu, #adminmenu .wp-submenu, #adminmenuback, #adminmenuwrap { background-color: {$settings->navigationBackground} !important; }
                    #adminmenu > li .wp-menu-name, div.wp-menu-image:before { color: {$settings->navigationText} !important; }
                    #adminmenu .wp-submenu { background-color: {$settings->navigationBackground2} !important; }
                    #adminmenu .wp-submenu li a, #adminmenu .wp-submenu li a:focus, #adminmenu .wp-submenu li a:hover { color: {$settings->navigationText2} !important; }
                    /* Hover/active backgrounds live on the anchor only. WP core paints the <li>
                       instantly but the <a> only after the hoverIntent delay (.opensub) — painting
                       both briefly shows the default color and stacks semi-transparent colors. */
                    #adminmenu li.menu-top:hover, #adminmenu li.opensub { background-color: transparent !important; }
                    #adminmenu li.menu-top:hover > a.menu-top, #adminmenu li.opensub > a.menu-top, #adminmenu li > a.menu-top:focus, #adminmenu a.wp-menu-open, #adminmenu .wp-submenu li:hover, #collapse-menu:hover { background-color: {$settings->navigationBackgroundHover} !important; color: {$settings->navigationTextHover} !important; }
                    #collapse-menu:hover button, #collapse-button:focus { color: {$settings->navigationTextHover} !important; }
                    #adminmenu a.wp-menu-open .wp-menu-name, #adminmenu a.wp-menu-open div.wp-menu-image:before { color: {$settings->navigationTextHover} !important; }
                    #adminmenu li.menu-top:hover .wp-menu-name, #adminmenu li.opensub>a.menu-top, #adminmenu li>a.menu-top:focus, #adminmenu li.menu-top:hover div.wp-menu-image:before, #adminmenu > li .wp-has-current-submenu .wp-menu-name, #adminmenu .wp-submenu li:hover a { color: {$settings->navigationTextHover} !important; border-color: {$settings->navigationTextHover} !important; }
                    .wp-submenu { border: 0!important; }
                ";

                if (isset($settings->adminBarBackground)) {
                    $styles .= "#wpadminbar { background: {$settings->adminBarBackground}; }";
                    $styles .= "#wpadminbar .menupop .ab-sub-wrapper, #wpadminbar .shortlink-input { background: {$settings->adminBarBackground}; }";
                    $styles .= "#wpadminbar .ab-top-menu>li.hover>.ab-item, #wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus, #wpadminbar:not(.mobile) .ab-top-menu>li:hover>.ab-item, #wpadminbar:not(.mobile) .ab-top-menu>li>.ab-item:focus { background: {$settings->adminBarBackground}; }";
                }

                if (isset($settings->adminBarTextColor)) {
                    $styles .= "#wpadminbar .ab-empty-item, #wpadminbar a.ab-item, #wpadminbar>#wp-toolbar span.ab-label, #wpadminbar>#wp-toolbar span.noticon { color: {$settings->adminBarTextColor}; }";
                    $styles .= "#wpadminbar a.ab-item::before, #wpadminbar a.ab-item span::before, #wpadminbar .quicklinks .menupop ul li a, #wpadminbar .quicklinks .menupop ul li a strong, #wpadminbar .quicklinks .menupop.hover ul li a, #wpadminbar.nojs .quicklinks .menupop:hover ul li a { color: {$settings->adminBarTextColor}!important; }";
                }

                if (isset($settings->adminBarHoverBackground)) {
                    $styles .= "#wpadminbar ul > li:hover, #wpadminbar .shortlink-input { background: {$settings->adminBarHoverBackground}; }";
                    $styles .= "#wpadminbar .ab-top-menu>li.hover>.ab-item, #wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus, #wpadminbar:not(.mobile) .ab-top-menu>li:hover>.ab-item, #wpadminbar:not(.mobile) .ab-top-menu>li>.ab-item:focus { background: {$settings->adminBarHoverBackground}; }";
                }

                // adminBarHoverText
                if (isset($settings->adminBarHoverText)) {
                    // Add hover text color
                    $styles .= "#wpadminbar ul > li:hover .ab-sub-wrapper li:hover *, #wpadminbar .ab-top-menu li:hover div, #wpadminbar .ab-top-menu li:hover a, #wpadminbar .ab-top-menu li:hover span.ab-label, #wpadminbar a.ab-item:hover::before, #wpadminbar a.ab-item:hover span::before { color: {$settings->adminBarHoverText}!important; }";
                }
            }

            // Stop here on Bricksforge's own admin apps (settings, form submissions).
            // They bring their own UI, which the generic page styles below would break.
            $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            if (strpos($_SERVER['REQUEST_URI'], 'page=bricksforge') !== false || $current_page === 'brf-form-submissions') {
                // Return Navigation Styles
                $this->inject_styles($styles);
                return;
            }

            // Stop if url contains: plugin-editor.php or theme-editor.php
            /* if (strpos($_SERVER['REQUEST_URI'], 'plugin-editor.php') !== false || strpos($_SERVER['REQUEST_URI'], 'theme-editor.php') !== false) {
                return;
            } */

            // Stop if url contains: widgets.php
            if (strpos($_SERVER['REQUEST_URI'], 'widgets.php') !== false) {
                return;
            }

            // Stop if is edit mode - only for block editor (Gutenberg)
            if (
                strpos($_SERVER['REQUEST_URI'], 'action=edit') !== false &&
                strpos($_SERVER['REQUEST_URI'], 'post.php') !== false &&
                function_exists('use_block_editor_for_post') &&
                isset($_GET['post']) &&
                use_block_editor_for_post($_GET['post'])
            ) {
                return;
            }

            /**
             * Page Styles
             */
            if (isset($status->pages) && $status->pages == true) {
                $styles .= "
                    .block-editor-inserter__block-list {
                        background: {$settings->pagesContentBackground} !important;
                    }
                    .block-editor-inserter__block-list * {
                        color: {$settings->pagesTextColor} !important;
                    }
                    .edit-post-header {
                        background: {$settings->pagesContentBackground} !important;
                        margin-bottom: -1px;
                    }
                    .community-events ul {
                        background: {$settings->pagesContentBackground};
                    }
                    .js #dashboard_quick_press .drafts {
                        border-color: {$settings->pagesContentBackgroundVariant};
                    }
                    #dashboard-widgets .postbox-container .empty-container {
                        outline-color: {$settings->pagesContentBackgroundVariant};
                    }
                    .edit-post-header * {
                        color: {$settings->pagesTextColor} !important;
                    }
                    #wpcontent a, button.button-link {
                        color: {$settings->pagesLinkColor};
                    }
                    #wpfooter a {
                        color: {$settings->pagesLinkColor};
                    }
                    #wpcontent table.plugins.wp-list-table .row-actions a {
                        color: {$settings->pagesLinkColor}!important;
                    }
                    #wpcontent table.plugins.wp-list-table .row-actions span.delete a {
                        color: #b32d2e!important;
                    }
                    .components-notice {
                        background: {$settings->pagesContentBackground} !important;
                        color: {$settings->pagesTextColor} !important;
                    }
                    .edit-post-fullscreen-mode-close.components-button {
                        height: 59px;
                    }
                    .components-popover__content {
                        background: {$settings->pagesContentBackground} !important;
                    }
                    .components-popover__content * {
                        color: {$settings->pagesTextColor} !important;
                    }
                    body {
                        background-color: {$settings->pagesBodyBackground} !important;
                        color: {$settings->pagesTextColor} !important;
                    }
                    .wp-core-ui .attachment .filename, tr, th, li {
                        color: {$settings->pagesTextColor} !important;
                    }
                    h1,h2,h3,h4,h5,h6, p, td, th, span, label, legend, .media-menu-item {
                        color: {$settings->pagesTextColor} !important;
                    }
                    #wpcontent a:not(.page-title-action), #wpcontent button.button-link {
                        color: {$settings->pagesLinkColor};
                    }
                    table {
                        border-color: {$settings->pagesContentBackground} !important;
                    }
                    .interface-interface-skeleton__sidebar {
                        background: transparent!important;
                    }
                    input[type=checkbox]:checked::before {
                        filter: grayscale(1)
                    }
                    #screen-meta, .revisions-diff, .revisions-meta, .attachments-browser .media-toolbar, .wp-core-ui
                    .attachment-preview, .wp-core-ui .attachment .filename, .welcome-panel .welcome-panel-column-container, .postbox,
                    #dashboard-widgets .postbox-container .empty-container, th, .nav-tab, .health-check-header, #contextual-help-back,
                    .contextual-help-tabs .active, .theme-about, .theme-actions, .nav-menus-php #post-body,
                    #nav-menu-footer, .bulk-select-button, #nav-menu-header, .accordion-section-title, .accordion-section-content,
                    .tabs-panel, ul.add-menu-item-tabs li.tabs, .notification-dialog, .CodeMirror, .bricks-admin-wrapper.getting-started
                    .bricks-admin-inner, .bricks-admin-wrapper.getting-started .box-wrapper:after, .bricks-admin-wrapper.getting-started
                    .badge, .manage-menus, .edit-post-header, .components-panel__body, .block-editor-block-inspector__no-blocks,
                    .components-panel__header, .media-modal-content, .attachments-wrapper, .media-sidebar, .media-frame-content,
                    .components-popover__content, .plugin-card, #plugin-information-content, #plugin-information .fyi,
                    #TB_window.plugin-details-modal, .health-check-accordion-trigger:focus, .privacy-settings-accordion-trigger:focus {
                        background-color: {$settings->pagesContentBackground} !important;
                        border-color: {$settings->pagesContentBackground} !important;
                    }
                    .components-button.editor-post-last-revision__title:active, .components-button.editor-post-last-revision__title:hover,
                    .plugin-card-bottom, .popular-tags, #plugin-information-footer, #plugin-information-tabs, .color-option.selected,
                    .color-option:hover, .card, .importer-item, .health-check-accordion-trigger, .privacy-settings-accordion-trigger,
                    .health-check-accordion-heading, .health-check-accordion, .health-check-accordion-panel,
                    .privacy-settings-accordion-panel, .health-check-header, .privacy-settings-header, #wpadminbar {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .health-check-accordion-trigger:focus, .privacy-settings-accordion-trigger:focus {
                        outline: none;
                    }
                    .filter-links li>a {
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .filter-links li>a.current {
                        border-color: {$settings->pagesLinkColor} !important;
                    }
                    #plugin-information .fyi strong {
                        color: {$settings->pagesTextColor} !important;
                    }
                    .menu-item-handle, .menu-item-settings {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    #plugin-information-tabs a.current {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                        color: {$settings->pagesTextColor} !important;
                    }
                    td, th, tr, ul, section, .postbox-header, .empty-container, .activity-block, p, li, .accordion-container, .menu-edit,
                    .menu-settings, #nav-menu-footer, .menu-item-settings, .bricks-admin-wrapper.getting-started .box-wrapper {
                        border-color: {$settings->pagesDividersColor} !important;
                        box-shadow: none!important;
                    }
                    #bricks-settings .separator {
                        background-color: {$settings->pagesDividersColor} !important;
                    }
                    #activity-widget #the-comment-list .comment-item {
                        background-color: {$settings->pagesContentBackground} !important;
                    }
                    .nav-tab-active {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    p.info {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .bricks-admin-wrapper.sidebars .bricks-admin-inner {
                        background-color: {$settings->pagesContentBackground} !important;
                        border-color: {$settings->pagesContentBackground} !important;
                    }
                    .bricks-admin-wrapper.sidebars .new-sidebar-wrapper form {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .notice, div.error, div.updated {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .bricks-admin-wrapper.license form, .wp-filter {
                        background-color: {$settings->pagesContentBackground} !important;
                        border-color: {$settings->pagesContentBackground} !important;
                    }
                    .bricks-admin-inner {
                        border-color: {$settings->pagesContentBackground} !important;
                    }
                    .wp-core-ui .button.disabled, .edit-attachment-frame .attachment-info {
                        background-color: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                        color: {$settings->pagesTextColor} !important;
                    }
                    .edit-attachment-frame .attachment-info .details, .edit-attachment-frame .attachment-info .settings,
                    .edit-attachment-frame .attachment-info .filename {
                        color: {$settings->pagesTextColor} !important;
                    }
                    .view-switch a.current:before {
                        color: {$settings->pagesLinkColor} !important;
                    }
                    .edit-media-header button {
                        border: 0!important;
                    }
                    .edit-media-header button:hover {
                        background: {$settings->pagesContentBackgroundVariant} !important;
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                        color: {$settings->pagesTextColor} !important;
                    }
                    .media-upload-form .media-item {
                        background: {$settings->pagesContentBackground} !important;
                    }
                    .nav-tab-wrapper, .wrap h2.nav-tab-wrapper, h1.nav-tab-wrapper {
                        border-color: {$settings->pagesContentBackgroundVariant} !important;
                    }
                    .wp-person a:focus .gravatar, a:focus, a:focus .media-icon img, a:focus .plugin-icon {
                        box-shadow: none!important;
                        outline: none!important;
                    }
                ";
            }

            /**
             * Button Styles
             */
            if (isset($status->buttons) && $status->buttons == true) {
                $styles .= "
                    .wp-core-ui .button, button.is-tertiary, button.components-button, .media-router .active, .media-router .media-menu-item.active:last-child {
                        background-color: {$settings->defaultButtonBackground} !important;
                        color: {$settings->defaultButtonText} !important;
                        border-color: {$settings->defaultButtonBackground} !important;
                    }

                    .wp-core-ui .button.button-primary, .wrap .page-title-action, button.is-primary {
                        background-color: {$settings->primaryButtonBackground} !important;
                        color: {$settings->primaryButtonText} !important;
                        border-color: {$settings->primaryButtonBackground} !important;
                    }
                    .bricks-admin-wrapper.sidebars .registered-sidebars-wrapper button[type=submit] {
                        color: {$settings->primaryButtonBackground} !important;
                    }
                ";

                $styles .= "
                    .wp-core-ui .button, button.is-tertiary, .media-router .active, .media-router .media-menu-item.active:last-child {
                        background-color: {$settings->defaultButtonBackground} !important;
                        color: {$settings->defaultButtonText} !important;
                        border-color: {$settings->defaultButtonBackground} !important;
                    }
                    .button.button-primary, .wrap .page-title-action, button.is-primary {
                        background-color: {$settings->primaryButtonBackground} !important;
                        color: {$settings->primaryButtonText} !important;
                        border-color: {$settings->primaryButtonBackground} !important;
                    }
                    .components-button:focus:not(:disabled), .components-button:hover:not(:disabled) {
                        box-shadow: 0 0 0 1px {$settings->primaryButtonBackground} !important;
                    }
                ";
            }

            /**
             * Forms Styles
             */
            if (isset($status->forms) && $status->forms == true) {
                $styles .= "
                    input, textarea, select {
                        background-color: {$settings->formsBackground} !important;
                        color: {$settings->formsText} !important;
                        box-shadow: 0 0 0 1px {$settings->formsBorder} !important;
                        border-color: {$settings->formsBorder} !important;
                    }

                    table.form-table th {
                        padding-left: 25px;
                    }

                    input[type=radio]:checked::before {
                        background-color: {$settings->formsAccent} !important;
                    }

                    .plugin-details-modal #TB_closeWindowButton {
                        color: {$settings->formsAccent} !important;
                    }
                    .wp-core-ui .attachment.details .check, .wp-core-ui .attachment.selected .check:focus, .wp-core-ui .media-frame.mode-grid .attachment.selected .check {
                        background-color: {$settings->formsAccent} !important;
                        border-color: {$settings->formsAccent} !important;
                        outline: none!important;
                        box-shadow: none!important;
                    }
                    #bricks-settings input[type=checkbox]:checked {
                        background-color: {$settings->formsAccent} !important;
                    }
                ";
            }


            /**
             * Tables Styles
             */
            if (isset($status->tables) && $status->tables == true) {
                $styles .= "
                    .wp-list-table tr, .wp-list-table th, .wp-list-table td {
                        background-color: {$settings->tablesEvenColor} !important;
                    }

                    table.striped tr {
                        background-color: {$settings->tablesEvenColor} !important;
                    }

                    .striped>tbody>:nth-child(odd), .striped>tbody>:nth-child(odd) th, .striped>tbody>:nth-child(odd) td, ul.striped>:nth-child(odd), ul.striped>:nth-child(odd) th, ul.striped>:nth-child(odd) td {
                        background-color: {$settings->tablesOddColor} !important;
                    }

                    .wp-list-table tr, .wp-list-table th, .wp-list-table td {
                        background-color: {$settings->tablesEvenColor} !important;
                    }

                    .wp-list-table tr.active, .wp-list-table tr.active th, .wp-list-table tr.active td {
                        background-color: {$settings->tablesOddColor} !important;
                    }

                    #bricks-settings td {
                        background-color: {$settings->tablesEvenColor} !important;
                    }
                    #wpcontent table.plugins tr, #wpcontent table.plugins tr > th {
                        border-left-color: {$settings->pagesLinkColor}!important;
                    }
                ";
            }

            /** Inject Styles */
            $this->inject_styles($styles);
        }, 10);

        /**
         * Change Footer Text
         */
        if (isset($settings->footerText) && $settings->footerText != '' && $status->footer == true) {
            add_filter('admin_footer_text', function () use ($settings) {
                return $settings->footerText;
            });
        }

        /** 
         * Change WordPress Version Text
         */
        if (isset($settings->versionText) && $settings->versionText != '' && $status->footer == true) {
            add_filter('update_footer', function () use ($settings) {
                return $settings->versionText;
            }, 11);
        }

        /**
         * Change WP Admin Bar Logo
         */
        if (isset($settings->adminBarLogo) && $settings->adminBarLogo != '' && $status->adminBar == true) {
            add_action('admin_bar_menu', function ($wp_admin_bar) use ($settings) {
                $wp_admin_bar->remove_node('wp-logo');

                $logo_height = isset($settings->adminBarLogoHeight) && $settings->adminBarLogoHeight != '' ? $settings->adminBarLogoHeight : '30px';

                $wp_admin_bar->add_node([
                    'id' => 'brf-custom-logo',
                    'title' => '<img src="' . $settings->adminBarLogo . '" alt="Logo" style="max-height: 100%; height: ' . $logo_height . '" />',
                    'href' => home_url(),
                ]);
            }, 11);
        }

        /**
         * Replace Howdy in Admin Bar
         */
        if (isset($settings->adminBarNewHowdy) && $settings->adminBarNewHowdy != '' && $status->adminBar == true) {
            // Core builds the greeting from the translated 'Howdy, %s', so matching the
            // rendered title only ever worked in en_US. Replace the translation instead.
            $greeting = function ($translation, $text, $domain) use ($settings) {
                if ($domain === 'default' && $text === 'Howdy, %s') {
                    // sprintf() runs on the result, so escape percent signs the user typed
                    return str_replace('%', '%%', esc_html($settings->adminBarNewHowdy)) . ' %s';
                }

                return $translation;
            };

            // wp_admin_bar_my_account_item() runs on admin_bar_menu at priority 9991,
            // so the filter is only active while that node is built.
            add_action('admin_bar_menu', function () use ($greeting) {
                add_filter('gettext', $greeting, 10, 3);
            }, 9990);

            add_action('admin_bar_menu', function () use ($greeting) {
                remove_filter('gettext', $greeting, 10);
            }, 9992);
        }

        /**
         * Remove all Admin Bar links except logo and user
         */
        if (isset($settings->clearAdminBar) && $settings->clearAdminBar == '1' && $status->adminBar == true) {
            add_action('admin_bar_menu', function ($wp_admin_bar) {
                $wp_admin_bar->remove_node('site-name');
                $wp_admin_bar->remove_node('comments');
                $wp_admin_bar->remove_node('new-content');
                $wp_admin_bar->remove_node('customize');
                $wp_admin_bar->remove_node('updates');
                $wp_admin_bar->remove_node('search');
                $wp_admin_bar->remove_node('wp-logo-external');
                $wp_admin_bar->remove_node('edit');
                $wp_admin_bar->remove_node('view');
                $wp_admin_bar->remove_node('preview');
                $wp_admin_bar->remove_node('trash');
                $wp_admin_bar->remove_node('archive');
                $wp_admin_bar->remove_node('untrash');
                $wp_admin_bar->remove_node('delete');
                $wp_admin_bar->remove_node('spam');
                $wp_admin_bar->remove_node('unspam');
                $wp_admin_bar->remove_node('duplicate');
                $wp_admin_bar->remove_node('edit-as-new-draft');
                $wp_admin_bar->remove_node('revisions');
                $wp_admin_bar->remove_node('view-revisions');
                $wp_admin_bar->remove_node('next-post');
                $wp_admin_bar->remove_node('previous-post');
                $wp_admin_bar->remove_node('next-page');
                $wp_admin_bar->remove_node('previous-page');
                $wp_admin_bar->remove_node('next-media');
                $wp_admin_bar->remove_node('previous-media');
                $wp_admin_bar->remove_node('next-image');
                $wp_admin_bar->remove_node('previous-image');
                $wp_admin_bar->remove_node('next-user');
                $wp_admin_bar->remove_node('previous-user');
                $wp_admin_bar->remove_node('next-comment');
                $wp_admin_bar->remove_node('previous-comment');
            }, 999);
        }
    }

    /**
     * Store a snapshot of the unmodified admin menu (plus the available roles)
     * so the Menu Editor UI can list all items. Only captured for admins,
     * before any menu rules are applied.
     */
    private function clean_menu_title($raw, $fallback)
    {
        // Strip update badges & screen reader text from the title
        $title = preg_replace('/<span\b.*$/s', '', (string) $raw);
        $title = trim(wp_strip_all_tags($title));

        return $title === '' ? $fallback : $title;
    }

    public function capture_menu_snapshot()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $menu, $submenu;

        if (!is_array($menu) || empty($menu)) {
            return;
        }

        // WordPress renders the menu sorted by its numeric position keys
        // (menu.php ksorts $menu after admin_menu). We capture during
        // admin_menu — before that sort — so ksort a copy here to store the
        // real render order instead of the raw insertion order.
        $sorted_menu = $menu;
        ksort($sorted_menu);

        // The Link Manager is registered during admin_menu but removed before
        // rendering when it's disabled — don't list it as a real menu item.
        $link_manager_enabled = (bool) get_option('link_manager_enabled');

        $items = [];

        foreach ($sorted_menu as $item) {
            $slug = isset($item[2]) ? $item[2] : '';

            // Separators are not manageable entries
            if ($slug === '' || strpos($slug, 'separator') === 0) {
                continue;
            }

            if (
                !$link_manager_enabled &&
                ($slug === 'link-manager.php' || strpos($slug, 'taxonomy=link_category') !== false)
            ) {
                continue;
            }

            $children = [];

            if (is_array($submenu) && isset($submenu[$slug]) && is_array($submenu[$slug])) {
                foreach ($submenu[$slug] as $sub_item) {
                    $sub_slug = isset($sub_item[2]) ? $sub_item[2] : '';

                    if ($sub_slug === '') {
                        continue;
                    }

                    $children[] = [
                        'slug'  => $sub_slug,
                        'title' => $this->clean_menu_title(isset($sub_item[0]) ? $sub_item[0] : '', $sub_slug),
                    ];
                }
            }

            $items[] = [
                'slug'     => $slug,
                'title'    => $this->clean_menu_title(isset($item[0]) ? $item[0] : '', $slug),
                'icon'     => isset($item[6]) ? $item[6] : '',
                'children' => $children,
            ];
        }

        $roles = [];

        foreach (wp_roles()->get_names() as $role_key => $role_name) {
            $roles[] = [
                'key'  => $role_key,
                'name' => translate_user_role($role_name),
            ];
        }

        $snapshot = [
            'menu'  => $items,
            'roles' => $roles,
        ];

        if (get_option('brf_bd_menu_snapshot') != $snapshot) {
            update_option('brf_bd_menu_snapshot', $snapshot, false);
        }
    }

    /**
     * Menu Editor: hide, rename and reorder admin menu items per role.
     * Runs after the snapshot capture so the UI always sees the raw menu.
     */
    public function menu_editor_settings($menu_editor)
    {
        add_action('admin_menu', function () use ($menu_editor) {
            $this->apply_menu_rules($menu_editor);
        }, PHP_INT_MAX);
    }

    private function apply_menu_rules($menu_editor)
    {
        $rules = $this->get_value($menu_editor, 'rules');

        if (!$rules) {
            return;
        }

        $user = wp_get_current_user();

        if (!$user || !$user->exists()) {
            return;
        }

        // The first of the user's roles with its own rule wins, otherwise "default"
        $rule = null;

        foreach ((array) $user->roles as $role) {
            $role_rule = $this->get_value($rules, $role);

            if ($role_rule) {
                $rule = $role_rule;
                break;
            }
        }

        if (!$rule) {
            $rule = $this->get_value($rules, 'default');
        }

        if (!$rule) {
            return;
        }

        global $menu, $submenu;

        $items = $this->get_value($rule, 'items');

        if ($items) {
            foreach ((array) $items as $slug => $conf) {
                $hidden = $this->get_value($conf, 'hidden', false);
                $label = $this->get_value($conf, 'label', '');

                // Hiding only removes the link — page access stays untouched,
                // so an admin can never lock themselves out.
                if ($hidden == true) {
                    remove_menu_page($slug);
                    continue;
                }

                if ($label !== '' && $label !== null && is_array($menu)) {
                    foreach ($menu as $index => $item) {
                        if (isset($item[2]) && $item[2] === $slug) {
                            $menu[$index][0] = esc_html($label);
                        }
                    }
                }
            }
        }

        // Submenus: hide & rename ({ parentSlug: { childSlug: {label, hidden} } })
        $sub_items = $this->get_value($rule, 'subItems');

        if ($sub_items) {
            foreach ((array) $sub_items as $parent_slug => $children) {
                foreach ((array) $children as $child_slug => $conf) {
                    $hidden = $this->get_value($conf, 'hidden', false);
                    $label = $this->get_value($conf, 'label', '');

                    if ($hidden == true) {
                        remove_submenu_page($parent_slug, $child_slug);
                        continue;
                    }

                    if (
                        $label !== '' && $label !== null &&
                        is_array($submenu) && isset($submenu[$parent_slug]) && is_array($submenu[$parent_slug])
                    ) {
                        foreach ($submenu[$parent_slug] as $index => $sub_item) {
                            if (isset($sub_item[2]) && $sub_item[2] === $child_slug) {
                                $submenu[$parent_slug][$index][0] = esc_html($label);
                            }
                        }
                    }
                }
            }
        }

        // Submenus: order ({ parentSlug: [childSlug, ...] })
        $sub_order = $this->get_value($rule, 'subOrder');

        if ($sub_order) {
            foreach ((array) $sub_order as $parent_slug => $order_list) {
                if (
                    !is_array($order_list) || empty($order_list) ||
                    !is_array($submenu) || !isset($submenu[$parent_slug]) || !is_array($submenu[$parent_slug])
                ) {
                    continue;
                }

                $remaining = array_values($submenu[$parent_slug]);
                $ordered = [];

                foreach ($order_list as $child_slug) {
                    foreach ($remaining as $key => $entry) {
                        if (isset($entry[2]) && $entry[2] === $child_slug) {
                            $ordered[] = $entry;
                            unset($remaining[$key]);
                            break;
                        }
                    }
                }

                // Unknown entries (new plugins) keep their relative order at the end
                foreach ($remaining as $entry) {
                    $ordered[] = $entry;
                }

                $submenu[$parent_slug] = $ordered;
            }
        }

        // Folders: group top-level items into a container (before the order
        // filter, so folder IDs can be positioned by it).
        $this->apply_folders($rule);

        $order = $this->get_value($rule, 'order');

        if ($order && is_array($order) && count($order) > 0) {
            add_filter('custom_menu_order', '__return_true');
            add_filter('menu_order', function ($menu_order) use ($order) {
                if (!is_array($menu_order)) {
                    return $menu_order;
                }

                // Saved order first; unknown items (new plugins, separators)
                // keep their relative order and are appended at the end
                $custom = array_values(array_intersect($order, $menu_order));
                $rest = array_values(array_diff($menu_order, $custom));

                return array_merge($custom, $rest);
            });
        }
    }

    /**
     * Folders: group top-level items into a container menu whose flyout holds
     * the grouped plugins' subpages, each group prefixed with a section header
     * that links to the plugin's landing page.
     *
     * WordPress renders exactly two menu levels, so we don't build a third
     * level. Instead we create a folder top-level item and relocate the
     * grouped items' existing $submenu entries into it. Because
     * get_admin_page_parent() scans $submenu live, active-state highlighting
     * keeps working natively — no JavaScript involved.
     *
     * @param mixed $rule The resolved rule for the current user's role.
     */
    private function apply_folders($rule)
    {
        $folders = $this->get_value($rule, 'folders');

        if (!$folders || !is_array($folders)) {
            return;
        }

        global $menu, $submenu, $_parent_pages, $admin_page_hooks;

        if (!is_array($menu)) {
            return;
        }

        // Top-level slugs hidden by the items rule are never folded.
        $hidden = [];
        $items = $this->get_value($rule, 'items');

        if ($items) {
            foreach ((array) $items as $slug => $conf) {
                if ($this->get_value($conf, 'hidden', false) == true) {
                    $hidden[$slug] = true;
                }
            }
        }

        foreach ((array) $folders as $folder) {
            $folder_id  = $this->get_value($folder, 'id');
            $label      = $this->get_value($folder, 'label', 'Folder');
            $icon       = $this->get_value($folder, 'icon', 'dashicons-portfolio');
            $item_slugs = $this->get_value($folder, 'items');

            if (!$folder_id || !is_string($folder_id) || !$item_slugs || !is_array($item_slugs)) {
                continue;
            }

            // Defensive: the ID is generated client-side, but must be a safe,
            // recognizable folder slug that can't collide with real menu pages.
            $folder_id = preg_replace('/[^a-z0-9\-_]/', '', (string) $folder_id);

            if ($folder_id === '' || strpos($folder_id, 'brf-folder-') !== 0) {
                continue;
            }

            // Collect everything to move BEFORE touching the menu, so removing a
            // top-level item can't wipe children we still need.
            $groups = [];

            foreach ($item_slugs as $slug) {
                if (isset($hidden[$slug])) {
                    continue;
                }

                $title = null;
                $cap   = 'read';

                foreach ($menu as $mi) {
                    if (isset($mi[2]) && $mi[2] === $slug) {
                        $title = isset($mi[0]) ? $this->clean_menu_title($mi[0], $slug) : $slug;
                        $cap   = isset($mi[1]) ? $mi[1] : 'read';
                        break;
                    }
                }

                if ($title === null) {
                    // Not present (hidden elsewhere / doesn't exist for this role)
                    continue;
                }

                $children = (is_array($submenu) && isset($submenu[$slug]) && is_array($submenu[$slug]))
                    ? $submenu[$slug]
                    : [];

                $groups[] = [
                    'slug'     => $slug,
                    'title'    => $title,
                    'cap'      => $cap,
                    'children' => $children,
                ];
            }

            if (empty($groups)) {
                continue;
            }

            // Create the folder top-level item. 'read' so it always registers;
            // the grouped children carry their own capabilities.
            add_menu_page(
                $label,
                $label,
                'read',
                $folder_id,
                function () use ($label) {
                    echo '<div class="wrap"><h1>' . esc_html($label) . '</h1></div>';
                },
                $icon
            );

            if (!isset($submenu[$folder_id]) || !is_array($submenu[$folder_id])) {
                $submenu[$folder_id] = [];
            }

            foreach ($groups as $group) {
                $slug     = $group['slug'];
                $children = $group['children'];

                if (!empty($children)) {
                    // Section header — a styled row that links to the plugin's
                    // landing page (its own top-level slug).
                    $submenu[$folder_id][] = [
                        $group['title'],
                        $group['cap'],
                        $slug,
                        '',
                        'brf-folder-section',
                    ];

                    if (is_array($_parent_pages)) {
                        $_parent_pages[$slug] = $folder_id;
                    }

                    // The landing was a top-level page (hook type "toplevel").
                    $this->remap_admin_page_hook($slug, 'toplevel', $folder_id);

                    // Parent's page-type, used to rebuild each child's page hook.
                    $parent_type = isset($admin_page_hooks[$slug]) ? $admin_page_hooks[$slug] : $slug;

                    foreach ($children as $child) {
                        $child_slug = isset($child[2]) ? $child[2] : '';

                        // Skip the auto-added landing duplicate (child == parent)
                        if ($child_slug === '' || $child_slug === $slug) {
                            continue;
                        }

                        $submenu[$folder_id][] = $child;

                        if (is_array($_parent_pages)) {
                            $_parent_pages[$child_slug] = $folder_id;
                        }

                        $this->remap_admin_page_hook($child_slug, $parent_type, $folder_id);
                    }
                } else {
                    // Standalone item — a single entry, no header.
                    $submenu[$folder_id][] = [
                        $group['title'],
                        $group['cap'],
                        $slug,
                    ];

                    if (is_array($_parent_pages)) {
                        $_parent_pages[$slug] = $folder_id;
                    }

                    $this->remap_admin_page_hook($slug, 'toplevel', $folder_id);
                }

                // Drop the original top-level. remove_menu_page() only clears
                // $menu, so we also unset the (now-relocated) $submenu entry —
                // otherwise the children live in two parents and
                // get_admin_page_parent() resolves them inconsistently.
                remove_menu_page($slug);

                if (isset($submenu[$slug])) {
                    unset($submenu[$slug]);
                }
            }

            $this->folder_styles_needed = true;
        }

        if ($this->folder_styles_needed) {
            add_action('admin_head', [$this, 'print_folder_styles']);
        }
    }

    /**
     * Re-map a callback page's registration to a new parent (the folder).
     *
     * WordPress builds a page's render hook from its parent's page-type
     * ("{type}_page_{slug}"). Moving a "?page=" page into a folder changes the
     * computed parent, so the callback registered under the old hook is never
     * fired and the page 404s. We copy the registered callbacks to the new
     * hook and mark it as a registered page. File-based pages (edit.php, …)
     * don't use a page hook and are skipped.
     *
     * @param string $slug     The page slug being moved.
     * @param string $old_type The page-type of its original parent
     *                         ("toplevel" for top-level items, otherwise the
     *                         parent's $admin_page_hooks value).
     * @param string $folder_id The folder slug the page now lives under.
     */
    private function remap_admin_page_hook($slug, $old_type, $folder_id)
    {
        if (strpos($slug, '.php') !== false) {
            return;
        }

        global $admin_page_hooks, $wp_filter, $_registered_pages;

        $name = preg_replace('!\.php!', '', $slug);
        $new_type = isset($admin_page_hooks[$folder_id]) ? $admin_page_hooks[$folder_id] : $folder_id;

        $old_hook = $old_type . '_page_' . $name;
        $new_hook = $new_type . '_page_' . $name;

        if ($old_hook === $new_hook) {
            return;
        }

        // Only remap when there is an actual registered callback to move.
        if (isset($wp_filter[$old_hook])) {
            $wp_filter[$new_hook] = $wp_filter[$old_hook];

            if (is_array($_registered_pages)) {
                $_registered_pages[$new_hook] = true;
            }
        }
    }

    /**
     * Minimal styling for folder section headers in the admin menu flyout.
     */
    public function print_folder_styles()
    {
        echo '<style id="brf-menu-folder-styles">'
            . '#adminmenu .wp-submenu li.brf-folder-section{margin-top:5px;padding-top:5px;border-top:1px solid rgba(255,255,255,.10);}'
            . '#adminmenu .wp-submenu li.brf-folder-section:first-child{margin-top:0;padding-top:0;border-top:0;}'
            . '#adminmenu .wp-submenu li.brf-folder-section a{text-transform:uppercase;font-size:10px;letter-spacing:.6px;font-weight:700;opacity:.6;}'
            . '#adminmenu .wp-submenu li.brf-folder-section a:hover{opacity:.9;}'
            . '</style>';
    }

    public function inject_styles($styles)
    {
        if ($styles != '') {
            $styles = preg_replace('/\s+/', ' ', $styles);
            $styles = trim($styles);

            $styles = $this->wrap_css_vars($styles);

            echo "
                <style type='text/css' id='brf-admin-styles'>{$styles}</style>
            ";
        }
    }

    public function dashboard_settings($settings)
    {
        // Ensure settings is an object (recursively convert nested arrays)
        if (is_array($settings)) {
            $settings = json_decode(json_encode($settings));
        }

        if (isset($settings->useTemplate) && $settings->useTemplate) {
            add_action('admin_head', function () use ($settings) {
                if (get_current_screen()->id != 'dashboard') {
                    return;
                }

                wp_enqueue_script('bricksforge-custom-dashboard-script', BRICKSFORGE_ASSETS . '/js/backend-designer/dashboard.js', [], false, true);
                wp_localize_script('bricksforge-custom-dashboard-script', 'dashboardSettings', ['linkHandling' => $settings->linkHandling ?? '']);

                wp_enqueue_style('bricksforge-custom-dashboard-style', BRICKSFORGE_ASSETS . '/css/backend-designer/dashboard.css');
            });

            if (is_user_logged_in() && isset($_GET['backend']) && $_GET['backend'] == 'true') {
                add_filter('body_class', function ($classes) {
                    $classes[] = 'brf-backend-view';
                    return $classes;
                });

                add_filter('show_admin_bar', function ($show) {
                    return false;
                });
            }

            add_action('wp_dashboard_setup', function () use ($settings) {
                $this->remove_default_dashboard_widgets();

                $url = add_query_arg('backend', 'true', get_permalink($settings->template));

                wp_add_dashboard_widget(
                    'brf_custom_dashboard',
                    'Welcome',
                    function () use ($url) {
                        echo '<iframe src="' . $url . '" width="100%" height="100%"></iframe>';
                    }
                );
            }, 999);
        }
    }

    public function wrap_css_vars($css_rules)
    {
        $cssVarRegex = '/(--[a-zA-Z0-9-_]+)/';

        return preg_replace_callback($cssVarRegex, function ($matches) {
            return 'var(' . $matches[0] . ')';
        }, $css_rules);
    }

    private function remove_default_dashboard_widgets()
    {
        global $wp_meta_boxes;

        $widget_ids = [
            'dashboard_activity',
            'dashboard_right_now',
            'dashboard_recent_comments',
            'dashboard_incoming_links',
            'dashboard_plugins',
            'dashboard_primary',
            'dashboard_secondary',
            'dashboard_quick_press',
            'dashboard_recent_drafts',
            'dashboard_site_health',
            'welcome-panel-column-container',
        ];

        foreach ($widget_ids as $widget_id) {
            foreach (['normal', 'side'] as $context) {
                foreach (['core'] as $priority) {
                    unset($wp_meta_boxes['dashboard'][$context][$priority][$widget_id]);
                }
            }
        }

        remove_action('welcome_panel', 'wp_welcome_panel');
    }
}
