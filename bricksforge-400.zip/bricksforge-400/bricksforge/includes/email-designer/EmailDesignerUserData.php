<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Read-only view of a user for the Twig context of a mail template.
 *
 * The Email Designer used to hand the live WP_User object to Twig, which let
 * template code call its methods - and mail bodies contain submitted form
 * values, so that was reachable from a form field. This carries the same data
 * without the behaviour.
 *
 * It is an ArrayAccess object rather than a plain array so that {{ user.foo }}
 * can still fall back to the user's meta the way WP_User::__get() did.
 * Everything Twig can reach on it is a value; there is nothing to call.
 */
class EmailDesignerUserData implements \ArrayAccess
{
    /**
     * @var array
     */
    private $data;

    /**
     * User ID to read meta from, or 0 to switch the fallback off.
     *
     * @var int
     */
    private $meta_user_id;

    /**
     * Meta keys that never belong in an email, no matter who asks.
     *
     * @var string[]
     */
    private $blocked_meta_keys = [
        'user_pass',
        'user_activation_key',
        'session_tokens',
        'user_level',
    ];

    /**
     * @param array $data
     * @param int $meta_user_id
     */
    public function __construct(array $data, $meta_user_id = 0)
    {
        $this->data = $data;
        $this->meta_user_id = (int) $meta_user_id;
    }

    /**
     * @param mixed $offset
     * @return bool
     */
    #[\ReturnTypeWillChange]
    public function offsetExists($offset)
    {
        if (array_key_exists($offset, $this->data)) {
            return true;
        }

        return $this->get_meta($offset) !== null;
    }

    /**
     * @param mixed $offset
     * @return mixed
     */
    #[\ReturnTypeWillChange]
    public function offsetGet($offset)
    {
        if (array_key_exists($offset, $this->data)) {
            return $this->data[$offset];
        }

        $meta = $this->get_meta($offset);

        return $meta === null ? '' : $meta;
    }

    /**
     * Read-only: a template must not change the user.
     *
     * @param mixed $offset
     * @param mixed $value
     * @return void
     */
    #[\ReturnTypeWillChange]
    public function offsetSet($offset, $value)
    {
    }

    /**
     * Read-only: a template must not change the user.
     *
     * @param mixed $offset
     * @return void
     */
    #[\ReturnTypeWillChange]
    public function offsetUnset($offset)
    {
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return isset($this->data['display_name']) ? (string) $this->data['display_name'] : '';
    }

    /**
     * @param mixed $key
     * @return mixed|null Null when there is nothing to return.
     */
    private function get_meta($key)
    {
        if (!$this->meta_user_id || !is_string($key) || $key === '') {
            return null;
        }

        if (in_array($key, $this->blocked_meta_keys, true)) {
            return null;
        }

        // Capabilities are stored under a table-prefixed key.
        if (strpos($key, 'capabilities') !== false) {
            return null;
        }

        $value = get_user_meta($this->meta_user_id, $key, true);

        if ($value === '' || $value === false) {
            return null;
        }

        return $value;
    }
}
