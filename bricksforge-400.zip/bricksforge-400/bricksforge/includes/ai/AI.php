<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Handler
 */
class AI
{

    public function __construct()
    {
        $this->init();
    }

    public function init()
    {
        if ($this->activated() === false) {
            return;
        }
    }

    public function activated()
    {
        return get_option('brf_activated_tools') && in_array(14, get_option('brf_activated_tools'));
    }

    public function run($prompt, $type = 'animation', $context = null, $page_colors = null, $custom_fields = null, $post_types = null, $use_css_variables = false, $taxonomies = null, $language = null)
    {
        if ($this->activated() === false) {
            return;
        }

        try {
            return $this->run_task($prompt, $type, $context, $page_colors, $custom_fields, $post_types, $use_css_variables, $taxonomies, $language);
        } catch (\Exception $e) {
            error_log($e->getMessage());
        }
    }

    private function get_ai_settings()
    {
        $ai_settings = array_values(array_filter(get_option('brf_tool_settings'), function ($tool) {
            return $tool->id == 14;
        }));

        if (count($ai_settings) === 0) {
            wp_send_json_error(['message' => 'No API key provided.', 'code' => 'no_api_key', 'status' => 400]);
        }

        $ai_settings = $ai_settings[0];

        if (is_array($ai_settings)) {
            $ai_settings = json_decode(json_encode($ai_settings));
        }

        return $ai_settings;
    }

    private function get_provider()
    {
        $settings = $this->get_ai_settings();
        return isset($settings->settings->aiProvider) ? $settings->settings->aiProvider : 'openai';
    }

    private function get_api_key()
    {
        $settings = $this->get_ai_settings();
        $provider = $this->get_provider();
        $utils = new \Bricksforge\Api\Utils();

        if ($provider === 'anthropic') {
            $key = isset($settings->settings->anthropicApiKey) ? $utils->decrypt($settings->settings->anthropicApiKey) : null;
        } else {
            $key = isset($settings->settings->apiKey) ? $utils->decrypt($settings->settings->apiKey) : null;
        }

        if (!$key) {
            wp_send_json_error(['message' => 'No API key provided for ' . $provider, 'code' => 'no_api_key', 'status' => 400]);
        }

        return $key;
    }

    public function run_task($prompt, $type = 'animation', $context = null, $page_colors = null, $custom_fields = null, $post_types = null, $use_css_variables = false, $taxonomies = null, $language = null)
    {
        $api_key = $this->get_api_key();

        if ($type === 'form_settings') {
            $body = $this->build_settings_request_body($prompt, $context, $custom_fields, $post_types);
            $timeout = 30;
        } else if ($type === 'form_intent') {
            $body = $this->build_intent_request_body($prompt, $context);
            $timeout = 15;
        } else if ($type === 'form_clarify') {
            $body = $this->build_clarify_request_body($prompt, $context);
            $timeout = 20;
        } else if ($type === 'form_design') {
            $body = $this->build_design_request_body($prompt, $page_colors, $use_css_variables);
            $timeout = 30;
        } else if ($type === 'form') {
            $body = $this->build_form_request_body($prompt, $context, $page_colors, $custom_fields, $post_types, $taxonomies, $language);
            $timeout = 60;
        } else if ($type === 'email_template') {
            $body = $this->build_email_template_request_body($prompt, $context);
            $timeout = 60;
        } else if ($type === 'email_text') {
            $body = $this->build_email_text_request_body($prompt, $context);
            $timeout = 30;
        } else {
            $body = $this->build_animation_request_body($prompt);
            $timeout = 20;
        }

        $provider = $this->get_provider();

        if ($provider === 'anthropic') {
            return $this->call_anthropic($api_key, $body, $timeout);
        }

        return $this->call_openai($api_key, $body, $timeout);
    }

    private function call_openai($api_key, $body, $timeout)
    {
        // Convert legacy functions/function_call to tools/tool_choice format
        $body = $this->convert_functions_to_tools($body);

        $args = array(
            'method' => 'POST',
            'timeout' => $timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($body),
        );

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', $args);

        if (is_wp_error($response)) {
            return $response->get_error_message();
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        // Normalize tool_calls response back to function_call format for client compatibility
        if (isset($data['choices'][0]['message']['tool_calls']) && !isset($data['choices'][0]['message']['function_call'])) {
            $tc = $data['choices'][0]['message']['tool_calls'][0];
            $data['choices'][0]['message']['function_call'] = [
                'name' => $tc['function']['name'] ?? '',
                'arguments' => $tc['function']['arguments'] ?? '{}',
            ];
        }

        return $data;
    }

    /**
     * Convert legacy OpenAI functions/function_call format to the current tools/tool_choice format.
     */
    private function convert_functions_to_tools($body)
    {
        if (!isset($body['functions'])) {
            return $body;
        }

        $tools = [];
        foreach ($body['functions'] as $func) {
            $tools[] = [
                'type' => 'function',
                'function' => [
                    'name' => $func['name'],
                    'description' => $func['description'] ?? '',
                    'parameters' => $func['parameters'] ?? ['type' => 'object', 'properties' => []],
                ],
            ];
        }

        $body['tools'] = $tools;
        unset($body['functions']);

        // Convert function_call to tool_choice
        if (isset($body['function_call'])) {
            if (is_array($body['function_call']) && isset($body['function_call']['name'])) {
                $body['tool_choice'] = [
                    'type' => 'function',
                    'function' => ['name' => $body['function_call']['name']],
                ];
            } elseif ($body['function_call'] === 'auto') {
                $body['tool_choice'] = 'auto';
            }
            unset($body['function_call']);
        }

        return $body;
    }

    private function call_anthropic($api_key, $openai_body, $timeout)
    {
        // Convert OpenAI format to Anthropic format
        $anthropic_body = $this->convert_to_anthropic($openai_body);

        $args = array(
            'method' => 'POST',
            'timeout' => $timeout,
            'headers' => array(
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($anthropic_body),
        );

        $response = wp_remote_post('https://api.anthropic.com/v1/messages', $args);

        if (is_wp_error($response)) {
            return $response->get_error_message();
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        // Normalize Anthropic response to OpenAI format so the client code works unchanged
        return $this->normalize_anthropic_response($response_body);
    }

    private function convert_to_anthropic($openai_body)
    {
        // Map OpenAI model to Anthropic model
        // gpt-4o (complex tasks) → Claude Sonnet 4.6 (best quality/price for structured output)
        // gpt-4o-mini (simple tasks) → Claude Haiku 4.5 (fast, cheap for intent/clarify)
        $model_map = [
            'gpt-4o' => 'claude-sonnet-4-6',
            'gpt-4o-mini' => 'claude-haiku-4-5-20251001',
        ];

        $openai_model = $openai_body['model'] ?? 'gpt-4o-mini';
        $anthropic_model = $model_map[$openai_model] ?? 'claude-sonnet-4-6';

        // Extract system messages and user messages
        $system_parts = [];
        $messages = [];

        foreach ($openai_body['messages'] as $msg) {
            if ($msg['role'] === 'system') {
                $system_parts[] = $msg['content'];
            } else {
                $messages[] = $msg;
            }
        }

        // Convert OpenAI functions to Anthropic tools
        $tools = [];
        $tool_choice = null;

        if (isset($openai_body['functions'])) {
            foreach ($openai_body['functions'] as $func) {
                $tools[] = [
                    'name' => $func['name'],
                    'description' => $func['description'] ?? '',
                    'input_schema' => $func['parameters'] ?? ['type' => 'object', 'properties' => new \stdClass()],
                ];
            }
        }

        if (isset($openai_body['function_call'])) {
            $tool_choice = [
                'type' => 'tool',
                'name' => is_array($openai_body['function_call']) ? $openai_body['function_call']['name'] : $openai_body['function_call'],
            ];
        }

        $anthropic_body = [
            'model' => $anthropic_model,
            'max_tokens' => $openai_body['max_tokens'] ?? 1024,
            'messages' => $messages,
        ];

        if (!empty($system_parts)) {
            $anthropic_body['system'] = implode("\n\n", $system_parts);
        }

        if (!empty($tools)) {
            $anthropic_body['tools'] = $tools;
        }

        if ($tool_choice) {
            $anthropic_body['tool_choice'] = $tool_choice;
        }

        // Anthropic doesn't have temperature in the same range concerns, but pass it through
        if (isset($openai_body['temperature'])) {
            $anthropic_body['temperature'] = $openai_body['temperature'];
        }

        return $anthropic_body;
    }

    private function normalize_anthropic_response($response)
    {
        if (!is_array($response) || !isset($response['content'])) {
            return $response;
        }

        // Find tool_use block in content
        $tool_use = null;
        foreach ($response['content'] as $block) {
            if (isset($block['type']) && $block['type'] === 'tool_use') {
                $tool_use = $block;
                break;
            }
        }

        if (!$tool_use) {
            // No tool use — return as text response in OpenAI format
            $text = '';
            foreach ($response['content'] as $block) {
                if (isset($block['type']) && $block['type'] === 'text') {
                    $text .= $block['text'];
                }
            }

            return [
                'choices' => [[
                    'message' => [
                        'role' => 'assistant',
                        'content' => $text,
                    ],
                    'finish_reason' => $response['stop_reason'] ?? 'stop',
                ]],
            ];
        }

        // Convert tool_use to OpenAI function_call format
        return [
            'choices' => [[
                'message' => [
                    'role' => 'assistant',
                    'content' => null,
                    'function_call' => [
                        'name' => $tool_use['name'],
                        'arguments' => json_encode($tool_use['input']),
                    ],
                ],
                'finish_reason' => 'stop',
            ]],
        ];
    }

    /**
     * Email Designer: generate a full template (colors + elements) from a
     * prompt. The result maps 1:1 onto the designer's element schema.
     */
    private function build_email_template_request_body($prompt, $context = null)
    {
        $system = "You are an expert email designer for the Bricksforge Email Designer (WordPress). "
            . "You create beautiful, production-ready email templates. "
            . "Return the template via the function call.\n\n"
            . "ELEMENTS (flat array, rendered top to bottom). Each item: { \"type\": string, \"values\": object }.\n"
            . "Available types and their values:\n"
            . "- h1 / h2 / h3: { text, textAlign(left|center|right), spacingTop(px number), spacingBottom }\n"
            . "- text: { text (HTML, <p> allowed), textAlign, spacingTop, spacingBottom }\n"
            . "- button: { text, link (URL), textAlign, spacingTop, spacingBottom }\n"
            . "- image: { image (URL), fullWidth (boolean), textAlign, alt }\n"
            . "- spacing: { height (px number) }\n\n"
            . "For images use https://placehold.co/{W}x{H}/{BGHEX}/{FGHEX}.png?text={Label} with colors matching the design. "
            . "Full-width hero images: 600x240. Inline images: max 600 wide.\n"
            . "Dynamic data placeholders like {{ user_name }} or {{ site_title }} may be used in texts.\n\n"
            . "CANVAS (colors & meta): { backgroundColor, contentBackgroundColor, textColor, headingTextColor, "
            . "linkColor, linkHoverColor, buttonBackgroundColor, buttonTextColor, buttonBackgroundHoverColor, "
            . "buttonTextHoverColor, buttonBorderRadius (number), emailSubject, preheader }. "
            . "All colors as hex strings. Choose a cohesive palette fitting the request. "
            . "Write a fitting emailSubject and a short preheader.\n\n"
            . "Design guidelines: generous spacing (use spacing elements of 20-40px between sections), "
            . "one clear call to action, short scannable texts, 6-12 elements total.";

        if ($context) {
            $system .= "\n\nMODIFY MODE: You are MODIFYING an existing template. The current template is provided below as JSON. "
                . "Apply ONLY the requested changes and return the FULL updated template. "
                . "Keep everything the user did not ask to change EXACTLY identical (texts, order, values). "
                . "Existing elements carry an 'id' (and possibly 'parent', 'parentIndex', 'index' for column children) — "
                . "return these fields unchanged for kept elements. New elements get no id. "
                . "To remove an element, simply omit it.\n"
                . "CRITICAL: Your response is INVALID without the 'elements' field. "
                . "Work element by element: copy each element from CURRENT TEMPLATE (keeping its id), "
                . "apply the requested change if it affects that element, and include it in 'elements'. "
                . "Even if the request only touches colors, still return ALL elements. "
                . "If the request concerns texts or content (e.g. filling dummy text), you MUST rewrite the 'text' values of the elements accordingly. "
                . "NEVER replace the user's existing image URLs — keep every 'image' value exactly as it is, even for design/color changes. "
                . "placehold.co is ONLY for brand-new image elements you add. "
                . "Do NOT rename the template — always return the current 'name' unchanged.\n\nCURRENT TEMPLATE:\n"
                . (is_string($context) ? $context : json_encode($context));

            $prompt .= "\n\n(Apply this to the template above and return the FULL template — name, canvas AND the complete elements array.)";
        }

        return [
            'model' => 'gpt-4o',
            // Anthropic requires max_tokens and defaults to 1024 in the
            // converter — far too small for a full template (elements!)
            'max_tokens' => 8000,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $prompt],
            ],
            'functions' => [
                [
                    'name' => 'create_email_template',
                    'description' => 'Create the email template',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'name' => [
                                'type' => 'string',
                                'description' => 'Short template name',
                            ],
                            'canvas' => [
                                'type' => 'string',
                                'description' => 'Stringified JSON object with the CANVAS keys described in the system prompt',
                            ],
                            'elements' => [
                                'type' => 'string',
                                'description' => 'REQUIRED, never omit. Stringified JSON array of ALL elements of the template as described in the system prompt. In modify mode: every element of the current template (unchanged ones copied verbatim with their id), with the requested changes applied.',
                            ],
                        ],
                        'required' => ['name', 'canvas', 'elements'],
                    ],
                ],
            ],
            'function_call' => ['name' => 'create_email_template'],
        ];
    }

    /**
     * Email Designer: rewrite a single text (improve/shorten/translate...)
     * or suggest subject lines / preheaders. Context carries the template's
     * subject and purpose so the tone stays consistent.
     */
    private function build_email_text_request_body($prompt, $context = null)
    {
        $system = "You are an expert email copywriter working inside the Bricksforge Email Designer. "
            . "You rewrite email copy on request.\n"
            . "RULES:\n"
            . "- Keep any HTML structure (<p>, <strong>, <a href>, lists) intact unless asked otherwise.\n"
            . "- Keep Twig placeholders like {{ user_name }} and directives like {% if %} EXACTLY as they are.\n"
            . "- Answer in the same language as the input text.\n"
            . "- For rewrite tasks return the result in 'result'.\n"
            . "- For subject line or preheader suggestions return exactly 3 options as a stringified JSON array in 'suggestions'.";

        if ($context) {
            $system .= "\n\nTEMPLATE CONTEXT: " . (is_string($context) ? $context : json_encode($context));
        }

        return [
            'model' => 'gpt-4o',
            'max_tokens' => 2000,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $prompt],
            ],
            'functions' => [
                [
                    'name' => 'email_text_result',
                    'description' => 'Return the rewritten text or suggestions',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'result' => [
                                'type' => 'string',
                                'description' => 'The rewritten text (for rewrite tasks)',
                            ],
                            'suggestions' => [
                                'type' => 'string',
                                'description' => 'Stringified JSON array of exactly 3 strings (for subject/preheader suggestions)',
                            ],
                        ],
                    ],
                ],
            ],
            'function_call' => ['name' => 'email_text_result'],
        ];
    }

    private function build_animation_request_body($prompt)
    {
        $animation_controls = ['x', 'y', 'scale', 'scaleX', 'scaleY', 'rotate', 'rotateX', 'rotateY', 'rotateZ', 'skew', 'skewX', 'skewY', 'opacity', 'fillOpacity', 'strokeOpacity', 'color', 'backgroundColor', 'fill', 'stroke', 'borderRadius', 'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius', 'padding', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'margin', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'width', 'minWidth', 'height', 'minHeight', 'filter', 'drawSVG'];
        $animation_properties = [
            'method' => [
                'type' => 'string',
                'description' => 'The gsap method to use.',
                'enum' => ['from', 'to', 'fromTo'],
            ],
            'selector' => [
                'type' => 'string',
                'description' => 'The selector of the element to animate. The prompt MUST include a very clear selector which starts with . or # (for example .card or .card-wrapper). If no clear selector is provided, choose: ".your-selector"',
            ],
            'duration' => [
                'type' => 'number',
                'description' => 'The duration of the animation in seconds.',
            ],
            'delay' => [
                'type' => 'number',
                'description' => 'The delay of the animation in seconds.',
            ],
            'ease' => [
                'type' => 'string',
                'description' => 'The ease of the animation.',
            ],
            'data' => [
                'type' => 'string',
                'description' => 'The data to animate, for example: {x: 200, y: 50, repeat: -1}. Wrap the data with {}.  This MUST be a stringified JSON object.',
            ],
            'data2' => [
                'type' => 'string',
                'description' => 'The second data for fromTo animations, for example: {x: 200, y: 50, repeat: -1}. Wrap the data with {}.  This MUST be a stringified JSON object.',
            ],
            'yoyo' => [
                'type' => 'boolean',
                'description' => 'The yoyo of the animation.',
            ],
            'position' => [
                'type' => 'string',
                'description' => 'The position of the animation. In most cases this will be ">".',
                'enum' => ['>', '<', 'custom']
            ],
            'customPosition' => [
                'type' => 'string',
                'description' => 'The custom position of the animation.',
            ],
            'splitText' => [
                'type' => 'boolean',
                'description' => 'The splitText of the animation. If this is true, you MUST provide a splitTextType. Also, you MUST provide a stagger and staggerValue.',
            ],
            'splitTextType' => [
                'type' => 'string',
                'description' => 'The splitTextType of the animation.',
                'enum' => ['chars', 'words', 'lines']
            ],
            'stagger' => [
                'type' => 'boolean',
                'description' => 'The stagger of the animation.',
            ],
            'staggerValue' => [
                'type' => 'number',
                'description' => 'The staggerValue of the animation.',
            ],
            'repeat' => [
                'type' => 'number',
                'description' => 'The repeat of the animation.',
            ],
        ];

        return array(
            'model' => 'gpt-4o',
            'messages' => [
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'functions' => [
                [
                    'name' => 'create_gsap_animation_objects',
                    'description' => 'Creates GSAP animation objects from the provided data. The data property MUST be a stringified JSON object. For colors, always use HEX format.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            "animationObjects" => [
                                "type" => "array",
                                "items" => [
                                    "type" => "object",
                                    "properties" => $animation_properties,
                                    "required" => [
                                        "method",
                                        "duration",
                                        "delay",
                                        "data",
                                        "position",
                                    ]
                                ]
                            ],
                        ],
                        'required' => [
                            'animationObjects'
                        ]
                    ]
                ]
            ],
            'max_tokens' => 1000,
            'temperature' => 0.2,
            'function_call' => [
                'name' => 'create_gsap_animation_objects',
            ]
        );
    }

    private function build_form_request_body($prompt, $context = null, $page_colors = null, $custom_fields = null, $post_types = null, $taxonomies = null, $language = null)
    {
        $system_prompt = 'You design forms. Output semantic JSON. The client builds actual elements.

MODIFY RULE (CRITICAL): When context is provided:
1. Copy ALL existing rows from context into your output EXACTLY as they are.
2. Then apply ONLY the change the user requested (add condition, change label, add field, etc.).
3. To add a condition to an existing field: find that field in the rows, add "hasConditions":true and "conditions" to it. Do NOT replace the field with a conditional-wrapper.
4. To add validation: find the field, add "validation" array to it.
5. NEVER remove or replace existing fields unless explicitly asked. NEVER return empty rows.

OUTPUT: Each field needs "type" and "id". Rows: array of arrays. Multiple fields in one row = side by side.
Types: text, email, textarea, number, tel, url, password, date, file, hidden, select, checkbox, radio, card-radio, card-checkbox, calculation, rating, slider, repeater, live-value, layout-row, conditional-wrapper, honeypot.
Use "rows" for simple forms, "sections" (with own rows) for grouped forms, "steps" for wizards.

FIELDS:
- select/checkbox/radio/card-radio/card-checkbox: need "options":[{label, value, calcValue?, description?}]. Use radio/checkbox by default, card- only when explicitly asked.
- QUERY LOOP on fields: Instead of static "options", use "queryLoop" to populate options dynamically from WordPress posts/CPTs/taxonomies.
  Format: {"type":"checkbox","id":"courses","label":"Select Courses","queryLoop":{"postType":"course","label":"{post_title}","value":"{post_id}","orderby":"title","order":"asc","postsPerPage":10}}
  Works on: checkbox, radio, card-radio, card-checkbox, select (and their option children).
  "label" and "value" use Bricks dynamic data tags with SINGLE curly braces: {post_title}, {post_id}, {post_name}, {post_excerpt}, or ACF/Meta Box tags like {acf_field_name}. IMPORTANT: Single braces {tag} for Bricks dynamic data. Double braces {{field_id}} are ONLY for Pro Forms field references in actions/formulas.
  Optional: "taxQuery":[{"taxonomy":"category","terms":"slug","operator":"IN"}], "metaQuery":[{"key":"meta_key","value":"meta_value","compare":"="}].
  When queryLoop is set, do NOT include static "options" — the options come from the query.
- calculation: "formula" with {field_id} refs. Supports +,-,*,/,ternary (?:), variable assignments (x={field};). calcValue on options = 0 when unchecked. Use ONE calculation field with a complex formula for the final result. Do NOT create multiple calculation fields for intermediate values — do all math in one formula using variable assignments.
CALCULATION ID RULE: In formulas, {field_id} references the WRAPPER ID of radio/checkbox/select fields — NEVER individual option IDs. The wrapper automatically returns the sum of all selected calcValues. Example: if a checkbox wrapper has id "upgrades" with options (Insurance calcValue:89, Transfer calcValue:45, Tours calcValue:199), use {upgrades} in the formula. Do NOT use {upgrades_insurance} or {insurance} — those do not exist. Same for radio: if wrapper id is "meal_type", use {meal_type}, not {meal_type_buffet}.
- live-value: "connection" (field ID to show), "prefix", "suffix". Displays a field value as styled text.
IMPORTANT: A live-value shows the TEXT VALUE of a field, NOT the calcValue. So a live-value connected to a radio "destination" shows "japan", NOT "2100". To display PRICES or calculated numbers, you MUST use a calculation field in between:
  1. Create a calculation field (e.g. "dest_price") with formula "{destination}" — this returns the calcValue (2100)
  2. Create a live-value connected to "dest_price" with prefix "$" — this shows "$2100"
  NEVER connect a live-value directly to a radio/checkbox/select if you want to show the price. Always go through a calculation field.
Example: Radio "destination" (Bali calcValue:1200, Japan calcValue:2100), checkbox "upgrades" (Insurance calcValue:89, Tours calcValue:199), number "travelers".
  Calculation fields: "dest_cost" formula "{destination}*{travelers}", "upgrades_cost" formula "{upgrades}*{travelers}", "total" formula "{dest_cost}+{upgrades_cost}".
  Live-values: connection "dest_cost" prefix "$", connection "upgrades_cost" prefix "$", connection "total" prefix "$".
- layout-row: "columns":["Label","Value"] for pricing tables/summaries. Builds a flex-row with text columns. Use for price breakdowns, summaries, any label-value display. Can reference live calculation values with {{field_id}} syntax in columns. Add "bold":true for emphasis rows, "highlight":true for accent rows.
Example pricing summary with 3 rows:
[{"type":"layout-row","columns":["Meal Cost","${{meal_subtotal}}"]},{"type":"layout-row","columns":["Drinks","${{drink_subtotal}}"]},{"type":"layout-row","columns":["Total","${{total}}"],"bold":true}]
NO richtext with HTML tables.
- repeater: "fields" array of child field objects.
- conditional-wrapper: wraps MULTIPLE fields to show/hide together. "conditions":[{"condition":"form_field","value":"field_id","operator":"==","value2":"target"}]
  For showing/hiding a SINGLE existing field: add "hasConditions":true and "conditions" directly on that field — do NOT use a conditional-wrapper. Only use conditional-wrapper when you need to group multiple fields under one condition.
- validation: array of rules, each: {"type":"...","message":"Error text"}. Types:
  "required" (field must have value), "email" (valid email), "number" (must be numeric), "url" (valid URL),
  "minChars" (needs "charsCount":N), "maxChars" (needs "charsCount":N),
  "value" (must match exact "value":"expected"),
  "custom" (regex: needs "regex":"pattern" — e.g. "regex":"^[0-9]{10,500}$" for number range).
  For number ranges (min/max): use the field "min" and "max" properties on the field itself, not validation.
  "liveValidation":true enables on-blur validation.

DESIGN: Group related fields in rows. Add title+description for 4+ fields. Plain text only, never HTML in values.
FIELD IDS: EVERY field MUST have a clear, descriptive, snake_case "id" like "first_name", "email", "phone_number", "travel_date". NEVER use random/hex IDs like "a42434" or "f2b94c". The ID is used in form actions ({{field_id}}) and must be human-readable.
NO COLORS: Do NOT include color properties (headingColor, labelColor, fieldBg, accentColor, textColor) in your output. Colors are inherited from the CSS framework. Focus on form fields, structure, and settings.
IMPORTANT: You MUST always include "rows" or "sections" with actual form fields. A response with only title/description/submitLabel is INVALID — the form needs fields!

BRICKS LAYOUT: You can nest Bricks elements inside the form for any visual layout. These go in the "rows" array alongside form fields.
Elements with children use: {"type":"block","settings":{...},"children":[...]}
Available layout elements:
- "block": Nestable container. Settings: _display (flex/grid), _direction (row/column), _justifyContent (flex-start/center/flex-end/space-between/space-around), _alignItems (flex-start/center/flex-end/stretch), _columnGap, _rowGap, _padding, _margin, _background:{color:{raw:"#hex"}}, _border:{width:{top:"1px",...},style:"solid",color:{raw:"#hex"},radius:{top:"8px",...}}, _borderRadius, _boxShadow.
- "heading": {text, tag (h1-h6/span/p)}. Plain text titles.
- "text-basic": {text, tag (div/p/span), bold:true}. Simple text for labels, values, prices.
- "divider": Visual line. {style:"solid/dashed/dotted", color:"#hex", height:"1px"}.
- "icon": {icon:{library:"fontawesome",icon:"fas fa-check"}, iconColor:"#hex", iconSize:"16px"}.
- "button": {text, link:{url:"#"}, style:"primary/secondary", size:"sm/md/lg", outline:true}.
- "list": Styled list. {items:[{title:"Feature",meta:"$99",description:"Details",icon:{library:"fontawesome",icon:"fas fa-check"}}]}. Has built-in alternating row colors, highlight badges, separator styling.
- "live-value": {connection:"field_id", prefix:"$", suffix:"/mo"} to display calculated values.

LAYOUT PATTERNS:
1. Pricing row: {"type":"block","settings":{"_display":"flex","_justifyContent":"space-between","_padding":"8px 0","_border":{"width":{"bottom":"1px"},"style":"solid","color":{"raw":"rgba(0,0,0,0.06)"}}},"children":[{"type":"text-basic","text":"Subtotal"},{"type":"live-value","connection":"subtotal","prefix":"$"}]}
2. Card: {"type":"block","settings":{"_padding":"20px","_background":{"color":{"raw":"rgba(0,0,0,0.02)"}},"_border":{"radius":{"top":"12px","right":"12px","bottom":"12px","left":"12px"}}},"children":[...]}
3. Summary table: Parent block with padding/border + multiple pricing rows inside.
4. Feature item: {"type":"block","settings":{"_display":"flex","_columnGap":"12px","_alignItems":"center"},"children":[{"type":"icon","icon":{"library":"fontawesome","icon":"fas fa-check"},"iconColor":"#22c55e","iconSize":"16px"},{"type":"text-basic","text":"Feature description"}]}
NEVER use richtext/text (HTML editor) for layouts. Use text-basic for all text content.

ACTIONS: formSettings.actions is an array of action keys. Available: email, create_submission, redirect, reload, webhook, custom, login, registration, post_create, post_update, post_delete, update_post_meta, update_user_meta, reset_user_password, confetti, create_pdf, set_storage_item, stripe, mollie, wc_add_to_cart.
DEFAULT: Only include "email" in actions unless the user explicitly asks for other actions. Do NOT add create_submission, confetti, redirect, or any other action on your own.

CRITICAL ACTION RULE: When the user mentions saving data as posts, post meta, custom fields, or creating new entries — you MUST add "post_create" AND "update_post_meta" to the actions array AND include the full config (title, post type, meta mappings). Do NOT default to just "email" when post storage is requested.

When user asks for post creation, webhooks, redirects etc., add the action AND its config to formSettings:
- post_create: add "post_create" to actions + set pro_forms_post_action_post_create_title (use {{field_id}} to reference form fields), pro_forms_post_action_post_create_content, pro_forms_post_action_post_create_pt ("post"|"page"|custom type), pro_forms_post_action_post_create_post_status ("publish"|"draft"|"pending").
- update_post_meta: add "update_post_meta" to actions + set pro_forms_post_action_update_post_meta_data as array of {name: "meta_key", value: "{{field_id}}", type: "replace", post_id: "{{live_post_id}}", field_key: "field_xxx"}. Use {{live_post_id}} to reference a post created by post_create in the same submission. For ACF fields: ALWAYS include the "field_key" from the custom fields data (e.g. "field_64a1b2c3"). This ensures ACF correctly identifies the field.
ARRAY VALUES: For checkbox, multi-select, or any field that stores multiple values, use {{field_id:array}} (with :array suffix) in the meta value. This preserves the array format. Without :array, values are stored as a comma-separated string which breaks ACF checkbox/select fields. Example: {name:"upgrades", value:"{{upgrades:array}}", ...}.
IMPORTANT: When user asks to save data as posts with custom fields / post meta, you MUST add BOTH "post_create" AND "update_post_meta" to actions. post_create creates the post, update_post_meta saves each form field as post meta on the newly created post. Map EVERY form field to a matching meta key using {{live_post_id}} as post_id. Example: if form has fields "animal_name", "species", "age" and ACF fields with keys, add: pro_forms_post_action_update_post_meta_data: [{name:"animal_name",value:"{{animal_name}}",type:"replace",post_id:"{{live_post_id}}",field_key:"field_64a..."},{name:"species",value:"{{species}}",type:"replace",post_id:"{{live_post_id}}",field_key:"field_64b..."},{name:"age",value:"{{age}}",type:"replace",post_id:"{{live_post_id}}",field_key:"field_64c..."}].
- redirect: add "redirect" to actions + set redirect: "https://example.com" (supports {{field_id}}).
- webhook: add "webhook" to actions + set pro_forms_post_action_webhooks as array of {url: "...", method: "POST", content_type: "json", data: [{key: "name", value: "{{field_id}}"}]}.
- registration: add "registration" to actions + set registrationEmail: "{{email}}", registrationPassword: "{{password}}", registrationUsername: "{{username}}".
- login: add "login" to actions + set loginEmail: "{{email}}", loginPassword: "{{password}}".
- create_submission: just add "create_submission" to actions (no extra config needed).
- confetti: just add "confetti" to actions.
Field references in action configs use {{field_id}} syntax (double curly braces around the field ID).';

        $messages = [['role' => 'system', 'content' => $system_prompt]];

        if ($context) {
            $messages[] = [
                'role' => 'system',
                'content' => 'Current form (preserve all, only change what user requests): ' . json_encode($context)
            ];
        }

        // Page colors intentionally NOT sent to form build — colors are inherited from user's CSS framework.
        // Design/styling is handled separately via the design override flow.

        if (isset($custom_fields) && !empty($custom_fields)) {
            $messages[] = [
                'role' => 'system',
                'content' => 'Available custom fields on this site (use these for update_post_meta mappings when user asks to save to custom fields): ' . json_encode($custom_fields)
            ];
        }

        if (isset($post_types) && !empty($post_types)) {
            $messages[] = [
                'role' => 'system',
                'content' => 'Available post types on this site (use the SLUG, not the label, for query loops and post creation). ONLY use post types from this list: ' . json_encode($post_types)
            ];
        }

        if (isset($taxonomies) && !empty($taxonomies)) {
            $messages[] = [
                'role' => 'system',
                'content' => 'Available taxonomies on this site (use for taxonomy queries in query loops): ' . json_encode($taxonomies)
            ];
        }

        if (isset($language) && !empty($language)) {
            $messages[] = [
                'role' => 'system',
                'content' => 'Site language: ' . $language . '. Use this language for all labels, placeholders, descriptions, headings, and success messages.'
            ];
        }

        $messages[] = ['role' => 'user', 'content' => $prompt];

        return array(
            'model' => 'gpt-4o',
            'messages' => $messages,
            'functions' => [
                [
                    'name' => 'build_form',
                    'description' => 'Builds a form from semantic description. Client handles all element creation and styling.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'formSettings' => [
                                'type' => 'object',
                                'description' => 'Form config. Keys: actions (array), emailSubject, emailTo, emailToCustom, emailContent, successMessage, htmlEmail, redirect. For post_create: pro_forms_post_action_post_create_title, _content, _pt, _post_status. For update_post_meta: pro_forms_post_action_update_post_meta_data (array of {name,value,type,post_id}). For webhook: pro_forms_post_action_webhooks (array). For registration: registrationEmail, registrationPassword, registrationUsername. Use {{field_id}} for field references.',
                            ],
                            'title' => ['type' => 'string', 'description' => 'Form heading (optional)'],
                            'description' => ['type' => 'string', 'description' => 'Form description text (optional)'],
                            'sections' => [
                                'type' => 'array',
                                'description' => 'For grouped forms. Each section has optional title, description, and rows.',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'title' => ['type' => 'string'],
                                        'description' => ['type' => 'string'],
                                        'rows' => ['type' => 'array', 'items' => ['type' => 'array', 'items' => ['type' => 'object']]],
                                    ],
                                ],
                            ],
                            'rows' => [
                                'type' => 'array',
                                'description' => 'For simple forms without sections. Array of rows, each row is array of fields.',
                                'items' => ['type' => 'array', 'items' => ['type' => 'object']],
                            ],
                            'steps' => [
                                'type' => 'array',
                                'description' => 'For multi-step wizards. Each step has title and rows.',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'title' => ['type' => 'string'],
                                        'rows' => ['type' => 'array', 'items' => ['type' => 'array', 'items' => ['type' => 'object']]],
                                    ],
                                ],
                            ],
                            'submitLabel' => ['type' => 'string', 'description' => 'Submit button text. Default: "Submit"'],
                        ],
                        'required' => ['formSettings'],
                    ],
                ],
            ],
            'max_tokens' => 8192,
            'temperature' => 0.2,
            'function_call' => ['name' => 'build_form'],
        );
    }

    private function build_clarify_request_body($prompt, $context = null)
    {
        $system = 'You decide if a form-building request needs clarification. If specific (mentions fields, or is a modification), set skip:true. If vague, return 1-2 SHORT questions.

RULES:
- ONLY ask about which fields to include. NEVER ask about email, success messages, recipients, actions, required fields, or config.
- ALWAYS use "choice" type with allowMultiple:true for the fields question. Suggest 6-8 relevant field options based on the form type (e.g. for contact form: "First Name", "Last Name", "Email", "Phone", "Company", "Subject", "Message").
- Max 2 questions. First question: which fields (choice, multi-select). Optional second: layout preference (choice: "Simple", "Multi-section", "Multi-step wizard").
- Keep options short (1-3 words).
- Parentheses in answers are valid syntax, e.g. "Fruits (as radio)".';

        $messages = [['role' => 'system', 'content' => $system]];

        if ($context) {
            $messages[] = ['role' => 'system', 'content' => 'Form already exists (this is a modification request — almost always skip): ' . json_encode($context)];
        }

        $messages[] = ['role' => 'user', 'content' => $prompt];

        return array(
            'model' => 'gpt-4o',
            'messages' => $messages,
            'functions' => [
                [
                    'name' => 'clarify_form_request',
                    'description' => 'Decide if clarification is needed before building a form.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'skip' => [
                                'type' => 'boolean',
                                'description' => 'true if the prompt is clear enough to build directly without questions',
                            ],
                            'questions' => [
                                'type' => 'array',
                                'description' => 'Clarification questions. Only include if skip is false.',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'id' => ['type' => 'string', 'description' => 'Question ID (q1, q2, ...)'],
                                        'question' => ['type' => 'string', 'description' => 'The question to ask'],
                                        'type' => ['type' => 'string', 'enum' => ['choice', 'text'], 'description' => 'choice = multiple choice, text = free text input'],
                                        'options' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Options for choice type'],
                                        'allowMultiple' => ['type' => 'boolean', 'description' => 'Allow selecting multiple options (choice type only)'],
                                    ],
                                    'required' => ['id', 'question', 'type'],
                                ],
                            ],
                        ],
                        'required' => ['skip'],
                    ],
                ],
            ],
            'max_tokens' => 500,
            'temperature' => 0.3,
            'function_call' => ['name' => 'clarify_form_request'],
        );
    }

    private function build_intent_request_body($prompt, $context = null)
    {
        $system = 'Classify the user intent for a form builder AND determine what context data the AI needs to fulfill the request.

INTENT — classify into exactly one category:
- "settings": ONLY form-level actions/config: adding actions (email, confetti, redirect, create post, webhook), changing success message, email subject, email recipient. NOT label/field styling.
- "structure": ANY change to individual fields: adding/removing fields, changing labels, placeholders, required, validation, conditions, steps/sections, calculators, repeaters, query loops. Also: creating a new form.
- "design": ONLY visual styling: colors, backgrounds, borders, shadows, fonts, spacing, rounded corners.
- "both": Multiple categories.
KEY: validation, conditions, required, placeholder, label changes = ALWAYS "structure". Actions, confetti, email config = "settings".

REQUIRED CONTEXT — select which data sources the AI will need:
- "postTypes": When the prompt mentions custom post types, posts, CPTs, content types, query loops, or dynamic data from posts. Examples: "checkboxes from courses", "select with products", "create post on submit".
- "customFields": When the prompt mentions ACF, Meta Box, JetEngine, custom fields, meta data, or saving to custom fields. Examples: "save to ACF field", "use meta box fields", "update post meta".
- "taxonomies": When the prompt mentions categories, tags, taxonomy terms, or filtering by taxonomy.
- "language": When the form should match the site language or the user mentions a specific language.
Only include context types that are actually relevant. For simple prompts like "add a phone field" or "make it dark", requiredContext should be empty [].';

        $messages = [['role' => 'system', 'content' => $system]];

        if ($context) {
            $messages[] = ['role' => 'system', 'content' => 'Current form exists with these fields: ' . json_encode($context)];
        }

        $messages[] = ['role' => 'user', 'content' => $prompt];

        return array(
            'model' => 'gpt-4o',
            'messages' => $messages,
            'functions' => [
                [
                    'name' => 'classify_intent',
                    'description' => 'Classify user intent and determine what context data is needed.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'intent' => [
                                'type' => 'string',
                                'enum' => ['settings', 'structure', 'design', 'both'],
                            ],
                            'requiredContext' => [
                                'type' => 'array',
                                'description' => 'Which data sources the AI needs for this request.',
                                'items' => [
                                    'type' => 'string',
                                    'enum' => ['postTypes', 'customFields', 'taxonomies', 'language'],
                                ],
                            ],
                        ],
                        'required' => ['intent', 'requiredContext'],
                    ],
                ],
            ],
            'max_tokens' => 200,
            'temperature' => 0,
            'function_call' => ['name' => 'classify_intent'],
        );
    }

    private function build_settings_request_body($prompt, $context = null, $custom_fields = null, $post_types = null)
    {
        $system = 'You modify form-level settings for a Bricksforge Pro Form. Output ONLY the settings that should change based on the user request. IMPORTANT: Include the COMPLETE actions array (all existing actions + new ones). Do NOT add actions the user did not ask for.

Available settings:
- actions: array of action keys. Available: email, create_submission, redirect, reload, webhook, custom, login, registration, post_create, post_update, update_post_meta, confetti, create_pdf, stripe, mollie, wc_add_to_cart
- emailSubject, emailTo (admin_email|custom|dynamic), emailToCustom, emailContent, successMessage, htmlEmail
- redirect: URL for redirect action
- For post_create: pro_forms_post_action_post_create_title (use {{field_id}}), pro_forms_post_action_post_create_content, pro_forms_post_action_post_create_pt (post type slug), pro_forms_post_action_post_create_post_status (publish|draft)
- For update_post_meta: pro_forms_post_action_update_post_meta_data (array of {name:"meta_key", value:"{{field_id}}", type:"replace", post_id:"{{live_post_id}}"}). For checkbox/multi-select fields use {{field_id:array}} to preserve array format.
- For webhook: pro_forms_post_action_webhooks (array of {url, method, content_type, data:[{key,value}]})
- Global Field Styles (form-level typography): labelTypography (object with color, font-size, font-weight, text-transform, letter-spacing), placeholderTypography (object with color, font-size), fieldTypography (object with color, font-size), fieldBackgroundColor (string or {raw:"value"}), fieldPadding (object with top,right,bottom,left). Color values use {raw:"value"} format.

IMPORTANT for post creation:
- You MUST include "post_create" in the actions array to create a post. Without it, no post is created.
- To also save custom fields, add "update_post_meta" to actions AND provide the meta data mapping.
- In pro_forms_post_action_update_post_meta_data, the "name" is the REAL field name (e.g. "name", "email"), NOT the dynamic data tag (e.g. NOT "acf_name"). The custom fields list provides both: "tag" is the dynamic data tag, "fieldName" is what you should use as the meta "name".
- For ACF fields: ALWAYS include "field_key" (e.g. "field_64a1b2c3") from the custom fields data. This ensures ACF correctly identifies the field.
- Use {{live_post_id}} as post_id to reference the newly created post.
- Automatically map matching form fields to custom fields when available.';

        $messages = [['role' => 'system', 'content' => $system]];

        if ($context) {
            $messages[] = ['role' => 'system', 'content' => 'Current form (fields and settings): ' . json_encode($context)];
        }

        if (isset($post_types) && !empty($post_types)) {
            $messages[] = ['role' => 'system', 'content' => 'Available post types on this site (slug → label): ' . json_encode($post_types) . '. IMPORTANT: Use the SLUG (key) for pro_forms_post_action_post_create_pt, NOT the label. If user says "Courses", find the matching slug.'];
        }

        if (isset($custom_fields) && !empty($custom_fields)) {
            $messages[] = ['role' => 'system', 'content' => 'Available custom fields (use fieldName as meta key, NOT tag): ' . json_encode($custom_fields) . '. When post_create is used, ALWAYS also add update_post_meta to actions and map ALL matching form fields to these custom fields automatically using {{live_post_id}} as post_id. IMPORTANT: Also set pro_forms_post_action_update_post_meta_source based on the field group: "ACF"→"acf", "Meta Box"→"metabox", "JetEngine"→"jetengine", otherwise "default".'];
        }

        $messages[] = ['role' => 'user', 'content' => $prompt];

        return array(
            'model' => 'gpt-4o',
            'messages' => $messages,
            'functions' => [
                [
                    'name' => 'update_form_settings',
                    'description' => 'Update form settings. Output the settings directly as top-level properties.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'actions' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'COMPLETE actions array (keep existing + add new)'],
                            'pro_forms_post_action_post_create_pt' => ['type' => 'string', 'description' => 'Post type slug for post_create action'],
                            'pro_forms_post_action_post_create_title' => ['type' => 'string', 'description' => 'Post title, use {{field_id}} for field values'],
                            'pro_forms_post_action_post_create_content' => ['type' => 'string'],
                            'pro_forms_post_action_post_create_post_status' => ['type' => 'string', 'enum' => ['publish', 'draft', 'pending']],
                            'pro_forms_post_action_update_post_meta_source' => ['type' => 'string', 'enum' => ['default', 'acf', 'metabox', 'jetengine', 'acpt'], 'description' => 'Source plugin for custom fields. Set based on field group.'],
                            'pro_forms_post_action_update_post_meta_data' => [
                                'type' => 'array',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'name' => ['type' => 'string', 'description' => 'Real field name (e.g. "name", NOT "acf_name")'],
                                        'value' => ['type' => 'string', 'description' => 'Form field reference {{field_id}}'],
                                        'type' => ['type' => 'string', 'enum' => ['replace']],
                                        'post_id' => ['type' => 'string', 'description' => 'Use {{live_post_id}} for newly created posts'],
                                    ],
                                ],
                            ],
                            'emailSubject' => ['type' => 'string'],
                            'emailTo' => ['type' => 'string'],
                            'emailToCustom' => ['type' => 'string'],
                            'emailContent' => ['type' => 'string'],
                            'successMessage' => ['type' => 'string'],
                            'redirect' => ['type' => 'string'],
                        ],
                    ],
                ],
            ],
            'max_tokens' => 800,
            'temperature' => 0.2,
            'function_call' => ['name' => 'update_form_settings'],
        );
    }

    private function build_design_request_body($prompt, $page_colors = null, $use_css_variables = false)
    {
        $system = 'You are a refined, professional form designer for the Bricks page builder. Style forms by outputting an array of style overrides.

DESIGN PHILOSOPHY:
- Professional, refined, polished. Think Stripe, Linear, or Apple forms.
- The form should feel native to the page. Match the site color temperature (warm/cool).
- Form background: ALWAYS use transparent, rgba(255,255,255,0.5), or rgba(255,255,255,0.7). NEVER use the sectionBg color directly as the form background — it will look garish. The form should float subtly above the page, not match it.
- Inputs: clean white (#ffffff) background, crisp 1px border in a neutral gray (#d4d4d4 to #e5e5e5), generous 8-10px border-radius. No colored borders on inputs.
- Headings: use the site heading color. Clean, no underlines or decorations unless asked.
- Labels: slightly muted (#555 to #666), never black.
- Submit button: make it stand out as the primary CTA. Be creative: use the site accent color, a gradient, rounded pill shape, bold typography, or a subtle shadow. Each "improve" request should produce a DIFFERENT design — vary between styles like: pill-shaped with gradient, sharp corners with bold bg, outlined with hover-style border, full-width with large padding, compact with icon-like feel.
- Subtle box-shadow on the form for depth: rgba(0,0,0,0.04) to rgba(0,0,0,0.08).
- Do NOT add colored underlines to headings. Do NOT use olive/yellow/green for text colors.
- VARIETY: When user says "improve", produce something genuinely different each time. Vary border-radius (0px to 24px), vary padding sizes, vary color approaches (dark, accent, gradient), vary border styles (none, thin, thick accent).

LIGHT/DARK DETECTION: Check the sectionBg and bodyBg values. If they are light (luminance > 0.5, e.g. #ffffff, #f5f5f5, #f1f1c0), use DARK text colors for readability. If they are dark (luminance < 0.5, e.g. #1a1a1a, #171717), use LIGHT text colors. NEVER use white/light text on light backgrounds. NEVER use dark text on dark backgrounds.

COLOR RULE: ALWAYS use the colors from the SITE DESIGN CONTEXT provided. Use headingColor for headings, textColor for labels/descriptions, buttonBg/buttonColor for submit, sectionBg to calculate a complementary form background. Only invent colors if the site context does not provide them. If the user asks for specific colors, use those instead.

CONSISTENCY: ALL input fields MUST have the same background, border, typography, and padding. Never mix different styles between inputs. Use the same values for every "input" override.

EXAMPLE structure (use site colors, not these placeholder values):
form: _background {color:{raw:"rgba(255,255,255,0.55)"}}, _padding all "36px", _border {radius all "16px", width all "1px", style "solid", color:{raw:"rgba(0,0,0,0.08)"}}
heading: _typography {color:"[use site headingColor]", font-weight:"600"}  (NO _border, NO text-decoration)
text: _typography {color:"[use site textColor, slightly muted]"}
input: background {color:{raw:"#ffffff"}}, border {width all "1px", style "solid", color:{raw:"[subtle gray]"}, radius all "8px"}, typography {color:{raw:"[use site textColor]"}}, padding all "12px"
submit: background {color:{raw:"[use site buttonBg or accent]"}}, typography {color:{raw:"[use site buttonColor or white]"}, font-weight:"600"}, border {radius all "8px"}, padding "14px 28px"

CRITICAL: Do NOT change spacing/layout (_margin, _padding on headings/text/blocks, _display, _direction, _columnGap, _rowGap, _flexGrow, _flexBasis). Only change VISUAL properties: colors, backgrounds, borders, border-radius, shadows, typography (color, font-size, font-weight, text-transform). Exceptions: _padding on "form" and "padding" on "input"/"submit" are OK. _width on "submit" is OK (e.g. "100%" for full-width buttons).

TARGETS: "form" (the form wrapper), "heading", "text" (descriptions), "input" (all input fields), "submit" (submit button), "block" (layout wrappers), "card" (card radio/checkbox), "label" (form field labels — sets labelTypography on form), "placeholder" (input placeholder text — sets placeholderTypography on form), "field" (global input field styles — sets fieldTypography, fieldBackgroundColor, fieldPadding on form).

FORM-LEVEL TARGETS (label, placeholder, field):
These targets set "Global Field Styles" on the form element itself (not on individual fields).
- "label": use _typography format: {"_typography": {"color": "var(--white)", "font-size": "14px", "font-weight": "500"}}
- "placeholder": use _typography format: {"_typography": {"color": "rgba(255,255,255,0.4)"}}
- "field": use _typography for text color, _background for bg, _padding for padding: {"_typography": {"color": "#333"}, "_background": {"color": {"raw": "#fff"}}, "_padding": {"top": "12px", ...}}

BRICKS SETTINGS FORMAT — use these exact key structures:
- background: {"color": {"raw": "#hex"}}
- _background: {"color": {"raw": "#hex"}} (for Bricks elements like form/heading/text)
- typography: {"color": {"raw": "#hex"}, "font-size": "16", "font-weight": "600"} (for form fields)
- _typography: {"color": "#hex", "font-size": "16", "font-weight": "600"} (for Bricks elements)
- border: {"width": {"top": "1px", "right": "1px", "bottom": "1px", "left": "1px"}, "style": "solid", "color": {"raw": "#hex"}, "radius": {"top": "8px", "right": "8px", "bottom": "8px", "left": "8px"}}
- _border: same format but for Bricks elements
- padding: {"top": "12px", "right": "12px", "bottom": "12px", "left": "12px"}
- _padding: same for Bricks elements
- _margin: {"top": "0px", "right": "0px", "bottom": "20px", "left": "0px"}
- _boxShadow: {"values": {"offsetX": "0", "offsetY": "4", "blur": "12", "spread": "0"}, "color": {"raw": "rgba(0,0,0,0.1)"}}
- For partial borders (e.g. bottom only): {"width": {"top": "0px", "right": "0px", "bottom": "2px", "left": "0px"}, "style": "solid", "color": {"raw": "#hex"}}

RULES:
- Be creative! Red accents can mean: red heading underlines, red submit button, red left borders on inputs, red focus rings, subtle red background tints.
- Only include overrides for elements you want to change. Omit elements that should stay as-is.
- Use rgba for subtle effects: rgba(255,0,0,0.05) for tints, rgba(0,0,0,0.1) for shadows.
- "form" target uses underscore-prefix keys (_background, _padding, _border, _boxShadow).
- "heading" and "text" targets use underscore-prefix keys (_typography, _margin, _border).
- "input" and "submit" targets use non-prefix keys (background, typography, border, padding).
- "card" target uses cardBackground, cardBorder, checkedCardBackground, checkedCardBorder (string/object values, not underscore-prefix).';

        $messages = [['role' => 'system', 'content' => $system]];

        if (isset($page_colors) && !empty($page_colors)) {
            $messages[] = ['role' => 'system', 'content' => 'SITE DESIGN CONTEXT (use to match the site aesthetic): ' . json_encode($page_colors) . '. When user says "improve design" or "match site style", use these values. The form should feel native to this site — use the same color family, similar contrast ratios, and complementary tones.'];
        }

        $css_variables = null;
        if (is_object($page_colors) && isset($page_colors->cssVariables)) {
            $css_variables = $page_colors->cssVariables;
        } elseif (is_array($page_colors) && isset($page_colors['cssVariables'])) {
            $css_variables = $page_colors['cssVariables'];
        }

        if ($use_css_variables && $css_variables) {
            $messages[] = ['role' => 'system', 'content' => 'CSS VARIABLES MODE IS ON. You MUST use var(--name) references instead of static hex values wherever a matching variable exists. The site has these CSS variables: ' . json_encode($css_variables) . '

RULES for CSS Variables mode — APPLY TO ALL VALUES, NOT JUST COLORS:
- Colors: use var(--variable-name) instead of hex. In {raw} format: {raw: "var(--primary)"}.
- Padding & Margin: use spacing variables. padding: {top: "var(--gap-s)", right: "var(--gap-m)", ...}. NEVER use static px values like "12px" for padding/margin when spacing variables exist.
- Border-radius: use var(--radius-card) or similar. In border.radius: {top: "var(--radius-card)", ...}.
- Font sizes: use var(--font-h3), var(--font-body) etc.
- Gaps (columnGap, rowGap): use var(--gap-s), var(--gap-m) etc.
- Scale variants: look for xs/s/m/l/xl patterns. Use appropriate scale (xs for tight padding, s for input padding, m for section gaps, l for large spacing).
- EVERY value that has a matching variable MUST use var(--name). This includes padding, margin, gap, border-radius, font-size, AND colors.
- Only use static values as fallback when NO matching variable exists.
- NEVER invent variable names not in the provided list.'];
        }

        $messages[] = ['role' => 'user', 'content' => $prompt];

        return array(
            'model' => 'gpt-4o',
            'messages' => $messages,
            'functions' => [
                [
                    'name' => 'style_form',
                    'description' => 'Apply creative visual styles to form elements.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'overrides' => [
                                'type' => 'array',
                                'description' => 'Array of style overrides, each targeting a specific element type.',
                                'items' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'target' => [
                                            'type' => 'string',
                                            'enum' => ['form', 'heading', 'text', 'input', 'submit', 'block', 'card', 'label', 'placeholder', 'field'],
                                            'description' => 'Which element type to style',
                                        ],
                                        'settings' => [
                                            'type' => 'object',
                                            'description' => 'Bricks settings to merge into the element. Use exact Bricks format.',
                                        ],
                                    ],
                                    'required' => ['target', 'settings'],
                                ],
                            ],
                        ],
                        'required' => ['overrides'],
                    ],
                ],
            ],
            'max_tokens' => 1500,
            'temperature' => 0.65,
            'function_call' => ['name' => 'style_form'],
        );
    }
}
