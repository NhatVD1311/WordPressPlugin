<?php

namespace Bricksforge\ProForms\Actions;

use Bricksforge\Api\FormsHelper as FormsHelper;

class Reset_User_Password
{
    public $name = "reset_user_password";

    public function run($form)
    {
        $forms_helper = new FormsHelper();

        $form_settings = $form->get_settings();
        $form_fields   = $form->get_fields();
        $form_files = $form->get_uploaded_files();
        $post_id = $form->get_post_id();
        $form_id = $form->get_form_id();

        $method = $form_settings['resetUserPasswordMethod'];
        $email_field = isset($form_settings['resetUserPasswordEmail']) ? $form_settings['resetUserPasswordEmail'] : '';
        $email = $email_field ? $form->get_form_field_by_id($email_field) : '';
        $user = get_user_by('email', $email);

        switch ($method) {
            case 'request':
                if ($user) {

                    $result = retrieve_password($user->user_login);

                    if (is_wp_error($result)) {
                        error_log($result->get_error_message());
                    }
                } else {
                    error_log("User with email $email does not exist");
                }
                break;
            case 'update':
                $verify_password_confirmation = isset($form_settings['resetUserPasswordVerifyPasswordConfirmation']) ? $form_settings['resetUserPasswordVerifyPasswordConfirmation'] : false;
                $verify_current_password = isset($form_settings['resetUserPasswordVerifyCurrentPassword']) ? $form_settings['resetUserPasswordVerifyCurrentPassword'] : false;
                $strong_passwords = isset($form_settings['resetUserPasswordAllowOnlyStrongPasswords']) ? $form_settings['resetUserPasswordAllowOnlyStrongPasswords'] : false;

                $current_password = isset($form_settings['resetUserPasswordCurrentPasswordValue']) ? $form_settings['resetUserPasswordCurrentPasswordValue'] : null;
                if ($current_password) {
                    $current_password = $form->get_form_field_by_id($current_password);
                    $current_password = $forms_helper->sanitize_value($current_password);
                }

                $new_password = isset($form_settings['resetUserPasswordNewPassword']) ? $form_settings['resetUserPasswordNewPassword'] : null;
                if ($new_password) {
                    $new_password = $form->get_form_field_by_id($new_password);
                    $new_password = $forms_helper->sanitize_value($new_password);
                }

                $new_password_confirm = isset($form_settings['resetUserPasswordPasswordConfirmationValue']) ? $form_settings['resetUserPasswordPasswordConfirmationValue'] : null;
                if ($new_password_confirm) {
                    $new_password_confirm = $form->get_form_field_by_id($new_password_confirm);
                    $new_password_confirm = $forms_helper->sanitize_value($new_password_confirm);
                }

                $note_enter_new_password = isset($form_settings['resetUserPasswordNotificationNewPassword']) ? $form_settings['resetUserPasswordNotificationNewPassword'] : "Please enter a new password.";
                $note_current_password_incorrect = isset($form_settings['resetUserPasswordNotificationCurrentPasswordIncorrect']) ? $form_settings['resetUserPasswordNotificationCurrentPasswordIncorrect'] : "The current password is incorrect.";
                $note_passwords_do_not_match = isset($form_settings['resetUserPasswordNotificationPasswordsDoNotMatch']) ? $form_settings['resetUserPasswordNotificationPasswordsDoNotMatch'] : "Passwords do not match.";

                if (!isset($new_password) || empty($new_password)) {
                    $form->log_error_and_exit($this->name, __($note_enter_new_password, 'bricksforge'));
                }

                if ($verify_password_confirmation == true) {
                    // Compare passwords
                    if ($new_password != $new_password_confirm) {
                        $form->log_error_and_exit($this->name, __($note_passwords_do_not_match, 'bricksforge'));
                    }
                }

                if ($strong_passwords) {
                    $password_strength = $forms_helper->check_password_strength($new_password);
                    if ($password_strength['score'] < 3) {
                        $form->log_error_and_exit($this->name, implode(" ", $password_strength['reasons']));
                    }
                }

                // SECURITY: decide *whose* password this submission may change
                // before anything is written. The submitted email address is
                // not proof of identity, so it can never be the only input
                // into that decision. See authorize_update().
                $authorization = $this->authorize_update($form, $user, $email, $form_settings);

                $user = $authorization['user'];

                // A valid password reset key already proves control over the
                // account's mailbox, which is strictly stronger evidence than
                // knowing the current password — and the whole point of that
                // flow is that the current password is unknown. So the
                // current-password check only applies to the other paths.
                if ($verify_current_password == true && !$authorization['ownership_proven']) {
                    if (!wp_check_password($current_password, $user->data->user_pass, $user->ID)) {
                        $form->log_error_and_exit($this->name, __($note_current_password_incorrect, 'bricksforge'));
                    }
                }

                $this->reset_password($new_password, $user->ID, $authorization['auto_login']);

                break;
            default:
                break;
        }

        $form->set_result(
            [
                'action'         => $this->name,
                'type'           => 'success'
            ]
        );
    }

    /**
     * Determine which account this submission is allowed to change.
     *
     * SECURITY: until 3.1.8.8 the target account was taken straight from the
     * submitted email address and the password was written without any check
     * that the requester owned that account. Because /form_submit is reachable
     * by anonymous visitors, that allowed anyone to set the password of any
     * account — administrators included.
     *
     * A submission may now only change a password when one of these holds:
     *
     *   0. The account was created by this very submission, i.e. the form also
     *      runs the Registration action.
     *   1. It carries a valid WordPress password reset key for the account.
     *      That proves control over the account's mailbox.
     *   2. It comes from a logged-in user changing their own password.
     *   3. It comes from a logged-in user who is allowed to edit the target
     *      account, e.g. an administrator using a back-office form.
     *
     * Anything else is rejected with a deliberately generic message so the
     * form cannot be used to probe which email addresses have accounts.
     *
     * @param object   $form           The form instance.
     * @param \WP_User|false $requested_user User resolved from the submitted email.
     * @param string   $email          The submitted email address, if any.
     * @param array    $form_settings  The form settings.
     * @return array{user: \WP_User, auto_login: bool, ownership_proven: bool}
     */
    private function authorize_update($form, $requested_user, $email, $form_settings)
    {
        $note_not_allowed = isset($form_settings['resetUserPasswordNotificationNotAllowed']) && $form_settings['resetUserPasswordNotificationNotAllowed']
            ? $form_settings['resetUserPasswordNotificationNotAllowed']
            : "You are not allowed to change the password for this account.";

        // 0. The account was created by this very submission (Registration
        // action running before this one). Nothing to authorize — the
        // submission owns that account. Note that registration only sets the
        // live user ID after a successful insert, so a registration that
        // failed because the email already exists cannot reach this branch.
        $live_user_id = $form->get_live_user_id();

        if ($live_user_id && (!$requested_user || (int) $requested_user->ID === (int) $live_user_id)) {
            $live_user = get_user_by('id', $live_user_id);

            if ($live_user) {
                return [
                    'user'          => $live_user,
                    'auto_login'    => true,
                    'ownership_proven' => true,
                ];
            }
        }

        // 1. Password reset key
        $reset_key_user = $this->get_user_by_reset_key($form, $form_settings);

        if ($reset_key_user) {
            // If the form also collects an email address it has to match the
            // account the key was issued for, otherwise the submission is
            // internally inconsistent and we refuse it.
            if ($requested_user && (int) $requested_user->ID !== (int) $reset_key_user->ID) {
                $form->log_error_and_exit($this->name, __($note_not_allowed, 'bricksforge'));
            }

            return [
                'user'          => $reset_key_user,
                'auto_login'    => true,
                'ownership_proven' => true,
            ];
        }

        // When the form targets an account by email (an email field is
        // configured) but nobody resolved — a typo, a blank field, or an
        // address with no account — and no stronger proof (registration above,
        // reset key above) applied, this must be an error. Falling through to
        // the logged-in branch would silently reset the visitor's own password
        // instead of the account they typed, which is surprising and was easy
        // to trigger by accident. A form with no email field is a genuine
        // self-service "change my own password" form and is left to the
        // logged-in branch below.
        $targets_by_email = !empty($form_settings['resetUserPasswordEmail']);

        if (!$requested_user && $targets_by_email) {
            $form->log_error_and_exit($this->name, __("User not found", 'bricksforge'));
        }

        $current_user_id = get_current_user_id();

        if ($current_user_id) {
            // 2. Logged-in user changing their own password. Also covers forms
            // that do not collect an email address at all.
            if (!$requested_user || (int) $requested_user->ID === (int) $current_user_id) {
                return [
                    'user'          => wp_get_current_user(),
                    'auto_login'    => true,
                    'ownership_proven' => false,
                ];
            }

            // 3. Logged-in user acting on somebody else's account.
            if (current_user_can('edit_user', $requested_user->ID)) {
                return [
                    'user'          => $requested_user,
                    'auto_login'    => false,
                    'ownership_proven' => false,
                ];
            }
        }

        $form->log_error_and_exit($this->name, __($note_not_allowed, 'bricksforge'));
    }

    /**
     * Resolve the account a valid WordPress password reset key was issued for.
     *
     * The key itself is the security boundary here: check_password_reset_key()
     * verifies it against the hash stored on the user and honours its
     * expiry, so it cannot be guessed or replayed after use. That is why it is
     * safe to read the key from whichever transport the reset page happens to
     * use — a forged value simply fails the check.
     *
     * @return \WP_User|null
     */
    private function get_user_by_reset_key($form, $form_settings)
    {
        $key_field   = isset($form_settings['resetUserPasswordResetKey']) ? $form_settings['resetUserPasswordResetKey'] : null;
        $login_field = isset($form_settings['resetUserPasswordResetLogin']) ? $form_settings['resetUserPasswordResetLogin'] : null;

        $key   = $key_field ? $form->get_form_field_by_id($key_field) : null;
        $login = $login_field ? $form->get_form_field_by_id($login_field) : null;

        if (!$key || !$login) {
            $fallback = $this->get_reset_key_from_request();

            $key   = $key ? $key : $fallback['key'];
            $login = $login ? $login : $fallback['login'];
        }

        if (!$key || !$login) {
            return null;
        }

        $user = check_password_reset_key($key, $login);

        // An invalid or expired key is not an error in itself — it just means
        // this submission carries no proof, so the caller falls through to the
        // logged-in-user checks.
        return is_wp_error($user) ? null : $user;
    }

    /**
     * Pick up "key" and "login" from the places a reset page may carry them,
     * so existing reset pages keep working without extra configuration.
     *
     * @return array{key: string|null, login: string|null}
     */
    private function get_reset_key_from_request()
    {
        $result = ['key' => null, 'login' => null];

        // a) Submitted directly with the form / present on the request.
        foreach (['key', 'login'] as $param) {
            if (isset($_POST[$param]) && is_string($_POST[$param])) {
                $result[$param] = sanitize_text_field(wp_unslash($_POST[$param]));
            } elseif (isset($_GET[$param]) && is_string($_GET[$param])) {
                $result[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
            }
        }

        if ($result['key'] && $result['login']) {
            return $result;
        }

        // b) The cookie WordPress sets when a user follows a reset link.
        if (defined('COOKIEHASH') && isset($_COOKIE['wp-resetpass-' . COOKIEHASH]) && is_string($_COOKIE['wp-resetpass-' . COOKIEHASH])) {
            $cookie = wp_unslash($_COOKIE['wp-resetpass-' . COOKIEHASH]);
            $parts  = array_pad(explode(':', $cookie, 2), 2, '');

            if ($parts[0] && $parts[1]) {
                $result['login'] = $result['login'] ? $result['login'] : sanitize_text_field($parts[0]);
                $result['key']   = $result['key'] ? $result['key'] : sanitize_text_field($parts[1]);
            }
        }

        if ($result['key'] && $result['login']) {
            return $result;
        }

        // c) The page the form was submitted from, e.g. /reset/?key=…&login=…
        $referer = wp_get_referer();

        if ($referer) {
            $query = parse_url($referer, PHP_URL_QUERY);

            if ($query) {
                $params = [];
                parse_str($query, $params);

                foreach (['key', 'login'] as $param) {
                    if (!$result[$param] && isset($params[$param]) && is_string($params[$param])) {
                        $result[$param] = sanitize_text_field($params[$param]);
                    }
                }
            }
        }

        return $result;
    }

    private function reset_password($new_password, $user_id, $auto_login = true)
    {
        wp_set_password($new_password, $user_id);

        /**
         * Filters whether the account is signed in right after its password
         * changed.
         *
         * This is on for a user changing their own password (wp_set_password()
         * invalidates the current session, so without it they would be logged
         * out). It is off when somebody changes *another* user's password —
         * handing the editor that user's session would be an account takeover.
         *
         * @param bool $auto_login
         * @param int  $user_id
         */
        $auto_login = apply_filters('bricksforge/pro_forms/reset_user_password/auto_login', $auto_login, $user_id);

        if ($auto_login) {
            wp_set_auth_cookie($user_id);
        }
    }
}
