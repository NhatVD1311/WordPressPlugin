<?php

namespace Bricksforge\ProForms\Actions;

class Update_User
{
    public $name = "update_user";

    public function run($form)
    {

        $form_settings = $form->get_settings();
        $form_fields = $form->get_fields();

        $to_change = [];

        $user_id = isset($form_settings['updateUserId']) ? $form->get_form_field_by_id($form_settings['updateUserId']) : '';

        // If there is no user id, we can't update the user
        if (!$user_id) {
            $form->set_result(
                [
                    'action' => $this->name,
                    'type'   => 'error',
                    'message' => __('User ID is required', 'bricksforge'),
                ]
            );
            return;
        }

        $user_email = isset($form_settings['updateUserEmail']) ? $form->get_form_field_by_id($form_settings['updateUserEmail']) : '';

        // SECURITY: the user ID is resolved from a form field, so it is fully
        // attacker-controlled, and /form_submit is reachable anonymously. The
        // ownership check therefore cannot stay an opt-in setting — changing
        // an account's email address is enough to take it over through the
        // regular WordPress password reset.
        //
        // Allowed: the account created by this very submission, the visitor's
        // own account, or an account the logged-in visitor may edit anyway.
        $live_user_id    = $form->get_live_user_id();
        $current_user_id = get_current_user_id();

        $is_live_user = $form->is_live_id(isset($form_settings['updateUserId']) ? $form_settings['updateUserId'] : null)
            && $live_user_id
            && (int) $user_id === (int) $live_user_id;

        // Existing setting, now an *additional* restriction on top of the
        // baseline check: when enabled, the visitor may only ever touch their
        // own account, even if they could edit others.
        $only_if_logged_in_user = isset($form_settings['updateUserOnlyIfLoggedInUser']) ? $form_settings['updateUserOnlyIfLoggedInUser'] : false;

        if ($only_if_logged_in_user && (int) $user_id !== (int) $current_user_id) {
            $form->set_result(
                [
                    'action' => $this->name,
                    'type'   => 'error',
                    'message' => __('User ID is not the logged in user', 'bricksforge'),
                ]
            );
            return;
        }

        if (!$is_live_user && (int) $user_id !== (int) $current_user_id) {
            if (!$current_user_id || !current_user_can('edit_user', absint($user_id))) {
                $form->set_result(
                    [
                        'action' => $this->name,
                        'type'   => 'error',
                        'message' => __('You are not allowed to update this user', 'bricksforge'),
                    ]
                );
                return;
            }
        }

        if ($user_email) {
            $to_change["user_email"] = $user_email;
        }

        // We loop through the to_change array and update the user
        foreach ($to_change as $key => $value) {
            wp_update_user(array('ID' => $user_id, $key => $value));
        }

        // Action: bricksforge/pro_forms/user_updated
        do_action('bricksforge/pro_forms/user_updated', $user_id, $to_change);

        $form->set_result(
            [
                'action' => $this->name,
                'type'   => 'success',
            ]
        );
    }
}
