<?php

namespace Bricks;

use \Bricksforge\ProForms\Helper as Helper;
use \Bricksforge\ProForms\Honeypot as HoneypotHelper;

if (!defined('ABSPATH'))
    exit;

require_once __DIR__ . '/../Honeypot.php';

class Brf_Pro_Forms_Honeypot extends \Bricks\Element
{

    public $category = 'bricksforge forms';
    public $name = 'brf-pro-forms-field-honeypot';
    public $icon = 'fa-solid fa-user-ninja';
    public $css_selector = '';
    public $scripts = [];
    public $nestable = false;

    public function get_label()
    {
        return esc_html__("Honeypot", 'bricksforge');
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script('bricksforge-elements');
    }

    public function set_control_groups()
    {
        $this->control_groups['general'] = [
            'title'    => esc_html__('General', 'bricksforge'),
            'tab'      => 'content',
        ];
    }

    public function set_controls()
    {
        // Honeypot Info
        $this->controls['honeypotInfo'] = [
            'group' => 'general',
            'type' => 'info',
            'content' => esc_html__('This field is hidden from users and is used to prevent spam. Just place it somewhere in your form. Leave the settings below untouched to keep the default behavior.', 'bricksforge'),
        ];

        // Field Name (name and id attribute)
        $this->controls['fieldName'] = [
            'group' => 'general',
            'label' => esc_html__('Field Name', 'bricksforge'),
            'description' => esc_html__('Used as the name and id attribute of the input. Choose something that blends in with your other fields. Must not collide with the name of a real field.', 'bricksforge'),
            'type' => 'text',
            'inline' => true,
            'spellcheck' => false,
            'placeholder' => HoneypotHelper::DEFAULT_FIELD_NAME,
        ];

        // Label
        $this->controls['label'] = [
            'group' => 'general',
            'label' => esc_html__('Label', 'bricksforge'),
            'type' => 'text',
            'inline' => true,
            'hasDynamicData' => true,
            'placeholder' => HoneypotHelper::DEFAULT_LABEL,
        ];

        // Input Type
        $this->controls['inputType'] = [
            'group' => 'general',
            'label' => esc_html__('Input Type', 'bricksforge'),
            'description' => esc_html__('Any value entered into this field marks the submission as spam, no matter which type you choose.', 'bricksforge'),
            'type' => 'select',
            'inline' => true,
            'options' => HoneypotHelper::get_input_types(),
            'placeholder' => HoneypotHelper::DEFAULT_INPUT_TYPE,
        ];

        // Wrapper Classes
        $this->controls['wrapperCssClass'] = [
            'group' => 'general',
            'label' => esc_html__('Wrapper Classes', 'bricksforge'),
            'description' => esc_html__('Additional classes for the wrapping element, separated by spaces.', 'bricksforge'),
            'type' => 'text',
            'inline' => true,
            'spellcheck' => false,
        ];

        // Field Classes
        $this->controls['cssClass'] = [
            'group' => 'general',
            'label' => esc_html__('Field Classes', 'bricksforge'),
            'description' => esc_html__('Additional classes for the input itself, separated by spaces.', 'bricksforge'),
            'type' => 'text',
            'inline' => true,
            'spellcheck' => false,
        ];

        // Remove Default Classes
        $this->controls['removeDefaultClasses'] = [
            'group' => 'general',
            'label' => esc_html__('Remove Default Classes', 'bricksforge'),
            'description' => esc_html__('Removes the default classes and the inline hiding of the input. The field is then visible until you hide it yourself, for example with one of the classes above.', 'bricksforge'),
            'type' => 'checkbox',
            'default' => false,
        ];
    }

    public function render()
    {
        $settings = $this->settings;

        $field_name = HoneypotHelper::get_field_name($settings);
        $input_type = HoneypotHelper::get_input_type($settings);
        $remove_default_classes = !empty($settings['removeDefaultClasses']);

        $label = isset($settings['label']) && $settings['label'] !== ''
            ? bricks_render_dynamic_data($settings['label'])
            : HoneypotHelper::DEFAULT_LABEL;

        /**
         * Wrapper
         */
        if (!$remove_default_classes) {
            $this->set_attribute('_root', 'class', ['pro-forms-builder-field', 'brf-visually-hidden']);
            $this->set_attribute('_root', 'class', 'form-group');
        }

        if (!empty($settings['wrapperCssClass'])) {
            $this->set_attribute('_root', 'class', $settings['wrapperCssClass']);
        }

        /**
         * Field
         */
        $this->set_attribute('field', 'type', $input_type);
        $this->set_attribute('field', 'name', $field_name);
        Helper::apply_aria_label($this);
        $this->set_attribute('field', 'id', $field_name);

        // Radios and checkboxes only submit a value once they are checked, so they
        // carry one. Free text types have to start out empty to work as a honeypot.
        if (in_array($input_type, ['radio', 'checkbox'], true)) {
            $this->set_attribute('field', 'value', '1');
        }

        // Keep the field out of the tab order and away from browser autofill, so
        // that no real visitor ever fills it by accident.
        $this->set_attribute('field', 'tabindex', '-1');
        $this->set_attribute('field', 'autocomplete', 'off');

        if (!empty($settings['cssClass'])) {
            $this->set_attribute('field', 'class', $settings['cssClass']);
        }

        if (!$remove_default_classes) {
            $this->set_attribute('field', 'style', 'display: none');
        }

?>
        <div <?php echo $this->render_attributes('_root'); ?>>
            <label for="<?php echo esc_attr($field_name); ?>" aria-hidden="true">
                <?php echo esc_html($label); ?>
                <input <?php echo $this->render_attributes('field'); ?>>
            </label>
        </div>
<?php
    }
}
