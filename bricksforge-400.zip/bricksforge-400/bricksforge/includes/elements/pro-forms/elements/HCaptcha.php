<?php

namespace Bricks;

if (!defined('ABSPATH'))
    exit;

class Brf_Pro_Forms_HCaptcha extends \Bricks\Element
{

    public $category = 'bricksforge forms';
    public $name = 'brf-pro-forms-field-hcaptcha';
    public $icon = 'fa-solid fa-shield-halved';
    public $css_selector = '';
    public $scripts = [];
    public $nestable = true;
    private $hcaptcha_key;
    private $hcaptcha_secret;

    public function get_label()
    {
        return esc_html__("hCaptcha", 'bricksforge');
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script('bricksforge-elements');
        wp_enqueue_script('bricksforge-hcaptcha');
    }

    public function set_control_groups()
    {
        $this->control_groups['general'] = [
            'title'    => esc_html__('General', 'bricksforge'),
            'tab'      => 'content',
        ];
    }

    public function set_controls()
    {
        if ($this->check_for_hcaptcha_keys()[0] === true) {
            $this->controls['enableHCaptcha'] = [
                'tab'      => 'content',
                'group'    => 'general',
                'label'    => esc_html__('Enable hCaptcha', 'bricksforge'),
                'type'     => 'checkbox',
                'default'  => true
            ];

            $this->controls['hCaptchaTheme'] = [
                'tab'      => 'content',
                'group'    => 'general',
                'label'    => esc_html__('Theme', 'bricksforge'),
                'type'     => 'select',
                'options'  => [
                    'light' => esc_html__('Light', 'bricksforge'),
                    'dark'  => esc_html__('Dark', 'bricksforge'),
                ],
                'default'  => 'light',
                'required' => ['enableHCaptcha', '=', true],
            ];

            $this->controls['hCaptchaInfoMessage'] = [
                'tab'      => 'content',
                'group'    => 'general',
                'label'    => esc_html__('Info Message', 'bricksforge'),
                'type'     => 'text',
                'required' => ['enableHCaptcha', '=', true],
                'description' => esc_html__('Optional info message displayed below the hCaptcha.', 'bricksforge'),
            ];
        } else {
            $this->controls['hcaptchaInfo'] = [
                'tab'      => 'content',
                'content'  => '<a href="https://www.hcaptcha.com/" target="_blank">hCaptcha</a> ' . esc_html__('API key required! Add your key under Bricksforge -> Elements -> Pro Forms, or in the Bricks settings under Settings -> API Keys.', 'bricksforge'),
                'type'     => 'info',
            ];
        }
    }

    public function check_for_hcaptcha_keys()
    {
        $settings = \Bricksforge\ProForms\Helper::get_pro_forms_settings();

        if (!isset($settings->useHCaptcha) || $settings->useHCaptcha !== true) {
            return [false];
        }

        // Falls back to the Bricks settings when no Bricksforge keys are stored.
        list($hcaptcha_key, $hcaptcha_secret) = \Bricksforge\ProForms\Helper::get_hcaptcha_keys();

        if (empty($hcaptcha_key) || empty($hcaptcha_secret)) {
            return [false];
        }

        $this->hcaptcha_key = $hcaptcha_key;
        $this->hcaptcha_secret = $hcaptcha_secret;

        return [true, $hcaptcha_key, $hcaptcha_secret];
    }

    public function render()
    {
        $settings = $this->settings;

        // Only render if element is enabled and we have API keys
        if (!isset($settings['enableHCaptcha']) || !$settings['enableHCaptcha'] || $this->check_for_hcaptcha_keys()[0] !== true) {
            return;
        }

        /**
         * Wrapper
         */
        $this->set_attribute('_root', 'class', 'brf-hcaptcha-wrapper form-group');

        $output = '<div ' . $this->render_attributes('_root') . '>';

        $hcaptcha_theme = isset($settings['hCaptchaTheme']) && $settings['hCaptchaTheme'] === 'dark' ? 'dark' : 'light';

        $output .= '<div class="h-captcha" 
                        data-sitekey="' . $this->hcaptcha_key . '"
                        data-theme="' . $hcaptcha_theme . '"';

        if (isset($settings['hCaptchaInfoMessage']) && !empty($settings['hCaptchaInfoMessage'])) {
            $output .= ' data-info="' . esc_attr($settings['hCaptchaInfoMessage']) . '"';
        }

        $output .= '></div>';
        $output .= '</div>';

        echo $output;
    }
}
