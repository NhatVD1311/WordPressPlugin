<?php

namespace Bricksforge\ProForms;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shared knowledge about the Pro Forms honeypot field.
 *
 * The element renders the field, the submit handler has to recognize it again in
 * the posted data. Both sides read the same settings through this class, so a
 * honeypot that was renamed in the builder stays detectable on the server.
 */
class Honeypot
{
    /**
     * Bricks element name of the honeypot field.
     */
    const ELEMENT_NAME = 'brf-pro-forms-field-honeypot';

    /**
     * Element name as it appears in a form structure built by
     * FormsHelper::build_form_structure(), which strips the field prefix.
     */
    const STRUCTURE_NAME = 'honeypot';

    /**
     * Name and id of honeypots placed before the field became configurable.
     * Those forms carry no settings at all, so this stays the fallback and is
     * always part of the server side check.
     */
    const DEFAULT_FIELD_NAME = 'form-field-guardian42';

    const DEFAULT_LABEL = 'Guardian';

    const DEFAULT_INPUT_TYPE = 'radio';

    /**
     * Input types the honeypot can be rendered as.
     *
     * @return array
     */
    public static function get_input_types()
    {
        return [
            'radio'    => esc_html__('Radio', 'bricksforge'),
            'checkbox' => esc_html__('Checkbox', 'bricksforge'),
            'text'     => esc_html__('Text', 'bricksforge'),
            'email'    => esc_html__('Email', 'bricksforge'),
            'tel'      => esc_html__('Phone', 'bricksforge'),
            'url'      => esc_html__('URL', 'bricksforge'),
        ];
    }

    /**
     * @param array $settings Settings of a honeypot element.
     *
     * @return string
     */
    public static function get_input_type($settings = [])
    {
        $type = isset($settings['inputType']) ? $settings['inputType'] : '';

        return array_key_exists($type, self::get_input_types()) ? $type : self::DEFAULT_INPUT_TYPE;
    }

    /**
     * Name and id attribute of the rendered input, and with that the key the
     * value arrives under in the submitted form data.
     *
     * @param array $settings Settings of a honeypot element.
     *
     * @return string
     */
    public static function get_field_name($settings = [])
    {
        $name = isset($settings['fieldName']) ? trim((string) $settings['fieldName']) : '';

        // Keep the value usable as an HTML name and id attribute.
        $name = preg_replace('/[^A-Za-z0-9_\-.]/', '', $name);

        return $name === '' ? self::DEFAULT_FIELD_NAME : $name;
    }

    /**
     * Field names of every honeypot inside a form structure as built by
     * FormsHelper::build_form_structure().
     *
     * Empty when the form has no honeypot, but also when its structure could not
     * be resolved at all. The caller has to fall back to DEFAULT_FIELD_NAME in
     * that case, so forms built before the field became configurable keep the
     * protection they always had.
     *
     * @param array $form_structure
     *
     * @return array
     */
    public static function get_field_names($form_structure = [])
    {
        $names = [];

        self::collect_field_names($form_structure, $names);

        return array_values(array_unique($names));
    }

    /**
     * @param array $fields
     * @param array $names
     */
    private static function collect_field_names($fields, &$names)
    {
        if (!is_array($fields)) {
            return;
        }

        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }

            if (isset($field['name']) && $field['name'] === self::STRUCTURE_NAME) {
                $names[] = self::get_field_name(isset($field['settings']) ? $field['settings'] : []);
            }

            if (!empty($field['children'])) {
                self::collect_field_names($field['children'], $names);
            }
        }
    }

    /**
     * A honeypot is only ever filled by something that is not a human visitor,
     * so any value counts no matter which input type the field was rendered as.
     *
     * Unchecked checkboxes are submitted as "0" by the form script, which is why
     * that value has to pass as empty.
     *
     * @param mixed $value
     *
     * @return bool
     */
    public static function is_filled($value)
    {
        if (is_array($value)) {
            foreach ($value as $single) {
                if (self::is_filled($single)) {
                    return true;
                }
            }

            return false;
        }

        if (is_bool($value) || is_null($value)) {
            return (bool) $value;
        }

        $value = strtolower(trim((string) $value));

        return $value !== '' && $value !== '0' && $value !== 'false';
    }
}
