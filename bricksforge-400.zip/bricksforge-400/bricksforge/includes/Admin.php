<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Pages Handler
 */
class Admin
{

    public function __construct()
    {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_menu', [$this, 'capture_admin_menu_snapshot'], PHP_INT_MAX);
        add_filter('plugin_action_links_bricksforge/plugin.php', [$this, 'add_plugin_links']);
        wp_enqueue_style('bricksforge-style');
        $this->render_conditionals();
    }

    /**
     * One-time migration for 4.0.0-beta.2: the Builder Customizer (tool 21) and
     * White Label (tool 22) became opt-in tools instead of always-on features.
     * To keep existing installs unchanged, activate each for sites that already
     * have it configured (roles / white-label settings present). Fresh installs
     * stay off. The flag also disables the legacy fallback in is_module_active(),
     * so after this runs the tools are controlled purely by their toggle.
     *
     * @return void
     */
    public function migrate_tool_visibility()
    {
        if (get_option('brf_bcwl_migrated')) {
            return;
        }

        $tools = get_option('brf_activated_tools');
        $tools = is_array($tools) ? $tools : array();

        $roles = get_option('brf_permissions_roles');
        if (is_array($roles) && !empty($roles) && !in_array(21, $tools)) {
            $tools[] = 21;
        }

        $whitelabel = get_option('brf_whitelabel');
        if (is_array($whitelabel) && isset($whitelabel[0]) && !in_array(22, $tools)) {
            $tools[] = 22;
        }

        // Global Classes management is now its own opt-in tool (23), separate
        // from the Global Classes Backups tool (10). Activate it for installs
        // that already use global classes so the menu entry stays.
        $gc_data = get_option('brf_global_classes');
        if ((get_option('brf_global_classes_activated') || (is_array($gc_data) && !empty($gc_data))) && !in_array(23, $tools)) {
            $tools[] = 23;
        }

        update_option('brf_activated_tools', array_values($tools));
        update_option('brf_bcwl_migrated', true);
    }

    public function render_conditionals()
    {

        if (get_option('brf_activated_tools') && in_array(0, get_option('brf_activated_tools'))) {
            wp_enqueue_script('bricksforge-font-uploader');
            add_filter('upload_mimes', [$this, 'upload_mimes']);
        }

        // If the url contains externalApiLoops, we enqueue the papaparse script
        if ($this->is_bricksforge_admin_page()) {
            wp_enqueue_script('bricksforge-papaparse');
        }
    }

    public function is_bricksforge_admin_page()
    {
        return strpos($_SERVER['REQUEST_URI'], 'page=bricksforge') !== false;
    }

    /**
     * Register our menu page
     *
     * @return void
     */
    public function admin_menu()
    {
        global $submenu;

        // Runs before the submenu is built so newly-migrated tool ids are
        // already present on the very first admin load after an upgrade.
        $this->migrate_tool_visibility();

        $capability = 'manage_options';
        $slug = 'bricksforge';

        $whitelabel = get_option('brf_whitelabel');
        $whitelabel = $whitelabel != false && is_array($whitelabel) && isset($whitelabel[0]) ? $whitelabel[0] : false;

        $menu_title = 'Bricksforge';
        if ($whitelabel) {
            if (is_object($whitelabel) && isset($whitelabel->menuTitle) && $whitelabel->menuTitle) {
                $menu_title = $whitelabel->menuTitle;
            } elseif (is_array($whitelabel) && isset($whitelabel['menuTitle']) && $whitelabel['menuTitle']) {
                $menu_title = $whitelabel['menuTitle'];
            }
        }

        // Bricksforge is a top-level menu: every tool with an own UI gets a
        // real, full-width admin page as a submenu entry. The page slug stays
        // "bricksforge", so old links to admin.php?page=bricksforge (e.g.
        // bookmarks or the plugin row "Settings" link) keep working.
        $icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgMTM2IDE0OCI+PGltYWdlIHdpZHRoPSIxMzYiIGhlaWdodD0iMTQ4IiB4bGluazpocmVmPSJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUlnQUFBQ1VDQVlBQUFCSXJtR3lBQUFOZUVsRVFWUjQydTJkZTVBVTFSWEdmOTBMYkM4cU0yTjYxVlNaVkNvaUZRcUJaVjBzWXhLMWtoaEJnMFlGQ1Q1U0VUVWF0RFNKRlUxS3dJaXYrSW9tSmI1aTFBeVBVaFJOcGZBZDR4TUlyd213dkJUVWFFQ0RZbWFHUUhmUE1ydWRQN3FYblIxbTlqSGJNOVBkYzc2cUxtcnBudTdiNTM1OXpybm4zbnVPWXRzMkFrRXhEQUt3VmtaQktYQldLZndqdTlpSklyOXZPRFk1R3pnUnVOTmNFM3VwcDN2M2NzcGI1RDlJc1l0Y1kzdjduUDYrWTg3RjlhUFRYd2R1QkRZQzEyWmFJL3RLYVkvZGgrZHBvOUlvdG0yWGpTQU5MY2tmdUM4ekp1ZS9Gd0d6ekVUc1hTRkkzMzlmUHpyOVJXQU9jRW5PbVErQTMyUmFJL0ZBRWFTaEpYa004RnZnZElyZEF1NEFiallUc1QxQ2tPS29INU5XZ2V1QTY0R0RpbHoySnZDclRHdGt1ZGNFVWIyVWQwTkxNdHJRa3J3YmFPMkJISjFOdUE3WTJ0Q2N2RmdzZlZGeVRBSGVBVzd0Z1J5NDVudFovZWowSS9XajAwZDYrZzE1cFVFYVdwSlhBYk1BdllSMkxBTm1tb25ZYTZKQm9INU0rbGpnWm1CQ0NVOHpYVUxka21tTjJGVTNNUTB0eWJPQTJVQ1RCMTMySkRESFNzUTIxU0pCNnNla2ozUmxlYWtIYi9jZWNGT21OZkxucWhDa29TVTV6bVg1YVdYb3VqdGRvdXlwQllLNGZzYXZYVCtqd2VPM2ZBdVltV21OdkZrUkgwUnJTVFUydENUdkF4SmxJZ2ZBTDRGdFduUHk4aHJ3TTZZQjc3b2ZXME1aSHZFdDRJMzYwZWw1OWFQVFh5bXJENksxcEs1MmgxckRLaWpEMWNCTUsrSEdUMEtpUWJReDZST0FtNEJ2VjFDV1diZi9ick0yUkxLZW1SaXRKWFdHZStPeFZmellublNKc2kzSUJOSEdwSTl3WlhscEZXWDVQbkNEdFNFeWYwQUUwY2FuV2x5bmFaSlBOSElIY0Rkd3M1V0k3UTRTUWJReDZUclh6N2dPT05nbjhud2RtR050aUx6V0w0Sm80MU02VGdSMGhrOU45NmV1RXpzM0NBVFJ4cVl2Qkc0QWp2S3BQQmNBczZ3TmtROTZKWWcyUG5XTkc4K0lCTURIU3dEWFc0bllpMzRraURZMmZZSWJremdwQUxMTUFyY0J0MW9iSTFaM2dpUWlhTTNwczExUGVtUUFCd09MZ2RuVzZuN0dUMVQzc0lzUXhBYnFiQmpjUDRKb0kzZC8yZFVZMHdNb3krM0FMS3MxOHJnMjJpVUk4QlF3T1FTanhzdXRUWkdIc1BzUWkxVnQyS2RBVnVuU0pQa0VxYlBCVUxIM3FDaUQrK1loYVNkL1BobVlCMmdCbCtVU1lOSWc5NC9KT2QrTUVyQVhzWE9Nd1ZrMDJBL1IyeG9YRmVoUW9LMFByenJZaHY4T3hzNG9NTVR1UzB0T0N3RTVBRTRGZHoySTYvUWRWa0RnUVNCSExxay9KcXYwemUvWXE4QStvSzRucTZ5QTFvSHlwVGJzajRiQTRJNitTR1ZuRWZJRzBkUWNFRWxWY2w3R0h2ajRydXpFNkh3SHBlc0Y3T0tIYmFPb05tU0FqRUt2Y1dRRmFGTmhXQlppV2Npby9lMXFKYURrNktac2Uzc3gyNmZFNkwvd1ZUZVNZcWw1dE9vRjdRcEtZeGJxT3h5L0pkQmQ3ZzFCOGhWeXRiVkozNGxoSzhVUEJUQlZhTzhudGJJSzFIYzRKTm5ua3N3dWN0UVlRZnhnZG14UEZwdXBRSnZpT0p0cUNmR1NOaFZpN1JCdEJ5dlFXcVJmZlRpb2hMQ1NYU0hucTZSbjJEMmR5S2lsdDdyRC9lbmhXZXk5cXFOSkJnVkdhNVQ4a2FrbHhoL0w2Wjk0VDBEVmRyNzZiSWx2dkYrTEtOQmd1NlpHQ1FJNTdCeURXSkxEckE1d0prUHgyT3pZQS9iKzgzMENCYWN6MnhRR3ZBSlh3ZEVjWDJpSFF6b2MwdmtYdWNSUUI3UXZ4Z094RGZTcjkwNWoyQVZhMXFiMEdnTFV4aVcvQnZ6Qi9mTXFhMjEwUzdFUkRYVTJ5aEZaN0wyREhZZTN6bGZFYU05NSt3RXZTbGM5WEZsUmlqYXh1Nnk3Uitha20vYXdvYzNWSUdwUllnelR4aVh2QURZRHA3akhacTBwZFlmV2xCcFdXSXNvY0hBN3ltSHRmWXZHVm80WSs5dzNWNzNxV3hYdlIwVjlJVXJSUUJkZUxnWnFWNXpSUjNGeVhBMXN3MW5pU01GbGowMnBxd3YrZUo4Q2pWazRxTU1oWVhXSjBlWithSFd1VlZBcU9jd2R5RVI2UGxGc1QveU12aTJtZEw3dWpvTEVtS0NOU3lhQWU0SEdIdTdTQ055ck5hVVNXbE5xd29HbUJzZlVkQ2pZN1ZEaGJjNGRPREhoemdtRHdlWG9UNVh5cmhsWEtrNk1YRE9RWjFxMDV1UW9yVG41TlBBQ01LNGZkeHdIdktBMXBaN1dtbEtqdWowajBvR2laNTNRdlZMUnRSdVcyd3F0bkY2UVNtVjJuM1Q2R2tyRnZxMGMwNkkxSncvUm1wTjNBUnVBY3dadzUzT0FEVnBUNmk2dEtYVUlIVTVYS1lkblVScHNsRXhGTlVnOU1BUWZSRkxMdFVTNGZFUC9mVjJtUld0T3puRDlqR3M4Zk1nMXdEWnRYR29HV1FXR09LYW1rRGtyRStvcTFYY3E0WUpDMWxrRXBMVWt6OUNhazJ1QnVYUXRaZkFTaHdGenRYR3B0ZHJJOUprYzJnNkh0bGZxUTZqWWxNZWdrQkZraCtha1NYaUl5cTNFSHd2OFJSdVpYc0pJcGdNZmh1cUxjNWNjN2l6VFY1WTNrMUYyamZVK2NEZzk3NFF2SjFJNEMyMk9xWUNYVlc1NWZnQjhOV3dhNUt0VmZuN1VQYWlsNlg1QkRVTUlJaENDQ0lRZ0FpR0lRQWdpRUlJSWhDQUNJWWhBQ0NMQXJ4Tm9WRHFadjZES203cUVJS0hXRm1yb3k0RUlLR1VtTmZBNzk0VWdlTDU2M05NdEJVS1E4QkNqY3oxdEhUV1YvRUVJMHBzcHllYklTYTNaa21TQ0F4elFOdmZmUWJVdUl5Rkk0YzFJS3VGSVJDY0V3ZnV0R1ZxdCtSbENFTi90M1VGQzdRSWhpRUFJSWhDQ0NBUkNFSUVRUkNBRUVRaEJCRUlRZ1JCRUlBUVJDRUVFQWlHSVFBZ2lvUFRGMlVJUUFUMHRCVkZsSFlTZ0NBN05KVWlIeUVQUWs0a3hSUjZDUEdSeUNiSlg1Q0hJZzVWTGtMVElRNUNIUGJrRStWemtJY2pELzNJSjhySElRNUNIejNNSnNsM2tJY2pEaDdrRStVVGtJY2pEdi95a1FVS1p2aW5nMkpGTGtNMVZyZ3d0OEIvZTMwOFFZMEhqUjFVb2hKT2JkNk1tc3ZVUXJDQlphNWNHY1lvS3JhY3lNOGRabkZLZVVJTUpXUUtDZGRibXlKNzgyZHh5bTVrMmw1bWRCWURycEI5OGl3MFUyTjIvdE16YXc2YXJNclJnWUg1YnViWHU2a0lFZWQxVi80UEtXT2VWdkFMTGd0THlzcFpiZHE4Y3NLTE1tSy92emxVdGxEOEhod3hyU3lOR3VjbXh3OW9jMlZac3llSExWRFpSaThRLy9CY2ZlaTMzcWZrRWVZYktadk1Sb3ZoRGErUmk4WUZEejY3dVdRa2txWHphSnlIS2dWcWpHckVoTzlmL09FQ0RHUE4wRzFoRTlmS0QxYkovVWsxaWRHS0p0U215dDdkdEQwOVEvVVJ5U2cxcEU5dEhJN3NGKzF0VHhBZkJtS2UvamovV2g0VGQ3TmhWOURNS3dRRCtTaDgzVHNYeFQxcktNR29UMjRjVkk1NnlOa2JNdmhMa1B2eTNBekJNZ1RVL1RrN2VXM3dDemU1K0dIRjlSd1ZqSW9McVk3MjFNYksydjN0emJ4UzUxUXptOUh2enRoSFhsd0diUkhhaHgzK3NqWkhGcGU3dXYxYmtGM3JNS2puOWd4SFhud08yaUF4RGk1M1d4c2dqQTgwUGNvWElNYlQ0UmY0QXBkZEFXUUV0OG5kZ2hjZ3lkSGd2MHhwWnFOaFE3T2hQQXBtTFJKNmh3MFdlcGFBeTR2cG00RkdSYVdqd2ZLWTE4cGJYT2NvdUIzYUxiQWxEWXBnTDhEcUpuUkhYOXdFL0Z2a0dIbGRrV2lQSnNtUTVOT0w2czhEekl1UEFZbVdtTmZJZ1pVNkRPUm5KU0JSVVRPcHhXRnZLTUxlQUZqR0JNMFhXZ2NPMHpQcklwMVFpa2E0UjExOEZiaEtaQndZUFp0WkhucWhvcG1VanJzOG1iNEdyd0pkWVk2MlAvTFEvbGlWM2RkWkFNeTFQQkQ2U1B2QXRVc0IzcUZhdWRpT3V0d1Bmd00ycEtmQWR2bW10aTZRcFJYM1lIaVh6TitMNmR1QWs2UXZmWVlLMUxySVJQMVI3TU9MNkN1QjA2UlBmNEh4clhmU2w3cmw1U2prOHJQWmd4UFhuZ2JPbGI2cU9pNnkxMFlVbG14V3ZUVXlCU09zNTBrZFZ3M1JyYmZSeC9GeFF5SWpyejRpNXFRcW1XV3VqanhHRWlsT3V1VGxaUmpjVncvZXR0ZEVuQWxXU3pJanJid0JOdU9rVUJXWEJKMENMOWMvWWN3U3hacDBSMTdjQW81QVo0SExnRFdDVWxZaXRJY2hGRFkyNGJobHgvWFRnVnVsVHovQjdLeEU3MlVyRWtxR3BlbW5FOWV1QlNVanBFUVpZdzJXcWxZajlqRENXUlRYaStoSmdKUENzOUhXLzhTSXcwa3JFRm9XNmJxNFIxejh6NHZyWndIVFJKbjNDYm1DR21ZaE5OQk94N1RWVFdObUk2NDhCUndOL0VnNFV4WHhnaExrbTlnQzFXSG5iaU90Skk2NWZnalBaOTVid1lUOVdBS2VZcTJNWG1tdGlPNm4xMHV4R1hIL1RpT3NuNG16bXFlWHFWenVCbjVpclk4ZWJxMk4vd3llWmUzd0RJNjQvN3BxZG0zSEtoZFFTN2dDR1c2dGpmL1JUb3hUYnRqSGl1dStrTmZSSHU0N0NXZmM2TGVURWVCcVlhYTJLdnVQTXNDdmRrN0VwM2Y4dG1MZEtvV3N6cllmUW1sTCswaUI1MlJiZk0rYnA1d0hmRGFsL3NoeVlhSzJNVHJGV1JkL3hheU5WdjB2Um1LZS9hc3pUVHdRdURvbC84Z2x3bWJVeWVvSzFNdnFpM3h1ckJrV3F4ano5VVdBRWNFdUF5WEU3TU1KYUdYMDRLQTMyclE5U05FbWtBa012Mk5YcHlKNGJFRGt2Qm1aYUs2SmJDcjViTno5RGZKQ0JhNVA1K2xaanZqNFYrSjdQazl1c0JpYWFLNktUelU1eUJBeUJKRWdPVVY0eDV1dkhBNWNCLy9aUjB6NEdacGdyb3VQTkZmNzNNMEpMa0J5aVBJd1RQN21WNnFmc3ZoMFlicTZJUGhBRzJRYlNCK2t4Zm5MQnJoR3VmektsQ3ZHTVdlWS9pdmdadWY4bFBraFZ0Y203eG56OVhPQlVZRTBGSHBrQUpwakxvMVBNNWRIUXBRd05IVUZ5aVBLeXNhQ3hCU2VOWnprbXZENEZyalNYUjQ4MWwwZGZDcXNjUTB1US9VUlowSGkvR3orNTB5UC94QWJ1QWthWXk2Tnp3eTYvMFBrZzNhL3RmdkhROHo4N0dtZCtaMnFKclZvRXpEU1h4Ylk2N2JDTHQwOThrRUJxazYzR2dzWWZ1djdKcW43OGRCVndxcmswTnRWY0Z0dGFTektyS1lMa0VPVmxZMkhqY2E1L3NxdUhTM2NCVjVwTFk4ZVpTMk0xV1QrbkpnbXlueWdMRys4SGhnUDNGRGg5RHpEY2ZEczJ0NVpsVkZNK1NFLzNHWHJlWjJPQTM3bG5mbTYrSFZ0ZjhOcHVQa0g0ZlJERnRxWGd0YUE0L2cvR084RnhtZWs2UkFBQUFBQkpSVTVFcmtKZ2dnPT0iLz48L3N2Zz4=';

        $hook = add_menu_page(__($menu_title, 'bricksforge'), __($menu_title, 'bricksforge'), $capability, $slug, [$this, 'plugin_page'], $icon, 24);

        // Bricksforge Admin Page
        add_action('load-' . $hook, [$this, 'init_hooks']);

        // Core sections (hash routes of the settings app)
        add_submenu_page($slug, __('General', 'bricksforge'), __('General', 'bricksforge'), $capability, $slug);
        add_submenu_page($slug, __('Elements', 'bricksforge'), __('Elements', 'bricksforge'), $capability, 'admin.php?page=bricksforge#/elements');
        add_submenu_page($slug, __('Extensions', 'bricksforge'), __('Extensions', 'bricksforge'), $capability, 'admin.php?page=bricksforge#/tools');

        // Tools with an own UI — one entry per activated tool
        $activated_tools = get_option('brf_activated_tools');
        $activated_tools = is_array($activated_tools) ? $activated_tools : array();

        $feature_pages = $this->get_feature_pages();

        foreach ($feature_pages as $feature) {
            if (!in_array($feature['id'], $activated_tools)) {
                continue;
            }

            add_submenu_page($slug, __($feature['label'], 'bricksforge'), __($feature['label'], 'bricksforge'), $capability, 'admin.php?page=bricksforge#/' . $feature['route']);
        }

        add_submenu_page($slug, __('Logs', 'bricksforge'), __('Logs', 'bricksforge'), $capability, 'admin.php?page=bricksforge#/logs');
        add_submenu_page($slug, __('License', 'bricksforge'), __('License', 'bricksforge'), $capability, 'admin.php?page=bricksforge#/license');

        // Submissions if activated
        if (get_option('brf_activated_tools') && in_array(11, get_option('brf_activated_tools'))) {
            add_action('load-bricks_page_brf-form-submissions', [$this, 'init_hooks']);
            add_action('load-toplevel_page_brf-form-submissions', [$this, 'init_hooks']);
        }
    }

    /**
     * Feature tools that get their own submenu entry under "Bricksforge".
     * Single source of truth for both the server-rendered menu (admin_menu)
     * and the client-side live sync (plugin_page).
     *
     * @return array
     */
    private function get_feature_pages()
    {
        return array(
            array('id' => 13, 'label' => 'Email Designer', 'route' => 'emailDesigner'),
            array('id' => 18, 'label' => 'API Query Builder', 'route' => 'apiQueryBuilder'),
            array('id' => 17, 'label' => 'Admin Pages', 'route' => 'adminPages'),
            array('id' => 16, 'label' => 'Page Transitions', 'route' => 'pageTransitions'),
            array('id' => 5, 'label' => 'Popups', 'route' => 'popups'),
            array('id' => 4, 'label' => 'Maintenance Mode', 'route' => 'maintenance'),
            array('id' => 9, 'label' => 'Backend Designer', 'route' => 'backenddesigner'),
            array('id' => 21, 'label' => 'Builder Customizer', 'route' => 'permissions'),
            array('id' => 23, 'label' => 'Global Classes', 'route' => 'global-classes'),
            array('id' => 22, 'label' => 'White Label', 'route' => 'whitelabel'),
        );
    }

    /**
     * Add Plugin Links
     *
     *  @return void
     */
    public function add_plugin_links($links)
    {
        $links = array_merge(
            array(
                '<a style="color: #555; font-weight: 600" href="' . esc_url(admin_url('/admin.php?page=bricksforge')) . '">' . __('Settings', 'bricksforge') . '</a>',
                '<a style="color: #555; font-weight: 600" href="https://forum.bricksforge.io" target="_blank">' . __('Forum', 'bricksforge') . '</a>',
                '<a style="color: #555; font-weight: 600" href="https://bricksforge.io/documentation" target="_blank">' . __('Documentation', 'bricksforge') . '</a>'
            ),
            $links
        );

        return $links;
    }

    /**
     * Initialize our hooks for the admin page
     *
     * @return void
     */
    public function init_hooks()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Load scripts and styles for the app
     *
     * @return void
     */
    public function enqueue_scripts()
    {
        // The Bricksforge admin app (e.g. the Email Designer image picker) relies
        // on the WordPress media library. Enqueue it here so it no longer depends
        // on the White Label tool being active.
        wp_enqueue_media();

        $lk = get_option('brf_settings');
        if ($lk && class_exists('\Bricksforge\Api\Utils')) {
            $utils = new \Bricksforge\Api\Utils();
            $lk = $utils->encrypt($lk);
        }

        global $wp_roles;

        $args = array(
            'siteurl'                   => get_option('siteurl'),
            'ajaxurl'                   => admin_url('admin-ajax.php'),
            'nonce'                     => wp_create_nonce('wp_rest'),
            'pluginurl'                 => BRICKSFORGE_URL,
            'pluginVersion'             => BRICKSFORGE_VERSION,
            'apiurl'                    => get_rest_url() . "bricksforge/v1/",
            'bricksElements'            => \Bricks\Elements::$elements,
            'globalClasses'             => get_option('bricks_global_classes'),
            'globalClassesLocked'       => get_option('bricks_global_classes_locked'),
            'brfGlobalClassesActivated' => get_option('brf_global_classes_activated'),
            'brfActivatedTools'         => get_option('brf_activated_tools'),
            'brfActivatedElements'      => get_option('brf_activated_elements'),
            'breakpoints'               => \Bricks\Breakpoints::$breakpoints,
            'pages'                    => query_posts(["post_type" => ["page", "bricks_template"], 'posts_per_page' => 200]),
            'ptPage'                    => query_posts(["post_type" => "page", 'posts_per_page' => 200]),
            'templates'                 => get_posts(['post_type' => 'bricks_template', 'post_status' => 'publish', 'numberposts' => 200, 'posts_per_page' => 200]),
            'contentTemplates'           => \Bricks\Templates::get_templates([
                "type" => "content"
            ]),
            'popups'                    => get_option('brf_popups'),
            'permissions'               => get_option('brf_permissions_roles'),
            'maintenance'               => get_option('brf_maintenance'),
            'whiteLabel'                => get_option('brf_whitelabel'),
            'panelActivated'            => get_option('brf_activated_tools') && in_array(6, get_option('brf_activated_tools')),
            'animationPanelActivated'   => get_option('brf_activated_tools') && in_array(19, get_option('brf_activated_tools')),
            'nodeEditorActivated'       => get_option('brf_activated_tools') && in_array(20, get_option('brf_activated_tools')),
            'settings'                  => $lk,
            'adminEmail'               => get_option('admin_email'),
            'adminMenu'                 => $this->get_admin_menu_snapshot(),
            'isWoocommerceActive'       => class_exists('WooCommerce'),
            'aiActive'                  => $this->is_ai_ready(),
            'terminalCommands' => get_option('brf_terminal_commands') ? get_option('brf_terminal_commands') : [],
            'locale'                    => get_locale(),
            'userRoles'                 => $wp_roles->roles,
        );

        wp_enqueue_style('bricksforge-admin');
        wp_localize_script('bricksforge-admin', 'BRFVARS', $args);

        wp_enqueue_script('bricksforge-admin');
    }

    /**
     * AI features are only offered when the Bricksforge Assistant (tool 14)
     * is activated AND an API key for the chosen provider is configured.
     */
    private function is_ai_ready()
    {
        $tools = get_option('brf_activated_tools');

        if (!$tools || !in_array(14, $tools)) {
            return false;
        }

        $settings_option = get_option('brf_tool_settings');

        if (!$settings_option) {
            return false;
        }

        $ai_settings = array_values(array_filter($settings_option, function ($tool) {
            $tool = is_array($tool) ? (object) $tool : $tool;
            return isset($tool->id) && $tool->id == 14;
        }));

        if (!count($ai_settings)) {
            return false;
        }

        $tool = is_array($ai_settings[0]) ? json_decode(json_encode($ai_settings[0])) : $ai_settings[0];
        $provider = isset($tool->settings->provider) ? $tool->settings->provider : 'openai';

        if ($provider === 'anthropic') {
            return !empty($tool->settings->anthropicApiKey);
        }

        return !empty($tool->settings->apiKey);
    }

    /**
     * Render our admin page
     *
     * @return void
     */
    public function plugin_page()
    {
        // .wp-header-end tells WordPress (common.js) where admin notices go.
        // Without it, core moves them behind the first h1 inside .wrap, which
        // is a heading rendered by the app (e.g. "Welcome to Bricksforge").
        echo '<div class="wrap"><hr class="wp-header-end" style="display:none"><div id="bricksforge-admin-app"></div></div>';

        // Native WP admin notices are printed inside .wrap, outside our Vue app.
        // The styling lives in admin.css; here we only align their left edge with
        // the app content, which shifts when the side nav collapses/expands.
        ?>
        <script>
            (function () {
                function noticeNodes() {
                    var scope = document.getElementById('wpbody') || document.body;
                    // WP prints these in the content area (usually a sibling of
                    // .wrap) — grab them all, excluding anything the app renders.
                    return Array.prototype.slice.call(
                        scope.querySelectorAll('.notice, .update-nag, .updated, .error')
                    ).filter(function (n) { return !n.closest('#bricksforge-admin-app'); });
                }
                function align() {
                    var app = document.getElementById('bricksforge-admin-app');
                    // Align to the actual left edge of the content column, so it
                    // stays correct regardless of nav width, padding or margins.
                    var ref = app && app.querySelector('.brf-content');
                    if (!ref) return;
                    var box = ref.getBoundingClientRect();
                    if (box.width < 40) return; // app not laid out yet — retry later
                    var desiredLeft = box.left;
                    noticeNodes().forEach(function (n) {
                        var cur = parseFloat(getComputedStyle(n).marginLeft) || 0;
                        var delta = desiredLeft - n.getBoundingClientRect().left;
                        if (Math.abs(delta) < 1) return; // already aligned
                        // setProperty important to beat any !important margin in CSS.
                        n.style.setProperty('margin-left', Math.max(0, Math.round(cur + delta)) + 'px', 'important');
                    });
                }
                // Coalesce bursts (Vue re-renders, nav collapse) into one measure.
                var raf = null;
                function schedule() {
                    if (raf) return;
                    raf = requestAnimationFrame(function () { raf = null; align(); });
                }
                // The app mounts async — keep re-aligning for a while, then
                // rely on the observers below for later shifts.
                var start = Date.now();
                var contentRO = null;
                function watchContent() {
                    if (contentRO || !window.ResizeObserver) return;
                    var app = document.getElementById('bricksforge-admin-app');
                    var content = app && app.querySelector('.brf-content');
                    if (!content) return;
                    // .brf-content widens when the side nav collapses → re-align.
                    contentRO = new ResizeObserver(schedule);
                    contentRO.observe(content);
                }
                var iv = setInterval(function () {
                    align();
                    watchContent();
                    if (contentRO && Date.now() - start > 4000) clearInterval(iv);
                }, 250);
                window.addEventListener('resize', schedule);
                // Late-injected notices (WP/other plugins) → align them too.
                var host = document.getElementById('wpbody-content') || document.body;
                if (window.MutationObserver) {
                    new MutationObserver(schedule).observe(host, { childList: true });
                }
            })();
        </script>
        <?php
        // Live-sync the native WP submenu under "Bricksforge" when a tool is
        // toggled in the app, so its page appears/disappears without a reload.
        $nav_features = array();
        foreach ($this->get_feature_pages() as $f) {
            $nav_features[] = array(
                'id'    => $f['id'],
                'label' => __($f['label'], 'bricksforge'),
                'route' => $f['route'],
            );
        }
        ?>
        <script>
            (function () {
                var FEATURES = <?php echo wp_json_encode($nav_features); ?>;
                var BASE = 'admin.php?page=bricksforge';

                function submenu() {
                    return document.querySelector('#toplevel_page_bricksforge ul.wp-submenu');
                }
                // Match a submenu <li> by a route token in its link href.
                function liByRoute(menu, route) {
                    var links = menu.querySelectorAll('a');
                    for (var i = 0; i < links.length; i++) {
                        if ((links[i].getAttribute('href') || '').indexOf(route) !== -1) {
                            return links[i].closest('li');
                        }
                    }
                    return null;
                }
                function sync(activated) {
                    var menu = submenu();
                    if (!menu) return;
                    var logsLi = liByRoute(menu, 'logs');
                    if (!logsLi) return;
                    // Rebuild the feature section: drop every known feature item,
                    // then re-insert the active ones in canonical order, before Logs.
                    FEATURES.forEach(function (f) {
                        var li = liByRoute(menu, f.route);
                        if (li) li.parentNode.removeChild(li);
                    });
                    FEATURES.forEach(function (f) {
                        if (activated.indexOf(f.id) === -1) return;
                        var li = document.createElement('li');
                        var a = document.createElement('a');
                        a.href = BASE + '#/' + f.route;
                        a.textContent = f.label;
                        li.appendChild(a);
                        menu.insertBefore(li, logsLi);
                    });
                }
                document.addEventListener('brf-activated-tools-changed', function (e) {
                    sync((e.detail && e.detail.activatedTools) || []);
                });
            })();
        </script>
        <?php
    }

    private $admin_menu_snapshot = array();

    /**
     * Capture the admin menu LATE in the admin_menu hook: every plugin has
     * registered its entries, but WordPress hasn't sorted/re-indexed $menu
     * yet — so the array keys still carry the REAL menu positions
     * (including collision suffixes like "22abcd", which floatval() maps
     * back to their numeric base).
     */
    public function capture_admin_menu_snapshot()
    {
        global $menu;

        if (!is_array($menu)) {
            return;
        }

        $snapshot = array();

        foreach ($menu as $position => $item) {
            $label = isset($item[0]) ? trim(strip_tags(preg_replace('/<span[^>]*>.*?<\/span>/s', '', $item[0]))) : '';

            // Skip separators and empty entries
            if ($label === '') {
                continue;
            }

            $icon = isset($item[6]) ? $item[6] : '';

            $snapshot[] = array(
                'label'    => $label,
                'slug'     => isset($item[2]) ? $item[2] : '',
                'position' => floatval($position),
                'icon'     => strpos($icon, 'dashicons-') === 0 ? $icon : '',
                'iconUrl'  => (strpos($icon, 'data:') === 0 || strpos($icon, 'http') === 0) ? $icon : '',
            );
        }

        // Display order: sort by real position (stable)
        $order = array_keys($snapshot);
        usort($order, function ($a, $b) use ($snapshot) {
            if ($snapshot[$a]['position'] === $snapshot[$b]['position']) {
                return $a - $b;
            }

            return $snapshot[$a]['position'] <=> $snapshot[$b]['position'];
        });

        $this->admin_menu_snapshot = array_values(array_map(function ($index) use ($snapshot) {
            return $snapshot[$index];
        }, $order));
    }

    /**
     * Snapshot of the real admin menu (labels, icons, real positions) —
     * used by the Admin Pages live preview to reflect the actual site menu.
     *
     * @return array
     */
    public function get_admin_menu_snapshot()
    {
        return $this->admin_menu_snapshot;
    }

    public function upload_mimes($mime_types)
    {
        $font_mime_types = [
            // 'eot'   => 'font/eot', // <IE9 only (if specified, it must be listed first)
            'woff2' => 'font/woff2',
            'woff'  => 'font/woff',
            'ttf'   => 'font/ttf',
        ];

        if (\Bricks\Capabilities::current_user_can_use_builder()) {
            foreach ($font_mime_types as $type => $mime) {
                if (!isset($mime_types[$type])) {
                    $mime_types[$type] = $mime;
                }
            }
        }

        return $mime_types;
    }
}
