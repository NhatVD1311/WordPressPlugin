<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Global Classes Handler
 */
class PageTransitions
{
    private $settings = [];

    public function __construct()
    {
        $this->init();
    }

    /**
     * The defaults for everything the frontend runtime acts on.
     *
     * This is the single place they are defined. The option filters below
     * apply them to every read of 'brf_page_transitions', so the frontend
     * runtime (BRFTRANSITIONS) and the settings panel (REST get_option) see
     * the same values — an installation that never saved the settings page
     * behaves exactly like one that saved them unchanged.
     *
     * Panel-only fields (custom CSS, compatibility code, hooks) are not
     * listed here; their default is "empty", which needs no merging.
     */
    public static function get_defaults()
    {
        return [
            'containers'             => '#brx-content',
            'animationScope'         => 'html',
            'animationType'          => 'css',
            'animateHistoryBrowsing' => true,
            'cache'                  => true,
            'native'                 => false,
            'linkToSelf'             => 'navigate',
            'linkSelector'           => 'a[href]:not(.bricks-lightbox):not([data-pswp-src])',
        ];
    }

    /**
     * Fills in the defaults the stored settings don't define.
     *
     * A stored value wins, including `false` — only a missing key falls back
     * to the default. The one exception is a stored empty string for a
     * setting that needs a value (a cleared selector field, for instance):
     * an empty container or link selector would break the transition, so the
     * default takes over there as well.
     */
    public static function with_defaults($settings)
    {
        if (is_object($settings)) {
            $settings = get_object_vars($settings);
        }

        if (!is_array($settings)) {
            $settings = [];
        }

        foreach (self::get_defaults() as $key => $default) {
            if (!isset($settings[$key])) {
                $settings[$key] = $default;
                continue;
            }

            if (is_string($default) && $default !== '' && $settings[$key] === '') {
                $settings[$key] = $default;
            }
        }

        return $settings;
    }

    /**
     * Option filter — see get_defaults().
     */
    public function filter_settings($settings)
    {
        return self::with_defaults($settings);
    }

    /**
     * Get a setting value - handles both object and array formats
     */
    private function get_setting($key, $default = null)
    {
        if (is_object($this->settings) && isset($this->settings->$key)) {
            return $this->settings->$key;
        } elseif (is_array($this->settings) && isset($this->settings[$key])) {
            return $this->settings[$key];
        }
        return $default;
    }

    public function init()
    {
        // Registered outside the activated() gate: the settings panel reads
        // the option through the REST API and has to see the same defaults.
        // 'default_option_' covers the case where the option was never saved,
        // 'option_' the case where it was saved by an older version and is
        // missing keys.
        add_filter('option_brf_page_transitions', [$this, 'filter_settings']);
        add_filter('default_option_brf_page_transitions', [$this, 'filter_settings']);

        if ($this->activated() === true) {
            $this->settings = self::with_defaults(get_option('brf_page_transitions'));

            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
            add_action('wp_enqueue_scripts', [$this, 'add_custom_styles']);
            add_action('wp_footer', [$this, 'load_main_script'], 999);
            $this->add_attributes();
        }
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script('bricksforge-swup');
        wp_enqueue_script('bricksforge-swup-head-plugin');
        wp_enqueue_script('bricksforge-swup-body-class-plugin');
        wp_enqueue_script('bricksforge-swup-accessibility-plugin');
        wp_enqueue_script('bricksforge-swup-morph-plugin');

        $animation_type = $this->get_setting('animationType');

        if ($animation_type === 'gsap') {
            wp_enqueue_script('bricksforge-gsap');
            wp_enqueue_script('bricksforge-swup-js-plugin');
        }
    }

    private function add_attributes()
    {
        add_filter('bricks/content/attributes', function ($attributes) {
            $attributes['data-post-id'] = get_the_ID();
            $attributes['class'] = 'brf-page-transition';

            return $attributes;
        });

        $animation_type = $this->get_setting('animationType');

        if ($animation_type === 'css' || $animation_type === null) {
            add_filter('bricks/content/attributes', function ($attributes) {
                $attributes['data-transition-type'] = "css";

                return $attributes;
            });
        }
    }

    public function add_custom_styles()
    {
        $animation_type = $this->get_setting('animationType');

        if ($animation_type !== null && $animation_type !== 'css') {
            return;
        }

        $css = $this->get_setting('customCssCode');

        if (empty($css)) {
            return;
        }

        // Add custom CSS to the page
        wp_add_inline_style('bricksforge-style', $css);
    }

    public function load_main_script()
    {
        // Settings first — the runtime has no defaults of its own and reads
        // them from here (see get_defaults()).
        echo '<script id="bricksforge-transitions-settings-js">var BRFTRANSITIONS = ' . json_encode($this->settings) . ';</script>';

        // Load the main script
        echo '<script src="' . BRICKSFORGE_ASSETS . '/js/bricksforge_transitions.js?ver=' . filemtime(BRICKSFORGE_PATH . '/assets/js/bricksforge_transitions.js') . '' . '" id="bricksforge-transitions-js"></script>';
    }

    public function activated()
    {
        return get_option('brf_activated_tools') && in_array(16, get_option('brf_activated_tools'));
    }
}
