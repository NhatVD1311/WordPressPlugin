<?php
if( ! defined( 'AVIA_FW' ) )	{	exit( 'No direct script access allowed' );	}

/**
 * Handles importing a demo
 *
 * By default errors importing a demo due to not activated plugins are ignored.
 *
 * Creating demos it is usefull to check for import errors - In wp-config.php or functions.php:
 *
 * Enable logging to default error log, behaviour is same as default, reroute to theme options page when finished:
 *		- define( 'WP_DEBUG', true );
 *
 * To enable additional displaying of error message to user - no reroute to theme options page when error occur:
 *		-  define( 'AVIA_REPORT_DEMO_IMPORT_ERRORS', true );
 *
 */

if ( ! defined( 'WP_LOAD_IMPORTERS' ) )
{
	define( 'WP_LOAD_IMPORTERS', true );
}

if( ! defined( 'AVIA_REPORT_DEMO_IMPORT_ERRORS' ) )
{
	define( 'AVIA_REPORT_DEMO_IMPORT_ERRORS', false );
}

//heavily increased the execution time. if an image optimization plugin is active this will be necessary when importing larger demos
@ini_set( 'max_execution_time', 1200 );

$demo_full_name = ! empty( $_REQUEST['demo_full_name'] ) ? stripslashes( $_REQUEST['demo_full_name'] ) : '';
$debug_prefix = sprintf( __( 'Demo Importer (%s):', 'avia_framework' ), $demo_full_name ) . ' ';

if( defined( 'WP_DEBUG' ) && WP_DEBUG )
{
	error_log( $debug_prefix . __( 'Import started', 'avia_framework' ) );
}

// Load Importer API
require_once ABSPATH . 'wp-admin/includes/import.php';

$avia_importerError = false;

global $avia_config;

/**
 * We have to handle:
 *
 *	- a default demo shipped with theme (default)
 *	- Demos shipped with theme
 *	- Downloaded demos from an external server
 *
 * @since 4.8.2
 */
$default_path = get_template_directory() . '/includes/admin/demo_files/default';

if( isset( $_POST['files'] ) && ! empty( $_POST['files'] ) )
{
	//	Shipped demo: a theme relative path. Reject traversal so it can only point inside the theme.
	$files = wp_normalize_path( (string) $_POST['files'] );
	if( false === strpos( $files, '..' ) )
	{
		$default_path = get_template_directory() . $files;
	}
}
else if( ! empty( $_POST['demo_name'] ) )
{
	//	Downloaded demo: derive the folder from the ( sanitized ) demo name on the server, never from
	//	the request, so the import can only ever read from inside the demo folder.
	$demo_name_safe = sanitize_file_name( (string) $_POST['demo_name'] );
	$demo_dir = avia_demo_import_dir( $demo_name_safe );
	if( '' !== $demo_dir )
	{
		$default_path = $demo_dir . $demo_name_safe;
	}
}

$import_filepath = apply_filters(  'avf_import_dummy_filepath', $default_path, THEMENAME );

/**
 * Make path global to allow other scripts to get access (e.g. config-woocommerce/admin-import.php)
 */
$avia_config['demo_import']['current_import_filepath'] = $import_filepath;


//check if wp_importer, the base importer class is available, otherwise include it
if( ! class_exists( 'WP_Importer', false ) )
{
	$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
	if ( file_exists( $class_wp_importer ) )
	{
		require_once( $class_wp_importer );
	}
	else
	{
		$avia_importerError = true;
	}
}

//check if the wp import class is available, this class handles the wordpress XML files. If not include it
//make sure to exclude the init function at the end of the file in kriesi_importer
if( ! class_exists( 'WP_Import', false ) )
{
	$class_wp_import = AVIA_PHP . 'wordpress-importer/wordpress-importer.php';
	if ( file_exists( $class_wp_import ) )
	{
		require_once( $class_wp_import );
	}
	else
	{
		$avia_importerError = true;
	}
}

if( $avia_importerError !== false )
{
	$msg = sprintf( __( 'The importer could not be loaded. Import the file %s manually with the WordPress importer.', 'avia_framework' ), '<pre>' . $import_filepath . '.xml</pre>' );

	if( defined( 'WP_DEBUG' ) && WP_DEBUG )
	{
		error_log( $debug_prefix . $msg );
	}

	exit( 'avia_error-' . $msg );
}
else
{
	if( class_exists( 'WP_Import', false ) )
	{
		include_once( 'wordpress-importer/avia-import-class.php' );
	}

	$import_error = false;

	if( ! is_file( $import_filepath . '.xml' ) )
	{
		$msg = sprintf( __( 'The demo content file %s is missing or cannot be read. Check its file permissions, or import it manually with the WordPress importer.', 'avia_framework' ), '<pre>' . $import_filepath . '.xml</pre>' ) . ' <a href="https://kriesi.at/documentation/enfold/import-demos/#how-to-manually-import-a-theme-demo" target="_blank" rel="noopener noreferrer">' . __( 'Learn more', 'avia_framework' ) . '</a>';
		if( defined( 'WP_DEBUG' ) && WP_DEBUG )
		{
			error_log( $debug_prefix . $msg );
		}

		exit( 'avia_error-' . $msg );
	}
	else
	{
		if( ! isset( $custom_export ) )
		{
			/**
			 * @used_by		enfold\config-woocommerce\admin-import.php					10
			 * @used_by		aviaCustomLayout::handler_avia_import_hook					10
			 * @used_by		aviaElementTemplates::handler_avia_import_hook				10
			 */
			do_action( 'avia_import_hook' );

			/**
			 * WP Importer plugin echos messages -> success message AND error messages (e.g. when posttypes of non active plugins are imported)
			 */
			ob_start();

			$wp_import = new avia_wp_import();
			$wp_import->rename_existing_menus();
			$wp_import->fetch_attachments = true;

			/**
			 * Demo content is first party ( vendor authored, shipped with the theme or downloaded from
			 * the allow-listed demo server ). A multisite subsite admin lacks 'unfiltered_html', which
			 * would silently strip demo markup ( code blocks, custom embeds ) and report a clean import.
			 * Bypass kses for the first party demo import only, then restore the previous state.
			 *
			 * @since 8.1
			 */
			$restore_kses = ! current_user_can( 'unfiltered_html' );
			if( $restore_kses )
			{
				kses_remove_filters();
			}

			$wp_import->import( $import_filepath . '.xml' );

			if( $restore_kses )
			{
				kses_init();
			}

			//	Demo theme options are read from the .txt options file. Legacy .php option files are
			//	no longer supported - the theme never includes a php file from a downloaded demo.
			$options_file = '';
			if( is_file( $import_filepath . '.txt' ) )
			{
				$options_file = $import_filepath . '.txt';
			}

			if( ! empty( $options_file ) )
			{
				$wp_import->saveOptions( $options_file );
			}

			$wp_import->set_menus();

			/**
			 * Replace the term and post ids of the demo by the ids on this site.
			 * Must run before 'ava_after_import_demo_settings' regenerates the assets.
			 *
			 * @since 8.0
			 */
			$wp_import->remap_imported_ids();

			$wp_import_msg = trim( ob_get_clean() );

			$result_pos = strpos( $wp_import_msg, '<p>All done.' );
			if( 0 ===  $result_pos )
			{
				if( defined( 'WP_DEBUG' ) && WP_DEBUG )
				{
					error_log( $debug_prefix . 'No Errors from importer: ' . $wp_import_msg );
				}

				echo $wp_import_msg;
			}
			else if( false !== $result_pos && ( ! defined( 'AVIA_REPORT_DEMO_IMPORT_ERRORS' ) || true !== AVIA_REPORT_DEMO_IMPORT_ERRORS ) )
			{
				//	Error message only reported to log file - not to user
				if( defined( 'WP_DEBUG' ) && WP_DEBUG )
				{
					$out = str_replace( '<br />', "\n\t\t", $wp_import_msg );
					error_log( $debug_prefix . 'Errors from importer - not reported to user: ' . "\n\t\t" . $out );
				}

				$done = substr( $wp_import_msg, $result_pos );
				echo $done;
			}
			else
			{
				//	report errors to log and user
				if( defined( 'WP_DEBUG' ) && WP_DEBUG )
				{
					$out = str_replace( '<br />', "\n\t\t", $wp_import_msg );
					error_log( $debug_prefix . 'Errors from importer: ' . "\n\t\t" . $out );
				}

				//	limit output to user in modal popup
				$err_msg = '';
				if( strlen( $wp_import_msg ) > 0 )
				{
					$wp_import_msg = explode( '<br />', $wp_import_msg );
					$add_more = true;
					$i = 0;

					foreach( $wp_import_msg as $err )
					{
						if( false !== stripos( $err, '<p>All done' ) )
						{
							$add_more = false;
							break;
						}

						$err_msg .= '<br />' . $err;

						$i++;
						if( $i > 10 )
						{
							break;
						}
					}

					if( $add_more )
					{
						$err_msg .= '<br />..........';
					}
				}

				if( '' != $err_msg )
				{
					$import_error = true;

					$out  =  'avia_error-' . __( 'The demo import had errors. Check that all required plugins are active and that no existing content conflicts with the demo.', 'avia_framework' ) . '<br />';
					$out .= __( 'Error(s) returned:', 'avia_framework' ) . '<br />';
					$out .= $err_msg;

					echo $out;
				}
			}

			/**
			 * @used_by		enfold\config-woocommerce\config.php			10
			 */
			do_action( 'avia_after_import_hook' ); // todo: rename. make sure to update hook name of our woocommerce import script
		}
		else
		{
			$import = new avia_wp_import();
			$import->saveOptions( $import_filepath . '.php', $custom_export );

			do_action( 'avia_after_custom_import_hook' );
		}

		/**
		 * generic hook. example use: after demo setting import we want to regen cached stylesheet
		 *
		 * @used_by			class aviaElementManager				10
		 * @used_by			functions-enfold.php					30
		 * @used_by			includes\helper-assets.php				100
		 */
		do_action( 'ava_after_import_demo_settings' );


		/**
		 * In case an error occured we can break script now
		 */
		if( $import_error )
		{
			exit;
		}

		update_option( 'av_demo_content_imported', true );
	}
}




