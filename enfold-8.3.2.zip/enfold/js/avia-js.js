/**
 * Contains plain js basic and helpers classes
 *
 * @since 5.6
 */

/**
 * Global namespace
 *
 * @since 5.6
 */
var aviaJS = aviaJS || {};

(function()
{
	"use strict";

	if( ! aviaJS.aviaJSHelpers )
	{
		class aviaJSHelpers
		{
			constructor()
			{
				this.wpHooks();
			}

			//	based on _.js debounce()
			debounce( callback, wait, immediate )
			{
				var timeout;

				return function()
				{
					var context = this,
						args = arguments;

					var later = function()
					{
						timeout = null;
						if( ! immediate )
						{
							callback.apply(context, args);
						}
					};

					var callNow = immediate && ! timeout;

					clearTimeout( timeout );
					timeout = setTimeout( later, wait );
					if( callNow )
					{
						callback.apply( context, args );
					}
				};
			}

			wpHooks()
			{
				//	to avoid checking for wp.hooks calling filters or actions we create dummy functions here
				if( window['wp'] && wp.hooks )
				{
					return;
				}

				if( ! window['wp'] )
				{
					window['wp'] = { hooks: {} };
				}
				else
				{
					window['wp'].hooks = {};
				}

				let obj = window['wp'].hooks;

				obj.applyFilters = this.wpHooks_applyFilters;
				obj.doAction = this.wpHooks_applyFilters;
				obj.hasFilter = this.wpHooks_hasFilters;
				obj.hasAction = this.wpHooks_hasFilters;
			}

			wpHooks_applyFilters( handle, value )
			{
				return value;
			}

			wpHooks_hasFilters( handle, namespace )
			{
				return false;
			}

			/**
			 * Tooltip text is shown as HTML so tooltips can be formatted. It comes from data attributes that
			 * any writer can set, so only formatting survives: allowed tags keep their safe attributes, other
			 * tags are unwrapped (their text stays), script-like elements go with their content, and links or
			 * images may only point to web, mail or phone addresses.
			 *
			 * The markup is parsed into an inert <template>, so nothing in it loads or runs while it is cleaned.
			 *
			 * @since 8.3.1
			 * @param {string} html
			 * @returns {string}
			 */
			cleanTooltipHtml( html )
			{
				const keep = [ 'a', 'abbr', 'b', 'blockquote', 'br', 'code', 'del', 'div', 'em', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'i', 'img', 'ins', 'li', 'mark', 'ol', 'p', 's', 'small', 'span', 'strong', 'sub', 'sup', 'u', 'ul' ],
					drop = [ 'script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'template', 'noscript', 'noembed', 'noframes', 'svg', 'math', 'link', 'meta', 'base', 'form', 'input', 'button', 'textarea', 'select', 'title' ],
					attributes = [ 'class', 'style', 'title', 'alt', 'href', 'src', 'target', 'rel', 'width', 'height', 'lang', 'dir' ],
					urls = [ 'href', 'src' ],
					template = document.createElement( 'template' );

				const safe_url = function( value )
				{
					const url = value.replace( /[\u0000-\u0020]/g, '' ).toLowerCase(),
						scheme = url.match( /^([a-z][a-z0-9+.-]*):/ );

					return ! scheme || [ 'http', 'https', 'mailto', 'tel' ].indexOf( scheme[1] ) >= 0;
				};

				const clean = function( parent )
				{
					Array.from( parent.childNodes ).forEach( function( node )
					{
						if( node.nodeType === 3 )
						{
							return;
						}

						const tag = node.nodeType === 1 ? node.nodeName.toLowerCase() : '';

						if( '' === tag || drop.indexOf( tag ) >= 0 )
						{
							node.remove();
							return;
						}

						clean( node );

						if( keep.indexOf( tag ) < 0 )
						{
							node.replaceWith( ...Array.from( node.childNodes ) );
							return;
						}

						Array.from( node.attributes ).forEach( function( attr )
						{
							const name = attr.name.toLowerCase();

							if( attributes.indexOf( name ) < 0 || ( urls.indexOf( name ) >= 0 && ! safe_url( attr.value ) ) || ( 'style' === name && /expression\(|url\(|javascript:/i.test( attr.value ) ) )
							{
								node.removeAttribute( attr.name );
							}
						});
					});
				};

				template.innerHTML = String( html );
				clean( template.content );

				return template.innerHTML;
			}

			/**
			 * Content the theme renders itself for a tooltip (the search form in the main menu), printed as a
			 * <template> directly inside <body>. Writers cannot add <template> elements (WordPress strips them from
			 * posts, comments and builder content of users who may not publish raw HTML); requiring a direct child
			 * of <body> and exactly one keeps look-alikes from other markup out as well.
			 *
			 * @since 8.3.2
			 * @param {string} id
			 * @returns {string|null}		null unless exactly one such template exists
			 */
			trustedTemplateHtml( id )
			{
				if( 'string' != typeof id || '' === id || ! document.body )
				{
					return null;
				}

				const found = Array.from( document.body.children ).filter( function( element )
				{
					return 'TEMPLATE' === element.nodeName && element.id === id;
				});

				return 1 === found.length ? found[0].innerHTML : null;
			}
		}

		aviaJS.aviaJSHelpers = new aviaJSHelpers();
	}

	if( ! aviaJS.aviaPlugins )
	{
		class aviaPlugins
		{
			plugins = [];
			defaultPlugin = {
				classFactory:	null,
				selector:		''
			};

			constructor()
			{
				this.plugins = [];
			}

			register( classFactory, selector )
			{
				if( 'function' != typeof classFactory )
				{
					return false;
				}

				let newPlugin = Object.assign( {}, this.defaultPlugin );

				if( 'string' != typeof selector )
				{
					selector = 'body';
				}

				newPlugin.classFactory = classFactory;
				newPlugin.selector = selector;

				this.plugins.push( newPlugin );

				this.check_bind();
			}

			check_bind()
			{
				if( document.readyState === 'complete' )
				{
					// The page is already fully loaded
					this.bind_plugins();
				}
				else
				{
					document.addEventListener( 'readystatechange', this.bind_plugins.bind( this ) );
				}
			}

			bind_plugins( e )
			{
				if( document.readyState !== 'complete' )
				{
					return;
				}

				let plugins = this.plugins;
				this.plugins = [];

				for( let plugin of plugins )
				{
					let elements = document.querySelectorAll( plugin.selector );

					for( let element of elements )
					{
						plugin.classFactory( element );
					}
				}
			}
		}

		aviaJS.aviaPlugins = new aviaPlugins();
	}

})();

