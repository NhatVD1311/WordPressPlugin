/* Indonesian initialisation for the jQuery UI date picker plugin. */
/* Written by Deden Fathurahman (dedenf@gmail.com). */
( function( factory ) {
	// eslint-disable-next-line no-undef
	if ( typeof define === "function" && define.amd ) {
		// AMD. Register as an anonymous module.
		// eslint-disable-next-line no-undef
		define( [ "../widgets/datepicker" ], factory );
	} else {
		// Browser globals
		// eslint-disable-next-line no-undef
		factory( jQuery.datepicker );
	}
}( function( datepicker ) {

datepicker.regional.id = {
	closeText: "Tutup",
	prevText: "&#x3C;mundur",
	nextText: "maju&#x3E;",
	currentText: "hari ini",
	monthNames: [ "Januari","Februari","Maret","April","Mei","Juni",
	"Juli","Agustus","September","Oktober","Nopember","Desember" ],
	monthNamesShort: [ "Jan","Feb","Mar","Apr","Mei","Jun",
	"Jul","Agus","Sep","Okt","Nop","Des" ],
	dayNames: [ "Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu" ],
	dayNamesShort: [ "Min","Sen","Sel","Rab","kam","Jum","Sab" ],
	dayNamesMin: [ "Mg","Sn","Sl","Rb","Km","jm","Sb" ],
	weekHeader: "Mg",
	dateFormat: "dd/mm/yy",
	firstDay: 0,
	isRTL: false,
	showMonthAfterYear: false,
	yearSuffix: "" };
datepicker.setDefaults( datepicker.regional.id );

return datepicker.regional.id;

} ) );
