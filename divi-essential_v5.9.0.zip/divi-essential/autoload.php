<?php
/**
 * Custom PSR-4 Autoloader for Divi Essential
 *
 * This replaces the Composer vendor/autoload.php
 *
 * @package DNXTE
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

spl_autoload_register( function ( $class ) {
    // Project-specific namespace prefixes and their base directories
    $namespace_map = array(
        'DNXTE\\Modules\\'  => array(
            __DIR__ . '/modules/',
            __DIR__ . '/divi-5/server/Modules/',
        ),
        'DNXTE\\Includes\\' => array(
            __DIR__ . '/includes/',
        ),
        'DNXTE\\Shared\\'   => array(
            __DIR__ . '/divi-5/server/Shared/',
        ),
    );

    // Loop through namespace prefixes
    foreach ( $namespace_map as $prefix => $base_dirs ) {
        // Check if the class uses this namespace prefix
        $len = strlen( $prefix );
        if ( strncmp( $prefix, $class, $len ) !== 0 ) {
            continue;
        }

        // Get the relative class name
        $relative_class = substr( $class, $len );

        // Replace namespace separators with directory separators
        $relative_path = str_replace( '\\', '/', $relative_class ) . '.php';

        // Look for the file in each base directory
        foreach ( (array) $base_dirs as $base_dir ) {
            $file = $base_dir . $relative_path;

            if ( file_exists( $file ) ) {
                require_once $file;
                return true;
            }
        }
    }

    return false;
});
