<?php

defined( 'ABSPATH' ) || die();

if ( ! function_exists( 'divi_essential_divi4_init' ) ) {
	function divi_essential_divi4_init() {
		require_once DIVI_ESSENTIAL_DIR . 'includes/Traits/button-render.php';
		require_once DIVI_ESSENTIAL_DIR . 'divi-4/server/modules/base/Common.php';

		$inactive_modules = get_option( 'dnxte_inactive_modules', array() );

		// Define module mapping array
		$module_mapping = array(
			'dnxte-divider'                   => 'DiviNextDivider',
			'dnxte-image-magnifier'           => 'DiviNextImageMagnifier',
			'dnxte-image-reveal'              => 'DiviNextImageReveal',
			'dnxte-lottie'                    => 'DiviNextLottie',
			'dnxte-gallery-slider'            => array( 'DiviNextThumbsGallery', 'DiviNextThumbsGalleryChild' ),
			'dnxte-image-hotspot'             => array( 'DiviNextTooltip', 'DiviNextTooltipChild' ),
			'dnxte-3d-cube-slider'            => array( 'DiviNxte3dCubeSlider', 'DiviNxte3dCubeSliderChild' ),
			'dnxte-business-hour'             => array( 'DiviNxteBusinessHour', 'DiviNxteBusinessHourChild' ),
			'dnxte-coverflow-slider'          => array( 'DiviNxteCoverflowSlider', 'DiviNxteCoverflowSliderChild' ),
			'dnxte-feature-list'              => array( 'DiviNxteFeatureList', 'DiviNxteFeatureListChild' ),
			'dnxte-floating-element'          => array( 'DiviNxteFloatingElement', 'DiviNxteFloatingElementChild' ),
			'dnxte-price-list'                => array( 'DiviNxtePriceList', 'DiviNxtePriceListChild' ),
			'dnxte-promo-box'                 => 'DiviNxtePromobox',
			'dnxte-testimonial-slider'        => array( 'DiviNxteTestimonial', 'DiviNxteTestimonialChild' ),
			'dnxte-flip-box'                  => 'DiviNxtFlipbox',
			'dnxte-logo-carousel'             => array( 'DiviNxtLogoCarousel', 'DiviNxtLogoCarouselChild' ),
			'dnxte-person'                    => array( 'DiviNxtPerson', 'DiviNxtPersonItem' ),
			'dnxte-3D-flip-box'               => 'Next3dFlipbox',
			'dnxte-before-after'              => 'NextBeforeAfter',
			'dnxte-blurb'                     => 'NextBlurb',
			'dnxte-button'                    => 'NextButton',
			'dnxte-circular-image-hover'      => 'NextCircularImageHover',
			'dnxte-facbook-comment'           => 'NextComment',
			'dnxte-dual-button'               => 'NextDualButton',
			'dnxte-facebook-embedded-comment' => 'NextEmbeddedComment',
			'dnxte-facebook-embedded-post'    => 'NextEmbeddedPost',
			'dnxte-facebook-embedded-Video'   => 'NextEmbeddedVideo',
			'dnxte-facebook-page'             => 'NextFBPage',
			'dnxte-facebook-share-button'     => 'NextFBShareButton',
			'dnxte-text-gradient'             => 'NextGradientText',
			'dnxte-image-accordion'           => array( 'NextImageAccordion', 'NextImageAccordionItem' ),
			'dnxte-image-hover-box'           => 'NextImageHoverBox',
			'dnxte-image-icon-effect'         => 'NextImageIcon',
			'dnxte-image-scroll'              => 'NextImageScroll',
			'dnxte-facebook-like-button'      => 'NextLikeButton',
			'dnxte-masonry-gallery'           => 'NextMasonary',
			'dnxte-mega-image-effect'         => 'NextMegaImageEffect',
			'dnxte-minimal-image'             => 'NextMinimalImageHover',
			'dnxte-text-multi-heading'        => 'NextMultiHeading',
			'dnxte-rating'                    => 'NextRating',
			'dnxte-divi-review'               => 'NextReview',
			'dnxte-step-flow'                 => 'NextStepFlow',
			'dnxte-team-creative'             => array( 'NextTeamCreative', 'NextTeamCreativeItem' ),
			'dnxte-team-member-overlay'       => array( 'NextTeamOverlay', 'NextTeamOverlayItem' ),
			'dnxte-team-overlay-card'         => array( 'NextTeamOverlayCard', 'NextTeamOverlayCardItem' ),
			'dnxte-team-social-reveal'        => array( 'NextTeamSocialReveal', 'NextTeamSocialRevealChild' ),
			'dnxte-text-animation'            => 'NextTextAnimation',
			'dnxte-text-color-motion'         => 'NextTextColorMotion',
			'dnxte-text-divider'              => 'NextTextDivider',
			'dnxte-text-glitch'               => 'NextTextGlitch',
			'dnxte-text-highlight'            => 'NextTextHighlight',
			'dnxte-text-hover-highlight'      => 'NextTextHoverHighlight',
			'dnxte-text-mask'                 => 'NextTextMask',
			'dnxte-text-stroke'               => 'NextTextStroke',
			'dnxte-text-stroke-motion'        => 'NextTextStrokeMotion',
			'dnxte-text-tilt'                 => 'NextTextTilt',
			'dnxte-timeline'                  => array( 'NextTimeline', 'NextTimelineChild' ),
			'dnxte-twitter-follow'            => 'NextTwitterFollow',
			'dnxte-twitter-share'             => 'NextTwitterShare',
			'dnxte-twitter-timeline'          => 'NextTwitterTimeline',
			'dnxte-twitter-tweet'             => 'NextTwitterTweet',
			'dnxte-ultimate-image-hover'      => 'NextUltimateImageHover',
			'dnxte-content-toggle'            => 'NextContentToggle',
			'dnxte-post-carousel'             => 'NextBlogSlider',
			'dnxte-advanced-tab'              => array( 'NextAdvancedTab', 'NextAdvancedTabItem' ),
		);

		foreach ( $module_mapping as $module_key => $module_value ) {
			if ( ! in_array( $module_key, $inactive_modules, true) ) {
				if ( is_array( $module_value ) ) {
					foreach ( $module_value as $module_file ) {
						$path = DIVI_ESSENTIAL_DIR . 'divi-4/server/modules/' . $module_file . '/' . $module_file . '.php';
						if ( file_exists( $path ) ) {
							require_once $path;
						}
					}
				} else {
					$path = DIVI_ESSENTIAL_DIR . 'divi-4/server/modules/' . $module_value . '/' . $module_value . '.php';
					if ( file_exists( $path ) ) {
						require_once $path;
					}
				}
			}
		}
	}

	divi_essential_divi4_init();

}
