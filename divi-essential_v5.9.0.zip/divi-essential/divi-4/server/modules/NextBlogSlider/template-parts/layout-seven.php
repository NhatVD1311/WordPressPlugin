<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$meta_date = isset($args['meta_date']) ? $args['meta_date'] : '';
        global $authordata;
?>
<div style="display:flex;flex-direction:column;">
<div class="dnxte-content-wrapper">
    
        <?php

        $author = 'off' !== $args['show_author'] 
        ? sprintf('<div class="dnxte-authovcard">
            <span class="author vcard">
                <img src="%1$s"
                alt="">
                %2$s
            </span></div>',
            esc_url(get_avatar_url($authordata->ID)),
            et_pb_get_the_author_posts_link()
        ) : '';
            
        ?>
    
    <<?php echo et_core_esc_previously($processed_header_level); ?> class="dnxte-entry-title">
        <a href="<?php esc_url(the_permalink());?>">
            <?php the_title(); ?>
        </a>
    </<?php echo et_core_esc_previously($processed_header_level); ?>>
    <div class="dnxte-blog-post-content">
    <?php
		global $post; 
		$content = '';
		if ('off' === $args['dnext_content_source']) {
			


				if ( has_excerpt() ) {
		
					$content = apply_filters( 'the_excerpt', $post->post_excerpt );
					$content = rtrim( wp_trim_words( $content, $excerpt_length) );
			
				} else{
					$content = $post->post_content;
					$content = preg_replace( '@\[caption[^\]]*?\].*?\[\/caption]@si', '', $content );
					$content = preg_replace( '@\[et_pb_post_nav[^\]]*?\].*?\[\/et_pb_post_nav]@si', '', $content );
					$content = preg_replace( '@\[audio[^\]]*?\].*?\[\/audio]@si', '', $content );
					$content = preg_replace( '@\[embed[^\]]*?\].*?\[\/embed]@si', '', $content );
					$content = wp_strip_all_tags( $content );
					$content = et_strip_shortcodes( $content );
					$content = et_builder_strip_dynamic_content( $content );
					$content = apply_filters( 'et_truncate_post', $content, get_the_ID() );
					$content = rtrim( wp_trim_words( $content, $excerpt_length) );
				}
				echo et_core_intentionally_unescaped( $content, 'html' );
			}else if('on' === $args['dnext_content_source']){
				echo et_core_intentionally_unescaped( apply_filters( 'the_content', $post->post_content ), 'html' );
			}
			
			

		?>
    </div>
    <div class="dnxte-post-meta <?php esc_attr($args['meta_alignment_class']); ?>">
        <?php
            global $authordata;

            $dnxte_clock_icon = $args['multi_view']->render_element(array(
                'tag' => 'span',
                'content' => et_pb_process_font_icon('}'),
                'attrs' => array(
                    'class' => 'dnxte-blogslider-content-icon'
                )
            ));

            $bottom_date = 'off' !== $args['show_date'] ? sprintf(
                '<span class="dnxte-blog-published">%1$s %2$s</span>',
                    $dnxte_clock_icon,
                    get_the_date( $meta_date )
                ) : '';

            sprintf('%1$s %2$s',
            et_core_esc_previously( $author ),
            et_core_esc_previously( $bottom_date )
            );
        ?>
    </div>
</div>
<div class="dnxte-readmorewrapper">
    <?php echo et_core_esc_previously($dnxte_more); ?>
</div>
</div>