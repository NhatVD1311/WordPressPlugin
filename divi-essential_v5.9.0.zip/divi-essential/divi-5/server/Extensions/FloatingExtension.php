<?php
/**
 * Section Floating Elements Extension
 *
 * Injects floating image controls into Divi Section modules.
 *
 * @package DNXTE\Extensions
 * @since ??
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class FloatingExtension {

    private static $target_modules = [ 'divi/section', 'divi/fullwidth-header' ];

    /** Per-page counter so each section's floating items get unique CSS classes. */
    private static $counter = 0;

    /**
     * Numeric value or fallback (allows floats; rejects empty / non-numeric).
     */
    private static function num( $value, $default ) {
        return ( is_numeric( $value ) ) ? (string) $value : $default;
    }

    /**
     * Whether an item override key holds a usable numeric value.
     */
    private static function has( $item, $key ) {
        return isset( $item[ $key ] ) && '' !== $item[ $key ] && is_numeric( $item[ $key ] );
    }

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
    }

    /**
     * Register VB scripts.
     */
    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        // Custom repeater field
        $field_path = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-floating-field.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
            [
                'name'    => 'dnxte-floating-field',
                'version' => file_exists( $field_path ) ? filemtime( $field_path ) : DIVI_ESSENTIAL_VERSION,
                'script'  => [
                    'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-floating-field.js',
                    'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks' ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                    'args'               => [ 'in_footer' => false ],
                ],
            ]
        );

        // Extension hooks
        $ext_path = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-floating-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
            [
                'name'    => 'dnxte-floating-extension',
                'version' => file_exists( $ext_path ) ? filemtime( $ext_path ) : DIVI_ESSENTIAL_VERSION,
                'script'  => [
                    'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-floating-extension.js',
                    'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-floating-field' ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                    'args'               => [ 'in_footer' => false ],
                ],
            ]
        );
    }

    /**
     * Register attributes on target modules.
     */
    public static function register_attributes( $settings ) {
        $module_name = $settings['name'] ?? '';

        if ( ! in_array( $module_name, self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['floating_config'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'use_floating' => [ 'desktop' => [ 'value' => 'off' ] ],
                    'items'        => [ 'desktop' => [ 'value' => '[]' ] ],
                ],
            ],
        ];

        return $settings;
    }

    /**
     * Inject floating elements into frontend HTML.
     */
    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $module_name  = $args['name'] ?? '';
        $module_attrs = $args['attrs'] ?? [];

        if ( ! in_array( $module_name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $fc = $module_attrs['floating_config']['advanced'] ?? [];
        $use_floating = $fc['use_floating']['desktop']['value'] ?? 'off';

        if ( 'on' !== $use_floating ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Whole-effect device switches (hide the entire floating layer per device).
        $disable_tablet = ( $fc['disable_tablet']['desktop']['value'] ?? 'off' ) === 'on';
        $disable_phone  = ( $fc['disable_phone']['desktop']['value'] ?? 'off' ) === 'on';

        $items_json = $fc['items']['desktop']['value'] ?? '[]';
        $items      = json_decode( $items_json, true );

        if ( ! is_array( $items ) || empty( $items ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Container data attributes — defaults, items carry per-item overrides
        $config_attrs = [
            'data-float-y-range'        => '30',
            'data-float-x-range'        => '25',
            'data-float-rot-range'      => '8',
            'data-float-duration'       => '6',
            'data-float-3d'             => 'false',
            'data-float-parallax'       => 'true',
            'data-float-mouse-parallax' => 'true',
            'data-float-stagger'        => '0.15',
        ];

        // Build floating image elements HTML with per-item animation data
        $uid         = self::$counter++;
        $images_html = '';
        $css         = '';
        $idx         = 0;
        foreach ( $items as $item ) {
            $src = $item['src'] ?? '';
            if ( empty( $src ) ) {
                continue;
            }

            $cls = 'dnxte-fe-' . $uid . '-' . $idx;
            ++$idx;

            $z_raw    = $item['zIndex'] ?? '1';
            $z_index  = ( is_numeric( $z_raw ) ) ? esc_attr( (string) intval( $z_raw ) ) : '1';
            $b_radius = esc_attr( $item['borderRadius'] ?? '0' );
            $alt      = esc_attr( $item['alt'] ?? '' );

            // Non-responsive base; position/size live in the <style> block so they
            // can vary per breakpoint. GSAP still animates transform on top.
            $style = "position:absolute;z-index:{$z_index};border-radius:{$b_radius}px;overflow:hidden;pointer-events:auto;will-change:transform;opacity:0;";

            // Desktop position/size.
            $dx   = self::num( $item['posX'] ?? '', '20' );
            $dy   = self::num( $item['posY'] ?? '', '20' );
            $dw   = self::num( $item['width'] ?? '', '200' );
            $css .= ".{$cls}{left:{$dx}%;top:{$dy}%;width:{$dw}px;}";

            // Tablet overrides (only the props the user set; rest inherit desktop).
            $t = '';
            if ( self::has( $item, 'posXTablet' ) ) { $t .= 'left:' . self::num( $item['posXTablet'], '' ) . '%;'; }
            if ( self::has( $item, 'posYTablet' ) ) { $t .= 'top:' . self::num( $item['posYTablet'], '' ) . '%;'; }
            if ( self::has( $item, 'widthTablet' ) ) { $t .= 'width:' . self::num( $item['widthTablet'], '' ) . 'px;'; }
            if ( '' !== $t ) { $css .= "@media(max-width:980px){.{$cls}{{$t}}}"; }

            // Phone overrides (inherit tablet-or-desktop via cascade when unset).
            $ph = '';
            if ( self::has( $item, 'posXPhone' ) ) { $ph .= 'left:' . self::num( $item['posXPhone'], '' ) . '%;'; }
            if ( self::has( $item, 'posYPhone' ) ) { $ph .= 'top:' . self::num( $item['posYPhone'], '' ) . '%;'; }
            if ( self::has( $item, 'widthPhone' ) ) { $ph .= 'width:' . self::num( $item['widthPhone'], '' ) . 'px;'; }
            if ( '' !== $ph ) { $css .= "@media(max-width:767px){.{$cls}{{$ph}}}"; }

            // Hide on device (tablet range = 768–980, phone = ≤767).
            if ( ! empty( $item['hideTablet'] ) ) { $css .= "@media(max-width:980px) and (min-width:768px){.{$cls}{display:none;}}"; }
            if ( ! empty( $item['hidePhone'] ) ) { $css .= "@media(max-width:767px){.{$cls}{display:none;}}"; }

            // Per-item animation data attributes
            $item_data = '';
            $item_data .= ' data-float-preset="' . esc_attr( $item['preset'] ?? 'gentle-float' ) . '"';
            $item_data .= ' data-float-custom="' . ( ! empty( $item['useCustom'] ) && $item['useCustom'] ? 'true' : 'false' ) . '"';

            // Custom animation overrides
            if ( ! empty( $item['useCustom'] ) && $item['useCustom'] ) {
                $item_data .= ' data-float-item-y="' . esc_attr( $item['yRange'] ?? '30' ) . '"';
                $item_data .= ' data-float-item-x="' . esc_attr( $item['xRange'] ?? '25' ) . '"';
                $item_data .= ' data-float-item-rot="' . esc_attr( $item['rotRange'] ?? '8' ) . '"';
                $item_data .= ' data-float-item-duration="' . esc_attr( $item['duration'] ?? '6' ) . '"';
                $item_data .= ' data-float-item-delay="' . esc_attr( $item['delay'] ?? '0' ) . '"';
                $item_data .= ' data-float-item-easing="' . esc_attr( $item['easing'] ?? 'sine.inOut' ) . '"';
                $item_data .= ' data-float-item-direction="' . esc_attr( $item['direction'] ?? 'both' ) . '"';
                $item_data .= ' data-float-item-scale="' . esc_attr( $item['scale'] ?? '1.02' ) . '"';
                $item_data .= ' data-float-item-opacity-min="' . esc_attr( $item['opacityMin'] ?? '1' ) . '"';
            }

            // 3D per-item
            if ( ! empty( $item['use3d'] ) && $item['use3d'] ) {
                $item_data .= ' data-float-item-3d="true"';
                $item_data .= ' data-float-item-rx="' . esc_attr( $item['rotateXRange'] ?? '10' ) . '"';
                $item_data .= ' data-float-item-ry="' . esc_attr( $item['rotateYRange'] ?? '20' ) . '"';
            }

            $images_html .= '<div class="dnxte-floating-element-item ' . esc_attr( $cls ) . '" style="' . esc_attr( $style ) . '"' . $item_data . '>';
            $images_html .= '<img src="' . esc_url( $src ) . '" alt="' . $alt . '" style="width:100%;height:auto;display:block;border-radius:inherit;" />';
            $images_html .= '</div>';
        }

        // Build container with config data attributes
        $container_attrs_str = '';
        foreach ( $config_attrs as $key => $val ) {
            $container_attrs_str .= ' ' . esc_attr( $key ) . '="' . esc_attr( $val ) . '"';
        }

        // No z-index on the container: a z-index here creates a stacking context
        // that traps each item's z-index inside this layer, so per-item z-index
        // could never push an element above/below the module's own content.
        // Whole-layer per-device disable.
        $wrap_cls = 'dnxte-fe-' . $uid . '-wrap';
        if ( $disable_tablet ) { $css .= "@media(max-width:980px) and (min-width:768px){.{$wrap_cls}{display:none;}}"; }
        if ( $disable_phone ) { $css .= "@media(max-width:767px){.{$wrap_cls}{display:none;}}"; }

        $style_block    = '' !== $css ? '<style>' . $css . '</style>' : '';
        $container_html = '<div class="dnxte-floating-elements-container ' . esc_attr( $wrap_cls ) . '" style="position:absolute;inset:0;pointer-events:none;overflow:hidden;"' . $container_attrs_str . '>' . $style_block . $images_html . '</div>';

        // Inject container after the first opening tag + ensure position:relative
        $injected = false;
        $module_wrapper = preg_replace_callback(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            function ( $matches ) use ( &$injected ) {
                if ( $injected ) {
                    return $matches[0];
                }
                $injected   = true;
                $tag        = $matches[1];
                $close      = $matches[2];

                // Add position:relative to existing style or add new style
                if ( preg_match( '/style\s*=\s*"([^"]*)"/i', $tag ) ) {
                    $tag = preg_replace(
                        '/style\s*=\s*"([^"]*)"/i',
                        'style="$1; position:relative;"',
                        $tag
                    );
                } else {
                    $tag .= ' style="position:relative;"';
                }

                return $tag . $close;
            },
            $module_wrapper,
            1
        );

        // Inject container HTML after first opening tag. Must be a callback:
        // $container_html carries builder-controlled item fields (esc_attr does
        // NOT escape `$`/`\`), so a literal `$0`/`$1` in e.g. an alt text would
        // expand as a PCRE backreference in a plain replacement string and break
        // out of its attribute (same bug class fixed in ImageMaskExtension).
        $module_wrapper = preg_replace_callback(
            '/^(<[a-zA-Z][^>]*>)/s',
            function ( $matches ) use ( $container_html ) {
                return $matches[1] . $container_html;
            },
            $module_wrapper,
            1
        );

        // Enqueue GSAP + floating JS
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );
        wp_enqueue_script( 'dnxte_floating_elements_js' );

        return et_core_esc_previously( $module_wrapper );
    }
}
