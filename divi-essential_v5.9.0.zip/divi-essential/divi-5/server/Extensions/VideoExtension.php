<?php
/**
 * Video Background Extension for Section
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class VideoExtension {

    private static $target_modules = [ 'divi/section', 'divi/row', 'divi/column' ];

    private static $fields = [
        'use_video_bg'     => 'off',
        'source_type'      => 'self-hosted',
        'video_url'        => '',
        'youtube_id'       => '',
        'vimeo_id'         => '',
        'fallback_image'   => '',
        'autoplay'         => 'on',
        'loop'             => 'on',
        'muted'            => 'on',
        'start_time'       => '0',
        'end_time'         => '0',
        'playback_speed'   => '1',
        'play_in_viewport' => 'on',
        'disable_on_mobile'=> 'off',
        'mobile_behavior'  => 'image',
        'lazy_load'        => 'on',
        'reduced_motion'   => 'on',
        'overlay_type'     => 'none',
        'overlay_color'    => 'rgba(0,0,0,0.4)',
        'overlay_opacity'  => '1',
        'object_fit'       => 'cover',
        'brightness'       => '100',
        'contrast'         => '100',
        'saturation'       => '100',
        'blur'             => '0',
        'scroll_effect'    => 'none',
        'scroll_intensity' => '1',
        'show_controls'    => 'off',
        'controls_position'=> 'bottom-right',
        'control_icon_size'=> '20',
        'control_icon_color'=> '#ffffff',
        'control_bg_color' => 'rgba(0,0,0,0.5)',
    ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend_scripts' ] );
    }

    public static function enqueue_frontend_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );
        wp_enqueue_script( 'dnxte-video-background' );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-video-background.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-video-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-video-background.js',
                'deps'               => [ 'dnxte-gsap', 'dnxte-trigger' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-video-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-video-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-video-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-video-engine' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $defaults = [];
        foreach ( self::$fields as $key => $val ) {
            $defaults[ $key ] = [ 'desktop' => [ 'value' => $val ] ];
        }

        $settings['attributes']['video_config'] = [
            'type'    => 'object',
            'default' => [ 'advanced' => $defaults ],
        ];

        return $settings;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $vc = $attrs['video_config']['advanced'] ?? [];
        if ( 'on' !== ( $vc['use_video_bg']['desktop']['value'] ?? 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Build data attributes from all fields
        $data = [];
        $key_map = [
            'source_type'      => 'source-type',
            'video_url'        => 'url',
            'youtube_id'       => 'youtube-id',
            'vimeo_id'         => 'vimeo-id',
            'fallback_image'   => 'fallback-image',
            'autoplay'         => 'autoplay',
            'loop'             => 'loop',
            'muted'            => 'muted',
            'start_time'       => 'start-time',
            'end_time'         => 'end-time',
            'playback_speed'   => 'playback-speed',
            'play_in_viewport' => 'play-in-viewport',
            'disable_on_mobile'=> 'disable-on-mobile',
            'mobile_behavior'  => 'mobile-behavior',
            'lazy_load'        => 'lazy-load',
            'reduced_motion'   => 'reduced-motion',
            'overlay_type'     => 'overlay-type',
            'overlay_color'    => 'overlay-color',
            'overlay_opacity'  => 'overlay-opacity',
            'object_fit'       => 'object-fit',
            'brightness'       => 'brightness',
            'contrast'         => 'contrast',
            'saturation'       => 'saturation',
            'blur'             => 'blur',
            'scroll_effect'    => 'scroll-effect',
            'scroll_intensity' => 'scroll-intensity',
            'show_controls'    => 'show-controls',
            'controls_position'=> 'controls-position',
            'control_icon_size'=> 'control-icon-size',
            'control_icon_color'=> 'control-icon-color',
            'control_bg_color' => 'control-bg-color',
        ];

        foreach ( $key_map as $php_key => $data_key ) {
            $val = $vc[ $php_key ]['desktop']['value'] ?? ( self::$fields[ $php_key ] ?? '' );
            // Convert on/off to true/false for boolean fields
            if ( in_array( $php_key, [ 'autoplay', 'loop', 'muted', 'play_in_viewport', 'disable_on_mobile', 'lazy_load', 'reduced_motion', 'show_controls' ], true ) ) {
                $val = $val === 'on' ? 'true' : 'false';
            }
            if ( ! empty( $val ) || $val === '0' ) {
                $data[ 'data-video-' . $data_key ] = $val;
            }
        }

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );
        wp_enqueue_script( 'dnxte-video-background' );

        return et_core_esc_previously( $module_wrapper );
    }
}
