<?php
/**
 * Image Mask Extension — masks, clip-paths, transforms & filters for images.
 *
 * Targets the Image modules + Section only, using NATIVE Divi fields (one
 * group-item per setting under image_mask.advanced.*). Single mask per module:
 * an Image module masks its own image, a Section masks ALL images inside it
 * (engine item is always target_type:'images'). The individual attrs are mapped
 * to the engine "item" here and emitted as a {items:[item]} JSON data-attr;
 * output is pure CSS applied by the shared engine (dnxte-image-mask.js).
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class ImageMaskExtension {

	public static function init() {
		add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
		add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ] );
	}

	/**
	 * Image modules + Section. Must match the TARGET list in
	 * assets/js/dnxte-image-mask-extension.js.
	 */
	private static $targets = [
		'divi/image', 'divi/fullwidth-image', 'divi/section',
	];

	private static function is_target( $name ) {
		return is_string( $name ) && in_array( $name, self::$targets, true );
	}

	public static function enqueue_frontend() {
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		wp_enqueue_script( 'dnxte_image_mask' );
	}

	public static function register_vb_scripts() {
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
			return;
		}

		// Shared engine (also used by the injector for live preview).
		$engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-image-mask.js';
		\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
			[
				'name'    => 'dnxte-image-mask-engine',
				'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
				'script'  => [
					'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-image-mask.js',
					'deps'               => [],
					'enqueue_top_window' => false,
					'enqueue_app_window' => true,
					'args'               => [ 'in_footer' => false ],
				],
			]
		);

		// VB injector (settings + live-preview EffectInjector) + repeater UI CSS.
		$ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-image-mask-extension.js';
		\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
			[
				'name'    => 'dnxte-image-mask-extension',
				'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
				'script'  => [
					'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-image-mask-extension.js',
					'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-image-mask-engine' ],
					'enqueue_top_window' => false,
					'enqueue_app_window' => true,
					'args'               => [ 'in_footer' => false ],
				],
				'style'   => [
					'src'                => DIVI_ESSENTIAL_URL . 'assets/css/dnxte-mask-fields.css',
					'enqueue_top_window' => true,
					'enqueue_app_window' => true,
				],
			]
		);
	}

	public static function filter_wrapper_render( $module_wrapper, $args ) {
		$name  = $args['name'] ?? '';
		$attrs = $args['attrs'] ?? [];

		if ( ! self::is_target( $name ) ) {
			return et_core_esc_previously( $module_wrapper );
		}

		$adv = $attrs['image_mask']['advanced'] ?? [];

		// Only inject when the mask is enabled.
		$enable = $adv['enable']['desktop']['value'] ?? 'off';
		if ( 'on' !== $enable ) {
			return et_core_esc_previously( $module_wrapper );
		}

		// Build the same engine "item" the VB builds from the native attrs, then
		// hand the engine a {items:[item]} JSON string verbatim.
		$config = wp_json_encode( [ 'items' => [ self::build_item( $adv ) ] ] );
		if ( ! is_string( $config ) || '' === $config ) {
			return et_core_esc_previously( $module_wrapper );
		}

		// The config must NOT be concatenated into a preg_replace() replacement
		// string: PHP expands $1/$2/\1 backreferences in the replacement *after*
		// esc_attr() has run, and esc_attr() does not escape `$`. A mask field
		// containing a literal `$1` would therefore expand to the module's own
		// opening tag — raw quotes included — breaking out of the attribute and
		// letting a Builder user inject arbitrary attributes such as onmouseover.
		// (It also silently corrupted innocent values like a "$1 OFF" mask text.)
		// preg_replace_callback() treats the replacement as data, not a template.
		$module_wrapper = preg_replace_callback(
			'/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
			static function ( $matches ) use ( $config ) {
				return $matches[1] . ' data-dnxte-mask="' . esc_attr( $config ) . '"' . $matches[2];
			},
			$module_wrapper,
			1
		);

		return et_core_esc_previously( $module_wrapper );
	}

	/**
	 * Read a desktop value off image_mask.advanced.<field>.
	 */
	private static function dv( $adv, $field, $fallback ) {
		$v = $adv[ $field ]['desktop']['value'] ?? null;
		return ( null !== $v && '' !== $v ) ? $v : $fallback;
	}

	/**
	 * Raw tablet/phone value (null when unset) — for responsive transform fields.
	 *
	 * @param array  $adv    Advanced attrs.
	 * @param string $field  Field key.
	 * @param string $device 'tablet' | 'phone'.
	 * @return mixed|null
	 */
	private static function dv_dev( $adv, $field, $device ) {
		$v = $adv[ $field ][ $device ]['value'] ?? null;
		return ( null !== $v && '' !== $v ) ? $v : null;
	}

	/**
	 * Map the native image_mask.advanced.* attrs to the engine "item" object.
	 * Keep in sync with buildItem() in dnxte-image-mask-extension.js.
	 */
	private static function build_item( $adv ) {
		return [
			'enabled'      => self::dv( $adv, 'enable', 'off' ),
			'target_type'  => 'images',
			'maskType'     => self::dv( $adv, 'maskType', 'preset' ),
			'maskPreset'   => self::dv( $adv, 'maskShape', 'blob1' ),
			'customSvg'    => self::dv( $adv, 'customSvg', '' ),
			'clipPath'     => self::dv( $adv, 'clipPath', '' ),
			'invert'       => self::dv( $adv, 'invert', 'off' ),
			'scale'        => self::num( self::dv( $adv, 'scale', 100 ), 100 ),
			'posX'         => self::num( self::dv( $adv, 'posX', 0 ), 0 ),
			'posY'         => self::num( self::dv( $adv, 'posY', 0 ), 0 ),
			'rotation'     => self::num( self::dv( $adv, 'rotation', 0 ), 0 ),
			'scaleTablet'    => self::dv_dev( $adv, 'scale', 'tablet' ),
			'scalePhone'     => self::dv_dev( $adv, 'scale', 'phone' ),
			'posXTablet'     => self::dv_dev( $adv, 'posX', 'tablet' ),
			'posXPhone'      => self::dv_dev( $adv, 'posX', 'phone' ),
			'posYTablet'     => self::dv_dev( $adv, 'posY', 'tablet' ),
			'posYPhone'      => self::dv_dev( $adv, 'posY', 'phone' ),
			'rotationTablet' => self::dv_dev( $adv, 'rotation', 'tablet' ),
			'rotationPhone'  => self::dv_dev( $adv, 'rotation', 'phone' ),
			'fadeDir'      => self::dv( $adv, 'fadeDir', 'edges' ),
			'fadeAmount'   => self::num( self::dv( $adv, 'fadeAmount', 30 ), 30 ),
			'patternType'  => self::dv( $adv, 'patternType', 'dots' ),
			'patternScale' => self::num( self::dv( $adv, 'patternScale', 24 ), 24 ),
			'mediaUrl'     => self::dv( $adv, 'mediaUrl', '' ),
			'drift'        => self::dv( $adv, 'drift', 'off' ),
			'driftSpeed'   => self::num( self::dv( $adv, 'driftSpeed', 8 ), 8 ),
			'filters'      => [
				'brightness' => self::num( self::dv( $adv, 'brightness', 100 ), 100 ),
				'contrast'   => self::num( self::dv( $adv, 'contrast', 100 ), 100 ),
				'saturate'   => self::num( self::dv( $adv, 'saturate', 100 ), 100 ),
			],
			'disableTablet' => self::dv( $adv, 'disableTablet', 'off' ),
			'disablePhone'  => self::dv( $adv, 'disablePhone', 'off' ),
		];
	}

	/**
	 * Numeric coercion mirroring the JS num() helper (parseFloat).
	 *
	 * divi/range values are stored WITH their unit (e.g. "150%", "45deg", "8s"),
	 * so a plain is_numeric() check fails and every transform fell back to its
	 * default on the front-end. Parse the leading number like parseFloat does.
	 */
	private static function num( $v, $d ) {
		if ( null === $v || '' === $v ) {
			return $d;
		}
		if ( is_numeric( $v ) ) {
			return 0 + $v;
		}
		if ( is_string( $v ) && preg_match( '/^-?\d*\.?\d+/', $v, $m ) ) {
			return 0 + $m[0];
		}
		return $d;
	}
}
