<?php
/**
 * Section Particle Effects Extension
 *
 * Injects 40 GSAP-based particle effects into Divi Section modules.
 *
 * @package DNXTE\Extensions
 * @since ??
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class ParticlesExtension {

    private static $target_modules = [ 'divi/section', 'divi/row', 'divi/column' ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend_scripts' ] );
    }

    /**
     * Register VB extension scripts.
     */
    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        // Particle engine
        $engine_path = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-particles.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
            [
                'name'    => 'dnxte-particles-engine',
                'version' => file_exists( $engine_path ) ? filemtime( $engine_path ) : DIVI_ESSENTIAL_VERSION,
                'script'  => [
                    'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-particles.js',
                    'deps'               => [ 'dnxte-gsap', 'dnxte-trigger' ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                    'args'               => [ 'in_footer' => false ],
                ],
            ]
        );

        // VB hooks extension
        $ext_path = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-particles-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
            [
                'name'    => 'dnxte-particles-extension',
                'version' => file_exists( $ext_path ) ? filemtime( $ext_path ) : DIVI_ESSENTIAL_VERSION,
                'script'  => [
                    'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-particles-extension.js',
                    'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-particles-engine' ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                    'args'               => [ 'in_footer' => false ],
                ],
            ]
        );
    }

    /**
     * Enqueue frontend scripts when particle effects are used.
     */
    public static function enqueue_frontend_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }

        // Enqueue GSAP + ScrollTrigger + particle engine for frontend
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );

        wp_enqueue_script(
            'dnxte-particles-engine',
            DIVI_ESSENTIAL_URL . 'assets/js/dnxte-particles.js',
            [ 'dnxte-gsap', 'dnxte-trigger' ],
            file_exists( DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-particles.js' )
                ? filemtime( DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-particles.js' )
                : DIVI_ESSENTIAL_VERSION,
            true
        );
    }

    /**
     * Register particle attributes on target modules.
     */
    public static function register_attributes( $settings ) {
        $module_name = $settings['name'] ?? '';

        if ( ! in_array( $module_name, self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['particle_settings'] = [
            'type'    => 'object',
            'default' => [
                'decoration' => [
                    'color1' => [ 'desktop' => [ 'value' => '#00d4aa' ] ],
                    'color2' => [ 'desktop' => [ 'value' => '#7c3aed' ] ],
                    'color3' => [ 'desktop' => [ 'value' => '' ] ],
                    'color4' => [ 'desktop' => [ 'value' => '' ] ],
                ],
                'advanced' => [
                    'use_particles'       => [ 'desktop' => [ 'value' => 'off' ] ],
                    'particle_type'       => [ 'desktop' => [ 'value' => 'snowfall' ] ],
                    'count'               => [ 'desktop' => [ 'value' => '40' ] ],
                    'speed'               => [ 'desktop' => [ 'value' => '1' ] ],
                    'size'                => [ 'desktop' => [ 'value' => '1' ] ],
                    'opacity'             => [ 'desktop' => [ 'value' => '0.8' ] ],
                    'trigger'             => [ 'desktop' => [ 'value' => 'always' ] ],
                    'effect_width'        => [ 'desktop' => [ 'value' => '100' ] ],
                    'glow'                => [ 'desktop' => [ 'value' => 'off' ] ],
                    'glow_intensity'      => [ 'desktop' => [ 'value' => '1' ] ],
                    'wind'                => [ 'desktop' => [ 'value' => '0' ] ],
                    'wind_strength'       => [ 'desktop' => [ 'value' => '1' ] ],
                    'burst_interval'      => [ 'desktop' => [ 'value' => '2000' ] ],
                    'connection_distance' => [ 'desktop' => [ 'value' => '150' ] ],
                    'force_strength'      => [ 'desktop' => [ 'value' => '1' ] ],
                    'force_radius'        => [ 'desktop' => [ 'value' => '150' ] ],
                ],
            ],
        ];

        return $settings;
    }

    /**
     * Inject data attributes into frontend HTML.
     */
    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $module_name  = $args['name'] ?? '';
        $module_attrs = $args['attrs'] ?? [];

        if ( ! in_array( $module_name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $use_particles = $module_attrs['particle_settings']['advanced']['use_particles']['desktop']['value'] ?? 'off';

        if ( 'on' !== $use_particles ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $ps = $module_attrs['particle_settings'];

        $color3 = $ps['decoration']['color3']['desktop']['value'] ?? '';
        $color4 = $ps['decoration']['color4']['desktop']['value'] ?? '';

        $data_attrs = [
            'data-particle-type'                => $ps['advanced']['particle_type']['desktop']['value'] ?? 'snowfall',
            'data-particle-count'               => $ps['advanced']['count']['desktop']['value'] ?? '40',
            'data-particle-speed'               => $ps['advanced']['speed']['desktop']['value'] ?? '1',
            'data-particle-color1'              => $ps['decoration']['color1']['desktop']['value'] ?? '#00d4aa',
            'data-particle-color2'              => $ps['decoration']['color2']['desktop']['value'] ?? '#7c3aed',
            'data-particle-size'                => $ps['advanced']['size']['desktop']['value'] ?? '1',
            'data-particle-opacity'             => $ps['advanced']['opacity']['desktop']['value'] ?? '0.8',
            'data-particle-trigger'             => $ps['advanced']['trigger']['desktop']['value'] ?? 'always',
            'data-particle-effect-width'        => $ps['advanced']['effect_width']['desktop']['value'] ?? '100',
            'data-particle-glow'                => ( $ps['advanced']['glow']['desktop']['value'] ?? 'off' ) === 'on' ? 'true' : 'false',
            'data-particle-glow-intensity'      => $ps['advanced']['glow_intensity']['desktop']['value'] ?? '1',
            'data-particle-wind'                => $ps['advanced']['wind']['desktop']['value'] ?? '0',
            'data-particle-wind-strength'       => $ps['advanced']['wind_strength']['desktop']['value'] ?? '1',
            'data-particle-burst-interval'      => $ps['advanced']['burst_interval']['desktop']['value'] ?? '2000',
            'data-particle-connection-distance'  => $ps['advanced']['connection_distance']['desktop']['value'] ?? '150',
            'data-particle-force-strength'      => $ps['advanced']['force_strength']['desktop']['value'] ?? '1',
            'data-particle-force-radius'        => $ps['advanced']['force_radius']['desktop']['value'] ?? '150',
        ];

        // Only add color3/color4 if set
        if ( ! empty( $color3 ) ) {
            $data_attrs['data-particle-color3'] = $color3;
        }
        if ( ! empty( $color4 ) ) {
            $data_attrs['data-particle-color4'] = $color4;
        }

        // Build attribute string
        $attr_string = '';
        foreach ( $data_attrs as $key => $val ) {
            $attr_string .= ' ' . esc_attr( $key ) . '="' . esc_attr( $val ) . '"';
        }

        // Inject into first opening tag
        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_string . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
