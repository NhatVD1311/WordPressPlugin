<?php
/**
 * Section Cursor & Trail Effects Extension
 *
 * 50 cursor/trail/image-trail effects on Divi Section.
 *
 * @package DNXTE\Extensions
 * @since ??
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class CursorExtension {

    private static $target_modules = [ 'divi/section', 'divi/row', 'divi/column' ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-cursor-effects.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-cursor-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-cursor-effects.js',
                'deps'               => [ 'dnxte-gsap' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-cursor-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-cursor-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-cursor-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-cursor-engine' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['cursor_config'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'use_cursor'      => [ 'desktop' => [ 'value' => 'off' ] ],
                    'cursor_type'     => [ 'desktop' => [ 'value' => 'circle-follower' ] ],
                    'color1'          => [ 'desktop' => [ 'value' => '#00d4aa' ] ],
                    'color2'          => [ 'desktop' => [ 'value' => '#7c3aed' ] ],
                    'size'            => [ 'desktop' => [ 'value' => '30' ] ],
                    'speed'           => [ 'desktop' => [ 'value' => '0.3' ] ],
                    'trail_length'    => [ 'desktop' => [ 'value' => '25' ] ],
                    'fade_ms'         => [ 'desktop' => [ 'value' => '800' ] ],
                    'image_urls'      => [ 'desktop' => [ 'value' => '' ] ],
                    'image_size'      => [ 'desktop' => [ 'value' => '100' ] ],
                    'image_threshold' => [ 'desktop' => [ 'value' => '60' ] ],
                    'cursor_text'     => [ 'desktop' => [ 'value' => 'HELLO' ] ],
                ],
            ],
        ];

        return $settings;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $cc = $attrs['cursor_config']['advanced'] ?? [];
        if ( 'on' !== ( $cc['use_cursor']['desktop']['value'] ?? 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Build data attributes
        $data = [
            'data-cursor-type'            => $cc['cursor_type']['desktop']['value'] ?? 'circle-follower',
            'data-cursor-color1'          => $cc['color1']['desktop']['value'] ?? '#00d4aa',
            'data-cursor-color2'          => $cc['color2']['desktop']['value'] ?? '#7c3aed',
            'data-cursor-size'            => $cc['size']['desktop']['value'] ?? '30',
            'data-cursor-speed'           => $cc['speed']['desktop']['value'] ?? '0.3',
            'data-cursor-trail-length'    => $cc['trail_length']['desktop']['value'] ?? '25',
            'data-cursor-fade-ms'         => $cc['fade_ms']['desktop']['value'] ?? '800',
            'data-cursor-image-size'      => $cc['image_size']['desktop']['value'] ?? '100',
            'data-cursor-image-threshold' => $cc['image_threshold']['desktop']['value'] ?? '60',
            'data-cursor-text'            => $cc['cursor_text']['desktop']['value'] ?? 'HELLO',
        ];

        // Image URLs (only if set)
        $img_urls = $cc['image_urls']['desktop']['value'] ?? '';
        if ( ! empty( $img_urls ) ) {
            $data['data-cursor-images'] = $img_urls;
        }

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        // Inject into first tag
        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        // Enqueue scripts
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-cursor-effects' );

        return et_core_esc_previously( $module_wrapper );
    }
}
