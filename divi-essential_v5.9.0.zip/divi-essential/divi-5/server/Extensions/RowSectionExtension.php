<?php
/**
 * Row/Section/Column Extension - Spotlight & Card Effects
 *
 * Injects Spotlight and Card Effects options into Divi Row, Column, and Section modules.
 *
 * @package DNXTE\Extensions
 * @since ??
 */

namespace DNXTE\Extensions;

use DNXTE\Modules\Utils\CardEffectsUtils;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class RowSectionExtension {

    /**
     * Feature flags — set from divi-5.php before init().
     */
    public static $spotlight_enabled = true;
    public static $card_enabled      = true;

    /**
     * Target modules for spotlight effect.
     */
    private static $spotlight_targets = [ 'divi/row', 'divi/column', 'divi/section', 'divi/blurb', 'divi/blog', 'divi/fullwidth-header' ];

    /**
     * Target modules for card effects.
     */
    private static $card_targets = [ 'divi/row', 'divi/column', 'divi/section', 'divi/blurb', 'divi/fullwidth-header' ];

    /**
     * Initialize the extension.
     */
    public static function init() {
        // Register VB script
        add_action( 'wp', [ __CLASS__, 'register_vb_script' ] );

        // Register attributes (PHP side)
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );

        // Modify frontend wrapper output
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );

        // Enqueue frontend engine assets only for the effects this extension has enabled.
        // Priority 20 so the handles registered in includes/Frontend/Assets.php (priority 10)
        // already exist.
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ], 20 );
    }

    /**
     * Enqueue the frontend engine assets for whichever effects are enabled.
     *
     * Handles are registered (register-only) in includes/Frontend/Assets.php; we
     * enqueue them here so disabling the extension stops the assets from loading.
     */
    public static function enqueue_frontend() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }

        if ( self::$spotlight_enabled ) {
            wp_enqueue_style( 'spotlight_css' );
            wp_enqueue_script( 'dnxte_spotlight_card_effects' );
        }

        if ( self::$card_enabled ) {
            wp_enqueue_style( 'effect_card_css' );
            wp_enqueue_script( 'dnxte_effect_card_js' );
        }
    }

    /**
     * Print the Visual Builder feature flags as an inline script.
     *
     * Uses an inline-only handle (src = false) so the flags go through the
     * WordPress script API instead of being echoed straight into wp_head.
     */
    public static function enqueue_vb_flags() {
        wp_register_script( 'dnxte-row-section-flags', false, [], DIVI_ESSENTIAL_VERSION, false );
        wp_enqueue_script( 'dnxte-row-section-flags' );
        wp_add_inline_script(
            'dnxte-row-section-flags',
            'window.dnxteRowSectionFlags=' . wp_json_encode(
                [
                    'spotlight' => (bool) self::$spotlight_enabled,
                    'card'      => (bool) self::$card_enabled,
                ]
            ) . ';',
            'before'
        );
    }

    /**
     * Register the Visual Builder extension script.
     */
    public static function register_vb_script() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        // Pass feature flags to JS via a data-only script handle rather than a raw
        // echo into wp_head. Registering with src=false makes this an inline-only
        // handle; enqueueing at wp_enqueue_scripts priority 1 puts it at the front
        // of the head queue, so it still prints before the package builds below
        // (which are head scripts too) and before assets/js/dnxte-row-section-extension.js
        // reads window.dnxteRowSectionFlags.
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_vb_flags' ], 1 );

        // Spotlight engine + CSS for the VB is now registered UNCONDITIONALLY in
        // divi-5/divi-5.php (shared by modules like Blurb too), so it is not
        // re-registered here to avoid a duplicate package build.

        // Card effects engine (needed by EffectInjector in VB)
        if ( self::$card_enabled ) {
            // Three.js — required by the Laser Flow & Floating Lines effects.
            // Registered as its own app-window build so it loads before the
            // engine (referenced in the engine's deps below).
            $three_path = DIVI_ESSENTIAL_DIR . 'assets/js/three.min.js';
            \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
                [
                    'name'    => 'dnxte-three-vb',
                    'version' => file_exists( $three_path ) ? filemtime( $three_path ) : DIVI_ESSENTIAL_VERSION,
                    'script'  => [
                        'src'                => DIVI_ESSENTIAL_URL . 'assets/js/three.min.js',
                        'deps'               => [],
                        'enqueue_top_window' => false,
                        'enqueue_app_window' => true,
                        'args'               => [ 'in_footer' => false ],
                    ],
                ]
            );

            $effect_path = DIVI_ESSENTIAL_DIR . 'assets/js/effect-card.js';
            \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
                [
                    'name'    => 'dnxte-effect-card-vb',
                    'version' => file_exists( $effect_path ) ? filemtime( $effect_path ) : DIVI_ESSENTIAL_VERSION,
                    'script'  => [
                        'src'                => DIVI_ESSENTIAL_URL . 'assets/js/effect-card.js',
                        'deps'               => [ 'dnxte-three-vb' ],
                        'enqueue_top_window' => false,
                        'enqueue_app_window' => true,
                        'args'               => [ 'in_footer' => false ],
                    ],
                ]
            );
        }

        $script_path = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-row-section-extension.js';

        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
            [
                'name'    => 'dnxte-row-section-extension',
                'version' => file_exists( $script_path ) ? filemtime( $script_path ) : DIVI_ESSENTIAL_VERSION,
                'script'  => [
                    'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-row-section-extension.js',
                    'deps'               => [
                        'divi-module-library',
                        'divi-vendor-wp-hooks',
                    ],
                    'enqueue_top_window' => false,
                    'enqueue_app_window' => true,
                    'args'               => [
                        'in_footer' => false,
                    ],
                ],
            ]
        );
    }

    /**
     * Register spotlight and card effect attributes on target modules (PHP side).
     *
     * @param array $settings Block type settings.
     * @return array Modified settings.
     */
    public static function register_attributes( $settings ) {
        $module_name = $settings['name'] ?? '';

        $is_spotlight_target = self::$spotlight_enabled && in_array( $module_name, self::$spotlight_targets, true );
        $is_card_target      = self::$card_enabled && in_array( $module_name, self::$card_targets, true );

        if ( ! $is_spotlight_target && ! $is_card_target ) {
            return $settings;
        }

        // Spotlight settings attribute
        if ( $is_spotlight_target ) {
        $settings['attributes']['spotlight_settings'] = [
            'type'    => 'object',
            'default' => [
                'decoration' => [
                    'color'  => [ 'desktop' => [ 'value' => '#29c4a9' ] ],
                    'color2' => [ 'desktop' => [ 'value' => '' ] ],
                ],
                'advanced' => [
                    'use_spotlight'      => [ 'desktop' => [ 'value' => 'off' ] ],
                    'variant'            => [ 'desktop' => [ 'value' => 'default' ] ],
                    'mode'               => [ 'desktop' => [ 'value' => 'hover' ] ],
                    'autoplay'           => [ 'desktop' => [ 'value' => 'off' ] ],
                    'autoplay_animation' => [ 'desktop' => [ 'value' => 'circle' ] ],
                    'spotlightSize'      => [ 'desktop' => [ 'value' => '330px' ] ],
                    'intensity'          => [ 'desktop' => [ 'value' => '0.50' ] ],
                    'speed'              => [ 'desktop' => [ 'value' => '3000' ] ],
                ],
            ],
        ];

        } // end spotlight target

        // Card effects attribute
        if ( $is_card_target ) {
        $settings['attributes']['card_effects'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'use_card_effect'   => [ 'desktop' => [ 'value' => 'off' ] ],
                    'effect_type'       => [ 'desktop' => [ 'value' => 'electric-border' ] ],
                    'speed'             => [ 'desktop' => [ 'value' => 1 ] ],
                    'intensity'         => [ 'desktop' => [ 'value' => '1' ] ],
                    'chaos'             => [ 'desktop' => [ 'value' => '0.12' ] ],
                    'radius'            => [ 'desktop' => [ 'value' => '0' ] ],
                    'lightning_size'    => [ 'desktop' => [ 'value' => '1.0' ] ],
                    'offset_x'         => [ 'desktop' => [ 'value' => '0' ] ],
                    'line_count'        => [ 'desktop' => [ 'value' => 6 ] ],
                    'enable_wave'       => [ 'desktop' => [ 'value' => [ 'top', 'middle', 'bottom' ] ] ],
                    'wisp_density'      => [ 'desktop' => [ 'value' => '1.0' ] ],
                    'fog_density'       => [ 'desktop' => [ 'value' => '0.45' ] ],
                    'flow_speed'        => [ 'desktop' => [ 'value' => '0.35' ] ],
                    'horizontal_offset' => [ 'desktop' => [ 'value' => '0.10' ] ],
                    'vertical_offset'   => [ 'desktop' => [ 'value' => '0.00' ] ],
                    'vertical_sizing'   => [ 'desktop' => [ 'value' => '2.0' ] ],
                    'horizontal_sizing' => [ 'desktop' => [ 'value' => '0.5' ] ],
                    'wisp_intensity'    => [ 'desktop' => [ 'value' => '5.0' ] ],
                ],
                'decoration' => [
                    'primary_color'   => [ 'desktop' => [ 'value' => '#5227FF' ] ],
                    'secondary_color' => [ 'desktop' => [ 'value' => '#FF9FFC' ] ],
                ],
            ],
        ];
        } // end card target

        return $settings;
    }

    /**
     * Modify frontend HTML output to inject data attributes for Spotlight & Card Effects.
     *
     * @param string $module_wrapper The rendered module HTML.
     * @param array  $args           Module arguments (name, attrs, elements, etc.).
     * @return string Modified HTML.
     */
    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $module_name  = $args['name'] ?? '';
        $module_attrs = $args['attrs'] ?? [];

        $is_spotlight_target = self::$spotlight_enabled && in_array( $module_name, self::$spotlight_targets, true );
        $is_card_target      = self::$card_enabled && in_array( $module_name, self::$card_targets, true );

        if ( ! $is_spotlight_target && ! $is_card_target ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $use_spotlight   = $is_spotlight_target ? ( $module_attrs['spotlight_settings']['advanced']['use_spotlight']['desktop']['value'] ?? 'off' ) : 'off';
        $use_card_effect = $is_card_target ? ( $module_attrs['card_effects']['advanced']['use_card_effect']['desktop']['value'] ?? 'off' ) : 'off';

        if ( 'on' !== $use_spotlight && 'on' !== $use_card_effect ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Build data attributes to inject
        $data_attrs = [];
        $style_parts = [];

        // ─── Spotlight ───
        $is_blog = ( $module_name === 'divi/blog' );

        if ( 'on' === $use_spotlight ) {
            $sa = $module_attrs['spotlight_settings'];

            $spotlight_color     = $sa['decoration']['color']['desktop']['value'] ?? '#29c4a9';
            $spotlight_color2    = $sa['decoration']['color2']['desktop']['value'] ?? '';
            $spotlight_variant   = $sa['advanced']['variant']['desktop']['value'] ?? 'default';
            $spotlight_mode      = $sa['advanced']['mode']['desktop']['value'] ?? 'hover';
            $spotlight_autoplay  = $sa['advanced']['autoplay']['desktop']['value'] ?? 'off';
            $spotlight_size      = $sa['advanced']['spotlightSize']['desktop']['value'] ?? '330px';
            $spotlight_intensity = $sa['advanced']['intensity']['desktop']['value'] ?? '0.50';
            $spotlight_speed     = $sa['advanced']['speed']['desktop']['value'] ?? '3000';
            $spotlight_animation = $sa['advanced']['autoplay_animation']['desktop']['value'] ?? 'circle';

            $spotlight_attrs = array(
                'data-spotlight-card'           => '',
                'data-spotlight-color'          => $spotlight_color,
                'data-spotlight-gradient-colors' => "$spotlight_color, $spotlight_color2",
                'data-spotlight-size'           => $spotlight_size,
                'data-spotlight-intensity'      => $spotlight_intensity,
                'data-spotlight-variant'        => $spotlight_variant,
                'data-spotlight-mode'           => $spotlight_mode,
                'data-spotlight-autoplay'       => $spotlight_autoplay === 'on' ? 'true' : 'false',
            );

            if ( 'on' === $spotlight_autoplay ) {
                $spotlight_attrs['data-spotlight-autoplay-type']  = $spotlight_animation;
                $spotlight_attrs['data-spotlight-autoplay-speed'] = ! empty( $spotlight_speed ) ? intval( $spotlight_speed ) : 3000;
            }

            if ( $is_blog ) {
                // Blog: add data attr on wrapper telling JS to init on each child post
                $data_attrs['data-spotlight-children'] = '.et_pb_post';
                // Store spotlight config as JSON for JS to read
                $data_attrs['data-spotlight-config'] = wp_json_encode( $spotlight_attrs );
            } else {
                // Non-blog: add spotlight directly on wrapper
                $data_attrs = array_merge( $data_attrs, $spotlight_attrs );
            }
        }

        // ─── Card Effects ───
        if ( 'on' === $use_card_effect ) {
            $card_effects_data   = CardEffectsUtils::get_card_effects_attrs( $module_attrs );
            $card_effects_styles = CardEffectsUtils::get_card_effects_styles( $module_attrs );

            $data_attrs = array_merge( $data_attrs, $card_effects_data );

            if ( ! empty( $card_effects_styles ) ) {
                $style_parts[] = $card_effects_styles;
            }
        }

        // Inject attributes into the first element of the wrapper HTML
        if ( empty( $data_attrs ) && empty( $style_parts ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Build attribute string
        $attr_string = '';
        foreach ( $data_attrs as $key => $val ) {
            if ( '' === $val ) {
                $attr_string .= ' ' . esc_attr( $key );
            } else {
                $attr_string .= ' ' . esc_attr( $key ) . '="' . esc_attr( $val ) . '"';
            }
        }

        // Build style string
        $style_string = '';
        if ( ! empty( $style_parts ) ) {
            $style_string = implode( '; ', $style_parts );
        }

        // Inject into the first opening tag using regex
        // Find the first > in the wrapper and inject before it
        $injected = false;

        $module_wrapper = preg_replace_callback(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            function ( $matches ) use ( $attr_string, $style_string, &$injected ) {
                if ( $injected ) {
                    return $matches[0];
                }
                $injected = true;

                $tag_content = $matches[1];
                $tag_close   = $matches[2];

                // Merge style attribute
                if ( ! empty( $style_string ) ) {
                    if ( preg_match( '/style\s*=\s*"([^"]*)"/i', $tag_content ) ) {
                        $tag_content = preg_replace(
                            '/style\s*=\s*"([^"]*)"/i',
                            'style="$1; ' . esc_attr( $style_string ) . '"',
                            $tag_content
                        );
                    } else {
                        $attr_string .= ' style="' . esc_attr( $style_string ) . '"';
                    }
                }

                return $tag_content . $attr_string . $tag_close;
            },
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
