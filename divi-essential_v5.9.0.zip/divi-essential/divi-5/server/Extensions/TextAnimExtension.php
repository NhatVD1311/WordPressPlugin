<?php
/**
 * Text Animation Extension for Heading & Text modules
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class TextAnimExtension {

    private static $target_modules = [ 'divi/heading', 'divi/text' ];

    private static $fields = [
        'use_text_anim'  => 'off',
        'anim_type'      => 'blur',
        'direction'      => 'left',
        'speed'          => '1',
        'stagger'        => '0.08',
        'color1'         => '#00d4aa',
        'color2'         => '#7c3aed',
        'repeat_anim'    => 'on',
        'words'          => '',
        'glitch_variant' => 'classic',
        'focus_mode'     => 'auto',
        'typing_speed'   => '60',
        'deleting_speed' => '35',
        'pause_duration' => '2000',
        'cursor_char'    => '|',
        'cursor_blink'   => '0.5',
        'show_cursor'    => 'on',
        'variable_speed' => 'on',
        'var_speed_min'  => '40',
        'var_speed_max'  => '120',
        'texture_url'    => '',
    ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ] );
    }

    public static function enqueue_frontend() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-text-animation' );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-text-animation.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-text-anim-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-text-animation.js',
                'deps'               => [ 'dnxte-gsap' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-text-anim-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-text-anim-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-text-anim-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-text-anim-engine' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $defaults = [];
        foreach ( self::$fields as $key => $val ) {
            $defaults[ $key ] = [ 'desktop' => [ 'value' => $val ] ];
        }

        $settings['attributes']['text_anim'] = [
            'type'    => 'object',
            'default' => [ 'advanced' => $defaults ],
        ];

        return $settings;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $ta = $attrs['text_anim']['advanced'] ?? [];
        if ( 'on' !== ( $ta['use_text_anim']['desktop']['value'] ?? 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $key_map = [
            'anim_type'      => 'anim',
            'direction'      => 'direction',
            'speed'          => 'speed',
            'stagger'        => 'stagger',
            'color1'         => 'color1',
            'color2'         => 'color2',
            'repeat_anim'    => 'repeat',
            'words'          => 'words',
            'glitch_variant' => 'glitch',
            'focus_mode'     => 'focus-mode',
            'typing_speed'   => 'typing-speed',
            'deleting_speed' => 'deleting-speed',
            'pause_duration' => 'pause-duration',
            'cursor_char'    => 'cursor-char',
            'cursor_blink'   => 'cursor-blink',
            'show_cursor'    => 'show-cursor',
            'variable_speed' => 'variable-speed',
            'var_speed_min'  => 'var-speed-min',
            'var_speed_max'  => 'var-speed-max',
            'texture_url'    => 'texture-url',
        ];

        $data = [];
        foreach ( $key_map as $php_key => $data_key ) {
            $val = $ta[ $php_key ]['desktop']['value'] ?? ( self::$fields[ $php_key ] ?? '' );
            if ( in_array( $php_key, [ 'repeat_anim', 'show_cursor', 'variable_speed' ], true ) ) {
                $val = $val === 'on' ? 'true' : 'false';
            }
            if ( ! empty( $val ) || $val === '0' ) {
                $data[ 'data-text-' . $data_key ] = $val;
            }
        }

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
