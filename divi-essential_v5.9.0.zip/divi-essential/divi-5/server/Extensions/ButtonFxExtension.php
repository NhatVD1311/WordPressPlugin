<?php
/**
 * Button FX Extension — Glow border, ripple, celebration for Button modules
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class ButtonFxExtension {

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
        // No unconditional wp_enqueue_scripts hook: the engine (dnxte-button-fx) is
        // registered in includes/Frontend/Assets.php and enqueued from
        // filter_wrapper_render() only when a button on this view actually uses FX.
        // It's an in_footer script, so enqueuing during the_content render is in time.
    }

    private static function is_target( $name ) {
        if ( empty( $name ) ) return false;
        if ( $name === 'divi/button' ) return true;
        if ( strpos( $name, 'dnxte/' ) === 0 && stripos( $name, 'button' ) !== false ) return true;
        return false;
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-button-fx-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-button-fx-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-button-fx-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-button-fx.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-button-fx-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-button-fx.js',
                'deps'               => [],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        $name = $settings['name'] ?? '';
        if ( ! self::is_target( $name ) ) {
            return $settings;
        }

        // Register attribute so PHP can read it from saved data on frontend render
        $settings['attributes']['dnxte_button_fx'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'use_button_fx'      => [ 'desktop' => [ 'value' => 'off' ] ],
                    'glow_enabled'       => [ 'desktop' => [ 'value' => 'off' ] ],
                    'glow_color1'        => [ 'desktop' => [ 'value' => '#7C3AED' ] ],
                    'glow_color2'        => [ 'desktop' => [ 'value' => '#06B6D4' ] ],
                    'glow_color3'        => [ 'desktop' => [ 'value' => '#F43F5E' ] ],
                    'glow_intensity'     => [ 'desktop' => [ 'value' => '1' ] ],
                    'glow_blur'          => [ 'desktop' => [ 'value' => '15' ] ],
                    'glow_spread'        => [ 'desktop' => [ 'value' => '25' ] ],
                    'ripple_enabled'     => [ 'desktop' => [ 'value' => 'off' ] ],
                    'ripple_color'       => [ 'desktop' => [ 'value' => 'rgba(255,255,255,0.35)' ] ],
                    'celebration_type'   => [ 'desktop' => [ 'value' => 'none' ] ],
                    'celebration_count'  => [ 'desktop' => [ 'value' => '30' ] ],
                    'celebration_trigger' => [ 'desktop' => [ 'value' => 'always' ] ],
                ],
            ],
        ];

        return $settings;
    }

    private static function get_val( $attrs, $key, $default = '' ) {
        return $attrs['dnxte_button_fx']['advanced'][ $key ]['desktop']['value'] ?? $default;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! self::is_target( $name ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        if ( 'on' !== self::get_val( $attrs, 'use_button_fx', 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // A button on this view uses FX — load the engine (registered in Assets.php).
        wp_enqueue_script( 'dnxte-button-fx' );

        $cfg = [
            'enabled'            => 'on',
            'glowBorder'         => self::get_val( $attrs, 'glow_enabled', 'off' ),
            'glowColor1'         => self::get_val( $attrs, 'glow_color1', '#7C3AED' ),
            'glowColor2'         => self::get_val( $attrs, 'glow_color2', '#06B6D4' ),
            'glowColor3'         => self::get_val( $attrs, 'glow_color3', '#F43F5E' ),
            'glowIntensity'      => self::get_val( $attrs, 'glow_intensity', '1' ),
            'glowBlur'           => self::get_val( $attrs, 'glow_blur', '15' ),
            'glowSpread'         => self::get_val( $attrs, 'glow_spread', '25' ),
            'glowAutoPlay'       => self::get_val( $attrs, 'glow_auto_play', 'off' ),
            'glowAutoSpeed'      => self::get_val( $attrs, 'glow_auto_speed', '3' ),
            'ripple'             => self::get_val( $attrs, 'ripple_enabled', 'off' ),
            'rippleColor'        => self::get_val( $attrs, 'ripple_color', 'rgba(255,255,255,0.35)' ),
            'celebration'        => self::get_val( $attrs, 'celebration_type', 'none' ),
            'celebrationCount'   => self::get_val( $attrs, 'celebration_count', '30' ),
            'celebrationTrigger' => self::get_val( $attrs, 'celebration_trigger', 'always' ),
        ];

        $data = [
            'data-btn-fx-init'   => 'true',
            'data-btn-fx-config' => wp_json_encode( $cfg ),
        ];

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
