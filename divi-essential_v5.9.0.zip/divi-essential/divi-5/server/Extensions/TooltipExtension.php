<?php
/**
 * Tooltip Extension — Adds hover/click tooltips to ALL modules
 *
 * Uses Divi native field groups (divi/font, divi/box-shadow) for typography
 * and shadow controls; reads their saved values and emits flat data-* attrs
 * for the frontend engine.
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class TooltipExtension {

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ] );
    }

    private static function is_target( $name ) {
        if ( empty( $name ) || ! is_string( $name ) ) return false;
        if ( $name === 'core/null' ) return false;
        return strpos( $name, '/' ) !== false;
    }

    public static function enqueue_frontend() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }
        wp_enqueue_script( 'dnxte-tooltip' );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-tooltip-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-tooltip-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-tooltip-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-tooltip.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-tooltip-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-tooltip.js',
                'deps'               => [],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    /** Read a simple advanced field. */
    private static function get_val( $attrs, $key, $default = '' ) {
        $val = $attrs['dnxte_tooltip']['advanced'][ $key ]['desktop']['value'] ?? null;
        return ( $val === null || $val === '' ) ? $default : $val;
    }

    /**
     * Build the CSS typography string from the native divi/font group value.
     *
     * The tooltip is teleported to <body> at runtime, so the module's own font
     * CSS (which targets the module selector) never reaches it. We read the font
     * group value here and reuse Divi's own Font declaration to produce a CSS
     * string, then hand it to the engine to apply inline.
     */
    private static function get_font_css( $attrs ) {
        // Full attr (breakpoint > state > value); Font::style_declaration() reads
        // the `attr` key for inherited-style resolution, so it must be passed.
        $font_attr  = $attrs['dnxte_tooltip']['decoration']['font']['font'] ?? [];
        $font_value = $font_attr['desktop']['value'] ?? null;
        if ( ! is_array( $font_value ) || empty( $font_value ) ) {
            return '';
        }
        if ( class_exists( '\ET\Builder\Packages\StyleLibrary\Declarations\Font\Font' ) ) {
            return \ET\Builder\Packages\StyleLibrary\Declarations\Font\Font::style_declaration(
                [
                    'attr'       => $font_attr,
                    'attrValue'  => $font_value,
                    'returnType' => 'string',
                ]
            );
        }
        return '';
    }

    /** Build the CSS box-shadow string from the native divi/box-shadow group value. */
    private static function get_box_shadow_css( $attrs ) {
        $shadow_value = $attrs['dnxte_tooltip']['decoration']['boxShadow']['desktop']['value'] ?? null;
        if ( ! is_array( $shadow_value ) || empty( $shadow_value ) ) {
            return '';
        }
        if ( class_exists( '\ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow' ) ) {
            return \ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow::value( $shadow_value );
        }
        // Fallback if Divi class unavailable: build manually from explicit values
        $h        = $shadow_value['horizontal'] ?? '0px';
        $v        = $shadow_value['vertical']   ?? '4px';
        $blur     = $shadow_value['blur']       ?? '12px';
        $spread   = $shadow_value['spread']     ?? '0px';
        $color    = $shadow_value['color']      ?? 'rgba(0,0,0,0.15)';
        $position = ( ( $shadow_value['position'] ?? 'outer' ) === 'inner' ) ? 'inset ' : '';
        return $position . $h . ' ' . $v . ' ' . $blur . ' ' . $spread . ' ' . $color;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! self::is_target( $name ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        if ( 'on' !== self::get_val( $attrs, 'use_tooltip', 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $text = trim( self::get_val( $attrs, 'tooltip_text', 'Hover to see tooltip' ) );
        if ( empty( $text ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Allow safe HTML (bold, italic, links + rich text markup)
        $safe_text = wp_kses_post( $text );

        // ─── Read native divi/font group → CSS string ───
        $font_css = self::get_font_css( $attrs );

        // ─── Read native divi/box-shadow group → CSS string ───
        $shadow_css = self::get_box_shadow_css( $attrs );

        $data = [
            'data-dnxte-tooltip'           => $safe_text,
            'data-tooltip-position'        => esc_attr( self::get_val( $attrs, 'tooltip_position', 'top' ) ),
            'data-tooltip-trigger'         => esc_attr( self::get_val( $attrs, 'tooltip_trigger', 'hover' ) ),
            'data-tooltip-bg'              => esc_attr( self::get_val( $attrs, 'tooltip_bg', '#1e293b' ) ),
            'data-tooltip-animation'       => esc_attr( self::get_val( $attrs, 'tooltip_animation', 'fade' ) ),
            // Box
            'data-tooltip-padding-y'       => esc_attr( self::get_val( $attrs, 'tooltip_padding_y', '6' ) ),
            'data-tooltip-padding-x'       => esc_attr( self::get_val( $attrs, 'tooltip_padding_x', '12' ) ),
            'data-tooltip-max-width'       => esc_attr( self::get_val( $attrs, 'tooltip_max_width', '250' ) ),
            'data-tooltip-border-radius'   => esc_attr( self::get_val( $attrs, 'tooltip_border_radius', '6' ) ),
            // Border
            'data-tooltip-border-width'    => esc_attr( self::get_val( $attrs, 'tooltip_border_width', '0' ) ),
            'data-tooltip-border-color'    => esc_attr( self::get_val( $attrs, 'tooltip_border_color', '#000000' ) ),
            // Arrow
            'data-tooltip-arrow'           => self::get_val( $attrs, 'tooltip_arrow', 'on' ) === 'on' ? 'true' : 'false',
            'data-tooltip-arrow-size'      => esc_attr( self::get_val( $attrs, 'tooltip_arrow_size', '5' ) ),
            // Native font group → single CSS string (font-family, weight, size, color…)
            'data-tooltip-font-css'        => esc_attr( $font_css ),
            // Native box-shadow group (single CSS string)
            'data-tooltip-shadow'          => esc_attr( $shadow_css ),
        ];

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
