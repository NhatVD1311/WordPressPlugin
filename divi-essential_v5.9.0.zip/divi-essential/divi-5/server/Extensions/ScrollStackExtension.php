<?php
/**
 * Scroll Stack Extension — GSAP scroll-stack effect for Sections.
 * Stacks child Rows (or the first Row's Columns) as the user scrolls.
 * Options mirror Divi Animation's Scroll Stack (Card Stack). Emits the shared
 * `data-da-scroll-*` contract read by the unified engine (dnxte-scroll-effects.js).
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class ScrollStackExtension {

    private static $target_modules = [ 'divi/section', 'divi/row', 'divi/row-inner', 'divi/column', 'divi/column-inner' ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ] );
    }

    public static function enqueue_frontend() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );
        wp_enqueue_script( 'dnxte-scroll-effects' );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-scroll-stack-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-scroll-stack-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-scroll-stack-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['dnxte_sstack'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'enabled'     => [ 'desktop' => [ 'value' => 'off' ] ],
                    'mode'        => [ 'desktop' => [ 'value' => 'stack' ] ],
                    'style'       => [ 'desktop' => [ 'value' => 'flat' ] ],
                    'stackOffset' => [ 'desktop' => [ 'value' => '10px' ] ],
                    'scrubSpeed'  => [ 'desktop' => [ 'value' => '1' ] ],
                    'startOffset' => [ 'desktop' => [ 'value' => 'top top' ] ],
                    'fade'        => [ 'desktop' => [ 'value' => 'off' ] ],
                    'blur'        => [ 'desktop' => [ 'value' => '0' ] ],
                    'rotate'      => [ 'desktop' => [ 'value' => '0' ] ],
                ],
            ],
        ];

        return $settings;
    }

    private static function get_val( $attrs, $key, $default = '' ) {
        $val = $attrs['dnxte_sstack']['advanced'][ $key ]['desktop']['value'] ?? null;
        return ( $val === null || $val === '' ) ? $default : $val;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        if ( 'on' !== self::get_val( $attrs, 'enabled', 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $settings = [
            'mode'        => (string) self::get_val( $attrs, 'mode', 'stack' ),
            'style'       => (string) self::get_val( $attrs, 'style', 'flat' ),
            'stackOffset' => (string) self::get_val( $attrs, 'stackOffset', '10px' ),
            'scrubSpeed'  => (string) self::get_val( $attrs, 'scrubSpeed', '1' ),
            'startOffset' => (string) self::get_val( $attrs, 'startOffset', 'top top' ),
            'extras'      => [
                'fade'   => (string) self::get_val( $attrs, 'fade', 'off' ),
                'blur'   => (string) self::get_val( $attrs, 'blur', '0' ),
                'rotate' => (string) self::get_val( $attrs, 'rotate', '0' ),
            ],
        ];

        // Host type drives which structural children become the stacked panels:
        // section → rows, row → columns, column → modules (handled in the engine).
        // 'divi/row-inner' → 'row-inner', 'divi/column-inner' → 'column-inner', etc.
        $host_type = str_replace( 'divi/', '', $name );

        $data = [
            'data-da-scroll-effect' => 'cardStack',
            'data-da-scroll-host'   => $host_type,
            'data-da-scroll-data'   => wp_json_encode( $settings ),
        ];

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
