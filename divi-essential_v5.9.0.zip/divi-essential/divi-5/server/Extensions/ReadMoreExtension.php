<?php
/**
 * Read More Extension — collapses tall module content behind a "Read more" toggle.
 *
 * Divi 5 port of the Divi 4 extension in includes/Extensions/read-more/. The D4
 * version hooks et_pb_all_fields_unprocessed_* and et_module_shortcode_output,
 * neither of which Divi 5 ever calls, so it produced no editor UI and no
 * frontend markup on D5 sites.
 *
 * The runtime is assets/js/dnxte-readmore.js, a dependency-free rewrite of the
 * Divi 4 expander shared by the frontend and the VB canvas. It self-initialises
 * over `.dnxte-rm` and reads the data-readmore-* attributes this filter emits.
 * The Divi 4 extension keeps its own jQuery runtime and is untouched.
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class ReadMoreExtension {

    /**
     * Modules this extension attaches to.
     *
     * Mirrors the Divi 4 $allowed_modules list (et_pb_text, et_pb_blog, et_pb_code,
     * et_pb_cta, et_pb_blurb) translated to Divi 5 names, plus divi/fullwidth-code
     * which is the only fullwidth twin among them.
     */
    const ALLOWED_MODULES = [
        'divi/text',
        'divi/blog',
        'divi/code',
        'divi/cta',
        'divi/blurb',
        'divi/fullwidth-code',
    ];

    /** Easing keywords the runtime resolves; anything else falls back to 'ease'. */
    const EASINGS = [
        'ease',
        'linear',
        'ease-in',
        'ease-out',
        'ease-in-out',
        'back-out',
    ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
    }

    /**
     * The Divi 4 version exposed dnxte_extend_readmore_supported_module for the
     * same purpose (read-more.php:26). The D5 filter is deliberately named
     * differently because the two take different module identifiers — D4 passes
     * shortcode slugs, D5 passes namespaced module names.
     */
    private static function target_modules() {
        return (array) apply_filters( 'dnxte_extend_readmore_supported_module_d5', self::ALLOWED_MODULES );
    }

    private static function is_target( $name ) {
        return is_string( $name ) && in_array( $name, self::target_modules(), true );
    }

    /**
     * Register the Visual Builder settings UI and the editor preview engine.
     */
    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }
        if ( ! class_exists( '\ET\Builder\VisualBuilder\Assets\PackageBuildManager' ) ) {
            return;
        }

        // Engine first — the settings build declares it as a dependency because its
        // live-preview injector calls window.DnxteReadMore.
        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-readmore.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-readmore-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-readmore.js',
                'deps'               => [],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-readmore-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-readmore-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-readmore-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-readmore-engine' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    /** Read a simple advanced field off the dnxte_readmore attribute group. */
    private static function get_val( $attrs, $key, $default = '' ) {
        $val = $attrs['dnxte_readmore']['advanced'][ $key ]['desktop']['value'] ?? null;
        return ( null === $val || '' === $val ) ? $default : $val;
    }

    /**
     * Build a CSS string from the native divi/font group value.
     *
     * The Read More bar is created by the engine at runtime, so it does not exist
     * when Divi generates the module's stylesheet and no selector can reach it. We
     * resolve the font group to a declaration string here and let the engine apply
     * it inline — the same approach TooltipExtension uses for its teleported
     * tooltip element. Emits font-family/size/color/text-align/line-height etc.
     */
    private static function get_font_css( $attrs ) {
        $font_attr  = $attrs['dnxte_readmore']['decoration']['font']['font'] ?? [];
        $font_value = $font_attr['desktop']['value'] ?? null;
        if ( ! is_array( $font_value ) || empty( $font_value ) ) {
            return '';
        }
        if ( class_exists( '\ET\Builder\Packages\StyleLibrary\Declarations\Font\Font' ) ) {
            return \ET\Builder\Packages\StyleLibrary\Declarations\Font\Font::style_declaration(
                [
                    'attr'       => $font_attr,
                    'attrValue'  => $font_value,
                    'returnType' => 'string',
                ]
            );
        }
        return '';
    }

    /** Hover colour lives on the font group's hover state, not a separate field. */
    private static function get_font_hover_color( $attrs ) {
        $hover = $attrs['dnxte_readmore']['decoration']['font']['font']['desktop']['hover'] ?? null;
        return is_array( $hover ) ? ( $hover['color'] ?? '' ) : '';
    }

    /**
     * Standalone font size for the engine, used when the Font declaration class is
     * unavailable and get_font_css() returns nothing. Falls back to the Divi 4
     * default of 14px.
     */
    private static function get_font_size( $attrs ) {
        $size = $attrs['dnxte_readmore']['decoration']['font']['font']['desktop']['value']['size'] ?? '';
        return '' === $size ? '14px' : $size;
    }

    /**
     * Drop a colour/shadow value that carries CSS punctuation.
     *
     * Both values are applied through the CSSOM client-side (setProperty and a
     * property assignment), which cannot spill into neighbouring declarations,
     * so this is only a second line of defence — no colour or shadow ever needs
     * a brace or a semicolon.
     */
    private static function sanitize_css_value( $value ) {
        $value = is_string( $value ) ? trim( $value ) : '';
        return preg_match( '/[;{}<>\\\\]/', $value ) ? '' : $value;
    }

    /**
     * Build the CSS box-shadow string from the native divi/box-shadow group value.
     *
     * The bar does not exist when Divi generates the module stylesheet, so — like
     * the font group above — the value is resolved here and applied inline by the
     * engine. Core's BoxShadow::value() already folds the chosen preset into the
     * custom fields; the fallback only matters if that class is unavailable.
     */
    private static function get_box_shadow_css( $attrs ) {
        $shadow_value = $attrs['dnxte_readmore']['decoration']['boxShadow']['desktop']['value'] ?? null;
        if ( ! is_array( $shadow_value ) || empty( $shadow_value ) ) {
            return '';
        }

        if ( class_exists( '\ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow' ) ) {
            return \ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow::value( $shadow_value );
        }

        $style = $shadow_value['style'] ?? 'none';
        if ( ! $style || 'none' === $style ) {
            return '';
        }

        $position = ( 'inner' === ( $shadow_value['position'] ?? 'outer' ) ) ? 'inset ' : '';
        $spread   = $shadow_value['spread'] ?? '';
        $color    = $shadow_value['color'] ?? '';

        return $position
            . ( $shadow_value['horizontal'] ?? '0px' ) . ' '
            . ( $shadow_value['vertical'] ?? '0px' ) . ' '
            . ( $shadow_value['blur'] ?? '0px' )
            . ( $spread ? ' ' . $spread : '' )
            . ( $color ? ' ' . $color : '' );
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! self::is_target( $name ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        if ( 'on' !== self::get_val( $attrs, 'use_readmore', 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Height is stored with a unit by divi/range; the expander does arithmetic
        // on it, so hand it a bare number.
        $height = (float) self::get_val( $attrs, 'readmore_height', '200' );
        if ( $height <= 0 ) {
            $height = 200;
        }

        // Word mode trims the text after N words instead of clamping the box.
        $trim = 'words' === self::get_val( $attrs, 'readmore_trim_type', 'height' ) ? 'words' : 'height';

        $words = (int) self::get_val( $attrs, 'readmore_word_count', '50' );
        if ( $words <= 0 ) {
            $words = 50;
        }

        // Expand/collapse animation. 0 keeps the toggle instant. The easing goes
        // into an inline transition declaration client-side, so only the keywords
        // the engine knows are ever emitted.
        $duration = (int) self::get_val( $attrs, 'readmore_duration', '400' );
        if ( $duration < 0 ) {
            $duration = 0;
        }

        $easing = self::get_val( $attrs, 'readmore_easing', 'ease' );
        if ( ! in_array( $easing, self::EASINGS, true ) ) {
            $easing = 'ease';
        }

        $data = [
            'data-readmore-text'              => self::get_val( $attrs, 'readmore_text', 'Read more' ),
            'data-readmore-less-text'         => self::get_val( $attrs, 'readmore_less_text', 'Read less' ),
            'data-readmore-height'            => (string) $height,
            'data-readmore-trim'              => $trim,
            'data-readmore-words'             => (string) $words,
            'data-readmore-duration'          => (string) $duration,
            'data-readmore-easing'            => $easing,
            'data-readmore-no-less'           => self::get_val( $attrs, 'readmore_no_less', 'on' ),
            'data-readmore-disable-on-device' => self::get_val( $attrs, 'readmore_disable_on_device', 'none' ),
            'data-readmore-font-size'         => self::get_font_size( $attrs ),
            'data-readmore-font-css'          => self::get_font_css( $attrs ),
            'data-readmore-hover-color'       => self::get_font_hover_color( $attrs ),
            'data-readmore-bg'                => self::sanitize_css_value( self::get_val( $attrs, 'readmore_bg_color', '' ) ),
            'data-readmore-shadow'            => self::sanitize_css_value( self::get_box_shadow_css( $attrs ) ),
            'data-readmore-custom-css'        => self::get_val( $attrs, 'readmore_custom_css', '' ),
        ];

        // Enqueued lazily so pages with no Read More module pay nothing. Safe here
        // because the handle is registered in_footer.
        wp_enqueue_script( 'dnxte-readmore' );

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        // Append the hook class to the wrapper's existing class attribute; fall back
        // to adding one if the wrapper somehow has none. Callback form is required:
        // the attribute string is user-controlled (custom CSS) and a literal "$1" or
        // backslash in it would otherwise be interpreted as a backreference.
        $module_wrapper = preg_replace_callback(
            '/^(<[a-zA-Z][^>]*?\sclass=")/i',
            function ( $m ) {
                return $m[1] . 'dnxte-rm ';
            },
            $module_wrapper,
            1,
            $class_added
        );

        if ( empty( $class_added ) ) {
            $attr_str = ' class="dnxte-rm"' . $attr_str;
        }

        $module_wrapper = preg_replace_callback(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            function ( $m ) use ( $attr_str ) {
                return $m[1] . $attr_str . $m[2];
            },
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
