<?php
/**
 * Horizontal Scroll Extension — GSAP horizontal scroll for Sections
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class HorizontalScrollExtension {

    private static $target_modules = [ 'divi/section' ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 12, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend' ] );
    }

    public static function enqueue_frontend() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
            return;
        }
        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-trigger' );
        wp_enqueue_script( 'dnxte-scroll-effects' );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-horizontal-scroll-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-horizontal-scroll-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-horizontal-scroll-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['dnxte_hscroll'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'enabled'            => [ 'desktop' => [ 'value' => 'off' ] ],
                    'direction'          => [ 'desktop' => [ 'value' => 'ltr' ] ],
                    'itemNumber'         => [ 'desktop' => [ 'value' => '' ] ],
                    'offsetLeft'         => [ 'desktop' => [ 'value' => '0px' ] ],
                    'offsetRight'        => [ 'desktop' => [ 'value' => '0px' ] ],
                    'scrubSpeed'         => [ 'desktop' => [ 'value' => '1' ] ],
                    'startOffset'        => [ 'desktop' => [ 'value' => 'top top' ] ],
                    'scrollLength'       => [ 'desktop' => [ 'value' => '' ] ],
                    'progressBarEnabled' => [ 'desktop' => [ 'value' => 'off' ] ],
                    'fade'               => [ 'desktop' => [ 'value' => 'off' ] ],
                    'blur'               => [ 'desktop' => [ 'value' => '0' ] ],
                    'rotate'             => [ 'desktop' => [ 'value' => '0' ] ],
                ],
            ],
        ];

        return $settings;
    }

    private static function get_val( $attrs, $key, $default = '' ) {
        return $attrs['dnxte_hscroll']['advanced'][ $key ]['desktop']['value'] ?? $default;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        if ( 'on' !== self::get_val( $attrs, 'enabled', 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $settings = [
            'direction'          => (string) self::get_val( $attrs, 'direction', 'ltr' ),
            'itemNumber'         => (string) self::get_val( $attrs, 'itemNumber', '' ),
            'offsetLeft'         => (string) self::get_val( $attrs, 'offsetLeft', '0px' ),
            'offsetRight'        => (string) self::get_val( $attrs, 'offsetRight', '0px' ),
            'scrubSpeed'         => (string) self::get_val( $attrs, 'scrubSpeed', '1' ),
            'startOffset'        => (string) self::get_val( $attrs, 'startOffset', 'top top' ),
            'scrollLength'       => (string) self::get_val( $attrs, 'scrollLength', '' ),
            'progressBarEnabled' => (string) self::get_val( $attrs, 'progressBarEnabled', 'off' ),
            'extras'             => [
                'fade'   => (string) self::get_val( $attrs, 'fade', 'off' ),
                'blur'   => (string) self::get_val( $attrs, 'blur', '0' ),
                'rotate' => (string) self::get_val( $attrs, 'rotate', '0' ),
            ],
        ];

        $data = [
            'data-da-scroll-effect' => 'horizontal',
            'data-da-scroll-host'   => 'section',
            'data-da-scroll-data'   => wp_json_encode( $settings ),
        ];

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        return et_core_esc_previously( $module_wrapper );
    }
}
