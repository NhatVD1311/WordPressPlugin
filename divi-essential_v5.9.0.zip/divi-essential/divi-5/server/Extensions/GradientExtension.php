<?php
/**
 * Animated Gradient Extension for Section
 * Animates the section's existing Divi gradient background.
 * No extra color pickers — colors extracted from Divi's native gradient.
 *
 * @package DNXTE\Extensions
 */

namespace DNXTE\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

class GradientExtension {

    private static $target_modules = [ 'divi/section', 'divi/row', 'divi/column' ];

    public static function init() {
        add_action( 'wp', [ __CLASS__, 'register_vb_scripts' ] );
        add_filter( 'block_type_metadata_settings', [ __CLASS__, 'register_attributes' ] );
        add_filter( 'divi_module_wrapper_render', [ __CLASS__, 'filter_wrapper_render' ], 10, 2 );
    }

    public static function register_vb_scripts() {
        if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
            return;
        }

        $engine = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-animated-gradient.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-gradient-engine',
            'version' => file_exists( $engine ) ? filemtime( $engine ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-animated-gradient.js',
                'deps'               => [ 'dnxte-gsap' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );

        $ext = DIVI_ESSENTIAL_DIR . 'assets/js/dnxte-gradient-extension.js';
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
            'name'    => 'dnxte-gradient-extension',
            'version' => file_exists( $ext ) ? filemtime( $ext ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . 'assets/js/dnxte-gradient-extension.js',
                'deps'               => [ 'divi-module-library', 'divi-vendor-wp-hooks', 'dnxte-gradient-engine' ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
                'args'               => [ 'in_footer' => false ],
            ],
        ] );
    }

    public static function register_attributes( $settings ) {
        if ( ! in_array( $settings['name'] ?? '', self::$target_modules, true ) ) {
            return $settings;
        }

        $settings['attributes']['gradient_config'] = [
            'type'    => 'object',
            'default' => [
                'advanced' => [
                    'use_gradient_anim' => [ 'desktop' => [ 'value' => 'off' ] ],
                    'gradient_type'     => [ 'desktop' => [ 'value' => 'color-shift' ] ],
                    'speed'             => [ 'desktop' => [ 'value' => '1' ] ],
                    'intensity'         => [ 'desktop' => [ 'value' => '1' ] ],
                    'mouse_interactive' => [ 'desktop' => [ 'value' => 'off' ] ],
                    'mouse_strength'    => [ 'desktop' => [ 'value' => '1' ] ],
                    'custom_direction'  => [ 'desktop' => [ 'value' => 'horizontal' ] ],
                    'custom_movement'   => [ 'desktop' => [ 'value' => 'slide' ] ],
                    'custom_angle'      => [ 'desktop' => [ 'value' => '135' ] ],
                    'custom_range'      => [ 'desktop' => [ 'value' => '100' ] ],
                ],
            ],
        ];

        return $settings;
    }

    public static function filter_wrapper_render( $module_wrapper, $args ) {
        $name  = $args['name'] ?? '';
        $attrs = $args['attrs'] ?? [];

        if ( ! in_array( $name, self::$target_modules, true ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        $gc = $attrs['gradient_config']['advanced'] ?? [];
        if ( 'on' !== ( $gc['use_gradient_anim']['desktop']['value'] ?? 'off' ) ) {
            return et_core_esc_previously( $module_wrapper );
        }

        // Extract gradient colors from Divi's native background settings
        $bg_gradient = $attrs['module']['decoration']['background'] ?? [];
        $colors      = self::extract_gradient_colors( $bg_gradient );

        $data = [
            'data-gradient-type'      => $gc['gradient_type']['desktop']['value'] ?? 'color-shift',
            'data-gradient-speed'     => $gc['speed']['desktop']['value'] ?? '1',
            'data-gradient-intensity' => $gc['intensity']['desktop']['value'] ?? '1',
            'data-gradient-color1'    => $colors[0] ?? '#00d4aa',
            'data-gradient-color2'    => $colors[1] ?? '#7c3aed',
            'data-gradient-color3'    => $colors[2] ?? '#f472b6',
            'data-gradient-color4'    => $colors[3] ?? '#3b82f6',
            'data-gradient-mouse'    => ( $gc['mouse_interactive']['desktop']['value'] ?? 'off' ) === 'on' ? 'true' : 'false',
            'data-gradient-mouse-strength' => $gc['mouse_strength']['desktop']['value'] ?? '1',
            'data-gradient-custom-dir'     => $gc['custom_direction']['desktop']['value'] ?? 'horizontal',
            'data-gradient-custom-move'    => $gc['custom_movement']['desktop']['value'] ?? 'slide',
            'data-gradient-custom-angle'   => $gc['custom_angle']['desktop']['value'] ?? '135',
            'data-gradient-custom-range'   => $gc['custom_range']['desktop']['value'] ?? '100',
        ];

        $attr_str = '';
        foreach ( $data as $k => $v ) {
            $attr_str .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
        }

        $module_wrapper = preg_replace(
            '/^(<[a-zA-Z][^>]*)(\s*\/?>)/s',
            '$1' . $attr_str . '$2',
            $module_wrapper,
            1
        );

        wp_enqueue_script( 'dnxte-gsap' );
        wp_enqueue_script( 'dnxte-animated-gradient' );

        return et_core_esc_previously( $module_wrapper );
    }

    /**
     * Extract colors from Divi's gradient background attribute structure.
     */
    private static function extract_gradient_colors( $bg_attr ) {
        $colors = [];

        // Divi stores gradient colors in background.gradient.stops
        // Format varies — try common paths
        $gradient = $bg_attr['gradient'] ?? [];

        // Try stops array
        if ( isset( $gradient['desktop']['value']['stops'] ) ) {
            foreach ( $gradient['desktop']['value']['stops'] as $stop ) {
                if ( isset( $stop['color'] ) ) {
                    $colors[] = $stop['color'];
                }
            }
        }

        // Try color1/color2 format
        if ( empty( $colors ) ) {
            if ( isset( $gradient['desktop']['value']['color1'] ) ) {
                $colors[] = $gradient['desktop']['value']['color1'];
            }
            if ( isset( $gradient['desktop']['value']['color2'] ) ) {
                $colors[] = $gradient['desktop']['value']['color2'];
            }
        }

        // Fallback: scan the entire background string for colors
        if ( empty( $colors ) ) {
            $bg_str = is_string( $bg_attr ) ? $bg_attr : wp_json_encode( $bg_attr );
            preg_match_all( '/#[0-9a-fA-F]{3,8}/', $bg_str, $matches );
            if ( ! empty( $matches[0] ) ) {
                $colors = array_values( array_unique( $matches[0] ) );
            }
        }

        return array_slice( $colors, 0, 4 );
    }
}
