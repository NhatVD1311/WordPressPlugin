<?php
/**
 * ParentModule::module_styles().
 *
 * @package MEE\Modules\ParentModule
 * @since ??
 */

namespace DNXTE\Modules\NextBusinessHour\BusinessHourTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/parent-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					CssStyle::style([
						'selector'  => $args['orderClass'],
						'attr'      => $attrs['css'] ?? [],
						'cssFields' => self::custom_css(),
					]),


					$elements->style(['attrName' => 'separator',
					'styleProps'=> [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$order_class} .dnxte-Busihr-separator",
									'attr'     => $attrs['separator']['decoration']['gap'] ?? [],
									'property' => 'margin-left',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$order_class} .dnxte-Busihr-separator",
									'attr'     => $attrs['separator']['decoration']['gap'] ?? [],
									'property' => 'margin-right',
								],
							],
						]
					]]),
					$elements->style(['attrName' => 'list_item']),
					$elements->style(['attrName' => 'day']),
					$elements->style(['attrName' => 'time']),
					
					// Odd Background
					...( isset($attrs['dnxte_busihr_bg_striped']['advanced']['enable_stripe']['desktop']['value']) && $attrs['dnxte_busihr_bg_striped']['advanced']['enable_stripe']['desktop']['value'] === 'on' ? [
						$elements->style([
							'attrName' => 'dnxte_busihr_odd_background',
							'styleProps'=> [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte_business_hour_child:nth-child(odd)",
											'attr'     => $attrs['dnxte_busihr_odd_background']['decoration']['background'] ?? [],
											'property' => 'background',
										],
									],
								]
							]
						])
					] : [] ),
					
					// Even Background
					...( isset($attrs['dnxte_busihr_bg_striped']['advanced']['enable_stripe']['desktop']['value']) && $attrs['dnxte_busihr_bg_striped']['advanced']['enable_stripe']['desktop']['value'] === 'on' ? [
						$elements->style([
							'attrName' => 'dnxte_busihr_even_background',
							'styleProps'=> [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte_business_hour_child:nth-child(even)",
											'attr'     => $attrs['dnxte_busihr_even_background']['decoration']['background'] ?? [],
											'property' => 'background',
										],
									],
								]
							]
						])
					] : [] )
				],
			]
		);
	}

}
