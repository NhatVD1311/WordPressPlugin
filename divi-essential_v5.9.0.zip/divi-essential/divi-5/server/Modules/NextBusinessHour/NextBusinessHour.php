<?php
/**
 * Module: Parent Module class.
 *
 * @package MEE\Modules\NextBusinessHour
 * @since ??
 */

namespace DNXTE\Modules\NextBusinessHour;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `NextBusinessHour` is consisted of functions used for Parent Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextBusinessHour implements DependencyInterface {
	use BusinessHourTrait\RenderCallbackTrait;

	/**
	 * Loads `NextBusinessHour` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextBusinessHour/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextBusinessHour::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
