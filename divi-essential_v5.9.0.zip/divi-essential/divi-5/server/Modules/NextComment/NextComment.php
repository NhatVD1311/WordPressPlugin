<?php
/**
 * Module: Next FB Comment  Module class.
 *
 * @package MEE\Modules\NextComment
 * @since ??
 */

namespace DNXTE\Modules\NextComment;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\NextComment\NextCommentTrait;

/**
 * `NextComment` is consisted of functions used for Divi 4 Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextComment implements DependencyInterface {
	use NextCommentTrait\RenderCallbackTrait;

	/**
	 * Loads `NextComment` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextComment/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextComment::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
