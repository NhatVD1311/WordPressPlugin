<?php
/**
 * BeforeAfter::module_styles().
 *
 * @package MEE\Modules\BeforeAfter
 * @since ??
 */

namespace DNXTE\Modules\BeforeAfter\BeforeAfterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * D4 module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/d4-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';
		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
								'disabledOn'               => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-handle:before, ' . $args['orderClass'] . ' .twentytwenty-handle:after',
							'attr'     => $attrs['sliderColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-handle',
							'attr'     => $attrs['handleColor']['decoration']['color'] ?? [],
							'property' => 'border-color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-handle',
							'attr'     => $attrs['handleBackgroundColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-left-arrow',
							'attr'     => $attrs['handleIconColor']['decoration']['color'] ?? [],
							'property' => 'border-right-color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-right-arrow',
							'attr'     => $attrs['handleIconColor']['decoration']['color'] ?? [],
							'property' => 'border-left-color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-up-arrow',
							'attr'     => $attrs['handleIconColor']['decoration']['color'] ?? [],
							'property' => 'border-bottom-color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-down-arrow',
							'attr'     => $attrs['handleIconColor']['decoration']['color'] ?? [],
							'property' => 'border-top-color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-before-label:before',
							'attr'     => $attrs['beforeLabelBackgroundColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-after-label:before',
							'attr'     => $attrs['afterLabelBackgroundColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-overlay',
							'attr'     => $attrs['overlayColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .twentytwenty-overlay:hover',
							'attr'     => $attrs['overlayHoverColor']['decoration']['color'] ?? [],
							'property' => 'background',
						]
					)
					

					
				],
			]
		);
	}

}
