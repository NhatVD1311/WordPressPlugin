<?php
/**
 * BeforeAfter::render_callback()
 *
 * @package MEE\Modules\BeforeAfter
 * @since ??
 */

namespace DNXTE\Modules\BeforeAfter\BeforeAfterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	/**
	 * Divi 4 module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Before label.
		$offset           = isset($attrs['sliderStartOffset']['innerContent']['desktop']['value']) ? $attrs['sliderStartOffset']['innerContent']['desktop']['value'] : 0.5;
		$direction        = isset($attrs['sliderDirection']['innerContent']['desktop']['value']['select']) ? $attrs['sliderDirection']['innerContent']['desktop']['value']['select'] : 'horizontal';
		$alwaysShowLabels = isset($attrs['alwaysShowLabels']['advanced']['use']['desktop']['value']) ? $attrs['alwaysShowLabels']['advanced']['use']['desktop']['value'] : '';
		$beforeLabel      = isset($attrs['beforeLabel']['innerContent']['desktop']['value']) ? $attrs['beforeLabel']['innerContent']['desktop']['value'] : '';
		$afterLabel       = isset($attrs['afterLabel']['innerContent']['desktop']['value']) ? $attrs['afterLabel']['innerContent']['desktop']['value'] : '';
		$overlay          = isset($attrs['enabledOverlay']['advanced']['use']['desktop']['value']) ? $attrs['enabledOverlay']['advanced']['use']['desktop']['value'] : 'off';
		$moveOnHover      = isset($attrs['moveOnHover']['advanced']['use']['desktop']['value']) ? $attrs['moveOnHover']['advanced']['use']['desktop']['value'] : '';
		$moveOnClick      = isset($attrs['moveOnClick']['advanced']['use']['desktop']['value']) ? $attrs['moveOnClick']['advanced']['use']['desktop']['value'] : '';
		$moveWithHandle   = isset($attrs['moveWithHandle']['advanced']['use']['desktop']['value']) ? $attrs['moveWithHandle']['advanced']['use']['desktop']['value'] : '';
		$beforeImgAlt     = isset($attrs['beforeImageAlt']['innerContent']['desktop']['value']) ? $attrs['beforeImageAlt']['innerContent']['desktop']['value'] : '';
		$afterImgAlt      = isset($attrs['afterImageAlt']['innerContent']['desktop']['value']) ? $attrs['afterImageAlt']['innerContent']['desktop']['value'] : '';



					

		// Background component.
		$background_component = ElementComponents::component(
			[
				'attrs'         => $attrs['module']['decoration'] ?? [],
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);


		// Before Image.
		$before_image = $elements->render(
			[
				'attrName'          => 'beforeImage',
				'tag'               => 'img',
				'attributes'        => [
					'class' => 'beforeImage twentytwenty-before',
					'alt' => esc_attr($beforeImgAlt)
				],
				'childrenSanitizer' => 'et_core_esc_previously',
			]
		);

		$before_image_wrapper = HTMLUtility::render(
			[
				'tag'		=> 'div',
				'attributes' 	=> [
					'class' => 'dnxte_bf_img',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'	=> [
					$before_image
				]
			]
		);
		// After Image.
		$after_image = $elements->render(
			[
				'attrName'          => 'afterImage',
				'tag'               => 'img',
				'attributes'        => [
					'class' => 'afterImage twentytwenty-after',
					'alt' => esc_attr($afterImgAlt)
				],
				'childrenSanitizer' => 'et_core_esc_previously',
			]
		);

		$after_image_wrapper = HTMLUtility::render(
			[
				'tag'		=> 'div',
				'attributes' 	=> [
					'class' => 'dnxte_af_img',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'	=> [
					$after_image
				]
			]
		);

		// Container markup =============
		$container = HTMLUtility::render(
			[
				'tag'		=> 'div',
				'attributes' 	=> [
					'class'             => "dnxtecomparisonslide dnxte_before_after_wrapper overlay-{$overlay} always-show-labels-{$alwaysShowLabels}",
					"data-offset"       => esc_attr($offset),
					"data-orientation"  => esc_attr($direction),
					"data-always-label" => esc_attr($alwaysShowLabels),
					"data-before-label" => esc_attr($beforeLabel),
					"data-after-label"  => esc_attr($afterLabel),
					"data-overlay"      => esc_attr($overlay),
					"data-move-hover"   => esc_attr($moveOnHover),
					"data-move-click"   => esc_attr($moveOnClick),
					"data-move-handle"  => esc_attr($moveWithHandle),
					"ref"               => "dnxte_before_after_wrapper"

				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'	=> [
					$before_image_wrapper,
					$after_image_wrapper
				]
			]
		);



		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',				
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) .	$background_component . $container,
				
			]
		);
	}
}
