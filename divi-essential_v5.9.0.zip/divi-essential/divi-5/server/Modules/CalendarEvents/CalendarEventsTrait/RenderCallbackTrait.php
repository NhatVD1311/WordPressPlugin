<?php
/**
 * Module: CalendarEvents - Render Callback Trait.
 *
 * @package DNXTE\Modules\CalendarEvents
 * @since ??
 */

namespace DNXTE\Modules\CalendarEvents\CalendarEventsTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use CustomCssTrait;

	/**
	 * Category color configuration matching the frontend CATEGORY_CONFIG.
	 */
	private static $category_colors = array(
		'business' => '#3b82f6',
		'personal' => '#10b981',
		'holiday'  => '#ef4444',
		'family'   => '#8b5cf6',
		'meeting'  => '#f97316',
		'other'    => '#64748b',
	);

	/**
	 * Get the color for a category. Handles both preset and custom categories.
	 *
	 * @param string $category          Category key.
	 * @param string $custom_cat_color  Custom category color (used when category is 'custom').
	 *
	 * @return string Hex color code.
	 */
	private static function get_category_color( $category, $custom_cat_color = '' ) {
		if ( 'custom' === $category && ! empty( $custom_cat_color ) ) {
			return $custom_cat_color;
		}
		return self::$category_colors[ $category ] ?? self::$category_colors['other'];
	}

	/**
	 * Render callback for the CalendarEvents module.
	 *
	 * @param array    $attrs    Block attributes.
	 * @param string   $content  Block content.
	 * @param object   $block    Block object.
	 * @param object   $elements Elements instance.
	 *
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Extract calendar settings
		$default_view    = $attrs['calendarSettings']['advanced']['defaultView']['desktop']['value'] ?? 'dayGridMonth';
		$first_day       = $attrs['calendarSettings']['advanced']['firstDay']['desktop']['value'] ?? '0';
		$header_toolbar  = $attrs['calendarSettings']['advanced']['headerToolbar']['desktop']['value'] ?? 'on';

		// Extract interaction settings
		$week_numbers = $attrs['calendarInteraction']['advanced']['weekNumbers']['desktop']['value'] ?? 'off';
		// Disable week numbers for multi-month view (breaks layout)
		if ( 'multiMonthYear' === $default_view ) {
			$week_numbers = 'off';
		}

		// Extract features
		$hidden_days = $attrs['calendarFeatures']['advanced']['hiddenDays']['desktop']['value'] ?? '';

		// Height
		$height = $attrs['calendarHeight']['advanced']['height']['desktop']['value'] ?? '600px';

		// Colors
		$event_bg_color   = $attrs['calendarColors']['advanced']['eventBgColor']['desktop']['value'] ?? '#3b82f6';
		$event_text_color = $attrs['calendarColors']['advanced']['eventTextColor']['desktop']['value'] ?? '#ffffff';
		$today_bg_color   = $attrs['calendarColors']['advanced']['todayBgColor']['desktop']['value'] ?? '#eff6ff';
		$header_bg_color      = $attrs['calendarColors']['advanced']['headerBgColor']['desktop']['value'] ?? '';
		$day_header_bg_color  = $attrs['calendarColors']['advanced']['dayHeaderBgColor']['desktop']['value'] ?? '';
		$border_color         = $attrs['calendarColors']['advanced']['borderColor']['desktop']['value'] ?? '#e5e7eb';

		// Filter settings
		$show_filter = $attrs['filterSettings']['advanced']['showFilter']['desktop']['value'] ?? 'on';

		// Modal design settings
		$modal_bg_color      = $attrs['modalDesign']['advanced']['modalBgColor']['desktop']['value'] ?? '#ffffff';
		$modal_title_color   = $attrs['modalDesign']['advanced']['modalTitleColor']['desktop']['value'] ?? '#1e293b';
		$modal_text_color    = $attrs['modalDesign']['advanced']['modalTextColor']['desktop']['value'] ?? '#334155';
		$modal_label_color   = $attrs['modalDesign']['advanced']['modalLabelColor']['desktop']['value'] ?? '#64748b';
		$modal_overlay_color        = $attrs['modalDesign']['advanced']['modalOverlayColor']['desktop']['value'] ?? 'rgba(0,0,0,0.5)';
		$modal_header_bg_color      = $attrs['modalDesign']['advanced']['modalHeaderBgColor']['desktop']['value'] ?? '';
		$modal_header_border_color  = $attrs['modalDesign']['advanced']['modalHeaderBorderColor']['desktop']['value'] ?? '#e2e8f0';
		$modal_border_radius        = $attrs['modalDesign']['advanced']['modalBorderRadius']['desktop']['value'] ?? '12px';

		// Data source
		$data_source       = $attrs['dataSource']['innerContent']['desktop']['value'] ?? 'manual';
		$google_api_key    = $attrs['googleCalendar']['advanced']['apiKey']['desktop']['value'] ?? '';
		$google_calendar_id = $attrs['googleCalendar']['advanced']['calendarId']['desktop']['value'] ?? '';
		$events            = array();

		if ( 'json' === $data_source ) {
			$json_raw = $attrs['jsonData']['innerContent']['desktop']['value'] ?? '';
			if ( ! empty( $json_raw ) ) {
				$parsed = json_decode( $json_raw, true );
				if ( is_array( $parsed ) ) {
					foreach ( $parsed as $item ) {
						$item_category    = sanitize_text_field( $item['category'] ?? 'other' );
						$item_custom_color = sanitize_text_field( $item['customCategoryColor'] ?? '' );

						$event_data = array(
							'title' => sanitize_text_field( $item['title'] ?? 'New Event' ),
							'start' => sanitize_text_field( $item['start'] ?? '' ),
						);
						if ( ! empty( $item['end'] ) ) {
							$event_data['end'] = sanitize_text_field( $item['end'] );
						}
						if ( isset( $item['allDay'] ) ) {
							$event_data['allDay'] = (bool) $item['allDay'];
						}
						if ( ! empty( $item['url'] ) ) {
							$event_data['url'] = esc_url( $item['url'] );
						}

						// Use explicit color, or fall back to category color
						$explicit_color = ! empty( $item['color'] ) ? ( sanitize_hex_color( $item['color'] ) ?: $item['color'] ) : '';
						$event_data['color'] = $explicit_color ?: self::get_category_color( $item_category, $item_custom_color );

						if ( ! empty( $item['textColor'] ) ) {
							$event_data['textColor'] = sanitize_hex_color( $item['textColor'] ) ?: $item['textColor'];
						}
						$ext_props = array();
						if ( ! empty( $item['description'] ) ) {
							$ext_props['description'] = sanitize_text_field( $item['description'] );
						}
						$ext_props['category'] = $item_category;
						if ( ! empty( $item['customCategoryName'] ) ) {
							$ext_props['customCategoryName'] = sanitize_text_field( $item['customCategoryName'] );
						}
						if ( ! empty( $item_custom_color ) ) {
							$ext_props['customCategoryColor'] = $item_custom_color;
						}
						$event_data['extendedProps'] = $ext_props;
						$events[] = $event_data;
					}
				}
			}
		} elseif ( 'manual' === $data_source ) {
			// Build events from child innerBlocks
			if ( ! empty( $block->parsed_block['innerBlocks'] ) ) {
				// Day offsets for children without a start date, so they spread across the month.
				$default_day_offsets = array( 2, 7, 14, 21, 5, 10, 17, 24 );
				$child_index         = 0;

				foreach ( $block->parsed_block['innerBlocks'] as $inner_block ) {
					$child_attrs = $inner_block['attrs'] ?? [];
					$title       = $child_attrs['event']['advanced']['title']['desktop']['value'] ?? 'New Event';
					$start       = $child_attrs['event']['advanced']['start']['desktop']['value'] ?? '';
					$end         = $child_attrs['event']['advanced']['end']['desktop']['value'] ?? '';
					$all_day     = $child_attrs['event']['advanced']['allDay']['desktop']['value'] ?? 'on';
					$url         = $child_attrs['event']['advanced']['url']['desktop']['value'] ?? '';
					$description = $child_attrs['event']['advanced']['description']['desktop']['value'] ?? '';
					$color       = $child_attrs['event']['advanced']['color']['desktop']['value'] ?? '';
					$text_color  = $child_attrs['event']['advanced']['textColor']['desktop']['value'] ?? '';
					$category          = $child_attrs['event']['advanced']['category']['desktop']['value'] ?? 'business';
					$custom_cat_name   = $child_attrs['event']['advanced']['customCategoryName']['desktop']['value'] ?? '';
					$custom_cat_color  = $child_attrs['event']['advanced']['customCategoryColor']['desktop']['value'] ?? '#6366f1';

					// Use explicit color, or fall back to category color
					$effective_color = ! empty( $color ) ? $color : self::get_category_color( $category, $custom_cat_color );

					// When no start date set, space events across the current month.
					if ( empty( $start ) ) {
						$offset = $default_day_offsets[ $child_index % count( $default_day_offsets ) ];
						$start  = gmdate( 'Y-m-d', strtotime( '+' . $offset . ' days' ) );
					}

					$event_data = array(
						'title'  => $title ?: 'New Event',
						'start'  => $start,
						'allDay' => 'on' === $all_day,
						'color'  => $effective_color,
						'extendedProps' => array(
							'description'         => $description,
							'category'            => $category,
							'customCategoryName'  => 'custom' === $category ? $custom_cat_name : '',
							'customCategoryColor' => 'custom' === $category ? $custom_cat_color : '',
						),
					);

					if ( ! empty( $end ) ) {
						$event_data['end'] = $end;
					}
					if ( ! empty( $url ) ) {
						$event_data['url'] = $url;
					}
					if ( ! empty( $text_color ) ) {
						$event_data['textColor'] = $text_color;
					}

					$events[]    = $event_data;
					$child_index++;
				}
			}
		}

		// Fallback to defaults only when no innerBlocks exist (fresh module).
		// If innerBlocks existed but were all deleted, show empty calendar.
		$has_inner_blocks = ! empty( $block->parsed_block['innerBlocks'] );
		if ( empty( $events ) && 'google' !== $data_source && ! $has_inner_blocks && 'manual' === $data_source ) {
			$events = array(
				array( 'title' => 'Team Meeting', 'start' => gmdate( 'Y-m-d', strtotime( '+2 days' ) ), 'color' => '#f97316', 'extendedProps' => array( 'category' => 'meeting', 'description' => 'Weekly team sync meeting' ) ),
				array( 'title' => 'Product Launch', 'start' => gmdate( 'Y-m-d', strtotime( '+7 days' ) ), 'end' => gmdate( 'Y-m-d', strtotime( '+9 days' ) ), 'color' => '#3b82f6', 'extendedProps' => array( 'category' => 'business', 'description' => 'New product launch event' ) ),
				array( 'title' => 'Conference', 'start' => gmdate( 'Y-m-d', strtotime( '+14 days' ) ), 'end' => gmdate( 'Y-m-d', strtotime( '+16 days' ) ), 'color' => '#3b82f6', 'extendedProps' => array( 'category' => 'business', 'description' => 'Annual tech conference' ) ),
				array( 'title' => 'Workshop', 'start' => gmdate( 'Y-m-d', strtotime( '+21 days' ) ), 'color' => '#f97316', 'extendedProps' => array( 'category' => 'meeting', 'description' => 'Team building workshop' ) ),
			);
		}

		$events_json = wp_json_encode( $events );

		// Enqueue Google Calendar plugin if needed
		if ( 'google' === $data_source && ! empty( $google_api_key ) ) {
			wp_enqueue_script( 'dnxte_fullcalendar_google' );
		}

		// Build calendar container with data attributes
		$calendar_html = sprintf(
			'<div class="calendar-container" data-calendar data-default-view="%s" data-first-day="%s" data-header-toolbar="%s" data-week-numbers="%s" data-hidden-days="%s" data-source="%s" data-google-api-key="%s" data-google-calendar-id="%s" data-event-bg-color="%s" data-event-text-color="%s" data-today-bg-color="%s" data-header-bg-color="%s" data-day-header-bg-color="%s" data-border-color="%s" data-show-filter="%s" data-modal-bg="%s" data-modal-title-color="%s" data-modal-text-color="%s" data-modal-label-color="%s" data-modal-overlay="%s" data-modal-header-bg="%s" data-modal-header-border="%s" data-modal-radius="%s" data-events=\'%s\' style="height:%s;"></div>',
			esc_attr( $default_view ),
			esc_attr( $first_day ),
			esc_attr( $header_toolbar === 'on' ? 'true' : 'false' ),
			esc_attr( $week_numbers === 'on' ? 'true' : 'false' ),
			esc_attr( $hidden_days ),
			esc_attr( $data_source ),
			esc_attr( $google_api_key ),
			esc_attr( $google_calendar_id ),
			esc_attr( $event_bg_color ),
			esc_attr( $event_text_color ),
			esc_attr( $today_bg_color ),
			esc_attr( $header_bg_color ),
			esc_attr( $day_header_bg_color ),
			esc_attr( $border_color ),
			esc_attr( $show_filter === 'on' ? 'true' : 'false' ),
			esc_attr( $modal_bg_color ),
			esc_attr( $modal_title_color ),
			esc_attr( $modal_text_color ),
			esc_attr( $modal_label_color ),
			esc_attr( $modal_overlay_color ),
			esc_attr( $modal_header_bg_color ),
			esc_attr( $modal_header_border_color ),
			esc_attr( $modal_border_radius ),
			esc_attr( $events_json ),
			esc_attr( $height )
		);

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'className'           => 'dnxte-calendar-events',
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $calendar_html . $content,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
