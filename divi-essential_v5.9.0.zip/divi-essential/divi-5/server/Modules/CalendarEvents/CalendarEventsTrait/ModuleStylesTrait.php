<?php
/**
 * Module: CalendarEvents - Module Styles Trait.
 *
 * @package DNXTE\Modules\CalendarEvents
 * @since ??
 */

namespace DNXTE\Modules\CalendarEvents\CalendarEventsTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;

	/**
	 * CalendarEvents module styles.
	 *
	 * @param array $args Module style arguments.
	 *
	 * @return void
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';

		$base_styles = [
			$elements->style(
				[
					'attrName'   => 'module',
					'styleProps' => [
						'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
						'disabledOn'               => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				]
			),
			CssStyle::style(
				[
					'selector'  => $args['orderClass'],
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => self::custom_css(),
				]
			),
			$elements->style( [ 'attrName' => 'headerFont' ] ),
			$elements->style( [ 'attrName' => 'dayHeaderFont' ] ),
			$elements->style( [ 'attrName' => 'dayNumberFont' ] ),
			$elements->style( [ 'attrName' => 'eventFont' ] ),
			$elements->style( [ 'attrName' => 'filterBar' ] ),
			$elements->style( [ 'attrName' => 'container' ] ),
			$elements->style(
				[
					'attrName'   => 'calendarHeight',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['calendarHeight']['advanced']['height'] ?? [],
									'property'  => 'min-height',
									'important' => true,
								],
							],
						],
					],
				]
			),
		];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $base_styles,
			]
		);
	}
}
