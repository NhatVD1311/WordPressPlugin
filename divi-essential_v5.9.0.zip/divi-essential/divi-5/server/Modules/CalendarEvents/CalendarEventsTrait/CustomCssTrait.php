<?php
/**
 * Module: CalendarEvents - Custom CSS Trait.
 *
 * @package DNXTE\Modules\CalendarEvents
 * @since ??
 */

namespace DNXTE\Modules\CalendarEvents\CalendarEventsTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	/**
	 * Get custom CSS fields for the CalendarEvents module.
	 *
	 * @return array
	 */
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/calendar-events' );
		return $block_type ? ( $block_type->customCssFields ?? array() ) : array();
	}
}
