<?php
/**
 * Module: CalendarEvents - Module Script Data Trait.
 *
 * @package DNXTE\Modules\CalendarEvents
 * @since ??
 */

namespace DNXTE\Modules\CalendarEvents\CalendarEventsTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

trait ModuleScriptDataTrait {

	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setStyle'      => [
					[
						'selector' => $selector . ' .calendar-container',
						'data'     => array(
							'height' => $attrs['calendarHeight']['advanced']['height'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? '600px';
						},
					],
				],
				'storeInstance' => $store_instance,
			]
		);

		wp_enqueue_script( 'dnxte_fullcalendar' );
		wp_enqueue_script( 'dnxte_calendar_events' );
		wp_enqueue_style( 'dnxte_calendar_events_css' );
	}
}
