<?php
/**
 * Module: CalendarEvents Module class.
 *
 * @package DNXTE\Modules\CalendarEvents
 * @since ??
 */

namespace DNXTE\Modules\CalendarEvents;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\CalendarEvents\CalendarEventsTrait;

class CalendarEvents implements DependencyInterface {
	use CalendarEventsTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'CalendarEvents/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ CalendarEvents::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
