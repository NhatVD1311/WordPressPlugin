<?php
/**
 * Module: Globe3dMapItem class.
 *
 * @package DNXTE\Modules\Globe3dMapItem
 * @since ??
 */

namespace DNXTE\Modules\Globe3dMapItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class Globe3dMapItem implements DependencyInterface {
	use Globe3dMapItemTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'Globe3dMapItem/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ Globe3dMapItem::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
