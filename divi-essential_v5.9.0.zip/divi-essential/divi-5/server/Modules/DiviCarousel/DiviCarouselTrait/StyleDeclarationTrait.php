<?php
/**
 * NextButton::render_callback()
 *
 * @package MEE\Modules\NextButton
 * @since ??
 */

namespace DNXTE\Modules\DiviCarousel\DiviCarouselTrait;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

trait StyleDeclarationTrait {

    /**
     * Style declaration for the carousel image max height.
     *
     * This function is equivalent of JS function imageMaxHeightDeclaration located in
     * src/components/DiviCarousel/style-declarations/image-max-height.ts.
     *
     * The slide images are laid out with `width: 100%; height: auto`, so capping the
     * height alone would squash them. `object-fit: cover` is emitted alongside the
     * cap so the image is cropped instead of distorted.
     *
     * @param array $params {
     *     An array of arguments.
     *
     *     @type string     $attrValue  The value (breakpoint > state > value) of module attribute.
     *     @type bool|array $important  If set to true, the CSS will be added with !important.
     *     @type string     $returnType This is the type of value that the function will return. Can be either string or key_value_pair.
     * }
     *
     * @return string
     * @since ??
     */
    public static function image_max_height_style_declaration( array $params ): string {
        $max_height = $params['attrValue'] ?? '';

        $style_declarations = new StyleDeclarations(
            [
                'returnType' => 'string',
                'important'  => false,
            ]
        );

        if ( ! empty( $max_height ) ) {
            $style_declarations->add( 'max-height', $max_height );
            $style_declarations->add( 'object-fit', 'cover' );
        }

        return $style_declarations->value();
    }
}
