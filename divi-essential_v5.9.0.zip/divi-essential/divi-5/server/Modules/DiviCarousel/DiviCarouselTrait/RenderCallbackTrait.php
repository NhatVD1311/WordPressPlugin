<?php
/**
 * DiviCarouselChild::render_callback()
 *
 * @package MEE\Modules\DiviCarouselChild
 * @since ??
 */

namespace DNXTE\Modules\DiviCarousel\DiviCarouselTrait;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\Base\Traits\CommonTrait;
use DNXTE\Modules\DiviCarousel\DiviCarousel;

trait RenderCallbackTrait {
    use ModuleClassnamesTrait;
    use ModuleStylesTrait;
    use ModuleScriptDataTrait;
    use CommonTrait;
    /**
     * Parent module render callback which outputs server side rendered HTML on the Front-End.
     *
     * @since ??
     *
     * @param array          $attrs Block attributes that were saved by VB.
     * @param string         $content          Block content.
     * @param \WP_Block      $block            Parsed block object that being rendered.
     * @param ModuleElements $elements         ModuleElements instance.
     *
     * @return string HTML rendered of Parent module.
     */
    private function get_arrow_class( $arrowPosition ) {
        $position_arr = array(
            "top-left",
            "top-center",
            "top-right",
            "bottom-left",
            "bottom-center",
            "bottom-right",
        );

        if ( $arrowPosition === "inner" ) {
            return "dnxte_coverflow_arrows_inner";
        }

        if ( $arrowPosition === "outer" ) {
            return "dnxte_coverflow_arrows_outer";
        }

        if ( in_array( $arrowPosition, $position_arr ) ) {
            return "coverflow-" . $arrowPosition;
        }

        return "dnxte_coverflow_arrows_default";
    }

    private function get_pagination_class( $pagination_type, $dynamic_bullets ) {
        if ( $pagination_type === 'none' ) {
            return 'swiper-pagination swiper-pagination-none';
        }

        if ( $pagination_type === 'bullets' && $dynamic_bullets === 'on' ) {
            return 'swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-bullets-dynamic mt-10';
        }

        if ( $pagination_type === 'bullets' ) {
            return 'swiper-pagination swiper-pagination-clickable swiper-pagination-bullets mt-10';
        }

        if ( $pagination_type === 'fraction' ) {
            return 'swiper-pagination swiper-pagination-fraction';
        }

        if ( $pagination_type === 'progressbar' ) {
            return 'swiper-pagination swiper-pagination-progressbar';
        }

        return '';
    }

    public static function render_callback( $attrs, $content, $block, $elements ) {
        $children_ids = $block->parsed_block['innerBlocks'] ? array_map(
            function ( $inner_block ) {
                return $inner_block['id'];
            },
            $block->parsed_block['innerBlocks']
        ) : [];
        $self = new self();
        $slides_desktop = $attrs['carouselSettings']['advanced']['slidesPerView']['desktop']['value'] ?? '3';
        $slides_tablet = $attrs['carouselSettings']['advanced']['slidesPerView']['tablet']['value'] ?? '2';
        $slides_phone = $attrs['carouselSettings']['advanced']['slidesPerView']['phone']['value'] ?? '1';

        $breakpoints = "$slides_desktop|$slides_tablet|$slides_phone";
        // Carousel Settings
        $auto_play =  $attrs['carouselSettings']['advanced']['autoplay']['desktop']['value'] ?? "" ;
        $delay =  $attrs['carouselSettings']['advanced']['delay']['desktop']['value'] ?? "" ;
        $loop =  $attrs['carouselSettings']['advanced']['loop']['desktop']['value'] ?? "" ;
        $slides_per_view = $breakpoints;
        $centered_slides =  $attrs['carouselSettings']['advanced']['centerSlides']['desktop']['value'] ?? "" ;
        $speed =  $attrs['carouselSettings']['advanced']['speed']['desktop']['value'] ?? "" ;
        $space_between =  $attrs['carouselSettings']['advanced']['spaceBetween']['desktop']['value'] ?? "" ;
        $auto_height =  $attrs['carouselSettings']['advanced']['autoHeight']['desktop']['value'] ?? "" ;
        $grab_cursor =  $attrs['navSettings']['advanced']['useGrabCursor']['desktop']['value'] ?? "" ;
        $navigation =  $attrs['navSettings']['advanced']['useArrowNavigation']['desktop']['value'] ?? "" ;
        $keyboard =  $attrs['navSettings']['advanced']['keyboardNavigation']['desktop']['value'] ?? "" ;
        $mousewheel =  $attrs['navSettings']['advanced']['mousewheelNavigation']['desktop']['value'] ?? "" ;
        $pagination_type =  $attrs['navSettings']['advanced']['paginationType']['desktop']['value'] ?? "" ;
        $dynamic_bullets =  $attrs['navSettings']['advanced']['dynamicBullets']['desktop']['value'] ?? "" ;
        $arrow_position =  $attrs['navSettings']['advanced']['arrowPosition']['desktop']['value'] ?? "" ;
        $effects_setting =  $attrs['effectSettings']['advanced']['slideShadow']['desktop']['value'] ?? "" ;
        $rotate =  $attrs['effectSettings']['advanced']['rotate']['desktop']['value'] ?? "" ;
        $stretch =  $attrs['effectSettings']['advanced']['stretch']['desktop']['value'] ?? "" ;
        $depth =  $attrs['effectSettings']['advanced']['depth']['desktop']['value'] ?? "" ;
        $use_light_box =  $attrs['lightbox_settings']['advanced']['use_lightbox']['desktop']['value'] ?? "" ;

        $className = 'coverflow-container ' .
            ( strpos( $arrow_position, 'top' ) === 0 ? 'arrow-position-top ' : 'arrow-position-bottom ' ) .
            ( !in_array( $arrow_position, ['default', 'outer', 'inner'] ) ? 'multi-position-container' : '' );

        $class = '';
        if ( !in_array( $arrow_position, ['default', 'outer', 'inner'] ) ) {
            $class .= 'multi-position-button-container ';
        }

        if ( strpos( $arrow_position, 'left' ) !== false ) {
            $class .= 'multi-position-button-left ';
        }
        if ( strpos( $arrow_position, 'center' ) !== false ) {
            $class .= 'multi-position-button-center ';
        }
        if ( strpos( $arrow_position, 'right' ) !== false ) {
            $class .= 'multi-position-button-right ';
        }

        $class = trim( $class );
        $arrow_class = '';
        if ( !in_array( $arrow_position, ['default', 'outer', 'inner'] ) ) {
            $arrow_class .= 'multi-position-button';
        }

        // when pagination type  is none condational 
        $pagination_class_parent = $pagination_type === 'none' ? 'mb-30' : '';
        

        // var_dump( $slides_per_view, "ami slide per view" );
        $navigation_content = $navigation === 'on' ? HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'swiper-button-container ' . $self->get_arrow_class( $arrow_position ) . ' ' . $class,
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => HTMLUtility::render(
                    [
                        'tag'               => 'div',
                        'attributes'        => [
                            'class'     => 'swiper-button-prev ' . $arrow_class,
                            'data-icon' => "4",
                        ],
                        'childrenSanitizer' => 'et_core_esc_previously',
                        'children'          => '',
                    ]
                ) . HTMLUtility::render(
                    [
                        'tag'               => 'div',
                        'attributes'        => [
                            'class'     => 'swiper-button-next ' . $arrow_class,
                            'data-icon' => "5",
                        ],
                        'childrenSanitizer' => 'et_core_esc_previously',
                        'children'          => '',
                    ]
                ),
            ]
        ) : '';
        $pagination = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => $self->get_pagination_class( $pagination_type, $dynamic_bullets ),
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => '',
            ]
        );

        $wrapper_markup = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'swiper-wrapper',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $content,

            ]
        );

        $swiper_active = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class'                => 'swiper-container dnxte-coverflowslider-active ' . $pagination_class_parent . '',
                    'data-slides-per-view' => $slides_per_view,
                    'data-centered-slides' => $centered_slides,
                    'data-speed'           => $speed,
                    'data-space-between'   => $space_between,
                    'data-loop'            => $loop,
                    'data-autoplay'        => $auto_play,
                    'data-delay'           => $delay,
                    'data-grab-cursor'     => $grab_cursor,
                    'data-keyboard'        => $keyboard,
                    'data-mousewheel'      => $mousewheel,
                    'data-pagination-type' => $pagination_type,
                    'data-dynamic-bullets' => $dynamic_bullets,
                    'data-effects-setting' => $effects_setting,
                    'data-rotate'          => $rotate,
                    'data-stretch'         => $stretch,
                    'data-depth'           => $depth,
                    'data-navigation'      => $navigation,
                    'data-slide-shadow'    => $effects_setting,
                    'data-light-box'       => $use_light_box,
                    'data-auto-height'     => $auto_height,

                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $wrapper_markup . $pagination,

            ]
        );
        $main_wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => $className,
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $swiper_active . $navigation_content,
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
        $parent_attrs = $parent->attrs ?? [];

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'id'                  => $block->parsed_block['id'],
                'name'                => $block->block_type->name,
                'moduleCategory'      => $block->block_type->category,
                'attrs'               => $attrs,
                'elements'            => $elements,
                'classnamesFunction'  => [DiviCarousel::class, 'module_classnames'],
                'scriptDataComponent' => [DiviCarousel::class, 'module_script_data'],
                'stylesComponent'     => [DiviCarousel::class, 'module_styles'],
                'parentAttrs'         => $parent_attrs,
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => ElementComponents::component(
                    [
                        'attrs'         => $attrs['module']['decoration'] ?? [],
                        'id'            => $block->parsed_block['id'],

                        // FE only.
                        'orderIndex'    => $block->parsed_block['orderIndex'],
                        'storeInstance' => $block->parsed_block['storeInstance'],
                    ]
                ) . $main_wrapper,
                'childrenIds'         => $children_ids,
            ]
        );
    }
}
