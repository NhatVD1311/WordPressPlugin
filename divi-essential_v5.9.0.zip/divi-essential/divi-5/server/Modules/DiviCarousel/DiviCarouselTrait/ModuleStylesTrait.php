<?php
/**
 * DiviCarousel::module_styles().
 *
 * @package MEE\Modules\DiviCarousel
 * @since ??
 */

namespace DNXTE\Modules\DiviCarousel\DiviCarouselTrait;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\Base\Traits\CommonTrait;

trait ModuleStylesTrait {

    use CustomCssTrait;
    use StyleDeclarationTrait;
    use CommonTrait;
    /**
     * Child Module's style components.
     *
     * This function is equivalent of JS function ModuleStyles located in
     * src/components/parent-module/styles.tsx.
     *
     * @param array $args {
     *     An array of arguments.
     *
     * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
     * @type string $name Module name.
     * @type string $attrs Module attributes.
     * @type string $parentAttrs Parent attrs.
     * @type string $orderClass Selector class name.
     * @type string $parentOrderClass Parent selector class name.
     * @type string $wrapperOrderClass Wrapper selector class name.
     * @type string $settings Custom settings.
     * @type string $state Attributes state.
     * @type string $mode Style mode.
     * @type ModuleElements $elements ModuleElements instance.
     * }
     * @since ??
     */
    public static function module_styles( $args ) {
        $attrs = $args['attrs'] ?? [];
        $parent_attrs = $args['parentAttrs'] ?? [];
        $order_class = $args['orderClass'];
        $elements = $args['elements'];
        $settings = $args['settings'] ?? [];

        $icon_selector = "{$order_class} .et-pb-icon";
        

        $arrow_width = max( intval(  $attrs['navSettings']['advanced']['arrowSize']['desktop']['value'] ?? ""  ) - 15, 0 ) . 'px';
        Style::add(
            [
                'id'            => $args['id'],
                'name'          => $args['name'],
                'orderIndex'    => $args['orderIndex'],
                'storeInstance' => $args['storeInstance'],
                'styles'        => [
                    // Module.
                    $elements->style(
                        [
                            'attrName'   => 'module',
                            'styleProps' => [
                                'disabledOn' => [
                                    'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                                ],
                            ],
                        ]
                    ),
                    CssStyle::style(
                        [
                            'selector'  => $args['orderClass'],
                            'attr'      => $attrs['css'] ?? [],
                            'cssFields' => self::custom_css(),
                        ]
                    ),
                     $elements->style(
                        [
                            'attrName' => 'module_item',
                        ]
                    ),
                    $elements->style(
                        [
                            'attrName' => 'title',
                        ]
                    ),
                    // Image.
                    $elements->style(
                        [
                            'attrName'   => 'image',
                            'styleProps' => [
                                'advancedStyles' => [
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'attr'                => $attrs['image']['advanced']['maxHeight'] ?? [],
                                            'declarationFunction' => [self::class, 'image_max_height_style_declaration'],
                                        ],
                                    ],
                                ],
                            ],
                        ]
                    ),
                    $elements->style(
                        [
                            'attrName' => 'content',
                        ]
                    ),
                    $elements->style(
                        [
                            'attrName' => 'link',
                        ]
                    ),
                    // Carousel Settings.
                    $elements->style(
                        [
                            'attrName' => 'carouselSettings',
                        ]
                    ),

                    $elements->style(
                        [
                            'attrName'   => 'navSettings',
                            'styleProps' => [
                                'advancedStyles' => [
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector'            => "{$args['orderClass']} .dnxte-coverflowslider-active .swiper-button-next::after",
                                            'attr'                => $attrs['navSettings']['advanced']['navigationIconLeft'] ?? [],
                                            'declarationFunction' => [self::class, 'icon_style_declaration'],
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector'            => "{$args['orderClass']} .dnxte-coverflowslider-active .swiper-button-prev::after",
                                            'attr'                => $attrs['navSettings']['advanced']['navigationIconRight'] ?? [],
                                            'declarationFunction' => [self::class, 'icon_style_declaration'],
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
                                            'attr'     => $attrs['navSettings']['advanced']['arrowColor'] ?? [],
                                            'property' => 'color',
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
                                            'attr'     => $attrs['navSettings']['advanced']['arrowBgColor'] ?? [],
                                            'property' => 'background-color',
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-pagination .swiper-pagination-bullet",
                                            'attr'     => $attrs['navSettings']['advanced']['dotsColor'] ?? [],
                                            'property' => 'background-color',
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-pagination .swiper-pagination-bullet-active",
                                            'attr'     => $attrs['navSettings']['advanced']['dotsActiveColor'] ?? [],
                                            'property' => 'background-color',
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-pagination-progressbar .swiper-pagination-progressbar-fill",
                                            'attr'     => $attrs['navSettings']['advanced']['progressBarColor'] ?? [],
                                            'property' => 'background-color',
                                        ],
                                    ],
                                    [
                                        'componentName' => 'divi/common',
                                        'props'         => [
                                            'selector' => "{$args['orderClass']} .swiper-button-prev:after, {$args['orderClass']} .swiper-button-next:after",
                                            'attr'     => $attrs['navSettings']['advanced']['arrowSize'] ?? [],
                                            'property' => 'font-size',
                                        ],
                                    ],

                                ],
                            ],
                        ]
                    ),
                    $elements->style(
                        [
                            'attrName' => 'effectSettings',
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class .swiper-button-prev, $order_class .swiper-button-next",
                            'property' => "width: $arrow_width; height: $arrow_width;",
                            'attr'     => $attrs['navSettings']['advanced']['arrowSize'] ?? [],
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class .swiper-pagination .swiper-pagination-bullet",
                            'property' => "background-color",
                            'attr'     => $attrs['navSettings']['advanced']['dotsColor'] ?? [],
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class .swiper-pagination .swiper-pagination-bullet-active",
                            'property' => "background-color",
                            'attr'     => $attrs['navSettings']['advanced']['dotsActiveColor'] ?? [],
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class  .swiper-slide-shadow-left,  $order_class  .swiper-slide-shadow-right",
                            'attr'     => $attrs['navSettings']['advanced']['slideShadow'] ?? [],
                            // Attr text must never reach the declaration (it lands
                            // unescaped in the page <style> block) — map the toggle
                            // to fixed CSS here instead.
                            'declarationFunction' => function ( $params ) {
                                return 'on' === ( $params['attrValue'] ?? '' ) ? 'display: block;' : 'display: none;';
                            },
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector'  => " .mfp-arrow:after",
                            'property'  => "color",
                            'attr'      => $attrs['lightbox_settings']['advanced']['arrowColor'] ?? [],
                            "important" => true,
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector'  => " .mfp-close",
                            'property'  => "color",
                            'attr'      => $attrs['lightbox_settings']['advanced']['closeBtnColor'] ?? [],
                            "important" => true,
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector'  => " .mfp-bg.mfp-ready",
                            'property'  => "background",
                            'attr'      => $attrs['lightbox_settings']['advanced']['overlayColor'] ?? [],
                            "important" => true,
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class  .dnxte_coverflowslider_child",
                            'attr'     => $attrs['carouselSettings']['advanced']['equalHeight'] ?? [],
                            // See slideShadow above — toggle mapped to fixed CSS,
                            // attr text never reaches the declaration.
                            'declarationFunction' => function ( $params ) {
                                return 'on' === ( $params['attrValue'] ?? '' )
                                    ? 'height: 100% !important;'
                                    : 'height: auto !important;';
                            },
                        ]
                    ),

                    CommonStyle::style(
                        [
                            'selector' => "$order_class .dnxte-coverflow-inside-image",
                            'property' => "left",
                            'attr'     => $attrs['content_wrapper']['advanced']['horizontalPosition'] ?? [],
                        ]
                    ),
                    CommonStyle::style(
                        [
                            'selector' => "$order_class .dnxte-coverflow-inside-image",
                            'property' => "top",
                            'attr'     => $attrs['content_wrapper']['advanced']['verticalPosition'] ?? [],
                        ]
                    ),
                ],
            ]
        );

    }

}