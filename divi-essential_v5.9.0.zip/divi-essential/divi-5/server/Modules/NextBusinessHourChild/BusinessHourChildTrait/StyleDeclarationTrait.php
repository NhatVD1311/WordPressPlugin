<?php
/**
 * ChildModule::icon_style_declaration().
 *
 * @package Builder\Packages\ModuleLibrary
 * @since ??
 */

namespace DNXTE\Modules\NextBusinessHourChild\BusinessHourChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


trait StyleDeclarationTrait {
}
