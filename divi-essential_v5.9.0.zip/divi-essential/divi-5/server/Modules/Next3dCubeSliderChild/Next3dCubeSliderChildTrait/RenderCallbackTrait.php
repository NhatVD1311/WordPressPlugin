<?php
/**
 * Next3dCubeSliderChild::render_callback()
 *
 * @package MEE\Modules\Next3dCubeSliderChild
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSliderChild\Next3dCubeSliderChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\Next3dCubeSliderChild\Next3dCubeSliderChild;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Child module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param WP_Block       $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Child module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		$parent_attrs = $parent->attrs ?? [];

		$parent_default_attributes = ModuleRegistration::get_default_attrs( 'dnxte/dnxte-3dcubeslider-parent' );
		$parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );


		$logo_src = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';
		$logo_alt = $attrs['image']['innerContent']['desktop']['value']['alt'] ?? '';

		// Heading.
		$heading = $elements->render(
			[
				'attrName' => 'heading',
			]
		);

		// Content.
		$body_content = $elements->render(
			[
				'attrName' => 'content',
			]
		);

		// Cube slider child item.
		$cube_slider_child_item = sprintf(
			'<div class="dnxte-3dcubeslider-item">
				<img src="%1$s" alt="%2$s" class="img-fluid swiper-lazy">
				 <div class="dnxte-3dcubeslider-multitext">
				 	%3$s
					<div class="dnxte-3dcubeslider-pra">
						%4$s
					</div>
				 </div>
			</div>',
			esc_url( $logo_src ),
			esc_attr( $logo_alt ),
			$heading,
			$body_content
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],
				'classNames'         => 'swiper-slide',
				// VB equivalent.
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [ Next3dCubeSliderChild::class, 'module_classnames' ],
				'stylesComponent'    => [ Next3dCubeSliderChild::class, 'module_styles' ],
				'scriptDataComponent' => [ Next3dCubeSliderChild::class, 'module_script_data' ],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				'children'           => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $cube_slider_child_item,
			]
		);
	}
}
