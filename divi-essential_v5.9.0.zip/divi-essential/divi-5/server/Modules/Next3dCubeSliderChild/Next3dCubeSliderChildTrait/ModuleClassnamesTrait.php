<?php
/**
 * Next3dCubeSliderChild::module_classnames().
 *
 * @package Builder\Packages\ModuleLibrary
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSliderChild\Next3dCubeSliderChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Text\TextClassnames;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
trait ModuleClassnamesTrait {

	/**
	 * Module classnames function for Child module.
	 *
	 * This function is equivalent of JS function moduleClassnames located in
	 * src/components/child-module/module-classnames.ts.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type object $classnamesInstance Instance of ET\Builder\Packages\Module\Layout\Components\Classnames.
	 *     @type array  $attrs              Block attributes data that being rendered.
	 * }
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];


		$text_options_classnames = TextClassnames::text_options_classnames( $attrs['module']['advanced']['text'] ?? [] );
		$link_options_classnames = isset( $attrs['module']['advanced']['link']['desktop']['value']['url'] ) ? 'dnxte_linked' : '';
		if ( $link_options_classnames ) {
			$classnames_instance->add( $link_options_classnames, true );
			
		}
		$classnames_instance->add( 'swiper-slide', true );
		if ( $text_options_classnames ) {
			$classnames_instance->add( $text_options_classnames, true );
			
		}
	}

}
