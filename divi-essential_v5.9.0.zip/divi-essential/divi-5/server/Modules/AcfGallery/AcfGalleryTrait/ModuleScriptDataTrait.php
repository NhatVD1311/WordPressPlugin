<?php
/**
 * AcfGallery::module_script_data()
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery\AcfGalleryTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

trait ModuleScriptDataTrait {

	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set( [
			'id'            => $id,
			'selector'      => $selector,
			'attrs'         => array_merge(
				$module_decoration_attrs,
				[
					'link' => $attrs['module']['advanced']['link'] ?? [],
				]
			),
			'storeInstance' => $store_instance,
		] );

		// Enqueue frontend scripts and styles.
		wp_enqueue_script( 'dnxte-acf-gallery-script' );
		wp_enqueue_style( 'dnxte-acf-gallery-style' );
		wp_enqueue_style( 'dnext_magnific_popup' );
		wp_enqueue_script( 'dnext_magnific_popup' );
		wp_enqueue_script( 'dnext_isotope' );
		wp_enqueue_script( 'imagesloaded' );
		wp_enqueue_style( 'dnext_msnary_hvr_css' );
	}
}
