<?php
/**
 * AcfGallery::render_callback()
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery\AcfGalleryTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DNXTE\Modules\AcfGallery\AcfGallery;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Render callback.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes.
	 * @param string         $content  Inner content.
	 * @param \WP_Block      $block    Parsed block.
	 * @param ModuleElements $elements Module elements.
	 *
	 * @return string Rendered HTML.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// ── ACF Source ───────────────────────────────────────────────
		$field_type     = $attrs['acfSource']['advanced']['fieldType']['desktop']['value'] ?? 'gallery';
		$field_name     = $attrs['acfSource']['advanced']['fieldName']['desktop']['value'] ?? '';
		$post_source    = $attrs['acfSource']['advanced']['postSource']['desktop']['value'] ?? 'current';
		$manual_post_id = absint( $attrs['acfSource']['advanced']['manualPostId']['desktop']['value'] ?? 0 );
		$fallback_ids   = $attrs['acfSource']['innerContent']['desktop']['value'] ?? '';
		$fallback_msg   = esc_html( $attrs['acfSource']['advanced']['fallbackMessage']['desktop']['value'] ?? 'No images found.' );

		// ── Layout ───────────────────────────────────────────────────
		$layout_type    = $attrs['galleryLayout']['advanced']['layoutType']['desktop']['value'] ?? 'grid';
		$columns_d      = absint( $attrs['galleryLayout']['advanced']['columns']['desktop']['value'] ?? 4 );
		$columns_t      = absint( $attrs['galleryLayout']['advanced']['columns']['tablet']['value'] ?? 3 );
		$columns_m      = absint( $attrs['galleryLayout']['advanced']['columns']['phone']['value'] ?? 2 );
		$gap_d          = absint( $attrs['galleryLayout']['advanced']['gap']['desktop']['value'] ?? 0 );
		$gap_t          = absint( $attrs['galleryLayout']['advanced']['gap']['tablet']['value'] ?? 0 );
		$gap_m          = absint( $attrs['galleryLayout']['advanced']['gap']['phone']['value'] ?? 0 );
		$aspect_ratio   = $attrs['galleryLayout']['advanced']['aspectRatio']['desktop']['value'] ?? 'auto';
		$custom_height  = absint( $attrs['galleryLayout']['advanced']['customAspectHeight']['desktop']['value'] ?? 300 );
		$equal_height   = $attrs['galleryLayout']['advanced']['equalHeight']['desktop']['value'] ?? 'off';

		// ── Interaction ──────────────────────────────────────────────
		$click_action   = $attrs['interaction']['advanced']['clickAction']['desktop']['value'] ?? 'lightbox';
		$custom_url     = esc_url( $attrs['interaction']['advanced']['customUrl']['desktop']['value'] ?? '' );
		$caption_source = $attrs['interaction']['advanced']['lightboxCaptionSource']['desktop']['value'] ?? 'media';

		// ── Hover ────────────────────────────────────────────────────
		$enable_overlay = $attrs['hoverSettings']['advanced']['enableOverlay']['desktop']['value'] ?? 'on';
		$hover_effect   = $attrs['hoverSettings']['advanced']['hoverEffect']['desktop']['value'] ?? 'zoom';
		$show_caption   = $attrs['hoverSettings']['advanced']['showCaption']['desktop']['value'] ?? 'off';
		$show_desc      = $attrs['hoverSettings']['advanced']['showDescription']['desktop']['value'] ?? 'off';
		$content_pos      = esc_attr( $attrs['hoverSettings']['advanced']['contentPosition']['desktop']['value'] ?? 'center' );
		$border_animation = $attrs['hoverSettings']['advanced']['borderAnimation']['desktop']['value'] ?? 'off';

		// ── Performance (hardcoded defaults) ─────────────────────────
		$image_size = 'large';

		// ── Icon ─────────────────────────────────────────────────────
		$enable_icon    = $attrs['overlayIcon']['advanced']['use']['enableIcon']['desktop']['value'] ?? 'on';
		$icon_value     = $attrs['overlayIcon']['innerContent']['desktop']['value'] ?? '';

		$wp_size = $image_size;

		// ── Get post ID ──────────────────────────────────────────────
		if ( 'manual' === $post_source ) {
			$post_id = $manual_post_id;
		} elseif ( class_exists( 'ET_Post_Stack' ) && \ET_Post_Stack::get_main_post_id() ) {
			$post_id = \ET_Post_Stack::get_main_post_id();
		} else {
			$post_id = get_the_ID();
		}

		// ── Fetch images ─────────────────────────────────────────────
		$images = [];

		if ( $field_name && $post_id && function_exists( 'get_field' ) ) {
			$post_status = get_post_status( $post_id );
			if ( $post_status && 'trash' !== $post_status ) {
				$acf_value = get_field( $field_name, $post_id );

				if ( 'gallery' === $field_type && is_array( $acf_value ) ) {
					foreach ( $acf_value as $img ) {
						$aid = is_array( $img ) ? ( $img['ID'] ?? 0 ) : absint( $img );
						if ( ! $aid ) continue;
						$images[] = self::build_image_data( $aid, $img, $wp_size );
					}
				} elseif ( 'repeater' === $field_type && is_array( $acf_value ) ) {
					foreach ( $acf_value as $row ) {
						foreach ( $row as $value ) {
							$aid = 0;
							if ( is_array( $value ) && isset( $value['ID'] ) ) {
								$aid = $value['ID'];
							} elseif ( is_numeric( $value ) ) {
								$aid = absint( $value );
							}
							if ( $aid ) {
								$images[] = self::build_image_data( $aid, $value, $wp_size );
								break;
							}
						}
					}
				}
			}
		}

		// Fallback images.
		if ( empty( $images ) && $fallback_ids ) {
			$ids = array_filter( array_map( 'absint', explode( ',', $fallback_ids ) ) );
			foreach ( $ids as $aid ) {
				$images[] = self::build_image_data( $aid, null, $wp_size );
			}
		}

		// ── ACF not active notice ────────────────────────────────────
		if ( ! function_exists( 'get_field' ) && empty( $images ) ) {
			$notice = '<div class="dnxte-acf-gallery-notice">'
				. esc_html__( 'ACF Pro is required for this module. Please install and activate Advanced Custom Fields Pro.', 'dnxte-divi-essential' )
				. '</div>';
			return self::wrap_module( $notice, $attrs, $block, $elements, $parent_attrs, $parent );
		}

		// ── No images ────────────────────────────────────────────────
		if ( empty( $images ) ) {
			$notice = '<div class="dnxte-acf-gallery-notice">' . $fallback_msg . '</div>';
			return self::wrap_module( $notice, $attrs, $block, $elements, $parent_attrs, $parent );
		}

		// ── Build gallery items ──────────────────────────────────────
		$items_html = '';
		foreach ( $images as $index => $img ) {
			$loading_attr = $index > 0 ? ' loading="lazy"' : '';

			$img_tag = '<img src="' . esc_url( $img['display_url'] ) . '" alt="' . esc_attr( $img['alt'] ) . '"' . $loading_attr . ' />';

			// Link wrapper.
			$link_href  = '#';
			$link_class = 'dnxte-acf-image-link-nobox';
			$data_attrs = '';

			if ( 'lightbox' === $click_action ) {
				$link_href  = esc_url( $img['url'] );
				$link_class = 'dnxte-acf-image-link image-popup';
				$caption_text = self::get_caption_text( $img, $caption_source );
				$data_attrs = ' data-title="' . esc_attr( $img['title'] ) . '" data-caption="' . esc_attr( $caption_text ) . '"';
				$data_attrs .= ' data-gallery-order="dnxte_acf_gallery_' . $block->parsed_block['orderIndex'] . '"';
			} elseif ( 'media_file' === $click_action ) {
				$link_href = esc_url( $img['url'] );
			} elseif ( 'custom_url' === $click_action && $custom_url ) {
				$link_href = $custom_url;
			}

			$link_open  = '<a class="' . $link_class . '" href="' . $link_href . '"' . $data_attrs . '>';
			$link_close = '</a>';

			// Overlay.
			$overlay = '';
			if ( 'on' === $enable_overlay ) {
				$icon_html = '';
				if ( 'on' === $enable_icon && $icon_value ) {
					$icon_html = '<span class="dnxte-acf-overlay-icon">' . Utils::process_font_icon( $icon_value ) . '</span>';
				}

				$hover_content = '';
				if ( 'on' === $show_caption && $img['caption'] ) {
					$hover_content .= '<p class="dnxte-acf-gallery-caption">' . esc_html( $img['caption'] ) . '</p>';
				}
				if ( 'on' === $show_desc && $img['description'] ) {
					$hover_content .= '<p class="dnxte-acf-gallery-description">' . esc_html( $img['description'] ) . '</p>';
				}

				$content_div = ( 'on' === $show_caption || 'on' === $show_desc )
					? '<div class="dnxte-acf-overlay-content">' . $hover_content . '</div>'
					: '';

				$overlay = '<div class="dnxte-acf-overlay dnxte-acf-content-' . $content_pos . '">'
					. $icon_html
					. $content_div
					. '</div>';
			}

			$item_classes = [ 'dnxte-acf-gallery-item' ];
			if ( 'on' === $enable_overlay ) {
				$item_classes[] = 'dnxte-acf-hover-effect-' . $hover_effect;
				if ( 'on' === $border_animation ) {
					$item_classes[] = 'dnxte-acf-border-animation';
				}
			} else {
				$item_classes[] = 'dnxte-acf-overlay-disabled';
			}

			$items_html .= '<div class="' . esc_attr( implode( ' ', $item_classes ) ) . '">'
				. $link_open . $img_tag . $link_close
				. $overlay
				. '</div>';
		}

		// ── Grid sizers for masonry ──────────────────────────────────
		$sizers = '';
		if ( 'masonry' === $layout_type ) {
			$sizers = '<div class="dnxte-acf-grid-sizer"></div><div class="dnxte-acf-gutter-sizer"></div>';
		}

		// ── CSS variables ────────────────────────────────────────────
		$style_vars = sprintf(
			'--acf-columns:%d;--acf-gap:%dpx;--acf-aspect-ratio:%s;--acf-custom-height:%s;',
			$columns_d,
			$gap_d,
			'custom' === $aspect_ratio ? 'auto' : esc_attr( $aspect_ratio ),
			'custom' === $aspect_ratio ? $custom_height . 'px' : 'auto'
		);

		$preload_first = '';

		// ── Data config for frontend JS ──────────────────────────────
		$data_config = wp_json_encode( [
			'layout'    => $layout_type,
			'columns'   => [ 'desktop' => $columns_d, 'tablet' => $columns_t, 'phone' => $columns_m ],
			'gap'       => [ 'desktop' => $gap_d, 'tablet' => $gap_t, 'phone' => $gap_m ],
			'lightbox'  => 'lightbox' === $click_action ? '1' : '',
			'captionSrc'=> $caption_source,
		] );

		$grid_classes = 'dnxte-acf-gallery-grid dnxte-acf-layout-' . esc_attr( $layout_type );
		if ( 'on' === $equal_height && 'grid' === $layout_type ) {
			$grid_classes .= ' dnxte-acf-equal-height';
		}

		// ── Lightbox customization ───────────────────────────────
		$lightbox_css = '';
		if ( 'lightbox' === $click_action ) {
			$lb_overlay     = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['overlayColor']['desktop']['value'] ?? '', 'rgba(11,11,11,0.8)' );
			$lb_close       = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['closeColor']['desktop']['value'] ?? '', '#ffffff' );
			$lb_close_size  = esc_attr( $attrs['lightboxSettings']['advanced']['closeSize']['desktop']['value'] ?? '24px' );
			$lb_close_bg    = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['closeBg']['desktop']['value'] ?? '', 'transparent' );
			$lb_close_w     = esc_attr( $attrs['lightboxSettings']['advanced']['closeWidth']['desktop']['value'] ?? '44px' );

			$lb_arrow       = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['arrowColor']['desktop']['value'] ?? '', '#ffffff' );
			$lb_arrow_size  = esc_attr( $attrs['lightboxSettings']['advanced']['arrowSize']['desktop']['value'] ?? '30px' );
			$lb_arrow_bg    = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['arrowBg']['desktop']['value'] ?? '', 'transparent' );
			$lb_arrow_w     = esc_attr( $attrs['lightboxSettings']['advanced']['arrowWidth']['desktop']['value'] ?? '40px' );

			$lb_close_hover_color = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['closeHoverColor']['desktop']['value'] ?? '', '' );
			$lb_close_hover_bg    = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['closeHoverBg']['desktop']['value'] ?? '', '' );
			$lb_arrow_hover_color = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['arrowHoverColor']['desktop']['value'] ?? '', '' );
			$lb_arrow_hover_bg    = self::sanitize_css_color( $attrs['lightboxSettings']['advanced']['arrowHoverBg']['desktop']['value'] ?? '', '' );

			$close_border = $attrs['lightboxSettings']['advanced']['closeBorder']['desktop']['value'] ?? [];
			$arrow_border = $attrs['lightboxSettings']['advanced']['arrowBorder']['desktop']['value'] ?? [];
			
			$lb_close_border_css = self::get_border_styles_from_attr( $close_border );
			$lb_arrow_border_css = self::get_border_styles_from_attr( $arrow_border );

			$lightbox_css = '<style>'
				. '.mfp-bg.dnxte-acf-gallery-wrapper { background: ' . $lb_overlay . ' !important; opacity: 1 !important; }'
				. '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-close, .mfp-wrap.dnxte-acf-gallery-wrapper .mfp-image-holder .mfp-close { '
				. 'color: ' . $lb_close . ' !important; '
				. 'background-color: ' . $lb_close_bg . ' !important; '
				. 'font-size: ' . $lb_close_size . ' !important; '
				. 'width: ' . $lb_close_w . ' !important; '
				. 'height: ' . $lb_close_w . ' !important; '
				. 'line-height: ' . $lb_close_w . ' !important; '
				. 'display: flex !important; align-items: center !important; justify-content: center !important; '
				. $lb_close_border_css
				. '}'
				. ( ( $lb_close_hover_color || $lb_close_hover_bg )
					? '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-close:hover, .mfp-wrap.dnxte-acf-gallery-wrapper .mfp-image-holder .mfp-close:hover { '
					. ( $lb_close_hover_color ? 'color: ' . $lb_close_hover_color . ' !important; ' : '' )
					. ( $lb_close_hover_bg    ? 'background-color: ' . $lb_close_hover_bg . ' !important; ' : '' )
					. '}'
					: ''
				)
				. '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-arrow { '
				. 'background-color: ' . $lb_arrow_bg . ' !important; '
				. 'width: ' . $lb_arrow_w . ' !important; '
				. 'height: ' . $lb_arrow_w . ' !important; '
				. 'display: flex !important; align-items: center !important; justify-content: center !important; '
				. 'margin: 0 !important; top: 50% !important; transform: translateY(-50%) !important; opacity: 1 !important; '
				. $lb_arrow_border_css
				. '}'
				. '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-arrow:after { '
				. "font-family: 'ETmodules' !important; "
				. 'font-size: ' . $lb_arrow_size . ' !important; '
				. 'color: ' . $lb_arrow . ' !important; '
				. 'position: static !important; transform: none !important; margin: 0 !important; opacity: 1 !important; display: block !important; }'
				. ( ( $lb_arrow_hover_color || $lb_arrow_hover_bg )
					? '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-arrow:hover { '
					. ( $lb_arrow_hover_bg ? 'background-color: ' . $lb_arrow_hover_bg . ' !important; ' : '' )
					. '}'
					. '.mfp-wrap.dnxte-acf-gallery-wrapper .mfp-arrow:hover:after { '
					. ( $lb_arrow_hover_color ? 'color: ' . $lb_arrow_hover_color . ' !important; ' : '' )
					. '}'
					: ''
				)
				. '</style>';
		}

		// ── Ghost spacers for justified layout ──────────────────────
		$spacers_html = '';
		if ( 'justified' === $layout_type ) {
			for ( $i = 0; $i < $columns_d; $i++ ) {
				$spacers_html .= '<div class="dnxte-acf-justified-spacer" aria-hidden="true"></div>';
			}
		}

		$gallery_html = $lightbox_css
			. '<div class="dnxte-acf-gallery-wrapper">'
			. '<div class="' . $grid_classes . '" style="' . $style_vars . '" data-config="' . esc_attr( $data_config ) . '">'
			. $sizers
			. $items_html
			. $spacers_html
			. '</div></div>';

		return self::wrap_module( $gallery_html, $attrs, $block, $elements, $parent_attrs, $parent );
	}

	/**
	 * Convert border attribute structure to CSS string.
	 */
	protected static function get_border_styles_from_attr( $b ) {
		if ( empty( $b ) ) {
			return '';
		}
		$styles = [];

		// Handle styles (width, color, style)
		if ( ! empty( $b['styles'] ) ) {
			$s     = $b['styles'];
			$sides = [ 'top', 'bottom', 'left', 'right' ];

			if ( ! empty( $s['all'] ) ) {
				$all = $s['all'];
				if ( ! empty( $all['width'] ) ) {
					$styles[] = "border-width: {$all['width']} !important;";
				}
				if ( ! empty( $all['color'] ) ) {
					$styles[] = "border-color: {$all['color']} !important;";
				}
				// Default style to solid if width or color is set but style is missing
				if ( ! empty( $all['width'] ) || ! empty( $all['color'] ) ) {
					$styles[] = "border-style: " . ( ! empty( $all['style'] ) ? $all['style'] : 'solid' ) . " !important;";
				} elseif ( ! empty( $all['style'] ) ) {
					$styles[] = "border-style: {$all['style']} !important;";
				}
			} else {
				foreach ( $sides as $side ) {
					if ( ! empty( $s[ $side ] ) ) {
						$side_data = $s[ $side ];
						if ( ! empty( $side_data['width'] ) ) {
							$styles[] = "border-{$side}-width: {$side_data['width']} !important;";
						}
						if ( ! empty( $side_data['color'] ) ) {
							$styles[] = "border-{$side}-color: {$side_data['color']} !important;";
						}
						if ( ! empty( $side_data['width'] ) || ! empty( $side_data['color'] ) ) {
							$styles[] = "border-{$side}-style: " . ( ! empty( $side_data['style'] ) ? $side_data['style'] : 'solid' ) . " !important;";
						} elseif ( ! empty( $side_data['style'] ) ) {
							$styles[] = "border-{$side}-style: {$side_data['style']} !important;";
						}
					}
				}
			}
		}

		// Handle radius
		if ( ! empty( $b['radius'] ) ) {
			$r = $b['radius'];
			if ( ! empty( $r['topLeft'] ) ) {
				$styles[] = "border-top-left-radius: {$r['topLeft']} !important;";
			}
			if ( ! empty( $r['topRight'] ) ) {
				$styles[] = "border-top-right-radius: {$r['topRight']} !important;";
			}
			if ( ! empty( $r['bottomLeft'] ) ) {
				$styles[] = "border-bottom-left-radius: {$r['bottomLeft']} !important;";
			}
			if ( ! empty( $r['bottomRight'] ) ) {
				$styles[] = "border-bottom-right-radius: {$r['bottomRight']} !important;";
			}
		}

		return implode( ' ', $styles );
	}

	/**
	 * Sanitize a CSS color value. Allows hex, rgb(), rgba(), hsl(), hsla().
	 *
	 * @param string $color   The color value to sanitize.
	 * @param string $default Fallback if invalid.
	 *
	 * @return string Sanitized color or default.
	 */
	protected static function sanitize_css_color( $color, $default ) {
		$color = trim( $color );
		if ( '' === $color ) {
			return $default;
		}
		if ( preg_match( '/^(#[0-9a-fA-F]{3,8}|rgba?\(\s*[\d\s,.%\/]+\)|hsla?\(\s*[\d\s,.%\/deg]+\)|var\(\s*--[a-zA-Z0-9_-]+\s*\))$/', $color ) ) {
			return $color;
		}
		return $default;
	}

	/**
	 * Build image data array from attachment ID.
	 *
	 * @param int        $aid       Attachment ID.
	 * @param array|null $acf_img   ACF image array (if available).
	 * @param string|array $wp_size WordPress image size.
	 *
	 * @return array Image data.
	 */
	protected static function build_image_data( $aid, $acf_img, $wp_size ) {
		$attachment = get_post( $aid );
		$display_url = wp_get_attachment_image_url( $aid, $wp_size );
		$full_url    = wp_get_attachment_image_url( $aid, 'full' );

		if ( is_array( $acf_img ) ) {
			return [
				'id'          => $aid,
				'url'         => $full_url ?: ( $acf_img['url'] ?? '' ),
				'display_url' => $display_url ?: ( $acf_img['sizes'][ is_string( $wp_size ) ? $wp_size : 'large' ] ?? $acf_img['url'] ?? '' ),
				'alt'         => $acf_img['alt'] ?? '',
				'title'       => $acf_img['title'] ?? '',
				'caption'     => $acf_img['caption'] ?? '',
				'description' => $acf_img['description'] ?? '',
			];
		}

		return [
			'id'          => $aid,
			'url'         => $full_url ?: '',
			'display_url' => $display_url ?: '',
			'alt'         => get_post_meta( $aid, '_wp_attachment_image_alt', true ),
			'title'       => $attachment->post_title ?? '',
			'caption'     => $attachment->post_excerpt ?? '',
			'description' => $attachment->post_content ?? '',
		];
	}

	/**
	 * Get caption text based on source setting.
	 *
	 * @param array  $img    Image data.
	 * @param string $source Caption source.
	 *
	 * @return string
	 */
	protected static function get_caption_text( $img, $source ) {
		switch ( $source ) {
			case 'acf':
			case 'media':
				return $img['caption'] ?? '';
			case 'title':
				return $img['title'] ?? '';
			default:
				return '';
		}
	}

	/**
	 * Wrap inner content with Module::render().
	 */
	protected static function wrap_module( $inner_html, $attrs, $block, $elements, $parent_attrs, $parent ) {
		$background = ElementComponents::component( [
			'attrs'         => $attrs['module']['decoration'] ?? [],
			'id'            => $block->parsed_block['id'],
			'orderIndex'    => $block->parsed_block['orderIndex'],
			'storeInstance' => $block->parsed_block['storeInstance'],
		] );

		return Module::render( [
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],
			'id'                  => $block->parsed_block['id'],
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'attrs'               => $attrs,
			'elements'            => $elements,
			'classnamesFunction'  => [ AcfGallery::class, 'module_classnames' ],
			'stylesComponent'     => [ AcfGallery::class, 'module_styles' ],
			'scriptDataComponent' => [ AcfGallery::class, 'module_script_data' ],
			'parentAttrs'         => $parent_attrs,
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $background . $inner_html,
		] );
	}
}
