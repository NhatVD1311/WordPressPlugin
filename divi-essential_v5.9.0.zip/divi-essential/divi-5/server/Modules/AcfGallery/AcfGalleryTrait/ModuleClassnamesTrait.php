<?php
/**
 * AcfGallery::module_classnames()
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery\AcfGalleryTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Text\TextClassnames;

trait ModuleClassnamesTrait {

	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$text = TextClassnames::text_options_classnames( $attrs['module']['advanced']['text'] ?? [] );
		if ( $text ) {
			$classnames_instance->add( $text, true );
		}

		$layout = $attrs['galleryLayout']['advanced']['layoutType']['desktop']['value'] ?? 'grid';
		$classnames_instance->add( 'dnxte-acf-layout-' . $layout, true );

		$hover = $attrs['hoverSettings']['advanced']['hoverEffect']['desktop']['value'] ?? 'zoom';
		$classnames_instance->add( 'dnxte-acf-hover-' . $hover, true );
	}
}
