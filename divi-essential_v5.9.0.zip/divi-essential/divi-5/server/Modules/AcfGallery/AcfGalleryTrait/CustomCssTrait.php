<?php
/**
 * AcfGallery::custom_css()
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery\AcfGalleryTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	public static function custom_css() {
		return [
			'galleryWrapper' => [
				'subName'        => 'galleryWrapper',
				'selectorSuffix' => ' .dnxte-acf-gallery-wrapper',
			],
			'galleryItem'    => [
				'subName'        => 'galleryItem',
				'selectorSuffix' => ' .dnxte-acf-gallery-item',
			],
			'galleryImage'   => [ 
				'subName'        => 'galleryImage',
				'selectorSuffix' => ' .dnxte-acf-gallery-item img',
			],
			'overlay'        => [
				'subName'        => 'overlay',
				'selectorSuffix' => ' .dnxte-acf-overlay',
			],
			'caption'        => [
				'subName'        => 'caption',
				'selectorSuffix' => ' .dnxte-acf-gallery-caption',
			],
			'description'    => [
				'subName'        => 'description',
				'selectorSuffix' => ' .dnxte-acf-gallery-description',
			],
		];
	}
}
