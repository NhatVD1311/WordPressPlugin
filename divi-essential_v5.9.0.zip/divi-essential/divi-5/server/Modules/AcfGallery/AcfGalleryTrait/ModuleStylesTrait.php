<?php
/**
 * AcfGallery::module_styles()
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery\AcfGalleryTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$settings    = $args['settings'] ?? [];
		$elements    = $args['elements'];
		$order_class = $args['orderClass'] ?? '';

		$icon_selector = "{$order_class} .dnxte-acf-gallery-item .dnxte-acf-overlay-icon";
		$mark_selector = "{$order_class} .dnxte-acf-gallery-item.dnxte-acf-border-animation::after";

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => [
				$elements->style( [
					'attrName'   => 'module',
					'styleProps' => [
						'disabledOn' => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				] ),
				$elements->style( [ 'attrName' => 'galleryImage' ] ),
				$elements->style( [ 'attrName' => 'imageOverlay' ] ),
				$elements->style( [ 'attrName' => 'hoverOverlayBg' ] ),
				$elements->style( [ 'attrName' => 'imageCaption' ] ),
				$elements->style( [ 'attrName' => 'imageDescription' ] ),
				$elements->style( [ 'attrName' => 'lightboxSettings' ] ),

				// Overlay icon font (content + font-family via ::before).
				$elements->style( [
					'attrName'   => 'overlayIcon',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'                => $attrs['overlayIcon']['innerContent'] ?? null,
									'selector'            => $icon_selector,
									'declarationFunction' => [ self::class, 'icon_font_declaration' ],
								],
							],
						],
					],
				] ),

				// Icon color.
				CommonStyle::style( [
					'selector' => $icon_selector,
					'attr'     => $attrs['overlayIcon']['decoration']['color'] ?? [],
					'property' => 'color',
				] ),

				// Icon size.
				CommonStyle::style( [
					'selector' => $icon_selector,
					'attr'     => $attrs['overlayIcon']['decoration']['size'] ?? [],
					'property' => 'font-size',
				] ),

				// Mark border color.
				CommonStyle::style( [
					'selector' => $mark_selector,
					'attr'     => $attrs['hoverSettings']['advanced']['markBorderColor'] ?? [],
					'property' => 'border-color',
				] ),

				// Mark border width.
				CommonStyle::style( [
					'selector' => $mark_selector,
					'attr'     => $attrs['hoverSettings']['advanced']['markBorderWidth'] ?? [],
					'property' => 'border-width',
				] ),

				CssStyle::style( [
					'selector'  => $order_class,
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => self::custom_css(),
				] ),
			],
		] );
	}
}
