<?php
/**
 * Module: ACF Gallery
 *
 * @package DNXTE\Modules\AcfGallery
 * @since ??
 */

namespace DNXTE\Modules\AcfGallery;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\AcfGallery\AcfGalleryTrait;

/**
 * ACF Gallery module for Divi 5.
 *
 * @since ??
 */
class AcfGallery implements DependencyInterface {
	use AcfGalleryTrait\RenderCallbackTrait;

	/**
	 * Load the module.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'AcfGallery/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ AcfGallery::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
