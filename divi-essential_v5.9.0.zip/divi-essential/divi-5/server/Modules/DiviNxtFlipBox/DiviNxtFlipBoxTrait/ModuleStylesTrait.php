<?php
/**
 * DiviNxtFlipBox::module_styles().
 *
 * @package MEE\Modules\DiviNxtFlipBox
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtFlipBox\DiviNxtFlipBoxTrait;

use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\DiviNxtFlipBox\DiviNxtFlipBox;
use DNXTE\Modules\Base\Traits\CommonTrait;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;
	use CommonTrait;

	/**
	 * DiviNxtFlipBox's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/DiviNxtFlipBox/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements  ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs    = $args['attrs'] ?? [];
		$elements = $args['elements'];
		$settings = $args['settings'] ?? [];
		$order_class  = $args['orderClass'];
		$colorStyle = [];

		$frontSelector = "{$order_class} .dnext-flpb-flibbox-card .dnext-flpb-flibbox-front";
		$backSelector = "{$order_class} .dnext-flpb-flibbox-card .dnext-flpb-flibbox-back";
		$frontBg = ( new self() )->applyBgOld( $attrs, 'frontBg', $order_class, $frontSelector, $args );
		$backBg = ( new self() )->applyBgOld( $attrs, 'backBg', $order_class, $backSelector, $args );

		$colorStyle = array_merge( $colorStyle, $frontBg, $backBg);
		$frontMaskPosition = (new self())->mask_position_style($elements,$attrs, 'frontMask', "$order_class .dnext-flipbox-front-image img");
		$backMaskPosition = (new self())->mask_position_style($elements,$attrs, 'backMask', "$order_class .dnext-flipbox-back-image img");

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					TextStyle::style(
						[
							'selector' => "{$args['orderClass']} .example_static_module__content-container",
							'attr'     => $attrs['module']['advanced']['text'] ?? [],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => DiviNxtFlipBox::custom_css(),
						]
					),

					// contentContainer.
					$elements->style(
						[
							'attrName' => 'contentContainer',
						]
					),

					// backContentContainer.
					$elements->style(
						[
							'attrName' => 'backContentContainer',
						]
					),
					// frontTitle.
					$elements->style(
						[
							'attrName' => 'frontTitle',
						]
					),
					// frontContent.
					$elements->style(
						[
							'attrName' => 'frontContent',
						]
					),
					// Image
					(new self())->image_style($elements, "frontImage", "$order_class .dnext-flipbox-front-image", $attrs),
					(new self())->image_style($elements, "backImage", "$order_class .dnext-flipbox-back-image", $attrs),
					// backIcon.
					(new self())->icon_style($elements, "frontIcon", "$order_class .dnext-flpb-flibbox-front .dnext-flpb-flibbox-icon-font", $attrs),
					(new self())->icon_style($elements, "backIcon", "$order_class .dnext-flpb-flibbox-back .dnext-flpb-flibbox-icon-font", $attrs),
					// backTitle.
					$elements->style(
						[
							'attrName' => 'backTitle',
						]
					),
					// backContent.
					$elements->style(
						[
							'attrName' => 'backContent',
						]
					),
					// flipButton.
					(new self())->button_style($elements, $attrs, "flipButton", "$order_class .dnext-flpb-flibbox-flip-button"),
					$frontMaskPosition,
					$backMaskPosition,
					// flipButtonContainer.
					$elements->style(
						[
							'attrName' => 'flipButtonContainer',
						]
					),
					...$colorStyle
				],
			]
		);
	}

	public function button_style($elements, $attrs, $slug, $selector) {

		return $elements->style(
			[
				'attrName' => $slug,
				'styleProps'=> [
					'advancedStyles' => [
						[
							'componentName'=> 'divi/common',
							'props'=>[
								'selector'=> $selector . " .dnext-flpb-flibbox-readmore",
								'attr'=> $attrs[$slug]['decoration']['background'] ?? [],
								'property'=> 'background',
							]
						],
						[
						      // button alignment
							'componentName'=> 'divi/common',
							'props'=>[
								'selector'=> $selector,
								'attr'=> $attrs[$slug]['decoration']['font']['font'] ?? [],
								'declarationFunction' => [ self::class, 'button_alignment_declaration' ],
							]
						],
						[
							'componentName'=> 'divi/common',
							'props'=>[
								'selector'=> $selector,
								'attr'=> $attrs[$slug]['decoration']['spacing']['outer'] ?? [],
								'declarationFunction' => [ self::class, 'spacing_declaration' ],
							]
							],
							[
								'componentName'=> 'divi/common',
								'props'=>[
									'selector'=> $selector . " .dnext-flpb-flibbox-readmore",
									'attr'=> $attrs[$slug]['decoration']['spacing']['inner'] ?? [],
									'declarationFunction' => [ self::class, 'spacing_declaration' ],
								]
							]
					]
				]
			]
		);
	}

	public function icon_style($elements, $slug, $selector, $attrs) {
		return $elements->style(
			[
				'attrName' => $slug,
				'styleProps'=> [
					'advancedStyles' => [
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector . ":before",
								'attr'     => $attrs[$slug]['advanced']['icon'] ?? [],
								'declarationFunction' => [ self::class, 'icon_style_declaration' ],
							],
						],
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector . ":before",
								'attr'     => $attrs[$slug]['advanced']['color'] ?? [],
								'property' => "color",
							],
						],
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector . ":before",
								'attr'     => $attrs[$slug]['advanced']['size'] ?? [],
								'property' => "font-size",
							],
						],
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector,
								'attr'     => $attrs[$slug]['advanced']['alignment'] ?? [],
								'property' => "text-align",
							],
						],
					]
				]
			]
		);
	}

	public function image_style($elements, $slug, $selector, $attrs) {
        return $elements->style(
			[
				'attrName' => $slug,
				'styleProps'=> [
					'advancedStyles' => [
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector . "  img",
								'attr'     => $attrs[$slug]['decoration']['background'] ?? [],
								"property"	=> "background-color"
							],
						],
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector . "  img",
								'attr'     => $attrs[$slug]['decoration']['size'] ?? [],
								"property"	=> "width"
							],
						],
						[
							'componentName' => 'divi/common',
							'props'         => [
								'selector' => $selector,
								'attr'     => $attrs[$slug]['decoration']['alignment'] ?? [],
								"property"	=> "align-items"
							],
						],
					]
				]
			]
		);
	}

	public function mask_position_style($elements, $attrs, $slug, $selector) {
		$mask_style = $this->style_declaration();
		$imageHPosition = $attrs[$slug]['advanced']['imageHPosition']['desktop']['value'] ?? 0;
		$imageVPosition = $attrs[$slug]['advanced']['imageVPosition']['desktop']['value'] ?? 0;


		$imageHPositionTab = $attrs[$slug]['advanced']['imageHPosition']['tablet']['value'] ?? $imageHPosition;
		$imageVPositionTab = $attrs[$slug]['advanced']['imageVPosition']['tablet']['value'] ?? $imageVPosition;

		$imageHPositionPhone = $attrs[$slug]['advanced']['imageHPosition']['phone']['value'] ?? $imageHPositionTab;
		$imageVPositionPhone = $attrs[$slug]['advanced']['imageVPosition']['phone']['value'] ?? $imageVPositionTab;

		$mask_style->add("transform", "matrix(1, 0, 0, 1, $imageHPosition, $imageVPosition);");
		$imagePositionTab = "transform: matrix(1, 0, 0, 1, $imageHPositionTab, $imageVPositionTab);";
		$imagePositionPhone = "transform: matrix(1, 0, 0, 1, $imageHPositionPhone, $imageVPositionPhone);";

		$desktop =  $elements->style(
			[
				'attrName' => $slug,
				'styleProps'=> [
					'advancedStyles' => [
						[
							'componentName'=> 'divi/common',
							'props'=>[
								'selector'=> $selector,
								'attr'=> $attrs[$slug]['advanced']['imageHPosition'] ?? [],
								'property'=> $mask_style->value(),
							]
						]
					]
				]
			]
		);

		$responsive_rules = array(
			array(
				'atRules'     => '@media only screen and (max-width: 980px)',
				'selector'    => $selector,
				'declaration' => $imagePositionTab,
			),
			array(
				'atRules'     => '@media only screen and (max-width: 767px)',
				'selector'    => $selector,
				'declaration' => $imagePositionPhone,
			),
		);
		return array_merge($desktop, $responsive_rules);
	}
}
