<?php

/**
 * DiviNxtFlipBox::render_callback()
 *
 * @package MEE\Modules\DiviNxtFlipBox
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtFlipBox\DiviNxtFlipBoxTrait;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use DNXTE\Modules\DiviNxtFlipBox\DiviNxtFlipBox;
use DNXTE\Modules\Base\Traits\CommonTrait;

trait RenderCallbackTrait
{
    use CommonTrait;
	/**
	 * DiviNxtFlipBox render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param WP_Block       $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of DiviNxtFlipBox.
	 */
	public static function render_callback($attrs, $content, $block, $elements)
	{
		$self = new self();
		$flipbox_effect = $attrs['flipBoxEffect']['innerContent']['desktop']['value'] ?? 'right';
		$frontHasIcon = $attrs['frontIcon']['advanced']['use']['desktop']['value'] ?? '';
		$backHasIcon = $attrs['backIcon']['advanced']['use']['desktop']['value'] ?? '';

		// Check if front image is enabled and has a source.
		$frontImageUse = $attrs['frontImage']['innerContent']['desktop']['value']['use'] ?? 'off';
		$has_front_image_src = $frontImageUse === 'on' && ModuleUtils::has_value(
			$attrs['frontImage']['innerContent'] ?? [],
			[
				'valueResolver' => function ( $value ) {
					return ! empty( $value['src'] );
				},
			]
		);

		// Front Image.
		$front_image = $has_front_image_src ? HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [
					'class' => 'et_pb_image_wrap',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [
					$elements->style_components(
						[
							'attrName' => 'frontImage',
						]
					),
					$elements->render(
						[
							'attrName'    => 'frontImage',
							'elementType' => 'image',
							'attributes'  => [
								'class' => 'dnext-flpb-flipbox-front-image',
							],
						]
					),
				],
			]
		) : '';

		// Front Image container.
		$frontMask = $self->mask_style($attrs, 'frontMask');

		$front_image_container = $has_front_image_src ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flipbox-image dnext-flipbox-front-image',
					...$frontMask
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $front_image,
			]
		) : '';



		// Title.
		$front_title = $elements->render(
			[
				'attrName' => 'frontTitle',
				'tagName' => $attrs['frontTitle']['decoration']['headingTag']['desktop']['value'] ?? "h4",
				'attributes'        => [
                    'class' => 'dnext-flpb-flibbox-heading-font',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
			]
		);

		// Content.
		$front_content = $elements->render(
			[
				'tagName' => 'p',
				'attrName' => 'frontContent',
				// 'attributes'           => array(
				// 	'class' => array( 'dnext-flipbox-front-pra' ),
				// ),
				// 'selector'             => '{{selector}} .dnext-flipbox-front-pra',
                'childrenSanitizer' => 'et_core_esc_previously',
                'attributesSanitizers' => array( 'et_core_esc_previously' ),
			]
		);

		$front_content = sprintf('<div class="dnext-flipbox-front-pra">%1$s</div>', $front_content);

		$front_icon = $frontHasIcon == 'on' ?  sprintf('<span class="dnext-flpb-flibbox-icon-font"></span>') : '';

		$flipBox_front = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flpb-flibbox-front',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $front_icon . $front_image_container . $front_title . $front_content,
			]
		);



		// Check if back image is enabled and has a source.
		$backImageUse = $attrs['backImage']['innerContent']['desktop']['value']['use'] ?? 'off';
		$has_back_image_src = $backImageUse === 'on' && ModuleUtils::has_value(
			$attrs['backImage']['innerContent'] ?? [],
			[
				'valueResolver' => function ( $value ) {
					return ! empty( $value['src'] );
				},
			]
		);

		// Back Image.
		$back_image = $has_back_image_src ? HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [
					'class' => 'et_pb_image_wrap',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [
					$elements->style_components(
						[
							'attrName' => 'backImage',
						]
					),
					$elements->render(
						[
							'attrName'    => 'backImage',
							'elementType' => 'image',
							'attributes'  => [
								'class' => 'dnext-flpb-flipbox-back-image',
							],
						]
					),
				],
			]
		) : '';

		// Back Image container.
		$backMask = $self->mask_style($attrs, 'backMask');
		$back_image_container = $has_back_image_src ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flipbox-image dnext-flipbox-back-image',
					...$backMask
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $back_image,
			]
		) : '';

		// Title.
		$back_title = $elements->render(
			[
				'attrName' => 'backTitle',
				'elementType' => 'heading',
				'tagName' => $attrs['backTitle']['decoration']['headingTag']['desktop']['value'] ?? "h4",
				'attributes'        => [
                    'class' => 'dnext-flpb-flibbox-heading-back',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
			]
		);

		// Content.
		$back_content = $elements->render(
			[
    			'tagName' => 'p',
    			'attrName' => 'backContent',
    			// 'attributes'           => array(
    			// 	'class' => array( 'dnext-flipbox-back-pra' ),
    			// ),
    			// 'selector'             => '{{selector}} .dnext-flipbox-back-pra',
                'childrenSanitizer' => 'et_core_esc_previously',
                'attributesSanitizers' => array( 'et_core_esc_previously' ),
			]
		);

		$back_content = sprintf('<div class="dnext-flipbox-back-pra">%1$s</div>', $back_content);

		$buttonUse = $attrs['flipButton']['innerContent']['desktop']['value']['use'] ?? 'on';
		$buttonText = $attrs['flipButton']['innerContent']['desktop']['value']['text'] ?? '';
		$linkTarget = $attrs['flipButton']['innerContent']['desktop']['value']['linkTarget'] ?? 'off';
		$buttonLink = $attrs['flipButton']['innerContent']['desktop']['value']['linkUrl'] ?? '';
		$flip_button = "on" === $buttonUse ? sprintf('<a
              class="dnext-flpb-flibbox-readmore"
              href="%1$s"
              target="%2$s"
            >
              %3$s
            </a>', esc_url( $buttonLink ), 'on' === $linkTarget ? '_blank' : '_self', esc_html( $buttonText )) : '';

		// todo: we will use this way to make this button responsive
		// $flip_button = $elements->render([
				// 'attrName' => 'flipButton',
				// 'elementType' => 'button',
		// ]);

		$flip_button_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flpb-flibbox-flip-button',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $flip_button,
			]
		);

		$back_icon = $backHasIcon == 'on' ? sprintf('<span class="dnext-flpb-flibbox-icon-font"></span>') : '';

		$flipBox_back = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flpb-flibbox-back',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $back_icon. $back_image_container . $back_title . $back_content . $flip_button_container,
			]
		);

		$flipBox_card = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-flpb-flibbox-card',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $flipBox_front . $flipBox_back,
			]
		);

		$parent       = BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [DiviNxtFlipBox::class, 'module_classnames'],
				'stylesComponent'     => [DiviNxtFlipBox::class, 'module_styles'],
				'scriptDataComponent' => [DiviNxtFlipBox::class, 'module_script_data'],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => [
					ElementComponents::component(
						[
							'attrs'         => $attrs['module']['decoration'] ?? [],
							'id'            => $block->parsed_block['id'],

							// FE only.
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						]
					),
					HTMLUtility::render(
						[
							'tag'               => 'div',
							'attributes'        => [
								'class' => "dnext-flpb-flibbox-card-wrapper dnext-flpb-flibbox-flip-{$flipbox_effect}",
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $flipBox_card,
						]
					),
				],
			]
		);
	}

	public function mask_style($attrs, $slug){
		$shapeUse = $attrs[$slug]['advanced']['use']['desktop']['value'] ?? "off";
		$useUploaded = $attrs[$slug]['advanced']['useUploaded']['desktop']['value'] ?? "off";
		$uploadedShape = $attrs[$slug]['advanced']['uploadedShape']['desktop']['value'] ?? "";

		$shapeName = $attrs[$slug]['advanced']['shape']['desktop']['value'] ?? "";

		$shapeSize = $attrs[$slug]['advanced']['shapeSize']['desktop']['value'] ?? "";

		$shapeName    = "on" == $shapeUse && "none" != $shapeName ? $shapeName : "";
		$uploadedShape= "on" == $useUploaded ? $uploadedShape : "";
		return [
			'data-svg-shape' => $shapeName,
			'data-shape-size' => $shapeSize,
			'data-use-upload' => $useUploaded,
			'data-uploaded-mask' => $uploadedShape
		];
	}
}
