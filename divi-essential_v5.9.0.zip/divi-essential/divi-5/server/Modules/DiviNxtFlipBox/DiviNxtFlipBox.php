<?php
/**
 * Module: DiviNxt FlipBox class.
 *
 * @package MEE\Modules\DiviNxtFlipBox
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtFlipBox;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;


/**
 * `DiviNxtFlipBox` is consisted of functions used for DiviNxtFlipBox such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class DiviNxtFlipBox implements DependencyInterface {
	use DiviNxtFlipBoxTrait\RenderCallbackTrait;
	use DiviNxtFlipBoxTrait\ModuleClassnamesTrait;
	use DiviNxtFlipBoxTrait\ModuleStylesTrait;
	use DiviNxtFlipBoxTrait\ModuleScriptDataTrait;

	/**
	 * Loads `DiviNxtFlipBox` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'DiviNxtFlipBox/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ self::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
