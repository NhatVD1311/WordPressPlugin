<?php
/**
 * DualButton::module_script_data()
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

 namespace DNXTE\Modules\DualButton\DualButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

//use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		// Enqueue hover common CSS for frontend
		wp_enqueue_style( 'dnext_hvr_common_css', DIVI_ESSENTIAL_URL . 'assets/css/hover-common.css', array(), DIVI_ESSENTIAL_VERSION );

		// Assign variables.
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$elements       = $args['elements'];
		$store_instance = $args['storeInstance'] ?? null;

		// Module decoration attributes.
		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		// Element Script Data Options.
		$elements->script_data(
			[
				'attrName' => 'module',
			]
		);

		MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'storeInstance' => $store_instance,
				'hoverSelector' => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'setContent'    => [
					[
						[
							'selector'      => $selector . ' .dnxt-one-btn-icon i',
							'data'          => $attrs['btn_one_icon']['innerContent'] ?? [],
							'valueResolver' => function ( $value ) {
								return Utils::process_font_icon( $value ) ?? '';
							},
						],
						[
							'selector'      => $selector . ' .dnxt-two-btn-icon i',
							'data'          => $attrs['btn_two_icon']['innerContent'] ?? [],
							'valueResolver' => function ( $value ) {
								return Utils::process_font_icon( $value ) ?? '';
							},
						],
					]
				]

			]
		);
	}

}
