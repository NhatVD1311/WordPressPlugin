<?php
/**
 * DualButton::render_callback()
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

 namespace DNXTE\Modules\DualButton\DualButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Framework\Utility\HTMLUtility;
use DNXTE\Modules\DualButton\DualButton;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use DNXTE\Modules\DualButton\DualButtonTrait\StyleDeclarationTrait;
use WP_Block;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use StyleDeclarationTrait;
	/**
	 * Divi 4 module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( array $attrs, string $content, WP_Block $block, ModuleElements $elements, array $default_printed_style_attrs ):string {
		// Button One.
        $button_text_one = $attrs['button_text_one']['innerContent']['desktop']['value']['text'] ?? '';
		$button_link = $attrs['button_text_one']['innerContent']['desktop']['value']['linkUrl'] ?? '';
		$button_one_target_value = $attrs['button_text_one']['innerContent']['desktop']['value']['linkTarget'] ?? '';
		$button_text_one = empty( $button_text_one ) && ! empty( $button_link) ? esc_url( $button_link) : esc_attr( $button_text_one);
		
		$button_alignment_desktop = $attrs['button_text_one']['advanced']['alignment']['desktop']['value'] ?? 'left';
		$button_alignment_tablet = $attrs['button_text_one']['advanced']['alignment']['tablet']['value'] ?? $button_alignment_desktop;
		$button_alignment_phone = $attrs['button_text_one']['advanced']['alignment']['phone']['value'] ?? $button_alignment_tablet;

		$button_one_target = 'on' === $button_one_target_value ? '_blank' : null;

		// Button One hover effects - read from converted paths only
		$hover_effect_two_d_one = $attrs['button_text_one']['advanced']['hoverEffect2d']['desktop']['value'] ?? '';
		$bg_hover_one_effect 	= $attrs['button_text_one']['advanced']['hoverEffectBg']['desktop']['value'] ?? '';
		$strock_hover_effect_one= $attrs['button_text_one']['advanced']['hoverEffectBorder']['desktop']['value'] ?? '';

		// Icon One - use 'show' attribute (not 'use')
		$use_icon   = $attrs['btn_one_icon']['advanced']['show']['desktop']['value'] ?? 'on';
		$icon_value = Utils::process_font_icon($attrs['btn_one_icon']['innerContent']['desktop']['value'] ?? '');
		$is_icon_enabled = 'on' === $use_icon;
		$icon_placement = $attrs['btn_one_icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$id_class_one = $attrs['button_text_one']['advanced']['htmlAttributes']['desktop']['value'] ?? array('id'=>'','class'=>'');
		$id_class_two = $attrs['button_text_two']['advanced']['htmlAttributes']['desktop']['value'] ?? array('id'=>'','class'=>'');
		// Button Two
		$button_text_two = $attrs['button_text_two']['innerContent']['desktop']['value']['text'] ?? '';
		$button_link_two = $attrs['button_text_two']['innerContent']['desktop']['value']['linkUrl'] ?? '';
		$button_two_target_value = $attrs['button_text_two']['innerContent']['desktop']['value']['linkTarget'] ?? '';

		$button_text_two = empty( $button_text_two ) && ! empty( $button_link_two) ? esc_url( $button_link_two) : esc_attr( $button_text_two);

		$button_two_target = 'on' === $button_two_target_value ? '_blank' : null;

		// Button Two hover effects - read from converted paths only
		$hover_effect_two_d_two = $attrs['button_text_two']['advanced']['hoverEffect2d']['desktop']['value'] ?? '';
		$bg_hover_two_effect = $attrs['button_text_two']['advanced']['hoverEffectBg']['desktop']['value'] ?? '';
		$strock_hover_effect_two = $attrs['button_text_two']['advanced']['hoverEffectBorder']['desktop']['value'] ?? '';
		$btnOneHoverIcons = $attrs['btn_one_icon']['advanced']['hoverIcons']['desktop']['value'] ?? '';
		$btnTwoHoverIcons = $attrs['btn_two_icon']['advanced']['hoverIcons']['desktop']['value'] ?? '';

		// Icon Two - use 'show' attribute (not 'use')
		$use_icon_two   = $attrs['btn_two_icon']['advanced']['show']['desktop']['value'] ?? 'on';
		$icon_two_value = Utils::process_font_icon($attrs['btn_two_icon']['innerContent']['desktop']['value'] ?? '');
		$is_icon_two_enabled = 'on' === $use_icon_two;
		$icon_two_placement = $attrs['btn_two_icon']['advanced']['placement']['desktop']['value'] ?? 'right';

		//Button On Hover class inner
		$btnIconOneOnHover = 'off' == $attrs['btn_one_icon']['advanced']['onHover']['desktop']['value'] ? "dnxt-btn-icon-one-on-hover" : "";
		$btnIconTwoOnHover = 'off' == $attrs['btn_two_icon']['advanced']['onHover']['desktop']['value'] ? "dnxt-btn-icon-two-on-hover" : "";

		// Icon.
		$icon       = ! empty( $icon_value ) && $is_icon_enabled ? HTMLUtility::render(
			[
				'tag'               => 'i',
				'attributes'        => [],
				'childrenSanitizer' =>  'et_core_esc_previously',
				'children'          =>  $icon_value,
			]
		) : '';

		// Icon.
		$icon_two       = ! empty( $icon_two_value ) && $is_icon_two_enabled ? HTMLUtility::render(
			[
				'tag'               => 'i',
				'attributes'        => [],
				'childrenSanitizer' =>  'et_core_esc_previously',
				'children'          =>  $icon_two_value,
			]
		) : '';

		$right_icon = $left_icon  = '';
		if ( 'left' === $icon_placement ) {
			$left_icon 	= $icon;
		} else {
			$right_icon = $icon;
		}
		
		$right_icon_two = $left_icon_two  = '';
		if ( 'left' === $icon_two_placement ) {
			$left_icon_two 	= $icon_two;
		} else {
			$right_icon_two = $icon_two;
		}
		$class_one 	= $id_class_one['class'] ?? '';
		$class_two 	= $id_class_two['class'] ?? '';
		$id_one 	= $id_class_one['id'] ?? '';
		$id_two 	= $id_class_two['id'] ?? '';

		$attributes_one = [
			'href' 	=> $button_link,
			'id' 	=> $id_one,
			'class'	=> "buttonOne dnxt-one-btn-icon $class_one {$btnIconOneOnHover} {$btnOneHoverIcons} {$hover_effect_two_d_one} {$bg_hover_one_effect} {$strock_hover_effect_one}",
			'target'  => $button_one_target,
		];

		$attributes_two = [
			'href' 	=> $button_link_two,
			'id' 	=> $id_two,
			'class'=> "buttonTwo dnxt-two-btn-icon $class_two  {$btnIconTwoOnHover} {$btnTwoHoverIcons} {$hover_effect_two_d_two}  {$bg_hover_two_effect} {$strock_hover_effect_two}",
			'target'  => $button_two_target,
		];
 
		// Button Wrapper
        $button_wrapper = HTMLUtility::render(
            [
              'tag'               =>  'div',
              'attributes'        =>  [
                'class'         => 'et_pb_module_inner',
              ],
              'childrenSanitizer' =>  'et_core_esc_previously',
              'children'          =>  [
                HTMLUtility::render(
                  [
                    'tag'               => 'div',
                    'attributes'        => [
					  'class'           => HTMLUtility::classnames(
						[
							'dnxt-button-wrapper' => true,
							"dnxt_button_alignment_{$button_alignment_desktop}" => ! empty( $button_alignment_desktop ),
							"dnxt_button_alignment_{$button_alignment_tablet}_tablet" => ! empty( $button_alignment_tablet ),
							"dnxt_button_alignment_{$button_alignment_phone}_phone" => ! empty( $button_alignment_phone ),
						]
					  ), 
                    ],
                    'childrenSanitizer' =>  'et_core_esc_previously',
                    'children'          => [
						HTMLUtility::render(
							[
							  'tag'         => 'a',
							//   'attributes'  => [
							// 	'href' => $button_link,
							// 	'class'=> "buttonOne dnxt-one-btn-icon {$btnIconOneOnHover} {$icon_one_hover_effect} {$hover_effect_two_d_one} {$bg_hover_one_effect} {$strock_hover_effect_one}",
							// 	'target'  => $button_one_target
							//   ],
							   'attributes'=>$attributes_one,
							  'childrenSanitizer' =>  'et_core_esc_previously',
							  'children'  => $elements->style_components(
								[
								  'attrName' => 'button_text_one',
								]
							  ) . $left_icon . $button_text_one . $right_icon
						]),
						HTMLUtility::render(
								[
									'tag'         => 'a',
									// 'attributes'  => [
									// 'href' => $button_link,
									// 'class'=> "buttonTwo dnxt-two-btn-icon {$btnIconTwoOnHover} {$icon_two_hover_effect} {$hover_effect_two_d_two}  {$bg_hover_two_effect} {$strock_hover_effect_two}",
									// 'target'  => $button_two_target
									// ],
									'attributes'=>$attributes_two,
									'childrenSanitizer' =>  'et_core_esc_previously',
									'children'  => $elements->style_components(
									[
										'attrName' => 'button_text_two',
									]
									) . $left_icon_two . $button_text_two . $right_icon_two
						])
                    ]
                  ]
                )
              ],
            ]
		);


		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ DualButton::class, 'module_classnames' ],
				'stylesComponent'     => [ DualButton::class, 'module_styles' ],
				'scriptDataComponent' => [ DualButton::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
                'hasModuleWrapper'    => false,
				'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $button_wrapper
			]
		);
	}
}
