<?php
/**
 * DualButton::render_callback()
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

 namespace DNXTE\Modules\DualButton\DualButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use Exception;

trait StyleDeclarationTrait{
	/**
	 * Icon Font declaration.
	 *
	 * This function will declare icon font for Child module.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array      $attrValue  The value (breakpoint > state > value) of module attribute.
	 *     @type bool|array $important  If set to true, the CSS will be added with !important.
	 *     @type string     $returnType This is the type of value that the function will return. Can be either string or key_value_pair.
	 * }
	 *
	 * @return string
	 * @since ??
	 */
	public static function icon_style_one_declaration( array $params ) {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
				],
			]
		);

		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		// if ( ! empty( $icon_attr['unicode'] ) ) {
		// 	$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		// }

		return $style_declarations->value();
	}

	public static function icon_style_two_declaration( array $params ) {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
				],
			]
		);


		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		// if ( ! empty( $icon_attr['unicode'] ) ) {
		// 	$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		// }

		return $style_declarations->value();
	}


	public static function icon_one_hover_style_declaration( array $params ) {
		$icon_attr = $params['attr'];

		$icon_placement = $icon_attr['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['onHover']['desktop']['value'] ?? 'on';

		return self::apply_hover_effect( $icon_on_hover , $icon_placement );
	}

	public static function icon_two_hover_style_declaration( array $params ) {
		$icon_attr = $params['attr'];

		$icon_placement = $icon_attr['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['onHover']['desktop']['value'] ?? 'on';


		return self::apply_hover_effect( $icon_on_hover , $icon_placement );
	}

	public static function apply_hover_effect( $icon_on_hover , $icon_placement ){

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		if('on' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('off' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('on' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}
		if('off' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}


		return $style_declarations->value();
	}

	/**
	 * Default icon visibility style declaration (for when icon should show by default, not on hover).
	 *
	 * @param array $params
	 * @return string
	 */
	public static function icon_one_default_style_declaration( array $params ) {
		$icon_attr = $params['attr'] ?? [];

		$icon_placement = $icon_attr['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['onHover']['desktop']['value'] ?? 'on';

		// Only apply styles when onHover is 'off' (show icon by default)
		if ('off' !== $icon_on_hover) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		$style_declarations->add( 'opacity', '1' );
		$style_declarations->add( 'visibility', 'visible' );
		$style_declarations->add( 'margin-left', '0' );

		if ('right' === $icon_placement) {
			$style_declarations->add( 'padding-left', '0.4em' );
		} else {
			$style_declarations->add( 'padding-right', '0.4em' );
		}

		return $style_declarations->value();
	}

	/**
	 * Default icon visibility style declaration for button two.
	 *
	 * @param array $params
	 * @return string
	 */
	public static function icon_two_default_style_declaration( array $params ) {
		$icon_attr = $params['attr'];

		$icon_placement = $icon_attr['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['onHover']['desktop']['value'] ?? 'on';

		// Only apply styles when onHover is 'off' (show icon by default)
		if ('off' !== $icon_on_hover) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		$style_declarations->add( 'opacity', '1' );
		$style_declarations->add( 'visibility', 'visible' );
		$style_declarations->add( 'margin-left', '0' );

		if ('right' === $icon_placement) {
			$style_declarations->add( 'padding-left', '0.4em' );
		} else {
			$style_declarations->add( 'padding-right', '0.4em' );
		}

		return $style_declarations->value();
	}

	/**
	 * Gradient style declaration for button backgrounds.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array $attrValue The value of module attribute.
	 * }
	 *
	 * @return string
	 */
	public static function gradient_style_declaration( array $params ) {
		$attr = $params['attrValue'] ?? $params['attr'] ?? [];

		// Access advanced property - similar to TypeScript attr.attr.attr.advanced
		$advanced = $attr['advanced'] ?? [];

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		// Check if gradient is enabled
		$use_gradient = $advanced['use'] ?? '';

		if ( 'on' === $use_gradient ) {
			$gradient_type    = ! empty( $advanced['gradient_type'] ) ? $advanced['gradient_type'] : 'linear-gradient';
			$linear_direction = ! empty( $advanced['linear_direction'] ) ? $advanced['linear_direction'] : '180deg';
			$radial_direction = ! empty( $advanced['radial_direction'] ) ? $advanced['radial_direction'] : 'center';
			$color_one        = $advanced['color'] ?? '';
			$color_two        = $advanced['color2'] ?? '';
			$start_position   = ! empty( $advanced['start_position'] ) ? $advanced['start_position'] : '0%';
			$end_position     = ! empty( $advanced['end_position'] ) ? $advanced['end_position'] : '100%';

			if ( ! empty( $color_one ) && ! empty( $color_two ) ) {
				if ( 'radial-gradient' === $gradient_type ) {
					// Format radial gradient correctly for frontend compatibility
					$gradient = "{$gradient_type}(circle at {$radial_direction}, {$color_one} {$start_position}, {$color_two} {$end_position})";
				} else {
					// Linear gradient with normal spacing
					$gradient = "{$gradient_type}({$linear_direction}, {$color_one} {$start_position}, {$color_two} {$end_position})";
				}

				$style_declarations->add( 'background', $gradient );
			}
		}

		return $style_declarations->value();
	}

	/**
	 * Background color declaration for hover effects.
	 *
	 * This function extracts the background color from the attr value structure
	 * and returns it as a CSS background declaration.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array $attrValue The value of module attribute (breakpoint > state > value structure).
	 * }
	 *
	 * @return string
	 */
	public static function background_color_declaration( array $params ) {
		$attr_value = $params['attrValue'] ?? [];

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		// Handle both direct color values and nested background structures
		$color = null;

		// Check for direct color value (like hoverBgColor structure)
		if ( is_string( $attr_value ) ) {
			$color = $attr_value;
		} elseif ( isset( $attr_value['color'] ) ) {
			// Background object with color property
			$color = $attr_value['color'];
		} elseif ( isset( $attr_value['desktop']['value']['color'] ) ) {
			$color = $attr_value['desktop']['value']['color'];
		} elseif ( isset( $attr_value['desktop']['value'] ) && is_string( $attr_value['desktop']['value'] ) ) {
			$color = $attr_value['desktop']['value'];
		}

		if ( ! empty( $color ) ) {
			$style_declarations->add( 'background', $color );
		}

		return $style_declarations->value();
	}

	/**
	 * Button spacing declaration for padding and margin.
	 * Handles both Divi 5 object format and Divi 4 pipe-separated format.
	 *
	 * @param array $params
	 * @return string
	 */
	public static function button_spacing_declaration( array $params ) {
		$attr = $params['attrValue'] ?? $params['attr'] ?? [];

		$css = '';

		// Handle padding
		$padding = $attr['desktop']['value']['padding'] ?? $attr['padding'] ?? null;
		if ( ! empty( $padding ) ) {
			$css .= self::parse_spacing_value( $padding, 'padding' );
		}

		// Handle margin
		$margin = $attr['desktop']['value']['margin'] ?? $attr['margin'] ?? null;
		if ( ! empty( $margin ) ) {
			$css .= self::parse_spacing_value( $margin, 'margin' );
		}

		return $css;
	}

	/**
	 * Parse spacing value from Divi 4 pipe format or Divi 5 object format.
	 *
	 * @param mixed  $value The spacing value (string with pipes or object).
	 * @param string $property Either 'padding' or 'margin'.
	 * @return string CSS spacing value with individual properties.
	 */
	private static function parse_spacing_value( $value, $property = 'padding' ) {
		if ( empty( $value ) ) {
			return '';
		}

		// If it's already an object with top/right/bottom/left
		if ( \is_array( $value ) ) {
			$top    = $value['top'] ?? '';
			$right  = $value['right'] ?? '';
			$bottom = $value['bottom'] ?? '';
			$left   = $value['left'] ?? '';

			$css = '';
			if ( $top ) $css .= "{$property}-top: {$top}; ";
			if ( $right ) $css .= "{$property}-right: {$right}; ";
			if ( $bottom ) $css .= "{$property}-bottom: {$bottom}; ";
			if ( $left ) $css .= "{$property}-left: {$left}; ";
			return $css;
		}

		// Handle Divi 4 pipe-separated format: "top|right|bottom|left|linked|linked"
		if ( \is_string( $value ) && strpos( $value, '|' ) !== false ) {
			$parts  = explode( '|', $value );
			$top    = ! empty( $parts[0] ) ? $parts[0] : '';
			$right  = ! empty( $parts[1] ) ? $parts[1] : '';
			$bottom = ! empty( $parts[2] ) ? $parts[2] : '';
			$left   = ! empty( $parts[3] ) ? $parts[3] : '';

			$css = '';
			if ( $top ) $css .= "{$property}-top: {$top}; ";
			if ( $right ) $css .= "{$property}-right: {$right}; ";
			if ( $bottom ) $css .= "{$property}-bottom: {$bottom}; ";
			if ( $left ) $css .= "{$property}-left: {$left}; ";
			return $css;
		}

		// Return as-is if it's a simple value
		return \is_string( $value ) ? "{$property}: {$value};" : '';
	}

	/**
	 * Get gradient style for button using CommonStyle.
	 *
	 * @param array  $advanced_attrs The advanced attributes containing gradient settings.
	 * @param string $selector       The CSS selector.
	 *
	 * @return mixed CommonStyle output or empty string.
	 */
	public static function get_gradient_style( array $advanced_attrs, string $selector ) {
		$use_gradient = $advanced_attrs['use'] ?? '';

		if ( 'on' !== $use_gradient ) {
			return '';
		}

		$gradient_type    = ! empty( $advanced_attrs['gradient_type'] ) ? $advanced_attrs['gradient_type'] : 'linear-gradient';
		$linear_direction = ! empty( $advanced_attrs['linear_direction'] ) ? $advanced_attrs['linear_direction'] : '180deg';
		$radial_direction = ! empty( $advanced_attrs['radial_direction'] ) ? $advanced_attrs['radial_direction'] : 'center';
		$color_one        = $advanced_attrs['color'] ?? '';
		$color_two        = $advanced_attrs['color2'] ?? '';
		$start_position   = ! empty( $advanced_attrs['start_position'] ) ? $advanced_attrs['start_position'] : '0%';
		$end_position     = ! empty( $advanced_attrs['end_position'] ) ? $advanced_attrs['end_position'] : '100%';

		if ( empty( $color_one ) || empty( $color_two ) ) {
			return '';
		}

		if ( 'radial-gradient' === $gradient_type ) {
			// Format radial gradient correctly for frontend compatibility
			$gradient = "{$gradient_type}(circle at {$radial_direction}, {$color_one} {$start_position}, {$color_two} {$end_position})";
		} else {
			// Linear gradient with normal spacing
			$gradient = "{$gradient_type}({$linear_direction}, {$color_one} {$start_position}, {$color_two} {$end_position})";
		}

		return CommonStyle::style(
			[
				'selector'  => $selector,
				'property'  => 'background',
				'important' => true,
				'attr'      => [
					'desktop' => [
						'value' => $gradient,
					],
				],
			]
		);
	}

}