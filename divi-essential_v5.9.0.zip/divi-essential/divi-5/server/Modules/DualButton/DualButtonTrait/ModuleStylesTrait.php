<?php
/**
 * DualButton::module_styles().
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

namespace DNXTE\Modules\DualButton\DualButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DNXTE\Modules\DualButton\DualButton;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use StyleDeclarationTrait;
	public static function applyHoverStyles($selector, $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass, $buttonClass = '') {
		$styles = [];

		// Build the full selector - if buttonClass is provided, use it for specificity
		$fullSelector = ! empty( $buttonClass ) ? "{$orderClass} {$buttonClass}{$selector}" : "{$orderClass} {$selector}";

		if ( ! empty( $mainBackgroundAttr ) && is_array( $mainBackgroundAttr ) ) {
			$styles[] = CommonStyle::style(
				[
					'selector'            => $fullSelector,
					'attr'                => $mainBackgroundAttr,
					'declarationFunction' => [ self::class, 'background_color_declaration' ],
					'important'           => true,
				]
			);
		}

		if ( ! empty( $beforeBackgroundAttr ) && is_array( $beforeBackgroundAttr ) ) {
			$styles[] = CommonStyle::style(
				[
					'selector'            => "{$fullSelector}:before",
					'attr'                => $beforeBackgroundAttr,
					'declarationFunction' => [ self::class, 'background_color_declaration' ],
					'important'           => true,
				]
			);
		}

		return $styles;

	}

	/**
	 * D4 module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/d4-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$orderClass                  = $args['orderClass'] ?? '';

		// Default shutter background color (matching Divi 4)
		$defaultShutterBgColor = [
			'desktop' => [
				'value' => 'rgba(0,0,0,0.3)',
			],
		];

		// Default hover background color (matching Divi 4: dnxt_dual_one_hover_bg_color default)
		$defaultHoverBgColor = [
			'desktop' => [
				'value' => '#29c4a9',
			],
		];

		$hover_bg_one_value = $attrs['button_text_one']['advanced']['hoverEffectBg']['desktop']['value'] ?? null;
		$mainBackgroundAttr = $attrs['button_text_one']['decoration']['background'] ?? null;
		$beforeBackgroundAttr = $attrs['dnxt_dual_one_bg_color']['advanced']['shutterBgColor'] ?? $defaultShutterBgColor;
		// Get hover bg color - matches Divi 4 pattern: dnxt_dual_one_hover_bg_color -> button_text_one.advanced.hoverBgColor
		$hoverBgColorOne = $attrs['button_text_one']['advanced']['hoverBgColor'] ?? $defaultHoverBgColor;

		// Effects that have their own specific :before color handling (should NOT use general hoverBgColor on :before)
		$effectsWithSpecificBeforeColor = [
			'dnxt-hover-shutter-in-horizontal',
			'dnxt-hover-shutter-out-horizontal',
			'dnxt-hover-shutter-in-vertical',
			'dnxt-hover-shutter-out-vertical',
			'dnxt-hover-radial-in',
			'dnxt-hover-radial-out',
			'dnxt-hover-rectangle-in',
			'dnxt-hover-rectangle-out',
		];
		$shouldApplyGeneralHoverBgOne = ! in_array( $hover_bg_one_value, $effectsWithSpecificBeforeColor, true );

		// Button Dual One Hover Background Color - only for effects without specific :before handling
		$hoverStyle = [];
		if ( ! empty( $hover_bg_one_value ) && ! empty( $hoverBgColorOne ) && $shouldApplyGeneralHoverBgOne ) {
			// 1. Set background on :before (like Divi 4 line 2280-2282)
			$hoverStyle[] = CommonStyle::style([
				'selector'            => "{$orderClass} a.buttonOne.{$hover_bg_one_value}:before",
				'attr'                => $hoverBgColorOne,
				'declarationFunction' => [ self::class, 'background_color_declaration' ],
			]);
			// 2. Set transform on :hover:before (like Divi 4 line 2284-2286)
			$hoverStyle[] = CommonStyle::style([
				'selector'  => "{$orderClass} .{$hover_bg_one_value}:hover:before",
				'attr'      => ['desktop' => ['value' => 'scaleX(1)']],
				'property'  => 'transform',
				'important' => true,
			]);
			// 3. For fade effect, apply to button:hover (like Divi 4 line 2288-2290)
			$hoverStyle[] = CommonStyle::style([
				'selector'            => "{$orderClass} a.buttonOne.dnxt-hover-fade:hover",
				'attr'                => $hoverBgColorOne,
				'declarationFunction' => [ self::class, 'background_color_declaration' ],
			]);
		}

		$styles = [];

		// Get specific color attributes for each effect with defaults
		$radialOutColorOne = $attrs['button_text_one']['advanced']['radialOutColor'] ?? $defaultShutterBgColor;
		$radialInColorOne = $attrs['button_text_one']['advanced']['radialInColor'] ?? $defaultShutterBgColor;
		$rectangleOutColorOne = $attrs['button_text_one']['advanced']['rectangleOutColor'] ?? $defaultShutterBgColor;
		$rectangleInColorOne = $attrs['button_text_one']['advanced']['rectangleInColor'] ?? $defaultShutterBgColor;

		// Hover effect styles matching Divi 4 exactly
		// Button One hover effects - use .dnxt-one-btn-icon for specificity
		switch ($hover_bg_one_value) {
		case 'dnxt-hover-radial-out':
			// Divi 4: Button = radialOutColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-out', $radialOutColorOne, $hoverBgColorOne, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		case 'dnxt-hover-radial-in':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = radialInColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-in', $hoverBgColorOne, $radialInColorOne, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		case 'dnxt-hover-rectangle-in':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = rectangleInColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-in', $hoverBgColorOne, $rectangleInColorOne, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		case 'dnxt-hover-rectangle-out':
			// Divi 4: Button = rectangleOutColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-out', $rectangleOutColorOne, $hoverBgColorOne, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		case 'dnxt-hover-shutter-in-horizontal':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = shutterBgColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-in-horizontal', $hoverBgColorOne, $beforeBackgroundAttr, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		case 'dnxt-hover-shutter-out-horizontal':
			// Divi 4: Button = shutterBgColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-out-horizontal', $beforeBackgroundAttr, $hoverBgColorOne, $orderClass, '.dnxt-one-btn-icon')
			);
			break;
		// Note: shutter-in-vertical and shutter-out-vertical are handled separately
		// via $shutter_one_in_bg and $shutter_one_out_v_bg arrays to match Divi 4 exactly
		default:
			break;
		}

		// Button One shutter-in-vertical: Button=hoverBgColor, :before=shutterBgColor, :hover:before=scaleY(0)
		$shutter_one_in_bg = [];
		if ('dnxt-hover-shutter-in-vertical' === $hover_bg_one_value) {
			// Get actual color values (like Divi 4)
			$hoverBgColorOneValue = $hoverBgColorOne['desktop']['value'] ?? '#29c4a9';
			$shutterBgColorOneValue = $attrs['dnxt_dual_one_bg_color']['advanced']['shutterBgColor']['desktop']['value'] ?? 'rgba(0,0,0,0.3)';


			// :before element: shutterBgColor
			$shutter_one_in_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonOne.dnxt-hover-shutter-in-vertical:before",
				'attr'      => ['desktop' => ['value' => $shutterBgColorOneValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :hover:before: transform scaleY(0)
			$shutter_one_in_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonOne.dnxt-hover-shutter-in-vertical:hover:before",
				'attr'      => ['desktop' => ['value' => 'scaleY(0)']],
				'property'  => 'transform',
				'important' => true,
			]);
		}

		// Button One shutter-out-vertical: Button=shutterBgColor, :before=hoverBgColor, :hover:before=scaleY(1)
		$shutter_one_out_v_bg = [];
		if ('dnxt-hover-shutter-out-vertical' === $hover_bg_one_value) {
			// Get actual color values (like Divi 4)
			$hoverBgColorOneValue = $hoverBgColorOne['desktop']['value'] ?? '#29c4a9';
			$shutterBgColorOneValue = $attrs['dnxt_dual_one_bg_color']['advanced']['shutterBgColor']['desktop']['value'] ?? 'rgba(0,0,0,0.3)';

			// Button element: shutterBgColor
			$shutter_one_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonOne.dnxt-hover-shutter-out-vertical",
				'attr'      => ['desktop' => ['value' => $shutterBgColorOneValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :before element: hoverBgColor
			$shutter_one_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonOne.dnxt-hover-shutter-out-vertical:before",
				'attr'      => ['desktop' => ['value' => $hoverBgColorOneValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :hover:before: transform scaleY(1)
			$shutter_one_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonOne.dnxt-hover-shutter-out-vertical:hover:before",
				'attr'      => ['desktop' => ['value' => 'scaleY(1)']],
				'property'  => 'transform',
				'important' => true,
			]);
		}

		// Button Two hover effect styles
		$hover_bg_two_value = $attrs['button_text_two']['advanced']['hoverEffectBg']['desktop']['value'] ?? null;
		$mainBackgroundAttrTwo = $attrs['button_text_two']['decoration']['background'] ?? null;
		$beforeBackgroundAttrTwo = $attrs['dnxt_dual_two_bg_color']['advanced']['shutterBgColor'] ?? $defaultShutterBgColor;
		$hoverBgColorTwo = $attrs['button_text_two']['advanced']['hoverBgColor'] ?? $defaultHoverBgColor;

		// Get specific color attributes for each effect with defaults (button two)
		$radialOutColorTwo = $attrs['button_text_two']['advanced']['radialOutColor'] ?? $defaultShutterBgColor;
		$radialInColorTwo = $attrs['button_text_two']['advanced']['radialInColor'] ?? $defaultShutterBgColor;
		$rectangleOutColorTwo = $attrs['button_text_two']['advanced']['rectangleOutColor'] ?? $defaultShutterBgColor;
		$rectangleInColorTwo = $attrs['button_text_two']['advanced']['rectangleInColor'] ?? $defaultShutterBgColor;

		// Button Two shutter-in-vertical: Button=hoverBgColor, :before=shutterBgColor, :hover:before=scaleY(0)
		$shutter_two_in_bg = [];
		if ('dnxt-hover-shutter-in-vertical' === $hover_bg_two_value) {
			// Get actual color values (like Divi 4)
			$hoverBgColorTwoValue = $hoverBgColorTwo['desktop']['value'] ?? '#29c4a9';
			$shutterBgColorTwoValue = $attrs['dnxt_dual_two_bg_color']['advanced']['shutterBgColor']['desktop']['value'] ?? 'rgba(0,0,0,0.3)';

			// :before element: shutterBgColor
			$shutter_two_in_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonTwo.dnxt-hover-shutter-in-vertical:before",
				'attr'      => ['desktop' => ['value' => $shutterBgColorTwoValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :hover:before: transform scaleY(0)
			$shutter_two_in_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonTwo.dnxt-hover-shutter-in-vertical:hover:before",
				'attr'      => ['desktop' => ['value' => 'scaleY(0)']],
				'property'  => 'transform',
				'important' => true,
			]);
		}

		// Button Two shutter-out-vertical: Button=shutterBgColor, :before=hoverBgColor, :hover:before=scaleY(1)
		$shutter_two_out_v_bg = [];
		if ('dnxt-hover-shutter-out-vertical' === $hover_bg_two_value) {
			// Get actual color values (like Divi 4)
			$hoverBgColorTwoValue = $hoverBgColorTwo['desktop']['value'] ?? '#29c4a9';
			$shutterBgColorTwoValue = $attrs['dnxt_dual_two_bg_color']['advanced']['shutterBgColor']['desktop']['value'] ?? 'rgba(0,0,0,0.3)';

			// Button element: shutterBgColor
			$shutter_two_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonTwo.dnxt-hover-shutter-out-vertical",
				'attr'      => ['desktop' => ['value' => $shutterBgColorTwoValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :before element: hoverBgColor
			$shutter_two_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonTwo.dnxt-hover-shutter-out-vertical:before",
				'attr'      => ['desktop' => ['value' => $hoverBgColorTwoValue]],
				'property'  => 'background',
				'important' => true,
			]);
			// :hover:before: transform scaleY(1)
			$shutter_two_out_v_bg[] = CommonStyle::style([
				'selector'  => "{$orderClass} a.buttonTwo.dnxt-hover-shutter-out-vertical:hover:before",
				'attr'      => ['desktop' => ['value' => 'scaleY(1)']],
				'property'  => 'transform',
				'important' => true,
			]);
		}

		// General hover bg color style for button two - only for effects without specific :before handling
		$hoverStyleTwo = [];
		$shouldApplyGeneralHoverBgTwo = ! in_array( $hover_bg_two_value, $effectsWithSpecificBeforeColor, true );
		if ( ! empty( $hover_bg_two_value ) && ! empty( $hoverBgColorTwo ) && $shouldApplyGeneralHoverBgTwo ) {
			$selectorTwo = $hover_bg_two_value === 'dnxt-hover-fade'
				? "{$orderClass} .dnxt-two-btn-icon.dnxt-hover-fade:hover"
				: "{$orderClass} .dnxt-two-btn-icon.{$hover_bg_two_value}:before";
			$hoverStyleTwo = [
				CommonStyle::style(
					[
						'selector'            => $selectorTwo,
						'attr'                => $hoverBgColorTwo,
						'declarationFunction' => [ self::class, 'background_color_declaration' ],
					]
				)
			];
		}

		// Button Two hover effects - use .dnxt-two-btn-icon for specificity (matching Divi 4)
		switch ($hover_bg_two_value) {
		case 'dnxt-hover-radial-out':
			// Divi 4: Button = radialOutColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-out', $radialOutColorTwo, $hoverBgColorTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		case 'dnxt-hover-radial-in':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = radialInColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-in', $hoverBgColorTwo, $radialInColorTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		case 'dnxt-hover-rectangle-in':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = rectangleInColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-in', $hoverBgColorTwo, $rectangleInColorTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		case 'dnxt-hover-rectangle-out':
			// Divi 4: Button = rectangleOutColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-out', $rectangleOutColorTwo, $hoverBgColorTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		case 'dnxt-hover-shutter-in-horizontal':
			// Divi 4: Button = hoverBgColor (revealed after hover), :before = shutterBgColor (overlay, default rgba(0,0,0,0.3))
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-in-horizontal', $hoverBgColorTwo, $beforeBackgroundAttrTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		case 'dnxt-hover-shutter-out-horizontal':
			// Divi 4: Button = shutterBgColor (initial visible), :before = hoverBgColor (revealed on hover)
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-out-horizontal', $beforeBackgroundAttrTwo, $hoverBgColorTwo, $orderClass, '.dnxt-two-btn-icon')
			);
			break;
		// Note: shutter-in-vertical and shutter-out-vertical are handled separately
		// via $shutter_two_in_bg and $shutter_two_out_v_bg arrays to match Divi 4 exactly
		default:
			break;
		}

		$hover_strock_value_one = $attrs['button_text_one']['advanced']['hoverEffectBorder']['desktop']['value'] ?? null;
		$hover_strock_value_two = $attrs['button_text_two']['advanced']['hoverEffectBorder']['desktop']['value'] ?? null;
		$has_strock_bg_color = [
			'dnxt-hover-underline-from-left',
			'dnxt-hover-underline-from-center',
			'dnxt-hover-underline-from-right',
			'dnxt-hover-overline-from-left',
			'dnxt-hover-overline-from-center',
			'dnxt-hover-overline-from-right',
			'dnxt-hover-underline-reveal',
			'dnxt-hover-overline-reveal',
		];
		$hover_strock_color_one = in_array($hover_strock_value_one ?? null, $has_strock_bg_color);
		$hover_strock_color_two = in_array($hover_strock_value_two ?? null, $has_strock_bg_color);
		// Build gradient styles array (filter out empty)
		$gradientStyles = array_filter([
			self::get_gradient_style(
				$attrs['button_text_one']['advanced'] ?? [],
				"{$args['orderClass']} .dnxt-button-wrapper .buttonOne"
			),
			self::get_gradient_style(
				$attrs['button_text_two']['advanced'] ?? [],
				"{$args['orderClass']} .dnxt-button-wrapper .buttonTwo"
			),
		]);

		// Icon visibility styles - matching TypeScript styles.tsx lines 63-95
		$iconVisibilityStyles = [];

		// Button One icon settings
		$btnIconOneOnHover = $attrs['btn_one_icon']['advanced']['onHover']['desktop']['value'] ?? 'on';
		$iconPlacementOne = $attrs['btn_one_icon']['advanced']['placement']['desktop']['value'] ?? 'right';

		// Button Two icon settings
		$btnIconTwoOnHover = $attrs['btn_two_icon']['advanced']['onHover']['desktop']['value'] ?? 'on';
		$iconPlacementTwo = $attrs['btn_two_icon']['advanced']['placement']['desktop']['value'] ?? 'right';

		// When onHover is 'off', show icon by default (not just on hover)
		if ('off' === $btnIconOneOnHover) {
			$padding = 'right' === $iconPlacementOne ? 'padding-left' : 'padding-right';
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '1'],
				],
				'property' => 'opacity',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => 'visible'],
				],
				'property' => 'visibility',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '0'],
				],
				'property' => 'margin-left',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '0.4em'],
				],
				'property' => $padding,
				'important' => true,
			]);
		}

		// When onHover is 'on', show icon only on hover
		if ('on' === $btnIconOneOnHover) {
			$padding = 'right' === $iconPlacementOne ? 'padding-left' : 'padding-right';
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '1'],
				],
				'property' => 'opacity',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => 'visible'],
				],
				'property' => 'visibility',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '0'],
				],
				'property' => 'margin-left',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-one-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '0.4em'],
				],
				'property' => $padding,
				'important' => true,
			]);
		}

		// Button Two visibility styles
		if ('off' === $btnIconTwoOnHover) {
			$padding = 'right' === $iconPlacementTwo ? 'padding-left' : 'padding-right';
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '1'],
				],
				'property' => 'opacity',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => 'visible'],
				],
				'property' => 'visibility',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '0'],
				],
				'property' => 'margin-left',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon i",
				'attr'     => [
					'desktop' => ['value' => '0.4em'],
				],
				'property' => $padding,
				'important' => true,
			]);
		}

		if ('on' === $btnIconTwoOnHover) {
			$padding = 'right' === $iconPlacementTwo ? 'padding-left' : 'padding-right';
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '1'],
				],
				'property' => 'opacity',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => 'visible'],
				],
				'property' => 'visibility',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '0'],
				],
				'property' => 'margin-left',
				'important' => true,
			]);
			$iconVisibilityStyles[] = CommonStyle::style([
				'selector' => "{$orderClass} .dnxt-two-btn-icon:hover i",
				'attr'     => [
					'desktop' => ['value' => '0.4em'],
				],
				'property' => $padding,
				'important' => true,
			]);
		}

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array_values(array_filter(array_merge(
					[
						$elements->style(
							[
								'attrName'   => 'module',
								'styleProps' => [
									'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
									'disabledOn'               => [
										'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
									],
								],
							]
						),
						CssStyle::style(
							[
								'selector'  => $args['orderClass'],
								'attr'      => $attrs['css'] ?? [],
								'cssFields' => self::custom_css(),
							]
						),
						// Button One Stroke Hover Color
						CommonStyle::style(
							[
								'selector' => "$orderClass a.buttonOne.{$hover_strock_value_one}:before",
								'property'=> $hover_strock_color_one ? 'background' : 'border-color',
								'attr'     => $attrs['strock_hover_color']['advanced']['strockhovercolor'] ?? [],
							]
						),
						// Button Two Stroke Hover Color
						CommonStyle::style(
							[
								'selector' => "$orderClass a.buttonTwo.{$hover_strock_value_two}:before",
								'property'=> $hover_strock_color_two ? 'background' : 'border-color',
								'attr'     => $attrs['strock_hover_color_two']['advanced']['strockhovercolor'] ?? [],
							]
						),
						...$shutter_one_in_bg,
						...$shutter_one_out_v_bg,
						...$shutter_two_in_bg,
						...$shutter_two_out_v_bg,
						// Button One text styles
						$elements->style(
							[
								'attrName' => 'button_text_one',
								'styleProps' => [
									'advancedStyles' => [
										[
											'componentName' => 'divi/common',
											'props' => [
												'selector' => "{$args['orderClass']} .dnxt-button-wrapper .buttonOne",
												'attr' => $attrs['button_text_one'] ?? [],
												'declarationFunction' => [ self::class, 'gradient_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props' => [
												'selector' => "{$args['orderClass']} .dnxt-one-btn-icon",
												'attr' => $attrs['button_text_one']['decoration']['spacing'] ?? [],
												'declarationFunction' => [ self::class, 'button_spacing_declaration' ],
											],
										],
									],
								],
							]
						),
						// Button Two text styles
						$elements->style(
							[
								'attrName' => 'button_text_two',
								'styleProps' => [
									'advancedStyles' => [
										[
											'componentName' => 'divi/common',
											'props' => [
												'selector' => "{$args['orderClass']} .dnxt-button-wrapper .buttonTwo",
												'attr' => $attrs['button_text_two'] ?? [],
												'declarationFunction' => [ self::class, 'gradient_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props' => [
												'selector' => "{$args['orderClass']} .dnxt-two-btn-icon",
												'attr' => $attrs['button_text_two']['decoration']['spacing'] ?? [],
												'declarationFunction' => [ self::class, 'button_spacing_declaration' ],
											],
										],
									],
								],
							]
						),
						$elements->style(
							[
								'attrName' => 'btn_one_icon',
								'styleProps'=> [
									'advancedStyles' => [
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-one-btn-icon i",
												'attr'     => $attrs['btn_one_icon']['innerContent'] ?? [],
												'declarationFunction' => [ self::class, 'icon_style_one_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-one-btn-icon i",
												'attr'     => $attrs['btn_one_icon']['advanced'] ?? [],
												'declarationFunction' => [ self::class, 'icon_one_default_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-one-btn-icon:hover i",
												'attr'     => $attrs['btn_one_icon']['advanced'] ?? [],
												'declarationFunction' => [ self::class, 'icon_one_hover_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-one-btn-icon.dnxt-btn-icon-one-on-hover i",
												'attr'     => $attrs['btn_one_icon']['advanced'] ?? [],
												'declarationFunction' => [ self::class, 'icon_one_hover_style_declaration' ],
											],
										],
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnxt-one-btn-icon i",
												'attr'=> $attrs['btn_one_icon']['advanced']['color'] ?? [],
												'property'=> 'color',
											]
										],
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnxt-one-btn-icon:hover i",
												'attr'=> $attrs['btn_one_icon']['advanced']['color'] ?? [],
												'property'=> 'color',
											]
										],
									]
								]
							]
						),
						$elements->style(
							[
								'attrName' => 'btn_two_icon',
								'styleProps'=> [
									'advancedStyles' => [
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnxt-two-btn-icon i",
													'attr'=> $attrs['btn_two_icon']['advanced']['color'] ?? null,
												'property'=> 'color'
											]
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-two-btn-icon i",
												'attr'     => $attrs['btn_two_icon']['innerContent'] ?? [],
												'declarationFunction' => [ self::class, 'icon_style_two_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-two-btn-icon i",
														'attr'     => $attrs['btn_two_icon']['advanced'] ?? null,
												'declarationFunction' => [ self::class, 'icon_two_default_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnxt-two-btn-icon.dnxt-btn-icon-two-on-hover i",
														'attr'     => $attrs['btn_two_icon']['advanced'] ?? null,
														'declarationFunction' => [ self::class, 'icon_two_hover_style_declaration' ],
											],
										],
										[
												'componentName' => 'divi/common',
												'props'         => [
													'selector' => "{$args['orderClass']} .dnxt-two-btn-icon:hover i",
													'attr'     => $attrs['btn_two_icon']['advanced'] ?? null,
													'declarationFunction' => [ self::class, 'icon_two_hover_style_declaration' ],
											],
										],
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnxt-two-btn-icon:hover i",
												'attr'=> $attrs['btn_two_icon']['advanced']['color'] ?? null,
												'property'=> 'color',
											]
										],
									]
								]
							]
						),
					],
					$styles,
					$hoverStyle,
					$hoverStyleTwo,
					$gradientStyles,
					$iconVisibilityStyles
				)))
			]
		);

	}

}
