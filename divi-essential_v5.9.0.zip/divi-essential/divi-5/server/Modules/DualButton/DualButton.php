<?php
/**
 * Module: Divi Dual Button Module class.
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

namespace DNXTE\Modules\DualButton;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\DualButton\DualButtonTrait;

/**
 * `Dual Button` is consisted of functions used for Dual Button Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class DualButton implements DependencyInterface {
	use DualButtonTrait\RenderCallbackTrait;

	/**
	 * Loads `DualButton` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextDualButton/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ DualButton::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
