<?php
/**
 * Module: Globe3dMap - Custom CSS Trait.
 *
 * @package DNXTE\Modules\Globe3dMap
 * @since ??
 */

namespace DNXTE\Modules\Globe3dMap\Globe3dMapTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	/**
	 * Get custom CSS fields for the Globe3dMap module.
	 *
	 * @return array
	 */
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/globe-3d-map' );
		return $block_type ? ( $block_type->customCssFields ?? array() ) : array();
	}
}
