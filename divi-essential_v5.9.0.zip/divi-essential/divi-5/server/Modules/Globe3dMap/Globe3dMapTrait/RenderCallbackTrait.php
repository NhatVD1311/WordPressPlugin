<?php
/**
 * Module: Globe3dMap - Render Callback Trait.
 *
 * @package DNXTE\Modules\Globe3dMap
 * @since ??
 */

namespace DNXTE\Modules\Globe3dMap\Globe3dMapTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use CustomCssTrait;

	/**
	 * Render callback for the Globe3dMap module.
	 *
	 * @param array    $attrs    Block attributes.
	 * @param string   $content  Block content.
	 * @param object   $block    Block object.
	 * @param object   $elements Elements instance.
	 *
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Extract globe settings
		$theme            = $attrs['globeSettings']['advanced']['theme']['desktop']['value'] ?? 'dark-space';
		$marker_style     = $attrs['globeSettings']['advanced']['markerStyle']['desktop']['value'] ?? 'pins';
		$connection_style = $attrs['globeSettings']['advanced']['connectionStyle']['desktop']['value'] ?? 'dashed';
		$animation_mode   = $attrs['globeSettings']['advanced']['animationMode']['desktop']['value'] ?? 'continuous';
		$marker_size      = $attrs['globeSettings']['advanced']['markerSize']['desktop']['value'] ?? '0.06';

		// Default marker image
		$default_marker_src = $attrs['defaultMarkerImage']['innerContent']['desktop']['value']['src'] ?? '';

		// Extract interaction settings
		$auto_rotate       = $attrs['globeInteraction']['advanced']['autoRotate']['desktop']['value'] ?? 'on';
		$auto_rotate_speed = $attrs['globeInteraction']['advanced']['autoRotateSpeed']['desktop']['value'] ?? '0.3';
		$enable_zoom       = $attrs['globeInteraction']['advanced']['enableZoom']['desktop']['value'] ?? 'on';
		$tour_interval     = $attrs['globeInteraction']['advanced']['tourInterval']['desktop']['value'] ?? '3000';

		// Extract features
		$show_arcs      = $attrs['globeFeatures']['advanced']['showArcs']['desktop']['value'] ?? 'on';
		$show_pulse     = $attrs['globeFeatures']['advanced']['showPulse']['desktop']['value'] ?? 'on';
		$show_heatmap   = $attrs['globeFeatures']['advanced']['showHeatmap']['desktop']['value'] ?? 'off';
		$show_day_night = $attrs['globeFeatures']['advanced']['showDayNight']['desktop']['value'] ?? 'off';
		$show_dots      = $attrs['globeFeatures']['advanced']['showDots']['desktop']['value'] ?? 'off';

		// Extract colors
		$pin_color     = $attrs['globeColors']['advanced']['pinColor']['desktop']['value'] ?? '#f97316';
		$arc_color     = $attrs['globeColors']['advanced']['arcColor']['desktop']['value'] ?? '#3b82f6';
		$arc_color_end = $attrs['globeColors']['advanced']['arcColorEnd']['desktop']['value'] ?? '#f97316';
		$dot_color     = $attrs['globeColors']['advanced']['dotColor']['desktop']['value'] ?? '#4a90d9';

		// Height & Position
		$height         = $attrs['globeHeight']['advanced']['height']['desktop']['value'] ?? '500px';
		$globe_position = $attrs['globePosition']['advanced']['position']['desktop']['value'] ?? 'center';

		// Initial view — resolve "Starting Region" preset to lat/lng, or use custom
		// values. Keep these presets in sync with REGION_PRESETS in edit.tsx.
		$initial_region = $attrs['initialView']['advanced']['region']['desktop']['value'] ?? 'asia';
		$region_presets = array(
			'asia'     => array( 35.6762, 139.6503 ),   // Tokyo
			'europe'   => array( 51.5074, -0.1278 ),    // London
			'americas' => array( 40.7128, -74.006 ),    // New York
			'africa'   => array( -1.2921, 36.8219 ),    // Nairobi
			'oceania'  => array( -33.8688, 151.2093 ),  // Sydney
		);
		if ( isset( $region_presets[ $initial_region ] ) ) {
			list( $initial_lat, $initial_lng ) = $region_presets[ $initial_region ];
		} else {
			$initial_lat = (float) ( $attrs['initialView']['advanced']['lat']['desktop']['value'] ?? 35.6762 );
			$initial_lng = (float) ( $attrs['initialView']['advanced']['lng']['desktop']['value'] ?? 139.6503 );
		}

		// Data source
		$data_source = $attrs['dataSource']['innerContent']['desktop']['value'] ?? 'manual';
		$markers     = array();

		if ( 'json' === $data_source ) {
			// JSON import mode
			$json_raw = $attrs['jsonData']['innerContent']['desktop']['value'] ?? '';
			if ( ! empty( $json_raw ) ) {
				$parsed = json_decode( $json_raw, true );
				if ( is_array( $parsed ) ) {
					foreach ( $parsed as $item ) {
						$marker_data = array(
							'lat'   => (float) ( $item['lat'] ?? 0 ),
							'lng'   => (float) ( $item['lng'] ?? 0 ),
							'label' => sanitize_text_field( $item['label'] ?? '' ),
							'value' => (float) ( $item['value'] ?? 0.8 ),
						);
						if ( ! empty( $item['color'] ) ) {
							$marker_data['color'] = sanitize_hex_color( $item['color'] ) ?: $item['color'];
						}
						if ( ! empty( $item['src'] ) ) {
							$marker_data['src'] = esc_url( $item['src'] );
						}
						$markers[] = $marker_data;
					}
				}
			}
		} else {
			// Manual mode - build markers from child innerBlocks
			if ( ! empty( $block->parsed_block['innerBlocks'] ) ) {
				foreach ( $block->parsed_block['innerBlocks'] as $inner_block ) {
					$child_attrs = $inner_block['attrs'] ?? [];
					$lat   = $child_attrs['marker']['advanced']['lat']['desktop']['value'] ?? '0';
					$lng   = $child_attrs['marker']['advanced']['lng']['desktop']['value'] ?? '0';
					$label = $child_attrs['marker']['advanced']['label']['desktop']['value'] ?? '';
					$value = $child_attrs['marker']['advanced']['value']['desktop']['value'] ?? '0.8';
					$color = $child_attrs['marker']['advanced']['color']['desktop']['value'] ?? '';
					$src   = $child_attrs['markerImage']['innerContent']['desktop']['value']['src'] ?? '';

					$marker_data = array(
						'lat'   => (float) $lat,
						'lng'   => (float) $lng,
						'label' => $label,
						'value' => (float) $value,
					);

					if ( ! empty( $color ) ) {
						$marker_data['color'] = $color;
					}
					if ( ! empty( $src ) ) {
						$marker_data['src'] = $src;
					}

					$markers[] = $marker_data;
				}
			}
		}

		// Fall back to defaults if no markers from either source
		if ( empty( $markers ) ) {
			$markers = array(
				array( 'lat' => 40.7128, 'lng' => -74.006, 'label' => 'New York', 'value' => 0.9 ),
				array( 'lat' => 51.5074, 'lng' => -0.1278, 'label' => 'London', 'value' => 0.85 ),
				array( 'lat' => 35.6762, 'lng' => 139.6503, 'label' => 'Tokyo', 'value' => 0.95 ),
				array( 'lat' => -33.8688, 'lng' => 151.2093, 'label' => 'Sydney', 'value' => 0.7 ),
				array( 'lat' => 48.8566, 'lng' => 2.3522, 'label' => 'Paris', 'value' => 0.8 ),
				array( 'lat' => 28.6139, 'lng' => 77.209, 'label' => 'New Delhi', 'value' => 0.75 ),
			);
		}

		$markers_json = wp_json_encode( $markers );

		// Build globe container with position wrapper
		$position_class = 'globe-position-' . esc_attr( $globe_position );
		$globe_html     = sprintf(
			'<div class="globe-wrapper %s"><div class="globe-container" data-globe data-theme="%s" data-marker-style="%s" data-connection-style="%s" data-animation-mode="%s" data-auto-rotate="%s" data-auto-rotate-speed="%s" data-enable-zoom="%s" data-tour-interval="%s" data-show-arcs="%s" data-show-pulse="%s" data-show-heatmap="%s" data-show-day-night="%s" data-show-dots="%s" data-pin-color="%s" data-arc-color="%s" data-arc-color-end="%s" data-dot-color="%s" data-marker-size="%s" data-default-marker-src="%s" data-initial-lat="%s" data-initial-lng="%s" data-markers=\'%s\' style="height:%s;"></div></div>',
			$position_class,
			esc_attr( $theme ),
			esc_attr( $marker_style ),
			esc_attr( $connection_style ),
			esc_attr( $animation_mode ),
			esc_attr( $auto_rotate === 'on' ? 'true' : 'false' ),
			esc_attr( $auto_rotate_speed ),
			esc_attr( $enable_zoom === 'on' ? 'true' : 'false' ),
			esc_attr( $tour_interval ),
			esc_attr( $show_arcs === 'on' ? 'true' : 'false' ),
			esc_attr( $show_pulse === 'on' ? 'true' : 'false' ),
			esc_attr( $show_heatmap === 'on' ? 'true' : 'false' ),
			esc_attr( $show_day_night === 'on' ? 'true' : 'false' ),
			esc_attr( $show_dots === 'on' ? 'true' : 'false' ),
			esc_attr( $pin_color ),
			esc_attr( $arc_color ),
			esc_attr( $arc_color_end ),
			esc_attr( $dot_color ),
			esc_attr( $marker_size ),
			esc_attr( $default_marker_src ),
			esc_attr( (string) $initial_lat ),
			esc_attr( (string) $initial_lng ),
			esc_attr( $markers_json ),
			esc_attr( $height )
		);

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'className'           => 'dnxte-globe-3d-map',
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $globe_html . $content,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
