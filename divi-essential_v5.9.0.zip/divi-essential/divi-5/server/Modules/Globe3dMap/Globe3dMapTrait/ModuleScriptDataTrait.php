<?php
/**
 * Module: Globe3dMap - Module Script Data Trait.
 *
 * @package DNXTE\Modules\Globe3dMap
 * @since ??
 */

namespace DNXTE\Modules\Globe3dMap\Globe3dMapTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

trait ModuleScriptDataTrait {

	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setStyle'      => [
					[
						'selector' => $selector . ' .globe-container',
						'data'     => array(
							'height' => $attrs['globeHeight']['advanced']['height'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? '500px';
						},
					],
				],
				'storeInstance' => $store_instance,
			]
		);

		wp_enqueue_script( 'dnxte_three_js' );
		wp_enqueue_script( 'dnxte_orbit_controls' );
		wp_enqueue_script( 'dnxte_globe3d' );
		wp_enqueue_style( 'dnxte_globe3d_css' );

		// Point Globe3D at the plugin's local texture folder. wp_localize_script prints the
		// window.dnxteGlobe3D variable inline BEFORE the dnxte_globe3d script tag, so the
		// textures base URL is resolved when the globe's IIFE runs.
		wp_localize_script(
			'dnxte_globe3d',
			'dnxteGlobe3D',
			array(
				'texturesBase' => DIVI_ESSENTIAL_ASSETS . 'images/globe/',
			)
		);
	}
}
