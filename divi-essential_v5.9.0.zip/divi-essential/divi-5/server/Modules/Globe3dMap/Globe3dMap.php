<?php
/**
 * Module: 3D Globe Map Module class.
 *
 * @package DNXTE\Modules\Globe3dMap
 * @since ??
 */

namespace DNXTE\Modules\Globe3dMap;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\Globe3dMap\Globe3dMapTrait;

class Globe3dMap implements DependencyInterface {
	use Globe3dMapTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'Globe3dMap/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ Globe3dMap::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
