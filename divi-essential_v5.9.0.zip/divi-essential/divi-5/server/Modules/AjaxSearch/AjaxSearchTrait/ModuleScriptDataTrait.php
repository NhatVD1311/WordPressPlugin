<?php
namespace DNXTE\Modules\AjaxSearch\AjaxSearchTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

trait ModuleScriptDataTrait {
	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set( [
			'id'            => $id,
			'selector'      => $selector,
			'attrs'         => array_merge(
				$module_decoration_attrs,
				[ 'link' => $args['attrs']['module']['advanced']['link'] ?? [] ]
			),
			'storeInstance' => $store_instance,
		] );

		wp_register_style(
			'dnxte-ajax-search',
			DIVI_ESSENTIAL_URL . 'divi-5/assets/css/ajax-search.css',
			array(),
			DIVI_ESSENTIAL_VERSION
		);
		wp_enqueue_style( 'dnxte-ajax-search' );

		wp_register_script(
			'dnxte-ajax-search',
			DIVI_ESSENTIAL_URL . 'divi-5/assets/js/ajax-search.js',
			array(),
			DIVI_ESSENTIAL_VERSION,
			true
		);

		wp_localize_script( 'dnxte-ajax-search', 'dnxteAjaxSearch', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'dnxte_ajax_search' ),
		] );

		wp_enqueue_script( 'dnxte-ajax-search' );
	}
}
