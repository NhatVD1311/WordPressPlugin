<?php
namespace DNXTE\Modules\AjaxSearch\AjaxSearchTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\AjaxSearch\AjaxSearch;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Search Config
		$sc = $attrs['searchConfig']['innerContent']['desktop']['value'] ?? [];
		$skin            = $sc['skin']           ?? 'dropdown';
		if ( 'slidein' === $skin ) $skin = 'dropdown'; // slidein removed, fallback.
		$placeholder     = $sc['placeholder']    ?? 'Search products, articles...';
		$min_chars       = $sc['minChars']       ?? '3';
		$results_per_page = $sc['resultsPerPage'] ?? '5';
		$order_by        = $sc['orderBy']        ?? 'date';

		// Display Config
		$dc = $attrs['displayConfig']['innerContent']['desktop']['value'] ?? [];
		$show_search_icon  = $dc['showSearchIcon']  ?? 'on';
		$show_clear        = $dc['showClear']       ?? 'on';
		$show_loader       = $dc['showLoader']      ?? 'on';
		$result_layout     = $dc['resultLayout']    ?? 'list';
		$image_position    = $dc['imagePosition']   ?? 'left';
		$excerpt_length    = $dc['excerptLength']   ?? '100';
		$no_results_msg    = $dc['noResultsMsg']    ?? 'No results found. Try a different search.';
		$pagination_style  = $dc['paginationStyle'] ?? 'loadmore';
		$loader_style      = $dc['loaderStyle']     ?? 'spinner';
		$show_results_count = $dc['showResultsCount'] ?? 'on';
		$show_see_all      = $dc['showSeeAll']      ?? 'on';

		// Smart Search
		$ss = $attrs['smartSearch']['innerContent']['desktop']['value'] ?? [];
		$voice_search      = $ss['voiceSearch']      ?? 'on';
		$show_suggested    = $ss['showSuggested']    ?? 'on';
		$show_recent       = $ss['showRecent']       ?? 'on';
		$auto_correct      = $ss['autoCorrect']      ?? 'off';
		$category_filter   = $ss['categoryFilter']   ?? 'on';

		// Categories & Suggested Searches (from checkboxes attributes)
		$categories_raw    = $attrs['searchCategories']['advanced']['categories']['desktop']['value'] ?? [];
		if ( empty( $categories_raw ) ) {
			$categories_raw = [ 'all', 'products', 'articles', 'pages' ];
		}
		$suggested_raw     = $attrs['searchSuggestions']['advanced']['suggestions']['desktop']['value'] ?? [];
		if ( empty( $suggested_raw ) ) {
			$suggested_raw = [ 'new_arrivals', 'best_sellers', 'on_sale' ];
		}

		// Map checkbox values to display labels.
		$category_label_map = [
			'all'       => 'All',
			'products'  => 'Products',
			'articles'  => 'Articles',
			'pages'     => 'Pages',
		];
		$suggested_label_map = [
			'new_arrivals'  => 'New Arrivals',
			'best_sellers'  => 'Best Sellers',
			'on_sale'       => 'On Sale',
			'tutorials'     => 'Tutorials',
			'documentation' => 'Documentation',
		];

		// WooCommerce Config
		$wc = $attrs['wooConfig']['innerContent']['desktop']['value'] ?? [];
		// Excluded products: stored as array from the divi/select multiselect.
		$exclude_product_ids_arr = $attrs['excludeProducts']['advanced']['productIds']['desktop']['value'] ?? [];
		$exclude_product_ids_raw = is_array( $exclude_product_ids_arr )
			? wp_json_encode( array_map( 'absint', $exclude_product_ids_arr ) )
			: '[]';

		// Excluded posts: stored as array from the divi/checkboxes multiselect.
		$exclude_post_ids_arr = $attrs['excludePosts']['advanced']['postIds']['desktop']['value'] ?? [];
		$exclude_post_ids_raw = is_array( $exclude_post_ids_arr )
			? wp_json_encode( array_map( 'absint', $exclude_post_ids_arr ) )
			: '[]';

		// Included pages: stored as array from the divi/checkboxes multiselect.
		// Empty means all pages are searchable.
		$include_page_ids_arr = $attrs['includePages']['advanced']['pageIds']['desktop']['value'] ?? [];
		$include_page_ids_raw = is_array( $include_page_ids_arr )
			? wp_json_encode( array_map( 'absint', $include_page_ids_arr ) )
			: '[]';

		// Design: Results Container
		$results_animation = $attrs['resultsContainerDesign']['advanced']['resultsAnimation']['desktop']['value'] ?? 'fadeIn';

		// Design: Result Items
		$hover_transform = $attrs['resultItemsDesign']['advanced']['hoverTransform']['desktop']['value'] ?? 'none';

		// Parse checkbox values (may be array or pipe-separated string) and map to labels.
		$cat_slugs = is_array( $categories_raw )
			? $categories_raw
			: array_filter( array_map( 'trim', explode( '|', $categories_raw ) ) );
		$categories = array_map( function ( $slug ) use ( $category_label_map ) {
			return $category_label_map[ $slug ] ?? ucfirst( $slug );
		}, $cat_slugs );

		$sug_slugs = is_array( $suggested_raw )
			? $suggested_raw
			: array_filter( array_map( 'trim', explode( '|', $suggested_raw ) ) );
		$suggested = array_map( function ( $slug ) use ( $suggested_label_map ) {
			return $suggested_label_map[ $slug ] ?? ucfirst( str_replace( '_', ' ', $slug ) );
		}, $sug_slugs );
		$default_cat = ! empty( $categories ) ? $categories[0] : 'All';

		// Category dropdown with selectable list
		$category_html = '';
		if ( 'on' === $category_filter ) {
			$cat_items = '';
			foreach ( $categories as $cat ) {
				$active_class = ( $cat === $default_cat ) ? ' is-active' : '';
				$cat_items .= HTMLUtility::render( [
					'tag'               => 'div',
					'attributes'        => [
						'class'          => 'ajax_search__category-item' . $active_class,
						'data-category'  => esc_attr( $cat ),
					],
					'childrenSanitizer' => 'esc_html',
					'children'          => $cat,
				] );
			}
			$cat_list = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'ajax_search__category-list', 'style' => 'display:none' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $cat_items,
			] );

			$category_html = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'ajax_search__category-dropdown' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>
					HTMLUtility::render( [
						'tag'               => 'span',
						'attributes'        => [ 'class' => 'ajax_search__category-label' ],
						'childrenSanitizer' => 'esc_html',
						'children'          => $default_cat,
					] )
					. '<svg class="ajax_search__category-chevron" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
					. $cat_list,
			] ) . '<div class="ajax_search__category-divider"></div>';
		}

		// Search icon
		$search_icon = '';
		if ( 'on' === $show_search_icon ) {
			$search_icon = '<svg class="ajax_search__search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 21L16.65 16.65M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 6.58172 3 11 3C15.4183 3 19 6.58172 19 11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
		}

		// Input. Placeholder text supports shortcodes; strip any markup they emit since this is an attribute value.
		$input = sprintf(
			'<input type="search" class="ajax_search__input" placeholder="%s" />',
			esc_attr( wp_strip_all_tags( do_shortcode( $placeholder ), true ) )
		);

		// Clear button
		$clear_btn = '';
		if ( 'on' === $show_clear ) {
			$clear_btn = '<button class="ajax_search__clear-btn" type="button" aria-label="Clear search"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
		}

		// Voice button
		$voice_btn = '';
		if ( 'on' === $voice_search ) {
			$voice_btn = '<button class="ajax_search__voice-btn" type="button" aria-label="Voice search"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 1C10.34 1 9 2.34 9 4V12C9 13.66 10.34 15 12 15C13.66 15 15 13.66 15 12V4C15 2.34 13.66 1 12 1Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M19 10V12C19 15.866 15.866 19 12 19C8.13401 19 5 15.866 5 12V10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 19V23M8 23H16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
		}

		// Search bar
		$search_bar = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'ajax_search__search-bar' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => $category_html . $search_icon . $input . $clear_btn . $voice_btn,
		] );

		// Suggested searches section
		$suggested_html = '';
		if ( 'on' === $show_suggested && ! empty( $suggested ) ) {
			$tags_html = '';
			foreach ( $suggested as $tag ) {
				$tags_html .= HTMLUtility::render( [
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'ajax_search__tag' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => $tag,
				] );
			}
			$suggested_html = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'ajax_search__suggested-section' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>
					'<span class="ajax_search__section-label">SUGGESTED SEARCHES</span>'
					. HTMLUtility::render( [
						'tag'               => 'div',
						'attributes'        => [ 'class' => 'ajax_search__tags-wrapper' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $tags_html,
					] ),
			] );
		}

		// Recent searches section (empty list - populated by JS from localStorage)
		$recent_html = '';
		if ( 'on' === $show_recent ) {
			$recent_html = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'ajax_search__recent-section', 'style' => 'display:none' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>
					'<span class="ajax_search__section-label">RECENT SEARCHES</span>'
					. HTMLUtility::render( [
						'tag'               => 'div',
						'attributes'        => [ 'class' => 'ajax_search__recent-list' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => '',
					] ),
			] );
		}

		// Results count (hidden by default)
		$results_count_html = '';
		if ( 'on' === $show_results_count ) {
			$results_count_html = '<div class="ajax_search__results-count" style="display:none"></div>';
		}

		// Results wrapper (populated by JS via AJAX)
		$results_wrapper = '<div class="ajax_search__results-wrapper" style="display:none"></div>';

		// See All link (hidden by default)
		$see_all_html = '';
		if ( 'on' === $show_see_all ) {
			$see_all_html = '<a class="ajax_search__see-all" style="display:none" href="#">See all results</a>';
		}

		// Autocorrect suggestion (hidden by default)
		$autocorrect_html = '';
		if ( 'on' === $auto_correct ) {
			$autocorrect_html = '<div class="ajax_search__autocorrect" style="display:none"></div>';
		}

		// Pagination (hidden by default)
		$pagination_html = '';
		if ( 'none' !== $pagination_style ) {
			$pagination_html = '<div class="ajax_search__pagination" style="display:none"></div>';
		}

		// Loader (hidden by default)
		$loader_html = '';
		if ( 'on' === $show_loader ) {
			$loader_class = 'ajax_search__loader ajax_search__loader--' . esc_attr( $loader_style );
			$loader_html  = '<div class="' . $loader_class . '" style="display:none"><span class="ajax_search__loader-spinner"></span></div>';
		}

		// No results message (hidden by default)
		$no_results_html = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class' => 'ajax_search__no-results',
				'style' => 'display:none',
			],
			'childrenSanitizer' => 'esc_html',
			'children'          => $no_results_msg,
		] );

		// Dropdown panel
		$dropdown_panel = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class'          => 'ajax_search__dropdown-panel',
				'data-animation' => esc_attr( $results_animation ),
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => $suggested_html . $recent_html . $results_count_html . $results_wrapper . $autocorrect_html . $see_all_html . $pagination_html . $loader_html . $no_results_html,
		] );

		// Overlay (for modal skin)
		$overlay_html = '';
		if ( 'modal' === $skin ) {
			$overlay_html = '<div class="ajax_search__overlay" style="display:none"></div>';
		}

		// Title
		$title_html = $elements->render( [ 'attrName' => 'title' ] );

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Build post types list from settings.
		$post_types = [];
		if ( 'on' === ( $sc['searchPosts'] ?? 'on' ) )    $post_types[] = 'post';
		if ( 'on' === ( $sc['searchPages'] ?? 'on' ) )    $post_types[] = 'page';
		if ( 'on' === ( $sc['searchProducts'] ?? 'off' ) ) $post_types[] = 'product';
		if ( 'on' === ( $sc['searchProjects'] ?? 'off' ) ) $post_types[] = 'project';

		// If category filter is on, only show categories whose post type is enabled.
		if ( 'on' === $category_filter ) {
			$cat_to_post_type = [
				'Products' => 'product',
				'Articles' => 'post',
				'Pages'    => 'page',
			];
			$categories = array_filter( $categories, function ( $cat ) use ( $cat_to_post_type, $post_types ) {
				if ( 'All' === $cat ) return true;
				if ( ! isset( $cat_to_post_type[ $cat ] ) ) return true;
				return in_array( $cat_to_post_type[ $cat ], $post_types, true );
			} );
			$categories = array_values( $categories );
		}

		if ( empty( $post_types ) ) $post_types[] = 'post';

		$inner_class = 'ajax_search__inner ajax_search__skin--' . esc_attr( $skin )
			. ' ajax_search__layout--' . esc_attr( $result_layout )
			. ' ajax_search__imgpos--' . esc_attr( $image_position );

		$inner_attrs = [
			'class'                => $inner_class,
			'data-hover'           => esc_attr( $hover_transform ),
			'data-post-types'      => esc_attr( implode( ',', $post_types ) ),
			'data-min-chars'       => esc_attr( $min_chars ),
			'data-per-page'        => esc_attr( $results_per_page ),
			'data-order-by'        => esc_attr( $order_by ),
			'data-excerpt-length'  => esc_attr( $excerpt_length ),
			'data-image-position'  => esc_attr( $image_position ),
			'data-pagination'      => esc_attr( $pagination_style ),
			'data-loader-style'    => esc_attr( $loader_style ),
			'data-auto-correct'    => esc_attr( $auto_correct ),
			'data-show-image'      => esc_attr( $dc['showImage'] ?? 'on' ),
			'data-show-title'      => esc_attr( $dc['showTitle'] ?? 'on' ),
			'data-show-excerpt'    => esc_attr( $dc['showExcerpt'] ?? 'on' ),
			'data-show-category'   => esc_attr( $dc['showCategory'] ?? 'on' ),
			'data-show-date'       => esc_attr( $dc['showDate'] ?? 'off' ),
			'data-show-author'     => esc_attr( $dc['showAuthor'] ?? 'off' ),
			'data-show-count'      => esc_attr( $show_results_count ),
			'data-show-see-all'    => esc_attr( $show_see_all ),
			'data-show-price'      => esc_attr( $wc['showPrice'] ?? 'on' ),
			'data-show-rating'     => esc_attr( $wc['showRating'] ?? 'on' ),
			'data-show-sale-badge' => esc_attr( $wc['showSaleBadge'] ?? 'on' ),
			'data-show-add-to-cart' => esc_attr( $wc['showAddToCart'] ?? 'off' ),
			'data-search-title'    => esc_attr( $sc['searchTitle'] ?? 'on' ),
			'data-search-content'  => esc_attr( $sc['searchContent'] ?? 'on' ),
			'data-search-excerpt'  => esc_attr( $sc['searchExcerpt'] ?? 'on' ),
			'data-search-categories' => esc_attr( $sc['searchCategories'] ?? 'off' ),
			'data-search-tags'     => esc_attr( $sc['searchTags'] ?? 'off' ),
			'data-search-sku'      => esc_attr( $sc['searchSku'] ?? 'off' ),
			'data-search-meta'     => esc_attr( $sc['searchMeta'] ?? 'off' ),
			'data-exclude-product-ids' => esc_attr( $exclude_product_ids_raw ),
			'data-exclude-post-ids' => esc_attr( $exclude_post_ids_raw ),
			'data-include-page-ids' => esc_attr( $include_page_ids_raw ),
		];

		return Module::render( [
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AjaxSearch::class, 'module_classnames' ],
			'stylesComponent'     => [ AjaxSearch::class, 'module_styles' ],
			'scriptDataComponent' => [ AjaxSearch::class, 'module_script_data' ],
			'parentAttrs'         => $parent_attrs,
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => [
				ElementComponents::component( [
					'attrs'         => $attrs['module']['decoration'] ?? [],
					'id'            => $block->parsed_block['id'],
					'orderIndex'    => $block->parsed_block['orderIndex'],
					'storeInstance' => $block->parsed_block['storeInstance'],
				] ),
				$title_html,
				HTMLUtility::render( [
					'tag'               => 'div',
					'attributes'        => $inner_attrs,
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $overlay_html . $search_bar . $dropdown_panel,
				] ),
			],
		] );
	}
}
