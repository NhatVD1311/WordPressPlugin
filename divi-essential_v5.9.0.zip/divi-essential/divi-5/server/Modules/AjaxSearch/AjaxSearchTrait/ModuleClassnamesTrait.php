<?php
namespace DNXTE\Modules\AjaxSearch\AjaxSearchTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait ModuleClassnamesTrait {
	public static function module_classnames( $args ) {
	}
}
