<?php
namespace DNXTE\Modules\AjaxSearch\AjaxSearchTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DNXTE\Modules\AjaxSearch\AjaxSearch;

trait ModuleStylesTrait {
	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];
		$order_class = $args['orderClass'];

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => [
				// Module
				$elements->style( [
					'attrName'   => 'module',
					'styleProps' => [
						'disabledOn' => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				] ),

				// Title
				$elements->style( [ 'attrName' => 'title' ] ),

				// === Search Input Design ===
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-bar",
					'attr'     => $attrs['searchInputDesign']['advanced']['inputBg'] ?? [],
					'property' => 'background-color',
				] ),
				CommonStyle::style( [
					'selector'  => "$order_class .ajax_search__search-bar input.ajax_search__input",
					'attr'      => $attrs['searchInputDesign']['advanced']['inputTextColor'] ?? [],
					'property'  => 'color',
					'important' => true,
				] ),
				CommonStyle::style( [
					'selector'  => "$order_class .ajax_search__search-bar input.ajax_search__input::placeholder",
					'attr'      => $attrs['searchInputDesign']['advanced']['placeholderColor'] ?? [],
					'property'  => 'color',
					'important' => true,
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-bar",
					'attr'     => $attrs['searchInputDesign']['advanced']['inputBorderColor'] ?? [],
					'property' => 'border-color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-bar",
					'attr'     => $attrs['searchInputDesign']['advanced']['inputBorderRadius'] ?? [],
					'property' => 'border-radius',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-bar",
					'attr'     => $attrs['searchInputDesign']['advanced']['inputHeight'] ?? [],
					'property' => 'min-height',
					'important' => true,
				] ),
				CommonStyle::style( [
					'selector'  => "$order_class .ajax_search__search-bar input.ajax_search__input",
					'attr'      => $attrs['searchInputDesign']['advanced']['inputFontSize'] ?? [],
					'property'  => 'font-size',
					'important' => true,
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-icon",
					'attr'     => $attrs['searchInputDesign']['advanced']['iconColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__search-bar",
					'attr'     => $attrs['searchInputDesign']['advanced']['focusRingColor'] ?? [],
					'property' => '--ajax-focus-color',
				] ),

				// === Results Container Design ===
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__dropdown-panel",
					'attr'     => $attrs['resultsContainerDesign']['advanced']['resultsBg'] ?? [],
					'property' => 'background-color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__dropdown-panel",
					'attr'     => $attrs['resultsContainerDesign']['advanced']['resultsBorderRadius'] ?? [],
					'property' => '--ajax-results-radius',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__dropdown-panel",
					'attr'     => $attrs['resultsContainerDesign']['advanced']['resultsShadow'] ?? [],
					'property' => '--ajax-shadow-depth',
				] ),

				// === Result Items Design ===
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__result-item",
					'attr'     => $attrs['resultItemsDesign']['advanced']['itemBg'] ?? [],
					'property' => 'background-color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__recent-item, $order_class .ajax_search__result-item",
					'attr'     => $attrs['resultItemsDesign']['advanced']['itemHoverBg'] ?? [],
					'property' => '--ajax-item-hover-bg',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__recent-text, $order_class .ajax_search__result-title",
					'attr'     => $attrs['resultItemsDesign']['advanced']['titleColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__recent-text, $order_class .ajax_search__result-title",
					'attr'     => $attrs['resultItemsDesign']['advanced']['titleSize'] ?? [],
					'property' => 'font-size',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__result-excerpt",
					'attr'     => $attrs['resultItemsDesign']['advanced']['excerptColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__result-price",
					'attr'     => $attrs['resultItemsDesign']['advanced']['priceColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__tag, $order_class .ajax_search__result-badge",
					'attr'     => $attrs['resultItemsDesign']['advanced']['catBadgeBg'] ?? [],
					'property' => 'background-color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__tag, $order_class .ajax_search__result-badge",
					'attr'     => $attrs['resultItemsDesign']['advanced']['catBadgeColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__result-image img",
					'attr'     => $attrs['resultItemsDesign']['advanced']['imageRadius'] ?? [],
					'property' => 'border-radius',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__recent-item, $order_class .ajax_search__result-item",
					'attr'     => $attrs['resultItemsDesign']['advanced']['itemPadding'] ?? [],
					'property' => 'padding',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__recent-list, $order_class .ajax_search__results-wrapper",
					'attr'     => $attrs['resultItemsDesign']['advanced']['itemGap'] ?? [],
					'property' => 'gap',
				] ),

				// === Pagination Button Design ===
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__load-more, $order_class .ajax_search__prev-btn, $order_class .ajax_search__next-btn",
					'attr'     => $attrs['paginationDesign']['advanced']['btnBg'] ?? [],
					'property' => '--ajax-btn-bg',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__load-more, $order_class .ajax_search__prev-btn, $order_class .ajax_search__next-btn",
					'attr'     => $attrs['paginationDesign']['advanced']['btnColor'] ?? [],
					'property' => 'color',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__pagination",
					'attr'     => $attrs['paginationDesign']['advanced']['btnHoverBg'] ?? [],
					'property' => '--ajax-btn-hover-bg',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__load-more, $order_class .ajax_search__prev-btn, $order_class .ajax_search__next-btn",
					'attr'     => $attrs['paginationDesign']['advanced']['btnBorderColor'] ?? [],
					'property' => '--ajax-btn-border',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__load-more, $order_class .ajax_search__prev-btn, $order_class .ajax_search__next-btn",
					'attr'     => $attrs['paginationDesign']['advanced']['btnRadius'] ?? [],
					'property' => '--ajax-btn-radius',
				] ),
				CommonStyle::style( [
					'selector' => "$order_class .ajax_search__load-more, $order_class .ajax_search__prev-btn, $order_class .ajax_search__next-btn",
					'attr'     => $attrs['paginationDesign']['advanced']['btnFontSize'] ?? [],
					'property' => '--ajax-btn-size',
				] ),

				// Custom CSS (always at the bottom)
				CssStyle::style( [
					'selector'  => $args['orderClass'],
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => AjaxSearch::custom_css(),
				] ),
			],
		] );
	}
}
