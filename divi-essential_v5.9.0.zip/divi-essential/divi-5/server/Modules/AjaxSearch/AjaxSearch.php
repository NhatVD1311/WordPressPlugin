<?php
namespace DNXTE\Modules\AjaxSearch;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class AjaxSearch implements DependencyInterface {
	use AjaxSearchTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'AjaxSearch/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ AjaxSearch::class, 'render_callback' ],
					]
				);
			}
		);

		add_action( 'wp_ajax_dnxte_ajax_search', [ AjaxSearch::class, 'handle_search' ] );
		add_action( 'wp_ajax_nopriv_dnxte_ajax_search', [ AjaxSearch::class, 'handle_search' ] );
		add_action( 'wp_ajax_dnxte_get_woo_products', [ AjaxSearch::class, 'handle_get_products' ] );

		// Dynamically inject WooCommerce product options into the excludeProducts multiselect.
		add_filter( 'block_type_metadata', [ AjaxSearch::class, 'inject_product_options' ] );

		// Dynamically inject post options (all public post types except products) into the excludePosts multiselect.
		add_filter( 'block_type_metadata', [ AjaxSearch::class, 'inject_post_options' ] );

		// Dynamically inject page options into the includePages multiselect.
		add_filter( 'block_type_metadata', [ AjaxSearch::class, 'inject_page_options' ] );
	}

	/**
	 * Injects published posts from all public post types (excluding WooCommerce
	 * products and attachments) as options into the excludePosts divi/checkboxes
	 * field via the block_type_metadata filter.
	 *
	 * @param array $metadata Full module metadata array.
	 * @return array
	 */
	public static function inject_post_options( array $metadata ): array {
		if ( ( $metadata['name'] ?? '' ) !== 'dnxte/ajax-search' ) {
			return $metadata;
		}

		// Walk the metadata attrs tree and inject options.
		if ( isset( $metadata['attributes']['excludePosts']['settings']['advanced']['postIds']['item']['component']['props'] ) ) {
			$metadata['attributes']['excludePosts']['settings']['advanced']['postIds']['item']['component']['props']['options'] = self::get_post_options();
		}

		return $metadata;
	}

	/**
	 * Builds the list of post options (value/label pairs) for the excludePosts
	 * field, covering all public post types except products and attachments.
	 * Cached for 5 minutes. Shared by the block metadata injector and the
	 * visual-builder inline-script localization.
	 *
	 * @return array
	 */
	public static function get_post_options(): array {
		$cache_key = 'dnxte_ajax_search_post_options';
		$options   = wp_cache_get( $cache_key, 'dnxte_ajax_search' );

		if ( false !== $options ) {
			return $options;
		}

		$post_types = get_post_types( [ 'public' => true ], 'names' );
		unset( $post_types['product'], $post_types['attachment'], $post_types['page'] );
		$post_types = array_values( $post_types );

		$options = [];

		if ( ! empty( $post_types ) ) {
			$posts = get_posts( [
				'post_type'        => $post_types,
				'post_status'      => 'publish',
				'posts_per_page'   => 200,
				'orderby'          => 'title',
				'order'            => 'ASC',
				'suppress_filters' => false,
			] );

			foreach ( $posts as $post ) {
				$type_obj   = get_post_type_object( $post->post_type );
				$type_label = $type_obj && isset( $type_obj->labels->singular_name )
					? $type_obj->labels->singular_name
					: $post->post_type;
				$options[]  = [
					'value' => (string) $post->ID,
					'label' => $post->post_title . ' (' . $type_label . ')',
				];
			}
		}

		wp_cache_set( $cache_key, $options, 'dnxte_ajax_search', 5 * MINUTE_IN_SECONDS );

		return $options;
	}

	/**
	 * Injects published pages as options into the includePages divi/checkboxes
	 * field via the block_type_metadata filter.
	 *
	 * @param array $metadata Full module metadata array.
	 * @return array
	 */
	public static function inject_page_options( array $metadata ): array {
		if ( ( $metadata['name'] ?? '' ) !== 'dnxte/ajax-search' ) {
			return $metadata;
		}

		if ( isset( $metadata['attributes']['includePages']['settings']['advanced']['pageIds']['item']['component']['props'] ) ) {
			$metadata['attributes']['includePages']['settings']['advanced']['pageIds']['item']['component']['props']['options'] = self::get_page_options();
		}

		return $metadata;
	}

	/**
	 * Builds the list of published-page options (value/label pairs) for the
	 * includePages field. Cached for 5 minutes. Shared by the block metadata
	 * injector and the visual-builder inline-script localization.
	 *
	 * @return array
	 */
	public static function get_page_options(): array {
		$cache_key = 'dnxte_ajax_search_page_options';
		$options   = wp_cache_get( $cache_key, 'dnxte_ajax_search' );

		if ( false !== $options ) {
			return $options;
		}

		$pages = get_posts( [
			'post_type'        => 'page',
			'post_status'      => 'publish',
			'posts_per_page'   => 200,
			'orderby'          => 'title',
			'order'            => 'ASC',
			'suppress_filters' => false,
		] );

		$options = [];
		foreach ( $pages as $page ) {
			$options[] = [
				'value' => (string) $page->ID,
				'label' => $page->post_title,
			];
		}

		wp_cache_set( $cache_key, $options, 'dnxte_ajax_search', 5 * MINUTE_IN_SECONDS );

		return $options;
	}

	/**
	 * Injects published WooCommerce products as options into the excludeProducts
	 * divi/select (multiple) field via the block_type_metadata filter.
	 *
	 * @param array $metadata Full module metadata array.
	 * @return array
	 */
	public static function inject_product_options( array $metadata ): array {
		if ( ( $metadata['name'] ?? '' ) !== 'dnxte/ajax-search' ) {
			return $metadata;
		}

		if ( ! function_exists( 'wc_get_products' ) ) {
			return $metadata;
		}

		$cache_key = 'dnxte_ajax_search_product_options';
		$options   = wp_cache_get( $cache_key, 'dnxte_ajax_search' );

		if ( false === $options ) {
			$products = wc_get_products( [
				'status'  => 'publish',
				'limit'   => 200,
				'orderby' => 'title',
				'order'   => 'ASC',
				'return'  => 'objects',
			] );

			$options = [];
			foreach ( $products as $product ) {
				$sku       = $product->get_sku();
				$label     = $product->get_name() . ( $sku ? ' (SKU: ' . $sku . ')' : '' );
				$options[] = [
					'value' => (string) $product->get_id(),
					'label' => $label,
				];
			}

			wp_cache_set( $cache_key, $options, 'dnxte_ajax_search', 5 * MINUTE_IN_SECONDS );
		}

		// Walk the metadata attrs tree and inject options.
		if ( isset( $metadata['attributes']['excludeProducts']['settings']['advanced']['productIds']['item']['component']['props'] ) ) {
			$metadata['attributes']['excludeProducts']['settings']['advanced']['productIds']['item']['component']['props']['options'] = $options;
		}

		return $metadata;
	}

	/**
	 * AJAX search handler.
	 */
	public static function handle_search() {
		check_ajax_referer( 'dnxte_ajax_search', 'nonce' );

		$query          = sanitize_text_field( wp_unslash( $_GET['q'] ?? '' ) );
		$post_types_str = sanitize_text_field( $_GET['post_types'] ?? 'post,page' );
		$per_page       = absint( $_GET['per_page'] ?? 5 );
		$page           = max( 1, absint( $_GET['page'] ?? 1 ) );
		$order_by       = sanitize_text_field( $_GET['order_by'] ?? 'date' );
		$excerpt_length = absint( $_GET['excerpt_length'] ?? 15 );
		$category       = sanitize_text_field( $_GET['category'] ?? '' );

		// Search field toggles.
		$search_title      = sanitize_text_field( wp_unslash( $_GET['search_title'] ?? 'on' ) ) === 'on';
		$search_content    = sanitize_text_field( wp_unslash( $_GET['search_content'] ?? 'on' ) ) === 'on';
		$search_excerpt    = sanitize_text_field( wp_unslash( $_GET['search_excerpt'] ?? 'on' ) ) === 'on';
		$search_categories = sanitize_text_field( wp_unslash( $_GET['search_categories'] ?? 'off' ) ) === 'on';
		$search_tags       = sanitize_text_field( wp_unslash( $_GET['search_tags'] ?? 'off' ) ) === 'on';
		$search_sku        = sanitize_text_field( wp_unslash( $_GET['search_sku'] ?? 'off' ) ) === 'on';
		$search_meta       = sanitize_text_field( wp_unslash( $_GET['search_meta'] ?? 'off' ) ) === 'on';
		$auto_correct      = sanitize_text_field( wp_unslash( $_GET['auto_correct'] ?? 'off' ) ) === 'on';

		// WooCommerce-specific filters.
		// Product IDs come as a JSON-encoded array from the divi/checkboxes component.
		$exclude_product_ids_raw = sanitize_text_field( wp_unslash( $_GET['exclude_product_ids'] ?? '' ) );
		$decoded                 = json_decode( $exclude_product_ids_raw, true );
		$exclude_product_ids     = is_array( $decoded )
			? array_filter( array_map( 'absint', $decoded ) )
			: array_filter( array_map( 'absint', explode( ',', $exclude_product_ids_raw ) ) );

		// Excluded post IDs come as a JSON-encoded array from the divi/checkboxes component.
		$exclude_post_ids_raw = sanitize_text_field( wp_unslash( $_GET['exclude_post_ids'] ?? '' ) );
		$decoded_posts        = json_decode( $exclude_post_ids_raw, true );
		$exclude_post_ids     = is_array( $decoded_posts )
			? array_filter( array_map( 'absint', $decoded_posts ) )
			: array_filter( array_map( 'absint', explode( ',', $exclude_post_ids_raw ) ) );

		// Included page IDs come as a JSON-encoded array from the divi/checkboxes component.
		// Empty means all pages are searchable.
		$include_page_ids_raw = sanitize_text_field( wp_unslash( $_GET['include_page_ids'] ?? '' ) );
		$decoded_pages        = json_decode( $include_page_ids_raw, true );
		$include_page_ids     = is_array( $decoded_pages )
			? array_filter( array_map( 'absint', $decoded_pages ) )
			: array_filter( array_map( 'absint', explode( ',', $include_page_ids_raw ) ) );

		if ( empty( $query ) ) {
			wp_send_json_success( [ 'results' => [], 'total' => 0, 'pages' => 0 ] );
		}

		// Word count for excerpt trimming (generous to avoid cutting short).
		$word_count = max( 5, intval( $excerpt_length / 5 ) );

		$post_types = array_filter( array_map( 'trim', explode( ',', $post_types_str ) ) );

		// The caller chooses which post types to search, and WP_Query does not filter by
		// visibility when post types are named explicitly — so without this guard an
		// anonymous request could search any non-public CPT that stores rows as
		// `publish` (WooCommerce coupon codes, form entries, licence CPTs, …).
		// Mirrors the guard already used by NextPostGrid and FilterableCpt.
		$post_types = array_values(
			array_filter(
				$post_types,
				static function ( $post_type ) {
					$post_type_object = get_post_type_object( $post_type );

					if ( ! $post_type_object ) {
						return false;
					}

					// Logged-in users may legitimately search private types they can
					// already see; anonymous callers are limited to public ones.
					if ( ! is_user_logged_in() ) {
						return ! empty( $post_type_object->public );
					}

					return true;
				}
			)
		);

		if ( empty( $post_types ) ) {
			wp_send_json_success( [ 'results' => [], 'total' => 0, 'pages' => 0 ] );
		}

		// Allow developers to override product ID exclusion via filter.
		$exclude_product_ids = apply_filters( 'dnxte_ajax_search_exclude_product_ids', $exclude_product_ids, $post_types );

		// Allow developers to override post ID exclusion via filter.
		$exclude_post_ids = apply_filters( 'dnxte_ajax_search_exclude_post_ids', $exclude_post_ids, $post_types );

		// Allow developers to override the page inclusion list via filter.
		$include_page_ids = apply_filters( 'dnxte_ajax_search_include_page_ids', $include_page_ids, $post_types );

		// Handle special suggested search tags.
		$special_tags = [
			'New Arrivals'  => [ 'orderby' => 'date', 'order' => 'DESC' ],
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- required for WooCommerce best sellers ordering.
			'Best Sellers'  => [ 'orderby' => 'meta_value_num', 'meta_key' => 'total_sales', 'order' => 'DESC' ],
			'On Sale'       => [ 'on_sale' => true ],
			'Tutorials'     => [ 's_query' => 'tutorial' ],
			'Documentation' => [ 's_query' => 'documentation' ],
		];

		$is_special = isset( $special_tags[ $query ] );

		// Map orderBy.
		$orderby_map = [
			'date'      => 'date',
			'title'     => 'title',
			'random'    => 'rand',
		];
		$orderby = $orderby_map[ $order_by ] ?? 'date';

		$order = 'title' === $orderby ? 'ASC' : 'DESC';

		$args = [
			'post_type'      => $post_types,
			'posts_per_page' => min( $per_page, 20 ),
			'paged'          => $page,
			'post_status'    => 'publish',
			'orderby'        => $orderby,
			'order'          => $order,
		];

		// Exclude specific products and posts by ID (from the multiselect fields).
		// Both feed a single post__not_in array, so they must be merged.
		$excluded_ids = array_values( array_unique( array_merge( $exclude_product_ids, $exclude_post_ids ) ) );
		if ( ! empty( $excluded_ids ) ) {
			$args['post__not_in'] = $excluded_ids;
		}

		// Restrict page results to the selected pages only. post__in can't be
		// used because it would also restrict the other post types, so the
		// condition is added as a WHERE clause that only touches pages.
		$include_pages_where = null;
		if ( ! empty( $include_page_ids ) ) {
			global $wpdb;
			$ids_sql             = implode( ',', array_map( 'absint', $include_page_ids ) );
			$include_pages_where = function ( $where ) use ( $wpdb, $ids_sql ) {
				return $where . " AND ({$wpdb->posts}.post_type <> 'page' OR {$wpdb->posts}.ID IN ($ids_sql))";
			};
			add_filter( 'posts_where', $include_pages_where, 10 );
		}

		// Category filter — maps dropdown labels to post types.
		if ( ! empty( $category ) && 'All' !== $category ) {
			$category_post_type_map = [
				'Products' => 'product',
				'Articles' => 'post',
				'Pages'    => 'page',
			];

			if ( isset( $category_post_type_map[ $category ] ) ) {
				$args['post_type'] = [ $category_post_type_map[ $category ] ];
			}
		}

		$search_where = null;

		// Seed native search; posts_search below narrows it to the enabled fields.
		$args['s'] = $query;

		// Handle special suggested search tags.
		if ( $is_special ) {
			$tag_config = $special_tags[ $query ];

			if ( ! empty( $tag_config['orderby'] ) ) {
				$args['orderby'] = $tag_config['orderby'];
			}
			if ( ! empty( $tag_config['order'] ) ) {
				$args['order'] = $tag_config['order'];
			}
			if ( ! empty( $tag_config['meta_key'] ) ) {
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- dynamic meta_key from special tag config.
				$args['meta_key'] = $tag_config['meta_key'];
			}
			if ( ! empty( $tag_config['on_sale'] ) && function_exists( 'wc_get_product_ids_on_sale' ) ) {
				$sale_ids = wc_get_product_ids_on_sale();
				$args['post__in'] = ! empty( $sale_ids ) ? $sale_ids : [ 0 ];
			}
			if ( ! empty( $tag_config['s_query'] ) ) {
				$args['s'] = $tag_config['s_query'];
			}
		} else {
			// Extend search to additional fields (taxonomy, SKU, meta) via posts_where.
			global $wpdb;
			$like             = '%' . $wpdb->esc_like( $query ) . '%';
			$extra_conditions = [];

			if ( $search_categories || $search_tags ) {
				$taxonomies = [];
				if ( $search_categories ) {
					$taxonomies[] = 'category';
					if ( taxonomy_exists( 'product_cat' ) ) {
						$taxonomies[] = 'product_cat';
					}
				}
				if ( $search_tags ) {
					$taxonomies[] = 'post_tag';
					if ( taxonomy_exists( 'product_tag' ) ) {
						$taxonomies[] = 'product_tag';
					}
				}
				$tax_count        = \count( $taxonomies );
				$tax_placeholders = implode( ',', array_fill( 0, $tax_count, '%s' ) );
				$sql_args         = $taxonomies;
				$sql_args[]       = $like;
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
				$extra_conditions[] = $wpdb->prepare(
					"{$wpdb->posts}.ID IN (
						SELECT tr.object_id FROM {$wpdb->term_relationships} tr
						INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
						INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
						WHERE tt.taxonomy IN ($tax_placeholders) AND t.name LIKE %s
					)",
					...$sql_args
				);
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			}
			if ( $search_sku && function_exists( 'wc_get_product' ) ) {
				$extra_conditions[] = $wpdb->prepare(
					"{$wpdb->posts}.ID IN (
						SELECT post_id FROM {$wpdb->postmeta}
						WHERE meta_key = '_sku' AND meta_value LIKE %s
					)",
					$like
				);
			}
			if ( $search_meta ) {
				$extra_conditions[] = $wpdb->prepare(
					"{$wpdb->posts}.ID IN (
						SELECT post_id FROM {$wpdb->postmeta}
						WHERE meta_key NOT LIKE %s AND meta_value LIKE %s
					)",
					$wpdb->esc_like( '_' ) . '%',
					$like
				);
			}

			// WP's native `s` always matches post_title OR post_excerpt OR post_content,
			// so a disabled field keeps matching unless the clause is replaced outright.
			$search_columns = [];
			if ( $search_title ) {
				$search_columns[] = 'post_title';
			}
			if ( $search_excerpt ) {
				$search_columns[] = 'post_excerpt';
			}
			if ( $search_content ) {
				$search_columns[] = 'post_content';
			}

			if ( \count( $search_columns ) < 3 ) {
				$column_conditions = [];
				foreach ( $search_columns as $search_column ) {
					// Column name comes from the hardcoded list above, never from input.
					$column_conditions[] = $wpdb->prepare( "{$wpdb->posts}.{$search_column} LIKE %s", $like );
				}

				$conditions   = array_merge( $column_conditions, $extra_conditions );
				$search_where = function () use ( $conditions ) {
					// Nothing searchable left: match nothing, not everything.
					return empty( $conditions ) ? ' AND 1=0' : ' AND (' . implode( ' OR ', $conditions ) . ')';
				};
				add_filter( 'posts_search', $search_where, 10 );
			} elseif ( ! empty( $extra_conditions ) ) {
				// All native fields enabled: keep WP's clause (and its multi-word term
				// splitting) and OR the extras into it. posts_search (not posts_where)
				// keeps post__not_in a separate AND clause so exclusions still apply.
				$extra_sql    = implode( ' OR ', $extra_conditions );
				$search_where = function ( $search ) use ( $extra_sql ) {
					if ( empty( $search ) ) {
						return ' AND (' . $extra_sql . ')';
					}
					// $search is " AND (cond1 OR cond2)" — insert extra inside the parens.
					$search = rtrim( $search );
					if ( ')' === substr( $search, -1 ) ) {
						$search = substr( $search, 0, -1 ) . ' OR ' . $extra_sql . ')';
					} else {
						$search .= ' OR ' . $extra_sql;
					}
					return $search;
				};
				add_filter( 'posts_search', $search_where, 10 );
			}
		}

		$wp_query = new \WP_Query( $args );

		if ( $search_where ) {
			remove_filter( 'posts_search', $search_where, 10 );
		}

		if ( $include_pages_where ) {
			remove_filter( 'posts_where', $include_pages_where, 10 );
		}

		$results = [];

		while ( $wp_query->have_posts() ) {
			$wp_query->the_post();
			$post_id = get_the_ID();

			$result = [
				'id'      => $post_id,
				'title'   => get_the_title(),
				'url'     => get_permalink(),
				'excerpt' => wp_strip_all_tags( get_the_excerpt() ),
				'type'    => get_post_type(),
				'image'   => get_the_post_thumbnail_url( $post_id, 'thumbnail' ) ?: '',
				'date'    => get_the_date(),
				'author'  => get_the_author(),
			];

			// WooCommerce product data.
			if ( 'product' === get_post_type() && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $post_id );
				if ( $product ) {
					$result['price']        = $product->get_price_html();
					$result['rating']       = floatval( $product->get_average_rating() );
					$result['reviewCount']  = intval( $product->get_review_count() );
					$result['onSale']       = $product->is_on_sale();
					$result['addToCartUrl'] = $product->add_to_cart_url();
					$result['addToCartText'] = $product->add_to_cart_text();
				}
				$terms = get_the_terms( $post_id, 'product_cat' );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					$result['category'] = $terms[0]->name;
				}
			} else {
				$cats = get_the_category( $post_id );
				if ( ! empty( $cats ) ) {
					$result['category'] = $cats[0]->name;
				}
			}

			$results[] = $result;
		}

		wp_reset_postdata();

		$response = [
			'results' => $results,
			'total'   => intval( $wp_query->found_posts ),
			'pages'   => intval( $wp_query->max_num_pages ),
		];

		// Autocorrect: if no results, try broader search.
		if ( empty( $results ) && $auto_correct ) {
			$words = preg_split( '/\s+/', $query );
			if ( count( $words ) > 1 ) {
				// Try searching for the longest word.
				usort( $words, function ( $a, $b ) {
					return strlen( $b ) - strlen( $a );
				} );
				$suggestion_args = [
					's'              => $words[0],
					'post_type'      => $post_types,
					'posts_per_page' => 1,
					'post_status'    => 'publish',
				];
				$suggestion_query = new \WP_Query( $suggestion_args );
				if ( $suggestion_query->have_posts() ) {
					$suggestion_query->the_post();
					$response['suggestion'] = get_the_title();
					wp_reset_postdata();
				}
			} else {
				// Single word: try partial match on titles.
				global $wpdb;
				$like      = '%' . $wpdb->esc_like( $query ) . '%';
				$cache_key = 'dnxte_search_suggest_' . md5( $query );
				$title     = wp_cache_get( $cache_key, 'dnxte_ajax_search' );

				if ( false === $title ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- single-row lookup with no WP_Query equivalent.
					$title = $wpdb->get_var( $wpdb->prepare(
						"SELECT post_title FROM {$wpdb->posts}
						 WHERE post_status = 'publish' AND post_title LIKE %s
						 LIMIT 1",
						$like
					) );
					wp_cache_set( $cache_key, $title ? $title : '', 'dnxte_ajax_search', HOUR_IN_SECONDS );
				}

				if ( $title ) {
					$response['suggestion'] = $title;
				}
			}
		}

		wp_send_json_success( $response );
	}

	/**
	 * AJAX handler: returns a flat list of published WooCommerce products (id + name)
	 * used to populate the product exclusion selector in the module settings panel.
	 */
	public static function handle_get_products() {
		check_ajax_referer( 'dnxte_ajax_search', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions.' ], 403 );
		}

		if ( ! function_exists( 'wc_get_products' ) ) {
			wp_send_json_success( [] );
		}

		$per_page = min( absint( $_GET['per_page'] ?? 100 ), 200 );
		$page     = max( 1, absint( $_GET['page'] ?? 1 ) );
		$search   = sanitize_text_field( wp_unslash( $_GET['search'] ?? '' ) );

		$query_args = [
			'status'     => 'publish',
			'limit'      => $per_page,
			'page'       => $page,
			'orderby'    => 'title',
			'order'      => 'ASC',
			'return'     => 'objects',
		];

		if ( ! empty( $search ) ) {
			$query_args['s'] = $search;
		}

		$products = wc_get_products( $query_args );
		$data     = [];

		foreach ( $products as $product ) {
			$data[] = [
				'id'   => $product->get_id(),
				'name' => $product->get_name(),
				'sku'  => $product->get_sku(),
			];
		}

		wp_send_json_success( $data );
	}
}
