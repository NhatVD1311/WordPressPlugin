<?php
namespace DNXTE\Modules\Base\Traits;

use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DNXTE\Shared\ClassScoper;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

trait CommonTrait {
    public function applyGradientOld( $attrs, $slug, $order_class, $selector, $args ) {
        $elements = $args['elements'];

        // Desktop
        $gradientUse = $attrs[$slug]['advanced']['gradientUse']['desktop']['value'] ?? 'off';

        $gradientStyle = $this->getGradientStyle( $attrs, $slug );
        $gradientStyleTab = $this->getGradientStyle( $attrs, $slug, 'tablet' );
        $gradientStylePhone = $this->getGradientStyle( $attrs, $slug, 'phone' );

        if ( 'on' === $gradientUse ) {
            $gradientStyle = "background: $gradientStyle;";
            $gradientStyleTablet = "background: $gradientStyleTab;";
            $gradientStylePhone = "background: $gradientStylePhone;";

            $style = $elements->style(
                array(
                    'attrName'   => $slug,
                    'styleProps' => array(
                        'advancedStyles' => array(
                            array(
                                'componentName' => 'divi/common',
                                'props'         => array(
                                    'attr'     => $attrs[$slug]['advanced']['colorOne'] ?? '',
                                    'property' => $gradientStyle,
                                ),
                            ),
                        ),

                    ),
                )
            );
            $responsive_rules = array(
                array(
                    'atRules'     => '@media only screen and (max-width: 980px)',
                    'selector'    => $selector,
                    'declaration' => $gradientStyleTablet,
                ),
                array(
                    'atRules'     => '@media only screen and (max-width: 767px)',
                    'selector'    => $selector,
                    'declaration' => $gradientStylePhone,
                ),
            );

            return array_merge( $style, $responsive_rules );
        }
        return array();
    }

    // $backBg = ( new self() )->applyBgOld( $attrs, 'backBg', $order_class, $backSelector, $args );
    public function applyBgOld( $attrs, $slug, $order_class, $selector, $args ) {
        $colorStyle = [];
        $use_bg_color = $attrs[$slug]['advanced']['colorUse']['desktop']['value'] ?? 'off';
        $use_bg_image = $attrs[$slug]['advanced']['imageUse']['desktop']['value'] ?? 'off';

        if ( 'on' === $use_bg_image ) {
            $image_src = $attrs[$slug]['advanced']['imageSrc']['desktop']['value'] ?? '';

            // The upload field persists its value as a structured object
            // ( [ 'src' => url, 'id' => ... ] ), not a bare URL string. Feeding
            // that array into StyleDeclarations::add() — which is strictly typed
            // to string — fatals, so normalize to the scalar 'src' URL first.
            if ( is_array( $image_src ) ) {
                $image_src = $image_src['src'] ?? $image_src['url'] ?? '';
            }

            if ( '' !== $image_src ) {
                $colorStyle[] = CommonStyle::style(
                    array(
                        'selector' => $selector,
                        'property' => 'background-image',
                        'attr'     => array( 'desktop' => array( 'value' => "url($image_src)" ) ),
                    )
                );
            }
            return $colorStyle;
        }
        $colorStyle[] = $this->applyGradientOld( $attrs, $slug, $order_class, $selector, $args );

        if ( 'on' === $use_bg_color ) {
            $color1 = $attrs[$slug]['advanced']['singleColorOne'] ?? array();
            $colorStyle[] = CommonStyle::style(
                array(
                    'selector' => $selector,
                    'property' => 'background-color',
                    'attr'     => $color1,
                )
            );
        }

        return $colorStyle;
    }


    public function getAttrByMode($attr)
    {
        if (!is_array($attr)) {
            return '';
        }

        $mode = $this->detectDeviceMode();

        // Return the value based on the active mode, or fallback to desktop
        return $attr[$mode]['value'] ?? $attr['desktop']['value'] ?? '';
    }

    private function detectDeviceMode()
    {
        $modes = ['desktop', 'tablet', 'phone'];

        // First, check cookie (set by JS for accurate viewport detection)
        if (isset($_COOKIE['device_mode'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $cookie_mode = sanitize_key(wp_unslash($_COOKIE['device_mode']));
            if (in_array($cookie_mode, $modes, true)) {
                return $cookie_mode;
            }
        }

        // Fallback: detect from User-Agent for first visit
        return $this->detectDeviceFromUserAgent();
    }

    private function detectDeviceFromUserAgent()
    {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) {
            return 'desktop';
        }

        $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT']));

        // Phone patterns (check first - more specific)
        $phone_patterns = [
            '/iPhone/i',
            '/Android.*Mobile/i',
            '/Windows Phone/i',
            '/BlackBerry/i',
            '/webOS/i',
            '/Opera Mini/i',
            '/IEMobile/i',
        ];

        foreach ($phone_patterns as $pattern) {
            if (preg_match($pattern, $user_agent)) {
                return 'phone';
            }
        }

        // Tablet patterns
        $tablet_patterns = [
            '/iPad/i',
            '/Android(?!.*Mobile)/i',
            '/Tablet/i',
            '/Kindle/i',
            '/Silk/i',
            '/PlayBook/i',
        ];

        foreach ($tablet_patterns as $pattern) {
            if (preg_match($pattern, $user_agent)) {
                return 'tablet';
            }
        }

        return 'desktop';
    }


    public static function style_declaration(): object {
        return new StyleDeclarations(
            [
                'returnType' => 'string',
                'important'  => [
                    'font-family' => true,
                ],
            ]
        );
        // return
    }

    public function getGradientStyle( $attrs, $slug, $viewport = 'desktop' ) {
        $gradientUse = $attrs[$slug]['advanced']['gradientUse']['desktop']['value'] ?? 'off';

        if ( "on" !== $gradientUse ) {
            return '';
        }

        $viewport = !empty( $viewport ) ? $viewport : 'desktop';

        $gradientType = $attrs[$slug]['advanced']['gradientType'][$viewport]['value'] ?? '';
        $gradientLinerDic = $attrs[$slug]['advanced']['gradientLinearDirection'][$viewport]['value'] ?? '';
        $gradientRadialDic = $attrs[$slug]['advanced']['gradientRadialDirection'][$viewport]['value'] ?? '';
        $gradientApply = 'linear-gradient' === $gradientType ? $gradientLinerDic : $gradientRadialDic;

        // Color
        $colorOne = $attrs[$slug]['advanced']['colorOne'][$viewport]['value'] ?? '';
        $colorTwo = $attrs[$slug]['advanced']['colorTwo'][$viewport]['value'] ?? '';

        // Color Position
        $startPos = $attrs[$slug]['advanced']['startPos'][$viewport]['value'] ?? '';
        $endPos = $attrs[$slug]['advanced']['endPos'][$viewport]['value'] ?? '';

        return $gradientStyle = "$gradientType($gradientApply, $colorOne $startPos, $colorTwo $endPos)";
    }

    public static function spacing_declaration( $params ) {
        $attrValue = $params['attrValue'] ?? [];

        $margin = $attrValue['margin'] ?? [];
        $padding = $attrValue['padding'] ?? [];

        $style_declarations = new StyleDeclarations(
            [
                'returnType' => 'string',
            ]
        );

        if ( !empty( $margin ) ) {
            if ( isset( $margin['top'] ) ) {
                $style_declarations->add( "margin-top", $margin['top'] );
            }
            if ( isset( $margin['right'] ) ) {
                $style_declarations->add( "margin-right", $margin['right'] );
            }
            if ( isset( $margin['bottom'] ) ) {
                $style_declarations->add( "margin-bottom", $margin['bottom'] );
            }
            if ( isset( $margin['left'] ) ) {
                $style_declarations->add( "margin-left", $margin['left'] );
            }
        }

        if ( !empty( $padding ) ) {
            if ( isset( $padding['top'] ) ) {
                $style_declarations->add( "padding-top", $padding['top'] );
            }
            if ( isset( $padding['right'] ) ) {
                $style_declarations->add( "padding-right", $padding['right'] );
            }
            if ( isset( $padding['bottom'] ) ) {
                $style_declarations->add( "padding-bottom", $padding['bottom'] );
            }
            if ( isset( $padding['left'] ) ) {
                $style_declarations->add( "padding-left", $padding['left'] );
            }
        }

        return $style_declarations->value();
    }

    /**
	 * Icon Font declaration.
	 *
	 * This function will declare icon font for DiviNxtPersonItem.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array      $attrValue  The value (breakpoint > state > value) of module attribute.
	 *     @type bool|array $important  If set to true, the CSS will be added with !important.
	 *     @type string     $returnType This is the type of value that the function will return. Can be either string or key_value_pair.
	 * }
	 *
	 * @return string
	 * @since ??
	 */
	public static function icon_style_declaration( array $params ): string {
           $icon_attr = $params['attrValue'] ?? [];

           $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
				],
			]
		);


		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		if ( ! empty( $icon_attr['unicode'] ) ) {
			$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		}

		return $style_declarations->value();
	}

    /**
     * Get content by library ID
     *
     * @param int|string $library_id The library post ID.
     * @return string The filtered post content.
     */
    public static function get_content( $library_id ) {
        if ( empty( $library_id ) ) {
            return '';
        }

        // The ID is a free block attr — any builder-capable user can point it
        // at any post. Without this gate a draft/private/password-protected
        // post's content would render publicly on the page embedding it.
        // Library items (et_pb_layout) are always status 'publish' with no
        // password, so legitimate picks pass unchanged.
        $library_post = get_post( (int) $library_id );
        if ( ! $library_post
            || 'publish' !== $library_post->post_status
            || '' !== $library_post->post_password ) {
            return '';
        }

        $post_content = get_post_field( 'post_content', (int) $library_id );

        // A library layout is rendered here in a *separate* pass, so Divi
        // restarts its per-slug order-class counter (`dnxte_button_0`,
        // `et_pb_text_0`, …). Those numbers then collide with the identically
        // numbered order classes of the same modules on the host page. We give
        // every embed a unique token and rewrite its order classes to it so
        // nothing can collide. A process-wide counter keeps the token unique
        // even when the same layout is embedded multiple times on one page,
        // across different module types.
        //
        // The embed must render under an isolated style key: Divi's shared
        // buffer merges same-selector declarations and Style::render() never
        // consumes it, so anything registered under the page's own key ends up
        // un-renamed in the global (statically cached) stylesheet where it
        // restyles the host page's modules.
        $prefix = ClassScoper::instance_prefix( 'lib', $library_id );
        $handle = ClassScoper::begin_isolated_styles( $prefix );

        // Module links and entrance animations are bound in JS from Divi's
        // `link` / `animation` script data, keyed by the same order classes we
        // rename below — mark where this embed's entries start so they can be
        // renamed in lockstep with the HTML. Animations especially: base CSS
        // hides `.et_animated` at `opacity: 0` and only the animation script
        // (matching by that class) ever reveals the module, so a stale class
        // here means the module never appears at all.
        $link_data_offset      = ClassScoper::script_data_offset( 'link' );
        $animation_data_offset = ClassScoper::script_data_offset( 'animation' );

        $content = apply_filters( 'the_content', $post_content );

        $embed_css = ClassScoper::end_isolated_styles( $handle );

        // Only rewrite the HTML when we actually captured matching CSS to
        // rewrite alongside it — otherwise the embed's HTML classes would no
        // longer match their (still globally-output) styles and it would lose
        // its styling. When there's nothing to capture we fall back to the
        // original, un-scoped behaviour.
        if ( '' === trim( $embed_css ) ) {
            return $content;
        }

        $content   = ClassScoper::rename_html( $content, $prefix );
        $embed_css = ClassScoper::rename_css( $embed_css, $prefix );

        ClassScoper::rename_script_data( 'link', $link_data_offset, $prefix );
        ClassScoper::rename_script_data( 'animation', $animation_data_offset, $prefix );

        return '<style>' . $embed_css . '</style>' . $content;
    }
}
