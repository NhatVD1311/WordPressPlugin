<?php

/**
 * DiviNxtPerson::module_styles().
 *
 * @package MEE\Modules\DiviNxtPerson
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtPerson\DiviNxtPersonTrait;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\ModuleLibrary\Portfolio\PortfolioModuleTraits\StyleDeclarationTrait;
use DNXTE\Modules\DiviNxtPersonItem\DiviNxtPersonItem;

trait ModuleStylesTrait
{

	use CustomCssTrait;
	// use StyleDeclarationTrait;

	/**
	 * DiviNxtPersonItem's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/DiviNxtPerson/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
	public static function module_styles($args)
	{
		$attrs        = $args['attrs'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		//   @media only screen and (max-width: 980px) {
        //         .dnxte_person_0 .dnxte-nextperson-team-wrap {
        //             align-items:left-center
        //         }

        //         .dnxte_person_0 .dnxte-nextperson-img {
        //             align-items: top-center
        //         }
        //     }

        //     @media only screen and (max-width: 767px) {
        //         .dnxte_person_0 .dnxte-nextperson-team-wrap {
        //             align-items:left-bottom
        //         }

        //         .dnxte_person_0 .dnxte-nextperson-img {
        //             align-items: top-left
        //         }
        //     }


		$imgLeftPositionTablet = isset($attrs['featureImage']['advanced']['imageLeftPosition']['tablet']['value']) ? $attrs['featureImage']['advanced']['imageLeftPosition']['tablet']['value'] : '';
		$imgLeftPositionMobile = isset($attrs['featureImage']['advanced']['imageLeftPosition']['phone']['value']) ? $attrs['featureImage']['advanced']['imageLeftPosition']['phone']['value'] : '';
		$imageTopPositionTablet = isset($attrs['featureImage']['advanced']['imageTopPosition']['tablet']['value']) ? $attrs['featureImage']['advanced']['imageTopPosition']['tablet']['value'] : '';
		$imageTopPositionMobile = isset($attrs['featureImage']['advanced']['imageTopPosition']['phone']['value']) ? $attrs['featureImage']['advanced']['imageTopPosition']['phone']['value'] : '';
		

		switch ( $imgLeftPositionTablet ) {
			case 'left-top':
				$imgLeftPositionTablet = 'flex-start';
				break;
			case 'left-center':
				$imgLeftPositionTablet = 'center';
				break;
			case 'left-bottom':
				$imgLeftPositionTablet = 'flex-end';
				break;
			default:
				$imgLeftPositionTablet = 'flex-start';
		}
		switch ( $imgLeftPositionMobile ) {
			case 'left-top':
				$imgLeftPositionMobile = 'flex-start';
				break;
			case 'left-center':
				$imgLeftPositionMobile = 'center';
				break;
			case 'left-bottom':
				$imgLeftPositionMobile = 'flex-end';
				break;
			default:
				$imgLeftPositionMobile = 'flex-start';
		}
		switch ( $imageTopPositionTablet ) {
			case 'top-left':
				$imageTopPositionTablet = 'flex-start';
				break;
			case 'top-center':
				$imageTopPositionTablet = 'center';
				break;
			case 'top-right':
				$imageTopPositionTablet = 'flex-end';
				break;
			default:
				$imageTopPositionTablet = 'flex-start';
		}
		switch ( $imageTopPositionMobile ) {
			case 'top-left':
				$imageTopPositionMobile = 'flex-start';
				break;
			case 'top-center':
				$imageTopPositionMobile = 'center';
				break;
			case 'top-right':
				$imageTopPositionMobile = 'flex-end';
				break;
			default:
				$imageTopPositionMobile = 'flex-start';
		}

		$isGradientEnabled = isset( $attrs['contentArea']['advanced']['enableGradient']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['enableGradient']['desktop']['value'] : 'off';
		$colorOne        = isset( $attrs['contentArea']['advanced']['colorOne']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['colorOne']['desktop']['value'] : '';
		$colorTwo        = isset( $attrs['contentArea']['advanced']['colorTwo']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['colorTwo']['desktop']['value'] : '';
		$gradientType    = isset( $attrs['contentArea']['advanced']['gradientType']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['gradientType']['desktop']['value'] : 'linear';
		$linearDirection = isset( $attrs['contentArea']['advanced']['linearDirection']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['linearDirection']['desktop']['value'] : '180deg';
		$radialPosition  = isset( $attrs['contentArea']['advanced']['radialDirection']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['radialDirection']['desktop']['value'] : 'circle at center';
		$startPoint      = isset( $attrs['contentArea']['advanced']['startPoint']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['startPoint']['desktop']['value'] : '0%';
		$endPoint        = isset( $attrs['contentArea']['advanced']['endPoint']['desktop']['value'] ) ?  $attrs['contentArea']['advanced']['endPoint']['desktop']['value'] : '100%';
		$bgProperties    = $gradientType === 'linear' ? "background: linear-gradient($linearDirection, $colorOne $startPoint, $colorTwo $endPoint);background-color" : "background: radial-gradient($radialPosition, $colorOne, $colorTwo);background-color";
		
		$gradientBg = $isGradientEnabled === "on" ? [
			CommonStyle::style(
				[
					'selector' => $args['orderClass'] . ' .dnxte-nextperson-wrapper',
					'attr'     => $attrs['contentArea']['advanced']['colorOne'] ?? [],
					'property' => $bgProperties,
				]
			),
		] : [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					$elements->style(
						[
							'attrName' => 'featureImage',
						]
					),

					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .dnxte-nextperson-img img',
							'attr'     => $attrs['featureImage']['advanced']['width'] ?? [],
							'property' => 'max-width',
						]
					),

					// personName.
					$elements->style(
						[
							'attrName' => 'personName',
						]
					),

					// personPosition.
					$elements->style(
						[
							'attrName' => 'designation',
						]
					),

					// personDetails.
					$elements->style(
						[
							'attrName' => 'description',
						]
					),
					
					// contentContainer.
					$elements->style(
						[
							'attrName' => 'contentArea',
						]
					),
					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .dnxte-nextperson-social',
							'attr'     => $attrs['socialIcons']['advanced']['alignment'] ?? [],
							'property' => 'justify-content',
						]
					),

					CommonStyle::style(
						[
							'selector' => $args['orderClass'] . ' .dnxte-nextperson-wrapper',
							'attr'     => $attrs['contentArea']['advanced']['background'] ?? [],
							'property' => 'background-color',
						]
					),

					...$gradientBg,

					[
						[
							'atRules'     => '@media only screen and (max-width: 980px)',
							'selector'    => $order_class . ' .dnxte-nextperson-team-wrap',
							'declaration' => "align-items: {$imgLeftPositionTablet};",
						],
						[
							'atRules'     => '@media only screen and (max-width: 767px)',
							'selector'    => $order_class . ' .dnxte-nextperson-team-wrap',
							'declaration' => "align-items: {$imgLeftPositionMobile};",
						],
						[
							'atRules'     => '@media only screen and (max-width: 980px)',
							'selector'    => $order_class . ' .dnxte-nextperson-img',
							'declaration' => "align-items: {$imageTopPositionTablet};",
						],
						[
							'atRules'     => '@media only screen and (max-width: 767px)',
							'selector'    => $order_class . ' .dnxte-nextperson-img',
							'declaration' => "align-items: {$imageTopPositionMobile};",
						],

					],
				
				],
			]
		);
	}
}
