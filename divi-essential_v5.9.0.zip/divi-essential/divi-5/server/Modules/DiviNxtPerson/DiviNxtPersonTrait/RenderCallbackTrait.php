<?php

/**
 * DiviNxtPersonItem::render_callback()
 *
 * @package MEE\Modules\DiviNxtPersonItem
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtPerson\DiviNxtPersonTrait;

use ET\Builder\Framework\Utility\HTMLUtility;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\DiviNxtPerson\DiviNxtPerson;

trait RenderCallbackTrait
{
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	/**
	 * DiviNxtPerson render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Parent module.
	 */
	public static function render_callback($attrs, $content, $block, $elements)
	{
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ($inner_block) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent       = BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
		$parent_attrs = $parent->attrs ?? [];

		
		$imagePosition         = isset($attrs['featureImage']['advanced']['imagePosition']['desktop']['value']) ? $attrs['featureImage']['advanced']['imagePosition']['desktop']['value'] : 'person-top';
		$imageLeftPosition     = isset($attrs['featureImage']['advanced']['imageLeftPosition']['desktop']['value']) ? $attrs['featureImage']['advanced']['imageLeftPosition']['desktop']['value'] : 'left-top';
		$wrappreClass          = $imagePosition == 'person-left' ? $imageLeftPosition : '';
		$imageTopPosition      = isset($attrs['featureImage']['advanced']['imageTopPosition']['desktop']['value']) ? $attrs['featureImage']['advanced']['imageTopPosition']['desktop']['value'] : 'top-left';
		$imageInnerPosition    = $imagePosition == 'person-top' ? $imageTopPosition : '';
		$socialItemAlign       = isset($attrs['socialIcons']['advanced']['alignment']['desktop']['value']) ? $attrs['socialIcons']['advanced']['alignment']['desktop']['value'] : '';
		$social_item_alignment = $socialItemAlign ? "dnext_person_social_alignment_{$socialItemAlign}" : "";



		$image_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => "dnxte-nextperson-img dnxte-nextperson-{$imageInnerPosition}",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [
					$elements->render(
						[
							'attrName' => 'featureImage',
						]
					),
				],
			]
		);

		$person_name = $elements->render(
			[
				'attrName' => 'personName',
			]
		);

		$designation = $elements->render(
			[
				'attrName' => 'designation',
			]
		);

		$description = $elements->render(
			[
				'attrName' => 'description',
			]
		);

		$network_items = HTMLUtility::render(
			[
				'tag'               => 'ul',
				'attributes'        => [
					'class' => "dnxte-nextperson-social {$social_item_alignment}",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content,
			]
		);

		$content_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-nextperson-des'
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [
					HTMLUtility::render(
						[
							'tag'               => 'div',
							'attributes'        => [
								'class' => 'dnxte-nextperson-wrapper'
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => [
								$person_name,
								$designation,
								$description
							]
						]
					),
					$network_items,
				]
			]
		);



		$next_person_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => "dnxte-nextperson-team-wrap dnxte-nextperson-{$wrappreClass}",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [$image_container, $content_container]
			]
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [DiviNxtPerson::class, 'module_classnames'],
				'scriptDataComponent' => [DiviNxtPerson::class, 'module_script_data'],
				'stylesComponent'     => [DiviNxtPerson::class, 'module_styles'],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $next_person_container,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
