<?php

/**
 * Register all modules with dependency tree.
 *
 * @package DNXTE\Modules
 * @since ??
 */

namespace DNXTE\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class Modules {
	private $module_mapping = array(
		'dnxte-button'                  => 'NextButton',
		'dnxte-dual-button'             => 'DualButton',
		'dnxte-text-highlight'          => 'NextTextHighlight',
		'dnxte-minimal-image'           => 'NextMinimalImageHover',
		'dnxte-team-creative'           => array( 'NextTeamCreative', 'NextTeamCreativeItem' ),
		'dnxte-before-after'            => 'BeforeAfter',
		'dnxte-text-color-motion'       => 'NextTextColorMotion',
		'dnxte-text-hover-highlight'    => 'NextTextHoverHighlight',
		'dnxte-lottie'                  => 'NextLottie',
		'dnxte-divider'                 => 'Divider',
		'dnxte-rating'                  => 'Rating',
		'dnxte-feature-list'            => array( 'NextFeatureList', 'NextFeatureListChild' ),
		'dnxte-gallery-slider'          => array( 'NextGallerySlider', 'NextGallerySliderChild' ),
		'dnxte-price-list'              => array( 'NextPriceList', 'NextPriceListChild' ),
		'dnxte-image-accordion'         => array( 'NextImageAccordion', 'NextImageAccordionChild' ),
		'dnxte-business-hour'           => array( 'NextBusinessHour', 'NextBusinessHourChild' ),
		'dnxte-divi-review'             => 'Review',
		'dnxte-image-reveal'            => 'NextImageReveal',
		'dnxte-image-icon-effect'       => 'NextImageIcon',
		'dnxte-text-stroke'             => 'NextTextStroke',
		'dnxte-text-mask'               => 'NextTextMask',
		'dnxte-3D-flip-box'             => 'NextFlipBox3d',
		'dnxte-promo-box'               => 'NextPromoBox',
		'dnxte-text-tilt'               => 'NextTextTilt',
		'dnxte-person'                  => array( 'DiviNxtPerson', 'DiviNxtPersonItem' ),
		'dnxte-flip-box'                => 'DiviNxtFlipBox',
		'dnxte-team-social-reveal'      => array( 'NextTeamSocialReveal', 'NextTeamSocialRevealItem' ),
		'dnxte-team-member-overlay'     => array( 'NextTeamOverlay', 'NextTeamOverlayItem' ),
		'dnxte-text-multi-heading'      => 'NextMultiHeading',
		'dnxte-text-glitch'             => 'NextTextGlitch',
		'dnxte-step-flow'               => 'NextStepFlow',
		'dnxte-timeline'                => array( 'NextTimeline', 'NextTimelineChild' ),
		'dnxte-text-gradient'           => 'NextGradientText',
		'dnxte-image-hover-box'         => 'NextImageHoverBox',
		'dnxte-mega-image-effect'       => 'NextMegaImageEffect',
		'dnxte-text-divider'            => 'TextDivider',
		'dnxte-image-scroll'            => 'NextImageScroll',
		'dnxte-facebook-embedded-post'  => 'NextEmbeddedPost',
		'dnxte-facbook-comment'         => 'NextComment',
		'dnxte-facebook-embedded-comment' => 'NextEmbeddedComment',
		'dnxte-facebook-embedded-Video' => 'NextEmbeddedVideo',
		'dnxte-facebook-page'           => 'NextFBPage',
		'dnxte-facebook-share-button'   => 'NextFBShareButton',
		'dnxte-facebook-like-button'    => 'NextLikeButton',
		'dnxte-circular-image-hover'    => 'NextCircularImageHover',
		'dnxte-blurb'                   => 'NextBlurb',
		'dnxte-twitter-tweet'           => 'NextXPost',
		'dnxte-twitter-timeline'        => 'NextXTimeline',
		'dnxte-twitter-share'           => 'NextXPostButton',
		'dnxte-twitter-follow'          => 'NextXFollowButton',
		'dnxte-ultimate-image-hover'    => 'NextUltimateImageHover',
		'dnxte-image-magnifier'         => 'NextImageMagnifier',
		'dnxte-testimonial-slider'      => array( 'NextTestimonialSlider', 'NextTestimonialSliderItem' ),
		'dnxte-logo-carousel'           => array( 'NextLogoCarousel', 'NextLogoCarouselChild' ),
		'dnxte-text-animation'          => 'NextTextAnimation',
		'dnxte-team-overlay-card'       => array( 'NextTeamOverlayCard', 'NextTeamOverlayCardItem' ),
		'dnxte-floating-element'        => array( 'NextFloatingElements', 'NextFloatingElementsItem' ),
		'dnxte-3d-cube-slider'          => array( 'Next3dCubeSlider', 'Next3dCubeSliderChild' ),
		'dnxte-image-hotspot'           => array( 'NexthotsPot', 'NexthotspotChild' ),
		'dnxte-post-carousel'           => 'NextPostCarousel',
		'dnxte-content-toggle'          => 'NextContentToggle',
		'dnxte-masonry-gallery'         => 'NextMasonryGallery',
		'dnxte-image-rotation'          => 'ImageRotation',
		'dnxte-video-gallery'      => array( 'NextVideoGallery', 'NextVideoGalleryChild' ),
		'dnxte-skill-bars'         => array( 'NextSkillBars', 'NextSkillBarsChild' ),
		'dnxte-acf-gallery'             => 'AcfGallery',
		'dnxte-advanced-tab'            => array( 'NextAdvancedTab', 'NextAdvancedTabItem' ),
		'dnxte-coverflow-slider'        => array( 'DiviCarousel', 'DiviCarouselChild' ),
		'dnxte-text-stroke-motion'      => 'NextTextStrokeMotion',
		'dnxte-table-content'       	=> 'NextTableOfContents',
		'dnxte-reading-progressbar'     => 'ProgressBar',
		'dnxte-stripe-button'           => 'StripeButton',
		'dnxte-data-table'              => 'NextDataTable',
		'scroll-stacking-cards'         => array( 'NextScrollStackingCards', 'NextScrollStackingCardsItem' ),
		'dnxte-interactive-circle'      => array( 'InteractiveCircle', 'InteractiveCircleChild' ),
		'dnxte-text-marquee'            => array( 'NextTextMarquee', 'NextTextMarqueeChild' ),
		'dnxte-contact-7'               => 'NextContactForm7',
		'dnxte-stacked-images'          => array( 'NextStackedImages', 'NextStackedImagesItem' ),
		'dnxte-gravity-forms-styler'    => 'NextGravityForms',
		'dnxte-tablepress-styler'       => 'NextTablePressStyler',
		'dnxte-text-scroll'             => 'TextScroll',
		'dnxte-countdown'               => 'NextCountDown',
		'dnxte-breadcrumb'              => 'NextBreadcrumb',
		'dnxte-vertical-menu'           => 'NextVerticalMenu',
		'dnxte-social-proof'            => 'NextSocialProof',
		'dnxte-post-grid'               => 'NextPostGrid',
		'dnxte-filterable-cpt'          => 'FilterableCpt',
		'dnxte-svg-animator'            => 'SvgAnimator',
		'dnxte-rotating-text'           => 'NextRotatingText',
		'dnxte-expanding-cta'           => 'NextExpandingCta',
		'dnxte-next-pie-chart'          => 'NextPieChart',
		'dnxte-next-audio'              => 'NextAudio',
		'dnxte-next-video'              => 'NextVideo',
		'dnxte-next-spline'             => 'NextSpline',
		'dnxte-ig-carousel-feed'        => 'NextInstaFeedCarousel',
		'dnxte-next-chart'              => array( 'NextChart', 'NextChartDataset' ),
		'dnxte-next-social-share'       => array( 'NextSocialShare', 'NextSocialShareItem' ),
		'dnxte-paypal-button'           => 'PaypalButton',
		'dnxte-scrolling-zoom-gallery'  => array( 'NextScrollingZoomGallery', 'NextScrollingZoomGalleryChild' ),
		'dnxte-spin-wheel'              => array( 'NextSpinWheel', 'NextSpinWheelChild' ),
		'dnxte-advance-counter'         => 'AdvanceCounter',
		'dnxte-inline-content'          => array( 'InlineContent', 'InlineContentChild' ),
		'dnxte-throwable-items'         => array( 'NextThrowableItems', 'NextThrowableItemsItem' ),
		'dnxte-ajax-search'             => 'AjaxSearch',
		'dnxte-news-ticker'             => 'NewsTicker',
		'dnxte-globe-3d-map'            => array( 'Globe3dMap', 'Globe3dMapItem' ),
		'dnxte-calendar-events'         => array( 'CalendarEvents', 'CalendarEventsItem' ),
		'dnxte-orbiting-skills'         => array( 'OrbitingSkills', 'OrbitingSkillsItem' ),
		'dnxte-logo-tree'               => array( 'LogoTree', 'LogoTreeItem' ),
		'dnxte-next-comparison-list'    => array( 'NextComparisonList', 'NextComparisonListItem' ),
		'dnxte-advanced-icon'           => 'AdvancedIcon',
		'dnxte-advanced-pricing-table'  => array( 'AdvancedPricingTable', 'AdvancedPricingFeature' ),
		'dnxte-whatsapp-chat'           => array( 'WhatsAppChat', 'ChatAgent' ),
		'dnxte-next-faq'                => array( 'NextFAQ', 'NextFAQItem' ),
	);


	/**
	 * Class constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			array( $this, 'init_modules' )
		);
	}

	/**
	 * Initialize modules and add them to the dependency tree.
	 *
	 * @param object $dependency_tree The dependency tree object.
	 *
	 * @return void
	 */
	public function init_modules( $dependency_tree ) {
		$inactive_modules = get_option( 'dnxte_inactive_modules', array() );

		// NOTE: the WhatsApp Chat builder module is a self-contained Divi module
		// (its own Chat Agent CHILD module, not the centralised Chat Agents CPT),
		// so it is gated ONLY by its own module toggle here — independent of the
		// "WhatsApp Chat" EXTENSION switch (which gates the hub menu / floating
		// widget / WooCommerce button). Extension on/off ≠ module on/off.
		foreach ( $this->module_mapping as $module_key => $module_value ) {
			if ( in_array( $module_key, $inactive_modules, true ) ) {
				continue;
			}
			if ( is_array( $module_value ) ) {
				foreach ( $module_value as $class_name ) {
					$class_name = '\\DNXTE\\Modules\\' . $class_name . '\\' . $class_name;
					if ( class_exists( $class_name ) ) {
						$dependency_tree->add_dependency( new $class_name() );
					}
				}
			} else {
				$class_name = '\\DNXTE\\Modules\\' . $module_value . '\\' . $module_value;
				if ( class_exists( $class_name ) ) {
					$dependency_tree->add_dependency( new $class_name() );
				}
			}
		}
	}
}

// Initialize the Modules class.
new Modules();
