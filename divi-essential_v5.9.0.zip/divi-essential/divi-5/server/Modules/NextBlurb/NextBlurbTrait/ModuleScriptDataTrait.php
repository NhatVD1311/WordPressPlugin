<?php
/**
 * NextBlurb::module_script_data()
 *
 * @package MEE\Modules\NextBlurb
 * @since ??
 */

namespace DNXTE\Modules\NextBlurb\NextBlurbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;
use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		// Assign variables.
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		// Module decoration attributes.
		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		// Element Script Data Options.
		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setContent'    => [
					[
						'selector'      => $selector . ' .example_static_module__title',
						'data'          => $attrs['title']['innerContent'] ?? [],
						'valueResolver' => function( $value ) {
							return $value ?? '';
						},
					],
					[
						'selector'      => $selector . ' .example_static_module__content',
						'data'          => $attrs['content']['innerContent'] ?? [],
						'valueResolver' => function( $value ) {
							return $value ?? '';
						},
						'sanitizer'     => 'et_core_esc_previously',
					],
							[
							'selector'      => $selector . ' .dnxt-blurb-icon span',
							'data'          => $attrs['icon']['innerContent'] ?? [],
							'valueResolver' => function ( $value ) {
								return Utils::process_font_icon( $value ) ?? '';
							},
						],
				],
				'setAttrs'      => [
					[
						'selector'      => $selector . ' .example_static_module__image img',
						'data'          => [
							'src' => $attrs['image']['innerContent'] ?? [],
						],
						'valueResolver' => function( $value ) {
							return $value['src'] ?? '';
						},
						'tag'           => 'img',
					],
				],
			]
		);
		wp_enqueue_script('divi-essential-modules-vanilla-tilt');

		// The Spotlight effect uses the shared spotlight-card engine. Enqueue it
		// here when this Blurb uses it, so it works on the front end independently
		// of the Section/Row Spotlight extension's on/off toggle. (Handles are
		// registered in includes/Frontend/Assets.php.)
		if ( 'on' === ( $attrs['spotlight_settings']['advanced']['use_spotlight']['desktop']['value'] ?? '' ) ) {
			wp_enqueue_style( 'spotlight_css' );
			wp_enqueue_script( 'dnxte_spotlight_card_effects' );
		}

		// Ensure this module's frontend CSS loads even when the wp_enqueue_scripts
		// content-scanner in divi-5.php misses the block — e.g. the Blurb module
		// lives inside a Theme Builder layout, a global/library module, a synced
		// pattern, or loop-builder output, none of which are visible to a regex on
		// the current post's `post_content`. Without NextBlurb.css the static layout
		// rules (e.g. `span.dnxt-blurb-post-heading { display: inherit }`, which makes
		// the inline heading span block-level so its generated `text-align` actually
		// takes effect) are absent on the front end, so alignments set in the builder
		// silently do nothing. Uses the SAME handle the scanner uses
		// (`dnxte-divi5-module-nextblurb`) so WordPress de-duplicates: a no-op when the
		// scanner already enqueued it in <head>, otherwise it loads here.
		if ( \defined( 'DIVI_ESSENTIAL_PATH' ) && \defined( 'DIVI_ESSENTIAL_URL' ) ) {
			$blurb_css_handle = 'dnxte-divi5-module-nextblurb';
			$blurb_css_path   = DIVI_ESSENTIAL_PATH . '/divi-5/styles/module-styles/NextBlurb.css';

			if ( file_exists( $blurb_css_path ) && ! wp_style_is( $blurb_css_handle, 'enqueued' ) ) {
				wp_enqueue_style(
					$blurb_css_handle,
					DIVI_ESSENTIAL_URL . 'divi-5/styles/module-styles/NextBlurb.css',
					[],
					filemtime( $blurb_css_path )
				);
			}
		}
	}
}
