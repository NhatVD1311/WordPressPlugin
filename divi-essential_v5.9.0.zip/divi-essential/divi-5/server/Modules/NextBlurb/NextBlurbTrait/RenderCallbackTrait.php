<?php
/**
 * NextBlurb::render_callback()
 *
 * @package MEE\Modules\NextBlurb
 * @since ??
 */

namespace DNXTE\Modules\NextBlurb\NextBlurbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\NextBlurb\NextBlurb;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DNXTE\Modules\Utils\CardEffectsUtils;

trait RenderCallbackTrait {

	/**
	 * Static module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param WP_Block       $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Static module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

// heading tags 
$pre_heading_tag = $attrs['pre_heading']['advanced']['tag']['desktop']['value'] ?? 'span';
$title_heading_tag = $attrs['title']['advanced']['tag']['desktop']['value'] ?? 'h2';
$post_heading_tag = $attrs['post_heading']['advanced']['tag']['desktop']['value'] ?? 'span';
$pre_headong_content = $attrs['pre_heading']['innerContent']['desktop']['value'] ?? '';
$title_content = $attrs['title']['innerContent']['desktop']['value'] ?? '';
$post_heading_content = $attrs['post_heading']['innerContent']['desktop']['value'] ?? '';


		// Image.
		$image_src = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';
		$image_alt = $attrs['image']['innerContent']['desktop']['value']['alt'] ?? '';
		$image_placement = $attrs['image']['advanced']['placement']['desktop']['value'] ?? '';
		$image_pacement_tablet= $attrs['image']['advanced']['placement']['tablet']['value'] ?? '';
		$image_pacement_mobile= $attrs['image']['advanced']['placement']['phone']['value'] ?? '';

		// icon
		$icon_placement = $attrs['icon']['advanced']['placement']['desktop']['value'] ?? '';
		$use_icon = $attrs['title']['advanced']['useIcon']['desktop']['value'] ?? '';
		$icon_value = $attrs['icon']['innerContent']['desktop']['value']  ?? [];

		// boxwrapper 
		$hover_animation = $attrs['box_wrapper']['decoration']['hoverEffect2D']['desktop']['value'] ?? '';
		$enable_hover_animation = $attrs['box_wrapper']['advanced']['enabelHoverEffect']['desktop']['value'] ?? '';
		$animation_class = $enable_hover_animation === 'on' ? $hover_animation : '';
		// all tilt 

		$tilt_reverse = $attrs['box_wrapper']['advanced']['tilt_reverse']['desktop']['value'] ?? '';
		$tilt_max = $attrs['box_wrapper']['advanced']['tilt_max']['desktop']['value'] ?? '';
		$tilt_speed = $attrs['box_wrapper']['advanced']['tilt_speed']['desktop']['value'] ?? '';
		$tilt_startX = $attrs['box_wrapper']['advanced']['tilt_startX']['desktop']['value'] ?? '';
		$tilt_startY = $attrs['box_wrapper']['advanced']['tilt_startY']['desktop']['value'] ?? '';
		$tilt_scale = $attrs['box_wrapper']['advanced']['tilt_scale']['desktop']['value'] ?? '';
		$tilt_perspective = $attrs['box_wrapper']['advanced']['tilt_perspective']['desktop']['value'] ?? '';
		$glare_switch = $attrs['box_wrapper']['advanced']['enableGlare']['desktop']['value'] ?? '';
		$tilt_enable_switch = $attrs['box_wrapper']['advanced']['titlEffectEnable']['desktop']['value'] ?? '';
		$data_tilt =  $tilt_enable_switch === 'on' ? 'data-tilt' : '';

		$max_glare = $attrs['box_wrapper']['advanced']['maxGlare']['desktop']['value'] ?? '0.8';

// button icon
$button_content = $attrs['link']['innerContent']['desktop']['value'] ?? '';
$button_href = $attrs['link']['advanced']['linkGroup']['desktop']['value'] ?? '';
$button_icon_value = $attrs['button_icon']['innerContent']['desktop']['value']  ?? [];
$show_button_icon = $attrs['button_icon']['advanced']['useIcon']['desktop']['value'] ?? '';
$only_show_hover = $attrs['button_icon']['advanced']['showonHover']['desktop']['value'] ?? '';
$button_icon_placement = $attrs['button_icon']['advanced']['placement']['desktop']['value'] ?? '';

// badge
$use_badge = $attrs['badge']['advanced']['useBadge']['desktop']['value'] ?? '';
$badge_text = $attrs['badge']['innerContent']['desktop']['value'] ?? 'New';


$button_left_content = '';
$button_right_content = '';

$button_2d_hover_effect = $attrs['button_icon']['advanced']['hoverEffect']['desktop']['value'] ?? '';
$button_bgHover_Style = $attrs['button_icon']['advanced']['bghoverEffect']['desktop']['value'] ?? '';
$button_icon_hover_effect = $attrs['button_icon']['advanced']['hoverEffect2']['desktop']['value'] ?? '';
$button_stroke_hover_effect = $attrs['button_icon']['advanced']['strokeEffect']['desktop']['value'] ?? '';

// spotlight card 
$spotlight_color = $attrs['spotlight_settings']['decoration']['color']['desktop']['value'] ?? '';
$spotlight_color2 = $attrs['spotlight_settings']['decoration']['color2']['desktop']['value'] ?? '';
$spotlight_variant = $attrs['spotlight_settings']['advanced']['variant']['desktop']['value'] ?? '';
$spotlight_autoplay = $attrs['spotlight_settings']['advanced']['autoplay']['desktop']['value'] ?? '';
$spotlight_size = $attrs['spotlight_settings']['advanced']['spotlightSize']['desktop']['value'] ?? '';
$spotlight_intensity = $attrs['spotlight_settings']['advanced']['intensity']['desktop']['value'] ?? '';
$spotlight_speed = $attrs['spotlight_settings']['advanced']['speed']['desktop']['value'] ?? '';
$spotlight_animationType = $attrs['spotlight_settings']['advanced']['autoplay_animation']['desktop']['value'] ?? '';
$spotlight_mode = $attrs['spotlight_settings']['advanced']['mode']['desktop']['value'] ?? '';
$use_spotlight = $attrs['spotlight_settings']['advanced']['use_spotlight']['desktop']['value'] ?? '';

$tilt = array();
if ( 'on' === $tilt_enable_switch ) {
    $tilt = array(
        'data-tilt'             => '',
        'data-tilt-reverse'     => $tilt_reverse === 'on' ? 'true' : 'false',
        'data-tilt-perspective' => intval( $tilt_perspective ),
        'data-tilt-max'         => intval( $tilt_max ),
        'data-tilt-speed'       => intval( $tilt_speed ),
        'data-tilt-startX'      => intval( $tilt_startX ),
        'data-tilt-startY'      => intval( $tilt_startY ),
        'data-tilt-scale'       => $tilt_scale,
        'data-tilt-gyroscope'   => 'true',
    );

    if ( 'on' === $glare_switch ) {
        $tilt['data-tilt-glare'] = '';
        $tilt['data-tilt-max-glare'] = $max_glare ?? '0.8';
    }
}



$spotlight = array();
if ($use_spotlight === 'on' ) {
    $spotlight = array(
        'data-spotlight-card'           => '',
        'data-spotlight-color'          =>  $spotlight_color,
				'data-spotlight-gradient-colors' =>"$spotlight_color, $spotlight_color2",
        'data-spotlight-size'           => $spotlight_size,
        'data-spotlight-intensity'      => $spotlight_intensity,
        'data-spotlight-variant'        => $spotlight_variant,
         'data-spotlight-mode'           =>  $spotlight_mode,
        // 'data-spotlight-disabled'       => 'false',
				'data-spotlight-autoplay'      => $spotlight_autoplay === 'on' ? 'true' : 'false',
				// 'data-spotlight-autoplay-type'  =>  $spotlight_animationType,
				// 'data-spotlight-autoplay-speed' => $spotlight_speed,
    );

    if ( $spotlight_autoplay === 'on'  ) {
        $spotlight['data-spotlight-autoplay-type']  = $spotlight_animationType ?? 'circle';
        $spotlight['data-spotlight-autoplay-speed'] = ! empty( $spotlight_speed ) ? intval( $spotlight_speed ) : 3000;
    }
}

	// Card Effects
$card_effects = CardEffectsUtils::get_card_effects_attrs( $attrs );
$card_effects_styles = CardEffectsUtils::get_card_effects_styles( $attrs );



$button_icon       = $show_button_icon === 'on' ? HTMLUtility::render(
			[
				'tag'               => 'i',
						'attributes'        => [
							'class' => '',
							],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          =>  Utils::process_font_icon( $button_icon_value),
			],
		): '';

$button_right_content = $button_icon_placement === 'right' ? $button_icon : '';
$button_left_content = $button_icon_placement === 'left' ? $button_icon : '';


// icon class condition
$iconClassMap = [
    'dnxt-blurb-wrapper-two-top-left' => 'dnxt-blurb-icon-top-left',
    'dnxt-blurb-wrapper-two-top-center' => 'dnxt-blurb-icon-top-center',
    'dnxt-blurb-wrapper-two-top-right' => 'dnxt-blurb-icon-top-right',
    'dnxt-blurb-wrapper-two-left-top' => 'dnxt-blurb-icon-left-top',
    'dnxt-blurb-wrapper-two-left-center' => 'dnxt-blurb-icon-left-center',
    'dnxt-blurb-wrapper-two-left-bottom' => 'dnxt-blurb-icon-left-bottom',
    'dnxt-blurb-wrapper-two-right-top' => 'dnxt-blurb-icon-right-top',
    'dnxt-blurb-wrapper-two-right-center' => 'dnxt-blurb-icon-right-center',
    'dnxt-blurb-wrapper-two-right-bottom' => 'dnxt-blurb-icon-right-bottom',
    'dnxt-blurb-wrapper-two-bottom-center' => 'dnxt-blurb-icon-bottom-center',
    'dnxt-blurb-wrapper-two-bottom-right' => 'dnxt-blurb-icon-bottom-right',
];
		$icon       = $use_icon === 'on' ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxt-blurb-icon '.($iconClassMap[$icon_placement] ?? ''),
					'html'  => $icon_value,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>  HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [
							'class' => 'et-pb-icon',
							],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          =>  Utils::process_font_icon( $icon_value ),
					]
				),
			],
		): '';

	
		// Image container with hover support.
		$image_classes = 'dnxt-blurb-image dnxt-blurb-image_image_placement_' . $image_placement;
		if ( ! empty( $image_pacement_tablet ) ) {
			$image_classes .= ' dnxt-blurb-image_image_placement_tablet_' . $image_pacement_tablet;
		}
		if ( ! empty( $image_pacement_mobile ) ) {
			$image_classes .= ' dnxt-blurb-image_image_placement_phone_' . $image_pacement_mobile;
		}

		$image_container = $image_src ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => $image_classes,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $elements->render(
					[
						'attrName' => 'image',
					]
				),
			]
		) : '';

		// Title.
		$pre_heading = !empty($pre_headong_content) ? HTMLUtility::render(
			[
				'tag' => $pre_heading_tag,
				'attributes' => [
					'class' => 'dnxt-blurb-pre-heading',	
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => $pre_headong_content,
			]
			) : '';
		$title  = !empty($title_content) ?  HtMLUtility::render(
			[
				'tag' => $title_heading_tag,
				'attributes' => [
					'class' => 'dnxt-blurb-heading',	
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => $title_content,

			]
		) : '';

		$post_heading = !empty($post_heading_content) ? HTMLUtility::render(
			[
				'tag' => $post_heading_tag,
				'attributes' => [
					'class' => 'dnxt-blurb-post-heading',	
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => $post_heading_content,
			]
		): '';

			$blurb_heading = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [
						'class' => 'dnxt-blurb-heading-wrapper',
						
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $pre_heading.$title.$post_heading,
				]
			);

			

		$button = $button_content !== '' ?   HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxt-button-wrapper',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>  HTMLUtility::render(
				[
					'tag' => 'a',
					'attributes' => [	
						'href' =>  !empty($button_href )? esc_url( $button_href['url'] ) : '#',
						'target' => !empty($button_href ) && isset($button_href['target']) ? '_blank' : '_self',
								
								'class' => HTMLUtility::classnames(
						[
							'dnxt-btn-icon dnxt-blurb-btn ' => true,
							'dnxt-btn-icon-on-hover' => $show_button_icon === 'on' &&   $only_show_hover !== 'on',
						"dnxt-hover-$button_2d_hover_effect" => !empty($button_2d_hover_effect) && $button_2d_hover_effect !== 'none',
						"$button_bgHover_Style" => !empty($button_bgHover_Style) && $button_bgHover_Style !== 'none',
						"$button_icon_hover_effect" => !empty($button_icon_hover_effect) && $button_icon_hover_effect !== 'none',
						"$button_stroke_hover_effect" => !empty($button_stroke_hover_effect) && $button_stroke_hover_effect !== 'none',
			
						]
					  ), 
					],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          =>$button_left_content. $button_content .$button_right_content
				]
			)
			]
			) : '';

		// Content.
		$content = $elements->render(
			[
				'attrName' => 'content',
			]
			);
		$blurb_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxt-blurb-container',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>   $blurb_heading .$content .$button,
			]
		);

		
		$inner_content = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => $use_icon === 'on' ?  $icon_placement : ''
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon.$blurb_container,
			]
			);

		$wrapper_classes = 'dnxt-blurb-wrapper dnxt-blurb-wrapper-one_image_placement_' . $image_placement;
		if ( ! empty( $image_pacement_tablet ) ) {
			$wrapper_classes .= ' dnxt-blurb-wrapper-one_image_placement_tablet_' . $image_pacement_tablet;
		}
		if ( ! empty( $image_pacement_mobile ) ) {
			$wrapper_classes .= ' dnxt-blurb-wrapper-one_image_placement_phone_' . $image_pacement_mobile;
		}

		$blurb_wrapper = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => $wrapper_classes,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $image_container . $inner_content,
			]
			);

		// Content container.
		$content_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => array_merge(
					[
						'class' => 'dnxt-blurb-wrapper-outer  ' .$animation_class,
						'style' => $card_effects_styles,
					
					],
					
					
					//lightning

					
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $blurb_wrapper,
			]
		);

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [ NextBlurb::class, 'module_classnames' ],
				'stylesComponent'     => [ NextBlurb::class, 'module_styles' ],
				'scriptDataComponent' => [ NextBlurb::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
								 'htmlAttrs' => array_merge(
							
is_array($tilt) ? $tilt : [],
					is_array($spotlight) ? $spotlight : [],
					 is_array( $card_effects ) ? $card_effects : [],

),
				'children'            => [
					ElementComponents::component(
						[
							'attrs'         => $attrs['module']['decoration'] ?? [],
							'id'            => $block->parsed_block['id'],

							// FE only.
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						]
					),
					$use_badge === 'on' ? HTMLUtility::render(
						[
							'tag'               => 'span',
							'attributes'        => [
								'class' => 'dnxte-blurb-badge',
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $badge_text,
						]
					) : '',
					HTMLUtility::render(
						[
							'tag'               => 'div',
							'attributes'        => [
								'class' => 'example_static_module__inner',

							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $content_container,
						]
					),
				],
			]
		);
	}
}
