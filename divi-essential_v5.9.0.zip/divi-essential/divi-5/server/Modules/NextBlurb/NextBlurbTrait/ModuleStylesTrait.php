<?php
/**
 * NextBlurb::module_styles().
 *
 * @package MEE\Modules\NextBlurb
 * @since ??
 */

namespace DNXTE\Modules\NextBlurb\NextBlurbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\NextBlurb\NextBlurb;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Static Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/static-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements  ModuleElements instance.
	 * }
	 */
	/**
 * Get gradient style string.
 *
 * @param array  $attrs       The attributes array.
 * @param string $gradientKey The key for the gradient configuration.
 * @return string Gradient style string.
 */
		public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
					'font-weight' => true,
				],
			]
		);


		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		if ( ! empty( $icon_attr['unicode'] ) ) {
			$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		}

		return $style_declarations->value();
	}

	public static function icon_on_hover_style_declaration( array $params ): string {
		$icon_attr = $params['attrValue'];

		$icon_placement = $icon_attr['icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['icon']['advanced']['onHover']['desktop']['value'] ?? 'on';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		if('on' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
		}
		if('off' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
		}
		if('on' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
		}
		if('off' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
		}

		

		return $style_declarations->value();
	}
public static  function get_gradient_style( $attrs, $gradientKey ) {
    // Fallbacks and extracting values
    $color1 = $attrs[$gradientKey]['decoration']['color1']['desktop']['value'] ?? '#444';
    $color2 = $attrs[$gradientKey]['decoration']['color2']['desktop']['value'] ?? '#000';
    $startPosition = $attrs[$gradientKey]['decoration']['start_position']['desktop']['value'] ?? '50%';
    $endPosition = $attrs[$gradientKey]['decoration']['end_position']['desktop']['value'] ?? '100%';
    $gradientType = $attrs[$gradientKey]['decoration']['gradient_type']['desktop']['value'] ?? '';
    $gradientDirection = $attrs[$gradientKey]['decoration']['direction']['desktop']['value'] ?? '';
    $radialDirection = $attrs[$gradientKey]['decoration']['radial_direction']['desktop']['value'] ?? '';

    // Determine gradient style
    if ( $gradientType === 'linear-gradient' ) {
        return "{$gradientType}({$gradientDirection}, {$color1} {$startPosition}, {$color2} {$endPosition})";
    } elseif ( $gradientType === 'radial-gradient' ) {
        return "{$gradientType}(circle at {$radialDirection}, {$color1} {$startPosition}, {$color2} {$endPosition})";
    }

    return '';
}

	public static function module_styles( $args ) {
		$attrs    = $args['attrs'] ?? [];
		$elements = $args['elements'];
		$settings = $args['settings'] ?? [];
		$order_class = $args['orderClass'];
		$image_styles = [];
		$description_styles = [];
		$heading_styles = [];
		$image_gradient_style = [];
		$icon_gradient_style = [];
		$link_gradient_style = [];
		$button_stoke_hoverCss =[];

		$image_placement = $attrs['image']['advanced']['placement']['desktop']['value'] ?? "";
		$image_z_index = $attrs['image']['advanced']['zIndex']['desktop']['value'] ?? "";
		$icon_z_index = $attrs['icon']['advanced']['zIndex']['desktop']['value'] ?? "";
		$heading_z_index = $attrs['desc_body']['decoration']['zIndex']['desktop']['value'] ?? "";
		$btn_z_index = $attrs['link']['decoration']['zIndex']['desktop']['value'] ?? "";

		// remove px form $image_z_index if have px  or % or any other thing 
		$image_z_index = preg_replace('/(\d+)(px|%)/', '$1', $image_z_index);
		$icon_z_index = preg_replace('/(\d+)(px|%)/', '$1', $icon_z_index);
		$heading_z_index = preg_replace('/(\d+)(px|%)/', '$1', $heading_z_index);
		$btn_z_index = preg_replace('/(\d+)(px|%)/', '$1', $btn_z_index);

		// gradient 

		$desc_gradient_switch = $attrs['description_gradient']['decoration']['use_gradient']['desktop']['value'] ?? "";
		$desc_gradient_color =  self::get_gradient_style($attrs, 'description_gradient');
		$heading_gradient_switch = $attrs['heading_gradient']['decoration']['use_gradient']['desktop']['value'] ?? "";
		$heading_gradient_color =  self::get_gradient_style($attrs, 'heading_gradient');

		$image_gr_switch = $attrs['image_gradient']['decoration']['use_gradient']['desktop']['value'] ?? "";
		$image_gradient_color =  self::get_gradient_style($attrs, 'image_gradient');
		$link_gr_switch = $attrs['link']['decoration']['use_gradient']['desktop']['value'] ?? "";
		$link_gradient_color =  self::get_gradient_style($attrs, 'link');
		
		$icon_gr_switch = $attrs['icon_gradient']['decoration']['use_gradient']['desktop']['value'] ?? "";
		$icon_gradient_color =  self::get_gradient_style($attrs, 'icon');


		// button icon 
		$show_button_icon = $attrs['button_icon']['advanced']['useIcon']['desktop']['value'] ?? '';
$only_show_hover = $attrs['button_icon']['advanced']['showonHover']['desktop']['value'] ?? '';
$button_icon_placement = $attrs['button_icon']['advanced']['placement']['desktop']['value'] ?? '';
$button_bgHover_Style = $attrs['button_icon']['advanced']['bghoverEffect']['desktop']['value'] ?? '';
$button_stroke_hover_effect = $attrs['button_icon']['advanced']['strokeEffect']['desktop']['value'] ?? '';


// image masking 
	$image_mask = $attrs['image_mask']['advanced']['useImageMask']['desktop']['value'] ?? '';
		$upload_mask = $attrs['image_mask']['advanced']['useUploadMask']['desktop']['value'] ?? '';
		$selected_shape = $attrs['image_mask']['decoration']['selectShape']['desktop']['value'] ?? '';
		$selected_shape_mask = DIVI_ESSENTIAL_URL . 'assets/images/shapes/' . $selected_shape . '.svg';
		$upload_image_mask = $attrs['image_mask']['innerContent']['mask_image']['desktop']['value']['src'] ?? '';

		// mask postion 
		$mask_attrX = $attrs['image_mask']['decoration']['imageHorizontalPosition'] ?? [];
		$mask_attrY = $attrs['image_mask']['decoration']['imageVerticalPosition'] ?? [];
		$combine_atrr = array_merge($mask_attrX, $mask_attrY);
		$mask_postionX = $attrs['image_mask']['decoration']['imageHorizontalPosition']['desktop']['value'] ?? '';
		$mask_postionY = $attrs['image_mask']['decoration']['imageVerticalPosition']['desktop']['value'] ?? '';


// buton conditon clsass 
$button_bgHover_StyleClass = $button_bgHover_Style === 'dnxt-hover-fade' ?  ".{$button_bgHover_Style}:hover": ".{$button_bgHover_Style}:before";

// button alognment 
$button_alignment = $attrs['link']['decoration']['font']['font']['desktop']['value']['textAlign'] ?? '';

		if(
			str_starts_with( $image_placement, "left" )
			|| str_starts_with( $image_placement, "right" )
		){
			$image_styles = [
				
					
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image",
							'attr'     =>$attrs['image']['advanced']['placement'] ?? [],
							 'property' =>"width: auto;"
							
						]
						),
				
			];
		}
	if($desc_gradient_switch === 'on'){
	$description_styles= [
			CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-container",
							'attr'     => $attrs['description_gradient']['decoration']['color1'] ?? [],
							 'property' =>"background: {$desc_gradient_color};"
							
						]
						),
	]; 
	
	}

	if($heading_gradient_switch === 'on'){
	$heading_styles= [
			CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-heading-wrapper",
							'attr'     => $attrs['heading_gradient']['decoration']['color1'] ?? [],
							 'property' =>"background: {$heading_gradient_color};"
							
						]
						),
	]; 
	
	}

	if($image_gr_switch === 'on'){
	$image_gradient_style= [
			CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image",
							'attr'     => $attrs['image_gradient']['decoration']['color1'] ?? [],
							 'property' =>"background: {$image_gradient_color};"
							
						]
						),
	]; 
	
	}

	if($icon_gr_switch === 'on'){
	$icon_gradient_style= [
			CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-icon span",
							'attr'     => $attrs['icon']['decoration']['color1'] ?? [],
							 'property' =>"background: {$icon_gradient_color};"
							
						]
						),
	]; 
	
	}

	if($link_gr_switch === 'on'){
	$link_gradient_style= [
			CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-btn",
							'attr'     => $attrs['link']['decoration']['color1'] ?? [],
							 'property' =>"background: {$link_gradient_color};"

						]
			)
						];
	
	}

	// button stroke css 
	if(
	$button_stroke_hover_effect === 'dnxt-hover-trim' ||
	$button_stroke_hover_effect === 'dnxt-hover-ripple-out' ||
	$button_stroke_hover_effect === 'dnxt-hover-ripple-in' ||
	$button_stroke_hover_effect === 'dnxt-hover-reveal' 
	
	) {

		$button_stoke_hoverCss = [
			CommonStyle::style(
				[
					'selector' => "{$order_class} .$button_stroke_hover_effect:before",
					'attr'     => $attrs['button_icon']['advanced']['borderbgcolor'] ?? [],
					'property' => "border-color",
				]
			)
		];

	} else {
	$button_stoke_hoverCss = [
			CommonStyle::style(
				[
					'selector' => "{$order_class} .$button_stroke_hover_effect:before",
					'attr'     => $attrs['button_icon']['advanced']['borderbgcolor'] ?? [],
					'property' => "background",
				]
			)
		];
	}



	// button hover effect bg color
	// Button hover effect variables
$button_bg_color_hover_effect = $attrs['button_icon']['advanced']['bgcolor']['desktop']['value'] ?? '';
$button_bg_solid_color = $attrs['button_icon']['advanced']['bgSolidcolor']['desktop']['value'] ?? '';

// bgEffectsClass array
$bg_effects_class = [
    "dnxt-hover-radial-in",
    "dnxt-hover-rectangle-in",
    "dnxt-hover-rectangle-out",
    "dnxt-hover-shutter-in-horizontal",
    "dnxt-hover-shutter-out-horizontal",
    "dnxt-hover-shutter-in-vertical",
    "dnxt-hover-shutter-out-vertical",
];

$hover_bg_color = in_array($button_bgHover_Style, $bg_effects_class);

$button_hover_bg_css = [];

// hoverBgColor !== true (when NOT in bgEffectsClass)
if (!$hover_bg_color) {
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .dnxt-btn-icon.{$button_bgHover_Style}:before, {$order_class} .dnxt-btn-icon.dnxt-hover-fade:hover",
            'declaration' => "background: {$button_bg_color_hover_effect} !important",
        ];
    }
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .dnxt-btn-icon.{$button_bgHover_Style}, {$order_class} .dnxt-btn-icon.dnxt-hover-fade",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
}

// dnxt-hover-fade
if ($button_bgHover_Style === 'dnxt-hover-fade') {
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .dnxt-btn-icon.dnxt-hover-fade:before",
            'declaration' => "background: {$button_bg_color_hover_effect} !important",
        ];
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .dnxt-btn-icon.dnxt-hover-fade:hover",
            'declaration' => "background: {$button_bg_color_hover_effect} !important",
        ];
    }
}

// dnxt-hover-radial-in
if ($button_bgHover_Style === 'dnxt-hover-radial-in') {
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_solid_color} !important",
        ];
    }
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background-color: {$button_bg_color_hover_effect} !important",
        ];
    }
}

// dnxt-hover-rectangle-in
if ($button_bgHover_Style === 'dnxt-hover-rectangle-in') {
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
}

// dnxt-hover-rectangle-out
if ($button_bgHover_Style === 'dnxt-hover-rectangle-out') {
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
}

// dnxt-hover-shutter-in-horizontal
if ($button_bgHover_Style === 'dnxt-hover-shutter-in-horizontal') {
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
}

// dnxt-hover-shutter-out-horizontal
if ($button_bgHover_Style === 'dnxt-hover-shutter-out-horizontal') {
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
}

// dnxt-hover-shutter-in-vertical
if ($button_bgHover_Style === 'dnxt-hover-shutter-in-vertical') {
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
}

// dnxt-hover-shutter-out-vertical
if ($button_bgHover_Style === 'dnxt-hover-shutter-out-vertical') {
    if (!empty($button_bg_solid_color)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}",
            'declaration' => "background: {$button_bg_solid_color}",
        ];
    }
    if (!empty($button_bg_color_hover_effect)) {
        $button_hover_bg_css[] = [
            'atRules'     => false,
            'selector'    => "{$order_class} .{$button_bgHover_Style}:before",
            'declaration' => "background: {$button_bg_color_hover_effect}",
        ];
    }
}

	// button icon hover color
	$button_icon_hover_color = $attrs['button_icon']['advanced']['color']['desktop']['hover'] ?? '';
	$hover_icon_color_css = [];
	// cehck if not empty
	if(!empty($button_icon_hover_color)) {
		$hover_icon_color_css[] = [
				'atRules'     => false,
					'selector' => "{$order_class} .dnxt-btn-icon:hover i",
					'declaration' => "color: $button_icon_hover_color !important",
				
		];
	}




		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn'     => [
									'selector'                 => "{$args['orderClass']}.dnxte_next_blurb",
									'important'                => true,
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									[
										'componentName' => 'divi/text',
										'props'         => [
											'selector' => "{$args['orderClass']} .example_static_module__content-container",
											'attr'     => $attrs['module']['advanced']['text'] ?? [],
										]
									]
								]
							],
						]
					),

					// Image.
					$elements->style(
						[
							'attrName' => 'image_wrapper',
							'styleProps' => [
								'advancedStyles' => [
								
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['image_wrapper']['decoration']['width'] ?? [],
											'property' => 'max-width',
										]
									],
								
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'image',
						]
					),

					// Title.
					$elements->style(
						[
							'attrName' => 'pre_heading',
						]
					),
					$elements->style(
						[
							'attrName' => 'title',
						]
					),
					
						$elements->style(
						[
							'attrName' => 'post_heading',
						]
					),
					// Content.
					$elements->style(
						[
							'attrName' => 'content',
						]
					),
					$elements->style(
						[
							'attrName' => 'link',
						]
					),
			$elements->style(
						[
							'attrName' => 'desc_body',
							'styleProps' => [
								'advancedStyles' => [
								
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['desc_body']['decoration']['width'] ?? [],
											'property' => 'max-width',
										]
									],
								
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'heading_gradient',
						]
					),
					$elements->style(
						[
							'attrName' => 'description_gradient',
						]
					),

						$elements->style(
						[
							'attrName' => 'image_gradient',
						]
					),
						$elements->style(
						[
							'attrName' => 'icon_gradient',
						]
					),
						$elements->style(
						[
							'attrName'   => 'icon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['innerContent']?? [],
											'declarationFunction' => [ self::class, 'icon_style_declaration' ],
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['innerContent'] ?? [],
											'declarationFunction' => [ self::class, 'icon_on_hover_style_declaration' ],
										],
									],
								
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['color'] ?? [],
											'property' => 'color',
											
										]
									],
									
								
								]
							]
						]
					),
					$elements->style(
						[
							'attrName'   => 'button_icon',
							'styleProps' => [
								'advancedStyles' => [
								
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['button_icon']['advanced']['color'] ?? [],
											'property' => 'color',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['button_icon']['innerContent']?? [],
											'declarationFunction' => [ self::class, 'icon_style_declaration' ],
										],
									],
									
								
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'badge',
						]
					),

					// Badge position styles
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-blurb-badge",
							'attr'     => $attrs['badge']['advanced']['positionVertical'] ?? [],
							'property' => 'top',
						]
					),
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-blurb-badge",
							'attr'     => $attrs['badge']['advanced']['positionHorizontal'] ?? [],
							'property' => 'right',
						]
					),

					//common style
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-icon span",
							'attr'     => $attrs['icon']['advanced']['size'] ?? [],
							 'property' =>"font-size"
							
						]
						),
						...$image_styles,
						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image img",
							'attr'     => $attrs['image']['advanced']['zIndex'] ?? [],
							 'property' =>"position: relative;z-index: {$image_z_index};"
							
						]
						),

						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-icon",
							'attr'     => $attrs['icon']['advanced']['zIndex'] ?? [],
							 'property' =>" position: relative; z-index: {$icon_z_index};"
							
						]
						),

						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-heading-wrapper",
							'attr'     => $attrs['desc_body']['decoration']['zIndex'] ?? [],
							 'property' =>" position: relative; z-index: {$heading_z_index};"
							
						]
						),

							CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-btn",
							'attr'     => $attrs['link']['decoration']['zIndex'] ?? [],
							 'property' =>" position: relative;z-index: {$btn_z_index} !important;",
							
						]
						),
						...	$icon_gradient_style,
						...$image_gradient_style,
						...$heading_styles,
						...$description_styles,
						...$link_gradient_style,

						// buton icon style 
							CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon:hover i",
							'attr'     => $attrs['button_icon']['advanced']['showonHover'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover === 'on') ? 'opacity: 1;visibility: visible;' : '',
							
						]
						),
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon.dnxt-btn-icon-on-hover i",
							'attr'     => $attrs['button_icon']['advanced']['showonHover'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover !== 'on') ? 'opacity: 1;visibility: visible;' : '',
							
						]
						),

					// buton icon css by it's placement 
						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon:hover i",
							'attr'     => $attrs['button_icon']['advanced']['placement'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover === 'on' && $button_icon_placement === 'right') ? 'margin-left: 0;padding-left: 0.4em;' : '',
							
						]
						),
							CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon:hover i",
							'attr'     => $attrs['button_icon']['advanced']['placement'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover === 'on' && $button_icon_placement === 'left') ? 'padding-right: 0.4em;margin-left: 0;' : '',
							
						]
						),
						// ico placement not in hover 
						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon.dnxt-btn-icon-on-hover i",
							'attr'     => $attrs['button_icon']['advanced']['placement'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover !== 'on' && $button_icon_placement === 'left') ? 'margin-left: 0;padding-right: 0.4em;' : '',
							
						]
						),

						CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-btn-icon.dnxt-btn-icon-on-hover i",
							'attr'     => $attrs['button_icon']['advanced']['placement'] ?? [],
							'property' => ($show_button_icon === 'on' && $only_show_hover !== 'on' && $button_icon_placement === 'right') ? 'margin-left: 0;padding-left: 0.4em;' : '',
							
						]
						),
						// button hover effect bg color

						// CommonStyle::style(
						// [
						// 	'selector' => "{$order_class} $button_bgHover_StyleClass",
						// 	'attr'     => $attrs['button_icon']['advanced']['bgcolor'] ?? [],
						// 	'property' => "background"
							
						// ]
						// ),
						
							CommonStyle::style(
						[
							'selector' => "{$order_class} .{$button_bgHover_Style}",
							'attr'     => $attrs['button_icon']['advanced']['bgSolidcolor'] ?? [],
						
							'property' => "background"
							
						]
						),
						// buttob stroke bg
						...$button_stoke_hoverCss,
						CommonStyle::style(
									[
										'selector' => "{$order_class} .$button_stroke_hover_effect",
										'attr'     => $attrs['button_icon']['advanced']['strokebgcolor'] ?? [],
										'property' => "background",
									]
						),
						

				// masking css 

				CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image",
							'attr'     => $attrs['image_mask']['decoration']['selectShape'] ?? [],
							'property' => ($image_mask === 'on' && $upload_mask !== 'on') ? "mask-image:url($selected_shape_mask);" : "",
							
						]
						),

					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image",
							'attr'     => $attrs['image_mask']['decoration']['selectShape'] ?? [],
							'property' => ($upload_mask === 'on' && $image_mask !== 'on') ? "mask-image:url($upload_image_mask);" : "",
							
						]
						),
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxt-blurb-image",
							'attr'     => $combine_atrr   ?? [],
							'property' => ($upload_mask === 'on' || $image_mask === 'on') ?"mask-position:{$mask_postionX} {$mask_postionY};" : "",
							
						]
						),
					/*
					 * We need to add CssStyle at the very bottom of other
					 * components so that custom css can override module styles
					 * till we find a more elegant solution.
					 */
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => NextBlurb::custom_css(),
						]
					),
					

			
					[
						[
							'atRules'     => false,
							'selector'    => "{$order_class} .dnxt-button-wrapper",
							'declaration' => $button_alignment !== '' ? "text-align:{$button_alignment};" : ""
						],
						...$button_hover_bg_css,
						...$hover_icon_color_css 
					],
				],
			],
			
		);
	}
}
