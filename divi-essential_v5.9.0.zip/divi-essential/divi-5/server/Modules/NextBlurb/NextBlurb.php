<?php
/**
 * Module: Static Module class.
 *
 * @package MEE\Modules\NextBlurb
 * @since ??
 */

namespace DNXTE\Modules\NextBlurb;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;


/**
 * `NextBlurb` is consisted of functions used for Static Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextBlurb implements DependencyInterface {
	use NextBlurbTrait\RenderCallbackTrait;
	use NextBlurbTrait\ModuleClassnamesTrait;
	use NextBlurbTrait\ModuleStylesTrait;
	use NextBlurbTrait\ModuleScriptDataTrait;

	/**
	 * Loads `NextBlurb` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path =  DIVI_ESSENTIAL_MODULES_JSON_PATH   . 'NextBlurb/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextBlurb::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
