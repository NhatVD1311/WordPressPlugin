<?php
/**
 * Module: NextChart class.
 *
 * @package DNXTE\Modules\NextChart
 * @since ??
 */

namespace DNXTE\Modules\NextChart;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class NextChart implements DependencyInterface {
	use NextChartTrait\RenderCallbackTrait;

	/**
	 * Loads NextChart and registers Front-End render callback.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextChart/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextChart::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
