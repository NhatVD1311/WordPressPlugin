<?php
/**
 * NextChart::module_styles().
 *
 * @package DNXTE\Modules\NextChart
 * @since ??
 */

namespace DNXTE\Modules\NextChart\NextChartTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Module styles.
	 *
	 * @since ??
	 *
	 * @param array $args An array of arguments.
	 */
	public static function module_styles( $args ) {
		$attrs    = $args['attrs'] ?? [];
		$elements = $args['elements'];
		$settings = $args['settings'] ?? [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					// Chart Wrapper.
					$elements->style(
						[
							'attrName' => 'chartWrapper',
									'styleProps' => [
								'advancedStyles' => [
								
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['chartWrapper']['advanced']['chartHeight'] ?? [],
											'property' => 'height',
										]
									],
								
								]
							]
						]
					),
					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}

}
