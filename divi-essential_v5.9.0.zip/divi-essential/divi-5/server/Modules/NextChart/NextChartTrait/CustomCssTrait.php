<?php
/**
 * NextChart::custom_css().
 *
 * @package DNXTE\Modules\NextChart
 * @since ??
 */

namespace DNXTE\Modules\NextChart\NextChartTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/next-chart' )->customCssFields;
	}

}
