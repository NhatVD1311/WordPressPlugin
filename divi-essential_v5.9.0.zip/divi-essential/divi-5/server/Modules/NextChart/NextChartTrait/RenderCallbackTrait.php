<?php
/**
 * NextChart::render_callback()
 *
 * @package DNXTE\Modules\NextChart
 * @since ??
 */

namespace DNXTE\Modules\NextChart\NextChartTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\NextChart\NextChart;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Default colors for datasets.
	 *
	 * @var array
	 */
	private static $default_colors = [
		[ 'bg' => 'rgba(54, 162, 235, 0.5)', 'border' => 'rgba(54, 162, 235, 1)' ],
		[ 'bg' => 'rgba(255, 99, 132, 0.5)', 'border' => 'rgba(255, 99, 132, 1)' ],
		[ 'bg' => 'rgba(75, 192, 192, 0.5)', 'border' => 'rgba(75, 192, 192, 1)' ],
		[ 'bg' => 'rgba(255, 206, 86, 0.5)', 'border' => 'rgba(255, 206, 86, 1)' ],
		[ 'bg' => 'rgba(153, 102, 255, 0.5)', 'border' => 'rgba(153, 102, 255, 1)' ],
		[ 'bg' => 'rgba(255, 159, 64, 0.5)', 'border' => 'rgba(255, 159, 64, 1)' ],
	];

	/**
	 * Parse comma-separated color palette string into array of { bg, border } entries.
	 * Falls back to default colors when empty.
	 *
	 * @since ??
	 *
	 * @param string $palette_str Comma-separated colors.
	 *
	 * @return array
	 */
	private static function parse_color_palette( $palette_str ) {
		if ( empty( $palette_str ) ) {
			return self::$default_colors;
		}

		$raw = array_filter( array_map( 'trim', explode( ',', $palette_str ) ) );

		if ( empty( $raw ) ) {
			return self::$default_colors;
		}

		return array_map(
			function( $color ) {
				return [ 'bg' => $color, 'border' => $color ];
			},
			array_values( $raw )
		);
	}

	/**
	 * Render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array     $attrs    Block attributes.
	 * @param string    $content  Block content.
	 * @param \WP_Block $block    Parsed block object.
	 * @param object    $elements ModuleElements instance.
	 *
	 * @return string HTML rendered output.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		// Data source.
		$data_source = $attrs['dataSource']['innerContent']['desktop']['value'] ?? 'manual';

		// Chart settings.
		$chart_type       = $attrs['chartSettings']['advanced']['chartType']['desktop']['value'] ?? 'bar';
		$responsive       = ( $attrs['chartSettings']['advanced']['responsive']['desktop']['value'] ?? 'on' ) === 'on';
		$maintain_ratio   = ( $attrs['chartSettings']['advanced']['maintainAspectRatio']['desktop']['value'] ?? 'on' ) === 'on';
		$animation_dur    = (int) ( $attrs['chartSettings']['advanced']['animationDuration']['desktop']['value'] ?? 1000 );
		$index_axis       = $attrs['chartSettings']['advanced']['indexAxis']['desktop']['value'] ?? 'x';

		// Title.
		$title_display     = ( $attrs['chartTitle']['advanced']['display']['desktop']['value'] ?? 'on' ) === 'on';
		$title_text        = $attrs['chartTitle']['advanced']['text']['desktop']['value'] ?? 'Chart Title';
		$title_position    = $attrs['chartTitle']['advanced']['position']['desktop']['value'] ?? 'top';
		$title_color       = $attrs['chartTitle']['advanced']['color']['desktop']['value'] ?? '#666666';
		$title_font_size   = (int) ( $attrs['chartTitle']['advanced']['fontSize']['desktop']['value'] ?? 16 );
		$title_font_weight = $attrs['chartTitle']['advanced']['fontWeight']['desktop']['value'] ?? 'bold';
		$title_align       = $attrs['chartTitle']['advanced']['align']['desktop']['value'] ?? 'center';
		$title_padding     = (int) ( $attrs['chartTitle']['advanced']['padding']['desktop']['value'] ?? 10 );

		// Legend.
		$legend_display   = ( $attrs['legend']['advanced']['display']['desktop']['value'] ?? 'on' ) === 'on';
		$legend_position  = $attrs['legend']['advanced']['position']['desktop']['value'] ?? 'top';
		$legend_color     = $attrs['legend']['advanced']['color']['desktop']['value'] ?? '#666666';
		$legend_font_size = (int) ( $attrs['legend']['advanced']['fontSize']['desktop']['value'] ?? 12 );
		$legend_box_width = (int) ( $attrs['legend']['advanced']['boxWidth']['desktop']['value'] ?? 40 );
		$legend_padding   = (int) ( $attrs['legend']['advanced']['padding']['desktop']['value'] ?? 10 );
		$legend_align     = $attrs['legend']['advanced']['align']['desktop']['value'] ?? 'center';

		// Tooltip.
		$tooltip_enabled       = ( $attrs['tooltip']['advanced']['enabled']['desktop']['value'] ?? 'on' ) === 'on';
		$tooltip_bg_color      = $attrs['tooltip']['advanced']['backgroundColor']['desktop']['value'] ?? 'rgba(0,0,0,0.8)';
		$tooltip_title_color   = $attrs['tooltip']['advanced']['titleColor']['desktop']['value'] ?? '#ffffff';
		$tooltip_body_color    = $attrs['tooltip']['advanced']['bodyColor']['desktop']['value'] ?? '#ffffff';
		$tooltip_font_size     = (int) ( $attrs['tooltip']['advanced']['fontSize']['desktop']['value'] ?? 12 );
		$tooltip_border_color  = $attrs['tooltip']['advanced']['borderColor']['desktop']['value'] ?? 'rgba(0,0,0,0)';
		$tooltip_border_width  = (int) ( $attrs['tooltip']['advanced']['borderWidth']['desktop']['value'] ?? 0 );
		$tooltip_corner_radius = (int) ( $attrs['tooltip']['advanced']['cornerRadius']['desktop']['value'] ?? 6 );
		$tooltip_padding       = (int) ( $attrs['tooltip']['advanced']['padding']['desktop']['value'] ?? 6 );

		// Axes.
		$axis_x_display = ( $attrs['axisX']['advanced']['display']['desktop']['value'] ?? 'on' ) === 'on';
		$axis_x_title   = $attrs['axisX']['advanced']['title']['desktop']['value'] ?? '';
		$axis_x_grid    = ( $attrs['axisX']['advanced']['gridDisplay']['desktop']['value'] ?? 'on' ) === 'on';
		$axis_y_display = ( $attrs['axisY']['advanced']['display']['desktop']['value'] ?? 'on' ) === 'on';
		$axis_y_title   = $attrs['axisY']['advanced']['title']['desktop']['value'] ?? '';
		$axis_y_grid    = ( $attrs['axisY']['advanced']['gridDisplay']['desktop']['value'] ?? 'on' ) === 'on';
		$axis_y_zero    = ( $attrs['axisY']['advanced']['beginAtZero']['desktop']['value'] ?? 'on' ) === 'on';

		// Color palette (for CSV/JSON modes).
		$palette_str   = $attrs['colorPalette']['innerContent']['desktop']['value'] ?? '';
		$custom_colors = self::parse_color_palette( $palette_str );

		// Build labels and datasets based on data source.
		$labels   = [];
		$datasets = [];

		switch ( $data_source ) {
			case 'csv':
				$csv_file = $attrs['csvFile']['innerContent']['desktop']['value'] ?? '';
				$chart_data = self::parse_chart_csv_file( $csv_file, $chart_type, $custom_colors );
				$labels   = $chart_data['labels'];
				$datasets = $chart_data['datasets'];
				break;

			case 'csv-paste':
				$csv_content = $attrs['csvData']['innerContent']['desktop']['value'] ?? '';
				$chart_data  = self::parse_chart_csv_content( $csv_content, $chart_type, $custom_colors );
				$labels   = $chart_data['labels'];
				$datasets = $chart_data['datasets'];
				break;

			case 'json':
				$json_str   = $attrs['jsonData']['innerContent']['desktop']['value'] ?? '';
				$chart_data = self::parse_chart_json_data( $json_str, $chart_type, $custom_colors );
				$labels   = $chart_data['labels'];
				$datasets = $chart_data['datasets'];
				break;

			case 'manual':
			default:
				$labels_str = $attrs['chartLabels']['innerContent']['desktop']['value'] ?? 'Jan,Feb,Mar,Apr,May,Jun';
				$labels     = array_map( 'trim', explode( ',', $labels_str ) );
				$datasets   = self::build_manual_datasets( $block, $chart_type );
				break;
		}

		// Fallback if no datasets.
		if ( empty( $datasets ) ) {
			$datasets[] = [
				'label'           => 'Dataset 1',
				'data'            => [ 12, 19, 3, 5, 2, 3 ],
				'backgroundColor' => self::$default_colors[0]['bg'],
				'borderColor'     => self::$default_colors[0]['border'],
				'borderWidth'     => 2,
			];
		}

		if ( empty( $labels ) ) {
			$labels = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun' ];
		}

		// Handle area type.
		$actual_chart_type = $chart_type;
		if ( 'area' === $chart_type ) {
			$actual_chart_type = 'line';
			foreach ( $datasets as &$ds ) {
				$ds['fill'] = true;
			}
			unset( $ds );
		}

		// Build Chart.js config.
		$chart_config = [
			'type' => $actual_chart_type,
			'data' => [
				'labels'   => $labels,
				'datasets' => $datasets,
			],
			'options' => [
				'responsive'          => $responsive,
				'maintainAspectRatio' => $maintain_ratio,
				'animation'           => [
					'duration' => $animation_dur,
				],
				'indexAxis' => $index_axis,
				'plugins'   => [
					'title'   => [
						'display'  => $title_display,
						'text'     => $title_text,
						'position' => $title_position,
						'color'    => $title_color,
						'font'     => [
							'size'   => $title_font_size,
							'weight' => $title_font_weight,
						],
						'align'    => $title_align,
						'padding'  => $title_padding,
					],
					'legend'  => [
						'display'  => $legend_display,
						'position' => $legend_position,
						'align'    => $legend_align,
						'labels'   => [
							'color'    => $legend_color,
							'font'     => [
								'size' => $legend_font_size,
							],
							'boxWidth' => $legend_box_width,
							'padding'  => $legend_padding,
						],
					],
					'tooltip' => [
						'enabled'         => $tooltip_enabled,
						'backgroundColor' => $tooltip_bg_color,
						'titleColor'      => $tooltip_title_color,
						'bodyColor'       => $tooltip_body_color,
						'titleFont'       => [
							'size' => $tooltip_font_size,
						],
						'bodyFont'        => [
							'size' => $tooltip_font_size,
						],
						'borderColor'     => $tooltip_border_color,
						'borderWidth'     => $tooltip_border_width,
						'cornerRadius'    => $tooltip_corner_radius,
						'padding'         => $tooltip_padding,
					],
				],
			],
		];

		$is_pie_type = in_array( $actual_chart_type, [ 'pie', 'doughnut', 'polarArea', 'radar' ], true );
		if ( ! $is_pie_type ) {
			$chart_config['options']['scales'] = [
				'x' => [
					'display' => $axis_x_display,
					'title'   => [
						'display' => ! empty( $axis_x_title ),
						'text'    => $axis_x_title,
					],
					'grid'    => [
						'display' => $axis_x_grid,
					],
				],
				'y' => [
					'display'    => $axis_y_display,
					'title'      => [
						'display' => ! empty( $axis_y_title ),
						'text'    => $axis_y_title,
					],
					'grid'       => [
						'display' => $axis_y_grid,
					],
					'beginAtZero' => $axis_y_zero,
				],
			];
		}

		$chart_json = wp_json_encode( $chart_config );

		$canvas = HTMLUtility::render(
			[
				'tag'        => 'canvas',
				'attributes' => [
					'data-chart-config' => $chart_json,
				],
			]
		);

		$chart_wrapper = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-chart-wrapper',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $canvas,
			]
		);

		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ NextChart::class, 'module_classnames' ],
				'scriptDataComponent' => [ NextChart::class, 'module_script_data' ],
				'stylesComponent'     => [ NextChart::class, 'module_styles' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $chart_wrapper,
				'childrenIds'         => $children_ids,
			]
		);
	}

	/**
	 * Build datasets from child blocks (manual mode).
	 *
	 * @since ??
	 *
	 * @param \WP_Block $block      Parsed block object.
	 * @param string    $chart_type Chart type.
	 *
	 * @return array
	 */
	private static function build_manual_datasets( $block, $chart_type ) {
		$datasets     = [];
		$inner_blocks = $block->parsed_block['innerBlocks'] ?? [];
		$is_pie_type  = in_array( $chart_type, [ 'pie', 'doughnut', 'polarArea', 'radar' ], true );

		foreach ( $inner_blocks as $index => $inner_block ) {
			$child_attrs   = $inner_block['attrs'] ?? [];
			$ds            = $child_attrs['datasetSettings']['advanced'] ?? [];
			$default_color = self::$default_colors[ $index % count( self::$default_colors ) ];

			$label       = $ds['label']['desktop']['value'] ?? 'Dataset ' . ( $index + 1 );
			$data_str    = $ds['data']['desktop']['value'] ?? '12,19,3,5,2,3';
			$data        = array_map( 'floatval', array_map( 'trim', explode( ',', $data_str ) ) );
			$bg_color    = $ds['backgroundColor']['desktop']['value'] ?? $default_color['bg'];
			$bdr_color   = $ds['borderColor']['desktop']['value'] ?? $default_color['border'];
			$bdr_width   = (int) ( $ds['borderWidth']['desktop']['value'] ?? 2 );
			$type        = $ds['type']['desktop']['value'] ?? 'inherit';
			$tension     = (float) ( $ds['tension']['desktop']['value'] ?? 0.4 );
			$fill        = ( $ds['fill']['desktop']['value'] ?? 'off' ) === 'on';
			$point_rad   = (int) ( $ds['pointRadius']['desktop']['value'] ?? 3 );
			$point_style = $ds['pointStyle']['desktop']['value'] ?? 'circle';

			$dataset = [
				'label'           => $label,
				'data'            => $data,
				'backgroundColor' => $bg_color,
				'borderColor'     => $bdr_color,
				'borderWidth'     => $bdr_width,
			];

			if ( 'inherit' !== $type ) {
				$dataset['type'] = $type;
			}

			if ( ! $is_pie_type ) {
				$dataset['tension']     = $tension;
				$dataset['fill']        = $fill;
				$dataset['pointRadius'] = $point_rad;
				$dataset['pointStyle']  = $point_style;
			}

			$datasets[] = $dataset;
		}

		return $datasets;
	}

	/**
	 * Parse a CSV file URL into chart labels and datasets.
	 *
	 * @since ??
	 *
	 * @param string $file_path CSV file URL.
	 * @param string $chart_type Chart type.
	 *
	 * @return array { labels: array, datasets: array }
	 */
	private static function parse_chart_csv_file( $file_path, $chart_type, $colors = null ) {
		$empty = [ 'labels' => [], 'datasets' => [] ];

		if ( empty( $file_path ) ) {
			return $empty;
		}

		// Resolve and confine to the uploads directory before opening anything. The
		// previous checks only rejected values that parsed as a URL, so a bare absolute
		// path such as /var/www/html/wp-config.php was passed straight to fopen().
		$file_path = \DNXTE\Shared\DataFilePath::resolve( $file_path, array( 'csv', 'txt' ), 'chart' );

		if ( '' === $file_path ) {
			return $empty;
		}

		$rows   = [];
		$handle = @fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( false !== $handle ) {
			while ( ( $row = fgetcsv( $handle, 0, ',', '"' ) ) !== false ) { // phpcs:ignore
				$rows[] = array_map( 'trim', $row );
			}
			fclose( $handle );
		}

		return self::csv_rows_to_chart_data( $rows, $chart_type, $colors );
	}

	/**
	 * Parse CSV content string into chart labels and datasets.
	 *
	 * @since ??
	 *
	 * @param string $csv_content CSV text content.
	 * @param string $chart_type  Chart type.
	 *
	 * @return array { labels: array, datasets: array }
	 */
	private static function parse_chart_csv_content( $csv_content, $chart_type, $colors = null ) {
		if ( empty( $csv_content ) ) {
			return [ 'labels' => [], 'datasets' => [] ];
		}

		$rows  = [];
		$lines = explode( "\n", str_replace( "\r", '', $csv_content ) );

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( empty( $line ) ) {
				continue;
			}
			$row = str_getcsv( $line, ',', '"' );
			if ( ! empty( $row ) ) {
				$rows[] = array_map( 'trim', $row );
			}
		}

		return self::csv_rows_to_chart_data( $rows, $chart_type, $colors );
	}

	/**
	 * Convert 2D CSV rows into chart labels and datasets.
	 * Row 0 = headers (first cell ignored, rest = dataset labels).
	 * Column 0 = chart labels.
	 * Remaining cells = numeric data.
	 *
	 * @since ??
	 *
	 * @param array  $rows       2D array of CSV data.
	 * @param string $chart_type Chart type.
	 *
	 * @return array { labels: array, datasets: array }
	 */
	private static function csv_rows_to_chart_data( $rows, $chart_type, $colors = null ) {
		$empty = [ 'labels' => [], 'datasets' => [] ];

		if ( count( $rows ) < 2 || count( $rows[0] ) < 2 ) {
			return $empty;
		}

		$palette   = $colors ?: self::$default_colors;
		$headers   = $rows[0];
		$data_rows = array_slice( $rows, 1 );
		$is_pie    = in_array( $chart_type, [ 'pie', 'doughnut', 'polarArea', 'radar' ], true );

		$labels = array_map(
			function( $row ) {
				return $row[0] ?? '';
			},
			$data_rows
		);

		$datasets = [];

		if ( $is_pie ) {
			// For pie/doughnut/polarArea/radar: ONE dataset with array colors per data point.
			$data       = array_map(
				function( $row ) {
					return (float) ( $row[1] ?? 0 );
				},
				$data_rows
			);
			$bg_colors     = [];
			$border_colors = [];
			foreach ( $data_rows as $i => $row ) {
				$color_idx       = $i % count( $palette );
				$bg_colors[]     = $palette[ $color_idx ]['bg'];
				$border_colors[] = $palette[ $color_idx ]['border'];
			}

			$datasets[] = [
				'label'           => $headers[1] ?: 'Dataset 1',
				'data'            => $data,
				'backgroundColor' => $bg_colors,
				'borderColor'     => $border_colors,
				'borderWidth'     => 2,
			];
		} else {
			// For bar/line/area: each column = separate dataset.
			for ( $col = 1; $col < count( $headers ); $col++ ) {
				$color = $palette[ ( $col - 1 ) % count( $palette ) ];

				$datasets[] = [
					'label'           => $headers[ $col ] ?: 'Dataset ' . $col,
					'data'            => array_map(
						function( $row ) use ( $col ) {
							return (float) ( $row[ $col ] ?? 0 );
						},
						$data_rows
					),
					'backgroundColor' => $color['bg'],
					'borderColor'     => $color['border'],
					'borderWidth'     => 2,
					'tension'         => 0.4,
					'fill'            => false,
					'pointRadius'     => 3,
					'pointStyle'      => 'circle',
				];
			}
		}

		return [
			'labels'   => $labels,
			'datasets' => $datasets,
		];
	}

	/**
	 * Parse JSON string in Chart.js format into chart labels and datasets.
	 * Expected: { "labels": [...], "datasets": [{ "label": "...", "data": [...], ... }] }
	 *
	 * @since ??
	 *
	 * @param string $json_string JSON string.
	 * @param string $chart_type  Chart type.
	 *
	 * @return array { labels: array, datasets: array }
	 */
	private static function parse_chart_json_data( $json_string, $chart_type, $colors = null ) {
		$empty = [ 'labels' => [], 'datasets' => [] ];

		if ( empty( $json_string ) ) {
			return $empty;
		}

		$parsed = json_decode( $json_string, true );

		if ( ! is_array( $parsed ) || ! isset( $parsed['labels'] ) || ! isset( $parsed['datasets'] ) ) {
			return $empty;
		}

		if ( ! is_array( $parsed['labels'] ) || ! is_array( $parsed['datasets'] ) ) {
			return $empty;
		}

		$palette = $colors ?: self::$default_colors;
		$is_pie  = in_array( $chart_type, [ 'pie', 'doughnut', 'polarArea', 'radar' ], true );
		$labels  = array_map( 'strval', $parsed['labels'] );

		$datasets = [];
		foreach ( $parsed['datasets'] as $index => $ds ) {
			if ( ! is_array( $ds ) ) {
				continue;
			}

			$color = $palette[ $index % count( $palette ) ];

			$data = is_array( $ds['data'] ?? null )
				? array_map( 'floatval', $ds['data'] )
				: [];

			if ( $is_pie ) {
				// For pie-type: use array colors per data point if not already arrays.
				$bg = $ds['backgroundColor'] ?? null;
				$bd = $ds['borderColor'] ?? null;

				$bg_colors = is_array( $bg )
					? $bg
					: array_map(
						function( $i ) use ( $palette ) {
							return $palette[ $i % count( $palette ) ]['bg'];
						},
						array_keys( $data )
					);
				$border_colors = is_array( $bd )
					? $bd
					: array_map(
						function( $i ) use ( $palette ) {
							return $palette[ $i % count( $palette ) ]['border'];
						},
						array_keys( $data )
					);

				$dataset = [
					'label'           => $ds['label'] ?? 'Dataset ' . ( $index + 1 ),
					'data'            => $data,
					'backgroundColor' => $bg_colors,
					'borderColor'     => $border_colors,
					'borderWidth'     => $ds['borderWidth'] ?? 2,
				];
			} else {
				$dataset = [
					'label'           => $ds['label'] ?? 'Dataset ' . ( $index + 1 ),
					'data'            => $data,
					'backgroundColor' => $ds['backgroundColor'] ?? $color['bg'],
					'borderColor'     => $ds['borderColor'] ?? $color['border'],
					'borderWidth'     => $ds['borderWidth'] ?? 2,
					'tension'         => $ds['tension'] ?? 0.4,
					'fill'            => $ds['fill'] ?? false,
					'pointRadius'     => $ds['pointRadius'] ?? 3,
					'pointStyle'      => $ds['pointStyle'] ?? 'circle',
				];
			}

			if ( isset( $ds['type'] ) && ! empty( $ds['type'] ) ) {
				$dataset['type'] = $ds['type'];
			}

			$datasets[] = $dataset;
		}

		return [
			'labels'   => $labels,
			'datasets' => $datasets,
		];
	}
}
