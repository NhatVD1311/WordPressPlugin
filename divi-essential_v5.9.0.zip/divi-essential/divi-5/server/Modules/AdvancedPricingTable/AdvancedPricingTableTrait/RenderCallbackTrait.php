<?php
/**
 * AdvancedPricingTable::render_callback()
 *
 * @package MEE\Modules\AdvancedPricingTable
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingTable\AdvancedPricingTableTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\AdvancedPricingTable\AdvancedPricingTable;

trait RenderCallbackTrait {

	/**
	 * Default media icon (mdi:star). Kept in sync with the JS DEFAULT_ICON_SVG so
	 * the card renders even before an icon has been picked.
	 *
	 * @since ??
	 *
	 * @return string
	 */
	public static function default_icon_svg() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m12 17.27l4.15 2.51c.76.46 1.69-.22 1.49-1.08l-1.1-4.72l3.67-3.18c.67-.58.31-1.68-.57-1.75l-4.83-.41l-1.89-4.46c-.34-.81-1.5-.81-1.84 0L9.19 8.61l-4.83.41c-.88.07-1.24 1.17-.57 1.75l3.67 3.18l-1.1 4.72c-.2.86.73 1.54 1.49 1.08z"/></svg>';
	}

	/**
	 * Parent module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * Renders a single pricing plan card: optional ribbon, media (icon/image),
	 * header (title + subtitle), price block, the child feature rows ($content),
	 * and a button. The same markup is produced in the VB by edit.tsx.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content (rendered child feature rows).
	 * @param \WP_Block      $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Parent module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Background component.
		$background_component = ElementComponents::component(
			[
				'attrs'         => $attrs['module']['decoration'] ?? [],
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);

		// Media.
		$media_type = $attrs['media']['advanced']['type']['desktop']['value'] ?? 'icon';
		$icon_value = $attrs['media']['innerContent']['desktop']['value'] ?? [];
		// Custom SVG is a raw block attr headed for a passthrough sanitizer —
		// scrub it, same as NextAdvancedTab CommonTrait::get_tab_svg().
		$icon_svg   = ( is_array( $icon_value ) && ! empty( $icon_value['svg'] ) )
			? \DNXTE\Shared\SvgSanitizer::sanitize( $icon_value['svg'] )
			: self::default_icon_svg();
		$image_src  = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';

		// Price.
		$currency_symbol   = $attrs['price']['advanced']['currencySymbol']['desktop']['value'] ?? '$';
		$currency_position = $attrs['price']['advanced']['currencyPosition']['desktop']['value'] ?? 'before';
		$amount            = $attrs['price']['advanced']['amount']['desktop']['value'] ?? '';
		$period            = $attrs['price']['advanced']['period']['desktop']['value'] ?? '';
		$original_amount   = $attrs['price']['advanced']['originalAmount']['desktop']['value'] ?? '';

		// Ribbon.
		$ribbon_enabled   = $attrs['ribbon']['advanced']['enable']['desktop']['value'] ?? 'off';
		$ribbon_text      = $attrs['ribbon']['advanced']['text']['desktop']['value'] ?? '';
		$ribbon_variation = $attrs['ribbon']['advanced']['variation']['desktop']['value'] ?? 'badge';

		// Button.
		$button_text     = $attrs['button']['advanced']['text']['desktop']['value'] ?? '';
		$button_url      = $attrs['button']['advanced']['url']['desktop']['value'] ?? '#';
		$button_target   = $attrs['button']['advanced']['target']['desktop']['value'] ?? 'off';
		$button_position = $attrs['button']['advanced']['position']['desktop']['value'] ?? 'bottom';

		// Footer (optional description at the very bottom of the card).
		$footer_text = $attrs['footer']['innerContent']['desktop']['value'] ?? '';

		// Rating / review block.
		$rating_enabled  = ( $attrs['rating']['advanced']['enable']['desktop']['value'] ?? 'off' ) === 'on';
		$rating_title    = $attrs['rating']['advanced']['title']['desktop']['value'] ?? '';
		$rating_value    = (float) ( $attrs['rating']['advanced']['value']['desktop']['value'] ?? '5' );
		$rating_position = $attrs['rating']['advanced']['position']['desktop']['value'] ?? 'belowPrice';
		$rating_pct      = max( 0, min( 100, ( $rating_value / 5 ) * 100 ) );

		// Ribbon.
		$ribbon_html = '';
		if ( 'on' === $ribbon_enabled && '' !== $ribbon_text ) {
			$ribbon_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [
						'class' => 'dnxte-pricing-ribbon dnxte-pricing-ribbon-' . $ribbon_variation,
					],
					'childrenSanitizer' => 'esc_html',
					'children'          => $ribbon_text,
				]
			);
		}

		// Media (icon or image).
		$media_html = '';
		if ( 'none' !== $media_type ) {
			$media_inner = '';

			if ( 'image' === $media_type && '' !== $image_src ) {
				$media_inner = $elements->render(
					[
						'attrName' => 'image',
					]
				);
			} elseif ( 'icon' === $media_type ) {
				$media_inner = HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [
							'class' => 'dnxte-pricing-icon-inner',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $icon_svg,
					]
				);
			}

			$media_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [
						'class' => 'dnxte-pricing-media',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $media_inner,
				]
			);
		}

		// Header (title + subtitle).
		$header_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-pricing-header',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $elements->render( [ 'attrName' => 'title' ] ) . $elements->render( [ 'attrName' => 'subtitle' ] ),
			]
		);

		// Currency element.
		$currency_html = '' !== $currency_symbol ? HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-pricing-currency' ],
				'childrenSanitizer' => 'esc_html',
				'children'          => $currency_symbol,
			]
		) : '';

		// Original (struck-through) amount.
		$original_html = '';
		if ( '' !== $original_amount ) {
			$original_value = 'before' === $currency_position
				? $currency_symbol . $original_amount
				: $original_amount . $currency_symbol;

			$original_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'dnxte-pricing-original' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => $original_value,
				]
			);
		}

		// Amount.
		$amount_html = HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-pricing-amount' ],
				'childrenSanitizer' => 'esc_html',
				'children'          => $amount,
			]
		);

		// Period.
		$period_html = '' !== $period ? HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-pricing-period' ],
				'childrenSanitizer' => 'esc_html',
				'children'          => $period,
			]
		) : '';

		$amount_wrap_inner  = 'before' === $currency_position ? $currency_html : '';
		$amount_wrap_inner .= $amount_html;
		$amount_wrap_inner .= 'after' === $currency_position ? $currency_html : '';
		$amount_wrap_inner .= $period_html;

		$amount_wrap_html = HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-pricing-amount-wrap' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $amount_wrap_inner,
			]
		);

		$price_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-pricing-price',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $original_html . $amount_wrap_html,
			]
		);

		// Feature rows — rendered child blocks ($content). The marker class drives
		// the icon vs numeric/roman counter styling (see module.scss).
		$marker_type    = $attrs['features']['advanced']['markerType']['desktop']['value'] ?? 'icon';
		$features_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-pricing-features dnxte-pricing-features--' . $marker_type,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content,
			]
		);

		// Button.
		$button_html = '';
		if ( '' !== $button_text ) {
			$button_wrap_class = 'dnxte-pricing-button-wrap dnxte-pricing-button-wrap--' . $button_position;

			$button_attributes = [
				'class' => 'dnxte-pricing-button',
				'href'  => '' !== $button_url ? $button_url : '#',
			];

			if ( 'on' === $button_target ) {
				$button_attributes['target'] = '_blank';
				$button_attributes['rel']    = 'noopener noreferrer';
			}

			$button_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => $button_wrap_class ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => HTMLUtility::render(
						[
							'tag'               => 'a',
							'attributes'        => $button_attributes,
							'childrenSanitizer' => 'esc_html',
							'children'          => $button_text,
						]
					),
				]
			);
		}

		// Footer — rendered only when it has content; always sits at the very bottom
		// of the card (below the button when the button is at the bottom).
		$footer_html = '' !== $footer_text ? $elements->render( [ 'attrName' => 'footer' ] ) : '';

		// Rating / review block — short title + 5-star overlay (fill width = value/5).
		$rating_html = '';
		if ( $rating_enabled ) {
			$rating_title_html = '' !== $rating_title ? HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'dnxte-pricing-rating-title' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => $rating_title,
				]
			) : '';

			$stars_html  = '<div class="dnxte-pricing-rating-stars">';
			$stars_html .= '<span class="dnxte-pricing-rating-stars-empty">&#9733;&#9733;&#9733;&#9733;&#9733;</span>';
			$stars_html .= '<span class="dnxte-pricing-rating-stars-fill" style="width:' . esc_attr( $rating_pct ) . '%">&#9733;&#9733;&#9733;&#9733;&#9733;</span>';
			$stars_html .= '</div>';

			$rating_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'dnxte-pricing-rating' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $rating_title_html . $stars_html,
				]
			);
		}

		// Card content — the module wrapper itself is the card. The button is placed
		// at top (below header), middle (below price) or bottom (below features).
		$card_inner  = $ribbon_html . $media_html . $header_html;
		$card_inner .= 'top' === $button_position ? $button_html : '';
		$card_inner .= 'belowHeader' === $rating_position ? $rating_html : '';
		$card_inner .= $price_html;
		$card_inner .= 'belowPrice' === $rating_position ? $rating_html : '';
		$card_inner .= 'middle' === $button_position ? $button_html : '';
		$card_inner .= $features_html;
		$card_inner .= 'bottom' === $button_position ? $button_html : '';
		$card_inner .= $footer_html;

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [ AdvancedPricingTable::class, 'module_classnames' ],
				'stylesComponent'     => [ AdvancedPricingTable::class, 'module_styles' ],
				'scriptDataComponent' => [ AdvancedPricingTable::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				// Extra inner <div> wrapper — mirrors the plain <div> added inside
				// ModuleContainer in edit.tsx so VB and front-end markup match.
				'children'            => HTMLUtility::render(
					[
						'tag'               => 'div',
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $background_component . $card_inner,
					]
				),
			]
		);
	}
}
