<?php
/**
 * AdvancedPricingTable::module_styles().
 *
 * @package MEE\Modules\AdvancedPricingTable
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingTable\AdvancedPricingTableTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\AdvancedPricingTable\AdvancedPricingTable;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Parent Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/AdvancedPricingTable/styles.tsx.
	 *
	 * Every property is routed through Divi's style system — native font /
	 * decoration groups plus `$elements->style( advancedStyles => [ divi/common ] )`
	 * for the custom selectors — so everything is auto-responsive and hover-capable
	 * without any hand-written media queries.
	 *
	 * @since ??
	 *
	 * @param array $args Style component arguments.
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];
		$order_class = $args['orderClass'] ?? '';

		$media_selector  = "{$order_class} .dnxte-pricing-media";
		$icon_selector   = "{$order_class} .dnxte-pricing-icon-inner";
		$ribbon_selector = "{$order_class} .dnxte-pricing-ribbon";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module + every custom-selector style routed through divi/common.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn'     => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									// Media icon color — recolors fill + stroke, preserving fill="none".
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $icon_selector,
											'attr'     => $attrs['media']['advanced']['iconColor'] ?? [],
											'property' => 'color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$icon_selector} svg, {$icon_selector} svg [fill]:not([fill=\"none\"])",
											'attr'     => $attrs['media']['advanced']['iconColor'] ?? [],
											'property' => 'fill',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$icon_selector} svg [stroke]:not([stroke=\"none\"])",
											'attr'     => $attrs['media']['advanced']['iconColor'] ?? [],
											'property' => 'stroke',
										],
									],
									// Media icon size — inner SVG is sized in em (see module.scss).
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $icon_selector,
											'attr'     => $attrs['media']['advanced']['iconSize'] ?? [],
											'property' => 'font-size',
										],
									],
									// Image width.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$media_selector} img",
											'attr'     => $attrs['image']['decoration']['image_width'] ?? [],
											'property' => 'width',
										],
									],
									// Media alignment.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $media_selector,
											'attr'     => $attrs['media']['advanced']['alignment'] ?? [],
											'property' => 'justify-content',
										],
									],
									// Ribbon position — left / top (%) so the user can place it anywhere.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $ribbon_selector,
											'attr'     => $attrs['ribbon']['advanced']['offsetX'] ?? [],
											'property' => 'left',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $ribbon_selector,
											'attr'     => $attrs['ribbon']['advanced']['offsetY'] ?? [],
											'property' => 'top',
										],
									],
									// Ribbon rotation — CSS var consumed by the transform in module.scss.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $ribbon_selector,
											'attr'     => $attrs['ribbon']['advanced']['rotation'] ?? [],
											'property' => '--dnxte-ribbon-rotate',
										],
									],
									// Circle size — diameter (width); height follows via aspect-ratio.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$ribbon_selector}.dnxte-pricing-ribbon-circle",
											'attr'     => $attrs['ribbon']['advanced']['size'] ?? [],
											'property' => 'width',
										],
									],
									// Features spacing - gap between the child feature rows.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-features",
											'attr'     => $attrs['features']['advanced']['gap'] ?? [],
											'property' => 'gap',
										],
									],
									// Button width.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-button",
											'attr'     => $attrs['button']['advanced']['width'] ?? [],
											'property' => 'width',
										],
									],
									// Button alignment - text-align positions the inline-block button.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-button-wrap",
											'attr'     => $attrs['button']['advanced']['alignment'] ?? [],
											'property' => 'text-align',
										],
									],
									// Rating - filled star color.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-rating-stars-fill",
											'attr'     => $attrs['rating']['advanced']['starColor'] ?? [],
											'property' => 'color',
										],
									],
									// Rating - empty star color.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-rating-stars-empty",
											'attr'     => $attrs['rating']['advanced']['emptyStarColor'] ?? [],
											'property' => 'color',
										],
									],
									// Rating - star size.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$order_class} .dnxte-pricing-rating-stars",
											'attr'     => $attrs['rating']['advanced']['starSize'] ?? [],
											'property' => 'font-size',
										],
									],


								],
							],
						]
					),

					// Media wrapper + Header wrapper - border / spacing.
					$elements->style( [ 'attrName' => 'media' ] ),
					$elements->style( [ 'attrName' => 'header' ] ),

					// Number marker (numeric / roman) font.
					$elements->style( [ 'attrName' => 'marker' ] ),

					// Global feature-text font (child rows can override).
					$elements->style( [ 'attrName' => 'featureFont' ] ),

					// Rating title font.
					// Rating block (border / spacing).
					$elements->style( [ 'attrName' => 'rating' ] ),
					$elements->style( [ 'attrName' => 'ratingTitle' ] ),

					// Title / Subtitle fonts.
					$elements->style( [ 'attrName' => 'title' ] ),
					$elements->style( [ 'attrName' => 'subtitle' ] ),

					// Price amount / currency / period / original fonts.
					$elements->style( [ 'attrName' => 'price' ] ),
					$elements->style( [ 'attrName' => 'currency' ] ),
					$elements->style( [ 'attrName' => 'period' ] ),
					$elements->style( [ 'attrName' => 'original' ] ),

					// Button — native decoration groups + font.
					$elements->style( [ 'attrName' => 'button' ] ),

					// Ribbon background + color + font (routed through the decoration group).
					$elements->style( [ 'attrName' => 'ribbon' ] ),

					// Footer font / spacing / border.
					$elements->style( [ 'attrName' => 'footer' ] ),

					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => AdvancedPricingTable::custom_css(),
						]
					),
				],
			]
		);
	}
}
