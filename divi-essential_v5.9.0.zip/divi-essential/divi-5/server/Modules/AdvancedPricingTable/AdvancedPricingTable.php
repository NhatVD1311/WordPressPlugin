<?php
/**
 * Module: Parent Module class.
 *
 * @package MEE\Modules\AdvancedPricingTable
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingTable;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `AdvancedPricingTable` is consisted of functions used for Parent Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class AdvancedPricingTable implements DependencyInterface {
	use AdvancedPricingTableTrait\RenderCallbackTrait;
	use AdvancedPricingTableTrait\ModuleClassnamesTrait;
	use AdvancedPricingTableTrait\ModuleStylesTrait;
	use AdvancedPricingTableTrait\ModuleScriptDataTrait;

	/**
	 * Loads `AdvancedPricingTable` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'AdvancedPricingTable/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ AdvancedPricingTable::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
