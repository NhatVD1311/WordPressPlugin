<?php
/**
 * Module: Child Module class.
 *
 * @package MEE\Modules\InteractiveCircleChild
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircleChild;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `InteractiveCircleChild` is consisted of functions used for Child Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class InteractiveCircleChild implements DependencyInterface {
	use InteractiveCircleChildTrait\RenderCallbackTrait;

	/**
	 * Loads `InteractiveCircleChild` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'InteractiveCircleChild/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ InteractiveCircleChild::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
