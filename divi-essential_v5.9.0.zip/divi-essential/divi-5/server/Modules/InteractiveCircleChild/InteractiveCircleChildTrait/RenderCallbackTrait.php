<?php
/**
 * InteractiveCircleChild::render_callback()
 *
 * @package MEE\Modules\InteractiveCircleChild
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircleChild\InteractiveCircleChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\InteractiveCircleChild\InteractiveCircleChild;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;

	/**
	 * Child module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param WP_Block       $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Child module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		$parent_attrs = $parent->attrs ?? [];

		$parent_default_attributes = ModuleRegistration::get_default_attrs( 'example/parent-module' );
		$parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );

		$button_content = $attrs['content_button']['innerContent']['desktop']['value'] ?? '';
$button_href = $attrs['content_button']['advanced']['linkGroup']['desktop']['value'] ?? '';
		// Icon.
		$icon_value = $attrs['icon']['innerContent']['desktop']['value'] ?? "";
		 $image_src = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';
        $image_alt = $attrs['image']['innerContent']['desktop']['value']['alt'] ?? '';

			$use_icon = $attrs['module']['advanced']['useIcon']['desktop']['value'] ?? '';
			$use_content_icon = $attrs['module']['advanced']['useIconContent']['desktop']['value'] ?? '';
			$use_content_image = $attrs['module']['advanced']['useContentImage']['desktop']['value'] ?? '';
			$icon       = Utils::process_font_icon( $icon_value );
			$use_tooltip = $parent_attrs['orbitSettings']['advanced']['tooltip']['desktop']['value'] ?? '';
			$content_icon = $use_content_icon === 'on' ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'content-icon',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => HTMLUtility::render(
					[
						'tag'        => 'span',
							'childrenSanitizer' => 'esc_html',
						'children'   => Utils::process_font_icon( $icon_value ),
					]
				),
			]
		): '';
$thumb_title =  $attrs['orbit_thumb_title']['innerContent']['desktop']['value'] ?? '';

		// Title.
		$title = $elements->render(
			[
				'attrName'      => 'title',
				'hoverSelector' => '{{parentSelector}}',
			]
		);
$content = $elements->render(
			[
				'attrName'      => 'content',
				'hoverSelector' => '{{parentSelector}}',
			]
		);
		$orbit_thumb =  HTMLUtility::render(
			[
				'tag'               => 'img',
				'attributes'        => [
					'src'                => $image_src,
					'alt'                => $image_alt,
				],
				
				

			]
		) ;

		$orbit_thumb_icon  = null;

		$orbit_thumb_wrapper = $use_icon === 'off' && $use_content_image === 'on' && $image_src ? HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'                => 'content-image',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $orbit_thumb,

			]
		): '';
	$button = $button_content !== '' ? HTMLUtility::render(
			[
				'tag' => 'a',
				'attributes' => [
					'href' => !empty($button_href) ? esc_url($button_href['url']) : '#',
					'target' => !empty($button_href) && isset($button_href['target']) ? '_blank' : '_self',
					'class' => 'orbit-slide-button',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => $button_content,
			]
		) : '';
		$orbit_slide_content = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'                => 'orbit-slide-content',
					
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $orbit_thumb_wrapper . $content_icon . $title . $content . $button,

			]
		);

		$orbit_slide = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'                => 'orbit-slide',
					'data-orbit-thumb'     => $image_src,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          =>   $orbit_slide_content,

			]
		);

		
	


		return Module::render(
			[
				// FE only.
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [ InteractiveCircleChild::class, 'module_classnames' ],
				'stylesComponent'    => [ InteractiveCircleChild::class, 'module_styles' ],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				 'htmlAttrs' => array_merge(
							$use_icon === 'on'
									? ['data-orbit-icon' => $icon]
									: ['data-orbit-thumb' => esc_attr($image_src)],
							['data-thumb-class' => 'orbit-slide_' . $block->parsed_block['orderIndex']],
							$use_tooltip === 'on' ? ['data-orbit-tooltip' => wp_strip_all_tags( $title )] : [],
							$use_icon === 'on' ? ['data-orbit-title' => wp_strip_all_tags( $thumb_title )] : []


),				'children'           => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $orbit_slide_content,
			]
		);
	}
}
