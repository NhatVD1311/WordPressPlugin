<?php
/**
 * InteractiveCircleChild::module_styles().
 *
 * @package Builder\Packages\ModuleLibrary
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircleChild\InteractiveCircleChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\InteractiveCircleChild\InteractiveCircleChild;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
		public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
            [
                'returnType' => 'string',
                'important'  => [
                    'font-family' => true,
                    'font-weight' => true,
                ],
            ]
        );

        if ( isset( $icon_attr['type'] ) ) {
            $font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
            $style_declarations->add( 'font-family', $font_family );
        }

        if ( ! empty( $icon_attr['weight'] ) ) {
            $style_declarations->add( 'font-weight', $icon_attr['weight'] );
        }

        if ( ! empty( $icon_attr['unicode'] ) ) {
            $unicode = Utils::process_font_icon( $icon_attr );
            $unicode = trim( (string) $unicode );
            // Strip accidental trailing quotes/semicolons
            $unicode = preg_replace( '/[;\'"]+$/', '', $unicode );

            // Normalize formats: &#xE090;, E090, \E090 -> \E090
            if ( preg_match( '/^&#x([0-9a-fA-F]{1,6});?$/', $unicode, $m ) ) {
                $unicode = $m[1];
            }
            if ( preg_match( '/^[0-9a-fA-F]{1,6}$/', $unicode ) ) {
                $unicode = '\\' . $unicode;
            }

            $is_valid = (bool) preg_match( '/^\\\[0-9a-fA-F]{1,6}$/', $unicode );

            if ( $is_valid ) {
                $style_declarations->add( 'content', '"' . $unicode . '"' );
            }
        }

        return $style_declarations->value();
    }
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];

		$parent_default_attributes = ModuleRegistration::get_default_attrs( 'example/parent-module' );
		$parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );

		$content_container_selector = "{$order_class} .example_child_module__content-container";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn'     => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									[
										'componentName' => 'divi/text',
										'props'         => [
											'selector' => $content_container_selector,
											'attr'     => $attrs['module']['advanced']['text'] ?? [],
										]
									]
								]
							],
						]
					),

					// Title.
					$elements->style(
						[
							'attrName' => 'title',
						]
					),
	$elements->style(
						[
							'attrName' => 'content_button',
						]
					),
					// Content.
					$elements->style(
						[
							'attrName' => 'content',
						]
					),
$elements->style(
						[
							'attrName' => 'innercircleDesign',
						]
					),
					// Icon.
					$elements->style(
						[
							'attrName'   => 'icon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['icon']['innerContent'] ?? [],
											'declarationFunction' => [self::class, 'icon_style_declaration'],
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['color'] ?? $parent_attrs_with_default['icon']['advanced']['color'] ?? [],
											'property' => 'color',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['size'] ?? $parent_attrs_with_default['icon']['advanced']['size'] ?? [],
											'property' => 'font-size',
										]
									],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName'   => 'contentIconWrapper',
							'styleProps' => [
								'advancedStyles' => [
									
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['contentIconWrapper']['advanced']['size'] ?? $parent_attrs_with_default['contentIconWrapper']['advanced']['size'] ?? [],
											'property' => 'width',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['contentIconWrapper']['advanced']['size'] ?? $parent_attrs_with_default['contentIconWrapper']['advanced']['size'] ?? [],
											'property' => 'height',
										]
									],
										[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['icon']['innerContent'] ?? [],
											'declarationFunction' => [self::class, 'icon_style_declaration'],
										]
									],
										[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['iconSize'] ?? [],
														'property' => 'font-size',
													]
												],
													[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['iconColor'] ?? [],
														'property' => 'color',
													]
												],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'orbit_thumb_title',
						]
					),
					/*
					 * We need to add CssStyle at the very bottom of other
					 * components so that custom css can override module styles
					 * till we find a more elegant solution.
					 */
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					// ATTENTION: The code is intentionally added and commented in FE only as an example of expected value format.
					// If you have custom style processing, the style output should be passed as an `array` of style declarations
					// to the `styles` property of the `Style::add` method. For example:
					// [
					// 	[
					// 		'atRules'     => false,
					// 		'selector'    => $icon_selector,
					// 		'declaration' => 'color: red;'
					// 	],
					// 	[
					// 		'atRules'     => '@media only screen and (max-width: 767px)',
					// 		'selector'    => $icon_selector,
					// 		'declaration' => 'color: green;'
					// 	],
					// ],

					// The code below is an example of how to use the `CssStyle::style` method to generate CSS style.
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}

}
