<?php
/**
 * NextAdvancedTabItem::module_styles().
 *
 * @package MEE\Modules\NextAdvancedTabItem
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTabItem\NextAdvancedTabItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DNXTE\Modules\Base\Traits\CommonTrait as BaseCommonTrait;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use BaseCommonTrait;

	/**
	 * D4 module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/d4-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? array();
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? array();
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? array();
		$order_class                 = $args['orderClass'] ?? '';
		$colorStyle                  = array();

		$bodyIconSelector      = "$order_class .dnxte_tab_content_icon";
		$tabIconSelector       = "$order_class span.dnxte_tab_nav_icon";
		$tabIconSelectorActive = "$order_class span.dnxte_tab_nav_icon_active";

		$is_icon_active  = $attrs['tabsIconActive']['advanced']['use']['desktop']['value'] ?? 'off';
		$buttonAttrs     = $attrs['button']['decoration']['button']['desktop']['value'] ?? [];
		$buttonAlignment = $buttonAttrs['alignment'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? array(),
								'disabledOn'               => array(
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? array(),
							'cssFields' => self::custom_css(),
						)
					),
					// // Image.
					// $elements->style(
					// [
					// 'attrName' => 'image',
					// ]
					// ),
					// // Title.
					$elements->style(
    					[
    					   'attrName' => 'tab',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'body',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'title',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'subtitle',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'bodyTitle',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'bodyContent',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'bodyImage',
                            'styleProps' => array(
                                'advancedStyles' => array(
                                    array(
                        				'componentName' => 'divi/common',
                        				'props'         => array(
            								'selector' => "{$order_class} .dnxte_tab_content.dnxte_tab_content_active",
            								'attr'     => $attrs['bodyImage']['advanced']['placement'] ?? array(),
            								'declarationFunction' => function( $params ) {
               									$attrValue = $params['attrValue'] ?? '';

               									$placementObj = array(
              										'center'    => 'column',
              										'bottom' => 'column-reverse',
              										'left'   => 'row',
              										'right'  => 'row-reverse',
               									);
               									return "flex-direction: {$placementObj[$attrValue]};";
            								},
                        				),
                                    ),
                                    array(
                        				'componentName' => 'divi/common',
                        				'props'         => array(
            								'selector' => "{$order_class} .dnxte_tab_content_slidebar_one",
            								'attr'     => $attrs['bodyImage']['decoration']['sizing'] ?? array(),
            								'declarationFunction' => function( $params ) {
               									$attrValue = $params['attrValue'] ?? [];
                                                $width = $attrValue['width'] ?? '50%';

               									return "flex: 0 0 {$width};";
            								},
                        				),
                                    ),
                                )
                            )
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'tabsImageIconActive',
    					]
					),
					$elements->style(
    					[
    					   'attrName' => 'button',
                            'styleProps' => array(
    								'advancedStyles' => array(
        								array(
            								'componentName' => 'divi/common',
            								'props'         => array(
                								'selector' => "{$order_class} .dnxte_tab_content_button_wrap",
                								'attr'     => $attrs['button']['decoration']['button'] ?? array(),
                								'declarationFunction' => fn() => "justify-content: $buttonAlignment",
            								),
    								),
    							)
                            )
    					]
					),
					$elements->style(
						array(
							'attrName'   => 'bodyIcon',
							'styleProps' => array(
								'advancedStyles' => array(
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'selector' => "{$order_class} .dnxte_tab_content_slidebar_one",
											'attr'     => $attrs['bodyIcon']['advanced']['alignment'] ?? array(),
											'property' => 'justify-content',
										),
									),
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'selector' => "{$order_class} .dnxte_tab_content_slidebar_one > span.dnxte_tab_content_icon, {$order_class} .dnxte_tab_content_slidebar_one > span.dnxte_tab_content_icon_active",
											'attr'     => $attrs['bodyIcon']['advanced']['size'] ?? array(),
											'property' => 'font-size',
										),
									),
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'selector' => "{$order_class} .dnxte_tab_content_slidebar_one > span.dnxte_tab_content_icon, {$order_class} .dnxte_tab_content_slidebar_one > span.dnxte_tab_content_icon_active",
											'attr'     => $attrs['bodyIcon']['advanced']['color'] ?? array(),
											'property' => 'color',
										),
									),
								),
							),
						)
					),
					( new self() )->tab_image_style( $elements, 'tabsImageIconNormal', $order_class, $attrs ),
					( new self() )->tab_icon_style( $elements, 'tabsIconNormal', $tabIconSelector, $attrs ),
					( new self() )->tab_icon_style( $elements, 'tabsIconNormal', $tabIconSelectorActive, $attrs, 'on' === $is_icon_active ),
					( new self() )->body_icon_style( $elements, 'bodyIcon', $bodyIconSelector, $attrs ),
					...$colorStyle,
				),
			)
		);
	}




	public function tab_image_style( $elements, $slug, $order_class, $attrs ) {
		$useImageOrIcon = $attrs['misc']['advanced']['useImageOrIcon']['desktop']['value'] ?? 'none';

		return $elements->style(
			array(
				'attrName'   => 'tabsImageIconNormal',
				'styleProps' => array(
					'advancedStyles' => array(
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => $order_class . ' a.dnxte_tab_a',
								'attr'                => $attrs['tabsImageIconNormal']['advanced']['placement'] ?? array(),
								'declarationFunction' => function( $params ) {
									$attrValue = $params['attrValue'] ?? '';

									$placementObj = array(
										'center' => 'column',
										'bottom' => 'column-reverse',
										'left'   => 'row',
										'right'  => 'row-reverse',
									);
									return "flex-direction: {$placementObj[$attrValue]};";
								},
							),
						),
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'atRules'             => '@media only screen and (max-width: 980px)',
								'selector'            => $order_class . ' a.dnxte_tab_a',
								'attr'                => array( 'desktop' => array( 'value' => 'on' ) ),
								'declarationFunction' => function( $params ) {
									return 'flex-direction: column; justify-content: initial;';
								},
							),
						),
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'atRules'             => '@media only screen and (max-width: 767px)',
								'selector'            => $order_class . ' a.dnxte_tab_a',
								'attr'                => array( 'desktop' => array( 'value' => 'on' ) ),
								'declarationFunction' => function( $params ) {
									return 'flex-direction: column; justify-content: initial;';
								},
							),
						),
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => "{$order_class} a.dnxte_tab_a .dnxte_tab_nav_image, {$order_class} a.dnxte_tab_a .dnxte_tab_nav_icon,{$order_class} a.dnxte_tab_a .dnxte_tab_nav_image_active, {$order_class} a.dnxte_tab_a .dnxte_tab_nav_icon_active",
								'attr'                => $attrs['tabsImageIconNormal']['advanced']['alignment'] ?? array(),
								'declarationFunction' => function( $params ) {
									$attrValue = $params['attrValue'] ?? '';
									return "align-self: {$attrValue};";
								},
							),
						),
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => "{$order_class} a.dnxte_tab_a .dnxte_tab_nav_image > img, {$order_class} a.dnxte_tab_a .dnxte_tab_nav_icon,{$order_class} a.dnxte_tab_a .dnxte_tab_nav_image_active > img, {$order_class} a.dnxte_tab_a .dnxte_tab_nav_icon_active",
								'attr'                => $attrs['tabsImageIconNormal']['advanced']['size'] ?? array(),
								'declarationFunction' => function( $params ) use ( $useImageOrIcon ) {
									$attrValue      = $params['attrValue'] ?? '';
									if ( 'none' === $useImageOrIcon ) {
										return '';
									}
									$sizeProperty = 'image' === $useImageOrIcon ? 'max-width' : 'font-size';
									return "{$sizeProperty}: {$attrValue} !important;";
								},
							),
						),
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => "{$order_class} a.dnxte_tab_a .dnxte_tab_nav_icon",
								'attr'                => $attrs['tabsImageIconNormal']['advanced']['color'] ?? array(),
								'property' => 'color'
							),
						),
					),
				),
			)
		);
	}


	public function body_icon_style( $elements, $slug, $selector, $attrs ) {
		return $elements->style(
			array(
				'attrName'   => $slug,
				'styleProps' => array(
					'advancedStyles' => array(
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => $selector . ':before',
								'attr'                => $attrs[ $slug ]['innerContent'] ?? array(),
								'declarationFunction' => array( self::class, 'icon_style_declaration' ),
							),
						),
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector . ":before",
						// 'attr'     => $attrs[$slug]['advanced']['color'] ?? [],
						// 'property' => "color",
						// ],
						// ],
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector . ":before",
						// 'attr'     => $attrs[$slug]['advanced']['size'] ?? [],
						// 'property' => "font-size",
						// ],
						// ],
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector,
						// 'attr'     => $attrs[$slug]['advanced']['alignment'] ?? [],
						// 'property' => "text-align",
						// ],
						// ],
					),
				),
			)
		);
	}

	public function tab_icon_style( $elements, $slug, $selector, $attrs, $is_active_icon = false ) {
		$attrN = $slug;
		if ( $is_active_icon ) {
			$iconActive = $attrs[ $slug ]['innerContent']['desktop']['value'] ?? null;
			if ( $iconActive ) {
				$attrN = 'tabsIconActive';
			}
		}
		return $elements->style(
			array(
				'attrName'   => $attrN,
				'styleProps' => array(
					'advancedStyles' => array(
						array(
							'componentName' => 'divi/common',
							'props'         => array(
								'selector'            => $selector,
								'attr'                => $attrs[ $attrN ]['innerContent'] ?? array(),
								'declarationFunction' => array( self::class, 'icon_style_declaration' ),
							),
						),
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector . ":before",
						// 'attr'     => $attrs[$slug]['advanced']['color'] ?? [],
						// 'property' => "color",
						// ],
						// ],
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector . ":before",
						// 'attr'     => $attrs[$slug]['advanced']['size'] ?? [],
						// 'property' => "font-size",
						// ],
						// ],
						// [
						// 'componentName' => 'divi/common',
						// 'props'         => [
						// 'selector' => $selector,
						// 'attr'     => $attrs[$slug]['advanced']['alignment'] ?? [],
						// 'property' => "text-align",
						// ],
						// ],
					),
				),
			)
		);
	}
}
