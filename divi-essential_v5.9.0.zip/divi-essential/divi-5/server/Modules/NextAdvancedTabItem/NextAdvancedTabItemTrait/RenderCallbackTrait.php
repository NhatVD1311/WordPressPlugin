<?php
/**
 * NextAdvancedTabItem::render_callback()
 *
 * @package MEE\Modules\NextAdvancedTabItem
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTabItem\NextAdvancedTabItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use DNXTE\Modules\Base\Traits\CommonTrait as BaseCommonTrait;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleUtils\ChildrenUtils;
use DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait\CommonTrait;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use CommonTrait;
	use BaseCommonTrait;

	/**
	 * Divi 4 module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $child_modules_content Block content rendered from the nested child modules.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( $attrs, $child_modules_content, $block, $elements ) {

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		// Background component.
		$background_component = ElementComponents::component(
			array(
				'attrs'         => $attrs['module']['decoration'] ?? array(),
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			)
		);

		$use_library = $attrs['misc']['advanced']['useLibrary']['desktop']['value'] ?? 'off';

		$content = '';
		if ( 'on' === $use_library ) {
			$layout_id = $attrs['misc']['advanced']['library']['desktop']['value'] ?? '0';
			$content   = self::get_content( $layout_id );



		} else {
			$content = self::get_custom_content( $elements, $attrs );
		}

		// Nested modules dropped into the tab body via the "Elements" group.
		$children_ids = ChildrenUtils::extract_children_ids( $block );

		$content = sprintf(
			'
            <div class="dnxte_tab_content" data-id="%1$s">
                %2$s
                %3$s
            </div>
		',
			self::get_module_class( $block->parsed_block['id'] ), // from common trait
			$content,
			$child_modules_content
		);

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'childrenIds'         => $children_ids,
				'children'            => $background_component . $content,
			)
		);
	}


	public static function get_custom_content( $elements, $attrs ) {
		// Title - use $elements->render() to properly resolve dynamic content.
		$heading_level = $attrs['bodyTitle']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h2';
		$body_title    = $elements->render(
			array(
				'attrName'          => 'bodyTitle',
				'tagName'           => $heading_level,
				'childrenSanitizer' => 'et_core_esc_previously',
			)
		);

		$body_content = $elements->render(
			array(
				'attrName'          => 'bodyContent',
				'childrenSanitizer' => 'et_core_esc_previously',
			)
		);

		// Use $elements->render() to properly resolve dynamic content for button.
		$button_attr = $attrs['button']['innerContent']['desktop']['value'] ?? array();
		$button_text = $button_attr['text'] ?? '';
		$button      = '';

		if ( '' !== $button_text ) {
			$button = sprintf(
				'<a href="%2$s" target="%3$s" class="et_pb_button_ dnxte_tab_content_btn">%1$s</a>',
				esc_html( $button_text ),
				esc_url( $button_attr['linkUrl'] ?? '#' ),
				esc_attr( $button_attr['linkTarget'] ?? '_self' )
			);
		}

		$image_or_icon     = '';
		$use_image_or_icon = $attrs['misc']['advanced']['useImageOrIconInBody']['desktop']['value'] ?? 'none';

		if ( 'icon' === $use_image_or_icon ) {
			$image_or_icon = sprintf( '<span class="dnxte_tab_content_icon"></span>' );
		} elseif ( 'image' === $use_image_or_icon ) {
			$image_or_icon = $elements->render(
				array(
					'attrName'          => 'bodyImage',
					'childrenSanitizer' => 'et_core_esc_previously',
				)
			);
		} elseif ( 'svg' === $use_image_or_icon ) {
			// Raw block attr — scrub like the tab-nav SVG in CommonTrait::get_tab_svg().
			$body_svg = \DNXTE\Shared\SvgSanitizer::sanitize( $attrs['bodySvg']['innerContent']['desktop']['value'] ?? '' );

			if ( '' !== $body_svg ) {
				$image_or_icon = sprintf( '<span class="dnxte_tab_content_svg">%1$s</span>', $body_svg );
			}
		}

		if ( '' !== $image_or_icon ) {
			$image_or_icon = sprintf(
				'<div class="dnxte_tab_content_slidebar_one">
    		     %1$s
                    </div>',
				$image_or_icon
			);
		}

		return sprintf(
			'
                %4$s
                <div class="dnxte_tab_content_slidebar_two">
                    %1$s
                    %2$s
                    <div class="dnxte_tab_content_button_wrap">
                        %3$s
                    </div>
                </div>',
			$body_title,
			$body_content,
			$button,
			$image_or_icon,
		);
	}
}
