<?php
/**
 * NextAdvancedTabItem::module_script_data()
 *
 * @package MEE\Modules\NextAdvancedTabItem
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTabItem\NextAdvancedTabItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		// Assign variables.
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? array();
		$store_instance = $args['storeInstance'] ?? null;

		// Module decoration attributes.
		$module_decoration_attrs = $attrs['module']['decoration'] ?? array();

		ElementScriptData::set(
			array(
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					array(
						'link' => $args['attrs']['module']['advanced']['link'] ?? array(),
					)
				),
				'storeInstance' => $store_instance,
			)
		);

		MultiViewScriptData::set(
			array(
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => $attrs,
				'storeInstance' => $store_instance,
				'setContent'    => array(
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_title",
						'data'          => $attrs['title']['innerContent'] ?? array(),
						'valueResolver' => function ( $value ) {
							return $value ?? '';
						},
						'sanitizer'     => 'et_core_esc_previously',
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_pra",
						'data'          => $attrs['subtitle']['innerContent'] ?? array(),
						'valueResolver' => function ( $value ) {
							return $value ?? '';
						},
						'sanitizer'     => 'et_core_esc_previously',
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_icon, {$selector} .dnxte_tab_nav_icon_active",
						'data'          => $attrs['tabsIconNormal']['innerContent'] ?? array(),
						'valueResolver' => function ( $value ) {
							return Utils::process_font_icon( $value ) ?? '';
						},
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_content_title",
						'data'          => $attrs['bodyTitle']['innerContent'] ?? array(),
						'valueResolver' => function ( $value ) {
							return $value ?? '';
						},
						'sanitizer'     => 'et_core_esc_previously',
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_content_pra",
						'data'          => $attrs['bodyContent']['innerContent'] ?? array(),
						'valueResolver' => function ( $value ) {
							return $value ?? '';
						},
						'sanitizer'     => 'et_core_esc_previously',
					),
				),
				'setAttrs'      => array(
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_image img, {$selector} .dnxte_tab_nav_image_active img",
						'attrs'         => $attrs['tabsImageNormal']['innerContent'] ?? array(),
						'data'          => array(
							'src' => $attrs['tabsImageNormal']['innerContent'] ?? array(),
						),
						'valueResolver' => function ( $value ) {
							return $value['src'] ?? array();
						},
						'tag'           => 'img',
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_content_slidebar_one img",
						'attrs'         => $attrs['bodyImage']['innerContent'] ?? array(),
						'data'          => array(
							'src' => $attrs['bodyImage']['innerContent'] ?? array(),
						),
						'valueResolver' => function ( $value ) {
							return $value['src'] ?? array();
						},
						'tag'           => 'img',
					),
				),
				'setVisibility' => array(
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_icon, {$selector} .dnxte_tab_nav_icon_active",
						'data'          => $attrs['misc']['advanced']['useImageOrIcon'] ?? array(),
						'valueResolver' => function ( $value ) {
							return 'icon' === $value ? 'visible' : 'hidden';
						},
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_nav_image, {$selector} .dnxte_tab_nav_image_active",
						'data'          => $attrs['misc']['advanced']['useImageOrIcon'] ?? array(),
						'valueResolver' => function ( $value ) {
							return 'image' === $value ? 'visible' : 'hidden';
						},
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_content_slidebar_one .dnxte_tab_content_icon",
						'data'          => $attrs['misc']['advanced']['useImageOrIconInBody'] ?? array(),
						'valueResolver' => function ( $value ) {
							return 'icon' === $value ? 'visible' : 'hidden';
						},
					),
					array(
						'selector'      => "{$selector} .dnxte_tab_content_slidebar_one img",
						'data'          => $attrs['misc']['advanced']['useImageOrIconInBody'] ?? array(),
						'valueResolver' => function ( $value ) {
							return 'image' === $value ? 'visible' : 'hidden';
						},
					),
				),
			)
		);
	}
}
