<?php
/**
 * Module: Next Advanced Tab Item  Module class.
 *
 * @package MEE\Modules\NextAdvancedTabItem
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTabItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\NextAdvancedTabItem\NextAdvancedTabItemTrait;

/**
 * `NextAdvancedTabItem` is consisted of functions used for Divi 4 Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextAdvancedTabItem implements DependencyInterface {
	use NextAdvancedTabItemTrait\RenderCallbackTrait;

	/**
	 * Loads `NextAdvancedTabItem` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextAdvancedTabItem/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					array(
						'render_callback' => array( NextAdvancedTabItem::class, 'render_callback' ),
					)
				);
			}
		);
	}
}
