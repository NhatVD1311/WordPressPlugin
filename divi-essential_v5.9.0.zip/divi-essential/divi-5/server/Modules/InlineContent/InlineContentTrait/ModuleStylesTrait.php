<?php
/**
 * InlineContent::module_styles()
 *
 * @package DNXTE\Modules\InlineContent
 * @since ??
 */

namespace DNXTE\Modules\InlineContent\InlineContentTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					$elements->style(
						[
							'attrName' => 'contentWrapper',
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .dnxte-inline-content-items",
							'property' => 'display: flex; flex-wrap: wrap;',
							'attr'     => $attrs['module']['advanced']['text'] ?? [],
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .dnxte-inline-content-items",
							'property' => 'justify-content',
							'attr'     => $attrs['contentWrapper']['advanced']['alignment'] ?? [],
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .dnxte-inline-content-items",
							'property' => 'align-items',
							'attr'     => $attrs['contentWrapper']['advanced']['verticalAlignment'] ?? [],
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .dnxte-inline-content-items",
							'property' => 'gap',
							'attr'     => $attrs['contentWrapper']['advanced']['gap'] ?? [],
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .dnxte-inline-content-items",
							'property' => 'row-gap',
							'attr'     => $attrs['contentWrapper']['advanced']['rowGap'] ?? [],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}
}
