<?php
/**
 * InlineContent::custom_css()
 *
 * @package DNXTE\Modules\InlineContent
 * @since ??
 */

namespace DNXTE\Modules\InlineContent\InlineContentTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	public static function custom_css() {
		return [
			'contentWrapper' => [
				'subName'        => 'contentWrapper',
				'selectorSuffix' => ' .dnxte-inline-content-items',
				'label'          => esc_html__( 'Content Wrapper', 'dnxte-divi-essential' ),
			],
		];
	}
}
