<?php
/**
 * Module: InlineContent parent class.
 *
 * @package DNXTE\Modules\InlineContent
 * @since ??
 */

namespace DNXTE\Modules\InlineContent;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class InlineContent implements DependencyInterface {
	use InlineContentTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'InlineContent/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ InlineContent::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
