<?php
namespace DNXTE\Modules\NextAudio;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class NextAudio implements DependencyInterface {
	use NextAudioTrait\RenderCallbackTrait;

	/**
	 * Additional audio MIME types beyond WordPress defaults.
	 *
	 * WordPress already supports: mp3, ogg, wav, m4a, flac.
	 * We add formats that are valid audio containers but not in WP defaults.
	 *
	 * @var array<string, string>
	 */
	private static $audio_mime_types = array(
		'ogm'  => 'audio/ogg',
		'opus' => 'audio/ogg',
		'aac'  => 'audio/aac',
		'webm' => 'audio/webm',
		'wma'  => 'audio/x-ms-wma',
	);

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextAudio/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					array(
						'render_callback' => array( NextAudio::class, 'render_callback' ),
					)
				);
			}
		);

		// Extend WordPress allowed MIME types for audio uploads.
		add_filter( 'upload_mimes', array( self::class, 'extend_audio_mimes' ) );

		// Handle file type validation for extended audio formats.
		add_filter( 'wp_check_filetype_and_ext', array( self::class, 'check_audio_filetype' ), 10, 4 );
	}

	/**
	 * Add additional audio MIME types to WordPress allowed uploads.
	 *
	 * @param array $mimes Existing MIME types.
	 * @return array Modified MIME types.
	 */
	public static function extend_audio_mimes( array $mimes ): array {
		foreach ( self::$audio_mime_types as $ext => $mime ) {
			if ( ! isset( $mimes[ $ext ] ) ) {
				$mimes[ $ext ] = $mime;
			}
		}

		return $mimes;
	}

	/**
	 * Validate extended audio file types during upload.
	 *
	 * WordPress sometimes fails to identify non-standard file extensions
	 * even when they're in the allowed MIME list. This ensures they pass validation.
	 *
	 * @param array  $check    File type check result.
	 * @param string $file     Full path to the file.
	 * @param string $filename The name of the file.
	 * @param array  $mimes    Allowed MIME types.
	 * @return array Modified check result.
	 */
	public static function check_audio_filetype( $check, $file, $filename, $mimes ) {
		if ( ! empty( $check['type'] ) ) {
			return $check;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		if ( isset( self::$audio_mime_types[ $ext ] ) ) {
			$check['ext']             = $ext;
			$check['type']            = self::$audio_mime_types[ $ext ];
			$check['proper_filename'] = false;
		}

		return $check;
	}
}
