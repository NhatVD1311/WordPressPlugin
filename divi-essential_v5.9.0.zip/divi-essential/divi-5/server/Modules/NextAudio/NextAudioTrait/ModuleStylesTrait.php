<?php
namespace DNXTE\Modules\NextAudio\NextAudioTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;

	/**
	 * Higher-specificity selector bases to beat layout-preset SCSS overrides.
	 * Layout SCSS uses `.dnxte-next-audio-container.layout-xxx .element` (0-3-0).
	 * Adding the container + controls classes gives us 0-4-0, always winning.
	 */
	private static function ctr( $oc ) {
		return $oc . ' .dnxte-next-audio-container';
	}

	private static function ctrl( $oc ) {
		return self::ctr( $oc ) . ' .next_audio__controls';
	}

	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';

		$ctr  = self::ctr( $order_class );
		$ctrl = self::ctrl( $order_class );

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module styles.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
								'disabledOn'               => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					// Title styles.
					$elements->style( [ 'attrName' => 'title' ] ),
					// Artist styles.
					$elements->style( [ 'attrName' => 'artist' ] ),
					// Meta text (Album · Genre · Year) styles.
					$elements->style( [ 'attrName' => 'albumMeta' ] ),
					// Play button styles — 0-4-0 / 0-4-1 specificity.
					$elements->style(
						[
							'attrName'   => 'playButtonSettings',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn svg',
											'attr'      => $attrs['playButtonSettings']['decoration']['iconColor'] ?? [],
											'property'  => 'fill',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn',
											'attr'      => $attrs['playButtonSettings']['decoration']['bgColor'] ?? [],
											'property'  => 'background-color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn',
											'attr'      => $attrs['playButtonSettings']['decoration']['size'] ?? [],
											'property'  => 'width',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn',
											'attr'      => $attrs['playButtonSettings']['decoration']['size'] ?? [],
											'property'  => 'height',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn',
											'attr'      => $attrs['playButtonSettings']['decoration']['size'] ?? [],
											'property'  => 'min-width',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__play_btn',
											'attr'      => $attrs['playButtonSettings']['decoration']['borderRadius'] ?? [],
											'property'  => 'border-radius',
											'important' => true,
										],
									],
								],
							],
						]
					),
					// Progress bar styles — 0-4-0 specificity.
					$elements->style(
						[
							'attrName'   => 'progressBarSettings',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__progress',
											'attr'      => $attrs['progressBarSettings']['decoration']['trackColor'] ?? [],
											'property'  => 'background-color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__progress_filled',
											'attr'      => $attrs['progressBarSettings']['decoration']['fillColor'] ?? [],
											'property'  => 'background-color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__progress',
											'attr'      => $attrs['progressBarSettings']['decoration']['height'] ?? [],
											'property'  => 'height',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__progress',
											'attr'      => $attrs['progressBarSettings']['decoration']['borderRadius'] ?? [],
											'property'  => 'border-radius',
											'important' => true,
										],
									],
								],
							],
						]
					),
					// Volume bar styles — 0-4-0 specificity.
					$elements->style(
						[
							'attrName'   => 'volumeBarSettings',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__volume',
											'attr'      => $attrs['volumeBarSettings']['decoration']['trackColor'] ?? [],
											'property'  => 'background-color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__volume_filled',
											'attr'      => $attrs['volumeBarSettings']['decoration']['fillColor'] ?? [],
											'property'  => 'background-color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__volume',
											'attr'      => $attrs['volumeBarSettings']['decoration']['height'] ?? [],
											'property'  => 'height',
											'important' => true,
										],
									],
								],
							],
						]
					),
					// Controls text color + font — 0-4-0 specificity.
					$elements->style(
						[
							'attrName'   => 'controlsTextSettings',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__current_time, ' . $ctrl . ' .next_audio__duration',
											'attr'      => $attrs['controlsTextSettings']['decoration']['color'] ?? [],
											'property'  => 'color',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__mute_btn svg',
											'attr'      => $attrs['controlsTextSettings']['decoration']['color'] ?? [],
											'property'  => 'fill',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__current_time, ' . $ctrl . ' .next_audio__duration',
											'attr'      => $attrs['controlsTextSettings']['decoration']['fontSize'] ?? [],
											'property'  => 'font-size',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctrl . ' .next_audio__current_time, ' . $ctrl . ' .next_audio__duration',
											'attr'      => $attrs['controlsTextSettings']['decoration']['fontWeight'] ?? [],
											'property'  => 'font-weight',
											'important' => true,
										],
									],
								],
							],
						]
					),
					// Cover image styles — 0-3-0 specificity.
					$elements->style(
						[
							'attrName'   => 'coverImageSettings',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctr . ' .next_audio__cover',
											'attr'      => $attrs['coverImageSettings']['decoration']['width'] ?? [],
											'property'  => 'width',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctr . ' .next_audio__cover',
											'attr'      => $attrs['coverImageSettings']['decoration']['width'] ?? [],
											'property'  => 'min-width',
											'important' => true,
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector'  => $ctr . ' .next_audio__cover',
											'attr'      => $attrs['coverImageSettings']['decoration']['borderRadius'] ?? [],
											'property'  => 'border-radius',
											'important' => true,
										],
									]
								],
							],
						]
					),
					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}
}
