<?php
namespace DNXTE\Modules\NextAudio\NextAudioTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

trait ModuleScriptDataTrait {

	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link'          => $args['attrs']['module']['advanced']['link'] ?? [],
						'audioSrc'      => $args['attrs']['audioSrc']['innerContent']['desktop']['value']['src'] ?? '',
						'mode'          => $args['attrs']['mode']['innerContent']['desktop']['value'] ?? 'single',
						'sourceType'    => $args['attrs']['sourceType']['innerContent']['desktop']['value'] ?? 'media_library',
						'externalUrl'   => $args['attrs']['externalUrl']['innerContent']['desktop']['value'] ?? '',
						'fallbackAudio' => $args['attrs']['fallbackAudio']['innerContent']['desktop']['value']['src'] ?? '',
						'preload'       => $args['attrs']['preload']['innerContent']['desktop']['value'] ?? 'metadata',
						'album'         => $args['attrs']['album']['innerContent']['desktop']['value'] ?? '',
						'genre'         => $args['attrs']['genre']['innerContent']['desktop']['value'] ?? '',
						'year'          => $args['attrs']['year']['innerContent']['desktop']['value'] ?? '',
						'showName'      => $args['attrs']['showName']['innerContent']['desktop']['value'] ?? '',
						'seasonNumber'  => $args['attrs']['seasonNumber']['innerContent']['desktop']['value'] ?? '',
						'episodeNumber' => $args['attrs']['episodeNumber']['innerContent']['desktop']['value'] ?? '',
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		// Enqueue frontend audio player script.
		wp_enqueue_script( 'dnxte-next-audio-script' );
	}
}
