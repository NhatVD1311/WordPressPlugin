<?php
/**
 * NextAudio::render_callback()
 *
 * @package DNXTE\Modules\NextAudio
 * @since   ??
 */

namespace DNXTE\Modules\NextAudio\NextAudioTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Front-end render callback.
	 *
	 * @since ??
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		$background_component = ElementComponents::component(
			[
				'attrs'         => $attrs['module']['decoration'] ?? [],
				'id'            => $block->parsed_block['id'],
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);

		// ── Layout & Mode ───────────────────────────────────────────────────────
		$layout   = $attrs['layout']['innerContent']['desktop']['value']['select'] ?? 'card';
		$autoplay = ( $attrs['enableAutoplay']['advanced']['use']['desktop']['value'] ?? 'off' ) === 'on';
		$loop     = ( $attrs['enableLoop']['advanced']['use']['desktop']['value'] ?? 'off' ) === 'on';

		// ── Source Type & URLs ──────────────────────────────────────────────────
		$source_type   = $attrs['sourceType']['innerContent']['desktop']['value']['select'] ?? 'media_library';
		$media_lib_src = $attrs['audioSrc']['innerContent']['desktop']['value']['src'] ?? '';
		$external_url  = $attrs['audioExternalUrl']['innerContent']['desktop']['value']['url'] ?? '';
		$fallback_src  = $attrs['fallbackUrl']['innerContent']['desktop']['value']['src'] ?? '';
		$preload       = $attrs['preload']['innerContent']['desktop']['value']['select'] ?? 'metadata';
		$audio_url     = 'external_url' === $source_type ? $external_url : $media_lib_src;

		// ── Cover Image ─────────────────────────────────────────────────────────
		$cover_url        = $attrs['coverImage']['innerContent']['desktop']['value']['src'] ?? '';
		$show_cover_image = ( $attrs['showCoverImage']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';

		// ── Controls visibility ──────────────────────────────────────────────────
		$show_current_time  = ( $attrs['showCurrentTime']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';
		$show_duration      = ( $attrs['showDuration']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';
		$show_volume_button = ( $attrs['showVolumeButton']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';
		$show_volume_bar    = ( $attrs['showVolumeBar']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';

		// ── Track Info show/hide toggles (Step 4) ───────────────────────────────
		$show_title      = ( $attrs['showTitle']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';
		$show_artist     = ( $attrs['showArtist']['advanced']['use']['desktop']['value'] ?? 'on' ) !== 'off';
		$show_album_name = ( $attrs['showAlbumName']['advanced']['use']['desktop']['value'] ?? 'off' ) === 'on';
		$show_genre      = ( $attrs['showGenre']['advanced']['use']['desktop']['value'] ?? 'off' ) === 'on';
		$show_year       = ( $attrs['showYear']['advanced']['use']['desktop']['value'] ?? 'off' ) === 'on';

		$album_name = $attrs['albumName']['innerContent']['desktop']['value'] ?? '';
		$genre      = $attrs['genre']['innerContent']['desktop']['value'] ?? '';
		$year       = $attrs['year']['innerContent']['desktop']['value'] ?? '';

		// ── Rendered inline text elements ────────────────────────────────────────
		$title_html  = $show_title  ? $elements->render( [ 'attrName' => 'title' ] )  : '';
		$artist_html = $show_artist ? $elements->render( [ 'attrName' => 'artist' ] ) : '';

		// ── Album · Genre · Year meta line ───────────────────────────────────────
		$meta_html = '';
		$meta_parts = [];
		if ( $show_album_name && $album_name ) $meta_parts[] = $album_name;
		if ( $show_genre      && $genre )      $meta_parts[] = $genre;
		if ( $show_year       && $year )        $meta_parts[] = $year;

		if ( ! empty( $meta_parts ) ) {
			$meta_html = HTMLUtility::render(
				[
					'tag'               => 'p',
					'attributes'        => [ 'class' => 'next_audio__meta' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => esc_html( implode( ' · ', $meta_parts ) ),
				]
			);
		}

		// ── Play / Pause button ─────────────────────────────────────────────────
		$play_icon  = '<svg class="next_audio__play_icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
		$pause_icon = '<svg class="next_audio__pause_icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>';

		$play_button = HTMLUtility::render(
			[
				'tag'               => 'button',
				'attributes'        => [
					'class'      => 'next_audio__play_btn',
					'type'       => 'button',
					'aria-label' => 'Play',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $play_icon . $pause_icon,
			]
		);

		// ── Current time ───────────────────────────────────────────────────────
		$current_time_html = '';
		if ( $show_current_time ) {
			$current_time_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'next_audio__current_time', 'aria-live' => 'off' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => '00:00',
				]
			);
		}

		// ── Progress bar ───────────────────────────────────────────────────────
		$progress_filled = HTMLUtility::render(
			[
				'tag'        => 'div',
				'attributes' => [ 'class' => 'next_audio__progress_filled', 'style' => 'width:0%' ],
			]
		);

		$progress_bar = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'         => 'next_audio__progress',
					'role'          => 'slider',
					'aria-label'    => 'Audio progress',
					'aria-valuemin' => '0',
					'aria-valuemax' => '100',
					'aria-valuenow' => '0',
					'tabindex'      => '0',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $progress_filled,
			]
		);

		// ── Duration ───────────────────────────────────────────────────────────
		$duration_html = '';
		if ( $show_duration ) {
			$duration_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'next_audio__duration' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => '00:00',
				]
			);
		}

		// ── Volume / Mute button ───────────────────────────────────────────────
		$volume_icon = '<svg class="next_audio__volume_icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>';
		$mute_icon   = '<svg class="next_audio__mute_icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>';

		$mute_button_html = '';
		if ( $show_volume_button ) {
			$mute_button_html = HTMLUtility::render(
				[
					'tag'               => 'button',
					'attributes'        => [
						'class'      => 'next_audio__mute_btn',
						'type'       => 'button',
						'aria-label' => 'Mute',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $volume_icon . $mute_icon,
				]
			);
		}

		// ── Volume bar ─────────────────────────────────────────────────────────
		$volume_bar_html = '';
		if ( $show_volume_bar ) {
			$volume_filled = HTMLUtility::render(
				[
					'tag'        => 'div',
					'attributes' => [ 'class' => 'next_audio__volume_filled', 'style' => 'width:80%' ],
				]
			);

			$volume_bar_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [
						'class'         => 'next_audio__volume',
						'role'          => 'slider',
						'aria-label'    => 'Volume',
						'aria-valuemin' => '0',
						'aria-valuemax' => '100',
						'aria-valuenow' => '80',
						'tabindex'      => '0',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $volume_filled,
				]
			);
		}

		// ── Controls row ───────────────────────────────────────────────────────
		$controls = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'next_audio__controls' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $play_button . $current_time_html . $progress_bar . $duration_html . $mute_button_html . $volume_bar_html,
			]
		);

		// ── Info section ────────────────────────────────────────────────────────
		$info_section = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'next_audio__info' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $title_html . $artist_html . $meta_html . $controls,
			]
		);

		// ── Cover image ────────────────────────────────────────────────────────
		$cover_html = '';
		if ( $show_cover_image && $cover_url ) {
			$cover_img = HTMLUtility::render(
				[
					'tag'        => 'img',
					'attributes' => [
						'src'   => esc_url( $cover_url ),
						'alt'   => '',
						'class' => 'next_audio__cover_img',
					],
				]
			);

			$cover_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'next_audio__cover' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $cover_img,
				]
			);
		}

		// ── Audio element with primary + fallback sources ───────────────────────
		$audio_tag = '';
		if ( $audio_url ) {
			$audio_attrs = [
				'class'   => 'next_audio__audio_element',
				'preload' => esc_attr( $preload ),
			];
			if ( $autoplay ) {
				$audio_attrs['autoplay'] = 'autoplay';
				$audio_attrs['muted']    = 'muted'; // Required for browser autoplay policy.
			}
			if ( $loop ) {
				$audio_attrs['loop'] = 'loop';
			}

			$sources = HTMLUtility::render(
				[ 'tag' => 'source', 'attributes' => [ 'src' => esc_url( $audio_url ) ] ]
			);
			if ( $fallback_src ) {
				$sources .= HTMLUtility::render(
					[ 'tag' => 'source', 'attributes' => [ 'src' => esc_url( $fallback_src ) ] ]
				);
			}

			$audio_tag = HTMLUtility::render(
				[
					'tag'               => 'audio',
					'attributes'        => $audio_attrs,
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $sources,
				]
			);
		}

		// ── Container ──────────────────────────────────────────────────────────
		$container_class = 'dnxte-next-audio-container layout-' . sanitize_html_class( $layout );
		if ( ! $show_cover_image || ! $cover_url ) {
			$container_class .= ' no-cover';
		}

		$module_content = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'             => $container_class,
					'data-source-type'  => esc_attr( $source_type ),
					'data-audio-src'    => esc_url( $audio_url ),
					'data-fallback-src' => $fallback_src ? esc_url( $fallback_src ) : '',
					'data-preload'      => esc_attr( $preload ),
					'data-autoplay'     => $autoplay ? 'on' : 'off',
					'data-loop'         => $loop ? 'on' : 'off',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $info_section . $cover_html . $audio_tag,
			]
		);

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => $background_component . $module_content,
			]
		);
	}
}
