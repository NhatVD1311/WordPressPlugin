<?php
/**
 * Module: NextChartDataset class.
 *
 * @package DNXTE\Modules\NextChartDataset
 * @since ??
 */

namespace DNXTE\Modules\NextChartDataset;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class NextChartDataset implements DependencyInterface {
	use NextChartDatasetTrait\RenderCallbackTrait;

	/**
	 * Loads NextChartDataset and registers Front-End render callback.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextChartDataset/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextChartDataset::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
