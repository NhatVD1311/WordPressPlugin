<?php
/**
 * NextChartDataset::custom_css().
 *
 * @package DNXTE\Modules\NextChartDataset
 * @since ??
 */

namespace DNXTE\Modules\NextChartDataset\NextChartDatasetTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/next-chart-dataset' )->customCssFields;
	}

}
