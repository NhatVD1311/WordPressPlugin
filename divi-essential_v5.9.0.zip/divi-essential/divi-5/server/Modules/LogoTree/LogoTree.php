<?php
namespace DNXTE\Modules\LogoTree;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\LogoTree\LogoTreeTrait;

class LogoTree implements DependencyInterface {
	use LogoTreeTrait\RenderCallbackTrait;

	/**
	 * Store children node data for MultiView script data.
	 *
	 * @var array
	 */
	public static $child_node_data = [];

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'LogoTree/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ LogoTree::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
