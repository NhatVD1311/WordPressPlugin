<?php
namespace DNXTE\Modules\LogoTree\LogoTreeTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/logo-tree' );
		return $block_type ? ( $block_type->customCssFields ?? array() ) : array();
	}
}
