<?php
namespace DNXTE\Modules\LogoTree\LogoTreeTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

trait ModuleScriptDataTrait {
	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		// MultiView for per-node responsive values
		$child_node_data = \DNXTE\Modules\LogoTree\LogoTree::$child_node_data;
		$set_attrs       = [];

		foreach ( $child_node_data as $i => $node_data ) {
			$set_attrs[] = [
				'selector'      => $selector . ' .logo-tree-node-' . $i,
				'data'          => array(
					'data-node-size'  => $node_data['nodeSize'] ?? [],
					'data-position-x' => $node_data['positionX'] ?? [],
					'data-position-y' => $node_data['positionY'] ?? [],
				),
				'valueResolver' => function( $value ) {
					return $value ?? '';
				},
			];
		}

		if ( ! empty( $set_attrs ) ) {
			MultiViewScriptData::set(
				[
					'id'            => $id,
					'name'          => $name,
					'hoverSelector' => $selector,
					'setAttrs'      => $set_attrs,
					'storeInstance' => $store_instance,
				]
			);
		}

		wp_enqueue_script( 'dnxte_logo_tree' );
	}
}
