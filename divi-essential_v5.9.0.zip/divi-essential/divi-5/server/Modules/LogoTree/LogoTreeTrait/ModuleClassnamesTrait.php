<?php
namespace DNXTE\Modules\LogoTree\LogoTreeTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait ModuleClassnamesTrait {
	public static function module_classnames( $args ) {
		// No dynamic classnames needed
	}
}
