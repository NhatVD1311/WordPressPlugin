<?php
namespace DNXTE\Modules\LogoTree\LogoTreeTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use CustomCssTrait;

	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Extract tree settings
		$bg_effect       = $attrs['treeSettings']['advanced']['bgEffect']['desktop']['value'] ?? 'particles';
		$line_style      = $attrs['treeSettings']['advanced']['lineStyle']['desktop']['value'] ?? 'bezier';
		$particle_count  = $attrs['treeSettings']['advanced']['particleCount']['desktop']['value'] ?? '80';
		$line_color      = $attrs['treeSettings']['advanced']['lineColor']['desktop']['value'] ?? 'rgba(139, 92, 246, 0.6)';
		$line_glow_color = $attrs['treeSettings']['advanced']['lineGlowColor']['desktop']['value'] ?? 'rgba(139, 92, 246, 0.3)';
		$particle_color  = $attrs['treeSettings']['advanced']['particleColor']['desktop']['value'] ?? 'rgba(139, 92, 246, 0.4)';
		$flow_dot_color  = $attrs['treeSettings']['advanced']['flowDotColor']['desktop']['value'] ?? '#a78bfa';

		// Main logo
		$main_logo_val  = $attrs['mainLogo']['innerContent']['desktop']['value'] ?? [];
		$main_logo_src  = is_array( $main_logo_val ) ? ( $main_logo_val['src'] ?? '' ) : '';
		$main_logo_text = $attrs['mainLogoText']['innerContent']['desktop']['value'] ?? 'MyBrand';

		// Build node HTML from children
		$node_html_items = '';
		$child_node_data = [];

		if ( ! empty( $block->parsed_block['innerBlocks'] ) ) {
			foreach ( $block->parsed_block['innerBlocks'] as $i => $inner_block ) {
				$child_attrs = $inner_block['attrs'] ?? [];
				$icon_val    = $child_attrs['nodeIcon']['innerContent']['desktop']['value'] ?? [];
				$icon_src    = is_array( $icon_val ) ? ( $icon_val['src'] ?? '' ) : '';
				$label       = $child_attrs['itemConfig']['advanced']['label']['desktop']['value'] ?? '';
				$link        = $child_attrs['itemConfig']['advanced']['link']['desktop']['value'] ?? '';
				$child_node_size = $child_attrs['itemConfig']['advanced']['nodeSize']['desktop']['value'] ?? '65';
				$child_pos_x     = $child_attrs['itemConfig']['advanced']['positionX']['desktop']['value'] ?? '-1';
				$child_pos_y     = $child_attrs['itemConfig']['advanced']['positionY']['desktop']['value'] ?? '-1';
				$child_img_size     = $child_attrs['itemConfig']['advanced']['imageSize']['desktop']['value'] ?? '';
				$child_bg_color     = $child_attrs['itemConfig']['advanced']['bgColor']['desktop']['value'] ?? '';
				$child_border_width = $child_attrs['itemConfig']['advanced']['borderWidth']['desktop']['value'] ?? '';
				$child_border_color = $child_attrs['itemConfig']['advanced']['borderColor']['desktop']['value'] ?? '';
				$child_border_style = $child_attrs['itemConfig']['advanced']['borderStyle']['desktop']['value'] ?? 'solid';

				// Store for MultiView
				$child_node_data[] = [
					'nodeSize'  => $child_attrs['itemConfig']['advanced']['nodeSize'] ?? [],
					'positionX' => $child_attrs['itemConfig']['advanced']['positionX'] ?? [],
					'positionY' => $child_attrs['itemConfig']['advanced']['positionY'] ?? [],
				];

				$node_attributes = [
					'class'           => 'logo-tree-node logo-tree-node-' . $i,
					'data-node-label' => $label,
					'data-node-size'  => $child_node_size,
					'data-position-x' => $child_pos_x,
					'data-position-y' => $child_pos_y,
				];

				if ( '' !== $child_border_width ) {
					$border_color              = '' !== $child_border_color ? $child_border_color : 'rgba(255,255,255,0.5)';
					$border_style              = '' !== $child_border_style ? $child_border_style : 'solid';
					$node_attributes['style']  = 'border:' . esc_attr( $child_border_width ) . ' ' . esc_attr( $border_style ) . ' ' . esc_attr( $border_color ) . ';';
				}

				if ( $link ) {
					$node_attributes['data-node-link'] = $link;
				}

				$icon_html = '';
				if ( $icon_src ) {
					$img_attributes = [
						'src'   => $icon_src,
						'alt'   => $label,
						'class' => 'logo-tree-node-icon-img',
					];
					if ( '' !== $child_img_size ) {
						// !important so a per-node size overrides the global !important size rule.
						$img_attributes['style'] = 'width:' . esc_attr( $child_img_size ) . ' !important;height:' . esc_attr( $child_img_size ) . ' !important;';
					}
					$icon_html = HTMLUtility::render(
						[
							'tag'        => 'img',
							'attributes' => $img_attributes,
						]
					);
				}

				$inner_attributes = [ 'class' => 'logo-tree-node-inner' ];
				if ( '' !== $child_bg_color ) {
					$inner_attributes['style'] = 'background:' . esc_attr( $child_bg_color ) . ';';
				}
				$inner_html = HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => $inner_attributes,
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $icon_html,
					]
				);

				$label_html = $label ? HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => [ 'class' => 'logo-tree-node-label' ],
						'childrenSanitizer' => 'esc_html',
						'children'          => $label,
					]
				) : '';

				$node_html_items .= HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => $node_attributes,
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $inner_html . $label_html,
					]
				);
			}
		}

		// Store for MultiView script data
		\DNXTE\Modules\LogoTree\LogoTree::$child_node_data = $child_node_data;

		// Main logo HTML
		$main_icon_html = '';
		if ( $main_logo_src ) {
			$main_icon_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'logo-tree-main-icon' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => HTMLUtility::render(
						[
							'tag'        => 'img',
							'attributes' => [
								'src' => $main_logo_src,
								'alt' => $main_logo_text,
							],
						]
					),
				]
			);
		}

		$main_text_html = '';
		if ( ! empty( $main_logo_text ) ) {
			$main_text_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'logo-tree-main-text' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => $main_logo_text,
				]
			);
		}

		$main_logo_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'logo-tree-main' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $main_icon_html . $main_text_html,
			]
		);

		// Container
		$container_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'                => 'logo-tree-container',
					'data-logo-tree'       => true,
					'data-tree-background' => $bg_effect,
					'data-tree-line-style' => $line_style,
					'data-tree-particles'  => $particle_count,
					'data-line-color'      => $line_color,
					'data-line-glow-color' => $line_glow_color,
					'data-particle-color'  => $particle_color,
					'data-flow-dot-color'  => $flow_dot_color,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $main_logo_html . $node_html_items,
			]
		);

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'className'           => 'dnxte-logo-tree',
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $container_html . $content,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
