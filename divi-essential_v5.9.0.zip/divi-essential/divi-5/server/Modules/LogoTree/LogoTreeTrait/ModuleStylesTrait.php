<?php
namespace DNXTE\Modules\LogoTree\LogoTreeTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];

		$base_styles = [
			$elements->style(
				[
					'attrName'   => 'module',
					'styleProps' => [
						'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
						'disabledOn'               => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				]
			),
			$elements->style(
				[
					'attrName'   => 'mainLogoWrapper',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['mainLogoWrapper']['advanced']['heightWidth'] ?? [],
									'property'  => 'width',
									'important' => true,
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['mainLogoWrapper']['advanced']['heightWidth'] ?? [],
									'property'  => 'height',
									'important' => true,
								],
							],
						],
					],
				]
			),
			$elements->style(
				[
					'attrName'   => 'mainLogoImage',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['mainLogoImage']['advanced']['size'] ?? [],
									'property'  => 'width',
									'important' => true,
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['mainLogoImage']['advanced']['size'] ?? [],
									'property'  => 'height',
									'important' => true,
								],
							],
						],
					],
				]
			),
			
			$elements->style( [ 'attrName' => 'mainLogo' ] ),
			$elements->style( [ 'attrName' => 'mainLogoText' ] ),
			$elements->style( [ 'attrName' => 'nodeWrapper' ] ),
			$elements->style(
				[
					'attrName'   => 'nodeImage',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['nodeImage']['advanced']['size'] ?? [],
									'property'  => 'width',
									'important' => true,
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['nodeImage']['advanced']['size'] ?? [],
									'property'  => 'height',
									'important' => true,
								],
							],
						],
					],
				]
			),
			$elements->style( [ 'attrName' => 'nodeLabelStyle' ] ),
			CssStyle::style(
				[
					'selector'  => $args['orderClass'],
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => self::custom_css(),
				]
			),
		];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $base_styles,
			]
		);
	}
}
