<?php
/**
 * Lottie::render_callback()
 *
 * @package MEE\Modules\Lottie
 * @since ??
 */

 namespace DNXTE\Modules\Divider\DividerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use DNXTE\Modules\Divider\Divider;
use DNXTE\Modules\Divider\DividerTrait\StyleDeclarationTrait;
use WP_Block;
use DNXTE\Modules\Lottie\Lottie;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use StyleDeclarationTrait;
	/**
	 * module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( array $attrs, string $content, WP_Block $block, ModuleElements $elements, array $default_printed_style_attrs ):string {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];
		$use_icon     = $attrs['icon']['advanced']['use']['desktop']['value'] ?? 'on';
		$icon_value   = Utils::process_font_icon($attrs['icon']['advanced']['icon']['desktop']['value'] ?? '');
		$image_src 	  = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';

		$alignment_desktop 	= $attrs['icon']['decoration']['alignment']['desktop']['value'] ?? 'center';
		$alignment_tablet 	= $attrs['icon']['decoration']['alignment']['tablet']['value'] ?? $alignment_desktop;
		$alignment_phone 	= $attrs['icon']['decoration']['alignment']['phone']['value'] ?? $alignment_tablet;

		if ( 'on' === $use_icon && $image_src == '' ) {
			$icon = sprintf(
				'<span class="dnext-sid-text-divider-icon">%1$s</span>',
				$icon_value
			);
		} else {
			$icon = sprintf(
				'<img src="%1$s" alt="" class="dnext_sid_image_max_width">',
				esc_url( $image_src )
			);
		}

		$divider_child = sprintf( 
			'
				<div class="dnext-sid-text-divider-before dnext-sid-text-divider"></div>
				%1$s
				<div class="dnext-sid-text-divider-after dnext-sid-text-divider"></div>
			',$icon );

		$divider_wrapper = HTMLUtility::render(
            [
              'tag'               =>  'div',
              'attributes'        =>  [
                'class'         => 'et_pb_module_inner',
              ],
              'childrenSanitizer' =>  'et_core_esc_previously',
              'children'          =>  [
                HTMLUtility::render(
                  [
                    'tag'               => 'div',
                    'attributes'        => [
					  'class'           => HTMLUtility::classnames(
						[
							'dnext-sid-text-divider-wrapper' => true,
							"dnext-sid-text-divider-alignment-{$alignment_desktop}" => ! empty( $alignment_desktop ),
							"dnext-sid-text-divider-alignment-{$alignment_tablet}_tablet" => ! empty( $alignment_tablet ),
							"dnext-sid-text-divider-alignment-{$alignment_phone}_phone" => ! empty( $alignment_phone ),
						]
					  ), 
                    ],
                    'childrenSanitizer' =>  'et_core_esc_previously',
                    'children'          => [ $divider_child ]
                  ]
                )
              ],
            ]
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ Divider::class, 'module_classnames' ],
				'stylesComponent'     => [ Divider::class, 'module_styles' ],
				'scriptDataComponent' => [ Divider::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
                'hasModuleWrapper'    => false,
				'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $divider_wrapper
			]
		);
	}

}
