<?php
/**
 * DualButton::render_callback()
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

 namespace DNXTE\Modules\Divider\DividerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use Exception;

trait StyleDeclarationTrait {
	public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
				],
			]
		);


		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		if ( ! empty( $icon_attr['unicode'] ) ) {
			$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		}

		return $style_declarations->value();
	}

	public static function icon_design_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-size' => false,
				],
			]
		);


		if ( isset( $icon_attr['size'] ) ) {
			$style_declarations->add( 'font-size', $icon_attr['size'] );
		}

		if ( ! empty( $icon_attr['color'] ) ) {
			$style_declarations->add( 'color', $icon_attr['color'] );
		}

		return $style_declarations->value();
	}
}