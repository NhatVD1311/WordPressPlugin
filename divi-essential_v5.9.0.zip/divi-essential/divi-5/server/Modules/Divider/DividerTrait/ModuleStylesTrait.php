<?php
/**
 * DualButton::module_styles().
 *
 * @package MEE\Modules\DualButton
 * @since ??
 */

namespace DNXTE\Modules\Divider\DividerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use StyleDeclarationTrait;
	public static function applyHoverStyles($selector, $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass) {
		$styles = [];
	
		$styles[] = CommonStyle::style(
			[
				'selector' => "{$orderClass} {$selector}",
				'property' => 'background',
				'attr'     => $mainBackgroundAttr,
			]
		);
	
		$styles[] = CommonStyle::style(
			[
				'selector' => "{$orderClass} {$selector}:before",
				'property' => 'background',
				'attr'     => $beforeBackgroundAttr,
			]
		);
	
		return $styles;
	
	}

	/**
	 * Lottie module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/Lottie/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';
		
		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array_merge(
					[
						$elements->style(
							[
								'attrName'   => 'module',
								'styleProps' => [
									'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
									'disabledOn'               => [
										'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
									],
								],
							]
						),
						$elements->style(
							['attrName' => 'dnext_sid_divider_style']
						),
						$elements->style(
							[
								'attrName' => 'image',
								'styleProps'=> [
									'advancedStyles' => [
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnext_sid_image_max_width",
												'attr'=> $attrs['image']['decoration']['dnext_sid_image_max_width'] ?? [],
												'property'=> 'width',
											]
										]
									]
								]
							]
						),
						$elements->style(
							[
								'attrName' => 'icon',
								'styleProps'=> [
									'advancedStyles' => [
										[
											'componentName'=> 'divi/common',
											'props'=>[
												'selector'=> "{$args['orderClass']} .dnext-sid-text-divider-icon",
												'attr'=> $attrs['icon']['advanced']['color'] ?? [],
												'property'=> 'color',
											]
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnext-sid-text-divider-icon",
												'attr'     => $attrs['icon']['advanced']['icon'] ?? [],
												'declarationFunction' => [ self::class, 'icon_style_declaration' ],
											],
										],
										[
											'componentName' => 'divi/common',
											'props'         => [
												'selector' => "{$args['orderClass']} .dnext-sid-text-divider-icon",
												'attr'     => $attrs['icon']['decoration'] ?? [],
												'declarationFunction' => [ self::class, 'icon_design_declaration' ],
											],
										]
									]
								]
							]
						),
						CssStyle::style(
							[
								'selector'  => $args['orderClass'],
								'attr'      => $attrs['css'] ?? [],
								'cssFields' => self::custom_css(),
							]
						),
						TextStyle::style(
							[
								'selector' => $order_class . ' .example_d4_module_inner',
								'attr'     => $attrs['module']['advanced']['text'] ?? [],
							]
						)
					],
				)
			]
		);

	}

}
