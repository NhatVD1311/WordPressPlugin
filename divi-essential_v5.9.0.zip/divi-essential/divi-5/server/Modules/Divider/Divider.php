<?php
/**
 * Module: Divi Divider Module class.
 *
 * @package MEE\Modules\Divider
 * @since ??
 */

namespace DNXTE\Modules\Divider;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\Divider\DividerTrait;

/**
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class Divider implements DependencyInterface {
	use DividerTrait\RenderCallbackTrait;

	/**
	 * Loads `DualButton` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextDivider/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ Divider::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
