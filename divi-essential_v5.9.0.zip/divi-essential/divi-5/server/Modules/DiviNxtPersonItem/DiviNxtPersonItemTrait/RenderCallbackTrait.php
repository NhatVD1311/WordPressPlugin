<?php

/**
 * DiviNxtPersonItem::render_callback()
 *
 * @package MEE\Modules\DiviNxtPersonItem
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtPersonItem\DiviNxtPersonItemTrait;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\DiviNxtPersonItem\DiviNxtPersonItem;

trait RenderCallbackTrait
{
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;

	/**
	 * DiviNxtPersonItem render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param WP_Block       $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Child module.
	 */
	public static function render_callback($attrs, $content, $block, $elements)
	{
		$parent = BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);

		$parent_attrs = $parent->attrs ?? [];

		$parent_default_attributes = ModuleRegistration::get_default_attrs('dnxte/person');
		$parent_attrs_with_default = array_replace_recursive($parent_default_attributes, $parent_attrs);

		$icon_class = isset($attrs['social_icon']['advanced']['listIcon']['desktop']['value']) ? $attrs['social_icon']['advanced']['listIcon']['desktop']['value'] : '';
		$social_url = isset($attrs['social_icon']['advanced']['url']['desktop']['value']['url']) ? $attrs['social_icon']['advanced']['url']['desktop']['value']['url'] : '#';

		$skypeAccount = isset($attrs['skype']['innerContent']['desktop']['value']) ? $attrs['skype']['innerContent']['desktop']['value'] : '';
		$skypeAction = isset($attrs['skype']['advanced']['use']['desktop']['value']) ? $attrs['skype']['advanced']['use']['desktop']['value'] : '';
		if ('skype' === $icon_class) {
			$social_url = sprintf(
				'skype:%1$s?%2$s',
				sanitize_text_field($skypeAccount),
				sanitize_text_field($skypeAction)
			);
		}


		// Icon value.
		$icon_value = isset($attrs['social_icon']['advanced']['icon']['desktop']['value']) ? $attrs['social_icon']['advanced']['icon']['desktop']['value'] : '';
		$icon = Utils::process_font_icon($icon_value) ?? '';



		$span = HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [$icon]
			]
		);
		$netwrok_container       = HTMLUtility::render(
			[
				'tag'               => 'a',
				'attributes'        => [
					'href'  => esc_url($social_url),
					'class' => 'dnext-person-social-icon dnext-person-' . $icon_class,

				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => [$span]
			]
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [DiviNxtPersonItem::class, 'module_classnames'],
				'stylesComponent'    => [DiviNxtPersonItem::class, 'module_styles'],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				'tag'                => 'li',
				'children'           => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $netwrok_container,
			]
		);
	}
}
