<?php
/**
 * DiviNxtPersonItem::module_styles().
 *
 * @package Builder\Packages\ModuleLibrary
 * @since ??
 */

namespace DNXTE\Modules\DiviNxtPersonItem\DiviNxtPersonItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\DiviNxtPersonItem\DiviNxtPersonItem;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	/**
	 * DiviNxtPersonItem's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/DiviNxtPersonItem/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];

		$parent_default_attributes = ModuleRegistration::get_default_attrs( 'dnxte/person' );
		$parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );

		$social_network = $attrs['socialNetwork']['innerContent']['desktop']['value'] ?? '';
		$icon_selector   = "{$order_class} .dnext-person-social-icon span";
		$icon_size		= isset($attrs['social_icon']['advanced']['size']['desktop']['value']) ? $attrs['social_icon']['advanced']['size']['desktop']['value'] : '';
		// Lands unescaped in the page <style> block — validate (see DNXTE\Shared\CssGradient).
		$icon_size		= \DNXTE\Shared\CssGradient::safe_length( $icon_size );

		$social_network_icon_selector = "{$order_class} .dnext-person-{$social_network} span::before";

		$content_container_selector = "{$order_class} .example_child_module__content-container";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					TextStyle::style(
						[
							'selector' => $content_container_selector,
							'attr'     => $attrs['module']['advanced']['text'] ?? [],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					// iconContainer.
					$elements->style(
						[
							'attrName' => 'iconContainer',
						]
					),

					// Icon.
					CommonStyle::style(
						[
							'selector'            => $icon_selector,
							'attr'                => $attrs['social_icon']['advanced']['icon'] ?? [],
							'declarationFunction' => [DiviNxtPersonItem::class, 'icon_font_declaration'],
						]
					),
					CommonStyle::style(
						[
							'selector' => $icon_selector,
							'attr'     => $attrs['social_icon']['advanced']['color'] ?? [],
							'property' => 'color',
						]
					),
					CommonStyle::style(
						[
							'selector' => $icon_selector,
							'attr'     => $attrs['social_icon']['advanced']['size'] ?? [],
							'property' => "width:calc({$icon_size} * 2);height:calc({$icon_size} * 2);line-hight:calc({$icon_size} * 2);font-size",
						]
					),
					$elements->style(
						[
							'attrName' => 'social_icon',
						]
					),
				],
			]
		);
	}

}
