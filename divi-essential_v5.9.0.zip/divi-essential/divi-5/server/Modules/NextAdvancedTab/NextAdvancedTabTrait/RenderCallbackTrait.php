<?php
/**
 * NextAdvancedTab::render_callback()
 *
 * @package MEE\Modules\NextAdvancedTab
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\Base\Traits\CommonTrait as BaseCommonTrait;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	use CommonTrait;
	use BaseCommonTrait;

	/**
	 * Divi 4 module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$child = $block->parsed_block['innerBlocks'] ?? array();

		// Background component.
		$background_component = ElementComponents::component(
			array(
				'attrs'         => $attrs['module']['decoration'] ?? array(),
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			)
		);

		$tab_hover_effect = $attrs['tabs']['advanced']['hoverEffect']['desktop']['value'] ?? 'none';

		// How a tab becomes active on the front-end: 'click' (default) or 'hover'.
		$tab_change_on = $attrs['tabs']['advanced']['changeOn']['desktop']['value'] ?? 'click';
		$tab_change_on = 'hover' === $tab_change_on ? 'hover' : 'click';

		// Block info for MultiView support
		$block_info = [
			'id'            => $block->parsed_block['id'],
			'name'          => $block->block_type->name,
			'storeInstance' => $block->parsed_block['storeInstance'],
		];

		$tab_html = self::get_tab_html( $child, $tab_hover_effect, $block_info );

		$html = sprintf(
			'<div class="tab-container dnxte_tab_wrapper">
            <div class="dnxte_tab_menu" data-tab-effect="%3$s" data-tab-change-on="%4$s">
               %1$s
            </div>
                <div class="dnxte_body_content_wrapper">
                    %2$s
				</div>
            </div>',
			$tab_html,
			$content,
			esc_attr( $tab_hover_effect ),
			esc_attr( $tab_change_on )
		);

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => $background_component . $html,
			)
		);
	}
}
