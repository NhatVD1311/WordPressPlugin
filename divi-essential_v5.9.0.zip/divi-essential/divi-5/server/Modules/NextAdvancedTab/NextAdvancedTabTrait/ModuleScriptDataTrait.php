<?php
/**
 * NextAdvancedTab::module_script_data()
 *
 * @package MEE\Modules\NextAdvancedTab
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		// Assign variables.
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? array();
		$store_instance = $args['storeInstance'] ?? null;

		// Module decoration attributes.
		$module_decoration_attrs = $attrs['module']['decoration'] ?? array();

		ElementScriptData::set(
			array(
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					array(
						'link' => $args['attrs']['module']['advanced']['link'] ?? array(),
					)
				),
				'storeInstance' => $store_instance,
			)
		);

		// MultiView for responsive hover effect.
		MultiViewScriptData::set(
			array(
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setAttrs'      => array(
					array(
						'selector'      => $selector . ' .dnxte_tab_menu',
						'data'          => array(
							'data-tab-effect' => $attrs['tabs']['advanced']['hoverEffect'] ?? array(),
						),
						'valueResolver' => function ( $value ) {
							return $value ?? 'none';
						},
					),
					array(
						'selector'      => $selector . ' .dnxte_tab_wrapper .dnxte_tab_menu li',
						'data'          => $attrs['tabs']['advanced']['fullwidth'] ?? array(),
						'valueResolver' => function ( $value ) {
							return $value;
						},
					),
				),
				'storeInstance' => $store_instance,
			)
		);
	}
}
