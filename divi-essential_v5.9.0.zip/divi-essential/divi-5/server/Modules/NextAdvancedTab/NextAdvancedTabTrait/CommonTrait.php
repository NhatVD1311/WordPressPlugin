<?php
/**
 * NextAdvancedTab::custom_css().
 *
 * @package MEE\Modules\NextAdvancedTab
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use DNXTE\Modules\Base\Traits\CommonTrait as BaseCommonTrait;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewElement;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewElementValue;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

trait CommonTrait {
	use BaseCommonTrait;

	/**
	 * Get tab HTML with optional MultiView support.
	 *
	 * @param array  $childs           Child blocks.
	 * @param string $tab_hover_effect Tab hover effect value.
	 * @param array  $block_info       Optional. Block info for MultiView support.
	 *
	 * @return string Tab HTML.
	 */
	public static function get_tab_html( $childs, $tab_hover_effect, $block_info = [] ) {
		$html = '<ul>';

		$self = new self();

		$child_default_attrs = ModuleRegistration::get_default_attrs( 'dnxte/advanced-tab-item' );

		foreach ( $childs as $child ) {
			$attrs = array_replace_recursive( $child_default_attrs, $child['attrs'] ?? array() );
			$tab_icon  = $self->get_tab_icon( $attrs );
			$tab_image = $self->get_tab_image( $attrs, $block_info ) . $self->get_tab_svg( $attrs );
			
			$module_link = $attrs['module']['advanced']['link']['desktop']['value']['url'] ?? '#';
			$clickable_class = $module_link === '#' ? '' : ' dnxte_tab_a_clickable';
			$module_link_target = $attrs['module']['advanced']['link']['desktop']['value']['target'] ?? '_self';

			$html .= sprintf(
				'<li class="%1$s">
                    <a href="%8$s" %9$s class="dnxte_tab_a dnxt-hover-ad-%6$s %10$s"
                        data-id="%1$s" data-activeOnLoad="%5$s" data-tab-effect="%6$s">
                        %4$s
                        %7$s
                        <span class="dnxte_tab_nav_content">
                            <div class="dnxte_tab_nav_title">%2$s</div>
                            <p class="dnxte_tab_nav_pra">%3$s</p>
                        </span>
                        </a>
                    </li>',
				esc_attr( self::get_module_class( $child['id'] ?? '' ) ),
				wp_kses_post( $attrs['title']['innerContent']['desktop']['value'] ?? '' ),
				wp_kses_post( $attrs['subtitle']['innerContent']['desktop']['value'] ?? '' ),
				$tab_icon,
				esc_attr( $attrs['misc']['advanced']['activeOnLoad']['desktop']['value'] ?? 'off' ),
				esc_attr( $tab_hover_effect ),
				$tab_image,
				esc_url($module_link),
				$module_link_target === 'on' ? 'target="_blank"' : '',
				$clickable_class // 10 clickable class
			);
		}
		$html .= '</ul>';

		return $html;
	}

	public static function get_module_class( $id ) {
		return preg_replace( '/\/|-/i', '_', $id );
	}

	public function get_tab_icon( $attrs ) {
		$self    = new self();
		$useIcon = isset($attrs['misc']['advanced']['useImageOrIcon']['desktop']['value']) ? $attrs['misc']['advanced']['useImageOrIcon']['desktop']['value'] : '';
		$icon_data = isset($attrs['tabsIconNormal']['innerContent']['desktop']['value']['unicode']) ? $attrs['tabsIconNormal']['innerContent']['desktop']['value']['unicode'] : '';
		if ( 'icon' !== $useIcon ) {
			return '';
		}

		return sprintf('<span class="dnxte_tab_nav_icon">%1$s</span><span class="dnxte_tab_nav_icon_active">%1$s</span>', wp_kses_post( $icon_data ) );
	}

	public function get_tab_svg( $attrs ) {
		$use_svg = isset( $attrs['misc']['advanced']['useImageOrIcon']['desktop']['value'] ) ? $attrs['misc']['advanced']['useImageOrIcon']['desktop']['value'] : '';
		if ( 'svg' !== $use_svg ) {
			return '';
		}

		$svg            = $attrs['tabsSvgNormal']['innerContent']['desktop']['value'] ?? '';
		$has_active_svg = $attrs['tabsSvgActive']['advanced']['use']['desktop']['value'] ?? 'off';
		$active_svg     = $attrs['tabsSvgActive']['innerContent']['desktop']['value'] ?? '';

		if ( '' === $svg && '' === $active_svg ) {
			return '';
		}

		// These are "paste your SVG code" fields, so the markup is intentional and
		// cannot simply be esc_html()'d — but it is still author-supplied, and it is
		// echoed into the page unescaped. Strip scripting from it instead.
		$svg        = \DNXTE\Shared\SvgSanitizer::sanitize( $svg );
		$active_svg = \DNXTE\Shared\SvgSanitizer::sanitize( $active_svg );

		return sprintf(
			'
            <div class="dnxte_tab_nav_image dnxte_tab_nav_svg">%1$s</div>
            <div class="dnxte_tab_nav_image_active dnxte_tab_nav_svg">%2$s</div>',
			$svg,
			'on' === $has_active_svg && '' !== $active_svg ? $active_svg : $svg
		);
	}

	public function get_tab_image( $attrs ) {
		$self     = new self();
		$useImage = isset($attrs['misc']['advanced']['useImageOrIcon']['desktop']['value']) ? $attrs['misc']['advanced']['useImageOrIcon']['desktop']['value'] : '';
		if ( 'image' !== $useImage ) {
			return '';
		}

		$hasActiveImage = isset($attrs['tabsImageActive']['innerContent']['desktop']['value']) ? $attrs['tabsImageActive']['innerContent']['desktop']['value'] : '';
		$image          = isset( $attrs['tabsImageNormal']['innerContent']['desktop']['value'] ) ? $attrs['tabsImageNormal']['innerContent']['desktop']['value'] : '';
		$activeImage    = isset( $attrs['tabsImageActive']['innerContent']['desktop']['value'] ) ? $attrs['tabsImageActive']['innerContent']['desktop']['value'] : '';

		return sprintf(
			'
            <div class="dnxte_tab_nav_image">
                <img decoding="async" src="%1$s" alt="" />
            </div>
            <div class="dnxte_tab_nav_image_active">
                <img
                    alt=""
                    src="%2$s"
                    decoding="async"
                />
            </div>',
			esc_url( $image['src'] ?? '' ),
			esc_url( 'on' === ( $hasActiveImage['use'] ?? 'off' ) ? $activeImage['src'] ?? '' : $image['src'] ?? '' )
		);
	}

}
