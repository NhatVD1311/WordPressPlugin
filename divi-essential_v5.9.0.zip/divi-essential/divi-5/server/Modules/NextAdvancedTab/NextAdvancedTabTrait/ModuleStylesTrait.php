<?php
/**
 * NextAdvancedTab::module_styles().
 *
 * @package MEE\Modules\NextAdvancedTab
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Declarations\Declarations;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use CommonTrait;

	/**
	 * D4 module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/d4-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? array();
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? array();
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? array();
		$order_class                 = $args['orderClass'] ?? '';
		$colorStyle                  = array();

		wp_enqueue_style( 'dnext_ad_tab_effects' );
		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? array(),
								'disabledOn'               => array(
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? array(),
							'cssFields' => self::custom_css(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'title',
						)
					),
					$elements->style([
						'attrName' => 'subtitle',
						'styleProps' => array(
							'advancedStyles' => array(
								array(
									'componentName' => 'divi/common',
									'props'         => array(
										'selector' => $order_class . ' .dnxte_tab_menu .dnxte_tab_a:not(.dnxte_active_a) .dnxte_tab_nav_pra',
										'attr'     => $attrs['subtitle']['advanced']['showHide'] ?? array(),
										'declarationFunction' => function ( $params ) {
											$attrValue = $params['attrValue'] ?? '';
											if ($attrValue === 'on') {
												return "display: none;";
											}
										},
									),			
								)
							)
						)
					]),
					$elements->style(
						array(
							'attrName' => 'titleActive',
						)
					),
					$elements->style(
						array(
							'attrName' => 'subtitleActive',
						)
					),
					$elements->style(
						array(
							'attrName' => 'bodyTitle',
						)
					),
					$elements->style(
						array(
							'attrName' => 'activeTab',
						)
					),
					$elements->style(
						array(
							'attrName' => 'tabWrapper',
						)
					),
					self::tab_style( $elements, $attrs, $order_class ),
					self::body_style( $elements, $attrs, $order_class ),
					...$colorStyle,
				),
			)
		);
	}

	public static function tab_style( $elements, $attrs, $order_class ) {

		$fullWidth = $attrs['tabs']['advanced']['fullwidth']['desktop']['value'] ?? '';
		$tabWrapAttr = $attrs['tabs']['advanced']['tabWrap'] ?? array();
		$tabWrapDesktop = $tabWrapAttr['desktop']['value'] ?? 'off';
		$tabWrapTablet = $tabWrapAttr['tablet']['value'] ?? $tabWrapDesktop;
		$tabWrapPhone = $tabWrapAttr['phone']['value'] ?? $tabWrapTablet;


		$declarations = new Declarations();


		$before_bg_added_effects = array(
			'sweep-to-right',
			'sweep-to-left',
			'sweep-to-top',
			'sweep-to-bottom',
			'bounce-to-right',
			'bounce-to-left',
			'bounce-to-top',
			'bounce-to-bottom',
		);

		$hoverEffectAttr = $attrs['tabs']['advanced']['hoverEffect'] ?? array();
		$hoverEffectDesktop = $hoverEffectAttr['desktop']['value'] ?? '';
		$hoverEffectTablet = $hoverEffectAttr['tablet']['value'] ?? $hoverEffectDesktop;
		$hoverEffectPhone = $hoverEffectAttr['phone']['value'] ?? $hoverEffectTablet;

		$itemPlacementAttr = $attrs['tabs']['advanced']['itemPlacement'] ?? array();
		$itemPlacementDesktop = $itemPlacementAttr['desktop']['value'] ?? 'center';

		$getActiveBGSelector = function( $effect ) use ( $order_class, $before_bg_added_effects ) {
			return in_array( $effect, $before_bg_added_effects, true )
				? "{$order_class} .dnxte_tab_wrapper .dnxte_tab_menu li a.dnxt-hover-ad-{$effect}:before"
				: "{$order_class} .dnxte_tab_wrapper .dnxte_tab_menu li a.dnxte_active_a";
		};

		$activeBGSelectorDesktop = $getActiveBGSelector( $hoverEffectDesktop );
		$activeBGSelectorTablet = $getActiveBGSelector( $hoverEffectTablet );
		$activeBGSelectorPhone = $getActiveBGSelector( $hoverEffectPhone );


		$styles = array(
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector' => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu li a',
					'attr'     => $attrs['tabs']['decoration']['singleBackground'] ?? array(),
					'declarationFunction' => [$declarations, 'background_style_declaration']
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector' => $activeBGSelectorDesktop,
					'attr'     => $attrs['tabs']['decoration']['activeBackground'] ?? array(),
					'declarationFunction' => [$declarations, 'background_style_declaration'],
					'important' => true,
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'atRules'  => '@media only screen and (max-width: 980px)',
					'selector' => $activeBGSelectorTablet,
					'attr'     => $attrs['tabs']['decoration']['activeBackground'] ?? array(),
					'declarationFunction' => [$declarations, 'background_style_declaration'],
					'important' => true,
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'atRules'  => '@media only screen and (max-width: 767px)',
					'selector' => $activeBGSelectorPhone,
					'attr'     => $attrs['tabs']['decoration']['activeBackground'] ?? array(),
					'declarationFunction' => [$declarations, 'background_style_declaration'],
					'important' => true,
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector' => $order_class . ' a.dnxte_tab_a span',
					'attr'     => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
					'property' => 'text-align',
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					// atRules: "@media only screen and (max-width: 980px)",
					'selector'            => "{$order_class} .dnxte_tab_wrapper",
					'attr'                => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
					'declarationFunction' => function ( $args ) {
						$attrValue    = $args['attrValue'] ?? '';
						$placementObj = array(
							'center' => 'column',
							'bottom' => 'column-reverse',
							'left'   => 'row',
							'right'  => 'row-reverse',
						);
						$value        = $placementObj[ $attrValue ] ?? 'column';
						return "flex-direction: {$value};";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					// atRules: "@media only screen and (max-width: 980px)",
					'selector'            => "{$order_class} .dnxte_tab_a",
					'attr'                => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
					'declarationFunction' => function ( $args ) {
						$attrValue    = $args['attrValue'] ?? '';
						if(in_array($attrValue, array("center", "bottom"))){
						  return "height: 100%;";
						}
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'atRules'             => '@media only screen and (max-width: 980px)',
					'selector'            => "{$order_class} a.dnxte_tab_a",
					'attr'                => ! empty( $attrs['tabs']['advanced']['itemPlacement'] ) ? $attrs['tabs']['advanced']['itemPlacement'] : array( 'desktop' => array( 'value' => 'center' ) ),
					'declarationFunction' => function ( $args ) {
						$attrValue = $args['attrValue'] ?? 'center';

						$placementObj = array(
							'center' => 'column',
							'bottom' => 'column-reverse',
							'left'   => 'row',
							'right'  => 'row-reverse',
						);
						return "flex-direction: {$placementObj[$attrValue]}; justify-content: initial;";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'atRules'             => '@media only screen and (max-width: 767px)',
					'selector'            => "{$order_class} a.dnxte_tab_a",
					'attr'                => ! empty( $attrs['tabs']['advanced']['itemPlacement'] ) ? $attrs['tabs']['advanced']['itemPlacement'] : array( 'desktop' => array( 'value' => 'center' ) ),
					'declarationFunction' => function ( $args ) {
						$attrValue = $args['attrValue'] ?? 'center';

						$placementObj = array(
							'center' => 'column',
							'bottom' => 'column-reverse',
							'left'   => 'row',
							'right'  => 'row-reverse',
						);
						return "flex-direction: {$placementObj[$attrValue]}; justify-content: initial;";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => "{$order_class} .dnxte_tab_wrapper ul",
					'attr'                => $attrs['tabs']['advanced']['itemAlignment'] ?? array(),
					'declarationFunction' => function ( $args ) {
						$attrValue = $args['attrValue'] ?? '';
						return "flex-wrap: initial; justify-content: {$attrValue}; height: 100%;";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => "{$order_class} .dnxte_tab_wrapper ul .dnxte_tab_a span.dnxte_tab_nav_icon,{$order_class} .dnxte_tab_wrapper ul .dnxte_tab_a span.dnxte_tab_nav_icon_active",
					'attr'                => $attrs['tabs']['advanced']['iconSize'] ?? array(),
					'property'            => 'font-size',
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => "{$order_class} .dnxte_tab_wrapper ul .dnxte_tab_a span.dnxte_tab_nav_icon",
					'attr'                => $attrs['tabs']['advanced']['iconColor'] ?? array(),
					'property'            => 'color',
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => "{$order_class} .dnxte_tab_wrapper ul .dnxte_tab_a span.dnxte_tab_nav_icon_active",
					'attr'                => $attrs['tabs']['advanced']['iconActiveColor'] ?? array(),
					'property'            => 'color',
				),
			),
		);

		if ( 'on' === $fullWidth ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu li',
						'attr'                => $attrs['tabs']['advanced']['fullwidth'] ?? array(),
						'declarationFunction' => fn() => 'width: 100%;',
					),
				),
			);
		}

		if ( 'on' !== $fullWidth ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector' => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu li',
						'attr'     => $attrs['tabs']['advanced']['width'] ?? array(),
						'property' => 'width',
					),
				),
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector' => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu li',
						'attr'     => $attrs['tabs']['advanced']['maxWidth'] ?? array(),
						'property' => 'max-width',
					),
				),
			);
		}

		// Desktop: tabWrap
		if ( 'on' === $tabWrapDesktop ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'flex-wrap: wrap;',
					),
				),
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul li',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'width: auto;',
					),
				),
			);
		}

		// Tablet: tabWrap
		if ( 'on' === $tabWrapTablet ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 980px)',
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'flex-wrap: wrap;',
					),
				),
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 980px)',
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul li',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'width: auto;',
					),
				),
			);
		}

		// Phone: tabWrap
		if ( 'on' === $tabWrapPhone ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 767px)',
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'flex-wrap: wrap;',
					),
				),
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 767px)',
						'selector'            => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul li',
						'attr'                => $attrs['tabs']['advanced']['tabWrap'] ?? array(),
						'declarationFunction' => fn() => 'width: auto;',
					),
				),
			);
		}

		if ( in_array( $itemPlacementDesktop, array( 'left', 'right' ), true ) ) {
			// Desktop: flex-direction column
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'selector'            => "{$order_class} .dnxte_tab_wrapper ul",
						'attr'                => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
						'declarationFunction' => fn() => 'flex-direction: column !important;',
					),
				),
			);

			// Tablet: flex-direction row
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 980px)',
						'selector'            => "{$order_class} .dnxte_tab_wrapper ul",
						'attr'                => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
						'declarationFunction' => fn() => 'flex-direction: row !important;',
					),
				),
			);

			// Phone: flex-direction column
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 767px)',
						'selector'            => "{$order_class} .dnxte_tab_wrapper ul",
						'attr'                => $attrs['tabs']['advanced']['itemPlacement'] ?? array(),
						'declarationFunction' => fn() => 'flex-direction: row !important;',
					),
				),
			);
		}

		// Phone responsive: flex-direction column (for Top placement)
		if ( 'center' === $itemPlacementDesktop ) {
			array_push(
				$styles,
				array(
					'componentName' => 'divi/common',
					'props'         => array(
						'atRules'             => '@media only screen and (max-width: 767px)',
						'selector'            => "{$order_class} .dnxte_tab_wrapper ul",
						'attr'                => array( 'phone' => array( 'value' => 'column' ) ),
						'declarationFunction' => fn() => 'flex-direction: column !important;',
					),
				),
			);
		}

		return $elements->style(
			array(
				'attrName'   => 'tabs',
				'selector'       => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul',
				'styleProps' => array(
					'selector'       => $order_class . ' .dnxte_tab_wrapper .dnxte_tab_menu ul',
					'advancedStyles' => $styles,
				),
			)
		);
	}

	public static function body_style( $elements, $attrs, $order_class ) {
		$self = new self();

		$styles = array(
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => $order_class . ' .dnxte_tab_content_active',
					'attr'                => $attrs['body']['advanced']['hoverEffect'] ?? array(),
					'declarationFunction' => function ( $params ) {
						$attrValue = $params['attrValue'] ?? '';
						return "animation-name: $attrValue;-webkit-animation-name:$attrValue;";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => $order_class . ' .dnxte_tab_content_active',
					'attr'                => $attrs['body']['advanced']['animationDuration'] ?? array(),
					'declarationFunction' => function ( $params ) {
						$attrValue = $params['attrValue'] ?? '';
						return "animation-duration: {$attrValue}s;-webkit-animation-duration:{$attrValue}s;";
					},
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => $order_class . ' .dnxte_tab_content_slidebar_one .dnxte_tab_content_icon',
					'attr'                => $attrs['body']['advanced']['iconSize'] ?? array(),
					'property'            => 'font-size',
				),
			),
			array(
				'componentName' => 'divi/common',
				'props'         => array(
					'selector'            => $order_class . ' .dnxte_tab_content_slidebar_one .dnxte_tab_content_icon',
					'attr'                => $attrs['body']['advanced']['iconColor'] ?? array(),
					'property'            => 'color',
				),
			),
		);

		return $elements->style(
			array(
				'attrName'   => 'body',
				'styleProps' => array(
					'advancedStyles' => $styles,
				),
			)
		);
	}
}
