<?php
/**
 * Module: Next Advanced Tab  Module class.
 *
 * @package MEE\Modules\NextAdvancedTab
 * @since ??
 */

namespace DNXTE\Modules\NextAdvancedTab;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\NextAdvancedTab\NextAdvancedTabTrait;

/**
 * `NextAdvancedTab` is consisted of functions used for Divi 4 Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextAdvancedTab implements DependencyInterface {
	use NextAdvancedTabTrait\RenderCallbackTrait;

	/**
	 * Loads `NextAdvancedTab` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextAdvancedTab/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					array(
						'render_callback' => array( NextAdvancedTab::class, 'render_callback' ),
					)
				);
			}
		);
	}
}
