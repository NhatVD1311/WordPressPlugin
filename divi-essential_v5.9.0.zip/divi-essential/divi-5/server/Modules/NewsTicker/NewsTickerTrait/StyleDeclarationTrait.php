<?php
/**
 * NewsTicker style declarations.
 *
 * @package DNXTE\Modules\NewsTicker
 * @since ??
 */

namespace DNXTE\Modules\NewsTicker\NewsTickerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

trait StyleDeclarationTrait {

	/**
	 * Icon font style declaration.
	 *
	 * Sets font-family (ETmodules or FontAwesome) and font-weight
	 * based on the icon attribute value.
	 *
	 * @param array $params Declaration function params with attrValue.
	 * @return string CSS declarations string.
	 */
	public static function icon_style_declaration( array $params ): string {
		$icon_attr = $params['attrValue'] ?? [];

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
				],
			]
		);

		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		return $style_declarations->value();
	}
}
