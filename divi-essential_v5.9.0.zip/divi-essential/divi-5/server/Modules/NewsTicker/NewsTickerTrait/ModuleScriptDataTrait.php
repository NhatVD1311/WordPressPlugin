<?php
/**
 * NewsTicker::module_script_data()
 *
 * @package DNXTE\Modules\NewsTicker
 * @since ??
 */

namespace DNXTE\Modules\NewsTicker\NewsTickerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

trait ModuleScriptDataTrait {

	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setAttrs'      => [
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-label' => $attrs['elements']['advanced']['showLabel'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-use-label-text' => $attrs['label']['advanced']['useLabelText'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-use-label-icon' => $attrs['label']['advanced']['useLabelIcon'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-controls' => $attrs['elements']['advanced']['showControls'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'off';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-progress' => $attrs['elements']['advanced']['showProgress'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'off';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-mode' => $attrs['tickerSettings']['advanced']['mode'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'scroll';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-auto-play' => $attrs['tickerSettings']['advanced']['autoPlay'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-pause-on-hover' => $attrs['tickerSettings']['advanced']['pauseOnHover'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-category' => $attrs['elements']['advanced']['showCategory'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-tag' => $attrs['elements']['advanced']['showTag'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'off';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-separator' => $attrs['elements']['advanced']['showSeparator'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'on';
						},
					],
					[
						'selector' => $selector . ' .news-ticker',
						'data'     => array(
							'data-show-date' => $attrs['elements']['advanced']['showDate'] ?? [],
						),
						'valueResolver' => function( $value ) {
							return $value ?? 'off';
						},
					],
				],
			]
		);

		wp_enqueue_script( 'dnext_news_ticker' );
	}
}
