<?php
/**
 * NewsTicker::module_styles().
 *
 * @package DNXTE\Modules\NewsTicker
 * @since ??
 */

namespace DNXTE\Modules\NewsTicker\NewsTickerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';

		$base_styles = [
			$elements->style(
				[
					'attrName'   => 'module',
					'styleProps' => [
						'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
						'disabledOn'               => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				]
			),
			CssStyle::style(
				[
					'selector'  => $args['orderClass'],
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => self::custom_css(),
				]
			),
			$elements->style( [ 'attrName' => 'title' ] ),
			$elements->style( [ 'attrName' => 'category' ] ),
			$elements->style( [ 'attrName' => 'tag' ] ),
			$elements->style( [ 'attrName' => 'date' ] ),
			$elements->style( [ 'attrName' => 'label' ] ),
			$elements->style(
				[
					'attrName'   => 'labelIcon',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'                => $attrs['label']['advanced']['icon'] ?? [],
									'declarationFunction' => [ self::class, 'icon_style_declaration' ],
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['labelIcon']['advanced']['color'] ?? [],
									'property'  => 'color',
									'important' => true,
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'attr'      => $attrs['labelIcon']['advanced']['size'] ?? [],
									'property'  => 'font-size',
									'important' => true,
								],
							],
						],
					],
				]
			),
			$elements->style( [ 'attrName' => 'ticker' ] ),
		];

		// Separator color
		$conditional_styles = [];
		if ( ! empty( $attrs['separator']['advanced']['color'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__separator",
					'attr'     => $attrs['separator']['advanced']['color'] ?? [],
					'property' => 'color',
				]
			);
		}

		// Progress bar background color
		if ( ! empty( $attrs['progressBar']['advanced']['bgColor'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__progress",
					'attr'     => $attrs['progressBar']['advanced']['bgColor'] ?? [],
					'property' => 'background-color',
				]
			);
		}

		// Progress bar active/fill color
		if ( ! empty( $attrs['progressBar']['advanced']['activeColor'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__progress-bar",
					'attr'     => $attrs['progressBar']['advanced']['activeColor'] ?? [],
					'property' => 'background-color',
				]
			);
		}

		// Progress bar height
		if ( ! empty( $attrs['progressBar']['advanced']['height'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__progress",
					'attr'     => $attrs['progressBar']['advanced']['height'] ?? [],
					'property' => 'height',
				]
			);
		}

		// Controls button background
		if ( ! empty( $attrs['controls']['advanced']['bgColor'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__btn",
					'attr'     => $attrs['controls']['advanced']['bgColor'] ?? [],
					'property' => 'background-color',
				]
			);
		}

		// Controls button color
		if ( ! empty( $attrs['controls']['advanced']['color'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__btn",
					'attr'     => $attrs['controls']['advanced']['color'] ?? [],
					'property' => 'color',
				]
			);
		}

		// Controls button size
		if ( ! empty( $attrs['controls']['advanced']['size'] ?? [] ) ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__btn",
					'attr'     => $attrs['controls']['advanced']['size'] ?? [],
					'property' => 'width',
				]
			);
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "{$order_class} .news-ticker__btn",
					'attr'     => $attrs['controls']['advanced']['size'] ?? [],
					'property' => 'height',
				]
			);
		}

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array_merge( $base_styles, $conditional_styles ),
			]
		);
	}
}
