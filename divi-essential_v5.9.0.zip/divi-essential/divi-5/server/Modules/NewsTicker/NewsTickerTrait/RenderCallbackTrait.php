<?php
/**
 * NewsTicker::render_callback()
 *
 * @package DNXTE\Modules\NewsTicker
 * @since ??
 */

namespace DNXTE\Modules\NewsTicker\NewsTickerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use WP_Query;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Post settings
		$post_type      = $attrs['post']['advanced']['type']['desktop']['value'] ?? 'post';
		$posts_per_page = $attrs['post']['advanced']['number']['desktop']['value'] ?? '5';
		$offset         = $attrs['post']['advanced']['offset']['desktop']['value'] ?? '0';
		$date_format    = $attrs['post']['advanced']['dateFormat']['desktop']['value'] ?? 'M j, Y';
		$orderby        = $attrs['post']['advanced']['orderby']['desktop']['value'] ?? 'date';
		$shorted_by     = $attrs['post']['advanced']['shortedBy']['desktop']['value'] ?? 'DESC';

		// Elements
		$show_category  = $attrs['elements']['advanced']['showCategory']['desktop']['value'] ?? 'on';
		$show_tag       = $attrs['elements']['advanced']['showTag']['desktop']['value'] ?? 'off';
		$show_date      = $attrs['elements']['advanced']['showDate']['desktop']['value'] ?? 'off';
		$show_separator  = $attrs['elements']['advanced']['showSeparator']['desktop']['value'] ?? 'on';
		$separator_style = $attrs['elements']['advanced']['separatorStyle']['desktop']['value'] ?? 'bullet';
		$show_label       = $attrs['elements']['advanced']['showLabel']['desktop']['value'] ?? 'on';
		$show_label_arrow = $attrs['elements']['advanced']['showLabelArrow']['desktop']['value'] ?? 'on';
		$show_controls    = $attrs['elements']['advanced']['showControls']['desktop']['value'] ?? 'off';
		$show_progress  = $attrs['elements']['advanced']['showProgress']['desktop']['value'] ?? 'off';
		$progress_pos   = $attrs['elements']['advanced']['progressPosition']['desktop']['value'] ?? 'bottom';

		// Ticker settings
		$mode           = $attrs['tickerSettings']['advanced']['mode']['desktop']['value'] ?? 'scroll';
		$direction      = $attrs['tickerSettings']['advanced']['direction']['desktop']['value'] ?? 'left';
		$speed          = $attrs['tickerSettings']['advanced']['speed']['desktop']['value'] ?? '50';
		$duration       = $attrs['tickerSettings']['advanced']['duration']['desktop']['value'] ?? '4000';
		$pause_on_hover = $attrs['tickerSettings']['advanced']['pauseOnHover']['desktop']['value'] ?? 'on';
		$auto_play      = $attrs['tickerSettings']['advanced']['autoPlay']['desktop']['value'] ?? 'on';
		$gap            = $attrs['tickerSettings']['advanced']['gap']['desktop']['value'] ?? '60px';

		// Separator character mapping
		$separator_map = array(
			'bullet'  => '•',
			'pipe'    => '|',
			'slash'   => '/',
			'star'    => '★',
			'diamond' => '◆',
			'dash'    => '—',
		);
		$separator_char = $separator_map[ $separator_style ] ?? '•';

		// Label
		$use_label_text = $attrs['label']['advanced']['useLabelText']['desktop']['value'] ?? 'on';
		$use_label_icon = $attrs['label']['advanced']['useLabelIcon']['desktop']['value'] ?? 'on';
		$label_text = $attrs['label']['advanced']['text']['desktop']['value'] ?? 'Latest News';
		$label_icon_value = $attrs['label']['advanced']['icon']['desktop']['value'] ?? array();
		$label_icon_unicode = '';
		if ( is_array( $label_icon_value ) && ! empty( $label_icon_value['unicode'] ) ) {
			$label_icon_unicode = $label_icon_value['unicode'];
		} elseif ( is_string( $label_icon_value ) ) {
			$label_icon_unicode = $label_icon_value;
		}

		// Build WP_Query
		$query_args = array(
			'posts_per_page' => $posts_per_page,
			'post_status'    => array( 'publish', 'private', 'inherit' ),
			'perm'           => 'readable',
			'post_type'      => $post_type,
			'orderby'        => $orderby,
			'order'          => $shorted_by,
		);

		if ( '' !== $offset && ! empty( $offset ) ) {
			$query_args['offset'] = $offset;
		}

		$wp_query = new WP_Query( $query_args );

		// Build items HTML
		$items_output = '';
		$item_index = 0;

		if ( $wp_query->have_posts() ) {
			while ( $wp_query->have_posts() ) {
				$wp_query->the_post();

				$item_parts = '';

				// Category
				if ( 'on' === $show_category ) {
					$post_categories = get_the_category();
					if ( ! empty( $post_categories ) ) {
						$item_parts .= HTMLUtility::render(
							[
								'tag'        => 'span',
								'attributes' => [ 'class' => 'news-ticker__category' ],
								'children'   => esc_html( $post_categories[0]->name ),
							]
						);
					}
				}

				// Title
				$item_parts .= HTMLUtility::render(
					[
						'tag'               => 'a',
						'attributes'        => [
							'href'  => get_the_permalink(),
							'class' => 'news-ticker__text',
						],
						'children'          => get_the_title(),
						'childrenSanitizer' => 'et_core_esc_previously',
					]
				);

				// Tag
				if ( 'on' === $show_tag ) {
					$post_tags = get_the_tags();
					if ( ! empty( $post_tags ) ) {
						$item_parts .= HTMLUtility::render(
							[
								'tag'        => 'span',
								'attributes' => [ 'class' => 'news-ticker__tag' ],
								'children'   => esc_html( $post_tags[0]->name ),
							]
						);
					}
				}

				// Date
				if ( 'on' === $show_date ) {
					$item_parts .= HTMLUtility::render(
						[
							'tag'        => 'span',
							'attributes' => [ 'class' => 'news-ticker__date' ],
							'children'   => get_the_date( $date_format ),
						]
					);
				}

				// Separator
				if ( 'on' === $show_separator ) {
					$item_parts .= HTMLUtility::render(
						[
							'tag'        => 'span',
							'attributes' => [ 'class' => 'news-ticker__separator' ],
							'children'   => $separator_char,
						]
					);
				}

				$active_class = ( $mode !== 'scroll' && 0 === $item_index ) ? ' news-ticker__item--active' : '';

				$items_output .= HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => [
							'class' => 'news-ticker__item' . $active_class,
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $item_parts,
					]
				);

				$item_index++;
			}
		}

		wp_reset_postdata();

		// Track
		$track = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'news-ticker__track' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $items_output,
			]
		);

		// Content
		$ticker_content = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'news-ticker__content' . ( 'scroll' !== $mode ? ' news-ticker__content--truncate' : '' ) ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $track,
			]
		);

		// Label
		$label_html = '';
		if ( 'on' === $show_label ) {
			$icon_html = '';
			if ( 'on' === $use_label_icon && ! empty( $label_icon_unicode ) ) {
				$icon_html = HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [ 'class' => 'news-ticker__label-icon et-pb-icon' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $label_icon_unicode,
					]
				);
			}

			$text_html = '';
			if ( 'on' === $use_label_text ) {
				$text_html = HTMLUtility::render(
					[
						'tag'        => 'span',
						'attributes' => [ 'class' => 'news-ticker__label-text' ],
						'children'   => esc_html( $label_text ),
					]
				);
			}

			$label_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'news-ticker__label' . ( 'on' === $show_label_arrow ? ' news-ticker__label--has-arrow' : '' ) ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $icon_html . $text_html,
				]
			);
		}

		// Controls
		$controls_html = '';
		if ( 'on' === $show_controls ) {
			$controls_children = '';
			if ( 'scroll' !== $mode ) {
				$controls_children .= '<button class="news-ticker__btn news-ticker__btn--prev">&#8249;</button>';
			}
			$controls_children .= '<button class="news-ticker__btn news-ticker__btn--pause">&#9208;</button>';
			if ( 'scroll' !== $mode ) {
				$controls_children .= '<button class="news-ticker__btn news-ticker__btn--next">&#8250;</button>';
			}
			$controls_html = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'news-ticker__controls' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $controls_children,
				]
			);
		}

		// Wrapper
		$wrapper = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'news-ticker__wrapper' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $label_html . $ticker_content . $controls_html,
			]
		);

		// Progress bar
		$progress_top_html  = '';
		$progress_bottom_html = '';
		if ( 'on' === $show_progress && 'scroll' !== $mode ) {
			$progress_bar = HTMLUtility::render(
				[
					'tag'               => 'div',
					'attributes'        => [ 'class' => 'news-ticker__progress news-ticker__progress--' . esc_attr( $progress_pos ) ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => '<div class="news-ticker__progress-bar"></div>',
				]
			);

			if ( 'top' === $progress_pos ) {
				$progress_top_html = $progress_bar;
			} else {
				$progress_bottom_html = $progress_bar;
			}
		}

		// Gap value (strip unit for data attr)
		$gap_num = intval( $gap );

		// Main ticker container with data attributes for JS
		$ticker_output = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'               => 'news-ticker news-ticker--' . esc_attr( $mode ),
					'data-news-ticker'    => '',
					'data-mode'           => esc_attr( $mode ),
					'data-direction'      => esc_attr( $direction ),
					'data-speed'          => esc_attr( $speed ),
					'data-duration'       => esc_attr( $duration ),
					'data-pause-on-hover' => esc_attr( $pause_on_hover ),
					'data-auto-play'      => esc_attr( $auto_play ),
					'data-gap'            => esc_attr( $gap_num ),
					'data-show-controls'  => esc_attr( $show_controls ),
					'data-show-progress'  => esc_attr( $show_progress ),
					'data-show-label'     => esc_attr( $show_label ),
					'data-use-label-text' => esc_attr( $use_label_text ),
					'data-use-label-icon' => esc_attr( $use_label_icon ),
					'data-show-category'  => esc_attr( $show_category ),
					'data-show-tag'       => esc_attr( $show_tag ),
					'data-show-separator' => esc_attr( $show_separator ),
					'data-show-date'      => esc_attr( $show_date ),
					'style'               => '--ticker-gap: ' . esc_attr( $gap ) . ';',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $progress_top_html . $wrapper . $progress_bottom_html,
			]
		);

		return Module::render(
			[
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'className'           => 'dnxte-news-ticker',
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ self::class, 'module_classnames' ],
				'stylesComponent'     => [ self::class, 'module_styles' ],
				'scriptDataComponent' => [ self::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => $elements->style_components(
					[
						'attrName' => 'module',
					]
				) . $ticker_output,
			]
		);
	}
}
