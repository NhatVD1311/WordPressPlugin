<?php
/**
 * NewsTicker::custom_css().
 *
 * @package DNXTE\Modules\NewsTicker
 * @since ??
 */

namespace DNXTE\Modules\NewsTicker\NewsTickerTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/news-ticker' )->customCssFields;
	}
}
