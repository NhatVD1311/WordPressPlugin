<?php

/**
 * NextCircularImageHover::render_callback()
 *
 * @package MEE\Modules\NextCircularImageHover
 * @since ??
 */

namespace DNXTE\Modules\NextCircularImageHover\NextCircularImageHoverTrait;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\NextCircularImageHover\NextCircularImageHover;

trait RenderCallbackTrait
{

	/**
	 * Static module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param WP_Block       $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Static module.
	 */
	public static function render_callback($attrs, $content, $block, $elements)
	{
		$hover_effect = $attrs['container']['advanced']['hover_effect_name']['desktop']['value'] ?? '';
		$image_hover_direction1 = $attrs['container']['advanced']['image_hover_direction1']['desktop']['value'] ?? '';
		$image_hover_direction2 = $attrs['container']['advanced']['image_hover_direction2']['desktop']['value'] ?? '';
		$image_hover_direction3 = $attrs['container']['advanced']['image_hover_direction3']['desktop']['value'] ?? '';
		$image_hover_direction4 = $attrs['container']['advanced']['image_hover_direction4']['desktop']['value'] ?? '';
		$image_hover_direction5 = $attrs['container']['advanced']['image_hover_direction5']['desktop']['value'] ?? '';
		$image_hover_direction6 = $attrs['container']['advanced']['image_hover_direction6']['desktop']['value'] ?? '';
		$use_gradient = $attrs['caption_container']['advanced']['use2']['desktop']['value'] ?? '';
		$use_BgColor = $attrs['caption_container']['advanced']['use']['desktop']['value'] ?? '';

		// Gradient and Background related attributes
		$BG_color = $attrs['caption_container']['decoration']['bgcolor']['desktop']['value'] ?? '';
		$gradient_color_one = $attrs['caption_container']['decoration']['color']['desktop']['value'] ?? '';
		$gradient_color_two = $attrs['caption_container']['decoration']['color2']['desktop']['value'] ?? '';
		$gradient_color_type = $attrs['caption_container']['advanced']['selectGradientType']['desktop']['value'] ?? '';
		$linear_gradient_direction = $attrs['caption_container']['advanced']['selectLinearDirection']['desktop']['value'] ?? '';
		$radial_gradient_direction = $attrs['caption_container']['advanced']['selectRadialDirection']['desktop']['value'] ?? '';
		$start_position = $attrs['caption_container']['advanced']['startPosition']['desktop']['value'] ?? '';
		$end_position = $attrs['caption_container']['advanced']['endPosition']['desktop']['value'] ?? '';

		$caption_BG_color = '';

		if ($gradient_color_type === 'linear-gradient') {
			$caption_BG_color = "linear-gradient({$linear_gradient_direction}, {$gradient_color_one} {$start_position}, {$gradient_color_two} {$end_position})";
		} else {
			$caption_BG_color = "radial-gradient({$radial_gradient_direction}, {$gradient_color_one} {$start_position}, {$gradient_color_two} {$end_position})";
		}

		$captionContainerStyle = [
			'background' => ($use_BgColor === 'on' && $use_gradient === 'off' ? $BG_color : '') ?: ($use_gradient === 'on' ? $caption_BG_color : '')
		];

		

		$dnxtiep_cih_info_back = ["effect4", "effect17", "effect19"];

		$direction_class = "";
		$dnxtiep_cih_effect1 = [
			"effect1",
			"effect2",
			"effect3",
			"effect6",
			"effect7",
			"effect8",
			"effect10",
			"effect11",
			"effect13",
			"effect17"
		];
		$dnxtiep_cih_effect2 = "effect5";
		$dnxtiep_cih_effect3 = "effect15";
		$dnxtiep_cih_effect4 = ["effect9", "effect19"];
		$dnxtiep_cih_effect5 = "effect12";
		$dnxtiep_cih_effect6 = "effect14";

		if (in_array($hover_effect, $dnxtiep_cih_effect1)) {
			$direction_class = "neip-cih-" . $image_hover_direction1;
		}

		if ($hover_effect === $dnxtiep_cih_effect2) {
			$direction_class = "neip-cih-" . $image_hover_direction2;
		}
		if ($hover_effect === $dnxtiep_cih_effect3) {
			$direction_class = "neip-cih-" . $image_hover_direction3;
		}
		if (in_array($hover_effect, $dnxtiep_cih_effect4)) {
			$direction_class = "neip-cih-" . $image_hover_direction4;
		}
		if ($hover_effect === $dnxtiep_cih_effect5) {
			$direction_class = "neip-cih-" . $image_hover_direction5;
		}
		if ($hover_effect === $dnxtiep_cih_effect6) {
			$direction_class = "neip-cih-" . $image_hover_direction6;
		}



		// Image content related elements render

		$image = $elements->render(
			[
				'attrName' => 'image',
			]
		);


		$img_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-img',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $image,
			]
		);

		$img_content_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-img-container',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $img_container,
			]
		);

		//  contents related elements render

		// Title.
		$heading_text = $elements->render(
			[
				'attrName' => 'heading_text',
			]
		);

		// Content.
		$content = $elements->render(
			[
				'attrName' => 'content',
			]
		);

		$description = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => '',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content,
			]
		);

		$content_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-info-back',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $heading_text . $description,
			]
		);

		$container_type_one = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-info',
					'style' => $captionContainerStyle,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content_container,
			]
		);

		$container_type_two = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-info',
					'style' => $captionContainerStyle,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $heading_text . $description,
			]
		);

		$container_type_wrapper = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'neip-cih-info-container',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container_type_two,
			]
		);

		// Content container.
		$main_container = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnext-neip-cih-hvr',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => (
					$hover_effect === 'effect7' ? $img_content_container : $img_container)
					.
					(in_array($hover_effect, $dnxtiep_cih_info_back, true)
						?
						$container_type_one : ($hover_effect === 'effect7'
							?
							$container_type_wrapper : $container_type_two)
					),
			]
		);

		$parent       = BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [NextCircularImageHover::class, 'module_classnames'],
				'stylesComponent'     => [NextCircularImageHover::class, 'module_styles'],
				'scriptDataComponent' => [NextCircularImageHover::class, 'module_script_data'],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => [
					ElementComponents::component(
						[
							'attrs'         => $attrs['module']['decoration'] ?? [],
							'id'            => $block->parsed_block['id'],

							// FE only.
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						]
					),
					HTMLUtility::render(
						[
							'tag'               => 'div',
							'attributes'        => [
								'class' => "dnext-neip-cih-item neip-cih-{$hover_effect} {$direction_class}",
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $main_container,
						]
					),
				],
			]
		);
	}
}
