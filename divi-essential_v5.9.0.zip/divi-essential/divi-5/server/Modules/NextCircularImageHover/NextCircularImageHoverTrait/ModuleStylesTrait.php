<?php

/**
 * NextCircularImageHover::module_styles().
 *
 * @package MEE\Modules\NextCircularImageHover
 * @since ??
 */

namespace DNXTE\Modules\NextCircularImageHover\NextCircularImageHoverTrait;

use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

if (! defined('ABSPATH')) {
	die('Direct access forbidden.');
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\NextCircularImageHover\NextCircularImageHover;

trait ModuleStylesTrait
{

	use CustomCssTrait;

	/**
	 * Static Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/NextCircularImageHover/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements  ModuleElements instance.
	 * }
	 */
	public static function module_styles($args)
	{
		$attrs    = $args['attrs'] ?? [];
		$elements = $args['elements'];
		$settings = $args['settings'] ?? [];
		$order_class = $args['orderClass'];

		$img_box_shadow_selector              = "{$order_class} .dnext-neip-cih-item .neip-cih-img::before";

		$boxShadowHorizontal = $attrs['horizontal_position']['innerContent']['desktop']['value'] ?? '';
		$boxShadowVertical = $attrs['vertical_position']['innerContent']['desktop']['value'] ?? '0px';
		$boxShadowBlur = $attrs['blur_strength']['innerContent']['desktop']['value'] ?? '';
		$boxShadowSpread = $attrs['spread_strength']['innerContent']['desktop']['value'] ?? '';
		$boxShadowColor = $attrs['shadoow_color']['innerContent']['desktop']['value'] ?? '';
		// Lands unescaped in the page <style> block — validate (see DNXTE\Shared\CssGradient).
		$boxShadowHorizontal = \DNXTE\Shared\CssGradient::safe_length( $boxShadowHorizontal );
		$boxShadowVertical = \DNXTE\Shared\CssGradient::safe_length( $boxShadowVertical );
		$boxShadowBlur = \DNXTE\Shared\CssGradient::safe_length( $boxShadowBlur );
		$boxShadowSpread = \DNXTE\Shared\CssGradient::safe_length( $boxShadowSpread );
		$boxShadowColor = \DNXTE\Shared\CssGradient::safe_color( $boxShadowColor );

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => NextCircularImageHover::custom_css(),
						]
					),

					CommonStyle::style(
						[
							'selector' => $img_box_shadow_selector,
							'attr'     => $attrs['horizontal_position']['innerContent'] ?? [],
							'property' => "box-shadow: inset {$boxShadowHorizontal} {$boxShadowVertical} {$boxShadowBlur} {$boxShadowSpread} {$boxShadowColor},0 1px 2px rgba(0, 0, 0, 0.3) !important;",
						]
					),

					// main_content_spacing.
					$elements->style(
						[
							'attrName' => 'main_content_spacing',
						]
					),
					// image_container_shadow.
					$elements->style(
						[
							'attrName' => 'image_container_shadow',
						]
					),
					// Image.
					$elements->style(
						[
							'attrName' => 'image',
						]
					),
					

					// heading_text.
					$elements->style(
						[
							'attrName' => 'heading_text',
						]
					),

					// Content.
					$elements->style(
						[
							'attrName' => 'content',
						]
					),
				],
			]
		);
	}
}
