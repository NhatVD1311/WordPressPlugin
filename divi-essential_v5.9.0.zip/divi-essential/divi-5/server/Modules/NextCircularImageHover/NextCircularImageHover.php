<?php
/**
 * Module: NextCircularImageHover class.
 *
 * @package MEE\Modules\NextCircularImageHover
 * @since ??
 */

namespace DNXTE\Modules\NextCircularImageHover;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;


/**
 * `NextCircularImageHover` is consisted of functions used for NextCircularImageHover such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextCircularImageHover implements DependencyInterface {
	use NextCircularImageHoverTrait\RenderCallbackTrait;
	use NextCircularImageHoverTrait\ModuleClassnamesTrait;
	use NextCircularImageHoverTrait\ModuleStylesTrait;
	use NextCircularImageHoverTrait\ModuleScriptDataTrait;

	/**
	 * Loads `NextCircularImageHover` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextCircularImageHover/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextCircularImageHover::class, 'render_callback' ],
					]
				);
			}
		);
	}
}