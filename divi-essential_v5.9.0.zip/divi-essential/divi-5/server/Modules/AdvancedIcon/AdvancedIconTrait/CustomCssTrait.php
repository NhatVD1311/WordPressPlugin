<?php
/**
 * AdvancedIcon::custom_css().
 *
 * @package MEE\Modules\AdvancedIcon
 * @since ??
 */

namespace DNXTE\Modules\AdvancedIcon\AdvancedIconTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * This function is equivalent of JS const cssFields located in
	 * src/components/AdvancedIcon/custom-css.ts.
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/advanced-icon' )->customCssFields;
	}

}
