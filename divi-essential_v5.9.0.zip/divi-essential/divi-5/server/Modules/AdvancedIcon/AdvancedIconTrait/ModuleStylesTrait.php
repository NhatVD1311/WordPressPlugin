<?php
/**
 * AdvancedIcon::module_styles().
 *
 * @package MEE\Modules\AdvancedIcon
 * @since ??
 */

namespace DNXTE\Modules\AdvancedIcon\AdvancedIconTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\AdvancedIcon\AdvancedIcon;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Build the transform string from rotate + flip attributes (desktop values).
	 *
	 * @since ??
	 *
	 * @param array $attrs Module attributes.
	 *
	 * @return string
	 */
	public static function build_transform( $attrs ) {
		$rotate = $attrs['icon']['advanced']['rotate']['desktop']['value'] ?? '0deg';
		// Lands unescaped in the page <style> block — validate (see DNXTE\Shared\CssGradient).
		$rotate = \DNXTE\Shared\CssGradient::safe_length( $rotate );
		$flip_h = $attrs['icon']['advanced']['flipHorizontal']['desktop']['value'] ?? 'off';
		$flip_v = $attrs['icon']['advanced']['flipVertical']['desktop']['value'] ?? 'off';

		$parts = [];

		if ( $rotate && '0deg' !== $rotate && '0' !== $rotate ) {
			$parts[] = "rotate({$rotate})";
		}
		if ( 'on' === $flip_h ) {
			$parts[] = 'scaleX(-1)';
		}
		if ( 'on' === $flip_v ) {
			$parts[] = 'scaleY(-1)';
		}

		return empty( $parts ) ? '' : implode( ' ', $parts );
	}

	/**
	 * Static Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/AdvancedIcon/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args Style component arguments.
	 */
	public static function module_styles( $args ) {
		$attrs          = $args['attrs'] ?? [];
		$elements       = $args['elements'];
		$settings       = $args['settings'] ?? [];
		$order_class    = $args['orderClass'] ?? '';
		$inner_selector = "{$order_class} .dnxt-advanced-icon-inner";

		$transform = self::build_transform( $attrs );

		$transform_style = [];
		if ( '' !== $transform ) {
			$transform_style = [
				CommonStyle::style(
					[
						'selector' => "{$inner_selector} svg",
						'attr'     => $attrs['icon']['advanced']['rotate'] ?? [],
						'property' => "transform: {$transform};",
					]
				),
			];
		}

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),

					// Icon color — force-recolors the whole SVG (fill + stroke),
					// preserving fill="none" so outline icons stay outlined.
					CommonStyle::style(
						[
							'selector' => $inner_selector,
							'attr'     => $attrs['icon']['advanced']['iconColor'] ?? [],
							'property' => 'color',
						]
					),
					CommonStyle::style(
						[
							'selector' => "{$inner_selector} svg, {$inner_selector} svg [fill]:not([fill=\"none\"])",
							'attr'     => $attrs['icon']['advanced']['iconColor'] ?? [],
							'property' => 'fill',
						]
					),
					CommonStyle::style(
						[
							'selector' => "{$inner_selector} svg [stroke]:not([stroke=\"none\"])",
							'attr'     => $attrs['icon']['advanced']['iconColor'] ?? [],
							'property' => 'stroke',
						]
					),

					// Icon hover color.
					CommonStyle::style(
						[
							'selector' => "{$inner_selector}:hover",
							'attr'     => $attrs['icon']['advanced']['iconHoverColor'] ?? [],
							'property' => 'color',
						]
					),
					CommonStyle::style(
						[
							'selector' => "{$inner_selector}:hover svg, {$inner_selector}:hover svg [fill]:not([fill=\"none\"])",
							'attr'     => $attrs['icon']['advanced']['iconHoverColor'] ?? [],
							'property' => 'fill',
						]
					),
					CommonStyle::style(
						[
							'selector' => "{$inner_selector}:hover svg [stroke]:not([stroke=\"none\"])",
							'attr'     => $attrs['icon']['advanced']['iconHoverColor'] ?? [],
							'property' => 'stroke',
						]
					),

					// Icon size.
					CommonStyle::style(
						[
							'selector' => $inner_selector,
							'attr'     => $attrs['icon']['advanced']['iconSize'] ?? [],
							'property' => 'font-size',
							'important' => true,
						]
					),

					$elements->style(
						[
							'attrName'   => 'icon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['alignment'] ?? [],
											'property' => 'justify-content',
										]
									],
									
								]
							]
						]
					),

					// Rotate / flip.
					...$transform_style,

					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => AdvancedIcon::custom_css(),
						]
					),
				],
			]
		);
	}
}
