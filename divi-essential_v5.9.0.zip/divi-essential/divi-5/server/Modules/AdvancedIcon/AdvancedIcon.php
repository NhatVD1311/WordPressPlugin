<?php
/**
 * Module: Static Module class.
 *
 * @package MEE\Modules\AdvancedIcon
 * @since ??
 */

namespace DNXTE\Modules\AdvancedIcon;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `AdvancedIcon` is consisted of functions used for Static Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class AdvancedIcon implements DependencyInterface {
	use AdvancedIconTrait\RenderCallbackTrait;
	use AdvancedIconTrait\ModuleClassnamesTrait;
	use AdvancedIconTrait\ModuleStylesTrait;
	use AdvancedIconTrait\ModuleScriptDataTrait;

	/**
	 * Loads `AdvancedIcon` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'AdvancedIcon/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ AdvancedIcon::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
