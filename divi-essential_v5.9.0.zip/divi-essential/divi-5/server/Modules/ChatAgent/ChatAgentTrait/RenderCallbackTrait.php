<?php
/**
 * ChatAgent::render_callback()
 *
 * @package MEE\Modules\ChatAgent
 * @since ??
 */

namespace DNXTE\Modules\ChatAgent\ChatAgentTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\ChatAgent\ChatAgent;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use CustomCssTrait;

	/**
	 * Neutral user silhouette shown when no avatar image has been uploaded. Kept
	 * in sync with the JS DEFAULT_AVATAR_SVG.
	 *
	 * @since ??
	 *
	 * @return string
	 */
	public static function default_avatar_svg() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 12a5 5 0 1 0 0-10a5 5 0 0 0 0 10m0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5"/></svg>';
	}

	/**
	 * Small channel badge glyphs rendered over the avatar. Kept in sync with the
	 * JS CHANNEL_ICONS map.
	 *
	 * @since ??
	 *
	 * @param string $channel Channel key.
	 *
	 * @return string
	 */
	public static function channel_icon_svg( $channel ) {
		$icons = [
			'whatsapp'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M19.05 4.91A9.82 9.82 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91c0-2.65-1.03-5.14-2.91-7.01M12.05 20.15h-.01c-1.48 0-2.93-.4-4.2-1.15l-.3-.18l-3.12.82l.83-3.04l-.2-.31a8.26 8.26 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24c2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.25 8.23m4.52-6.16c-.25-.12-1.47-.72-1.69-.81c-.23-.08-.39-.12-.56.12c-.17.25-.64.81-.79.97c-.14.17-.29.19-.54.06c-.25-.12-1.05-.39-1.99-1.23c-.74-.66-1.23-1.47-1.38-1.72c-.14-.25-.02-.38.11-.51c.11-.11.25-.29.37-.43s.17-.25.25-.41c.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31c-.22.25-.86.85-.86 2.07c0 1.22.89 2.4 1.01 2.56s1.75 2.67 4.23 3.74c.59.26 1.05.41 1.41.52c.59.19 1.13.16 1.56.1c.48-.07 1.47-.6 1.67-1.18c.21-.58.21-1.07.14-1.18s-.22-.16-.47-.28"/></svg>',
			'messenger' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.14 7.17c.16.14.26.35.27.57l.05 1.78c.03.57.61.94 1.13.71l1.98-.87c.17-.08.36-.09.54-.04c.91.25 1.88.38 2.89.38c5.64 0 10-4.13 10-9.7S17.64 2 12 2m6 7.46l-2.93 4.66c-.47.74-1.47.92-2.17.4L10.56 12.7a.6.6 0 0 0-.72 0l-3.16 2.4c-.42.32-.97-.18-.69-.63l2.93-4.66c.47-.74 1.47-.92 2.17-.4l2.34 1.82c.21.16.5.16.72 0l3.16-2.4c.42-.32.97.18.69.63"/></svg>',
			'telegram'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M9.78 18.65l.28-4.23l7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3L3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42"/></svg>',
			'viber'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M11.4 2c1.78.02 3.85.22 5.02.53c1.36.36 2.31 1.34 2.62 2.72c.27 1.2.36 2.6.34 4.03c-.02 1.43-.13 2.7-.4 3.75c-.31 1.16-1.13 2.02-2.29 2.36c-.38.11-.85.2-1.34.27l.01 2.36c0 .48-.57.72-.9.38l-2.13-2.19c-.3.01-.6.02-.9.02c-1.78-.02-3.55-.22-4.72-.53c-1.36-.36-2.31-1.34-2.62-2.72c-.27-1.2-.36-2.6-.34-4.03c.02-1.43.13-2.85.4-3.9c.31-1.16 1.13-2.02 2.29-2.36C9.34 2.16 9.63 2 11.4 2"/></svg>',
			'phone'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M6.62 10.79a15.15 15.15 0 0 0 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24c1.12.37 2.33.57 3.57.57c.55 0 1 .45 1 1V20c0 .55-.45 1-1 1c-9.39 0-17-7.61-17-17c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1c0 1.25.2 2.45.57 3.57c.11.35.03.74-.25 1.02z"/></svg>',
			'email'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2m0 4l-8 5l-8-5V6l8 5l8-5z"/></svg>',
		];

		return $icons[ $channel ] ?? $icons['whatsapp'];
	}

	/**
	 * Strip everything except digits (wa.me / viber / tel need bare digits).
	 *
	 * @since ??
	 *
	 * @param string $value Raw value.
	 *
	 * @return string
	 */
	public static function digits_only( $value ) {
		return preg_replace( '/[^0-9]/', '', (string) $value );
	}

	/**
	 * Replace {page_title} / {page_url} tokens using the current request.
	 *
	 * The FE script re-resolves these at click time from document.title /
	 * location.href so cached pages stay correct; this is the no-JS fallback.
	 *
	 * @since ??
	 *
	 * @param string $message Raw message.
	 *
	 * @return string
	 */
	public static function replace_tokens( $message ) {
		if ( '' === (string) $message ) {
			return '';
		}

		$page_title = function_exists( 'wp_get_document_title' ) ? wp_get_document_title() : get_bloginfo( 'name' );
		$page_url   = home_url( add_query_arg( [] ) );

		return str_replace(
			[ '{page_title}', '{page_url}' ],
			[ $page_title, $page_url ],
			$message
		);
	}

	/**
	 * Build the channel deep-link for one agent.
	 *
	 * This is the PHP mirror of src/components/ChatAgent/link-builder.ts and the
	 * FE script. Keep all three in sync.
	 *
	 * @since ??
	 *
	 * @param string $channel Channel key.
	 * @param string $contact Phone / username / email.
	 * @param string $prefill Optional pre-filled message (raw, tokens intact).
	 *
	 * @return string
	 */
	public static function build_agent_link( $channel, $contact, $prefill ) {
		$value   = trim( (string) $contact );
		$message = self::replace_tokens( $prefill );

		switch ( $channel ) {
			case 'messenger':
				return 'https://m.me/' . rawurlencode( $value );
			case 'telegram':
				return 'https://t.me/' . rawurlencode( $value );
			case 'viber':
				return 'viber://chat?number=' . self::digits_only( $value );
			case 'phone':
				return 'tel:' . self::digits_only( $value );
			case 'email':
				return '' !== $message
					? 'mailto:' . $value . '?subject=' . rawurlencode( $message )
					: 'mailto:' . $value;
			case 'whatsapp':
			default:
				return '' !== $message
					? 'https://wa.me/' . self::digits_only( $value ) . '?text=' . rawurlencode( $message )
					: 'https://wa.me/' . self::digits_only( $value );
		}
	}

	/**
	 * Child module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * Renders one clickable agent row: avatar (with online dot + channel badge),
	 * name and role. The same markup is produced in the VB by edit.tsx.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param \WP_Block      $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Child module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Background component.
		$background_component = ElementComponents::component(
			[
				'attrs'         => $attrs['module']['decoration'] ?? [],
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);

		$channel = $attrs['channel']['advanced']['value']['desktop']['value'] ?? 'whatsapp';
		$contact = $attrs['contact']['advanced']['value']['desktop']['value'] ?? '';
		$status  = $attrs['status']['advanced']['value']['desktop']['value'] ?? 'online';

		// Working hours (computed client-side against the agent timezone).
		$hours_mode    = $attrs['hours']['advanced']['mode']['desktop']['value'] ?? 'always-online';
		$hours_tz      = $attrs['hours']['advanced']['timezone']['desktop']['value'] ?? '0';
		$hours_start   = $attrs['hours']['advanced']['start']['desktop']['value'] ?? '09:00';
		$hours_end     = $attrs['hours']['advanced']['end']['desktop']['value'] ?? '17:00';
		$hours_days    = $attrs['hours']['advanced']['days']['desktop']['value'] ?? '1,2,3,4,5';
		$hours_offline = $attrs['hours']['advanced']['offlineText']['desktop']['value'] ?? '';

		$agent_prefill  = $attrs['agentPrefill']['advanced']['value']['desktop']['value'] ?? '';
		$parent_prefill = $parent_attrs['prefill']['advanced']['message']['desktop']['value'] ?? '';
		$prefill        = '' !== $agent_prefill ? $agent_prefill : $parent_prefill;

		$avatar_src = $attrs['avatar']['innerContent']['desktop']['value']['src'] ?? '';

		$href = self::build_agent_link( $channel, $contact, $prefill );

		// Avatar (image or placeholder) + status dot + channel badge.
		$avatar_inner = '' !== $avatar_src
			? $elements->render( [ 'attrName' => 'avatar' ] )
			: HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'dnxte-wa-agent-avatar-ph' ],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => self::default_avatar_svg(),
				]
			);

		$avatar_inner .= HTMLUtility::render(
			[
				'tag'        => 'span',
				'attributes' => [ 'class' => 'dnxte-wa-agent-dot' ],
			]
		);

		$avatar_inner .= HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-wa-agent-channel' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => self::channel_icon_svg( $channel ),
			]
		);

		$avatar_html = HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-wa-agent-avatar' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $avatar_inner,
			]
		);

		$offline_text_html = HTMLUtility::render(
			[
				'tag'        => 'span',
				'attributes' => [ 'class' => 'dnxte-wa-agent-offline-text' ],
			]
		);

		$info_html = HTMLUtility::render(
			[
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dnxte-wa-agent-info' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $elements->render( [ 'attrName' => 'name' ] ) . $elements->render( [ 'attrName' => 'role' ] ) . $offline_text_html,
			]
		);

		$agent_html = HTMLUtility::render(
			[
				'tag'               => 'a',
				'attributes'        => [
					'class'                => 'dnxte-wa-agent dnxte-wa-agent-' . $status . ' dnxte-wa-agent-' . $channel,
					'href'                 => esc_url( $href, [ 'http', 'https', 'mailto', 'tel', 'viber' ] ),
					'target'               => '_blank',
					'rel'                  => 'noopener noreferrer',
					'data-channel'         => esc_attr( $channel ),
					'data-contact'         => esc_attr( $contact ),
					'data-prefill'         => esc_attr( $prefill ),
					'data-wa-hours-mode'   => esc_attr( $hours_mode ),
					'data-wa-tz'           => esc_attr( $hours_tz ),
					'data-wa-start'        => esc_attr( $hours_start ),
					'data-wa-end'          => esc_attr( $hours_end ),
					'data-wa-days'         => esc_attr( $hours_days ),
					'data-wa-offline-text' => esc_attr( $hours_offline ),
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $avatar_html . $info_html,
			]
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [ ChatAgent::class, 'module_classnames' ],
				'stylesComponent'    => [ ChatAgent::class, 'module_styles' ],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				'children'           => $background_component . $agent_html,
			]
		);
	}
}
