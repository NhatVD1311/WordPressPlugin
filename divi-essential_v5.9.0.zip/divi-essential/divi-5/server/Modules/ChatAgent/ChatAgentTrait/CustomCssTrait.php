<?php
/**
 * ChatAgent::custom_css().
 *
 * @package MEE\Modules\ChatAgent
 * @since ??
 */

namespace DNXTE\Modules\ChatAgent\ChatAgentTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * This function is equivalent of JS const cssFields located in
	 * src/components/ChatAgent/custom-css.ts.
	 *
	 * @since ??
	 */
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/chat-agent' );
		return $block_type ? ( $block_type->customCssFields ?? [] ) : [];
	}

}
