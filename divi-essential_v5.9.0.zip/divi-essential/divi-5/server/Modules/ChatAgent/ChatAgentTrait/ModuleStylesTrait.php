<?php
/**
 * ChatAgent::module_styles().
 *
 * @package MEE\Modules\ChatAgent
 * @since ??
 */

namespace DNXTE\Modules\ChatAgent\ChatAgentTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/ChatAgent/styles.tsx.
	 *
	 * Every property is routed through Divi's style system via
	 * `$elements->style( advancedStyles => [ divi/common ] )` (with explicit
	 * selectors) so everything is auto-responsive and hover-capable without manual
	 * media queries.
	 *
	 * @since ??
	 *
	 * @param array $args Style component arguments.
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];
		$order_class = $args['orderClass'] ?? '';

		$avatar_selector = "{$order_class} .dnxte-wa-agent-avatar";
		$dot_selector    = "{$order_class} .dnxte-wa-agent-dot";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module + every custom-selector style routed through divi/common.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn'     => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									// Avatar size — square (width + height).
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $avatar_selector,
											'attr'     => $attrs['avatar']['advanced']['size'] ?? [],
											'property' => 'width',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $avatar_selector,
											'attr'     => $attrs['avatar']['advanced']['size'] ?? [],
											'property' => 'height',
										],
									],
									// Online-dot color.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $dot_selector,
											'attr'     => $attrs['status']['advanced']['onlineColor'] ?? [],
											'property' => 'background-color',
										],
									],
								],
							],
						]
					),

					// Name / role fonts.
					$elements->style( [ 'attrName' => 'name' ] ),
					$elements->style( [ 'attrName' => 'role' ] ),

					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}
}
