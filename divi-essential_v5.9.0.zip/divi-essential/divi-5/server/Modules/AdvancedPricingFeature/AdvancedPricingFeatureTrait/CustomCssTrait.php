<?php
/**
 * AdvancedPricingFeature::custom_css().
 *
 * @package MEE\Modules\AdvancedPricingFeature
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingFeature\AdvancedPricingFeatureTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * This function is equivalent of JS const cssFields located in
	 * src/components/AdvancedPricingFeature/custom-css.ts.
	 *
	 * @since ??
	 */
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/pricing-feature' );
		return $block_type ? ( $block_type->customCssFields ?? [] ) : [];
	}

}
