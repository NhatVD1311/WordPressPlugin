<?php
/**
 * AdvancedPricingFeature::module_styles().
 *
 * @package MEE\Modules\AdvancedPricingFeature
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingFeature\AdvancedPricingFeatureTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/AdvancedPricingFeature/styles.tsx.
	 *
	 * Every property is routed through Divi's style system via
	 * `$elements->style( advancedStyles => [ divi/common ] )` (with explicit
	 * selectors) so everything is auto-responsive and hover-capable without manual
	 * media queries.
	 *
	 * @since ??
	 *
	 * @param array $args Style component arguments.
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];
		$order_class = $args['orderClass'] ?? '';

		$row_selector      = "{$order_class} .dnxte-pricing-feature-row";
		$icon_selector     = "{$order_class} .dnxte-pricing-feature-icon";
		$included_selector = "{$order_class} .dnxte-pricing-feature-included .dnxte-pricing-feature-icon";
		$excluded_selector = "{$order_class} .dnxte-pricing-feature-excluded .dnxte-pricing-feature-icon";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module + every custom-selector style routed through divi/common.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn'     => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									// Included icon color — recolors monochrome + outline icons alike.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $included_selector,
											'attr'     => $attrs['icon']['advanced']['includedColor'] ?? [],
											'property' => 'color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$included_selector} svg, {$included_selector} svg [fill]:not([fill=\"none\"])",
											'attr'     => $attrs['icon']['advanced']['includedColor'] ?? [],
											'property' => 'fill',
										],
									],
									// Excluded icon color.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $excluded_selector,
											'attr'     => $attrs['icon']['advanced']['excludedColor'] ?? [],
											'property' => 'color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$excluded_selector} svg, {$excluded_selector} svg [fill]:not([fill=\"none\"])",
											'attr'     => $attrs['icon']['advanced']['excludedColor'] ?? [],
											'property' => 'fill',
										],
									],
									// Icon size — inner SVG is sized in em (see module.scss).
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $icon_selector,
											'attr'     => $attrs['icon']['advanced']['iconSize'] ?? [],
											'property' => 'font-size',
										],
									],
									// Row gap between icon and text.
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $row_selector,
											'attr'     => $attrs['feature']['advanced']['gap'] ?? [],
											'property' => 'gap',
										],
									],
									// Row alignment (vertical alignment of icon vs text).
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $row_selector,
											'attr'     => $attrs['feature']['advanced']['alignment'] ?? [],
											'property' => 'align-items',
										],
									],
									// Excluded-row dim level (user-controlled opacity).
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$row_selector}.dnxte-pricing-feature-excluded",
											'attr'     => $attrs['icon']['advanced']['excludedOpacity'] ?? [],
											'property' => 'opacity',
										],
									],
								],
							],
						]
					),

					// Feature text font.
					$elements->style( [ 'attrName' => 'text' ] ),

					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}
}
