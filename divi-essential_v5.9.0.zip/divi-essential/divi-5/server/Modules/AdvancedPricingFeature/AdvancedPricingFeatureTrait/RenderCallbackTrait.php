<?php
/**
 * AdvancedPricingFeature::render_callback()
 *
 * @package MEE\Modules\AdvancedPricingFeature
 * @since ??
 */

namespace DNXTE\Modules\AdvancedPricingFeature\AdvancedPricingFeatureTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\AdvancedPricingFeature\AdvancedPricingFeature;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use CustomCssTrait;

	/**
	 * Default "included" status icon (mdi:check). Kept in sync with the JS
	 * DEFAULT_INCLUDED_SVG.
	 *
	 * @since ??
	 *
	 * @return string
	 */
	public static function default_included_svg() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19L21 7l-1.41-1.41z"/></svg>';
	}

	/**
	 * Default "excluded" status icon (mdi:close). Kept in sync with the JS
	 * DEFAULT_EXCLUDED_SVG.
	 *
	 * @since ??
	 *
	 * @return string
	 */
	public static function default_excluded_svg() {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12z"/></svg>';
	}

	/**
	 * Child module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * Renders one feature row: a status icon (custom, or the default check/cross
	 * based on `status`) followed by the feature text. The same markup is produced
	 * in the VB by edit.tsx.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param \WP_Block      $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Child module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		// Background component.
		$background_component = ElementComponents::component(
			[
				'attrs'         => $attrs['module']['decoration'] ?? [],
				'id'            => $block->parsed_block['id'],

				// FE only.
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);

		$status     = $attrs['icon']['advanced']['status']['desktop']['value'] ?? 'included';
		$use_custom = ( $attrs['icon']['advanced']['useCustom']['desktop']['value'] ?? 'off' ) === 'on';
		$icon_value = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
		$custom_svg = ( is_array( $icon_value ) && ! empty( $icon_value['svg'] ) ) ? $icon_value['svg'] : '';
		if ( 'excluded' === $status ) {
			$default_svg = self::default_excluded_svg();
		} elseif ( 'included' === $status ) {
			$default_svg = self::default_included_svg();
		} else {
			$default_svg = ''; // 'none' → no automatic icon.
		}
		// 'none' means no icon at all — not even a custom one; the icon column is
		// dropped entirely (no empty span) so the text aligns flush.
		if ( 'none' === $status ) {
			$svg = '';
		} else {
			// The custom SVG is a raw block attr (kses never inspects block
			// attributes) headed for a passthrough sanitizer — scrub it, same
			// as NextAdvancedTab CommonTrait::get_tab_svg().
			$svg = ( $use_custom && '' !== $custom_svg )
				? \DNXTE\Shared\SvgSanitizer::sanitize( $custom_svg )
				: $default_svg;
		}

		$icon_html = '' !== $svg
			? HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [
						'class' => 'dnxte-pricing-feature-icon',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $svg,
				]
			)
			: '';

		$text_html = $elements->render( [ 'attrName' => 'text' ] );

		$row_html = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dnxte-pricing-feature-row dnxte-pricing-feature-' . $status,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_html . $text_html,
			]
		);

		return Module::render(
			[
				// FE only.
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [ AdvancedPricingFeature::class, 'module_classnames' ],
				'stylesComponent'    => [ AdvancedPricingFeature::class, 'module_styles' ],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				'children'           => $background_component . $row_html,
			]
		);
	}
}
