<?php
/**
 * NextButton::render_callback()
 *
 * @package MEE\Modules\NextButton
 * @since ??
 */

namespace DNXTE\Modules\NextButton\NextButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use Exception;

trait StyleDeclarationTrait {
    	/**
	 * Icon Font declaration.
	 *
	 * This function will declare icon font for Child module.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array      $attrValue  The value (breakpoint > state > value) of module attribute.
	 *     @type bool|array $important  If set to true, the CSS will be added with !important.
	 *     @type string     $returnType This is the type of value that the function will return. Can be either string or key_value_pair.
	 * }
	 *
	 * @return string
	 * @since ??
	 */
	public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
					'font-weight' => true,
				],
			]
		);


		if ( isset( $icon_attr['type'] ) ) {
			$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		if ( ! empty( $icon_attr['weight'] ) ) {
			$style_declarations->add( 'font-weight', $icon_attr['weight'] );
		}

		if ( ! empty( $icon_attr['unicode'] ) ) {
			$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		}

		return $style_declarations->value();
	}

	public static function icon_on_hover_style_declaration( array $params ): string {
		$icon_attr = $params['attrValue'];

		$icon_placement = $icon_attr['icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['icon']['advanced']['onHover']['desktop']['value'] ?? 'on';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		if('on' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('off' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('on' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}
		if('off' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}

		

		return $style_declarations->value();
	}
}