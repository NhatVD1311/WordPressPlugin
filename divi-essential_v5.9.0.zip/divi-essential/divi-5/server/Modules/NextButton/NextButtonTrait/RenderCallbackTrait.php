<?php
/**
 * NextButton::render_callback()
 *
 * @package MEE\Modules\NextButton
 * @since ??
 */

namespace DNXTE\Modules\NextButton\NextButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Framework\Utility\HTMLUtility;
use DNXTE\Modules\NextButton\NextButton;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use ET\Builder\Packages\Module\Options\Attributes\AttributeUtils;
use Exception;
use WP_Block;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	/**
	 * Divi 4 module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of D4 module.
	 */
	public static function render_callback( array $attrs, string $content, WP_Block $block, ModuleElements $elements, array $default_printed_style_attrs ):string {
		// Button Text.
		//die('Render Callback');
        $button_text = $attrs['button_text']['innerContent']['desktop']['value']['text'] ?? '';
		$button_link = $attrs['button_text']['innerContent']['desktop']['value']['linkUrl'] ?? '#';
		$button_target_value = $attrs['button_text']['innerContent']['desktop']['value']['linkTarget'] ?? '';


		$button_text = empty( $button_text ) && ! empty( $button_link) ? esc_url( $button_link) : esc_attr( $button_text);


		$button_alignment_desktop = $attrs['button_text']['advanced']['alignment']['desktop']['value'] ?? 'left';
		$button_alignment_tablet = $attrs['button_text']['advanced']['alignment']['tablet']['value'] ?? $button_alignment_desktop;
		$button_alignment_phone = $attrs['button_text']['advanced']['alignment']['phone']['value'] ?? $button_alignment_tablet;

		

		$button_target = 'on' === $button_target_value ? '_blank' : null;

		// Custom attributes — legacy (old custom_attributes approach for backward compatibility)
		$custom_attributes_enabled = $attrs['custom_attributes']['advanced']['enabled']['desktop']['value'] ?? 'off';
		$custom_attributes = [];

		if ('on' === $custom_attributes_enabled) {
			$custom_attributes_string = $attrs['custom_attributes']['advanced']['attributes']['desktop']['value'] ?? '';
			if (! empty($custom_attributes_string)) {
				$decoded = json_decode($custom_attributes_string, true);
				if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
					$custom_attributes = $decoded;
				}
			}
		}

		// Custom attributes — Divi 5 standard way via Advanced > Attributes panel.
		// module.decoration.attributes stores attributes with targetElement; 'main' goes to
		// the module wrapper (handled by Module::render()), all other targets are applied
		// to the anchor <a> element since it is the primary interactive element.
		$module_decoration_attributes = $attrs['module']['decoration']['attributes'] ?? [];
		if ( ! empty( $module_decoration_attributes ) ) {
			$separated = AttributeUtils::separate_attributes_by_target_element( $module_decoration_attributes );
			unset( $separated['main'] ); // 'main' is already handled by Module::render()
			foreach ( $separated as $target_attrs ) {
				foreach ( $target_attrs as $attr_name => $attr_value ) {
					if ( isset( $custom_attributes[ $attr_name ] ) ) {
						$custom_attributes[ $attr_name ] = AttributeUtils::merge_attribute_values(
							$attr_name,
							$custom_attributes[ $attr_name ],
							$attr_value
						);
					} else {
						$custom_attributes[ $attr_name ] = $attr_value;
					}
				}
			}
		}

		$hover_effect_two_d = $attrs['two_d_hover_effect']['innerContent']['desktop']['value']['twodeffect'] ?? '';
		$bg_hover_effect = $attrs['bg_hover_effect']['innerContent']['desktop']['value']['bghovereffect'] ?? '';
		$stroke_hover_effect = $attrs['stroke_hover_effect']['innerContent']['desktop']['value']['strokehovereffect'] ?? '';
		$icon_hover_effect = $attrs['icons_hover_effect']['innerContent']['desktop']['value']['iconhovereffect'] ?? '';

		$use_icon   = $attrs['icon']['advanced']['use']['desktop']['value'] ?? 'on';
		$icon_value = Utils::process_font_icon($attrs['icon']['advanced']['icon']['desktop']['value']) ?? '';
		
		$icon_placement = $attrs['icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$btn_icon_on_hover = 'on' !== $attrs['icon']['advanced']['onHover']['desktop']['value'] ? 'dnxt-btn-icon-on-hover' : '';
		
		
		// Icon enabled.
		$is_icon_enabled = 'on' === $use_icon;
		
		// Icon.
		$icon_left       = ! empty( $icon_value ) && $is_icon_enabled && 'left'  === $icon_placement ? HTMLUtility::render(
			[
				'tag'               => 'i',
				'attributes'        => [],
				'childrenSanitizer' =>  'esc_html',
				'children'          =>  $icon_value,
			]
		) : '';
		$icon_right       = ! empty( $icon_value ) && $is_icon_enabled && 'right'  === $icon_placement ? HTMLUtility::render(
			[
				'tag'               => 'i',
				'attributes'        => [],
				'childrenSanitizer' =>  'esc_html',
				'children'          =>  $icon_value,
			]
		) : '';

		// Button Wrapper.
        $button_wrapper = HTMLUtility::render(
            [
              'tag'               =>  'div',
              'attributes'        =>  [
                'class'         => 'et_pb_module_inner',
              ],
              'childrenSanitizer' =>  'et_core_esc_previously',
              'children'          =>  [
                HTMLUtility::render(
                  [
                    'tag'               => 'div',
                    'attributes'        => [
                      'class'           => HTMLUtility::classnames(
						[
							'dnxt-button-wrapper' => true,
							"dnxt_button_alignment_{$button_alignment_desktop}" => ! empty( $button_alignment_desktop ),
							"dnxt_button_alignment_{$button_alignment_tablet}_tablet" => ! empty( $button_alignment_tablet ),
							"dnxt_button_alignment_{$button_alignment_phone}_phone" => ! empty( $button_alignment_phone ),
						]
					  ), 
                    ],
                    'childrenSanitizer' =>  'et_core_esc_previously',
                    'children'          => [
                      HTMLUtility::render(
                        [
                          'tag'         => 'a',
                          'attributes'  => array_merge([
                            'href' => $button_link,
                            'class'=> HTMLUtility::classnames(
								[
									'dnxt-btn-icon'  => true,
									
								],
								$btn_icon_on_hover,
								$hover_effect_two_d,
								$bg_hover_effect,
								$stroke_hover_effect,
								$icon_hover_effect
							),
                            'target'  => $button_target
                          ], $custom_attributes),
                          'childrenSanitizer' =>  'et_core_esc_previously',
                          'children'  => $elements->style_components(
                            [
                              'attrName' => 'button_text',
                            ]
                          ) . $icon_left . $button_text . $icon_right
                        ]
                      )
                    ]
                  ]
                )
              ],
            ]
          );



		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ NextButton::class, 'module_classnames' ],
				'stylesComponent'     => [ NextButton::class, 'module_styles' ],
				'scriptDataComponent' => [ NextButton::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
                'hasModuleWrapper'    => false,
				'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $button_wrapper
			]
		);
	}
}
