<?php
/**
 * NextButton::module_styles().
 *
 * @package MEE\Modules\NextButton
 * @since ??
 */

namespace DNXTE\Modules\NextButton\NextButtonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait ModuleStylesTrait {
	use CustomCssTrait;
	//use StyleDeclarationTrait;


	public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
            [
                'returnType' => 'string',
                'important'  => [
                    'font-family' => true,
                    'font-weight' => true,
                ],
            ]
        );

        if ( isset( $icon_attr['type'] ) ) {
            $font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
            $style_declarations->add( 'font-family', $font_family );
        }

        if ( ! empty( $icon_attr['weight'] ) ) {
            $style_declarations->add( 'font-weight', $icon_attr['weight'] );
        }

        if ( ! empty( $icon_attr['unicode'] ) ) {
            $unicode = Utils::process_font_icon( $icon_attr );
            $unicode = trim( (string) $unicode );
            // Strip accidental trailing quotes/semicolons
            $unicode = preg_replace( '/[;\'"]+$/', '', $unicode );

            // Normalize formats: &#xE090;, E090, \E090 -> \E090
            if ( preg_match( '/^&#x([0-9a-fA-F]{1,6});?$/', $unicode, $m ) ) {
                $unicode = $m[1];
            }
            if ( preg_match( '/^[0-9a-fA-F]{1,6}$/', $unicode ) ) {
                $unicode = '\\' . $unicode;
            }

            $is_valid = (bool) preg_match( '/^\\\[0-9a-fA-F]{1,6}$/', $unicode );

            if ( $is_valid ) {
                $style_declarations->add( 'content', '"' . $unicode . '"' );
            }
        }

        return $style_declarations->value();
    }

	public static function icon_on_hover_style_declaration( array $params ): string {
		$icon_attr = $params['attrValue'];

		$icon_placement = $icon_attr['icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$icon_on_hover = $icon_attr['icon']['advanced']['onHover']['desktop']['value'] ?? 'on';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => true,
			]
		);

		if('on' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('off' === $icon_on_hover && 'right' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-left', '0.4em' );
		}
		if('on' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}
		if('off' === $icon_on_hover && 'left' === $icon_placement) {
			$style_declarations->add( 'opacity', '1' );
			$style_declarations->add( 'visibility', 'visible' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'padding-right', '0.4em' );
		}

		

		return $style_declarations->value();
	}

	public static function applyHoverStyles($selector, $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass) {
		$styles = [];
	
		$styles[] = CommonStyle::style(
			[
				'selector' => "{$orderClass} {$selector}",
				'property' => 'background',
				'attr'     => $mainBackgroundAttr,
				"important" => true,
			]
		);
	
		$styles[] = CommonStyle::style(
			[
				'selector' => "{$orderClass} {$selector}:before",
				'property' => 'background',
				'attr'     => $beforeBackgroundAttr,
				"important" => true,
			]
		);
	
		return $styles;
	
	}

	/**
	 * D4 module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/d4-module/styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string $id                Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *      @type string $name              Module name.
	 *      @type string $attrs             Module attributes.
	 *      @type string $parentAttrs       Parent attrs.
	 *      @type string $orderClass        Selector class name.
	 *      @type string $parentOrderClass  Parent selector class name.
	 *      @type string $wrapperOrderClass Wrapper selector class name.
	 *      @type string $settings          Custom settings.
	 *      @type string $state             Attributes state.
	 *      @type string $mode              Style mode.
	 *      @type ModuleElements $elements         ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';


		$hover_bg_value = $attrs['bg_hover_effect']['innerContent']['desktop']['value']['bghovereffect'] ?? null;

		$has_bg_color = [
			'dnxt-hover-radial-out',
			'dnxt-hover-radial-in',
			'dnxt-hover-rectangle-in',
			'dnxt-hover-rectangle-out',
			'dnxt-hover-shutter-in-horizontal',
			'dnxt-hover-shutter-out-horizontal',
			'dnxt-hover-shutter-in-vertical',
			'dnxt-hover-shutter-out-vertical',   
		];

		$hover_bg_color = in_array($hover_bg_value ?? null, $has_bg_color);


		$hoverStyle = [];
		if ($hover_bg_color !== true) {
			$hoverStyle = [
				CommonStyle::style(
					[
						'selector' => "$order_class .dnxt-btn-icon.{$hover_bg_value}:before, $order_class .dnxt-btn-icon.dnxt-hover-fade:hover",
						'attr'     => $attrs['button_text']['advanced']['hasbghovercolor'] ?? [],
						'property' => 'background',
						'important' => true
					]
					)
			];
		}
		

		$hover_bg_value = $attrs['bg_hover_effect']['innerContent']['desktop']['value']['bghovereffect'] ?? null;
		$mainBackgroundAttr = $attrs['button_text']['advanced']['hasbghovercolor'] ?? null;
		$beforeBackgroundAttr = $attrs['button_text']['advanced']['bghovercolor'] ?? null;
		$orderClass = $args['orderClass'];

		$styles = [];

		switch ($hover_bg_value) {
		case 'dnxt-hover-fade':
			// Get the actual color value for fade effect
			$fadeColorValue = $mainBackgroundAttr['desktop']['value'] ?? '#29c4a9';
			$styles[] = CommonStyle::style(
				[
					'selector' => "{$orderClass} .dnxt-btn-icon.dnxt-hover-fade:before",
					'property' => 'background',
					'attr'     => ['desktop' => ['value' => $fadeColorValue]],
					'important' => true,
				]
			);
			$styles[] = CommonStyle::style(
				[
					'selector' => "{$orderClass} .dnxt-btn-icon.dnxt-hover-fade:hover",
					'property' => 'background',
					'attr'     => ['desktop' => ['value' => $fadeColorValue]],
					'important' => true,
				]
			);
			break;
		case 'dnxt-hover-radial-out':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-out', $beforeBackgroundAttr, $mainBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-radial-in':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-radial-in', $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-rectangle-in':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-in', $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-rectangle-out':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-rectangle-out', $beforeBackgroundAttr, $mainBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-shutter-in-horizontal':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-in-horizontal', $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-shutter-out-horizontal':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-out-horizontal', $beforeBackgroundAttr, $mainBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-shutter-in-vertical':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-in-vertical', $mainBackgroundAttr, $beforeBackgroundAttr, $orderClass)
			);
			break;
		case 'dnxt-hover-shutter-out-vertical':
			$styles = array_merge(
			$styles,
			self::applyHoverStyles('.dnxt-hover-shutter-out-vertical', $beforeBackgroundAttr, $mainBackgroundAttr, $orderClass)
			);
			break;
		// Add more cases if needed
		default:
			// Handle default case if necessary
			break;
		}
		
		$hover_stroke_value = $attrs['stroke_hover_effect']['innerContent']['desktop']['value']['strokehovereffect'] ?? '';


		
		$has_stroke_bg_color = [
			'dnxt-hover-underline-from-left',
			'dnxt-hover-underline-from-center',
			'dnxt-hover-underline-from-right',
			'dnxt-hover-overline-from-left',
			'dnxt-hover-overline-from-center',
			'dnxt-hover-overline-from-right',
			'dnxt-hover-underline-reveal',
			'dnxt-hover-overline-reveal', 
		];

		$hover_stroke_color = in_array($hover_stroke_value ?? null, $has_stroke_bg_color);

		$icon_hover_effect = $attrs['icons_hover_effect']['innerContent']['desktop']['value']['iconhovereffect'] ?? '';


		//die('Style Added');
		$style_button =Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
								'disabledOn'               => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'] . ' .dnxt-button-wrapper a',
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
					TextStyle::style(
						[
							'selector' => $order_class . ' .example_d4_module_inner',
							'attr'     => $attrs['module']['advanced']['text'] ?? [],
						]
					),

					CommonStyle::style(
						[
							'selector' => "$order_class .{$hover_stroke_value}:before",
							'property'=> 'border-color',
							'attr'     => $attrs['button_text']['advanced']['strokehovercolor'] ?? [],
						]
					),
					CommonStyle::style(
						[
							'selector' => "$order_class .{$hover_stroke_value}:before",
							'property'=> $hover_stroke_color ? 'background' : 'border-color',
							'attr'     => $attrs['button_text']['advanced']['strokehovercolor'] ?? [],
							'important' => true,
						]
					),
					...$hoverStyle,
					...$styles,

					// Title.
					$elements->style(
						[
							'attrName' => 'button_text'			
						]
					),
					CommonStyle::style(
						[
							'selector'  => "{$args['orderClass']} .dnxt-btn-icon i",
							'attr'      => $attrs['icon']['advanced']['color'] ?? [],
							'property'  => 'color',
							'important' => true,
						]
					),
					( ! empty( $attrs['icon']['advanced']['color']['desktop']['hover'] ) ? CommonStyle::style(
						[
							'selector'  => "{$args['orderClass']} .dnxt-button-wrapper a:hover i",
							'attr'      => [
								'desktop' => [
									'value' => $attrs['icon']['advanced']['color']['desktop']['hover']
								]
							],
							'property'  => 'color',
							'important' => true,
						]
					) : '' ),
					$elements->style(
						[
							'attrName' => 'icon',
							'styleProps'=> [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .dnxt-btn-icon i",
											'attr'     => $attrs['icon']['advanced']['icon'] ?? [],
											'declarationFunction' => [ self::class, 'icon_style_declaration' ],
										],
									],
								]
							]
						]
					),
					// Icon visibility + spacing between icon and text (matches VB CommonStyle logic).
					...self::icon_visibility_styles( $attrs, $args['orderClass'] ),
				]
			]
		);
	}

	/**
	 * Generate icon visibility and spacing styles matching VB CommonStyle conditionals.
	 *
	 * @param array  $attrs      Module attributes.
	 * @param string $order_class Module order class selector.
	 *
	 * @return array Array of CommonStyle::style() results.
	 */
	public static function icon_visibility_styles( array $attrs, string $order_class ): array {
		$icon_on_hover  = $attrs['icon']['advanced']['onHover']['desktop']['value'] ?? 'on';
		$icon_placement = $attrs['icon']['advanced']['placement']['desktop']['value'] ?? 'right';
		$styles         = [];

		// Determine the padding direction based on icon placement.
		$padding_prop = 'right' === $icon_placement ? 'padding-left' : 'padding-right';
		$css_value    = "opacity:1; visibility:visible; margin-left:0; {$padding_prop}:0.4em;";

		if ( 'on' === $icon_on_hover ) {
			// Show icon only on hover.
			$styles[] = CommonStyle::style(
				[
					'selector'  => "{$order_class} .dnxt-btn-icon:hover i",
					'attr'      => $attrs['icon']['advanced']['onHover'] ?? [],
					'property'  => $css_value,
				]
			);
		} else {
			// Always show icon.
			$styles[] = CommonStyle::style(
				[
					'selector'  => "{$order_class} .dnxt-btn-icon.dnxt-btn-icon-on-hover i",
					'attr'      => $attrs['icon']['advanced']['onHover'] ?? [],
					'property'  => $css_value,
				]
			);
		}

		return $styles;
	}
}
