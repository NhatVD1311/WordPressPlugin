<?php
/**
 * Module: Next Filterable CPT Module class.
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\FilterableCpt\FilterableCptTrait;

define( 'DNXTE_FILTERABLE_CPT_LAYOUTS', dirname( __FILE__ ) . '/layout/' );

class FilterableCpt implements DependencyInterface {
	use FilterableCptTrait\RenderCallbackTrait;
	use FilterableCptTrait\AjaxHandlerTrait;

	/**
	 * Whitelist an alignment value used in CSS class names. Module attrs (and
	 * the AJAX params echoing them) are attacker-controlled for builder-role
	 * users, and these values are interpolated into class attributes — never
	 * emit anything outside the known set.
	 *
	 * @param mixed $value Raw alignment value.
	 * @return string 'left'|'center'|'right' or ''.
	 */
	public static function sanitize_alignment( $value ) {
		return in_array( $value, array( 'left', 'center', 'right' ), true ) ? $value : '';
	}

	/**
	 * Whitelist the title heading level. It is used as a literal HTML tag name
	 * (Divi's tag_escape strips characters, not names — 'script' would pass).
	 *
	 * @param mixed $value Raw heading level.
	 * @return string A safe tag name; 'h2' when unrecognized.
	 */
	public static function sanitize_heading_level( $value ) {
		$allowed = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div' );
		return in_array( $value, $allowed, true ) ? $value : 'h2';
	}

	/**
	 * The only button class this module ever emits. The AJAX handler must not
	 * trust an arbitrary class string from POST; it only decides WHETHER the
	 * fixed class applies.
	 *
	 * @param mixed $value Raw class string (from POST or attrs).
	 * @return string The fixed custom-button class or ''.
	 */
	public static function sanitize_button_class( $value ) {
		return 'et_pb_button et_pb_custom_button_icon' === $value ? $value : '';
	}

	/**
	 * Loads `FilterableCpt` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'FilterableCpt/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ FilterableCpt::class, 'render_callback' ],
					]
				);
			}
		);

		add_action( 'wp_ajax_dnxte_filterable_cpt_filter', [ self::class, 'handle_filter_request' ] );
		add_action( 'wp_ajax_nopriv_dnxte_filterable_cpt_filter', [ self::class, 'handle_filter_request' ] );
		add_action( 'rest_api_init', [ self::class, 'register_rest_routes' ] );
	}

	/**
	 * Register REST API routes for the post grid module.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			'dnxte/v1',
			'/filterable-cpt/categories',
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_categories_by_post_type' ],
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => [
					'post_type' => [
						'required'          => false,
						'default'           => 'post',
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			]
		);

		register_rest_route(
			'dnxte/v1',
			'/filterable-cpt/post-types',
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_public_post_types' ],
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			]
		);
	}

	/**
	 * Return every public post type as a label/value map keyed by slug.
	 *
	 * Mirrors the shape Divi expects for SelectContainer options:
	 *   { post: { label: "Posts" }, product: { label: "Products" }, ... }
	 *
	 * @since ??
	 *
	 * @return \WP_REST_Response
	 */
	public static function get_public_post_types() {
		$types  = get_post_types(
			[
				'public'  => true,
				'show_ui' => true,
			],
			'objects'
		);

		// Hide a few internal types that aren't meaningful for a post grid.
		$excluded = [ 'attachment', 'elementor_library', 'et_pb_layout', 'et_theme_builder' ];

		$result = [];
		foreach ( $types as $slug => $obj ) {
			if ( in_array( $slug, $excluded, true ) ) {
				continue;
			}
			$result[ $slug ] = [
				'label' => $obj->labels->name,
			];
		}

		// Always include the basic 'post' fallback so the dropdown is never empty.
		if ( empty( $result ) ) {
			$result['post'] = [ 'label' => __( 'Posts', 'dnxte-divi-essential' ) ];
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * Get the primary hierarchical taxonomy for a post type.
	 *
	 * @since ??
	 *
	 * @param string $post_type The post type slug.
	 *
	 * @return string|null Taxonomy name or null if none found.
	 */
	public static function get_primary_taxonomy( $post_type ) {
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );

		// Well-known category taxonomies per post type.
		$known = [
			'post'    => 'category',
			'product' => 'product_cat',
		];

		if ( isset( $known[ $post_type ], $taxonomies[ $known[ $post_type ] ] ) ) {
			return $known[ $post_type ];
		}

		// Fallback: first hierarchical public taxonomy.
		foreach ( $taxonomies as $tax ) {
			if ( $tax->hierarchical && $tax->public ) {
				return $tax->name;
			}
		}

		return null;
	}

	/**
	 * Get categories/taxonomy terms for a given post type.
	 *
	 * @since ??
	 *
	 * @param \WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public static function get_categories_by_post_type( $request ) {
		$post_type = $request->get_param( 'post_type' );
		$taxonomy  = self::get_primary_taxonomy( $post_type );

		// No hierarchical taxonomy found (e.g., page) — return empty.
		if ( ! $taxonomy ) {
			return new \WP_REST_Response( [], 200 );
		}

		$terms = get_terms( [
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => 0,
		] );

		if ( is_wp_error( $terms ) ) {
			return new \WP_REST_Response( [], 200 );
		}

		$result = array_map( function ( $term ) {
			return [
				'id'   => $term->term_id,
				'name' => $term->name,
			];
		}, $terms );

		return new \WP_REST_Response( $result, 200 );
	}
}
