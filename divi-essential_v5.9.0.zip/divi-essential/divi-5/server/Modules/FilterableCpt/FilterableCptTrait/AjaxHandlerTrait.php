<?php
/**
 * FilterableCpt::handle_filter_request()
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if (!defined('ABSPATH')) {
	die('Direct access forbidden.');
}

use ET\Builder\Framework\Utility\HTMLUtility;
use DNXTE\Modules\FilterableCpt\FilterableCpt;
use DNXTE\Shared\LayoutTemplate;
use WP_Query;

trait AjaxHandlerTrait
{

	/**
	 * Handle AJAX filter/pagination request for the Filterable CPT module.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public static function handle_filter_request()
	{
		check_ajax_referer('dnxte_filterable_cpt_nonce', 'nonce');

		// Sanitize inputs.
		$category = sanitize_text_field($_POST['category'] ?? 'all');
		$page = absint($_POST['page'] ?? 1);
		$posts_per_page = absint($_POST['posts_per_page'] ?? 6);
		$orderby = sanitize_text_field($_POST['orderby'] ?? 'date');
		$order = sanitize_text_field($_POST['order'] ?? 'DESC');
		$post_type = sanitize_key(wp_unslash($_POST['post_type'] ?? 'post'));

		// Validate the post type exists and (for logged-out requests) is public, so
		// private/internal CPTs cannot be enumerated through this endpoint. The
		// nonce above is printed on every public page, so it proves nothing about
		// who is asking. Mirrors the guard in includes/functions.php.
		if (!post_type_exists($post_type)) {
			wp_send_json_success([
				'html' => '',
				'max_pages' => 0,
				'current_page' => 1,
				'found_posts' => 0,
			]);
			return;
		}
		// Revisions inherit their parent's content, so querying them would leak
		// draft/private post content to anyone who can pass the status filter.
		// Non-public post types are for builder-capable users only: a plain
		// subscriber login must not widen what this public-nonce endpoint
		// exposes beyond what a logged-out visitor gets.
		$pt_obj = get_post_type_object($post_type);
		if ('revision' === $post_type
			|| (!current_user_can('edit_posts') && (!$pt_obj || empty($pt_obj->public)))) {
			wp_send_json_success([
				'html' => '',
				'max_pages' => 0,
				'current_page' => 1,
				'found_posts' => 0,
			]);
			return;
		}

		// This value picks the included layout template. sanitize_text_field() only
		// normalises the text — it leaves `../` intact — so resolve_name() is what
		// keeps the include inside the module's own layout directory.
		$layout = LayoutTemplate::resolve_name(DNXTE_FILTERABLE_CPT_LAYOUTS, sanitize_text_field(wp_unslash($_POST['layout'] ?? 'card')));
		$offset_base = absint($_POST['offset'] ?? 0);
		$search = sanitize_text_field($_POST['search'] ?? '');
		$no_results_text = sanitize_text_field($_POST['no_results_text'] ?? 'No posts found.');

		// Element toggles — use same variable names as RenderCallbackTrait so layout files work.
		$show_title = sanitize_text_field($_POST['show_title'] ?? 'on');
		$show_date = sanitize_text_field($_POST['show_date'] ?? 'on');
		$show_author = sanitize_text_field($_POST['show_author'] ?? 'on');
		$show_categories = sanitize_text_field($_POST['show_categories'] ?? 'on');
		$show_excerpt = sanitize_text_field($_POST['show_excerpt'] ?? 'off');
		$show_readmore = sanitize_text_field($_POST['show_readmore'] ?? 'off');
		$reamMoreText = sanitize_text_field($_POST['readmore_text'] ?? 'Read More');
		$show_thumbnail = sanitize_text_field($_POST['show_thumbnail'] ?? 'on');
		$dnxte_feaimage_thumb_size = sanitize_text_field($_POST['featured_image_size'] ?? 'large');
		$date_format = sanitize_text_field($_POST['date_format'] ?? 'M j, Y');
		$excerpt_length = absint($_POST['excerpt_length'] ?? 20);
		$excerpt_length_type = sanitize_text_field($_POST['excerpt_length_type'] ?? 'words');
		$content_length = absint($_POST['content_length'] ?? 0);
		$postTarget = sanitize_text_field($_POST['post_target'] ?? '_self');
		$heading_level = FilterableCpt::sanitize_heading_level(sanitize_text_field($_POST['heading_level'] ?? 'h2'));
		$show_comment_count = sanitize_text_field($_POST['show_comment_count'] ?? 'off');
		$date_position = sanitize_text_field($_POST['date_position'] ?? 'bottom');
		$excerpt_content = sanitize_text_field($_POST['excerpt_content'] ?? 'off');
		// Alignments land in class attributes and button_class in an <a> class —
		// these arrive from module data attributes (builder-controlled), so
		// whitelist rather than echo (see FilterableCpt::sanitize_* docs).
		$meta_alingment = FilterableCpt::sanitize_alignment(sanitize_text_field($_POST['meta_alignment'] ?? ''));
		$meta_separator = sanitize_text_field($_POST['meta_separator'] ?? '|');
		$button_alingment = FilterableCpt::sanitize_alignment(sanitize_text_field($_POST['button_alignment'] ?? ''));
		$customBtnStyleClassName = FilterableCpt::sanitize_button_class(sanitize_text_field($_POST['button_class'] ?? ''));
		$button_icon = sanitize_text_field($_POST['button_icon'] ?? '');
		$button_data_icon_attr = ! empty($button_icon) ? sprintf(' data-icon="%s"', esc_attr($button_icon)) : '';

		// Icon visibility toggles.
		$show_date_icon = sanitize_text_field($_POST['show_date_icon'] ?? 'on');
		$show_author_avatar = sanitize_text_field($_POST['show_author_avatar'] ?? 'on');
		$show_comment_icon = sanitize_text_field($_POST['show_comment_icon'] ?? 'on');
		$category_count    = absint($_POST['category_count'] ?? 3);

		// Element order values.
		$title_order    = absint($_POST['title_order'] ?? 1);
		$meta_order     = absint($_POST['meta_order'] ?? 2);
		$content_order  = absint($_POST['content_order'] ?? 3);
		$readmore_order = absint($_POST['readmore_order'] ?? 4);

		// Icon HTML passed from the frontend data attributes — only use if toggle is on.
		$date_icon = 'on' === $show_date_icon ? wp_kses_post($_POST['icon_date'] ?? '') : '';
		$comment_icon = 'on' === $show_comment_icon ? wp_kses_post($_POST['icon_comment'] ?? '') : '';

		// Build WP_Query args.
		$query_args = [
			'posts_per_page' => $posts_per_page,
			'paged' => $page,
			'post_status' => ['publish', 'private', 'inherit'],
			'perm' => 'readable',
			'post_type' => $post_type,
			'orderby' => $orderby,
			'order' => $order,
		];

		// Keyword search — build a custom partial-match WHERE clause instead of using
		// WP_Query's built-in `s` parameter. Search plugins / word-based indexers
		// (Relevanssi, SearchWP, etc.) hook the `s` search path and fall back to
		// whole-word matching, which breaks partial matches like "ava" -> "Avatar".
		// A direct LIKE '%term%' guarantees substring matching and composes (AND)
		// with the category tax_query below.
		$search_where = '';
		if ('' !== $search) {
			global $wpdb;
			$like = '%' . $wpdb->esc_like($search) . '%';
			$search_where = $wpdb->prepare(
				" AND ({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_excerpt LIKE %s OR {$wpdb->posts}.post_content LIKE %s) ",
				$like,
				$like,
				$like
			);
		}

		if ($offset_base > 0) {
			$query_args['offset'] = $offset_base + (($page - 1) * $posts_per_page);
		}

		// Category filter — use the correct taxonomy for the post type.
		// $category may be a single slug or a comma-separated list of slugs
		// (the frontend sends the included-category slugs when "All" is clicked).
		$primary_taxonomy = FilterableCpt::get_primary_taxonomy( $post_type );
		if ('all' !== $category && !empty($category) && $primary_taxonomy) {
			$terms = array_filter( array_map( 'trim', explode( ',', $category ) ) );
			$query_args['tax_query'] = [
				[
					'taxonomy' => $primary_taxonomy,
					'field'    => 'slug',
					'terms'    => $terms,
				],
			];
		}

		// Apply the partial-match search clause only around this query, then detach it
		// so no other query on the request is affected.
		$search_filter = null;
		if ('' !== $search_where) {
			$search_filter = function ($where) use ($search_where) {
				return $where . $search_where;
			};
			add_filter('posts_where', $search_filter);
		}

		$wp_query = new WP_Query($query_args);

		if (null !== $search_filter) {
			remove_filter('posts_where', $search_filter);
		}

		$output = '';

		if ($wp_query->have_posts()) {
			while ($wp_query->have_posts()) {
				$wp_query->the_post();

				$has_thumbnail = has_post_thumbnail() || 'attachment' === get_post_type();

				// Build image — MUST match RenderCallbackTrait exactly so load-more posts
				// get the same click-through links and hover behavior as initial posts.
				$image_wrapper = '';
				if ($has_thumbnail && 'on' === $show_thumbnail) {
					if ('custom' === $dnxte_feaimage_thumb_size) {
						$thumb_width = absint($_POST['thumb_width'] ?? 600);
						$thumb_height = absint($_POST['thumb_height'] ?? 400);
						add_image_size('dnxte_custom_image_size', $thumb_width, $thumb_height);
						$post_thumbnail = get_the_post_thumbnail(get_the_ID(), 'dnxte_custom_image_size', ['class' => 'dnxte-blog-featured-image']);
					} else {
						$post_thumbnail = get_the_post_thumbnail(get_the_ID(), $dnxte_feaimage_thumb_size, ['class' => 'dnxte-blog-featured-image']);
					}

					// Wrap the <img> in <a href> so the thumbnail is clickable.
					$image = HTMLUtility::render(
						[
							'tag' => 'div',
							'attributes' => [
								'class' => 'dnxte-post-thumb',
							],
							'children' => [
								HTMLUtility::render(
									[
										'tag' => 'a',
										'attributes' => [
											'href' => get_permalink(),
											'target' => $postTarget,
										],
										'children' => $post_thumbnail,
										'childrenSanitizer' => 'et_core_esc_previously',
									]
								),
							],
							'childrenSanitizer' => 'et_core_esc_previously',
						]
					);

					$image_wrapper = HTMLUtility::render(
						[
							'tag' => 'div',
							'attributes' => [
								'class' => 'blog-wrap',
							],
							'children' => $image,
							'childrenSanitizer' => 'et_core_esc_previously',
						]
					);
				}

				// Title — wrapped in <a href> so the title is clickable (matches RenderCallbackTrait).
				$title = '';
				if ('on' === $show_title) {
					$title = HTMLUtility::render([
						'tag' => 'a',
						'attributes' => [
							'href' => get_permalink(),
							'target' => $postTarget,
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children' => [
							HTMLUtility::render([
								'tag' => $heading_level,
								'attributes' => ['class' => 'dnxte-filterable-cpt-card-title'],
								'childrenSanitizer' => 'et_core_esc_previously',
								'children' => get_the_title(),
							]),
						],
					]);
				}

				// Author with dynamic avatar.
				$author_avatar = '';
				if ('on' === $show_author_avatar) {
					$author_avatar = '<span class="dnxte-filterable-cpt-author-avatar">' . get_avatar(get_the_author_meta('ID'), 32, '', get_the_author(), ['class' => 'dnxte-filterable-cpt-avatar-img']) . '</span>';
				}
			$author = sprintf(
				'<span class="dnxte-authovcard"><a href="%3$s" target="%4$s">%1$s %2$s</a></span>',
				$author_avatar,
				get_the_author(),
				esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
				esc_attr( $postTarget )
			);

				// Date with icon.
				$date = sprintf(
					'<span class="dnxte-blog-date">%1$s %2$s</span>',
					$date_icon,
					get_the_date($date_format)
				);

				$top_date = sprintf(
					'<div class="dnxte-blog-post-date">
						<span class="dnxte-month">%1$s</span>
						<span class="dnxte-day">%2$s</span>
						<span class="dnxte-year">%3$s</span>
					</div>',
					get_the_date('M'),
					get_the_date('d'),
					get_the_date('Y')
				);

				$cats = $primary_taxonomy
					? get_the_terms( get_the_ID(), $primary_taxonomy )
					: [];
				if ( is_wp_error( $cats ) || empty( $cats ) ) {
					$cats = [];
				}
				$visible_cats = array_slice( $cats, 0, $category_count );
				$cat_links = array_map( function ( $cat ) use ( $postTarget ) {
					return sprintf(
						'<a href="%s" target="%s">%s</a>',
						esc_url( get_term_link( $cat ) ),
						esc_attr( $postTarget ),
						esc_html( $cat->name )
					);
				}, $visible_cats );
				// Categories render as separate pills in every layout (see the
				// .dnxte-blog-categories pill styles); no comma separators or icon.
				$categories_html = sprintf(
					'<span class="dnxte-blog-categories meta-category">%1$s</span>',
					implode( '', $cat_links )
				);

				// Comment count.
				$comment_count_html = '';
				if ('on' === $show_comment_count) {
					$count = get_comments_number();
					$comment_count_html = sprintf(
						'<span class="dnxte-blog-comment-count">%1$s %2$s</span>',
						$comment_icon,
						get_comments_number_text()
					);
				}

				// Excerpt.
				$excerptContent = '';
				if ('on' === $show_excerpt) {
					if ('off' === $excerpt_content) {
						$raw_text = has_excerpt()
							? wp_strip_all_tags(strip_shortcodes(get_the_excerpt()))
							: wp_strip_all_tags(strip_shortcodes(get_the_content()));

						if ('characters' === $excerpt_length_type) {
							$raw_excerpt = mb_strlen($raw_text) > $excerpt_length
								? mb_substr($raw_text, 0, $excerpt_length) . '...'
								: $raw_text;
						} else {
							$raw_excerpt = wp_trim_words($raw_text, $excerpt_length, '...');
						}
						$excerptContent = HTMLUtility::render([
							'tag' => 'div',
							'attributes' => ['class' => 'dnxte-post-excerpt dnxte-blog-post-content'],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children' => [wp_kses_post($raw_excerpt)],
						]);
					} else {
						if ($content_length > 0) {
							$rendered = apply_filters('the_content', get_the_content());
							$plain = wp_strip_all_tags($rendered);
							$trimmed = wp_trim_words($plain, $content_length, '...');
							$content_html = '<p>' . esc_html($trimmed) . '</p>';
						} else {
							$content_html = get_the_content();
						}

						$excerptContent = HTMLUtility::render([
							'tag' => 'div',
							'attributes' => ['class' => 'dnxte-blog-post-content'],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children' => $content_html,
						]);
					}
				}

				$readmore = sprintf(
					'<div class="dnxte-filterable-cpt-card-read-more dnxt_button_alignment_%2$s">
						<a href="%4$s" class="dnxte-readmore-link %3$s"%5$s>%1$s</a>
					</div>',
					esc_html($reamMoreText),
					$button_alingment,
					$customBtnStyleClassName,
					get_permalink(),
					$button_data_icon_attr
				);

				// Include layout template — sets $carousel_wrap.
				$carousel_wrap = '';
				$layout_file   = LayoutTemplate::locate(DNXTE_FILTERABLE_CPT_LAYOUTS, $layout);

				if ('' !== $layout_file) {
					include $layout_file;
				}

				// Wrap in card div (matches RenderCallbackTrait).
				$output .= HTMLUtility::render([
					'tag' => 'div',
					'attributes' => [
						'class' => 'dnxte-filterable-cpt-card dnxte-filterable-cpt-card--' . $layout,
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => $carousel_wrap,
				]);
			}
		}

		wp_reset_postdata();

		// No matching posts — return the no-results message (mirrors RenderCallbackTrait).
		if ('' === $output) {
			$output = '<div class="dnxte-filterable-cpt-no-results" role="status">' . esc_html($no_results_text) . '</div>';
		}

		wp_send_json_success([
			'html' => $output,
			'max_pages' => $wp_query->max_num_pages,
			'current_page' => $page,
			'found_posts' => $wp_query->found_posts,
		]);
	}
}
