<?php
/**
 * FilterableCpt::module_classnames().
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Text\TextClassnames;

trait ModuleClassnamesTrait {

	/**
	 * Module classnames function for FilterableCpt module.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type object $classnamesInstance Instance of ET\Builder\Packages\Module\Layout\Components\Classnames.
	 *     @type array  $attrs              Block attributes data that being rendered.
	 * }
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$text_options_classnames = TextClassnames::text_options_classnames( $attrs['module']['advanced']['text'] ?? [] );

		if ( $text_options_classnames ) {
			$classnames_instance->add( $text_options_classnames, true );
		}

		// Image hover effect + object-fit — consumed by the CSS in module.scss.
		$hover_effect = $attrs['image']['advanced']['hoverEffect']['desktop']['value'] ?? 'none';
		if ( $hover_effect && 'none' !== $hover_effect ) {
			$classnames_instance->add( 'dnxte-img-hover-' . $hover_effect, true );
		}

		$object_fit = $attrs['image']['advanced']['objectFit']['desktop']['value'] ?? '';
		if ( $object_fit ) {
			$classnames_instance->add( 'dnxte-img-fit-' . $object_fit, true );
		}
	}
}
