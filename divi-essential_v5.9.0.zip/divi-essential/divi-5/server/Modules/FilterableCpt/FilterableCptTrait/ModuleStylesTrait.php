<?php
/**
 * FilterableCpt::module_styles().
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;

trait ModuleStylesTrait {
	use CustomCssTrait;

	/**
	 * Filterable CPT module's style components.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *      @type string         $id                Module ID.
	 *      @type string         $name              Module name.
	 *      @type string         $attrs             Module attributes.
	 *      @type string         $parentAttrs       Parent attrs.
	 *      @type string         $orderClass        Selector class name.
	 *      @type string         $parentOrderClass  Parent selector class name.
	 *      @type string         $wrapperOrderClass Wrapper selector class name.
	 *      @type string         $settings          Custom settings.
	 *      @type string         $state             Attributes state.
	 *      @type string         $mode              Style mode.
	 *      @type ModuleElements $elements          ModuleElements instance.
	 * }
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';

		$title_underline_onhover = $attrs['title']['advanced']['showUnderlineOnHover']['desktop']['value'] ?? '';

		// Conditional styles.
		$conditional_styles = [];

		if ( 'on' === $title_underline_onhover ) {
			$conditional_styles[] = CommonStyle::style(
				[
					'selector' => "$order_class .dnxte-filterable-cpt-card:hover .dnxte-filterable-cpt-card-title",
					'attr'     => $attrs['title']['advanced']['showUnderlineOnHover'] ?? [],
					'property' => 'text-decoration: underline;',
				]
			);
		}

		$base_styles = [
			$elements->style(
				[
					'attrName'   => 'module',
					'styleProps' => [
						'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
						'disabledOn'               => [
							'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
						],
					],
				]
			),
			CssStyle::style(
				[
					'selector'  => $args['orderClass'],
					'attr'      => $attrs['css'] ?? [],
					'cssFields' => self::custom_css(),
				]
			),
			$elements->style(
				[
					'attrName'   => 'imageSettings',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-card-image img",
									'attr'     => $attrs['imageSettings']['advanced']['imageWidth'] ?? [],
									'property' => 'width',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-card-image img",
									'attr'                => $attrs['imageSettings']['advanced']['imageAspectRatio'] ?? [],
									'declarationFunction' => function ( $args_fn ) {
										$val = $args_fn['attrValue'] ?? '';
										if ( empty( $val ) || 'auto' === $val ) {
											return '';
										}
										return "aspect-ratio: {$val}; object-fit: cover;";
									},
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-card-image img",
									'attr'                => $attrs['imageSettings']['advanced']['imageAlignment'] ?? [],
									'declarationFunction' => function ( $args_fn ) {
										$val = $args_fn['attrValue'] ?? '';
										$map = [
											'flex-start' => 'margin-right: auto;',
											'center'     => 'margin-left: auto; margin-right: auto;',
											'flex-end'   => 'margin-left: auto;',
										];
										return $map[ $val ] ?? '';
									},
								],
							],
						],
					],
				]
			),
			$elements->style( [ 'attrName' => 'post' ] ),
			$elements->style( [ 'attrName' => 'title' ] ),
			$elements->style( [ 'attrName' => 'content' ] ),
			$elements->style( [ 'attrName' => 'category' ] ),
			$elements->style( [ 'attrName' => 'image' ] ),
			$elements->style( [ 'attrName' => 'contentWrapper' ] ),
			$elements->style( [ 'attrName' => 'author' ] ),
			$elements->style( [ 'attrName' => 'date' ] ),
			$elements->style( [ 'attrName' => 'button' ] ),
			$elements->style(
				[
					'attrName'   => 'meta',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-card-meta .meta-separator",
									'attr'     => $attrs['meta']['advanced']['separatorColor'] ?? [],
									'property' => 'color',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-card-meta .meta-separator",
									'attr'     => $attrs['meta']['advanced']['separatorSize'] ?? [],
									'property' => 'font-size',
								],
							],
						],
					],
				]
			),
			$elements->style( [ 'attrName' => 'card' ] ),
			$elements->style(
				[
					'attrName'   => 'grid',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-container",
									'attr'                => $attrs['grid']['advanced']['columns'] ?? [],
									'declarationFunction' => function ( $args_fn ) use ( $attrs ) {
										$val = $args_fn['attrValue'] ?? '';
										if ( empty( $val ) ) {
											return '';
										}
										$layout = $attrs['post']['advanced']['postLayout']['desktop']['value'] ?? 'card';
										if ( 'masonry' === $layout ) {
											// CSS columns fallback for VB / no-JS
											return "column-count: {$val};";
										}
										return "grid-template-columns: repeat({$val}, 1fr);";
									},
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-container",
									'attr'     => $attrs['grid']['advanced']['columnGap'] ?? [],
									'property' => 'column-gap',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-container",
									'attr'     => $attrs['grid']['advanced']['rowGap'] ?? [],
									'property' => 'row-gap',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-container--masonry .dnxte-filterable-cpt-card",
									'attr'                => $attrs['grid']['advanced']['rowGap'] ?? [],
									'property'            => 'margin-bottom',
								],
							],
						],
					],
				]
			),
			$elements->style(
				[
					'attrName'   => 'filter',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar-tab--active",
									'attr'     => $attrs['filter']['advanced']['activeBackground'] ?? [],
									'property' => 'background-color',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar-tab--active",
									'attr'     => $attrs['filter']['advanced']['activeColor'] ?? [],
									'property' => 'color',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar-tab:not(.dnxte-filterable-cpt-filter-bar-tab--active)",
									'attr'     => $attrs['filter']['advanced']['inactiveBackground'] ?? [],
									'property' => 'background-color',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar-tab:not(.dnxte-filterable-cpt-filter-bar-tab--active)",
									'attr'     => $attrs['filter']['advanced']['inactiveColor'] ?? [],
									'property' => 'color',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar",
									'attr'     => $attrs['filter']['advanced']['spacing'] ?? [],
									'property' => 'gap',
								],
							],
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-filter-bar",
									'attr'                => $attrs['filter']['advanced']['alignment'] ?? [],
									'declarationFunction' => function ( $args_fn ) {
										$val = $args_fn['attrValue'] ?? '';
										if ( empty( $val ) ) {
											return '';
										}
										$map      = [
											'left'   => 'flex-start',
											'center' => 'center',
											'right'  => 'flex-end',
										];
										$flex_val = $map[ $val ] ?? $val;
										return "justify-content: {$flex_val};";
									},
								],
							],
						],
					],
				]
			),
			$elements->style( [ 'attrName' => 'filterTab' ] ),
			$elements->style( [ 'attrName' => 'filterBar' ] ),
			$elements->style(
				[
					'attrName'   => 'horizontalImage',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-card--horizontal .dnxte-filterable-cpt-card-image",
									'attr'     => $attrs['horizontalImage']['advanced']['width'] ?? [],
									'property' => 'width',
								],
							],
								[
									'componentName' => 'divi/common',
									'props'         => [
										'selector'            => "{$args['orderClass']} .dnxte-filterable-cpt-card--horizontal",
										'attr'                => $attrs['horizontalImage']['advanced']['reverse'] ?? [],
										'declarationFunction' => function ( $args_fn ) {
											return 'on' === ( $args_fn['attrValue'] ?? '' ) ? 'flex-direction: row-reverse;' : '';
										},
									],
								],
						],
					],
				]
			),
			$elements->style(
				[
					'attrName'   => 'paginationStyle',
					'styleProps' => [
						'advancedStyles' => [
							[
								'componentName' => 'divi/common',
								'props'         => [
									'selector' => "{$args['orderClass']} .dnxte-filterable-cpt-pagination",
									'attr'     => $attrs['paginationStyle']['advanced']['alignment'] ?? [],
									'declarationFunction' => function ( $args_fn ) {
										$val = $args_fn['attrValue'] ?? '';
										if ( empty( $val ) ) {
											return '';
										}
										$map = [
											'left'   => 'flex-start',
											'center' => 'center',
											'right'  => 'flex-end',
										];
										$flex_val = $map[ $val ] ?? $val;
										return "justify-content: {$flex_val};";
									},
								],
							],
								[
									'componentName' => 'divi/common',
									'props'         => [
										'selector'  => "{$args['orderClass']} .dnxte-filterable-cpt-pagination-number.active",
										'attr'      => $attrs['paginationStyle']['advanced']['activeBackground'] ?? [],
										'property'  => 'background-color',
										'important' => true,
									],
								],
								[
									'componentName' => 'divi/common',
									'props'         => [
										'selector'  => "{$args['orderClass']} .dnxte-filterable-cpt-pagination-number.active",
										'attr'      => $attrs['paginationStyle']['advanced']['activeColor'] ?? [],
										'property'  => 'color',
										'important' => true,
									],
								],
						],
					],
				]
			),
		];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array_merge( $base_styles, $conditional_styles ),
			]
		);
	}
}
