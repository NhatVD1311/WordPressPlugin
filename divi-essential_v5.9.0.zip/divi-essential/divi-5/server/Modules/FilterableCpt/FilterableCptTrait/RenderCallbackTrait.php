<?php
/**
 * FilterableCpt::render_callback()
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if (!defined('ABSPATH')) {
	die('Direct access forbidden.');
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use DNXTE\Modules\FilterableCpt\FilterableCpt;
use DNXTE\Shared\LayoutTemplate;
use WP_Query;

trait RenderCallbackTrait
{
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Remove inline <style> blocks from post content to prevent global style leakage.
	 *
	 * @param string $html
	 * @return string
	 */
	private static function strip_inline_style_blocks($html)
	{
		if ('' === trim((string) $html)) {
			return $html;
		}

		return preg_replace('/<style\b[^>]*>.*?<\/style>/is', '', $html);
	}

	/**
	 * Render callback for the Filterable CPT module.
	 *
	 * @since ??
	 *
	 * @param array     $attrs    Block attributes that were saved by VB.
	 * @param string    $content  Block content.
	 * @param \WP_Block $block    Parsed block object that being rendered.
	 * @param object    $elements ModuleElements instance.
	 *
	 * @return string HTML rendered output.
	 */
	public static function render_callback($attrs, $content, $block, $elements)
	{
		$parent = BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
		$parent_attrs = $parent->attrs ?? [];

		// Background component.
		$background_component = ElementComponents::component(
			[
				'attrs' => $attrs['module']['decoration'] ?? [],
				'id' => $block->parsed_block['id'],
				'orderIndex' => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			]
		);

		// Post settings.
		$post_type = $attrs['post']['advanced']['type']['desktop']['value'] ?? 'post';
		$posts_per_page = $attrs['post']['advanced']['number']['desktop']['value'] ?? '9';
		$offset = $attrs['post']['advanced']['offset']['desktop']['value'] ?? '';
		$categories = $attrs['post']['advanced']['categories']['desktop']['value'] ?? [];
		$date_format = $attrs['post']['advanced']['dateFormat']['desktop']['value'] ?? '';
		$orderby = $attrs['post']['advanced']['orderby']['desktop']['value'] ?? 'date';
		$shorted_by = $attrs['post']['advanced']['shortedBy']['desktop']['value'] ?? 'DESC';
		$show_excerpt = $attrs['post']['advanced']['excerptContent']['desktop']['value'] ?? '';
		$excerpt_length = $attrs['post']['advanced']['excerptLength']['desktop']['value'] ?? '';
		$excerpt_length_type = $attrs['post']['advanced']['excerptLengthType']['desktop']['value'] ?? 'words';
		$content_length = $attrs['post']['advanced']['contentLength']['desktop']['value'] ?? '0';
		$postTarget = $attrs['post']['advanced']['postTarget']['desktop']['value'] ?? '';

		// Grid settings. The layout picks an included template, so resolve it to a
		// known one here — every downstream use (card class, data-layout echoed
		// back by the AJAX request, template include) then shares that value.
		$grid_layout = LayoutTemplate::resolve_name(DNXTE_FILTERABLE_CPT_LAYOUTS, $attrs['post']['advanced']['postLayout']['desktop']['value'] ?? 'card');
		$columns = $attrs['grid']['advanced']['columns']['desktop']['value'] ?? '3';
		$columns_tablet = $attrs['grid']['advanced']['columns']['tablet']['value'] ?? '2';
		$columns_phone = $attrs['grid']['advanced']['columns']['phone']['value'] ?? '1';
		$column_gap = $attrs['grid']['advanced']['columnGap']['desktop']['value'] ?? '30px';
		$row_gap = $attrs['grid']['advanced']['rowGap']['desktop']['value'] ?? '30px';

		// Filter bar settings.
		$show_filter_bar = $attrs['filterBar']['advanced']['show']['desktop']['value'] ?? 'on';
		$all_label = $attrs['filterBar']['advanced']['allLabel']['desktop']['value'] ?? 'All';

		// Pagination settings.
		$pagination_type = $attrs['pagination']['advanced']['type']['desktop']['value'] ?? 'loadMore';
		$load_more_text = $attrs['pagination']['advanced']['loadMoreText']['desktop']['value'] ?? 'Load More';
		$loading_text = $attrs['pagination']['advanced']['loadingText']['desktop']['value'] ?? 'Loading...';

		// Element toggles.
		$show_title = $attrs['elements']['advanced']['showTitle']['desktop']['value'] ?? 'on';
		$show_excerpt_toggle = $attrs['elements']['advanced']['showExcerpt']['desktop']['value'] ?? 'off';
		$show_comment_count = $attrs['elements']['advanced']['showCommentCount']['desktop']['value'] ?? 'off';
		$no_results_text = $attrs['elements']['advanced']['noResultsText']['desktop']['value'] ?? 'No posts found.';
		$show_date_icon = $attrs['elements']['advanced']['showDateIcon']['desktop']['value'] ?? 'on';
		$show_author_avatar = $attrs['elements']['advanced']['showAuthorAvatar']['desktop']['value'] ?? 'on';
		$category_count     = absint( $attrs['elements']['advanced']['categoryCount']['desktop']['value'] ?? 3 );
		$show_comment_icon = $attrs['elements']['advanced']['showCommentIcon']['desktop']['value'] ?? 'on';

		$show_thumbnail = ModuleUtils::has_value(
			$attrs['elements']['advanced']['showFeaturedImage'] ?? [],
			[
				'valueResolver' => function ($value) {
					return 'on' === $value;
				},
			]
		);

		$dnxte_feaimage_thumb_size = $attrs['elements']['advanced']['featuredImageSize']['desktop']['value'] ?? '';
		$thumb_width = $attrs['elements']['advanced']['thumbnailWidth']['desktop']['value'] ?? '';
		$thumb_height = $attrs['elements']['advanced']['thumbnailHeight']['desktop']['value'] ?? '';
		$date_position = $attrs['elements']['advanced']['datePosition']['desktop']['value'] ?? '';
		$show_date = $attrs['elements']['advanced']['showDate']['desktop']['value'] ?? '';
		$show_author = $attrs['elements']['advanced']['showAuthor']['desktop']['value'] ?? '';
		$show_categories = $attrs['elements']['advanced']['showCategories']['desktop']['value'] ?? '';
		$reamMoreText = $attrs['elements']['advanced']['readMoreText']['desktop']['value'] ?? '';
		$show_readmore = $attrs['elements']['advanced']['showReadMore']['desktop']['value'] ?? '';
		$title_order    = absint( $attrs['elements']['advanced']['titleOrder']['desktop']['value'] ?? 1 );
		$meta_order     = absint( $attrs['elements']['advanced']['metaOrder']['desktop']['value'] ?? 2 );
		$content_order  = absint( $attrs['elements']['advanced']['contentOrder']['desktop']['value'] ?? 3 );
		$readmore_order = absint( $attrs['elements']['advanced']['readMoreOrder']['desktop']['value'] ?? 4 );
		$buttonAttrs = $attrs['button']['decoration']['button']['desktop']['value'] ?? [];
		$customBtnStyleClassName = 'on' === ($buttonAttrs['enable'] ?? 'off') ? 'et_pb_button et_pb_custom_button_icon' : '';
		$button_icon = $buttonAttrs['icon'] ?? [];
		$button_icon_settings = is_array($button_icon) ? ($button_icon['settings'] ?? []) : [];
		$button_data_icon_val = ! empty($button_icon_settings) ? Utils::process_font_icon($button_icon_settings) : '';
		$button_data_icon_attr = ! empty($button_data_icon_val) ? sprintf(' data-icon="%s"', esc_attr($button_data_icon_val)) : '';
		$button_alingment = self::sanitize_alignment( $attrs['button']['advanced']['alignment']['desktop']['value'] ?? '' );
		$meta_alingment = self::sanitize_alignment( $attrs['meta']['advanced']['metaAlignment']['desktop']['value'] ?? '' );
		$meta_separator = $attrs['meta']['advanced']['separator']['desktop']['value'] ?? '|';

		$heading_level = self::sanitize_heading_level( $attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h2' );

		// Build query.
		$query_args = array(
			'posts_per_page' => $posts_per_page,
			'post_status' => array('publish', 'private', 'inherit'),
			'perm' => 'readable',
			'post_type' => $post_type,
			'orderby' => $orderby,
			'order' => $shorted_by,
		);

		// Determine the primary taxonomy for this post type.
		$primary_taxonomy = FilterableCpt::get_primary_taxonomy( $post_type );

		if (!empty($categories)) {
			if (is_array($categories) && in_array('all', $categories)) {
				// "All" selected — no taxonomy filter; query all posts of this post type.
			} else {
				$cat_ids = is_array($categories) ? $categories : explode(',', $categories);
				$cat_ids = array_filter($cat_ids, 'is_numeric');
				if (!empty($cat_ids) && $primary_taxonomy) {
					$query_args['tax_query'] = [
						[
							'taxonomy' => $primary_taxonomy,
							'field'    => 'term_id',
							'terms'    => array_map( 'intval', $cat_ids ),
						],
					];
				}
			}
		}
		// Note: previously this branch added a global `pre_get_posts` closure that set
		// `$query->is_home = true` on the module's secondary WP_Query. Inside a Theme
		// Builder template, Divi re-applies the home/archive template to any inner
		// query flagged as `is_home`, causing infinite recursion and a 504 timeout.
		// The flag is unnecessary because the WP_Query args are already complete.

		if ('' !== $offset && !empty($offset)) {
			$query_args['offset'] = $offset;
		}

		// Process icons (same for all posts, so done before the loop).
		// Process icons — conditionally rendered based on show icon toggles.
		$date_icon = '';
		if ('on' === $show_date_icon) {
			$icon_date_attr = $attrs['icon']['decoration']['icon']['desktop']['value'] ?? null;
			if (empty($icon_date_attr)) {
				$icon_date_attr = ['unicode' => '&#x7d;', 'type' => 'divi', 'weight' => '400'];
			}
			$icon_value = Utils::process_font_icon($icon_date_attr);
			$date_icon = sprintf('<span class="dnxte-blogslider-content-icon">%1$s</span>', $icon_value);
		}


		$comment_icon = '';
		if ('on' === $show_comment_icon) {
			$icon_comment_attr = $attrs['icon_comment']['decoration']['icon']['desktop']['value'] ?? null;
			if (empty($icon_comment_attr)) {
				$icon_comment_attr = ['unicode' => '&#xe065;', 'type' => 'divi', 'weight' => '400'];
			}
			$icon_comment_value = Utils::process_font_icon($icon_comment_attr);
			$comment_icon = sprintf('<span class="dnxte-filterable-cpt-comment-icon">%1$s</span>', $icon_comment_value);
		}

		$wp_query = new WP_Query($query_args);

		$output = '';

		// No results.
		if (!$wp_query->have_posts()) {
			$output = '<div class="dnxte-filterable-cpt-no-results" role="status">' . esc_html($no_results_text) . '</div>';
		} else {
			while ($wp_query->have_posts()) {
				$wp_query->the_post();

				$has_thumbnail = has_post_thumbnail() || 'attachment' === get_post_type();

				$image = '';
				$image_wrapper = '';
				if ($has_thumbnail && $show_thumbnail) {
					if ('custom' === $dnxte_feaimage_thumb_size) {
						if (function_exists('add_theme_support')) {
							add_theme_support('dnxte_custom_image_size');
							set_post_thumbnail_size($thumb_width, $thumb_height, true);
						}
						add_image_size('dnxte_custom_image_size', $thumb_width, $thumb_height);
						$post_thumbnail = get_the_post_thumbnail(get_the_ID(), 'dnxte_custom_image_size', array('class' => 'dnxte-blog-featured-image'));
					} else {
						$post_thumbnail = get_the_post_thumbnail(get_the_ID(), $dnxte_feaimage_thumb_size, array('class' => 'dnxte-blog-featured-image'));
					}

					$image = HTMLUtility::render(
						[
							'tag' => 'div',
							'attributes' => [
								'class' => 'dnxte-post-thumb',
							],
							'children' => [
								HTMLUtility::render(
									[
										'tag' => 'a',
										'attributes' => [
											'href' => get_permalink(),
											'target' => $postTarget,
										],
										'children' => $post_thumbnail,
										'childrenSanitizer' => 'et_core_esc_previously',
									]
								)
							],
							'childrenSanitizer' => 'et_core_esc_previously',
						]
					);

					$image_wrapper = HTMLUtility::render(
						[
							'tag' => 'div',
							'attributes' => [
								'class' => 'blog-wrap',
							],
							'children' => $image,
							'childrenSanitizer' => 'et_core_esc_previously',
						]
					);
				}

				$title = '';
				if ('on' === $show_title) {
					$title = HTMLUtility::render(
						[
							'tag' => 'a',
							'attributes' => [
								'href' => get_permalink(),
								'target' => $postTarget,
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children' => [
								HTMLUtility::render(
									[
										'tag' => $heading_level,
										'attributes' => [
											'class' => 'dnxte-filterable-cpt-card-title',
										],
										'childrenSanitizer' => 'et_core_esc_previously',
										'children' => get_the_title(),
									]
								)
							]
						]
					);
				}

				$rendered_content = null;
				$post_id          = get_the_ID();
				$get_post_content = function () use ( &$rendered_content, $post_id ) {
					if ( null !== $rendered_content ) {
						return $rendered_content;
					}

					// Guard against recursion: applying `the_content` to a post in our
					// loop triggers Divi's Theme Builder engine, which may try to apply
					// the "All Posts" TB body template to that post. If that template
					// (or any other rendered post) contains the Filterable CPT module, the
					// render recurses infinitely → 504. The static flag below ensures
					// only the outermost render runs the_content; nested calls fall
					// back to the raw post_content.
					static $depth = 0;
					$raw = get_post_field( 'post_content', $post_id );
					if ( $depth > 0 ) {
						$rendered_content = self::strip_inline_style_blocks( $raw );
						return $rendered_content;
					}

					$depth++;
					try {
						$rendered = apply_filters( 'the_content', $raw );
					} finally {
						$depth--;
					}
					$rendered_content = self::strip_inline_style_blocks( $rendered );
					return $rendered_content;
				};

				$excerptContent = '';
				if ('on' === $show_excerpt_toggle) {
					if (isset($show_excerpt) && 'off' === $show_excerpt) {
						$raw_text = has_excerpt()
							? wp_strip_all_tags(strip_shortcodes(get_the_excerpt()))
							: wp_strip_all_tags(strip_shortcodes(get_the_content()));
						$len = isset($excerpt_length) && is_numeric($excerpt_length) ? (int) $excerpt_length : 25;

						if ('characters' === $excerpt_length_type) {
							$raw_excerpt = mb_strlen($raw_text) > $len
								? mb_substr($raw_text, 0, $len) . '...'
								: $raw_text;
						} else {
							$raw_excerpt = wp_trim_words($raw_text, $len, '...');
						}

						$excerptContent = HTMLUtility::render([
							'tag' => 'div',
							'attributes' => ['class' => 'dnxte-post-excerpt dnxte-blog-post-content'],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children' => [wp_kses_post($raw_excerpt)],
						]);
					} else {
						if ( isset( $content_length ) && is_numeric( $content_length ) && (int) $content_length > 0 ) {
							// Use the same recursion-guarded renderer as $post_content.
							$rendered = $get_post_content();
							$plain = wp_strip_all_tags( $rendered );
							$trimmed = wp_trim_words( $plain, (int) $content_length, '...' );
							$excerptContent = HTMLUtility::render(
								[
									'tag' => 'div',
									'attributes' => [
										'class' => 'dnxte-blog-post-content',
									],
									'childrenSanitizer' => 'et_core_esc_previously',
									'children' => '<p>' . esc_html( $trimmed ) . '</p>',
								]
							);
						} else {
							$excerptContent = HTMLUtility::render(
								[
									'tag' => 'div',
									'attributes' => [
										'class' => 'dnxte-blog-post-content',
									],
									'childrenSanitizer' => 'et_core_esc_previously',
									'children' => $get_post_content(),
								]
							);
						}
					}
				}

				// Author with dynamic avatar.
				$author_avatar = '';
				if ('on' === $show_author_avatar) {
					$author_avatar = '<span class="dnxte-filterable-cpt-author-avatar">' . get_avatar(get_the_author_meta('ID'), 32, '', get_the_author(), ['class' => 'dnxte-filterable-cpt-avatar-img']) . '</span>';
				}
				$author = sprintf(
					'<span class="dnxte-authovcard"><a href="%3$s" target="%4$s">%1$s %2$s</a></span>',
					$author_avatar,
					get_the_author(),
					esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
					esc_attr( $postTarget )
				);

				$top_date = sprintf(
					'<div class="dnxte-blog-post-date">
						<span class="dnxte-month">%1$s</span>
						<span class="dnxte-day">%2$s</span>
						<span class="dnxte-year">%3$s</span>
					</div>',
					get_the_date('M'),
					get_the_date('d'),
					get_the_date('Y')
				);

				$date = sprintf(
					'<span class="dnxte-blog-date">%2$s %1$s</span>',
					get_the_date($date_format),
					$date_icon
				);

				$cats = $primary_taxonomy
					? get_the_terms( get_the_ID(), $primary_taxonomy )
					: [];
				if ( is_wp_error( $cats ) || empty( $cats ) ) {
					$cats = [];
				}
				$visible_cats = array_slice( $cats, 0, $category_count );
				$cat_links = array_map( function ( $cat ) use ( $postTarget ) {
					return sprintf(
						'<a href="%s" target="%s">%s</a>',
						esc_url( get_term_link( $cat ) ),
						esc_attr( $postTarget ),
						esc_html( $cat->name )
					);
				}, $visible_cats );
				// Categories render as separate pills in every layout (see the
				// .dnxte-blog-categories pill styles); no comma separators or icon.
				$categories_html = sprintf(
					'<span class="dnxte-blog-categories meta-category">%1$s</span>',
					implode( '', $cat_links )
				);

				$comment_count_html = '';
				if ('on' === $show_comment_count) {
					$comment_count_html = sprintf(
						'<span class="dnxte-blog-comment-count">%1$s %2$s</span>',
						$comment_icon,
						get_comments_number_text()
					);
				}

				$readmore = sprintf(
					'<div class="dnxte-filterable-cpt-card-read-more dnxt_button_alignment_%2$s">
						<a href="%4$s" class="dnxte-readmore-link %3$s"%5$s>%1$s</a>
					</div>',
					esc_html($reamMoreText),
					$button_alingment,
					$customBtnStyleClassName,
					get_permalink(),
					$button_data_icon_attr
				);

				$carousel_wrap = '';

				// Use layout file to build card content.
				$layout      = $grid_layout;
				$layout_file = LayoutTemplate::locate(DNXTE_FILTERABLE_CPT_LAYOUTS, $layout);

				if ('' !== $layout_file) {
					include $layout_file;
				}

				// Wrap each post in a card with link.
				$card_class = 'dnxte-filterable-cpt-card dnxte-filterable-cpt-card--' . esc_attr($grid_layout);

				$output .= HTMLUtility::render(
					[
						'tag' => 'div',
						'attributes' => [
							'class' => $card_class,
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children' => $carousel_wrap,
					]
				);
			}
		}

		unset($image_wrapper);
		wp_reset_postdata();

		// Filter bar — uses Included Categories from Post Settings.
		$filter_bar = '';
		$filter_cat_slugs = '';
		if ('on' === $show_filter_bar) {
			$filter_cats = [];

			// Use the already-built query tax_query IDs if specific categories were selected.
			$has_specific_cats = false;
			if ( ! empty( $query_args['tax_query'][0]['terms'] ) && $primary_taxonomy ) {
				$cat_ids = $query_args['tax_query'][0]['terms'];
				$filter_cats = get_terms( [
					'taxonomy'   => $primary_taxonomy,
					'include'    => $cat_ids,
					'hide_empty' => false,
					'orderby'    => 'include',
				] );
				if ( ! is_wp_error( $filter_cats ) && ! empty( $filter_cats ) ) {
					$has_specific_cats = true;
				}
			}

			if ( empty( $filter_cats ) && $primary_taxonomy ) {
				$filter_cats = get_terms( [
					'taxonomy'   => $primary_taxonomy,
					'hide_empty' => true,
				] );
				if ( is_wp_error( $filter_cats ) ) {
					$filter_cats = [];
				}
			}

			// Store slugs so JS "All" tab and pagination can scope to these categories.
			if ( $has_specific_cats && ! empty( $filter_cats ) ) {
				$filter_cat_slugs = implode( ',', wp_list_pluck( $filter_cats, 'slug' ) );
			}

			$filter_tabs = '<button class="dnxte-filterable-cpt-filter-bar-tab dnxte-filterable-cpt-filter-bar-tab--active" role="tab" aria-selected="true" data-category="all">' . esc_html($all_label) . '</button>';
			foreach ($filter_cats as $cat) {
				$filter_tabs .= '<button class="dnxte-filterable-cpt-filter-bar-tab" role="tab" aria-selected="false" data-category="' . esc_attr($cat->slug) . '">' . esc_html($cat->name) . '</button>';
			}

			$filter_bar = HTMLUtility::render(
				[
					'tag' => 'div',
					'attributes' => [
						'class' => 'dnxte-filterable-cpt-filter-bar',
						'role' => 'tablist',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => $filter_tabs,
				]
			);
		}

		// Search box — rendered above the filter bar when enabled. Search is user-driven,
		// so no data attribute is needed for the query; the frontend reads the input directly.
		$search_bar = '';
		$show_search = $attrs['search']['advanced']['show']['desktop']['value'] ?? 'off';
		$search_mode = $attrs['search']['advanced']['searchMode']['desktop']['value'] ?? 'button';
		if ('on' === $show_search) {
			$search_placeholder = $attrs['search']['advanced']['placeholder']['desktop']['value'] ?? esc_attr__('Search posts...', 'dnxte-divi-essential');
			$search_button_text = $attrs['search']['advanced']['buttonText']['desktop']['value'] ?? esc_html__('Search', 'dnxte-divi-essential');
			$search_bar = HTMLUtility::render(
				[
					'tag' => 'form',
					'attributes' => [
						'class' => 'dnxte-filterable-cpt-search',
						'role'  => 'search',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => sprintf(
						'<input type="search" class="dnxte-filterable-cpt-search-input" placeholder="%1$s" aria-label="%1$s" value="" /><button type="submit" class="dnxte-filterable-cpt-search-button">%2$s</button>',
						esc_attr($search_placeholder),
						esc_html($search_button_text)
					),
				]
			);
		}

		// Grid container — no inline style so responsive CSS from ModuleStylesTrait takes effect.
		$container_class = 'dnxte-filterable-cpt-container';
		if ( 'masonry' === $grid_layout ) {
			$container_class .= ' dnxte-filterable-cpt-container--masonry';
		}
		$grid_container = HTMLUtility::render(
			[
				'tag' => 'div',
				'attributes' => [
					'class' => $container_class,
					'role' => 'tabpanel',
					'aria-live' => 'polite',
					'data-columns' => $columns,
					'data-columns-tablet' => $columns_tablet,
					'data-columns-phone' => $columns_phone,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => $output,
			]
		);

		// Pagination.
		$pagination_html = '';
		if ('loadMore' === $pagination_type) {
			$pagination_html = HTMLUtility::render(
				[
					'tag' => 'div',
					'attributes' => ['class' => 'dnxte-filterable-cpt-pagination'],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => '<button class="dnxte-filterable-cpt-pagination-load-more" data-loading-text="' . esc_attr($loading_text) . '">' . esc_html($load_more_text) . '</button>',
				]
			);
		} elseif ('numbered' === $pagination_type) {
			$total_pages = $wp_query->max_num_pages;
			$current_page = 1;
			$mid_size = absint($attrs['pagination']['advanced']['midSize']['desktop']['value'] ?? 2);
			$page_numbers = '';

			for ($i = 1; $i <= $total_pages; $i++) {
				// Show: first page, last page, and pages within mid_size of current
				if ($i === 1 || $i === $total_pages || abs($i - $current_page) <= $mid_size) {
					$active = $current_page === $i ? ' active' : '';
					$page_numbers .= '<span class="dnxte-filterable-cpt-pagination-number' . $active . '" data-page="' . $i . '">' . $i . '</span>';
				} elseif (
					($i === 2 && $current_page - $mid_size > 2) ||
					($i === $total_pages - 1 && $current_page + $mid_size < $total_pages - 1)
				) {
					$page_numbers .= '<span class="dnxte-filterable-cpt-pagination-ellipsis">&hellip;</span>';
				}
			}
			$pagination_html = HTMLUtility::render(
				[
					'tag' => 'div',
					'attributes' => ['class' => 'dnxte-filterable-cpt-pagination'],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => '<div class="dnxte-filterable-cpt-pagination-numbers">' . $page_numbers . '</div>',
				]
			);
		} elseif ('infiniteScroll' === $pagination_type) {
			$pagination_html = HTMLUtility::render(
				[
					'tag' => 'div',
					'attributes' => ['class' => 'dnxte-filterable-cpt-pagination'],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children' => '<div class="dnxte-filterable-cpt-pagination-sentinel"></div>',
				]
			);
		}

		// Main wrapper.
		$filterable_cpt_container = HTMLUtility::render(
			[
				'tag' => 'div',
				'attributes' => [
					'class' => 'dnxte-filterable-cpt-wrapper',
					'data-posts-per-page' => $posts_per_page,
					'data-orderby' => $orderby,
					'data-order' => $shorted_by,
					'data-post-type' => $post_type,
					'data-layout' => $grid_layout,
					'data-pagination-type' => $pagination_type,
					'data-max-pages' => $wp_query->max_num_pages,
					'data-current-page' => '1',
					'data-show-title' => $show_title,
					'data-show-date' => $show_date,
					'data-show-author' => $show_author,
					'data-show-categories' => $show_categories,
					'data-show-excerpt' => $show_excerpt_toggle,
					'data-show-readmore' => $show_readmore,
					'data-readmore-text' => $reamMoreText,
					'data-show-thumbnail' => $show_thumbnail ? 'on' : 'off',
					'data-featured-image-size' => $dnxte_feaimage_thumb_size,
					'data-title-order' => $title_order,
					'data-meta-order' => $meta_order,
					'data-content-order' => $content_order,
					'data-readmore-order' => $readmore_order,
					'data-date-format' => $date_format,
					'data-excerpt-length' => $excerpt_length,
					'data-excerpt-length-type' => $excerpt_length_type,
					'data-content-length' => $content_length,
					'data-post-target' => $postTarget,
					'data-heading-level' => $heading_level,
					'data-show-comment-count' => $show_comment_count,
					'data-date-position' => $date_position,
					'data-excerpt-content' => $show_excerpt,
					'data-meta-alignment' => $meta_alingment,
					'data-meta-separator' => $meta_separator,
					'data-button-alignment' => $button_alingment,
					'data-button-class' => $customBtnStyleClassName,
					'data-button-icon' => $button_data_icon_val,
					'data-mid-size' => $attrs['pagination']['advanced']['midSize']['desktop']['value'] ?? '2',
					'data-show-date-icon' => $show_date_icon,
					'data-show-author-avatar' => $show_author_avatar,
					'data-category-count'     => $category_count,
					'data-filter-cat-slugs'   => $filter_cat_slugs,
					'data-show-comment-icon' => $show_comment_icon,
					'data-icon-date' => $date_icon,
					'data-icon-comment' => $comment_icon,
					'data-show-search' => $show_search,
					'data-search-mode' => $search_mode,
					'data-no-results' => $no_results_text,
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children' => [$search_bar, $filter_bar, $grid_container, $pagination_html],
			]
		);

		return Module::render(
			[
				'orderIndex' => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
				'className' => 'dnxte_filterable_cpt',
				'id' => $block->parsed_block['id'],
				'name' => $block->block_type->name,
				'moduleCategory' => $block->block_type->category,
				'attrs' => $attrs,
				'elements' => $elements,
				'classnamesFunction' => [self::class, 'module_classnames'],
				'stylesComponent' => [self::class, 'module_styles'],
				'scriptDataComponent' => [self::class, 'module_script_data'],
				'parentAttrs' => $parent_attrs,
				'parentId' => $parent->id ?? '',
				'parentName' => $parent->blockName ?? '',
				'children' => $elements->style_components(
					[
						'attrName' => 'module',
					]
				) . $filterable_cpt_container,
			]
		);
	}
}
