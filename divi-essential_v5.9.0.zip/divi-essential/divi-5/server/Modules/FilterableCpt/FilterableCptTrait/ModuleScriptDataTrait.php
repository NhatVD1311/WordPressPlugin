<?php
/**
 * FilterableCpt::module_script_data()
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);

		// Enqueue Isotope + imagesLoaded for masonry layout.
		$layout = $attrs['post']['advanced']['postLayout']['desktop']['value'] ?? 'card';
		if ( 'masonry' === $layout ) {
			wp_enqueue_script( 'dnext_isotope' );
			wp_enqueue_script( 'imagesloaded' );
		}

		// Register the handle here (it is not part of the central Frontend\Assets
		// registry), otherwise the enqueue below is a silent no-op on the front end
		// and the module renders but never becomes interactive.
		wp_register_script(
			'dnext_filterable_cpt',
			DIVI_ESSENTIAL_URL . 'assets/js/filterable-cpt.js',
			array(),
			DIVI_ESSENTIAL_VERSION,
			true
		);

		wp_localize_script( 'dnext_filterable_cpt', 'dnxteFilterableCpt', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'dnxte_filterable_cpt_nonce' ),
		] );

		wp_enqueue_script( 'dnext_filterable_cpt' );
	}
}
