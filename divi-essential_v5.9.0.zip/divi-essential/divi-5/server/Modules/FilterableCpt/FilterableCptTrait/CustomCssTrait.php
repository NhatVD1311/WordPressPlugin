<?php
/**
 * FilterableCpt::custom_css().
 *
 * @package MEE\Modules\FilterableCpt
 * @since ??
 */

namespace DNXTE\Modules\FilterableCpt\FilterableCptTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/filterable-cpt' )->customCssFields;
	}
}
