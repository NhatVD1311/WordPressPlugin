<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ET\Builder\Framework\Utility\HTMLUtility;

// Meta row.
$meta_items = [];
if ( 'on' === $show_author ) {
	$meta_items[] = $author;
}
if ( 'on' === $show_date && 'bottom' === $date_position ) {
	$meta_items[] = $date;
}
if ( 'on' === $show_categories ) {
	$meta_items[] = $categories_html;
}
if ( 'on' === $show_comment_count && ! empty( $comment_count_html ) ) {
	$meta_items[] = $comment_count_html;
}

$meta = HTMLUtility::render(
	[
		'tag'               => 'div',
		'attributes'        => [
			'class' => 'dnxte-filterable-cpt-card-meta dnxte_meta_alignment_' . $meta_alingment,
		],
		'childrenSanitizer' => 'et_core_esc_previously',
		'children'          => ( isset( $meta_separator ) && 'none' !== $meta_separator )
			? implode( '<span class="meta-separator">' . esc_html( $meta_separator ) . '</span>', $meta_items )
			: implode( '', $meta_items ),
	]
);

// Content wrapper — elements ordered by their per-element order value.
$excerpt_html = '';
if ( ! empty( $excerptContent ) ) {
	$excerpt_html = HTMLUtility::render(
		[
			'tag'               => 'div',
			'attributes'        => [
				'class' => 'dnxte-filterable-cpt-card-excerpt',
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => $excerptContent,
		]
	);
}

$content_elements = [];
if ( 'on' === $show_title ) {
	$content_elements[] = [ 'order' => (int) ( $title_order ?? 1 ), 'idx' => 0, 'html' => $title ];
}
$content_elements[] = [ 'order' => (int) ( $meta_order ?? 2 ), 'idx' => 1, 'html' => $meta ];
if ( ! empty( $excerpt_html ) ) {
	$content_elements[] = [ 'order' => (int) ( $content_order ?? 3 ), 'idx' => 2, 'html' => $excerpt_html ];
}
if ( 'on' === $show_readmore ) {
	$content_elements[] = [ 'order' => (int) ( $readmore_order ?? 4 ), 'idx' => 3, 'html' => $readmore ];
}

usort(
	$content_elements,
	function ( $a, $b ) {
		return [ $a['order'], $a['idx'] ] <=> [ $b['order'], $b['idx'] ];
	}
);

$content_children = array_column( $content_elements, 'html' );

$content_wrapper = HTMLUtility::render(
	[
		'tag'               => 'div',
		'attributes'        => [
			'class' => 'dnxte-filterable-cpt-card-content',
		],
		'childrenSanitizer' => 'et_core_esc_previously',
		'children'          => $content_children,
	]
);

// Card wrap.
$card_children = [];
if ( ! empty( $image_wrapper ) ) {
	$card_children[] = HTMLUtility::render(
		[
			'tag'               => 'div',
			'attributes'        => [
				'class' => 'dnxte-filterable-cpt-card-image',
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => $image_wrapper,
		]
	);
}
if ( 'top' === $date_position ) {
	$card_children[] = $top_date;
}
$card_children[] = $content_wrapper;

$carousel_wrap = implode( '', $card_children );
