<?php
/**
 * NextBreadcrumb REST API Trait
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait RestApiTrait {

	/**
	 * Register REST API endpoints for breadcrumb data.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			'dnxte/v1',
			'/breadcrumb/(?P<post_id>\d+)',
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_breadcrumb_data' ],
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => [
					'post_id' => [
						'required'          => true,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param );
						},
						'sanitize_callback' => 'absint',
					],
				],
			]
		);

		register_rest_route(
			'dnxte/v1',
			'/post-types',
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_public_post_types' ],
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			]
		);

		register_rest_route(
			'dnxte/v1',
			'/posts/(?P<post_type>[a-zA-Z0-9_-]+)',
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_posts_by_type' ],
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => [
					'post_type' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					],
				],
			]
		);
	}

	/**
	 * Get breadcrumb data for a specific post.
	 *
	 * @since ??
	 *
	 * @param \WP_REST_Request $request REST request object.
	 *
	 * @return \WP_REST_Response
	 */
	public static function get_breadcrumb_data( $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			return new \WP_REST_Response(
				[
					'error' => 'Post not found',
				],
				404
			);
		}

		$attrs = [
			'content' => [
				'advanced' => [
					'showHome'        => [
						'desktop' => [
							'value' => 'on',
						],
					],
					'homeLabel'       => [
						'desktop' => [
							'value' => 'Home',
						],
					],
					'showCurrentPage' => [
						'desktop' => [
							'value' => 'on',
						],
					],
				],
			],
		];

		// Build breadcrumbs for this specific post (works in REST context).
		$items   = [];
		$items[] = [
			'label'      => 'Home',
			'url'        => home_url( '/' ),
			'is_current' => false,
		];

		$breadcrumbs = self::get_post_breadcrumbs_by_id( $attrs, $items, $post_id );

		return new \WP_REST_Response(
			[
				'success'     => true,
				'breadcrumbs' => $breadcrumbs,
			],
			200
		);
	}

	/**
	 * Get all public post types.
	 *
	 * @since ??
	 *
	 * @return \WP_REST_Response
	 */
	public static function get_public_post_types() {
		$post_types = get_post_types(
			[
				'public' => true,
			],
			'objects'
		);

		$result = [];
		foreach ( $post_types as $post_type ) {
			if ( 'attachment' === $post_type->name ) {
				continue;
			}
			$result[] = [
				'label' => $post_type->labels->singular_name,
				'value' => $post_type->name,
			];
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * Get published posts of a specific post type.
	 *
	 * @since ??
	 *
	 * @param \WP_REST_Request $request REST request object.
	 *
	 * @return \WP_REST_Response
	 */
	public static function get_posts_by_type( $request ) {
		$post_type = $request->get_param( 'post_type' );

		if ( ! post_type_exists( $post_type ) ) {
			return new \WP_REST_Response(
				[
					'error' => 'Invalid post type',
				],
				400
			);
		}

		$posts = get_posts(
			[
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);

		$result = [];
		foreach ( $posts as $post ) {
			$result[] = [
				'label' => $post->post_title,
				'value' => (string) $post->ID,
			];
		}

		return new \WP_REST_Response( $result, 200 );
	}
}
