<?php
/**
 * NextBreadcrumb::module_classnames()
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Text\TextClassnames;

trait ModuleClassnamesTrait {

	/**
	 * Module's classnames.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type object $classnamesInstance Classnames instance.
	 *     @type array  $attrs              Module attributes.
	 * }
	 *
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'] ?? [];

		// Add base class
		$classnames_instance->add( 'dnxte-breadcrumb-module' );

		// Text Options classnames.
		$classnames_instance->add(
			TextClassnames::text_options_classnames( $attrs['module']['advanced']['text'] ?? [] )
		);
	}
}
