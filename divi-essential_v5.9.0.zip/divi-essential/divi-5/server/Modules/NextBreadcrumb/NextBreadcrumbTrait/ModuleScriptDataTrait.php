<?php
/**
 * NextBreadcrumb::module_script_data()
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait ModuleScriptDataTrait {

	/**
	 * Module's script data.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type string $id        Module ID.
	 *     @type array  $attrs     Module attributes.
	 *     @type object $elements  ModuleElements instance.
	 * }
	 *
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Add module script data
		$elements->script_data(
			[
				'attrName' => 'module',
			]
		);
	}
}
