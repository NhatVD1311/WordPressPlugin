<?php
/**
 * NextBreadcrumb::render_callback()
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\NextBreadcrumb\NextBreadcrumb;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {

	/**
	 * Breadcrumb module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 * @param array     $attrs    Block attributes that were saved by VB.
	 * @param string    $content  Block content.
	 * @param \WP_Block $block    Parsed block object that being rendered.
	 * @param object    $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Breadcrumb module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Get settings
		$source            = $attrs['content']['advanced']['source']['desktop']['value'] ?? 'auto';
		$show_home         = $attrs['content']['advanced']['showHome']['desktop']['value'] ?? 'on';
		$home_label        = $attrs['content']['advanced']['homeLabel']['desktop']['value'] ?? 'Home';
		$use_home_icon     = $attrs['content']['advanced']['useHomeIcon']['desktop']['value'] ?? 'off';
		$home_icon         = $attrs['homeIcon']['innerContent']['desktop']['value'] ?? '';
		$icon_position     = $attrs['content']['advanced']['iconPosition']['desktop']['value'] ?? 'before';
		$separator_type    = $attrs['content']['advanced']['separatorType']['desktop']['value'] ?? 'text';
		$separator_text    = $attrs['content']['advanced']['separatorText']['desktop']['value'] ?? '/';
		$separator_icon    = $attrs['content']['advanced']['separatorIcon']['desktop']['value'] ?? '';
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';
		$link_current_page = $attrs['content']['advanced']['linkCurrentPage']['desktop']['value'] ?? 'off';
		$alignment         = $attrs['layout']['advanced']['alignment']['desktop']['value'] ?? 'left';
		$aria_label        = $attrs['accessibility']['advanced']['ariaLabel']['desktop']['value'] ?? 'Breadcrumb';
		$enable_schema     = $attrs['schema']['advanced']['enableSchema']['desktop']['value'] ?? 'on';
		$schema_format     = $attrs['schema']['advanced']['schemaFormat']['desktop']['value'] ?? 'microdata';

		// Visibility settings
		$hide_on_homepage = $attrs['visibility']['advanced']['hideOnHomepage']['desktop']['value'] ?? 'on';
		$hide_on_404      = $attrs['visibility']['advanced']['hideOn404']['desktop']['value'] ?? 'off';
		$hide_on_search   = $attrs['visibility']['advanced']['hideOnSearch']['desktop']['value'] ?? 'off';

		// Check visibility conditions
		if ( 'on' === $hide_on_homepage && is_front_page() ) {
			return '';
		}
		if ( 'on' === $hide_on_404 && is_404() ) {
			return '';
		}
		if ( 'on' === $hide_on_search && is_search() ) {
			return '';
		}

		// Generate breadcrumb items
		$breadcrumb_items = self::generate_breadcrumbs( $attrs );

		if ( empty( $breadcrumb_items ) ) {
			return '';
		}

		// Build separator HTML
		$separator_html = '';
		if ( 'icon' === $separator_type && ! empty( $separator_icon ) ) {
			$separator_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [
						'class'       => 'dnxte-breadcrumb__separator',
						'aria-hidden' => 'true',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => HTMLUtility::render(
						[
							'tag'               => 'span',
							'attributes'        => [
								'class' => 'dnxte-breadcrumb__separator-icon',
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => Utils::process_font_icon( $separator_icon ),
						]
					),
				]
			);
		} else if ( 'text' === $separator_type && ! empty( $separator_text ) ) {
			$separator_html = HTMLUtility::render(
				[
					'tag'               => 'span',
					'attributes'        => [
						'class'       => 'dnxte-breadcrumb__separator',
						'aria-hidden' => 'true',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => HTMLUtility::render(
						[
							'tag'               => 'span',
							'attributes'        => [
								'class' => 'dnxte-breadcrumb__separator-text',
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => esc_html( $separator_text ),
						]
					),
				]
			);
		}

		// Build breadcrumb list items
		$list_items = [];
		$position   = 1;

		foreach ( $breadcrumb_items as $index => $item ) {
			$is_first   = 0 === $index;
			$is_home    = $is_first && 'on' === $show_home;
			$is_current = ! empty( $item['is_current'] );

			// Build item content
			$item_content = '';

			// Home icon handling
			$home_icon_html = '';
			if ( $is_home && 'on' === $use_home_icon && ! empty( $home_icon ) ) {
				$home_icon_html = HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [
							'class' => 'dnxte-breadcrumb__home-icon',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => Utils::process_font_icon( $home_icon ),
					]
				);
			}

			// Build text span
			$text_html = '';
			if ( ! ( $is_home && 'only' === $icon_position ) ) {
				$text_html = HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [
							'class' => 'dnxte-breadcrumb__text dnxte-breadcrumb_current_item',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => 'on' === $enable_schema && 'microdata' === $schema_format
							? HTMLUtility::render(
								[
									'tag'               => 'span',
									'attributes'        => [
										'itemprop' => 'name',
									],
									'childrenSanitizer' => 'et_core_esc_previously',
									'children'          => esc_html( $item['label'] ),
								]
							)
							: esc_html( $item['label'] ),
					]
				);
			}

			// Combine icon and text based on position
			if ( $is_home && 'on' === $use_home_icon ) {
				if ( 'before' === $icon_position ) {
					$item_content = $home_icon_html . $text_html;
				} elseif ( 'after' === $icon_position ) {
					$item_content = $text_html . $home_icon_html;
				} else {
					$item_content = $home_icon_html;
				}
			} else {
				$item_content = $text_html;
			}

			// Build item classes
			$item_classes = [ 'dnxte-breadcrumb__item' ];
			if ( $is_current ) {
				$item_classes[] = 'dnxte-breadcrumb__item--current';
			}

			// Schema attributes
			$item_attrs = [
				'class' => implode( ' ', $item_classes ),
			];

			if ( 'on' === $enable_schema && 'microdata' === $schema_format ) {
				$item_attrs['itemprop']   = 'itemListElement';
				$item_attrs['itemscope']  = '';
				$item_attrs['itemtype']   = 'https://schema.org/ListItem';
			}

			if ( $is_current ) {
				$item_attrs['aria-current'] = 'page';
			}

			// Build link or span for current
			$inner_content = '';
			if ( $is_current && 'off' === $link_current_page ) {
				$inner_content = $item_content;
			} else {
				$link_attrs = [
					'class' => 'dnxte-breadcrumb__link',
					'href'  => esc_url( $item['url'] ),
				];

				if ( 'on' === $enable_schema && 'microdata' === $schema_format ) {
					$link_attrs['itemprop'] = 'item';
				}

				$inner_content = HTMLUtility::render(
					[
						'tag'               => 'a',
						'attributes'        => $link_attrs,
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $item_content,
					]
				);
			}

			if ( $index > 0 && ! empty( $separator_html ) ) {
				$inner_content = $separator_html . $inner_content;
			}

			// Add position meta for schema
			$position_meta = '';
			if ( 'on' === $enable_schema && 'microdata' === $schema_format ) {
				$position_meta = HTMLUtility::render(
					[
						'tag'        => 'meta',
						'attributes' => [
							'itemprop' => 'position',
							'content'  => $position,
						],
					]
				);
			}

			$list_items[] = HTMLUtility::render(
				[
					'tag'               => 'li',
					'attributes'        => $item_attrs,
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $inner_content . $position_meta,
				]
			);

			$position++;
		}

		// Build the ordered list
		$list_attrs = [
			'class' => 'dnxte-breadcrumb__list',
		];

		if ( 'on' === $enable_schema && 'microdata' === $schema_format ) {
			$list_attrs['itemscope'] = '';
			$list_attrs['itemtype']  = 'https://schema.org/BreadcrumbList';
		}

		$breadcrumb_list = HTMLUtility::render(
			[
				'tag'               => 'ol',
				'attributes'        => $list_attrs,
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => implode( '', $list_items ),
			]
		);

		// Build JSON-LD schema if enabled
		$json_ld_script = '';
		if ( 'on' === $enable_schema && 'json-ld' === $schema_format ) {
			$json_ld_items = [];
			$pos           = 1;
			foreach ( $breadcrumb_items as $item ) {
				$json_ld_items[] = [
					'@type'    => 'ListItem',
					'position' => $pos,
					'name'     => $item['label'],
					'item'     => $item['url'],
				];
				$pos++;
			}

			$json_ld = [
				'@context'        => 'https://schema.org',
				'@type'           => 'BreadcrumbList',
				'itemListElement' => $json_ld_items,
			];

			$json_ld_script = HTMLUtility::render(
				[
					'tag'               => 'script',
					'attributes'        => [
						'type' => 'application/ld+json',
					],
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => wp_json_encode( $json_ld, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ),
				]
			);
		}

		// Build nav container
		$nav_content = HTMLUtility::render(
			[
				'tag'               => 'nav',
				'attributes'        => [
					'class'      => 'dnxte-breadcrumb dnxte-breadcrumb--align-' . esc_attr( $alignment ),
					'aria-label' => esc_attr( $aria_label ),
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $breadcrumb_list . $json_ld_script,
			]
		);

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [ NextBreadcrumb::class, 'module_classnames' ],
				'stylesComponent'     => [ NextBreadcrumb::class, 'module_styles' ],
				'scriptDataComponent' => [ NextBreadcrumb::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => [
					ElementComponents::component(
						[
							'attrs'         => $attrs['module']['decoration'] ?? [],
							'id'            => $block->parsed_block['id'],
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						]
					),
					$nav_content,
				],
			]
		);
	}
}
