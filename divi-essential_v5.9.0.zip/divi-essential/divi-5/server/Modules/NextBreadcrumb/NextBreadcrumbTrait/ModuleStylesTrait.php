<?php
/**
 * NextBreadcrumb::module_styles()
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use StyleDeclarationTrait;
	use CustomCssTrait;
	/**
	 * Module's styles.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type string $id                Module ID.
	 *     @type string $name              Module name.
	 *     @type array  $attrs             Module attributes.
	 *     @type object $elements          ModuleElements instance.
	 *     @type array  $settings          Module settings.
	 *     @type string $orderClass        Order class.
	 *     @type string $storeInstance     Store instance.
	 *     @type mixed  $defaultPrintedStyleAttrs  Default printed style attrs.
	 * }
	 *
	 * @return void
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? [];
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? [];
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? [];
		$order_class                 = $args['orderClass'] ?? '';

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module styles
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? [],
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),

					// Home Icon styles
					$elements->style(
						[
							'attrName'   => 'content',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['content']['advanced']['separatorIcon'] ?? null,
											'selector'            => "{$order_class} .dnxte-breadcrumb__separator-icon",
											'declarationFunction' => [ self::class, 'icon_font_declaration' ],
										],
									],								
								],
							],
						]
					),
					$elements->style(
						[
							'attrName'   => 'homeIcon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['homeIcon']['innerContent'] ?? null,
											'selector'            => "{$order_class} .dnxte-breadcrumb__home-icon",
											'declarationFunction' => [ self::class, 'icon_font_declaration' ],
										],
									]									
								],
							],
						]
					),

					// Link styles
					$elements->style(
						[
							'attrName' => 'link',
						]
					),

					// Current Item styles
					$elements->style(
						[
							'attrName' => 'currentItem',
						]
					),

					// Alignment
					CommonStyle::style(
						[
							'selector'  => "{$order_class} .dnxte-breadcrumb",
							'attr'      => $attrs['layout']['advanced']['alignment'] ?? null,
							'property'  => 'justify-content',
							'important' => true,
						]
					),

					// Item Spacing
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__list",
							'attr'     => $attrs['layout']['advanced']['itemSpacing'] ?? null,
							'property' => 'gap',
						]
					),

					// Current Item Color
					CommonStyle::style(
						[
							'selector'  => "{$order_class} .dnxte-breadcrumb__item--current",
							'attr'      => $attrs['currentItem']['advanced']['color'] ?? null,
							'property'  => 'color',
							'important' => true,
						]
					),

					// Separator Color
					CommonStyle::style(
						[
							'selector'  => "{$order_class} .dnxte-breadcrumb__separator",
							'attr'      => $attrs['separator']['advanced']['color'] ?? null,
							'property'  => 'color',
							'important' => true,
						]
					),

					// Separator Spacing - margin-left
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__separator",
							'attr'     => $attrs['separator']['advanced']['spacing'] ?? null,
							'property' => 'margin-left',
						]
					),

					// Separator Spacing - margin-right
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__separator",
							'attr'     => $attrs['separator']['advanced']['spacing'] ?? null,
							'property' => 'margin-right',
						]
					),

					// Separator Icon Size
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__separator-icon",
							'attr'     => $attrs['separatorIcon']['decoration']['size'] ?? null,
							'property' => 'font-size',
						]
					),

					// Home Icon Color
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__home-icon",
							'attr'     => $attrs['homeIcon']['decoration']['color'] ?? null,
							'property' => 'color',
						]
					),

					// Home Icon Size
					CommonStyle::style(
						[
							'selector' => "{$order_class} .dnxte-breadcrumb__home-icon",
							'attr'     => $attrs['homeIcon']['decoration']['size'] ?? null,
							'property' => 'font-size',
						]
					),

					// Custom CSS
					CssStyle::style(
						[
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}
}
