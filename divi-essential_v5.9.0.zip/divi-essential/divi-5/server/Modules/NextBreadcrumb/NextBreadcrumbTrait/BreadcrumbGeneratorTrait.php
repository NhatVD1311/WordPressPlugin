<?php
/**
 * NextBreadcrumb Breadcrumb Generator Trait
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait BreadcrumbGeneratorTrait {

	/**
	 * Generate breadcrumb items based on current page context.
	 *
	 * @since ??
	 *
	 * @param array $attrs Block attributes.
	 *
	 * @return array Array of breadcrumb items.
	 */
	protected static function generate_breadcrumbs( $attrs ) {
		$source            = $attrs['content']['advanced']['source']['desktop']['value'] ?? 'auto';
		$show_home         = $attrs['content']['advanced']['showHome']['desktop']['value'] ?? 'on';
		$home_label        = $attrs['content']['advanced']['homeLabel']['desktop']['value'] ?? 'Home';
		$custom_home_url   = $attrs['content']['advanced']['customHomeUrl']['desktop']['value'] ?? '';
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';

		$items = [];

		// Add home item.
		if ( 'on' === $show_home ) {
			$home_url = ! empty( $custom_home_url ) ? $custom_home_url : home_url( '/' );
			$items[]  = [
				'label'      => $home_label,
				'url'        => $home_url,
				'is_current' => false,
			];
		}

		// Handle custom source — render breadcrumbs for a specific post.
		if ( 'custom' === $source ) {
			$custom_post_id = $attrs['content']['advanced']['customPostId']['desktop']['value'] ?? '';
			if ( ! empty( $custom_post_id ) ) {
				return self::get_post_breadcrumbs_by_id( $attrs, $items, (int) $custom_post_id );
			}
			return $items;
		}

		// Handle WooCommerce source.
		if ( 'woocommerce' === $source && self::is_woocommerce_active() ) {
			return self::get_woocommerce_breadcrumbs( $attrs, $items );
		}

		// Auto source - WordPress hierarchy.
		return self::get_auto_breadcrumbs( $attrs, $items );
	}

	/**
	 * Get automatic breadcrumbs based on WordPress hierarchy.
	 *
	 * @param array $attrs Block attributes.
	 * @param array $items Existing items array.
	 *
	 * @return array
	 */
	protected static function get_auto_breadcrumbs( $attrs, $items ) {
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';

		if ( is_singular() ) {
			$items = self::get_singular_breadcrumbs( $attrs, $items );
		} elseif ( is_archive() ) {
			$items = self::get_archive_breadcrumbs( $attrs, $items );
		} elseif ( is_search() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => sprintf( 'Search: %s', get_search_query() ),
					'url'        => get_search_link(),
					'is_current' => true,
				];
			}
		} elseif ( is_404() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => 'Page Not Found',
					'url'        => '',
					'is_current' => true,
				];
			}
		}

		return $items;
	}

	/**
	 * Get breadcrumbs for singular pages/posts.
	 *
	 * @param array $attrs Block attributes.
	 * @param array $items Existing items array.
	 *
	 * @return array
	 */
	protected static function get_singular_breadcrumbs( $attrs, $items ) {
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';
		$post              = get_queried_object();

		if ( ! $post ) {
			return $items;
		}

		// For pages, show hierarchy.
		if ( is_page() ) {
			$ancestors = get_post_ancestors( $post );
			if ( ! empty( $ancestors ) ) {
				$ancestors = array_reverse( $ancestors );
				foreach ( $ancestors as $ancestor_id ) {
					$items[] = [
						'label'      => get_the_title( $ancestor_id ),
						'url'        => get_permalink( $ancestor_id ),
						'is_current' => false,
					];
				}
			}
		}

		// For posts and custom post types, show taxonomy hierarchy.
		if ( is_single() ) {
			// Get all public taxonomies for this post type.
			$taxonomies = get_object_taxonomies( $post->post_type, 'objects' );

			// Filter to only public taxonomies, exclude post formats.
			$taxonomies = array_filter(
				$taxonomies,
				function ( $taxonomy ) {
					return $taxonomy->public && 'post_format' !== $taxonomy->name;
				}
			);

			// Prioritize hierarchical taxonomies.
			usort(
				$taxonomies,
				function ( $a, $b ) {
					if ( $a->hierarchical === $b->hierarchical ) {
						return 0;
					}
					return $a->hierarchical ? -1 : 1;
				}
			);

			// Get the first taxonomy that has terms assigned to this post.
			$selected_taxonomy = null;
			$selected_terms    = null;

			foreach ( $taxonomies as $taxonomy ) {
				$terms = get_the_terms( $post->ID, $taxonomy->name );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					$selected_taxonomy = $taxonomy;
					$selected_terms    = $terms;
					break;
				}
			}

			// If we found a taxonomy with terms, add them to breadcrumbs.
			if ( $selected_taxonomy && $selected_terms ) {
				// Get the primary term (first one).
				$primary_term = $selected_terms[0];

				// For hierarchical taxonomies, show ancestors.
				if ( $selected_taxonomy->hierarchical ) {
					$term_ancestors = get_ancestors( $primary_term->term_id, $selected_taxonomy->name );
					if ( ! empty( $term_ancestors ) ) {
						$term_ancestors = array_reverse( $term_ancestors );
						foreach ( $term_ancestors as $ancestor_id ) {
							$ancestor_term = get_term( $ancestor_id, $selected_taxonomy->name );
							if ( $ancestor_term && ! is_wp_error( $ancestor_term ) ) {
								$items[] = [
									'label'      => $ancestor_term->name,
									'url'        => get_term_link( $ancestor_term ),
									'is_current' => false,
								];
							}
						}
					}
				}

				// Add the primary term.
				$items[] = [
					'label'      => $primary_term->name,
					'url'        => get_term_link( $primary_term ),
					'is_current' => false,
				];
			} else {
				// Fallback: If no taxonomy terms, show post type archive (for custom post types).
				if ( 'post' !== $post->post_type ) {
					$post_type_obj = get_post_type_object( $post->post_type );
					if ( $post_type_obj && $post_type_obj->has_archive ) {
						$items[] = [
							'label'      => $post_type_obj->labels->name,
							'url'        => get_post_type_archive_link( $post->post_type ),
							'is_current' => false,
						];
					}
				}
			}
		}

		// Add current page.
		if ( 'on' === $show_current_page ) {
			$items[] = [
				'label'      => get_the_title( $post ),
				'url'        => get_permalink( $post ),
				'is_current' => true,
			];
		}

		return $items;
	}

	/**
	 * Get breadcrumbs for archive pages.
	 *
	 * @param array $attrs Block attributes.
	 * @param array $items Existing items array.
	 *
	 * @return array
	 */
	protected static function get_archive_breadcrumbs( $attrs, $items ) {
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';

		if ( is_category() ) {
			$category = get_queried_object();

			// Show category ancestors.
			$cat_ancestors = get_ancestors( $category->term_id, 'category' );
			if ( ! empty( $cat_ancestors ) ) {
				$cat_ancestors = array_reverse( $cat_ancestors );
				foreach ( $cat_ancestors as $cat_id ) {
					$cat     = get_category( $cat_id );
					$items[] = [
						'label'      => $cat->name,
						'url'        => get_category_link( $cat_id ),
						'is_current' => false,
					];
				}
			}

			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => $category->name,
					'url'        => get_category_link( $category->term_id ),
					'is_current' => true,
				];
			}
		} elseif ( is_tag() ) {
			$tag = get_queried_object();
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => sprintf( 'Tag: %s', $tag->name ),
					'url'        => get_tag_link( $tag->term_id ),
					'is_current' => true,
				];
			}
		} elseif ( is_author() ) {
			$author = get_queried_object();
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => sprintf( 'Author: %s', $author->display_name ),
					'url'        => get_author_posts_url( $author->ID ),
					'is_current' => true,
				];
			}
		} elseif ( is_date() ) {
			if ( is_year() ) {
				if ( 'on' === $show_current_page ) {
					$items[] = [
						'label'      => get_the_date( 'Y' ),
						'url'        => get_year_link( get_the_date( 'Y' ) ),
						'is_current' => true,
					];
				}
			} elseif ( is_month() ) {
				$items[] = [
					'label'      => get_the_date( 'Y' ),
					'url'        => get_year_link( get_the_date( 'Y' ) ),
					'is_current' => false,
				];
				if ( 'on' === $show_current_page ) {
					$items[] = [
						'label'      => get_the_date( 'F' ),
						'url'        => get_month_link( get_the_date( 'Y' ), get_the_date( 'm' ) ),
						'is_current' => true,
					];
				}
			} elseif ( is_day() ) {
				$items[] = [
					'label'      => get_the_date( 'Y' ),
					'url'        => get_year_link( get_the_date( 'Y' ) ),
					'is_current' => false,
				];
				$items[] = [
					'label'      => get_the_date( 'F' ),
					'url'        => get_month_link( get_the_date( 'Y' ), get_the_date( 'm' ) ),
					'is_current' => false,
				];
				if ( 'on' === $show_current_page ) {
					$items[] = [
						'label'      => get_the_date( 'j' ),
						'url'        => get_day_link( get_the_date( 'Y' ), get_the_date( 'm' ), get_the_date( 'd' ) ),
						'is_current' => true,
					];
				}
			}
		} elseif ( is_post_type_archive() ) {
			$post_type_obj = get_queried_object();
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => $post_type_obj->label,
					'url'        => get_post_type_archive_link( $post_type_obj->name ),
					'is_current' => true,
				];
			}
		} elseif ( is_tax() ) {
			$term = get_queried_object();

			// Show term ancestors.
			$term_ancestors = get_ancestors( $term->term_id, $term->taxonomy );
			if ( ! empty( $term_ancestors ) ) {
				$term_ancestors = array_reverse( $term_ancestors );
				foreach ( $term_ancestors as $ancestor_id ) {
					$ancestor_term = get_term( $ancestor_id, $term->taxonomy );
					$items[]       = [
						'label'      => $ancestor_term->name,
						'url'        => get_term_link( $ancestor_term ),
						'is_current' => false,
					];
				}
			}

			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => $term->name,
					'url'        => get_term_link( $term ),
					'is_current' => true,
				];
			}
		}

		return $items;
	}

	/**
	 * Get WooCommerce breadcrumbs.
	 *
	 * @param array $attrs Block attributes.
	 * @param array $items Existing items array.
	 *
	 * @return array
	 */
	protected static function get_woocommerce_breadcrumbs( $attrs, $items ) {
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';

		if ( ! function_exists( 'wc_get_page_id' ) ) {
			return $items;
		}

		// Add Shop page.
		$shop_page_id = wc_get_page_id( 'shop' );
		if ( $shop_page_id > 0 && ! is_shop() ) {
			$items[] = [
				'label'      => get_the_title( $shop_page_id ),
				'url'        => get_permalink( $shop_page_id ),
				'is_current' => false,
			];
		}

		if ( is_shop() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => get_the_title( $shop_page_id ),
					'url'        => get_permalink( $shop_page_id ),
					'is_current' => true,
				];
			}
		} elseif ( is_product_category() ) {
			$category = get_queried_object();

			// Category ancestors.
			$cat_ancestors = get_ancestors( $category->term_id, 'product_cat' );
			if ( ! empty( $cat_ancestors ) ) {
				$cat_ancestors = array_reverse( $cat_ancestors );
				foreach ( $cat_ancestors as $cat_id ) {
					$cat     = get_term( $cat_id, 'product_cat' );
					$items[] = [
						'label'      => $cat->name,
						'url'        => get_term_link( $cat ),
						'is_current' => false,
					];
				}
			}

			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => $category->name,
					'url'        => get_term_link( $category ),
					'is_current' => true,
				];
			}
		} elseif ( is_product_tag() ) {
			$tag = get_queried_object();
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => sprintf( 'Tag: %s', $tag->name ),
					'url'        => get_term_link( $tag ),
					'is_current' => true,
				];
			}
		} elseif ( is_product() ) {
			$product = get_queried_object();

			// Get primary product category.
			$terms = get_the_terms( $product->ID, 'product_cat' );
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$main_term = $terms[0];

				// Category ancestors.
				$cat_ancestors = get_ancestors( $main_term->term_id, 'product_cat' );
				if ( ! empty( $cat_ancestors ) ) {
					$cat_ancestors = array_reverse( $cat_ancestors );
					foreach ( $cat_ancestors as $cat_id ) {
						$cat     = get_term( $cat_id, 'product_cat' );
						$items[] = [
							'label'      => $cat->name,
							'url'        => get_term_link( $cat ),
							'is_current' => false,
						];
					}
				}

				$items[] = [
					'label'      => $main_term->name,
					'url'        => get_term_link( $main_term ),
					'is_current' => false,
				];
			}

			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => get_the_title( $product ),
					'url'        => get_permalink( $product ),
					'is_current' => true,
				];
			}
		} elseif ( is_cart() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => get_the_title( wc_get_page_id( 'cart' ) ),
					'url'        => wc_get_cart_url(),
					'is_current' => true,
				];
			}
		} elseif ( is_checkout() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => get_the_title( wc_get_page_id( 'checkout' ) ),
					'url'        => wc_get_checkout_url(),
					'is_current' => true,
				];
			}
		} elseif ( is_account_page() ) {
			if ( 'on' === $show_current_page ) {
				$items[] = [
					'label'      => get_the_title( wc_get_page_id( 'myaccount' ) ),
					'url'        => wc_get_page_permalink( 'myaccount' ),
					'is_current' => true,
				];
			}
		}

		return $items;
	}

	/**
	 * Build breadcrumbs for a specific post by ID.
	 *
	 * Unlike get_auto_breadcrumbs / get_singular_breadcrumbs, this method does
	 * not rely on WordPress query conditionals (is_singular, is_page, etc.)
	 * so it works correctly in REST API context and for the custom source.
	 *
	 * @param array $attrs    Block attributes.
	 * @param array $items    Existing items array (typically contains home).
	 * @param int   $post_id  The post ID to build breadcrumbs for.
	 *
	 * @return array
	 */
	protected static function get_post_breadcrumbs_by_id( $attrs, $items, $post_id ) {
		$show_current_page = $attrs['content']['advanced']['showCurrentPage']['desktop']['value'] ?? 'on';
		$post              = get_post( $post_id );

		if ( ! $post ) {
			return $items;
		}

		// Pages — show parent page hierarchy.
		if ( 'page' === $post->post_type ) {
			$ancestors = get_post_ancestors( $post );
			if ( ! empty( $ancestors ) ) {
				$ancestors = array_reverse( $ancestors );
				foreach ( $ancestors as $ancestor_id ) {
					$items[] = [
						'label'      => get_the_title( $ancestor_id ),
						'url'        => get_permalink( $ancestor_id ),
						'is_current' => false,
					];
				}
			}
		} else {
			// Posts & custom post types — show taxonomy hierarchy.
			$taxonomies = get_object_taxonomies( $post->post_type, 'objects' );

			$taxonomies = array_filter(
				$taxonomies,
				function ( $taxonomy ) {
					return $taxonomy->public && 'post_format' !== $taxonomy->name;
				}
			);

			// Prioritize hierarchical taxonomies.
			usort(
				$taxonomies,
				function ( $a, $b ) {
					if ( $a->hierarchical === $b->hierarchical ) {
						return 0;
					}
					return $a->hierarchical ? -1 : 1;
				}
			);

			$selected_taxonomy = null;
			$selected_terms    = null;

			foreach ( $taxonomies as $taxonomy ) {
				$terms = get_the_terms( $post->ID, $taxonomy->name );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					$selected_taxonomy = $taxonomy;
					$selected_terms    = $terms;
					break;
				}
			}

			if ( $selected_taxonomy && $selected_terms ) {
				$primary_term = $selected_terms[0];

				if ( $selected_taxonomy->hierarchical ) {
					$term_ancestors = get_ancestors( $primary_term->term_id, $selected_taxonomy->name );
					if ( ! empty( $term_ancestors ) ) {
						$term_ancestors = array_reverse( $term_ancestors );
						foreach ( $term_ancestors as $ancestor_id ) {
							$ancestor_term = get_term( $ancestor_id, $selected_taxonomy->name );
							if ( $ancestor_term && ! is_wp_error( $ancestor_term ) ) {
								$items[] = [
									'label'      => $ancestor_term->name,
									'url'        => get_term_link( $ancestor_term ),
									'is_current' => false,
								];
							}
						}
					}
				}

				$items[] = [
					'label'      => $primary_term->name,
					'url'        => get_term_link( $primary_term ),
					'is_current' => false,
				];
			} elseif ( 'post' !== $post->post_type ) {
				// Fallback: show post type archive for custom post types.
				$post_type_obj = get_post_type_object( $post->post_type );
				if ( $post_type_obj && $post_type_obj->has_archive ) {
					$items[] = [
						'label'      => $post_type_obj->labels->name,
						'url'        => get_post_type_archive_link( $post->post_type ),
						'is_current' => false,
					];
				}
			}
		}

		// Add the selected post as current item.
		if ( 'on' === $show_current_page ) {
			$items[] = [
				'label'      => get_the_title( $post ),
				'url'        => get_permalink( $post ),
				'is_current' => true,
			];
		}

		return $items;
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	protected static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}
}
