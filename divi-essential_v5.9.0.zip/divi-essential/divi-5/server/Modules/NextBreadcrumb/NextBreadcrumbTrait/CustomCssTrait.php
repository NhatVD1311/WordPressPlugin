<?php
/**
 * NextBreadcrumb::custom_css()
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb\NextBreadcrumbTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Get custom CSS fields from block type registry.
	 *
	 * @since ??
	 *
	 * @return array Custom CSS fields.
	 */
	public static function custom_css() {
		$block_type_registry = \WP_Block_Type_Registry::get_instance();
		$block_type          = $block_type_registry->get_registered( 'dnxte/breadcrumb' );

		return $block_type->customCssFields ?? [];
	}
}
