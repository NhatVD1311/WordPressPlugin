<?php
/**
 * Module: Breadcrumb Module class.
 *
 * @package DNXTE\Modules\NextBreadcrumb
 * @since ??
 */

namespace DNXTE\Modules\NextBreadcrumb;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `NextBreadcrumb` is consisted of functions used for Breadcrumb Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class NextBreadcrumb implements DependencyInterface {
	use NextBreadcrumbTrait\RenderCallbackTrait;
	use NextBreadcrumbTrait\ModuleClassnamesTrait;
	use NextBreadcrumbTrait\ModuleStylesTrait;
	use NextBreadcrumbTrait\ModuleScriptDataTrait;
	use NextBreadcrumbTrait\CustomCssTrait;
	use NextBreadcrumbTrait\BreadcrumbGeneratorTrait;
	use NextBreadcrumbTrait\RestApiTrait;

	/**
	 * Loads `NextBreadcrumb` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'NextBreadcrumb/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ NextBreadcrumb::class, 'render_callback' ],
					]
				);
			}
		);

		// Register REST API routes.
		add_action( 'rest_api_init', [ NextBreadcrumb::class, 'register_rest_routes' ] );
	}
}
