<?php
/**
 * InlineContentChild::render_callback()
 *
 * @package DNXTE\Modules\InlineContentChild
 * @since ??
 */

namespace DNXTE\Modules\InlineContentChild\InlineContentChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\InlineContentChild\InlineContentChild;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;

	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		$item_type = $attrs['module']['advanced']['type']['desktop']['value'] ?? 'text';

		$inner_content = '';

		switch ( $item_type ) {
			case 'text':
				$text_content = $elements->render(
					[
						'attrName' => 'text',
					]
				);
				$inner_content = HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => [
							'class' => 'dnxte-inline-content-text-wrap',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $text_content,
					]
				);
				break;

			case 'icon':
				$icon_unicode = $attrs['icon']['innerContent']['desktop']['value']['unicode'] ?? '';
				$icon_type    = $attrs['icon']['innerContent']['desktop']['value']['type'] ?? 'divi';
				$icon_weight  = $attrs['icon']['innerContent']['desktop']['value']['weight'] ?? '400';

				if ( $icon_unicode ) {
					$inner_content = HTMLUtility::render(
						[
							'tag'               => 'span',
							'attributes'        => [
								'class' => 'dnxte-inline-content-icon',
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $icon_unicode,
						]
					);
				}
				break;

			case 'image':
				$image_src = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';
				$image_alt = $attrs['image']['innerContent']['desktop']['value']['alt'] ?? '';

				if ( $image_src ) {
					$img = HTMLUtility::render(
						[
							'tag'                  => 'img',
							'attributes'           => [
								'src'   => $image_src,
								'alt'   => $image_alt,
								'class' => 'dnxte-inline-content-img',
							],
							'attributesSanitizers' => [
								'src' => function ( $value ) {
									$protocols = array_merge( wp_allowed_protocols(), [ 'data' ] );
									return esc_url( $value, $protocols );
								},
							],
						]
					);
					$inner_content = HTMLUtility::render(
						[
							'tag'               => 'span',
							'attributes'        => [
								'class' => 'dnxte-inline-content-image',
							],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => $img,
						]
					);
				}
				break;

			case 'button':
				$button_text = $attrs['button']['innerContent']['desktop']['value'] ?? 'Button';
				$button_link = $attrs['button']['advanced']['linkGroup']['desktop']['value'] ?? [];
				$button_url  = is_array( $button_link ) ? ( $button_link['url'] ?? '#' ) : '#';
				$button_tgt  = is_array( $button_link ) && ( $button_link['target'] ?? '' ) === 'on' ? '_blank' : '_self';

				$inner_content = HTMLUtility::render(
					[
						'tag'               => 'span',
						'attributes'        => [
							'class' => 'dnxte-inline-content-button',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => HTMLUtility::render(
							[
								'tag'               => 'a',
								'attributes'        => [
									'href'   => $button_url,
									'target' => $button_tgt,
								],
								'childrenSanitizer' => 'et_core_esc_previously',
								'children'          => esc_html( $button_text ),
							]
						),
					]
				);
				break;

			case 'linebreak':
				$inner_content = HTMLUtility::render(
					[
						'tag'        => 'span',
						'attributes' => [
							'class' => 'dnxte-inline-content-linebreak',
						],
					]
				);
				break;
		}

		return Module::render(
			[
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'moduleCategory'     => $block->block_type->category,
				'attrs'              => $attrs,
				'elements'           => $elements,
				'classnamesFunction' => [ InlineContentChild::class, 'module_classnames' ],
				'stylesComponent'    => [ InlineContentChild::class, 'module_styles' ],
				'parentAttrs'        => $parent_attrs,
				'parentId'           => $parent->id ?? '',
				'parentName'         => $parent->blockName ?? '',
				'children'           => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $inner_content,
			]
		);
	}
}
