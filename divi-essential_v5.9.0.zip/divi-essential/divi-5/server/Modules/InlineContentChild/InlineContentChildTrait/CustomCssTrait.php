<?php
/**
 * InlineContentChild::custom_css()
 *
 * @package DNXTE\Modules\InlineContentChild
 * @since ??
 */

namespace DNXTE\Modules\InlineContentChild\InlineContentChildTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	public static function custom_css() {
		return [
			'text'   => [
				'subName'        => 'text',
				'selectorSuffix' => ' .dnxte-inline-content-text',
				'label'          => esc_html__( 'Text', 'dnxte-divi-essential' ),
			],
			'icon'   => [
				'subName'        => 'icon',
				'selectorSuffix' => ' .dnxte-inline-content-icon',
				'label'          => esc_html__( 'Icon', 'dnxte-divi-essential' ),
			],
			'image'  => [
				'subName'        => 'image',
				'selectorSuffix' => ' .dnxte-inline-content-image img',
				'label'          => esc_html__( 'Image', 'dnxte-divi-essential' ),
			],
			'button' => [
				'subName'        => 'button',
				'selectorSuffix' => ' .dnxte-inline-content-button a',
				'label'          => esc_html__( 'Button', 'dnxte-divi-essential' ),
			],
		];
	}
}
