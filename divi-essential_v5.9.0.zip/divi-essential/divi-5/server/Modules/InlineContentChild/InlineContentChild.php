<?php
/**
 * Module: InlineContentChild class.
 *
 * @package DNXTE\Modules\InlineContentChild
 * @since ??
 */

namespace DNXTE\Modules\InlineContentChild;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class InlineContentChild implements DependencyInterface {
	use InlineContentChildTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'InlineContentChild/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ InlineContentChild::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
