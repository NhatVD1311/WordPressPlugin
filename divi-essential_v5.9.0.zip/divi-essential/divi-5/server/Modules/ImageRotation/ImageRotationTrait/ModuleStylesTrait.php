<?php
/**
 * ImageRotation::module_styles().
 *
 * @package DNXTE\Modules\ImageRotation
 * @since ??
 */

namespace DNXTE\Modules\ImageRotation\ImageRotationTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Module's style components.
	 *
	 * @since ??
	 *
	 * @param array $args Style arguments.
	 */
	public static function module_styles( $args ) {
		$attrs                       = $args['attrs'] ?? array();
		$elements                    = $args['elements'];
		$settings                    = $args['settings'] ?? array();
		$default_printed_style_attrs = $args['defaultPrintedStyleAttrs'] ?? array();
		$order_class                 = $args['orderClass'] ?? '';

		$container     = $order_class . ' .dnxte-image-rotation-container';
		$viewport      = $order_class . ' .image_rotation__viewport';
		$frame         = $order_class . ' .image_rotation__frame';
		$overlay       = $order_class . ' .image_rotation__viewport::after';
		$overlay_hover = $order_class . ' .image_rotation__viewport:hover::after';
		$btn           = $order_class . ' .image_rotation__btn';
		$btn_hover     = $order_class . ' .image_rotation__btn:hover';
		$progress      = $order_class . ' .image_rotation__progress';
		$progress_bar  = $order_class . ' .image_rotation__progress-bar';
		$counter       = $order_class . ' .image_rotation__counter';
		$indicator     = $order_class . ' .image_rotation__indicator';
		$lens          = $order_class . ' .image_rotation__lens';
		$magnify_btn   = $order_class . ' .image_rotation__magnify';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'defaultPrintedStyleAttrs' => $default_printed_style_attrs['module']['decoration'] ?? array(),
								'disabledOn'               => array(
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					// Decoration-group driven styles.
					$elements->style( array( 'attrName' => 'image' ) ),
					$elements->style( array( 'attrName' => 'controls' ) ),
					$elements->style( array( 'attrName' => 'counter' ) ),

					// Container.
					CommonStyle::style(
						array(
							'selector'            => $container,
							'attr'                => $attrs['container']['advanced']['alignment'] ?? array(),
							'declarationFunction' => array( self::class, 'alignment_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => $container,
							'attr'     => $attrs['container']['advanced']['width'] ?? array(),
							'property' => 'width',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $container,
							'attr'     => $attrs['container']['advanced']['maxWidth'] ?? array(),
							'property' => 'max-width',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $viewport,
							'attr'     => $attrs['container']['advanced']['aspectRatio'] ?? array(),
							'property' => 'aspect-ratio',
						)
					),

					// Image.
					CommonStyle::style(
						array(
							'selector' => $frame,
							'attr'     => $attrs['image']['advanced']['objectFit'] ?? array(),
							'property' => 'object-fit',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $overlay,
							'attr'     => $attrs['imageOverlay']['advanced']['overlayColor'] ?? array(),
							'property' => 'background',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $overlay_hover,
							'attr'     => $attrs['imageOverlay']['advanced']['hoverOverlayColor'] ?? array(),
							'property' => 'background',
						)
					),

					// Controls.
					CommonStyle::style(
						array(
							'selector' => $btn,
							'attr'     => $attrs['controls']['advanced']['buttonSize'] ?? array(),
							'property' => 'width',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $btn,
							'attr'     => $attrs['controls']['advanced']['buttonSize'] ?? array(),
							'property' => 'height',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $btn,
							'attr'     => $attrs['controls']['advanced']['iconSize'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $btn,
							'attr'     => $attrs['controls']['advanced']['iconColor'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $btn,
							'attr'     => $attrs['controls']['advanced']['bgColor'] ?? array(),
							'property' => 'background',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $btn_hover,
							'attr'     => $attrs['controls']['advanced']['hoverColor'] ?? array(),
							'property' => 'background',
						)
					),

					// Progress indicator.
					CommonStyle::style(
						array(
							'selector' => $progress,
							'attr'     => $attrs['progress']['advanced']['height'] ?? array(),
							'property' => 'height',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $progress,
							'attr'     => $attrs['progress']['advanced']['baseColor'] ?? array(),
							'property' => 'background',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $progress_bar,
							'attr'     => $attrs['progress']['advanced']['activeColor'] ?? array(),
							'property' => 'background',
						)
					),

					// 360° indicator badge.
					CommonStyle::style(
						array(
							'selector' => $indicator,
							'attr'     => $attrs['indicator']['advanced']['size'] ?? array(),
							'property' => 'width',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $indicator,
							'attr'     => $attrs['indicator']['advanced']['color'] ?? array(),
							'property' => 'color',
						)
					),

					// Magnify lens: size the toggle button (icon scales at the default
					// 18px/40px ratio), keep the zoom circle in sync.
					CommonStyle::style(
						array(
							'selector'            => $magnify_btn,
							'attr'                => $attrs['magnify']['advanced']['buttonSize'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr_value = $params['attrValue'] ?? '';
								$size       = (float) $attr_value;

								if ( ! $size ) {
									return '';
								}

								$unit      = preg_replace( '/^[\d.]+/', '', (string) $attr_value );
								$unit      = '' !== $unit ? $unit : 'px';
								$font_size = round( $size * 0.45 ) . $unit;

								return "width: {$attr_value}; height: {$attr_value}; font-size: {$font_size};";
							},
						)
					),
					CommonStyle::style(
						array(
							'selector' => $magnify_btn,
							'attr'     => $attrs['magnify']['advanced']['buttonColor'] ?? array(),
							'property' => 'background',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $lens,
							'attr'     => $attrs['magnify']['advanced']['lensSize'] ?? array(),
							'property' => 'width',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $lens,
							'attr'     => $attrs['magnify']['advanced']['lensSize'] ?? array(),
							'property' => 'height',
						)
					),

					// Frame counter.
					CommonStyle::style(
						array(
							'selector' => $counter,
							'attr'     => $attrs['counter']['advanced']['textColor'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $counter,
							'attr'     => $attrs['counter']['advanced']['bgColor'] ?? array(),
							'property' => 'background',
						)
					),

					CssStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['css'] ?? array(),
							'cssFields' => self::custom_css(),
						)
					),
				),
			)
		);
	}

	/**
	 * Horizontal placement of the rotation container.
	 *
	 * The container is `flex-direction: column`, so `justify-content` only moves
	 * things vertically — horizontal placement of the (max-width capped) block is
	 * done with auto margins. Both sides must be written explicitly to override
	 * the base `margin: 0 auto`.
	 *
	 * Kept in sync with alignmentDeclaration in visual-builder styles.tsx.
	 *
	 * @since ??
	 *
	 * @param array $args Style declaration arguments.
	 *
	 * @return string CSS declarations.
	 */
	public static function alignment_style_declaration( $args ) {
		$value = $args['attrValue'] ?? '';
		$map   = array(
			'flex-start' => 'margin-left: 0; margin-right: auto;',
			'center'     => 'margin-left: auto; margin-right: auto;',
			'flex-end'   => 'margin-left: auto; margin-right: 0;',
		);

		return $map[ $value ] ?? '';
	}
}
