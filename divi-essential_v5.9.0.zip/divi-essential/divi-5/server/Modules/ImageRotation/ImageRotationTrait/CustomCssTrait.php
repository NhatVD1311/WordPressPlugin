<?php
/**
 * ImageRotation::custom_css().
 *
 * @package DNXTE\Modules\ImageRotation
 * @since ??
 */

namespace DNXTE\Modules\ImageRotation\ImageRotationTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields.
	 *
	 * This function is equivalent of JS const cssFields located in
	 * src/components/ImageRotation/custom-css.ts.
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/image-rotation' )->customCssFields;
	}
}
