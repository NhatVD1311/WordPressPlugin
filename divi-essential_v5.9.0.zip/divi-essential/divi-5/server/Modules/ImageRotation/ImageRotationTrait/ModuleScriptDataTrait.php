<?php
/**
 * ImageRotation::module_script_data()
 *
 * @package DNXTE\Modules\ImageRotation
 * @since ??
 */

namespace DNXTE\Modules\ImageRotation\ImageRotationTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;

trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options and enqueue the frontend script.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		$id             = $args['id'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? array();
		$store_instance = $args['storeInstance'] ?? null;

		$module_decoration_attrs = $attrs['module']['decoration'] ?? array();

		ElementScriptData::set(
			array(
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					array(
						'link' => $args['attrs']['module']['advanced']['link'] ?? array(),
					)
				),
				'storeInstance' => $store_instance,
			)
		);

		// Enqueue the frontend rotation script and styles.
		wp_enqueue_style( 'dnext_image_rotation' );
		wp_enqueue_script( 'dnext_image_rotation' );
	}
}
