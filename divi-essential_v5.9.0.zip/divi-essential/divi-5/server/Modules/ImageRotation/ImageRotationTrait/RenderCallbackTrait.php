<?php
/**
 * ImageRotation::render_callback()
 *
 * @package DNXTE\Modules\ImageRotation
 * @since ??
 */

namespace DNXTE\Modules\ImageRotation\ImageRotationTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param \WP_Block      $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of the module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Frame source.
		$frame_ids = isset( $attrs['frames']['innerContent']['desktop']['value'] ) ? $attrs['frames']['innerContent']['desktop']['value'] : '';

		// Rotation settings.
		$trigger          = isset( $attrs['rotation']['advanced']['trigger']['desktop']['value'] ) ? $attrs['rotation']['advanced']['trigger']['desktop']['value'] : 'drag';
		$autoplay         = isset( $attrs['rotation']['advanced']['autoplay']['desktop']['value'] ) ? $attrs['rotation']['advanced']['autoplay']['desktop']['value'] : 'off';
		$loop             = isset( $attrs['rotation']['advanced']['loop']['desktop']['value'] ) ? $attrs['rotation']['advanced']['loop']['desktop']['value'] : 'on';
		$direction        = isset( $attrs['rotation']['advanced']['direction']['desktop']['value'] ) ? $attrs['rotation']['advanced']['direction']['desktop']['value'] : 'cw';
		$speed            = isset( $attrs['rotation']['advanced']['speed']['desktop']['value'] ) ? $attrs['rotation']['advanced']['speed']['desktop']['value'] : '50';
		$drag_sensitivity = isset( $attrs['rotation']['advanced']['dragSensitivity']['desktop']['value'] ) ? $attrs['rotation']['advanced']['dragSensitivity']['desktop']['value'] : '50';
		$inertia          = isset( $attrs['rotation']['advanced']['inertia']['desktop']['value'] ) ? $attrs['rotation']['advanced']['inertia']['desktop']['value'] : '0.3';
		$frame_snap       = isset( $attrs['rotation']['advanced']['frameSnap']['desktop']['value'] ) ? $attrs['rotation']['advanced']['frameSnap']['desktop']['value'] : 'off';
		$pause_on_hover   = isset( $attrs['rotation']['advanced']['pauseOnHover']['desktop']['value'] ) ? $attrs['rotation']['advanced']['pauseOnHover']['desktop']['value'] : 'on';
		$keyboard_nav     = isset( $attrs['rotation']['advanced']['keyboardNav']['desktop']['value'] ) ? $attrs['rotation']['advanced']['keyboardNav']['desktop']['value'] : 'off';
		$wheel_rotate     = isset( $attrs['rotation']['advanced']['wheelRotate']['desktop']['value'] ) ? $attrs['rotation']['advanced']['wheelRotate']['desktop']['value'] : 'off';

		// 360° indicator badge and magnify lens.
		$show_indicator = isset( $attrs['indicator']['advanced']['showIndicator']['desktop']['value'] ) ? $attrs['indicator']['advanced']['showIndicator']['desktop']['value'] : 'on';
		$indicator_style = isset( $attrs['indicator']['advanced']['style']['desktop']['value'] ) ? $attrs['indicator']['advanced']['style']['desktop']['value'] : 'arrow';
		$enable_magnify = isset( $attrs['magnify']['advanced']['enableMagnify']['desktop']['value'] ) ? $attrs['magnify']['advanced']['enableMagnify']['desktop']['value'] : 'off';
		$zoom_level     = isset( $attrs['magnify']['advanced']['zoomLevel']['desktop']['value'] ) ? $attrs['magnify']['advanced']['zoomLevel']['desktop']['value'] : '2.5';

		// Navigation controls.
		$show_play_pause = isset( $attrs['navigation']['advanced']['showPlayPause']['desktop']['value'] ) ? $attrs['navigation']['advanced']['showPlayPause']['desktop']['value'] : 'on';
		$show_arrows     = isset( $attrs['navigation']['advanced']['showArrows']['desktop']['value'] ) ? $attrs['navigation']['advanced']['showArrows']['desktop']['value'] : 'on';
		$show_progress   = isset( $attrs['navigation']['advanced']['showProgress']['desktop']['value'] ) ? $attrs['navigation']['advanced']['showProgress']['desktop']['value'] : 'on';
		$show_counter    = isset( $attrs['navigation']['advanced']['showCounter']['desktop']['value'] ) ? $attrs['navigation']['advanced']['showCounter']['desktop']['value'] : 'on';

		// Performance.
		$lazy_load      = isset( $attrs['performance']['advanced']['lazyLoad']['desktop']['value'] ) ? $attrs['performance']['advanced']['lazyLoad']['desktop']['value'] : 'on';
		$preload_frames = isset( $attrs['performance']['advanced']['preloadFrames']['desktop']['value'] ) ? intval( $attrs['performance']['advanced']['preloadFrames']['desktop']['value'] ) : 5;

		// Build the frame <img> markup in sequence.
		$frame_ids_array = array_filter( array_map( 'trim', explode( ',', $frame_ids ) ) );

		/**
		 * Image size used for the rotation frames.
		 *
		 * Frames are swapped on every rotation step, so their decode cost sits on
		 * the critical path: a full-size original can take longer to decode than
		 * the gap between two frames, which the viewer sees as a blink. A bounded
		 * size keeps both the download and the decode cheap.
		 *
		 * @param string $size  Registered image size name.
		 * @param array  $attrs Module attributes.
		 */
		$frame_size = apply_filters( 'dnxte_image_rotation_frame_size', 'large', $attrs );

		$frames_markup = '';
		$index         = 0;
		foreach ( $frame_ids_array as $frame_id ) {
			$image_url = wp_get_attachment_image_url( intval( $frame_id ), $frame_size );
			if ( ! $image_url && 'full' !== $frame_size ) {
				// An unregistered or not-yet-generated size: fall back to the original.
				$image_url = wp_get_attachment_image_url( intval( $frame_id ), 'full' );
			}
			if ( ! $image_url ) {
				continue;
			}
			$is_active     = 0 === $index;
			$is_eager      = 'on' !== $lazy_load || $index < $preload_frames;
			$frame_classes = 'image_rotation__frame' . ( $is_active ? ' is-active' : '' );

			$frame_attributes = array(
				'class'     => $frame_classes,
				'data-src'  => $image_url,
				'alt'       => sprintf( 'Frame %d', $index + 1 ),
				'draggable' => 'false',
			);

			// Deferred frames ship with no src at all and are loaded by the JS
			// preloader; an empty src="" would make the browser re-request the
			// page URL, and loading="lazy" would never fire for a hidden frame.
			if ( $is_eager ) {
				$frame_attributes['src']     = $image_url;
				$frame_attributes['loading'] = 'eager';
			}

			$frames_markup .= HTMLUtility::render(
				array(
					'tag'        => 'img',
					'attributes' => $frame_attributes,
				)
			);
			$index++;
		}
		$frame_count = $index;

		// No frames uploaded: show a hint to editors, nothing to visitors.
		if ( 0 === $frame_count && current_user_can( 'edit_posts' ) ) {
			$empty_text = sprintf(
				/* translators: %s: settings path to the frame uploader, wrapped in <strong>. */
				esc_html__( 'Add at least 8 frames in %s to start the rotation.', 'dnxte-divi-essential' ),
				'<strong>' . esc_html__( 'Content → Image Source', 'dnxte-divi-essential' ) . '</strong>'
			);

			$frames_markup = HTMLUtility::render(
				array(
					'tag'               => 'div',
					'attributes'        => array(
						'class' => 'image_rotation__empty',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array(
						'<span class="image_rotation__empty-icon">' . self::get_indicator_svg( 'spin' ) . '</span>',
						'<span class="image_rotation__empty-title">' . esc_html__( '360° Image Rotation', 'dnxte-divi-essential' ) . '</span>',
						'<span class="image_rotation__empty-text">' . $empty_text . '</span>',
						'<span class="image_rotation__empty-note">' . esc_html__( 'Only editors see this notice', 'dnxte-divi-essential' ) . '</span>',
					),
				)
			);
		}

		// Frame counter markup.
		$counter_markup = 'on' === $show_counter && $frame_count > 0 ? HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'image_rotation__counter',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => array(
					sprintf(
						'<span class="image_rotation__counter-current">1</span> / <span class="image_rotation__counter-total">%d</span>',
						$frame_count
					),
				),
			)
		) : '';

		// 360° indicator badge markup.
		$indicator_markup = '';
		if ( 'on' === $show_indicator && $frame_count > 0 ) {
			$indicator_svg = self::get_indicator_svg( $indicator_style );

			$indicator_markup = HTMLUtility::render(
				array(
					'tag'               => 'div',
					'attributes'        => array(
						'class'       => 'image_rotation__indicator',
						'aria-hidden' => 'true',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array( $indicator_svg ),
				)
			);
		}

		// Magnify button and lens markup.
		$magnify_markup = '';
		if ( 'on' === $enable_magnify && $frame_count > 0 ) {
			$magnify_markup = HTMLUtility::render(
				array(
					'tag'               => 'button',
					'attributes'        => array(
						'type'       => 'button',
						'class'      => 'image_rotation__btn image_rotation__magnify',
						'aria-label' => 'Toggle magnify',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array( '&#128269;' ),
				)
			);
			$magnify_markup .= HTMLUtility::render(
				array(
					'tag'        => 'div',
					'attributes' => array(
						'class'       => 'image_rotation__lens',
						'aria-hidden' => 'true',
					),
				)
			);
		}

		// Viewport markup.
		$viewport_markup = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'image_rotation__viewport',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $frames_markup . $indicator_markup . $magnify_markup . $counter_markup,
			)
		);

		// Progress indicator markup.
		$progress_markup = 'on' === $show_progress && $frame_count > 0 ? HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'image_rotation__progress',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => array(
					HTMLUtility::render(
						array(
							'tag'        => 'span',
							'attributes' => array(
								'class' => 'image_rotation__progress-bar',
								'style' => 'width:0%;',
							),
						)
					),
				),
			)
		) : '';

		// Controls markup.
		$controls_children = array();
		if ( 'on' === $show_arrows ) {
			$controls_children[] = HTMLUtility::render(
				array(
					'tag'               => 'button',
					'attributes'        => array(
						'type'       => 'button',
						'class'      => 'image_rotation__btn image_rotation__prev',
						'aria-label' => 'Previous frame',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array( self::get_control_icon_svg( 'prev' ) ),
				)
			);
		}
		if ( 'on' === $show_play_pause ) {
			$controls_children[] = HTMLUtility::render(
				array(
					'tag'               => 'button',
					'attributes'        => array(
						'type'       => 'button',
						'class'      => 'image_rotation__btn image_rotation__playpause',
						'aria-label' => 'Play or pause',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array( self::get_control_icon_svg( 'play' ) ),
				)
			);
		}
		if ( 'on' === $show_arrows ) {
			$controls_children[] = HTMLUtility::render(
				array(
					'tag'               => 'button',
					'attributes'        => array(
						'type'       => 'button',
						'class'      => 'image_rotation__btn image_rotation__next',
						'aria-label' => 'Next frame',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => array( self::get_control_icon_svg( 'next' ) ),
				)
			);
		}

		$controls_markup = ! empty( $controls_children ) && $frame_count > 0 ? HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'image_rotation__controls',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $controls_children,
			)
		) : '';

		// Container markup with the JS configuration data attributes.
		$container = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class'                 => 'dnxte-image-rotation-container',
					'data-trigger'          => $trigger,
					'data-autoplay'         => $autoplay,
					'data-loop'             => $loop,
					'data-direction'        => $direction,
					'data-speed'            => $speed,
					'data-drag-sensitivity' => $drag_sensitivity,
					'data-inertia'          => $inertia,
					'data-frame-snap'       => $frame_snap,
					'data-pause-on-hover'   => $pause_on_hover,
					'data-keyboard-nav'     => $keyboard_nav,
					'data-wheel-rotate'     => $wheel_rotate,
					'data-magnify'          => $enable_magnify,
					'data-zoom-level'       => $zoom_level,
					'data-frame-count'      => $frame_count,
					'data-lazy-load'        => $lazy_load,
					'data-preload-frames'   => $preload_frames,
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $viewport_markup . $progress_markup . $controls_markup,
			)
		);

		// Background component.
		$background_component = ElementComponents::component(
			array(
				'attrs'         => $attrs['module']['decoration'] ?? array(),
				'id'            => $block->parsed_block['id'],
				'orderIndex'    => $block->parsed_block['orderIndex'],
				'storeInstance' => $block->parsed_block['storeInstance'],
			)
		);

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => $background_component . $container,
			)
		);
	}

	/**
	 * Raw SVG markup for a 360° indicator style.
	 *
	 * Kept in sync with the JS equivalent in visual-builder indicator-svg.ts.
	 *
	 * @since ??
	 *
	 * @param string $style Indicator style: arrow (default), spin, drag, text.
	 *
	 * @return string SVG markup.
	 */
	public static function get_indicator_svg( $style ) {
		switch ( $style ) {
			case 'spin':
				return '<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">'
					. '<path d="M38 16 A16 16 0 1 0 40 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
					. '<path d="M39 10 l1.5 8 l-8 -2 z" fill="currentColor"/>'
					. '<text x="24" y="29" text-anchor="middle" font-size="12" font-weight="700" font-family="sans-serif" fill="currentColor">360</text>'
					. '</svg>';

			case 'drag':
				return '<svg viewBox="0 0 96 40" xmlns="http://www.w3.org/2000/svg">'
					. '<path d="M8 20 l8 -6 v4 h6 v4 h-6 v4 z" fill="currentColor"/>'
					. '<path d="M88 20 l-8 -6 v4 h-6 v4 h6 v4 z" fill="currentColor"/>'
					. '<text x="48" y="25" text-anchor="middle" font-size="13" font-weight="700" font-family="sans-serif" fill="currentColor">360&#176;</text>'
					. '</svg>';

			case 'text':
				return '<svg viewBox="0 0 64 40" xmlns="http://www.w3.org/2000/svg">'
					. '<text x="32" y="27" text-anchor="middle" font-size="19" font-weight="700" font-family="sans-serif" fill="currentColor">360&#176;</text>'
					. '</svg>';

			case 'arrow':
			default:
				return '<svg viewBox="0 0 80 48" xmlns="http://www.w3.org/2000/svg">'
					. '<text x="40" y="23" text-anchor="middle" font-size="17" font-weight="700" font-family="sans-serif" fill="currentColor">360&#176;</text>'
					. '<path d="M18 33 Q40 44 60 37" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>'
					. '<path d="M64 36 L58 43 L55 34 Z" fill="currentColor"/>'
					. '</svg>';
		}
	}

	/**
	 * Raw SVG markup for a control button icon.
	 *
	 * Text glyphs (&#8249; &#9658; &#8250;) sit off-centre inside the button because
	 * their side bearings and baseline offsets differ per font, so the icons are
	 * drawn instead on a symmetric 24x24 grid centred on 12,12.
	 *
	 * Kept in sync with the JS equivalent in visual-builder control-icon-svg.ts
	 * and in assets/js/dnxte.imageRotation.js.
	 *
	 * @since ??
	 *
	 * @param string $icon Icon name: prev, next, play, pause.
	 *
	 * @return string SVG markup.
	 */
	public static function get_control_icon_svg( $icon ) {
		$open = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" focusable="false" aria-hidden="true">';

		switch ( $icon ) {
			case 'prev':
				return $open
					. '<path d="M15 6 L9 12 L15 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'
					. '</svg>';

			case 'pause':
				return $open
					. '<rect x="7.5" y="5.5" width="3.4" height="13" rx="0.6" fill="currentColor"/>'
					. '<rect x="13.1" y="5.5" width="3.4" height="13" rx="0.6" fill="currentColor"/>'
					. '</svg>';

			case 'play':
				return $open
					. '<path d="M7 5.5 L17 12 L7 18.5 Z" fill="currentColor"/>'
					. '</svg>';

			case 'next':
			default:
				return $open
					. '<path d="M9 6 L15 12 L9 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'
					. '</svg>';
		}
	}
}
