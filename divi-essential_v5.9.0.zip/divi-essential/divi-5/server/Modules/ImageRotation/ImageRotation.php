<?php
/**
 * Module: Image Rotation (360°) Module class.
 *
 * @package DNXTE\Modules\ImageRotation
 * @since ??
 */

namespace DNXTE\Modules\ImageRotation;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\ImageRotation\ImageRotationTrait;

/**
 * `ImageRotation` registers the 360° Image Rotation module Front-End render callback.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class ImageRotation implements DependencyInterface {
	use ImageRotationTrait\RenderCallbackTrait;

	/**
	 * Loads `ImageRotation` and registers the Front-End render callback.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'ImageRotation/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					array(
						'render_callback' => array( ImageRotation::class, 'render_callback' ),
					)
				);
			}
		);
	}
}
