<?php
/**
 * Next3dCubeSlider::module_styles().
 *
 * @package MEE\Modules\Next3dCubeSlider
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSlider\Next3dCubeSliderTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\Next3dCubeSliderChild\Next3dCubeSliderChild;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;
	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/parent-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		$icon_selector = "{$order_class} .et-pb-icon";

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					// Image.
					$elements->style(
						[
							'attrName' => 'image',
						]
					),
					// Carousel Settings.
					$elements->style(
						[
							'attrName' => 'carouselSettings',
						]
					),
					// Icon.
					// CommonStyle::style(
					// 	[
					// 		'selector'            => $icon_selector,
					// 		'attr'                => $attrs['icon']['innerContent'] ?? [],
					// 		'declarationFunction' => [ Next3dCubeSliderChild::class, 'icon_font_declaration' ],
					// 	]
					// ),
					// Heading
					$elements->style(
						[
							'attrName' => 'heading',
						]
					),
					// Content
					$elements->style(
						[
							'attrName' => 'content',
						]
					),
					$elements->style(
						[
							'attrName' => 'image',
						]
					),
					$elements->style(
						[
							'attrName' => 'navigationSettings',
							'styleProps'=> [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .dnxte_logo_carousel_parent .swiper-button-next::after",
											'attr'     => $attrs['navigationSettings']['advanced']['navigationIconLeft'] ?? [],
											'declarationFunction' => [ self::class, 'icon_style_declaration' ],
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .dnxte_logo_carousel_parent .swiper-button-prev::after::after",
											'attr'     => $attrs['navigationSettings']['advanced']['navigationIconRight'] ?? [],
											'declarationFunction' => [ self::class, 'icon_style_declaration' ],
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
											'attr'     => $attrs['navigationSettings']['advanced']['arrowColor'] ?? [],
											'property' => 'color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
											'attr'     => $attrs['navigationSettings']['advanced']['arrowBgColor'] ?? [],
											'property' => 'background-color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-pagination .swiper-pagination-bullet",
											'attr'     => $attrs['navigationSettings']['advanced']['dotsColor'] ?? [],
											'property' => 'background-color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-pagination .swiper-pagination-bullet-active",
											'attr'     => $attrs['navigationSettings']['advanced']['dotsActiveColor'] ?? [],
											'property' => 'background-color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-pagination-progressbar .swiper-pagination-progressbar-fill",
											'attr'     => $attrs['navigationSettings']['advanced']['progressBarColor'] ?? [],
											'property' => 'background-color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-button-prev:after, {$args['orderClass']} .swiper-button-next:after",
											'attr'     => $attrs['navigationSettings']['advanced']['arrowSize'] ?? [],
											'property' => 'font-size',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
											'attr'     => $attrs['navigationSettings']['advanced']['arrowSize'] ?? [],
											'property' => 'width',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
											'attr'     => $attrs['navigationSettings']['advanced']['arrowSize'] ?? [],
											'property' => 'height',
										],
									]
								]
							]
						]
					),
				],
			]
		);
		
	}

}