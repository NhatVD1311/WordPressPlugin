<?php
/**
 * Next3dCubeSlider::custom_css().
 *
 * @package MEE\Modules\Next3dCubeSlider
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSlider\Next3dCubeSliderTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {

	/**
	 * Custom CSS fields
	 *
	 * This function is equivalent of JS const cssFields located in
	 * src/components/parent-module/custom-css.ts.
	 *
	 * A minor difference with the JS const cssFields, this function did not have `label` property on each array item.
	 *
	 * @since ??
	 */
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/dnxte-3dcubeslider-parent' )->customCssFields;
	}

}
