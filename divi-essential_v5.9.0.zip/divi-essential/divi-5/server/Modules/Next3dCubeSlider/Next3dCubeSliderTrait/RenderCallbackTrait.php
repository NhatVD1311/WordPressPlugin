<?php
/**
 * Next3dCubeSliderChild::render_callback()
 *
 * @package MEE\Modules\Next3dCubeSliderChild
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSlider\Next3dCubeSliderTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\Next3dCubeSlider\Next3dCubeSlider;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	/**
	 * Parent module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Parent module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

			
		// Carousel Settings
		$auto_play = $attrs['carouselSettings']['advanced']['autoplay']['desktop']['value'] ?? '';
		$delay = $attrs['carouselSettings']['advanced']['delay']['desktop']['value'] ?? '';
		$speed = $attrs['carouselSettings']['advanced']['speed']['desktop']['value'] ?? '';
		$loop = $attrs['carouselSettings']['advanced']['loop']['desktop']['value'] ?? '';
		
		$pause_on_hover = $attrs['carouselSettings']['advanced']['pauseOnHover']['desktop']['value'] ?? '';

		//Navigation Settings
		$grab = $attrs['navigationSettings']['advanced']['useGrabCursor']['desktop']['value'] ?? '';
		$use_arrow_navigation = $attrs['navigationSettings']['advanced']['useArrowNavigation']['desktop']['value'] ?? '';
		$pagination_type = $attrs['navigationSettings']['advanced']['paginationType']['desktop']['value'] ?? '';
		$dynamic_bullets = $attrs['navigationSettings']['advanced']['dynamicBullets']['desktop']['value'] ?? '';
		$keyboard_navigation = $attrs['navigationSettings']['advanced']['keyboardNavigation']['desktop']['value'] ?? '';
		$mouse_wheel_navigation = $attrs['navigationSettings']['advanced']['mousewheelNavigation']['desktop']['value'] ?? '';
		$arrow_position = $attrs['navigationSettings']['advanced']['arrowPosition']['desktop']['value'] ?? 'default';
		$slide_shadow = $attrs['effectSettings']['advanced']['slideShadows']['desktop']['value'] ?? '';
		$shadows = $attrs['effectSettings']['advanced']['shadows']['desktop']['value'] ?? '';
		$shadowoffset = $attrs['effectSettings']['advanced']['shadowOffset']['desktop']['value'] ?? '';
		$shadowscale = $attrs['effectSettings']['advanced']['shadowScale']['desktop']['value'] ?? '';
		
		$pagination = '<div class="swiper-pagination mt-10"></div>';
		
		$navigation = 'on' === $use_arrow_navigation ? "<div class='swiper-button-container dnexte_cubeslider_arrows_{$arrow_position}'><div class='swiper-button-prev'></div><div class='swiper-button-next'></div></div>" : '';
		$wrapper_markup  = HTMLUtility::render(
			[
				'tag'		=> 'div',
				'attributes' 	=> [
					'class' => 'swiper-wrapper',
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'	=> $content 
				
			]
		);

		$swiper_active = HTMLUtility::render(
			[
				'tag'		=> 'div',
				'attributes' 	=> [
					'class' => 'swiper-container dnxte-3dcubeslider-active',
					'data-autoplay' => $auto_play,
					'data-delay'=> $delay,
					'data-speed'=> $speed,
					'data-grab'=> $grab,
					'data-loop'=> $loop,
					'data-pauseonhover'=> $pause_on_hover,
					'data-usearrownavigation'=> $use_arrow_navigation,
					'data-paginationtype'=> $pagination_type,
					'data-dynamicbullets'=> $dynamic_bullets,
					'data-keyboard'=> $keyboard_navigation,
					'data-mouse'=> $mouse_wheel_navigation,
					'data-slideshadows'=> $slide_shadow,
					'data-shadow'=> $shadows,
					'data-shadowoffset'=> $shadowoffset,
					'data-shadowscale'=> $shadowscale,

				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'	=> $wrapper_markup . $navigation . $pagination,
				
			]
		);




		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ Next3dCubeSlider::class, 'module_classnames' ],
				'scriptDataComponent' => [ Next3dCubeSlider::class, 'module_script_data' ],
				'stylesComponent'     => [ Next3dCubeSlider::class, 'module_styles' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $swiper_active,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
