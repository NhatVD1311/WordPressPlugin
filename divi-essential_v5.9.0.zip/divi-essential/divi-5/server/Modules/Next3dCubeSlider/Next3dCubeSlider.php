<?php
/**
 * Module: Parent Module class.
 *
 * @package MEE\Modules\Next3dCubeSlider
 * @since ??
 */

namespace DNXTE\Modules\Next3dCubeSlider;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `Next3dCubeSlider` is consisted of functions used for Parent Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class Next3dCubeSlider implements DependencyInterface {
	use Next3dCubeSliderTrait\RenderCallbackTrait;

	/**
	 * Loads `Next3dCubeSlider` and registers Front-End render callback and REST API Endpoints.
	 *
	 * @since ??
	 *
	 * @return void
	 */
	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'Next3dCubeSlider/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ Next3dCubeSlider::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
