<?php
/**
 * InteractiveCircleChild::render_callback()
 *
 * @package MEE\Modules\InteractiveCircleChild
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircle\InteractiveCircleTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\InteractiveCircle\InteractiveCircle;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;
	/**
	 * Parent module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs Block attributes that were saved by VB.
	 * @param string         $content          Block content.
	 * @param \WP_Block      $block            Parsed block object that being rendered.
	 * @param ModuleElements $elements         ModuleElements instance.
	 *
	 * @return string HTML rendered of Parent module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : [];

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

			// all orbit settings 

		$layout = $attrs['orbitSettings']['advanced']['layout']['desktop']['value'] ?? '';
		$autoplay = $attrs['orbitSettings']['advanced']['autoplay']['desktop']['value'] ?? '';
		$delay  = $attrs['orbitSettings']['advanced']['delay']['desktop']['value'] ?? 2500;
		$animationType = $attrs['orbitSettings']['advanced']['animationType']['desktop']['value'] ?? '';
		$usePagination = $attrs['orbitSettings']['advanced']['usePagination']['desktop']['value'] ?? '';
		$useArrowNavigation = $attrs['orbitSettings']['advanced']['useArrowNavigation']['desktop']['value'] ?? '';
		$loop = $attrs['orbitSettings']['advanced']['loop']['desktop']['value'] ?? '';
		$pauseOnHover = $attrs['orbitSettings']['advanced']['desktop']['value'] ?? '';
		$orbitSize = $attrs['orbitSize']['innerContent']['desktop']['value'] ?? '';
		$thumbSize = $attrs['thumbSize']['innerContent']['desktop']['value'] ?? '';
		$mode = $attrs['orbitSettings']['advanced']['mode']['desktop']['value'] ?? '';
		$opacity = $attrs['orbitSettings']['advanced']['inactiveThumbOpacity']['desktop']['value'] ?? '';
		$tooltip = $attrs['orbitSettings']['advanced']['tooltip']['desktop']['value'] ?? '';
		

		// arrow icon 
		$arrow_prevIcon = $attrs['arrowPrev']['innerContent']['desktop']['value'] ?? '';
		$arrow_nextIcon = $attrs['arrowNext']['innerContent']['desktop']['value'] ?? '';
	$unique_id =  $block->parsed_block['id'];
	// need to remove form $unique_id dnxte/ this part 
	$unique_id = str_replace('dnxte/', '', $unique_id);
		
			$halfvalue = floatval($orbitSize) / 2;
			$attributes = [
			'class' => 'orbit-container orbit_slider_active',
			'data-mode' => $mode,
			'data-radius' => $halfvalue,
			'data-thumb-size' => $thumbSize,
			'data-animation' => $animationType,
			'data-layout' => $layout,
			'data-loop' => $loop,
			'data-pause-on-hover' => $pauseOnHover,
			'data-inactive-thumb-opacity' => $opacity,
			'data-effect' => "fade",
			'data-use-pagination' => $usePagination,
			'data-use-arrow-navigation' => $useArrowNavigation,
			'data-orbit-id' => $unique_id,
			'data-tooltip' => $tooltip,
			 
			];


			

			// Only add autoplay attribute if enabled
			if ($autoplay === 'on') {
			$attributes['data-autoplay'] =  "on";
			$attributes['data-delay'] = $delay;
			}
		$parent_attrs = $parent->attrs ?? [];
			$orbit_pagination  = $usePagination === 'on' ? HTMLUtility::render(
				[
						'tag'               => 'div',
						'attributes'        => [
								'class'                => 'orbit-pagination orbit-pagination-' . $unique_id,
						],
						'childrenSanitizer' => 'et_core_esc_previously',

				]
			) : '';
			$prev_button_content = $useArrowNavigation === 'on' ? HTMLUtility::render(
				[
					'tag' => 'button',
					'attributes' => [
						'class' => 'orbit-button-prev orbit-button-prev-' . $unique_id,
					],
					'childrenSanitizer' => 'esc_html',
					'children' => Utils::process_font_icon($arrow_prevIcon),
				]
			) : '';
			$next_button_content = $useArrowNavigation === 'on' ? HTMLUtility::render(
				[
					'tag' => 'button',
					'attributes' => [
						'class' => 'orbit-button-next orbit-button-next-' . $unique_id,
					],
					'childrenSanitizer' => 'esc_html',
					'children' => Utils::process_font_icon($arrow_nextIcon),
				]
			) : '';
			$orbit_navigation = ($useArrowNavigation === 'on' || $usePagination === 'on') ? HTMLUtility::render(
				[
						'tag'               => 'div',
						'attributes'        => [
								'class'                => 'orbit-navigation',
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          =>  $prev_button_content .$orbit_pagination. $next_button_content,

				]
			) : '';
			$orbit_wrapper = HTMLUtility::render(
						[
								'tag'               => 'div',
								'attributes'        => [
										'class'                => 'orbit-wrapper',
								],
								'childrenSanitizer' => 'et_core_esc_previously',
								'children'          => $content,

						]
				);
			$orbit_container = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => $attributes,
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $orbit_wrapper ,

            ]
        ).  $orbit_navigation;

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'attrs'               => $attrs,
				'elements'            => $elements,
				'classnamesFunction'  => [ InteractiveCircle::class, 'module_classnames' ],
				'scriptDataComponent' => [ InteractiveCircle::class, 'module_script_data' ],
				'stylesComponent'     => [ InteractiveCircle::class, 'module_styles' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => ElementComponents::component(
					[
						'attrs'         => $attrs['module']['decoration'] ?? [],
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					]
				) . $orbit_container,
				'childrenIds'         => $children_ids,
			]
		);
	}
}
