<?php
/**
 * Module Library: Parent Module - Script Data
 *
 * @package Builder\Packages\InteractiveCircle
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircle\InteractiveCircleTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Element\ElementScriptData;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;
trait ModuleScriptDataTrait {

	/**
	 * Set script data of used module options.
	 *
	 * @since ??
	 *
	 * @param array $args {
	 *   Array of arguments.
	 *
	 *   @type string $id       Module id.
	 *   @type string $selector Module selector.
	 *   @type array  $attrs    Module attributes.
	 * }
	 */
	public static function module_script_data( $args ) {
		// Assign variables.
		$id             = $args['id'] ?? '';
		$name           = $args['name'] ?? '';
		$selector       = $args['selector'] ?? '';
		$attrs          = $args['attrs'] ?? [];
		$store_instance = $args['storeInstance'] ?? null;

		// Module decoration attributes.
		$module_decoration_attrs = $attrs['module']['decoration'] ?? [];

		// Element Script Data Options.
		ElementScriptData::set(
			[
				'id'            => $id,
				'selector'      => $selector,
				'attrs'         => array_merge(
					$module_decoration_attrs,
					[
						'link' => $args['attrs']['module']['advanced']['link'] ?? [],
					]
				),
				'storeInstance' => $store_instance,
			]
		);
				MultiViewScriptData::set(
			[
				'id'            => $id,
				'name'          => $name,
				'hoverSelector' => $selector,
				'setAttrs'    => [
					[
						'selector'      => $selector . ' .orbit-container',
						'data'          => array(
							'data-radius' => $attrs['orbitSize']['innerContent']  ?? [],
							
						),
						'valueResolver' => function( $value ) {
							 $value = preg_replace('/[^\d.]/', '', $value);
							
							    $value = (float) $value / 2;
							return (string) $value ?? '';
						},
					],
					[
						'selector'      => $selector . ' .orbit-container',
						'data'          => array(
							'data-thumb-size' => $attrs['thumbSize']['innerContent']  ?? [],
							
						),
						'valueResolver' => function( $value ) {
							 $value = preg_replace('/[^\d.]/', '', $value);
							return $value ?? '';
						},
					],
					// [
					// 	'selector'      => $selector . ' .example_static_module__content',
					// 	'data'          => $attrs['content']['innerContent'] ?? [],
					// 	'valueResolver' => function( $value ) {
					// 		return $value ?? '';
					// 	},
					// 	'sanitizer'     => 'et_core_esc_previously',
					// ],
				],
			]
		);
		wp_enqueue_script( 'dnext_orbit_carousel' );
		wp_enqueue_script( 'dnext_active_orbit' );
	}
}
