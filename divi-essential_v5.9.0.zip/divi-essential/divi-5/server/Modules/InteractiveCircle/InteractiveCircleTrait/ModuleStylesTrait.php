<?php
/**
 * InteractiveCircle::module_styles().
 *
 * @package MEE\Modules\InteractiveCircle
 * @since ??
 */

namespace DNXTE\Modules\InteractiveCircle\InteractiveCircleTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DNXTE\Modules\InteractiveCircleChild\InteractiveCircleChild;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/parent-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since ??
	 */
	public static function icon_style_declaration( array $params ): string {
        $icon_attr = $params['attrValue'] ?? [];

        $style_declarations = new StyleDeclarations(
            [
                'returnType' => 'string',
                'important'  => [
                    'font-family' => true,
                    'font-weight' => true,
                ],
            ]
        );

        if ( isset( $icon_attr['type'] ) ) {
            $font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
            $style_declarations->add( 'font-family', $font_family );
        }

        if ( ! empty( $icon_attr['weight'] ) ) {
            $style_declarations->add( 'font-weight', $icon_attr['weight'] );
        }

        if ( ! empty( $icon_attr['unicode'] ) ) {
            $unicode = Utils::process_font_icon( $icon_attr );
            $unicode = trim( (string) $unicode );
            // Strip accidental trailing quotes/semicolons
            $unicode = preg_replace( '/[;\'"]+$/', '', $unicode );

            // Normalize formats: &#xE090;, E090, \E090 -> \E090
            if ( preg_match( '/^&#x([0-9a-fA-F]{1,6});?$/', $unicode, $m ) ) {
                $unicode = $m[1];
            }
            if ( preg_match( '/^[0-9a-fA-F]{1,6}$/', $unicode ) ) {
                $unicode = '\\' . $unicode;
            }

            $is_valid = (bool) preg_match( '/^\\\[0-9a-fA-F]{1,6}$/', $unicode );

            if ( $is_valid ) {
                $style_declarations->add( 'content', '"' . $unicode . '"' );
            }
        }

        return $style_declarations->value();
    }
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$parent_attrs = $args['parentAttrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
							],
						]
					),

					// Title.
					$elements->style(
						[
							'attrName' => 'title',
						]
					),
		$elements->style(
						[
							'attrName' => 'orbit_thumb_title',
						]
					),
					$elements->style(
						[
							'attrName' => 'content_button',
						]
					),
					// Content.
					$elements->style(
						[
							'attrName' => 'content',
						]
					),
					$elements->style(
									[
										'attrName'   => 'orbitSize',
										'styleProps' => [
											'advancedStyles' => [
												
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['orbitSize']['innerContent'] ?? [],
														'property' => 'width',
													]
												],
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['orbitSize']['innerContent'] ?? [],
														'property' => 'height',
													]
												],
											]
										]
									]
								),
							$elements->style(
									[
										'attrName'   => 'orbitGap',
										'styleProps' => [
											'advancedStyles' => [
												
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['orbitGap']['innerContent'] ?? [],
														'property' => 'padding',
													]
												],
												
											]
										]
									]
								),
					// Icon.
					$elements->style(
						[
							'attrName'   => 'icon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['icon']['innerContent'] ?? [],
											'declarationFunction' => [self::class, 'icon_style_declaration'],
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['color'] ?? [],
											'property' => 'color',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['size'] ?? [],
											'property' => 'font-size',
										]
									],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'innercircleDesign',
						]
					),
					$elements->style(
						[
							'attrName' => 'orbitRing',
						]
					),
					
$elements->style(
						[
							'attrName' => 'contentIconWrapper',
							'styleProps' => [
											'advancedStyles' => [
												
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['size'] ?? [],
														'property' => 'width',
													]
												],
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['size'] ?? [],
														'property' => 'height',
													]
												],
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['iconSize'] ?? [],
														'property' => 'font-size',
													]
												],
													[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['contentIconWrapper']['advanced']['iconColor'] ?? [],
														'property' => 'color',
													]
												],
											]
										]
						]
					),
					$elements->style(
						[
							'attrName'   => 'arrowPrev',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['arrowPrev']['innerContent'] ?? [],
											'declarationFunction' => [self::class, 'icon_style_declaration'],
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['arrowPrev']['advanced']['color'] ?? [],
											'property' => 'color',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['arrowPrev']['advanced']['size'] ?? [],
											'property' => 'font-size',
										]
									],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName'   => 'arrowNext',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['arrowNext']['innerContent'] ?? [],
											'declarationFunction' => [self::class, 'icon_style_declaration'],
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['arrowPrev']['advanced']['color'] ?? [],
											'property' => 'color',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['arrowPrev']['advanced']['size'] ?? [],
											'property' => 'font-size',
										]
									],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'navigationWrapper',
							'styleProps' => [
											'advancedStyles' => [
												
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['navigationWrapper']['advanced']['size'] ?? [],
														'property' => 'width',
													]
												],
												[
													'componentName' => 'divi/common',
													'props'         => [
														'attr'     => $attrs['navigationWrapper']['advanced']['size'] ?? [],
														'property' => 'height',
													]
												],
											]
										]
						]
					),
					$elements->style(
						[
							'attrName' => 'paginationdot',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['paginationdot']['advanced']['size'] ?? [],
											'property' => 'width',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['paginationdot']['advanced']['size'] ?? [],
											'property' => 'height',
										]
									],
								]
							]
						]
					),
					$elements->style(
						[
							'attrName' => 'paginationActiveDot',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['paginationActiveDot']['advanced']['size'] ?? [],
											'property' => 'width',
										]
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['paginationActiveDot']['advanced']['size'] ?? [],
											'property' => 'height',
										]
									],
								]
							]
						]
					),
$elements->style(
						[
							'attrName' => 'singleThumb',
							'styleProps' => [],
						]
					),
					$elements->style(
						[
							'attrName' => 'activeThumb',
							'styleProps' => [
								'advancedStyles' => [
					
									[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $args['orderClass'] . ' .orbit-thumb.orbit-thumb-active .orbit-thumb-icon',
											'attr'     => $attrs['activeThumb']['advanced']['size'] ?? [],
											'property' => 'font-size',
											'important' => true,
										]
									],
												[
										'componentName' => 'divi/common',
										'props'         => [
											'selector' => $args['orderClass'] . ' .orbit-thumb.orbit-thumb-active .orbit-thumb-icon',
											'attr'     => $attrs['activeThumb']['advanced']['color'] ?? [],
											'property' => 'color',
											'important' => true,
										]
									],
								]
							]
						]
					),
$elements->style(
						[
							'attrName' => 'tooltipStyle',
							'styleProps' => [],
						]
					),
					/*
					 * We need to add CssStyle at the very bottom of other
					 * components so that custom css can override module styles
					 * till we find a more elegant solution.
					 */
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),

					// ATTENTION: The code is intentionally added and commented in FE only as an example of expected value format.
					// If you have custom style processing, the style output should be passed as an `array` of style declarations
					// to the `styles` property of the `Style::add` method. For example:
					// [
					// 	[
					// 		'atRules'     => false,
					// 		'selector'    => $icon_selector,
					// 		'declaration' => 'color: red;'
					// 	],
					// 	[
					// 		'atRules'     => '@media only screen and (max-width: 767px)',
					// 		'selector'    => $icon_selector,
					// 		'declaration' => 'color: green;'
					// 	],
					// ],

					// The code below is an example of how to use the `CssStyle::style` method to generate CSS style.
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => self::custom_css(),
						]
					),
				],
			]
		);
	}

}