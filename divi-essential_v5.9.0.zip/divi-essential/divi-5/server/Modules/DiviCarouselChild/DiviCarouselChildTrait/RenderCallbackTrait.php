<?php
/**
 * DiviCarouselChild::render_callback()
 *
 * @package MEE\Modules\DiviCarouselChild
 * @since ??
 */

namespace DNXTE\Modules\DiviCarouselChild\DiviCarouselChildTrait;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

// phpcs:disable ET.Sniffs.ValidVariableName.UsedPropertyNotSnakeCase -- WP use snakeCase in \WP_Block_Parser_Block

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DNXTE\Modules\Base\Traits\CommonTrait;
use DNXTE\Modules\DiviCarouselChild\DiviCarouselChild;

trait RenderCallbackTrait {
    use ModuleClassnamesTrait;
    use ModuleStylesTrait;
    use CommonTrait;

    /**
     * Child module render callback which outputs server side rendered HTML on the Front-End.
     *
     * @since ??
     *
     * @param array          $attrs Block attributes that were saved by VB.
     * @param string         $content          Block content.
     * @param WP_Block       $block            Parsed block object that being rendered.
     * @param ModuleElements $elements         ModuleElements instance.
     *
     * @return string HTML rendered of Child module.
     */
    public static function render_callback( $attrs, $content, $block, $elements ) {
        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        $parent_attrs = $parent->attrs ?? [];
        $self = new self();
        $parent_default_attributes = ModuleRegistration::get_default_attrs( 'dnxte/logo-carousel-parent' );
        $parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );

        $image_src = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';
        $image_alt = $attrs['image']['innerContent']['desktop']['value']['alt'] ?? '';
        $layout =  $attrs['module']['advanced']['layout']['desktop']['value'] ?? "" ;
        $link =  $attrs['link']['innerContent']['desktop']['value'] ?? "" ;
        $button_href =  $attrs['link']['advanced']['linkGroup']['desktop']['value'] ?? "" ;

        $use_light_box = $parent_attrs['lightbox_settings']['advanced']['use_lightbox']['desktop']['value'] ?? "" ;
        // each link 

        $module_each_image_link = $attrs['module']['advanced']['link']['desktop']['value']['url'] ?? "";
        $module_each_image_link_target = $attrs['module']['advanced']['link']['desktop']['value']['target'] ?? "";

        $link_prevent_default_class = $module_each_image_link === "" && $use_light_box === 'off' ? 'link_prevent_default dnxte-coverflow-image-link' : 'dnxte-coverflow-image-link';
        //var_dump( $module_each_image_link, "ami layout" );
        $overlay_color = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'dnxte-coverflow-overlay-color',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',

            ]
        );
        $overlay_color_hover = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'dnxte-coverflow-overlay-color-hover',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',

            ]
        );
        $carousel_image = $image_src !== '' ? HTMLUtility::render(
            [
                'tag'                  => 'img',
                'attributes'           => [
                    'src'   => $image_src,
                    'alt'   => $image_alt,
                    'class' => 'img-fluid',

                ],
                'attributesSanitizers' => [
                    'src' => function ( $value ) {
                        $protocols = array_merge( wp_allowed_protocols(), ['data'] ); // Need to add `data` protocol for default image.
                        return esc_url( $value, $protocols );
                    },
                ],
            ]
        ) : '';
        $carousel_content_text = ( $layout !== 'text' ) ? HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'dnxte-coverflow-image-container',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => HTMLUtility::render(
                    [
                        'tag'               => 'a',

                        'attributes'        => [
                            'class' => empty($module_each_image_link) && $use_light_box === 'on' ? 'dnxte-coverflow-image-link' : $link_prevent_default_class,
                            'data-link' => $module_each_image_link,
                            'href'  => !empty( $image_src ) && $use_light_box === 'on' && $module_each_image_link === "" ? $image_src : $module_each_image_link,
                            'target'=> $module_each_image_link_target === 'on' ? '_blank' : '_self',
                        ],
                        'childrenSanitizer' => 'et_core_esc_previously',
                        'children'          => $overlay_color . $overlay_color_hover . $carousel_image,
                    ]
                ),
            ]
        ) : '';

        $title = $elements->render(
            [
                'attrName'      => 'title',
                'hoverSelector' => '{{parentSelector}}',
            ]
        );
        $content = $elements->render(
            [
                'attrName'      => 'content',
                'hoverSelector' => '{{parentSelector}}',
            ]
        );
        $button_content = ( $link !== '' ) ? HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'dnxte-coverflow-button-wrapper',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => HTMLUtility::render(
                    [
                        'tag'               => 'a',
                        'attributes'        => [
                            'class'  => 'dnxte-coverflow-button',
                            'href'   => $button_href['url'] ?? '',
                            'target' => $button_href['target'] ?? '',
                        ],
                        'childrenSanitizer' => 'et_core_esc_previously',
                        'children'          => $link,

                    ]
                ),
            ]
        ) : '';
        $carousel_content_image = ( $layout !== 'image' ) ? HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => "dnxte-coverflow-multitext " . ( $layout === 'inside-image' ? 'dnxte-coverflow-inside-image' : '' ),
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          =>$title . $content . $button_content,
            ]
        ) : '';

        $main_content_wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'et_pb_module_inner dnxte-coverflowslider-item ' . ( in_array( $layout, ['left-image', 'right-image'] ) ? 'dnxte-coverflow-carousel-' . $layout : '' ),

                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $carousel_content_text . $carousel_content_image,
            ]
        );
        $content_container = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'swiper-slide dnxte_coverflowslider_child',
                ],
                'childrenSanitizer' => 'et_core_esc_previously',
                'children'          => $main_content_wrapper,
            ]
        );

        return Module::render(
            [
                // FE only.
                'orderIndex'         => $block->parsed_block['orderIndex'],
                'storeInstance'      => $block->parsed_block['storeInstance'],
                'classNames'         => 'swiper-slide',
                // VB equivalent.
                'id'                 => $block->parsed_block['id'],
                'name'               => $block->block_type->name,
                'moduleCategory'     => $block->block_type->category,
                'attrs'              => $attrs,
                'elements'           => $elements,
                'classnamesFunction' => [DiviCarouselChild::class, 'module_classnames'],
                'stylesComponent'    => [DiviCarouselChild::class, 'module_styles'],
                'parentAttrs'        => $parent_attrs,
                'parentId'           => $parent->id ?? '',
                'parentName'         => $parent->blockName ?? '',
                'children'           => ElementComponents::component(
                    [
                        'attrs'         => $attrs['module']['decoration'] ?? [],
                        'id'            => $block->parsed_block['id'],

                        // FE only.
                        'orderIndex'    => $block->parsed_block['orderIndex'],
                        'storeInstance' => $block->parsed_block['storeInstance'],
                    ]
                ) . $main_content_wrapper,
            ]
        );
    }
}
