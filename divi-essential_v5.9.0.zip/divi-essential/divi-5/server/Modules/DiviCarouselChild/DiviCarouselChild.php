<?php
/**
 * Module: Child Module class.
 *
 * @package MEE\Modules\DiviCarouselChild
 * @since ??
 */

namespace DNXTE\Modules\DiviCarouselChild;

if ( !defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * `DiviCarouselChild` is consisted of functions used for Child Module such as Front-End rendering, REST API Endpoints etc.
 *
 * This is a dependency class and can be used as a dependency for `DependencyTree`.
 *
 * @since ??
 */
class DiviCarouselChild implements DependencyInterface {
    use DiviCarouselChildTrait\RenderCallbackTrait;

    /**
     * Loads `DiviCarouselChild` and registers Front-End render callback and REST API Endpoints.
     *
     * @since ??
     *
     * @return void
     */
    public function load() {
        $module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'DiviCarouselChild/';

        add_action(
            'init',
            function () use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [DiviCarouselChild::class, 'render_callback'],
                    ]
                );
            }
        );
    }
}
