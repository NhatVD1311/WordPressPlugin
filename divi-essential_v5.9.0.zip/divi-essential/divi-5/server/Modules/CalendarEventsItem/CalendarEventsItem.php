<?php
/**
 * Module: CalendarEventsItem class.
 *
 * @package DNXTE\Modules\CalendarEventsItem
 * @since ??
 */

namespace DNXTE\Modules\CalendarEventsItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class CalendarEventsItem implements DependencyInterface {
	use CalendarEventsItemTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'CalendarEventsItem/';

		add_action(
			'init',
			function () use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ CalendarEventsItem::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
