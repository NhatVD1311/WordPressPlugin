<?php
/**
 * Module: CalendarEventsItem - Custom CSS Trait.
 *
 * @package DNXTE\Modules\CalendarEventsItem
 * @since ??
 */

namespace DNXTE\Modules\CalendarEventsItem\CalendarEventsItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	/**
	 * Get custom CSS fields for the CalendarEventsItem module.
	 *
	 * @return array
	 */
	public static function custom_css() {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/calendar-events-item' );
		return $block_type ? ( $block_type->customCssFields ?? array() ) : array();
	}
}
