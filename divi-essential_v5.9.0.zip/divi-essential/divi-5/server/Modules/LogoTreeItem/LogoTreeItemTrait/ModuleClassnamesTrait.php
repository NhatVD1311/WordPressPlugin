<?php
namespace DNXTE\Modules\LogoTreeItem\LogoTreeItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait ModuleClassnamesTrait {
	public static function module_classnames( $args ) {
		// No dynamic classnames
	}
}
