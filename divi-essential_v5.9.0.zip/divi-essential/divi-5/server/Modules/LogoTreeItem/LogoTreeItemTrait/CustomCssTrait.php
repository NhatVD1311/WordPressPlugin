<?php
namespace DNXTE\Modules\LogoTreeItem\LogoTreeItemTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	public static function custom_css() {
		return [];
	}
}
