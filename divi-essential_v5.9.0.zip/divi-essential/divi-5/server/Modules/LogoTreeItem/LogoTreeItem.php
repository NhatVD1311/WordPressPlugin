<?php
namespace DNXTE\Modules\LogoTreeItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DNXTE\Modules\LogoTreeItem\LogoTreeItemTrait;

class LogoTreeItem implements DependencyInterface {
	use LogoTreeItemTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'LogoTreeItem/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ LogoTreeItem::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
