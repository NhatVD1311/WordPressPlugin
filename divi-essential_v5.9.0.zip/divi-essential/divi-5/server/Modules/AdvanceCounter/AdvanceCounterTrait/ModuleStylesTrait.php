<?php
namespace DNXTE\Modules\AdvanceCounter\AdvanceCounterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DNXTE\Modules\AdvanceCounter\AdvanceCounter;

trait ModuleStylesTrait {
	use CustomCssTrait;

	/**
	 * Generate icon font-family declaration.
	 *
	 * @param array $params Style declaration params.
	 * @return string CSS declaration string.
	 */
	public static function icon_font_declaration( $params ) {
		$icon_attr = $params['attrValue'] ?? [];

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'font-family' => true,
					'content'     => true,
				],
			]
		);

		if ( ! empty( $icon_attr ) ) {
			if ( ! empty( $icon_attr['type'] ) ) {
				$font_family = 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
				$style_declarations->add( 'font-family', $font_family );
			}

			if ( ! empty( $icon_attr['weight'] ) ) {
				$style_declarations->add( 'font-weight', $icon_attr['weight'] );
			}

			$style_declarations->add( 'content', '"' . Utils::process_font_icon( $icon_attr ) . '"' );
		}

		return $style_declarations->value();
	}

	public static function module_styles( $args ) {
		$attrs    = $args['attrs'] ?? [];
		$elements = $args['elements'];
		$settings = $args['settings'] ?? [];

		Style::add(
			[
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => [
					// Module.
					$elements->style(
						[
							'attrName'   => 'module',
							'styleProps' => [
								'disabledOn' => [
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								],
								'advancedStyles' => [
									[
										'componentName' => 'divi/text',
										'props'         => [
											'selector' => "{$args['orderClass']} .advance_counter__inner",
											'attr'     => $attrs['module']['advanced']['text'] ?? [],
										],
									],
								],
							],
						]
					),

					// Title.
					$elements->style( [ 'attrName' => 'title' ] ),

					// Counter Number.
					$elements->style( [ 'attrName' => 'counterNumber' ] ),

					// Description.
					$elements->style( [ 'attrName' => 'description' ] ),

					// Icon (font-family, color, size).
					$elements->style(
						[
							'attrName'   => 'icon',
							'styleProps' => [
								'advancedStyles' => [
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'                => $attrs['icon']['innerContent'] ?? [],
											'declarationFunction' => [ AdvanceCounter::class, 'icon_font_declaration' ],
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['color'] ?? [],
											'property' => 'color',
										],
									],
									[
										'componentName' => 'divi/common',
										'props'         => [
											'attr'     => $attrs['icon']['advanced']['size'] ?? [],
											'property' => 'font-size',
										],
									],
								],
							],
						]
					),

					// Custom CSS.
					CssStyle::style(
						[
							'selector'  => $args['orderClass'],
							'attr'      => $attrs['css'] ?? [],
							'cssFields' => AdvanceCounter::custom_css(),
						]
					),
				],
			]
		);
	}
}
