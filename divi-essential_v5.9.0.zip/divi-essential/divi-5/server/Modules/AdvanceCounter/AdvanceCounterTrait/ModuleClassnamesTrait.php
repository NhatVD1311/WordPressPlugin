<?php
namespace DNXTE\Modules\AdvanceCounter\AdvanceCounterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Options\Text\TextClassnames;

trait ModuleClassnamesTrait {
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$text_options_classnames = TextClassnames::text_options_classnames( $attrs['module']['advanced']['text'] ?? [] );

		if ( $text_options_classnames ) {
			$classnames_instance->add( $text_options_classnames, true );
		}

		// Layout class.
		$layout = $attrs['layout']['innerContent']['desktop']['value'] ?? 'layout1';
		$classnames_instance->add( 'advance_counter--' . sanitize_html_class( $layout ) );

		// Icon class.
		$use_icon = $attrs['useIcon']['innerContent']['desktop']['value'] ?? 'off';
		if ( 'on' === $use_icon ) {
			$classnames_instance->add( 'advance_counter--has-icon' );
		}
	}
}
