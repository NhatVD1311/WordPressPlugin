<?php
/**
 * AdvanceCounter::render_callback()
 *
 * @package DNXTE\Modules\AdvanceCounter
 * @since ??
 */

namespace DNXTE\Modules\AdvanceCounter\AdvanceCounterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DNXTE\Modules\AdvanceCounter\AdvanceCounter;

trait RenderCallbackTrait {
	use ModuleClassnamesTrait;
	use ModuleStylesTrait;
	use ModuleScriptDataTrait;

	/**
	 * Static module render callback which outputs server side rendered HTML on the Front-End.
	 *
	 * @since ??
	 *
	 * @param array          $attrs    Block attributes that were saved by VB.
	 * @param string         $content  Block content.
	 * @param WP_Block       $block    Parsed block object that being rendered.
	 * @param ModuleElements $elements ModuleElements instance.
	 *
	 * @return string HTML rendered of Static module.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Extract attributes.
		$use_icon = $attrs['useIcon']['innerContent']['desktop']['value'] ?? 'off';

		// Icon section.
		$icon_html = '';

		if ( 'on' === $use_icon ) {
			$icon_value = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
			if ( ! empty( $icon_value ) ) {
				$icon_content = HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => [ 'class' => 'advance_counter__icon et-pb-icon' ],
						'childrenSanitizer' => 'esc_html',
						'children'          => Utils::process_font_icon( $icon_value ),
					]
				);

				$icon_html = HTMLUtility::render(
					[
						'tag'               => 'div',
						'attributes'        => [ 'class' => 'advance_counter__icon-wrap' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $icon_content,
					]
				);
			}
		}

		// Title.
		$title = $elements->render( [ 'attrName' => 'title' ] );

		// Counter number.
		$counter_number = $elements->render( [ 'attrName' => 'counterNumber' ] );

		// Animation settings (single grouped attribute).
		$anim    = $attrs['counterAnimation']['innerContent']['desktop']['value'] ?? [];
		$enabled = $anim['enabled'] ?? 'on';
		$duration = $anim['duration'] ?? '2000';
		$delay    = $anim['delay'] ?? '0';
		$easing   = $anim['easing'] ?? 'easeOut';
		$trigger  = $anim['trigger'] ?? 'viewport';
		$repeat   = $anim['repeat'] ?? 'on';

		$counter_wrap = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [
					'class'                   => 'advance_counter__counter-wrap',
					'data-enable-animation'   => esc_attr( $enabled ),
					'data-duration'           => absint( $duration ) ?: 2000,
					'data-delay'              => absint( $delay ),
					'data-easing'             => esc_attr( $easing ),
					'data-trigger'            => esc_attr( $trigger ),
					'data-repeat'             => esc_attr( $repeat ),
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $counter_number,
			]
		);

		// Description.
		$description = $elements->render( [ 'attrName' => 'description' ] );

		// Content wrapper (groups title, counter, description).
		$content = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'advance_counter__content' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $title . $counter_wrap . $description,
			]
		);

		// Inner wrapper.
		$inner = HTMLUtility::render(
			[
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'advance_counter__inner' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_html . $content,
			]
		);

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? [];

		return Module::render(
			[
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => [ AdvanceCounter::class, 'module_classnames' ],
				'stylesComponent'     => [ AdvanceCounter::class, 'module_styles' ],
				'scriptDataComponent' => [ AdvanceCounter::class, 'module_script_data' ],
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => $parent->blockName ?? '',
				'children'            => [
					ElementComponents::component(
						[
							'attrs'         => $attrs['module']['decoration'] ?? [],
							'id'            => $block->parsed_block['id'],
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						]
					),
					$inner,
				],
			]
		);
	}
}
