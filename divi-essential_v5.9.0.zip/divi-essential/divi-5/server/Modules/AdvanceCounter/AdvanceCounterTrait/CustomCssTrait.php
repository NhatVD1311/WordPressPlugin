<?php
namespace DNXTE\Modules\AdvanceCounter\AdvanceCounterTrait;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dnxte/advance-counter' )->customCssFields;
	}
}
