<?php
namespace DNXTE\Modules\AdvanceCounter;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

class AdvanceCounter implements DependencyInterface {
	use AdvanceCounterTrait\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = DIVI_ESSENTIAL_MODULES_JSON_PATH . 'AdvanceCounter/';

		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[
						'render_callback' => [ AdvanceCounter::class, 'render_callback' ],
					]
				);
			}
		);
	}
}
