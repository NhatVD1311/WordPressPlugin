<?php
/**
 * Divi 5 Module Integration
 *
 * @package DNXTE
 * @since 5.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Require php files.
// Autoloader is already loaded in main plugin file
require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/ValueExpansion.php';
require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Modules/Modules.php';

// Register the Vertical Menu icon picker for Appearance > Menus.
// Must run here — not in load() — because load() only fires inside the Divi builder context.
// We include the trait file directly to avoid autoloading NextVerticalMenu (which implements
// a Divi ET interface that isn't available this early in the boot sequence).
$dnxte_inactive_modules = get_option( 'dnxte_inactive_modules', array() );
if ( ! in_array( 'dnxte-vertical-menu', (array) $dnxte_inactive_modules, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Modules/NextVerticalMenu/NextVerticalMenuTrait/IconPickerTrait.php';

	class DnxteVerticalMenuIconPicker {
		use \DNXTE\Modules\NextVerticalMenu\NextVerticalMenuTrait\IconPickerTrait;
	}

	DnxteVerticalMenuIconPicker::register_icon_picker_hooks();
}

// Initialize Divi 5 Section/Row/Column Extensions (conditionally based on dashboard toggles)
$dnxte_inactive_ext = get_option( 'dnxte_inactive_extensions', array() );

$dnxte_spotlight_on = ! in_array( 'dnxte-spotlight-effect', $dnxte_inactive_ext, true );
$dnxte_card_on      = ! in_array( 'dnxte-card-effects', $dnxte_inactive_ext, true );

if ( $dnxte_spotlight_on || $dnxte_card_on ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/RowSectionExtension.php';
	\DNXTE\Extensions\RowSectionExtension::$spotlight_enabled = $dnxte_spotlight_on;
	\DNXTE\Extensions\RowSectionExtension::$card_enabled      = $dnxte_card_on;
	\DNXTE\Extensions\RowSectionExtension::init();
}

// The lightweight Spotlight engine (spotlight-card.js → window.SpotlightCard) is a
// shared building block used by the Section/Row extension AND by modules (e.g. the
// Blurb module's Spotlight). Register it for the Visual Builder UNCONDITIONALLY so
// a module never hits "window.SpotlightCard is not a constructor" when the
// Section/Row Spotlight extension happens to be toggled off. (Registered here so it
// is the single owner; RowSectionExtension no longer registers the VB build.)
add_action( 'wp', function () {
	if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled()
		|| ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled()
		|| ! class_exists( '\ET\Builder\VisualBuilder\Assets\PackageBuildManager' ) ) {
		return;
	}
	$engine = DIVI_ESSENTIAL_DIR . 'assets/js/spotlight-card.js';
	$css    = DIVI_ESSENTIAL_DIR . 'assets/css/spotlight-card.css';
	if ( ! file_exists( $engine ) ) {
		return;
	}
	\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( array(
		'name'    => 'dnxte-spotlight-card-vb',
		'version' => filemtime( $engine ),
		'script'  => array(
			'src'                => DIVI_ESSENTIAL_URL . 'assets/js/spotlight-card.js',
			'deps'               => array(),
			'enqueue_top_window' => false,
			'enqueue_app_window' => true,
			'args'               => array( 'in_footer' => false ),
		),
		'style'   => file_exists( $css ) ? array(
			'src'                => DIVI_ESSENTIAL_URL . 'assets/css/spotlight-card.css',
			'enqueue_top_window' => false,
			'enqueue_app_window' => true,
		) : array(),
	) );
}, 5 );

if ( ! in_array( 'dnxte-particle-effects', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/ParticlesExtension.php';
	\DNXTE\Extensions\ParticlesExtension::init();
}

if ( ! in_array( 'dnxte-floating-elements', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/FloatingExtension.php';
	\DNXTE\Extensions\FloatingExtension::init();
}

if ( ! in_array( 'dnxte-cursor-trail-effects', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/CursorExtension.php';
	\DNXTE\Extensions\CursorExtension::init();
}

if ( ! in_array( 'dnxte-animated-gradient', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/GradientExtension.php';
	\DNXTE\Extensions\GradientExtension::init();
}

if ( ! in_array( 'dnxte-video-background', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/VideoExtension.php';
	\DNXTE\Extensions\VideoExtension::init();
}

if ( ! in_array( 'dnxte-text-animation', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/TextAnimExtension.php';
	\DNXTE\Extensions\TextAnimExtension::init();
}

if ( ! in_array( 'dnxte-button-fx', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/ButtonFxExtension.php';
	\DNXTE\Extensions\ButtonFxExtension::init();
}

if ( ! in_array( 'dnxte-tooltip', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/TooltipExtension.php';
	\DNXTE\Extensions\TooltipExtension::init();
}

if ( ! in_array( 'dnxte-horizontal-scroll', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/HorizontalScrollExtension.php';
	\DNXTE\Extensions\HorizontalScrollExtension::init();
}

if ( ! in_array( 'dnxte-scroll-stack', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/ScrollStackExtension.php';
	\DNXTE\Extensions\ScrollStackExtension::init();
}

if ( ! in_array( 'dnxte-image-mask', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/ImageMaskExtension.php';
	\DNXTE\Extensions\ImageMaskExtension::init();
}
// Uses the same 'read-more-extension' slug as the Divi 4 loader
// (includes/Extensions/extensions.php:41), so one dashboard toggle governs both builders.
if ( ! in_array( 'read-more-extension', $dnxte_inactive_ext, true ) ) {
	require_once DIVI_ESSENTIAL_DIR . 'divi-5/server/Extensions/ReadMoreExtension.php';
	\DNXTE\Extensions\ReadMoreExtension::init();
}


/**
 * Enqueue Divi 5 Visual Builder Assets
 *
 * @since 5.0.0
 */
function dnxte_divi5_enqueue_visual_builder_assets() {
    // Everything below targets the Visual Builder app window only (no frontend impact),
    // so bail on the front end. This also prevents a fatal when PackageBuildManager — a
    // VB-only class that isn't loaded on regular frontend requests — is referenced below.
    if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
        return;
    }
    // Safety net: PackageBuildManager may be absent depending on the active Divi build.
    if ( ! class_exists( '\ET\Builder\VisualBuilder\Assets\PackageBuildManager' ) ) {
        return;
    }

    // Module-picker icons — selectors all target .et-vb-module-picker-*.
    wp_enqueue_style( 'dnxte-module-icon', DIVI_ESSENTIAL_URL . 'assets/css/modules-icon.css', array(), DIVI_ESSENTIAL_VERSION );

    $bundle_css = DIVI_ESSENTIAL_PATH . '/divi-5/styles/bundle.css';
    \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
        [
            'name'    => 'dnxte-divi5-visual-builder',
            'version' => file_exists( $bundle_css ) ? filemtime( $bundle_css ) : DIVI_ESSENTIAL_VERSION,
            'script'  => [
                'src'                => DIVI_ESSENTIAL_URL . '/divi-5/scripts/bundle.js',
                'deps'               => [
                    'divi-module-library',
                    'divi-vendor-wp-hooks',
                    'react',
                    'jquery-core',
                    'divi-rest',
                    'wp-hooks',
                ],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
            ],
            'style'   => [
                'src'                => DIVI_ESSENTIAL_URL . 'divi-5/styles/bundle.css',
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
            ],
        ]
    );
}
add_action( 'wp', 'dnxte_divi5_enqueue_visual_builder_assets' );

/**
 * Inject WooCommerce product options into the visual builder bundle for the
 * AjaxSearch Exclude Products multiselect. Runs after PackageBuildManager
 * enqueues scripts (priority 10), so the handle is already registered.
 */
function dnxte_inject_ajax_search_product_options() {
    if ( ! function_exists( 'wc_get_products' ) ) {
        return;
    }
    if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
        return;
    }

    $cache_key = 'dnxte_ajax_search_product_options';
    $options   = wp_cache_get( $cache_key, 'dnxte_ajax_search' );

    if ( false === $options ) {
        $products = wc_get_products( [
            'status'  => 'publish',
            'limit'   => 200,
            'orderby' => 'title',
            'order'   => 'ASC',
            'return'  => 'objects',
        ] );

        $options = [];
        foreach ( $products as $product ) {
            $sku       = $product->get_sku();
            $label     = $product->get_name() . ( $sku ? ' (SKU: ' . $sku . ')' : '' );
            $options[] = [
                'value' => (string) $product->get_id(),
                'label' => $label,
            ];
        }

        wp_cache_set( $cache_key, $options, 'dnxte_ajax_search', 5 * MINUTE_IN_SECONDS );
    }

    wp_add_inline_script(
        'dnxte-divi5-visual-builder',
        'window.dnxteAjaxSearchProducts = ' . wp_json_encode( $options ) . ';',
        'before'
    );
}
add_action( 'wp_enqueue_scripts', 'dnxte_inject_ajax_search_product_options', 20 );

/**
 * Inject post options (all public post types except products/attachments) into
 * the visual builder bundle for the AjaxSearch Exclude Posts multiselect.
 * Runs after PackageBuildManager enqueues scripts (priority 10), so the handle
 * is already registered.
 */
function dnxte_inject_ajax_search_post_options() {
    if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
        return;
    }

    if ( ! class_exists( '\DNXTE\Modules\AjaxSearch\AjaxSearch' ) ) {
        return;
    }

    $options = \DNXTE\Modules\AjaxSearch\AjaxSearch::get_post_options();

    wp_add_inline_script(
        'dnxte-divi5-visual-builder',
        'window.dnxteAjaxSearchPosts = ' . wp_json_encode( $options ) . ';',
        'before'
    );
}
add_action( 'wp_enqueue_scripts', 'dnxte_inject_ajax_search_post_options', 20 );

/**
 * Inject published-page options into the visual builder bundle for the
 * AjaxSearch Include Pages multiselect. Runs after PackageBuildManager
 * enqueues scripts (priority 10), so the handle is already registered.
 */
function dnxte_inject_ajax_search_page_options() {
    if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
        return;
    }

    if ( ! class_exists( '\DNXTE\Modules\AjaxSearch\AjaxSearch' ) ) {
        return;
    }

    $options = \DNXTE\Modules\AjaxSearch\AjaxSearch::get_page_options();

    wp_add_inline_script(
        'dnxte-divi5-visual-builder',
        'window.dnxteAjaxSearchPages = ' . wp_json_encode( $options ) . ';',
        'before'
    );
}
add_action( 'wp_enqueue_scripts', 'dnxte_inject_ajax_search_page_options', 20 );

/**
 * Detect whether a given content blob references any Divi Essential module.
 *
 * Matches both Divi 4 shortcodes ([dnxte_*]) and Divi 5 blocks (wp:dnxte/*).
 */
function dnxte_content_has_essential_module( $content ) {
    if ( ! is_string( $content ) || '' === $content ) {
        return false;
    }
    return false !== strpos( $content, '[dnxte_' ) || false !== strpos( $content, 'wp:dnxte/' );
}

/**
 * Extract Divi Library layout IDs referenced by wp:divi/global-layout blocks.
 *
 * When content is placed from the Divi Library as a global item, the page's
 * post_content stores only a reference block —
 *   <!-- wp:divi/global-layout {"globalModule":"123"} /-->
 * — while the actual module markup lives in the referenced et_pb_layout post.
 * Divi expands these at render time (BlockParser), long after
 * wp_enqueue_scripts, so our content scans must resolve them explicitly.
 * The regex mirrors the one Divi core uses in BlockParser::parse().
 */
function dnxte_extract_global_layout_ids( $content ) {
    if ( ! is_string( $content ) || '' === $content || false === strpos( $content, 'wp:divi/global-layout' ) ) {
        return array();
    }
    if ( ! preg_match_all( '/<!--\s*wp:divi\/global-layout\s+\{.*?"globalModule":"?(\d+)"?/s', $content, $matches ) ) {
        return array();
    }
    return array_values( array_unique( array_map( 'intval', $matches[1] ) ) );
}

/**
 * Extract Divi Library layout IDs embedded in Essential module attributes.
 *
 * Some modules render a Divi Library layout as their inner content — e.g.
 * NextAdvancedTabItem (misc.advanced.library) and NextContentToggle
 * (content.advanced.<side>.library). The layout ID is serialized into the
 * block-comment JSON as a breakpoint-structured attribute:
 *   "library":{"desktop":{"value":"155"}}
 * The layout is fetched and rendered by CommonTrait::get_content() during
 * the_content — after wp_enqueue_scripts — so the scan must resolve these
 * references itself.
 */
function dnxte_extract_module_library_ids( $content ) {
    if ( ! is_string( $content ) || '' === $content || false === strpos( $content, '"library"' ) ) {
        return array();
    }
    if ( ! preg_match_all( '/"library"\s*:\s*\{\s*"desktop"\s*:\s*\{\s*"value"\s*:\s*"?(\d+)"?/', $content, $matches ) ) {
        return array();
    }
    return array_values( array_unique( array_map( 'intval', $matches[1] ) ) );
}

/**
 * Extract Divi Library layout IDs referenced via shortcodes.
 *
 * Covers the Shortcode Library extension —
 *   [divi_shortcode_library id="123"]
 * — and raw global-module shortcodes ([et_pb_section global_module="123"],
 * which the extension expands to at render time; users also paste these
 * directly). Both execute during the_content — after wp_enqueue_scripts —
 * so the scan must resolve the referenced layout itself or modules that
 * exist only inside the shortcode's library item load without their CSS.
 */
function dnxte_extract_shortcode_library_ids( $content ) {
    if ( ! is_string( $content ) || '' === $content ) {
        return array();
    }

    $ids = array();

    // The quote around the ID varies by storage context: none, ", ', \" (JSON
    // string escape), "/' (Divi 5 block-comment JSON), or
    // &quot;/&#034;/&#039; (entity-encoded).
    $quote = '(?:\\\\u002[27]|\\\\?["\']|&quot;|&#0?3[49];)?';

    if ( false !== strpos( $content, 'divi_shortcode_library' )
        && preg_match_all( '/\[divi_shortcode_library[^\]]*\bid\s*=\s*' . $quote . '(\d+)/i', $content, $matches ) ) {
        $ids = $matches[1];
    }

    if ( false !== strpos( $content, 'global_module' )
        && preg_match_all( '/\bglobal_module\s*=\s*' . $quote . '(\d+)/i', $content, $matches ) ) {
        $ids = array_merge( $ids, $matches[1] );
    }

    return array_values( array_unique( array_map( 'intval', $ids ) ) );
}

/**
 * Resolve Divi Library references inside a set of content blobs.
 *
 * Returns the original blobs plus the post_content of every library layout
 * they reference, followed transitively (a library item can itself reference
 * another library item). Three reference kinds are resolved:
 *   - wp:divi/global-layout blocks — Divi core only renders these when the
 *     target is a published et_pb_layout, so the same gate applies here.
 *   - module "library" attributes — rendered via CommonTrait::get_content(),
 *     which uses get_post_field() with no status/type gate, so none is
 *     applied here either.
 *   - library shortcodes ([divi_shortcode_library id] / global_module attrs)
 *     — ungated: enqueuing CSS for a layout that ends up not rendering is
 *     harmless, while gating risks unstyled output.
 * Each referenced ID is fetched at most once, so circular references terminate.
 */
function dnxte_expand_library_references( $contents ) {
    $expanded = array();
    $queue    = array();
    foreach ( (array) $contents as $content ) {
        if ( is_string( $content ) && '' !== $content ) {
            $expanded[] = $content;
            $queue[]    = $content;
        }
    }

    $seen_ids    = array();
    $layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';

    while ( ! empty( $queue ) ) {
        $content = array_shift( $queue );

        // Keyed by layout ID => whether the publish/post-type gate applies.
        // `+` (not array_merge, which renumbers integer keys) keeps IDs intact;
        // an ID referenced both ways stays ungated, matching the more
        // permissive render path.
        $refs = array_fill_keys( dnxte_extract_module_library_ids( $content ), false )
            + array_fill_keys( dnxte_extract_shortcode_library_ids( $content ), false )
            + array_fill_keys( dnxte_extract_global_layout_ids( $content ), true );

        foreach ( $refs as $layout_id => $is_gated ) {
            if ( isset( $seen_ids[ $layout_id ] ) ) {
                continue;
            }
            $seen_ids[ $layout_id ] = true;

            $layout_post = get_post( $layout_id );
            if ( ! $layout_post ) {
                continue;
            }
            if ( $is_gated && ( $layout_type !== $layout_post->post_type || 'publish' !== $layout_post->post_status ) ) {
                continue;
            }
            $expanded[] = $layout_post->post_content;
            $queue[]    = $layout_post->post_content;
        }
    }

    return $expanded;
}

/**
 * Decide whether the current request needs the Divi Essential frontend bundle.
 *
 * Conservative by design: only short-circuits on singular views where we can
 * fully inspect content + applicable Theme Builder layouts. Everything else
 * (archives, home, search, 404) keeps loading the bundle to avoid unstyled
 * modules. Override via the `dnxte_force_enqueue_frontend_styles` filter.
 */
function dnxte_page_uses_essential_modules() {
    if ( ! is_singular() ) {
        return true;
    }

    $contents_to_scan = array();

    $post = get_post();
    if ( $post ) {
        $contents_to_scan[] = $post->post_content;
    }

    // Theme Builder layouts (header/body/footer) can inject modules into any view.
    if ( function_exists( 'et_theme_builder_get_template_layouts' ) ) {
        $layouts = et_theme_builder_get_template_layouts();
        if ( is_array( $layouts ) ) {
            foreach ( $layouts as $layout ) {
                if ( empty( $layout['id'] ) || empty( $layout['enabled'] ) ) {
                    continue;
                }
                $layout_post = get_post( $layout['id'] );
                if ( $layout_post ) {
                    $contents_to_scan[] = $layout_post->post_content;
                }
            }
        }
    } else {
        // Theme Builder API unavailable — fail safe.
        return true;
    }

    foreach ( dnxte_expand_library_references( $contents_to_scan ) as $content ) {
        if ( dnxte_content_has_essential_module( $content ) ) {
            return true;
        }
    }

    // Filter-contributed content (e.g. active popups via popup-pro). Same filter
    // the scanner uses — keeps this gate in sync so a page whose Essential
    // modules live ONLY in a popup doesn't get its enqueue skipped here.
    $extras = apply_filters( 'dnxte_extra_content_for_module_detection', array() );
    if ( is_array( $extras ) ) {
        foreach ( dnxte_expand_library_references( $extras ) as $content ) {
            if ( dnxte_content_has_essential_module( $content ) ) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Build a map of Divi 5 block name (e.g. "dnxte/dnxte-text-tilt") → ModuleName
 * (e.g. "NextTextTilt"). The ModuleName matches the per-module CSS filename
 * emitted by webpack (divi-5/styles/module-styles/<ModuleName>.css).
 *
 * Cached in a transient keyed by plugin version so it rebuilds automatically
 * on upgrade. Manual flush: delete the transient or bump DIVI_ESSENTIAL_VERSION.
 */
function dnxte_get_module_style_map() {
    $cache_key = 'dnxte_module_style_map_' . DIVI_ESSENTIAL_VERSION;
    $cached    = get_transient( $cache_key );
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $map = array();
    if ( ! defined( 'DIVI_ESSENTIAL_MODULES_JSON_PATH' ) ) {
        return $map;
    }

    $module_dirs = glob( DIVI_ESSENTIAL_MODULES_JSON_PATH . '*', GLOB_ONLYDIR );
    if ( ! is_array( $module_dirs ) ) {
        return $map;
    }

    foreach ( $module_dirs as $dir ) {
        $json_path = trailingslashit( $dir ) . 'module.json';
        if ( ! is_readable( $json_path ) ) {
            continue;
        }
        $data = json_decode( file_get_contents( $json_path ), true );
        if ( ! is_array( $data ) || empty( $data['name'] ) || 0 !== strpos( $data['name'], 'dnxte/' ) ) {
            continue;
        }
        $map[ $data['name'] ] = basename( $dir );
    }

    set_transient( $cache_key, $map, DAY_IN_SECONDS );
    return $map;
}

/**
 * Scan content for Divi 5 block names matching wp:dnxte/<slug> and return
 * the slugs found. Used to enumerate which per-module CSS files to enqueue.
 *
 * Returns an empty array if nothing matched.
 */
function dnxte_extract_block_names_from_content( $content ) {
    if ( ! is_string( $content ) || '' === $content || false === strpos( $content, 'wp:dnxte/' ) ) {
        return array();
    }
    if ( ! preg_match_all( '/<!--\s*wp:(dnxte\/[a-z0-9\-_]+)/i', $content, $matches ) ) {
        return array();
    }
    return array_values( array_unique( $matches[1] ) );
}

/**
 * Collect every Divi 5 Essential block name referenced by the current view —
 * post content plus any enabled Theme Builder layouts (header/body/footer),
 * plus anything contributed by the `dnxte_extra_content_for_module_detection`
 * filter (used by popup-pro to feed in active popup post_content so per-module
 * CSS files load on pages that will render a popup).
 */
function dnxte_collect_block_names_for_current_view() {
    $contents_to_scan = array();

    $post = get_post();
    if ( $post ) {
        $contents_to_scan[] = $post->post_content;
    }

    if ( function_exists( 'et_theme_builder_get_template_layouts' ) ) {
        $layouts = et_theme_builder_get_template_layouts();
        if ( is_array( $layouts ) ) {
            foreach ( $layouts as $layout ) {
                if ( empty( $layout['id'] ) || empty( $layout['enabled'] ) ) {
                    continue;
                }
                $layout_post = get_post( $layout['id'] );
                if ( $layout_post ) {
                    $contents_to_scan[] = $layout_post->post_content;
                }
            }
        }
    }

    /**
     * Filter content blobs scanned for Divi 5 Essential block detection.
     *
     * Lets extensions contribute additional post_content strings (e.g. active
     * popups, reusable blocks, future loop-builder sources) so the per-module
     * CSS enqueue path sees the modules they contain.
     *
     * @param string[] $contents_to_scan Array of raw post_content strings.
     */
    $contents_to_scan = apply_filters( 'dnxte_extra_content_for_module_detection', $contents_to_scan );

    // Resolve Divi Library references (wp:divi/global-layout) so modules that
    // exist only inside a global library item are still enumerated.
    $contents_to_scan = dnxte_expand_library_references( $contents_to_scan );

    $found = array();
    foreach ( (array) $contents_to_scan as $content ) {
        $found = array_merge( $found, dnxte_extract_block_names_from_content( $content ) );
    }

    return array_values( array_unique( $found ) );
}

/**
 * Enqueue Divi 5 Frontend Styles
 *
 * Per-module CSS split: enqueue only the styles each present module needs.
 * Falls back to the full bundle.css when:
 *   - VB is active (editor can insert any module)
 *   - Detection is unsafe (non-singular, no TB API, D4 shortcodes present)
 *   - The `dnxte_force_enqueue_frontend_styles` filter returns true
 *
 * Why scan content here (at `wp_enqueue_scripts`) instead of enqueuing inside
 * each module's `ModuleScriptDataTrait`?
 *   Divi calls `module_script_data()` from `Module::render()` during
 *   `the_content` — which fires AFTER `wp_head` has already flushed. A
 *   `wp_enqueue_style()` from a trait therefore lands in the footer via
 *   `wp_print_footer_scripts`, causing FOUC: module HTML paints unstyled,
 *   then snaps to styled when the late `<link>` arrives. Scanning at
 *   `wp_enqueue_scripts` (priority 20) keeps every per-module `<link>` in
 *   `<head>`. Scripts use the trait pattern because footer-loaded scripts
 *   are fine; CSS in the footer is not.
 *
 * Known risks / limits of the content-scan approach:
 *   - Divi Library global items (`<!-- wp:divi/global-layout ... /-->`) ARE
 *     handled: dnxte_expand_library_references() resolves them (transitively)
 *     before scanning, so modules living only inside a library item still get
 *     their per-module CSS.
 *   - Reusable blocks (`<!-- wp:block {"ref":N} /-->`) reference content stored
 *     in a separate post; any DE block used only inside a synced pattern is
 *     invisible to a regex on `post_content` and its CSS will be missed. Sites
 *     that rely on synced patterns should set the
 *     `dnxte_force_enqueue_frontend_styles` filter to true.
 *   - Dynamic content (loop builders, ACF flexible content, shortcodes that
 *     inject blocks at render time) is not present in raw `post_content` and
 *     won't be detected. Same mitigation.
 *   - `dnxte_get_module_style_map()` is transient-cached and keyed by
 *     `DIVI_ESSENTIAL_VERSION`. Adding or renaming a module without bumping
 *     the plugin version leaves a stale map for up to `DAY_IN_SECONDS`. Bump
 *     the version on release or delete the transient to flush.
 *
 * Performance:
 *   Per request the scan runs `get_post()` (already cached by core), optional
 *   `get_post()` calls for each enabled TB layout (≤3, also cached), one
 *   `preg_match_all` over `post_content`, plus `file_exists`/`filemtime` per
 *   matched module. Typical cost is well under a millisecond; the TB lookups
 *   and stat calls dominate and are still negligible. The transient skips the
 *   `glob()` + JSON parse of `modules-json/` on every request.
 *
 * @since 5.0.0
 */
function dnxte_divi5_enqueue_frontend_styles() {
    $needed = apply_filters(
        'dnxte_force_enqueue_frontend_styles',
        dnxte_page_uses_essential_modules()
    );
    if ( ! $needed ) {
        return;
    }

    $bundle_css      = DIVI_ESSENTIAL_PATH . '/divi-5/styles/bundle.css';
    $bundle_url      = DIVI_ESSENTIAL_URL . 'divi-5/styles/bundle.css';
    $bundle_version  = file_exists( $bundle_css ) ? filemtime( $bundle_css ) : DIVI_ESSENTIAL_VERSION;
    $enqueue_bundle  = function () use ( $bundle_url, $bundle_version ) {
        wp_enqueue_style( 'dnxte-divi5-modules', $bundle_url, array(), $bundle_version );
    };

    // VB / FB context: editor needs every module's CSS for the picker preview.
    if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
        $enqueue_bundle();
        return;
    }

    // Conservative bail-outs: anywhere we can't reliably enumerate modules,
    // load the full bundle to avoid unstyled output.
    if ( ! is_singular() ) {
        $enqueue_bundle();
        return;
    }

    $post = get_post();
    if ( ! $post ) {
        $enqueue_bundle();
        return;
    }

    // Divi 4 shortcodes need legacy module CSS already enqueued via per-module
    // PHP traits — but they aren't represented in the D5 style map. To stay
    // safe, fall back to the bundle whenever we see D4 shortcodes in content.
    if ( false !== strpos( $post->post_content, '[dnxte_' ) ) {
        $enqueue_bundle();
        return;
    }

    $block_names = dnxte_collect_block_names_for_current_view();
    if ( empty( $block_names ) ) {
        // No D5 DE blocks but page_uses_essential_modules() returned true —
        // probably a TB layout with D4 content. Fail safe.
        $enqueue_bundle();
        return;
    }

    // Per-module CSS dependencies on shared libraries. Declared here (not in
    // module traits) because trait-level wp_enqueue_style runs during
    // the_content rendering, AFTER wp_head — too late to land in <head> before
    // the module's JS initializes. Listing deps here ensures the shared style
    // is loaded ahead of the module CSS and before any frontend script runs.
    $module_style_deps = array(
        'NextLogoCarousel'      => array( 'dnext_swiper' ),
        'NextPostCarousel'      => array( 'dnext_swiper' ),
        'NextInstaFeedCarousel' => array( 'dnext_swiper' ),
        'Next3dCubeSlider'      => array( 'dnext_swiper' ),
        'DiviCarousel'          => array( 'dnext_swiper' ),
        'NextSocialProof'       => array( 'dnext_swiper' ),
        'NextGallerySlider'     => array( 'dnext_swiper' ),
        'NextTestimonialSlider' => array( 'dnext_swiper' ),
    );

    $style_map         = dnxte_get_module_style_map();
    $module_styles_dir = DIVI_ESSENTIAL_PATH . '/divi-5/styles/module-styles/';
    $module_styles_url = DIVI_ESSENTIAL_URL . 'divi-5/styles/module-styles/';
    $enqueued_any      = false;

    foreach ( $block_names as $block_name ) {
        if ( empty( $style_map[ $block_name ] ) ) {
            continue;
        }
        $module_name = $style_map[ $block_name ];
        $file_path   = $module_styles_dir . $module_name . '.css';
        if ( ! file_exists( $file_path ) ) {
            continue;
        }
        $deps = isset( $module_style_deps[ $module_name ] ) ? $module_style_deps[ $module_name ] : array();
        wp_enqueue_style(
            'dnxte-divi5-module-' . sanitize_key( $module_name ),
            $module_styles_url . $module_name . '.css',
            $deps,
            filemtime( $file_path )
        );
        $enqueued_any = true;
    }

    // Final safety net: if mapping missed everything (e.g. stale cache after a
    // module rename), serve the bundle so the page renders styled.
    if ( ! $enqueued_any ) {
        $enqueue_bundle();
    }
}
// Priority 20: ensures includes/Frontend/Assets.php (default priority 10) has
// already registered shared handles like dnext_swiper before we use them as
// per-module style deps below.
add_action( 'wp_enqueue_scripts', 'dnxte_divi5_enqueue_frontend_styles', 20 );

/**
 * Add script data for inactive modules
 *
 * @since 5.0.0
 */
function dnxte_divi5_add_script_data() {
    if ( ! et_core_is_fb_enabled() ) {
        return;
    }

    $inactive_modules = get_option( 'dnxte_inactive_modules', array() );

    // Check if Stripe keys are configured.
    $integrations    = get_option( 'dnxte_integrations', array() );
    $stripe_settings = isset( $integrations['stripe'] ) ? $integrations['stripe'] : array();
    $has_test_key    = ! empty( $stripe_settings['test_secret_key'] );
    $has_live_key    = ! empty( $stripe_settings['live_secret_key'] );

    // Check if PayPal keys are configured.
    $paypal_settings        = isset( $integrations['paypal'] ) ? $integrations['paypal'] : array();
    $has_sandbox_client_id  = ! empty( $paypal_settings['sandbox_client_id'] );
    $has_sandbox_secret     = ! empty( $paypal_settings['sandbox_secret'] );
    $has_live_client_id     = ! empty( $paypal_settings['live_client_id'] );
    $has_live_secret        = ! empty( $paypal_settings['live_secret'] );

    // Built as an inline script on a data-only handle (src = false) rather than
    // echoed into wp_head, so it goes through the WordPress script API. The
    // `window.X = window.X || {}` merge is preserved verbatim: wp_localize_script()
    // would replace the whole object instead of extending it, which would clobber
    // anything another module had already put on these globals.
    $data = 'window.divi_essential = window.divi_essential || {};' . "\n";
    $data .= 'window.divi_essential.inactive_modules = ' . wp_json_encode( $inactive_modules ) . ";\n";
    $data .= 'window.Dnxte_Essential = window.Dnxte_Essential || {};' . "\n";
    $data .= 'window.Dnxte_Essential.ajaxurl = ' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ";\n";
    $data .= 'window.Dnxte_Essential.nonce = ' . wp_json_encode( wp_create_nonce( DNXTE_MODULES_NONCE ) ) . ";\n";
    $data .= 'window.Dnxte_Essential.postId = ' . wp_json_encode( get_the_ID() ) . ";\n";
    $data .= 'window.Dnxte_Essential.restNonce = ' . wp_json_encode( wp_create_nonce( 'wp_rest' ) ) . ";\n";
    $data .= 'window.Dnxte_Essential.integrationsUrl = ' . wp_json_encode( admin_url( 'admin.php?page=dnxte-essential-integrations' ) ) . ";\n";
    // Base URL for the plugin's bundled assets. The Visual Builder needs this so
    // editor previews can load vendored libraries (FullCalendar, etc.) from the
    // copies shipped with the plugin instead of reaching out to a public CDN.
    $data .= 'window.Dnxte_Essential.assetsUrl = ' . wp_json_encode( DIVI_ESSENTIAL_URL . 'assets/' ) . ";\n";
    $data .= 'window.Dnxte_Essential.stripe = ' . wp_json_encode(
        array(
            'hasTestKey' => (bool) $has_test_key,
            'hasLiveKey' => (bool) $has_live_key,
            'currency'   => isset( $stripe_settings['currency'] ) ? $stripe_settings['currency'] : 'usd',
        )
    ) . ";\n";
    $data .= 'window.Dnxte_Essential.paypal = ' . wp_json_encode(
        array(
            'hasSandboxClientId' => (bool) $has_sandbox_client_id,
            'hasSandboxSecret'   => (bool) $has_sandbox_secret,
            'hasLiveClientId'    => (bool) $has_live_client_id,
            'hasLiveSecret'      => (bool) $has_live_secret,
            'currency'           => isset( $paypal_settings['currency'] ) ? $paypal_settings['currency'] : 'USD',
        )
    ) . ";\n";

    wp_register_script( 'dnxte-divi5-script-data', false, array(), DIVI_ESSENTIAL_VERSION, false );
    wp_enqueue_script( 'dnxte-divi5-script-data' );
    wp_add_inline_script( 'dnxte-divi5-script-data', $data, 'before' );
}
// Priority 1 puts this at the head of the script queue, so the globals are
// printed in wp_head ahead of the builder bundles that read them.
add_action( 'wp_enqueue_scripts', 'dnxte_divi5_add_script_data', 1 );
