/**
 * PayPal Button Frontend Script
 * Handles quantity selector and PayPal checkout
 */
(function() {
    'use strict';

    /**
     * Initialize quantity selectors
     */
    function initQuantitySelectors() {
        var minusBtns = document.querySelectorAll('.dnxte-paypal-quantity-btn--minus:not([data-qty-initialized])');
        var plusBtns  = document.querySelectorAll('.dnxte-paypal-quantity-btn--plus:not([data-qty-initialized])');

        minusBtns.forEach(function(btn) {
            btn.dataset.qtyInitialized = 'true';
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var selector = btn.closest('.dnxte-paypal-quantity-selector');
                if (!selector) return;
                var valueEl = selector.querySelector('.dnxte-paypal-quantity-value');
                if (!valueEl) return;
                var current = parseInt(valueEl.textContent, 10) || 1;
                if (current > 1) {
                    valueEl.textContent = current - 1;
                }
            });
        });

        plusBtns.forEach(function(btn) {
            btn.dataset.qtyInitialized = 'true';
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var selector = btn.closest('.dnxte-paypal-quantity-selector');
                if (!selector) return;
                var valueEl = selector.querySelector('.dnxte-paypal-quantity-value');
                if (!valueEl) return;
                var current = parseInt(valueEl.textContent, 10) || 1;
                if (current < 99) {
                    valueEl.textContent = current + 1;
                }
            });
        });
    }

    /**
     * Initialize PayPal buttons
     */
    function initPaypalButtons() {
        var buttons = document.querySelectorAll('.dnxte-paypal-button:not([disabled]):not([data-paypal-initialized])');

        buttons.forEach(function(button) {
            button.dataset.paypalInitialized = 'true';

            button.addEventListener('click', function(e) {
                e.preventDefault();
                handlePaypalCheckout(button);
            });
        });
    }

    /**
     * Handle PayPal checkout
     * @param {HTMLElement} button - The clicked button element
     */
    function handlePaypalCheckout(button) {
        var checkoutId = button.dataset.checkoutId;
        var ajaxUrl    = button.dataset.ajaxUrl;
        var nonce      = button.dataset.nonce;

        // Get quantity from the nearest quantity selector
        var wrapper  = button.closest('.dnxte-paypal-layout1__content');
        var quantity = 1;
        if (wrapper) {
            var valueEl = wrapper.querySelector('.dnxte-paypal-quantity-value');
            if (valueEl) {
                quantity = parseInt(valueEl.textContent, 10) || 1;
            }
        }

        // Get error/success containers
        var outerWrapper     = button.closest('.dnxte-paypal-button-wrapper');
        var errorContainer   = outerWrapper ? outerWrapper.querySelector('.dnxte-paypal-error') : null;
        var successContainer = outerWrapper ? outerWrapper.querySelector('.dnxte-paypal-success') : null;

        // Hide previous messages
        if (errorContainer) {
            errorContainer.style.display = 'none';
            errorContainer.textContent = '';
        }
        if (successContainer) {
            successContainer.style.display = 'none';
            successContainer.textContent = '';
        }

        // Loading state
        var textEl       = button.querySelector('.dnxte-paypal-button__text');
        var originalText = textEl ? textEl.textContent : '';
        if (textEl) {
            textEl.textContent = 'Processing...';
        }
        button.disabled = true;

        // AJAX request — only send opaque checkout ID, config stays server-side
        var formData = new FormData();
        formData.append('action', 'dnxte_paypal_create_order');
        formData.append('nonce', nonce);
        formData.append('checkout_id', checkoutId);
        formData.append('quantity', quantity);

        fetch(ajaxUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success && data.data && data.data.approval_url) {
                window.location.href = data.data.approval_url;
            } else {
                var errorMessage = (data.data && data.data.message) ? data.data.message : 'An error occurred. Please try again.';
                if (errorContainer) {
                    errorContainer.textContent = errorMessage;
                    errorContainer.style.display = 'block';
                }
                if (textEl) {
                    textEl.textContent = originalText;
                }
                button.disabled = false;
            }
        })
        .catch(function(error) {
            console.error('PayPal checkout error:', error);
            if (errorContainer) {
                errorContainer.textContent = 'Failed to process payment. Please try again.';
                errorContainer.style.display = 'block';
            }
            if (textEl) {
                textEl.textContent = originalText;
            }
            button.disabled = false;
        });
    }

    /**
     * Initialize all components
     */
    function init() {
        initQuantitySelectors();
        initPaypalButtons();
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Re-initialize on dynamic content
    if (typeof MutationObserver !== 'undefined') {
        var observer = new MutationObserver(function(mutations) {
            var shouldInit = false;
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1 && (
                            node.classList.contains('dnxte-paypal-button') ||
                            node.classList.contains('dnxte-paypal-quantity-btn') ||
                            node.querySelector && (
                                node.querySelector('.dnxte-paypal-button') ||
                                node.querySelector('.dnxte-paypal-quantity-btn')
                            )
                        )) {
                            shouldInit = true;
                        }
                    });
                }
            });
            if (shouldInit) {
                init();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
})();
