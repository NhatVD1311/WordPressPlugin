(function () {
  'use strict';

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.next_social_share_item__btn');
    if (!btn) return;

    var network = btn.getAttribute('data-network');

    if (network === 'copy_link') {
      e.preventDefault();
      var wrapper = btn.closest('.next_social_share__buttons');
      var url = wrapper ? wrapper.getAttribute('data-share-url') : window.location.href;

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () {
          showCopiedFeedback(btn);
        });
      } else {
        // Fallback for older browsers.
        var textarea = document.createElement('textarea');
        textarea.value = url;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showCopiedFeedback(btn);
      }
    }

    if (network === 'print') {
      e.preventDefault();
      window.print();
    }
  });

  function showCopiedFeedback(btn) {
    var label = btn.querySelector('.next_social_share_item__btn-label');
    if (!label) return;

    var original = label.textContent;
    label.textContent = 'Copied!';
    setTimeout(function () {
      label.textContent = original;
    }, 2000);
  }
})();
