/**
 * Divi Essential — Vertical Menu (frontend)
 *
 * Powers click/hover toggling, off-canvas drawer, single-open accordion mode,
 * external trigger binding, basic keyboard navigation, focus trap and body
 * scroll lock.
 *
 * The CSS (module.scss) is the source of truth for visual state via:
 *   - `.dnxte-vmenu-item.is-open`           → submenu open
 *   - `.dnxte-vmenu[data-offcanvas-open]`   → drawer open
 *   - `[aria-expanded="true|false"]` on caret/hamburger
 *
 * Configuration is read from data-* attributes on the root <nav>:
 *   data-trigger              click | hover
 *   data-open-behavior        single | multi
 *   data-mobile-layout        accordion | offcanvas | flyout | list
 *   data-mobile-breakpoint    px (number)
 *   data-offcanvas-active     true | false
 *   data-offcanvas-side       left | right
 *   data-offcanvas-trigger    CSS selector (optional external opener)
 */

( function () {
	'use strict';

	var ROOT_SELECTOR = '.dnxte-vmenu';
	var initialised   = new WeakSet();

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	function $$( sel, ctx ) {
		return Array.prototype.slice.call( ( ctx || document ).querySelectorAll( sel ) );
	}

	function closestItem( el ) {
		while ( el && el !== document ) {
			if ( el.classList && el.classList.contains( 'dnxte-vmenu-item' ) ) {
				return el;
			}
			el = el.parentNode;
		}
		return null;
	}

	function siblings( item ) {
		var out = [];
		if ( ! item || ! item.parentNode ) {
			return out;
		}
		var nodes = item.parentNode.children;
		for ( var i = 0; i < nodes.length; i++ ) {
			if ( nodes[ i ] !== item && nodes[ i ].classList.contains( 'dnxte-vmenu-item' ) ) {
				out.push( nodes[ i ] );
			}
		}
		return out;
	}

	function transitionMs( el ) {
		var raw = ( getComputedStyle( el ).transitionDuration || '' ).split( ',' )[ 0 ].trim();
		var val = parseFloat( raw ) || 0;
		return raw.indexOf( 'ms' ) === -1 ? val * 1000 : val;
	}

	function setOpen( item, isOpen ) {
		if ( ! item ) {
			return;
		}
		isOpen = !! isOpen;
		var wasOpen = item.classList.contains( 'is-open' );
		var caret   = item.querySelector( ':scope > a > .dnxte-vmenu-caret, :scope > .dnxte-vmenu-heading > .dnxte-vmenu-caret' );
		if ( caret ) {
			caret.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		}

		var submenu = item.querySelector( ':scope > .dnxte-vmenu-submenu' );

		// Flyout reveals via opacity/transform (max-height: none) — an inline
		// max-height would clip the panel, so it keeps the plain class toggle.
		if ( ! submenu || wasOpen === isOpen || item.closest( '.is-layout-flyout' ) ) {
			item.classList.toggle( 'is-open', isOpen );
			return;
		}

		// Animate to the MEASURED height. Transitioning to the fixed 2000px CSS
		// clamp distorts the configured --vmenu-expand-duration: opening visibly
		// finishes within the first few percent of the transition and closing
		// spends most of it in a dead freeze before snapping shut. The clamp
		// stays as the static open state (and no-JS fallback); the inline
		// max-height exists only while the transition runs.
		if ( submenu._dnxteCancel ) {
			submenu._dnxteCancel();
		}

		var startHeight = submenu.getBoundingClientRect().height;
		submenu.style.transition = 'none';
		item.classList.toggle( 'is-open', isOpen );
		// scrollHeight ignores the max-height clamp; with transitions suspended
		// the open-state padding is already applied, so this is the true height.
		var endHeight = isOpen ? submenu.scrollHeight : 0;
		submenu.style.maxHeight = startHeight + 'px';
		void submenu.offsetHeight; // commit the start frame
		submenu.style.transition = '';
		submenu.style.maxHeight  = endHeight + 'px';

		var finish = function () {
			submenu._dnxteCancel();
			submenu.style.maxHeight = '';
		};
		var onEnd = function ( e ) {
			// Nested submenu transitions bubble up — only act on this element.
			if ( e.target === submenu && 'max-height' === e.propertyName ) {
				finish();
			}
		};
		// Fallback for a lost transitionend (element hidden mid-animation, 0ms duration).
		var timer = setTimeout( finish, transitionMs( submenu ) + 100 );
		submenu._dnxteCancel = function () {
			submenu.removeEventListener( 'transitionend', onEnd );
			clearTimeout( timer );
			submenu._dnxteCancel = null;
		};
		submenu.addEventListener( 'transitionend', onEnd );
	}

	function toggleItem( root, item ) {
		var openBehavior = root.getAttribute( 'data-open-behavior' ) || 'single';
		var willOpen     = ! item.classList.contains( 'is-open' );

		if ( willOpen && 'single' === openBehavior ) {
			siblings( item ).forEach( function ( sib ) {
				setOpen( sib, false );
			} );
		}
		setOpen( item, willOpen );
	}

	// ------------------------------------------------------------------
	// Off-canvas drawer
	// ------------------------------------------------------------------

	var bodyScrollLockCount = 0;
	function lockBodyScroll() {
		bodyScrollLockCount++;
		if ( bodyScrollLockCount === 1 ) {
			document.documentElement.style.overflow = 'hidden';
		}
	}
	function unlockBodyScroll() {
		bodyScrollLockCount = Math.max( 0, bodyScrollLockCount - 1 );
		if ( bodyScrollLockCount === 0 ) {
			document.documentElement.style.overflow = '';
		}
	}

	function focusableIn( ctx ) {
		return $$(
			'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
			ctx
		).filter( function ( el ) {
			return el.offsetParent !== null;
		} );
	}

	/**
	 * Opens the off-canvas drawer panel.
	 *
	 * @param {Element} root   The root `.dnxte-vmenu` nav element.
	 * @param {Element} panel  The off-canvas panel element to open.
	 *                         When using footer rendering this is the separate
	 *                         `.dnxte-vmenu-offcanvas-panel[data-panel-id]` element.
	 *                         When using inline rendering this is root itself.
	 */
	function openDrawer( root, panel ) {
		var isOpen = panel === root
			? root.hasAttribute( 'data-offcanvas-open' )
			: 'true' === panel.getAttribute( 'data-open' );

		if ( isOpen ) {
			return;
		}

		if ( panel === root ) {
			root.setAttribute( 'data-offcanvas-open', 'true' );
		} else {
			panel.setAttribute( 'data-open', 'true' );
			panel.setAttribute( 'aria-hidden', 'false' );
		}

		// Toggle paired backdrop (footer rendering).
		var pId = panel.getAttribute && panel.getAttribute( 'data-panel-id' );
		var backdrop = pId
			? document.querySelector( '.dnxte-vmenu-offcanvas-backdrop[data-panel-id="' + pId + '"]' )
			: null;
		if ( backdrop ) {
			backdrop.setAttribute( 'data-open', 'true' );
			backdrop.setAttribute( 'aria-hidden', 'false' );
		}

		var hamburger = root.querySelector( '.dnxte-vmenu-hamburger' );
		if ( hamburger ) {
			hamburger.setAttribute( 'aria-expanded', 'true' );
		}
		lockBodyScroll();
		document.body.classList.add( 'dnxte-vmenu-drawer-open' );

		// Close when clicking anywhere outside the off-canvas panel.
		var outsideClickHandler = function ( e ) {
			var panelEl = panel === root ? root.querySelector( '.dnxte-vmenu-panel' ) : panel;
			if ( panelEl && ! panelEl.contains( e.target ) ) {
				document.removeEventListener( 'click', outsideClickHandler, true );
				closeDrawer( root, panel, hamburger );
			}
		};
		// Use capture so the listener fires before any inner handlers; defer one tick
		// so the hamburger click that opened the drawer doesn't immediately re-close it.
		setTimeout( function () {
			document.addEventListener( 'click', outsideClickHandler, true );
		}, 0 );

		// Move focus into panel.
		var panelContent = panel === root
			? root.querySelector( '.dnxte-vmenu-panel' )
			: panel;
		var first = focusableIn( panelContent )[ 0 ];
		if ( first ) {
			first.focus();
		}
	}

	/**
	 * Closes the off-canvas drawer panel.
	 *
	 * @param {Element} root            The root `.dnxte-vmenu` nav element.
	 * @param {Element} panel            The off-canvas panel element to close.
	 * @param {Element} returnFocusTo   Element to receive focus after close (optional).
	 */
	function closeDrawer( root, panel, returnFocusTo ) {
		var isOpen = panel === root
			? root.hasAttribute( 'data-offcanvas-open' )
			: 'true' === panel.getAttribute( 'data-open' );

		if ( ! isOpen ) {
			return;
		}

		if ( panel === root ) {
			root.removeAttribute( 'data-offcanvas-open' );
		} else {
			panel.removeAttribute( 'data-open' );
			panel.setAttribute( 'aria-hidden', 'true' );
		}

		// Toggle paired backdrop (footer rendering).
		var pId = panel.getAttribute && panel.getAttribute( 'data-panel-id' );
		var backdrop = pId
			? document.querySelector( '.dnxte-vmenu-offcanvas-backdrop[data-panel-id="' + pId + '"]' )
			: null;
		if ( backdrop ) {
			backdrop.removeAttribute( 'data-open' );
			backdrop.setAttribute( 'aria-hidden', 'true' );
		}

		var hamburger = root.querySelector( '.dnxte-vmenu-hamburger' );
		if ( hamburger ) {
			hamburger.setAttribute( 'aria-expanded', 'false' );
		}
		unlockBodyScroll();
		document.body.classList.remove( 'dnxte-vmenu-drawer-open' );

		var target = returnFocusTo || hamburger;
		if ( target && typeof target.focus === 'function' ) {
			target.focus();
		}
	}

	function trapFocus( root, e ) {
		if ( e.key !== 'Tab' ) {
			return;
		}
		var panel    = root.querySelector( '.dnxte-vmenu-panel' );
		var focusable = focusableIn( panel );
		if ( ! focusable.length ) {
			e.preventDefault();
			return;
		}
		var first = focusable[ 0 ];
		var last  = focusable[ focusable.length - 1 ];

		if ( e.shiftKey && document.activeElement === first ) {
			e.preventDefault();
			last.focus();
		} else if ( ! e.shiftKey && document.activeElement === last ) {
			e.preventDefault();
			first.focus();
		}
	}

	// ------------------------------------------------------------------
	// Keyboard navigation within the menu
	// ------------------------------------------------------------------

	function visibleMenuLinks( root ) {
		return $$( '.dnxte-vmenu-item > a, .dnxte-vmenu-item > .dnxte-vmenu-heading', root )
			.filter( function ( el ) {
				// Ensure all ancestor <li>s are open (or top-level).
				var p = el.parentElement;
				while ( p && p !== root ) {
					if ( p.classList.contains( 'dnxte-vmenu-item' ) ) {
						var parentItem = p.parentElement && p.parentElement.closest( '.dnxte-vmenu-item' );
						if ( parentItem && ! parentItem.classList.contains( 'is-open' ) ) {
							return false;
						}
					}
					p = p.parentElement;
				}
				return true;
			} );
	}

	function handleKeydown( root, e ) {
		var active = document.activeElement;
		if ( ! active || ! root.contains( active ) ) {
			return;
		}

		var key = e.key;
		if ( [ 'ArrowDown', 'ArrowUp', 'Home', 'End' ].indexOf( key ) === -1
			&& key !== 'ArrowRight' && key !== 'ArrowLeft' && key !== 'Escape' ) {
			return;
		}

		var item    = closestItem( active );
		var links   = visibleMenuLinks( root );
		var idx     = links.indexOf( active.closest( 'a, .dnxte-vmenu-heading' ) );

		switch ( key ) {
			case 'ArrowDown':
				e.preventDefault();
				if ( idx > -1 && links[ idx + 1 ] ) {
					links[ idx + 1 ].focus();
				}
				break;
			case 'ArrowUp':
				e.preventDefault();
				if ( idx > 0 ) {
					links[ idx - 1 ].focus();
				}
				break;
			case 'Home':
				e.preventDefault();
				if ( links[ 0 ] ) {
					links[ 0 ].focus();
				}
				break;
			case 'End':
				e.preventDefault();
				if ( links.length ) {
					links[ links.length - 1 ].focus();
				}
				break;
			case 'ArrowRight':
				if ( item && item.classList.contains( 'has-children' ) && ! item.classList.contains( 'is-open' ) ) {
					e.preventDefault();
					setOpen( item, true );
				}
				break;
			case 'ArrowLeft':
				if ( item && item.classList.contains( 'is-open' ) ) {
					e.preventDefault();
					setOpen( item, false );
				}
				break;
			case 'Escape': {
				// Determine if drawer is open (supports both inline and footer rendering).
				var hPanelId = root.getAttribute( 'data-panel-id' );
				var hPanel   = hPanelId
					? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + hPanelId + '"]' )
					: root;

				var hIsOpen = hPanel && (
					hPanel === root
						? root.hasAttribute( 'data-offcanvas-open' )
						: 'true' === hPanel.getAttribute( 'data-open' )
				);

				if ( hIsOpen && hPanel ) {
					e.preventDefault();
					closeDrawer( root, hPanel, hamburger );
				} else if ( item && item.classList.contains( 'is-open' ) ) {
					e.preventDefault();
					setOpen( item, false );
				}
				break;
			}
		}
	}

	// ------------------------------------------------------------------
	// Init
	// ------------------------------------------------------------------

	function initRoot( root ) {
		if ( initialised.has( root ) ) {
			return;
		}
		initialised.add( root );

		var trigger      = root.getAttribute( 'data-trigger' ) || 'click';
		var moduleWrapper = root.closest && root.closest( '.dnxte-vmenu-module' );

		// ---------------------------------------------------------------
		// Breakpoint-aware mobile activation
		// Toggles `is-mobile-active` on the module wrapper and adjusts
		// `data-offcanvas-active` when the viewport crosses the configured
		// breakpoint. PHP sets `data-offcanvas-active` as the "configured"
		// intent; JS overrides it based on the actual viewport width.
		// ---------------------------------------------------------------
		var bp               = parseInt( root.getAttribute( 'data-mobile-breakpoint' ) || '0', 10 );
		var offcanvasConfigured = root.getAttribute( 'data-offcanvas-active' ) === 'true';
		// "Force Off-Canvas" (enableOffCanvas) means: use the drawer at ALL widths,
		// overriding the mobile breakpoint. This is distinct from mobileLayout=offcanvas,
		// which only switches to the drawer *below* the breakpoint.
		var offcanvasForced  = root.getAttribute( 'data-offcanvas-force' ) === 'true';

		if ( bp > 0 && window.matchMedia ) {
			var mq = window.matchMedia( '(max-width: ' + ( bp - 1 ) + 'px)' );

			var applyBreakpoint = function () {
				// When forced, behave as "mobile-active" at every width so the inline
				// menu is hidden (via .is-mobile-active.has-offcanvas) and only the
				// hamburger/drawer show.
				var mobileActive = offcanvasForced || mq.matches;

				if ( moduleWrapper ) {
					moduleWrapper.classList.toggle( 'is-mobile-active', mobileActive );
				}

				// Off-canvas is active when forced, or when configured AND below breakpoint.
				var shouldBeActive = offcanvasForced || ( offcanvasConfigured && mq.matches );
				root.setAttribute( 'data-offcanvas-active', shouldBeActive ? 'true' : 'false' );

				if ( ! shouldBeActive ) {
					var panelId = root.getAttribute( 'data-panel-id' );
					var panel   = panelId
						? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' )
						: root;
					if ( panel ) {
						closeDrawer( root, panel, hamburger );
					}
				}
			};

			applyBreakpoint();

			if ( mq.addEventListener ) {
				mq.addEventListener( 'change', applyBreakpoint );
			} else if ( mq.addListener ) {
				// Safari < 14 fallback.
				mq.addListener( applyBreakpoint );
			}
		} else if ( offcanvasForced ) {
			// No usable breakpoint media query, but force is on — activate unconditionally.
			if ( moduleWrapper ) {
				moduleWrapper.classList.add( 'is-mobile-active' );
			}
			root.setAttribute( 'data-offcanvas-active', 'true' );
		}

		// Caret button → toggle submenu.
		root.addEventListener( 'click', function ( e ) {
			var caret = e.target.closest && e.target.closest( '.dnxte-vmenu-caret' );
			if ( caret && root.contains( caret ) ) {
				e.preventDefault();
				e.stopPropagation();
				var item = closestItem( caret );
				if ( item ) {
					toggleItem( root, item );
				}
				return;
			}

			// Click trigger on parent link — toggle (open OR close).
			if ( 'click' === trigger ) {
				var link = e.target.closest && e.target.closest( '.dnxte-vmenu-item.has-children > a' );
				if ( link && root.contains( link ) ) {
					e.preventDefault();
					var item2 = closestItem( link );
					if ( item2 ) {
						toggleItem( root, item2 );
					}
				}
			}
		} );

		// Sidebar collapse toggle.
		// CSS targets [data-collapsed="true"] on .dnxte-vmenu-module (the outer wrapper),
		// not on .dnxte-vmenu (root). moduleWrapper is already found above.
		var sidebarToggle = root.querySelector( '.dnxte-vmenu-sidebar-toggle' );
		if ( sidebarToggle && moduleWrapper ) {
			var initCollapsed = moduleWrapper.getAttribute( 'data-collapsed' ) === 'true';
			sidebarToggle.setAttribute( 'aria-expanded', initCollapsed ? 'false' : 'true' );

			sidebarToggle.addEventListener( 'click', function () {
				var nowCollapsed = moduleWrapper.getAttribute( 'data-collapsed' ) !== 'true';
				if ( nowCollapsed ) {
					moduleWrapper.setAttribute( 'data-collapsed', 'true' );
				} else {
					moduleWrapper.removeAttribute( 'data-collapsed' );
				}
				sidebarToggle.setAttribute( 'aria-expanded', nowCollapsed ? 'false' : 'true' );
			} );
		}

		// Off-canvas wiring.
		// Gate on the *configured* intent (captured before applyBreakpoint() ran),
		// not the live data-offcanvas-active attribute. applyBreakpoint() sets that
		// attribute to 'false' on a desktop-width load, so reading it here would skip
		// hamburger creation and listener binding entirely — leaving off-canvas dead
		// after the viewport later drops below the breakpoint. The hamburger is hidden
		// by CSS until data-offcanvas-active becomes 'true', so creating it eagerly is safe.
		if ( offcanvasConfigured || offcanvasForced ) {
			// For footer rendering (root is .dnxte-vmenu with data-panel-id), the hamburger
			// lives inside .dnxte-vmenu (not the footer panel). For inline rendering,
			// the hamburger is also inside .dnxte-vmenu. Always look there first.
			var panelId     = root.getAttribute( 'data-panel-id' );
			var menuRoot    = panelId
				? document.querySelector( '.dnxte-vmenu[data-panel-id="' + panelId + '"]' )
				: root;
			var hamburger   = menuRoot ? menuRoot.querySelector( '.dnxte-vmenu-hamburger' ) : null;

			// Create hamburger button if it doesn't exist in .dnxte-vmenu.
			if ( ! hamburger ) {
				var hamburgerLabel = root.getAttribute( 'data-offcanvas-label' ) || 'Menu';
				hamburger = document.createElement( 'button' );
				hamburger.type = 'button';
				hamburger.className = 'dnxte-vmenu-hamburger';
				hamburger.setAttribute( 'aria-expanded', 'false' );
				hamburger.setAttribute( 'aria-label', hamburgerLabel );

				var iconSpan = document.createElement( 'span' );
				iconSpan.className = 'dnxte-vmenu-hamburger-icon';
				iconSpan.setAttribute( 'aria-hidden', 'true' );
				var iconInner = document.createElement( 'span' );
				iconSpan.appendChild( iconInner );

				var labelSpan = document.createElement( 'span' );
				labelSpan.className = 'dnxte-vmenu-hamburger-label';
				labelSpan.textContent = hamburgerLabel;

				hamburger.appendChild( iconSpan );
				hamburger.appendChild( labelSpan );

				// Insert hamburger into .dnxte-vmenu so CSS selector
				// .dnxte-vmenu[data-offcanvas-active='true'] .dnxte-vmenu-hamburger works.
				if ( menuRoot ) {
					menuRoot.insertBefore( hamburger, menuRoot.firstChild );
				}
			}

			// Attach click listener to toggle drawer.
			hamburger.addEventListener( 'click', function () {
				// Determine the panel element: footer-rendered panel (via data-panel-id)
				// or the root element itself (inline rendering).
				var panelId = root.getAttribute( 'data-panel-id' );
				var panel   = panelId
					? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' )
					: root;

				if ( ! panel ) {
					return;
				}

				var isOpen = panel === root
					? root.hasAttribute( 'data-offcanvas-open' )
					: 'true' === panel.getAttribute( 'data-open' );

				if ( isOpen ) {
					closeDrawer( root, panel, hamburger );
				} else {
					openDrawer( root, panel );
				}
			} );

			// Wire close button inside the off-canvas panel.
			var offcanvasPanel = panelId
				? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' )
				: null;
			if ( offcanvasPanel ) {
				var closeBtn = offcanvasPanel.querySelector( '.dnxte-vmenu-offcanvas-close' );
				if ( closeBtn ) {
					closeBtn.addEventListener( 'click', function ( e ) {
						e.stopPropagation();
						closeDrawer( root, offcanvasPanel, hamburger );
					} );
				}

				// Handle caret clicks inside the off-canvas panel.
				// The off-canvas panel is rendered in the footer, outside .dnxte-vmenu,
				// so clicks on carets inside the panel won't bubble to the root listener.
				offcanvasPanel.addEventListener( 'click', function ( e ) {
					var caret = e.target.closest && e.target.closest( '.dnxte-vmenu-caret' );
					if ( caret && offcanvasPanel.contains( caret ) ) {
						e.preventDefault();
						e.stopPropagation();
						var item = closestItem( caret );
						if ( item ) {
							toggleItem( root, item );
						}
					}
				} );
			}

			// Wire backdrop click to close.
			if ( panelId ) {
				var backdropEl = document.querySelector( '.dnxte-vmenu-offcanvas-backdrop[data-panel-id="' + panelId + '"]' );
				if ( backdropEl ) {
					backdropEl.addEventListener( 'click', function () {
						var panel = document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' );
						if ( panel ) {
							closeDrawer( root, panel, hamburger );
						}
					} );
				}
			}

			// External triggers (any element matching the user-provided selector).
			var extSelector = ( root.getAttribute( 'data-offcanvas-trigger' ) || '' ).trim();
			if ( extSelector ) {
				try {
					$$( extSelector ).forEach( function ( el ) {
						el.addEventListener( 'click', function ( e ) {
							e.preventDefault();

							// Find the footer panel (or fall back to root for inline rendering).
							var panelId = root.getAttribute( 'data-panel-id' );
							var panel   = panelId
								? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' )
								: root;

							if ( ! panel ) {
								return;
							}

							var isOpen = panel === root
								? root.hasAttribute( 'data-offcanvas-open' )
								: 'true' === panel.getAttribute( 'data-open' );

							if ( isOpen ) {
								closeDrawer( root, panel, el );
							} else {
								openDrawer( root, panel );
							}
						} );
					} );
				} catch ( err ) {
					// Bad selector — ignore.
				}
			}

			// Trap focus + escape inside the drawer.
			document.addEventListener( 'keydown', function ( e ) {
				// Determine the panel and whether the drawer is open.
				var panelId = root.getAttribute( 'data-panel-id' );
				var panel   = panelId
					? document.querySelector( '.dnxte-vmenu-offcanvas-panel[data-panel-id="' + panelId + '"]' )
					: root;

				var isOpen = panel && (
					panel === root
						? root.hasAttribute( 'data-offcanvas-open' )
						: 'true' === panel.getAttribute( 'data-open' )
				);

				if ( ! isOpen ) {
					return;
				}

				if ( e.key === 'Escape' ) {
					e.preventDefault();
					if ( panel ) {
						closeDrawer( root, panel, hamburger );
					}
					return;
				}
				trapFocus( root, e );
			} );
		}

		// Hover-trigger handling (top-level only — child menus still need click to open).
		if ( 'hover' === trigger ) {
			$$( '.dnxte-vmenu-item.has-children', root ).forEach( function ( item ) {
				var open  = function () { setOpen( item, true ); };
				var close = function () { setOpen( item, false ); };
				item.addEventListener( 'mouseenter', open );
				item.addEventListener( 'mouseleave', close );
				item.addEventListener( 'focusin', open );
				item.addEventListener( 'focusout', function ( e ) {
					if ( ! item.contains( e.relatedTarget ) ) {
						close();
					}
				} );
			} );
		}

		// Keyboard navigation.
		root.addEventListener( 'keydown', function ( e ) {
			handleKeydown( root, e );
		} );
	}

	function initAll() {
		$$( ROOT_SELECTOR ).forEach( initRoot );
	}

	ready( initAll );

	// Re-init when Divi VB injects new content (best-effort).
	if ( window.MutationObserver ) {
		var mo = new MutationObserver( function ( mutations ) {
			for ( var i = 0; i < mutations.length; i++ ) {
				var added = mutations[ i ].addedNodes;
				for ( var j = 0; j < added.length; j++ ) {
					var node = added[ j ];
					if ( node && 1 === node.nodeType ) {
						if ( node.matches && node.matches( ROOT_SELECTOR ) ) {
							initRoot( node );
						}
						if ( node.querySelectorAll ) {
							$$( ROOT_SELECTOR, node ).forEach( initRoot );
						}
					}
				}
			}
		} );
		mo.observe( document.body, { childList: true, subtree: true } );
	}
} )();
