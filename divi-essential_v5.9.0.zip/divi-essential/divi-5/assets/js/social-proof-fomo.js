(function () {
  'use strict';

  /**
   * FOMO Notification Manager for NextSocialProof module.
   *
   * Reads configuration from data-attributes on the notification container,
   * fetches activity data from the REST API, and cycles through notifications
   * with configurable timing and animations.
   */

  function getConfig(container) {
    return {
      activityType: container.getAttribute('data-activity-type') || 'recent_sale',
      position:     container.getAttribute('data-position') || 'bottom-left',
      delay:        parseInt(container.getAttribute('data-delay'), 10) || 3000,
      duration:     parseInt(container.getAttribute('data-duration'), 10) || 5000,
      interval:     parseInt(container.getAttribute('data-interval'), 10) || 8000,
      loop:         container.getAttribute('data-loop') !== 'off',
      showClose:    container.getAttribute('data-show-close') !== 'off',
      animation:    container.getAttribute('data-animation') || 'slide',
    };
  }

  function getAnimationKeyframes(animation, position) {
    var isLeft = position.indexOf('left') !== -1;

    switch (animation) {
      case 'fade':
        return {
          enter: [{ opacity: 0 }, { opacity: 1 }],
          exit:  [{ opacity: 1 }, { opacity: 0 }],
        };

      case 'zoom':
        return {
          enter: [
            { opacity: 0, transform: 'scale(0.8)' },
            { opacity: 1, transform: 'scale(1)' },
          ],
          exit: [
            { opacity: 1, transform: 'scale(1)' },
            { opacity: 0, transform: 'scale(0.8)' },
          ],
        };

      case 'slide':
      default:
        var translateFrom = isLeft ? 'translateX(-30px)' : 'translateX(30px)';
        return {
          enter: [
            { opacity: 0, transform: translateFrom },
            { opacity: 1, transform: 'translateX(0)' },
          ],
          exit: [
            { opacity: 1, transform: 'translateX(0)' },
            { opacity: 0, transform: translateFrom },
          ],
        };
    }
  }

  // --- Safe DOM element creation helpers ---

  function createEl(tag, className, textContent) {
    var el = document.createElement(tag);
    if (className) el.className = className;
    if (textContent) el.textContent = textContent;
    return el;
  }

  function createImg(src, alt) {
    var img = document.createElement('img');
    img.src = src;
    img.alt = alt || '';
    return img;
  }

  function buildNotificationDOM(item, config) {
    var notification = createEl('div', 'dnxte-sp-notification');
    notification.style.opacity = '0';

    // Close button.
    if (config.showClose) {
      var closeBtn = document.createElement('button');
      closeBtn.className = 'dnxte-sp-notification__close';
      closeBtn.setAttribute('aria-label', 'Close');
      closeBtn.textContent = '\u00D7'; // multiplication sign (×)
      closeBtn.addEventListener('click', function () {
        dismissNotification(notification, config);
      });
      notification.appendChild(closeBtn);
    }

    // Image wrapper.
    var imageWrap = createEl('div', 'dnxte-sp-notification__image');

    // Content wrapper.
    var contentWrap = createEl('div', 'dnxte-sp-notification__content');
    var textWrap    = createEl('div', 'dnxte-sp-notification__text');

    if (config.activityType === 'live_visitors') {
      imageWrap.appendChild(createEl('span', 'dnxte-sp-notification__icon dnxte-sp-notification__icon--visitors'));

      var countStrong = createEl('strong', null, String(item.count || 0));
      textWrap.appendChild(countStrong);
      textWrap.appendChild(document.createTextNode(' ' + (item.message || 'people are viewing this page')));

    } else if (config.activityType === 'recent_signup') {
      if (item.avatar) {
        imageWrap.appendChild(createImg(item.avatar, item.name || ''));
      } else {
        imageWrap.appendChild(createEl('span', 'dnxte-sp-notification__icon dnxte-sp-notification__icon--signup'));
      }

      var nameStrong = createEl('strong', null, item.name || 'Someone');
      textWrap.appendChild(nameStrong);
      textWrap.appendChild(document.createTextNode(' just signed up'));

    } else {
      // recent_sale
      if (item.product_image) {
        imageWrap.appendChild(createImg(item.product_image, item.product_name || ''));
      } else {
        imageWrap.appendChild(createEl('span', 'dnxte-sp-notification__icon dnxte-sp-notification__icon--sale'));
      }

      var customerStrong = createEl('strong', null, item.customer || 'Someone');
      textWrap.appendChild(customerStrong);

      if (item.location) {
        textWrap.appendChild(document.createTextNode(' from ' + item.location));
      }

      textWrap.appendChild(document.createTextNode(' just purchased '));

      var productStrong = createEl('strong', null, item.product_name || 'a product');
      textWrap.appendChild(productStrong);
    }

    contentWrap.appendChild(textWrap);

    // Time.
    if (item.time) {
      contentWrap.appendChild(createEl('div', 'dnxte-sp-notification__time', item.time));
    }

    notification.appendChild(imageWrap);
    notification.appendChild(contentWrap);

    return notification;
  }

  function showNotification(notification, config) {
    var keyframes = getAnimationKeyframes(config.animation, config.position);
    notification.style.opacity = '1';

    if (notification.animate) {
      notification.animate(keyframes.enter, { duration: 300, easing: 'ease-out', fill: 'forwards' });
    }
  }

  function hideNotification(notification, config, callback) {
    var keyframes = getAnimationKeyframes(config.animation, config.position);

    if (notification.animate) {
      var anim = notification.animate(keyframes.exit, { duration: 300, easing: 'ease-in', fill: 'forwards' });
      anim.onfinish = function () {
        notification.remove();
        if (callback) callback();
      };
    } else {
      notification.style.opacity = '0';
      setTimeout(function () {
        notification.remove();
        if (callback) callback();
      }, 300);
    }
  }

  function dismissNotification(notification, config) {
    hideNotification(notification, config, null);
  }

  function fetchActivityData(config, callback) {
    var data    = window.dnxteSocialProof || {};
    var baseUrl = data.restUrl || '/wp-json/dnxte/v1/social-proof/';
    var nonce   = data.nonce || '';

    var url = baseUrl + 'activity?type=' + encodeURIComponent(config.activityType) + '&limit=5';

    var headers = { 'Content-Type': 'application/json' };
    if (nonce) {
      headers['X-WP-Nonce'] = nonce;
    }

    fetch(url, { headers: headers })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(function (items) {
        callback(null, items);
      })
      .catch(function (err) {
        callback(err, null);
      });
  }

  function startNotificationCycle(container, config) {
    fetchActivityData(config, function (err, items) {
      if (err || !items) {
        return;
      }

      // For live_visitors, the API returns a single object, not an array.
      if (config.activityType === 'live_visitors' && !Array.isArray(items)) {
        items = [items];
      }

      if (!items.length) {
        return;
      }

      var index  = 0;
      var timers = { show: 0, hide: 0, next: 0 };

      // Store cleanup reference on container for teardown.
      container._fomoCleanup = function () {
        clearTimeout(timers.show);
        clearTimeout(timers.hide);
        clearTimeout(timers.next);
      };

      function showNext() {
        if (index >= items.length) {
          if (config.loop) {
            index = 0;

            // Re-fetch data on each loop to keep notifications fresh.
            fetchActivityData(config, function (err2, freshItems) {
              if (!err2 && freshItems) {
                if (config.activityType === 'live_visitors' && !Array.isArray(freshItems)) {
                  freshItems = [freshItems];
                }
                if (freshItems.length) {
                  items = freshItems;
                }
              }
              timers.next = setTimeout(showNext, config.interval);
            });
            return;
          }
          return;
        }

        var item         = items[index];
        var notification = buildNotificationDOM(item, config);
        container.appendChild(notification);
        showNotification(notification, config);

        // Auto-hide after display duration.
        timers.hide = setTimeout(function () {
          hideNotification(notification, config, function () {
            index++;
            timers.next = setTimeout(showNext, config.interval);
          });
        }, config.duration);
      }

      // Start after initial delay.
      timers.show = setTimeout(showNext, config.delay);
    });
  }

  function initFomo() {
    var containers = document.querySelectorAll('.dnxte-sp-notifications[data-activity-type]');

    if (!containers.length) {
      return;
    }

    containers.forEach(function (container) {
      // Skip if already initialized.
      if (container._fomoInitialized) {
        return;
      }
      container._fomoInitialized = true;

      var config = getConfig(container);
      startNotificationCycle(container, config);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFomo);
  } else {
    initFomo();
  }
})();
