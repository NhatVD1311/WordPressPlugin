(function () {
  'use strict';

  function initComparisonList(container) {
    var body = container.querySelector('.dnxte-ncl-body');
    if (!body) return;

    var accordionEnabled = body.getAttribute('data-accordion') === 'true';
    var accordionType = body.getAttribute('data-accordion-type') || 'section';
    var allowMultiple = body.getAttribute('data-accordion-multiple') === 'true';
    var firstOpen = body.getAttribute('data-accordion-first-open') === 'true';
    var animation = body.getAttribute('data-animation') || 'none';

    // Initialize row animations
    if (animation !== 'none') {
      initAnimations(body, animation);
    }

    // Initialize accordion based on type
    if (accordionEnabled) {
      if (accordionType === 'section') {
        initSectionAccordion(body, allowMultiple, firstOpen);
      } else if (accordionType === 'row') {
        initRowAccordion(body, allowMultiple, firstOpen);
      }
    }
  }

  function initAnimations(body, animation) {
    var rows = body.querySelectorAll('.dnxte-ncl-row');
    if (!rows.length) return;

    rows.forEach(function (row) {
      // Skip accordion headers — they are structural and should always be visible
      if (row.classList.contains('dnxte-ncl-row--accordion-header')) return;
      row.classList.add('dnxte-ncl-row--hidden', 'dnxte-ncl-row--' + animation);
    });

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry, idx) {
          if (entry.isIntersecting) {
            var el = entry.target;
            setTimeout(function () {
              el.classList.remove('dnxte-ncl-row--hidden');
              el.classList.add('dnxte-ncl-row--visible');
            }, idx * 80);
            observer.unobserve(el);
          }
        });
      },
      { threshold: 0.1 }
    );

    rows.forEach(function (row) {
      if (row.classList.contains('dnxte-ncl-row--accordion-header')) return;
      observer.observe(row);
    });
  }

  /**
   * Section Accordion: Groups rows under collapsible section headers.
   * Items with class `dnxte-ncl-row--accordion-header` act as section headers.
   * All rows between two headers belong to the first header's section.
   */
  function initSectionAccordion(body, allowMultiple, firstOpen) {
    var allRows = Array.prototype.slice.call(body.querySelectorAll('.dnxte-ncl-row'));
    if (!allRows.length) return;

    var sections = [];
    var currentSection = null;

    // Group rows into sections based on accordion headers
    allRows.forEach(function (row) {
      if (row.classList.contains('dnxte-ncl-row--accordion-header')) {
        currentSection = {
          header: row,
          rows: [],
        };
        sections.push(currentSection);
      } else if (currentSection) {
        currentSection.rows.push(row);
      }
      // Rows before the first header are not grouped (always visible)
    });

    if (!sections.length) return;

    // Wrap each section's rows in a collapsible container
    sections.forEach(function (section, sectionIndex) {
      var headerEl = section.header;
      var sectionRows = section.rows;

      // Create a wrapper div for the section content
      var wrapper = document.createElement('div');
      wrapper.className = 'dnxte-ncl-accordion-section-content';

      // Move rows into the wrapper
      sectionRows.forEach(function (row) {
        wrapper.appendChild(row);
      });

      // Insert wrapper after the header row
      headerEl.parentNode.insertBefore(wrapper, headerEl.nextSibling);

      // Start collapsed (unless firstOpen and first section)
      if (firstOpen && sectionIndex === 0) {
        headerEl.classList.add('dnxte-ncl-row--section-open');
        wrapper.classList.add('dnxte-ncl-accordion-section-content--open');
      }

      // Store wrapper reference on the section object for reliable access
      section.wrapper = wrapper;

      // Click handler on the header
      headerEl.style.cursor = 'pointer';
      headerEl.addEventListener('click', function () {
        var isOpen = headerEl.classList.contains('dnxte-ncl-row--section-open');

        if (!allowMultiple) {
          // Close all other sections using stored wrapper references
          sections.forEach(function (s) {
            s.header.classList.remove('dnxte-ncl-row--section-open');
            if (s.wrapper) {
              s.wrapper.classList.remove('dnxte-ncl-accordion-section-content--open');
            }
          });
        }

        if (isOpen) {
          headerEl.classList.remove('dnxte-ncl-row--section-open');
          wrapper.classList.remove('dnxte-ncl-accordion-section-content--open');
        } else {
          headerEl.classList.add('dnxte-ncl-row--section-open');
          wrapper.classList.add('dnxte-ncl-accordion-section-content--open');
        }
      });
    });
  }

  /**
   * Row Accordion: Each row with a description expands/collapses its own description.
   */
  function initRowAccordion(body, allowMultiple, firstOpen) {
    var expandableRows = body.querySelectorAll('.dnxte-ncl-row--expandable');
    if (!expandableRows.length) return;

    var allRows = [];

    expandableRows.forEach(function (row, index) {
      var descEl = row.querySelector('.dnxte-ncl-row-description');
      if (!descEl) return;

      row.style.cursor = 'pointer';

      // Start collapsed (unless firstOpen and first row)
      if (firstOpen && index === 0) {
        row.classList.add('dnxte-ncl-row--open');
      }

      // Click handler on the entire row
      row.addEventListener('click', function (e) {
        // Don't toggle if clicking on a tooltip or link
        if (e.target.closest('.dnxte-ncl-tooltip, .dnxte-ncl-tooltip-icon, a')) return;

        var isOpen = row.classList.contains('dnxte-ncl-row--open');

        if (!allowMultiple) {
          // Close all other rows
          allRows.forEach(function (r) {
            r.classList.remove('dnxte-ncl-row--open');
          });
        }

        if (isOpen) {
          row.classList.remove('dnxte-ncl-row--open');
        } else {
          row.classList.add('dnxte-ncl-row--open');
        }
      });

      allRows.push(row);
    });
  }

  /**
   * Sticky header via position:fixed.
   *
   * CSS position:sticky breaks when ANY ancestor has overflow:hidden/auto (Divi
   * Section/Row/Column wrappers often do). position:fixed instead escapes those
   * clipping ancestors — it is positioned against the viewport — so it works even
   * when sticky cannot. While pinned the `top` is constant, so the browser keeps
   * it smooth via the compositor (no per-frame transform → no shake). A placeholder
   * preserves the row's space; width/left are matched to the placeholder so the
   * fixed header lines up perfectly with the columns below it.
   *
   * (Requires no transform-based smooth-scroll ancestor — those would re-anchor a
   * fixed element; that is a browser limitation.)
   */
  function initStickyHeader(container) {
    var list = container.querySelector('.comparison-list--sticky-header');
    if (!list) return;

    var table = list.querySelector('.dnxte-ncl-table');
    var header = list.querySelector('.dnxte-ncl-row--header');
    if (!table || !header) return;

    var offset = parseFloat(list.getAttribute('data-ncl-sticky-top')) || 0;
    var placeholder = null;
    var pinned = false;
    var ticking = false;
    var last = { top: null, left: null, width: null };

    function pin() {
      placeholder = document.createElement('div');
      placeholder.className = 'dnxte-ncl-header-placeholder';
      placeholder.style.height = header.offsetHeight + 'px';
      placeholder.setAttribute('aria-hidden', 'true');
      header.parentNode.insertBefore(placeholder, header);
      header.style.position = 'fixed';
      header.style.zIndex = '999';
      header.style.margin = '0';
      pinned = true;
    }

    function unpin() {
      header.style.position = '';
      header.style.top = '';
      header.style.left = '';
      header.style.width = '';
      header.style.zIndex = '';
      header.style.margin = '';
      if (placeholder && placeholder.parentNode) placeholder.parentNode.removeChild(placeholder);
      placeholder = null;
      pinned = false;
      last.top = last.left = last.width = null;
    }

    function update() {
      ticking = false;
      var tRect = table.getBoundingClientRect();
      var hHeight = pinned ? placeholder.offsetHeight : header.offsetHeight;
      var shouldPin = tRect.top < offset && tRect.bottom > offset;

      if (!shouldPin) {
        if (pinned) unpin();
        return;
      }

      if (!pinned) pin();

      // Constant `offset` while the table is well in view; slides up with the table
      // bottom near the end so the header releases smoothly instead of snapping.
      var top = Math.min(offset, Math.round(tRect.bottom - hHeight));
      var pRect = placeholder.getBoundingClientRect();
      var left = Math.round(pRect.left);
      var width = Math.round(pRect.width);

      // Only write when something actually changes (constant-top pin = zero writes
      // per frame → pure compositor → no jitter).
      if (top !== last.top) { header.style.top = top + 'px'; last.top = top; }
      if (left !== last.left) { header.style.left = left + 'px'; last.left = left; }
      if (width !== last.width) { header.style.width = width + 'px'; last.width = width; }
    }

    function onScroll() {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }

    // capture:true also catches scroll from nested scroll containers (custom scrollbars).
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onScroll);
    update();
  }

  /**
   * Tooltip auto-position: the preset tooltip sits to the RIGHT of the icon.
   * On hover we measure it and flip it (left → top → bottom) whenever the
   * chosen side would spill outside the viewport, so it stays fully visible.
   */
  function positionTooltip(tip) {
    var M = 8; // viewport safety margin (px)
    tip.classList.remove(
      'dnxte-ncl-tooltip--left',
      'dnxte-ncl-tooltip--top',
      'dnxte-ncl-tooltip--bottom'
    );

    var vw = window.innerWidth;
    var r = tip.getBoundingClientRect();

    // Default right side spills off the right edge → try the left side.
    if (r.right > vw - M) {
      tip.classList.add('dnxte-ncl-tooltip--left');
      r = tip.getBoundingClientRect();

      // Left also spills → put it above the icon.
      if (r.left < M) {
        tip.classList.remove('dnxte-ncl-tooltip--left');
        tip.classList.add('dnxte-ncl-tooltip--top');
        r = tip.getBoundingClientRect();

        // Above spills over the top → drop it below.
        if (r.top < M) {
          tip.classList.remove('dnxte-ncl-tooltip--top');
          tip.classList.add('dnxte-ncl-tooltip--bottom');
        }
      }
    }
  }

  function initTooltips(container) {
    var cells = container.querySelectorAll('.dnxte-ncl-cell--feature');
    cells.forEach(function (cell) {
      var tip = cell.querySelector('.dnxte-ncl-tooltip');
      if (!tip) return;
      cell.addEventListener('mouseenter', function () {
        positionTooltip(tip);
      });
    });
  }

  function init() {
    var containers = document.querySelectorAll('.dnxte_next_comparison_list');
    containers.forEach(function (container) {
      initComparisonList(container);
      initStickyHeader(container);
      initTooltips(container);
    });
  }

  // Initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
