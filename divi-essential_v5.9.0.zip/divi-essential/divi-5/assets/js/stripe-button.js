/**
 * Stripe Button Frontend Script
 * Handles Stripe Checkout button clicks
 */
(function() {
    'use strict';

    /**
     * Initialize quantity selectors
     */
    function initQuantitySelectors() {
        const quantityBtns = document.querySelectorAll('.dnxte-stripe-quantity-btn:not([data-qty-initialized])');

        quantityBtns.forEach(function(btn) {
            btn.dataset.qtyInitialized = 'true';

            btn.addEventListener('click', function(e) {
                e.preventDefault();

                const selector = btn.closest('.dnxte-stripe-quantity-selector');
                if (!selector) return;

                const input = selector.querySelector('.dnxte-stripe-quantity-value');
                if (!input) return;

                let currentValue = parseInt(input.value, 10) || 1;
                const minValue = parseInt(input.min, 10) || 1;
                const maxValue = parseInt(input.max, 10) || 99;
                const action = btn.dataset.action;

                if (action === 'decrease' && currentValue > minValue) {
                    currentValue--;
                } else if (action === 'increase' && currentValue < maxValue) {
                    currentValue++;
                }

                input.value = currentValue;

                // Trigger change event for any listeners
                input.dispatchEvent(new Event('change', { bubbles: true }));
            });
        });
    }

    /**
     * Initialize Stripe buttons
     */
    function initStripeButtons() {
        const buttons = document.querySelectorAll('.dnxte-stripe-button:not([disabled])');

        buttons.forEach(function(button) {
            // Skip if already initialized
            if (button.dataset.stripeInitialized) {
                return;
            }

            button.dataset.stripeInitialized = 'true';

            button.addEventListener('click', function(e) {
                e.preventDefault();
                handleStripeCheckout(button);
            });
        });
    }

    /**
     * Handle Stripe checkout
     * @param {HTMLElement} button - The clicked button element
     */
    function handleStripeCheckout(button) {
        // Get data attributes — only opaque IDs, no sensitive config.
        const checkoutId = button.dataset.checkoutId;
        const ajaxUrl = button.dataset.ajaxUrl;
        const nonce = button.dataset.nonce;
        const quantityInputId = button.dataset.quantityInput;

        // Get quantity from input
        let quantity = 1;
        if (quantityInputId) {
            const quantityInput = document.getElementById(quantityInputId);
            if (quantityInput) {
                quantity = parseInt(quantityInput.value, 10) || 1;
                // Ensure quantity is within valid range
                quantity = Math.max(1, Math.min(99, quantity));
            }
        }

        // Get wrapper for error/success messages
        const wrapper = button.closest('.dnxte-stripe-button-wrapper');
        const errorContainer = wrapper ? wrapper.querySelector('.dnxte-stripe-error') : null;
        const successContainer = wrapper ? wrapper.querySelector('.dnxte-stripe-success') : null;

        // Hide any previous messages
        if (errorContainer) {
            errorContainer.style.display = 'none';
            errorContainer.textContent = '';
        }
        if (successContainer) {
            successContainer.style.display = 'none';
            successContainer.textContent = '';
        }

        // Show loading state
        const originalText = button.querySelector('.dnxte-stripe-button__text');
        const originalTextContent = originalText ? originalText.textContent : '';
        if (originalText) {
            // Store original text for bfcache restoration
            button.dataset.originalText = originalTextContent;
            originalText.textContent = 'Processing...';
        }
        button.disabled = true;

        // Create form data — only send checkout ID, config stays server-side.
        const formData = new FormData();
        formData.append('action', 'dnxte_create_stripe_checkout');
        formData.append('nonce', nonce);
        formData.append('checkout_id', checkoutId);
        formData.append('quantity', quantity);

        // Send AJAX request
        fetch(ajaxUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success && data.data && data.data.checkout_url) {
                // Redirect to Stripe Checkout
                window.location.href = data.data.checkout_url;
            } else {
                // Show error message
                const errorMessage = data.data && data.data.message ? data.data.message : 'An error occurred. Please try again.';
                if (errorContainer) {
                    errorContainer.textContent = errorMessage;
                    errorContainer.style.display = 'block';
                } else {
                    alert(errorMessage);
                }

                // Reset button state
                if (originalText) {
                    originalText.textContent = originalTextContent;
                }
                button.disabled = false;
            }
        })
        .catch(function(error) {
            console.error('Stripe checkout error:', error);

            // Show error message
            const errorMessage = 'Failed to process payment. Please try again.';
            if (errorContainer) {
                errorContainer.textContent = errorMessage;
                errorContainer.style.display = 'block';
            } else {
                alert(errorMessage);
            }

            // Reset button state
            if (originalText) {
                originalText.textContent = originalTextContent;
            }
            button.disabled = false;
        });
    }

    /**
     * Initialize all components
     */
    function init() {
        initQuantitySelectors();
        initStripeButtons();
    }

    /**
     * Reset all buttons from processing state (e.g. after bfcache restore)
     */
    function resetAllButtons() {
        const buttons = document.querySelectorAll('.dnxte-stripe-button[disabled]');
        buttons.forEach(function(button) {
            button.disabled = false;
            var textEl = button.querySelector('.dnxte-stripe-button__text');
            if (textEl && textEl.textContent === 'Processing...') {
                var originalText = button.dataset.originalText;
                if (originalText) {
                    textEl.textContent = originalText;
                }
            }
            // Allow re-initialization
            button.removeAttribute('data-stripe-initialized');
        });
        // Re-init so click handlers are re-attached
        initStripeButtons();
    }

    // Reset button state when page is restored from bfcache (browser back/forward)
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            resetAllButtons();
        }
    });

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Re-initialize on dynamic content (for Divi Builder)
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function(mutations) {
            let shouldInit = false;
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1 && (
                            node.classList.contains('dnxte-stripe-button') ||
                            node.classList.contains('dnxte-stripe-quantity-btn') ||
                            node.querySelector('.dnxte-stripe-button') ||
                            node.querySelector('.dnxte-stripe-quantity-btn')
                        )) {
                            shouldInit = true;
                        }
                    });
                }
            });
            if (shouldInit) {
                init();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
})();
