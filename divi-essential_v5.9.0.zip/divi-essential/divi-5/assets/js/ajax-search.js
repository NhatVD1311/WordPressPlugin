(function () {
  'use strict';

  var STORAGE_KEY = 'dnxte_recent_searches';
  var MAX_RECENT  = 10;

  function getRecentSearches() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch (e) { return []; }
  }

  function saveRecentSearch(term) {
    term = (term || '').trim();
    if (!term) return;
    var recent = getRecentSearches().filter(function (r) { return r !== term; });
    recent.unshift(term);
    if (recent.length > MAX_RECENT) recent = recent.slice(0, MAX_RECENT);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(recent)); } catch (e) {}
  }

  function debounce(fn, delay) {
    var timer;
    return function () {
      var ctx = this, args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, delay);
    };
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str || ''));
    // A text node only escapes < > &, but the result of this helper is also placed
    // inside double-quoted attributes (src, alt, href), so quotes must be escaped
    // too — otherwise a post title can break out of the attribute it sits in.
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function attr(el, name) {
    return el ? el.getAttribute(name) || '' : '';
  }

  function isOn(val) { return val !== 'off'; }

  // Star rating HTML
  function renderStars(rating) {
    var html = '<span class="ajax_search__stars">';
    for (var i = 1; i <= 5; i++) {
      if (rating >= i) {
        html += '<span class="ajax_search__star is-full">&#9733;</span>';
      } else if (rating >= i - 0.5) {
        html += '<span class="ajax_search__star is-half">&#9733;</span>';
      } else {
        html += '<span class="ajax_search__star is-empty">&#9734;</span>';
      }
    }
    html += '</span>';
    return html;
  }

  function initAjaxSearch(module) {
    var inner    = module.querySelector('.ajax_search__inner');
    var input    = module.querySelector('.ajax_search__input');
    var panel    = module.querySelector('.ajax_search__dropdown-panel');
    var clearBtn = module.querySelector('.ajax_search__clear-btn');
    var overlay  = module.querySelector('.ajax_search__overlay');

    if (!input || !panel || !inner) return;

    var suggestedSection = panel.querySelector('.ajax_search__suggested-section');
    var recentSection    = panel.querySelector('.ajax_search__recent-section');
    var recentList       = panel.querySelector('.ajax_search__recent-list');
    var resultsWrapper   = panel.querySelector('.ajax_search__results-wrapper');
    var resultsCountEl   = panel.querySelector('.ajax_search__results-count');
    var seeAllEl         = panel.querySelector('.ajax_search__see-all');
    var autocorrectEl    = panel.querySelector('.ajax_search__autocorrect');
    var paginationEl     = panel.querySelector('.ajax_search__pagination');
    var loader           = panel.querySelector('.ajax_search__loader');
    var noResults        = panel.querySelector('.ajax_search__no-results');

    // Config from data attributes
    var postTypes      = attr(inner, 'data-post-types') || 'post,page';
    var minChars       = parseInt(attr(inner, 'data-min-chars'), 10) || 3;
    var perPage        = parseInt(attr(inner, 'data-per-page'), 10) || 5;
    var orderBy        = attr(inner, 'data-order-by') || 'date';
    var excerptLength  = attr(inner, 'data-excerpt-length') || '100';
    var imagePosition  = attr(inner, 'data-image-position') || 'left';
    var paginationStyle = attr(inner, 'data-pagination') || 'loadmore';
    var autoCorrect    = isOn(attr(inner, 'data-auto-correct'));
    var showImage      = isOn(attr(inner, 'data-show-image'));
    var showTitle      = isOn(attr(inner, 'data-show-title'));
    var showExcerpt    = isOn(attr(inner, 'data-show-excerpt'));
    var showCategory   = isOn(attr(inner, 'data-show-category'));
    var showDate       = isOn(attr(inner, 'data-show-date'));
    var showAuthor     = isOn(attr(inner, 'data-show-author'));
    var showPrice      = isOn(attr(inner, 'data-show-price'));
    var showRating     = isOn(attr(inner, 'data-show-rating'));
    var showSaleBadge  = isOn(attr(inner, 'data-show-sale-badge'));
    var showAddToCart  = isOn(attr(inner, 'data-show-add-to-cart'));
    var showCount      = isOn(attr(inner, 'data-show-count'));
    var showSeeAll     = isOn(attr(inner, 'data-show-see-all'));

    // Search field settings
    var searchTitle      = attr(inner, 'data-search-title') || 'on';
    var searchContent    = attr(inner, 'data-search-content') || 'on';
    var searchExcerpt    = attr(inner, 'data-search-excerpt') || 'on';
    var searchCategories = attr(inner, 'data-search-categories') || 'off';
    var searchTags       = attr(inner, 'data-search-tags') || 'off';
    var searchSku        = attr(inner, 'data-search-sku') || 'off';
    var searchMeta       = attr(inner, 'data-search-meta') || 'off';
    var excludeProductIds = attr(inner, 'data-exclude-product-ids') || '[]';
    var excludePostIds = attr(inner, 'data-exclude-post-ids') || '[]';
    var includePageIds = attr(inner, 'data-include-page-ids') || '[]';

    var currentXHR     = null;
    var currentPage    = 1;
    var totalPages     = 0;
    var currentQuery   = '';
    var activeCategory = '';
    var isSkin         = function (s) { return inner.classList.contains('ajax_search__skin--' + s); };

    // --- Category dropdown ---
    var catDropdown = module.querySelector('.ajax_search__category-dropdown');
    var catLabel    = module.querySelector('.ajax_search__category-label');
    var catList     = module.querySelector('.ajax_search__category-list');
    if (clearBtn) clearBtn.style.display = "none";

    if (catDropdown && catList) {
      // Move category list to body so it escapes any overflow:hidden ancestors
      document.body.appendChild(catList);

      function positionCatList() {
        var rect = catDropdown.getBoundingClientRect();
        catList.style.top = (rect.bottom + 4) + 'px';
        catList.style.left = rect.left + 'px';
      }

      catDropdown.addEventListener('click', function (e) {
        e.stopPropagation();
        var isOpen = catList.style.display !== 'none';
        if (isOpen) {
          catList.style.display = 'none';
        } else {
          positionCatList();
          catList.style.display = '';
        }
      });

      var catItems = catList.querySelectorAll('.ajax_search__category-item');
      for (var ci = 0; ci < catItems.length; ci++) {
        catItems[ci].addEventListener('click', function (e) {
          e.stopPropagation();
          var cat = this.getAttribute('data-category');
          activeCategory = (cat === 'All' || cat === catItems[0].getAttribute('data-category')) ? '' : cat;
          if (catLabel) catLabel.textContent = cat;

          // Update active state
          for (var k = 0; k < catItems.length; k++) catItems[k].classList.remove('is-active');
          this.classList.add('is-active');
          catList.style.display = 'none';

          // Re-search if there's a query
          if (input.value.trim().length >= minChars) {
            currentPage = 1;
            performSearch(input.value, false);
          }
        });
      }

      // Close category list when clicking outside
      document.addEventListener('click', function () {
        catList.style.display = 'none';
      });
    }

    // --- Modal: create fixed modal on body ---
    var modalEl = null;
    var modalOverlay = null;
    var modalBody = null;
    var modalOpen = false;
    if (isSkin('modal')) {
      var searchBar = inner.querySelector('.ajax_search__search-bar');


      modalEl = document.createElement('div');
      modalEl.className = 'ajax_search__modal';
      modalEl.style.display = 'none';

      modalOverlay = document.createElement('div');
      modalOverlay.className = 'ajax_search__modal-overlay';

      modalBody = document.createElement('div');
      modalBody.className = 'ajax_search__modal-body';

      // Clone search bar for modal, move panel
      var modalSearchBar = searchBar.cloneNode(true);
      var modalInput = modalSearchBar.querySelector('.ajax_search__input');
      modalInput.removeAttribute('readonly');

      // Sync modal input → triggers search via original input reference
      modalInput.addEventListener('input', function () {
        input.value = modalInput.value;
        if (modalInput.value.trim().length === 0) {
          showIdleState();
          if (clearBtn) clearBtn.style.display = "none";
        } else if (modalInput.value.trim().length >= minChars) {
          currentPage = 1;
          performSearch(modalInput.value, false);
          if (clearBtn) clearBtn.style.display = "block";

        }
      });
      modalInput.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closePanel(); }
        if (e.key === 'Enter') {
          e.preventDefault();
          var val = modalInput.value.trim();
          if (val) {
            saveRecentSearch(val);
            currentPage = 1;
            performSearch(val, false);
          }
        }
      });

      // Modal clear button
      var modalClearBtn = modalSearchBar.querySelector('.ajax_search__clear-btn');
      if (modalClearBtn) {
        modalClearBtn.addEventListener('click', function () {
          modalInput.value = '';
          input.value = '';
          showIdleState();
          modalInput.focus();
        });
      }

      modalBody.appendChild(modalSearchBar);
      modalBody.appendChild(panel);

      modalEl.appendChild(modalOverlay);
      modalEl.appendChild(modalBody);
      document.body.appendChild(modalEl);

      modalOverlay.addEventListener('click', function () { closePanel(); });

    }

    // --- Panel open / close ---
    function openPanel() {
      panel.classList.add('is-active');
      if (overlay) overlay.style.display = '';
      if (isSkin('modal') && modalEl && !modalOpen) {
        modalOpen = true;
        modalEl.style.display = '';
        document.body.style.overflow = 'hidden';
        setTimeout(function () { input.focus(); }, 50);
      }
    }

    function closePanel() {
      panel.classList.remove('is-active');
      if (overlay) overlay.style.display = 'none';
      if (isSkin('modal') && modalEl) {
        modalOpen = false;
        modalEl.style.display = 'none';
        document.body.style.overflow = '';
      }
    }

    // --- Section visibility ---
    function showIdleState() {
      if (suggestedSection) suggestedSection.style.display = '';
      renderRecentSection();
      if (resultsWrapper) resultsWrapper.style.display = 'none';
      if (resultsCountEl) resultsCountEl.style.display = 'none';
      if (seeAllEl) seeAllEl.style.display = 'none';
      if (autocorrectEl) autocorrectEl.style.display = 'none';
      if (paginationEl) paginationEl.style.display = 'none';
      if (loader) loader.style.display = 'none';
      if (noResults) noResults.style.display = 'none';
    }

    function showSearchState() {
      if (suggestedSection) suggestedSection.style.display = 'none';
      if (recentSection) recentSection.style.display = 'none';
    }

    // --- Recent searches ---
    function renderRecentSection() {
      if (!recentSection || !recentList) return;
      var recent = getRecentSearches();
      if (recent.length === 0) { recentSection.style.display = 'none'; return; }
      recentSection.style.display = '';
      var html = '';
      for (var i = 0; i < recent.length; i++) {
        html += '<div class="ajax_search__recent-item">'
          + '<svg class="ajax_search__recent-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
          + '<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/>'
          + '<path d="M12 7V12L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
          + '</svg>'
          + '<span class="ajax_search__recent-text">' + escapeHtml(recent[i]) + '</span>'
          + '</div>';
      }
      recentList.innerHTML = html;
      var items = recentList.querySelectorAll('.ajax_search__recent-item');
      for (var j = 0; j < items.length; j++) {
        items[j].addEventListener('click', function () {
          var text = this.querySelector('.ajax_search__recent-text');
          if (text) { input.value = text.textContent; performSearch(text.textContent, false); }
        });
      }
    }

    // --- Render results ---
    function renderResults(data, append) {
      var results = data.results || [];
      var total   = data.total || 0;
      totalPages  = data.pages || 0;

      if (loader) loader.style.display = 'none';

      if (results.length === 0 && !append) {
        if (resultsWrapper) resultsWrapper.style.display = 'none';
        if (noResults) noResults.style.display = '';
        if (resultsCountEl) resultsCountEl.style.display = 'none';
        if (seeAllEl) seeAllEl.style.display = 'none';
        if (paginationEl) paginationEl.style.display = 'none';

        // Autocorrect suggestion
        if (autocorrectEl && data.suggestion) {
          autocorrectEl.innerHTML = 'Did you mean: <a class="ajax_search__autocorrect-link" href="#">' + escapeHtml(data.suggestion) + '</a>?';
          autocorrectEl.style.display = '';
          var link = autocorrectEl.querySelector('.ajax_search__autocorrect-link');
          if (link) {
            link.addEventListener('click', function (e) {
              e.preventDefault();
              input.value = data.suggestion;
              performSearch(data.suggestion, false);
            });
          }
        }
        return;
      }

      if (noResults) noResults.style.display = 'none';
      if (autocorrectEl) autocorrectEl.style.display = 'none';
      if (resultsWrapper) resultsWrapper.style.display = '';

      // Results count
      if (resultsCountEl && showCount) {
        resultsCountEl.textContent = total + ' result' + (total !== 1 ? 's' : '') + ' found';
        resultsCountEl.style.display = '';
      }

      // See all link (hide when pagination is active)
      if (seeAllEl && showSeeAll && total > perPage && paginationStyle === 'none') {
        seeAllEl.href = '/?s=' + encodeURIComponent(currentQuery);
        seeAllEl.textContent = 'See all ' + total + ' results';
        seeAllEl.style.display = '';
      } else if (seeAllEl) {
        seeAllEl.style.display = 'none';
      }

      var html = '';
      for (var i = 0; i < results.length; i++) {
        var r = results[i];
        html += '<a href="' + escapeHtml(r.url) + '" class="ajax_search__result-item">';

        // Image
        if (showImage && imagePosition !== 'hidden' && r.image) {
          html += '<img class="ajax_search__result-image" src="' + escapeHtml(r.image) + '" alt="' + escapeHtml(r.title) + '" loading="lazy" />';
        }

        html += '<div class="ajax_search__result-content">';

        // Title
        if (showTitle) {
          html += '<div class="ajax_search__result-title">' + escapeHtml(r.title) + '</div>';
        }

        // Excerpt
        if (showExcerpt && r.excerpt) {
          html += '<div class="ajax_search__result-excerpt">' + escapeHtml(r.excerpt) + '</div>';
        }

        // Meta row
        var metaParts = [];

        // Date
        if (showDate && r.date) {
          metaParts.push('<span class="ajax_search__result-date">' + escapeHtml(r.date) + '</span>');
        }

        // Author
        if (showAuthor && r.author) {
          metaParts.push('<span class="ajax_search__result-author">by ' + escapeHtml(r.author) + '</span>');
        }

        // Price
        if (showPrice && r.price) {
          metaParts.push('<span class="ajax_search__result-price">' + r.price + '</span>');
        }

        // Rating
        if (showRating && r.rating && r.rating > 0) {
          metaParts.push(renderStars(r.rating));
        }

        // Sale badge
        if (showSaleBadge && r.onSale) {
          metaParts.push('<span class="ajax_search__sale-badge">Sale!</span>');
        }

        // Category badge
        if (showCategory && r.category) {
          metaParts.push('<span class="ajax_search__result-badge">' + escapeHtml(r.category) + '</span>');
        }

        // Add to cart button
        if (showAddToCart && r.addToCartUrl) {
          metaParts.push('<button type="button" class="ajax_search__add-to-cart" data-url="' + escapeHtml(r.addToCartUrl) + '" onclick="event.preventDefault();event.stopPropagation();window.location.href=this.dataset.url">' + escapeHtml(r.addToCartText || 'Add to cart') + '</button>');
        }

        if (metaParts.length > 0) {
          html += '<div class="ajax_search__result-meta">' + metaParts.join('') + '</div>';
        }

        html += '</div>'; // result-content
        html += '</a>'; // result-item
      }

      if (append && resultsWrapper) {
        resultsWrapper.insertAdjacentHTML('beforeend', html);
      } else if (resultsWrapper) {
        resultsWrapper.innerHTML = html;
      }

      // Pagination
      renderPagination();
    }

    // --- Pagination ---
    function renderPagination() {
      if (!paginationEl || paginationStyle === 'none') return;
      if (currentPage >= totalPages) {
        paginationEl.style.display = 'none';
        return;
      }
      paginationEl.style.display = '';

      if (paginationStyle === 'loadmore') {
        paginationEl.innerHTML = '<button class="ajax_search__load-more" type="button">Load More</button>';
        paginationEl.querySelector('.ajax_search__load-more').addEventListener('click', function () {
          currentPage++;
          performSearch(currentQuery, true);
        });
      } else if (paginationStyle === 'prevnext') {
        var html = '<div class="ajax_search__prevnext">';
        if (currentPage > 1) {
          html += '<button class="ajax_search__prev-btn" type="button">&laquo; Previous</button>';
        }
        html += '<span class="ajax_search__page-info">Page ' + currentPage + ' of ' + totalPages + '</span>';
        if (currentPage < totalPages) {
          html += '<button class="ajax_search__next-btn" type="button">Next &raquo;</button>';
        }
        html += '</div>';
        paginationEl.innerHTML = html;

        var prevBtn = paginationEl.querySelector('.ajax_search__prev-btn');
        var nextBtn = paginationEl.querySelector('.ajax_search__next-btn');
        if (prevBtn) prevBtn.addEventListener('click', function () { currentPage--; performSearch(currentQuery, false); });
        if (nextBtn) nextBtn.addEventListener('click', function () { currentPage++; performSearch(currentQuery, false); });
      } else if (paginationStyle === 'numbered') {
        var numHtml = '<div class="ajax_search__numbered">';
        for (var p = 1; p <= totalPages; p++) {
          var activeClass = p === currentPage ? ' is-active' : '';
          numHtml += '<button class="ajax_search__page-num' + activeClass + '" type="button" data-page="' + p + '">' + p + '</button>';
        }
        numHtml += '</div>';
        paginationEl.innerHTML = numHtml;

        var numBtns = paginationEl.querySelectorAll('.ajax_search__page-num');
        for (var nb = 0; nb < numBtns.length; nb++) {
          numBtns[nb].addEventListener('click', function () {
            currentPage = parseInt(this.getAttribute('data-page'), 10);
            performSearch(currentQuery, false);
          });
        }
      } else if (paginationStyle === 'infinite') {
        // Set up IntersectionObserver sentinel
        paginationEl.innerHTML = '<div class="ajax_search__sentinel"></div>';
        var sentinel = paginationEl.querySelector('.ajax_search__sentinel');
        if ('IntersectionObserver' in window && sentinel) {
          var observer = new IntersectionObserver(function (entries) {
            if (entries[0].isIntersecting && currentPage < totalPages) {
              currentPage++;
              performSearch(currentQuery, true);
            }
          }, { threshold: 0.1 });
          observer.observe(sentinel);
        }
      }
    }

    // --- AJAX search ---
    function performSearch(query, append) {
      query = (query || '').trim();
      currentQuery = query;

      if (query.length < minChars) {
        showIdleState();
        openPanel();
        return;
      }

      if (currentXHR) { currentXHR.abort(); currentXHR = null; }

      showSearchState();
      if (!append) {
        if (loader) loader.style.display = '';
        if (resultsWrapper) resultsWrapper.style.display = 'none';
      }
      if (noResults) noResults.style.display = 'none';
      if (autocorrectEl) autocorrectEl.style.display = 'none';
      if (!isSkin('modal')) openPanel();

      var url = dnxteAjaxSearch.ajaxUrl
        + '?action=dnxte_ajax_search'
        + '&nonce=' + encodeURIComponent(dnxteAjaxSearch.nonce)
        + '&q=' + encodeURIComponent(query)
        + '&post_types=' + encodeURIComponent(postTypes)
        + '&per_page=' + encodeURIComponent(perPage)
        + '&page=' + encodeURIComponent(currentPage)
        + '&order_by=' + encodeURIComponent(orderBy)
        + '&excerpt_length=' + encodeURIComponent(excerptLength)
        + '&search_title=' + encodeURIComponent(searchTitle)
        + '&search_content=' + encodeURIComponent(searchContent)
        + '&search_excerpt=' + encodeURIComponent(searchExcerpt)
        + '&search_categories=' + encodeURIComponent(searchCategories)
        + '&search_tags=' + encodeURIComponent(searchTags)
        + '&search_sku=' + encodeURIComponent(searchSku)
        + '&search_meta=' + encodeURIComponent(searchMeta)
        + '&exclude_product_ids=' + encodeURIComponent(excludeProductIds)
        + '&exclude_post_ids=' + encodeURIComponent(excludePostIds)
        + '&include_page_ids=' + encodeURIComponent(includePageIds)
        + '&auto_correct=' + encodeURIComponent(autoCorrect ? 'on' : 'off');

      if (activeCategory) {
        url += '&category=' + encodeURIComponent(activeCategory);
      }

      var xhr = new XMLHttpRequest();
      currentXHR = xhr;
      xhr.open('GET', url, true);
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

      xhr.onload = function () {
        currentXHR = null;
        if (xhr.status === 200) {
          try {
            var response = JSON.parse(xhr.responseText);
            if (response.success && response.data) {
              renderResults(response.data, append);
              openPanel();
            } else {
              renderResults({ results: [], total: 0, pages: 0 }, false);
              openPanel();
            }
          } catch (e) {
            renderResults({ results: [], total: 0, pages: 0 }, false);
            openPanel();
          }
        } else {
          renderResults({ results: [], total: 0, pages: 0 }, false);
          openPanel();
        }
      };

      xhr.onerror = function () {
        currentXHR = null;
        if (loader) loader.style.display = 'none';
        renderResults({ results: [], total: 0, pages: 0 }, false);
      };

      xhr.send();
    }

    var debouncedSearch = debounce(function () {
      currentPage = 1;
      performSearch(input.value, false);
    }, 300);

    // Prevent panel opening on browser focus restoration during page reload.
    var initReady = false;
    setTimeout(function () { initReady = true; }, 300);

    // --- Event listeners ---
    input.addEventListener('focus', function () {
      if (!initReady) return;
      if (isSkin('modal')) return;
      if (input.value.trim().length >= minChars) {
        performSearch(input.value, false);
      } else if (input.value.trim().length > 0) {
        showIdleState();
        openPanel();
      }
    });

    input.addEventListener('input', function () {
      if (input.value.trim().length === 0) {
        if (clearBtn) clearBtn.style.display = "none";
        showIdleState();
        closePanel();
      } else if (input.value.trim().length < minChars) {
        showIdleState();
        if (!isSkin('modal')) openPanel();
      } else {
        debouncedSearch();
        if (clearBtn) clearBtn.style.display = "block";

      }
    });

    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        var val = input.value.trim();
        if (val) {
          saveRecentSearch(val);
          currentPage = 1;
          performSearch(val, false);
        }
      }
      if (e.key === 'Escape') {
        closePanel();
        input.blur();
      }
    });

    // Click outside closes panel
    document.addEventListener('click', function (e) {
      if (modalBody && modalBody.contains(e.target)) return;
      if (!inner.contains(e.target)) { closePanel(); }
    });

    // Overlay click closes panel
    if (overlay) {
      overlay.addEventListener('click', closePanel);
    }

    // Clear button
    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        input.value = '';
        currentPage = 1;
        showIdleState();
        closePanel();
        input.focus();
      });
    }

    // Suggested tag click
    var tags = panel.querySelectorAll('.ajax_search__tag');
    for (var i = 0; i < tags.length; i++) {
      tags[i].addEventListener('click', function () {
        input.value = this.textContent;
        saveRecentSearch(this.textContent);
        currentPage = 1;
        performSearch(this.textContent, false);
      });
    }

    // Voice search
    var voiceBtn = module.querySelector('.ajax_search__voice-btn');
    if (voiceBtn) {
      var hasSpeechAPI = ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);
      var isSecure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';

      if (hasSpeechAPI && isSecure) {
        voiceBtn.addEventListener('click', function () {
          var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
          var recognition = new SpeechRecognition();
          recognition.lang = document.documentElement.lang || 'en-US';
          recognition.interimResults = false;
          recognition.maxAlternatives = 1;
          recognition.continuous = false;

          voiceBtn.classList.add('is-listening');

          recognition.onresult = function (event) {
            var transcript = event.results[0][0].transcript;
            input.value = transcript;
            saveRecentSearch(transcript);
            currentPage = 1;
            performSearch(transcript, false);
            voiceBtn.classList.remove('is-listening');
          };

          recognition.onerror = function (e) {
            voiceBtn.classList.remove('is-listening');
            if (e.error === 'not-allowed') {
              alert('Microphone access denied. Please allow microphone permission in your browser settings.');
            } else if (e.error === 'no-speech') {
              // Silent - user just didn't speak
            } else {
              alert('Voice search error: ' + e.error);
            }
          };

          recognition.onend = function () {
            voiceBtn.classList.remove('is-listening');
          };

          try {
            recognition.start();
          } catch (e) {
            voiceBtn.classList.remove('is-listening');
            alert('Voice search is not available. Please use HTTPS or check browser support.');
          }
        });
      } else {
        // Hide voice button if not supported
        voiceBtn.style.display = 'none';
      }
    }

    // Remove readOnly so user can type on frontend
    input.removeAttribute('readonly');

    // Initial render of recent section
    renderRecentSection();
  }

  function init() {
    var modules = document.querySelectorAll('.ajax_search');
    for (var i = 0; i < modules.length; i++) {
      initAjaxSearch(modules[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
