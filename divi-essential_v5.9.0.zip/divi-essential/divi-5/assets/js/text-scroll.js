/**
 * ============================================
 * SCROLL TEXT ANIMATION - DIVI MODULE
 * Pure Vanilla JS - No external dependencies
 * Version: 3.0.0 - Per-span viewport progress
 * ============================================
 */
(function () {
  "use strict";

  // ============================================
  // CONFIGURATION & CONSTANTS
  // ============================================
  var CONFIG = {
    defaultScrollStart: 100, // Bottom of viewport (%)
    defaultScrollEnd: 20, // 20% from top (%)
    defaultSpeed: "normal",
    defaultEffect: "fade",
    defaultSplit: "word",
    defaultStartColor: "#999999",
    defaultEndColor: "#ffffff",
    defaultEasing: "ease-out",
    defaultStagger: 0,
    defaultDelay: 0,
    defaultDuration: 1,
    defaultDirection: "normal",
    defaultBlurAmount: 10,
    defaultSlideDistance: 50,
    defaultScaleStart: 0.5,
    defaultRotateAngle: 180,
    defaultPerspective: 1000,
    defaultOrigin: "center center",
  };

  // Cache for DOM elements and their configurations
  var elementsCache = new Map();

  // Track animation states for events
  var animationStates = new Map();

  // Track if initialized
  var isInitialized = false;

  // MutationObserver instance
  var observer = null;

  // rAF ID for scroll
  var rafId = 0;

  // ============================================
  // EASING FUNCTIONS
  // ============================================
  var EASING = {
    linear: function (t) {
      return t;
    },

    "ease-in": function (t) {
      return t * t;
    },

    "ease-out": function (t) {
      return t * (2 - t);
    },

    "ease-in-out": function (t) {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    },

    "ease-in-cubic": function (t) {
      return t * t * t;
    },

    "ease-out-cubic": function (t) {
      return --t * t * t + 1;
    },

    "ease-in-out-cubic": function (t) {
      return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
    },

    "ease-in-quart": function (t) {
      return t * t * t * t;
    },

    "ease-out-quart": function (t) {
      return 1 - --t * t * t * t;
    },

    "ease-in-out-quart": function (t) {
      return t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t;
    },

    "ease-in-expo": function (t) {
      return t === 0 ? 0 : Math.pow(2, 10 * (t - 1));
    },

    "ease-out-expo": function (t) {
      return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
    },

    "ease-in-out-expo": function (t) {
      if (t === 0 || t === 1) return t;
      if (t < 0.5) return Math.pow(2, 20 * t - 10) / 2;
      return (2 - Math.pow(2, -20 * t + 10)) / 2;
    },

    bounce: function (t) {
      var n1 = 7.5625;
      var d1 = 2.75;
      if (t < 1 / d1) {
        return n1 * t * t;
      } else if (t < 2 / d1) {
        return n1 * (t -= 1.5 / d1) * t + 0.75;
      } else if (t < 2.5 / d1) {
        return n1 * (t -= 2.25 / d1) * t + 0.9375;
      } else {
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
      }
    },

    elastic: function (t) {
      if (t === 0 || t === 1) return t;
      return -Math.pow(2, 10 * (t - 1)) * Math.sin((t - 1.1) * 5 * Math.PI);
    },

    "elastic-out": function (t) {
      if (t === 0 || t === 1) return t;
      return Math.pow(2, -10 * t) * Math.sin((t - 0.1) * 5 * Math.PI) + 1;
    },

    "back-in": function (t) {
      var s = 1.70158;
      return t * t * ((s + 1) * t - s);
    },

    "back-out": function (t) {
      var s = 1.70158;
      return --t * t * ((s + 1) * t + s) + 1;
    },

    "back-in-out": function (t) {
      var s = 1.70158 * 1.525;
      if ((t *= 2) < 1) return 0.5 * (t * t * ((s + 1) * t - s));
      return 0.5 * ((t -= 2) * t * ((s + 1) * t + s) + 2);
    },
  };

  // ============================================
  // HELPER FUNCTIONS
  // ============================================

  /**
   * Debounce function
   */
  function debounce(func, delay) {
    var timeoutId;
    return function () {
      var args = arguments;
      var context = this;
      clearTimeout(timeoutId);
      timeoutId = setTimeout(function () {
        func.apply(context, args);
      }, delay);
    };
  }

  /**
   * Convert hex color to RGB object
   */
  function hexToRgb(hex) {
    hex = hex.replace(/^#/, "");
    if (hex.length === 3) {
      hex = hex
        .split("")
        .map(function (char) {
          return char + char;
        })
        .join("");
    }
    var result = /^([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16),
        }
      : { r: 153, g: 153, b: 153 };
  }

  /**
   * Convert RGB values to CSS rgb() string
   */
  function rgbToString(r, g, b) {
    return (
      "rgb(" + Math.round(r) + ", " + Math.round(g) + ", " + Math.round(b) + ")"
    );
  }

  /**
   * Interpolate between two colors based on progress
   */
  function interpolateColor(color1, color2, progress) {
    var r = color1.r + (color2.r - color1.r) * progress;
    var g = color1.g + (color2.g - color1.g) * progress;
    var b = color1.b + (color2.b - color1.b) * progress;
    return rgbToString(r, g, b);
  }

  /**
   * Clamp a value between min and max
   */
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  /**
   * Parse effect string to handle combined effects
   */
  function parseEffects(effectString) {
    return effectString.split("+").map(function (e) {
      return e.trim();
    });
  }

  // ============================================
  // TEXT SPLITTING FUNCTION
  // ============================================

  /**
   * Split text content into wrapped spans
   */
  function splitText(element, splitType) {
    var text = element.textContent.trim();
    var spans = [];

    // Store original text for accessibility
    element.setAttribute("aria-label", text);
    element.innerHTML = "";

    if (splitType === "word") {
      var words = text.split(/\s+/);
      words.forEach(function (word, index) {
        var span = document.createElement("span");
        span.className = "scroll-text-span";
        span.textContent = word;
        span.setAttribute("data-index", index);
        span.setAttribute("aria-hidden", "true");
        element.appendChild(span);
        spans.push(span);

        if (index < words.length - 1) {
          element.appendChild(document.createTextNode(" "));
        }
      });
    } else if (splitType === "letter") {
      var characters = text.split("");
      var charIndex = 0;

      characters.forEach(function (char) {
        if (char === " ") {
          var spaceSpan = document.createElement("span");
          spaceSpan.className = "scroll-text-span space";
          spaceSpan.innerHTML = "&nbsp;";
          spaceSpan.setAttribute("data-index", charIndex);
          spaceSpan.setAttribute("aria-hidden", "true");
          element.appendChild(spaceSpan);
          spans.push(spaceSpan);
        } else {
          var span = document.createElement("span");
          span.className = "scroll-text-span";
          span.textContent = char;
          span.setAttribute("data-index", charIndex);
          span.setAttribute("aria-hidden", "true");
          element.appendChild(span);
          spans.push(span);
        }
        charIndex++;
      });
    } else if (splitType === "line") {
      var lines = text.split(/\n/).filter(function (line) {
        return line.trim();
      });
      if (lines.length === 0) lines = [text];
      lines.forEach(function (line, index) {
        var span = document.createElement("span");
        span.className = "scroll-text-span scroll-text-line";
        span.textContent = line.trim();
        span.setAttribute("data-index", index);
        span.setAttribute("aria-hidden", "true");
        element.appendChild(span);
        spans.push(span);

        if (index < lines.length - 1) {
          element.appendChild(document.createElement("br"));
        }
      });
    }

    return spans;
  }

  // ============================================
  // SPEED & TIMING CONTROL
  // ============================================

  /**
   * Calculate speed multiplier based on speed type
   */
  function calculateSpeedMultiplier(speedType) {
    var speeds = {
      "ultra-slow": 0.25,
      slow: 0.5,
      normal: 1.0,
      fast: 1.5,
      "ultra-fast": 2.5,
    };
    return speeds[speedType] || 1.0;
  }

  /**
   * Apply easing function to progress
   */
  function applyEasing(progress, easingName) {
    var easingFn = EASING[easingName] || EASING.linear;
    return easingFn(progress);
  }

  // ============================================
  // PER-SPAN VIEWPORT-BASED PROGRESS
  // ============================================

  /**
   * Calculate per-span progress based on each span's own viewport position.
   * This fixes long text — each span animates as it scrolls into view.
   */
  function calculateSpanViewportProgress(span, index, totalSpans, config) {
    var rect = span.getBoundingClientRect();
    var windowHeight = window.innerHeight;

    var scrollStart = (windowHeight * (config.scrollStart || CONFIG.defaultScrollStart)) / 100;
    var scrollEnd = (windowHeight * (config.scrollEnd || CONFIG.defaultScrollEnd)) / 100;

    var spanTop = rect.top;

    // Span below start trigger — not yet visible
    if (spanTop > scrollStart) return 0;
    // Span above end trigger — fully animated
    if (spanTop < scrollEnd) return 1;

    // Base progress from span's own viewport position
    var baseProgress = (scrollStart - spanTop) / (scrollStart - scrollEnd);

    // Apply speed multiplier
    var speedMultiplier = config.speedMultiplier || 1;
    var duration = config.duration || 1;
    var speedAdjusted = clamp(baseProgress * speedMultiplier * duration, 0, 1);

    // Apply direction-based delay
    var direction = config.direction || "normal";
    var stagger = (config.stagger || 0) / 1000;

    var delayFactor = 0;
    if (direction === "reverse") {
      delayFactor = (totalSpans - 1 - index) / totalSpans;
    } else if (direction === "center-out") {
      var center = (totalSpans - 1) / 2;
      delayFactor = center > 0 ? Math.abs(index - center) / center : 0;
    } else if (direction === "edges-in") {
      var center2 = (totalSpans - 1) / 2;
      delayFactor = center2 > 0 ? 1 - Math.abs(index - center2) / center2 : 0;
    } else if (direction === "alternate") {
      delayFactor = index % 2 === 0 ? 0 : 0.5;
    } else if (direction === "random") {
      delayFactor = ((index * 7 + 3) % totalSpans) / totalSpans;
    }

    var delay = delayFactor * (0.3 + stagger);
    var denominator = 1 - delay;
    var adjustedProgress = denominator > 0
      ? (speedAdjusted - delay) / denominator
      : speedAdjusted;

    return clamp(adjustedProgress, 0, 1);
  }

  // ============================================
  // GHOST COLOR HELPER
  // Applies ghost color when span is not fully animated.
  // ============================================

  function applyGhostColor(span, p, config) {
    if (!config.ghostColor) return;
    if (p >= 1) {
      span.style.color = "";
      return;
    }
    // Cache parsed colors on first call
    if (!config._ghostRgb) {
      config._ghostRgb = hexToRgb(config.ghostColor);
      // Read the inherited CSS font color (temporarily clear inline color)
      var saved = span.style.color;
      span.style.color = "";
      var computed = window.getComputedStyle(span).color;
      span.style.color = saved;
      var match = computed.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      config._normalRgb = match
        ? { r: parseInt(match[1]), g: parseInt(match[2]), b: parseInt(match[3]) }
        : { r: 255, g: 255, b: 255 };
    }
    // Smoothly blend from ghost color → normal CSS color as p goes 0 → 1
    span.style.color = interpolateColor(config._ghostRgb, config._normalRgb, p);
  }

  // ============================================
  // ANIMATION EFFECT ENGINES
  // Each effect receives (spans, config) and calculates
  // per-span progress from viewport position.
  // ============================================

  function applyFadeEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.opacity = clamp(0.1 + p * 0.9, 0.1, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyBlurEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var blurAmount = config.blurAmount || CONFIG.defaultBlurAmount;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.filter = "blur(" + (blurAmount * (1 - p)) + "px)";
      span.style.opacity = clamp(0.3 + p * 0.7, 0.3, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyColorFillEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var startRgb = hexToRgb(config.startColor || CONFIG.defaultStartColor);
    var endRgb = hexToRgb(config.endColor || CONFIG.defaultEndColor);

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.color = interpolateColor(startRgb, endRgb, p);
    });
  }

  function applySlideUpEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "translateY(" + (slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applySlideDownEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "translateY(" + (-slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applySlideLeftEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "translateX(" + (slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applySlideRightEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "translateX(" + (-slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyScaleEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var scaleStart = config.scaleStart || CONFIG.defaultScaleStart;
    var origin = config.origin || CONFIG.defaultOrigin;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transformOrigin = origin;
      span.style.transform = "scale(" + (scaleStart + (1 - scaleStart) * p) + ")";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyRotateEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var rotateAngle = config.rotateAngle || CONFIG.defaultRotateAngle;
    var origin = config.origin || CONFIG.defaultOrigin;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transformOrigin = origin;
      span.style.transform = "rotate(" + (rotateAngle * (1 - p)) + "deg)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyFlipEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var perspective = config.perspective || CONFIG.defaultPerspective;
    var origin = config.origin || CONFIG.defaultOrigin;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transformOrigin = origin;
      span.style.transform =
        "perspective(" + perspective + "px) rotateX(" + (90 * (1 - p)) + "deg)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyFlipYEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var perspective = config.perspective || CONFIG.defaultPerspective;
    var origin = config.origin || CONFIG.defaultOrigin;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transformOrigin = origin;
      span.style.transform =
        "perspective(" + perspective + "px) rotateY(" + (90 * (1 - p)) + "deg)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyWaveEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || 20;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      var waveOffset = Math.sin(
        (index / totalSpans) * Math.PI * 2 + p * Math.PI * 4
      );
      var translateY = slideDistance * waveOffset * (1 - p);

      span.style.transform = "translateY(" + translateY + "px)";
      span.style.opacity = clamp(0.3 + p * 0.7, 0.3, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyTypewriterEffect(spans, config) {
    var totalSpans = spans.length;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      var isVisible = p > 0.5;

      span.style.opacity = isVisible ? 1 : 0;
      span.style.visibility = isVisible ? "visible" : "hidden";
      applyGhostColor(span, p, config);
    });
  }

  function applyGlowEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var endColor = config.endColor || "#00ffff";

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      var glowIntensity = p * 20;

      span.style.textShadow =
        "0 0 " + glowIntensity + "px " + endColor +
        ", 0 0 " + (glowIntensity * 2) + "px " + endColor;
      span.style.opacity = clamp(0.3 + p * 0.7, 0.3, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyDepthEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var perspective = config.perspective || CONFIG.defaultPerspective;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform =
        "perspective(" + perspective + "px) translateZ(" + (-100 * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyBounceInEffect(spans, config) {
    var totalSpans = spans.length;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = EASING.bounce(p);

      span.style.transform =
        "translateY(" + (slideDistance * (1 - p)) + "px) scale(" + (0.5 + p * 0.5) + ")";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyElasticEffect(spans, config) {
    var totalSpans = spans.length;
    var slideDistance = config.slideDistance || CONFIG.defaultSlideDistance;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = EASING["elastic-out"](p);

      span.style.transform = "translateX(" + (slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(Math.min(1, p + 0.2), 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyGradientSweepEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var startColor = config.startColor || "#667eea";
    var endColor = config.endColor || "#764ba2";

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      var gradientPosition = p * 100;
      span.style.background =
        "linear-gradient(90deg, " + endColor + " " + gradientPosition +
        "%, " + startColor + " " + gradientPosition + "%)";
      span.style.backgroundClip = "text";
      span.style.webkitBackgroundClip = "text";
      span.style.webkitTextFillColor = "transparent";
      span.style.color = "transparent";
    });
  }

  function applySkewEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var rotateAngle = config.rotateAngle || 30;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "skewX(" + (rotateAngle * (1 - p)) + "deg)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applySpiralEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var rotateAngle = config.rotateAngle || 360;
    var slideDistance = config.slideDistance || 50;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform =
        "rotate(" + (rotateAngle * (1 - p)) + "deg) scale(" +
        (0.3 + p * 0.7) + ") translateY(" + (slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applyZoomBlurEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var scaleStart = config.scaleStart || 2;
    var blurAmount = config.blurAmount || 8;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      span.style.transform = "scale(" + (scaleStart - (scaleStart - 1) * p) + ")";
      span.style.filter = "blur(" + (blurAmount * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  function applySplitEffect(spans, config) {
    var totalSpans = spans.length;
    var easing = config.easing;
    var slideDistance = config.slideDistance || 30;
    var center = (totalSpans - 1) / 2;

    spans.forEach(function (span, index) {
      var p = calculateSpanViewportProgress(span, index, totalSpans, config);
      p = applyEasing(p, easing);

      var dir = index < center ? -1 : 1;
      var distance = Math.abs(index - center);

      span.style.transform =
        "translateX(" + (dir * distance * slideDistance * (1 - p)) + "px)";
      span.style.opacity = clamp(p, 0, 1);
      applyGhostColor(span, p, config);
    });
  }

  // ============================================
  // EFFECT APPLICATOR MAP
  // ============================================
  var EFFECTS = {
    fade: applyFadeEffect,
    blur: applyBlurEffect,
    "color-fill": applyColorFillEffect,
    "slide-up": applySlideUpEffect,
    "slide-down": applySlideDownEffect,
    "slide-left": applySlideLeftEffect,
    "slide-right": applySlideRightEffect,
    scale: applyScaleEffect,
    rotate: applyRotateEffect,
    flip: applyFlipEffect,
    "flip-y": applyFlipYEffect,
    wave: applyWaveEffect,
    typewriter: applyTypewriterEffect,
    glow: applyGlowEffect,
    depth: applyDepthEffect,
    "bounce-in": applyBounceInEffect,
    elastic: applyElasticEffect,
    "gradient-sweep": applyGradientSweepEffect,
    skew: applySkewEffect,
    spiral: applySpiralEffect,
    "zoom-blur": applyZoomBlurEffect,
    split: applySplitEffect,
  };

  // ============================================
  // MAIN SCROLL HANDLER
  // ============================================

  /**
   * Handle scroll event for all scroll-text elements.
   * Each effect now calculates per-span progress from viewport position.
   */
  function onScroll() {
    elementsCache.forEach(function (config) {
      var effects = parseEffects(config.effect);

      effects.forEach(function (effectName) {
        var effectFn = EFFECTS[effectName];
        if (effectFn) {
          try {
            effectFn(config.spans, config);
          } catch (e) {
            // Prevent one broken effect from killing all scroll animations
          }
        }
      });
    });
  }

  /**
   * rAF-throttled scroll handler
   */
  function onScrollThrottled() {
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(onScroll);
  }

  // ============================================
  // RESIZE HANDLER
  // ============================================

  var debouncedResize = debounce(function () {
    onScroll();
  }, 100);

  // ============================================
  // BROWSER SCROLLBAR (SimpleBar) COMPATIBILITY
  // The "Browser Scrollbar" extension wraps the whole page in SimpleBar, which
  // scrolls inside `.simplebar-content-wrapper` instead of `window`. The window
  // 'scroll' event therefore never fires, freezing the scroll-driven animation.
  // Bind the same handler to SimpleBar's scroll element so it keeps updating.
  // (getBoundingClientRect already reflects the real viewport position because
  // SimpleBar uses native scrolling, so only the event source needs fixing.)
  // ============================================

  var simpleBarBound = false;

  function getSimpleBarScrollElement(instance) {
    if (instance && typeof instance.getScrollElement === "function") {
      return instance.getScrollElement();
    }
    return document.querySelector(
      "#dnxte_simplebar .simplebar-content-wrapper"
    );
  }

  function bindSimpleBarScroll(instance) {
    if (simpleBarBound) return;
    var scrollEl = getSimpleBarScrollElement(instance);
    if (!scrollEl) return;
    scrollEl.addEventListener("scroll", onScrollThrottled, { passive: true });
    simpleBarBound = true;
    // Sync once now that we're listening to the real scroll container.
    onScroll();
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  /**
   * Check if element has already been split (contains scroll-text-span children)
   */
  function isAlreadySplit(element) {
    return element.querySelector(".scroll-text-span") !== null;
  }

  /**
   * Initialize a single element
   */
  function initElement(element) {
    // Skip if already initialized
    if (elementsCache.has(element)) {
      return elementsCache.get(element);
    }

    // Get configuration from data attributes
    var splitType = element.dataset.split || CONFIG.defaultSplit;
    var effect = element.dataset.effect || CONFIG.defaultEffect;
    var speed = element.dataset.speed || CONFIG.defaultSpeed;
    var startColor = element.dataset.startColor || CONFIG.defaultStartColor;
    var endColor = element.dataset.endColor || CONFIG.defaultEndColor;
    var ghostColor = element.dataset.ghostColor || "";
    var easing = element.dataset.easing || CONFIG.defaultEasing;
    var stagger = parseFloat(element.dataset.stagger) || CONFIG.defaultStagger;
    var duration =
      parseFloat(element.dataset.duration) || CONFIG.defaultDuration;
    var direction = element.dataset.direction || CONFIG.defaultDirection;
    var scrollStart =
      parseFloat(element.dataset.scrollStart) || CONFIG.defaultScrollStart;
    var scrollEnd =
      parseFloat(element.dataset.scrollEnd) || CONFIG.defaultScrollEnd;
    var blurAmount =
      parseFloat(element.dataset.blurAmount) || CONFIG.defaultBlurAmount;
    var slideDistance =
      parseFloat(element.dataset.slideDistance) || CONFIG.defaultSlideDistance;
    var scaleStart =
      parseFloat(element.dataset.scaleStart) || CONFIG.defaultScaleStart;
    var rotateAngle =
      parseFloat(element.dataset.rotateAngle) || CONFIG.defaultRotateAngle;
    var perspective =
      parseFloat(element.dataset.perspective) || CONFIG.defaultPerspective;
    var origin = element.dataset.origin || CONFIG.defaultOrigin;

    var spans;

    // Check if text is already split (e.g., by server-side rendering or React)
    if (isAlreadySplit(element)) {
      // Use existing spans
      spans = Array.from(element.querySelectorAll(".scroll-text-span"));
    } else {
      // Split text into spans
      spans = splitText(element, splitType);
    }

    // Calculate speed multiplier
    var speedMultiplier = calculateSpeedMultiplier(speed);

    // Store configuration in cache
    var config = {
      spans: spans,
      effect: effect,
      splitType: splitType,
      speedMultiplier: speedMultiplier,
      startColor: startColor,
      endColor: endColor,
      ghostColor: ghostColor,
      easing: easing,
      stagger: stagger,
      duration: duration,
      direction: direction,
      scrollStart: scrollStart,
      scrollEnd: scrollEnd,
      blurAmount: blurAmount,
      slideDistance: slideDistance,
      scaleStart: scaleStart,
      rotateAngle: rotateAngle,
      perspective: perspective,
      origin: origin,
    };

    elementsCache.set(element, config);

    // Apply initial state immediately
    applyInitialState(spans, effect, config);

    return config;
  }

  /**
   * Apply initial state based on effect type
   */
  function applyInitialState(spans, effect, config) {
    var effects = parseEffects(effect);

    spans.forEach(function (span) {
      // Reset all properties first
      span.style.opacity = "";
      span.style.transform = "";
      span.style.filter = "";
      span.style.color = "";
      span.style.visibility = "";
      span.style.textShadow = "";
      span.style.background = "";
      span.style.backgroundClip = "";
      span.style.webkitBackgroundClip = "";
      span.style.webkitTextFillColor = "";

      effects.forEach(function (effectName) {
        switch (effectName) {
          case "fade":
            span.style.opacity = "0.5";
            break;
          case "blur":
            span.style.filter =
              "blur(" + (config.blurAmount || CONFIG.defaultBlurAmount) + "px)";
            span.style.opacity = "0.3";
            break;
          case "color-fill":
            span.style.color = config.startColor || CONFIG.defaultStartColor;
            break;
          case "slide-up":
          case "slide-down":
          case "slide-left":
          case "slide-right":
          case "scale":
          case "rotate":
          case "flip":
          case "flip-y":
          case "depth":
          case "bounce-in":
          case "elastic":
          case "skew":
          case "spiral":
          case "zoom-blur":
          case "split":
            span.style.opacity = "0";
            break;
          case "wave":
          case "glow":
            span.style.opacity = "0.3";
            break;
          case "typewriter":
            span.style.opacity = "0";
            span.style.visibility = "hidden";
            break;
          case "gradient-sweep":
            span.style.background =
              "linear-gradient(90deg, " +
              (config.startColor || "#667eea") +
              " 0%, " +
              (config.startColor || "#667eea") +
              " 0%)";
            span.style.backgroundClip = "text";
            span.style.webkitBackgroundClip = "text";
            span.style.webkitTextFillColor = "transparent";
            span.style.color = "transparent";
            break;
        }
      });

      // Apply ghost color in initial state
      if (config.ghostColor && effect !== "color-fill" && effect !== "gradient-sweep") {
        span.style.color = config.ghostColor;
      }
    });
  }

  /**
   * Initialize all scroll-text elements
   */
  function init() {
    var elements = document.querySelectorAll(".scroll-text");

    if (elements.length === 0) {
      return;
    }

    elements.forEach(function (element) {
      initElement(element);
    });

    // Only attach event listeners once
    if (!isInitialized) {
      window.addEventListener("scroll", onScrollThrottled, { passive: true });
      window.addEventListener("resize", debouncedResize, { passive: true });
      isInitialized = true;
    }

    // Bind to the Browser Scrollbar extension's scroll container if it already
    // exists (it may also mount later — see the dnxteSimpleBarReady listener).
    bindSimpleBarScroll();

    // Run initial scroll to set correct state
    onScroll();
  }

  /**
   * Initialize MutationObserver to watch for dynamically added elements
   */
  function initMutationObserver() {
    if (observer) return; // Already initialized

    if (typeof MutationObserver === "undefined") return; // Not supported

    observer = new MutationObserver(function (mutations) {
      var hasNewElements = false;

      mutations.forEach(function (mutation) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach(function (node) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Check if the added node is a scroll-text element
              if (node.classList && node.classList.contains("scroll-text")) {
                initElement(node);
                hasNewElements = true;
              }
              // Check for scroll-text elements within the added node
              if (node.querySelectorAll) {
                var nestedElements = node.querySelectorAll(".scroll-text");
                nestedElements.forEach(function (el) {
                  if (!elementsCache.has(el)) {
                    initElement(el);
                    hasNewElements = true;
                  }
                });
              }
            }
          });
        }
      });

      if (hasNewElements) {
        onScroll();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  /**
   * Refresh a specific element or all elements
   */
  function refresh(element) {
    if (element) {
      // Remove from cache first
      elementsCache.delete(element);

      // Get original text from aria-label
      var originalText = element.getAttribute("aria-label");
      if (originalText) {
        element.textContent = originalText;
      }

      initElement(element);
    } else {
      // Refresh all elements
      elementsCache.forEach(function (config, el) {
        var originalText = el.getAttribute("aria-label");
        if (originalText) {
          el.textContent = originalText;
        }
      });
      elementsCache.clear();
      init();
    }
    onScroll();
  }

  /**
   * Destroy and cleanup
   */
  function destroy() {
    window.removeEventListener("scroll", onScrollThrottled);
    window.removeEventListener("resize", debouncedResize);

    if (rafId) cancelAnimationFrame(rafId);

    if (observer) {
      observer.disconnect();
      observer = null;
    }

    elementsCache.clear();
    animationStates.clear();
    isInitialized = false;
  }

  // ============================================
  // DOM CONTENT LOADED
  // ============================================

  function startInit() {
    init();
    initMutationObserver();
  }

  // The Browser Scrollbar extension (SimpleBar) may finish mounting after this
  // script runs. When it signals readiness, bind to its scroll container so the
  // animation responds to scrolling inside SimpleBar.
  document.addEventListener("dnxteSimpleBarReady", function (e) {
    bindSimpleBarScroll(e && e.detail ? e.detail.instance : null);
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startInit);
  } else {
    startInit();
  }

  // Re-initialize on Divi Builder events
  if (typeof window.jQuery !== "undefined") {
    window.jQuery(document).on("et_builder_api_ready", function () {
      setTimeout(init, 100); // Small delay to ensure DOM is ready
    });
  }

  // Handle window load for late-loading content
  window.addEventListener("load", function () {
    setTimeout(init, 200);
  });

  // ============================================
  // EXPOSE API
  // ============================================

  window.ScrollTextAnimation = {
    init: init,
    refresh: refresh,
    destroy: destroy,
    initElement: initElement,
    splitText: splitText,
    hexToRgb: hexToRgb,
    interpolateColor: interpolateColor,
    EFFECTS: EFFECTS,
    EASING: EASING,
    CONFIG: CONFIG,
    getCache: function () {
      return elementsCache;
    },
    getStates: function () {
      return animationStates;
    },
    onScroll: onScroll,
    isAlreadySplit: isAlreadySplit,
    applyInitialState: applyInitialState,
  };

  // Legacy support
  window.DNXTETextScroll = {
    init: init,
    initSection: function (section) {
      var scrollText = section.querySelector(".scroll-text");
      if (scrollText) initElement(scrollText);
    },
  };
})();
