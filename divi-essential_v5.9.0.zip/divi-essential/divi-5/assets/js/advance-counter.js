(function () {
  'use strict';

  // Easing functions (cubic for visible difference between modes).
  var easings = {
    linear: function (t) { return t; },
    easeIn: function (t) { return t * t * t; },
    easeOut: function (t) { return 1 - Math.pow(1 - t, 3); },
    easeInOut: function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
  };

  function animateCounter(numberEl, config) {
    var text = numberEl.getAttribute('data-original-text') || numberEl.textContent.trim();

    // Store original text for repeat animations.
    if (!numberEl.getAttribute('data-original-text')) {
      numberEl.setAttribute('data-original-text', text);
    }

    // Parse target from cleaned numeric portion (handles prefixes like "$").
    var numPart  = text.replace(/[^0-9.\-]/g, '');
    var target   = parseFloat(numPart);

    if (isNaN(target)) {
      return;
    }

    // Determine decimal places from original text.
    var parts    = numPart.split('.');
    var decimals = parts.length > 1 ? parts[1].length : 0;

    // Extract prefix/suffix (e.g., "$", "+", "%").
    var prefix = text.match(/^[^0-9.\-]*/)[0];
    var suffix = text.match(/[^0-9.\-]*$/)[0];

    var duration = config.duration;
    var easing   = easings[config.easing] || easings.easeOut;
    var start    = null;
    var frameId  = 0;

    // Cancel any previous animation on this element.
    if (numberEl._cancelAnim) {
      numberEl._cancelAnim();
    }

    numberEl.textContent = prefix + (decimals > 0 ? (0).toFixed(decimals) : '0') + suffix;

    numberEl._cancelAnim = function () {
      if (frameId) {
        cancelAnimationFrame(frameId);
        frameId = 0;
      }
    };

    function step(timestamp) {
      if (!start) {
        start = timestamp;
      }

      var progress = Math.min((timestamp - start) / duration, 1);
      var eased    = easing(progress);
      var current  = eased * target;

      if (progress < 1) {
        numberEl.textContent = prefix + (decimals > 0 ? current.toFixed(decimals) : Math.floor(current).toString()) + suffix;
        frameId = requestAnimationFrame(step);
      } else {
        numberEl.textContent = text;
        numberEl._cancelAnim = null;
      }
    }

    frameId = requestAnimationFrame(step);
  }

  function getConfig(wrapEl) {
    return {
      enabled:  wrapEl.getAttribute('data-enable-animation') !== 'off',
      duration: parseInt(wrapEl.getAttribute('data-duration'), 10) || 2000,
      delay:    parseInt(wrapEl.getAttribute('data-delay'), 10) || 0,
      easing:   wrapEl.getAttribute('data-easing') || 'easeOut',
      trigger:  wrapEl.getAttribute('data-trigger') || 'viewport',
      repeat:   wrapEl.getAttribute('data-repeat') !== 'off',
    };
  }

  function triggerAnimation(numberEl, config) {
    if (config.delay > 0) {
      setTimeout(function () {
        animateCounter(numberEl, config);
      }, config.delay);
    } else {
      animateCounter(numberEl, config);
    }
  }

  function initCounters() {
    var wraps = document.querySelectorAll('.advance_counter__counter-wrap');

    if (!wraps.length) {
      return;
    }

    wraps.forEach(function (wrapEl) {
      var config   = getConfig(wrapEl);
      var numberEl = wrapEl.querySelector('.advance_counter__number');

      if (!numberEl || !config.enabled) {
        return;
      }

      // Store original text.
      numberEl.setAttribute('data-original-text', numberEl.textContent.trim());

      if (config.trigger === 'pageLoad') {
        // Animate on page load.
        triggerAnimation(numberEl, config);
      } else if ('IntersectionObserver' in window) {
        // Animate on viewport entry.
        var observer = new IntersectionObserver(
          function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting) {
                triggerAnimation(numberEl, config);

                if (!config.repeat) {
                  observer.unobserve(entry.target);
                }
              }
            });
          },
          { threshold: 0.1 }
        );

        observer.observe(wrapEl);
      } else {
        // Fallback: animate immediately.
        triggerAnimation(numberEl, config);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCounters);
  } else {
    initCounters();
  }
})();
