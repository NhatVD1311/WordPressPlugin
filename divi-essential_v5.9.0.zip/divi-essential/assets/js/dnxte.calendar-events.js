/**
 * Calendar Events - Frontend Initializer
 * Reads data-* attributes from calendar containers and initializes FullCalendar.
 */
(function () {
  "use strict";

  var CATEGORY_CONFIG = {
    business: { label: "Business", color: "#3b82f6" },
    personal: { label: "Personal", color: "#10b981" },
    holiday: { label: "Holiday", color: "#ef4444" },
    family: { label: "Family", color: "#8b5cf6" },
    meeting: { label: "Meeting", color: "#f97316" },
    other: { label: "Other", color: "#64748b" },
  };

  /**
   * Get category info for an event. Handles both preset and custom categories.
   */
  function getCategoryInfo(event) {
    var cat = (event.extendedProps && event.extendedProps.category) || event.category || "other";
    var customName = (event.extendedProps && event.extendedProps.customCategoryName) || event.customCategoryName || "";
    var customColor = (event.extendedProps && event.extendedProps.customCategoryColor) || event.customCategoryColor || "";

    if (cat === "custom" && customName) {
      return {
        key: "custom_" + customName.toLowerCase().replace(/\s+/g, "_"),
        label: customName,
        color: customColor || "#6366f1",
      };
    }

    var config = CATEGORY_CONFIG[cat] || CATEGORY_CONFIG.other;
    return { key: cat, label: config.label, color: config.color };
  }

  function formatEventDate(date, allDay) {
    if (!date) return "";
    var options = allDay
      ? { weekday: "short", year: "numeric", month: "short", day: "numeric" }
      : {
          weekday: "short",
          year: "numeric",
          month: "short",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        };
    return date.toLocaleDateString(undefined, options);
  }

  function removeEventModal() {
    var existing = document.querySelector(
      ".dnxte-calendar-event-modal-overlay"
    );
    if (existing) existing.remove();
  }

  function showEventModal(data, modalStyle) {
    removeEventModal();

    var ms = modalStyle || {};
    var catInfo = getCategoryInfo(data);

    var overlay = document.createElement("div");
    overlay.className = "dnxte-calendar-event-modal-overlay";
    if (ms.overlayColor) overlay.style.background = ms.overlayColor;
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) removeEventModal();
    });

    var modal = document.createElement("div");
    modal.className = "dnxte-calendar-event-modal";
    if (ms.bgColor) modal.style.background = ms.bgColor;
    if (ms.borderRadius) modal.style.borderRadius = ms.borderRadius;

    // Header
    var header = document.createElement("div");
    header.className = "dnxte-calendar-event-modal-header";
    if (ms.headerBgColor) header.style.background = ms.headerBgColor;
    if (ms.headerBorderColor) header.style.borderBottomColor = ms.headerBorderColor;

    var colorBar = document.createElement("div");
    colorBar.className = "dnxte-calendar-event-modal-color";
    colorBar.style.backgroundColor = data.color || catInfo.color;

    var title = document.createElement("h3");
    title.className = "dnxte-calendar-event-modal-title";
    title.textContent = data.title;
    if (ms.titleColor) title.style.color = ms.titleColor;

    var closeBtn = document.createElement("button");
    closeBtn.className = "dnxte-calendar-event-modal-close";
    closeBtn.innerHTML = "&times;";
    closeBtn.addEventListener("click", removeEventModal);

    header.appendChild(colorBar);
    header.appendChild(title);
    header.appendChild(closeBtn);

    // Body
    var body = document.createElement("div");
    body.className = "dnxte-calendar-event-modal-body";

    // Category row
    if (data.category) {
      var catRow = document.createElement("div");
      catRow.className = "dnxte-calendar-event-modal-row";
      var catLabel = document.createElement("div");
      catLabel.className = "dnxte-calendar-event-modal-label";
      catLabel.textContent = "Category";
      if (ms.labelColor) catLabel.style.color = ms.labelColor;
      var catValue = document.createElement("div");
      catValue.className = "dnxte-calendar-event-modal-value";
      var badge = document.createElement("span");
      badge.className = "dnxte-calendar-event-modal-category-badge";
      badge.style.backgroundColor = catInfo.color + "18";
      badge.style.color = catInfo.color;
      badge.textContent = catInfo.label;
      catValue.appendChild(badge);
      catRow.appendChild(catLabel);
      catRow.appendChild(catValue);
      body.appendChild(catRow);
    }

    // Start date row
    if (data.start) {
      body.appendChild(
        createModalRow(
          "Start",
          formatEventDate(data.start, data.allDay),
          ms
        )
      );
    }

    // End date row
    if (data.end) {
      body.appendChild(
        createModalRow(
          "End",
          formatEventDate(data.end, data.allDay),
          ms
        )
      );
    }

    // All day row
    if (data.allDay) {
      body.appendChild(createModalRow("Type", "All Day Event", ms));
    }

    // Description row
    if (data.description) {
      body.appendChild(createModalRow("Details", data.description, ms));
    }

    // URL row
    if (data.url) {
      var row = document.createElement("div");
      row.className = "dnxte-calendar-event-modal-row";
      var label = document.createElement("div");
      label.className = "dnxte-calendar-event-modal-label";
      label.textContent = "Link";
      if (ms.labelColor) label.style.color = ms.labelColor;
      var value = document.createElement("div");
      value.className = "dnxte-calendar-event-modal-value";
      var link = document.createElement("a");
      link.className = "dnxte-calendar-event-modal-link";
      link.href = data.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = data.url;
      value.appendChild(link);
      row.appendChild(label);
      row.appendChild(value);
      body.appendChild(row);
    }

    modal.appendChild(header);
    modal.appendChild(body);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Close on Escape key
    document.addEventListener("keydown", function onEsc(e) {
      if (e.key === "Escape") {
        removeEventModal();
        document.removeEventListener("keydown", onEsc);
      }
    });
  }

  function createModalRow(labelText, valueText, ms) {
    var row = document.createElement("div");
    row.className = "dnxte-calendar-event-modal-row";
    var label = document.createElement("div");
    label.className = "dnxte-calendar-event-modal-label";
    label.textContent = labelText;
    if (ms && ms.labelColor) label.style.color = ms.labelColor;
    var value = document.createElement("div");
    value.className = "dnxte-calendar-event-modal-value";
    value.textContent = valueText;
    if (ms && ms.textColor) value.style.color = ms.textColor;
    row.appendChild(label);
    row.appendChild(value);
    return row;
  }

  function buildFilterUI(el, allEvents, calendar, eventBgColor, eventTextColor) {
    var wrapper = el.parentElement;
    if (!wrapper) return;

    // Collect unique categories using getCategoryInfo
    var categoryMap = {};
    var categoryOrder = [];
    allEvents.forEach(function (ev) {
      var info = getCategoryInfo(ev);
      if (!categoryMap[info.key]) {
        categoryMap[info.key] = info;
        categoryOrder.push(info.key);
      }
    });
    if (categoryOrder.length === 0) return;

    var activeFilters = {};
    categoryOrder.forEach(function (k) {
      activeFilters[k] = true;
    });

    var filterEl = document.createElement("div");
    filterEl.className = "dnxte-calendar-filter";

    var filterLabel = document.createElement("span");
    filterLabel.className = "dnxte-calendar-filter-label";
    filterLabel.textContent = "Filter";
    filterEl.appendChild(filterLabel);

    // All checkbox
    var allItem = createFilterItem(
      "All",
      "#6366f1",
      true,
      function (checked) {
        categoryOrder.forEach(function (k) {
          activeFilters[k] = checked;
        });
        updateCheckboxes();
        applyFilter();
      }
    );
    filterEl.appendChild(allItem.el);

    var filterItems = {};
    categoryOrder.forEach(function (catKey) {
      var info = categoryMap[catKey];
      var item = createFilterItem(
        info.label,
        info.color,
        true,
        function (checked) {
          activeFilters[catKey] = checked;
          updateAllCheckbox();
          applyFilter();
        }
      );
      filterEl.appendChild(item.el);
      filterItems[catKey] = item;
    });

    // Insert filter before calendar container
    wrapper.insertBefore(filterEl, el);

    function updateCheckboxes() {
      categoryOrder.forEach(function (k) {
        if (filterItems[k]) {
          filterItems[k].cb.checked = activeFilters[k];
        }
      });
    }

    function updateAllCheckbox() {
      var allActive = categoryOrder.every(function (k) {
        return activeFilters[k];
      });
      allItem.cb.checked = allActive;
    }

    function applyFilter() {
      var filteredEvents = allEvents.filter(function (ev) {
        var info = getCategoryInfo(ev);
        return activeFilters[info.key] !== false;
      });
      calendar.removeAllEvents();
      calendar.addEventSource(filteredEvents);
    }
  }

  function createFilterItem(label, color, checked, onChange) {
    var item = document.createElement("label");
    item.className = "dnxte-calendar-filter-item";

    var cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = checked;
    cb.className = "dnxte-calendar-filter-checkbox";
    cb.style.setProperty("--filter-color", color);
    cb.addEventListener("change", function () {
      onChange(cb.checked);
    });

    var text = document.createElement("span");
    text.className = "dnxte-calendar-filter-text";
    text.textContent = label;

    item.appendChild(cb);
    item.appendChild(text);

    return { el: item, cb: cb };
  }

  function initCalendarEvents() {
    var calendars = document.querySelectorAll("[data-calendar]");
    if (!calendars.length || typeof FullCalendar === "undefined") return;

    calendars.forEach(function (el) {
      // Skip if already initialized
      if (el._fcInstance) return;

      var defaultView =
        el.getAttribute("data-default-view") || "dayGridMonth";
      var firstDay = parseInt(
        el.getAttribute("data-first-day") || "0",
        10
      );
      var headerToolbar =
        el.getAttribute("data-header-toolbar") !== "false";
      var weekNumbers =
        defaultView === "multiMonthYear" ? false : el.getAttribute("data-week-numbers") === "true";
      var hiddenDaysStr = el.getAttribute("data-hidden-days") || "";
      var hiddenDays = hiddenDaysStr
        ? hiddenDaysStr.split(",").map(function (d) { return parseInt(d.trim(), 10); }).filter(function (n) { return !isNaN(n); })
        : [];
      var source = el.getAttribute("data-source") || "manual";
      var googleApiKey = el.getAttribute("data-google-api-key") || "";
      var googleCalendarId =
        el.getAttribute("data-google-calendar-id") || "";
      var eventBgColor =
        el.getAttribute("data-event-bg-color") || "#3b82f6";
      var eventTextColor =
        el.getAttribute("data-event-text-color") || "#ffffff";
      var todayBgColor =
        el.getAttribute("data-today-bg-color") || "#eff6ff";
      var headerBgColor =
        el.getAttribute("data-header-bg-color") || "";
      var dayHeaderBgColor =
        el.getAttribute("data-day-header-bg-color") || "";
      var borderColor =
        el.getAttribute("data-border-color") || "#e5e7eb";
      var showFilter =
        el.getAttribute("data-show-filter") !== "false";
      var eventsJson = el.getAttribute("data-events") || "[]";

      // Modal design data attributes
      var modalStyle = {
        bgColor: el.getAttribute("data-modal-bg") || "#ffffff",
        titleColor:
          el.getAttribute("data-modal-title-color") || "#1e293b",
        textColor:
          el.getAttribute("data-modal-text-color") || "#334155",
        labelColor:
          el.getAttribute("data-modal-label-color") || "#64748b",
        overlayColor:
          el.getAttribute("data-modal-overlay") || "rgba(0,0,0,0.5)",
        headerBgColor:
          el.getAttribute("data-modal-header-bg") || "",
        headerBorderColor:
          el.getAttribute("data-modal-header-border") || "#e2e8f0",
        borderRadius:
          el.getAttribute("data-modal-radius") || "12px",
      };

      // Apply CSS custom properties for theming
      el.style.setProperty("--fc-today-bg-color", todayBgColor);
      el.style.setProperty("--fc-border-color", borderColor);
      el.style.setProperty("--fc-button-bg-color", eventBgColor);
      el.style.setProperty(
        "--fc-button-active-bg-color",
        eventBgColor
      );
      if (headerBgColor) {
        el.style.setProperty(
          "--dnxte-calendar-header-bg",
          headerBgColor
        );
      }
      if (dayHeaderBgColor) {
        el.style.setProperty(
          "--dnxte-calendar-day-header-bg",
          dayHeaderBgColor
        );
      }

      var toolbarConfig = headerToolbar
        ? {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
          }
        : false;

      var parsedEvents = [];
      try {
        parsedEvents = JSON.parse(eventsJson);
      } catch (e) {
        parsedEvents = [];
      }

      var calendarOptions = {
        initialView: defaultView,
        firstDay: firstDay,
        headerToolbar: toolbarConfig,
        weekNumbers: weekNumbers,
        hiddenDays: hiddenDays,
        height: "100%",
        eventColor: eventBgColor,
        eventTextColor: eventTextColor,
        editable: false,
        selectable: false,
        dayMaxEvents: 3,
        eventContent: function (arg) {
          var ev = arg.event;
          var catInfo = getCategoryInfo(ev);
          var wrapper = document.createElement("div");
          wrapper.className = "dnxte-fc-event-content";
          var dot = document.createElement("span");
          dot.className = "dnxte-fc-event-dot";
          dot.style.backgroundColor = catInfo.color;
          wrapper.appendChild(dot);
          if (arg.timeText) {
            var timeEl = document.createElement("span");
            timeEl.className = "dnxte-fc-event-time";
            timeEl.textContent = arg.timeText;
            wrapper.appendChild(timeEl);
          }
          var titleEl = document.createElement("span");
          titleEl.className = "dnxte-fc-event-title";
          titleEl.textContent = ev.title;
          wrapper.appendChild(titleEl);
          return { domNodes: [wrapper] };
        },
        eventClick: function (info) {
          info.jsEvent.preventDefault();
          var ev = info.event;
          showEventModal(
            {
              title: ev.title || "Untitled Event",
              start: ev.start,
              end: ev.end,
              allDay: ev.allDay,
              color: ev.backgroundColor || eventBgColor,
              description: ev.extendedProps
                ? ev.extendedProps.description
                : "",
              url: ev.url || "",
              category: ev.extendedProps
                ? ev.extendedProps.category
                : "",
              customCategoryName: ev.extendedProps
                ? ev.extendedProps.customCategoryName
                : "",
              customCategoryColor: ev.extendedProps
                ? ev.extendedProps.customCategoryColor
                : "",
            },
            modalStyle
          );
        },
      };

      // Set event sources based on data source
      if (source === "google" && googleApiKey && googleCalendarId) {
        calendarOptions.googleCalendarApiKey = googleApiKey;
        calendarOptions.eventSources = [
          {
            googleCalendarId: googleCalendarId,
            failure: function (error) {
              console.error("Google Calendar error:", error);
              var errEl = el.querySelector(".dnxte-gc-error");
              if (!errEl) {
                var div = document.createElement("div");
                div.className = "dnxte-gc-error";
                div.style.cssText = "padding:16px;text-align:center;color:#ef4444;font-size:13px;";
                div.textContent = "Failed to load Google Calendar. Make sure the calendar is public and the API key has Google Calendar API enabled.";
                el.appendChild(div);
              }
            },
          },
        ];
      } else {
        calendarOptions.events = parsedEvents;
      }

      var calendar = new FullCalendar.Calendar(el, calendarOptions);
      calendar.render();
      el._fcInstance = calendar;

      // Build filter UI if enabled and not Google source
      if (
        showFilter &&
        source !== "google" &&
        parsedEvents.length > 0
      ) {
        buildFilterUI(
          el,
          parsedEvents,
          calendar,
          eventBgColor,
          eventTextColor
        );
      }
    });
  }

  // Initialize on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initCalendarEvents);
  } else {
    initCalendarEvents();
  }

  // Re-initialize on resize for responsive behavior
  var resizeTimer;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      document
        .querySelectorAll("[data-calendar]")
        .forEach(function (el) {
          if (el._fcInstance) {
            el._fcInstance.updateSize();
          }
        });
    }, 250);
  });
})();
