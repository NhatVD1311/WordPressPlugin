/**
 * Divi Essential - Row/Section/Column Extension
 * Adds Spotlight & Card Effects to Divi structural modules.
 *
 * @package DNXTE
 */

(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var element = wp.element;

  // Spotlight: structural + blurb + blog + hero
  var SPOTLIGHT_TARGETS = ['divi/row', 'divi/column', 'divi/section', 'divi/blurb', 'divi/blog', 'divi/fullwidth-header'];
  // Card: structural + blurb + hero (no blog)
  var CARD_TARGETS      = ['divi/row', 'divi/column', 'divi/section', 'divi/blurb', 'divi/fullwidth-header'];
  // Combined: any module that gets at least one effect
  var ALL_TARGETS       = ['divi/row', 'divi/column', 'divi/section', 'divi/blurb', 'divi/blog', 'divi/fullwidth-header'];

  // Feature flags from PHP (dashboard toggles)
  var FLAGS = window.dnxteRowSectionFlags || { spotlight: true, card: true };
  var SPOTLIGHT_ON = FLAGS.spotlight;
  var CARD_ON = FLAGS.card;

  // ─── Spotlight attribute defaults (mirrors NextBlurb module.json) ───
  var spotlightAttrDef = {
    type: 'object',
    selector: '{{selector}}',
    default: {
      decoration: {
        color:  { desktop: { value: '#29c4a9' } },
        color2: { desktop: { value: '' } }
      },
      advanced: {
        use_spotlight:      { desktop: { value: 'off' } },
        variant:            { desktop: { value: 'default' } },
        mode:               { desktop: { value: 'hover' } },
        autoplay:           { desktop: { value: 'off' } },
        autoplay_animation: { desktop: { value: 'circle' } },
        spotlightSize:      { desktop: { value: '330px' } },
        intensity:          { desktop: { value: '0.50' } },
        speed:              { desktop: { value: '3000' } }
      }
    }
  };

  // ─── Card Effects attribute defaults (mirrors NextBlurb module.json) ───
  var cardEffectsAttrDef = {
    type: 'object',
    selector: '{{selector}}',
    default: {
      advanced: {
        use_card_effect:  { desktop: { value: 'off' } },
        effect_type:      { desktop: { value: 'electric-border' } },
        speed:            { desktop: { value: 1 } },
        intensity:        { desktop: { value: '1' } },
        chaos:            { desktop: { value: '0.12' } },
        radius:           { desktop: { value: '0' } },
        lightning_size:   { desktop: { value: '1.0' } },
        offset_x:         { desktop: { value: '0' } },
        line_count:       { desktop: { value: 6 } },
        enable_wave:      { desktop: { value: ['top', 'middle', 'bottom'] } },
        wisp_density:     { desktop: { value: '1.0' } },
        fog_density:      { desktop: { value: '0.45' } },
        flow_speed:       { desktop: { value: '0.35' } },
        horizontal_offset:{ desktop: { value: '0.10' } },
        vertical_offset:  { desktop: { value: '0.00' } },
        vertical_sizing:  { desktop: { value: '2.0' } },
        horizontal_sizing:{ desktop: { value: '0.5' } },
        wisp_intensity:   { desktop: { value: '5.0' } }
      },
      decoration: {
        primary_color:   { desktop: { value: '#5227FF' } },
        secondary_color: { desktop: { value: '#FF9FFC' } }
      }
    }
  };

  // ════════════════════════════════════════════════════════════════════
  // 1. ADD OPTION GROUPS (Settings panels)
  // ════════════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleSettings.groups',
    'dnxte-extension',
    function (groups, metadata) {
      var isSpotlightTarget = SPOTLIGHT_ON && SPOTLIGHT_TARGETS.indexOf(metadata.name) !== -1;
      var isCardTarget      = CARD_ON && CARD_TARGETS.indexOf(metadata.name) !== -1;

      if (!isSpotlightTarget && !isCardTarget) return groups;

      if (isSpotlightTarget) groups.dnxteSpotlight = {
        groupName:     'dnxteSpotlight',
        panel:         'design',
        priority:      80,
        multiElements: true,
        component: {
          name:  'divi/composite',
          props: { groupLabel: 'Spotlight Effect' }
        }
      };

      if (isCardTarget) groups.dnxteCardEffects = {
        groupName:     'dnxteCardEffects',
        panel:         'design',
        priority:      81,
        multiElements: true,
        component: {
          name:  'divi/composite',
          props: { groupLabel: 'Card Effects' }
        }
      };

      return groups;
    }
  );

  // ════════════════════════════════════════════════════════════════════
  // 2. ADD ATTRIBUTES (Fields / Controls)
  // ════════════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleAttributes',
    'dnxte-extension',
    function (attributes, metadata) {
      var isSpotlightTarget = SPOTLIGHT_ON && SPOTLIGHT_TARGETS.indexOf(metadata.name) !== -1;
      var isCardTarget      = CARD_ON && CARD_TARGETS.indexOf(metadata.name) !== -1;

      if (!isSpotlightTarget && !isCardTarget) return attributes;

      // ─── Spotlight fields ───
      var spotlightAttr = JSON.parse(JSON.stringify(spotlightAttrDef));
      spotlightAttr.settings = {
        decoration: {
          color: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.decoration.color',
              label:     'Spotlight Color',
              groupSlug: 'dnxteSpotlight',
              priority:  20,
              render:    true,
              features:  { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          },
          color2: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.decoration.color2',
              label:     'Gradient Color 2',
              groupSlug: 'dnxteSpotlight',
              priority:  25,
              render:    true,
              features:  { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: function (p) {
                var v = p.attrs?.spotlight_settings?.advanced?.variant?.desktop?.value;
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value) &&
                  (v === 'gradient' || v === 'gradient-border');
              }
            }
          }
        },
        advanced: {
          use_spotlight: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.use_spotlight',
              label:     'Use Spotlight',
              groupSlug: 'dnxteSpotlight',
              priority:  10,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' }
            }
          },
          variant: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.variant',
              label:     'Variant',
              groupSlug: 'dnxteSpotlight',
              priority:  30,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: {
                type: 'field',
                name: 'divi/select',
                props: {
                  options: {
                    'default':         { label: 'Default' },
                    'border':          { label: 'Border' },
                    'gradient':        { label: 'Gradient' },
                    'gradient-border': { label: 'Gradient Border' }
                  }
                }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          },
          mode: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.mode',
              label:     'Mode',
              groupSlug: 'dnxteSpotlight',
              priority:  35,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: {
                type: 'field',
                name: 'divi/select',
                props: {
                  options: {
                    hover:     { label: 'Hover' },
                    proximity: { label: 'Proximity' }
                  }
                }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          },
          autoplay: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.autoplay',
              label:     'Auto Play',
              groupSlug: 'dnxteSpotlight',
              priority:  40,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          },
          autoplay_animation: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.autoplay_animation',
              label:     'Autoplay Animation',
              groupSlug: 'dnxteSpotlight',
              priority:  45,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: {
                type: 'field',
                name: 'divi/select',
                props: {
                  options: {
                    circle:     { label: 'Circle' },
                    horizontal: { label: 'Horizontal' },
                    vertical:   { label: 'Vertical' },
                    diagonal:   { label: 'Diagonal' },
                    figure8:    { label: 'Figure 8' }
                  }
                }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value) &&
                  'on' === (p.attrs?.spotlight_settings?.advanced?.autoplay?.desktop?.value);
              }
            }
          },
          speed: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.speed',
              label:     'Duration',
              groupSlug: 'dnxteSpotlight',
              priority:  50,
              render:    true,
              features:  { sticky: false },
              component: {
                type: 'field',
                name: 'divi/range',
                props: { min: 500, max: 10000 }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value) &&
                  'on' === (p.attrs?.spotlight_settings?.advanced?.autoplay?.desktop?.value);
              }
            }
          },
          spotlightSize: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.spotlightSize',
              label:     'Spotlight Size',
              groupSlug: 'dnxteSpotlight',
              priority:  55,
              render:    true,
              features:  { sticky: false },
              component: {
                type: 'field',
                name: 'divi/range',
                props: { min: 0, max: 1000, allowedUnits: ['px'] }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          },
          intensity: {
            groupType: 'group-item',
            item: {
              attrName:  'spotlight_settings.advanced.intensity',
              label:     'Intensity',
              groupSlug: 'dnxteSpotlight',
              priority:  60,
              render:    true,
              features:  { sticky: false },
              component: {
                type: 'field',
                name: 'divi/range',
                props: { min: 0, max: 1, step: 0.01 }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value);
              }
            }
          }
        }
      };
      if (isSpotlightTarget) attributes.spotlight_settings = spotlightAttr;

      // ─── Card Effects fields ───
      var cardAttr = JSON.parse(JSON.stringify(cardEffectsAttrDef));
      cardAttr.settings = {
        decoration: {
          primary_color: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.decoration.primary_color',
              label:     'Primary Color',
              groupSlug: 'dnxteCardEffects',
              priority:  20,
              render:    true,
              features:  { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value);
              }
            }
          },
          secondary_color: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.decoration.secondary_color',
              label:     'Secondary Color',
              groupSlug: 'dnxteCardEffects',
              priority:  25,
              render:    true,
              features:  { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'floating-lines' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          }
        },
        advanced: {
          use_card_effect: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.use_card_effect',
              label:     'Use Card Effect',
              groupSlug: 'dnxteCardEffects',
              priority:  10,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' }
            }
          },
          effect_type: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.effect_type',
              label:     'Effect Type',
              groupSlug: 'dnxteCardEffects',
              priority:  15,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: {
                type: 'field',
                name: 'divi/select',
                props: {
                  options: {
                    'electric-border': { label: 'Electric Border' },
                    'lightning':       { label: 'Lightning' },
                    'laser-flow':      { label: 'Laser Flow' },
                    'floating-lines':  { label: 'Floating Lines' }
                  }
                }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value);
              }
            }
          },
          speed: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.speed',
              label:     'Speed',
              groupSlug: 'dnxteCardEffects',
              priority:  30,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 3.0, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value);
              }
            }
          },
          // Electric Border
          chaos: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.chaos',
              label:     'Chaos',
              groupSlug: 'dnxteCardEffects',
              priority:  35,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 0.5, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'electric-border' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          radius: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.radius',
              label:     'Radius',
              groupSlug: 'dnxteCardEffects',
              priority:  36,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 100 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'electric-border' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          // Lightning
          intensity: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.intensity',
              label:     'Intensity',
              groupSlug: 'dnxteCardEffects',
              priority:  37,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 3, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'lightning' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          offset_x: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.offset_x',
              label:     'Offset X',
              groupSlug: 'dnxteCardEffects',
              priority:  38,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: -2, max: 2, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'lightning' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          lightning_size: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.lightning_size',
              label:     'Lightning Size',
              groupSlug: 'dnxteCardEffects',
              priority:  39,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 3.0, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'lightning' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          // Floating Lines
          line_count: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.line_count',
              label:     'Line Count',
              groupSlug: 'dnxteCardEffects',
              priority:  40,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 1, max: 10 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'floating-lines' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          enable_wave: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.enable_wave',
              label:     'Enable Wave',
              groupSlug: 'dnxteCardEffects',
              priority:  45,
              render:    true,
              features:  { sticky: false, hover: false, responsive: false },
              component: {
                type: 'field',
                name: 'divi/checkboxes',
                props: {
                  options: [
                    { value: 'top', label: 'Top' },
                    { value: 'middle', label: 'Middle' },
                    { value: 'bottom', label: 'Bottom' }
                  ]
                }
              },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'floating-lines' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          // Laser Flow
          wisp_density: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.wisp_density',
              label:     'Wisp Density',
              groupSlug: 'dnxteCardEffects',
              priority:  50,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 2, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          fog_density: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.fog_density',
              label:     'Fog Density',
              groupSlug: 'dnxteCardEffects',
              priority:  51,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 1, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          flow_speed: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.flow_speed',
              label:     'Flow Speed',
              groupSlug: 'dnxteCardEffects',
              priority:  52,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 1, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          horizontal_offset: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.horizontal_offset',
              label:     'Horizontal Offset',
              groupSlug: 'dnxteCardEffects',
              priority:  53,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: -0.5, max: 0.5, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          vertical_offset: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.vertical_offset',
              label:     'Vertical Offset',
              groupSlug: 'dnxteCardEffects',
              priority:  54,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: -0.5, max: 0.5, step: 0.01 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          vertical_sizing: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.vertical_sizing',
              label:     'Vertical Sizing',
              groupSlug: 'dnxteCardEffects',
              priority:  55,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 4, step: 0.1 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          horizontal_sizing: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.horizontal_sizing',
              label:     'Horizontal Sizing',
              groupSlug: 'dnxteCardEffects',
              priority:  56,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 2, step: 0.1 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          },
          wisp_intensity: {
            groupType: 'group-item',
            item: {
              attrName:  'card_effects.advanced.wisp_intensity',
              label:     'Wisp Intensity',
              groupSlug: 'dnxteCardEffects',
              priority:  57,
              render:    true,
              features:  { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 10, step: 0.1 } },
              visible: function (p) {
                return 'on' === (p.attrs?.card_effects?.advanced?.use_card_effect?.desktop?.value) &&
                  'laser-flow' === (p.attrs?.card_effects?.advanced?.effect_type?.desktop?.value);
              }
            }
          }
        }
      };
      if (isCardTarget) attributes.card_effects = cardAttr;

      return attributes;
    }
  );

  // ════════════════════════════════════════════════════════════════════
  // 3. MODIFY MODULE OUTPUT (Visual Builder) — init effects on wrapper
  //    Uses a hidden helper span inside the wrapper to get DOM access
  //    to the parent element (cloneElement ref doesn't work on structural modules)
  // ════════════════════════════════════════════════════════════════════

  // Helper: build SpotlightCard options from attrs
  function getSpotlightOptions(sa) {
    return {
      color:          sa?.decoration?.color?.desktop?.value || '#29c4a9',
      size:           sa?.advanced?.spotlightSize?.desktop?.value || '330px',
      variant:        sa?.advanced?.variant?.desktop?.value || 'default',
      mode:           sa?.advanced?.mode?.desktop?.value || 'hover',
      autoplay:       sa?.advanced?.autoplay?.desktop?.value === 'on',
      gradientColors: [
        sa?.decoration?.color?.desktop?.value || '#29c4a9',
        sa?.decoration?.color2?.desktop?.value || ''
      ],
      autoplayType:  sa?.advanced?.autoplay_animation?.desktop?.value || 'circle',
      intensity:     sa?.advanced?.intensity?.desktop?.value || '0.50',
      autoplaySpeed: parseInt(sa?.advanced?.speed?.desktop?.value || '3000')
    };
  }

  // Helper: convert hex color to HSL hue (0-360)
  function hexToHue(hex) {
    if (!hex || hex.charAt(0) !== '#') return 230;
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var r = parseInt(hex.substring(0,2), 16) / 255;
    var g = parseInt(hex.substring(2,4), 16) / 255;
    var b = parseInt(hex.substring(4,6), 16) / 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var h = 0;
    if (max !== min) {
      var d = max - min;
      if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
      else if (max === g) h = ((b - r) / d + 2) / 6;
      else h = ((r - g) / d + 4) / 6;
    }
    return Math.round(h * 360);
  }

  // Helper: build EffectCard options from attrs
  function getCardOptions(ca) {
    var effectType     = ca?.advanced?.effect_type?.desktop?.value || 'electric-border';
    var primaryColor   = ca?.decoration?.primary_color?.desktop?.value || '#5227FF';
    var secondaryColor = ca?.decoration?.secondary_color?.desktop?.value || '#FF9FFC';

    return {
      type:       effectType,
      color:      primaryColor,
      speed:      parseFloat(ca?.advanced?.speed?.desktop?.value || 1),
      intensity:  parseFloat(ca?.advanced?.intensity?.desktop?.value || 1),
      interactive: false,
      chaos:      parseFloat(ca?.advanced?.chaos?.desktop?.value || 0.12),
      borderRadius: parseInt(ca?.advanced?.radius?.desktop?.value || 0),
      hue:        hexToHue(primaryColor),
      xOffset:    parseFloat(ca?.advanced?.offset_x?.desktop?.value || 0),
      size:       parseFloat(ca?.advanced?.lightning_size?.desktop?.value || 1),
      wispDensity:          parseFloat(ca?.advanced?.wisp_density?.desktop?.value || 1),
      fogIntensity:         parseFloat(ca?.advanced?.fog_density?.desktop?.value || 0.45),
      flowSpeed:            parseFloat(ca?.advanced?.flow_speed?.desktop?.value || 0.35),
      horizontalBeamOffset: parseFloat(ca?.advanced?.horizontal_offset?.desktop?.value || 0.1),
      verticalBeamOffset:   parseFloat(ca?.advanced?.vertical_offset?.desktop?.value || 0),
      verticalSizing:       parseFloat(ca?.advanced?.vertical_sizing?.desktop?.value || 2),
      horizontalSizing:     parseFloat(ca?.advanced?.horizontal_sizing?.desktop?.value || 0.5),
      wispIntensity:        parseFloat(ca?.advanced?.wisp_intensity?.desktop?.value || 5),
      color1:       primaryColor,
      color2:       secondaryColor,
      enabledWaves: ca?.advanced?.enable_wave?.desktop?.value || '',
      bendStrength: -0.5,
      topLineCount:    parseInt(ca?.advanced?.line_count?.desktop?.value || 6),
      middleLineCount: parseInt(ca?.advanced?.line_count?.desktop?.value || 6),
      bottomLineCount: parseInt(ca?.advanced?.line_count?.desktop?.value || 6)
    };
  }

  /**
   * EffectInjector — a hidden component rendered as a child of the module wrapper.
   * On mount, it finds its closest .et_pb_module parent and initializes effects on it.
   */
  function EffectInjector(props) {
    var React = window.vendor.React;
    var helperRef = React.useRef(null);
    var spotlightRef = React.useRef(null);
    var spotlightOverlayRef = React.useRef(null);
    var cardEffectRef = React.useRef(null);
    var moduleAttrs = props.moduleAttrs;

    var useSpotlight  = moduleAttrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value;
    var useCardEffect = moduleAttrs?.card_effects?.advanced?.use_card_effect?.desktop?.value;

    // Find the actual module DOM element from our helper span
    function getModuleEl() {
      if (!helperRef.current) return null;
      var el = helperRef.current.parentElement;
      while (el) {
        if (el.classList.contains('et_pb_module') ||
            el.classList.contains('et_pb_row') ||
            el.classList.contains('et_pb_section') ||
            el.classList.contains('et_pb_column') ||
            el.dataset.diviRenderer) {
          return el;
        }
        el = el.parentElement;
      }
      return helperRef.current.parentElement;
    }

    // Spotlight — overlay approach for structural modules, per-post for blog
    React.useEffect(function () {
      if (useSpotlight !== 'on') return;

      var timer = setTimeout(function () {
        var moduleEl = getModuleEl();
        if (!moduleEl || !window.SpotlightCard) return;

        var spotlightOpts = getSpotlightOptions(moduleAttrs.spotlight_settings);
        var isBlog = props.moduleName === 'divi/blog';

        if (isBlog) {
          // Blog: init spotlight on each article.et_pb_post
          var posts = moduleEl.querySelectorAll('article.et_pb_post, .et_pb_post');
          var instances = [];

          posts.forEach(function (post) {
            var pPos = getComputedStyle(post).position;
            if (pPos === 'static') post.style.position = 'relative';
            post.style.overflow = 'hidden';

            instances.push(new window.SpotlightCard(post, spotlightOpts));
          });

          spotlightRef.current = instances;

          // Observe for new posts (AJAX load more / VB re-render)
          if (window.MutationObserver) {
            var obs = new MutationObserver(function () {
              var newPosts = moduleEl.querySelectorAll('article.et_pb_post:not(.spotlight-card), .et_pb_post:not(.spotlight-card)');
              newPosts.forEach(function (post) {
                var pPos = getComputedStyle(post).position;
                if (pPos === 'static') post.style.position = 'relative';
                post.style.overflow = 'hidden';
                instances.push(new window.SpotlightCard(post, spotlightOpts));
              });
            });
            obs.observe(moduleEl, { childList: true, subtree: true });
            spotlightOverlayRef.current = obs;
          }
        } else {
          // Non-blog: overlay div approach
          var pos = getComputedStyle(moduleEl).position;
          if (pos === 'static') moduleEl.style.position = 'relative';

          var overlay = document.createElement('div');
          overlay.className = 'dnxte-spotlight-overlay';
          overlay.style.cssText = 'position:absolute;inset:0;z-index:1;pointer-events:auto;border-radius:inherit;overflow:hidden;';
          moduleEl.appendChild(overlay);
          spotlightOverlayRef.current = overlay;

          spotlightRef.current = new window.SpotlightCard(overlay, spotlightOpts);
        }
      }, 100);

      return function () {
        clearTimeout(timer);
        // Cleanup
        if (Array.isArray(spotlightRef.current)) {
          spotlightRef.current.forEach(function (inst) { if (inst && inst.destroy) inst.destroy(); });
        } else if (spotlightRef.current && spotlightRef.current.destroy) {
          spotlightRef.current.destroy();
        }
        spotlightRef.current = null;

        if (spotlightOverlayRef.current) {
          if (spotlightOverlayRef.current.disconnect) {
            // MutationObserver
            spotlightOverlayRef.current.disconnect();
          } else if (spotlightOverlayRef.current.parentNode) {
            // Overlay div
            spotlightOverlayRef.current.parentNode.removeChild(spotlightOverlayRef.current);
          }
          spotlightOverlayRef.current = null;
        }
      };
    }, [
      useSpotlight,
      moduleAttrs?.spotlight_settings?.decoration?.color?.desktop?.value,
      moduleAttrs?.spotlight_settings?.decoration?.color2?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.variant?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.mode?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.autoplay?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.autoplay_animation?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.spotlightSize?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.intensity?.desktop?.value,
      moduleAttrs?.spotlight_settings?.advanced?.speed?.desktop?.value
    ]);

    // Card Effect
    React.useEffect(function () {
      if (useCardEffect !== 'on') return;

      var timer = setTimeout(function () {
        var moduleEl = getModuleEl();
        if (!moduleEl || !window.EffectCard) return;

        var ca = moduleAttrs.card_effects;
        var primaryColor   = ca?.decoration?.primary_color?.desktop?.value || '#5227FF';
        var secondaryColor = ca?.decoration?.secondary_color?.desktop?.value || '#FF9FFC';

        moduleEl.style.setProperty('--effect-card-color', primaryColor);
        moduleEl.style.setProperty('--effect-card-color-alt', secondaryColor);

        cardEffectRef.current = new window.EffectCard(moduleEl, getCardOptions(ca));
      }, 50);

      return function () {
        clearTimeout(timer);
        if (cardEffectRef.current) {
          cardEffectRef.current.destroy();
          cardEffectRef.current = null;
        }
      };
    }, [
      useCardEffect,
      moduleAttrs?.card_effects?.advanced?.effect_type?.desktop?.value,
      moduleAttrs?.card_effects?.decoration?.primary_color?.desktop?.value,
      moduleAttrs?.card_effects?.decoration?.secondary_color?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.speed?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.intensity?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.chaos?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.radius?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.offset_x?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.lightning_size?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.line_count?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.enable_wave?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.wisp_density?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.fog_density?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.flow_speed?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.horizontal_offset?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.vertical_offset?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.vertical_sizing?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.horizontal_sizing?.desktop?.value,
      moduleAttrs?.card_effects?.advanced?.wisp_intensity?.desktop?.value
    ]);

    // Hidden helper span — just to get a DOM foothold
    return element.createElement('span', {
      ref: helperRef,
      'data-dnxte-effect-injector': '',
      style: { display: 'none', position: 'absolute', pointerEvents: 'none' }
    });
  }

  hooks.addFilter(
    'divi.module.wrapper.render',
    'dnxte-extension',
    function (moduleWrapper, param) {
      var moduleName = param.name;
      var moduleAttrs = param.attrs;

      if (ALL_TARGETS.indexOf(moduleName) === -1) return moduleWrapper;

      var useSpotlight  = moduleAttrs?.spotlight_settings?.advanced?.use_spotlight?.desktop?.value;
      var useCardEffect = moduleAttrs?.card_effects?.advanced?.use_card_effect?.desktop?.value;

      if (useSpotlight !== 'on' && useCardEffect !== 'on') return moduleWrapper;

      // Inject EffectInjector as an additional child of the module wrapper
      var children = moduleWrapper.props.children;
      var childArray = Array.isArray(children) ? children : [children];

      var injector = element.createElement(EffectInjector, {
        key: 'dnxte-effect-injector',
        moduleAttrs: moduleAttrs,
        moduleName: moduleName
      });

      return element.cloneElement(
        moduleWrapper,
        {},
        childArray.concat([injector])
      );
    }
  );

})();
