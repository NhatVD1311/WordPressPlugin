(function ($) {
  "use strict";

  var dnxte = dnxte || {};
  dnxte = {
    init: function () {
      dnxte.imageAccordion();
      dnxte.tiltAnimation();
      dnxte.magnifier();
      dnxte.floatingElements();
      dnxte.masonryGallery();
      dnxte.contentToggle();
      this.advancedTabInit();
      dnxte.faqAccordion();
      dnxte.diviModuleLibrary();
    },
    imageAccordion: function () {
      $.fn.dnxte_image_accordion = function () {
        let $this = $(this);
        let accordion_type = $this.data("accordion-type");
        let expandLastItem = $this.data("expand-last-item");

        let $accordion_children = $this.find(".dnxte_image_accordion_item");

        let onloadOpen = $this.find("[data-active-on-load=1]");
        let accordionExpand = $this.find("[data-accordion-expand=defaults]");

        //Setup active on load
        if (expandLastItem == "on") {
          $this.find(".dnxte_image_accordion_item").removeClass("dnxte-active");
          $this
            .find(".dnxte_image_accordion_item")
            .last()
            .addClass("dnxte-active");
        } else {
          onloadOpen
            .parents(".dnxte_image_accordion_item")
            .addClass("dnxte-active");
        }

        if (accordion_type === "on_hover") {
          $accordion_children.mouseenter(function () {
            $accordion_children.removeClass("dnxte-active");
            $(this).addClass("dnxte-active");
          });

          "off" === expandLastItem &&
            $accordion_children.mouseleave(function () {
              $accordion_children.removeClass("dnxte-active");
              $(this).addClass("dnxte-active");
            });

          "off" === expandLastItem &&
            $accordion_children.mouseleave(function () {
              $accordion_children.removeClass("dnxte-active");
              accordionExpand
                .parents(".dnxte_image_accordion_item")
                .addClass("dnxte-active");
            });
        }

        // Setup active on click
        if (accordion_type === "on_click") {
          $this.addClass("dnxte_clickable");
          $accordion_children.click(function (e) {
            if ($(this).hasClass("dnxte-active")) {
              return;
            }
            $accordion_children.removeClass("dnxte-active");
            $(this).addClass("dnxte-active");
          });
        }
      };

      $(".dnxte_image_accordion").each(function () {
        $(this).dnxte_image_accordion();
      });
    },
    tiltAnimation: function () {
      function tilt_animation(params, values, element) {
        switch (params) {
          case "init":
            VanillaTilt.init(element, { ...values });
            break;
          case "destroy":
            if (element) {
              try {
                if (element.vanillaTilt) {
                  element.vanillaTilt.destroy();
                }
              } catch (err) {
                console.log("err", err);
              }
            }
            break;
          default:
            break;
        }
      }
    },
    magnifier: function () {
      $(".dnxte-magnifier img").each(function () {
        const magnifyData = $(this).data();
        $(this).magnify({
          speed: +magnifyData.speed,
          limitBounds: magnifyData.boundary === "on",
        });
      });
    },
    floatingElements: function () {
      let floatingElementsImg = $(".responsive-image-wrapper");
      if (floatingElementsImg.length > 0) {
        function updateMaxHeight(wrapperSelector) {
          $(wrapperSelector).each(function () {
            let self = $(this);
            let maxHeight = 0; // Reset height calculation for each wrapper

            self.find(".dnxte_floating_elements_item img").each(function () {
              const imgHeight = $(this).height(); // Get the displayed height
              maxHeight = Math.max(maxHeight, imgHeight);
            });

            // Apply the largest height to the wrapper
            if (maxHeight > 0) {
              self.css("height", maxHeight + "px");
            }
          });
        }

        // Initial execution after page load
        $(window).on("load", function () {
          updateMaxHeight(".responsive-image-wrapper"); // Apply to all instances
        });

        // Recalculate on window resize
        $(window).on("resize", function () {
          updateMaxHeight(".responsive-image-wrapper"); // Apply to all instances
        });
      }
    },
    masonryGallery: function () {
      const $grid = $(".dnxte-msnary-grid");
      if ($grid.length > 0) {
        const firstMenuItemSelector = $(
          ".dnxte-msnary-filter-items li:first-child"
        );
        const firstMenuItemFilter = firstMenuItemSelector.attr("data-filter");
        firstMenuItemSelector.addClass("active");

        if ($grid.length) {
          $grid.each(function () {
            let gutter = 0;
            let gutter_value = $(this).data("options");
            // Function to update gutter based on screen width
            function updateGutter() {              
              if ( gutter_value === undefined ) {
                return;
              }
              if (window.innerWidth > 980) {
                gutter = gutter_value.desktop || 0;
              } else if (window.innerWidth > 767) {
                gutter = gutter_value.tablet || 0;
              } else {
                gutter = gutter_value.phone || 0;
              }
            }

            // Run function immediately on page load
            updateGutter();

            // Optimize performance with throttled resize event
            let resizeTimer;
            window.addEventListener("resize", function () {
              clearTimeout(resizeTimer);
              resizeTimer = setTimeout(updateGutter, 100);
            });

            let initialFilter = firstMenuItemFilter;
            if ($(this).data("load-more")) {
              initialFilter =
                (firstMenuItemFilter || "*") +
                ":not(.dnxte-msnary-hidden-item)";
            }

            $(this).isotope({
              // layoutMode: "masonry",
              itemSelector: ".dnxte-msnary-item",
              percentPosition: true,
              stagger: 0,
              filter: initialFilter,
              // transitionDuration: 90,
              // percentPosition: true,
              horizontalOrder: true,
              masonry: {
                columnWidth: ".grid-sizer",
                gutter: parseInt(gutter, 10),
              },
            });
          });

          $grid.imagesLoaded().progress(function () {
            $grid.isotope("layout");
          });
          $(window).scroll(() => {
            $grid.isotope("layout");
          });
        }

        $(".dnxte-msnary-filter-items li:first-child").addClass("active");
        $(".dnxte-msnary-filter-items li").on("click", function (item) {
          const that =
            "." +
            $(this)
              .parent()
              .parent()
              .parent()
              .parent()
              .parent()
              .attr("class")
              .split(" ")
              .join(".");

          $(`${that} .dnxte-msnary-filter-items li`).removeClass("active");
          $(this).addClass("active");
          var selector = $(this).attr("data-filter");

          const $filterGrid = $(`${that} .dnxte-msnary-grid`);
          if ($filterGrid.data("load-more")) {
            selector = selector + ":not(.dnxte-msnary-hidden-item)";
          }

          $filterGrid.isotope({
            filter: selector,
          });
        });

        // Load more button
        $(".dnxte-msnary-load-more").on("click", function () {
          const $wrapper = $(this).closest(".dnxte-msnary-wrapper");
          const $thisGrid = $wrapper.find(".dnxte-msnary-grid");
          const loadLimit = parseInt($thisGrid.data("load-limit"), 10) || 8;
          const perLoad = parseInt($thisGrid.data("per-load"), 10) || loadLimit;

          $thisGrid
            .find(".dnxte-msnary-hidden-item")
            .slice(0, perLoad)
            .removeClass("dnxte-msnary-hidden-item");

          const activeFilter =
            $wrapper.find(".dnxte-msnary-filter-item.active").attr("data-filter") ||
            "*";

          $thisGrid.isotope({
            filter: activeFilter + ":not(.dnxte-msnary-hidden-item)",
          });
          $thisGrid.imagesLoaded().progress(function () {
            $thisGrid.isotope("layout");
          });

          if (!$thisGrid.find(".dnxte-msnary-hidden-item").length) {
            $(this).closest(".dnxte-msnary-load-more-wrap").hide();
          }
        });

        const img = $(".image-popup");
        const lighboxData = $grid.length && $grid.data();

        const lightboxMarkup =
          lighboxData?.captionPosition === "on_image"
            ? '<div class="mfp-figure dnxte-msnary-mfp-config title_on_top">' +
              '<div class="mfp-close"></div>' +
              '<div class="mfp-top-bar">' +
              '<div class="mfp-title"></div>' +
              '<div class="mfp-counter"></div>' +
              "</div>" +
              '<div class="mfp-img"></div>' +
              "</div>"
            : '<div class="mfp-figure dnxte-msnary-mfp-config title_on_bottom">' +
              '<div class="mfp-close"></div>' +
              '<div class="mfp-img"></div>' +
              '<div class="mfp-bottom-bar">' +
              '<div class="mfp-title"></div>' +
              '<div class="mfp-counter"></div>' +
              "</div>" +
              "</div>";

        if (img.length && "none" !== lighboxData.lightbox) {
          img.each(function () {
            let orderClass = $(this).data("gallery-order");
            const that =
              "." +
              $(this)
                // .parent()
                .parent()
                .parent()
                .parent()
                .parent()
                .parent()
                .attr("class")
                .split(" ")
                .join(".");

            const url = $(this)[0]?.attributes[1]?.value; // This will 'true' if the URL is an image link, 'false' otherwise.

            if (!isImageLink(url)) return;

            $(`${that} .image-popup`).magnificPopup({
              removalDelay: 500,
              type: "image",
              gallery: {
                enabled: true,
                navigateByImgClick: true,
                tCounter: "%curr% of %total%", // Markup for "1 of 7" counter
              },
              callbacks: {
                open: function () {
                  $(".mfp-bg").addClass(orderClass);
                },
              },
              disableOn: function () {
                return lighboxData.lightbox;
              },
              image: {
                markup: lightboxMarkup,
                titleSrc: function (item) {
                  return (
                    item.el.attr("data-title") + item.el.attr("data-caption")
                  );
                },
              },
              zoom: {
                enabled: lighboxData.lightbox,
                duration: 500,
                opener: function (element) {
                  return element.find("img");
                },
              },
            });
          });
          function isImageLink(url) {
            // Regular expression to match image file extensions
            const imagePattern = /\.(jpeg|jpg|gif|png|svg|webp)$/i;
            return imagePattern.test(url);
          }
        }
      }
    },
    diviModuleLibrary: function () {
      if (
        window.divi &&
        window.divi.moduleLibrary &&
        typeof window.divi.moduleLibrary.registerFolder === 'function'
      ) {
        window.divi.moduleLibrary.registerFolder({
          name: "divi-essential",
          path: "",
          title: "Divi Essential",
          icon: "dnxte/divi-essential",
          category: "module",
        });
      }

      if (window.vendor?.wp?.hooks) {
        window.vendor.wp.hooks?.addFilter(
          "divi.moduleLibrary.moduleMapping",
          "divi",
          (modules) => {
            // A path to select and modify in the `modules` object
            const path = ["dnxte", "metadata"];

            // Helper functions and constants
            const { get, has } = window?.lodash;
            const target = get(modules, path, {});

            if (has(modules, path)) {
              target.folder = "divi-essential";
            } else {
              console.warn(`Path ${path.join(".")} does not exist in modules.`);
            }

            // Return the modified modules
            return modules;
          }
        );
      }
    },
    // Divi's entrance-animation handler skips elements that are hidden when
    // their scroll waypoint fires (it checks `:visible`) and never retries, so
    // animated modules inside an initially hidden panel (content toggle back
    // side, inactive advanced tab) stay at `opacity: 0` forever. Call this
    // right after revealing a panel: `et_animate_element` is Divi 5's own
    // per-element trigger and is safe to call repeatedly — it skips elements
    // already animated (`.et_had_animation`) and elements still hidden.
    animateRevealed: function ($panel) {
      if (typeof window.et_animate_element !== "function") {
        return;
      }
      $panel
        .find("[data-animation-style]")
        .addBack("[data-animation-style]")
        .each(function () {
          window.et_animate_element($(this));
        });
    },
    contentToggle: function () {
      jQuery(function (dnxte_contenttoggle) {
        dnxte_contenttoggle(".dnxte-toggle-btn .dnxte-input").each(function () {
          var n = dnxte_contenttoggle(this)
              .parents(".dnxte-toggle-container")
              .find(".dnxte-content-toggle-back"),
            e = dnxte_contenttoggle(this)
              .parents(".dnxte-toggle-container")
              .find(".dnxte-content-toggle-front");

          this.checked ? (e.hide(), n.show()) : (n.hide(), e.show()),
            dnxte_contenttoggle(this).on("change", function () {
              this.checked
                ? (e.hide(), n.show(), dnxte.animateRevealed(n))
                : (n.hide(), e.show(), dnxte.animateRevealed(e));
            });
        });
      });
    },

    advancedTabInit: function () {
      $(".tab-container").each(function () {
        const $menu = $(this).find(".dnxte_tab_menu");
        const { tabEffect } = $menu.data();
        // "click" (default) or "hover" — how a tab becomes active.
        const changeOn =
          "hover" === $menu.attr("data-tab-change-on") ? "hover" : "click";

        const dnxteTab = $(this).find(".dnxte_tab_a[data-activeOnLoad='on']");
        const tabActiveEffect = `dnxt-hover-ad-${tabEffect}--active`;
        if (dnxteTab.length > 0) {
          dnxteTab.first().addClass("dnxte_active_a");
          dnxteTab.first().addClass(tabActiveEffect);
          $(this)
            .find(
              ".dnxte_tab_content[data-id='" +
                dnxteTab.first().attr("data-id") +
                "']"
            )
            .addClass("dnxte_tab_content_active");
        } else {
          $(this)
            .find(".dnxte_tab_a:first")
            .addClass(`dnxte_active_a ${tabActiveEffect}`);
          $(this)
            .find(".dnxte_tab_content:first")
            .addClass("dnxte_tab_content_active");
        }
        const that = $(this);
        const activateTab = function (tab) {
          that.find(".dnxte_tab_content").removeClass("dnxte_tab_content_active");
          const $activated = that
            .find(".dnxte_tab_content[data-id='" + $(tab).attr("data-id") + "']")
            .addClass("dnxte_tab_content_active");
          that
            .find(".dnxte_tab_a")
            .removeClass(`dnxte_active_a ${tabActiveEffect}`);
          $(tab).addClass(`dnxte_active_a ${tabActiveEffect}`);
          dnxte.animateRevealed($activated);
        };

        const $tabLinks = $(this).find(".dnxte_tab_a");

        $tabLinks.click(function (e) {
          if ($(this).hasClass("dnxte_tab_a_clickable")) {
            // Allow navigation for clickable tabs with module links
            return;
          }
          e.preventDefault();
          activateTab(this);
        });

        // Hover mode keeps the click binding above, so tabs carrying a module
        // link still navigate on click.
        if ("hover" === changeOn) {
          $tabLinks.on("mouseenter", function () {
            activateTab(this);
          });
        }
      });
    },

    faqAccordion: function () {
      $(".dnxte-next-faq-list").each(function () {
        const $list = $(this);
        const $wrap = $list.parent();
        const layout = $list.attr("data-layout") || "accordion";
        const isPlainText = layout === "plainText";
        const oneAtATime =
          layout === "accordion" && $list.attr("data-one-at-a-time") !== "off";
        const defaultOpen = $list.attr("data-default-open") || "none";
        const animateClose = $list.attr("data-animate-close") === "on";
        const $items = $list.find(".next_faq__item");

        // Duration (ms) used as a fallback timer for the close animation. Take
        // the longer of the reveal animation (--dnxte-faq-anim-duration) and the
        // body expand/collapse transition (--dnxte-faq-transition-duration) so
        // the item is not cleared before the slower of the two finishes.
        function cssMs(varName) {
          const raw = (
            getComputedStyle($list[0]).getPropertyValue(varName) || ""
          ).trim();
          if (!raw) return 0;
          const num = parseFloat(raw) || 0;
          return raw.indexOf("ms") > -1 ? num : num * 1000;
        }
        function closeDuration() {
          return (
            Math.max(
              cssMs("--dnxte-faq-anim-duration"),
              cssMs("--dnxte-faq-transition-duration")
            ) || 300
          );
        }
        const $empty = $wrap.find(".next_faq__empty");
        const $search = $wrap.find(".next_faq__search input");
        const $tabs = $wrap.find(".next_faq__tabs");

        // Screen-reader live region announcing expand/collapse state changes.
        // Reuse an existing region so a second init does not stack duplicates.
        let $live = $wrap.find(".next_faq__sr-live").first();
        if (!$live.length) {
          $live = $('<div class="next_faq__sr-live" aria-live="polite"></div>');
          $list.before($live);
        }

        function setOpen($item, open) {
          // Re-opening cancels any in-progress close animation.
          if (open) $item.removeClass("dnxte-closing");
          $item.toggleClass("dnxte-active", open);
          $item
            .find(".next_faq__header")
            .attr("aria-expanded", open ? "true" : "false");
        }

        // Collapse an item, optionally playing the reverse reveal animation
        // before removing the active state.
        function closeItem($item) {
          $item
            .find(".next_faq__header")
            .attr("aria-expanded", "false");

          if (!$item.hasClass("dnxte-active")) {
            $item.removeClass("dnxte-closing");
            return;
          }

          if (!animateClose) {
            $item.removeClass("dnxte-active");
            return;
          }

          if ($item.hasClass("dnxte-closing")) return;
          $item.addClass("dnxte-closing");

          let done = false;
          const finish = function () {
            if (done) return;
            done = true;
            $item.removeClass("dnxte-active dnxte-closing");
          };

          const $aw = $item.find(".next_faq__answer-wrap").first();
          if ($aw.length) $aw.one("animationend", finish);
          // Fallback for animation="none" / reduced motion where no
          // animationend event fires.
          setTimeout(finish, closeDuration() + 80);
        }

        function openItem($item) {
          if (oneAtATime) {
            $items.not($item).each(function () {
              closeItem($(this));
            });
          }
          setOpen($item, true);
        }

        // The hideable cell is the Divi module wrapper directly under the list.
        function cellOf($item) {
          const $parents = $item.parentsUntil($list);
          return $parents.length ? $parents.last() : $item;
        }

        // Initial open state.
        if (isPlainText) {
          $items.each(function () {
            setOpen($(this), true);
          });
        } else {
          $items.each(function () {
            if ($(this).attr("data-active-on-load") === "on") {
              setOpen($(this), true);
            }
          });

          if (defaultOpen === "all") {
            $items.each(function () {
              setOpen($(this), true);
            });
          } else if (
            defaultOpen === "first" &&
            !$items.filter(".dnxte-active").length
          ) {
            setOpen($items.first(), true);
          }

          // Deep link: open and scroll to the item referenced by the URL hash.
          const hash = window.location.hash.replace("#", "");
          if (hash) {
            const $target = $items
              .filter(function () {
                return (
                  this.id === hash || $(this).attr("data-anchor") === hash
                );
              })
              .first();

            if ($target.length) {
              openItem($target);
              setTimeout(function () {
                $target[0].scrollIntoView({
                  behavior: "smooth",
                  block: "start",
                });
              }, 150);
            }
          }

          // Toggle on header click. Namespaced + unbound first so a repeat
          // init cannot stack a second handler that would immediately undo the
          // first one's toggle.
          $list.off("click.faqToggle").on("click.faqToggle", ".next_faq__header", function () {
            const $item = $(this).closest(".next_faq__item");
            // An item mid-close re-opens on click.
            const willOpen =
              $item.hasClass("dnxte-closing") ||
              !$item.hasClass("dnxte-active");

            if (willOpen) {
              openItem($item);

              // Update the URL hash for deep-linkable items.
              const anchor = $item.attr("data-anchor");
              if (anchor && window.history.replaceState) {
                window.history.replaceState(null, "", "#" + anchor);
              }
            } else {
              closeItem($item);
            }

            const label = $item.find(".next_faq__question").text();
            $live.text(label + (willOpen ? " expanded" : " collapsed"));
          });

          // Keyboard accessibility (Enter / Space / Arrow / Home / End).
          $list.off("keydown.faqKeys").on("keydown.faqKeys", ".next_faq__header", function (e) {
            const key = e.key;
            if (key === "Enter" || key === " " || e.keyCode === 13 || e.keyCode === 32) {
              e.preventDefault();
              $(this).trigger("click");
              return;
            }

            if (
              key === "ArrowDown" ||
              key === "ArrowUp" ||
              key === "Home" ||
              key === "End"
            ) {
              e.preventDefault();
              const $headers = $list.find(".next_faq__header:visible");
              let index = $headers.index(this);

              if (key === "ArrowDown") index += 1;
              else if (key === "ArrowUp") index -= 1;
              else if (key === "Home") index = 0;
              else index = $headers.length - 1;

              if (index >= 0 && index < $headers.length) {
                $headers.eq(index).trigger("focus");
              }
            }
          });
        }

        // Search + category filtering.
        let query = "";
        let activeCategory = "";

        function categoriesOf($item) {
          return ($item.attr("data-category") || "")
            .split(",")
            .map(function (c) {
              return c.trim().toLowerCase();
            })
            .filter(Boolean);
        }

        // Order category labels for the tab list. Mirrors the TypeScript helper
        // in divi-5/visual-builder/src/components/NextFAQ/category-order.ts —
        // keep the two in sync.
        function orderFaqCategories(labels, mode, manualOrder) {
          var list = (labels || []).filter(Boolean);
          if (mode === "az") {
            return list.slice().sort(function (a, b) {
              return a.localeCompare(b, undefined, { sensitivity: "base" });
            });
          }
          if (mode === "za") {
            return list.slice().sort(function (a, b) {
              return b.localeCompare(a, undefined, { sensitivity: "base" });
            });
          }
          if (mode === "manual") {
            var byKey = {};
            list.forEach(function (label) {
              var key = label.trim().toLowerCase();
              if (key && !(key in byKey)) byKey[key] = label;
            });
            var out = [];
            var used = {};
            (manualOrder || []).forEach(function (raw) {
              var key = String(raw).trim().toLowerCase();
              if (key && byKey[key] && !used[key]) {
                used[key] = true;
                out.push(byKey[key]);
              }
            });
            list.forEach(function (label) {
              var key = label.trim().toLowerCase();
              if (key && !used[key]) {
                used[key] = true;
                out.push(label);
              }
            });
            return out;
          }
          return list;
        }

        function applyFilter() {
          let visible = 0;

          $items.each(function () {
            const $item = $(this);
            const matchesQuery =
              !query || $item.text().toLowerCase().indexOf(query) !== -1;
            const matchesCategory =
              !activeCategory ||
              categoriesOf($item).indexOf(activeCategory) !== -1;

            if (matchesQuery && matchesCategory) {
              cellOf($item).removeAttr("data-dnxte-faq-hidden");
              visible++;
            } else {
              cellOf($item).attr("data-dnxte-faq-hidden", "");
            }
          });

          $empty.prop("hidden", visible > 0);
        }

        if ($search.length) {
          let timer = null;
          $search.off("input.faqSearch").on("input.faqSearch", function () {
            const value = String($(this).val()).toLowerCase().trim();
            clearTimeout(timer);
            timer = setTimeout(function () {
              query = value;
              applyFilter();
            }, 250);
          });
        }

        if ($tabs.length) {
          // Start from a clean slate so re-initialisation (e.g. in the Divi
          // visual builder) can't duplicate the "All" tab or category tabs.
          $tabs.empty();

          // Build the tab list from the categories found in the items.
          const labels = [];
          const seen = {};
          $items.each(function () {
            ($(this).attr("data-category") || "")
              .split(",")
              .forEach(function (raw) {
                const label = raw.trim();
                const key = label.toLowerCase();
                if (label && !seen[key]) {
                  seen[key] = true;
                  labels.push(label);
                }
              });
          });

          if ($tabs.attr("data-show-all") !== "off") {
            $(
              '<button type="button" class="next_faq__tab dnxte-active" role="tab" aria-selected="true"></button>'
            )
              .attr("data-category", "")
              .text($tabs.attr("data-all-label") || "All")
              .appendTo($tabs);
          }

          var tabOrder = $tabs.attr("data-tab-order") || "default";
          var manualOrder = ($tabs.attr("data-manual-order") || "")
            .split(",")
            .map(function (s) {
              return s.trim().toLowerCase();
            })
            .filter(Boolean);
          var orderedLabels = orderFaqCategories(labels, tabOrder, manualOrder);

          orderedLabels.forEach(function (label) {
            $(
              '<button type="button" class="next_faq__tab" role="tab" aria-selected="false"></button>'
            )
              .attr("data-category", label.toLowerCase())
              .text(label)
              .appendTo($tabs);
          });

          // Without an "All" tab the first category starts active.
          const $first = $tabs.find(".next_faq__tab").first();
          if ($first.length && !$first.hasClass("dnxte-active")) {
            $first.addClass("dnxte-active").attr("aria-selected", "true");
            activeCategory = $first.attr("data-category") || "";
            applyFilter();
          }

          // Honour a saved "Default Active Category": if it matches a built tab,
          // make that tab active on load. A blank or stale value keeps the
          // All/first-tab default set above.
          const defaultCategory = ($tabs.attr("data-default-category") || "")
            .trim()
            .toLowerCase();
          if (defaultCategory) {
            const $match = $tabs
              .find(".next_faq__tab")
              .filter(function () {
                return ($(this).attr("data-category") || "") === defaultCategory;
              })
              .first();
            if ($match.length) {
              $tabs
                .find(".next_faq__tab")
                .removeClass("dnxte-active")
                .attr("aria-selected", "false");
              $match.addClass("dnxte-active").attr("aria-selected", "true");
              activeCategory = defaultCategory;
              applyFilter();
            }
          }

          $tabs.off("click.faqTabs").on("click.faqTabs", ".next_faq__tab", function () {
            $tabs
              .find(".next_faq__tab")
              .removeClass("dnxte-active")
              .attr("aria-selected", "false");
            $(this).addClass("dnxte-active").attr("aria-selected", "true");
            activeCategory = $(this).attr("data-category") || "";
            applyFilter();
          });
        }
      });
    },
  };

  // Initialize the script on document ready
  $(document).ready(function () {
    dnxte.init();
  });
})(jQuery);


(function() {
  const MEDIA_QUERIES = {
    phone: window.matchMedia("(max-width: 767px)"),
    tablet: window.matchMedia("(max-width: 980px)")
  };

  let debounceTimer = null;

  function setDeviceModeCookie(mode) {
    const secure = location.protocol === 'https:' ? '; Secure' : '';
    document.cookie = `device_mode=${mode}; path=/${secure}; SameSite=Lax`;
  }

  function getDeviceMode() {
    if (MEDIA_QUERIES.phone.matches) return "phone";
    if (MEDIA_QUERIES.tablet.matches) return "tablet";
    return "desktop";
  }

  function getCurrentCookieValue() {
    const match = document.cookie.match(/(?:^|; )device_mode=([^;]*)/);
    return match ? match[1] : null;
  }

  function updateDeviceMode() {
    const mode = getDeviceMode();
    const currentValue = getCurrentCookieValue();
    if (currentValue !== mode) {
      setDeviceModeCookie(mode);
    }
  }

  function debouncedUpdate() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(updateDeviceMode, 100);
  }

  // Set on load
  updateDeviceMode();

  // Listen for media query changes (handles resize automatically)
  Object.values(MEDIA_QUERIES).forEach((mq) => {
    mq.addEventListener("change", debouncedUpdate);
  });
})();
