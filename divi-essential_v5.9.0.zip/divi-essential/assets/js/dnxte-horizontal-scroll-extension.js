/**
 * Horizontal Scroll — VB Extension
 * Section-only horizontal scroll. Options mirror Divi Animation.
 * Uses Divi native fields (toggle, range, select, text).
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var TARGET = ['divi/section'];

  function isTarget(name) { return TARGET.indexOf(name) !== -1; }
  function isOn(p) { return 'on' === (p.attrs?.dnxte_hscroll?.advanced?.enabled?.desktop?.value); }

  function buildGroup() {
    return {
      groupName: 'dnxteHScroll',
      panel: 'design',
      priority: 92,
      multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Horizontal Scroll' } }
    };
  }

  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-hscroll', function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteHScroll) next.dnxteHScroll = buildGroup();
    return next;
  });

  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-hscroll', function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs.dnxte_hscroll = {
      type: 'object',
      selector: '{{selector}}',
      default: { advanced: {
        enabled:            { desktop: { value: 'off' } },
        direction:          { desktop: { value: 'ltr' } },
        itemNumber:         { desktop: { value: '' } },
        offsetLeft:         { desktop: { value: '0px' } },
        offsetRight:        { desktop: { value: '0px' } },
        scrubSpeed:         { desktop: { value: '1' } },
        startOffset:        { desktop: { value: 'top top' } },
        scrollLength:       { desktop: { value: '' } },
        progressBarEnabled: { desktop: { value: 'off' } },
        fade:               { desktop: { value: 'off' } },
        blur:               { desktop: { value: '0' } },
        rotate:             { desktop: { value: '0' } },
      }},
      settings: { advanced: {
        enabled: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.enabled', label: 'Enable Horizontal Scroll',
          description: 'Pin the section and scroll its child panels horizontally.',
          groupSlug: 'dnxteHScroll', priority: 1, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }
        }},
        direction: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.direction', label: 'Direction',
          groupSlug: 'dnxteHScroll', priority: 10, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'ltr': { label: 'Left to Right' },
            'rtl': { label: 'Right to Left' },
          } } },
          visible: isOn
        }},
        itemNumber: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.itemNumber', label: 'Visible Panels',
          description: 'Force N panels visible per viewport (blank = auto).',
          groupSlug: 'dnxteHScroll', priority: 12, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 1, max: 8, step: 1, defaultUnit: '' } },
          visible: isOn
        }},
        offsetLeft: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.offsetLeft', label: 'Start Padding',
          groupSlug: 'dnxteHScroll', priority: 14, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 500, step: 1, defaultUnit: 'px' } },
          visible: isOn
        }},
        offsetRight: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.offsetRight', label: 'End Padding',
          groupSlug: 'dnxteHScroll', priority: 16, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 500, step: 1, defaultUnit: 'px' } },
          visible: isOn
        }},
        scrubSpeed: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.scrubSpeed', label: 'Smoothness',
          description: 'Higher = looser / slower follow.',
          groupSlug: 'dnxteHScroll', priority: 18, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 5, step: 0.1, defaultUnit: '' } },
          visible: isOn
        }},
        startOffset: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.startOffset', label: 'Start Point',
          description: 'ScrollTrigger start, e.g. "top top".',
          groupSlug: 'dnxteHScroll', priority: 20, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/text' },
          visible: isOn
        }},
        scrollLength: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.scrollLength', label: 'Scroll Distance',
          description: 'Override scroll distance (blank = auto).',
          groupSlug: 'dnxteHScroll', priority: 22, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 5000, step: 10, defaultUnit: 'px' } },
          visible: isOn
        }},
        progressBarEnabled: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.progressBarEnabled', label: 'Progress Bar',
          groupSlug: 'dnxteHScroll', priority: 30, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: isOn
        }},

        // ── Extra reveal (fade / blur / tilt) ──
        fade: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.fade', label: 'Fade In',
          description: 'Fade each panel in as it scrolls into view.',
          groupSlug: 'dnxteHScroll', priority: 40, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: isOn
        }},
        blur: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.blur', label: 'Blur In',
          description: 'Start blurred, sharpen on reveal (0 = off).',
          groupSlug: 'dnxteHScroll', priority: 42, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 30, step: 1, defaultUnit: 'px' } },
          visible: isOn
        }},
        rotate: { groupType: 'group-item', item: {
          attrName: 'dnxte_hscroll.advanced.rotate', label: 'Tilt In',
          description: 'Start tilted, straighten on reveal (0 = off).',
          groupSlug: 'dnxteHScroll', priority: 44, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: -45, max: 45, step: 1, defaultUnit: 'deg' } },
          visible: isOn
        }},
      }}
    };

    if (meta && typeof meta === 'object') {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteHScroll) {
        meta.settings.groups.dnxteHScroll = buildGroup();
      }
    }

    return attrs;
  });
})();
