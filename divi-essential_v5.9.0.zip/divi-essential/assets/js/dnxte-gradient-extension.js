/**
 * Animated Gradient — Section Extension
 * Animates the section's EXISTING gradient background set via Divi's native BackgroundGroup.
 * No extra color pickers — reads colors from the computed gradient.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var el = wp.element;
  var ce = el.createElement;
  var TARGET = ['divi/section', 'divi/row', 'divi/column'];

  var GRADIENT_TYPES = {
    'color-shift':     { label: 'Color Shift' },
    'flowing-wave':    { label: 'Flowing Wave' },
    'radial-pulse':    { label: 'Radial Pulse' },
    'aurora':          { label: 'Aurora Borealis' },
    'mesh':            { label: 'Mesh Gradient' },
    'sunset':          { label: 'Sunset Animation' },
    'neon-pulse':      { label: 'Neon Pulse' },
    'liquid-metal':    { label: 'Liquid Metal' },
    'rotating-conic':  { label: 'Rotating Conic' },
    'ocean-waves':     { label: 'Ocean Waves' },
    'fire':            { label: 'Fire Blaze' },
    'holographic':     { label: 'Holographic' },
    'mouse-follow':    { label: 'Mouse Follow' },
    'stripe-wave':     { label: 'Stripe Wave' },
    'galaxy-swirl':    { label: 'Galaxy Swirl' },
    'plasma':          { label: 'Plasma Field' },
    'gradient-border': { label: 'Gradient Border' },
    'noise-grain':     { label: 'Noise Grain' },
    'scroll-reactive': { label: 'Scroll Reactive' },
    'morphing-blobs':  { label: 'Morphing Blobs' },
    'custom':          { label: 'Custom Animation' },
  };

  // Custom animation direction options
  var CUSTOM_DIRECTIONS = {
    'horizontal':  { label: 'Horizontal' },
    'vertical':    { label: 'Vertical' },
    'diagonal':    { label: 'Diagonal' },
    'radial':      { label: 'Radial' },
    'conic':       { label: 'Conic (Rotate)' },
  };

  // Custom animation movement options
  var CUSTOM_MOVEMENTS = {
    'shift':    { label: 'Color Shift' },
    'slide':    { label: 'Slide Position' },
    'rotate':   { label: 'Rotate Angle' },
    'pulse':    { label: 'Pulse Size' },
    'breathe':  { label: 'Breathe (Scale)' },
  };

  function isEnabled(p) {
    return 'on' === (p.attrs?.gradient_config?.advanced?.use_gradient_anim?.desktop?.value);
  }

  function getType(p) {
    return p.attrs?.gradient_config?.advanced?.gradient_type?.desktop?.value || 'color-shift';
  }

  // ════════════════════════════════════════════════════════════
  // 1. OPTION GROUP
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-gradient', function (groups, meta) {
    if (TARGET.indexOf(meta.name) === -1) return groups;
    groups.dnxteGradient = {
      groupName: 'dnxteGradient', panel: 'design', priority: 85, multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Animated Gradient' } }
    };
    return groups;
  });

  // ════════════════════════════════════════════════════════════
  // 2. ATTRIBUTES — just toggle, type, speed, intensity
  //    Colors come from Divi's native gradient background
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-gradient', function (attrs, meta) {
    if (TARGET.indexOf(meta.name) === -1) return attrs;

    attrs.gradient_config = {
      type: 'object',
      selector: '{{selector}}',
      default: {
        advanced: {
          use_gradient_anim:  { desktop: { value: 'off' } },
          gradient_type:      { desktop: { value: 'color-shift' } },
          speed:              { desktop: { value: '1' } },
          intensity:          { desktop: { value: '1' } },
          mouse_interactive:  { desktop: { value: 'off' } },
          mouse_strength:     { desktop: { value: '1' } },
          custom_direction:   { desktop: { value: 'horizontal' } },
          custom_movement:    { desktop: { value: 'slide' } },
          custom_angle:       { desktop: { value: '135' } },
          custom_range:       { desktop: { value: '100' } },
        }
      },
      settings: {
        advanced: {
          use_gradient_anim: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.use_gradient_anim',
              label: 'Animate Gradient',
              description: 'Animates the gradient set in Background settings',
              groupSlug: 'dnxteGradient', priority: 10, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' }
            }
          },
          gradient_type: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.gradient_type',
              label: 'Animation Type', groupSlug: 'dnxteGradient', priority: 15, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/select', props: { options: GRADIENT_TYPES } },
              visible: isEnabled
            }
          },
          speed: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.speed',
              label: 'Speed', groupSlug: 'dnxteGradient', priority: 20, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 3, step: 0.1, defaultUnit: '' } },
              visible: isEnabled
            }
          },
          intensity: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.intensity',
              label: 'Intensity', groupSlug: 'dnxteGradient', priority: 25, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 2, step: 0.1, defaultUnit: '' } },
              visible: isEnabled
            }
          },
          // ── Mouse Interactive ──
          mouse_interactive: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.mouse_interactive',
              label: 'Mouse Interactive',
              description: 'Gradient reacts to mouse movement on hover',
              groupSlug: 'dnxteGradient', priority: 30, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' },
              visible: isEnabled
            }
          },
          mouse_strength: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.mouse_strength',
              label: 'Mouse Strength',
              description: 'How strongly gradient reacts to mouse',
              groupSlug: 'dnxteGradient', priority: 31, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.2, max: 3, step: 0.1, defaultUnit: '' } },
              visible: function (p) {
                return isEnabled(p) && 'on' === (p.attrs?.gradient_config?.advanced?.mouse_interactive?.desktop?.value);
              }
            }
          },
          // ── Custom Animation Controls ──
          custom_direction: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.custom_direction',
              label: 'Direction', groupSlug: 'dnxteGradient', priority: 40, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/select', props: { options: CUSTOM_DIRECTIONS } },
              visible: function (p) {
                return isEnabled(p) && getType(p) === 'custom';
              }
            }
          },
          custom_movement: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.custom_movement',
              label: 'Movement Type', groupSlug: 'dnxteGradient', priority: 41, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/select', props: { options: CUSTOM_MOVEMENTS } },
              visible: function (p) {
                return isEnabled(p) && getType(p) === 'custom';
              }
            }
          },
          custom_angle: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.custom_angle',
              label: 'Start Angle',
              description: 'Gradient starting angle in degrees',
              groupSlug: 'dnxteGradient', priority: 42, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0, max: 360, step: 5, defaultUnit: '' } },
              visible: function (p) {
                return isEnabled(p) && getType(p) === 'custom';
              }
            }
          },
          custom_range: {
            groupType: 'group-item',
            item: {
              attrName: 'gradient_config.advanced.custom_range',
              label: 'Animation Range',
              description: 'How far the animation moves (percentage)',
              groupSlug: 'dnxteGradient', priority: 43, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 10, max: 200, step: 5, defaultUnit: '' } },
              visible: function (p) {
                return isEnabled(p) && getType(p) === 'custom';
              }
            }
          }
        }
      }
    };
    return attrs;
  });

  // ════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER
  // ════════════════════════════════════════════════════════════
  // Map module name to the CSS class to look for
  var MODULE_CLASS_MAP = {
    'divi/section': 'et_pb_section',
    'divi/row':     'et_pb_row',
    'divi/column':  'et_pb_column'
  };

  function GradientInjector(props) {
    var React = window.vendor.React;
    var ref = React.useRef(null);
    var instanceRef = React.useRef(null);
    var gc = props.moduleAttrs?.gradient_config?.advanced;
    var moduleName = props.moduleName;

    React.useEffect(function () {
      if (gc?.use_gradient_anim?.desktop?.value !== 'on') return;

      var timer = setTimeout(function () {
        if (!ref.current) return;

        // Find the correct element based on module type
        var targetClass = MODULE_CLASS_MAP[moduleName];
        var targetEl = ref.current.parentElement;

        while (targetEl) {
          // Check for the specific module class OR data-divi-renderer for VB preview
          if (targetEl.classList.contains(targetClass) ||
              (targetEl.dataset.diviRenderer && targetEl.dataset.diviRenderer.includes(moduleName))) {
            break;
          }
          targetEl = targetEl.parentElement;
        }

        // Fallback to immediate parent if target not found
        if (!targetEl) targetEl = ref.current.parentElement;
        if (!window.DnxteAnimatedGradient) return;

        // Extract colors from the target element's computed gradient
        var colors = extractGradientColors(targetEl);

        instanceRef.current = new window.DnxteAnimatedGradient(targetEl, {
          type:             gc?.gradient_type?.desktop?.value || 'color-shift',
          speed:            parseFloat(gc?.speed?.desktop?.value || 1),
          intensity:        parseFloat(gc?.intensity?.desktop?.value || 1),
          color1:           colors[0] || '#00d4aa',
          color2:           colors[1] || '#7c3aed',
          color3:           colors[2] || '#f472b6',
          color4:           colors[3] || '#3b82f6',
          mouseInteractive: gc?.mouse_interactive?.desktop?.value === 'on',
          mouseStrength:    parseFloat(gc?.mouse_strength?.desktop?.value || 1),
          customDirection:  gc?.custom_direction?.desktop?.value || 'horizontal',
          customMovement:   gc?.custom_movement?.desktop?.value || 'slide',
          customAngle:      parseFloat(gc?.custom_angle?.desktop?.value || 135),
          customRange:      parseFloat(gc?.custom_range?.desktop?.value || 100),
        });
      }, 200); // Slightly longer delay to ensure Divi has painted the gradient

      return function () {
        clearTimeout(timer);
        if (instanceRef.current) { instanceRef.current.destroy(); instanceRef.current = null; }
      };
    }, [
      gc?.use_gradient_anim?.desktop?.value,
      gc?.gradient_type?.desktop?.value,
      gc?.speed?.desktop?.value,
      gc?.intensity?.desktop?.value,
      gc?.mouse_interactive?.desktop?.value,
      gc?.mouse_strength?.desktop?.value,
      gc?.custom_direction?.desktop?.value,
      gc?.custom_movement?.desktop?.value,
      gc?.custom_angle?.desktop?.value,
      gc?.custom_range?.desktop?.value,
    ]);

    return ce('span', { ref: ref, style: { display: 'none', position: 'absolute', pointerEvents: 'none' } });
  }

  function rgbToHex(r, g, b) {
    return '#' + ((1 << 24) + (Math.round(r) << 16) + (Math.round(g) << 8) + Math.round(b)).toString(16).slice(1);
  }

  // Extract colors from computed background-image gradient, returns hex strings
  function extractGradientColors(el) {
    var bg = getComputedStyle(el).backgroundImage || '';
    // Also check inline style background
    if (!bg || bg === 'none') bg = el.style.background || el.style.backgroundImage || '';
    var colors = [];
    // Match rgb/rgba colors and convert to hex
    var rgbRegex = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*[\d.]+)?\s*\)/g;
    var match;
    while ((match = rgbRegex.exec(bg)) !== null) {
      colors.push(rgbToHex(parseInt(match[1]), parseInt(match[2]), parseInt(match[3])));
    }
    // Fallback: try hex
    if (colors.length === 0) {
      var hexRegex = /#[0-9a-fA-F]{3,8}/g;
      var hm;
      while ((hm = hexRegex.exec(bg)) !== null) {
        colors.push(hm[0]);
      }
    }
    return colors;
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-gradient', function (wrapper, param) {
    if (TARGET.indexOf(param.name) === -1) return wrapper;
    if (param.attrs?.gradient_config?.advanced?.use_gradient_anim?.desktop?.value !== 'on') return wrapper;

    var children = wrapper.props.children;
    var arr = Array.isArray(children) ? children : [children];
    return el.cloneElement(wrapper, {}, arr.concat([
      ce(GradientInjector, { key: 'dnxte-gradient-injector', moduleAttrs: param.attrs, moduleName: param.name })
    ]));
  });
})();
