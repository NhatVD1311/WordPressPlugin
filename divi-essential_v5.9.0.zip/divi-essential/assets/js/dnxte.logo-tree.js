(function() {
  'use strict';

  // ============================================================
  // CSS Injection (keyframes + base styles for dynamic elements)
  // ============================================================
  var styleInjected = false;

  function injectStyles() {
    if (styleInjected) return;
    styleInjected = true;

    var css = [
      '@keyframes ltParticleFloat {',
      '  0%, 100% { transform: translate(0, 0) scale(1); opacity: 0; }',
      '  10% { opacity: 1; }',
      '  90% { opacity: 1; }',
      '  50% { transform: translate(var(--lt-px, 30px), var(--lt-py, -40px)) scale(1.2); }',
      '}',
      '@keyframes ltStarTwinkle {',
      '  0%, 100% { opacity: 0.2; transform: scale(0.8); }',
      '  50% { opacity: 1; transform: scale(1.2); }',
      '}',
      '@keyframes ltAuroraWave {',
      '  0% { transform: translateX(-100%) skewX(-15deg); opacity: 0.3; }',
      '  50% { opacity: 0.6; }',
      '  100% { transform: translateX(100%) skewX(15deg); opacity: 0.3; }',
      '}',
      '@keyframes ltMeshPulse {',
      '  0%, 100% { opacity: 0.15; }',
      '  50% { opacity: 0.35; }',
      '}',
      '@keyframes ltFlowDot {',
      '  0% { offset-distance: 0%; opacity: 0; }',
      '  5% { opacity: 1; }',
      '  95% { opacity: 1; }',
      '  100% { offset-distance: 100%; opacity: 0; }',
      '}',
      '@keyframes ltNodeEntry {',
      '  0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); }',
      '  100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }',
      '}',
      '@keyframes ltPathDraw {',
      '  0% { stroke-dashoffset: var(--lt-path-length, 1000); }',
      '  100% { stroke-dashoffset: 0; }',
      '}',

      /* Background effects containers */
      '.logo-tree-bg-layer {',
      '  position: absolute; top: 0; left: 0; width: 100%; height: 100%;',
      '  pointer-events: none; overflow: hidden; z-index: 0;',
      '}',

      /* Particles */
      '.logo-tree-particle {',
      '  position: absolute; border-radius: 50%;',
      '  animation: ltParticleFloat var(--lt-pdur, 8s) var(--lt-pdel, 0s) infinite ease-in-out;',
      '}',

      /* Stars */
      '.logo-tree-star {',
      '  position: absolute; border-radius: 50%; background: currentColor;',
      '  animation: ltStarTwinkle var(--lt-sdur, 3s) var(--lt-sdel, 0s) infinite ease-in-out;',
      '}',

      /* Mesh lines */
      '.logo-tree-mesh-line {',
      '  position: absolute; background: var(--lt-line-color, rgba(139,92,246,0.2));',
      '  animation: ltMeshPulse var(--lt-mdur, 4s) var(--lt-mdel, 0s) infinite ease-in-out;',
      '}',

      /* Aurora waves */
      '.logo-tree-aurora-wave {',
      '  position: absolute; top: 0; left: 0; width: 200%; height: 100%;',
      '  animation: ltAuroraWave var(--lt-adur, 8s) var(--lt-adel, 0s) infinite ease-in-out;',
      '}',

      /* SVG */
      '.logo-tree-svg {',
      '  position: absolute; top: 0; left: 0; width: 100%; height: 100%;',
      '  pointer-events: none; z-index: 1;',
      '}',
      '.logo-tree-path-glow {',
      '  fill: none; stroke: var(--lt-line-glow, rgba(139,92,246,0.3));',
      '  stroke-width: 6; stroke-linecap: round;',
      '  filter: blur(4px);',
      '}',
      '.logo-tree-path-main {',
      '  fill: none; stroke: var(--lt-line-color, rgba(139,92,246,0.6));',
      '  stroke-width: 2; stroke-linecap: round;',
      '}',
      '.logo-tree-path-animated {',
      '  stroke-dasharray: var(--lt-path-length, 1000);',
      '  stroke-dashoffset: var(--lt-path-length, 1000);',
      '  animation: ltPathDraw 1.5s ease forwards;',
      '}',

      /* Flow dots */
      '.logo-tree-flow-dot {',
      '  width: 4px; height: 4px; border-radius: 50%;',
      '  background: var(--lt-accent-color, #a78bfa);',
      '  box-shadow: 0 0 6px var(--lt-accent-color, #a78bfa);',
      '  position: absolute;',
      '  offset-rotate: 0deg;',
      '  animation: ltFlowDot var(--lt-fdur, 3s) var(--lt-fdel, 0s) infinite ease-in-out;',
      '}'
    ].join('\n');

    var styleEl = document.createElement('style');
    styleEl.setAttribute('data-logo-tree-styles', '');
    styleEl.textContent = css;
    document.head.appendChild(styleEl);
  }

  // ============================================================
  // Background Effect Generators
  // ============================================================

  function createBgLayer(container) {
    var existing = container.querySelector('.logo-tree-bg-layer');
    if (existing) existing.remove();
    var layer = document.createElement('div');
    layer.className = 'logo-tree-bg-layer';
    container.insertBefore(layer, container.firstChild);
    return layer;
  }

  function generateParticles(container, count, color) {
    var layer = createBgLayer(container);
    var rect = container.getBoundingClientRect();
    for (var i = 0; i < count; i++) {
      var p = document.createElement('div');
      p.className = 'logo-tree-particle';
      var size = Math.random() * 4 + 2;
      var x = Math.random() * rect.width;
      var y = Math.random() * rect.height;
      var dx = (Math.random() - 0.5) * 80;
      var dy = (Math.random() - 0.5) * 80;
      var dur = Math.random() * 6 + 5;
      var del = Math.random() * 5;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.left = x + 'px';
      p.style.top = y + 'px';
      p.style.background = color;
      p.style.setProperty('--lt-px', dx + 'px');
      p.style.setProperty('--lt-py', dy + 'px');
      p.style.setProperty('--lt-pdur', dur + 's');
      p.style.setProperty('--lt-pdel', del + 's');
      layer.appendChild(p);
    }
    return layer;
  }

  function generateStars(container, count, color) {
    var layer = createBgLayer(container);
    var rect = container.getBoundingClientRect();
    for (var i = 0; i < count; i++) {
      var s = document.createElement('div');
      s.className = 'logo-tree-star';
      var size = Math.random() * 3 + 1;
      s.style.width = size + 'px';
      s.style.height = size + 'px';
      s.style.left = Math.random() * rect.width + 'px';
      s.style.top = Math.random() * rect.height + 'px';
      s.style.color = color;
      s.style.setProperty('--lt-sdur', (Math.random() * 4 + 2) + 's');
      s.style.setProperty('--lt-sdel', (Math.random() * 5) + 's');
      layer.appendChild(s);
    }
    return layer;
  }

  function generateMesh(container, color) {
    var layer = createBgLayer(container);
    var rect = container.getBoundingClientRect();
    var spacing = 60;
    var cols = Math.ceil(rect.width / spacing);
    var rows = Math.ceil(rect.height / spacing);

    for (var r = 0; r <= rows; r++) {
      var line = document.createElement('div');
      line.className = 'logo-tree-mesh-line';
      line.style.width = '100%';
      line.style.height = '1px';
      line.style.top = (r * spacing) + 'px';
      line.style.left = '0';
      line.style.background = color;
      line.style.setProperty('--lt-mdur', (Math.random() * 3 + 3) + 's');
      line.style.setProperty('--lt-mdel', (Math.random() * 2) + 's');
      layer.appendChild(line);
    }

    for (var c = 0; c <= cols; c++) {
      var vline = document.createElement('div');
      vline.className = 'logo-tree-mesh-line';
      vline.style.width = '1px';
      vline.style.height = '100%';
      vline.style.top = '0';
      vline.style.left = (c * spacing) + 'px';
      vline.style.background = color;
      vline.style.setProperty('--lt-mdur', (Math.random() * 3 + 3) + 's');
      vline.style.setProperty('--lt-mdel', (Math.random() * 2) + 's');
      layer.appendChild(vline);
    }
    return layer;
  }

  function generateAurora(container, color) {
    var layer = createBgLayer(container);
    for (var i = 0; i < 3; i++) {
      var wave = document.createElement('div');
      wave.className = 'logo-tree-aurora-wave';
      wave.style.background = 'linear-gradient(90deg, transparent, ' + color + ', transparent)';
      wave.style.top = (20 + i * 25) + '%';
      wave.style.height = '30%';
      wave.style.opacity = '0.3';
      wave.style.filter = 'blur(40px)';
      wave.style.setProperty('--lt-adur', (6 + i * 2) + 's');
      wave.style.setProperty('--lt-adel', (i * 1.5) + 's');
      layer.appendChild(wave);
    }
    return layer;
  }

  function generateGradient(container) {
    var layer = createBgLayer(container);
    return layer;
  }

  function applyBackground(container, effect, particleCount, color) {
    switch (effect) {
      case 'particles':
        generateParticles(container, particleCount, color);
        break;
      case 'stars':
        generateStars(container, Math.floor(particleCount * 1.5), color);
        break;
      case 'mesh':
        generateMesh(container, color);
        break;
      case 'aurora':
        generateAurora(container, color);
        break;
      case 'gradient':
      default:
        generateGradient(container);
        break;
    }
  }

  // ============================================================
  // SVG Path Generation
  // ============================================================

  function generatePath(mainX, startPointY, endX, endY, nodeSize, lineStyle) {
    var targetY = endY - nodeSize / 2 - 5;
    if (lineStyle === 'straight') {
      return 'M ' + mainX + ' ' + startPointY + ' L ' + endX + ' ' + targetY;
    }
    if (lineStyle === 'wave') {
      var midX = (mainX + endX) / 2;
      var midY = startPointY + (targetY - startPointY) * 0.5;
      var amplitude = Math.abs(endX - mainX) * 0.1;
      return 'M ' + mainX + ' ' + startPointY +
        ' Q ' + mainX + ' ' + (midY - amplitude) + ', ' + midX + ' ' + midY +
        ' Q ' + endX + ' ' + (midY + amplitude) + ', ' + endX + ' ' + targetY;
    }
    var cMidY = startPointY + (targetY - startPointY) * 0.4;
    return 'M ' + mainX + ' ' + startPointY +
      ' C ' + mainX + ' ' + cMidY + ', ' + endX + ' ' + cMidY + ', ' + endX + ' ' + targetY;
  }

  function createSvgElement(tag, attrs) {
    var el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    if (attrs) {
      for (var key in attrs) {
        if (attrs.hasOwnProperty(key)) {
          el.setAttribute(key, attrs[key]);
        }
      }
    }
    return el;
  }

  // ============================================================
  // Position Calculation (with per-node custom positions)
  // ============================================================

  function calculateNodePositions(nodeEls, width, height) {
    var count = nodeEls.length;
    if (count === 0) return [];

    var padding = 50;
    var startY = height * 0.28;
    var defaultNodeSize = 65;

    var autoNodes = [];
    var customNodes = [];
    var nodeArr = Array.prototype.slice.call(nodeEls);

    // Separate custom-positioned nodes from auto-positioned
    nodeArr.forEach(function(nodeEl) {
      var posX = parseFloat(nodeEl.getAttribute('data-position-x') || '-1');
      var posY = parseFloat(nodeEl.getAttribute('data-position-y') || '-1');
      var ns = parseInt(nodeEl.getAttribute('data-node-size') || '65', 10);

      if (posX >= 0 && posY >= 0) {
        customNodes.push({
          el: nodeEl,
          x: (posX / 100) * width,
          y: (posY / 100) * height,
          nodeSize: ns
        });
      } else {
        autoNodes.push({ el: nodeEl, nodeSize: ns });
      }
    });

    var positions = [];

    // Auto-layout for nodes without custom positions
    if (autoNodes.length > 0) {
      var availableWidth = width - padding * 2;
      var maxPerRow = Math.max(1, Math.floor(availableWidth / (defaultNodeSize + 30)));

      var rows = [];
      if (autoNodes.length <= maxPerRow) {
        rows = [autoNodes];
      } else if (autoNodes.length <= maxPerRow * 2) {
        var firstRow = Math.ceil(autoNodes.length / 2);
        rows = [autoNodes.slice(0, firstRow), autoNodes.slice(firstRow)];
      } else {
        var perRow = Math.ceil(autoNodes.length / 3);
        rows = [autoNodes.slice(0, perRow), autoNodes.slice(perRow, perRow * 2), autoNodes.slice(perRow * 2)];
      }

      var rowHeight = (height - startY - padding) / rows.length;

      rows.forEach(function(row, rowIndex) {
        var y = startY + rowIndex * rowHeight + rowHeight * 0.4;
        var spacing = (width - padding * 2) / (row.length + 1);
        row.forEach(function(nodeData, itemIndex) {
          var x = padding + spacing * (itemIndex + 1);
          var waveOffset = Math.sin((itemIndex / Math.max(row.length, 1)) * Math.PI) * 15;
          positions.push({ el: nodeData.el, x: x, y: y + waveOffset, nodeSize: nodeData.nodeSize });
        });
      });
    }

    // Add custom-positioned nodes
    customNodes.forEach(function(cn) {
      positions.push(cn);
    });

    return positions;
  }

  // ============================================================
  // Flow Dots
  // ============================================================

  function createFlowDots(container, svg, pathElements, accentColor) {
    var existing = container.querySelectorAll('.logo-tree-flow-dot');
    existing.forEach(function(d) { d.remove(); });

    pathElements.forEach(function(pathData, index) {
      var pathEl = pathData.mainPath;
      if (!pathEl) return;

      var pathLength = pathEl.getTotalLength();
      if (pathLength < 10) return;

      for (var d = 0; d < 2; d++) {
        var dot = document.createElement('div');
        dot.className = 'logo-tree-flow-dot';
        dot.style.setProperty('--lt-fdur', (3 + Math.random() * 2) + 's');
        dot.style.setProperty('--lt-fdel', (d * 1.5 + index * 0.3) + 's');

        var pathD = pathEl.getAttribute('d');
        dot.style.offsetPath = 'path("' + pathD + '")';
        dot.style.background = accentColor;
        dot.style.boxShadow = '0 0 6px ' + accentColor;

        container.appendChild(dot);
      }
    });
  }

  // ============================================================
  // Main Initialization
  // ============================================================

  function buildTree(el) {
    var bgEffect = el.getAttribute('data-tree-background') || 'particles';
    var lineStyle = el.getAttribute('data-tree-line-style') || 'bezier';
    var particleCount = parseInt(el.getAttribute('data-tree-particles') || '80', 10);

    var lineColor = el.getAttribute('data-line-color') || 'rgba(139, 92, 246, 0.6)';
    var lineGlowColor = el.getAttribute('data-line-glow-color') || 'rgba(139, 92, 246, 0.3)';
    var particleColor = el.getAttribute('data-particle-color') || 'rgba(139, 92, 246, 0.4)';
    var flowDotColor = el.getAttribute('data-flow-dot-color') || '#a78bfa';

    el.style.setProperty('--lt-line-color', lineColor);
    el.style.setProperty('--lt-line-glow', lineGlowColor);
    el.style.setProperty('--lt-accent-color', flowDotColor);
    el.style.setProperty('--lt-particle-color', particleColor);

    var mainEl = el.querySelector('.logo-tree-main');
    var nodeEls = el.querySelectorAll('.logo-tree-node');

    var rect = el.getBoundingClientRect();
    var width = rect.width;
    var height = rect.height;

    if (width < 10 || height < 10) return;

    var mainY = height * 0.1;
    if (mainEl) {
      mainEl.style.top = mainY + 'px';
    }

    // Apply per-node sizes from data attribute
    nodeEls.forEach(function(nodeEl) {
      var ns = parseInt(nodeEl.getAttribute('data-node-size') || '65', 10);
      nodeEl.style.width = ns + 'px';
      nodeEl.style.height = ns + 'px';
    });

    // Calculate positions (handles per-node custom positions)
    var positions = calculateNodePositions(nodeEls, width, height);
    positions.forEach(function(pos) {
      pos.el.style.left = pos.x + 'px';
      pos.el.style.top = pos.y + 'px';
    });

    // Remove old SVG
    var oldSvg = el.querySelector('.logo-tree-svg');
    if (oldSvg) oldSvg.remove();

    // Create SVG
    var svg = createSvgElement('svg', {
      'class': 'logo-tree-svg',
      'viewBox': '0 0 ' + width + ' ' + height,
      'preserveAspectRatio': 'xMidYMid meet'
    });

    var mainX = width / 2;
    var startPointY = mainY + 50;

    // Draw paths
    var pathElements = [];
    positions.forEach(function(pos, index) {
      var d = generatePath(mainX, startPointY, pos.x, pos.y, pos.nodeSize, lineStyle);
      var g = createSvgElement('g');

      var glowPath = createSvgElement('path', {
        'd': d,
        'class': 'logo-tree-path-glow'
      });
      g.appendChild(glowPath);

      var mainPath = createSvgElement('path', {
        'd': d,
        'class': 'logo-tree-path-main logo-tree-path-animated'
      });
      g.appendChild(mainPath);

      svg.appendChild(g);
      pathElements.push({ mainPath: mainPath, glowPath: glowPath });

      setTimeout(function() {
        try {
          var len = mainPath.getTotalLength();
          mainPath.style.setProperty('--lt-path-length', len);
          mainPath.setAttribute('stroke-dasharray', len);
          mainPath.setAttribute('stroke-dashoffset', len);
          mainPath.getBoundingClientRect();
          mainPath.style.animation = 'ltPathDraw 1.5s ' + (index * 0.1) + 's ease forwards';
        } catch (e) {}
      }, 0);
    });

    if (mainEl) {
      el.insertBefore(svg, mainEl);
    } else {
      el.appendChild(svg);
    }

    applyBackground(el, bgEffect, particleCount, particleColor);

    setTimeout(function() {
      createFlowDots(el, svg, pathElements, flowDotColor);
    }, 100);

    positions.forEach(function(pos, index) {
      pos.el.style.opacity = '0';
      pos.el.style.animation = 'ltNodeEntry 0.5s ' + (0.3 + index * 0.08) + 's ease forwards';
    });
  }

  function initLogoTree() {
    var containers = document.querySelectorAll('[data-logo-tree]');
    containers.forEach(function(el) {
      if (el._logoTreeInit) return;

      buildTree(el);

      var resizeTimer = null;

      var resizeObserver = new ResizeObserver(function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
          buildTree(el);
        }, 150);
      });
      resizeObserver.observe(el);

      // MutationObserver for container-level data attribute changes
      var containerObserver = new MutationObserver(function(mutations) {
        var shouldRebuild = false;
        mutations.forEach(function(m) {
          if (m.attributeName && m.attributeName.indexOf('data-') === 0) {
            shouldRebuild = true;
          }
        });
        if (shouldRebuild) {
          buildTree(el);
        }
      });
      containerObserver.observe(el, {
        attributes: true,
        attributeFilter: [
          'data-tree-background',
          'data-tree-line-style',
          'data-tree-particles',
          'data-line-color',
          'data-line-glow-color',
          'data-particle-color',
          'data-flow-dot-color'
        ]
      });

      // MutationObserver for individual node data attribute changes (MultiView responsive)
      var nodeEls = el.querySelectorAll('.logo-tree-node');
      nodeEls.forEach(function(nodeEl) {
        var nodeObserver = new MutationObserver(function(mutations) {
          var shouldRebuild = false;
          mutations.forEach(function(m) {
            if (m.attributeName === 'data-node-size' ||
                m.attributeName === 'data-position-x' ||
                m.attributeName === 'data-position-y') {
              shouldRebuild = true;
            }
          });
          if (shouldRebuild) {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
              buildTree(el);
            }, 50);
          }
        });
        nodeObserver.observe(nodeEl, {
          attributes: true,
          attributeFilter: ['data-node-size', 'data-position-x', 'data-position-y']
        });
      });

      // Handle clicks on nodes with links
      el.addEventListener('click', function(e) {
        var nodeEl = e.target.closest('.logo-tree-node');
        if (!nodeEl) return;
        var link = nodeEl.getAttribute('data-node-link');
        if (link) {
          window.open(link, '_blank', 'noopener');
        }
      });

      el._logoTreeInit = true;
    });
  }

  // ============================================================
  // Bootstrap
  // ============================================================

  injectStyles();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLogoTree);
  } else {
    initLogoTree();
  }

  window.addEventListener('load', initLogoTree);

  if (typeof MutationObserver !== 'undefined') {
    var bodyObserver = new MutationObserver(function(mutations) {
      var hasNewTree = false;
      mutations.forEach(function(m) {
        if (m.addedNodes && m.addedNodes.length) {
          for (var i = 0; i < m.addedNodes.length; i++) {
            var node = m.addedNodes[i];
            if (node.nodeType === 1) {
              if (node.hasAttribute && node.hasAttribute('data-logo-tree')) {
                hasNewTree = true;
              } else if (node.querySelector && node.querySelector('[data-logo-tree]')) {
                hasNewTree = true;
              }
            }
          }
        }
      });
      if (hasNewTree) {
        initLogoTree();
      }
    });

    if (document.body) {
      bodyObserver.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', function() {
        bodyObserver.observe(document.body, { childList: true, subtree: true });
      });
    }
  }

})();
