/**
 * Read More — shared runtime engine (Divi 5)
 *
 * Used by BOTH the frontend and the Visual Builder canvas, so the editor preview
 * and the published page cannot drift.
 *
 * This is a dependency-free rewrite of the Divi 4 runtime
 * (assets/js/divi-4/jquery.expander.min.js). Two reasons it is not reused:
 *
 *  1. jQuery is not guaranteed in the Divi 5 VB app window.
 *  2. The D4 script wraps the target in a new `.expandable` parent, relocating a
 *     node React owns, which breaks reconciliation on the next render. This engine
 *     only sets inline styles on the module node and appends one child, so nothing
 *     React owns is ever moved.
 *
 * Behaviour, defaults and breakpoints are kept identical to the Divi 4 script.
 * The Divi 4 extension still uses its own runtime and is unaffected by this file.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var BAR_CLASS = 'dnxte-rm-bar';
  var INLINE_CLASS = 'dnxte-rm-inline';
  var STYLE_ID = 'dnxte-readmore-inline-css';
  var SHOW_TEXT = 4; // NodeFilter.SHOW_TEXT, spelled out so no cross-window global is needed.

  /**
   * Easing curves the toggle accepts. The value ends up in an inline
   * `transition` declaration, so it is resolved through this map rather than
   * passed through — an unknown keyword falls back to `ease`.
   */
  var EASINGS = {
    'ease':        'ease',
    'linear':      'linear',
    'ease-in':     'ease-in',
    'ease-out':    'ease-out',
    'ease-in-out': 'ease-in-out',
    'back-out':    'cubic-bezier(0.34,1.56,0.64,1)'
  };

  /**
   * Baseline styles, injected once. Mirrors assets/css/divi-4/jquery.expandable.css
   * but targets this engine's flatter DOM (bar is a child of the module, not a
   * sibling inside a generated `.expandable` wrapper).
   */
  function injectStyles(doc) {
    if (doc.getElementById(STYLE_ID)) return;
    var style = doc.createElement('style');
    style.id = STYLE_ID;
    style.textContent =
      // --dnxte-rm-bg is the one knob for the bar's colour, written by the
      // Background Color setting. Height mode falls back to white (it has to
      // mask the clamped text); the inline bar of word mode sits in the text
      // flow and falls back to transparent.
      '.' + BAR_CLASS + '{position:absolute;left:0;bottom:0;width:100%;' +
      'display:inline-flex;align-items:center;box-sizing:border-box;cursor:pointer;' +
      'text-decoration:none;background-color:var(--dnxte-rm-bg,#fff);font-weight:500;' +
      'line-height:1;font-size:16px;z-index:2;}' +
      // Kept as a bare 20px spacer above the bar — no fade, so the text runs
      // right up to it and the bar's own background is the only masking.
      '.' + BAR_CLASS + '::before{position:absolute;width:100%;height:20px;top:-20px;' +
      'left:0;display:block;content:"";pointer-events:none;}' +
      '.' + BAR_CLASS + ' i::before,.' + BAR_CLASS + ' i::after{font-family:ETmodules;' +
      'font-weight:400;font-variant:normal;text-transform:none;line-height:1;' +
      '-webkit-font-smoothing:antialiased;font-size:inherit;font-style:normal;' +
      'display:inline-block;box-sizing:border-box;direction:ltr;}' +
      '.' + BAR_CLASS + ' i::before{content:"\\33";}' +
      '.' + BAR_CLASS + '.dnxte-rm-expanded i::before{display:none;}' +
      '.' + BAR_CLASS + ' i::after{content:"\\32";display:none;}' +
      '.' + BAR_CLASS + '.dnxte-rm-expanded i::after{display:inline-flex;}' +
      // Word-count mode does not clamp the box, so the bar flows after the
      // trimmed text instead of floating over the bottom of it.
      '.' + BAR_CLASS + '.' + INLINE_CLASS + '{position:static;width:auto;' +
      'background-color:var(--dnxte-rm-bg,transparent);}' +
      '.' + BAR_CLASS + '.' + INLINE_CLASS + '::before{display:none;}';
    (doc.head || doc.documentElement).appendChild(style);
  }

  /** Matches the Divi 4 thresholds in jquery.expander.min.js lines 88-94. */
  function disabledOnThisDevice(mode, width) {
    if ('phone' === mode) return width > 0 && width <= 767;
    if ('tablet' === mode) return width >= 768 && width <= 980;
    if ('desktop' === mode) return width > 980;
    return false;
  }

  /** Read config off the data-readmore-* attributes the PHP filter emits. */
  function configFromDataset(el) {
    var d = el.dataset;
    return {
      // 'height' clamps the box; 'words' trims the text after a word count.
      trim: d.readmoreTrim || 'height',
      words: parseInt(d.readmoreWords, 10) || 50,
      height: parseFloat(d.readmoreHeight) || 200,
      // 0 keeps the old instant toggle.
      duration: undefined === d.readmoreDuration ? 400 : (parseInt(d.readmoreDuration, 10) || 0),
      easing: d.readmoreEasing || 'ease',
      more: d.readmoreText || 'Read more',
      less: d.readmoreLessText || 'Read less',
      // D4 semantics: no_less 'on' means KEEP showing the "less" link.
      keepLess: 'off' !== d.readmoreNoLess,
      device: d.readmoreDisableOnDevice || 'none',
      fontSize: d.readmoreFontSize || '',
      fontCss: d.readmoreFontCss || '',
      hoverColor: d.readmoreHoverColor || '',
      bg: d.readmoreBg || '',
      shadow: d.readmoreShadow || '',
      customCss: d.readmoreCustomCss || ''
    };
  }

  function DnxteReadMore(el, config) {
    this.el = el;
    this.cfg = config || configFromDataset(el);
    this.expanded = false;
    this.textNodes = [];
    this.hiddenEls = [];
    this.totalWords = 0;

    var doc = el.ownerDocument;
    injectStyles(doc);

    this.prev = {
      height: el.style.height,
      overflow: el.style.overflow,
      position: el.style.position,
      transition: el.style.transition
    };

    var byWords = this.byWords();

    if (byWords) {
      // Word mode leaves the box alone — it shortens the text instead — so the
      // original overflow/position are never touched. Snapshot before the bar is
      // appended so the bar's own label can never be counted as content.
      this.snapshotText();
    } else {
      var computedPos = doc.defaultView.getComputedStyle(el).position;
      if (!computedPos || 'static' === computedPos) {
        el.style.position = 'relative';
      }
      el.style.overflow = 'hidden';
    }

    var bar = doc.createElement('a');
    bar.className = byWords ? BAR_CLASS + ' ' + INLINE_CLASS : BAR_CLASS;
    bar.setAttribute('href', '#');
    bar.innerHTML = '<span class="dnxte-rm-more"></span>' +
                    '<span class="dnxte-rm-less" style="display:none"></span><i></i>';
    bar.querySelector('.dnxte-rm-more').textContent = this.cfg.more;
    bar.querySelector('.dnxte-rm-less').textContent = this.cfg.less;
    this.applyBarStyles(bar);

    this._onClick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      this.toggle();
    }.bind(this);
    bar.addEventListener('click', this._onClick);

    if (this.cfg.hoverColor) {
      this._baseColor = bar.style.color;
      this._onEnter = function () { bar.style.color = this.cfg.hoverColor; }.bind(this);
      this._onLeave = function () { bar.style.color = this._baseColor || ''; }.bind(this);
      bar.addEventListener('mouseenter', this._onEnter);
      bar.addEventListener('mouseleave', this._onLeave);
    }

    el.appendChild(bar);
    this.bar = bar;

    this._onResize = this.refresh.bind(this);
    doc.defaultView.addEventListener('resize', this._onResize);

    this.refresh();
  }

  DnxteReadMore.prototype.byWords = function () {
    return 'words' === this.cfg.trim;
  };

  function wordsIn(text) {
    var trimmed = text.trim();
    return trimmed ? trimmed.split(/\s+/).length : 0;
  }

  /**
   * Record every text node the module owns, with its original value.
   *
   * Trimming only ever rewrites `nodeValue` on these nodes and toggles `display`
   * on the elements it empties — no node is created, moved or removed — so React
   * keeps owning the same DOM it rendered and reconciliation stays intact.
   */
  DnxteReadMore.prototype.snapshotText = function () {
    var walker = this.el.ownerDocument.createTreeWalker(this.el, SHOW_TEXT, null, false);
    var nodes = [];
    var total = 0;
    var node;

    while ((node = walker.nextNode())) {
      var tag = node.parentNode ? node.parentNode.nodeName : '';
      if ('SCRIPT' === tag || 'STYLE' === tag) continue;
      if (!node.nodeValue || !node.nodeValue.trim()) continue;
      nodes.push({ node: node, text: node.nodeValue, clamped: undefined });
      total += wordsIn(node.nodeValue);
    }

    this.textNodes = nodes;
    this.totalWords = total;
  };

  /**
   * Put every text node and emptied element back the way it was found.
   *
   * A node whose value is no longer the trimmed string this instance wrote has
   * been rewritten by someone else — React re-rendering the module while the
   * author types in the VB — so its snapshot is stale and restoring it would
   * paste the old copy back over the new one. Those nodes are left alone.
   */
  DnxteReadMore.prototype.restoreText = function () {
    for (var i = 0; i < this.textNodes.length; i++) {
      var item = this.textNodes[i];
      if (undefined === item.clamped) continue;
      if (item.node.nodeValue === item.clamped) item.node.nodeValue = item.text;
      item.clamped = undefined;
    }
    for (var j = 0; j < this.hiddenEls.length; j++) {
      this.hiddenEls[j].el.style.display = this.hiddenEls[j].display;
    }
    this.hiddenEls = [];
  };

  /** Cut the content down to cfg.words words, ellipsis included. */
  DnxteReadMore.prototype.clampWords = function () {
    // Always trim from the pristine text so repeated calls (resize, re-collapse)
    // cannot compound.
    this.restoreText();

    var limit = this.cfg.words;
    var used = 0;
    var i;

    // Elements that carry text now; the ones this pass empties get hidden, so an
    // emptied paragraph does not leave a blank line behind. Elements that were
    // already empty (spacers, dividers) are never in this list and stay visible.
    var all = this.el.querySelectorAll('*');
    var carried = [];
    for (i = 0; i < all.length; i++) {
      if (all[i] === this.bar || (this.bar && this.bar.contains(all[i]))) continue;
      if (all[i].textContent && all[i].textContent.trim()) carried.push(all[i]);
    }

    for (i = 0; i < this.textNodes.length; i++) {
      var entry = this.textNodes[i];
      if (used >= limit) {
        entry.clamped = '';
        entry.node.nodeValue = '';
        continue;
      }
      var words = entry.text.trim().split(/\s+/);
      if (used + words.length <= limit) {
        used += words.length;
        continue;
      }
      entry.clamped = words.slice(0, limit - used).join(' ') + '\u2026 ';
      entry.node.nodeValue = entry.clamped;
      used = limit;
    }

    for (i = 0; i < carried.length; i++) {
      if (carried[i].textContent.trim()) continue;
      this.hiddenEls.push({ el: carried[i], display: carried[i].style.display });
      carried[i].style.display = 'none';
    }
  };

  /**
   * text-align maps to justify-content on the bar.
   *
   * The bar is an inline-flex container whose label and icon are flex items, so
   * the text-align the typography group emits never reaches them — alignment
   * silently did nothing. Mirroring it onto justify-content aligns the whole
   * label+icon pair, which is what the control implies.
   */
  var ALIGN_TO_JUSTIFY = {
    left: 'flex-start',
    start: 'flex-start',
    center: 'center',
    right: 'flex-end',
    end: 'flex-end',
    justify: 'space-between'
  };

  DnxteReadMore.prototype.applyBarStyles = function (bar) {
    var c = this.cfg;
    // The whole font group, already serialised to CSS text by the PHP side.
    if (c.fontCss) bar.style.cssText += c.fontCss;
    if (c.fontSize) bar.style.fontSize = c.fontSize;
    // Set as properties, never concatenated into cssText, so a value coming from
    // the settings can only ever be a colour/shadow — the CSSOM drops anything else.
    if (c.bg) bar.style.setProperty('--dnxte-rm-bg', c.bg);
    if (c.shadow) bar.style.boxShadow = c.shadow;
    // User CSS wins over everything above.
    if (c.customCss) bar.style.cssText += c.customCss;

    var justify = ALIGN_TO_JUSTIFY[bar.style.textAlign];
    // Only when the author has not aligned it themselves via custom CSS.
    if (justify && !bar.style.justifyContent) bar.style.justifyContent = justify;
  };

  DnxteReadMore.prototype.reducedMotion = function () {
    var win = this.el.ownerDocument.defaultView;
    return !!(win.matchMedia && win.matchMedia('(prefers-reduced-motion: reduce)').matches);
  };

  /**
   * Finish any animation in flight right now, landing on its end state.
   *
   * Called before starting a new one (rapid clicking) and before refresh()
   * rewrites the height itself, so the two can never fight over the box.
   */
  DnxteReadMore.prototype.cancelAnimation = function () {
    if (this._settle) this._settle();
  };

  /**
   * Animate the module's height between two measured values, then hand the box
   * back to whatever static state the caller asked for.
   *
   * `finalHeight`/`finalOverflow` are the inline values to leave behind: height
   * mode keeps its clamp and its hidden overflow, word mode owns neither and
   * gets its originals back.
   *
   * `finalize` is the content change that must not be visible until the box has
   * finished travelling — the word-mode trim, which would otherwise wipe the
   * text on the first frame and leave an empty box to shrink.
   */
  DnxteReadMore.prototype.animateHeight = function (from, to, finalHeight, finalOverflow, finalize) {
    var el = this.el;
    var win = el.ownerDocument.defaultView;
    var self = this;

    this.cancelAnimation();

    var land = function () {
      // Still clipped to `to` px here, so the swap cannot make the box jump.
      if (finalize) finalize();
      el.style.height = finalHeight;
      el.style.overflow = finalOverflow;
    };

    if (!this.cfg.duration || from === to || this.reducedMotion()) {
      land();
      return;
    }

    el.style.overflow = 'hidden';
    el.style.height = from + 'px';
    el.style.transition = 'height ' + this.cfg.duration + 'ms ' +
      (EASINGS[this.cfg.easing] || EASINGS.ease);

    // Read the layout back so the start height is committed before the end
    // height replaces it — without this the browser only ever sees the end value.
    void el.offsetHeight;
    el.style.height = to + 'px';

    var onEnd = function (e) {
      if (e.target !== el || 'height' !== e.propertyName) return;
      self._settle();
    };

    this._settle = function () {
      self._settle = null;
      if (self._animTimer) win.clearTimeout(self._animTimer);
      self._animTimer = null;
      el.removeEventListener('transitionend', onEnd);
      el.style.transition = self.prev.transition || '';
      land();
    };

    el.addEventListener('transitionend', onEnd);
    // transitionend never fires in a background tab or when the transition is
    // interrupted, so the timeout is the one guaranteed way out.
    this._animTimer = win.setTimeout(this._settle, this.cfg.duration + 80);
  };

  /** Apply the collapsed / expanded content state, without any animation. */
  DnxteReadMore.prototype.applyState = function (expand) {
    if (this.byWords()) {
      if (expand) {
        this.restoreText();
      } else {
        this.clampWords();
      }
      return;
    }
    this.el.style.height = expand ? 'auto' : this.cfg.height + 'px';
  };

  DnxteReadMore.prototype.toggle = function () {
    var more = this.bar.querySelector('.dnxte-rm-more');
    var less = this.bar.querySelector('.dnxte-rm-less');
    var byWords = this.byWords();
    var expand = !this.expanded;

    this.cancelAnimation();

    // Where the box stands before the content changes.
    var from = this.el.offsetHeight;

    // The bar sits in the text flow in word mode, so its label has to be the
    // final one before any height is measured off it.
    less.style.display = expand ? '' : 'none';
    more.style.display = expand ? 'none' : '';
    this.bar.classList.toggle('dnxte-rm-expanded', expand);
    this.expanded = expand;

    if (expand && !this.cfg.keepLess) {
      this.bar.style.display = 'none';
    }

    // Word mode never leaves an inline height or overflow behind; height mode
    // keeps its clamp collapsed and releases it expanded.
    var to, finalHeight, finalOverflow;
    var finalize = null;

    if (byWords) {
      finalHeight = this.prev.height || '';
      finalOverflow = this.prev.overflow || '';
      if (expand) {
        // Expanding reveals text that is already there: the box grows and the
        // clip that was hiding the rest of it moves out of the way.
        this.applyState(true);
        to = this.el.offsetHeight;
      } else {
        // Collapsing has to mirror that, so the trim is measured and then undone
        // — the box shrinks over the full text and clips it away, and the trim
        // itself only lands once the travel is over. Applying it up front wiped
        // the text on the first frame and left an empty box to shrink, which
        // read as no transition at all.
        this.clampWords();
        to = this.el.offsetHeight;
        this.restoreText();
        finalize = this.clampWords.bind(this);
      }
    } else {
      this.applyState(expand);
      if (expand) {
        to = this.el.offsetHeight;
        finalHeight = 'auto';
      } else {
        to = this.cfg.height;
        finalHeight = this.cfg.height + 'px';
      }
      finalOverflow = 'hidden';
    }

    this.animateHeight(from, to, finalHeight, finalOverflow, finalize);
  };

  /** Re-evaluate device gating and whether the content is tall enough to clamp. */
  DnxteReadMore.prototype.refresh = function () {
    var c = this.cfg;
    var offHere = disabledOnThisDevice(c.device, this.el.ownerDocument.defaultView.innerWidth);

    this.cancelAnimation();

    if (this.byWords()) {
      // Nothing to hide when the module is shorter than the limit, so the bar
      // stays out of the way — same rule as the height mode below.
      if (offHere || this.totalWords <= c.words) {
        this.restoreText();
        this.bar.style.display = 'none';
        return;
      }
      // Once expanded with the less link off, the bar is gone for good.
      if (this.expanded && !c.keepLess) return;
      this.bar.style.display = '';
      if (!this.expanded) this.clampWords();
      return;
    }

    if (offHere) {
      this.el.style.height = 'auto';
      this.bar.style.display = 'none';
      return;
    }

    // Measure natural height with the clamp lifted and the bar out of the flow.
    var prevHeight = this.el.style.height;
    this.el.style.height = 'auto';
    var natural = this.el.scrollHeight;
    this.el.style.height = prevHeight;

    if (natural <= c.height) {
      this.el.style.height = 'auto';
      this.bar.style.display = 'none';
      return;
    }

    if (this.expanded && !c.keepLess) return;

    this.bar.style.display = '';
    if (!this.expanded) {
      this.el.style.height = c.height + 'px';
    }
  };

  DnxteReadMore.prototype.destroy = function () {
    var win = this.el.ownerDocument.defaultView;
    if (this._onResize) win.removeEventListener('resize', this._onResize);
    this.cancelAnimation();
    this.restoreText();
    if (this.bar) {
      this.bar.removeEventListener('click', this._onClick);
      if (this._onEnter) this.bar.removeEventListener('mouseenter', this._onEnter);
      if (this._onLeave) this.bar.removeEventListener('mouseleave', this._onLeave);
      if (this.bar.parentNode) this.bar.parentNode.removeChild(this.bar);
    }
    this.el.style.height = this.prev.height || '';
    this.el.style.overflow = this.prev.overflow || '';
    this.el.style.position = this.prev.position || '';
    this.el.style.transition = this.prev.transition || '';
    if (this.el._dnxteReadMore === this) delete this.el._dnxteReadMore;
  };

  function initAll() {
    var els = document.querySelectorAll('.dnxte-rm');
    Array.prototype.forEach.call(els, function (el) {
      if (el._dnxteReadMore) return;
      el._dnxteReadMore = new DnxteReadMore(el);
    });
  }

  function boot() {
    initAll();
    if (document.body) {
      var observer = new MutationObserver(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
          if (mutations[i].addedNodes && mutations[i].addedNodes.length) {
            initAll();
            return;
          }
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.DnxteReadMore = DnxteReadMore;
})();
