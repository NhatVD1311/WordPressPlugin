(function ($) {
  if (typeof Swiper === 'undefined') {
    return;
  }

  function initSocialProofSliders() {
    $(".dnxte-sp-swiper").each(function () {
      if ($(this).data('swiper-initialized')) {
        return;
      }

      $(this).data('swiper-initialized', true);

      var $container = $(this);
      var $wrapper = $container.closest('.dnxte-sp-slider-wrapper');
      var data = $container.data();

      var slidesPerViewDesktop = parseInt(data.slidesPerView) || 3;
      var slidesPerViewTablet = parseInt(data.slidesPerViewTablet) || Math.min(slidesPerViewDesktop, 2);
      var slidesPerViewPhone = parseInt(data.slidesPerViewPhone) || 1;
      var spaceBetween = parseInt(data.spaceBetween) || 20;
      var isLoop = data.loop === 'on';
      var isAutoplay = data.autoplay === 'on';
      var autoplayDelay = parseInt(data.autoplaySpeed) || 5000;
      var isPauseOnHover = data.pauseOnHover === 'on';
      var showArrows = data.showArrows !== 'off';
      var showPagination = data.showPagination !== 'off';

      var swiperConfig = {
        slidesPerView: slidesPerViewDesktop,
        spaceBetween: spaceBetween,
        loop: isLoop,
        autoplay: isAutoplay ? {
          delay: autoplayDelay,
          disableOnInteraction: false,
        } : false,
        breakpoints: {
          1024: {
            slidesPerView: slidesPerViewDesktop,
          },
          768: {
            slidesPerView: slidesPerViewTablet,
          },
          200: {
            slidesPerView: slidesPerViewPhone,
          },
        },
        observer: true,
        observeParents: true,
        observeSlideChildren: true,
      };

      if (showPagination) {
        swiperConfig.pagination = {
          el: $container.find('.swiper-pagination')[0],
          clickable: true,
        };
      }

      if (showArrows) {
        swiperConfig.navigation = {
          nextEl: $wrapper.find('.swiper-button-next')[0],
          prevEl: $wrapper.find('.swiper-button-prev')[0],
        };
      }

      var swiperInstance = new Swiper(this, swiperConfig);

      if (isAutoplay && isPauseOnHover) {
        $container.on('mouseenter', function () {
          swiperInstance.autoplay.stop();
        });
        $container.on('mouseleave', function () {
          swiperInstance.autoplay.start();
        });
      }
    });
  }

  $(document).ready(initSocialProofSliders);
  $(window).on('load', initSocialProofSliders);
})(jQuery);
