(function ($) {
  "use strict";
  $(document).ready(function(){
      // Insta Carousel
    $(".dnxte_insta_carousel_container").each(function(e) {
      
      const activeSelector = $(this).find('.dnxte-insta-feed-carousel-active');
      
      const instaCarouselData = activeSelector[0].dataset;

      const carouselBreakpoint =
        instaCarouselData.breakpoints && instaCarouselData.breakpoints.split("|");

      let arrowLeft = $(this).find('.swiper-button-prev');
      let arrowRight = $(this).find('.swiper-button-next');
      
      const instaSwiper = new Swiper(activeSelector[0], {
        
        // direction: instaCarouselData.direction,
        autoHeight:"on" === instaCarouselData.autoheight,
        speed: instaCarouselData.speed ? parseInt(instaCarouselData.speed) : 400,
        spaceBetween: parseInt(instaCarouselData.spacing),
        centeredSlides: "on" === instaCarouselData.center,
        grabCursor: "on" === instaCarouselData.grab,
        loop: "on" === instaCarouselData.loop,
        slidesPerView: carouselBreakpoint && parseInt(carouselBreakpoint[0]),
        autoplay: "on" === instaCarouselData.autoplay  ? { delay: instaCarouselData.delay } : false,
        centeredSlides: "on" === instaCarouselData.center,
        breakpoints: {
          1024: {
            slidesPerView:
              carouselBreakpoint ? parseInt(carouselBreakpoint[0]) : 4 ,
          },
          768: {
            slidesPerView:
              carouselBreakpoint ? parseInt(carouselBreakpoint[1]) : 3,
          },
          479: {
            slidesPerView:
              carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 2,
          },
          200: {
            slidesPerView:
              carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 1,
          },
        },
        direction: "horizontal",
        effect: "coverflow",
        coverflowEffect: {
          slideShadows: "on" === instaCarouselData.slideshadow,
          rotate: instaCarouselData.rotate,
          stretch: instaCarouselData.stretch,
          depth: instaCarouselData.depth,
        },
        pagination: {
          el: ".swiper-pagination",
          type: instaCarouselData.paginationtype,
          dynamicBullets: "on" === instaCarouselData.dynamicbullets,
          clickable: true,
        },
        keyboard: {
          enabled: "on" === instaCarouselData.keyboard,
          onlyInViewport: false,
        },
        mousewheel: {
          enabled: "on" === instaCarouselData.mousewheel,
          invert: false,
        },
        navigation: {
          nextEl: arrowRight[0],
          prevEl: arrowLeft[0],
        },
        observer: true,
        observeParents: true,
        observeSlideChildren: true,
      });

      // Handle autoplay on hover
      if ('on' === instaCarouselData.autoplay && 'on' === instaCarouselData.pauseonhover) {
        $(this).on("mouseenter", function() {
          instaSwiper.autoplay.stop();
        });
        $(this).on("mouseleave", function() {
          instaSwiper.autoplay.start();
        });
      }
    });
  });
})(jQuery);