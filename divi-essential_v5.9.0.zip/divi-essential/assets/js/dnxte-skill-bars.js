/**
 * NextSkillBars Frontend Animation Script
 */
(function () {
  "use strict";

  function animateValue(el, start, end, duration, suffix, easing) {
    const startTime = performance.now();
    const easingFns = {
      "ease-out": (t) => 1 - Math.pow(1 - t, 3),
      "ease-in-out": (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
      linear: (t) => t,
      bounce: (t) => {
        const n1 = 7.5625, d1 = 2.75;
        if (t < 1 / d1) return n1 * t * t;
        if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
        if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
      },
    };
    const ease = easingFns[easing] || easingFns["ease-out"];

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = ease(progress);
      const current = Math.round(start + (end - start) * easedProgress);
      el.textContent = current + suffix;
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  function animateBar(item, config, index) {
    const pct = parseInt(item.getAttribute("data-percentage"), 10) || 0;
    const fill = item.querySelector(".dnxte-skill-bar-fill, .dnxte-skill-bar-fill-vertical");
    const circleFill = item.querySelector(".dnxte-skill-circle-fill");
    // Animate ALL visible percentage elements (multiple positions exist in DOM)
    const pctEls = item.querySelectorAll(".dnxte-skill-bar-percentage, .dnxte-skill-circle-percentage");
    const duration = parseInt(config.animation.duration, 10) || 1500;
    const stagger = parseInt(config.animation.stagger, 10) || 120;
    const easing = config.animation.easing || "ease-out";
    const suffix = config.suffix || "%";
    const delay = index * stagger;

    setTimeout(function () {
      // Animate bar fill
      if (fill) {
        if (config.layout === "vertical") {
          fill.style.transition = "height " + duration + "ms " + easing;
          fill.style.height = pct + "%";
        } else {
          fill.style.transition = "width " + duration + "ms " + easing;
          fill.style.width = pct + "%";
        }
      }

      // Animate circle stroke (both full and half use stroke-dashoffset)
      if (circleFill) {
        var isHalfAnim = item.querySelector(".dnxte-skill-half-circle") !== null;
        var svgAnim = circleFill.closest("svg");
        var sizeAnim = parseInt(svgAnim.getAttribute("width"), 10) || 120;
        var swAnim = parseInt(circleFill.getAttribute("stroke-width"), 10) || 10;
        var rAnim = (sizeAnim - swAnim) / 2;
        var circAnim = isHalfAnim ? Math.PI * rAnim : 2 * Math.PI * rAnim;
        var fillLen = (pct / 100) * circAnim;
        // Compensate for round linecap visual extension
        var sCap = config.strokeCap || "round";
        var sW = config.strokeWidth || swAnim;
        if (sCap === "round" && pct < 100 && pct > 0) {
          fillLen = Math.max(fillLen - sW, 0);
        }
        var offAnim = pct >= 100 ? 0 : circAnim - fillLen;

        circleFill.style.transition = "stroke-dashoffset " + duration + "ms " + easing;
        circleFill.style.strokeDashoffset = offAnim;
      }

      // Animate percentage number (all position instances)
      pctEls.forEach(function (pctEl) {
        animateValue(pctEl, 0, pct, duration, suffix, easing);
      });

      item.classList.add("dnxte-skill-animated");
    }, delay);
  }

  function initSkillBars(wrapper) {
    var configStr = wrapper.getAttribute("data-config");
    if (!configStr) return;

    var config;
    try {
      config = JSON.parse(configStr);
    } catch (e) {
      return;
    }

    if (config.animation.enable !== "on") return;

    var items = wrapper.querySelectorAll(".dnxte-skill-bar-item");
    var animated = false;

    function resetBars() {
      items.forEach(function (item) {
        var fill = item.querySelector(".dnxte-skill-bar-fill, .dnxte-skill-bar-fill-vertical");
        var circleFill = item.querySelector(".dnxte-skill-circle-fill");
        var pctEls = item.querySelectorAll(".dnxte-skill-bar-percentage, .dnxte-skill-circle-percentage");

        if (fill) {
          fill.style.transition = "none";
          if (config.layout === "vertical") {
            fill.style.height = "0%";
          } else {
            fill.style.width = "0%";
          }
        }
        if (circleFill) {
          circleFill.style.transition = "none";
          var svgReset = circleFill.closest("svg");
          var sizeReset = parseInt(svgReset.getAttribute("width"), 10) || 120;
          var swReset = parseInt(circleFill.getAttribute("stroke-width"), 10) || 10;
          var rReset = (sizeReset - swReset) / 2;
          var isHalfReset = item.querySelector(".dnxte-skill-half-circle") !== null;
          var circReset = isHalfReset ? Math.PI * rReset : 2 * Math.PI * rReset;
          circleFill.style.strokeDashoffset = circReset;
        }
        pctEls.forEach(function (pctEl) {
          pctEl.textContent = "0" + (config.suffix || "%");
        });
        item.classList.remove("dnxte-skill-animated");
      });
    }

    function runAnimation() {
      if (animated && config.animation.replay !== "on") return;
      if (animated) resetBars();
      // Force reflow before starting animation so reset takes effect
      void wrapper.offsetHeight;
      items.forEach(function (item, index) {
        animateBar(item, config, index);
      });
      animated = true;
    }

    // IntersectionObserver for viewport detection
    if ("IntersectionObserver" in window) {
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              runAnimation();
              if (config.animation.replay !== "on") {
                observer.unobserve(wrapper);
              }
            } else if (config.animation.replay === "on" && animated) {
              resetBars();
              animated = false;
            }
          });
        },
        { threshold: 0.2 }
      );
      observer.observe(wrapper);
    } else {
      runAnimation();
    }
  }

  // Init on DOM ready
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".dnxte-skill-bars-wrapper").forEach(initSkillBars);
  });

  // Re-init for dynamic content
  document.addEventListener("dnxte-skill-bars-init", function (e) {
    if (e.detail) initSkillBars(e.detail);
  });
})();
