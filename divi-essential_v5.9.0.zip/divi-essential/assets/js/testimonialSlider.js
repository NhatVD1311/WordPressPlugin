(function ($) {
  // Check if Swiper is available
  if (typeof Swiper === 'undefined') {
    console.error('DiviNxtTestimonial: Swiper library not loaded');
    return;
  }

  $(".dnxte-tstimonial-wrap").length &&
    $(".dnxte-tstimonial-wrap").each(function (e) {
      // Skip if already initialized
      if ($(this).hasClass('swiper-container-initialized') || $(this).data('swiper-initialized')) {
        return;
      }

      // Mark as being initialized
      $(this).data('swiper-initialized', true);

      // Add swiper-slide class to Divi module wrappers (direct children of swiper-wrapper)
      $(this).find('.swiper-wrapper > .dnxte_testimonial_child').addClass('swiper-slide');

      const data = $(this).data();

      const breakpoints = typeof data?.breakpoints === 'string'
        ? data.breakpoints.split("|")
        : [data?.breakpoints || 1];

      const testimonialSwiper = new Swiper(this, {
        autoplay:
          "on" === data.autoplay
            ? {
                delay: data.delay ? data.delay : 0,
                disableOnInteraction: !1,
                reverseDirection: data?.rtl_direction,
              }
            : false,
        slidesPerView: breakpoints[0],
        centeredSlides: "on" === data.center,
        spaceBetween: parseInt(data.spacing),
        direction: data.direction,
        speed: data?.speed || 400,
        grabCursor: "on" === data.grab,
        loop: "on" === data.loop,
        loopAdditionalSlides: 1,
        loopedSlides: null,
        breakpoints: {
          1024: {
            slidesPerView: breakpoints[0],
          },
          768: {
            slidesPerView: breakpoints?.[1] || breakpoints[0],
          },
          479: {
            slidesPerView: breakpoints?.[2] || breakpoints[0],
          },
          200: {
            slidesPerView: breakpoints?.[2] || breakpoints[0],
          },
        },
        pagination: {
          el: ".swiper-pagination",
          dynamicBullets: "on" === data.paginationBullets,
          clickable: true,
          type: data.paginationType,
        },
        navigation: {
          nextEl: $(this).siblings(".swiper-button-next")[0],
          prevEl: $(this).siblings(".swiper-button-prev")[0],
        },
        keyboard: {
          enabled: "on" === data.keyboard,
          onlyInViewport: false,
        },
        mousewheel: {
          enabled: "on" === data.mousewheel,
          invert: true,
        },
        observer: !0,
        observeParents: !0,
        observeSlideChildren: !0,
      });

      if ("on" === data.autoplay && data.pauseonhover === "on") {
        $(this).on("mouseenter", function () {
          testimonialSwiper.autoplay.stop();
        });
        $(this).on("mouseleave", function () {
          testimonialSwiper.autoplay.start();
        });
      }
    });
})(jQuery);
