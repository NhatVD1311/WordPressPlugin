/**
 * Live Copy — VB Settings Extension
 *
 * Adds "Live Copy" settings to Section:
 * - Advanced tab: enable toggle
 * - Design tab: Normal & Copied button styling (font, background, border, boxShadow, spacing)
 */
(function () {
  'use strict';

  var wp = window.vendor && window.vendor.wp;
  var hooks = wp && wp.hooks;
  if (!hooks) return;

  var TARGET_MODULE  = 'divi/section';
  var GROUP_TOGGLE   = 'dnxteLiveCopy';
  var GROUP_NORMAL   = 'dnxteLiveCopyNormal';
  var GROUP_COPIED   = 'dnxteLiveCopyCopied';

  var BTN_SELECTOR             = '{{selector}} .dnxte-live-copy-btn';
  var BTN_LABEL_SELECTOR       = '{{selector}} .dnxte-live-copy-btn span';
  var COPIED_SELECTOR          = '{{selector}} .dnxte-live-copy-btn.dnxte-live-copy-success';
  var COPIED_LABEL_SELECTOR    = '{{selector}} .dnxte-live-copy-btn.dnxte-live-copy-success span';

  function isEnabled(p) {
    return 'on' === (p.attrs?.dnxte_live_copy?.advanced?.enable?.desktop?.value);
  }

  // ════════════════════════════════════════════════════════════
  // 1. OPTION GROUPS
  // ════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleSettings.groups',
    'dnxte-live-copy',
    function (groups, metadata) {
      if (metadata.name !== TARGET_MODULE) return groups;

      // Advanced tab — enable toggle
      groups.dnxteLiveCopy = {
        groupName: GROUP_TOGGLE,
        panel: 'advanced',
        priority: 90,
        multiElements: false,
        component: { name: 'divi/composite', props: { groupLabel: 'Live Copy' } },
      };

      // Design tab — Normal state
      groups.dnxteLiveCopyNormal = {
        groupName: GROUP_NORMAL,
        panel: 'design',
        priority: 91,
        multiElements: false,
        visible: isEnabled,
        component: { name: 'divi/composite', props: { groupLabel: 'Live Copy Button' } },
      };

      // Design tab — Copied state
      groups.dnxteLiveCopyCopied = {
        groupName: GROUP_COPIED,
        panel: 'design',
        priority: 92,
        multiElements: false,
        visible: isEnabled,
        component: { name: 'divi/composite', props: { groupLabel: 'Live Copy Button — Copied' } },
      };

      return groups;
    }
  );

  // ════════════════════════════════════════════════════════════
  // 2. ATTRIBUTES
  // ════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleAttributes',
    'dnxte-live-copy',
    function (attributes, metadata) {
      if (metadata.name !== TARGET_MODULE) return attributes;

      // ── Enable toggle (Advanced) ──
      attributes.dnxte_live_copy = {
        type: 'object',
        default: {
          advanced: {
            enable: { desktop: { value: 'off' } },
          },
        },
        settings: {
          advanced: {
            enable: {
              groupType: 'group-item',
              item: {
                attrName: 'dnxte_live_copy.advanced.enable',
                label: 'Enable Live Copy',
                description: 'Show a Live Copy button on this section in the frontend.',
                groupSlug: GROUP_TOGGLE,
                priority: 10,
                render: true,
                features: { sticky: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' },
              },
            },
          },
        },
      };

      // ── Normal Button Styling (Design) ──
      attributes.dnxte_lcp_btn = {
        type: 'object',
        selector: BTN_SELECTOR,
        styleProps: {
          font: {
            important: true,
            selector: BTN_LABEL_SELECTOR,
          },
          background: {
            important: true,
          },
          border: {
            important: true,
          },
          boxShadow: {
            important: true,
          },
          spacing: {
            important: true,
          },
        },
        default: {
          decoration: {},
        },
        settings: {
          decoration: {
            font: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_NORMAL,
                priority: 10,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/font',
                  props: { grouped: true, groupLabel: 'Button Text' },
                },
              },
            },
            background: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_NORMAL,
                priority: 20,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/background',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            border: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_NORMAL,
                priority: 30,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/border',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            boxShadow: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_NORMAL,
                priority: 40,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/box-shadow',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            spacing: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_NORMAL,
                priority: 50,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/spacing',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
          },
        },
      };

      // ── Copied Button Styling (Design) ──
      attributes.dnxte_lcp_btn_copied = {
        type: 'object',
        selector: COPIED_SELECTOR,
        styleProps: {
          font: {
            important: true,
            selector: COPIED_LABEL_SELECTOR,
          },
          background: {
            important: true,
          },
          border: {
            important: true,
          },
          boxShadow: {
            important: true,
          },
          spacing: {
            important: true,
          },
        },
        default: {
          decoration: {},
        },
        settings: {
          decoration: {
            font: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_COPIED,
                priority: 10,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/font',
                  props: { grouped: true, groupLabel: 'Button Text' },
                },
              },
            },
            background: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_COPIED,
                priority: 20,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/background',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            border: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_COPIED,
                priority: 30,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/border',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            boxShadow: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_COPIED,
                priority: 40,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/box-shadow',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
            spacing: {
              groupType: 'group-item',
              item: {
                groupSlug: GROUP_COPIED,
                priority: 50,
                render: true,
                component: {
                  type: 'group',
                  name: 'divi/spacing',
                  props: { grouped: true, fieldLabel: 'Button' },
                },
              },
            },
          },
        },
      };

      return attributes;
    }
  );
})();
