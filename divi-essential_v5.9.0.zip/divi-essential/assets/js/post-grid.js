(function() {
  'use strict';

  // Initialize all Post Grid instances on the page
  function initPostGrids() {
    const grids = document.querySelectorAll('.dnxte_post_grid');
    grids.forEach(initPostGrid);
  }

  function initPostGrid(moduleEl) {
    const wrapper = moduleEl.querySelector('.dnxte-post-grid-wrapper');
    if (!wrapper) return;

    const container = wrapper.querySelector('.dnxte-post-grid-container');
    const filterBar = wrapper.querySelector('.dnxte-post-grid-filter-bar');
    const pagination = wrapper.querySelector('.dnxte-post-grid-pagination');
    var isoInstance = null;

    // Read config from data attributes
    const config = {
      postsPerPage: wrapper.dataset.postsPerPage || '6',
      orderby: wrapper.dataset.orderby || 'date',
      order: wrapper.dataset.order || 'DESC',
      postType: wrapper.dataset.postType || 'post',
      layout: wrapper.dataset.layout || 'card',
      paginationType: wrapper.dataset.paginationType || 'loadMore',
      maxPages: parseInt(wrapper.dataset.maxPages || '1'),
      midSize: parseInt(wrapper.dataset.midSize || '2'),
      filterCatSlugs: wrapper.dataset.filterCatSlugs || '',
      currentPage: 1,
      currentCategory: 'all',
      isLoading: false,
    };

    // Get localized data
    const ajaxUrl = (window.dnxtePostGrid && window.dnxtePostGrid.ajaxUrl) || '/wp-admin/admin-ajax.php';
    const nonce = (window.dnxtePostGrid && window.dnxtePostGrid.nonce) || '';

    // ========== AJAX REQUEST ==========
    function fetchPosts(page, category, append) {
      if (config.isLoading) return;
      config.isLoading = true;

      // Set loading state
      if (!append) {
        moduleEl.classList.add('dnxte-post-grid--loading');
        container.setAttribute('aria-busy', 'true');
        // Hide masonry container during full reload to prevent layout jump
        if (config.layout === 'masonry') {
          container.style.opacity = '0';
        }
      }

      // Update load more button text
      const loadMoreBtn = pagination?.querySelector('.dnxte-post-grid-pagination-load-more');
      const originalText = loadMoreBtn?.textContent;
      if (loadMoreBtn) {
        loadMoreBtn.textContent = loadMoreBtn.dataset.loadingText || 'Loading...';
        loadMoreBtn.classList.add('dnxte-post-grid-pagination-load-more--loading');
      }

      // Show spinner for infinite scroll
      if (config.paginationType === 'infiniteScroll' && append) {
        showSpinner();
      }

      const formData = new FormData();
      // When "all" is selected but specific filter categories exist, send those slugs
      // so the query is scoped to only the selected filter categories.
      let resolvedCategory = category;
      if (category === 'all' && config.filterCatSlugs) {
        resolvedCategory = config.filterCatSlugs;
      }

      formData.append('action', 'dnxte_post_grid_filter');
      formData.append('nonce', nonce);
      formData.append('category', resolvedCategory);
      formData.append('page', page.toString());
      formData.append('posts_per_page', config.postsPerPage);
      formData.append('orderby', config.orderby);
      formData.append('order', config.order);
      formData.append('post_type', config.postType);
      formData.append('layout', config.layout);

      // Pass element toggles from data attributes
      const toggles = ['show_title', 'show_date', 'show_author', 'show_categories',
                       'show_excerpt', 'show_readmore', 'readmore_text', 'show_thumbnail',
                       'featured_image_size', 'date_format', 'excerpt_length', 'excerpt_length_type', 'content_length', 'post_target',
                       'heading_level', 'show_comment_count', 'date_position', 'excerpt_content',
                       'meta_alignment', 'meta_separator', 'button_alignment',
                       'show_date_icon', 'show_author_avatar', 'show_category_icon', 'show_comment_icon', 'category_count',
                       'icon_date', 'icon_cate', 'icon_comment',
                       'button_class', 'button_icon',
                       'query_source', 'relate_by', 'current_post_id'];
      toggles.forEach(key => {
        const val = wrapper.dataset[key.replace(/_([a-z])/g, (m, c) => c.toUpperCase())];
        if (val !== undefined) formData.append(key, val);
      });

      fetch(ajaxUrl, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Content is from trusted WordPress server-side rendering (same-origin AJAX with nonce)
          if (append) {
            // Parse new items into DOM nodes before inserting
            var temp = document.createElement('div');
            temp.innerHTML = data.data.html; // eslint-disable-line -- trusted server HTML
            var newItems = Array.from(temp.children);
            newItems.forEach(function(item) { container.appendChild(item); });
            appendToMasonry(newItems);
          } else {
            container.innerHTML = data.data.html; // eslint-disable-line -- trusted server HTML
            relayoutMasonry();
          }

          config.maxPages = data.data.max_pages;
          config.currentPage = data.data.current_page;

          // Update pagination
          updatePagination();

          // Focus first new card for accessibility
          if (!append) {
            const firstCard = container.querySelector('.dnxte-post-grid-card');
            if (firstCard) firstCard.focus();
          }
        } else {
          showError('Failed to load posts. Please try again.');
        }
      })
      .catch(() => {
        showError('Failed to load posts. Please try again.');
      })
      .finally(() => {
        config.isLoading = false;
        moduleEl.classList.remove('dnxte-post-grid--loading');
        container.removeAttribute('aria-busy');
        hideSpinner();

        if (loadMoreBtn) {
          loadMoreBtn.textContent = originalText;
          loadMoreBtn.classList.remove('dnxte-post-grid-pagination-load-more--loading');
        }
      });
    }

    // ========== FILTER BAR ==========
    if (filterBar) {
      filterBar.addEventListener('click', function(e) {
        const tab = e.target.closest('.dnxte-post-grid-filter-bar-tab');
        if (!tab) return;

        // Update active tab
        filterBar.querySelectorAll('.dnxte-post-grid-filter-bar-tab').forEach(t => {
          t.classList.remove('dnxte-post-grid-filter-bar-tab--active');
          t.setAttribute('aria-selected', 'false');
        });
        tab.classList.add('dnxte-post-grid-filter-bar-tab--active');
        tab.setAttribute('aria-selected', 'true');

        config.currentCategory = tab.dataset.category || 'all';
        config.currentPage = 1;

        fetchPosts(1, config.currentCategory, false);
      });
    }

    // ========== LOAD MORE ==========
    if (config.paginationType === 'loadMore' && pagination) {
      const loadMoreBtn = pagination.querySelector('.dnxte-post-grid-pagination-load-more');
      if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
          if (config.currentPage >= config.maxPages) return;
          config.currentPage++;
          fetchPosts(config.currentPage, config.currentCategory, true);
        });
      }
    }

    // ========== NUMBERED PAGINATION ==========
    if (config.paginationType === 'numbered' && pagination) {
      pagination.addEventListener('click', function(e) {
        const pageNum = e.target.closest('.dnxte-post-grid-pagination-number');
        if (!pageNum) return;

        const page = parseInt(pageNum.dataset.page);
        if (isNaN(page) || page === config.currentPage) return;

        config.currentPage = page;
        fetchPosts(page, config.currentCategory, false);

        // Smooth scroll to module top
        moduleEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }

    // ========== INFINITE SCROLL ==========
    if (config.paginationType === 'infiniteScroll') {
      const sentinel = pagination?.querySelector('.dnxte-post-grid-pagination-sentinel');
      if (sentinel) {
        const observer = new IntersectionObserver(function(entries) {
          entries.forEach(entry => {
            if (entry.isIntersecting && !config.isLoading && config.currentPage < config.maxPages) {
              config.currentPage++;
              fetchPosts(config.currentPage, config.currentCategory, true);
            }
          });
        }, {
          rootMargin: '0px 0px 200px 0px',
        });
        observer.observe(sentinel);
      }
    }

    // ========== MASONRY (ISOTOPE) ==========
    function getResponsiveColumns() {
      var w = window.innerWidth;
      if (w <= 767) {
        return parseInt(container.dataset.columnsPhone) || 1;
      }
      if (w <= 980) {
        return parseInt(container.dataset.columnsTablet) || 2;
      }
      return parseInt(container.dataset.columns) || 3;
    }

    function getMasonryConfig() {
      var cols = getResponsiveColumns();
      var styles = getComputedStyle(container);
      var gap = parseFloat(styles.columnGap) || 30;
      return { cols: cols, gap: gap };
    }

    function setCardWidths() {
      var mc = getMasonryConfig();
      var cardWidth = 'calc((100% - ' + (mc.gap * (mc.cols - 1)) + 'px) / ' + mc.cols + ')';
      container.querySelectorAll('.dnxte-post-grid-card').forEach(function(card) {
        card.style.width = cardWidth;
      });
    }

    function initMasonry() {
      if (config.layout !== 'masonry') return;
      if (typeof window.Isotope === 'undefined') return;

      var mc = getMasonryConfig();

      // Hide container during layout to prevent jump
      container.style.opacity = '0';

      // Destroy previous instance
      if (isoInstance) {
        isoInstance.destroy();
        isoInstance = null;
        container.classList.remove('isotope-initialized');
      }

      // Set card widths BEFORE Isotope init so it measures correctly
      setCardWidths();

      var doInit = function() {
        isoInstance = new window.Isotope(container, {
          itemSelector: '.dnxte-post-grid-card',
          layoutMode: 'masonry',
          masonry: {
            columnWidth: '.dnxte-post-grid-card',
            gutter: mc.gap,
          },
          percentPosition: true,
          transitionDuration: '0.3s',
          initLayout: false,
        });

        container.classList.add('isotope-initialized');

        // Do initial layout, then fade in
        isoInstance.layout();

        // Fade in after layout is computed
        requestAnimationFrame(function() {
          container.style.transition = 'opacity 0.3s ease';
          container.style.opacity = '1';
        });
      };

      // Wait for ALL images to load so Isotope measures correct heights
      if (typeof window.imagesLoaded !== 'undefined') {
        window.imagesLoaded(container, doInit);
      } else {
        doInit();
      }
    }

    function appendToMasonry(newElements) {
      if (config.layout !== 'masonry' || !isoInstance) return;

      var mc = getMasonryConfig();
      var cardWidth = 'calc((100% - ' + (mc.gap * (mc.cols - 1)) + 'px) / ' + mc.cols + ')';

      // Set widths on new items
      newElements.forEach(function(el) {
        el.style.width = cardWidth;
      });

      // Wait for new images to load, then tell Isotope about them
      var doAppend = function() {
        isoInstance.appended(newElements);
        isoInstance.layout();
      };

      if (typeof window.imagesLoaded !== 'undefined') {
        window.imagesLoaded(newElements, doAppend);
      } else {
        doAppend();
      }
    }

    function relayoutMasonry() {
      if (config.layout !== 'masonry') return;
      initMasonry();
    }

    // Init masonry on first load
    initMasonry();

    // Re-layout masonry on window resize (debounced)
    if (config.layout === 'masonry') {
      var resizeTimer;
      window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
          if (!isoInstance) return;
          setCardWidths();
          isoInstance.layout();
        }, 150);
      });
    }

    // ========== HELPERS ==========
    function updatePagination() {
      if (!pagination) return;

      if (config.paginationType === 'loadMore') {
        const btn = pagination.querySelector('.dnxte-post-grid-pagination-load-more');
        if (btn) {
          btn.style.display = config.currentPage >= config.maxPages ? 'none' : '';
        }
      }

      if (config.paginationType === 'numbered') {
        const numbersContainer = pagination.querySelector('.dnxte-post-grid-pagination-numbers');
        if (numbersContainer) {
          var mid = config.midSize;
          var total = config.maxPages;
          var current = config.currentPage;
          var html = '';
          var lastPrinted = 0;

          // Prev
          if (current > 1) {
            html += '<span class="dnxte-post-grid-pagination-number" data-page="' + (current - 1) + '">\u2190</span>';
          }

          for (var i = 1; i <= total; i++) {
            // Show: first, last, and pages within midSize of current
            if (i === 1 || i === total || Math.abs(i - current) <= mid) {
              if (lastPrinted > 0 && i - lastPrinted > 1) {
                html += '<span class="dnxte-post-grid-pagination-ellipsis">&hellip;</span>';
              }
              var active = i === current ? ' active' : '';
              html += '<span class="dnxte-post-grid-pagination-number' + active + '" data-page="' + i + '">' + i + '</span>';
              lastPrinted = i;
            }
          }

          // Next
          if (current < total) {
            html += '<span class="dnxte-post-grid-pagination-number" data-page="' + (current + 1) + '">\u2192</span>';
          }

          numbersContainer.innerHTML = html;
        }
      }
    }

    function showSpinner() {
      if (!pagination) return;
      let spinner = pagination.querySelector('.dnxte-post-grid-pagination-spinner');
      if (!spinner) {
        spinner = document.createElement('div');
        spinner.className = 'dnxte-post-grid-pagination-spinner';
        pagination.appendChild(spinner);
      }
      spinner.style.display = 'block';
    }

    function hideSpinner() {
      if (!pagination) return;
      const spinner = pagination.querySelector('.dnxte-post-grid-pagination-spinner');
      if (spinner) spinner.style.display = 'none';
    }

    function showError(message) {
      // Remove existing error
      const existing = moduleEl.querySelector('.dnxte-post-grid-error');
      if (existing) existing.remove();

      const error = document.createElement('div');
      error.className = 'dnxte-post-grid-error';
      error.textContent = message;
      container.after(error);

      // Auto-remove after 5 seconds
      setTimeout(() => error.remove(), 5000);
    }
  }

  // Init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPostGrids);
  } else {
    initPostGrids();
  }
})();
