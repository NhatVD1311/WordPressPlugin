/**
 * Tooltip — VB Extension
 * Uses Divi native fields and groups (divi/font, divi/box-shadow). Works on ALL modules.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;

  function isTarget(name) {
    if (!name || typeof name !== 'string') return false;
    if (name === 'core/null') return false;
    return name.indexOf('/') !== -1;
  }

  function buildGroup() {
    return {
      groupName: 'dnxteTooltip',
      panel: 'design',
      priority: 91,
      multiElements: true,
      component: {
        name: 'divi/composite',
        props: { groupLabel: 'Tooltip' }
      }
    };
  }

  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-tooltip', function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteTooltip) next.dnxteTooltip = buildGroup();
    return next;
  });

  function isOn(p) {
    return 'on' === (p.attrs?.dnxte_tooltip?.advanced?.use_tooltip?.desktop?.value);
  }
  function isOnAndArrow(p) {
    return isOn(p) && 'on' === (p.attrs?.dnxte_tooltip?.advanced?.tooltip_arrow?.desktop?.value);
  }
  function isOnAndBorder(p) {
    var w = p.attrs?.dnxte_tooltip?.advanced?.tooltip_border_width?.desktop?.value;
    return isOn(p) && w && parseFloat(w) > 0;
  }

  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-tooltip', function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs.dnxte_tooltip = {
      type: 'object',
      selector: '{{selector}}',
      default: {
        advanced: {
          // Core
          use_tooltip:           { desktop: { value: 'off' } },
          tooltip_text:          { desktop: { value: 'Hover to see tooltip' } },
          tooltip_position:      { desktop: { value: 'top' } },
          tooltip_trigger:       { desktop: { value: 'hover' } },
          tooltip_animation:     { desktop: { value: 'fade' } },
          // Background
          tooltip_bg:            { desktop: { value: '#1e293b' } },
          // Box
          tooltip_padding_y:     { desktop: { value: '6' } },
          tooltip_padding_x:     { desktop: { value: '12' } },
          tooltip_max_width:     { desktop: { value: '250' } },
          tooltip_border_radius: { desktop: { value: '6' } },
          // Border
          tooltip_border_width:  { desktop: { value: '0' } },
          tooltip_border_color:  { desktop: { value: '#000000' } },
          // Arrow
          tooltip_arrow:         { desktop: { value: 'on' } },
          tooltip_arrow_size:    { desktop: { value: '5' } },
        },
        // Native Divi groups — boxShadow + font (typography).
        decoration: {
          boxShadow: { desktop: { value: {} } },
          font: { font: { desktop: { value: {} } } },
        },
      },
      settings: {
        advanced: {
          use_tooltip: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.use_tooltip', label: 'Enable Tooltip',
            groupSlug: 'dnxteTooltip', priority: 1, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/toggle' }
          }},
          tooltip_text: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_text', label: 'Tooltip Text',
            description: 'HTML supported (bold, italic, links)',
            groupSlug: 'dnxteTooltip', priority: 5, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/richtext' },
            visible: isOn
          }},
          tooltip_position: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_position', label: 'Position',
            groupSlug: 'dnxteTooltip', priority: 10, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'top':    { label: 'Top' },
              'bottom': { label: 'Bottom' },
              'left':   { label: 'Left' },
              'right':  { label: 'Right' },
              'auto':   { label: 'Auto (Smart)' },
            } } },
            visible: isOn
          }},
          tooltip_trigger: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_trigger', label: 'Trigger',
            description: 'Click is recommended for mobile devices',
            groupSlug: 'dnxteTooltip', priority: 12, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'hover': { label: 'Hover' },
              'click': { label: 'Click' },
            } } },
            visible: isOn
          }},
          tooltip_animation: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_animation', label: 'Animation',
            groupSlug: 'dnxteTooltip', priority: 13, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'fade':  { label: 'Fade' },
              'scale': { label: 'Scale' },
              'slide': { label: 'Slide' },
              'none':  { label: 'None' },
            } } },
            visible: isOn
          }},

          // ─── Background ───
          tooltip_bg: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_bg', label: 'Background Color',
            groupSlug: 'dnxteTooltip', priority: 20, render: true,
            features: { sticky: false, responsive: false },
            component: { type: 'field', name: 'divi/color-picker' },
            visible: isOn
          }},

          // ─── Box ───
          tooltip_padding_y: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_padding_y', label: 'Padding Vertical',
            groupSlug: 'dnxteTooltip', priority: 40, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 0, max: 40, step: 1, defaultUnit: 'px' } },
            visible: isOn
          }},
          tooltip_padding_x: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_padding_x', label: 'Padding Horizontal',
            groupSlug: 'dnxteTooltip', priority: 41, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 0, max: 60, step: 1, defaultUnit: 'px' } },
            visible: isOn
          }},
          tooltip_max_width: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_max_width', label: 'Max Width',
            groupSlug: 'dnxteTooltip', priority: 42, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 80, max: 600, step: 10, defaultUnit: 'px' } },
            visible: isOn
          }},
          tooltip_border_radius: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_border_radius', label: 'Border Radius',
            groupSlug: 'dnxteTooltip', priority: 43, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 0, max: 40, step: 1, defaultUnit: 'px' } },
            visible: isOn
          }},

          // ─── Border ───
          tooltip_border_width: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_border_width', label: 'Border Width',
            groupSlug: 'dnxteTooltip', priority: 50, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 0, max: 8, step: 1, defaultUnit: 'px' } },
            visible: isOn
          }},
          tooltip_border_color: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_border_color', label: 'Border Color',
            groupSlug: 'dnxteTooltip', priority: 51, render: true,
            features: { sticky: false, responsive: false },
            component: { type: 'field', name: 'divi/color-picker' },
            visible: isOnAndBorder
          }},

          // ─── Arrow ───
          tooltip_arrow: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_arrow', label: 'Show Arrow',
            groupSlug: 'dnxteTooltip', priority: 60, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/toggle' },
            visible: isOn
          }},
          tooltip_arrow_size: { groupType: 'group-item', item: {
            attrName: 'dnxte_tooltip.advanced.tooltip_arrow_size', label: 'Arrow Size',
            groupSlug: 'dnxteTooltip', priority: 61, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/range', props: { min: 3, max: 15, step: 1, defaultUnit: 'px' } },
            visible: isOnAndArrow
          }},

        },

        // ─── Native Divi groups ───
        decoration: {
          // Typography — full Divi font group (family, weight, style, size,
          // color, letter-spacing, line-height, alignment). Read in PHP and
          // applied inline on the (teleported) tooltip element via data-attr.
          font: { groupType: 'group-item', item: {
            groupSlug: 'dnxteTooltip', priority: 30, render: true,
            component: {
              type: 'group',
              name: 'divi/font',
              props: {
                grouped: false,
                fieldLabel: 'Tooltip',
                // Divi checks component.props.visible for group items (item-level
                // `visible` only gates plain fields), so gate the group here too.
                visible: isOn,
                fields: {
                  headingLevel: { render: false },
                },
              },
            },
            visible: isOn
          }},
          // Box Shadow — uses Divi's preset library + custom controls
          boxShadow: { groupType: 'group-item', item: {
            groupSlug: 'dnxteTooltip', priority: 70, render: true,
            component: {
              type: 'group',
              name: 'divi/box-shadow',
              props: {
                grouped: false,
                fieldLabel: 'Tooltip',
                visible: isOn,
              },
            },
            visible: isOn
          }},
        },
      }
    };

    if (meta && typeof meta === 'object') {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteTooltip) {
        meta.settings.groups.dnxteTooltip = buildGroup();
      }
    }

    return attrs;
  });
})();
