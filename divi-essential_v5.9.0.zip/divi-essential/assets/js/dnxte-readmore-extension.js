/**
 * Read More — VB Extension (settings UI)
 *
 * Divi 5 port of the Divi 4 field set in
 * includes/Extensions/read-more/read-more-traits/helper.trait.php.
 *
 * Unlike the Tooltip extension this is restricted to a fixed module allowlist,
 * matching the Divi 4 $allowed_modules list. Keep ALLOWED in sync with
 * ReadMoreExtension::ALLOWED_MODULES on the PHP side.
 *
 * Typography (font, size, alignment, link colour + hover) is handled by the
 * native divi/font group rather than the four separate Divi 4 fields.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var React = window.vendor.React;
  var element = wp.element;

  var ALLOWED = [
    'divi/text',
    'divi/blog',
    'divi/code',
    'divi/cta',
    'divi/blurb',
    'divi/fullwidth-code'
  ];

  /**
   * Mirrors BoxShadow::$_presets in Divi core. The bar is built at runtime and
   * gets its shadow inline, so the preset the author picks has to be resolved
   * to a CSS string here exactly the way ReadMoreExtension does it server-side.
   */
  var SHADOW_PRESETS = {
    preset1: { horizontal: '0px',  vertical: '2px',  blur: '18px', spread: '0px',   position: 'outer', color: 'rgba(0,0,0,0.3)' },
    preset2: { horizontal: '6px',  vertical: '6px',  blur: '18px', spread: '0px',   position: 'outer', color: 'rgba(0,0,0,0.3)' },
    preset3: { horizontal: '0px',  vertical: '12px', blur: '18px', spread: '-6px',  position: 'outer', color: 'rgba(0,0,0,0.3)' },
    preset4: { horizontal: '10px', vertical: '10px', blur: '0px',  spread: '0px',   position: 'outer', color: 'rgba(0,0,0,0.3)' },
    preset5: { horizontal: '0px',  vertical: '6px',  blur: '0px',  spread: '10px',  position: 'outer', color: 'rgba(0,0,0,0.3)' },
    preset6: { horizontal: '0px',  vertical: '0px',  blur: '18px', spread: '0px',   position: 'inner', color: 'rgba(0,0,0,0.3)' },
    preset7: { horizontal: '10px', vertical: '10px', blur: '0px',  spread: '0px',   position: 'inner', color: 'rgba(0,0,0,0.3)' }
  };

  function shadowCss(value) {
    if (!value || 'object' !== typeof value) return '';
    if (!value.style || 'none' === value.style) return '';

    var s = Object.assign({}, SHADOW_PRESETS[value.style] || {});
    Object.keys(value).forEach(function (key) {
      if (undefined !== value[key] && null !== value[key] && '' !== value[key]) s[key] = value[key];
    });

    return ('inner' === s.position ? 'inset ' : '') +
      (s.horizontal || '0px') + ' ' + (s.vertical || '0px') + ' ' + (s.blur || '0px') +
      (s.spread ? ' ' + s.spread : '') + (s.color ? ' ' + s.color : '');
  }

  function isTarget(name) {
    return !!name && ALLOWED.indexOf(name) !== -1;
  }

  function buildGroup() {
    return {
      groupName: 'dnxteReadMore',
      panel: 'advanced',
      // Divi's own advanced groups: visibility 40, transition 60. Sitting at 45
      // puts Read More right after Visibility, where Divi 4 placed it
      // (tab_slug 'custom_css', toggle_slug 'visibility').
      priority: 45,
      multiElements: false,
      component: {
        name: 'divi/composite',
        props: { groupLabel: 'Read More' }
      }
    };
  }

  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-readmore', function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteReadMore) next.dnxteReadMore = buildGroup();
    return next;
  });

  // Mirrors Divi 4's show_if => { dnxte_rm_readmore: 'on' } on every field but the toggle.
  function isOn(p) {
    return 'on' === (p.attrs?.dnxte_readmore?.advanced?.use_readmore?.desktop?.value);
  }

  function trimValue(p, key, fallback) {
    var out = p.attrs?.dnxte_readmore?.advanced?.[key]?.desktop?.value;
    return (out === undefined || out === null || out === '') ? fallback : out;
  }

  function trimType(p) {
    return trimValue(p, 'readmore_trim_type', 'height');
  }

  // Height and Word Count are alternative ways to decide where the content is
  // cut, so each one's field only shows for its own mode.
  function isHeightMode(p) {
    return isOn(p) && 'words' !== trimType(p);
  }

  function isWordMode(p) {
    return isOn(p) && 'words' === trimType(p);
  }

  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-readmore', function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs.dnxte_readmore = {
      type: 'object',
      selector: '{{selector}}',
      default: {
        advanced: {
          use_readmore:               { desktop: { value: 'off' } },
          readmore_trim_type:         { desktop: { value: 'height' } },
          readmore_height:            { desktop: { value: '200px' } },
          readmore_word_count:        { desktop: { value: '50' } },
          readmore_text:              { desktop: { value: 'Read more' } },
          readmore_less_text:         { desktop: { value: 'Read less' } },
          readmore_no_less:           { desktop: { value: 'on' } },
          readmore_duration:          { desktop: { value: '400' } },
          readmore_easing:            { desktop: { value: 'ease' } },
          readmore_disable_on_device: { desktop: { value: 'none' } },
          readmore_bg_color:          { desktop: { value: '' } },
          readmore_custom_css:        { desktop: { value: '' } }
        },
        // Native Divi typography group — replaces the D4 font / text size /
        // text alignment / link colour fields in one control.
        decoration: {
          font: { font: { desktop: { value: {} } } },
          boxShadow: { desktop: { value: {} } }
        }
      },
      settings: {
        advanced: {
          use_readmore: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.use_readmore', label: 'Use Read More',
            description: 'Toggle whether you want to use the Read More feature on this module or not.',
            groupSlug: 'dnxteReadMore', priority: 1, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/toggle' }
          }},
          readmore_trim_type: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_trim_type', label: 'Trim By',
            description: 'Height - collapse the module to a fixed height. Word Count - trim the text after a set number of words.',
            groupSlug: 'dnxteReadMore', priority: 3, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'height': { label: 'Height' },
              'words':  { label: 'Word Count' }
            } } },
            visible: isOn
          }},
          readmore_height: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_height', label: 'Height',
            description: 'Adjust the collapsed height of the Read More block.',
            groupSlug: 'dnxteReadMore', priority: 5, render: true,
            features: { sticky: false, hover: false },
            component: { type: 'field', name: 'divi/range', props: { min: 50, max: 1000, step: 10, defaultUnit: 'px' } },
            visible: isHeightMode
          }},
          readmore_word_count: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_word_count', label: 'Word Count',
            description: 'Show the Read More link after this many words. Modules with fewer words are left untouched.',
            groupSlug: 'dnxteReadMore', priority: 6, render: true,
            features: { sticky: false, hover: false },
            component: { type: 'field', name: 'divi/range', props: {
              min: 5, max: 500, step: 5, allowUnitless: true, defaultUnit: '', unitless: true
            } },
            visible: isWordMode
          }},
          readmore_text: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_text', label: 'Read More Text',
            description: 'Insert Read More placeholder text.',
            groupSlug: 'dnxteReadMore', priority: 10, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/text' },
            visible: isOn
          }},
          readmore_less_text: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_less_text', label: 'Read Less Text',
            description: 'Insert Read Less placeholder text.',
            groupSlug: 'dnxteReadMore', priority: 15, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/text' },
            visible: isOn
          }},
          readmore_no_less: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_no_less', label: 'Less Text Show',
            description: 'Yes - show the Read Less link. No - hide it after expanding.',
            groupSlug: 'dnxteReadMore', priority: 20, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/toggle' },
            visible: isOn
          }},
          readmore_duration: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_duration', label: 'Transition Duration',
            description: 'How long the expand and collapse animation runs, in milliseconds. Set 0 for an instant toggle.',
            groupSlug: 'dnxteReadMore', priority: 22, render: true,
            features: { sticky: false, hover: false },
            component: { type: 'field', name: 'divi/range', props: {
              min: 0, max: 2000, step: 50, allowUnitless: true, defaultUnit: '', unitless: true
            } },
            visible: isOn
          }},
          readmore_easing: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_easing', label: 'Transition Easing',
            description: 'Speed curve of the expand and collapse animation.',
            groupSlug: 'dnxteReadMore', priority: 24, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'ease':        { label: 'Ease' },
              'linear':      { label: 'Linear' },
              'ease-in':     { label: 'Ease In' },
              'ease-out':    { label: 'Ease Out' },
              'ease-in-out': { label: 'Ease In Out' },
              'back-out':    { label: 'Back Out' }
            } } },
            // Nothing to curve when the toggle is instant.
            visible: function (p) { return isOn(p) && 0 !== parseInt(trimValue(p, 'readmore_duration', '400'), 10); }
          }},
          readmore_disable_on_device: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_disable_on_device', label: 'Disabled On Device',
            description: 'Phone - disable Read More below 767px. Tablet - disable between 768px and 980px. Desktop - disable above 980px.',
            groupSlug: 'dnxteReadMore', priority: 25, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/select', props: { options: {
              'none':    { label: 'None' },
              'phone':   { label: 'Phone' },
              'tablet':  { label: 'Tablet' },
              'desktop': { label: 'Desktop' }
            } } },
            visible: isOn
          }},
          readmore_bg_color: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_bg_color', label: 'Link Background',
            description: 'Background colour of the Read More bar. In Height mode the fade above the bar follows this colour too. Leave empty for the default (white bar in Height mode, transparent in Word Count mode).',
            groupSlug: 'dnxteReadMore', priority: 32, render: true,
            features: { sticky: false },
            component: { type: 'field', name: 'divi/color-picker' },
            visible: isOn
          }},
          readmore_custom_css: { groupType: 'group-item', item: {
            attrName: 'dnxte_readmore.advanced.readmore_custom_css', label: 'Link Custom CSS',
            description: 'Add / customize the Read More link with custom CSS.',
            groupSlug: 'dnxteReadMore', priority: 40, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: 'field', name: 'divi/code', props: { mode: 'css' } },
            visible: isOn
          }}
        },

        decoration: {
          // Divi checks component.props.visible for group items — item-level
          // `visible` only gates plain fields — so the gate is set in both places.
          font: { groupType: 'group-item', item: {
            groupSlug: 'dnxteReadMore', priority: 30, render: true,
            component: {
              type: 'group',
              name: 'divi/font',
              props: {
                grouped: false,
                fieldLabel: 'Read More Link',
                visible: isOn,
                fields: {
                  headingLevel: { render: false }
                }
              }
            },
            visible: isOn
          }},
          // Box Shadow — Divi's own preset library plus the custom controls.
          boxShadow: { groupType: 'group-item', item: {
            groupSlug: 'dnxteReadMore', priority: 35, render: true,
            component: {
              type: 'group',
              name: 'divi/box-shadow',
              props: {
                grouped: false,
                fieldLabel: 'Read More Link',
                visible: isOn
              }
            },
            visible: isOn
          }}
        }
      }
    };

    if (meta && typeof meta === 'object') {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteReadMore) {
        meta.settings.groups.dnxteReadMore = buildGroup();
      }
    }

    return attrs;
  });

  // ─── Live preview ───
  // The PHP wrapper filter does not run in the VB (modules render client-side in
  // React), so the editor preview is driven here. Mirrors the mapping in
  // ReadMoreExtension::filter_wrapper_render() — keep the two in sync.
  function buildConfig(attrs) {
    var a = attrs?.dnxte_readmore?.advanced || {};
    function v(key, fallback) {
      var out = a?.[key]?.desktop?.value;
      return (out === undefined || out === null || out === '') ? fallback : out;
    }
    var font = attrs?.dnxte_readmore?.decoration?.font?.font?.desktop?.value || {};
    var hover = attrs?.dnxte_readmore?.decoration?.font?.font?.desktop?.hover || {};

    var css = '';
    if (font.family) css += 'font-family:' + font.family + ';';
    if (font.weight) css += 'font-weight:' + font.weight + ';';
    if (font.color) css += 'color:' + font.color + ';';
    if (font.lineHeight) css += 'line-height:' + font.lineHeight + ';';
    if (font.letterSpacing) css += 'letter-spacing:' + font.letterSpacing + ';';
    // No display override here: the engine turns text-align into justify-content
    // on the inline-flex bar, so the canvas and the frontend align identically.
    if (font.textAlign) css += 'text-align:' + font.textAlign + ';';
    if (font.style) {
      if (font.style.indexOf('italic') !== -1) css += 'font-style:italic;';
      if (font.style.indexOf('uppercase') !== -1) css += 'text-transform:uppercase;';
      if (font.style.indexOf('underline') !== -1) css += 'text-decoration:underline;';
    }

    return {
      enabled: v('use_readmore', 'off'),
      trim: v('readmore_trim_type', 'height'),
      words: parseInt(v('readmore_word_count', '50'), 10) || 50,
      height: parseFloat(v('readmore_height', '200')) || 200,
      more: v('readmore_text', 'Read more'),
      less: v('readmore_less_text', 'Read less'),
      keepLess: 'off' !== v('readmore_no_less', 'on'),
      duration: parseInt(v('readmore_duration', '400'), 10) || 0,
      easing: v('readmore_easing', 'ease'),
      device: v('readmore_disable_on_device', 'none'),
      fontSize: font.size || '',
      fontCss: css,
      hoverColor: hover.color || '',
      bg: v('readmore_bg_color', ''),
      shadow: shadowCss(attrs?.dnxte_readmore?.decoration?.boxShadow?.desktop?.value),
      customCss: v('readmore_custom_css', '')
    };
  }

  function ReadMoreInjector(props) {
    var ref = React.useRef(null);
    var instRef = React.useRef(null);
    var raw = props.config || '';
    // Word trimming measures the rendered text, so the instance has to be rebuilt
    // when the module's own content changes, not only when a Read More setting does.
    var content = props.content || '';

    function getHostEl() {
      if (!ref.current) return null;
      var el = ref.current.parentElement;
      while (el) {
        if (el.classList.contains('et_pb_module') || el.dataset.diviRenderer) return el;
        el = el.parentElement;
      }
      return ref.current.parentElement;
    }

    function teardown() {
      if (instRef.current && instRef.current.destroy) {
        try { instRef.current.destroy(); } catch (e) {}
      }
      instRef.current = null;
    }

    React.useEffect(function () {
      if (!window.DnxteReadMore) return;
      // Let Divi finish painting the module before measuring its height.
      var timer = setTimeout(function () {
        var host = getHostEl();
        if (!host) return;

        teardown();
        // The engine's MutationObserver may have instantiated on this node too;
        // without this the VB accumulates bars on every keystroke.
        if (host._dnxteReadMore && host._dnxteReadMore.destroy) {
          try { host._dnxteReadMore.destroy(); } catch (e) {}
        }

        var cfg;
        try { cfg = raw ? JSON.parse(raw) : null; } catch (e) { cfg = null; }
        if (cfg && 'on' === cfg.enabled) {
          instRef.current = new window.DnxteReadMore(host, cfg);
          host._dnxteReadMore = instRef.current;
        }
      }, 80);
      return function () { clearTimeout(timer); teardown(); };
    }, [raw, content]);

    return element.createElement('span', {
      ref: ref,
      'data-dnxte-readmore-injector': '',
      style: { display: 'none', position: 'absolute', pointerEvents: 'none' }
    });
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-readmore', function (moduleWrapper, param) {
    if (!isTarget(param.name)) return moduleWrapper;
    if ('on' !== param.attrs?.dnxte_readmore?.advanced?.use_readmore?.desktop?.value) {
      return moduleWrapper;
    }
    var raw = JSON.stringify(buildConfig(param.attrs));
    var children = moduleWrapper.props.children;
    var childArray = Array.isArray(children) ? children : [children];
    var injector = element.createElement(ReadMoreInjector, {
      key: 'dnxte-readmore-injector',
      config: raw,
      content: JSON.stringify(param.attrs?.content || '')
    });
    return element.cloneElement(moduleWrapper, {}, childArray.concat([injector]));
  });
})();
