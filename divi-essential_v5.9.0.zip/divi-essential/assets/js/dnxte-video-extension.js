/**
 * Video Background — Section Extension
 * Adds video background with full controls to Divi Section.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var el = wp.element;
  var ce = el.createElement;
  var TARGET = ['divi/section', 'divi/row', 'divi/column'];

  // Option maps
  var SOURCE_TYPES = {
    'self-hosted': { label: 'Self Hosted (MP4)' },
    'youtube':     { label: 'YouTube' },
    'vimeo':       { label: 'Vimeo' },
  };
  var MOBILE_BEHAVIOR = {
    'image': { label: 'Show Fallback Image' },
    'play':  { label: 'Play Normally' },
    'hide':  { label: 'Hide Video' },
  };
  var OBJECT_FITS = {
    'cover':   { label: 'Cover' },
    'contain': { label: 'Contain' },
    'fill':    { label: 'Fill' },
  };
  var SCROLL_EFFECTS = {
    'none':       { label: 'None' },
    'parallax':   { label: 'Parallax' },
    'fade':       { label: 'Fade In' },
    'zoom':       { label: 'Zoom Out' },
    'blur-clear': { label: 'Blur to Clear' },
    'clip-reveal':{ label: 'Circle Reveal' },
    'scrub':      { label: 'Scroll Scrub (MP4 only)' },
  };
  var OVERLAY_TYPES = {
    'none':     { label: 'None' },
    'color':    { label: 'Color' },
    'gradient': { label: 'Gradient' },
  };
  var CTRL_POSITIONS = {
    'bottom-right':  { label: 'Bottom Right' },
    'bottom-left':   { label: 'Bottom Left' },
    'bottom-center': { label: 'Bottom Center' },
    'top-right':     { label: 'Top Right' },
  };

  function isOn(p) {
    return 'on' === (p.attrs?.video_config?.advanced?.use_video_bg?.desktop?.value);
  }
  function getSource(p) {
    return p.attrs?.video_config?.advanced?.source_type?.desktop?.value || 'self-hosted';
  }
  function getOverlay(p) {
    return p.attrs?.video_config?.advanced?.overlay_type?.desktop?.value || 'none';
  }
  function hasControls(p) {
    return isOn(p) && 'on' === (p.attrs?.video_config?.advanced?.show_controls?.desktop?.value);
  }

  // ════════════════════════════════════════════════════════════
  // 1. OPTION GROUP
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-video', function (groups, meta) {
    if (TARGET.indexOf(meta.name) === -1) return groups;
    groups.dnxteVideo = {
      groupName: 'dnxteVideo', panel: 'design', priority: 86, multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Video Background' } }
    };
    return groups;
  });

  // ════════════════════════════════════════════════════════════
  // 2. ATTRIBUTES
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-video', function (attrs, meta) {
    if (TARGET.indexOf(meta.name) === -1) return attrs;

    attrs.video_config = {
      type: 'object', selector: '{{selector}}',
      default: { advanced: {
        use_video_bg: { desktop: { value: 'off' } },
        source_type: { desktop: { value: 'self-hosted' } },
        video_url: { desktop: { value: '' } },
        youtube_id: { desktop: { value: '' } },
        vimeo_id: { desktop: { value: '' } },
        fallback_image: { desktop: { value: '' } },
        autoplay: { desktop: { value: 'on' } },
        loop: { desktop: { value: 'on' } },
        muted: { desktop: { value: 'on' } },
        start_time: { desktop: { value: '0' } },
        end_time: { desktop: { value: '0' } },
        playback_speed: { desktop: { value: '1' } },
        play_in_viewport: { desktop: { value: 'on' } },
        disable_on_mobile: { desktop: { value: 'off' } },
        mobile_behavior: { desktop: { value: 'image' } },
        lazy_load: { desktop: { value: 'on' } },
        reduced_motion: { desktop: { value: 'on' } },
        overlay_type: { desktop: { value: 'none' } },
        overlay_color: { desktop: { value: 'rgba(0,0,0,0.4)' } },
        overlay_opacity: { desktop: { value: '1' } },
        object_fit: { desktop: { value: 'cover' } },
        brightness: { desktop: { value: '100' } },
        contrast: { desktop: { value: '100' } },
        saturation: { desktop: { value: '100' } },
        blur: { desktop: { value: '0' } },
        scroll_effect: { desktop: { value: 'none' } },
        scroll_intensity: { desktop: { value: '1' } },
        show_controls: { desktop: { value: 'off' } },
        controls_position: { desktop: { value: 'bottom-right' } },
        control_icon_size: { desktop: { value: '20' } },
        control_icon_color: { desktop: { value: '#ffffff' } },
        control_bg_color: { desktop: { value: 'rgba(0,0,0,0.5)' } },
      }},
      settings: { advanced: {
        // ── Enable ──
        use_video_bg: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.use_video_bg', label: 'Enable Video Background',
          groupSlug: 'dnxteVideo', priority: 1, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }
        }},
        // ── Source ──
        source_type: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.source_type', label: 'Video Source',
          groupSlug: 'dnxteVideo', priority: 2, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: SOURCE_TYPES } },
          visible: isOn
        }},
        video_url: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.video_url', label: 'Video URL (MP4)',
          description: 'Direct link to MP4 file',
          groupSlug: 'dnxteVideo', priority: 3, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: function(p) { return isOn(p) && getSource(p) === 'self-hosted'; }
        }},
        youtube_id: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.youtube_id', label: 'YouTube Video ID',
          description: 'e.g. dQw4w9WgXcQ',
          groupSlug: 'dnxteVideo', priority: 4, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: function(p) { return isOn(p) && getSource(p) === 'youtube'; }
        }},
        vimeo_id: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.vimeo_id', label: 'Vimeo Video ID',
          description: 'e.g. 336812686',
          groupSlug: 'dnxteVideo', priority: 5, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: function(p) { return isOn(p) && getSource(p) === 'vimeo'; }
        }},
        fallback_image: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.fallback_image', label: 'Fallback Image URL',
          groupSlug: 'dnxteVideo', priority: 6, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: isOn
        }},
        // ── Playback ──
        autoplay: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.autoplay', label: 'Autoplay',
          groupSlug: 'dnxteVideo', priority: 10, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        loop: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.loop', label: 'Loop',
          groupSlug: 'dnxteVideo', priority: 11, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        muted: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.muted', label: 'Muted',
          groupSlug: 'dnxteVideo', priority: 12, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        playback_speed: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.playback_speed', label: 'Playback Speed',
          groupSlug: 'dnxteVideo', priority: 13, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.25, max: 2, step: 0.25 } },
          visible: function(p) { return isOn(p) && getSource(p) === 'self-hosted'; }
        }},
        start_time: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.start_time', label: 'Start Time (s)',
          groupSlug: 'dnxteVideo', priority: 14, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 300, step: 1 } },
          visible: isOn
        }},
        end_time: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.end_time', label: 'End Time (s, 0=full)',
          groupSlug: 'dnxteVideo', priority: 15, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 300, step: 1 } },
          visible: isOn
        }},
        // ── Visibility ──
        play_in_viewport: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.play_in_viewport', label: 'Play Only in Viewport',
          groupSlug: 'dnxteVideo', priority: 20, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        disable_on_mobile: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.disable_on_mobile', label: 'Disable on Mobile',
          groupSlug: 'dnxteVideo', priority: 21, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        mobile_behavior: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.mobile_behavior', label: 'Mobile Behavior',
          groupSlug: 'dnxteVideo', priority: 22, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: MOBILE_BEHAVIOR } },
          visible: function(p) { return isOn(p) && 'on' === (p.attrs?.video_config?.advanced?.disable_on_mobile?.desktop?.value); }
        }},
        reduced_motion: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.reduced_motion', label: 'Respect Reduced Motion',
          groupSlug: 'dnxteVideo', priority: 23, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        // ── Overlay ──
        overlay_type: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.overlay_type', label: 'Overlay',
          groupSlug: 'dnxteVideo', priority: 30, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: OVERLAY_TYPES } },
          visible: isOn
        }},
        overlay_color: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.overlay_color', label: 'Overlay Color',
          groupSlug: 'dnxteVideo', priority: 31, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function(p) { return isOn(p) && getOverlay(p) === 'color'; }
        }},
        overlay_opacity: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.overlay_opacity', label: 'Overlay Opacity',
          groupSlug: 'dnxteVideo', priority: 32, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 1, step: 0.05 } },
          visible: function(p) { return isOn(p) && getOverlay(p) !== 'none'; }
        }},
        // ── Appearance ──
        object_fit: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.object_fit', label: 'Object Fit',
          groupSlug: 'dnxteVideo', priority: 40, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: OBJECT_FITS } },
          visible: isOn
        }},
        // ── Filters ──
        brightness: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.brightness', label: 'Brightness',
          groupSlug: 'dnxteVideo', priority: 50, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 200, step: 5 } },
          visible: isOn
        }},
        contrast: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.contrast', label: 'Contrast',
          groupSlug: 'dnxteVideo', priority: 51, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 200, step: 5 } },
          visible: isOn
        }},
        saturation: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.saturation', label: 'Saturation',
          groupSlug: 'dnxteVideo', priority: 52, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 200, step: 5 } },
          visible: isOn
        }},
        blur: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.blur', label: 'Blur',
          groupSlug: 'dnxteVideo', priority: 53, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 20, step: 1 } },
          visible: isOn
        }},
        // ── Scroll Effects ──
        scroll_effect: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.scroll_effect', label: 'Scroll Effect',
          groupSlug: 'dnxteVideo', priority: 60, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: SCROLL_EFFECTS } },
          visible: isOn
        }},
        scroll_intensity: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.scroll_intensity', label: 'Scroll Intensity',
          groupSlug: 'dnxteVideo', priority: 61, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 2, step: 0.1 } },
          visible: function(p) { return isOn(p) && (p.attrs?.video_config?.advanced?.scroll_effect?.desktop?.value || 'none') !== 'none'; }
        }},
        // ── Controls ──
        show_controls: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.show_controls', label: 'Show Controls',
          groupSlug: 'dnxteVideo', priority: 70, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }, visible: isOn
        }},
        controls_position: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.controls_position', label: 'Controls Position',
          groupSlug: 'dnxteVideo', priority: 71, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: CTRL_POSITIONS } },
          visible: hasControls
        }},
        control_icon_size: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.control_icon_size', label: 'Icon Size',
          groupSlug: 'dnxteVideo', priority: 72, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 12, max: 40, step: 2 } },
          visible: hasControls
        }},
        control_icon_color: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.control_icon_color', label: 'Icon Color',
          groupSlug: 'dnxteVideo', priority: 73, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: hasControls
        }},
        control_bg_color: { groupType: 'group-item', item: {
          attrName: 'video_config.advanced.control_bg_color', label: 'Control Background',
          groupSlug: 'dnxteVideo', priority: 74, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: hasControls
        }},
      }}
    };
    return attrs;
  });

  // ════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER
  // ════════════════════════════════════════════════════════════
  function VideoInjector(props) {
    var React = window.vendor.React;
    var ref = React.useRef(null);
    var instanceRef = React.useRef(null);
    var vc = props.moduleAttrs?.video_config?.advanced;

    React.useEffect(function () {
      if (vc?.use_video_bg?.desktop?.value !== 'on') return;

      var timer = setTimeout(function () {
        if (!ref.current) return;
        var sectionEl = ref.current.parentElement;
        while (sectionEl) {
          if (sectionEl.classList.contains('et_pb_section') || sectionEl.dataset.diviRenderer) break;
          sectionEl = sectionEl.parentElement;
        }
        if (!sectionEl) sectionEl = ref.current.parentElement;
        if (!window.DnxteVideoBackground) return;

        var v = function(k, def) { return vc?.[k]?.desktop?.value ?? def; };

        instanceRef.current = new window.DnxteVideoBackground(sectionEl, {
          sourceType:       v('source_type', 'self-hosted'),
          videoUrl:         v('video_url', ''),
          youtubeId:        String(v('youtube_id', '') || ''),
          vimeoId:          String(v('vimeo_id', '') || ''),
          fallbackImage:    v('fallback_image', ''),
          autoplay:         v('autoplay', 'on') === 'on',
          loop:             v('loop', 'on') === 'on',
          muted:            v('muted', 'on') === 'on',
          startTime:        parseFloat(v('start_time', 0)),
          endTime:          parseFloat(v('end_time', 0)),
          playbackSpeed:    parseFloat(v('playback_speed', 1)),
          playInViewport:   v('play_in_viewport', 'on') === 'on',
          disableOnMobile:  v('disable_on_mobile', 'off') === 'on',
          mobileBehavior:   v('mobile_behavior', 'image'),
          lazyLoad:         v('lazy_load', 'on') === 'on',
          reducedMotion:    v('reduced_motion', 'on') === 'on',
          overlayType:      v('overlay_type', 'none'),
          overlayColor:     v('overlay_color', 'rgba(0,0,0,0.4)'),
          overlayOpacity:   parseFloat(v('overlay_opacity', 1)),
          objectFit:        v('object_fit', 'cover'),
          brightness:       parseInt(v('brightness', 100)),
          contrast:         parseInt(v('contrast', 100)),
          saturation:       parseInt(v('saturation', 100)),
          blur:             parseInt(v('blur', 0)),
          scrollEffect:     v('scroll_effect', 'none'),
          scrollIntensity:  parseFloat(v('scroll_intensity', 1)),
          showControls:     v('show_controls', 'off') === 'on',
          controlsPosition: v('controls_position', 'bottom-right'),
          controlIconSize:  parseInt(v('control_icon_size', 20)),
          controlIconColor: v('control_icon_color', '#ffffff'),
          controlBgColor:   v('control_bg_color', 'rgba(0,0,0,0.5)'),
        });
      }, 150);

      return function () {
        clearTimeout(timer);
        if (instanceRef.current) { instanceRef.current.destroy(); instanceRef.current = null; }
      };
    }, [JSON.stringify(vc)]);

    return ce('span', { ref: ref, style: { display: 'none', position: 'absolute', pointerEvents: 'none' } });
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-video', function (wrapper, param) {
    if (TARGET.indexOf(param.name) === -1) return wrapper;
    if (param.attrs?.video_config?.advanced?.use_video_bg?.desktop?.value !== 'on') return wrapper;

    var children = wrapper.props.children;
    var arr = Array.isArray(children) ? children : [children];
    return el.cloneElement(wrapper, {}, arr.concat([
      ce(VideoInjector, { key: 'dnxte-video-injector', moduleAttrs: param.attrs })
    ]));
  });
})();
