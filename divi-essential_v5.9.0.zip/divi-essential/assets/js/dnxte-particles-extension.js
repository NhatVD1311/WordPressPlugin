/**
 * Divi Essential - Particle Effects Extension for Section
 * Adds particle effect options to Divi Section via hooks.
 *
 * @package DNXTE
 */

(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var element = wp.element;

  var TARGET_MODULES = ['divi/section', 'divi/row', 'divi/column'];

  // All 40 particle types organized by category
  var PARTICLE_TYPES = {
    // Celebration
    'confetti':        { label: 'Confetti Burst' },
    'fireworks':       { label: 'Fireworks' },
    'streamers':       { label: 'Party Streamers' },
    'balloons':        { label: 'Rising Balloons' },
    'champagne':       { label: 'Champagne Pop' },
    'glitter':         { label: 'Glitter Rain' },
    'starburst':       { label: 'Star Celebration' },
    'emoji':           { label: 'Emoji Party' },
    // Nature
    'snowfall':        { label: 'Snowfall' },
    'fireflies':       { label: 'Fireflies' },
    'cherry-blossoms': { label: 'Cherry Blossoms' },
    'rain':            { label: 'Rain Storm' },
    'leaves':          { label: 'Autumn Leaves' },
    'bubbles':         { label: 'Bubbles' },
    // Cosmic
    'galaxy':          { label: 'Galaxy Spiral' },
    'starfield':       { label: 'Starfield' },
    'nebula':          { label: 'Nebula Cloud' },
    'comets':          { label: 'Comet Trails' },
    // Tech
    'matrix':          { label: 'Matrix Rain' },
    'network':         { label: 'Network Nodes' },
    'dna':             { label: 'DNA Helix' },
    // Abstract
    'wave':            { label: 'Wave Motion' },
    'magnetic':        { label: 'Magnetic Orbit' },
    'aurora':          { label: 'Aurora Waves' },
    'geometric':       { label: 'Geometric Float' },
    'pulse-rings':     { label: 'Pulse Rings' },
    'vortex':          { label: 'Vortex' },
    'sparks':          { label: 'Rising Sparks' },
    'dust':            { label: 'Dust Motes' },
    'blobs':           { label: 'Morphing Blobs' },
    // Interactive
    'mouse-attract':   { label: 'Mouse Attraction' },
    'mouse-repel':     { label: 'Mouse Repulsion' },
    'mouse-trail':     { label: 'Magnetic Trail' },
    'hover-burst':     { label: 'Hover Explosion' },
    'swarm':           { label: 'Swarm Follow' },
    'gravity-well':    { label: 'Gravity Well' },
    'connection-web':  { label: 'Connection Web' },
    'ripple':          { label: 'Ripple Effect' },
    'orbit-cursor':    { label: 'Orbit Cursor' },
    'color-wave':      { label: 'Color Wave' }
  };

  // Types that have burst intervals
  var BURST_TYPES = ['confetti', 'fireworks', 'champagne', 'starburst', 'pulse-rings', 'comets'];
  // Types with connection lines
  var CONNECTION_TYPES = ['network', 'connection-web'];
  // Types with wind
  var WIND_TYPES = ['snowfall', 'cherry-blossoms', 'rain', 'leaves', 'glitter', 'streamers', 'confetti', 'balloons', 'bubbles', 'sparks', 'dust'];
  // Interactive types
  var INTERACTIVE_TYPES = ['mouse-attract', 'mouse-repel', 'mouse-trail', 'hover-burst', 'swarm', 'gravity-well', 'connection-web', 'ripple', 'orbit-cursor', 'color-wave'];
  // Types that benefit from width control (centered effects)
  var WIDTH_TYPES = ['galaxy', 'dna', 'magnetic', 'orbit-cursor', 'wave', 'vortex', 'pulse-rings', 'network', 'blobs', 'nebula', 'aurora', 'dust', 'ripple', 'color-wave', 'starfield', 'connection-web'];
  // Types that DON'T support custom colors (use fixed/theme colors)
  var NO_COLOR_TYPES = ['emoji', 'snowfall', 'rain', 'champagne', 'glitter', 'cherry-blossoms', 'fireflies', 'matrix', 'dust'];

  function isEnabled(p) {
    return 'on' === (p.attrs?.particle_settings?.advanced?.use_particles?.desktop?.value);
  }

  function getType(p) {
    return p.attrs?.particle_settings?.advanced?.particle_type?.desktop?.value || 'snowfall';
  }

  function isTypeIn(p, list) {
    return isEnabled(p) && list.indexOf(getType(p)) !== -1;
  }

  // ════════════════════════════════════════════════════════════════════
  // 1. ADD OPTION GROUP
  // ════════════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleSettings.groups',
    'dnxte-particles',
    function (groups, metadata) {
      if (TARGET_MODULES.indexOf(metadata.name) === -1) return groups;

      groups.dnxteParticles = {
        groupName:     'dnxteParticles',
        panel:         'design',
        priority:      82,
        multiElements: true,
        component: {
          name:  'divi/composite',
          props: { groupLabel: 'Particle Effects' }
        }
      };

      return groups;
    }
  );

  // ════════════════════════════════════════════════════════════════════
  // 2. ADD ATTRIBUTES
  // ════════════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleAttributes',
    'dnxte-particles',
    function (attributes, metadata) {
      if (TARGET_MODULES.indexOf(metadata.name) === -1) return attributes;

      attributes.particle_settings = {
        type: 'object',
        selector: '{{selector}}',
        default: {
          decoration: {
            color1: { desktop: { value: '#00d4aa' } },
            color2: { desktop: { value: '#7c3aed' } },
            color3: { desktop: { value: '' } },
            color4: { desktop: { value: '' } }
          },
          advanced: {
            use_particles:       { desktop: { value: 'off' } },
            particle_type:       { desktop: { value: 'snowfall' } },
            count:               { desktop: { value: '40' } },
            speed:               { desktop: { value: '1' } },
            size:                { desktop: { value: '1' } },
            opacity:             { desktop: { value: '0.8' } },
            trigger:             { desktop: { value: 'always' } },
            effect_width:        { desktop: { value: '100' } },
            glow:                { desktop: { value: 'off' } },
            glow_intensity:      { desktop: { value: '1' } },
            wind:                { desktop: { value: '0' } },
            wind_strength:       { desktop: { value: '1' } },
            burst_interval:      { desktop: { value: '2000' } },
            connection_distance: { desktop: { value: '150' } },
            force_strength:      { desktop: { value: '1' } },
            force_radius:        { desktop: { value: '150' } }
          }
        },
        settings: {
          decoration: {
            color1: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.decoration.color1',
                label: 'Primary Color',
                groupSlug: 'dnxteParticles',
                priority: 20,
                render: true,
                features: { sticky: false, responsive: false },
                component: { type: 'field', name: 'divi/color-picker' },
                visible: function (p) { return isEnabled(p) && NO_COLOR_TYPES.indexOf(getType(p)) === -1; }
              }
            },
            color2: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.decoration.color2',
                label: 'Secondary Color',
                groupSlug: 'dnxteParticles',
                priority: 25,
                render: true,
                features: { sticky: false, responsive: false },
                component: { type: 'field', name: 'divi/color-picker' },
                visible: function (p) { return isEnabled(p) && NO_COLOR_TYPES.indexOf(getType(p)) === -1; }
              }
            },
            color3: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.decoration.color3',
                label: 'Color 3',
                description: 'Optional third color for multi-color effects',
                groupSlug: 'dnxteParticles',
                priority: 26,
                render: true,
                features: { sticky: false, responsive: false },
                component: { type: 'field', name: 'divi/color-picker' },
                visible: function (p) { return isEnabled(p) && NO_COLOR_TYPES.indexOf(getType(p)) === -1; }
              }
            },
            color4: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.decoration.color4',
                label: 'Color 4',
                description: 'Optional fourth color for multi-color effects',
                groupSlug: 'dnxteParticles',
                priority: 27,
                render: true,
                features: { sticky: false, responsive: false },
                component: { type: 'field', name: 'divi/color-picker' },
                visible: function (p) { return isEnabled(p) && NO_COLOR_TYPES.indexOf(getType(p)) === -1; }
              }
            }
          },
          advanced: {
            use_particles: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.use_particles',
                label: 'Enable Particles',
                groupSlug: 'dnxteParticles',
                priority: 10,
                render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' }
              }
            },
            particle_type: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.particle_type',
                label: 'Particle Type',
                groupSlug: 'dnxteParticles',
                priority: 15,
                render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: {
                  type: 'field',
                  name: 'divi/select',
                  props: { options: PARTICLE_TYPES }
                },
                visible: isEnabled
              }
            },
            count: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.count',
                label: 'Particle Count',
                groupSlug: 'dnxteParticles',
                priority: 30,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 5, max: 200, step: 1 } },
                visible: isEnabled
              }
            },
            speed: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.speed',
                label: 'Speed',
                groupSlug: 'dnxteParticles',
                priority: 35,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 5, step: 0.1 } },
                visible: isEnabled
              }
            },
            size: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.size',
                label: 'Size',
                groupSlug: 'dnxteParticles',
                priority: 40,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 3, step: 0.1 } },
                visible: isEnabled
              }
            },
            opacity: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.opacity',
                label: 'Opacity',
                groupSlug: 'dnxteParticles',
                priority: 45,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0, max: 1, step: 0.05 } },
                visible: isEnabled
              }
            },
            trigger: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.trigger',
                label: 'Trigger',
                groupSlug: 'dnxteParticles',
                priority: 50,
                render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: {
                  type: 'field',
                  name: 'divi/select',
                  props: {
                    options: {
                      'always': { label: 'Always' },
                      'scroll': { label: 'On Scroll' },
                      'hover':  { label: 'On Hover' }
                    }
                  }
                },
                visible: isEnabled
              }
            },
            effect_width: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.effect_width',
                label: 'Effect Width',
                description: 'Restrict effect to center area (10-100%)',
                groupSlug: 'dnxteParticles',
                priority: 52,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 10, max: 100, step: 5, allowedUnits: ['%'] } },
                visible: function (p) { return isTypeIn(p, WIDTH_TYPES); }
              }
            },
            glow: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.glow',
                label: 'Glow Effect',
                groupSlug: 'dnxteParticles',
                priority: 55,
                render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' },
                visible: isEnabled
              }
            },
            glow_intensity: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.glow_intensity',
                label: 'Glow Intensity',
                groupSlug: 'dnxteParticles',
                priority: 56,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 3, step: 0.1 } },
                visible: function (p) {
                  return isEnabled(p) && 'on' === (p.attrs?.particle_settings?.advanced?.glow?.desktop?.value);
                }
              }
            },
            wind: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.wind',
                label: 'Wind Direction',
                description: 'Negative = left, Positive = right',
                groupSlug: 'dnxteParticles',
                priority: 60,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: -5, max: 5, step: 0.5 } },
                visible: function (p) { return isTypeIn(p, WIND_TYPES); }
              }
            },
            wind_strength: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.wind_strength',
                label: 'Wind Strength',
                groupSlug: 'dnxteParticles',
                priority: 61,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 5, step: 0.1 } },
                visible: function (p) {
                  return isTypeIn(p, WIND_TYPES) &&
                    parseFloat(p.attrs?.particle_settings?.advanced?.wind?.desktop?.value || 0) !== 0;
                }
              }
            },
            burst_interval: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.burst_interval',
                label: 'Burst Interval (ms)',
                groupSlug: 'dnxteParticles',
                priority: 65,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 500, max: 10000, step: 100 } },
                visible: function (p) { return isTypeIn(p, BURST_TYPES); }
              }
            },
            connection_distance: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.connection_distance',
                label: 'Connection Distance',
                groupSlug: 'dnxteParticles',
                priority: 70,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 50, max: 400, step: 10 } },
                visible: function (p) { return isTypeIn(p, CONNECTION_TYPES); }
              }
            },
            force_strength: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.force_strength',
                label: 'Force Strength',
                groupSlug: 'dnxteParticles',
                priority: 75,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 5, step: 0.1 } },
                visible: function (p) { return isTypeIn(p, INTERACTIVE_TYPES); }
              }
            },
            force_radius: {
              groupType: 'group-item',
              item: {
                attrName: 'particle_settings.advanced.force_radius',
                label: 'Force Radius',
                groupSlug: 'dnxteParticles',
                priority: 76,
                render: true,
                features: { sticky: false },
                component: { type: 'field', name: 'divi/range', props: { min: 50, max: 400, step: 10 } },
                visible: function (p) { return isTypeIn(p, INTERACTIVE_TYPES); }
              }
            }
          }
        }
      };

      return attributes;
    }
  );

  // ════════════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER — init particle engine on the section
  // ════════════════════════════════════════════════════════════════════

  function getParticleOptions(attrs) {
    var ps = attrs.particle_settings;
    return {
      type:               ps?.advanced?.particle_type?.desktop?.value || 'snowfall',
      count:              parseInt(ps?.advanced?.count?.desktop?.value || 40),
      speed:              parseFloat(ps?.advanced?.speed?.desktop?.value || 1),
      color1:             ps?.decoration?.color1?.desktop?.value || '#00d4aa',
      color2:             ps?.decoration?.color2?.desktop?.value || '#7c3aed',
      color3:             ps?.decoration?.color3?.desktop?.value || '',
      color4:             ps?.decoration?.color4?.desktop?.value || '',
      size:               parseFloat(ps?.advanced?.size?.desktop?.value || 1),
      opacity:            parseFloat(ps?.advanced?.opacity?.desktop?.value || 0.8),
      trigger:            'always', // Always in VB for live preview
      interactive:        false,
      effectWidth:        parseInt(ps?.advanced?.effect_width?.desktop?.value || 100),
      glow:               ps?.advanced?.glow?.desktop?.value === 'on',
      glowIntensity:      parseFloat(ps?.advanced?.glow_intensity?.desktop?.value || 1),
      wind:               parseFloat(ps?.advanced?.wind?.desktop?.value || 0),
      windStrength:       parseFloat(ps?.advanced?.wind_strength?.desktop?.value || 1),
      burstInterval:      parseInt(ps?.advanced?.burst_interval?.desktop?.value || 2000),
      connectionDistance: parseFloat(ps?.advanced?.connection_distance?.desktop?.value || 150),
      forceStrength:      parseFloat(ps?.advanced?.force_strength?.desktop?.value || 1),
      forceRadius:        parseFloat(ps?.advanced?.force_radius?.desktop?.value || 150)
    };
  }

  // Build a flat dep array from all particle attrs for useEffect
  function getDepArray(attrs) {
    var ps = attrs?.particle_settings;
    if (!ps) return [];
    return [
      ps?.advanced?.use_particles?.desktop?.value,
      ps?.advanced?.particle_type?.desktop?.value,
      ps?.advanced?.count?.desktop?.value,
      ps?.advanced?.speed?.desktop?.value,
      ps?.decoration?.color1?.desktop?.value,
      ps?.decoration?.color2?.desktop?.value,
      ps?.decoration?.color3?.desktop?.value,
      ps?.decoration?.color4?.desktop?.value,
      ps?.advanced?.size?.desktop?.value,
      ps?.advanced?.opacity?.desktop?.value,
      ps?.advanced?.trigger?.desktop?.value,
      ps?.advanced?.effect_width?.desktop?.value,
      ps?.advanced?.glow?.desktop?.value,
      ps?.advanced?.glow_intensity?.desktop?.value,
      ps?.advanced?.wind?.desktop?.value,
      ps?.advanced?.wind_strength?.desktop?.value,
      ps?.advanced?.burst_interval?.desktop?.value,
      ps?.advanced?.connection_distance?.desktop?.value,
      ps?.advanced?.force_strength?.desktop?.value,
      ps?.advanced?.force_radius?.desktop?.value
    ];
  }

  function ParticleInjector(props) {
    var React = window.vendor.React;
    var helperRef = React.useRef(null);
    var engineRef = React.useRef(null);
    var moduleAttrs = props.moduleAttrs;

    var useParticles = moduleAttrs?.particle_settings?.advanced?.use_particles?.desktop?.value;

    function getModuleEl() {
      if (!helperRef.current) return null;
      var el = helperRef.current.parentElement;
      while (el) {
        if (el.classList.contains('et_pb_section') || el.dataset.diviRenderer) return el;
        el = el.parentElement;
      }
      return helperRef.current.parentElement;
    }

    React.useEffect(function () {
      if (useParticles !== 'on') return;

      var timer = setTimeout(function () {
        var el = getModuleEl();
        if (!el || !window.DnxteParticleEngine) return;

        engineRef.current = new window.DnxteParticleEngine(el, getParticleOptions(moduleAttrs));
      }, 100);

      return function () {
        clearTimeout(timer);
        if (engineRef.current) {
          engineRef.current.destroy();
          engineRef.current = null;
        }
      };
    }, getDepArray(moduleAttrs));

    return element.createElement('span', {
      ref: helperRef,
      'data-dnxte-particle-injector': '',
      style: { display: 'none', position: 'absolute', pointerEvents: 'none' }
    });
  }

  hooks.addFilter(
    'divi.module.wrapper.render',
    'dnxte-particles',
    function (moduleWrapper, param) {
      if (TARGET_MODULES.indexOf(param.name) === -1) return moduleWrapper;

      var useParticles = param.attrs?.particle_settings?.advanced?.use_particles?.desktop?.value;
      if (useParticles !== 'on') return moduleWrapper;

      var children = moduleWrapper.props.children;
      var childArray = Array.isArray(children) ? children : [children];

      var injector = element.createElement(ParticleInjector, {
        key: 'dnxte-particle-injector',
        moduleAttrs: param.attrs
      });

      return element.cloneElement(moduleWrapper, {}, childArray.concat([injector]));
    }
  );

})();
