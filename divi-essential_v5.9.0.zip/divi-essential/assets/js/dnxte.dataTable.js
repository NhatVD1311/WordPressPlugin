/**
 * NextDataTable JavaScript functionality
 * Handles AJAX search, pagination, sorting, and filtering
 */

class DnxteDataTable {
	constructor(element) {
		this.table = element;
		this.wrapper = element.closest('.dnxt-datatable-wrapper');
		this.searchInput = this.wrapper.querySelector('.dnxt-datatable-search input');
		this.entriesSelect = this.wrapper.querySelector('.dnxt-datatable-pagination select');
		this.tbody = this.table.querySelector('tbody');
		this.tableInfo = this.wrapper.querySelector('.dnxt-table-info');
		this.paginationContainer = this.wrapper.querySelector('.dnxt-pagination');
		
		// Get pagination dot styling from data attributes
		this.paginationDotColor = this.wrapper.getAttribute('data-pagination-dot-color') || '#000000';
		this.paginationDotFontSize = this.wrapper.getAttribute('data-pagination-dot-font-size') || '16px';
		
		// Get initial pagination state from server-rendered data
		const totalPages = parseInt(this.table.getAttribute('data-total-pages')) || 1;
		const itemsPerPage = parseInt(this.table.getAttribute('data-items-per-page')) || 10;
		const totalItems = parseInt(this.table.getAttribute('data-total-items')) || 0;
		const currentPageFromServer = parseInt(this.paginationContainer?.getAttribute('data-current-page')) || 1;
		
		// Load translations once
		this.translations = this.loadTranslations();
		
		// Configuration
		this.currentPage = currentPageFromServer;
		this.entriesPerPage = itemsPerPage;
		this.totalPages = totalPages;
		this.totalItems = totalItems;
		this.searchTerm = '';
		this.sortColumn = null;
		this.sortDirection = 'asc';
		
		// Set default value for entries select if found
		if (this.entriesSelect) {
			// Get the default value from data attribute or use itemsPerPage
			const defaultValue = this.entriesSelect.getAttribute('data-default-value') || itemsPerPage;
			
			// Set the select value to match the default
			this.entriesSelect.value = defaultValue.toString();
			
			// Update entriesPerPage with the actual value
			const selectValue = parseInt(this.entriesSelect.value) || itemsPerPage;
			this.entriesPerPage = selectValue;
		}
		
		// Get column configuration from table headers
		this.columns = this.getColumnConfiguration();
		
		// Original data (should be loaded from server or attributes)
		this.originalData = this.getTableData();
		this.filteredData = [...this.originalData];
		
		this.init();
	}

	loadTranslations() {
		let translations = {};
		try {
			const attrTranslations = this.wrapper.getAttribute('data-translations');
			if (attrTranslations) {
				translations = JSON.parse(attrTranslations);
			}
		} catch (e) {
			console.error('Error parsing data-translations:', e);
		}

		// Fallback to global config if data-attribute is missing or empty
		if (!translations || Object.keys(translations).length === 0) {
			translations = window.dnxte_datatable_config?.translations || {};
		}

		// Final fallbacks for critical strings
		return {
			showing: translations.showing || 'Showing',
			to: translations.to || 'to',
			of: translations.of || 'of',
			entries: translations.entries || 'entries',
			noResults: translations.noResults || 'No matching records found',
			previous: translations.previous || 'Previous',
			next: translations.next || 'Next',
			search: translations.search || 'Search',
			...translations
		};
	}
	
	init() {        
		if (!this.wrapper) return;
		
		// Bind all events including pagination
		this.bindEvents();
		
		// Correct pagination if there's a mismatch between server and client calculations
		this.correctInitialPagination();
		
		// Initial table update with current data
		this.updateTable();
	}
	
	correctInitialPagination() {
		// Check if there's a mismatch between server pagination and client requirements
		const clientTotalPages = Math.ceil(this.filteredData.length / this.entriesPerPage);
		
		// If server-rendered pagination is different from what client calculates, update immediately
		if (this.totalPages !== clientTotalPages) {
			this.totalPages = clientTotalPages;
			
			// Reset current page if it exceeds the new total
			if (this.currentPage > clientTotalPages) {
				this.currentPage = Math.max(1, clientTotalPages);
			}
		}
	}
	
	getColumnConfiguration() {
		const headers = this.table.querySelectorAll('thead th');
		const columns = [];
		
		headers.forEach((header, index) => {
			const columnKey = header.getAttribute('data-column') || `column_${index}`;
			const columnType = header.getAttribute('data-type') || 'text';
			const isSortable = header.hasAttribute('data-column');
			
			columns.push({
				key: columnKey,
				label: header.textContent.replace('↕', '').trim(),
				type: columnType,
				sortable: isSortable,
				index: index
			});
		});
		
		return columns;
	}
	
	bindEvents() {
		// Search functionality
		if (this.searchInput) {
			this.searchInput.addEventListener('input', this.debounce((e) => {
				this.searchTerm = e.target.value.toLowerCase();
				this.currentPage = 1;
				this.filterAndUpdate();
			}, 300));
		}
		
		// Entries per page selection
		if (this.entriesSelect) {
			this.entriesSelect.addEventListener('change', (e) => {
				this.entriesPerPage = parseInt(e.target.value);
				this.currentPage = 1;
				this.updateTable();
			});
		}
		
		// Sort functionality
		const headers = this.table.querySelectorAll('th[style*="cursor: pointer"]');
		headers.forEach((header, index) => {
			header.addEventListener('click', () => {
				this.handleSort(index);
			});
		});
		
		// Pagination
		this.bindPaginationEvents();
	}
	
	bindPaginationEvents() {
		if (this.paginationContainer && !this.paginationContainer.hasAttribute('data-events-bound')) {
			// Mark as bound to prevent duplicate binding
			this.paginationContainer.setAttribute('data-events-bound', 'true');
			
			// Use event delegation for all pagination elements
			this.paginationContainer.addEventListener('click', (e) => {
				e.preventDefault();
				e.stopPropagation();
				
				const totalPages = Math.ceil(this.filteredData.length / this.entriesPerPage);
				
				// Handle Previous button clicks
				if (e.target.classList.contains('dnxt-pagination-previous') || e.target.getAttribute('data-action') === 'previous') {
					if (this.currentPage > 1 && !e.target.disabled) {
						this.currentPage = Math.max(1, this.currentPage - 1);
						this.updateTable();
					}
				} 
				// Handle Next button clicks
				else if (e.target.classList.contains('dnxt-pagination-next') || e.target.getAttribute('data-action') === 'next') {
					if (this.currentPage < totalPages && !e.target.disabled) {
						this.currentPage = Math.min(totalPages, this.currentPage + 1);
						this.updateTable();
					}
				} 
				// Handle page number clicks
				else if (e.target.classList.contains('dnxt-pagination-info') || e.target.hasAttribute('data-page')) {
					const pageNumber = parseInt(e.target.getAttribute('data-page')) || parseInt(e.target.textContent);
					if (pageNumber && pageNumber !== this.currentPage && pageNumber >= 1 && pageNumber <= totalPages) {
						this.currentPage = pageNumber;
						this.updateTable();
					}
				}
			});
		}
	}
	
	getTableData() {
		const rows = Array.from(this.tbody.querySelectorAll('tr'));
		return rows.map(row => {
			const cells = Array.from(row.querySelectorAll('td'));
			const rowData = { rowClass: row.className };
			
			// Map cells to column keys dynamically
			this.columns.forEach((column, index) => {
				const cellValue = cells[index]?.textContent || '';
				
				// Convert values based on column type
				switch (column.type) {
					case 'number':
					case 'currency':
						rowData[column.key] = parseFloat(cellValue.replace(/[$,]/g, '')) || 0;
						break;
					case 'date':
					case 'datetime':
						rowData[column.key] = new Date(cellValue);
						break;
					default:
						rowData[column.key] = cellValue;
				}
			});
			
			return rowData;
		});
	}
	
	filterAndUpdate() {
		this.filteredData = this.originalData.filter(row => {
			// Search across all columns dynamically
			return this.columns.some(column => {
				const value = row[column.key];
				if (value === undefined || value === null) return false;
				
				const searchValue = value.toString().toLowerCase();
				return searchValue.includes(this.searchTerm);
			});
		});
		
		this.updateTable();
	}
	
	handleSort(columnIndex) {
		const column = this.columns[columnIndex];
		
		if (!column || !column.sortable) return;
		
		const columnKey = column.key;
		
		if (this.sortColumn === columnKey) {
			this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
		} else {
			this.sortColumn = columnKey;
			this.sortDirection = 'asc';
		}
		
		this.filteredData.sort((a, b) => {
			let valueA = a[columnKey];
			let valueB = b[columnKey];
			
			// Handle sorting based on column type
			switch (column.type) {
				case 'number':
				case 'currency':
					valueA = parseFloat(valueA) || 0;
					valueB = parseFloat(valueB) || 0;
					break;
				case 'date':
				case 'datetime':
					valueA = valueA instanceof Date ? valueA : new Date(valueA);
					valueB = valueB instanceof Date ? valueB : new Date(valueB);
					break;
				default:
					valueA = valueA ? valueA.toString().toLowerCase() : '';
					valueB = valueB ? valueB.toString().toLowerCase() : '';
			}
			
			if (valueA < valueB) return this.sortDirection === 'asc' ? -1 : 1;
			if (valueA > valueB) return this.sortDirection === 'asc' ? 1 : -1;
			return 0;
		});
		
		this.updateSortIcons(columnIndex);
		this.updateTable();
	}
	
	updateSortIcons(activeIndex) {
		const headers = this.table.querySelectorAll('th[style*="cursor: pointer"]');
		headers.forEach((header, index) => {
			const icon = header.querySelector('.dnxt-sort-icon');
			if (icon) {
				if (index === activeIndex) {
					icon.textContent = this.sortDirection === 'asc' ? '↑' : '↓';
					icon.style.color = '#333';
				} else {
					icon.textContent = '↕';
					icon.style.color = 'rgb(51, 51, 51)';
				}
			}
		});
	}
	
	updateTable() {
		const startIndex = (this.currentPage - 1) * this.entriesPerPage;
		const endIndex = startIndex + this.entriesPerPage;
		const pageData = this.filteredData.slice(startIndex, endIndex);
		
		// Update table body
		this.tbody.innerHTML = '';
		pageData.forEach((row, index) => {
			const tr = document.createElement('tr');
			tr.className = (startIndex + index) % 2 === 0 ? 'dnxt-table-row-even' : 'dnxt-table-row-odd';
			
			// Generate cells dynamically based on columns
			let cellsHTML = '';
			this.columns.forEach(column => {
				const value = row[column.key] || '';
				const formattedValue = this.formatCellValue(value, column);
				cellsHTML += `<td>${formattedValue}</td>`;
			});
			
			tr.innerHTML = cellsHTML;
			this.tbody.appendChild(tr);
		});
		
		// Update table info
		this.updateTableInfo();
		
		// Update pagination
		this.updatePagination();
	}
	
	formatCellValue(value, column) {
		if (value === null || value === undefined) return '';
		
		switch (column.type) {
			// The non-numeric/unparseable fallbacks below return the cell value straight
			// into a `<td>${...}</td>` template that is assigned with innerHTML, so they
			// must be escaped just like the default case.
			case 'currency':
				const numValue = parseFloat(value);
				return isNaN(numValue) ? this.escapeHtml(value) : '$' + numValue.toFixed(2);
			case 'number':
				const num = parseFloat(value);
				return isNaN(num) ? this.escapeHtml(value) : num.toLocaleString();
			case 'date':
				if (value instanceof Date) {
					return value.toLocaleDateString();
				}
				const date = new Date(value);
				return isNaN(date.getTime()) ? this.escapeHtml(value) : date.toLocaleDateString();
			case 'datetime':
				if (value instanceof Date) {
					return value.toLocaleString();
				}
				const datetime = new Date(value);
				return isNaN(datetime.getTime()) ? this.escapeHtml(value) : datetime.toLocaleString();
			case 'email':
				return `<a href="mailto:${encodeURIComponent(value)}">${this.escapeHtml(value)}</a>`;
			case 'url':
				return `<a href="${encodeURIComponent(value)}" target="_blank">${this.escapeHtml(value)}</a>`;
			case 'image':
				return `<img src="${encodeURIComponent(value)}" alt="" style="max-width: 100px; height: auto;">`;
			default:
				return this.escapeHtml(value.toString());
		}
	}
	
	escapeHtml(text) {
		const div = document.createElement('div');
		div.textContent = text;
		return div.innerHTML;
	}
	
	updateTableInfo() {
		if (this.tableInfo) {
			const startIndex = (this.currentPage - 1) * this.entriesPerPage + 1;
			const endIndex = Math.min(this.currentPage * this.entriesPerPage, this.filteredData.length);
			const total = this.filteredData.length;
			
			const { showing, to, of, entries, noResults } = this.translations;
			
			if (total === 0) {
				this.tableInfo.textContent = noResults;
			} else {
				this.tableInfo.textContent = `${showing} ${startIndex} ${to} ${endIndex} ${of} ${total} ${entries}`;
			}
		}
	}
	
	updatePagination() {
		if (!this.paginationContainer) return;
		
		const totalPages = Math.ceil(this.filteredData.length / this.entriesPerPage);
		
		// Update pagination container data attributes
		this.paginationContainer.setAttribute('data-current-page', this.currentPage);
		this.paginationContainer.setAttribute('data-total-pages', totalPages);
		
		// Update existing pagination buttons instead of recreating them
		const existingPrevBtn = this.paginationContainer.querySelector('.dnxt-pagination-previous');
		const existingNextBtn = this.paginationContainer.querySelector('.dnxt-pagination-next');
		const existingPageBtns = this.paginationContainer.querySelectorAll('.dnxt-pagination-info');
		
		// Update Previous button
		if (existingPrevBtn) {
			const isPrevDisabled = this.currentPage <= 1;
			existingPrevBtn.disabled = isPrevDisabled;
			
			if (isPrevDisabled) {
				existingPrevBtn.setAttribute('disabled', 'disabled');
				existingPrevBtn.classList.add('disabled');
			} else {
				existingPrevBtn.removeAttribute('disabled');
				existingPrevBtn.classList.remove('disabled');
			}
		}
		
		// Update Next button
		if (existingNextBtn) {
			const isNextDisabled = this.currentPage >= totalPages || totalPages === 0;
			existingNextBtn.disabled = isNextDisabled;
			
			if (isNextDisabled) {
				existingNextBtn.setAttribute('disabled', 'disabled');
				existingNextBtn.classList.add('disabled');
			} else {
				existingNextBtn.removeAttribute('disabled');
				existingNextBtn.classList.remove('disabled');
			}
		}
		
		// Always rebuild page buttons to match the enhanced logic
		if (existingPrevBtn && existingNextBtn) {
			// Remove existing page buttons and rebuild
			existingPageBtns.forEach(btn => btn.remove());
			this.addPageButtons(totalPages);
		}
		
		// Update stored total pages
		this.totalPages = totalPages;
		
		// If no existing pagination structure, create it
		if (!existingPrevBtn && !existingNextBtn) {
			this.createPaginationStructure(totalPages);
		}
	}
	
	addPageButtons(totalPages) {
		// Find the next button to insert page buttons before it
		const nextBtn = this.paginationContainer.querySelector('.dnxt-pagination-next');
		
		// Enhanced pagination logic with ellipsis
		const pagesToShow = [];
		
		if (totalPages <= 7) {
			// Show all pages if total pages <= 7
			for (let i = 1; i <= totalPages; i++) {
				pagesToShow.push(i);
			}
		} else {
			// Always show first page
			pagesToShow.push(1);

			if (this.currentPage <= 5) {
				// Near the beginning: show 1, 2, 3, 4, 5, ..., last
				for (let i = 2; i <= 5; i++) {
					pagesToShow.push(i);
				}
				pagesToShow.push('...');
				pagesToShow.push(totalPages);
			} else if (this.currentPage >= totalPages - 4) {
				// Near the end: show 1, ..., last-4, last-3, last-2, last-1, last
				pagesToShow.push('...');
				for (let i = totalPages - 4; i <= totalPages; i++) {
					pagesToShow.push(i);
				}
			} else {
				// In the middle: show 1, ..., current-1, current, current+1, ..., last
				pagesToShow.push('...');
				pagesToShow.push(this.currentPage - 1, this.currentPage, this.currentPage + 1);
				pagesToShow.push('...');
				pagesToShow.push(totalPages);
			}
		}
		
		// Create buttons for each page or ellipsis
		pagesToShow.forEach((page, index) => {
			const pageBtn = document.createElement('button');
			
			if (page === '...') {
				// Ellipsis - make it clickable to jump to approximate page
				pageBtn.className = 'dnxt-pagination dnxt-pagination-info dnxt-pagination-dots';

				// Create span with SVG icon
				const dotSpan = document.createElement('span');
				dotSpan.className = 'et-pb-icon';
				dotSpan.style.color = this.paginationDotColor;
				dotSpan.style.fontSize = this.paginationDotFontSize;
				dotSpan.innerHTML = '<svg width="40" height="40" viewBox="0 0 0.75 0.75" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M.181.375a.056.056 0 1 1-.112 0 .056.056 0 0 1 .112 0m.25 0a.056.056 0 1 1-.112 0 .056.056 0 0 1 .112 0m.194.056a.056.056 0 1 0 0-.112.056.056 0 0 0 0 .112" fill="currentColor"/></svg>';
				pageBtn.appendChild(dotSpan);
				
				// Calculate which page to jump to when clicking ellipsis
				let targetPage;
				if (index < pagesToShow.length / 2) {
					// First ellipsis - jump to middle of gap
					targetPage = Math.floor((pagesToShow[index - 1] + pagesToShow[index + 1]) / 2);
				} else {
					// Second ellipsis - jump to middle of gap
					targetPage = Math.floor((pagesToShow[index - 1] + pagesToShow[index + 1]) / 2);
				}
				
				pageBtn.setAttribute('data-page', targetPage);
				pageBtn.setAttribute('role', 'button');
				pageBtn.setAttribute('tabindex', '0');
			} else {
				// Regular page number
				pageBtn.className = `dnxt-pagination dnxt-pagination-info ${page === this.currentPage ? 'active' : ''}`;
				pageBtn.setAttribute('data-page', page);
				pageBtn.setAttribute('role', 'button');
				pageBtn.setAttribute('tabindex', '0');
				pageBtn.textContent = page;
			}
			
			// Insert before next button
			if (nextBtn) {
				this.paginationContainer.insertBefore(pageBtn, nextBtn);
			} else {
				this.paginationContainer.appendChild(pageBtn);
			}
		});
	}
	
	createPaginationStructure(totalPages) {
		if (!this.paginationContainer) return;
		
		// Clear current pagination
		this.paginationContainer.innerHTML = '';
		
		const { previous, next } = this.translations;
		
		// Previous button
		const prevBtn = document.createElement('button');
		prevBtn.className = 'dnxt-pagination dnxt-pagination-next-prev dnxt-pagination-previous';
		prevBtn.setAttribute('data-action', 'previous');
		prevBtn.textContent = previous;
		
		const isPrevDisabled = this.currentPage <= 1;
		prevBtn.disabled = isPrevDisabled;
		if (isPrevDisabled) {
			prevBtn.setAttribute('disabled', 'disabled');
			prevBtn.classList.add('disabled');
		}
		this.paginationContainer.appendChild(prevBtn);
		
		// Add page buttons using the enhanced logic
		this.addPageButtons(totalPages);
		
		// Next button
		const nextBtn = document.createElement('button');
		nextBtn.className = 'dnxt-pagination dnxt-pagination-next-prev dnxt-pagination-next';
		nextBtn.setAttribute('data-action', 'next');
		nextBtn.textContent = next;
		
		const isNextDisabled = this.currentPage >= totalPages || totalPages === 0;
		nextBtn.disabled = isNextDisabled;
		if (isNextDisabled) {
			nextBtn.setAttribute('disabled', 'disabled');
			nextBtn.classList.add('disabled');
		}
		this.paginationContainer.appendChild(nextBtn);
	}
	
	// AJAX search functionality (for server-side processing)
	performAjaxSearch() {
		const data = {
			action: 'dnxte_datatable_search',
			search: this.searchTerm,
			page: this.currentPage,
			entries_per_page: this.entriesPerPage,
			sort_column: this.sortColumn,
			sort_direction: this.sortDirection,
			nonce: window.dnxte_datatable_config.nonce
		};
		
		// Show loading state
		this.showLoading();
		
		fetch(window.dnxte_datatable_config.ajax_url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded',
			},
			body: new URLSearchParams(data)
		})
		.then(response => response.json())
		.then(data => {
			if (data.success) {
				this.filteredData = data.data.rows;
				this.updateTable();
			} else {
				console.error('DataTable AJAX error:', data.data);
			}
		})
		.catch(error => {
			console.error('DataTable AJAX error:', error);
		})
		.finally(() => {
			this.hideLoading();
		});
	}
	
	showLoading() {
		if (!this.wrapper.querySelector('.dnxt-loading')) {
			const loader = document.createElement('div');
			loader.className = 'dnxt-loading';
			loader.innerHTML = '<div class="dnxt-spinner"></div>';
			this.wrapper.appendChild(loader);
		}
	}
	
	hideLoading() {
		const loader = this.wrapper.querySelector('.dnxt-loading');
		if (loader) {
			loader.remove();
		}
	}
	
	// Utility function for debouncing
	debounce(func, wait) {
		let timeout;
		return function executedFunction(...args) {
			const later = () => {
				clearTimeout(timeout);
				func(...args);
			};
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
		};
	}
}

// Initialize DataTables when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
	const dataTables = document.querySelectorAll('.dnxte-data-table');
	dataTables.forEach(table => {
		new DnxteDataTable(table);
	});
});

// Export for potential external use
window.DnxteDataTable = DnxteDataTable;