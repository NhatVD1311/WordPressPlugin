document.addEventListener('DOMContentLoaded', () => {
    // 1. Find all containers in case there are multiple on the page
    const containers = document.querySelectorAll('.dnxte-stacked-images-container');

    containers.forEach(container => {
        // 2. Extract settings from the container's data attributes
        const {
            tooltipUse,
            tooltipAnim,
            tooltipAnimDelay,
            interactive,
            placement,
            theme,
            arrow,
            animateFill,
            trigger,
            hideOnClick
        } = container.dataset;

        // 3. Only initialize Tippy if tooltips are enabled
        if (tooltipUse !== 'on') {
            return;
        }

        // 4. Initialize Tippy only for items INSIDE this specific container
        tippy(container.querySelectorAll('.dnxte-stacked-image-item'), {
            content(reference) {
                // Get text from the item itself
                return reference.dataset.tooltipText || '';
            },
            // Logic for mapping "on"/"off" or "true"/"false" strings to Booleans
            placement: placement || 'top',
            theme: theme || 'dark',
            animation: tooltipAnim || 'fade',
            delay: Number(tooltipAnimDelay) || 0,
            interactive: interactive === 'on' || interactive === 'true',
            animateFill: animateFill === 'true' || animateFill === 'on',
            trigger: trigger || 'mouseenter',
            hideOnClick: hideOnClick === 'on' || hideOnClick === 'true',
            arrow: arrow !== 'false', // Shows arrow unless explicitly 'false'

            // Ensures the tooltip isn't cut off by overflow:hidden containers
            appendTo: () => document.body,
        });
    });
});