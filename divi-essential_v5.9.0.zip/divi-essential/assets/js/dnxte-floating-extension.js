/**
 * Floating Elements — Section Extension
 * Adds floating image controls to Divi Section via hooks.
 * VB renders images as React elements (not DOM manipulation).
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var el = wp.element;
  var ce = el.createElement;
  var TARGET_MODULES = ['divi/section', 'divi/fullwidth-header'];

  // ════════════════════════════════════════════════════════════
  // 1. ADD OPTION GROUP
  // ════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.moduleLibrary.moduleSettings.groups',
    'dnxte-floating',
    function (groups, metadata) {
      if (TARGET_MODULES.indexOf(metadata.name) === -1) return groups;
      groups.dnxteFloating = {
        groupName: 'dnxteFloating', panel: 'design', priority: 83, multiElements: true,
        component: { name: 'divi/composite', props: { groupLabel: 'Floating Elements' } }
      };
      return groups;
    }
  );

  // ════════════════════════════════════════════════════════════
  // 2. ADD ATTRIBUTES
  // ════════════════════════════════════════════════════════════
  function isEnabled(p) {
    return 'on' === (p.attrs?.floating_config?.advanced?.use_floating?.desktop?.value);
  }

  hooks.addFilter(
    'divi.moduleLibrary.moduleAttributes',
    'dnxte-floating',
    function (attributes, metadata) {
      if (TARGET_MODULES.indexOf(metadata.name) === -1) return attributes;
      attributes.floating_config = {
        type: 'object',
        selector: '{{selector}}',
        default: {
          advanced: {
            use_floating:   { desktop: { value: 'off' } },
            items:          { desktop: { value: '[]' } },
            disable_tablet: { desktop: { value: 'off' } },
            disable_phone:  { desktop: { value: 'off' } }
          }
        },
        settings: {
          advanced: {
            use_floating: {
              groupType: 'group-item',
              item: {
                attrName: 'floating_config.advanced.use_floating',
                label: 'Enable Floating Elements',
                groupSlug: 'dnxteFloating', priority: 10, render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' }
              }
            },
            items: {
              groupType: 'group-item',
              item: {
                attrName: 'floating_config.advanced.items',
                label: 'Floating Images',
                groupSlug: 'dnxteFloating', priority: 15, render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'dnxte/floating-image-repeater' },
                visible: isEnabled
              }
            },
            disable_tablet: {
              groupType: 'group-item',
              item: {
                attrName: 'floating_config.advanced.disable_tablet',
                label: 'Disable on Tablet',
                groupSlug: 'dnxteFloating', priority: 20, render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' },
                visible: isEnabled
              }
            },
            disable_phone: {
              groupType: 'group-item',
              item: {
                attrName: 'floating_config.advanced.disable_phone',
                label: 'Disable on Phone',
                groupSlug: 'dnxteFloating', priority: 21, render: true,
                features: { sticky: false, hover: false, responsive: false },
                component: { type: 'field', name: 'divi/toggle' },
                visible: isEnabled
              }
            }
          }
        }
      };
      return attributes;
    }
  );

  // ════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER — React elements + GSAP animation
  // ════════════════════════════════════════════════════════════
  function parseItems(val) {
    if (!val) return [];
    if (typeof val === 'string') { try { return JSON.parse(val); } catch (e) { return []; } }
    return Array.isArray(val) ? val : [];
  }

  /**
   * Single floating image component — handles its own GSAP animation.
   */
  function FloatingImage(props) {
    var React = window.vendor.React;
    var ref = React.useRef(null);
    var item = props.item;
    var index = props.index;

    React.useEffect(function () {
      var node = ref.current;
      if (!node || typeof gsap === 'undefined') return;

      // Small delay for DOM paint
      var t = setTimeout(function () {
        // Entrance
        gsap.fromTo(node,
          { opacity: 0, scale: 0.9 },
          { opacity: 1, scale: 1, duration: 1, delay: index * 0.15, ease: 'power3.out' }
        );

        // Apply floating based on preset or custom
        var preset = item.preset || 'gentle-float';
        var useCustom = !!item.useCustom;
        var dur = parseFloat(item.duration || 6);
        var yR = parseFloat(item.yRange || 30);
        var xR = parseFloat(item.xRange || 25);
        var rotR = parseFloat(item.rotRange || 8);
        var ease = item.easing || 'sine.inOut';
        var delay = parseFloat(item.delay || 0) + index * 0.15;
        var sc = parseFloat(item.scale || 1.02);

        if (useCustom) {
          // Custom animation
          var dir = item.direction || 'both';
          if (dir === 'both' || dir === 'vertical')
            gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: ease, delay: delay });
          if (dir === 'both' || dir === 'horizontal')
            gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur * 1.2, repeat: -1, yoyo: true, ease: ease, delay: delay });
          if (dir === 'diagonal')
            gsap.to(node, { x: gsap.utils.random(-xR, xR), y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: ease, delay: delay });
          if (rotR > 0)
            gsap.to(node, { rotation: gsap.utils.random(-rotR, rotR), duration: dur * 1.5, repeat: -1, yoyo: true, ease: ease });
          gsap.to(node, { scale: gsap.utils.random(0.98, sc), duration: dur * 0.6, repeat: -1, yoyo: true, ease: 'power1.inOut' });
          var opMin = parseFloat(item.opacityMin || 1);
          if (opMin < 1)
            gsap.to(node, { opacity: opMin, duration: dur * 0.5, repeat: -1, yoyo: true, ease: 'sine.inOut' });
        } else {
          // Preset animations
          switch (preset) {
            case 'orbit':
              var radius = Math.max(xR, yR);
              var a = gsap.utils.random(0, Math.PI * 2);
              gsap.to(node, {
                keyframes: [
                  { x: Math.cos(a) * radius, y: Math.sin(a) * radius * 0.6 },
                  { x: Math.cos(a + Math.PI/2) * radius, y: Math.sin(a + Math.PI/2) * radius * 0.6 },
                  { x: Math.cos(a + Math.PI) * radius, y: Math.sin(a + Math.PI) * radius * 0.6 },
                  { x: Math.cos(a + Math.PI*1.5) * radius, y: Math.sin(a + Math.PI*1.5) * radius * 0.6 },
                  { x: Math.cos(a) * radius, y: Math.sin(a) * radius * 0.6 }
                ],
                duration: dur, repeat: -1, ease: 'none', delay: delay
              });
              break;
            case 'bounce':
              gsap.to(node, { y: -yR, duration: dur * 0.4, repeat: -1, yoyo: true, ease: 'bounce.out', delay: delay });
              gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur * 1.5, repeat: -1, yoyo: true, ease: 'sine.inOut' });
              break;
            case 'sway':
              gsap.to(node, { rotation: gsap.utils.random(-rotR*2, rotR*2), duration: dur, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay, transformOrigin: '50% 0%' });
              gsap.to(node, { x: gsap.utils.random(-xR*1.5, xR*1.5), duration: dur*0.8, repeat: -1, yoyo: true, ease: 'sine.inOut' });
              break;
            case 'zigzag':
              gsap.to(node, {
                keyframes: [
                  { x: xR, y: -yR*0.5, duration: dur*0.5 },
                  { x: -xR, y: -yR, duration: dur*0.5 },
                  { x: xR, y: -yR*1.5, duration: dur*0.5 },
                  { x: 0, y: 0, duration: dur*0.5 }
                ], repeat: -1, ease: 'sine.inOut', delay: delay
              });
              break;
            case 'pulse':
              gsap.to(node, { scale: sc+0.1, duration: dur*0.3, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay });
              gsap.to(node, { y: gsap.utils.random(-yR*0.4, yR*0.4), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut' });
              gsap.to(node, { opacity: 0.6, duration: dur*0.3, repeat: -1, yoyo: true, ease: 'power1.inOut' });
              break;
            case 'drift':
              gsap.to(node, { x: gsap.utils.random(-xR*2, xR*2), duration: dur*2, repeat: -1, yoyo: true, ease: 'none', delay: delay });
              gsap.to(node, { y: gsap.utils.random(-yR*2, yR*2), duration: dur*2.5, repeat: -1, yoyo: true, ease: 'none' });
              gsap.to(node, { rotation: gsap.utils.random(-rotR, rotR), duration: dur*3, repeat: -1, yoyo: true, ease: 'none' });
              break;
            case 'spin-float':
              gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: delay });
              gsap.to(node, { rotation: 360, duration: dur*2, repeat: -1, ease: 'none' });
              break;
            case 'pendulum':
              gsap.to(node, { rotation: gsap.utils.random(-rotR*3, rotR*3), duration: dur*0.7, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay, transformOrigin: '50% 0%' });
              break;
            case 'elastic-pop':
              gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'back.inOut(1.2)', delay: delay+0.8 });
              gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur*1.3, repeat: -1, yoyo: true, ease: 'back.inOut(1)', delay: delay+0.8 });
              break;
            default: // gentle-float
              gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: delay });
              gsap.to(node, { x: gsap.utils.random(-xR*0.5, xR*0.5), duration: dur*1.3, repeat: -1, yoyo: true, ease: 'sine.inOut' });
              gsap.to(node, { scale: gsap.utils.random(0.98, sc), duration: dur*0.6, repeat: -1, yoyo: true, ease: 'power1.inOut' });
              break;
          }
        }

        // 3D
        if (item.use3d) {
          var rxR = parseFloat(item.rotateXRange || 10);
          var ryR = parseFloat(item.rotateYRange || 20);
          gsap.to(node, { rotateX: gsap.utils.random(-rxR, rxR), rotateY: gsap.utils.random(-ryR, ryR), duration: dur*2, repeat: -1, yoyo: true, ease: 'sine.inOut' });
        }
      }, 50);

      return function () {
        clearTimeout(t);
        if (ref.current) gsap.killTweensOf(ref.current);
      };
    }, [item.preset, item.useCustom, item.yRange, item.xRange, item.rotRange, item.duration, item.delay, item.easing, item.direction, item.scale, item.opacityMin, item.use3d, item.rotateXRange, item.rotateYRange, item.posX, item.posY, item.width, item.zIndex]);

    if (!item.src) return null;

    return ce('div', {
      ref: ref,
      className: 'dnxte-floating-element-item ' + (props.cls || ''),
      style: {
        // position/size come from the injected <style> so they can vary per device.
        position: 'absolute',
        zIndex: (function () { var z = parseInt(item.zIndex, 10); return isNaN(z) ? 1 : z; })(),
        pointerEvents: 'auto',
        willChange: 'transform',
        opacity: 0,
        borderRadius: (item.borderRadius || '0') + 'px',
        overflow: 'hidden',
      }
    },
      ce('img', {
        src: item.src,
        alt: item.alt || '',
        style: { width: '100%', height: 'auto', display: 'block' }
      })
    );
  }

  // Responsive position/size CSS for one item — mirrors FloatingExtension.php.
  function fnum(v, def) { return (v !== undefined && v !== null && v !== '' && !isNaN(parseFloat(v))) ? v : def; }
  function fhas(item, key) { return item[key] !== undefined && item[key] !== null && item[key] !== '' && !isNaN(parseFloat(item[key])); }
  function cssForItem(cls, item) {
    var css = '.' + cls + '{left:' + fnum(item.posX, '20') + '%;top:' + fnum(item.posY, '20') + '%;width:' + fnum(item.width, '200') + 'px;}';
    var t = '';
    if (fhas(item, 'posXTablet')) t += 'left:' + fnum(item.posXTablet, '') + '%;';
    if (fhas(item, 'posYTablet')) t += 'top:' + fnum(item.posYTablet, '') + '%;';
    if (fhas(item, 'widthTablet')) t += 'width:' + fnum(item.widthTablet, '') + 'px;';
    if (t) css += '@media(max-width:980px){.' + cls + '{' + t + '}}';
    var ph = '';
    if (fhas(item, 'posXPhone')) ph += 'left:' + fnum(item.posXPhone, '') + '%;';
    if (fhas(item, 'posYPhone')) ph += 'top:' + fnum(item.posYPhone, '') + '%;';
    if (fhas(item, 'widthPhone')) ph += 'width:' + fnum(item.widthPhone, '') + 'px;';
    if (ph) css += '@media(max-width:767px){.' + cls + '{' + ph + '}}';
    if (item.hideTablet) css += '@media(max-width:980px) and (min-width:768px){.' + cls + '{display:none;}}';
    if (item.hidePhone) css += '@media(max-width:767px){.' + cls + '{display:none;}}';
    return css;
  }

  var vbUidSeq = 0;

  /**
   * Container — renders all floating images as React children.
   */
  function FloatingContainer(props) {
    var React = window.vendor.React;
    var items = props.items;
    var validItems = items.filter(function (it) { return !!it.src; });
    var uidRef = React.useRef(null);
    if (uidRef.current === null) { uidRef.current = 'dnxte-fevb-' + (vbUidSeq++); }
    if (!validItems.length) return null;

    var uid = uidRef.current;
    var wrapCls = uid + '-wrap';
    var css = validItems.map(function (item, i) { return cssForItem(uid + '-' + i, item); }).join('');
    if (props.disableTablet) css += '@media(max-width:980px) and (min-width:768px){.' + wrapCls + '{display:none;}}';
    if (props.disablePhone) css += '@media(max-width:767px){.' + wrapCls + '{display:none;}}';

    return ce('div', {
      className: 'dnxte-floating-elements-container ' + wrapCls,
      style: {
        position: 'absolute',
        top: 0, left: 0, right: 0, bottom: 0,
        pointerEvents: 'none',
        overflow: 'hidden',
        // No z-index here: setting one creates a stacking context that would trap
        // every item's z-index inside this layer, so per-item z-index could never
        // move an element above/below the module's own content. Left as `auto`.
      }
    },
      ce('style', { key: 'dnxte-fe-css' }, css),
      validItems.map(function (item, i) {
        return ce(FloatingImage, { key: item.id || i, item: item, index: i, cls: uid + '-' + i });
      })
    );
  }

  // ════════════════════════════════════════════════════════════
  // 4. WRAPPER RENDER HOOK
  // ════════════════════════════════════════════════════════════
  hooks.addFilter(
    'divi.module.wrapper.render',
    'dnxte-floating',
    function (moduleWrapper, param) {
      if (TARGET_MODULES.indexOf(param.name) === -1) return moduleWrapper;
      if (param.attrs?.floating_config?.advanced?.use_floating?.desktop?.value !== 'on') return moduleWrapper;

      var itemsJson = param.attrs?.floating_config?.advanced?.items?.desktop?.value || '[]';
      var items = parseItems(itemsJson);
      if (!items.length) return moduleWrapper;

      var children = moduleWrapper.props.children;
      var childArray = Array.isArray(children) ? children : [children];

      var adv = param.attrs?.floating_config?.advanced || {};
      var floatingContainer = ce(FloatingContainer, {
        key: 'dnxte-floating-container',
        items: items,
        disableTablet: adv.disable_tablet?.desktop?.value === 'on',
        disablePhone: adv.disable_phone?.desktop?.value === 'on'
      });

      return el.cloneElement(moduleWrapper, {
        style: Object.assign({}, moduleWrapper.props.style || {}, { position: 'relative' })
      }, childArray.concat([floatingContainer]));
    }
  );
})();
