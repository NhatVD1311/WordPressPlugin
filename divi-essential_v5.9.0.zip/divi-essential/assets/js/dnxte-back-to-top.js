/**
 * Divi Essential Back to Top Admin JS
 */

jQuery(document).ready(function($) {
	// Tab functionality
	$('.dnxte-tab-button').on('click', function() {
		const tabId = $(this).data('tab');
		
		// Update active tab button
		$('.dnxte-tab-button').removeClass('active');
		$(this).addClass('active');
		
		// Show active tab content
		$('.dnxte-tab-content').removeClass('active');
		$('#' + tabId).addClass('active');
	});

	const $selectField = $('#dnxte-back-to-top-button_content');
	const $imageRow = $('.dnxte-field-button_custom_image');
	const $dashiconRow = $('.dnxte-field-button_dashicon');
	const $iconType = $('input[name="button_icon_type"]');

	function toggleImageRow() {
		const selectedValue = $selectField.val();
		
		if (selectedValue == 'text') {
			$imageRow.hide();
			$dashiconRow.addClass('dnxte-hidden');
		} else {
			$imageRow.show();
			$dashiconRow.removeClass('dnxte-hidden');
		}
				
		if (selectedValue === 'icon') {
			$('.dnxte-field-row.dnxte-field-display_text_align').hide();
		} else {
			$('.dnxte-field-row.dnxte-field-display_text_align').show();
		}
	}

	// Initial check on page load
	toggleImageRow();

	// Bind change event
	$selectField.on('change', function () {
		toggleImageRow();
	});

	
	// Initialize color pickers
	$('.dnxte-color-picker').wpColorPicker({
		change: function() {
			setTimeout(function() {
				updatePreview();
			}, 100);
		},
		clear: function() {},
		palettes: true,
		alpha: true
	});
	
	// Handle field dependencies
	$('.dnxte-select-field, .dnxte-radio-field').on('change', function() {
		handleDependencies();
		updatePreview();
	});

	// Add this near the top of your jQuery document ready function:
	$('.dnxte-checkbox-field').on('change', function() {
		handleDependencies();
		updatePreview();
	});

	// Add this near the top of your jQuery document ready function:
	$('select[name="button_font"]').on('change', function() {
		handleDependencies();
		updatePreview();
	});
	
	$('.dnxte-text-field, .dnxte-dimension-field-input').on('input', function() {
		updatePreview();
	});
	
	// Initial setup
	handleDependencies();
	updatePreview();

	// Initialize color pickers
	$('.dnxte-color-picker').each(function() {
		$(this).wpColorPicker({
			change: function(event, ui) {
				setTimeout(function() {
					updatePreview();
				}, 100);
			},
			clear: function() {},
			palettes: true,
			alpha: true
		});
	});
	
	// Handle field dependencies
	$('.dnxte-select-field, .dnxte-radio-field').on('change', function() {
		handleDependencies();
		updatePreview();
	});
	
	$('.dnxte-text-field').on('input', function() {
		updatePreview();
	});
	
	// Dashicon picker
	$('.dnxte-open-dashicon-picker').on('click', function(e) {
		e.preventDefault();
		$(this).siblings('.dnxte-dashicon-picker-container').show();
	});
	
	$('.dnxte-close-dashicon-picker').on('click', function() {
		$(this).closest('.dnxte-dashicon-picker-container').hide();
	});
	
	$('.dnxte-dashicon-item').on('click', function() {
		const $this = $(this);
		const iconClass = $this.data('icon');
		const $container = $this.closest('.dnxte-dashicon-selector');
		
		// Update selected state
		$('.dnxte-dashicon-item').removeClass('selected');
		$this.addClass('selected');
		
		// Update input and preview
		$container.find('input[type="hidden"]').val(iconClass);
		$container.find('.dnxte-selected-dashicon i').attr('class', 'dashicons ' + iconClass);
		$container.find('.dnxte-dashicon-name').text(iconClass);
		
		// Close picker
		$container.find('.dnxte-dashicon-picker-container').hide();
		
		updatePreview();
	});
	
	// Search Dashicons
	$('.dnxte-dashicon-search').on('input', function() {
		const searchTerm = $(this).val().toLowerCase();
		
		$(this).closest('.dnxte-dashicon-picker-container').find('.dnxte-dashicon-item').each(function() {
			const iconName = $(this).data('icon').toLowerCase();
			if (iconName.includes(searchTerm)) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});
	});
	
	// Media uploader
	let mediaUploader;
	
	$('.dnxte-upload-image').on('click', function(e) {
		e.preventDefault();
		
		const $button = $(this);
		const fieldId = $button.data('field');
		const $input = $('#dnxte-back-to-top-' + fieldId);
		const $preview = $button.siblings('.dnxte-custom-image-preview');
		const $removeButton = $button.siblings('.dnxte-remove-image');
		
		// If the media uploader already exists, open it
		if (mediaUploader) {
			mediaUploader.open();
			return;
		}
		
		// Create the media uploader
		mediaUploader = wp.media({
			title: 'Select or Upload Icon Image',
			button: {
				text: 'Use this image'
			},
			multiple: false
		});
		
		// When an image is selected, run a callback
		mediaUploader.on('select', function() {
			const attachment = mediaUploader.state().get('selection').first().toJSON();
			
			// Set the image URL to the hidden input
			$input.val(attachment.url);
			
			// Update the preview
			$preview.html('<img width="32" height="32" src="' + attachment.url + '" alt="Custom Icon">');
			$removeButton.show();
			
			updatePreview();
		});
		
		// Open the uploader dialog
		mediaUploader.open();
	});
	
	// Remove image
	$('.dnxte-remove-image').on('click', function(e) {
		e.preventDefault();
		
		const $button = $(this);
		const fieldId = $button.data('field');
		const $input = $('#dnxte-back-to-top-' + fieldId);
		const $preview = $button.siblings('.dnxte-custom-image-preview');
		
		// Clear the input value
		$input.val('');
		
		// Update the preview
		$preview.html('<div class="dnxte-no-image">No image selected</div>');
		$button.hide();
		
		updatePreview();
	});
	
	// Initial setup
	handleDependencies();
	updatePreview();
	
	// Handle form submission
	$('#dnxte-back-to-top-form').on('submit', function(e) {
		e.preventDefault();
		saveSettings();
	});
	
	function handleDependencies() {
		// Loop through all fields with dependencies
		$('[data-field]').each(function() {
			const $field = $(this);
			const fieldId = $field.data('field');

			// Find the field definition
			let fieldDef = null;

			// Search through all sections - skip if dnxteBackToTopData is not available
			if (typeof dnxteBackToTopData !== 'undefined' && dnxteBackToTopData.settingsFields) {
				Object.values(dnxteBackToTopData.settingsFields).forEach(function(section) {
					if (section.fields && section.fields[fieldId] && section.fields[fieldId].dependency) {
						fieldDef = section.fields[fieldId];
					}
				});
			}

			if (fieldDef && fieldDef.dependency) {
				const depField = fieldDef.dependency[0];
				const depValue = fieldDef.dependency[1];
				let currentValue;

				// Get the current value of the dependency field
				if ($('input[name="' + depField + '"]').is(':checkbox')) {
					currentValue = $('input[name="' + depField + '"]').is(':checked') ? '1' : '0';
				} else if ($('input[name="' + depField + '"]').is(':radio')) {
					currentValue = $('input[name="' + depField + '"]:checked').val();
				} else {
					currentValue = $('#dnxte-back-to-top-' + depField).val();
				}

				// Check if the current value matches the dependency value
				let showField = false;

				if (Array.isArray(depValue)) {
					showField = depValue.includes(currentValue);
				} else {
					showField = (currentValue == depValue);
				}

				// Show or hide the field
				if (showField) {
					$field.show();
				} else {
					$field.hide();
				}
			}
		});
	}


    function updatePreview() {
        const $preview = $('#dnxte-back-to-top-preview'),
            bgColor = $('.dnxte-color-picker[name="bg_color"]').val(),
			bgHoverColor = $('.dnxte-color-picker[name="bg_hover_color"]').val(),
            borderRadius = $('#dnxte-back-to-top-border_radius').val(),
            textColor = $('.dnxte-color-picker[name="icon_text_color"]').val(),
            textHoverColor = $('.dnxte-color-picker[name="icon_text_hover_color"]').val(),
            buttonContent = $('#dnxte-back-to-top-button_content').val() || $('select[name="button_content"]').val(),
            buttonIcon = $('#dnxte-back-to-top-button_icon').val(),
            buttonText = $('#dnxte-back-to-top-icon_text').val(),
            iconPlacement = $('#dnxte-back-to-top-icon_placement').val() || $('input[name="icon_placement"]:checked').val(),
            iconType = $('input[name="button_icon_type"]:checked').val(),
            iconPosition = $('select[name="position"]').val(),
            positionOffsetLeft = $('#dnxte-back-to-top-position_offset_left').val() || '10',
            positionOffsetRight = $('#dnxte-back-to-top-position_offset_right').val() || '10',
            positionOffsetBottom = $('#dnxte-back-to-top-position_offset_bottom').val() || '10',
            iconSize = $('#dnxte-back-to-top-icon_size').val() || '24',
            displayText = $('input[name="display_text"]').val() || 'Back to Top',
            buttonTextAlign = $('input[name="display_text_align"]:checked').val() || 'horizontal',
            fontSize = $('#dnxte-back-to-top-button_font_size').val() || '14',
            googleFont = $('select[name="button_font"]').val() || "Roboto",
            fontWeight = $('#dnxte-back-to-top-button_font_weight').val() || '400',
            letterSpacing = $('#dnxte-back-to-top-button_letter_spacing').val() || '0',
            lineHeight = $('#dnxte-back-to-top-button_line_height').val() || '1',
            paddingTop = $('input[name="button_padding_top"]').val() || '10',
            paddingRight = $('input[name="button_padding_right"]').val() || '10',
            paddingBottom = $('input[name="button_padding_bottom"]').val() || '10',
            paddingLeft = $('input[name="button_padding_left"]').val() || '10';

		const encodedFont = googleFont.replace(/ /g, '+'),
			newHref = 'https://fonts.googleapis.com/css2?family=' + encodedFont + ':wght@400;700&display=swap';

		$('link[rel="stylesheet"][href*="fonts.googleapis.com"]').attr('href', newHref);

        // Update preview styles
        $preview.css({
            'background-color': bgColor,
            'border-radius': borderRadius + 'px',
        });
    
        if ('left' === iconPosition) {
            $preview.css({
                'left': positionOffsetLeft + 'px',
                'right': 'unset',
                'bottom': positionOffsetBottom + 'px'
            });
        } else {
            $preview.css({
                'left': 'unset',
                'right': positionOffsetRight + 'px',
                'bottom': positionOffsetBottom + 'px'
            });
        }
    
        // Create the wrapper div with appropriate class
        let previewContent = '<div class="button-content ' + (buttonTextAlign === 'vertical' ? 'vertical' : 'horizontal') + '">';

		if ( buttonTextAlign === 'vertical' ) {
			previewContent += '<span class="dnxte-back-to-top-vertical">';
		}
    
        // Handle left icon placement
        if ((buttonContent === 'icon' && iconPlacement === 'left') || 
            (buttonContent === 'both' && iconPlacement === 'left')) {
            
            if (iconType === 'dashicon') {
                const dashicon = $('#dnxte-back-to-top-button_dashicon').val();
                previewContent += '<i class="dashicons ' + dashicon + '" style="display:inline-block; width: ' + iconSize + 'px; height: ' + iconSize + 'px; font-size:' + iconSize + 'px; vertical-align:middle;"></i>';
            } else if (iconType === 'custom_image' && $('#dnxte-back-to-top-button_custom_image').val()) {
                const imageUrl = $('#dnxte-back-to-top-button_custom_image').val();
                previewContent += '<img src="' + imageUrl + '" alt="Icon" style="width:' + iconSize + 'px;height:' + iconSize + 'px; vertical-align:middle;">';
            } else if (iconType === 'external_url' && $('#dnxte-back-to-top-button_external_url').val()) {
                const imageUrl = $('#dnxte-back-to-top-button_external_url').val();
                previewContent += '<img src="' + imageUrl + '" alt="Icon" style="width:' + iconSize + 'px;height:' + iconSize + 'px; vertical-align:middle;">';
            } else {
                previewContent += '<i class="' + buttonIcon + '" style="font-size:' + iconSize + 'px; vertical-align:middle;"></i>';
            }
        }
        
		// Add text if needed
        if (buttonContent === 'text' || (buttonContent === 'both' && iconPlacement === 'left')) {
            previewContent += '<span>' + buttonText + '</span>';
        } else if (buttonContent === 'text' || (buttonContent === 'both' && iconPlacement === 'right')) {
            previewContent += '<span>' + buttonText + '</span>';
        }
        
        // Handle right icon placement
        if ((buttonContent === 'icon' && iconPlacement === 'right') || 
            (buttonContent === 'both' && iconPlacement === 'right')) {

            if (iconType === 'dashicon') {
                const dashicon = $('#dnxte-back-to-top-button_dashicon').val();
                previewContent += '<i class="dashicons ' + dashicon + '" style="display:inline-block; width: ' + iconSize + 'px; height: ' + iconSize + 'px; font-size:' + iconSize + 'px;"></i>';
            } else if (iconType === 'custom_image' && $('#dnxte-back-to-top-button_custom_image').val()) {
                const imageUrl = $('#dnxte-back-to-top-button_custom_image').val();
                previewContent += '<img src="' + imageUrl + '" alt="Icon" style="width:' + iconSize + 'px;height:' + iconSize + 'px;">';
            } else if (iconType === 'external_url' && $('#dnxte-back-to-top-button_external_url').val()) {
                const imageUrl = $('#dnxte-back-to-top-button_external_url').val();
                previewContent += '<img src="' + imageUrl + '" alt="Icon" style="width:' + iconSize + 'px;height:' + iconSize + 'px;">';
            } else {
                previewContent += '<i class="' + buttonIcon + '" style="font-size:' + iconSize + 'px;"></i>';
            }
        }

		if ( buttonTextAlign === 'vertical' ) {
			previewContent += '</span>';
		} else {
			previewContent += '';
		}
        
        // Close the wrapper div
        previewContent += '</div>';
        
        $preview.html(previewContent);

        // IMPORTANT: Now that the content is in the DOM, we can select and style the button-content element
        const $previewBtn = $('#dnxte-back-to-top-preview .button-content');
        
        // Apply styles to the button content
        $previewBtn.css({
            'color': textColor,
            'font-weight': fontWeight,
			'font-family': `"${googleFont}", sans-serif`,
            'letter-spacing': letterSpacing + 'px',
            'line-height': lineHeight,
            'font-size': fontSize + 'px',
            'padding-top': paddingTop + 'px',
            'padding-right': paddingRight + 'px',
            'padding-bottom': paddingBottom + 'px',
            'padding-left': paddingLeft + 'px'
        });

		$previewBtn.on('mouseenter', function() {
			$(this).css('background-color', bgHoverColor);
			$(this).css('color', textHoverColor);
		});
	
		$previewBtn.on('mouseleave', function() {
			$(this).css('background-color', bgColor);
			$(this).css('color', textColor);
		});
    }
	
	function saveSettings() {
		// Create an object to hold all settings
		const settings = {};
		
		// Collect all input values
		$('#dnxte-back-to-top-form').find('input[type="text"], input[type="hidden"], select, input[type="radio"], input[type="number"]').each(function() {
			const $input = $(this);
			const name = $input.attr('name');

			if (name) {
				settings[name] = $input.val();
			}
		});
		
		// Handle radio buttons
		$('#dnxte-back-to-top-form').find('input[type="radio"]:checked').each(function() {
			const $input = $(this);
			const name = $input.attr('name');
			
			if (name) {
				settings[name] = $input.val();
			}
		});
		
		// Handle checkbox values - they need special handling
		$('#dnxte-back-to-top-form').find('input[type="checkbox"]').each(function() {
			const $input = $(this);
			const name = $input.attr('name');
			
			if (name) {
				// Set to "1" if checked, "0" if not
				settings[name] = $input.is(':checked') ? '1' : '0';
			}
		});

		// For color pickers, get the value directly from the input
		$('.dnxte-color-picker').each(function() {
			const $input = $(this);
			const name = $input.attr('name');
			
			if (name) {
				settings[name] = $input.val();
			}
		});
		
		$('#dnxte-back-to-top-save').prop('disabled', true).text('Saving...');

		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'dnxte_save_back_to_top_settings',
				nonce: $('#dnxte_back_to_top_nonce').val(),
				settings: settings
			},
			success: function(response) {
				// Remove previous notice
				$('.wrap > .notice').remove();

				const notice = $('<div class="notice is-dismissible"></div>');
				const message = $('<p></p>');

				if (response.success) {
					notice.addClass('notice-success');
					message.text('Settings saved successfully!');
				} else {
					notice.addClass('notice-error');
					message.text('Error saving settings. Please try again.');
				}

				notice.append(message);

				// Dismiss button
				const closeBtn = $('<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>');
				closeBtn.on('click', function () {
					notice.fadeOut(200, function () {
						$(this).remove();
					});
				});
				notice.append(closeBtn);

				// Insert after <h1> inside .wrap
				$('.wrap > h1').first().after(notice);

				// Auto-hide after 3 seconds
				setTimeout(function () {
					notice.fadeOut(400, function () {
						$(this).remove();
					});
				}, 3000);
			},
			error: function() {
				$('.wrap > .notice').remove();

				const notice = $('<div class="notice notice-error is-dismissible"><p>Server error. Please try again.</p></div>');
				
				// Dismiss button
				const closeBtn = $('<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>');
				closeBtn.on('click', function () {
					notice.fadeOut(200, function () {
						$(this).remove();
					});
				});
				notice.append(closeBtn);

				// Insert after <h1> inside .wrap
				$('.wrap > h1').first().after(notice);

				// Auto-hide after 3 seconds
				setTimeout(function () {
					notice.fadeOut(400, function () {
						$(this).remove();
					});
				}, 3000);
			},
			complete: function () {
				$('#dnxte-back-to-top-save').prop('disabled', false).text('Save Settings');
			}
		});

	}


	// Handle Button Position Left/Right - Change Label as Bottom/Top
	const displayTextRadios = document.querySelectorAll('input[name="display_text_align"]');
	const iconPlacementLabels = document.querySelectorAll('.dnxte-field-icon_placement .dnxte-radio-label');

	const updateIconPlacementLabels = function (alignment) {
		if (alignment === 'vertical') {
			iconPlacementLabels.forEach(function (label) {
				const input = label.querySelector('input');
				if (input && input.value === 'left') {
					label.querySelector('span').textContent = 'Bottom';
				} else if (input && input.value === 'right') {
					label.querySelector('span').textContent = 'Top';
				}
			});
		} else {
			iconPlacementLabels.forEach(function (label) {
				const input = label.querySelector('input');
				if (input && input.value === 'left') {
					label.querySelector('span').textContent = 'Left Side';
				} else if (input && input.value === 'right') {
					label.querySelector('span').textContent = 'Right Side';
				}
			});
		}
	};

	// Initial load
	const selectedAlignment = document.querySelector('input[name="display_text_align"]:checked');
	if (selectedAlignment) {
		updateIconPlacementLabels(selectedAlignment.value);
	}

	// Event listener for changes
	displayTextRadios.forEach(function (radio) {
		radio.addEventListener('change', function () {
			updateIconPlacementLabels(this.value);
		});
	});
});

// Handle the linked dimension inputs
jQuery(document).ready(function($) {
    function updateLinkedDimensionInput(sourceInput, targetInput) {
        if (sourceInput.val() !== targetInput.val()) {
            targetInput.val(sourceInput.val());
            targetInput.trigger('input'); 
        }
    }

    // Handle link button click
    $(document).on('click', '.dnxte-dimension-link-button', function() {
        var $button = $(this);
        var checkboxId = $button.data('controls-checkbox');
        var $checkbox = $('#' + checkboxId);
        var $icon = $button.find('.dashicons');
        var $fieldWrapper = $button.closest('.dnxte-dimension-field');

        // Toggle checkbox state
        $checkbox.prop('checked', !$checkbox.prop('checked')).trigger('change');

        // Update button appearance and ARIA state
        if ($checkbox.is(':checked')) {
            $button.attr('aria-pressed', 'true');
            $icon.removeClass('dashicons-editor-unlink').addClass('dashicons-admin-links');
            
            // When linking, sync values (current input's pair)
            var linkPair = $checkbox.data('link-pair');
            if (linkPair === 'vertical') {
                var $topInput = $fieldWrapper.find('.dnxte-dimension-input-top');
                var $bottomInput = $fieldWrapper.find('.dnxte-dimension-input-bottom');
                // Sync bottom to top's current value
                updateLinkedDimensionInput($topInput, $bottomInput);
            } else if (linkPair === 'horizontal') {
                var $leftInput = $fieldWrapper.find('.dnxte-dimension-input-left');
                var $rightInput = $fieldWrapper.find('.dnxte-dimension-input-right');
                // Sync right to left's current value
                updateLinkedDimensionInput($leftInput, $rightInput);
            }
        } else {
            $button.attr('aria-pressed', 'false');
            $icon.removeClass('dashicons-admin-links').addClass('dashicons-editor-unlink');
        }
    });

    // Handle dimension input changes
    $(document).on('input', '.dnxte-dimension-field-input', function() {
        var $input = $(this);
        var $fieldWrapper = $input.closest('.dnxte-dimension-field');
        var part = $input.data('dimension-part'); // 'top', 'bottom', 'left', 'right'

        var $verticalLinkCheckbox = $fieldWrapper.find('.dnxte-dimension-link-vertical .dnxte-dimension-link-checkbox');
        var $horizontalLinkCheckbox = $fieldWrapper.find('.dnxte-dimension-link-horizontal .dnxte-dimension-link-checkbox');

        if ((part === 'top' || part === 'bottom') && $verticalLinkCheckbox.is(':checked')) {
            var $topInput = $fieldWrapper.find('.dnxte-dimension-input-top');
            var $bottomInput = $fieldWrapper.find('.dnxte-dimension-input-bottom');
            if (part === 'top') {
                updateLinkedDimensionInput($input, $bottomInput);
            } else { // part === 'bottom'
                updateLinkedDimensionInput($input, $topInput);
            }
        } else if ((part === 'left' || part === 'right') && $horizontalLinkCheckbox.is(':checked')) {
            var $leftInput = $fieldWrapper.find('.dnxte-dimension-input-left');
            var $rightInput = $fieldWrapper.find('.dnxte-dimension-input-right');
            if (part === 'left') {
                updateLinkedDimensionInput($input, $rightInput);
            } else { // part === 'right'
                updateLinkedDimensionInput($input, $leftInput);
            }
        }
    });

    $('.dnxte-dimension-link-checkbox:checked').each(function() {
        var $checkbox = $(this);
        var $fieldWrapper = $checkbox.closest('.dnxte-dimension-field');
        var linkPair = $checkbox.data('link-pair');

        if (linkPair === 'vertical') {
            var $topInput = $fieldWrapper.find('.dnxte-dimension-input-top');
            var $bottomInput = $fieldWrapper.find('.dnxte-dimension-input-bottom');
            updateLinkedDimensionInput($topInput, $bottomInput); // Sync bottom to top
        } else if (linkPair === 'horizontal') {
            var $leftInput = $fieldWrapper.find('.dnxte-dimension-input-left');
            var $rightInput = $fieldWrapper.find('.dnxte-dimension-input-right');
            updateLinkedDimensionInput($leftInput, $rightInput); // Sync right to left
        }
    });
});