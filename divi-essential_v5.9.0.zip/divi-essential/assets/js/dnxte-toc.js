/**
 * Table of Contents JavaScript functionality
 * Enhanced Vanilla JS version (optimized for Divi 5 modules)
 * Features:
 * - Whole-page and section-specific mode
 * - Auto-prefix class names
 * - Smooth scrolling
 * - Dynamic sticky positioning
 * - Active item highlight while scrolling
 * - MutationObserver for live DOM updates
 * - Infinite loop prevention
 * - requestAnimationFrame throttling for performance
 * - URL sync without jump
 */

// Debug mode - set to false in production
const DEBUG_TOC = false;

class TableOfContents {
    constructor(options = {}, containerElement = null) {
        this.options = {
            containerSelector: '.dnxte-toc-container',
            contentSelector: '.dnxte-toc-list',
            headingSelector: '.dnxte_table_heading',
            collapsibleIconSelector: '.dnxte-collapsible-icon',
            headingTags: 'h1,h2,h3,h4,h5,h6',
            generateFromSection: 'off', // 'on' for section mode, 'off' for whole-page
            sectionSelectors: '', // CSS selectors for section mode
            isCollapsible: false,
            tableHeading: 'Table of Contents',
            headerIcon: null,
            iconPosition: 'left',
            throttleMs: 250,
            scrollOffset: 100,
            isSticky: false,
            stickyOffset: 20,
            stickyBreakpoint: 768,
            // Maximum number of items to render (0 = show all). Set via data-list-limit.
            listLimit: 0,
            // Duration for animated scroll (ms). Can be overridden via data-scroll-time
            scrollTimeMs: 400,
            ...options
        };

        this.tocItems = [];
        this.container = containerElement || null;
        this.contentElement = null;
        this.headingElement = null;
        this.collapsibleIcon = null;
        this.mutationObserver = null;
        this.throttleFrame = null;
        this.lastRun = 0;
        this.activeObserver = null;
        this.isUpdatingDOM = false; // Prevent infinite MutationObserver loops
        this.assignedIds = new WeakSet(); // Track headings we've assigned IDs to
        this.instanceId = this.generateInstanceId();

        this.init();
    }

    generateInstanceId() {
        return 'toc-' + Math.random().toString(36).substr(2, 9);
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        if (!this.container) {
            this.container = document.querySelector(this.options.containerSelector);
        }
        if (!this.container) {
            console.warn('TOC container not found:', this.options.containerSelector);
            return;
        }

        this.contentElement = this.container.querySelector(this.options.contentSelector);
        this.headingElement = this.container.querySelector(this.options.headingSelector);
        this.collapsibleIcon = this.container.querySelector(this.options.collapsibleIconSelector);

        this.generateTableOfContents();
        this.setupCollapsible();
        this.setupSticky();
        this.observeScrollActive();
        this.observeChanges();
    }

    // Live list of regions whose headings must never appear in the TOC:
    //  - Theme header/footer + admin bar (navigation/chrome, not content).
    //  - Mega Menu panels (.dnxte-mega-menu-panel): the Mega Menu prerenders full
    //    Divi layouts — blurbs, text, countdown modules, etc., each containing real
    //    heading tags — into these panels and injects them into the desktop nav,
    //    vertical flyouts AND the off-canvas menu. Those panels live OUTSIDE
    //    .et-l--header, so a header-only exclusion misses the off-canvas/vertical
    //    copies. .dnxte-mega-menu-panel wraps every copy (see mega-menu renderer
    //    build_panel_html()), so it is the reliable selector.
    // NOTE: bare `header`/`footer` tags are intentionally NOT used — they would also
    // match content sub-headers like `<header class="entry-header">` and drop real
    // headings. The Divi-specific selectors below target only the theme chrome.
    getExcludedRegions() {
        if (typeof document === 'undefined') return [];
        const selector = [
            '#wpadminbar',
            '.et-l--header', '.et-l--footer',
            '#main-header', '#top-header',
            '#main-footer', '#footer', '#footer-widgets',
            '.dnxte-mega-menu-panel'
        ].join(',');
        return Array.from(document.querySelectorAll(selector));
    }

    getHeadings() {
        if (typeof document === 'undefined' || typeof window === 'undefined') return [];

        try {
            // Debug: Check what mode we're in
            if (DEBUG_TOC) {
                console.log(`[TOC ${this.instanceId}] Mode check:`, {
                    generateFromSection: this.options.generateFromSection,
                    sectionSelectors: this.options.sectionSelectors
                });
            }

            // Get all TOC containers to exclude them from heading collection
            const allTocContainers = document.querySelectorAll('.dnxte-toc-container');
            const headingTags = this.options.headingTags.split(',').map(t => t.trim()).filter(Boolean);

            if (!headingTags.length) {
                if (DEBUG_TOC) console.warn(`[TOC ${this.instanceId}] No heading tags configured`);
                return [];
            }

            let collectedHeadings = [];

            if (this.options.generateFromSection === 'on') {
                // Section-specific mode: only collect headings from specified sections
                if (!this.options.sectionSelectors || !this.options.sectionSelectors.trim()) {
                    if (DEBUG_TOC) console.warn(`[TOC ${this.instanceId}] Section mode enabled but no selectors provided`);
                    return [];
                }

                // Parse and normalize selectors - add dot prefix for class names if missing
                const sectionArray = this.options.sectionSelectors.split(',').map(s => {
                    const trimmed = s.trim();
                    // If it doesn't start with a CSS selector character, assume it's a class and add dot
                    if (trimmed && !trimmed.match(/^[.#\[]/) && trimmed.match(/^[a-zA-Z0-9_-]+$/)) {
                        return `.${trimmed}`;
                    }
                    return trimmed;
                }).filter(Boolean);

                if (!sectionArray.length) {
                    if (DEBUG_TOC) console.warn(`[TOC ${this.instanceId}] Empty section selectors after parsing`);
                    return [];
                }

                try {
                    // Query for section containers
                    const selectorString = sectionArray.join(',');
                    if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Querying sections with selector: "${selectorString}"`);

                    const containers = document.querySelectorAll(selectorString);
                    if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Found ${containers.length} section containers`);

                    if (!containers.length) {
                        if (DEBUG_TOC) console.warn(`[TOC ${this.instanceId}] No sections found matching: ${selectorString}`);
                        return [];
                    }

                    // Collect headings from each section
                    containers.forEach((container, idx) => {
                        // Make sure the container itself is not inside a TOC
                        const isInsideToc = Array.from(allTocContainers).some(toc => toc.contains(container));
                        if (isInsideToc) {
                            if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Skipping section ${idx} - inside TOC`);
                            return;
                        }

                        const sectionHeadings = container.querySelectorAll(headingTags.join(','));
                        if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Section ${idx}: found ${sectionHeadings.length} headings`);
                        collectedHeadings.push(...Array.from(sectionHeadings));
                    });

                    if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Section mode: found ${collectedHeadings.length} total headings in ${containers.length} sections`);
                } catch (error) {
                    console.error(`[TOC ${this.instanceId}] Error querying sections:`, error);
                    return [];
                }
            } else {
                // Whole-page mode: collect all headings from the document (header/footer
                // headings are removed in the filtering step below).
                const nodeList = document.querySelectorAll(headingTags.join(','));
                collectedHeadings = Array.from(nodeList);
                if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Whole-page mode: found ${collectedHeadings.length} total headings`);
            }

            // Exclude headings that are inside any TOC container OR inside a
            // header/footer/admin-bar region (we never want chrome headings in the TOC).
            const excludedRegions = this.getExcludedRegions();
            const filteredHeadings = collectedHeadings.filter(h => {
                const insideToc = allTocContainers.length && Array.from(allTocContainers).some(toc => toc.contains(h));
                const insideChrome = excludedRegions.some(region => region.contains(h));
                return !insideToc && !insideChrome;
            });

            if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] After filtering TOC + header/footer: ${filteredHeadings.length} headings`);
            return filteredHeadings;
        } catch (error) {
            console.error(`[TOC ${this.instanceId}] Error in getHeadings:`, error);
            return [];
        }
    }

    getTagLevel(tagName) {
        const order = this.options.headingTags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
        const natural = /^h([1-6])$/i.exec(tagName);
        const naturalLevel = natural ? parseInt(natural[1], 10) : 6;
        const configuredIndex = order.indexOf(tagName.toLowerCase());
        return configuredIndex !== -1 ? configuredIndex : naturalLevel - 1;
    }

    generateTableOfContents() {
        if (!this.container) return;

        if (DEBUG_TOC) {
            console.log(`[TOC ${this.instanceId}] === GENERATING TABLE OF CONTENTS ===`);
            console.log(`[TOC ${this.instanceId}] Settings:`, {
                generateFromSection: this.options.generateFromSection,
                sectionSelectors: this.options.sectionSelectors,
                headingTags: this.options.headingTags
            });
        }

        const allHeadings = this.getHeadings();
        if (!allHeadings.length) {
            this.tocItems = [];
            this.renderTOC();
            return;
        }

        // Set flag to indicate we're updating the DOM (assigning IDs)
        // This prevents MutationObserver from triggering on our own changes
        this.isUpdatingDOM = true;

        const items = allHeadings.map((heading, index) => {
            // Safety check
            if (!heading || !heading.tagName) {
                console.warn(`[TOC ${this.instanceId}] Invalid heading element at index ${index}`);
                return null;
            }

            // Get the text content of the heading
            const text = heading.innerText?.trim() || heading.textContent?.trim() || `Heading ${index + 1}`;

            // Only assign ID if heading doesn't already have one AND we haven't assigned one before
            if (!heading.id && !this.assignedIds.has(heading)) {
                // Create base slug from text
                const base = text
                    .trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-|-$/g, '');

                if (base) {
                    // Check if this ID already exists on the page
                    let candidateId = `dnxte-toc-${base}`;
                    let counter = 1;
                    while (document.getElementById(candidateId) && document.getElementById(candidateId) !== heading) {
                        candidateId = `dnxte-toc-${base}-${counter}`;
                        counter++;
                    }
                    heading.id = candidateId;
                    this.assignedIds.add(heading);
                } else {
                    // Fallback to index-based ID
                    heading.id = `dnxte-toc-heading-${Date.now()}-${index}`;
                    this.assignedIds.add(heading);
                }
            }

            const tag = heading.tagName.toLowerCase();

            return {
                id: heading.id,
                text: text,
                tag: tag,
                level: this.getTagLevel(tag)
            };
        }).filter(Boolean); // Remove any null items

        // Reset flag after a small delay to ensure mutations are processed
        setTimeout(() => {
            this.isUpdatingDOM = false;
            if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] DOM update complete - re-enabling MutationObserver`);
        }, 100);

        // Apply the optional item-count limit (0 / empty / invalid = show all).
        // IDs are already assigned to every heading above, so deep-links and scroll
        // targets for headings beyond the limit still work — they just aren't listed.
        const limit = parseInt(this.options.listLimit, 10);
        const limitedItems = (Number.isFinite(limit) && limit > 0) ? items.slice(0, limit) : items;

        if (!this.arraysEqual(limitedItems, this.tocItems)) {
            if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] Setting ${limitedItems.length} items (prev: ${this.tocItems.length})`);
            this.tocItems = limitedItems;
            this.renderTOC();
        }
    }

    arraysEqual(a, b) {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) {
            const itemA = a[i];
            const itemB = b[i];
            if (!itemB || itemA.id !== itemB.id || itemA.text !== itemB.text ||
                itemA.tag !== itemB.tag || itemA.level !== itemB.level) {
                return false;
            }
        }
        return true;
    }

    // Smoothly scroll the window to a Y position over a specified duration
    smoothScrollTo(targetY, durationMs = 400) {
        if (typeof window === 'undefined') return;

        const startY = window.pageYOffset || document.documentElement.scrollTop || 0;
        const diff = targetY - startY;

        // If duration is invalid or movement is negligible, jump directly
        if (!durationMs || durationMs <= 0 || Math.abs(diff) < 1) {
            window.scrollTo(0, Math.round(targetY));
            return;
        }

        const startTime = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

        // EaseInOutQuad for a pleasant acceleration/deceleration
        const easeInOutQuad = (t) => (t < 0.5) ? (2 * t * t) : (-1 + (4 - 2 * t) * t);

        const step = (now) => {
            const current = (typeof performance !== 'undefined' && performance.now) ? now : Date.now();
            const elapsed = current - startTime;
            const t = Math.min(1, elapsed / durationMs);
            const eased = easeInOutQuad(t);
            const y = Math.round(startY + diff * eased);
            window.scrollTo(0, y);
            if (t < 1) {
                requestAnimationFrame(step);
            }
        };

        requestAnimationFrame(step);
    }

    renderTOC() {
        if (!this.contentElement) return;
        this.contentElement.innerHTML = '';

        if (this.tocItems.length === 0) {
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'dnxte-toc-empty';
            emptyDiv.textContent = 'No headings found.';
            this.contentElement.appendChild(emptyDiv);
            return;
        }

        this.tocItems.forEach(item => {
            const li = document.createElement('li');
            const indentPx = item.level * 16;

            li.className = `dnxte-toc-item dnxte-toc-item-${item.tag} dnxte-toc-level-${item.level}`;
            li.setAttribute('data-level', item.level);
            if (indentPx) li.style.paddingLeft = `${indentPx}px`;

            const link = document.createElement('a');
            link.href = `#${item.id}`;
            link.textContent = item.text;

            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.getElementById(item.id);
                if (target) {
                    const topOffset = parseInt(this.options.stickyOffset || 0);
                    const rect = target.getBoundingClientRect();
                    const scrollTop = window.pageYOffset + rect.top - topOffset + 25;
                    const duration = parseInt(this.options.scrollTimeMs, 10);
                    this.smoothScrollTo(scrollTop, isNaN(duration) ? 400 : duration);
                    history.pushState(null, null, `#${item.id}`);
                }
            });

            li.appendChild(link);
            this.contentElement.appendChild(li);
        });

        // Re-observe scroll after rendering new links
        this.observeScrollActive();
    }

    setupCollapsible() {
        if (!this.options.isCollapsible || !this.headingElement) return;

        this.headingElement.addEventListener('click', () => {
            this.container.classList.toggle('dnxte-collapsible-active');
            if (this.collapsibleIcon) {
                const isActive = this.container.classList.contains('dnxte-collapsible-active');
                this.collapsibleIcon.textContent = isActive ? '3' : '5';
            }
        });
        this.headingElement.style.cursor = 'pointer';
    }

    setupSticky() {
        if (!this.options.isSticky || !this.container) return;

        // Normalize the offset (distance from the top of the viewport while stuck).
        if (this.options.stickyOffset === null || this.options.stickyOffset === undefined) {
            this.options.stickyOffset = 20;
        }

        // position:sticky only travels within its containing block. The inner
        // .dnxte-toc-container is only as tall as itself, so it has no room to stick.
        // The tall element is the column, so we make the module wrapper (a direct child
        // of the column) sticky instead — the browser then pins it while scrolling AND
        // automatically stops it at the bottom of the column, so it never floats over the
        // footer. No placeholder or scroll math needed.
        this.stickyEl = this.container.closest('.et_pb_module') || this.container.parentElement || this.container;

        this.applySticky = this.applySticky.bind(this);
        this.applySticky();
        window.addEventListener('resize', this.applySticky, { passive: true });
    }

    applySticky() {
        const stickyEl = this.stickyEl || this.container;
        if (!stickyEl) return;

        // Sticky is disabled below the configured breakpoint (e.g. mobile).
        const enabled = window.innerWidth >= this.options.stickyBreakpoint;
        if (enabled) {
            stickyEl.style.position = 'sticky';
            stickyEl.style.top = `${this.options.stickyOffset}px`;
            this.container.classList.add('dnxte-toc-sticky');
        } else {
            stickyEl.style.position = '';
            stickyEl.style.top = '';
            this.container.classList.remove('dnxte-toc-sticky');
        }
    }

    observeScrollActive() {
        // Clean up existing observers/listeners
        if (this.activeObserver) this.activeObserver.disconnect();
        if (this.activeScrollCleanup) this.activeScrollCleanup();

        const headings = this.getHeadings();
        if (!headings.length) return;

        const tocLinks = Array.from(this.contentElement.querySelectorAll('a'));
        if (!tocLinks.length) return;

        // Store last scroll position to detect direction
        let lastScrollY = window.pageYOffset;
        let ticking = false;
        let currentActiveId = null; // Track currently active heading to prevent flickering
        let isInitialCall = true; // Suppress URL hash write on first call (page load shouldn't add a hash)

        const updateActiveLink = () => {
            const scrollY = window.pageYOffset;
            const windowHeight = window.innerHeight;
            const documentHeight = document.documentElement.scrollHeight;

            // Detect scroll direction
            const scrollDirection = scrollY > lastScrollY ? 'down' : 'up';

            // Offset from top of viewport (adjust based on sticky header if any)
            // Use smaller offset when scrolling up for more responsive switching
            const offset = scrollDirection === 'up'
                ? (this.options.stickyOffset || 80)  // Smaller offset for scrolling up
                : (this.options.stickyOffset || 100); // Normal offset for scrolling down

            // Check if we're at the bottom of the page
            const isAtBottom = scrollY + windowHeight >= documentHeight - 10;

            // Check if we're at the top of the page
            const isAtTop = scrollY < 50;

            let activeHeading = null;

            // Calculate heading positions for all headings (needed for adaptive thresholds)
            const triggerPoint = scrollY + offset;
            const headingPositions = headings.map((heading, index) => {
                    const rect = heading.getBoundingClientRect();
                    const topPosition = rect.top + scrollY;

                    // Calculate spacing to next heading
                    let spacingToNext = null;
                    if (index < headings.length - 1) {
                        const nextRect = headings[index + 1].getBoundingClientRect();
                        spacingToNext = (nextRect.top + scrollY) - topPosition;
                    }

                    return {
                        heading: heading,
                        index: index,
                        top: topPosition,
                        bottom: rect.bottom + scrollY,
                        spacingToNext: spacingToNext,
                        distanceFromTrigger: Math.abs(topPosition - triggerPoint)
                    };
                });

                if (scrollDirection === 'down') {
                    // Scrolling down: activate the last heading that's above or at the trigger point
                    for (let i = headingPositions.length - 1; i >= 0; i--) {
                        if (headingPositions[i].top <= triggerPoint) {
                            activeHeading = headingPositions[i].heading;
                            break;
                        }
                    }
                } else {
                    // Scrolling up: activate when the heading comes back into the trigger zone
                    // Find the first heading whose top is at or below the trigger point
                    for (let i = 0; i < headingPositions.length; i++) {
                        const pos = headingPositions[i];

                        // Adaptive hysteresis: smaller for closely spaced headings
                        let hysteresis = 50; // Default
                        if (i > 0 && headingPositions[i - 1].spacingToNext !== null) {
                            const prevSpacing = headingPositions[i - 1].spacingToNext;
                            // If headings are close (< 200px apart), reduce hysteresis
                            if (prevSpacing < 200) {
                                hysteresis = Math.max(10, prevSpacing * 0.2); // 20% of spacing, minimum 10px
                            }
                        }

                        // When scrolling up, switch to this heading when its top passes the trigger
                        if (pos.top >= triggerPoint - hysteresis) {
                            // Use the previous heading if we're above this one
                            if (i > 0) {
                                activeHeading = headingPositions[i - 1].heading;
                            } else {
                                activeHeading = pos.heading;
                            }
                            break;
                        }
                    }

                    // If we didn't find one (scrolled past all headings), use the last one
                    if (!activeHeading) {
                        activeHeading = headingPositions[headingPositions.length - 1].heading;
                    }
                }

            // Fallback: if still no active heading, use the closest one
            if (!activeHeading && headingPositions.length > 0) {
                const closest = headingPositions.reduce((prev, curr) =>
                    curr.distanceFromTrigger < prev.distanceFromTrigger ? curr : prev
                );
                activeHeading = closest.heading;
            }

            // Override: when scrolled above all headings, no heading is active.
            // Don't lock onto the first heading via the closest-heading fallback.
            const isAboveAllHeadings = headingPositions.length > 0 && triggerPoint < headingPositions[0].top;
            if (isAboveAllHeadings) {
                activeHeading = null;
            }

            // Update active state - only if it's actually different
            if (activeHeading) {
                const activeId = activeHeading.id;

                // Only update if the active heading has actually changed
                if (currentActiveId !== activeId) {
                    // Find the current and new heading positions to check spacing
                    const newHeadingPos = headingPositions ? headingPositions.find(p => p.heading.id === activeId) : null;
                    const currentHeadingPos = currentActiveId && headingPositions ?
                        headingPositions.find(p => p.heading.id === currentActiveId) : null;

                    // Determine minimum scroll threshold based on heading spacing
                    let minScrollThreshold = 5; // Default
                    if (currentHeadingPos && currentHeadingPos.spacingToNext !== null && currentHeadingPos.spacingToNext < 200) {
                        // For closely spaced headings, reduce the threshold
                        minScrollThreshold = 1; // Almost no threshold for close headings
                    }

                    // Additional check: prevent rapid switching between close headings
                    // Calculate if we should actually switch based on scroll distance
                    const shouldSwitch = Math.abs(scrollY - lastScrollY) > minScrollThreshold || // Adaptive scroll distance
                                       currentActiveId === null || // First activation
                                       isAtTop || isAtBottom; // Edge cases

                    if (shouldSwitch) {
                        const activeLink = tocLinks.find(a => a.getAttribute('href') === `#${activeId}`);

                        if (activeLink) {
                            // Remove active from all links
                            tocLinks.forEach(link => {
                                link.closest('li').classList.remove('active');
                                link.removeAttribute('aria-current');
                            });

                            // Add active to current link
                            // activeLink.classList.add('active');
                            activeLink.closest('li').classList.add('active');
                            activeLink.setAttribute('aria-current', 'true');

                            // Update URL without jumping.
                            // Skip on the very first call: on page load the user hasn't
                            // scrolled, so we shouldn't rewrite the URL with the first
                            // heading's hash (also preserves any deep-link hash on arrival).
                            if (history.replaceState && !isInitialCall) {
                                history.replaceState(null, null, `#${activeId}`);
                            }

                            // Update the tracked active ID
                            currentActiveId = activeId;

                            if (DEBUG_TOC) {
                                console.log(`[TOC ${this.instanceId}] Scrolling ${scrollDirection}, Active heading: ${activeHeading.textContent}`);
                            }
                        }
                    }
                }
            } else if (isAboveAllHeadings && currentActiveId !== null) {
                // User scrolled back above all headings - clear active class and URL hash.
                tocLinks.forEach(link => {
                    link.closest('li').classList.remove('active');
                    link.removeAttribute('aria-current');
                });
                if (history.replaceState && window.location.hash) {
                    history.replaceState(null, null, window.location.pathname + window.location.search);
                }
                currentActiveId = null;
            }

            lastScrollY = scrollY;
            ticking = false;
        };

        const onScroll = () => {
            if (!ticking) {
                window.requestAnimationFrame(updateActiveLink);
                ticking = true;
            }
        };

        // Initial update to set the first active item (URL hash write is suppressed for this call)
        updateActiveLink();
        isInitialCall = false;

        // Listen to scroll events
        window.addEventListener('scroll', onScroll, { passive: true });

        // Store the cleanup function
        this.activeScrollCleanup = () => {
            window.removeEventListener('scroll', onScroll);
        };
    }

    observeChanges() {
        if (typeof MutationObserver === 'undefined') return;

        this.mutationObserver = new MutationObserver((mutations) => {
            // Ignore mutations we caused ourselves (like assigning IDs to headings)
            if (this.isUpdatingDOM) {
                if (DEBUG_TOC) {
                    console.log(`[TOC ${this.instanceId}] MutationObserver: ignoring mutations (we are updating DOM)`);
                }
                return;
            }

            if (!this.container) return;

            // Dynamically query all TOC containers (not cached) to handle multiple instances
            const allTocContainers = document.querySelectorAll('.dnxte-toc-container');

            // Ignore mutations that happen inside any TOC container
            const relevant = mutations.some(m => {
                const target = m.target;
                return !Array.from(allTocContainers).some(toc => toc.contains(target));
            });

            if (!relevant) {
                if (DEBUG_TOC) {
                    console.log(`[TOC ${this.instanceId}] MutationObserver: ignoring mutations inside TOC`);
                }
                return;
            }

            if (DEBUG_TOC) {
                console.log(`[TOC ${this.instanceId}] MutationObserver: relevant mutation detected, triggering regeneration`);
            }

            const now = performance.now();
            if (now - this.lastRun < this.options.throttleMs) {
                if (this.throttleFrame) cancelAnimationFrame(this.throttleFrame);
                this.throttleFrame = requestAnimationFrame(() => {
                    if (DEBUG_TOC) console.log(`[TOC ${this.instanceId}] MutationObserver: calling generateTableOfContents (throttled)`);
                    this.generateTableOfContents();
                });
                return;
            }

            this.lastRun = now;
            this.generateTableOfContents();
        });

        this.mutationObserver.observe(document.body, { subtree: true, childList: true, characterData: true });
    }

    destroy() {
        if (this.mutationObserver) this.mutationObserver.disconnect();
        if (this.activeObserver) this.activeObserver.disconnect();
        if (this.activeScrollCleanup) this.activeScrollCleanup();
        if (this.throttleFrame) cancelAnimationFrame(this.throttleFrame);

        if (this.options.isSticky) {
            window.removeEventListener('resize', this.applySticky);

            // Reset the inline sticky styles applied in applySticky().
            const stickyEl = this.stickyEl || this.container;
            if (stickyEl) {
                stickyEl.style.position = '';
                stickyEl.style.top = '';
            }
            if (this.container) {
                this.container.classList.remove('dnxte-toc-sticky');
            }
        }
    }

    refresh() {
        this.generateTableOfContents();
        this.observeScrollActive();
    }

    updateSettings(newOptions) {
        this.options = { ...this.options, ...newOptions };
        this.generateTableOfContents();
        this.observeScrollActive();
    }
}

// Auto-init on DOM ready
document.addEventListener('DOMContentLoaded', function () {
    const tocContainers = document.querySelectorAll('.dnxte-toc-container');
    tocContainers.forEach(container => {
        if (container.dataset.tocInitialized) return;

        const settings = {
            headingTags: container.dataset.headingTags || 'h1,h2,h3,h4,h5,h6',
            generateFromSection: container.dataset.generateFromSection || 'off', // Read from data-generate-from-section
            sectionSelectors: container.dataset.sectionSelectors || '', // Read from data-section-selectors
            isCollapsible: container.dataset.collapsible === 'true' || container.dataset.collapsible === 'on',
            tableHeading: container.dataset.tableHeading || 'Table of Contents',
            isSticky: container.dataset.sticky === 'true' || container.dataset.sticky === 'on',
            stickyOffset: container.dataset.stickyOffset ? parseInt(container.dataset.stickyOffset) : 20,
            stickyBreakpoint: parseInt(container.dataset.stickyBreakpoint) || 768,
            listLimit: container.dataset.listLimit ? parseInt(container.dataset.listLimit) : 0,
            // Read scroll duration: accepts milliseconds (e.g., 400) or seconds (e.g., 0.4)
            scrollTimeMs: (() => {
                const v = container.dataset.scrollTime;
                if (v === undefined || v === null || v === '') return 400;
                const num = parseFloat(v);
                if (isNaN(num)) return 400;
                // If value looks like seconds (< 10), convert to ms
                return num < 10 ? Math.round(num * 1000) : Math.round(num);
            })()
        };

        if (DEBUG_TOC) {
            console.log('[TOC] Initializing with settings:', settings);
        }

        new TableOfContents(settings, container);
        container.dataset.tocInitialized = 'true';
    });
});

window.TableOfContents = TableOfContents;
