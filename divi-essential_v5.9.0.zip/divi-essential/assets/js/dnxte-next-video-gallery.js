/**
 * NextVideoGallery Frontend Script
 *
 * Handles: Lightbox (Magnific Popup), Category Filtering, Lazy Loading
 */
(function ($) {
  "use strict";

  function initVideoGallery($wrapper) {
    var $grid = $wrapper.find(".dnxte-video-gallery-grid");
    var configStr = $grid.attr("data-config");
    if (!configStr) return;

    var config;
    try {
      config = JSON.parse(configStr);
    } catch (e) {
      return;
    }

    // Detect order class from module wrapper (parent of .dnxte-video-gallery-wrapper).
    var $moduleWrapper = $wrapper.closest('[class*="dnxte_next_video_gallery_"]');
    var orderClassMatch = $moduleWrapper.length
      ? $moduleWrapper.attr("class").match(/dnxte_next_video_gallery_\d+/)
      : null;
    var orderClassStr = orderClassMatch ? orderClassMatch[0] : "";

    // --- Category Filtering ---
    var $filterBar = $wrapper.find(".dnxte-video-gallery-filter-bar");
    if ($filterBar.length) {
      $filterBar.on("click", ".dnxte-video-gallery-filter-item", function () {
        var $btn = $(this);
        var filter = $btn.data("filter");

        $filterBar.find(".dnxte-video-gallery-filter-item").removeClass("active");
        $btn.addClass("active");

        // In Divi 5, each child <a> is wrapped in a module div. Target the
        // inner anchor (.dnxte-video-gallery-item) for show/hide filtering.
        var $items = $grid.find(".dnxte-video-gallery-item");
        // Also grab the Divi child wrappers so we can show/hide them.
        var $childWrappers = $grid.find(".dnxte-next-vg-child");

        if (filter === "*") {
          $childWrappers.show();
          $items.show();
          if (config.filterAnim === "fade") {
            $childWrappers.css("opacity", 0).animate({ opacity: 1 }, 300);
          }
        } else {
          $childWrappers.hide();
          $items.hide();
          var $matched = $items.filter(filter);
          $matched.each(function () {
            $(this).show().closest(".dnxte-next-vg-child").show();
          });
          if (config.filterAnim === "fade") {
            $matched.closest(".dnxte-next-vg-child").css("opacity", 0).animate({ opacity: 1 }, 300);
          }
        }
      });
    }

    // --- Lightbox (Magnific Popup) ---
    if (config.clickAction === "lightbox" && typeof $.fn.magnificPopup === "function") {
      var mainClass = "dnxte-video-gallery-lightbox" + (orderClassStr ? " " + orderClassStr : "");

      $grid.magnificPopup({
        delegate: ".dnxte-video-gallery-item",
        type: "inline",
        mainClass: mainClass,
        gallery: {
          enabled: config.lightbox.arrows === "on",
          navigateByImgClick: false,
        },
        closeOnBgClick: config.lightbox.closeOnBg === "on",
        enableEscapeKey: config.lightbox.closeOnEsc === "on",
        callbacks: {
          elementParse: function (item) {
            var $el     = item.el;
            var $anchor = $el.is("a") ? $el : $el.find("a").first();
            var src = ($anchor.length ? ($anchor.attr("data-src") || $anchor.attr("href")) : "") ||
                      $el.attr("data-src") || $el.attr("data-mfp-src") || "";
            var source = ($anchor.length ? $anchor.attr("data-source") : "") || $el.attr("data-source") || "";
            var autoplay = config.lightbox.autoplay === "on" ? "1" : "0";

            var title = ($anchor.length ? $anchor.attr("data-title") : "") || $el.attr("data-title") || "";
            var desc  = ($anchor.length ? $anchor.attr("data-description") : "") || $el.attr("data-description") || "";

            var titleHtml = "";
            if (config.lightbox.showTitle === "on" && title) {
              titleHtml += '<h4 class="dnxte-video-gallery-lb-title">' + $("<span>").text(title).html() + "</h4>";
            }
            if (config.lightbox.showDesc === "on" && desc) {
              titleHtml += '<p class="dnxte-video-gallery-lb-desc">' + $("<span>").text(desc).html() + "</p>";
            }
            var bottomBar = titleHtml ? '<div class="mfp-bottom-bar"><div class="mfp-title">' + titleHtml + '</div></div>' : '';

            item.type = "inline";

            if (source === "self-hosted") {
              var muteAttr = autoplay === "1" ? " muted" : "";
              item.src = '<div class="dnxte-video-inline-wrapper"><video autoplay' + muteAttr + ' controls style="width:100%;height:auto;display:block;">' +
                         '<source src="' + src + '" type="video/mp4">' +
                         '</video>' + bottomBar + '</div>';
            } else {
              if (src && (src.indexOf("youtube.com") !== -1 || src.indexOf("youtube-nocookie.com") !== -1)) {
                src += (src.indexOf("?") === -1 ? "?" : "&") + "autoplay=" + autoplay + "&rel=0";
                if (autoplay === "1") src += "&mute=1";
              } else if (src && src.indexOf("vimeo.com") !== -1) {
                src += (src.indexOf("?") === -1 ? "?" : "&") + "autoplay=" + autoplay;
              }
              item.src = '<div class="dnxte-video-inline-wrapper"><div class="mfp-iframe-scaler">' +
                         '<iframe class="mfp-iframe" src="' + src + '" frameborder="0" allowfullscreen allow="autoplay; encrypted-media"></iframe>' +
                         '</div>' + bottomBar + '</div>';
            }
          },
        },
      });
    }

    // --- Inline Play ---
    if (config.clickAction === "inline") {
      // Stop clicks on video/iframe from bubbling to the anchor.
      $grid.on("click", "video, iframe", function (e) {
        e.stopPropagation();
      });

      $grid.on("click", ".dnxte-video-gallery-item", function (e) {
        e.preventDefault();
        var $item = $(this);

        if ($item.hasClass("dnxte-video-playing")) {
          return;
        }

        var $anchor = $item.is("a") ? $item : $item.find("a").first();
        var src    = ($anchor.length ? ($anchor.attr("data-src") || $anchor.attr("href")) : "") || "";
        var source = ($anchor.length ? $anchor.attr("data-source") : "") || $item.attr("data-source") || "";

        if (!src) { return; }

        var $thumb = $anchor.find(".dnxte-video-gallery-thumbnail").length
          ? $anchor.find(".dnxte-video-gallery-thumbnail")
          : $item.find(".dnxte-video-gallery-thumbnail");

        if (source === "self-hosted") {
          $thumb.html(
            '<video autoplay controls style="width:100%;display:block;">' +
            '<source src="' + src + '" type="video/mp4">' +
            "</video>"
          );
        } else {
          var thumbH = $thumb.outerHeight();
          if (thumbH > 0) {
            $thumb.css({ height: thumbH + "px", position: "relative" });
          }
          src += (src.indexOf("?") === -1 ? "?" : "&") + "autoplay=1&mute=1";
          $thumb.html(
            '<iframe src="' + src + '" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allowfullscreen allow="autoplay; encrypted-media"></iframe>'
          );
        }

        $item.addClass("dnxte-video-playing");
      });
    }

    // --- Lazy Loading with IntersectionObserver ---
    if ("IntersectionObserver" in window) {
      var lazyImages = $wrapper.find("img[loading='lazy']").get();
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target;
            if (img.dataset.src) {
              img.src = img.dataset.src;
              delete img.dataset.src;
            }
            observer.unobserve(img);
          }
        });
      });

      lazyImages.forEach(function (img) {
        observer.observe(img);
      });
    }
  }

  // Initialize on DOM ready
  $(function () {
    $(".dnxte-video-gallery-wrapper").each(function () {
      initVideoGallery($(this));
    });
  });

  // Re-init for dynamic content (e.g., AJAX load)
  $(document).on("dnxte-video-gallery-init", function (e, wrapper) {
    initVideoGallery($(wrapper));
  });
})(jQuery);
