/**
 * DNXTE — "Order on WhatsApp" for WooCommerce (front-end).
 *
 * Vanilla JS (jQuery is used only if present, for WC variation events). Rebuilds
 * the button's wa.me href so:
 *   - {product_url}/{site_name} re-resolve client-side on cached pages, and
 *   - variable products reflect the selected variation's price / SKU / id.
 *
 * The wa.me logic mirrors the PHP WhatsAppWooCommerce::build_wa_link() and the
 * ChatAgent module's builder — kept as a small local copy, no shared module.
 */
(function () {
  'use strict';

  /** Strip everything except digits (wa.me needs bare digits). */
  function digitsOnly(value) {
    return String(value || '').replace(/[^0-9]/g, '');
  }

  /** Replace {tokens} in the template with the current token values. */
  function applyTokens(template, tokens) {
    return String(template || '')
      .replace(/\{product_name\}/g, tokens.name || '')
      .replace(/\{product_price\}/g, tokens.price || '')
      .replace(/\{product_sku\}/g, tokens.sku || '')
      .replace(/\{product_url\}/g, tokens.url || '')
      .replace(/\{product_id\}/g, tokens.id || '')
      .replace(/\{site_name\}/g, tokens.site || '')
      .replace(/\{cart_summary\}/g, tokens.cart || '');
  }

  /** Build the wa.me deep link. */
  function buildHref(number, message) {
    var digits = digitsOnly(number);
    if (!digits) {
      return '';
    }
    return message
      ? 'https://wa.me/' + digits + '?text=' + encodeURIComponent(message)
      : 'https://wa.me/' + digits;
  }

  /** Turn an HTML string (e.g. WC price_html) into plain text. */
  function stripHtml(html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = String(html || '');
    return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
  }

  /** Read the current token map off the button's data-* attributes. */
  function tokensFrom(btn) {
    return {
      name: btn.getAttribute('data-wa-name') || '',
      price: btn.getAttribute('data-wa-price') || '',
      sku: btn.getAttribute('data-wa-sku') || '',
      url: btn.getAttribute('data-wa-url') || window.location.href,
      id: btn.getAttribute('data-wa-id') || '',
      site: btn.getAttribute('data-wa-site') || '',
      cart: btn.getAttribute('data-wa-cart') || ''
    };
  }

  /** Rebuild and set the button href from its template + tokens. */
  function refresh(btn) {
    var template = btn.getAttribute('data-wa-template');
    var number = btn.getAttribute('data-wa-number');
    // No template = static button (loop / cart) — leave the server href intact.
    if (template === null || number === null) {
      return;
    }
    var message = applyTokens(template, tokensFrom(btn));
    var href = buildHref(number, message);
    if (href) {
      btn.setAttribute('href', href);
    }
  }

  /** The single-product button (the one with rebuild data). */
  function primaryButton() {
    return document.querySelector('.dnxte-wa-wc-btn[data-wa-template]');
  }

  /**
   * Fire-and-forget aggregate ping to the plugin's own click counter, matching
   * the shared chat script's dnxte_wa_track endpoint. Guarded on
   * window.dnxteWaTrack (localized only when analytics is available) so it is a
   * no-op otherwise. Separate from any GA/GTM/Pixel tracking. Never blocks the
   * WhatsApp navigation.
   */
  function pingClick() {
    var cfg = window.dnxteWaTrack;
    if (!cfg || !cfg.url) {
      return;
    }
    try {
      var data = new FormData();
      data.append('action', 'dnxte_wa_track');
      data.append('nonce', cfg.nonce || '');
      data.append('event', 'click');
      data.append('channel', 'whatsapp');
      data.append('agent', '');
      if (navigator && typeof navigator.sendBeacon === 'function') {
        navigator.sendBeacon(cfg.url, data);
      } else if (typeof window.fetch === 'function') {
        window.fetch(cfg.url, { method: 'POST', body: data, keepalive: true, credentials: 'same-origin' });
      }
    } catch (e) {
      /* ping failed — ignore. */
    }
  }

  function init() {
    var buttons = document.querySelectorAll('.dnxte-wa-wc-btn[data-wa-template]');
    Array.prototype.forEach.call(buttons, function (btn) {
      // Re-resolve cache-sensitive tokens on load.
      if (!btn.getAttribute('data-wa-url')) {
        btn.setAttribute('data-wa-url', window.location.href);
      }
      refresh(btn);
    });

    // Aggregate click ping on every WooCommerce WhatsApp button (all of them,
    // including static loop/cart buttons — not just the template one).
    Array.prototype.forEach.call(document.querySelectorAll('.dnxte-wa-wc-btn'), function (btn) {
      btn.addEventListener('click', pingClick);
    });

    // Variable-product support via WC's jQuery events.
    if (window.jQuery) {
      var $ = window.jQuery;
      $('.variations_form').each(function () {
        var $form = $(this);

        $form.on('found_variation', function (event, variation) {
          var btn = primaryButton();
          if (!btn || !variation) {
            return;
          }
          if (variation.sku) {
            btn.setAttribute('data-wa-sku', variation.sku);
          }
          if (variation.price_html) {
            btn.setAttribute('data-wa-price', stripHtml(variation.price_html));
          } else if (variation.display_price != null) {
            btn.setAttribute('data-wa-price', String(variation.display_price));
          }
          if (variation.variation_id) {
            btn.setAttribute('data-wa-id', String(variation.variation_id));
          }
          refresh(btn);
        });

        $form.on('reset_data', function () {
          var btn = primaryButton();
          if (!btn) {
            return;
          }
          // Restore the base (parent-product) token values.
          ['price', 'sku', 'id'].forEach(function (key) {
            var base = btn.getAttribute('data-wa-' + key + '-base');
            if (base !== null) {
              btn.setAttribute('data-wa-' + key, base);
            }
          });
          refresh(btn);
        });
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
