/**
 * NextAudio — Frontend initialization.
 *
 * Reads configuration from data-* attributes on .dnxte-next-audio-container.
 * Supports: source type (media library / external URL), preload, autoplay,
 *           loop, fallback audio source, and full playback controls.
 */
(function () {
  'use strict';

  /**
   * Format seconds into MM:SS string.
   *
   * @param {number} time
   * @returns {string}
   */
  function formatTime(time) {
    if (isNaN(time) || !isFinite(time)) return '00:00';
    var minutes = Math.floor(time / 60);
    var seconds = Math.floor(time % 60);
    return (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
  }

  /**
   * Initialize a single audio player container.
   *
   * @param {HTMLElement} container
   */
  function initAudioPlayer(container) {
    if (container.dataset.audioInit) return;
    container.dataset.audioInit = 'true';

    // ── Read config from data-* attributes ──────────────────────────────────
    var audioSrc     = container.dataset.audioSrc || '';
    var fallbackSrc  = container.dataset.fallbackSrc || '';
    var preload      = container.dataset.preload || 'metadata';
    var autoplay     = container.dataset.autoplay === 'on';
    var loop         = container.dataset.loop === 'on';

    // ── Locate the <audio> element ──────────────────────────────────────────
    var audio = container.querySelector('.next_audio__audio_element');

    // If no audio element exists (e.g., old markup without source), build one.
    if (!audio && audioSrc) {
      audio = document.createElement('audio');
      audio.className = 'next_audio__audio_element';
      audio.style.display = 'none';
      container.appendChild(audio);
    }

    if (!audio) return;

    // Ensure the <audio> attributes match current settings.
    audio.preload = preload;
    audio.loop    = loop;

    // Rebuild <source> elements only if the audio URL actually changed.
    var currentSource = audio.querySelector('source');
    var needsReload   = !currentSource || currentSource.getAttribute('src') !== audioSrc;

    if (needsReload) {
      while (audio.firstChild) audio.removeChild(audio.firstChild);

      if (audioSrc) {
        var primary = document.createElement('source');
        primary.src = audioSrc;
        audio.appendChild(primary);
      }
      if (fallbackSrc) {
        var fallback = document.createElement('source');
        fallback.src = fallbackSrc;
        audio.appendChild(fallback);
      }

      audio.load();
    }

    // ── DOM references (before autoplay so we can sync UI) ───────────────────
    var playBtn      = container.querySelector('.next_audio__play_btn');
    var progress     = container.querySelector('.next_audio__progress');
    var progressFill = container.querySelector('.next_audio__progress_filled');
    var currentTime  = container.querySelector('.next_audio__current_time');
    var durationEl   = container.querySelector('.next_audio__duration');
    var muteBtn      = container.querySelector('.next_audio__mute_btn');
    var volumeBar    = container.querySelector('.next_audio__volume');
    var volumeFill   = container.querySelector('.next_audio__volume_filled');

    var savedVolume = 0.8;

    // ── Helper: sync mute UI with audio.muted state ─────────────────────────
    function syncMuteUI() {
      var muted = audio.muted;
      if (muteBtn) {
        muteBtn.classList.toggle('is-muted', muted);
        muteBtn.setAttribute('aria-label', muted ? 'Unmute' : 'Mute');
      }
      if (volumeFill) {
        volumeFill.style.width = muted ? '0%' : (audio.volume * 100) + '%';
      }
      if (volumeBar) {
        volumeBar.setAttribute('aria-valuenow', muted ? '0' : Math.round(audio.volume * 100).toString());
      }
    }

    // ── Helper: sync play/pause UI ──────────────────────────────────────────
    function syncPlayUI(playing) {
      if (playBtn) {
        playBtn.classList.toggle('is-playing', playing);
        playBtn.setAttribute('aria-label', playing ? 'Pause' : 'Play');
      }
    }

    // ── Autoplay (muted — required by browser policy) ───────────────────────
    if (autoplay) {
      audio.muted = true;

      function attemptAutoplay() {
        audio.play().then(function () {
          syncPlayUI(true);
          syncMuteUI();
        }).catch(function () {
          // Browser blocked autoplay — leave in paused state.
        });
      }

      if (needsReload) {
        // Audio was just reloaded — wait until ready.
        audio.addEventListener('canplay', attemptAutoplay, { once: true });
      } else if (audio.readyState >= 3) {
        // Already has enough data.
        attemptAutoplay();
      } else {
        // Wait for data.
        audio.addEventListener('canplay', attemptAutoplay, { once: true });
      }

      // Immediately sync the mute UI to show muted state.
      syncMuteUI();
    }

    // ── Sync play-state UI via audio events ─────────────────────────────────
    audio.addEventListener('playing', function () {
      syncPlayUI(true);
    });

    audio.addEventListener('pause', function () {
      syncPlayUI(false);
    });

    // ── Play / Pause ────────────────────────────────────────────────────────
    if (playBtn) {
      playBtn.addEventListener('click', function () {
        if (audio.paused) {
          audio.play().catch(function () {});
        } else {
          audio.pause();
        }
      });
    }

    // ── Time update → progress bar & current-time display ───────────────────
    audio.addEventListener('timeupdate', function () {
      if (currentTime) {
        currentTime.textContent = formatTime(audio.currentTime);
      }
      if (progressFill && audio.duration) {
        var pct = (audio.currentTime / audio.duration) * 100;
        progressFill.style.width = pct + '%';
        if (progress) {
          progress.setAttribute('aria-valuenow', Math.round(pct).toString());
        }
      }
    });

    // ── Loaded metadata → show duration ─────────────────────────────────────
    audio.addEventListener('loadedmetadata', function () {
      if (durationEl) {
        durationEl.textContent = formatTime(audio.duration);
      }
    });

    // ── Track ended ─────────────────────────────────────────────────────────
    audio.addEventListener('ended', function () {
      // Loop is handled natively by the <audio loop> attribute.
      if (!loop) {
        if (progressFill) progressFill.style.width = '0%';
        if (currentTime) currentTime.textContent = '00:00';
        if (progress) progress.setAttribute('aria-valuenow', '0');
      }
    });

    // ── Seek on progress bar click ───────────────────────────────────────────
    if (progress) {
      function seekFromEvent(e) {
        if (!audio.duration) return;
        var rect    = progress.getBoundingClientRect();
        var clientX = e.touches ? e.touches[0].clientX : e.clientX;
        var percent = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        audio.currentTime = percent * audio.duration;
      }

      var seeking = false;
      progress.addEventListener('mousedown', function (e) {
        seeking = true;
        seekFromEvent(e);
      });
      document.addEventListener('mousemove', function (e) {
        if (seeking) seekFromEvent(e);
      });
      document.addEventListener('mouseup', function () { seeking = false; });

      // Touch.
      progress.addEventListener('touchstart', function (e) {
        seeking = true;
        seekFromEvent(e);
      }, { passive: true });
      document.addEventListener('touchmove', function (e) {
        if (seeking) seekFromEvent(e);
      }, { passive: true });
      document.addEventListener('touchend', function () { seeking = false; });

      // Keyboard: arrow keys nudge.
      progress.addEventListener('keydown', function (e) {
        if (!audio.duration) return;
        if (e.key === 'ArrowRight') {
          audio.currentTime = Math.min(audio.duration, audio.currentTime + 5);
        } else if (e.key === 'ArrowLeft') {
          audio.currentTime = Math.max(0, audio.currentTime - 5);
        }
      });
    }

    // ── Mute toggle ─────────────────────────────────────────────────────────
    if (muteBtn) {
      muteBtn.addEventListener('click', function () {
        audio.muted = !audio.muted;
        syncMuteUI();
      });
    }

    // ── Volume bar click / drag ──────────────────────────────────────────────
    if (volumeBar) {
      function setVolumeFromEvent(e) {
        var rect      = volumeBar.getBoundingClientRect();
        var clientX   = e.touches ? e.touches[0].clientX : e.clientX;
        var newVolume = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        audio.volume  = newVolume;
        audio.muted   = newVolume === 0;
        savedVolume   = newVolume > 0 ? newVolume : savedVolume;

        syncMuteUI();
        volumeBar.setAttribute('aria-valuenow', Math.round(newVolume * 100).toString());
      }

      var volumeDragging = false;
      volumeBar.addEventListener('mousedown', function (e) {
        volumeDragging = true;
        setVolumeFromEvent(e);
      });
      document.addEventListener('mousemove', function (e) {
        if (volumeDragging) setVolumeFromEvent(e);
      });
      document.addEventListener('mouseup', function () { volumeDragging = false; });

      volumeBar.addEventListener('touchstart', function (e) {
        volumeDragging = true;
        setVolumeFromEvent(e);
      }, { passive: true });
      document.addEventListener('touchmove', function (e) {
        if (volumeDragging) setVolumeFromEvent(e);
      }, { passive: true });
      document.addEventListener('touchend', function () { volumeDragging = false; });

      // Keyboard.
      volumeBar.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') {
          audio.volume = Math.min(1, audio.volume + 0.05);
          audio.muted  = false;
          if (volumeFill) volumeFill.style.width = (audio.volume * 100) + '%';
        } else if (e.key === 'ArrowLeft') {
          audio.volume = Math.max(0, audio.volume - 0.05);
          audio.muted  = audio.volume === 0;
          if (volumeFill) volumeFill.style.width = (audio.volume * 100) + '%';
        }
      });
    }
  }

  /**
   * Initialize all audio players on the page.
   */
  function initAll() {
    var containers = document.querySelectorAll('.dnxte-next-audio-container');
    containers.forEach(function (c) { initAudioPlayer(c); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

})();
