(function(global) {
  'use strict';

  var CURSOR_EFFECTS = [
    'circle-follower','dot-ring','magnetic','text-cursor','spotlight',
    'particle-trail','emoji','stretch','blend-mode','morph',
    'glitch','ripple-click','arrow','bubble','multi-ring'
  ];
  var TRAIL_EFFECTS = [
    'trail-dot','trail-line','trail-neon','trail-rainbow','trail-particles',
    'trail-geometric','trail-spotlight','trail-comet','trail-bubbles','trail-stars',
    'trail-smoke','trail-electric','trail-dna','trail-confetti','trail-ink',
    'trail-fire','trail-snow','trail-magnetic','trail-glitch','trail-pixel'
  ];
  var IMAGE_EFFECTS = [
    'img-fade','img-scale','img-float','img-spiral','img-bounce',
    'img-blur','img-slide','img-3d-flip','img-stagger','img-gravity',
    'img-zoom-rotate','img-scatter','img-polaroid','img-circle','img-glitch'
  ];

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function dist(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
  }

  function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  }

  function randomRange(min, max) {
    return min + Math.random() * (max - min);
  }

  function hslToRgba(h, s, l, a) {
    h = h % 360;
    s /= 100;
    l /= 100;
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs((h / 60) % 2 - 1));
    var m = l - c / 2;
    var r, g, b;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return 'rgba(' + Math.round((r + m) * 255) + ',' + Math.round((g + m) * 255) + ',' + Math.round((b + m) * 255) + ',' + a + ')';
  }

  function drawStar(ctx, cx, cy, spikes, outerR, innerR) {
    var rot = Math.PI / 2 * 3;
    var step = Math.PI / spikes;
    ctx.beginPath();
    ctx.moveTo(cx, cy - outerR);
    for (var i = 0; i < spikes; i++) {
      ctx.lineTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
      rot += step;
      ctx.lineTo(cx + Math.cos(rot) * innerR, cy + Math.sin(rot) * innerR);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerR);
    ctx.closePath();
  }

  function drawPolygon(ctx, cx, cy, sides, radius, rotation) {
    ctx.beginPath();
    for (var i = 0; i <= sides; i++) {
      var angle = (i * 2 * Math.PI / sides) + rotation;
      var x = cx + radius * Math.cos(angle);
      var y = cy + radius * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  // ─── Main Class ────────────────────────────────────────────────────
  function DnxteCursorEffects(element, options) {
    this.el = element;
    this._destroyed = false;
    this._rafId = null;
    this._listeners = [];
    this._domEls = [];
    this._tweens = [];
    this._canvas = null;
    this._ctx = null;
    this._container = null;
    this._trailPoints = [];
    this._particles = [];
    this._imgIndex = 0;
    this._lastImgX = 0;
    this._lastImgY = 0;

    // Mouse state
    this._mx = 0;
    this._my = 0;
    this._cx = 0;
    this._cy = 0;
    this._vx = 0;
    this._vy = 0;
    this._prevMx = 0;
    this._prevMy = 0;
    this._localX = 0;
    this._localY = 0;

    // Parse data attributes
    var d = element.dataset;
    var defaults = {
      type: 'circle-follower',
      color1: '#00d4aa',
      color2: '#7c3aed',
      size: 30,
      speed: 0.3,
      trailLength: 25,
      fadeMs: 800,
      imageUrls: [],
      imageSize: 100,
      imageThreshold: 60,
      cursorText: 'HELLO'
    };

    var parsed = {
      type: d.cursorType || (options && options.type) || defaults.type,
      cursorText: d.cursorText || (options && options.cursorText) || defaults.cursorText,
      color1: d.cursorColor1 || (options && options.color1) || defaults.color1,
      color2: d.cursorColor2 || (options && options.color2) || defaults.color2,
      size: parseFloat(d.cursorSize || (options && options.size) || defaults.size),
      speed: parseFloat(d.cursorSpeed || (options && options.speed) || defaults.speed),
      trailLength: parseInt(d.cursorTrailLength || (options && options.trailLength) || defaults.trailLength, 10),
      fadeMs: parseInt(d.cursorFadeMs || (options && options.fadeMs) || defaults.fadeMs, 10),
      imageUrls: d.cursorImages ? d.cursorImages.split(',').map(function(s) { return s.trim(); }) : (options && options.imageUrls) || defaults.imageUrls,
      imageSize: parseFloat(d.cursorImageSize || (options && options.imageSize) || defaults.imageSize),
      imageThreshold: parseFloat(d.cursorImageThreshold || (options && options.imageThreshold) || defaults.imageThreshold)
    };

    this.opts = parsed;
    this._speed = clamp(parsed.speed, 0.05, 1);

    // Determine category
    var type = this.opts.type;
    if (CURSOR_EFFECTS.indexOf(type) !== -1) {
      this._category = 'cursor';
    } else if (TRAIL_EFFECTS.indexOf(type) !== -1) {
      this._category = 'trail';
    } else if (IMAGE_EFFECTS.indexOf(type) !== -1) {
      this._category = 'image';
    } else {
      this._category = 'cursor';
      this.opts.type = 'circle-follower';
    }

    this._setup();
  }

  var proto = DnxteCursorEffects.prototype;

  // ─── Helpers ───────────────────────────────────────────────────────
  proto._on = function(target, event, fn) {
    target.addEventListener(event, fn);
    this._listeners.push({ target: target, event: event, fn: fn });
  };

  proto._createEl = function(tag, styles, parent) {
    var el = document.createElement(tag);
    if (styles) Object.assign(el.style, styles);
    // For cursor effects, use cursor container (inside section).
    // For trail/image, parent is explicitly passed.
    var target = parent || (this._cursorContainer || this.el);
    target.appendChild(el);
    this._domEls.push(el);
    return el;
  };

  proto._startRaf = function(fn) {
    var self = this;
    function loop() {
      if (self._destroyed) return;
      fn();
      self._rafId = requestAnimationFrame(loop);
    }
    self._rafId = requestAnimationFrame(loop);
  };

  // ─── Setup ─────────────────────────────────────────────────────────
  proto._setup = function() {
    var self = this;
    this._mouseInSection = false;

    // Ensure section is positioned for absolute cursor elements
    var pos = getComputedStyle(this.el).position;
    if (pos === 'static') this.el.style.position = 'relative';
    this.el.style.overflow = 'hidden';

    if (this._category === 'cursor') {
      // Setup cursor container inside section (not document.body)
      this._cursorContainer = this._createEl('div', {
        position: 'absolute',
        top: '0', left: '0', right: '0', bottom: '0',
        pointerEvents: 'none',
        zIndex: '9999',
        overflow: 'visible'
      }, this.el);

      this.el.style.cursor = 'none';

      // Track mouse relative to section
      this._on(this.el, 'mousemove', function(e) {
        var rect = self.el.getBoundingClientRect();
        self._prevMx = self._mx;
        self._prevMy = self._my;
        self._mx = e.clientX - rect.left;
        self._my = e.clientY - rect.top;
        self._vx = self._mx - self._prevMx;
        self._vy = self._my - self._prevMy;
        self._mouseInSection = true;
      });
      this._on(this.el, 'mouseenter', function() {
        self._mouseInSection = true;
        self._domEls.forEach(function(el) {
          if (el !== self._cursorContainer) el.style.opacity = '1';
        });
      });
      this._on(this.el, 'mouseleave', function() {
        self._mouseInSection = false;
        self._domEls.forEach(function(el) {
          if (el !== self._cursorContainer) el.style.opacity = '0';
        });
      });
      this._cx = 0;
      this._cy = 0;
    } else if (this._category === 'trail') {
      this._setupCanvas();
      this._on(this.el, 'mousemove', function(e) {
        var rect = self.el.getBoundingClientRect();
        self._prevMx = self._localX;
        self._prevMy = self._localY;
        self._localX = e.clientX - rect.left;
        self._localY = e.clientY - rect.top;
        self._vx = self._localX - self._prevMx;
        self._vy = self._localY - self._prevMy;
        self._mouseInSection = true;
      });
      this._on(this.el, 'mouseleave', function() {
        self._mouseInSection = false;
      });
    } else if (this._category === 'image') {
      this._setupImageContainer();
      this._on(this.el, 'mousemove', function(e) {
        var rect = self.el.getBoundingClientRect();
        self._localX = e.clientX - rect.left;
        self._localY = e.clientY - rect.top;
        self._mouseInSection = true;
      });
      this._on(this.el, 'mouseleave', function() {
        self._mouseInSection = false;
      });
    }

    // Init specific effect
    var method = '_init' + this.opts.type.replace(/-([a-z])/g, function(m, c) { return c.toUpperCase(); }).replace(/^(.)/, function(m) { return m.toUpperCase(); });
    if (typeof this[method] === 'function') {
      this[method]();
    }

    // For cursor effects: hide all cursor DOM elements initially (show on mouseenter)
    if (this._category === 'cursor') {
      this._domEls.forEach(function(el) {
        if (el !== self._cursorContainer) {
          el.style.opacity = '0';
          el.style.transition = 'opacity 0.15s';
        }
      });
    }
  };

  proto._setupCanvas = function() {
    var pos = getComputedStyle(this.el).position;
    if (pos === 'static') this.el.style.position = 'relative';
    this._canvas = this._createEl('canvas', {
      position: 'absolute',
      top: '0', left: '0', width: '100%', height: '100%',
      pointerEvents: 'none',
      zIndex: '5'
    }, this.el);
    this._ctx = this._canvas.getContext('2d');
    this._resizeCanvas();
    var self = this;
    this._on(window, 'resize', function() { self._resizeCanvas(); });
  };

  proto._resizeCanvas = function() {
    if (!this._canvas) return;
    this._canvas.width = this.el.offsetWidth;
    this._canvas.height = this.el.offsetHeight;
  };

  proto._setupImageContainer = function() {
    var pos = getComputedStyle(this.el).position;
    if (pos === 'static') this.el.style.position = 'relative';
    this._container = this._createEl('div', {
      position: 'absolute',
      top: '0', left: '0', right: '0', bottom: '0',
      overflow: 'hidden',
      pointerEvents: 'none',
      zIndex: '5'
    }, this.el);
  };

  proto._spawnImage = function(x, y, animateFn) {
    if (this._destroyed) return;
    var urls = this.opts.imageUrls;
    if (!urls || urls.length === 0) return;
    var d = dist(x, y, this._lastImgX, this._lastImgY);
    if (d < this.opts.imageThreshold) return;
    this._lastImgX = x;
    this._lastImgY = y;
    var url = urls[this._imgIndex % urls.length];
    this._imgIndex++;
    var sz = this.opts.imageSize;
    var img = document.createElement('div');
    img.style.cssText = 'position:absolute;width:' + sz + 'px;height:' + sz + 'px;' +
      'background-image:url(' + url + ');background-size:cover;background-position:center;' +
      'left:' + (x - sz / 2) + 'px;top:' + (y - sz / 2) + 'px;pointer-events:none;will-change:transform,opacity;';
    this._container.appendChild(img);
    this._domEls.push(img);
    animateFn(img, sz);
  };

  // ═══════════════════════════════════════════════════════════════════
  // CURSOR EFFECTS (1-15)
  // ═══════════════════════════════════════════════════════════════════

  // 1. circle-follower
  proto._initCircleFollower = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      border: '2px solid ' + this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      transition: 'width 0.2s, height 0.2s'
    });
    var self = this;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 2. dot-ring
  proto._initDotRing = function() {
    var s = this.opts.size;
    var dot = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: '6px', height: '6px',
      background: this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '10000',
      transform: 'translate(-50%, -50%)'
    });
    var ring = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      border: '2px solid ' + this.opts.color2,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)'
    });
    var rx = 0, ry = 0;
    var self = this;
    this._startRaf(function() {
      gsap.set(dot, { x: self._mx, y: self._my });
      rx = lerp(rx, self._mx, self._speed * 0.5);
      ry = lerp(ry, self._my, self._speed * 0.5);
      gsap.set(ring, { x: rx, y: ry });
    });
  };

  // 3. magnetic
  proto._initMagnetic = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      border: '2px solid ' + this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      transition: 'width 0.3s, height 0.3s, border-color 0.3s'
    });
    var self = this;
    var targetX = 0, targetY = 0;
    this._startRaf(function() {
      targetX = self._mx;
      targetY = self._my;
      var magneticEls = self.el.querySelectorAll('.magnetic-target');
      var snapped = false;
      magneticEls.forEach(function(el) {
        var rect = el.getBoundingClientRect();
        var cx = rect.left + rect.width / 2;
        var cy = rect.top + rect.height / 2;
        var d = dist(self._mx, self._my, cx, cy);
        if (d < 80) {
          targetX = cx;
          targetY = cy;
          snapped = true;
          cursor.style.width = (s * 1.5) + 'px';
          cursor.style.height = (s * 1.5) + 'px';
          cursor.style.borderColor = self.opts.color2;
        }
      });
      if (!snapped) {
        cursor.style.width = s + 'px';
        cursor.style.height = s + 'px';
        cursor.style.borderColor = self.opts.color1;
      }
      self._cx = lerp(self._cx, targetX, self._speed);
      self._cy = lerp(self._cy, targetY, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 4. text-cursor
  proto._initTextCursor = function() {
    var text = (this.opts.cursorText || 'HELLO') + ' \u2022 ' + (this.opts.cursorText || 'HELLO') + ' \u2022 ';
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: '80px', height: '80px',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)'
    });
    var svgNS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('viewBox', '0 0 80 80');
    svg.setAttribute('width', '80');
    svg.setAttribute('height', '80');
    svg.style.overflow = 'visible';
    var defs = document.createElementNS(svgNS, 'defs');
    var path = document.createElementNS(svgNS, 'path');
    path.setAttribute('id', 'dnxte-cursor-text-path');
    path.setAttribute('d', 'M 40,40 m -30,0 a 30,30 0 1,1 60,0 a 30,30 0 1,1 -60,0');
    defs.appendChild(path);
    svg.appendChild(defs);
    var textEl = document.createElementNS(svgNS, 'text');
    textEl.setAttribute('fill', this.opts.color1);
    textEl.setAttribute('font-size', '10');
    textEl.setAttribute('font-family', 'sans-serif');
    textEl.setAttribute('font-weight', 'bold');
    var tp = document.createElementNS(svgNS, 'textPath');
    tp.setAttribute('href', '#dnxte-cursor-text-path');
    tp.textContent = text;
    textEl.appendChild(tp);
    svg.appendChild(textEl);
    cursor.appendChild(svg);
    var rot = 0;
    var self = this;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      rot += 1;
      gsap.set(cursor, { x: self._cx, y: self._cy, rotation: rot });
    });
  };

  // 5. spotlight
  proto._initSpotlight = function() {
    var s = Math.max(this.opts.size * 8, 200);
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(255,255,255,0.5) 0%, transparent 70%)',
      pointerEvents: 'none',
      zIndex: '9999',
      mixBlendMode: 'overlay',
      transform: 'translate(-50%, -50%)'
    });
    var self = this;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 6. particle-trail
  proto._initParticleTrail = function() {
    var self = this;
    var particles = [];
    this._on(document, 'mousemove', function() {
      for (var i = 0; i < 2; i++) {
        var sz = randomRange(4, self.opts.size * 0.5);
        var p = self._createEl('div', {
          position: 'absolute', top: '0', left: '0',
          width: sz + 'px', height: sz + 'px',
          background: Math.random() > 0.5 ? self.opts.color1 : self.opts.color2,
          borderRadius: '50%',
          pointerEvents: 'none',
          zIndex: '9999'
        });
        gsap.set(p, { x: self._mx + randomRange(-10, 10), y: self._my + randomRange(-10, 10) });
        gsap.to(p, {
          x: self._mx + randomRange(-60, 60),
          y: self._my + randomRange(-60, 60),
          opacity: 0,
          scale: 0,
          duration: self.opts.fadeMs / 1000,
          ease: 'power2.out',
          onComplete: function() {
            if (p.parentNode) p.parentNode.removeChild(p);
            var idx = self._domEls.indexOf(p);
            if (idx > -1) self._domEls.splice(idx, 1);
          }
        });
      }
    });
  };

  // 7. emoji
  proto._initEmoji = function() {
    var currentEmoji = '✌️';
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      fontSize: this.opts.size + 'px',
      lineHeight: '1',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      userSelect: 'none'
    });
    cursor.textContent = currentEmoji;
    var self = this;
    var targets = this.el.querySelectorAll('.emoji-target[data-emoji]');
    targets.forEach(function(t) {
      self._on(t, 'mouseenter', function() {
        currentEmoji = t.dataset.emoji || '✌️';
        cursor.textContent = currentEmoji;
        gsap.fromTo(cursor, { scale: 1.4 }, { scale: 1, duration: 0.3 });
      });
    });
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 8. stretch
  proto._initStretch = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      background: this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)'
    });
    var self = this;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      var speed = Math.sqrt(self._vx * self._vx + self._vy * self._vy);
      var angle = Math.atan2(self._vy, self._vx) * (180 / Math.PI);
      var stretchX = 1 + clamp(speed * 0.02, 0, 0.8);
      var stretchY = 1 - clamp(speed * 0.01, 0, 0.3);
      gsap.set(cursor, {
        x: self._cx, y: self._cy,
        scaleX: stretchX, scaleY: stretchY,
        rotation: angle
      });
    });
  };

  // 9. blend-mode
  proto._initBlendMode = function() {
    var s = Math.max(this.opts.size * 2, 40);
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      background: '#ffffff',
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      mixBlendMode: 'difference',
      transform: 'translate(-50%, -50%)'
    });
    var self = this;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 10. morph
  proto._initMorph = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      background: this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      transition: 'border-radius 0.4s, clip-path 0.4s'
    });
    var self = this;
    var targets = this.el.querySelectorAll('.morph-target[data-shape]');
    targets.forEach(function(t) {
      self._on(t, 'mouseenter', function() {
        var shape = t.dataset.shape;
        if (shape === 'square') {
          cursor.style.borderRadius = '4px';
          cursor.style.clipPath = 'none';
        } else if (shape === 'triangle') {
          cursor.style.borderRadius = '0';
          cursor.style.clipPath = 'polygon(50% 0%, 0% 100%, 100% 100%)';
        } else if (shape === 'star') {
          cursor.style.borderRadius = '0';
          cursor.style.clipPath = 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)';
        }
      });
      self._on(t, 'mouseleave', function() {
        cursor.style.borderRadius = '50%';
        cursor.style.clipPath = 'none';
      });
    });
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 11. glitch
  proto._initGlitch = function() {
    var s = this.opts.size;
    var base = {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      mixBlendMode: 'screen'
    };
    var white = this._createEl('div', Object.assign({}, base, { background: 'rgba(255,255,255,0.8)' }));
    var red = this._createEl('div', Object.assign({}, base, { background: 'rgba(255,0,0,0.5)' }));
    var blue = this._createEl('div', Object.assign({}, base, { background: 'rgba(0,100,255,0.5)' }));
    var self = this;
    var jitterTimer = 0;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      jitterTimer++;
      var jx = (jitterTimer % 3 === 0) ? randomRange(-4, 4) : 0;
      var jy = (jitterTimer % 5 === 0) ? randomRange(-4, 4) : 0;
      gsap.set(white, { x: self._cx, y: self._cy });
      gsap.set(red, { x: self._cx + jx + 3, y: self._cy + jy - 1 });
      gsap.set(blue, { x: self._cx - jx - 3, y: self._cy - jy + 1 });
    });
  };

  // 12. ripple-click
  proto._initRippleClick = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      border: '2px solid ' + this.opts.color1,
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)'
    });
    var self = this;
    this._on(this.el, 'click', function(e) {
      for (var i = 0; i < 3; i++) {
        (function(delay) {
          var ripple = self._createEl('div', {
            position: 'absolute', top: '0', left: '0',
            width: s + 'px', height: s + 'px',
            border: '2px solid ' + self.opts.color2,
            borderRadius: '50%',
            pointerEvents: 'none',
            zIndex: '9998',
            transform: 'translate(-50%, -50%)'
          });
          gsap.set(ripple, { x: e.clientX, y: e.clientY });
          gsap.fromTo(ripple, { scale: 1, opacity: 1 }, {
            scale: 3 + i, opacity: 0,
            duration: 0.8,
            delay: delay,
            ease: 'power2.out',
            onComplete: function() {
              if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
              var idx = self._domEls.indexOf(ripple);
              if (idx > -1) self._domEls.splice(idx, 1);
            }
          });
        })(i * 0.12);
      }
    });
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      gsap.set(cursor, { x: self._cx, y: self._cy });
    });
  };

  // 13. arrow
  proto._initArrow = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      fontSize: s + 'px',
      color: this.opts.color1,
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      lineHeight: '1',
      userSelect: 'none'
    });
    cursor.textContent = '→';
    var self = this;
    var angle = 0;
    this._startRaf(function() {
      self._cx = lerp(self._cx, self._mx, self._speed);
      self._cy = lerp(self._cy, self._my, self._speed);
      var speed = Math.sqrt(self._vx * self._vx + self._vy * self._vy);
      if (speed > 1) {
        angle = Math.atan2(self._vy, self._vx) * (180 / Math.PI);
      }
      gsap.set(cursor, { x: self._cx, y: self._cy, rotation: angle });
    });
  };

  // 14. bubble
  proto._initBubble = function() {
    var s = this.opts.size;
    var cursor = this._createEl('div', {
      position: 'absolute', top: '0', left: '0',
      width: s + 'px', height: s + 'px',
      background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.4), ' + this.opts.color1 + ')',
      borderRadius: '50%',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      boxShadow: 'inset 0 -4px 8px rgba(0,0,0,0.2), 0 2px 12px rgba(0,0,0,0.15)'
    });
    var self = this;
    var bx = 0, by = 0, bvx = 0, bvy = 0;
    this._startRaf(function() {
      var dx = self._mx - bx;
      var dy = self._my - by;
      bvx += dx * 0.08;
      bvy += dy * 0.08;
      bvx *= 0.75;
      bvy *= 0.75;
      bx += bvx;
      by += bvy;
      var speed = Math.sqrt(bvx * bvx + bvy * bvy);
      var squishX = 1 + clamp(speed * 0.008, 0, 0.35);
      var squishY = 1 - clamp(speed * 0.005, 0, 0.2);
      var angle = Math.atan2(bvy, bvx) * (180 / Math.PI);
      gsap.set(cursor, {
        x: bx, y: by,
        scaleX: squishX, scaleY: squishY,
        rotation: angle
      });
    });
  };

  // 15. multi-ring
  proto._initMultiRing = function() {
    var s = this.opts.size;
    var colors = [this.opts.color1, this.opts.color2, this.opts.color1];
    var sizes = [s, s * 1.6, s * 2.2];
    var speeds = [this._speed, this._speed * 0.6, this._speed * 0.3];
    var rings = [];
    var positions = [];
    for (var i = 0; i < 3; i++) {
      var ring = this._createEl('div', {
        position: 'absolute', top: '0', left: '0',
        width: sizes[i] + 'px', height: sizes[i] + 'px',
        border: '2px solid ' + colors[i],
        borderRadius: '50%',
        pointerEvents: 'none',
        zIndex: String(9999 - i),
        transform: 'translate(-50%, -50%)',
        opacity: String(1 - i * 0.2)
      });
      rings.push(ring);
      positions.push({ x: 0, y: 0 });
    }
    var self = this;
    var rot = 0;
    this._startRaf(function() {
      rot += 0.5;
      for (var i = 0; i < 3; i++) {
        positions[i].x = lerp(positions[i].x, self._mx, speeds[i]);
        positions[i].y = lerp(positions[i].y, self._my, speeds[i]);
        var r = (i % 2 === 0) ? rot : -rot;
        gsap.set(rings[i], {
          x: positions[i].x, y: positions[i].y,
          rotation: r * (i + 1)
        });
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════════
  // TRAIL EFFECTS (16-35)
  // ═══════════════════════════════════════════════════════════════════

  // 16. trail-dot
  proto._initTrailDot = function() {
    var self = this;
    var points = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, alpha: 1 });
      if (points.length > self.opts.trailLength) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      var w = self._canvas.width;
      var h = self._canvas.height;
      ctx.clearRect(0, 0, w, h);
      for (var i = 0; i < points.length; i++) {
        var p = points[i];
        p.alpha -= 1 / (self.opts.fadeMs / 16);
        if (p.alpha <= 0) { points.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, self.opts.size * 0.3 * p.alpha, 0, Math.PI * 2);
        ctx.fillStyle = self.opts.color1;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    });
  };

  // 17. trail-line
  proto._initTrailLine = function() {
    var self = this;
    var points = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, alpha: 1 });
      if (points.length > self.opts.trailLength) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      if (points.length < 2) return;
      for (var i = 0; i < points.length; i++) {
        points[i].alpha -= 1 / (self.opts.fadeMs / 16);
        if (points[i].alpha <= 0) { points.splice(i, 1); i--; }
      }
      if (points.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (var i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      ctx.strokeStyle = self.opts.color1;
      ctx.lineWidth = self.opts.size * 0.15;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = points[points.length - 1].alpha;
      ctx.stroke();
      ctx.globalAlpha = 1;
    });
  };

  // 18. trail-neon
  proto._initTrailNeon = function() {
    var self = this;
    var points = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, alpha: 1 });
      if (points.length > self.opts.trailLength) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < points.length; i++) {
        points[i].alpha -= 1 / (self.opts.fadeMs / 16);
        if (points[i].alpha <= 0) { points.splice(i, 1); i--; }
      }
      if (points.length < 2) return;
      // Outer glow
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (var i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      ctx.strokeStyle = self.opts.color1;
      ctx.lineWidth = self.opts.size * 0.4;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = 0.3;
      ctx.shadowBlur = 20;
      ctx.shadowColor = self.opts.color1;
      ctx.stroke();
      // Inner core
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (var i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = self.opts.size * 0.1;
      ctx.globalAlpha = 0.9;
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#ffffff';
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    });
  };

  // 19. trail-rainbow
  proto._initTrailRainbow = function() {
    var self = this;
    var points = [];
    var hue = 0;
    this._on(this.el, 'mousemove', function() {
      hue = (hue + 3) % 360;
      points.push({ x: self._localX, y: self._localY, alpha: 1, hue: hue });
      if (points.length > self.opts.trailLength) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < points.length; i++) {
        points[i].alpha -= 1 / (self.opts.fadeMs / 16);
        if (points[i].alpha <= 0) { points.splice(i, 1); i--; continue; }
        var p = points[i];
        ctx.beginPath();
        ctx.arc(p.x, p.y, self.opts.size * 0.25 * p.alpha, 0, Math.PI * 2);
        ctx.fillStyle = hslToRgba(p.hue, 90, 55, p.alpha);
        ctx.fill();
      }
    });
  };

  // 20. trail-particles
  proto._initTrailParticles = function() {
    var self = this;
    var particles = [];
    this._on(this.el, 'mousemove', function() {
      for (var i = 0; i < 3; i++) {
        var angle = Math.random() * Math.PI * 2;
        var speed = randomRange(1, 4);
        particles.push({
          x: self._localX, y: self._localY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 1,
          alpha: 1,
          size: randomRange(2, self.opts.size * 0.3),
          color: Math.random() > 0.5 ? self.opts.color1 : self.opts.color2
        });
      }
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.1; // gravity
        p.alpha -= 0.02;
        if (p.alpha <= 0) { particles.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * p.alpha, 0, Math.PI * 2);
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (particles.length > 300) particles.splice(0, particles.length - 300);
    });
  };

  // 21. trail-geometric
  proto._initTrailGeometric = function() {
    var self = this;
    var shapes = [];
    var shapeTypes = ['triangle', 'square', 'hexagon', 'diamond'];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 3 !== 0) return;
      shapes.push({
        x: self._localX, y: self._localY,
        alpha: 1,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: randomRange(-0.05, 0.05),
        size: randomRange(self.opts.size * 0.2, self.opts.size * 0.5),
        type: shapeTypes[Math.floor(Math.random() * shapeTypes.length)],
        color: Math.random() > 0.5 ? self.opts.color1 : self.opts.color2
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < shapes.length; i++) {
        var s = shapes[i];
        s.alpha -= 1 / (self.opts.fadeMs / 16);
        s.rotation += s.rotSpeed;
        if (s.alpha <= 0) { shapes.splice(i, 1); i--; continue; }
        ctx.save();
        ctx.globalAlpha = s.alpha;
        ctx.fillStyle = s.color;
        ctx.translate(s.x, s.y);
        ctx.rotate(s.rotation);
        var r = s.size;
        if (s.type === 'triangle') {
          drawPolygon(ctx, 0, 0, 3, r, -Math.PI / 2);
        } else if (s.type === 'square') {
          ctx.fillRect(-r / 2, -r / 2, r, r);
          ctx.restore();
          continue;
        } else if (s.type === 'hexagon') {
          drawPolygon(ctx, 0, 0, 6, r, 0);
        } else if (s.type === 'diamond') {
          drawPolygon(ctx, 0, 0, 4, r, 0);
        }
        ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      if (shapes.length > 200) shapes.splice(0, shapes.length - 200);
    });
  };

  // 22. trail-spotlight
  proto._initTrailSpotlight = function() {
    var self = this;
    var cx = 0, cy = 0;
    this._startRaf(function() {
      cx = lerp(cx, self._localX, self._speed);
      cy = lerp(cy, self._localY, self._speed);
      var ctx = self._ctx;
      var w = self._canvas.width;
      var h = self._canvas.height;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = 'rgba(0,0,0,0.85)';
      ctx.fillRect(0, 0, w, h);
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      var radius = self.opts.size * 4;
      var grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
      grad.addColorStop(0, 'rgba(0,0,0,1)');
      grad.addColorStop(0.7, 'rgba(0,0,0,0.8)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  };

  // 23. trail-comet
  proto._initTrailComet = function() {
    var self = this;
    var points = [];
    var sparks = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, alpha: 1 });
      if (points.length > self.opts.trailLength) points.shift();
      // Sparks
      if (Math.random() > 0.5) {
        sparks.push({
          x: self._localX, y: self._localY,
          vx: randomRange(-2, 2), vy: randomRange(-2, 2),
          alpha: 1, size: randomRange(1, 3)
        });
      }
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      // Tail
      for (var i = 0; i < points.length; i++) {
        points[i].alpha -= 1 / (self.opts.fadeMs / 16);
        if (points[i].alpha <= 0) { points.splice(i, 1); i--; continue; }
        var p = points[i];
        var r = self.opts.size * 0.3 * p.alpha;
        var grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        grad.addColorStop(0, 'rgba(255,200,50,' + p.alpha + ')');
        grad.addColorStop(0.5, 'rgba(255,100,20,' + (p.alpha * 0.6) + ')');
        grad.addColorStop(1, 'rgba(255,50,0,0)');
        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      }
      // Head
      if (points.length > 0) {
        var head = points[points.length - 1];
        var hr = self.opts.size * 0.5;
        var hg = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, hr);
        hg.addColorStop(0, 'rgba(255,255,220,1)');
        hg.addColorStop(0.4, 'rgba(255,200,50,0.8)');
        hg.addColorStop(1, 'rgba(255,100,20,0)');
        ctx.beginPath();
        ctx.arc(head.x, head.y, hr, 0, Math.PI * 2);
        ctx.fillStyle = hg;
        ctx.fill();
      }
      // Sparks
      for (var i = 0; i < sparks.length; i++) {
        var s = sparks[i];
        s.x += s.vx;
        s.y += s.vy;
        s.alpha -= 0.03;
        if (s.alpha <= 0) { sparks.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,220,100,' + s.alpha + ')';
        ctx.fill();
      }
      if (sparks.length > 150) sparks.splice(0, sparks.length - 150);
    });
  };

  // 24. trail-bubbles
  proto._initTrailBubbles = function() {
    var self = this;
    var bubbles = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 3 !== 0) return;
      bubbles.push({
        x: self._localX + randomRange(-10, 10),
        y: self._localY,
        alpha: 1,
        size: randomRange(self.opts.size * 0.15, self.opts.size * 0.4),
        vx: randomRange(-0.5, 0.5),
        vy: randomRange(-1.5, -0.5)
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < bubbles.length; i++) {
        var b = bubbles[i];
        b.x += b.vx;
        b.y += b.vy;
        b.alpha -= 0.01;
        if (b.alpha <= 0) { bubbles.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
        ctx.strokeStyle = self.opts.color1;
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = b.alpha;
        ctx.stroke();
        // Highlight
        ctx.beginPath();
        ctx.arc(b.x - b.size * 0.25, b.y - b.size * 0.25, b.size * 0.2, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (bubbles.length > 200) bubbles.splice(0, bubbles.length - 200);
    });
  };

  // 25. trail-stars
  proto._initTrailStars = function() {
    var self = this;
    var stars = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 2 !== 0) return;
      stars.push({
        x: self._localX + randomRange(-15, 15),
        y: self._localY + randomRange(-15, 15),
        alpha: 1,
        size: randomRange(self.opts.size * 0.1, self.opts.size * 0.35),
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: randomRange(-0.05, 0.05),
        twinkle: Math.random() * Math.PI
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < stars.length; i++) {
        var s = stars[i];
        s.alpha -= 1 / (self.opts.fadeMs / 16);
        s.rotation += s.rotSpeed;
        s.twinkle += 0.1;
        if (s.alpha <= 0) { stars.splice(i, 1); i--; continue; }
        ctx.save();
        ctx.translate(s.x, s.y);
        ctx.rotate(s.rotation);
        ctx.globalAlpha = s.alpha * (0.6 + 0.4 * Math.sin(s.twinkle));
        ctx.fillStyle = Math.random() > 0.5 ? self.opts.color1 : self.opts.color2;
        drawStar(ctx, 0, 0, 5, s.size, s.size * 0.4);
        ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      if (stars.length > 200) stars.splice(0, stars.length - 200);
    });
  };

  // 26. trail-smoke
  proto._initTrailSmoke = function() {
    var self = this;
    var puffs = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 3 !== 0) return;
      puffs.push({
        x: self._localX + randomRange(-5, 5),
        y: self._localY,
        alpha: 0.6,
        size: randomRange(self.opts.size * 0.2, self.opts.size * 0.4),
        vx: randomRange(-0.3, 0.3),
        vy: randomRange(-1.2, -0.3),
        growth: randomRange(0.3, 0.8)
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < puffs.length; i++) {
        var p = puffs[i];
        p.x += p.vx;
        p.y += p.vy;
        p.size += p.growth;
        p.alpha -= 0.008;
        if (p.alpha <= 0) { puffs.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(150,150,150,' + p.alpha + ')';
        ctx.fill();
      }
      if (puffs.length > 200) puffs.splice(0, puffs.length - 200);
    });
  };

  // 27. trail-electric
  proto._initTrailElectric = function() {
    var self = this;
    var points = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, alpha: 1 });
      if (points.length > self.opts.trailLength) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < points.length; i++) {
        points[i].alpha -= 1 / (self.opts.fadeMs / 16);
        if (points[i].alpha <= 0) { points.splice(i, 1); i--; }
      }
      if (points.length < 2) return;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.shadowBlur = 8;
      ctx.shadowColor = self.opts.color1;
      for (var i = 1; i < points.length; i++) {
        var a = points[i - 1];
        var b = points[i];
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        // Zigzag midpoints
        var midX = (a.x + b.x) / 2 + randomRange(-12, 12);
        var midY = (a.y + b.y) / 2 + randomRange(-12, 12);
        ctx.lineTo(midX, midY);
        ctx.lineTo(b.x, b.y);
        ctx.strokeStyle = self.opts.color1;
        ctx.globalAlpha = b.alpha;
        ctx.stroke();
        // Branch
        if (Math.random() > 0.7) {
          ctx.beginPath();
          ctx.moveTo(midX, midY);
          ctx.lineTo(midX + randomRange(-20, 20), midY + randomRange(-20, 20));
          ctx.globalAlpha = b.alpha * 0.4;
          ctx.strokeStyle = self.opts.color2;
          ctx.stroke();
        }
      }
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    });
  };

  // 28. trail-dna
  proto._initTrailDna = function() {
    var self = this;
    var points = [];
    this._on(this.el, 'mousemove', function() {
      points.push({ x: self._localX, y: self._localY, t: Date.now() });
      if (points.length > self.opts.trailLength * 2) points.shift();
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      var now = Date.now();
      // Prune
      while (points.length > 0 && (now - points[0].t) > self.opts.fadeMs) {
        points.shift();
      }
      if (points.length < 2) return;
      for (var i = 0; i < points.length; i++) {
        var p = points[i];
        var age = (now - p.t) / self.opts.fadeMs;
        var alpha = 1 - age;
        var offset = Math.sin(i * 0.3) * self.opts.size;
        var x1 = p.x + offset;
        var y1 = p.y;
        var x2 = p.x - offset;
        var y2 = p.y;
        // Strand 1
        ctx.beginPath();
        ctx.arc(x1, y1, 3, 0, Math.PI * 2);
        ctx.fillStyle = self.opts.color1;
        ctx.globalAlpha = alpha;
        ctx.fill();
        // Strand 2
        ctx.beginPath();
        ctx.arc(x2, y2, 3, 0, Math.PI * 2);
        ctx.fillStyle = self.opts.color2;
        ctx.fill();
        // Connector every few points
        if (i % 4 === 0) {
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.4) + ')';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
    });
  };

  // 29. trail-confetti
  proto._initTrailConfetti = function() {
    var self = this;
    var confetti = [];
    var colors = [self.opts.color1, self.opts.color2, '#ff6b6b', '#ffd93d', '#6bcb77', '#4d96ff'];
    this._on(this.el, 'mousemove', function() {
      confetti.push({
        x: self._localX, y: self._localY,
        vx: randomRange(-3, 3),
        vy: randomRange(-4, 0),
        alpha: 1,
        w: randomRange(4, 10),
        h: randomRange(6, 14),
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: randomRange(-0.15, 0.15),
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < confetti.length; i++) {
        var c = confetti[i];
        c.x += c.vx;
        c.y += c.vy;
        c.vy += 0.15; // gravity
        c.vx *= 0.98;
        c.rotation += c.rotSpeed;
        c.alpha -= 0.012;
        if (c.alpha <= 0) { confetti.splice(i, 1); i--; continue; }
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.rotate(c.rotation);
        ctx.globalAlpha = c.alpha;
        ctx.fillStyle = c.color;
        ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h);
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      if (confetti.length > 300) confetti.splice(0, confetti.length - 300);
    });
  };

  // 30. trail-ink
  proto._initTrailInk = function() {
    var self = this;
    var blobs = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 2 !== 0) return;
      var count = Math.floor(randomRange(1, 4));
      for (var j = 0; j < count; j++) {
        blobs.push({
          x: self._localX + randomRange(-8, 8),
          y: self._localY + randomRange(-8, 8),
          alpha: randomRange(0.3, 0.7),
          size: randomRange(self.opts.size * 0.1, self.opts.size * 0.5),
          growth: randomRange(0.2, 0.8)
        });
      }
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < blobs.length; i++) {
        var b = blobs[i];
        b.size += b.growth;
        b.growth *= 0.96;
        b.alpha -= 0.008;
        if (b.alpha <= 0) { blobs.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
        ctx.fillStyle = self.opts.color1;
        ctx.globalAlpha = b.alpha;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (blobs.length > 300) blobs.splice(0, blobs.length - 300);
    });
  };

  // 31. trail-fire
  proto._initTrailFire = function() {
    var self = this;
    var flames = [];
    this._on(this.el, 'mousemove', function() {
      for (var i = 0; i < 3; i++) {
        flames.push({
          x: self._localX + randomRange(-5, 5),
          y: self._localY,
          vx: randomRange(-0.8, 0.8),
          vy: randomRange(-3, -1),
          alpha: 1,
          size: randomRange(self.opts.size * 0.15, self.opts.size * 0.45)
        });
      }
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < flames.length; i++) {
        var f = flames[i];
        f.x += f.vx;
        f.y += f.vy;
        f.size *= 0.97;
        f.alpha -= 0.025;
        if (f.alpha <= 0 || f.size < 0.5) { flames.splice(i, 1); i--; continue; }
        var grad = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.size);
        grad.addColorStop(0, 'rgba(255,255,100,' + f.alpha + ')');
        grad.addColorStop(0.4, 'rgba(255,180,30,' + (f.alpha * 0.8) + ')');
        grad.addColorStop(1, 'rgba(255,80,0,0)');
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.size, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      }
      if (flames.length > 300) flames.splice(0, flames.length - 300);
    });
  };

  // 32. trail-snow
  proto._initTrailSnow = function() {
    var self = this;
    var flakes = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 3 !== 0) return;
      flakes.push({
        x: self._localX + randomRange(-15, 15),
        y: self._localY,
        alpha: 1,
        size: randomRange(self.opts.size * 0.08, self.opts.size * 0.25),
        vy: randomRange(0.5, 2),
        wobble: Math.random() * Math.PI * 2,
        wobbleSpeed: randomRange(0.02, 0.08),
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: randomRange(-0.03, 0.03)
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < flakes.length; i++) {
        var f = flakes[i];
        f.wobble += f.wobbleSpeed;
        f.x += Math.sin(f.wobble) * 0.8;
        f.y += f.vy;
        f.rotation += f.rotSpeed;
        f.alpha -= 0.005;
        if (f.alpha <= 0 || f.y > self._canvas.height + 10) { flakes.splice(i, 1); i--; continue; }
        ctx.save();
        ctx.translate(f.x, f.y);
        ctx.rotate(f.rotation);
        ctx.globalAlpha = f.alpha;
        // Draw snowflake (6-point star)
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        for (var j = 0; j < 6; j++) {
          var angle = (j / 6) * Math.PI * 2;
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(Math.cos(angle) * f.size, Math.sin(angle) * f.size);
          ctx.stroke();
          // Branch
          var bx = Math.cos(angle) * f.size * 0.6;
          var by = Math.sin(angle) * f.size * 0.6;
          ctx.beginPath();
          ctx.moveTo(bx, by);
          ctx.lineTo(bx + Math.cos(angle + 0.5) * f.size * 0.3, by + Math.sin(angle + 0.5) * f.size * 0.3);
          ctx.stroke();
        }
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      if (flakes.length > 200) flakes.splice(0, flakes.length - 200);
    });
  };

  // 33. trail-magnetic
  proto._initTrailMagnetic = function() {
    var self = this;
    var orbiters = [];
    this._on(this.el, 'mousemove', function() {
      if (orbiters.length < 60) {
        orbiters.push({
          x: self._localX + randomRange(-30, 30),
          y: self._localY + randomRange(-30, 30),
          angle: Math.random() * Math.PI * 2,
          radius: randomRange(20, self.opts.size * 2),
          speed: randomRange(0.02, 0.08),
          size: randomRange(2, self.opts.size * 0.2),
          alpha: 1,
          color: Math.random() > 0.5 ? self.opts.color1 : self.opts.color2
        });
      }
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < orbiters.length; i++) {
        var o = orbiters[i];
        o.angle += o.speed;
        // Move orbit center toward cursor
        var tx = self._localX + Math.cos(o.angle) * o.radius;
        var ty = self._localY + Math.sin(o.angle) * o.radius;
        o.x = lerp(o.x, tx, 0.1);
        o.y = lerp(o.y, ty, 0.1);
        o.alpha -= 0.003;
        if (o.alpha <= 0) { orbiters.splice(i, 1); i--; continue; }
        ctx.beginPath();
        ctx.arc(o.x, o.y, o.size, 0, Math.PI * 2);
        ctx.fillStyle = o.color;
        ctx.globalAlpha = o.alpha;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    });
  };

  // 34. trail-glitch
  proto._initTrailGlitch = function() {
    var self = this;
    var blocks = [];
    var spawnCounter = 0;
    this._on(this.el, 'mousemove', function() {
      spawnCounter++;
      if (spawnCounter % 2 !== 0) return;
      var sz = randomRange(self.opts.size * 0.3, self.opts.size);
      blocks.push({
        x: self._localX + randomRange(-10, 10), y: self._localY + randomRange(-10, 10),
        w: sz, h: randomRange(3, sz * 0.4),
        alpha: 1, type: 'white'
      });
      blocks.push({
        x: self._localX + randomRange(2, 8), y: self._localY + randomRange(-3, 3),
        w: sz * 0.8, h: randomRange(2, sz * 0.3),
        alpha: 0.6, type: 'red'
      });
      blocks.push({
        x: self._localX + randomRange(-8, -2), y: self._localY + randomRange(-3, 3),
        w: sz * 0.8, h: randomRange(2, sz * 0.3),
        alpha: 0.6, type: 'blue'
      });
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      for (var i = 0; i < blocks.length; i++) {
        var b = blocks[i];
        b.alpha -= 0.04;
        if (b.alpha <= 0) { blocks.splice(i, 1); i--; continue; }
        ctx.globalAlpha = b.alpha;
        if (b.type === 'white') ctx.fillStyle = 'rgba(255,255,255,0.9)';
        else if (b.type === 'red') ctx.fillStyle = 'rgba(255,0,0,0.7)';
        else ctx.fillStyle = 'rgba(0,100,255,0.7)';
        ctx.fillRect(b.x - b.w / 2, b.y - b.h / 2, b.w, b.h);
      }
      ctx.globalAlpha = 1;
      if (blocks.length > 300) blocks.splice(0, blocks.length - 300);
    });
  };

  // 35. trail-pixel
  proto._initTrailPixel = function() {
    var self = this;
    var pixels = {};
    var gridSize = Math.max(Math.floor(self.opts.size * 0.4), 6);
    this._on(this.el, 'mousemove', function() {
      var gx = Math.floor(self._localX / gridSize) * gridSize;
      var gy = Math.floor(self._localY / gridSize) * gridSize;
      var key = gx + '_' + gy;
      pixels[key] = { x: gx, y: gy, alpha: 1, color: Math.random() > 0.5 ? self.opts.color1 : self.opts.color2 };
    });
    this._startRaf(function() {
      var ctx = self._ctx;
      ctx.clearRect(0, 0, self._canvas.width, self._canvas.height);
      var keys = Object.keys(pixels);
      for (var i = 0; i < keys.length; i++) {
        var p = pixels[keys[i]];
        p.alpha -= 1 / (self.opts.fadeMs / 16);
        if (p.alpha <= 0) { delete pixels[keys[i]]; continue; }
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, gridSize - 1, gridSize - 1);
      }
      ctx.globalAlpha = 1;
    });
  };

  // ═══════════════════════════════════════════════════════════════════
  // IMAGE TRAIL EFFECTS (36-50)
  // ═══════════════════════════════════════════════════════════════════

  // 36. img-fade
  proto._initImgFade = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.set(img, { opacity: 1, scale: 1 });
        gsap.to(img, {
          opacity: 0, scale: 0.6,
          duration: self.opts.fadeMs / 1000,
          ease: 'power2.out',
          onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
        });
      });
    });
  };

  // 37. img-scale
  proto._initImgScale = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.fromTo(img,
          { opacity: 1, scale: 0.5 },
          {
            opacity: 0, scale: 2,
            duration: self.opts.fadeMs / 1000,
            ease: 'power1.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 38. img-float
  proto._initImgFloat = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.fromTo(img,
          { opacity: 1, y: 0 },
          {
            opacity: 0, y: -80,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 39. img-spiral
  proto._initImgSpiral = function() {
    var self = this;
    var angle = 0;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        angle += 0.8;
        var radius = 100;
        gsap.fromTo(img,
          { opacity: 1, scale: 1, x: 0, y: 0, rotation: 0 },
          {
            opacity: 0, scale: 0.3,
            x: Math.cos(angle) * radius,
            y: Math.sin(angle) * radius,
            rotation: 360,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 40. img-bounce
  proto._initImgBounce = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.fromTo(img,
          { opacity: 0, scale: 0 },
          {
            opacity: 1, scale: 1,
            duration: 0.4,
            ease: 'elastic.out(1, 0.4)',
            onComplete: function() {
              gsap.to(img, {
                opacity: 0, scale: 0,
                duration: 0.4,
                delay: 0.2,
                ease: 'elastic.in(1, 0.4)',
                onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
              });
            }
          }
        );
      });
    });
  };

  // 41. img-blur
  proto._initImgBlur = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.fromTo(img,
          { opacity: 1, scale: 1 },
          {
            opacity: 0, scale: 1.1,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.out',
            onUpdate: function() {
              var progress = this.progress();
              img.style.filter = 'blur(' + (progress * 15) + 'px)';
            },
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 42. img-slide
  proto._initImgSlide = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        var angle = Math.random() * Math.PI * 2;
        var distance = randomRange(60, 150);
        gsap.fromTo(img,
          { opacity: 1, x: 0, y: 0 },
          {
            opacity: 0,
            x: Math.cos(angle) * distance,
            y: Math.sin(angle) * distance,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 43. img-3d-flip
  proto._initImg3dFlip = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        img.style.transformStyle = 'preserve-3d';
        img.style.perspective = '600px';
        gsap.fromTo(img,
          { opacity: 1, rotationY: 0 },
          {
            opacity: 0, rotationY: 180,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.inOut',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 44. img-stagger
  proto._initImgStagger = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      var d = dist(self._localX, self._localY, self._lastImgX, self._lastImgY);
      if (d < self.opts.imageThreshold) return;
      self._lastImgX = self._localX;
      self._lastImgY = self._localY;
      var urls = self.opts.imageUrls;
      if (!urls || urls.length === 0) return;
      var url = urls[self._imgIndex % urls.length];
      self._imgIndex++;
      var sz = self.opts.imageSize * 0.5;
      for (var i = 0; i < 3; i++) {
        (function(idx) {
          var clone = document.createElement('div');
          clone.style.cssText = 'position:absolute;width:' + sz + 'px;height:' + sz + 'px;' +
            'background-image:url(' + url + ');background-size:cover;background-position:center;' +
            'left:' + (self._localX - sz / 2) + 'px;top:' + (self._localY - sz / 2) + 'px;' +
            'pointer-events:none;will-change:transform,opacity;';
          self._container.appendChild(clone);
          self._domEls.push(clone);
          var angle = (idx / 3) * Math.PI * 2 + Math.random();
          gsap.fromTo(clone,
            { opacity: 0, scale: 0 },
            {
              opacity: 1, scale: 1,
              x: Math.cos(angle) * 40,
              y: Math.sin(angle) * 40,
              duration: 0.3,
              delay: idx * 0.08,
              ease: 'back.out(1.7)',
              onComplete: function() {
                gsap.to(clone, {
                  opacity: 0, scale: 0.3,
                  duration: 0.4,
                  delay: 0.2,
                  onComplete: function() { if (clone.parentNode) clone.parentNode.removeChild(clone); }
                });
              }
            }
          );
        })(i);
      }
    });
  };

  // 45. img-gravity
  proto._initImgGravity = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        var vx = randomRange(-2, 2);
        gsap.to(img, {
          y: self._canvas ? self._canvas.height : 500,
          x: vx * 80,
          rotation: randomRange(-180, 180),
          opacity: 0,
          duration: self.opts.fadeMs / 1000 * 1.5,
          ease: 'power1.in',
          onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
        });
      });
    });
  };

  // 46. img-zoom-rotate
  proto._initImgZoomRotate = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        gsap.fromTo(img,
          { opacity: 1, scale: 0.3, rotation: 0 },
          {
            opacity: 0, scale: 1.8, rotation: 360,
            duration: self.opts.fadeMs / 1000,
            ease: 'power2.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 47. img-scatter
  proto._initImgScatter = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        img.style.boxShadow = '0 4px 20px rgba(0,0,0,0.3)';
        img.style.borderRadius = '4px';
        var angle = Math.random() * Math.PI * 2;
        var distance = randomRange(50, 150);
        gsap.fromTo(img,
          { opacity: 1, scale: 0.8, rotation: randomRange(-15, 15) },
          {
            opacity: 0,
            x: Math.cos(angle) * distance,
            y: Math.sin(angle) * distance,
            rotation: randomRange(-45, 45),
            scale: 0.5,
            duration: self.opts.fadeMs / 1000,
            ease: 'power3.out',
            onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
          }
        );
      });
    });
  };

  // 48. img-polaroid
  proto._initImgPolaroid = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      var d = dist(self._localX, self._localY, self._lastImgX, self._lastImgY);
      if (d < self.opts.imageThreshold) return;
      self._lastImgX = self._localX;
      self._lastImgY = self._localY;
      var urls = self.opts.imageUrls;
      if (!urls || urls.length === 0) return;
      var url = urls[self._imgIndex % urls.length];
      self._imgIndex++;
      var sz = self.opts.imageSize;
      var pad = 8;
      var padBottom = 30;
      var wrapper = document.createElement('div');
      wrapper.style.cssText = 'position:absolute;' +
        'width:' + (sz + pad * 2) + 'px;height:' + (sz + pad + padBottom) + 'px;' +
        'left:' + (self._localX - (sz + pad * 2) / 2) + 'px;' +
        'top:' + (self._localY - (sz + pad + padBottom) / 2) + 'px;' +
        'background:#fff;padding:' + pad + 'px;padding-bottom:' + padBottom + 'px;' +
        'box-shadow:0 4px 15px rgba(0,0,0,0.25);pointer-events:none;will-change:transform,opacity;';
      var inner = document.createElement('div');
      inner.style.cssText = 'width:100%;height:' + sz + 'px;background-image:url(' + url + ');' +
        'background-size:cover;background-position:center;';
      wrapper.appendChild(inner);
      self._container.appendChild(wrapper);
      self._domEls.push(wrapper);
      var tilt = randomRange(-20, 20);
      gsap.fromTo(wrapper,
        { opacity: 0, scale: 0.5, rotation: tilt - 10 },
        {
          opacity: 1, scale: 1, rotation: tilt,
          duration: 0.4,
          ease: 'back.out(1.7)',
          onComplete: function() {
            gsap.to(wrapper, {
              opacity: 0, y: -30,
              duration: self.opts.fadeMs / 1000,
              delay: 0.3,
              ease: 'power2.in',
              onComplete: function() { if (wrapper.parentNode) wrapper.parentNode.removeChild(wrapper); }
            });
          }
        }
      );
    });
  };

  // 49. img-circle
  proto._initImgCircle = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      self._spawnImage(self._localX, self._localY, function(img) {
        img.style.borderRadius = '50%';
        img.style.clipPath = 'circle(0% at center)';
        gsap.to(img, {
          clipPath: 'circle(50% at center)',
          duration: 0.4,
          ease: 'power2.out',
          onComplete: function() {
            gsap.to(img, {
              scale: 1.5, opacity: 0,
              duration: self.opts.fadeMs / 1000 * 0.7,
              ease: 'power2.in',
              onComplete: function() { if (img.parentNode) img.parentNode.removeChild(img); }
            });
          }
        });
      });
    });
  };

  // 50. img-glitch
  proto._initImgGlitch = function() {
    var self = this;
    this._on(this.el, 'mousemove', function() {
      var d = dist(self._localX, self._localY, self._lastImgX, self._lastImgY);
      if (d < self.opts.imageThreshold) return;
      self._lastImgX = self._localX;
      self._lastImgY = self._localY;
      var urls = self.opts.imageUrls;
      if (!urls || urls.length === 0) return;
      var url = urls[self._imgIndex % urls.length];
      self._imgIndex++;
      var sz = self.opts.imageSize;
      var offsets = [
        { dx: 0, dy: 0, color: 'none', opacity: 1 },
        { dx: 5, dy: -3, color: 'rgba(255,0,0,0.6)', opacity: 0.7 },
        { dx: -5, dy: 3, color: 'rgba(0,100,255,0.6)', opacity: 0.7 }
      ];
      var els = [];
      for (var i = 0; i < offsets.length; i++) {
        (function(o, idx) {
          var el = document.createElement('div');
          el.style.cssText = 'position:absolute;width:' + sz + 'px;height:' + sz + 'px;' +
            'background-image:url(' + url + ');background-size:cover;background-position:center;' +
            'left:' + (self._localX - sz / 2 + o.dx) + 'px;' +
            'top:' + (self._localY - sz / 2 + o.dy) + 'px;' +
            'pointer-events:none;will-change:transform,opacity;' +
            'mix-blend-mode:' + (idx === 0 ? 'normal' : 'screen') + ';' +
            'opacity:' + o.opacity + ';';
          if (o.color !== 'none') {
            el.style.backgroundColor = o.color;
            el.style.backgroundBlendMode = 'multiply';
          }
          self._container.appendChild(el);
          self._domEls.push(el);
          els.push(el);
          gsap.to(el, {
            opacity: 0,
            x: idx === 0 ? 0 : randomRange(-10, 10),
            duration: self.opts.fadeMs / 1000,
            delay: 0.05,
            ease: 'power2.out',
            onComplete: function() { if (el.parentNode) el.parentNode.removeChild(el); }
          });
        })(offsets[i], i);
      }
    });
  };

  // ═══════════════════════════════════════════════════════════════════
  // DESTROY
  // ═══════════════════════════════════════════════════════════════════
  proto.destroy = function() {
    this._destroyed = true;
    if (this._rafId) cancelAnimationFrame(this._rafId);

    // Remove event listeners
    for (var i = 0; i < this._listeners.length; i++) {
      var l = this._listeners[i];
      l.target.removeEventListener(l.event, l.fn);
    }
    this._listeners = [];

    // Kill GSAP tweens and remove DOM elements
    for (var i = 0; i < this._domEls.length; i++) {
      gsap.killTweensOf(this._domEls[i]);
      if (this._domEls[i].parentNode) {
        this._domEls[i].parentNode.removeChild(this._domEls[i]);
      }
    }
    this._domEls = [];

    // Clear canvas
    if (this._canvas && this._ctx) {
      this._ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
    }

    // Restore cursor
    if (this._category === 'cursor') {
      this.el.style.cursor = '';
    }

    this._trailPoints = [];
    this._particles = [];
  };

  // ─── Auto-init ─────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-cursor-type]').forEach(function(el) {
      el._dnxteCursor = new DnxteCursorEffects(el, {});
    });
  });

  global.DnxteCursorEffects = DnxteCursorEffects;
})(window);
