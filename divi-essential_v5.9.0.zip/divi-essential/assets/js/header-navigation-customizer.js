(function ($) {
  function applyBoxSpacing(selector, spacing, type = "padding") {
    const elements = document.querySelectorAll(selector);
    if (!elements.length) return;

    const sides = ["top", "right", "bottom", "left"];

    elements.forEach((el) => {
      sides.forEach((side) => {
        const prop = spacing[side];
        const cssProp = `${type}-${side}`;
        el.style.removeProperty(cssProp); // Clear old

        if (prop) {
          el.style.setProperty(
            cssProp,
            prop + (hasUnit(prop) ? "" : "px"),
            "important"
          );
        }
      });
    });
  }
  function applyMarginToElements(selector, margin, direction = "right") {
    const elements = document.querySelectorAll(selector);
    if (!elements.length) return;

    elements.forEach((el, index) => {
      const isLast = index === elements.length - 1;
      const prop = `margin-${direction}`;
      el.style.removeProperty(prop);

      if (!isLast && margin !== undefined) {
        el.style.setProperty(
          prop,
          margin + (hasUnit(margin) ? "" : "px"),
          "important"
        );
      } else if (isLast) {
        el.style.setProperty(prop, "0px", "important");
      }
    });
  }

  function hasUnit(value) {
    return /[a-z%]+$/i.test(value);
  }

  // write all commented code in the above format menually
  wp.customize("dnxte_cta_font_select", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.fontFamily = newval + ", sans-serif";
    });
  });
  wp.customize("dnxte_cta_font_size", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.fontSize = newval + "px";
    });
  });
  wp.customize("dnxte_cta_font_weight", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.fontWeight = newval;
    });
  });
  wp.customize("dnxte_cta_letter_spaciong", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.letterSpacing = newval + "px";
    });
  });
  wp.customize("dnxte_cta_font_style_transform", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.fontStyle = newval;
    });
  });
  wp.customize("dnxte_cta_text_color", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.color = newval;
    });
  });
  wp.customize("dnxte_cta_text_color_hover", function (value) {
    value.bind(function (newval) {
      document
        .querySelector(
          "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
        )
        .style.setProperty("--dnxte_cta_text_color_hover", newval);
    });
  });

  wp.customize("dnxte_icon_setting", function (value) {
    const iconPosition = wp.customize("dnxte_icon_position").get();
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-icon"
      ).innerHTML = newval;
    });
  });
  wp.customize("dnxte_cta_icon_color", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-icon"
      ).style.color = newval;
    });
  });
  wp.customize("dnxte_cta_icon_size", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-icon"
      ).style.fontSize = newval + "px";
    });
  });
  wp.customize("dnxte_cta_icon_gap", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.gap = newval + "px";
    });
  });
  wp.customize("dnxte_icon_position", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.flexDirection = newval;
    });
  });
  wp.customize("dnxte_button_background_color", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.background = newval;
    });
  });
  wp.customize("dnxte_button_background_color_hover", function (value) {
    value.bind(function (newval) {
      document
        .querySelector(
          "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
        )
        .style.setProperty("--dnxte_button_background_color_hover", newval);
    });
  });
  wp.customize("dnxte_cta_button_border_width", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.borderWidth = newval + "px";
    });
  });
  wp.customize("dnxte_cta_button_border_radius", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.borderRadius = newval + "px";
    });
  });
  wp.customize("dnxte_button_border_color", function (value) {
    value.bind(function (newval) {
      document.querySelector(
        "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
      ).style.borderColor = newval;
    });
  });
  wp.customize("dnxte_button_border_color_hover", function (value) {
    value.bind(function (newval) {
      document
        .querySelector(
          "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
        )
        .style.setProperty("--dnxte_button_border_color_hover", newval);
    });
  });
  wp.customize("dnxte_cta_btn_shadow", function (value) {
    value.bind(function (newval) {
      if (newval === true || newval === "1") {
        document.querySelector(
          "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
        ).style.boxShadow = "0 0px 10px rgba(0, 0, 0, 0.1)";
      } else {
        document.querySelector(
          "#main-header .dnxte-header-cta-btn-wrapper .dnxte-cta-btn"
        ).style.boxShadow = "none";
      }
    });
  });

  /**
   * Dropdown Menu Customizer
   */
  wp.customize("dnxte_dp_font_select_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty(
            "--dnxte_dp_font_select_dp",
            newval + ", sans-serif"
          );
        });
    });
  });
  wp.customize("dnxte_dp_font_size_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty("--dnxte_dp_font_size_dp", newval + "px");
        });
    });
  });
  wp.customize("dnxte_dp_font_weight_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty("--dnxte_dp_font_weight_dp", newval);
        });
    });
  });
  wp.customize("dnxte_dp_letter_spacing_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty("--dnxte_dp_letter_spacing_dp", newval + "px");
        });
    });
  });
  wp.customize("dnxte_dp_text_color_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty("--dnxte_dp_text_color_dp", newval);
        });
    });
  });
  wp.customize("dnxte_dp_text_color_hover_dp", function (value) {
    value.bind(function (newval) {
      document
        .querySelectorAll("#top-menu-nav > ul > li.menu-item ul.sub-menu li a")
        .forEach(function (el) {
          el.style.setProperty("--dnxte_dp_text_color_hover_dp", newval);
        });
    });
  });
  wp.customize("dnxte_dropdown_arrow_icon", function (value) {
    value.bind(function (newval) {
      document
        .querySelector("#top-menu-nav #top-menu .menu-item-has-children>a")
        .style.setProperty("--dnxte_dropdown_arrow_icon", newval);
    });
  });

  wp.customize("dnxte_hover_animated_color", function (value) {
    value.bind(function (newval) {     

      var hoverAnimationStyle =
        '<style id="dnxte-menu-hover-animation-style">' +
        ".dnxte-hover-hover_effect_border_oval #et-top-navigation ul>li:hover>a, " +
        ".dnxte-hover-hover_effect_brackets #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_brackets #et-top-navigation ul>li>a .dnxte-menu-item-animation:before, " +
        ".dnxte-hover-hover_effect_corner_in #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_corner_in #et-top-navigation ul>li>a .dnxte-menu-item-animation:before, " +
        ".dnxte-hover-hover_effect_borderbr #et-top-navigation ul>li>a:hover, " +
        ".dnxte-hover-hover_effect_slide_right #et-top-navigation ul>li>a { " +
        "border-color: " +
        newval +
        " !important; " +
        "}" +
        ".dnxte-hover-hover_effect_border_lr #et-top-navigation ul>li>a .dnxte-menu-item-animation:before{ " +
        "border-left-color: " +
        newval +
        " !important; " +
        "border-top-color: " +
        newval +
        " !important; " +
        "} " +
        ".dnxte-hover-hover_effect_border_lr #et-top-navigation ul>li>a .dnxte-menu-item-animation:after{ " +
        "border-right-color: " +
        newval +
        " !important; " +
        "border-bottom-color: " +
        newval +
        " !important; " +
        "} " +
        ".dnxte-hover-hover_effect_border_rl #et-top-navigation ul>li>a .dnxte-menu-item-animation:before{ " +
        "border-left-color: " +
        newval +
        " !important; " +
        "border-bottom-color: " +
        newval +
        " !important; " +
        "} " +
        ".dnxte-hover-hover_effect_border_rl #et-top-navigation ul>li>a .dnxte-menu-item-animation:after{ " +
        "border-right-color: " +
        newval +
        " !important; " +
        "border-top-color: " +
        newval +
        " !important; " +
        "} " +
        ".dnxte-hover-hover_effect_underline #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_revel_border #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_revel_border #et-top-navigation ul>li>a .dnxte-menu-item-animation:before, " +
        ".dnxte-hover-hover_effect_glow #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_slide_down #et-top-navigation ul>li>a .dnxte-menu-item-animation:hover:after," +
        ".dnxte-hover-hover_effect_slide_up #et-top-navigation ul>li>a .dnxte-menu-item-animation:hover:after," +
        ".dnxte-hover-hover_effect_slide_left #et-top-navigation ul>li>a .dnxte-menu-item-animation:hover:after," +
        ".dnxte-hover-hover_effect_slide_right #et-top-navigation ul>li>a .dnxte-menu-item-animation:hover:after," +
        ".dnxte-hover-hover_effect_fill_slide_up #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_fill_slide_down #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_fill_slide_left #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_fill_slide_right #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_slide_down #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_slide_up #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_slide_left #et-top-navigation ul>li>a .dnxte-menu-item-animation:after, " +
        ".dnxte-hover-hover_effect_slide_right #et-top-navigation ul>li>a .dnxte-menu-item-animation:after { " +
        "background: " +
        newval +
        " !important; " +
        "}" +
        ".dnxte-hover-hover_effect_border_lr #et-top-navigation ul>li>a .dnxte-menu-item-animation:before{ " +
        "background: linear-gradient(to top," + newval + ", transparent 30%); " +
        " !important; " +
        "} " +
        "</style>";

      $("head").append(hoverAnimationStyle);

    });
  });


  wp.customize("dnxte_header_shadow", function (toggleVal) {
    wp.customize("dnxte_header_shadow_color", function (colorVal) {
      wp.customize("dnxte_header_shadow_offset_x", function (offsetXVal) {
        wp.customize("dnxte_header_shadow_offset_y", function (offsetYVal) {
          wp.customize("dnxte_header_shadow_blur", function (blurVal) {
            wp.customize("dnxte_header_shadow_spread", function (spreadVal) {
              let header = null;

              function findHeader() {
                const selectors = [
                  "#main-header",
                  ".main-header",
                  "header",
                  ".site-header",
                  ".header",
                  "[role='banner']",
                ];

                for (const selector of selectors) {
                  const element = document.querySelector(selector);
                  if (element) return element;
                }
                return null;
              }

              function applyShadow() {
                if (!header) {
                  header = findHeader();
                }

                if (!header) {
                  console.warn("Header element still not found");
                  return;
                }

                const shadowEnabled = toggleVal.get();
                const color = colorVal.get();
                const x = parseInt(offsetXVal.get()) || 0;
                const y = parseInt(offsetYVal.get()) || 0;
                const blur = parseInt(blurVal.get()) || 0;
                const spread = parseInt(spreadVal.get()) || 0;

                if (shadowEnabled === true || shadowEnabled === "1") {
                  header.style.setProperty(
                    "box-shadow",
                    `${x}px ${y}px ${blur}px ${spread}px ${color}`,
                    "important"
                  );
                } else {
                  header.style.removeProperty("box-shadow");
                }
              }

              // Watch for DOM changes if header not immediately available
              function watchForHeader() {
                if (header) return;

                const observer = new MutationObserver((mutations) => {
                  header = findHeader();
                  if (header) {
                    observer.disconnect();
                    applyShadow();
                  }
                });

                observer.observe(document.body, {
                  childList: true,
                  subtree: true,
                });

                // Stop watching after 10 seconds
                setTimeout(() => {
                  observer.disconnect();
                }, 10000);
              }

              // Initial setup
              header = findHeader();
              if (!header) {
                watchForHeader();
              }

              // Bind all controls
              toggleVal.bind(applyShadow);
              colorVal.bind(applyShadow);
              offsetXVal.bind(applyShadow);
              offsetYVal.bind(applyShadow);
              blurVal.bind(applyShadow);
              spreadVal.bind(applyShadow);

              // Initial apply
              applyShadow();
            });
          });
        });
      });
    });
  });

  wp.customize("dnxte_header_shadow_fixed", function (toggleVal) {
    wp.customize("dnxte_header_shadow_color_fixed", function (colorVal) {
      wp.customize("dnxte_header_fixed_shadow_offset_x", function (offsetXVal) {
        wp.customize(
          "dnxte_header_fixed_shadow_offset_y",
          function (offsetYVal) {
            wp.customize("dnxte_header_fixed_shadow_blur", function (blurVal) {
              wp.customize(
                "dnxte_header_fixed_shadow_spread",
                function (spreadVal) {
                  function applyShadow() {
                    const shadowEnabled = toggleVal.get();
                    const color = colorVal.get();
                    const x = parseInt(offsetXVal.get()) || 0;
                    const y = parseInt(offsetYVal.get()) || 0;
                    const blur = parseInt(blurVal.get()) || 0;
                    const spread = parseInt(spreadVal.get()) || 0;

                    // Try multiple possible selectors for the fixed header
                    const fixedHeaderSelectors = [
                      "#main-header.et-fixed-header",
                      "#main-header.fixed",
                      ".main-header.et-fixed-header",
                      ".main-header.fixed",
                      "header.et-fixed-header",
                      "header.fixed",
                      ".site-header.et-fixed-header",
                      ".site-header.fixed",
                      ".header.et-fixed-header",
                      ".header.fixed",
                      "[role='banner'].et-fixed-header",
                      "[role='banner'].fixed",
                    ];

                    let header = null;
                    for (const selector of fixedHeaderSelectors) {
                      header = document.querySelector(selector);
                      if (header) break;
                    }

                    // If no fixed header found, exit gracefully
                    if (!header) {
                      return;
                    }

                    if (shadowEnabled === true || shadowEnabled === "1") {
                      header.style.setProperty(
                        "box-shadow",
                        `${x}px ${y}px ${blur}px ${spread}px ${color}`,
                        "important"
                      );
                    } else {
                      header.style.removeProperty("box-shadow");
                    }
                  }

                  // Function to wait for the fixed header class to be added
                  function waitForFixedHeader() {
                    const baseHeader =
                      document.querySelector("#main-header") ||
                      document.querySelector(".main-header") ||
                      document.querySelector("header");

                    if (!baseHeader) {
                      console.warn("Base header element not found");
                      return;
                    }

                    // Check if fixed class already exists
                    if (
                      baseHeader.classList.contains("et-fixed-header") ||
                      baseHeader.classList.contains("fixed")
                    ) {
                      applyShadow();
                      return;
                    }

                    // Watch for the fixed class to be added
                    const observer = new MutationObserver((mutations) => {
                      mutations.forEach((mutation) => {
                        if (
                          mutation.type === "attributes" &&
                          mutation.attributeName === "class"
                        ) {
                          if (
                            baseHeader.classList.contains("et-fixed-header") ||
                            baseHeader.classList.contains("fixed")
                          ) {
                            applyShadow();
                          }
                        }
                      });
                    });

                    observer.observe(baseHeader, {
                      attributes: true,
                      attributeFilter: ["class"],
                    });

                    // Also try applying immediately in case the class is already there
                    applyShadow();
                  }

                  // Wait for DOM to be ready
                  function initialize() {
                    if (document.readyState === "loading") {
                      document.addEventListener(
                        "DOMContentLoaded",
                        waitForFixedHeader
                      );
                    } else {
                      waitForFixedHeader();
                    }
                  }

                  // Bind all controls
                  toggleVal.bind(applyShadow);
                  colorVal.bind(applyShadow);
                  offsetXVal.bind(applyShadow);
                  offsetYVal.bind(applyShadow);
                  blurVal.bind(applyShadow);
                  spreadVal.bind(applyShadow);

                  // Initial setup
                  initialize();
                }
              );
            });
          }
        );
      });
    });
  });

  // cta button hover effect
  wp.customize("dnxte_button_hover_effect_select", function (value) {
    value.bind(function (newval) {
      const ctaBtn = document.querySelector(".dnxte-cta-btn");

      if (ctaBtn) {
        const hoverClasses = [
          "dnxt-hover-grow",
          "dnxt-hover-shrink",
          "dnxt-hover-pulse-shrink",
          "dnxt-hover-pulse",
          "dnxt-hover-pulse-grow",
          "dnxt-hover-push",
          "dnxt-hover-pop",
          "dnxt-hover-bounce-in",
          "dnxt-hover-bounce-out",
          "dnxt-hover-rotate",
          "dnxt-hover-grow-rotate",
          "dnxt-hover-float",
          "dnxt-hover-bob",
          "dnxt-hover-hang",
          "dnxt-hover-skew",
          "dnxt-hover-skew-forward",
          "dnxt-hover-skew-backward",
        ];

        hoverClasses.forEach((cls) => ctaBtn.classList.remove(cls));

        if (newval && newval !== "none") {
          ctaBtn.classList.add(newval);
        }
      }
    });
  });
  // primary menu hover thing
  wp.customize("dnxte_menu_hover_color", function (value) {
    value.bind(function (newval) {
      $("body #dnxte-menu-hover-style").remove();

      var hoverStyle =
        '<style id="dnxte-menu-hover-style">' +
        "body #top-menu-nav>ul>li>a:hover { " +
        "color: " +
        newval +
        " !important; " +
        "}" +
        "</style>";

      $("head").append(hoverStyle);
    });
  });
  wp.customize("dnxte_menu_hover_bg_color", function (value) {
    value.bind(function (newval) {
      //$("body #et-top-navigation ul>li>a").remove();

      var hoverBgStyle =
        '<style id="dnxte-menu-hover-bg-style">' +
        "body #et-top-navigation ul>li>a:hover { " +
        "background: " +
        newval +
        " !important; " +
        "}" +
        "</style>";

      $("head").append(hoverBgStyle);
    });
  });
  wp.customize("dnxte_menu_hover_color_fixed", function (value) {
    value.bind(function (newval) {
      $("body  #dnxte-menu-hover-style-fixed").remove();

      var hoverStyle =
        '<style id="dnxte-menu-hover-style-fixed">' +
        "body .et-fixed-header #top-menu-nav>ul>li>a:hover { " +
        "color: " +
        newval +
        " !important; " +
        "}" +
        "</style>";

      $("head").append(hoverStyle);
    });
  });
  // for menu item padding
  wp.customize("dnxte_padding", function (value) {
    value.bind(function (newVal) {
      try {
        const padding = JSON.parse(newVal);
        applyBoxSpacing("body #top-menu-nav > ul > li > a", padding, "padding");
      } catch (e) {
        console.warn("Invalid padding JSON", e);
      }
    });
  });
  wp.customize("dnxte_menu_item_space", function (value) {
    value.bind(function (newVal) {
      applyMarginToElements("#top-menu-nav > ul > li > a", newVal, "right");
    });
  });
  // cta padding
  wp.customize("dnxte_cta_button_padding", function (value) {
    value.bind(function (newVal) {
      try {
        const padding = JSON.parse(newVal);
        applyBoxSpacing(
          "body .dnxte-header-cta-btn-wrapper .dnxte-cta-btn",
          padding,
          "padding"
        );
      } catch (e) {
        console.warn("Invalid padding JSON", e);
      }
    });
  });
})(jQuery);
