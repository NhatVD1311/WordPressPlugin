/**
 * DNXTE — WhatsApp Chat floating widget (front-end).
 *
 * Vanilla JS, no jQuery. Powers popup open/close, the teaser bubble (+ unread
 * badge & Web Audio blip), the smart triggers (click / auto / scroll / exit-intent
 * / element), the pre-chat form, GDPR consent, agent routing (all / round-robin /
 * random), the offline desktop QR (real scannable matrix), per-agent
 * working-hours/countdown, analytics events, and click-time deep-link building
 * (so cached pages still resolve {page_title}/{page_url}). The link-building logic
 * mirrors src/components/ChatAgent/link-builder.ts and the PHP build_agent_link().
 */
(function () {
  'use strict';

  // ===========================================================================
  // Inlined QR encoder — "qrcode-generator" v1.4.4 by Kazuhiko Arase.
  // MIT License (http://www.opensource.org/licenses/mit-license.php).
  // Source: http://www.d-project.com/ — Terser-minified UMD build with the
  // module/AMD export tail removed so it stays local to this IIFE. It exposes a
  // single factory: dnxteQrFactory(typeNumber, errorCorrectionLevel).
  // "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
  // ===========================================================================
  var dnxteQrFactory = (function () {
    var qrcode=function(){var t=function(t,r){var e=t,n=g[r],o=null,i=0,a=null,u=[],f={},c=function(t,r){o=function(t){for(var r=new Array(t),e=0;e<t;e+=1){r[e]=new Array(t);for(var n=0;n<t;n+=1)r[e][n]=null}return r}(i=4*e+17),l(0,0),l(i-7,0),l(0,i-7),s(),h(),d(t,r),e>=7&&v(t),null==a&&(a=p(e,n,u)),w(a,r)},l=function(t,r){for(var e=-1;e<=7;e+=1)if(!(t+e<=-1||i<=t+e))for(var n=-1;n<=7;n+=1)r+n<=-1||i<=r+n||(o[t+e][r+n]=0<=e&&e<=6&&(0==n||6==n)||0<=n&&n<=6&&(0==e||6==e)||2<=e&&e<=4&&2<=n&&n<=4)},h=function(){for(var t=8;t<i-8;t+=1)null==o[t][6]&&(o[t][6]=t%2==0);for(var r=8;r<i-8;r+=1)null==o[6][r]&&(o[6][r]=r%2==0)},s=function(){for(var t=B.getPatternPosition(e),r=0;r<t.length;r+=1)for(var n=0;n<t.length;n+=1){var i=t[r],a=t[n];if(null==o[i][a])for(var u=-2;u<=2;u+=1)for(var f=-2;f<=2;f+=1)o[i+u][a+f]=-2==u||2==u||-2==f||2==f||0==u&&0==f}},v=function(t){for(var r=B.getBCHTypeNumber(e),n=0;n<18;n+=1){var a=!t&&1==(r>>n&1);o[Math.floor(n/3)][n%3+i-8-3]=a}for(n=0;n<18;n+=1){a=!t&&1==(r>>n&1);o[n%3+i-8-3][Math.floor(n/3)]=a}},d=function(t,r){for(var e=n<<3|r,a=B.getBCHTypeInfo(e),u=0;u<15;u+=1){var f=!t&&1==(a>>u&1);u<6?o[u][8]=f:u<8?o[u+1][8]=f:o[i-15+u][8]=f}for(u=0;u<15;u+=1){f=!t&&1==(a>>u&1);u<8?o[8][i-u-1]=f:u<9?o[8][15-u-1+1]=f:o[8][15-u-1]=f}o[i-8][8]=!t},w=function(t,r){for(var e=-1,n=i-1,a=7,u=0,f=B.getMaskFunction(r),c=i-1;c>0;c-=2)for(6==c&&(c-=1);;){for(var g=0;g<2;g+=1)if(null==o[n][c-g]){var l=!1;u<t.length&&(l=1==(t[u]>>>a&1)),f(n,c-g)&&(l=!l),o[n][c-g]=l,-1==(a-=1)&&(u+=1,a=7)}if((n+=e)<0||i<=n){n-=e,e=-e;break}}},p=function(t,r,e){for(var n=A.getRSBlocks(t,r),o=b(),i=0;i<e.length;i+=1){var a=e[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var u=0;for(i=0;i<n.length;i+=1)u+=n[i].dataCount;if(o.getLengthInBits()>8*u)throw"code length overflow. ("+o.getLengthInBits()+">"+8*u+")";for(o.getLengthInBits()+4<=8*u&&o.put(0,4);o.getLengthInBits()%8!=0;)o.putBit(!1);for(;!(o.getLengthInBits()>=8*u||(o.put(236,8),o.getLengthInBits()>=8*u));)o.put(17,8);return function(t,r){for(var e=0,n=0,o=0,i=new Array(r.length),a=new Array(r.length),u=0;u<r.length;u+=1){var f=r[u].dataCount,c=r[u].totalCount-f;n=Math.max(n,f),o=Math.max(o,c),i[u]=new Array(f);for(var g=0;g<i[u].length;g+=1)i[u][g]=255&t.getBuffer()[g+e];e+=f;var l=B.getErrorCorrectPolynomial(c),h=k(i[u],l.getLength()-1).mod(l);for(a[u]=new Array(l.getLength()-1),g=0;g<a[u].length;g+=1){var s=g+h.getLength()-a[u].length;a[u][g]=s>=0?h.getAt(s):0}}var v=0;for(g=0;g<r.length;g+=1)v+=r[g].totalCount;var d=new Array(v),w=0;for(g=0;g<n;g+=1)for(u=0;u<r.length;u+=1)g<i[u].length&&(d[w]=i[u][g],w+=1);for(g=0;g<o;g+=1)for(u=0;u<r.length;u+=1)g<a[u].length&&(d[w]=a[u][g],w+=1);return d}(o,n)};f.addData=function(t,r){var e=null;switch(r=r||"Byte"){case"Numeric":e=M(t);break;case"Alphanumeric":e=x(t);break;case"Byte":e=m(t);break;case"Kanji":e=L(t);break;default:throw"mode:"+r}u.push(e),a=null},f.isDark=function(t,r){if(t<0||i<=t||r<0||i<=r)throw t+","+r;return o[t][r]},f.getModuleCount=function(){return i},f.make=function(){if(e<1){for(var t=1;t<40;t++){for(var r=A.getRSBlocks(t,n),o=b(),i=0;i<u.length;i++){var a=u[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var g=0;for(i=0;i<r.length;i++)g+=r[i].dataCount;if(o.getLengthInBits()<=8*g)break}e=t}c(!1,function(){for(var t=0,r=0,e=0;e<8;e+=1){c(!0,e);var n=B.getLostPoint(f);(0==e||t>n)&&(t=n,r=e)}return r}())},f.createTableTag=function(t,r){t=t||2;var e="";e+='<table style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: "+(r=void 0===r?4*t:r)+"px;",e+='">',e+="<tbody>";for(var n=0;n<f.getModuleCount();n+=1){e+="<tr>";for(var o=0;o<f.getModuleCount();o+=1)e+='<td style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: 0px;",e+=" width: "+t+"px;",e+=" height: "+t+"px;",e+=" background-color: ",e+=f.isDark(n,o)?"#000000":"#ffffff",e+=";",e+='"/>';e+="</tr>"}return e+="</tbody>",e+="</table>"},f.createSvgTag=function(t,r,e,n){var o={};"object"==typeof arguments[0]&&(t=(o=arguments[0]).cellSize,r=o.margin,e=o.alt,n=o.title),t=t||2,r=void 0===r?4*t:r,(e="string"==typeof e?{text:e}:e||{}).text=e.text||null,e.id=e.text?e.id||"qrcode-description":null,(n="string"==typeof n?{text:n}:n||{}).text=n.text||null,n.id=n.text?n.id||"qrcode-title":null;var i,a,u,c,g=f.getModuleCount()*t+2*r,l="";for(c="l"+t+",0 0,"+t+" -"+t+",0 0,-"+t+"z ",l+='<svg version="1.1" xmlns="http://www.w3.org/2000/svg"',l+=o.scalable?"":' width="'+g+'px" height="'+g+'px"',l+=' viewBox="0 0 '+g+" "+g+'" ',l+=' preserveAspectRatio="xMinYMin meet"',l+=n.text||e.text?' role="img" aria-labelledby="'+y([n.id,e.id].join(" ").trim())+'"':"",l+=">",l+=n.text?'<title id="'+y(n.id)+'">'+y(n.text)+"</title>":"",l+=e.text?'<description id="'+y(e.id)+'">'+y(e.text)+"</description>":"",l+='<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>',l+='<path d="',a=0;a<f.getModuleCount();a+=1)for(u=a*t+r,i=0;i<f.getModuleCount();i+=1)f.isDark(a,i)&&(l+="M"+(i*t+r)+","+u+c);return l+='" stroke="transparent" fill="black"/>',l+="</svg>"},f.createDataURL=function(t,r){t=t||2,r=void 0===r?4*t:r;var e=f.getModuleCount()*t+2*r,n=r,o=e-r;return I(e,e,(function(r,e){if(n<=r&&r<o&&n<=e&&e<o){var i=Math.floor((r-n)/t),a=Math.floor((e-n)/t);return f.isDark(a,i)?0:1}return 1}))},f.createImgTag=function(t,r,e){t=t||2,r=void 0===r?4*t:r;var n=f.getModuleCount()*t+2*r,o="";return o+="<img",o+=' src="',o+=f.createDataURL(t,r),o+='"',o+=' width="',o+=n,o+='"',o+=' height="',o+=n,o+='"',e&&(o+=' alt="',o+=y(e),o+='"'),o+="/>"};var y=function(t){for(var r="",e=0;e<t.length;e+=1){var n=t.charAt(e);switch(n){case"<":r+="&lt;";break;case">":r+="&gt;";break;case"&":r+="&amp;";break;case'"':r+="&quot;";break;default:r+=n}}return r};return f.createASCII=function(t,r){if((t=t||1)<2)return function(t){t=void 0===t?2:t;var r,e,n,o,i,a=1*f.getModuleCount()+2*t,u=t,c=a-t,g={"██":"█","█ ":"▀"," █":"▄","  ":" "},l={"██":"▀","█ ":"▀"," █":" ","  ":" "},h="";for(r=0;r<a;r+=2){for(n=Math.floor((r-u)/1),o=Math.floor((r+1-u)/1),e=0;e<a;e+=1)i="█",u<=e&&e<c&&u<=r&&r<c&&f.isDark(n,Math.floor((e-u)/1))&&(i=" "),u<=e&&e<c&&u<=r+1&&r+1<c&&f.isDark(o,Math.floor((e-u)/1))?i+=" ":i+="█",h+=t<1&&r+1>=c?l[i]:g[i];h+="\n"}return a%2&&t>0?h.substring(0,h.length-a-1)+Array(a+1).join("▀"):h.substring(0,h.length-1)}(r);t-=1,r=void 0===r?2*t:r;var e,n,o,i,a=f.getModuleCount()*t+2*r,u=r,c=a-r,g=Array(t+1).join("██"),l=Array(t+1).join("  "),h="",s="";for(e=0;e<a;e+=1){for(o=Math.floor((e-u)/t),s="",n=0;n<a;n+=1)i=1,u<=n&&n<c&&u<=e&&e<c&&f.isDark(o,Math.floor((n-u)/t))&&(i=0),s+=i?g:l;for(o=0;o<t;o+=1)h+=s+"\n"}return h.substring(0,h.length-1)},f.renderTo2dContext=function(t,r){r=r||2;for(var e=f.getModuleCount(),n=0;n<e;n++)for(var o=0;o<e;o++)t.fillStyle=f.isDark(n,o)?"black":"white",t.fillRect(n*r,o*r,r,r)},f};t.stringToBytes=(t.stringToBytesFuncs={default:function(t){for(var r=[],e=0;e<t.length;e+=1){var n=t.charCodeAt(e);r.push(255&n)}return r}}).default,t.createStringToBytes=function(t,r){var e=function(){for(var e=S(t),n=function(){var t=e.read();if(-1==t)throw"eof";return t},o=0,i={};;){var a=e.read();if(-1==a)break;var u=n(),f=n()<<8|n();i[String.fromCharCode(a<<8|u)]=f,o+=1}if(o!=r)throw o+" != "+r;return i}(),n="?".charCodeAt(0);return function(t){for(var r=[],o=0;o<t.length;o+=1){var i=t.charCodeAt(o);if(i<128)r.push(i);else{var a=e[t.charAt(o)];"number"==typeof a?(255&a)==a?r.push(a):(r.push(a>>>8),r.push(255&a)):r.push(n)}}return r}};var r,e,n,o,i,a=1,u=2,f=4,c=8,g={L:1,M:0,Q:3,H:2},l=0,h=1,s=2,v=3,d=4,w=5,p=6,y=7,B=(r=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],e=1335,n=7973,i=function(t){for(var r=0;0!=t;)r+=1,t>>>=1;return r},(o={}).getBCHTypeInfo=function(t){for(var r=t<<10;i(r)-i(e)>=0;)r^=e<<i(r)-i(e);return 21522^(t<<10|r)},o.getBCHTypeNumber=function(t){for(var r=t<<12;i(r)-i(n)>=0;)r^=n<<i(r)-i(n);return t<<12|r},o.getPatternPosition=function(t){return r[t-1]},o.getMaskFunction=function(t){switch(t){case l:return function(t,r){return(t+r)%2==0};case h:return function(t,r){return t%2==0};case s:return function(t,r){return r%3==0};case v:return function(t,r){return(t+r)%3==0};case d:return function(t,r){return(Math.floor(t/2)+Math.floor(r/3))%2==0};case w:return function(t,r){return t*r%2+t*r%3==0};case p:return function(t,r){return(t*r%2+t*r%3)%2==0};case y:return function(t,r){return(t*r%3+(t+r)%2)%2==0};default:throw"bad maskPattern:"+t}},o.getErrorCorrectPolynomial=function(t){for(var r=k([1],0),e=0;e<t;e+=1)r=r.multiply(k([1,C.gexp(e)],0));return r},o.getLengthInBits=function(t,r){if(1<=r&&r<10)switch(t){case a:return 10;case u:return 9;case f:case c:return 8;default:throw"mode:"+t}else if(r<27)switch(t){case a:return 12;case u:return 11;case f:return 16;case c:return 10;default:throw"mode:"+t}else{if(!(r<41))throw"type:"+r;switch(t){case a:return 14;case u:return 13;case f:return 16;case c:return 12;default:throw"mode:"+t}}},o.getLostPoint=function(t){for(var r=t.getModuleCount(),e=0,n=0;n<r;n+=1)for(var o=0;o<r;o+=1){for(var i=0,a=t.isDark(n,o),u=-1;u<=1;u+=1)if(!(n+u<0||r<=n+u))for(var f=-1;f<=1;f+=1)o+f<0||r<=o+f||0==u&&0==f||a==t.isDark(n+u,o+f)&&(i+=1);i>5&&(e+=3+i-5)}for(n=0;n<r-1;n+=1)for(o=0;o<r-1;o+=1){var c=0;t.isDark(n,o)&&(c+=1),t.isDark(n+1,o)&&(c+=1),t.isDark(n,o+1)&&(c+=1),t.isDark(n+1,o+1)&&(c+=1),0!=c&&4!=c||(e+=3)}for(n=0;n<r;n+=1)for(o=0;o<r-6;o+=1)t.isDark(n,o)&&!t.isDark(n,o+1)&&t.isDark(n,o+2)&&t.isDark(n,o+3)&&t.isDark(n,o+4)&&!t.isDark(n,o+5)&&t.isDark(n,o+6)&&(e+=40);for(o=0;o<r;o+=1)for(n=0;n<r-6;n+=1)t.isDark(n,o)&&!t.isDark(n+1,o)&&t.isDark(n+2,o)&&t.isDark(n+3,o)&&t.isDark(n+4,o)&&!t.isDark(n+5,o)&&t.isDark(n+6,o)&&(e+=40);var g=0;for(o=0;o<r;o+=1)for(n=0;n<r;n+=1)t.isDark(n,o)&&(g+=1);return e+=Math.abs(100*g/r/r-50)/5*10},o),C=function(){for(var t=new Array(256),r=new Array(256),e=0;e<8;e+=1)t[e]=1<<e;for(e=8;e<256;e+=1)t[e]=t[e-4]^t[e-5]^t[e-6]^t[e-8];for(e=0;e<255;e+=1)r[t[e]]=e;var n={glog:function(t){if(t<1)throw"glog("+t+")";return r[t]},gexp:function(r){for(;r<0;)r+=255;for(;r>=256;)r-=255;return t[r]}};return n}();function k(t,r){if(void 0===t.length)throw t.length+"/"+r;var e=function(){for(var e=0;e<t.length&&0==t[e];)e+=1;for(var n=new Array(t.length-e+r),o=0;o<t.length-e;o+=1)n[o]=t[o+e];return n}(),n={getAt:function(t){return e[t]},getLength:function(){return e.length},multiply:function(t){for(var r=new Array(n.getLength()+t.getLength()-1),e=0;e<n.getLength();e+=1)for(var o=0;o<t.getLength();o+=1)r[e+o]^=C.gexp(C.glog(n.getAt(e))+C.glog(t.getAt(o)));return k(r,0)},mod:function(t){if(n.getLength()-t.getLength()<0)return n;for(var r=C.glog(n.getAt(0))-C.glog(t.getAt(0)),e=new Array(n.getLength()),o=0;o<n.getLength();o+=1)e[o]=n.getAt(o);for(o=0;o<t.getLength();o+=1)e[o]^=C.gexp(C.glog(t.getAt(o))+r);return k(e,0).mod(t)}};return n}var A=function(){var t=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12,7,37,13],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],r=function(t,r){var e={};return e.totalCount=t,e.dataCount=r,e},e={};return e.getRSBlocks=function(e,n){var o=function(r,e){switch(e){case g.L:return t[4*(r-1)+0];case g.M:return t[4*(r-1)+1];case g.Q:return t[4*(r-1)+2];case g.H:return t[4*(r-1)+3];default:return}}(e,n);if(void 0===o)throw"bad rs block @ typeNumber:"+e+"/errorCorrectionLevel:"+n;for(var i=o.length/3,a=[],u=0;u<i;u+=1)for(var f=o[3*u+0],c=o[3*u+1],l=o[3*u+2],h=0;h<f;h+=1)a.push(r(c,l));return a},e}(),b=function(){var t=[],r=0,e={getBuffer:function(){return t},getAt:function(r){var e=Math.floor(r/8);return 1==(t[e]>>>7-r%8&1)},put:function(t,r){for(var n=0;n<r;n+=1)e.putBit(1==(t>>>r-n-1&1))},getLengthInBits:function(){return r},putBit:function(e){var n=Math.floor(r/8);t.length<=n&&t.push(0),e&&(t[n]|=128>>>r%8),r+=1}};return e},M=function(t){var r=a,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+2<r.length;)t.put(o(r.substring(n,n+3)),10),n+=3;n<r.length&&(r.length-n==1?t.put(o(r.substring(n,n+1)),4):r.length-n==2&&t.put(o(r.substring(n,n+2)),7))}},o=function(t){for(var r=0,e=0;e<t.length;e+=1)r=10*r+i(t.charAt(e));return r},i=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);throw"illegal char :"+t};return n},x=function(t){var r=u,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+1<r.length;)t.put(45*o(r.charAt(n))+o(r.charAt(n+1)),11),n+=2;n<r.length&&t.put(o(r.charAt(n)),6)}},o=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);if("A"<=t&&t<="Z")return t.charCodeAt(0)-"A".charCodeAt(0)+10;switch(t){case" ":return 36;case"$":return 37;case"%":return 38;case"*":return 39;case"+":return 40;case"-":return 41;case".":return 42;case"/":return 43;case":":return 44;default:throw"illegal char :"+t}};return n},m=function(r){var e=f,n=t.stringToBytes(r),o={getMode:function(){return e},getLength:function(t){return n.length},write:function(t){for(var r=0;r<n.length;r+=1)t.put(n[r],8)}};return o},L=function(r){var e=c,n=t.stringToBytesFuncs.SJIS;if(!n)throw"sjis not supported.";!function(){var t=n("友");if(2!=t.length||38726!=(t[0]<<8|t[1]))throw"sjis not supported."}();var o=n(r),i={getMode:function(){return e},getLength:function(t){return~~(o.length/2)},write:function(t){for(var r=o,e=0;e+1<r.length;){var n=(255&r[e])<<8|255&r[e+1];if(33088<=n&&n<=40956)n-=33088;else{if(!(57408<=n&&n<=60351))throw"illegal char at "+(e+1)+"/"+n;n-=49472}n=192*(n>>>8&255)+(255&n),t.put(n,13),e+=2}if(e<r.length)throw"illegal char at "+(e+1)}};return i},D=function(){var t=[],r={writeByte:function(r){t.push(255&r)},writeShort:function(t){r.writeByte(t),r.writeByte(t>>>8)},writeBytes:function(t,e,n){e=e||0,n=n||t.length;for(var o=0;o<n;o+=1)r.writeByte(t[o+e])},writeString:function(t){for(var e=0;e<t.length;e+=1)r.writeByte(t.charCodeAt(e))},toByteArray:function(){return t},toString:function(){var r="";r+="[";for(var e=0;e<t.length;e+=1)e>0&&(r+=","),r+=t[e];return r+="]"}};return r},S=function(t){var r=t,e=0,n=0,o=0,i={read:function(){for(;o<8;){if(e>=r.length){if(0==o)return-1;throw"unexpected end of file./"+o}var t=r.charAt(e);if(e+=1,"="==t)return o=0,-1;t.match(/^\s$/)||(n=n<<6|a(t.charCodeAt(0)),o+=6)}var i=n>>>o-8&255;return o-=8,i}},a=function(t){if(65<=t&&t<=90)return t-65;if(97<=t&&t<=122)return t-97+26;if(48<=t&&t<=57)return t-48+52;if(43==t)return 62;if(47==t)return 63;throw"c:"+t};return i},I=function(t,r,e){for(var n=function(t,r){var e=t,n=r,o=new Array(t*r),i={setPixel:function(t,r,n){o[r*e+t]=n},write:function(t){t.writeString("GIF87a"),t.writeShort(e),t.writeShort(n),t.writeByte(128),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(255),t.writeByte(255),t.writeByte(255),t.writeString(","),t.writeShort(0),t.writeShort(0),t.writeShort(e),t.writeShort(n),t.writeByte(0);var r=a(2);t.writeByte(2);for(var o=0;r.length-o>255;)t.writeByte(255),t.writeBytes(r,o,255),o+=255;t.writeByte(r.length-o),t.writeBytes(r,o,r.length-o),t.writeByte(0),t.writeString(";")}},a=function(t){for(var r=1<<t,e=1+(1<<t),n=t+1,i=u(),a=0;a<r;a+=1)i.add(String.fromCharCode(a));i.add(String.fromCharCode(r)),i.add(String.fromCharCode(e));var f,c,g,l=D(),h=(f=l,c=0,g=0,{write:function(t,r){if(t>>>r!=0)throw"length over";for(;c+r>=8;)f.writeByte(255&(t<<c|g)),r-=8-c,t>>>=8-c,g=0,c=0;g|=t<<c,c+=r},flush:function(){c>0&&f.writeByte(g)}});h.write(r,n);var s=0,v=String.fromCharCode(o[s]);for(s+=1;s<o.length;){var d=String.fromCharCode(o[s]);s+=1,i.contains(v+d)?v+=d:(h.write(i.indexOf(v),n),i.size()<4095&&(i.size()==1<<n&&(n+=1),i.add(v+d)),v=d)}return h.write(i.indexOf(v),n),h.write(e,n),h.flush(),l.toByteArray()},u=function(){var t={},r=0,e={add:function(n){if(e.contains(n))throw"dup key:"+n;t[n]=r,r+=1},size:function(){return r},indexOf:function(r){return t[r]},contains:function(r){return void 0!==t[r]}};return e};return i}(t,r),o=0;o<r;o+=1)for(var i=0;i<t;i+=1)n.setPixel(i,o,e(i,o));var a=D();n.write(a);for(var u=function(){var t=0,r=0,e=0,n="",o={},i=function(t){n+=String.fromCharCode(a(63&t))},a=function(t){if(t<0);else{if(t<26)return 65+t;if(t<52)return t-26+97;if(t<62)return t-52+48;if(62==t)return 43;if(63==t)return 47}throw"n:"+t};return o.writeByte=function(n){for(t=t<<8|255&n,r+=8,e+=1;r>=6;)i(t>>>r-6),r-=6},o.flush=function(){if(r>0&&(i(t<<6-r),t=0,r=0),e%3!=0)for(var o=3-e%3,a=0;a<o;a+=1)n+="="},o.toString=function(){return n},o}(),f=a.toByteArray(),c=0;c<f.length;c+=1)u.writeByte(f[c]);return u.flush(),"data:image/gif;base64,"+u};return t}();qrcode.stringToBytesFuncs["UTF-8"]=function(t){return function(t){for(var r=[],e=0;e<t.length;e++){var n=t.charCodeAt(e);n<128?r.push(n):n<2048?r.push(192|n>>6,128|63&n):n<55296||n>=57344?r.push(224|n>>12,128|n>>6&63,128|63&n):(e++,n=65536+((1023&n)<<10|1023&t.charCodeAt(e)),r.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|63&n))}return r}(t)};
    return qrcode;
  })();

  /** Strip everything except digits (wa.me / viber / tel need bare digits). */
  function digitsOnly(value) {
    return String(value || '').replace(/[^0-9]/g, '');
  }

  /** Replace {page_title} / {page_url} tokens from the live document. */
  function replaceTokens(message) {
    if (!message) {
      return '';
    }
    return String(message)
      .replace(/\{page_title\}/g, document.title || '')
      .replace(/\{page_url\}/g, window.location.href || '');
  }

  /** Build the channel deep-link for one agent. */
  function buildAgentLink(channel, contact, prefill) {
    var value = String(contact || '').trim();
    var message = replaceTokens(prefill || '');

    switch (channel) {
      case 'messenger':
        return 'https://m.me/' + encodeURIComponent(value);
      case 'telegram':
        return 'https://t.me/' + encodeURIComponent(value);
      case 'viber':
        return 'viber://chat?number=' + digitsOnly(value);
      case 'phone':
        return 'tel:' + digitsOnly(value);
      case 'email':
        return message !== ''
          ? 'mailto:' + value + '?subject=' + encodeURIComponent(message)
          : 'mailto:' + value;
      case 'whatsapp':
      default:
        return message !== ''
          ? 'https://wa.me/' + digitsOnly(value) + '?text=' + encodeURIComponent(message)
          : 'https://wa.me/' + digitsOnly(value);
    }
  }

  function sessionFlag(key) {
    try {
      return window.sessionStorage.getItem(key) === '1';
    } catch (e) {
      return false;
    }
  }

  function setSessionFlag(key) {
    try {
      window.sessionStorage.setItem(key, '1');
    } catch (e) {
      /* sessionStorage unavailable — fail silently. */
    }
  }

  function clearSessionFlag(key) {
    try {
      window.sessionStorage.removeItem(key);
    } catch (e) {
      /* noop */
    }
  }

  function lsGet(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function lsSet(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (e) {
      /* localStorage unavailable — fail silently. */
    }
  }

  /**
   * Round-robin index for a widget, persisted in localStorage and advanced once
   * per page-load. Falls back to 0 when storage is unavailable.
   */
  function nextRoundRobinIndex(uid, length) {
    if (length <= 0) {
      return 0;
    }
    var key = 'dnxte-wa-rr-' + uid;
    var current = parseInt(lsGet(key) || '0', 10);
    if (isNaN(current) || current < 0) {
      current = 0;
    }
    var index = current % length;
    lsSet(key, String((current + 1) % 1000000));
    return index;
  }

  /**
   * Render `text` as a real, scannable QR matrix into a <canvas> using the
   * inlined qrcode-generator encoder (byte mode, ECC level M, auto version).
   * Returns false if encoding fails (e.g. content exceeds QR capacity).
   */
  function renderQrToCanvas(canvas, text) {
    try {
      var qr = dnxteQrFactory(0, 'M');
      qr.addData(String(text || ''));
      qr.make();
      var count = qr.getModuleCount();
      var quiet = 4; // quiet-zone margin in modules
      var total = count + quiet * 2;
      var scale = Math.max(2, Math.floor(320 / total));
      var dim = total * scale;
      canvas.width = dim;
      canvas.height = dim;
      var ctx = canvas.getContext('2d');
      if (!ctx) {
        return false;
      }
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, dim, dim);
      ctx.fillStyle = '#000000';
      for (var row = 0; row < count; row++) {
        for (var col = 0; col < count; col++) {
          if (qr.isDark(row, col)) {
            ctx.fillRect((col + quiet) * scale, (row + quiet) * scale, scale, scale);
          }
        }
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  /** Desktop = no touch input and a reasonably wide viewport. */
  function isDesktop() {
    var noTouch = !('ontouchstart' in window) && (navigator.maxTouchPoints || 0) === 0;
    var wide = !window.matchMedia || window.matchMedia('(min-width: 768px)').matches;
    return noTouch && wide;
  }

  /** Short notification blip via Web Audio (no file / network). */
  function playBlip() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) {
        return;
      }
      var ctx = new Ctx();
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
      osc.onended = function () {
        try { ctx.close(); } catch (e) { /* noop */ }
      };
    } catch (e) {
      /* audio blocked / unavailable — fail silently. */
    }
  }

  /** Push an analytics event to any present provider (all guarded). */
  function pushAnalytics(eventName, channel, agentName) {
    try {
      if (window.dataLayer && typeof window.dataLayer.push === 'function') {
        window.dataLayer.push({ event: eventName, channel: channel || '', agent: agentName || '' });
      }
    } catch (e) { /* noop */ }
    try {
      if (typeof window.gtag === 'function') {
        window.gtag('event', eventName, { channel: channel || '', agent: agentName || '' });
      }
    } catch (e) { /* noop */ }
    try {
      if (typeof window.fbq === 'function') {
        window.fbq('track', 'Contact', { channel: channel || '', agent: agentName || '' });
      }
    } catch (e) { /* noop */ }
  }

  /**
   * Fire-and-forget ping to the plugin's own aggregate counter (separate from
   * the GA/GTM/Pixel pushes above). Uses navigator.sendBeacon so it survives the
   * page unloading when the WhatsApp deep-link navigates away, falling back to a
   * keepalive fetch. Guarded on window.dnxteWaTrack (localized only when the
   * analytics flag is on) so it is a no-op otherwise. Never throws, never blocks.
   *
   * @param {string} event      'open' | 'click'.
   * @param {string} channel    Channel key.
   * @param {string} agentName  Agent display name.
   * @param {string} agentId    Agent post id if the DOM exposes one, else ''.
   */
  function sendTrackingBeacon(event, channel, agentName, agentId) {
    var cfg = window.dnxteWaTrack;
    if (!cfg || !cfg.url) {
      return;
    }
    try {
      var data = new FormData();
      data.append('action', 'dnxte_wa_track');
      data.append('nonce', cfg.nonce || '');
      data.append('event', event || '');
      data.append('channel', channel || '');
      data.append('agent', agentName || '');
      if (agentId) {
        data.append('agent_id', agentId);
      }
      if (navigator && typeof navigator.sendBeacon === 'function') {
        navigator.sendBeacon(cfg.url, data);
      } else if (typeof window.fetch === 'function') {
        window.fetch(cfg.url, { method: 'POST', body: data, keepalive: true, credentials: 'same-origin' });
      }
    } catch (e) {
      /* analytics ping failed — ignore, never affect the chat flow. */
    }
  }

  // ── Working hours ─────────────────────────────────────────────

  /** "HH:MM" → minutes of day (NaN-safe). */
  function parseHM(value) {
    var parts = String(value || '').split(':');
    var h = parseInt(parts[0], 10);
    var m = parseInt(parts[1], 10);
    if (isNaN(h)) { h = 0; }
    if (isNaN(m)) { m = 0; }
    return h * 60 + m;
  }

  /** Minutes → "Xh Ym" (compact). */
  function formatBackIn(minutes) {
    var total = Math.max(0, Math.round(minutes));
    var h = Math.floor(total / 60);
    var m = total % 60;
    if (h > 0 && m > 0) { return h + 'h ' + m + 'm'; }
    if (h > 0) { return h + 'h'; }
    return m + 'm';
  }

  /**
   * Compute the online state (and minutes until the next opening) for one agent,
   * evaluated in the agent's own UTC offset so it is cache-safe.
   *
   * @returns {null|{online:boolean, backIn:number, offlineText:string}}
   */
  function computeAgentHours(agent) {
    if (agent.getAttribute('data-wa-hours-mode') !== 'scheduled') {
      return null;
    }

    var tz = parseFloat(agent.getAttribute('data-wa-tz') || '0');
    if (isNaN(tz)) { tz = 0; }

    var startMin = parseHM(agent.getAttribute('data-wa-start') || '09:00');
    var endMin = parseHM(agent.getAttribute('data-wa-end') || '17:00');

    var days = String(agent.getAttribute('data-wa-days') || '')
      .split(',')
      .map(function (d) { return parseInt(d, 10); })
      .filter(function (d) { return !isNaN(d) && d >= 0 && d <= 6; });

    // "Now", shifted into the agent's offset (read back with UTC getters).
    var shifted = new Date(Date.now() + tz * 3600000);
    var nowDay = shifted.getUTCDay();
    var nowMin = shifted.getUTCHours() * 60 + shifted.getUTCMinutes();

    var overnight = startMin > endMin;
    var withinWindow = overnight
      ? (nowMin >= startMin || nowMin < endMin)
      : (nowMin >= startMin && nowMin < endMin);
    var online = days.indexOf(nowDay) !== -1 && withinWindow;

    var backIn = 0;
    if (!online) {
      // Minutes until the next opening across the coming week.
      for (var offset = 0; offset < 8; offset++) {
        var day = (nowDay + offset) % 7;
        if (days.indexOf(day) === -1) {
          continue;
        }
        if (offset === 0 && nowMin >= startMin) {
          continue; // today's opening already passed
        }
        backIn = offset * 1440 + startMin - nowMin;
        break;
      }
    }

    var text = String(agent.getAttribute('data-wa-offline-text') || '')
      .replace(/\{back_in\}/g, formatBackIn(backIn));

    return { online: online, backIn: backIn, offlineText: text };
  }

  /** Apply the computed hours to an agent row (dot + offline text). */
  function applyAgentHours(agent) {
    var info = computeAgentHours(agent);
    if (!info) {
      return;
    }
    var textEl = agent.querySelector('.dnxte-wa-agent-offline-text');
    if (info.online) {
      agent.classList.add('dnxte-wa-agent-online');
      agent.classList.remove('dnxte-wa-agent-offline');
      if (textEl) { textEl.textContent = ''; }
    } else {
      agent.classList.add('dnxte-wa-agent-offline');
      agent.classList.remove('dnxte-wa-agent-online');
      if (textEl) { textEl.textContent = info.offlineText; }
    }
  }

  // ── Widget ────────────────────────────────────────────────────

  function initWidget(root, index) {
    if (!root || root.dataset.waInit === '1') {
      return;
    }
    root.dataset.waInit = '1';

    var button = root.querySelector('.dnxte-wa-button');
    var popup = root.querySelector('.dnxte-wa-popup');
    var popupBody = root.querySelector('.dnxte-wa-popup-body');
    var teaser = root.querySelector('.dnxte-wa-teaser');
    var closeBtn = root.querySelector('.dnxte-wa-popup-close');
    var teaserClose = root.querySelector('.dnxte-wa-teaser-close');
    var badge = root.querySelector('.dnxte-wa-badge');
    var prechat = root.querySelector('.dnxte-wa-prechat');

    if (!button || !popup) {
      return;
    }

    var uid = root.id || 'dnxte-wa-' + index;
    var cfg = {
      trigger: button.getAttribute('data-wa-trigger') || 'click',
      autoDelay: parseFloat(button.getAttribute('data-wa-auto-delay') || '5'),
      scrollPercent: parseFloat(button.getAttribute('data-wa-scroll-percent') || '50'),
      elementSelector: button.getAttribute('data-wa-element-selector') || '',
      teaserDelay: parseFloat(button.getAttribute('data-wa-teaser-delay') || '3'),
      teaserSound: button.getAttribute('data-wa-teaser-sound') === 'on',
      analytics: button.getAttribute('data-wa-analytics') === 'on',
      qr: button.getAttribute('data-wa-qr') === 'on',
      routingMode: button.getAttribute('data-wa-routing-mode') || 'all',
      singleButton: button.getAttribute('data-wa-single-button') === 'on',
      openDir: button.getAttribute('data-wa-open-dir') || 'auto',
    };

    var agents = Array.prototype.slice.call(root.querySelectorAll('.dnxte-wa-agent'));

    // ── Routing (all / round-robin / random) ──────────────────────
    // When not "all", pick a single active agent and reflect it in the popup by
    // hiding the others. Round-robin advances a localStorage counter per load;
    // random picks on load. mode=all leaves everything untouched.
    var activeAgent = null;
    if (cfg.routingMode !== 'all' && agents.length > 0) {
      var activeIndex = cfg.routingMode === 'random'
        ? Math.floor(Math.random() * agents.length)
        : nextRoundRobinIndex(uid, agents.length);
      activeAgent = agents[activeIndex];
      agents.forEach(function (agent, i) {
        if (i !== activeIndex) {
          agent.classList.add('dnxte-wa-agent-hidden');
        }
      });
    }

    // Consent (may live in the popup body or inside the pre-chat form).
    var consentEl = popup.querySelector('.dnxte-wa-consent');
    var consentBox = consentEl ? consentEl.querySelector('.dnxte-wa-consent-checkbox') : null;
    var consentRequired = !!consentEl && consentEl.getAttribute('data-wa-required') === 'on';
    var consentInForm = !!(prechat && prechat.contains(consentEl));

    function consentAccepted() {
      if (!consentRequired) {
        return true;
      }
      return consentBox ? consentBox.checked : false;
    }

    function analytics(eventName, agent) {
      if (!cfg.analytics) {
        return;
      }
      var channel = agent ? (agent.getAttribute('data-channel') || '') : '';
      var nameEl = agent ? agent.querySelector('.dnxte-wa-agent-name') : null;
      var agentName = nameEl ? (nameEl.textContent || '').trim() : '';
      // Keep the existing GA/GTM/Pixel pushes intact…
      pushAnalytics(eventName, channel, agentName);
      // …and additionally record an aggregate hit in the plugin's own store.
      var agentId = agent ? (agent.getAttribute('data-agent-id') || agent.getAttribute('data-wa-agent-id') || '') : '';
      var beaconEvent = eventName === 'whatsapp_open' ? 'open' : 'click';
      sendTrackingBeacon(beaconEvent, channel, agentName, agentId);
    }

    function isOpen() {
      return popup.classList.contains('dnxte-wa-open');
    }

    // Auto open direction — tooltip-style. Only runs when the control is set to
    // Auto; Above/Below keep their static class. Measures the room above vs below
    // the button and opens toward the side that fits (preferring the larger gap),
    // flipping only when the preferred side can't hold the popup but the other can.
    function applyAutoDirection() {
      if (cfg.openDir !== 'auto') {
        return;
      }
      var rect = button.getBoundingClientRect();
      var vh = window.innerHeight || document.documentElement.clientHeight || 0;
      var popupH = popup.offsetHeight || 420;
      var spaceAbove = rect.top;
      var spaceBelow = vh - rect.bottom;
      var up = spaceAbove >= spaceBelow;
      if (up && spaceAbove < popupH && spaceBelow >= popupH) {
        up = false;
      } else if (!up && spaceBelow < popupH && spaceAbove >= popupH) {
        up = true;
      }
      popup.classList.toggle('dnxte-wa-up', up);
      popup.classList.toggle('dnxte-wa-down', !up);
    }

    function openPopup() {
      popup.classList.add('dnxte-wa-open');
      applyAutoDirection();
      popup.setAttribute('aria-hidden', 'false');
      button.setAttribute('aria-expanded', 'true');
      hideTeaser();
      // Opening clears the unread badge for the session.
      root.classList.remove('dnxte-wa-badge-visible');
      setSessionFlag(uid + '-opened');
      analytics('whatsapp_open', null);
    }

    function closePopup() {
      popup.classList.remove('dnxte-wa-open');
      popup.setAttribute('aria-hidden', 'true');
      button.setAttribute('aria-expanded', 'false');
      resetPanels();
    }

    function togglePopup() {
      if (isOpen()) {
        closePopup();
      } else {
        openPopup();
      }
    }

    function hideTeaser() {
      root.classList.remove('dnxte-wa-teaser-visible');
    }

    function showTeaser() {
      if (teaser && !sessionFlag(uid + '-teaser')) {
        root.classList.add('dnxte-wa-teaser-visible');
        if (cfg.teaserSound) {
          playBlip();
        }
      }
    }

    // Reset the popup back to the agent list (out of the pre-chat / QR states).
    function resetPanels() {
      popup.classList.remove('dnxte-wa-prechat-active');
      popup.classList.remove('dnxte-wa-qr-active');
      var qrPanel = popup.querySelector('.dnxte-wa-qr');
      if (qrPanel && qrPanel.parentNode) {
        qrPanel.parentNode.removeChild(qrPanel);
      }
    }

    // ── Consent gating (only relevant when there is no pre-chat form) ──
    function updateAgentsEnabled() {
      var disable = consentRequired && !consentInForm && !consentAccepted();
      agents.forEach(function (agent) {
        if (disable) {
          agent.classList.add('dnxte-wa-disabled');
        } else {
          agent.classList.remove('dnxte-wa-disabled');
        }
      });
    }

    if (consentBox) {
      // Restore session acceptance.
      if (sessionFlag(uid + '-consent')) {
        consentBox.checked = true;
      }
      consentBox.addEventListener('change', function () {
        if (consentBox.checked) {
          setSessionFlag(uid + '-consent');
        } else {
          clearSessionFlag(uid + '-consent');
        }
        updateAgentsEnabled();
        updatePrechatSubmit();
      });
    }
    updateAgentsEnabled();

    // ── QR (desktop) ──────────────────────────────────────────────
    function qrApplies(agent) {
      var channel = agent.getAttribute('data-channel') || 'whatsapp';
      return cfg.qr && isDesktop() && (channel === 'whatsapp' || channel === 'viber');
    }

    function showQrPanel(agent, link) {
      resetPanels();
      var panel = document.createElement('div');
      panel.className = 'dnxte-wa-qr';

      var note = document.createElement('div');
      note.className = 'dnxte-wa-qr-note';
      note.textContent = 'Scan or open on your phone to start the chat.';
      panel.appendChild(note);

      // Real scannable QR of the deep-link, rendered offline. The number/link
      // below stay as a fallback if the canvas can't render the matrix.
      var canvas = document.createElement('canvas');
      canvas.className = 'dnxte-wa-qr-canvas';
      canvas.setAttribute('role', 'img');
      canvas.setAttribute('aria-label', 'WhatsApp QR code');
      if (renderQrToCanvas(canvas, link)) {
        panel.appendChild(canvas);
      }

      var contact = (agent.getAttribute('data-contact') || '').trim();
      if (contact) {
        var contactEl = document.createElement('div');
        contactEl.className = 'dnxte-wa-qr-contact';
        contactEl.textContent = contact;
        panel.appendChild(contactEl);
      }

      var linkEl = document.createElement('a');
      linkEl.className = 'dnxte-wa-qr-link';
      linkEl.setAttribute('href', link);
      linkEl.setAttribute('target', '_blank');
      linkEl.setAttribute('rel', 'noopener noreferrer');
      linkEl.textContent = 'Open chat link';
      panel.appendChild(linkEl);

      var backBtn = document.createElement('button');
      backBtn.type = 'button';
      backBtn.className = 'dnxte-wa-qr-close';
      backBtn.textContent = 'Back';
      backBtn.addEventListener('click', function () { resetPanels(); });
      panel.appendChild(backBtn);

      if (popupBody) {
        popupBody.appendChild(panel);
      }
      popup.classList.add('dnxte-wa-qr-active');
    }

    // ── Proceed / navigate ────────────────────────────────────────
    function proceed(agent, extraMessage) {
      var channel = agent.getAttribute('data-channel') || 'whatsapp';
      var contact = agent.getAttribute('data-contact') || '';
      var basePrefill = agent.getAttribute('data-prefill') || '';
      var prefill = extraMessage ? (extraMessage + '\n\n' + basePrefill) : basePrefill;
      var link = buildAgentLink(channel, contact, prefill);

      analytics('whatsapp_click', agent);

      if (qrApplies(agent)) {
        showQrPanel(agent, link);
        return;
      }
      agent.setAttribute('href', link);
      if (channel === 'phone' || channel === 'email') {
        window.location.href = link;
      } else {
        window.open(link, '_blank', 'noopener');
      }
    }

    // ── Pre-chat form ─────────────────────────────────────────────
    var pendingAgent = null;
    var prechatName = prechat ? prechat.querySelector('.dnxte-wa-prechat-name') : null;
    var prechatEmail = prechat ? prechat.querySelector('.dnxte-wa-prechat-email') : null;
    var prechatMessage = prechat ? prechat.querySelector('.dnxte-wa-prechat-message') : null;
    var prechatSubmit = prechat ? prechat.querySelector('.dnxte-wa-prechat-submit') : null;
    var prechatCancel = prechat ? prechat.querySelector('.dnxte-wa-prechat-cancel') : null;

    function updatePrechatSubmit() {
      if (!prechatSubmit) {
        return;
      }
      var ok = true;
      if (prechatName && prechatName.value.trim() === '') { ok = false; }
      if (consentInForm && consentRequired && !consentAccepted()) { ok = false; }
      prechatSubmit.disabled = !ok;
    }

    function openPrechat(agent) {
      pendingAgent = agent;
      resetPanels();
      popup.classList.add('dnxte-wa-prechat-active');
      updatePrechatSubmit();
      if (prechatName) {
        try { prechatName.focus(); } catch (e) { /* noop */ }
      }
    }

    function composePrechatMessage() {
      var lines = [];
      if (prechatName && prechatName.value.trim() !== '') {
        lines.push('Name: ' + prechatName.value.trim());
      }
      if (prechatEmail && prechatEmail.value.trim() !== '') {
        lines.push('Email: ' + prechatEmail.value.trim());
      }
      if (prechatMessage && prechatMessage.value.trim() !== '') {
        lines.push('Message: ' + prechatMessage.value.trim());
      }
      return lines.join('\n');
    }

    if (prechat) {
      if (prechatName) {
        prechatName.addEventListener('input', updatePrechatSubmit);
      }
      prechat.addEventListener('submit', function (e) {
        e.preventDefault();
        if (prechatSubmit && prechatSubmit.disabled) {
          return;
        }
        var agent = pendingAgent;
        if (!agent) {
          return;
        }
        proceed(agent, composePrechatMessage());
      });
      if (prechatCancel) {
        prechatCancel.addEventListener('click', function () {
          pendingAgent = null;
          resetPanels();
        });
      }
    }

    // ── Agent clicks ──────────────────────────────────────────────
    agents.forEach(function (agent) {
      // Compute working hours (dot + offline countdown) on load.
      applyAgentHours(agent);

      agent.addEventListener('click', function (e) {
        // Consent gate (no pre-chat form): block until accepted.
        if (consentRequired && !consentInForm && !consentAccepted()) {
          e.preventDefault();
          if (consentEl) {
            consentEl.classList.add('dnxte-wa-consent-flash');
            window.setTimeout(function () {
              consentEl.classList.remove('dnxte-wa-consent-flash');
            }, 600);
          }
          return;
        }

        // Pre-chat form: intercept, collect, then proceed on submit.
        if (prechat) {
          e.preventDefault();
          openPrechat(agent);
          return;
        }

        // QR on desktop: intercept and show the QR panel instead of navigating.
        if (qrApplies(agent) || cfg.analytics) {
          e.preventDefault();
          proceed(agent, '');
          return;
        }

        // Default: rebuild the link at click time so tokens resolve on cached pages.
        var href = buildAgentLink(
          agent.getAttribute('data-channel') || 'whatsapp',
          agent.getAttribute('data-contact') || '',
          agent.getAttribute('data-prefill') || ''
        );
        agent.setAttribute('href', href);
      });
    });

    // Single-button routing: open the chosen agent directly (skip the popup)
    // unless a gate (consent / pre-chat / desktop QR) still needs the popup UI.
    function activateSingle() {
      if (!activeAgent) {
        togglePopup();
        return;
      }
      if (consentRequired && !consentInForm && !consentAccepted()) {
        openPopup();
        return;
      }
      if (prechat) {
        openPopup();
        openPrechat(activeAgent);
        return;
      }
      if (qrApplies(activeAgent)) {
        openPopup();
      }
      proceed(activeAgent, '');
    }

    // Button — toggles the popup, or (single-button routing) opens the agent.
    // Click always works (it's also the touch fallback for the hover trigger).
    button.addEventListener('click', function (e) {
      e.preventDefault();
      if (cfg.singleButton && cfg.routingMode !== 'all' && activeAgent) {
        activateSingle();
        return;
      }
      togglePopup();
    });

    // Hover trigger — open when the pointer enters the widget, close shortly
    // after it leaves (the delay lets the pointer cross the gap to the popup
    // without it snapping shut). Pointer-capable devices only; on touch the
    // click handler above still opens it.
    if (cfg.trigger === 'hover' && window.matchMedia && window.matchMedia('(hover: hover)').matches) {
      var hoverCloseTimer = null;
      root.addEventListener('mouseenter', function () {
        if (hoverCloseTimer) {
          clearTimeout(hoverCloseTimer);
          hoverCloseTimer = null;
        }
        if (!isOpen()) {
          openPopup();
        }
      });
      root.addEventListener('mouseleave', function () {
        if (hoverCloseTimer) {
          clearTimeout(hoverCloseTimer);
        }
        hoverCloseTimer = window.setTimeout(function () {
          if (isOpen()) {
            closePopup();
          }
        }, 280);
      });
    }

    // Close button.
    if (closeBtn) {
      closeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        closePopup();
      });
    }

    // Teaser: click opens popup; its × dismisses for the session.
    if (teaser) {
      teaser.addEventListener('click', function (e) {
        if (teaserClose && teaserClose.contains(e.target)) {
          return;
        }
        openPopup();
      });
    }
    if (teaserClose) {
      teaserClose.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        hideTeaser();
        setSessionFlag(uid + '-teaser');
      });
    }

    // Outside click closes the popup.
    document.addEventListener('click', function (e) {
      if (isOpen() && !root.contains(e.target)) {
        closePopup();
      }
    });

    // Esc closes the popup.
    document.addEventListener('keydown', function (e) {
      if ((e.key === 'Escape' || e.keyCode === 27) && isOpen()) {
        closePopup();
      }
    });

    // Unread badge — show until first open (persisted per session).
    if (badge && !sessionFlag(uid + '-opened')) {
      root.classList.add('dnxte-wa-badge-visible');
    }

    // Teaser bubble after its delay (once per session).
    if (teaser && !sessionFlag(uid + '-teaser')) {
      window.setTimeout(showTeaser, Math.max(0, cfg.teaserDelay) * 1000);
    }

    // Only Click and Hover triggers are supported; the popup opens from the
    // button interaction bound above.
  }

  function initAll() {
    var roots = document.querySelectorAll('.dnxte-whatsapp-chat');
    Array.prototype.forEach.call(roots, initWidget);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
