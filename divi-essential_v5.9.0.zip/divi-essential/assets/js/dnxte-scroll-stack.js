/**
 * Scroll Stack — Frontend Runtime
 * GSAP ScrollTrigger based: pin + scrub + snap-to-labels.
 * Does NOT override Divi's Row/Column/Section layout — respects whatever
 * layout settings the user configured in Divi. Stacking illusion comes
 * from timeline translateY math that pulls each card up to overlap the
 * first card's position during pin.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  function readConfig(el) {
    var get = function (name, def) {
      var v = el.getAttribute('data-sstack-' + name);
      return (v === null || v === '') ? def : v;
    };
    var num = function (name, def) {
      var v = parseFloat(get(name, String(def)));
      return isNaN(v) ? def : v;
    };
    var bool = function (name, def) {
      var v = get(name, def ? 'true' : 'false');
      return v === 'true' || v === 'on';
    };
    return {
      selector:      get('selector', ''),
      stackPos:      num('position', 20),
      stackDist:     num('distance', 20),
      itemDist:      num('item-distance', 150),
      scrub:         get('scrub', '1'),
      ease:          get('ease', 'none'),
      anticipate:    bool('anticipate', false),
      scaleOn:       bool('scale', true),
      baseScale:     num('base-scale', 0.9),
      scalePerCard:  num('scale-per-card', 0.03),
      rotateOn:      bool('rotate', false),
      rotateAmount:  num('rotate-amount', 0),
      blurOn:        bool('blur', false),
      blurAmount:    num('blur-amount', 0),
      opacityOn:     bool('opacity', false),
      opacityAmount: num('opacity-amount', 0),
    };
  }

  function findCards(section, customSel) {
    if (customSel) {
      var custom = section.querySelectorAll(customSel);
      if (custom.length >= 2) return Array.prototype.slice.call(custom);
    }
    var rows = section.querySelectorAll(':scope > .et_pb_row, :scope > .et_pb_row_inner');
    rows = Array.prototype.slice.call(rows);
    if (rows.length >= 2) return rows;
    if (rows.length === 1) {
      var cols = rows[0].querySelectorAll(':scope > .et_pb_column, :scope > .et_pb_column_inner');
      if (cols.length >= 2) return Array.prototype.slice.call(cols);
    }
    return [];
  }

  function absTop(el) {
    return el.getBoundingClientRect().top + window.scrollY;
  }

  function initSection(section) {
    if (section._dnxteSStackInit) return;

    var cfg = readConfig(section);
    var cards = findCards(section, cfg.selector);
    if (cards.length < 2) return;

    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      console.warn('[DnxteSStack] GSAP or ScrollTrigger not loaded');
      return;
    }
    gsap.registerPlugin(ScrollTrigger);
    section._dnxteSStackInit = true;

    // Section: overflow visible so transformed cards don't clip.
    var originalSectionOverflow = section.style.overflow;
    section.style.setProperty('overflow', 'visible', 'important');

    var minH = Math.round(window.innerHeight * 0.5);

    // Snapshot per-card styles we touch so cleanup can restore them.
    // We do NOT touch horizontal-layout properties (width, display, grid) —
    // Divi's Row/Column arrangement stays intact. We only collapse the
    // VERTICAL flow space via negative margin-top so the section isn't left
    // with a tall empty zone where cards used to live.
    var originalCardStyles = cards.map(function (card) {
      return {
        willChange: card.style.willChange,
        backfaceVisibility: card.style.backfaceVisibility,
        transformOrigin: card.style.transformOrigin,
        minHeight: card.style.minHeight,
        transition: card.style.transition,
        zIndex: card.style.zIndex,
        marginTop: card.style.marginTop,
      };
    });

    cards.forEach(function (card, i) {
      card.style.willChange = 'transform, filter, opacity';
      card.style.backfaceVisibility = 'hidden';
      card.style.transformOrigin = 'center top';
      card.style.setProperty('transition', 'none', 'important');
      card.style.zIndex = String(i + 1);
      if (card.offsetHeight < minH) {
        card.style.setProperty('min-height', minH + 'px', 'important');
      }
    });

    // Capture natural heights BEFORE applying negative margins.
    var cardHeights = cards.map(function (c) { return c.offsetHeight; });

    // Collapse cards 1+ vertical flow space via negative margin-top.
    // Each card is pulled up to sit `stackDist` below the previous card's TOP
    // (rather than below its bottom). Section's flow height becomes roughly
    // card0 height + stackDist * (N-1) instead of sum of all card heights.
    // Horizontal layout untouched — only vertical flow.
    cards.forEach(function (card, i) {
      if (i === 0) return;
      var pullUp = cardHeights[i - 1] - cfg.stackDist;
      if (pullUp > 0) {
        card.style.setProperty('margin-top', -pullUp + 'px', 'important');
      }
    });

    // Capture doc-relative offsets AFTER margins are applied.
    // These are small values now (~stackDist per index) since cards overlap.
    var firstTop = absTop(cards[0]);
    var naturalOffsets = cards.map(function (c) { return absTop(c) - firstTop; });

    // ── Timeline with labels (one per card transition) ──────────
    var tl = gsap.timeline();
    tl.addLabel('card1', 0);
    var dur = 0.5;
    var ease = cfg.ease || 'none';

    cards.forEach(function (card, i) {
      if (i === 0) return;
      var prev = cards[i - 1];
      var label = 'card' + (i + 1);
      tl.addLabel(label);

      // Prev card: shrink / rotate / blur / fade (no y-change — holds position)
      var prevTo = { duration: dur, ease: ease };
      if (cfg.scaleOn) {
        prevTo.scale = Math.max(0.5, cfg.baseScale + (i - 1) * cfg.scalePerCard);
      }
      if (cfg.rotateOn && cfg.rotateAmount !== 0) {
        prevTo.rotation = i * cfg.rotateAmount;
      }
      if (cfg.blurOn && cfg.blurAmount > 0) {
        prevTo.filter = 'blur(' + cfg.blurAmount + 'px)';
      }
      if (cfg.opacityOn && cfg.opacityAmount > 0) {
        prevTo.opacity = Math.max(0.1, 1 - cfg.opacityAmount);
      }
      tl.to(prev, prevTo, label);

      // Current card: slide from below viewport UP to overlap position
      // with a small peek of `stackDist` so earlier cards show beneath.
      // Target y = (i * stackDist) - naturalOffset pulls card up to card 0's
      // natural y, offset down by stackDist per stack index.
      var targetY = (i * cfg.stackDist) - naturalOffsets[i];
      tl.fromTo(card,
        { y: function () { return window.innerHeight; } },
        {
          y: function () { return targetY; },
          duration: dur,
          ease: ease,
        },
        label
      );
    });

    tl.addLabel('cardEnd');

    // ── ScrollTrigger: pin + scrub + snap ─────────────────────
    // Trigger off the first card (not the Section) so pin activates precisely
    // when card 0 reaches stackPos from viewport top.
    var scrubVal = cfg.scrub === 'true' ? true : (parseFloat(cfg.scrub) || 1);

    var st = ScrollTrigger.create({
      trigger: cards[0],
      start: 'top ' + cfg.stackPos + '%',
      endTrigger: section,
      end: function () {
        var base = window.innerHeight * (cards.length - 1);
        var extra = cfg.itemDist > 0 ? cfg.itemDist * (cards.length - 1) : 0;
        return '+=' + (base + extra);
      },
      pin: section,
      pinSpacing: true,
      scrub: scrubVal,
      snap: {
        snapTo: 'labels',
        duration: { min: 0.2, max: 0.6 },
        ease: 'power1.inOut',
        delay: 0.05,
      },
      animation: tl,
      anticipatePin: cfg.anticipate ? 1 : 0,
      invalidateOnRefresh: true,
    });

    section._dnxteSStackCleanup = function () {
      if (st) st.kill();
      tl.kill();
      section.style.overflow = originalSectionOverflow;
      cards.forEach(function (card, i) {
        var o = originalCardStyles[i];
        card.style.willChange = o.willChange;
        card.style.backfaceVisibility = o.backfaceVisibility;
        card.style.transformOrigin = o.transformOrigin;
        card.style.minHeight = o.minHeight;
        card.style.transition = o.transition;
        card.style.zIndex = o.zIndex;
        card.style.marginTop = o.marginTop;
        card.style.transform = '';
        card.style.filter = '';
        card.style.opacity = '';
      });
      section._dnxteSStackInit = false;
    };
  }

  function initAll() {
    var els = document.querySelectorAll('[data-sstack-init="true"]');
    Array.prototype.forEach.call(els, initSection);
  }

  function boot() {
    initAll();
    if (document.body) {
      var obs = new MutationObserver(function (muts) {
        var hasNew = false;
        for (var i = 0; i < muts.length; i++) {
          if (muts[i].addedNodes && muts[i].addedNodes.length) { hasNew = true; break; }
        }
        if (hasNew) initAll();
      });
      obs.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
