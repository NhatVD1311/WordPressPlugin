/**
 * Social Proof — Read More / Read Less toggle for truncated review text.
 *
 * The server renders truncated text in .dnxte-sp-review__text and stores the
 * full/short variants on the button's data attributes (RenderCallbackTrait).
 * textContent is used for the swap, so the values are never parsed as HTML.
 */
(function () {
	'use strict';

	document.addEventListener('click', function (e) {
		var btn = e.target && e.target.closest ? e.target.closest('.dnxte-sp-readmore') : null;
		if (!btn) {
			return;
		}

		var content = btn.closest('.dnxte-sp-review__content');
		var textEl = content ? content.querySelector('.dnxte-sp-review__text') : null;
		if (!textEl) {
			return;
		}

		var expanded = btn.getAttribute('data-expanded') === 'true';
		textEl.textContent = expanded ? btn.getAttribute('data-short') : btn.getAttribute('data-full');
		btn.setAttribute('data-expanded', expanded ? 'false' : 'true');
		btn.textContent = expanded ? btn.getAttribute('data-more-label') : btn.getAttribute('data-less-label');
	});
})();
