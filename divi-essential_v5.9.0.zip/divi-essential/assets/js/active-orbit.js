(function ($) {
  "use strict";

  const carouselInstances = new Map();
  const observerInstances = new Map();

  function initOrbitCarousel(orbitEl) {
    const orbitId = orbitEl.dataset.orbitId;

    // Destroy existing instance
    if (carouselInstances.has(orbitId)) {
      carouselInstances.get(orbitId).destroy?.();
    }

    const instance = new OrbitCarousel(orbitEl, {
      radius: orbitEl.dataset.radius,
      thumbSize: orbitEl.dataset.thumbSize,
      animation: orbitEl.dataset.animation,
      layout: orbitEl.dataset.layout,
      mode: orbitEl.dataset.mode,
      inactiveThumbOpacity: orbitEl.dataset.inactiveThumbOpacity,
      tooltip: {
        enabled: orbitEl.dataset.tooltip === "on",
        placement: "auto",
        animation: "shift-away",
        arrow: true,
        delay: [100, 0],
        duration: [275, 250],
      },
      autoplay:
        orbitEl.dataset.autoplay === "on"
          ? {
              delay: orbitEl.dataset.delay,
              pauseOnMouseEnter: orbitEl.dataset.pauseOnHover === "on",
            }
          : false,
      pagination: orbitEl.dataset.usePagination === "on" && {
        el: ".orbit-pagination-" + orbitId,
        clickable: true,
      },
      navigation: orbitEl.dataset.useArrowNavigation === "on" && {
        nextEl: ".orbit-button-next-" + orbitId,
        prevEl: ".orbit-button-prev-" + orbitId,
      },
      loop: orbitEl.dataset.loop === "on",
    });

    carouselInstances.set(orbitId, instance);
  }

  function setupObserver(orbitEl) {
    const orbitId = orbitEl.dataset.orbitId;

    // Don't create duplicate observers
    if (observerInstances.has(orbitId)) {
      return;
    }

    let debounceTimer;

    const observer = new MutationObserver((mutations) => {
      // Debounce to avoid multiple reinits
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        initOrbitCarousel(orbitEl);
      }, 100);
    });

    observer.observe(orbitEl, {
      attributes: true,
      attributeFilter: [
        "data-radius",
        "data-thumb-size",
        "data-animation",
        "data-layout",
        "data-mode",
        "data-inactive-thumb-opacity",
        "data-autoplay",
        "data-delay",
        "data-pause-on-hover",
        "data-use-pagination",
        "data-use-arrow-navigation",
        "data-loop",
        "data-tooltip",
      ],
    });

    observerInstances.set(orbitId, observer);
  }

  function initAllCarousels() {
    const orbitElements = document.querySelectorAll(".orbit_slider_active");

    if (!orbitElements.length) {
      console.warn("No elements found for Orbit.");
      return;
    }

    orbitElements.forEach((orbitEl) => {
      if (!orbitEl) return;
      initOrbitCarousel(orbitEl);
      setupObserver(orbitEl);
    });
  }

  // Initialize on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAllCarousels);
  } else {
    initAllCarousels();
  }

  // Also initialize on window load (for late-loaded content)
  window.addEventListener("load", initAllCarousels);
})(jQuery);
