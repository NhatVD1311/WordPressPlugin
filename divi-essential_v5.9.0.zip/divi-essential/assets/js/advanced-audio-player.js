/**
 * NextAdvancedAudioPlayer — Frontend initialization.
 *
 * Zero-dependency HTML5 Audio API player.
 * Reads configuration from data-* attributes on .dnxte-audio-player-wrapper.
 */
(function () {
  'use strict';

  /**
   * Format seconds into a time string.
   *
   * @param {number} secs       Total seconds.
   * @param {string} timeFormat 'mm_ss' or 'hh_mm_ss'.
   * @returns {string}
   */
  function formatTime(secs, timeFormat) {
    if (isNaN(secs) || secs < 0) return '0:00';
    var h = Math.floor(secs / 3600);
    var m = Math.floor((secs % 3600) / 60);
    var s = Math.floor(secs % 60);
    if (timeFormat === 'hh_mm_ss' || h > 0) {
      return h + ':' + pad(m) + ':' + pad(s);
    }
    return m + ':' + pad(s);
  }

  function pad(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  /**
   * Initialize a single audio player wrapper.
   *
   * @param {HTMLElement} wrapper
   */
  function initAudioPlayer(wrapper) {
    if (wrapper.dataset.initialized) return;
    wrapper.dataset.initialized = 'true';

    // Read config from data-* attributes.
    var audioUrl      = wrapper.dataset.audioUrl || '';
    var timeFormat    = wrapper.dataset.timeFormat || 'mm_ss';
    var skipBack      = parseInt(wrapper.dataset.skipBack || '15', 10);
    var skipForward   = parseInt(wrapper.dataset.skipForward || '30', 10);
    var primaryColor  = wrapper.dataset.primaryColor || '#2098d1';
    var progressFill  = wrapper.dataset.progressFill || '#2098d1';
    var progressTrack = wrapper.dataset.progressTrack || '#e0e0e0';
    var progressBuffer= wrapper.dataset.progressBuffer || '#b0b0b0';
    var progressHeight= wrapper.dataset.progressHeight || '4';
    var enableSticky  = wrapper.dataset.enableSticky === 'on';
    var stickyPos     = wrapper.dataset.stickyPosition || 'bottom_bar';
    var preload       = wrapper.dataset.preload || 'metadata';

    if (!audioUrl) return;

    // Create <audio> element.
    var audio         = new Audio();
    audio.src         = audioUrl;
    audio.preload     = preload;

    // DOM references.
    var playBtn       = wrapper.querySelector('.dnxte-audio-play-btn');
    var iconPlay      = wrapper.querySelector('.dnxte-audio-icon-play');
    var iconPause     = wrapper.querySelector('.dnxte-audio-icon-pause');
    var progressBar   = wrapper.querySelector('.dnxte-audio-progress-bar');
    var progressFillEl= wrapper.querySelector('.dnxte-audio-progress-fill');
    var progressBufEl = wrapper.querySelector('.dnxte-audio-progress-buffer');
    var currentTimeEl = wrapper.querySelector('.dnxte-audio-current-time');
    var durationEl    = wrapper.querySelector('.dnxte-audio-duration');
    var volumeSlider  = wrapper.querySelector('.dnxte-audio-volume-slider');
    var muteBtn       = wrapper.querySelector('.dnxte-audio-mute-btn');
    var speedSelect   = wrapper.querySelector('.dnxte-audio-speed-select');
    var skipBackBtn   = wrapper.querySelector('.dnxte-audio-skip-back');
    var skipFwdBtn    = wrapper.querySelector('.dnxte-audio-skip-forward');

    // — — — — — Play state — — — — —
    function setPlayState(playing) {
      if (iconPlay)  iconPlay.style.display  = playing ? 'none' : '';
      if (iconPause) iconPause.style.display = playing ? '' : 'none';
      if (playBtn) {
        playBtn.setAttribute('aria-label', playing ? 'Pause' : 'Play');
        playing ? playBtn.classList.add('is-playing') : playBtn.classList.remove('is-playing');
      }
    }

    // — — — — — Progress — — — — —
    function updateProgress() {
      if (!audio.duration) return;
      var pct = (audio.currentTime / audio.duration) * 100;
      if (progressFillEl) progressFillEl.style.width = pct + '%';
      if (currentTimeEl)  currentTimeEl.textContent  = formatTime(audio.currentTime, timeFormat);
    }

    function updateBuffer() {
      if (!audio.duration || !audio.buffered.length) return;
      var buffered = (audio.buffered.end(audio.buffered.length - 1) / audio.duration) * 100;
      if (progressBufEl) progressBufEl.style.width = buffered + '%';
    }

    // — — — — — Event bindings — — — — —
    if (playBtn) {
      playBtn.addEventListener('click', function () {
        if (audio.paused) {
          audio.play();
        } else {
          audio.pause();
        }
      });
    }

    audio.addEventListener('play',  function () { setPlayState(true); });
    audio.addEventListener('pause', function () { setPlayState(false); });
    audio.addEventListener('ended', function () {
      setPlayState(false);
      audio.currentTime = 0;
      updateProgress();
    });
    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('progress',   updateBuffer);
    audio.addEventListener('loadedmetadata', function () {
      if (durationEl) durationEl.textContent = formatTime(audio.duration, timeFormat);
    });

    // Progress bar — click to seek.
    if (progressBar) {
      var seeking = false;

      function seekTo(e) {
        var rect = progressBar.getBoundingClientRect();
        var pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        if (audio.duration) {
          audio.currentTime = pct * audio.duration;
        }
      }

      progressBar.addEventListener('mousedown', function (e) {
        seeking = true;
        seekTo(e);
      });
      document.addEventListener('mousemove', function (e) {
        if (seeking) seekTo(e);
      });
      document.addEventListener('mouseup', function () {
        seeking = false;
      });

      // Touch support.
      progressBar.addEventListener('touchstart', function (e) {
        seeking = true;
        seekTo(e.touches[0]);
      }, { passive: true });
      document.addEventListener('touchmove', function (e) {
        if (seeking) seekTo(e.touches[0]);
      }, { passive: true });
      document.addEventListener('touchend', function () {
        seeking = false;
      });
    }

    // Volume slider.
    if (volumeSlider) {
      audio.volume = parseFloat(volumeSlider.value) / 100;
      volumeSlider.addEventListener('input', function () {
        audio.volume = this.value / 100;
        audio.muted  = false;
        updateMuteIcon();
      });
    }

    // Mute button.
    function updateMuteIcon() {
      if (!muteBtn) return;
      var isMuted = audio.muted || audio.volume === 0;
      muteBtn.setAttribute('aria-label', isMuted ? 'Unmute' : 'Mute');
      muteBtn.innerHTML = isMuted
        ? '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>'
        : '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z"/></svg>';
    }

    if (muteBtn) {
      muteBtn.addEventListener('click', function () {
        audio.muted = !audio.muted;
        updateMuteIcon();
      });
    }

    // Playback speed.
    if (speedSelect) {
      speedSelect.addEventListener('change', function () {
        audio.playbackRate = parseFloat(this.value);
      });
    }

    // Skip buttons.
    if (skipBackBtn) {
      skipBackBtn.addEventListener('click', function () {
        audio.currentTime = Math.max(0, audio.currentTime - skipBack);
      });
    }
    if (skipFwdBtn) {
      skipFwdBtn.addEventListener('click', function () {
        if (audio.duration) {
          audio.currentTime = Math.min(audio.duration, audio.currentTime + skipForward);
        }
      });
    }

    // Keyboard accessibility on progress bar.
    if (progressBar) {
      progressBar.setAttribute('tabindex', '0');
      progressBar.addEventListener('keydown', function (e) {
        if (!audio.duration) return;
        if (e.key === 'ArrowRight') {
          audio.currentTime = Math.min(audio.duration, audio.currentTime + 5);
        } else if (e.key === 'ArrowLeft') {
          audio.currentTime = Math.max(0, audio.currentTime - 5);
        }
      });
    }

    // — — — — — Sticky player — — — — —
    if (enableSticky) {
      var stickyClone = null;

      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (!entry.isIntersecting) {
              // Module scrolled out of view — show sticky clone.
              if (!stickyClone) {
                stickyClone = wrapper.cloneNode(true);
                stickyClone.classList.add(
                  'dnxte-audio-sticky',
                  'dnxte-sticky-' + stickyPos
                );
                // Reset init flag so clone initializes its own audio.
                delete stickyClone.dataset.initialized;
                document.body.appendChild(stickyClone);
                initAudioPlayer(stickyClone);

                // Sync playback state to the original audio.
                var cloneAudio = stickyClone.querySelector('audio');
                if (cloneAudio) {
                  cloneAudio.src = audioUrl;
                  if (!audio.paused) cloneAudio.play();
                }
              } else {
                stickyClone.style.display = '';
              }
            } else {
              if (stickyClone) {
                stickyClone.style.display = 'none';
              }
            }
          });
        },
        { threshold: 0.1 }
      );

      observer.observe(wrapper);
    }
  }

  /**
   * Initialize all audio players on the page.
   */
  function initAll() {
    var wrappers = document.querySelectorAll('.dnxte-audio-player-wrapper');
    wrappers.forEach(initAudioPlayer);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

})();
