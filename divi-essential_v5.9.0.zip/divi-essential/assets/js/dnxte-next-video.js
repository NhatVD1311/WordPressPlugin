/**
 * NextVideo — Frontend initialization.
 *
 * Handles: overlay play (self-hosted + embed), poster facade, lightbox,
 * sticky player, lazy load, and IntersectionObserver-based sticky triggers.
 */
(function () {
  'use strict';

  // ── Helpers ────────────────────────────────────────────────────────────────

  function qs(el, sel) { return el.querySelector(sel); }

  /**
   * Sanitize an embed URL — remove end=0 / start=0 params that would cause
   * the player to restart immediately (blinking), and ensure mute is present
   * when autoplay is set (required by browser autoplay policies).
   */
  function sanitizeEmbedUrl(src) {
    if (!src) return src;
    try {
      var url = new URL(src);
      // Remove end=0 and start=0 — they cause the video to end/start at 0s.
      if (url.searchParams.get('end') === '0') url.searchParams.delete('end');
      if (url.searchParams.get('start') === '0') url.searchParams.delete('start');
      // Ensure mute is present when autoplay is set (browser policy).
      if (url.searchParams.get('autoplay') === '1') {
        var host = url.hostname.toLowerCase();
        if (host.indexOf('youtube.com') !== -1 && !url.searchParams.has('mute')) {
          url.searchParams.set('mute', '1');
        }
        if (host === 'player.vimeo.com' && !url.searchParams.has('muted')) {
          url.searchParams.set('muted', '1');
        }
      }
      return url.toString();
    } catch (e) {
      return src;
    }
  }

  /**
   * Create an iframe element for embed playback.
   */
  function createEmbedIframe(src) {
    var el = document.createElement('iframe');
    el.className = 'dnxte-next-video__iframe';
    el.src = sanitizeEmbedUrl(src);
    el.setAttribute('allowfullscreen', 'allowfullscreen');
    el.setAttribute('allow', 'autoplay; encrypted-media');
    return el;
  }

  /**
   * Remove all child nodes from an element (safe, no innerHTML).
   */
  function clearChildren(el) {
    while (el.firstChild) el.removeChild(el.firstChild);
  }

  // ── Core player init ───────────────────────────────────────────────────────

  function initVideoModule(container) {
    if (container.dataset.videoInit) return;
    container.dataset.videoInit = 'true';

    var videoType       = container.dataset.videoType || 'self_hosted';
    var embedUrl        = container.dataset.embedUrl || '';
    var enableLightbox  = container.dataset.enableLightbox === 'on';
    var triggerType     = container.dataset.triggerType || 'overlay_click';
    var enableSticky    = container.dataset.enableSticky === 'on';
    var pauseOnMin      = container.dataset.pauseOnMinimize === 'on';
    var lazyLoad        = container.dataset.lazyLoad === 'on';
    var autoplay        = container.dataset.autoplay === 'on';

    var wrapper         = qs(container, '.dnxte-next-video__wrapper');
    var video           = qs(container, '.dnxte-next-video__video');
    var iframe          = qs(container, '.dnxte-next-video__iframe');
    var overlay         = qs(container, '.dnxte-next-video__overlay');
    var playBtn         = qs(container, '.dnxte-next-video__play-btn');
    var lightbox        = qs(container, '.dnxte-next-video__lightbox');
    var lightboxInner   = lightbox ? qs(lightbox, '.dnxte-next-video__lightbox-inner') : null;
    var lightboxClose   = lightbox ? qs(lightbox, '.dnxte-next-video__lightbox-close') : null;
    var lightboxTrigger = qs(container, '.dnxte-next-video__lightbox-trigger');
    var stickyEl        = qs(container, '.dnxte-next-video__sticky');
    var stickyClose     = stickyEl ? qs(stickyEl, '.dnxte-next-video__sticky-close') : null;

    // Move lightbox to document.body so position:fixed works correctly
    // (avoids issues with parent transform/will-change breaking fixed position).
    if (lightbox) {
      document.body.appendChild(lightbox);
    }

    // ── Poster facade for embed URLs (click to load iframe) ──────────────────
    var facade = qs(container, '.dnxte-next-video__embed-facade');
    if (facade) {
      facade.addEventListener('click', function () {
        var src = facade.getAttribute('data-embed-src') || embedUrl;
        if (!src) return;
        clearChildren(facade);
        facade.classList.remove('dnxte-next-video__embed-facade');
        var newIframe = createEmbedIframe(src);
        facade.appendChild(newIframe);
        iframe = newIframe;
      });

      // Autoplay: bypass facade and load iframe immediately (no overlay).
      if (autoplay && !overlay) {
        var src = facade.getAttribute('data-embed-src') || embedUrl;
        if (src) {
          clearChildren(facade);
          facade.classList.remove('dnxte-next-video__embed-facade');
          var newIframe = createEmbedIframe(src);
          facade.appendChild(newIframe);
          iframe = newIframe;
        }
      }
    }

    // ── Start/end time for self-hosted videos ────────────────────────────────
    var startTimeSec = parseInt(container.dataset.startTime, 10) || 0;
    var endTimeSec   = parseInt(container.dataset.endTime, 10)   || 0;

    if (video && startTimeSec > 0) {
      video.addEventListener('loadedmetadata', function () {
        if (video.currentTime < startTimeSec) {
          video.currentTime = startTimeSec;
        }
      }, { once: true });
    }

    if (video && endTimeSec > 0) {
      video.addEventListener('timeupdate', function () {
        if (video.currentTime >= endTimeSec) {
          video.pause();
          video.currentTime = startTimeSec || 0;
        }
      });
    }

    // ── Lazy load ────────────────────────────────────────────────────────────
    if (lazyLoad && video) {
      video.setAttribute('preload', 'none');
    }

    // ── Overlay click → play video / open lightbox ───────────────────────────
    function handlePlayAction() {
      // Lightbox takes priority if enabled with overlay trigger.
      if (enableLightbox && triggerType === 'overlay_click') {
        openLightbox();
        return;
      }

      // Hide overlay.
      if (overlay) overlay.style.display = 'none';

      // Self-hosted: just play the video.
      if (video) {
        video.play().catch(function () {});
        return;
      }

      // Embed URL: load iframe if not already loaded (facade was showing).
      if (videoType === 'embed_url' && embedUrl) {
        var embedWrapper = qs(container, '.dnxte-next-video__embed-wrapper');
        if (embedWrapper && !qs(embedWrapper, '.dnxte-next-video__iframe')) {
          clearChildren(embedWrapper);
          embedWrapper.classList.remove('dnxte-next-video__embed-facade');
          var newIframe = createEmbedIframe(embedUrl);
          embedWrapper.appendChild(newIframe);
          iframe = newIframe;
        }
      }
    }

    if (playBtn) playBtn.addEventListener('click', handlePlayAction);
    if (overlay) {
      overlay.addEventListener('click', handlePlayAction);
    }

    // ── Whole-module lightbox trigger ─────────────────────────────────────────
    if (lightboxTrigger) {
      lightboxTrigger.addEventListener('click', openLightbox);
    }
    if (enableLightbox && triggerType === 'whole_module') {
      if (wrapper) wrapper.style.cursor = 'pointer';
      if (wrapper) {
        wrapper.addEventListener('click', function (e) {
          if (e.target === playBtn || (playBtn && playBtn.contains(e.target))) return;
          openLightbox();
        });
      }
    }

    // ── Lightbox ─────────────────────────────────────────────────────────────
    function openLightbox() {
      if (!lightbox || !lightboxInner) return;

      // Pause the inline video if playing.
      if (video && !video.paused) video.pause();

      clearChildren(lightboxInner);

      if (videoType === 'embed_url') {
        // Use the embed URL from data attribute (always available).
        var src = embedUrl || (iframe ? iframe.src : '');
        if (src) {
          lightboxInner.appendChild(createEmbedIframe(src));
        }
      } else if (video) {
        var cloneVideo = video.cloneNode(true);
        cloneVideo.controls = true;
        cloneVideo.autoplay = true;
        lightboxInner.appendChild(cloneVideo);
      }

      // Move lightbox to body so it escapes any overflow/transform
      // stacking contexts from parent modules.
      document.body.appendChild(lightbox);

      lightbox.setAttribute('aria-hidden', 'false');
      lightbox.classList.add('is-open');
      document.body.classList.add('dnxte-lightbox-open');
    }

    function closeLightbox() {
      if (!lightbox || !lightboxInner) return;
      clearChildren(lightboxInner);
      lightbox.setAttribute('aria-hidden', 'true');
      lightbox.classList.remove('is-open');
      document.body.classList.remove('dnxte-lightbox-open');
      // Move lightbox back into the module container.
      container.appendChild(lightbox);
    }

    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);

    // Close on backdrop click.
    if (lightbox) {
      lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLightbox();
      });
    }

    // Close on Escape.
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && lightbox && lightbox.classList.contains('is-open')) {
        closeLightbox();
      }
    });

    // ── Sticky player ────────────────────────────────────────────────────────
    // Move sticky element to document.body so position:fixed escapes any
    // parent stacking contexts (transform, will-change, etc.) created by
    // Divi sections/rows. Same pattern used for the lightbox above.
    if (enableSticky && stickyEl) {
      document.body.appendChild(stickyEl);
    }

    if (enableSticky && stickyEl && wrapper && typeof IntersectionObserver !== 'undefined') {
      // The movable element is either the <video> (self-hosted) or
      // the embed wrapper containing the iframe (embed_url).
      var embedWrapper = qs(container, '.dnxte-next-video__embed-wrapper');

      /**
       * Get the element that should be moved into / out of sticky.
       * For embed_url: only move if an iframe has been loaded (user clicked).
       */
      function getStickyTarget() {
        if (video) return video;
        if (videoType === 'embed_url' && embedWrapper && qs(embedWrapper, '.dnxte-next-video__iframe')) {
          return embedWrapper;
        }
        return null;
      }

      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            var visible = entry.isIntersecting;
            var target = getStickyTarget();

            // Only activate sticky when there's a playable target.
            if (!target) {
              stickyEl.setAttribute('aria-hidden', 'true');
              stickyEl.classList.remove('is-active');
              return;
            }

            stickyEl.setAttribute('aria-hidden', visible ? 'true' : 'false');
            stickyEl.classList.toggle('is-active', !visible);

            if (!visible) {
              // Scrolled out of view → move target to sticky container.
              if (!stickyEl.contains(target)) {
                stickyEl.appendChild(target);

                if (video) {
                  video.controls = true;
                  if (pauseOnMin) {
                    video.pause();
                  } else {
                    video.muted = true;
                    video.play().catch(function () {});
                  }
                }
              }
            } else {
              // Scrolled back into view → return target to inline wrapper.
              if (stickyEl.contains(target)) {
                wrapper.appendChild(target);
              }
            }
          });
        },
        { threshold: 0.15 }
      );

      observer.observe(wrapper);

      if (stickyClose) {
        stickyClose.addEventListener('click', function () {
          var target = getStickyTarget();
          if (target && stickyEl.contains(target)) {
            wrapper.appendChild(target);
            if (video && pauseOnMin) video.pause();
          }
          stickyEl.classList.remove('is-active');
          stickyEl.setAttribute('aria-hidden', 'true');
          observer.disconnect();
        });
      }
    }
  }

  // ── Init all ───────────────────────────────────────────────────────────────

  function initAll() {
    document.querySelectorAll('.dnxte-next-video-container').forEach(function (c) {
      initVideoModule(c);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

})();
