/**
 * Tooltip — Frontend Runtime
 * Hover/click tooltips with smart positioning, arrow, animations, full styling control.
 * Pure vanilla JS, no dependencies.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  // Inject base styles once
  function ensureStyles() {
    if (document.getElementById('dnxte-tooltip-css')) return;
    var s = document.createElement('style');
    s.id = 'dnxte-tooltip-css';
    s.textContent = [
      '.dnxte-tooltip{position:fixed;z-index:999999;pointer-events:none;line-height:1.4;white-space:normal;word-wrap:break-word;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:13px;color:#ffffff;box-sizing:border-box}',
      '.dnxte-tooltip.dnxte-tooltip-clickable{pointer-events:auto}',
      '.dnxte-tooltip a{color:inherit;text-decoration:underline}',
      '.dnxte-tooltip strong,.dnxte-tooltip b{font-weight:700}',
      '.dnxte-tooltip em,.dnxte-tooltip i{font-style:italic}',
      '.dnxte-tooltip-arrow{position:absolute;width:0;height:0}',
      // Animations
      '.dnxte-tooltip[data-anim="fade"]{opacity:0;transition:opacity 0.2s ease-out}',
      '.dnxte-tooltip[data-anim="fade"].dnxte-tooltip-show{opacity:1}',
      '.dnxte-tooltip[data-anim="scale"]{opacity:0;transform:scale(0.8);transition:opacity 0.2s ease-out,transform 0.2s ease-out}',
      '.dnxte-tooltip[data-anim="scale"].dnxte-tooltip-show{opacity:1;transform:scale(1)}',
      '.dnxte-tooltip[data-anim="slide"]{opacity:0;transition:opacity 0.2s ease-out,transform 0.2s ease-out}',
      '.dnxte-tooltip[data-anim="slide"].dnxte-tooltip-show{opacity:1;transform:translate(0,0)!important}',
      '.dnxte-tooltip[data-anim="none"]{transition:none}',
    ].join('\n');
    document.head.appendChild(s);
  }

  function num(v, def) {
    var n = parseFloat(v);
    return isNaN(n) ? def : n;
  }

  function attr(el, name, def) {
    var v = el.getAttribute(name);
    return (v === null || v === '') ? def : v;
  }

  function DnxteTooltip(el) {
    this.el = el;
    this._tooltip = null;
    this._arrow = null;
    this._listeners = [];
    this._docClickHandler = null;
    this._destroyed = false;

    // ─── Read all data attributes ───
    this.text       = el.getAttribute('data-dnxte-tooltip') || '';
    this.position   = attr(el, 'data-tooltip-position', 'top');
    this.trigger    = attr(el, 'data-tooltip-trigger', 'hover');
    this.animation  = attr(el, 'data-tooltip-animation', 'fade');

    // Background
    this.bg         = attr(el, 'data-tooltip-bg', '#1e293b');

    // Typography — full CSS string from the native divi/font group (built in PHP).
    // Applied inline because the tooltip lives on <body>, away from the module.
    this.fontCss = el.getAttribute('data-tooltip-font-css') || '';

    // Box
    this.paddingY     = num(el.getAttribute('data-tooltip-padding-y'), 6);
    this.paddingX     = num(el.getAttribute('data-tooltip-padding-x'), 12);
    this.maxWidth     = num(el.getAttribute('data-tooltip-max-width'), 250);
    this.borderRadius = num(el.getAttribute('data-tooltip-border-radius'), 6);

    // Border
    this.borderWidth = num(el.getAttribute('data-tooltip-border-width'), 0);
    this.borderColor = attr(el, 'data-tooltip-border-color', '#000000');

    // Arrow
    this.showArrow  = el.getAttribute('data-tooltip-arrow') !== 'false';
    this.arrowSize  = num(el.getAttribute('data-tooltip-arrow-size'), 5);

    // Box shadow (from divi/box-shadow group, parsed in PHP into single CSS string)
    this.shadowCss  = el.getAttribute('data-tooltip-shadow') || '';

    if (!this.text) return;

    this._target = this._findTarget(el);
    this._init();
  }

  var proto = DnxteTooltip.prototype;

  proto._findTarget = function (el) {
    var btn = el.querySelector('a.et_pb_button, a.dnxte-btn, button, a[href]');
    if (btn) return btn;
    var img = el.querySelector('img, .et_pb_image_wrap');
    if (img) return img;
    var inner = el.querySelector('.et_pb_blurb_content, .et_pb_main_blurb_image');
    if (inner) return inner;
    return el;
  };

  proto._gap = function () {
    return this.showArrow ? this.arrowSize : 6;
  };

  proto._init = function () {
    var self = this;
    var target = this._target;
    ensureStyles();

    if (this.trigger === 'click') {
      var onClick = function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (self._tooltip) self._hide();
        else self._show();
      };
      target.addEventListener('click', onClick);
      this._listeners.push({ el: target, evt: 'click', fn: onClick });

      this._docClickHandler = function (e) {
        if (!self._tooltip) return;
        if (target.contains(e.target)) return;
        if (self._tooltip.contains(e.target)) return;
        self._hide();
      };
      document.addEventListener('click', this._docClickHandler);

      var onEsc = function (e) {
        if (e.key === 'Escape' && self._tooltip) self._hide();
      };
      document.addEventListener('keydown', onEsc);
      this._listeners.push({ el: document, evt: 'keydown', fn: onEsc });
    } else {
      var onEnter = function () { self._show(); };
      var onLeave = function () { self._hide(); };
      target.addEventListener('mouseenter', onEnter);
      target.addEventListener('mouseleave', onLeave);
      this._listeners.push({ el: target, evt: 'mouseenter', fn: onEnter });
      this._listeners.push({ el: target, evt: 'mouseleave', fn: onLeave });

      target.addEventListener('focus', onEnter);
      target.addEventListener('blur', onLeave);
      this._listeners.push({ el: target, evt: 'focus', fn: onEnter });
      this._listeners.push({ el: target, evt: 'blur', fn: onLeave });
    }
  };

  proto._createTooltip = function () {
    var tip = document.createElement('div');
    tip.className = 'dnxte-tooltip';
    if (this.trigger === 'click') tip.classList.add('dnxte-tooltip-clickable');
    tip.setAttribute('data-anim', this.animation);
    tip.innerHTML = this.text;

    // Background
    tip.style.backgroundColor = this.bg;

    // Typography — apply the font group's CSS string inline (font-family,
    // weight, size, color, letter-spacing, line-height, alignment…).
    if (this.fontCss) {
      tip.style.cssText += ';' + this.fontCss;
    }

    // Box
    tip.style.padding = this.paddingY + 'px ' + this.paddingX + 'px';
    tip.style.maxWidth = this.maxWidth + 'px';
    tip.style.borderRadius = this.borderRadius + 'px';

    // Border
    if (this.borderWidth > 0) {
      tip.style.border = this.borderWidth + 'px solid ' + this.borderColor;
    } else {
      tip.style.border = 'none';
    }

    // Box Shadow (full CSS string from divi/box-shadow group)
    if (this.shadowCss && this.shadowCss !== 'none') {
      tip.style.boxShadow = this.shadowCss;
    } else {
      tip.style.boxShadow = 'none';
    }

    if (this.showArrow) {
      var arrow = document.createElement('div');
      arrow.className = 'dnxte-tooltip-arrow';
      tip.appendChild(arrow);
      this._arrow = arrow;
    }

    document.body.appendChild(tip);
    this._tooltip = tip;
    return tip;
  };

  proto._resolvePosition = function (pos, elRect, tipRect) {
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var gap = this._gap();

    var fits = {
      top:    elRect.top - tipRect.height - gap > 0,
      bottom: elRect.bottom + tipRect.height + gap < vh,
      left:   elRect.left - tipRect.width - gap > 0,
      right:  elRect.right + tipRect.width + gap < vw,
    };

    if (pos === 'auto') {
      if (fits.top) return 'top';
      if (fits.bottom) return 'bottom';
      if (fits.right) return 'right';
      if (fits.left) return 'left';
      return 'top';
    }

    if (!fits[pos]) {
      var opposite = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
      if (fits[opposite[pos]]) return opposite[pos];
    }

    return pos;
  };

  proto._positionTooltip = function (tip, pos, elRect, tipRect) {
    var x, y;
    var vw = window.innerWidth;
    var gap = this._gap();

    switch (pos) {
      case 'top':
        x = elRect.left + elRect.width / 2 - tipRect.width / 2;
        y = elRect.top - tipRect.height - gap;
        break;
      case 'bottom':
        x = elRect.left + elRect.width / 2 - tipRect.width / 2;
        y = elRect.bottom + gap;
        break;
      case 'left':
        x = elRect.left - tipRect.width - gap;
        y = elRect.top + elRect.height / 2 - tipRect.height / 2;
        break;
      case 'right':
        x = elRect.right + gap;
        y = elRect.top + elRect.height / 2 - tipRect.height / 2;
        break;
    }

    x = Math.max(5, Math.min(x, vw - tipRect.width - 5));
    y = Math.max(5, y);

    tip.style.left = x + 'px';
    tip.style.top  = y + 'px';

    // ─── Arrow positioning ───
    // Arrow box is (arrowSize * 2) tall/wide (border-based). Visible triangle is half.
    // Overlap 1px with tooltip to kill sub-pixel rendering gap.
    if (this._arrow) {
      var arrow = this._arrow;
      var a = this.arrowSize;
      var offset = (a * 2) - 1;

      arrow.style.cssText = 'position:absolute;width:0;height:0;border:' + a + 'px solid transparent;';

      switch (pos) {
        case 'top':
          arrow.style.bottom = -offset + 'px';
          arrow.style.left = '50%';
          arrow.style.transform = 'translateX(-50%)';
          arrow.style.borderTopColor = this.bg;
          break;
        case 'bottom':
          arrow.style.top = -offset + 'px';
          arrow.style.left = '50%';
          arrow.style.transform = 'translateX(-50%)';
          arrow.style.borderBottomColor = this.bg;
          break;
        case 'left':
          arrow.style.right = -offset + 'px';
          arrow.style.top = '50%';
          arrow.style.transform = 'translateY(-50%)';
          arrow.style.borderLeftColor = this.bg;
          break;
        case 'right':
          arrow.style.left = -offset + 'px';
          arrow.style.top = '50%';
          arrow.style.transform = 'translateY(-50%)';
          arrow.style.borderRightColor = this.bg;
          break;
      }
    }

    if (this.animation === 'slide') {
      var sOff = { top: '0,5px', bottom: '0,-5px', left: '5px,0', right: '-5px,0' };
      tip.style.transform = 'translate(' + (sOff[pos] || '0,0') + ')';
    }
  };

  proto._show = function () {
    var self = this;
    if (this._tooltip) this._hide();

    var tip = this._createTooltip();
    var elRect = this._target.getBoundingClientRect();

    requestAnimationFrame(function () {
      if (self._destroyed || !self._tooltip) return;
      var tipRect = tip.getBoundingClientRect();
      var pos = self._resolvePosition(self.position, elRect, tipRect);
      self._positionTooltip(tip, pos, elRect, tipRect);

      requestAnimationFrame(function () {
        if (self._tooltip) self._tooltip.classList.add('dnxte-tooltip-show');
      });
    });
  };

  proto._hide = function () {
    var self = this;
    if (!this._tooltip) return;
    var tip = this._tooltip;
    tip.classList.remove('dnxte-tooltip-show');

    var delay = this.animation === 'none' ? 0 : 250;
    setTimeout(function () {
      if (tip.parentNode) tip.parentNode.removeChild(tip);
      if (self._tooltip === tip) {
        self._tooltip = null;
        self._arrow = null;
      }
    }, delay);
  };

  proto.destroy = function () {
    this._destroyed = true;
    this._hide();
    this._listeners.forEach(function (l) {
      try { l.el.removeEventListener(l.evt, l.fn); } catch (e) {}
    });
    this._listeners = [];
    if (this._docClickHandler) {
      document.removeEventListener('click', this._docClickHandler);
      this._docClickHandler = null;
    }
  };

  function initAll() {
    var els = document.querySelectorAll('[data-dnxte-tooltip]');
    els.forEach(function (el) {
      if (el._dnxteTooltip) return;
      el._dnxteTooltip = new DnxteTooltip(el);
    });
  }

  function boot() {
    initAll();
    if (document.body) {
      var observer = new MutationObserver(function (mutations) {
        var shouldInit = false;
        mutations.forEach(function (m) {
          if (m.addedNodes && m.addedNodes.length) shouldInit = true;
        });
        if (shouldInit) initAll();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.DnxteTooltip = DnxteTooltip;
})();
