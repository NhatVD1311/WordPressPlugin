(function(global) {
  'use strict';

  // ── SVG Icons ──
  var playIcon = '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg>';
  var pauseIcon = '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="3" width="4" height="18"/><rect x="15" y="3" width="4" height="18"/></svg>';
  var muteIcon = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.5 12A4.5 4.5 0 0014 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.796 8.796 0 0021 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 003.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>';
  var unmuteIcon = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05c1.48-.73 2.5-2.25 2.5-3.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>';

  // ── YouTube API loader (shared across instances) ──
  var ytAPIReady = false;
  var ytAPILoading = false;
  var ytReadyCallbacks = [];

  function loadYouTubeAPI() {
    return new Promise(function(resolve) {
      if (global.YT && global.YT.Player) {
        resolve();
        return;
      }

      ytReadyCallbacks.push(resolve);

      if (ytAPILoading) {
        return;
      }

      ytAPILoading = true;

      var existingCallback = global.onYouTubeIframeAPIReady;
      global.onYouTubeIframeAPIReady = function() {
        ytAPIReady = true;
        if (existingCallback) {
          existingCallback();
        }
        var cbs = ytReadyCallbacks.slice();
        ytReadyCallbacks = [];
        cbs.forEach(function(cb) { cb(); });
      };

      var script = document.createElement('script');
      script.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(script);
    });
  }

  // ── Vimeo API loader (shared across instances) ──
  var vimeoAPILoading = false;
  var vimeoReadyCallbacks = [];

  function loadVimeoAPI() {
    return new Promise(function(resolve) {
      if (global.Vimeo && global.Vimeo.Player) {
        resolve();
        return;
      }

      vimeoReadyCallbacks.push(resolve);

      if (vimeoAPILoading) {
        return;
      }

      vimeoAPILoading = true;

      var script = document.createElement('script');
      script.src = 'https://player.vimeo.com/api/player.js';
      script.onload = function() {
        var cbs = vimeoReadyCallbacks.slice();
        vimeoReadyCallbacks = [];
        cbs.forEach(function(cb) { cb(); });
      };
      document.head.appendChild(script);
    });
  }

  // ── Mobile detection ──
  function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || global.innerWidth < 768;
  }

  // ── Reduced motion check ──
  function prefersReducedMotion() {
    return global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  // ── Helper: camelCase to kebab-case ──
  function toKebab(str) {
    return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
  }

  // ── Helper: parse data attributes ──
  function parseDataAttrs(el) {
    var result = {};
    var attrs = el.attributes;
    for (var i = 0; i < attrs.length; i++) {
      var attr = attrs[i];
      if (attr.name.indexOf('data-video-') === 0) {
        var key = attr.name.slice(11); // remove 'data-video-'
        // Convert kebab-case to camelCase
        var camelKey = key.replace(/-([a-z])/g, function(m, c) { return c.toUpperCase(); });
        var val = attr.value;

        // Auto-parse booleans and numbers
        if (val === 'true') val = true;
        else if (val === 'false') val = false;
        else if (val !== '' && !isNaN(Number(val)) && camelKey !== 'youtubeId' && camelKey !== 'vimeoId') val = Number(val);

        result[camelKey] = val;
      }
    }
    return result;
  }

  // ── Default options ──
  var DEFAULTS = {
    sourceType: 'self-hosted',
    videoUrl: '',
    youtubeId: '',
    vimeoId: '',
    fallbackImage: '',

    autoplay: true,
    loop: true,
    muted: true,
    startTime: 0,
    endTime: 0,
    playbackSpeed: 1,

    playInViewport: true,
    pauseOutOfView: true,
    stopAfterFirstPlay: false,

    disableOnMobile: false,
    mobileBehavior: 'image',

    lazyLoad: true,
    preload: 'metadata',

    reducedMotion: true,
    pauseInactiveTab: true,

    overlayType: 'none',
    overlayColor: 'rgba(0,0,0,0.4)',
    overlayGradient: 'linear-gradient(180deg, rgba(0,0,0,0.2), rgba(0,0,0,0.8))',
    overlayOpacity: 1,

    objectFit: 'cover',

    brightness: 100,
    contrast: 100,
    saturation: 100,
    blur: 0,

    scrollEffect: 'none',
    scrollIntensity: 1,

    showControls: false,
    controlsPosition: 'bottom-right',
    controlIconSize: 20,
    controlIconColor: '#ffffff',
    controlBgColor: 'rgba(0,0,0,0.5)'
  };

  // ── Constructor ──
  function DnxteVideoBackground(element, options) {
    if (!element || !element.nodeType) {
      return;
    }

    this.el = element;
    this.videoEl = null;
    this.ytPlayer = null;
    this.vimeoPlayer = null;
    this.bgContainer = null;
    this.overlayEl = null;
    this.controlsEl = null;
    this.observer = null;
    this.scrollTriggerInstance = null;
    this.isPlaying = false;
    this.isMuted = true;
    this.isInView = false;
    this.isDestroyed = false;
    this.hasPlayedOnce = false;
    this._boundHandleVisibility = null;
    this._boundHandleEndTime = null;
    this._boundResize = null;

    // Merge: defaults < data attributes < passed options
    var dataOpts = parseDataAttrs(element);
    this.options = {};
    var self = this;
    Object.keys(DEFAULTS).forEach(function(key) {
      if (options && options[key] !== undefined) {
        self.options[key] = options[key];
      } else if (dataOpts[key] !== undefined) {
        self.options[key] = dataOpts[key];
      } else {
        self.options[key] = DEFAULTS[key];
      }
    });

    this.isMuted = this.options.muted;

    // Force IDs to string to prevent number precision loss
    this.options.youtubeId = String(this.options.youtubeId || '');
    this.options.vimeoId = String(this.options.vimeoId || '');

    // Auto-extract IDs from full URLs
    var yt = this.options.youtubeId;
    if (yt && yt.indexOf('youtu') !== -1) {
      var ytMatch = yt.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/);
      if (ytMatch) this.options.youtubeId = ytMatch[1];
    }

    var vm = this.options.vimeoId;
    if (vm && vm.indexOf('vimeo') !== -1) {
      var vmMatch = vm.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if (vmMatch) this.options.vimeoId = vmMatch[1];
    }

    this._init();
  }

  var proto = DnxteVideoBackground.prototype;

  // ── Init ──
  proto._init = function() {
    // Check reduced motion
    if (this.options.reducedMotion && prefersReducedMotion()) {
      this._showFallback();
      return;
    }

    // Check mobile
    if (isMobileDevice() && this.options.disableOnMobile) {
      if (this.options.mobileBehavior === 'image') {
        this._showFallback();
        return;
      } else if (this.options.mobileBehavior === 'hide') {
        return;
      }
      // 'play' falls through to normal init
    }

    // Ensure element has position relative and overflow hidden
    var elStyle = global.getComputedStyle(this.el);
    if (elStyle.position === 'static') {
      this.el.style.position = 'relative';
    }
    this.el.style.overflow = 'hidden';

    // Create background container
    this.bgContainer = document.createElement('div');
    this.bgContainer.className = 'dnxte-video-bg';
    this.bgContainer.style.cssText = 'position:absolute;top:0;left:0;right:0;bottom:0;z-index:0;overflow:hidden;pointer-events:none;';

    // Insert as first child
    this.el.insertBefore(this.bgContainer, this.el.firstChild);

    // Init based on source type
    var sourceType = this.options.sourceType;
    if (sourceType === 'youtube' && this.options.youtubeId) {
      this._initYouTube();
    } else if (sourceType === 'vimeo' && this.options.vimeoId) {
      this._initVimeo();
    } else if (this.options.videoUrl) {
      this._initSelfHosted();
    } else {
      this._showFallback();
      return;
    }

    // Create overlay
    if (this.options.overlayType !== 'none') {
      this._createOverlay();
    }

    // Create controls
    if (this.options.showControls) {
      this._createControls();
    }

    // Setup viewport observer
    if (this.options.playInViewport || this.options.pauseOutOfView) {
      this._setupViewport();
    }

    // Setup scroll effects
    if (this.options.scrollEffect !== 'none') {
      this._setupScrollEffect();
    }

    // Setup tab visibility
    if (this.options.pauseInactiveTab) {
      this._setupTabVisibility();
    }
  };

  // ── Fallback image ──
  proto._showFallback = function() {
    if (!this.options.fallbackImage) {
      return;
    }

    var elStyle = global.getComputedStyle(this.el);
    if (elStyle.position === 'static') {
      this.el.style.position = 'relative';
    }
    this.el.style.overflow = 'hidden';

    var fallback = document.createElement('div');
    fallback.className = 'dnxte-video-bg dnxte-video-bg--fallback';
    fallback.style.cssText = 'position:absolute;top:0;left:0;right:0;bottom:0;z-index:0;' +
      'background-image:url(' + this.options.fallbackImage + ');' +
      'background-size:cover;background-position:center;';
    this.el.insertBefore(fallback, this.el.firstChild);
    this.bgContainer = fallback;

    if (this.options.overlayType !== 'none') {
      this._createOverlay();
    }
  };

  // ── Self-hosted video ──
  proto._initSelfHosted = function() {
    var self = this;
    var opts = this.options;

    var video = document.createElement('video');
    video.setAttribute('playsinline', '');
    video.setAttribute('webkit-playsinline', '');

    if (opts.muted) {
      video.setAttribute('muted', '');
      video.muted = true;
    }
    if (opts.loop) {
      video.setAttribute('loop', '');
    }
    if (opts.preload) {
      video.setAttribute('preload', opts.preload);
    }
    if (opts.fallbackImage) {
      video.setAttribute('poster', opts.fallbackImage);
    }

    video.style.cssText = 'width:100%;height:100%;object-fit:' + opts.objectFit + ';display:block;';

    var source = document.createElement('source');
    source.src = opts.videoUrl;
    source.type = 'video/mp4';
    video.appendChild(source);

    this.bgContainer.appendChild(video);
    this.videoEl = video;

    // Apply filters
    this._applyFilters();

    // Playback speed
    video.playbackRate = Math.max(0.25, Math.min(2, opts.playbackSpeed));

    // Start time
    if (opts.startTime > 0) {
      video.currentTime = opts.startTime;
    }

    // End time handling
    if (opts.endTime > 0) {
      this._boundHandleEndTime = function() {
        if (video.currentTime >= opts.endTime) {
          if (opts.loop) {
            video.currentTime = opts.startTime || 0;
            video.play().catch(function() {});
          } else {
            video.pause();
          }
        }
      };
      video.addEventListener('timeupdate', this._boundHandleEndTime);
    }

    // Stop after first play
    if (opts.stopAfterFirstPlay) {
      video.addEventListener('ended', function() {
        self.hasPlayedOnce = true;
        self.isPlaying = false;
        self._updateControlIcons();
      });
    }

    // Autoplay
    if (opts.autoplay && (!opts.playInViewport || this.isInView)) {
      video.play().catch(function() {});
      this.isPlaying = true;
    }

    // Lazy load handling
    if (opts.lazyLoad && opts.playInViewport) {
      // Will be handled by viewport observer
    }
  };

  // ── YouTube ──
  proto._initYouTube = function() {
    var self = this;
    var opts = this.options;

    // Create wrapper for cover scaling
    var wrapper = document.createElement('div');
    wrapper.className = 'dnxte-video-yt-wrap';
    wrapper.style.cssText = 'position:absolute;top:50%;left:50%;width:100vw;height:56.25vw;' +
      'min-height:100%;min-width:177.78vh;transform:translate(-50%,-50%);pointer-events:none;';

    var playerDiv = document.createElement('div');
    playerDiv.id = 'dnxte-yt-' + Math.random().toString(36).slice(2, 10);
    wrapper.appendChild(playerDiv);
    this.bgContainer.appendChild(wrapper);

    this._ytWrapper = wrapper;

    // Apply filters to wrapper
    this._applyFilters();

    loadYouTubeAPI().then(function() {
      if (self.isDestroyed) return;

      var startSeconds = opts.startTime || 0;
      var endSeconds = opts.endTime || undefined;

      self.ytPlayer = new YT.Player(playerDiv.id, {
        videoId: opts.youtubeId,
        playerVars: {
          autoplay: opts.autoplay ? 1 : 0,
          controls: 0,
          showinfo: 0,
          rel: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          disablekb: 1,
          fs: 0,
          playsinline: 1,
          loop: opts.loop ? 1 : 0,
          playlist: opts.loop ? opts.youtubeId : undefined,
          start: startSeconds || undefined,
          end: endSeconds,
          mute: opts.muted ? 1 : 0,
          origin: global.location.origin
        },
        events: {
          onReady: function(event) {
            var player = event.target;
            player.setPlaybackRate(Math.max(0.25, Math.min(2, opts.playbackSpeed)));

            if (opts.muted) {
              player.mute();
            }

            // Resize iframe to fill wrapper
            var iframe = player.getIframe();
            iframe.style.cssText = 'width:100%;height:100%;border:0;pointer-events:none;';

            if (opts.autoplay && (!opts.playInViewport || self.isInView)) {
              player.playVideo();
              self.isPlaying = true;
            }
          },
          onStateChange: function(event) {
            if (event.data === YT.PlayerState.ENDED) {
              if (opts.stopAfterFirstPlay) {
                self.hasPlayedOnce = true;
                self.isPlaying = false;
                self._updateControlIcons();
              } else if (opts.loop) {
                event.target.seekTo(opts.startTime || 0);
                event.target.playVideo();
              }
            }
            if (event.data === YT.PlayerState.PLAYING) {
              self.isPlaying = true;
              self._updateControlIcons();
            }
            if (event.data === YT.PlayerState.PAUSED) {
              self.isPlaying = false;
              self._updateControlIcons();
            }
          }
        }
      });
    });
  };

  // ── Vimeo ──
  proto._initVimeo = function() {
    var self = this;
    var opts = this.options;

    // Create wrapper for cover scaling
    var wrapper = document.createElement('div');
    wrapper.className = 'dnxte-video-vimeo-wrap';
    wrapper.style.cssText = 'position:absolute;top:50%;left:50%;width:100vw;height:56.25vw;' +
      'min-height:100%;min-width:177.78vh;transform:translate(-50%,-50%);pointer-events:none;';

    var playerDiv = document.createElement('div');
    wrapper.appendChild(playerDiv);
    this.bgContainer.appendChild(wrapper);

    this._vimeoWrapper = wrapper;

    // Apply filters to wrapper
    this._applyFilters();

    // Build Vimeo iframe URL directly (works for ALL Vimeo videos, no API dependency)
    var vimeoId = String(opts.vimeoId).replace(/\D/g, ''); // ensure only digits
    if (!vimeoId) { self._showFallback(); return; }

    var iframeSrc = 'https://player.vimeo.com/video/' + vimeoId +
      '?autoplay=1&muted=1&loop=' + (opts.loop ? '1' : '0') +
      '&controls=0&title=0&byline=0&portrait=0&background=1' +
      '&playsinline=1&dnt=1';

    if (opts.startTime > 0) iframeSrc += '#t=' + opts.startTime + 's';

    var iframe = document.createElement('iframe');
    iframe.src = iframeSrc;
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');
    iframe.setAttribute('allowfullscreen', '');
    iframe.style.cssText = 'width:100%;height:100%;border:0;pointer-events:none;';
    wrapper.appendChild(iframe);

    // Also try Vimeo Player API for advanced controls (optional, non-blocking)
    loadVimeoAPI().then(function() {
      if (self.isDestroyed) return;

      try {
        self.vimeoPlayer = new Vimeo.Player(iframe);

        self.vimeoPlayer.ready().then(function() {
          if (self.isDestroyed) return;

          if (opts.muted) {
            self.vimeoPlayer.setVolume(0).catch(function() {});
          }

          if (opts.autoplay && (!opts.playInViewport || self.isInView)) {
            self.vimeoPlayer.play().catch(function() {});
            self.isPlaying = true;
          }
        }).catch(function() {});
      } catch(e) {}
    }).catch(function() {});
  };

  // ── Viewport observer ──
  proto._setupViewport = function() {
    var self = this;

    if ('IntersectionObserver' in global) {
      this.observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          self.isInView = entry.isIntersecting;

          if (entry.isIntersecting) {
            if (self.options.stopAfterFirstPlay && self.hasPlayedOnce) {
              return;
            }
            self._play();
          } else if (self.options.pauseOutOfView) {
            self._pause();
          }
        });
      }, {
        threshold: 0.1
      });

      this.observer.observe(this.el);
    }
  };

  // ── Play/Pause helpers ──
  proto._play = function() {
    if (this.isDestroyed) return;

    var opts = this.options;

    if (opts.sourceType === 'self-hosted' && this.videoEl) {
      this.videoEl.play().catch(function() {});
      this.isPlaying = true;
    } else if (opts.sourceType === 'youtube' && this.ytPlayer && this.ytPlayer.playVideo) {
      this.ytPlayer.playVideo();
      this.isPlaying = true;
    } else if (opts.sourceType === 'vimeo' && this.vimeoPlayer) {
      this.vimeoPlayer.play().catch(function() {});
      this.isPlaying = true;
    }

    this._updateControlIcons();
  };

  proto._pause = function() {
    if (this.isDestroyed) return;

    var opts = this.options;

    if (opts.sourceType === 'self-hosted' && this.videoEl) {
      this.videoEl.pause();
      this.isPlaying = false;
    } else if (opts.sourceType === 'youtube' && this.ytPlayer && this.ytPlayer.pauseVideo) {
      this.ytPlayer.pauseVideo();
      this.isPlaying = false;
    } else if (opts.sourceType === 'vimeo' && this.vimeoPlayer) {
      this.vimeoPlayer.pause().catch(function() {});
      this.isPlaying = false;
    }

    this._updateControlIcons();
  };

  // ── Scroll effects ──
  proto._setupScrollEffect = function() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    var self = this;
    var opts = this.options;
    var effect = opts.scrollEffect;
    var intensity = Math.max(0.5, Math.min(2, opts.scrollIntensity));
    var target = this.bgContainer;
    var videoTarget = this.videoEl || this._ytWrapper || this._vimeoWrapper || target;

    switch (effect) {
      case 'parallax':
        this.scrollTriggerInstance = gsap.to(target, {
          y: (20 * intensity) + '%',
          ease: 'none',
          scrollTrigger: {
            trigger: this.el,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true
          }
        });
        break;

      case 'fade':
        this.scrollTriggerInstance = gsap.fromTo(target, {
          opacity: 0
        }, {
          opacity: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: this.el,
            start: 'top bottom',
            end: 'center center',
            scrub: true
          }
        });
        break;

      case 'zoom':
        this.scrollTriggerInstance = gsap.fromTo(videoTarget, {
          scale: 1 + (0.5 * intensity)
        }, {
          scale: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: this.el,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true
          }
        });
        break;

      case 'blur-clear':
        var maxBlur = 20 * intensity;
        this.scrollTriggerInstance = ScrollTrigger.create({
          trigger: this.el,
          start: 'top bottom',
          end: 'center center',
          scrub: true,
          onUpdate: function(st) {
            var blurVal = maxBlur - (st.progress * maxBlur);
            target.style.filter = self._buildFilterString(blurVal);
          }
        });
        break;

      case 'clip-reveal':
        this.scrollTriggerInstance = gsap.fromTo(target, {
          clipPath: 'circle(0% at 50% 50%)'
        }, {
          clipPath: 'circle(100% at 50% 50%)',
          ease: 'none',
          scrollTrigger: {
            trigger: this.el,
            start: 'top bottom',
            end: 'center center',
            scrub: true
          }
        });
        break;

      case 'scrub':
        // Only works with self-hosted video
        if (opts.sourceType === 'self-hosted' && this.videoEl) {
          var video = this.videoEl;
          // Pause autoplay for scrub mode
          video.pause();
          this.isPlaying = false;

          video.addEventListener('loadedmetadata', function() {
            self.scrollTriggerInstance = ScrollTrigger.create({
              trigger: self.el,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
              onUpdate: function(st) {
                var duration = video.duration || 0;
                if (duration > 0) {
                  var startT = opts.startTime || 0;
                  var endT = opts.endTime > 0 ? opts.endTime : duration;
                  video.currentTime = startT + (st.progress * (endT - startT));
                }
              }
            });
          });
        }
        break;
    }
  };

  // ── Overlay ──
  proto._createOverlay = function() {
    var opts = this.options;
    var overlay = document.createElement('div');
    overlay.className = 'dnxte-video-overlay';

    var bg = '';
    if (opts.overlayType === 'color') {
      bg = opts.overlayColor;
    } else if (opts.overlayType === 'gradient') {
      bg = opts.overlayGradient;
    }

    var bgProp = opts.overlayType === 'gradient' ? 'background-image' : 'background-color';

    overlay.style.cssText = 'position:absolute;top:0;left:0;right:0;bottom:0;z-index:1;' +
      bgProp + ':' + bg + ';' +
      'opacity:' + opts.overlayOpacity + ';pointer-events:none;';

    this.bgContainer.appendChild(overlay);
    this.overlayEl = overlay;
  };

  // ── Controls UI ──
  proto._createControls = function() {
    var self = this;
    var opts = this.options;

    var controls = document.createElement('div');
    controls.className = 'dnxte-video-controls';

    // Position mapping
    var posStyles = {
      'bottom-right': 'bottom:15px;right:15px;',
      'bottom-left': 'bottom:15px;left:15px;',
      'bottom-center': 'bottom:15px;left:50%;transform:translateX(-50%);',
      'top-right': 'top:15px;right:15px;'
    };

    controls.style.cssText = 'position:absolute;z-index:10;display:flex;gap:8px;' +
      (posStyles[opts.controlsPosition] || posStyles['bottom-right']);

    // Play/Pause button
    var playBtn = document.createElement('button');
    playBtn.className = 'dnxte-video-btn dnxte-video-btn--play';
    playBtn.setAttribute('aria-label', 'Play/Pause');
    playBtn.setAttribute('type', 'button');
    playBtn.style.cssText = this._controlBtnStyle();
    playBtn.innerHTML = this.isPlaying ? pauseIcon : playIcon;
    this._playBtn = playBtn;

    playBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      if (self.isPlaying) {
        self._pause();
      } else {
        self._play();
      }
    });

    // Mute button
    var muteBtn = document.createElement('button');
    muteBtn.className = 'dnxte-video-btn dnxte-video-btn--mute';
    muteBtn.setAttribute('aria-label', 'Mute/Unmute');
    muteBtn.setAttribute('type', 'button');
    muteBtn.style.cssText = this._controlBtnStyle();
    muteBtn.innerHTML = this.isMuted ? muteIcon : unmuteIcon;
    this._muteBtn = muteBtn;

    muteBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      self._toggleMute();
    });

    controls.appendChild(playBtn);
    controls.appendChild(muteBtn);
    this.el.appendChild(controls);
    this.controlsEl = controls;
  };

  proto._controlBtnStyle = function() {
    var opts = this.options;
    var size = opts.controlIconSize + 16; // padding around icon
    return 'display:flex;align-items:center;justify-content:center;' +
      'width:' + size + 'px;height:' + size + 'px;' +
      'border:none;border-radius:4px;cursor:pointer;' +
      'background:' + opts.controlBgColor + ';' +
      'color:' + opts.controlIconColor + ';' +
      'padding:0;pointer-events:auto;transition:opacity 0.2s;' +
      'opacity:0.8;';
  };

  proto._updateControlIcons = function() {
    if (this._playBtn) {
      this._playBtn.innerHTML = this.isPlaying ? pauseIcon : playIcon;
    }
    if (this._muteBtn) {
      this._muteBtn.innerHTML = this.isMuted ? muteIcon : unmuteIcon;
    }
  };

  proto._toggleMute = function() {
    var opts = this.options;
    this.isMuted = !this.isMuted;

    if (opts.sourceType === 'self-hosted' && this.videoEl) {
      this.videoEl.muted = this.isMuted;
    } else if (opts.sourceType === 'youtube' && this.ytPlayer) {
      if (this.isMuted) {
        this.ytPlayer.mute();
      } else {
        this.ytPlayer.unMute();
      }
    } else if (opts.sourceType === 'vimeo' && this.vimeoPlayer) {
      this.vimeoPlayer.setMuted(this.isMuted).catch(function() {});
    }

    this._updateControlIcons();
  };

  // ── Filters ──
  proto._applyFilters = function() {
    var filterStr = this._buildFilterString();
    var target = this.videoEl || this._ytWrapper || this._vimeoWrapper;
    if (target) {
      target.style.filter = filterStr;
    }
  };

  proto._buildFilterString = function(overrideBlur) {
    var opts = this.options;
    var parts = [];

    if (opts.brightness !== 100) {
      parts.push('brightness(' + (opts.brightness / 100) + ')');
    }
    if (opts.contrast !== 100) {
      parts.push('contrast(' + (opts.contrast / 100) + ')');
    }
    if (opts.saturation !== 100) {
      parts.push('saturate(' + (opts.saturation / 100) + ')');
    }

    var blurVal = overrideBlur !== undefined ? overrideBlur : opts.blur;
    if (blurVal > 0) {
      parts.push('blur(' + blurVal + 'px)');
    }

    return parts.length > 0 ? parts.join(' ') : 'none';
  };

  // ── Tab visibility ──
  proto._setupTabVisibility = function() {
    var self = this;
    this._boundHandleVisibility = function() {
      if (self.isDestroyed) return;

      if (document.visibilityState === 'hidden') {
        if (self.isPlaying) {
          self._pause();
          self._pausedByTab = true;
        }
      } else if (document.visibilityState === 'visible') {
        if (self._pausedByTab && self.isInView) {
          if (!(self.options.stopAfterFirstPlay && self.hasPlayedOnce)) {
            self._play();
          }
          self._pausedByTab = false;
        }
      }
    };

    document.addEventListener('visibilitychange', this._boundHandleVisibility);
  };

  // ── Destroy ──
  proto.destroy = function() {
    this.isDestroyed = true;

    // Disconnect viewport observer
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }

    // Kill ScrollTrigger
    if (this.scrollTriggerInstance) {
      if (this.scrollTriggerInstance.scrollTrigger) {
        this.scrollTriggerInstance.scrollTrigger.kill();
      } else if (this.scrollTriggerInstance.kill) {
        this.scrollTriggerInstance.kill();
      }
      this.scrollTriggerInstance = null;
    }

    // Destroy YouTube player
    if (this.ytPlayer) {
      try {
        this.ytPlayer.destroy();
      } catch (e) {}
      this.ytPlayer = null;
    }

    // Destroy Vimeo player
    if (this.vimeoPlayer) {
      try {
        this.vimeoPlayer.destroy();
      } catch (e) {}
      this.vimeoPlayer = null;
    }

    // Remove video element and end time listener
    if (this.videoEl) {
      if (this._boundHandleEndTime) {
        this.videoEl.removeEventListener('timeupdate', this._boundHandleEndTime);
      }
      this.videoEl.pause();
      this.videoEl.removeAttribute('src');
      this.videoEl.load();
      this.videoEl = null;
    }

    // Remove tab visibility listener
    if (this._boundHandleVisibility) {
      document.removeEventListener('visibilitychange', this._boundHandleVisibility);
      this._boundHandleVisibility = null;
    }

    // Remove DOM elements
    if (this.bgContainer && this.bgContainer.parentNode) {
      this.bgContainer.parentNode.removeChild(this.bgContainer);
      this.bgContainer = null;
    }

    if (this.controlsEl && this.controlsEl.parentNode) {
      this.controlsEl.parentNode.removeChild(this.controlsEl);
      this.controlsEl = null;
    }

    this.overlayEl = null;
    this._playBtn = null;
    this._muteBtn = null;
    this._ytWrapper = null;
    this._vimeoWrapper = null;

    // Clean up reference on element
    if (this.el && this.el._dnxteVideo === this) {
      delete this.el._dnxteVideo;
    }
  };

  // ── Auto-init ──
  document.addEventListener('DOMContentLoaded', function() {
    var elements = document.querySelectorAll('[data-video-source-type]');
    for (var i = 0; i < elements.length; i++) {
      elements[i]._dnxteVideo = new DnxteVideoBackground(elements[i], {});
    }
  });

  global.DnxteVideoBackground = DnxteVideoBackground;

})(window);
