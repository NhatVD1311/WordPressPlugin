(function ($) {
    'use strict';

    /**
     * DNXTE Expanding CTA Module
     * Handles scroll-triggered expanding animation, countdown timer,
     * overlay management, and page behavior controls.
     *
     * Architecture (matches Divi Pixel pattern):
     * - Module wrapper (.dnxte-expanding-cta) carries Divi's background.
     *   On expand it gets transform: scale(--ecta-scale) so the background
     *   AND content both scale up.
     * - Overlay effect uses CSS box-shadow (0 0 0 100vmax) on the module
     *   wrapper — no DOM overlay element needed, avoids position:fixed
     *   issues inside a transform context.
     *
     * Z-index strategy:
     * - On expand: bubble z-index + overflow:visible through ALL ancestors
     *   up to <body> (not stopping at section — matches Divi Pixel)
     * - On collapse: two-phase removal (on-top → on-top-removing → clean)
     * - filter: none on ancestors to break stacking contexts
     */

    var Z_CLASS_ON_TOP   = 'dnxte-ecta-on-top';
    var Z_CLASS_REMOVING = 'dnxte-ecta-on-top-removing';
    var BODY_HAS_CTA     = 'dnxte-has-expanding-cta';
    var BODY_EXPANDED    = 'dnxte-ecta-expanded';
    var BODY_HIDE_HEADER = 'dnxte-ecta-hide-header';
    var BODY_HIDE_BTT    = 'dnxte-ecta-hide-btt';
    var BODY_SCROLL_LOCK = 'dnxte-ecta-scroll-locked';

    // ── Z-index helpers (bubble through all ancestors) ──
    // z-index only works on positioned elements (non-static).
    // We set position:relative on static ancestors and track
    // which ones we changed so we can revert on collapse.

    // Bubble z-index ALL the way to <body> (like Divi Pixel).
    // Stopping at et_pb_section is insufficient — sections themselves
    // can be clipped by their parent stacking contexts.

    function setHighZindex(el) {
        while (el && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
            el.classList.add(Z_CLASS_ON_TOP);
            if (window.getComputedStyle(el).position === 'static') {
                el.style.position = 'relative';
                el.setAttribute('data-ecta-pos', '1');
            }
            el = el.parentElement;
        }
    }

    function startRemovingZindex(el) {
        while (el && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
            if (el.classList.contains(Z_CLASS_ON_TOP)) {
                el.classList.remove(Z_CLASS_ON_TOP);
                el.classList.add(Z_CLASS_REMOVING);
            }
            el = el.parentElement;
        }
    }

    function removeZindex(el) {
        while (el && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
            el.classList.remove(Z_CLASS_ON_TOP);
            el.classList.remove(Z_CLASS_REMOVING);
            if (el.getAttribute('data-ecta-pos')) {
                el.style.position = '';
                el.removeAttribute('data-ecta-pos');
            }
            el = el.parentElement;
        }
    }

    class DNXTEExpandingCta {
        constructor(element) {
            this.$container = $(element);
            this.$moduleWrapper = this.$container.closest('.dnxte-expanding-cta');
            this.$body = $('body');
            this.settings = this.getSettings();
            this.isExpanded = false;
            this.observer = null;
            this.countdownInterval = null;
            this.countdownEndTime = null;
            this.lottieAnimation = null;
            this._removeZindexTimer = null;
            this._scrollTriggeredOnce = false;
            this.$bodyOverlay = null;

            if (!this.$moduleWrapper.length) return;

            this.init();
        }

        getSettings() {
            var c = this.$container;
            var easing = c.data('animation-easing') || 'ease';
            var customBezier = c.data('custom-bezier') || '';

            return {
                triggerMode:       c.data('trigger-mode') || 'scroll',
                expandScale:       parseFloat(c.data('expand-scale')) || 1.1,
                animationDuration: parseInt(c.data('animation-duration'), 10) || 600,
                animationEasing:   easing === 'custom' && customBezier
                                       ? 'cubic-bezier(' + customBezier + ')'
                                       : easing,
                viewportOffset:    parseInt(c.data('viewport-offset'), 10) || 30,
                collapseOnExit:    c.data('collapse-on-exit') === 'on',
                triggerOnce:       c.data('trigger-once') === 'on',
                showOverlay:       c.data('show-overlay') === 'on',
                overlayColor:      c.data('overlay-color') || 'rgba(0,0,0,0.5)',
                hideHeader:        c.data('hide-header') === 'on',
                hideBackToTop:     c.data('hide-back-to-top') === 'on',
                disableScroll:     c.data('disable-scroll') === 'on',
                showCountdown:     c.data('show-countdown') === 'on',
                countdownMode:     c.data('countdown-mode') || 'fixed',
                countdownTarget:   c.data('countdown-target') || '',
                evergreenDuration: parseInt(c.data('evergreen-duration'), 10) || 24,
                expiredAction:     c.data('expired-action') || 'hide',
                expiredRedirectUrl: c.data('expired-redirect-url') || '',
                moduleId:          c.data('module-id') || '',
            };
        }

        init() {
            this.$body.addClass(BODY_HAS_CTA);

            this.initCssProperties();
            this.initTrigger();
            this.initOverlay();

            // Overlay click to collapse
            var self = this;
            if (this.settings.showOverlay && this.$bodyOverlay && this.$bodyOverlay.length) {
                this.$bodyOverlay.on('click.ectaOverlay', function() {
                    self.collapse();
                });
            }

            if (this.settings.showCountdown) {
                this.initCountdown();
            }

            this.initLottie();
        }

        // ── CSS Custom Properties ──

        initCssProperties() {
            var wrapper = this.$moduleWrapper[0];
            if (!wrapper) return;

            var scale = this.settings.expandScale;
            if (scale && !isNaN(scale)) {
                wrapper.style.setProperty('--ecta-scale', scale);
            }

            var dur = this.settings.animationDuration + 'ms';
            var ease = this.settings.animationEasing;

            wrapper.style.setProperty('--ecta-duration', dur);
            wrapper.style.setProperty('--ecta-easing', ease);

            // Overlay color for box-shadow overlay effect
            if (this.settings.showOverlay) {
                wrapper.style.setProperty('--ecta-overlay-color', this.settings.overlayColor);
            } else {
                wrapper.style.setProperty('--ecta-overlay-color', 'transparent');
            }

            wrapper.style.willChange = 'transform';
        }

        // ── Trigger Mode Routing ──

        initTrigger() {
            switch (this.settings.triggerMode) {
                case 'scroll':
                    this.initScrollTrigger();
                    break;
                case 'click':
                    this.initClickTrigger();
                    break;
                case 'hover':
                    this.initHoverTrigger();
                    break;
                case 'always':
                    this.expand();
                    break;
            }
        }

        initOverlay() {
            // Visual overlay is handled entirely by CSS box-shadow on the
            // module wrapper — no DOM element needed. We only create a
            // transparent click-catching overlay on <body> for click-to-collapse.
            if (!this.settings.showOverlay) return;

            this.$bodyOverlay = $('<div class="dnxte-ecta-click-catcher"></div>');
            this.$body.append(this.$bodyOverlay);

            var dur = this.settings.animationDuration + 'ms';
            var ease = this.settings.animationEasing;
            this.$bodyOverlay.css({
                'position': 'fixed',
                'top': '0',
                'left': '0',
                'width': '100vw',
                'height': '100vh',
                'z-index': '9998',
                'opacity': '0',
                'visibility': 'hidden',
                'pointer-events': 'none',
                'cursor': 'pointer',
                'transition': 'opacity ' + dur + ' ' + ease + ', visibility ' + dur + ' ' + ease,
            });
        }

        // ── Scroll Trigger (IntersectionObserver) ──

        initScrollTrigger() {
            var self = this;
            var wrapper = this.$moduleWrapper[0];
            if (!wrapper) return;

            // Use viewportOffset to build rootMargin.
            // E.g. offset 30 → '-30% 0px -30% 0px' → center 40% of viewport triggers.
            var offset = Math.min(Math.max(this.settings.viewportOffset, 10), 45);
            var rootMargin = '-' + offset + '% 0px -' + offset + '% 0px';

            this.observer = new IntersectionObserver(function (entries) {
                // Process only the LAST entry — when multiple threshold
                // crossings are batched in one callback, only the final
                // state matters. This prevents the race where "enter" and
                // "exit" arrive together but expand hasn't set isExpanded yet.
                var entry = entries[entries.length - 1];

                if (entry.isIntersecting) {
                    if (!self.isExpanded && !self._scrollTriggeredOnce) {
                        self.expand();

                        if (self.settings.triggerOnce) {
                            self._scrollTriggeredOnce = true;
                            if (self.observer) {
                                self.observer.disconnect();
                                self.observer = null;
                            }
                        }
                    }
                } else {
                    if (self.isExpanded && self.settings.collapseOnExit) {
                        self.collapse();
                    }
                }
            }, {
                rootMargin: rootMargin,
                threshold: 0
            });

            this.observer.observe(wrapper);
        }

        // ── Click Trigger ──

        initClickTrigger() {
            var self = this;
            this.$container.on('click.ectaTrigger', function (e) {
                if ($(e.target).closest('a, button').length && self.isExpanded) {
                    return;
                }
                if (self.isExpanded) {
                    self.collapse();
                } else {
                    self.expand();
                }
            });
        }

        // ── Hover Trigger ──

        initHoverTrigger() {
            var self = this;
            var _hoverTimer = null;
            var _isAnimating = false;

            this.$moduleWrapper.on('mouseenter.ectaTrigger', function () {
                clearTimeout(_hoverTimer);
                if (!self.isExpanded && !_isAnimating) {
                    _isAnimating = true;
                    self.expand();
                    setTimeout(function () { _isAnimating = false; }, self.settings.animationDuration + 50);
                }
            });

            this.$moduleWrapper.on('mouseleave.ectaTrigger', function () {
                clearTimeout(_hoverTimer);
                if (!self.settings.triggerOnce) {
                    var delay = _isAnimating ? self.settings.animationDuration + 50 : 0;
                    _hoverTimer = setTimeout(function () {
                        if (self.isExpanded) {
                            self.collapse();
                        }
                    }, delay);
                }
            });
        }

        // ── Expand / Collapse ──

        expand() {
            if (this.isExpanded) return;
            this.isExpanded = true;

            if (this._removeZindexTimer) {
                clearTimeout(this._removeZindexTimer);
                this._removeZindexTimer = null;
            }

            // Set z-index on ALL ancestors first so overflow:visible is applied
            // before the scale transform enlarges the element
            setHighZindex(this.$moduleWrapper[0]);

            // Add expanded class — triggers transform:scale + box-shadow overlay
            this.$moduleWrapper.addClass('dnxte-expanding-cta--expanded');

            // Show transparent click-catcher overlay
            if (this.$bodyOverlay && this.$bodyOverlay.length) {
                this.$bodyOverlay.css({
                    'opacity': '1',
                    'visibility': 'visible',
                    'pointer-events': 'auto',
                });
            }

            this.applyPageBehaviors();
        }

        collapse() {
            if (!this.isExpanded) return;
            this.isExpanded = false;

            // Remove expanded class — triggers reverse animation
            this.$moduleWrapper.removeClass('dnxte-expanding-cta--expanded');

            // Hide click-catcher overlay
            if (this.$bodyOverlay && this.$bodyOverlay.length) {
                this.$bodyOverlay.css({
                    'opacity': '0',
                    'visibility': 'hidden',
                    'pointer-events': 'none',
                });
            }

            // Two-phase z-index removal (keeps overflow:visible during collapse)
            startRemovingZindex(this.$moduleWrapper[0]);

            var self = this;
            this._removeZindexTimer = setTimeout(function () {
                removeZindex(self.$moduleWrapper[0]);
                self._removeZindexTimer = null;
            }, self.settings.animationDuration + 100);

            this.removePageBehaviors();
        }

        // ── Page Behaviors ──

        applyPageBehaviors() {
            this.$body.addClass(BODY_EXPANDED);

            if (this.settings.hideHeader) {
                this.$body.addClass(BODY_HIDE_HEADER);
            }
            if (this.settings.hideBackToTop) {
                this.$body.addClass(BODY_HIDE_BTT);
            }
            // Never lock scroll in scroll trigger mode — deadlock
            if (this.settings.disableScroll && this.settings.triggerMode !== 'scroll') {
                this.$body.addClass(BODY_SCROLL_LOCK);
            }
        }

        removePageBehaviors() {
            this.$body.removeClass(BODY_EXPANDED);
            this.$body.removeClass(BODY_HIDE_HEADER);
            this.$body.removeClass(BODY_HIDE_BTT);
            this.$body.removeClass(BODY_SCROLL_LOCK);
        }

        // ── Countdown Timer ──

        initCountdown() {
            this.calculateEndTime();

            if (!this.countdownEndTime) return;

            this.tickCountdown();
            var self = this;
            this.countdownInterval = setInterval(function () {
                self.tickCountdown();
            }, 1000);
        }

        calculateEndTime() {
            if (this.settings.countdownMode === 'fixed') {
                if (this.settings.countdownTarget) {
                    var targetDate = new Date(this.settings.countdownTarget);
                    if (!isNaN(targetDate.getTime())) {
                        this.countdownEndTime = targetDate.getTime();
                    } else {
                        console.warn('Expanding CTA: Invalid fixed countdown date:', this.settings.countdownTarget);
                    }
                }
            } else if (this.settings.countdownMode === 'evergreen') {
                var cookieName = 'dnxte_ecta_' + this.settings.moduleId;
                var saved = this.getCookie(cookieName);

                if (saved && parseInt(saved, 10) > Date.now()) {
                    this.countdownEndTime = parseInt(saved, 10);
                } else {
                    var durationMs = this.settings.evergreenDuration * 60 * 60 * 1000;
                    this.countdownEndTime = Date.now() + durationMs;
                    this.setCookie(cookieName, this.countdownEndTime, this.settings.evergreenDuration);
                }
            }
        }

        tickCountdown() {
            var remaining = this.countdownEndTime - Date.now();

            if (remaining <= 0) {
                this.handleExpiration();
                return;
            }

            var days    = Math.floor(remaining / (1000 * 60 * 60 * 24));
            var hours   = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((remaining % (1000 * 60)) / 1000);

            this.updateCountdownUnit('days', days);
            this.updateCountdownUnit('hours', hours);
            this.updateCountdownUnit('minutes', minutes);
            this.updateCountdownUnit('seconds', seconds);
        }

        updateCountdownUnit(unit, value) {
            var $item = this.$container.find('.next_expanding_cta__countdown-item[data-unit="' + unit + '"]');
            if ($item.length) {
                $item.find('.next_expanding_cta__countdown-number').text(
                    value.toString().padStart(2, '0')
                );
            }
        }

        handleExpiration() {
            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
                this.countdownInterval = null;
            }

            this.updateCountdownUnit('days', 0);
            this.updateCountdownUnit('hours', 0);
            this.updateCountdownUnit('minutes', 0);
            this.updateCountdownUnit('seconds', 0);

            switch (this.settings.expiredAction) {
                case 'hide':
                    this.$moduleWrapper.fadeOut(500);
                    break;

                case 'message':
                    this.$container.find('.next_expanding_cta__countdown').hide();
                    this.$container.find('.next_expanding_cta__expired-message').show();
                    break;

                case 'redirect':
                    if (this.settings.expiredRedirectUrl) {
                        window.location.href = this.settings.expiredRedirectUrl;
                    }
                    break;
            }

            if (this.settings.countdownMode === 'evergreen' && this.settings.moduleId) {
                var cookieName = 'dnxte_ecta_' + this.settings.moduleId;
                document.cookie = cookieName + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
            }
        }

        // ── Cookie Helpers ──

        getCookie(name) {
            var value = '; ' + document.cookie;
            var parts = value.split('; ' + name + '=');
            if (parts.length === 2) {
                return parts.pop().split(';').shift();
            }
            return null;
        }

        setCookie(name, value, hours) {
            var expires = new Date(Date.now() + hours * 60 * 60 * 1000);
            document.cookie = name + '=' + value + '; expires=' + expires.toUTCString() + '; path=/';
        }

        // ── Lottie Initialization ──

        initLottie() {
            var $lottie = this.$container.find('.next_expanding_cta__lottie');
            if (!$lottie.length) return;

            if (typeof window.bodymovin === 'undefined') return;

            var url = $lottie.data('lottie-url');
            if (!url) return;

            this.lottieAnimation = window.bodymovin.loadAnimation({
                container: $lottie[0],
                renderer: 'svg',
                loop: $lottie.data('lottie-loop') !== 'off',
                autoplay: $lottie.data('lottie-autoplay') !== 'off',
                path: url,
            });
        }

        // ── Cleanup ──

        destroy() {
            if (this.observer) {
                this.observer.disconnect();
                this.observer = null;
            }

            if (this._removeZindexTimer) {
                clearTimeout(this._removeZindexTimer);
                this._removeZindexTimer = null;
            }

            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
                this.countdownInterval = null;
            }

            if (this.lottieAnimation) {
                this.lottieAnimation.destroy();
                this.lottieAnimation = null;
            }

            if (this.$bodyOverlay && this.$bodyOverlay.length) {
                this.$bodyOverlay.off('.ectaOverlay');
                this.$bodyOverlay.remove();
            }

            removeZindex(this.$moduleWrapper[0]);
            this.removePageBehaviors();
        }
    }

    // ── Initialization ──

    function initExpandingCtas() {
        $('.dnxte_next_expanding_cta').each(function () {
            if (!$(this).data('dnxte-ecta-initialized')) {
                var instance = new DNXTEExpandingCta(this);
                $(this).data('dnxte-ecta-initialized', true);
                $(this).data('dnxte-ecta-instance', instance);
            }
        });
    }

    $(document).ready(function () {
        initExpandingCtas();
    });

    $(window).on('load', function () {
        initExpandingCtas();
    });

    window.DNXTEExpandingCta = DNXTEExpandingCta;
    window.initDNXTEExpandingCtas = initExpandingCtas;

})(jQuery);
