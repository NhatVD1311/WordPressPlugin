/**
 * Globe3D - Interactive 3D Globe Library
 * Version: 3.0.0
 *
 * Features:
 * - Multiple visual themes (Dark Space, Night Lights, Holographic, Minimal, Political)
 * - Multiple marker styles (Pins, Beams, Ripples, Dots, Pillars)
 * - Multiple connection styles (Dashed, Animated Flow, Gradient, Solid Glow)
 * - Animation modes (Continuous, Focus Tour, Idle Bounce)
 * - Extra features (Heatmap, Region Highlight, Day/Night Cycle, Zoom to Region)
 *
 * Usage:
 * <div data-globe data-theme="dark-space" data-marker-style="pins" ...></div>
 */

(function() {
    'use strict';

    // ============================================
    // TEXTURE URLs
    // ============================================
    // Resolved from window.dnxteGlobe3D.texturesBase (injected by PHP via wp_localize_script).
    // Falls back to the jsdelivr CDN if the base URL is not set, so the globe still
    // renders if the localize step is missing. Local copies of bump/specular are JPG
    // (re-encoded for size); the CDN variants are PNG, so the filename depends on source.
    const CDN_BASE = 'https://cdn.jsdelivr.net/npm/three-globe@2.31.0/example/img/';
    function getTexturesBase() {
        const base = (typeof window !== 'undefined' && window.dnxteGlobe3D && window.dnxteGlobe3D.texturesBase) || '';
        return base || CDN_BASE;
    }
    function tex(localName, cdnName) {
        const base = getTexturesBase();
        const name = (base === CDN_BASE && cdnName) ? cdnName : localName;
        return base + name;
    }
    const TEXTURES = {
        get earth()       { return tex('earth-blue-marble.jpg'); },
        get bump()        { return tex('earth-topology.jpg', 'earth-topology.png'); },
        get specular()    { return tex('earth-water.jpg',    'earth-water.png'); },
        get nightLights() { return tex('earth-night.jpg'); },
        get political()   { return tex('earth-dark.jpg'); }
    };

    // ============================================
    // THEME CONFIGURATIONS
    // ============================================
    const THEMES = {
        'dark-space': {
            name: 'Dark Space',
            globeTexture: TEXTURES.earth,
            showBump: true,
            showSpecular: true,
            showClouds: false,
            showAtmosphere: false,
            atmosphereColor: '#4da6ff',
            atmosphereIntensity: 1.2,
            showStars: true,
            backgroundColor: null,
            globeEmissive: null,
            wireframe: false
        },
        'night-lights': {
            name: 'Night Lights',
            globeTexture: TEXTURES.nightLights,
            showBump: true,
            showSpecular: false,
            showClouds: false,
            showAtmosphere: true,
            atmosphereColor: '#ff9500',
            atmosphereIntensity: 0.8,
            showStars: true,
            backgroundColor: null,
            globeEmissive: '#221100',
            wireframe: false
        },
        'holographic': {
            name: 'Holographic',
            globeTexture: null,
            showBump: false,
            showSpecular: false,
            showClouds: false,
            showAtmosphere: true,
            atmosphereColor: '#00ffff',
            atmosphereIntensity: 1.5,
            showStars: true,
            backgroundColor: null,
            globeColor: '#001a1a',
            globeEmissive: '#003333',
            wireframe: true,
            wireframeColor: '#00ffff',
            wireframeOpacity: 0.6
        },
        'minimal': {
            name: 'Minimal',
            globeTexture: null,
            showBump: false,
            showSpecular: false,
            showClouds: false,
            showAtmosphere: false,
            showStars: false,
            backgroundColor: '#0a0a0a',
            globeColor: '#1a1a2e',
            globeEmissive: '#0a0a1a',
            wireframe: true,
            wireframeColor: '#3b82f6',
            wireframeOpacity: 0.15,
            showDots: true,
            dotsColor: '#4a90d9'
        },
        'political': {
            name: 'Political',
            globeTexture: TEXTURES.political,
            showBump: false,
            showSpecular: false,
            showClouds: false,
            showAtmosphere: true,
            atmosphereColor: '#6366f1',
            atmosphereIntensity: 1.0,
            showStars: true,
            backgroundColor: null,
            globeEmissive: '#1a1a2e'
        }
    };

    // ============================================
    // DEFAULT CONFIGURATION
    // ============================================
    const DEFAULT_CONFIG = {
        theme: 'dark-space',
        globeRadius: 1,
        bumpScale: 0.05,
        markerStyle: 'pins',
        pinHeight: 0.08,
        pinColor: '#f97316',
        beamHeight: 0.3,
        pillarMinHeight: 0.05,
        pillarMaxHeight: 0.4,
        connectionStyle: 'dashed',
        arcColor: '#3b82f6',
        arcColorEnd: '#f97316',
        showArcs: true,
        animationMode: 'continuous',
        autoRotate: true,
        autoRotateSpeed: 0.3,
        tourInterval: 3000,
        bounceAmplitude: 0.1,
        enableZoom: true,
        enablePan: false,
        minDistance: 1.5,
        maxDistance: 4,
        zoomToRegionDistance: 1.8,
        showPulse: true,
        showHeatmap: false,
        heatmapIntensity: 1.0,
        heatmapRadius: 0.15,
        enableRegionHighlight: false,
        showDayNight: false,
        dayNightSpeed: 0.1,
        markerSize: 0.06,
        defaultMarkerSrc: '',
        dotColor: '#4a90d9',
        showDots: false,
        initialLat: 35.6762,
        initialLng: 139.6503
    };

    // ============================================
    // SHADERS
    // ============================================
    const SHADERS = {
        atmosphere: {
            vertex: `
                varying vec3 vNormal;
                varying vec3 vPosition;
                void main() {
                    vNormal = normalize(normalMatrix * normal);
                    vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragment: `
                uniform vec3 glowColor;
                uniform float intensity;
                varying vec3 vNormal;
                varying vec3 vPosition;
                void main() {
                    vec3 viewDir = normalize(-vPosition);
                    float rim = 1.0 - max(0.0, dot(viewDir, vNormal));
                    float glow = pow(rim, 3.0) * intensity;
                    gl_FragColor = vec4(glowColor, glow * 0.6);
                }
            `
        },
        beam: {
            vertex: `
                varying vec2 vUv;
                varying float vHeight;
                void main() {
                    vUv = uv;
                    vHeight = position.y;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragment: `
                uniform vec3 color;
                uniform float time;
                uniform float height;
                varying vec2 vUv;
                varying float vHeight;
                void main() {
                    float normalizedHeight = vHeight / height;
                    float alpha = (1.0 - normalizedHeight) * 0.9;
                    float pulse = sin(time * 4.0 + normalizedHeight * 8.0) * 0.3 + 0.7;
                    float glow = smoothstep(0.0, 0.3, normalizedHeight) * smoothstep(1.0, 0.7, normalizedHeight);
                    gl_FragColor = vec4(color * pulse * 1.5, alpha * glow);
                }
            `
        },
        dayNight: {
            vertex: `
                varying vec3 vNormal;
                varying vec3 vPosition;
                varying vec2 vUv;
                void main() {
                    vNormal = normalize(normalMatrix * normal);
                    vPosition = (modelMatrix * vec4(position, 1.0)).xyz;
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragment: `
                uniform sampler2D dayTexture;
                uniform sampler2D nightTexture;
                uniform vec3 sunDirection;
                varying vec3 vNormal;
                varying vec3 vPosition;
                varying vec2 vUv;
                void main() {
                    vec3 normal = normalize(vNormal);
                    float intensity = dot(normal, sunDirection);
                    intensity = smoothstep(-0.2, 0.3, intensity);
                    vec4 dayColor = texture2D(dayTexture, vUv);
                    vec4 nightColor = texture2D(nightTexture, vUv);
                    nightColor.rgb *= 1.5;
                    gl_FragColor = mix(nightColor, dayColor, intensity);
                }
            `
        }
    };

    const globeInstances = new Map();

    // ============================================
    // GLOBE3D CLASS
    // ============================================
    class Globe3D {
        constructor(container, options = {}) {
            this.container = typeof container === 'string'
                ? document.querySelector(container)
                : container;

            if (!this.container) {
                console.error('Globe3D: Container not found');
                return;
            }

            const dataConfig = this.parseDataAttributes();
            this.config = { ...DEFAULT_CONFIG, ...dataConfig, ...options };
            this.applyTheme();

            this.markers = [];
            this.markerGroups = [];
            this.arcMeshes = [];
            this.pulseRings = [];
            this.labels = [];
            this.beamMeshes = [];
            this.animatedArcs = [];
            this.heatSpots = [];
            this.tourIndex = 0;
            this.tourTimeout = null;
            this.isInitialized = false;

            this.scene = null;
            this.camera = null;
            this.renderer = null;
            this.globeGroup = null;
            this.earthMesh = null;
            this.cloudsMesh = null;
            this.controls = null;
            this.clock = null;
            this.textureLoader = null;
            this.raycaster = null;
            this.mouse = null;

            this.onMarkerClick = options.onMarkerClick || null;
            this.onMarkerHover = options.onMarkerHover || null;

            this.init();
        }

        parseDataAttributes() {
            const config = {};
            const el = this.container;

            if (el.dataset.theme) config.theme = el.dataset.theme;
            if (el.dataset.markerStyle) config.markerStyle = el.dataset.markerStyle;
            if (el.dataset.pinColor) config.pinColor = el.dataset.pinColor;
            if (el.dataset.pinHeight) config.pinHeight = parseFloat(el.dataset.pinHeight);
            if (el.dataset.beamHeight) config.beamHeight = parseFloat(el.dataset.beamHeight);
            if (el.dataset.connectionStyle) config.connectionStyle = el.dataset.connectionStyle;
            if (el.dataset.arcColor) config.arcColor = el.dataset.arcColor;
            if (el.dataset.arcColorEnd) config.arcColorEnd = el.dataset.arcColorEnd;
            if (el.dataset.showArcs !== undefined) config.showArcs = el.dataset.showArcs === 'true';
            if (el.dataset.animationMode) config.animationMode = el.dataset.animationMode;
            if (el.dataset.autoRotate !== undefined) config.autoRotate = el.dataset.autoRotate === 'true';
            if (el.dataset.autoRotateSpeed) config.autoRotateSpeed = parseFloat(el.dataset.autoRotateSpeed);
            if (el.dataset.tourInterval) config.tourInterval = parseInt(el.dataset.tourInterval);
            if (el.dataset.enableZoom !== undefined) config.enableZoom = el.dataset.enableZoom === 'true';
            if (el.dataset.showPulse !== undefined) config.showPulse = el.dataset.showPulse === 'true';
            if (el.dataset.showHeatmap !== undefined) config.showHeatmap = el.dataset.showHeatmap === 'true';
            if (el.dataset.showDayNight !== undefined) config.showDayNight = el.dataset.showDayNight === 'true';
            if (el.dataset.enableRegionHighlight !== undefined) config.enableRegionHighlight = el.dataset.enableRegionHighlight === 'true';
            if (el.dataset.markerSize) config.markerSize = parseFloat(el.dataset.markerSize);
            if (el.dataset.defaultMarkerSrc) config.defaultMarkerSrc = el.dataset.defaultMarkerSrc;
            if (el.dataset.dotColor) config.dotColor = el.dataset.dotColor;
            if (el.dataset.showDots !== undefined) config.showDots = el.dataset.showDots === 'true';
            if (el.dataset.initialLat) config.initialLat = parseFloat(el.dataset.initialLat);
            if (el.dataset.initialLng) config.initialLng = parseFloat(el.dataset.initialLng);

            if (el.dataset.markers) {
                try {
                    config.markersData = JSON.parse(el.dataset.markers);
                } catch (e) {
                    console.error('Globe3D: Invalid markers JSON');
                }
            }

            return config;
        }

        applyTheme() {
            const theme = THEMES[this.config.theme] || THEMES['dark-space'];
            this.theme = { ...theme };
            if (this.config.atmosphereColor) this.theme.atmosphereColor = this.config.atmosphereColor;
            if (this.config.atmosphereIntensity) this.theme.atmosphereIntensity = this.config.atmosphereIntensity;
        }

        async init() {
            if (this.isInitialized) return;

            const THREE = window.THREE;
            if (!THREE) {
                console.error('Globe3D: Three.js is required');
                return;
            }

            this.THREE = THREE;
            this.isInitialized = true;
            this.clock = new THREE.Clock();
            this.textureLoader = new THREE.TextureLoader();
            this.textureLoader.crossOrigin = 'anonymous';

            this.setupScene();
            this.setupLights();
            await this.setupGlobe();
            this.setupControls();
            this.setupInteraction();
            this.applyInitialView();

            if (this.config.markersData) {
                this.setMarkers(this.config.markersData);
            }

            this.animate();

            this._resizeHandler = () => this.handleResize();
            window.addEventListener('resize', this._resizeHandler);

            // Watch container size changes (e.g. MultiView breakpoint switches)
            if (typeof ResizeObserver !== 'undefined') {
                this._resizeObserver = new ResizeObserver(() => this.handleResize());
                this._resizeObserver.observe(this.container);
            }

            this.container.dispatchEvent(new CustomEvent('globe:ready', { detail: this }));
            globeInstances.set(this.container, this);
        }

        setupScene() {
            const THREE = this.THREE;
            const width = this.container.clientWidth;
            const height = this.container.clientHeight;

            this.scene = new THREE.Scene();
            this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
            this.camera.position.z = this.theme.showAtmosphere ? 3.2 : 2.8;

            this.renderer = new THREE.WebGLRenderer({
                antialias: true,
                alpha: true,
                powerPreference: 'high-performance'
            });
            this.renderer.setSize(width, height);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.setClearColor(0x000000, 0);
            this.container.appendChild(this.renderer.domElement);

            this.globeGroup = new THREE.Group();
            this.scene.add(this.globeGroup);

            if (this.config.showDots || this.theme.showStars) {
                this.createStars();
            }
        }

        createStars() {
            const THREE = this.THREE;
            const geometry = new THREE.BufferGeometry();
            const positions = [];

            for (let i = 0; i < 3000; i++) {
                const radius = 50 + Math.random() * 100;
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.acos(2 * Math.random() - 1);
                positions.push(
                    radius * Math.sin(phi) * Math.cos(theta),
                    radius * Math.sin(phi) * Math.sin(theta),
                    radius * Math.cos(phi)
                );
            }

            geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
            const dotColor = this.config.dotColor || '#ffffff';
            const material = new THREE.PointsMaterial({
                color: new THREE.Color(dotColor),
                size: 0.5,
                sizeAttenuation: true
            });
            this.scene.add(new THREE.Points(geometry, material));
        }

        setupLights() {
            const THREE = this.THREE;
            this.scene.add(new THREE.AmbientLight(0xffffff, 0.6));

            this.sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
            this.sunLight.position.set(5, 3, 5);
            this.scene.add(this.sunLight);

            const fillLight = new THREE.DirectionalLight(0x4a90d9, 0.3);
            fillLight.position.set(-5, -3, -5);
            this.scene.add(fillLight);
        }

        async setupGlobe() {
            const THREE = this.THREE;
            const cfg = this.config;
            const theme = this.theme;

            const geometry = new THREE.SphereGeometry(cfg.globeRadius, 64, 64);

            if (cfg.showDayNight) {
                await this.setupDayNightGlobe(geometry);
            } else if (theme.globeTexture) {
                const material = new THREE.MeshPhongMaterial({
                    map: this.textureLoader.load(theme.globeTexture),
                    bumpMap: theme.showBump ? this.textureLoader.load(TEXTURES.bump) : null,
                    bumpScale: cfg.bumpScale,
                    specularMap: theme.showSpecular ? this.textureLoader.load(TEXTURES.specular) : null,
                    specular: new THREE.Color(0x333333),
                    shininess: 25,
                    emissive: theme.globeEmissive ? new THREE.Color(theme.globeEmissive) : new THREE.Color(0x000000),
                    emissiveIntensity: theme.globeEmissive ? 0.1 : 0
                });
                this.earthMesh = new THREE.Mesh(geometry, material);
                this.globeGroup.add(this.earthMesh);
            } else {
                const material = new THREE.MeshPhongMaterial({
                    color: new THREE.Color(theme.globeColor || '#1a1a2e'),
                    emissive: new THREE.Color(theme.globeEmissive || '#0a0a1a'),
                    emissiveIntensity: 0.2,
                    transparent: true,
                    opacity: 0.9,
                    shininess: 10
                });
                this.earthMesh = new THREE.Mesh(geometry, material);
                this.globeGroup.add(this.earthMesh);
            }

            if (theme.wireframe) {
                const wireGeometry = new THREE.SphereGeometry(cfg.globeRadius * 1.002, 32, 32);
                const wireMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(theme.wireframeColor || '#3b82f6'),
                    wireframe: true,
                    transparent: true,
                    opacity: theme.wireframeOpacity || 0.15
                });
                this.globeGroup.add(new THREE.Mesh(wireGeometry, wireMaterial));
            }

            if (theme.showDots) {
                this.createDotPattern();
            }


            if (theme.showAtmosphere) {
                this.createAtmosphere();
            }
        }

        async setupDayNightGlobe(geometry) {
            const THREE = this.THREE;
            const dayTexture = this.textureLoader.load(TEXTURES.earth);
            const nightTexture = this.textureLoader.load(TEXTURES.nightLights);

            const material = new THREE.ShaderMaterial({
                vertexShader: SHADERS.dayNight.vertex,
                fragmentShader: SHADERS.dayNight.fragment,
                uniforms: {
                    dayTexture: { value: dayTexture },
                    nightTexture: { value: nightTexture },
                    sunDirection: { value: new THREE.Vector3(1, 0, 0) }
                }
            });

            this.earthMesh = new THREE.Mesh(geometry, material);
            this.earthMesh.userData.isDayNight = true;
            this.globeGroup.add(this.earthMesh);
        }

        createDotPattern() {
            const THREE = this.THREE;
            const geometry = new THREE.BufferGeometry();
            const positions = [];
            const radius = this.config.globeRadius * 1.005;
            const numPoints = 2000;
            const goldenRatio = (1 + Math.sqrt(5)) / 2;

            for (let i = 0; i < numPoints; i++) {
                const theta = (2 * Math.PI * i) / goldenRatio;
                const phi = Math.acos(1 - (2 * (i + 0.5)) / numPoints);
                positions.push(
                    radius * Math.sin(phi) * Math.cos(theta),
                    radius * Math.sin(phi) * Math.sin(theta),
                    radius * Math.cos(phi)
                );
            }

            geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
            const material = new THREE.PointsMaterial({
                color: new THREE.Color(this.config.dotColor || this.theme.dotsColor || '#4a90d9'),
                size: 0.008,
                sizeAttenuation: true,
                transparent: true,
                opacity: 0.6
            });
            this.globeGroup.add(new THREE.Points(geometry, material));
        }

        createAtmosphere() {
            const THREE = this.THREE;
            const geometry = new THREE.SphereGeometry(this.config.globeRadius * 1.15, 64, 64);
            const material = new THREE.ShaderMaterial({
                vertexShader: SHADERS.atmosphere.vertex,
                fragmentShader: SHADERS.atmosphere.fragment,
                uniforms: {
                    glowColor: { value: new THREE.Color(this.theme.atmosphereColor) },
                    intensity: { value: this.theme.atmosphereIntensity }
                },
                side: THREE.BackSide,
                blending: THREE.AdditiveBlending,
                transparent: true,
                depthWrite: false
            });
            this.globeGroup.add(new THREE.Mesh(geometry, material));
        }

        setupControls() {
            const THREE = this.THREE;
            const OrbitControls = THREE.OrbitControls;

            if (OrbitControls) {
                this.controls = new OrbitControls(this.camera, this.renderer.domElement);
                this.controls.enableDamping = true;
                this.controls.dampingFactor = 0.05;
                this.controls.enableZoom = this.config.enableZoom;
                this.controls.enablePan = this.config.enablePan;
                this.controls.minDistance = this.config.minDistance;
                this.controls.maxDistance = this.config.maxDistance;
                this.controls.autoRotate = this.config.autoRotate && this.config.animationMode === 'continuous';
                this.controls.autoRotateSpeed = this.config.autoRotateSpeed;
            }
        }

        setupInteraction() {
            const THREE = this.THREE;
            this.raycaster = new THREE.Raycaster();
            this.mouse = new THREE.Vector2();

            this.renderer.domElement.addEventListener('click', (e) => this.handleClick(e));
            this.renderer.domElement.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        }

        handleClick(event) {
            const rect = this.renderer.domElement.getBoundingClientRect();
            this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            this.raycaster.setFromCamera(this.mouse, this.camera);

            const clickables = this.markerGroups.map(g =>
                g.children.find(c => c.userData.isClickable)
            ).filter(Boolean);

            const intersects = this.raycaster.intersectObjects(clickables);

            if (intersects.length > 0) {
                const marker = intersects[0].object.parent.userData.markerData;
                if (this.onMarkerClick) {
                    this.onMarkerClick(marker);
                }
                this.container.dispatchEvent(new CustomEvent('globe:marker-click', { detail: marker }));
                this.focusOnMarker(marker, true);
            }
        }

        handleMouseMove(event) {
            const rect = this.renderer.domElement.getBoundingClientRect();
            this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            this.raycaster.setFromCamera(this.mouse, this.camera);

            const clickables = this.markerGroups.map(g =>
                g.children.find(c => c.userData.isClickable)
            ).filter(Boolean);

            const intersects = this.raycaster.intersectObjects(clickables);

            this.markerGroups.forEach((group, idx) => {
                group.scale.setScalar(1);
                if (this.labels[idx]) {
                    this.labels[idx].style.opacity = '0';
                    this.labels[idx].style.transform = 'translate(-50%, -100%) scale(0.9)';
                }
            });

            if (intersects.length > 0) {
                const group = intersects[0].object.parent;
                const idx = this.markerGroups.indexOf(group);
                group.scale.setScalar(1.3);

                if (this.labels[idx]) {
                    this.labels[idx].style.opacity = '1';
                    this.labels[idx].style.transform = 'translate(-50%, -100%) scale(1)';
                }

                this.renderer.domElement.style.cursor = 'pointer';

                if (this.onMarkerHover) {
                    this.onMarkerHover(group.userData.markerData);
                }

                this.container.dispatchEvent(new CustomEvent('globe:marker-hover', {
                    detail: group.userData.markerData
                }));
            } else {
                this.renderer.domElement.style.cursor = 'grab';
            }
        }

        // ============================================
        // MARKER METHODS
        // ============================================

        setMarkers(markers) {
            this.clearMarkers();
            this.markers = markers;

            markers.forEach(marker => this.addMarker(marker));

            if (this.config.showArcs && markers.length > 1) {
                this.generateArcs();
            }

            if (this.config.showHeatmap) {
                this.generateHeatmap();
            }

            if (this.config.animationMode === 'focus-tour' && markers.length > 0) {
                this.startTour();
            }
        }

        addMarker(marker) {
            const style = this.config.markerStyle;

            switch (style) {
                case 'beams':
                    this.addBeamMarker(marker);
                    break;
                case 'ripples':
                    this.addRippleMarker(marker);
                    break;
                case 'dots':
                    this.addDotMarker(marker);
                    break;
                case 'pillars':
                    this.addPillarMarker(marker);
                    break;
                default:
                    this.addPinMarker(marker);
            }
        }

        /**
         * Creates a camera-facing image sprite for any marker type.
         * Returns the sprite or null if no src provided.
         */
        /**
         * Returns the size scale ratio relative to the default 0.06 marker size.
         */
        getSizeScale() {
            return (this.config.markerSize || 0.06) / 0.06;
        }

        createImageSprite(marker, yPosition, scale) {
            const imgSrc = marker.src || this.config.defaultMarkerSrc;
            if (!imgSrc) return null;
            const THREE = this.THREE;
            const texture = this.textureLoader.load(imgSrc, undefined, undefined, (err) => {
                console.warn('Globe3D: Failed to load marker image', imgSrc, err);
            });
            texture.crossOrigin = 'anonymous';
            const spriteMat = new THREE.SpriteMaterial({
                map: texture,
                sizeAttenuation: true,
                depthTest: true,
                depthWrite: false
            });
            const sprite = new THREE.Sprite(spriteMat);
            const s = scale || this.config.markerSize || 0.06;
            sprite.scale.set(s, s, 1);
            sprite.position.y = yPosition;
            sprite.userData.isClickable = true;
            return sprite;
        }

        addPinMarker(marker) {
            const THREE = this.THREE;
            const cfg = this.config;
            const sc = this.getSizeScale();
            const pinColor = marker.color || cfg.pinColor;
            const surfacePos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius);
            const normal = surfacePos.clone().normalize();

            const group = new THREE.Group();
            group.userData.markerData = marker;

            const needleGeometry = new THREE.CylinderGeometry(0.004 * sc, 0.006 * sc, cfg.pinHeight, 8);
            const needleMaterial = new THREE.MeshPhongMaterial({
                color: new THREE.Color(pinColor),
                emissive: new THREE.Color(pinColor),
                emissiveIntensity: 0.3,
                shininess: 80
            });
            const needle = new THREE.Mesh(needleGeometry, needleMaterial);
            needle.position.y = cfg.pinHeight / 2;
            group.add(needle);

            const imgSprite = this.createImageSprite(marker, cfg.pinHeight + 0.02, cfg.markerSize);
            if (imgSprite) {
                group.add(imgSprite);
            } else {
                const headGeometry = new THREE.SphereGeometry(0.02 * sc, 16, 16);
                const headMaterial = new THREE.MeshPhongMaterial({
                    color: new THREE.Color(pinColor),
                    emissive: new THREE.Color(pinColor),
                    emissiveIntensity: 0.5,
                    shininess: 100
                });
                const head = new THREE.Mesh(headGeometry, headMaterial);
                head.position.y = cfg.pinHeight + 0.015;
                head.userData.isClickable = true;
                group.add(head);
            }

            group.position.copy(surfacePos);
            group.lookAt(surfacePos.clone().add(normal));
            group.rotateX(Math.PI / 2);

            this.globeGroup.add(group);
            this.markerGroups.push(group);

            this.createLabel(marker, group);

            if (cfg.showPulse) {
                this.createPulseRing(marker, surfacePos, normal, pinColor);
            }
        }

        addBeamMarker(marker) {
            const THREE = this.THREE;
            const cfg = this.config;
            const sc = this.getSizeScale();
            const beamColor = marker.color || cfg.pinColor;
            const surfacePos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius);
            const normal = surfacePos.clone().normalize();

            const group = new THREE.Group();
            group.userData.markerData = marker;

            const beamGeometry = new THREE.CylinderGeometry(0.006 * sc, 0.012 * sc, cfg.beamHeight, 16, 1, true);
            const beamMaterial = new THREE.ShaderMaterial({
                vertexShader: SHADERS.beam.vertex,
                fragmentShader: SHADERS.beam.fragment,
                uniforms: {
                    color: { value: new THREE.Color(beamColor) },
                    time: { value: 0 },
                    height: { value: cfg.beamHeight }
                },
                transparent: true,
                side: THREE.DoubleSide,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const beam = new THREE.Mesh(beamGeometry, beamMaterial);
            beam.position.y = cfg.beamHeight / 2;
            beam.userData.isBeam = true;
            group.add(beam);
            this.beamMeshes.push(beam);

            const glowGeometry = new THREE.CylinderGeometry(0.015 * sc, 0.025 * sc, cfg.beamHeight, 16, 1, true);
            const glowMaterial = new THREE.MeshBasicMaterial({
                color: new THREE.Color(beamColor),
                transparent: true,
                opacity: 0.15,
                side: THREE.DoubleSide,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const glow = new THREE.Mesh(glowGeometry, glowMaterial);
            glow.position.y = cfg.beamHeight / 2;
            group.add(glow);

            const beamImgSprite = this.createImageSprite(marker, cfg.beamHeight + 0.02, cfg.markerSize);
            if (beamImgSprite) {
                group.add(beamImgSprite);
            } else {
                const ringGeometry = new THREE.RingGeometry(0.01 * sc, 0.025 * sc, 32);
                const ringMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(beamColor),
                    transparent: true,
                    opacity: 0.8,
                    side: THREE.DoubleSide
                });
                const ring = new THREE.Mesh(ringGeometry, ringMaterial);
                ring.position.y = cfg.beamHeight;
                ring.rotation.x = -Math.PI / 2;
                ring.userData.isClickable = true;
                group.add(ring);
            }

            group.position.copy(surfacePos);
            group.lookAt(surfacePos.clone().add(normal));
            group.rotateX(Math.PI / 2);

            this.globeGroup.add(group);
            this.markerGroups.push(group);

            this.createLabel(marker, group);
        }

        addRippleMarker(marker) {
            const THREE = this.THREE;
            const cfg = this.config;
            const sc = this.getSizeScale();
            const rippleColor = marker.color || cfg.pinColor;
            const surfacePos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius);
            const normal = surfacePos.clone().normalize();

            const group = new THREE.Group();
            group.userData.markerData = marker;

            // Image sprite floats above the ripple, or fallback to colored dot
            const rippleImgSprite = this.createImageSprite(marker, cfg.markerSize, cfg.markerSize);
            if (rippleImgSprite) {
                group.add(rippleImgSprite);
            } else {
                const dotGeometry = new THREE.SphereGeometry(0.015 * sc, 16, 16);
                const dotMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(rippleColor)
                });
                const dot = new THREE.Mesh(dotGeometry, dotMaterial);
                dot.userData.isClickable = true;
                group.add(dot);
            }

            for (let i = 0; i < 3; i++) {
                const ringGeometry = new THREE.RingGeometry(0.02 * sc, 0.025 * sc, 32);
                const ringMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(rippleColor),
                    transparent: true,
                    opacity: 0.6,
                    side: THREE.DoubleSide,
                    depthWrite: false
                });
                const ring = new THREE.Mesh(ringGeometry, ringMaterial);
                ring.userData.ripplePhase = (i / 3) * Math.PI * 2;
                ring.userData.isRipple = true;
                group.add(ring);
                this.pulseRings.push(ring);
            }

            group.position.copy(surfacePos.clone().multiplyScalar(1.001));
            group.lookAt(surfacePos.clone().add(normal));

            this.globeGroup.add(group);
            this.markerGroups.push(group);

            this.createLabel(marker, group);
        }

        addDotMarker(marker) {
            const THREE = this.THREE;
            const cfg = this.config;
            const sc = this.getSizeScale();
            const dotColor = marker.color || cfg.pinColor;
            const surfacePos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius);
            const normal = surfacePos.clone().normalize();

            const group = new THREE.Group();
            group.userData.markerData = marker;

            // Image sprite floats above the dot, or fallback to colored sphere
            const dotImgSprite = this.createImageSprite(marker, cfg.markerSize * 0.83, cfg.markerSize);
            if (dotImgSprite) {
                group.add(dotImgSprite);
            } else {
                const dotGeometry = new THREE.SphereGeometry(0.02 * sc, 16, 16);
                const dotMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(dotColor)
                });
                const dot = new THREE.Mesh(dotGeometry, dotMaterial);
                dot.userData.isClickable = true;
                group.add(dot);
            }

            const glowGeometry = new THREE.SphereGeometry(0.035 * sc, 16, 16);
            const glowMaterial = new THREE.MeshBasicMaterial({
                color: new THREE.Color(dotColor),
                transparent: true,
                opacity: 0.3
            });
            group.add(new THREE.Mesh(glowGeometry, glowMaterial));

            group.position.copy(surfacePos.clone().multiplyScalar(1.01));

            this.globeGroup.add(group);
            this.markerGroups.push(group);

            this.createLabel(marker, group);

            if (cfg.showPulse) {
                this.createPulseRing(marker, surfacePos, normal, dotColor);
            }
        }

        addPillarMarker(marker) {
            const THREE = this.THREE;
            const cfg = this.config;
            const sc = this.getSizeScale();
            const pillarColor = marker.color || cfg.pinColor;
            const surfacePos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius);
            const normal = surfacePos.clone().normalize();

            const value = marker.value !== undefined ? marker.value : Math.random();
            const height = cfg.pillarMinHeight + (cfg.pillarMaxHeight - cfg.pillarMinHeight) * value;

            const group = new THREE.Group();
            group.userData.markerData = marker;

            const pillarGeometry = new THREE.CylinderGeometry(0.01 * sc, 0.014 * sc, height, 8);
            const pillarMaterial = new THREE.MeshPhongMaterial({
                color: new THREE.Color(pillarColor),
                emissive: new THREE.Color(pillarColor),
                emissiveIntensity: 0.3,
                transparent: true,
                opacity: 0.9
            });
            const pillar = new THREE.Mesh(pillarGeometry, pillarMaterial);
            pillar.position.y = height / 2;
            group.add(pillar);

            const pillarImgSprite = this.createImageSprite(marker, height + 0.02, cfg.markerSize);
            if (pillarImgSprite) {
                group.add(pillarImgSprite);
            } else {
                const capGeometry = new THREE.SphereGeometry(0.015 * sc, 16, 16);
                const capMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(pillarColor),
                    transparent: true,
                    opacity: 0.9
                });
                const cap = new THREE.Mesh(capGeometry, capMaterial);
                cap.position.y = height;
                cap.userData.isClickable = true;
                group.add(cap);
            }

            group.position.copy(surfacePos);
            group.lookAt(surfacePos.clone().add(normal));
            group.rotateX(Math.PI / 2);

            this.globeGroup.add(group);
            this.markerGroups.push(group);

            this.createLabel(marker, group);
        }

        createLabel(marker, group) {
            if (!marker.label) return;

            const labelDiv = document.createElement('div');
            labelDiv.className = 'globe-marker-label';
            labelDiv.innerHTML = `
                <div class="globe-label-content">
                    ${marker.src ? `<img src="${marker.src}" alt="${marker.label}" />` : ''}
                    <span>${marker.label}</span>
                </div>
            `;
            labelDiv._markerGroup = group;
            this.container.appendChild(labelDiv);
            this.labels.push(labelDiv);
        }

        createPulseRing(marker, surfacePos, normal, color) {
            const THREE = this.THREE;
            const sc = this.getSizeScale();

            const ringGeometry = new THREE.RingGeometry(0.012 * sc, 0.025 * sc, 32);
            const ringMaterial = new THREE.MeshBasicMaterial({
                color: new THREE.Color(color),
                transparent: true,
                opacity: 0.6,
                side: THREE.DoubleSide,
                depthWrite: false
            });
            const ring = new THREE.Mesh(ringGeometry, ringMaterial);
            ring.position.copy(surfacePos.clone().multiplyScalar(1.001));
            ring.lookAt(surfacePos.clone().add(normal));
            ring.userData.pulsePhase = Math.random() * Math.PI * 2;
            ring.userData.baseScale = 1;
            ring.userData.maxScale = 4;
            this.globeGroup.add(ring);
            this.pulseRings.push(ring);
        }

        // ============================================
        // ARC METHODS
        // ============================================

        generateArcs() {
            const markers = this.markers;
            for (let i = 0; i < markers.length - 1; i++) {
                this.addArc(markers[i], markers[i + 1]);
            }
            if (markers.length > 2) {
                this.addArc(markers[markers.length - 1], markers[0]);
            }
        }

        addArc(from, to) {
            const style = this.config.connectionStyle;
            switch (style) {
                case 'animated':
                    this.addAnimatedArc(from, to);
                    break;
                case 'gradient':
                    this.addGradientArc(from, to);
                    break;
                case 'glow':
                    this.addGlowArc(from, to);
                    break;
                default:
                    this.addDashedArc(from, to);
            }
        }

        addDashedArc(from, to) {
            const THREE = this.THREE;
            const cfg = this.config;

            const start = this.latLngToVector3(from.lat, from.lng, cfg.globeRadius * 1.001);
            const end = this.latLngToVector3(to.lat, to.lng, cfg.globeRadius * 1.001);
            const curve = this.createArcCurve(start, end, 0.25);
            const points = curve.getPoints(80);

            const geometry = new THREE.BufferGeometry().setFromPoints(points);
            const material = new THREE.LineDashedMaterial({
                color: new THREE.Color(cfg.arcColor),
                dashSize: 0.04,
                gapSize: 0.008,
                transparent: true,
                opacity: 0.7
            });

            const arc = new THREE.Line(geometry, material);
            arc.computeLineDistances();
            this.globeGroup.add(arc);
            this.arcMeshes.push(arc);
        }

        addAnimatedArc(from, to) {
            const THREE = this.THREE;
            const cfg = this.config;

            const start = this.latLngToVector3(from.lat, from.lng, cfg.globeRadius * 1.001);
            const end = this.latLngToVector3(to.lat, to.lng, cfg.globeRadius * 1.001);
            const curve = this.createArcCurve(start, end, 0.25);

            const points = curve.getPoints(80);
            const geometry = new THREE.BufferGeometry().setFromPoints(points);
            const material = new THREE.LineBasicMaterial({
                color: new THREE.Color(cfg.arcColor),
                transparent: true,
                opacity: 0.3
            });
            const baseLine = new THREE.Line(geometry, material);
            this.globeGroup.add(baseLine);
            this.arcMeshes.push(baseLine);

            const particleCount = 20;
            const particleGeometry = new THREE.BufferGeometry();
            const positions = new Float32Array(particleCount * 3);
            particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

            const particleMaterial = new THREE.PointsMaterial({
                color: new THREE.Color(cfg.arcColor),
                size: 0.02,
                transparent: true,
                opacity: 0.9,
                sizeAttenuation: true
            });

            const particles = new THREE.Points(particleGeometry, particleMaterial);
            particles.userData.curve = curve;
            particles.userData.particleCount = particleCount;
            particles.userData.offset = Math.random();
            this.globeGroup.add(particles);
            this.animatedArcs.push(particles);
        }

        addGradientArc(from, to) {
            const THREE = this.THREE;
            const cfg = this.config;

            const start = this.latLngToVector3(from.lat, from.lng, cfg.globeRadius * 1.001);
            const end = this.latLngToVector3(to.lat, to.lng, cfg.globeRadius * 1.001);
            const curve = this.createArcCurve(start, end, 0.25);
            const points = curve.getPoints(80);

            const colors = [];
            const startColor = new THREE.Color(cfg.arcColor);
            const endColor = new THREE.Color(cfg.arcColorEnd);

            for (let i = 0; i < points.length; i++) {
                const t = i / (points.length - 1);
                const color = startColor.clone().lerp(endColor, t);
                colors.push(color.r, color.g, color.b);
            }

            const geometry = new THREE.BufferGeometry().setFromPoints(points);
            geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

            const material = new THREE.LineBasicMaterial({
                vertexColors: true,
                transparent: true,
                opacity: 0.8
            });

            const arc = new THREE.Line(geometry, material);
            this.globeGroup.add(arc);
            this.arcMeshes.push(arc);
        }

        addGlowArc(from, to) {
            const THREE = this.THREE;
            const cfg = this.config;

            const start = this.latLngToVector3(from.lat, from.lng, cfg.globeRadius * 1.001);
            const end = this.latLngToVector3(to.lat, to.lng, cfg.globeRadius * 1.001);
            const curve = this.createArcCurve(start, end, 0.25);
            const points = curve.getPoints(80);

            const glowGeometry = new THREE.BufferGeometry().setFromPoints(points);
            const glowMaterial = new THREE.LineBasicMaterial({
                color: new THREE.Color(cfg.arcColor),
                transparent: true,
                opacity: 0.2
            });
            const glow = new THREE.Line(glowGeometry, glowMaterial);
            this.globeGroup.add(glow);
            this.arcMeshes.push(glow);

            const coreGeometry = new THREE.BufferGeometry().setFromPoints(points);
            const coreMaterial = new THREE.LineBasicMaterial({
                color: new THREE.Color(cfg.arcColor),
                transparent: true,
                opacity: 0.9
            });
            const core = new THREE.Line(coreGeometry, coreMaterial);
            this.globeGroup.add(core);
            this.arcMeshes.push(core);
        }

        // ============================================
        // HEATMAP
        // ============================================

        generateHeatmap() {
            const THREE = this.THREE;
            const cfg = this.config;

            this.markers.forEach(marker => {
                const pos = this.latLngToVector3(marker.lat, marker.lng, cfg.globeRadius * 1.002);
                const normal = pos.clone().normalize();

                for (let i = 3; i >= 1; i--) {
                    const radius = cfg.heatmapRadius * (i / 3);
                    const opacity = (0.4 / i) * cfg.heatmapIntensity;
                    const geometry = new THREE.CircleGeometry(radius, 32);
                    const hue = 0.1 * (1 - (i / 3));
                    const color = new THREE.Color().setHSL(hue, 1, 0.5);

                    const material = new THREE.MeshBasicMaterial({
                        color: color,
                        transparent: true,
                        opacity: opacity,
                        side: THREE.DoubleSide,
                        depthWrite: false,
                        blending: THREE.AdditiveBlending
                    });

                    const heatSpot = new THREE.Mesh(geometry, material);
                    heatSpot.position.copy(pos);
                    heatSpot.lookAt(pos.clone().add(normal));
                    this.globeGroup.add(heatSpot);
                    this.heatSpots.push(heatSpot);
                }
            });
        }

        // ============================================
        // ANIMATION
        // ============================================

        animate() {
            this._animationId = requestAnimationFrame(() => this.animate());

            const time = this.clock.getElapsedTime();

            if (this.controls) {
                this.controls.update();
            }

            if (this.config.animationMode === 'idle-bounce') {
                if (this.controls) this.controls.autoRotate = false;
                this.globeGroup.rotation.y += 0.001;
                this.globeGroup.rotation.x = Math.sin(time * 0.5) * this.config.bounceAmplitude;
            }

            if (this.cloudsMesh) {
                this.cloudsMesh.rotation.y += 0.0002;
            }

            if (this.config.showDayNight && this.earthMesh?.userData.isDayNight) {
                const angle = time * this.config.dayNightSpeed;
                const sunDir = new this.THREE.Vector3(Math.cos(angle), 0, Math.sin(angle));
                this.earthMesh.material.uniforms.sunDirection.value = sunDir;
            }

            this.beamMeshes.forEach(beam => {
                if (beam.material.uniforms) {
                    beam.material.uniforms.time.value = time;
                }
            });

            this.updatePulseRings(time);
            this.updateAnimatedArcs(time);
            this.updateLabels();

            this.renderer.render(this.scene, this.camera);
        }

        updatePulseRings(time) {
            this.pulseRings.forEach(ring => {
                if (ring.userData.isRipple) {
                    const phase = ring.userData.ripplePhase;
                    const t = ((time * 2 + phase) % (Math.PI * 2)) / (Math.PI * 2);
                    const scale = 1 + t * 3;
                    ring.scale.setScalar(scale);
                    ring.material.opacity = 0.6 * (1 - t);
                } else {
                    const phase = ring.userData.pulsePhase || 0;
                    const t = ((time * 1.5 + phase) % (Math.PI * 2)) / (Math.PI * 2);
                    const scale = ring.userData.baseScale +
                        (ring.userData.maxScale - ring.userData.baseScale) * t;
                    ring.scale.setScalar(scale);
                    ring.material.opacity = 0.6 * (1 - t);
                }
            });
        }

        updateAnimatedArcs(time) {
            this.animatedArcs.forEach(particles => {
                const curve = particles.userData.curve;
                const count = particles.userData.particleCount;
                const offset = particles.userData.offset;
                const positions = particles.geometry.attributes.position.array;

                for (let i = 0; i < count; i++) {
                    const t = ((time * 0.3 + offset + i / count) % 1);
                    const point = curve.getPoint(t);
                    positions[i * 3] = point.x;
                    positions[i * 3 + 1] = point.y;
                    positions[i * 3 + 2] = point.z;
                }

                particles.geometry.attributes.position.needsUpdate = true;
            });
        }

        updateLabels() {
            const THREE = this.THREE;

            this.labels.forEach(label => {
                const group = label._markerGroup;
                if (!group) return;

                const clickable = group.children.find(c => c.userData.isClickable);
                if (!clickable) return;

                const worldPos = new THREE.Vector3();
                clickable.getWorldPosition(worldPos);

                const toMarker = worldPos.clone().normalize();
                const cameraDir = this.camera.position.clone().normalize();
                const dot = toMarker.dot(cameraDir);

                if (dot < 0.2) {
                    label.style.display = 'none';
                    return;
                }

                label.style.display = 'block';
                const screenPos = worldPos.clone().project(this.camera);
                const x = (screenPos.x * 0.5 + 0.5) * this.container.clientWidth;
                const y = (-screenPos.y * 0.5 + 0.5) * this.container.clientHeight;
                label.style.left = `${x}px`;
                label.style.top = `${y - 15}px`;
            });
        }

        // ============================================
        // TOUR MODE
        // ============================================

        startTour() {
            this.stopTour();
            this.tourIndex = 0;
            this.runTourStep();
        }

        runTourStep() {
            if (this.markers.length === 0) return;

            const marker = this.markers[this.tourIndex];
            this.focusOnMarker(marker);

            this.tourTimeout = setTimeout(() => {
                this.tourIndex = (this.tourIndex + 1) % this.markers.length;
                this.runTourStep();
            }, this.config.tourInterval);
        }

        stopTour() {
            if (this.tourTimeout) {
                clearTimeout(this.tourTimeout);
                this.tourTimeout = null;
            }
        }

        // ============================================
        // UTILITY METHODS
        // ============================================

        latLngToVector3(lat, lng, radius) {
            const THREE = this.THREE;
            const phi = (90 - lat) * (Math.PI / 180);
            const theta = (lng + 180) * (Math.PI / 180);

            return new THREE.Vector3(
                -radius * Math.sin(phi) * Math.cos(theta),
                radius * Math.cos(phi),
                radius * Math.sin(phi) * Math.sin(theta)
            );
        }

        createArcCurve(start, end, altitude) {
            const THREE = this.THREE;
            const startNorm = start.clone().normalize();
            const endNorm = end.clone().normalize();
            let mid = startNorm.clone().add(endNorm);
            const distance = start.distanceTo(end);

            // When markers are nearly opposite, mid approaches zero vector.
            // Use a perpendicular vector instead to keep the arc valid.
            if (mid.lengthSq() < 0.001) {
                mid = new THREE.Vector3(0, 1, 0);
                if (Math.abs(startNorm.dot(mid)) > 0.9) {
                    mid = new THREE.Vector3(1, 0, 0);
                }
                mid.crossVectors(startNorm, mid).normalize();
            } else {
                mid.normalize();
            }

            const midHeight = this.config.globeRadius + altitude + distance * 0.2;
            mid.multiplyScalar(midHeight);

            return new THREE.QuadraticBezierCurve3(start, mid, end);
        }

        applyInitialView() {
            const lat = this.config.initialLat;
            const lng = this.config.initialLng;
            if (lat === undefined || lat === null || lng === undefined || lng === null) return;

            const pos = this.latLngToVector3(lat, lng, this.config.globeRadius);
            this.globeGroup.rotation.y = -Math.atan2(pos.x, pos.z);
            this.globeGroup.rotation.x = Math.asin(pos.y / this.config.globeRadius);
        }

        focusOnMarker(marker, zoom = false) {
            const pos = this.latLngToVector3(marker.lat, marker.lng, this.config.globeRadius);
            const targetRotY = -Math.atan2(pos.x, pos.z);
            const targetRotX = Math.asin(pos.y / this.config.globeRadius);

            if (this.controls) this.controls.autoRotate = false;

            const startRotY = this.globeGroup.rotation.y;
            const startRotX = this.globeGroup.rotation.x;
            const startTime = Date.now();
            const duration = 1000;

            const startDistance = this.camera.position.z;
            const targetDistance = zoom ? this.config.zoomToRegionDistance : startDistance;

            const animateFocus = () => {
                const elapsed = Date.now() - startTime;
                const t = Math.min(elapsed / duration, 1);
                const eased = 1 - Math.pow(1 - t, 3);

                this.globeGroup.rotation.y = startRotY + (targetRotY - startRotY) * eased;
                this.globeGroup.rotation.x = startRotX + (targetRotX - startRotX) * eased;

                if (zoom) {
                    this.camera.position.z = startDistance + (targetDistance - startDistance) * eased;
                }

                if (t < 1) {
                    requestAnimationFrame(animateFocus);
                } else if (this.controls && this.config.autoRotate &&
                           this.config.animationMode === 'continuous') {
                    this.controls.autoRotate = true;
                }
            };

            animateFocus();
        }

        clearMarkers() {
            this.markerGroups.forEach(g => this.globeGroup.remove(g));
            this.markerGroups = [];

            this.pulseRings.forEach(r => this.globeGroup.remove(r));
            this.pulseRings = [];

            this.arcMeshes.forEach(a => this.globeGroup.remove(a));
            this.arcMeshes = [];

            this.animatedArcs.forEach(a => this.globeGroup.remove(a));
            this.animatedArcs = [];

            this.heatSpots.forEach(h => this.globeGroup.remove(h));
            this.heatSpots = [];

            this.beamMeshes = [];

            this.labels.forEach(l => l.remove());
            this.labels = [];

            this.markers = [];

            this.stopTour();
        }

        handleResize() {
            const width = this.container.clientWidth;
            const height = this.container.clientHeight;

            this.camera.aspect = width / height;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(width, height);
        }

        // ============================================
        // PUBLIC API
        // ============================================

        setTheme(themeName) {
            if (THEMES[themeName]) {
                this.config.theme = themeName;
                this.applyTheme();
                this.rebuildGlobe();
            }
        }

        rebuildGlobe() {
            const THREE = this.THREE;
            const cfg = this.config;
            const theme = this.theme;

            const toRemove = [];
            this.globeGroup.traverse((child) => {
                if (child !== this.globeGroup) {
                    toRemove.push(child);
                }
            });
            toRemove.forEach(child => this.globeGroup.remove(child));

            this.scene.traverse((child) => {
                if (child.type === 'Points' && child.geometry?.attributes?.position?.count > 1000) {
                    this.scene.remove(child);
                }
            });

            this.earthMesh = null;
            this.cloudsMesh = null;

            if (this.config.showDots || theme.showStars) {
                this.createStars();
            }

            const geometry = new THREE.SphereGeometry(cfg.globeRadius, 64, 64);

            if (cfg.showDayNight) {
                this.setupDayNightGlobe(geometry);
            } else if (theme.globeTexture) {
                const material = new THREE.MeshPhongMaterial({
                    map: this.textureLoader.load(theme.globeTexture),
                    bumpMap: theme.showBump ? this.textureLoader.load(TEXTURES.bump) : null,
                    bumpScale: cfg.bumpScale,
                    specularMap: theme.showSpecular ? this.textureLoader.load(TEXTURES.specular) : null,
                    specular: new THREE.Color(0x333333),
                    shininess: 25,
                    emissive: theme.globeEmissive ? new THREE.Color(theme.globeEmissive) : new THREE.Color(0x000000),
                    emissiveIntensity: theme.globeEmissive ? 0.1 : 0
                });
                this.earthMesh = new THREE.Mesh(geometry, material);
                this.globeGroup.add(this.earthMesh);
            } else {
                const material = new THREE.MeshPhongMaterial({
                    color: new THREE.Color(theme.globeColor || '#1a1a2e'),
                    emissive: new THREE.Color(theme.globeEmissive || '#0a0a1a'),
                    emissiveIntensity: 0.2,
                    transparent: true,
                    opacity: 0.9,
                    shininess: 10
                });
                this.earthMesh = new THREE.Mesh(geometry, material);
                this.globeGroup.add(this.earthMesh);
            }

            if (theme.wireframe) {
                const wireGeometry = new THREE.SphereGeometry(cfg.globeRadius * 1.002, 32, 32);
                const wireMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(theme.wireframeColor || '#3b82f6'),
                    wireframe: true,
                    transparent: true,
                    opacity: theme.wireframeOpacity || 0.15
                });
                this.globeGroup.add(new THREE.Mesh(wireGeometry, wireMaterial));
            }

            if (theme.showDots) {
                this.createDotPattern();
            }


            if (theme.showAtmosphere) {
                this.createAtmosphere();
            }

            const currentMarkers = [...this.markers];
            if (currentMarkers.length > 0) {
                this.setMarkers(currentMarkers);
            }
        }

        setMarkerStyle(style) {
            this.config.markerStyle = style;
            const currentMarkers = [...this.markers];
            this.setMarkers(currentMarkers);
        }

        setConnectionStyle(style) {
            this.config.connectionStyle = style;
            this.arcMeshes.forEach(a => this.globeGroup.remove(a));
            this.arcMeshes = [];
            this.animatedArcs.forEach(a => this.globeGroup.remove(a));
            this.animatedArcs = [];
            if (this.markers.length > 1) {
                this.generateArcs();
            }
        }

        setAnimationMode(mode) {
            this.config.animationMode = mode;
            this.stopTour();

            if (this.controls) {
                this.controls.autoRotate = mode === 'continuous';
            }

            if (mode === 'focus-tour' && this.markers.length > 0) {
                this.startTour();
            }
        }

        setAutoRotate(enabled, speed) {
            this.config.autoRotate = enabled;
            if (speed !== undefined) this.config.autoRotateSpeed = speed;

            if (this.controls) {
                this.controls.autoRotate = enabled;
                this.controls.autoRotateSpeed = this.config.autoRotateSpeed;
            }
        }

        toggleHeatmap(enabled) {
            this.config.showHeatmap = enabled;

            this.heatSpots.forEach(h => this.globeGroup.remove(h));
            this.heatSpots = [];

            if (enabled && this.markers.length > 0) {
                this.generateHeatmap();
            }
        }

        toggleDayNight(enabled) {
            this.config.showDayNight = enabled;
            this.rebuildGlobe();
        }

        destroy() {
            this.stopTour();
            this.clearMarkers();

            if (this._animationId) {
                cancelAnimationFrame(this._animationId);
            }

            if (this._resizeHandler) {
                window.removeEventListener('resize', this._resizeHandler);
            }

            if (this._resizeObserver) {
                this._resizeObserver.disconnect();
            }

            if (this.renderer) {
                this.renderer.dispose();
                if (this.renderer.domElement && this.renderer.domElement.parentNode) {
                    this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
                }
            }

            globeInstances.delete(this.container);
        }
    }

    // ============================================
    // AUTO-INITIALIZATION
    // ============================================
    function initGlobes() {
        document.querySelectorAll('[data-globe]').forEach(el => {
            if (!el._globe3d) {
                el._globe3d = new Globe3D(el);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initGlobes);
    } else {
        initGlobes();
    }

    // Export
    window.Globe3D = Globe3D;
    window.Globe3DThemes = THEMES;
    window.Globe3DApp = {
        Globe3D,
        THEMES,
        initGlobes,
        getInstance: (el) => globeInstances.get(el),
        getAllInstances: () => Array.from(globeInstances.values())
    };
})();
