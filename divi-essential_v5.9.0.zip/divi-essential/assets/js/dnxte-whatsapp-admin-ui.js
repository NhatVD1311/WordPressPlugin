/**
 * DNXTE — WhatsApp hub admin UI helpers.
 *
 * Vanilla JS (no jQuery dependency). Two jobs:
 *   1. Keep the restyled toggle switches accessible (they are pure CSS, but we
 *      make the whole row keyboard-friendly).
 *   2. Drive the LIVE PREVIEW on the Floating Widget settings screen: read the
 *      real form fields and render a lightweight, self-contained mock of the
 *      floating widget that updates on every input/change.
 *
 * The preview is a visual approximation only — it never touches the front-end
 * widget markup, script, or stylesheet, and it changes no field values.
 */
(function () {
	'use strict';

	var WA_ICON =
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M19.05 4.91A9.82 9.82 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91c0-2.65-1.03-5.14-2.91-7.01M12.05 20.15h-.01c-1.48 0-2.93-.4-4.2-1.15l-.3-.18l-3.12.82l.83-3.04l-.2-.31a8.26 8.26 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24c2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.25 8.23m4.52-6.16c-.25-.12-1.47-.72-1.69-.81c-.23-.08-.39-.12-.56.12c-.17.25-.64.81-.79.97c-.14.17-.29.19-.54.06c-.25-.12-1.05-.39-1.99-1.23c-.74-.66-1.23-1.47-1.38-1.72c-.14-.25-.02-.38.11-.51c.11-.11.25-.29.37-.43s.17-.25.25-.41c.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31c-.22.25-.86.85-.86 2.07c0 1.22.89 2.4 1.01 2.56s1.75 2.67 4.23 3.74c.59.26 1.05.41 1.41.52c.59.19 1.13.16 1.56.1c.48-.07 1.47-.6 1.67-1.18c.21-.58.21-1.07.14-1.18s-.22-.16-.47-.28"/></svg>';

	var AVATAR_ICON =
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12a5 5 0 1 0 0-10a5 5 0 0 0 0 10m0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5"/></svg>';

	// Button glyphs, keyed to the `btn_icon` setting (mirror of button_icon_svg()).
	var BTN_ICONS = {
		whatsapp: WA_ICON,
		'chat-bubble':
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2m-3 12H7v-2h10zm0-3H7V9h10zm0-3H7V6h10z"/></svg>',
		phone:
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M6.62 10.79a15.15 15.15 0 0 0 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24c1.12.37 2.33.57 3.57.57c.55 0 1 .45 1 1V20c0 .55-.45 1-1 1c-9.39 0-17-7.61-17-17c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1c0 1.25.2 2.45.57 3.57c.11.35.03.74-.25 1.02z"/></svg>'
	};

	// Font stacks (mirror of font_stack()).
	var FONT_STACKS = {
		system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
		arial: 'Arial, Helvetica, sans-serif',
		georgia: 'Georgia, "Times New Roman", serif',
		roboto: '"Roboto", sans-serif',
		opensans: '"Open Sans", sans-serif',
		poppins: '"Poppins", sans-serif',
		montserrat: '"Montserrat", sans-serif',
		lato: '"Lato", sans-serif'
	};

	// Shadow presets (mirror of shadow_value()).
	function shadowValue(key, kind) {
		if (key === 'none') {
			return 'none';
		}
		if (kind === 'popup') {
			return key === 'strong' ? '0 18px 50px rgba(0,0,0,0.30)' : '0 8px 24px rgba(0,0,0,0.14)';
		}
		return key === 'strong' ? '0 12px 30px rgba(0,0,0,0.30)' : '0 6px 20px rgba(0,0,0,0.18)';
	}

	/** Escape HTML for safe injection into the preview. */
	function esc(str) {
		return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
			return {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#39;'
			}[c];
		});
	}

	/* ── Toggle accessibility ─────────────────────────────────────────────── */
	function initToggles() {
		var toggles = document.querySelectorAll('.dnxte-wa-toggle');
		Array.prototype.forEach.call(toggles, function (label) {
			var input = label.querySelector('input[type="checkbox"]');
			if (!input) {
				return;
			}
			// Native <label> already forwards clicks; nothing else required. Kept as
			// a hook for potential future interactions.
		});
	}

	/* ── Live preview ─────────────────────────────────────────────────────── */
	function initPreview() {
		var form = document.getElementById('dnxte-wa-widget-form');
		var stage = document.getElementById('dnxte-wa-preview-stage');
		if (!form || !stage) {
			return;
		}

		/** Read a field value by its `name`. Checkboxes return boolean. */
		function field(name) {
			var el = form.querySelector('[name="dnxte_wa_widget[' + name + ']"]');
			if (!el) {
				return '';
			}
			if (el.type === 'checkbox') {
				return el.checked;
			}
			return el.value;
		}

		/** Sample agents drawn from the on-page agent picker, else two defaults. */
		function sampleAgents() {
			var out = [];
			var picks = form.querySelectorAll('.dnxte-wa-agent-pick');
			Array.prototype.forEach.call(picks, function (row) {
				if (out.length >= 3) {
					return;
				}
				var nameEl = row.querySelector('strong');
				var metaEl = row.querySelector('.dnxte-wa-agent-pick-meta');
				out.push({
					name: nameEl ? nameEl.textContent.trim() : 'Agent',
					role: metaEl ? metaEl.textContent.trim() : ''
				});
			});
			if (!out.length) {
				out = [
					{ name: 'Sarah — Sales', role: 'Sales · Online' },
					{ name: 'Mike — Support', role: 'Support · Online' }
				];
			}
			return out;
		}

		/** Read a numeric field with a fallback. */
		function num(name, fallback) {
			var v = parseInt(field(name), 10);
			return isNaN(v) ? fallback : v;
		}

		function render() {
			var position = field('position') || 'bottom-right';
			var theme = field('theme') || 'auto';
			if (theme === 'auto') {
				theme = 'light';
			}
			var skin = field('skin') || 'default';
			var buttonBg = field('button_bg') || '#25D366';
			var buttonColor = field('button_color') || '#ffffff';
			var label = field('button_label');
			var title = field('header_title');
			var subtitle = field('header_subtitle');
			var greeting = field('greeting');
			var badge = field('teaser_badge');
			var teaserOn = field('teaser_enable');
			var teaserText = field('teaser_text');
			var teaserX = num('teaser_offset_x', 0);
			var teaserY = num('teaser_offset_y', 0);
			var teaserPlace = field('teaser_position') || 'above';
			var agents = sampleAgents();

			// ── Design values ────────────────────────────────────────────────
			var btnSize = num('btn_size', 60);
			var btnRadius = num('btn_radius', 50);
			var btnRadiusCss = btnRadius >= 50 ? '50%' : btnRadius + 'px';
			var btnIcon = field('btn_icon') || 'whatsapp';
			var btnIconColor = field('btn_icon_color') || buttonColor;
			var btnShadow = shadowValue(field('btn_shadow') || 'soft', 'btn');

			var popupWidth = num('popup_width', 340);
			var popupRadius = num('popup_radius', 16);
			var popupBg = field('popup_bg') || '#ffffff';
			var popupShadow = shadowValue(field('popup_shadow') || 'strong', 'popup');
			var headerBg = field('header_bg') || '#075E54';
			var headerText = field('header_text_color') || '#ffffff';
			var greetingColor = field('greeting_color') || '#333333';
			var greetingBg = field('greeting_bg') || '#f0f2f5';

			var agentBg = field('agent_bg') || '#f6f7f9';
			var agentHoverBg = field('agent_hover_bg') || '#eef0f3';
			var agentNameColor = field('agent_name_color') || '#1a1a1a';
			var agentRoleColor = field('agent_role_color') || '#667085';
			var avatarSize = num('avatar_size', 44);
			var agentRadius = num('agent_radius', 12);

			var fontFamily = FONT_STACKS[field('font_family')] || FONT_STACKS.system;
			var baseFont = num('base_font_size', 14);
			var titleFont = num('title_font_size', 17);

			var iconGlyph = BTN_ICONS[btnIcon] || WA_ICON;

			var agentsHtml = agents
				.map(function (a) {
					return (
						'<div class="wapv-agent" style="background:' +
						esc(agentBg) +
						';border-radius:' +
						agentRadius +
						'px">' +
						'<span class="wapv-agent__avatar" style="width:' +
						avatarSize +
						'px;height:' +
						avatarSize +
						'px">' +
						AVATAR_ICON +
						'<span class="wapv-agent__dot"></span></span>' +
						'<span class="wapv-agent__info">' +
						'<span class="wapv-agent__name" style="color:' +
						esc(agentNameColor) +
						'">' +
						esc(a.name) +
						'</span>' +
						(a.role
							? '<span class="wapv-agent__role" style="color:' + esc(agentRoleColor) + '">' + esc(a.role) + '</span>'
							: '') +
						'</span>' +
						'</div>'
					);
				})
				.join('');

			var teaserHtml =
				teaserOn && teaserText
					? '<div class="wapv-teaser" style="transform:translate(' + teaserX + 'px,' + teaserY + 'px)">' + esc(teaserText) + '</div>'
					: '';

			var badgeHtml = badge ? '<span class="wapv-badge">1</span>' : '';

			var buttonClasses = 'wapv-button wapv-skin-' + esc(skin) + (label ? ' has-label' : '');
			// With a label the button is an auto-width pill (like the front-end's
			// `:has(.dnxte-wa-button-label){width:auto}`). A fixed inline width would
			// squash the label/icon, so only pin width/height when there is NO label.
			var sizeCss = label
				? 'height:' + btnSize + 'px;border-radius:999px;'
				: 'width:' + btnSize + 'px;height:' + btnSize + 'px;border-radius:' + btnRadiusCss + ';';
			var buttonHtml =
				'<div class="' +
				buttonClasses +
				'" style="background:' +
				esc(buttonBg) +
				';color:' +
				esc(buttonColor) +
				';' +
				sizeCss +
				'box-shadow:' +
				btnShadow +
				'">' +
				'<span class="wapv-button__icon" style="color:' +
				esc(btnIconColor) +
				'">' +
				iconGlyph +
				'</span>' +
				(label ? '<span class="wapv-button__label">' + esc(label) + '</span>' : '') +
				badgeHtml +
				'</div>';

			var popupHtml =
				'<div class="wapv-popup" style="width:' +
				popupWidth +
				'px;border-radius:' +
				popupRadius +
				'px;background:' +
				esc(popupBg) +
				';box-shadow:' +
				popupShadow +
				'">' +
				'<div class="wapv-popup__header" style="background:' +
				esc(headerBg) +
				';color:' +
				esc(headerText) +
				'">' +
				'<p class="wapv-popup__title" style="font-size:' +
				titleFont +
				'px">' +
				esc(title || 'Chat with us') +
				'</p>' +
				(subtitle ? '<p class="wapv-popup__subtitle">' + esc(subtitle) + '</p>' : '') +
				'</div>' +
				'<div class="wapv-popup__body">' +
				(greeting
					? '<div class="wapv-greeting" style="color:' + esc(greetingColor) + ';background:' + esc(greetingBg) + '">' + esc(greeting) + '</div>'
					: '') +
				agentsHtml +
				'</div>' +
				'</div>';

			stage.className = 'wapv-stage wapv-theme-' + esc(theme);
			stage.style.fontFamily = fontFamily;
			stage.style.fontSize = baseFont + 'px';
			stage.style.setProperty('--wapv-agent-hover', agentHoverBg);
			stage.innerHTML =
				'<div class="wapv-anchor wapv-pos-' +
				esc(position) +
				' wapv-teaser-place-' +
				esc(teaserPlace) +
				'">' +
				popupHtml +
				teaserHtml +
				buttonHtml +
				'</div>';
		}

		// Update on any field interaction (bubbles up to the form).
		form.addEventListener('input', render);
		form.addEventListener('change', render);

		// The WP color picker does not always dispatch a bubbling event on the
		// underlying input, so poll every colour field as a cheap fallback.
		var colorFields = [
			'button_bg', 'button_color', 'btn_icon_color', 'btn_hover_bg',
			'popup_bg', 'header_bg', 'header_text_color', 'greeting_color',
			'greeting_bg', 'agent_bg', 'agent_hover_bg',
			'agent_name_color', 'agent_role_color'
		];
		var lastColors = '';
		setInterval(function () {
			var sig = colorFields
				.map(function (name) {
					return field(name);
				})
				.join('|');
			if (sig !== lastColors) {
				lastColors = sig;
				render();
			}
		}, 400);

		render();
	}

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	ready(function () {
		initToggles();
		initPreview();
	});
})();
