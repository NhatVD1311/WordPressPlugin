(function () {
  function initCharts() {
    document.querySelectorAll('canvas[data-chart-config]').forEach(function (canvas) {
      if (canvas._chartInstance) return;
      try {
        var config = JSON.parse(canvas.dataset.chartConfig);
        canvas._chartInstance = new Chart(canvas, config);
      } catch (e) {
        console.error('Chart init error:', e);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCharts);
  } else {
    initCharts();
  }
})();
