/**
 * Button FX — Frontend Runtime
 * Cursor-following border glow, click ripple, click celebration.
 * Pure CSS + vanilla JS, no external libraries.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var COLORS = ['#7C3AED','#06B6D4','#F43F5E','#FBBF24','#10B981','#3B82F6','#EC4899','#8B5CF6','#14B8A6','#F97316'];
  var EMOJIS = ['🎉','🎊','✨','🔥','⭐','💜','🎯','🚀','💎','🏆'];

  function ensureKeyframes(doc) {
    doc = doc || document;
    if (doc.getElementById('dnxte-btn-fx-kf')) return;
    var kf = doc.createElement('style');
    kf.id = 'dnxte-btn-fx-kf';
    kf.textContent = '@keyframes dnxte-btn-ripple{to{transform:scale(1);opacity:0}}';
    (doc.head || doc.documentElement).appendChild(kf);
  }

  // ── Glow helpers ──
  function getCursorAngle(el, x, y) {
    var rect = el.getBoundingClientRect();
    var cx = rect.width / 2;
    var cy = rect.height / 2;
    var dx = x - cx;
    var dy = y - cy;
    if (dx === 0 && dy === 0) return 0;
    var deg = Math.atan2(dy, dx) * (180 / Math.PI) + 90;
    if (deg < 0) deg += 360;
    return deg;
  }

  function getEdgeProximity(el, x, y) {
    var w = el.offsetWidth;
    var h = el.offsetHeight;
    var cx = w / 2;
    var cy = h / 2;
    var dx = x - cx;
    var dy = y - cy;
    var kx = dx !== 0 ? cx / Math.abs(dx) : 9999;
    var ky = dy !== 0 ? cy / Math.abs(dy) : 9999;
    return Math.min(Math.max(1 / Math.min(kx, ky), 0), 1);
  }

  function buildBoxShadow(colors, intensity, blur) {
    // Multi-layer inset + outset box-shadow using the first color
    var c = colors[0] || '#7C3AED';
    var layers = [];
    var steps = [
      [0, 0, 0, 1, 0.8, true],
      [0, 0, Math.round(blur * 0.1), 0, 0.5, true],
      [0, 0, Math.round(blur * 0.3), 0, 0.35, true],
      [0, 0, Math.round(blur * 0.6), 0, 0.25, true],
      [0, 0, blur, 0, 0.15, true],
      [0, 0, Math.round(blur * 0.1), 0, 0.5, false],
      [0, 0, Math.round(blur * 0.3), 0, 0.35, false],
      [0, 0, Math.round(blur * 0.6), 0, 0.25, false],
      [0, 0, blur, 2, 0.15, false],
      [0, 0, Math.round(blur * 1.5), 2, 0.08, false],
    ];
    steps.forEach(function (s) {
      var alpha = Math.min(s[4] * intensity, 1);
      layers.push((s[5] ? 'inset ' : '') + s[0] + 'px ' + s[1] + 'px ' + s[2] + 'px ' + s[3] + 'px ' + hexToRgba(c, alpha));
    });
    return layers.join(', ');
  }

  function hexToRgba(hex, alpha) {
    if (hex.indexOf('rgba') === 0 || hex.indexOf('rgb') === 0) {
      return hex.replace(/[\d.]+\)$/, alpha + ')').replace('rgb(', 'rgba(');
    }
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var r = parseInt(hex.substring(0, 2), 16);
    var g = parseInt(hex.substring(2, 4), 16);
    var b = parseInt(hex.substring(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  function buildMeshGradients(colors) {
    var positions = ['80% 55%', '69% 34%', '8% 6%', '41% 38%', '86% 85%', '82% 18%', '51% 4%'];
    var map = [0, 1, 2, 0, 1, 2, 1];
    var grads = [];
    for (var i = 0; i < 7; i++) {
      var c = colors[Math.min(map[i], colors.length - 1)];
      grads.push('radial-gradient(at ' + positions[i] + ', ' + c + ' 0px, transparent 50%)');
    }
    grads.push('linear-gradient(' + colors[0] + ' 0 100%)');
    return grads;
  }

  // ══════════════════════════════════════════════════════════
  // Main class
  // ══════════════════════════════════════════════════════════
  function DnxteButtonFx(el, config) {
    this.el = el;
    this.cfg = config;
    // Work in the element's OWN document/window — on the front-end this is the
    // page; inside the Visual Builder the button lives in the canvas iframe, so
    // createElement / getComputedStyle / rAF / body must target that frame.
    this.doc = el.ownerDocument || document;
    this.win = this.doc.defaultView || window;
    this._listeners = [];
    this._els = [];
    this._destroyed = false;
    ensureKeyframes(this.doc);
    this._init();
  }

  var proto = DnxteButtonFx.prototype;

  proto._init = function () {
    var self = this;
    var el = this.el;
    var cfg = this.cfg;

    var btn = el.querySelector('a.et_pb_button, a.dnxte-btn, button, a[href]') || el;
    this._btn = btn;
    btn.style.position = 'relative';

    if (cfg.glowBorder === 'on') this._initGlowBorder(btn, cfg);
    if (cfg.ripple === 'on') {
      var onRipple = function (e) { self._createRipple(btn, e); };
      btn.addEventListener('mousedown', onRipple);
      self._listeners.push({ el: btn, evt: 'mousedown', fn: onRipple });
      btn.style.overflow = 'hidden';
    }
    if (cfg.celebration && cfg.celebration !== 'none') {
      var triggerMode = cfg.celebrationTrigger || 'always';
      var storageKey = 'dnxte-btn-cel-' + (el.id || Math.random().toString(36).substr(2, 6));
      var onCeleb = function () {
        if (triggerMode === 'once') { if (el._celebDone) return; el._celebDone = true; }
        else if (triggerMode === 'once_session') { if (sessionStorage.getItem(storageKey)) return; sessionStorage.setItem(storageKey, '1'); }
        else if (triggerMode === 'once_ever') { if (localStorage.getItem(storageKey)) return; localStorage.setItem(storageKey, '1'); }
        self._fireCelebration(btn, cfg);
      };
      btn.addEventListener('click', onCeleb);
      self._listeners.push({ el: btn, evt: 'click', fn: onCeleb });
    }
  };

  // ── Resolve background color ──
  // Walks up the DOM to find the first non-transparent background color.
  // This is needed for the padding-box trick (same as the React BorderGlow).
  function resolveBackgroundColor(el) {
    var doc = el.ownerDocument || document;
    var win = doc.defaultView || window;
    var current = el;
    while (current && current !== doc.documentElement) {
      var bg = win.getComputedStyle(current).backgroundColor;
      if (bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') return bg;
      current = current.parentElement;
    }
    return '#000000';
  }

  // ── Cursor-following border glow ──
  // Uses the EXACT same padding-box/border-box technique as the React
  // BorderGlow component: gradient fills border-box, solid bg fills
  // padding-box on top → gradient only visible in the 1px border strip.
  proto._initGlowBorder = function (btn, cfg) {
    var self = this;
    var doc = self.doc;
    var win = self.win;
    var colors = [cfg.glowColor1 || '#7C3AED', cfg.glowColor2 || '#06B6D4', cfg.glowColor3 || '#F43F5E'];
    var intensity = parseFloat(cfg.glowIntensity) || 1;
    var blur = parseFloat(cfg.glowBlur) || 15;
    var spread = parseFloat(cfg.glowSpread) || 25;

    btn.style.position = 'relative';
    btn.style.isolation = 'isolate';

    // Resolve the actual visible bg color (walk up DOM if transparent)
    var bgColor = resolveBackgroundColor(btn);

    var meshGrads = buildMeshGradients(colors);
    // Border backgrounds with border-box sizing
    var borderBgs = meshGrads.map(function (g) { return g + ' border-box'; });

    // ── Border overlay: padding-box trick (identical to React BorderGlow) ──
    var borderEl = doc.createElement('div');
    borderEl.className = 'dnxte-btn-glow-border';
    borderEl.style.cssText = [
      'position:absolute', 'inset:0', 'pointer-events:none', 'z-index:-1',
      'border-radius:inherit', 'border:1px solid transparent',
      'opacity:0', 'transition:opacity 0.25s ease-out'
    ].join(';') + ';';

    // Static background: solid bg on padding-box covers interior,
    // mesh gradient on border-box peeks through only at the 1px border
    borderEl.style.background = [
      'linear-gradient(' + bgColor + ' 0 100%) padding-box',
      'linear-gradient(rgba(255,255,255,0) 0% 100%) border-box'
    ].concat(borderBgs).join(', ');

    // ── Outer glow (box-shadow layers) ──
    var glowOuter = doc.createElement('span');
    glowOuter.className = 'dnxte-btn-glow-outer';
    glowOuter.style.cssText = [
      'position:absolute', 'pointer-events:none', 'z-index:1',
      'border-radius:inherit', 'opacity:0',
      'mix-blend-mode:plus-lighter', 'transition:opacity 0.25s ease-out'
    ].join(';') + ';';
    glowOuter.style.inset = '-' + Math.round(blur) + 'px';

    var glowInner = doc.createElement('span');
    glowInner.style.cssText = 'position:absolute;border-radius:inherit;inset:' + Math.round(blur) + 'px;';
    glowOuter.appendChild(glowInner);

    btn.appendChild(borderEl);
    btn.appendChild(glowOuter);
    this._els.push(borderEl, glowOuter);

    var cursorAngle = 0;
    var edgeProx = 0;
    var isHovered = false;

    function updateVisuals() {
      var angleDeg = cursorAngle.toFixed(1) + 'deg';
      var s = spread;

      // Conic mask: cursor-following cone of visibility
      var maskCone = 'conic-gradient(from ' + angleDeg + ' at center, black ' + s + '%, transparent ' + (s + 15) + '%, transparent ' + (100 - s - 15) + '%, black ' + (100 - s) + '%)';
      borderEl.style.maskImage = maskCone;
      borderEl.style.webkitMaskImage = maskCone;

      // Outer glow mask — narrower cone
      var maskGlow = 'conic-gradient(from ' + angleDeg + ' at center, black 2.5%, transparent 10%, transparent 90%, black 97.5%)';
      glowOuter.style.maskImage = maskGlow;
      glowOuter.style.webkitMaskImage = maskGlow;

      // Box shadow on inner span
      glowInner.style.boxShadow = buildBoxShadow(colors, intensity * edgeProx, blur);

      // Opacity based on edge proximity (same formula as React component)
      var edgeSensitivity = 30;
      var colorSensitivity = edgeSensitivity + 20;
      var borderOpacity = isHovered
        ? Math.max(0, (edgeProx * 100 - colorSensitivity) / (100 - colorSensitivity))
        : 0;
      var glowOpacity = isHovered
        ? Math.max(0, (edgeProx * 100 - edgeSensitivity) / (100 - edgeSensitivity))
        : 0;

      borderEl.style.opacity = borderOpacity;
      glowOuter.style.opacity = glowOpacity;
    }

    var onMove = function (e) {
      var rect = btn.getBoundingClientRect();
      var x = e.clientX - rect.left;
      var y = e.clientY - rect.top;
      cursorAngle = getCursorAngle(btn, x, y);
      edgeProx = getEdgeProximity(btn, x, y);
      updateVisuals();
    };

    var onEnter = function () {
      isHovered = true;
      borderEl.style.transition = 'opacity 0.25s ease-out';
      glowOuter.style.transition = 'opacity 0.25s ease-out';
    };

    var onLeave = function () {
      isHovered = false;
      edgeProx = 0;
      borderEl.style.transition = 'opacity 0.75s ease-in-out';
      glowOuter.style.transition = 'opacity 0.75s ease-in-out';
      updateVisuals();
    };

    // ── Auto-play mode: glow sweeps around border continuously ──
    var autoPlay = cfg.glowAutoPlay === 'on';
    var autoSpeed = parseFloat(cfg.glowAutoSpeed) || 3; // seconds per full rotation
    var autoFrame = null;

    if (autoPlay) {
      // Auto-play: continuously animate the glow around the border
      edgeProx = 0.85; // constant edge proximity for auto mode
      var degsPerFrame = 360 / (autoSpeed * 60); // ~60fps

      function autoTick() {
        cursorAngle = (cursorAngle + degsPerFrame) % 360;

        var angleDeg = cursorAngle.toFixed(1) + 'deg';
        var s = spread;

        var maskCone = 'conic-gradient(from ' + angleDeg + ' at center, black ' + s + '%, transparent ' + (s + 15) + '%, transparent ' + (100 - s - 15) + '%, black ' + (100 - s) + '%)';
        borderEl.style.maskImage = maskCone;
        borderEl.style.webkitMaskImage = maskCone;

        var maskGlow = 'conic-gradient(from ' + angleDeg + ' at center, black 2.5%, transparent 10%, transparent 90%, black 97.5%)';
        glowOuter.style.maskImage = maskGlow;
        glowOuter.style.webkitMaskImage = maskGlow;

        glowInner.style.boxShadow = buildBoxShadow(colors, intensity * edgeProx, blur);

        borderEl.style.opacity = '0.9';
        glowOuter.style.opacity = '0.7';

        autoFrame = win.requestAnimationFrame(autoTick);
      }

      // Start immediately
      autoTick();
      self._autoFrame = function () { if (autoFrame) win.cancelAnimationFrame(autoFrame); };

      // On hover: boost intensity, on leave: return to auto
      var onAutoEnter = function () {
        edgeProx = 1;
      };
      var onAutoLeave = function () {
        edgeProx = 0.85;
      };
      btn.addEventListener('pointerenter', onAutoEnter);
      btn.addEventListener('pointerleave', onAutoLeave);
      self._listeners.push({ el: btn, evt: 'pointerenter', fn: onAutoEnter });
      self._listeners.push({ el: btn, evt: 'pointerleave', fn: onAutoLeave });
    } else {
      // Hover mode: only show glow on mouse interaction
      btn.addEventListener('pointerenter', onEnter);
      btn.addEventListener('pointermove', onMove);
      btn.addEventListener('pointerleave', onLeave);
      self._listeners.push({ el: btn, evt: 'pointerenter', fn: onEnter });
      self._listeners.push({ el: btn, evt: 'pointermove', fn: onMove });
      self._listeners.push({ el: btn, evt: 'pointerleave', fn: onLeave });
    }
  };

  // ── Ripple with custom color ──
  proto._createRipple = function (btn, e) {
    var rect = btn.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height) * 2;
    var x = e.clientX - rect.left - size / 2;
    var y = e.clientY - rect.top - size / 2;
    var color = this.cfg.rippleColor || 'rgba(255,255,255,0.35)';

    var ripple = this.doc.createElement('div');
    ripple.style.cssText = [
      'position:absolute', 'border-radius:50%', 'pointer-events:none',
      'background:' + color,
      'width:' + size + 'px', 'height:' + size + 'px',
      'left:' + x + 'px', 'top:' + y + 'px',
      'transform:scale(0)', 'opacity:1', 'z-index:2',
      'animation:dnxte-btn-ripple 0.6s ease-out forwards'
    ].join(';') + ';';
    btn.appendChild(ripple);
    setTimeout(function () { if (ripple.parentNode) ripple.parentNode.removeChild(ripple); }, 700);
  };

  // ── Celebration ──
  proto._fireCelebration = function (btn, cfg) {
    var doc = this.doc;
    var type = cfg.celebration;
    var count = parseInt(cfg.celebrationCount) || 30;
    var rect = btn.getBoundingClientRect();
    var originX = rect.left + rect.width / 2;
    var originY = rect.top + rect.height / 2;

    for (var i = 0; i < count; i++) {
      var particle = doc.createElement('div');
      particle.style.position = 'fixed';
      particle.style.pointerEvents = 'none';
      particle.style.zIndex = '99999';
      particle.style.left = originX + 'px';
      particle.style.top = originY + 'px';

      var angle = Math.random() * Math.PI * 2;
      var dist = 150 + Math.random() * 250;
      var dx = Math.cos(angle) * dist;
      var dy = Math.sin(angle) * dist - 100;
      var dur = 0.8 + Math.random() * 0.7;
      var rot = Math.random() * 720;

      if (type === 'confetti') {
        particle.style.width = (6 + Math.random() * 6) + 'px';
        particle.style.height = (4 + Math.random() * 8) + 'px';
        particle.style.background = COLORS[Math.floor(Math.random() * COLORS.length)];
        particle.style.borderRadius = Math.random() > 0.5 ? '50%' : '1px';
      } else if (type === 'stars') {
        particle.textContent = '★';
        particle.style.fontSize = (12 + Math.random() * 12) + 'px';
        particle.style.color = COLORS[Math.floor(Math.random() * COLORS.length)];
        particle.style.textShadow = '0 0 6px currentColor';
      } else if (type === 'emoji') {
        particle.textContent = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
        particle.style.fontSize = (14 + Math.random() * 10) + 'px';
      } else if (type === 'fireworks') {
        particle.style.width = '2px';
        particle.style.height = (8 + Math.random() * 8) + 'px';
        var fwColor = COLORS[Math.floor(Math.random() * COLORS.length)];
        particle.style.background = fwColor;
        particle.style.boxShadow = '0 0 4px ' + fwColor;
        particle.style.borderRadius = '1px';
      }

      particle.style.transition = 'transform ' + dur + 's ease-out, opacity ' + dur + 's ease-out';
      doc.body.appendChild(particle);
      particle.offsetHeight;
      particle.style.transform = 'translate(' + dx + 'px, ' + dy + 'px) rotate(' + rot + 'deg)';
      particle.style.opacity = '0';

      (function (p, d) {
        setTimeout(function () { if (p.parentNode) p.parentNode.removeChild(p); }, d * 1000 + 100);
      })(particle, dur);
    }
  };

  proto.destroy = function () {
    this._destroyed = true;
    this._listeners.forEach(function (l) { try { l.el.removeEventListener(l.evt, l.fn); } catch (e) {} });
    this._els.forEach(function (el) { if (el && el.parentNode) el.parentNode.removeChild(el); });
    if (this._autoFrame) this._autoFrame();
    if (this._btn) { this._btn.style.boxShadow = ''; this._btn.style.overflow = ''; }
    this._listeners = []; this._els = [];
  };

  // ── Auto-init ──
  function initAll() {
    var els = document.querySelectorAll('[data-btn-fx-init="true"]');
    els.forEach(function (el) {
      if (el._dnxteButtonFx) return;
      var raw = el.getAttribute('data-btn-fx-config');
      if (!raw) return;
      try {
        var cfg = JSON.parse(raw);
        if (!cfg || cfg.enabled !== 'on') return;
        el._dnxteButtonFx = new DnxteButtonFx(el, cfg);
      } catch (e) { console.warn('[ButtonFX] Init failed:', e); }
    });
  }

  function boot() {
    initAll();
    if (document.body) {
      var observer = new MutationObserver(function (mutations) {
        var shouldInit = false;
        mutations.forEach(function (m) { if (m.addedNodes && m.addedNodes.length) shouldInit = true; });
        if (shouldInit) initAll();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.DnxteButtonFx = DnxteButtonFx;
})();
