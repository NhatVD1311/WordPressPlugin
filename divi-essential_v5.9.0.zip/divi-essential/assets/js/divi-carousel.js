(function ($) {
  "use strict";
  const swiperElements = document?.querySelectorAll(
    ".dnxte-coverflowslider-active"
  );

  if (!swiperElements.length) {
    console.warn("No elements found for Swiper.");
    return;
  }

  swiperElements.forEach((swiperEl) => {
    if (!swiperEl) return;
    let lightBox = swiperEl.dataset.lightBox;
    if (lightBox === "on") {
      $(".dnxte-coverflowslider-active .swiper-wrapper").magnificPopup({
        delegate: "a.dnxte-coverflow-image-link",
        type: "image",
        mainClass: "dnxte-msnary-wrapper",
        gallery: {
          enabled: true,
          navigateByImgClick: true,
        },
        zoom: {
          enabled: true,
          duration: 500,
          opener: function (element) {
            return element.find("img");
          },
        },
        image: {
          markup:
            `<div class="mfp-figure dnxte-coverflow-mfp-config ${`ss`}">` +
            '<div class="mfp-close"></div>' +
            '<div class="mfp-img"></div>' +
            '<div class="mfp-bottom-bar">' +
            '<div class="mfp-title"></div>' +
            '<div class="mfp-counter"></div>' +
            "</div>" +
            "</div>",
          titleSrc: function (item) {
            const caption = item.el.attr("data-caption") || "";
            return item.el.attr("data-title") + caption;
          },
        },
      });
    }
    else { 
      // Prevent default action for links with class 'link_prevent_default'
      let linkPrevent = swiperEl.querySelector(".link_prevent_default");
      if (linkPrevent) {
        linkPrevent.addEventListener("click", function (e) {
          e.preventDefault();
        });  
      }
    }
    let get_sl_per_view = swiperEl.dataset.slidesPerView;

    let sl_per_view = get_sl_per_view ? get_sl_per_view.split("|") : [];

    let slidesPerView = sl_per_view ? parseInt(sl_per_view[0]) : 3;
    let spaceBetween = swiperEl.dataset.spaceBetween
      ? parseInt(swiperEl.dataset.spaceBetween)
      : 10;
    let loop = swiperEl.dataset.loop === "on" ? true : false;
    let centerSlide = swiperEl.dataset.centeredSlides === "on" ? true : false;
    let grabCursor = swiperEl.dataset.grabCursor === "on" ? true : false;
    let speed = swiperEl.dataset.speed
      ? parseInt(swiperEl.dataset.speed)
      : null;
    let keyboard = swiperEl.dataset.keyboard;
    let navigation = swiperEl.dataset.navigation;
    let mousewheel = swiperEl.dataset.mousewheel;
    let rotate = swiperEl.dataset.rotate;
    let stretch = swiperEl.dataset.stretch;
    let depth = swiperEl.dataset.depth;
    let slideShadow = swiperEl.dataset.slideShadow;
    let autoHeight = swiperEl.dataset.autoHeight;
    let autoplay = swiperEl.dataset.autoplay;
    let delay = swiperEl.dataset.delay;
    let paginationType = swiperEl.dataset.paginationType;
    let dynamicBullets = swiperEl.dataset.dynamicBullets;
    new Swiper(swiperEl, {
      centeredSlides: centerSlide,
      slidesPerView: slidesPerView,
      spaceBetween: spaceBetween,
      loop: loop,
      grabCursor: grabCursor,
      speed: speed,
      autoHeight: autoHeight,
      autoplay: autoplay === "on" ? { delay: parseInt(delay) } : false,
      navigation:
        navigation === "on"
          ? {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
            }
          : false,
      keyboard:
        keyboard === "on"
          ? {
              enabled: true,
              onlyInViewport: false,
            }
          : false,
      mousewheel:
        mousewheel === "on"
          ? {
              enabled: true,
              invert: false,
            }
          : false,
      observer: true,
      observeParents: true,
      effect: "coverflow",
      coverflowEffect: {
        rotate: parseInt(rotate),
        stretch: parseInt(stretch),
        depth: parseInt(depth),
        slideShadows: slideShadow === "on" ? true : false,
      },
      direction: "horizontal",
      breakpoints: {
        1024: {
          slidesPerView: sl_per_view ? parseInt(sl_per_view[0]) : 3,
        },
        768: {
          slidesPerView: sl_per_view ? parseInt(sl_per_view[1]) : 2,
        },
        479: {
          slidesPerView: sl_per_view ? parseInt(sl_per_view[2]) : 1,
        },
        200: {
          slidesPerView: sl_per_view ? parseInt(sl_per_view[2]) : 1,
        },
      },
      pagination: {
        el: ".swiper-pagination",
        type: paginationType,
        dynamicBullets: dynamicBullets === "on" ? true : false,
        clickable: true,
      },
    });
  });
})(jQuery);
