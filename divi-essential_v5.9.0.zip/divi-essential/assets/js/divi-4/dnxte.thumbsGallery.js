jQuery(document).ready(function ($) {
  if ($(".dnxte_thumbs_gallery_child").length) {
    $(".dnxte_thumbs_gallery_child").addClass("swiper-slide");
    $(".dnxte_thumbs_gallery_child .et_pb_module_inner").addClass(
      "dnext-thumbs-gallery-item"
    );
  }

  $(".dnext-thumbs-gallery-top").length &&
    $(".dnext-thumbs-gallery-top").each(function (index) {
      var $moduleWrapper = $(this).closest(".dnxte_thumbs_gallery_parent");
      var $bottomGallery = $moduleWrapper.find(".dnext-thumbs-gallery-bottom");

      if (!$bottomGallery.length) {
        return;
      }

      var thumbsBottomData = $bottomGallery.data();
      if (!thumbsBottomData) {
        return;
      }

      var thumbsBottomBreakpoint =
        thumbsBottomData.breakpoints &&
        thumbsBottomData.breakpoints.split("|");

      var thumbsBottomSwiper = new Swiper($bottomGallery[0], {
        watchSlidesProgress: true,
        slideToClickedSlide: true,
        direction: thumbsBottomData.direction,
        speed: thumbsBottomData.speed ? parseInt(thumbsBottomData.speed) : 400,
        spaceBetween: parseInt(thumbsBottomData.spacing),
        grabCursor: "on" === thumbsBottomData.grab,
        preventClicksPropagation: true,
        autoplay: {
          enabled: 1 === thumbsBottomData.autoplay,
          delay: thumbsBottomData.delay
            ? parseInt(thumbsBottomData.delay)
            : 0,
          disableOnInteraction: !1,
        },
        centeredSlides: "on" === thumbsBottomData.center,
        loop: "on" === thumbsBottomData.loop,
        freeMode: true,
        breakpoints: {
          1024: {
            slidesPerView:
              thumbsBottomBreakpoint && parseInt(thumbsBottomBreakpoint[0]),
          },
          768: {
            slidesPerView:
              thumbsBottomBreakpoint && parseInt(thumbsBottomBreakpoint[1]),
          },
          479: {
            slidesPerView:
              thumbsBottomBreakpoint && parseInt(thumbsBottomBreakpoint[2]),
          },
          200: {
            slidesPerView:
              thumbsBottomBreakpoint && parseInt(thumbsBottomBreakpoint[2]),
          },
        },
        keyboard: {
          enabled: "on" === thumbsBottomData.keyboard,
          onlyInViewport: false,
        },
        mousewheel: {
          enabled: "on" === thumbsBottomData.mouse,
          invert: true,
        },
        observer: !0,
        observeParents: !0,
        observeSlideChildren: !0,
        watchSlidesVisibility: true,
      });

      if (
        1 === thumbsBottomData.autoplay &&
        thumbsBottomData.pauseonhover === 1
      ) {
        $bottomGallery.on("mouseenter", function () {
          thumbsBottomSwiper.autoplay.stop();
        });
        $bottomGallery.on("mouseleave", function () {
          thumbsBottomSwiper.autoplay.start();
        });
      }

      var thumbsData = $(this).data();
      if (!thumbsData) {
        return;
      }

      var thumbsBreakpoint =
        thumbsData.breakpoints && thumbsData.breakpoints.split("|");

      var thumbsSwiper = new Swiper(this, {
        direction: thumbsData.direction,
        thumbs: {
          swiper: thumbsBottomSwiper,
        },
        speed: thumbsData.speed ? parseInt(thumbsData.speed) : 400,
        spaceBetween: parseInt(thumbsData.spacing),
        grabCursor: "on" === thumbsData.grab,
        preventClicksPropagation: true,
        autoplay: {
          enabled: 1 === thumbsData.autoplay,
          delay: thumbsData.delay ? parseInt(thumbsData.delay) : 0,
          disableOnInteraction: !1,
        },
        slidesPerView: thumbsBreakpoint && parseInt(thumbsBreakpoint[0]),
        centeredSlides: "on" === thumbsData.center,
        loop: "on" === thumbsData.loop,
        breakpoints: {
          1024: {
            slidesPerView: thumbsBreakpoint && parseInt(thumbsBreakpoint[0]),
          },
          768: {
            slidesPerView: thumbsBreakpoint && parseInt(thumbsBreakpoint[1]),
          },
          479: {
            slidesPerView: thumbsBreakpoint && parseInt(thumbsBreakpoint[2]),
          },
          200: {
            slidesPerView: thumbsBreakpoint && parseInt(thumbsBreakpoint[2]),
          },
        },
        pagination: {
          el: ".swiper-pagination",
          dynamicBullets: "on" === thumbsData.paginationBullets,
          clickable: true,
          type: thumbsData.paginationType,
        },
        keyboard: {
          enabled: "on" === thumbsData.keyboard,
          onlyInViewport: false,
        },
        mousewheel: {
          enabled: "on" === thumbsData.mouse,
          invert: true,
        },
        navigation: {
          nextEl: $(this).siblings(".swiper-button-next")[0],
          prevEl: $(this).siblings(".swiper-button-prev")[0],
        },
        observer: !0,
        observeParents: !0,
        observeSlideChildren: !0,
      });

      if (1 === thumbsData.autoplay && thumbsData.pauseonhover === 1) {
        $(this).on("mouseenter", function () {
          thumbsSwiper.autoplay.stop();
          thumbsBottomSwiper.autoplay.stop();
        });
        $(this).on("mouseleave", function () {
          thumbsSwiper.autoplay.start();
          thumbsBottomSwiper.autoplay.start();
        });
      }
    });
});
