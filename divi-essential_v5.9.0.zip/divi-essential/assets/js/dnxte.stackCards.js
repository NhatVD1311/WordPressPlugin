class DNXTEStackCards {
    constructor() {
        this.containers = [];
        this.horizontalContainers = new Map();
        this.init();
    }

    init() {
        // Check if body has et-fb class (Divi Builder)
        if (document.body && document.body.classList.contains('et-fb')) {
            return;
        }

        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        // Get all stack card containers
        const containers = document.querySelectorAll('.dnxte-stack-cards-container');
        
        containers.forEach(container => {
            this.setupContainer(container);
        });
    }

    setupContainer(container) {
        const cards = container.querySelectorAll('.dnxte-stack-card-item');
        
        if (!cards.length) return;

        // Get attributes from container
        const stackDirection = container.dataset.stackDirection || container.dataset.direction || 'vertical';
        
        if (stackDirection === 'horizontal') {
            this.setupHorizontalContainer(container, cards);
        } else {
            this.setupVerticalContainer(container, cards);
        }
    }

    setupHorizontalContainer(container, cards) {
        const parentModule = container.closest('.dnxte_scroll_stacking_cards');
        const wrapper = parentModule.querySelector('.wrapper');

        // Prevent duplicate setup
        if (this.horizontalContainers.has(parentModule)) {
            return;
        }

        this.horizontalContainers.set(parentModule, true);

        // Check if GSAP is available
        if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
            console.warn('GSAP or ScrollTrigger not loaded');
            return;
        }

        // Ensure GSAP plugin is registered
        gsap.registerPlugin(ScrollTrigger);

        if (!wrapper || cards.length === 0) return;

        // The Browser Scrollbar extension (SimpleBar) moves the page into a custom
        // scroll container, so the window no longer scrolls and ScrollTrigger — which
        // listens to window scroll by default — never fires. Resolve the active
        // scroller (window, or SimpleBar's scroll element) before building the trigger.
        this.withScroller((scroller) => {
            this.createHorizontalScrollTrigger(container, cards, wrapper, scroller);
        });
    }

    /**
     * Resolve the scroll container that ScrollTrigger should observe and invoke
     * `callback(scroller)` with it.
     *
     * Default is `window`. When the Browser Scrollbar extension is enabled it wraps
     * the page in `#dnxte_simplebar` and the real scroller becomes
     * `.simplebar-content-wrapper`. SimpleBar boots asynchronously (after a rAF inside
     * jQuery ready), so that wrapper may not exist yet when this module initializes —
     * in that case we wait for the `dnxteSimpleBarReady` event before resolving, with
     * a timeout fallback to `window` if SimpleBar never comes up.
     */
    withScroller(callback) {
        const getWrapper = () => document.querySelector('#dnxte_simplebar .simplebar-content-wrapper');

        // SimpleBar already initialized — use its scroll element.
        const existing = getWrapper();
        if (existing) {
            callback(existing);
            return;
        }

        // Browser Scrollbar extension present but not yet booted — wait for it.
        const simplebarPending = typeof window.dnxte_scroll_config !== 'undefined'
            && !document.body.classList.contains('et-fb');

        if (!simplebarPending) {
            callback(window);
            return;
        }

        let resolved = false;
        const resolve = () => {
            if (resolved) return;
            resolved = true;
            callback(getWrapper() || window);
        };

        document.addEventListener('dnxteSimpleBarReady', resolve, { once: true });
        // Safety net: if SimpleBar fails to init, fall back to window scroll.
        setTimeout(resolve, 1500);
    }

    createHorizontalScrollTrigger(container, cards, wrapper, scroller) {
        const usingCustomScroller = scroller && scroller !== window;

        // Get sticky top position from data attribute (for horizontal pinning offset)
        const stickyTopPositionRaw = container.dataset.stickyTopPosition || '50px';
        // Parse the value - could be "50px" or "50"
        const stickyTopValue = parseInt(stickyTopPositionRaw) || 0;
        // Format for ScrollTrigger start position
        const startPosition = stickyTopValue > 0 ? `top ${stickyTopValue}px` : 'top top';

        const animation = gsap.timeline();
        let cardWidth;

        const initCards = () => {
            animation.clear();
            cardWidth = cards[0].offsetWidth;

            cards.forEach((card, index) => {
                if (index > 0) {
                    // Set initial position
                    gsap.set(card, {x: index * cardWidth});
                    // Animate to stacked position
                    animation.to(card, {x: index * 50, duration: index * 0.5, ease: "none"}, 0);
                }
            });
        };

        initCards();

        const scrollTrigger = ScrollTrigger.create({
            trigger: wrapper,
            scroller: scroller || window, // Use SimpleBar's element when the Browser Scrollbar extension is active
            start: startPosition, // Use sticky top position for pin offset (e.g., "top 50px")
            pin: true,
            pinSpacing: true,
            end: () => `+=${(cards.length * cardWidth)}`,
            scrub: true,
            animation: animation,
            markers: false,
            invalidateOnRefresh: true,
            // Apply the top offset when pinning starts. With a custom scroller
            // ScrollTrigger pins via transform, so the manual top would double the
            // offset — skip it and let the `start` position handle the gap.
            onEnter: () => {
                if (!usingCustomScroller && stickyTopValue > 0) {
                    wrapper.style.top = `${stickyTopValue}px`;
                }
            },
            // Reset top when scrolling back past the start
            onLeaveBack: () => {
                if (!usingCustomScroller && stickyTopValue > 0) {
                    wrapper.style.top = '';
                }
            },
            // Also handle the active state on refresh
            onRefresh: (self) => {
                if (!usingCustomScroller && self.isActive && stickyTopValue > 0) {
                    wrapper.style.top = `${stickyTopValue}px`;
                }
            }
        });

        const refreshHandler = () => initCards();
        ScrollTrigger.addEventListener("refreshInit", refreshHandler);

        // SimpleBar lays out asynchronously, so refresh once the trigger is bound to
        // the custom scroller to recompute pin spacing against its final size.
        if (usingCustomScroller) {
            ScrollTrigger.refresh();
        }

        // Store reference for cleanup
        this.containers.push({
            element: container,
            cards: cards,
            scrollTrigger: scrollTrigger,
            cleanup: () => {
                ScrollTrigger.removeEventListener("refreshInit", refreshHandler);
                if (scrollTrigger) {
                    scrollTrigger.kill();
                }
            }
        });
    }

    setupVerticalContainer(container, cards) {
        // Set equal heights for vertical stack cards
        this.setEqualHeights(cards);

        // Get attributes from container
        const stickyTopPosition = container.dataset.stickyTopPosition || '20px';
        const stackEffect = container.dataset.stackEffect || '';
        const enableScrollMotion = container.dataset.enableScrollMotion !== 'off';
        const scrollMotionDuration = parseInt(container.dataset.scrollMotionDuration || '200');

        // Set CSS custom properties
        container.style.setProperty('--cards-count', cards.length);
        container.style.setProperty('--sticky-top-position', stickyTopPosition);
        container.style.setProperty('--scroll-duration', `${scrollMotionDuration}ms`);

        // Fix: Remove residual transforms from animated ancestors that break position:sticky
        this.fixAnimatedAncestors(container);

        // Store container reference
        this.containers.push({
            element: container,
            cards: cards
        });

        // Add resize listener for vertical cards only
        window.addEventListener('resize', () => {
            this.setEqualHeights(cards);
        });

        // Only setup animation if stack effect is not 'none' and scroll motion is enabled
        if (stackEffect !== 'none' && enableScrollMotion && typeof aat !== 'undefined') {
            // Setup vertical animation (existing code)
            this.setupVerticalAnimation(container, cards, stackEffect, stickyTopPosition);
        } else {
            // Basic vertical setup
            Array.from(cards).forEach((card, index) => {
                const stickyTopValue = parseInt(stickyTopPosition);
                const offsetTop = stickyTopValue + index * 20;
                card.style.top = `${offsetTop}px`;
            });
        }
    }

    /**
     * Fix: Two issues prevent position:sticky from working with Divi animations:
     *
     * 1. Divi's et_process_animation_data() sets overflow-y:hidden on #page-container.
     *    Per CSS spec, overflow:hidden creates a "scrolling mechanism" that captures
     *    position:sticky, making sticky elements stick relative to the non-scrolling
     *    #page-container instead of the viewport. This is the PRIMARY cause.
     *
     * 2. Some CSS animation keyframes end with identity-equivalent transforms
     *    (e.g. scaleX(1), translateZ(0)) which create new containing blocks.
     *    Divi's cleanup function removes these, but there's a brief window
     *    during animation where they break sticky.
     *
     * Note: Our script loads BEFORE Divi's frontend scripts, so we use a
     * MutationObserver to catch overflow changes that happen after our init.
     */
    fixAnimatedAncestors(container) {
        // Fix 1: Prevent overflow-y:hidden on #page-container from breaking sticky.
        // Divi sets this when ANY animation data exists on the page.
        // It's never removed by Divi's cleanup, so sticky stays broken permanently.
        // Only set up once even if multiple vertical containers exist on the page.
        if (!DNXTEStackCards._overflowObserverAttached) {
            DNXTEStackCards._overflowObserverAttached = true;
            const pageContainer = document.getElementById('page-container');
            if (pageContainer) {
                const fixOverflow = () => {
                    if (pageContainer.style.overflowY === 'hidden') {
                        pageContainer.style.overflowY = '';
                    }
                };
                fixOverflow();

                // Our script loads before Divi's, so watch for Divi setting it later
                const overflowObserver = new MutationObserver(fixOverflow);
                overflowObserver.observe(pageContainer, {
                    attributes: true,
                    attributeFilter: ['style']
                });
            }
        }

        // Fix 2: Clear transforms from animated ancestors
        let ancestor = container.parentElement;
        while (ancestor && ancestor !== document.body) {
            const el = ancestor;

            if (el.classList.contains('et_had_animation')) {
                this.clearAncestorTransform(el);
            }

            el.addEventListener('animationend', (e) => {
                if (e.target === el) {
                    requestAnimationFrame(() => {
                        this.clearAncestorTransform(el);
                    });
                }
            });

            ancestor = ancestor.parentElement;
        }
    }

    clearAncestorTransform(element) {
        const computed = window.getComputedStyle(element);
        if (computed.transform && computed.transform !== 'none') {
            element.style.setProperty('transform', 'none', 'important');
        }
    }

	setEqualHeights(cards) {
		if (!cards || !cards.length) return;

		// Per-item height mode (data-height-mode): "dynamic" cards keep their natural
		// content height, "manual" cards are sized by CSS — only "equal" cards (or
		// cards without the attribute, e.g. posts source) get equalized.
		const equalCards = Array.from(cards).filter(card => {
			const mode = card.dataset.heightMode || 'equal';
			if (mode === 'dynamic') {
				card.style.height = 'auto';
			}
			return mode !== 'dynamic' && mode !== 'manual';
		});

		if (!equalCards.length) return;

		// Reset heights to get natural size
		equalCards.forEach(card => {
			card.style.height = 'auto';
		});

		// Find max height
		const maxHeight = Math.max(...equalCards.map(card => card.offsetHeight));

		// Apply max height to all cards
		equalCards.forEach(card => {
			card.style.height = `${maxHeight}px`;
		});
	}

    setupVerticalAnimation(container, cards, stackEffect, stickyTopPosition) {
        const { ScrollObserver, valueAtPercentage } = aat;
        const stickyTopValue = parseInt(stickyTopPosition);
        
        Array.from(cards).forEach((card, index) => {
            // Set sticky top offset per card to create the stagger peek effect
            let offsetTop = stickyTopValue + index * 20;

            card.style.top = `${offsetTop}px`;
            this.setEqualHeights(cards);

            // Skip animation for the last card
            if (index === cards.length - 1) {
                return;
            }

            const nextCard = cards[index + 1];
            const cardInner = card.querySelector('.dnxte-stack-card-wrap');

            if (!cardInner) return;

            // Get viewport percentage from container
            const viewportStart = container.dataset.animationStartViewPort || '0';
            const viewportPercentage = parseInt(viewportStart) / 100;

            // Create scroll observer for this card
            const observer = ScrollObserver.Element(nextCard, {
                offsetTop: offsetTop + (window.innerHeight * viewportPercentage),
                offsetBottom: window.innerHeight - card.clientHeight,
            });

            // Handle scroll events based on effect type
            observer.onScroll(({ percentageY }) => {
                switch (stackEffect) {
                    case 'scale':
                        const toScale = 1 - (cards.length - 1 - index) * 0.1;
                        cardInner.style.transform = `scale(${valueAtPercentage({
                            from: 1,
                            to: toScale,
                            percentage: percentageY,
                        })})`;
                        break;

                    case 'slide':
                        const slideY = valueAtPercentage({
                            from: 0,
                            to: -30,
                            percentage: percentageY,
                        });
                        cardInner.style.transform = `translateY(${slideY}px)`;
                        break;

                    case 'rotate':
                        const rotation = valueAtPercentage({
                            from: 0,
                            to: 5,
                            percentage: percentageY,
                        });
                        cardInner.style.transform = `rotate(${rotation}deg)`;
                        break;

                    default:
                        const defaultScale = 1 - (cards.length - 1 - index) * 0.1;
                        cardInner.style.transform = `scale(${valueAtPercentage({
                            from: 1,
                            to: defaultScale,
                            percentage: percentageY,
                        })})`;
                }
            });
        });
    }

    destroy() {
        // Clean up
        this.containers.forEach(container => {
            if (container.cleanup) {
                container.cleanup();
            }
            if (container.scrollTrigger) {
                container.scrollTrigger.kill();
            }
        });

        this.containers = [];
        this.horizontalContainers.clear();
    }
}

// Initialize the stack cards
new DNXTEStackCards();