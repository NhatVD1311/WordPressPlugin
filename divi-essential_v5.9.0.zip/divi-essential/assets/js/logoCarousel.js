; (function ($) {
    $(document).ready(function () {
        // Logo Carousel
        $(".dnext-logo-carosuel-active").each(function(e) {
          const logoData = $(this).data();
          const carouselBreakpoint =
            logoData.breakpoints && logoData.breakpoints.split("|");
          
          const logoSwiper = new Swiper(this, {
            
            // direction: logoData.direction,
            speed: logoData.speed ? parseInt(logoData.speed) : 400,
            spaceBetween: parseInt(logoData.spacing),
            centeredSlides: "on" === logoData.center,
            grabCursor: "on" === logoData.grab,
            loop: "on" === logoData.loop,
            slidesPerView: carouselBreakpoint && parseInt(carouselBreakpoint[0]),
            autoplay: "on" === logoData.autoplay  ? { delay: "on" === logoData.smoothscrolling ? 0 : logoData.delay, disableOnInteraction: false } : false,
            centeredSlides: "on" === logoData.center,
            breakpoints: {
              1024: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[0]) : 4 ,
              },
              768: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[1]) : 3,
              },
              479: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 2,
              },
              200: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 1,
              },
            },
            pagination: {
              el: ".swiper-pagination",
              type: logoData.paginationtype,
              dynamicBullets: "on" === logoData.dynamicbullets,
              clickable: true,
            },
            keyboard: {
              enabled: "on" === logoData.keyboard,
              onlyInViewport: false,
            },
            mousewheel: {
              enabled: "on" === logoData.mouse,
              invert: true,
            },
            navigation: "on" === logoData.usearrownavigation ? {
              nextEl:
                $(this).siblings(".swiper-button-next")[0] ||
                $(this)
                  .siblings(".swiper-button-container")
                  .children(".swiper-button-next")[0],
              prevEl:
                $(this).siblings(".swiper-button-prev")[0] ||
                $(this)
                  .siblings(".swiper-button-container")
                  .children(".swiper-button-prev")[0],
          } : false,
            observer: true,
            observeParents: true,
            observeSlideChildren: true,
          });

          // Handle autoplay on hover
          if ('on' === logoData.autoplay && 'on' === logoData.pauseonhover) {
            $(this).on("mouseenter", function() {
              logoSwiper.autoplay.stop();
            });
            $(this).on("mouseleave", function() {
              logoSwiper.autoplay.start();
            });
          }
            // if (logoData.pauseonhover === "on") {
            //   const handleMouseEnter = () => {
            //       logoSwiper.autoplay.stop();
            //   };

            //   const handleMouseLeave = () => {
            //       logoSwiper.autoplay.start();
            //   };

            //   const swiperContainer = this;
            //   swiperContainer.addEventListener("mouseenter", handleMouseEnter);
            //   swiperContainer.addEventListener("mouseleave", handleMouseLeave);

            //   // Clean up event listeners on destroy
            //   logoSwiper.on('destroy', () => {
            //       swiperContainer.removeEventListener("mouseenter", handleMouseEnter);
            //       swiperContainer.removeEventListener("mouseleave", handleMouseLeave);
            //   });
            // }
        });
    });
})(jQuery);