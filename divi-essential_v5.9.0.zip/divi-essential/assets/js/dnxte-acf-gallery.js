/**
 * ACF Gallery — Frontend JS
 *
 * Handles masonry layout (Isotope), lightbox (Magnific Popup),
 * and responsive column adjustments.
 */
(function ($) {
  "use strict";

  function initAcfGallery() {
    $(".dnxte-acf-gallery-grid").each(function () {
      const $grid = $(this);
      const configRaw = $grid.attr("data-config");
      if (!configRaw) return;

      let config;
      try {
        config = JSON.parse(configRaw);
      } catch (e) {
        return;
      }

      // ── Helpers ───────────────────────────────────────────────
      const getResponsiveValue = (obj, desktopFallback) => {
        const w = window.innerWidth;
        if (w <= 480) return obj.phone  !== undefined ? obj.phone  : desktopFallback;
        if (w <= 980) return obj.tablet !== undefined ? obj.tablet : desktopFallback;
        return obj.desktop !== undefined ? obj.desktop : desktopFallback;
      };

      // ── Masonry layout ────────────────────────────────────────
      if (config.layout === "masonry" && typeof Isotope !== "undefined") {
        const initIsotope = () => {
          const gap = getResponsiveValue(config.gap, 0);

          if ($grid.data("isotope")) {
            $grid.isotope("destroy");
          }

          $grid.imagesLoaded(function () {
            $grid.isotope({
              itemSelector: ".dnxte-acf-gallery-item",
              layoutMode: "masonry",
              percentPosition: true,
              masonry: {
                columnWidth: ".dnxte-acf-grid-sizer",
                gutter: gap,
                horizontalOrder: true,
              },
            });
          });
        };

        initIsotope();

        let resizeTimer;
        $(window).on("resize", function () {
          clearTimeout(resizeTimer);
          resizeTimer = setTimeout(initIsotope, 250);
        });
      }

      // ── Lightbox ──────────────────────────────────────────────
      if (config.lightbox === "1") {
        $grid.magnificPopup({
          delegate: "a.dnxte-acf-image-link",
          type: "image",
          mainClass: "dnxte-acf-gallery-wrapper",
          gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [1, 1],
          },
          zoom: {
            enabled: true,
            duration: 400,
            opener: function (el) {
              return el.find("img");
            },
          },
          image: {
            titleSrc: function (item) {
              const title = item.el.attr("data-title") || "";
              const caption = item.el.attr("data-caption") || "";
              return title + (caption ? "<small>" + caption + "</small>" : "");
            },
          },
        });
      }

      // ── Responsive columns via CSS variable ───────────────────
      const updateColumns = () => {
        const cols = getResponsiveValue(config.columns, 4);
        const gap  = getResponsiveValue(config.gap, 0);

        $grid[0].style.setProperty("--acf-columns", cols);
        $grid[0].style.setProperty("--acf-gap", gap + "px");
      };

      updateColumns();
      $(window).on("resize", updateColumns);
    });
  }

  // Init on DOM ready and Divi builder events.
  $(document).ready(initAcfGallery);
  $(document).on("divi:builderReady", initAcfGallery);
})(jQuery);
