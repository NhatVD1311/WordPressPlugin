/**
 * OrbitCarousel v2.3.0
 * A 3D carousel with orbiting thumbnails - Swiper/Slick style
 * Original slides remain visible and functional (no display:none)
 * Now with Tippy-style tooltips!
 * Made by Mahedi Amin
 * mahedi5544@gmail.com
 *
 * Usage:
 * const orbit = new OrbitCarousel('.orbit-container', {
 *   layout: 'orbit',
 *   mode: 'click',
 *   radius: 200,
 *   thumbSize: 80,
 *   animation: 'spring',
 *   tooltip: {
 *     enabled: true,
 *     placement: 'auto'
 *   }
 * });
 *
 * HTML:
 * <div class="orbit-slide" data-orbit-tooltip="Tooltip content here">...</div>
 */

(function (global, factory) {
  typeof exports === "object" && typeof module !== "undefined"
    ? (module.exports = factory())
    : typeof define === "function" && define.amd
    ? define(factory)
    : ((global = global || self), (global.OrbitCarousel = factory()));
})(this, function () {
  "use strict";

  // ============================================
  // ANIMATION PRESETS
  // ============================================
  var ANIMATIONS = {
    spring: {
      name: "Spring",
      duration: 0.6,
      easing: "cubic-bezier(0.34, 1.56, 0.64, 1)",
    },
    smooth: {
      name: "Smooth",
      duration: 0.5,
      easing: "cubic-bezier(0.25, 0.1, 0.25, 1)",
    },
    bounce: {
      name: "Bounce",
      duration: 0.7,
      easing: "cubic-bezier(0.68, -0.55, 0.265, 1.55)",
    },
    elastic: {
      name: "Elastic",
      duration: 0.8,
      easing: "cubic-bezier(0.68, -0.6, 0.32, 1.6)",
    },
    slide: {
      name: "Slide",
      duration: 0.4,
      easing: "ease-out",
    },
    fade: {
      name: "Fade",
      duration: 0.5,
      easing: "linear",
    },
    none: {
      name: "None",
      duration: 0,
      easing: "linear",
    },
  };

  // ============================================
  // LAYOUT MODES
  // ============================================
  var LAYOUTS = {
    orbit: "orbit",
    static: "static",
  };

  // ============================================
  // INTERACTION MODES
  // ============================================
  var MODES = {
    click: "click",
    hover: "hover",
  };

  // ============================================
  // TOOLTIP PLACEMENTS
  // ============================================
  var TOOLTIP_PLACEMENTS = {
    top: "top",
    "top-start": "top-start",
    "top-end": "top-end",
    bottom: "bottom",
    "bottom-start": "bottom-start",
    "bottom-end": "bottom-end",
    left: "left",
    "left-start": "left-start",
    "left-end": "left-end",
    right: "right",
    "right-start": "right-start",
    "right-end": "right-end",
    auto: "auto",
  };

  // ============================================
  // TOOLTIP ANIMATIONS
  // ============================================
  var TOOLTIP_ANIMATIONS = {
    fade: "fade",
    scale: "scale",
    "shift-away": "shift-away",
    "shift-toward": "shift-toward",
    perspective: "perspective",
    none: "none",
  };

  // ============================================
  // ORBIT CAROUSEL CLASS
  // ============================================
  function OrbitCarousel(selector, options) {
    options = options || {};

    this.el =
      typeof selector === "string"
        ? document.querySelector(selector)
        : selector;

    if (!this.el) {
      console.error("OrbitCarousel: Container element not found:", selector);
      return;
    }

    // Default tooltip options
    var defaultTooltip = {
      enabled: true,
      placement: "auto",
      arrow: true,
      animation: "shift-away",
      delay: [100, 0],
      duration: [275, 250],
      offset: [0, 10],
      interactive: false,
      maxWidth: 350,
      appendTo: "parent",
      zIndex: 9999,
      hideOnClick: true,
      trigger: "mouseenter focus",
    };

    // Default options
    this.params = Object.assign(
      {
        initialSlide: 0,
        radius: 200,
        mobileRadius: 130,
        thumbSize: 80,
        mobileThumbSize: 60,
        activeThumbScale: 1.25,
        inactiveThumbOpacity: 0.7,
        animation: "spring",
        layout: "orbit",
        mode: "click",
        hoverDelay: 150,
        loop: true,
        speed: 300,
        autoplay: false,
        pagination: false,
        navigation: false,
        keyboard: false,
        grabCursor: false,
        wrapperClass: "orbit-wrapper",
        slideClass: "orbit-slide",
        slideActiveClass: "orbit-slide-active",
        slideVisibleClass: "orbit-slide-visible",
        slidePrevClass: "orbit-slide-prev",
        slideNextClass: "orbit-slide-next",
        thumbSelector: ".orbit-slide-thumb",
        thumbAttribute: "data-orbit-thumb",
        orbitIconAttribute: "data-orbit-icon",
        thumbTitleAttribute: "data-orbit-title",
        tooltipAttribute: "data-orbit-tooltip",
        tooltip: defaultTooltip,
        effect: "fade",
        fadeEffect: {
          crossFade: true,
        },
        on: {},
        breakpoints: {},
        observer: false,
        observeParents: false,
        centeredSlides: true,
        slidesPerView: 1,
      },
      options,
    );

    // Merge tooltip options if provided partially
    if (options.tooltip && typeof options.tooltip === "object") {
      this.params.tooltip = Object.assign({}, defaultTooltip, options.tooltip);
    }

    // Validate layout
    if (!LAYOUTS[this.params.layout]) {
      console.warn(
        'OrbitCarousel: Invalid layout "' +
          this.params.layout +
          '", defaulting to "orbit"',
      );
      this.params.layout = "orbit";
    }

    // Validate mode
    if (!MODES[this.params.mode]) {
      console.warn(
        'OrbitCarousel: Invalid mode "' +
          this.params.mode +
          '", defaulting to "click"',
      );
      this.params.mode = "click";
    }

    // Internal state
    this.activeIndex = this.params.initialSlide;
    this.previousIndex = 0;
    this.slides = [];
    this.thumbElements = [];
    this.tooltipInstances = [];
    this.isAnimating = false;
    this.destroyed = false;
    this._autoplay = null;
    this.autoplayTimer = null;
    this._hoverTimers = {};

    // Dimensions
    this.dims = {
      radius: this.params.radius,
      thumbSize: this.params.thumbSize,
    };

    // Initialize
    this._init();
  }

  // ============================================
  // INITIALIZATION
  // ============================================
  OrbitCarousel.prototype._init = function () {
    this._emit("beforeInit");

    this._findElements();
    this._discoverSlides();

    if (this.slides.length === 0) {
      console.warn("OrbitCarousel: No slides found");
      return;
    }

    this._setupStructure();
    this._updateDimensions();
    this._attachEvents();

    if (this.params.pagination) this._initPagination();
    if (this.params.navigation) this._initNavigation();
    if (this.params.keyboard) this._initKeyboard();
    if (this.params.autoplay) this._initAutoplay();
    if (this.params.observer) this._initObserver();

    this._update();

    this._emit("init");
    this._emit("afterInit");
  };

  OrbitCarousel.prototype._findElements = function () {
    this.wrapperEl = this.el.querySelector("." + this.params.wrapperClass);

    if (!this.wrapperEl) {
      this.wrapperEl = this.el;
    }
  };

  OrbitCarousel.prototype._discoverSlides = function () {
    var slideEls = this.wrapperEl.querySelectorAll(
      "." + this.params.slideClass,
    );
    this.slides = [];
    var self = this;

    slideEls.forEach(function (el, index) {
      var thumbEl = el.querySelector(self.params.thumbSelector);
      var thumbSrc = el.getAttribute(self.params.thumbAttribute);
      var iconValue = el.getAttribute(self.params.orbitIconAttribute);
      var thumbTitle = el.getAttribute(self.params.thumbTitleAttribute);
      var tooltipContent = el.getAttribute(self.params.tooltipAttribute);
      var thumbHTML = "";

      if (thumbEl) {
        thumbHTML = thumbEl.outerHTML;
      } else if (iconValue) {
        thumbHTML = '<span class="orbit-thumb-icon">' + iconValue + "</span>";
        if (thumbTitle) {
          thumbHTML +=
            '<span class="orbit-thumb-title">' + thumbTitle + "</span>";
        }
      } else if (thumbSrc) {
        thumbHTML =
          '<img src="' + thumbSrc + '" alt="Slide ' + (index + 1) + '">';
      } else {
        var firstImg = el.querySelector("img");
        if (firstImg) {
          thumbHTML =
            '<img src="' +
            firstImg.src +
            '" alt="' +
            (firstImg.alt || "Slide " + (index + 1)) +
            '">';
        } else {
          thumbHTML =
            '<span class="orbit-thumb-index">' + (index + 1) + "</span>";
        }
      }

      self.slides.push({
        el: el,
        index: index,
        thumbEl: thumbEl,
        thumbHTML: thumbHTML,
        tooltipContent: tooltipContent,
      });
    });

    this._emit("slidesFound", this.slides);
  };

  // ============================================
  // STRUCTURE
  // ============================================
  OrbitCarousel.prototype._setupStructure = function () {
    var self = this;

    this.el.classList.add("orbit-carousel-initialized");
    this.wrapperEl.classList.add("orbit-wrapper-initialized");

    this.orbitOverlay = document.createElement("div");
    this.orbitOverlay.className = "orbit-overlay";
    this.orbitOverlay.classList.add("orbit-layout-" + this.params.layout);
    this.orbitOverlay.classList.add("orbit-mode-" + this.params.mode);

    this.ringEl = document.createElement("div");
    this.ringEl.className = "orbit-ring";
    this.orbitOverlay.appendChild(this.ringEl);

    this.thumbsEl = document.createElement("div");
    this.thumbsEl.className = "orbit-thumbs";
    this.orbitOverlay.appendChild(this.thumbsEl);

    this._createThumbs();

    this.el.appendChild(this.orbitOverlay);

    this.slides.forEach(function (slide, index) {
      slide.el.classList.add("orbit-slide-initialized");
      if (index !== self.activeIndex) {
        self._hideSlide(slide.el);
      } else {
        self._showSlide(slide.el);
      }
    });

    if (this.params.grabCursor) {
      this.el.style.cursor = "grab";
    }
  };

  OrbitCarousel.prototype._createThumbs = function () {
    this.thumbElements = [];
    this.thumbsEl.innerHTML = "";
    this._hoverTimers = {};
    this._destroyTooltips();
    var self = this;

    this.slides.forEach(function (slide, index) {
      var wrapper = document.createElement("div");
      wrapper.className = "orbit-thumb-wrapper";
      wrapper.setAttribute("data-index", index);

      var customThumbClass = slide.el.getAttribute("data-thumb-class");
      if (customThumbClass) {
        wrapper.classList.add(customThumbClass);
      }

      var thumb = document.createElement("div");
      thumb.className = "orbit-thumb";
      thumb.innerHTML = slide.thumbHTML;

      thumb.addEventListener("click", function () {
        if (!self.isAnimating && index !== self.activeIndex) {
          self.slideTo(index);
        }
      });

      thumb.addEventListener("mouseenter", function () {
        if (index !== self.activeIndex) {
          if (self.params.mode === "hover") {
            self._clearHoverTimer(index);
            self._hoverTimers[index] = setTimeout(function () {
              if (!self.isAnimating && index !== self.activeIndex) {
                self.slideTo(index);
              }
            }, self.params.hoverDelay);
          }
          self._onThumbHover(index, true);
        }
      });

      thumb.addEventListener("mouseleave", function () {
        self._clearHoverTimer(index);
        self._onThumbHover(index, false);
      });

      wrapper.appendChild(thumb);
      self.thumbsEl.appendChild(wrapper);
      self.thumbElements.push({ wrapper: wrapper, thumb: thumb });

      // Create tooltip if content exists
      if (slide.tooltipContent && self.params.tooltip.enabled) {
        self._createTooltip(thumb, slide.tooltipContent, index);
      }
    });
  };

  // ============================================
  // TOOLTIP METHODS
  // ============================================
  OrbitCarousel.prototype._createTooltip = function (targetEl, content, index) {
    var self = this;
    var config = this.params.tooltip;

    var tooltip = document.createElement("div");
    tooltip.className = "orbit-tooltip";
    tooltip.setAttribute("data-animation", config.animation);
    tooltip.setAttribute("role", "tooltip");
    tooltip.style.maxWidth =
      typeof config.maxWidth === "number"
        ? config.maxWidth + "px"
        : config.maxWidth;
    tooltip.style.zIndex = config.zIndex;

    var showDuration = Array.isArray(config.duration)
      ? config.duration[0]
      : config.duration;
    var hideDuration = Array.isArray(config.duration)
      ? config.duration[1]
      : config.duration;

    if (config.interactive) {
      tooltip.classList.add("orbit-tooltip-interactive");
    }

    var contentEl = document.createElement("div");
    contentEl.className = "orbit-tooltip-content";
    contentEl.innerHTML = content;
    tooltip.appendChild(contentEl);

    if (config.arrow) {
      var arrow = document.createElement("div");
      arrow.className = "orbit-tooltip-arrow";
      tooltip.appendChild(arrow);
    }

    var appendTarget;
    if (config.appendTo === "parent") {
      appendTarget = this.orbitOverlay;
    } else if (config.appendTo === "body") {
      appendTarget = document.body;
    } else if (typeof config.appendTo === "string") {
      appendTarget = document.querySelector(config.appendTo) || document.body;
    } else if (config.appendTo instanceof Element) {
      appendTarget = config.appendTo;
    } else {
      appendTarget = document.body;
    }

    appendTarget.appendChild(tooltip);

    var tooltipInstance = {
      el: tooltip,
      target: targetEl,
      content: content,
      index: index,
      showTimeout: null,
      hideTimeout: null,
      isVisible: false,
    };

    var showDelay = Array.isArray(config.delay)
      ? config.delay[0]
      : config.delay;
    var hideDelay = Array.isArray(config.delay)
      ? config.delay[1]
      : config.delay;

    var show = function () {
      clearTimeout(tooltipInstance.hideTimeout);
      tooltipInstance.showTimeout = setTimeout(function () {
        self._positionTooltip(tooltipInstance);
        tooltip.style.transitionDuration = showDuration + "ms";
        tooltip.classList.add("orbit-tooltip-visible");
        tooltipInstance.isVisible = true;
        self._emit("tooltipShow", { tooltip: tooltipInstance, index: index });
      }, showDelay);
    };

    var hide = function () {
      clearTimeout(tooltipInstance.showTimeout);
      tooltipInstance.hideTimeout = setTimeout(function () {
        tooltip.style.transitionDuration = hideDuration + "ms";
        tooltip.classList.remove("orbit-tooltip-visible");
        tooltipInstance.isVisible = false;
        self._emit("tooltipHide", { tooltip: tooltipInstance, index: index });
      }, hideDelay);
    };

    var triggers = (config.trigger || "mouseenter focus").split(" ");

    if (triggers.indexOf("mouseenter") > -1) {
      targetEl.addEventListener("mouseenter", show);
      targetEl.addEventListener("mouseleave", hide);

      if (config.interactive) {
        tooltip.addEventListener("mouseenter", function () {
          clearTimeout(tooltipInstance.hideTimeout);
        });
        tooltip.addEventListener("mouseleave", hide);
      }
    }

    if (triggers.indexOf("focus") > -1) {
      targetEl.addEventListener("focus", show);
      targetEl.addEventListener("blur", hide);
    }

    if (triggers.indexOf("click") > -1) {
      targetEl.addEventListener("click", function () {
        if (tooltipInstance.isVisible) {
          hide();
        } else {
          show();
        }
      });
    }

    if (config.hideOnClick) {
      document.addEventListener("click", function (e) {
        if (
          tooltipInstance.isVisible &&
          !tooltip.contains(e.target) &&
          !targetEl.contains(e.target)
        ) {
          hide();
        }
      });
    }

    tooltipInstance.show = show;
    tooltipInstance.hide = hide;

    this.tooltipInstances.push(tooltipInstance);

    return tooltipInstance;
  };

  OrbitCarousel.prototype._positionTooltip = function (tooltipInstance) {
    var tooltip = tooltipInstance.el;
    var target = tooltipInstance.target;
    var config = this.params.tooltip;
    var offset = config.offset || [0, 10];
    var skidding = offset[0] || 0;
    var distance = offset[1] || 10;

    var targetRect = target.getBoundingClientRect();
    var tooltipRect = tooltip.getBoundingClientRect();

    var viewportWidth = window.innerWidth;
    var viewportHeight = window.innerHeight;

    var spaceTop = targetRect.top;
    var spaceBottom = viewportHeight - targetRect.bottom;
    var spaceLeft = targetRect.left;
    var spaceRight = viewportWidth - targetRect.right;

    var placement = config.placement;

    if (placement === "auto") {
      var spaces = {
        top: spaceTop,
        bottom: spaceBottom,
        left: spaceLeft,
        right: spaceRight,
      };

      if (
        spaces.top >= tooltipRect.height + distance ||
        spaces.bottom >= tooltipRect.height + distance
      ) {
        placement = spaces.bottom >= spaces.top ? "bottom" : "top";
      } else {
        placement = spaces.right >= spaces.left ? "right" : "left";
      }
    }

    var basePlacement = placement.split("-")[0];
    var finalPlacement = placement;

    switch (basePlacement) {
      case "top":
        if (
          spaceTop < tooltipRect.height + distance &&
          spaceBottom > spaceTop
        ) {
          finalPlacement = placement.replace("top", "bottom");
        }
        break;
      case "bottom":
        if (
          spaceBottom < tooltipRect.height + distance &&
          spaceTop > spaceBottom
        ) {
          finalPlacement = placement.replace("bottom", "top");
        }
        break;
      case "left":
        if (
          spaceLeft < tooltipRect.width + distance &&
          spaceRight > spaceLeft
        ) {
          finalPlacement = placement.replace("left", "right");
        }
        break;
      case "right":
        if (
          spaceRight < tooltipRect.width + distance &&
          spaceLeft > spaceRight
        ) {
          finalPlacement = placement.replace("right", "left");
        }
        break;
    }

    tooltip.setAttribute("data-placement", finalPlacement);

    var appendTarget = tooltip.parentElement;
    var appendRect = appendTarget.getBoundingClientRect();

    var top, left;
    var finalBasePlacement = finalPlacement.split("-")[0];
    var alignment = finalPlacement.split("-")[1];

    switch (finalBasePlacement) {
      case "top":
        top = targetRect.top - appendRect.top - tooltipRect.height - distance;
        left =
          targetRect.left -
          appendRect.left +
          (targetRect.width - tooltipRect.width) / 2 +
          skidding;
        break;
      case "bottom":
        top = targetRect.bottom - appendRect.top + distance;
        left =
          targetRect.left -
          appendRect.left +
          (targetRect.width - tooltipRect.width) / 2 +
          skidding;
        break;
      case "left":
        top =
          targetRect.top -
          appendRect.top +
          (targetRect.height - tooltipRect.height) / 2 +
          skidding;
        left = targetRect.left - appendRect.left - tooltipRect.width - distance;
        break;
      case "right":
        top =
          targetRect.top -
          appendRect.top +
          (targetRect.height - tooltipRect.height) / 2 +
          skidding;
        left = targetRect.right - appendRect.left + distance;
        break;
    }

    if (alignment === "start") {
      if (finalBasePlacement === "top" || finalBasePlacement === "bottom") {
        left = targetRect.left - appendRect.left + skidding;
      } else {
        top = targetRect.top - appendRect.top + skidding;
      }
    } else if (alignment === "end") {
      if (finalBasePlacement === "top" || finalBasePlacement === "bottom") {
        left =
          targetRect.right - appendRect.left - tooltipRect.width + skidding;
      } else {
        top =
          targetRect.bottom - appendRect.top - tooltipRect.height + skidding;
      }
    }

    var arrowEl = tooltip.querySelector(".orbit-tooltip-arrow");
    if (arrowEl) {
      if (finalBasePlacement === "top" || finalBasePlacement === "bottom") {
        arrowEl.style.left =
          Math.max(
            10,
            Math.min(
              tooltipRect.width - 26,
              targetRect.left -
                appendRect.left -
                left +
                targetRect.width / 2 -
                8,
            ),
          ) + "px";
        arrowEl.style.top = "";
      } else {
        arrowEl.style.top =
          Math.max(
            10,
            Math.min(
              tooltipRect.height - 26,
              targetRect.top - appendRect.top - top + targetRect.height / 2 - 8,
            ),
          ) + "px";
        arrowEl.style.left = "";
      }
    }

    tooltip.style.top = top + "px";
    tooltip.style.left = left + "px";
  };

  OrbitCarousel.prototype._destroyTooltips = function () {
    this.tooltipInstances.forEach(function (instance) {
      clearTimeout(instance.showTimeout);
      clearTimeout(instance.hideTimeout);
      if (instance.el && instance.el.parentNode) {
        instance.el.parentNode.removeChild(instance.el);
      }
    });
    this.tooltipInstances = [];
  };

  // Public method to update tooltip content
  OrbitCarousel.prototype.setTooltipContent = function (index, content) {
    var instance = this.tooltipInstances.find(function (t) {
      return t.index === index;
    });
    if (instance) {
      instance.content = content;
      var contentEl = instance.el.querySelector(".orbit-tooltip-content");
      if (contentEl) {
        contentEl.innerHTML = content;
      }
    }
    return this;
  };

  // Public method to show tooltip programmatically
  OrbitCarousel.prototype.showTooltip = function (index) {
    var instance = this.tooltipInstances.find(function (t) {
      return t.index === index;
    });
    if (instance && instance.show) {
      instance.show();
    }
    return this;
  };

  // Public method to hide tooltip programmatically
  OrbitCarousel.prototype.hideTooltip = function (index) {
    var instance = this.tooltipInstances.find(function (t) {
      return t.index === index;
    });
    if (instance && instance.hide) {
      instance.hide();
    }
    return this;
  };

  // Public method to hide all tooltips
  OrbitCarousel.prototype.hideAllTooltips = function () {
    this.tooltipInstances.forEach(function (instance) {
      if (instance.hide) {
        instance.hide();
      }
    });
    return this;
  };

  OrbitCarousel.prototype._clearHoverTimer = function (index) {
    if (this._hoverTimers[index]) {
      clearTimeout(this._hoverTimers[index]);
      delete this._hoverTimers[index];
    }
  };

  OrbitCarousel.prototype._clearAllHoverTimers = function () {
    var self = this;
    Object.keys(this._hoverTimers).forEach(function (key) {
      clearTimeout(self._hoverTimers[key]);
    });
    this._hoverTimers = {};
  };

  OrbitCarousel.prototype._onThumbHover = function (index, isHovering) {
    var item = this.thumbElements[index];
    if (!item) return;

    if (isHovering && index !== this.activeIndex) {
      if (this.params.layout === "static") {
        var baseRotation = (index * 360) / this.slides.length;
        item.thumb.style.transform =
          "rotate(" + -baseRotation + "deg) scale(1.1)";
      } else {
        var rotation = ((index - this.activeIndex) * 360) / this.slides.length;
        item.thumb.style.transform = "rotate(" + -rotation + "deg) scale(1.1)";
      }
    } else {
      this._updateThumbTransform(index);
    }
  };

  // ============================================
  // SLIDE VISIBILITY
  // ============================================
  OrbitCarousel.prototype._showSlide = function (el) {
    var animation = ANIMATIONS[this.params.animation] || ANIMATIONS.spring;
    var effect = this.params.effect;

    el.style.transition =
      "opacity " +
      animation.duration +
      "s " +
      animation.easing +
      ", transform " +
      animation.duration +
      "s " +
      animation.easing;

    if (effect === "fade") {
      el.style.opacity = "1";
      el.style.visibility = "visible";
      el.style.pointerEvents = "auto";
      el.style.position = "relative";
      el.style.zIndex = "1";
    } else if (effect === "slide") {
      el.style.opacity = "1";
      el.style.visibility = "visible";
      el.style.pointerEvents = "auto";
      el.style.transform = "translateX(0)";
    } else if (effect === "flip") {
      el.style.opacity = "1";
      el.style.visibility = "visible";
      el.style.pointerEvents = "auto";
      el.style.transform = "rotateY(0deg)";
    } else {
      el.style.opacity = "1";
      el.style.visibility = "visible";
      el.style.pointerEvents = "auto";
    }
  };

  OrbitCarousel.prototype._hideSlide = function (el, direction) {
    var animation = ANIMATIONS[this.params.animation] || ANIMATIONS.spring;
    var effect = this.params.effect;
    direction = direction || "next";

    el.style.transition =
      "opacity " +
      animation.duration +
      "s " +
      animation.easing +
      ", transform " +
      animation.duration +
      "s " +
      animation.easing;

    if (effect === "fade") {
      el.style.opacity = "0";
      el.style.visibility = "hidden";
      el.style.pointerEvents = "none";
      el.style.position = "absolute";
      el.style.zIndex = "0";
    } else if (effect === "slide") {
      el.style.opacity = "0";
      el.style.visibility = "hidden";
      el.style.pointerEvents = "none";
      el.style.transform =
        direction === "next" ? "translateX(-100%)" : "translateX(100%)";
    } else if (effect === "flip") {
      el.style.opacity = "0";
      el.style.visibility = "hidden";
      el.style.pointerEvents = "none";
      el.style.transform =
        direction === "next" ? "rotateY(-90deg)" : "rotateY(90deg)";
    } else {
      el.style.opacity = "0";
      el.style.visibility = "hidden";
      el.style.pointerEvents = "none";
    }
  };

  // ============================================
  // DIMENSIONS
  // ============================================
  OrbitCarousel.prototype._updateDimensions = function () {
    var isMobile = window.innerWidth < 768;

    var breakpointParams = {};
    if (this.params.breakpoints) {
      var sortedBreakpoints = Object.keys(this.params.breakpoints)
        .map(Number)
        .sort(function (a, b) {
          return a - b;
        });

      for (var i = 0; i < sortedBreakpoints.length; i++) {
        var bp = sortedBreakpoints[i];
        if (window.innerWidth >= bp) {
          breakpointParams = Object.assign(
            {},
            breakpointParams,
            this.params.breakpoints[bp],
          );
        }
      }
    }

    this.dims = {
      radius: breakpointParams.radius || this.params.radius,
      thumbSize: breakpointParams.thumbSize || this.params.thumbSize,
    };

    // Calculate overlay size based on radius and thumb size
    var overlaySize = this.dims.radius * 2 + this.dims.thumbSize + 20;
    this.orbitOverlay.style.width = overlaySize + "px";
    this.orbitOverlay.style.height = overlaySize + "px";
    this.orbitOverlay.style.maxWidth = "100%";
    this.orbitOverlay.style.maxHeight = "100%";

    // Set CSS custom properties for dynamic centering (matches OrbitCarousel.css)
    this.orbitOverlay.style.setProperty(
      "--orbit-thumb-size",
      this.dims.thumbSize + "px",
    );
    this.orbitOverlay.style.setProperty(
      "--orbit-radius",
      this.dims.radius + "px",
    );
    this.orbitOverlay.style.setProperty(
      "--orbit-overlay-size",
      overlaySize + "px",
    );

    this.ringEl.style.width = this.dims.radius * 2 + "px";
    this.ringEl.style.height = this.dims.radius * 2 + "px";

    var self = this;
    this.thumbElements.forEach(function (item) {
      item.wrapper.style.width = self.dims.thumbSize + "px";
      item.wrapper.style.height = self.dims.thumbSize + "px";
    });

    this._emit("resize");
  };

  // ============================================
  // NAVIGATION METHODS
  // ============================================
  OrbitCarousel.prototype.slideTo = function (index, speed, runCallbacks) {
    if (this.destroyed || this.isAnimating) return this;
    if (index < 0 || index >= this.slides.length) return this;
    if (index === this.activeIndex) return this;

    speed = speed !== undefined ? speed : this.params.speed;
    runCallbacks = runCallbacks !== undefined ? runCallbacks : true;

    var direction = index > this.activeIndex ? "next" : "prev";

    this.previousIndex = this.activeIndex;
    this.activeIndex = index;
    this.isAnimating = true;

    if (runCallbacks) {
      this._emit("slideChange");
      this._emit("slideChangeTransitionStart");
    }

    this._update(direction);

    var self = this;
    setTimeout(function () {
      self.isAnimating = false;
      if (runCallbacks) {
        self._emit("slideChangeTransitionEnd");
      }
    }, speed);

    return this;
  };

  OrbitCarousel.prototype.slideNext = function (speed, runCallbacks) {
    var nextIndex = this.activeIndex + 1;
    if (nextIndex >= this.slides.length) {
      nextIndex = this.params.loop ? 0 : this.slides.length - 1;
    }
    return this.slideTo(nextIndex, speed, runCallbacks);
  };

  OrbitCarousel.prototype.slidePrev = function (speed, runCallbacks) {
    var prevIndex = this.activeIndex - 1;
    if (prevIndex < 0) {
      prevIndex = this.params.loop ? this.slides.length - 1 : 0;
    }
    return this.slideTo(prevIndex, speed, runCallbacks);
  };

  // ============================================
  // LAYOUT MODE SWITCHING
  // ============================================
  OrbitCarousel.prototype.setLayout = function (layout) {
    if (!LAYOUTS[layout]) {
      console.warn('OrbitCarousel: Invalid layout "' + layout + '"');
      return this;
    }

    if (layout === this.params.layout) return this;

    this.orbitOverlay.classList.remove("orbit-layout-" + this.params.layout);
    this.params.layout = layout;
    this.orbitOverlay.classList.add("orbit-layout-" + layout);

    this._updateThumbs();
    this._emit("layoutChange", layout);

    return this;
  };

  OrbitCarousel.prototype.getLayout = function () {
    return this.params.layout;
  };

  // ============================================
  // MODE SWITCHING
  // ============================================
  OrbitCarousel.prototype.setMode = function (mode) {
    if (!MODES[mode]) {
      console.warn('OrbitCarousel: Invalid mode "' + mode + '"');
      return this;
    }

    if (mode === this.params.mode) return this;

    this.orbitOverlay.classList.remove("orbit-mode-" + this.params.mode);
    this.params.mode = mode;
    this.orbitOverlay.classList.add("orbit-mode-" + mode);

    this._clearAllHoverTimers();

    this._emit("modeChange", mode);

    return this;
  };

  OrbitCarousel.prototype.getMode = function () {
    return this.params.mode;
  };

  // ============================================
  // UPDATE / RENDER
  // ============================================
  OrbitCarousel.prototype._update = function (direction) {
    direction = direction || "next";
    this._updateSlides(direction);
    this._updateThumbs();
    this._updatePagination();
    this._updateSlideClasses();
    this._emit("update");
  };

  OrbitCarousel.prototype._updateSlides = function (direction) {
    var self = this;

    this.slides.forEach(function (slide, index) {
      if (index === self.activeIndex) {
        self._showSlide(slide.el);
      } else {
        self._hideSlide(slide.el, direction);
      }
    });
  };

  OrbitCarousel.prototype._updateThumbs = function () {
    var self = this;

    this.thumbElements.forEach(function (item, index) {
      self._updateThumbTransform(index);

      var isActive = index === self.activeIndex;
      item.thumb.classList.toggle("orbit-thumb-active", isActive);
      item.wrapper.classList.toggle("active", isActive);
    });
  };

  OrbitCarousel.prototype._updateThumbTransform = function (index) {
    var animation = ANIMATIONS[this.params.animation] || ANIMATIONS.spring;
    var total = this.slides.length;
    var item = this.thumbElements[index];
    var wrapper = item.wrapper;
    var thumb = item.thumb;
    var isActive = index === this.activeIndex;

    var transitionValue =
      "transform " +
      animation.duration +
      "s " +
      animation.easing +
      ", opacity " +
      animation.duration +
      "s " +
      animation.easing;

    if (this.params.layout === "static") {
      var baseRotation = (index * 360) / total;

      wrapper.style.transition = transitionValue;
      wrapper.style.transform =
        "rotate(" +
        baseRotation +
        "deg) translateY(-" +
        this.dims.radius +
        "px)";

      thumb.style.transition = transitionValue;

      if (isActive) {
        thumb.style.transform =
          "rotate(" +
          -baseRotation +
          "deg) scale(" +
          this.params.activeThumbScale +
          ")";
        thumb.style.opacity = "1";
        thumb.style.zIndex = "10";
      } else {
        thumb.style.transform = "rotate(" + -baseRotation + "deg) scale(1)";
        thumb.style.opacity = String(this.params.inactiveThumbOpacity);
        thumb.style.zIndex = "1";
      }
    } else {
      var rotation = ((index - this.activeIndex) * 360) / total;

      wrapper.style.transition = transitionValue;
      wrapper.style.transform =
        "rotate(" + rotation + "deg) translateY(-" + this.dims.radius + "px)";

      thumb.style.transition = transitionValue;
      thumb.style.transform = "rotate(" + -rotation + "deg)";
      thumb.style.opacity = "1";
      thumb.style.zIndex = "1";
    }
  };

  OrbitCarousel.prototype._updateSlideClasses = function () {
    var self = this;
    var total = this.slides.length;

    this.slides.forEach(function (slide, index) {
      var el = slide.el;

      el.classList.remove(self.params.slideActiveClass);
      el.classList.remove(self.params.slidePrevClass);
      el.classList.remove(self.params.slideNextClass);
      el.classList.remove(self.params.slideVisibleClass);

      if (index === self.activeIndex) {
        el.classList.add(self.params.slideActiveClass);
        el.classList.add(self.params.slideVisibleClass);
      }

      var prevIndex =
        self.activeIndex - 1 < 0 ? total - 1 : self.activeIndex - 1;
      if (index === prevIndex) {
        el.classList.add(self.params.slidePrevClass);
      }

      var nextIndex = self.activeIndex + 1 >= total ? 0 : self.activeIndex + 1;
      if (index === nextIndex) {
        el.classList.add(self.params.slideNextClass);
      }
    });
  };

  // ============================================
  // PAGINATION
  // ============================================
  OrbitCarousel.prototype._initPagination = function () {
    var config = this.params.pagination;
    if (!config || !config.el) return;

    this.paginationEl =
      typeof config.el === "string"
        ? document.querySelector(config.el)
        : config.el;

    if (!this.paginationEl) return;

    this.paginationEl.classList.add("orbit-pagination");
    this._renderPagination();
  };

  OrbitCarousel.prototype._renderPagination = function () {
    if (!this.paginationEl) return;

    var config = this.params.pagination;
    var type = config.type || "bullets";
    var self = this;

    if (type === "bullets") {
      var html = "";
      this.slides.forEach(function (_, index) {
        var activeClass =
          index === self.activeIndex ? " orbit-pagination-bullet-active" : "";
        html +=
          '<span class="orbit-pagination-bullet' +
          activeClass +
          '" data-index="' +
          index +
          '"></span>';
      });
      this.paginationEl.innerHTML = html;

      if (config.clickable) {
        var bullets = this.paginationEl.querySelectorAll(
          ".orbit-pagination-bullet",
        );
        bullets.forEach(function (bullet) {
          bullet.addEventListener("click", function () {
            self.slideTo(parseInt(bullet.getAttribute("data-index")));
          });
        });
      }
    } else if (type === "fraction") {
      this.paginationEl.innerHTML =
        '<span class="orbit-pagination-current">' +
        (this.activeIndex + 1) +
        '</span> / <span class="orbit-pagination-total">' +
        this.slides.length +
        "</span>";
    }
  };

  OrbitCarousel.prototype._updatePagination = function () {
    if (!this.paginationEl) return;

    var config = this.params.pagination;
    var type = config && config.type ? config.type : "bullets";
    var self = this;

    if (type === "bullets") {
      var bullets = this.paginationEl.querySelectorAll(
        ".orbit-pagination-bullet",
      );
      bullets.forEach(function (bullet, index) {
        bullet.classList.toggle(
          "orbit-pagination-bullet-active",
          index === self.activeIndex,
        );
      });
    } else if (type === "fraction") {
      var current = this.paginationEl.querySelector(
        ".orbit-pagination-current",
      );
      if (current) current.textContent = this.activeIndex + 1;
    }

    this._emit("paginationUpdate");
  };

  // ============================================
  // NAVIGATION
  // ============================================
  OrbitCarousel.prototype._initNavigation = function () {
    var config = this.params.navigation;
    if (!config) return;
    var self = this;

    if (config.nextEl) {
      this.nextEl =
        typeof config.nextEl === "string"
          ? document.querySelector(config.nextEl)
          : config.nextEl;

      if (this.nextEl) {
        this._nextClickHandler = function () {
          self.slideNext();
        };
        this.nextEl.addEventListener("click", this._nextClickHandler);
      }
    }

    if (config.prevEl) {
      this.prevEl =
        typeof config.prevEl === "string"
          ? document.querySelector(config.prevEl)
          : config.prevEl;

      if (this.prevEl) {
        this._prevClickHandler = function () {
          self.slidePrev();
        };
        this.prevEl.addEventListener("click", this._prevClickHandler);
      }
    }
  };

  // ============================================
  // KEYBOARD
  // ============================================
  OrbitCarousel.prototype._initKeyboard = function () {
    var config = this.params.keyboard;
    if (!config) return;

    var enabled = config === true || config.enabled;
    var onlyInViewport = config.onlyInViewport !== false;
    var self = this;

    if (enabled) {
      this._keyboardHandler = function (e) {
        if (onlyInViewport && !self._isInViewport()) return;

        if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
          e.preventDefault();
          self.slidePrev();
        } else if (e.key === "ArrowRight" || e.key === "ArrowDown") {
          e.preventDefault();
          self.slideNext();
        }
      };
      document.addEventListener("keydown", this._keyboardHandler);
    }
  };

  OrbitCarousel.prototype._isInViewport = function () {
    var rect = this.el.getBoundingClientRect();
    return (
      rect.top < window.innerHeight &&
      rect.bottom > 0 &&
      rect.left < window.innerWidth &&
      rect.right > 0
    );
  };

  // ============================================
  // AUTOPLAY
  // ============================================
  OrbitCarousel.prototype._initAutoplay = function () {
    var config = this.params.autoplay;
    if (!config) return;

    var delay =
      typeof config === "object"
        ? config.delay || 3000
        : typeof config === "number"
        ? config
        : 3000;
    var pauseOnMouseEnter = config.pauseOnMouseEnter === true;
    var stopOnLastSlide = config.stopOnLastSlide === true;
    var self = this;

    this._autoplay = {
      running: false,
      paused: false,
      delay: delay,
      stopOnLastSlide: stopOnLastSlide,
    };

    if (pauseOnMouseEnter) {
      this._mouseEnterHandler = function () {
        if (self._autoplay) self._autoplay.paused = true;
      };
      this._mouseLeaveHandler = function () {
        if (self._autoplay) self._autoplay.paused = false;
      };
      this.el.addEventListener("mouseenter", this._mouseEnterHandler);
      this.el.addEventListener("mouseleave", this._mouseLeaveHandler);
    }

    this._startAutoplay();
  };

  OrbitCarousel.prototype._startAutoplay = function () {
    if (this.autoplayTimer) clearInterval(this.autoplayTimer);
    if (!this._autoplay) return;

    this._autoplay.running = true;
    this._autoplay.paused = false;
    var self = this;

    this.autoplayTimer = setInterval(function () {
      if (self._autoplay && self._autoplay.paused) return;

      if (
        self._autoplay &&
        self._autoplay.stopOnLastSlide &&
        self.activeIndex === self.slides.length - 1
      ) {
        self._stopAutoplay();
        return;
      }

      self.slideNext();
    }, this._autoplay.delay);

    this._emit("autoplayStart");
  };

  OrbitCarousel.prototype._stopAutoplay = function () {
    if (this.autoplayTimer) {
      clearInterval(this.autoplayTimer);
      this.autoplayTimer = null;
    }
    if (this._autoplay) {
      this._autoplay.running = false;
    }
    this._emit("autoplayStop");
  };

  Object.defineProperty(OrbitCarousel.prototype, "autoplay", {
    get: function () {
      var self = this;
      return {
        get running() {
          return self._autoplay ? self._autoplay.running : false;
        },
        get paused() {
          return self._autoplay ? self._autoplay.paused : false;
        },
        start: function () {
          self._startAutoplay();
        },
        stop: function () {
          self._stopAutoplay();
        },
        pause: function () {
          if (self._autoplay) self._autoplay.paused = true;
        },
        resume: function () {
          if (self._autoplay) self._autoplay.paused = false;
        },
      };
    },
  });

  // ============================================
  // OBSERVER
  // ============================================
  OrbitCarousel.prototype._initObserver = function () {
    if (!this.params.observer) return;
    var self = this;

    this._observer = new MutationObserver(function (mutations) {
      var needsUpdate = false;
      mutations.forEach(function (mutation) {
        if (mutation.addedNodes.length || mutation.removedNodes.length) {
          needsUpdate = true;
        }
      });

      if (needsUpdate) {
        self._discoverSlides();
        self._createThumbs();
        self._update();
        self._emit("observerUpdate");
      }
    });

    this._observer.observe(this.wrapperEl, {
      childList: true,
      subtree: this.params.observeParents,
    });
  };

  // ============================================
  // EVENTS
  // ============================================
  OrbitCarousel.prototype._attachEvents = function () {
    var self = this;
    this._resizeHandler = function () {
      self._updateDimensions();
      self._updateThumbs();
    };
    window.addEventListener("resize", this._resizeHandler);
  };

  OrbitCarousel.prototype.on = function (event, handler) {
    if (!this.params.on) this.params.on = {};

    var existing = this.params.on[event];
    if (!existing) {
      this.params.on[event] = handler;
    } else if (typeof existing === "function") {
      this.params.on[event] = [existing, handler];
    } else if (Array.isArray(existing)) {
      existing.push(handler);
    }
    return this;
  };

  OrbitCarousel.prototype.off = function (event, handler) {
    if (!this.params.on || !this.params.on[event]) return this;

    var existing = this.params.on[event];
    if (typeof existing === "function") {
      if (existing === handler || !handler) {
        delete this.params.on[event];
      }
    } else if (Array.isArray(existing)) {
      if (handler) {
        var index = existing.indexOf(handler);
        if (index > -1) existing.splice(index, 1);
      } else {
        delete this.params.on[event];
      }
    }
    return this;
  };

  OrbitCarousel.prototype._emit = function (event) {
    var args = Array.prototype.slice.call(arguments, 1);

    if (this.params.on && this.params.on[event]) {
      var handler = this.params.on[event];
      if (typeof handler === "function") {
        handler.apply(this, args);
      } else if (Array.isArray(handler)) {
        var self = this;
        handler.forEach(function (fn) {
          fn.apply(self, args);
        });
      }
    }
  };

  // ============================================
  // DESTROY
  // ============================================
  OrbitCarousel.prototype.destroy = function (deleteInstance) {
    if (this.destroyed) return;

    deleteInstance = deleteInstance !== false;

    this._emit("beforeDestroy");

    this._stopAutoplay();
    this._clearAllHoverTimers();
    this._destroyTooltips();

    if (this._resizeHandler) {
      window.removeEventListener("resize", this._resizeHandler);
    }
    if (this._keyboardHandler) {
      document.removeEventListener("keydown", this._keyboardHandler);
    }
    if (this._mouseEnterHandler) {
      this.el.removeEventListener("mouseenter", this._mouseEnterHandler);
    }
    if (this._mouseLeaveHandler) {
      this.el.removeEventListener("mouseleave", this._mouseLeaveHandler);
    }
    if (this._nextClickHandler && this.nextEl) {
      this.nextEl.removeEventListener("click", this._nextClickHandler);
    }
    if (this._prevClickHandler && this.prevEl) {
      this.prevEl.removeEventListener("click", this._prevClickHandler);
    }

    if (this._observer) {
      this._observer.disconnect();
    }

    if (this.orbitOverlay && this.orbitOverlay.parentNode) {
      this.orbitOverlay.parentNode.removeChild(this.orbitOverlay);
    }

    var self = this;
    this.slides.forEach(function (slide) {
      slide.el.style.opacity = "";
      slide.el.style.visibility = "";
      slide.el.style.pointerEvents = "";
      slide.el.style.position = "";
      slide.el.style.transform = "";
      slide.el.style.transition = "";
      slide.el.style.zIndex = "";
      slide.el.classList.remove("orbit-slide-initialized");
      slide.el.classList.remove(self.params.slideActiveClass);
      slide.el.classList.remove(self.params.slidePrevClass);
      slide.el.classList.remove(self.params.slideNextClass);
      slide.el.classList.remove(self.params.slideVisibleClass);
    });

    this.wrapperEl.classList.remove("orbit-wrapper-initialized");
    this.el.classList.remove("orbit-carousel-initialized");

    this.destroyed = true;
    this._emit("destroy");

    if (deleteInstance) {
      this.el.orbitCarousel = null;
    }
  };

  // ============================================
  // UPDATE PUBLIC
  // ============================================
  OrbitCarousel.prototype.update = function () {
    this._discoverSlides();
    this._createThumbs();
    this._updateDimensions();
    this._update();
    if (this.params.pagination) this._renderPagination();
    return this;
  };

  // ============================================
  // STATIC PROPERTIES
  // ============================================
  Object.defineProperty(OrbitCarousel, "animations", {
    get: function () {
      return ANIMATIONS;
    },
  });

  Object.defineProperty(OrbitCarousel, "layouts", {
    get: function () {
      return LAYOUTS;
    },
  });

  Object.defineProperty(OrbitCarousel, "modes", {
    get: function () {
      return MODES;
    },
  });

  Object.defineProperty(OrbitCarousel, "tooltipPlacements", {
    get: function () {
      return TOOLTIP_PLACEMENTS;
    },
  });

  Object.defineProperty(OrbitCarousel, "tooltipAnimations", {
    get: function () {
      return TOOLTIP_ANIMATIONS;
    },
  });

  OrbitCarousel.registerAnimation = function (name, config) {
    ANIMATIONS[name] = config;
  };

  // ============================================
  // AUTO INIT
  // ============================================
  OrbitCarousel.autoInit = function (selector) {
    selector = selector || "[data-orbit-carousel]";

    document.querySelectorAll(selector).forEach(function (el) {
      if (el.orbitCarousel) return;

      var options = {};

      // Parse data attributes
      if (el.dataset.initialSlide !== undefined)
        options.initialSlide = parseInt(el.dataset.initialSlide);
      if (el.dataset.radius !== undefined)
        options.radius = parseInt(el.dataset.radius);
      if (el.dataset.mobileRadius !== undefined)
        options.mobileRadius = parseInt(el.dataset.mobileRadius);
      if (el.dataset.thumbSize !== undefined)
        options.thumbSize = parseInt(el.dataset.thumbSize);
      if (el.dataset.mobileThumbSize !== undefined)
        options.mobileThumbSize = parseInt(el.dataset.mobileThumbSize);
      if (el.dataset.activeThumbScale !== undefined)
        options.activeThumbScale = parseFloat(el.dataset.activeThumbScale);
      if (el.dataset.inactiveThumbOpacity !== undefined)
        options.inactiveThumbOpacity = parseFloat(
          el.dataset.inactiveThumbOpacity,
        );
      if (el.dataset.animation !== undefined)
        options.animation = el.dataset.animation;
      if (el.dataset.layout !== undefined) options.layout = el.dataset.layout;
      if (el.dataset.mode !== undefined) options.mode = el.dataset.mode;
      if (el.dataset.hoverDelay !== undefined)
        options.hoverDelay = parseInt(el.dataset.hoverDelay);
      if (el.dataset.effect !== undefined) options.effect = el.dataset.effect;
      if (el.dataset.loop !== undefined)
        options.loop = el.dataset.loop !== "false";
      if (el.dataset.speed !== undefined)
        options.speed = parseInt(el.dataset.speed);

      // Tooltip options from data attributes
      var tooltipOptions = {};
      if (el.dataset.tooltipEnabled !== undefined)
        tooltipOptions.enabled = el.dataset.tooltipEnabled !== "false";
      if (el.dataset.tooltipPlacement !== undefined)
        tooltipOptions.placement = el.dataset.tooltipPlacement;
      if (el.dataset.tooltipAnimation !== undefined)
        tooltipOptions.animation = el.dataset.tooltipAnimation;
      if (el.dataset.tooltipArrow !== undefined)
        tooltipOptions.arrow = el.dataset.tooltipArrow !== "false";

      if (Object.keys(tooltipOptions).length > 0) {
        options.tooltip = tooltipOptions;
      }

      // Autoplay
      if (el.dataset.autoplay !== undefined) {
        options.autoplay = {
          delay: parseInt(el.dataset.autoplay),
          pauseOnMouseEnter: el.dataset.pauseOnHover !== undefined,
          stopOnLastSlide: el.dataset.stopOnLastSlide !== undefined,
        };
      }

      // Keyboard
      if (el.dataset.keyboard !== undefined) {
        options.keyboard = {
          enabled: el.dataset.keyboard !== "false",
          onlyInViewport: el.dataset.keyboardOnlyInViewport !== "false",
        };
      }

      if (el.dataset.grabCursor !== undefined)
        options.grabCursor = el.dataset.grabCursor !== "false";

      // Observer
      if (el.dataset.observer !== undefined)
        options.observer = el.dataset.observer !== "false";
      if (el.dataset.observeParents !== undefined)
        options.observeParents = el.dataset.observeParents !== "false";

      // Pagination
      var paginationEl = el.querySelector(".orbit-pagination");
      if (paginationEl || el.dataset.pagination !== undefined) {
        options.pagination = {
          el: paginationEl || el.dataset.pagination,
          clickable: el.dataset.paginationClickable !== "false",
          type: el.dataset.paginationType || "bullets",
        };
      }

      // Navigation
      var nextEl = el.querySelector(".orbit-button-next");
      var prevEl = el.querySelector(".orbit-button-prev");
      if (nextEl || prevEl || el.dataset.navigation !== undefined) {
        options.navigation = {
          nextEl: nextEl || el.dataset.navigationNext,
          prevEl: prevEl || el.dataset.navigationPrev,
        };
      }

      el.orbitCarousel = new OrbitCarousel(el, options);
    });
  };

  // Auto-init on DOMContentLoaded
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        OrbitCarousel.autoInit();
      });
    } else {
      setTimeout(function () {
        OrbitCarousel.autoInit();
      }, 0);
    }
  }

  return OrbitCarousel;
});
