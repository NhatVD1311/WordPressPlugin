jQuery(document).ready(function ($) {
	'use strict';

	// if body has .et-fb than return the below code execution
	// for divi builder wireframe mode interrupt the code execution
	if (document.body.classList.contains('et-fb')) {
		return;
	}

  $(".et_pb_scroll_top.et-pb-icon").each(function () {
    // Remove the existing content
    $(this).empty();

    const settings = dnxteFrontendBackToTopData.settingsFields;

    const iconType = settings.button_icon_type,
      buttonContent = settings.button_content,
      iconText = settings.icon_text,
      buttonText = settings.display_text,
      iconPlacement = settings.icon_placement,
      buttonPosition = settings.position,
      hideOnMobile = settings.hide_on_mobile,
      hideOnMobileSize = settings.hide_on_mobile_size,
      buttonPaddingTop = settings.button_padding_top,
      buttonPaddingRight = settings.button_padding_right,
      buttonPaddingBottom = settings.button_padding_bottom,
      buttonPaddingLeft = settings.button_padding_left,
      buttonFontSize = settings.button_font_size,
      buttonIconSize = settings.icon_size,
      buttonFontWeight = settings.button_font_weight,
      buttonFont = settings.button_font,
      buttonIconColor = settings.icon_text_color,
      buttonIconHoverColor = settings.icon_text_hover_color,
      buttonBgColor = settings.bg_color,
      buttonBgHoverColor = settings.bg_hover_color,
      buttonBorderRadius = settings.border_radius,
      positionOffsetRight = settings.position_offset_right,
      positionOffsetLeft = settings.position_offset_left,
      positionOffsetBottom = settings.position_offset_bottom,
      buttonLineHeight = settings.button_line_height,
      buttonLetterSpacing = settings.button_letter_spacing,
      buttonTextAlign = settings.display_text_align,
      iconPosition = settings.position,
      borderWidth = settings.border_width,
      borderStyle = settings.border_style,
      borderColor = settings.border_color,
      borderHoverColor = settings.border_hover_color;

    $(this).addClass(
      "dnxte-back-to-top-wrapper dnxte-back-to-top-" + buttonPosition,
    );

    if ("1" == hideOnMobile && hideOnMobileSize) {
      $(this).attr("data-hide-on-mobile-size", hideOnMobileSize);
      $(this).addClass("dnxte-back-to-top-hide-on-mobile");
    }

    const $el = $(".dnxte-back-to-top-hide-on-mobile");
    $el.each(function () {
      const hideBelow = parseInt($(this).attr("data-hide-on-mobile-size"), 10);

      if (window.innerWidth <= hideBelow) {
        $(this).addClass("dnxte-back-to-top-hide-on-mobile");
      } else {
        $(this).removeClass("dnxte-back-to-top-hide-on-mobile");
      }
    });

    function toggleBackToTopVisibility() {
      $("[data-hide-on-mobile-size]").each(function () {
        const $el = $(this);
        const maxWidth = parseInt($el.data("hide-on-mobile-size"), 10);

        if (window.innerWidth <= maxWidth) {
          $el.hide();
        } else {
          $el.show();
        }
      });
    }

    // Run on load and on resize
    toggleBackToTopVisibility();
    $(window).on("resize", toggleBackToTopVisibility);

	$(this).css({ bottom: positionOffsetBottom + "px" });

	if ("left" === iconPosition) {
		$(this).css({
		  left: positionOffsetLeft + "px",
		  right: "unset",
		});
	} else {
		$(this).css({
		  left: "unset",
		  right: positionOffsetRight + "px",
		});
	}

    $(window).on("resize", function () {
      $el.each(function () {
        const hideBelow = parseInt(
          $(this).attr("data-hide-on-mobile-size"),
          10,
        );

        if (window.innerWidth <= hideBelow) {
          $(this).addClass("dnxte-back-to-top-hide-on-mobile");
        } else {
          $(this).removeClass("dnxte-back-to-top-hide-on-mobile");
        }
      });
    });

    let icon = "";
    let displayText = dnxteFrontendBackToTopData.settingsFields.display_text;

    if ("both" === buttonContent) {
      if (iconType === "dashicon" && "left" == iconPlacement) {
        icon = `<i class="dashicons ${dnxteFrontendBackToTopData.settingsFields.button_dashicon}"></i><span>${iconText}</span>`;
      } else if (
        iconType === "custom_image" &&
        dnxteFrontendBackToTopData.settingsFields.button_custom_image &&
        "left" == iconPlacement
      ) {
        icon = `<img src="${dnxteFrontendBackToTopData.settingsFields.button_custom_image}" alt="Custom Icon" /><span>${iconText}</span>`;
      } else if (
        iconType === "external_url" &&
        dnxteFrontendBackToTopData.settingsFields.button_external_url &&
        "left" == iconPlacement
      ) {
        icon = `<img src="${dnxteFrontendBackToTopData.settingsFields.button_external_url}" alt="Custom Icon" /><span>${iconText}</span>`;
      }

      if (iconType === "dashicon" && "right" == iconPlacement) {
        icon = `<span>${iconText}</span><i class="dashicons ${dnxteFrontendBackToTopData.settingsFields.button_dashicon}"></i>`;
      } else if (
        iconType === "custom_image" &&
        dnxteFrontendBackToTopData.settingsFields.button_custom_image &&
        "right" == iconPlacement
      ) {
        icon = `<span>${iconText}</span><img src="${dnxteFrontendBackToTopData.settingsFields.button_custom_image}" alt="Custom Icon" />`;
      } else if (
        iconType === "external_url" &&
        dnxteFrontendBackToTopData.settingsFields.button_external_url &&
        "right" == iconPlacement
      ) {
        icon = `<span>${iconText}</span><img src="${dnxteFrontendBackToTopData.settingsFields.button_external_url}" alt="Custom Icon" />`;
      }
    }

    if ("icon" == buttonContent && "dashicon" == iconType) {
      icon = `<i class="dashicons ${dnxteFrontendBackToTopData.settingsFields.button_dashicon}"></i>`;
    } else if (
      "icon" == buttonContent &&
      "custom_image" == iconType &&
      dnxteFrontendBackToTopData.settingsFields.button_custom_image
    ) {
      icon = `<img src="${dnxteFrontendBackToTopData.settingsFields.button_custom_image}" alt="Custom Icon" />`;
    } else if (
      "icon" == buttonContent &&
      "external_url" == iconType &&
      dnxteFrontendBackToTopData.settingsFields.button_external_url
    ) {
      icon = `<img src="${dnxteFrontendBackToTopData.settingsFields.button_external_url}" alt="Custom Icon" />`;
    }

    if ("text" == buttonContent) {
      icon = `<span>${iconText}</span>`;
    }

    if ("vertical" == buttonTextAlign) {
      // Add the new button HTML
      $(this).html(
        '<button id="dnxte-back-to-top-button" class="dnxte-back-to-top dnxte-back-to-top-right"><span class="dnxte-back-to-top-vertical">' +
          icon +
          "</span></button>",
      );
    } else {
      // Add the new button HTML
      $(this).html(
        '<button id="dnxte-back-to-top-button" class="dnxte-back-to-top dnxte-back-to-top-right">' +
          icon +
          "</button>",
      );
    }

    const $btn = $(this).find(".dnxte-back-to-top"),
      $btnImg = $(this).find(".dnxte-back-to-top img"),
      $btnIcon = $(this).find(".dnxte-back-to-top i");

    if ($btnIcon.length) {
      $btnIcon.css({
        "font-size": buttonIconSize + "px",
        width: buttonIconSize + "px",
        height: buttonIconSize + "px",
      });
    }

    if ($btnImg.length) {
      $btnImg.css({
        "max-width": buttonIconSize + "px",
        height: buttonIconSize + "px",
      });
    }

    $btn.on("mouseenter", function () {
      $(this).css("background-color", buttonBgHoverColor);
      $(this).css("color", buttonIconHoverColor);
      $(this).css("border-color", borderHoverColor);
    });

    $btn.on("mouseleave", function () {
      $(this).css("background-color", buttonBgColor);
      $(this).css("color", buttonIconColor);
      $(this).css("border-color", borderColor);
    });

    if ($btn.length) {
      $btn.css({
        "padding-top": buttonPaddingTop + "px",
        "padding-right": buttonPaddingRight + "px",
        "padding-bottom": buttonPaddingBottom + "px",
        "padding-left": buttonPaddingLeft + "px",
        "border-radius": buttonBorderRadius + "px",
        "border-width": borderWidth + "px",
        "border-style": borderStyle,
        "border-color": borderColor,
        "background-color": buttonBgColor,
        color: buttonIconColor,
        "font-size": buttonFontSize + "px",
        "font-family": `"${buttonFont}", sans-serif`,
        "font-weight": buttonFontWeight,
        "line-height": buttonLineHeight,
        "letter-spacing": buttonLetterSpacing + "px",
      });
    }
  });
});

/**
 * Apply visibility for back to top button
 */
function applyBackToTopVisibility() {
    jQuery(".et_pb_scroll_top.dnxte-back-to-top-wrapper").each(function () {
        let i = jQuery(this),
            o = parseInt(i.data("hide-on-mobile-size"), 10) || 767;
            window.innerWidth <= o
                ? i.css("display", "none").addClass("dnxte-back-to-top-hide-on-mobile")
                : i.css("display", "inline").removeClass("dnxte-back-to-top-hide-on-mobile");
    });
}
applyBackToTopVisibility(), jQuery(window).on("resize", applyBackToTopVisibility);
