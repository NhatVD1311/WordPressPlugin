/**
 * SVG Animator Frontend JavaScript
 *
 * Uses CSS stroke-dasharray/dashoffset transitions for SVG path drawing animation.
 * Supports delayed, sync, and oneByOne animation types.
 */

(function($) {
    'use strict';

    if (typeof $ === 'undefined') {
        return;
    }

    /**
     * SVG Animator Class
     */
    function SVGAnimator(element) {
        this.element = element;
        this.$element = $(element);
        this.innerElement = element.querySelector('.svg_animator__inner');
        this.svgContainer = element.querySelector('.svg_animator__svg-container');
        this.svg = this.svgContainer ? this.svgContainer.querySelector('svg') : null;

        if (!this.svg || !this.innerElement) {
            return;
        }

        this.config = this.getConfiguration();
        this.paths = [];
        this.loopTimer = null;
        this.delayTimer = null;
        this.currentLoopCount = 0;
        this.intersectionObserver = null;
        this.isAnimating = false;

        this.init();
    }

    /**
     * Get animation configuration from data attributes
     */
    SVGAnimator.prototype.getConfiguration = function() {
        var dataset = this.innerElement.dataset;

        return {
            animationType: dataset.animationType || 'delayed',
            timingFunction: dataset.timingFunction || 'ease',
            speed: parseInt(dataset.speed) || 200,
            delay: parseInt(dataset.delay) || 0,
            loop: dataset.loop === 'on',
            unlimited: dataset.unlimited === 'on',
            loopCount: parseInt(dataset.loopCount) || 3,
            trigger: dataset.trigger === 'on',
            triggerType: dataset.triggerType || 'inViewport'
        };
    };

    /**
     * Discover and prepare animatable SVG elements
     */
    SVGAnimator.prototype.discoverPaths = function() {
        this.paths = [];
        var elements = this.svg.querySelectorAll('path, line, polyline, polygon, circle, ellipse, rect');

        for (var i = 0; i < elements.length; i++) {
            var el = elements[i];
            var length = 0;

            try {
                length = el.getTotalLength ? el.getTotalLength() : 0;
            } catch (e) {
                length = 0;
            }

            if (length <= 0) continue;

            // Ensure element has stroke for animation
            var style = window.getComputedStyle(el);
            if (!style.stroke || style.stroke === 'none') {
                el.style.stroke = style.fill || '#000000';
                el.style.fill = 'none';
            }
            if (!style.strokeWidth || style.strokeWidth === '0' || style.strokeWidth === '0px') {
                el.style.strokeWidth = '1';
            }

            this.paths.push({ el: el, length: length });
        }
    };

    /**
     * Initialize the SVG animator
     */
    SVGAnimator.prototype.init = function() {
        this.discoverPaths();

        if (this.paths.length === 0) {
            return;
        }

        // Set all paths to hidden state
        this.resetPaths();

        if (this.config.trigger) {
            this.setupTriggers();
        } else {
            if (this.config.delay > 0) {
                var self = this;
                this.delayTimer = setTimeout(function() {
                    self.startAnimation();
                }, this.config.delay * 16.67); // frames to ms at 60fps
            } else {
                this.startAnimation();
            }
        }
    };

    /**
     * Reset all paths to hidden state (stroke fully offset)
     */
    SVGAnimator.prototype.resetPaths = function() {
        for (var i = 0; i < this.paths.length; i++) {
            var p = this.paths[i];
            p.el.style.transition = 'none';
            p.el.style.strokeDasharray = p.length + ' ' + p.length;
            p.el.style.strokeDashoffset = p.length;
        }
    };

    /**
     * Setup animation triggers based on configuration
     */
    SVGAnimator.prototype.setupTriggers = function() {
        var self = this;

        switch (this.config.triggerType) {
            case 'inViewport':
                this.setupIntersectionObserver();
                break;
            case 'hover':
                this.$element.on('mouseenter.svgAnimator', function() {
                    self.startAnimation();
                });
                break;
            case 'click':
                this.$element.on('click.svgAnimator', function() {
                    self.startAnimation();
                });
                break;
        }
    };

    /**
     * Setup intersection observer for viewport trigger
     */
    SVGAnimator.prototype.setupIntersectionObserver = function() {
        var self = this;

        if (!window.IntersectionObserver) {
            this.startAnimation();
            return;
        }

        this.intersectionObserver = new IntersectionObserver(function(entries) {
            for (var i = 0; i < entries.length; i++) {
                if (entries[i].isIntersecting) {
                    self.startAnimation();
                    if (!self.config.loop) {
                        self.intersectionObserver.disconnect();
                    }
                }
            }
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });

        this.intersectionObserver.observe(this.element);
    };

    /**
     * Start the stroke-draw animation
     */
    SVGAnimator.prototype.startAnimation = function(isLoopIteration) {
        if (this.paths.length === 0) return;

        this.isAnimating = true;
        if (!isLoopIteration) {
            this.currentLoopCount = 0;
        }

        // Reset paths to hidden
        this.resetPaths();

        // Force reflow so the reset takes effect before transition
        this.svg.getBoundingClientRect();

        var totalDuration = this.config.speed / 60; // frames to seconds
        var timing = this.config.timingFunction;
        var self = this;
        var longestEnd = 0;

        for (var i = 0; i < this.paths.length; i++) {
            var p = this.paths[i];
            var pathDelay = 0;
            var pathDuration = totalDuration;

            switch (this.config.animationType) {
                case 'sync':
                    // All paths animate simultaneously for the full duration
                    pathDelay = 0;
                    pathDuration = totalDuration;
                    break;

                case 'oneByOne':
                    // Each path gets an equal share of the total time, sequential
                    pathDuration = totalDuration / this.paths.length;
                    pathDelay = pathDuration * i;
                    break;

                case 'delayed':
                default:
                    // Paths start with staggered delays, overlapping
                    var stagger = totalDuration / (this.paths.length + 1);
                    pathDelay = stagger * i;
                    pathDuration = totalDuration - pathDelay;
                    if (pathDuration < 0.1) pathDuration = 0.1;
                    break;
            }

            var endTime = pathDelay + pathDuration;
            if (endTime > longestEnd) longestEnd = endTime;

            // Apply transition and animate
            (function(path, dur, del) {
                setTimeout(function() {
                    path.el.style.transition = 'stroke-dashoffset ' + dur + 's ' + timing;
                    path.el.style.strokeDashoffset = '0';
                }, del * 1000);
            })(p, pathDuration, pathDelay);
        }

        // After animation completes, handle loop
        if (this.config.loop) {
            var completionMs = longestEnd * 1000 + 50; // small buffer
            this.loopTimer = setTimeout(function() {
                self.handleLooping();
            }, completionMs);
        }
    };

    /**
     * Handle looping behavior
     */
    SVGAnimator.prototype.handleLooping = function() {
        if (!this.config.loop) return;

        this.currentLoopCount++;

        var shouldLoop = this.config.unlimited ||
            this.currentLoopCount < this.config.loopCount;

        if (shouldLoop) {
            var self = this;
            // Brief pause between loops
            this.loopTimer = setTimeout(function() {
                self.resetPaths();
                self.svg.getBoundingClientRect(); // reflow
                // Small delay to let reset be visible
                setTimeout(function() {
                    self.startAnimation(true);
                }, 50);
            }, 400);
        } else {
            this.isAnimating = false;
        }
    };

    /**
     * Stop the animation and clean up
     */
    SVGAnimator.prototype.destroy = function() {
        if (this.loopTimer) {
            clearTimeout(this.loopTimer);
            this.loopTimer = null;
        }
        if (this.delayTimer) {
            clearTimeout(this.delayTimer);
            this.delayTimer = null;
        }
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
            this.intersectionObserver = null;
        }
        this.$element.off('.svgAnimator');
        this.isAnimating = false;
    };

    /**
     * Restart the animation (for VB or settings changes)
     */
    SVGAnimator.prototype.restart = function() {
        this.destroy();
        this.config = this.getConfiguration();
        this.init();
    };

    /**
     * Initialize all SVG Animator modules on the page
     */
    function initSVGAnimators() {
        $('.svg_animator').each(function() {
            var $this = $(this);

            if ($this.data('svg-animator-initialized')) {
                return;
            }

            var animator = new SVGAnimator(this);
            $this.data('svg-animator-instance', animator);
            $this.data('svg-animator-initialized', true);
        });
    }

    /**
     * Reinitialize SVG Animators (for Visual Builder)
     */
    function reinitSVGAnimators() {
        $('.svg_animator').each(function() {
            var $this = $(this);
            var instance = $this.data('svg-animator-instance');

            if (instance) {
                instance.restart();
            } else {
                var animator = new SVGAnimator(this);
                $this.data('svg-animator-instance', animator);
                $this.data('svg-animator-initialized', true);
            }
        });
    }

    // Initialize on page load
    $(document).ready(function() {
        setTimeout(initSVGAnimators, 100);
    });

    // Reinitialize after page content changes
    $(document).on('et_pb_after_init_modules', function() {
        setTimeout(initSVGAnimators, 100);
    });

    // Fallback for Divi 5 modules
    $(window).on('load', function() {
        setTimeout(initSVGAnimators, 200);
    });

    // Visual Builder compatibility
    if (window.et_pb_custom && window.et_pb_custom.is_builder) {
        $(window).on('et_pb_after_init_modules et_pb_module_updated', function() {
            reinitSVGAnimators();
        });

        $('body').on('et_pb_settings_updated', '.svg_animator', function() {
            var $this = $(this);
            var instance = $this.data('svg-animator-instance');

            if (instance) {
                setTimeout(function() {
                    instance.restart();
                }, 100);
            }
        });
    }

    // Export for global access
    window.DNXTESVGAnimator = SVGAnimator;

})(jQuery);
