/**
 * Button FX — VB Extension
 * Uses Divi native fields. Features: Glow Border, Click Ripple, Click Celebration.
 * Targets: divi/button + any dnxte button modules.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var React = window.vendor.React;
  var element = wp.element;

  function isTarget(name) {
    if (!name || typeof name !== 'string') return false;
    if (name === 'divi/button') return true;
    // Match any dnxte module with "button" in name
    if (name.indexOf('dnxte/') === 0 && name.toLowerCase().indexOf('button') !== -1) return true;
    return false;
  }

  function buildGroup() {
    return {
      groupName: 'dnxteButtonFx',
      panel: 'design',
      priority: 88,
      multiElements: true,
      component: {
        name: 'divi/composite',
        props: { groupLabel: 'Button FX' }
      }
    };
  }

  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-button-fx', function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteButtonFx) next.dnxteButtonFx = buildGroup();
    return next;
  });

  function isOn(p) {
    return 'on' === (p.attrs?.dnxte_button_fx?.advanced?.use_button_fx?.desktop?.value);
  }
  function getVal(p, key) {
    return p.attrs?.dnxte_button_fx?.advanced?.[key]?.desktop?.value;
  }

  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-button-fx', function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs.dnxte_button_fx = {
      type: 'object',
      selector: '{{selector}}',
      default: { advanced: {
        use_button_fx:      { desktop: { value: 'off' } },
        // Glow Border
        glow_enabled:       { desktop: { value: 'off' } },
        glow_color1:        { desktop: { value: '#7C3AED' } },
        glow_color2:        { desktop: { value: '#06B6D4' } },
        glow_color3:        { desktop: { value: '#F43F5E' } },
        glow_intensity:     { desktop: { value: '1' } },
        glow_blur:          { desktop: { value: '15' } },
        glow_spread:        { desktop: { value: '25' } },
        glow_auto_play:     { desktop: { value: 'off' } },
        glow_auto_speed:    { desktop: { value: '3' } },
        // Ripple
        ripple_enabled:     { desktop: { value: 'off' } },
        ripple_color:       { desktop: { value: 'rgba(255,255,255,0.35)' } },
        // Celebration
        celebration_type:   { desktop: { value: 'none' } },
        celebration_count:  { desktop: { value: '30' } },
        celebration_trigger:{ desktop: { value: 'always' } },
      }},
      settings: { advanced: {
        use_button_fx: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.use_button_fx', label: 'Enable Button FX',
          groupSlug: 'dnxteButtonFx', priority: 1, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }
        }},

        // ── Glow Border ──
        glow_enabled: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_enabled', label: 'Glow Border',
          groupSlug: 'dnxteButtonFx', priority: 10, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: isOn
        }},
        glow_color1: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_color1', label: 'Glow Color 1',
          groupSlug: 'dnxteButtonFx', priority: 11, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_color2: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_color2', label: 'Glow Color 2',
          groupSlug: 'dnxteButtonFx', priority: 12, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_color3: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_color3', label: 'Glow Color 3',
          groupSlug: 'dnxteButtonFx', priority: 13, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_intensity: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_intensity', label: 'Glow Intensity',
          groupSlug: 'dnxteButtonFx', priority: 14, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.2, max: 2, step: 0.1, defaultUnit: '' } },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_blur: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_blur', label: 'Glow Blur',
          groupSlug: 'dnxteButtonFx', priority: 15, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 5, max: 50, step: 1, defaultUnit: '' } },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_spread: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_spread', label: 'Cone Spread',
          groupSlug: 'dnxteButtonFx', priority: 16, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 10, max: 50, step: 1, defaultUnit: '' } },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},

        glow_auto_play: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_auto_play', label: 'Auto Play Glow',
          description: 'Glow automatically sweeps around the border without hover',
          groupSlug: 'dnxteButtonFx', priority: 17, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on'; }
        }},
        glow_auto_speed: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.glow_auto_speed', label: 'Auto Play Speed',
          groupSlug: 'dnxteButtonFx', priority: 18, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 1, max: 10, step: 0.5, defaultUnit: '' } },
          visible: function (p) { return isOn(p) && getVal(p, 'glow_enabled') === 'on' && getVal(p, 'glow_auto_play') === 'on'; }
        }},

        // ── Ripple ──
        ripple_enabled: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.ripple_enabled', label: 'Click Ripple',
          groupSlug: 'dnxteButtonFx', priority: 30, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: isOn
        }},
        ripple_color: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.ripple_color', label: 'Ripple Color',
          groupSlug: 'dnxteButtonFx', priority: 31, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function (p) { return isOn(p) && getVal(p, 'ripple_enabled') === 'on'; }
        }},

        // ── Celebration ──
        celebration_type: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.celebration_type', label: 'Click Celebration',
          groupSlug: 'dnxteButtonFx', priority: 40, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'none':      { label: 'None' },
            'confetti':  { label: 'Confetti Burst' },
            'stars':     { label: 'Stars Burst' },
            'emoji':     { label: 'Emoji Burst' },
            'fireworks': { label: 'Fireworks' },
          } } },
          visible: isOn
        }},
        celebration_count: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.celebration_count', label: 'Particle Count',
          groupSlug: 'dnxteButtonFx', priority: 41, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 10, max: 60, step: 5, defaultUnit: '' } },
          visible: function (p) { return isOn(p) && getVal(p, 'celebration_type') !== 'none'; }
        }},
        celebration_trigger: { groupType: 'group-item', item: {
          attrName: 'dnxte_button_fx.advanced.celebration_trigger', label: 'Celebration Trigger',
          groupSlug: 'dnxteButtonFx', priority: 42, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'always':       { label: 'Every Click' },
            'once':         { label: 'Once per Page' },
            'once_session': { label: 'Once per Session' },
            'once_ever':    { label: 'Once Ever' },
          } } },
          visible: function (p) { return isOn(p) && getVal(p, 'celebration_type') !== 'none'; }
        }},
      }}
    };

    if (meta && typeof meta === 'object') {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteButtonFx) {
        meta.settings.groups.dnxteButtonFx = buildGroup();
      }
    }

    return attrs;
  });

  // ════════════════ VB live preview ════════════════
  // Mirror of the PHP config mapping in ButtonFxExtension::filter_wrapper_render.
  function buildConfig(attrs) {
    var adv = (attrs && attrs.dnxte_button_fx && attrs.dnxte_button_fx.advanced) || {};
    function dv(key, def) {
      var f = adv[key];
      var v = f && f.desktop ? f.desktop.value : undefined;
      return (v != null && v !== '') ? v : def;
    }
    return {
      enabled:            'on',
      glowBorder:         dv('glow_enabled', 'off'),
      glowColor1:         dv('glow_color1', '#7C3AED'),
      glowColor2:         dv('glow_color2', '#06B6D4'),
      glowColor3:         dv('glow_color3', '#F43F5E'),
      glowIntensity:      dv('glow_intensity', '1'),
      glowBlur:           dv('glow_blur', '15'),
      glowSpread:         dv('glow_spread', '25'),
      glowAutoPlay:       dv('glow_auto_play', 'off'),
      glowAutoSpeed:      dv('glow_auto_speed', '3'),
      ripple:             dv('ripple_enabled', 'off'),
      rippleColor:        dv('ripple_color', 'rgba(255,255,255,0.35)'),
      celebration:        dv('celebration_type', 'none'),
      celebrationCount:   dv('celebration_count', '30'),
      celebrationTrigger: dv('celebration_trigger', 'always'),
    };
  }

  // A hidden span appended to the module wrapper; it finds the module DOM in the
  // canvas and drives the shared engine (window.DnxteButtonFx) so the effect —
  // notably the glow border — is visible live in the Visual Builder, not just
  // on the front end.
  function EffectInjector(props) {
    var ref = React.useRef(null);
    var instRef = React.useRef(null);
    var raw = props.config || '';

    function getHostEl() {
      if (!ref.current) return null;
      var el = ref.current.parentElement;
      while (el) {
        if (
          el.classList.contains('et_pb_button') ||
          el.classList.contains('et_pb_module') ||
          el.dataset.diviRenderer
        ) { return el; }
        el = el.parentElement;
      }
      return ref.current.parentElement;
    }

    function teardown() {
      if (instRef.current && instRef.current.destroy) {
        try { instRef.current.destroy(); } catch (e) {}
      }
      instRef.current = null;
    }

    React.useEffect(function () {
      if (!window.DnxteButtonFx) return;
      var timer = setTimeout(function () {
        var host = getHostEl();
        if (!host) return;
        // Clean up any previous instance (config change / re-render).
        teardown();
        if (host._dnxteButtonFx && host._dnxteButtonFx.destroy) {
          try { host._dnxteButtonFx.destroy(); } catch (e) {}
        }
        var cfg;
        try { cfg = raw ? JSON.parse(raw) : null; } catch (e) { cfg = null; }
        if (cfg && cfg.enabled === 'on') {
          instRef.current = new window.DnxteButtonFx(host, cfg);
          host._dnxteButtonFx = instRef.current;
        }
      }, 60);
      return function () { clearTimeout(timer); teardown(); };
    }, [raw]);

    return element.createElement('span', {
      ref: ref,
      'data-dnxte-btnfx-injector': '',
      style: { display: 'none', position: 'absolute', pointerEvents: 'none' },
    });
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-button-fx', function (moduleWrapper, param) {
    if (!isTarget(param.name)) return moduleWrapper;
    var use = param.attrs?.dnxte_button_fx?.advanced?.use_button_fx?.desktop?.value;
    if (use !== 'on') return moduleWrapper;
    var raw = JSON.stringify(buildConfig(param.attrs));
    var children = moduleWrapper.props.children;
    var childArray = Array.isArray(children) ? children : [children];
    var injector = element.createElement(EffectInjector, { key: 'dnxte-btnfx-injector', config: raw });
    return element.cloneElement(moduleWrapper, {}, childArray.concat([injector]));
  });
})();
