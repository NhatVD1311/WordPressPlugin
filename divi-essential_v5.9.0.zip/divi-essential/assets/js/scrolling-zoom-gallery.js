(() => {
  "use strict";
  var o = {
    n: (e) => {
      var r = e && e.__esModule ? () => e.default : () => e;
      return o.d(r, { a: r }), r;
    },
    d: (e, r) => {
      for (var l in r)
        o.o(r, l) &&
          !o.o(e, l) &&
          Object.defineProperty(e, l, { enumerable: !0, get: r[l] });
    },
    o: (o, e) => Object.prototype.hasOwnProperty.call(o, e),
  };
  const e = window.jQuery;
  var r = o.n(e);

  function l(o) {
    let e = o.find(".dnxte-scroll-zoom-init"),
      l = o.find(".dnxte-scroll-zoom-gallery-items"),
      t = o.find(".dnxte_scrolling_zoom_gallery_child"),
      n = parseFloat(e.data("start_opacity")),
      a = t.length;

    // Read all settings from data attributes
    var zDepth = parseInt(e.data("z_depth") || 200, 10);
    var scrollSpeed = parseInt(e.data("scroll_speed") || 150, 10);
    var scrub = parseFloat(e.data("scrub") || 1);
    var easing = e.data("easing") || "none";
    var customEase = e.data("custom_ease") || "0.25,0.1,0.25,1";
    var perspective = parseInt(e.data("perspective") || 1000, 10);
    var hideScrollbar = e.data("hide_scrollbar") || "off";
    var zoomDirection = e.data("zoom_direction") || "in";
    var reverse = e.data("reverse") || "on";
    var disableMobile = e.data("disable_mobile") || "off";
    var reducedMotion = e.data("reduced_motion") || "on";
    var gpu = e.data("gpu") || "on";
    var stickyOffset = e.data("sticky_offset") || "0px";

    // Disable on mobile if setting is on
    if (disableMobile === "on" && window.innerWidth <= 768) {
      return;
    }

    // Respect prefers-reduced-motion
    if (reducedMotion === "on" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      return;
    }

    // Resolve easing value
    var resolvedEase = easing;
    if (easing === "custom" && customEase) {
      resolvedEase = "cubic-bezier(" + customEase + ")";
    }

    // Apply perspective
    e.find(".dnxte-scroll-zoom-inner").css("perspective", perspective + "px");

    // Apply GPU acceleration
    if (gpu === "on") {
      l.css("will-change", "transform");
      t.css("will-change", "transform, opacity");
    }

    // Z direction multiplier: "in" = positive (towards viewer), "out" = negative (away)
    var zSign = zoomDirection === "out" ? -1 : 1;

    ScrollTrigger.getAll().forEach(function (o) {
      o.trigger === e[0] && o.kill();
    });

    // Collect child elements for pointer-events management
    var childElements = [];
    t.each(function () { childElements.push(this); });

    function setActiveChild(activeIndex) {
      for (var idx = 0; idx < childElements.length; idx++) {
        childElements[idx].style.pointerEvents = (idx === activeIndex) ? "all" : "none";
      }
    }

    function setAllChildrenClickable() {
      for (var idx = 0; idx < childElements.length; idx++) {
        childElements[idx].style.pointerEvents = "all";
      }
    }

    function setAllChildrenNone() {
      for (var idx = 0; idx < childElements.length; idx++) {
        childElements[idx].style.pointerEvents = "none";
      }
    }

    let i = gsap.timeline({
      defaults: { duration: 2 * a, ease: resolvedEase },
      scrollTrigger: {
        trigger: e[0],
        start: "top top+=" + stickyOffset,
        end: "+=" + scrollSpeed * a + "%",
        scrub: scrub,
        pin: !0,
        anticipatePin: 1,
        onUpdate: function (self) {
          // Calculate active child based on scroll progress
          // Each child takes 3 units in the timeline (1 for container .to + 2 for child .fromTo)
          // Total timeline duration = 3 * a (a = number of children)
          var progress = self.progress;
          var activeIndex = Math.min(Math.floor(progress * a), a - 1);
          setActiveChild(activeIndex);
        },
        onEnter: function () {
          if (hideScrollbar === "on") r()("html").addClass("dnxte_hide_scrollbar");
        },
        onLeave: function () {
          r()("html").removeClass("dnxte_hide_scrollbar");
          // After animation completes, make the last child clickable
          setActiveChild(a - 1);
        },
        onEnterBack: function () {
          if (hideScrollbar === "on") r()("html").addClass("dnxte_hide_scrollbar");
        },
        onLeaveBack: function () {
          r()("html").removeClass("dnxte_hide_scrollbar");
          // Before animation, nothing is clickable
          setAllChildrenNone();
        },
      },
    });

    // Reverse animation: if off, disable reverse playback on scroll back
    if (reverse !== "on") {
      i.scrollTrigger.vars.toggleActions = "play none none none";
    }

    t.each(function (o) {
      var el = this;
      let e = zSign * (zDepth * (o + 1) + (zDepth / 2)),
        childZ = zSign * -(zDepth * (o + 1));
      i.to(l[0], { z: e }).fromTo(
        el,
        { opacity: n, z: childZ },
        { opacity: 1, z: childZ },
        o,
      );
    });
  }

  // Handle button/link clicks via event delegation since 3D transforms block native clicks
  function bindClickHandlers(wrapper) {
    wrapper.off("click.szg").on("click.szg", ".dnxte-szg-button, .dnxte-szg-content a", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      var href = r()(this).attr("href");
      var target = r()(this).attr("target") || "_self";
      if (href && href !== "#") {
        if (target === "_blank") {
          window.open(href, "_blank");
        } else {
          window.location.href = href;
        }
      }
    });

    // Item link (whole card clickable)
    wrapper.off("click.szg-item").on("click.szg-item", ".dnxte_scrolling_zoom_gallery_child[data-link]", function (ev) {
      if (r()(ev.target).closest("a, button").length) return; // Don't override button clicks
      var opacity = parseFloat(gsap.getProperty(this, "opacity") || 0);
      if (opacity < 0.5) return; // Only clickable when visible
      var href = r()(this).data("link");
      var target = r()(this).data("link-target") || "_self";
      if (href) {
        if (target === "_blank") {
          window.open(href, "_blank");
        } else {
          window.location.href = href;
        }
      }
    });
  }

  r()(document).ready(function () {
    window.addEventListener("DnxteScrollZoomGalleryPropsChanged", () => {
      r()(".dnxte-scroll-zoom-wrapper").each(function () {
        gsap.registerPlugin(ScrollTrigger), l(r()(this));
        bindClickHandlers(r()(this));
      });
    }),
      r()(".dnxte-scroll-zoom-wrapper").each(function () {
        gsap.registerPlugin(ScrollTrigger), l(r()(this));
        bindClickHandlers(r()(this));
      });
  });
})();
