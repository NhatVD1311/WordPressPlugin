; (function ($) {
    $(document).ready(function () {
        // Cube Slider Data
        $(".dnxte-3dcubeslider-active").length &&
        $(".dnxte-3dcubeslider-active").each(function() {
          const cubeSliderData = $(this).data();
          const cubeSliderSwiper = new Swiper(this, {
            // direction: cubeSliderDataData.direction,
            autoplay: "on" === cubeSliderData.autoplay  ? { delay: cubeSliderData.delay } : false,
            speed: cubeSliderData.speed ? parseInt(cubeSliderData.speed) : 400,
            grabCursor: "on" === cubeSliderData.grab,
            loop: "on" === cubeSliderData.loop,
            effect: "cube",
            cubeEffect: {
              slideShadows: "on" === cubeSliderData.slideshadows,
              shadow: "on" === cubeSliderData.shadow,
              shadowOffset:"on" === cubeSliderData.shadow ? parseInt(cubeSliderData.shadowoffset) : 20,
              shadowScale: 'on' === cubeSliderData.shadow ? parseFloat(cubeSliderData.shadowscale) : 0,
            },
            pagination: {
              el: ".swiper-pagination",
              type: cubeSliderData.paginationtype,
              dynamicBullets: "on" === cubeSliderData.dynamicbullets,
              clickable: true,
            },
            keyboard: {
              enabled: "on" === cubeSliderData.keyboard,
              onlyInViewport: false,
            },
            mousewheel: {
              enabled: "on" === cubeSliderData.mouse,
              invert: true,
            },
            navigation: "on" === cubeSliderData.usearrownavigation ? {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
          } : false,
            observer: true,
            observeParents: true,
            observeSlideChildren: true,
          });
    
          // Handle autoplay on hover
          if ('on' === cubeSliderData.autoplay && 'on' === cubeSliderData.pauseonhover) {
            $(this).on("mouseenter", function() {
              cubeSliderSwiper.autoplay.stop();
            });
            $(this).on("mouseleave", function() {
              cubeSliderSwiper.autoplay.start();
            });
          }
        });
    });
})(jQuery);