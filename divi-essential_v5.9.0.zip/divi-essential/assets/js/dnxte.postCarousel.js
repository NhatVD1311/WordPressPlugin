; (function ($) {
    $(document).ready(function () {
        // Logo Carousel
        $(".dnxte-blog-carousel-slide-active").each(function(e) {
          const data = $(this).data();
          const carouselBreakpoint =
            data.breakpoints && data.breakpoints.split("|");
          
          const postCarouselSwiper = new Swiper(this, {
            
            // direction: logoData.direction,
            speed: data?.speed || 400,
            slidesPerView: carouselBreakpoint && parseInt(carouselBreakpoint[0]),
            breakpoints: {
              1024: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[0]) : 3 ,
              },
              768: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[1]) : 2,
              },
              479: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 1,
              },
              200: {
                slidesPerView:
                  carouselBreakpoint ? parseInt(carouselBreakpoint[2]) : 1,
              },
            },
            spaceBetween: parseInt(data.spacebetween),
            centeredSlides: "on" === data.centerslide,
            direction: "horizontal",
            effect: "coverflow",
            coverflowEffect: {
              slideShadows: "on" === data.slideshadow,
              rotate: data.rotate,
              stretch: data.stretch,
              depth: data.depth,
            },
            grabCursor: "on" === data.grab,
            loop: "on" === data.loop,
            autoplay: "on" === data.autoplay  ? { delay: data.delay } : false,
            navigation: {
              nextEl:
                $(this).siblings(".swiper-button-next")[0] ||
                $(this)
                  .siblings(".swiper-button-container")
                  .children(".swiper-button-next")[0],
              prevEl:
                $(this).siblings(".swiper-button-prev")[0] ||
                $(this)
                  .siblings(".swiper-button-container")
                  .children(".swiper-button-prev")[0],
            },
            pagination: {
              el: ".swiper-pagination",
              type: data.paginationtype,
              dynamicBullets: "on" === data.dynamicbullets,
              clickable: "on" === data.clickable,
            },
            keyboard: {
              enabled: "on" === data.keyboard,
              onlyInViewport: false
            },
            mousewheel: {
              enabled: "on" === data.mousewheel,
              invert: false
            },
            observer: true,
            observeParents: true,
            observeSlideChildren: true,
          });

			// ONLY inject when ON
			if (data.autoheight === "on") {
				swiperConfig.autoHeight = true;
			}

          // Handle autoplay on hover
          if ('on' === data.autoplay && 'on' === data.pauseonhover) {
            $(this).on("mouseenter", function() {
              postCarouselSwiper.autoplay.stop();
            });
            $(this).on("mouseleave", function() {
              postCarouselSwiper.autoplay.start();
            });
          }

          // Handle autoplay on hover
          // if ('on' === logoData.autoplay && 'on' === logoData.pauseonhover) {
          //   $(this).on("mouseenter", function() {
          //     logoSwiper.autoplay.stop();
          //   });
          //   $(this).on("mouseleave", function() {
          //     logoSwiper.autoplay.start();
          //   });
          // }
            // if (logoData.pauseonhover === "on") {
            //   const handleMouseEnter = () => {
            //       logoSwiper.autoplay.stop();
            //   };

            //   const handleMouseLeave = () => {
            //       logoSwiper.autoplay.start();
            //   };

            //   const swiperContainer = this;
            //   swiperContainer.addEventListener("mouseenter", handleMouseEnter);
            //   swiperContainer.addEventListener("mouseleave", handleMouseLeave);

            //   // Clean up event listeners on destroy
            //   logoSwiper.on('destroy', () => {
            //       swiperContainer.removeEventListener("mouseenter", handleMouseEnter);
            //       swiperContainer.removeEventListener("mouseleave", handleMouseLeave);
            //   });
            // }
        });
    });
})(jQuery);