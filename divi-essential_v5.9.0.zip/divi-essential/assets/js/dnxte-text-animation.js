(function(global) {
  'use strict';

  // Register GSAP TextPlugin if available.
  if (typeof gsap !== 'undefined' && typeof TextPlugin !== 'undefined') {
    gsap.registerPlugin(TextPlugin);
  }

  var DEFAULTS = {
    type:          'blur',
    direction:     'left',
    speed:         1,
    stagger:       0.08,
    color1:        '#00d4aa',
    color2:        '#7c3aed',
    repeat:        true,
    splitBy:       'char',
    words:         [],
    glitchVariant: 'classic',
    focusMode:     'auto',   // 'auto' | 'manual' | 'both'
    // Typewriter
    typingSpeed:   60,
    deletingSpeed: 35,
    pauseDuration: 2000,
    cursorChar:    '|',
    cursorBlink:   0.5,
    showCursor:    true,
    variableSpeed: true,
    varSpeedMin:   40,
    varSpeedMax:   120,
    textureUrl:    '',
  };

  // ---------------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------------
  function DnxteTextAnimation(element, options) {
    if (!element || typeof gsap === 'undefined') return;

    this.el          = element;
    this._destroyed  = false;
    this._tweens     = [];
    this._intervals  = [];
    this._timeouts   = [];
    this._listeners  = [];
    this._rafId      = null;
    this._domEls     = [];

    // Preserve originals.
    this._originalHTML = element.innerHTML;
    this._originalText = element.textContent.trim();

    // Build options: defaults < data-attributes < passed options.
    var dataOpts = this._parseDataAttrs();
    this.opts = {};
    var key;
    for (key in DEFAULTS) { this.opts[key] = DEFAULTS[key]; }
    for (key in dataOpts)  { if (dataOpts[key] !== undefined) this.opts[key] = dataOpts[key]; }
    for (key in options)   { if (options[key] !== undefined) this.opts[key] = options[key]; }

    this._init();
  }

  var proto = DnxteTextAnimation.prototype;

  // ---------------------------------------------------------------
  // Data-attribute parser
  // ---------------------------------------------------------------
  proto._parseDataAttrs = function() {
    var el = this.el;
    var o  = {};

    if (el.hasAttribute('data-text-anim'))      o.type          = el.getAttribute('data-text-anim');
    if (el.hasAttribute('data-text-direction'))  o.direction     = el.getAttribute('data-text-direction');
    if (el.hasAttribute('data-text-speed'))      o.speed         = parseFloat(el.getAttribute('data-text-speed')) || 1;
    if (el.hasAttribute('data-text-stagger'))    o.stagger       = parseFloat(el.getAttribute('data-text-stagger'));
    if (el.hasAttribute('data-text-color1'))     o.color1        = el.getAttribute('data-text-color1');
    if (el.hasAttribute('data-text-color2'))     o.color2        = el.getAttribute('data-text-color2');
    if (el.hasAttribute('data-text-split'))      o.splitBy       = el.getAttribute('data-text-split');
    if (el.hasAttribute('data-text-glitch'))          o.glitchVariant = el.getAttribute('data-text-glitch');
    if (el.hasAttribute('data-text-focus-mode'))     o.focusMode     = el.getAttribute('data-text-focus-mode');
    // Typewriter
    if (el.hasAttribute('data-text-typing-speed'))   o.typingSpeed   = parseInt(el.getAttribute('data-text-typing-speed'));
    if (el.hasAttribute('data-text-deleting-speed')) o.deletingSpeed = parseInt(el.getAttribute('data-text-deleting-speed'));
    if (el.hasAttribute('data-text-pause-duration')) o.pauseDuration = parseInt(el.getAttribute('data-text-pause-duration'));
    if (el.hasAttribute('data-text-cursor-char'))    o.cursorChar    = el.getAttribute('data-text-cursor-char');
    if (el.hasAttribute('data-text-cursor-blink'))   o.cursorBlink   = parseFloat(el.getAttribute('data-text-cursor-blink'));
    if (el.hasAttribute('data-text-show-cursor'))    o.showCursor    = el.getAttribute('data-text-show-cursor') !== 'false';
    if (el.hasAttribute('data-text-variable-speed')) o.variableSpeed = el.getAttribute('data-text-variable-speed') !== 'false';
    if (el.hasAttribute('data-text-var-speed-min'))  o.varSpeedMin   = parseInt(el.getAttribute('data-text-var-speed-min'));
    if (el.hasAttribute('data-text-var-speed-max'))  o.varSpeedMax   = parseInt(el.getAttribute('data-text-var-speed-max'));
    if (el.hasAttribute('data-text-texture-url'))   o.textureUrl    = el.getAttribute('data-text-texture-url');

    if (el.hasAttribute('data-text-repeat')) {
      var rv = el.getAttribute('data-text-repeat');
      o.repeat = rv === 'false' ? false : true;
    }

    if (el.hasAttribute('data-text-words')) {
      var raw = el.getAttribute('data-text-words');
      o.words = raw ? raw.split(',').map(function(w) { return w.trim(); }).filter(Boolean) : [];
    }

    return o;
  };

  // ---------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------

  /** Split element text into <span> wrapped chars or words. */
  proto._splitText = function(forceMode) {
    var text    = this._originalText;
    var splitBy = forceMode || this.opts.splitBy;
    var el      = this.el;

    if (splitBy === 'word') {
      var words = text.split(/\s+/);
      el.innerHTML = words.map(function(w) {
        return '<span class="dnxte-ta-word" style="display:inline-block;margin-right:0.3em;">' + w + '</span>';
      }).join('');
      return Array.prototype.slice.call(el.querySelectorAll('.dnxte-ta-word'));
    }

    var chars = text.split('');
    // Ensure element doesn't stack children vertically
    var compDisplay = getComputedStyle(el).display;
    if (compDisplay === 'flex' || compDisplay === 'inline-flex') {
      el.style.flexWrap = 'wrap';
      el.style.flexDirection = 'row';
    }
    // Group each word's chars inside a nowrap wrapper so that line breaks
    // happen between words, never mid-word. Spaces sit between wrappers and
    // remain valid break points.
    var html   = '';
    var inWord = false;
    chars.forEach(function(c) {
      if (c === ' ') {
        if (inWord) { html += '</span>'; inWord = false; }
        html += '<span class="dnxte-ta-char" style="display:inline-block;white-space:pre;">&nbsp;</span>';
      } else {
        if (!inWord) { html += '<span class="dnxte-ta-word-wrap" style="display:inline-block;white-space:nowrap;">'; inWord = true; }
        html += '<span class="dnxte-ta-char" style="display:inline-block;">' + c + '</span>';
      }
    });
    if (inWord) { html += '</span>'; }
    el.innerHTML = html;
    return Array.prototype.slice.call(el.querySelectorAll('.dnxte-ta-char'));
  };

  /** Create a word-cycling container inside the element. Returns { container, wordEl, setWord }. */
  proto._createWordCycler = function() {
    var words = this.opts.words;
    var el    = this.el;

    // Measure approximate max width so container doesn't jump around.
    var measurer     = document.createElement('span');
    measurer.style.cssText = 'visibility:hidden;position:absolute;white-space:nowrap;';
    var computed = getComputedStyle(el);
    measurer.style.font = computed.font;
    document.body.appendChild(measurer);

    var maxW = 0;
    words.forEach(function(w) {
      measurer.textContent = w;
      var ww = measurer.offsetWidth;
      if (ww > maxW) maxW = ww;
    });
    document.body.removeChild(measurer);

    // Build DOM.
    el.innerHTML = '';
    var container = document.createElement('span');
    container.className = 'dnxte-ta-cycler';
    container.style.cssText = 'display:inline-block;overflow:hidden;vertical-align:bottom;position:relative;min-width:' + maxW + 'px;text-align:center;';

    var wordEl = document.createElement('span');
    wordEl.className = 'dnxte-ta-cycler-word';
    wordEl.style.cssText = 'display:inline-block;';
    wordEl.textContent = words[0] || this._originalText;

    container.appendChild(wordEl);
    el.appendChild(container);

    this._domEls.push(container);

    return {
      container: container,
      wordEl:    wordEl,
      setWord:   function(txt) { wordEl.textContent = txt; },
    };
  };

  /** Store a GSAP tween/timeline for cleanup. */
  proto._addTween = function(t) {
    if (t) this._tweens.push(t);
    return t;
  };

  /** Store an interval ID for cleanup. */
  proto._addInterval = function(id) {
    this._intervals.push(id);
    return id;
  };

  /** Store a timeout ID for cleanup. */
  proto._addTimeout = function(id) {
    this._timeouts.push(id);
    return id;
  };

  /** Store an event listener for cleanup. */
  proto._addListener = function(target, event, fn) {
    target.addEventListener(event, fn);
    this._listeners.push({ target: target, event: event, fn: fn });
  };

  /** Direction offsets helper. */
  proto._dirOffset = function(dist) {
    dist = dist || 30;
    var map = {
      left:  { x: -dist, y: 0 },
      right: { x:  dist, y: 0 },
      up:    { x: 0, y: -dist },
      down:  { x: 0, y:  dist },
    };
    return map[this.opts.direction] || map.left;
  };

  // ---------------------------------------------------------------
  // Router
  // ---------------------------------------------------------------
  proto._init = function() {
    var method = '_init_' + this.opts.type.replace(/-/g, '_');
    if (typeof this[method] === 'function') {
      this[method]();
    }
  };

  // ---------------------------------------------------------------
  // 1. blur
  // ---------------------------------------------------------------
  proto._init_blur = function() {
    var pieces  = this._splitText();
    var off     = this._dirOffset(20);
    var speed   = this.opts.speed;
    var stagger = this.opts.stagger;
    var repeat  = this.opts.repeat;

    this._addTween(
      gsap.fromTo(pieces,
        { opacity: 0, filter: 'blur(10px)', x: off.x, y: off.y },
        {
          opacity:     1,
          filter:      'blur(0px)',
          x:           0,
          y:           0,
          stagger:     stagger,
          duration:    0.5 / speed,
          ease:        'power2.out',
          repeat:      repeat ? -1 : 0,
          yoyo:        true,
          repeatDelay: 0.5,
        }
      )
    );
  };

  // ---------------------------------------------------------------
  // 2. bounce-words
  // ---------------------------------------------------------------
  proto._init_bounce_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;
    var dir   = this.opts.direction;

    if (!words.length) {
      // Static bounce on existing chars.
      var chars = this._splitText();
      chars.forEach(function(c, i) {
        self._addTween(
          gsap.to(c, {
            y:           -20,
            duration:    0.6 / speed,
            ease:        'elastic.out(1,0.4)',
            repeat:      -1,
            yoyo:        true,
            delay:       i * self.opts.stagger,
          })
        );
      });
      return;
    }

    var cyc    = this._createWordCycler();
    var idx    = 0;
    var entryY = (dir === 'up' || dir === 'left') ? 50 : -50;
    var exitY  = -entryY;

    function next() {
      if (self._destroyed) return;
      self._addTween(
        gsap.to(cyc.wordEl, {
          opacity:    0,
          y:          exitY,
          ease:       'back.in(2)',
          duration:   0.4 / speed,
          onComplete: function() {
            idx = (idx + 1) % words.length;
            cyc.setWord(words[idx]);
            gsap.set(cyc.wordEl, { y: entryY, opacity: 0 });
            self._addTween(
              gsap.to(cyc.wordEl, { opacity: 1, y: 0, duration: 0.6 / speed, ease: 'elastic.out(1,0.5)' })
            );
          },
        })
      );
    }

    self._addInterval(setInterval(next, 3000 / speed));
  };

  // ---------------------------------------------------------------
  // 3. bouncy
  // ---------------------------------------------------------------
  proto._init_bouncy = function() {
    var self    = this;
    var chars   = this._splitText();
    var speed   = this.opts.speed;
    var stagger = this.opts.stagger;

    chars.forEach(function(c, i) {
      self._addTween(
        gsap.to(c, {
          y:        -15,
          duration: 0.5 / speed,
          ease:     'sine.inOut',
          repeat:   -1,
          yoyo:     true,
          delay:    i * stagger,
        })
      );
    });
  };

  // ---------------------------------------------------------------
  // 4. fade-words
  // ---------------------------------------------------------------
  proto._init_fade_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;

    if (!words.length) {
      var pieces = this._splitText();
      this._addTween(
        gsap.fromTo(pieces,
          { opacity: 0 },
          { opacity: 1, stagger: this.opts.stagger, duration: 0.5 / speed, repeat: this.opts.repeat ? -1 : 0, yoyo: true, repeatDelay: 0.5 }
        )
      );
      return;
    }

    var cyc = this._createWordCycler();
    var idx = 0;

    function next() {
      if (self._destroyed) return;
      self._addTween(
        gsap.to(cyc.wordEl, {
          opacity:    0,
          duration:   0.5 / speed,
          onComplete: function() {
            idx = (idx + 1) % words.length;
            cyc.setWord(words[idx]);
            self._addTween(
              gsap.to(cyc.wordEl, { opacity: 1, duration: 0.5 / speed })
            );
          },
        })
      );
    }

    self._addInterval(setInterval(next, 2500 / speed));
  };

  // ---------------------------------------------------------------
  // 5. flip-words
  // ---------------------------------------------------------------
  proto._init_flip_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;

    if (!words.length) {
      this._addTween(
        gsap.fromTo(this.el,
          { opacity: 0, rotationX: -90, filter: 'blur(4px)', scale: 0.8 },
          { opacity: 1, rotationX: 0, filter: 'blur(0px)', scale: 1, duration: 0.8 / speed, ease: 'power3.out', repeat: this.opts.repeat ? -1 : 0, yoyo: true, repeatDelay: 1 }
        )
      );
      return;
    }

    var cyc = this._createWordCycler();
    var idx = 0;
    cyc.wordEl.style.transformStyle = 'preserve-3d';

    function next() {
      if (self._destroyed) return;
      self._addTween(
        gsap.to(cyc.wordEl, {
          opacity:    0,
          rotationX:  90,
          filter:     'blur(4px)',
          scale:      0.8,
          y:          -20,
          duration:   0.4 / speed,
          ease:       'power2.in',
          onComplete: function() {
            idx = (idx + 1) % words.length;
            cyc.setWord(words[idx]);
            gsap.set(cyc.wordEl, { rotationX: -90, scale: 0.8, y: 20, opacity: 0, filter: 'blur(4px)' });
            self._addTween(
              gsap.to(cyc.wordEl, { opacity: 1, rotationX: 0, scale: 1, y: 0, filter: 'blur(0px)', duration: 0.6 / speed, ease: 'power3.out' })
            );
          },
        })
      );
    }

    self._addInterval(setInterval(next, 2800 / speed));
  };

  // ---------------------------------------------------------------
  // 6. slide-words
  // ---------------------------------------------------------------
  proto._init_slide_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;
    var dir   = this.opts.direction;

    var entryProp = (dir === 'up' || dir === 'down') ? 'y' : 'x';
    var entryVal  = (dir === 'down' || dir === 'right') ? 60 : -60;

    if (!words.length) {
      var from = {}; from[entryProp] = entryVal; from.opacity = 0;
      var to   = {}; to[entryProp] = 0; to.opacity = 1; to.duration = 0.6 / speed; to.ease = 'power2.out'; to.repeat = this.opts.repeat ? -1 : 0; to.yoyo = true; to.repeatDelay = 1;
      this._addTween(gsap.fromTo(this.el, from, to));
      return;
    }

    var cyc = this._createWordCycler();
    var idx = 0;

    function next() {
      if (self._destroyed) return;
      var exitTo = {};
      exitTo[entryProp] = -entryVal;
      exitTo.opacity    = 0;
      exitTo.duration   = 0.4 / speed;
      exitTo.ease       = 'power2.in';
      exitTo.onComplete = function() {
        idx = (idx + 1) % words.length;
        cyc.setWord(words[idx]);
        var set = {}; set[entryProp] = entryVal; set.opacity = 0;
        gsap.set(cyc.wordEl, set);
        var animTo = {}; animTo[entryProp] = 0; animTo.opacity = 1; animTo.duration = 0.5 / speed; animTo.ease = 'power2.out';
        self._addTween(gsap.to(cyc.wordEl, animTo));
      };
      self._addTween(gsap.to(cyc.wordEl, exitTo));
    }

    self._addInterval(setInterval(next, 2500 / speed));
  };

  // ---------------------------------------------------------------
  // 7. scale-words
  // ---------------------------------------------------------------
  proto._init_scale_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;
    var off   = this._dirOffset(30);

    if (!words.length) {
      this._addTween(
        gsap.fromTo(this.el,
          { opacity: 0, scale: 0.3, x: off.x, y: off.y },
          { opacity: 1, scale: 1, x: 0, y: 0, duration: 0.7 / speed, ease: 'back.out(2)', repeat: this.opts.repeat ? -1 : 0, yoyo: true, repeatDelay: 1 }
        )
      );
      return;
    }

    var cyc = this._createWordCycler();
    var idx = 0;

    function next() {
      if (self._destroyed) return;
      self._addTween(
        gsap.to(cyc.wordEl, {
          opacity:    0,
          scale:      0.3,
          x:          -off.x,
          y:          -off.y,
          duration:   0.35 / speed,
          ease:       'power2.in',
          onComplete: function() {
            idx = (idx + 1) % words.length;
            cyc.setWord(words[idx]);
            gsap.set(cyc.wordEl, { scale: 0.3, x: off.x, y: off.y, opacity: 0 });
            self._addTween(
              gsap.to(cyc.wordEl, { opacity: 1, scale: 1, x: 0, y: 0, duration: 0.6 / speed, ease: 'back.out(2)' })
            );
          },
        })
      );
    }

    self._addInterval(setInterval(next, 2800 / speed));
  };

  // ---------------------------------------------------------------
  // 8. rotate-words
  // ---------------------------------------------------------------
  proto._init_rotate_words = function() {
    var self  = this;
    var words = this.opts.words;
    var speed = this.opts.speed;

    if (!words.length) {
      this._addTween(
        gsap.fromTo(this.el,
          { opacity: 0, rotation: -90, scale: 0.5 },
          { opacity: 1, rotation: 0, scale: 1, duration: 0.8 / speed, ease: 'back.out(2)', repeat: this.opts.repeat ? -1 : 0, yoyo: true, repeatDelay: 1 }
        )
      );
      return;
    }

    var cyc = this._createWordCycler();
    var idx = 0;

    function next() {
      if (self._destroyed) return;
      self._addTween(
        gsap.to(cyc.wordEl, {
          opacity:    0,
          rotation:   90,
          scale:      0.5,
          duration:   0.4 / speed,
          ease:       'power2.in',
          onComplete: function() {
            idx = (idx + 1) % words.length;
            cyc.setWord(words[idx]);
            gsap.set(cyc.wordEl, { rotation: -90, scale: 0.5, opacity: 0 });
            self._addTween(
              gsap.to(cyc.wordEl, { opacity: 1, rotation: 0, scale: 1, duration: 0.6 / speed, ease: 'back.out(2)' })
            );
          },
        })
      );
    }

    self._addInterval(setInterval(next, 2800 / speed));
  };

  // ---------------------------------------------------------------
  // 9. typewriter
  // ---------------------------------------------------------------
  proto._init_typewriter = function() {
    var self   = this;
    var opts   = this.opts;
    var words  = opts.words.length ? opts.words : [this._originalText];
    var el     = this.el;
    var repeat = opts.repeat;

    // User-configurable speeds
    var typSpeed     = opts.typingSpeed;
    var delSpeed     = opts.deletingSpeed;
    var pauseAfter   = opts.pauseDuration;
    var pauseBefore  = 500;
    var useVarSpeed  = opts.variableSpeed;
    var varMin       = opts.varSpeedMin;
    var varMax       = opts.varSpeedMax;
    var cursorChar   = opts.cursorChar || '|';
    var blinkDur     = opts.cursorBlink || 0.5;
    var showCursor   = opts.showCursor !== false;

    // Build DOM
    el.innerHTML = '';
    var textSpan = document.createElement('span');
    textSpan.className = 'dnxte-ta-tw-text';
    textSpan.style.cssText = 'display:inline;';
    el.appendChild(textSpan);
    this._domEls.push(textSpan);

    // Cursor
    if (showCursor) {
      var cursor = document.createElement('span');
      cursor.className = 'dnxte-ta-tw-cursor';
      cursor.textContent = cursorChar;
      cursor.style.cssText = 'display:inline-block;margin-left:2px;font-weight:100;';
      el.appendChild(cursor);
      this._domEls.push(cursor);

      // GSAP smooth cursor blink
      this._addTween(gsap.to(cursor, {
        opacity: 0,
        duration: blinkDur,
        repeat: -1,
        yoyo: true,
        ease: 'power2.inOut'
      }));
    }

    var wordIdx    = 0;
    var charIdx    = 0;
    var isDeleting = false;

    function getSpeed() {
      if (useVarSpeed) {
        // Random between min and max for natural feel
        var base = isDeleting ? delSpeed : typSpeed;
        var min = Math.min(varMin, varMax);
        var max = Math.max(varMin, varMax);
        return min + Math.random() * (max - min);
      }
      return isDeleting ? delSpeed : typSpeed;
    }

    function tick() {
      if (self._destroyed) return;

      var currentWord = words[wordIdx];

      if (!isDeleting) {
        charIdx++;
        textSpan.textContent = currentWord.substring(0, charIdx);

        if (charIdx >= currentWord.length) {
          // Single word, no loop — stop
          if (words.length <= 1 && !repeat) return;
          // Pause then delete
          self._addTimeout(setTimeout(function() {
            isDeleting = true;
            tick();
          }, pauseAfter));
          return;
        }

        self._addTimeout(setTimeout(tick, getSpeed()));
      } else {
        charIdx--;
        textSpan.textContent = currentWord.substring(0, charIdx);

        if (charIdx <= 0) {
          isDeleting = false;
          wordIdx = (wordIdx + 1) % words.length;

          if (!repeat && wordIdx === 0) {
            // No loop — type first word final time
            (function typeFinal() {
              if (self._destroyed) return;
              charIdx++;
              textSpan.textContent = words[0].substring(0, charIdx);
              if (charIdx < words[0].length) {
                self._addTimeout(setTimeout(typeFinal, getSpeed()));
              }
            })();
            return;
          }

          self._addTimeout(setTimeout(tick, pauseBefore));
          return;
        }

        self._addTimeout(setTimeout(tick, getSpeed()));
      }
    }

    // Initial delay
    self._addTimeout(setTimeout(tick, 300));
  };

  // ---------------------------------------------------------------
  // 10. glitch
  // ---------------------------------------------------------------
  proto._init_glitch = function() {
    var self    = this;
    var el      = this.el;
    var speed   = this.opts.speed;
    var variant = this.opts.glitchVariant;
    var color1  = this.opts.color1;
    var color2  = this.opts.color2;

    var shadowSets = {
      classic: [
        '2px 0 ' + color1 + ', -2px 0 ' + color2,
        '-2px 0 ' + color1 + ', 2px 0 ' + color2,
        '2px 2px ' + color1 + ', -2px -2px ' + color2,
        '0 0 transparent',
      ],
      vertical: [
        '0 2px ' + color1 + ', 0 -2px ' + color2,
        '0 -3px ' + color1 + ', 0 3px ' + color2,
        '0 1px ' + color1 + ', 0 -1px ' + color2,
        '0 0 transparent',
      ],
      chaos: [
        '3px -2px ' + color1 + ', -3px 2px ' + color2,
        '-2px 3px ' + color1 + ', 2px -3px ' + color2,
        '4px 1px ' + color1 + ', -4px -1px ' + color2,
        '-1px -4px ' + color1 + ', 1px 4px ' + color2,
        '0 0 transparent',
      ],
      shake: [
        '2px 0 ' + color1 + ', -2px 0 ' + color2,
        '-3px 0 ' + color1 + ', 3px 0 ' + color2,
        '1px 0 ' + color1 + ', -1px 0 ' + color2,
        '0 0 transparent',
      ],
      neon: [
        '0 0 5px ' + color1 + ', 0 0 10px ' + color1 + ', 0 0 20px ' + color2,
        '0 0 2px ' + color1 + ', 0 0 8px ' + color2 + ', 0 0 15px ' + color2,
        '0 0 10px ' + color1 + ', 0 0 5px ' + color2,
        '0 0 5px ' + color1 + ', 0 0 10px ' + color1 + ', 0 0 20px ' + color2,
      ],
      cyberpunk: [
        '3px 0 ' + color1 + ', -3px 0 ' + color2 + ', 0 0 10px ' + color1,
        '-2px 0 ' + color1 + ', 2px 0 ' + color2 + ', 0 0 5px ' + color2,
        '1px 1px ' + color1 + ', -1px -1px ' + color2 + ', 0 0 15px ' + color1,
        '0 0 5px ' + color2,
      ],
      matrix: [
        '0 0 5px #00ff00, 0 0 10px #00ff00',
        '1px 0 #00ff00, -1px 0 #003300',
        '0 0 15px #00ff00, 2px 0 #003300',
        '0 0 5px #00ff00',
      ],
      flicker: [
        '0 0 transparent',
        '2px 0 ' + color1 + ', -2px 0 ' + color2,
        '0 0 transparent',
        '-2px 0 ' + color1 + ', 2px 0 ' + color2,
        '0 0 transparent',
      ],
    };

    var shadows = shadowSets[variant] || shadowSets.classic;

    // Build a timeline for the shadow cycle.
    var tl = gsap.timeline({ repeat: -1 });
    var stepDur = 0.1 / speed;

    shadows.forEach(function(s) {
      tl.to(el, { textShadow: s, duration: stepDur, ease: 'none' });
    });

    this._addTween(tl);

    // Add shake for chaos/shake/cyberpunk variants.
    if (variant === 'chaos' || variant === 'shake' || variant === 'cyberpunk') {
      this._addTween(
        gsap.to(el, {
          x:        function() { return (Math.random() - 0.5) * 6; },
          y:        function() { return (Math.random() - 0.5) * 4; },
          duration: 0.05 / speed,
          repeat:   -1,
          yoyo:     true,
          ease:     'none',
        })
      );
    }

    // Flicker: opacity flicker.
    if (variant === 'flicker') {
      this._addTween(
        gsap.to(el, {
          opacity:  function() { return 0.6 + Math.random() * 0.4; },
          duration: 0.08 / speed,
          repeat:   -1,
          yoyo:     true,
          ease:     'none',
        })
      );
    }
  };

  // ---------------------------------------------------------------
  // 11. wavy
  // ---------------------------------------------------------------
  proto._init_wavy = function() {
    var self    = this;
    var chars   = this._splitText();
    var speed   = this.opts.speed;
    var stagger = this.opts.stagger;

    chars.forEach(function(c, i) {
      self._addTween(
        gsap.to(c, {
          y:        -15,
          duration: 1.5 / speed,
          ease:     'sine.inOut',
          repeat:   -1,
          yoyo:     true,
          delay:    i * stagger,
        })
      );
    });
  };

  // ---------------------------------------------------------------
  // 12. gradient
  // ---------------------------------------------------------------
  proto._init_gradient = function() {
    var el     = this.el;
    var color1 = this.opts.color1;
    var color2 = this.opts.color2;
    var speed  = this.opts.speed;

    el.style.backgroundImage       = 'linear-gradient(90deg, ' + color1 + ', ' + color2 + ', ' + color1 + ')';
    el.style.backgroundSize        = '200% 100%';
    el.style.webkitBackgroundClip  = 'text';
    el.style.webkitTextFillColor   = 'transparent';
    el.style.backgroundClip        = 'text';
    el.style.color                 = 'transparent';

    this._addTween(
      gsap.to(el, {
        backgroundPosition: '200% 50%',
        duration:           3 / speed,
        ease:               'none',
        repeat:             -1,
      })
    );
  };

  // ---------------------------------------------------------------
  // 13. stagger-pop
  // ---------------------------------------------------------------
  proto._init_stagger_pop = function() {
    var chars   = this._splitText();
    var speed   = this.opts.speed;
    var stagger = this.opts.stagger;
    var repeat  = this.opts.repeat;

    this._addTween(
      gsap.fromTo(chars,
        { opacity: 0, scale: 0.5, y: 20 },
        {
          opacity:     1,
          scale:       1,
          y:           0,
          stagger:     stagger,
          duration:    0.3 / speed,
          ease:        'back.out(2)',
          repeat:      repeat ? -1 : 0,
          repeatDelay: 1,
        }
      )
    );
  };

  // ---------------------------------------------------------------
  // 14. focus
  // ---------------------------------------------------------------
  proto._init_focus = function() {
    var self   = this;
    var wordEls = this._splitText('word');
    var speed   = this.opts.speed;

    if (wordEls.length === 0) return;

    // Add bracket indicators around focused word.
    var bracketL = document.createElement('span');
    bracketL.className = 'dnxte-ta-focus-bracket';
    bracketL.textContent = '[';
    bracketL.style.cssText = 'opacity:0;display:inline-block;margin-right:0.15em;transition:opacity 0.3s;';

    var bracketR = document.createElement('span');
    bracketR.className = 'dnxte-ta-focus-bracket';
    bracketR.textContent = ']';
    bracketR.style.cssText = 'opacity:0;display:inline-block;margin-left:0.15em;transition:opacity 0.3s;';

    this.el.insertBefore(bracketL, wordEls[0]);
    this.el.appendChild(bracketR);
    this._domEls.push(bracketL, bracketR);

    var currentIdx = 0;

    function focusWord(idx) {
      if (self._destroyed) return;

      // Blur all words.
      wordEls.forEach(function(w, i) {
        self._addTween(
          gsap.to(w, {
            filter:   i === idx ? 'blur(0px)' : 'blur(3px)',
            opacity:  i === idx ? 1 : 0.4,
            duration: 0.4 / speed,
            ease:     'power2.out',
          })
        );
      });

      // Position brackets around focused word.
      var target = wordEls[idx];
      bracketL.style.opacity = '1';
      bracketR.style.opacity = '1';

      // Move brackets next to focused word.
      self.el.insertBefore(bracketL, target);
      target.parentNode.insertBefore(bracketR, target.nextSibling);
    }

    focusWord(0);

    var focusMode = self.opts.focusMode || 'auto';

    if (focusMode === 'auto' || focusMode === 'both') {
      self._addInterval(setInterval(function() {
        if (self._destroyed) return;
        currentIdx = (currentIdx + 1) % wordEls.length;
        focusWord(currentIdx);
      }, 2000 / speed));
    }

    if (focusMode === 'manual' || focusMode === 'both') {
      wordEls.forEach(function(w, i) {
        self._addListener(w, 'mouseenter', function() {
          currentIdx = i;
          focusWord(i);
        });
        w.style.cursor = 'pointer';
      });
    }
  };

  // ---------------------------------------------------------------
  // 15. scramble
  // ---------------------------------------------------------------
  proto._init_scramble = function() {
    var self         = this;
    var chars        = this._splitText();
    var speed        = this.opts.speed;
    var stagger      = this.opts.stagger;
    var repeat       = this.opts.repeat;
    var scramblePool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    var originalText = this._originalText;

    function scrambleAll() {
      if (self._destroyed) return;

      chars.forEach(function(c, i) {
        var originalChar = originalText[i];
        if (!originalChar || originalChar === ' ') return;

        var iterations   = 0;
        var maxIter      = Math.floor(6 + Math.random() * 6);
        var charDelay    = i * stagger * 1000 / speed;

        self._addTimeout(setTimeout(function() {
          var intv = setInterval(function() {
            if (self._destroyed) { clearInterval(intv); return; }
            iterations++;
            if (iterations >= maxIter) {
              clearInterval(intv);
              c.textContent = originalChar;
            } else {
              c.textContent = scramblePool[Math.floor(Math.random() * scramblePool.length)];
            }
          }, 50 / speed);
          self._intervals.push(intv);
        }, charDelay));
      });
    }

    // Initial scramble: start from random chars.
    chars.forEach(function(c) {
      if (c.textContent.trim()) {
        c.textContent = scramblePool[Math.floor(Math.random() * scramblePool.length)];
      }
    });

    self._addTimeout(setTimeout(function() {
      scrambleAll();
    }, 200));

    if (repeat) {
      var totalDur = (chars.length * stagger * 1000 / speed) + (12 * 50 / speed) + 1500;
      self._addInterval(setInterval(function() {
        // Re-randomize before re-scrambling.
        chars.forEach(function(c) {
          if (c.textContent.trim()) {
            c.textContent = scramblePool[Math.floor(Math.random() * scramblePool.length)];
          }
        });
        self._addTimeout(setTimeout(scrambleAll, 200));
      }, totalDur));
    }
  };

  // ---------------------------------------------------------------
  // 16. split-reveal
  // ---------------------------------------------------------------
  proto._init_split_reveal = function() {
    var el     = this.el;
    var speed  = this.opts.speed;
    var dir    = this.opts.direction;
    var repeat = this.opts.repeat;

    var clips = {
      left:  { from: 'inset(0 100% 0 0)', to: 'inset(0 0% 0 0)' },
      right: { from: 'inset(0 0 0 100%)', to: 'inset(0 0 0 0%)' },
      up:    { from: 'inset(100% 0 0 0)', to: 'inset(0% 0 0 0)' },
      down:  { from: 'inset(0 0 100% 0)', to: 'inset(0 0 0% 0)' },
    };

    var clip = clips[dir] || clips.left;

    this._addTween(
      gsap.fromTo(el,
        { clipPath: clip.from },
        {
          clipPath:    clip.to,
          duration:    1 / speed,
          ease:        'power2.out',
          repeat:      repeat ? -1 : 0,
          yoyo:        true,
          repeatDelay: 1,
        }
      )
    );
  };

  // ---------------------------------------------------------------
  // 17. magnetic
  // ---------------------------------------------------------------
  proto._init_magnetic = function() {
    var self     = this;
    var chars    = this._splitText();
    var maxDist  = 150;

    function onMove(e) {
      if (self._destroyed) return;

      chars.forEach(function(c) {
        var rect   = c.getBoundingClientRect();
        var cx     = rect.left + rect.width / 2;
        var cy     = rect.top + rect.height / 2;
        var dx     = e.clientX - cx;
        var dy     = e.clientY - cy;
        var dist   = Math.sqrt(dx * dx + dy * dy);

        if (dist < maxDist) {
          var force  = 1 - (dist / maxDist);
          var pushX  = -dx * force * 0.4;
          var pushY  = -dy * force * 0.4;

          gsap.to(c, {
            x:        pushX,
            y:        pushY,
            scale:    1 + force * 0.3,
            duration: 0.3,
            ease:     'power2.out',
            overwrite: 'auto',
          });
        } else {
          gsap.to(c, {
            x:        0,
            y:        0,
            scale:    1,
            duration: 0.5,
            ease:     'elastic.out(1,0.4)',
            overwrite: 'auto',
          });
        }
      });
    }

    function onLeave() {
      if (self._destroyed) return;
      chars.forEach(function(c) {
        gsap.to(c, { x: 0, y: 0, scale: 1, duration: 0.6, ease: 'elastic.out(1,0.4)', overwrite: 'auto' });
      });
    }

    // Listen on the parent or document so movement outside the element still resets.
    var target = this.el.parentElement || document;
    this._addListener(target, 'mousemove', onMove);
    this._addListener(target, 'mouseleave', onLeave);
  };

  // ---------------------------------------------------------------
  // 18. particle (floating particles around text)
  // ---------------------------------------------------------------
  proto._init_particle = function() {
    var self   = this;
    var el     = this.el;
    var color1 = this.opts.color1;
    var color2 = this.opts.color2;
    var speed  = this.opts.speed;
    var count  = 40;

    // Make parent relative so particles are absolute inside
    el.style.position = 'relative';
    el.style.overflow = 'visible';

    // Add text glow
    el.style.textShadow = '0 0 20px ' + color1;

    for (var i = 0; i < count; i++) {
      (function(idx) {
        var p = document.createElement('span');
        p.className = 'dnxte-ta-particle';
        var size = 2 + Math.random() * 4;
        var color = Math.random() > 0.5 ? color1 : color2;
        p.style.cssText = 'position:absolute;width:' + size + 'px;height:' + size + 'px;' +
          'border-radius:50%;background:' + color + ';pointer-events:none;opacity:' + (0.3 + Math.random() * 0.7) + ';' +
          'left:' + (Math.random() * 100) + '%;top:' + (Math.random() * 100) + '%;z-index:-1;';
        el.appendChild(p);
        self._domEls.push(p);

        self._addTween(gsap.to(p, {
          x: 'random(-40, 40)',
          y: 'random(-30, 30)',
          opacity: 'random(0.1, 0.8)',
          scale: 'random(0.5, 1.5)',
          duration: (2 + Math.random() * 3) / speed,
          repeat: -1,
          yoyo: true,
          ease: 'sine.inOut',
          delay: idx * 0.05,
        }));
      })(i);
    }
  };

  // ---------------------------------------------------------------
  // 19. resize (selection handles around text)
  // ---------------------------------------------------------------
  proto._init_resize = function() {
    var self  = this;
    var el    = this.el;
    var speed = this.opts.speed;
    var color = this.opts.color1;

    // Wrap text in a bordered box
    el.style.position = 'relative';
    el.style.display = 'inline-block';
    el.style.border = '2px solid ' + color;
    el.style.borderRadius = '6px';
    el.style.padding = '10px 20px';

    // Create 4 corner handles
    var corners = ['top:0;left:0;transform:translate(-50%,-50%)', 'top:0;right:0;transform:translate(50%,-50%)',
                   'bottom:0;left:0;transform:translate(-50%,50%)', 'bottom:0;right:0;transform:translate(50%,50%)'];

    corners.forEach(function(pos, i) {
      var handle = document.createElement('span');
      handle.style.cssText = 'position:absolute;width:10px;height:10px;background:#fff;border:2px solid ' + color +
        ';border-radius:2px;pointer-events:none;z-index:2;' + pos;
      el.appendChild(handle);
      self._domEls.push(handle);

      // Animate handles in
      self._addTween(gsap.from(handle, {
        scale: 0,
        duration: 0.4 / speed,
        delay: i * 0.1,
        ease: 'back.out(2)',
      }));

      // Continuous subtle pulse
      self._addTween(gsap.to(handle, {
        scale: 1.2,
        duration: 1 / speed,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: 0.5 + i * 0.2,
      }));
    });

    // If words provided, cycle text with blur transition
    var words = this.opts.words;
    if (words.length > 1) {
      var idx = 0;
      self._addInterval(setInterval(function() {
        if (self._destroyed) return;
        // Get the text node (first child or all text content)
        var textNode = el.childNodes[0];
        if (!textNode || textNode.nodeType !== 3) {
          // Find first text node
          for (var j = 0; j < el.childNodes.length; j++) {
            if (el.childNodes[j].nodeType === 3 && el.childNodes[j].textContent.trim()) {
              textNode = el.childNodes[j]; break;
            }
          }
        }
        if (!textNode) return;

        self._addTween(gsap.to(el, {
          opacity: 0, filter: 'blur(6px)', duration: 0.3 / speed,
          onComplete: function() {
            idx = (idx + 1) % words.length;
            textNode.textContent = words[idx];
            self._addTween(gsap.to(el, { opacity: 1, filter: 'blur(0px)', duration: 0.3 / speed }));
          }
        }));
      }, 3000 / speed));
    }
  };

  // ---------------------------------------------------------------
  // 20. textured-mask (image/texture clipped to text + scale animation)
  // ---------------------------------------------------------------
  proto._init_textured_mask = function() {
    var self   = this;
    var el     = this.el;
    var speed  = this.opts.speed;
    var color1 = this.opts.color1;
    var imgUrl = this.opts.textureUrl || '';

    // Save original styles
    this._origBgImage = el.style.backgroundImage || '';
    this._origBgClip  = el.style.webkitBackgroundClip || '';
    this._origColor   = el.style.color || '';

    // Apply texture/image as background clipped to text
    if (imgUrl) {
      el.style.backgroundImage = 'url(' + imgUrl + ')';
    } else {
      // Fallback: gradient texture using color1/color2
      el.style.backgroundImage = 'linear-gradient(135deg, ' + color1 + ', ' + this.opts.color2 + ', ' + color1 + ')';
    }
    el.style.backgroundSize = 'cover';
    el.style.backgroundPosition = 'center';
    el.style.webkitBackgroundClip = 'text';
    el.style.webkitTextFillColor = 'transparent';
    el.style.backgroundClip = 'text';
    el.style.color = 'transparent';
    el.style.display = 'inline-block'; // needed for transform

    // Scale animation (Ken Burns style — slow zoom in/out)
    this._addTween(gsap.to(el, {
      scale: 1.15,
      duration: 10 / speed,
      ease: 'linear',
      repeat: -1,
      yoyo: true,
    }));

    // Also animate background position for subtle movement
    this._addTween(gsap.to(el, {
      backgroundPosition: '80% 80%',
      duration: 12 / speed,
      ease: 'sine.inOut',
      repeat: -1,
      yoyo: true,
    }));
  };

  // ---------------------------------------------------------------
  // Destroy
  // ---------------------------------------------------------------
  proto.destroy = function() {
    this._destroyed = true;

    // Kill all GSAP tweens/timelines.
    this._tweens.forEach(function(t) {
      if (t && typeof t.kill === 'function') t.kill();
    });
    this._tweens = [];

    // Clear intervals.
    this._intervals.forEach(function(id) { clearInterval(id); });
    this._intervals = [];

    // Clear timeouts.
    this._timeouts.forEach(function(id) { clearTimeout(id); });
    this._timeouts = [];

    // Cancel rAF.
    if (this._rafId) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }

    // Remove listeners.
    this._listeners.forEach(function(l) {
      l.target.removeEventListener(l.event, l.fn);
    });
    this._listeners = [];

    // Clear created DOM elements ref.
    this._domEls = [];

    // Restore original HTML.
    this.el.innerHTML = this._originalHTML;

    // Clear inline styles GSAP may have set.
    gsap.set(this.el, { clearProps: 'all' });
  };

  // ---------------------------------------------------------------
  // Auto-init on DOMContentLoaded
  // ---------------------------------------------------------------
  function autoInit() {
    var elements = document.querySelectorAll('[data-text-anim]');
    for (var i = 0; i < elements.length; i++) {
      var wrapper = elements[i];
      if (wrapper._dnxteTextAnim) continue;

      // Find the actual text element inside the wrapper
      var textEl = wrapper.querySelector('h1, h2, h3, h4, h5, h6, .et_pb_module_header');
      if (!textEl) textEl = wrapper.querySelector('p, .et_pb_text_inner');
      if (!textEl) textEl = wrapper; // fallback

      // Copy data attributes from wrapper to textEl for parsing
      var attrs = wrapper.attributes;
      for (var j = 0; j < attrs.length; j++) {
        if (attrs[j].name.indexOf('data-text-') === 0 && !textEl.hasAttribute(attrs[j].name)) {
          textEl.setAttribute(attrs[j].name, attrs[j].value);
        }
      }

      wrapper._dnxteTextAnim = new DnxteTextAnimation(textEl, {});
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  // Expose globally.
  global.DnxteTextAnimation = DnxteTextAnimation;

})(window);
