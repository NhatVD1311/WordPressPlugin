/**
 * OrbitingSkills - Frontend Initializer
 * Reads data-* attributes from server-rendered ring elements and builds animated orbiting images.
 * Visual styling (colors, sizes, border-radius) is handled by CSS via advancedStyles.
 * Ring elements are rendered server-side so MultiView can update data-orbit-radius responsively.
 */
(function () {
  "use strict";

  function initOrbitingSkills() {
    var containers = document.querySelectorAll("[data-orbiting-skills]");
    if (!containers.length) return;

    containers.forEach(function (el) {
      if (el._orbitInstance) return;

      var centerImage = el.getAttribute("data-center-image") || "";
      var pauseOnHover = el.getAttribute("data-pause-on-hover") !== "false";
      var showLabels = el.getAttribute("data-show-labels") !== "false";

      // Read ring elements rendered by PHP
      var ringEls = el.querySelectorAll(".orbiting-orbit-path");

      // Wrapper
      var wrapper = document.createElement("div");
      wrapper.className = "orbiting-skills-wrapper";

      // Center element
      var center = document.createElement("div");
      center.className = "orbiting-skills-center";

      var glow = document.createElement("div");
      glow.className = "orbiting-skills-center-glow";
      center.appendChild(glow);

      if (centerImage) {
        var cImg = document.createElement("img");
        cImg.src = centerImage;
        cImg.alt = "center";
        cImg.className = "orbiting-skills-center-image";
        center.appendChild(cImg);
      } else {
        var placeholder = document.createElement("div");
        placeholder.className = "orbiting-skills-center-placeholder";
        placeholder.textContent = "+";
        center.appendChild(placeholder);
      }

      wrapper.appendChild(center);

      // Process each server-rendered ring element
      var skillEls = [];

      ringEls.forEach(function (ringEl) {
        var radius = parseFloat(ringEl.getAttribute("data-orbit-radius") || "120");
        var itemSize = parseFloat(ringEl.getAttribute("data-item-size") || "40");
        var speed = parseFloat(ringEl.getAttribute("data-speed") || "1");
        var ringColor = ringEl.getAttribute("data-ring-color") || "rgba(6, 182, 212, 0.3)";
        var images = [];
        var labels = [];

        try { images = JSON.parse(ringEl.getAttribute("data-images") || "[]"); } catch (e) { images = []; }
        try { labels = JSON.parse(ringEl.getAttribute("data-labels") || "[]"); } catch (e) { labels = []; }

        // Set ring dimensions from data-orbit-radius
        ringEl.style.width = (radius * 2) + "px";
        ringEl.style.height = (radius * 2) + "px";

        // Add glow and border
        var ringGlow = document.createElement("div");
        ringGlow.className = "orbiting-orbit-glow";
        ringGlow.style.background = "radial-gradient(circle, transparent 30%, " + ringColor + " 70%)";
        ringGlow.style.boxShadow = "0 0 60px " + ringColor;
        ringEl.appendChild(ringGlow);

        var ringBorder = document.createElement("div");
        ringBorder.className = "orbiting-orbit-border";
        ringBorder.style.border = "1px solid " + ringColor;
        ringEl.appendChild(ringBorder);

        // Move ring element into wrapper
        wrapper.appendChild(ringEl);

        // Create orbiting items with auto-calculated phase
        var totalImages = images.length || 1;
        var ringItems = [];

        images.forEach(function (imgSrc, index) {
          var phase = (index / totalImages) * Math.PI * 2;
          var label = labels[index] || "";

          var skillEl = document.createElement("div");
          skillEl.className = "orbiting-skill";
          skillEl.style.width = itemSize + "px";
          skillEl.style.height = itemSize + "px";
          skillEl.dataset.orbitRadius = radius;
          skillEl.dataset.speed = speed;
          skillEl.dataset.phase = phase;

          var inner = document.createElement("div");
          inner.className = "orbiting-skill-inner";

          if (imgSrc) {
            var img = document.createElement("img");
            img.src = imgSrc;
            img.alt = label || "";
            inner.appendChild(img);
          } else {
            var ph = document.createElement("div");
            ph.className = "orbiting-skill-placeholder";
            inner.appendChild(ph);
          }

          skillEl.appendChild(inner);

          // Tooltip
          var tooltip = null;
          if (showLabels && label) {
            tooltip = document.createElement("div");
            tooltip.textContent = label;
            tooltip.className = "orbiting-skill-tooltip";
            skillEl.appendChild(tooltip);
          }

          // Hover effects
          skillEl.addEventListener("mouseenter", function () {
            inner.style.transform = "scale(1.25)";
            inner.style.boxShadow = "0 25px 50px -12px rgba(0,0,0,0.25)";
            skillEl.style.zIndex = "20";
            if (tooltip) {
              tooltip.style.opacity = "1";
              tooltip.style.visibility = "visible";
              tooltip.style.transform = "translateX(-50%) translateY(0)";
            }
          });
          skillEl.addEventListener("mouseleave", function () {
            inner.style.transform = "";
            inner.style.boxShadow = "";
            skillEl.style.zIndex = "10";
            if (tooltip) {
              tooltip.style.opacity = "0";
              tooltip.style.visibility = "hidden";
              tooltip.style.transform = "translateX(-50%) translateY(4px)";
            }
          });

          wrapper.appendChild(skillEl);
          skillEls.push(skillEl);
          ringItems.push(skillEl);
        });

        // Watch for responsive data-orbit-radius and data-item-size changes from MultiView
        var observer = new MutationObserver(function (mutations) {
          mutations.forEach(function (m) {
            if (m.attributeName === "data-orbit-radius") {
              var newRadius = parseFloat(ringEl.getAttribute("data-orbit-radius") || "120");
              ringEl.style.width = (newRadius * 2) + "px";
              ringEl.style.height = (newRadius * 2) + "px";
              ringItems.forEach(function (item) {
                item.dataset.orbitRadius = newRadius;
              });
            }
            if (m.attributeName === "data-item-size") {
              var newSize = parseFloat(ringEl.getAttribute("data-item-size") || "40");
              ringItems.forEach(function (item) {
                item.style.width = newSize + "px";
                item.style.height = newSize + "px";
              });
            }
          });
        });
        observer.observe(ringEl, { attributes: true, attributeFilter: ["data-orbit-radius", "data-item-size"] });
      });

      el.appendChild(wrapper);

      // Animation
      var time = 0;
      var lastTime = 0;
      var isPaused = false;

      function animate(currentTime) {
        if (!isPaused) {
          var delta = lastTime ? (currentTime - lastTime) / 1000 : 0;
          time += delta;
          skillEls.forEach(function (sEl) {
            var r = parseFloat(sEl.dataset.orbitRadius);
            var sp = parseFloat(sEl.dataset.speed);
            var ph = parseFloat(sEl.dataset.phase);
            var angle = time * sp + ph;
            var x = Math.cos(angle) * r;
            var y = Math.sin(angle) * r;
            sEl.style.transform = "translate(calc(" + x + "px - 50%), calc(" + y + "px - 50%))";
          });
        }
        lastTime = currentTime;
        requestAnimationFrame(animate);
      }

      requestAnimationFrame(animate);

      if (pauseOnHover) {
        el.addEventListener("mouseenter", function () { isPaused = true; });
        el.addEventListener("mouseleave", function () { isPaused = false; });
      }

      el._orbitInstance = true;
    });
  }

  // Inject keyframes
  if (!document.getElementById("dnxte-orbit-keyframes")) {
    var style = document.createElement("style");
    style.id = "dnxte-orbit-keyframes";
    style.textContent = "@keyframes dnxte-orbit-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }";
    document.head.appendChild(style);
  }

  // Initialize
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initOrbitingSkills);
  } else {
    initOrbitingSkills();
  }
})();
