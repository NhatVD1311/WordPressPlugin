(function(global) {
  'use strict';

  // ─── Utility helpers ───────────────────────────────────────────────
  function hexToRgb(color) {
    if (!color) return { r: 0, g: 0, b: 0 };
    color = color.trim();
    // Handle rgb/rgba strings
    var rgbMatch = color.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (rgbMatch) {
      return { r: parseInt(rgbMatch[1]), g: parseInt(rgbMatch[2]), b: parseInt(rgbMatch[3]) };
    }
    // Handle hex
    var hex = color.replace('#', '');
    if (hex.length === 3) {
      hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
    }
    var r = parseInt(hex.substring(0, 2), 16) || 0;
    var g = parseInt(hex.substring(2, 4), 16) || 0;
    var b = parseInt(hex.substring(4, 6), 16) || 0;
    return { r: r, g: g, b: b };
  }

  function rgbToHex(r, g, b) {
    r = Math.round(Math.max(0, Math.min(255, r)));
    g = Math.round(Math.max(0, Math.min(255, g)));
    b = Math.round(Math.max(0, Math.min(255, b)));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  function lerpColor(c1, c2, t) {
    var a = hexToRgb(c1);
    var b = hexToRgb(c2);
    return rgbToHex(
      a.r + (b.r - a.r) * t,
      a.g + (b.g - a.g) * t,
      a.b + (b.b - a.b) * t
    );
  }

  function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  }

  // ─── Default options ───────────────────────────────────────────────
  var DEFAULTS = {
    type: 'color-shift',
    speed: 1,
    intensity: 1,
    color1: '#00d4aa',
    color2: '#7c3aed',
    color3: '#f472b6',
    color4: '#3b82f6',
    mouseInteractive: false,
    mouseStrength: 1,
    customDirection: 'horizontal',
    customMovement: 'slide',
    customAngle: 135,
    customRange: 100
  };

  // ─── Constructor ───────────────────────────────────────────────────
  function DnxteAnimatedGradient(element, options) {
    if (!element) return;

    this.element = element;
    this._rafId = null;
    this._tweens = [];
    this._listeners = [];
    this._intervals = [];
    this._childElements = [];
    this._overlay = null;
    this._styleEl = null;
    this._destroyed = false;
    this._startTime = Date.now();

    // Parse data attributes
    var data = {
      type: element.getAttribute('data-gradient-type'),
      speed: parseFloat(element.getAttribute('data-gradient-speed')),
      intensity: parseFloat(element.getAttribute('data-gradient-intensity')),
      color1: element.getAttribute('data-gradient-color1'),
      color2: element.getAttribute('data-gradient-color2'),
      color3: element.getAttribute('data-gradient-color3'),
      color4: element.getAttribute('data-gradient-color4'),
      mouseInteractive: element.getAttribute('data-gradient-mouse') === 'true',
      mouseStrength: parseFloat(element.getAttribute('data-gradient-mouse-strength')),
      customDirection: element.getAttribute('data-gradient-custom-dir'),
      customMovement: element.getAttribute('data-gradient-custom-move'),
      customAngle: parseFloat(element.getAttribute('data-gradient-custom-angle')),
      customRange: parseFloat(element.getAttribute('data-gradient-custom-range'))
    };

    // Merge: data attrs > options > defaults
    this.options = {};
    for (var key in DEFAULTS) {
      if (DEFAULTS.hasOwnProperty(key)) {
        var dv = data[key];
        var ov = options && options[key] !== undefined ? options[key] : undefined;
        // data attrs: accept if not null/undefined, and for numbers check NaN
        var dataValid = dv !== null && dv !== undefined && dv !== '' && (typeof dv !== 'number' || !isNaN(dv));
        if (dataValid) {
          this.options[key] = dv;
        } else if (ov !== undefined) {
          this.options[key] = ov;
        } else {
          this.options[key] = DEFAULTS[key];
        }
      }
    }

    this.speed = clamp(this.options.speed, 0.5, 3);
    this.intensity = clamp(this.options.intensity, 0.5, 2);
    this.colors = [this.options.color1, this.options.color2, this.options.color3, this.options.color4];

    // Mouse interactive options
    this.mouseInteractive = this.options.mouseInteractive || false;
    this.mouseStrength = parseFloat(this.options.mouseStrength) || 1;
    this._mouseX = 0.5;
    this._mouseY = 0.5;

    // Custom animation options
    this.customDirection = this.options.customDirection || 'horizontal';
    this.customMovement = this.options.customMovement || 'slide';
    this.customAngle = parseFloat(this.options.customAngle) || 135;
    this.customRange = parseFloat(this.options.customRange) || 100;

    // Save original background
    this.originalBackground = this.element.style.background || '';
    this.originalBackgroundImage = this.element.style.backgroundImage || '';
    this.originalBackgroundSize = this.element.style.backgroundSize || '';
    this.originalBackgroundPosition = this.element.style.backgroundPosition || '';
    this.originalBoxShadow = this.element.style.boxShadow || '';
    this.originalPosition = getComputedStyle(this.element).position;

    // Ensure relative positioning
    if (this.originalPosition === 'static') {
      this.element.style.position = 'relative';
    }

    // Setup mouse tracking if interactive
    if (this.mouseInteractive) {
      this._setupMouseInteractive();
    }

    // Initialize the selected effect
    this._initEffect();
  }

  // ─── Core methods ──────────────────────────────────────────────────

  DnxteAnimatedGradient.prototype._initEffect = function() {
    var methodMap = {
      'color-shift':      '_initColorShift',
      'flowing-wave':     '_initFlowingWave',
      'radial-pulse':     '_initRadialPulse',
      'aurora':           '_initAurora',
      'mesh':             '_initMesh',
      'sunset':           '_initSunset',
      'neon-pulse':       '_initNeonPulse',
      'liquid-metal':     '_initLiquidMetal',
      'rotating-conic':   '_initRotatingConic',
      'ocean-waves':      '_initOceanWaves',
      'fire':             '_initFire',
      'holographic':      '_initHolographic',
      'mouse-follow':     '_initMouseFollow',
      'stripe-wave':      '_initStripeWave',
      'galaxy-swirl':     '_initGalaxySwirl',
      'plasma':           '_initPlasma',
      'gradient-border':  '_initGradientBorder',
      'noise-grain':      '_initNoiseGrain',
      'scroll-reactive':  '_initScrollReactive',
      'morphing-blobs':   '_initMorphingBlobs',
      'custom':           '_initCustom'
    };

    var method = methodMap[this.options.type];
    if (method && typeof this[method] === 'function') {
      this[method]();
    }
  };

  // Set background with !important to override Divi's generated CSS
  DnxteAnimatedGradient.prototype._setBg = function(value) {
    this.element.style.setProperty('background', value, 'important');
  };
  DnxteAnimatedGradient.prototype._setBgProp = function(prop, value) {
    this.element.style.setProperty(prop, value, 'important');
  };

  DnxteAnimatedGradient.prototype._createOverlay = function() {
    if (this._overlay) return this._overlay;
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:1;overflow:hidden;';
    overlay.className = 'dnxte-gradient-overlay';
    this.element.appendChild(overlay);
    this._overlay = overlay;
    this._childElements.push(overlay);
    return overlay;
  };

  DnxteAnimatedGradient.prototype._startRAF = function(callback) {
    var self = this;
    function loop() {
      if (self._destroyed) return;
      callback();
      self._rafId = requestAnimationFrame(loop);
    }
    self._rafId = requestAnimationFrame(loop);
  };

  DnxteAnimatedGradient.prototype._addListener = function(target, event, handler) {
    target.addEventListener(event, handler);
    this._listeners.push({ target: target, event: event, handler: handler });
  };

  DnxteAnimatedGradient.prototype._gsapTo = function(target, vars) {
    if (typeof gsap !== 'undefined') {
      var tween = gsap.to(target, vars);
      this._tweens.push(tween);
      return tween;
    }
    return null;
  };

  // ─── 1. Color Shift ───────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initColorShift = function() {
    var self = this;
    var colors = this.colors.slice();
    var duration = 3 / this.speed;

    if (typeof gsap === 'undefined') {
      // Fallback: simple rAF transition
      this._startRAF(function() {
        var t = ((Date.now() - self._startTime) / 1000) * self.speed;
        var i = Math.floor(t) % 4;
        var next = (i + 1) % 4;
        var frac = t % 1;
        var c1 = lerpColor(colors[i], colors[next], frac);
        var c2 = lerpColor(colors[(i + 2) % 4], colors[(i + 3) % 4], frac);
        self._setBg('linear-gradient(135deg, ' + c1 + ', ' + c2 + ')');
      });
      return;
    }

    var proxy = { r1: 0, g1: 0, b1: 0, r2: 0, g2: 0, b2: 0 };
    var stages = [];
    for (var i = 0; i < 4; i++) {
      var c1 = hexToRgb(colors[i]);
      var c2 = hexToRgb(colors[(i + 2) % 4]);
      stages.push({ r1: c1.r, g1: c1.g, b1: c1.b, r2: c2.r, g2: c2.g, b2: c2.b });
    }

    proxy.r1 = stages[0].r1; proxy.g1 = stages[0].g1; proxy.b1 = stages[0].b1;
    proxy.r2 = stages[0].r2; proxy.g2 = stages[0].g2; proxy.b2 = stages[0].b2;

    var currentStage = 0;
    function animateNext() {
      if (self._destroyed) return;
      var nextStage = (currentStage + 1) % 4;
      self._gsapTo(proxy, {
        duration: duration,
        r1: stages[nextStage].r1, g1: stages[nextStage].g1, b1: stages[nextStage].b1,
        r2: stages[nextStage].r2, g2: stages[nextStage].g2, b2: stages[nextStage].b2,
        ease: 'sine.inOut',
        onUpdate: function() {
          var hex1 = rgbToHex(proxy.r1, proxy.g1, proxy.b1);
          var hex2 = rgbToHex(proxy.r2, proxy.g2, proxy.b2);
          self._setBg('linear-gradient(135deg, ' + hex1 + ', ' + hex2 + ')');
        },
        onComplete: function() {
          currentStage = nextStage;
          animateNext();
        }
      });
    }
    animateNext();
  };

  // ─── 2. Flowing Wave ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initFlowingWave = function() {
    var self = this;
    var colors = this.colors;
    this.element.style.backgroundSize = '400% 400%';
    this.element.style.background = 'linear-gradient(135deg, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ')';

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 0.5;
      var angle = (t * 30) % 360;
      var x = 50 + Math.sin(t) * 25 * self.intensity;
      var y = 50 + Math.cos(t * 0.7) * 25 * self.intensity;
      self._setBg('linear-gradient(' + angle + 'deg, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ')');
      self._setBgProp('background-size', '400% 400%');
      self._setBgProp('background-position', x + '% ' + y + '%');
    });
  };

  // ─── 3. Radial Pulse ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initRadialPulse = function() {
    var self = this;
    var colors = this.colors;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed;
      var size = 20 + (Math.sin(t * 1.5) + 1) * 30 * self.intensity;
      self._setBg('radial-gradient(circle ' + size + '% at 50% 50%, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ')');
    });
  };

  // ─── 4. Aurora ─────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initAurora = function() {
    var overlay = this._createOverlay();
    var colors = this.colors;
    var intensity = this.intensity;
    var speed = this.speed;

    for (var i = 0; i < 3; i++) {
      var div = document.createElement('div');
      var c1 = colors[i % 4];
      var c2 = colors[(i + 1) % 4];
      div.style.cssText = 'position:absolute;width:100%;height:60%;left:0;' +
        'background:linear-gradient(180deg, ' + c1 + ', ' + c2 + ');' +
        'filter:blur(' + (40 * intensity) + 'px);' +
        'opacity:' + (0.4 * intensity) + ';' +
        'top:' + (i * 20) + '%;' +
        'transform-origin:center center;';
      overlay.appendChild(div);
      this._childElements.push(div);

      this._gsapTo(div, {
        duration: (4 + i * 1.5) / speed,
        x: (i % 2 === 0 ? 1 : -1) * 80 * intensity,
        scaleY: 1.3 + (0.3 * intensity),
        opacity: 0.2 * intensity,
        yoyo: true,
        repeat: -1,
        ease: 'sine.inOut',
        delay: i * 0.5
      });
    }
  };

  // ─── 5. Mesh ───────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initMesh = function() {
    var overlay = this._createOverlay();
    var colors = this.colors;
    var intensity = this.intensity;
    var speed = this.speed;
    var positions = [
      { x: '10%', y: '10%' },
      { x: '70%', y: '20%' },
      { x: '30%', y: '60%' },
      { x: '80%', y: '70%' }
    ];

    for (var i = 0; i < 4; i++) {
      var div = document.createElement('div');
      var size = 50 + i * 10;
      div.style.cssText = 'position:absolute;width:' + size + '%;height:' + size + '%;' +
        'border-radius:50%;' +
        'background:' + colors[i] + ';' +
        'filter:blur(' + (60 * intensity) + 'px);' +
        'opacity:' + (0.5 * intensity) + ';' +
        'left:' + positions[i].x + ';top:' + positions[i].y + ';' +
        'transform:translate(-50%,-50%);';
      overlay.appendChild(div);
      this._childElements.push(div);

      this._gsapTo(div, {
        duration: (5 + i) / speed,
        x: (Math.random() - 0.5) * 200 * intensity,
        y: (Math.random() - 0.5) * 200 * intensity,
        scale: 0.8 + Math.random() * 0.6,
        yoyo: true,
        repeat: -1,
        ease: 'sine.inOut',
        delay: i * 0.7
      });
    }
  };

  // ─── 6. Sunset ─────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initSunset = function() {
    var self = this;
    var speed = this.speed;
    var stages = [
      'linear-gradient(180deg, #ff6b35, #f7c948, #ff8c42)',
      'linear-gradient(180deg, #e8451e, #f0a500, #ff6f61)',
      'linear-gradient(180deg, #c2185b, #7b1fa2, #283593)',
      'linear-gradient(180deg, #1a237e, #0d47a1, #01579b)',
      'linear-gradient(180deg, #ff8f00, #ff6d00, #d84315)'
    ];
    var currentStage = 0;

    if (typeof gsap === 'undefined') {
      // Fallback: cycle via CSS transition
      this.element.style.transition = 'background ' + (2 / speed) + 's ease-in-out';
      var interval = setInterval(function() {
        if (self._destroyed) return;
        currentStage = (currentStage + 1) % stages.length;
        self._setBg(stages[currentStage]);
      }, (2500 / speed));
      this._intervals.push(interval);
      self._setBg(stages[0]);
      return;
    }

    function cycleStage() {
      if (self._destroyed) return;
      var nextStage = (currentStage + 1) % stages.length;
      self._gsapTo(self.element, {
        duration: 2.5 / speed,
        background: stages[nextStage],
        ease: 'sine.inOut',
        onComplete: function() {
          currentStage = nextStage;
          cycleStage();
        }
      });
    }
    self._setBg(stages[0]);
    cycleStage();
  };

  // ─── 7. Neon Pulse ─────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initNeonPulse = function() {
    var self = this;
    var c1 = this.colors[0];
    var c2 = this.colors[1];
    var intensity = this.intensity;
    var speed = this.speed;
    var spread = 20 * intensity;

    if (typeof gsap === 'undefined') {
      this._startRAF(function() {
        var t = ((Date.now() - self._startTime) / 1000) * speed;
        var pulse = (Math.sin(t * 2) + 1) / 2;
        var s = spread * pulse;
        self.element.style.boxShadow = 'inset 0 0 ' + s + 'px ' + c1 + ', inset 0 0 ' + (s * 2) + 'px ' + c2;
      });
      return;
    }

    var proxy = { glow: 0 };
    this._gsapTo(proxy, {
      duration: 1.2 / speed,
      glow: 1,
      yoyo: true,
      repeat: -1,
      ease: 'sine.inOut',
      onUpdate: function() {
        var s = spread * proxy.glow;
        self.element.style.boxShadow = 'inset 0 0 ' + s + 'px ' + c1 + ', inset 0 0 ' + (s * 2) + 'px ' + c2;
      }
    });
  };

  // ─── 8. Liquid Metal ───────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initLiquidMetal = function() {
    var self = this;
    var intensity = this.intensity;
    var colors = this.colors;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 0.6;
      var x1 = 50 + Math.sin(t * 1.1) * 30 * intensity;
      var y1 = 50 + Math.cos(t * 0.9) * 30 * intensity;
      var x2 = 50 + Math.sin(t * 0.8 + 2) * 30 * intensity;
      var y2 = 50 + Math.cos(t * 1.2 + 1) * 30 * intensity;
      var x3 = 50 + Math.sin(t * 1.3 + 4) * 25 * intensity;
      var y3 = 50 + Math.cos(t * 0.7 + 3) * 25 * intensity;
      self._setBg(
        'radial-gradient(circle at ' + x1 + '% ' + y1 + '%, ' + colors[0] + ' 0%, transparent 50%), ' +
        'radial-gradient(circle at ' + x2 + '% ' + y2 + '%, ' + colors[1] + ' 0%, transparent 50%), ' +
        'radial-gradient(circle at ' + x3 + '% ' + y3 + '%, ' + colors[2] + ' 0%, transparent 50%), ' +
        colors[3]);
    });
  };

  // ─── 9. Rotating Conic ─────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initRotatingConic = function() {
    var self = this;
    var colors = this.colors;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 40;
      var angle = t % 360;
      self._setBg('conic-gradient(from ' + angle + 'deg at 50% 50%, ' +
        colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ', ' + colors[0] + ')');
    });
  };

  // ─── 10. Ocean Waves ───────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initOceanWaves = function() {
    var self = this;
    var intensity = this.intensity;
    var colors = this.colors;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 0.8;
      var s1 = 10 + Math.sin(t * 1.2) * 10 * intensity;
      var s2 = 30 + Math.sin(t * 0.8 + 1) * 10 * intensity;
      var s3 = 55 + Math.sin(t * 1.0 + 2) * 10 * intensity;
      var s4 = 80 + Math.sin(t * 0.6 + 3) * 8 * intensity;
      self._setBg('linear-gradient(180deg, ' +
        colors[0] + ' ' + s1 + '%, ' +
        colors[1] + ' ' + s2 + '%, ' +
        colors[2] + ' ' + s3 + '%, ' +
        colors[3] + ' ' + s4 + '%)');
    });
  };

  // ─── 11. Fire ──────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initFire = function() {
    var self = this;
    var intensity = this.intensity;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed;
      var flicker1 = 20 + Math.sin(t * 3) * 10 * intensity + (Math.random() * 5 * intensity);
      var flicker2 = 50 + Math.sin(t * 2.5 + 1) * 15 * intensity + (Math.random() * 8 * intensity);
      var flicker3 = 80 + Math.sin(t * 2 + 2) * 10 * intensity + (Math.random() * 4 * intensity);
      var cx = 50 + Math.sin(t * 1.5) * 5 * intensity;
      self._setBg('radial-gradient(ellipse at ' + cx + '% 100%, ' +
        '#fff7a0 ' + (flicker1 * 0.3) + '%, ' +
        '#ffcc33 ' + flicker1 + '%, ' +
        '#ff6600 ' + flicker2 + '%, ' +
        '#cc2200 ' + flicker3 + '%, ' +
        '#1a0000 100%)');
    });
  };

  // ─── 12. Holographic ───────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initHolographic = function() {
    var self = this;
    var intensity = this.intensity;
    var colors = this.colors;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 25;
      var angle = t % 360;
      var rainbowOpacity = 0.3 * intensity;
      self._setBg(
        'linear-gradient(' + angle + 'deg, ' +
        'rgba(255,0,0,' + rainbowOpacity + '), ' +
        'rgba(255,165,0,' + rainbowOpacity + '), ' +
        'rgba(255,255,0,' + rainbowOpacity + '), ' +
        'rgba(0,255,0,' + rainbowOpacity + '), ' +
        'rgba(0,0,255,' + rainbowOpacity + '), ' +
        'rgba(75,0,130,' + rainbowOpacity + '), ' +
        'rgba(238,130,238,' + rainbowOpacity + ')), ' +
        'linear-gradient(' + (angle + 60) + 'deg, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ')');
    });
  };

  // ─── 13. Mouse Follow ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initMouseFollow = function() {
    var self = this;
    var mx = 50;
    var my = 50;
    var currentX = 50;
    var currentY = 50;
    var colors = this.colors;
    var intensity = this.intensity;

    this._addListener(this.element, 'mousemove', function(e) {
      var rect = self.element.getBoundingClientRect();
      mx = ((e.clientX - rect.left) / rect.width) * 100;
      my = ((e.clientY - rect.top) / rect.height) * 100;
    });

    this._addListener(this.element, 'mouseleave', function() {
      mx = 50;
      my = 50;
    });

    this._startRAF(function() {
      // Smooth lerp towards mouse position
      currentX += (mx - currentX) * 0.08 * self.speed;
      currentY += (my - currentY) * 0.08 * self.speed;
      var size = 30 + 20 * intensity;
      self._setBg('radial-gradient(circle ' + size + '% at ' + currentX + '% ' + currentY + '%, ' +
        colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ')');
    });
  };

  // ─── 14. Stripe Wave ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initStripeWave = function() {
    var self = this;
    var colors = this.colors;
    var intensity = this.intensity;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed;
      var angle = (t * 20) % 360;
      var offset = (t * 60 * intensity) % 200;
      self._setBg('repeating-linear-gradient(' + angle + 'deg, ' +
        colors[0] + ' 0px, ' +
        colors[1] + ' ' + (20 * intensity) + 'px, ' +
        colors[2] + ' ' + (40 * intensity) + 'px, ' +
        colors[3] + ' ' + (60 * intensity) + 'px, ' +
        colors[0] + ' ' + (80 * intensity) + 'px)');
      self._setBgProp('background-size', '200% 200%');
      self._setBgProp('background-position', offset + 'px ' + offset + 'px');
    });
  };

  // ─── 15. Galaxy Swirl ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initGalaxySwirl = function() {
    var overlay = this._createOverlay();
    var colors = this.colors;
    var intensity = this.intensity;
    var speed = this.speed;

    var swirl = document.createElement('div');
    var size = 140 * intensity;
    swirl.style.cssText = 'position:absolute;width:' + size + '%;height:' + size + '%;' +
      'left:50%;top:50%;transform:translate(-50%,-50%);' +
      'border-radius:50%;' +
      'background:conic-gradient(from 0deg, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ', ' + colors[0] + ');' +
      'filter:blur(' + (30 * intensity) + 'px);' +
      'opacity:' + (0.6 * intensity) + ';';
    overlay.appendChild(swirl);
    this._childElements.push(swirl);

    this._gsapTo(swirl, {
      duration: 8 / speed,
      rotation: 360,
      repeat: -1,
      ease: 'none'
    });
  };

  // ─── 16. Plasma ────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initPlasma = function() {
    var self = this;
    var colors = this.colors;
    var intensity = this.intensity;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed * 0.5;
      var x1 = 50 + Math.sin(t * 1.3) * 35 * intensity;
      var y1 = 50 + Math.cos(t * 0.9) * 35 * intensity;
      var x2 = 50 + Math.sin(t * 0.7 + 2.1) * 35 * intensity;
      var y2 = 50 + Math.cos(t * 1.1 + 1.5) * 35 * intensity;
      var x3 = 50 + Math.sin(t * 1.0 + 4.2) * 30 * intensity;
      var y3 = 50 + Math.cos(t * 0.8 + 3.0) * 30 * intensity;
      self._setBg(
        'radial-gradient(circle at ' + x1 + '% ' + y1 + '%, ' + colors[0] + ', transparent 50%), ' +
        'radial-gradient(circle at ' + x2 + '% ' + y2 + '%, ' + colors[1] + ', transparent 50%), ' +
        'radial-gradient(circle at ' + x3 + '% ' + y3 + '%, ' + colors[2] + ', transparent 50%), ' +
        'linear-gradient(135deg, ' + colors[3] + ', ' + colors[0] + ')');
    });
  };

  // ─── 17. Gradient Border ───────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initGradientBorder = function() {
    var colors = this.colors;
    var intensity = this.intensity;
    var speed = this.speed;
    var borderWidth = Math.round(3 * intensity);
    var id = 'dnxte-gradient-border-' + Math.random().toString(36).substr(2, 9);

    this.element.classList.add(id);

    var style = document.createElement('style');
    style.textContent =
      '@keyframes dnxteGradientBorderAnim {' +
        '0% { background-position: 0% 50%; }' +
        '50% { background-position: 100% 50%; }' +
        '100% { background-position: 0% 50%; }' +
      '}' +
      '.' + id + '::before {' +
        'content: "";' +
        'position: absolute;' +
        'inset: 0;' +
        'padding: ' + borderWidth + 'px;' +
        'border-radius: inherit;' +
        'background: linear-gradient(90deg, ' + colors[0] + ', ' + colors[1] + ', ' + colors[2] + ', ' + colors[3] + ', ' + colors[0] + ');' +
        'background-size: 300% 300%;' +
        'animation: dnxteGradientBorderAnim ' + (3 / speed) + 's ease infinite;' +
        '-webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);' +
        '-webkit-mask-composite: xor;' +
        'mask-composite: exclude;' +
        'pointer-events: none;' +
        'z-index: 1;' +
      '}';
    document.head.appendChild(style);
    this._styleEl = style;
    this._gradientBorderClass = id;
  };

  // ─── 18. Noise Grain ──────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initNoiseGrain = function() {
    var overlay = this._createOverlay();
    var intensity = this.intensity;

    var canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;opacity:' + (0.08 * intensity) + ';pointer-events:none;mix-blend-mode:overlay;';
    overlay.appendChild(canvas);
    this._childElements.push(canvas);

    var ctx = canvas.getContext('2d');
    var w = 256;
    var h = 256;
    canvas.width = w;
    canvas.height = h;

    var self = this;
    this._startRAF(function() {
      var imageData = ctx.createImageData(w, h);
      var data = imageData.data;
      for (var i = 0, len = data.length; i < len; i += 4) {
        var v = Math.random() * 255;
        data[i] = v;
        data[i + 1] = v;
        data[i + 2] = v;
        data[i + 3] = 255;
      }
      ctx.putImageData(imageData, 0, 0);
    });
  };

  // ─── 19. Scroll Reactive ───────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initScrollReactive = function() {
    var self = this;
    var colors = this.colors;

    // Try GSAP ScrollTrigger first
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      gsap.registerPlugin(ScrollTrigger);
      var proxy = { progress: 0 };
      var st = ScrollTrigger.create({
        trigger: this.element,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
        onUpdate: function(s) {
          proxy.progress = s.progress;
          self._applyScrollGradient(proxy.progress);
        }
      });
      this._tweens.push(st);
      return;
    }

    // Fallback: manual scroll listener
    function onScroll() {
      if (self._destroyed) return;
      var rect = self.element.getBoundingClientRect();
      var viewH = window.innerHeight;
      var progress = clamp((viewH - rect.top) / (viewH + rect.height), 0, 1);
      self._applyScrollGradient(progress);
    }

    this._addListener(window, 'scroll', onScroll);
    this._addListener(window, 'resize', onScroll);
    onScroll();
  };

  DnxteAnimatedGradient.prototype._applyScrollGradient = function(progress) {
    var colors = this.colors;
    var c1, c2;
    if (progress < 0.33) {
      var t = progress / 0.33;
      c1 = lerpColor(colors[0], colors[1], t);
      c2 = lerpColor(colors[1], colors[2], t);
    } else if (progress < 0.66) {
      var t = (progress - 0.33) / 0.33;
      c1 = lerpColor(colors[1], colors[2], t);
      c2 = lerpColor(colors[2], colors[3], t);
    } else {
      var t = (progress - 0.66) / 0.34;
      c1 = lerpColor(colors[2], colors[3], t);
      c2 = lerpColor(colors[3], colors[0], t);
    }
    var angle = 135 + progress * 90;
    this.element.style.background = 'linear-gradient(' + angle + 'deg, ' + c1 + ', ' + c2 + ')';
  };

  // ─── 20. Morphing Blobs ────────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initMorphingBlobs = function() {
    var overlay = this._createOverlay();
    var colors = this.colors;
    var intensity = this.intensity;
    var speed = this.speed;

    for (var i = 0; i < 2; i++) {
      var blob = document.createElement('div');
      var c1 = colors[i * 2];
      var c2 = colors[i * 2 + 1];
      var size = 50 + i * 15;
      blob.style.cssText = 'position:absolute;width:' + size + '%;height:' + size + '%;' +
        'background:linear-gradient(135deg, ' + c1 + ', ' + c2 + ');' +
        'filter:blur(' + (40 * intensity) + 'px);' +
        'opacity:' + (0.6 * intensity) + ';' +
        'border-radius:40% 60% 60% 40% / 60% 30% 70% 40%;' +
        'left:' + (i === 0 ? '20%' : '50%') + ';top:' + (i === 0 ? '15%' : '40%') + ';';
      overlay.appendChild(blob);
      this._childElements.push(blob);

      // Animate position and morph borderRadius
      this._gsapTo(blob, {
        duration: (6 + i * 2) / speed,
        x: (i === 0 ? 100 : -80) * intensity,
        y: (i === 0 ? 60 : -50) * intensity,
        borderRadius: '60% 40% 30% 70% / 40% 60% 70% 30%',
        yoyo: true,
        repeat: -1,
        ease: 'sine.inOut'
      });

      // Second tween for scale
      this._gsapTo(blob, {
        duration: (4 + i) / speed,
        scale: 1.2 + 0.2 * intensity,
        yoyo: true,
        repeat: -1,
        ease: 'sine.inOut',
        delay: 0.5
      });
    }
  };

  // ─── 21. Custom Animation ───────────────────────────────────────────
  DnxteAnimatedGradient.prototype._initCustom = function() {
    var self = this;
    var colors = this.colors;
    var dir = this.customDirection;
    var movement = this.customMovement;
    var startAngle = this.customAngle;
    var range = this.customRange;

    this._startRAF(function() {
      var t = ((Date.now() - self._startTime) / 1000) * self.speed;

      // Build gradient type based on direction
      var gradType, prefix;
      if (dir === 'radial') {
        gradType = 'radial-gradient';
        prefix = 'circle at 50% 50%';
      } else if (dir === 'conic') {
        gradType = 'conic-gradient';
        prefix = 'from ' + ((startAngle + t * 40) % 360) + 'deg at 50% 50%';
      } else {
        gradType = 'linear-gradient';
        var angle = startAngle;
        if (movement === 'rotate') angle = (startAngle + t * 30) % 360;
        prefix = angle + 'deg';
      }

      // Build color stops
      var stops = colors.join(', ');

      // Apply movement
      switch (movement) {
        case 'shift':
          // Interpolate colors over time
          var shift = (t * 0.5) % 1;
          var shifted = [];
          for (var i = 0; i < 4; i++) {
            var idx = (i + Math.floor(t)) % 4;
            shifted.push(colors[idx]);
          }
          stops = shifted.join(', ');
          self._setBg(gradType + '(' + prefix + ', ' + stops + ')');
          break;

        case 'slide':
          self._setBg(gradType + '(' + prefix + ', ' + stops + ')');
          var pos = (Math.sin(t * 0.8) * range * 0.5 * self.intensity) + 50;
          var posDir = dir === 'vertical' ? '50% ' + pos + '%' : pos + '% 50%';
          self._setBgProp('background-size', (range * 2) + '% ' + (range * 2) + '%');
          self._setBgProp('background-position', posDir);
          break;

        case 'rotate':
          self._setBg(gradType + '(' + prefix + ', ' + stops + ')');
          break;

        case 'pulse':
          var pulseSize = 50 + Math.sin(t * 1.5) * range * 0.3 * self.intensity;
          if (dir === 'radial') {
            self._setBg('radial-gradient(circle ' + pulseSize + '% at 50% 50%, ' + stops + ')');
          } else {
            self._setBg(gradType + '(' + prefix + ', ' + stops + ')');
            self._setBgProp('background-size', pulseSize * 2 + '% ' + pulseSize * 2 + '%');
            self._setBgProp('background-position', '50% 50%');
          }
          break;

        case 'breathe':
          var scale = 100 + Math.sin(t * 1.2) * range * 0.5 * self.intensity;
          self._setBg(gradType + '(' + prefix + ', ' + stops + ')');
          self._setBgProp('background-size', scale + '% ' + scale + '%');
          self._setBgProp('background-position', '50% 50%');
          break;
      }
    });
  };

  // ─── Mouse Interactive Layer ─────────────────────────────────────
  // Creates a visible radial glow that follows cursor + shifts the
  // main gradient angle/position based on mouse location.
  DnxteAnimatedGradient.prototype._setupMouseInteractive = function() {
    var self = this;
    var str = this.mouseStrength;
    var colors = this.colors;

    // Create overlay with 2 layers: glow + wave distortion
    var overlay = this._createOverlay();

    // Glow layer — bright radial that follows cursor
    var glow = document.createElement('div');
    glow.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:2;opacity:0;transition:opacity 0.4s;mix-blend-mode:screen;';
    overlay.appendChild(glow);
    this._childElements.push(glow);

    // Wave layer — subtle color wave ripple
    var wave = document.createElement('div');
    wave.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:3;opacity:0;transition:opacity 0.4s;';
    overlay.appendChild(wave);
    this._childElements.push(wave);

    var mx = 0.5, my = 0.5;    // raw mouse (0-1)
    var cx = 0.5, cy = 0.5;    // smoothed cursor
    var prevCx = 0.5, prevCy = 0.5;
    var hovering = false;

    this._addListener(this.element, 'mouseenter', function() {
      hovering = true;
      glow.style.opacity = '1';
      wave.style.opacity = '1';
    });
    this._addListener(this.element, 'mouseleave', function() {
      hovering = false;
      glow.style.opacity = '0';
      wave.style.opacity = '0';
    });
    this._addListener(this.element, 'mousemove', function(e) {
      var rect = self.element.getBoundingClientRect();
      mx = (e.clientX - rect.left) / rect.width;
      my = (e.clientY - rect.top) / rect.height;
    });

    var raf;
    function render() {
      if (self._destroyed) return;

      prevCx = cx; prevCy = cy;
      cx += (mx - cx) * 0.06 * str;
      cy += (my - cy) * 0.06 * str;

      // Mouse velocity for wave intensity
      var vx = cx - prevCx;
      var vy = cy - prevCy;
      var vel = Math.sqrt(vx * vx + vy * vy) * 100;
      var waveOpacity = Math.min(vel * str * 2, 0.6);

      var px = (cx * 100).toFixed(1);
      var py = (cy * 100).toFixed(1);

      // ── Glow: bright radial spotlight following cursor ──
      var glowSize = 25 + 15 * str;
      glow.style.background =
        'radial-gradient(circle ' + glowSize + '% at ' + px + '% ' + py + '%, ' +
        colors[0] + '55, ' +
        colors[1] + '30, ' +
        'transparent 70%)';

      // ── Wave: concentric ripple from cursor position ──
      var t = Date.now() * 0.003 * str;
      var r1 = 15 + Math.sin(t) * 8;
      var r2 = 30 + Math.sin(t + 1) * 10;
      var r3 = 50 + Math.sin(t + 2) * 12;
      wave.style.background =
        'radial-gradient(circle at ' + px + '% ' + py + '%, ' +
        colors[0] + (Math.round(waveOpacity * 80)).toString(16).padStart(2, '0') + ' ' + r1 + '%, ' +
        'transparent ' + r2 + '%, ' +
        colors[1] + (Math.round(waveOpacity * 40)).toString(16).padStart(2, '0') + ' ' + r3 + '%, ' +
        'transparent 70%)';

      // ── Influence main element: shift background-position based on mouse ──
      if (hovering) {
        var shiftX = (cx - 0.5) * 30 * str;
        var shiftY = (cy - 0.5) * 30 * str;
        self.element.style.setProperty('background-position',
          'calc(50% + ' + shiftX.toFixed(1) + 'px) calc(50% + ' + shiftY.toFixed(1) + 'px)', 'important');
      }

      raf = requestAnimationFrame(render);
    }
    raf = requestAnimationFrame(render);
    this._mouseRaf = raf;
  };

  // ─── Destroy ───────────────────────────────────────────────────────
  DnxteAnimatedGradient.prototype.destroy = function() {
    this._destroyed = true;

    // Cancel rAF
    if (this._rafId) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
    if (this._mouseRaf) {
      cancelAnimationFrame(this._mouseRaf);
      this._mouseRaf = null;
    }

    // Kill GSAP tweens/ScrollTriggers
    for (var i = 0; i < this._tweens.length; i++) {
      var tween = this._tweens[i];
      if (tween && typeof tween.kill === 'function') {
        tween.kill();
      }
    }
    this._tweens = [];

    // Clear intervals
    for (var i = 0; i < this._intervals.length; i++) {
      clearInterval(this._intervals[i]);
    }
    this._intervals = [];

    // Remove event listeners
    for (var i = 0; i < this._listeners.length; i++) {
      var l = this._listeners[i];
      l.target.removeEventListener(l.event, l.handler);
    }
    this._listeners = [];

    // Remove child elements and overlay
    for (var i = 0; i < this._childElements.length; i++) {
      var el = this._childElements[i];
      if (el && el.parentNode) {
        el.parentNode.removeChild(el);
      }
    }
    this._childElements = [];
    this._overlay = null;

    // Remove injected style element (gradient-border)
    if (this._styleEl && this._styleEl.parentNode) {
      this._styleEl.parentNode.removeChild(this._styleEl);
      this._styleEl = null;
    }
    if (this._gradientBorderClass) {
      this.element.classList.remove(this._gradientBorderClass);
    }

    // Restore original styles
    this.element.style.background = this.originalBackground;
    this.element.style.backgroundImage = this.originalBackgroundImage;
    this.element.style.backgroundSize = this.originalBackgroundSize;
    this.element.style.backgroundPosition = this.originalBackgroundPosition;
    this.element.style.boxShadow = this.originalBoxShadow;

    if (this.originalPosition === 'static') {
      this.element.style.position = '';
    }
  };

  // ─── Auto-init ─────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-gradient-type]').forEach(function(el) {
      el._dnxteGradient = new DnxteAnimatedGradient(el, {});
    });
  });

  global.DnxteAnimatedGradient = DnxteAnimatedGradient;

})(window);
