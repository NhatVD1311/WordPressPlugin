/**
 * Text Animation — Heading/Text Extension
 * Adds 17 text animations to Divi Heading & Text modules.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var el = wp.element;
  var ce = el.createElement;
  var TARGET = ['divi/heading', 'divi/text'];

  var ANIM_TYPES = {
    'blur':         { label: 'Blur In' },
    'bounce-words': { label: 'Bounce Words' },
    'bouncy':       { label: 'Bouncy Characters' },
    'fade-words':   { label: 'Fade Words' },
    'flip-words':   { label: 'Flip Words' },
    'slide-words':  { label: 'Slide Words' },
    'scale-words':  { label: 'Scale Words' },
    'rotate-words': { label: 'Rotate Words' },
    'typewriter':   { label: 'Typewriter' },
    'glitch':       { label: 'Glitch' },
    'wavy':         { label: 'Wavy' },
    'gradient':     { label: 'Gradient Flow' },
    'stagger-pop':  { label: 'Stagger Pop' },
    'focus':        { label: 'True Focus' },
    'scramble':     { label: 'Scramble' },
    'split-reveal': { label: 'Split Reveal' },
    'magnetic':     { label: 'Magnetic' },
    'particle':       { label: 'Particle Text' },
    'resize':         { label: 'Resize Handle' },
    'textured-mask':  { label: 'Textured Mask' },
  };

  var DIRECTIONS = {
    'left':  { label: 'Left' },
    'right': { label: 'Right' },
    'up':    { label: 'Up' },
    'down':  { label: 'Down' },
  };

  var GLITCH_VARIANTS = {
    'classic':   { label: 'Classic' },
    'vertical':  { label: 'Vertical' },
    'chaos':     { label: 'Chaos' },
    'shake':     { label: 'Shake' },
    'neon':      { label: 'Neon' },
    'cyberpunk': { label: 'Cyberpunk' },
    'matrix':    { label: 'Matrix' },
    'flicker':   { label: 'Flicker' },
  };

  // Types that support direction
  var DIR_TYPES = ['blur', 'bounce-words', 'slide-words', 'scale-words', 'split-reveal'];
  // Types that cycle words
  var WORD_TYPES = ['bounce-words', 'fade-words', 'flip-words', 'slide-words', 'scale-words', 'rotate-words', 'typewriter', 'resize'];
  // Types that use colors
  var COLOR_TYPES = ['gradient', 'glitch', 'particle', 'resize', 'textured-mask'];
  // Types without repeat option
  var NO_REPEAT = ['typewriter', 'magnetic', 'gradient', 'wavy', 'bouncy', 'focus'];

  function isOn(p) {
    return 'on' === (p.attrs?.text_anim?.advanced?.use_text_anim?.desktop?.value);
  }
  function getType(p) {
    return p.attrs?.text_anim?.advanced?.anim_type?.desktop?.value || 'blur';
  }

  // ════════════════════════════════════════════════════════════
  // 1. OPTION GROUP
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-text-anim', function (groups, meta) {
    if (TARGET.indexOf(meta.name) === -1) return groups;
    groups.dnxteTextAnim = {
      groupName: 'dnxteTextAnim', panel: 'design', priority: 87, multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Text Animation' } }
    };
    return groups;
  });

  // ════════════════════════════════════════════════════════════
  // 2. ATTRIBUTES
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-text-anim', function (attrs, meta) {
    if (TARGET.indexOf(meta.name) === -1) return attrs;

    attrs.text_anim = {
      type: 'object', selector: '{{selector}}',
      default: { advanced: {
        use_text_anim: { desktop: { value: 'off' } },
        anim_type:     { desktop: { value: 'blur' } },
        direction:     { desktop: { value: 'left' } },
        speed:         { desktop: { value: '1' } },
        stagger:       { desktop: { value: '0.08' } },
        color1:        { desktop: { value: '#00d4aa' } },
        color2:        { desktop: { value: '#7c3aed' } },
        repeat_anim:   { desktop: { value: 'on' } },
        words:         { desktop: { value: '' } },
        glitch_variant:  { desktop: { value: 'classic' } },
        focus_mode:      { desktop: { value: 'auto' } },
        // Typewriter specific
        typing_speed:    { desktop: { value: '60' } },
        deleting_speed:  { desktop: { value: '35' } },
        pause_duration:  { desktop: { value: '2000' } },
        cursor_char:     { desktop: { value: '|' } },
        cursor_blink:    { desktop: { value: '0.5' } },
        show_cursor:     { desktop: { value: 'on' } },
        variable_speed:  { desktop: { value: 'on' } },
        var_speed_min:   { desktop: { value: '40' } },
        var_speed_max:   { desktop: { value: '120' } },
        texture_url:     { desktop: { value: '' } },
      }},
      settings: { advanced: {
        use_text_anim: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.use_text_anim', label: 'Enable Text Animation',
          groupSlug: 'dnxteTextAnim', priority: 1, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }
        }},
        anim_type: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.anim_type', label: 'Animation',
          groupSlug: 'dnxteTextAnim', priority: 5, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: ANIM_TYPES } },
          visible: isOn
        }},
        direction: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.direction', label: 'Direction',
          groupSlug: 'dnxteTextAnim', priority: 10, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: DIRECTIONS } },
          visible: function(p) { return isOn(p) && DIR_TYPES.indexOf(getType(p)) !== -1; }
        }},
        speed: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.speed', label: 'Speed',
          groupSlug: 'dnxteTextAnim', priority: 15, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.5, max: 3, step: 0.1, defaultUnit: '' } },
          visible: isOn
        }},
        stagger: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.stagger', label: 'Stagger Delay',
          groupSlug: 'dnxteTextAnim', priority: 20, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.02, max: 0.2, step: 0.01, defaultUnit: '' } },
          visible: isOn
        }},
        words: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.words', label: 'Word List',
          description: 'Comma-separated words to cycle (e.g. Creative,Amazing,Bold)',
          groupSlug: 'dnxteTextAnim', priority: 25, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: function(p) { return isOn(p) && WORD_TYPES.indexOf(getType(p)) !== -1; }
        }},
        glitch_variant: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.glitch_variant', label: 'Glitch Style',
          groupSlug: 'dnxteTextAnim', priority: 26, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: GLITCH_VARIANTS } },
          visible: function(p) { return isOn(p) && getType(p) === 'glitch'; }
        }},
        focus_mode: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.focus_mode', label: 'Focus Mode',
          groupSlug: 'dnxteTextAnim', priority: 27, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'auto':   { label: 'Auto Cycle' },
            'manual': { label: 'Manual (Hover)' },
            'both':   { label: 'Both' },
          } } },
          visible: function(p) { return isOn(p) && getType(p) === 'focus'; }
        }},
        // ── Typewriter specific ──
        cursor_char: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.cursor_char', label: 'Cursor Character',
          groupSlug: 'dnxteTextAnim', priority: 28, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            '|':  { label: 'Pipe ( | )' },
            '_':  { label: 'Underscore ( _ )' },
            '\u2588': { label: 'Block ( \u2588 )' },
            '\u25AE': { label: 'Rectangle ( \u25AE )' },
          } } },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        typing_speed: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.typing_speed', label: 'Typing Speed (ms)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 20, max: 200, step: 5, defaultUnit: '' } },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        deleting_speed: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.deleting_speed', label: 'Deleting Speed (ms)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 10, max: 150, step: 5, defaultUnit: '' } },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        pause_duration: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.pause_duration', label: 'Pause Duration (ms)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 500, max: 5000, step: 100, defaultUnit: '' } },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        cursor_blink: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.cursor_blink', label: 'Cursor Blink Duration (s)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.2, max: 1.5, step: 0.1, defaultUnit: '' } },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        show_cursor: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.show_cursor', label: 'Show Cursor',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        variable_speed: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.variable_speed', label: 'Variable Speed',
          description: 'Natural typing feel with random speed variation',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: function(p) { return isOn(p) && getType(p) === 'typewriter'; }
        }},
        var_speed_min: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.var_speed_min', label: 'Variable Speed Min (ms)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 20, max: 150, step: 5, defaultUnit: '' } },
          visible: function(p) {
            return isOn(p) && getType(p) === 'typewriter' && 'on' === (p.attrs?.text_anim?.advanced?.variable_speed?.desktop?.value);
          }
        }},
        var_speed_max: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.var_speed_max', label: 'Variable Speed Max (ms)',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 50, max: 250, step: 5, defaultUnit: '' } },
          visible: function(p) {
            return isOn(p) && getType(p) === 'typewriter' && 'on' === (p.attrs?.text_anim?.advanced?.variable_speed?.desktop?.value);
          }
        }},
        texture_url: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.texture_url', label: 'Texture Image URL',
          description: 'Image URL to clip through text. Leave empty to use gradient colors.',
          groupSlug: 'dnxteTextAnim', priority: 29, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/text' },
          visible: function(p) { return isOn(p) && getType(p) === 'textured-mask'; }
        }},
        color1: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.color1', label: 'Color 1',
          groupSlug: 'dnxteTextAnim', priority: 30, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function(p) { return isOn(p) && COLOR_TYPES.indexOf(getType(p)) !== -1; }
        }},
        color2: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.color2', label: 'Color 2',
          groupSlug: 'dnxteTextAnim', priority: 35, render: true,
          features: { sticky: false, responsive: false },
          component: { type: 'field', name: 'divi/color-picker' },
          visible: function(p) { return isOn(p) && COLOR_TYPES.indexOf(getType(p)) !== -1; }
        }},
        repeat_anim: { groupType: 'group-item', item: {
          attrName: 'text_anim.advanced.repeat_anim', label: 'Loop Animation',
          groupSlug: 'dnxteTextAnim', priority: 40, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: function(p) { return isOn(p) && NO_REPEAT.indexOf(getType(p)) === -1; }
        }},
      }}
    };
    return attrs;
  });

  // ════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER
  // ════════════════════════════════════════════════════════════
  function TextAnimInjector(props) {
    var React = window.vendor.React;
    var ref = React.useRef(null);
    var instanceRef = React.useRef(null);
    var ta = props.moduleAttrs?.text_anim?.advanced;

    React.useEffect(function () {
      if (ta?.use_text_anim?.desktop?.value !== 'on') return;

      var timer = setTimeout(function () {
        if (!ref.current) return;
        var moduleEl = ref.current.parentElement;
        while (moduleEl) {
          if (moduleEl.classList.contains('et_pb_module') || moduleEl.dataset.diviRenderer) break;
          moduleEl = moduleEl.parentElement;
        }
        if (!moduleEl) moduleEl = ref.current.parentElement;
        if (!window.DnxteTextAnimation) return;

        // Find the actual heading/text element inside the module
        var textEl = moduleEl.querySelector('h1, h2, h3, h4, h5, h6, .et_pb_module_header, p');
        if (!textEl) textEl = moduleEl;

        var wordsStr = ta?.words?.desktop?.value || '';
        var wordsArr = wordsStr ? wordsStr.split(',').map(function(s) { return s.trim(); }).filter(Boolean) : [];

        instanceRef.current = new window.DnxteTextAnimation(textEl, {
          type:          ta?.anim_type?.desktop?.value || 'blur',
          direction:     ta?.direction?.desktop?.value || 'left',
          speed:         parseFloat(ta?.speed?.desktop?.value || 1),
          stagger:       parseFloat(ta?.stagger?.desktop?.value || 0.08),
          color1:        ta?.color1?.desktop?.value || '#00d4aa',
          color2:        ta?.color2?.desktop?.value || '#7c3aed',
          repeat:        ta?.repeat_anim?.desktop?.value !== 'off',
          words:         wordsArr,
          glitchVariant: ta?.glitch_variant?.desktop?.value || 'classic',
          focusMode:     ta?.focus_mode?.desktop?.value || 'auto',
          // Typewriter
          typingSpeed:   parseInt(ta?.typing_speed?.desktop?.value || 60),
          deletingSpeed: parseInt(ta?.deleting_speed?.desktop?.value || 35),
          pauseDuration: parseInt(ta?.pause_duration?.desktop?.value || 2000),
          cursorChar:    ta?.cursor_char?.desktop?.value || '|',
          cursorBlink:   parseFloat(ta?.cursor_blink?.desktop?.value || 0.5),
          showCursor:    ta?.show_cursor?.desktop?.value !== 'off',
          variableSpeed: ta?.variable_speed?.desktop?.value === 'on',
          varSpeedMin:   parseInt(ta?.var_speed_min?.desktop?.value || 40),
          varSpeedMax:   parseInt(ta?.var_speed_max?.desktop?.value || 120),
          textureUrl:    ta?.texture_url?.desktop?.value || '',
        });
      }, 200);

      return function () {
        clearTimeout(timer);
        if (instanceRef.current) { instanceRef.current.destroy(); instanceRef.current = null; }
      };
    }, [JSON.stringify(ta)]);

    return ce('span', { ref: ref, style: { display: 'none', position: 'absolute', pointerEvents: 'none' } });
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-text-anim', function (wrapper, param) {
    if (TARGET.indexOf(param.name) === -1) return wrapper;
    if (param.attrs?.text_anim?.advanced?.use_text_anim?.desktop?.value !== 'on') return wrapper;

    var children = wrapper.props.children;
    var arr = Array.isArray(children) ? children : [children];
    return el.cloneElement(wrapper, {}, arr.concat([
      ce(TextAnimInjector, { key: 'dnxte-text-anim-injector', moduleAttrs: param.attrs })
    ]));
  });
})();
