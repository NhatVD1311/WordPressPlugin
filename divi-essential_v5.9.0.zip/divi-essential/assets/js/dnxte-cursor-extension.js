/**
 * Cursor Effects — Section Extension
 * Adds 50 cursor/trail/image-trail effects to Divi Section.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var el = wp.element;
  var ce = el.createElement;
  var TARGET = ['divi/section', 'divi/row', 'divi/column'];

  // All 50 effect types organized
  var CURSOR_TYPES = {
    'circle-follower': 'Circle Follower',
    'dot-ring':        'Dot & Ring',
    'magnetic':        'Magnetic Snap',
    'spotlight':       'Spotlight',
    'particle-trail':  'Particle Trail',
    'emoji':           'Emoji Cursor',
    'stretch':         'Stretch Cursor',
    'blend-mode':      'Blend Mode',
    'morph':           'Morphing Shape',
    'glitch':          'Glitch RGB',
    'ripple-click':    'Ripple Click',
    'arrow':           'Direction Arrow',
    'bubble':          'Bubble Cursor',
    'multi-ring':      'Multi Ring',
  };
  var TRAIL_TYPES = {
    'trail-dot':       'Dot Trail',
    'trail-line':      'Line Trail',
    'trail-neon':      'Neon Glow',
    'trail-rainbow':   'Rainbow',
    'trail-particles': 'Particle Burst',
    'trail-geometric': 'Geometric Shapes',
    'trail-spotlight': 'Spotlight Reveal',
    'trail-comet':     'Comet Trail',
    'trail-bubbles':   'Bubbles',
    'trail-stars':     'Star Trail',
    'trail-smoke':     'Smoke Effect',
    'trail-electric':  'Electric Arc',
    'trail-dna':       'DNA Helix',
    'trail-confetti':  'Confetti',
    'trail-ink':       'Ink Splatter',
    'trail-fire':      'Fire Trail',
    'trail-snow':      'Snowflakes',
    'trail-magnetic':  'Magnetic Field',
    'trail-glitch':    'Glitch Effect',
    'trail-pixel':     'Pixel Art',
  };
  var IMAGE_TYPES = {
    'img-fade':        'Fade & Shrink',
    'img-scale':       'Scale Up',
    'img-float':       'Float Up',
    'img-spiral':      'Spiral Out',
    'img-bounce':      'Bounce',
    'img-blur':        'Blur Out',
    'img-slide':       'Random Slide',
    'img-3d-flip':     '3D Flip',
    'img-stagger':     'Stagger Trail',
    'img-gravity':     'Gravity Fall',
    'img-zoom-rotate': 'Zoom & Rotate',
    'img-scatter':     'Card Scatter',
    'img-polaroid':    'Polaroid',
    'img-circle':      'Circle Reveal',
    'img-glitch':      'Glitch Images',
  };

  // Merged for dropdown
  var ALL_TYPES = {};
  var k;
  for (k in CURSOR_TYPES) ALL_TYPES[k] = { label: 'Cursor: ' + CURSOR_TYPES[k] };
  for (k in TRAIL_TYPES)  ALL_TYPES[k] = { label: 'Trail: ' + TRAIL_TYPES[k] };
  for (k in IMAGE_TYPES)  ALL_TYPES[k] = { label: 'Image: ' + IMAGE_TYPES[k] };

  // Flat label map
  var ALL_LABELS = {};
  for (k in CURSOR_TYPES) ALL_LABELS[k] = CURSOR_TYPES[k];
  for (k in TRAIL_TYPES) ALL_LABELS[k] = TRAIL_TYPES[k];
  for (k in IMAGE_TYPES) ALL_LABELS[k] = IMAGE_TYPES[k];

  function isImg(type) { return type && type.indexOf('img-') === 0; }
  function isTrail(type) { return type && type.indexOf('trail-') === 0; }

  // Effects that don't support custom colors
  var NO_COLOR_TYPES = [
    'emoji', 'arrow', 'blend-mode',
    'trail-rainbow', 'trail-spotlight', 'trail-fire', 'trail-snow',
    'trail-smoke', 'trail-glitch', 'trail-pixel'
  ];

  function isEnabled(p) {
    return 'on' === (p.attrs?.cursor_config?.advanced?.use_cursor?.desktop?.value);
  }
  function getType(p) {
    return p.attrs?.cursor_config?.advanced?.cursor_type?.desktop?.value || 'circle-follower';
  }
  function supportsColor(p) {
    return isEnabled(p) && NO_COLOR_TYPES.indexOf(getType(p)) === -1;
  }

  // ════════════════════════════════════════════════════════════
  // 1. OPTION GROUP
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-cursor', function (groups, meta) {
    if (TARGET.indexOf(meta.name) === -1) return groups;
    groups.dnxteCursor = {
      groupName: 'dnxteCursor', panel: 'design', priority: 84, multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Cursor & Trail Effects' } }
    };
    return groups;
  });

  // ════════════════════════════════════════════════════════════
  // 2. ATTRIBUTES
  // ════════════════════════════════════════════════════════════
  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-cursor', function (attrs, meta) {
    if (TARGET.indexOf(meta.name) === -1) return attrs;

    attrs.cursor_config = {
      type: 'object',
      selector: '{{selector}}',
      default: {
        advanced: {
          use_cursor:      { desktop: { value: 'off' } },
          cursor_type:     { desktop: { value: 'circle-follower' } },
          color1:          { desktop: { value: '#00d4aa' } },
          color2:          { desktop: { value: '#7c3aed' } },
          size:            { desktop: { value: '30' } },
          speed:           { desktop: { value: '0.3' } },
          trail_length:    { desktop: { value: '25' } },
          fade_ms:         { desktop: { value: '800' } },
          cursor_text:     { desktop: { value: 'HELLO' } },
          image_urls:      { desktop: { value: '' } },
          image_size:      { desktop: { value: '100' } },
          image_threshold: { desktop: { value: '60' } },
        }
      },
      settings: {
        advanced: {
          use_cursor: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.use_cursor',
              label: 'Enable Cursor Effect',
              groupSlug: 'dnxteCursor', priority: 10, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/toggle' }
            }
          },
          cursor_type: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.cursor_type',
              label: 'Effect Type',
              groupSlug: 'dnxteCursor', priority: 15, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/select', props: { options: ALL_TYPES } },
              visible: isEnabled
            }
          },
          color1: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.color1',
              label: 'Primary Color',
              groupSlug: 'dnxteCursor', priority: 20, render: true,
              features: { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: supportsColor
            }
          },
          color2: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.color2',
              label: 'Secondary Color',
              groupSlug: 'dnxteCursor', priority: 25, render: true,
              features: { sticky: false, responsive: false },
              component: { type: 'field', name: 'divi/color-picker' },
              visible: supportsColor
            }
          },
          size: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.size',
              label: 'Cursor Size',
              groupSlug: 'dnxteCursor', priority: 30, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 5, max: 200, step: 1 } },
              visible: isEnabled
            }
          },
          speed: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.speed',
              label: 'Follow Speed',
              groupSlug: 'dnxteCursor', priority: 35, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 0.05, max: 1, step: 0.05 } },
              visible: isEnabled
            }
          },
          trail_length: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.trail_length',
              label: 'Trail Length',
              groupSlug: 'dnxteCursor', priority: 40, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 5, max: 100, step: 1 } },
              visible: function (p) { return isEnabled(p) && isTrail(getType(p)); }
            }
          },
          fade_ms: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.fade_ms',
              label: 'Fade Duration (ms)',
              groupSlug: 'dnxteCursor', priority: 45, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 200, max: 3000, step: 100 } },
              visible: function (p) { return isEnabled(p) && isTrail(getType(p)); }
            }
          },
          image_urls: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.image_urls',
              label: 'Image URLs (comma-separated)',
              groupSlug: 'dnxteCursor', priority: 50, render: true,
              features: { sticky: false, hover: false, responsive: false },
              component: { type: 'field', name: 'divi/text' },
              visible: function (p) { return isEnabled(p) && isImg(getType(p)); }
            }
          },
          image_size: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.image_size',
              label: 'Image Size',
              groupSlug: 'dnxteCursor', priority: 55, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 40, max: 300, step: 10 } },
              visible: function (p) { return isEnabled(p) && isImg(getType(p)); }
            }
          },
          image_threshold: {
            groupType: 'group-item',
            item: {
              attrName: 'cursor_config.advanced.image_threshold',
              label: 'Spawn Distance',
              description: 'Minimum mouse distance to spawn next image',
              groupSlug: 'dnxteCursor', priority: 60, render: true,
              features: { sticky: false },
              component: { type: 'field', name: 'divi/range', props: { min: 20, max: 200, step: 5 } },
              visible: function (p) { return isEnabled(p) && isImg(getType(p)); }
            }
          }
        }
      }
    };

    return attrs;
  });

  // ════════════════════════════════════════════════════════════
  // 3. VB WRAPPER RENDER — init cursor effect
  // ════════════════════════════════════════════════════════════

  function CursorInjector(props) {
    var React = window.vendor.React;
    var ref = React.useRef(null);
    var instanceRef = React.useRef(null);
    var ma = props.moduleAttrs;
    var cc = ma?.cursor_config?.advanced;

    React.useEffect(function () {
      if (cc?.use_cursor?.desktop?.value !== 'on') return;

      var timer = setTimeout(function () {
        if (!ref.current) return;
        // Find section element
        var sectionEl = ref.current.parentElement;
        while (sectionEl) {
          if (sectionEl.classList.contains('et_pb_section') || sectionEl.dataset.diviRenderer) break;
          sectionEl = sectionEl.parentElement;
        }
        if (!sectionEl) sectionEl = ref.current.parentElement;

        if (!window.DnxteCursorEffects) return;

        var imgUrls = (cc?.image_urls?.desktop?.value || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);

        instanceRef.current = new window.DnxteCursorEffects(sectionEl, {
          type:           cc?.cursor_type?.desktop?.value || 'circle-follower',
          color1:         cc?.color1?.desktop?.value || '#00d4aa',
          color2:         cc?.color2?.desktop?.value || '#7c3aed',
          size:           parseInt(cc?.size?.desktop?.value || 30),
          speed:          parseFloat(cc?.speed?.desktop?.value || 0.3),
          trailLength:    parseInt(cc?.trail_length?.desktop?.value || 25),
          fadeMs:         parseInt(cc?.fade_ms?.desktop?.value || 800),
          imageUrls:      imgUrls,
          imageSize:      parseInt(cc?.image_size?.desktop?.value || 100),
          imageThreshold: parseInt(cc?.image_threshold?.desktop?.value || 60),
          cursorText:     cc?.cursor_text?.desktop?.value || 'HELLO',
        });
      }, 100);

      return function () {
        clearTimeout(timer);
        if (instanceRef.current) {
          instanceRef.current.destroy();
          instanceRef.current = null;
        }
      };
    }, [
      cc?.use_cursor?.desktop?.value,
      cc?.cursor_type?.desktop?.value,
      cc?.color1?.desktop?.value,
      cc?.color2?.desktop?.value,
      cc?.size?.desktop?.value,
      cc?.speed?.desktop?.value,
      cc?.trail_length?.desktop?.value,
      cc?.fade_ms?.desktop?.value,
      cc?.image_urls?.desktop?.value,
      cc?.image_size?.desktop?.value,
      cc?.image_threshold?.desktop?.value,
    ]);

    return ce('span', {
      ref: ref,
      style: { display: 'none', position: 'absolute', pointerEvents: 'none' }
    });
  }

  hooks.addFilter('divi.module.wrapper.render', 'dnxte-cursor', function (wrapper, param) {
    if (TARGET.indexOf(param.name) === -1) return wrapper;
    if (param.attrs?.cursor_config?.advanced?.use_cursor?.desktop?.value !== 'on') return wrapper;

    var children = wrapper.props.children;
    var arr = Array.isArray(children) ? children : [children];

    return el.cloneElement(wrapper, {}, arr.concat([
      ce(CursorInjector, { key: 'dnxte-cursor-injector', moduleAttrs: param.attrs })
    ]));
  });

})();
