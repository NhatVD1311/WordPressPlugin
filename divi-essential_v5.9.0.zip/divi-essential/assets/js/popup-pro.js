// Custom Popup Implementation - No Magnific Popup Required
(function ($) {
  // Popup settings arrive via data-* attributes, which the browser has already
  // decoded — so the server's escaping is gone by the time these values are
  // spliced back into markup below. Escape again at the sink.
  function escapeAttr(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // These two land in a class attribute, where only class-name characters are
  // ever legitimate; anything else is dropped rather than escaped.
  function sanitizeClassToken(value) {
    return String(value == null ? "" : value).replace(/[^\w\s-]/g, "");
  }

  // Custom popup implementation object
  const DnxteCustomPopup = {
    // Current active popup (for backward compatibility)
    currentPopup: null,
    // Track all active popups
    activePopups: [],

    // Cache of detached popup templates keyed by their source selector.
    templates: {},

    // Initialize the popup
    open: function (config) {
      // The popup markup is server-rendered once inside the hidden #dnxte_popup
      // holder and cloned into the visible wrapper on open. Cloning the LIVE
      // holder each time left two elements in the DOM sharing the same ids (the
      // popup container id plus any custom module ids the user set, e.g.
      // #popupcoutdown on a countdown) — invalid HTML that makes
      // getElementById()/#id lookups resolve to the hidden copy. On first use,
      // cache a detached template (ids intact, captured after Divi has
      // initialized the holder so clone behavior is unchanged) and remove the
      // live-holder copy, so only the visible clone carries the ids.
      const src = config.items.src;
      let popupContent;
      if (typeof src === "string") {
        if (!this.templates[src]) {
          const liveSource = $(src);
          if (!liveSource.length) return;
          this.templates[src] = liveSource.clone();
          liveSource.remove();
        }
        popupContent = this.templates[src];
      } else {
        // Non-string src (already a jQuery/DOM node): use as-is, no dedup needed.
        popupContent = $(src);
      }
      if (!popupContent || !popupContent.length) return;

      // Create popup wrapper (creates both background and wrapper)
      const popupWrapper = this.createPopupWrapper(config);
      const popupContainer = this.createPopupContainer(config);

      // Clone content and make it visible
      const clonedContent = popupContent.clone();
      clonedContent.css('display', 'block');

      // Divi 5 lazy-loads video iframes (src moved to data-src, restored by an
      // IntersectionObserver when scrolled into view). That observer can never
      // fire for popup content: the holder is display:none, then removed, and
      // each open injects a fresh clone the observer has never seen. Opening
      // the popup IS the visibility signal, so restore the real src here.
      clonedContent.find('iframe[data-src], source[data-src]').each(function () {
        this.setAttribute('src', this.getAttribute('data-src'));
        this.removeAttribute('data-src');
      });

      // Apply popup position classes
      this.applyPopupPosition(popupContainer, clonedContent);

      popupContainer.prepend(clonedContent);

      // Add close button if needed - for inline popups, add to wrapper not content
      if (config.closeMarkup && !config.closeBtnInside) {
        popupWrapper.prepend(config.closeMarkup);
      } else if (config.closeMarkup && config.closeBtnInside) {
        // how to check already exit button or not
        if (popupContainer.children().last().find('.dnxte_popup_close').length < 1) {
          popupContainer.children().last().prepend(config.closeMarkup);
        }
      }

      // Append container to wrapper's dnxte_popup_container
      popupWrapper.find('.dnxte_popup_container').append(popupContainer);

      // Store current popup reference (maintain backward compatibility)
      this.currentPopup = popupWrapper;
      // Also add to activePopups array
      this.activePopups.push(popupWrapper);

      // Re-initialize countdown timers in the popup
      this.initializeCountdownTimers(clonedContent);

      // Trigger beforeOpen callback
      if (config.callbacks && config.callbacks.beforeOpen) {
        config.callbacks.beforeOpen();
      }

      // Bind events  
      this.bindEvents(popupWrapper, config);

      // Prevent body scroll if needed
      if (config.fixedContentPos) {
        $('body').addClass('dnxte-popup-open');
      }

      // Re-initialize Divi element links on the cloned popup content
      // Cloned elements don't carry jQuery event handlers, so Divi's
      // element-link click bindings (from diviElementLinkData) are lost.
      // if (typeof window.et_pb_init_link === 'function') {
      //   window.et_pb_init_link();
      // }
    },

    close: function (specificPopup = null) {
      const popup = specificPopup || this?.currentPopup;
      if (!popup) return;

      const bgOverlay = popup?.data('bg-overlay');
      const config = popup?.data('popup-config');

      // Trigger beforeClose callback
      if (config && config.callbacks && config.callbacks.beforeClose) {
        config.callbacks.beforeClose();
      }

      // Add closing animation classes
      popup?.addClass('dnxte_popup-removing');
      if (bgOverlay) {
        bgOverlay?.addClass('dnxte_popup-removing');
      }

      // Remove after animation
      setTimeout(() => {
        popup?.remove();
        if (bgOverlay) {
          bgOverlay.remove();
        }

        // Remove from activePopups array
        const index = this.activePopups.indexOf(popup);
        if (index > -1) {
          this.activePopups.splice(index, 1);
        }

        // Update currentPopup reference
        if (this.currentPopup === popup) {
          this.currentPopup = this.activePopups.length > 0 ? this.activePopups[this.activePopups.length - 1] : null;
        }

        // Only remove body class if no popups are active
        if (this.activePopups.length === 0) {
          $('body').removeClass('dnxte-popup-open');
        }

        // Trigger afterClose callback
        if (config && config.callbacks && config.callbacks.afterClose) {
          config.callbacks.afterClose();
        }
      }, config ? config.removalDelay || 1000 : 1000);
    },

    createPopupWrapper: function (config) {

      // Create background overlay with exact magnific popup classes
      const bgOverlay = $('<div>', {
        class: `dnxte_popup_overlay ${config.mainClass || ''} animate__animated`,
      });

      // Create popup wrapper with exact magnific popup classes  
      const wrapper = $('<div>', {
        class: `dnxte_popup_wrap ${config.mainClass || ''}`,
      });

      // Create container
      const container = $('<div>', {
        class: 'dnxte_popup_container'
      });
      wrapper.append(bgOverlay);
      wrapper.append(container);

      // Add both background and wrapper to body
      $('body').prepend(wrapper);
      //document.body.insertAdjacentHTML("afterbegin", wrapper);

      wrapper.data('popup-config', config);
      wrapper.data('bg-overlay', bgOverlay);
      return wrapper;
    },

    createPopupContainer: function (config) {
      return $('<div>', {
        class: 'dnxte_popup-content'
      });
    },



    applyPopupPosition: function (container, content) {
      // Check if it's full width layout
      const isFullWidth = content.hasClass('dnxte_popup_pro_layout_full_width');

      if (isFullWidth) {
        // For full width, make content fill the entire viewport
        container.css({
          width: '100%',
          height: '100%',
          maxWidth: '100vw',
          maxHeight: '100vh'
        });
        content.css({
          width: '100%',
          height: '100%'
        });
      } else {
        // Extract position classes from content
        const className = content.attr('class') || '';
        const positionClasses = className.match(/dnxte_popup_pro_position_[\w-]+/);
        if (positionClasses) {
          const positionClass = positionClasses[0];
          const position = positionClass.replace('dnxte_popup_pro_position_', '').replace(/-/g, '_');

          // Apply position-specific styling to container
          switch (position) {
            case 'top_left':
              container.parent().css({ justifyContent: 'flex-start', alignItems: 'flex-start' });
              break;
            case 'top_center':
              container.parent().css({ justifyContent: 'center', alignItems: 'flex-start' });
              break;
            case 'top_right':
              container.parent().css({ justifyContent: 'flex-end', alignItems: 'flex-start' });
              break;
            case 'center_left':
              container.parent().css({ justifyContent: 'flex-start', alignItems: 'center' });
              break;
            case 'center_center':
              container.parent().css({ justifyContent: 'center', alignItems: 'center' });
              break;
            case 'center_right':
              container.parent().css({ justifyContent: 'flex-end', alignItems: 'center' });
              break;
            case 'bottom_left':
              container.parent().css({ justifyContent: 'flex-start', alignItems: 'flex-end' });
              content.css({ left: '', right: '', top: '', bottom: '', transform: '' });
              break;
            case 'bottom_center':
              container.parent().css({ justifyContent: 'center', alignItems: 'flex-end' });
              break;
            case 'bottom_right':
              container.parent().css({ justifyContent: 'flex-end', alignItems: 'flex-end' });
              break;
          }
        }
      }
    },

    // Initialize countdown timers in popup content
    initializeCountdownTimers: function (popupContent) {
      const self = this;

      // Find all countdown timer elements in the popup
      const countdownTimers = popupContent.find('.et_pb_countdown_timer');

      if (countdownTimers.length > 0) {

        countdownTimers.each(function () {
          const $timer = $(this);

          // Clear any existing intervals
          const existingInterval = $timer.data('interval');
          if (existingInterval) {
            clearInterval(existingInterval);
          }

          // Try Divi's native countdown initialization first
          if (typeof window.et_pb_countdown_timer_init === 'function') {
            try {
              window.et_pb_countdown_timer_init($timer);
            } catch (e) {
              self.fallbackCountdownInit($timer);
            }
          } else if (typeof window.et_countdown_timer === 'function') {
            try {
              // Use et_countdown_timer function
              window.et_countdown_timer($timer);

              // Set up interval for continuous updates
              const interval = setInterval(function () {
                window.et_countdown_timer($timer);
              }, 1000);

              $timer.data('interval', interval);
            } catch (e) {
              self.fallbackCountdownInit($timer);
            }
          } else {
            // Use fallback initialization
            self.fallbackCountdownInit($timer);
          }
        });
      }
    },

    // Fallback countdown initialization
    fallbackCountdownInit: function ($timer) {
      const endTimestamp = $timer.data('end-timestamp');

      if (!endTimestamp) {
        return;
      }


      const updateCountdown = function () {
        const now = Math.floor(Date.now() / 1000);
        const timeLeft = endTimestamp - now;

        if (timeLeft <= 0) {
          // Countdown finished
          $timer.find('.value').text('00');
          return;
        }

        const days = Math.floor(timeLeft / (60 * 60 * 24));
        const hours = Math.floor((timeLeft % (60 * 60 * 24)) / (60 * 60));
        const minutes = Math.floor((timeLeft % (60 * 60)) / 60);
        const seconds = timeLeft % 60;

        // Update display
        $timer.find('.days .value').text(String(days).padStart(3, '0'));
        $timer.find('.hours .value').text(String(hours).padStart(2, '0'));
        $timer.find('.minutes .value').text(String(minutes).padStart(2, '0'));
        $timer.find('.seconds .value').text(String(seconds).padStart(2, '0'));
      };

      // Initial update
      updateCountdown();

      // Set up interval
      const interval = setInterval(updateCountdown, 1000);
      $timer.data('interval', interval);
    },

    bindEvents: function (wrapper, config) {
      const self = this;
      const bgOverlay = wrapper.data('bg-overlay');

      // Close on overlay click - bind to both wrapper and background
      if (config.closeOnBgClick) {
        // Bind to wrapper container click
        wrapper.on('click', function (e) {
          if (e.target === this || $(e.target).hasClass('dnxte_popup_container')) {
            self.close(wrapper);
          }
        });

        // Bind to background overlay click
        if (bgOverlay) {
          bgOverlay.on('click', function (e) {
            self.close(wrapper);
          });
        }
      }
      // Close button click — route to close() so the closing animation
      // (class swap in beforeClose) plays for the full removalDelay before
      // the popup is removed. Previously this handler set a 500ms inline
      // animation but removed the element at 200ms, cutting the animation off.
      const idMatch = config.closeMarkup ? config.closeMarkup.match(/id="popup_close_(\d+)"/) : null;
      const id = idMatch ? idMatch[1] : null;
      let closeButton = wrapper.find(`#popup_close_${id}`);

      closeButton.on('click', function (e) {
        e.preventDefault();
        self.close(wrapper);
      });

      // Custom close trigger — any element inside the popup matching the
      // user-provided selector closes the popup (works alongside the default
      // close button). A bare value (no . or #) matches either an id or a class.
      if (config.closeTriggerSelector) {
        let closeSel = String(config.closeTriggerSelector).trim();
        if (closeSel) {
          if (!closeSel.startsWith('.') && !closeSel.startsWith('#')) {
            closeSel = '#' + closeSel + ', .' + closeSel;
          }
          wrapper.on('click', closeSel, function (e) {
            e.preventDefault();
            self.close(wrapper);
          });
        }
      }

      // ESC key - close the most recently opened popup
      $(document).on('keydown.dnxte-popup', function (e) {
        if (e.keyCode === 27 && self.activePopups.length > 0) {
          // Close the most recent popup
          const mostRecentPopup = self.activePopups[self.activePopups.length - 1];
          self.close(mostRecentPopup);
        }
      });



      // Close popup by clicking back button ========
      let allPopups = $(".dnxte_popup_wrap");
      allPopups.each(function () {
        let ppID = $(this).find('.dnxte_popup_content').data("popup-id");
        const ppOptions = ppID?.data()?.popup;
        const clickOnBack = ppOptions?.close_clicking_back_button;


        if ('true' === clickOnBack) {
          window.history.pushState(null, null, "");
          window.history.pushState(null, null, "");
          window.history.pushState(null, null, "");
          $(window).on("popstate", function (e) {
            e.preventDefault();

            const ppWrapper = $(`.dnxte_popup_custom_${ppID}`);
            const ppContent = ppWrapper.find('.dnxte_popup_content');
            if (ppWrapper.length > 0) {
              ppContent.css('animation', `500ms ease 0s 1 normal none running dnxte_popup_pro_${ppOptions?.closing_animation}`);
              setTimeout(function () {
                ppWrapper.remove();

                // Remove from activePopups array
                const index = self.activePopups.indexOf(ppWrapper);
                if (index > -1) {
                  self.activePopups.splice(index, 1);
                }

                // Update currentPopup reference
                if (self.currentPopup === ppWrapper) {
                  self.currentPopup = self.activePopups.length > 0 ? self.activePopups[self.activePopups.length - 1] : null;
                }

                // Only remove body class if no popups are active
                if (self.activePopups.length === 0) {
                  $('body').removeClass('dnxte-popup-open');
                }
              }, 500);
            }

          });
        }
      });

    }
  };

  // Replace magnificPopup with our custom implementation
  if (!window.jQuery.magnificPopup) {
    $.magnificPopup = DnxteCustomPopup;
  }

  $(document).ready(function ($) {
    if ("undefined" == typeof popup_frontend) return false;

    var popup_json = JSON.parse(popup_frontend?.dnxte_popup_show);
    popupIds = popup_json?.popup_ids;

    // Helper function to set cookie when popup is triggered
    function setPopupCookie(popupId) {
      const popupShow = JSON.parse(popup_frontend.dnxte_popup_show);
      const periodicity = popupShow[`popup_perodicity${popupId}`];

      if (periodicity !== "every_time" && !document.cookie.includes(`dxnteHours${popupId}=`)) {
        var expires = new Date();
        expires.setTime(expires.getTime() + popupShow[`periodicity_cookie${popupId}`]);
        document.cookie = `dxnteHours${popupId}=true; expires=` + expires.toUTCString() + "; path=/;";
      }
    }

    // Helper function to check if popup should be shown based on cookie
    function canShowPopup(popupId) {
      const popupShow = JSON.parse(popup_frontend.dnxte_popup_show);
      const periodicity = popupShow[`popup_perodicity${popupId}`];

      if (periodicity === "every_time") {
        return true;
      }

      return !document.cookie.includes(`dxnteHours${popupId}=`);
    }

    popupIds.forEach((id) => {
      const data = JSON.parse(popup_json[`json_data${id}`]);
      const content = $(`.dnxte_popup_content_${id}`);
      const close_btn_tooltip = content.data("close-btn-tooltip") ? `data-tooltip="${escapeAttr(content.data("close-btn-tooltip"))}"` : '';
      const tooltipClass = content.data("close-btn-tooltip") ? ` close-btn-tooltip` : '';

      if ("true" === data?.remove_link) {
        $(`a#popup_${id}`).removeAttr("href");
      }


      let preventScrolling =
        "true" === data.prevent_page_scrolling ? `dnxte-prevent-scrolling` : "";

      const clickable_under_overlay =
        "false" === data.close_overlay_click
          ? data.clickable_under_overlay
          : false;

      const popupConfig = {
        items: {
          src: `.dnxte_popup_content_${id}`,
          // src: content,
        },
        callbacks: {
          beforeClose: function () {
            $(`.dnxte_popup_content.dnxte_popup_content_${id}`)
              .removeClass(`dnxte_popup_pro_${data.opening_animation}`)
              .addClass(`dnxte_popup_pro_${data.closing_animation}`);
          },
          afterClose: function () {
            $(`.dnxte_popup_content.dnxte_popup_content_${id}`)
              .removeClass(`dnxte_popup_pro_${data.closing_animation}`)
              .addClass(`dnxte_popup_pro_${data.opening_animation}`);
          },
        },
        type: "inline",
        closeBtnInside: !JSON.parse(data?.close_btn_outside?.toLowerCase()),
        closeOnBgClick: JSON.parse(data.close_overlay_click.toLowerCase()),
        closeTriggerSelector: data.close_trigger_selector,
        fixedContentPos: JSON.parse(data.prevent_page_scrolling.toLowerCase()),
        mainClass: `dnxte_popup_custom ${clickable_under_overlay} ${preventScrolling} dnxte_popup_custom_${id}`, // mainClass: `dnxte_popup_custom ${data.clickable_under_overlay} dnxte_popup_custom_${id}`,
        removalDelay: 1500,
        midClick: true,
        closeMarkup:
          "false" === data.hide_close_button
            ? `<button type="button" ${close_btn_tooltip} data-popup-id="${escapeAttr(id)}" id="popup_close_${escapeAttr(id)}" class="custom-tooltip dnxte_popup-close ${sanitizeClassToken(data.closing_css_selector)} dnxte_popup_pro_${sanitizeClassToken(data.close_btn_position)}_close ${tooltipClass}">&#215;</button>`
            : ``,
      };

      if ("on" == data.dnxte_disable_desktop && 981 < $(window).width()) {
        return;
      }
      if (
        "on" == data.dnxte_disable_tablet &&
        768 <= $(window).width() &&
        981 >= $(window).width()
      ) {
        return;
      }
      if ("on" == data.dnxte_disable_phone && 768 > $(window).width()) {
        return;
      }

      var dnxte_popup_show = JSON.parse(popup_frontend.dnxte_popup_show);

      let startTime = 0;

      if ("" !== data?.trigger_delay_start) {
        startTime = +data?.trigger_delay_start * 1000;
      }
      const endTime = startTime + data?.trigger_delay_end * 1000;

      // Check if popup should be shown based on periodicity - but don't set cookie yet
      if ("trigger_on_none" !== data?.trigger_event) {
        // Only check if popup should show, don't set cookie until popup is actually triggered
        if (!dnxte_popup_show[`popup_show${id}`]) return false;

        // Remove cookie if periodicity is "every_time"
        if ("every_time" == dnxte_popup_show[`popup_perodicity${id}`]) {
          if (document.cookie.includes(`dxnteHours${id}=`)) {
            document.cookie = `dxnteHours${id}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
          }
        }
      }
      var trigger_event = JSON.parse(popup_frontend.trigger_event);

      if ("trigger_on_none" === data.trigger_event) {
        $(`#popup_${id}`).on("click", function (event) {
          event.preventDefault();

          if ($(`body > .dnxte_popup_content_${id}`).length === 0 && canShowPopup(id)) {
            DnxteCustomPopup.open(popupConfig);
            setPopupCookie(id);
          }
        });

        /* custom css selector */
        if ("" == dnxte_popup_show[`custom_selector${id}`]) return false;        
        
        let custom_selector = dnxte_popup_show[`custom_selector${id}`];
        if (!custom_selector.startsWith('.')) {
          custom_selector = '.' + custom_selector;
        }

        $(custom_selector).each(function () {
          $(this).on("click", function (event) {            
              event.preventDefault();
              if (canShowPopup(id)) {
                DnxteCustomPopup.open(popupConfig);
                setPopupCookie(id);
              }
            },
          );
        });
      } else if ("trigger_on_load" === data.trigger_event) {
        // Check if popup can be shown based on periodicity before triggering
        if (canShowPopup(id)) {
          if (0 == startTime) {
            DnxteCustomPopup.open(popupConfig);
            setPopupCookie(id);
          } else {
            const popupOpenTimer = setTimeout(() => {
              DnxteCustomPopup.open(popupConfig);
              setPopupCookie(id);
              clearTimeout(popupOpenTimer);
            }, startTime);
          }
          if (startTime < endTime) {
            const popupCloseTimer = setTimeout(() => {
              DnxteCustomPopup.close();
              clearTimeout(popupCloseTimer);
            }, endTime);
          }
        }
      } else if ("trigger_on_scroll" === data.trigger_event) {
        let scroll_event = trigger_event[id];
        var recentScroll = false;
        $(window).on("scroll", function () {
          // Only proceed if popup can be shown based on periodicity
          if (!recentScroll && canShowPopup(id)) {
            const scrollPosition = window.scrollY + window.innerHeight;
            const totalHeight = document.documentElement.scrollHeight;
            let isPopupShown = false;

            if (scroll_event.onscroll_offset_units != "px") {
              const scrollPercentage = (scrollPosition / totalHeight) * 100;
              if (scrollPercentage >= scroll_event.onscroll_offset) {
                isPopupShown = true;
                recentScroll = true;
              }
            } else if (scroll_event.onscroll_offset_units == "px") {
              if (window.scrollY >= scroll_event.onscroll_offset) {
                isPopupShown = true;
                recentScroll = true;
              }
            }

            if (isPopupShown) {
              DnxteCustomPopup.open(popupConfig);
              setPopupCookie(id);
            }
          }
        });
      } else if ("trigger_on_exit" === data.trigger_event) {
        let exitPopupShown = false;
        let exitIntentCooldown = false;

        document.addEventListener("mousemove", function exitIntentHandler(e) {
          // Check if popup can be shown based on periodicity
          if (!canShowPopup(id)) return;

          // For "every_time" periodicity, allow multiple triggers but with cooldown
          const popupShow = JSON.parse(popup_frontend.dnxte_popup_show);
          const periodicity = popupShow[`popup_perodicity${id}`];

          // If not "every_time", only show once per session
          if (periodicity !== "every_time" && exitPopupShown) return;

          // Prevent rapid firing with cooldown
          if (exitIntentCooldown) return;

          // Get current scroll position
          var scroll = window.pageYOffset || document.documentElement.scrollTop;

          // Trigger on exit intent (mouse moving to top of viewport)
          if (e.pageY - scroll < 7) {
            // Check if this specific exit popup is already showing
            const isThisPopupActive = $(`.dnxte_popup_custom_${id}`).length > 0;

            if (!isThisPopupActive) {
              DnxteCustomPopup.open(popupConfig);
              setPopupCookie(id);
              exitPopupShown = true;
              exitIntentCooldown = true;

              // Set cooldown to prevent rapid firing (3 seconds)
              setTimeout(() => {
                exitIntentCooldown = false;
                // Reset exitPopupShown for "every_time" periodicity
                if (periodicity === "every_time") {
                  exitPopupShown = false;
                }
              }, 3000);

              // Only remove event listener for non-"every_time" periodicity
              if (periodicity !== "every_time") {
                document.removeEventListener("mousemove", exitIntentHandler);
              }
            }
          }
        });
      } else if ("trigger_on_inactivity" === data.trigger_event) {
        let inactivity_event = trigger_event[id];

        // Only set up inactivity timeout if popup can be shown
        if (canShowPopup(id)) {
          setIdleTimeout(
            inactivity_event.oninactivity_delays * 1000,
            function () {
              if (canShowPopup(id)) { // Double check before showing
                DnxteCustomPopup.open(popupConfig);
                setPopupCookie(id);
              }
            },
            function () {
              return false;
            },
          );
        }

        function setIdleTimeout(millis, onIdle, onUnidle) {
          var timeout = 0;
          startTimer();

          function startTimer() {
            timeout = setTimeout(onExpires, millis);
            document.addEventListener("mousemove", onActivity);
            document.addEventListener("keydown", onActivity);
            document.addEventListener("touchstart", onActivity);
          }

          function onExpires() {
            timeout = 0;
            onIdle();
          }

          function onActivity() {
            if (timeout) clearTimeout(timeout);
            else onUnidle();
            //since the mouse is moving, we turn off our event hooks for 1 second
            document.removeEventListener("mousemove", onActivity);
            document.removeEventListener("keydown", onActivity);
            document.removeEventListener("touchstart", onActivity);
            setTimeout(startTimer, 1000);
          }
        }
      }
      return false;
    });
  });

  $.initModules = function () {
    const element = document.querySelector(".et_pb_section");
    if (element) {
      const parent = element.parentElement;
      if (parent) {
        element.style.width = `${parent.offsetWidth}px`;
      }
    }
    if (typeof et_pb_init_global_functions === "function") {
      et_pb_init_global_functions();
    }
    if (typeof et_pb_init_modules === "function") {
      et_pb_init_modules();
    }
  };
})(jQuery);
