/**
 * Image Mask — VB Extension.
 *
 * Re-architected to use NATIVE Divi fields (like the Tooltip extension) instead
 * of a custom JSON-blob field. Every control is a `group-item` under
 * `image_mask.advanced.<field>`, declared via the `divi.moduleLibrary.*` filters.
 *
 * Targets = Image module (divi/image, divi/fullwidth-image) + Section
 * (divi/section) ONLY. SINGLE mask per module: an Image module masks its own
 * image; a Section masks ALL images inside it. The engine config item is always
 * `target_type:'images'` (the engine's itemSelector turns that into hostSel+' img').
 *
 * Two custom fields remain (registered as `dnxte/image-mask-shape` and
 * `dnxte/image-mask-media`) for the visual preset-shape grid and the wp.media
 * picker — both are pure UI, reading/writing a single string attr value.
 *
 * Live preview + front-end run through the shared engine (window.DnxteImageMask),
 * which injects a scoped <style> into the host's own document (iframe in the VB).
 *
 * @package DNXTE
 */
(function () {
  "use strict";

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var React = window.vendor.React;
  var h = wp.element.createElement;
  var element = wp.element;

  var ATTR = "image_mask";
  var TARGET_MODULES = ["divi/image", "divi/fullwidth-image", "divi/section"];
  function isTarget(name) { return TARGET_MODULES.indexOf(name) !== -1; }
  function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

  var PRESET_KEYS = [
    "blob1", "blob2", "blob3", "blob4", "wave1", "wave2", "wave3",
    "circle", "ellipse", "rounded", "hexagon", "octagon", "pentagon",
    "triangle", "diamond", "star", "heart", "arrow", "chevron",
    "diagonal", "cornercut", "blade",
    "squircle", "pill", "arch_window", "leaf", "teardrop", "shield", "flower", "bubble", "cross", "parallelogram", "blob5", "blob6",
    "divi_arch", "divi_bean", "divi_blades", "divi_caret", "divi_chevrons", "divi_corner_blob", "divi_corner_lake", "divi_corner_paint", "divi_corner_pill", "divi_corner_square", "divi_diagonal_bars_2", "divi_diagonal_bars", "divi_diagonal_pills", "divi_diagonal", "divi_ellipse", "divi_floating_squares", "divi_honeycomb", "divi_layer_blob", "divi_paint", "divi_rock_stack", "divi_square_stripes", "divi_triangles", "divi_wave",
  ];

  // ── group ──
  function buildGroup() {
    return {
      groupName: "dnxteImageMask",
      panel: "design",
      priority: 92,
      multiElements: true,
      component: { name: "divi/composite", props: { groupLabel: "Image Mask" } },
    };
  }

  hooks.addFilter("divi.moduleLibrary.moduleSettings.groups", "dnxte-image-mask", function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteImageMask) next.dnxteImageMask = buildGroup();
    return next;
  });

  // ════════════════ custom field components (reused UI bits) ════════════════
  // Read the current desktop string value from a native field's props.value
  // (which Divi passes as { desktop: { value } } | { value } | raw string).
  function readRaw(props) {
    var v = props.value;
    if (v && typeof v === "object") {
      if (v.desktop && v.desktop.value != null) return v.desktop.value;
      if (v.value != null) return v.value;
      return "";
    }
    return v != null ? v : (props.defaultValue || "");
  }
  // Commit a string back through the native field onChange (responsive shape).
  function commitRaw(props, value) {
    if (props.onChange) props.onChange({ event: { target: { value: value } } });
  }

  // Visual preset-shape grid (custom field: dnxte/image-mask-shape).
  function PresetGrid(props) {
    var value = readRaw(props);
    var presets = (window.DnxteImageMask && window.DnxteImageMask.PRESETS) || {};
    return h("div", { className: "dmf" },
      h("div", { className: "dmf-presets" },
        PRESET_KEYS.map(function (key) {
          return h("div", {
            key: key, className: "dmf-preset" + (value === key ? " is-active" : ""), title: key,
            onClick: function () { commitRaw(props, key); },
            dangerouslySetInnerHTML: { __html: presets[key] || "" },
          });
        })));
  }
  PresetGrid.fieldName = "dnxte/image-mask-shape";

  // wp.media mask picker (custom field: dnxte/image-mask-media).
  function MediaButton(props) {
    var value = readRaw(props);
    return h("div", { className: "dmf" },
      h("div", { className: "dmf-control" },
        h("button", { type: "button", className: "dmf-add", style: { marginTop: 0 }, onClick: function () {
          if (!window.wp || !window.wp.media) return;
          var frame = window.wp.media({ title: "Select Mask (SVG or transparent PNG)", button: { text: "Use as Mask" }, multiple: false });
          frame.on("select", function () { var a = frame.state().get("selection").first().toJSON(); commitRaw(props, a.url || ""); });
          frame.open();
        } }, value ? "Change Mask Image" : "Choose from Media Library"),
        value ? h("div", { className: "dmf-note" }, value.split("/").pop()) : null));
  }
  MediaButton.fieldName = "dnxte/image-mask-media";

  function regFields() {
    if (window.divi && window.divi.fieldLibrary && window.divi.fieldLibrary.registerFieldComponent) {
      window.divi.fieldLibrary.registerFieldComponent({ name: "dnxte/image-mask-shape", component: PresetGrid });
      window.divi.fieldLibrary.registerFieldComponent({ name: "dnxte/image-mask-media", component: MediaButton });
    }
  }
  hooks.addAction("divi.moduleLibrary.registerModuleLibraryStore.after", "dnxte-image-mask-field", regFields, 5);
  hooks.addAction("divi.moduleLibrary.registerModuleLibraryStore.before", "dnxte-image-mask-field-early", regFields);

  // ════════════════ conditional-visibility helpers ════════════════
  // Mirror the Tooltip extension signature exactly: each receives the field
  // `props` ({ attrs, ... }) and reads the desktop value off attrs.
  function maskTypeOf(p) {
    return p.attrs && p.attrs[ATTR] && p.attrs[ATTR].advanced && p.attrs[ATTR].advanced.maskType
      && p.attrs[ATTR].advanced.maskType.desktop ? p.attrs[ATTR].advanced.maskType.desktop.value : "preset";
  }
  function isOn(p) {
    return "on" === (p.attrs && p.attrs[ATTR] && p.attrs[ATTR].advanced && p.attrs[ATTR].advanced.enable
      && p.attrs[ATTR].advanced.enable.desktop ? p.attrs[ATTR].advanced.enable.desktop.value : "off");
  }
  function isType(type) { return function (p) { return isOn(p) && maskTypeOf(p) === type; }; }
  var isPreset = isType("preset");
  var isFade = isType("fade");
  var isPattern = isType("pattern");
  var isMedia = isType("media");
  var isSvg = isType("svg");
  var isClipPath = isType("clippath");
  // Invert is meaningless for text / clip-path masks.
  function isInvertable(p) { var t = maskTypeOf(p); return isOn(p) && t !== "text" && t !== "clippath"; }
  function isDrift(p) {
    return isOn(p) && "on" === (p.attrs && p.attrs[ATTR] && p.attrs[ATTR].advanced && p.attrs[ATTR].advanced.drift
      && p.attrs[ATTR].advanced.drift.desktop ? p.attrs[ATTR].advanced.drift.desktop.value : "off");
  }

  // ════════════════ attribute + native-field declarations ════════════════
  hooks.addFilter("divi.moduleLibrary.moduleAttributes", "dnxte-image-mask", function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs[ATTR] = {
      type: "object",
      selector: "{{selector}}",
      default: {
        advanced: {
          enable:       { desktop: { value: "off" } },
          maskType:     { desktop: { value: "preset" } },
          maskShape:    { desktop: { value: "blob1" } },
          fadeDir:      { desktop: { value: "edges" } },
          fadeAmount:   { desktop: { value: "30" } },
          patternType:  { desktop: { value: "dots" } },
          patternScale: { desktop: { value: "24" } },
          mediaUrl:     { desktop: { value: "" } },
          customSvg:    { desktop: { value: "" } },
          clipPath:     { desktop: { value: "" } },
          invert:       { desktop: { value: "off" } },
          scale:        { desktop: { value: "100" } },
          posX:         { desktop: { value: "0" } },
          posY:         { desktop: { value: "0" } },
          rotation:     { desktop: { value: "0" } },
          drift:        { desktop: { value: "off" } },
          driftSpeed:   { desktop: { value: "8" } },
          brightness:   { desktop: { value: "100" } },
          contrast:     { desktop: { value: "100" } },
          saturate:     { desktop: { value: "100" } },
          disableTablet:{ desktop: { value: "off" } },
          disablePhone: { desktop: { value: "off" } },
        },
      },
      settings: {
        advanced: {
          // ─── Core ───
          enable: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.enable", label: "Enable Image Mask",
            groupSlug: "dnxteImageMask", priority: 1, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/toggle" },
          }},
          maskType: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.maskType", label: "Mask Type",
            groupSlug: "dnxteImageMask", priority: 5, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/select", props: { options: {
              "preset":   { label: "Preset Shape" },
              "fade":     { label: "Fade / Gradient" },
              "pattern":  { label: "Pattern" },
              "media":    { label: "Media Library" },
              "svg":      { label: "Custom SVG" },
              "clippath": { label: "Clip Path" },
            } } },
            visible: isOn,
          }},

          // ─── Preset shape (custom visual grid) ───
          maskShape: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.maskShape", label: "Mask Shape",
            groupSlug: "dnxteImageMask", priority: 10, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "dnxte/image-mask-shape" },
            visible: isPreset,
          }},

          // ─── Fade ───
          fadeDir: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.fadeDir", label: "Fade Direction",
            groupSlug: "dnxteImageMask", priority: 11, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/select", props: { options: {
              "edges":  { label: "Edges (vignette)" },
              "radial": { label: "Radial" },
              "top":    { label: "Fade Top" },
              "bottom": { label: "Fade Bottom" },
              "left":   { label: "Fade Left" },
              "right":  { label: "Fade Right" },
            } } },
            visible: isFade,
          }},
          fadeAmount: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.fadeAmount", label: "Fade Amount",
            groupSlug: "dnxteImageMask", priority: 12, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 0, max: 80, step: 1, defaultUnit: "%" } },
            visible: isFade,
          }},

          // ─── Pattern ───
          patternType: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.patternType", label: "Pattern",
            groupSlug: "dnxteImageMask", priority: 13, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/select", props: { options: {
              "dots":    { label: "Dots" },
              "stripes": { label: "Diagonal Stripes" },
              "grid":    { label: "Grid" },
              "checker": { label: "Checkerboard" },
            } } },
            visible: isPattern,
          }},
          patternScale: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.patternScale", label: "Pattern Scale",
            groupSlug: "dnxteImageMask", priority: 14, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 6, max: 80, step: 1, defaultUnit: "px" } },
            visible: isPattern,
          }},

          // ─── Media Library (custom wp.media picker) ───
          mediaUrl: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.mediaUrl", label: "Mask Image / SVG",
            groupSlug: "dnxteImageMask", priority: 19, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "dnxte/image-mask-media" },
            visible: isMedia,
          }},

          // ─── Custom SVG ───
          customSvg: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.customSvg", label: "Custom SVG markup",
            groupSlug: "dnxteImageMask", priority: 20, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/textarea" },
            visible: isSvg,
          }},

          // ─── Clip Path ───
          clipPath: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.clipPath", label: "Clip Path (CSS)",
            description: "circle(50%) | polygon(…)",
            groupSlug: "dnxteImageMask", priority: 21, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/text" },
            visible: isClipPath,
          }},

          // ─── Invert ───
          invert: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.invert", label: "Invert Mask",
            groupSlug: "dnxteImageMask", priority: 22, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/toggle" },
            visible: isInvertable,
          }},

          // ─── Transform ───
          scale: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.scale", label: "Scale",
            groupSlug: "dnxteImageMask", priority: 30, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 50, max: 200, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},
          posX: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.posX", label: "Position X",
            groupSlug: "dnxteImageMask", priority: 31, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: -50, max: 50, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},
          posY: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.posY", label: "Position Y",
            groupSlug: "dnxteImageMask", priority: 32, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: -50, max: 50, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},
          rotation: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.rotation", label: "Rotation",
            groupSlug: "dnxteImageMask", priority: 33, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 0, max: 360, step: 1, defaultUnit: "deg" } },
            visible: isOn,
          }},

          // ─── Animation ───
          drift: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.drift", label: "Mask Drift (subtle motion)",
            groupSlug: "dnxteImageMask", priority: 40, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/toggle" },
            visible: isOn,
          }},
          driftSpeed: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.driftSpeed", label: "Drift Speed",
            groupSlug: "dnxteImageMask", priority: 41, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 2, max: 20, step: 0.5, defaultUnit: "s" } },
            visible: isDrift,
          }},

          // ─── Filters ───
          brightness: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.brightness", label: "Brightness",
            groupSlug: "dnxteImageMask", priority: 60, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 0, max: 200, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},
          contrast: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.contrast", label: "Contrast",
            groupSlug: "dnxteImageMask", priority: 61, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 0, max: 200, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},
          saturate: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.saturate", label: "Saturation",
            groupSlug: "dnxteImageMask", priority: 62, render: true,
            features: { sticky: false },
            component: { type: "field", name: "divi/range", props: { min: 0, max: 200, step: 1, defaultUnit: "%" } },
            visible: isOn,
          }},

          // ─── Responsive: turn the whole mask off per device ───
          disableTablet: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.disableTablet", label: "Disable on Tablet",
            groupSlug: "dnxteImageMask", priority: 70, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/toggle" },
            visible: isOn,
          }},
          disablePhone: { groupType: "group-item", item: {
            attrName: ATTR + ".advanced.disablePhone", label: "Disable on Phone",
            groupSlug: "dnxteImageMask", priority: 71, render: true,
            features: { sticky: false, hover: false, responsive: false },
            component: { type: "field", name: "divi/toggle" },
            visible: isOn,
          }},
        },
      },
    };

    if (meta && typeof meta === "object") {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteImageMask) meta.settings.groups.dnxteImageMask = buildGroup();
    }
    return attrs;
  });

  // ════════════════ build engine "item" from native attrs ════════════════
  // Read a desktop value off the image_mask.advanced.<field> attr.
  function dv(adv, field, fallback) {
    var f = adv && adv[field];
    var v = f && f.desktop ? f.desktop.value : undefined;
    return v != null && v !== "" ? v : fallback;
  }
  // Raw tablet/phone value (null when unset) — for responsive transform fields.
  function dvDev(adv, field, device) {
    var f = adv && adv[field];
    var v = f && f[device] ? f[device].value : undefined;
    return v != null && v !== "" ? v : null;
  }

  function buildItem(attrs) {
    var root = attrs && attrs[ATTR];
    var adv = (root && root.advanced) || {};
    return {
      enabled: dv(adv, "enable", "off"),
      target_type: "images",
      maskType: dv(adv, "maskType", "preset"),
      maskPreset: dv(adv, "maskShape", "blob1"),
      customSvg: dv(adv, "customSvg", ""),
      clipPath: dv(adv, "clipPath", ""),
      invert: dv(adv, "invert", "off"),
      scale: num(dv(adv, "scale", 100), 100),
      posX: num(dv(adv, "posX", 0), 0),
      posY: num(dv(adv, "posY", 0), 0),
      rotation: num(dv(adv, "rotation", 0), 0),
      scaleTablet: dvDev(adv, "scale", "tablet"), scalePhone: dvDev(adv, "scale", "phone"),
      posXTablet: dvDev(adv, "posX", "tablet"), posXPhone: dvDev(adv, "posX", "phone"),
      posYTablet: dvDev(adv, "posY", "tablet"), posYPhone: dvDev(adv, "posY", "phone"),
      rotationTablet: dvDev(adv, "rotation", "tablet"), rotationPhone: dvDev(adv, "rotation", "phone"),
      fadeDir: dv(adv, "fadeDir", "edges"),
      fadeAmount: num(dv(adv, "fadeAmount", 30), 30),
      patternType: dv(adv, "patternType", "dots"),
      patternScale: num(dv(adv, "patternScale", 24), 24),
      mediaUrl: dv(adv, "mediaUrl", ""),
      drift: dv(adv, "drift", "off"),
      driftSpeed: num(dv(adv, "driftSpeed", 8), 8),
      filters: {
        brightness: num(dv(adv, "brightness", 100), 100),
        contrast: num(dv(adv, "contrast", 100), 100),
        saturate: num(dv(adv, "saturate", 100), 100),
      },
      disableTablet: dv(adv, "disableTablet", "off"),
      disablePhone: dv(adv, "disablePhone", "off"),
    };
  }

  // ════════════════ live preview (EffectInjector → scoped <style>) ════════════════
  function EffectInjector(props) {
    var ref = React.useRef(null);
    var hostRef = React.useRef(null);
    var raw = props.config || "";

    function getHostEl() {
      if (!ref.current) return null;
      var el = ref.current.parentElement;
      while (el) {
        if (
          el.classList.contains("et_pb_module") ||
          el.classList.contains("et_pb_row") ||
          el.classList.contains("et_pb_section") ||
          el.classList.contains("et_pb_column") ||
          el.dataset.diviRenderer
        ) { return el; }
        el = el.parentElement;
      }
      return ref.current.parentElement;
    }

    React.useEffect(function () {
      if (!window.DnxteImageMask) return;
      var cancelled = false;

      function apply(tries) {
        if (cancelled) return;
        var host = getHostEl();
        // The order class may not be present yet right after a reload — retry.
        if (!host) { if (tries > 0) setTimeout(function () { apply(tries - 1); }, 80); return; }
        hostRef.current = host;
        var cfg;
        try { cfg = raw ? JSON.parse(raw) : { items: [] }; } catch (e) { cfg = { items: [] }; }
        // Driven ENTIRELY by the config — an item with enabled:"off" makes the
        // engine emit no CSS (the scoped <style> is removed). So there is no
        // fragile unmount-clear: the mask survives hover / re-render / reload, and
        // disabling it (or deleting the module) is handled by re-applying.
        window.DnxteImageMask.applyConfig(host, cfg, true); // true = VB-canvas selectors
      }

      var timer = setTimeout(function () { apply(10); }, 50);

      return function () { cancelled = true; clearTimeout(timer); };
    }, [raw]);

    return element.createElement("span", {
      ref: ref,
      "data-dnxte-mask-injector": "",
      style: { display: "none", position: "absolute", pointerEvents: "none" },
    });
  }

  hooks.addFilter("divi.module.wrapper.render", "dnxte-image-mask", function (moduleWrapper, param) {
    if (!isTarget(param.name)) return moduleWrapper;

    // Always attach the injector for a target module. The config carries the
    // enabled flag — when off, the engine emits nothing. This keeps the preview
    // purely config-driven (no flicker/disappear on hover or reload).
    var item = buildItem(param.attrs);
    var raw = JSON.stringify({ items: [item] });
    var children = moduleWrapper.props.children;
    var childArray = Array.isArray(children) ? children : [children];
    var injector = element.createElement(EffectInjector, { key: "dnxte-image-mask-injector", config: raw });
    return element.cloneElement(moduleWrapper, {}, childArray.concat([injector]));
  });
})();
