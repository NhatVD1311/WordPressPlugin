/**
 * Live Copy — Frontend Button
 *
 * Shows a floating "Live Copy" button on sections that have
 * data-dnxte-livecopy attribute. On click, fetches demo JSON
 * via AJAX and copies it to the system clipboard.
 */
(function () {
  'use strict';

  var config = window.dnxteLiveCopy;
  if (!config || !config.restUrl) return;

  var sections = document.querySelectorAll('[data-dnxte-livecopy-post]');
  if (!sections.length) return;

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    // Fallback for insecure contexts (http://).
    return new Promise(function (resolve, reject) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.top = '-9999px';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      try {
        var ok = document.execCommand('copy');
        document.body.removeChild(ta);
        ok ? resolve() : reject(new Error('execCommand copy failed'));
      } catch (e) {
        document.body.removeChild(ta);
        reject(e);
      }
    });
  }

  function createButton() {
    var btn = document.createElement('button');
    btn.className = 'dnxte-live-copy-btn';
    // Static SVG + label — no user input, safe to set as innerHTML
    btn.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>' +
      '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>' +
      '</svg>' +
      '<span>Live Copy</span>';
    btn.setAttribute('type', 'button');
    return btn;
  }

  sections.forEach(function (section) {
    var postId = parseInt(section.getAttribute('data-dnxte-livecopy-post'), 10);
    var index = parseInt(section.getAttribute('data-dnxte-livecopy-index'), 10);
    if (!postId || isNaN(index)) return;

    var position = window.getComputedStyle(section).position;
    if (position === 'static') {
      section.style.position = 'relative';
    }

    var btn = createButton();
    section.appendChild(btn);

    var isCopying = false;
    // Captured once — reading it per-click can capture a transient
    // "Copied!"/"Failed!" label and make it stick permanently.
    var span = btn.querySelector('span');
    var originalText = span.textContent;
    var revertTimer = null;

    function showStatus(className, label) {
      btn.classList.remove('dnxte-live-copy-loading');
      btn.classList.remove('dnxte-live-copy-success');
      btn.classList.remove('dnxte-live-copy-error');
      btn.classList.add(className);
      span.textContent = label;

      if (revertTimer) clearTimeout(revertTimer);
      revertTimer = setTimeout(function () {
        revertTimer = null;
        btn.classList.remove(className);
        span.textContent = originalText;
      }, 2000);
    }

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      if (isCopying) return;
      isCopying = true;

      btn.classList.add('dnxte-live-copy-loading');

      fetch(config.restUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': config.nonce,
        },
        body: JSON.stringify({ post_id: postId, index: index }),
      })
        .then(function (res) {
          if (!res.ok) throw new Error('Failed to fetch demo: ' + res.status);
          return res.json();
        })
        .then(function (result) {
          if (!result.success || !result.data) {
            throw new Error('Invalid response');
          }
          return copyText(result.data);
        })
        .then(function () {
          showStatus('dnxte-live-copy-success', 'Copied!');
        })
        .catch(function (err) {
          console.error('[LiveCopy] Error:', err);
          showStatus('dnxte-live-copy-error', 'Failed!');
        })
        .finally(function () {
          isCopying = false;
        });
    });
  });
})();
