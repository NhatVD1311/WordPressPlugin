jQuery(document).ready(function ($) {
  var animationDelay = 2500,
    loadingBarDelay = 3800,
    loadingBarRemove = loadingBarDelay - 3000,
    letterAnimationDelay = 50,
    letterRevealDelay = 150,
    typeTransitionSpeed = 500,
    typeAnimationDelay = typeTransitionSpeed + 800,
    clipAnimationSpeed = 600,
    clipAnimationDelay = 1500;

  function hideWord($word) {
    var nextWord = getNextWord($word);
    var wrapper = $word.parents(".dnxt-words-wrapper");
    var parentHeadline = $word.parents(".dnxt-headline");

    if (parentHeadline.hasClass("type")) {
      var parentSpan = $word.parent(".dnxt-words-wrapper");
      parentSpan.addClass("selected").removeClass("waiting");

      setTimeout(function () {
        parentSpan.removeClass("selected");
        $word.removeClass("is-visible").addClass("is-hidden");
        $word.children("i").removeClass("in").addClass("out");
      }, typeTransitionSpeed);

      setTimeout(function () {
        showWord(nextWord);
      }, typeAnimationDelay);
    } else if (parentHeadline.hasClass("letters")) {
      var isLonger =
        $word.children("i").length >= nextWord.children("i").length;

      // Temporarily expand wrapper so both old and new letters have room during transition,
      // then shrink to the new word's width once letters finish animating.
      var $lettersWrapper = $word.parent(".dnxt-words-wrapper");
      var oldW = $word.data("word-width") || 0;
      var newW = nextWord.data("word-width") || 0;
      $lettersWrapper.css("width", Math.max(oldW, newW));
      var letterCount = Math.max($word.children("i").length, nextWord.children("i").length);
      var lettersDuration = letterCount * letterAnimationDelay + 600;
      setTimeout(function () {
        $lettersWrapper.css("width", newW || oldW);
      }, lettersDuration);

      // Swap is-visible/is-hidden so the wrapper's intrinsic height tracks the newly-shown word.
      // Sweep all siblings first so that parallel hideWord chains (React's double useEffect
      // dispatches two cycles) cannot leave more than one <b> with is-visible.
      $lettersWrapper.children().removeClass("is-visible").addClass("is-hidden");
      nextWord.removeClass("is-hidden").addClass("is-visible");

      hideLetter($word.find("i").eq(0), $word, isLonger);
      showLetter(nextWord.find("i").eq(0), nextWord, isLonger);
    } else if (parentHeadline.hasClass("clip")) {
      wrapper.animate({ width: "2px" }, clipAnimationSpeed, function () {
        switchWord($word, nextWord);
        showWord(nextWord);
      });
    } else if (parentHeadline.hasClass("loading-bar")) {
      wrapper.removeClass("is-loading");

      setTimeout(function () {
        switchWord($word, nextWord);
        hideWord(nextWord);
      }, loadingBarDelay);

      setTimeout(function () {
        wrapper.addClass("is-loading");
      }, loadingBarRemove);
    } else {
      switchWord($word, nextWord);
      setTimeout(function () {
        hideWord(nextWord);
      }, animationDelay);
    }
  }

  function showWord($word) {
    if ($word.parents(".dnxt-headline").hasClass("type")) {
      showLetter($word.find("i").eq(0), $word, false);
      $word.addClass("is-visible").removeClass("is-hidden");
    } else if ($word.parents(".dnxt-headline").hasClass("clip")) {
      var clipWidth = $word.data("word-width") || $word.width();
      $word
        .parents(".dnxt-words-wrapper")
        .animate(
          { width: clipWidth + 10 },
          clipAnimationSpeed,
          function () {
            setTimeout(function () {
              hideWord($word);
            }, clipAnimationDelay);
          }
        );
    }
  }

  function hideLetter($letter, $word, isLonger) {
    $letter.removeClass("in").addClass("out");

    if (!$letter.is(":last-child")) {
      setTimeout(function () {
        hideLetter($letter.next(), $word, isLonger);
      }, letterAnimationDelay);
    } else if (isLonger) {
      setTimeout(function () {
        hideWord(getNextWord($word));
      }, animationDelay);
    }

    if ($letter.is(":last-child") && $("html").hasClass("no-csstransitions")) {
      var nextWord = getNextWord($word);
      switchWord($word, nextWord);
    }
  }

  function showLetter($letter, $word, isLonger) {
    $letter.addClass("in").removeClass("out");

    if (!$letter.is(":last-child")) {
      setTimeout(function () {
        showLetter($letter.next(), $word, isLonger);
      }, letterAnimationDelay);
    } else {
      if ($word.parents(".dnxt-headline").hasClass("type")) {
        setTimeout(function () {
          $word.parents(".dnxt-words-wrapper").addClass("waiting");
        }, 200);
      }
      if (!isLonger) {
        setTimeout(function () {
          hideWord($word);
        }, animationDelay);
      }
    }
  }

  function getNextWord($word) {
    return !$word.is(":last-child")
      ? $word.next()
      : $word.parent().children().eq(0);
  }

  function switchWord($oldWord, $newWord) {
    $oldWord.removeClass("is-visible").addClass("is-hidden");
    $newWord.removeClass("is-hidden").addClass("is-visible");
    // Update wrapper width to match the incoming word.
    // Skip: clip (manages its own collapse/expand animation) and
    //        letters (both words visible simultaneously — needs fixed max width).
    var $headline = $newWord.parents(".dnxt-headline");
    if (!$headline.hasClass("clip") && !$headline.hasClass("letters")) {
      var $wrapper = $newWord.parent(".dnxt-words-wrapper");
      var newWidth = $newWord.data("word-width");
      if (newWidth) {
        $wrapper.css("width", newWidth);
      }
    }
  }

  $(".dnxt-headline.letters")
    .find("b")
    .each(function () {
      var $word = $(this),
        letters = $word.text().split(""),
        isVisible = $word.hasClass("is-visible");
      for (var i in letters) {
        if ($word.parents(".rotate-2").length > 0)
          letters[i] = "<em>" + letters[i] + "</em>";
        letters[i] = isVisible
          ? '<i class="in">' + letters[i] + "</i>"
          : "<i>" + letters[i] + "</i>";
      }
      var newLetters = letters.join("");
      $word.html(newLetters).css("opacity", 1);
    });

  $(".dnxt-headline").each(function () {
    var $headline = $(this);

    // Measure every word's natural width and cache it, regardless of effect type.
    // This is needed so switchWord() can look up the width of any incoming word.
    if (!$headline.hasClass("type")) {
      var $words = $headline.find(".dnxt-words-wrapper b"),
        maxWidth = 0,
        firstVisibleWidth = 0;

      $words.each(function () {
        var $el = $(this);
        $el.css({ position: "relative", left: "auto", right: "auto" });
        // Round up so the wrapper width never subpixel-underflows the rendered
        // inline-block letters (which would force them to wrap to new lines).
        var wordWidth = Math.ceil($el[0].getBoundingClientRect().width);
        $el.css({ position: "", left: "", right: "" });
        $el.data("word-width", wordWidth);
        if ($el.hasClass("is-visible")) firstVisibleWidth = wordWidth;
        if (wordWidth > maxWidth) maxWidth = wordWidth;
      });

      var $wrapper = $headline.find(".dnxt-words-wrapper");

      if ($headline.hasClass("clip")) {
        // Clip starts slightly wider than current word; showWord() animates to new word width.
        $wrapper.css("width", ($wrapper.width() || firstVisibleWidth) + 10);
      } else if ($headline.hasClass("letters")) {
        // Spiral / Swirl / Flow: start at current word's width.
        // hideWord() will temporarily expand to max(old, new) during letter transitions.
        $wrapper.css("width", firstVisibleWidth || maxWidth);
      } else if ($headline.hasClass("loading-bar")) {
        // Loading Bar: start at current word's width; switchWord() updates on change.
        $wrapper.css("width", firstVisibleWidth || maxWidth);
        setTimeout(function () {
          $wrapper.addClass("is-loading");
        }, loadingBarRemove);
      } else {
        // Flip, Slide, Drop In, Push, and any future effects:
        // start at current word's width; switchWord() smoothly updates on each change.
        $wrapper.css("width", firstVisibleWidth || maxWidth);
      }
    }

    setTimeout(function () {
      hideWord($headline.find(".is-visible").eq(0));
    }, animationDelay);
  });
});
