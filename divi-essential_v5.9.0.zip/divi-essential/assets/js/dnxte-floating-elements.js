/**
 * Floating Elements — GSAP Frontend Animation
 * EXACT same animation logic as VB (dnxte-floating-extension.js).
 * Auto-discovers .dnxte-floating-elements-container[data-float-y-range].
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  if (typeof gsap === 'undefined') return;
  if (typeof ScrollTrigger !== 'undefined') gsap.registerPlugin(ScrollTrigger);

  /**
   * Apply floating animation to a single DOM node.
   * This is the EXACT same logic used in the VB extension.
   *
   * @param {Element} node  - DOM element to animate
   * @param {Object}  item  - Item config from data attributes
   * @param {number}  index - Item index (for stagger)
   */
  function applyFloatingAnimation(node, item, index) {
    var preset    = item.preset || 'gentle-float';
    var useCustom = item.useCustom;
    var dur       = parseFloat(item.duration || 6);
    var yR        = parseFloat(item.yRange || 30);
    var xR        = parseFloat(item.xRange || 25);
    var rotR      = parseFloat(item.rotRange || 8);
    var ease      = item.easing || 'sine.inOut';
    var delay     = parseFloat(item.delay || 0) + index * 0.15;
    var sc        = parseFloat(item.scale || 1.02);

    // Entrance
    gsap.fromTo(node,
      { opacity: 0, scale: 0.9 },
      { opacity: 1, scale: 1, duration: 1, delay: index * 0.15, ease: 'power3.out' }
    );

    if (useCustom) {
      var dir = item.direction || 'both';
      if (dir === 'both' || dir === 'vertical')
        gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: ease, delay: delay });
      if (dir === 'both' || dir === 'horizontal')
        gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur * 1.2, repeat: -1, yoyo: true, ease: ease, delay: delay });
      if (dir === 'diagonal')
        gsap.to(node, { x: gsap.utils.random(-xR, xR), y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: ease, delay: delay });
      if (rotR > 0)
        gsap.to(node, { rotation: gsap.utils.random(-rotR, rotR), duration: dur * 1.5, repeat: -1, yoyo: true, ease: ease });
      gsap.to(node, { scale: gsap.utils.random(0.98, sc), duration: dur * 0.6, repeat: -1, yoyo: true, ease: 'power1.inOut' });
      var opMin = parseFloat(item.opacityMin || 1);
      if (opMin < 1)
        gsap.to(node, { opacity: opMin, duration: dur * 0.5, repeat: -1, yoyo: true, ease: 'sine.inOut' });
    } else {
      switch (preset) {
        case 'orbit':
          var radius = Math.max(xR, yR);
          var a = gsap.utils.random(0, Math.PI * 2);
          gsap.to(node, {
            keyframes: [
              { x: Math.cos(a) * radius, y: Math.sin(a) * radius * 0.6 },
              { x: Math.cos(a + Math.PI/2) * radius, y: Math.sin(a + Math.PI/2) * radius * 0.6 },
              { x: Math.cos(a + Math.PI) * radius, y: Math.sin(a + Math.PI) * radius * 0.6 },
              { x: Math.cos(a + Math.PI*1.5) * radius, y: Math.sin(a + Math.PI*1.5) * radius * 0.6 },
              { x: Math.cos(a) * radius, y: Math.sin(a) * radius * 0.6 }
            ],
            duration: dur, repeat: -1, ease: 'none', delay: delay
          });
          break;
        case 'bounce':
          gsap.to(node, { y: -yR, duration: dur * 0.4, repeat: -1, yoyo: true, ease: 'bounce.out', delay: delay });
          gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur * 1.5, repeat: -1, yoyo: true, ease: 'sine.inOut' });
          break;
        case 'sway':
          gsap.to(node, { rotation: gsap.utils.random(-rotR*2, rotR*2), duration: dur, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay, transformOrigin: '50% 0%' });
          gsap.to(node, { x: gsap.utils.random(-xR*1.5, xR*1.5), duration: dur*0.8, repeat: -1, yoyo: true, ease: 'sine.inOut' });
          break;
        case 'zigzag':
          gsap.to(node, {
            keyframes: [
              { x: xR, y: -yR*0.5, duration: dur*0.5 },
              { x: -xR, y: -yR, duration: dur*0.5 },
              { x: xR, y: -yR*1.5, duration: dur*0.5 },
              { x: 0, y: 0, duration: dur*0.5 }
            ], repeat: -1, ease: 'sine.inOut', delay: delay
          });
          break;
        case 'pulse':
          gsap.to(node, { scale: sc+0.1, duration: dur*0.3, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay });
          gsap.to(node, { y: gsap.utils.random(-yR*0.4, yR*0.4), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut' });
          gsap.to(node, { opacity: 0.6, duration: dur*0.3, repeat: -1, yoyo: true, ease: 'power1.inOut' });
          break;
        case 'drift':
          gsap.to(node, { x: gsap.utils.random(-xR*2, xR*2), duration: dur*2, repeat: -1, yoyo: true, ease: 'none', delay: delay });
          gsap.to(node, { y: gsap.utils.random(-yR*2, yR*2), duration: dur*2.5, repeat: -1, yoyo: true, ease: 'none' });
          gsap.to(node, { rotation: gsap.utils.random(-rotR, rotR), duration: dur*3, repeat: -1, yoyo: true, ease: 'none' });
          break;
        case 'spin-float':
          gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: delay });
          gsap.to(node, { rotation: 360, duration: dur*2, repeat: -1, ease: 'none' });
          break;
        case 'pendulum':
          gsap.to(node, { rotation: gsap.utils.random(-rotR*3, rotR*3), duration: dur*0.7, repeat: -1, yoyo: true, ease: 'power2.inOut', delay: delay, transformOrigin: '50% 0%' });
          break;
        case 'elastic-pop':
          gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'back.inOut(1.2)', delay: delay+0.8 });
          gsap.to(node, { x: gsap.utils.random(-xR, xR), duration: dur*1.3, repeat: -1, yoyo: true, ease: 'back.inOut(1)', delay: delay+0.8 });
          break;
        default: // gentle-float
          gsap.to(node, { y: gsap.utils.random(-yR, yR), duration: dur, repeat: -1, yoyo: true, ease: 'sine.inOut', delay: delay });
          gsap.to(node, { x: gsap.utils.random(-xR*0.5, xR*0.5), duration: dur*1.3, repeat: -1, yoyo: true, ease: 'sine.inOut' });
          gsap.to(node, { scale: gsap.utils.random(0.98, sc), duration: dur*0.6, repeat: -1, yoyo: true, ease: 'power1.inOut' });
          break;
      }
    }

    // 3D
    if (item.use3d) {
      var rxR = parseFloat(item.rotateXRange || 10);
      var ryR = parseFloat(item.rotateYRange || 20);
      gsap.to(node, { rotateX: gsap.utils.random(-rxR, rxR), rotateY: gsap.utils.random(-ryR, ryR), duration: dur*2, repeat: -1, yoyo: true, ease: 'sine.inOut' });
    }
  }

  // ───────────────────────────────────────────────────────────
  // Read per-item config from data attributes
  // ───────────────────────────────────────────────────────────
  function readItemConfig(el) {
    var d = el.dataset;
    return {
      preset:       d.floatPreset || 'gentle-float',
      useCustom:    d.floatCustom === 'true',
      yRange:       d.floatItemY || '30',
      xRange:       d.floatItemX || '25',
      rotRange:     d.floatItemRot || '8',
      duration:     d.floatItemDuration || '6',
      delay:        d.floatItemDelay || '0',
      easing:       d.floatItemEasing || 'sine.inOut',
      direction:    d.floatItemDirection || 'both',
      scale:        d.floatItemScale || '1.02',
      opacityMin:   d.floatItemOpacityMin || '1',
      use3d:        d.floatItem3d === 'true',
      rotateXRange: d.floatItemRx || '10',
      rotateYRange: d.floatItemRy || '20',
    };
  }

  // ───────────────────────────────────────────────────────────
  // Main class
  // ───────────────────────────────────────────────────────────
  class DnxteFloatingElements {
    constructor(container) {
      this.container = container;
      this.items = container.querySelectorAll('.dnxte-floating-element-item');
      if (!this.items.length) return;

      this._listeners = [];
      this._rafs = [];

      this._initAnimations();
      this._initScrollParallax();
      this._initMouseParallax();
    }

    _initAnimations() {
      var self = this;
      this.items.forEach(function (node, i) {
        var itemCfg = readItemConfig(node);
        applyFloatingAnimation(node, itemCfg, i);
      });
    }

    _initScrollParallax() {
      if (typeof ScrollTrigger === 'undefined') return;
      var section = this.container.closest('.et_pb_section') || this.container.parentElement;

      this.items.forEach(function (item, i) {
        var speed = ((i % 3) + 1) * 0.15;
        gsap.to(item, {
          yPercent: -30 * speed, ease: 'none',
          scrollTrigger: { trigger: section, start: 'top bottom', end: 'bottom top', scrub: 1 },
        });
      });
    }

    _initMouseParallax() {
      var self = this;
      var mx = 0, my = 0, cx = 0, cy = 0;

      var onMove = function (e) {
        mx = (e.clientX - window.innerWidth / 2) / window.innerWidth;
        my = (e.clientY - window.innerHeight / 2) / window.innerHeight;
      };
      document.addEventListener('mousemove', onMove);
      this._listeners.push(['mousemove', onMove]);

      function update() {
        cx += (mx - cx) * 0.05;
        cy += (my - cy) * 0.05;
        var section = self.container.closest('.et_pb_section') || self.container.parentElement;
        var rect = section.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          self.items.forEach(function (item, i) {
            var depth = ((i % 4) + 1) * 8;
            gsap.to(item, {
              x: '+=' + cx * depth * 0.1, y: '+=' + cy * depth * 0.1,
              duration: 0.3, ease: 'power2.out', overwrite: 'auto',
            });
          });
        }
        self._rafs.push(requestAnimationFrame(update));
      }
      self._rafs.push(requestAnimationFrame(update));
    }

    destroy() {
      this.items.forEach(function (node) { gsap.killTweensOf(node); });
      this._rafs.forEach(function (id) { cancelAnimationFrame(id); });
      this._listeners.forEach(function (e) { document.removeEventListener(e[0], e[1]); });
      this._rafs = []; this._listeners = [];
    }
  }

  // Auto-init
  function init() {
    document.querySelectorAll('.dnxte-floating-elements-container[data-float-y-range]').forEach(function (el) {
      if (!el._dnxteFloating) { el._dnxteFloating = new DnxteFloatingElements(el); }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }

  // Expose for VB use too
  window.DnxteFloatingElements = DnxteFloatingElements;
  window.dnxteApplyFloatingAnimation = applyFloatingAnimation;
})();
