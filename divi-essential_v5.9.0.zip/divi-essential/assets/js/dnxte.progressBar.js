(function() {
    'use strict';

    /**
     * Progress Bar Frontend Script
     * Handles scroll-based progress tracking for entire page or specific selectors
     * Supports custom scroll containers like SimpleBar
     */

    /**
     * Find the actual scrolling container
     * Checks for custom scroll libraries (SimpleBar, etc.) and returns the appropriate element
     */
    function getScrollContainer() {
        // Check for SimpleBar scroll container - if it exists with overflow:scroll, use it
        var simpleBarWrapper = document.querySelector('.simplebar-content-wrapper');
        if (simpleBarWrapper) {
            var style = window.getComputedStyle(simpleBarWrapper);
            // SimpleBar sets overflow to 'scroll' or 'auto' on this element
            if (style.overflowY === 'scroll' || style.overflowY === 'auto' ||
                style.overflow === 'scroll' || style.overflow === 'auto') {
                return simpleBarWrapper;
            }
        }

        // Check for other common custom scroll containers
        var customScrollSelectors = [
            '[data-simplebar] .simplebar-content-wrapper',
            '.ps-container', // Perfect Scrollbar
            '.ps', // Perfect Scrollbar v2
            '.mCustomScrollBox', // mCustomScrollbar
            '.os-viewport', // OverlayScrollbars
            '.nano-content', // nanoScroller
            '.scroll-content' // Generic
        ];

        for (var i = 0; i < customScrollSelectors.length; i++) {
            var customContainer = document.querySelector(customScrollSelectors[i]);
            if (customContainer) {
                var containerStyle = window.getComputedStyle(customContainer);
                if (containerStyle.overflowY === 'scroll' || containerStyle.overflowY === 'auto' ||
                    containerStyle.overflow === 'scroll' || containerStyle.overflow === 'auto') {
                    return customContainer;
                }
            }
        }

        // Fallback: find any element with overflow scroll/auto that is scrollable
        var scrollableElements = document.querySelectorAll('body > div, #page, #wrapper, .site-content, main, [style*="overflow"]');
        for (var j = 0; j < scrollableElements.length; j++) {
            var el = scrollableElements[j];
            var elStyle = window.getComputedStyle(el);
            if ((elStyle.overflow === 'auto' || elStyle.overflow === 'scroll' ||
                 elStyle.overflowY === 'auto' || elStyle.overflowY === 'scroll') &&
                el.scrollHeight > el.clientHeight) {
                return el;
            }
        }

        return null; // Use window scroll as default
    }

    /**
     * Get scroll position from the appropriate container
     */
    function getScrollTop(scrollContainer) {
        if (scrollContainer) {
            return scrollContainer.scrollTop;
        }
        return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    }

    /**
     * Get total scrollable height
     */
    function getScrollHeight(scrollContainer) {
        if (scrollContainer) {
            return scrollContainer.scrollHeight;
        }
        return Math.max(
            document.body.scrollHeight || 0,
            document.documentElement.scrollHeight || 0,
            document.body.offsetHeight || 0,
            document.documentElement.offsetHeight || 0
        );
    }

    /**
     * Get viewport/client height
     */
    function getClientHeight(scrollContainer) {
        if (scrollContainer) {
            return scrollContainer.clientHeight;
        }
        return window.innerHeight || document.documentElement.clientHeight || 0;
    }

    /**
     * Move fixed position progress bars to body to avoid stacking context issues
     * This fixes conflicts with Divi's fixed header
     */
    function moveFixedBarsToBody() {
        var fixedBars = document.querySelectorAll(
            '.dnxte-bar-position-top_of_page, ' +
            '.dnxte-bar-position-bottom_of_page, ' +
            '.dnxte-bar-position-below_main_menu, ' +
            '.dnxte-circle-fixed, ' +
            '[data-bar-position="top_of_page"], ' +
            '[data-bar-position="bottom_of_page"], ' +
            '[data-bar-position="below_main_menu"]'
        );

        fixedBars.forEach(function(bar) {
            // Find the module container (parent with dnxte_progress_bar class)
            var moduleContainer = bar.closest('.dnxte_progress_bar');
            if (moduleContainer && moduleContainer.parentElement !== document.body) {
                // Move to body to escape stacking context created by Divi's transforms
                document.body.appendChild(moduleContainer);
            }
        });
    }

    function initProgressBars() {
        var containers = document.querySelectorAll('.dnxte-progress-bar-container, .dnxte-progress-circle-wrapper');

        if (!containers.length) {
            return;
        }

        // Detect the scroll container once for all progress bars
        var scrollContainer = getScrollContainer();

        containers.forEach(function(container) {
            // Mark container as initialized to prevent duplicate initialization
            if (container.getAttribute('data-progress-initialized') === 'true') {
                return;
            }
            container.setAttribute('data-progress-initialized', 'true');

            // Get data attributes
            var relativeTo = container.getAttribute('data-relative-to') || 'entire_page';
            var selectorInput = container.getAttribute('data-selector') || '';
            var direction = container.getAttribute('data-direction') || 'left';
            var type = container.getAttribute('data-type') || 'horizontal';
            var circumference = parseFloat(container.getAttribute('data-circumference')) || 0;
            var radius = parseFloat(container.getAttribute('data-radius')) || 0;

            // Only initialize scroll-based progress for entire_page or selector modes
            if (relativeTo !== 'entire_page' && relativeTo !== 'selector') {
                return;
            }

            // For selector mode, require a valid selector
            if (relativeTo === 'selector' && !selectorInput) {
                return;
            }

            /**
             * Try to find element with smart selector matching
             * Tries: original -> #original -> .original
             */
            function findTargetElement(selectorStr) {
                if (!selectorStr) return null;

                var selectorsToTry = [selectorStr];

                // If selector doesn't start with #, ., or [ (attribute selector), try adding prefixes
                if (!/^[#.\[]/.test(selectorStr)) {
                    selectorsToTry.push('#' + selectorStr);  // Try as ID
                    selectorsToTry.push('.' + selectorStr);  // Try as class
                }

                for (var i = 0; i < selectorsToTry.length; i++) {
                    try {
                        var element = document.querySelector(selectorsToTry[i]);
                        if (element) {
                            return element;
                        }
                    } catch (e) {
                        // Invalid selector syntax, continue
                    }
                }

                return null;
            }

            // Cache the target element for selector mode
            var cachedTargetElement = null;
            if (relativeTo === 'selector' && selectorInput) {
                cachedTargetElement = findTargetElement(selectorInput);
            }

            /**
             * Calculate percentage for selector-based progress
             */
            function percentageSeen(element, currentScrollContainer) {
                if (!element) {
                    return 0;
                }

                var viewportHeight = getClientHeight(currentScrollContainer);
                var scrollTop = getScrollTop(currentScrollContainer);
                var elementRect = element.getBoundingClientRect();

                // For custom scroll containers, calculate offset relative to container
                var containerOffset = 0;
                if (currentScrollContainer) {
                    var containerRect = currentScrollContainer.getBoundingClientRect();
                    containerOffset = containerRect.top;
                }

                var elementOffsetTop = elementRect.top - containerOffset + scrollTop;
                var elementHeight = element.offsetHeight;

                // Calculate percentage of the element that's been seen
                var distance = scrollTop + viewportHeight - elementOffsetTop;
                var percentage = Math.round(distance / ((viewportHeight + elementHeight) / 100));

                // Restrict the range to between 0 and 100
                return Math.min(100, Math.max(0, percentage));
            }

            /**
             * Calculate and update progress
             */
            function updateReadingProgress() {
                var w = 0;

                // Get fresh reference to scroll container each time
                var currentScrollContainer = getScrollContainer();

                if (relativeTo === 'entire_page') {
                    var scrollTop = getScrollTop(currentScrollContainer);
                    var scrollHeight = getScrollHeight(currentScrollContainer);
                    var clientHeight = getClientHeight(currentScrollContainer);
                    var scrollableHeight = scrollHeight - clientHeight;

                    if (scrollableHeight > 10) {
                        // Use round and ensure we reach 100% when near the bottom
                        w = Math.round((scrollTop / scrollableHeight) * 100);
                        // Ensure we hit 100% when within 5px of bottom (accounts for browser rounding)
                        if (scrollableHeight - scrollTop <= 5) {
                            w = 100;
                        }
                    } else {
                        // Page is not scrollable or very short - start at 0%
                        // Only show 100% if user is actually at the bottom
                        w = scrollTop > 0 ? 100 : 0;
                    }
                    w = Math.min(100, Math.max(0, w));
                }

                if (relativeTo === 'selector') {
                    // Try to find element again if not cached (in case it was added dynamically)
                    if (!cachedTargetElement) {
                        cachedTargetElement = findTargetElement(selectorInput);
                    }

                    if (cachedTargetElement) {
                        w = percentageSeen(cachedTargetElement, currentScrollContainer);
                    }
                    w = w >= 100 ? 100 : (w < 0 ? 0 : w);
                }

                // Update horizontal progress bar
                if (type === 'horizontal') {
                    var fill = container.querySelector('.dnxte-progress-bar-fill');
                    var tooltip = container.querySelector('.dnxte-progress-tooltip, .dnxte-layout1-tooltip, .dnxte-layout2-tooltip');
                    var percentageText = container.querySelector('.dnxte-layout2-percentage');

                    if (fill) {
                        // Use setProperty with important to override CSS
                        fill.style.setProperty('width', w + '%', 'important');
                    }

                    // Update tooltip text and position
                    if (tooltip) {
                        tooltip.textContent = Math.floor(w) + '%';

                        // Update tooltip position based on direction and layout
                        var isLayout2 = tooltip.classList.contains('dnxte-layout2-tooltip');

                        if (isLayout2) {
                            // Layout 2 - tooltip outside fill bar for both directions
                            if (direction === 'right') {
                                var layout2RightPos = Math.min(100, Math.max(0, 100 - w));
                                tooltip.style.setProperty('left', layout2RightPos + '%', 'important');
                                tooltip.style.setProperty('right', 'auto', 'important');
                                tooltip.style.setProperty('transform', 'translateX(-100%)', 'important');
                            } else {
                                var layout2Pos = Math.max(2, w);
                                tooltip.style.setProperty('left', layout2Pos + '%', 'important');
                                tooltip.style.setProperty('right', 'auto', 'important');
                                tooltip.style.setProperty('transform', 'translateX(-100%)', 'important');
                            }
                        } else {
                            // Layout 1 - clamp between 2-98% with centered transform
                            if (direction === 'right') {
                                tooltip.style.setProperty('left', Math.max(2, Math.min(98, 100 - w)) + '%', 'important');
                                tooltip.style.setProperty('right', 'auto', 'important');
                                tooltip.style.setProperty('transform', 'translateX(-50%)', 'important');
                            } else {
                                tooltip.style.setProperty('left', Math.max(2, Math.min(98, w)) + '%', 'important');
                                tooltip.style.setProperty('right', 'auto', 'important');
                                tooltip.style.setProperty('transform', 'translateX(-50%)', 'important');
                            }
                        }
                    }

                    if (percentageText) {
                        percentageText.textContent = w.toFixed(2) + '%';
                    }
                }

                // Update circular progress bar
                if (type === 'circle') {
                    var progressCircle = container.querySelector('.dnxte-progress-circle-bar');
                    var circlePercentageText = container.querySelector('.dnxte-progress-circle-text');

                    if (progressCircle) {
                        // Use data attributes for circumference if available, otherwise calculate
                        var circleCircumference = circumference || (radius * 2 * Math.PI);
                        if (!circleCircumference && progressCircle.r) {
                            var circleRadius = progressCircle.r.baseVal.value;
                            circleCircumference = circleRadius * 2 * Math.PI;
                        }

                        progressCircle.style.strokeDasharray = circleCircumference;
                        progressCircle.style.strokeDashoffset = circleCircumference - (w / 100) * circleCircumference;
                    }

                    if (circlePercentageText) {
                        circlePercentageText.textContent = Math.floor(w) + '%';
                    }
                }
            }

            // Initial update
            updateReadingProgress();

            // Listen to scroll events - use passive for better performance
            var scrollHandler = function() {
                requestAnimationFrame(updateReadingProgress);
            };

            // Attach scroll listeners to ALL potential scroll sources for maximum compatibility
            // Always attach to window and document
            window.addEventListener('scroll', scrollHandler, { passive: true });
            document.addEventListener('scroll', scrollHandler, { passive: true });

            // Also attach to custom scroll container if found
            if (scrollContainer) {
                scrollContainer.addEventListener('scroll', scrollHandler, { passive: true });
            }

            // Attach to any SimpleBar containers (they might be created after initial detection)
            document.querySelectorAll('.simplebar-content-wrapper').forEach(function(el) {
                el.addEventListener('scroll', function() {
                    scrollHandler();
                }, { passive: true });
            });

            window.addEventListener('resize', scrollHandler, { passive: true });

            // Listen for custom scroll event from SimpleBar handler
            container.addEventListener('progressbar-scroll', function() {
                scrollHandler();
            });
        });
    }

    /**
     * Handle below_main_menu positioning
     * Uses the shared updateBelowMainMenuPosition function
     */
    function initBelowMainMenuPosition() {
        // Find wrappers with below_main_menu position using data attribute or class
        var progressBars = document.querySelectorAll('[data-bar-position="below_main_menu"], .dnxte-bar-position-below_main_menu');
        if (!progressBars.length) {
            return;
        }

        // Initial update
        updateBelowMainMenuPosition();

        // Update on resize and load
        window.addEventListener('resize', function() {
            requestAnimationFrame(updateBelowMainMenuPosition);
        }, { passive: true });
        window.addEventListener('load', updateBelowMainMenuPosition);

        // Detect scroll container and listen to appropriate scroll events
        var scrollContainer = getScrollContainer();
        if (scrollContainer) {
            scrollContainer.addEventListener('scroll', function() {
                requestAnimationFrame(updateBelowMainMenuPosition);
            }, { passive: true });
        } else {
            window.addEventListener('scroll', function() {
                requestAnimationFrame(updateBelowMainMenuPosition);
            }, { passive: true });
        }

        // Also update after delays for Divi builder compatibility
        setTimeout(updateBelowMainMenuPosition, 100);
        setTimeout(updateBelowMainMenuPosition, 500);
        setTimeout(updateBelowMainMenuPosition, 1000);
        setTimeout(updateBelowMainMenuPosition, 2000);
    }

    /**
     * Global scroll handler for SimpleBar - updates all progress bars
     */
    function globalScrollUpdate() {
        // Update progress bar containers
        var containers = document.querySelectorAll('.dnxte-progress-bar-container[data-progress-initialized="true"], .dnxte-progress-circle-wrapper[data-progress-initialized="true"]');
        containers.forEach(function(container) {
            container.dispatchEvent(new CustomEvent('progressbar-scroll'));
        });

        // Also update below_main_menu position bars and circle top position
        updateBelowMainMenuPosition();
        updateCircleTopPosition();
    }

    /**
     * Update position of below_main_menu progress bars
     * Called on scroll to handle sticky headers
     */
    var lastHeaderHeight = 0;
    var lastScrollY = 0;
    var headerUpdatePending = false;

    function updateBelowMainMenuPosition() {
        var progressBars = document.querySelectorAll('[data-bar-position="below_main_menu"], .dnxte-bar-position-below_main_menu');
        if (!progressBars.length) return;

        // Detect scroll direction
        var currentScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
        var isScrollingUp = currentScrollY < lastScrollY;
        lastScrollY = currentScrollY;

        // Get header height - check multiple potential header elements
        var maxBottom = 0;

        // Check WordPress admin bar
        var adminBar = document.getElementById('wpadminbar');
        if (adminBar) {
            var adminRect = adminBar.getBoundingClientRect();
            maxBottom = adminRect.bottom;
        }

        // Check #main-header (Divi 4)
        var mainHeader = document.getElementById('main-header');
        if (mainHeader) {
            var rect = mainHeader.getBoundingClientRect();
            var style = window.getComputedStyle(mainHeader);
            var isFixed = style.position === 'fixed' || style.position === 'sticky' ||
                          mainHeader.classList.contains('et-fixed-header');

            // For fixed/sticky headers, use getBoundingClientRect which gives viewport-relative position
            if (isFixed) {
                if (rect.bottom > 0 && rect.bottom > maxBottom) {
                    maxBottom = rect.bottom;
                }
            } else {
                // Header is not fixed - check if we're at top of page or use rect.bottom
                if (currentScrollY <= 10) {
                    // At or near top of page, use the full header height
                    var headerFullHeight = mainHeader.offsetHeight;
                    if (adminBar) {
                        headerFullHeight += adminBar.offsetHeight;
                    }
                    if (headerFullHeight > maxBottom) {
                        maxBottom = headerFullHeight;
                    }
                } else if (rect.bottom > 0 && rect.bottom > maxBottom) {
                    maxBottom = rect.bottom;
                }
            }
        }

        // Also check for Divi top header bar
        var topHeader = document.getElementById('top-header');
        if (topHeader) {
            var topRect = topHeader.getBoundingClientRect();
            // Top header contributes to the overall header height
            if (topRect.bottom > 0 && topRect.height > 0) {
                // Don't override maxBottom, just ensure it's accounted for
            }
        }

        // Also check .et-l--header (Divi 5)
        var divi5Header = document.querySelector('.et-l--header');
        if (divi5Header) {
            var d5Rect = divi5Header.getBoundingClientRect();
            if (d5Rect.bottom > 0 && d5Rect.bottom > maxBottom) {
                maxBottom = d5Rect.bottom;
            }
        }

        // Fallback to 80px
        var headerHeight = maxBottom > 0 ? Math.round(maxBottom) : 80;

        // Always update position (not just when changed) to handle header animations
        progressBars.forEach(function(progressBar) {
            progressBar.style.setProperty('top', headerHeight + 'px', 'important');
        });

        // When scrolling up, schedule multiple updates to catch header expansion animations
        if (isScrollingUp && !headerUpdatePending) {
            headerUpdatePending = true;

            // Update frequently during upward scroll to catch header transitions
            var updateIntervals = [50, 100, 150, 200, 300, 400, 500];
            updateIntervals.forEach(function(delay) {
                setTimeout(function() {
                    updateBelowMainMenuPosition();
                }, delay);
            });

            // Reset pending flag after all scheduled updates
            setTimeout(function() {
                headerUpdatePending = false;
            }, 600);
        } else if (headerHeight !== lastHeaderHeight && !headerUpdatePending) {
            // For other cases, schedule updates only when height changed
            headerUpdatePending = true;
            setTimeout(function() {
                headerUpdatePending = false;
                updateBelowMainMenuPosition();
            }, 100);
            setTimeout(function() {
                updateBelowMainMenuPosition();
            }, 300);
        }

        lastHeaderHeight = headerHeight;
    }

    /**
     * Update position of top_of_page circle bars below main header
     * Uses the same header detection logic as updateBelowMainMenuPosition
     */
    var circleLastScrollY = 0;
    var circleUpdatePending = false;

    function updateCircleTopPosition() {
        var circles = document.querySelectorAll('.dnxte-circle-position-top_of_page');
        if (!circles.length) return;

        // Detect scroll direction
        var currentScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
        var isScrollingUp = currentScrollY < circleLastScrollY;
        circleLastScrollY = currentScrollY;

        var maxBottom = 0;

        // Check WordPress admin bar
        var adminBar = document.getElementById('wpadminbar');
        if (adminBar) {
            var adminRect = adminBar.getBoundingClientRect();
            maxBottom = adminRect.bottom;
        }

        // Check #main-header (Divi 4)
        var mainHeader = document.getElementById('main-header');
        if (mainHeader) {
            var rect = mainHeader.getBoundingClientRect();
            var style = window.getComputedStyle(mainHeader);
            var isFixed = style.position === 'fixed' || style.position === 'sticky' ||
                          mainHeader.classList.contains('et-fixed-header');

            if (isFixed) {
                if (rect.bottom > 0 && rect.bottom > maxBottom) {
                    maxBottom = rect.bottom;
                }
            } else {
                if (currentScrollY <= 10) {
                    var headerFullHeight = mainHeader.offsetHeight;
                    if (adminBar) {
                        headerFullHeight += adminBar.offsetHeight;
                    }
                    if (headerFullHeight > maxBottom) {
                        maxBottom = headerFullHeight;
                    }
                } else if (rect.bottom > 0 && rect.bottom > maxBottom) {
                    maxBottom = rect.bottom;
                }
            }
        }

        // Check .et-l--header (Divi 5)
        var divi5Header = document.querySelector('.et-l--header');
        if (divi5Header) {
            var d5Rect = divi5Header.getBoundingClientRect();
            if (d5Rect.bottom > 0 && d5Rect.bottom > maxBottom) {
                maxBottom = d5Rect.bottom;
            }
        }

        var topOffset = (maxBottom > 0 ? Math.round(maxBottom) : 80) + 30;

        circles.forEach(function(circle) {
            circle.style.setProperty('top', topOffset + 'px', 'important');
        });

        // When scrolling up, schedule multiple updates to catch header expansion animations
        if (isScrollingUp && !circleUpdatePending) {
            circleUpdatePending = true;

            var updateIntervals = [50, 100, 150, 200, 300, 400, 500];
            updateIntervals.forEach(function(delay) {
                setTimeout(function() {
                    updateCircleTopPosition();
                }, delay);
            });

            setTimeout(function() {
                circleUpdatePending = false;
            }, 600);
        }
    }

    /**
     * Initialize circle bar top_of_page positioning
     */
    function initCircleTopPosition() {
        var circles = document.querySelectorAll('.dnxte-circle-position-top_of_page');
        if (!circles.length) return;

        updateCircleTopPosition();

        window.addEventListener('resize', function() {
            requestAnimationFrame(updateCircleTopPosition);
        }, { passive: true });
        window.addEventListener('load', updateCircleTopPosition);

        var scrollContainer = getScrollContainer();
        if (scrollContainer) {
            scrollContainer.addEventListener('scroll', function() {
                requestAnimationFrame(updateCircleTopPosition);
            }, { passive: true });
        } else {
            window.addEventListener('scroll', function() {
                requestAnimationFrame(updateCircleTopPosition);
            }, { passive: true });
        }

        setTimeout(updateCircleTopPosition, 100);
        setTimeout(updateCircleTopPosition, 500);
        setTimeout(updateCircleTopPosition, 1000);
        setTimeout(updateCircleTopPosition, 2000);
    }

    /**
     * Attach scroll listeners to SimpleBar if it exists
     * Called after delays to catch dynamically created SimpleBar
     */
    function attachSimpleBarListeners() {
        var simpleBarWrappers = document.querySelectorAll('.simplebar-content-wrapper');
        if (simpleBarWrappers.length > 0) {
            simpleBarWrappers.forEach(function(wrapper) {
                // Check if we already attached a listener
                if (wrapper.getAttribute('data-progress-listener') === 'true') {
                    return;
                }
                wrapper.setAttribute('data-progress-listener', 'true');

                wrapper.addEventListener('scroll', function() {
                    globalScrollUpdate();
                }, { passive: true });
            });
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            moveFixedBarsToBody();
            initProgressBars();
            initBelowMainMenuPosition();
            initCircleTopPosition();
            attachSimpleBarListeners();
        });
    } else {
        moveFixedBarsToBody();
        initProgressBars();
        initBelowMainMenuPosition();
        attachSimpleBarListeners();
    }

    // Also initialize on window load for Divi compatibility
    window.addEventListener('load', function() {
        setTimeout(function() {
            moveFixedBarsToBody();
            initProgressBars();
            initBelowMainMenuPosition();
            initCircleTopPosition();
            attachSimpleBarListeners();
        }, 100);
    });

    // Additional delayed checks for SimpleBar (it may initialize late)
    setTimeout(attachSimpleBarListeners, 500);
    setTimeout(attachSimpleBarListeners, 1000);
    setTimeout(attachSimpleBarListeners, 2000);

})();
