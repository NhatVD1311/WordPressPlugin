/**
 * Horizontal Scroll — Frontend Runtime
 * GSAP ScrollTrigger-powered horizontal scroll for Divi Sections.
 * Modes: pinned, snap, parallax, gallery
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  function DnxteHScroll(el) {
    this.el = el;
    this._tweens = [];
    this._sts = [];
    this._injected = [];
    this._destroyed = false;

    var gsap = window.gsap;
    var ST = window.ScrollTrigger;
    if (!gsap || !ST) return;

    this.gsap = gsap;
    this.ST = ST;

    // Read config from data attributes
    this.type        = el.getAttribute('data-hscroll-type') || 'pinned';
    this.speed       = parseFloat(el.getAttribute('data-hscroll-speed')) || 1;
    this.scrubRaw    = el.getAttribute('data-hscroll-scrub') || '1';
    this.itemGap     = Math.max(0, parseFloat(el.getAttribute('data-hscroll-item-gap')) || 0);
    this.anticipate  = el.getAttribute('data-hscroll-anticipate') === 'true';
    this.contentPx   = el.getAttribute('data-hscroll-content-parallax') === 'true';
    this.contentSpd  = parseFloat(el.getAttribute('data-hscroll-content-speed')) || 0.5;
    this.enterFx     = el.getAttribute('data-hscroll-enter') || 'none';
    this.stagger     = el.getAttribute('data-hscroll-stagger') !== 'false';
    this.staggerDel  = parseFloat(el.getAttribute('data-hscroll-stagger-delay')) || 0.15;

    this._init();
  }

  var proto = DnxteHScroll.prototype;

  proto._init = function () {
    var self = this;
    var gsap = this.gsap;
    var ST = this.ST;
    var section = this.el;

    // Find child "slides" — try rows first, then columns inside a single row
    var slides = Array.prototype.slice.call(section.querySelectorAll(':scope > .et_pb_row, :scope > .et_pb_row_inner'));

    // If only 1 row, use its columns as slides (most common DE use case)
    if (slides.length === 1) {
      var cols = slides[0].querySelectorAll(':scope > .et_pb_column, :scope > .et_pb_column_inner');
      if (cols.length >= 2) {
        slides = Array.prototype.slice.call(cols);
      }
    }

    // Fallback: direct children that aren't decorations
    if (!slides.length) {
      slides = Array.prototype.slice.call(section.children).filter(function (c) {
        return !c.classList.contains('et_pb_section_video_bg') &&
               !c.classList.contains('et_pb_background_overlay') &&
               c.tagName !== 'STYLE' && c.tagName !== 'SCRIPT';
      });
    }

    if (!slides || slides.length < 2) return;

    // Section: only clip horizontal overflow so the off-screen slides don't
    // leak. Leaves Divi's own min-height / height / padding / background alone.
    section.style.setProperty('overflow', 'hidden', 'important');
    section.style.position = 'relative';

    // Track parent row for potential cleanup, but don't override its styles —
    // whatever Divi row/column settings the user configured stay intact.
    var parentRow = slides[0].parentElement;
    if (parentRow && parentRow !== section &&
        (parentRow.classList.contains('et_pb_row') || parentRow.classList.contains('et_pb_row_inner'))) {
      this._parentRow = parentRow;
    }

    // Inject horizontal flex wrapper — IN FLOW (not absolute). Section picks
    // up its natural height from the slides' content. No height/width/padding
    // forcing — Divi's column/row widths and paddings drive everything.
    var wrapper = document.createElement('div');
    wrapper.className = 'dnxte-hscroll-wrapper';
    wrapper.style.cssText = [
      'display:flex', 'flex-wrap:nowrap',
      'gap:' + this.itemGap + 'px',
      'will-change:transform'
    ].join(';') + ';';

    // Move slides into wrapper. Only prevent flex shrink/grow so the slides'
    // Divi-configured widths survive when their total exceeds the viewport.
    var items = [];
    slides.forEach(function (slide) {
      slide.style.setProperty('flex-shrink', '0', 'important');
      slide.style.setProperty('flex-grow', '0', 'important');
      wrapper.appendChild(slide);
      items.push(slide);
    });

    section.appendChild(wrapper);
    this._injected.push(wrapper);

    // wrapper is block-level inside the section's content-box, so its
    // clientWidth already equals (section.offsetWidth - paddingLeft - paddingRight).
    // scrollWidth - clientWidth = how much the wrapper must translate left so
    // the last item's right edge lands at the content-area's right edge —
    // section padding (left and right) is naturally respected.
    var scrollDist = wrapper.scrollWidth - wrapper.clientWidth;
    if (scrollDist <= 0) return;

    // Parse scrub value
    var scrubValue = this.scrubRaw === 'true' ? true : parseFloat(this.scrubRaw);
    if (isNaN(scrubValue)) scrubValue = 1;

    // ── Main horizontal scroll timeline ──
    var stConfig = {
      trigger: section,
      start: 'top top',
      end: function () { return '+=' + (scrollDist / self.speed); },
      scrub: scrubValue,
      pin: true,
      anticipatePin: this.anticipate ? 1 : 0,
    };

    // Snap mode
    if (this.type === 'snap' && items.length > 1) {
      stConfig.snap = {
        snapTo: 1 / (items.length - 1),
        duration: { min: 0.2, max: 0.5 },
        ease: 'power1.inOut'
      };
    }

    var mainTL = gsap.to(wrapper, {
      x: -scrollDist,
      ease: 'none',
      scrollTrigger: stConfig
    });
    this._tweens.push(mainTL);
    if (mainTL.scrollTrigger) this._sts.push(mainTL.scrollTrigger);
    this._mainTL = mainTL;

    // ── Content Parallax ──
    if (this.contentPx || this.type === 'parallax') {
      items.forEach(function (item) {
        var content = item.querySelector('.et_pb_column, .et_pb_text, .et_pb_blurb, .et_pb_heading') || item.firstElementChild;
        if (!content) return;
        var tween = gsap.to(content, {
          x: function () { return -window.innerWidth * self.contentSpd * 0.5; },
          scrollTrigger: {
            trigger: item,
            containerAnimation: mainTL,
            start: 'left right',
            end: 'right left',
            scrub: true
          }
        });
        self._tweens.push(tween);
      });
    }

    // ── Enter Effects ──
    if (this.enterFx !== 'none') {
      items.forEach(function (item) {
        var els = item.querySelectorAll('.et_pb_text, .et_pb_blurb, .et_pb_heading, .et_pb_button, img, h1, h2, h3, p');
        if (!els.length) els = [item];

        Array.prototype.forEach.call(els, function (target, j) {
          var fromVars = { opacity: 0 };
          var toVars = { opacity: 1, duration: 0.6, ease: 'power2.out' };

          switch (self.enterFx) {
            case 'slideUp':   fromVars.y = 50; toVars.y = 0; break;
            case 'slideDown': fromVars.y = -50; toVars.y = 0; break;
            case 'scale':     fromVars.scale = 0.85; toVars.scale = 1; break;
            case 'blur':      fromVars.filter = 'blur(10px)'; toVars.filter = 'blur(0px)'; break;
          }

          gsap.set(target, fromVars);
          var tween = gsap.to(target, Object.assign({}, toVars, {
            delay: self.stagger ? j * self.staggerDel : 0,
            scrollTrigger: {
              trigger: item,
              containerAnimation: mainTL,
              start: 'left 80%',
              toggleActions: 'play none none reverse'
            }
          }));
          self._tweens.push(tween);
        });
      });
    }

    ST.refresh();
  };

  proto.destroy = function () {
    this._destroyed = true;
    this._tweens.forEach(function (t) { try { t.kill(); } catch (e) {} });
    this._sts.forEach(function (st) { try { st.kill(); } catch (e) {} });
    this._injected.forEach(function (el) {
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
    if (this.el) this.el.style.overflow = '';
    this._tweens = []; this._sts = []; this._injected = [];
  };

  // ── Auto-init ──
  function initAll() {
    var els = document.querySelectorAll('[data-hscroll-init="true"]');
    els.forEach(function (el) {
      if (el._dnxteHScroll) return;
      el._dnxteHScroll = new DnxteHScroll(el);
    });
  }

  function boot() {
    initAll();
    if (document.body) {
      var observer = new MutationObserver(function (mutations) {
        var shouldInit = false;
        mutations.forEach(function (m) { if (m.addedNodes && m.addedNodes.length) shouldInit = true; });
        if (shouldInit) initAll();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.DnxteHScroll = DnxteHScroll;
    return;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.DnxteHScroll = DnxteHScroll;
})();
