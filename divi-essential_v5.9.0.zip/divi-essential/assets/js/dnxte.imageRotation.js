/**
 * Divi Essential — 360° Image Rotation
 *
 * Frontend behaviour for the Image Rotation module.
 * Supports: drag / hover / scroll / autoplay triggers, loop, direction,
 * play-pause, prev/next, frame counter, progress bar, pause-on-hover,
 * keyboard navigation, lazy frame loading, mouse-wheel rotation,
 * a 360° indicator badge (hidden on first interaction) and a magnify lens.
 *
 * Stubbed for a future pass: inertia momentum easing and frame-snap easing
 * (the data attributes are read but treated as simple on/off here).
 */
(function () {
  "use strict";

  // Icon markup for the play/pause toggle. Kept in sync with the PHP equivalent
  // in ImageRotationTrait/RenderCallbackTrait.php::get_control_icon_svg().
  var SVG_OPEN =
    '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" focusable="false" aria-hidden="true">';
  var PLAY_ICON = SVG_OPEN + '<path d="M7 5.5 L17 12 L7 18.5 Z" fill="currentColor"/></svg>';
  var PAUSE_ICON =
    SVG_OPEN +
    '<rect x="7.5" y="5.5" width="3.4" height="13" rx="0.6" fill="currentColor"/>' +
    '<rect x="13.1" y="5.5" width="3.4" height="13" rx="0.6" fill="currentColor"/></svg>';

  // Concurrent requests used by the idle background preloader.
  var PRELOAD_CONCURRENCY = 3;
  // Fallback window of frames kept decoded on each side of the current one.
  var DEFAULT_LOOKAHEAD = 6;
  // How long a decode may run before the downloaded image is used as-is.
  var DECODE_TIMEOUT = 300;

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function idle(callback) {
    if (window.requestIdleCallback) {
      window.requestIdleCallback(callback, { timeout: 500 });
    } else {
      window.setTimeout(callback, 1);
    }
  }

  // Resolves once the image has downloaded.
  function whenLoaded(img) {
    if (img.complete && img.naturalWidth > 0) {
      return Promise.resolve(true);
    }
    return new Promise(function (resolve) {
      img.addEventListener("load", function () {
        resolve(true);
      });
      img.addEventListener("error", function () {
        resolve(false);
      });
    });
  }

  // Resolves once the image bitmap is ready to paint. Swapping to an image that
  // has not been decoded yet is what makes the viewport flash.
  function decodeImage(img) {
    if (!img.decode) {
      return whenLoaded(img);
    }
    return whenLoaded(img).then(function (loaded) {
      if (!loaded) {
        return false;
      }
      var decoded = img.decode().then(
        function () {
          return true;
        },
        function () {
          // A rejected decode (broken URL, or an abort caused by a src swap)
          // must not wedge the rotation, so fall back to the load state.
          return img.complete && img.naturalWidth > 0;
        }
      );
      // Chrome never settles decode() while the tab is hidden, and the bytes
      // are already here, so a hidden tab stops waiting rather than stalling
      // the whole queue. A visible tab always waits for the real decode:
      // painting a downloaded-but-undecoded frame is what makes it blink.
      var release;
      var grace = new Promise(function (resolve) {
        release = resolve;
      });
      var onHidden = function () {
        if (document.hidden) {
          release(true);
        }
      };
      document.addEventListener("visibilitychange", onHidden);
      // Covers a tab that is already hidden when the decode starts.
      var timer = window.setTimeout(onHidden, DECODE_TIMEOUT);
      return Promise.race([decoded, grace]).then(function (ok) {
        document.removeEventListener("visibilitychange", onHidden);
        window.clearTimeout(timer);
        return ok;
      });
    });
  }

  function ImageRotation(container) {
    this.container = container;
    this.viewport = container.querySelector(".image_rotation__viewport");
    this.frames = Array.prototype.slice.call(
      container.querySelectorAll(".image_rotation__frame")
    );
    this.total = this.frames.length;
    if (this.total === 0) {
      return;
    }

    var data = container.dataset;
    this.trigger = data.trigger || "drag";
    this.autoplay = data.autoplay === "on";
    this.loop = data.loop !== "off";
    this.direction = data.direction === "ccw" ? -1 : 1;
    this.speed = clamp(parseInt(data.speed, 10) || 50, 1, 100);
    this.dragSensitivity = clamp(parseInt(data.dragSensitivity, 10) || 50, 1, 100);
    this.pauseOnHover = data.pauseOnHover !== "off";
    this.keyboardNav = data.keyboardNav === "on";
    this.wheelRotate = data.wheelRotate === "on";
    this.magnify = data.magnify === "on";
    this.zoomLevel = parseFloat(data.zoomLevel) || 2.5;
    this.magnifyOn = false;
    this.preload = parseInt(data.preloadFrames, 10);
    if (isNaN(this.preload)) {
      this.preload = DEFAULT_LOOKAHEAD;
    }
    // Frames kept decoded on each side of the current one while rotating.
    this.lookahead = clamp(this.preload, 2, this.total);

    this.current = 0;
    // Frame currently on screen; trails this.current while a frame decodes.
    this.painted = 0;
    // Guards against a slow frame painting after a newer one was requested.
    this.renderToken = 0;
    this.playing = false;
    this.timer = null;

    this.counterCurrent = container.querySelector(
      ".image_rotation__counter-current"
    );
    this.progressBar = container.querySelector(".image_rotation__progress-bar");
    this.prevBtn = container.querySelector(".image_rotation__prev");
    this.nextBtn = container.querySelector(".image_rotation__next");
    this.playBtn = container.querySelector(".image_rotation__playpause");
    this.indicator = container.querySelector(".image_rotation__indicator");
    this.magnifyBtn = container.querySelector(".image_rotation__magnify");
    this.lens = container.querySelector(".image_rotation__lens");

    this.init();
  }

  ImageRotation.prototype.init = function () {
    this.decodeRenderedFrames();
    this.render();
    this.bindControls();
    this.bindTrigger();
    this.bindWheel();
    this.bindMagnify();

    // Warm every frame in the background so no rotation ever waits on the
    // network. Held until the page has loaded so it never competes with it.
    var self = this;
    var startPreload = function () {
      idle(function () {
        self.preloadAll();
      });
    };
    if (document.readyState === "complete") {
      startPreload();
    } else {
      window.addEventListener("load", startPreload);
    }

    if (this.autoplay || this.trigger === "autoplay") {
      this.play();
    }
  };

  // Frames rendered with a src are downloaded, but a downloaded image is not a
  // decoded one: browsers skip decoding an image they never had to paint, and
  // every frame but the first sits at opacity 0. Marking them ready here would
  // send them straight to paint() and pay the decode mid-swap, which is what
  // blinks. Push them through the same decode path as the deferred frames.
  ImageRotation.prototype.decodeRenderedFrames = function () {
    for (var i = 0; i < this.total; i++) {
      if (this.frames[i].getAttribute("src")) {
        this.loadFrame(i);
      }
    }
  };

  // Fade out the 360° badge after the first interaction.
  ImageRotation.prototype.hideIndicator = function () {
    if (this.indicator) {
      this.indicator.classList.add("is-hidden");
    }
  };

  // Give a frame a real src (deferred frames ship without one) and resolve once
  // its bitmap is decoded, so callers can wait instead of painting a blank.
  ImageRotation.prototype.loadFrame = function (index) {
    var frame = this.frames[index];
    if (!frame) {
      return Promise.resolve(false);
    }
    if (frame.dnxteReady) {
      return Promise.resolve(true);
    }
    if (frame.dnxtePending) {
      return frame.dnxtePending;
    }
    if (!frame.getAttribute("src") && frame.dataset.src) {
      // Force an immediate request: a loading="lazy" image would otherwise wait
      // for its own visibility, which never changes while the frame is hidden.
      frame.setAttribute("loading", "eager");
      frame.setAttribute("src", frame.dataset.src);
    }
    frame.dnxtePending = decodeImage(frame).then(function (ok) {
      frame.dnxtePending = null;
      frame.dnxteReady = ok;
      return ok;
    });
    return frame.dnxtePending;
  };

  ImageRotation.prototype.render = function () {
    var self = this;
    var target = this.current;
    var token = ++this.renderToken;
    var frame = this.frames[target];

    if (frame && frame.dnxteReady) {
      this.paint(target);
    } else {
      // Hold the frame that is already on screen until the next one is decoded.
      this.loadFrame(target).then(function () {
        // Ignore a stale frame: the viewer has moved on while it was loading.
        if (self.renderToken === token) {
          self.paint(target);
        }
      });
    }

    this.warmNeighbours(target);
  };

  // Show a decoded frame and sync the readouts that track it.
  ImageRotation.prototype.paint = function (index) {
    for (var i = 0; i < this.total; i++) {
      this.frames[i].classList.toggle("is-active", i === index);
    }
    this.painted = index;

    if (this.counterCurrent) {
      this.counterCurrent.textContent = String(index + 1);
    }
    if (this.progressBar) {
      var pct = this.total > 1 ? (index / (this.total - 1)) * 100 : 0;
      this.progressBar.style.width = pct + "%";
    }
    // Keep the magnify lens showing the active frame while rotating.
    if (this.lens && this.magnifyOn && this.lens.style.display === "block") {
      this.lens.style.backgroundImage = "url('" + this.activeFrameSrc() + "')";
    }
  };

  // Keep a window of frames decoded around the current one so a fast drag or
  // autoplay never outruns the loader.
  ImageRotation.prototype.warmNeighbours = function (index) {
    for (var offset = 1; offset <= this.lookahead; offset++) {
      this.loadFrame((index + offset) % this.total);
      this.loadFrame(((index - offset) % this.total + this.total) % this.total);
    }
  };

  // Decode every remaining frame in the background, ordered outward from the
  // current one, a few at a time so the queue stays off the critical path.
  ImageRotation.prototype.preloadAll = function () {
    var self = this;
    var queue = [];
    for (var offset = 0; offset < this.total; offset++) {
      queue.push((this.current + offset) % this.total);
    }

    var next = function () {
      var index = queue.shift();
      if (undefined === index) {
        return;
      }
      self.loadFrame(index).then(function () {
        idle(next);
      });
    };

    for (var i = 0; i < Math.min(PRELOAD_CONCURRENCY, this.total); i++) {
      next();
    }
  };

  ImageRotation.prototype.step = function (delta) {
    var next = this.current + delta;
    if (next >= this.total) {
      next = this.loop ? 0 : this.total - 1;
    } else if (next < 0) {
      next = this.loop ? this.total - 1 : 0;
    }
    this.current = next;
    this.render();
  };

  ImageRotation.prototype.play = function () {
    if (this.playing || this.total < 2) {
      return;
    }
    this.playing = true;
    this.hideIndicator();
    if (this.playBtn) {
      this.playBtn.innerHTML = PAUSE_ICON;
    }
    var self = this;
    // Map speed (1-100) to an interval between ~400ms and ~20ms.
    var interval = 400 - (this.speed / 100) * 380;
    this.timer = window.setInterval(function () {
      self.step(self.direction);
    }, interval);
  };

  ImageRotation.prototype.pause = function () {
    this.playing = false;
    if (this.playBtn) {
      this.playBtn.innerHTML = PLAY_ICON;
    }
    if (this.timer) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  };

  ImageRotation.prototype.toggle = function () {
    if (this.playing) {
      this.pause();
    } else {
      this.play();
    }
  };

  ImageRotation.prototype.bindControls = function () {
    var self = this;
    if (this.prevBtn) {
      this.prevBtn.addEventListener("click", function () {
        self.pause();
        self.hideIndicator();
        self.step(-1);
      });
    }
    if (this.nextBtn) {
      this.nextBtn.addEventListener("click", function () {
        self.pause();
        self.hideIndicator();
        self.step(1);
      });
    }
    if (this.playBtn) {
      this.playBtn.addEventListener("click", function () {
        self.toggle();
      });
    }
    if (this.keyboardNav) {
      this.container.setAttribute("tabindex", "0");
      this.container.addEventListener("keydown", function (e) {
        if (e.key === "ArrowLeft") {
          self.pause();
          self.step(-1);
        } else if (e.key === "ArrowRight") {
          self.pause();
          self.step(1);
        }
      });
    }
    if (this.pauseOnHover) {
      this.container.addEventListener("mouseenter", function () {
        self.wasPlaying = self.playing;
        self.pause();
      });
      this.container.addEventListener("mouseleave", function () {
        if (self.wasPlaying) {
          self.play();
        }
      });
    }
  };

  ImageRotation.prototype.bindTrigger = function () {
    var self = this;

    if (this.trigger === "drag") {
      this.bindDrag();
    } else if (this.trigger === "hover") {
      this.viewport.addEventListener("mousemove", function (e) {
        var rect = self.viewport.getBoundingClientRect();
        var ratio = clamp((e.clientX - rect.left) / rect.width, 0, 1);
        self.hideIndicator();
        self.current = Math.round(ratio * (self.total - 1));
        self.render();
      });
    } else if (this.trigger === "scroll") {
      window.addEventListener("scroll", function () {
        var rect = self.container.getBoundingClientRect();
        var ratio = clamp(
          1 - (rect.top + rect.height) / (window.innerHeight + rect.height),
          0,
          1
        );
        self.current = Math.round(ratio * (self.total - 1));
        self.render();
      });
    }
  };

  // Rotate with the mouse wheel while hovering the viewport.
  ImageRotation.prototype.bindWheel = function () {
    if (!this.wheelRotate) {
      return;
    }
    var self = this;
    this.viewport.addEventListener(
      "wheel",
      function (e) {
        e.preventDefault();
        self.pause();
        self.hideIndicator();
        self.step(e.deltaY > 0 ? self.direction : -self.direction);
      },
      { passive: false }
    );
  };

  // Magnify lens: toggled by the magnify button, follows the cursor.
  ImageRotation.prototype.bindMagnify = function () {
    if (!this.magnify || !this.magnifyBtn || !this.lens) {
      return;
    }
    var self = this;
    this.magnifyBtn.addEventListener("click", function () {
      self.magnifyOn = !self.magnifyOn;
      self.magnifyBtn.classList.toggle("is-on", self.magnifyOn);
      // Drives the viewport cursor (zoom-in instead of the drag hand).
      self.container.classList.toggle("is-magnifying", self.magnifyOn);
      self.hideIndicator();
      if (!self.magnifyOn) {
        self.lens.style.display = "none";
      }
    });
    this.viewport.addEventListener("mousemove", function (e) {
      if (self.magnifyOn) {
        self.updateLens(e);
      }
    });
    this.viewport.addEventListener("mouseleave", function () {
      self.lens.style.display = "none";
    });
  };

  ImageRotation.prototype.activeFrameSrc = function () {
    // The painted frame, not the requested one: they differ while a frame loads.
    var frame = this.frames[this.painted];
    if (!frame) {
      return "";
    }
    return frame.currentSrc || frame.getAttribute("src") || frame.dataset.src || "";
  };

  ImageRotation.prototype.updateLens = function (e) {
    var rect = this.viewport.getBoundingClientRect();
    var x = e.clientX - rect.left;
    var y = e.clientY - rect.top;
    if (x < 0 || y < 0 || x > rect.width || y > rect.height) {
      this.lens.style.display = "none";
      return;
    }
    var lensW = this.lens.offsetWidth || 150;
    var lensH = this.lens.offsetHeight || 150;

    this.lens.style.display = "block";
    this.lens.style.left = x - lensW / 2 + "px";
    this.lens.style.top = y - lensH / 2 + "px";
    this.lens.style.backgroundImage = "url('" + this.activeFrameSrc() + "')";
    this.lens.style.backgroundSize =
      rect.width * this.zoomLevel + "px " + rect.height * this.zoomLevel + "px";
    this.lens.style.backgroundPosition =
      -(x * this.zoomLevel - lensW / 2) + "px " + -(y * this.zoomLevel - lensH / 2) + "px";
  };

  ImageRotation.prototype.bindDrag = function () {
    var self = this;
    var dragging = false;
    var startX = 0;
    var startFrame = 0;
    // Higher sensitivity => fewer pixels per frame step.
    var pxPerFrame = clamp(60 - (this.dragSensitivity / 100) * 50, 4, 60);

    function getX(e) {
      return e.touches ? e.touches[0].clientX : e.clientX;
    }

    function onDown(e) {
      dragging = true;
      startX = getX(e);
      startFrame = self.current;
      self.pause();
      self.hideIndicator();
      self.container.classList.add("is-dragging");
    }

    function onMove(e) {
      if (!dragging) {
        return;
      }
      var deltaX = getX(e) - startX;
      var stepCount = Math.round(deltaX / pxPerFrame) * self.direction;
      var next = startFrame + stepCount;
      if (self.loop) {
        next = ((next % self.total) + self.total) % self.total;
      } else {
        next = clamp(next, 0, self.total - 1);
      }
      if (next !== self.current) {
        self.current = next;
        self.render();
      }
      if (e.cancelable) {
        e.preventDefault();
      }
    }

    function onUp() {
      dragging = false;
      self.container.classList.remove("is-dragging");
    }

    this.viewport.addEventListener("mousedown", onDown);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    this.viewport.addEventListener("touchstart", onDown, { passive: true });
    this.viewport.addEventListener("touchmove", onMove, { passive: false });
    this.viewport.addEventListener("touchend", onUp);
  };

  function initAll() {
    var containers = document.querySelectorAll(
      ".dnxte-image-rotation-container"
    );
    Array.prototype.forEach.call(containers, function (container) {
      if (container.dataset.imageRotationInit === "1") {
        return;
      }
      container.dataset.imageRotationInit = "1";
      new ImageRotation(container);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll);
  } else {
    initAll();
  }
})();
