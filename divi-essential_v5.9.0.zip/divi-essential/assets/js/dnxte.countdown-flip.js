(function($) {
    'use strict';

    /**
     * DNXTE Flip Countdown - Based on CodePen by pong777
     * https://codepen.io/pong777/pen/QXzJLV
     */
    class FlipCountdown {
        get TIMESTAMP_SECOND() { return 1000; }
        get TIMESTAMP_MINUTE() { return 60 * this.TIMESTAMP_SECOND; }
        get TIMESTAMP_HOUR() { return 60 * this.TIMESTAMP_MINUTE; }
        get TIMESTAMP_DAY() { return 24 * this.TIMESTAMP_HOUR; }

        constructor(userOptions) {
            this.options = {
                cont: null,
                countdown: true,
                endDate: {
                    day: 0,
                    hour: 0,
                    minute: 0,
                    second: 0
                },
                endCallback: null,
                outputFormat: 'day|hour|minute|second',
                outputTranslation: {
                    day: 'Days',
                    hour: 'Hours',
                    minute: 'Minutes',
                    second: 'Seconds'
                },
                separator: ':',
                unitMode: false
            };

            this.lastTick = null;
            this.intervalsBySize = ['day', 'hour', 'minute', 'second'];
            this.interval = null;
            this.digitConts = {};
            this._assignOptions(this.options, userOptions);
        }

        start() {
            let endDate, endDateData;

            endDate = this._getDate(this.options.endDate);
            endDateData = this._prepareTimeByOutputFormat(endDate);

            this._bindFlapCleanup();
            this._writeData(endDateData);
            this.lastTick = endDateData;

            if (this.options.countdown && endDate.getTime() <= Date.now()) {
                if (typeof this.options.endCallback === 'function') {
                    this.stop();
                    this.options.endCallback();
                }
            } else {
                this.interval = setInterval(() => {
                    this._updateView(this._prepareTimeByOutputFormat(endDate));
                }, this.TIMESTAMP_SECOND);
            }
        }

        stop() {
            if (this.interval !== null) {
                clearInterval(this.interval);
                this.interval = null;
            }
        }

        _getDate(date) {
            if (typeof date === 'object') {
                if (date instanceof Date) {
                    return date;
                } else {
                    let expectedValues = {
                        day: 0,
                        hour: 0,
                        minute: 0,
                        second: 0
                    };

                    for (let i in expectedValues) {
                        if (expectedValues.hasOwnProperty(i) && date.hasOwnProperty(i)) {
                            expectedValues[i] = date[i];
                        }
                    }
                    return new Date(expectedValues.day, expectedValues.hour, expectedValues.minute, expectedValues.second);
                }
            } else if (typeof date === 'number' || typeof date === 'string') {
                return new Date(date);
            } else {
                return new Date();
            }
        }

        _prepareTimeByOutputFormat(dateObj) {
            let usedIntervals, output = {}, timeDiff;

            usedIntervals = this.intervalsBySize.filter(item => {
                return this.options.outputFormat.split('|').indexOf(item) !== -1;
            });

            timeDiff = this.options.countdown ? dateObj.getTime() - Date.now() : Date.now() - dateObj.getTime();

            usedIntervals.forEach(item => {
                let value;
                if (timeDiff > 0) {
                    switch (item) {
                        case 'day':
                            value = Math.trunc(timeDiff / this.TIMESTAMP_DAY);
                            timeDiff -= value * this.TIMESTAMP_DAY;
                            break;
                        case 'hour':
                            value = Math.trunc(timeDiff / this.TIMESTAMP_HOUR);
                            timeDiff -= value * this.TIMESTAMP_HOUR;
                            break;
                        case 'minute':
                            value = Math.trunc(timeDiff / this.TIMESTAMP_MINUTE);
                            timeDiff -= value * this.TIMESTAMP_MINUTE;
                            break;
                        case 'second':
                            value = Math.trunc(timeDiff / this.TIMESTAMP_SECOND);
                            timeDiff -= value * this.TIMESTAMP_SECOND;
                            break;
                    }
                } else {
                    value = '00';
                }
                const formatted = ('' + value).length < 2 ? '0' + value : '' + value;
                output[item] = this.options.unitMode ? formatted : formatted.split('');
            });
            return output;
        }

        _writeData(data) {
            if (this.options.unitMode) { this._writeUnitData(data); return; }
            let code = '';
            const intervalNames = Object.keys(data);
            const separator = this.options.separator;

            intervalNames.forEach((intervalName, index) => {
                if (data.hasOwnProperty(intervalName)) {
                    let label = this.options.outputTranslation[intervalName] || '';
                    let element = '<div><div class="interval_cont interval_cont_' + intervalName + '">';
                    let intervalDescription = label ? '<div class="description">' + label + '</div>' : '';

                    data[intervalName].forEach((digit, digitIndex) => {
                        element += '<div class="digit_cont digit_cont_' + digitIndex + '">' + this._getDigitElementString(digit, 0) + '</div>';
                    });

                    code += element + '</div>' + intervalDescription + '</div>';

                    // Add separator between intervals (not after the last one)
                    if (index < intervalNames.length - 1 && separator && separator !== 'none') {
                        code += '<div class="flip-countdown-separator">' + separator + '</div>';
                    }
                }
            });
            this.options.cont.innerHTML = code;
            this.lastTick = data;
        }

        _bindFlapCleanup() {
            if (this._flapCleanupBound || !this.options.cont) {
                return;
            }
            this._flapCleanupBound = true;

            // Rotated flaps kept at rest (animation-fill: forwards) stay 3D-composited
            // and their layers can bleed ~1px over the card border. Once the flip
            // finishes, show the new value on the static halves and drop the flaps.
            this.options.cont.addEventListener('animationend', (event) => {
                const target = event.target;
                if (!target || !target.classList) {
                    return;
                }

                if (target.classList.contains('new_rotate')) {
                    const digitCont = target.parentElement;
                    const placeholderSpan = digitCont ? digitCont.querySelector('.last_placeholder span') : null;
                    if (placeholderSpan) {
                        placeholderSpan.textContent = target.textContent.trim();
                    }
                    const lastRotate = digitCont ? digitCont.querySelector('.last_rotate') : null;
                    if (lastRotate) {
                        lastRotate.remove();
                    }
                    target.remove();
                } else if (target.classList.contains('unit-flap-bottom')) {
                    const digitCont = target.parentElement;
                    const flapTop = digitCont ? digitCont.querySelector('.unit-flap-top') : null;
                    if (flapTop) {
                        flapTop.remove();
                    }
                    target.remove();
                }
            });
        }

        _getDigitElementString(newDigit, lastDigit) {
            return '<div class="last_placeholder"><span>' + lastDigit + '</span></div>' +
                '<div class="new_placeholder">' + newDigit + '</div>' +
                '<div class="last_rotate">' + lastDigit + '</div>' +
                '<div class="new_rotate">' +
                    '<div class="rotated"><span>' + newDigit + '</span></div>' +
                '</div>';
        }

        _buildUnitCardInto(container, newValue, lastValue, animate) {
            container.textContent = '';

            const mkHalf = (cls, value) => {
                const half = document.createElement('div');
                half.className = cls;
                const span = document.createElement('span');
                span.textContent = value;
                half.appendChild(span);
                return half;
            };

            container.appendChild(mkHalf('unit-top-half', newValue));
            container.appendChild(mkHalf('unit-bottom-half', newValue));

            if (animate) {
                container.appendChild(mkHalf('unit-flap-top', lastValue));
                container.appendChild(mkHalf('unit-flap-bottom', newValue));
            }
        }

        _writeUnitData(data) {
            const cont = this.options.cont;
            cont.textContent = '';
            const intervalNames = Object.keys(data);
            const separator = this.options.separator;

            intervalNames.forEach((intervalName, index) => {
                if (!data.hasOwnProperty(intervalName)) return;

                const value = data[intervalName];
                const label = this.options.outputTranslation[intervalName] || '';

                const wrap = document.createElement('div');
                wrap.className = 'unit-flip-wrap';

                const digitCont = document.createElement('div');
                digitCont.className = 'digit_cont digit_cont_' + intervalName;
                this._buildUnitCardInto(digitCont, value, value, false);
                wrap.appendChild(digitCont);

                if (label) {
                    const desc = document.createElement('div');
                    desc.className = 'description';
                    desc.textContent = label;
                    wrap.appendChild(desc);
                }

                cont.appendChild(wrap);

                if (index < intervalNames.length - 1 && separator && separator !== 'none') {
                    const sep = document.createElement('div');
                    sep.className = 'flip-countdown-separator';
                    sep.textContent = separator;
                    cont.appendChild(sep);
                }
            });

            this.lastTick = data;
        }

        _updateUnitView(data) {
            for (let intervalName in data) {
                if (!data.hasOwnProperty(intervalName)) continue;
                const newValue = data[intervalName];
                const lastValue = this.lastTick ? this.lastTick[intervalName] : newValue;
                if (newValue !== lastValue) {
                    const digitCont = this.options.cont.querySelector('.digit_cont_' + intervalName);
                    if (digitCont) {
                        this._buildUnitCardInto(digitCont, newValue, lastValue);
                        this._buildUnitCardInto(digitCont, newValue, lastValue, true);
                    }
                }
            }
            this.lastTick = data;
        }

        _updateView(data) {
            if (this.options.unitMode) { this._updateUnitView(data); return; }
            for (let intervalName in data) {
                if (data.hasOwnProperty(intervalName)) {
                    data[intervalName].forEach((digit, index) => {
                        if (this.lastTick !== null &&
                            this.lastTick[intervalName][index] !== data[intervalName][index]) {
                            this._getDigitCont(intervalName, index).innerHTML =
                                this._getDigitElementString(data[intervalName][index], this.lastTick[intervalName][index]);
                        }
                    });
                }
            }
            this.lastTick = data;
        }

        _getDigitCont(intervalName, index) {
            if (!this.digitConts[intervalName + '_' + index]) {
                this.digitConts[intervalName + '_' + index] =
                    this.options.cont.querySelector('.interval_cont_' + intervalName + ' .digit_cont_' + index);
            }
            return this.digitConts[intervalName + '_' + index];
        }

        _assignOptions(options, userOptions) {
            for (let i in options) {
                if (options.hasOwnProperty(i) && userOptions.hasOwnProperty(i)) {
                    if (options[i] !== null && typeof options[i] === 'object' && typeof userOptions[i] === 'object') {
                        this._assignOptions(options[i], userOptions[i]);
                    } else {
                        options[i] = userOptions[i];
                    }
                }
            }
        }
    }

    /**
     * Initialize Flip Countdown modules
     */
    function initFlipCountdowns() {
        $('.dnxte-countdown-wrapper[data-display-style="flip"]').each(function() {
            if ($(this).data('flip-countdown-initialized')) {
                return;
            }

            const $wrapper = $(this);
            const settings = getSettings($wrapper);

            // Create flip countdown container if not exists
            let $flipCont = $wrapper.find('.flip-countdown');
            if (!$flipCont.length) {
                $wrapper.html('<div class="flip-countdown"></div>');
                $flipCont = $wrapper.find('.flip-countdown');
            }

            // Build output format based on visible units
            let outputFormat = [];
            if (settings.showDays) outputFormat.push('day');
            if (settings.showHours) outputFormat.push('hour');
            if (settings.showMinutes) outputFormat.push('minute');
            if (settings.showSeconds) outputFormat.push('second');

            // Get end date
            let endDate;
            if (settings.countdownType === 'evergreen') {
                endDate = getEvergreenEndDate($wrapper, settings);
            } else {
                endDate = new Date(settings.endDate);
            }

            // Create countdown instance
            const countdown = new FlipCountdown({
                cont: $flipCont[0],
                countdown: true,
                endDate: endDate.getTime(),
                outputFormat: outputFormat.join('|'),
                outputTranslation: {
                    day: settings.labelDays,
                    hour: settings.labelHours,
                    minute: settings.labelMinutes,
                    second: settings.labelSeconds
                },
                separator: settings.separator,
                endCallback: function() {
                    handleExpiration($wrapper, settings);
                }
            });

            countdown.start();
            $wrapper.data('flip-countdown-initialized', true);
            $wrapper.data('flip-countdown-instance', countdown);
        });
    }

    /**
     * Initialize Flip Unit Countdown modules (one card per unit)
     */
    function initFlipUnitCountdowns() {
        $('.dnxte-countdown-wrapper[data-display-style="flip_unit"]').each(function() {
            if ($(this).data('flip-unit-countdown-initialized')) {
                return;
            }

            const $wrapper = $(this);
            const settings = getSettings($wrapper);

            let $flipCont = $wrapper.find('.flip-countdown--unit-mode');
            if (!$flipCont.length) {
                const el = document.createElement('div');
                el.className = 'flip-countdown flip-countdown--unit-mode';
                $wrapper[0].textContent = '';
                $wrapper[0].appendChild(el);
                $flipCont = $wrapper.find('.flip-countdown--unit-mode');
            }

            const outputFormat = [];
            if (settings.showDays) outputFormat.push('day');
            if (settings.showHours) outputFormat.push('hour');
            if (settings.showMinutes) outputFormat.push('minute');
            if (settings.showSeconds) outputFormat.push('second');

            let endDate;
            if (settings.countdownType === 'evergreen') {
                endDate = getEvergreenEndDate($wrapper, settings);
            } else {
                endDate = new Date(settings.endDate);
            }

            const countdown = new FlipCountdown({
                cont: $flipCont[0],
                countdown: true,
                endDate: endDate.getTime(),
                outputFormat: outputFormat.join('|'),
                outputTranslation: {
                    day: settings.labelDays,
                    hour: settings.labelHours,
                    minute: settings.labelMinutes,
                    second: settings.labelSeconds
                },
                separator: settings.separator,
                unitMode: true,
                endCallback: function() {
                    handleExpiration($wrapper, settings);
                }
            });

            countdown.start();
            $wrapper.data('flip-unit-countdown-initialized', true);
            $wrapper.data('flip-unit-countdown-instance', countdown);
        });
    }

    /**
     * Get settings from wrapper data attributes
     */
    function getSettings($wrapper) {
        return {
            countdownType: $wrapper.data('countdown-type') || 'fixed',
            endDate: $wrapper.data('end-date') || '',
            evergreenDays: parseInt($wrapper.data('evergreen-days')) || 0,
            evergreenHours: parseInt($wrapper.data('evergreen-hours')) || 0,
            evergreenMinutes: parseInt($wrapper.data('evergreen-minutes')) || 0,
            evergreenSeconds: parseInt($wrapper.data('evergreen-seconds')) || 0,
            cookieDuration: parseInt($wrapper.data('cookie-duration')) || 24,
            showDays: $wrapper.data('show-days') === 'on',
            showHours: $wrapper.data('show-hours') === 'on',
            showMinutes: $wrapper.data('show-minutes') === 'on',
            showSeconds: $wrapper.data('show-seconds') === 'on',
            labelDays: $wrapper.data('label-days') || 'Days',
            labelHours: $wrapper.data('label-hours') || 'Hours',
            labelMinutes: $wrapper.data('label-minutes') || 'Minutes',
            labelSeconds: $wrapper.data('label-seconds') || 'Seconds',
            separator: $wrapper.data('separator') || ':',
            expireAction: $wrapper.data('expire-action') || 'hide',
            expireMessage: $wrapper.data('expire-message') || "Time's up!",
            expireRedirect: $wrapper.data('expire-redirect') || ''
        };
    }

    /**
     * Get evergreen end date with cookie persistence
     */
    function getEvergreenEndDate($wrapper, settings) {
        const cookieName = getCookieName($wrapper);
        const savedEndTime = getCookie(cookieName);

        if (savedEndTime && parseInt(savedEndTime) > Date.now()) {
            return new Date(parseInt(savedEndTime));
        }

        // Calculate new end time
        const duration =
            (settings.evergreenDays * 24 * 60 * 60 * 1000) +
            (settings.evergreenHours * 60 * 60 * 1000) +
            (settings.evergreenMinutes * 60 * 1000) +
            (settings.evergreenSeconds * 1000);

        const endTime = Date.now() + duration;
        setCookie(cookieName, endTime, settings.cookieDuration);

        return new Date(endTime);
    }

    /**
     * Cookie helper functions
     */
    function getCookieName($wrapper) {
        const $parent = $wrapper.closest('[id]');
        const moduleId = $parent.attr('id') || 'countdown_' + $wrapper.index();
        return 'dnxte_countdown_' + moduleId;
    }

    function getCookie(name) {
        const value = '; ' + document.cookie;
        const parts = value.split('; ' + name + '=');
        if (parts.length === 2) {
            return parts.pop().split(';').shift();
        }
        return null;
    }

    function setCookie(name, value, hours) {
        const expires = new Date(Date.now() + hours * 60 * 60 * 1000);
        document.cookie = name + '=' + value + '; expires=' + expires.toUTCString() + '; path=/';
    }

    /**
     * Handle countdown expiration
     */
    function handleExpiration($wrapper, settings) {
        switch (settings.expireAction) {
            case 'hide':
                $wrapper.fadeOut(500);
                break;
            case 'message':
                // .text(), not string-concat into .html(): the message comes back
                // from a data attribute, so jQuery has already undone the
                // server's attribute-escaping.
                $wrapper
                    .html('<div class="dnxte-countdown-expired-message"></div>')
                    .find('.dnxte-countdown-expired-message')
                    .text(settings.expireMessage);
                break;
            case 'redirect':
                // http(s) or same-site path only — a javascript: URL here would
                // execute for every visitor on expiry (server esc_url's it too;
                // defense in depth).
                if (settings.expireRedirect && /^(https?:\/\/|\/(?!\/))/i.test(settings.expireRedirect)) {
                    window.location.href = settings.expireRedirect;
                }
                break;
        }

        // Clear cookie for evergreen timers
        if (settings.countdownType === 'evergreen') {
            const cookieName = getCookieName($wrapper);
            document.cookie = cookieName + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        }
    }

    // Initialize on document ready
    $(document).ready(function() {
        initFlipCountdowns();
        initFlipUnitCountdowns();
    });

    // Re-initialize on window load
    $(window).on('load', function() {
        initFlipCountdowns();
        initFlipUnitCountdowns();
    });

    // Observe DOM for wrappers injected after page load (popups, AJAX, builder injections).
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function(mutations) {
            for (let i = 0; i < mutations.length; i++) {
                const added = mutations[i].addedNodes;
                for (let j = 0; j < added.length; j++) {
                    const node = added[j];
                    if (node.nodeType !== 1) continue;
                    if ((node.matches && node.matches('.dnxte-countdown-wrapper')) ||
                        (node.querySelector && node.querySelector('.dnxte-countdown-wrapper'))) {
                        initFlipCountdowns();
                        initFlipUnitCountdowns();
                        return;
                    }
                }
            }
        });
        const startObserving = function() {
            observer.observe(document.body, { childList: true, subtree: true });
        };
        if (document.body) {
            startObserving();
        } else {
            $(document).ready(startObserving);
        }
    }

    // Expose for external access
    window.DNXTEFlipCountdown = FlipCountdown;
    window.initDNXTEFlipCountdowns = initFlipCountdowns;
    window.initDNXTEFlipUnitCountdowns = initFlipUnitCountdowns;

})(jQuery);
