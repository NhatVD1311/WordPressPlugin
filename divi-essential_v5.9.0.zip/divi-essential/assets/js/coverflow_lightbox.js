(function($) {
  /*
   * Create magnificPopup for coverflow carousel
   */
  $(document).ready(function() {
    function swiperMagnificPopup(wrapper, imageClass, moduleName) {
      const moduleWrapper = $(wrapper).find('.swiper-wrapper')
      const { lightbox } = moduleWrapper.data();
      const moduleAnchor = $(`${wrapper}`).find(`${imageClass}`);
      
      if (moduleWrapper.length > 0 && "on" === lightbox) {
        moduleWrapper.each(function() {
          const that = `.${$(this)
            .parent()
            .parent()
            .parent()
            .parent()
            .attr("class")
            .split(" ")
            .join(".")} ${wrapper} .swiper-wrapper`;
            
            $(that).magnificPopup({
            removalDelay: 500,
            delegate: `${imageClass}`,
            type: "image",
            gallery: {
              enabled: true,
              navigateByImgClick: true,
              tCounter: "%curr% of %total%", // Markup for "1 of 7" counter
            },
            image: {
              markup:
                `<div class="mfp-figure dnxte-${moduleName}-mfp-config">` +
                '<div class="mfp-close"></div>' +
                '<div class="mfp-img"></div>' +
                '<div class="mfp-bottom-bar">' +
                '<div class="mfp-title"></div>' +
                '<div class="mfp-counter"></div>' +
                "</div>" +
                "</div>",
              titleSrc: function (item) {
                return item.el.attr("data-title"); //
                //return item.el.find('img').attr("alt");
              },
            },
            zoom: {
              enabled: true,
              duration: 500,
              opener: function(element) {
                return element.find("img");
              },
            },
          });
        });
      } else {
        if ("thumbs-gallery" === moduleName) {
          moduleAnchor.each(function() {
            $(this).removeAttr("href");
          });
        } 
      }
    }
    
    if ($(".dnext-thumbs-gallery-top").length > 0) {
      $(".dnext-thumbs-gallery-top")
        .each(function() {
          const mainClass =
            "." +
            $(this)
              .attr("class")
              .split(" ")
              .join(".");
              
          swiperMagnificPopup(
            `${mainClass}`,
            ".dnext-thumbs-gallery-top-image-link",
            "thumbs-gallery"
          );
        });
    }
    if ($(".dnxte-coverflowslider-active").length > 0) {
      $(".dnxte-coverflowslider-active")
        .each(function() {
          const mainClass =
            "." +
            $(this)
              .attr("class")
              .split(" ")
              .join(".");
              
          swiperMagnificPopup(
            `${mainClass}`,
            ".dnxte-coverflow-image-link",
            "coverflow"
          );
        });
    }

  });
})(jQuery);
