/**
 * DNXTE Chat Agent — edit-screen field toggle.
 *
 * Shows the "Working hours" block only when Status = "scheduled".
 * No dependencies (vanilla JS).
 */
( function () {
	'use strict';

	function init() {
		var status = document.querySelector( '.dnxte-agent-status' );
		var hours = document.querySelector( '[data-dnxte-agent-hours]' );

		if ( ! status || ! hours ) {
			return;
		}

		function sync() {
			hours.style.display = 'scheduled' === status.value ? '' : 'none';
		}

		status.addEventListener( 'change', sync );
		sync();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
