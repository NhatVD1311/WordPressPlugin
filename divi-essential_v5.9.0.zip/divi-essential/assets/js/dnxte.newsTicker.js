/**
 * News Ticker - Frontend Script
 * Works with server-rendered HTML items
 */
(function ($) {
    'use strict';

    var SCROLL_MODES = ['scroll'];
    var SINGLE_ITEM_MODES = [
        'fade', 'slide', 'typing', 'flip', 'zoom', 'bounce',
        'rotate', 'blur', 'wave', 'reveal', 'glitch', 'swing',
        'cube', 'newspaper', 'drop'
    ];

    function NewsTicker(el) {
        this.el = el;
        this.$el = $(el);
        this.config = this.getConfig();
        this.items = this.$el.find('.news-ticker__item').toArray();
        this.currentIndex = 0;
        this.isPaused = false;
        this.isManualPaused = false;
        this.timer = null;
        this.progressTimer = null;

        if (this.items.length === 0) return;

        this.init();
    }

    NewsTicker.prototype.getConfig = function () {
        var el = this.el;
        return {
            mode: el.getAttribute('data-mode') || 'scroll',
            direction: el.getAttribute('data-direction') || 'left',
            speed: parseInt(el.getAttribute('data-speed'), 10) || 50,
            duration: parseInt(el.getAttribute('data-duration'), 10) || 4000,
            pauseOnHover: el.getAttribute('data-pause-on-hover') === 'on',
            autoPlay: el.getAttribute('data-auto-play') !== 'off',
            gap: parseInt(el.getAttribute('data-gap'), 10) || 60,
            showControls: el.getAttribute('data-show-controls') === 'on',
            showProgress: el.getAttribute('data-show-progress') === 'on'
        };
    };

    NewsTicker.prototype.init = function () {
        if (SCROLL_MODES.indexOf(this.config.mode) !== -1) {
            this.initScroll();
        } else if (SINGLE_ITEM_MODES.indexOf(this.config.mode) !== -1) {
            this.initSingleItem();
        }

        if (this.config.pauseOnHover) {
            this.bindHover();
        }

        if (this.config.showControls) {
            this.bindControls();
        }
    };

    // ─── SCROLL MODE ───
    NewsTicker.prototype.initScroll = function () {
        var track = this.$el.find('.news-ticker__track');
        if (!track.length) return;

        // Clone items for seamless loop
        var items = track.children().clone();
        track.append(items);

        // Measure and set animation
        var self = this;
        requestAnimationFrame(function () {
            var trackWidth = 0;
            track.children().each(function (i) {
                if (i < self.items.length) {
                    trackWidth += $(this).outerWidth(true) + self.config.gap;
                }
            });

            track.css('--track-size', trackWidth + 'px');

            var animationDuration = trackWidth / self.config.speed;
            var animationName = self.config.direction === 'right'
                ? 'ticker-scroll-right'
                : 'ticker-scroll-left';

            track.css({
                'animation-name': animationName,
                'animation-duration': animationDuration + 's'
            });

            if (!self.config.autoPlay) {
                track.css('animation-play-state', 'paused');
            }
        });
    };

    // ─── SINGLE ITEM MODES ───
    NewsTicker.prototype.initSingleItem = function () {
        // Hide all items, show first
        $(this.items).removeClass('news-ticker__item--active');
        $(this.items[0]).addClass('news-ticker__item--active');
        this.currentIndex = 0;

        if (this.config.autoPlay) {
            this.startAutoPlay();
        }
    };

    NewsTicker.prototype.startAutoPlay = function () {
        var self = this;
        this.stopAutoPlay();
        this.timer = setInterval(function () {
            if (!self.isPaused) {
                self.next();
            }
        }, this.config.duration);

        if (this.config.showProgress) {
            this.startProgress();
        }
    };

    NewsTicker.prototype.stopAutoPlay = function () {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        this.stopProgress();
    };

    NewsTicker.prototype.startProgress = function () {
        var bar = this.$el.find('.news-ticker__progress-bar');
        if (!bar.length) return;

        var self = this;
        this.progressElapsed = 0;
        this.progressLastTick = Date.now();

        this.stopProgress();
        bar.css('width', '0%');

        this.progressTimer = setInterval(function () {
            if (self.isPaused) {
                self.progressLastTick = Date.now();
                return;
            }
            var now = Date.now();
            self.progressElapsed += now - self.progressLastTick;
            self.progressLastTick = now;
            var pct = Math.min((self.progressElapsed / self.config.duration) * 100, 100);
            bar.css('width', pct + '%');
            if (pct >= 100) {
                self.progressElapsed = 0;
            }
        }, 30);
    };

    NewsTicker.prototype.stopProgress = function () {
        if (this.progressTimer) {
            clearInterval(this.progressTimer);
            this.progressTimer = null;
        }
    };

    NewsTicker.prototype.next = function () {
        var nextIndex = (this.currentIndex + 1) % this.items.length;
        this.transition(this.currentIndex, nextIndex, 'next');
    };

    NewsTicker.prototype.prev = function () {
        var prevIndex = (this.currentIndex - 1 + this.items.length) % this.items.length;
        this.transition(this.currentIndex, prevIndex, 'prev');
    };

    NewsTicker.prototype.transition = function (fromIndex, toIndex, direction) {
        var mode = this.config.mode;
        var $from = $(this.items[fromIndex]);
        var $to = $(this.items[toIndex]);

        // Remove all animation classes
        $(this.items).each(function () {
            this.className = this.className.replace(/news-ticker__item--\S+/g, '').trim();
            $(this).addClass('news-ticker__item');
        });

        switch (mode) {
            case 'fade':
                $from.addClass('news-ticker__item--fade-out');
                $to.addClass('news-ticker__item--active news-ticker__item--fade-in');
                break;
            case 'slide':
                var inClass = direction === 'next' ? 'news-ticker__item--slide-in-next' : 'news-ticker__item--slide-in-prev';
                var outClass = direction === 'next' ? 'news-ticker__item--slide-out-next' : 'news-ticker__item--slide-out-prev';
                $from.addClass(outClass);
                $to.addClass('news-ticker__item--active ' + inClass);
                break;
            case 'typing':
                $from.removeClass('news-ticker__item--active news-ticker__item--typing');
                $to.addClass('news-ticker__item--active news-ticker__item--typing');
                break;
            case 'flip':
                $from.addClass('news-ticker__item--flip-out');
                $to.addClass('news-ticker__item--active news-ticker__item--flip-in');
                break;
            case 'zoom':
                $from.addClass('news-ticker__item--zoom-out');
                $to.addClass('news-ticker__item--active news-ticker__item--zoom-in');
                break;
            case 'bounce':
                $from.addClass('news-ticker__item--bounce-out');
                $to.addClass('news-ticker__item--active news-ticker__item--bounce-in');
                break;
            case 'rotate':
                $from.addClass('news-ticker__item--rotate-out');
                $to.addClass('news-ticker__item--active news-ticker__item--rotate-in');
                break;
            case 'blur':
                $from.addClass('news-ticker__item--blur-out');
                $to.addClass('news-ticker__item--active news-ticker__item--blur-in');
                break;
            case 'wave':
                $from.addClass('news-ticker__item--wave-out');
                $to.addClass('news-ticker__item--active news-ticker__item--wave-in');
                break;
            case 'reveal':
                $from.addClass('news-ticker__item--reveal-out');
                $to.addClass('news-ticker__item--active news-ticker__item--reveal-in');
                break;
            case 'glitch':
                $from.addClass('news-ticker__item--glitch-out');
                $to.addClass('news-ticker__item--active news-ticker__item--glitch-in');
                break;
            case 'swing':
                $from.addClass('news-ticker__item--swing-out');
                $to.addClass('news-ticker__item--active news-ticker__item--swing-in');
                break;
            case 'cube':
                $from.addClass('news-ticker__item--cube-out');
                $to.addClass('news-ticker__item--active news-ticker__item--cube-in');
                break;
            case 'newspaper':
                $from.addClass('news-ticker__item--newspaper-out');
                $to.addClass('news-ticker__item--active news-ticker__item--newspaper-in');
                break;
            case 'drop':
                $from.addClass('news-ticker__item--drop-out');
                $to.addClass('news-ticker__item--active news-ticker__item--drop-in');
                break;
        }

        this.currentIndex = toIndex;

        // Reset progress
        if (this.config.showProgress) {
            this.startProgress();
        }
    };

    // ─── HOVER PAUSE ───
    NewsTicker.prototype.bindHover = function () {
        var self = this;

        this.$el.on('mouseenter', function () {
            if (!self.isManualPaused) {
                self.isPaused = true;
                if (SCROLL_MODES.indexOf(self.config.mode) !== -1) {
                    self.$el.find('.news-ticker__track').css('animation-play-state', 'paused');
                }
            }
        });

        this.$el.on('mouseleave', function () {
            if (!self.isManualPaused) {
                self.isPaused = false;
                if (SCROLL_MODES.indexOf(self.config.mode) !== -1) {
                    self.$el.find('.news-ticker__track').css('animation-play-state', 'running');
                }
            }
        });
    };

    // ─── CONTROLS ───
    NewsTicker.prototype.bindControls = function () {
        var self = this;

        this.$el.find('.news-ticker__btn--prev').on('click', function () {
            self.prev();
            self.restartAutoPlay();
        });

        this.$el.find('.news-ticker__btn--next').on('click', function () {
            self.next();
            self.restartAutoPlay();
        });

        this.$el.find('.news-ticker__btn--pause').on('click', function () {
            if (self.isManualPaused) {
                self.isManualPaused = false;
                self.isPaused = false;
                $(this).html('\u23F8');
                if (SCROLL_MODES.indexOf(self.config.mode) !== -1) {
                    self.$el.find('.news-ticker__track').css('animation-play-state', 'running');
                } else if (SINGLE_ITEM_MODES.indexOf(self.config.mode) !== -1) {
                    self.startAutoPlay();
                }
            } else {
                self.isManualPaused = true;
                self.isPaused = true;
                $(this).html('\u25B6');
                if (SCROLL_MODES.indexOf(self.config.mode) !== -1) {
                    self.$el.find('.news-ticker__track').css('animation-play-state', 'paused');
                } else if (SINGLE_ITEM_MODES.indexOf(self.config.mode) !== -1) {
                    self.stopAutoPlay();
                }
            }
        });
    };

    NewsTicker.prototype.restartAutoPlay = function () {
        if (this.config.autoPlay && SINGLE_ITEM_MODES.indexOf(this.config.mode) !== -1) {
            this.startAutoPlay();
        }
    };

    // ─── INIT ALL TICKERS ───
    function initAllTickers() {
        $('[data-news-ticker]').each(function () {
            if (!$(this).data('newsTickerInit')) {
                $(this).data('newsTickerInit', true);
                new NewsTicker(this);
            }
        });
    }

    $(document).ready(initAllTickers);
    $(window).on('load', initAllTickers);

})(jQuery);
