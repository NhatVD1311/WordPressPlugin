/**
 * DNXTE — WhatsApp Widget admin settings.
 *
 * Agents are managed in the central Chat Agents CPT, so this script only wires
 * up the WP color picker for the global button colour fields. (The old
 * repeatable-agents / media-picker / scheduled-hours logic was removed when the
 * widget switched to sourcing agents from the CPT.)
 */
(function ($) {
  'use strict';

  $(function () {
    /** Init the WP color picker on any un-initialised fields. */
    function initColorPickers($scope) {
      if (typeof $.fn.wpColorPicker !== 'function') {
        return;
      }
      $scope.find('.dnxte-wa-color-field').each(function () {
        var $el = $(this);
        if (!$el.closest('.wp-picker-container').length) {
          $el.wpColorPicker();
        }
      });
    }

    // Global color fields (button bg / color).
    initColorPickers($(document));
  });
})(jQuery);
