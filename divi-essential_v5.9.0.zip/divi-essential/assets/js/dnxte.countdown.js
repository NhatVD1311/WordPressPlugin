(function ($) {
    'use strict';

    /**
     * DNXTE Countdown Module
     * Handles countdown timer functionality for frontend
     */
    class DNXTECountdown {
        constructor(element) {
            this.$wrapper = $(element);
            this.settings = this.getSettings();
            this.interval = null;
            this.endTime = null;

            this.init();
        }

        getSettings() {
            const $wrapper = this.$wrapper;
            return {
                countdownType: $wrapper.data('countdown-type') || 'fixed',
                endDate: $wrapper.data('end-date') || '',
                evergreenDays: parseInt($wrapper.data('evergreen-days')) || 0,
                evergreenHours: parseInt($wrapper.data('evergreen-hours')) || 0,
                evergreenMinutes: parseInt($wrapper.data('evergreen-minutes')) || 0,
                evergreenSeconds: parseInt($wrapper.data('evergreen-seconds')) || 0,
                cookieDuration: parseInt($wrapper.data('cookie-duration')) || 24,
                displayStyle: $wrapper.data('display-style') || 'default',
                showDays: $wrapper.data('show-days') === 'on',
                showHours: $wrapper.data('show-hours') === 'on',
                showMinutes: $wrapper.data('show-minutes') === 'on',
                showSeconds: $wrapper.data('show-seconds') === 'on',
                labelDays: $wrapper.data('label-days') || 'Days',
                labelHours: $wrapper.data('label-hours') || 'Hours',
                labelMinutes: $wrapper.data('label-minutes') || 'Minutes',
                labelSeconds: $wrapper.data('label-seconds') || 'Seconds',
                separator: $wrapper.data('separator') || ':',
                expireAction: $wrapper.data('expire-action') || 'hide',
                expireMessage: $wrapper.data('expire-message') || "Time's up!",
                expireRedirect: $wrapper.data('expire-redirect') || '',
                circleSize: parseInt($wrapper.data('circle-size')) || 120,
                strokeWidth: parseInt($wrapper.data('stroke-width')) || 8,
                trackColor: $wrapper.data('track-color') || '#e0e0e0',
                progressColor: $wrapper.data('progress-color') || '#2196f3'
            };
        }

        init() {
            this.calculateEndTime();
            this.startCountdown();
        }

        // Method to refresh countdown with current settings
        refresh(forceRecalculate = false) {
            // Stop current countdown
            if (this.interval) {
                clearInterval(this.interval);
                this.interval = null;
            }

            // Recalculate settings and end time
            this.settings = this.getSettings();
            this.calculateEndTime(forceRecalculate);
            this.startCountdown();
        }

        calculateEndTime(forceRecalculate = false) {
            if (this.settings.countdownType === 'fixed') {
                // Fixed date countdown
                if (this.settings.endDate) {
                    this.endTime = new Date(this.settings.endDate).getTime();
                } else {
                    // Default to 1 day from now if no date set
                    this.endTime = Date.now() + (24 * 60 * 60 * 1000);
                }
            } else if (this.settings.countdownType === 'evergreen') {
                // Evergreen countdown - per visitor
                const cookieName = this.getCookieName();
                const savedEndTime = this.getCookie(cookieName);
                const settingsHash = this.getSettingsHash();
                const savedSettingsHash = this.getCookie(cookieName + '_settings');

                // Check if settings have changed or if forced to recalculate
                const settingsChanged = savedSettingsHash !== settingsHash;
                const shouldRecalculate = forceRecalculate || settingsChanged || !savedEndTime || parseInt(savedEndTime) <= Date.now();

                if (!shouldRecalculate && savedEndTime && parseInt(savedEndTime) > Date.now()) {
                    // Use saved end time if settings haven't changed and it's still valid
                    this.endTime = parseInt(savedEndTime);
                } else {
                    // Calculate new end time
                    const duration =
                        (this.settings.evergreenDays * 24 * 60 * 60 * 1000) +
                        (this.settings.evergreenHours * 60 * 60 * 1000) +
                        (this.settings.evergreenMinutes * 60 * 1000) +
                        (this.settings.evergreenSeconds * 1000);

                    this.endTime = Date.now() + duration;

                    // Save to cookies
                    this.setCookie(cookieName, this.endTime, this.settings.cookieDuration);
                    this.setCookie(cookieName + '_settings', settingsHash, this.settings.cookieDuration);
                }
            }
        }

        getCookieName() {
            // Generate unique cookie name based on wrapper's parent ID or position
            const $parent = this.$wrapper.closest('[id]');
            const moduleId = $parent.attr('id') || 'countdown_' + this.$wrapper.index();
            return 'dnxte_countdown_' + moduleId;
        }

        getSettingsHash() {
            // Create a hash of the evergreen settings to detect changes
            const settingsString = [
                this.settings.evergreenDays,
                this.settings.evergreenHours,
                this.settings.evergreenMinutes,
                this.settings.evergreenSeconds,
                this.settings.cookieDuration
            ].join('|');
            
            // Simple hash function (djb2)
            let hash = 5381;
            for (let i = 0; i < settingsString.length; i++) {
                hash = ((hash << 5) + hash) + settingsString.charCodeAt(i);
            }
            return hash.toString();
        }

        getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) {
                return parts.pop().split(';').shift();
            }
            return null;
        }

        setCookie(name, value, hours) {
            const expires = new Date(Date.now() + hours * 60 * 60 * 1000);
            document.cookie = `${name}=${value}; expires=${expires.toUTCString()}; path=/`;
        }

        startCountdown() {
            // Initial update
            this.updateCountdown();

            // Update every second
            this.interval = setInterval(() => {
                this.updateCountdown();
            }, 1000);
        }

        updateCountdown() {
            const now = Date.now();
            const remaining = this.endTime - now;

            if (remaining <= 0) {
                this.handleExpiration();
                return;
            }

            const time = this.calculateTime(remaining);
            this.renderTime(time);
        }

        calculateTime(remaining) {
            const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
            const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((remaining % (1000 * 60)) / 1000);

            return { days, hours, minutes, seconds };
        }

        renderTime(time) {
            const style = this.settings.displayStyle;

            if (style === 'minimal') {
                this.renderMinimal(time);
            } else if (style === 'circle') {
                this.renderCircle(time);
            } else if (style === 'flip') {
                this.renderFlip(time);
            } else {
                this.renderDefault(time);
            }
        }

        renderDefault(time) {
            if (this.settings.showDays) {
                this.updateUnit('days', this.padNumber(time.days));
            }
            if (this.settings.showHours) {
                this.updateUnit('hours', this.padNumber(time.hours));
            }
            if (this.settings.showMinutes) {
                this.updateUnit('minutes', this.padNumber(time.minutes));
            }
            if (this.settings.showSeconds) {
                this.updateUnit('seconds', this.padNumber(time.seconds));
            }
        }

        renderMinimal(time) {
            const parts = [];

            if (this.settings.showDays && time.days > 0) {
                const suffix = this.settings.labelDays ? this.settings.labelDays.charAt(0).toLowerCase() : '';
                parts.push(`${time.days}${suffix}`);
            }
            if (this.settings.showHours) {
                const suffix = this.settings.labelHours ? this.settings.labelHours.charAt(0).toLowerCase() : '';
                parts.push(`${this.padNumber(time.hours)}${suffix}`);
            }
            if (this.settings.showMinutes) {
                const suffix = this.settings.labelMinutes ? this.settings.labelMinutes.charAt(0).toLowerCase() : '';
                parts.push(`${this.padNumber(time.minutes)}${suffix}`);
            }
            if (this.settings.showSeconds) {
                const suffix = this.settings.labelSeconds ? this.settings.labelSeconds.charAt(0).toLowerCase() : '';
                parts.push(`${this.padNumber(time.seconds)}${suffix}`);
            }

            const separator = this.settings.separator;
            const joinChar = (separator === 'none' || separator === '') ? ' ' : `<span class="dnxte-countdown-separator">${separator}</span>`;
            const minimalDisplay = this.$wrapper.find('.dnxte-countdown-number[data-minimal="true"]');
            if (minimalDisplay.length) {
                minimalDisplay.html(parts.join(joinChar));
            }
        }

        renderFlip(time) {
            if (this.settings.showDays) {
                this.updateFlipUnit('days', this.padNumber(time.days));
            }
            if (this.settings.showHours) {
                this.updateFlipUnit('hours', this.padNumber(time.hours));
            }
            if (this.settings.showMinutes) {
                this.updateFlipUnit('minutes', this.padNumber(time.minutes));
            }
            if (this.settings.showSeconds) {
                this.updateFlipUnit('seconds', this.padNumber(time.seconds));
            }
        }

        renderCircle(time) {
            const units = ['days', 'hours', 'minutes', 'seconds'];
            const maxValues = { days: 365, hours: 24, minutes: 60, seconds: 60 };

            units.forEach(unit => {
                const show = this.settings[`show${unit.charAt(0).toUpperCase() + unit.slice(1)}`];
                if (!show) return;

                const value = time[unit];
                const max = maxValues[unit];
                const progress = (value / max) * 100;

                this.updateCircleUnit(unit, this.padNumber(value), progress);
            });
        }

        updateUnit(unit, value) {
            const $unit = this.$wrapper.find(`.dnxte-countdown-unit[data-unit="${unit}"] .dnxte-countdown-number`);
            if ($unit.length) {
                $unit.text(value);
            }
        }

        updateFlipUnit(unit, value) {
            const $unit = this.$wrapper.find(`.dnxte-countdown-flip-unit[data-unit="${unit}"]`);
            if (!$unit.length) return;

            const $numbers = $unit.find('.dnxte-countdown-number');
            const currentValue = $numbers.first().text();

            if (currentValue !== value) {
                // Add flip animation class
                const $card = $unit.find('.dnxte-countdown-flip-card-inner');
                $card.addClass('flipping');

                // Update numbers
                $numbers.text(value);

                // Remove animation class after animation completes
                setTimeout(() => {
                    $card.removeClass('flipping');
                }, 600);
            }
        }

        updateCircleUnit(unit, value, progress) {
            const $unit = this.$wrapper.find(`.dnxte-countdown-circle-unit[data-unit="${unit}"]`);
            if (!$unit.length) return;

            // Update number
            const $number = $unit.find('.dnxte-countdown-number');
            $number.text(value);

            // Update circle progress
            const $progressCircle = $unit.find('.dnxte-countdown-circle-progress');
            if ($progressCircle.length) {
                const radius = parseFloat($progressCircle.attr('r'));
                const circumference = radius * 2 * Math.PI;
                const offset = circumference - (progress / 100) * circumference;
                $progressCircle.css('stroke-dashoffset', offset);
            }
        }

        padNumber(num) {
            return num.toString().padStart(2, '0');
        }

        handleExpiration() {
            // Clear interval
            if (this.interval) {
                clearInterval(this.interval);
                this.interval = null;
            }

            // Set all values to 00
            this.renderTime({ days: 0, hours: 0, minutes: 0, seconds: 0 });

            // Handle expiration action
            switch (this.settings.expireAction) {
                case 'hide':
                    this.$wrapper.fadeOut(500);
                    break;

                case 'message':
                    this.$wrapper.html(`<div class="dnxte-countdown-expired-message">${this.settings.expireMessage}</div>`);
                    break;

                case 'redirect':
                    if (this.settings.expireRedirect) {
                        window.location.href = this.settings.expireRedirect;
                    }
                    break;
            }

            // Clear cookies for evergreen timers
            if (this.settings.countdownType === 'evergreen') {
                const cookieName = this.getCookieName();
                document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
                document.cookie = `${cookieName}_settings=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
            }
        }

        destroy() {
            if (this.interval) {
                clearInterval(this.interval);
                this.interval = null;
            }
        }
    }

    // Initialize all countdown modules on page load
    function initCountdowns() {
        $('.dnxte-countdown-wrapper').each(function () {
            if (!$(this).data('dnxte-countdown-initialized')) {
                const countdown = new DNXTECountdown(this);
                $(this).data('dnxte-countdown-initialized', true);
                $(this).data('dnxte-countdown-instance', countdown);
            }
        });
    }

    // Function to refresh all countdowns (useful when settings change)
    function refreshCountdowns(forceRecalculate = false) {
        $('.dnxte-countdown-wrapper').each(function () {
            const countdown = $(this).data('dnxte-countdown-instance');
            if (countdown && typeof countdown.refresh === 'function') {
                countdown.refresh(forceRecalculate);
            }
        });
    }

    // Initialize on document ready
    $(document).ready(function () {
        initCountdowns();
    });

    // Re-initialize on window load (for any lazy-loaded content)
    $(window).on('load', function () {
        initCountdowns();
    });

    // Support for Divi Visual Builder preview
    if (typeof window.et_builder_utils !== 'undefined') {
        $(document).on('et_builder_api_ready', function () {
            initCountdowns();
        });
    }

    // Observe DOM for wrappers injected after page load (popups, AJAX, builder injections).
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function (mutations) {
            for (let i = 0; i < mutations.length; i++) {
                const added = mutations[i].addedNodes;
                for (let j = 0; j < added.length; j++) {
                    const node = added[j];
                    if (node.nodeType !== 1) continue;
                    if ((node.matches && node.matches('.dnxte-countdown-wrapper')) ||
                        (node.querySelector && node.querySelector('.dnxte-countdown-wrapper'))) {
                        initCountdowns();
                        return;
                    }
                }
            }
        });
        const startObserving = function () {
            observer.observe(document.body, { childList: true, subtree: true });
        };
        if (document.body) {
            startObserving();
        } else {
            $(document).ready(startObserving);
        }
    }

    // Expose for external access
    window.DNXTECountdown = DNXTECountdown;
    window.initDNXTECountdowns = initCountdowns;
    window.refreshDNXTECountdowns = refreshCountdowns;

})(jQuery);
