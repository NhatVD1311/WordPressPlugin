/**
 * Scroll Stack — VB Extension
 * Section-only card-stack scroll. Options mirror Divi Animation (Card Stack).
 * Uses Divi native fields (toggle, range, select, text).
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var wp = window.vendor.wp;
  var hooks = wp.hooks;
  var TARGET = ['divi/section', 'divi/row', 'divi/row-inner', 'divi/column', 'divi/column-inner'];

  function isTarget(name) { return TARGET.indexOf(name) !== -1; }
  function isOn(p) { return 'on' === (p.attrs?.dnxte_sstack?.advanced?.enabled?.desktop?.value); }

  function buildGroup() {
    return {
      groupName: 'dnxteScrollStack',
      panel: 'design',
      priority: 93,
      multiElements: true,
      component: { name: 'divi/composite', props: { groupLabel: 'Scroll Stack' } }
    };
  }

  hooks.addFilter('divi.moduleLibrary.moduleSettings.groups', 'dnxte-sstack', function (groups, meta) {
    if (!isTarget(meta.name)) return groups;
    var next = Object.assign({}, groups || {});
    if (!next.dnxteScrollStack) next.dnxteScrollStack = buildGroup();
    return next;
  });

  hooks.addFilter('divi.moduleLibrary.moduleAttributes', 'dnxte-sstack', function (attrs, meta) {
    if (!isTarget(meta.name)) return attrs;

    attrs.dnxte_sstack = {
      type: 'object',
      selector: '{{selector}}',
      default: { advanced: {
        enabled:     { desktop: { value: 'off' } },
        mode:        { desktop: { value: 'stack' } },
        style:       { desktop: { value: 'flat' } },
        stackOffset: { desktop: { value: '10px' } },
        scrubSpeed:  { desktop: { value: '1' } },
        startOffset: { desktop: { value: 'top top' } },
        fade:        { desktop: { value: 'off' } },
        blur:        { desktop: { value: '0' } },
        rotate:      { desktop: { value: '0' } },
      }},
      settings: { advanced: {
        enabled: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.enabled', label: 'Enable Scroll Stack',
          description: 'Stack the child panels as the user scrolls (rows in a Section, columns in a Row, modules in a Column).',
          groupSlug: 'dnxteScrollStack', priority: 1, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' }
        }},
        mode: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.mode', label: 'Mode',
          groupSlug: 'dnxteScrollStack', priority: 10, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'stack':           { label: 'Stack' },
            'peel':            { label: 'Peel Up' },
            'horizontalStack': { label: 'Slide Stack' },
            'horizontalPeel':  { label: 'Slide Peel' },
          } } },
          visible: isOn
        }},
        style: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.style', label: 'Style',
          groupSlug: 'dnxteScrollStack', priority: 12, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/select', props: { options: {
            'flat':        { label: 'Flat' },
            'slideRotate': { label: 'Tilt' },
          } } },
          visible: isOn
        }},
        stackOffset: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.stackOffset', label: 'Stack Gap',
          description: 'Visible gap between stacked cards.',
          groupSlug: 'dnxteScrollStack', priority: 14, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 200, step: 1, defaultUnit: 'px' } },
          visible: isOn
        }},
        scrubSpeed: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.scrubSpeed', label: 'Smoothness',
          description: 'Higher = looser / slower follow.',
          groupSlug: 'dnxteScrollStack', priority: 16, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0.1, max: 5, step: 0.1, defaultUnit: '' } },
          visible: isOn
        }},
        startOffset: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.startOffset', label: 'Start Point',
          description: 'ScrollTrigger start, e.g. "top top".',
          groupSlug: 'dnxteScrollStack', priority: 18, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/text' },
          visible: isOn
        }},

        // ── Extra reveal (fade / blur / tilt) ──
        fade: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.fade', label: 'Fade In',
          description: 'Fade each panel in as it scrolls into view.',
          groupSlug: 'dnxteScrollStack', priority: 40, render: true,
          features: { sticky: false, hover: false, responsive: false },
          component: { type: 'field', name: 'divi/toggle' },
          visible: isOn
        }},
        blur: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.blur', label: 'Blur In',
          description: 'Start blurred, sharpen on reveal (0 = off).',
          groupSlug: 'dnxteScrollStack', priority: 42, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: 0, max: 30, step: 1, defaultUnit: 'px' } },
          visible: isOn
        }},
        rotate: { groupType: 'group-item', item: {
          attrName: 'dnxte_sstack.advanced.rotate', label: 'Tilt In',
          description: 'Start tilted, straighten on reveal (0 = off).',
          groupSlug: 'dnxteScrollStack', priority: 44, render: true,
          features: { sticky: false },
          component: { type: 'field', name: 'divi/range', props: { min: -45, max: 45, step: 1, defaultUnit: 'deg' } },
          visible: isOn
        }},
      }}
    };

    if (meta && typeof meta === 'object') {
      if (!meta.settings) meta.settings = {};
      if (!meta.settings.groups) meta.settings.groups = {};
      if (!meta.settings.groups.dnxteScrollStack) {
        meta.settings.groups.dnxteScrollStack = buildGroup();
      }
    }

    return attrs;
  });
})();
