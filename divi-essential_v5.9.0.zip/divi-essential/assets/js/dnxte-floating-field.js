/**
 * Floating Elements — Custom Repeater Field
 * Clean UI, no drag, proper range styling.
 *
 * @package DNXTE
 */
(function () {
  'use strict';

  var React = window.vendor.React;
  var h = React.createElement;
  var useState = React.useState;
  var useEffect = React.useEffect;

  var uid = 0;
  function nextId() { return 'fi_' + (++uid) + '_' + Date.now(); }

  var PRESETS = {
    'gentle-float': 'Gentle Float',
    'orbit':        'Orbit',
    'bounce':       'Bounce',
    'sway':         'Sway',
    'zigzag':       'Zigzag',
    'pulse':        'Pulse',
    'drift':        'Drift',
    'spin-float':   'Spin Float',
    'pendulum':     'Pendulum',
    'elastic-pop':  'Elastic Pop',
  };
  var EASINGS = {
    'sine.inOut':   'Sine (Smooth)',
    'power1.inOut': 'Power1 (Gentle)',
    'power2.inOut': 'Power2 (Medium)',
    'power3.inOut': 'Power3 (Strong)',
    'elastic.out':  'Elastic',
    'bounce.out':   'Bounce',
    'back.inOut':   'Back (Overshoot)',
    'none':         'Linear',
  };
  var DIRECTIONS = {
    'both':       'Both (X + Y)',
    'vertical':   'Vertical Only',
    'horizontal': 'Horizontal Only',
    'diagonal':   'Diagonal',
  };

  function parseItems(val) {
    if (!val) return [];
    if (typeof val === 'string') { try { return JSON.parse(val); } catch (e) { return []; } }
    return Array.isArray(val) ? val : [];
  }

  function defaultItem() {
    return {
      id: nextId(), src: '', alt: '',
      posX: '20', posY: '20', width: '200', zIndex: '1', borderRadius: '0',
      preset: 'gentle-float', useCustom: false,
      yRange: '30', xRange: '25', rotRange: '8',
      duration: '6', delay: '0', easing: 'sine.inOut',
      direction: 'both', scale: '1.02',
      use3d: false, rotateXRange: '10', rotateYRange: '20',
      opacityMin: '1',
    };
  }

  // ─── Tokens ───
  var P = '#7c3aed';
  var Pbg = 'rgba(124,58,237,0.05)';
  var Pbdr = 'rgba(124,58,237,0.12)';
  var G1 = '#f7f7f9';
  var G2 = '#ebebef';
  var G3 = '#a0a0b0';
  var G4 = '#6e6e80';
  var G5 = '#3a3a4a';
  var R = '8px';

  // ─── Inject CSS for range thumb into ALL documents (parent + iframes) ───
  var _injected = new WeakSet();
  function css() {
    // Inject into current document
    _injectInto(document);
    // Also try iframe documents (VB renders in iframe)
    try {
      var frames = window.parent && window.parent.document ? [window.parent.document] : [];
      var iframes = document.querySelectorAll('iframe');
      for (var i = 0; i < iframes.length; i++) {
        try { if (iframes[i].contentDocument) frames.push(iframes[i].contentDocument); } catch(e) {}
      }
      frames.forEach(_injectInto);
    } catch(e) {}
  }
  function _injectInto(doc) {
    if (!doc || !doc.head || _injected.has(doc)) return;
    _injected.add(doc);
    var s = doc.createElement('style');
    s.setAttribute('data-dnxte-fr', '1');
    s.textContent =
      '.dfr{-webkit-appearance:none!important;appearance:none!important;width:100%!important;height:4px!important;border-radius:2px!important;outline:none!important;cursor:pointer!important;margin:0!important;padding:0!important;border:none!important;}' +
      '.dfr::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:inherit;}' +
      '.dfr::-webkit-slider-thumb{-webkit-appearance:none!important;appearance:none!important;width:14px!important;height:14px!important;border-radius:50%!important;background:#7c3aed!important;border:2.5px solid #fff!important;box-shadow:0 0 0 1px rgba(124,58,237,0.12),0 1px 3px rgba(0,0,0,0.12)!important;cursor:pointer!important;margin-top:-5px!important;transition:box-shadow 0.15s!important;}' +
      '.dfr::-webkit-slider-thumb:hover{box-shadow:0 0 0 2px rgba(124,58,237,0.2),0 2px 6px rgba(124,58,237,0.25)!important;}' +
      '.dfr::-moz-range-thumb{width:14px!important;height:14px!important;border-radius:50%!important;background:#7c3aed!important;border:2.5px solid #fff!important;box-shadow:0 0 0 1px rgba(124,58,237,0.12),0 1px 3px rgba(0,0,0,0.12)!important;cursor:pointer!important;}' +
      '.dfr::-moz-range-track{height:4px!important;border-radius:2px!important;background:inherit!important;border:none!important;}';
    doc.head.appendChild(s);
  }

  // ─── Sub-components ───

  function Slider(p) {
    css();
    var pct = Math.max(0, Math.min(100, ((parseFloat(p.value) - p.min) / (p.max - p.min)) * 100));
    var trackBg = 'linear-gradient(to right,' + P + ' ' + pct + '%,' + G2 + ' ' + pct + '%)';
    return h('div', { style: { marginBottom: '12px' } },
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '5px' } },
        h('span', { style: { fontSize: '11.5px', color: G4, fontWeight: '500' } }, p.label),
        h('span', { style: { fontSize: '11px', fontWeight: '600', color: P, background: Pbg, padding: '1px 7px', borderRadius: '3px' } }, p.value + (p.unit || ''))
      ),
      h('input', {
        type: 'range', className: 'dfr',
        min: p.min, max: p.max, step: p.step || 1, value: p.value,
        onChange: function (e) { p.onChange(e.target.value); },
        style: {
          width: '100%', height: '4px', borderRadius: '2px',
          background: trackBg, outline: 'none', border: 'none',
          WebkitAppearance: 'none', MozAppearance: 'none', appearance: 'none',
          cursor: 'pointer', margin: 0, padding: 0,
          accentColor: P,
        }
      })
    );
  }

  function NumberInput(p) {
    return h('div', { style: { marginBottom: '12px' } },
      h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '5px' } },
        h('span', { style: { fontSize: '11.5px', color: G4, fontWeight: '500' } }, p.label),
        p.hint ? h('span', { style: { fontSize: '10px', color: G4, opacity: 0.7 } }, p.hint) : null
      ),
      h('input', {
        type: 'number',
        step: p.step || 1,
        value: p.value,
        placeholder: p.placeholder || '',
        onChange: function (e) { p.onChange(e.target.value); },
        style: {
          width: '100%', padding: '7px 10px', fontSize: '12px',
          border: '1px solid ' + G2, borderRadius: '6px',
          background: '#fff', color: G5, outline: 'none', boxSizing: 'border-box',
        }
      })
    );
  }

  function Dropdown(p) {
    return h('div', { style: { marginBottom: '12px' } },
      h('div', { style: { fontSize: '11.5px', color: G4, fontWeight: '500', marginBottom: '5px' } }, p.label),
      h('select', {
        value: p.value,
        onChange: function (e) { p.onChange(e.target.value); },
        style: { width: '100%', padding: '7px 10px', fontSize: '12px', border: '1px solid ' + G2, borderRadius: '6px', background: '#fff', color: G5, outline: 'none', cursor: 'pointer' }
      }, Object.keys(p.options).map(function (k) { return h('option', { key: k, value: k }, p.options[k]); }))
    );
  }

  function Switch(p) {
    var on = !!p.value;
    return h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' } },
      h('span', { style: { fontSize: '11.5px', color: G4, fontWeight: '500' } }, p.label),
      h('div', {
        onClick: function () { p.onChange(!on); },
        style: { width: '34px', height: '18px', borderRadius: '9px', background: on ? P : G3, cursor: 'pointer', transition: 'background 0.2s', position: 'relative' }
      },
        h('div', { style: { width: '14px', height: '14px', borderRadius: '50%', background: '#fff', position: 'absolute', top: '2px', left: on ? '18px' : '2px', transition: 'left 0.2s', boxShadow: '0 1px 2px rgba(0,0,0,0.12)' } })
      )
    );
  }

  function Divider(p) {
    return h('div', { style: { fontSize: '10px', fontWeight: '600', color: P, textTransform: 'uppercase', letterSpacing: '0.8px', margin: '14px 0 8px', paddingBottom: '5px', borderBottom: '1px solid ' + Pbdr } }, p.label);
  }

  // ─── Responsive device tabs (Desktop / Tablet / Phone) ───
  var DEVICES = [ ['desktop', 'Desktop'], ['tablet', 'Tablet'], ['phone', 'Phone'] ];
  var DEV_SUFFIX = { desktop: '', tablet: 'Tablet', phone: 'Phone' };
  function DevTabs(p) {
    return h('div', { style: { display: 'flex', gap: '4px', margin: '0 0 8px' } },
      DEVICES.map(function (d) {
        var active = p.dev === d[0];
        return h('button', {
          key: d[0], type: 'button', onClick: function () { p.setDev(d[0]); },
          style: { flex: '1', padding: '5px 4px', fontSize: '10.5px', fontWeight: '600', borderRadius: '6px', cursor: 'pointer', border: '1px solid ' + (active ? P : G2), background: active ? Pbg : '#fff', color: active ? P : G3 }
        }, d[1]);
      })
    );
  }

  // ─── Settings Tab ───
  function SettingsTab(p) {
    var item = p.item, u = p.update;
    var _d = useState('desktop');
    var dev = _d[0], setDev = _d[1];
    var suf = DEV_SUFFIX[dev];
    // Effective (inherited) value for the active device: device → tablet → desktop.
    function dval(base, def) {
      var v = item[base + suf];
      if (v !== undefined && v !== '' && v !== null) return v;
      if (dev === 'phone') { var t = item[base + 'Tablet']; if (t !== undefined && t !== '' && t !== null) return t; }
      var d = item[base];
      return (d !== undefined && d !== '' && d !== null) ? d : def;
    }
    function openMedia() {
      var wm = window.top && window.top.wp && window.top.wp.media;
      if (!wm) { var url = prompt('Image URL:'); if (url) u('src', url); return; }
      var fr = wm({ title: 'Select Image', button: { text: 'Use Image' }, multiple: false });
      fr.on('select', function () { var a = fr.state().get('selection').first().toJSON(); u('src', a.url); if (a.alt) u('alt', a.alt); });
      fr.open();
    }
    return h('div', null,
      Divider({ label: 'Image' }),
      h('div', { style: { marginBottom: '12px' } },
        item.src && h('div', { style: { position: 'relative', marginBottom: '6px', borderRadius: '6px', overflow: 'hidden' } },
          h('img', { src: item.src, style: { width: '100%', height: '72px', objectFit: 'cover', display: 'block' } }),
          h('button', { onClick: function () { u('src', ''); u('alt', ''); }, type: 'button',
            style: { position: 'absolute', top: '4px', right: '4px', width: '18px', height: '18px', borderRadius: '50%', border: 'none', background: 'rgba(0,0,0,0.5)', color: '#fff', fontSize: '10px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1 }
          }, '\u00D7')
        ),
        h('button', { onClick: openMedia, type: 'button',
          style: { width: '100%', padding: '8px', fontSize: '11.5px', fontWeight: '500', color: P, background: Pbg, border: '1px dashed ' + Pbdr, borderRadius: '6px', cursor: 'pointer', textAlign: 'center' }
        }, item.src ? 'Change Image' : 'Upload Image')
      ),
      Divider({ label: 'Position & Size' }),
      DevTabs({ dev: dev, setDev: setDev }),
      Slider({ label: 'X Position', min: 0, max: 100, value: dval('posX', '20'), unit: '%', onChange: function (v) { u('posX' + suf, v); } }),
      Slider({ label: 'Y Position', min: 0, max: 100, value: dval('posY', '20'), unit: '%', onChange: function (v) { u('posY' + suf, v); } }),
      Slider({ label: 'Width', min: 50, max: 600, step: 10, value: dval('width', '200'), unit: 'px', onChange: function (v) { u('width' + suf, v); } }),
      dev !== 'desktop' && h('div', { style: { fontSize: '10px', color: G3, margin: '-2px 0 8px' } }, 'Leave a value to override; matches Desktop otherwise.'),
      NumberInput({ label: 'Z-Index', hint: 'negative = behind content', value: item.zIndex != null ? item.zIndex : '1', placeholder: '1', onChange: function (v) { u('zIndex', v); } }),
      Slider({ label: 'Border Radius', min: 0, max: 50, value: item.borderRadius || '0', unit: 'px', onChange: function (v) { u('borderRadius', v); } }),
      Divider({ label: 'Visibility' }),
      Switch({ label: 'Hide on Tablet', value: !!item.hideTablet, onChange: function (v) { u('hideTablet', v); } }),
      Switch({ label: 'Hide on Phone', value: !!item.hidePhone, onChange: function (v) { u('hidePhone', v); } })
    );
  }

  // ─── Animation Tab ───
  function AnimationTab(p) {
    var item = p.item, u = p.update;
    var custom = !!item.useCustom;
    return h('div', null,
      Divider({ label: 'Style' }),
      Dropdown({ label: 'Preset', value: item.preset || 'gentle-float', options: PRESETS, onChange: function (v) { u('preset', v); } }),
      Switch({ label: 'Custom Override', value: custom, onChange: function (v) { u('useCustom', v); } }),
      custom && h('div', null,
        Divider({ label: 'Movement' }),
        Dropdown({ label: 'Direction', value: item.direction || 'both', options: DIRECTIONS, onChange: function (v) { u('direction', v); } }),
        Slider({ label: 'Vertical Range', min: 0, max: 150, value: item.yRange || '30', unit: 'px', onChange: function (v) { u('yRange', v); } }),
        Slider({ label: 'Horizontal Range', min: 0, max: 150, value: item.xRange || '25', unit: 'px', onChange: function (v) { u('xRange', v); } }),
        Slider({ label: 'Rotation', min: 0, max: 180, value: item.rotRange || '8', unit: '\u00B0', onChange: function (v) { u('rotRange', v); } }),
        Divider({ label: 'Timing' }),
        Slider({ label: 'Duration', min: 1, max: 30, step: 0.5, value: item.duration || '6', unit: 's', onChange: function (v) { u('duration', v); } }),
        Slider({ label: 'Delay', min: 0, max: 5, step: 0.1, value: item.delay || '0', unit: 's', onChange: function (v) { u('delay', v); } }),
        Dropdown({ label: 'Easing', value: item.easing || 'sine.inOut', options: EASINGS, onChange: function (v) { u('easing', v); } }),
        Divider({ label: 'Effects' }),
        Slider({ label: 'Scale Breathing', min: 1, max: 1.5, step: 0.01, value: item.scale || '1.02', unit: 'x', onChange: function (v) { u('scale', v); } }),
        Slider({ label: 'Min Opacity', min: 0, max: 1, step: 0.05, value: item.opacityMin || '1', unit: '', onChange: function (v) { u('opacityMin', v); } }),
        Divider({ label: '3D Rotation' }),
        Switch({ label: 'Enable 3D', value: !!item.use3d, onChange: function (v) { u('use3d', v); } }),
        !!item.use3d && h('div', null,
          Slider({ label: 'Rotate X', min: 0, max: 45, value: item.rotateXRange || '10', unit: '\u00B0', onChange: function (v) { u('rotateXRange', v); } }),
          Slider({ label: 'Rotate Y', min: 0, max: 45, value: item.rotateYRange || '20', unit: '\u00B0', onChange: function (v) { u('rotateYRange', v); } })
        )
      )
    );
  }

  // ─── Accordion Item ───
  function FloatingItem(props) {
    var item = props.item, isOpen = props.isOpen, idx = props.index;
    var _t = useState('settings');
    var tab = _t[0], setTab = _t[1];

    function u(key, val) {
      var up = Object.assign({}, item); up[key] = val; props.onChange(up);
    }
    var presetLabel = PRESETS[item.preset] || 'Gentle Float';
    var hasImg = !!item.src;

    return h('div', {
      style: {
        borderRadius: R,
        marginBottom: '6px',
        background: '#fff',
        border: '1px solid ' + (isOpen ? P : G2),
        overflow: 'hidden',
        transition: 'border-color 0.15s, box-shadow 0.15s',
        boxShadow: isOpen ? '0 0 0 1px ' + Pbdr : 'none',
      }
    },
      // ── Header ──
      h('div', {
        onClick: props.onToggle,
        style: {
          display: 'flex', alignItems: 'center', gap: '10px',
          padding: '7px 10px', cursor: 'pointer', userSelect: 'none',
          background: isOpen ? Pbg : '#fff',
        }
      },
        // Thumb
        hasImg
          ? h('img', { src: item.src, style: { width: '30px', height: '30px', borderRadius: '6px', objectFit: 'cover', flexShrink: 0 } })
          : h('div', { style: { width: '30px', height: '30px', borderRadius: '6px', background: G1, border: '1px dashed ' + G2, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: '12px', color: G3 } }, (idx + 1)),
        // Text
        h('div', { style: { flex: 1, minWidth: 0 } },
          h('div', { style: { fontSize: '12px', fontWeight: '600', color: G5, lineHeight: 1.2 } }, (hasImg ? 'Image ' : 'Item ') + (idx + 1)),
          h('div', { style: { fontSize: '10px', color: G3, marginTop: '2px' } }, presetLabel + (item.useCustom ? '  \u2022  Custom' : ''))
        ),
        // Clone
        h('button', {
          onClick: function (e) { e.stopPropagation(); props.onClone(); },
          title: 'Duplicate', type: 'button',
          style: { background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: G3, fontSize: '14px', lineHeight: 1 }
        }, h('svg', { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' },
          h('rect', { x: 9, y: 9, width: 13, height: 13, rx: 2 }),
          h('path', { d: 'M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1' })
        )),
        // Delete
        h('button', {
          onClick: function (e) { e.stopPropagation(); props.onDelete(); },
          title: 'Remove', type: 'button',
          style: { background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: G3, fontSize: '14px', lineHeight: 1 }
        }, h('svg', { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' },
          h('polyline', { points: '3 6 5 6 21 6' }),
          h('path', { d: 'M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6m5 0V4a1 1 0 011-1h2a1 1 0 011 1v2' })
        )),
        // Chevron
        h('svg', {
          width: 12, height: 12, viewBox: '0 0 12 12',
          style: { transition: 'transform 0.2s', transform: isOpen ? 'rotate(180deg)' : 'none', flexShrink: 0, color: G3 }
        }, h('path', { d: 'M2.5 4.5l3.5 3 3.5-3', stroke: 'currentColor', strokeWidth: 1.5, fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' }))
      ),

      // ── Tabs + Body ──
      isOpen && h('div', null,
        h('div', { style: { display: 'flex', background: G1 } },
          ['settings', 'animation'].map(function (t) {
            var active = tab === t;
            return h('button', {
              key: t, type: 'button',
              onClick: function () { setTab(t); },
              style: {
                flex: 1, padding: '7px 0', textAlign: 'center',
                fontSize: '11px', fontWeight: active ? '600' : '400',
                color: active ? P : G3,
                background: active ? '#fff' : 'transparent',
                border: 'none', borderBottom: active ? '2px solid ' + P : '2px solid transparent',
                cursor: 'pointer', transition: 'all 0.15s',
              }
            }, t.charAt(0).toUpperCase() + t.slice(1));
          })
        ),
        h('div', { style: { padding: '10px 12px' } },
          tab === 'settings' ? h(SettingsTab, { item: item, update: u }) : h(AnimationTab, { item: item, update: u })
        )
      )
    );
  }

  // ─── Main Repeater ───
  function FloatingImageRepeater(props) {
    var value = props.value || props.defaultValue || '';
    var items = parseItems(typeof value === 'object' && value.desktop ? value.desktop.value : value);
    var _s = useState(null);
    var openId = _s[0], setOpenId = _s[1];

    function fire(arr) {
      if (props.onChange) { props.onChange({ event: { target: { value: JSON.stringify(arr) } } }); }
    }
    function add() { var n = defaultItem(); fire(items.concat([n])); setOpenId(n.id); }
    function clone(i) { var c = Object.assign({}, items[i], { id: nextId() }); var a = items.slice(); a.splice(i+1,0,c); fire(a); setOpenId(c.id); }

    return h('div', { style: { fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif', fontSize: '13px' } },
      items.length === 0 && h('div', { style: { textAlign: 'center', padding: '16px', color: G3, fontSize: '12px' } }, 'No floating images added.'),
      items.map(function (item, i) {
        var key = item.id || i;
        return h(FloatingItem, {
          key: key, item: item, index: i,
          isOpen: openId === key,
          onToggle: function () { setOpenId(openId === key ? null : key); },
          onChange: function (u) { var a = items.slice(); a[i] = u; fire(a); },
          onDelete: function () { var a = items.slice(); if (openId === key) setOpenId(null); a.splice(i,1); fire(a); },
          onClone: function () { clone(i); },
        });
      }),
      h('button', {
        onClick: add, type: 'button',
        style: {
          width: '100%', padding: '9px', fontSize: '12px', fontWeight: '500',
          color: P, background: Pbg, border: '1.5px dashed ' + Pbdr,
          borderRadius: R, cursor: 'pointer', textAlign: 'center', marginTop: '2px',
        }
      }, '+ Add Floating Image')
    );
  }

  FloatingImageRepeater.fieldName = 'dnxte/floating-image-repeater';
  function reg() {
    if (window.divi && window.divi.fieldLibrary && window.divi.fieldLibrary.registerFieldComponent) {
      window.divi.fieldLibrary.registerFieldComponent({ name: 'dnxte/floating-image-repeater', component: FloatingImageRepeater });
    }
  }
  window.vendor.wp.hooks.addAction('divi.moduleLibrary.registerModuleLibraryStore.after', 'dnxte-floating-field', reg, 5);
  window.vendor.wp.hooks.addAction('divi.moduleLibrary.registerModuleLibraryStore.before', 'dnxte-floating-field-early', reg);
  window.DnxteFloatingImageRepeater = FloatingImageRepeater;
})();
