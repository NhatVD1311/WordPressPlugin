(function () {
  'use strict';

  function initSpinWheel(container) {
    if (container.dataset.dnxteSpinWheelInit) return;
    container.dataset.dnxteSpinWheelInit = 'true';

    var wrapper = container.querySelector('.dnxte-spin-wheel__wheel-wrapper');
    var wheel = container.querySelector('.dnxte-spin-wheel__wheel');
    var formSection = container.querySelector('.dnxte-spin-wheel__form-section');
    var resultSection = container.querySelector('.dnxte-spin-wheel__result-section');
    var emailInput = container.querySelector('.dnxte-spin-wheel__email-input');
    var emailError = container.querySelector('.dnxte-spin-wheel__email-error');
    var submitBtn = container.querySelector('.dnxte-spin-wheel__submit-btn');
    var resultTitle = container.querySelector('.dnxte-spin-wheel__result-title');
    var resultDesc = container.querySelector('.dnxte-spin-wheel__result-description');
    var couponBox = container.querySelector('.dnxte-spin-wheel__coupon-box');
    var couponCodeEl = container.querySelector('.dnxte-spin-wheel__coupon-code');
    var couponTooltip = container.querySelector('.dnxte-spin-wheel__coupon-tooltip');
    var applyBtn = container.querySelector('.dnxte-spin-wheel__apply-btn');
    var tryAgainBtn = container.querySelector('.dnxte-spin-wheel__try-again-btn');
    var dismissBtn = container.querySelector('.dnxte-spin-wheel__dismiss');
    var confettiEl = container.querySelector('.dnxte-spin-wheel__confetti');

    if (!wrapper || !wheel) return;

    // Segments contain only label + color (no sensitive data like coupon codes or probabilities).
    var segments = [];
    try {
      segments = JSON.parse(wrapper.dataset.segments || '[]');
    } catch (e) {
      return;
    }

    if (segments.length === 0) return;

    var duration = parseInt(wrapper.dataset.spinDuration, 10) || 4000;
    var easing = wrapper.dataset.spinEasing || 'cubic-bezier(0.17, 0.67, 0.12, 0.99)';
    var pointerPosition = wrapper.dataset.pointerPosition || 'top';
    var moduleId = container.dataset.moduleId || '';
    var postId = container.dataset.postId || '0';
    var requireEmail = container.dataset.requireEmail === 'true';
    var showConfetti = container.dataset.confetti === 'true';
    var restUrl = container.dataset.restUrl || '';
    var nonce = container.dataset.nonce || '';

    // Fallback to global localized data.
    if (!restUrl && typeof dnxteSpinWheel !== 'undefined') {
      restUrl = dnxteSpinWheel.restUrl || '';
      nonce = dnxteSpinWheel.nonce || '';
    }

    var isSpinning = false;
    var currentRotation = 0;

    /**
     * Client-side fallback: equal probability (no weights available from server).
     * Only used when REST call fails completely.
     */
    function pickWinnerClient() {
      return Math.floor(Math.random() * segments.length);
    }

    function validateEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function showError(msg) {
      if (emailError) {
        emailError.textContent = msg;
        emailError.style.display = 'block';
      }
      if (emailInput) {
        emailInput.classList.add('dnxte-spin-wheel__email-input--error');
      }
    }

    function clearError() {
      if (emailError) {
        emailError.textContent = '';
        emailError.style.display = 'none';
      }
      if (emailInput) {
        emailInput.classList.remove('dnxte-spin-wheel__email-input--error');
      }
    }

    function spinWheel(winnerIndex, winnerData) {
      isSpinning = true;

      // Remove idle animation during spin.
      var idleClasses = ['dnxte-spin-wheel__idle-pulse', 'dnxte-spin-wheel__idle-rotate', 'dnxte-spin-wheel__idle-glow', 'dnxte-spin-wheel__idle-wobble'];
      var hadIdle = '';
      idleClasses.forEach(function (cls) {
        if (wrapper.classList.contains(cls)) {
          hadIdle = cls;
          wrapper.classList.remove(cls);
        }
      });

      var anglePerSegment = 360 / segments.length;
      // Offset for pointer position: top=0°, right=90° (segments start at -90° / top).
      var pointerOffset = pointerPosition === 'right' ? 90 : 0;
      var targetAngle = 360 - (winnerIndex * anglePerSegment + anglePerSegment / 2) + pointerOffset;
      var extraSpins = (Math.floor(Math.random() * 4) + 5) * 360;
      var finalRotation = currentRotation + extraSpins + targetAngle - (currentRotation % 360);

      wheel.style.transition = 'transform ' + duration + 'ms ' + easing;
      wheel.style.transform = 'rotate(' + finalRotation + 'deg)';
      currentRotation = finalRotation;

      setTimeout(function () {
        isSpinning = false;

        // Restore idle animation.
        if (hadIdle) {
          wrapper.classList.add(hadIdle);
        }

        // Dispatch custom event.
        var event = new CustomEvent('dnxte-spin-wheel-result', {
          detail: { index: winnerIndex, segment: winnerData },
          bubbles: true,
        });
        wrapper.dispatchEvent(event);

        // Show result.
        showResult(winnerData);
      }, duration + 200);
    }

    /**
     * Reset result UI elements to default hidden state.
     */
    function resetResultUI() {
      if (couponBox) couponBox.style.display = 'none';
      if (couponCodeEl) couponCodeEl.textContent = '';
      if (applyBtn) applyBtn.style.display = 'none';
      if (tryAgainBtn) tryAgainBtn.style.display = 'none';
      if (dismissBtn) dismissBtn.style.display = 'none';
    }

    function showResult(winnerData) {
      // Handle redirect type.
      if (winnerData.prize_type === 'redirect' && winnerData.redirect_url) {
        window.location.href = winnerData.redirect_url;
        return;
      }

      // Reset all result elements before showing new result.
      resetResultUI();

      // Switch to result state.
      if (formSection) {
        formSection.style.display = 'none';
      }

      if (resultSection) {
        resultSection.classList.add('dnxte-spin-wheel__result-section--active');
      }

      // Update result content.
      if (resultTitle) {
        var title = winnerData.prize_title || winnerData.winner_message || winnerData.label || 'Congratulations!';
        resultTitle.textContent = title;
      }

      if (resultDesc) {
        var desc = winnerData.prize_description || '';
        if (!desc) {
          if (winnerData.prize_type === 'no_prize') {
            desc = 'Better luck next time!';
          } else if (winnerData.prize_type === 'coupon_code' && winnerData.coupon_code) {
            desc = 'Use the coupon code below:';
        //   } else if (winnerData.prize_type === 'free_shipping') {
        //     desc = 'You won free shipping on your next order!';
        //   } else if (winnerData.prize_type === 'free_product') {
        //     desc = 'You won a free product!';
          } else {
            desc = winnerData.winner_message || 'You have won a special prize!';
          }
        }
        resultDesc.textContent = desc;
      }

      // Always show dismiss button after spin to allow re-spinning.
      if (dismissBtn) dismissBtn.style.display = 'block';

      if (winnerData.prize_type === 'no_prize') {
        // Show "Try Again" button for no_prize.
        if (tryAgainBtn) tryAgainBtn.style.display = 'block';
      } else {
        // Show coupon box only for coupon_code prize type with a valid code.
        if (winnerData.prize_type === 'coupon_code' && winnerData.coupon_code && couponBox && couponCodeEl) {
          couponCodeEl.textContent = winnerData.coupon_code;
          couponBox.style.display = 'flex';
          if (applyBtn) applyBtn.style.display = 'block';
        }

        // Trigger confetti for winning prizes.
        if (showConfetti && confettiEl) {
          document.body.appendChild(confettiEl);
          confettiEl.classList.add('dnxte-spin-wheel__confetti--active');
          setTimeout(function () {
            confettiEl.classList.remove('dnxte-spin-wheel__confetti--active');
          }, 4000);
        }
      }
    }

    /**
     * Reset the form to allow a re-spin (used by Try Again).
     */
    function resetForRespin() {
      // Hide result section.
      if (resultSection) {
        resultSection.classList.remove('dnxte-spin-wheel__result-section--active');
      }

      resetResultUI();

      // Show form section.
      if (formSection) {
        formSection.style.display = '';
      }

      // Re-enable submit button.
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = submitBtn.dataset.originalText || 'Spin Now';
      }
    }

    function handleSubmit() {
      if (isSpinning) return;
      clearError();

      var email = emailInput ? emailInput.value.trim() : '';

      // Validate email if required.
      if (requireEmail) {
        if (!email) {
          showError('Please enter your email address.');
          return;
        }
        if (!validateEmail(email)) {
          showError('Please enter a valid email address.');
          return;
        }
      }

      // Disable submit button.
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Spinning...';
      }

      // Always try server-side first — keeps probabilities and coupon codes secure.
      if (restUrl) {
        fetch(restUrl + 'submit', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': nonce,
          },
          body: JSON.stringify({
            email: email || 'anonymous@spin.local',
            module_id: moduleId,
            post_id: parseInt(postId, 10),
          }),
        })
          .then(function (response) { return response.json(); })
          .then(function (data) {
            if (data.success) {
              spinWheel(data.winner_index, data.segment);
            } else {
              showError(data.message || 'Something went wrong. Please try again.');
              if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = submitBtn.dataset.originalText || 'Spin Now';
              }
            }
          })
          .catch(function () {
            // Fallback to client-side on network error (equal probability, label only).
            var winnerIndex = pickWinnerClient();
            spinWheel(winnerIndex, { label: segments[winnerIndex].label || 'Prize' });
          });
      } else {
        // No REST URL available — client-side fallback only.
        var winnerIndex = pickWinnerClient();
        spinWheel(winnerIndex, { label: segments[winnerIndex].label || 'Prize' });
      }
    }

    // Event listeners.
    if (submitBtn) {
      submitBtn.dataset.originalText = submitBtn.textContent;
      submitBtn.addEventListener('click', handleSubmit);
    }

    if (tryAgainBtn) {
      tryAgainBtn.addEventListener('click', resetForRespin);
    }

    if (dismissBtn) {
      dismissBtn.addEventListener('click', resetForRespin);
    }

    function copyToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(showCopiedTooltip);
      } else {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showCopiedTooltip();
      }
    }

    function showCopiedTooltip() {
      if (couponTooltip) {
        couponTooltip.classList.add('dnxte-spin-wheel__coupon-tooltip--visible');
        setTimeout(function () {
          couponTooltip.classList.remove('dnxte-spin-wheel__coupon-tooltip--visible');
        }, 2000);
      }
    }

    if (couponBox && couponCodeEl) {
      couponBox.addEventListener('click', function () {
        var code = couponCodeEl.textContent;
        if (!code) return;
        copyToClipboard(code);
      });

      couponBox.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          var code = couponCodeEl.textContent;
          if (!code) return;
          copyToClipboard(code);
        }
      });
    }

    if (emailInput) {
      emailInput.addEventListener('input', function () {
        clearError();
      });

      emailInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleSubmit();
        }
      });
    }
  }

  function initAll() {
    var containers = document.querySelectorAll('.dnxte-spin-wheel__container[data-module-id]');
    containers.forEach(initSpinWheel);
  }

  // Init on DOM ready.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  // Re-init on Divi dynamic content load.
  document.addEventListener('divi-scripts-loaded', initAll);
})();
