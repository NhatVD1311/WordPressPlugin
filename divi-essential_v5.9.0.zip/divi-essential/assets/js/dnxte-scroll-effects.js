/**
 * Scroll Effects — frontend engine (unified).
 *
 * Reads `data-da-scroll-effect` (horizontal | cardStack | cardDeck | vertical),
 * `data-da-scroll-host` (section | row | column) and `data-da-scroll-data`
 * (JSON settings) off Section / Row / Column wrappers and runs the matching
 * GSAP + ScrollTrigger effect.
 *
 * Behaviour is a faithful re-implementation of DiviMotion's scroll effects:
 *   - Panels = the structural children of the host
 *       section → rows, row → columns, column → modules.
 *   - Horizontal: pin host, lay panels in a nowrap flex row, translateX the
 *     whole strip by its overflow distance.
 *   - Card Stack: 4 modes (stack / peel / horizontalStack / horizontalPeel)
 *     × 2 styles (flat / slideRotate).
 *   - Card Deck: sequential per-card pin + scale minScale → 1.
 *   - Vertical: our own — pin host, translateY tall columns (parallax).
 *
 * @package DiviAnimation
 */
(function () {
  'use strict';

  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (typeof window.gsap === 'undefined') return;
  var gsap = window.gsap;
  var ST = window.ScrollTrigger || null;
  if (ST && gsap.registerPlugin) { try { gsap.registerPlugin(ST); } catch (e) {} }

  function num(v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; }

  // Structural children that act as panels, per host type — mirrors
  // DiviMotion's `type === 'column' ? et_pb_module : 'row' ? et_pb_column : et_pb_row`.
  function getPanels(host) {
    var type = host.getAttribute('data-da-scroll-host') || 'section';
    var sel;
    if (type === 'column' || type === 'column-inner') sel = '.et_pb_module';
    else if (type === 'row' || type === 'row-inner') sel = '.et_pb_column, .et_pb_column_inner';
    else sel = '.et_pb_row, .et_pb_row_inner';
    var out = [];
    for (var i = 0; i < host.children.length; i++) {
      var c = host.children[i];
      if (c.nodeType === 1) {
        try { if (c.matches(sel)) out.push(c); } catch (e) {}
      }
    }
    return out;
  }

  // Save/restore a set of inline style props so destroy() can clean up.
  function saveStyles(el, props) {
    var s = {};
    props.forEach(function (p) { s[p] = el.style.getPropertyValue(p); });
    return s;
  }
  function restoreStyles(el, saved) {
    Object.keys(saved).forEach(function (p) {
      if (saved[p]) el.style.setProperty(p, saved[p]);
      else el.style.removeProperty(p);
    });
  }

  function makeDestroy(host, panels, savedHost, sts, tws, extra) {
    return function destroy() {
      try {
        (sts || []).forEach(function (s) { try { s.kill(); } catch (e) {} });
        (tws || []).forEach(function (t) { try { t.kill(); } catch (e) {} });
        if (savedHost) restoreStyles(host, savedHost);
        if (panels) panels.forEach(function (p) { gsap.set(p, { clearProps: 'all' }); });
        if (typeof extra === 'function') extra();
      } catch (e) {}
    };
  }

  // ── Extra reveal motion (carried over from the old separate extensions):
  // each panel can fade in, un-blur and un-tilt as it scrolls into view. Runs
  // as an independent scrubbed ScrollTrigger per panel, layered on top of the
  // chosen effect. opacity/filter never clash with the effect's transforms;
  // rotation simply adds to whatever the effect already does.
  function getExtras(s) {
    var e = (s && s.extras) || {};
    return {
      fade: e.fade === 'on' || e.fade === true,
      blur: num(e.blur, 0) || 0,
      rotate: num(e.rotate, 0) || 0
    };
  }
  function applyReveal(panels, ex, sts, tws) {
    if (!ex || (!ex.fade && !(ex.blur > 0) && ex.rotate === 0)) return;
    panels.forEach(function (panel) {
      var from = {}, to = { ease: 'none' };
      if (ex.fade) { from.opacity = 0; to.opacity = 1; }
      if (ex.blur > 0) { from.filter = 'blur(' + ex.blur + 'px)'; to.filter = 'blur(0px)'; }
      if (ex.rotate !== 0) { from.rotation = ex.rotate; to.rotation = 0; }
      to.scrollTrigger = { trigger: panel, start: 'top 92%', end: 'top 50%', scrub: true };
      var tw = gsap.fromTo(panel, from, to);
      tws.push(tw);
      if (tw.scrollTrigger) sts.push(tw.scrollTrigger);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // HORIZONTAL SCROLL
  // ══════════════════════════════════════════════════════════════
  function runHorizontal(host, s) {
    if (!ST) return null;
    var panels = getPanels(host);
    if (panels.length < 2) return null;

    var rtl = s.direction === 'rtl';
    var offsetLeft = s.offsetLeft || '0px';
    var offsetRight = s.offsetRight || '0px';
    var itemNumber = parseInt(s.itemNumber, 10) || 0;
    var scrub = num(s.scrubSpeed, 1);
    var startOffset = s.startOffset || 'top top';
    var scrollLength = s.scrollLength || '';
    var progress = s.progressBarEnabled === 'on' || s.progressBarEnabled === true;

    var savedHost = saveStyles(host, ['display', 'overflow', 'flex-wrap', 'position', 'flex-direction', 'justify-content', 'padding-left', 'padding-right']);
    var pos = getComputedStyle(host).position;
    host.style.setProperty('display', 'flex', 'important');
    host.style.setProperty('overflow', 'hidden', 'important');
    host.style.setProperty('flex-wrap', 'nowrap', 'important');
    host.style.setProperty('position', pos === 'static' ? 'relative' : pos, 'important');
    host.style.setProperty('flex-direction', rtl ? 'row-reverse' : 'row', 'important');
    host.style.setProperty('justify-content', 'flex-start', 'important');
    host.style.setProperty('padding-left', offsetLeft, 'important');
    host.style.setProperty('padding-right', offsetRight, 'important');

    panels.forEach(function (p) { p.style.setProperty('flex-shrink', '0', 'important'); });

    // itemNumber → lock each panel to an equal share of the host width.
    if (itemNumber > 0) {
      var cs = getComputedStyle(host);
      var padL = parseFloat(cs.paddingLeft) || 0, padR = parseFloat(cs.paddingRight) || 0;
      var gaps = (parseFloat(cs.columnGap) || parseFloat(cs.gap) || 0) * Math.max(0, itemNumber - 1);
      var avail = host.clientWidth - padL - padR - gaps;
      if (avail > 0) {
        var w = (avail / itemNumber) + 'px';
        panels.forEach(function (p) {
          p.style.setProperty('width', w, 'important');
          p.style.setProperty('max-width', w, 'important');
          p.style.setProperty('min-width', w, 'important');
        });
      }
    }

    // Overflow distance: how far the panel strip must travel so its far edge
    // meets the host's content edge. Negative = move left (ltr), positive = right (rtl).
    function distance() {
      var t = host.getBoundingClientRect(), cs2 = getComputedStyle(host);
      var pl = parseFloat(cs2.paddingLeft) || 0, pr = parseFloat(cs2.paddingRight) || 0;
      var cLeft = t.left + pl, cRight = t.right - pr;
      var minL = Infinity, maxR = -Infinity;
      panels.forEach(function (p) {
        var r = p.getBoundingClientRect();
        if (r.left < minL) minL = r.left;
        if (r.right > maxR) maxR = r.right;
      });
      var leftOver = cLeft - minL, rightOver = maxR - cRight;
      if (rightOver <= 0 && leftOver <= 0) return 0;
      return rightOver >= leftOver ? -rightOver : leftOver;
    }

    var tl = gsap.timeline({
      scrollTrigger: {
        trigger: host, pin: true, anticipatePin: 1, scrub: scrub, pinSpacing: true,
        start: startOffset,
        end: function () { return scrollLength ? '+=' + scrollLength : '+=' + Math.abs(distance()); },
        invalidateOnRefresh: true
      }
    });
    tl.to(panels, { x: distance, ease: 'none' }, 0);

    // Optional progress bar (bottom-center).
    var bar = null;
    if (progress) {
      bar = document.createElement('div');
      bar.className = 'da-se-progress';
      bar.style.cssText = 'position:absolute;left:50%;bottom:24px;transform:translateX(-50%);width:120px;height:4px;border-radius:2px;background:#e5e5e5;overflow:hidden;pointer-events:none;z-index:5;';
      var fill = document.createElement('div');
      fill.style.cssText = 'height:100%;width:100%;background:#000;transform:scaleX(0);transform-origin:' + (rtl ? 'right' : 'left') + ' center;';
      bar.appendChild(fill);
      host.appendChild(bar);
      tl.to(fill, { scaleX: 1, ease: 'none' }, 0);
    }

    if (tl.scrollTrigger) tl.scrollTrigger.refresh();
    if (Math.abs(distance()) <= 0) {
      try { if (tl.scrollTrigger) tl.scrollTrigger.kill(); tl.kill(); } catch (e) {}
      restoreStyles(host, savedHost);
      panels.forEach(function (p) { p.style.removeProperty('flex-shrink'); p.style.removeProperty('width'); p.style.removeProperty('max-width'); p.style.removeProperty('min-width'); });
      if (bar && bar.parentNode) bar.parentNode.removeChild(bar);
      return null;
    }

    var sts = [tl.scrollTrigger], tws = [tl];
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws, function () {
      panels.forEach(function (p) { p.style.removeProperty('flex-shrink'); p.style.removeProperty('width'); p.style.removeProperty('max-width'); p.style.removeProperty('min-width'); });
      if (bar && bar.parentNode) bar.parentNode.removeChild(bar);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // CARD STACK — 4 modes × 2 styles (DiviMotion-faithful).
  // ══════════════════════════════════════════════════════════════
  var STACK_STYLES = {
    flat: { behind: function () { return {}; }, peel: {} },
    slideRotate: {
      behind: function (i, t) { return { scale: 1 - 0.025 * t, rotation: -2 * t }; },
      peel: { rotation: -4, scale: 0.9 }
    }
  };

  // For "stack" mode: each card pins a touch lower than the previous, giving
  // the peek. Returns a fn(index) → ScrollTrigger start string.
  function parseStackStart(startOffset, stackOffset) {
    var parts = String(startOffset || 'top top').split(' ');
    var n = parts[0] || 'top';
    var i = parts[1] || 'top';
    var o = null;
    if (i === 'top') o = 0;
    else if (/^\d+$/.test(i) || /^\d+px$/.test(i)) o = parseInt(i, 10);
    return function (e) {
      var r = stackOffset * e;
      if (o !== null) return n + ' ' + (o + r);
      return r ? (n + ' ' + i + '+=' + r) : (n + ' ' + i);
    };
  }

  function runCardStack(host, s) {
    if (!ST) return null;
    var panels = getPanels(host);
    if (panels.length < 2) return null;
    var mode = s.mode || 'stack';
    if (mode === 'peel') return stackPeel(host, panels, s);
    if (mode === 'horizontalStack') return stackHorizontal(host, panels, s);
    if (mode === 'horizontalPeel') return stackHorizontalPeel(host, panels, s);
    return stackDefault(host, panels, s);
  }

  function stackDefault(host, panels, s) {
    var scrub = num(s.scrubSpeed, 1);
    var startOffset = s.startOffset || 'top top';
    var styleDef = STACK_STYLES[s.style] || STACK_STYLES.flat;
    var so = parseFloat(s.stackOffset); if (!(isFinite(so) && so >= 0)) so = 10;
    var c = panels.length;
    var startFn = parseStackStart(startOffset, so);

    var savedHost = saveStyles(host, ['display', 'flex-direction']);
    host.style.setProperty('display', 'flex', 'important');
    host.style.setProperty('flex-direction', 'column', 'important');

    var sts = [], tws = [];
    panels.forEach(function (panel, r) {
      var isLast = r === c - 1;
      var u = startFn(r);
      var pinST = ST.create({ trigger: panel, start: u, endTrigger: panels[c - 1], end: 'top top', pin: panel, pinSpacing: isLast });
      sts.push(pinST);
      if (!isLast) {
        var behind = styleDef.behind(r, c - r);
        if (Object.keys(behind).length) {
          var v = startFn(r + 1);
          var tw = gsap.to(panel, Object.assign({}, behind, {
            transformOrigin: 'top center', ease: 'none',
            scrollTrigger: { trigger: panel, start: u, endTrigger: panels[r + 1], end: v, scrub: scrub }
          }));
          tws.push(tw);
          if (tw.scrollTrigger) sts.push(tw.scrollTrigger);
        }
      }
    });
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws);
  }

  function stackPeel(host, panels, s) {
    var scrub = num(s.scrubSpeed, 1);
    var startOffset = s.startOffset || 'top top';
    var styleDef = STACK_STYLES[s.style] || STACK_STYLES.flat;
    var so = parseFloat(s.stackOffset); if (!isFinite(so)) so = 0;
    var u = panels.length;
    var peel = styleDef.peel;
    var d = so * (u - 1);
    var maxH = Math.max.apply(Math, panels.map(function (e) { return e.offsetHeight; }));
    var widths = panels.map(function (e) { return e.offsetWidth; });

    var savedHost = saveStyles(host, ['display', 'grid-template-columns', 'justify-items', 'padding-bottom']);
    host.style.setProperty('display', 'grid', 'important');
    gsap.set(host, Object.assign({ gridTemplateColumns: '1fr', justifyItems: 'center' }, d ? { paddingBottom: '+=' + d } : {}));
    panels.forEach(function (e, t) { gsap.set(e, { gridRow: 1, gridColumn: 1, width: widths[t], y: so ? (so * t + 'px') : 0, zIndex: u - t }); });

    var tl = gsap.timeline();
    panels.forEach(function (panel, r) {
      if (r !== u - 1) tl.to(panel, Object.assign({ y: '-100vh', ease: 'none' }, peel));
    });
    var st = ST.create({ trigger: host, animation: tl, pin: host, pinSpacing: true, scrub: scrub, start: startOffset, end: '+=' + (maxH * (u - 1)), invalidateOnRefresh: true });
    var sts = [st], tws = [tl];
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws);
  }

  function stackHorizontal(host, panels, s) {
    var scrub = num(s.scrubSpeed, 1);
    var startOffset = s.startOffset || 'top top';
    var styleDef = STACK_STYLES[s.style] || STACK_STYLES.flat;
    var so = parseFloat(s.stackOffset); if (!(isFinite(so) && so >= 0)) so = 10;
    var u = panels.length;
    var maxH = Math.max.apply(Math, panels.map(function (e) { return e.offsetHeight; }));
    var widths = panels.map(function (e) { return e.offsetWidth; });

    var savedHost = saveStyles(host, ['display', 'grid-template-columns', 'justify-items']);
    host.style.setProperty('display', 'grid', 'important');
    gsap.set(host, { gridTemplateColumns: '1fr', justifyItems: 'center' });
    panels.forEach(function (e, t) { gsap.set(e, { gridRow: 1, gridColumn: 1, width: widths[t], x: t === 0 ? 0 : '100vw', zIndex: t + 1 }); });

    var tl = gsap.timeline();
    panels.forEach(function (panel, r) {
      if (r !== 0) {
        var behind = styleDef.behind(r, u - r);
        tl.fromTo(panel, Object.assign({ x: '100vw' }, behind), { x: so * r, rotation: 0, scale: 1, transformOrigin: 'top center', ease: 'none' });
      }
    });
    var st = ST.create({ trigger: host, animation: tl, pin: host, pinSpacing: true, scrub: scrub, start: startOffset, end: '+=' + (maxH * (u - 1)), invalidateOnRefresh: true });
    var sts = [st], tws = [tl];
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws);
  }

  function stackHorizontalPeel(host, panels, s) {
    var scrub = num(s.scrubSpeed, 1);
    var startOffset = s.startOffset || 'top top';
    var styleDef = STACK_STYLES[s.style] || STACK_STYLES.flat;
    var so = parseFloat(s.stackOffset); if (!isFinite(so)) so = 0;
    var u = panels.length;
    var peel = styleDef.peel;
    var d = so * (u - 1);
    var maxH = Math.max.apply(Math, panels.map(function (e) { return e.offsetHeight; }));
    var widths = panels.map(function (e) { return e.offsetWidth; });

    var savedHost = saveStyles(host, ['display', 'grid-template-columns', 'justify-items', 'padding-right']);
    host.style.setProperty('display', 'grid', 'important');
    gsap.set(host, Object.assign({ gridTemplateColumns: '1fr', justifyItems: 'center' }, d ? { paddingRight: '+=' + d } : {}));
    panels.forEach(function (e, t) { gsap.set(e, { gridRow: 1, gridColumn: 1, width: widths[t], x: so ? (so * t + 'px') : 0, zIndex: u - t }); });

    var tl = gsap.timeline();
    panels.forEach(function (panel, r) {
      if (r !== u - 1) tl.to(panel, Object.assign({ x: '-100vw', ease: 'none' }, peel));
    });
    var st = ST.create({ trigger: host, animation: tl, pin: host, pinSpacing: true, scrub: scrub, start: startOffset, end: '+=' + (maxH * (u - 1)), invalidateOnRefresh: true });
    var sts = [st], tws = [tl];
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws);
  }

  // ══════════════════════════════════════════════════════════════
  // CARD DECK — sequential per-card pin; each scales minScale → 1.
  // ══════════════════════════════════════════════════════════════
  function runCardDeck(host, s) {
    if (!ST) return null;
    var panels = getPanels(host);
    if (panels.length < 2) return null;

    var cardOffset = parseFloat(s.cardOffset); cardOffset = isFinite(cardOffset) ? Math.max(0, cardOffset) : 40;
    var scrub = parseFloat(s.scrubSpeed); scrub = (isFinite(scrub) && scrub > 0) ? scrub : 1;
    var startOffset = s.startOffset || 'top 10%';
    var cardGap = parseFloat(s.cardGap); cardGap = isFinite(cardGap) ? Math.max(0, cardGap) : 0;
    var minScale = parseFloat(s.minScale); minScale = isFinite(minScale) ? Math.min(1, Math.max(0, minScale)) : 0.8;

    var parts = startOffset.trim().split(/\s+/);
    var side = parts[0] || 'top';
    var posStr = parts.slice(1).join(' ') || '10%';
    var v = panels.length;

    var savedHost = saveStyles(host, ['display', 'flex-direction', 'padding-bottom']);
    host.style.setProperty('display', 'flex', 'important');
    host.style.setProperty('flex-direction', 'column', 'important');

    gsap.set(panels, { transformOrigin: 'top center' });
    if (cardGap > 0) {
      panels.forEach(function (e, t) { gsap.set(e, { y: cardGap * t }); });
      var yp = parseFloat(getComputedStyle(host).paddingBottom) || 0;
      host.style.setProperty('padding-bottom', (yp + cardGap * (v - 1)) + 'px', 'important');
    }

    var scales = panels.map(function (e, t) { return minScale + t / (v - 1) * (1 - minScale); });

    var sts = [], tws = [];
    panels.forEach(function (panel, r) {
      var isLast = r === v - 1;
      var start = side + '-=' + (cardOffset * r) + ' ' + posStr;
      if (!isLast) {
        var end = side + '-=' + (cardOffset * (r + 1)) + ' ' + posStr;
        var tw = gsap.to(panel, { scale: scales[r], ease: 'none', scrollTrigger: { trigger: panel, start: start, endTrigger: panels[r + 1], end: end, scrub: scrub } });
        tws.push(tw);
        if (tw.scrollTrigger) sts.push(tw.scrollTrigger);
      }
      var pinST = ST.create({ trigger: panel, start: start, endTrigger: panels[v - 1], end: 'top top', pin: panel, pinSpacing: isLast, scrub: scrub, anticipatePin: 1 });
      sts.push(pinST);
    });
    applyReveal(panels, getExtras(s), sts, tws);
    return makeDestroy(host, panels, savedHost, sts, tws);
  }

  // ══════════════════════════════════════════════════════════════
  // VERTICAL SCROLL — ours: pin host, translateY its tall columns.
  // ══════════════════════════════════════════════════════════════
  function runVertical(host, s) {
    if (!ST) return null;
    var vh = window.innerHeight;
    var cols = Array.prototype.slice.call(host.querySelectorAll('.et_pb_column, .et_pb_column_inner'));
    var tracks = [];
    cols.forEach(function (col) {
      var kids = Array.prototype.filter.call(col.children, function (c) {
        return c.nodeType === 1 && c.tagName !== 'STYLE' && c.tagName !== 'SCRIPT' && !/et_pb_background/.test(c.className || '');
      });
      var h = 0; kids.forEach(function (k) { h += k.getBoundingClientRect().height; });
      if (h > vh + 50) tracks.push({ kids: kids, overflow: h - vh });
    });
    if (!tracks.length) return null;

    var speed = num(s.scroll_speed, 1);
    var scrub = s.scrub === 'true' ? true : num(s.scrub, 1);
    var pin = s.pin_enabled !== 'off';
    var markers = s.markers === 'on';

    var savedHost = saveStyles(host, ['height', 'max-height', 'overflow', 'position']);
    host.style.setProperty('height', vh + 'px', 'important');
    host.style.setProperty('max-height', vh + 'px', 'important');
    host.style.setProperty('overflow', 'hidden', 'important');
    if (getComputedStyle(host).position === 'static') host.style.setProperty('position', 'relative');

    var maxOverflow = 0;
    tracks.forEach(function (t) { if (t.overflow > maxOverflow) maxOverflow = t.overflow; });

    var tl = gsap.timeline({
      scrollTrigger: { trigger: host, start: 'top top', end: '+=' + (maxOverflow * speed), pin: pin, anticipatePin: 1, scrub: scrub, markers: markers, invalidateOnRefresh: true }
    });
    tracks.forEach(function (t) { tl.fromTo(t.kids, { y: 0 }, { y: -t.overflow, ease: 'none' }, 0); });

    var sts = [tl.scrollTrigger], tws = [tl];
    var revealPanels = getPanels(host);
    applyReveal(revealPanels, getExtras(s), sts, tws);

    return function () {
      try { sts.forEach(function (st) { try { st.kill(); } catch (e) {} }); tws.forEach(function (t) { try { t.kill(); } catch (e) {} }); } catch (e) {}
      restoreStyles(host, savedHost);
      tracks.forEach(function (t) { gsap.set(t.kids, { clearProps: 'y' }); });
      revealPanels.forEach(function (p) { gsap.set(p, { clearProps: 'opacity,filter,rotation' }); });
    };
  }

  var RUNNERS = {
    horizontal: runHorizontal,
    cardStack: runCardStack,
    cardDeck: runCardDeck,
    vertical: runVertical
  };

  // ══════════════════════════════════════════════════════════════
  // BOOT
  // ══════════════════════════════════════════════════════════════
  function initOne(host) {
    if (!host || host._daScrollInit) return;
    var type = host.getAttribute('data-da-scroll-effect');
    if (!type || !RUNNERS[type]) return;
    var s = {};
    try { s = JSON.parse(host.getAttribute('data-da-scroll-data') || '{}'); } catch (e) { s = {}; }
    host._daScrollInit = true;
    try { host._daScrollDestroy = RUNNERS[type](host, s) || null; } catch (e) {
      if (window.console) console.warn('[DA Scroll Effects] init failed', type, e);
    }
  }

  function initAll() {
    var nodes = document.querySelectorAll('[data-da-scroll-effect]');
    for (var i = 0; i < nodes.length; i++) initOne(nodes[i]);
  }

  function boot() {
    initAll();
    if (ST && ST.refresh) ST.refresh();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  window.addEventListener('load', function () { if (ST && ST.refresh) ST.refresh(); });
})();
