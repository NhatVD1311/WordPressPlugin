<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => '534a1f3184d0ebaeefd5');
