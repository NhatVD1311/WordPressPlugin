<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-element'), 'version' => 'caf4572afb641703821f');
