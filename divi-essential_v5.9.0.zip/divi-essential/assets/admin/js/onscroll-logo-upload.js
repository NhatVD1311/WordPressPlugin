jQuery(document).ready(function ($) {
    let frame;

    $('#on_scroll_logo_upload_button').on('click', function (e) {
        e.preventDefault();

        // If the media frame already exists, reopen it.
        if (frame) {
            frame.open();
            return;
        }

        // Create a new media frame
        frame = wp.media({
            title: 'Select or Upload an Image',
            button: {
                text: 'Use this image'
            },
            library: {
                type: 'image' // Only allow images
            },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();

            $('#on_scroll_logo').val(attachment.url);
            $('#on_scroll_logo_preview').attr('src', attachment.url).show();
        });

        frame.open();
    });

        $('#on_scroll_logo_remove_button').on('click', function (e) {
            e.preventDefault();
            $('#on_scroll_logo').val('');
            $('#on_scroll_logo_preview').hide();
        });
});
