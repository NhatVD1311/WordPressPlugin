(function(window, document) {
    'use strict';

	// if body has .et-fb than return the below code execution
	// for divi builder wireframe mode interrupt the code execution
	if (document.body.classList.contains('et-fb')) {
		return;
	}
    
    let dnxteSimpleBarInstance;
    
    // Main function to wrap body content and initialize SimpleBar
    function initializeCustomScrollbar() {
        try {
            // Check if config exists
            if (typeof window.dnxte_scroll_config === 'undefined') {
                return false;
            }

            // Touch-primary devices (phones/tablets) keep native scrolling unless
            // explicitly enabled: overlay scrollbars make the custom bar near
            // invisible there, and the full-body rewrap + JS-driven scrolling is
            // a measurable mobile performance cost.
            if (window.dnxte_scroll_config.touchEnable !== 'true' &&
                window.matchMedia && window.matchMedia('(hover: none) and (pointer: coarse)').matches) {
                return false;
            }
            
            // Check if already initialized
            if (document.querySelector('#dnxte_simplebar')) {
                return true;
            }
            
            // Check if SimpleBar library is loaded
            if (typeof window.SimpleBar === 'undefined') {
                return false;
            }
            
            const config = window.dnxte_scroll_config;
            
            // Wrap body content
            wrapBodyContent(config);
            
            // Initialize SimpleBar after DOM is ready
            requestAnimationFrame(() => {
                initializeSimpleBar(config);
                applyCustomStyling(config);
            });
            
            return true;
        } catch (error) {
            return false;
        }
    }
    
    // Wrap body content with SimpleBar structure
    function wrapBodyContent(config) {
        const direction = config.alignment || 'ltr';
        const autoHide = config.autohide || 'true';
        
        // Create wrapper element
        const wrapper = document.createElement('div');
        wrapper.id = 'dnxte_simplebar';
        wrapper.className = 'dnxte_scrollbar_element';
        wrapper.setAttribute('data-simplebar-auto-hide', autoHide);
        wrapper.setAttribute('data-simplebar-direction', direction);
        wrapper.style.height = '100vh';
        
        // Move all body children to wrapper
        while (document.body.firstChild) {
            wrapper.appendChild(document.body.firstChild);
        }
        
        // Append wrapper to body
        document.body.appendChild(wrapper);
    }
    
    // Initialize SimpleBar
    function initializeSimpleBar(config) {
        try {
            const container = document.querySelector('#dnxte_simplebar');
            if (!container || typeof window.SimpleBar === 'undefined') {
                return;
            }
            
            // Clean up existing instance
            if (dnxteSimpleBarInstance && typeof dnxteSimpleBarInstance.unMount === 'function') {
                dnxteSimpleBarInstance.unMount();
            }
            
            // Convert autohide value to proper format
            let autoHideValue = true;
            switch(config.autohide) {
                case 'true':
                    autoHideValue = true;
                    break;
                case 'false':
                    autoHideValue = false;
                    break;
                case 'auto':
                    autoHideValue = 'auto';
                    break;
                default:
                    autoHideValue = true;
            }
            
            // Initialize SimpleBar with proper configuration
            dnxteSimpleBarInstance = new SimpleBar(container, {
                autoHide: autoHideValue,
                scrollbarMinSize: 25,
                scrollbarMaxSize: 100,
                forceVisible: config.autohide === 'false'
            });

            // Add body class to indicate SimpleBar is active (for CSS/JS detection)
            document.body.classList.add('dnxte-simplebar-active');

            // Remove aria-label attribute from content wrapper to prevent conflicts
            const contentWrapper = container.querySelector('.simplebar-content-wrapper');
            if (contentWrapper) {
                contentWrapper.removeAttribute('aria-label');
            }

            // Set up scroll event propagation for Divi fixed header
            setupDiviCompatibility();
            
            // Dispatch ready event
            document.dispatchEvent(new CustomEvent('dnxteSimpleBarReady', {
                detail: { instance: dnxteSimpleBarInstance }
            }));

            // Handle Divi animations with SimpleBar
            setupDiviAnimations();

            // Handle Divi 5 Number Counter with SimpleBar (triggers resize for native counter)
            setupDiviNumberCounters();

            // Handle anchor link (#hash) navigation with SimpleBar
            setupAnchorLinkHandling();

            // Recalculate after window fully loads (images, fonts, etc.)
            window.addEventListener('load', function() {
                if (dnxteSimpleBarInstance && typeof dnxteSimpleBarInstance.recalculate === 'function') {
                    dnxteSimpleBarInstance.recalculate();
                }
                // Trigger animations check after page fully loads
                setTimeout(triggerVisibleAnimations, 100);
            });

            // Recalculate after a short delay to catch any late-loading content
            setTimeout(function() {
                if (dnxteSimpleBarInstance && typeof dnxteSimpleBarInstance.recalculate === 'function') {
                    dnxteSimpleBarInstance.recalculate();
                }
            }, 500);

        } catch (error) {
            console.error('DNXTE: SimpleBar initialization failed:', error);
        }
    }

    // Check if element is visible in the SimpleBar viewport
    function isElementInSimpleBarViewport(el) {
        if (!dnxteSimpleBarInstance) return false;

        const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
        if (!scrollableElement) return false;

        const rect = el.getBoundingClientRect();
        const containerRect = scrollableElement.getBoundingClientRect();

        return (
            rect.top < containerRect.bottom &&
            rect.bottom > containerRect.top &&
            rect.left < containerRect.right &&
            rect.right > containerRect.left
        );
    }

    // Trigger animation on a single element
    function triggerElementAnimation(el) {
        if (el.classList.contains('et_had_animation')) return;

        // Get animation settings from data attributes
        const animationStyle = el.getAttribute('data-animation-style');
        const animationDuration = el.getAttribute('data-animation-duration') || '1000ms';
        const animationDelay = el.getAttribute('data-animation-delay') || '0ms';
        const animationCurve = el.getAttribute('data-animation-speed-curve') || 'ease-in-out';
        const animationIntensity = el.getAttribute('data-animation-intensity') || '50%';
        const startingOpacity = el.getAttribute('data-animation-starting-opacity') || '0%';

        if (!animationStyle) return;

        // Parse intensity value
        const intensity = parseFloat(animationIntensity) || 50;
        const opacityValue = parseFloat(startingOpacity) / 100 || 0;

        // Set initial transform based on animation style and intensity
        const transformMap = {
            'slideLeft': `translateX(-${intensity}%)`,
            'slideRight': `translateX(${intensity}%)`,
            'slideTop': `translateY(-${intensity}%)`,
            'slideBottom': `translateY(${intensity}%)`,
            'fadeLeft': `translateX(-${intensity}%)`,
            'fadeRight': `translateX(${intensity}%)`,
            'fadeTop': `translateY(-${intensity}%)`,
            'fadeBottom': `translateY(${intensity}%)`,
            'bounceLeft': `translateX(-${intensity * 2}px)`,
            'bounceRight': `translateX(${intensity * 2}px)`,
            'bounceTop': `translateY(-${intensity * 2}px)`,
            'bounceBottom': `translateY(${intensity * 2}px)`,
            'zoom': `scale(${1 - intensity / 100})`,
            'zoomTop': `scale(${1 - intensity / 100})`,
            'zoomRight': `scale(${1 - intensity / 100})`,
            'zoomBottom': `scale(${1 - intensity / 100})`,
            'zoomLeft': `scale(${1 - intensity / 100})`,
            'flip': `rotateX(${intensity * 1.8}deg)`,
            'flipTop': `rotateX(-${intensity * 1.8}deg)`,
            'flipBottom': `rotateX(${intensity * 1.8}deg)`,
            'flipLeft': `rotateY(${intensity * 1.8}deg)`,
            'flipRight': `rotateY(-${intensity * 1.8}deg)`,
            'fold': `rotateY(${intensity * 1.8}deg)`,
            'foldTop': `rotateX(-${intensity * 1.8}deg)`,
            'foldBottom': `rotateX(${intensity * 1.8}deg)`,
            'foldLeft': `rotateY(${intensity * 1.8}deg)`,
            'foldRight': `rotateY(-${intensity * 1.8}deg)`,
            'roll': `translateX(-${intensity}%) rotate(-${intensity * 3.6}deg)`,
            'rollTop': `translateY(-${intensity}%) rotate(-${intensity * 3.6}deg)`,
            'rollRight': `translateX(${intensity}%) rotate(${intensity * 3.6}deg)`,
            'rollBottom': `translateY(${intensity}%) rotate(${intensity * 3.6}deg)`,
            'rollLeft': `translateX(-${intensity}%) rotate(-${intensity * 3.6}deg)`
        };

        // Set initial state
        const initialTransform = transformMap[animationStyle] || '';
        if (initialTransform) {
            el.style.transform = initialTransform;
        }
        el.style.opacity = opacityValue;

        // Force reflow to ensure initial state is applied
        el.offsetHeight;

        // Apply animation settings with webkit prefixes
        el.style.animationDuration = animationDuration;
        el.style.webkitAnimationDuration = animationDuration;
        el.style.animationDelay = animationDelay;
        el.style.webkitAnimationDelay = animationDelay;
        el.style.animationTimingFunction = animationCurve;
        el.style.webkitAnimationTimingFunction = animationCurve;
        el.style.animationFillMode = 'both';
        el.style.webkitAnimationFillMode = 'both';

        // Add the animation class to trigger the CSS animation
        el.classList.add(animationStyle);
        el.classList.add('et_had_animation');
    }

    // Check and trigger animations for all visible elements
    function triggerVisibleAnimations() {
        const animatedElements = document.querySelectorAll('.et_animated:not(.et_had_animation)');
        animatedElements.forEach(function(el) {
            if (isElementInSimpleBarViewport(el)) {
                triggerElementAnimation(el);
            }
        });
    }

    // Setup Divi animations to work with SimpleBar scroll
    function setupDiviAnimations() {
        if (!dnxteSimpleBarInstance) return;

        const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
        if (!scrollableElement) return;

        let animationFrame = null;

        // Check animations on scroll
        scrollableElement.addEventListener('scroll', function() {
            if (animationFrame) {
                cancelAnimationFrame(animationFrame);
            }
            animationFrame = requestAnimationFrame(triggerVisibleAnimations);
        }, { passive: true });

        // Initial check for elements already in viewport
        setTimeout(triggerVisibleAnimations, 200);
        setTimeout(triggerVisibleAnimations, 500);
        setTimeout(triggerVisibleAnimations, 1000);
    }

    /**
     * Setup Divi 5 Number Counter compatibility with SimpleBar
     *
     * Problem: Divi 5's Number Counter uses IntersectionObserver which watches
     * the document viewport. But SimpleBar scrolls inside .simplebar-content-wrapper,
     * so elements never "enter" the document viewport from IntersectionObserver's perspective.
     *
     * Solution: Since resize triggers Divi's counter (user confirmed this), we dispatch
     * a resize event when counters become visible in SimpleBar's scroll viewport.
     */
    function setupDiviNumberCounters() {
        if (!dnxteSimpleBarInstance) return;

        const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
        if (!scrollableElement) return;

        // Track counters that we've already triggered resize for
        const triggeredCounters = new WeakSet();
        let resizeDebounceTimer = null;

        /**
         * Check if a number counter is visible in SimpleBar viewport
         */
        function isCounterVisible(counter) {
            const rect = counter.getBoundingClientRect();
            const containerRect = scrollableElement.getBoundingClientRect();

            // Check if at least 20% of the element is visible
            const visibleHeight = Math.min(rect.bottom, containerRect.bottom) - Math.max(rect.top, containerRect.top);
            const threshold = Math.min(rect.height * 0.2, 50); // 20% or 50px, whichever is smaller

            return visibleHeight >= threshold && rect.top < containerRect.bottom && rect.bottom > containerRect.top;
        }

        /**
         * Check if a counter needs triggering (hasn't animated yet)
         */
        function counterNeedsTrigger(counter) {
            const percentValue = counter.querySelector('.percent-value');
            // Counter needs trigger if percent-value is empty
            return percentValue && percentValue.textContent.trim() === '';
        }

        /**
         * Check all counters and trigger resize if any visible ones need it
         */
        function checkNumberCounters() {
            const counters = document.querySelectorAll('.et_pb_number_counter');
            let needsResize = false;

            counters.forEach(function(counter) {
                if (triggeredCounters.has(counter)) return;

                if (isCounterVisible(counter) && counterNeedsTrigger(counter)) {
                    triggeredCounters.add(counter);
                    needsResize = true;
                }
            });

            // Dispatch a single resize event for all visible counters (batched)
            if (needsResize) {
                clearTimeout(resizeDebounceTimer);
                resizeDebounceTimer = setTimeout(function() {

                    // Dispatch native resize event
                    window.dispatchEvent(new Event('resize'));

                    // Also trigger jQuery resize (Divi might use jQuery events)
                    if (typeof jQuery !== 'undefined') {
                        jQuery(window).trigger('resize');
                    }

                    // Try Divi's specific reinit function if it exists
                    if (typeof window.et_pb_reinit_number_counter === 'function') {
                        window.et_pb_reinit_number_counter();
                    }
                }, 50);
            }
        }

        // Throttled scroll handler
        let scrollFrame = null;
        let lastScrollTop = 0;

        scrollableElement.addEventListener('scroll', function() {
            const currentScrollTop = scrollableElement.scrollTop;

            // Only check if scrolled at least 20px (debounce)
            if (Math.abs(currentScrollTop - lastScrollTop) < 20) return;
            lastScrollTop = currentScrollTop;

            if (scrollFrame) {
                cancelAnimationFrame(scrollFrame);
            }
            scrollFrame = requestAnimationFrame(checkNumberCounters);
        }, { passive: true });

        /**
         * Force trigger resize for all visible counters (used on initial load)
         */
        function forceResizeForVisibleCounters() {
            const counters = document.querySelectorAll('.et_pb_number_counter');
            let hasVisibleEmpty = false;

            counters.forEach(function(counter) {
                const percentValue = counter.querySelector('.percent-value');
                const isEmpty = percentValue && percentValue.textContent.trim() === '';

                if (isEmpty && isCounterVisible(counter)) {
                    hasVisibleEmpty = true;
                    triggeredCounters.add(counter);
                }
            });

            if (hasVisibleEmpty) {
                window.dispatchEvent(new Event('resize'));
                if (typeof jQuery !== 'undefined') {
                    jQuery(window).trigger('resize');
                }
            }
        }

        // AGGRESSIVE initial checks - the counters might be visible immediately
        // Run immediately
        checkNumberCounters();

        // Run with progressive delays
        setTimeout(checkNumberCounters, 50);
        setTimeout(checkNumberCounters, 100);
        setTimeout(checkNumberCounters, 200);
        setTimeout(checkNumberCounters, 300);
        setTimeout(checkNumberCounters, 500);
        setTimeout(forceResizeForVisibleCounters, 600); // Force resize if still empty
        setTimeout(checkNumberCounters, 1000);
        setTimeout(forceResizeForVisibleCounters, 1500); // Force resize again
        setTimeout(checkNumberCounters, 2000);

        // Check on window load
        window.addEventListener('load', function() {
            setTimeout(checkNumberCounters, 50);
            setTimeout(checkNumberCounters, 100);
            setTimeout(forceResizeForVisibleCounters, 200);
            setTimeout(checkNumberCounters, 500);
            setTimeout(forceResizeForVisibleCounters, 1000);
        });

        // Also listen for Divi's custom events
        document.addEventListener('et_core_ready', forceResizeForVisibleCounters);
        document.addEventListener('et_builder_api_ready', forceResizeForVisibleCounters);

        // Expose manual trigger for debugging
        window.dnxteRefreshNumberCounters = function() {
            // Force resize
            window.dispatchEvent(new Event('resize'));
            if (typeof jQuery !== 'undefined') {
                jQuery(window).trigger('resize');
            }
        };
    }

    // Handle anchor link (#hash) navigation inside SimpleBar
    function setupAnchorLinkHandling() {
        if (!dnxteSimpleBarInstance) return;

        var scrollableElement = dnxteSimpleBarInstance.getScrollElement();
        if (!scrollableElement) return;

        // Get fixed header offset for scroll position calculation
        function getHeaderOffset() {
            var header = document.getElementById('main-header');
            if (header && (header.classList.contains('et-fixed-header') ||
                window.getComputedStyle(header).position === 'fixed')) {
                return header.offsetHeight + 20;
            }
            return 20;
        }

        // Scroll SimpleBar to a target element
        function scrollToElement(targetEl) {
            var offset = getHeaderOffset();
            var targetTop = targetEl.getBoundingClientRect().top
                + scrollableElement.scrollTop
                - scrollableElement.getBoundingClientRect().top
                - offset;

            scrollableElement.scrollTo({
                top: Math.max(0, targetTop),
                behavior: 'smooth'
            });
        }

        // [Fix #2] Triple-fallback element lookup for IDs with special characters
        function findTargetElement(hash) {
            if (!hash || hash === '#') return null;
            var id = hash.substring(1);

            // Primary: getElementById handles any ID string safely
            var el = document.getElementById(id);
            if (el) return el;

            // Fallback: querySelector (works for simple IDs, may fail on special chars)
            try {
                el = document.querySelector(hash);
                if (el) return el;
            } catch (e) {
                // Invalid CSS selector — ignore
            }

            // Legacy fallback: <a name="..."> anchors
            var namedEls = document.getElementsByName(id);
            if (namedEls.length > 0) return namedEls[0];

            return null;
        }

        // 1. Handle clicks on anchor links
        // [Fix #3] Use capture phase to intercept before Divi's handler
        document.addEventListener('click', function(e) {
            var anchor = e.target.closest('a[href*="#"]');
            if (!anchor) return;

            var href = anchor.getAttribute('href');
            if (!href) return;

            // Extract hash from href
            var hash;
            try {
                // [Fix #1] Use window.location.href as base so relative URLs
                // resolve correctly on non-root pages (e.g. /pricing-page/)
                var url = new URL(href, window.location.href);

                // Skip cross-origin links entirely
                if (url.origin !== window.location.origin) return;

                // Skip cross-page links — let the browser navigate normally
                if (url.pathname !== window.location.pathname) return;

                hash = url.hash;
            } catch (err) {
                if (href.startsWith('#')) {
                    hash = href;
                } else {
                    return;
                }
            }

            if (!hash || hash === '#') return;

            var targetEl = findTargetElement(hash);
            if (!targetEl) return;

            e.preventDefault();
            e.stopPropagation(); // [Fix #3] Prevent Divi's handler from conflicting
            scrollToElement(targetEl);

            // Update URL hash without native jump
            history.pushState(null, '', hash);
        }, true); // [Fix #3] Capture phase — fires before bubble-phase handlers

        // 2. Handle hash present on page load
        // [Fix #4] Progressive retry with MutationObserver fallback
        function tryHandleInitialHash(attempt) {
            var hash = window.location.hash;
            if (!hash || hash === '#') return;

            // Prevent native browser scroll on every attempt
            window.scrollTo(0, 0);

            var targetEl = findTargetElement(hash);
            if (targetEl) {
                scrollToElement(targetEl);
                return;
            }

            // Progressive retry: attempt * 100ms, up to 10 attempts
            if (attempt < 10) {
                setTimeout(function() {
                    tryHandleInitialHash(attempt + 1);
                }, attempt * 100);
                return;
            }

            // Final fallback: MutationObserver watches for dynamically added content
            var observer = new MutationObserver(function() {
                var el = findTargetElement(hash);
                if (el) {
                    observer.disconnect();
                    window.scrollTo(0, 0);
                    scrollToElement(el);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

            // Auto-disconnect after 10 seconds to prevent memory leaks
            setTimeout(function() {
                observer.disconnect();
            }, 10000);
        }

        // Kick off initial hash handling
        tryHandleInitialHash(0);

        // 3. Handle browser back/forward with hash changes
        window.addEventListener('hashchange', function() {
            var hash = window.location.hash;
            if (!hash || hash === '#') return;

            var targetEl = findTargetElement(hash);
            if (targetEl) {
                scrollToElement(targetEl);
            }
        });
    }

    // Apply custom styling
    function applyCustomStyling(config) {
        const container = document.querySelector('#dnxte_simplebar');
        if (!container) return;
        
        // Apply padding based on alignment
        if (config.alignment === "rtl") {
            container.style.paddingLeft = (config.width || 12) + 'px';
        } else {
            container.style.paddingRight = (config.width || 12) + 'px';
        }
        
        // Apply CSS custom properties for styling
        const styles = {
            '--scrollbar-width': (config.width || 12) + 'px',
            '--scrollbar-border-radius': (config.radius || 6) + 'px',
            '--scrollbar-thumb-color': config.thumbColor || '#888',
            '--scrollbar-track-color': config.trackColor || '#f1f1f1',
            '--scrollbar-thumb-shadow-color': config.shadowThumb || 'rgba(0,0,0,0.2)',
            '--scrollbar-rail-shadow-color': config.shadowTrack || 'rgba(0,0,0,0.1)',
            '--scrollbar-shadow-offset-y': (config.offsetY || 2) + 'px',
            '--scrollbar-shadow-blur': (config.blur || 4) + 'px'
        };
        
        Object.entries(styles).forEach(([property, value]) => {
            container.style.setProperty(property, value);
        });
        
        container.setAttribute('data-alignment', config.alignment || 'ltr');
    }
    
    // Set up Divi theme compatibility
    function setupDiviCompatibility() {
        if (!dnxteSimpleBarInstance) return;
        
        const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
        if (!scrollableElement) return;
        
        let lastScrollTop = 0;
        let isScrolling = false;
        let scrollTimer = null;
        
        // Function to handle fixed header logic
        function handleDiviFixedHeader() {
            const currentScrollTop = scrollableElement.scrollTop;
            const mainHeader = document.getElementById('main-header');
            
            if (!mainHeader) return;
            
            // Get header height for offset calculation
            const headerHeight = mainHeader.offsetHeight;
            const scrollThreshold = headerHeight + 50; // Add some buffer
            
            // Check if we should show fixed header
            if (currentScrollTop > scrollThreshold) {
                // Add fixed header class if not already present
                if (!mainHeader.classList.contains('et-fixed-header')) {
                    mainHeader.classList.add('et-fixed-header');
                    document.body.classList.add('et_fixed_header');
                    
                    // Trigger custom event for other scripts that might be listening
                    window.dispatchEvent(new CustomEvent('et-fixed-header-enabled'));
                }
                
                // Handle scroll direction for hide/show logic
                if (currentScrollTop > lastScrollTop && currentScrollTop > scrollThreshold + 150) {
                    // Scrolling down - hide header
                    mainHeader.classList.add('et-hide-fixed-header');
                } else {
                    // Scrolling up - show header
                    mainHeader.classList.remove('et-hide-fixed-header');
                }
            } else {
                // Remove fixed header class
                if (mainHeader.classList.contains('et-fixed-header')) {
                    mainHeader.classList.remove('et-fixed-header');
                    mainHeader.classList.remove('et-hide-fixed-header');
                    document.body.classList.remove('et_fixed_header');
                    
                    // Trigger custom event
                    window.dispatchEvent(new CustomEvent('et-fixed-header-disabled'));
                }
            }
            
            lastScrollTop = currentScrollTop;
        }
        
        // Debounced scroll handler
        function onScroll() {
            if (!isScrolling) {
                window.requestAnimationFrame(function() {
                    handleDiviFixedHeader();
                    isScrolling = false;
                });
                isScrolling = true;
            }
            
            // Clear and set timer for scroll end detection
            clearTimeout(scrollTimer);
            scrollTimer = setTimeout(function() {
                handleDiviFixedHeader();
            }, 150);
        }
        
        // Listen to SimpleBar scroll events
        scrollableElement.addEventListener('scroll', onScroll, { passive: true });
        
        // Initial check on load
        setTimeout(handleDiviFixedHeader, 100);
        
        // Also propagate scroll position to window for other scripts
        let propagationFrame = null;
        scrollableElement.addEventListener('scroll', function() {
            if (propagationFrame) {
                cancelAnimationFrame(propagationFrame);
            }
            propagationFrame = requestAnimationFrame(function() {
                // Update a custom property that other scripts can check
                window.dnxteScrollTop = scrollableElement.scrollTop;
                window.dnxteScrollLeft = scrollableElement.scrollLeft;
                
                // Dispatch a custom scroll event
                window.dispatchEvent(new CustomEvent('dnxte-scroll', {
                    detail: {
                        scrollTop: scrollableElement.scrollTop,
                        scrollLeft: scrollableElement.scrollLeft
                    }
                }));
            });
        });
    }
    
    // Initialize when DOM is ready
    function init() {
        // Wait for both DOM and jQuery to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                // Additional check for jQuery
                if (typeof jQuery !== 'undefined') {
                    jQuery(document).ready(initializeCustomScrollbar);
                } else {
                    initializeCustomScrollbar();
                }
            });
        } else {
            // DOM is already loaded
            if (typeof jQuery !== 'undefined') {
                jQuery(document).ready(initializeCustomScrollbar);
            } else {
                initializeCustomScrollbar();
            }
        }
    }
    
    // Start initialization
    init();
    
    // Expose cleanup function globally if needed
    window.dnxteCleanupScrollbar = function() {
        if (dnxteSimpleBarInstance) {
            dnxteSimpleBarInstance.unMount();
            dnxteSimpleBarInstance = null;
        }
    };

	setTimeout(() => {
		if (jQuery('.et_pb_scroll_top.dnxte-back-to-top-wrapper').length) {
			
			function getScrollPosition() {
				// Check if SimpleBar is active
				if (dnxteSimpleBarInstance) {
					const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
					return scrollableElement ? scrollableElement.scrollTop : 0;
				}
				// Fallback to window scroll for normal scrollbars
				return jQuery(window).scrollTop();
			}
			
			function handleBackToTopVisibility() {
				const scrollPosition = getScrollPosition();
				
				if (scrollPosition > 800) {
					jQuery('.et_pb_scroll_top.dnxte-back-to-top-wrapper').show().removeClass('et-hidden').addClass('et-visible')
				} else {
					jQuery('.et_pb_scroll_top.dnxte-back-to-top-wrapper').removeClass('et-visible').addClass('et-hidden')
				}
			}
			
			// Bind to window scroll (for normal scrollbar)
			jQuery(window).on('scroll', handleBackToTopVisibility);
			
			// Bind to SimpleBar scroll (when SimpleBar is active)
			if (dnxteSimpleBarInstance) {
				const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
				if (scrollableElement) {
					jQuery(scrollableElement).on('scroll', handleBackToTopVisibility);
				}
			}
			
			// Set initial state
			handleBackToTopVisibility();
		}

		jQuery('.et_pb_scroll_top.et-pb-icon.dnxte-back-to-top-wrapper').on('click', function () {
			
			// Check if SimpleBar is active
			if (dnxteSimpleBarInstance) {
				const scrollableElement = dnxteSimpleBarInstance.getScrollElement();
				if (scrollableElement) {
					// Animate SimpleBar scroll element
					jQuery(scrollableElement).animate({
						scrollTop: 0
					}, 800);
				}
			} else {
				// Animate normal html/body scroll
				jQuery('html, body').animate({
					scrollTop: 0
				}, 800);
			}
		});

	}, 1000 );
    
})(window, document);