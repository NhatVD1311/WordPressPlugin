(function ($) {
    $(document).ready(function () {

        /**
         * Header and Navigation Toggle and Ajax Form Submission
         */
        function showToast(message, type = "success") {
            const toast = $('<div class="dnxte-toast dnxte-header-navigation"></div>')
                .text(message)
                .addClass(type)
                .appendTo("body");

            // Trigger slide-up animation
            setTimeout(() => toast.addClass("show"), 50);

            // Remove toast after timeout with slide-down
            setTimeout(() => {
                toast.removeClass("show");
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Only bind to forms that are NOT font upload forms
        $(".dnext-ee-admin-content form:not([data-font-form])").on("submit", function (e) {
            e.preventDefault();

            const form = this;
            const formData = new FormData(form);

            const $submitBtn = $(form).find('input[type="submit"]');
            const originalText = $submitBtn.val();
            $submitBtn.val("Saving...").prop("disabled", true);

            $.ajax({
                url: dnxte_header_navigation_admin_ajax.ajax_url,
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        showToast("Settings saved successfully!", "success");
                    } else {
                        showToast(response.data || "Failed to save.", "error");
                    }
                },
                error: function (xhr, status, error) {
                    console.error("AJAX Error:", error);
                    showToast("AJAX request failed.", "error");
                },
                complete: function () {
                    $submitBtn.val(originalText).prop("disabled", false);
                },
            });
        });

        // new js for header and nav
        $(".toggle-with-children").each(function () {
            const $checkbox = $(this).find(".toggle-checkbox");
            const $child = $(this).find(".child-data");

            function toggleChild() {
                if ($checkbox.is(":checked")) {
                    $child.css("display", "block");
                } else {
                    $child.css("display", "none");
                }
            }

            toggleChild(); // initial state
            $checkbox.on("change", toggleChild);


        });

        // active state for select hover style
        $('input[name="group_of_effects"]').on("change", function () {
            $(".single-effect-box").attr("data-state", "inactive");
            $(this).closest(".single-effect-box").attr("data-state", "active");
        });

        // Optional: set active state on page load
        const checkedRadio = $('input[name="group_of_effects"]:checked');
        if (checkedRadio.length) {
            checkedRadio.closest(".single-effect-box").attr("data-state", "active");
        }

        // active state for select hover style
        $('input[name="button_icon"]').on("change", function () {
            $(".single-icon-box").attr("data-state", "inactive");
            $(this).closest(".single-icon-box").attr("data-state", "active");
        });

        // Optional: set active state on page load
        const buttonIcon = $('input[name="button_icon"]:checked');
        if (buttonIcon.length) {
            buttonIcon.closest(".single-icon-box").attr("data-state", "active");
        }

        // file upload
        $('.fileupload_group input[type="file"]').on("change", function () {
            var fileName = $(this).prop("files")[0]?.name || "";
            $(this)
                .closest(".fileupload_group")
                .find(".fileupload_filename")
                .text(fileName);
        });

        // Multiple CTA Buttons repeater
        (function initCtaRepeater() {
            const $repeater = $("#dnxte-cta-buttons-repeater");
            if (!$repeater.length) {
                return;
            }

            let counter = 0;

            // Add a new button row from the template.
            $("#dnxte-add-cta-button").on("click", function (e) {
                e.preventDefault();
                const tmpl = $("#tmpl-dnxte-cta-button-row").html() || "";
                // Use a unique, non-numeric index so it never collides with existing rows.
                const html = tmpl.replace(/__INDEX__/g, "new_" + counter);
                counter++;
                $repeater.append(html);
            });

            // Remove a button row.
            $repeater.on("click", ".dnxte-remove-cta-button", function (e) {
                e.preventDefault();
                $(this).closest(".dnxte-cta-button-row").remove();
            });

            // Per-row icon picker selection.
            $repeater.on("click", ".dnxte-cta-icon-option", function () {
                const $picker = $(this).closest(".dnxte-cta-icon-picker");
                $picker.find(".dnxte-cta-icon-option").removeClass("selected");
                $(this).addClass("selected");
                $picker.find(".dnxte-cta-icon-value").val($(this).data("icon") || "");
            });
        })();
        // Toaster Notification.
        function showToastNotification(message, type = 'success') {
            // Remove existing if any
            $('.dnxte-toast, .dnxte-toast-overlay').remove();

            // Add overlay
            const $overlay = $('<div class="dnxte-toast-overlay"></div>').appendTo('body').fadeIn(100);

            const iconBase = Dnxte_Essential.assets_url + 'images/admin/';
            const iconLoading = iconBase + 'dnx-loading-icon.svg'; // animated SVG or GIF
            const iconSuccess = iconBase + 'dnx-check-icon.svg';
            const iconError = iconBase + 'dnx-error-icon.svg';

            const toast = $(`
			<div class="dnxte-toast ${type}">
				<img src="${iconLoading}" class="dnxte-toast-icon loading" alt="loading">
				<span class="dnxte-toast-message">${message}</span>
				<div class="dnxte-toast-progress"></div>
			</div>
		`).appendTo('body');

            setTimeout(() => toast.addClass('show'), 10);

            // Replace loading icon with success/error icon
            setTimeout(() => {
                const $icon = toast.find('.dnxte-toast-icon');
                $icon.removeClass('loading');

                if (type === 'success') {
                    $icon.attr('src', iconSuccess).attr('alt', 'success');
                } else {
                    $icon.attr('src', iconError).attr('alt', 'error');
                }
            }, 600); // 600ms to simulate "loading"

            // Remove toast and overlay after timeout
            setTimeout(() => {
                toast.removeClass('show');
                setTimeout(() => {
                    toast.remove();
                    $overlay.fadeOut(200, () => $overlay.remove());
                }, 300);
            }, 3000);
        }

        // Toast Notification for Extension Maintenance Mode.
        $('.dnxte-admin-extensions-item-toggle input.show-alert-bar[type="checkbox"]').on('change', function () {
            const isChecked = $(this).is(':checked');
            const label = $(this).closest('.dnxte-admin-extensions-item')
                .find('.dnxte-admin-extensions-item-title label').text();

            showToastNotification(
                isChecked ? `${Dnxte_Essential.activated_notification}` : `${Dnxte_Essential.deactivated_notification}`,
                isChecked ? 'success' : 'error'
            );
        });

    });



    // On Scroll Logo Upload Functionality =======
    let frame;

    $('#on_scroll_logo_upload_button').on('click', function (e) {
        e.preventDefault();

        // If the media frame already exists, reopen it.
        if (frame) {
            frame.open();
            return;
        }

        // Create a new media frame
        frame = wp.media({
            title: 'Select or Upload an Image',
            button: {
                text: 'Use this image'
            },
            library: {
                type: 'image' // Only allow images
            },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();

            $('#on_scroll_logo').val(attachment.url);
            $('#on_scroll_logo_preview').attr('src', attachment.url).show();
        });

        frame.open();
    });

    $('#on_scroll_logo_remove_button').on('click', function (e) {
        e.preventDefault();
        $('#on_scroll_logo').val('');
        $('#on_scroll_logo_preview').hide();
    });


})(jQuery);
