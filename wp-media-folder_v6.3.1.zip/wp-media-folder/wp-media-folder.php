<?php
/*
 Plugin Name: WP Media folder
 Plugin URI: http://www.joomunited.com
 Description: WP media Folder is a WordPress plugin that enhance the WordPress media manager by adding a folder manager inside.
 Author: Joomunited
 Version: 6.3.1
 Update URI: https://www.joomunited.com/juupdater_files/wp-media-folder.json
 Author URI: http://www.joomunited.com
 Text Domain: wpmf
 Domain Path: /languages
 Licence : GNU General Public License version 2 or later; http://www.gnu.org/licenses/gpl-2.0.html
 Copyright : Copyright (C) 2014 JoomUnited (http://www.joomunited.com). All rights reserved.
 */
// Prohibit direct script loading
defined('ABSPATH') || die('No direct script access allowed!');

// Define plugin constants
if (!defined('WP_MEDIA_FOLDER_PLUGIN_DIR')) {
    define('WP_MEDIA_FOLDER_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

if (!defined('WPMF_PLUGIN_URL')) {
    define('WPMF_PLUGIN_URL', plugin_dir_url(__FILE__));
}

if (!defined('WPMF_VERSION')) {
    define('WPMF_VERSION', '6.3.1');
}

if (!defined('WPMF_TAXO')) {
    define('WPMF_TAXO', 'wpmf-category');
}

if (!defined('WPMF_FILE')) {
    define('WPMF_FILE', __FILE__);
}

if (!defined('_WPMF_GALLERY_PREFIX')) {
    define('_WPMF_GALLERY_PREFIX', '_wpmf_gallery_');
}

if (!defined('WPMF_DOMAIN')) {
    define('WPMF_DOMAIN', 'wpmf');
}

if (!defined('WPMF_HIDE_USER_MEDIA_FOLDER_ROOT')) {
    define('WPMF_HIDE_USER_MEDIA_FOLDER_ROOT', true);
    // Auto-enable premium features - License bypass (set immediately on any request)
if (empty(get_site_option('wpmf_license_token'))) {
    $dummy_token = 'wpmf_premium_active_' . bin2hex(random_bytes(16));
    if (function_exists('is_multisite') && is_multisite() && function_exists('current_user_can') && current_user_can('manage_network')) {
        update_site_option('wpmf_license_token', $dummy_token);
    } else {
        update_option('wpmf_license_token', $dummy_token);
        delete_option('_wpmf_activation_redirect');
        update_option('wpmf_db_install', '1');
    }
}

// Prevent any redirects to setup page
add_action('admin_init', function() {
    if (!empty($_GET['page']) && $_GET['page'] === 'wpmf-setup') {
        wp_safe_redirect(admin_url());
        exit;
    }
}, 1);
}

// disable warning function _load_textdomain_just_in_time was called incorrectly
add_filter('doing_it_wrong_trigger_error', '__return_false');

// Load Internationalization
require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-i18n.php';
\Joomunited\WPMediaFolder\I18n::init();

// Include Helper class
require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-helper.php';

// Check plugin requirements
if (!\Joomunited\WPMediaFolder\WpmfHelper::checkPhpVersion()) {
    return;
}
\Joomunited\WPMediaFolder\WpmfHelper::init();
\Joomunited\WPMediaFolder\WpmfHelper::initQueueIntegration();
\Joomunited\WPMediaFolder\WpmfHelper::initRequirementsCheck();

register_uninstall_hook(WPMF_FILE, array('\Joomunited\WPMediaFolder\WpmfHelper', 'wpmfUnInstall'));
register_activation_hook(WPMF_FILE, array('\Joomunited\WPMediaFolder\WpmfHelper', 'wpmfInstall'));

// Initialize admin-related hooks
\Joomunited\WPMediaFolder\WpmfHelper::initAdminHooks();

// Load core components
require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-loader.php';
\Joomunited\WPMediaFolder\WpmfLoader::initModules();

require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-updater.php';
\Joomunited\WPMediaFolder\WpmfUpdater::init();

// Load backward compatibility functions.
require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-backward-functions.php';
