<?php
/* Prohibit direct script loading */
defined('ABSPATH') || die('No direct script access allowed!');
$allow_tabs_submit = array(
    'general',
    'media_access',
    'wordpress_gallery',
    'sync_media',
    'gallery_addon',
    'files_folders',
    'server_sync',
    'physical_server_folders',
    'image_optimization',
    'gallery_photographer_addon'
);
?>
<?php if (in_array($ju_tab['id'], $allow_tabs_submit)) : ?>
<div class="btn_wpmf_saves">
    <button type="submit" name="btn_wpmf_save"
            class="btn_wpmf_save ju-button waves-effect waves-light"><?php esc_html_e('Save Changes', 'wpmf'); ?></button>
</div>
<?php endif; ?>
