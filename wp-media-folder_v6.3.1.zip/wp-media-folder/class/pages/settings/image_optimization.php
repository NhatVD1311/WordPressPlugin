<?php

/**
 * Image optimization settings.
 *
 * @var array $image_optimization
 * @var array $thumbnail_sizes
 * @var array $folders
 */

$image_optimization = isset($image_optimization) && is_array($image_optimization)
    ? $image_optimization
    : array();

$excluded_formats = isset($image_optimization['excluded_formats']) &&
    is_array($image_optimization['excluded_formats'])
    ? $image_optimization['excluded_formats']
    : array();

$selected_thumbnail_sizes = isset($image_optimization['thumbnail_sizes']) &&
    is_array($image_optimization['thumbnail_sizes'])
    ? $image_optimization['thumbnail_sizes']
    : array();

$thumbnail_sizes = array(
    'full'          => __('Full size', 'wpmf'),
    'thumbnail'     => __('Thumbnail', 'wpmf'),
    'medium'        => __('Medium', 'wpmf'),
    'medium_large'  => __('Medium Large', 'wpmf'),
    'large'         => __('Large', 'wpmf'),
);

$excluded_folders = isset($image_optimization['excluded_folders']) &&
    is_array($image_optimization['excluded_folders'])
    ? $image_optimization['excluded_folders']
    : array();

$compression_level = isset($image_optimization['compression_level'])
    ? $image_optimization['compression_level']
    : 'balanced';
?>

<div id="image_optimization_settings">

    <div class="content-box">

        <!-- Format and checks -->
        <div class="ju-settings-option wpmf_width_100">
            <div class="wpmf_row_full">
                <div class="wpmf_format_and_check wpmf_row_full">
                    <h2 class="wpmf_image_optimization_title ju-setting-label"><?php esc_html_e('Format and checks', 'wpmf'); ?></h2>
                    <p class="description">
                        <?php
                        esc_html_e(
                            'Select how images should be processed and which output formats to generate.',
                            'wpmf'
                        );
                        ?>
                    </p>
                </div>



                <!-- Auto-optimize new uploads -->
                <div class="wpmf_auto_optimize_uploads">
                    <input
                        type="hidden"
                        name="image_optimization[auto_optimize_uploads]"
                        value="0">

                    <div class="ju-switch-button">
                        <label class="switch">
                            <input
                                type="checkbox"
                                id="wpmf_auto_optimize_uploads"
                                name="image_optimization[auto_optimize_uploads]"
                                value="1"
                                <?php
                                checked(
                                    !empty($image_optimization['auto_optimize_uploads']),
                                    true
                                );
                                ?>>

                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="wrapper-title">
                        <label class="ju-setting-label text" for="wpmf_auto_optimize_uploads" data-wpmftippy="<?php esc_attr_e(
                            'Automatically apply image transformation and compression to new WebP and AVIF uploads.',
                            'wpmf'
                        ); ?>">
                            <?php esc_html_e('Auto-optimize new uploads', 'wpmf'); ?>
                        </label>

                        <p class="description">
                            <?php
                            esc_html_e(
                                'Enable this option to automatically optimize images when uploading new images.',
                                'wpmf'
                            );
                            ?>
                        </p>
                    </div>
                </div>

                <div class="wpmf_format_checks wpmf_width_100">

                    <!-- Library to Process Images -->
                    <div class="wpmf_format_check_section">

                        <div class="wpmf_format_check_header">
                            <label class="ju-setting-label text" data-wpmftippy="<?php esc_attr_e('Select the image processing library used to transform and compress WebP and AVIF images.', 'wpmf'); ?>">
                                <?php esc_html_e('Library to process images', 'wpmf'); ?>
                            </label>
                        </div>

                        <div class="wpmf_format_check_options">

                            <!-- GD -->
                            <div class="wpmf_format_check_item <?php echo esc_attr(isset($image_optimization['processing_library']) && $image_optimization['processing_library'] === 'gd' ? 'active' : ''); ?>">
                                <label>
                                    <input
                                        type="radio"
                                        name="image_optimization[processing_library]"
                                        value="gd"
                                        <?php
                                        checked(
                                            isset($image_optimization['processing_library'])
                                                ? $image_optimization['processing_library']
                                                : '',
                                            'gd'
                                        );
                                        ?>>
                                    <div>
                                        <span class="wpmf_format_check_name">
                                            <?php esc_html_e('GD', 'wpmf'); ?>
                                        </span>

                                        <span class="wpmf_format_check_status <?php echo empty($gd_available) ? 'unsupported' : ''; ?>">
                                            <?php
                                            if (!empty($gd_available)) {
                                                esc_html_e('Available', 'wpmf');
                                            } else {
                                                esc_html_e('Not installed', 'wpmf');
                                            }
                                            ?>
                                        </span>
                                    </div>


                                    <span class="wpmf_format_check_description">
                                        <?php esc_html_e('Built-in PHP library. Compatible with most servers.', 'wpmf'); ?>
                                    </span>
                                </label>
                            </div>

                            <!-- Imagick -->
                            <div class="wpmf_format_check_item <?php echo esc_attr(isset($image_optimization['processing_library']) && $image_optimization['processing_library'] === 'imagick' ? 'active' : ''); ?>">
                                <label>
                                    <input
                                        type="radio"
                                        name="image_optimization[processing_library]"
                                        value="imagick"
                                        <?php
                                        checked(
                                            isset($image_optimization['processing_library'])
                                                ? $image_optimization['processing_library']
                                                : '',
                                            'imagick'
                                        );
                                        ?>>
                                    <div>
                                        <span class="wpmf_format_check_name">
                                            <?php esc_html_e('Imagick', 'wpmf'); ?>
                                        </span>

                                        <span class="wpmf_format_check_status <?php echo empty($imagick_available) ? 'unsupported' : ''; ?>">
                                            <?php
                                            if (!empty($imagick_available)) {
                                                esc_html_e('Available', 'wpmf');
                                            } else {
                                                esc_html_e('Not installed', 'wpmf');
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    <span class="wpmf_format_check_description">
                                        <?php esc_html_e('Better performance and more features (recommended).', 'wpmf'); ?>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Output Formats -->
                    <div class="wpmf_format_check_section">

                        <div class="wpmf_format_check_header">
                            <label class="ju-setting-label text" data-wpmftippy="<?php esc_attr_e('Select the image formats that WPMF can process.', 'wpmf'); ?>">
                                <?php esc_html_e('Output Formats', 'wpmf'); ?>
                            </label>
                        </div>

                        <div class="wpmf_format_check_options">

                            <!-- WebP -->
                            <div class="wpmf_format_check_item">
                                <label>
                                    <input
                                        type="checkbox"
                                        name="image_optimization[output_formats][]"
                                        value="webp"
                                        <?php
                                        checked(
                                            !empty($image_optimization['output_formats'])
                                                && in_array(
                                                    'webp',
                                                    $image_optimization['output_formats'],
                                                    true
                                                ),
                                            true
                                        );
                                        ?>
                                        <?php
                                        disabled(
                                            empty($webp_supported),
                                            true
                                        );
                                        ?>>
                                    <div>
                                        <span class="wpmf_format_check_name">
                                            <?php esc_html_e('WebP', 'wpmf'); ?>
                                        </span>

                                        <span
                                            class="wpmf_format_check_status <?php echo empty($webp_supported) ? 'unsupported' : ''; ?>">
                                            <?php
                                            if (!empty($webp_supported)) {
                                                esc_html_e('Supported', 'wpmf');
                                            } else {
                                                esc_html_e('Unsupported', 'wpmf');
                                            }
                                            ?>
                                        </span>
                                    </div>

                                    <span class="wpmf_format_check_description">
                                        <?php esc_html_e('Modern format with better compression and quality.', 'wpmf'); ?>
                                    </span>
                                </label>
                            </div>

                            <!-- AVIF -->
                            <div class="wpmf_format_check_item">
                                <label>
                                    <input
                                        type="checkbox"
                                        name="image_optimization[output_formats][]"
                                        value="avif"
                                        <?php
                                        checked(
                                            !empty($image_optimization['output_formats'])
                                                && in_array(
                                                    'avif',
                                                    $image_optimization['output_formats'],
                                                    true
                                                ),
                                            true
                                        );
                                        ?>
                                        <?php
                                        disabled(
                                            empty($avif_supported),
                                            true
                                        );
                                        ?>>
                                    <div>
                                        <span class="wpmf_format_check_name">
                                            <?php esc_html_e('AVIF', 'wpmf'); ?>
                                        </span>

                                        <span
                                            class="wpmf_format_check_status <?php echo empty($avif_supported) ? 'unsupported' : ''; ?>">
                                            <?php
                                            if (!empty($avif_supported)) {
                                                esc_html_e('Supported', 'wpmf');
                                            } else {
                                                esc_html_e('Unsupported', 'wpmf');
                                            }
                                            ?>
                                        </span>
                                    </div>

                                    <span class="wpmf_format_check_description">
                                        <?php esc_html_e('Next-generation format with even smaller file sizes.', 'wpmf'); ?>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wp-start-image-optimization">
                    <div id="wpmf-image-optimization-progress" class="wpmf-image-optimization-progress" style="display: none;">
                        <!-- <div id="wpmf-image-optimization-progress" class="wpmf-image-optimization-progress"> -->
                        <div class="wpmf-image-optimization-progress-header">
                            <div class="wpmf-image-optimization-progress-info">
                                <span class="wpmf-image-optimization-progress-spinner"></span>

                                <div>
                                    <div class="wpmf-image-optimization-progress-title">
                                        <?php esc_html_e('Optimizing images...', 'wpmf'); ?>
                                    </div>

                                    <div class="wpmf-image-optimization-progress-description">
                                        <?php esc_html_e('Please keep this page open while the process is running.', 'wpmf'); ?>
                                    </div>
                                </div>
                            </div>

                            <button
                                type="button"
                                id="wpmf-image-optimization-stop"
                                class="wpmf-image-optimization-stop">
                                <span class="material-icons-outlined">close</span>
                                <?php esc_html_e('Stop', 'wpmf'); ?>
                            </button>
                        </div>

                        <div class="wpmf-image-optimization-progress-bar-wrap">
                            <div
                                id="wpmf-image-optimization-progress-bar"
                                class="wpmf-image-optimization-progress-bar"
                                style="width: 0%;"></div>
                        </div>

                        <div class="wpmf-image-optimization-progress-percent">
                            <span id="wpmf-image-optimization-progress-images"><?php esc_html_e('Calculating images...', 'wpmf'); ?></span>
                            <span id="wpmf-image-optimization-progress-value"></span>
                        </div>
                    </div>
                    <div class="wp-start-btn-image-optimization">
                        <div class="wp-optimize-icon">
                            <span class="material-icons">image</span>
                        </div>

                        <div class="wp-optimize-content">
                            <h2><?php esc_html_e('Ready to optimize your images', 'wpmf'); ?></h2>

                            <p>
                                <?php esc_html_e(
                                    'This will process existing images in your media library using the selected settings. It may take a few minutes depending on how many images you have.',
                                    'wpmf'
                                ); ?>
                            </p>
                        </div>

                        <a class="ju-button" id="start_image_optimization">
                            <span class="material-icons">play_arrow</span>
                            <?php esc_html_e('Start Optimization', 'wpmf'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- WebP & AVIF -->
        <div class="ju-settings-option wpmf_width_100">
            <div class="wpmf_row_full">
                <h2 class="wpmf_image_optimization_title ju-setting-label wpmf_width_100"><?php esc_html_e('WebP & AVIF', 'wpmf'); ?></h2>
                <p class="description">
                    <?php
                    esc_html_e(
                        'Select the compression level applied when processing WebP and AVIF images.',
                        'wpmf'
                    );
                    ?>
                </p>
                <div class="wpmf_image_optimization_option" style="display: inline-block; margin-top: 20px">

                    <label
                        class="ju-setting-label text"
                        for="wpmf_compression_level">
                        <?php esc_html_e('Compression level', 'wpmf'); ?>
                    </label>

                    <div>
                        <select
                            id="wpmf_compression_level"
                            name="image_optimization[compression_level]">
                            <option
                                value="low"
                                <?php selected($compression_level, 'low'); ?>>
                                <?php esc_html_e('Low', 'wpmf'); ?>
                            </option>

                            <option
                                value="balanced"
                                <?php selected($compression_level, 'balanced'); ?>>
                                <?php esc_html_e('Balanced', 'wpmf'); ?>
                            </option>

                            <option
                                value="high"
                                <?php selected($compression_level, 'high'); ?>>
                                <?php esc_html_e('High', 'wpmf'); ?>
                            </option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Thumbnail sizes -->
        <div class="ju-settings-option wpmf_width_100">
            <div class="wpmf_row_full">

                <h2 class="wpmf_image_optimization_title ju-setting-label wpmf_width_100">
                    <?php esc_html_e('Thumbnail sizes to process', 'wpmf'); ?>
                </h2>

                <p class="description">
                    <?php
                    esc_html_e(
                        'Select the image sizes that should be processed when optimizing WebP and AVIF images.',
                        'wpmf'
                    );
                    ?>
                </p>

                <div class="wpmf_thumbnail_sizes">

                    <?php if (!empty($thumbnail_sizes)) : ?>
                        <?php foreach ($thumbnail_sizes as $size_name => $size_data) : ?>
                            <?php
                            if (is_array($size_data)) {
                                $label = isset($size_data['label'])
                                    ? $size_data['label']
                                    : $size_name;
                            } else {
                                $label = $size_data;
                            }
                            ?>

                            <label class="wpmf_thumbnail_size">
                                <input
                                    type="checkbox"
                                    name="image_optimization[thumbnail_sizes][]"
                                    value="<?php echo esc_attr($size_name); ?>"
                                    <?php
                                    checked(
                                        in_array(
                                            $size_name,
                                            $selected_thumbnail_sizes,
                                            true
                                        ),
                                        true
                                    );
                                    ?>>

                                <span>
                                    <?php echo esc_html($label); ?>
                                </span>

                            </label>

                        <?php endforeach; ?>

                    <?php else : ?>
                        <p class="description">
                            <?php
                            esc_html_e(
                                'No thumbnail sizes are available.',
                                'wpmf'
                            );
                            ?>
                        </p>

                    <?php endif; ?>

                </div>

            </div>
        </div>

        <!-- Exclude folders -->
        <div class="ju-settings-option wpmf_width_100">
            <div class="wpmf_row_full">

                <h2 class="wpmf_image_optimization_title ju-setting-label wpmf_width_100">
                    <?php esc_html_e('Exclude folders', 'wpmf'); ?>
                </h2>

                <p class="description">
                    <?php
                    esc_html_e(
                        'Select the folders whose WebP and AVIF images should not be processed.',
                        'wpmf'
                    );
                    ?>
                </p>

                <div id="wpmf_image_optimization_excluded_folders">
                    <div class="ju-settings-option box-shadow-none wpmf_width_100" style="overflow:auto">
                        <div class="wpmf_row_full">
                            <div class="wpmf_left">
                                <div class="wpmf_foldertree_categories"></div>
                                <input
                                    type="hidden"
                                    name="image_optimization[excluded_folders]"
                                    id="image_optimization_excluded_folders_value"
                                    value="<?php
                                            echo esc_attr(
                                                wp_json_encode(
                                                    isset($image_optimization['excluded_folders'])
                                                        ? array_map('intval', (array) $image_optimization['excluded_folders'])
                                                        : []
                                                )
                                            );
                                            ?>">
                                <input type="hidden" name="wpmf_image_optimization[excluded_folders]" id="wpmf_image_optimization_excluded_folders_value"
                                    value="<?php
                                            echo esc_attr(
                                                wp_json_encode(
                                                    isset($image_optimization['excluded_folders'])
                                                        ? array_map('intval', (array) $image_optimization['excluded_folders'])
                                                        : []
                                                )
                                            );
                                            ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wpmf_image_optimization_option ju-setting-label">
                    <input
                        type="hidden"
                        name="image_optimization[do_not_convert_png]"
                        value="0">
                    <label for="wpmf_do_not_convert_png">
                        <input type="checkbox" id="wpmf_do_not_convert_png" name="image_optimization[do_not_convert_png]" value="1"
                            <?php checked(!empty($image_optimization['do_not_convert_png']), true); ?> />
                        <?php esc_html_e('Do not convert PNG', 'wpmf'); ?>
                    </label>
                </div>
            </div>
        </div>

    </div>
</div>
