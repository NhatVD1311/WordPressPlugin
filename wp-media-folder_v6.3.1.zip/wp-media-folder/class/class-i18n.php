<?php
/**
 * Internationalization (I18n) loader for WP Media Folder
 *
 * Handles translation initialization for the plugin.
 *
 * @package WP Media Folder
 */

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

/**
 * Class I18n
 *
 * Handles the initialization of translations for the WP Media Folder plugin.
 */
class I18n
{
    /**
     * Initialize plugin translations and core dependencies
     *
     * @return void
     */
    public static function init()
    {
        // Ensure plugin functions are available
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // Load JoomUnited translation helper
        $translation_file = WP_MEDIA_FOLDER_PLUGIN_DIR . 'jutranslation/jutranslation.php';
        if (file_exists($translation_file)) {
            include_once $translation_file;
        }

        // Initialize translation
        if (class_exists('\Joomunited\WPMediaFolder\Jutranslation\Jutranslation')) {
            call_user_func(
                '\Joomunited\WPMediaFolder\Jutranslation\Jutranslation::init',
                WPMF_FILE,
                'wpmf',
                'WP Media Folder',
                'wpmf',
                'languages' . DIRECTORY_SEPARATOR . 'wpmf-en_US.mo'
            );
        }
    }
}
