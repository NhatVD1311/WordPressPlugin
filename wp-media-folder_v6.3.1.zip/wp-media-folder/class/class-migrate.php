<?php
/**
 * Handle Migration for WP Media Folder
 *
 * @package WP Media Folder
 */

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

use Joomunited\WPMediaFolder\WpmfHelper;

/**
 * Class WpmfMigrate
 *
 * Purpose: Handles migration of media data into WP Media Folder.
 * - Transfers or synchronizes WordPress media library items.
 * - Preserves folder and file structure during migration.
 * - Integrates with WP Media Folder for organized media management.
 *
 * Usage: Instantiate the class and call its migrate methods
 * to perform the data transfer process.
 */
class WpmfMigrate
{
    /**
     * Register Ajax actions and migration-related hooks.
     *
     * @return void
     */
    public function __construct()
    {
        add_action('wp_ajax_wpmf_migrate_media_library_folders', array($this, 'migrateMediaLibraryFolders'));
        add_filter(
            'wpmf_migrate_upload_folder',
            array($this, 'doMigrateUploadsFolder'),
            10,
            3
        );

        add_filter(
            'wpmf_assign_attachment_folder',
            array($this, 'doAssignAttachmentFolder'),
            10,
            3
        );
    }

    /**
     * Get available migrations
     *
     * @return array
     */
    public static function getAvailableMigrations()
    {
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $migrations = array();

        /**
         * Media Library Folders
         */
        if (is_plugin_active('media-library-plus/media-library-plus.php')) {
            $migrations['media_library_folders'] = 1;
        }

        return $migrations;
    }

    /**
     * Queue uploads folders migration
     *
     * @return void
     */
    public function migrateMediaLibraryFolders()
    {
        if (empty($_POST['wpmf_nonce']) ||
            !wp_verify_nonce($_POST['wpmf_nonce'], 'wpmf_nonce')
        ) {
            die();
        }

        $wpmf_capability = apply_filters('wpmf_user_can', current_user_can('manage_options'), 'migrate_media_library_folders');
        if (!$wpmf_capability) {
            wp_send_json_error(null, 403);
        }

        $folders = $this->getUploadsFolderTree();

        if (empty($folders)) {
            wp_send_json(array(
                'status' => false,
            ));
        }

        /**
         * Reset old map
         */
        delete_option('wpmf_migrate_folder_map');

        foreach ($folders as $folder) {
            WpmfHelper::wpmfAddToQueue(array(
                'action' => 'wpmf_migrate_upload_folder',
                'type'   => 'folder',
                'name'   => $folder['name'],
                'path'   => $folder['path'],
                'parent' => $folder['parent'],
            ));
        }

        wp_send_json(array(
            'status' => true,
        ));
    }

    /**
     * Migrate an uploads folder into WP Media Folder taxonomy.
     *
     * @param mixed   $result     Previous filter result.
     * @param array   $datas      Folder migration data.
     * @param integer $element_id Queue element ID.
     *
     * @return boolean
     */
    public function doMigrateUploadsFolder($result, $datas, $element_id)
    {
        $folder_map = get_option(
            'wpmf_migrate_folder_map',
            array()
        );

        $name   = $datas['name'];
        $path   = $datas['path'];
        $parent = $datas['parent'];

        $parent_id = 0;

        if (!empty($parent) &&
            isset($folder_map[$parent])
        ) {
            $parent_id = (int) $folder_map[$parent];
        }

        /**
         * Check existing term
         */
        $existing = $this->getFolderTermByNameAndParent(
            $name,
            $parent_id
        );

        if ($existing) {
            $term_id = (int) $existing->term_id;
        } else {
            /**
             * Unique slug
             */
            $slug = md5($path);

            $created = $this->createFolderProgrammatically(
                $name,
                $parent_id,
                'uploads_tree_migrate',
                $slug
            );

            if (is_wp_error($created)) {
                return false;
            }

            $term_id = (int) $created->term_id;
        }

        /**
         * Save folder map
         */
        $folder_map[$path] = $term_id;

        update_option(
            'wpmf_migrate_folder_map',
            $folder_map
        );

        /**
         * Queue response
         */
        $responses = array(
            'folder_id' => $term_id
        );

        $wpmfQueue = \Joomunited\Queue\JuMainQueue::getInstance('wpmf');

        $wpmfQueue->updateQueueTermMeta(
            $term_id,
            (int) $element_id
        );

        $wpmfQueue->updateResponses(
            (int) $element_id,
            $responses
        );

        /**
         * Queue attachments
         */
        $this->addAttachmentsToQueue(
            $path,
            $term_id
        );

        return true;
    }

    /**
     * Add matching attachments to the migration queue.
     *
     * @param string  $folder_path Folder path to match.
     * @param integer $term_id     Destination folder term ID.
     *
     * @return void
     */
    public function addAttachmentsToQueue($folder_path, $term_id)
    {
        $attachments = get_posts(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        if (empty($attachments)) {
            return;
        }

        foreach ($attachments as $attachment_id) {
            $attached_file = get_post_meta(
                $attachment_id,
                '_wp_attached_file',
                true
            );

            if (empty($attached_file)) {
                continue;
            }

            $relative_dir = dirname($attached_file);

            if ($relative_dir === '.' ||
                empty($relative_dir)
            ) {
                $current_path = 'uploads';
            } else {
                $current_path = 'uploads/' . trim(
                    $relative_dir,
                    '/'
                );
            }

            if ($current_path !== $folder_path) {
                continue;
            }

            WpmfHelper::wpmfAddToQueue(array(
                'action'        => 'wpmf_assign_attachment_folder',
                'attachment_id' => $attachment_id,
                'term_id'       => $term_id,
            ));
        }
    }

    /**
     * Assign an attachment to a folder term.
     *
     * @param mixed   $result     Previous filter result.
     * @param array   $datas      Attachment and term data.
     * @param integer $element_id Queue element ID.
     *
     * @return boolean
     */
    public function doAssignAttachmentFolder($result, $datas, $element_id)
    {
        wp_set_object_terms(
            (int) $datas['attachment_id'],
            array((int) $datas['term_id']),
            WPMF_TAXO,
            false
        );

        $responses = array(
            'attachment_id' => (int) $datas['attachment_id']
        );

        $wpmfQueue = \Joomunited\Queue\JuMainQueue::getInstance('wpmf');

        $wpmfQueue->updateQueuePostMeta(
            (int) $datas['attachment_id'],
            (int) $element_id
        );

        $wpmfQueue->updateResponses(
            (int) $element_id,
            $responses
        );

        return true;
    }

    /**
     * Create a folder programmatically.
     *
     * @param string  $term       Folder name.
     * @param integer $termParent Parent term ID.
     * @param string  $trigger    Folder creation trigger.
     * @param string  $slug       Optional folder slug.
     *
     * @return object|false Folder term object on success, false on failure.
     */
    public function createFolderProgrammatically($term, $termParent = 0, $trigger = 'programmatically', $slug = '')
    {
        $args = array('parent' => $termParent);

        if (!empty($slug)) {
            $args['slug'] = $slug;
        }

        $inserted = wp_insert_term($term, WPMF_TAXO, $args);

        if (is_wp_error($inserted)) {
            return $inserted;
        }

        wp_update_term($inserted['term_id'], WPMF_TAXO, array('term_group' => get_current_user_id()));

        update_term_meta($inserted['term_id'], '_wpmf_created_time', time());

        do_action('wpmf_create_folder', $inserted['term_id'], $term, $termParent, array('trigger' => $trigger));

        return get_term($inserted['term_id'], WPMF_TAXO);
    }

    /**
     * Get folder term by name and parent term ID.
     *
     * @param string  $name   Folder term name.
     * @param integer $parent Parent term ID.
     *
     * @return object|false Folder term object on success, false on failure.
     */
    public function getFolderTermByNameAndParent($name, $parent = 0)
    {
        $terms = get_terms(array(
            'taxonomy'   => WPMF_TAXO,
            'hide_empty' => false,
            'name'       => $name,
            'parent'     => (int) $parent,
            'number'     => 1,
        ));

        if (is_wp_error($terms) ||
            empty($terms)
        ) {
            return false;
        }

        return $terms[0];
    }

    /**
     * Scan uploads tree
     *
     * @return array
     */
    public function getUploadsFolderTree()
    {
        $upload_dir = wp_upload_dir();

        $base_dir = $upload_dir['basedir'];

        $folders = array();

        $this->scanUploadsFoldersRecursive(
            $base_dir,
            'uploads',
            '',
            $folders
        );

        return $folders;
    }

    /**
     * Recursively scan upload folders and build folder hierarchy.
     *
     * @param string $dir           Absolute directory path.
     * @param string $relative_path Relative folder path.
     * @param string $parent        Parent folder path.
     * @param array  $folders       List of scanned folders.
     *
     * @return void
     */
    public function scanUploadsFoldersRecursive($dir, $relative_path, $parent, &$folders)
    {
        $excluded = $this->getExcludedUploadFolders();

        $folders[$relative_path] = array(
            'name'   => basename($relative_path),
            'path'   => $relative_path,
            'parent' => $parent,
        );

        $items = scandir($dir);

        if (empty($items)) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' ||
                $item === '..'
            ) {
                continue;
            }

            if (in_array(
                strtolower($item),
                $excluded,
                true
            )
            ) {
                continue;
            }

            $full_path = $dir . '/' . $item;

            if (!is_dir($full_path)) {
                continue;
            }

            $child_relative_path =
                $relative_path . '/' . $item;

            $this->scanUploadsFoldersRecursive(
                $full_path,
                $child_relative_path,
                $relative_path,
                $folders
            );
        }
    }

    /**
     * Excluded folders
     *
     * @return array
     */
    public function getExcludedUploadFolders()
    {
        return array(
            '_pda',
            'acymailing',
            'am_assets',
            'astra-sites',
            'author image',
            'avatars',
            'backupbuddy_backups',
            'backupbuddy_temp',
            'backwpup-restore',
            'backwpup-db7fac-backups',
            'backwpup-db7fac-logs',
            'backwpup-db7fac-temp',
            'bb-plugin',
            'bb-theme',
            'beaver-builder-plugin',
            'bpfb',
            'brizy',
            'buddypress',
            'cache',
            'code-profiler',
            'copysafe-pdf',
            'dynamic_avia',
            'edd',
            'elementor',
            'essential-addons-elementor',
            'et_temp',
            'events-manager',
            'fusionredux',
            'fusion-styles',
            'fusion-scripts',
            'fw-backup',
            'galleries',
            'gppro',
            'gravity_forms',
            'grid-gallery',
            'group-avatars',
            'group-documents',
            'h5p',
            'html_to_wp',
            'hummingbird-assets',
            'imagecleanup',
            'importwp',
            'ithemes-security',
            'iw-backup',
            'js_composer',
            'magictoolbox_cache',
            'mailster',
            'mailpoet',
            'mailpoet-premium',
            'maxbuttons',
            'maxbuttons-pro',
            'maxgalleria-export',
            'mg-backup',
            'mlfp_exim_files',
            'nginx-helper',
            'ninja-forms',
            'pb_backupbuddy',
            'planso-forms',
            'pluginbuddy_mobile',
            'photo-gallery',
            'protected-content',
            'pum',
            'redux',
            'revslider',
            'simple-responsive-slider',
            'siteorigin-widgets',
            'smack_uci_uploads',
            'smile_fonts',
            'so-css',
            'sucuri',
            'supsystic-tables',
            'ShortpixelBackups',
            'themify',
            'themify-css',
            'theplus-addons',
            'tractor-insightcore01',
            'ultimatemember',
            'ultimate-tinymce',
            'wc-logs',
            'wf-woocommerce-packing-list',
            'winp-css-js',
            'woocommerce_uploads',
            'woo-feed',
            'wordpress-popular-posts',
            'wpallimport',
            'wpallexport',
            'wpcf7_captcha',
            'wpcf7_uploads',
            'wpmc-trash',
            'wpdiscuz',
            'wpp-custom-code',
            'wpseo-redirects',
            'wp-clone',
            'wp-forms',
            'wp-google-maps',
            'wp-post-to-pdf-cache',
            'wp-file-manager-pro',
            'wp-migrate-db',
            'wp-pagebuilder',
            'wp2static',
            'wp-statistics',
            'wp-sync-db',
            'wysija',
            'xlplugins',
            'yellow-pencil',
            'yikes-log',
            'Yoast-SEO-Facebook',
        );
    }
}
