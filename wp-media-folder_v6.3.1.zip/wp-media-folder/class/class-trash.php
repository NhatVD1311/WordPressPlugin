<?php
/**
 * Handle Trash system for WP Media Folder
 *
 * @package WP Media Folder
 */

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

/**
 * Class WpmfTrash
 *
 * Handle Trash system for WP Media Folder.
 *
 * This class intercepts delete actions on media files and moves them
 * to a virtual Trash instead of deleting permanently. It supports both
 * local and cloud files by combining taxonomy-based folder handling
 * with meta-based trash flags.
 *
 * Features:
 * - Move files to Trash instead of permanent deletion
 * - Support bulk delete interception
 * - Handle both local and cloud media files
 * - Integrate with WP Media Library queries
 * - Provide auto cleanup via cron (if enabled)
 */
class WpmfTrash
{
    /**
     * Constructor
     *
     * Initialize trash system hooks and schedule cleanup cron.
     *
     * @return void
     */
    public function __construct()
    {
        if (!$this->isEnabled()) {
            return;
        }

        // Core hooks
        add_filter('wpmf_pre_delete_file', [$this, 'handleTrashInsteadDelete'], 10);
        add_filter('pre_delete_attachment', [$this, 'interceptBulkDelete'], 99, 3);

        // i18n
        add_filter('gettext', [__CLASS__, 'filterDeleteText'], 10, 3);

        // Query
        add_filter('ajax_query_attachments_args', [$this, 'excludeTrashFiles']);

        // Cron (future use)
        add_action('wpmf_trash_cleanup', [$this, 'autoDelete']);

        // Init
        $this->scheduleCleanupCron();
    }

    /**
     * Schedule or clear trash cleanup cron
     *
     * @return void
     */
    public function scheduleCleanupCron()
    {
        $enabled = (int) WpmfHelper::wpmfGetOption('trash');
        if ($enabled) {
            if (!wp_next_scheduled('wpmf_trash_cleanup')) {
                wp_schedule_event(time(), 'daily', 'wpmf_trash_cleanup');
            }
        } else {
            wp_clear_scheduled_hook('wpmf_trash_cleanup');
        }
    }

    /**
     * Check if trash feature is enabled
     *
     * @return boolean
     */
    public function isEnabled()
    {
        return (int) WpmfHelper::wpmfGetOption('trash') === 1;
    }

    /**
     * Ensure trash folder exists and return its ID
     *
     * @return integer
     */
    public static function ensureTrashFolder()
    {
        $trash_id = (int) get_option('wpmf_trash_term_id');

        if ($trash_id && term_exists($trash_id, 'wpmf-category')) {
            if ((int) get_term_meta($trash_id, 'wpmf_is_trash', true) === 1) {
                return $trash_id;
            }
        }

        $terms = get_terms(array(
            'taxonomy'   => 'wpmf-category',
            'hide_empty' => false,
            'meta_query' => array(
                array(
                    'key'   => 'wpmf_is_trash',
                    'value' => 1,
                )
            ),
            'number' => 1
        ));

        if (!empty($terms) && !is_wp_error($terms)) {
            $trash_id = $terms[0]->term_id;
            update_option('wpmf_trash_term_id', $trash_id);
            return $trash_id;
        }

        $name = '__wpmf_trash_system';
        $base_slug = 'wpmf-trash-system';
        $slug = $base_slug;
        $i = 1;

        while (term_exists($slug, 'wpmf-category')) {
            $slug = $base_slug . '-' . $i;
            $i++;
        }

        $result = wp_insert_term($name, 'wpmf-category', array(
            'slug'        => $slug,
            'description' => 'System Trash Folder',
            'parent'      => 0
        ));

        if (!is_wp_error($result)) {
            $trash_id = $result['term_id'];

            update_option('wpmf_trash_term_id', $trash_id);
            update_term_meta($trash_id, 'wpmf_is_trash', 1);

            return $trash_id;
        }

        return 0;
    }

   /**
     * Get trash folder ID.
     *
     * @return integer|null Trash folder ID, or null if the trash folder does not exist.
     */
    public static function getTrashFolderId()
    {
        static $trash_ids = array();

        $blog_id = get_current_blog_id();
        if (isset($trash_ids[$blog_id])) {
            return $trash_ids[$blog_id];
        }

        $term = get_terms([
            'taxonomy' => WPMF_TAXO,
            'hide_empty' => false,
            'name' => '__wpmf_trash_system',
            'number' => 1
        ]);

        if (!empty($term) && !is_wp_error($term)) {
            $trash_ids[$blog_id] = (int) $term[0]->term_id;
            return $trash_ids[$blog_id];
        }

        return null;
    }

    /**
     * Intercept delete action:
     * - Move to trash if file is not in trash
     * - Delete permanently if already in trash
     *
     * @param boolean $continue Continue default delete process
     *
     * @return boolean|void
     */
    public function handleTrashInsteadDelete($continue = true)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- No action, nonce is not required
        if (empty($_POST['id']) && empty($_POST['ids'])) {
            return $continue;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- No action, nonce is not required
        if (!empty($_POST['force_delete'])) {
            return $continue;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- No action, nonce is not required
        $ids = !empty($_POST['ids']) ? $_POST['ids'] : [$_POST['id']];
        $first_id = (int) $ids[0];

        $cloud_type = WpmfHelper::wpmfGetCloudFileType($first_id);

        /**
         * =========================
         * CLOUD FILE
         * =========================
         */
        if ($cloud_type !== 'local') {
            foreach ($ids as $attachment_id) {
                $attachment_id = (int) $attachment_id;

                if (get_post_meta($attachment_id, '_wpmf_trash', true)) {
                    remove_filter('wpmf_pre_delete_file', [$this, 'handleTrashInsteadDelete'], 10);
                    wp_delete_attachment($attachment_id, true);
                    continue;
                }

                $terms = wp_get_object_terms($attachment_id, WPMF_TAXO, ['fields' => 'ids']);

                if (!empty($terms)) {
                    update_post_meta($attachment_id, '_wpmf_original_folder', $terms[0]);
                }

                // move to trash (meta)
                update_post_meta($attachment_id, '_wpmf_trash', 1);
                update_post_meta($attachment_id, '_wpmf_trash_time', time());

                $trash_id = $this->getTrashFolderId();
                wp_set_object_terms($attachment_id, $trash_id, WPMF_TAXO, false);
            }

            wp_send_json([
                'status' => true,
                'action' => 'moved_to_trash'
            ]);
        }

        /**
         * =========================
         * LOCAL FILE
         * =========================
         */

        $trash_id = $this->getTrashFolderId();
        $terms = wp_get_object_terms($first_id, WPMF_TAXO, ['fields' => 'ids']);
        $is_in_trash = in_array($trash_id, $terms);

        if ($is_in_trash) {
            remove_filter('wpmf_pre_delete_file', [$this, 'handleTrashInsteadDelete'], 10);

            foreach ($ids as $attachment_id) {
                wp_delete_attachment((int) $attachment_id, true);
            }

            wp_send_json([
                'status' => true,
                'action' => 'deleted_permanently'
            ]);
        }

        foreach ($ids as $attachment_id) {
            $attachment_id = (int) $attachment_id;

            $terms = wp_get_object_terms($attachment_id, WPMF_TAXO, ['fields' => 'ids']);

            if (!empty($terms)) {
                update_post_meta($attachment_id, '_wpmf_original_folder', $terms[0]);
            }

            update_post_meta($attachment_id, '_wpmf_trash', 1);
            update_post_meta($attachment_id, '_wpmf_trash_time', time());

            wp_set_object_terms($attachment_id, $trash_id, WPMF_TAXO, false);

            do_action('wpmf_attachment_set_folder', $attachment_id, $trash_id, [
                'trigger' => 'trash_attachment'
            ]);

            update_post_meta($attachment_id, 'wpmf_order', 0);
        }

        wp_send_json([
            'status' => true,
            'action' => 'moved_to_trash',
            'trash_id' => $trash_id
        ]);

        return false;
    }

   /**
     * Intercept bulk delete and move attachments to Trash.
     *
     * @param boolean  $delete       Whether to delete.
     * @param \WP_Post $post         Attachment post object.
     * @param boolean  $force_delete Force permanent delete.
     *
     * @return boolean|\WP_Post
     */
    public function interceptBulkDelete($delete, $post, $force_delete)
    {
        if ($post->post_type !== 'attachment') {
            return $delete;
        }

        if ($force_delete) {
            return $delete;
        }

        $trash_id = $this->getTrashFolderId();
        if (!$trash_id) {
            return $delete;
        }

        $attachment_id = (int) $post->ID;

        // in trash → delete permanently
        $terms = wp_get_object_terms($attachment_id, WPMF_TAXO, ['fields' => 'ids']);
        if (in_array($trash_id, $terms)) {
            return $delete;
        }

        if (!empty($terms)) {
            update_post_meta($attachment_id, '_wpmf_original_folder', $terms[0]);
            update_post_meta($attachment_id, '_wpmf_trash', 1);
            update_post_meta($attachment_id, '_wpmf_trash_time', time());
        }

        // move to trash
        wp_set_object_terms($attachment_id, $trash_id, WPMF_TAXO, false);

        do_action('wpmf_attachment_set_folder', $attachment_id, $trash_id, [
            'trigger' => 'bulk_trash_attachment'
        ]);

        update_post_meta($attachment_id, 'wpmf_order', 0);

        return $post;
    }

    /**
     * Filter delete button text when trash is enabled
     *
     * @param string $translated_text Translated text
     * @param string $text            Original text
     * @param string $domain          Text domain
     *
     * @return string
     */
    public static function filterDeleteText($translated_text, $text, $domain)
    {
        if (strtolower($text) === 'delete permanently' || strtolower($text) === 'permanently delete') {
            return __('Delete', 'wpmf');
        }

        return $translated_text;
    }

    /**
     * Exclude trash files from media queries
     *
     * @param array $args WP_Query args
     *
     * @return array
     */
    public function excludeTrashFiles($args)
    {
        $trash_id = $this->getTrashFolderId();

        if (!$trash_id) {
            return $args;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- No action, nonce is not required
        $current_folder = isset($_REQUEST['query']['term_id']) ? (int) $_REQUEST['query']['term_id'] : 0;
        /**
         * =========================
         * VIEW TRASH
         * =========================
         */
        if ($current_folder === $trash_id) {
            if (!isset($args['meta_query'])) {
                $args['meta_query'] = [];
            }

            $args['meta_query'][] = [
                'relation' => 'OR',
                [
                    'key'     => '_wpmf_trash',
                    'compare' => 'EXISTS',
                ],
            ];

            return $args;
        }

        /**
         * =========================
         * NORMAL FOLDER
         * =========================
         */

        if (!isset($args['meta_query'])) {
            $args['meta_query'] = [];
        }

        $args['meta_query'][] = [
            'relation' => 'OR',
            [
                'key'     => '_wpmf_trash',
                'compare' => 'NOT EXISTS',
            ],
            [
                'key'     => '_wpmf_trash',
                'value'   => 0,
                'compare' => '='
            ],
        ];

        return $args;
    }

    /**
     * Automatically delete expired files in trash
     *
     * @return void
     */
    public function autoDelete()
    {
        $trash_id = $this->getTrashFolderId();
        if (!$trash_id) {
            return;
        }

        $days = (int) WpmfHelper::wpmfGetOption('trash_days', 30);
        if ($days <= 0) {
            return;
        }

        $expire_time = time() - ($days * DAY_IN_SECONDS);

        $args = [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'tax_query'      => [
                [
                    'taxonomy' => WPMF_TAXO,
                    'field'    => 'term_id',
                    'terms'    => $trash_id,
                ],
            ],
            'meta_query' => [
                [
                    'key'     => '_wpmf_trash_time',
                    'compare' => 'EXISTS',
                ],
            ],
            'fields' => 'ids'
        ];

        $attachments = get_posts($args);

        if (empty($attachments)) {
            return;
        }

        foreach ($attachments as $attachment_id) {
            $trash_time = (int) get_post_meta($attachment_id, '_wpmf_trash_time', true);

            if ($trash_time && $trash_time < $expire_time) {
                wp_delete_attachment($attachment_id, true);
            }
        }
    }
}
