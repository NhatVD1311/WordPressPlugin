<?php
/**
 * Global wrapper functions for WP Media Folder.
 *
 * These functions provide a public API and ensure backward
 * compatibility with legacy themes and addons.
 *
 * @package WP_Media_Folder
 */

defined('ABSPATH') || exit;

if (!function_exists('wpmfGetSizeFiletype')) {
    /**
     * Backward compatibility wrapper for themes and addons.
     *
     * @param integer $pid Attachment ID.
     *
     * @return array File information
     */
    function wpmfGetSizeFiletype($pid)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetSizeFiletype($pid);
    }
}

if (!function_exists('wpmfSetOption')) {
    /**
     * Backward compatibility wrapper for setting WPMF options.
     *
     * @param string $option_name Option key.
     * @param mixed  $value       Option value.
     *
     * @return boolean True if the option was updated, false otherwise.
     */
    function wpmfSetOption($option_name, $value)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfSetOption($option_name, $value);
    }
}

if (!function_exists('wpmfGetOption')) {
    /**
     * Wrapper for backward compatibility.
     *
     * @param string $option_name Option name.
     *
     * @return mixed Option value or null if not found.
     */
    function wpmfGetOption($option_name)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetOption($option_name);
    }
}

if (!function_exists('wpmfGetMainClass')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @return mixed|\WpMediaFolder Main plugin instance.
     */
    function wpmfGetMainClass()
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetMainClass();
    }
}

if (!function_exists('wpmfGetCloudFolderID')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param string|integer $folder_id Folder identifier.
     *
     * @return mixed|false Cloud folder ID on success, false otherwise.
     */
    function wpmfGetCloudFolderID($folder_id)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetCloudFolderID($folder_id);
    }
}

if (!function_exists('wpmfGetCloudFolderType')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param string|integer $folder_id Folder identifier.
     *
     * @return mixed|false Cloud folder type on success, false otherwise.
     */
    function wpmfGetCloudFolderType($folder_id)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetCloudFolderType($folder_id);
    }
}

if (!function_exists('wpmfGetCloudFileID')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param string|integer $file_id File identifier.
     *
     * @return mixed|false Cloud file ID on success, false otherwise.
     */
    function wpmfGetCloudFileID($file_id)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetCloudFileID($file_id);
    }
}

if (!function_exists('wpmfGetCloudFileType')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param string|integer $file_id File identifier.
     *
     * @return mixed|false Cloud file type on success, false otherwise.
     */
    function wpmfGetCloudFileType($file_id)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetCloudFileType($file_id);
    }
}

if (!function_exists('getIptcHeader')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @return array IPTC header configuration.
     */
    function getIptcHeader()
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::getIptcHeader();
    }
}

if (!function_exists('wpmfRenderVideoIcon')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param integer $attachment_id Attachment ID.
     *
     * @return string HTML markup for the video icon.
     */
    function wpmfRenderVideoIcon($attachment_id)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfRenderVideoIcon($attachment_id);
    }
}

if (!function_exists('wpmfAddToQueue')) {
    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param array   $datas        Queue data.
     * @param array   $responses    Optional. Queue responses.
     * @param boolean $check_status Optional. Whether to check queue status.
     *
     * @return void
     */
    function wpmfAddToQueue($datas = array(), $responses = array(), $check_status = false)
    {
        \Joomunited\WPMediaFolder\WpmfHelper::wpmfAddToQueue($datas, $responses, $check_status);
    }
}

if (!function_exists('wpmfCustomNumberFormat')) {

    /**
     * Wrapper for backward compatibility with legacy themes and addons.
     *
     * @param integer $number The number to format.
     *
     * @return string Formatted number.
     */
    function wpmfCustomNumberFormat($number)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfCustomNumberFormat($number);
    }
}

if (!function_exists('wpmfGetQueueOptions')) {
    /**
     * Retrieve WP Media Folder queue options.
     *
     * @param boolean $cron Optional. Whether the function is called via a cron job.
     *                   Default false.
     *
     * @return array Queue options.
     */
    function wpmfGetQueueOptions($cron = false)
    {
        return \Joomunited\WPMediaFolder\WpmfHelper::wpmfGetQueueOptions($cron);
    }
}
