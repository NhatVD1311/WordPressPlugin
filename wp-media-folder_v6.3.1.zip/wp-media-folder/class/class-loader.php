<?php
/**
 * Plugin core loader
 *
 * @package WP Media Folder
 */

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

/**
 * Class responsible for loading and initializing all core
 * components of the WP Media Folder plugin.
 *
 * This loader conditionally includes and instantiates plugin
 * modules based on the plugin settings and the current
 * WordPress execution context (admin or frontend).
 */
class WpmfLoader
{
    /**
     * Initialize core plugin components
     *
     * @return void
     */
    public static function initModules()
    {
        $frontend = get_option('wpmf_option_mediafolder');

        if (!empty($frontend) || is_admin()) {
            global $wpmfwatermark;
            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-main.php');
            $GLOBALS['wp_media_folder'] = new \WpMediaFolder;
            $useorder                   = get_option('wpmf_useorder');
            // todo : should this really be always loaded on each wp request?
            // todo : should we not loaded
            if (isset($useorder) && (int) $useorder === 1) {
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-orderby-media.php');
                new \WpmfOrderbyMedia;
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-filter-size.php');
                new \WpmfFilterSize;
            }

            $option_duplicate = get_option('wpmf_option_duplicate');
            if (isset($option_duplicate) && (int) $option_duplicate === 1) {
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-duplicate-file.php');
                new \WpmfDuplicateFile;
            }

            $wpmf_media_rename = get_option('wpmf_media_rename');
            if (isset($wpmf_media_rename) && (int) $wpmf_media_rename === 1) {
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-media-rename.php');
                new \WpmfMediaRename;
            }

            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-image-watermark.php');
            $wpmfwatermark = new \WpmfWatermark();

            $option_override = get_option('wpmf_option_override');
            if (isset($option_override) && (int) $option_override === 1) {
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-replace-file.php');
                new \WpmfReplaceFile;
            }

            $settings = get_option('wpmf_settings');
            if (isset($settings) && isset($settings['auto_generate_webp']) && $settings['auto_generate_webp']) {
                require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-generate-webp-file.php';
                new \WpmfGenerateWebpFile();
            }
        }

        $active_media = get_option('wpmf_active_media');
        if (isset($active_media) && (int) $active_media === 1) {
            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-folder-access.php');
            new \WpmfFolderAccess;
        }

        $enable_gallery = get_option('wpmf_usegellery');
        if (isset($enable_gallery) && (int) $enable_gallery === 1) {
            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-display-gallery.php');
            new \WpmfDisplayGallery;
        }

        if (is_admin()) {
            add_action('init', function () {
                require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-wp-folder-option.php');
                new \WpmfMediaFolderOption;
            });
        }

        $wpmf_option_singlefile = get_option('wpmf_option_singlefile');
        if (isset($wpmf_option_singlefile) && (int) $wpmf_option_singlefile === 1) {
            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-single-file.php');
            new \WpmfSingleFile();
        }

        $wpmf_option_lightboximage = get_option('wpmf_option_lightboximage');
        if (isset($wpmf_option_lightboximage) && (int) $wpmf_option_lightboximage === 1) {
            require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-single-lightbox.php');
            new \WpmfSingleLightbox;
        }

        require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-image-optimization.php';
        new \Joomunited\WPMediaFolder\WpmfImageOptimization();

        require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-pdf-embed.php');
        new \WpmfPdfEmbed();

        require_once(WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-folder-post-type.php');
        new \WpmfMediaFolderPostType();

        require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-trash.php';
        new \Joomunited\WPMediaFolder\WpmfTrash();
    }
}
