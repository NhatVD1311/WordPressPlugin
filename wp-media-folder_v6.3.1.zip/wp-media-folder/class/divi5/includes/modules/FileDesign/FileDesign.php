<?php
/**
 * Module: WPMF File Design (Media Download) for Divi 5.
 *
 * @package WPMF\Divi5\Modules\FileDesign
 */

namespace WPMF\Divi5\Modules\FileDesign;

if (!defined('ABSPATH')) {
    exit;
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Divi 5 File Design module dependency loader.
 */
class FileDesign implements DependencyInterface
{
    /**
     * Register the Divi 5 File Design module.
     *
     * @return void
     */
    public function load()
    {
        $module_path = WPMF_DIVI5_MODULES_JSON_PATH . 'file-design/';

        ModuleRegistration::register_module(
            $module_path,
            ['render_callback' => [self::class, 'render_callback']]
        );
    }

    /**
     * Generate classnames for the module.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_classnames(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $classnames_instance = $args['classnamesInstance'];
        $attrs               = $args['attrs'];

        $classnames_instance->add(
            \ET\Builder\Packages\Module\Options\Element\ElementClassnames::classnames([
                'attrs' => array_merge(
                    $attrs['module']['decoration'] ?? [],
                    [
                        'link' => $attrs['module']['advanced']['link'] ?? [],
                    ]
                ),
            ])
        );
    }

    /**
     * Load Module style components.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_styles(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $elements = $args['elements'];

        \ET\Builder\FrontEnd\Module\Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => [
                $elements->style([
                    'attrName' => 'module',
                ]),
            ],
        ]);
    }

    /**
     * Render callback for the WPMF Media Download module.
     * Mirrors Divi 4: [wpmffiledesign url="..." align="..."]
     *
     * @param array       $attrs    Module attributes.
     * @param string|null $content  Module content.
     * @param object      $block    Parsed block instance.
     * @param array       $elements Render elements.
     *
     * @return string
     */
    public static function render_callback($attrs, $content, $block, $elements) // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $module_data = $attrs['module']['innerContent']['desktop']['value'] ?? [];

        $url   = $module_data['url']   ?? '';
        $align = $module_data['align'] ?? 'left';

        if (empty($url)) {
            return '<div class="wpmf-divi-container">'
                . '<div id="divi-file-design-placeholder" class="divi-file-design-placeholder">'
                . '<span class="wpmf-divi-message">'
                . esc_html__('WP Media Folder media download. Select a media and transform it into a download button', 'wpmf')
                . '</span></div></div>';
        }

        $output = do_shortcode('[wpmffiledesign url="' . esc_attr($url) . '" align="' . esc_attr($align) . '"]');

        $use_divi_render = isset($block->parsed_block['id']) && !empty($block->parsed_block['id']);

        if (!$use_divi_render) {
            return '<div class="wpmf_file_design et_pb_module wpmf-d5-module">' . $output . '</div>';
        }

        $parent       = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
        $parent_attrs = $parent->attrs ?? [];

        return \ET\Builder\Packages\Module\Module::render([
            'orderIndex'     => $block->parsed_block['orderIndex'],
            'storeInstance'  => $block->parsed_block['storeInstance'],
            'id'             => $block->parsed_block['id'],
            'name'           => $block->block_type->name,
            'moduleCategory' => $block->block_type->category,
            'attrs'          => $attrs,
            'elements'       => $elements,
            'classnamesFunction'  => [self::class, 'module_classnames'],
            'stylesComponent'     => [self::class, 'module_styles'],
            'parentAttrs'    => $parent_attrs,
            'parentId'       => $parent->id ?? '',
            'parentName'     => $parent->blockName ?? '',
            'children'       => [
                $elements->style_components([
                    'attrName' => 'module',
                ]) . \ET\Builder\Framework\Utility\HTMLUtility::render([
                    'tag'               => 'div',
                    'attributes'        => ['class' => 'wpmf-d5-module-inner'],
                    'childrenSanitizer' => 'et_core_esc_previously',
                    'children'          => $output,
                ]),
            ],
        ]);
    }
}
