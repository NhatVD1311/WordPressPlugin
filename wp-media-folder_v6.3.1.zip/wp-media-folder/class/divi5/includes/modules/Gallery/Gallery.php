<?php
/**
 * Module: WPMF Gallery for Divi 5.
 *
 * @package WPMF\Divi5\Modules\Gallery
 */

namespace WPMF\Divi5\Modules\Gallery;

if (!defined('ABSPATH')) {
    exit;
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Divi 5 Gallery module dependency loader.
 */
class Gallery implements DependencyInterface
{
    /**
     * Register the Divi 5 Gallery module.
     *
     * @return void
     */
    public function load()
    {
        $module_path = WPMF_DIVI5_MODULES_JSON_PATH . 'gallery/';

        ModuleRegistration::register_module(
            $module_path,
            ['render_callback' => [self::class, 'render_callback']]
        );
    }

    /**
     * Generate classnames for the module.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_classnames(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $classnames_instance = $args['classnamesInstance'];
        $attrs               = $args['attrs'];

        $classnames_instance->add(
            \ET\Builder\Packages\Module\Options\Element\ElementClassnames::classnames([
                'attrs' => array_merge(
                    $attrs['module']['decoration'] ?? [],
                    [
                        'link' => $attrs['module']['advanced']['link'] ?? [],
                    ]
                ),
            ])
        );
    }

    /**
     * Load Module style components.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_styles(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $elements = $args['elements'];

        \ET\Builder\FrontEnd\Module\Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => [
                $elements->style([
                    'attrName' => 'module',
                ]),
            ],
        ]);
    }

    /**
     * Render callback for the WPMF Gallery module.
     *
     * @param array       $attrs    Module attributes.
     * @param string|null $content  Module content.
     * @param object      $block    Parsed block instance.
     * @param array       $elements Render elements.
     *
     * @return string
     */
    public static function render_callback($attrs, $content, $block, $elements) // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $module_data = $attrs['module']['innerContent']['desktop']['value'] ?? [];

        $theme          = $module_data['theme']          ?? 'default';
        $columns        = $module_data['columns']        ?? 3;
        $size           = $module_data['size']           ?? 'medium';
        $targetsize     = $module_data['targetsize']     ?? 'large';
        $orderby        = $module_data['orderby']        ?? 'post__in';
        $order          = $module_data['order']          ?? 'ASC';
        $action         = $module_data['action']         ?? 'file';
        $gutterwidth    = $module_data['gutterwidth']    ?? 5;
        $border_radius  = $module_data['borderRadius']  ?? 0;
        $border_style   = $module_data['borderStyle']   ?? 'solid';
        $border_width   = $module_data['borderWidth']   ?? 0;
        $border_color   = $module_data['borderColor']   ?? '#cccccc';
        $enable_shadow  = $module_data['enableShadow']  ?? 'off';
        $gallery_folders = $module_data['galleryFolders'] ?? 'off';
        $gallery_folder_id = $module_data['galleryFolderId'] ?? 0;
        $aspect_ratio   = $module_data['aspectRatio']   ?? '1_1';

        // Image IDs come from the images.advanced.galleryIds attribute
        // (populated by the divi/upload-gallery component in the VB).
        $items = trim($attrs['images']['advanced']['galleryIds']['desktop']['value'] ?? '');
        // Legacy fallback for any blocks saved before the upload-gallery migration.
        if ($items === '') {
            $items = $module_data['items'] ?? '';
        }

        $gallery_folders_val = ($gallery_folders === 'on') ? 1 : 0;

        $img_shadow = '';
        if ($enable_shadow === 'on') {
            $shadow_h       = $module_data['shadowHorizontal'] ?? '0px';
            $shadow_v       = $module_data['shadowVertical']   ?? '0px';
            $shadow_blur    = $module_data['shadowBlur']       ?? '0px';
            $shadow_spread  = $module_data['shadowSpread']     ?? '0px';
            $shadow_color   = $module_data['shadowColor']      ?? '#cccccc';
            $img_shadow = $shadow_h . ' ' . $shadow_v . ' ' . $shadow_blur . ' ' . $shadow_spread . ' ' . $shadow_color;
        }

        if (empty($items) && empty($gallery_folder_id)) {
            return '<div class="wpmf-divi-container"><div class="divi-gallery-placeholder"><span class="wpmf-divi-message">'
                . esc_html__('Please add some images to the gallery', 'wpmf')
                . '</span></div></div>';
        }

        $output = do_shortcode('[wpmf_gallery is_divi="1"'
            . ' include="' . esc_attr($items) . '"'
            . ' display="' . esc_attr($theme) . '"'
            . ' columns="' . esc_attr($columns) . '"'
            . ' size="' . esc_attr($size) . '"'
            . ' targetsize="' . esc_attr($targetsize) . '"'
            . ' link="' . esc_attr($action) . '"'
            . ' wpmf_orderby="' . esc_attr($orderby) . '"'
            . ' wpmf_order="' . esc_attr($order) . '"'
            . ' gutterwidth="' . esc_attr($gutterwidth) . '"'
            . ' border_width="' . esc_attr($border_width) . '"'
            . ' border_style="' . esc_attr($border_style) . '"'
            . ' border_color="' . esc_attr($border_color) . '"'
            . ' img_shadow="' . esc_attr($img_shadow) . '"'
            . ' img_border_radius="' . esc_attr($border_radius) . '"'
            . ' wpmf_autoinsert="' . esc_attr($gallery_folders_val) . '"'
            . ' wpmf_folder_id="' . esc_attr($gallery_folder_id) . '"'
            . ' aspect_ratio="' . esc_attr($aspect_ratio) . '"'
            . ']');

        $use_divi_render = isset($block->parsed_block['id']) && !empty($block->parsed_block['id']);

        if (!$use_divi_render) {
            return '<div class="wpmf_gallery_divi et_pb_module wpmf-d5-module">' . $output . '</div>';
        }

        $parent       = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
        $parent_attrs = $parent->attrs ?? [];

        return \ET\Builder\Packages\Module\Module::render([
            'orderIndex'     => $block->parsed_block['orderIndex'],
            'storeInstance'  => $block->parsed_block['storeInstance'],
            'id'             => $block->parsed_block['id'],
            'name'           => $block->block_type->name,
            'moduleCategory' => $block->block_type->category,
            'attrs'          => $attrs,
            'elements'       => $elements,
            'classnamesFunction'  => [self::class, 'module_classnames'],
            'stylesComponent'     => [self::class, 'module_styles'],
            'parentAttrs'    => $parent_attrs,
            'parentId'       => $parent->id ?? '',
            'parentName'     => $parent->blockName ?? '',
            'children'       => [
                $elements->style_components([
                    'attrName' => 'module',
                ]) . \ET\Builder\Framework\Utility\HTMLUtility::render([
                    'tag'               => 'div',
                    'attributes'        => ['class' => 'wpmf-d5-module-inner'],
                    'childrenSanitizer' => 'et_core_esc_previously',
                    'children'          => $output,
                ]),
            ],
        ]);
    }
}
