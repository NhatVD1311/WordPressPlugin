<?php
/**
 * Register all Divi 5 modules with dependency tree.
 *
 * NOTE: This file is loaded at after_setup_theme time, BEFORE Divi 5's
 * autoloader has initialized. Do NOT require module PHP files here.
 * Module files are lazy-loaded inside the callback which runs when
 * all Divi 5 classes are available.
 *
 * @package WPMF\Divi5\Modules
 */

namespace WPMF\Divi5\Modules;

use WPMF\Divi5\Modules\Gallery\Gallery;
use WPMF\Divi5\Modules\GalleryAddon\GalleryAddon;
use WPMF\Divi5\Modules\FileDesign\FileDesign;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register WPMF Divi 5 module dependencies.
 *
 * Divi's D5 Readiness plugin check attributes compatibility by reflecting
 * named callbacks attached to D5 hooks. Keep this callback named so the
 * checker can associate WP Media Folder with its Divi 5 integration.
 *
 * @param object $dependency_tree Divi dependency tree.
 *
 * @return void
 */
function registerModules($dependency_tree)
{
    // Now it's safe to load D5 module classes (autoloader is ready).
    require_once __DIR__ . '/Gallery/Gallery.php';
    require_once __DIR__ . '/GalleryAddon/GalleryAddon.php';
    require_once __DIR__ . '/PdfEmbed/PdfEmbed.php';

    $dependency_tree->add_dependency(
        new \WPMF\Divi5\Modules\Gallery\Gallery()
    );
    $dependency_tree->add_dependency(
        new \WPMF\Divi5\Modules\GalleryAddon\GalleryAddon()
    );
    $dependency_tree->add_dependency(
        new \WPMF\Divi5\Modules\PdfEmbed\PdfEmbed()
    );

    // FileDesign (Media Download) is only registered when the
    // wpmf_option_singlefile plugin option is enabled.
    $enable_singlefile = get_option('wpmf_option_singlefile');
    if (isset($enable_singlefile) && (int) $enable_singlefile === 1) {
        require_once __DIR__ . '/FileDesign/FileDesign.php';
        $dependency_tree->add_dependency(
            new \WPMF\Divi5\Modules\FileDesign\FileDesign()
        );
    }
}
add_action('divi_module_library_modules_dependency_tree', __NAMESPACE__ . '\\registerModules');
