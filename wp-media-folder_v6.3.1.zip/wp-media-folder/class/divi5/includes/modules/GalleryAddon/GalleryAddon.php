<?php
/**
 * GalleryAddon module for Divi 5.
 *
 * @package WPMF\Divi5\Modules\GalleryAddon
 */

namespace WPMF\Divi5\Modules\GalleryAddon;

if (!defined('ABSPATH')) {
    exit;
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Divi 5 GalleryAddon module dependency loader.
 */
class GalleryAddon implements DependencyInterface
{
    /**
     * Collected frontend styles that must be printed after Divi renders the page.
     *
     * @var array<int, string>
     */
    private static $frontend_inline_css = [];

    /**
     * Whether the footer printer hook has been registered.
     *
     * @var boolean
     */
    private static $footer_hook_registered = false;

    /**
     * Extract a scalar field value from a Divi 5 field payload.
     *
     * Divi controls such as range/color-picker may serialize to nested arrays
     * instead of plain strings, so shortcode building needs to unwrap them.
     *
     * @param mixed  $value    Raw field value.
     * @param string $fallback Fallback value.
     *
     * @return string
     */
    private static function normalize_field_value($value, string $fallback = ''): string
    {
        if ($value === null) {
            return $fallback;
        }

        if (is_bool($value)) {
            return $value ? 'on' : 'off';
        }

        if (is_scalar($value)) {
            return trim((string) $value);
        }

        if (is_object($value)) {
            $value = (array) $value;
        }

        if (is_array($value)) {
            foreach (['value', 'desktop', 'hex', 'color', 'rgb', 'raw', 'size', 'amount'] as $key) {
                if (array_key_exists($key, $value)) {
                    return self::normalize_field_value($value[$key], $fallback);
                }
            }

            if (count($value) === 1) {
                return self::normalize_field_value(reset($value), $fallback);
            }
        }

        return $fallback;
    }

    /**
     * Normalize a numeric field value from Divi.
     *
     * @param mixed  $value    Raw field value.
     * @param string $fallback Fallback value.
     *
     * @return string
     */
    private static function normalize_number($value, string $fallback): string
    {
        $normalized = self::normalize_field_value($value, $fallback);
        if ($normalized === '') {
            return $fallback;
        }

        if (is_numeric($normalized)) {
            return (string) $normalized;
        }

        if (preg_match('/-?\d+(?:\.\d+)?/', $normalized, $matches)) {
            return $matches[0];
        }

        return $fallback;
    }

    /**
     * Normalize CSS color values from Divi controls.
     *
     * @param mixed  $value    Raw field value.
     * @param string $fallback Fallback color.
     *
     * @return string
     */
    private static function normalize_color($value, string $fallback): string
    {
        $normalized = self::normalize_field_value($value, $fallback);
        if ($normalized === '') {
            return $fallback;
        }

        $normalized = trim($normalized);
        if (preg_match('/^[0-9a-fA-F]{3,4}([0-9a-fA-F]{3,4})?$/', $normalized)) {
            return '#' . $normalized;
        }

        return $normalized;
    }

    /**
     * Normalize an on/off toggle value.
     *
     * @param mixed  $value    Raw field value.
     * @param string $fallback Fallback value.
     *
     * @return string
     */
    private static function normalize_toggle($value, string $fallback = 'off'): string
    {
        return self::normalize_field_value($value, $fallback) === 'on' ? 'on' : 'off';
    }

    /**
     * Register the Divi 5 GalleryAddon module.
     *
     * @return void
     */
    public function load()
    {
        $module_path = WPMF_DIVI5_MODULES_JSON_PATH . 'gallery-addon/';

        ModuleRegistration::register_module(
            $module_path,
            ['render_callback' => [self::class, 'render_callback']]
        );
    }

    /**
     * Generate classnames for the module.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_classnames(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $classnames_instance = $args['classnamesInstance'];
        $attrs               = $args['attrs'];

        $classnames_instance->add(
            \ET\Builder\Packages\Module\Options\Element\ElementClassnames::classnames([
                'attrs' => array_merge(
                    $attrs['module']['decoration'] ?? [],
                    [
                        'link' => $attrs['module']['advanced']['link'] ?? [],
                    ]
                ),
            ])
        );
    }

    /**
     * Load Module style components.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_styles(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $elements = $args['elements'];

        \ET\Builder\FrontEnd\Module\Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => [
                $elements->style([
                    'attrName' => 'module',
                ]),
            ],
        ]);
    }

    /**
     * Render callback for the WPMF Gallery Addon module.
     *
     * @param array       $attrs    Module attributes.
     * @param string|null $content  Module content.
     * @param object      $block    Parsed block instance.
     * @param array       $elements Render elements.
     *
     * @return string
     */
    public static function render_callback($attrs, $content, $block, $elements) // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $inner = $attrs['module']['innerContent']['desktop']['value'] ?? [];
        $defaults = function_exists('wpmfGetDivi5GalleryAddonDefaults') ? wpmfGetDivi5GalleryAddonDefaults() : [];

        $gallery_id_raw      = self::normalize_field_value($inner['galleryId'] ?? ($defaults['galleryId'] ?? '0'), '0');
        $theme               = self::normalize_field_value($inner['theme'] ?? ($defaults['theme'] ?? 'masonry'), 'masonry');
        $layout              = self::normalize_field_value($inner['layout'] ?? ($defaults['layout'] ?? 'vertical'), 'vertical');
        $row_height          = self::normalize_number($inner['rowHeight'] ?? ($defaults['rowHeight'] ?? '200'), '200');
        $aspect_ratio        = self::normalize_field_value($inner['aspectRatio'] ?? ($defaults['aspectRatio'] ?? '1_1'), '1_1');
        $columns             = self::normalize_number($inner['columns'] ?? ($defaults['columns'] ?? '3'), '3');
        $number_lines        = self::normalize_number($inner['numberLines'] ?? ($defaults['numberLines'] ?? '1'), '1');
        $size                = self::normalize_field_value($inner['size'] ?? ($defaults['size'] ?? 'medium'), 'medium');
        $targetsize          = self::normalize_field_value($inner['targetsize'] ?? ($defaults['targetsize'] ?? 'large'), 'large');
        $action              = self::normalize_field_value($inner['action'] ?? ($defaults['action'] ?? 'file'), 'file');
        $orderby             = self::normalize_field_value($inner['orderby'] ?? ($defaults['orderby'] ?? 'post__in'), 'post__in');
        $order               = self::normalize_field_value($inner['order'] ?? ($defaults['order'] ?? 'ASC'), 'ASC');
        $gutterwidth         = self::normalize_number($inner['gutterwidth'] ?? ($defaults['gutterwidth'] ?? '5'), '5');
        $gallery_navigation  = self::normalize_toggle($inner['galleryNavigation'] ?? ($defaults['galleryNavigation'] ?? 'off')) === 'on' ? 1 : 0;
        $sub_galleries       = self::normalize_toggle($inner['subGalleriesListing'] ?? ($defaults['subGalleriesListing'] ?? 'off')) === 'on' ? 1 : 0;
        $image_tags          = self::normalize_toggle($inner['galleryImageTags'] ?? ($defaults['galleryImageTags'] ?? 'off')) === 'on' ? 1 : 0;
        $download_all        = self::normalize_toggle($inner['downloadAll'] ?? ($defaults['downloadAll'] ?? 'off')) === 'on' ? 1 : 0;
        $border_radius       = self::normalize_number($inner['borderRadius'] ?? ($defaults['borderRadius'] ?? '0'), '0');
        $border_style        = self::normalize_field_value($inner['borderStyle'] ?? ($defaults['borderStyle'] ?? 'solid'), 'solid');
        $border_width        = self::normalize_number($inner['borderWidth'] ?? ($defaults['borderWidth'] ?? '0'), '0');
        $border_color        = self::normalize_color($inner['borderColor'] ?? ($defaults['borderColor'] ?? '#cccccc'), '#cccccc');
        $enable_shadow       = self::normalize_toggle($inner['enableShadow'] ?? ($defaults['enableShadow'] ?? 'off')) === 'on';
        $shadow_color        = self::normalize_color($inner['shadowColor'] ?? ($defaults['shadowColor'] ?? '#cccccc'), '#cccccc');
        $shadow_horizontal   = self::normalize_number($inner['shadowHorizontal'] ?? ($defaults['shadowHorizontal'] ?? '0'), '0');
        $shadow_vertical     = self::normalize_number($inner['shadowVertical'] ?? ($defaults['shadowVertical'] ?? '0'), '0');
        $shadow_blur         = self::normalize_number($inner['shadowBlur'] ?? ($defaults['shadowBlur'] ?? '0'), '0');
        $shadow_spread       = self::normalize_number($inner['shadowSpread'] ?? ($defaults['shadowSpread'] ?? '0'), '0');
        $disable_overlay     = self::normalize_toggle($inner['disableOverlay'] ?? ($defaults['disableOverlay'] ?? 'off')) === 'on' ? 1 : 0;
        $hover_color         = self::normalize_color($inner['hoverColor'] ?? ($defaults['hoverColor'] ?? '#000000'), '#000000');
        $hover_opacity       = self::normalize_number($inner['hoverOpacity'] ?? ($defaults['hoverOpacity'] ?? '0.4'), '0.4');
        $hover_title_pos     = self::normalize_field_value($inner['hoverTitlePosition'] ?? ($defaults['hoverTitlePosition'] ?? 'center_center'), 'center_center');
        $hover_title_size    = self::normalize_number($inner['hoverTitleSize'] ?? ($defaults['hoverTitleSize'] ?? '16'), '16');
        $hover_title_color   = self::normalize_color($inner['hoverTitleColor'] ?? ($defaults['hoverTitleColor'] ?? '#ffffff'), '#ffffff');
        $hover_desc_pos      = self::normalize_field_value($inner['hoverDescPosition'] ?? ($defaults['hoverDescPosition'] ?? 'none'), 'none');
        $hover_desc_size     = self::normalize_number($inner['hoverDescSize'] ?? ($defaults['hoverDescSize'] ?? '14'), '14');
        $hover_desc_color    = self::normalize_color($inner['hoverDescColor'] ?? ($defaults['hoverDescColor'] ?? '#ffffff'), '#ffffff');

        // Parse gallery_id — Divi 4 stores as "index-termId"
        $gallery_id = $gallery_id_raw;
        if (is_string($gallery_id_raw) && strpos($gallery_id_raw, '-') !== false) {
            $parts      = explode('-', $gallery_id_raw);
            $gallery_id = end($parts);
        }
        $gallery_id = (int) $gallery_id;

        if (empty($gallery_id)) {
            return '<div class="wpmf-divi-container"><div class="divi-gallery-addon-placeholder">'
                . '<span class="wpmf-divi-message">'
                . esc_html__('Please select a gallery to activate the preview', 'wpmf')
                . '</span></div></div>';
        }

        // Build img_shadow string
        $img_shadow = '';
        if ($enable_shadow) {
            $img_shadow = $shadow_horizontal . 'px '
                        . $shadow_vertical . 'px '
                        . $shadow_blur . 'px '
                        . $shadow_spread . 'px '
                        . $shadow_color;
        }

        $output = do_shortcode(
            '[wpmfgallery'
            . ' is_divi="1"'
            . ' gallery_id="' . esc_attr($gallery_id) . '"'
            . ' display="' . esc_attr($theme) . '"'
            . ' layout="' . esc_attr($layout) . '"'
            . ' row_height="' . esc_attr($row_height) . '"'
            . ' aspect_ratio="' . esc_attr($aspect_ratio) . '"'
            . ' columns="' . esc_attr($columns) . '"'
            . ' number_lines="' . esc_attr($number_lines) . '"'
            . ' size="' . esc_attr($size) . '"'
            . ' targetsize="' . esc_attr($targetsize) . '"'
            . ' link="' . esc_attr($action) . '"'
            . ' wpmf_orderby="' . esc_attr($orderby) . '"'
            . ' wpmf_order="' . esc_attr($order) . '"'
            . ' gutterwidth="' . esc_attr($gutterwidth) . '"'
            . ' display_tree="' . esc_attr($gallery_navigation) . '"'
            . ' sub_galleries_listing="' . esc_attr($sub_galleries) . '"'
            . ' display_tag="' . esc_attr($image_tags) . '"'
            . ' download_all="' . esc_attr($download_all) . '"'
            . ' img_border_radius="' . esc_attr($border_radius) . '"'
            . ' border_style="' . esc_attr($border_style) . '"'
            . ' border_width="' . esc_attr($border_width) . '"'
            . ' border_color="' . esc_attr($border_color) . '"'
            . ' img_shadow="' . esc_attr($img_shadow) . '"'
            . ' disable_overlay="' . esc_attr($disable_overlay) . '"'
            . ' hover_color="' . esc_attr($hover_color) . '"'
            . ' hover_opacity="' . esc_attr($hover_opacity) . '"'
            . ' hover_title_position="' . esc_attr($hover_title_pos) . '"'
            . ' hover_title_size="' . esc_attr($hover_title_size) . '"'
            . ' hover_title_color="' . esc_attr($hover_title_color) . '"'
            . ' hover_desc_position="' . esc_attr($hover_desc_pos) . '"'
            . ' hover_desc_size="' . esc_attr($hover_desc_size) . '"'
            . ' hover_desc_color="' . esc_attr($hover_desc_color) . '"'
            . ']'
        );

        $inline_styles = '';
        if (preg_match_all('#<style\b[^>]*>(.*?)</style>#is', $output, $style_matches)) {
            foreach ($style_matches[0] as $style_tag) {
                $inline_styles .= $style_tag;
            }
            $output = preg_replace('#<style\b[^>]*>.*?</style>#is', '', $output);
        }

        if ($inline_styles !== '' && !is_admin()) {
            self::queue_frontend_styles($inline_styles);
        }

        return '<div class="wpmf_gallery_addon_divi et_pb_module wpmf-d5-module">'
            . $inline_styles
            . $output
            . '</div>';
    }

    /**
     * Queue shortcode-generated CSS for footer output on real frontend pages.
     *
     * @param string $style_tags Raw style tags extracted from shortcode output.
     *
     * @return void
     */
    private static function queue_frontend_styles(string $style_tags): void
    {
        if (!preg_match_all('#<style\b[^>]*>(.*?)</style>#is', $style_tags, $style_matches)) {
            return;
        }

        foreach ($style_matches[1] as $css) {
            $css = trim($css);
            if ($css !== '') {
                self::$frontend_inline_css[] = $css;
            }
        }

        if (self::$footer_hook_registered) {
            return;
        }

        self::$footer_hook_registered = true;
        add_action('wp_footer', [self::class, 'print_frontend_styles'], 99);
    }

    /**
     * Print collected frontend styles after Divi/module rendering is complete.
     *
     * @return void
     */
    public static function print_frontend_styles(): void
    {
        if (empty(self::$frontend_inline_css)) {
            return;
        }

        $css = implode("\n", array_unique(self::$frontend_inline_css));
        echo '<style class="wpmf-divi5-gallery-addon-inline">' . $css . '</style>';
    }
}
