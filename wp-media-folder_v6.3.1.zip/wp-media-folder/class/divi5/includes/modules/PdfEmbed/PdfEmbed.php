<?php
/**
 * Module: WPMF PDF Embed for Divi 5.
 *
 * @package WPMF\Divi5\Modules\PdfEmbed
 */

namespace WPMF\Divi5\Modules\PdfEmbed;

if (!defined('ABSPATH')) {
    exit;
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Divi 5 PDF Embed module dependency loader.
 */
class PdfEmbed implements DependencyInterface
{
    /**
     * Register the Divi 5 PDF Embed module.
     *
     * @return void
     */
    public function load()
    {
        $module_path = WPMF_DIVI5_MODULES_JSON_PATH . 'pdf-embed/';

        ModuleRegistration::register_module(
            $module_path,
            ['render_callback' => [self::class, 'render_callback']]
        );
    }

    /**
     * Generate classnames for the module.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_classnames(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $classnames_instance = $args['classnamesInstance'];
        $attrs               = $args['attrs'];

        $classnames_instance->add(
            \ET\Builder\Packages\Module\Options\Element\ElementClassnames::classnames([
                'attrs' => array_merge(
                    $attrs['module']['decoration'] ?? [],
                    [
                        'link' => $attrs['module']['advanced']['link'] ?? [],
                    ]
                ),
            ])
        );
    }

    /**
     * Load Module style components.
     *
     * @param array $args Arguments.
     *
     * @return void
     */
    public static function module_styles(array $args): void // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $elements = $args['elements'];

        \ET\Builder\FrontEnd\Module\Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => [
                $elements->style([
                    'attrName' => 'module',
                ]),
            ],
        ]);
    }

    /**
     * Render callback for the WPMF PDF Embed module.
     *
     * @param array       $attrs    Module attributes.
     * @param string|null $content  Module content.
     * @param object      $block    Parsed block instance.
     * @param array       $elements Render elements.
     *
     * @return string
     */
    public static function render_callback($attrs, $content, $block, $elements) // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps -- Divi module registration expects this callback name
    {
        $module_data = $attrs['module']['innerContent']['desktop']['value'] ?? [];

        $url    = $module_data['url']    ?? '';
        $embed  = $module_data['embed']  ?? 'on';
        $target = $module_data['target'] ?? 'self';
        $width  = $module_data['width']  ?? '100%';
        $height = $module_data['height'] ?? '800';

        if (empty($url)) {
            return '<div class="wpmf-divi-container"><div class="divi-pdf-embed-placeholder"><span class="wpmf-divi-message">'
                . esc_html__('Please select a PDF file to activate the preview', 'wpmf')
                . '</span></div></div>';
        }

        // Normalise: thumbnail previews of PDFs end with -pdf.jpg etc.
        $clean_url = str_replace(['-pdf.jpg', '-pdf.jpeg', '-pdf.png'], '.pdf', $url);

        $output = do_shortcode('[wpmfpdf'
            . ' url="' . esc_url($clean_url) . '"'
            . ' width="' . esc_attr($width) . '"'
            . ' height="' . esc_attr($height) . '"'
            . ' embed="' . esc_attr($embed) . '"'
            . ' target="' . esc_attr($target) . '"'
            . ']');

        $use_divi_render = isset($block->parsed_block['id']) && !empty($block->parsed_block['id']);

        if (!$use_divi_render) {
            return '<div class="wpmf_pdf_embed et_pb_module wpmf-d5-module">' . $output . '</div>';
        }

        $parent       = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::get_parent($block->parsed_block['id'], $block->parsed_block['storeInstance']);
        $parent_attrs = $parent->attrs ?? [];

        return \ET\Builder\Packages\Module\Module::render([
            'orderIndex'     => $block->parsed_block['orderIndex'],
            'storeInstance'  => $block->parsed_block['storeInstance'],
            'id'             => $block->parsed_block['id'],
            'name'           => $block->block_type->name,
            'moduleCategory' => $block->block_type->category,
            'attrs'          => $attrs,
            'elements'       => $elements,
            'classnamesFunction'  => [self::class, 'module_classnames'],
            'stylesComponent'     => [self::class, 'module_styles'],
            'parentAttrs'    => $parent_attrs,
            'parentId'       => $parent->id ?? '',
            'parentName'     => $parent->blockName ?? '',
            'children'       => [
                $elements->style_components([
                    'attrName' => 'module',
                ]) . \ET\Builder\Framework\Utility\HTMLUtility::render([
                    'tag'               => 'div',
                    'attributes'        => ['class' => 'wpmf-d5-module-inner'],
                    'childrenSanitizer' => 'et_core_esc_previously',
                    'children'          => $output,
                ]),
            ],
        ]);
    }
}
