<?php
/**
 * Divi 5 Extension Loader for WP Media Folder.
 *
 * @package WPMF\Divi5
 */

namespace WPMF\Divi5;

if (!defined('ABSPATH')) {
    exit;
}
use Joomunited\WPMediaFolder\WpmfHelper;

define('WPMF_DIVI5_PATH', plugin_dir_path(__FILE__));
define('WPMF_DIVI5_MODULES_JSON_PATH', dirname(WPMF_DIVI5_PATH) . '/modules-json/');

// Use the plugin's base URL constant (already defined in main plugin file).
define('WPMF_DIVI5_URL', WPMF_PLUGIN_URL . 'class/divi5/');

require_once WPMF_DIVI5_PATH . 'modules/Modules.php';

/**
 * Enqueue Divi 5 Visual Builder bundle script.
 *
 * @return void
 */
function registerBuilderBundle()
{
    if (et_builder_d5_enabled() && et_core_is_fb_enabled()) {
        \ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build([
            'name'    => 'wpmf-divi5-builder-bundle-script',
            'version' => WPMF_VERSION,
            'script'  => [
                'src'                => WPMF_DIVI5_URL . 'scripts/bundle.js',
                'deps'               => ['divi-module-library', 'divi-vendor-wp-hooks'],
                'enqueue_top_window' => false,
                'enqueue_app_window' => true,
            ],
        ]);
    }
}
add_action('divi_visual_builder_assets_before_enqueue_scripts', __NAMESPACE__ . '\\registerBuilderBundle');

// Inject plugin options into the page <head> — before any scripts execute.
// wp_head fires before wp_footer and all enqueued scripts, guaranteeing
// window.wpmfDivi5Options is defined when the bundle's addAction callback runs.
function printBuilderOptions()
{
    if (!function_exists('et_core_is_fb_enabled') || !et_core_is_fb_enabled()) {
        return;
    }
    if (!function_exists('et_builder_d5_enabled') || !et_builder_d5_enabled()) {
        return;
    }
    $enable_singlefile = (int) get_option('wpmf_option_singlefile', 0);

    echo '<script id="wpmf-divi5-options">window.wpmfDivi5Options = ' . wp_json_encode([
        'enableSingleFile' => $enable_singlefile === 1,
        'galleries'        => WpmfHelper::wpmfGetDivi5GalleryAddonOptions(),
        'imageSizes'       => WpmfHelper::wpmfGetDivi5ImageSizeOptions(),
        'galleryAddonDefaults' => WpmfHelper::wpmfGetDivi5GalleryAddonDefaults(),
    ]) . ';</script>' . "\n";
}
add_action('wp_head', __NAMESPACE__ . '\\printBuilderOptions', 1);

/**
 * Enqueue plugin's frontend CSS/JS inside the Divi 5 Visual Builder iframe.
 *
 * In Divi 5, the VB runs in an iframe. Our edit.tsx components fetch
 * shortcode HTML via REST API (wpmf-block-preview), but the rendered HTML
 * needs the plugin's public CSS to display correctly.
 *
 * @return void
 */
function enqueueBuilderIframeAssets()
{
    if (!function_exists('et_core_is_fb_enabled') || !et_core_is_fb_enabled()) {
        return;
    }
    if (!function_exists('et_builder_d5_enabled') || !et_builder_d5_enabled()) {
        return;
    }

    $public_url = WPMF_PLUGIN_URL . 'assets/css/';
    $version    = WPMF_VERSION;

    wp_enqueue_style('wpmf-divi5-widgets-vb', $public_url . 'divi-widgets.css', [], $version);

    // Use the exact same enqueue path as Divi 4 for Gallery Addon (wp-media-folder-gallery-addon):
    // 1. galleryScripts() → registers all assets (slick, flipster, justifiedGallery, imagesloaded, etc.)
    // 2. enqueueScript('divi') → queues the full set for the builder iframe
    $gallery_addon_ready = defined('WPMF_GALLERY_ADDON_PLUGIN_URL')
        && defined('WPMF_GALLERY_ADDON_VERSION')
        && class_exists('WpmfGlrAddonFrontEnd');

    if ($gallery_addon_ready) {
        $addon = new \WpmfGlrAddonFrontEnd();
        $addon->galleryScripts();
        $addon->enqueueScript('divi');
        wp_enqueue_script('wpmf-gallery-js');
        wp_enqueue_script('wpmf-gallery-tree-js');
    }

    // Also ensure base WPMF gallery scripts are registered/enqueued.
    $enable_gallery = get_option('wpmf_usegellery');
    if (isset($enable_gallery) && (int)$enable_gallery === 1) {
        if (!class_exists('WpmfDisplayGallery')) {
            require_once WP_MEDIA_FOLDER_PLUGIN_DIR . 'class/class-display-gallery.php';
        }
        $gallery = new \WpmfDisplayGallery();
        $gallery->galleryScripts();
        $gallery->enqueueScript('divi');
    }
}
add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueueBuilderIframeAssets', 20);

/**
 * Ensure Divi 5's BlockParser processes pages containing wpmf/* blocks.
 *
 * Divi's BlockParser::has_any_divi_block() only recognises '<!-- wp:divi'
 * or '"desktop":{"value"' patterns. We inject the marker for wpmf blocks.
 *
 * @param string $content Post content.
 *
 * @return string
 */
function ensureBlockParserHandlesWpmfBlocks($content)
{
    if (strpos($content, '<!-- wp:wpmf/') === false) {
        return $content;
    }

    // If the content already has the detection pattern, Divi will parse it.
    if (strpos($content, '"desktop":{"value"') !== false) {
        return $content;
    }

    // Inject marker into attribute-less blocks: <!-- wp:wpmf/name /-->
    $content = preg_replace(
        '/<!-- wp:wpmf\/([\w-]+) \/-->/',
        '<!-- wp:wpmf/$1 {"_d":{"desktop":{"value":{}}}} /-->',
        $content
    );

    // Inject marker into blocks WITH attributes but missing the detection pattern.
    $content = preg_replace(
        '/<!-- wp:wpmf\/([\w-]+) (\{(?!.*"desktop":\{"value").+\}) \/-->/',
        '<!-- wp:wpmf/$1 {"_d":{"desktop":{"value":{}}},$2} /-->',
        $content
    );

    return $content;
}
add_filter('the_content', __NAMESPACE__ . '\\ensureBlockParserHandlesWpmfBlocks', -999);
