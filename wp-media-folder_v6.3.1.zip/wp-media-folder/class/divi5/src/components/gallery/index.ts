import { type ModuleLibrary } from '@divi/types';
import { GalleryEdit } from './edit';
import metadata from './module.json';

export const gallery: ModuleLibrary.Module.RegisterDefinition<any> = {
  metadata: metadata as any,
  renderers: {
    edit: GalleryEdit,
  },
};
