import { type ModuleLibrary } from '@divi/types';
import { PdfEmbedEdit } from './edit';
import metadata from './module.json';

export const pdfEmbed: ModuleLibrary.Module.RegisterDefinition<any> = {
  metadata: metadata as any,
  renderers: {
    edit: PdfEmbedEdit,
  },
};
