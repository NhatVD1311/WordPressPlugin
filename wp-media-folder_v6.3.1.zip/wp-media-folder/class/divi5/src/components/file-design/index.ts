import { type ModuleLibrary } from '@divi/types';
import { FileDesignEdit } from './edit';
import metadata from './module.json';

export const fileDesign: ModuleLibrary.Module.RegisterDefinition<any> = {
  metadata: metadata as any,
  renderers: {
    edit: FileDesignEdit,
  },
};
