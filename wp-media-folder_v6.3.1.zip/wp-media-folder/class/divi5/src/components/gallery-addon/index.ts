import { type ModuleLibrary } from '@divi/types';
import GalleryAddonEdit from './edit';
import metadata from './module.json';

export const galleryAddon: ModuleLibrary.Module.RegisterDefinition<any> = {
  metadata: metadata as any,
  renderers: {
    edit: GalleryAddonEdit,
  },
};
