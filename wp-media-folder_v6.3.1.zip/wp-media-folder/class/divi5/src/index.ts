import { omit } from 'lodash';
import { addAction } from '@wordpress/hooks';
import { registerModule } from '@divi/module-library';
import { registerFieldComponent } from '@divi/field-library';

import { gallery } from './components/gallery';
import { galleryAddon } from './components/gallery-addon';
import { fileDesign } from './components/file-design';
import { pdfEmbed } from './components/pdf-embed';

// wpmfDivi5Options is injected by PHP (loader.php) via wp_add_inline_script.
declare const wpmfDivi5Options: {
  enableSingleFile?: boolean;
  galleries?: { [key: string]: { label: string } };
  imageSizes?: { [key: string]: { label: string } };
  galleryAddonDefaults?: { [key: string]: string };
} | undefined;

/**
 * Inject dynamic options from PHP (window.wpmfDivi5Options) into module metadata
 * before registering with Divi 5.
 */
const injectDynamicOptions = () => {
  const data = typeof wpmfDivi5Options !== 'undefined' ? wpmfDivi5Options : {};

  // Inject gallery options into Gallery Addon metadata
  if (data.galleries && Object.keys(data.galleries).length > 0) {
    try {
      (galleryAddon.metadata as any).attributes.module.settings.innerContent.items.galleryId.component.props.options =
        data.galleries;
    } catch (e) {
      // Structure mismatch, skip
    }
  }

  if (data.imageSizes && Object.keys(data.imageSizes).length > 0) {
    try {
      (galleryAddon.metadata as any).attributes.module.settings.innerContent.items.size.component.props.options =
        data.imageSizes;
      (galleryAddon.metadata as any).attributes.module.settings.innerContent.items.targetsize.component.props.options =
        data.imageSizes;
    } catch (e) {
      // Structure mismatch, skip
    }
  }

  if (data.galleryAddonDefaults && Object.keys(data.galleryAddonDefaults).length > 0) {
    try {
      Object.assign(
        (galleryAddon.metadata as any).attributes.module.default.innerContent.desktop.value,
        data.galleryAddonDefaults
      );
    } catch (e) {
      // Structure mismatch, skip
    }
  }
};

// Register WPMF modules with Divi 5 Visual Builder.
addAction('divi.moduleLibrary.registerModuleLibraryStore.after', 'wpmf', () => {
  // Inject options before registration
  injectDynamicOptions();

  // Register WPMF Gallery
  registerModule(gallery.metadata, omit(gallery, 'metadata'));

  // Register WPMF Gallery Addon
  registerModule(galleryAddon.metadata, omit(galleryAddon, 'metadata'));

  registerModule(pdfEmbed.metadata, omit(pdfEmbed, 'metadata'));

  // FileDesign (Media Download) is only registered when the
  // wpmf_option_singlefile plugin option is enabled — matching Divi 4 behavior.
  const enableSingleFile =
    typeof wpmfDivi5Options !== 'undefined' && wpmfDivi5Options.enableSingleFile === true;

  if (enableSingleFile) {
    registerModule(fileDesign.metadata, omit(fileDesign, 'metadata'));
  }
});
