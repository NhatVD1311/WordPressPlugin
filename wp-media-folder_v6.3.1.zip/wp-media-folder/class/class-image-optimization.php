<?php

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

/**
 * Class WpmfImageOptimization
 *
 * Handles WebP and AVIF image generation for WP Media Folder.
 */
class WpmfImageOptimization
{
    /**
     * Queue option.
     */
    const QUEUE_OPTION = 'wpmf_image_optimization_queue';

    /**
     * Cron hook.
     */
    const CRON_HOOK = 'wpmf_process_image_optimization';

    /**
     * Number of attachments processed per batch.
     */
    const BATCH_SIZE = 10;

    /**
     * Next-generation directory.
     *
     * Physical path:
     *
     * wp-content/wpmf-nextgen/uploads/
     */
    const NEXTGEN_DIR = 'wpmf-nextgen/uploads';

    /**
     * Option name for storing optimization progress.
     */
    const PROGRESS_OPTION = 'wpmf_image_optimization_progress';

    /**
     * Option name for stopping optimization.
     */
    const STOP_OPTION = 'wpmf_image_optimization_stop';

    /**
     * Constructor.
     */
    public function __construct()
    {
        add_action('wp_ajax_wpmf_image_optimization_add_queue', [$this, 'startImageOptimization']);

        add_action('wp_ajax_wpmf_image_optimization_get_progress', [$this, 'getImageOptimizationProgress']);

        add_action('wp_ajax_wpmf_image_optimization_stop', [$this, 'stopImageOptimization']);

        add_action(self::CRON_HOOK, [$this, 'processImageOptimizationQueue']);

        add_action('wpmf_image_optimization_settings_saved', [$this, 'maybeSetupNextGenRewriteRules']);

        add_action('add_attachment', [$this, 'autoOptimizeAttachment']);

        add_action('delete_attachment', [$this, 'deleteNextGenFiles']);

        add_action('wp_ajax_wpmf_image_optimization_save_settings', [$this, 'saveImageOptimizationSettings']);
    }

    /**
     * Automatically optimize a newly uploaded image.
     *
     * @param integer $attachment_id Attachment ID.
     *
     * @return void
     */
    public function autoOptimizeAttachment($attachment_id)
    {
        $settings = $this->getSettings();

        if (empty($settings['auto_optimize_uploads'])) {
            return;
        }

        $mime_type = get_post_mime_type($attachment_id);

        if (!in_array($mime_type, ['image/jpeg', 'image/png', 'image/webp', 'image/avif'], true)) {
            return;
        }

        if (!empty($settings['do_not_convert_png']) && $mime_type === 'image/png') {
            return;
        }

        if ($this->isAttachmentInExcludedFolder($attachment_id, $settings['excluded_folders'] ?? [])) {
            return;
        }

        $queue = get_option(self::QUEUE_OPTION, []);

        if (!is_array($queue)) {
            $queue = [];
        }

        if (!in_array($attachment_id, $queue, true)) {
            $queue[] = (int) $attachment_id;
        }

        update_option(self::QUEUE_OPTION, $queue, false);

        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_single_event(time() + 1, self::CRON_HOOK);
        }
    }

    /**
     * Start image optimization.
     *
     * Creates the optimization queue.
     *
     * @return void
     */
    public function startImageOptimization()
    {
        check_ajax_referer('wpmf_nonce', 'wpmf_nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error([
                'message' => __('You are not allowed to optimize images.', 'wpmf')
            ]);
        }

        $settings = self::getSettings();

        /*
         * Processing library.
         */
        $processing_library = isset($settings['processing_library']) ? sanitize_key($settings['processing_library']) : 'gd';

        $processing_library = in_array($processing_library, ['gd', 'imagick'], true) ? $processing_library : 'gd';

        /*
         * Check processing library and format support.
         */
        $checks = self::getFormatChecks($processing_library);

        if ($processing_library === 'gd' && !$checks['gd_available']) {
            wp_send_json_error([
                'message' => __('GD library is not available.', 'wpmf')
            ]);
        }

        if ($processing_library === 'imagick' && !$checks['imagick_available']) {
            wp_send_json_error([
                'message' => __('Imagick library is not available.', 'wpmf')
            ]);
        }

        /*
         * Output formats.
         *
         * image_optimization[output_formats][]
         */
        $output_formats = isset($settings['output_formats']) && is_array($settings['output_formats']) ? $settings['output_formats'] : [];

        $output_formats = array_map('sanitize_key', $output_formats);

        $output_formats = array_values(array_intersect($output_formats, ['webp', 'avif']));

        if (empty($output_formats)) {
            wp_send_json_error([
                'message' => __(
                    'Please select at least one output format.',
                    'wpmf'
                )
            ]);
        }

        /*
         * Remove unsupported formats.
         */
        if (in_array('webp', $output_formats, true) && !$checks['webp_supported']) {
            $output_formats = array_values(array_diff($output_formats, ['webp']));
        }

        if (in_array('avif', $output_formats, true) && !$checks['avif_supported']) {
            $output_formats = array_values(array_diff($output_formats, ['avif']));
        }

        if (empty($output_formats)) {
            wp_send_json_error([
                'message' => __(
                    'None of the selected output formats are supported.',
                    'wpmf'
                )
            ]);
        }

        /*
         * Thumbnail sizes.
         *
         * image_optimization[thumbnail_sizes][]
         */
        $thumbnail_sizes = isset($settings['thumbnail_sizes']) && is_array($settings['thumbnail_sizes']) ? $settings['thumbnail_sizes'] : [];

        $allowed_sizes = [
            'full',
            'thumbnail',
            'medium',
            'medium_large',
            'large',
        ];

        $thumbnail_sizes = array_values(array_intersect($thumbnail_sizes, $allowed_sizes));

        if (empty($thumbnail_sizes)) {
            wp_send_json_error([
                'message' => __(
                    'Please select at least one image size.',
                    'wpmf'
                )
            ]);
        }

        /*
         * Excluded folders.
         *
         * image_optimization[excluded_folders][]
         */
        $excluded_folders = isset($settings['excluded_folders']) && is_array($settings['excluded_folders']) ? array_map('intval', $settings['excluded_folders']) : [];

        /*
         * Get image attachments.
         */
        $attachment_ids = get_posts([
            'post_type'              => 'attachment',
            'post_status'            => 'inherit',
            'post_mime_type'         => [
                'image/jpeg',
                'image/png',
                'image/webp',
                'image/avif',
            ],
            'posts_per_page'         => -1,
            'fields'                 => 'ids',
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        if (empty($attachment_ids)) {
            wp_send_json_success([
                'total'   => 0,
                'queued'  => 0,
                'message' => __('No images found.', 'wpmf')
            ]);
        }

        /*
         * Build queue.
         */
        $queue = [];

        foreach ($attachment_ids as $attachment_id) {
            $attachment_id = (int) $attachment_id;

            $mime_type = get_post_mime_type($attachment_id);

            if (!empty($settings['do_not_convert_png']) && $mime_type === 'image/png') {
                continue;
            }

            /*
             * Skip attachments in excluded folders.
             */
            if (!empty($excluded_folders) && self::isAttachmentInExcludedFolder($attachment_id, $excluded_folders)) {
                continue;
            }

            $queue[] = $attachment_id;
        }

        /*
         * Remove duplicate IDs.
         */
        $queue = array_values(
            array_unique(
                array_map(
                    'intval',
                    $queue
                )
            )
        );

        if (empty($queue)) {
            wp_send_json_success([
                'total'   => count($attachment_ids),
                'queued'  => 0,
                'message' => __(
                    'No images need to be processed.',
                    'wpmf'
                )
            ]);
        }

        update_option(
            self::PROGRESS_OPTION,
            [
                'total'     => count($queue),
                'processed' => 0,
            ],
            false
        );

        /*
        * Reset stop status.
        */
        delete_option(
            self::STOP_OPTION
        );

        /*
         * Save queue.
         *
         * Only attachment IDs are stored.
         *
         * The worker reads the current settings when processing.
         */
        update_option(
            self::QUEUE_OPTION,
            $queue,
            false
        );

        /*
         * Start background processing.
         */
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_single_event(
                time() + 1,
                self::CRON_HOOK
            );
        }

        wp_send_json_success([
            'total'   => count($attachment_ids),
            'queued'  => count($queue),
            'message' => __(
                'Image optimization queue started.',
                'wpmf'
            )
        ]);
    }

    /**
     * Get image optimization progress.
     *
     * @return void
     */
    public function getImageOptimizationProgress()
    {
        check_ajax_referer('wpmf_nonce', 'wpmf_nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error([
                'message' => __('You are not allowed to view image optimization progress.', 'wpmf')
            ]);
        }

        $progress = get_option(
            self::PROGRESS_OPTION,
            [
                'total'     => 0,
                'processed' => 0,
            ]
        );

        $total = isset($progress['total']) ? (int) $progress['total'] : 0;
        $processed = isset($progress['processed']) ? (int) $progress['processed'] : 0;

        $percent = $total > 0
            ? min(
                100,
                (int) round(($processed / $total) * 100)
            )
            : 0;

        wp_send_json_success([
            'total'     => $total,
            'processed' => $processed,
            'percent'   => $percent,
            'completed' => $total > 0 && $processed >= $total,
        ]);
    }

    /**
     * Stop image optimization.
     *
     * @return void
     */
    public function stopImageOptimization()
    {
        check_ajax_referer('wpmf_nonce', 'wpmf_nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error([
                'message' => __('You are not allowed to stop image optimization.', 'wpmf')
            ]);
        }

        update_option(
            self::STOP_OPTION,
            true,
            false
        );

        wp_clear_scheduled_hook(
            self::CRON_HOOK
        );

        delete_option(
            self::PROGRESS_OPTION
        );

        wp_send_json_success([
            'message' => __('Image optimization stopped.', 'wpmf')
        ]);
    }

    /**
     * Process optimization queue.
     *
     * @return void
     */
    public function processImageOptimizationQueue()
    {
        if (get_option(self::STOP_OPTION, false)) {
            delete_option(self::STOP_OPTION);
            delete_option(self::QUEUE_OPTION);
            return;
        }

        $queue = get_option(
            self::QUEUE_OPTION,
            []
        );

        if (empty($queue) || !is_array($queue)) {
            delete_option(
                self::QUEUE_OPTION
            );

            return;
        }

        /*
         * Process one batch.
         */
        $batch = array_splice(
            $queue,
            0,
            self::BATCH_SIZE
        );

        /*
         * Save remaining queue before processing.
         *
         * This prevents the entire queue from being lost
         * if PHP stops during processing.
         */
        if (!empty($queue)) {
            update_option(
                self::QUEUE_OPTION,
                array_values($queue),
                false
            );
        } else {
            delete_option(
                self::QUEUE_OPTION
            );
        }

        /*
         * Optimize attachments.
         */
        foreach ($batch as $attachment_id) {
            if (get_option(self::STOP_OPTION, false)) {
                delete_option(self::STOP_OPTION);
                delete_option(self::QUEUE_OPTION);

                return;
            }

            self::optimizeAttachment(
                (int) $attachment_id
            );

            $progress = get_option(
                self::PROGRESS_OPTION,
                [
                    'total'     => 0,
                    'processed' => 0,
                ]
            );

            $progress['processed'] = min(
                (int) $progress['processed'] + 1,
                (int) $progress['total']
            );

            update_option(
                self::PROGRESS_OPTION,
                $progress,
                false
            );
        }

        /*
         * Schedule next batch.
         */
        if (!empty($queue)) {
            wp_schedule_single_event(
                time() + 1,
                self::CRON_HOOK
            );
        }
    }

    /**
     * Optimize a single attachment.
     *
     * @param integer $attachment_id Attachment ID.
     *
     * @return boolean
     */
    private static function optimizeAttachment($attachment_id)
    {
        $file = get_attached_file($attachment_id);

        if (!$file || !file_exists($file)) {
            return false;
        }

        $settings = self::getSettings();

        $processing_library = isset($settings['processing_library']) ? sanitize_key($settings['processing_library']) : 'gd';

        $output_formats = isset($settings['output_formats']) && is_array($settings['output_formats']) ? $settings['output_formats'] : [];

        $thumbnail_sizes = isset(
            $settings['thumbnail_sizes']
        )
            && is_array(
                $settings['thumbnail_sizes']
            )
            ? $settings['thumbnail_sizes']
            : [];

        /*
         * Process original/full image.
         */
        if (in_array(
            'full',
            $thumbnail_sizes,
            true
        )) {
            self::convertImage(
                $file,
                $processing_library,
                $output_formats,
                $settings
            );
        }

        /*
         * Get WordPress attachment metadata.
         */
        $metadata = wp_get_attachment_metadata(
            $attachment_id
        );

        if (empty($metadata)
            || empty($metadata['sizes'])
            || !is_array($metadata['sizes'])
        ) {
            return true;
        }

        /*
         * Directory of original image.
         *
         * Example:
         *
         * /uploads/2026/09/
         */
        $source_directory = dirname($file);

        foreach ($metadata['sizes'] as $size_name => $size_data) {
            /*
             * Skip sizes not selected.
             */
            if (!in_array(
                $size_name,
                $thumbnail_sizes,
                true
            )) {
                continue;
            }

            if (empty($size_data['file'])
                || !is_string($size_data['file'])
            ) {
                continue;
            }

            $thumbnail_file = trailingslashit(
                $source_directory
            ) . $size_data['file'];

            if (!file_exists($thumbnail_file)) {
                continue;
            }

            self::convertImage(
                $thumbnail_file,
                $processing_library,
                $output_formats,
                $settings
            );
        }

        return true;
    }

    /**
     * Convert source image to selected formats.
     *
     * @param string $source_file        Source image.
     * @param string $processing_library Processing library.
     * @param array  $output_formats     Output formats.
     * @param array  $settings           Settings.
     *
     * @return boolean
     */
    private static function convertImage(
        $source_file,
        $processing_library,
        $output_formats,
        $settings
    ) {
        if (!$source_file
            || !file_exists($source_file)
        ) {
            return false;
        }

        $image_info = getimagesize($source_file);

        if (!$image_info
            || empty($image_info['mime'])
        ) {
            return false;
        }

        $mime = $image_info['mime'];

        /*
         * Only process supported image formats.
         */
        $supported_mimes = [
            'image/jpeg',
            'image/png',
            'image/webp',
            'image/avif',
        ];

        if (!in_array(
            $mime,
            $supported_mimes,
            true
        )) {
            return false;
        }

        /*
         * Do not convert a WebP file to WebP
         * or an AVIF file to AVIF.
         */
        if ($mime === 'image/webp') {
            $output_formats = array_values(
                array_diff(
                    $output_formats,
                    ['webp']
                )
            );
        }

        if ($mime === 'image/avif') {
            $output_formats = array_values(
                array_diff(
                    $output_formats,
                    ['avif']
                )
            );
        }

        if (empty($output_formats)) {
            return true;
        }

        /*
         * Compression quality.
         */
        $quality = self::getCompressionQuality(
            $settings
        );

        /*
         * GD.
         */
        if ($processing_library === 'gd') {
            return self::convertWithGD(
                $source_file,
                $mime,
                $output_formats,
                $quality
            );
        }

        /*
         * Imagick.
         */
        if ($processing_library === 'imagick') {
            return self::convertWithImagick(
                $source_file,
                $output_formats,
                $quality
            );
        }

        return false;
    }

    /**
     * Convert image using GD.
     *
     * @param string  $source_file    Source file.
     * @param string  $mime           MIME type.
     * @param array   $output_formats Output formats.
     * @param integer $quality        Quality.
     *
     * @return boolean
     */
    private static function convertWithGD(
        $source_file,
        $mime,
        $output_formats,
        $quality
    ) {
        $image = false;

        switch ($mime) {
            case 'image/jpeg':
                if (function_exists(
                    'imagecreatefromjpeg'
                )) {
                    $image = imagecreatefromjpeg(
                        $source_file
                    );
                }
                break;

            case 'image/png':
                if (function_exists(
                    'imagecreatefrompng'
                )) {
                    $image = imagecreatefrompng(
                        $source_file
                    );

                    if ($image) {
                        imagepalettetotruecolor(
                            $image
                        );

                        imagealphablending(
                            $image,
                            true
                        );

                        imagesavealpha(
                            $image,
                            true
                        );
                    }
                }
                break;

            case 'image/webp':
                if (function_exists(
                    'imagecreatefromwebp'
                )) {
                    $image = imagecreatefromwebp(
                        $source_file
                    );
                }
                break;

            case 'image/avif':
                if (function_exists(
                    'imagecreatefromavif'
                )) {
                    $image = imagecreatefromavif(
                        $source_file
                    );
                }
                break;
        }

        if (!$image) {
            return false;
        }

        /*
         * Get destination directory.
         *
         * Example:
         *
         * Source:
         * /wp-content/uploads/2026/09/test1.png
         *
         * Destination:
         * /wp-content/wpmf-nextgen/uploads/2026/09/
         */
        $destination_directory =
            self::getNextGenDirectory(
                $source_file
            );

        if (!wp_mkdir_p(
            $destination_directory
        )) {
            imagedestroy($image);

            return false;
        }

        $result = false;

        /*
         * WebP.
         */
        if (in_array(
            'webp',
            $output_formats,
            true
        )
            && function_exists('imagewebp')
        ) {
            $webp_file = self::getNextGenPath(
                $source_file,
                'webp'
            );

            if (imagewebp(
                $image,
                $webp_file,
                $quality
            )) {
                $result = true;
            }
        }

        /*
         * AVIF.
         */
        if (in_array(
            'avif',
            $output_formats,
            true
        )
            && function_exists('imageavif')
        ) {
            $avif_file = self::getNextGenPath(
                $source_file,
                'avif'
            );

            if (imageavif(
                $image,
                $avif_file,
                $quality
            )) {
                $result = true;
            }
        }

        imagedestroy($image);

        return $result;
    }

    /**
     * Convert image using Imagick.
     *
     * @param string  $source_file    Source file.
     * @param array   $output_formats Output formats.
     * @param integer $quality        Quality.
     *
     * @return boolean
     */
    private static function convertWithImagick(
        $source_file,
        $output_formats,
        $quality
    ) {
        if (!class_exists('Imagick')) {
            return false;
        }

        try {
            $image = new \Imagick(
                $source_file
            );

            $image->setIteratorIndex(0);

            /*
             * Get destination directory.
             */
            $destination_directory =
                self::getNextGenDirectory(
                    $source_file
                );

            if (!wp_mkdir_p(
                $destination_directory
            )) {
                $image->clear();
                $image->destroy();

                return false;
            }

            $result = false;

            /*
             * WebP.
             */
            if (in_array(
                'webp',
                $output_formats,
                true
            )) {
                $webp = clone $image;

                $webp->setImageFormat(
                    'webp'
                );

                $webp->setImageCompressionQuality(
                    $quality
                );

                $webp_file = self::getNextGenPath(
                    $source_file,
                    'webp'
                );

                if ($webp->writeImage(
                    $webp_file
                )) {
                    $result = true;
                }

                $webp->clear();
                $webp->destroy();
            }

            /*
             * AVIF.
             */
            if (in_array(
                'avif',
                $output_formats,
                true
            )) {
                $avif = clone $image;

                $avif->setImageFormat(
                    'avif'
                );

                $avif->setImageCompressionQuality(
                    $quality
                );

                $avif_file = self::getNextGenPath(
                    $source_file,
                    'avif'
                );

                if ($avif->writeImage(
                    $avif_file
                )) {
                    $result = true;
                }

                $avif->clear();
                $avif->destroy();
            }

            $image->clear();
            $image->destroy();

            return $result;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get next-generation directory.
     *
     * The directory mirrors the original uploads structure.
     *
     * Example:
     *
     * Original:
     * /wp-content/uploads/2026/09/
     *
     * Nextgen:
     * /wp-content/wpmf-nextgen/uploads/2026/09/
     *
     * @param string $source_file Source image path.
     *
     * @return string
     */
    private static function getNextGenDirectory(
        $source_file
    ) {
        $upload_dir = wp_upload_dir();

        $base_upload_dir = wp_normalize_path(
            $upload_dir['basedir']
        );

        $source_file = wp_normalize_path(
            $source_file
        );

        /*
         * Get relative path inside uploads.
         */
        $relative_path = '';

        if (strpos(
            $source_file,
            trailingslashit(
                $base_upload_dir
            )
        ) === 0
        ) {
            $relative_path = ltrim(
                substr(
                    $source_file,
                    strlen(
                        trailingslashit(
                            $base_upload_dir
                        )
                    )
                ),
                '/'
            );
        }

        /*
         * Remove filename.
         */
        $relative_directory = dirname(
            $relative_path
        );

        if ($relative_directory === '.') {
            $relative_directory = '';
        }

        /*
         * wp-content directory.
         */
        $wp_content_dir = dirname(
            $base_upload_dir
        );

        /*
         * Destination:
         *
         * wp-content/wpmf-nextgen/uploads/
         */
        $nextgen_base_dir = trailingslashit(
            $wp_content_dir
        ) . self::NEXTGEN_DIR;

        if (!empty($relative_directory)) {
            $nextgen_base_dir = trailingslashit(
                $nextgen_base_dir
            ) . $relative_directory;
        }

        return wp_normalize_path(
            $nextgen_base_dir
        );
    }

    /**
     * Get next-generation file path.
     *
     * Example:
     *
     * /uploads/2026/09/test1.png
     *
     * becomes:
     *
     * /wpmf-nextgen/uploads/2026/09/test1.webp
     *
     * @param string $source_file Source image.
     * @param string $format      Format.
     *
     * @return string
     */
    private static function getNextGenPath(
        $source_file,
        $format
    ) {
        $upload_dir = wp_upload_dir();

        $base_upload_dir = wp_normalize_path(
            $upload_dir['basedir']
        );

        $source_file = wp_normalize_path(
            $source_file
        );

        /*
         * Get filename.
         */
        $filename = wp_basename(
            $source_file
        );

        /*
         * Remove original extension.
         *
         * test1.png
         * =>
         * test1
         */
        $filename_without_extension =
            pathinfo(
                $filename,
                PATHINFO_FILENAME
            );

        /*
         * Get destination directory.
         */
        $destination_directory =
            self::getNextGenDirectory(
                $source_file
            );

        /*
         * Destination:
         *
         * test1.webp
         * test1.avif
         */
        return trailingslashit(
            $destination_directory
        )
            . $filename_without_extension
            . '.'
            . $format;
    }

    /**
     * Get compression quality.
     *
     * @param array $settings Settings.
     *
     * @return integer
     */
    private static function getCompressionQuality(
        $settings
    ) {
        $level = isset(
            $settings['compression_level']
        )
            ? sanitize_key(
                $settings['compression_level']
            )
            : 'balanced';

        switch ($level) {
            case 'low':
                return 85;

            case 'high':
                return 60;

            case 'balanced':
            default:
                return 75;
        }
    }

    /**
     * Get image optimization settings.
     *
     * Settings are stored as JSON in:
     *
     * wpmf_image_optimization
     *
     * @return array
     */
    private static function getSettings()
    {
        $settings = get_option(
            'wpmf_image_optimization',
            ''
        );

        if (empty($settings)) {
            return [];
        }

        /*
         * The option is stored as JSON.
         */
        $settings = json_decode(
            $settings,
            true
        );

        return is_array($settings)
            ? $settings
            : [];
    }

    /**
     * Check whether an attachment belongs
     * to an excluded WPMF folder.
     *
     * @param integer $attachment_id    Attachment ID.
     * @param array   $excluded_folders Folder IDs.
     *
     * @return boolean
     */
    private static function isAttachmentInExcludedFolder(
        $attachment_id,
        $excluded_folders
    ) {
        $folder_ids = wp_get_post_terms(
            $attachment_id,
            'wpmf-category',
            [
                'fields' => 'ids',
            ]
        );

        if (is_wp_error($folder_ids)
            || empty($folder_ids)
        ) {
            return false;
        }

        $folder_ids = array_map(
            'intval',
            $folder_ids
        );

        return !empty(array_intersect(
            $folder_ids,
            $excluded_folders
        ));
    }

    /**
     * Check image processing libraries
     * and output format support.
     *
     * @param string $processing_library Selected processing library.
     *
     * @return array
     */
    public static function getFormatChecks(
        $processing_library = 'gd'
    ) {
        $processing_library = in_array(
            $processing_library,
            ['gd', 'imagick'],
            true
        )
            ? $processing_library
            : 'gd';

        /*
         * Check GD.
         */
        $gd_available = extension_loaded(
            'gd'
        );

        /*
         * Check Imagick.
         */
        $imagick_available =
            extension_loaded('imagick')
            && class_exists('Imagick');

        /*
         * Check WebP.
         */
        $webp_supported = false;

        if ($processing_library === 'gd'
        ) {
            $webp_supported =
                $gd_available
                && function_exists(
                    'imagewebp'
                );
        } elseif ($processing_library === 'imagick'
        ) {
            $webp_supported =
                $imagick_available
                && self::imagickSupportsFormat(
                    'WEBP'
                );
        }

        /*
         * Check AVIF.
         */
        $avif_supported = false;

        if ($processing_library === 'gd'
        ) {
            $avif_supported =
                $gd_available
                && function_exists(
                    'imageavif'
                );
        } elseif ($processing_library === 'imagick'
        ) {
            $avif_supported =
                $imagick_available
                && self::imagickSupportsFormat(
                    'AVIF'
                );
        }

        return [
            'processing_library' => $processing_library,
            'gd_available'       => $gd_available,
            'imagick_available'  => $imagick_available,
            'webp_supported'     => $webp_supported,
            'avif_supported'     => $avif_supported,
        ];
    }

    /**
     * Check whether Imagick supports a format.
     *
     * @param string $format Format.
     *
     * @return boolean
     */
    private static function imagickSupportsFormat(
        $format
    ) {
        if (!class_exists('Imagick')) {
            return false;
        }

        try {
            $formats = \Imagick::queryFormats(
                strtoupper($format)
            );

            return !empty($formats);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Setup or remove NextGen rewrite rules based on enabled output formats.
     *
     * @return void
     */
    public function maybeSetupNextGenRewriteRules()
    {
        $settings = $this->getSettings();

        $output_formats = isset($settings['output_formats'])
            ? (array) $settings['output_formats']
            : [];

        $webp_enabled = in_array('webp', $output_formats, true);
        $avif_enabled = in_array('avif', $output_formats, true);

        if (!$webp_enabled && !$avif_enabled) {
            $this->removeNextGenRewriteRules();
            return;
        }

        $this->setupNextGenRewriteRules();
    }

    /**
     * Setup next-gen image rewrite rules.
     *
     * @return void
     */
    /**
     * Setup next-gen image rewrite rules.
     *
     * @return void
     */
    /**
     * Setup next-gen image rewrite rules.
     *
     * @return void
     */
    private function setupNextGenRewriteRules()
    {
        if (!function_exists('get_home_path')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!function_exists('insert_with_markers')) {
            require_once ABSPATH . 'wp-admin/includes/misc.php';
        }

        $home_path = get_home_path();

        if (!$home_path) {
            return;
        }

        $htaccess = trailingslashit($home_path) . '.htaccess';

        if (file_exists($htaccess)) {
            if (!is_writable($htaccess)) {
                return;
            }
        } elseif (!is_writable($home_path)) {
            return;
        }

        $settings = $this->getSettings();

        $output_formats = isset($settings['output_formats'])
            ? (array) $settings['output_formats']
            : [];

        $webp_enabled = in_array('webp', $output_formats, true);
        $avif_enabled = in_array('avif', $output_formats, true);

        /*
        * Get the URL path of the WordPress installation.
        *
        * Example:
        * /alpha/
        *
        * This is used only for the RewriteRule substitution.
        */
        $home_path_url = wp_parse_url(home_url('/'), PHP_URL_PATH);
        $home_path_url = '/' . trim((string) $home_path_url, '/');

        if ($home_path_url === '/') {
            $home_path_url = '';
        }

        /*
        * Physical path of the next-gen directory.
        *
        * Example:
        * /home/.../alpha/wp-content/wpmf-nextgen/uploads
        */
        $nextgen_dir = trailingslashit(WP_CONTENT_DIR) . 'wpmf-nextgen/uploads';
        $nextgen_dir = str_replace('\\', '/', $nextgen_dir);

        /*
        * Build rules.
        */
        $rules = [
            '<IfModule mod_rewrite.c>',
            'RewriteEngine On',
            '',
        ];

        /*
        * AVIF
        */
        if ($avif_enabled) {
            $rules[] = '# WPMF NEXTGEN - AVIF';
            $rules[] = 'RewriteCond %{HTTP_ACCEPT} image/avif [NC]';
            $rules[] = 'RewriteCond "' . $nextgen_dir . '/$1.avif" -f';
            $rules[] = 'RewriteRule ^wp-content/uploads/(.+)\.(jpe?g|png)$ ' .
                $home_path_url .
                '/wp-content/wpmf-nextgen/uploads/$1.avif [T=image/avif,L]';
            $rules[] = '';
        }

        /*
        * WebP
        */
        if ($webp_enabled) {
            $rules[] = '# WPMF NEXTGEN - WebP';
            $rules[] = 'RewriteCond %{HTTP_ACCEPT} image/webp [NC]';
            $rules[] = 'RewriteCond "' . $nextgen_dir . '/$1.webp" -f';
            $rules[] = 'RewriteRule ^wp-content/uploads/(.+)\.(jpe?g|png)$ ' .
                $home_path_url .
                '/wp-content/wpmf-nextgen/uploads/$1.webp [T=image/webp,L]';
            $rules[] = '';
        }

        /*
        * Register MIME types for next-gen image formats.
        */
        $rules[] = 'AddType image/avif .avif';
        $rules[] = 'AddType image/webp .webp';

        $rules[] = '</IfModule>';

        \insert_with_markers(
            $htaccess,
            'WPMF NEXTGEN',
            $rules
        );
    }

    /**
     * Remove WPMF next-gen rewrite rules from .htaccess.
     *
     * @return void
     */
    private function removeNextGenRewriteRules()
    {
        if (!function_exists('get_home_path')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        if (!function_exists('insert_with_markers')) {
            require_once ABSPATH . 'wp-admin/includes/misc.php';
        }

        $home_path = get_home_path();

        if (!$home_path) {
            return;
        }

        $htaccess = trailingslashit($home_path) . '.htaccess';

        if (!file_exists($htaccess) || !is_writable($htaccess)) {
            return;
        }

        \insert_with_markers(
            $htaccess,
            'WPMF NEXTGEN',
            []
        );
    }

    /**
     * Delete generated NextGen files for an attachment.
     *
     * Deletes WebP and AVIF files generated for the original image
     * and all WordPress thumbnail sizes.
     *
     * @param integer $attachment_id Attachment ID.
     *
     * @return void
     */
    public static function deleteNextGenFiles($attachment_id)
    {
        $source_file = get_attached_file($attachment_id);

        if (empty($source_file)) {
            return;
        }

        // Get original/full image.
        self::deleteNextGenFile($source_file);

        // Get WordPress attachment metadata.
        $metadata = wp_get_attachment_metadata($attachment_id);

        if (empty($metadata['sizes'])
            || !is_array($metadata['sizes'])
        ) {
            return;
        }

        // Get original image directory.
        $source_directory = dirname($source_file);

        foreach ($metadata['sizes'] as $size_data) {
            if (empty($size_data['file'])
                || !is_string($size_data['file'])
            ) {
                continue;
            }

            $thumbnail_file = trailingslashit(
                $source_directory
            ) . $size_data['file'];

            self::deleteNextGenFile($thumbnail_file);
        }
    }

    /**
     * Delete generated WebP and AVIF files for a source image.
     *
     * @param string $source_file Source image file.
     *
     * @return void
     */
    private static function deleteNextGenFile($source_file)
    {
        if (empty($source_file)) {
            return;
        }

        $source_file = wp_normalize_path($source_file);

        $nextgen_directory = self::getNextGenDirectory(
            $source_file
        );

        $filename = wp_basename($source_file);

        $filename_without_extension = pathinfo(
            $filename,
            PATHINFO_FILENAME
        );

        foreach (['webp', 'avif'] as $format) {
            $nextgen_file = trailingslashit(
                $nextgen_directory
            ) . $filename_without_extension . '.' . $format;

            if (file_exists($nextgen_file)) {
                wp_delete_file($nextgen_file);
            }
        }
    }

    /**
     * Save image optimization settings via AJAX.
     *
     * @return void
     */
    public function saveImageOptimizationSettings()
    {
        check_ajax_referer('wpmf_nonce', 'wpmf_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => __('You are not allowed to save image optimization settings.', 'wpmf')
            ]);
        }

        if (!isset($_POST['image_optimization']) || !is_array($_POST['image_optimization'])) {
            wp_send_json_error([
                'message' => __('Invalid image optimization settings.', 'wpmf')
            ]);
        }

        $raw_input = wp_unslash($_POST['image_optimization']);
        $image_optimization = array();

        if (isset($raw_input['auto_optimize_uploads'])) {
            $image_optimization['auto_optimize_uploads'] = absint($raw_input['auto_optimize_uploads']);
        }

        if (isset($raw_input['processing_library'])) {
            $image_optimization['processing_library'] = sanitize_key($raw_input['processing_library']);
        }

        if (isset($raw_input['compression_level'])) {
            $image_optimization['compression_level'] = sanitize_key($raw_input['compression_level']);
        }

        if (isset($raw_input['do_not_convert_png'])) {
            $image_optimization['do_not_convert_png'] = absint($raw_input['do_not_convert_png']);
        }

        if (isset($raw_input['output_formats']) && is_array($raw_input['output_formats'])) {
            $image_optimization['output_formats'] = array_map('sanitize_key', $raw_input['output_formats']);
        }

        if (isset($raw_input['thumbnail_sizes']) && is_array($raw_input['thumbnail_sizes'])) {
            $image_optimization['thumbnail_sizes'] = array_map('sanitize_key', $raw_input['thumbnail_sizes']);
        }

        if (isset($raw_input['excluded_folders'])) {
            $excluded_folders = json_decode($raw_input['excluded_folders'], true);
            $image_optimization['excluded_folders'] = is_array($excluded_folders) ? array_map('intval', $excluded_folders) : array();
        }

        update_option('wpmf_image_optimization', wp_json_encode($image_optimization));

        do_action('wpmf_image_optimization_settings_saved');

        wp_send_json_success([
            'message' => __('Image optimization settings saved.', 'wpmf'),
            'success' => true
        ]);
    }
}
