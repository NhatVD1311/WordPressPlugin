<?php
/**
 * Plugin updater integration
 *
 * @package WP Media Folder
 */

namespace Joomunited\WPMediaFolder;

defined('ABSPATH') || die('No direct script access allowed!');

/**
 * Class WpmfUpdater
 *
 * Initializes the update mechanism for the WP Media Folder plugin.
 */
class WpmfUpdater
{
    /**
     * Initialize updater
     *
     * @return void
     */
    public static function init()
    {
        if (!is_admin()) {
            return;
        }

        // Define base URL if not already defined
        if (!defined('JU_BASE')) {
            define('JU_BASE', 'https://www.joomunited.com/');
        }

        $remote_updateinfo = JU_BASE . 'juupdater_files/wp-media-folder.json';

        // Load updater library
        $updater_file = WP_MEDIA_FOLDER_PLUGIN_DIR . 'juupdater/juupdater.php';
        if (file_exists($updater_file)) {
            require_once $updater_file;
        }

        // Initialize update checker
        if (class_exists('\Jufactory')) {
            \Jufactory::buildUpdateChecker(
                $remote_updateinfo,
                WPMF_FILE
            );
        }
    }
}
