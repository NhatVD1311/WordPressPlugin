<?php

namespace JET_ABAF\Formbuilder_Plugin;

class Manage_Calculated_Data {

	public function __construct() {

		// Macros %ADVANCED_PRICE% procession in the calculator field.
		add_filter( 'jet-engine/calculated-data/ADVANCED_PRICE', function ( $macros ) {
			return $macros;
		} );

		// Macros %BOOKING_TIME% procession in the calculator field.
		add_filter( 'jet-engine/calculated-data/BOOKING_TIME', function ( $macros ) {
			return $macros;
		} );

		add_filter( 'jet-form-builder/field-data/calculated-field', [ $this, 'prepare_calc_description' ] );
		add_filter(
			'jet-form-builder/gateways/trusted-price/resolve-macro',
			[ $this, 'resolve_gateway_price_macro' ],
			10,
			3
		);

	}

	/**
	 * Recalculate the advanced booking price for secure gateway payments.
	 *
	 * @param mixed  $value      Value resolved by another integration.
	 * @param string $macro_type Calculated Field macro type.
	 * @param string $field_name Check-in/out field or capacity field referenced by the macro.
	 *
	 * @return mixed
	 * @throws \Jet_Form_Builder\Exceptions\Gateway_Exception
	 */
	public function resolve_gateway_price_macro( $value, $macro_type, $field_name ) {

		if ( null !== $value ) {
			return $value;
		}

		$macro_type = strtoupper( $macro_type );

		if ( 'BOOKING_UNITS' === $macro_type ) {
			return $this->resolve_gateway_units_macro( $field_name );
		}

		if ( 'ADVANCED_PRICE' !== $macro_type ) {
			return $value;
		}

		$actions = $this->get_booking_actions();

		if (
			1 !== count( $actions )
			|| $field_name !== ( $actions[0]->settings['booking_dates_field'] ?? '' )
		) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The ADVANCED_PRICE macro must reference the Check-in/Check-out date field of exactly one Apartment Booking action.', 'jet-booking' )
			);
		}

		$booking = $this->get_booking_data( $actions[0] );
		$post_id = $booking['apartment_id'];

		if ( ! jet_abaf()->tools->is_booking_post( $post_id ) ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The booking price source is not a valid booking instance.', 'jet-booking' )
			);
		}

		wp_cache_delete( jet_abaf()->settings::CONTEXT_KEY, 'jet-booking' );
		wp_cache_set( jet_abaf()->settings::CONTEXT_KEY, $post_id, 'jet-booking', 60 );

		try {
			$price = new \JET_ABAF\Price( $post_id );

			return $price->get_booking_price( [
				'apartment_id'   => $post_id,
				'check_in_date'  => $booking['check_in_date'],
				'check_out_date' => $booking['check_out_date'],
			] );
		} catch ( \Exception $exception ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'Unable to calculate the trusted JetBooking price.', 'jet-booking' )
			);
		}

	}

	/**
	 * Recalculate the submitted units count for secure gateway payments.
	 *
	 * Re-derives the requested capacity the same way `Apartment_Booking_Trait::run_action()`
	 * does, so the priced quantity can never diverge from the quantity actually booked.
	 *
	 * @param string $field_name Capacity field referenced by the macro.
	 *
	 * @return int
	 * @throws \Jet_Form_Builder\Exceptions\Gateway_Exception
	 */
	public function resolve_gateway_units_macro( $field_name ) {

		$actions = $this->get_booking_actions();

		if (
			1 !== count( $actions )
			|| $field_name !== ( $actions[0]->settings['booking_capacity_field'] ?? '' )
		) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The BOOKING_UNITS macro must reference the Units Capacity field of exactly one Apartment Booking action.', 'jet-booking' )
			);
		}

		$action  = $actions[0];
		$enabled = ! empty( $action->settings['booking_multiple_units'] )
			&& filter_var( $action->settings['booking_multiple_units'], FILTER_VALIDATE_BOOLEAN );

		if ( ! $enabled ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The BOOKING_UNITS macro requires "Allow booking several units" to be enabled on the Apartment Booking action.', 'jet-booking' )
			);
		}

		$requested_units = absint( jet_fb_context()->get_value( $field_name ) );
		$requested_units = max( 1, $requested_units );

		$booking = $this->get_booking_data( $action );

		// Mirror run_action(): capacity is only meaningful when the apartment
		// actually has more than one physical unit; otherwise exactly 1 is booked.
		$units = jet_abaf()->db->get_apartment_units( $booking['apartment_id'] );

		if ( empty( $units ) || count( $units ) <= 1 ) {
			return 1;
		}

		// Match the availability window used by run_action(): if the check-in/out
		// dates collapse to the same day, extend check-out by 12 hours, then shift
		// check-in forward by one second so the current day is not treated as booked.
		if ( $booking['check_in_date'] >= $booking['check_out_date'] ) {
			$booking['check_out_date'] = $booking['check_in_date'] + 12 * HOUR_IN_SECONDS;
		}

		$booking['check_in_date']++;

		$available_units       = jet_abaf()->db->get_available_units( $booking );
		$available_units_count = count( (array) $available_units );

		if ( $available_units_count < $requested_units ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				sprintf(
					/* translators: available units number */
					__( 'Not enough available units. Only %d available.', 'jet-booking' ),
					$available_units_count
				)
			);
		}

		return $requested_units;

	}

	/**
	 * Build the booking data used by the configured Apartment Booking action.
	 *
	 * @param object $action Apartment Booking action.
	 *
	 * @return array
	 * @throws \Jet_Form_Builder\Exceptions\Gateway_Exception
	 */
	private function get_booking_data( $action ) {

		$apartment_field = $action->settings['booking_apartment_field'] ?? '';
		$dates_field     = $action->settings['booking_dates_field'] ?? '';
		$post_id         = jet_abaf()->db->get_initial_booking_item_id(
			absint( jet_fb_context()->get_value( $apartment_field ) )
		);

		if ( ! $apartment_field || ! $dates_field || ! $post_id ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The Apartment Booking action has incomplete price source settings.', 'jet-booking' )
			);
		}

		// The price is derived from the same submitted Apartment ID that run_action()
		// uses to create the booking, so the paid amount always matches the booked
		// object. Post/referrer context is intentionally not consulted here: it is
		// client-controllable and is no longer a trusted price source.
		if ( ! jet_abaf()->tools->is_booking_post( $post_id ) ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The selected Apartment ID does not belong to a valid booking instance.', 'jet-booking' )
			);
		}

		$dates = $this->get_booking_dates( $action, $dates_field );

		return [
			'apartment_id'   => $post_id,
			'check_in_date'  => $dates[0],
			'check_out_date' => $dates[1],
		];

	}

	/**
	 * Parse the submitted dates using the Check-in/Check-out field settings.
	 *
	 * @param object $action     Apartment Booking action.
	 * @param string $field_name Check-in/out field name.
	 *
	 * @return int[]
	 * @throws \Jet_Form_Builder\Exceptions\Gateway_Exception
	 */
	private function get_booking_dates( $action, $field_name ) {

		if ( jet_fb_context()->has_field( $field_name . '__in' ) ) {
			$date_in  = jet_fb_context()->get_value( $field_name . '__in' );
			$date_out = jet_fb_context()->get_value( $field_name . '__out' );
			$dates    = [ $date_in, $date_out ?: $date_in ];
		} else {
			$value = jet_fb_context()->get_value( $field_name );
			$dates = is_string( $value ) ? explode( ' - ', $value ) : [];

			if ( 1 === count( $dates ) ) {
				$dates[] = $dates[0];
			}
		}

		if ( 2 !== count( $dates ) || empty( $dates[0] ) || empty( $dates[1] ) ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'Unable to resolve the booking dates for the secure payment amount.', 'jet-booking' )
			);
		}

		$separator = $action->getFieldSettingsByName( $field_name, 'cio_fields_separator', '-' );
		$separator = 'space' === $separator ? ' ' : $separator;
		$format    = '!' . $action->getFieldSettingsByName( $field_name, 'cio_fields_format', 'Y-m-d' );
		$format    = jet_abaf()->tools->date_format_js_to_php( $format );
		$dates     = array_map(
			function ( $date ) use ( $separator ) {
				return str_replace( $separator, '-', $date );
			},
			$dates
		);

		$check_in  = \DateTime::createFromFormat( $format, $dates[0] );
		$check_out = \DateTime::createFromFormat( $format, $dates[1] );
		$check_in  = $check_in ? $check_in->getTimestamp() : strtotime( $dates[0] );
		$check_out = $check_out ? $check_out->getTimestamp() : strtotime( $dates[1] );

		if ( ! $check_in || ! $check_out ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'Unable to parse the booking dates for the secure payment amount.', 'jet-booking' )
			);
		}

		// A reversed range would price fewer nights than the booking actually reserves.
		if ( $check_out < $check_in ) {
			throw new \Jet_Form_Builder\Exceptions\Gateway_Exception(
				__( 'The booking check-out date cannot be earlier than the check-in date.', 'jet-booking' )
			);
		}

		return [ $check_in, $check_out ];

	}

	/**
	 * Find configured Apartment Booking actions.
	 *
	 * @return array
	 */
	private function get_booking_actions() {

		$matches = [];

		foreach ( jet_fb_action_handler()->get_all() as $action ) {
			if ( 'apartment_booking' !== $action->get_id() ) {
				continue;
			}

			$matches[] = $action;
		}

		return $matches;

	}

	/**
	 * Prepare calc descriptions.
	 *
	 * Add booking related calculated field macros descriptions.
	 *
	 * @since 2.2.5
	 * @since 3.2.0 Changed template include.
	 *
	 * @param array $content List of calculated field description.
	 *
	 * @return mixed
	 */
	public function prepare_calc_description( $content ) {

		ob_start();

		include JET_ABAF_PATH . 'includes/compatibility/packages/jet-engine/templates/admin/macros-list.php';

		$content['field_desc'] .= ob_get_clean() . '<br>';

		return $content;

	}

}
