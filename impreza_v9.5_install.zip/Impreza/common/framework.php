<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * UpSolution Themes Framework
 *
 * Should be included in global context.
 */

global $us_template_directory, $us_stylesheet_directory, $us_template_directory_uri, $us_stylesheet_directory_uri;

$us_template_directory = get_template_directory();
$us_stylesheet_directory = get_stylesheet_directory();
$us_template_directory_uri = get_template_directory_uri();
$us_stylesheet_directory_uri = get_stylesheet_directory_uri();

// Define theme constants
if ( ! defined( 'US_THEMENAME' ) OR ! defined( 'US_THEMEVERSION' ) ) {

	$us_theme = wp_get_theme();

	if ( is_child_theme() ) {
		$us_theme = wp_get_theme( $us_theme->get( 'Template' ) );
	}
	if ( ! defined( 'US_THEMENAME' ) ) {
		define( 'US_THEMENAME', $us_theme->get( 'Name' ) );
	}
	if ( ! defined( 'US_THEMEVERSION' ) ) {
		define( 'US_THEMEVERSION', $us_theme->get( 'Version' ) );
	}
	if ( ! defined( 'US_THEME_BETA' ) AND strpos( $us_theme->get( 'Version' ), 'beta' ) !== FALSE ) {
		define( 'US_THEME_BETA', TRUE );
	}
	if ( ! defined( 'US_HELP_PORTAL_URL' ) ) {
		$help_portal_url = defined( 'US_DEV_HELP' )
			? US_DEV_HELP
			: 'https://us-themes.com';
		define( 'US_HELP_PORTAL_URL', $help_portal_url );
	}

	unset( $us_theme );
}

// Reinit files location
global $us_files_search_paths, $us_file_paths;
unset( $us_files_search_paths );
unset( $us_file_paths );

if ( ! defined( 'US_CORE_VERSION' ) ) {

	// Enqueue FALLBACK styles and scripts
	add_action( 'wp_enqueue_scripts', 'us_theme_styles_scripts', 12 );

	function us_theme_styles_scripts() {

		// CSS
		wp_enqueue_style( 'us-fallback-style', get_template_directory_uri() . '/css/style.min.css', array(), US_THEMEVERSION, 'all' );
		wp_enqueue_style( 'us-fallback-header', get_template_directory_uri() . '/common/css/base/header-hor.css', array(), US_THEMEVERSION, 'all' );
		wp_enqueue_style( 'us-fallback-theme', get_template_directory_uri() . '/css/theme.css', array(), US_THEMEVERSION, 'all' );

		// JS
		wp_enqueue_script( 'us-fallback-core', get_template_directory_uri() . '/js/us.core.min.js', array( 'jquery' ), US_THEMEVERSION, TRUE );
	}
}

// Common helper functions
// Dev note: always include this file for compatibility with older US Core versions
require $us_template_directory . '/common/functions/helpers.php';

// Language packs of the theme from UpSolution Help Portal
require $us_template_directory . '/common/functions/language-packs.php';

// Include plugins that relate to translations and can be used in helpers.php
if ( defined( 'US_CORE_DIR' ) ) {
	global $us_theme_supports;
	foreach ( us_arr_path( $us_theme_supports, 'translate_plugins', array() ) as $translate_plugin_path ) {
		if ( $translate_plugin_path === NULL OR ! file_exists( US_CORE_DIR . $translate_plugin_path ) ) {
			continue;
		}
		include US_CORE_DIR . $translate_plugin_path;
	}
}

/**
 * Theme Setup
 */
add_action( 'after_setup_theme', 'us_theme_setup', 9 );
function us_theme_setup() {
	global $us_template_directory;

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'post-formats', array(
		'video',
		'gallery',
		'audio',
		'link',
	) );
	add_theme_support( 'html5', array(
		'comment-list',
		'comment-form',
		'search-form',
		'gallery',
		'caption',
		'script',
		'style',
	) );

	// Add Block Editor (Gutenberg) features, if it is enabled
	if ( us_get_option( 'block_editor' ) ) {
		add_theme_support( 'align-wide' );
		add_theme_support( 'responsive-embeds' );

		// or disable enabled by default features
	} else {
		remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' ); // extra SVGs after <body>
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' ); // extra style.min.css
		remove_theme_support( 'core-block-patterns' );
		remove_theme_support( 'widgets-block-editor' );
	}

	// Menu custom markup
	require $us_template_directory . '/common/functions/menu.php';

	// Comments custom markup
	require $us_template_directory . '/common/functions/comments.php';

	// Admin specific functions
	if ( is_admin() OR ( defined( 'WP_CLI' ) AND WP_CLI ) ) {
		require $us_template_directory . '/common/admin/functions/updater.php';
		require $us_template_directory . '/common/admin/functions/theme-updater.php';
		require $us_template_directory . '/common/admin/functions/translations.php';
		require $us_template_directory . '/common/admin/functions/functions.php';
		require $us_template_directory . '/common/admin/functions/addons.php';
		require $us_template_directory . '/common/admin/functions/about.php';
		require $us_template_directory . '/common/admin/functions/setup-wizard.php';

		// Setup Wizard steps as WP-CLI commands
		if ( defined( 'WP_CLI' ) AND WP_CLI ) {
			require $us_template_directory . '/common/admin/functions/cli.php';
		}
	}

	// Custom image sizes
	$custom_image_sizes = us_get_option( 'img_size' );
	if ( is_array( $custom_image_sizes ) ) {
		foreach ( $custom_image_sizes as $size_index => $size ) {
			$crop = ( ! empty( $size['crop'][0] ) );
			$crop_str = ( $crop ) ? '_crop' : '';
			$width = ( ! empty( $size['width'] ) AND (int) $size['width'] > 0 ) ? (int) $size['width'] : 0;
			$height = ( ! empty( $size['height'] ) AND (int) $size['height'] > 0 ) ? (int) $size['height'] : 0;

			add_image_size( 'us_' . $width . '_' . $height . $crop_str, $width, $height, $crop );
		}
	}

	// Remove [...] from excerpt
	add_filter( 'excerpt_more', 'us_excerpt_more' );
	function us_excerpt_more( $more ) {
		return '...';
	}

	// Theme localization
	us_maybe_load_theme_textdomain();

	// Set the maximum size for the theme
	$GLOBALS['content_width'] = (int) us_get_option( 'site_content_width' );

	// Set default embed sizes
	add_filter( 'embed_defaults', 'us_embed_defaults' );
	function us_embed_defaults() {
		return array( 'width' => 640, 'height' => 360 );
	}

	// Include plugins support files
	global $us_theme_supports;
	if ( ! isset( $us_theme_supports ) ) {
		$us_theme_supports = array();
	}
	if ( defined( 'US_CORE_DIR' ) ) {
		if ( ! isset( $us_theme_supports['plugins'] ) ) {
			$us_theme_supports['plugins'] = array();
		}
		foreach ( $us_theme_supports['plugins'] as $us_plugin_name => $us_plugin_path ) {
			if ( $us_plugin_path === NULL OR ! file_exists( US_CORE_DIR . $us_plugin_path ) ) {
				continue;
			}
			include US_CORE_DIR . $us_plugin_path;
		}
	}
}

// Remove built-in WordPress image sizes, which cannot be edited by UI.
// This improves control of image sizes, which can be easily managed on Theme Options > Image Sizes
add_filter( 'intermediate_image_sizes', 'delete_intermediate_image_sizes' );
function delete_intermediate_image_sizes( $sizes ) {
	return array_diff( $sizes, array( 'medium_large', '1536x1536', '2048x2048' ) );
}

// Change Big Image Size Threshold
add_filter( 'big_image_size_threshold', function() {
	return (int) us_get_option( 'big_image_size_threshold', 2560 );
} );

// Disable CSS file of WPML plugin
if ( ! defined( 'ICL_DONT_LOAD_LANGUAGE_SELECTOR_CSS' ) ) {
	define( 'ICL_DONT_LOAD_LANGUAGE_SELECTOR_CSS', TRUE );
}

// Additional file types for uploading to Media Library
add_filter( 'upload_mimes', 'us_upload_file_types' );
function us_upload_file_types( $mimes ) {
	$mimes['svg'] = 'image/svg+xml';
	// Note: the types are registered in RFC 8081, the "application/font-woff" ones are outdated
	$mimes['woff'] = 'font/woff';
	$mimes['woff2'] = 'font/woff2';

	return $mimes;
}

// Remove executable content from uploaded SVG files, since they are opened as documents
add_filter( 'wp_handle_upload_prefilter', 'us_sanitize_svg_upload' );
add_filter( 'wp_handle_sideload_prefilter', 'us_sanitize_svg_upload' );
function us_sanitize_svg_upload( $file ) {

	// Skip files, which are rejected before
	if ( ! empty( $file['error'] ) ) {
		return $file;
	}

	if ( strtolower( (string) pathinfo( (string) ( $file['name'] ?? '' ), PATHINFO_EXTENSION ) ) !== 'svg' ) {
		return $file;
	}

	// Users, who are allowed to post any HTML, can upload SVG files as they are
	if ( function_exists( 'current_user_can' ) AND current_user_can( 'unfiltered_html' ) ) {
		return $file;
	}

	$error_message = us_translate( 'Sorry, this file type is not permitted for security reasons.' );

	if ( ! class_exists( 'DOMDocument' ) OR ! is_readable( $file['tmp_name'] ) ) {
		$file['error'] = $error_message;

		return $file;
	}

	$dom = new DOMDocument;

	// Note: the LIBXML_NOENT flag is not used on purpose, so entities are not expanded
	if ( ! @$dom->loadXML( ltrim( (string) file_get_contents( $file['tmp_name'] ) ), LIBXML_NONET ) ) {
		$file['error'] = $error_message;

		return $file;
	}

	// Reject files having a custom DTD, which can define entities to smuggle any content
	if ( $dom->doctype instanceof DOMDocumentType ) {
		if ( ! empty( $dom->doctype->internalSubset ) ) {
			$file['error'] = $error_message;

			return $file;
		}
		$dom->removeChild( $dom->doctype );
	}

	if (
		! $dom->documentElement instanceof DOMElement
		OR strtolower( $dom->documentElement->localName ) !== 'svg'
	) {
		$file['error'] = $error_message;

		return $file;
	}

	// Elements, which can execute scripts or embed another document
	$denied_elements = array( 'script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'annotation-xml' );

	/**
	 * Attributes, which can contain a URL: the WordPress list extended with the SVG
	 * animation ones, since <animate attributeName="href" to="..."> changes a link.
	 * Note: attributes are matched by a local name, so any xlink prefix is covered.
	 */
	$uri_attributes = array_merge( wp_kses_uri_attributes(), array( 'from', 'to', 'values', 'by' ) );

	// The "data" scheme is checked separately below, since raster images are kept
	$allowed_protocols = array_merge( wp_allowed_protocols(), array( 'data' ) );

	// XSLT turns a file into an arbitrary document with scripts: either via the "xml-stylesheet"
	// processing instruction or when the file itself is used as a stylesheet
	$xslt_namespace = 'http://www.w3.org/1999/XSL/Transform';

	$xpath = new DOMXPath( $dom );
	foreach ( iterator_to_array( $xpath->query( '//processing-instruction()' ) ) as $instruction ) {
		if ( $instruction->parentNode instanceof DOMNode ) {
			$instruction->parentNode->removeChild( $instruction );
		}
	}

	foreach ( iterator_to_array( $dom->getElementsByTagName( '*' ) ) as $element ) {

		$element_name = strtolower( $element->localName );

		if (
			(
				in_array( $element_name, $denied_elements, TRUE )
				OR $element->namespaceURI === $xslt_namespace

				// Animation of a link, which can switch it to a "javascript:" URL
				OR (
					in_array( $element_name, array( 'animate', 'set' ), TRUE )
					AND preg_match( '~(^|:)href$~i', trim( (string) $element->getAttribute( 'attributeName' ) ) )
				)
			)
			AND $element->parentNode instanceof DOMNode
		) {
			$element->parentNode->removeChild( $element );
			continue;
		}

		foreach ( iterator_to_array( $element->attributes ) as $attribute ) {

			$attribute_name = strtolower( $attribute->localName ?: $attribute->nodeName );
			$value = (string) $attribute->nodeValue;

			if (
				// Event handlers: onload, onclick, etc.
				strpos( $attribute_name, 'on' ) === 0

				// Attributes of XSLT, like "xsl:version" of a simplified stylesheet
				OR $attribute->namespaceURI === $xslt_namespace

				OR (
					in_array( $attribute_name, $uri_attributes, TRUE )
					AND (
						// Schemes, which can execute code
						wp_kses_bad_protocol( $value, $allowed_protocols ) !== $value

						// Data URI of everything except raster images
						OR (
							stripos( ltrim( $value ), 'data:' ) === 0
							AND ! preg_match( '~^\s*data:image/(png|jpe?g|gif|webp|bmp);~i', $value )
						)
					)
				)
			) {
				$element->removeAttributeNode( $attribute );
			}
		}
	}

	file_put_contents( $file['tmp_name'], (string) $dom->saveXML() );

	return $file;
}

/**
 * Fix the width and height attributes of <img> with SVG source
 *
 * Without this filter, the width and height are set to "1" since
 * WordPress core can't seem to figure out an SVG file's dimensions.
 */
if ( ! is_admin() OR wp_doing_ajax() ) {
	add_filter( 'image_downsize', 'us_fix_svg_size_attributes', 10, 3 );
}
function us_fix_svg_size_attributes( $out, $id, $size ) {

	// Note: the result of other filters is passed through, so they are not overridden
	if ( get_post_mime_type( $id ) !== 'image/svg+xml' ) {
		return $out;
	}

	// Get width and height values for provided size name
	if ( function_exists( 'us_get_image_size_params' ) AND is_string( $size ) ) {
		$size_array = us_get_image_size_params( $size );
	} else {
		$size_array = array(
			'width' => NULL,
			'height' => NULL,
		);
	}

	return array( wp_get_attachment_url( $id ), $size_array['width'], $size_array['height'], FALSE );
}
