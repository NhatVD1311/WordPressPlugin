<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Translations of the theme in the admin area: a notice when updated translations are available.
 *
 * The packs themselves are installed by WordPress (see common/functions/language-packs.php), the
 * "Update Translations" button submits the same form as Dashboard > Updates does.
 */

if ( ! function_exists( 'us_get_translation_language_name' ) ) {
	/**
	 * Get the name of a language in the language itself: Deutsch, Français
	 *
	 * The list of WordPress.org is used only if it is cached already, so the admin pages do not wait
	 * for it; otherwise the intl extension or the locale code
	 *
	 * @param string $locale
	 *
	 * @return string
	 */
	function us_get_translation_language_name( $locale ) {
		$translations = get_site_transient( 'available_translations' );
		if ( ! empty( $translations[ $locale ]['native_name'] ) ) {
			return $translations[ $locale ]['native_name'];
		}
		if ( class_exists( 'Locale' ) ) {
			// The region is shown only where it tells the variants of a language apart: Português do Brasil
			$language = Locale::getPrimaryLanguage( $locale );
			$name = in_array( $language, array( 'pt', 'zh' ), TRUE )
				? Locale::getDisplayName( $locale, $locale )
				: Locale::getDisplayLanguage( $locale, $locale );
			if ( $name AND $name !== $locale ) {
				return function_exists( 'mb_strtoupper' )
					? mb_strtoupper( mb_substr( $name, 0, 1 ) ) . mb_substr( $name, 1 )
					: ucfirst( $name );
			}
		}

		return $locale;
	}
}

if ( ! function_exists( 'us_output_translations_update_form' ) ) {
	/**
	 * The "Update Translations" button: the form of Dashboard > Updates, so WordPress installs the packs
	 * itself (asking for the file system credentials if needed) together with the other translations
	 *
	 * On multisite the updates screen is in Network Admin: the one of a site redirects there and loses the action
	 */
	function us_output_translations_update_form() {
		?>
		<form method="post" action="<?= esc_url( self_admin_url( 'update-core.php?action=do-translation-upgrade' ) ) ?>" class="us-translations-update-form">
			<?php wp_nonce_field( 'upgrade-translations' ) ?>
			<button type="submit" class="button"><?= us_translate( 'Update Translations' ) ?></button>
		</form>
		<?php
	}
}

if ( ! function_exists( 'us_translations_notice' ) ) {
	add_action( is_multisite() ? 'network_admin_notices' : 'admin_notices', 'us_translations_notice' );
	/**
	 * Notice about updated translations of the theme that WordPress can not install in the background,
	 * until they are installed or the notice is dismissed
	 *
	 * Uses only the cached list of packs, so it never makes the admin pages wait for the portal
	 */
	function us_translations_notice() {
		global $pagenow;
		if (
			! current_user_can( 'update_languages' )
			// The updates screen lists the translations itself
			OR $pagenow === 'update-core.php'
		) {
			return;
		}

		$updates = us_get_language_pack_updates( /* refresh */ FALSE, /* allow_request */ FALSE );
		if ( empty( $updates ) ) {
			return;
		}

		// The notice is dismissed for each language until its pack is updated, so the pack of a newly added
		// language shows it again, even if this pack was published before the dismissed ones
		$dismissed = get_user_meta( get_current_user_id(), 'us_translations_notice_dismissed', TRUE );
		if ( ! is_array( $dismissed ) ) {
			$dismissed = array();
		}
		$new_languages = array();
		foreach ( $updates as $update ) {
			if (
				! isset( $dismissed[ $update['language'] ] )
				OR $dismissed[ $update['language'] ] < strtotime( $update['updated'] )
			) {
				$new_languages[] = $update['language'];
			}
		}
		// Checked first: the check of the background install below creates a test file in the languages
		// folder for each pack
		if ( empty( $new_languages ) ) {
			return;
		}

		// The packs installed in the background need no action: right after the site language or the theme
		// changes, and with the automatic updates of WordPress. The notice remains for the packs that need
		// the button: automatic updates are disabled, it is a VCS checkout, or there is no direct access
		// to the file system. And for all the packs if cron does not run (a blocked loopback request,
		// DISABLE_WP_CRON without a server cron): then the install job, scheduled after the theme update
		// or the site language change, and the update check of WordPress, which runs its background
		// updates, are overdue
		$next_install = wp_next_scheduled( 'us_install_language_packs' );
		$next_update_check = wp_next_scheduled( 'wp_version_check' );
		$cron_is_stalled = (
			( $next_install AND $next_install < time() - HOUR_IN_SECONDS )
			OR ( $next_update_check AND $next_update_check < time() - DAY_IN_SECONDS )
		);
		if ( ! $cron_is_stalled ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			$automatic_updater = new WP_Automatic_Updater();
			foreach ( $updates as $i => $update ) {
				if ( $automatic_updater->should_update( 'translation', (object) $update, WP_LANG_DIR ) ) {
					unset( $updates[ $i ] );
				}
			}
		}
		if ( ! array_intersect( wp_list_pluck( $updates, 'language' ), $new_languages ) ) {
			return;
		}

		$languages = array_map( 'us_get_translation_language_name', wp_list_pluck( $updates, 'language' ) );
		// The dates of the shown packs go with the link, so that exactly the shown updates are dismissed
		$dismiss_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'us_dismiss_translations_notice',
					'dismissed' => array_map( 'strtotime', wp_list_pluck( $updates, 'updated', 'language' ) ),
				),
				admin_url( 'admin-post.php' )
			),
			'us_dismiss_translations_notice'
		);

		$notice_classes = 'notice notice-warning us-translations-notice';
		// WordPress moves notices under the first heading of the page, which on the theme's About page is
		// inside .about-wrap, and .about-wrap hides notices (wp-admin/css/about.css). Inline notices stay in place
		if ( $pagenow === 'admin.php' AND isset( $_GET['page'] ) AND $_GET['page'] === 'us-home' ) {
			$notice_classes .= ' inline';
		}
		?>
		<div class="<?= esc_attr( $notice_classes ) ?>">
			<p>
				<strong><?= sprintf( __( '%s translations have been updated:', 'us' ), esc_html( apply_filters( 'us_theme_name', US_THEMENAME ) ) ) ?></strong>
				<?= esc_html( implode( ', ', $languages ) ) ?>.
			</p>
			<!-- Not a paragraph: a form inside <p> would close the paragraph before itself -->
			<div class="us-translations-notice-actions">
				<?php us_output_translations_update_form() ?>
				<a href="<?= esc_url( $dismiss_url ) ?>"><?= us_translate( 'Dismiss' ) ?></a>
			</div>
		</div>
		<style>
			.us-translations-notice-actions { display: flex; align-items: center; gap: 12px; margin: 0 0 10px; }
		</style>
		<?php
	}
}

if ( ! function_exists( 'us_dismiss_translations_notice' ) ) {
	add_action( 'admin_post_us_dismiss_translations_notice', 'us_dismiss_translations_notice' );
	/**
	 * Hide the notice for the shown languages until their packs are updated: the date of each shown pack is remembered
	 */
	function us_dismiss_translations_notice() {
		check_admin_referer( 'us_dismiss_translations_notice' );

		if ( isset( $_GET['dismissed'] ) AND is_array( $_GET['dismissed'] ) ) {
			$dismissed = get_user_meta( get_current_user_id(), 'us_translations_notice_dismissed', TRUE );
			if ( ! is_array( $dismissed ) ) {
				$dismissed = array();
			}
			foreach ( $_GET['dismissed'] as $language => $updated ) {
				// Locales of WordPress: de_DE, ary, pt_PT_ao90
				if ( preg_match( '~^[a-z]{2,3}(_[A-Z]{2})?(_[a-z0-9]+)?$~', $language ) ) {
					$dismissed[ $language ] = (int) $updated;
				}
			}
			update_user_meta( get_current_user_id(), 'us_translations_notice_dismissed', $dismissed );
		}

		wp_safe_redirect( wp_get_referer() ?: admin_url() );
		exit;
	}
}
