<?php defined( 'ABSPATH' ) or die( 'This script cannot be accessed directly.' );

$theme_url = US_HELP_PORTAL_URL . '/' . strtolower( US_THEMENAME );

// The finishing steps that may fail without breaking the installed website
$finishing_messages = array(
	'regenerate_thumbnails' => sprintf(
		__( 'Images may have a wrong size: re-save %s.', 'us' ),
		sprintf(
			'<a href="%s" target="_blank">%s &rarr; %s</a>',
			us_theme_options_url( 'image_sizes' ),
			__( 'Theme Options', 'us' ),
			us_translate( 'Image sizes' )
		)
	),
	'rebuild_index_table' => sprintf(
		__( 'Filters show no results: press "%s" in %s.', 'us' ),
		__( 'Index filter items', 'us' ),
		sprintf(
			'<a href="%s" target="_blank">%s &rarr; %s</a>',
			us_theme_options_url( 'advanced' ),
			__( 'Theme Options', 'us' ),
			_x( 'Advanced', 'Advanced Settings', 'us' )
		)
	),
);
$finishing_failed = ! empty( $_GET['finishing_failed'] )
	? explode( ',', sanitize_text_field( $_GET['finishing_failed'] ) )
	: array();

$finishing_messages = array_intersect_key( $finishing_messages, array_flip( $finishing_failed ) );
if ( $finishing_messages ) {
	array_unshift( $finishing_messages, __( 'The website is installed, but some finishing tasks failed.', 'us' ) );
}

?>
<div class="us-wizard step-success">
	<div class="us-wizard-body">
		<div class="us-wizard-step active">
			<i class="dashicons dashicons-saved"></i>
			<div class="us-wizard-step-title"><?= __( 'Installation Completed', 'us' ) ?></div>
			<a class="button button-primary" href="<?= home_url() ?>" target="_blank"><?= us_translate( 'Visit Site' ) ?></a>
			<div class="us-wizard-step-links">
				<a href="<?= $theme_url ?>/" target="_blank"><?= __( 'Online Documentation', 'us' ) ?></a>
				<a href="<?= $theme_url ?>/tickets/" target="_blank"><?= __( 'Support Portal', 'us' ) ?></a>
			</div>
			<?php if ( $finishing_messages ) { ?>
				<div class="us-wizard-notification">
					<span><?= implode( '<br>', $finishing_messages ) ?></span>
				</div>
			<?php } ?>
		</div>
	</div>
</div>
