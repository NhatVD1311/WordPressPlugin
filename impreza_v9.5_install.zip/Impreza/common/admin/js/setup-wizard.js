;( function( $, _undefined ) {
	"use strict";

	function usSetupWizard() {
		const self = this;

		// Elements
		self.$container = $( '#us-wizard' );

		// Installation Queue
		self.queue = [];

		// Import demo images as is, instead of replacing them with placeholders
		self.importImages = true;

		// Installation actions container
		self.$installationActionsList = $( '.us-wizard-install-actions-list', self.$container );

		// Load data
		var $data = $( '.us-wizard-json', self.$container );
		if ( ! $data.length ) {
			return;
		}
		self.data = JSON.parse( $data.attr( 'data-us-json' ) || '{}' ) || {};

		self.steps = self.data.steps || {};
		self.activeStepID = Object.keys( self.steps )[0];
		self.activeStep = self.steps[ self.activeStep ];

		// Top Menu
		self.$menu = $( '.us-wizard-menu', self.$container );

		// From Scratch - Preview
		self.$preview = $( '.us-wizard-preview', self.$container );
		self.$previewIframe = $( 'iframe', self.$preview );
		self.previewParams = {
			header_id: '',
			footer_id: '',
			scheme_id: '',
			font_id: ''
		};

		// Steps
		self.$steps = $( '.us-wizard-step', self.$container );

		// Demos
		self.$demos = $( '.us-wizard-demos-item', self.$container );
		self.$demoFilter = $( '.us-wizard-demos-filters', self.$container );

		// Demo preview
		self.$demoContentOptions = $( '.us-wizard-content-options', self.$container );

		// Bindable events
		self._events = {
			menuClick: self.menuClick.bind( self ),
			selectType: self.selectType.bind( self ),
			showNextStep: self.showNextStep.bind( self ),
			filterDemos: self.filterDemos.bind( self ),
			selectDemo: self.selectDemo.bind( self ),
			selectDemoContent: self.selectDemoContent.bind( self ),
			changeContentCheckboxes: self.changeContentCheckboxes.bind( self ),
			toggleContentChildren: self.toggleContentChildren.bind( self ),
			selectFromScratchParam: self.selectFromScratchParam.bind( self ),
			selectAddons: self.selectAddons.bind( self ),
			installContent: self.installContent.bind( self ),
		};

		// Common actions
		self.$menu.on( 'click', 'button.us-wizard-menu-item', self._events.menuClick );
		self.$container
			.on( 'click', '.us-wizard-setup-type-item', self._events.selectType )
			.on( 'click', 'button.action-next-step', self._events.showNextStep );

		// Filter demos
		self.$demoFilter.on( 'change', 'input', self._events.filterDemos );

		// Select Demo
		self.$demos.on( 'click', self._events.selectDemo );
		self.$container.on( 'click', '.action-select-content', self._events.selectDemoContent );
		self.$demoContentOptions.on( 'change', 'label', self._events.changeContentCheckboxes );
		self.$demoContentOptions.on( 'click', '.us-wizard-toggle-children', self._events.toggleContentChildren );

		// The tooltip is inside a label, so a click on it would toggle the checkbox
		self.$demoContentOptions.on( 'click', '.us-tooltip', ( e ) => {
			e.preventDefault();
		} );

		self.$container
			// Select From-Scratch param (Header/Footer/Colors/Fonts)
			.on( 'click', '.us-wizard-templates-item', self._events.selectFromScratchParam )
			// Select addons to install
			.on( 'click', '.us-addon > label', self._events.selectAddons )
			// Install selected website
			.on( 'click', '.action-install-website', self._events.installContent );

		self.$container.data( 'usSetupWizard', self );
	};

	const prototype = usSetupWizard.prototype;

	/**
	 * Steps
	 */
	$.extend( prototype, {

		/**
		 * @param e {Event}
		 */
		selectType: function( e ) {
			const self = this;

			var $target = $( e.target ),
				selectedType;

			if ( ! $target.hasClass( 'us-wizard-setup-type-item' ) ) {
				$target = $target.closest( '.us-wizard-setup-type-item' );
			}
			if ( $target.length ) {
				selectedType = $target.attr( 'for' );
			}
			
			if ( ! selectedType ) {
				return;
			}

			self.selectedType = selectedType;

			// Show menu items for selected type
			$( '.us-wizard-menu-item:not(.type-start, .type-from_scratch)', self.$menu ).addClass( 'hidden' ).prop( 'disabled', true );
			$( `.us-wizard-menu-item.type-${self.selectedType}`, self.$menu ).removeClass( 'hidden' );

			// Move layout part of Install step to selected type container
			var $installationActions = $( '.us-wizard-column.for_install-actions' )
				.detach();
			if ( self.selectedType == 'prebuilt' ) {
				$installationActions.appendTo('.us-wizard-step.prebuilt_with_iframe .us-wizard-step-row' );
			} else {
				$installationActions.appendTo('.us-wizard-step.from_scratch_with_iframe .us-wizard-step-row' );
			}

			// Reset installation actions
			self.installationActions = {
				plugins: {},
				content: {},
			};

			// Prepare From Scratch options
			if ( self.selectedType == 'from_scratch' ) {
				self.prepareFromScratchOptions();
			}

			// Find the first step in type and show it
			$.each( self.steps, ( stepID, step ) => {
				if ( step.type == selectedType ) {
					self.showStep( stepID );
					// break execution when first step is found
					return false;
				}
			} );
		},

		showStep: function( stepID ) {
			const self = this;

			const stepsWithIframeFromScratch = [
				'from_scratch_header',
				'from_scratch_footer',
				'from_scratch_colors',
				'from_scratch_fonts',
				'from_scratch_install'
			];
			const stepsWithIframePrebuilt = [
				'prebuilt_content',
				'prebuilt_install'
			];
			const stepsWithScrollToTemplate = [
				'from_scratch_header',
				'from_scratch_footer',
				'from_scratch_colors',
				'from_scratch_fonts'
			];

			if ( stepID == self.activeStepID ) {
				return;
			}

			self.activeStepID = stepID;
			self.activeStep = self.steps[ stepID ];

			// Hide previous active step
			self.$steps.removeClass( 'active' );

			// Show the current step
			if ( stepsWithIframeFromScratch.includes( stepID ) ) {
				self.$steps.filter( '.from_scratch_with_iframe' ).addClass( 'active' );

			} else if ( stepsWithIframePrebuilt.includes( stepID ) ) {
				self.$steps.filter( '.prebuilt_with_iframe' ).addClass( 'active' );

			} else {
				self.$steps.filter( '.' + self.activeStepID ).addClass( 'active' );
			}

			// Set menu item active
			$( `[data-step-id="${self.activeStepID}"]`, self.$menu )
				.addClass( 'active' )
				.removeAttr( 'disabled' )
				.siblings( '.us-wizard-menu-item' )
				.removeClass( 'active' );

			// Replace step name in main container class
			self.$container.removeClass( ( index, className ) => {
				return ( className.match( /(^|\s)step-\S+/g ) || [] ).join( ' ' );
			} );
			self.$container.addClass( 'step-' + stepID );

			if ( stepsWithScrollToTemplate.includes( stepID ) ) {
				// removing 'from_scratch_' from step ID to get the selected item class
				var templateClass = stepID.substr( 'from_scratch_'.length ),
					$activeItem = $( `.us-wizard-templates-list.for_${templateClass}` )
						.find( '.us-wizard-templates-item.active' ),
					scrollTo = 0;

				if ( $activeItem.length ) {
					scrollTo = ( $activeItem.offset().top - $( '#wpadminbar' ).innerHeight() - 10 ) // padding in the list
				}

				$( 'html, body' ).animate( { scrollTop: scrollTo }, 200 );

			} else {
				$( 'html, body' ).animate( { scrollTop: 0 }, 200 );
			}

			/*
			 * Additional actions for special steps
			 */

			// Disable all menu items for the Success step
			if ( stepID === 'prebuilt_success' || stepID === 'from_scratch_success' ) {
				$( '.us-wizard-menu-item', self.$menu )
					.prop( 'disabled', true )
					.removeClass( 'active' );
			}

			// When selecting header of footer, scroll the preview to see what is selected
			if ( stepID === 'from_scratch_header' || stepID === 'from_scratch_footer' ) {
				self._scrollToElement( stepID.substr( -6 ) );
			}

			// Hide all menu items when going back to start (except the first menu item)
			if ( stepID === 'setup_type' ) {
				$( '.us-wizard-menu-item:not(.type-start)', self.$menu ).addClass( 'hidden' );
			}
		},

		/**
		 * @param e {Event}
		 */
		menuClick: function( e ) {
			// Set active selected step
			this.showStep( $( e.currentTarget ).data( 'step-id' ) );
		},

		/**
		 * Next step action
		 *
		 * @param e {Event}
		 */
		showNextStep: function() {
			const self = this;
			var currentStepFound = false;

			// Find the next step and show it
			$.each( self.steps, ( stepID, step ) => {
				// Locate the current step in cycle...
				if ( stepID == self.activeStepID ) {
					// ... mark that cycle went through the current step...
					currentStepFound = true;
					// ... and go to the next item in cycle
					return;
				}
				// If current step was found in previous iteration of cycle...
				if ( currentStepFound ) {
					// ... this is the next step related to current, so show it...
					self.showStep( stepID );
					// ... and break execution
					return false;
				}
			} );
		},

	} );

	/**
	 * Functional for the Prebuilt
	 */
	$.extend( prototype, {
		/**
		 * Select website and insert its preview
		 *
		 * @param e {Event}
		 */
		selectDemo: function( e ) {
			const self = this;
			var $target = $( e.target ),
				$demoItem = $target.closest( '.us-wizard-demos-item' ),
				demoID = $demoItem.data( 'demo-id' ),
				$previewOptions = $( `#demo_content_${demoID}`, self.$demos ) || '',
				demoTitle = $demoItem.find( '.us-wizard-demos-item-title' ).html(),
				previewLink = $demoItem.find( 'a' ).attr( 'href' ),
				$previewTitleAnchor = $( '.us-wizard-step.prebuilt_with_iframe .us-wizard-step-title a', self.$container ),
				$previewFrame = $( '.us-wizard-step.prebuilt_with_iframe iframe', self.$container ),
				previewFrameSrc = $previewFrame.length ? $previewFrame.attr( 'src' ) : '',
				$previewPreloader = $( '.us-wizard-step.prebuilt_with_iframe .g-preloader', self.$container );

			if ( $target.is( 'a' ) ) {
				return;
			}

			self.selectedDemo = demoID;

			// Build preview
			// If Iframe is not showing selected Demo preview already - rebuild the Iframe
			if ( previewFrameSrc != previewLink ) {
				// If another Demo preview was shown in Iframe before - remove the Iframe and show Preloader
				if ( $previewFrame.length ) {
					$previewPreloader.show();
					$previewFrame.remove();
				}

				// Rebuild the Iframe and insert it after the browser bar imitating div
				$previewFrame = $( `<iframe src="${previewLink}?us_setup_wizard_prebuilt_preview=1" frameborder="0"></iframe>` );
				$previewFrame.insertAfter( '.us-wizard-step.prebuilt_with_iframe .us-wizard-preview-bar' );

				// Set the preview link text and URL
				$previewTitleAnchor.html( demoTitle ).attr( 'href', previewLink );

				// Remove Preloader after the Iframe is loaded
				$previewFrame.load( () => {
					$previewPreloader.hide();
				});
			}

			// Set the Content Options checkboxes for selected Demo
			self.$demoContentOptions.html( $previewOptions.html() );

			self.showNextStep();
		},

		/**
		 * Save selected options for the prebuilt
		 */
		selectDemoContent: function() {
			const self = this;
			const $checkboxes = $( 'input[type="checkbox"]:checked', self.$demoContentOptions );

			// Goes along with every request, and adds two actions of its own: the images and their sizes
			self.importImages = $checkboxes.filter( '[name="import_images"]' ).length > 0;

			// Reset installation actions
			self.installationActions = {
				plugins: {},
				content: {},
			};

			// Append US-Core
			if ( self.data.plugins[ 'us-core' ] ) {
				self.installationActions.plugins[ 'us-core' ] = self.data.plugins[ 'us-core' ];
			}

			// The images go first: the content imported after them refers to them
			if ( self.importImages ) {
				self.installationActions.content[ 'content_images' ] = $checkboxes
					.filter( '[name="import_images"]' )
					.parent()
					.find( 'span.title' )
					.text();
			}

			// Append contents and additional plugins
			$checkboxes.each( ( _, item ) => {
				var $item = $( item ),
					name = $item.attr( 'name' ),
					title = $item.parent().find( 'span.title' ).text(),
					pluginSlug = $item.data( 'plugin' );

				if ( name === 'import_images' ) {
					return;
				}

				self.installationActions.content[ name ] = title;
				if ( pluginSlug && self.data.plugins[ pluginSlug ] ) {
					self.installationActions.plugins[ pluginSlug ] = self.data.plugins[ pluginSlug ];
				}
			} );

			// Removing children, if checked content_all
			if ( $checkboxes.filter( '[name="content_all"]' ).is( ':checked' ) ) {
				$checkboxes.filter( '.child_checkbox' ).each( ( _, item ) => {
					var $item = $( item ),
						name = $item.attr( 'name' );

					if ( self.installationActions.content[ name ] ) {
						delete self.installationActions.content[ name ];
					}
				} );
			}

			// Must be last: needs the image sizes from the imported Theme Options
			if ( self.importImages ) {
				self.installationActions.content[ 'regenerate_thumbnails' ] = ( self.data[ 'labels' ] || {} )[ 'image_sizes' ] || '';
			}

			// Prepare and output options for the next install
			self._prepareInstallation( 'prebuilt' );

			self.showNextStep();
		},

		/**
		 * Show or hide the options nested into "All content"
		 *
		 * @param e {Event}
		 */
		toggleContentChildren: function( e ) {
			const self = this;

			// The button is inside a label, whose click would toggle the checkbox
			e.preventDefault();

			var collapsed = self.$demoContentOptions.toggleClass( 'hide_children' ).hasClass( 'hide_children' );

			$( e.currentTarget ).attr( 'aria-expanded', collapsed ? 'false' : 'true' );
		},

		/**
		 * Change checkboxes on the pre-built content
		 *
		 * @param e {Event}
		 */
		changeContentCheckboxes: function( e ) {
			const self = this;
			var $target = $( e.currentTarget ),
				$button = $( '.action-select-content', self.$steps ),
				checked = true;

			// Action for select All Content
			if ( $target.hasClass( 'content' ) ) {
				self.$demoContentOptions
					.find( '.child_checkbox' )
					.prop( 'checked', $( 'input[type="checkbox"]', $target ).is( ':checked' ) );
			}

			// Action for select children of the All content
			if ( $target.hasClass( 'child' ) ) {
				self.$demoContentOptions
					.find( 'label.child input' )
					.each( ( _, item ) => {
						checked = checked && $( item ).is( ':checked' );
					} );
				self.$demoContentOptions
					.find( 'label.content input' )
					.prop( 'checked', checked );
			}

			// Disable button, if don't select any one checkbox
			$button.prop( 'disabled', ! $( 'input[type="checkbox"]', self.$demoContentOptions ).is( ':checked' ) );
		},

		/**
		 * Filter websites
		 *
		 */
		filterDemos: function() {
			const self = this;
			const value = $( 'input:radio:checked', self.$demoFilter ).val();

			self.$demos
				.addClass('hidden')
				.filter( `[data-tags^="${value}"], [data-tags*="${value}"]` )
				.removeClass('hidden');

			// Reset items, if filter do not selected
			if ( value === 'all' ) {
				self.$demos.removeClass( 'hidden' );
			}
		}
	} );

	/**
	 * Functional for From scratch
	 */
	$.extend( prototype, {
		/**
		 * Insert selected template in the preview
		 *
		 * @param e {Event}
		 */
		selectFromScratchParam: function( e ) {
			const self = this;
			var $item = $( e.currentTarget ),
				$root = $( 'html', self.$previewIframe.contents() ),
				type  = $item.data( 'type' ),
				id = $item.data( 'id' ),
				$templateContent = '',
				vertical = '',
				css = '',
				script = '',
				link = '';

			// Save params for the installation
			self.previewParams[ type ] = id;

			if ( $item.hasClass('active') || ! $root.length ) {
				return;
			}

			$item
				.addClass( 'active' )
				.siblings()
				.removeClass( 'active' );

			// Get name for replace iframe html
			type = type.split( '_' )[ 0 ];

			$templateContent = $( `.us-sw-template-for-${type}[data-id="${id}"]`, $root ).first();
			css = $( ' > style', $templateContent ).first().text();
			vertical = $templateContent.data( 'vertical' ); // Using for the Header
			link = $( ` > #us-${type}-link`, $templateContent ).first().text();

			// Reset body classes for the header
			if ( type == 'header' ) {
				$root.find( 'body' )
					.removeClass( 'header_ver' )
					.addClass( 'header_hor' );

				if ( vertical ) {
					$root.find( 'body' )
						.removeClass( 'header_hor' )
						.addClass( 'header_ver' );
				}
			}

			if ( type == 'footer' ) {
				$root.find( type )
					.empty()
					.append( $templateContent.html() )
			} else {
				$root.find( '.l-canvas > ' + type )
					.after( $templateContent.html() )
					.remove();
			}

			if ( link ) {
				link = atob( link );

				$root.find( `link#us-enqueue-${type}-css` ).remove();
				$root.find( 'head' ).append( link );
			}

			if ( css ) {
				css = atob( css );

				$root.find( `style#us-${type}-css` ).remove();
				$root.find( 'head' ).append( `<style id="us-${type}-css"> ${css}</style>` );
			}

			// Header parameters and header JS re-init
			if ( type == 'header' ) {
				script = $( ' > div.sw-header-settings', $templateContent ).first().text();
				script = atob( script );
				$root.find( 'script#us-header-settings' ).remove();
				$root.find( 'head' ).append( script );
				self.$previewIframe[0].contentWindow.USReinitHeader();
			}

			self._scrollToElement( type );
		},

		/**
		 * Scroll Preview after select footer
		 *
		 * @private
		 */
		_scrollToElement: function( type ) {
			const self = this;
			var $root = $( 'body, html', self.$previewIframe.contents() ),
				scrollTop = 0;

			// Exclude other types
			if ( type !== 'header' && type !== 'footer' ) {
				return;
			}

			if ( type == 'footer' ) {
				scrollTop = $root.height();
			}

			$root.animate( { scrollTop: scrollTop }, 200 );
		},

		/**
		 * Prepare options Scratch Step to install
		 *
		 */
		prepareFromScratchOptions: function() {
			const self = this;

			if ( ! self.data.hasOwnProperty( 'translations' ) ) {
				return;
			}

			// Append US-Core
			if ( self.data.plugins[ 'us-core' ] ) {
				self.installationActions.plugins[ 'us-core' ] = self.data.plugins[ 'us-core' ];
			}

			// Get first templates
			for ( const param in self.previewParams ) {
				if ( self.previewParams[ param ] == '' ) {
					var $item = $( `[data-type="${param}"]` ).first(),
						id = $item.data( 'id' );

					if ( id !== '' ) {
						self.previewParams[ param ] = id;
					}
				}
			}

			for ( const type in self.data[ 'translations' ] ) {
				self.installationActions.content[ type ] = self.data[ 'translations' ][ type ];
			}

			self._prepareInstallation( 'from_scratch' );
		},

		selectAddons: function() {
			const self = this;

			self.installationActions.plugins = {};

			$( '.us-addons-list input[type="checkbox"]', self.$container ).each( ( _, item ) => {
				var $item = $( item ),
					plugin = $item.data( 'plugin' ),
					title = $item.data( 'title' );

				if ( ! $item.is( ':checked' ) ) {
					return;
				}

				self.installationActions.plugins[ plugin ] = title;
			} );

			self._prepareInstallation( 'from_scratch' );
		}
	} );

	/**
	 * Functional for the installation (both Prebuilt / From Scratch)
	 */
	$.extend( prototype, {
		/**
		 * State when run install
		 */
		installRunning: false,

		/**
		 * Ajax data shared by all the installation steps
		 */
		installData: null,

		/**
		 * The original label of the install button, replaced with the retry one on a failure
		 */
		installLabel: null,

		/**
		 * The finishing steps that have failed, the website itself being installed
		 */
		installWarnings: [],

		/**
		 * How far a step run in portions has got, as "imported / total": shown by the step
		 * while its next portion is on the way, kept for a retry along with `installData.offset`.
		 * Empty for the other steps.
		 */
		installProgress: '',

		/**
		 * Sort install options before install
		 *
		 * @param type
		 * @private
		 */
		_prepareInstallation: function( type ) {
			const self = this;
			var action_prefix = ( type == 'from_scratch' ) ? 'us_from_scratch_install_' : 'us_import_';

			// Reset installation options
			self.queue = [];
			self.installData = null;
			self.installWarnings = [];
			self.installProgress = '';
			self.$installationActionsList.html( '' );

			// Drop the failed state of the button, the queue is built anew
			var $installButton = $( '.action-install-website', self.$container ).removeClass( 'has_failed' );
			if ( self.installLabel !== null ) {
				$( 'span', $installButton ).text( self.installLabel );
			}

			for ( const type in self.installationActions ) {
				if ( ! self.installationActions.hasOwnProperty( type ) ) {
					continue;
				}

				for ( const item in self.installationActions[ type ] ) {
					var action = action_prefix + item,
						plugin = '';

					if ( type === 'plugins' ) {
						action = 'us_ajax_install_plugin';
						plugin = item;
					}

					self._addInstallationAction( action, self.installationActions[ type ][ item ], plugin );
				}
			}
		},

		/**
		 * Insert options to Install Step
		 *
		 * @param action
		 * @param title
		 * @param plugin
		 * @private
		 */
		_addInstallationAction: function( action, title, plugin = '' ) {
			const self = this;

			var installPlugin = '';

			if ( plugin ) {
				installPlugin = `data-install-plugin="${plugin}"`;
			}

			// Note: <small> takes the progress of a step run in portions, <span> the messages
			self.$installationActionsList.append( `
				<div class="us-wizard-install-actions-item" data-install-action-item="${action}" ${installPlugin}>
					${title}<small></small><span></span><i class="fas"></i>
				</div>
			` );

			self.queue.push( action );
		},

		/**
		 * Install selected content
		 *
		 * @param e {Event}
		 * @private
		 */
		installContent: function( e ) {
			const self = this;
			var $button = $( e.currentTarget ),
				installQueue = self.queue,
				data;

			if ( self.installRunning ) {
				return;
			}

			/**
			 * Default data for Ajax, kept between the runs: a retry after a failed step
			 * must not lose the values returned by the already completed steps
			 */
			if ( ! self.installData ) {
				self.installData = {
					demo: self.selectedDemo,
					images: self.importImages ? 1 : 0,
					// Tells the steps of this run from the ones a previous run has completed
					run_id: String( Date.now() ),
					security: self.data[ 'ajax' ].nonce
				};

				if ( self.selectedType === 'from_scratch' ) {
					// Remove variables from the Demo Import
					delete self.installData.demo;
					delete self.installData.images;
					// Extend selected preview params
					$.extend( self.installData, self.previewParams );
				}
			}

			data = self.installData;

			const labels = self.data[ 'labels' ] || {};
			const installFailedMessage = labels[ 'install_failed' ] || '';

			// Remember the original label once: on a failure the button offers to retry
			if ( self.installLabel === null ) {
				self.installLabel = $( 'span', $button ).text();
			}

			/**
			 * Mark the step as done and go on with the queue
			 *
			 * @param $installOption {jQuery}
			 * @param resData {Object}
			 */
			function succeedQueue( $installOption, resData ) {
				installQueue.shift();

				$installOption.removeClass( 'loading' ).addClass( 'loading_success' );
				$( 'span', $installOption ).text( '' );

				// The final count of a step run in portions stays on its row
				$( 'small', $installOption ).text( self.installProgress );

				// The portions belong to the finished step, the next one starts from the beginning
				delete data.offset;
				self.installProgress = '';

				// Extend data from the result,
				// used for the install Setup Wizard: Install theme options
				if ( resData ) {
					$.extend( data, resData );
				}

				processQueue();
			}

			/**
			 * Take the answer of a step: a step run in portions asks for the next portion
			 * until the server reports the last one, any other step is done at once
			 *
			 * @param $installOption {jQuery}
			 * @param resData {Object}
			 */
			function handleStepResult( $installOption, resData ) {
				var portion = resData || {};

				// A step run in portions reports how far it has got, the last portion included
				if ( portion.total ) {
					self.installProgress = portion.imported + ' / ' + portion.total;
				}

				if ( portion.total > portion.imported ) {
					data.offset = portion.imported;
					processQueue();
				} else {
					succeedQueue( $installOption, resData );
				}
			}

			/**
			 * Ask the server whether the step it has lost the connection to has finished
			 *
			 * A heavy step often outlives its request: the connection drops, while PHP goes
			 * on and completes the work. Reporting a failure right away would stop an
			 * installation that is actually running, so give the server time to confirm.
			 *
			 * @param installAction {String}
			 * @param $installOption {jQuery}
			 * @param attempt {Number}
			 * @param failMessage {String} What the server answered, if it answered at all
			 */
			function verifyStep( installAction, $installOption, attempt, failMessage ) {
				if ( attempt >= 60 ) {
					endStep( installAction, $installOption, failMessage );
					return;
				}

				$( 'span', $installOption ).text( labels[ 'install_waiting' ] || '' );

				setTimeout( () => {
					$.post( self.data[ 'ajax' ].url, {
						action: 'us_import_step_status',
						// All the plugins are installed by one action, so the slug tells them apart,
						// as does the offset for the portions of a step run in portions
						step: installAction
							+ ( data.plugin ? ':' + data.plugin : '' )
							+ ( data.offset ? ':' + data.offset : '' ),
						run_id: data.run_id,
						security: self.data[ 'ajax' ].nonce
					}, ( res ) => {
						var status = ( res.data || {} );

						if ( res.success && status.done ) {
							// The response of the step, as if its request had not been interrupted
							handleStepResult( $installOption, status.result );

							// The step has died: there is nothing left to wait for
						} else if ( res.success && status.failed ) {
							endStep( installAction, $installOption, status.message );

						} else {
							verifyStep( installAction, $installOption, attempt + 1, failMessage );
						}
					}, 'json' )
						.fail( () => {
							verifyStep( installAction, $installOption, attempt + 1, failMessage );
						} );
				}, 5000 );
			}

			/**
			 * The steps that only polish the already installed website: their failure
			 * leaves the site usable, so it must not throw away the whole installation
			 */
			const finishingActions = [ 'us_import_rebuild_index_table', 'us_import_regenerate_thumbnails' ];

			/**
			 * Turn an answer that is not valid JSON into something readable
			 *
			 * A request that got no answer at all falls back to the common message, while
			 * an answer that did arrive is shown as it is: an error page or a PHP error
			 * printed instead of the response tells much more than any wording of ours
			 *
			 * @param jqXHR {Object}
			 * @return {String}
			 */
			function serverErrorMessage( jqXHR ) {
				if ( ! jqXHR.status ) {
					return installFailedMessage;
				}

				var text = ( jqXHR.responseText || '' )
					.replace( /<[^>]*>/g, ' ' )
					.replace( /\s+/g, ' ' )
					.trim();

				return 'HTTP ' + jqXHR.status + ( text ? ': ' + text.substring( 0, 300 ) : '' );
			}

			/**
			 * Report a step that has not made it: stop the queue, or go on with a warning
			 *
			 * @param installAction {String}
			 * @param $installOption {jQuery}
			 * @param message {String}
			 */
			function endStep( installAction, $installOption, message ) {
				if ( finishingActions.indexOf( installAction ) === -1 ) {
					failQueue( $installOption, message );
					return;
				}

				installQueue.shift();
				delete data.offset;
				self.installProgress = '';
				self.installWarnings.push( installAction.replace( 'us_import_', '' ) );

				$installOption.removeClass( 'loading' ).addClass( 'loading_warning' );
				$( 'span', $installOption ).text( message || installFailedMessage );

				processQueue();
			}

			/**
			 * Mark the step as failed and stop the queue
			 *
			 * The failed action stays at the head of the queue, so that pressing
			 * the button again repeats it instead of skipping it
			 *
			 * @param $installOption {jQuery}
			 * @param message {String}
			 */
			function failQueue( $installOption, message ) {
				$installOption.removeClass( 'loading' ).addClass( 'loading_fail' );
				$( 'span', $installOption ).text( message || installFailedMessage );

				self.installRunning = false;
				$button.removeClass( 'loading' ).addClass( 'has_failed' );
				$( 'span', $button ).text( labels[ 'install_retry' ] || self.installLabel );
				$( '.us-wizard-menu-item', self.$menu ).removeAttr( 'disabled' );
			}

			function processQueue() {
				if ( installQueue.length ) {
					// Note: the action is taken off the queue once it succeeds
					var installAction = installQueue[ 0 ],
						$installOption = $( `[data-install-action-item="${installAction}"]:not(.loading_success)` ).first();

					$installOption.removeClass( 'loading_fail loading_warning' ).addClass( 'loading' );

					// Drop the message of the previous attempt, the step starts over
					$( 'span', $installOption ).text( '' );

					// How far a step run in portions has got, if it goes on with its next portion
					$( 'small', $installOption ).text( self.installProgress );

					$button
						.removeClass( 'has_failed' )
						.addClass( 'loading' );
					$( 'span', $button ).text( self.installLabel );

					// Disable menu, if start Install
					$( '.us-wizard-menu-item', self.$menu ).attr( 'disabled', 'disabled' );

					// Extend ajax action
					$.extend( data, {
						action: installAction,
					} );

					if ( installAction == 'us_ajax_install_plugin' ) {
						data.plugin = $installOption.data( 'install-plugin' );
					} else {
						// Note: the data is shared by all the steps, so do not leave it behind
						delete data.plugin;
					}

					$.post( self.data[ 'ajax' ].url, data, ( res ) => {
						if ( res.success ) {
							handleStepResult( $installOption, res.data );
						} else {
							// Note: some steps report the problem outside of `data`
							endStep( installAction, $installOption, ( res.data || {} ).message || res.message );
						}
					}, 'json' )
						.fail( ( jqXHR ) => {
							window.console && console.error(
								'Setup Wizard:', installAction, jqXHR.status, jqXHR.responseText
							);

							/**
							 * An error answer ends the step right here: the server has said its
							 * word and asking it again changes nothing. Only a request that got
							 * no answer is worth waiting for — its step is usually still running
							 * on the server, be it cut off midway or given up on by a gateway
							 */
							var gatewayStatuses = [ 502, 503, 504 ];

							if ( jqXHR.status >= 400 && gatewayStatuses.indexOf( jqXHR.status ) === -1 ) {
								endStep( installAction, $installOption, serverErrorMessage( jqXHR ) );
							} else {
								verifyStep( installAction, $installOption, 0, serverErrorMessage( jqXHR ) );
							}
						} );

				} else {
					// Install is completed
					self.installRunning = true;

					var successUrl = window.location.href + '&success=1';

					// The website is installed, but the user has to know about the leftovers
					if ( self.installWarnings.length ) {
						successUrl += '&finishing_failed=' + self.installWarnings.join( ',' );
					}

					// Update page and open success step
					setTimeout( () => {
						window.location.replace( successUrl );
					}, 500 );
				}
			};

			self.installRunning = true;
			processQueue();
		},
	} );

	// Init Setup Wizard
	$( () => new usSetupWizard() );

} )( jQuery );
