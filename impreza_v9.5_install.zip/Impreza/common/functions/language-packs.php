<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Language packs of the theme from UpSolution Help Portal
 *
 * Translations are delivered as native WordPress language packs, like the ones of WordPress.org themes:
 * the packs published on the portal are added to the "translations" of the update_themes transient,
 * so WordPress installs them into wp-content/languages/themes (us-{locale}.po, .mo and .l10n.php)
 * with its translation updates — automatically in the background or with the "Update Translations"
 * button at Dashboard > Updates. No license is needed for that.
 *
 * The transient is filtered on reading rather than on saving: WordPress checks for updates in cron,
 * admin and WP-CLI, and the packs have to get into the list in all of them.
 */

if ( ! defined( 'US_LANGUAGE_PACKS_TRANSIENT' ) ) {
	define( 'US_LANGUAGE_PACKS_TRANSIENT', 'us_language_packs' );
}

if ( ! function_exists( 'us_get_language_packs' ) ) {
	/**
	 * Get the language packs published on the portal
	 *
	 * The portal is requested only when WordPress checks for updates (cron, Dashboard > Updates,
	 * WP-CLI) or on the theme's About page: the list is read on every admin page (the update counter
	 * in the menu), and a slow portal must not slow the admin down. Between the checks the cached
	 * list is used — it is kept for a week, and a failed check keeps it as well, so that the packs
	 * do not disappear from the updates when the portal does not answer.
	 *
	 * @param bool $allow_request Request the portal if the list is not cached
	 * @param bool $refresh Request the portal even if the list is cached
	 *
	 * @return array Locale => pack data: language, updated (the PO-Revision-Date of the pack), version, package
	 */
	function us_get_language_packs( $allow_request = TRUE, $refresh = FALSE ) {
		$cached = get_site_transient( US_LANGUAGE_PACKS_TRANSIENT );
		if ( is_array( $cached ) AND ! $refresh ) {
			return $cached;
		}
		if (
			! $allow_request
			OR ( ! is_admin() AND ! wp_doing_cron() AND ! ( defined( 'WP_CLI' ) AND WP_CLI ) )
		) {
			return is_array( $cached ) ? $cached : array();
		}

		// An admin page waits for the answer, so the portal gets about as long as WordPress.org gets
		// in the update check of WordPress, not the 60 seconds of us_api()
		$set_timeout = function ( $args ) {
			$args['timeout'] = ( wp_doing_cron() OR ( defined( 'WP_CLI' ) AND WP_CLI ) ) ? 30 : 5;
			return $args;
		};
		add_filter( 'http_request_args', $set_timeout );
		$response = us_api( '/us.api/translations/:us_themename', array(), US_API_RETURN_ARRAY );
		remove_filter( 'http_request_args', $set_timeout );

		$translations = is_array( $response ) ? us_arr_path( $response, 'body.data.translations' ) : NULL;

		// The portal did not answer: the cached list stays as it is, and without it an empty list is
		// cached for an hour, so that the portal is not requested on every call
		if ( ! is_array( $translations ) ) {
			if ( is_array( $cached ) ) {
				return $cached;
			}
			set_site_transient( US_LANGUAGE_PACKS_TRANSIENT, array(), HOUR_IN_SECONDS );

			return array();
		}

		$packs = array();
		foreach ( $translations as $pack ) {
			if ( ! empty( $pack['language'] ) AND ! empty( $pack['package'] ) AND ! empty( $pack['updated'] ) ) {
				$packs[ $pack['language'] ] = $pack;
			}
		}
		set_site_transient( US_LANGUAGE_PACKS_TRANSIENT, $packs, WEEK_IN_SECONDS );

		return $packs;
	}
}

if ( ! function_exists( 'us_refresh_language_packs' ) ) {
	add_filter( 'pre_set_site_transient_update_themes', 'us_refresh_language_packs' );
	/**
	 * Request the fresh list of packs together with the update check of WordPress
	 *
	 * Once per request: wp_update_themes() saves the transient twice, before and after its own request.
	 * After a theme update WordPress checks for updates again (upgrader_process_complete, priority 10),
	 * so the list is requested before the translation updates are installed (priority 20)
	 *
	 * @param mixed $value The update_themes transient being saved, returned as is
	 *
	 * @return mixed
	 */
	function us_refresh_language_packs( $value = NULL ) {
		static $refreshed = FALSE;
		if ( ! $refreshed ) {
			$refreshed = TRUE;
			us_get_language_packs( /* allow_request */ TRUE, /* refresh */ TRUE );
			us_get_language_pack_statuses( /* refresh */ TRUE );
		}

		return $value;
	}
}

if ( ! function_exists( 'us_get_language_pack_statuses' ) ) {
	/**
	 * Get the state of the language packs the site needs
	 *
	 * The packs are needed for the site language and the languages installed in WordPress (users can
	 * pick them in their profiles). A regional or formal locale gets the pack of the closest language
	 * by us_get_locale_fallbacks(): es_MX → es_ES, de_DE_formal → de_DE.
	 *
	 * The result is kept only for the request, not saved between requests: the packs are installed in
	 * the background by another request (cron), and a result calculated before the install ends would
	 * keep offering the installed packs.
	 *
	 * @param bool $refresh Calculate again: the result is kept for the request, and installed packs change it
	 * @param bool $allow_request Request the portal if the list of packs is not cached
	 *
	 * @return array Pack locale => language (pack locale), updated (the published PO-Revision-Date),
	 *               installed (the PO-Revision-Date of the installed pack, empty if none), has_update, pack
	 */
	function us_get_language_pack_statuses( $refresh = FALSE, $allow_request = TRUE ) {
		static $statuses = NULL;
		if ( $statuses !== NULL AND ! $refresh ) {
			return $statuses;
		}

		$packs = us_get_language_packs( $allow_request );
		if ( empty( $packs ) ) {
			// Not kept for the request: a later call may be allowed to request the portal
			$statuses = NULL;

			return array();
		}

		$statuses = array();

		$installed = wp_get_installed_translations( 'themes' );
		$installed = isset( $installed['us'] ) ? $installed['us'] : array();
		$locales = array_unique( array_merge( array( get_locale() ), get_available_languages() ) );

		foreach ( $locales as $locale ) {
			foreach ( us_get_locale_fallbacks( $locale ) as $candidate ) {
				if ( ! isset( $packs[ $candidate ] ) ) {
					continue;
				}
				$installed_date = isset( $installed[ $candidate ]['PO-Revision-Date'] )
					? $installed[ $candidate ]['PO-Revision-Date']
					: '';
				$statuses[ $candidate ] = array(
					'language' => $candidate,
					'updated' => $packs[ $candidate ]['updated'],
					'installed' => $installed_date,
					'has_update' => ( $installed_date === '' OR strtotime( $packs[ $candidate ]['updated'] ) > strtotime( $installed_date ) ),
					'pack' => $packs[ $candidate ],
				);

				// The closest pack for the locale is found
				break;
			}
		}

		return $statuses;
	}
}

if ( ! function_exists( 'us_get_language_pack_updates' ) ) {
	/**
	 * Get the language packs to install or update, in the format of WordPress translation updates
	 *
	 * @param bool $refresh Calculate again: the result is kept for the request, and installed packs change it
	 * @param bool $allow_request Request the portal if the list of packs is not cached
	 *
	 * @return array
	 */
	function us_get_language_pack_updates( $refresh = FALSE, $allow_request = TRUE ) {
		$updates = array();
		foreach ( us_get_language_pack_statuses( $refresh, $allow_request ) as $status ) {
			if ( ! $status['has_update'] ) {
				continue;
			}
			$updates[] = array(
				'type' => 'theme',
				'slug' => get_template(),
				'language' => $status['language'],
				'version' => isset( $status['pack']['version'] ) ? $status['pack']['version'] : US_THEMEVERSION,
				'updated' => $status['updated'],
				'package' => $status['pack']['package'],
				'autoupdate' => TRUE,
			);
		}

		return $updates;
	}
}

if ( ! function_exists( 'us_add_language_pack_updates' ) ) {
	add_filter( 'site_transient_update_themes', 'us_add_language_pack_updates' );
	/**
	 * Add the language packs of the theme to the translation updates of WordPress
	 *
	 * @param object|false $value The update_themes transient
	 *
	 * @return object|false
	 */
	function us_add_language_pack_updates( $value ) {
		if ( ! is_object( $value ) ) {
			return $value;
		}

		// The filtered value can be saved back by WordPress, so the entries added before are replaced
		$translations = array();
		foreach ( isset( $value->translations ) ? (array) $value->translations : array() as $translation ) {
			$translation = (array) $translation;
			if ( ! ( isset( $translation['type'], $translation['slug'] ) AND $translation['type'] === 'theme' AND $translation['slug'] === get_template() ) ) {
				$translations[] = $translation;
			}
		}
		// Only the cached list: the transient is read on every admin page
		$value->translations = array_merge( $translations, us_get_language_pack_updates( /* refresh */ FALSE, /* allow_request */ FALSE ) );

		return $value;
	}
}

if ( ! function_exists( 'us_install_language_packs' ) ) {
	add_action( 'us_install_language_packs', 'us_install_language_packs' );
	/**
	 * Install the language packs right away, without waiting for the next translation update of WordPress
	 *
	 * Runs in cron after the theme is activated or updated and after the site language is changed.
	 * The packs are installed on the same conditions as the background translation updates of WordPress:
	 * not when automatic updates are disabled (AUTOMATIC_UPDATER_DISABLED, the "auto_update_translation"
	 * filter), not in a VCS checkout, and only with direct access to the file system.
	 */
	function us_install_language_packs() {
		// The upgrader needs the admin includes, which cron does not load (wp_maybe_auto_update() does the same)
		require_once ABSPATH . 'wp-admin/includes/admin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		// The list is fresh: the job is scheduled when the theme or the site languages have changed
		us_refresh_language_packs();

		$automatic_updater = new WP_Automatic_Updater();
		$updates = array();
		foreach ( us_get_language_pack_updates() as $update ) {
			// Language_Pack_Upgrader works with the updates as objects
			$update = (object) $update;
			if ( $automatic_updater->should_update( 'translation', $update, WP_LANG_DIR ) ) {
				$updates[] = $update;
			}
		}
		if ( empty( $updates ) ) {
			return;
		}

		$upgrader = new Language_Pack_Upgrader( new Automatic_Upgrader_Skin() );
		$upgrader->bulk_upgrade( $updates, array( 'clear_update_cache' => FALSE ) );
	}
}

if ( ! function_exists( 'us_schedule_language_packs_install' ) ) {
	add_action( 'after_switch_theme', 'us_schedule_language_packs_install' );
	add_action( 'update_option_WPLANG', 'us_schedule_language_packs_install' );
	add_action( 'add_option_WPLANG', 'us_schedule_language_packs_install' );
	/**
	 * Schedule the install of the language packs, the job requests a fresh list from the portal
	 */
	function us_schedule_language_packs_install() {
		if ( ! wp_next_scheduled( 'us_install_language_packs' ) ) {
			wp_schedule_single_event( time(), 'us_install_language_packs' );
		}
	}
}

if ( ! function_exists( 'us_maybe_schedule_language_packs_install' ) ) {
	add_action( 'init', 'us_maybe_schedule_language_packs_install' );
	/**
	 * Schedule the install of the language packs once after the theme version changes
	 *
	 * The theme is updated by the code of its previous version, so the hooks of the new version do not
	 * run during the update. Versions without language packs do not request them at all, while the
	 * update removes their bundled translations. Updates via FTP or Git run no hooks either.
	 */
	function us_maybe_schedule_language_packs_install() {
		if ( get_option( 'us_language_packs_theme_version' ) === US_THEMEVERSION ) {
			return;
		}
		update_option( 'us_language_packs_theme_version', US_THEMEVERSION, /* autoload */ TRUE );
		us_schedule_language_packs_install();
	}
}

if ( ! function_exists( 'us_refresh_language_pack_updates' ) ) {
	add_action( 'upgrader_process_complete', 'us_refresh_language_pack_updates', 10, 2 );
	/**
	 * After translations are installed the list of updates is calculated again, so that the
	 * installed packs are not offered once more within the same request
	 *
	 * @param WP_Upgrader $upgrader
	 * @param array $options
	 */
	function us_refresh_language_pack_updates( $upgrader, $options ) {
		if ( isset( $options['type'] ) AND $options['type'] === 'translation' ) {
			us_get_language_pack_updates( /* refresh */ TRUE );
		}
	}
}

if ( ! function_exists( 'us_translations_api' ) ) {
	add_filter( 'translations_api', 'us_translations_api', 10, 3 );
	/**
	 * Answer the translations API for the theme, so that WP-CLI can install its language packs:
	 * wp language theme install Impreza de_DE
	 *
	 * @param false|array $result
	 * @param string $type
	 * @param object|array $args
	 *
	 * @return false|array
	 */
	function us_translations_api( $result, $type, $args ) {
		$args = (array) $args;
		if ( $type !== 'themes' OR empty( $args['slug'] ) OR $args['slug'] !== get_template() ) {
			return $result;
		}

		require_once ABSPATH . 'wp-admin/includes/translation-install.php';
		$names = wp_get_available_translations();

		$translations = array();
		foreach ( us_get_language_packs() as $locale => $pack ) {
			$translations[] = array(
				'language' => $locale,
				'version' => isset( $pack['version'] ) ? $pack['version'] : US_THEMEVERSION,
				'updated' => $pack['updated'],
				'english_name' => isset( $names[ $locale ]['english_name'] ) ? $names[ $locale ]['english_name'] : $locale,
				'native_name' => isset( $names[ $locale ]['native_name'] ) ? $names[ $locale ]['native_name'] : $locale,
				'package' => $pack['package'],
				'iso' => isset( $names[ $locale ]['iso'] ) ? $names[ $locale ]['iso'] : array(),
			);
		}

		return array( 'translations' => $translations );
	}
}
