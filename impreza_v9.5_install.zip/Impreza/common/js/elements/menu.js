/**
 * Header navigation with all the possible states
 *
 * @requires $us.canvas
 */
! function( $, _undefined ) {
	"use strict";

	window.$us = window.$us || {};

	$us.mobileNavOpened = 0;

	const SLIDE_DURATION = 250;

	function usNav( container ) {
		const self = this;

		self.$container = $( container );
		if ( self.$container.length === 0 ) {
			return;
		}

		// Elements
		self.$items = $( '.menu-item', self.$container );
		self.$list = $( '.w-nav-list.level_1', self.$container );
		self.$anchors = $( '.w-nav-anchor', self.$container );
		self.$mobileMenu = $( '.w-nav-control', self.$container );
		self.$itemsHasChildren = $( '.menu-item-has-children', self.$list );
		self.$childLists = $( '.menu-item-has-children > .w-nav-list', self.$list );
		self.$reusableBlocksLinks = $( '.menu-item-object-us_page_block a', self.$container );

		// Private "Variables"
		self.type = self.$container.usMod( 'type' );
		self.layout = self.$container.usMod( 'layout' );
		self.openDropdownOnClick = self.$container.hasClass( 'open_on_click' );
		self.mobileNavOpened = false;
		self.keyboardNavEvent = false;
		self.opts = {};

		// Bindable events
		self._events = {
			closeMobileMenu: self.closeMobileMenu.bind( self ),
			closeMobileMenuOnClick: self.closeMobileMenuOnClick.bind( self ),
			closeMobileMenuOnFocusIn: self.closeMobileMenuOnFocusIn.bind( self ),
			closeOnClickOutside: self.closeOnClickOutside.bind( self ),
			closeOnMouseOver: self.closeOnMouseOver.bind( self ),
			forwardArrowClick: self.forwardArrowClick.bind( self ),
			handleKeyboardNav: self.handleKeyboardNav.bind( self ),
			handleMobileClick: self.handleMobileClick.bind( self ),
			resize: self.resize.bind( self ),
			toggleMenuOnClick: self.toggleMenuOnClick.bind( self ),
			toggleMobileMenu: self.toggleMobileMenu.bind( self ),
			toggleSubMenu: self.toggleSubMenu.bind( self ),
			updateDropDirection: self.updateDropDirection.bind( self ),
		}

		// Load nav options
		const $opts = $( '.w-nav-options:first', self.$container );
		self.opts = $ush.getPassedData( $opts ) || {};
		$opts.remove();

		// Events
		self.$container
			// Detach animation after transition
			.on( 'transitionend', () => self.$container.removeClass( 'us_animate_this' ) )
			// Keyboard navigation accessibility
			.on( 'keydown.upsolution', self._events.handleKeyboardNav )
			.on( 'click', '.w-nav-close', self._events.closeMobileMenu )
			.on( 'click', '.w-nav-anchor, .w-hwrapper-link', self._events.closeMobileMenuOnClick )
			.on( 'click', '.w-nav-control', self._events.toggleMobileMenu )
			.on( 'closeMobileMenu', self._events.closeMobileMenu )
			// Detect the open direction of the dropdowns
			.on( 'mouseenter', '.menu-item-has-children', self._events.updateDropDirection )
			.on( 'focusin', '.menu-item-has-children > .w-nav-anchor, .menu-item-has-children > .w-nav-item-toggle', self._events.updateDropDirection );

		// Open dropdown on click
		if ( self.openDropdownOnClick ) {
			self.$container.on( 'click', '.menu-item.togglable > .w-nav-anchor', self._events.toggleMenuOnClick );

			// Close on outside menu click
			$us.$document.on( 'mouseup touchend.noPreventDefault', self._events.closeOnClickOutside );
		}

		// Triggered in `$us.header.setView()`
		$us.$document
			.on( 'usHeader.update_view', self._events.resize );

		$us.$window
			.on( 'resize', $ush.debounce( self._events.resize, 5 ) );

		// Fix "Safari outline webkit bug #243289"
		if ( $ush.isSafari ) {
			self.$mobileMenu.on( 'mouseup', () => {
				self.$mobileMenu.attr( 'style', 'outline: none' );
			} );
		}

		// Add anchors from reusable blocks
		self.$reusableBlocksLinks.each( ( index, anchor ) => {
			if ( $( anchor ).parents( '.w-popup-wrap' ).length === 0 ) {
				self.$anchors.push( anchor );
			}
		} );

		// Close the main menu on tablets after a submenu click (since tablets don’t support hover)
		if ( $.isMobile && self.type === 'desktop' ) {
			self.$list.on( 'click', '.w-nav-anchor[class*="level_"]', ( e ) => {
				const $target = $( e.currentTarget );
				const $menuItem = $target.closest( '.menu-item' );
				if ( $target.usMod('level') > 1 && ! $menuItem.hasClass( 'menu-item-has-children' ) ) {
					self.setOpened( $target.parents( '.menu-item.opened' ), false );
				}
			} );
		}

		self.$itemsHasChildren.each( ( _, menuItem ) => {
			const $menuItem = $( menuItem );

			// Mark toggleable items (skip descendants of mega menus)
			const isInMegaMenu = $menuItem.parents( '.menu-item.has_cols, .menu-item.has_side_panel' ).length > 0;
			if ( ! isInMegaMenu ) {
				$menuItem.addClass( 'togglable' );
			}

			// Behavior of menu items on mobile
			const $subAnchor = $menuItem.children( '.w-nav-anchor' );
			const dropByLabel = $menuItem.hasClass( 'mobile-drop-by_label' ) || $menuItem.parents( '.menu-item' ).hasClass( 'mobile-drop-by_label' );
			const dropByArrow = $menuItem.hasClass( 'mobile-drop-by_arrow' ) || $menuItem.parents( '.menu-item' ).hasClass( 'mobile-drop-by_arrow' );

			// The toggle is a button, so both a pointer and a keyboard activate it with a click
			$menuItem.children( '.w-nav-item-toggle' ).on( 'click', self._events.toggleSubMenu );

			if ( dropByLabel || ( self.opts.mobileBehavior && ! dropByArrow ) ) {
				$subAnchor.on( 'click', self._events.handleMobileClick );
			} else {
				$( '.w-nav-arrow', $subAnchor ).on( 'click', self._events.forwardArrowClick );
			}
		} );

		// Touchscreen handling on desktop devices
		if ( ! $us.$html.hasClass( 'no-touch' ) ) {
			self.$list.on( 'click', '.menu-item-has-children.togglable > .w-nav-anchor', ( e ) => {
				if ( self.type === 'mobile' ) {
					return;
				}
				e.preventDefault();
				const $target = $( e.currentTarget );
				const $menuItem = $target.parent();
				if ( $menuItem.hasClass( 'opened' ) ) {
					return location.assign( $target.attr( 'href' ) );
				}
				self.setOpened( $menuItem, true );
				const onOutsideClick = ( e ) => {
					if ( $.contains( $menuItem[0], e.target ) ) {
						return;
					}
					self.setOpened( $menuItem, false );
					$us.$body.off( 'touchstart', onOutsideClick );
				};
				$us.$body.on( 'touchstart.noPreventDefault', onOutsideClick );
			} );
		}

		$us.$document.on( 'keydown', ( e ) => {

			// Fix Safari outline webkit bug #243289
			if ( $ush.isSafari ) {
				self.$mobileMenu.removeAttr( 'style' );
			}

			// Close mobile menu on ESC
			if ( e.keyCode === $ush.ESC_KEYCODE && self.type === 'mobile' && self.mobileNavOpened ) {
				self.closeMobileMenu();
			}

			// Close submenus when navigating outside the menu
			if ( e.keyCode === $ush.TAB_KEYCODE && self.type === 'desktop' && ! $( e.target ).closest( '.w-nav' ).length ) {
				self.setOpened( self.$items, false );
			}
		} );

		$ush.timeout( () => {
			self.resize();
			$us.header.$container.trigger( 'contentChange' );
		}, 50 );
	};

	// Mobile navigation API.
	$.extend( usNav.prototype, {

		/**
		 * Mobile menu toggle button.
		 *
		 * @param {Event} e
		 */
		toggleMobileMenu: function( e ) {
			const self = this;

			e.preventDefault();

			self.mobileNavOpened = ! self.mobileNavOpened;

			// Close on outside menu click
			$us.$document.on( 'mouseup touchend.noPreventDefault', self._events.closeOnClickOutside );

			// Make empty links focusable and clickable to open dropdown
			self.$anchors.each( ( _, node ) => { node.href = node.href || 'javascript:void(0)'; } );

			if ( self.mobileNavOpened ) {

				// Close other opened menus
				$( '.l-header .w-nav' ).not( self.$container ).each( ( _, node ) => {
					$( node ).trigger( 'closeMobileMenu' );
				} );

				// Close opened sublists
				self.$mobileMenu.addClass( 'active' ).focus();
				self.setOpened( self.$items.filter( '.opened' ), false );
				self.$childLists.resetInlineCSS( 'display', 'height', 'opacity' );
				if ( self.layout === 'dropdown' ) {
					self.$list.slideDownCSS( SLIDE_DURATION, () => $us.header.$container.trigger( 'contentChange' ) );
				}
				$us.$html.addClass( 'w-nav-open' );
				self.$mobileMenu.attr( 'aria-expanded', 'true' );
				$us.mobileNavOpened++;

				// Close mobile menu when focus is outside the menu
				$us.$document.on( 'focusin', self._events.closeMobileMenuOnFocusIn );

			} else {
				self.closeMobileMenu();
			}

			$us.$canvas.trigger( 'contentChange' );
		},

		/**
		 * Handle click on mobile.
		 *
		 * @param {Event} e
		 */
		handleMobileClick: function( e ) {
			const self = this;
			if ( self.type === 'mobile' ) {
				e.stopPropagation();
				e.preventDefault();
				const $menuItem = $( e.currentTarget ).closest( '.menu-item' );
				self.switchMobileSubMenu( $menuItem, ! $menuItem.hasClass( 'opened' ) );
			}
		},

		/**
		 * Switch mobile submenu items.
		 *
		 * @param {Node} $menuItem
		 * @param {Boolean} opened
		 */
		switchMobileSubMenu: function( $menuItem, opened ) {
			const self = this;
			if ( self.type !== 'mobile' ) {
				return;
			}
			const $subMenu = $menuItem.children( '.w-nav-list' );

			self.setOpened( $menuItem, opened );

			if ( opened ) {
				$subMenu.slideDownCSS( SLIDE_DURATION, () => $us.header.$container.trigger( 'contentChange' ) );
			} else {
				$subMenu.slideUpCSS( SLIDE_DURATION, () => $us.header.$container.trigger( 'contentChange' ) );
			}
		},

		/**
		 * Close mobile menu on focus leave.
		 *
		 * @event handler
		 */
		closeMobileMenuOnFocusIn: function() {
			const self = this;
			if ( ! $.contains( self.$container[0], document.activeElement ) ) {
				self.closeMobileMenu();
			}
		},

		/**
		 * Close mobile menu.
		 */
		closeMobileMenu: function() {
			const self = this;
			if ( self.type !== 'mobile' ) {
				return;
			}
			self.mobileNavOpened = false;
			self.$mobileMenu.removeClass( 'active' );
			$us.$html.removeClass( 'w-nav-open' );
			self.$mobileMenu.attr( 'aria-expanded', 'false' );

			if ( self.$list && self.layout === 'dropdown' ) {
				self.$list.slideUpCSS( SLIDE_DURATION );
			}

			$us.mobileNavOpened--;
			self.$mobileMenu[0].focus();
			$us.$canvas.trigger( 'contentChange' );

			$us.$document
				.off( 'focusin', self._events.closeMobileMenuOnFocusIn )
				.off( 'mouseup touchend.noPreventDefault', self._events.closeOnClickOutside );

			// Change state of items
			self.setOpened( self.$items, false );
		},

		/**
		 * Close on anchor click (mobile).
		 *
		 * @param {Event} e
		 */
		closeMobileMenuOnClick: function( e ) {
			const self = this;
			const $menuItem = $( e.currentTarget ).closest( '.menu-item' );
			const dropByLabel = $menuItem.hasClass( 'mobile-drop-by_label' ) || $menuItem.parents( '.menu-item' ).hasClass( 'mobile-drop-by_label' );
			const dropByArrow = $menuItem.hasClass( 'mobile-drop-by_arrow' ) || $menuItem.parents( '.menu-item' ).hasClass( 'mobile-drop-by_arrow' );

			if ( self.type !== 'mobile' || $us.header.isVertical() ) {
				return;
			}
			if (
				dropByLabel
				|| ( self.opts.mobileBehavior && $menuItem.hasClass( 'menu-item-has-children' ) && ! dropByArrow )
			) {
				return;
			}

			self.closeMobileMenu();
		},

	} );

	// Global navigation API
	$.extend( usNav.prototype, {

		/**
		 * Set the opened state of items and report it on the controls that toggle them.
		 *
		 * @param {jQuery} $menuItems
		 * @param {Boolean} opened
		 */
		setOpened: function( $menuItems, opened ) {
			$menuItems
				.toggleClass( 'opened', !! opened )
				.children( '.w-nav-item-toggle' )
				.attr( 'aria-expanded', opened ? 'true' : 'false' );
		},

		/**
		 * Open/close a submenu by its toggle, which is a button placed next to the anchor.
		 *
		 * @param {Event} e
		 */
		toggleSubMenu: function( e ) {
			const self = this;
			const $toggle = $( e.currentTarget );
			const $menuItem = $toggle.closest( '.menu-item-has-children' );

			e.preventDefault();
			e.stopPropagation();

			if ( self.type === 'mobile' ) {
				self.switchMobileSubMenu( $menuItem, ! $menuItem.hasClass( 'opened' ) );
				return;
			}

			// Close items opened via the toggles on hover over other items
			self.$itemsHasChildren
				.off( 'mouseover', self._events.closeOnMouseOver )
				.one( 'mouseover', self._events.closeOnMouseOver );

			if ( $menuItem.hasClass( 'opened' ) ) {
				self.setOpened( $menuItem, false );
				return;
			}

			// Close the other items, while the ancestors of this one must stay opened
			self.setOpened(
				self.$itemsHasChildren
					.not( $menuItem )
					.not( $menuItem.parents( '.menu-item-has-children' ) ),
				false
			);
			self.setOpened( $menuItem, true );
		},

		/**
		 * Activate the toggle by a click on the arrow icon.
		 *
		 * The arrow stays inside the anchor to keep the item layout, and on mobile it can be
		 * placed right next to the label, so the toggle can't overlay it as it does on desktop.
		 *
		 * @param {Event} e
		 */
		forwardArrowClick: function( e ) {
			const self = this;

			if ( self.type !== 'mobile' ) {
				return;
			}

			e.preventDefault();
			e.stopPropagation();

			const toggle = $( e.currentTarget )
				.closest( '.menu-item-has-children' )
				.children( '.w-nav-item-toggle' )[0];

			if ( toggle ) {
				toggle.click();
			}
		},

		/**
		 * Open/close dropdown on click.
		 *
		 * @param {Event} e
		 */
		toggleMenuOnClick: function( e ) {
			const self = this;

			if ( self.type === 'mobile' ) {
				return;
			}

			const $menuItem = $( e.currentTarget ).closest( '.menu-item' );
			const isOpened = $menuItem.hasClass( 'opened' );

			if ( ! self.keyboardNavEvent ) {
				e.preventDefault();
				e.stopPropagation();
			} else {
				return;
			}

			self.setOpened( $menuItem, ! isOpened );

			// Events for open items
			if ( ! isOpened ) {
				self.closeOnMouseOver( e );

			} else {
				self.setOpened( $( '.menu-item-has-children.opened', $menuItem ), false );
			}
		},

		/**
		 * Close menu on click outside.
		 *
		 * @param {Event} e
		 */
		closeOnClickOutside: function( e ) {
			const self = this;

			if ( self.mobileNavOpened && self.type === 'mobile' ) {
				if (
					! self.$mobileMenu.is( e.target )
					&& ! self.$mobileMenu.has( e.target ).length
					&& ! self.$list.is( e.target )
					&& ! self.$list.has( e.target ).length
				) {
					self.closeMobileMenu();
				}

			} else if (
				self.$itemsHasChildren.hasClass( 'opened' )
				&& ! $.contains( self.$container[0], e.target )
			) {
				self.setOpened( self.$itemsHasChildren, false );
			}
		},

		/**
		 * Close tab-opened items on hover of other items.
		 *
		 * @param {Event} e
		 */
		closeOnMouseOver: function( e ) {
			const self = this;
			if ( self.type === 'mobile' ) {
				return;
			}
			const $target = $( e.target );
			const $itemHasChildren = $target.closest( '.menu-item-has-children' );
			const $menuItemLevel1 = $target.closest( '.menu-item.level_1' );
			self.setOpened(
				self.$itemsHasChildren
					.not( $itemHasChildren )
					.not( $itemHasChildren.parents( '.menu-item-has-children' ) )
					.not( $menuItemLevel1 ),
				false
			);
		},

		/**
		 * Move the focus between the side panel items by Up/Down keys.
		 *
		 * They behave as tabs, and each of them opens its own panel, so walking through all
		 * the panels by Tab to reach the next item would take too many steps.
		 *
		 * @param {Event} e
		 */
		switchSidePanelTab: function( e ) {
			const $target = $( e.target );

			if (
				! $target.is( '.w-nav-anchor.level_2' )
				|| ! $target.closest( '.menu-item.has_side_panel' ).length
			) {
				return;
			}

			// The panel items are links, so the keys must not scroll the page
			e.preventDefault();

			const $tabs = $target
				.closest( '.w-nav-list.level_2' )
				.children( '.w-nav-item' )
				.children( '.w-nav-anchor' );
			const index = $tabs.index( $target );

			if ( index === -1 ) {
				return;
			}

			const shift = ( ( e.keyCode || e.which ) === $ush.DOWN_KEYCODE ) ? 1 : -1;

			$tabs.eq( ( index + shift + $tabs.length ) % $tabs.length ).focus();
		},

		/**
		 * Detect and set the open direction of a dropdown depending on the available space
		 *
		 * @param {Event} e
		 */
		updateDropDirection: function( e ) {
			const self = this;

			if ( self.type !== 'desktop' || $us.header.isVertical() ) {
				return;
			}

			const $itemHasChildren = $( e.currentTarget ).closest( '.menu-item-has-children' );
			const dropdown = $itemHasChildren.children( '.w-nav-list' )[0];
			if ( ! dropdown ) {
				return;
			}

			// Skip mega / side-panel / full-width dropdowns
			if ( $itemHasChildren.closest( '.menu-item.has_cols, .menu-item.has_side_panel, .menu-item.dropdown_full_width' ).length ) {
				return;
			}

			// Check if the dropdown fit to the screen edge
			const itemRect = $ush.$rect( $itemHasChildren[0] );
			const isLevel1 = $itemHasChildren.hasClass( 'level_1' );
			const dropLeft = $ush.isRtl()
				? ( ( isLevel1 ? itemRect.right : itemRect.left ) - dropdown.offsetWidth < 0 )
				: ( ( isLevel1 ? itemRect.left : itemRect.right ) + dropdown.offsetWidth > window.innerWidth );

			$itemHasChildren.toggleClass( 'drop_left', dropLeft );
		},

		/**
		 * Handle keydown events.
		 *
		 * @param {Event} e
		 */
		handleKeyboardNav: function( e ) {
			const self = this;
			const keyCode = e.keyCode || e.which;
			const $target = $( e.target );
			const $menuItemLevel1 = $target.closest( '.menu-item.level_1' );

			/*
			 * Note: the toggles are buttons, so Enter and Space on them come
			 * as a click and are handled in "toggleSubMenu".
			 */

			// Mobile menu handlers
			if ( self.type === 'mobile' ) {

				// The control has role="button", so Space is expected to work
				// (Enter already fires a native click on the link)
				if ( keyCode === $ush.SPACE_KEYCODE && $target.is( self.$mobileMenu ) ) {
					e.stopPropagation();
					self.toggleMobileMenu( e );
				}
				if ( keyCode === $ush.TAB_KEYCODE ) {
					if ( e.shiftKey && self.$anchors.index( $target ) === 0 ) {
						self.closeMobileMenu();
					}
				}
			}

			// Desktop menu handlers
			if ( self.type === 'desktop' ) {
				if ( keyCode === $ush.ESC_KEYCODE ) {
					if ( $menuItemLevel1.hasClass( 'opened' ) ) {
						$menuItemLevel1.children( '.w-nav-item-toggle' ).focus();
					}
					self.setOpened( self.$items, false );
				}
				if ( [ $ush.UP_KEYCODE, $ush.DOWN_KEYCODE ].includes( keyCode ) ) {
					self.switchSidePanelTab( e );
				}

				self.keyboardNavEvent = true;
				$ush.timeout( () => { self.keyboardNavEvent = false; }, 1 );
			}
		},

		/**
		 * Resize handler.
		 */
		resize: function() {
			const self = this;

			if ( self.$container.length === 0 ) {
				return;
			}

			const newType = ( window.innerWidth < self.opts.mobileWidth ) ? 'mobile' : 'desktop';

			if ( $us.header.orientation !== self.headerOrientation || newType !== self.type ) {

				self.$childLists.resetInlineCSS( 'display', 'height', 'opacity' );

				if ( self.headerOrientation === 'hor' && self.type === 'mobile' ) {
					self.$list.resetInlineCSS( 'display', 'height', 'opacity' );
				}

				self.setOpened( self.$items, false );
				self.headerOrientation = $us.header.orientation;
				self.type = newType;
				self.$container.usMod( 'type', newType );
			}

			self.$list.removeClass( 'hide_for_mobiles' );
		},

	} );

	$.fn.usNav = function() {
		return this.each( function() {
			$( this ).data( 'usNav', new usNav( this ) );
		} );
	};

	$( '.l-header .w-nav' ).usNav();

}( jQuery );
