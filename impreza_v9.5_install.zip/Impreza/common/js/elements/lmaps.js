/**
 * UpSolution Element: Leaflet Maps
 *
 * Used for [us_gmaps] shortcode
 *
 * Leaflet JS Official Docs https://leafletjs.com/
 * @requires jQuery
 */
! function( $, undefined ) {
	"use strict";

	// Private variables that are used only in the context of this function, it is necessary to optimize the code
	var _document = document,
		_window = window,
		_null = null;

	// Check for is set objects
	_window.$us = _window.$us || {};

	/**
	 * @type {RegExp} Regular expression to check or extract coordinates.
	 */
	const _REGEXP_EXTRACT_COORDINATES_ = /^(-?[\d\.]+),(-?[\d\.]+)$/;

	/**
	 * @class wLmaps
	 * @param {Node} container The node container
	 * @param {{}} options The map options
	 */
	$us.wLmaps = function( container, options ) {
		var self = this;

		// Elements
		self.$container = $( container );

		// Prevent double init
		if ( self.$container.data( '_inited' ) ) {
			return;
		}
		self.$container.data( '_inited', 1 );

		// Variables
		self._mapInstance = _null;
		self.cookieName = self.$container.data( 'cookie-name' );
		self.options = options || {};

		/**
		 * @var {{}} Bindable events
		 */
		self._events = {
			confirmInit: self._confirmInit.bind( self ),
			redraw: self._redraw.bind( self ),
			keydown: self._closeInfoWindowOnEscape.bind( self ),
			// Popups of the shown markers are preloaded after the map view settles and after the cluster animation,
			// which shows markers of the zoomed cluster, @see maps.js
			preloadVisible: $ush.debounce( self._preloadVisibleInfoWindows.bind( self ), 300 ),
		};

		// Confirm initialization
		if ( self.cookieName ) {
			self.$container
				.on( 'click', '.action_confirm_load', self._events.confirmInit )
				// The acceptance in the Cookie Notice, see _general.js
				.on( 'usLoadConfirmed', self._events.confirmInit );

			// The consent given earlier is checked on the client, as page caches skip the server-side check
			if ( $ush.isLoadConfirmed( self.$container ) ) {
				self._confirmInit();
			}
			return;
		}

		self._init();
	};

	/**
	 * Export API
	 */
	// Note: methods for markers are common for all providers, @see maps.js
	$.extend( $us.wLmaps.prototype, $us.mapMarkers || {}, {

		/**
		 * Map initialization handler after confirmation
		 *
		 * @event handler
		 */
		_confirmInit: function() {
			var self = this;

			// Save permission to loading maps in cookies
			if ( $( 'input[name^=' + self.cookieName + ']:checked', self.$container ).length ) {
				$ush.setCookie( self.cookieName, /* value */1, /* days */365 );
			}

			self.$container
				// Add map html markup to element
				.html( $ush.base64Decode( $( 'script[type="text/template"]', self.$container ).text() ) )
				.removeAttr( 'data-cookie-name' );

			self._init();
		},

		/**
		 * Map the init
		 */
		_init: function() {
			var self = this;

			// Get map options
			var $mapJson = $( '.w-map-json', self.$container );
			$.extend( self.options, $ush.getPassedData( $mapJson ) || {} );
			$mapJson.remove();

			// Markers of posts, which were filtered before the map init
			if ( self.options.fitMarkers ) {
				self._restorePendingMarkers();
			}

			self._initMarkerStyle();

			$us.$canvas.on( 'contentChange', self._events.redraw );
			self._beforeRender();
		},

		/**
		 * Get data before rendering the map
		 */
		_beforeRender: function() {
			var self = this;

			// The map of posts markers fits all of them, so it doesn't need the center
			if ( self.options.fitMarkers ) {
				self._render();
				return;
			}

			var address = ( '' + self.options.address ),
				matches = $ush.removeSpaces( address ) // Remove all spaces and tabs
					.match( _REGEXP_EXTRACT_COORDINATES_ ); // Example: -0.00000,0.00000

			if ( matches ) {
				self.center = [ matches[1], matches[2] ];
				self._render();
			} else {
				self._geocoder( address );
			}
		},

		/**
		 * Map render
		 */
		_render: function() {
			var self = this,
				mapId = self.$container.attr( 'id' ),
				lmapsOptions = {};

			// Basic Map setup, the map of posts markers sets its view after fitting all of them
			if ( ! self.options.fitMarkers ) {
				lmapsOptions.center = self.center;
				lmapsOptions.zoom = self.options.zoom;

				// The hidden map can't fit markers, so show the whole world until it becomes visible
			} else if ( self.$container.is( ':hidden' ) ) {
				lmapsOptions.center = [ 20, 0 ];
				lmapsOptions.zoom = 2;
			}

			if ( self.options.hideControls ) {
				lmapsOptions.zoomControl = false; // Hide zooming buttons
			}
			if ( self.options.disableZoom ) {
				lmapsOptions.scrollWheelZoom = false; // Disable Mouse Zooming
			}

			// Create an instance of the L.map class
			self._mapInstance = L.map( mapId, lmapsOptions );

			// The popup by the Grid Layout is closed by the Escape key, while Leaflet does it only when the map itself
			// has the focus, @see maps.js
			if ( self.options.markerClick === 'grid_layout' ) {
				self.$container.on( 'keydown', self._events.keydown );
				self._mapInstance.on( 'moveend', self._events.preloadVisible );
			}

			// Add a Raster layer to the map. Copyright layer required by OSM https://www.openstreetmap.org/copyright
			var attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

			// CARTO tiles require their own copyright as well https://carto.com/attributions/
			if ( /basemaps\.cartocdn\.com/.test( self.options.style ) ) {
				attribution += ', &copy; <a href="https://carto.com/attributions/">CARTO</a>';
			}

			L.tileLayer( self.options.style, { attribution: attribution } ).addTo( self._mapInstance );

			// Add all markers to the map
			if ( self.options.fitMarkers ) {
				self.setMarkers( self.options.markers );
			} else {
				self._renderMarkers();
			}

			if (
				$us.usbPreview()
				|| self.options.disableDragging && ! $us.$html.hasClass( 'no-touch' )
			) {
				// Disable dragging on mobiles
				self._mapInstance.dragging.disable();
			}
		},

		/**
		 * Set a markers at an address
		 *
		 * @param {String} text The request text
		 * @param {{}} markerOptions The marker options
		 * @param {String} popup The popup
		 */
		_geocoder: function( text, markerOptions, popup ) {
			var self = this,
				osmUrl = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent( text );

			// Get coordinates from the search engine
			$.getJSON( osmUrl, /* First Success */$.noop ).done( function( json ) {
				if ( ! json.length ) {
					// Return in case no coordinates were found
					return;
				}
				// Get Coordinates of the found place, not the corner of its bounding box
				var coordinates = [ json[0].lat, json[0].lon ];
				if ( ! markerOptions ) {
					// Get coordinates to set map center and add 1st marker
					self.center = coordinates;
					self._render();
				} else {
					self.marker = L
						.marker( coordinates, markerOptions )
						.addTo( self._mapInstance );
					self._watchActiveMarker( self.marker );
					// Add marker popups
					if ( popup ) {
						self.marker.bindPopup( popup );
					}
				}
			});
		},

		/**
		 * Map redraw
		 *
		 * @event handler
		 */
		_redraw: function() {
			var self = this;
			if ( ! self._mapInstance || self.$container.is( ':hidden' ) ) {
				return;
			}
			$ush.timeout( function() {
				self._mapInstance.invalidateSize( /* animate */true );
				// Fit markers only when it was skipped for the hidden map, to keep the view set by a visitor
				if ( self.options.fitMarkers && self._needsFit ) {
					self._fitMarkers();
				}
			}, 100 );
		},

		/**
		 * Get the marker icon
		 *
		 * @param {{url: String, size: Number[], anchor: Number[]}} icon The icon, the anchor is optional
		 * @param {String} className The optional class of the icon
		 * @param {Number} scale The optional scale of the icon, the anchor is scaled too, so the icon keeps its point
		 * @return {L.Icon} Returns the icon
		 */
		_getIcon: function( icon, className, scale ) {
			scale = scale || 1;
			var width = $ush.parseInt( icon.size[/* width */0] ) * scale,
				height = $ush.parseInt( icon.size[/* height */1] ) * scale,
				// Without the anchor, the image is anchored at its bottom center
				anchor = icon.anchor
					? [ icon.anchor[/* x */0] * scale, icon.anchor[/* y */1] * scale ]
					: [ width / 2, height ];
			return L.icon( {
				iconUrl: icon.url,
				iconSize: [ width, height ],
				iconAnchor: anchor,
				// The popup opens above the image. The scale isn't applied, so the open popup keeps its position,
				// while the list item of its marker is hovered, the same as for Google Maps
				popupAnchor: [ 0, - anchor[/* y */1] / scale ],
				className: className || '',
			} );
		},

		/**
		 * Get the default icon of Leaflet with the class and the scale, @see _getIcon()
		 *
		 * @param {String} className The class of the icon
		 * @param {Number} scale The scale of the icon
		 * @return {L.Icon.Default} Returns the icon
		 */
		_getDefaultIcon: function( className, scale ) {
			var options = {
				className: className,
			};
			// The popup anchor isn't scaled, @see _getIcon()
			if ( scale !== 1 ) {
				$.each( [ 'iconSize', 'iconAnchor', 'tooltipAnchor', 'shadowSize' ], function( _, name ) {
					options[ name ] = L.Icon.Default.prototype.options[ name ].map( function( value ) {
						return value * scale;
					} );
				} );
			}
			return new L.Icon.Default( options );
		},

		/**
		 * Get options of the marker of the "Marker Style" setting, @see maps.js
		 *
		 * @param {String} label The label text, it's used by the label style only
		 * @param {{active: Boolean, highlighted: Boolean, visited: Boolean}} state The optional state, @see maps.js
		 * @return {{}} Returns the marker options
		 */
		_getMarkerOptions: function( label, state ) {
			var self = this,
				options = {};

			state = state || {};

			// The label under the cursor has swapped colors, the same as the label with the open popup
			var active = state.active || state.highlighted;

			// The class is in the icon options, so it's kept, when the marker element is created again
			// on changes of clusters. Visited markers get the contrast filter, except the active one, @see leaflet.css
			var className = ( state.visited && ! active ) ? 'visited' : '';

			if ( self.options.markerStyle === 'label' ) {
				label = $ush.toString( label );
				var style = self._getLabelStyle( active ),
					height = style.height,
					css = 'background:' + style.background + ';color:' + style.color + ';height:' + height + 'px;';
				if ( label ) {
					css += 'line-height:' + height + 'px;padding:0 ' + style.padding + 'px;font-size:' + style.fontSize + 'px';
				} else {
					// The label without text is a circle of the same height
					css += 'width:' + height + 'px';
				}
				options.icon = L.divIcon( {
					// The label is centered at the marker point by CSS, because its width depends on the text, @see maps.css
					className: ( 'w-map-marker-label ' + className ).trim(),
					html: '<div style="' + css + '">' + $( '<i>' ).text( label ).html() + '</div>',
					iconSize: [ 0, 0 ],
					iconAnchor: [ 0, 0 ],
					// The popup opens above the label
					popupAnchor: [ 0, - height / 2 ],
				} );
				options.markerLabel = label;

				// Other icons are enlarged under the cursor, the same as for Google Maps
			} else {
				var scale = state.highlighted ? self._highlightScale : 1;
				options.icon = ( self.options.icon != _null )
					? self._getIcon( self.options.icon, className, scale )
					: self._getDefaultIcon( className, scale );
			}

			// The active marker is above other markers, the z-index of which is their vertical position in pixels
			options.zIndexOffset = active ? 100000 : 0;

			// Icons of the built-in style are updated, e.g. after the Color Scheme Switch
			if ( self.options.markerStyle ) {
				options.styleIcon = true;
			}

			return options;
		},

		/**
		 * Update the icon of the marker of the built-in style, @see maps.js
		 *
		 * @param {L.Marker} marker The marker
		 */
		_updateMarkerIcon: function( marker ) {
			var self = this,
				options = self._getMarkerOptions(
					marker.options.markerLabel,
					self._getMarkerState( marker, marker.options.postId )
				);

			// The marker without its element isn't shown: it's in a cluster or it's being removed from the map,
			// which closes its popup and so resets the active marker. setIcon() would add the element to the map
			// once again, while Leaflet removes the marker from the map after the "remove" event, so the element
			// would stay on the map. The icon is applied on the next show instead
			if ( ! self._isMarkerShown( marker ) ) {
				marker.options.icon = options.icon;
				marker.options.zIndexOffset = options.zIndexOffset || 0;
				return;
			}
			marker.setIcon( options.icon );
			marker.setZIndexOffset( options.zIndexOffset || 0 );
		},

		/**
		 * Check if the marker is shown on the map, it has no element, when it's in a cluster, @see maps.js
		 *
		 * @param {L.Marker} marker The marker
		 * @return {Boolean}
		 */
		_isMarkerShown: function( marker ) {
			return !! marker.getElement();
		},

		/**
		 * Get the map view for the preload of popups of shown markers, @see maps.js
		 *
		 * @return {{center: Number[], contains: Function}} The center as [ lat, lng ] and the check of the bounds
		 */
		_getMapView: function() {
			var map = this._mapInstance,
				bounds = map.getBounds(),
				center = map.getCenter();
			return {
				center: [ center.lat, center.lng ],
				contains: function( latLng ) {
					return bounds.contains( latLng );
				},
			};
		},

		/**
		 * Get the position of the marker, @see maps.js
		 *
		 * @param {L.Marker} marker The marker
		 * @return {Number[]} The [ lat, lng ] pair
		 */
		_getMarkerLatLng: function( marker ) {
			var latLng = marker.getLatLng();
			return [ latLng.lat, latLng.lng ];
		},

		/**
		 * Update icons of all markers of the built-in style, @see maps.js
		 */
		_refreshMarkerIcons: function() {
			var self = this;
			var updateIcon = function( layer ) {
				if ( layer instanceof L.Marker && layer.options.styleIcon ) {
					self._updateMarkerIcon( layer );
				}
			};
			// Markers of posts are in their layer, also hidden in clusters, while the markers of custom addresses are on the map
			if ( self._markersLayer ) {
				self._markersLayer.eachLayer( updateIcon );
			} else {
				self._mapInstance.eachLayer( updateIcon );
			}
		},

		/**
		 * Make the marker of the label style or of posts active, while its popup is open, @see maps.js
		 *
		 * @param {L.Marker} marker The marker
		 */
		_watchActiveMarker: function( marker ) {
			var self = this;
			// Additional markers with their own images aren't labels, while markers of posts of any style are active
			// to get the default contrast, even if they're visited
			if (
				( self.options.markerStyle !== 'label' || ! marker.options.styleIcon )
				&& ! marker.options.postId
			) {
				return;
			}
			marker
				.on( 'popupopen', function() {
					self._setActiveMarker( marker );
				} )
				.on( 'popupclose', function() {
					if ( self._activeMarker === marker ) {
						self._setActiveMarker( _null );
					}
				} );
		},

		/**
		 * Close the open popup of a marker, @see maps.js
		 */
		_closeInfoWindow: function() {
			if ( this._mapInstance ) {
				this._mapInstance.closePopup();
			}
		},

		/**
		 * Set markers of posts and fit the map to them
		 *
		 * @param {[]} markers The markers list, each one is { id, lat, lng, url? }
		 */
		setMarkers: function( markers ) {
			var self = this;

			if ( ! self._saveMarkers( markers ) ) {
				return;
			}

			self.clearMarkers();

			// The same options for all markers, except labels with their own texts
			var sharedOptions = ( self.options.markerStyle !== 'label' ) ? self._getMarkerOptions() : _null;

			var layers = self.options.markers.map( function( item ) {
				// Markers, which were clicked before filtering, stay visited, so they get their own options
				var isVisited = self._isPostVisited( item.id ),
					marker = L.marker(
						[ item.lat, item.lng ],
						$.extend(
							{
								postId: item.id,
							},
							( sharedOptions && ! isVisited )
								? sharedOptions
								: self._getMarkerOptions( self._getMarkerLabel( item ), { visited: isVisited } )
						)
					);
				// Markers by post IDs, so the hovered list item finds its marker at once, @see maps.js
				self._markersByPost.set( item.id, marker );
				self._watchActiveMarker( marker );
				// The "Marker Click" setting: the popup shows the item by the Grid Layout, which is loaded on the first
				// click: the content function shows the loading state, the loaded node replaces it, so the popup is
				// resized to the item and keeps it for the next opens, @see maps.js
				if ( self.options.markerClick === 'grid_layout' ) {
					marker.bindPopup( function() {
						return self._getAjaxInfoWindow( item.id, function( node, isLoaded ) {
							// The popup can be closed meanwhile, then the item is loaded again on the next open
							if ( ! marker.isPopupOpen() ) {
								return false;
							}
							// The popup is resized to the loaded item, a failure leaves nothing to show
							if ( isLoaded ) {
								marker.getPopup().setContent( node );
								return true;
							}
							marker.closePopup();
							return false;
						} );
					}, {
						maxWidth: 10000, // the width is set by the "Marker Popup Width" setting, not by the popup
					} );
					// The popup is opened by the click and by the Enter key, which doesn't fire the click
					marker.on( 'popupopen', function() {
						self._markPostVisited( marker, item.id );
					} );

					// Or the post link is opened in a new tab
				} else if ( self.options.markerClick === 'post_link' && item.url ) {
					marker.on( 'click', function() {
						self._markPostVisited( marker, item.id );
						_window.open( item.url, '_blank', 'noopener' );
					} );
				}
				return marker;
			} );

			// Clustered markers are added at once, it's much faster than one by one
			if ( self.options.clusterMarkers && L.markerClusterGroup ) {
				self._markersLayer = self._createClusterGroup().addLayers( layers );
			} else {
				self._markersLayer = L.featureGroup( layers );
			}
			self._markersLayer.addTo( self._mapInstance );

			self._fitMarkers();

			// Popups of the shown markers are loaded in the background, also when the view isn't changed, @see maps.js
			self._events.preloadVisible();
		},

		/**
		 * Create the group of markers, which are grouped into clusters
		 * @link https://github.com/Leaflet/Leaflet.markercluster
		 *
		 * @return {L.MarkerClusterGroup}
		 */
		_createClusterGroup: function() {
			var self = this;
			return L.markerClusterGroup( {
				showCoverageOnHover: false,
				// The same icon as for Google Maps, @see maps.js
				iconCreateFunction: function( cluster ) {
					var count = cluster.getChildCount(),
						size = self._getClusterSize( count );
					return L.divIcon( {
						html: self._getClusterSvg( size, self._getClusterTitle( count ) )
							+ '<span style="color:' + self._getClusterStyle().textColor + '">' + count + '</span>',
						className: 'w-map-cluster',
						iconSize: L.point( size, size ),
					} );
				},
			} ).on( 'animationend', self._events.preloadVisible );
		},

		/**
		 * Redraw icons of clusters with the current colors, @see maps.js
		 */
		_refreshClusters: function() {
			var self = this;
			if ( self._markersLayer && self._markersLayer.refreshClusters ) {
				self._markersLayer.refreshClusters();
			}
		},

		/**
		 * Remove all markers of posts from the map
		 */
		clearMarkers: function() {
			var self = this;
			if ( self._markersLayer ) {
				self._markersLayer.remove();
				self._markersLayer = _null;
			}
			self._activeMarker = _null;
			self._highlightedMarker = _null;
			self._markersByPost = new Map();
		},

		/**
		 * Fit the map to all markers of posts, the "Zoom" option is used as the maximum zoom
		 */
		_fitMarkers: function() {
			var self = this,
				hasMarkers = !! ( self._markersLayer && self._markersLayer.getLayers().length );

			self._toggleNoResults( ! hasMarkers );

			// The hidden map has zero size, so it's fitted when it becomes visible
			if ( self._waitForVisibility() ) {
				return;
			}

			if ( hasMarkers ) {
				self._mapInstance.fitBounds( self._markersLayer.getBounds(), {
					maxZoom: $ush.parseInt( self.options.zoom ) || 14,
					padding: [ 40, 40 ],
				} );

				// Show the whole world when there are no markers
			} else {
				self._mapInstance.setView( [ 20, 0 ], 2 );
			}
		},

		/**
		 * Add all markers to the map
		 */
		_renderMarkers: function() {
			var self = this;
			if ( ! self.options.markers.length ) {
				return;
			}
			// Add markers
			var mainOptions = self._getMarkerOptions( self._getMarkerLabel() );
			for ( var i = 0; i < self.options.markers.length; i++ ) {
				var item = self.options.markers[ i ];
				if ( i == 0 ) {
					// Add main marker with calculated coordinates
					var marker = L.marker( self.center, mainOptions ).addTo( self._mapInstance );
					self._watchActiveMarker( marker );
					// Add a popup to the 1st marker
					if ( item.html ) {
						if ( item.infowindow ) {
							marker.bindPopup( item.html ).openPopup();
						} else {
							marker.bindPopup( item.html );
						}
					}
				}
				else {
					var markerOptions = {};
					// All markers but first
					if ( item.marker_img != _null ) {
						markerOptions.icon = self._getIcon( {
							url: item.marker_img[0],
							size: item.marker_size,
						} );
					} else {
						markerOptions = mainOptions;
					}
					var matches = $ush.removeSpaces( item.address ) // Remove all spaces and tabs
						.match( _REGEXP_EXTRACT_COORDINATES_ );
					if ( matches ) {
						self.marker = L.marker( [ matches[/* latitude */1], matches[/* longitude */2] ], markerOptions ).addTo( self._mapInstance );
						self._watchActiveMarker( self.marker );
						if ( item.html ) {
							// Add a popup if marker has some text
							self.marker.bindPopup( item.html )
						}
					} else {
						self._geocoder( item.address, markerOptions, item.html );
					}
				}
			}
		}

	} );

	/**
	 * Wrapper for jQuery
	 *
	 * @param {{}} options The map options
	 * @return self
	 */
	$.fn.wLmaps = function( options ) {
		options = options || {};
		return this.each( function() {
			// Repeated calls must keep the instance, the constructor returns a blank object for the inited map
			if ( ! this._wLmaps ) {
				this._wLmaps = new $us.wLmaps( this, $ush.clone( options ) );
			}
		} );
	};

	// Initializing an element after loading a document
	$( function() {
		$( '.w-map.provider_osm' ).wLmaps();
	} );

}( jQuery );
