/**
 * UpSolution Element: Carousel
 */
! function( $, _undefined ) {
	"use strict";

	window.$us = window.$us || {};

	/**
	 * Behavior shared by all carousel elements.
	 *
	 * (!) The "Content Carousel" element declares this file as a dependency (see the
	 *     'content_carousel' entry in us-core/config/assets.php) and mixes this object into
	 *     its own prototype. Everything that is not specific to a single element belongs
	 *     here, so that a carousel fix never has to be repeated in two places.
	 *
	 * Expects the host object to provide: $carousel, options, owlCarousel, _events.
	 *
	 * @type {Object}
	 */
	$us.carouselMixin = {

		/**
		 * Elements that may receive the focus inside carousel items
		 *
		 * @type {String}
		 */
		focusableSelectors: [
			'a[href]', 'area[href]',
			'input:not([disabled])',
			'select:not([disabled])',
			'textarea:not([disabled])',
			'button:not([disabled])',
			'iframe', 'object', 'embed',
			'[tabindex]:not([tabindex="-1"])',
			'[contenteditable]', 'video[controls] source'
		].join(),

		/**
		 * Fallbacks for the accessible names provided by PHP
		 *
		 * @type {Object}
		 */
		defaultAriaLabels: {
			prev: 'Previous',
			next: 'Next',
			slide: 'item',
			slide_x_of_y: '%1$s / %2$s',
			play: 'Play',
			pause: 'Pause',
		},

		/**
		 * @return {Boolean} True if the user asked to minimize non-essential motion.
		 */
		prefersReducedMotion: function() {
			return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
		},

		/**
		 * Amend the options loaded from PHP, must run before the Owl Carousel init
		 */
		prepareOptions: function() {
			const self = this;

			// Accessible names, may be absent when overridden via the JS options filter
			self.ariaLabels = $.extend( {}, self.defaultAriaLabels, self.options.aria_labels || {} );

			// Bake the accessible names into the navigation buttons, so they survive any re-init.
			// (!) The "type" is required, otherwise the buttons submit the form they are placed in.
			$.extend( self.options, {
				navElement: 'button type="button"',
				navText: [
					'<span class="screen-reader-text">' + self.ariaLabels.prev + '</span>',
					'<span class="screen-reader-text">' + self.ariaLabels.next + '</span>',
				],
			} );

			// Respect the reduced motion system preference
			if ( self.prefersReducedMotion() ) {
				self.disableMotion();
			}

			// To prevent scroll blocking on mobiles
			if ( $us.$html.hasClass( 'touch' ) || $us.$html.hasClass( 'ios-touch' ) ) {
				self.options.mouseDrag = false;
			}

			// Override specific options for proper operation in Live Builder
			if ( $us.usbPreview() ) {
				$.extend( self.options, {
					autoplayHoverPause: true,
					mouseDrag: false,
					touchDrag: false,
					loop: false,
				} );
			}

			// Continual rotation moves at a constant speed, without pauses between the items
			if ( self.options.autoplayContinual ) {
				$.extend( self.options, {
					slideTransition: 'linear',
					autoplaySpeed: self.options.autoplayTimeout,
					smartSpeed: self.options.autoplayTimeout,
				} );
				if ( ! self.options.autoWidth ) {
					self.options.slideBy = 1;
				}
			}
		},

		/**
		 * Get current screen size.
		 *
		 * @return {String} The screen size.
		 */
		getScreenSize: function() {
			return ( String( this.$carousel[0].className ).match( /owl-responsive-(\d+)/ ) || [] )[1];
		},

		/**
		 * @return {Object} Options of the currently applied breakpoint.
		 */
		getResponsiveOptions: function() {
			return ( this.options.responsive || {} )[ this.getScreenSize() ] || {};
		},

		/**
		 * Toggle classes that depend on the currently applied breakpoint
		 */
		applyResponsiveClasses: function() {
			const self = this;
			const carouselResponsive = self.getResponsiveOptions();

			if ( carouselResponsive.items === 1 ) {
				self.$carousel.toggleClass( 'autoheight', !! carouselResponsive.autoHeight );
			}
			self.$carousel.toggleClass( 'with_dots', !! carouselResponsive.dots );
			self.$carousel.toggleClass( 'autoplay_continual_css', !! carouselResponsive.autoplayContinualCss );
		},

		/**
		 * Control animation appearance (USAnimate) of the items
		 */
		initItemAnimation: function() {
			const self = this;

			if ( ! $( '.us_animate_this:first', self.$carousel ).length ) {
				return;
			}

			if ( self.options.autoplayContinual ) {
				self.$carousel.on( 'translate.owl.carousel', self._events.controlItemAnimation );

			} else {
				$( '.owl-item.active', self.owlCarousel.$stage ).addClass( 'animation-start' );
				self.$carousel.on( 'translated.owl.carousel', self._events.controlItemAnimation );
			}
		},

		/**
		 * Re-init the "Show More" links after the carousel init to set the correct height
		 */
		initCollapsibleContent: function() {
			const self = this;
			const $toggleLinks = $( '[data-content-height]', self.$carousel );

			$toggleLinks.each( ( _, node ) => {
				const $node = $( node );
				var usCollapsibleContent = $node.data( 'usCollapsibleContent' );
				// Init for nodes that are cloned
				if ( $ush.isUndefined( usCollapsibleContent ) ) {
					usCollapsibleContent = $node.usCollapsibleContent().data( 'usCollapsibleContent' );
				}
				usCollapsibleContent.setHeight();
				$ush.timeout( () => {
					self.$carousel.trigger( 'refresh.owl.carousel' );
				}, 1 );
			} );

			// Updates the carousel height when expanding or collapsing text.
			// (!) The option is only set inside the responsive values, not on the top level.
			if ( self.getResponsiveOptions().autoHeight ) {
				$toggleLinks.on( 'showContent', () => {
					self.$carousel.trigger( 'refresh.owl.carousel' );
				} );
			}
		},

		/*
		 * Control animation appearance (USAnimate)
		 */
		controlItemAnimation: function( e ) {
			const self = this;
			if (
				! e.item
				|| ! e.item.index
				|| ! e.type
			) {
				return;
			}

			const $stage = self.owlCarousel.$stage;

			// Prevent hide item when it is visible for autoplayContinual
			if ( e.type === 'translate' && self.options.autoplayContinual ) {
				// Select item that will be translated
				const $translatedOwlItem = $( '.owl-item', $stage ).eq( e.item.index - 1 );
				if ( $translatedOwlItem.length ) {
					$translatedOwlItem.addClass( 'translated' );
					$ush.timeout( () => {
						$translatedOwlItem.removeClass( 'translated' );
					}, self.options.autoplaySpeed );
				}
			}

			// Control start animation class of items after carousel is translated
			if ( e.type === 'translated' ) {
				$stage.find( '.owl-item:not(.active)' ).removeClass( 'animation-start' );
				$stage.find( '.owl-item.active' ).addClass( 'animation-start' );
			}
		},
	};

	// Accessibility
	$.extend( $us.carouselMixin, {

		/**
		 * Turn off everything that moves on its own
		 */
		disableMotion: function() {
			const self = this;

			// Without the CSS rotation the items may only be reached by dragging,
			// because the arrows and dots are disabled for it on the PHP side
			const restoreDrag = !! self.options.autoplayContinualCss;

			// (!) Only the motion that starts on its own is turned off. The transition
			// speed must stay untouched: with "smartSpeed: 0" Owl stops firing the
			// translate events, which breaks its own navigation.
			$.extend( self.options, {
				autoplay: false,
				autoplayContinual: false,
				autoplayContinualCss: false,
			} );

			if ( restoreDrag ) {
				$.extend( self.options, {
					mouseDrag: true,
					touchDrag: true,
				} );
			}

			$.each( self.options.responsive || {}, ( _, responsiveOptions ) => {
				$.extend( responsiveOptions, {
					autoplay: false,
					autoplayContinualCss: false,
				} );
				if ( restoreDrag ) {
					$.extend( responsiveOptions, {
						mouseDrag: true,
						touchDrag: true,
					} );
				}
			} );
		},

		/**
		 * @return {Boolean} True if the carousel moves without a user action.
		 */
		hasMotion: function() {
			const self = this;

			if ( self.options.autoplay || self.options.autoplayContinualCss ) {
				return true;
			}
			for ( const breakpoint in ( self.options.responsive || {} ) ) {
				const responsiveOptions = self.options.responsive[ breakpoint ] || {};
				if ( responsiveOptions.autoplay || responsiveOptions.autoplayContinualCss ) {
					return true;
				}
			}
			return false;
		},

		/**
		 * Add the playback control and keep the ARIA structure up to date
		 */
		initA11y: function() {
			const self = this;

			if ( ! self.owlCarousel ) {
				return;
			}

			self.isPausedByUser = false;

			// Owl recreates the clones on every refresh, so the state must be reapplied
			self.$carousel.on( 'refreshed.owl.carousel', self._events.updateAria );

			self.updateAria();

			// WCAG 2.2.2: moving content must be stoppable.
			// (!) Prepended, so that the control comes before the content it stops.
			if ( self.hasMotion() ) {
				self.$playPause = $( '<button type="button" class="owl-playpause"></button>' )
					.attr( 'aria-label', self.ariaLabels.pause )
					.on( 'click', self._events.togglePlayback )
					.prependTo( self.$carousel );
			}
		},

		/**
		 * Describe every slide and hide the duplicates from assistive technology
		 */
		updateAria: function() {
			const self = this;

			if ( ! self.owlCarousel ) {
				return;
			}

			const $items = $( '.owl-item', self.owlCarousel.$stage );
			const $slides = $items.not( '.cloned, .us_cloned' );
			const itemsCount = $slides.length;

			$slides.each( ( index, node ) => {
				$( node ).attr( {
					'role': 'group',
					'aria-roledescription': self.ariaLabels.slide,
					'aria-label': self.getSlideLabel( index + 1, itemsCount ),
				} );
			} );

			// Clones repeat the content that is already present in the DOM.
			// (!) Focusable elements must leave the tab order, otherwise "aria-hidden" is invalid.
			$items.filter( '.cloned, .us_cloned' )
				.attr( 'aria-hidden', 'true' )
				.find( self.focusableSelectors )
				.attr( 'tabindex', -1 );
		},

		/**
		 * @param {Number} index Current slide number, starting from 1
		 * @param {Number} total Total amount of slides
		 * @return {String} The slide description, e.g. "3 of 8".
		 */
		getSlideLabel: function( index, total ) {
			return String( this.ariaLabels.slide_x_of_y )
				.replace( '%1$s', index )
				.replace( '%2$s', total );
		},

		/**
		 * Stop or resume the automatic rotation
		 *
		 * @param {Event} e
		 */
		togglePlayback: function( e ) {
			const self = this;

			self.isPausedByUser = ! self.isPausedByUser;

			$( e.currentTarget )
				.toggleClass( 'paused', self.isPausedByUser )
				.attr( 'aria-label', self.isPausedByUser ? self.ariaLabels.play : self.ariaLabels.pause );

			// The CSS-based continual rotation is stopped by the class only
			self.$carousel.toggleClass( 'is_paused', self.isPausedByUser );

			// (!) The cursor stays over the carousel after the click, so "pause on hover" would
			// immediately stop it again. An explicit user choice takes over from that point on.
			// The "is_playing" class does the same for the CSS-based rotation, see carousel.css
			self.$carousel.toggleClass( 'is_playing', ! self.isPausedByUser );
			self.owlCarousel.settings.autoplayHoverPause = false;
			self.owlCarousel.options.autoplayHoverPause = false;

			// (!) "play" starts the rotation even when the autoplay is off
			if ( self.owlCarousel.settings.autoplay ) {
				self.$carousel.trigger( ( self.isPausedByUser ? 'stop' : 'play' ) + '.owl.autoplay' );
			}
		},
	} );

	// Keyboard navigation
	$.extend( $us.carouselMixin, {

		/**
		 * Control the carousel navigation from a keyboard
		 */
		initKeyboardNav: function() {
			const self = this;

			const carouselResponsive = self.getResponsiveOptions();
			const focusableSelectors = self.focusableSelectors;

			if ( carouselResponsive.autoplay ) {

				// Stop the rotation while the focus is inside the carousel, so that
				// the item being read or operated does not move away
				self.$carousel.off( 'focusin.carouselKeyboardNav' ).on( 'focusin.carouselKeyboardNav', () => {
					self.$carousel.trigger( 'stop.owl.autoplay' );
				} );

				// Enable autoplay on focusout, unless it was stopped by the user
				self.$carousel.off( 'focusout.carouselKeyboardNav' ).on( 'focusout.carouselKeyboardNav', () => {
					// (!) "play" starts the rotation even when the autoplay is off
					if ( ! self.isPausedByUser && self.owlCarousel.settings.autoplay ) {
						self.$carousel.trigger( 'play.owl.autoplay' );
					}
				} );
			}

			// Move the carousel to the item that has just received the focus.
			// (!) Following the focus is the only reliable way to keep the focused element in
			// sight. Guessing the moment instead — "the focus is on the last focusable of the
			// active items, so the next Tab will leave them" — falls apart on looped carousels,
			// where the visible items may be clones, on "slide by page" and on a single item.
			const $viewport = self.owlCarousel.$stage.parent(); // .owl-stage-outer

			// (!) The viewport has "overflow: hidden", and the browser still scrolls such a box
			// to reveal a focused element inside it. That shifts the content away from the
			// position Owl holds in the stage transform: the focus ring ends up outside the
			// visible area and every further move is off by the scrolled amount. The offset is
			// dropped, and the carousel is moved by the handler below instead.
			$viewport.off( 'scroll.carouselFocusNav' ).on( 'scroll.carouselFocusNav', ( e ) => {
				e.currentTarget.scrollLeft = 0;
				e.currentTarget.scrollTop = 0;
			} );

			self.$carousel.off( 'focusin.carouselFocusNav' ).on( 'focusin.carouselFocusNav', ( e ) => {
				const $owlItem = $( e.target ).closest( '.owl-item' );

				// The focus is on the navigation itself
				if ( ! $owlItem.length ) {
					return;
				}

				$viewport[0].scrollLeft = 0;
				$viewport[0].scrollTop = 0;

				// (!) Owl marks the partially visible items as "active" as well, so its state
				// cannot be used here: an item may be "active" with most of it cut off, and the
				// focus ring inside it invisible. Only the geometry answers "is it fully in sight".
				const viewportRect = $viewport[0].getBoundingClientRect();
				const itemRect = $owlItem[0].getBoundingClientRect();

				if (
					itemRect.left >= viewportRect.left - 1
					&& itemRect.right <= viewportRect.right + 1
				) {
					return;
				}

				// The duplicates are excluded from the tab order, so only the originals are counted
				const index = $( '.owl-item', self.owlCarousel.$stage )
					.not( '.cloned, .us_cloned' )
					.index( $owlItem );

				if ( index < 0 ) {
					return;
				}

				// (!) The third argument keeps the value from being treated as a dots page index
				self.$carousel.trigger( 'to.owl.carousel', [ index, null, true ] );
			} );

			// Remember the navigation button that holds the focus, to be able to hand
			// the focus over before the button is hidden, see keepNavFocus()
			self.$carousel
				.off( '.carouselNavFocus' )
				.on( 'focusin.carouselNavFocus', '.owl-prev, .owl-next', ( e ) => {
					self.$focusedNav = $( e.currentTarget );
				} )
				// (!) Owl redraws the disabled state of the buttons on these very events,
				// and its own handlers are bound earlier, so they always run first
				.on(
					'changed.owl.carousel.carouselNavFocus refreshed.owl.carousel.carouselNavFocus',
					self._events.keepNavFocus
				);

			// Slide carousel with arrow keys when focused.
			// (!) Delegated to the focusable elements, so it only works when the focus
			// is inside the carousel. Screen readers in browse mode never pass these keys through.
			self.$carousel.off( 'keydown.carouselArrowsNav' ).on( 'keydown.carouselArrowsNav', focusableSelectors, ( e ) => {

				// Never steal the arrow keys from the fields where they move the caret or change the value
				if ( $( e.target ).is( 'input, textarea, select, [contenteditable]' ) ) {
					return;
				}

				const isRtl = !! self.options.rtl;

				switch ( e.keyCode ) {
					case 37: // ArrowLeft
						e.preventDefault();
						self.$carousel.trigger( ( isRtl ? 'next' : 'prev' ) + '.owl.carousel' );
						break;
					case 39: // ArrowRight
						e.preventDefault();
						self.$carousel.trigger( ( isRtl ? 'prev' : 'next' ) + '.owl.carousel' );
						break;
				}
			} );
		},

		/**
		 * Hand the focus over when the navigation button holding it becomes disabled
		 *
		 * (!) The "Hide" style of the disabled arrow applies "visibility: hidden", and such an
		 * element cannot keep the focus — the browser drops it to the document body. The user
		 * is left without a focus ring while the carousel is still moving.
		 */
		keepNavFocus: function() {
			const self = this;
			const $focusedNav = self.$focusedNav;

			if ( ! $focusedNav || ! $focusedNav.length || ! $focusedNav.hasClass( 'disabled' ) ) {
				return;
			}

			// The focus has already been moved elsewhere by the user
			if (
				document.activeElement !== $focusedNav[0]
				&& document.activeElement !== document.body
			) {
				return;
			}

			// The opposite arrow is always available: there is a way back from any edge
			const $opposite = $focusedNav.siblings( '.owl-prev, .owl-next' ).not( '.disabled' );

			// (!) Reset before moving the focus, otherwise the "focusin" handler below sets
			// the new button and this line wipes it right away, leaving the other edge unhandled
			self.$focusedNav = null;

			if ( $opposite.length ) {
				$opposite.trigger( 'focus' );
			} else if ( self.$playPause ) {
				self.$playPause.trigger( 'focus' );
			}
		},
	} );

	// Rotation via CSS
	$.extend( $us.carouselMixin, {

		/**
		 * Init continual rotation via CSS, if the current breakpoint asks for it
		 */
		initContinualRotationCss: function() {
			const self = this;

			if ( ! self.owlCarousel || ! self.options.autoplayContinualCss ) {
				return;
			}

			self.continualRotationCss();

			// Responsive continual rotation via CSS
			self.$carousel.on( 'resized.owl.carousel', self._events.continualRotationCssResize );
		},

		/**
		 * Continual rotation via CSS
		 * Duplicate items to make width higher than container for infinite rotation
		 */
		continualRotationCss: function( isResizeUse = false ) {
			const self = this;

			if ( ! self.$carousel.hasClass( 'autoplay_continual_css' ) ) {
				return;
			}

			const $stage = self.owlCarousel.$stage;
			const $items = $stage.children();

			// Do not duplicate items if they are already duplicated
			if (
				isResizeUse
				&& self.$originalItems
				&& ( self.$originalItems.length !== $items.length )
			) {
				return;
			}

			$stage.removeAttr( 'style' );

			if ( ! self.$originalItems ) {
				self.$originalItems = $items.clone();
			}

			var iteration = 0;

			// Fill the stage if needed
			while ( $stage[0].scrollWidth < self.owlCarousel.$element.outerWidth() ) {
				if ( iteration++ > 200 ) {
					break;
				}
				$stage.append( self.$originalItems.clone() );
			}

			// Duplicate stage content for infinite rotation
			$stage.append( $stage.html() );

			// The duplicates repeat the original items, so they must be ignored
			// by assistive technology and excluded from the tab order
			$stage.children().slice( self.$originalItems.length )
				.addClass( 'us_cloned' )
				.attr( 'aria-hidden', 'true' )
				.find( self.focusableSelectors )
				.attr( 'tabindex', -1 );
		},

		/**
		 * Toggle continual rotation via CSS based on responsive values
		 */
		continualRotationCssResize: function() {
			const self = this;

			self.owlCarousel.$stage.removeAttr( 'style' );

			if ( ! self.getResponsiveOptions().autoplayContinualCss ) {
				self.$carousel.removeClass( 'autoplay_continual_css' );
				self.owlCarousel.$stage.html( self.$originalItems );
				self.$carousel.trigger( 'refresh.owl.carousel' );

			} else {
				self.$carousel.addClass( 'autoplay_continual_css' );
				self.continualRotationCss( true );
			}

			self.updateAria();
		},
	} );

	/**
	 * Links of the popup gallery without the clones
	 * (!) Every level is a direct child, so links of nested grids stay out of the gallery
	 *
	 * @type {String}
	 */
	const POPUP_GALLERY_LINKS = '> .owl-stage-outer > .owl-stage > .owl-item:not(.cloned):not(.us_cloned) > .w-grid-item > .w-grid-item-h > a[ref=magnificPopupList]';

	/**
	 * Links of the popup gallery clones
	 * (!) Every level is a direct child, so links of nested grids are not taken for clones
	 *
	 * @type {String}
	 */
	const POPUP_GALLERY_CLONED_LINKS = '> .owl-stage-outer > .owl-stage > .owl-item.cloned > .w-grid-item > .w-grid-item-h > a[ref=magnificPopupList],'
		+ ' > .owl-stage-outer > .owl-stage > .owl-item.us_cloned > .w-grid-item > .w-grid-item-h > a[ref=magnificPopupList]';

	/**
	 * @param {Node} container.
	 */
	function usCarousel( container ) {
		const self = this;

		// Elements
		self.$container = $( container );
		self.$carousel = $( '.w-grid-list.owl-carousel', self.$container );

		// https://owlcarousel2.github.io/OwlCarousel2/docs/api-options.html
		self.options = {
			responsiveRefreshRate: 100,
		};

		// Bindable events
		self._events = {
			initializedOwlCarousel: self.initializedOwlCarousel.bind( self ),
			mousedownOwlCore: self.mousedownOwlCore.bind( self ),
			continualRotationCssResize: self.continualRotationCssResize.bind( self ),
			controlItemAnimation: self.controlItemAnimation.bind( self ),
			updateAria: self.updateAria.bind( self ),
			togglePlayback: self.togglePlayback.bind( self ),
			keepNavFocus: self.keepNavFocus.bind( self ),
		};

		// Load Owl Options
		const $opts = $( '.w-grid-carousel-json', self.$container );
		$.extend( self.options, ( $ush.getPassedData( $opts ) || {} ).carousel_settings || {} );
		$opts.remove();

		self.prepareOptions();

		// (!) Leftovers of a previous instance would be turned into carousel items on init
		$( '> .owl-playpause', self.$carousel ).remove();

		// Events
		self.$carousel
			.on( 'initialized.owl.carousel', self._events.initializedOwlCarousel )
			.on( 'mousedown.owl.core', self._events.mousedownOwlCore );

		// Init Owl Carousel
		self.owlCarousel = self.$carousel.owlCarousel( self.options ).data( 'owl.carousel' );

		self.initItemAnimation();

		// Trigger continual autoplay
		if ( self.owlCarousel && self.options.autoplayContinual ) {
			self.$carousel.trigger( 'next.owl.carousel' );
		}

		self.applyResponsiveClasses();
		self.initContinualRotationCss();

		// Open Post Image in a Popup
		if ( $( '[ref=magnificPopupList]:first', self.$carousel ).length ) {
			$ush.timeout( self.initMagnificPopup.bind( self ), 1 );
		}

		// Open posts in popup
		if ( self.$container.hasClass( 'open_items_in_popup' ) ) {
			new $us.usPopup().popupPost( self.$container );
		}

		// Expose the carousel structure and state to assistive technology
		self.initA11y();

		// Control the carousel navigation from a keyboard
		self.initKeyboardNav();
	}

	// Carousel API
	$.extend( usCarousel.prototype, $us.carouselMixin, {

		/**
		 * Re-init for "Show More" link after carousel init to set correct height.
		 *
		 * @param {Event} e
		 */
		initializedOwlCarousel: function( e ) {
			const self = this;

			self.initCollapsibleContent();

			// Refresh for active tabs
			if ( $.isMobile && self.$carousel.closest( '.w-tabs-section.active' ).length > 0 ) {
				$ush.timeout( () => {
					self.$carousel.trigger( 'refresh.owl.carousel' );
				}, 50 );
			}
		},

		/**
		 * Due to the carousel’s behavior, we handle movement completion manually,
		 * but sometimes errors occur when clicking on third-party elements.
		 *
		 * @param {Event} e
		 */
		mousedownOwlCore: function( e ) {
			const self = this;
			if ( ! String( e.target.className ).includes( 'collapsible-content-' ) ) {
				return;
			}
			if ( self.owlCarousel.settings.mouseDrag ) {
				self.owlCarousel.$stage.trigger( 'mouseup.owl.core' );
			}
			if ( self.owlCarousel.settings.touchDrag ) {
				self.owlCarousel.$stage.trigger( 'touchcancel.owl.core' );
			}
		},

		/**
		 * Open Post Image in a Popup
		 */
		initMagnificPopup: function() {
			const self = this;
			const globalOpts = $us.langOptions.magnificPopup || {};

			self.$carousel.magnificPopup( {
				type: 'image',
				delegate: POPUP_GALLERY_LINKS,
				gallery: {
					enabled: true,
					navigateByImgClick: true,
					preload: [0, 1],
					tPrev: globalOpts.tPrev, // Alt text on left arrow
					tNext: globalOpts.tNext, // Alt text on right arrow
					tCounter: globalOpts.tCounter // Markup for "1 of 7" counter
				},
				image: {
					titleSrc: 'aria-label'
				},
				removalDelay: 300,
				mainClass: 'mfp-fade',
				fixedContentPos: true,
				callbacks: {
					beforeOpen: function() {
						if ( self.owlCarousel && self.owlCarousel.settings.autoplay ) {
							self.$carousel.trigger( 'stop.owl.autoplay' );
						}
					},
					beforeClose: function() {
						if ( self.owlCarousel && self.owlCarousel.settings.autoplay ) {
							self.$carousel.trigger( 'play.owl.autoplay' );
						}
					}
				}
			} );

			// Clicking a clone opens the popup on the item that clone was made from
			self.$carousel.on( 'click', POPUP_GALLERY_CLONED_LINKS, ( e ) => {
				e.preventDefault();
				e.stopPropagation();

				self.getPopupLink( e.currentTarget ).trigger( 'click' );
			} );
		},

		/**
		 * Get the gallery link that shows the same image as a clone
		 * (!) The image URL is what Magnific Popup itself identifies an item by
		 *
		 * @param {Node} clonedLink The gallery link of a clone
		 * @return {jQuery} The link, empty if there is nothing to open
		 */
		getPopupLink: function( clonedLink ) {
			const self = this;
			const href = $ush.toString( clonedLink.getAttribute( 'href' ) );

			return $( POPUP_GALLERY_LINKS, self.$carousel )
				.filter( ( _, link ) => $ush.toString( link.getAttribute( 'href' ) ) === href )
				.first();
		},
	} );

	$.fn.usCarousel = function() {
		return this.each( function() {
			$( this ).data( 'usCarousel', new usCarousel( this ) );
		} );
	};

	$( () => $( '.w-grid.type_carousel' ).usCarousel() );

} ( jQuery );
