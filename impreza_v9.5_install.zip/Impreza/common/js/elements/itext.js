/**
 * UpSolution Element: Interactive Text
 */
!function( $ ) {
	"use strict";

	// Regular expression for searching for a space.
	const REGEXP_SPACE = /\p{Zs}/ug;

	/**
	 * @class usItext
	 * @param {string|node} container
	 */
	function usItext( container ) {
		const self = this;

		// Elements
		self.$container = $( container );
		self.$parts = $( '.w-itext-part', self.$container );
		if ( ! self.$parts.length ) {
			return;
		}

		// Options
		self.opts = $ush.getPassedData( self.$container ) || {};
		if ( ! $us.usbPreview() ) {
			self.$container.removeAttr( 'data-us-json' );
		}

		// Private "Variables"
		self.partsData = [];
		self._destroyed = false; // set by destroy() — stops the animation loops
		self.type = self.$container.usMod( 'type' ) || 'fadeIn';
		self.isCharsAnimate = self.type.includes( 'Chars' );
		self.isDisablePartAnimation = self.$container.hasClass( 'disable_part_animation' );
		self.spaceChar = ' ';

		// Whether the box width is managed at all (typing animation never is — it
		// renders inline). disable_part_animation IS managed: its whole-line states
		// have different widths and would otherwise jump on change at any width.
		self.isWidthManaged = ! self.isTypingChars();

		// A hidden element (closed tab, popup etc.) measures all widths as 0, so its
		// sizing is left to remeasure() on reveal and the parts keep a natural width.
		const isHidden = self.isHidden();

		// Fill data for each part
		self.$parts.each( ( _, node ) => {

			const $part = $( node );
			const $states = $( '.w-itext-state', $part );

			// State texts (needed for chars rendering and for re-measuring)
			const statesText = [];
			$states.each( ( _, node ) => {
				statesText.push( $( node ).text() );
			} );

			const part = {
				$part,
				$states,
				statesText,
				widths: [],
				minWidth: 0,
				maxWidth: 0,
				index: 0,
				stabilized: isHidden // set by applySizing() — true when width must not be animated
			};
			self.partsData.push( part );

			// Measure each state's width before the markup is rebuilt for chars
			self.refreshWidths( part );

			if ( self.isCharsAnimate ) {
				$part.html( statesText[0].replace( REGEXP_SPACE, self.spaceChar ) );
			}

			// Needed for 1st animation
			if ( self.isWidthManaged && ! isHidden ) {
				self.applySizing( part );
			}
		} );

		// Different logic for chars and simple animation
		self.partsData.forEach( ( part ) => {
			if ( self.isCharsAnimate ) {
				self.startCharsAnimate( part );
			} else {
				part.loopTimer = $ush.timeout( () => self.startSimpleAnimate( part ), self.opts.delay + self.opts.duration );
			}
		} );

		// Wrapping depends on the column width and on (responsive) font-size, so the
		// stabilize/animate decision must be re-evaluated when the viewport changes,
		// when the element is revealed (tabs, popups etc.) and once web fonts load.
		if ( self.isWidthManaged ) {
			self._onResize = $ush.debounce( () => self.remeasure(), 100 );
			$us.$window.on( 'resize', self._onResize );
			$us.$canvas.on( 'contentChange', self._onResize );
			// Widths measured with a fallback font are wrong once a web font (font-display: swap) loads
			document.fonts.ready.then( self._onResize );
		}
	};

	$.extend( usItext.prototype, {

		/**
		 * Determines if typing characters.
		 *
		 * @return {Boolean} True if typing characters, False otherwise.
		 */
		isTypingChars: function() {
			return this.type === 'typingChars';
		},

		/**
		 * Determines if the element is hidden (closed tab, popup etc.).
		 *
		 * @return {Boolean} True if hidden, False otherwise.
		 */
		isHidden: function() {
			return ! this.$container[0].offsetWidth;
		},

		/**
		 * Measure the pixel width of every state.
		 *
		 * - chars: the markup is rebuilt each cycle, so measure from the stored text
		 *   via a throwaway `.measure` span (same technique as renderChars()).
		 * - disable_part_animation: states are white-space:normal whole lines, so
		 *   measure each at its natural (possibly wrapped) width while in flow.
		 *   Inactive states are absolute and would collapse to min-content, so an
		 *   in-flow clone of each one is measured instead (toggling .is-active
		 *   on the real states would restart their CSS animations). Using the natural
		 *   width (never wider than the container) keeps the locked box from breaking
		 *   the states' own line wrapping.
		 * - simple: states are white-space:pre single lines — read offsetWidth.
		 *
		 * @param {{}} part - Part data object
		 * @return {number[]}
		 */
		measureWidths: function( part ) {
			const self = this;

			if ( self.isCharsAnimate ) {
				return part.statesText.map( ( text ) => {
					const $measure = $( '<span class="measure"></span>' )
						.text( text.replace( REGEXP_SPACE, self.spaceChar ) )
						.appendTo( part.$part );
					const width = $measure[0].offsetWidth;
					$measure.remove();
					return width;
				} );
			}

			// Drop any forced width from a previous sizing pass before measuring
			part.$states.css( 'width', '' );

			if ( self.isDisablePartAnimation ) {
				return $.map( part.$states, ( node ) => {
					const $clone = $( node ).clone().css( 'position', 'relative' ).appendTo( part.$part );
					const width = $clone[0].offsetWidth;
					$clone.remove();
					return width;
				} );
			}

			return $.map( part.$states, ( node ) => node.offsetWidth );
		},

		/**
		 * Re-measure widths and recompute min/max for a part.
		 *
		 * @param {{}} part - Part data object
		 */
		refreshWidths: function( part ) {
			part.widths = this.measureWidths( part );
			part.minWidth = part.widths.length ? Math.min( ...part.widths ) : 0;
			part.maxWidth = part.widths.length ? Math.max( ...part.widths ) : 0;
		},

		/**
		 * Decide whether animating this part's width would change line wrapping.
		 *
		 * The part width animates within [minWidth, maxWidth]; heading height grows
		 * monotonically with part width, so probing both ends is enough. If the line
		 * count differs between the narrowest and widest state, the width animation
		 * would reflow the heading (words jumping between lines) and the width must be
		 * locked instead. Depends only on content + container, never on screen width.
		 *
		 * @param {{}} part - Part data object
		 * @return {boolean}
		 */
		needsStabilization: function( part ) {
			const self = this,
				$part = part.$part,
				el = self.$container[0],
				saved = $part.attr( 'style' );

			// The CSS width transition is suppressed by applySizing(), so the probed widths
			// apply instantly — otherwise offsetHeight is read while width is still mid-transition.
			$part.css( { 'min-width': '', 'width': part.minWidth + 'px' } );
			const hMin = el.offsetHeight;
			$part.css( 'width', part.maxWidth + 'px' );
			const hMax = el.offsetHeight;

			// Restore the pre-probe inline styles; applySizing() sets the real mode next
			if ( saved == null ) {
				$part.removeAttr( 'style' );
			} else {
				$part.attr( 'style', saved );
			}

			return hMin !== hMax;
		},

		/**
		 * Apply the current sizing mode for a part.
		 *
		 * - stabilized: lock the part to its widest state (min-width) so the active
		 *   state can change without reflow; states fill the box and inherit the
		 *   heading's own alignment so crossfading states stay aligned.
		 * - animated: set an explicit per-state width and let the CSS width transition
		 *   run, so the box resizes smoothly in sync with the crossfade.
		 *   startSimpleAnimate updates that width on each state change.
		 *
		 * disable_part_animation is ALWAYS stabilized: its whole-line states swap as
		 * blocks of different widths, so the only way to avoid a jump is to lock the
		 * box to the widest state.
		 *
		 * @param {{}} part - Part data object
		 */
		applySizing: function( part ) {
			const self = this;

			// Apply the probed and the final widths instantly, otherwise the CSS width transition
			// would start from the last probed width (maxWidth) and the box would visibly shrink
			part.$part.addClass( 'notransition' );

			part.stabilized = self.isDisablePartAnimation || self.needsStabilization( part );

			if ( part.stabilized ) {
				part.$part.css( { 'width': '', 'min-width': part.maxWidth + 'px' } );
				if ( ! self.isCharsAnimate ) {
					part.$states.css( 'width', '100%' );
				}
			} else {
				part.$part.css( { 'min-width': '', 'width': part.widths[ part.index ] + 'px' } );
				if ( ! self.isCharsAnimate ) {
					part.$states.css( 'width', '' );
				}
			}

			// Reading a layout property forces a reflow, so the final width is applied before the transition is restored
			part.$part[0].offsetWidth;
			part.$part.removeClass( 'notransition' );
		},

		/**
		 * Re-measure widths and re-evaluate the sizing mode for all parts.
		 * Called on window resize, content change and once web fonts are loaded.
		 */
		remeasure: function() {
			const self = this;
			// Skip a pending call of a destroyed instance and a hidden element (all widths would be 0)
			if ( self._destroyed || self.isHidden() ) {
				return;
			}
			self.partsData.forEach( ( part ) => {
				// Reset any forced sizing so the natural layout can be measured
				part.$part.css( { 'width': '', 'min-width': '' } );

				self.refreshWidths( part );
				self.applySizing( part );
			} );
		},

		/**
		 * Starts a simple animation for a part
		 *
		 * @param {{}} part - Part data object
		 */
		startSimpleAnimate: function( part ) {
			const self = this;
			if ( self._destroyed ) {
				return;
			}

			if ( ! self.$container.hasClass( 'animation_started' ) ) {
				self.$container.addClass( 'animation_started' );
			}

			const nextIndex = ( part.index + 1 ) % part.$states.length;
			const $currentEl = part.$states.eq( part.index );
			const $nextEl = part.$states.eq( nextIndex );

			// Out
			$currentEl.removeClass( 'is-active' );

			// In
			$nextEl.addClass( 'is-active' );

			// Resize the box to the new state in sync with the change, so the CSS
			// width transition runs together with the crossfade. Stabilized parts keep
			// their fixed min-width and need no per-state update.
			if ( self.isWidthManaged && ! part.stabilized ) {
				part.$part.css( 'width', part.widths[ nextIndex ] + 'px' );
			}

			part.index = nextIndex;

			$ush.clearTimeout( part.loopTimer );

			part.loopTimer = $ush.timeout( () => self.startSimpleAnimate( part ), self.opts.delay + self.opts.duration );
		},

		/**
		 * Starts a chars animation for a part
		 *
		 * @param {{}} part - Part data object
		 */
		startCharsAnimate: function( part ) {
			$ush.timeout( () => this.charsNext( part ), this.opts.delay );
		},

		/**
		 * Set index of next item and start render chars
		 *
		 * @param {{}} part - Part data object
		 */
		charsNext: function( part ) {
			if ( this._destroyed ) {
				return;
			}
			part.index = ( part.index + 1 ) % part.statesText.length;
			this.renderChars( part );
		},

		/**
		 * Render a chars one by one with animation
		 *
		 * @param {{}} part - Part data object
		 */
		renderChars: function( part ) {
			const self = this;
			if ( self._destroyed ) {
				return;
			}
			const nextValue = part.statesText[ part.index ];
			const $node = part.$part;
			const duration = $ush.parseInt( self.opts.duration ) || 1000;
			var curDuration = duration;
			var startDelay = 0;

			const $curSpan = $node.wrapInner( '<span></span>' ).children( 'span' );
			const $nextSpan = $( '<span class="measure"></span>' )
				.text( nextValue.replace( REGEXP_SPACE, self.spaceChar ) )
				.appendTo( $node );

			const nextWidth = $nextSpan.width();

			// Typing animation - erase chars
			if ( self.isTypingChars() ) {
				const oldValue = $curSpan.text().trim() + ' ';
				const removeDuration = Math.floor( curDuration / 3 );
				startDelay = removeDuration * oldValue.length;

				for ( var i = 0; i < oldValue.length; i ++ ) {
					$ush.timeout( () => {
						const t = $curSpan.text();
						$curSpan.text( t.substring( 0, t.length - 1 ) );
					}, removeDuration * i );
				}
			}

			$ush.timeout( () => {

				$node.addClass( 'notransition' );
				// Animate width only when not stabilized; locked parts keep min-width.
				if ( self.isWidthManaged && ! part.stabilized ) {
					$node.css( 'width', $node.width() );
				}

				$ush.timeout( () => {
					$node.removeClass( 'notransition' );
					if ( self.isWidthManaged && ! part.stabilized ) {
						$node.css( 'width', nextWidth );
					}
				}, 25 );

				if ( ! self.isTypingChars() ) {
					$curSpan.addClass( 'hidden-state' ).css( 'width', nextWidth );
				}

				$nextSpan.removeClass( 'measure' ).prependTo( $node ).empty();

				const stagger = 60; // Delay between chars (zoomInChars only)

				for ( var i = 0; i < nextValue.length; i++ ) {
					const char = nextValue[ i ];

					if ( ! self.isTypingChars() ) {
						// Build with a text node so chars like < > & render literally
						const $char = $( '<span class="w-itext-char"></span>' )
							.text( char )
							.css( 'animation-delay', ( i * stagger ) + 'ms' )
							.appendTo( $nextSpan );

						$char.addClass( 'is-active' );
						// Needed to prevent char line break
						$char[0].onanimationend = () => {
							$char.css( 'display', 'inline' );
						};
					} else {
						// Append a text node — avoids re-parsing the growing HTML each
						// char (O(n^2)) and keeps < > & intact
						$ush.timeout( () => {
							$nextSpan[0].appendChild( document.createTextNode( char ) );
						}, curDuration * i );
					}
				}

				if ( self.isTypingChars() ) {
					curDuration *= ( nextValue.length + 1 );
				} else {
					curDuration = duration + ( nextValue.length * stagger );
				}

				$ush.timeout( () => {
					self.clearChars( part, nextValue );
				}, curDuration + Math.floor( self.opts.delay / 3 ) );

			}, startDelay );
		},

		clearChars: function( part, text ) {
			const self = this;
			if ( self._destroyed ) {
				return;
			}
			part.$part.html( text.replace( REGEXP_SPACE, self.spaceChar ) );
			$ush.timeout( () => self.charsNext( part ), self.opts.delay );
		},

		/**
		 * Tear down the instance: stop the animation loops and drop the resize and
		 * content change listeners. Called before re-initializing on the same/replaced
		 * node (e.g. in the builder, where usItext() runs again on every edit) so
		 * timers and window handlers don't accumulate.
		 */
		destroy: function() {
			const self = this;
			self._destroyed = true;
			if ( self._onResize ) {
				$us.$window.off( 'resize', self._onResize );
				$us.$canvas.off( 'contentChange', self._onResize );
			}
			( self.partsData || [] ).forEach( ( part ) => {
				$ush.clearTimeout( part.loopTimer );
			} );
		}
	} );


	$.fn.usItext = function() {
		return this.each( function() {
			const prevInstance = $( this ).data( 'usItext' );
			if ( prevInstance ) {
				prevInstance.destroy();
			}
			$( this ).data( 'usItext', new usItext( this ) );
		} );
	};

	$( () => $( '.w-itext' ).usItext() );

}( jQuery );
