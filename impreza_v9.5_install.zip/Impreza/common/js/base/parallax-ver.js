/**
 * Background Parallax - vertical parallax for the "Design > Background" option and the Row background image
 */
! function( $, undefined ) {
	"use strict";

	// Private variables that are used only in the context of this function, it is necessary to optimize the code.
	var _window = window,
		_document = document;

	// Prevent errors if our global objects are not set yet
	_window.$us = _window.$us || {};
	_window.$ush = _window.$ush || {};

	/**
	 * @type {[]} The list of CSS properties the effect writes inline.
	 */
	const _OWN_PROPS_ = [ 'background-size', 'background-position-y', 'background-attachment' ];

	/**
	 * @type {{}} Proportions (width / height) of the background images, the key is an image URL.
	 *            `null` marks an image that is still loading, so it is not requested again.
	 */
	var _imageRatios = {};

	/**
	 * Custom properties are inherited by default, and usof does not store a value equal to
	 * the default one. So an element that keeps the defaults has no properties of its own
	 * and would pick up the ones of a parent that has the parallax enabled.
	 */
	[ '--bg-parallax', '--bg-parallax-speed' ].map( function( name ) {
		try {
			CSS.registerProperty( { name: name, syntax: '*', inherits: false } );
		} catch ( err ) {
			// Not supported, or the property is already registered
		}
	} );

	/**
	 * Split a value of a multiple background property into layers.
	 *
	 * NOTE: a plain split by comma is not enough, since url() and gradients contain commas themselves.
	 *
	 * @param {String} value The computed value, e.g. `url(a.jpg), linear-gradient(red, blue)`.
	 * @return {[]} Returns the list of layer values.
	 */
	function splitLayers( value ) {
		var result = [],
			buffer = '',
			depth = 0;

		value = '' + ( value || '' );

		for ( var i = 0; i < value.length; i++ ) {
			var char = value.charAt( i );
			if ( char === '(' ) {
				depth++;
			} else if ( char === ')' ) {
				depth--;
			} else if ( char === ',' && depth === 0 ) {
				result.push( buffer.trim() );
				buffer = '';
				continue;
			}
			buffer += char;
		}
		if ( buffer.trim() ) {
			result.push( buffer.trim() );
		}

		return result;
	}

	/**
	 * Build a value for a multiple background property, where the first layer is ours
	 * and all the other layers keep their original values.
	 *
	 * @param {String} ownValue The value for the first layer.
	 * @param {String} originalValue The original computed value of the property.
	 * @param {Number} layerCount The amount of the background layers.
	 * @param {String} fallback The value for the layers, if the original value is empty.
	 * @return {String} Returns the resulting property value.
	 */
	function layerize( ownValue, originalValue, layerCount, fallback ) {
		if ( layerCount < 2 ) {
			return ownValue;
		}

		var layers = splitLayers( originalValue ),
			result = [ ownValue ];

		// Note: a list shorter than the amount of layers is repeated cyclically by CSS
		for ( var i = 1; i < layerCount; i++ ) {
			result.push( layers.length ? layers[ i % layers.length ] : fallback );
		}

		return result.join( ', ' );
	}

	/**
	 * Get the URL of the first background image layer.
	 *
	 * @param {String} backgroundImage The computed `background-image` value.
	 * @return {String} Returns the URL or an empty string.
	 */
	function getImageUrl( backgroundImage ) {
		var matches = /url\((['"]?)(.*?)\1\)/.exec( splitLayers( backgroundImage )[0] || '' );
		return matches ? matches[2] : '';
	}

	/**
	 * Get the vertical alignment of the first background layer as a 0-1 fraction.
	 *
	 * Note: the position keywords are computed to percents ("center" is "50%"), while a length
	 * is an explicit offset from the top, so it is treated as the top alignment.
	 *
	 * @param {String} backgroundPositionY The computed `background-position-y` value.
	 * @return {Number} Returns the fraction.
	 */
	function getAlignY( backgroundPositionY ) {
		var value = splitLayers( backgroundPositionY )[0] || '';
		return /%$/.test( value )
			? $ush.limitValueByRange( $ush.parseFloat( value ) / 100, 0, 1 )
			: 0;
	}

	/**
	 * Get the largest viewport height: on mobiles it is the height with the address bar hidden.
	 *
	 * The image sizes are computed for it, so the visible part of an element stays covered
	 * in any state of the address bar, while the positions do not depend on the viewport height.
	 *
	 * @return {Number} Returns the height in pixels.
	 */
	function getViewportHeight() {
		var height = _window.innerHeight;
		if ( typeof CSS !== 'undefined' && CSS.supports && CSS.supports( 'height', '100lvh' ) ) {
			var probe = _document.createElement( 'div' );
			probe.style.cssText = 'position:fixed;top:0;left:0;width:0;height:100lvh;visibility:hidden';
			_document.body.appendChild( probe );
			height = Math.max( height, probe.offsetHeight );
			_document.body.removeChild( probe );
		}
		return height;
	}

	/**
	 * @class USBgParallax - Background parallax manager.
	 */
	function USBgParallax() {
		var self = this;

		// Variables
		self.items = [];
		self.viewportHeight = _window.innerHeight;
		self._lastState = { width: 0, bodyHeight: 0 };

		/**
		 * @var {{}} Bindable events
		 */
		self._events = {
			onScroll: self._onScroll.bind( self ),
			onResize: $ush.debounce( self._onResize.bind( self ), 25 ),
			onRefresh: $ush.debounce( self.refresh.bind( self ), 25 ),
		};

		// Events
		$us.$window
			.on( 'scroll.noPreventDefault', self._events.onScroll )
			.on( 'resize', self._events.onResize )
			// Images and fonts inside an element change its height, so the size is measured again
			.on( 'load', self._events.onRefresh );

		// Handlers for updating the data when the content changes, including the Live Builder edits
		$us.$canvas.on( 'contentChange', self._events.onRefresh );
		$us.$document
			.on( 'usb.contentChange', self._events.onRefresh )
			// Grid and Post List items loaded via AJAX (pagination, filters, "Load more")
			.on( 'usPostList.itemsLoaded usGrid.itemsLoaded', self._events.onRefresh );
	}

	// Background parallax manager API
	USBgParallax.prototype = {

		/**
		 * Rescan the document and re-read the configuration of all the elements.
		 *
		 * NOTE: the DOM reads and writes are kept in separate passes, otherwise every write
		 * would force the browser to recalculate the styles before the next read.
		 */
		refresh: function() {
			var self = this;

			/**
			 * The inline properties must be restored before measuring, otherwise the computed style
			 * will contain the values written by the effect itself. The original inline values are put back,
			 * e.g. the Row background position, since the effect overwrote them.
			 *
			 * Note: the effect writes "important" values only, so a value without the priority was set
			 * after the effect by someone else, e.g. by the Live Builder preview, and is kept as is.
			 */
			self.items.map( function( item ) {
				var style = item.node.style;
				_OWN_PROPS_.map( function( propName ) {
					if ( style.getPropertyPriority( propName ) !== 'important' ) {
						return;
					}
					var original = item.inlineStyle[ propName ];
					if ( original.value ) {
						style.setProperty( propName, original.value, original.priority );
					} else {
						style.removeProperty( propName );
					}
				} );
			} );
			self.items = [];

			// Remember the state the items are built for, see _onResize()
			self._lastState.width = _window.innerWidth;
			self._lastState.bodyHeight = _document.body.clientHeight;

			if ( $us.areEffectsDisabled() ) {
				return;
			}

			self.viewportHeight = getViewportHeight();

			// Read pass
			$( '.has_bg_parallax' ).each( function() {
				/**
				 * NOTE: the marker class and the design class may be set to different nodes,
				 * e.g. a Column moves its "us_custom_*" class to the inner container.
				 */
				var item = self.readConfig( this )
					|| self.readConfig( this.querySelector( ':scope > [class*="us_custom_"]' ) );
				if ( item ) {
					self.items.push( item );
				}
			} );

			// Write pass
			self.items.map( function( item ) {
				// The "fixed" attachment resolves the geometry against the viewport by itself, which breaks the effect
				if ( item.fixedAttachment ) {
					item.node.style.setProperty( 'background-attachment', 'scroll', 'important' );
				}
				self.applySize( item );
			} );

			/**
			 * Set the initial position for all the items, including the ones outside the viewport.
			 * Otherwise the background stays at its CSS position and jumps to the calculated one
			 * at the very moment the element enters the view.
			 */
			self.updatePositions();
		},

		/**
		 * Read the configuration and the sizes of the node, without changing its styles.
		 *
		 * @param {Node|null} node The node.
		 * @return {{}|null} Returns the item data or null, if the parallax is not enabled for the node
		 *                   in the current responsive state.
		 */
		readConfig: function( node ) {
			if ( ! node ) {
				return null;
			}

			var style = getComputedStyle( node ),
				url = getImageUrl( style.backgroundImage );

			if ( style.getPropertyValue( '--bg-parallax' ).trim() !== 'vertical' || ! url ) {
				return null;
			}

			// The inline values of the own properties, they are restored by the next refresh()
			var inlineStyle = {};
			_OWN_PROPS_.map( function( propName ) {
				inlineStyle[ propName ] = {
					value: node.style.getPropertyValue( propName ),
					priority: node.style.getPropertyPriority( propName ),
				};
			} );

			return {
				node: node,
				url: url,
				// Note: the fallback matches the default value of the option, which is not saved
				speed: $ush.limitValueByRange( $ush.parseFloat( style.getPropertyValue( '--bg-parallax-speed' ) ) || 0.4, 0.1, 1 ),
				layers: splitLayers( style.backgroundImage ).length,
				originalSize: style.backgroundSize,
				originalPositionY: style.backgroundPositionY,
				fixedAttachment: splitLayers( style.backgroundAttachment )[0] === 'fixed',
				width: node.clientWidth,
				height: node.clientHeight,
				// The offset that aligns the image when it is higher than needed, see applySize()
				extraOffset: 0,
				// The size is applied and the position may be written, see applySize()
				ready: false,
				lastPosition: null,
				inlineStyle: inlineStyle,
			};
		},

		/**
		 * Set the background size that keeps the visible part of the element covered by the image
		 * at any scroll position, see applyPosition() for the movement model.
		 *
		 * Only the part of the element inside the viewport has to be covered, so the required height
		 * depends on the viewport height and not on the element height alone: at speed 1 it is
		 * the viewport height for an element of any height, at speed 0 it would be the element height.
		 *
		 * The size is chosen to match the "cover" size, which the compiled CSS sets for the parallax
		 * elements, whenever the required height allows it, so the image does not jump on page load.
		 *
		 * @param {{}} item The item data.
		 */
		applySize: function( item ) {
			var self = this,
				/**
				 * The image is never smaller than the element itself (the required height is smaller for elements
				 * higher than the viewport), so it matches the "cover" size painted by CSS before the script runs
				 * and the repeated tiles never get into the element.
				 */
				targetHeight = Math.ceil( Math.max(
					item.speed * self.viewportHeight + ( 1 - item.speed ) * item.height, item.height
				) ),
				ratio = _imageRatios[ item.url ],
				size = 'auto ' + targetHeight + 'px',
				extraOffset = 0;

			if ( ratio === undefined ) {
				ratio = self.loadImageRatio( item.url );
			}

			/**
			 * Nothing is written while the proportions are unknown: the element keeps the "cover" state
			 * of the compiled CSS, which is the initial state of the effect anyway, and an intermediate
			 * size would be painted for a frame in the browsers that load a cached image asynchronously.
			 * The size and the positions are applied once the image is loaded, see loadImageRatio().
			 */
			if ( ratio === null ) {
				item.ready = false;
				return;
			}

			/**
			 * For a portrait image or a wide element the "auto" width may become smaller than the element width,
			 * so the image is scaled by width instead. The extra height does not change the speed, it is only
			 * distributed around the visible part of the image according to the original vertical position,
			 * otherwise a short wide element would always show the top of the image.
			 *
			 * The offset is measured against the element height like the CSS position is, so the initial state
			 * matches the one painted by CSS before the script runs and the image does not jump on page load.
			 * It is limited to the extra height above the required one, otherwise the bottom would not be covered.
			 */
			if ( ratio && ratio * targetHeight < item.width ) {
				var imageHeight = item.width / ratio;
				size = '100% auto';
				extraOffset = $ush.limitValueByRange(
					( imageHeight - item.height ) * getAlignY( item.originalPositionY ), 0, imageHeight - targetHeight
				);
			}

			item.extraOffset = extraOffset;
			item.ready = true;
			item.node.style.setProperty(
				'background-size', layerize( size, item.originalSize, item.layers, 'auto' ), 'important'
			);
		},

		/**
		 * Load the natural proportions of the background image and apply the size to
		 * all the items with this image once it is known.
		 *
		 * @param {String} url The image URL.
		 * @return {Number|null} Returns the proportions (width / height) if the image is already available,
		 *                       null while it is loading.
		 */
		loadImageRatio: function( url ) {
			var self = this,
				image = new Image;

			// Mark the image as loading, so the other items with the same image do not request it again
			_imageRatios[ url ] = null;

			// Apply the size and the positions to all the items with this image
			// Note: the items may be rebuilt by a refresh() while the image was loading
			var applyToItems = function() {
				self.items.map( function( item ) {
					if ( item.url === url ) {
						self.applySize( item );
					}
				} );
				self.updatePositions();
			};

			image.onload = function() {
				// The proportions were read at once, see below
				if ( _imageRatios[ url ] ) {
					return;
				}
				_imageRatios[ url ] = image.naturalHeight
					? ( image.naturalWidth / image.naturalHeight )
					: 0;
				applyToItems();
			};
			image.onerror = function() {
				_imageRatios[ url ] = 0;
				applyToItems();
			};
			image.src = url;

			/**
			 * An image that is already in the browser cache (it is the background of the element, so
			 * it usually is) may be available right after the URL is set, e.g. in Chrome, then there is
			 * no need to wait for the load event. Other browsers report it via the load event only.
			 */
			if ( image.complete && image.naturalHeight ) {
				_imageRatios[ url ] = image.naturalWidth / image.naturalHeight;
			}

			return _imageRatios[ url ];
		},

		/**
		 * Handler for the resize event.
		 *
		 * NOTE: mobile browsers fire "resize" every time the address bar collapses or expands
		 * while scrolling. Only the viewport height changes then and the layout stays the same,
		 * while a rebuild would re-measure everything in the middle of the scroll.
		 * So the rebuild is done only when the layout has actually changed.
		 *
		 * @event handler
		 */
		_onResize: function() {
			var self = this;
			if (
				_window.innerWidth !== self._lastState.width
				|| _document.body.clientHeight !== self._lastState.bodyHeight
			) {
				self.refresh();

				// The viewport got higher without a reflow, e.g. the window height changed on desktops.
				// The sizes are computed for the viewport height, while the positions do not depend on it
			} else if ( _window.innerHeight > self.viewportHeight ) {
				self.viewportHeight = getViewportHeight();
				self.items.map( function( item ) {
					self.applySize( item );
				} );
				self.updatePositions();
			}
		},

		/**
		 * Handler for the scroll event.
		 *
		 * NOTE: the positions are written right in the handler, not in requestAnimationFrame().
		 * Browsers fire "scroll" at most once per frame right before rendering anyway, while in Firefox
		 * a frame callback requested from the scroll handler runs in the next frame only, so the image
		 * would lag behind the compositor by a frame and visibly jitter at high speeds.
		 *
		 * @event handler
		 */
		_onScroll: function() {
			var self = this;

			// Note: the list is empty when the effects are disabled, see refresh()
			if ( self.items.length ) {
				self.updatePositions();
			}
		},

		/**
		 * Set the background position of all the items matching the current scroll offset.
		 */
		updatePositions: function() {
			var self = this,
				viewportHeight = self.viewportHeight;

			/**
			 * NOTE: nodes outside the viewport are not skipped on purpose. Their top is clamped
			 * to the viewport edges anyway, so the position simply stops at the edge value
			 * and no writing happens, while skipping them would freeze the position at
			 * an arbitrary value and cause a jump once the node gets back into the view.
			 */

			// Read pass: all the geometry is measured before the first write
			var rects = self.items.map( function( item ) {
				return item.node.getBoundingClientRect();
			} );

			// Write pass
			self.items.map( function( item, index ) {
				self.applyPosition( item, rects[ index ], viewportHeight );
			} );
		},

		/**
		 * Set the background position matching the current scroll offset.
		 *
		 * The image is moved relative to the viewport, like a "fixed" background driven by JS:
		 * its top on the screen is `( 1 - speed ) * top`, where `top` is the element top on the screen,
		 * so the image goes up slower than the content and at speed 1 it stays fixed on the screen.
		 * The inline value is written in element coordinates, i.e. `- speed * top`.
		 *
		 * Note: the value depends neither on the viewport height nor on the image size, so the mobile
		 * address bar does not shift the image and a bigger image does not change the speed.
		 *
		 * @param {{}} item The item data.
		 * @param {DOMRect} rect The bounding rect of the node.
		 * @param {Number} viewportHeight The viewport height.
		 */
		applyPosition: function( item, rect, viewportHeight ) {
			// The image is still loading, the element keeps its CSS state, see applySize()
			if ( ! item.ready ) {
				return;
			}

			var top = $ush.limitValueByRange( rect.top, - item.height, viewportHeight ),
				position = ( - item.speed * top - item.extraOffset ).toFixed( 2 ) + 'px';

			if ( position === item.lastPosition ) {
				return;
			}
			item.lastPosition = position;

			item.node.style.setProperty(
				'background-position-y',
				layerize( position, item.originalPositionY, item.layers, '0%' ),
				'important'
			);
		},

	};

	// Export API
	$us.bgParallax = new USBgParallax;

	// Init background parallax
	$( function() {
		$us.bgParallax.refresh();
	} );

}( jQuery );
