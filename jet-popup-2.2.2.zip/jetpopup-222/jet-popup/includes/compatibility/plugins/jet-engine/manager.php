<?php
namespace Jet_Popup\Compatibility;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Compatibility Manager
 */
class Jet_Engine {

	/**
	 * Stored JetEngine listing data state for popup render.
	 *
	 * @var array|null
	 */
	private $popup_render_state = null;

	/**
	 * Include files
	 */
	public function load_files() {}

	/**
	 * Setup JetEngine current object for popup AJAX render.
	 *
	 * @param array $settings Popup render settings.
	 */
	public function setup_popup_render_context( $settings = array() ) {

		if ( empty( $settings['post_id'] ) || ! function_exists( 'jet_engine' ) ) {
			return;
		}

		$post = get_post( absint( $settings['post_id'] ) );

		if ( ! $post ) {
			return;
		}

		$data = jet_engine()->listings->data;

		$this->popup_render_state = [
			'post'           => $post,
			'current_object' => $data->get_current_object(),
			'wp_query'       => $GLOBALS['wp_query'] ?? null,
			'queried_object' => isset( $GLOBALS['wp_query'] ) ? $GLOBALS['wp_query']->queried_object : null,
		];

		$data->set_current_object( $post );

		if ( isset( $GLOBALS['wp_query'] ) && $GLOBALS['wp_query'] instanceof \WP_Query ) {
			$data->set_queried_object( $post, $GLOBALS['wp_query'] );
		}

		add_filter( 'jet-engine/listings/data/default-object', [ $this, 'set_popup_default_object' ], 9999, 2 );
	}

	/**
	 * Restore JetEngine state after popup AJAX render.
	 */
	public function reset_popup_render_context() {

		if ( ! $this->popup_render_state || ! function_exists( 'jet_engine' ) ) {
			return;
		}

		$data = jet_engine()->listings->data;

		remove_filter( 'jet-engine/listings/data/default-object', [ $this, 'set_popup_default_object' ], 9999 );

		if ( ! empty( $this->popup_render_state['current_object'] ) && is_object( $this->popup_render_state['current_object'] ) ) {
			$data->set_current_object( $this->popup_render_state['current_object'] );
		} else {
			$data->reset_current_object();
		}

		if (
			! empty( $this->popup_render_state['wp_query'] )
			&& $this->popup_render_state['wp_query'] instanceof \WP_Query
			&& isset( $this->popup_render_state['queried_object'] )
		) {
			$data->set_queried_object( $this->popup_render_state['queried_object'], $this->popup_render_state['wp_query'] );
		}

		$this->popup_render_state = null;
	}

	/**
	 * Provide popup item post as JetEngine default object.
	 *
	 * @param mixed $default_object
	 *
	 * @return mixed
	 */
	public function set_popup_default_object( $default_object ) {

		if ( empty( $this->popup_render_state['post'] ) || ! is_object( $this->popup_render_state['post'] ) ) {
			return $default_object;
		}

		return $this->popup_render_state['post'];
	}

	/**
	 * @param $conditions_list
	 *
	 * @return mixed
	 */
	public function modify_popup_conditions_group_list( $conditions_group_list ) {

		$groups_list = [
			'jet-engine' => [
				'label'      => __( 'Jet Engine', 'jet-popup' ),
				'sub-groups' => [],
			],
		];

		return wp_parse_args( $groups_list, $conditions_group_list );
	}

	/**
	 * @param $conditions_sub_group_list
	 *
	 * @return array|object
	 */
	public function modify_popup_conditions_sub_group_list( $conditions_sub_group_list ) {

		$sub_groups_list = [
			'jet-engine-custom-query' => [
				'label'   => __( 'Custom Query', 'jet-popup' ),
				'options' => [],
			],
		];

		return wp_parse_args( $sub_groups_list, $conditions_sub_group_list );
	}

	/**
	 * @param $conditions_list
	 *
	 * @return mixed
	 */
	public function modify_popup_conditions_list( $conditions_list ) {

		$base_path = jet_popup()->plugin_path( 'includes/compatibility/plugins/jet-engine/conditions/' );

		$new_conditions_list = [
			'\Jet_Popup\Conditions\Jet_Engine_Custom_Query_Has_Items'    => $base_path . 'custom-query-has-items.php',
			'\Jet_Popup\Conditions\Jet_Engine_Custom_Query_Has_No_Items' => $base_path . 'custom-query-has-no-items.php',
		];

		return wp_parse_args( $new_conditions_list, $conditions_list );
	}

	/**
	 * [__construct description]
	 */
	public function __construct() {

		if ( ! class_exists( 'Jet_Engine' ) ) {
			return false;
		}

		$this->load_files();

		add_filter( 'jet-popup/conditions/conditions-group-list', [ $this, 'modify_popup_conditions_group_list' ], 10, 2 );
		add_filter( 'jet-popup/conditions/condition-sub-groups', [ $this, 'modify_popup_conditions_sub_group_list' ], 10, 2 );
		add_filter( 'jet-popup/conditions/conditions-list', [ $this, 'modify_popup_conditions_list' ], 10, 2 );
		add_action( 'jet-popup/render/elementor-content/before', [ $this, 'setup_popup_render_context' ] );
		add_action( 'jet-popup/render/elementor-content/after', [ $this, 'reset_popup_render_context' ] );
		//add_filter( 'jet-popup/rest-api/endpoint-list', [ $this, 'modify_popup_endpoint_list' ], 10, 2 );

	}

}
