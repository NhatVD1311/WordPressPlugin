<?php
namespace Jet_Popup;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Elementor_Preview_Context {

	/**
	 * Stored state before switching preview query.
	 *
	 * @var bool
	 */
	private $query_switched = false;

	/**
	 * @var int
	 */
	private $post_switched = 0;

	/**
	 * Register AJAX actions.
	 */
	public function __construct() {
		add_action( 'wp_ajax_jet_popup_search_preview_posts', [ $this, 'ajax_search_preview_posts' ] );
	}

	/**
	 * Get preview source options.
	 *
	 * @return array
	 */
	public function get_preview_source_options() {
		$options = [
			'current_popup' => esc_html__( 'Current Popup', 'jet-popup' ),
			'current_post' => esc_html__( 'Current Post', 'jet-popup' ),
			'manual_selection' => esc_html__( 'Manual Selection', 'jet-popup' ),
		];

		if ( post_type_exists( 'product' ) ) {
			$options['current_product'] = esc_html__( 'Current Product', 'jet-popup' );
		}

		return $options;
	}

	/**
	 * Get available post types for preview controls.
	 *
	 * @return array
	 */
	public function get_preview_post_type_options() {
		$post_types = get_post_types(
			[
				'public' => true,
			],
			'objects'
		);

		$options = [];

		foreach ( $post_types as $post_type => $object ) {
			if ( empty( $object->labels->singular_name ) ) {
				continue;
			}

			$options[ $post_type ] = $object->labels->singular_name;
		}

		return $options;
	}

	/**
	 * Get default preview settings for a popup.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return array
	 */
	public function get_preview_settings( $popup_id ) {
		$document = $this->get_editor_document( $popup_id );
		$settings = [];

		if ( $document ) {
			$settings = $document->get_settings();
		}

		$defaults = [
			'jet_popup_preview_source'    => 'current_popup',
			'jet_popup_preview_post_type' => post_type_exists( 'post' ) ? 'post' : key( $this->get_preview_post_type_options() ),
			'jet_popup_preview_post_id'   => 0,
		];

		return wp_parse_args( $settings, $defaults );
	}

	/**
	 * Resolve document instance for editor/preview with autosave support.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return object|false
	 */
	private function get_editor_document( $popup_id ) {
		$documents = \Elementor\Plugin::instance()->documents;
		$popup_id  = absint( $popup_id );

		if ( ! $popup_id ) {
			return false;
		}

		if (
			\Elementor\Plugin::$instance->preview->is_preview_mode()
			|| ( isset( $_GET['elementor-preview'] ) && absint( wp_unslash( $_GET['elementor-preview'] ) ) === $popup_id ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			|| ( isset( $_GET['preview'] ) && filter_var( wp_unslash( $_GET['preview'] ), FILTER_VALIDATE_BOOLEAN ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		) {
			return $documents->get_doc_or_auto_save( $popup_id, get_current_user_id() );
		}

		return $documents->get( $popup_id );
	}

	/**
	 * Get preview settings overridden by request query args when present.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return array
	 */
	public function get_effective_preview_settings( $popup_id ) {
		$settings = $this->get_preview_settings( $popup_id );
		$temp_settings = $this->get_temporary_preview_settings( $popup_id );

		if ( ! empty( $temp_settings ) ) {
			$settings = wp_parse_args( $temp_settings, $settings );
		}

		if ( isset( $_GET['jet_popup_preview_source'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$settings['jet_popup_preview_source'] = sanitize_key( wp_unslash( $_GET['jet_popup_preview_source'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( isset( $_GET['jet_popup_preview_post_type'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$settings['jet_popup_preview_post_type'] = sanitize_key( wp_unslash( $_GET['jet_popup_preview_post_type'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( isset( $_GET['jet_popup_preview_post_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$settings['jet_popup_preview_post_id'] = absint( wp_unslash( $_GET['jet_popup_preview_post_id'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		return $settings;
	}

	/**
	 * Persist temporary preview settings for current user.
	 *
	 * @param int   $popup_id Popup ID.
	 * @param array $settings Settings to persist.
	 *
	 * @return void
	 */
	public function set_temporary_preview_settings( $popup_id, $settings = [] ) {
		$user_id = get_current_user_id();

		if ( ! $user_id || ! $popup_id || ! is_array( $settings ) ) {
			return;
		}

		update_user_meta(
			$user_id,
			$this->get_temporary_settings_meta_key( $popup_id ),
			[
				'jet_popup_preview_source'    => sanitize_key( $settings['jet_popup_preview_source'] ?? 'current_popup' ),
				'jet_popup_preview_post_type' => $this->sanitize_preview_post_type( $settings['jet_popup_preview_post_type'] ?? 'post' ),
				'jet_popup_preview_post_id'   => absint( $settings['jet_popup_preview_post_id'] ?? 0 ),
			]
		);
	}

	/**
	 * Get temporary preview settings for current user.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return array
	 */
	public function get_temporary_preview_settings( $popup_id ) {
		$user_id = get_current_user_id();

		if ( ! $user_id || ! $popup_id ) {
			return [];
		}

		$settings = get_user_meta( $user_id, $this->get_temporary_settings_meta_key( $popup_id ), true );

		return is_array( $settings ) ? $settings : [];
	}

	/**
	 * Resolve runtime preview object for popup rendering.
	 *
	 * @param int $popup_id Popup ID.
	 * @param int $runtime_post_id Runtime post ID.
	 *
	 * @return \WP_Post|false
	 */
	public function resolve_preview_post( $popup_id, $runtime_post_id = 0 ) {
		$runtime_post_id = absint( $runtime_post_id );

		if ( $runtime_post_id ) {
			$post = get_post( $runtime_post_id );

			if ( $post instanceof \WP_Post ) {
				return $post;
			}
		}

		$settings    = $this->get_effective_preview_settings( $popup_id );
		$source      = $settings['jet_popup_preview_source'];
		$post_type   = $this->sanitize_preview_post_type( $settings['jet_popup_preview_post_type'] );
		$selected_id = absint( $settings['jet_popup_preview_post_id'] );

		if ( 'current_popup' === $source ) {
			$post = get_post( $popup_id );

			if ( $post instanceof \WP_Post ) {
				return $post;
			}
		}

		if ( 'manual_selection' === $source && $selected_id ) {
			$post = get_post( $selected_id );

			if ( $post instanceof \WP_Post ) {
				return $post;
			}
		}

		if ( 'current_product' === $source ) {
			$post_type = 'product';
		}

		$queried_id = get_queried_object_id();

		if ( $queried_id ) {
			$queried_post = get_post( $queried_id );

			if ( $queried_post instanceof \WP_Post && $post_type === $queried_post->post_type ) {
				return $queried_post;
			}
		}

		return $this->get_fallback_post( $post_type );
	}

	/**
	 * Resolve preview URL for Elementor editor iframe.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return string
	 */
	public function get_preview_url( $popup_id ) {
		return $this->build_popup_preview_url( $popup_id, $this->get_effective_preview_settings( $popup_id ) );
	}

	/**
	 * Resolve preview URL using raw editor settings.
	 *
	 * @param int   $popup_id Popup ID.
	 * @param array $settings Preview settings.
	 *
	 * @return string
	 */
	public function get_preview_url_from_settings( $popup_id, $settings = [] ) {
		$settings = wp_parse_args( $settings, $this->get_preview_settings( $popup_id ) );

		return $this->build_popup_preview_url( $popup_id, $settings );
	}

	/**
	 * Switch current query to resolved preview object.
	 *
	 * @param int $popup_id Popup ID.
	 * @param int $runtime_post_id Runtime post ID.
	 *
	 * @return \WP_Post|false
	 */
	public function switch_to_preview( $popup_id, $runtime_post_id = 0 ) {
		$post = $this->resolve_preview_post( $popup_id, $runtime_post_id );

		if ( ! $post ) {
			return false;
		}

		$elementor_db = \Elementor\Plugin::instance()->db;

		if ( method_exists( $elementor_db, 'switch_to_query' ) ) {
			$elementor_db->switch_to_query(
				[
					'p'         => $post->ID,
					'post_type' => $post->post_type,
				],
				true
			);

			$this->query_switched = true;
		}

		if ( method_exists( $elementor_db, 'switch_to_post' ) ) {
			$elementor_db->switch_to_post( $post->ID );
			$this->post_switched = $post->ID;
		}

		return $post;
	}

	/**
	 * Restore current query after preview switch.
	 *
	 * @return void
	 */
	public function restore_preview() {
		$elementor_db = \Elementor\Plugin::instance()->db;

		if ( $this->post_switched && method_exists( $elementor_db, 'restore_current_post' ) ) {
			$elementor_db->restore_current_post();
			$this->post_switched = 0;
		}

		if ( $this->query_switched && method_exists( $elementor_db, 'restore_current_query' ) ) {
			$elementor_db->restore_current_query();
			$this->query_switched = false;
		}
	}

	/**
	 * AJAX handler for preview post search.
	 *
	 * @return void
	 */
	public function ajax_search_preview_posts() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error();
		}

		$search    = '';
		$post_type = ! empty( $_GET['jet_popup_preview_post_type'] ) ? sanitize_key( wp_unslash( $_GET['jet_popup_preview_post_type'] ) ) : 'post';
		$selected  = ! empty( $_GET['selected'] ) ? absint( $_GET['selected'] ) : 0;
		$query     = [
			'post_type'           => $this->sanitize_preview_post_type( $post_type ),
			'post_status'         => [ 'publish', 'private', 'draft' ],
			'posts_per_page'      => 20,
			'orderby'             => 'title',
			'order'               => 'ASC',
			'suppress_filters'    => false,
			'ignore_sticky_posts' => true,
		];

		if ( ! empty( $_GET['term'] ) ) {
			$search = sanitize_text_field( wp_unslash( $_GET['term'] ) );
		} elseif ( ! empty( $_GET['q'] ) ) {
			$search = sanitize_text_field( wp_unslash( $_GET['q'] ) );
		}

		if ( $selected ) {
			$query['post__in'] = [ $selected ];
			$query['orderby']  = 'post__in';
		} elseif ( $search ) {
			$query['s'] = $search;
		} else {
			wp_send_json( [] );
		}

		$posts   = get_posts( $query );
		$results = [];

		foreach ( $posts as $post ) {
			$results[] = [
				'id'   => $post->ID,
				'text' => $post->post_title ? $post->post_title : sprintf( '#%d', $post->ID ),
			];
		}

		wp_send_json( $results );
	}

	/**
	 * Get first suitable post for preview fallback.
	 *
	 * @param string $post_type Post type.
	 *
	 * @return \WP_Post|false
	 */
	private function get_fallback_post( $post_type ) {
		$posts = get_posts(
			[
				'post_type'           => $this->sanitize_preview_post_type( $post_type ),
				'post_status'         => [ 'publish', 'private' ],
				'posts_per_page'      => 1,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'suppress_filters'    => false,
				'ignore_sticky_posts' => true,
			]
		);

		return ! empty( $posts ) ? $posts[0] : false;
	}

	/**
	 * Build preview URL that keeps popup editor wrapper and passes context as query args.
	 *
	 * @param int   $popup_id Popup ID.
	 * @param array $settings Preview settings.
	 *
	 * @return string
	 */
	private function build_popup_preview_url( $popup_id, $settings = [] ) {
		$preview_url = get_permalink( $popup_id );

		if ( ! $preview_url ) {
			$preview_url = home_url( '/' );
		}

		return add_query_arg(
			[
				'jet_popup_preview_source'    => sanitize_key( $settings['jet_popup_preview_source'] ?? 'current_popup' ),
				'jet_popup_preview_post_type' => $this->sanitize_preview_post_type( $settings['jet_popup_preview_post_type'] ?? 'post' ),
				'jet_popup_preview_post_id'   => absint( $settings['jet_popup_preview_post_id'] ?? 0 ),
			],
			$preview_url
		);
	}

	/**
	 * Resolve preview post using raw settings.
	 *
	 * @param int   $popup_id Popup ID.
	 * @param array $settings Preview settings.
	 *
	 * @return \WP_Post|false
	 */
	private function resolve_preview_post_from_settings( $popup_id, $settings = [] ) {
		$settings = wp_parse_args(
			$settings,
			[
				'jet_popup_preview_source'    => 'current_popup',
				'jet_popup_preview_post_type' => 'post',
				'jet_popup_preview_post_id'   => 0,
			]
		);

		$source      = $settings['jet_popup_preview_source'];
		$post_type   = $this->sanitize_preview_post_type( $settings['jet_popup_preview_post_type'] );
		$selected_id = absint( $settings['jet_popup_preview_post_id'] );

		if ( 'current_popup' === $source ) {
			$post = get_post( $popup_id );

			if ( $post instanceof \WP_Post ) {
				return $post;
			}
		}

		if ( 'manual_selection' === $source && $selected_id ) {
			$post = get_post( $selected_id );

			if ( $post instanceof \WP_Post ) {
				return $post;
			}
		}

		if ( 'current_product' === $source ) {
			$post_type = 'product';
		}

		return $this->get_fallback_post( $post_type );
	}

	/**
	 * Sanitize preview post type.
	 *
	 * @param string $post_type Post type.
	 *
	 * @return string
	 */
	private function sanitize_preview_post_type( $post_type ) {
		$post_type = sanitize_key( $post_type );
		$options   = $this->get_preview_post_type_options();

		if ( ! isset( $options[ $post_type ] ) ) {
			return post_type_exists( 'post' ) ? 'post' : key( $options );
		}

		return $post_type;
	}

	/**
	 * Build unique user meta key for temporary preview state.
	 *
	 * @param int $popup_id Popup ID.
	 *
	 * @return string
	 */
	private function get_temporary_settings_meta_key( $popup_id ) {
		return 'jet_popup_preview_state_' . absint( $popup_id );
	}
}
