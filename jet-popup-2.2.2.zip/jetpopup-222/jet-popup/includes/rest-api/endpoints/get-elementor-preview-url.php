<?php
namespace Jet_Popup\Endpoints;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Get_Elementor_Preview_Url extends Base {

	public function get_method() {
		return 'POST';
	}

	public function get_name() {
		return 'get-elementor-preview-url';
	}

	public function get_args() {
		return [
			'documentId' => [
				'default'  => 0,
				'required' => true,
			],
			'settings' => [
				'default'  => [],
				'required' => false,
			],
		];
	}

	public function callback( $request ) {

		if ( is_wp_error( $request ) ) {
			return rest_ensure_response(
				[
					'success' => false,
					'message' => __( 'Server Error', 'jet-popup' ),
					'data'    => [],
				]
			);
		}

		$args       = $request->get_params();
		$document_id = absint( $args['documentId'] ?? 0 );
		$settings    = isset( $args['settings'] ) && is_array( $args['settings'] ) ? $args['settings'] : [];

		if ( ! $document_id ) {
			return rest_ensure_response(
				[
					'success' => false,
					'message' => __( 'Invalid document ID', 'jet-popup' ),
					'data'    => [],
				]
			);
		}

		$preview_context = jet_popup()->elementor_manager->preview_context ?? null;

		if ( ! $preview_context ) {
			return rest_ensure_response(
				[
					'success' => false,
					'message' => __( 'Preview context is unavailable', 'jet-popup' ),
					'data'    => [],
				]
			);
		}

		$preview_context->set_temporary_preview_settings( $document_id, $settings );

		$preview_url = $preview_context->get_preview_url_from_settings( $document_id, $settings );

		if ( empty( $preview_url ) ) {
			$preview_url = get_permalink( $document_id );
		}

		$preview_url = set_url_scheme(
			add_query_arg(
				[
					'preview'           => true,
					'preview_nonce'     => wp_create_nonce( 'post_preview_' . $document_id ),
					'elementor-preview' => $document_id,
				],
				$preview_url
			)
		);

		return rest_ensure_response(
			[
				'success' => true,
				'message' => __( 'Preview URL generated', 'jet-popup' ),
				'data'    => [
					'previewUrl' => $preview_url,
				],
			]
		);
	}
}
