( function( $ ) {

	'use strict';

	var JetPopupEditor,
		JetPopupControlsViews;

	JetPopupControlsViews = {

		JetSearchView: null,

		init: function() {

			var self = this;

			self.JetSearchView = window.elementor.modules.controls.BaseData.extend( {

				storeSavedOption: function( optionData ) {
					var saved = this.model.get( 'saved' ) || {},
						value = optionData && undefined !== optionData.id ? String( optionData.id ) : '',
						label = optionData && undefined !== optionData.text ? optionData.text : '';

					if ( ! value || ! label ) {
						return;
					}

					saved[ value ] = label;
					this.model.set( 'saved', saved );
				},

				syncSelectedOption: function( optionData ) {
					var value = optionData && undefined !== optionData.id ? String( optionData.id ) : '',
						label = optionData && undefined !== optionData.text ? optionData.text : '',
						option = null;

					if ( ! value ) {
						this.ui.select.val( null ).trigger( 'change.select2' );

						return;
					}

					option = this.ui.select.find( 'option[value="' + value.replace( /"/g, '\\"' ) + '"]' );

					if ( option.length ) {
						option.text( label ).prop( 'selected', true );
					} else {
						option = new Option( label, value, true, true );
						this.ui.select.append( option );
					}

					this.ui.select.val( value ).trigger( 'change.select2' );
				},

				getQueryString: function() {
					var query       = '',
						queryParams = this.model.attributes.query_params || [];

					if ( queryParams.length > 0 ) {
						$.each( queryParams, function( index, param ) {
							if ( window.elementor.settings.page.model.attributes[ param ] ) {
								query += '&' + param + '=' + encodeURIComponent( window.elementor.settings.page.model.attributes[ param ] );
							}
						} );
					}

					return query;
				},

				hydrateSelectedOption: function() {
					var value = this.getControlValue();

					if ( ! value ) {
						return;
					}

					if ( this.ui.select.find( 'option[value="' + String( value ).replace( /"/g, '\\"' ) + '"]' ).text() ) {
						this.syncSelectedOption( {
							id: value,
							text: this.ui.select.find( 'option[value="' + String( value ).replace( /"/g, '\\"' ) + '"]' ).text()
						} );

						return;
					}

					$.ajax( {
						url: ajaxurl + '?action=' + this.model.attributes.action + this.getQueryString() + '&selected=' + encodeURIComponent( value ),
						dataType: 'json'
					} ).done( ( response ) => {
						var optionData = response && response.length ? response[0] : null;

						if ( ! optionData ) {
							return;
						}

						this.storeSavedOption( optionData );
						this.syncSelectedOption( optionData );
					} );
				},

				onReady: function() {

					var action = this.model.attributes.action,
						self   = this;

					this.ui.select.find( 'option' ).each(function(index, el) {
						$( this ).attr( 'selected', true );
					});

						this.ui.select.select2( {
							ajax: {
								url: function() {
									return ajaxurl + '?action=' + action + self.getQueryString();
								},
								dataType: 'json',
								data: function( params ) {
									return {
										term: params.term || '',
										q: params.term || '',
									};
								},
								processResults: function( response ) {
									return {
										results: response || [],
									};
								}
							},
							width: 'resolve',
							placeholder: 'Please enter 3 or more characters',
							minimumInputLength: 3
					} );
					this.hydrateSelectedOption();

					this.ui.select.on( 'change.jetPopupSearch', () => {
						self.setValue( self.ui.select.val() );
					} );

					this.ui.select.on( 'select2:select.jetPopupSearch', ( event ) => {
						var optionData = event.params && event.params.data ? event.params.data : null;

						if ( ! optionData ) {
							return;
						}

						self.storeSavedOption( optionData );
						self.syncSelectedOption( optionData );
						self.setValue( optionData.id );
					} );

				},

				onBeforeDestroy: function() {

					this.ui.select.off( '.jetPopupSearch' );

					if ( this.ui.select.data( 'select2' ) ) {
						this.ui.select.select2( 'destroy' );
					}

					this.$el.remove();
				}

			} );

			window.elementor.addControlView( 'jet_popup_search', self.JetSearchView );

		}

	};

	JetPopupEditor = {
		previewReloadRequest: null,
		previewApplyRequest: null,

		init: function() {
			let panel = jQuery( '#elementor-editor-wrapper' );

			panel.on( 'click', 'button[data-event="jet-popup-conditions-manager"]', function( event ) {
				window.open( window.jetPopupData.conditionManagerUrl, '_blank' );
			} );

			panel.on( 'click', 'button[data-event="jet-popup-apply-preview"]', function( event ) {
				event.preventDefault();
				JetPopupEditor.applyPreviewSettings( elementor.settings.page.model, {
					reloadEditorPage: true
				} );
			} );

			elementor.settings.page.model.on( 'change', JetPopupEditor.onPageSettingsChange );

			JetPopupControlsViews.init();
		},

		onPageSettingsChange: function( model ) {
			var iframe   = document.getElementById( 'elementor-preview-iframe' ),
				innerDoc = iframe.contentDocument || iframe.contentWindow.document;

			if ( model.changed.hasOwnProperty( 'jet_popup_preview_post_type' ) ) {
				model.set( 'jet_popup_preview_post_id', '' );
			}

			if ( model.changed.hasOwnProperty( 'close_button_icon' ) ) {
				var closeButton = $( '.jet-popup__close-button', innerDoc ),
					icon        = model.changed['close_button_icon'];

				$( 'i', closeButton ).attr( 'class', icon );
			}

			if ( model.changed.hasOwnProperty( 'selected_close_button_icon' ) ) {
				var $closeButton = $( '.jet-popup__close-button', innerDoc ),
				    iconData    = model.changed['selected_close_button_icon'];

				$closeButton.css( { 'opacity': 0.5 } );

				wp.apiFetch( {
					method: 'post',
					path: window.jetPopupData.getElementorIconHtml,
					data: {
						iconData: iconData
					},
				} ).then( ( response ) => {
					$closeButton.css( { 'opacity': 1 } );

					if ( response.success ) {
						$closeButton.html( response.data.iconHtml );
					}
				} );
			}

			if ( model.changed.hasOwnProperty( 'use_close_button' ) ) {
				var useCloseButton = ( 'yes' === model.changed['use_close_button'] ) ? true : false,
					closeButton    = $( '.jet-popup__close-button', innerDoc );

				if ( useCloseButton ) {
					closeButton.removeClass( 'hidden' );
				} else {
					closeButton.addClass( 'hidden' );
				}
			}

			if ( model.changed.hasOwnProperty( 'use_overlay' ) ) {
				var useOverlay = ( 'yes' === model.changed['use_overlay'] ) ? true : false,
					$overlay   = $( '.jet-popup__overlay', innerDoc );

				if ( useOverlay ) {
					$overlay.removeClass( 'hidden' );
				} else {
					$overlay.addClass( 'hidden' );
				}
			}

			if ( model.changed.hasOwnProperty( 'jet_popup_animation' ) ) {
				var $popup = $( '.jet-popup', innerDoc );

				JetPopupEditor.animationPopup(
					$popup,
					model.changed['jet_popup_animation'],
					model.attributes['jet_popup_animation_custom_duration'],
					model.attributes['jet_popup_animation_in_duration'],
					model.attributes['jet_popup_animation_out_duration']
				);
			}

		},

		applyPreviewSettings: function( model, options ) {
			var documentId = parseInt( window.jetPopupData.currentDocumentId || 0, 10 );

			options = options || {};

			if ( ! window.wp || ! wp.apiFetch ) {
				return;
			}

			if ( ! documentId ) {
				if ( window.elementor && window.elementor.reloadPreview ) {
					window.elementor.reloadPreview();
				}

				return;
			}

			if ( JetPopupEditor.previewReloadRequest && JetPopupEditor.previewReloadRequest.abort ) {
				JetPopupEditor.previewReloadRequest.abort();
			}

			JetPopupEditor.previewReloadRequest = wp.apiFetch( {
				method: 'post',
				path: window.jetPopupData.getElementorPreviewUrl,
				data: {
					documentId: documentId,
					settings: {
						jet_popup_preview_source: model.get( 'jet_popup_preview_source' ),
						jet_popup_preview_post_type: model.get( 'jet_popup_preview_post_type' ),
						jet_popup_preview_post_id: model.get( 'jet_popup_preview_post_id' )
					}
				}
			} ).then( ( response ) => {
				var previewUrl = response && response.success && response.data ? response.data.previewUrl : '';

				JetPopupEditor.saveAndReloadPreview( previewUrl, options );
			} ).catch( () => {
				if ( options.reloadEditorPage ) {
					window.location.reload();
				} else if ( window.elementor && window.elementor.reloadPreview ) {
					window.elementor.reloadPreview();
				}
			} );
		},

		saveAndReloadPreview: function( previewUrl, options ) {
			options = options || {};

			if ( ! window.$e || ! $e.run ) {
				if ( options.reloadEditorPage ) {
					window.location.reload();
				} else if ( previewUrl ) {
					JetPopupEditor.reloadPreviewFrame( previewUrl );
				} else if ( window.elementor && window.elementor.reloadPreview ) {
					window.elementor.reloadPreview();
				}

				return;
			}

			JetPopupEditor.previewApplyRequest = $e.run( 'document/save/auto', {
				force: true,
				onSuccess: function() {
					if ( window.elementor && window.elementor.dynamicTags && window.elementor.dynamicTags.cleanCache ) {
						window.elementor.dynamicTags.cleanCache();
					}

					if ( options.reloadEditorPage ) {
						window.location.reload();
					} else if ( previewUrl ) {
						JetPopupEditor.reloadPreviewFrame( previewUrl );
					} else if (
						window.elementor
						&& window.elementor.config
						&& window.elementor.documents
						&& window.elementor.config.initial_document
						&& window.elementor.config.initial_document.id === window.elementor.documents.getCurrentId()
					) {
						window.elementor.reloadPreview();
					} else if ( $e.internal ) {
						$e.internal( 'editor/documents/attach-preview' );
					}
				}
			} );
		},

		reloadPreviewFrame: function( previewUrl ) {
			var iframe = document.getElementById( 'elementor-preview-iframe' );

			if ( iframe && previewUrl ) {
				iframe.src = previewUrl;

				return;
			}

			if ( window.elementor && window.elementor.reloadPreview ) {
				window.elementor.reloadPreview();
			}
		},

		animationPopup: function( $popup, effect, custom_duration, in_duration, out_duration ) {

			const useCustom = custom_duration === 'yes';
			
			const inDurationNum = useCustom && in_duration ? parseInt(in_duration) : null;
			const outDurationNum = useCustom && out_duration ? parseInt(out_duration) : null;
			
			const effects = JetPopupEditor.avaliableEffects( inDurationNum, outDurationNum );
			
			const animeContainerSettings = jQuery.extend(
				{
					targets: $( '.jet-popup__container', $popup )[0]
				},
				effects[ effect ].show
			);
			
			anime( animeContainerSettings );
		},

		avaliableEffects: function( in_duration, out_duration ) {

			const effects = {
				'none': {
					'show': {
						duration: 0,
						opacity: {
							value: [ 1, 1 ],
						}
					},
					'hide': {
						duration: 0,
						opacity: {
							value: [ 1, 1 ],
						}
					}
				},
		
				'fade' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration || 600,
							easing: 'easeOutQuart',
						},
					},
					'hide': {
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
							easing: 'easeOutQuart',
							duration: out_duration || 400,
						},
					}
				},
		
				'zoom-in' : {
					'show': {
						duration: in_duration || 500,
						delay: 200,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 0, 1 ],
						},
						scale: {
							value: [ 0.75, 1 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						scale: {
							value: [ 1, 0.75 ],
						}
					}
				},
		
				'zoom-out' : {
					'show': {
						duration: in_duration || 500,
						delay: 200,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 0, 1 ],
						},
						scale: {
							value: [ 1.25, 1 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						scale: {
							value: [ 1, 1.25 ],
						}
					}
				},
		
				'rotate' : {
					'show': {
						duration: in_duration || 500,
						delay: 200,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 0, 1 ],
						},
						scale: {
							value: [ 0.75, 1 ],
						},
						rotate: {
							value: [ -65, 0 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						scale: {
							value: [ 1, 0.9 ],
						},
					}
				},
		
				'move-up' : {
					'show': {
						duration: in_duration || 500,
						delay: 200,
						easing: 'easeOutExpo',
						opacity: {
							value: [ 0, 1 ],
						},
						translateY: {
							value: [ 50, 1 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						translateY: {
							value: [ 1, 50 ],
						}
					}
				},
		
				'flip-x' : {
					'show': {
						duration: in_duration || 1000,
						delay: 200,
						easing: 'easeOutExpo',
						opacity: {
							value: [ 0, 1 ],
						},
						rotateX: {
							value: [ 65, 0 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						}
					}
				},
		
				'flip-y' : {
					'show': {
						duration: in_duration || 1000,
						delay: 200,
						easing: 'easeOutExpo',
						opacity: {
							value: [ 0, 1 ],
						},
						rotateY: {
							value: [ 65, 0 ],
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						}
					}
				},
		
				'bounce-in' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration || 500,
							easing: 'easeOutQuart',
						},
						scale: {
							value: [ 0.2, 1 ],
							duration: (in_duration ? in_duration * 1.6 : 800),
							elasticity: function(el, i, l) {
								return (400 + i * 200);
							},
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						scale: {
							value: [ 1, 0.8 ],
						}
					}
				},
		
				'bounce-out' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration || 500,
							easing: 'easeOutQuart',
						},
						scale: {
							value: [ 1.8, 1 ],
							duration: (in_duration ? in_duration * 1.6 : 800),
							elasticity: function(el, i, l) {
								return (400 + i * 200);
							},
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeOutQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						scale: {
							value: [ 1, 1.5 ],
						}
					}
				},
		
				'slide-in-up' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration ? Math.min(in_duration * 0.53, 400) : 400,
							easing: 'easeOutQuart',
						},
						translateY: {
							value: ['100vh', 0],
							duration: in_duration || 750,
							easing: 'easeOutQuart',
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeInQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						translateY: {
							value: [0,'100vh'],
						}
					}
				},
		
				'slide-in-right' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration ? Math.min(in_duration * 0.53, 400) : 400,
							easing: 'easeOutQuart',
						},
						translateX: {
							value: ['100vw', 0],
							duration: in_duration || 750,
							easing: 'easeOutQuart',
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeInQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						translateX: {
							value: [0,'100vw'],
						}
					}
				},
		
				'slide-in-down' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration ? Math.min(in_duration * 0.53, 400) : 400,
							easing: 'easeOutQuart',
						},
						translateY: {
							value: ['-100vh', 0],
							duration: in_duration || 750,
							easing: 'easeOutQuart',
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeInQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						translateY: {
							value: [0,'-100vh'],
						}
					}
				},
		
				'slide-in-left' : {
					'show': {
						delay: 200,
						opacity: {
							value: [ 0, 1 ],
							duration: in_duration ? Math.min(in_duration * 0.53, 400) : 400,
							easing: 'easeOutQuart',
						},
						translateX: {
							value: ['-100vw', 0],
							duration: in_duration || 750,
							easing: 'easeOutQuart',
						}
					},
					'hide': {
						duration: out_duration || 400,
						easing: 'easeInQuart',
						opacity: {
							value: [ 1, 0 ],
						},
						translateX: {
							value: [0,'-100vw'],
						}
					}
				}
			};
			
			return effects;
		}

	};

	$( window ).on( 'elementor:init', JetPopupEditor.init );

}( jQuery ) );
