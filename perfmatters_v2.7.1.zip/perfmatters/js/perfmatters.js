jQuery(function($) {

	var pmActionButtonTimeouts = [];

	//tab-content display
	$('#perfmatters-menu a[rel][href^="#"]').on('click', function(e) {

		//leave snippet editor when already on Code tab; otherwise return via client-side switch
		if(new URLSearchParams(location.search).has('snippet') && $(this).attr('rel') === 'code-code' && $('#perfmatters-menu a.active').attr('rel') === 'code-code') {
			e.preventDefault();
			var hash = $(this).attr('href');
			location.href = '?page=perfmatters' + (hash === '#' ? '' : hash);
			return;
		}

		$('.perfmatters-button-message').hide();
		$('#perfmatters-action-toast').removeClass('is-visible');
					
		//deactivate previous active tab + content
		var activeTab = $('#perfmatters-menu a.active');
		var activeContent = $('#' + activeTab.attr('rel'));
		activeTab.removeClass('active');
		activeContent.removeClass('active');

		//deactivate previous active child content
		var activeChild = $('#perfmatters-settings [data-pm-parent="' + activeTab.attr('rel') + '"].active');
		activeChild.removeClass('active');

		//activate selected tab + content
		$(this).addClass('active');
		var selected = $(this).attr('rel');
		$('#' + selected).addClass('active');

		//activate selected subnav
		var selectedSubNav = $('#' + selected).attr('data-pm-subnav');
		if(selectedSubNav) {
			$('#' + selectedSubNav).addClass('active');
		}

		//update selected section in settings container
		$('#perfmatters-settings').attr('data-pm-option', selected.split('-')[0]);
		
		//refresh codemirrors
		//do we need to refresh on tab change?
		$('#perfmatters-admin .CodeMirror').each(function(i, el) {
		    el.CodeMirror.refresh();
		});
	});

	//sub nav display
	$('.pm-subnav > a').on('click', function(e) {

		var active = $(this).closest('.pm-subnav').find('a.active');	
		var selected = $(this).attr('rel');

		//deactivate previous active subnav + content
		$('#' + active.attr('rel')).removeClass('active');

		//activate selected subnav + content
		$('#' + selected).addClass('active');
		
		//do we need to refresh here on subnav change?
		$('#perfmatters-admin .CodeMirror').each(function(i, el) {
		    el.CodeMirror.refresh();
		});
	});

	//menu toggle
	var menuToggle = document.getElementById('perfmatters-menu-toggle');
	if(menuToggle) {
		menuToggle.addEventListener('click', function(e) {
			e.preventDefault();
			var header = document.getElementById('perfmatters-menu');
			if(!header.classList.contains('perfmatters-menu-expanded')) {
				header.classList.add('perfmatters-menu-expanded');
			}
			else {
				header.classList.remove('perfmatters-menu-expanded');
			}
		});
	}

    //tooltip display
	$('.perfmatters-tooltip').on('mouseenter', function() {
    	$(this).closest('tr, .pmcs-title').find('.perfmatters-tooltip-text').fadeIn(100);
	})
	.on('mouseleave', function() {
    	$(this).closest('tr, .pmcs-title').find('.perfmatters-tooltip-text').fadeOut(100);
	});
	
	//add input row
	$('.perfmatters-add-input-row').on('click', function(ev) {
		ev.preventDefault();

		var rowCount = $(this).prop('rel');

		if(rowCount < 1) {
			$onlyRow = $(this).closest('.perfmatters-input-row-wrapper').find('.perfmatters-input-row');
			if($onlyRow.find('.perfmatters-input-row-extra').length > 0) {
				$onlyRow.addClass('perfmatters-opened');
			}
			$onlyRow.show();
		}
		else {
			var $container = $(this).closest('.perfmatters-input-row-wrapper').find('.perfmatters-input-row-container');
			var $clonedRow = $container.find('.perfmatters-input-row').last().clone();

			if($clonedRow.find('.perfmatters-input-row-extra').length > 0) {
				$clonedRow.addClass('perfmatters-opened');
			}

			/* snippet conditions */
			if($clonedRow.hasClass('condition')) {
				$clonedRow.removeClass('pmcs-condition-load-objects pmcs-condition-objects-loaded');
				$clonedRow.attr('data-object-type', '').attr('data-saved-object', '');
				$clonedRow.find('.condition-object-wrap').empty();
			}

			$clonedRow.find(':text, select').val('');
			$clonedRow.find(':checkbox').prop('checked', false);

			perfmattersUpdateRowCount($clonedRow, rowCount);

			$container.append($clonedRow);
		}
		rowCount++;

		$(this).prop('rel', rowCount);
	});

	//delete input row
	$('.perfmatters-input-row-wrapper').on('click', '.perfmatters-delete-input-row', function(ev) {
		ev.preventDefault();

		var siblings = $(this).closest('.perfmatters-input-row').siblings();
		var $addButton = $(this).closest('.perfmatters-input-row-wrapper').find('.perfmatters-add-input-row');

		if($addButton.prop('rel') == 1) {
			$row = $(this).closest('.perfmatters-input-row');
			$row.find(':text, select').val('');
			$row.find(':checkbox').prop("checked", false);
			$row.hide();

			/* snippet conditions */
			if($row.hasClass('condition')) {
				$row.removeClass('pmcs-condition-load-objects pmcs-condition-objects-loaded');
				$row.attr('data-object-type', '').attr('data-saved-object', '');
				$row.find('.condition-object-wrap').empty();
			}
		}
		else {
			$(this).closest('.perfmatters-input-row').remove();
		}

		$addButton.prop('rel', $addButton.prop('rel') - 1);
		
		siblings.each(function(i) {
			perfmattersUpdateRowCount(this, i);
		});
	});

	//expand input row
	$('.perfmatters-input-row-wrapper').on('click', '.perfmatters-expand-input-row', function(ev) {
		ev.preventDefault();

		$row = $(this).closest('.perfmatters-input-row');

		if($row.hasClass('perfmatters-opened')) {
			$row.removeClass('perfmatters-opened');
		}
		else {
			$row.addClass('perfmatters-opened');
		}
	});

	//quick exclusions
	$(".perfmatters-quick-exclusion-title-bar").on('click', function(e) {
        var clicked = $(this).closest(".perfmatters-quick-exclusion");
        if(clicked.hasClass("perfmatters-opened")) {
            clicked.removeClass("perfmatters-opened");
        }
        else {
        	clicked.addClass("perfmatters-opened");
        }
    });

	//input display control
	$('.perfmatters-input-controller input, .perfmatters-input-controller select').on('change', function() {

		var controller = $(this);

		var inputID = $(this).attr('id');

		var nestedControllers = [];

		$('.' + inputID).each(function() {

			var skipFlag = true;
			var forceHide = false;
			var forceShow = false;
			var optionSelected = false;

			if($(this).hasClass('perfmatters-input-controller')) {
				nestedControllers.push($(this).find('input, select').attr('id'));
			}

			var currentInputContainer = this;

			$.each(nestedControllers, function(index, value) {
				var currentController = $('#' + value);

				if(currentController.is('input')) {

					var controlChecked = $('#' + value).is(':checked');
					var controlReverse = $('#' + value).closest('.perfmatters-input-controller').hasClass('perfmatters-input-controller-reverse');

		  			if($(currentInputContainer).hasClass(value) && (controlChecked == controlReverse)) {
		  				skipFlag = false;
		  				return false;
		  			}
		  		}
		  		else if(currentController.is('select')) {
		  			var classNames = currentInputContainer.className.match(/perfmatters-select-control-([^\s]*)/g);

		  			if(classNames) {
						var foundClass = ($.inArray('perfmatters-select-control-' + $('#' + value).val(), classNames)) >= 0;
						if(!foundClass) {
							forceHide = true;
						}
					}
		  		}
			});

			if(controller.is('select')) {
				var classNames = this.className.match(/perfmatters-select-control-([^\s]*)/g);
				var foundClass = ($.inArray('perfmatters-select-control-' + controller.val(), classNames)) >= 0;

				if(classNames && (foundClass != $(this).hasClass('perfmatters-control-reverse'))) {
					forceShow = true;
				}
				else {
					forceHide = true;
				}
			}

			if(skipFlag) {
				if(($(this).hasClass('hidden') || forceShow) && !forceHide) {
					$(this).removeClass('hidden');
				}
				else {
					$(this).addClass('hidden');
				}
			}

		});
	});

	//validate input
	$("#perfmatters-admin [perfmatters_validate]").on('keypress', function(e) {

		//grab input and pattern
		var code = e.which;
		var character = String.fromCharCode(code);
		var pattern = $(this).attr('perfmatters_validate');

		//prevent input if character is invalid
		if(!character.match(pattern)) {
			e.preventDefault();
		}
	});

	//show advanced toggle
	$('#perfmatters-options-form #show_advanced').on('click', function(e) {
		var container = $('#perfmatters-options');
		var checked = $(this).is(':checked');
		if(checked) {
			container.removeClass('pm-hide-advanced');
		}
		else {
			container.addClass('pm-hide-advanced');
		}
	});

	//close cta
	$('#perfmatters-cta-close').on('click', function(e) {
		
		e.preventDefault();

		$('#perfmatters-cta').hide();

		 //ajax request
		$.ajax({
	        type: "POST",
	        url: PERFMATTERS.ajaxurl,
	        data: {
	        	action: 'perfmatters_close_cta',
	        	nonce: PERFMATTERS.nonce
	        }
	    });
	});

	//PHP-rendered reload toast: add is-visible after paint so the same CSS fade runs as AJAX toasts
	var $reloadToast = $('#perfmatters-action-toast');
	if($reloadToast.length && $.trim($reloadToast.text()) && !$reloadToast.hasClass('is-visible')) {
		requestAnimationFrame(function() {
			requestAnimationFrame(function() {
				$reloadToast.addClass('is-visible');
				clearTimeout(pmActionButtonTimeouts.reload_toast);
				pmActionButtonTimeouts.reload_toast = setTimeout(function() {
					$reloadToast.removeClass('is-visible');
				}, 10000);
			});
		});
	}

	function perfmattersFadeButtonMessage($message, action) {
		$message.fadeIn();
		clearTimeout(pmActionButtonTimeouts[action]);
		pmActionButtonTimeouts[action] = setTimeout(function() {
			$message.fadeOut();
		}, 10000);
	}

	//inline beside the button, or #perfmatters-action-toast when data-pm-message="toast"
	function perfmattersShowActionMessage(text, action, isError, messageMode, $inlineMessage) {
		if(!text) {
			return;
		}

		if(messageMode === 'toast') {
			var $toast = $('#perfmatters-action-toast');
			$toast.toggleClass('perfmatters-error', !!isError).text(text).addClass('is-visible');
			clearTimeout(pmActionButtonTimeouts[action]);
			pmActionButtonTimeouts[action] = setTimeout(function() {
				$toast.removeClass('is-visible');
			}, 10000);
			return;
		}

		$inlineMessage.toggleClass('perfmatters-error', !!isError).html(text);
		perfmattersFadeButtonMessage($inlineMessage, action);
	}

	//write scan badges one at a time; pause between rows, not after the last
	function perfmattersPaintScanRows(keys, writeRow) {
		var timer = function(ms) {
			return new Promise(function(resolve) {
				setTimeout(resolve, ms);
			});
		};

		return (async function() {
			for(var i = 0; i < keys.length; i++) {
				writeRow(keys[i]);

				if(i < keys.length - 1) {
					await timer(250);
				}
			}
		})();
	}

	function perfmattersReloadWithNotice(data) {
		if(!data.message_key) {
			window.location.reload();
			return;
		}

		var url = new URL(window.location.href);

		url.search = '';
		url.searchParams.set('page', 'perfmatters');
		url.searchParams.set('message', data.message_key);

		var messageKeyHashes = {
			snippets_imported: '#code/settings',
			editor_theme_updated: '#code/settings',
			settings_imported: '#tools',
			settings_restored: '#tools'
		};
		if(messageKeyHashes[data.message_key]) {
			url.hash = messageKeyHashes[data.message_key];
		}

		window.location.assign(url.toString());
	}

	//action button press
	$('button[data-pm-action]').on('click', function(e) {

		e.preventDefault();

		//confirmation dialog
		var confirmation = $(this).attr('data-pm-confirmation');
		if(confirmation && !confirm(confirmation)) {
			return;
		}

		//assign variables
		var action = $(this).attr('data-pm-action');
		var button = $(this);
		var container = $(this).closest('.perfmatters-button-container');
		var text = container.find('.perfmatters-button-text');
		var spinner = container.find('.perfmatters-button-spinner');
		var message = container.find('.perfmatters-button-message');
		var messageMode = button.attr('data-pm-message') || 'inline';

		message.html('').removeClass('perfmatters-error');
	 	clearTimeout(pmActionButtonTimeouts[action]);

	 	//switch to spinner
	    $(this).attr('disabled', true);
	    text.hide();
	    spinner.css('display', 'block');

	    //setup form data
	    var formData = new FormData();
	    formData.append('action', 'perfmatters_' + action);
	    formData.append('nonce', PERFMATTERS.nonce);

	    //additional setup
	    if(action == 'import_settings') {
    		formData.append('perfmatters_import_settings_file', document.getElementById('perfmatters-import-settings-file').files[0]);
	    }
	    else if(action == 'import_snippets') {
    		formData.append('pmcs_import_file', document.getElementById('pmcs-import-file').files[0]);
	    }
	    else if(action == 'scan_database') {
	    	$('#tools-database .perfmatters-option-data').html('');
	    }
	    else if(action == 'scan_warmer_sources') {
	    	$('#perfmatters-cache-warmer-sources .perfmatters-option-data').html('');
	    }
	    else if(action == 'sync_cloudflare_rules' || action == 'remove_cloudflare_token' || action == 'sync_cache_files' || action == 'cache_clear' || action == 'cache_warmer_start' || action == 'cache_warmer_stop') {
	    	//token + nonce only; do not serialize the settings form
	    }
	    else {
	    	var form = $(this).closest('form');
	    	form.find('.CodeMirror').each(function() {
			    this.CodeMirror.save();
			});
	    	formData.append('form', form.serialize());

	    	//include custom CodeMirror theme file upload when saving settings.
	    	if(action == 'save_settings') {
	    		var customThemeInput = document.getElementById('code-custom-theme-file');
	    		if(customThemeInput && customThemeInput.files && customThemeInput.files[0]) {
	    			formData.append('code_custom_theme_file', customThemeInput.files[0]);
	    		}
	    	}
	    }

	    //ajax request
		$.ajax({
	        type: "POST",
	        url: PERFMATTERS.ajaxurl,
	        data: formData,
	        processData: false,
       		contentType: false
	    })
	    .then(function(r) {

	    	//export settings
	    	const exportActions = ['export_settings', 'export_snippets'];
	    	if(exportActions.includes(action) && r.data && r.data.export) {
	    		var blob = new Blob([r.data.export], {
			        type: 'application/json'
		      	});
			    var link = document.createElement('a');
			    link.href = window.URL.createObjectURL(blob);

			    var d = new Date();
				var month = d.getMonth()+1;
				var day = d.getDate();
				var dateString = d.getFullYear() + '-' + (month<10 ? '0' : '') + month + '-' + (day<10 ? '0' : '') + day;

			    link.download = 'perfmatters-' + action.split('_').reverse().join('-') + '-' + location.hostname + '-' + dateString + '.json';
			    link.click();
	    	}

	    	//other actions resolve immediately; scans resolve after the last row is written
	    	var painted = Promise.resolve();

	    	//scan database
	    	if(action =='scan_database' && r.data && r.data.data) {
				painted = perfmattersPaintScanRows(Object.keys(r.data.data), function(key) {
			    	$('#database-' + key).closest('td').find('.perfmatters-option-data').html(r.data.data[key]);
				});
	    	}

	    	//scan warmer sources (Perfmatters Cache)
	    	else if(action == 'scan_warmer_sources' && r.data && r.data.data) {
				painted = perfmattersPaintScanRows(Object.keys(r.data.data), function(key) {
					//label is the per-source row (all sources share one settings <td>)
					$('#warmer-source-' + key).closest('label').find('.perfmatters-option-data').html(r.data.data[key]);
				});
	    	}

	    	//cache toolbar / Sync Rules / soft cache saves: refresh status cards without a full reload
	    	if((action == 'sync_cloudflare_rules' || action == 'cache_clear' || action == 'cache_warmer_start' || action == 'cache_warmer_stop' || action == 'save_settings') && r.data && r.data.progress && typeof window.perfmattersCacheApplyProgress === 'function') {
	    		window.perfmattersCacheApplyProgress(r.data.progress);
	    		if(r.data.progress.running && typeof window.perfmattersCacheWarmerPoll === 'function') {
	    			window.perfmattersCacheWarmerPoll();
	    		}
	    	}

	    	//returning painted holds the button reset until scan rows finish
	    	//wp_send_json_error() is HTTP 200, so those messages are shown here too
	    	return painted.then(function() {

	    		//reload responses show the notice on the next page only (avoid toast → navigate → toast again)
	    		if(r.data && r.data.message && !r.data.reload) {
	    			perfmattersShowActionMessage(r.data.message, action, !r.success, messageMode, message);
	    		}

	    		return r;
	    	});
		}, function() {

			//the request itself failed (500, timeout, invalid JSON)
			perfmattersShowActionMessage(PERFMATTERS.strings.failed, action, true, messageMode, message);
		})
		.always(function(r) {

			//a rejected request resolves this chain with no payload
			if(r && r.data && r.data.reload) {
				perfmattersReloadWithNotice(r.data);
				return;
			}

			//re-enable button
			button.attr('disabled', false);
			text.show();
	       	spinner.css('display', 'none');

	       	//clear checkboxes
	       	if(action == 'purge_meta') {
	       		$('#perfmatters-purge-meta input:checkbox').removeAttr('checked');
	       	}
		})
	});

	//update row count for given input row attributes
	function perfmattersUpdateRowCount(row, rowCount) {
		$(row).find('input, select, label').each(function() {
			if($(this).attr('id')) {
				$(this).attr('id', $(this).attr('id').replace(/[0-9]+/g, rowCount));
			}
			if($(this).attr('name')) {
				$(this).attr('name', $(this).attr('name').replace(/[0-9]+/g, rowCount));
			}
			if($(this).attr('for')) {
				$(this).attr('for', $(this).attr('for').replace(/[0-9]+/g, rowCount));
			}
		});
	}
});