<?php
/**
 * Services main template
 */
$classes_list[] = 'jet-services';

$show_on_hover = $this->get_settings_for_display( 'show_on_hover' );
$header_position = $this->get_settings_for_display( 'header_position' );

$classes_list[] = 'jet-services--header-position-' . $header_position;

if ( filter_var( $show_on_hover, FILTER_VALIDATE_BOOLEAN ) ) {
	$classes_list[] = 'jet-services--cover-hover';
}

$classes = implode( ' ', $classes_list );

?>
<div class="<?php echo esc_attr( $classes ); ?>">
	<div class="jet-services__inner">
		<?php // phpcs:disable ?>
		<div class="jet-services__header">
			<div class="jet-services__cover"><?php
			echo $this->_generate_icon( true );
			echo $this->_generate_title( true );
			echo $this->_generate_description( true );
			echo $this->_generate_action_button( true ); ?></div>
		</div>
		<div class="jet-services__content"><?php
			echo $this->_generate_icon();
			echo $this->_generate_title();
			echo $this->_generate_description();
			echo $this->_generate_action_button(); ?></div>
		<?php // phpcs:enable ?>
	</div>
</div>
