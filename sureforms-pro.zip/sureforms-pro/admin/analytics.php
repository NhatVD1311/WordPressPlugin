<?php
/**
 * Analytics class helps to connect BSF Analytics.
 *
 * @package sureforms.
 */

namespace SRFM_Pro\Admin;

use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Registry;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Analytics class.
 *
 * @since 1.4.0
 */
class Analytics {
	use Get_Instance;

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 1.4.0
	 */
	public function __construct() {
		add_filter( 'bsf_core_stats', [ $this, 'add_srfm_pro_analytics_data' ], 11 );
		add_filter( 'srfm_deactivation_survey_data', [ $this, 'add_pro_deactivation_data' ] );
		if ( defined( 'SRFM_FORMS_POST_TYPE' ) ) {
			add_action( 'save_post_' . SRFM_FORMS_POST_TYPE, [ $this, 'track_dynamic_options_configured' ], 10, 2 );
		}

		// Detect pro license activation state (dedup prevents repeat tracking).
		if ( 'licensed' === get_option( 'srfm_pro_license_status' )
			&& method_exists( '\SRFM\Admin\Analytics', 'events' )
			) {
			\SRFM\Admin\Analytics::events()->track( 'pro_license_activated', SRFM_PRO_VER );
		}

		// Detect state-based pro events (dedup prevents repeat tracking).
		$this->detect_pro_state_events();

		// Event tracking hooks.
		add_action( 'added_post_meta', [ $this, 'track_quiz_created' ], 10, 4 );
		add_action( 'updated_post_meta', [ $this, 'track_quiz_created' ], 10, 4 );
		add_action( 'added_post_meta', [ $this, 'track_survey_enabled' ], 10, 4 );
		add_action( 'updated_post_meta', [ $this, 'track_survey_enabled' ], 10, 4 );
	}

	/**
	 * Track first time a quiz is created/enabled on a form.
	 *
	 * Fires when _srfm_quiz_meta is saved with status true.
	 * Dedup in BSF_Analytics_Events::track() ensures this fires only once.
	 *
	 * @param int    $_meta_id   Meta ID (unused).
	 * @param int    $post_id    Post ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @since 2.6.0
	 * @return void
	 */
	public function track_quiz_created( $_meta_id, $post_id, $meta_key, $meta_value ) {

		unset( $_meta_id ); // Unused parameter.

		if ( '_srfm_quiz_meta' !== $meta_key
			|| ! method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			return;
		}

		$quiz_meta = is_string( $meta_value ) ? json_decode( $meta_value, true ) : null;
		if ( empty( $quiz_meta ) || ! is_array( $quiz_meta ) || empty( $quiz_meta['status'] ) ) {
			return;
		}

		$question_count = ! empty( $quiz_meta['questions'] ) && is_array( $quiz_meta['questions'] )
			? count( $quiz_meta['questions'] )
			: 0;

		$is_ai          = ! empty( get_post_meta( $post_id, '_srfm_is_ai_generated', true ) );
		$score_type     = ! empty( $quiz_meta['scoreType'] ) ? sanitize_text_field( $quiz_meta['scoreType'] ) : 'correct_incorrect';
		$grading_system = ! empty( $quiz_meta['gradingSystem'] ) ? sanitize_text_field( $quiz_meta['gradingSystem'] ) : 'default';

		$events = \SRFM\Admin\Analytics::events();

		// Flush old dedup so updated quiz config is always re-tracked.
		$events->flush_pushed( [ 'quiz_created' ] );

		$events->track(
			'quiz_created',
			(string) $post_id,
			[
				'is_ai_generated' => $is_ai,
				'score_type'      => $score_type,
				'grading_system'  => $grading_system,
				'question_count'  => $question_count,
			]
		);
	}

	/**
	 * Track when survey/poll mode is first enabled on a form.
	 *
	 * Fires when _srfm_survey_meta is saved with status true.
	 * Dedup in BSF_Analytics_Events::track() ensures this fires only once.
	 *
	 * @param int    $_meta_id   Meta ID (unused).
	 * @param int    $post_id    Post ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @since 2.8.0
	 * @return void
	 */
	public function track_survey_enabled( $_meta_id, $post_id, $meta_key, $meta_value ) {

		unset( $_meta_id ); // Unused parameter.

		if ( '_srfm_survey_meta' !== $meta_key
			|| ! method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			return;
		}

		$survey_meta = is_string( $meta_value ) ? json_decode( $meta_value, true ) : null;
		if ( empty( $survey_meta ) || ! is_array( $survey_meta ) || empty( $survey_meta['status'] ) ) {
			return;
		}

		$is_ai        = ! empty( get_post_meta( $post_id, '_srfm_is_ai_generated', true ) );
		$live_results = ! empty( $survey_meta['show_live_results'] );

		$events = \SRFM\Admin\Analytics::events();

		// Flush old dedup so updated survey config is always re-tracked.
		$events->flush_pushed( [ 'survey_enabled' ] );

		$events->track(
			'survey_enabled',
			(string) $post_id,
			[
				'is_ai_generated'   => $is_ai,
				'show_live_results' => $live_results,
			]
		);
	}

	/**
	 * Adds pro analytics data to existing stats data
	 *
	 * @param array $stats_data existing stats data.
	 * @since 1.4.0
	 * @return array
	 */
	public function add_srfm_pro_analytics_data( $stats_data ) {
		$pro_data = $this->pro_analytics_data();

		if ( ! empty( $stats_data['plugin_data']['sureforms'] ) && is_array( $stats_data['plugin_data']['sureforms'] ) ) {
			$stats_data['plugin_data']['sureforms'] = array_merge_recursive( $stats_data['plugin_data']['sureforms'], $pro_data );
		}

		// Build survey/poll usage snapshot (queues event if data changed).
		$this->get_survey_tracking_data();

		// Emit the whole pro_features block as a `pro_features` event so it
		// reaches the events table — the pro_features block in the stats payload
		// itself is NOT ingested into ClickHouse. Each sub-feature (survey,
		// partial_entries, form_styling_themes, …) becomes a queryable property,
		// re-sent with the latest snapshot every cycle.
		$this->track_pro_features_event( $pro_data );

		// Flush any events queued by pro (after core's flush at priority 10).
		if ( method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			$pending_events = \SRFM\Admin\Analytics::events()->flush_pending();
			if ( ! empty( $pending_events ) && is_array( $pending_events ) ) {
				if ( ! isset( $stats_data['plugin_data']['sureforms']['events_record'] ) || ! is_array( $stats_data['plugin_data']['sureforms']['events_record'] ) ) {
					$stats_data['plugin_data']['sureforms']['events_record'] = [];
				}
				$stats_data['plugin_data']['sureforms']['events_record'] = array_merge(
					$stats_data['plugin_data']['sureforms']['events_record'],
					$pending_events
				);
			}
		}

		return $stats_data;
	}

	/**
	 * Emit the pro_features block as a single `pro_features` event.
	 *
	 * The pro_features section of the bsf_core_stats payload is NOT ingested
	 * into the analytics store, so each pro feature's usage is sent as a
	 * property of one `pro_features` event (nested values JSON-encoded) to land
	 * in the events table and become queryable. The pushed dedup is flushed
	 * first so the latest snapshot is re-sent on every analytics cycle (same
	 * pattern as the `survey` event).
	 *
	 * @param array $pro_data Data returned by pro_analytics_data().
	 * @since 2.10.0
	 * @return void
	 */
	public function track_pro_features_event( $pro_data ) {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			return;
		}

		$pro_features = is_array( $pro_data ) && isset( $pro_data['pro_features'] ) && is_array( $pro_data['pro_features'] )
			? $pro_data['pro_features']
			: [];

		if ( empty( $pro_features ) ) {
			return;
		}

		$properties = [];
		foreach ( $pro_features as $feature => $value ) {
			$properties[ (string) $feature ] = is_scalar( $value )
				? (string) $value
				: (string) wp_json_encode( $value );
		}

		$events = \SRFM\Admin\Analytics::events();

		// Flush old dedup so the latest snapshot is always re-tracked.
		$events->flush_pushed( [ 'pro_features' ] );
		$events->track( 'pro_features', '', $properties );
	}

	/**
	 * Returns pro analytics data
	 *
	 * @since 1.4.0
	 * @return array
	 */
	public function pro_analytics_data() {
		$pro_data                = [];
		$pro_data['pro_version'] = SRFM_PRO_VER;
		$pro_data['numeric_values']['conditional_logic_forms']     = $this->conditional_logic_forms();
		$pro_data['numeric_values']['multi_step_forms']            = $this->multi_step_forms();
		$pro_data['numeric_values']['custom_apps_enabled']         = $this->custom_apps_enabled();
		$pro_data['numeric_values']['conversational_forms']        = $this->conversational_forms();
		$pro_data['numeric_values']['calculator_forms']            = $this->get_calculator_forms();
		$pro_data['numeric_values']['signature_block']             = $this->get_forms_count_with_signature_block();
		$pro_data['numeric_values']['ai_generated_calculator']     = $this->ai_generated_forms_by_type( 'calculator' );
		$pro_data['numeric_values']['ai_generated_conversational'] = $this->ai_generated_forms_by_type( 'conversational' );
		$pro_data['numeric_values']['custom_styled_forms']         = $this->get_custom_styled_forms();
		$pro_data['numeric_values']['post_feeds']                  = $this->get_forms_count_with_post_feeds();
		$pro_data['numeric_values']['user_registration_forms']     = $this->get_user_registration_forms();
		$pro_data['numeric_values']['login_forms']                 = $this->get_login_forms();
		$pro_data['numeric_values']['pdf_generation_forms']        = $this->get_pdf_generation_forms();
		$pro_data['numeric_values']['conditional_emails']          = $this->get_conditional_emails();
		$pro_data['numeric_values']['save_resume_forms']           = $this->get_save_resume_forms();
		$pro_data['numeric_values']['keyword_restricted_forms']    = $this->get_keyword_restricted_forms();
		$pro_data['numeric_values']['ip_restricted_forms']         = $this->get_ip_restricted_forms();
		$pro_data['numeric_values']['country_restricted_forms']    = $this->get_country_restricted_forms();
		$pro_data['numeric_values']['login_restricted_forms']      = $this->get_login_restricted_forms();
		$pro_data['numeric_values']['password_restricted_forms']   = $this->get_password_restricted_forms();
		$pro_data['numeric_values']['embed_styling_gb_custom']     = $this->embed_styling_gutenberg_custom_count();
		$pro_data['numeric_values']['embed_styling_el_custom']     = $this->embed_styling_elementor_custom_count();
		$pro_data['numeric_values']['embed_styling_br_custom']     = $this->embed_styling_bricks_custom_count();

		$pro_data['numeric_values']['dynamic_options_forms']              = $this->get_dynamic_options_forms();
		$pro_data['numeric_values']['dynamic_options_post_type_forms']    = $this->get_dynamic_options_source_type_forms( 'post_type' );
		$pro_data['numeric_values']['dynamic_options_taxonomy_forms']     = $this->get_dynamic_options_source_type_forms( 'taxonomy' );
		$pro_data['numeric_values']['dynamic_options_user_role_forms']    = $this->get_dynamic_options_source_type_forms( 'user_role' );
		$pro_data['numeric_values']['dynamic_options_dropdown_forms']     = $this->get_dynamic_options_field_type_forms( 'dropdown' );
		$pro_data['numeric_values']['dynamic_options_multi_choice_forms'] = $this->get_dynamic_options_field_type_forms( 'multi-choice' );

		$integration_settings                          = get_option( 'srfm_pro_integration_settings', [] );
		$pro_data['boolean_values']['webhook_enabled'] = is_array( $integration_settings ) && ! empty( $integration_settings['webhooks_enabled'] );

		$zapier_data                                  = get_option( 'srfm_zap_auth_data', [] );
		$pro_data['boolean_values']['zapier_enabled'] = ! empty( $zapier_data ) && is_array( $zapier_data );

		if ( class_exists( 'SRFM_PRO\Admin\Licensing' ) && function_exists( 'add_settings_error' ) ) {
			$pro_data['boolean_values']['license_active'] = Licensing::is_license_active();
		} else {
			$pro_data['boolean_values']['license_active'] = false;
		}

		// Add configured integrations data.
		$pro_data['integrations'] = $this->get_configured_integrations();

		// Pro feature-level analytics.
		$pro_data['pro_features']['survey'] = [
			'total_forms'          => $this->get_survey_forms(),
			'live_results_enabled' => $this->get_survey_live_results_forms(),
			'ai_generated'         => $this->ai_generated_forms_by_type( 'survey' ),
		];

		$pro_data['pro_features']['partial_entries'] = [
			'total_forms'    => $this->get_partial_entries_forms(),
			'resume_enabled' => $this->get_partial_entries_resume_forms(),
		];

		$pro_data['pro_features']['color_picker'] = [
			'total_forms' => $this->get_color_picker_forms(),
		];

		// Form-styling theme adoption — a { theme => form_count } map. Sent with
		// the rest of pro_features via the `pro_features` event (the stats-payload
		// pro_features block is not ingested into ClickHouse).
		$pro_data['pro_features']['form_styling_themes'] = $this->get_form_styling_theme_counts();

		// Cloud File Storage adoption — forms using the unified workflow plus
		// per-provider connection state, sourced dynamically from the registry
		// so newly registered providers are reported automatically.
		$cloud_file_storage = [ 'total_forms' => $this->get_cloud_file_storage_forms() ];
		foreach ( File_Storage_Registry::get_instance()->get_connection_states() as $provider_key => $connected ) {
			$cloud_file_storage[ $provider_key . '_connected' ] = (bool) $connected;
		}
		$pro_data['pro_features']['cloud_file_storage'] = $cloud_file_storage;

		return $pro_data;
	}

	/**
	 * Count forms that use the unified Cloud File Storage workflow.
	 *
	 * Matches the `thirdpartyfileupload` integration id stored in the
	 * `_srfm_native_integrations` post meta. The value is anchored to the
	 * `"integration":"…"` key so the substring can't false-positive against
	 * another field (e.g. a workflow name) that happens to contain it.
	 *
	 * @since 2.10.0
	 * @return int
	 */
	public function get_cloud_file_storage_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_native_integrations',
				'value'   => '"integration":"thirdpartyfileupload"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Return total number of ai generated forms by form type.
	 *
	 * @param string $form_type Form type to check.
	 *
	 * @since 1.6.1
	 * @return int
	 */
	public function ai_generated_forms_by_type( $form_type = '' ) {

		// Check if form type is valid.
		if ( empty( $form_type ) || ! is_string( $form_type ) ) {
			return 0;
		}

		$valid_types = [ 'conversational', 'calculator', 'survey' ];
		if ( ! in_array( $form_type, $valid_types, true ) ) {
			return 0;
		}

		// Meta query to get all AI generated forms.
		$meta_query = [
			[
				'key'     => '_srfm_is_ai_generated',
				'value'   => '',
				'compare' => '!=', // Checks if the value is NOT empty.
			],
		];

		$search = '';

		// Generate meta query or search string based on form type.
		switch ( $form_type ) {
			case 'conversational':
				$meta_query[] = [
					'key'     => '_srfm_conversational_form',
					'value'   => '"is_cf_enabled";b:1;',
					'compare' => 'LIKE',
				];
				break;
			case 'calculator':
				$search = '"enableCalculation":true';
				break;
			case 'survey':
				$meta_query[] = [
					'key'     => '_srfm_survey_meta',
					'value'   => '"status":true',
					'compare' => 'LIKE',
				];
				break;
			default:
				return 0;
		}

		return $this->custom_wp_query_total_posts( $meta_query, $search );
	}

	/**
	 * Return forms using custom apps
	 *
	 * @since 1.4.0
	 * @return int
	 */
	public function custom_apps_enabled() {
		$meta_query = [
			'relation' => 'OR',
			[
				'key'     => '_srfm_form_confirmation',
				'value'   => '"confirmation_type";s:23:"suretriggers_below_form"',
				'compare' => 'LIKE',
			],
			[
				'key'     => '_srfm_form_confirmation',
				'value'   => '"confirmation_type";s:30:"suretriggers_confirmation_page"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Return the number of forms using conditional logic
	 *
	 * @since 1.4.0
	 * @return int
	 */
	public function conditional_logic_forms() {
		$meta_query = [
			'relation' => 'AND',
			[
				'key'     => '_srfm_conditional_logic',
				'value'   => '',
				'compare' => '!=', // Exclude empty string.
			],
			[
				'key'     => '_srfm_conditional_logic',
				'value'   => 'a:0:{}',
				'compare' => '!=', // Exclude empty serialized array.
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of multi steps forms
	 *
	 * @since 1.4.0
	 * @return int
	 */
	public function multi_step_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_page_break_settings',
				'value'   => '',
				'compare' => '!=', // Checks if the value is NOT empty.
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Add pro data required for plugin deactivation survey.
	 *
	 * @param array $deactivation_data array of free deactivation data.
	 * @since 1.4.0
	 * @return array
	 */
	public function add_pro_deactivation_data( $deactivation_data ) {
		$deactivation_data[] = [
			'id'                => 'deactivation-survey-sureforms-business',
			'popup_logo'        => SRFM_URL . 'admin/assets/sureforms-logo.png',
			'plugin_slug'       => 'sureforms-business',
			'popup_title'       => 'Quick Feedback',
			'support_url'       => 'https://sureforms.com/contact/',
			// Translators: Message asking users for deactivation feedback. %1s is the product name.
			'popup_description' => sprintf( 'If you have a moment, please share why you are deactivating %1s:', SRFM_PRO_PRODUCT ),
			'show_on_screens'   => [ 'plugins' ],
			'plugin_version'    => SRFM_PRO_VER,
		];

		return $deactivation_data;
	}

	/**
	 * Get count of forms where conversational forms are active.
	 *
	 * @since 1.4.2
	 * @return int
	 */
	public function conversational_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_conversational_form',
				'value'   => '"is_cf_enabled";b:1;',
				'compare' => 'LIKE', // Checks if the value is NOT empty.
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get all published SureForms forms which have signature block.
	 *
	 * @since 1.6.0
	 * @return int
	 */
	public function get_forms_count_with_signature_block() {
		return $this->custom_wp_query_total_posts( [], 'wp:srfm/signature' );
	}

	/**
	 * Get all published SureForms forms where post_content contains '"enableCalculation":true'
	 *
	 * @since 1.5.0
	 * @return int
	 */
	public function get_calculator_forms() {
		return $this->custom_wp_query_total_posts( [], '"enableCalculation":true' );
	}

	/**
	 * Get all published SureForms forms where post_content contains '"isColorPicker":true'
	 *
	 * Counts forms using the Color Picker field (the srfm/input block with the
	 * isColorPicker attribute enabled).
	 *
	 * @since 2.11.0
	 * @return int
	 */
	public function get_color_picker_forms() {
		return $this->custom_wp_query_total_posts( [], '"isColorPicker":true' );
	}

	/**
	 * Get the count of forms where users are using custom styling options.
	 * All the published forms where the '_srfm_forms_styling_starter' meta contains '"form_theme";s:6:"custom"',
	 * are counted as forms using custom styling options.
	 *
	 * @since 1.6.3
	 * @return int
	 */
	public function get_custom_styled_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_forms_styling_starter',
				'value'   => '"form_theme";s:6:"custom"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Build a { theme => form_count } map of form-styling preset adoption.
	 *
	 * Reads the `_srfm_forms_styling_starter` meta of every published form and
	 * buckets it by its `form_theme` value into a fixed, privacy-safe set of
	 * keys only:
	 *  - the plugin-shipped presets `default`, `custom`, `baseline`,
	 *    `minimal`, `dark` (reported verbatim — these are not user data);
	 *  - `user_preset` — every user-created preset (`user-{slug}`) collapsed
	 *    into one bucket, since those slugs derive from user-supplied names;
	 *  - `other` — any value that is neither shipped nor a user preset (e.g.
	 *    a custom string written directly to the meta).
	 *
	 * The raw `form_theme` string is NEVER emitted as a key, so no
	 * user-authored/identifying value can leave the site. Counts (not names)
	 * are all this needs to gauge adoption. Forms with no styling-starter meta
	 * are untouched defaults and are not counted here.
	 *
	 * @since 2.10.0
	 * @return array<string,int> Map of theme bucket to number of forms using it.
	 */
	public function get_form_styling_theme_counts() {
		if ( ! defined( 'SRFM_FORMS_POST_TYPE' ) ) {
			return [];
		}

		global $wpdb;

		$meta_values = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Analytics aggregation, runs infrequently during stats collection.
			$wpdb->prepare(
				"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s AND p.post_type = %s AND p.post_status = 'publish'",
				'_srfm_forms_styling_starter',
				SRFM_FORMS_POST_TYPE
			)
		);

		// Plugin-shipped slugs that are safe to report verbatim. Anything that
		// is neither one of these nor a user preset is bucketed as `other`, so
		// a user-authored `form_theme` string is never transmitted as a key.
		$shipped_themes = [ 'default', 'custom', 'baseline', 'minimal', 'dark' ];

		$counts = [];

		foreach ( $meta_values as $raw ) {
			$data  = maybe_unserialize( $raw );
			$theme = is_array( $data ) && ! empty( $data['form_theme'] ) && is_string( $data['form_theme'] )
				? $data['form_theme']
				: 'default';

			if ( Pro_Helper::is_user_preset_slug( $theme ) ) {
				// Collapse every user-created preset into one bucket. Uses the
				// canonical helper (enforces the `user-` prefix + length guard)
				// so bucketing matches how presets are interpreted everywhere else.
				$theme = 'user_preset';
			} elseif ( ! in_array( $theme, $shipped_themes, true ) ) {
				// Bucket any unrecognised value generically — never emit it raw.
				$theme = 'other';
			}

			$counts[ $theme ] = ( $counts[ $theme ] ?? 0 ) + 1;
		}

		return $counts;
	}

	/**
	 * Get all published SureForms forms which have post-feeds.
	 *
	 * @since 1.10.0
	 * @return int
	 */
	public function get_forms_count_with_post_feeds() {
		return $this->custom_wp_query_total_posts(
			[
				'key'     => '_srfm_raw_cpt_meta',
				'compare' => 'EXISTS', // Ensure the meta key exists.
			]
		);
	}

	/**
	 * Get count of forms with conditional email notifications enabled.
	 *
	 * @since 1.10.1
	 * @return int
	 */
	public function get_conditional_emails() {
		$meta_query = [
			[
				'key'     => '_srfm_email_conditional_meta',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with user registration configuration enabled
	 *
	 * Checks for forms where the _srfm_user_registration_settings meta contains
	 * at least one configuration with "status":true
	 *
	 * @since 1.8.0
	 * @return int
	 */
	public function get_user_registration_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_user_registration_settings',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms containing login blocks
	 *
	 * @since 1.8.0
	 * @return int
	 */
	public function get_login_forms() {
		return $this->custom_wp_query_total_posts( [], 'wp:srfm/login' );
	}

	/**
	 * Get count of forms with PDF generation functionality enabled
	 *
	 * Checks for forms where the _srfm_pdf_meta contains PDF configuration settings.
	 * This indicates that PDF generation has been set up for the form.
	 *
	 * @since 1.9.0
	 * @return int
	 */
	public function get_pdf_generation_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_pdf_meta',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with IP restriction enabled
	 *
	 * @since 2.2.0
	 * @return int
	 */
	public function get_ip_restricted_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_additional_form_restriction',
				'value'   => '"ip":{"status":true,"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with country restriction enabled
	 *
	 * @since 2.2.0
	 * @return int
	 */
	public function get_country_restricted_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_additional_form_restriction',
				'value'   => '"country":{"status":true,"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with keyword restriction enabled
	 *
	 * @since 2.2.0
	 * @return int
	 */
	public function get_keyword_restricted_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_additional_form_restriction',
				'value'   => '"keyword":{"status":true,"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with login restriction enabled
	 *
	 * @since 2.2.0
	 * @return int
	 */
	public function get_login_restricted_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_additional_form_restriction',
				'value'   => '"login":{"status":true,"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with password restriction enabled
	 *
	 * @since 2.3.0
	 * @return int
	 */
	public function get_password_restricted_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_additional_form_restriction',
				'value'   => '"password":{"status":true,"',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get list of configured integrations
	 *
	 * Returns an array of integration names that are configured (enabled or disabled).
	 * Only sends the integration slug/type for privacy, not any configuration data.
	 *
	 * @since 1.13.0
	 * @return array Array of integration names (strings).
	 */
	public function get_configured_integrations() {
		$configured_integrations = [];

		// Check if the method exists before calling it.
		if ( ! method_exists( 'SRFM_Pro\Inc\Pro\Database\Tables\Integrations', 'get_enabled' ) ) {
			return $configured_integrations;
		}

		try {
			// Get all enabled integrations from database.
			$integrations = Integrations::get_enabled( false );

			// Extract only the integration name.
			foreach ( $integrations as $integration ) {
				if ( is_array( $integration ) && ! empty( $integration['name'] ) ) {
					$configured_integrations[] = $integration['name'];
				}
			}
		} catch ( \Exception $e ) {
			// Return empty array if there's any error accessing the database.
			$configured_integrations = [];
		}

		return $configured_integrations;
	}

	/**
	 * Get count of forms with Save & Resume functionality enabled
	 *
	 * Checks for forms where the _srfm_save_resume meta contains
	 * configuration with status set to true.
	 *
	 * @since 2.2.0
	 * @return int
	 */
	public function get_save_resume_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_save_resume',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}
	/**
	 * Get count of forms with Quiz functionality enabled
	 *
	 * Checks for forms where the _srfm_quiz_meta meta contains
	 * configuration with status set to true.
	 *
	 * @since 2.6.0
	 * @return int
	 */
	public function get_quiz_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_quiz_meta',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Track dynamic options configuration when a form is saved.
	 *
	 * Fires on save_post to detect forms that use dynamic options in
	 * dropdown or multi-choice blocks and tracks an analytics event.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @since 2.6.0
	 * @return void
	 */
	public function track_dynamic_options_configured( $post_id, $post ) {
		// Early returns for revisions, autosaves, and non-published posts.
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( 'publish' !== $post->post_status ) {
			return;
		}

		if ( ! method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			return;
		}

		$blocks = parse_blocks( $post->post_content );

		$source_types = [];
		$field_types  = [];
		$block_count  = 0;

		$this->walk_blocks_for_dynamic_options( $blocks, $source_types, $field_types, $block_count );

		if ( 0 === $block_count ) {
			return;
		}

		$events = \SRFM\Admin\Analytics::events();

		// Flush dedup so event is re-tracked on each meaningful save.
		$events->flush_pushed( [ 'dynamic_options_configured' ] );

		$properties = [
			'source_types' => array_values( array_unique( $source_types ) ),
			'field_types'  => array_values( array_unique( $field_types ) ),
			'block_count'  => $block_count,
		];

		$events->track( 'dynamic_options_configured', (string) $post_id, $properties );
	}

	/**
	 * Get count of forms with Partial Entries enabled.
	 *
	 * Mirrors get_save_resume_forms / get_survey_forms — checks the
	 * `_srfm_partial_entries` JSON meta for "status":true.
	 *
	 * @since 2.9.0
	 * @return int
	 */
	private function get_partial_entries_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_partial_entries',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with Partial Entries resume-from-last-step enabled.
	 *
	 * Resume only takes effect when status is also true, so we require both.
	 *
	 * @since 2.9.0
	 * @return int
	 */
	private function get_partial_entries_resume_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_partial_entries',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
			[
				'key'     => '_srfm_partial_entries',
				'value'   => '"resume":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of forms with Survey/Poll mode enabled.
	 *
	 * @since 2.8.0
	 * @return int
	 */
	private function get_survey_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_survey_meta',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Get count of survey/poll forms with live results enabled.
	 *
	 * @since 2.8.0
	 * @return int
	 */
	private function get_survey_live_results_forms() {
		$meta_query = [
			[
				'key'     => '_srfm_survey_meta',
				'value'   => '"status":true',
				'compare' => 'LIKE',
			],
			[
				'key'     => '_srfm_survey_meta',
				'value'   => '"show_live_results":true',
				'compare' => 'LIKE',
			],
		];

		return $this->custom_wp_query_total_posts( $meta_query );
	}

	/**
	 * Detect state-based pro events.
	 *
	 * Uses dedup in BSF_Analytics_Events::track() — safe to call repeatedly.
	 *
	 * @since 2.7.1
	 * @return void
	 */
	private function detect_pro_state_events() {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'events' ) ) {
			return;
		}

		$events = \SRFM\Admin\Analytics::events();

		// paypal_connected: detect PayPal connection state.
		if ( class_exists( '\SRFM_Pro\Inc\Business\Payments\PayPal\Helper' )
			&& \SRFM_Pro\Inc\Business\Payments\PayPal\Helper::is_paypal_connected() ) {
			$mode = class_exists( '\SRFM\Inc\Payments\Payment_Helper' )
				? \SRFM\Inc\Payments\Payment_Helper::get_payment_mode()
				: 'live';
			$events->track( 'paypal_connected', $mode );
		}

		// first_native_integration_configured: detect if any integration exists.
		// Guard with is_tracked() to skip the DB query after the event is already tracked.
		if ( method_exists( 'SRFM_Pro\Inc\Pro\Database\Tables\Integrations', 'get_enabled' )
			&& ! $events->is_tracked( 'first_native_integration_configured' ) ) {
			try {
				$integrations = Integrations::get_enabled( false );
			} catch ( \Exception $e ) {
				$integrations = [];
			}
			if ( ! empty( $integrations ) && is_array( $integrations ) ) {
				$first = reset( $integrations );
				$type  = is_array( $first ) && ! empty( $first['name'] ) ? sanitize_text_field( $first['name'] ) : '';
				$events->track( 'first_native_integration_configured', $type );
			}
		}
	}

	/**
	 * Count Gutenberg embed blocks using the 'custom' formTheme.
	 *
	 * Delegates to the free plugin's static Analytics method which handles
	 * the cross-post-type content search.
	 *
	 * @since 2.7.0
	 * @return int
	 */
	private function embed_styling_gutenberg_custom_count() {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'embed_styling_gutenberg_count' ) ) {
			return 0;
		}

		return \SRFM\Admin\Analytics::embed_styling_gutenberg_count( 'custom' );
	}

	/**
	 * Count Elementor widgets using the 'custom' formTheme.
	 *
	 * Delegates to the free plugin's static Analytics method which handles
	 * the post meta content search.
	 *
	 * @since 2.7.0
	 * @return int
	 */
	private function embed_styling_elementor_custom_count() {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'embed_styling_elementor_count' ) ) {
			return 0;
		}

		return \SRFM\Admin\Analytics::embed_styling_elementor_count( 'custom' );
	}

	/**
	 * Count Bricks elements using the 'custom' formTheme.
	 *
	 * Delegates to the free plugin's static Analytics method which handles
	 * the post meta content search.
	 *
	 * @since 2.7.0
	 * @return int
	 */
	private function embed_styling_bricks_custom_count() {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'embed_styling_bricks_count' ) ) {
			return 0;
		}

		return \SRFM\Admin\Analytics::embed_styling_bricks_count( 'custom' );
	}

	/**
	 * Get count of published forms using dynamic options.
	 *
	 * @since 2.6.0
	 * @return int
	 */
	private function get_dynamic_options_forms() {
		return $this->custom_wp_query_total_posts( [], '"optionsSource":"dynamic"' );
	}

	/**
	 * Get count of published forms using a specific dynamic options source type.
	 *
	 * @param string $source_type The source type to check (post_type, taxonomy, user_role).
	 * @since 2.6.0
	 * @return int
	 */
	private function get_dynamic_options_source_type_forms( $source_type ) {
		return $this->custom_wp_query_total_posts( [], '"dynamicSourceType":"' . $source_type . '"' );
	}

	/**
	 * Get count of published forms using dynamic options for a specific field type.
	 *
	 * Both the block name and the dynamic options attribute must co-exist
	 * in the same post_content, so we use two LIKE conditions.
	 *
	 * @param string $block_slug The block slug to check (dropdown, multi-choice).
	 * @since 2.6.0
	 * @return int
	 */
	private function get_dynamic_options_field_type_forms( $block_slug ) {
		$allowed_slugs = [ 'dropdown', 'multi-choice' ];
		if ( ! in_array( $block_slug, $allowed_slugs, true ) ) {
			return 0;
		}

		global $wpdb;
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Analytics aggregation query, runs infrequently during stats collection.
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts}
				 WHERE post_type = %s AND post_status = 'publish'
				 AND post_content LIKE %s AND post_content LIKE %s",
				SRFM_FORMS_POST_TYPE,
				'%' . $wpdb->esc_like( 'wp:srfm/' . $block_slug ) . '%',
				'%' . $wpdb->esc_like( '"optionsSource":"dynamic"' ) . '%'
			)
		);
	}

	/**
	 * Recursively walk blocks to find dynamic option blocks.
	 *
	 * @param array $blocks       Parsed blocks array.
	 * @param array $source_types Collected source types (passed by reference).
	 * @param array $field_types  Collected field types (passed by reference).
	 * @param int   $block_count  Count of dynamic option blocks (passed by reference).
	 * @since 2.6.0
	 * @return void
	 */
	private function walk_blocks_for_dynamic_options( $blocks, &$source_types, &$field_types, &$block_count ) {
		foreach ( $blocks as $block ) {
			if ( ! empty( $block['innerBlocks'] ) ) {
				$this->walk_blocks_for_dynamic_options( $block['innerBlocks'], $source_types, $field_types, $block_count );
			}

			$block_name = $block['blockName'] ?? '';
			$attrs      = $block['attrs'] ?? [];

			// Check if this is a dropdown or multi-choice block with dynamic options.
			if ( ! in_array( $block_name, [ 'srfm/dropdown', 'srfm/multi-choice' ], true ) ) {
				continue;
			}

			if ( empty( $attrs['optionsSource'] ) || 'dynamic' !== $attrs['optionsSource'] ) {
				continue;
			}

			++$block_count;

			// Extract the field type from the block name (e.g., 'srfm/dropdown' → 'dropdown').
			$field_types[] = str_replace( 'srfm/', '', $block_name );

			if ( ! empty( $attrs['dynamicSourceType'] ) ) {
				$source_types[] = sanitize_text_field( $attrs['dynamicSourceType'] );
			}
		}
	}

	/**
	 * Runs custom WP_Query to fetch data as per requirement
	 *
	 * @param array  $meta_query meta query array for WP_Query.
	 * @param string $search search string.
	 * @since 1.4.0
	 * @return int
	 */
	private function custom_wp_query_total_posts( $meta_query = [], $search = '' ) {

		$args = [
			'post_type'      => SRFM_FORMS_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		];

		if ( ! empty( $meta_query ) && is_array( $meta_query ) ) {
			$args['meta_query'] = $meta_query; //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Meta query required as we need to fetch count of nested data.
		}

		// if search string is provided, add it to the query.
		if ( ! empty( $search ) ) {
			$args['s'] = sanitize_text_field( $search );
		}

		$query       = new \WP_Query( $args );
		$posts_count = $query->found_posts;

		wp_reset_postdata();

		return $posts_count;
	}

	/**
	 * Get survey/poll usage data aggregated across all survey forms.
	 *
	 * Queries published forms with survey mode enabled, counts entries
	 * per form, and detects field types used. Called at analytics send
	 * time (bsf_core_stats filter, priority 11).
	 *
	 * @since 2.8.0
	 * @return void
	 */
	private function get_survey_tracking_data() {
		if ( ! method_exists( '\SRFM\Admin\Analytics', 'events' ) || ! defined( 'SRFM_FORMS_POST_TYPE' ) ) {
			return;
		}

		$events = \SRFM\Admin\Analytics::events();

		// Only send when survey data changed or event has never been tracked.
		$has_changed = get_transient( 'srfm_survey_data_changed' );
		if ( ! $has_changed && $events->is_tracked( 'survey' ) ) {
			return;
		}

		// Count published forms with survey mode enabled.
		$survey_forms = new \WP_Query(
			[
				'post_type'      => SRFM_FORMS_POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs once per analytics send cycle.
					[
						'key'     => '_srfm_survey_meta',
						'value'   => '"status":true',
						'compare' => 'LIKE',
					],
				],
			]
		);

		$total_forms = $survey_forms->found_posts;
		wp_reset_postdata();

		$properties = [
			'total_survey_forms' => (string) $total_forms,
		];

		// Flush dedup so event re-tracks with latest snapshot.
		$events->flush_pushed( [ 'survey' ] );
		$events->track( 'survey', (string) $total_forms, $properties );

		// Clear the change flag after tracking.
		delete_transient( 'srfm_survey_data_changed' );
	}
}
