<?php
/**
 * File Streamer Class.
 *
 * Handles streaming of protected files with support for byte-range requests.
 *
 * @package sureforms-pro.
 * @since 2.6.0
 */

namespace SRFM_Pro\Inc;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * File_Streamer Class.
 *
 * @since 2.6.0
 */
class File_Streamer {
	/**
	 * File path.
	 *
	 * @var string
	 */
	private $path = '';

	/**
	 * File stream resource.
	 *
	 * @var resource|false
	 */
	private $stream = false;

	/**
	 * Read buffer size in bytes.
	 *
	 * @var int
	 */
	private $buffer = 0;

	/**
	 * Stream start position.
	 *
	 * @var int
	 */
	private $start = -1;

	/**
	 * Stream end position.
	 *
	 * @var int
	 */
	private $end = -1;

	/**
	 * File size in bytes.
	 *
	 * @var int
	 */
	private $size = 0;

	/**
	 * File MIME type.
	 *
	 * @var string
	 */
	private $type = '';

	/**
	 * Whether the file is role-restricted and must not be stored by shared caches.
	 *
	 * @var bool
	 */
	private $is_protected = false;

	/**
	 * Constructor.
	 *
	 * @param string $file_path    Full path to the file.
	 * @param string $file_type    MIME type of the file.
	 * @param int    $buffer       Read buffer size in bytes. Default 102400 (100KB).
	 * @param bool   $is_protected Whether the file is role-restricted. Protected files
	 *                             are sent with no-store cache directives so a shared
	 *                             cache cannot replay them to an unauthorized request.
	 */
	public function __construct( $file_path, $file_type, $buffer = 102400, $is_protected = false ) {
		$this->path         = $file_path;
		$this->type         = $file_type;
		$this->buffer       = $buffer;
		$this->is_protected = (bool) $is_protected;
	}

	/**
	 * Start streaming the file.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public function start() {
		$this->open();
		$this->set_header();
		$this->stream();
		$this->end();
	}

	/**
	 * End the request after the response body has been written.
	 *
	 * A bare `exit` here terminated the PHP process with status 0. In production that is
	 * correct — nothing may append output after a streamed file. Under PHPUnit it killed
	 * the whole run mid-suite AND made the runner report success, so any test reaching
	 * start() silently truncated coverage for everything scheduled after it.
	 *
	 * The filter lets a test harness neutralise the termination without changing the
	 * production path. It is intentionally the only exit point in this class.
	 *
	 * @since 2.12.3
	 * @return void
	 */
	protected function terminate() {
		/**
		 * Filter whether the file streamer ends the request after writing the response.
		 *
		 * Return false ONLY in a test harness. Returning false in production would let
		 * WordPress append markup to a binary response.
		 *
		 * @since 2.12.3
		 * @param bool $should_exit Whether to terminate the request. Default true.
		 */
		if ( ! apply_filters( 'srfm_pro_file_streamer_terminate', true ) ) {
			return;
		}

		exit;
	}

	/**
	 * Open the file stream for reading.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	private function open() {
		$this->stream = fopen( $this->path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen

		if ( ! $this->stream ) {
			wp_die( esc_html__( 'Could not open file for reading.', 'sureforms-pro' ), '', [ 'response' => 500 ] );
		}
	}

	/**
	 * Set response headers, handling byte-range requests for partial content.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	private function set_header() {
		if ( ! is_resource( $this->stream ) ) {
			return;
		}

		$this->start = 0;
		$file_size   = filesize( $this->path );
		$this->size  = false !== $file_size ? $file_size : 0;
		$this->end   = $this->size - 1;

		ob_get_clean();
		header( 'Content-Type: ' . $this->type );
		// Role-restricted files must never be stored or replayed by a shared cache.
		// Per-request access control in handle_file_download() decides WHO may fetch the
		// file, but it cannot stop a CDN / reverse-proxy (Varnish, LiteSpeed, a Cloudflare
		// cache-everything rule, a managed host's edge) from replaying an authorized
		// download to a later anonymous request under this cookie-independent URL — with
		// PHP never running. Treating "most WordPress hosts don't cache dynamic PHP" as
		// sufficient is an assumption about deployment, not a control, so protected
		// responses opt out of shared-cache storage explicitly, and Vary: Cookie stops a
		// cache keyed without the session from conflating requesters. Unprotected uploads
		// stay long-lived and publicly cacheable, matching normal media behavior.
		if ( $this->is_protected ) {
			header( 'Cache-Control: private, no-store, no-cache, max-age=0, must-revalidate' );
			header( 'Pragma: no-cache' );
			header( 'Vary: Cookie' );
			header( 'Expires: 0' );
		} else {
			header( 'Cache-Control: max-age=2592000, public' );
			header( 'Expires: ' . gmdate( 'D, d M Y H:i:s', time() + 2592000 ) . ' GMT' );
		}
		$mtime = filemtime( $this->path );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', false !== $mtime ? $mtime : null ) . ' GMT' );
		// Note: Per RFC 7233 §2.3 the standard value is "bytes" (or "none").
		// The current value "0-{end}" is non-standard but intentional — it signals
		// the exact byte range available to the client, which works correctly with
		// all major browsers and download managers. Changing to "bytes" is safe but
		// would be a behavioral change; deferring to a future refactor to avoid
		// regressions in existing download flows.
		header( 'Accept-Ranges: 0-' . $this->end );
		// Note: the path is server-controlled (resolved via realpath() in
		// handle_file_download()) and validate_filename_strict() blocks control bytes
		// (`\r`, `\n`), so header injection / response splitting is impossible. However,
		// the validator no longer requires the name to match sanitize_file_name() (legacy
		// stored names may contain characters like `"`), so strip the two characters that
		// are unsafe inside the quoted-string filename parameter before emitting the header.
		header( 'Content-Disposition: inline; filename="' . str_replace( [ '"', '\\' ], '', basename( $this->path ) ) . '"' );

		if ( isset( $_SERVER['HTTP_RANGE'] ) ) {
			$c_start = $this->start;
			$c_end   = $this->end;

			[ , $range ] = explode( '=', wp_unslash( $_SERVER['HTTP_RANGE'] ), 2 ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( strpos( $range, ',' ) !== false ) {
				header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
				header( "Content-Range: bytes {$this->start}-{$this->end}/{$this->size}" );
				$this->terminate();
				return;
			}
			if ( '-' === $range ) {
				$c_start = $this->size - (int) substr( $range, 1 );
			} else {
				$range   = explode( '-', $range );
				$c_start = (int) $range[0];
				$c_end   = isset( $range[1] ) && is_numeric( $range[1] ) ? (int) $range[1] : $c_end;
			}
			$c_end = $c_end > $this->end ? $this->end : $c_end;
			if ( $c_start > $c_end || $c_start > $this->size - 1 || $c_end >= $this->size ) {
				header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
				header( "Content-Range: bytes {$this->start}-{$this->end}/{$this->size}" );
				$this->terminate();
				return;
			}
			$this->start = $c_start;
			$this->end   = $c_end;
			$length      = $this->end - $this->start + 1;
			fseek( $this->stream, $this->start );
			header( 'HTTP/1.1 206 Partial Content' );
			header( 'Content-Length: ' . $length );
			header( "Content-Range: bytes {$this->start}-{$this->end}/" . $this->size );
		} else {
			header( 'Content-Length: ' . $this->size );
		}
	}

	/**
	 * Stream the file content in buffered chunks.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	private function stream() {
		if ( ! is_resource( $this->stream ) ) {
			return;
		}

		$i = $this->start;
		// Removes the PHP execution time limit for the streaming loop.
		// This is necessary because large files (e.g. high-res images, multi-page PDFs)
		// streamed over slow connections can exceed the default 30s limit, causing
		// incomplete downloads. PHP's connection_aborted() check inside the loop
		// (below) ensures that if the client disconnects, the loop exits and the
		// worker is freed — so stalled connections do not hold PHP workers indefinitely.
		// A finite limit (e.g. 300s) could prematurely terminate legitimate large-file
		// downloads on slow networks, so 0 is the safer default here.
		set_time_limit( 0 );

		while ( ! feof( $this->stream ) && $i <= $this->end ) {
			$bytes_to_read = $this->buffer;
			if ( $i + $bytes_to_read > $this->end ) {
				$bytes_to_read = $this->end - $i + 1;
			}

			if ( $bytes_to_read > 0 ) {
				$data = fread( $this->stream, $bytes_to_read ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fread
				echo $data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				flush();
				$i += $bytes_to_read;
			}
		}
	}

	/**
	 * Close the stream and terminate.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	private function end() {
		if ( is_resource( $this->stream ) ) {
			fclose( $this->stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose
		}
		$this->terminate();
	}

}
