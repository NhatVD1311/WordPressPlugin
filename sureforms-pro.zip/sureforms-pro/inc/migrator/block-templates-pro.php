<?php
/**
 * Block_Templates_Pro — Gutenberg block emitters for Pro-only SureForms blocks
 * the CF7 migrator wants to produce (date-picker, upload, hidden, slider,
 * page-break).
 *
 * Mirrors Free's `SRFM\Inc\Migrator\Block_Templates` API so the CF7 importer
 * can call each method by name through the `srfm_migrator_block_template`
 * filter. The serialize/strip helpers are duplicated here (rather than
 * exposed from Free) to keep Free's public surface small.
 *
 * @package sureforms-pro
 * @since   2.11.0
 */

namespace SRFM_Pro\Inc\Migrator;

use SRFM\Inc\Migrator\Block_Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block_Templates_Pro
 *
 * @since 2.11.0
 */
class Block_Templates_Pro {
	/**
	 * Build an `srfm/date-picker` block.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, required, slug, default_value).
	 * @return string Block markup.
	 */
	public static function date_picker( array $args ) {
		// Note: srfm/date-picker has no `defaultValue` attribute, so we don't
		// emit one — a stored default would be an orphan attribute the block
		// ignores (matches date_time_picker, which also omits it).
		$attrs = self::strip_empty(
			[
				'label'      => self::str( $args, 'label', 'Date' ),
				'required'   => self::bool( $args, 'required' ),
				'help'       => self::str( $args, 'help' ),
				'errorMsg'   => self::str( $args, 'error_message' ),
				'dateFormat' => self::str( $args, 'date_format', 'mm/dd/yyyy' ),
				'slug'       => self::slug_from_args( $args, 'date' ),
				'block_id'   => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/date-picker', $attrs );
	}

	/**
	 * Build an `srfm/upload` block.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, required, file types, size limit).
	 * @return string Block markup.
	 */
	public static function upload( array $args ) {
		// SureForms Pro's upload block stores `allowedFormats` as an array of
		// `{ value: 'pdf' }` objects (see inc/fields/upload-markup.php — the
		// renderer reads `$item['value']`). Normalize the flat ['pdf','docx']
		// shape from the importer into that schema; pass through already-
		// shaped lists verbatim.
		$raw     = isset( $args['allowed_formats'] ) && is_array( $args['allowed_formats'] )
			? $args['allowed_formats']
			: [];
		$allowed = [];
		foreach ( $raw as $item ) {
			if ( is_array( $item ) && isset( $item['value'] ) ) {
				$allowed[] = [ 'value' => (string) $item['value'] ];
				continue;
			}
			if ( is_string( $item ) && '' !== $item ) {
				$allowed[] = [ 'value' => $item ];
			}
		}
		$attrs = self::strip_empty(
			[
				'label'          => self::str( $args, 'label', 'Upload' ),
				'required'       => self::bool( $args, 'required' ),
				'help'           => self::str( $args, 'help' ),
				'errorMsg'       => self::str( $args, 'error_message' ),
				'fileSizeLimit'  => self::int_or_null( $args, 'file_size_limit' ),
				'allowedFormats' => $allowed,
				'multiple'       => self::bool( $args, 'multiple' ),
				'maxFiles'       => self::int_or_null( $args, 'max_files' ),
				'slug'           => self::slug_from_args( $args, 'upload' ),
				'block_id'       => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/upload', $attrs );
	}

	/**
	 * Build an `srfm/hidden` block.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, default_value).
	 * @return string Block markup.
	 */
	public static function hidden_field( array $args ) {
		$attrs = self::strip_empty(
			[
				'label'        => self::str( $args, 'label', 'Hidden' ),
				'defaultValue' => self::str( $args, 'default_value' ),
				'slug'         => self::slug_from_args( $args, 'hidden' ),
				'block_id'     => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/hidden', $attrs );
	}

	/**
	 * Build an `srfm/slider` block.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, min, max, step, default_value).
	 * @return string Block markup.
	 */
	public static function slider( array $args ) {
		// srfm/slider declares `numberDefaultValue` as a *string* in its
		// block.json schema (default `'10'`). Emitting it as an int makes
		// the Gutenberg parser fall back to the schema default, so the
		// thumb sticks at the max value. Coerce to string here.
		$default = self::int_or_null( $args, 'default_value' );
		$attrs   = self::strip_empty(
			[
				'label'              => self::str( $args, 'label', 'Slider' ),
				'required'           => self::bool( $args, 'required' ),
				'help'               => self::str( $args, 'help' ),
				'errorMsg'           => self::str( $args, 'error_message' ),
				'type'               => 'number',
				'min'                => self::int_or_null( $args, 'min' ),
				'max'                => self::int_or_null( $args, 'max' ),
				'step'               => self::int_or_null( $args, 'step' ),
				'numberDefaultValue' => null === $default ? '' : (string) $default,
				'slug'               => self::slug_from_args( $args, 'slider' ),
				'block_id'           => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/slider', $attrs );
	}

	/**
	 * Build an `srfm/page-break` block — separates a multi-page form.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label = page heading).
	 * @return string Block markup.
	 */
	public static function page_break( array $args ) {
		$attrs = self::strip_empty(
			[
				'label'    => self::str( $args, 'label', 'Next' ),
				'slug'     => self::slug_from_args( $args, 'page-break' ),
				'block_id' => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/page-break', $attrs );
	}

	/**
	 * Build a date / time block. Routes to `srfm/date-picker` for `date` and
	 * `datetime` formats and to `srfm/time-picker` for `time` formats — both
	 * Pro blocks. WPForms uses `format` ∈ {`date`, `time`, `date-time`}.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, required, format,
	 *                                   date_format, time_format).
	 * @return string Block markup.
	 */
	public static function date_time_picker( array $args ) {
		$format = self::str( $args, 'format', 'date' );
		if ( 'time' === $format ) {
			$attrs = self::strip_empty(
				[
					'label'    => self::str( $args, 'label', 'Time' ),
					'required' => self::bool( $args, 'required' ),
					'help'     => self::str( $args, 'help' ),
					'errorMsg' => self::str( $args, 'error_message' ),
					'slug'     => self::slug_from_args( $args, 'time' ),
					'block_id' => Block_Templates::block_id(),
				]
			);
			return self::serialize_block( 'srfm/time-picker', $attrs );
		}
		// Date / Date+Time both render as a date-picker; WPForms' time_format
		// detail is lost since SureForms' date-picker doesn't toggle a time
		// component on the same field.
		$attrs = self::strip_empty(
			[
				'label'      => self::str( $args, 'label', 'Date' ),
				'required'   => self::bool( $args, 'required' ),
				'help'       => self::str( $args, 'help' ),
				'errorMsg'   => self::str( $args, 'error_message' ),
				'dateFormat' => self::str( $args, 'date_format', 'mm/dd/yyyy' ),
				'slug'       => self::slug_from_args( $args, 'date' ),
				'block_id'   => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/date-picker', $attrs );
	}

	/**
	 * Build an `srfm/signature` block.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, required, ink_color).
	 * @return string Block markup.
	 */
	public static function signature( array $args ) {
		$attrs = self::strip_empty(
			[
				'label'    => self::str( $args, 'label', 'Signature' ),
				'required' => self::bool( $args, 'required' ),
				'help'     => self::str( $args, 'help' ),
				'errorMsg' => self::str( $args, 'error_message' ),
				'penColor' => self::str( $args, 'ink_color' ),
				'slug'     => self::slug_from_args( $args, 'signature' ),
				'block_id' => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/signature', $attrs );
	}

	/**
	 * Build an `srfm/rating` block. WPForms supports `scale=3|5|10` and four
	 * icon shapes; SureForms' rating is fixed at 5 icons with iconShape ∈
	 * {`star`, `smiley`, `thumb`} (see src/blocks/rating/edit.js — there is no
	 * `heart` shape). We carry the icon shape where SureForms has an
	 * equivalent and fall back to `star` otherwise; the scale is lossy and
	 * noted partial in the migration summary.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, required, icon).
	 * @return string Block markup.
	 */
	public static function rating( array $args ) {
		$icon = self::str( $args, 'icon', 'star' );
		// Map WPForms icon → SureForms iconShape. SureForms supports
		// star/smiley/thumb natively; `heart` has no equivalent so it maps to
		// the nearest visual (star). `smiley` is supported — don't downgrade.
		$shape_map = [
			'star'   => 'star',
			'heart'  => 'star',
			'smiley' => 'smiley',
			'thumb'  => 'thumb',
		];
		$shape     = $shape_map[ $icon ] ?? 'star';
		$attrs     = self::strip_empty(
			[
				'label'     => self::str( $args, 'label', 'Rating' ),
				'required'  => self::bool( $args, 'required' ),
				'help'      => self::str( $args, 'help' ),
				'errorMsg'  => self::str( $args, 'error_message' ),
				'iconShape' => $shape,
				'slug'      => self::slug_from_args( $args, 'rating' ),
				'block_id'  => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/rating', $attrs );
	}

	/**
	 * Build an `srfm/nps` block — Net Promoter Score (0–10 with two end
	 * labels). Maps WPForms `nps_low_label` / `nps_high_label`.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args.
	 * @return string Block markup.
	 */
	public static function nps( array $args ) {
		$attrs = self::strip_empty(
			[
				'label'     => self::str( $args, 'label', 'How likely are you to recommend us?' ),
				'required'  => self::bool( $args, 'required' ),
				'help'      => self::str( $args, 'help' ),
				'errorMsg'  => self::str( $args, 'error_message' ),
				'lowLabel'  => self::str( $args, 'low_label' ),
				'highLabel' => self::str( $args, 'high_label' ),
				'slug'      => self::slug_from_args( $args, 'nps' ),
				'block_id'  => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/nps', $attrs );
	}

	/**
	 * Build an `srfm/html` block (Pro). Carries the raw HTML/content payload
	 * verbatim — kses sanitization happens downstream on save.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, content).
	 * @return string Block markup.
	 */
	public static function html_block( array $args ) {
		// `htmlContent` carries the raw payload verbatim. This is safe because
		// srfm/html is a by-design raw-HTML block whose render path applies
		// `wp_kses_post()` (inc/fields/html-markup.php) — that renderer is the
		// sanitization boundary. Do NOT remove the downstream kses pass without
		// adding sanitization here instead.
		$attrs = self::strip_empty(
			[
				'label'       => self::str( $args, 'label', 'HTML' ),
				'htmlContent' => self::str( $args, 'content' ),
				'slug'        => self::slug_from_args( $args, 'html' ),
				'block_id'    => Block_Templates::block_id(),
			]
		);
		return self::serialize_block( 'srfm/html', $attrs );
	}

	/**
	 * Build an `srfm/repeater` Gutenberg block with innerBlocks. Caller
	 * pre-assembles the children's block markup and passes it via
	 * `args['children']`; we wrap with the opening/closing tags so the
	 * block editor recognises the nested fields.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label, slug, children).
	 * @return string Block markup with innerBlocks.
	 */
	public static function repeater_container( array $args ) {
		$children = self::str( $args, 'children' );
		$attrs    = self::strip_empty(
			[
				'label'    => self::str( $args, 'label', 'Repeater Field' ),
				'help'     => self::str( $args, 'help' ),
				'minItems' => self::int_or_null( $args, 'min_rows' ),
				'maxItems' => self::int_or_null( $args, 'max_rows' ),
				'slug'     => self::slug_from_args( $args, 'repeater' ),
				'block_id' => Block_Templates::block_id(),
			]
		);
		$json     = self::encode_attrs( $attrs );
		return "<!-- wp:srfm/repeater {$json} -->\n{$children}\n<!-- /wp:srfm/repeater -->\n";
	}

	/**
	 * Build an `srfm/address` block (Free block; Pro maps WPForms' address
	 * field onto it). SureForms' address is an InnerBlocks container — the
	 * save function is `<InnerBlocks.Content />` so the block markup MUST
	 * include the six sub-fields (Address Line 1/2, City, State, Postal
	 * Code, Country) as nested `srfm/input` blocks or the field renders
	 * empty on the frontend.
	 *
	 * Mirrors the default `addressTemplate` in
	 * sureforms/src/blocks/address/edit.js: five `srfm/input` sub-fields plus
	 * Country as an `srfm/dropdown`, each laid out two-up at `fieldWidth: 50`.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args.
	 * @return string Block markup with innerBlocks.
	 */
	public static function address( array $args ) {
		$required = self::bool( $args, 'required' );
		$attrs    = self::strip_empty(
			[
				'label'    => self::str( $args, 'label', 'Address' ),
				'required' => $required,
				'help'     => self::str( $args, 'help' ),
				'errorMsg' => self::str( $args, 'error_message' ),
				'slug'     => self::slug_from_args( $args, 'address' ),
				'block_id' => Block_Templates::block_id(),
			]
		);

		// Build the six sub-fields directly (rather than via Free's
		// Block_Templates::input, which doesn't expose `fieldWidth`) so each
		// lays out two-up at 50% width like the native address template.
		// Country is a dropdown, not a text input, per the real template.
		$children  = self::address_sub_field( 'srfm/input', 'Address Line 1', $required );
		$children .= self::address_sub_field( 'srfm/input', 'Address Line 2', false );
		$children .= self::address_sub_field( 'srfm/input', 'City', $required );
		$children .= self::address_sub_field( 'srfm/input', 'State', $required );
		$children .= self::address_sub_field( 'srfm/input', 'Postal Code', $required );
		$children .= self::address_sub_field( 'srfm/dropdown', 'Country', $required );

		$json = self::encode_attrs( $attrs );
		return "<!-- wp:srfm/address {$json} -->\n{$children}<!-- /wp:srfm/address -->\n";
	}

	/**
	 * Build an `srfm/input` block configured for password input. WPForms'
	 * `password_strength` / `confirmation` keys are dropped — SureForms has
	 * no equivalent strength enforcement.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args.
	 * @return string Block markup.
	 */
	public static function password_input( array $args ) {
		// SureForms input doesn't expose an `inputType=password` toggle in
		// the migrator API today; emit a plain input and surface the field
		// as partially supported in the migration summary.
		return Block_Templates::input( $args );
	}

	/**
	 * Build a textarea-flavoured block for WPForms' Rich Text field. The
	 * rich-text formatting is lossy — emit a textarea and the caller flags
	 * it as `unsupported_fields_partial` in the migration summary.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args.
	 * @return string Block markup.
	 */
	public static function richtext( array $args ) {
		return Block_Templates::textarea( $args );
	}

	/**
	 * Build a divider as a dedicated `srfm/separator` block — the native
	 * SureForms separator (registered by the bundled Gutenberg module; see
	 * modules/gutenberg/dist/blocks/separator/class-spec-separator.php). It is
	 * the block the form editor offers under the "divider" keyword and is on
	 * the form CPT allow-list, so importing CF7/WPForms/Gravity/Ninja dividers
	 * onto it (rather than an `srfm/html` `<hr>`) yields an editable, on-brand
	 * separator instead of an opaque HTML payload.
	 *
	 * The block's render callback (`render_html`) fills every visual attribute
	 * from its schema defaults, so we only emit `block_id` plus — when the
	 * source field carries a label — the `text` element variant so the heading
	 * survives the import. A label-less divider emits a plain separator line.
	 *
	 * Note: the source field's description/help text has no home on the
	 * separator block (it renders a line plus an optional inline label/icon
	 * only), so it is intentionally dropped here.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Field args (label).
	 * @return string Block markup.
	 */
	public static function divider( array $args ) {
		$label = self::str( $args, 'label' );
		$attrs = [
			'block_id' => Block_Templates::block_id(),
		];
		if ( '' !== $label ) {
			// `elementType: 'text'` makes render_html emit the inline heading;
			// `separatorText` carries the source label (defaults to "Divider"
			// in the schema when absent).
			$attrs['elementType']   = 'text';
			$attrs['separatorText'] = $label;
		}
		return self::serialize_block( 'srfm/separator', $attrs );
	}

	/**
	 * Emit one address sub-field block at 50% width.
	 *
	 * The Country sub-field is an `srfm/dropdown`; its option list (the full
	 * country roster) lives in SureForms Free's `countries.json`, which is a
	 * build-time JS import and is not readable server-side — so we emit the
	 * dropdown shell with the correct block type and width and leave the
	 * option list to be populated in the editor. This still fixes the
	 * render-breaking bug where Country imported as a free-text input.
	 *
	 * @since 2.11.0
	 *
	 * @param string $name     Block name (`srfm/input` or `srfm/dropdown`).
	 * @param string $label    Sub-field label.
	 * @param bool   $required Whether the sub-field is required.
	 * @return string Indented block markup.
	 */
	private static function address_sub_field( $name, $label, $required ) {
		$attrs = self::strip_empty(
			[
				'label'      => $label,
				'required'   => $required,
				'fieldWidth' => 50,
				'slug'       => sanitize_title( $label ),
				'block_id'   => Block_Templates::block_id(),
			]
		);
		return "\t" . self::serialize_block( $name, $attrs );
	}

	/**
	 * Serialize a self-closing Gutenberg block with name + attributes.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $name  Block name (e.g. `srfm/date-picker`).
	 * @param array<string,mixed> $attrs Block attributes.
	 * @return string
	 */
	private static function serialize_block( $name, array $attrs ) {
		if ( empty( $attrs ) ) {
			return "<!-- wp:{$name} /-->\n";
		}
		return "<!-- wp:{$name} " . self::encode_attrs( $attrs ) . " /-->\n";
	}

	/**
	 * JSON-encode a block's attributes with the HEX-escaping flags every
	 * emitter shares. The `JSON_HEX_*` flags neutralise attacker-controlled
	 * labels (e.g. a literal `-->`) so they cannot break out of the
	 * surrounding Gutenberg HTML comment. Centralised here so the flag list
	 * lives in exactly one place — `serialize_block()` and the innerBlocks
	 * wrappers (`address()`, `repeater_container()`) all route through it.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $attrs Block attributes.
	 * @return string Encoded JSON (falls back to `{}` on encode failure).
	 */
	private static function encode_attrs( array $attrs ) {
		$flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
		$json  = wp_json_encode( $attrs, $flags );
		return is_string( $json ) ? $json : '{}';
	}

	/**
	 * Drop keys whose value is null, empty string, or empty array.
	 * Keeps zero-valued numbers and `false` booleans — they're meaningful.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $arr Attribute array.
	 * @return array<string,mixed>
	 */
	private static function strip_empty( array $arr ) {
		return array_filter(
			$arr,
			static function ( $v ) {
				if ( null === $v ) {
					return false;
				}
				if ( '' === $v ) {
					return false;
				}
				if ( is_array( $v ) && empty( $v ) ) {
					return false;
				}
				return true;
			}
		);
	}

	/**
	 * Fetch a string from args with a default.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args    Args.
	 * @param string              $key     Key to fetch.
	 * @param string              $default Default when missing/empty.
	 * @return string
	 */
	private static function str( array $args, $key, $default = '' ) {
		if ( ! isset( $args[ $key ] ) ) {
			return $default;
		}
		$value = $args[ $key ];
		if ( is_string( $value ) && '' !== $value ) {
			return $value;
		}
		return $default;
	}

	/**
	 * Fetch a bool from args (truthy values become true).
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Args.
	 * @param string              $key  Key to fetch.
	 * @return bool
	 */
	private static function bool( array $args, $key ) {
		return ! empty( $args[ $key ] );
	}

	/**
	 * Fetch an int from args (numeric → int, else null).
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args Args.
	 * @param string              $key  Key to fetch.
	 * @return int|null
	 */
	private static function int_or_null( array $args, $key ) {
		if ( ! isset( $args[ $key ] ) || ! is_numeric( $args[ $key ] ) ) {
			return null;
		}
		return (int) $args[ $key ];
	}

	/**
	 * Resolve the block slug — honors an explicit `slug` arg, else slugifies
	 * the label, else falls back to the supplied default.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed> $args     Args.
	 * @param string              $fallback Slug fallback.
	 * @return string
	 */
	private static function slug_from_args( array $args, $fallback ) {
		$override = self::str( $args, 'slug' );
		if ( '' !== $override ) {
			return $override;
		}
		$label = self::str( $args, 'label', $fallback );
		$slug  = sanitize_title( $label );
		return '' !== $slug ? $slug : $fallback;
	}
}
