<?php
/**
 * Block_Assets Class.
 *
 * @package sureforms-pro.
 */

namespace SRFM_Pro\Inc;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Block_Assets handler class.
 *
 * @since 0.0.1
 */
class Block_Assets {
	use Get_Instance;

	/**
	 * Color picker Text field block IDs for the current email render context.
	 *
	 * @var array<string,bool>
	 * @since 2.10.0
	 */
	private static $email_color_picker_block_ids = [];

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_filter( 'render_block', [ $this, 'generate_render_script' ], 10, 2 );
		add_filter( 'render_block_srfm/input', [ $this, 'render_input_color_picker' ], 10, 2 );
		add_filter( 'srfm_email_notification_should_send', [ $this, 'prepare_color_picker_email_fields_before_email' ], 10, 3 );
		add_action( 'srfm_before_processing_all_data_field', [ $this, 'render_input_color_picker_in_all_data_email' ] );
		add_filter( 'srfm_all_data_field_row', [ $this, 'should_skip_input_color_picker_field_row_in_email' ], 10, 2 );
	}

	/**
	 * Enqueue Script.
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function enqueue_scripts() {
		// Page Break compatibility for Elementor and Bricks preview.
		 // phpcs:ignore -- wordpress.Security.NonceVerification
		if ( ! empty( $_GET['bricks'] ) && 'run' === $_GET['bricks'] || ! empty( $_GET['elementor-preview'] ) ) {
		// phpcs:ignoreEnd
			wp_enqueue_script( SRFM_PRO_SLUG . '-page-break-deps', SRFM_PRO_URL . 'dist/pageBreak.js', [ 'srfm-form-submit', 'wp-i18n' ], SRFM_PRO_VER, true );

			wp_localize_script(
				SRFM_PRO_SLUG . '-page-break-deps',
				'srfm_page_break_data',
				[
					'is_bricks_preview' => ! empty( $_GET['bricks'] ) && 'run' === $_GET['bricks'], // phpcs:ignore -- wordpress.Security.NonceVerification
					'is_elementor_preview' => ! empty( $_GET['elementor-preview'] ), // phpcs:ignore -- wordpress.Security.NonceVerification
				]
			);

			// Register script translations.
			Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-page-break-deps' );
		}
	}

	/**
	 * Render function.
	 *
	 * @param string $block_content Entire Block Content.
	 * @param array  $block Block Properties As An Array.
	 * @return string
	 * @phpstan-ignore-next-line
	 */
	public function generate_render_script( $block_content, $block ) {

		if ( isset( $block['blockName'] ) ) {
			self::enqueue_script( $block['blockName'], $block );
		}
		return $block_content;
	}

	/**
	 * Enqueue block scripts
	 *
	 * @param string $block_type Block name.
	 * @param array  $block      Block properties array.
	 * @since 0.0.1
	 * @return void
	 */
	public function enqueue_script( $block_type, $block = [] ) {
		$block_name        = str_replace( 'srfm/', '', $block_type );
		$script_dep_blocks = [ 'rating', 'upload', 'date-picker', 'time-picker', 'slider', 'password', 'page-break', 'html', 'nps' ];

		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/';
		$rtl         = is_rtl() ? '-rtl' : '';

		wp_enqueue_style( SRFM_PRO_SLUG . '-custom-styles', $css_uri . 'custom-styles' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );

		if ( 'input' === $block_name && ! empty( $block['attrs']['isColorPicker'] ) ) {
			$js_uri = SRFM_PRO_URL . 'assets/js/' . $dir_name . '/blocks/';

			wp_enqueue_style( SRFM_PRO_SLUG . '-frontend-default', $css_uri . 'blocks/default/frontend' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );
			wp_enqueue_script( SRFM_PRO_SLUG . '-input-color-picker', $js_uri . 'input-color-picker' . $file_prefix . '.js', [], SRFM_PRO_VER, true );
		}

		if ( in_array( $block_name, $script_dep_blocks, true ) ) {
			$js_uri         = SRFM_PRO_URL . 'assets/js/' . $dir_name . '/blocks/';
			$js_vendor_uri  = SRFM_PRO_URL . 'assets/js/minified/deps/';
			$css_vendor_uri = SRFM_PRO_URL . 'assets/css/minified/deps/';

			wp_enqueue_style( SRFM_PRO_SLUG . '-frontend-default', $css_uri . 'blocks/default/frontend' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );

			// Load common dependencies by wp_enqueue_script.
			wp_enqueue_script( 'wp-a11y' );

			switch ( $block_name ) {
				case 'date-picker':
					/**
					 * We require the input mask library as well for the date-picker block.
					 * The same is being enqueued from the free frontend assets file along with the input block.
					 */
					wp_enqueue_style( SRFM_PRO_SLUG . '-vanillajs-datepicker', $css_vendor_uri . 'vanillajs-datepicker.min.css', [], SRFM_PRO_VER );
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}-vanillajs-datepicker-deps", $js_vendor_uri . 'vanillajs-datepicker.min.js', [], SRFM_PRO_VER, true );
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}-deps", SRFM_PRO_URL . 'dist/datePicker.js', [ 'srfm-form-submit' ], SRFM_PRO_VER, true );

					// Load appropriate locale file for datepicker.
					self::enqueue_datepicker_locale( $block );
					break;

				case 'time-picker':
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}", $js_uri . $block_name . $file_prefix . '.js', [], SRFM_PRO_VER, true );
					break;

				case 'page-break':
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}-deps", SRFM_PRO_URL . 'dist/pageBreak.js', [ 'srfm-form-submit', 'wp-i18n' ], SRFM_PRO_VER, true );
					Pro_Helper::register_script_translations( SRFM_PRO_SLUG . "-{$block_name}-deps" );
					break;

				case 'html':
					// HTML block only needs CSS, no JavaScript required.
					break;

				case 'nps':
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}", $js_uri . $block_name . $file_prefix . '.js', [ 'wp-hooks' ], SRFM_PRO_VER, true );
					break;

				default:
					wp_enqueue_script( SRFM_PRO_SLUG . "-{$block_name}", $js_uri . $block_name . $file_prefix . '.js', [], SRFM_PRO_VER, true );
					break;
			}

			// if block type is upload then localize allowed mime types.
			if ( 'upload' === $block_name ) {
				wp_localize_script(
					SRFM_PRO_SLUG . "-{$block_name}",
					'srfmProBlocksData',
					[
						'allowed_mime_types' => Pro_Helper::get_wp_file_types( true )['formats'],
					]
				);
			}
		}
	}

	/**
	 * Render the Pro color picker variant for the free Text field.
	 *
	 * @param string $block_content Entire Block Content.
	 * @param array  $block Block Properties As An Array.
	 * @return string
	 * @since 2.10.0
	 */
	public function render_input_color_picker( $block_content, $block ) {
		if ( empty( $block['attrs']['isColorPicker'] ) ) {
			return $block_content;
		}

		// NOTE: This relies on the core Text field markup exposing the `srfm-input-input`
		// input class and the `srfm-input-block` wrapper class. If core ever renames these,
		// the early-returns below leave the field as a plain text input — see the debug log.
		$input_tag = '';
		if ( preg_match( '/<input\b[^>]*class="[^"]*\bsrfm-input-input\b[^"]*"[^>]*\/?>/i', $block_content, $matches ) ) {
			$input_tag = $matches[0];
		}

		if ( empty( $input_tag ) ) {
			/**
			 * Fires when the color picker variant cannot be rendered because the
			 * expected core `srfm-input-input` markup was not found, so the field
			 * falls back to a plain text input. Lets the silent coupling surface.
			 *
			 * @param array $block The block being rendered.
			 * @since 2.10.0
			 */
			do_action( 'srfm_pro_color_picker_render_missed', $block );
			return $block_content;
		}

		$name              = self::get_input_attribute( $input_tag, 'name' );
		$id                = self::get_input_attribute( $input_tag, 'id' );
		$aria_described_by = self::get_input_attribute( $input_tag, 'aria-describedby' );
		$data_required     = self::get_input_attribute( $input_tag, 'data-required' );
		$aria_required     = self::get_input_attribute( $input_tag, 'aria-required' );
		$placeholder       = self::get_input_attribute( $input_tag, 'placeholder' );
		$default_value     = $block['attrs']['defaultValue'] ?? '';
		$color_value       = self::normalize_hex_color( is_string( $default_value ) ? $default_value : '' );
		$picker_value      = ! empty( $color_value ) ? $color_value : '#EF233C';
		$placeholder       = ! empty( $placeholder ) ? $placeholder : __( 'Select Color', 'sureforms-pro' );

		ob_start();
		?>
		<div class="srfm-input-common srfm-input-color-picker">
			<span class="srfm-color-picker-swatch" style="background-color: <?php echo esc_attr( $picker_value ); ?>;" role="button" tabindex="0" aria-label="<?php echo esc_attr__( 'Choose color', 'sureforms-pro' ); ?>"></span>
			<input
				class="srfm-color-picker-value"
				type="text"
				name="<?php echo esc_attr( $name ); ?>"
				id="<?php echo esc_attr( $id ); ?>"
				<?php echo ! empty( $aria_described_by ) ? "aria-describedby='" . esc_attr( $aria_described_by ) . "'" : ''; ?>
				data-required="<?php echo esc_attr( $data_required ); ?>"
				aria-required="<?php echo esc_attr( $aria_required ); ?>"
				value="<?php echo esc_attr( $color_value ); ?>"
				placeholder="<?php echo esc_attr( $placeholder ); ?>"
				inputmode="text"
				autocomplete="off"
				maxlength="7"
				title="<?php echo esc_attr__( 'Please add a proper hex color value.', 'sureforms-pro' ); ?>"
			/>
			<input
				class="srfm-color-picker-native"
				type="color"
				value="<?php echo esc_attr( $picker_value ); ?>"
				aria-label="<?php echo esc_attr__( 'Choose color', 'sureforms-pro' ); ?>"
				tabindex="-1"
			/>
		</div>
		<?php
		$color_picker_markup = (string) ob_get_clean();

		$block_content = (string) preg_replace( '/(<div\b[^>]*class=")([^"]*\bsrfm-input-block[^"]*)(")/i', '$1$2 srfm-input-color-picker-block$3', $block_content, 1 );

		// When no per-field error message is set, the core markup falls back to the Text field's
		// required message. Swap in the dedicated color picker required message instead.
		if ( empty( $block['attrs']['errorMsg'] ) ) {
			$message_key  = 'srfm_input_color_picker_block_required_text';
			$required_msg = Helper::get_default_dynamic_block_option( $message_key );

			// Backward compatibility: on sites whose saved dynamic block option predates
			// this key, the saved lookup returns empty — fall back to the registered default.
			if ( '' === $required_msg ) {
				$defaults     = Helper::default_dynamic_block_option();
				$required_msg = is_array( $defaults ) && isset( $defaults[ $message_key ] ) ? $defaults[ $message_key ] : '';
			}

			if ( is_string( $required_msg ) && '' !== $required_msg ) {
				$block_content = (string) preg_replace( '/(data-error-msg=")[^"]*(")/', '${1}' . esc_attr( $required_msg ) . '${2}', $block_content, 1 );
			}
		}

		return str_replace( $input_tag, $color_picker_markup, $block_content );
	}

	/**
	 * Prepare color picker Text field IDs before the core email template renders {all_data}.
	 *
	 * @param mixed $email_notifications Email notification data.
	 * @param mixed $submission_data     Submission data (unused; required positionally to reach $form_data).
	 * @param mixed $form_data           Form data.
	 * @since 2.10.0
	 * @return mixed Email notification data.
	 * @phpcsSuppress SlevomatCodingStandard.Functions.UnusedParameter
	 */
	public function prepare_color_picker_email_fields_before_email( $email_notifications, $submission_data, $form_data ) {
		// This is a pass-through filter callback: we only use the `srfm_email_notification_should_send`
		// hook timing to prime the color picker block-ID map before the {all_data} template renders,
		// then return $email_notifications untouched. The state is consumed immediately afterwards by
		// render_input_color_picker_in_all_data_email().
		$form_id = 0;

		if ( is_array( $form_data ) ) {
			// Core passes the form id under the `form-id` (hyphen) key; `form_id` is kept as a fallback.
			$form_id = absint( $form_data['form-id'] ?? $form_data['form_id'] ?? 0 );
		}

		self::prepare_color_picker_email_fields( $form_id );

		return $email_notifications;
	}

	/**
	 * Prepare color picker Text field IDs for email rendering.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.10.0
	 * @return void
	 */
	public static function prepare_color_picker_email_fields( $form_id ) {
		self::$email_color_picker_block_ids = [];

		$form_id = absint( $form_id );
		if ( ! $form_id ) {
			return;
		}

		$form = get_post( $form_id );
		if ( ! $form instanceof \WP_Post ) {
			return;
		}

		self::collect_color_picker_block_ids( parse_blocks( $form->post_content ) );
	}

	/**
	 * Render color picker Text field rows with a swatch in the {all_data} email section.
	 *
	 * @param array<string,mixed> $args Field render args.
	 * @since 2.10.0
	 * @return void
	 */
	public function render_input_color_picker_in_all_data_email( $args ) {
		if ( empty( $args['block_name'] ) || 'srfm-input' !== $args['block_name'] ) {
			return;
		}

		$field_name = isset( $args['label'] ) ? Helper::get_string_value( $args['label'] ) : '';
		if ( ! self::is_color_picker_email_field( $field_name ) ) {
			return;
		}

		$color_value = self::normalize_hex_color( Helper::get_string_value( $args['value'] ?? '' ) );
		if ( empty( $color_value ) ) {
			return;
		}

		$td_style    = 'font-weight: 500;font-size: 14px;line-height: 20px;padding: 12px;text-align:left;word-break: break-word;border-bottom: 1px solid #E5E7EB;';
		$field_label = isset( $args['processed_label'] ) && is_string( $args['processed_label'] ) ? $args['processed_label'] : '';

		?>
		<tr class="field-label">
			<th style="<?php echo esc_attr( $td_style ); ?>color: #1E293B;background-color: #F1F5F9;">
				<?php // The label is decoded from the submitted field key, so it is attacker-controllable — escape it as text, never as markup. ?>
				<strong><?php echo esc_html( html_entity_decode( $field_label ) ); ?>:</strong>
			</th>
		</tr>
		<tr class="field-value">
			<td style="<?php echo esc_attr( $td_style ); ?>color: #475569;">
				<span style="display:inline-block;width:12px;height:12px;border-radius:50%;border:1px solid #D0D5DD;background-color:<?php echo esc_attr( $color_value ); ?>;vertical-align:-1px;margin-right:8px;"></span><?php echo esc_html( $color_value ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Skip the default email row when a color picker row has already been rendered.
	 *
	 * @param bool         $should_add_field_row Whether the row should be rendered.
	 * @param array<mixed> $args                 Field render args.
	 * @since 2.10.0
	 * @return bool
	 */
	public function should_skip_input_color_picker_field_row_in_email( $should_add_field_row, $args ) {
		$field_name = isset( $args['field_name'] ) ? Helper::get_string_value( $args['field_name'] ) : '';

		if (
			isset( $args['block_name'] ) &&
			'srfm-input' === $args['block_name'] &&
			self::is_color_picker_email_field( $field_name ) &&
			self::normalize_hex_color( Helper::get_string_value( $args['value'] ?? '' ) )
		) {
			return false;
		}

		return $should_add_field_row;
	}

	/**
	 * Enqueue appropriate datepicker locale file based on WordPress locale.
	 *
	 * @param array $block Block properties array.
	 * @return void
	 * @since 2.5.0
	 */
	public static function enqueue_datepicker_locale( $block = [] ) {
		// Static variable to accumulate week start settings for all date picker blocks.
		static $week_start_settings = [];

		$wp_locale = get_locale();

		// Extract form_id and block_id from block attributes.
		$form_id  = $block['attrs']['formId'] ?? 0;
		$block_id = $block['attrs']['block_id'] ?? '';

		// Map WordPress locale to datepicker language code.
		$locale_map = [
			// German.
			'de_DE'          => 'de',
			'de_DE_formal'   => 'de',
			'de_CH'          => 'de',
			'de_CH_informal' => 'de',
			'de_AT'          => 'de',

			// Spanish.
			'es_ES'          => 'es',
			'es_MX'          => 'es',
			'es_AR'          => 'es',
			'es_CL'          => 'es',
			'es_CO'          => 'es',
			'es_CR'          => 'es',
			'es_DO'          => 'es',
			'es_EC'          => 'es',
			'es_GT'          => 'es',
			'es_HN'          => 'es',
			'es_PE'          => 'es',
			'es_PR'          => 'es',
			'es_UY'          => 'es',
			'es_VE'          => 'es',

			// French.
			'fr_FR'          => 'fr',
			'fr_CA'          => 'fr',
			'fr_BE'          => 'fr',
			'fr_CH'          => 'fr',

			// Italian.
			'it_IT'          => 'it',
			'it_CH'          => 'it',

			// Dutch.
			'nl_NL'          => 'nl',
			'nl_NL_formal'   => 'nl',
			'nl_BE'          => 'nl',

			// Polish.
			'pl_PL'          => 'pl',

			// Portuguese.
			'pt_PT'          => 'pt',
			'pt_PT_ao90'     => 'pt',
			'pt_AO'          => 'pt',
			'pt_BR'          => 'pt',

			// Swedish.
			'sv_SE'          => 'sv',
		];

		// Default to English.
		$datepicker_locale = $locale_map[ $wp_locale ] ?? 'en';

		// Enqueue locale script only if it's not English.
		if ( 'en' !== $datepicker_locale ) {
			$relative_path = 'assets/js/minified/deps/date-picker-locales/' . $datepicker_locale . '.js';
			$local_path    = SRFM_PRO_DIR . $relative_path;

			if ( file_exists( $local_path ) ) {
				wp_enqueue_script(
					SRFM_PRO_SLUG . '-datepicker-locale-' . $datepicker_locale,
					SRFM_PRO_URL . $relative_path,
					[ SRFM_PRO_SLUG . '-date-picker-vanillajs-datepicker-deps' ],
					SRFM_PRO_VER,
					true
				);
			}
		}

		/**
		 * Filter the first day of the week for the datepicker.
		 * Use this filter to customize which day the week starts on.
		 *
		 * Accepts day name strings: 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'
		 *
		 * @since 2.5.1
		 *
		 * @param string $week_start The day the week starts on. Default 'sunday'.
		 * @param int    $form_id    The form ID.
		 * @param string $block_id   The block ID.
		 */
		$week_start = apply_filters( 'srfm_datepicker_week_start', 'sunday', $form_id, $block_id );

		// Map day names to numeric values (0 = Sunday, 1 = Monday, etc.).
		$day_map = [
			'sunday'    => 0,
			'monday'    => 1,
			'tuesday'   => 2,
			'wednesday' => 3,
			'thursday'  => 4,
			'friday'    => 5,
			'saturday'  => 6,
		];

		// Ensure week_start is a string before processing.
		$week_start = is_string( $week_start ) ? $week_start : 'sunday';

		// Convert day name to number, default to 0 (Sunday) if invalid.
		$week_start_value = $day_map[ strtolower( $week_start ) ] ?? 0;

		// Store week start setting for this block.
		if ( ! empty( $block_id ) ) {
			$week_start_settings[ $block_id ] = $week_start_value;
		}

		// Always pass locale and settings to JS (with English fallback).
		wp_localize_script(
			SRFM_PRO_SLUG . '-date-picker-deps',
			'srfmDatepickerLocale',
			[
				'locale'            => $datepicker_locale,
				'weekStart'         => $week_start_value,
				'weekStartSettings' => $week_start_settings,
			]
		);
	}

	/**
	 * Recursively collect color picker Text field block IDs from parsed blocks.
	 *
	 * @param array<mixed> $blocks Parsed blocks.
	 * @since 2.10.0
	 * @return void
	 */
	private static function collect_color_picker_block_ids( $blocks ) {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];
			if (
				'srfm/input' === ( $block['blockName'] ?? '' ) &&
				! empty( $attrs['isColorPicker'] ) &&
				! empty( $attrs['block_id'] ) &&
				is_string( $attrs['block_id'] )
			) {
				self::$email_color_picker_block_ids[ $attrs['block_id'] ] = true;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_color_picker_block_ids( $block['innerBlocks'] );
			}
		}
	}

	/**
	 * Check whether an email field key belongs to a color picker Text field.
	 *
	 * @param string $field_name Field key.
	 * @since 2.10.0
	 * @return bool
	 */
	private static function is_color_picker_email_field( $field_name ) {
		if ( empty( self::$email_color_picker_block_ids ) ) {
			return false;
		}

		$block_id = Pro_Helper::get_block_id( $field_name );

		return ! empty( $block_id ) && isset( self::$email_color_picker_block_ids[ $block_id ] );
	}

	/**
	 * Get an attribute value from an input HTML tag.
	 *
	 * @param string $input_tag Input tag markup.
	 * @param string $attribute Attribute name.
	 * @return string
	 * @since 2.10.0
	 */
	private static function get_input_attribute( $input_tag, $attribute ) {
		if ( preg_match( '/\s' . preg_quote( $attribute, '/' ) . '=(["\'])(.*?)\1/i', $input_tag, $matches ) ) {
			return html_entity_decode( $matches[2], ENT_QUOTES );
		}

		return '';
	}

	/**
	 * Normalize a hex color value.
	 *
	 * Keep the `^#[0-9A-Fa-f]{6}$` rule identical to the JS copies in
	 * src/blocks/input-color-picker.js and assets/js/unminified/blocks/input-color-picker.js.
	 *
	 * @param string $value Color value.
	 * @return string
	 * @since 2.10.0
	 */
	private static function normalize_hex_color( $value ) {
		$color = trim( $value );

		if ( empty( $color ) ) {
			return '';
		}

		if ( 0 !== strpos( $color, '#' ) ) {
			$color = '#' . $color;
		}

		return preg_match( '/^#[0-9A-Fa-f]{6}$/', $color ) ? strtoupper( $color ) : '';
	}

}
