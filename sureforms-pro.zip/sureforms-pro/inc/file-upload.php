<?php
/**
 * File Upload Handler.
 *
 * Manages all file upload related operations including directory setup,
 * file naming, uploading, and deletion.
 *
 * @package sureforms-pro.
 * @since 2.6.0
 */

namespace SRFM_Pro\Inc;

use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Signature\Init as Signature_Init;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * File_Upload Class.
 *
 * @since 2.6.0
 */
class File_Upload {
	/**
	 * Private upload subdirectory name.
	 *
	 * @var string
	 */
	public static $upload_dir = 'sureforms-private';

	/**
	 * Download URL endpoint slug.
	 *
	 * @var string
	 */
	public static $download_slug = 'sureforms-download';

	/**
	 * Subfolder within UPLOAD_DIR where signature images are stored.
	 *
	 * @var string
	 */
	public static $signature_subdir = 'signature';

	/**
	 * Register file upload related hooks.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public static function file_upload_hooks() {
		add_filter( 'srfm_entry_value', [ self::class, 'transform_upload_urls' ], 10, 2 );
		add_action( 'srfm_pro_before_deleting_entry', [ self::class, 'delete_entry_files' ] );

		// Transform upload URLs in {all_data} smart tag email rendering.
		add_action( 'srfm_before_processing_all_data_field', [ self::class, 'render_upload_field_in_all_data_email' ] );
		add_filter( 'srfm_all_data_field_row', [ self::class, 'should_skip_upload_field_row_in_email' ], 10, 2 );

		// Transform upload URLs in default webhook submission data (no custom data filters).
		// `accepted_args = 3` to receive the optional `$form_id` passed by webhooks.php.
		add_filter( 'srfm_webhook_submission_data', [ self::class, 'transform_upload_urls_in_webhook_data' ], 10, 3 );

		// START: rewrite private upload URLs in label-keyed prepared submission data.
		// Covers downstream consumers of `srfm_form_submit` (OttoKit/SureTriggers, Zapier, etc.)
		// that receive `$modified_message` produced by `Form_Submit::prepare_submission_data()`.
		add_filter( 'srfm_update_prepared_submission_data', [ self::class, 'rewrite_private_upload_urls_in_prepared_data' ] );
		// END: rewrite private upload URLs in label-keyed prepared submission data.

		// Persist synchronous cloud-upload records onto the entry as it is created
		// (the entry id is unknown while files are uploaded during form processing).
		if ( class_exists( '\SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Handler' ) ) {
			add_filter(
				'srfm_before_entry_data',
				[ \SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Handler::get_instance(), 'persist_sync_records' ],
				10,
				2
			);
		}

		// Handle download immediately during init (before WP routing/404 logic).
		// This is called during init via on_plugin_init(), so if the URI matches,
		// the file is served and execution exits before WordPress processes the request.
		self::handle_file_download();
	}

	/**
	 * Delete all uploaded and signature files associated with an entry on deletion.
	 *
	 * Handles both upload fields (value is an array of file URLs) and signature fields
	 * (value is a single file URL string). For each file, the private directory is tried
	 * first and falls back to the legacy public directory for old entries.
	 *
	 * @param array<mixed> $entry Entry data.
	 * @since 2.6.0
	 * @return void
	 */
	public static function delete_entry_files( $entry ) {
		if ( empty( $entry ) || empty( $entry['form_data'] ) || ! is_array( $entry['form_data'] ) ) {
			return;
		}

		foreach ( $entry['form_data'] as $field_name => $value ) {
			// Handle upload fields — value is an array of file URLs.
			if ( false !== strpos( $field_name, 'srfm-upload' ) && \is_array( $value ) ) {
				foreach ( $value as $file_url ) {
					if ( empty( $file_url ) || ! \is_string( $file_url ) ) {
						continue;
					}
					// Try private directory first, fall back to legacy public directory.
					if ( ! self::delete_file( $file_url ) ) {
						Pro_Helper::delete_upload_file_from_subdir( $file_url, 'sureforms/' );
					}
				}
				continue;
			}

			// Handle signature fields — value is a single file URL string.
			if ( false !== strpos( $field_name, 'srfm-signature' ) && \is_string( $value ) && ! empty( $value ) ) {
				// Try private signature directory first, fall back to legacy public directory.
				if ( ! self::delete_signature_file( $value ) ) {
					Pro_Helper::delete_upload_file_from_subdir( $value, 'sureforms/signature/' );
				}
			}
		}
	}

	/**
	 * Handle file download requests.
	 *
	 * Called directly during init to intercept download requests before
	 * WordPress routing runs. Parses the request URI for the format:
	 * sureforms-download/{encoded-filename}/{form-id}/
	 *
	 * Security note — intentionally no nonce verification:
	 * Download URLs are embedded in emails (notifications, confirmations) and stored
	 * in entry data. These URLs must remain valid indefinitely — recipients may click
	 * them days, weeks, or months after the form submission. WordPress nonces expire
	 * after 24 hours (or on logout), which would break all previously sent email links
	 * and saved entry download URLs. Instead, access control is enforced by:
	 *  1. Base64-encoded filenames with randomized components (not guessable).
	 *  2. Block-level permission checks via `resolve_file_access()` — validates
	 *     the current user's role against the form's `protectFile`/`allowedUsers` settings.
	 *  3. Strict filename validation preventing path traversal and unauthorized access.
	 *  4. Admin capability checks (`manage_options`) as a bypass for administrators.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public static function handle_file_download() {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';

		if ( empty( $request_uri ) ) {
			return;
		}

		// Step 1: Strict URI verification before any processing.
		$verification = self::verify_download_request_uri( $request_uri );

		if ( ! $verification['valid'] ) {
			return;
		}

		$encoded_filename = isset( $verification['encoded_filename'] ) && is_string( $verification['encoded_filename'] ) ? $verification['encoded_filename'] : '';
		$form_id          = isset( $verification['form_id'] ) && is_numeric( $verification['form_id'] ) ? absint( $verification['form_id'] ) : 0;

		if ( empty( $encoded_filename ) ) {
			return;
		}

		$filename = Pro_Helper::srfm_base64_decode( $encoded_filename );

		if ( ! $filename ) {
			wp_die( esc_html__( 'Invalid file request.', 'sureforms-pro' ), '', [ 'response' => 400 ] );
		}

		// Legacy URLs decode to a relative path (e.g. "sureforms/img-1-1.jpg").
		// Serve them directly from the uploads directory without access control.
		if ( self::is_modified_backward_url( $filename, $form_id ) ) {
			self::stream_legacy_file( $filename );
			return;
		}

		// Step 2: Strict filename validation (Path Traversal Protection + Extension Whitelist).
		$validation = self::validate_filename_strict( $filename );

		if ( ! $validation['valid'] ) {
			/**
			 * Fires when a decoded download filename fails strict validation.
			 *
			 * The user-facing response is intentionally generic; this hook exposes the
			 * specific internal reason (empty name, separators, "..", control bytes, no
			 * extension, disallowed extension, too long) so site owners and support can
			 * log and diagnose rejected downloads without reproducing from the raw URL.
			 *
			 * @since 2.12.3
			 * @param string $filename The decoded filename that failed validation.
			 * @param string $reason   Internal validation failure reason.
			 */
			do_action( 'srfm_pro_download_filename_rejected', $filename, $validation['error'] ?? '' );

			wp_die(
				esc_html__( 'Invalid filename format.', 'sureforms-pro' ),
				'',
				[ 'response' => 400 ]
			);
		}

		// Reject a tampered trailing form ID before touching the filesystem.
		//
		// The physical file is resolved from the decoded filename below, while the
		// block-level permission set is loaded from the form ID. Those are two
		// independent inputs, so a request that keeps a valid encoded filename but
		// swaps the trailing form ID would resolve the real file while loading a
		// different form's configuration — where the filename's block ID cannot
		// exist, and the lookup therefore fell through to "no restriction".
		// generate_file_name() embeds the owning form ID in the name, so the two
		// must agree; a mismatch can only come from a hand-edited URL.
		$filename_form_id = self::get_form_id_from_filename( $filename );

		if ( self::is_form_id_mismatch( $filename, $form_id ) ) {
			/**
			 * Fires when a download request's trailing form ID does not match the
			 * form ID embedded in the encoded filename.
			 *
			 * @since 2.12.3
			 * @param string $filename         The decoded filename.
			 * @param int    $form_id          Form ID supplied in the request URL.
			 * @param int    $filename_form_id Form ID embedded in the filename.
			 */
			do_action( 'srfm_pro_download_form_id_mismatch', $filename, $form_id, $filename_form_id );

			wp_die( esc_html__( 'You do not have permission to access this file.', 'sureforms-pro' ), '', [ 'response' => 403 ] );
		}

		// Use the decoded, validated filename VERBATIM for path resolution. The download
		// token is built from basename() of the stored URL, which is the exact name written
		// to disk by upload_file() — token name == disk name, always. Re-running
		// sanitize_file_name() here would MUTATE names that are not fixed points of the
		// sanitizer (e.g. a stored "cv--{random}..." collapses to "cv-{random}...") and the
		// realpath() lookup below would then miss the real file -> bogus 404. For every name
		// the sanitizer leaves unchanged this was a no-op, so removing it cannot break any
		// previously-working download. Path safety is already enforced: Checks 2/3/4 in
		// validate_filename_strict() ban "/", "\", "..", and control bytes, and the
		// realpath() containment + file_exists() checks below are the final authority.
		$get_block_type = self::get_block_type_from_filename( $filename );

		if ( 'signature' === $get_block_type ) {
			$filename = '/signature/' . $filename;
		}

		$file_path = trailingslashit( self::get_upload_dir_path() ) . $filename;

		// Security: ensure the resolved path is within the upload directory.
		$real_file_path = realpath( $file_path );
		$real_base_path = realpath( self::get_upload_dir_path() );

		// trailingslashit() on the base: without a trailing separator the prefix test also
		// accepts a sibling directory whose name merely starts with the base, e.g.
		// `…/sureforms-private-backup/x.pdf`. Not reachable today because $filename cannot
		// contain a slash, but this makes the containment correct rather than incidental.
		if ( ! $real_file_path || ! $real_base_path || strpos( $real_file_path, trailingslashit( $real_base_path ) ) !== 0 ) {
			wp_die( esc_html__( 'File not found.', 'sureforms-pro' ), '', [ 'response' => 404 ] );
		}

		if ( ! file_exists( $real_file_path ) ) {
			wp_die( esc_html__( 'File not found.', 'sureforms-pro' ), '', [ 'response' => 404 ] );
		}

		// Re-derive the name from the file that actually resolved on disk, not the request
		// bytes. On a case-insensitive filesystem (Windows/IIS, macOS APFS/HFS+, SMB) or via
		// an NTFS 8.3 short-name alias, the request can present a casing/alias that resolves
		// the real file through realpath() yet misses the exact _srfm_block_config key — or
		// collapses the name below 5 segments so it reads as "no block, serve public". Binding
		// the policy lookup to basename( realpath ) — the canonical stored name — means the
		// permission set is always the one for the exact bytes being streamed.
		$canonical_filename = basename( $real_file_path );
		$access             = self::resolve_file_access( $canonical_filename, $form_id );

		// Admins always have access. All other roles are checked against block-level permissions.
		if ( ! $access['allowed'] ) {
			wp_die( esc_html__( 'You do not have permission to access this file.', 'sureforms-pro' ), '', [ 'response' => 403 ] );
		}

		// Determine MIME type and stream the file. Include the extra upload types so
		// files accepted at upload (e.g. ".stl") resolve a MIME type here too.
		$filetype = wp_check_filetype( $real_file_path, self::get_download_allowed_mimes() );

		if ( empty( $filetype['type'] ) ) {
			wp_die( esc_html__( 'Invalid file type.', 'sureforms-pro' ), '', [ 'response' => 403 ] );
		}

		// $access['protected'] suppresses shared-cache storage for role-restricted
		// files — see File_Streamer::set_header().
		$streamer = new File_Streamer( $real_file_path, $filetype['type'], 102400, $access['protected'] );
		$streamer->start();
	}

	/**
	 * Transform real upload URLs to secure download URLs for upload fields.
	 *
	 * Converts: http://site.com/wp-content/uploads/sureforms-private/img-3-gD9WCO2v-19.jpg
	 * To:       http://site.com/sureforms-download/{base64-encoded-filename}/19/
	 *
	 * @param mixed        $value   The entry field value.
	 * @param array<mixed> $context Context array with field_name, label, field_block_name.
	 * @since 2.6.0
	 * @return mixed Modified value with download URLs for upload fields.
	 */
	public static function transform_upload_urls( $value, $context ) {
		if ( empty( $context['field_block_name'] ) || 'srfm-upload' !== $context['field_block_name'] ) {
			return $value;
		}

		if ( ! is_array( $value ) ) {
			return $value;
		}

		$transformed = [];
		foreach ( $value as $encoded_url ) {
			if ( empty( $encoded_url ) || ! is_string( $encoded_url ) ) {
				$transformed[] = $encoded_url;
				continue;
			}

			$transformed[] = self::get_download_url( $encoded_url );
		}

		return $transformed;
	}

	/**
	 * Transform upload field URLs to secure download URLs in webhook submission data.
	 *
	 * Hooked to `srfm_webhook_submission_data`. Webhook payloads built without custom
	 * data filters bypass the per-field `srfm_entry_value` filter, so raw private URLs
	 * would otherwise leak into webhook bodies. This callback walks the original form
	 * data for upload-block keys, derives the matching slug used in
	 * `Helper::map_slug_to_submission_data`, and replaces each value with its secure
	 * download URL.
	 *
	 * Notes for maintainers:
	 * - The `srfm-upload-` prefix is the block-type prefix and is reserved for the
	 *   upload field at the registration layer. No other block type can produce a
	 *   key starting with this prefix, so a `strpos === 0` check is sufficient.
	 * - Repeater inner blocks are restricted to a fixed whitelist (input, email,
	 *   textarea, number, url, phone, date-picker, time-picker, dropdown) — upload
	 *   is not allowed inside a repeater, so nested handling is intentionally
	 *   omitted.
	 * - `self::get_download_url()` validates URL shape internally (decodes,
	 *   short-circuits via `is_backward_compatible_url`, and falls through to the
	 *   legacy handler for non-private URLs), so an upstream input check would
	 *   only duplicate that work.
	 * - Slug derivation is delegated to `Helper::map_slug_to_submission_data` so
	 *   any future change to the canonical derivation flows through automatically
	 *   instead of drifting out of sync with this method's inline logic.
	 * - Webhook trigger conditions (`Webhooks::process_logic`) evaluate AFTER this
	 *   filter runs — condition rules should be authored against the
	 *   `sureforms-download` URL form, not the pre-transform private path.
	 *
	 * Expected shapes:
	 * - $submission_data: array<string,mixed> — mapped slug => value pairs.
	 * - $form_data:       array<string,mixed> — original keys including the
	 *   `srfm-{type}-{block_id}-lbl-{label}` prefix.
	 * - $form_id:         int — provided by the filter for callbacks that need it,
	 *   currently unused here but accepted for API stability.
	 *
	 * @param mixed $submission_data Mapped slug => value pairs.
	 * @param mixed $form_data       Original form data with full block-type-prefixed keys.
	 * @param mixed $form_id         Form ID (currently unused).
	 * @since 2.9.0
	 * @return mixed
	 */
	public static function transform_upload_urls_in_webhook_data( $submission_data, $form_data, $form_id = 0 ) {
		unset( $form_id );

		if ( ! is_array( $submission_data ) || ! is_array( $form_data ) ) {
			return $submission_data;
		}

		foreach ( $form_data as $key => $value ) {
			// Block-type-specific prefix — see header note. Reserved for the upload field.
			if ( ! is_string( $key ) || 0 !== strpos( $key, 'srfm-upload-' ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}

			// Reuse the canonical slug derivation by feeding a single-key submission
			// through `Helper::map_slug_to_submission_data`. This stays in sync if the
			// helper's logic ever changes.
			$single_mapped = \SRFM\Inc\Helper::map_slug_to_submission_data( [ $key => $value ] );
			if ( empty( $single_mapped ) || ! is_array( $single_mapped ) ) {
				continue;
			}

			$slug = (string) array_key_first( $single_mapped );
			if ( '' === $slug || empty( $submission_data[ $slug ] ) || ! is_array( $submission_data[ $slug ] ) ) {
				continue;
			}

			$submission_data[ $slug ] = array_map(
				static function ( $url ) {
					return is_string( $url ) && '' !== $url ? self::get_download_url( $url ) : $url;
				},
				$submission_data[ $slug ]
			);
		}

		return $submission_data;
	}

	// START: rewrite_private_upload_urls_in_prepared_data.
	/**
	 * Rewrite raw `sureforms-private/` URLs in the label-keyed prepared submission data.
	 *
	 * Hooked to `srfm_update_prepared_submission_data` (fired in
	 * `Form_Submit::prepare_submission_data()`). The resulting `$modified_message` is
	 * the payload broadcast on `srfm_form_submit`, which is consumed by SureTriggers /
	 * OttoKit, Zapier dispatch, and any third-party listener. None of those paths run
	 * the slug-keyed `srfm_webhook_submission_data` filter, so without this rewrite
	 * they receive private storage URLs that are blocked by `.htaccess`.
	 *
	 * Thin wrapper around {@see self::rewrite_private_urls_in_array()} that guards
	 * non-array input from the filter pipeline.
	 *
	 * @param mixed $modified_message Label-keyed submission data from `prepare_submission_data()`.
	 * @since 2.10.0
	 * @return mixed Modified message with private URLs rewritten where applicable.
	 */
	public static function rewrite_private_upload_urls_in_prepared_data( $modified_message ) {
		if ( ! is_array( $modified_message ) ) {
			return $modified_message;
		}
		return self::rewrite_private_urls_in_array( $modified_message );
	}
	// END: rewrite_private_upload_urls_in_prepared_data.

	/**
	 * Recursively rewrite raw `sureforms-private/` URLs inside an array payload.
	 *
	 * Shared walker used by both filter paths that operate on label-keyed
	 * submission shapes:
	 * - {@see self::rewrite_private_upload_urls_in_prepared_data()} on the
	 *   `srfm_update_prepared_submission_data` filter (primary path).
	 * - {@see \SRFM_Pro\Inc\Pro\Zapier::rewrite_private_upload_urls_for_zapier()}
	 *   as a defense-in-depth safeguard on the Zapier dispatch payload.
	 *
	 * Heuristic: walk the array recursively, inspecting string values only. Each
	 * string is treated as a list of URLs joined by `, ` (the format used in
	 * `Form_Submit::prepare_submission_data` for multi-file uploads); each part
	 * is tested in isolation. A part is rewritten only when it (a) is a valid
	 * URL and (b) contains the private upload base URL — preserving any
	 * free-form text that happens to mention `sureforms-private` or any non-URL
	 * value. Signature URLs live under the `signature/` subdirectory and route
	 * through {@see Signature_Init::get_download_url()}; everything else routes
	 * through {@see self::get_download_url()}. Both converters are idempotent,
	 * so downstream filters re-applying the same logic are safe.
	 *
	 * @param array<int|string,mixed> $data Submission data array.
	 * @since 2.10.0
	 * @return array<int|string,mixed> Array with private URLs rewritten where applicable.
	 */
	public static function rewrite_private_urls_in_array( $data ) {
		$upload_dir = wp_upload_dir();
		$base_url   = isset( $upload_dir['baseurl'] ) && is_string( $upload_dir['baseurl'] )
			? trailingslashit( $upload_dir['baseurl'] ) . self::$upload_dir
			: '';

		if ( '' === $base_url ) {
			return $data;
		}

		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				$data[ $key ] = self::rewrite_private_urls_in_array( $value );
				continue;
			}

			if ( ! is_string( $value ) || false === strpos( $value, $base_url ) ) {
				continue;
			}

			$parts = array_map(
				static function ( $part ) use ( $base_url ) {
					$trimmed = trim( $part );
					if ( '' === $trimmed || false === strpos( $trimmed, $base_url ) ) {
						return $part;
					}
					if ( ! filter_var( $trimmed, FILTER_VALIDATE_URL ) ) {
						return $part;
					}
					// Signature files live in the `signature/` subdirectory and have
					// their own download-URL builder. Everything else routes through
					// the upload-field builder.
					if ( false !== strpos( $trimmed, '/' . self::$upload_dir . '/' . self::$signature_subdir . '/' ) ) {
						return Signature_Init::get_download_url( $trimmed );
					}
					return self::get_download_url( $trimmed );
				},
				explode( ', ', $value )
			);

			$data[ $key ] = implode( ', ', $parts );
		}

		return $data;
	}

	/**
	 * Render upload field rows with secure download URLs in the {all_data} email section.
	 *
	 * Hooked to `srfm_before_processing_all_data_field`. The core email template renders
	 * upload file URLs as-is (raw storage URLs). This method replaces that rendering by
	 * outputting the same HTML structure but with URLs transformed to secure download URLs.
	 * The default row is then skipped via `should_skip_upload_field_row_in_email()`.
	 *
	 * @param array<string,mixed> $args {
	 *     Field data passed by the action.
	 *
	 *     @type mixed  $value           The field value (array of file URLs for uploads).
	 *     @type string $label           The field name/key.
	 *     @type string $block_name      The block type identifier.
	 *     @type string $processed_label The decrypted human-readable label.
	 * }
	 * @since 2.6.0
	 * @return void
	 */
	public static function render_upload_field_in_all_data_email( $args ) {
		if ( empty( $args['block_name'] ) || 'srfm-upload' !== $args['block_name'] ) {
			return;
		}

		if ( empty( $args['value'] ) || ! \is_array( $args['value'] ) ) {
			return;
		}

		$td_style    = 'font-weight: 500;font-size: 14px;line-height: 20px;padding: 12px;text-align:left;word-break: break-word;border-bottom: 1px solid #E5E7EB;';
		$field_label = isset( $args['processed_label'] ) && is_string( $args['processed_label'] ) ? $args['processed_label'] : '';

		// Transform raw file URLs to secure download URLs.
		$clean_values = [];
		foreach ( $args['value'] as $file_url ) {
			$file_url = \SRFM\Inc\Helper::get_string_value( $file_url );
			if ( ! empty( $file_url ) && \is_string( $file_url ) ) {
				$clean_values[] = self::get_download_url( $file_url );
			}
		}

		if ( empty( $clean_values ) ) {
			return;
		}

		?>
		<tr class="field-label">
			<th style="<?php echo esc_attr( $td_style ); ?>color: #1E293B;background-color: #F1F5F9;">
				<?php // The label is decoded from the submitted field key, so it is attacker-controllable — escape it as text, never as markup. ?>
				<strong><?php echo esc_html( html_entity_decode( $field_label ) ); ?>:</strong>
			</th>
		</tr>
		<tr class="field-value">
			<td style="<?php echo esc_attr( $td_style ); ?>color: #475569;">
			<?php
			if ( count( $clean_values ) === 1 ) {
				$download_url = reset( $clean_values );
				?>
				<a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $download_url ); ?>">
					<?php echo esc_html( urldecode( $download_url ) ); ?>
				</a>
				<?php
			} else {
				?>
				<ol style="list-style: decimal; padding-left: 20px; margin: 0;">
					<?php foreach ( $clean_values as $download_url ) { ?>
						<li style="margin-bottom: 6px;">
							<a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $download_url ); ?>">
								<?php echo esc_html( urldecode( $download_url ) ); ?>
							</a>
						</li>
					<?php } ?>
				</ol>
				<?php
			}
			?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Skip the default email row rendering for upload fields in {all_data}.
	 *
	 * Since `render_upload_field_in_all_data_email()` already outputs the upload
	 * field rows with secure download URLs, this filter prevents the core email
	 * template from rendering the same field again with raw storage URLs.
	 *
	 * @param bool         $should_add_field_row Whether the field row should be added.
	 * @param array<mixed> $args                 Arguments containing field information.
	 * @since 2.6.0
	 * @return bool
	 */
	public static function should_skip_upload_field_row_in_email( $should_add_field_row, $args ) {
		if ( isset( $args['block_name'] ) && 'srfm-upload' === $args['block_name'] ) {
			return false;
		}

		return $should_add_field_row;
	}

	/**
	 * Determine whether a file URL uses the legacy (pre-2.5.0) public storage path.
	 *
	 * New files are stored in the protected /uploads/sureforms-private/ directory.
	 * Old files lived in the public /uploads/sureforms/ directory (no access control).
	 * If the URL does not contain the private directory segment it is considered a
	 * backward-compatible (legacy) URL.
	 *
	 * @param string $url The file URL to inspect.
	 * @since 2.6.0
	 * @return bool True if the URL is a legacy (non-private) file URL.
	 */
	public static function is_backward_compatible_url( $url ) {
		return false === strpos( $url, '/' . self::$upload_dir . '/' );
	}

	/**
	 * Convert a real file URL (possibly URL-encoded) to a secure download URL.
	 *
	 * @param string $file_url The real file URL (may be URL-encoded).
	 * @since 2.6.0
	 * @return string The secure download URL.
	 */
	public static function get_download_url( $file_url ) {
		$decoded_url = rawurldecode( $file_url );

		// External (cloud storage) URL — a file uploaded directly to a third-party
		// provider during submission. It is not under the WordPress uploads directory,
		// so leave it untouched instead of rewriting it into a (broken) local
		// /sureforms-download/ URL. Compare by path (host-agnostic).
		$srfm_upload_dir = wp_upload_dir();
		$srfm_base_url   = isset( $srfm_upload_dir['baseurl'] ) && is_string( $srfm_upload_dir['baseurl'] ) ? $srfm_upload_dir['baseurl'] : '';
		$srfm_base_path  = '' !== $srfm_base_url ? \SRFM\Inc\Helper::get_string_value( wp_parse_url( $srfm_base_url, PHP_URL_PATH ) ) : '';
		$srfm_url_path   = \SRFM\Inc\Helper::get_string_value( wp_parse_url( $decoded_url, PHP_URL_PATH ) );
		if (
			'' !== $srfm_base_path
			&& false === strpos( $srfm_url_path, $srfm_base_path )
			&& false === strpos( $decoded_url, '/' . self::$download_slug . '/' )
		) {
			return $decoded_url;
		}

		// Idempotency guard: if the URL already points at the secure download
		// handler, return it unchanged. Prevents double-encoding when the same
		// value flows through this method twice (e.g. a future code path or a
		// third-party filter that re-applies `srfm_webhook_submission_data`).
		if ( false !== strpos( $decoded_url, '/' . self::$download_slug . '/' ) ) {
			return $decoded_url;
		}

		// Route legacy URLs through the backward-compatible handler.
		if ( self::is_backward_compatible_url( $decoded_url ) ) {
			return self::get_backward_compatible_download_url( $decoded_url );
		}

		$filename = basename( $decoded_url );

		// Extract form ID from filename format: {name}-{random-id}-{form-id}.{ext}.
		$name_without_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$parts            = explode( '-', $name_without_ext );
		$form_id          = end( $parts );

		$encoded_filename = Pro_Helper::srfm_base64_encode( $filename );

		return home_url( self::$download_slug . '/' . $encoded_filename . '/' . $form_id . '/' );
	}

	/**
	 * Generate a secure file name in the format: {original-name}-{random-id}-{type}-{block-id}-{form-id}.{extension}
	 *
	 * @param string $original_filename The original uploaded file name.
	 * @param int    $form_id The form ID.
	 * @param string $field The field key (format: srfm-{type}-{block_id}-lbl-{label}).
	 * @since 2.6.0
	 * @return string The generated file name.
	 */
	public static function generate_file_name( $original_filename, $form_id, $field ) {
		$sanitized_name   = sanitize_file_name( $original_filename );
		$extension        = pathinfo( $sanitized_name, PATHINFO_EXTENSION );
		$name_without_ext = pathinfo( $sanitized_name, PATHINFO_FILENAME );
		$random_id        = strtolower( wp_generate_password( 8, false ) );

		// Extract block type and block ID from field key (format: srfm-{type}-{block_id}-lbl-{label}).
		$type_with_prefix = Pro_Helper::get_field_type_from_key_with_srfm( $field );
		$block_type       = $type_with_prefix ? str_replace( 'srfm-', '', $type_with_prefix ) : '';
		$block_id         = Pro_Helper::get_block_id( $field );

		// Re-sanitize the FINAL assembled name. sanitize_file_name() is applied to the
		// original above, but the extension is then stripped via pathinfo() and the parts
		// are re-joined with "-". If the sanitized base ends in a separator (e.g. an
		// original like "my file -.pdf" sanitizes to "my-file-.pdf", whose base keeps the
		// trailing "-" because the trailing trim only sees ".pdf" at the very end), joining
		// "-{random_id}" produces a double hyphen "--". sanitize_file_name() collapses "--"
		// to "-", so an un-sanitized assembled name would NOT be a fixed point of
		// sanitize_file_name() and would later be rejected by validate_filename_strict()
		// with "Invalid filename format." Sanitizing the whole result guarantees the stored
		// name is a fixed point.
		return sanitize_file_name( $name_without_ext . '-' . $random_id . '-' . $block_type . '-' . $block_id . '-' . absint( $form_id ) . '.' . $extension );
	}

	/**
	 * Extract the form ID from a generated filename.
	 *
	 * Filename format: {name}-{random_id}-{type}-{block_id}-{form_id}.{extension}
	 * Example: "img-1-fufrf8xc-upload-cbc7612b-19.jpg" => returns 19.
	 *
	 * @param string $filename The filename (with or without extension).
	 * @since 2.6.0
	 * @return int Form ID, or 0 if not found.
	 */
	public static function get_form_id_from_filename( $filename ) {
		$name_without_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$parts            = explode( '-', $name_without_ext );

		if ( \count( $parts ) < 5 ) {
			return 0;
		}

		$form_id = end( $parts );
		return is_numeric( $form_id ) ? absint( $form_id ) : 0;
	}

	/**
	 * Extract the block ID from a generated filename.
	 *
	 * Filename format: {name}-{random_id}-{type}-{block_id}-{form_id}.{extension}
	 * Example: "img-1-fufrf8xc-upload-cbc7612b-19.jpg" => returns "cbc7612b".
	 *
	 * @param string $filename The filename (with or without extension).
	 * @since 2.6.0
	 * @return string Block ID, or empty string if not found.
	 */
	public static function get_block_id_from_filename( $filename ) {
		$name_without_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$parts            = explode( '-', $name_without_ext );

		if ( \count( $parts ) < 5 ) {
			return '';
		}

		// Second-to-last segment is the block ID.
		return $parts[ \count( $parts ) - 2 ];
	}

	/**
	 * Extract the block type from a generated filename.
	 *
	 * Filename format: {name}-{random_id}-{type}-{block_id}-{form_id}.{extension}
	 * Example: "img-1-fufrf8xc-upload-cbc7612b-19.jpg" => returns "upload".
	 * Example: "sig-fufrf8xc-signature-cbc7612b-19.png" => returns "signature".
	 *
	 * @param string $filename The filename (with or without extension).
	 * @since 2.6.0
	 * @return string Block type (e.g. "upload", "signature"), or empty string if not found.
	 */
	public static function get_block_type_from_filename( $filename ) {
		$name_without_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$parts            = explode( '-', $name_without_ext );

		if ( \count( $parts ) < 5 ) {
			return '';
		}

		// Third-to-last segment is the block type.
		return $parts[ \count( $parts ) - 3 ];
	}

	/**
	 * Get the full path to the private upload directory.
	 *
	 * @since 2.6.0
	 * @return string Full directory path.
	 */
	public static function get_upload_dir_path() {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . self::$upload_dir;
	}

	/**
	 * Get the base URL for the private upload directory.
	 *
	 * @since 2.6.0
	 * @return string Base URL.
	 */
	public static function get_upload_dir_url() {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['baseurl'] ) . self::$upload_dir;
	}

	/**
	 * Create the private upload directory and .htaccess protection if they don't exist.
	 *
	 * @param string $dir_path Full path to the upload directory.
	 * @since 2.6.0
	 * @return void
	 */
	public static function maybe_create_upload_dir( $dir_path ) {
		if ( ! file_exists( $dir_path ) ) {
			wp_mkdir_p( $dir_path );
		}

		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();

		if ( ! $wp_filesystem instanceof \WP_Filesystem_Base ) {
			return;
		}

		$dir_path_trailing = trailingslashit( $dir_path );

		// .htaccess blocks direct access on Apache/LiteSpeed servers.
		$htaccess_path = $dir_path_trailing . '.htaccess';
		if ( ! file_exists( $htaccess_path ) ) {
			$wp_filesystem->put_contents( $htaccess_path, "Order Allow,Deny\nDeny from all\n", FS_CHMOD_FILE );
		}

		// index.php prevents directory listing and provides a minimal fallback
		// on non-Apache servers (Nginx, IIS, Caddy) that ignore .htaccess.
		// This follows the standard WordPress pattern used in wp-content/uploads/.
		// Note: Full protection on Nginx requires a server-level deny rule in
		// the Nginx config (e.g. location ~* /sureforms-private/ { deny all; }).
		$index_path = $dir_path_trailing . 'index.php';
		if ( ! file_exists( $index_path ) ) {
			$wp_filesystem->put_contents( $index_path, "<?php\n// Silence is golden.\n", FS_CHMOD_FILE );
		}
	}

	/**
	 * Process and upload a single file to the private upload directory.
	 *
	 * @param array<string,mixed> $file_data Single file data array with keys: name, type, tmp_name, error, size.
	 * @param int                 $form_id   The form ID.
	 * @param string              $field     The field name.
	 * @since 2.6.0
	 * @return string|false The uploaded file URL on success, false on failure.
	 */
	public static function upload_file( $file_data, $form_id, $field ) {
		// Require a real block id on the upload field. An extra multipart part named
		// e.g. "srfm-upload--lbl-x" passes the field-type gate but yields an EMPTY block
		// id, so generate_file_name() produces a name that collapses below 5 segments —
		// which get_block_id_from_filename() then reads as "no block id", so
		// resolve_file_access() treats the file as public (the retained fail-open at
		// download time). Rejecting the empty-block-id upload closes that at the source.
		//
		// Note: we intentionally do NOT additionally require the id to be a key of
		// _srfm_block_config — that meta is sparse (only blocks needing extra validation:
		// dropdown/payment/multi-choice/number/textarea) and does NOT contain plain
		// upload fields, so an isset() check there would reject every legitimate upload.
		// A fabricated NON-empty id is already handled at download: resolve_file_access()
		// now fails closed when the id is absent from the form's config.
		if ( '' === Pro_Helper::get_block_id( $field ) ) {
			return '';
		}

		$dir_path = self::get_upload_dir_path();

		// Ensure directory and .htaccess exist.
		self::maybe_create_upload_dir( $dir_path );

		$file_name = isset( $file_data['name'] ) && is_string( $file_data['name'] ) ? $file_data['name'] : '';

		$new_filename = self::generate_file_name( $file_name, $form_id, $field );
		$target_path  = trailingslashit( $dir_path ) . $new_filename;

		$file_temp_name = isset( $file_data['tmp_name'] ) && is_string( $file_data['tmp_name'] ) ? $file_data['tmp_name'] : '';

		// Validate the file type using WordPress file type checking.
		$wp_filetype = wp_check_filetype_and_ext( $file_temp_name, $new_filename );
		if ( ! $wp_filetype['type'] ) {
			return false;
		}

		// Move the uploaded file to the target directory.
		//
		// `move_uploaded_file()` is intentionally used (not a $wp_filesystem
		// move): this method is only ever fed entries from the PHP `$_FILES`
		// superglobal (see Hooks::add_upload_files_to_form_data), so the temp
		// file is always a genuine multipart HTTP upload. `move_uploaded_file()`
		// additionally verifies that `$file_temp_name` was uploaded via HTTP
		// POST, which is a security guarantee a plain rename/copy would lose.
		if ( ! move_uploaded_file( $file_temp_name, $target_path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return false;
		}

		// Set correct file permissions, mirroring the parent directory's
		// read/write bits. Routed through WP_Filesystem for WPCS compliance
		// (the upload dir / WP_Filesystem is already bootstrapped above via
		// maybe_create_upload_dir()).
		global $wp_filesystem;
		if ( $wp_filesystem instanceof \WP_Filesystem_Base ) {
			$dir_perms = $wp_filesystem->getchmod( dirname( $target_path ) );
			if ( '' !== $dir_perms ) {
				// getchmod() returns an octal string (e.g. "0755"); keep the
				// read/write bits and apply them to the uploaded file.
				$perms = intval( $dir_perms, 8 ) & 0000666;
				$wp_filesystem->chmod( $target_path, $perms );
			}
		}

		return trailingslashit( self::get_upload_dir_url() ) . $new_filename;
	}

	/**
	 * Delete uploaded file from the private upload subdirectory.
	 *
	 * @param string $file_url The file URL to delete.
	 * @since 2.6.0
	 * @return bool True on success, false on failure.
	 */
	public static function delete_file( $file_url ) {
		return Pro_Helper::delete_upload_file_from_subdir( $file_url, self::$upload_dir . '/' );
	}

	/**
	 * Strictly validate filename for security.
	 *
	 * Performs comprehensive validation to prevent path traversal, injection attacks,
	 * and unauthorized file access. Checks:
	 * - No directory separators (/, \)
	 * - No path traversal patterns (.., .)
	 * - No null bytes or special characters
	 * - Valid file extension from allowed list
	 * - Proper filename format
	 *
	 * @param string $filename The filename to validate.
	 * @since 2.6.0
	 * @return array{valid: bool, error?: string, extension?: string} Validation result.
	 */
	public static function validate_filename_strict( $filename ) {
		// Check 1: Filename must not be empty.
		if ( empty( $filename ) || ! is_string( $filename ) ) {
			return [
				'valid' => false,
				'error' => 'Filename is empty or invalid',
			];
		}

		// Check 2: No directory separators (path traversal prevention).
		if ( false !== strpos( $filename, '/' ) || false !== strpos( $filename, '\\' ) ) {
			return [
				'valid' => false,
				'error' => 'Filename contains directory separators',
			];
		}

		// Check 3: No path traversal patterns.
		if ( false !== strpos( $filename, '..' ) || '.' === $filename ) {
			return [
				'valid' => false,
				'error' => 'Filename contains path traversal patterns',
			];
		}

		// Check 4: No null bytes or dangerous special characters.
		if ( preg_match( '/[\x00-\x1F\x7F]/', $filename ) ) {
			return [
				'valid' => false,
				'error' => 'Filename contains null bytes or control characters',
			];
		}

		// Check 5: Must have an extension.
		$extension = pathinfo( $filename, PATHINFO_EXTENSION );
		if ( empty( $extension ) ) {
			return [
				'valid' => false,
				'error' => 'Filename has no extension',
			];
		}

		// Check 6: Validate extension using WordPress built-in function.
		// wp_check_filetype() checks against WordPress allowed mime types, extended with
		// the extra types uploads accept (see get_download_allowed_mimes()) so a file
		// that upload permitted is never rejected at download.
		$file_type = wp_check_filetype( $filename, self::get_download_allowed_mimes() );

		if ( ! $file_type['ext'] || ! $file_type['type'] ) {
			return [
				'valid'     => false,
				'error'     => 'File extension not allowed by WordPress',
				'extension' => strtolower( $extension ),
			];
		}

		$extension_lower = strtolower( $extension );

		// NOTE - former Check 7 (comparing the filename against sanitize_file_name()) was
		// removed deliberately. It asserted that every stored name must be a fixed point of
		// sanitize_file_name(), a premise that caused FOUR recurrences of the same
		// "Invalid filename format." bug: internal dots (PR #1343), non-ASCII / "@" / "^"
		// (2.12.2), double hyphens from separator-suffixed uploads ("my file -.pdf"), and it
		// would next fail on any legacy stored name containing a character the sanitizer
		// strips ("#", "+", quotes, ...). The validator's job is SAFETY, not re-deriving how
		// the name might have been produced:
		// - traversal is blocked by Check 2 (no "/" or "\"), Check 3 (no ".."), and
		// Check 4 (no control/null bytes);
		// - policy is Check 5/6 (extension present + allowed by wp_check_filetype());
		// - the final authority is the realpath() containment + file_exists() gate in
		// handle_file_download().
		// Any name passing those and resolving to a real file inside the SureForms upload
		// dir is safe to stream. Do NOT reintroduce a sanitize_file_name() comparison here.

		// Check 8: Ensure filename is not too long (max 255 characters).
		if ( strlen( $filename ) > 255 ) {
			return [
				'valid' => false,
				'error' => 'Filename too long',
			];
		}

		// All checks passed.
		return [
			'valid'     => true,
			'extension' => $extension_lower,
		];
	}

	/**
	 * Allowed MIME types for download-path filename checks.
	 *
	 * Uploads temporarily extend the WordPress whitelist with Pro_Helper::get_extra_mimes()
	 * (the `upload_mimes` filter added in Hooks::add_upload_files_to_form_data() is removed
	 * right after the upload completes). Download-time wp_check_filetype() calls therefore run
	 * WITHOUT those extra types, so an extension uploads legitimately accept (e.g. "stl")
	 * would be rejected at download with the generic "Invalid filename format." /
	 * "Invalid file type." errors. Merge them explicitly so any file that upload permitted
	 * can always be downloaded.
	 *
	 * Unlike Hooks::add_extra_upload_mimes() (which pipes multiple MIME candidates together
	 * for upload-side verification), only the FIRST MIME of each extra extension is used
	 * here: the value ends up verbatim in the streamer's Content-Type header, where a piped
	 * list would be malformed. Extensions WordPress already allows keep their core value.
	 *
	 * @since 2.12.3
	 * @return array<string, string> MIME types keyed by extension pattern, in wp_check_filetype() format.
	 */
	private static function get_download_allowed_mimes() {
		$mimes = get_allowed_mime_types();

		foreach ( Pro_Helper::get_extra_mimes() as $ext => $mime_list ) {
			if ( ! isset( $mimes[ $ext ] ) && ! empty( $mime_list ) ) {
				$mimes[ $ext ] = (string) reset( $mime_list );
			}
		}

		return $mimes;
	}

	/**
	 * Strictly verify and parse download request URI.
	 *
	 * Validates the URL structure to prevent malformed requests, injection attacks,
	 * and unauthorized access attempts. Checks:
	 * - Contains 'sureforms-download' at correct position
	 * - Has exactly 2 or 3 path segments after slug
	 * - Form ID is numeric at expected position
	 * - No extra slashes or unexpected characters
	 *
	 * Expected format: /sureforms-download/{encoded-filename}/{form-id}/
	 * Example: /sureforms-download/c2lnbmF0dXJl.../731/
	 *
	 * @param string $request_uri The request URI to validate.
	 * @since 2.6.0
	 * @return array{valid: bool, encoded_filename?: string, form_id?: int} Validation result.
	 */
	private static function verify_download_request_uri( $request_uri ) {
		// Step 1: match the slug on the URI PATH, anchored at the start of the site path.
		//
		// Matching anywhere in the raw request URI also matched the query string, so
		// `/about/?x=sureforms-download/{b64}/77/` streamed the file and exited. With
		// Content-Disposition: inline that serves uploaded content from an arbitrary
		// same-origin path and slips past path-anchored WAF rules.
		$uri_path = \SRFM\Inc\Helper::get_string_value( wp_parse_url( $request_uri, PHP_URL_PATH ) );

		// These URLs are built with home_url(), so a subdirectory install prefixes the
		// path (`/blog/sureforms-download/…`). Strip that prefix before anchoring, or such
		// installs would stop resolving downloads entirely.
		$home_path = \SRFM\Inc\Helper::get_string_value( wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );

		if ( '' !== $home_path && '/' !== $home_path && 0 === strpos( $uri_path, $home_path ) ) {
			$uri_path = substr( $uri_path, strlen( $home_path ) );
		}

		$uri_path = ltrim( $uri_path, '/' );

		if ( 0 !== strpos( $uri_path, self::$download_slug ) ) {
			return [ 'valid' => false ];
		}

		// Step 2: Extract the path after the slug.
		$path = $uri_path;

		// Remove leading slash and slug to get: {encoded-filename}/{form-id}/ or {encoded-filename}/{form-id}.
		$path = preg_replace( '#^' . preg_quote( self::$download_slug, '#' ) . '/?#', '', $path );

		if ( empty( $path ) || ! is_string( $path ) ) {
			return [ 'valid' => false ];
		}

		// Step 3: Split by '/' and validate structure.
		// Use explicit callback to only remove empty strings — "0" is a valid form ID and must not be filtered out.
		// array_values() re-indexes after the filter. array_filter() preserves keys, so a
		// URI with a doubled separator (`/sureforms-download//abc//19/`) produced keys
		// [1, 3] — count() === 2 passed the check below and then $parts[0] raised an
		// undefined-key error, i.e. a 500 on an attacker-shaped URL. The previous comment
		// here noted this was safe only as long as the path preprocessing guaranteed
		// sequential keys; that preprocessing changed above, so re-index explicitly.
		$parts = array_values( array_filter( explode( '/', $path ), static fn( string $p ) => '' !== $p ) );

		// Should have exactly 2 parts: encoded_filename and form_id.
		if ( \count( $parts ) !== 2 ) {
			return [ 'valid' => false ];
		}

		$encoded_filename = $parts[0];
		$form_id_string   = $parts[1];

		// Step 4: Validate encoded filename (base64 characters: A-Z, a-z, 0-9, +, /, =).
		// Also allow - and _ for URL-safe base64.
		if ( ! preg_match( '/^[A-Za-z0-9+\/=_-]+$/', $encoded_filename ) ) {
			return [ 'valid' => false ];
		}

		// Step 5: Validate form ID is numeric only (no letters, special chars, or extra content).
		if ( ! preg_match( '/^\d+$/', $form_id_string ) ) {
			return [ 'valid' => false ];
		}

		// Step 6: Check for abnormal patterns (multiple consecutive slashes, null bytes, etc).
		if ( preg_match( '/\/\/|\.\.|\0/', $request_uri ) ) {
			return [ 'valid' => false ];
		}

		// All validations passed.
		return [
			'valid'            => true,
			'encoded_filename' => $encoded_filename,
			'form_id'          => intval( $form_id_string ),
		];
	}

	/**
	 * Delete a signature file from the private signature subdirectory.
	 *
	 * @param string $file_url The file URL to delete.
	 * @since 2.6.0
	 * @return bool True on success, false on failure.
	 */
	private static function delete_signature_file( $file_url ) {
		return Pro_Helper::delete_upload_file_from_subdir(
			$file_url,
			self::$upload_dir . '/' . self::$signature_subdir . '/'
		);
	}

	/**
	 * Determine whether a base64-decoded download token is a legacy relative path.
	 *
	 * Legacy download URLs encode a relative path such as "sureforms/img-1-1.jpg"
	 * (form_id segment in the URL is 0). New-format tokens are bare filenames with
	 * no directory separator. The presence of "sureforms/" is the distinguishing marker.
	 *
	 * @param string $filename The base64-decoded value from the download URL.
	 * @param int    $form_id  The form ID from the download URL (0 for legacy URLs).
	 * @since 2.6.0
	 * @return bool True if the decoded value is a legacy relative path.
	 */
	private static function is_modified_backward_url( $filename, $form_id ) {
		return 0 === $form_id && false !== strpos( $filename, 'sureforms/' );
	}

	/**
	 * Validate legacy file path for security.
	 *
	 * Legacy files can only be in two locations:
	 * - sureforms/{filename}
	 * - sureforms/signature/{filename}
	 *
	 * This function extracts the filename and validates it using strict validation
	 * to prevent path traversal and unauthorized access.
	 *
	 * @param string $relative_path Relative path from uploads base (e.g., "sureforms/img-1-1.jpg").
	 * @since 2.6.0
	 * @return bool True if valid legacy file path, false otherwise.
	 */
	private static function is_valid_legacy_file( $relative_path ) {
		// Check 1: Must start with 'sureforms/'.
		if ( 0 !== strpos( $relative_path, 'sureforms/' ) ) {
			return false;
		}

		// Check 2: Extract filename based on allowed prefixes.
		$filename = '';

		// Check for signature subdirectory first (more specific).
		if ( 0 === strpos( $relative_path, 'sureforms/signature/' ) ) {
			// Extract filename after 'sureforms/signature/'.
			$filename = substr( $relative_path, strlen( 'sureforms/signature/' ) );
		} elseif ( 0 === strpos( $relative_path, 'sureforms/' ) ) {
			// Extract filename after 'sureforms/'.
			$filename = substr( $relative_path, strlen( 'sureforms/' ) );

			// Ensure filename doesn't contain additional directory separators.
			// Legacy files should be directly in sureforms/ not in subdirectories.
			if ( false !== strpos( $filename, '/' ) ) {
				// If it contains '/', it's not a valid legacy file (unless it's signature/).
				return false;
			}
		}

		// Check 3: Validate extracted filename is not empty.
		if ( empty( $filename ) ) {
			return false;
		}

		// Check 4: Use strict filename validation (reuses existing security checks).
		$validation = self::validate_filename_strict( $filename );

		return $validation['valid'];
	}

	/**
	 * Serve a legacy (pre-2.5.0) file directly from the public uploads directory.
	 *
	 * Legacy files were stored under /uploads/sureforms/ (a publicly accessible directory)
	 * and had no access control — anyone with the direct URL could download them.
	 *
	 * Intentionally no authentication check (is_user_logged_in / capability):
	 * These files were always publicly accessible before this PR. Adding an auth
	 * gate now would silently break existing email links and saved entry URLs for
	 * all legacy submissions, since recipients (including non-logged-in users) have
	 * been accessing them without authentication. This is not a regression — the
	 * sureforms-download/ route simply replaces the previous direct URL with a
	 * validated, path-traversal-safe handler while preserving the same access level.
	 * New files (post-2.5.0) stored in sureforms-private/ are protected by
	 * `resolve_file_access()` with block-level permission checks.
	 *
	 * The relative path (e.g. "sureforms/img-1-1.jpg") is resolved against the
	 * WordPress uploads base directory and streamed without block-level permission
	 * checks, since those files predate the permission system.
	 *
	 * @param string $relative_path Relative path from uploads base, e.g. "sureforms/img-1-1.jpg".
	 * @since 2.6.0
	 * @return void
	 */
	private static function stream_legacy_file( $relative_path ) {
		// Check the valid file or not.
		$is_valid_file = self::is_valid_legacy_file( $relative_path );

		if ( ! $is_valid_file ) {
			wp_die(
				esc_html__( 'Invalid legacy file path.', 'sureforms-pro' ),
				'',
				[ 'response' => 400 ]
			);
		}

		$upload_base_dir = wp_upload_dir()['basedir'];
		$file_path       = trailingslashit( $upload_base_dir ) . ltrim( $relative_path, '/' );

		// Security: ensure the resolved path stays within the uploads base directory.
		$real_file_path = realpath( $file_path );
		$real_base_path = realpath( $upload_base_dir );

		// trailingslashit() on the base: without a trailing separator the prefix test also
		// accepts a sibling directory whose name merely starts with the base, e.g.
		// `…/sureforms-private-backup/x.pdf`. Not reachable today because $filename cannot
		// contain a slash, but this makes the containment correct rather than incidental.
		if ( ! $real_file_path || ! $real_base_path || strpos( $real_file_path, trailingslashit( $real_base_path ) ) !== 0 ) {
			wp_die( esc_html__( 'File not found.', 'sureforms-pro' ), '', [ 'response' => 404 ] );
		}

		if ( ! file_exists( $real_file_path ) ) {
			wp_die( esc_html__( 'File not found.', 'sureforms-pro' ), '', [ 'response' => 404 ] );
		}

		$filetype = wp_check_filetype( $real_file_path, self::get_download_allowed_mimes() );

		if ( empty( $filetype['type'] ) ) {
			wp_die( esc_html__( 'Invalid file type.', 'sureforms-pro' ), '', [ 'response' => 403 ] );
		}

		$streamer = new File_Streamer( $real_file_path, $filetype['type'] );
		$streamer->start();
	}

	/**
	 * Build a backward-compatible secure download URL for a legacy (pre-2.5.0) file.
	 *
	 * Legacy files were stored in the public /uploads/sureforms/ directory and had no
	 * access-control. To serve them through the unified sureforms-download handler without
	 * breaking existing entry data, the path relative to the uploads base URL is base64-
	 * encoded and placed in the download URL. The form-id segment is set to 0 because
	 * legacy filenames carry no embedded form-id; the handler detects the presence of a
	 * path separator ('/') in the decoded value and serves the file directly from the
	 * uploads directory without enforcing block-level permissions.
	 *
	 * Example:
	 *   Input:  "http://site.com/wp-content/uploads/sureforms/img-1-1.jpg"
	 *   Encoded path: base64("sureforms/img-1-1.jpg")
	 *   Output: "http://site.com/sureforms-download/{base64}/0/"
	 *
	 * @param string $decoded_url The decoded (non-URL-encoded) legacy file URL.
	 * @since 2.6.0
	 * @return string The secure download URL for the legacy file.
	 */
	private static function get_backward_compatible_download_url( $decoded_url ) {
		// Extract the path relative to the WordPress uploads base URL.
		// e.g. "http://site.com/wp-content/uploads/sureforms/img-1-1.jpg"
		// → "sureforms/img-1-1.jpg".
		$upload_base_url = trailingslashit( wp_upload_dir()['baseurl'] );
		$relative_path   = ltrim( str_replace( $upload_base_url, '', $decoded_url ), '/' );

		$encoded_path = Pro_Helper::srfm_base64_encode( $relative_path );

		// form-id is 0 — legacy files have no embedded form-id.
		return home_url( self::$download_slug . '/' . $encoded_path . '/0/' );
	}

	/**
	 * Get the current logged-in user's roles.
	 *
	 * @since 2.6.0
	 * @return array<string> Array of role slugs, or empty array if not logged in.
	 */
	private static function get_current_user_roles() {
		$user = wp_get_current_user();
		if ( ! $user->ID ) {
			return [];
		}
		return (array) $user->roles;
	}

	/**
	 * Whether a request's trailing form ID contradicts the form ID embedded in the
	 * stored filename.
	 *
	 * The stored name is produced by generate_file_name(), which embeds the owning
	 * form ID as its last segment, so a well-formed download URL always agrees with it. A mismatch
	 * means the trailing ID was edited by hand, which previously pointed the
	 * permission lookup at an unrelated form's configuration.
	 *
	 * Returns false for names that carry no embedded form ID (legacy formats), which
	 * are handled separately and have no block-level configuration to enforce.
	 *
	 * @param string $filename The decoded, validated filename.
	 * @param int    $form_id  Form ID supplied in the request URL.
	 * @since 2.12.3
	 * @return bool True when the two disagree and the request must be rejected.
	 */
	private static function is_form_id_mismatch( $filename, $form_id ) {
		$filename_form_id = self::get_form_id_from_filename( $filename );

		if ( $filename_form_id <= 0 ) {
			return false;
		}

		return absint( $form_id ) !== $filename_form_id;
	}

	/**
	 * Resolve whether a stored upload is role-restricted, and whether the current
	 * user may access it.
	 *
	 * Enforces the block-level protectFile / allowedUsers settings stored in
	 * _srfm_block_config. Administrators bypass the role check but the file is still
	 * reported as protected, so the streamed response is kept out of shared caches.
	 *
	 * The owning form is resolved from the filename rather than the request URL, so
	 * the permission set is always the one belonging to the bytes being served.
	 *
	 * Access control design — intentionally no is_user_logged_in() gate:
	 * By default, uploaded files are accessible to anyone (including anonymous users).
	 * This is by design — form submissions may include file uploads or signatures
	 * whose download links are shared via email with non-logged-in recipients.
	 * Restriction only applies when the form builder explicitly enables `protectFile`
	 * on a field block. Only then are role-based checks enforced via `allowedUsers`.
	 * Without this intentional opt-in, files remain publicly accessible — matching
	 * the default WordPress media library behavior where uploaded files are public.
	 *
	 * @param string $filename The stored filename (used to extract the block and form ID).
	 * @param int    $form_id  Fallback form ID, used only when the filename carries none.
	 * @since 2.6.0
	 * @return array{protected:bool,allowed:bool} Whether the file is role-restricted, and
	 *                                            whether the current user may access it.
	 */
	private static function resolve_file_access( $filename, $form_id ) {
		$public = [
			'protected' => false,
			'allowed'   => true,
		];

		// Fail CLOSED when the permission state cannot be resolved.
		//
		// Every file reaching this method lives inside sureforms-private/ — the realpath
		// containment check in handle_file_download() guarantees it — so it is by
		// definition a file the permission system is responsible for. Pre-2.5.0 uploads in
		// sureforms/ never reach here; they take the separate stream_legacy_file() path,
		// which is deliberately unauthenticated, so existing email links are unaffected.
		//
		// These three branches previously returned true, which meant an unresolvable
		// config granted anonymous access. The consequence was not theoretical: deleting a
		// form drops _srfm_block_config with the post, while the uploaded files survive
		// (deletion is wired only to srfm_pro_before_deleting_entry). Every
		// protectFile-restricted document that form collected then became anonymously
		// downloadable via its original URL, permanently. An import or migration that
		// renumbers post IDs has the same effect.
		$block_id = self::get_block_id_from_filename( $filename );

		// Fewer than 5 hyphen-delimited segments means the name predates the
		// {name}-{random}-{type}-{block_id}-{form_id} scheme, so it carries no
		// block-level configuration to enforce. Legacy names are already served by
		// stream_legacy_file() before this point.
		if ( empty( $block_id ) ) {
			return $public;
		}

		// Resolve the owning form from the FILENAME, not from the request URL.
		// The filename is the same value that resolves the file on disk, so the
		// permission set can never be loaded for a different form than the bytes
		// being served. handle_file_download() also rejects a mismatch outright;
		// this keeps the two inputs bound together even if a future caller skips
		// that guard.
		$owner_form_id = self::get_form_id_from_filename( $filename );
		$form_id       = $owner_form_id > 0 ? $owner_form_id : absint( $form_id );

		// FAIL CLOSED from here on. A filename in the {name}-{random}-{type}-{block_id}-
		// {form_id} format carries a form and block identity, so its access policy is
		// knowable in principle — if we cannot load it, the policy is UNKNOWN, not "public".
		// A deleted form, a removed upload block, corrupt _srfm_block_config meta, or a
		// failed migration would otherwise turn a previously protectFile-restricted URL
		// into a public (and, before the cache fix, 30-day-cacheable) response. Legacy
		// names never reach here: they return above on an empty block ID, and
		// stream_legacy_file() handles them earlier.
		$unknown = [
			'protected' => true,
			'allowed'   => current_user_can( 'manage_options' ),
		];

		$block_config = \SRFM\Inc\Field_Validation::get_or_migrate_block_config_for_legacy_form( $form_id );
		if ( empty( $block_config ) || ! \is_array( $block_config ) ) {
			/**
			 * Fires when a new-format upload's block configuration cannot be loaded, so its
			 * access policy is indeterminate and the request is denied.
			 *
			 * @since 2.12.3
			 * @param string $filename The decoded filename.
			 * @param int    $form_id  The form ID resolved from the filename.
			 * @param string $reason   Which lookup failed.
			 */
			do_action( 'srfm_pro_download_policy_unresolved', $filename, $form_id, 'missing_block_config' );
			return $unknown;
		}

		$field_config = $block_config[ $block_id ] ?? null;
		if ( null === $field_config ) {
			do_action( 'srfm_pro_download_policy_unresolved', $filename, $form_id, 'missing_field_config' );
			return $unknown;
		}

		// protectFile not enabled — file is publicly accessible (default behavior).
		if ( empty( $field_config['protectFile'] ) ) {
			return $public;
		}

		// Administrators bypass the role check, but the response is still treated as
		// protected so it is never stored in a shared cache.
		if ( current_user_can( 'manage_options' ) ) {
			return [
				'protected' => true,
				'allowed'   => true,
			];
		}

		$allowed_users = isset( $field_config['allowedUsers'] ) && \is_array( $field_config['allowedUsers'] )
			? $field_config['allowedUsers']
			: [];

		// protectFile enabled but no specific roles configured — allow any logged-in user.
		if ( empty( $allowed_users ) ) {
			return [
				'protected' => true,
				'allowed'   => is_user_logged_in(),
			];
		}

		return [
			'protected' => true,
			'allowed'   => ! empty( array_intersect( self::get_current_user_roles(), $allowed_users ) ),
		];
	}
}
