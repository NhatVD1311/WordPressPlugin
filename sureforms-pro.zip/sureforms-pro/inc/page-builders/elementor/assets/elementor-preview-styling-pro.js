/**
 * Elementor Styling Preview - Pro Extension
 *
 * Handles live preview of Pro styling changes in the Elementor editor.
 * Listens for the custom event from the free plugin and applies Pro CSS variables.
 *
 * @package
 * @since 2.12.1
 */

import {
	applyDimensions,
	resetDimensions,
	buildGradientCSS,
	initGradientFromSettings,
} from '@Utils/styling-utils';

( function () {
	'use strict';

	/**
	 * Simple CSS variable mappings: controlName → cssVariable
	 * For controls that just set a single CSS variable.
	 */
	const SIMPLE_CSS_MAP = {
		// Layout.
		formRowGap: '--srfm-row-gap-between-blocks',
		formColumnGap: '--srfm-column-gap-between-blocks',
		// Button colors.
		buttonTextColorNormal: '--srfm-button-text-color-normal',
		buttonTextColorHover: '--srfm-button-text-color-hover',
		buttonBackgroundColorNormal: '--srfm-button-background-color-normal',
		buttonBackgroundColorHover: '--srfm-button-background-color-hover',
		buttonBorderColorNormal: '--srfm-button-border-color',
		buttonBorderColorHover: '--srfm-button-border-hover-color',
		buttonBorderStyle: '--srfm-button-border-style',
		// Field colors.
		fieldBgColor: '--srfm-color-input-background',
		fieldLabelColor: '--srfm-color-input-label',
		fieldInputColor: '--srfm-color-input-text',
		fieldHelpTextColor: '--srfm-color-input-description',
		fieldBorderColor: '--srfm-color-input-border',
		// Messages.
		errorColor: '--srfm-error-color',
	};

	/**
	 * Unit-based CSS variable mappings: controlName → { cssVar, unit }
	 * For controls that need a unit suffix.
	 */
	const UNIT_CSS_MAP = {
		buttonTextSize: { cssVar: '--srfm-btn-font-size', unit: 'px' },
		buttonLineHeight: { cssVar: '--srfm-btn-line-height', unit: 'em' },
		fieldLabelSize: { cssVar: '--srfm-label-font-size', unit: 'px' },
		fieldLabelLineHeight: {
			cssVar: '--srfm-label-line-height',
			unit: 'em',
		},
		fieldLabelGap: { cssVar: '--srfm-input-label-gap', unit: 'px' },
		fieldHelpTextSize: { cssVar: '--srfm-help-text-font-size', unit: 'px' },
		fieldHelpTextLineHeight: {
			cssVar: '--srfm-help-text-line-height',
			unit: 'em',
		},
	};

	/**
	 * DIMENSIONS control mappings: controlName → cssVarPrefix
	 * These controls have top/right/bottom/left values.
	 */
	const DIMENSIONS_CSS_MAP = {
		buttonPadding: '--srfm-button-padding',
		buttonBorderRadius: '--srfm-button-border-radius',
		buttonBorderWidth: '--srfm-button-border-width',
		fieldBorderWidth: '--srfm-field-border-width',
		fieldBorderRadius: '--srfm-field-border-radius',
	};

	/**
	 * Box shadow control names grouped by state.
	 */
	const BOX_SHADOW_CONTROLS = {
		normal: {
			color: 'fieldBoxShadowColorNormal',
			hOffset: 'fieldBoxShadowHOffsetNormal',
			vOffset: 'fieldBoxShadowVOffsetNormal',
			blur: 'fieldBoxShadowBlurNormal',
			spread: 'fieldBoxShadowSpreadNormal',
			position: 'fieldBoxShadowPositionNormal',
			cssVar: '--srfm-field-box-shadow-normal',
		},
		focus: {
			color: 'fieldBoxShadowColorFocus',
			hOffset: 'fieldBoxShadowHOffsetFocus',
			vOffset: 'fieldBoxShadowVOffsetFocus',
			blur: 'fieldBoxShadowBlurFocus',
			spread: 'fieldBoxShadowSpreadFocus',
			position: 'fieldBoxShadowPositionFocus',
			cssVar: '--srfm-field-box-shadow-focus',
		},
	};

	/**
	 * Set of all box shadow control names for fast lookup.
	 */
	const BOX_SHADOW_CONTROL_NAMES = new Set(
		Object.values( BOX_SHADOW_CONTROLS ).flatMap( ( s ) => [
			s.color,
			s.hOffset,
			s.vOffset,
			s.blur,
			s.spread,
			s.position,
		] )
	);

	/**
	 * Button background type controls.
	 */
	const BUTTON_BG_TYPE_CONTROLS = [
		'buttonBackgroundTypeNormal',
		'buttonBackgroundTypeHover',
	];

	/**
	 * Button background gradient group control field names.
	 * Position control is hidden - radial gradients use 'center center' position.
	 */
	const BUTTON_GRADIENT_CONTROLS = [
		// Normal state gradient fields.
		'buttonBgGradientNormal_color',
		'buttonBgGradientNormal_color_b',
		'buttonBgGradientNormal_gradient_type',
		'buttonBgGradientNormal_gradient_angle',
		'buttonBgGradientNormal_color_stop',
		'buttonBgGradientNormal_color_b_stop',
		// Hover state gradient fields.
		'buttonBgGradientHover_color',
		'buttonBgGradientHover_color_b',
		'buttonBgGradientHover_gradient_type',
		'buttonBgGradientHover_gradient_angle',
		'buttonBgGradientHover_color_stop',
		'buttonBgGradientHover_color_b_stop',
	];

	/**
	 * All Pro control names (derived from the maps above + special controls).
	 */
	const ALL_PRO_CONTROLS = [
		'formTheme',
		...Object.keys( SIMPLE_CSS_MAP ),
		...Object.keys( UNIT_CSS_MAP ),
		...Object.keys( DIMENSIONS_CSS_MAP ),
		...BUTTON_BG_TYPE_CONTROLS,
		...BUTTON_GRADIENT_CONTROLS,
		...BOX_SHADOW_CONTROL_NAMES,
	];

	/**
	 * Apply button background based on type.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      state     The state ('Normal' or 'Hover').
	 */
	function applyButtonBackground( container, state ) {
		const submitBtn = container.querySelector( '.srfm-button' );
		if ( ! submitBtn ) {
			return;
		}

		const bgType =
			container.dataset[ 'buttonBackgroundType' + state ] || 'color';
		const cssVarColor =
			state === 'Normal'
				? '--srfm-button-background-color-normal'
				: '--srfm-button-background-color-hover';
		const cssVarGradient =
			state === 'Normal'
				? '--srfm-button-background-gradient-normal'
				: '--srfm-button-background-gradient-hover';
		const bgClass =
			state === 'Normal' ? 'srfm-btn-bg-' : 'srfm-btn-bg-hover-';

		// Remove existing background type classes for this state.
		submitBtn.classList.remove(
			bgClass + 'color',
			bgClass + 'gradient',
			bgClass + 'transparent'
		);

		// Add the appropriate class.
		submitBtn.classList.add( bgClass + bgType );

		// Handle CSS variables based on type.
		if ( bgType === 'color' ) {
			// Color is handled via SIMPLE_CSS_MAP, just clear gradient.
			container.style.removeProperty( cssVarGradient );
		} else if ( bgType === 'gradient' ) {
			const gradient = buildGradientCSS(
				container,
				'buttonBgGradient' + state
			);
			if ( gradient ) {
				container.style.setProperty( cssVarGradient, gradient );
			}
			// Clear color when using gradient.
			container.style.removeProperty( cssVarColor );
		} else if ( bgType === 'transparent' ) {
			// Clear both for transparent.
			container.style.removeProperty( cssVarColor );
			container.style.removeProperty( cssVarGradient );
		}
	}

	/**
	 * Build a CSS box-shadow string from dataset values for a given state.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {Object}      config    The box shadow config for this state.
	 */
	function buildAndApplyBoxShadow( container, config ) {
		const hOffset = parseFloat( container.dataset[ config.hOffset ] ) || 0;
		const vOffset = parseFloat( container.dataset[ config.vOffset ] ) || 0;
		const blur = parseFloat( container.dataset[ config.blur ] ) || 0;
		const spread = parseFloat( container.dataset[ config.spread ] ) || 0;
		const color =
			container.dataset[ config.color ] ||
			'var(--srfm-color-input-border-focus-glow)';
		const position = container.dataset[ config.position ] || 'outset';
		const inset = position === 'inset' ? ' inset' : '';

		container.style.setProperty(
			config.cssVar,
			`${ hOffset }px ${ vOffset }px ${ blur }px ${ spread }px ${ color }${ inset }`
		);
	}

	/**
	 * Apply a style update for a Pro control.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      name      The control name.
	 * @param {*}           value     The control value.
	 */
	function applyProStyle( container, name, value ) {
		// Handle simple CSS variable mappings.
		if ( SIMPLE_CSS_MAP[ name ] ) {
			// Handle slider controls (object with size/unit).
			if ( typeof value === 'object' && value !== null && value.size !== undefined ) {
				container.style.setProperty(
					SIMPLE_CSS_MAP[ name ],
					value.size + ( value.unit || 'px' )
				);
			} else if ( typeof value !== 'object' ) {
				container.style.setProperty( SIMPLE_CSS_MAP[ name ], value );
			}
			return;
		}

		// Handle unit-based CSS variable mappings.
		if ( UNIT_CSS_MAP[ name ] ) {
			const { cssVar, unit } = UNIT_CSS_MAP[ name ];
			container.style.setProperty( cssVar, value + unit );
			return;
		}

		// Handle DIMENSIONS controls.
		if ( DIMENSIONS_CSS_MAP[ name ] ) {
			applyDimensions( container, DIMENSIONS_CSS_MAP[ name ], value );
			return;
		}

		// Handle special controls.
		if ( name === 'formTheme' ) {
			container.classList.toggle(
				'srfm-custom-stylings',
				value === 'custom'
			);
			return;
		}

		// Handle box shadow controls.
		if ( BOX_SHADOW_CONTROL_NAMES.has( name ) ) {
			// Store the value in dataset for composite rebuild.
			container.dataset[ name ] = value;

			// Determine which state and rebuild the composite CSS value.
			for ( const config of Object.values( BOX_SHADOW_CONTROLS ) ) {
				const controlNames = [
					config.color,
					config.hOffset,
					config.vOffset,
					config.blur,
					config.spread,
					config.position,
				];
				if ( controlNames.includes( name ) ) {
					buildAndApplyBoxShadow( container, config );
					break;
				}
			}
			return;
		}

		// Handle button background type controls.
		if ( name === 'buttonBackgroundTypeNormal' ) {
			container.dataset.buttonBackgroundTypeNormal = value;
			applyButtonBackground( container, 'Normal' );
			return;
		}
		if ( name === 'buttonBackgroundTypeHover' ) {
			container.dataset.buttonBackgroundTypeHover = value;
			applyButtonBackground( container, 'Hover' );
			return;
		}

		// Handle button gradient Normal state controls.
		if ( name.startsWith( 'buttonBgGradientNormal_' ) ) {
			const fieldName = name.replace( 'buttonBgGradientNormal_', '' );
			storeGradientValue(
				container,
				'buttonBgGradientNormal',
				fieldName,
				value
			);
			applyButtonBackground( container, 'Normal' );
			return;
		}

		// Handle button gradient Hover state controls.
		if ( name.startsWith( 'buttonBgGradientHover_' ) ) {
			const fieldName = name.replace( 'buttonBgGradientHover_', '' );
			storeGradientValue(
				container,
				'buttonBgGradientHover',
				fieldName,
				value
			);
			applyButtonBackground( container, 'Hover' );
		}
	}

	/**
	 * Store gradient control value in dataset.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      prefix    The dataset prefix.
	 * @param {string}      fieldName The gradient field name.
	 * @param {*}           value     The control value.
	 */
	function storeGradientValue( container, prefix, fieldName, value ) {
		switch ( fieldName ) {
			case 'color':
				container.dataset[ prefix + 'Color' ] = value;
				break;
			case 'color_b':
				container.dataset[ prefix + 'ColorB' ] = value;
				break;
			case 'gradient_type':
				container.dataset[ prefix + 'Type' ] = value;
				break;
			case 'gradient_angle': {
				const angleSize =
					typeof value === 'object' ? value.size : value;
				const angleUnit =
					typeof value === 'object' ? value.unit : 'deg';
				container.dataset[ prefix + 'Angle' ] = angleSize;
				container.dataset[ prefix + 'AngleUnit' ] = angleUnit;
				break;
			}
			case 'color_stop': {
				const stopSize = typeof value === 'object' ? value.size : value;
				const stopUnit = typeof value === 'object' ? value.unit : '%';
				container.dataset[ prefix + 'ColorStop' ] = stopSize;
				container.dataset[ prefix + 'ColorStopUnit' ] = stopUnit;
				break;
			}
			case 'color_b_stop': {
				const stopBSize =
					typeof value === 'object' ? value.size : value;
				const stopBUnit = typeof value === 'object' ? value.unit : '%';
				container.dataset[ prefix + 'ColorBStop' ] = stopBSize;
				container.dataset[ prefix + 'ColorBStopUnit' ] = stopBUnit;
				break;
			}
		}
	}

	/**
	 * Reset a Pro control to its original state.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      name      The control name.
	 */
	function resetProControl( container, name ) {
		// Handle simple CSS variable mappings.
		if ( SIMPLE_CSS_MAP[ name ] ) {
			container.style.removeProperty( SIMPLE_CSS_MAP[ name ] );
			return;
		}

		// Handle unit-based CSS variable mappings.
		if ( UNIT_CSS_MAP[ name ] ) {
			container.style.removeProperty( UNIT_CSS_MAP[ name ].cssVar );
			return;
		}

		// Handle DIMENSIONS controls.
		if ( DIMENSIONS_CSS_MAP[ name ] ) {
			resetDimensions( container, DIMENSIONS_CSS_MAP[ name ] );
			return;
		}

		// Handle box shadow controls.
		if ( BOX_SHADOW_CONTROL_NAMES.has( name ) ) {
			delete container.dataset[ name ];
			// Rebuild the composite CSS value after removing this control's data.
			for ( const config of Object.values( BOX_SHADOW_CONTROLS ) ) {
				const controlNames = [
					config.color,
					config.hOffset,
					config.vOffset,
					config.blur,
					config.spread,
					config.position,
				];
				if ( controlNames.includes( name ) ) {
					buildAndApplyBoxShadow( container, config );
					break;
				}
			}
			return;
		}

		// Handle special controls.
		if ( name === 'formTheme' ) {
			container.classList.remove( 'srfm-custom-stylings' );
			return;
		}

		// Handle button background type controls.
		if ( name === 'buttonBackgroundTypeNormal' ) {
			delete container.dataset.buttonBackgroundTypeNormal;
			resetButtonBackground( container, 'Normal' );
			return;
		}
		if ( name === 'buttonBackgroundTypeHover' ) {
			delete container.dataset.buttonBackgroundTypeHover;
			resetButtonBackground( container, 'Hover' );
			return;
		}

		// Handle button gradient controls.
		if (
			name.startsWith( 'buttonBgGradientNormal_' ) ||
			name.startsWith( 'buttonBgGradientHover_' )
		) {
			const isNormal = name.startsWith( 'buttonBgGradientNormal_' );
			const prefix = isNormal
				? 'buttonBgGradientNormal'
				: 'buttonBgGradientHover';
			const fieldName = name.replace( prefix + '_', '' );
			resetGradientValue( container, prefix, fieldName );
		}
	}

	/**
	 * Reset button background styles.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      state     The state ('Normal' or 'Hover').
	 */
	function resetButtonBackground( container, state ) {
		const submitBtn = container.querySelector( '.srfm-button' );
		if ( submitBtn ) {
			const bgClass =
				state === 'Normal' ? 'srfm-btn-bg-' : 'srfm-btn-bg-hover-';
			submitBtn.classList.remove(
				bgClass + 'color',
				bgClass + 'gradient',
				bgClass + 'transparent'
			);
		}

		const cssVarColor =
			state === 'Normal'
				? '--srfm-button-background-color-normal'
				: '--srfm-button-background-color-hover';
		const cssVarGradient =
			state === 'Normal'
				? '--srfm-button-background-gradient-normal'
				: '--srfm-button-background-gradient-hover';
		container.style.removeProperty( cssVarColor );
		container.style.removeProperty( cssVarGradient );
	}

	/**
	 * Reset gradient control value in dataset.
	 *
	 * @param {HTMLElement} container The form container element.
	 * @param {string}      prefix    The dataset prefix.
	 * @param {string}      fieldName The gradient field name.
	 */
	function resetGradientValue( container, prefix, fieldName ) {
		switch ( fieldName ) {
			case 'color':
				delete container.dataset[ prefix + 'Color' ];
				break;
			case 'color_b':
				delete container.dataset[ prefix + 'ColorB' ];
				break;
			case 'gradient_type':
				delete container.dataset[ prefix + 'Type' ];
				break;
			case 'gradient_angle':
				delete container.dataset[ prefix + 'Angle' ];
				delete container.dataset[ prefix + 'AngleUnit' ];
				break;
			case 'color_stop':
				delete container.dataset[ prefix + 'ColorStop' ];
				delete container.dataset[ prefix + 'ColorStopUnit' ];
				break;
			case 'color_b_stop':
				delete container.dataset[ prefix + 'ColorBStop' ];
				delete container.dataset[ prefix + 'ColorBStopUnit' ];
				break;
		}
	}

	/**
	 * Reset all Pro styles when formTheme is set to inherit.
	 *
	 * @param {HTMLElement} container The form container element.
	 */
	function resetAllProStyles( container ) {
		ALL_PRO_CONTROLS.forEach( function ( controlName ) {
			resetProControl( container, controlName );
		} );
	}

	// Main event listener.
	document.addEventListener(
		'srfm-elementor-styling-update',
		function ( event ) {
			const { name, value, container, widgetSettings } = event.detail;
			if ( ! container ) {
				return;
			}

			// Handle formTheme change - reset all Pro styles when set to inherit.
			if ( name === 'formTheme' && value === 'inherit' ) {
				resetAllProStyles( container );
				return;
			}

			// Handle empty/default values - reset to original.
			if ( value === '' || value === 'default' ) {
				resetProControl( container, name );
				return;
			}

			// Initialize button gradient values when any button gradient control changes.
			// This ensures colors are in dataset when location/angle sliders change.
			if ( widgetSettings ) {
				if ( name.startsWith( 'buttonBgGradientNormal_' ) ) {
					initGradientFromSettings(
						container,
						widgetSettings,
						'buttonBgGradientNormal',
						'buttonBgGradientNormal_'
					);
				} else if ( name.startsWith( 'buttonBgGradientHover_' ) ) {
					initGradientFromSettings(
						container,
						widgetSettings,
						'buttonBgGradientHover',
						'buttonBgGradientHover_'
					);
				}
			}

			// Apply the style update.
			applyProStyle( container, name, value );
		}
	);

	// Listen for init event from free plugin to initialize Pro controls.
	document.addEventListener(
		'srfm-elementor-styling-init',
		function ( event ) {
			const { container, widgetSettings } = event.detail;
			if ( ! container || ! widgetSettings ) {
				return;
			}

			// Initialize button background type for Normal state.
			const btnBgTypeNormal = widgetSettings.get(
				'buttonBackgroundTypeNormal'
			);
			if ( btnBgTypeNormal ) {
				container.dataset.buttonBackgroundTypeNormal = btnBgTypeNormal;

				// Initialize gradient values if type is gradient.
				if ( btnBgTypeNormal === 'gradient' ) {
					initGradientFromSettings(
						container,
						widgetSettings,
						'buttonBgGradientNormal',
						'buttonBgGradientNormal_'
					);
				}
			}

			// Initialize button background type for Hover state.
			const btnBgTypeHover = widgetSettings.get(
				'buttonBackgroundTypeHover'
			);
			if ( btnBgTypeHover ) {
				container.dataset.buttonBackgroundTypeHover = btnBgTypeHover;

				// Initialize gradient values if type is gradient.
				if ( btnBgTypeHover === 'gradient' ) {
					initGradientFromSettings(
						container,
						widgetSettings,
						'buttonBgGradientHover',
						'buttonBgGradientHover_'
					);
				}
			}

			// Initialize box shadow values from widget settings.
			for ( const config of Object.values( BOX_SHADOW_CONTROLS ) ) {
				const controlNames = [
					config.color,
					config.hOffset,
					config.vOffset,
					config.blur,
					config.spread,
					config.position,
				];
				controlNames.forEach( ( controlName ) => {
					const val = widgetSettings.get( controlName );
					if ( val !== undefined && val !== '' ) {
						container.dataset[ controlName ] = val;
					}
				} );
				buildAndApplyBoxShadow( container, config );
			}
		}
	);
}() );
