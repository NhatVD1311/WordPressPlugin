<?php
/**
 * Elementor Form Widget - Pro Extension.
 *
 * Adds Pro styling controls to the SureForms Elementor widget.
 *
 * @package sureforms-pro
 * @since 2.7.0
 */

namespace SRFM_Pro\Inc\Page_Builders\Elementor;

use SRFM\Inc\Helper;
use SRFM\Inc\Page_Builders\Elementor\Form_Widget;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Form_Widget_Pro Class.
 *
 * @since 2.7.0
 */
class Form_Widget_Pro {
	use Get_Instance;

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 2.7.0
	 */
	public function __construct() {
		// Add Form Theme control before basic controls (priority 5).
		add_action( 'srfm_elementor_after_basic_styling_controls', [ $this, 'add_form_theme_control' ], 5 );

		// Add Pro styling sections (after form theme control).
		add_action( 'srfm_elementor_after_styling_section', [ $this, 'add_messages_section' ] );

		// Add Pro button controls to free plugin's Button section.
		add_action( 'srfm_elementor_button_controls', [ $this, 'add_button_controls' ] );
		// Add Pro layout controls to free plugin's Layout section.
		add_action( 'srfm_elementor_layout_controls', [ $this, 'add_layout_controls' ] );
		// Add Pro field controls to free plugin's Fields section.
		add_action( 'srfm_elementor_field_controls', [ $this, 'add_field_controls' ] );

		// Extend block_attrs with Pro settings.
		add_filter( 'srfm_elementor_block_attrs', [ $this, 'extend_block_attrs' ], 10, 2 );

		// Register Pro preview assets (scripts and styles) in widget preview mode.
		add_action( 'srfm_elementor_register_preview_assets', [ $this, 'register_pro_preview_assets' ] );

		// Add Pro assets to widget dependencies.
		add_filter( 'srfm_elementor_widget_script_depends', [ $this, 'add_pro_script_depends' ] );
		add_filter( 'srfm_elementor_widget_style_depends', [ $this, 'add_pro_style_depends' ] );
	}

	/**
	 * Add Form Theme control.
	 *
	 * @param \Elementor\Widget_Base $widget The widget instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_form_theme_control( $widget ) {
		$widget->update_control(
			'formTheme',
			[
				'options' => [
					'inherit' => __( "Inherit Form's Original Style", 'sureforms-pro' ),
					'default' => __( 'Default', 'sureforms-pro' ),
					'custom'  => __( 'Custom', 'sureforms-pro' ),
				],
			]
		);
	}

	/**
	 * Add Pro Layout controls to the Layout section.
	 *
	 * Hooked to 'srfm_elementor_layout_controls' to add
	 * Pro controls after the Button Alignment control in the free plugin.
	 *
	 * @param \Elementor\Widget_Base $widget The widget instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_layout_controls( $widget ) {
		$widget->add_control(
			'formRowGap',
			[
				'label'      => __( 'Row Gap', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 18,
					'unit' => 'px',
				],
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'formColumnGap',
			[
				'label'      => __( 'Column Gap', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 16,
					'unit' => 'px',
				],
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);
	}

	/**
	 * Add Pro Button controls to the Button section.
	 *
	 * Hooked to 'srfm_elementor_button_controls' to add
	 * Pro controls after the Button Alignment control in the free plugin.
	 *
	 * @param \Elementor\Widget_Base $widget The widget instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_button_controls( $widget ) {
		// Button Padding (DIMENSIONS control).
		$widget->add_control(
			'buttonPadding',
			[
				'label'      => __( 'Padding', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '10',
					'right'    => '14',
					'bottom'   => '10',
					'left'     => '14',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'separator'  => 'before',
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);

		// Normal/Hover Tabs.
		$widget->start_controls_tabs(
			'srfm_button_tabs',
			[
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Normal Tab.
		$widget->start_controls_tab(
			'srfm_button_normal',
			[
				'label' => __( 'Normal', 'sureforms-pro' ),
			]
		);

		$widget->add_control(
			'buttonTextColorNormal',
			[
				'label' => __( 'Text Color', 'sureforms-pro' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
			]
		);

		// Normal state button background controls.
		$this->add_button_background_controls( $widget, 'Normal', '#046BD2', '#1E40AF' );

		$widget->add_control(
			'buttonBorderColorNormal',
			[
				'label' => __( 'Border Color', 'sureforms-pro' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
			]
		);

		$widget->end_controls_tab();

		// Hover Tab.
		$widget->start_controls_tab(
			'srfm_button_hover',
			[
				'label' => __( 'Hover', 'sureforms-pro' ),
			]
		);

		$widget->add_control(
			'buttonTextColorHover',
			[
				'label' => __( 'Text Color', 'sureforms-pro' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
			]
		);

		// Hover state button background controls.
		$this->add_button_background_controls( $widget, 'Hover', '#1E40AF', '#046BD2' );

		$widget->add_control(
			'buttonBorderColorHover',
			[
				'label' => __( 'Border Color', 'sureforms-pro' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
			]
		);

		$widget->end_controls_tab();

		$widget->end_controls_tabs();

		// Typography.
		$widget->add_control(
			'buttonTypographyHeading',
			[
				'label'     => __( 'Typography', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'buttonTextSize',
			[
				'label'     => __( 'Font Size (px)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 16,
				'min'       => 8,
				'max'       => 100,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'buttonLineHeight',
			[
				'label'     => __( 'Line Height (em)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 1.5,
				'min'       => 0.5,
				'max'       => 5,
				'step'      => 0.1,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Button Border.
		$widget->add_control(
			'buttonBorderHeading',
			[
				'label'     => __( 'Border', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'buttonBorderStyle',
			[
				'label'     => __( 'Border Style', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'none'   => __( 'None', 'sureforms-pro' ),
					'solid'  => __( 'Solid', 'sureforms-pro' ),
					'dashed' => __( 'Dashed', 'sureforms-pro' ),
					'dotted' => __( 'Dotted', 'sureforms-pro' ),
					'double' => __( 'Double', 'sureforms-pro' ),
				],
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Button Border Width (DIMENSIONS control).
		$widget->add_control(
			'buttonBorderWidth',
			[
				'label'      => __( 'Border Width', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default'    => [
					'top'      => '1',
					'right'    => '1',
					'bottom'   => '1',
					'left'     => '1',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);

		// Button Border Radius (DIMENSIONS control).
		$widget->add_control(
			'buttonBorderRadius',
			[
				'label'      => __( 'Border Radius', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '6',
					'right'    => '6',
					'bottom'   => '6',
					'left'     => '6',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);
	}

	/**
	 * Add Pro Field controls to the Fields section.
	 *
	 * Hooked to 'srfm_elementor_field_controls' to add
	 * Pro controls to the free plugin's Fields section.
	 *
	 * @param \Elementor\Widget_Base $widget The widget instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_field_controls( $widget ) {
		// Field Colors.
		$widget->add_control(
			'fieldColorsHeading',
			[
				'label'     => __( 'Colors', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldBgColor',
			[
				'label'     => __( 'Background Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldLabelColor',
			[
				'label'     => __( 'Label Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldInputColor',
			[
				'label'     => __( 'Input Text Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldHelpTextColor',
			[
				'label'     => __( 'Help Text Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Field Label Typography.
		$widget->add_control(
			'fieldLabelTypographyHeading',
			[
				'label'     => __( 'Label Typography', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldLabelSize',
			[
				'label'     => __( 'Font Size (px)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 16,
				'min'       => 8,
				'max'       => 100,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldLabelLineHeight',
			[
				'label'     => __( 'Line Height (em)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 1.5,
				'min'       => 0.5,
				'max'       => 5,
				'step'      => 0.1,
				'separator' => 'after',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Field Label Gap.
		$widget->add_control(
			'fieldLabelGap',
			[
				'label'     => __( 'Label Gap (px)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 6,
				'min'       => 0,
				'max'       => 50,
				'separator' => 'after',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Help Text Typography.
		$widget->add_control(
			'fieldHelpTextTypographyHeading',
			[
				'label'     => __( 'Help Text Typography', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldHelpTextSize',
			[
				'label'     => __( 'Font Size (px)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 14,
				'min'       => 8,
				'max'       => 100,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldHelpTextLineHeight',
			[
				'label'     => __( 'Line Height (em)', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 1.4,
				'min'       => 0.5,
				'max'       => 5,
				'step'      => 0.1,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Field Border.
		$widget->add_control(
			'fieldBorderHeading',
			[
				'label'     => __( 'Border', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		$widget->add_control(
			'fieldBorderColor',
			[
				'label'     => __( 'Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Field Border Width (DIMENSIONS control).
		$widget->add_control(
			'fieldBorderWidth',
			[
				'label'      => __( 'Border Width', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default'    => [
					'top'      => '1',
					'right'    => '1',
					'bottom'   => '1',
					'left'     => '1',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'separator'  => 'after',
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);

		// Field Border Radius (DIMENSIONS control).
		$widget->add_control(
			'fieldBorderRadius',
			[
				'label'      => __( 'Border Radius', 'sureforms-pro' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '6',
					'right'    => '6',
					'bottom'   => '6',
					'left'     => '6',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'condition'  => [
					'formTheme' => 'custom',
				],
			]
		);

		// Input Shadow.
		$widget->add_control(
			'fieldBoxShadowHeading',
			[
				'label'     => __( 'Input Shadow', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Normal/Focus Tabs for box shadow.
		$widget->start_controls_tabs(
			'srfm_field_box_shadow_tabs',
			[
				'condition' => [
					'formTheme' => 'custom',
				],
			]
		);

		// Normal Tab.
		$widget->start_controls_tab(
			'srfm_field_box_shadow_normal',
			[
				'label' => __( 'Normal', 'sureforms-pro' ),
			]
		);

		$this->add_box_shadow_controls( $widget, 'Normal', [ 'spread_default' => 0 ] );

		$widget->end_controls_tab();

		// Focus Tab.
		$widget->start_controls_tab(
			'srfm_field_box_shadow_focus',
			[
				'label' => __( 'Focus', 'sureforms-pro' ),
			]
		);

		$this->add_box_shadow_controls( $widget, 'Focus', [ 'spread_default' => 3 ] );

		$widget->end_controls_tab();

		$widget->end_controls_tabs();
	}

	/**
	 * Add Messages section.
	 *
	 * @param \Elementor\Widget_Base $widget The widget instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_messages_section( $widget ) {
		$widget->start_controls_section(
			'srfm_messages_section',
			[
				'label'     => __( 'Messages', 'sureforms-pro' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'srfm_form_block!' => '',
					'formTheme'        => 'custom',
				],
			]
		);

		$widget->add_control(
			'errorColor',
			[
				'label'   => __( 'Error Color', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::COLOR,
				'default' => '#dc2626',
			]
		);

		$widget->end_controls_section();
	}

	/**
	 * Extend block_attrs with Pro settings.
	 * Since control names match Gutenberg, we can pass them directly.
	 *
	 * @param array<string, mixed> $block_attrs Block attributes.
	 * @param array<string, mixed> $settings    Widget settings.
	 * @return array<string, mixed> Extended block attributes.
	 * @since 2.7.0
	 */
	public function extend_block_attrs( $block_attrs, $settings ) {
		// If inheriting styling, don't add any Pro styling attributes.
		if ( 'inherit' === ( $block_attrs['formTheme'] ?? 'inherit' ) ) {
			return $block_attrs;
		}

		// Color controls that support Elementor Global Colors.
		$color_keys = [
			// Button colors.
			'buttonTextColorNormal',
			'buttonTextColorHover',
			'buttonBackgroundColorNormal',
			'buttonBackgroundColorHover',
			'buttonBorderColorNormal',
			'buttonBorderColorHover',
			// Field colors.
			'fieldBgColor',
			'fieldLabelColor',
			'fieldInputColor',
			'fieldHelpTextColor',
			'fieldBorderColor',
			// Field box shadow colors.
			'fieldBoxShadowColorNormal',
			'fieldBoxShadowColorFocus',
			// Messages.
			'errorColor',
		];

		foreach ( $color_keys as $key ) {
			$color_value = Form_Widget::get_resolved_color( $settings, $key );
			if ( $color_value ) {
				$block_attrs[ $key ] = $color_value;
			}
		}

		// Non-color Pro styling keys (camelCase - same as Gutenberg).
		$pro_keys = [
			'formTheme',
			'formRowGap',
			'formColumnGap',
			// Button background type.
			'buttonBackgroundTypeNormal',
			'buttonBackgroundTypeHover',
			// Button typography.
			'buttonTextSize',
			'buttonLineHeight',
			// Button border style.
			'buttonBorderStyle',
			// Field label typography.
			'fieldLabelSize',
			'fieldLabelLineHeight',
			'fieldLabelGap',
			// Field help text typography.
			'fieldHelpTextSize',
			'fieldHelpTextLineHeight',
			// Field box shadow - Normal.
			'fieldBoxShadowHOffsetNormal',
			'fieldBoxShadowVOffsetNormal',
			'fieldBoxShadowBlurNormal',
			'fieldBoxShadowSpreadNormal',
			'fieldBoxShadowPositionNormal',
			// Field box shadow - Focus.
			'fieldBoxShadowHOffsetFocus',
			'fieldBoxShadowVOffsetFocus',
			'fieldBoxShadowBlurFocus',
			'fieldBoxShadowSpreadFocus',
			'fieldBoxShadowPositionFocus',
		];

		foreach ( $pro_keys as $key ) {
			if ( isset( $settings[ $key ] ) && '' !== $settings[ $key ] ) {
				// Handle slider controls (return array with size/unit).
				if ( is_array( $settings[ $key ] ) && isset( $settings[ $key ]['size'] ) ) {
					$block_attrs[ $key ]          = $settings[ $key ]['size'];
					$block_attrs[ $key . 'Unit' ] = $settings[ $key ]['unit'] ?? 'px';
				} else {
					$block_attrs[ $key ] = $settings[ $key ];
				}
			}
		}

		// Build button background gradient CSS strings from Group_Control_Background settings.
		// Normal state gradient.
		if ( 'gradient' === ( $settings['buttonBackgroundTypeNormal'] ?? '' ) ) {
			$gradient_css = $this->build_gradient_css( $settings, 'buttonBgGradientNormal' );
			if ( $gradient_css ) {
				$block_attrs['buttonBackgroundGradientNormal'] = $gradient_css;
			}
		}

		// Hover state gradient.
		if ( 'gradient' === ( $settings['buttonBackgroundTypeHover'] ?? '' ) ) {
			$gradient_css = $this->build_gradient_css( $settings, 'buttonBgGradientHover' );
			if ( $gradient_css ) {
				$block_attrs['buttonBackgroundGradientHover'] = $gradient_css;
			}
		}

		// Handle DIMENSIONS controls - map to individual camelCase keys for Gutenberg compatibility.
		$dimensions_controls = [
			'buttonPadding'      => 'buttonPadding',
			'buttonBorderRadius' => 'buttonBorderRadius',
			'buttonBorderWidth'  => 'buttonBorderWidth',
			'fieldBorderWidth'   => 'fieldBorderWidth',
			'fieldBorderRadius'  => 'fieldBorderRadius',
		];

		foreach ( $dimensions_controls as $setting_key => $attr_prefix ) {
			$block_attrs = array_merge(
				$block_attrs,
				$this->map_dimensions( $settings, $setting_key, $attr_prefix )
			);
		}

		return $block_attrs;
	}

	/**
	 * Register Pro preview assets (scripts and styles) for live preview in widget preview mode.
	 *
	 * @return void
	 * @since 2.7.0
	 */
	public function register_pro_preview_assets() {
		// Register Pro preview script.
		wp_register_script(
			'srfm-elementor-preview-styling-pro',
			SRFM_PRO_URL . 'dist/elementorPreviewStylingPro.js',
			[ 'srfm-elementor-preview-styling' ],
			SRFM_PRO_VER,
			true
		);

		// Register Pro preview styles.
		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/';
		$rtl         = is_rtl() ? '-rtl' : '';

		wp_register_style(
			'srfm-pro-custom-styles',
			$css_uri . 'custom-styles' . $file_prefix . $rtl . '.css',
			[],
			SRFM_PRO_VER
		);
	}

	/**
	 * Add Pro preview script to widget dependencies.
	 *
	 * @param array<string> $scripts Script handles.
	 * @return array<string> Modified script handles.
	 * @since 2.7.0
	 */
	public function add_pro_script_depends( $scripts ) {
		$scripts[] = 'srfm-elementor-preview-styling-pro';
		return $scripts;
	}

	/**
	 * Add Pro preview styles to widget dependencies.
	 *
	 * @param array<string> $styles Style handles.
	 * @return array<string> Modified style handles.
	 * @since 2.7.0
	 */
	public function add_pro_style_depends( $styles ) {
		$styles[] = 'srfm-pro-custom-styles';
		return $styles;
	}

	/**
	 * Add button background controls (type select, background color, gradient group) for a given state.
	 *
	 * @param \Elementor\Widget_Base $widget         The widget instance.
	 * @param string                 $state          State suffix — 'Normal' or 'Hover'.
	 * @param string                 $color1_default Default for gradient color 1.
	 * @param string                 $color2_default Default for gradient color 2.
	 * @return void
	 * @since 2.7.0
	 */
	private function add_button_background_controls( $widget, $state, $color1_default, $color2_default ) {
		$state_lower = strtolower( $state );

		$widget->add_control(
			'buttonBackgroundType' . $state,
			[
				'label'   => __( 'Background Type', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'color',
				'options' => [
					'transparent' => __( 'Transparent', 'sureforms-pro' ),
					'color'       => __( 'Color', 'sureforms-pro' ),
					'gradient'    => __( 'Gradient', 'sureforms-pro' ),
				],
			]
		);

		$widget->add_control(
			'buttonBackgroundColor' . $state,
			[
				'label'     => __( 'Background Color', 'sureforms-pro' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'buttonBackgroundType' . $state => 'color',
				],
			]
		);

		$widget->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'           => 'buttonBgGradient' . $state,
				'types'          => [ 'gradient' ],
				'fields_options' => [
					'background'        => [
						'label'   => __( 'Gradient', 'sureforms-pro' ),
						'default' => 'gradient',
					],
					'color'             => [
						'label'   => __( 'Color 1', 'sureforms-pro' ),
						'default' => $color1_default,
					],
					'color_stop'        => [
						'label'       => __( 'Location 1', 'sureforms-pro' ),
						'size_units'  => [ '%' ],
						'responsive'  => false,
						'description' => '',
					],
					'color_b'           => [
						'label'   => __( 'Color 2', 'sureforms-pro' ),
						'default' => $color2_default,
					],
					'color_b_stop'      => [
						'label'       => __( 'Location 2', 'sureforms-pro' ),
						'size_units'  => [ '%' ],
						'responsive'  => false,
						'description' => '',
					],
					'gradient_type'     => [],
					'gradient_angle'    => [
						'label'       => __( 'Angle', 'sureforms-pro' ),
						'size_units'  => [ 'deg' ],
						'responsive'  => false,
						'description' => '',
					],
					// Hide position control - use 'center center' as default for radial gradients.
					'gradient_position' => [
						'default' => 'center center',
						'type'    => \Elementor\Controls_Manager::HIDDEN,
					],
				],
				'selector'       => '{{WRAPPER}} .srfm-btn-gradient-' . $state_lower . '-dummy',
				'condition'      => [
					'buttonBackgroundType' . $state => 'gradient',
				],
			]
		);
	}

	/**
	 * Add box shadow sub-controls (color, offsets, blur, spread, position) for a given state.
	 *
	 * @param \Elementor\Widget_Base $widget  The widget instance.
	 * @param string                 $state   State suffix — 'Normal' or 'Focus'.
	 * @param array<string, int>     $options Override defaults. Supports 'spread_default'.
	 * @return void
	 * @since 2.7.0
	 */
	private function add_box_shadow_controls( $widget, $state, $options = [] ) {
		$spread_default = $options['spread_default'] ?? 0;

		$widget->add_control(
			'fieldBoxShadowColor' . $state,
			[
				'label' => __( 'Color', 'sureforms-pro' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
			]
		);

		$widget->add_control(
			'fieldBoxShadowHOffset' . $state,
			[
				'label'   => __( 'Horizontal', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 0,
				'min'     => -30,
				'max'     => 30,
			]
		);

		$widget->add_control(
			'fieldBoxShadowVOffset' . $state,
			[
				'label'   => __( 'Vertical', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 0,
				'min'     => -30,
				'max'     => 30,
			]
		);

		$widget->add_control(
			'fieldBoxShadowBlur' . $state,
			[
				'label'   => __( 'Blur', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 0,
				'min'     => 0,
				'max'     => 100,
			]
		);

		$widget->add_control(
			'fieldBoxShadowSpread' . $state,
			[
				'label'   => __( 'Spread', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => $spread_default,
				'min'     => -30,
				'max'     => 30,
			]
		);

		$widget->add_control(
			'fieldBoxShadowPosition' . $state,
			[
				'label'   => __( 'Position', 'sureforms-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'outset',
				'options' => [
					'outset' => __( 'Outset', 'sureforms-pro' ),
					'inset'  => __( 'Inset', 'sureforms-pro' ),
				],
			]
		);
	}

	/**
	 * Map Elementor DIMENSIONS control values to individual block attributes.
	 *
	 * @param array<string, mixed> $settings    Widget settings.
	 * @param string               $setting_key The DIMENSIONS control key in settings.
	 * @param string               $attr_prefix The attribute prefix for output keys.
	 * @return array<string, string> Mapped attributes with Top/Right/Bottom/Left suffixes.
	 * @since 2.7.0
	 */
	private function map_dimensions( $settings, $setting_key, $attr_prefix ) {
		$attrs = [];

		if ( empty( $settings[ $setting_key ] ) || ! is_array( $settings[ $setting_key ] ) ) {
			return $attrs;
		}

		$dims          = $settings[ $setting_key ];
		$allowed_units = [ 'px', '%', 'em', 'rem' ];
		$unit          = in_array( $dims['unit'] ?? 'px', $allowed_units, true ) ? ( $dims['unit'] ?? 'px' ) : 'px';

		$sides = [ 'top', 'right', 'bottom', 'left' ];
		foreach ( $sides as $side ) {
			if ( ! empty( $dims[ $side ] ) || '0' === ( $dims[ $side ] ?? null ) ) {
				$attrs[ $attr_prefix . ucfirst( $side ) ] = (string) floatval( $dims[ $side ] );
			}
		}

		$attrs[ $attr_prefix . 'Unit' ] = $unit;

		return $attrs;
	}

	/**
	 * Build CSS gradient string from Group_Control_Background settings.
	 *
	 * Constructs a CSS gradient value from Elementor's gradient control settings.
	 * Supports both linear and radial gradients with color stops.
	 *
	 * @param array<string, mixed> $settings Widget settings containing gradient values.
	 * @param string               $prefix   The group control name prefix (e.g., 'buttonBgGradientNormal').
	 * @return string|null CSS gradient string or null if colors not set.
	 * @since 2.7.0
	 */
	private function build_gradient_css( $settings, $prefix ) {
		// Get gradient colors - resolve global colors if used.
		$color_1 = Form_Widget::get_resolved_color( $settings, $prefix . '_color' );
		$color_2 = Form_Widget::get_resolved_color( $settings, $prefix . '_color_b' );

		// Both colors are required.
		if ( ! $color_1 || ! $color_2 ) {
			return null;
		}

		// Get gradient settings with defaults - use Helper::get_string_value for type safety.
		$type = isset( $settings[ $prefix . '_gradient_type' ] ) && '' !== $settings[ $prefix . '_gradient_type' ]
			? Helper::get_string_value( $settings[ $prefix . '_gradient_type' ] )
			: 'linear';

		// Get angle settings.
		$angle_settings = isset( $settings[ $prefix . '_gradient_angle' ] ) && is_array( $settings[ $prefix . '_gradient_angle' ] )
			? $settings[ $prefix . '_gradient_angle' ]
			: [];
		$angle          = isset( $angle_settings['size'] ) ? Helper::get_string_value( $angle_settings['size'] ) : '180';
		$angle_unit     = isset( $angle_settings['unit'] ) ? Helper::get_string_value( $angle_settings['unit'] ) : 'deg';

		// Get position for radial gradients.
		$position = isset( $settings[ $prefix . '_gradient_position' ] ) && '' !== $settings[ $prefix . '_gradient_position' ]
			? Helper::get_string_value( $settings[ $prefix . '_gradient_position' ] )
			: 'center center';

		// Get color 1 stop settings.
		$color_1_settings = isset( $settings[ $prefix . '_color_stop' ] ) && is_array( $settings[ $prefix . '_color_stop' ] )
			? $settings[ $prefix . '_color_stop' ]
			: [];
		$color_1_stop     = isset( $color_1_settings['size'] ) ? Helper::get_string_value( $color_1_settings['size'] ) : '0';
		$color_1_unit     = isset( $color_1_settings['unit'] ) ? Helper::get_string_value( $color_1_settings['unit'] ) : '%';

		// Get color 2 stop settings.
		$color_2_settings = isset( $settings[ $prefix . '_color_b_stop' ] ) && is_array( $settings[ $prefix . '_color_b_stop' ] )
			? $settings[ $prefix . '_color_b_stop' ]
			: [];
		$color_2_stop     = isset( $color_2_settings['size'] ) ? Helper::get_string_value( $color_2_settings['size'] ) : '100';
		$color_2_unit     = isset( $color_2_settings['unit'] ) ? Helper::get_string_value( $color_2_settings['unit'] ) : '%';

		// Sanitize values — use floatval() for numeric values, sanitize_css_value() for colors/position.
		$color_1      = Helper::sanitize_css_value( $color_1 );
		$color_2      = Helper::sanitize_css_value( $color_2 );
		$position     = Helper::sanitize_css_value( $position );
		$angle        = floatval( $angle );
		$angle_unit   = in_array( $angle_unit, [ 'deg', 'grad', 'rad', 'turn' ], true ) ? $angle_unit : 'deg';
		$color_1_stop = floatval( $color_1_stop );
		$color_1_unit = in_array( $color_1_unit, [ '%', 'px', 'em' ], true ) ? $color_1_unit : '%';
		$color_2_stop = floatval( $color_2_stop );
		$color_2_unit = in_array( $color_2_unit, [ '%', 'px', 'em' ], true ) ? $color_2_unit : '%';

		// Build the gradient string.
		if ( 'radial' === $type ) {
			// Radial gradient: radial-gradient(at position, color1 stop1, color2 stop2).
			return sprintf(
				'radial-gradient(at %s, %s %s%s, %s %s%s)',
				$position,
				$color_1,
				$color_1_stop,
				$color_1_unit,
				$color_2,
				$color_2_stop,
				$color_2_unit
			);
		}

		// Linear gradient: linear-gradient(angle, color1 stop1, color2 stop2).
		return sprintf(
			'linear-gradient(%s%s, %s %s%s, %s %s%s)',
			$angle,
			$angle_unit,
			$color_1,
			$color_1_stop,
			$color_1_unit,
			$color_2,
			$color_2_stop,
			$color_2_unit
		);
	}
}
