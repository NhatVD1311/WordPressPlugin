<?php
/**
 * Bricks Form Widget - Pro Extension.
 *
 * Adds Pro styling controls to the SureForms Bricks widget.
 *
 * @package sureforms-pro
 * @since 2.7.0
 */

namespace SRFM_Pro\Inc\Page_Builders\Bricks;

use SRFM\Inc\Helper;
use SRFM\Inc\Page_Builders\Bricks\Elements\Form_Widget;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Form_Widget_Pro Class.
 *
 * @since 2.7.0
 */
class Form_Widget_Pro {
	use Get_Instance;

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 2.7.0
	 */
	public function __construct() {
		// Add Form Theme control before basic controls (priority 5).
		add_action( 'srfm_bricks_after_basic_styling_controls', [ $this, 'add_form_theme_control' ], 5 );

		// Add Pro controls to existing groups.
		add_action( 'srfm_bricks_layout_controls', [ $this, 'add_layout_controls' ] );
		add_action( 'srfm_bricks_button_controls', [ $this, 'add_button_controls' ] );
		add_action( 'srfm_bricks_field_controls', [ $this, 'add_field_controls' ] );

		// Add Messages section after all styling groups.
		add_action( 'srfm_bricks_after_styling_section', [ $this, 'add_messages_controls' ] );

		// Extend block_attrs with Pro settings.
		add_filter( 'srfm_bricks_block_attrs', [ $this, 'extend_block_attrs' ], 10, 2 );
	}

	/**
	 * Add Form Theme control.
	 *
	 * @param Form_Widget $element The element instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_form_theme_control( $element ) {
		$element->controls['formTheme'] = [
			'group'    => 'srfm_form_styling',
			'label'    => __( 'Form Theme', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'inherit' => __( "Inherit Form's Original Style", 'sureforms-pro' ),
				'default' => __( 'Default', 'sureforms-pro' ),
				'custom'  => __( 'Custom', 'sureforms-pro' ),
			],
			'default'  => 'inherit',
			'required' => [
				[ 'form-id', '!=', '' ],
			],
		];
	}

	/**
	 * Add Pro Layout controls.
	 *
	 * @param Form_Widget $element The element instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_layout_controls( $element ) {
		$custom_required = self::get_custom_theme_required();

		$element->controls['formRowGap'] = [
			'group'    => 'srfm_layout',
			'label'    => __( 'Row Gap (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 18,
			'min'      => 0,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['formColumnGap'] = [
			'group'    => 'srfm_layout',
			'label'    => __( 'Column Gap (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 16,
			'min'      => 0,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];
	}

	/**
	 * Add Pro Button controls.
	 *
	 * @param Form_Widget $element The element instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_button_controls( $element ) {
		$custom_required = self::get_custom_theme_required();

		// Button Padding.
		$element->controls['buttonPadding'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Padding', 'sureforms-pro' ),
			'type'     => 'spacing',
			'css'      => [
				[
					'property' => '--srfm-button-padding-{key}',
					'selector' => '.srfm-form-container',
				],
			],
			'default'  => [
				'top'    => '10',
				'right'  => '14',
				'bottom' => '10',
				'left'   => '14',
				'unit'   => 'px',
			],
			'required' => $custom_required,
		];

		// --- Normal State ---
		$element->controls['buttonNormalSeparator'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Normal State', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['buttonTextColorNormal'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Text Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		$element->controls['buttonBackgroundTypeNormal'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Background Type', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'transparent' => __( 'Transparent', 'sureforms-pro' ),
				'color'       => __( 'Color', 'sureforms-pro' ),
				'gradient'    => __( 'Gradient', 'sureforms-pro' ),
			],
			'default'  => 'color',
			'required' => $custom_required,
		];

		$element->controls['buttonBackgroundColorNormal'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Background Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => array_merge( $custom_required, [ [ 'buttonBackgroundTypeNormal', '=', 'color' ] ] ),
		];

		// Normal Gradient Controls.
		$normal_gradient_required = array_merge( $custom_required, [ [ 'buttonBackgroundTypeNormal', '=', 'gradient' ] ] );

		$element->controls['buttonBgNormalGradientColor1'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Color 1', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $normal_gradient_required,
		];

		$element->controls['buttonBgNormalGradientColor1Stop'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Color 1 Location (%)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => 0,
			'max'      => 100,
			'unit'     => '%',
			'required' => $normal_gradient_required,
		];

		$element->controls['buttonBgNormalGradientColor2'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Color 2', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $normal_gradient_required,
		];

		$element->controls['buttonBgNormalGradientColor2Stop'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Color 2 Location (%)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 100,
			'min'      => 0,
			'max'      => 100,
			'unit'     => '%',
			'required' => $normal_gradient_required,
		];

		$element->controls['buttonBgNormalGradientType'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Type', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'linear' => __( 'Linear', 'sureforms-pro' ),
				'radial' => __( 'Radial', 'sureforms-pro' ),
			],
			'default'  => 'linear',
			'required' => $normal_gradient_required,
		];

		$element->controls['buttonBgNormalGradientAngle'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Angle', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 90,
			'min'      => 0,
			'max'      => 360,
			'unit'     => 'deg',
			'required' => array_merge( $normal_gradient_required, [ [ 'buttonBgNormalGradientType', '=', 'linear' ] ] ),
		];

		$element->controls['buttonBorderColorNormal'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		// --- Hover State ---
		$element->controls['buttonHoverSeparator'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Hover State', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['buttonTextColorHover'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Text Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		$element->controls['buttonBackgroundTypeHover'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Background Type', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'transparent' => __( 'Transparent', 'sureforms-pro' ),
				'color'       => __( 'Color', 'sureforms-pro' ),
				'gradient'    => __( 'Gradient', 'sureforms-pro' ),
			],
			'default'  => 'color',
			'required' => $custom_required,
		];

		$element->controls['buttonBackgroundColorHover'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Background Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => array_merge( $custom_required, [ [ 'buttonBackgroundTypeHover', '=', 'color' ] ] ),
		];

		// Hover Gradient Controls.
		$hover_gradient_required = array_merge( $custom_required, [ [ 'buttonBackgroundTypeHover', '=', 'gradient' ] ] );

		$element->controls['buttonBgHoverGradientColor1'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Color 1', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $hover_gradient_required,
		];

		$element->controls['buttonBgHoverGradientColor1Stop'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Color 1 Location (%)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => 0,
			'max'      => 100,
			'unit'     => '%',
			'required' => $hover_gradient_required,
		];

		$element->controls['buttonBgHoverGradientColor2'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Color 2', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $hover_gradient_required,
		];

		$element->controls['buttonBgHoverGradientColor2Stop'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Color 2 Location (%)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 100,
			'min'      => 0,
			'max'      => 100,
			'unit'     => '%',
			'required' => $hover_gradient_required,
		];

		$element->controls['buttonBgHoverGradientType'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Gradient Type', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'linear' => __( 'Linear', 'sureforms-pro' ),
				'radial' => __( 'Radial', 'sureforms-pro' ),
			],
			'default'  => 'linear',
			'required' => $hover_gradient_required,
		];

		$element->controls['buttonBgHoverGradientAngle'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Angle', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 90,
			'min'      => 0,
			'max'      => 360,
			'unit'     => 'deg',
			'required' => array_merge( $hover_gradient_required, [ [ 'buttonBgHoverGradientType', '=', 'linear' ] ] ),
		];

		$element->controls['buttonBorderColorHover'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		// --- Typography ---
		$element->controls['buttonTypographySeparator'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Typography', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['buttonTextSize'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Font Size (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 16,
			'min'      => 8,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['buttonLineHeight'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Line Height (em)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 1.5,
			'min'      => 0.5,
			'max'      => 5,
			'step'     => 0.1,
			'unit'     => 'em',
			'required' => $custom_required,
		];

		// --- Border ---
		$element->controls['buttonBorderSeparator'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['buttonBorderStyle'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border Style', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'none'   => __( 'None', 'sureforms-pro' ),
				'solid'  => __( 'Solid', 'sureforms-pro' ),
				'dashed' => __( 'Dashed', 'sureforms-pro' ),
				'dotted' => __( 'Dotted', 'sureforms-pro' ),
				'double' => __( 'Double', 'sureforms-pro' ),
			],
			'default'  => 'solid',
			'required' => $custom_required,
		];

		$element->controls['buttonBorderWidth'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border Width', 'sureforms-pro' ),
			'type'     => 'spacing',
			'css'      => [
				[
					'property' => '--srfm-button-border-width-{key}',
					'selector' => '.srfm-form-container',
				],
			],
			'default'  => [
				'top'    => '1',
				'right'  => '1',
				'bottom' => '1',
				'left'   => '1',
				'unit'   => 'px',
			],
			'required' => $custom_required,
		];

		$element->controls['buttonBorderRadius'] = [
			'group'    => 'srfm_button',
			'label'    => __( 'Border Radius', 'sureforms-pro' ),
			'type'     => 'spacing',
			'css'      => [
				[
					'property' => '--srfm-button-border-radius-{key}',
					'selector' => '.srfm-form-container',
				],
			],
			'default'  => [
				'top'    => '6',
				'right'  => '6',
				'bottom' => '6',
				'left'   => '6',
				'unit'   => 'px',
			],
			'required' => $custom_required,
		];
	}

	/**
	 * Add Pro Field controls.
	 *
	 * @param Form_Widget $element The element instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_field_controls( $element ) {
		$custom_required = self::get_custom_theme_required();

		// --- Colors ---
		$element->controls['fieldColorsSeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Colors', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldBgColor'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Background Color', 'sureforms-pro' ),
			'type'     => 'color',
			'default'  => '#FBFBFB',
			'required' => $custom_required,
		];

		$element->controls['fieldLabelColor'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Label Color', 'sureforms-pro' ),
			'type'     => 'color',
			'default'  => '#1E1E1E',
			'required' => $custom_required,
		];

		$element->controls['fieldInputColor'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Input Text Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		$element->controls['fieldHelpTextColor'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Help Text Color', 'sureforms-pro' ),
			'type'     => 'color',
			'default'  => '#1E1E1EA6',
			'required' => $custom_required,
		];

		// --- Label Typography ---
		$element->controls['fieldLabelTypographySeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Label Typography', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldLabelSize'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Font Size (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 16,
			'min'      => 8,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldLabelLineHeight'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Line Height (em)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 1.5,
			'min'      => 0.5,
			'max'      => 5,
			'step'     => 0.1,
			'unit'     => 'em',
			'required' => $custom_required,
		];

		$element->controls['fieldLabelGap'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Label Gap (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 6,
			'min'      => 0,
			'max'      => 50,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		// --- Help Text Typography ---
		$element->controls['fieldHelpTextTypographySeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Help Text Typography', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldHelpTextSize'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Font Size (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 14,
			'min'      => 8,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldHelpTextLineHeight'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Line Height (em)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 1.4,
			'min'      => 0.5,
			'max'      => 5,
			'step'     => 0.1,
			'unit'     => 'em',
			'required' => $custom_required,
		];

		// --- Border ---
		$element->controls['fieldBorderSeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Border', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldBorderColor'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Border Color', 'sureforms-pro' ),
			'type'     => 'color',
			'default'  => '#C4C4C4',
			'required' => $custom_required,
		];

		$element->controls['fieldBorderWidth'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Border Width', 'sureforms-pro' ),
			'type'     => 'spacing',
			'css'      => [
				[
					'property' => '--srfm-field-border-width-{key}',
					'selector' => '.srfm-form-container',
				],
			],
			'default'  => [
				'top'    => '1',
				'right'  => '1',
				'bottom' => '1',
				'left'   => '1',
				'unit'   => 'px',
			],
			'required' => $custom_required,
		];

		$element->controls['fieldBorderRadius'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Border Radius', 'sureforms-pro' ),
			'type'     => 'spacing',
			'css'      => [
				[
					'property' => '--srfm-field-border-radius-{key}',
					'selector' => '.srfm-form-container',
				],
			],
			'default'  => [
				'top'    => '6',
				'right'  => '6',
				'bottom' => '6',
				'left'   => '6',
				'unit'   => 'px',
			],
			'required' => $custom_required,
		];

		// --- Input Shadow ---
		$element->controls['fieldBoxShadowSeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Input Shadow', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		// --- Normal State ---
		$element->controls['fieldBoxShadowNormalSeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Normal State', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowColorNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowHOffsetNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Horizontal Offset (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowVOffsetNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Vertical Offset (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowBlurNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Blur (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => 0,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowSpreadNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Spread (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowPositionNormal'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Position', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'outset' => __( 'Outset', 'sureforms-pro' ),
				'inset'  => __( 'Inset', 'sureforms-pro' ),
			],
			'default'  => 'outset',
			'required' => $custom_required,
		];

		// --- Focus State ---
		$element->controls['fieldBoxShadowFocusSeparator'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Focus State', 'sureforms-pro' ),
			'type'     => 'separator',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowColorFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Color', 'sureforms-pro' ),
			'type'     => 'color',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowHOffsetFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Horizontal Offset (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowVOffsetFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Vertical Offset (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowBlurFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Blur (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 0,
			'min'      => 0,
			'max'      => 100,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowSpreadFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Spread (px)', 'sureforms-pro' ),
			'type'     => 'number',
			'default'  => 3,
			'min'      => -30,
			'max'      => 30,
			'unit'     => 'px',
			'required' => $custom_required,
		];

		$element->controls['fieldBoxShadowPositionFocus'] = [
			'group'    => 'srfm_fields',
			'label'    => __( 'Position', 'sureforms-pro' ),
			'type'     => 'select',
			'options'  => [
				'outset' => __( 'Outset', 'sureforms-pro' ),
				'inset'  => __( 'Inset', 'sureforms-pro' ),
			],
			'default'  => 'outset',
			'required' => $custom_required,
		];
	}

	/**
	 * Add Messages controls.
	 * Creates a new Messages control group dynamically.
	 *
	 * @param Form_Widget $element The element instance.
	 * @return void
	 * @since 2.7.0
	 */
	public function add_messages_controls( $element ) {
		$custom_required = self::get_custom_theme_required();

		// Register Messages group dynamically.
		$element->control_groups['srfm_messages'] = [
			'title'    => __( 'Messages', 'sureforms-pro' ),
			'tab'      => 'style',
			'required' => $custom_required,
		];

		$element->controls['errorColor'] = [
			'group'    => 'srfm_messages',
			'label'    => __( 'Error Color', 'sureforms-pro' ),
			'type'     => 'color',
			'default'  => '#dc2626',
			'required' => $custom_required,
		];
	}

	/**
	 * Extend block_attrs with Pro settings.
	 *
	 * @param array<string, mixed> $block_attrs Block attributes.
	 * @param array<string, mixed> $settings    Bricks element settings.
	 * @return array<string, mixed> Extended block attributes.
	 * @since 2.7.0
	 */
	public function extend_block_attrs( $block_attrs, $settings ) {
		// If inheriting styling, don't add any Pro styling attributes.
		if ( 'inherit' === ( $block_attrs['formTheme'] ?? 'inherit' ) ) {
			return $block_attrs;
		}

		// Only apply Pro styling when form theme is 'custom'.
		if ( 'custom' !== ( $settings['formTheme'] ?? 'default' ) ) {
			return $block_attrs;
		}

		// Color controls.
		$color_keys = [
			// Button colors.
			'buttonTextColorNormal',
			'buttonTextColorHover',
			'buttonBackgroundColorNormal',
			'buttonBackgroundColorHover',
			'buttonBorderColorNormal',
			'buttonBorderColorHover',
			// Field colors.
			'fieldBgColor',
			'fieldLabelColor',
			'fieldInputColor',
			'fieldHelpTextColor',
			'fieldBorderColor',
			// Field box shadow colors.
			'fieldBoxShadowColorNormal',
			'fieldBoxShadowColorFocus',
			// Messages.
			'errorColor',
		];

		foreach ( $color_keys as $key ) {
			$raw   = $settings[ $key ] ?? null;
			$color = Form_Widget::resolve_bricks_color( is_string( $raw ) || is_array( $raw ) ? $raw : null );
			if ( $color ) {
				$block_attrs[ $key ] = $color;
			}
		}

		// Enum keys — validate against allowlists.
		$enum_keys = [
			'formTheme'                    => [ 'inherit', 'default', 'custom' ],
			'buttonBackgroundTypeNormal'   => [ 'transparent', 'color', 'gradient' ],
			'buttonBackgroundTypeHover'    => [ 'transparent', 'color', 'gradient' ],
			'buttonBorderStyle'            => [ 'none', 'solid', 'dashed', 'dotted', 'double' ],
			'fieldBoxShadowPositionNormal' => [ 'outset', 'inset' ],
			'fieldBoxShadowPositionFocus'  => [ 'outset', 'inset' ],
		];

		foreach ( $enum_keys as $key => $allowed ) {
			if ( isset( $settings[ $key ] ) && in_array( $settings[ $key ], $allowed, true ) ) {
				$block_attrs[ $key ] = $settings[ $key ];
			}
		}

		// Numeric keys — sanitize with floatval().
		$numeric_keys = [
			'buttonTextSize',
			'buttonLineHeight',
			'fieldLabelSize',
			'fieldLabelLineHeight',
			'fieldLabelGap',
			'fieldHelpTextSize',
			'fieldHelpTextLineHeight',
			// Field box shadow.
			'fieldBoxShadowHOffsetNormal',
			'fieldBoxShadowVOffsetNormal',
			'fieldBoxShadowBlurNormal',
			'fieldBoxShadowSpreadNormal',
			'fieldBoxShadowHOffsetFocus',
			'fieldBoxShadowVOffsetFocus',
			'fieldBoxShadowBlurFocus',
			'fieldBoxShadowSpreadFocus',
		];

		foreach ( $numeric_keys as $key ) {
			if ( isset( $settings[ $key ] ) && '' !== $settings[ $key ] ) {
				$block_attrs[ $key ] = floatval( Helper::get_string_value( $settings[ $key ] ) );
			}
		}

		// Number controls that need a unit key appended.
		$number_with_unit = [
			'formRowGap'    => 'px',
			'formColumnGap' => 'px',
		];

		foreach ( $number_with_unit as $key => $default_unit ) {
			if ( isset( $settings[ $key ] ) && '' !== $settings[ $key ] ) {
				$block_attrs[ $key ]          = floatval( Helper::get_string_value( $settings[ $key ] ) );
				$block_attrs[ $key . 'Unit' ] = $default_unit;
			}
		}

		// Button gradient CSS strings.
		if ( 'gradient' === ( $settings['buttonBackgroundTypeNormal'] ?? '' ) ) {
			$gradient = Form_Widget::build_bricks_gradient_css( $settings, 'buttonBgNormal' );
			if ( $gradient ) {
				$block_attrs['buttonBackgroundGradientNormal'] = $gradient;
			}
		}

		if ( 'gradient' === ( $settings['buttonBackgroundTypeHover'] ?? '' ) ) {
			$gradient = Form_Widget::build_bricks_gradient_css( $settings, 'buttonBgHover' );
			if ( $gradient ) {
				$block_attrs['buttonBackgroundGradientHover'] = $gradient;
			}
		}

		// Spacing controls (4-sided).
		$spacing_controls = [
			'buttonPadding'      => 'buttonPadding',
			'buttonBorderWidth'  => 'buttonBorderWidth',
			'buttonBorderRadius' => 'buttonBorderRadius',
			'fieldBorderWidth'   => 'fieldBorderWidth',
			'fieldBorderRadius'  => 'fieldBorderRadius',
		];

		foreach ( $spacing_controls as $setting_key => $attr_prefix ) {
			$mapped = Form_Widget::map_bricks_spacing( $settings, $setting_key, $attr_prefix );
			$dims   = $settings[ $setting_key ] ?? null;
			if ( ! empty( $mapped ) && is_array( $dims ) && isset( $dims['unit'] ) ) {
				$block_attrs[ $attr_prefix . 'Unit' ] = $dims['unit'];
			}
			$block_attrs = array_merge( $block_attrs, $mapped );
		}

		return $block_attrs;
	}

	/**
	 * Get the 'required' condition array for custom-theme-only controls.
	 *
	 * @return array<int, array<int, string>>
	 * @since 2.7.0
	 */
	private static function get_custom_theme_required() {
		return [
			[ 'form-id', '!=', '' ],
			[ 'formTheme', '=', 'custom' ],
		];
	}
}
