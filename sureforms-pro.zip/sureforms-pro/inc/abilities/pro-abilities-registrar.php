<?php
/**
 * Pro Abilities Registrar.
 *
 * Coordinates pro extensions for core SureForms abilities.
 *
 * @package sureforms-pro
 * @since 2.5.2
 */

namespace SRFM_Pro\Inc\Abilities;

use SRFM_Pro\Inc\Abilities\Extensions\Create_Form_Extension;
use SRFM_Pro\Inc\Abilities\Extensions\Html_Form_Detector_Extension;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Pro_Abilities_Registrar class.
 *
 * Slim coordinator that loads per-ability extension classes.
 *
 * @since 2.5.2
 */
class Pro_Abilities_Registrar {
	use Get_Instance;

	/**
	 * Stored extension instance for future access/unregistration.
	 *
	 * @var Create_Form_Extension|null
	 * @since 2.5.2
	 */
	private $create_form_extension = null;

	/**
	 * Stored HTML form detector extension instance.
	 *
	 * @var Html_Form_Detector_Extension|null
	 * @since 2.10.0
	 */
	private $html_form_detector_extension = null;

	/**
	 * Constructor.
	 *
	 * Loads pro extensions for each core ability.
	 * Guards on the free registrar class rather than wp_register_ability()
	 * to make the dependency on core abilities explicit.
	 *
	 * @since 2.5.2
	 */
	public function __construct() {
		// Only load if the core abilities registrar is available.
		if ( ! class_exists( 'SRFM\Inc\Abilities\Abilities_Registrar' ) ) {
			return;
		}

		// Wrap each extension instantiation in its own try/catch — if
		// a future extension's constructor ever throws (e.g. it tries
		// to reach a service that is briefly unavailable during
		// plugin bootstrap), we still want the remaining extensions
		// to load. We swallow the `Throwable` silently rather than
		// logging it; the registrar's contract is best-effort, and
		// production sites should never see a stack trace surface
		// from a non-critical pro extension. Caller code checks the
		// `get_*_extension()` accessor for null before using the
		// instance.
		//
		// The catch blocks are intentionally per-extension (not a
		// shared helper) so PHPStan can narrow each property's
		// concrete type — a generic factory helper returning
		// `object|null` would conflict with the typed property
		// declarations.
		try {
			$this->create_form_extension = new Create_Form_Extension();
		} catch ( \Throwable $unused ) {
			$this->create_form_extension = null;
		}

		try {
			$this->html_form_detector_extension = new Html_Form_Detector_Extension();
		} catch ( \Throwable $unused ) {
			$this->html_form_detector_extension = null;
		}
	}

	/**
	 * Get the create-form extension instance.
	 *
	 * @since 2.5.2
	 * @return Create_Form_Extension|null
	 */
	public function get_create_form_extension() {
		return $this->create_form_extension;
	}

	/**
	 * Get the HTML-form-detector extension instance.
	 *
	 * @since 2.10.0
	 * @return Html_Form_Detector_Extension|null
	 */
	public function get_html_form_detector_extension() {
		return $this->html_form_detector_extension;
	}
}
