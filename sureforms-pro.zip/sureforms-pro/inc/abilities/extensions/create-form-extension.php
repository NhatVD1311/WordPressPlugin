<?php
/**
 * Create Form Extension.
 *
 * Pro extensions for the sureforms/create-form ability.
 *
 * @package sureforms-pro
 * @since 2.5.2
 */

namespace SRFM_Pro\Inc\Abilities\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Create_Form_Extension class.
 *
 * Adds pro field types, properties, and description extensions
 * to the core create-form ability via filters.
 *
 * @since 2.5.2
 */
class Create_Form_Extension {
	/**
	 * Pro field type slugs — single source of truth for types, description, and tests.
	 *
	 * @since 2.5.2
	 */
	public const PRO_FIELD_TYPES = [
		'hidden',
		'rating',
		'upload',
		'date-picker',
		'time-picker',
		'number-slider',
		// `slider` is the actual block slug (`srfm/slider`) and the
		// value `Field_Mapping` switch-cases on. `number-slider` was
		// declared here historically but has no matching case in
		// `Field_Mapping`. The `normalize_legacy_slugs` filter below
		// rewrites `number-slider` → `slider` on the way through, so
		// the enum can stay backwards-compatible for any pre-existing
		// AI / MCP payload AND actually round-trip to a `srfm/slider`
		// block instead of silently falling through to a plain
		// `srfm/input`.
		'slider',
		'signature',
		'page-break',
	];

	/**
	 * Filter priority — late to ensure core schema is built first.
	 *
	 * @since 2.5.2
	 */
	private const FILTER_PRIORITY = 20;

	/**
	 * Constructor.
	 *
	 * Registers filters for the create-form ability.
	 *
	 * @since 2.5.2
	 */
	public function __construct() {
		add_filter( 'srfm_ability_form_field_types', [ $this, 'add_pro_field_types' ], self::FILTER_PRIORITY );
		add_filter( 'srfm_ability_create_form_description', [ $this, 'extend_description' ], self::FILTER_PRIORITY );
		add_filter( 'srfm_ability_form_field_properties', [ $this, 'add_pro_field_properties' ], self::FILTER_PRIORITY );

		// Map the legacy `number-slider` slug onto `slider` so payloads
		// from older AI / MCP callers actually round-trip to a
		// `srfm/slider` block. The PRO_FIELD_TYPES enum still accepts
		// `number-slider` (so existing payloads pass schema validation
		// instead of erroring), but the `Field_Mapping` switch in free
		// only knows `slider` — without this normalization the field
		// would silently fall through to a plain `srfm/input`. Filter
		// fires before the switch in `generate_gutenberg_fields_from_questions`.
		add_filter( 'srfm_ai_field_modify_field_type', [ $this, 'normalize_legacy_slugs' ], self::FILTER_PRIORITY );
	}

	/**
	 * Normalize legacy field-type slugs to their canonical form.
	 *
	 * Single-purpose hook: ensure `number-slider` (kept in
	 * `PRO_FIELD_TYPES` for schema-validation back-compat) is
	 * translated to `slider` before the field-mapping switch sees it.
	 *
	 * @since 2.10.0
	 * @param string|mixed $field_type Incoming field type slug.
	 * @return string
	 */
	public function normalize_legacy_slugs( $field_type ) {
		if ( ! is_string( $field_type ) ) {
			return '';
		}
		if ( 'number-slider' === $field_type ) {
			return 'slider';
		}
		return $field_type;
	}

	/**
	 * Add pro field type slugs to the create-form ability.
	 *
	 * @param array<string>|mixed $field_types Core field types.
	 * @since 2.5.2
	 * @return array<string>
	 */
	public function add_pro_field_types( $field_types ) {
		if ( ! is_array( $field_types ) ) {
			$field_types = [];
		}

		return array_merge( $field_types, self::PRO_FIELD_TYPES );
	}

	/**
	 * Append pro field types to the ability description.
	 *
	 * @param string|mixed $description Core ability description.
	 * @since 2.5.2
	 * @return string
	 */
	public function extend_description( $description ) {
		if ( ! is_string( $description ) ) {
			$description = '';
		}

		$types_list = implode( ', ', self::PRO_FIELD_TYPES );

		return $description . ' ' . sprintf(
			/* translators: %s: comma-separated list of pro field types. */
			__( 'Also supports pro field types when SureForms Pro is active (%s).', 'sureforms-pro' ),
			$types_list
		);
	}

	/**
	 * Add pro field schema properties for upload, rating, date-picker, time-picker,
	 * signature, and page-break fields.
	 *
	 * @param array<string,array<string,mixed>>|mixed $properties Existing additional properties.
	 * @since 2.5.2
	 * @return array<string,array<string,mixed>>
	 */
	public function add_pro_field_properties( $properties ) {
		if ( ! is_array( $properties ) ) {
			$properties = [];
		}

		$pro_properties = [
			// Upload field properties.
			'uploadSize'          => [
				'type'        => 'integer',
				'description' => __( 'Max upload file size in MB (1-100).', 'sureforms-pro' ),
			],
			'allowedTypes'        => [
				'type'        => 'string',
				'description' => __( 'Allowed file types for upload. e.g. jpg, jpeg, gif, png, pdf', 'sureforms-pro' ),
			],
			'multiUpload'         => [
				'type'        => 'boolean',
				'description' => __( 'Allow multiple file uploads.', 'sureforms-pro' ),
			],
			'multiFilesNumber'    => [
				'type'        => 'integer',
				'description' => __( 'Max number of files when multiUpload is true.', 'sureforms-pro' ),
			],
			// Rating field properties.
			'iconShape'           => [
				'type'        => 'string',
				'description' => __( 'Icon shape for rating field: star, smiley, or thumb.', 'sureforms-pro' ),
				'enum'        => [ 'star', 'smiley', 'thumb' ],
			],
			'defaultRating'       => [
				'type'        => 'integer',
				'description' => __( 'Default rating value (1-5).', 'sureforms-pro' ),
			],
			'showTooltip'         => [
				'type'        => 'boolean',
				'description' => __( 'Show tooltips for rating field.', 'sureforms-pro' ),
			],
			'tooltipValues'       => [
				'type'        => 'array',
				'description' => __( 'Tooltip labels for each rating value.', 'sureforms-pro' ),
				'items'       => [
					'type'       => 'object',
					'properties' => [
						'value' => [
							'type'        => 'integer',
							'description' => __( 'Rating value (1-5).', 'sureforms-pro' ),
						],
						'label' => [
							'type'        => 'string',
							'description' => __( 'Tooltip text for this rating value.', 'sureforms-pro' ),
						],
					],
				],
			],
			// Date-picker field properties.
			'dateFormat'          => [
				'type'        => 'string',
				'description' => __( 'Date format: mm/dd/yyyy or dd/mm/yyyy.', 'sureforms-pro' ),
			],
			'minDate'             => [
				'type'        => 'string',
				'description' => __( 'Minimum date in yyyy/mm/dd format.', 'sureforms-pro' ),
			],
			'maxDate'             => [
				'type'        => 'string',
				'description' => __( 'Maximum date in yyyy/mm/dd format.', 'sureforms-pro' ),
			],
			// Time-picker field properties.
			'useTwelveHourFormat' => [
				'type'        => 'boolean',
				'description' => __( 'Use 12-hour format in time picker.', 'sureforms-pro' ),
			],
			'incrementInMinutes'  => [
				'type'        => 'integer',
				'description' => __( 'Time increment in minutes (1-60).', 'sureforms-pro' ),
			],
			'minTime'             => [
				'type'        => 'string',
				'description' => __( 'Minimum time in 24-hour format.', 'sureforms-pro' ),
			],
			'maxTime'             => [
				'type'        => 'string',
				'description' => __( 'Maximum time in 24-hour format.', 'sureforms-pro' ),
			],
			// Signature field properties.
			'signatureWidth'      => [
				'type'        => 'integer',
				'description' => __( 'Width of the signature pad in pixels.', 'sureforms-pro' ),
			],
			'signatureHeight'     => [
				'type'        => 'integer',
				'description' => __( 'Height of the signature pad in pixels.', 'sureforms-pro' ),
			],
			// Page-break field properties.
			'nextButtonText'      => [
				'type'        => 'string',
				'description' => __( 'Label for the Next button on multi-page forms.', 'sureforms-pro' ),
			],
			'prevButtonText'      => [
				'type'        => 'string',
				'description' => __( 'Label for the Previous button on multi-page forms.', 'sureforms-pro' ),
			],
		];

		return array_merge( $properties, $pro_properties );
	}
}
