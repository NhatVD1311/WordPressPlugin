<?php
/**
 * HTML Form Detector Extension.
 *
 * Pro extensions for the free plugin's `Html_Form_Detector` converter —
 * promotes parsed fields to pro block types when the source HTML uses
 * HTML5 inputs that have first-class equivalents in SureForms Pro
 * (`<input type="date">` → `date-picker`, etc.), and layers in pro
 * styling defaults on the converted form.
 *
 * The free parser ships with a deliberately conservative type map: it
 * only knows about field types the free plugin can render. We extend
 * the map here on the server side so the JS bundle stays free-only and
 * the pro behavior activates automatically as soon as this plugin is
 * loaded — no opt-in needed on the editor side.
 *
 * @package sureforms-pro
 * @since 2.10.0
 */

namespace SRFM_Pro\Inc\Abilities\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Html_Form_Detector_Extension class.
 *
 * Hooks into the free converter's filters to upgrade detected fields
 * to pro types and to write pro-only `_srfm_forms_styling` keys on the
 * created form.
 *
 * @since 2.10.0
 */
class Html_Form_Detector_Extension {
	/**
	 * Filter priority used for both hooks.
	 *
	 * Matches the priority used by `Create_Form_Extension` so pro
	 * adjustments to the schema and the conversion pipeline run in the
	 * same pass — keeps the cascade of pro-side modifications easy to
	 * reason about.
	 *
	 * @since 2.10.0
	 */
	private const FILTER_PRIORITY = 20;

	/**
	 * Map of HTML5 `<input type>` values to the pro field-type slug they
	 * should be promoted to. Keys MUST stay lower-case; values MUST be
	 * field-type slugs that `Field_Mapping` knows how to render.
	 *
	 * Why this is a class constant rather than runtime-derived: keeping
	 * the map static lets reviewers see at a glance which HTML inputs
	 * trigger which pro upgrades, and makes the relationship easy to
	 * unit-test without standing up the whole conversion pipeline.
	 *
	 * @since 2.10.0
	 */
	private const PRO_TYPE_PROMOTIONS = [
		'date'   => 'date-picker',
		// Deliberately NOT mapping `datetime-local` — SureForms'
		// `date-picker` block stores only the date portion, so
		// promoting `<input type="datetime-local">` would silently
		// drop the time component. Falling back to the free `input`
		// block preserves the user's value losslessly until SureForms
		// ships a dedicated datetime field type. Revisit when that
		// lands.
		'time'   => 'time-picker',
		// `slider` (not `number-slider`) is the value `Field_Mapping`
		// actually renders to `srfm/slider` — see the comment on
		// `Create_Form_Extension::PRO_FIELD_TYPES`.
		'range'  => 'slider',
		'file'   => 'upload',
		'hidden' => 'hidden',
	];

	/**
	 * Form theme slug to write onto every converted form when pro is
	 * active. `default` is the polished pro preset; users can switch to
	 * `custom` from the Styling sidebar to override any individual
	 * value. Anything other than `default` / `custom` is treated as
	 * "inherit" by `Form_Styling`.
	 *
	 * @since 2.10.0
	 */
	private const DEFAULT_FORM_THEME = 'default';

	/**
	 * Constructor.
	 *
	 * Subscription notes:
	 * - `srfm_html_form_detector_refine_fields` is fired with three
	 *   args (`$fields`, `$raw_html`, `$confidence`) in the free
	 *   plugin, but we deliberately subscribe with `accepted_args=2`
	 *   here. `$confidence` is the parser's self-rated quality flag
	 *   and is only used by the free side to gate the AI fallback; on
	 *   the pro side it adds no information beyond what the source
	 *   HTML itself provides, so we ignore it and keep the handler
	 *   signature tight.
	 * - `srfm_html_form_detector_after_styling` is an action (not a
	 *   filter); the handler returns `void`. Treating it as a filter
	 *   would null out the chain for any later subscriber.
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_filter( 'srfm_html_form_detector_refine_fields', [ $this, 'refine_fields' ], self::FILTER_PRIORITY, 2 );

		// Match the action's firing arity (`$form_id`, `$styling`,
		// `$raw_html`) even though the current handler only consumes
		// the first two. Subscribing with `accepted_args=2` works
		// today by ignoring the unused third arg, but the docblock
		// reserves `$raw_html` for a future inline-style heuristic;
		// keeping the count in sync now means that future heuristic
		// doesn't land alongside an invisibly-dropped argument.
		add_action( 'srfm_html_form_detector_after_styling', [ $this, 'apply_pro_styling' ], self::FILTER_PRIORITY, 3 );
	}

	/**
	 * Refine the parsed field list using the raw source HTML.
	 *
	 * The free parser flags HTML5 inputs it cannot render to a free
	 * block (e.g. `<input type="date">`) as plain `input` with a low
	 * confidence flag. We re-walk the source HTML in document order
	 * and pair each `<input>` / `<textarea>` / `<select>` with the
	 * parsed field at the same position, then rewrite the field's
	 * `fieldType` (plus relevant pro attributes) when the source uses
	 * a promotable HTML5 type.
	 *
	 * Pairing strategy — document-order lockstep:
	 * Both the free JS parser and `DOMDocument` walk the form in
	 * document order, and the free parser emits exactly one parsed
	 * field per submittable element (skipping `submit` / `button` /
	 * `reset` / `image` inputs). So the Nth parsed field corresponds
	 * to the Nth submittable element in the HTML. A naive
	 * bucket-by-type approach is wrong because it loses positional
	 * pairing: a form with `[text, email, date, time]` would
	 * incorrectly promote the first parsed field to `date-picker`
	 * (the bucket order's first entry) instead of leaving "text" as
	 * an input.
	 *
	 * Failure-mode: when DOM parsing fails OR the element counts
	 * diverge between the two walks (extreme edge case — e.g. malformed
	 * HTML), we return the input array unchanged. Losing pro fidelity
	 * is safer than reshuffling fields incorrectly.
	 *
	 * @since 2.10.0
	 * @param array<int,array<string,mixed>>|mixed $fields   Sanitized free-plugin field list.
	 * @param string|mixed                         $raw_html Raw HTML of the source `<form>`.
	 * @return array<int,array<string,mixed>>
	 */
	public function refine_fields( $fields, $raw_html ) {
		if ( ! is_array( $fields ) || empty( $fields ) || ! is_string( $raw_html ) || '' === $raw_html ) {
			return is_array( $fields ) ? $fields : [];
		}

		$ordered_sources = $this->collect_submittable_elements( $raw_html );
		if ( empty( $ordered_sources ) ) {
			return $fields;
		}

		// `collect_submittable_elements` and the JS parser both emit
		// one entry per submittable control in document order. They
		// should produce the same count for well-formed HTML; when
		// they do not (rare), we bail rather than try to second-guess
		// the misalignment.
		$parsed_count = count( $fields );
		$source_count = count( $ordered_sources );
		if ( $parsed_count !== $source_count && ! $this->counts_align_via_radios( $fields, $ordered_sources ) ) {
			return $fields;
		}

		// Walk both in lockstep. Build an iterator that yields one
		// source-input position per parsed-field index by collapsing
		// same-`name` radio groups (the free parser merges them into a
		// single multi-choice field).
		$source_cursor = 0;
		foreach ( $fields as $index => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$source = $this->next_source_for_field( $field, $ordered_sources, $source_cursor );
			if ( null === $source ) {
				continue;
			}

			$source_type = isset( $source['type'] ) && is_string( $source['type'] ) ? $source['type'] : '';
			if ( '' === $source_type || ! array_key_exists( $source_type, self::PRO_TYPE_PROMOTIONS ) ) {
				continue;
			}

			$fields[ $index ] = $this->apply_promotion( $field, $source, $source_type );
		}

		return $fields;
	}

	/**
	 * Apply pro styling defaults to the newly-created form.
	 *
	 * Writes `form_theme` onto `_srfm_forms_styling` so the converted
	 * form picks up pro's polished defaults out of the box. Anything
	 * already present in the meta (set by the free converter) is
	 * preserved — we only add keys, never overwrite.
	 *
	 * @since 2.10.0
	 * @param int                 $form_id  Newly-created SureForms form ID.
	 * @param array<string,mixed> $styling  Parser styling descriptor (currently unused, reserved for future heuristics).
	 * @param string              $raw_html Original source HTML (currently unused, reserved for future heuristics).
	 * @return void
	 */
	public function apply_pro_styling( $form_id, $styling, $raw_html = '' ) {
		// Both args are accepted for parity with the action's firing
		// arity (see __construct comment). They're reserved for future
		// inline-style → theme heuristics.
		unset( $styling, $raw_html );

		// Strict int check — `is_numeric('12.7')` is true, but
		// `(int) '12.7' === 12`, which would silently write meta to
		// post #12 (a real post in most installs). Require an actual
		// integer so callers can't accidentally redirect the write
		// onto an unrelated post.
		if ( ! is_int( $form_id ) || $form_id <= 0 ) {
			return;
		}

		$existing = get_post_meta( $form_id, '_srfm_forms_styling', true );
		$existing = is_array( $existing ) ? $existing : [];

		// Never clobber a theme an upstream step may have already
		// chosen — pro is the lowest-precedence opinion here.
		if ( ! empty( $existing['form_theme'] ) ) {
			return;
		}

		$existing['form_theme'] = self::DEFAULT_FORM_THEME;
		update_post_meta( $form_id, '_srfm_forms_styling', $existing );
	}

	/**
	 * Decide whether the divergent counts are explainable by collapsed
	 * radio groups, and if so, allow the lockstep walk to proceed.
	 *
	 * The free parser merges N radios sharing a `name` into one
	 * multi-choice field. Pro promotion never affects multi-choice
	 * fields, so a count mismatch caused only by radios is safe — we
	 * just need `next_source_for_field` to skip over the radio block
	 * when advancing the cursor.
	 *
	 * @since 2.10.0
	 * @param array<int,array<string,mixed>> $fields  Parsed fields.
	 * @param array<int,array<string,mixed>> $sources Ordered source descriptors.
	 * @return bool
	 */
	private function counts_align_via_radios( array $fields, array $sources ) {
		$radio_field_count = 0;
		foreach ( $fields as $field ) {
			if ( isset( $field['fieldType'] ) && 'multi-choice' === $field['fieldType'] ) {
				$radio_field_count++;
			}
		}

		// Fast path — when there are no multi-choice fields, a count
		// mismatch cannot be explained by radio collapsing. Skip the
		// O(n) source walk entirely; this is the common case (most
		// forms have no radio groups at all).
		if ( 0 === $radio_field_count ) {
			return false;
		}

		$radio_source_count = 0;
		$radio_groups       = [];
		foreach ( $sources as $source ) {
			// Explicit isset + is_string guards keep PHPStan level 9
			// happy when `$sources` is typed `array<int,array<string,mixed>>`
			// — `mixed` can't be narrowed to string by comparison alone.
			$type = isset( $source['type'] ) && is_string( $source['type'] ) ? $source['type'] : '';
			if ( 'radio' !== $type ) {
				continue;
			}
			$radio_source_count++;
			$name                  = isset( $source['name'] ) && is_string( $source['name'] ) ? $source['name'] : '';
			$radio_groups[ $name ] = true;
		}

		// After collapsing, source contributes one field per radio
		// group. If the deficit matches that collapse, counts align.
		$collapsed   = count( $sources ) - $radio_source_count + count( $radio_groups );
		$field_count = count( $fields );
		$group_count = count( $radio_groups );
		return $collapsed === $field_count && $group_count === $radio_field_count;
	}

	/**
	 * Advance the source cursor and return the source entry that
	 * corresponds to the current parsed field, handling collapsed
	 * radio groups along the way.
	 *
	 * The cursor reference is incremented past any radios that belong
	 * to the multi-choice field at this position, so the next call
	 * lines up with the next non-radio (or the next radio group).
	 *
	 * @since 2.10.0
	 * @param array<string,mixed>            $field   Parsed field at the current index.
	 * @param array<int,array<string,mixed>> $sources Ordered source descriptors.
	 * @param int                            $cursor  Current cursor by reference.
	 * @return array<string,mixed>|null Source descriptor to consult, or null when out of bounds.
	 */
	private function next_source_for_field( array $field, array $sources, &$cursor ) {
		if ( ! isset( $sources[ $cursor ] ) ) {
			return null;
		}

		$is_multi_choice = isset( $field['fieldType'] ) && 'multi-choice' === $field['fieldType'];
		if ( $is_multi_choice ) {
			// Consume the entire run of radios sharing this name. The
			// promotion logic never acts on a multi-choice so the
			// return value is only used to advance — we hand back the
			// first radio in the group.
			$first      = $sources[ $cursor ];
			$group_name = isset( $first['name'] ) && is_string( $first['name'] ) ? $first['name'] : '';
			while ( isset( $sources[ $cursor ] ) ) {
				// `$sources[$cursor]` is mixed at PHPStan level 9 even
				// after the isset, so narrow it locally before the
				// type/name comparisons. The two checks become flat
				// is_string guards instead of a chained `??`.
				$entry      = $sources[ $cursor ];
				$entry_type = isset( $entry['type'] ) && is_string( $entry['type'] ) ? $entry['type'] : '';
				$entry_name = isset( $entry['name'] ) && is_string( $entry['name'] ) ? $entry['name'] : '';
				if ( 'radio' !== $entry_type || $entry_name !== $group_name ) {
					break;
				}
				$cursor++;
			}
			return $first;
		}

		$source = $sources[ $cursor ];
		$cursor++;
		return $source;
	}

	/**
	 * Walk the source HTML in document order and return every
	 * submittable control with its normalized type and the source
	 * attributes that the free parser does not pass through.
	 *
	 * "Submittable" here mirrors what the free JS parser would have
	 * emitted as a parsed field: every `<input>` except the four button
	 * variants (`submit` / `button` / `reset` / `image`), every
	 * `<textarea>`, every `<select>`. Order matches the JS parser's
	 * `querySelectorAll('input, textarea, select')` walk so the lockstep
	 * pairing in `refine_fields` aligns one-to-one.
	 *
	 * @since 2.10.0
	 * @param string $raw_html Raw HTML of the source `<form>`.
	 * @return array<int,array<string,mixed>> Ordered list of source descriptors.
	 */
	private function collect_submittable_elements( $raw_html ) {
		// `loadHTML` warns on HTML5 tags it does not recognise; we
		// silence libxml notices around the call so the converter does
		// not surface noise from third-party markup, then restore.
		//
		// The internal-error mode MUST be restored even when `loadHTML`
		// throws (PHP 8+ can raise `ValueError` on empty / malformed
		// fragments). Leaking `libxml_use_internal_errors(true)` would
		// silently suppress libxml notices for every subsequent caller
		// in the same request. The `try / finally` makes the restore
		// unconditional; the `try` body deliberately stays small so
		// the only thing it covers is the libxml interaction.
		//
		// The XML encoding processing instruction is the intentional
		// encoding hint for the `loadHTML` call — PHP 8.2+ deprecated
		// `mb_convert_encoding(..., 'HTML-ENTITIES', 'UTF-8')`, so the
		// PI form is what we use going forward. Do NOT swap back to
		// `mb_convert_encoding` without confirming the deprecation
		// status on the supported PHP range.
		$prev    = libxml_use_internal_errors( true );
		$doc     = new \DOMDocument();
		$wrapped = '<?xml encoding="UTF-8"?><div>' . $raw_html . '</div>';

		try {
			// `LIBXML_NONET` is defense-in-depth against XXE-style
			// network fetches. `LIBXML_NOENT` is OFF (default — no
			// entity substitution) and `LIBXML_DTDLOAD` is OFF (we
			// never opt into external-DTD loading), so the realistic
			// attack surface here is already very small. But if a
			// crafted `<!DOCTYPE ... SYSTEM "http://attacker/x.dtd">`
			// ever slipped past `LIBXML_HTML_NODEFDTD`, this flag
			// guarantees libxml refuses the network round-trip even
			// then. Cost is zero; safety margin is real.
			$loaded = $doc->loadHTML(
				$wrapped,
				LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
			);
		} catch ( \Throwable $unused ) {
			$loaded = false;
		} finally {
			libxml_clear_errors();
			libxml_use_internal_errors( $prev );
		}

		if ( ! $loaded ) {
			return [];
		}

		// XPath gives us a single document-order walk across the three
		// tag names — using `getElementsByTagName` thrice would lose
		// the relative ordering between e.g. an input and a select.
		$xpath = new \DOMXPath( $doc );
		$nodes = $xpath->query( '//input | //textarea | //select' );
		if ( false === $nodes ) {
			return [];
		}

		$ordered      = [];
		$skip_buttons = [ 'submit', 'button', 'reset', 'image' ];
		foreach ( $nodes as $node ) {
			if ( ! $node instanceof \DOMElement ) {
				continue;
			}

			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMElement::$nodeName is a PHP-native camelCase property.
			$tag = strtolower( $node->nodeName );
			if ( 'input' === $tag ) {
				$type = strtolower( $node->getAttribute( 'type' ) );
				if ( '' === $type ) {
					$type = 'text';
				}
				if ( in_array( $type, $skip_buttons, true ) ) {
					continue;
				}
			} else {
				// `textarea` / `select` carry no `type` — synthesize
				// one so callers can branch uniformly on `type`.
				$type = $tag;
			}

			$ordered[] = [
				'type'        => $type,
				'name'        => $node->getAttribute( 'name' ),
				'accept'      => $node->getAttribute( 'accept' ),
				'multiple'    => $node->hasAttribute( 'multiple' ),
				'min'         => $node->getAttribute( 'min' ),
				'max'         => $node->getAttribute( 'max' ),
				'step'        => $node->getAttribute( 'step' ),
				'value'       => $node->getAttribute( 'value' ),
				'placeholder' => $node->getAttribute( 'placeholder' ),
			];
		}

		return $ordered;
	}

	/**
	 * Rewrite a single parsed field with the pro type + any source
	 * attributes that the free parser dropped.
	 *
	 * The free parser produces the right `fieldType` for `<input
	 * type="file">` (→ `upload`) and `<input type="hidden">` (→
	 * `hidden`) but drops the corresponding HTML attributes
	 * (`accept`, `multiple`, `value`). For those cases we keep the
	 * existing `fieldType` and only enrich; for everything else we
	 * also rewrite `fieldType` to the matching pro slug.
	 *
	 * @since 2.10.0
	 * @param array<string,mixed> $field       Parsed field descriptor.
	 * @param array<string,mixed> $source      Source HTML input attributes.
	 * @param string              $source_type Lower-case HTML `<input type>` of the source.
	 * @return array<string,mixed>
	 */
	private function apply_promotion( array $field, array $source, $source_type ) {
		$promoted = self::PRO_TYPE_PROMOTIONS[ $source_type ] ?? '';
		if ( '' === $promoted ) {
			// Defensive — the caller should only pass source types
			// listed in PRO_TYPE_PROMOTIONS. If that contract ever
			// breaks, prefer preserving the field over hard-failing
			// the whole conversion.
			return $field;
		}

		$field['fieldType'] = $promoted;

		// All values reaching this point come from
		// `DOMElement::getAttribute()`, which returns `string`. The
		// helpers below re-narrow the types from the array's `mixed`
		// declaration so PHPStan can verify each branch — and so a
		// caller passing through a malformed descriptor cannot trip
		// a `Cannot cast mixed to string` cascade at runtime.
		$min   = self::source_string( $source, 'min' );
		$max   = self::source_string( $source, 'max' );
		$step  = self::source_string( $source, 'step' );
		$value = self::source_string( $source, 'value' );

		switch ( $promoted ) {
			case 'date-picker':
				if ( '' !== $min ) {
					$field['minDate'] = $this->normalize_date( $min );
				}
				if ( '' !== $max ) {
					$field['maxDate'] = $this->normalize_date( $max );
				}
				break;

			case 'time-picker':
				if ( '' !== $min ) {
					$field['minTime'] = $min;
				}
				if ( '' !== $max ) {
					$field['maxTime'] = $max;
				}
				if ( '' !== $step && is_numeric( $step ) ) {
					// HTML `step` for time inputs is in seconds;
					// SureForms expects minutes. Skip the conversion
					// entirely when `step` is below 30 seconds — those
					// values would round up to a 1-minute increment,
					// which is wildly different semantics from
					// "increment by 1 second" and silently changes
					// what the source form said. Authors who actually
					// want sub-minute granularity will see the
					// attribute simply not carried over, which is the
					// correct outcome until SureForms grows
					// sub-minute support.
					$step_seconds = (float) $step;
					if ( $step_seconds >= 30.0 ) {
						$field['incrementInMinutes'] = max( 1, (int) round( $step_seconds / 60 ) );
					}
				}
				break;

			case 'upload':
				$accept = self::source_string( $source, 'accept' );
				if ( '' !== $accept ) {
					// HTML `accept` is a comma-separated list of MIME
					// types and / or `.ext` suffixes. SureForms wants
					// bare extensions — strip leading dots; MIME types
					// (containing `/`) are filtered out as not having
					// a stable extension equivalent.
					$exts                  = array_filter(
						array_map(
							static function ( $token ) {
								$token = trim( (string) $token );
								if ( '' === $token || false !== strpos( $token, '/' ) ) {
									return '';
								}
								return ltrim( $token, '.' );
							},
							explode( ',', $accept )
						)
					);
					$field['allowedTypes'] = implode( ',', $exts );
				}
				if ( ! empty( $source['multiple'] ) ) {
					$field['multiUpload'] = true;
				}
				break;

			case 'hidden':
				if ( '' !== $value ) {
					$field['defaultValue'] = $value;
				}
				break;

			case 'slider':
				if ( '' !== $min && is_numeric( $min ) ) {
					$field['min'] = (int) $min;
				}
				if ( '' !== $max && is_numeric( $max ) ) {
					$field['max'] = (int) $max;
				}
				if ( '' !== $step && is_numeric( $step ) ) {
					$field['step'] = (int) $step;
				}
				break;
		}

		return $field;
	}

	/**
	 * Read a string value from a source descriptor, returning `''`
	 * when the key is absent or the value is non-string.
	 *
	 * Centralised so `apply_promotion` can keep its branch bodies free
	 * of repetitive `is_string` guards — and so PHPStan sees a
	 * concrete `string` flowing into every downstream cast.
	 *
	 * @since 2.10.0
	 * @param array<string,mixed> $source Source descriptor.
	 * @param string              $key    Key to read.
	 * @return string
	 */
	private static function source_string( array $source, $key ) {
		return isset( $source[ $key ] ) && is_string( $source[ $key ] ) ? $source[ $key ] : '';
	}

	/**
	 * Normalize an HTML5 date-like string to the `yyyy/mm/dd` form
	 * that SureForms' date-picker schema accepts.
	 *
	 * Tolerates the two real-world deviations from strict HTML5
	 * (`yyyy-mm-dd`) that authors paste into `min=` / `max=`: the
	 * Slash-separator form (`2026/01/01`) and the un-padded
	 * day/month form (`2026-1-1`). Both are normalized to the
	 * canonical `yyyy/mm/dd` shape via `sprintf('%04d/%02d/%02d')`.
	 *
	 * Anything that doesn't start with a YYYY-MM-DD-or-/D triple
	 * (e.g. literal "today", a free-text placeholder, an obviously
	 * truncated string) returns '' so the caller drops the attribute.
	 *
	 * @since 2.10.0
	 * @param string $value Raw `min`/`max` value.
	 * @return string Normalized date, or empty string when the input is malformed.
	 */
	private function normalize_date( $value ) {
		if ( ! is_string( $value ) ) {
			return '';
		}
		if ( ! preg_match( '#^\s*(\d{4})[-/](\d{1,2})[-/](\d{1,2})#', $value, $match ) ) {
			return '';
		}
		return sprintf( '%04d/%02d/%02d', (int) $match[1], (int) $match[2], (int) $match[3] );
	}
}
