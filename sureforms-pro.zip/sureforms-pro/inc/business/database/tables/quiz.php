<?php
/**
 * SureForms Pro Quiz Database Table Class.
 *
 * @link       https://sureforms.com
 * @since      2.6.0
 * @package    sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Database\Tables;

use SRFM\Inc\Database\Base;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * SureForms Pro Quiz Database Table Class.
 *
 * @since 2.6.0
 */
class Quiz extends Base {
	use Get_Instance;

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	protected $table_suffix = 'quiz_entries';

	/**
	 * {@inheritDoc}
	 *
	 * @var int
	 */
	protected $table_version = 1;

	/**
	 * {@inheritDoc}
	 */
	public function get_schema() {
		return [
			// Entry ID.
			'id'          => [
				'type' => 'number',
			],
			// Identifier of the related form.
			'form_id'     => [
				'type' => 'number',
			],
			// Identifier of the related form entry.
			'entry_id'    => [
				'type'    => 'number',
				'default' => 0,
			],
			// Serialized quiz structure or answers (JSON).
			'quiz_data'   => [
				'type'    => 'array',
				'default' => [],
			],
			// Calculated quiz result/output (JSON).
			'quiz_result' => [
				'type'    => 'array',
				'default' => [],
			],
			// Internal notes or comments related to the record.
			'notes'       => [
				'type'    => 'array',
				'default' => [],
			],
			// Date and time the record was created.
			'created_at'  => [
				'type' => 'datetime',
			],
			// Date and time the record was last updated.
			'updated_at'  => [
				'type' => 'datetime',
			],
		];
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns_definition() {
		return [
			'id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY',
			'form_id BIGINT(20) UNSIGNED',
			'entry_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0',
			'quiz_data LONGTEXT',
			'quiz_result LONGTEXT',
			'notes LONGTEXT',
			'created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			'INDEX idx_form_id (form_id)',
			'INDEX idx_entry_id (entry_id)',
			'INDEX idx_created_at (created_at, id)',
		];
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_new_columns_definition() {
		return [
			// Note: @since 2.6.0 -- Added entry_id column for direct form entry lookup.
			'entry_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0 AFTER form_id',
			'INDEX idx_entry_id (entry_id)',
		];
	}

	/**
	 * Add a new quiz record to the database.
	 *
	 * @param array<mixed> $data An associative array of data for the new quiz record.
	 * @since 2.6.0
	 * @return int|false The number of rows inserted, or false if the insertion fails.
	 */
	public static function add( $data ) {
		if ( ! is_array( $data ) ) {
			return false;
		}

		if ( isset( $data['form_id'] ) ) {
			$data['form_id'] = absint( $data['form_id'] );
		}

		if ( isset( $data['entry_id'] ) ) {
			$data['entry_id'] = absint( $data['entry_id'] );
		}

		if ( isset( $data['quiz_data'] ) && is_array( $data['quiz_data'] ) ) {
			$data['quiz_data'] = wp_json_encode( $data['quiz_data'] );
		}

		if ( isset( $data['quiz_result'] ) && is_array( $data['quiz_result'] ) ) {
			$data['quiz_result'] = wp_json_encode( $data['quiz_result'] );
		}

		if ( isset( $data['notes'] ) ) {
			$data['notes'] = is_array( $data['notes'] )
				? Helper::get_array_value( $data['notes'] )
				: sanitize_textarea_field( Helper::get_string_value( $data['notes'] ) );
		}

		return self::get_instance()->use_insert( $data );
	}

	/**
	 * Retrieve a specific quiz record from the database.
	 *
	 * @param int $id The quiz record id.
	 * @since 2.6.0
	 * @return array<mixed> An associative array representing the quiz record, or an empty array if not found.
	 */
	public static function get( $id ) {
		if ( empty( $id ) ) {
			return [];
		}

		return self::get_by( 'id', absint( $id ) );
	}

	/**
	 * Retrieve all quiz records for a given form ID.
	 *
	 * @param int                 $form_id Form post ID.
	 * @param array<string,mixed> $args    Optional. Query arguments (limit, offset, orderby, order).
	 * @since 2.6.0
	 * @return array<mixed> Array of quiz records.
	 */
	public static function get_by_form_id( $form_id, $args = [] ) {
		if ( empty( $form_id ) ) {
			return [];
		}

		$existing_where = isset( $args['where'] ) && is_array( $args['where'] ) ? $args['where'] : [];

		$args['where'] = array_merge( $existing_where, [ 'form_id' => absint( $form_id ) ] );

		return self::get_instance()->get_records_by_args( $args );
	}

	/**
	 * Update a quiz record by id.
	 *
	 * @param int                 $id   Quiz record id.
	 * @param array<string,mixed> $data Data to update.
	 * @since 2.6.0
	 * @return int|false The number of rows updated, or false on error.
	 */
	public static function update( $id, $data = [] ) {
		if ( empty( $id ) ) {
			return false;
		}

		if ( isset( $data['quiz_data'] ) && is_array( $data['quiz_data'] ) ) {
			$data['quiz_data'] = wp_json_encode( $data['quiz_data'] );
		}

		if ( isset( $data['quiz_result'] ) && is_array( $data['quiz_result'] ) ) {
			$data['quiz_result'] = wp_json_encode( $data['quiz_result'] );
		}

		if ( isset( $data['notes'] ) ) {
			$data['notes'] = is_array( $data['notes'] )
				? Helper::get_array_value( $data['notes'] )
				: sanitize_textarea_field( Helper::get_string_value( $data['notes'] ) );
		}

		return self::get_instance()->use_update( $data, [ 'id' => absint( $id ) ] );
	}

	/**
	 * Delete a quiz record by id.
	 *
	 * @param int $id Quiz record id to delete.
	 * @since 2.6.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete( $id ) {
		if ( empty( $id ) ) {
			return false;
		}

		return self::get_instance()->use_delete( [ 'id' => absint( $id ) ], [ '%d' ] );
	}

	/**
	 * Delete all quiz records for a given form ID.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.6.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete_by_form_id( $form_id ) {
		if ( empty( $form_id ) ) {
			return false;
		}

		return self::get_instance()->use_delete( [ 'form_id' => absint( $form_id ) ], [ '%d' ] );
	}

	/**
	 * Delete all quiz records for a given form entry ID.
	 *
	 * @param int $entry_id Form entry ID.
	 * @since 2.6.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete_by_entry_id( $entry_id ) {
		if ( empty( $entry_id ) ) {
			return false;
		}

		return self::get_instance()->use_delete( [ 'entry_id' => absint( $entry_id ) ], [ '%d' ] );
	}

	/**
	 * Get adjacent quiz entry IDs (previous and next) for navigation.
	 * Navigation follows chronological order: Previous = older, Next = newer.
	 *
	 * @param int               $current_entry_id Current quiz entry ID.
	 * @param array<string,int> $args {
	 *     Optional. Arguments to filter adjacent entries.
	 *
	 *     @type int $form_id Form ID to scope navigation within. Default 0 (no filtering).
	 * }
	 * @since 2.6.0
	 * @return array<string,int|null> {
	 *     @type int|null $previous_id Previous entry ID (older entry) or null if at the oldest.
	 *     @type int|null $next_id     Next entry ID (newer entry) or null if at the newest.
	 * }
	 */
	public static function get_adjacent_entry_ids( $current_entry_id, $args = [] ) {
		if ( empty( $current_entry_id ) ) {
			return [
				'previous_id' => null,
				'next_id'     => null,
			];
		}

		$defaults = [
			'form_id' => 0,
		];

		$args    = wp_parse_args( $args, $defaults );
		$form_id = absint( $args['form_id'] );

		global $wpdb;
		$current_entry_id = absint( $current_entry_id );
		$table_name       = self::get_instance()->get_tablename();

		$form_clause = '';
		if ( $form_id > 0 ) {
			$form_clause = $wpdb->prepare( ' AND form_id = %d', $form_id ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared inline.
		}

		$current_created = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-row navigation lookup, request-scoped and intentionally uncached.
			$wpdb->prepare(
				"SELECT created_at FROM {$table_name} WHERE id = %d LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is from internal class config.
				$current_entry_id
			)
		);

		if ( ! is_string( $current_created ) || '' === $current_created ) {
			return [
				'previous_id' => null,
				'next_id'     => null,
			];
		}

		$previous_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-row adjacent ID lookup, intentionally uncached.
			$wpdb->prepare(
				"SELECT id FROM {$table_name} WHERE (( created_at < %s ) OR ( created_at = %s AND id < %d )){$form_clause} ORDER BY created_at DESC, id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name and form_clause are from internal class config / wpdb::prepare.
				$current_created,
				$current_created,
				$current_entry_id
			)
		);
		$next_id     = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-row adjacent ID lookup, intentionally uncached.
			$wpdb->prepare(
				"SELECT id FROM {$table_name} WHERE (( created_at > %s ) OR ( created_at = %s AND id > %d )){$form_clause} ORDER BY created_at ASC, id ASC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name and form_clause are from internal class config / wpdb::prepare.
				$current_created,
				$current_created,
				$current_entry_id
			)
		);

		return [
			'previous_id' => null !== $previous_id ? absint( $previous_id ) : null,
			'next_id'     => null !== $next_id ? absint( $next_id ) : null,
		];
	}

	/**
	 * Retrieve quiz record data by a given condition.
	 *
	 * @param string     $key   Lookup key (e.g., 'id', 'form_id').
	 * @param int|string $value Lookup value.
	 * @return array<mixed> Quiz record data or empty array if not found.
	 */
	private static function get_by( $key, $value ) {
		if ( empty( $key ) || empty( $value ) ) {
			return [];
		}

		$results = self::get_instance()->get_results(
			[
				$key => $value,
			]
		);

		$record = isset( $results[0] ) && is_array( $results[0] ) ? Helper::get_array_value( $results[0] ) : [];

		// Decode JSON fields.
		foreach ( [ 'quiz_data', 'quiz_result' ] as $json_field ) {
			if ( ! empty( $record[ $json_field ] ) && is_string( $record[ $json_field ] ) ) {
				$decoded = json_decode( $record[ $json_field ], true );
				if ( JSON_ERROR_NONE === json_last_error() ) {
					$record[ $json_field ] = $decoded;
				}
			}
		}

		return $record;
	}
}
