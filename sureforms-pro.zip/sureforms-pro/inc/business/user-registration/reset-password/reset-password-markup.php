<?php
/**
 * SureForms Reset Password Markup Class file.
 *
 * @package sureforms-pro.
 * @since 2.5.0
 */

namespace SRFM_Pro\Inc\Business\User_Registration\Reset_Password;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Fields\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Sureforms Reset Password Markup Class.
 *
 * @since 2.5.0
 */
class Reset_Password_Markup extends Base {
	/**
	 * Reset key from URL.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	protected $reset_key = '';

	/**
	 * User login from URL.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	protected $user_login = '';

	/**
	 * Whether the reset key is valid.
	 *
	 * @var bool
	 * @since 2.5.0
	 */
	protected $is_valid_key = false;

	/**
	 * Error message if key is invalid.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	protected $error_message = '';

	/**
	 * Flag to hide form for logged in users.
	 *
	 * @var bool
	 * @since 2.5.0
	 */
	protected $hide_form = false;

	/**
	 * Message to display if the user is already logged in.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	protected $logged_in_message = '';

	/**
	 * Initialize the properties based on block attributes.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @since 2.5.0
	 */
	public function __construct( $attributes ) {
		$this->set_properties( $attributes );
		$this->set_input_label( __( 'Reset Password', 'sureforms-pro' ) );
		$this->slug = 'reset-password';
		$this->set_markup_properties();
		$this->hide_form         = $attributes['hideForm'] ?? false;
		$this->logged_in_message = $attributes['loggedinMessage'] ?? '';

		// Get reset key and login from URL parameters.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed, we validate the key separately.
		$this->reset_key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed, we validate the key separately.
		$this->user_login = isset( $_GET['login'] ) ? sanitize_text_field( wp_unslash( $_GET['login'] ) ) : '';

		// Validate the reset key.
		$this->validate_reset_key();
	}

	/**
	 * Render the SureForms Reset Password Block.
	 *
	 * @param string $content inner block content.
	 * @since 2.5.0
	 * @return string|bool
	 */
	public function markup( $content = '' ) {
		$classes = $this->get_field_classes();

		if ( ! $this->is_valid_key && ! ( is_user_logged_in() && $this->hide_form ) ) {
			$classes .= ' srfm-form-restriction-wrapper';
		}

		ob_start();
		?>
			<div data-block-id="<?php echo esc_attr( $this->block_id ); ?>" class="<?php echo esc_attr( $classes ); ?>" data-slug="<?php echo esc_attr( $this->block_slug ); ?>">
				<div class="srfm-block-wrap srfm-reset-password" data-reset-key="<?php echo esc_attr( $this->reset_key ); ?>" data-user-login="<?php echo esc_attr( $this->user_login ); ?>" data-valid-key="<?php echo $this->is_valid_key ? 'true' : 'false'; ?>">
				<?php
				if ( is_user_logged_in() && $this->hide_form ) {
					?>
						<p class="srfm-logged-in-message">
							<?php echo wp_kses_post( Helper::get_string_value( $this->logged_in_message ) ); ?>
						</p>
					<?php
				} elseif ( ! $this->is_valid_key ) {
					?>
					<div class="srfm-form-restriction-message" role="alert" aria-live="assertive">
						<span class="srfm-form-restriction-icon" aria-hidden="true">
							<?php
								echo wp_kses(
									Helper::fetch_svg( 'instant-form-warning', 'srfm-form-restriction-icon', 'aria-hidden="true"' ),
									Helper::$allowed_tags_svg
								);
							?>
						</span>
						<p class="srfm-form-restriction-text"><?php echo wp_kses_post( $this->error_message ); ?></p>
					</div>
					<?php
				} else {
					echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The content is already sanitized, escaping it again would break the markup.
				}
				?>
				</div>
			</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Validate the reset key.
	 *
	 * @since 2.5.0
	 * @return void
	 */
	protected function validate_reset_key() {
		$request_new_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( wp_lostpassword_url() ),
			__( 'Please request a new one.', 'sureforms-pro' )
		);

		if ( empty( $this->reset_key ) || empty( $this->user_login ) ) {
			$this->is_valid_key  = false;
			$this->error_message = sprintf(
				/* translators: %s: Link to request a new password reset */
				__( 'Invalid password reset link. %s', 'sureforms-pro' ),
				$request_new_link
			);
			return;
		}

		$user = check_password_reset_key( $this->reset_key, $this->user_login );

		if ( is_wp_error( $user ) ) {
			$this->is_valid_key = false;
			if ( 'expired_key' === $user->get_error_code() ) {
				$this->error_message = sprintf(
					/* translators: %s: Link to request a new password reset */
					__( 'This password reset link has expired. %s', 'sureforms-pro' ),
					$request_new_link
				);
			} else {
				$this->error_message = sprintf(
					/* translators: %s: Link to request a new password reset */
					__( 'Invalid password reset link. %s', 'sureforms-pro' ),
					$request_new_link
				);
			}
			return;
		}

		$this->is_valid_key = true;
	}
}
