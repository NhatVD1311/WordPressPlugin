<?php
/**
 * User Registration and Login class for SureForms
 *
 * @package sureforms-pro.
 * @since 1.8.0
 */

namespace SRFM_Pro\Inc\Business\User_Registration;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * User Registration and Login class for SureForms
 *
 * @since 1.8.0
 */
class Init {
	use Get_Instance;

	/**
	 * Associative array to keep the count of block that requires scripts to work.
	 *
	 * @var array<int>
	 * @since 1.8.0
	 */
	public static $script_dep_blocks = [
		'password'       => 0,
		'link'           => 0,
		'login'          => 0,
		'register'       => 0,
		'lost-password'  => 0,
		'reset-password' => 0,
	];

	/**
	 * Captured password reset key from WordPress.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	private static $captured_reset_key = '';

	/**
	 * User login for the captured reset key.
	 *
	 * @var string
	 * @since 2.5.0
	 */
	private static $captured_user_login = '';

	/**
	 * Whether we are inside our own retrieve_password() call and should capture the
	 * reset key core mints. Kept false otherwise so an unrelated key minting this
	 * request (e.g. a third-party wp_new_user_notification()) can never populate the
	 * statics that feed the {reset_password_url} / {password_reset_email} tags.
	 *
	 * @var bool
	 * @since 2.12.3
	 */
	private static $capture_armed = false;

	/**
	 * Constructor
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function __construct() {
		add_filter( 'srfm_register_additional_blocks', [ $this, 'register_field' ] );
		add_filter( 'srfm_allowed_block_types', [ $this, 'allow_user_registration_blocks_in_sureforms' ], 10, 1 );
		add_filter( 'srfm_blocks', [ $this, 'allow_user_registration_blocks_in_sureforms' ] );
		add_filter( 'render_block', [ $this, 'generate_render_script' ], 10, 2 );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_block_editor_assets' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_script' ] );
		add_filter( 'srfm_dynamic_validation_messages', [ $this, 'add_password_messages' ] );
		add_filter( 'srfm_general_dynamic_options_to_save', [ $this, 'add_password_validation_messages_to_save' ], 10, 2 );
		add_filter( 'srfm_default_dynamic_block_option', [ $this, 'add_password_default_dynamic_pro_block_values' ], 10, 2 );
		add_filter( 'srfm_pro_updater_callbacks', [ $this, 'add_password_dynamic_option_callback' ] );
		add_action( 'srfm_enqueue_common_field_assets', [ $this, 'get_user_registration_assets' ] );
		add_action( 'srfm_form_css_variables', [ $this, 'render_user_registration_css_variables' ] );
		add_filter( 'srfm_css_vars_sizes', [ $this, 'user_registration_spacing_variables' ] );
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'add_login_endpoint' ] );
		add_filter( 'srfm_block_preview_images', [ $this, 'add_login_block_preview' ] );
		add_filter( 'srfm_smart_tag_list', [ $this, 'add_user_registration_smart_tags' ] );
		add_filter( 'srfm_parse_smart_tags', [ $this, 'parse_user_registration_smart_tags' ], 10, 2 );
		add_filter( 'srfm_save_user_registration_settings', [ $this, 'save_user_registration_settings' ], 10, 2 );
		add_filter( 'srfm_pro_global_settings', [ $this, 'get_user_registration_settings' ], 10, 2 );
		add_action( 'srfm_register_additional_post_meta', [ $this, 'add_user_registration_meta' ] );

		// Add redirect hooks for custom login and registration pages.
		add_action( 'login_init', [ $this, 'redirect_to_custom_pages' ] );

		// Filter login URL to use custom login page if configured.
		add_filter( 'login_url', [ $this, 'filter_login_url' ], 10, 3 );
		add_filter( 'register_url', [ $this, 'filter_register_url' ], 10, 1 );
		add_filter( 'lostpassword_url', [ $this, 'filter_lostpassword_url' ], 10, 2 );

		// Capture password reset key when WordPress generates it.
		add_action( 'retrieve_password_key', [ $this, 'capture_password_reset_key' ], 10, 2 );

		// Run the lost-password reset inside the submission request (so the captured
		// key/login are visible to the {reset_password_url} / {password_reset_email}
		// tags rendered later in the same request by send_email()/confirmation).
		add_action( 'srfm_before_submission', [ $this, 'process_lost_password' ] );

		// Load user registration processor.
		Processor::get_instance();
	}

	/**
	 * Add pro block's default error message values.
	 *
	 * @param array<mixed> $default_values the default values.
	 * @param array<mixed> $common_err_msg the common error message.
	 * @since 1.8.0
	 * @return array<mixed>
	 */
	public static function add_password_default_dynamic_pro_block_values( $default_values, $common_err_msg ) {

		$default_pro_values = [
			'srfm_password_block_required_text'  => $common_err_msg['required'],
			'srfm_password_strength_weak'        => __( 'Your password strength is weak.', 'sureforms-pro' ),
			'srfm_password_strength_medium'      => __( 'Your password strength is moderate.', 'sureforms-pro' ),
			'srfm_password_strength_strong'      => __( 'Your password strength is strong.', 'sureforms-pro' ),
			'srfm_password_strength_very_strong' => __( 'Your password strength is very strong.', 'sureforms-pro' ),
			'srfm_password_mismatch'             => __( 'Confirmation password does not match.', 'sureforms-pro' ),
		];

		return array_merge( $default_values, $default_pro_values );
	}

	/**
	 * Allow blocks related to User Registration and Login Feature in SureForms.
	 * 1. Password Block
	 *
	 * @param array<string> $blocks Array of blocks.
	 *
	 * @since 1.8.0
	 * @return array<string>
	 */
	public function allow_user_registration_blocks_in_sureforms( $blocks ) {
		return array_merge(
			$blocks,
			[
				'srfm/password',
				'srfm/login',
				'srfm/link',
				'srfm/register',
				'srfm/lost-password',
				'srfm/reset-password',
			]
		);
	}

	/**
	 * Add password field messages.
	 *
	 * @param array<string> $default_options Default options.
	 * @param array<string> $setting_options Setting options.
	 *
	 * @since 1.8.0
	 * @return array<string>
	 */
	public function add_password_validation_messages_to_save( $default_options, $setting_options ) {
		$pro_options_keys    = [
			'srfm_password_block_required_text',
			'srfm_password_strength_weak',
			'srfm_password_strength_medium',
			'srfm_password_strength_strong',
			'srfm_password_strength_very_strong',
			'srfm_password_mismatch',
		];
		$pro_options_to_save = [];
		foreach ( $pro_options_keys as $key ) {
			if ( isset( $setting_options[ $key ] ) ) {
				$pro_options_to_save[ $key ] = $setting_options[ $key ];
			}
		}
		return array_merge( $default_options, $pro_options_to_save );
	}

	/**
	 * Retrieve default dynamic validation messages.
	 *
	 * @param array<string, string> $default_value Associative array of translated validation messages for frontend use.
	 * @since 1.8.0
	 * @return array Associative array of translated validation messages for frontend use.
	 */
	public static function add_password_messages( $default_value = [] ) {
		$translatable_array = [
			'srfm_password_block_required_text'  => __( 'This field is required.', 'sureforms-pro' ),
			'srfm_password_strength_weak'        => __( 'Your password strength is weak.', 'sureforms-pro' ),
			'srfm_password_strength_medium'      => __( 'Your password strength is moderate.', 'sureforms-pro' ),
			'srfm_password_strength_strong'      => __( 'Your password strength is strong.', 'sureforms-pro' ),
			'srfm_password_strength_very_strong' => __( 'Your password strength is very strong.', 'sureforms-pro' ),
			'srfm_password_mismatch'             => __( 'Confirmation password does not match.', 'sureforms-pro' ),
		];

		return ! empty( $default_value ) && is_array( $default_value ) ? array_merge( $default_value, $translatable_array ) : $translatable_array;
	}

	/**
	 * Render function.
	 *
	 * @param string $block_content Entire Block Content.
	 * @param array  $block Block Properties As An Array.
	 * @since 1.8.0
	 * @return string
	 */
	public function generate_render_script( $block_content, $block ) {
		// Check if the block is one of the user registration blocks and enqueue the required assets.
		// The container blocks must be listed here in their own right. Relying on a nested
		// srfm/link or srfm/password block to pull the frontend script in breaks as soon as those
		// optional inner blocks are toggled off, which silently disables the submission handlers.
		$blocks = [
			'srfm/password',
			'srfm/link',
			'srfm/login',
			'srfm/register',
			'srfm/lost-password',
			'srfm/reset-password',
		];
		if ( isset( $block['blockName'] ) && in_array( $block['blockName'], $blocks, true ) ) {
			self::enqueue_frontend_assets( $block['blockName'] );
		}
		return $block_content;
	}

	/**
	 * Enqueue required styles for the user registration in the editor and frontend.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function enqueue_styles() {
		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/package/business/';
		// This checks the text direction of the site, if it is RTL then it will load the RTL version of the CSS file.
		$rtl = is_rtl() ? '-rtl' : '';

		// Load the frontend custom app styles.
		wp_enqueue_style( SRFM_PRO_SLUG . '-password', $css_uri . 'password' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );
		wp_enqueue_style( SRFM_PRO_SLUG . '-user-registration', $css_uri . 'user-registration' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );
	}

	/**
	 * Register user registration blocks.
	 *
	 * @param array<mixed> $blocks Array of blocks.
	 *
	 * @since 1.8.0
	 * @return array<mixed>
	 */
	public function register_field( $blocks ) {
		$block_files = [ 'password', 'login', 'link', 'register', 'lost-password', 'reset-password' ];
		foreach ( $block_files as $file ) {
			$blocks[] = [
				'dir'       => SRFM_PRO_DIR . "inc/business/user-registration/{$file}/block.php",
				'namespace' => 'SRFM_PRO\\Inc\\Blocks',
			];
		}

		return $blocks;
	}

	/**
	 * Enqueue user registration form admin scripts.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function enqueue_block_editor_assets() {
		$this->enqueue_styles();
		$scripts = [
			[
				'unique_file'        => 'srfmUserRegistrationAdmin',
				'unique_handle'      => 'user-registration-admin',
				'extra_dependencies' => [ 'srfm-blocks', SRFM_PRO_SLUG . '-block-editor' ],
			],
		];
		$this->enqueue_scripts( $scripts );
	}

	/**
	 * Enqueue user registration admin scripts.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function enqueue_admin_script() {
		$scripts = [
			[
				'unique_file'        => 'srfmUserRegistration',
				'unique_handle'      => 'user-registration',
				'extra_dependencies' => [],
			],
		];
		$this->enqueue_scripts( $scripts );
	}

	/**
	 * Enqueue user registration frontend scripts.
	 *
	 * @param string $block_type Block type.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function enqueue_frontend_assets( $block_type = '' ) {
		$block_name = str_replace( 'srfm/', '', $block_type );

		// Check if block is in the array and check if block is already enqueued.
		if (
			in_array( $block_name, array_keys( self::$script_dep_blocks ), true ) &&
			0 === self::$script_dep_blocks[ $block_name ]
		) {
			self::$script_dep_blocks[ $block_name ] += 1;
			$this->get_user_registration_assets();
		}
	}

	/**
	 * Get user registration assets.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function get_user_registration_assets() {
		$this->enqueue_styles();
		wp_enqueue_script( 'srfm-pro-zxcvbn', SRFM_PRO_URL . 'assets/js/minified/deps/zxcvbn.min.js', [], SRFM_PRO_VER, true );
		$scripts = [
			[
				'unique_file'         => 'srfmUserRegistrationFrontend',
				'unique_handle'       => 'user-registration-frontend',
				'extra_dependencies'  => [ 'srfm-pro-zxcvbn' ],
				'maybe_localize_data' => true,
			],
		];
		$this->enqueue_scripts( $scripts );
	}

	/**
	 * Render user registration CSS variables.
	 *
	 * @param array<string,string> $params array of values sent by action 'srfm_form_css_variables'.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function render_user_registration_css_variables( $params ) {
		// The unset is used to handle php insights error for unused parameter.
		unset( $params );
		$css_variables = [
			'--srfm-password-strength-weak'                => '#DC2626',
			'--srfm-password-strength-weak-border-glow'    => 'hsl( from var(--srfm-password-strength-weak) h s l / 0.15 )',
			'--srfm-password-strength-weak-border-color'   => 'hsl( from var(--srfm-password-strength-weak) h s l / 0.65 )',
			'--srfm-password-strength-medium'              => '#D97706',
			'--srfm-password-strength-medium-border-glow'  => 'hsl( from var(--srfm-password-strength-medium) h s l / 0.15 )',
			'--srfm-password-strength-medium-border-color' => 'hsl( from var(--srfm-password-strength-medium) h s l / 0.65 )',
			'--srfm-password-strength-strong'              => '#16A34A',
			'--srfm-password-strength-strong-border-glow'  => 'hsl( from var(--srfm-password-strength-strong) h s l / 0.15 )',
			'--srfm-password-strength-strong-border-color' => 'hsl( from var(--srfm-password-strength-strong) h s l / 0.65 )',
		];

		// Escape and echo the CSS variables.
		Pro_Helper::add_css_variables( $css_variables );
	}

	/**
	 * Add the spacing variables for the login block used in user registration.
	 * This is used in the frontend.
	 *
	 * @param array<string|mixed> $sizes array of css variables coming from 'srfm_css_vars_sizes' filter.
	 * @since 1.8.0
	 * @return array<string|mixed>
	 */
	public function user_registration_spacing_variables( $sizes ) {
		return array_replace_recursive(
			$sizes,
			[
				'small'  => [
					'--srfm-login-row-gap' => '12px',
				],
				'medium' => [
					'--srfm-login-row-gap' => '14px',
				],
				'large'  => [
					'--srfm-login-row-gap' => '16px',
				],
			]
		);
	}

	/**
	 * Add password field dynamic option callback.
	 *
	 * @param array<string> $callbacks Array of callbacks.
	 *
	 * @since 1.8.0
	 * @return array<mixed>
	 */
	public function add_password_dynamic_option_callback( $callbacks ) {
		$callbacks['1.8.0'] = [ 'SRFM_Pro\Inc\Business\User_Registration\Init::add_password_default_dynamic_options' ];
		return $callbacks;
	}

	/**
	 * Add password field dynamic option callback.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public static function add_password_default_dynamic_options() {
		$previous_options = get_option( 'srfm_default_dynamic_block_option' );

		if ( ! empty( $previous_options ) && is_array( $previous_options ) ) {
			$required_message = Helper::get_common_err_msg();
			$current_options  = self::add_password_messages();
			$current_options  = self::add_password_default_dynamic_pro_block_values( $current_options, $required_message );

			// Iterate $current_options and update the options.
			foreach ( $current_options as $key => $value ) {
				if ( ! isset( $previous_options[ $key ] ) ) {
					$previous_options[ $key ] = $value;
				}
			}
			update_option( 'srfm_default_dynamic_block_option', $previous_options );
		}
	}

	/**
	 * Add login endpoint.
	 *
	 * @param array<string, mixed> $endpoints Array of endpoints.
	 * @since 1.8.0
	 * @return array<string, mixed>
	 */
	public function add_login_endpoint( $endpoints ) {
		$endpoints['login'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'srfm_handle_login' ],
			'permission_callback' => '__return_true',
		];

		/*
		 * NOTE: there is deliberately no 'lost-password' endpoint here.
		 *
		 * It was removed in 2.12.3 along with the frontend pre-flight that was its only
		 * caller — the reset now runs server-side on `srfm_before_submission` (see
		 * process_lost_password()). Left registered it was an unauthenticated
		 * `__return_true` route that called retrieve_password() with no throttle and
		 * returned the WP_Error message verbatim: an account-existence oracle and an
		 * unmetered mail relay against any known login. Do not reinstate it.
		 */
		$endpoints['reset-password'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'srfm_handle_reset_password' ],
			'permission_callback' => '__return_true',
		];

		// Add the endpoint for fetching the user roles.
		$endpoints['user-roles']       = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_user_roles' ],
			'permission_callback' => static function () {
				return Helper::current_user_can(); // Only allow admins to access this endpoint.
			},
		];
		$endpoints['custom-meta-keys'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_custom_meta_keys' ],
			'permission_callback' => static function () {
				return Helper::current_user_can(); // Only allow admins to access this endpoint.
			},
		];

		return $endpoints;
	}

	/**
	 * Handle login request.
	 *
	 * @param \WP_REST_Request $request The request object.
	 * @since 1.8.0
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function srfm_handle_login( $request ) {
		$token   = Helper::get_string_value( $request->get_header( 'X-WP-Submit-Token' ) );
		$form_id = absint( $request->get_param( 'form_id' ) );
		if ( ! \SRFM\Inc\Submit_Token::verify( $token, $form_id ) ) {
			return new \WP_Error( 'srfm_token_invalid', __( 'Security verification failed. Please refresh the page and try again.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		// If the user is logged in then return an error.
		//
		// The cookie is checked as well as is_user_logged_in(), because this route
		// is called without an X-WP-Nonce header: core reads a cookie-authenticated
		// REST request carrying no nonce as anonymous and resets the current user to
		// 0 before dispatch (rest_cookie_check_errors()), which would leave
		// is_user_logged_in() permanently false and this branch dead.
		//
		// Sending a nonce instead is not an option here. The login block renders on
		// public, page-cacheable pages, and core answers a nonce that fails
		// verification with a hard `rest_cookie_invalid_nonce` 403 — so a value
		// baked into a cached page would break login outright once it aged out.
		// Reading the logged-in cookie directly is unaffected by the reset.
		if ( is_user_logged_in() || wp_validate_auth_cookie( '', 'logged_in' ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'code'    => 'already_logged_in',
					'message' => __( 'You are already logged in.', 'sureforms-pro' ),
				],
				200
			);
		}

		$creds = [
			'user_login'    => Helper::get_string_value( $request->get_param( 'username' ) ),
			'user_password' => Helper::get_string_value( $request->get_param( 'password' ) ),
			'remember'      => $request->get_param( 'remember' ) === 'true',
		];

		// Let core resolve the cookie's Secure flag. Passing an explicit `false` here
		// pinned the auth cookie to non-Secure even over TLS, so it was emitted without
		// the Secure attribute and then replayed on cleartext HTTP requests — and the
		// wp_set_auth_cookie() call below cannot retract a Set-Cookie already in the
		// response. Omitting the argument makes core fall back to is_ssl(), matching the
		// value used for wp_set_auth_cookie() below. The `secure_signon_cookie` filter
		// still applies either way, so sites can override it.
		$user = wp_signon( $creds );

		if ( is_wp_error( $user ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'code'    => 'login_failed',
					'message' => $user->get_error_message(),
				],
				401
			);
		}

		// Set the current user and authentication cookie so the login session is established.
		wp_set_current_user( $user->ID );
		$secure = is_ssl();

		// Capture the logged-in cookie value via action hook so we can populate $_COOKIE
		// before calling wp_create_nonce(). wp_set_auth_cookie() uses setcookie() which
		// sends the Set-Cookie header but does NOT update $_COOKIE in the current request.
		// wp_create_nonce() calls wp_get_session_token() which reads $_COOKIE, so without
		// this, nonces are created with an empty session token and fail verification on the
		// next request when the real session token is present.
		$srfm_logged_in_cookie = '';
		$srfm_cookie_hook      = static function ( $cookie_value ) use ( &$srfm_logged_in_cookie ) {
			$srfm_logged_in_cookie = $cookie_value;
		};
		add_action( 'set_logged_in_cookie', $srfm_cookie_hook );

		wp_set_auth_cookie(
			$user->ID,
			$creds['remember'],
			$secure
		);

		remove_action( 'set_logged_in_cookie', $srfm_cookie_hook );

		// Populate $_COOKIE so wp_get_session_token() returns the correct token.
		if ( ! empty( $srfm_logged_in_cookie ) ) {
			// COOKIEHASH is a WordPress core constant defined in wp-includes/default-constants.php.
			// It's a salted hash used to make cookie names unique per WordPress installation.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- COOKIEHASH is a WordPress core constant.
			// @phpstan-ignore-next-line Constant COOKIEHASH is a WordPress core constant defined in wp-includes/default-constants.php
			$_COOKIE[ 'wordpress_logged_in_' . COOKIEHASH ] = $srfm_logged_in_cookie;
		}

		$login_response = new \WP_REST_Response(
			[
				'success' => true,
				'code'    => 'login_success',
				'message' => __( 'Login successful.', 'sureforms-pro' ),
				'user'    => [
					'id'    => $user->ID,
					'name'  => $user->display_name,
					'email' => $user->user_email,
				],
			],
			200
		);
		$login_response->header( 'X-WP-Nonce', wp_create_nonce( 'wp_rest' ) );
		return $login_response;
	}

	/**
	 * Handle reset password request.
	 *
	 * @param \WP_REST_Request $request The request object.
	 * @since 2.5.0
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function srfm_handle_reset_password( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_Error( 'invalid_nonce', __( 'Nonce Verification Failed', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		$key      = Helper::get_string_value( $request->get_param( 'key' ) );
		$login    = Helper::get_string_value( $request->get_param( 'login' ) );
		$password = Helper::get_string_value( $request->get_param( 'password' ) );

		// Validate required parameters.
		if ( empty( $key ) || empty( $login ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'code'    => 'invalid_request',
					'message' => __( 'Invalid password reset link.', 'sureforms-pro' ),
				],
				400
			);
		}

		if ( empty( $password ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'code'    => 'empty_password',
					'message' => __( 'Please enter a new password.', 'sureforms-pro' ),
				],
				400
			);
		}

		// Validate the reset key.
		$user = check_password_reset_key( $key, $login );

		if ( is_wp_error( $user ) ) {
			$error_code = $user->get_error_code();
			if ( 'expired_key' === $error_code ) {
				$message = __( 'This password reset link has expired. Please request a new one.', 'sureforms-pro' );
			} else {
				$message = __( 'Invalid password reset link. Please request a new one.', 'sureforms-pro' );
			}

			return new \WP_REST_Response(
				[
					'success' => false,
					'code'    => $error_code,
					'message' => $message,
				],
				400
			);
		}

		// Reset the password.
		reset_password( $user, $password );

		/**
		 * Fires after the user's password has been reset.
		 *
		 * @since 2.5.0
		 * @param \WP_User $user The user whose password was reset.
		 */
		do_action( 'srfm_after_password_reset', $user );

		return new \WP_REST_Response(
			[
				'success' => true,
				'code'    => 'password_reset',
				'message' => __( 'Your password has been reset successfully. You can now log in with your new password.', 'sureforms-pro' ),
			],
			200
		);
	}

	/**
	 * Add login block preview.
	 *
	 * @param array<string,string> $preview_images Array of preview images.
	 * @since 1.8.0
	 * @return array<string,string>
	 */
	public function add_login_block_preview( $preview_images ) {
		return array_merge(
			$preview_images,
			[
				'login_preview'          => SRFM_PRO_URL . 'inc/business/user-registration/login/login-preview.svg',
				'password_preview'       => SRFM_PRO_URL . 'inc/business/user-registration/password/password-preview.svg',
				'register_preview'       => SRFM_PRO_URL . 'inc/business/user-registration/register/register-preview.svg',
				'lost_password_preview'  => SRFM_PRO_URL . 'inc/business/user-registration/lost-password/lost-password-preview.svg',
				'reset_password_preview' => SRFM_PRO_URL . 'inc/business/user-registration/reset-password/reset-password-preview.svg',
			]
		);
	}

	/**
	 * Add the smart tags for user registration.
	 *
	 * @param array<string,string> $smart_tags Array of smart tags.
	 * @since 1.8.0
	 * @return array<string,string>
	 */
	public function add_user_registration_smart_tags( $smart_tags ) {
		return array_merge(
			$smart_tags,
			[
				'{login_url}'            => __( 'Login URL', 'sureforms-pro' ),
				'{register_url}'         => __( 'Registration URL', 'sureforms-pro' ),
				'{forgot_url}'           => __( 'Forgot Password URL', 'sureforms-pro' ),
				'{logout_url}'           => __( 'Logout URL', 'sureforms-pro' ),
				'{reset_password_url}'   => __( 'Reset Password URL', 'sureforms-pro' ),
				'{password_reset_email}' => __( 'Password Reset Recipient', 'sureforms-pro' ),
			]
		);
	}

	/**
	 * Parse the above custom smart tags for user registration.
	 *
	 * @param string               $parsed The parsed smart tag.
	 * @param array<string,string> $context The context of the smart tag.
	 * @since 1.8.0
	 * @return mixed
	 */
	public function parse_user_registration_smart_tags( $parsed, $context ) {
		unset( $parsed );
		$tag      = $context['tag'] ?? '';
		$settings = get_option( 'srfm_pro_user_registration_settings', [] );

		// Ensure $settings is an array.
		if ( ! is_array( $settings ) ) {
			$settings = [];
		}

		$custom_registration_page   = ! empty( $settings['srfm_enable_custom_registration_page'] ) ? Helper::get_string_value( $settings['srfm_custom_registration_page'] ?? '' ) : '';
		$custom_login_page          = ! empty( $settings['srfm_enable_custom_login_page'] ) ? Helper::get_string_value( $settings['srfm_custom_login_page'] ?? '' ) : '';
		$custom_lost_password_page  = ! empty( $settings['srfm_enable_custom_lost_password_page'] ) ? Helper::get_string_value( $settings['srfm_custom_lost_password_page'] ?? '' ) : '';
		$custom_reset_password_page = ! empty( $settings['srfm_enable_custom_reset_password_page'] ) ? Helper::get_string_value( $settings['srfm_custom_reset_password_page'] ?? '' ) : '';

		switch ( $tag ) {
			case '{login_url}':
				return ! empty( $custom_login_page ) ? $custom_login_page : wp_login_url();
			case '{register_url}':
				return ! empty( $custom_registration_page ) ? $custom_registration_page : wp_registration_url();
			case '{forgot_url}':
				return ! empty( $custom_lost_password_page ) ? $custom_lost_password_page : wp_lostpassword_url();
			case '{logout_url}':
				return wp_logout_url( Helper::get_string_value( get_permalink() ) ); // Redirect to current page after logging out.
			case '{reset_password_url}':
				/**
				 * Render-context gate (defense in depth). A resolved value is a LIVE
				 * password-reset link (action=rp&key=…&login=…). It must never reach a
				 * form's confirmation message or submit-form response, which are returned
				 * to an anonymous submitter — that is an unauthenticated administrator
				 * takeover. The tag resolves to '' by default; a future reset-email flow
				 * that renders the link into the email SENT TO THE ACCOUNT OWNER opts in
				 * via this filter. Registered in the general smart-tag list, so this gate,
				 * not the editor picker, is the security boundary.
				 *
				 * @since 2.12.3
				 * @param bool                 $allow   Whether to resolve the tag. Default false.
				 * @param array<string,string> $context Smart-tag context.
				 */
				if ( ! apply_filters( 'srfm_allow_reset_password_url_tag', false, $context ) ) {
					return '';
				}
				return $this->generate_reset_password_url( $custom_reset_password_page );
			case '{password_reset_email}':
				/**
				 * Filter whether `{password_reset_email}` may resolve in this render.
				 *
				 * Default-deny, mirroring `srfm_allow_reset_password_url_tag` above and
				 * for the same reason: the tag is offered in the editor picker, so an
				 * author can place it in a lost-password form's CONFIRMATION MESSAGE,
				 * which is rendered back to whoever submitted the form. An anonymous
				 * visitor submitting a known login would then be handed that account's
				 * email address, and the empty-vs-populated result is an
				 * account-existence oracle for any guessed username besides.
				 *
				 * Only a template rendered TO THE ACCOUNT OWNER should opt in.
				 *
				 * @since 2.12.3
				 * @param bool                 $allow   Whether to resolve the tag. Default false.
				 * @param array<string,string> $context Smart-tag context.
				 */
				if ( ! apply_filters( 'srfm_allow_password_reset_email_tag', false, $context ) ) {
					return '';
				}
				$user = self::resolve_lost_password_user();
				return $user instanceof \WP_User ? $user->user_email : '';
			default:
				return null; // Let the main callback handle it if tags are not matched.
		}
	}

	/**
	 * Save User Registration Settings
	 *
	 * @param bool         $result Result of the save operation.
	 * @param array<mixed> $settings Setting options.
	 * @since 1.8.0
	 *
	 * @return bool
	 */
	public static function save_user_registration_settings( $result, $settings ) {
		// Unset the result variable to prevent phpinsights error for unused variable.
		unset( $result );
		$enabled_registration_page   = isset( $settings['srfm_enable_custom_registration_page'] ) ?
			(bool) $settings['srfm_enable_custom_registration_page'] : false;
		$registration_page           = isset( $settings['srfm_custom_registration_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_registration_page'] ) : '';
		$enabled_login_page          = isset( $settings['srfm_enable_custom_login_page'] ) ?
			(bool) $settings['srfm_enable_custom_login_page'] : false;
		$login_page                  = isset( $settings['srfm_custom_login_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_login_page'] ) : '';
		$enabled_lost_password_page  = isset( $settings['srfm_enable_custom_lost_password_page'] ) ?
			(bool) $settings['srfm_enable_custom_lost_password_page'] : false;
		$lost_password_page          = isset( $settings['srfm_custom_lost_password_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_lost_password_page'] ) : '';
		$enabled_reset_password_page = isset( $settings['srfm_enable_custom_reset_password_page'] ) ?
			(bool) $settings['srfm_enable_custom_reset_password_page'] : false;
		$reset_password_page         = isset( $settings['srfm_custom_reset_password_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_reset_password_page'] ) : '';

		return update_option(
			'srfm_pro_user_registration_settings',
			[
				'srfm_enable_custom_registration_page'   => $enabled_registration_page,
				'srfm_enable_custom_login_page'          => $enabled_login_page,
				'srfm_custom_registration_page'          => $registration_page,
				'srfm_custom_login_page'                 => $login_page,
				'srfm_enable_custom_lost_password_page'  => $enabled_lost_password_page,
				'srfm_custom_lost_password_page'         => $lost_password_page,
				'srfm_enable_custom_reset_password_page' => $enabled_reset_password_page,
				'srfm_custom_reset_password_page'        => $reset_password_page,
			]
		);
	}

	/**
	 * Get User Registration Settings
	 *
	 * @param array<mixed>  $global_settings Global settings array.
	 * @param array<string> $options_to_get Options to get.
	 * @since 1.8.0
	 *
	 * @return array<mixed> $global_settings Global settings array with user registration settings added.
	 */
	public function get_user_registration_settings( $global_settings, $options_to_get ) {
		if ( in_array( 'srfm_pro_user_registration_settings', $options_to_get, true ) && empty( $global_settings['srfm_pro_user_registration_settings'] ) ) {
			$global_settings['srfm_pro_user_registration_settings'] = [
				'srfm_enable_custom_registration_page'   => false,
				'srfm_custom_registration_page'          => '',
				'srfm_enable_custom_login_page'          => false,
				'srfm_custom_login_page'                 => '',
				'srfm_enable_custom_lost_password_page'  => false,
				'srfm_custom_lost_password_page'         => '',
				'srfm_enable_custom_reset_password_page' => false,
				'srfm_custom_reset_password_page'        => '',
			];
		}

		return $global_settings;
	}

	/**
	 * Register additional post meta for user registration.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function add_user_registration_meta() {
		register_post_meta(
			'sureforms_form',
			'_srfm_user_registration_settings',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => [ $this, 'sanitize_user_registration_settings' ],
			]
		);
	}

	/**
	 * Sanitize user registration settings.
	 *
	 * Sanitizes each field in the user registration settings:
	 * - name (string): Sanitized with sanitize_text_field()
	 * - status (boolean): Cast to boolean with (bool)
	 * - registrationType (string): Sanitized with sanitize_text_field()
	 * - username (string): Sanitized with sanitize_text_field()
	 * - firstname (string): Sanitized with sanitize_text_field()
	 * - lastname (string): Sanitized with sanitize_text_field()
	 * - email (string): Sanitized with sanitize_text_field()
	 * - website (string): Sanitized with sanitize_text_field() (holds a smart tag)
	 * - password (string): Sanitized with sanitize_text_field()
	 * - userRole (string): Sanitized with sanitize_text_field()
	 * - sendUserEmail (boolean): Cast to boolean with (bool)
	 * - emailNotificationType (string): Sanitized with sanitize_text_field()
	 * - customUserMeta (array): Each key and value sanitized with sanitize_text_field()
	 * - autoLogin (boolean): Cast to boolean with (bool)
	 *
	 * @param string $meta_value The meta value to sanitize.
	 * @since 1.8.0
	 * @return string Sanitized JSON string.
	 */
	public function sanitize_user_registration_settings( $meta_value ) {
		if ( empty( $meta_value ) ) {
			return '';
		}

		$decoded_value = json_decode( $meta_value, true );

		if ( ! is_array( $decoded_value ) ) {
			return '';
		}

		$sanitized_data = [];

		foreach ( $decoded_value as $registration ) {
			if ( ! is_array( $registration ) ) {
				continue;
			}

			$sanitized_item = [
				'name'                  => isset( $registration['name'] ) ? sanitize_text_field( $registration['name'] ) : '',
				'status'                => isset( $registration['status'] ) ? (bool) $registration['status'] : false,
				'registrationType'      => isset( $registration['registrationType'] ) ? sanitize_text_field( $registration['registrationType'] ) : 'create',
				'username'              => isset( $registration['username'] ) ? sanitize_text_field( $registration['username'] ) : '',
				'firstname'             => isset( $registration['firstname'] ) ? sanitize_text_field( $registration['firstname'] ) : '',
				'lastname'              => isset( $registration['lastname'] ) ? sanitize_text_field( $registration['lastname'] ) : '',
				'email'                 => isset( $registration['email'] ) ? sanitize_text_field( $registration['email'] ) : '',
				// Stored as a `{form:slug}` smart tag, so keep it a plain string —
				// esc_url_raw() strips `{`/`}` and mangles the tag. The mapped URL is
				// URL-sanitised later at the wp_insert_user() boundary (pre_user_url).
				'website'               => isset( $registration['website'] ) ? sanitize_text_field( $registration['website'] ) : '',
				'password'              => isset( $registration['password'] ) ? sanitize_text_field( $registration['password'] ) : '',
				'userRole'              => isset( $registration['userRole'] ) ? sanitize_text_field( $registration['userRole'] ) : 'subscriber',
				'sendUserEmail'         => isset( $registration['sendUserEmail'] ) ? (bool) $registration['sendUserEmail'] : false,
				'emailNotificationType' => isset( $registration['emailNotificationType'] ) ? sanitize_text_field( $registration['emailNotificationType'] ) : 'email',
				'autoLogin'             => isset( $registration['autoLogin'] ) ? (bool) $registration['autoLogin'] : false,
			];

			// Handle custom user meta separately.
			if ( isset( $registration['customUserMeta'] ) && is_array( $registration['customUserMeta'] ) ) {
				$sanitized_item['customUserMeta'] = [];

				foreach ( $registration['customUserMeta'] as $meta ) {
					if ( is_array( $meta ) ) {
						$sanitized_item['customUserMeta'][] = [
							'key'   => isset( $meta['key'] ) ? sanitize_text_field( $meta['key'] ) : '',
							'value' => isset( $meta['value'] ) ? sanitize_text_field( $meta['value'] ) : '',
						];
					}
				}
			} else {
				$sanitized_item['customUserMeta'] = [
					[
						'key'   => '',
						'value' => '',
					],
				];
			}

			$sanitized_data[] = $sanitized_item;
		}

		$return = wp_json_encode( $sanitized_data );
		return $return ? $return : '';
	}

	/**
	 * Fetch roles from the site, and the roles that are allowed to register.
	 *
	 * @since 1.8.0
	 * @return \WP_REST_Response
	 */
	public function get_user_roles() {
		$user_roles      = wp_roles()->get_names();
		$formatted_roles = [];
		foreach ( $user_roles as $key => $label ) {
			// Skip the administrator role for the inital release.
			if ( 'administrator' === $key ) {
				continue;
			}

			$formatted_roles[] = [
				'label' => $label,
				'value' => $key,
			];
		}

		return new \WP_REST_Response(
			[
				'success' => true,
				'roles'   => $formatted_roles,
			],
			200
		);
	}

	/**
	 * API Endpoint callback to get all custom meta keys.
	 *
	 * @since 1.8.0
	 * @return \WP_REST_Response
	 */
	public static function get_custom_meta_keys() {
		// Get all custom meta keys.
		$meta_keys = self::get_all_custom_meta_keys();

		$formatted_keys = [];

		// Add existing meta keys.
		if ( is_array( $meta_keys ) ) {
			foreach ( $meta_keys as $key ) {
				$formatted_keys[] = [
					'label' => $key,
					'value' => $key,
				];
			}
		}

		// Add the "Add Custom Meta" option in the end.
		$formatted_keys[] = [
			'label' => __( 'Add Custom Meta', 'sureforms-pro' ),
			'value' => '__add_custom_meta__',
		];

		return new \WP_REST_Response(
			[
				'success' => true,
				'keys'    => $formatted_keys,
			],
			200
		);
	}

	/**
	 * Redirect users to custom login/registration pages if configured.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function redirect_to_custom_pages() {
		// Don't redirect if we're in admin area.
		if ( is_admin() ) {
			return;
		}

		// Don't redirect AJAX requests.
		if ( wp_doing_ajax() ) {
			return;
		}

		// Don't redirect REST API requests.
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		// Get user registration settings.
		$settings = get_option( 'srfm_pro_user_registration_settings', [] );

		// Ensure $settings is an array.
		if ( ! is_array( $settings ) ) {
			$settings = [];
		}

		// Get current action.
		$current_action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : 'login'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed for this case.

		// Handle login page redirect.
		if ( 'login' === $current_action ) {
			$this->maybe_redirect_login_page( $settings );
		}

		// Handle registration page redirect.
		if ( 'register' === $current_action ) {
			$this->maybe_redirect_registration_page( $settings );
		}

		// Handle lost password page redirect.
		if ( 'lostpassword' === $current_action ) {
			$this->maybe_redirect_lost_password_page( $settings );
		}

		// Handle reset password page redirect (action=rp or action=resetpass).
		if ( 'rp' === $current_action || 'resetpass' === $current_action ) {
			$this->maybe_redirect_reset_password_page( $settings );
		}
	}

	/**
	 * Filter login URL to use custom login page if configured
	 *
	 * @param string $login_url The login URL.
	 * @param string $redirect The redirect URL.
	 * @param bool   $force_reauth Whether to force reauth.
	 * @since 1.8.0
	 * @return string
	 */
	public function filter_login_url( $login_url, $redirect = '', $force_reauth = false ) {
		// Get user registration settings.
		$settings = get_option( 'srfm_pro_user_registration_settings', [] );

		// Ensure $settings is an array.
		if ( ! is_array( $settings ) ) {
			return $login_url;
		}

		$custom_login_enabled = ! empty( $settings['srfm_enable_custom_login_page'] );
		$custom_login_page    = ! empty( $settings['srfm_custom_login_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_login_page'] ) : '';

		// Return original URL if custom login is not configured.
		if ( ! $custom_login_enabled || empty( $custom_login_page ) ) {
			return $login_url;
		}

		// Don't override if force reauth is required (admin login scenarios).
		if ( $force_reauth ) {
			return $login_url;
		}

		// Build custom login URL with redirect parameter if provided.
		$custom_url = $custom_login_page;
		if ( ! empty( $redirect ) ) {
			$custom_url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $custom_url );
		}

		return $custom_url;
	}

	/**
	 * Filter register URL to use custom registration page if configured
	 *
	 * @param string $register_url The registration URL.
	 * @since 1.8.0
	 * @return string
	 */
	public function filter_register_url( $register_url ) {
		// Get user registration settings.
		$settings = get_option( 'srfm_pro_user_registration_settings', [] );

		// Ensure $settings is an array.
		if ( ! is_array( $settings ) ) {
			return $register_url;
		}

		$custom_registration_enabled = ! empty( $settings['srfm_enable_custom_registration_page'] );
		$custom_registration_page    = ! empty( $settings['srfm_custom_registration_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_registration_page'] ) : '';

		// Return original URL if custom registration is not configured.
		if ( ! $custom_registration_enabled || empty( $custom_registration_page ) ) {
			return $register_url;
		}

		return $custom_registration_page;
	}

	/**
	 * Filter lost password URL to use custom lost password page if configured
	 *
	 * @param string $lostpassword_url The lost password URL.
	 * @param string $redirect The redirect URL.
	 * @since 2.5.0
	 * @return string
	 */
	public function filter_lostpassword_url( $lostpassword_url, $redirect = '' ) {
		// Get user registration settings.
		$settings = get_option( 'srfm_pro_user_registration_settings', [] );

		// Ensure $settings is an array.
		if ( ! is_array( $settings ) ) {
			return $lostpassword_url;
		}

		$custom_lost_password_enabled = ! empty( $settings['srfm_enable_custom_lost_password_page'] );
		$custom_lost_password_page    = ! empty( $settings['srfm_custom_lost_password_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_lost_password_page'] ) : '';

		// Return original URL if custom lost password is not configured.
		if ( ! $custom_lost_password_enabled || empty( $custom_lost_password_page ) ) {
			return $lostpassword_url;
		}

		// Build custom lost password URL with redirect parameter if provided.
		$custom_url = $custom_lost_password_page;
		if ( ! empty( $redirect ) ) {
			$custom_url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $custom_url );
		}

		return $custom_url;
	}

	/**
	 * Capture the password reset key WordPress generates during retrieve_password().
	 *
	 * Held only in per-request static properties — the sole legitimate source for
	 * the {reset_password_url} / {password_reset_email} tags, proving core actually
	 * ran the reset for this login in this request. The key is deliberately NOT
	 * persisted: core stores only a hash in user_activation_key, and writing a
	 * reversibly-encrypted live key into wp_options would reintroduce a recoverable
	 * secret (and enumerate which logins requested resets).
	 *
	 * @param string $user_login The user login.
	 * @param string $key The password reset key.
	 * @since 2.5.0
	 * @since 2.12.3 The key is only captured while our own retrieve_password() call is
	 *              armed, so an unrelated key minted this request can't feed the tags.
	 * @return void
	 */
	public function capture_password_reset_key( $user_login, $key ) {
		// Only trust the key when it was minted by our own process_lost_password()
		// call this request. `retrieve_password_key` also fires from core's
		// get_password_reset_key() (e.g. wp_new_user_notification) and third-party code.
		if ( ! self::$capture_armed ) {
			return;
		}
		self::$captured_reset_key  = $key;
		self::$captured_user_login = $user_login;
	}

	/**
	 * Run the WordPress password reset for a lost-password form during the submission
	 * request, so both the WP core reset email and our {reset_password_url} /
	 * {password_reset_email} tags work from a single, cache-safe, token+captcha-gated
	 * request.
	 *
	 * Security: the account is NEVER named by the client. The server derives which
	 * submitted field is the account field from the form's own block markup — the
	 * `srfm/input` nested in the `srfm/lost-password` block — and reads only that
	 * field's value. The visitor controls the value typed into the one field the form
	 * defines, exactly like core `wp-login.php?action=lostpassword`. On any failure the
	 * form proceeds normally with the tags empty (no account-existence oracle).
	 *
	 * @param array<string,mixed> $form_data Submission payload (`form_id` + `data`).
	 * @since 2.12.3
	 * @return void
	 */
	public function process_lost_password( $form_data ) {
		$form_id = isset( $form_data['form_id'] ) ? Helper::get_integer_value( $form_data['form_id'] ) : 0;
		$post    = $form_id ? get_post( $form_id ) : null;

		// The form must actually contain the lost-password block.
		if ( ! $post instanceof \WP_Post || ! has_block( 'srfm/lost-password', $post ) ) {
			return;
		}

		// The SERVER picks the account field from the form's markup; the client can't
		// steer resolution to another field or another account.
		$field = self::get_lost_password_field_identifiers( parse_blocks( $post->post_content ) );
		if ( '' === $field['slug'] && '' === $field['block_id'] ) {
			return;
		}

		$submitted = isset( $form_data['data'] ) && is_array( $form_data['data'] ) ? $form_data['data'] : [];
		$value     = '';
		foreach ( $submitted as $key => $val ) {
			if ( ! is_string( $key ) || ! is_string( $val ) ) {
				continue;
			}

			// Match the slug first: this hook receives the output of
			// Form_Submit::prepare_submission_data(), which keys every field by its slug
			// and discards the block_id half of the raw key. The block_id branch stays as
			// a fallback for a caller (or an srfm_update_prepared_submission_data filter)
			// that preserves raw submission keys.
			$matches_slug     = '' !== $field['slug'] && $key === $field['slug'];
			$matches_block_id = '' !== $field['block_id'] && false !== strpos( $key, $field['block_id'] );

			if ( $matches_slug || $matches_block_id ) {
				$value = sanitize_text_field( $val );
				break;
			}
		}

		// Load-bearing: core retrieve_password() falls back to $_POST['user_login'] on a
		// falsy argument, which would re-open a client-named account channel.
		if ( '' === $value ) {
			return;
		}

		// This runs on `srfm_before_submission`, which fires before Entries::add() in Free
		// (form-submit.php:527 vs :640) — deliberately, so the key captured by
		// retrieve_password_key is available to the {reset_password_url} /
		// {password_reset_email} tags rendered later in the same request.
		//
		// The consequence is that a failure after this point returns "Unable to submit
		// form" even though a valid reset email has already gone out, and an immediate
		// retry sends a second email while invalidating the first key.
		//
		// A previous attempt to suppress the duplicate with a short-lived transient was
		// REVERTED: returning early skips retrieve_password(), which is what populates the
		// per-request reset state, so an otherwise-successful retry rendered
		// {reset_password_url} and {password_reset_email} empty — a worse outcome than the
		// duplicate it prevented. Suppressing the core email is not sufficient; the whole
		// reset-flow output has to be reproduced, which cannot be done without re-running
		// retrieve_password(). Fixing this properly means either treating a completed reset
		// as a successful submission even when optional entry storage fails, or persisting
		// the captured key across the retry — both are product decisions, tracked for a
		// follow-up release.
		//
		// Arm capture only around our own call so the retrieve_password_key hook records
		// this login, then core sends its reset email in this request.
		self::$capture_armed = true;
		try {
			retrieve_password( $value );
		} finally {
			self::$capture_armed = false;
		}
	}

	/**
	 * Walk parsed blocks to find the account field for a lost-password form: the first
	 * `srfm/input` block nested inside an `srfm/lost-password` block.
	 *
	 * Returns BOTH identifiers, because the two consumers key differently. The raw
	 * submission key embeds `block_id`, but `srfm_before_submission` receives the output
	 * of Form_Submit::prepare_submission_data(), which re-keys every field by its slug —
	 * the block_id lives in the half of the key that function discards. Resolving on the
	 * slug is therefore what actually matches; block_id is kept as a fallback for any
	 * caller that hands over raw keys.
	 *
	 * @param array<mixed> $blocks Parsed blocks.
	 * @since 2.12.3
	 * @return array{block_id:string,slug:string} Empty strings when not found.
	 */
	private static function get_lost_password_field_identifiers( $blocks ) {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			$inner = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? $block['innerBlocks'] : [];
			if ( 'srfm/lost-password' === ( $block['blockName'] ?? '' ) ) {
				$field = self::first_input_identifiers( $inner );
				if ( '' !== $field['block_id'] || '' !== $field['slug'] ) {
					return $field;
				}
			}
			// The lost-password block may itself be nested (columns/group).
			if ( ! empty( $inner ) ) {
				$field = self::get_lost_password_field_identifiers( $block['innerBlocks'] );
				if ( '' !== $field['block_id'] || '' !== $field['slug'] ) {
					return $field;
				}
			}
		}
		return [
			'block_id' => '',
			'slug'     => '',
		];
	}

	/**
	 * Return the block_id and slug of the first `srfm/input` block in a (possibly nested)
	 * block tree. Both are empty strings when none is present.
	 *
	 * @param array<mixed> $blocks Parsed blocks.
	 * @since 2.12.3
	 * @return array{block_id:string,slug:string}
	 */
	private static function first_input_identifiers( $blocks ) {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			if ( 'srfm/input' === ( $block['blockName'] ?? '' ) ) {
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];
				return [
					'block_id' => Helper::get_string_value( $attrs['block_id'] ?? '' ),
					'slug'     => Helper::get_string_value( $attrs['slug'] ?? '' ),
				];
			}
			$inner = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? $block['innerBlocks'] : [];
			if ( ! empty( $inner ) ) {
				$field = self::first_input_identifiers( $inner );
				if ( '' !== $field['block_id'] || '' !== $field['slug'] ) {
					return $field;
				}
			}
		}
		return [
			'block_id' => '',
			'slug'     => '',
		];
	}

	/**
	 * Resolve the user a lost-password request was made for.
	 *
	 * ONLY the login WordPress captured in this request (via the retrieve_password_key
	 * hook, set only when core actually ran a reset for that account) is trusted. The
	 * earlier fallbacks — a client-supplied POST field and a scan of the submission
	 * data — were removed: they let an unauthenticated caller name any account (e.g.
	 * "admin") and have its reset key / email surfaced through the {reset_password_url}
	 * and {password_reset_email} tags in the response, an account-takeover / PII-oracle
	 * path. A resolved-user lookup is not authorization, so there is no fallback.
	 *
	 * @since 2.12.3
	 * @return \WP_User|false The matching user, or false when no reset ran this request.
	 */
	private static function resolve_lost_password_user() {
		if ( empty( self::$captured_user_login ) ) {
			return false;
		}

		$user = get_user_by( 'login', self::$captured_user_login );
		return $user instanceof \WP_User ? $user : false;
	}

	/**
	 * Generate the reset password URL from the key WordPress captured in THIS
	 * request. Returns '' unless core's retrieve_password() actually ran for a
	 * login in this request — the tag never mints a fresh key or resolves a user
	 * from untrusted input, so it can't be turned into an account-takeover link.
	 * Cached per request so the same link is reused everywhere.
	 *
	 * @param string $custom_reset_password_page Custom reset password page URL if configured.
	 * @since 2.5.0
	 * @since 2.12.3 The reset key is no longer persisted to a transient; it is read from
	 *              the per-request capture. Removed the per-process static cache, which
	 *              was not keyed to the captured login and could return user A's link
	 *              after a second reset re-pointed the statics to user B.
	 * @return string The reset password URL, or '' when no reset ran this request.
	 */
	private function generate_reset_password_url( $custom_reset_password_page ) {
		// Only the key captured from our own retrieve_password() in this request is a
		// legitimate source. No captured key → nothing to link to; render nothing. Not
		// cached in a static: the statics can be re-pointed within one PHP process, and
		// a cache not keyed to the login would then serve the wrong user's link.
		if ( empty( self::$captured_reset_key ) || empty( self::$captured_user_login ) ) {
			return '';
		}

		$reset_key  = self::$captured_reset_key;
		$user_login = self::$captured_user_login;

		// Build the reset password URL.
		$base_url = ! empty( $custom_reset_password_page )
			? $custom_reset_password_page
			: network_site_url( 'wp-login.php?action=rp', 'login' );

		$reset_url = add_query_arg(
			[
				'key'   => $reset_key,
				'login' => rawurlencode( $user_login ),
			],
			$base_url
		);

		// Return as a clickable link with URL as the text.
		return sprintf(
			/* translators: %1$s: Reset password URL */
			'<a href="%1$s">%1$s</a>',
			esc_url( $reset_url )
		);
	}

	/**
	 * Enqueue scripts.
	 *
	 * @param array<array<string, mixed>> $scripts Array of scripts to enqueue.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	private function enqueue_scripts( $scripts ) {
		foreach ( $scripts as $script ) {
			$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
			$script_dep_data = file_exists( $script_dep_path )
				? include $script_dep_path
				: [
					'dependencies' => [],
					'version'      => SRFM_PRO_VER,
				];

			// Ensure dependencies are arrays.
			$script_dep = array_merge(
				is_array( $script_dep_data['dependencies'] ) ? $script_dep_data['dependencies'] : [],
				is_array( $script['extra_dependencies'] ) ? $script['extra_dependencies'] : []
			);

			// Enqueue script.
			wp_enqueue_script(
				SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
				SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
				$script_dep, // Dependencies.
				$script_dep_data['version'], // Version.
				true // Enqueue the script in the footer.
			);

			if ( isset( $script['maybe_localize_data'] ) ) {
				wp_localize_script(
					SRFM_PRO_SLUG . '-' . $script['unique_handle'],
					'srfm_pro_user_registration',
					[
						'loginURL'           => wp_login_url(),
						'forgotURL'          => wp_lostpassword_url(),
						'registerURL'        => wp_registration_url(),
						'ajaxURL'            => admin_url( 'admin-ajax.php' ),
						'nonce'              => wp_create_nonce( 'wp_rest' ),
						// Fully resolved REST URLs so the frontend can call these
						// routes with a plain fetch() instead of wp.apiFetch(): a
						// JS-combining optimizer can drop the wp-api-fetch dependency
						// while still shipping this file, silently breaking login
						// and password reset. login is gated by the
						// X-WP-Submit-Token header (Submit_Token::verify()), same as
						// public form submission; reset-password checks the `nonce`
						// value above as a standard wp_rest-action nonce. Neither
						// needs anything else wp.apiFetch's middleware provided.
						'login_url'          => esc_url_raw( rest_url( 'sureforms/v1/login' ) ),
						'reset_password_url' => esc_url_raw( rest_url( 'sureforms/v1/reset-password' ) ),
					]
				);
			}

			// Register script translations.
			Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
		}
	}

	/**
	 * Get all the custom meta keys from the postmeta table.
	 *
	 * @since 1.8.0
	 * @return array<string>|mixed An array of custom meta keys.
	 */
	private static function get_all_custom_meta_keys() {
		global $wpdb;

		// Attempt to get from cache first.
		$cache_key     = 'srfm_custom_meta_keys';
		$cached_result = wp_cache_get( $cache_key, 'sureforms-pro' );

		if ( false !== $cached_result ) {
			return $cached_result;
		}

		// Query to get distinct meta keys that are not private/internal (those usually start with "_").
		// PHPCS: Ignore direct database query warning, as there is no built-in alternative.
    	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$meta_keys = $wpdb->get_col(
			$wpdb->prepare(
				"
			SELECT DISTINCT meta_key
			FROM {$wpdb->usermeta}
			WHERE meta_key NOT LIKE %s
			ORDER BY meta_key
			",
				$wpdb->esc_like( '_' ) . '%'
			)
		);

		// Store the result in cache for 1 hour.
		wp_cache_set( $cache_key, $meta_keys, 'sureforms-pro', HOUR_IN_SECONDS );

		// Return the array of keys.
		return $meta_keys;
	}

	/**
	 * Maybe redirect to custom login page
	 *
	 * @param array<string,mixed> $settings User registration settings.
	 * @since 1.8.0
	 * @return void
	 */
	private function maybe_redirect_login_page( $settings ) {
		$custom_login_enabled = ! empty( $settings['srfm_enable_custom_login_page'] );
		$custom_login_page    = ! empty( $settings['srfm_custom_login_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_login_page'] ) : '';

		// Only redirect if custom login is enabled and URL is set.
		if ( ! $custom_login_enabled || empty( $custom_login_page ) ) {
			return;
		}

		// Don't redirect for specific login actions that need the default page.
		$restricted_actions = [ 'logout', 'postpass' ];
		$current_action     = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : 'login'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed for this case.

		if ( in_array( $current_action, $restricted_actions, true ) ) {
			return;
		}

		// Preserve redirect_to parameter if present.
		$redirect_to = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed for this case.

		// Build custom login URL.
		$custom_url = $custom_login_page;
		if ( ! empty( $redirect_to ) ) {
			$custom_url = add_query_arg( 'redirect_to', $redirect_to, $custom_url );
		}

		// Perform the redirect.
		wp_safe_redirect( $custom_url );
		exit;
	}

	/**
	 * Maybe redirect to custom registration page
	 *
	 * @param array<string,mixed> $settings User registration settings.
	 * @since 1.8.0
	 * @return void
	 */
	private function maybe_redirect_registration_page( $settings ) {
		$custom_registration_enabled = ! empty( $settings['srfm_enable_custom_registration_page'] );
		$custom_registration_page    = ! empty( $settings['srfm_custom_registration_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_registration_page'] ) : '';

		// Only redirect if custom registration is enabled and URL is set.
		if ( ! $custom_registration_enabled || empty( $custom_registration_page ) ) {
			return;
		}

		// Perform the redirect.
		wp_safe_redirect( $custom_registration_page );
		exit;
	}

	/**
	 * Maybe redirect to custom lost password page
	 *
	 * @param array<string,mixed> $settings User registration settings.
	 * @since 2.5.0
	 * @return void
	 */
	private function maybe_redirect_lost_password_page( $settings ) {
		$custom_lost_password_enabled = ! empty( $settings['srfm_enable_custom_lost_password_page'] );
		$custom_lost_password_page    = ! empty( $settings['srfm_custom_lost_password_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_lost_password_page'] ) : '';

		// Only redirect if custom lost password is enabled and URL is set.
		if ( ! $custom_lost_password_enabled || empty( $custom_lost_password_page ) ) {
			return;
		}

		// Perform the redirect.
		wp_safe_redirect( $custom_lost_password_page );
		exit;
	}

	/**
	 * Maybe redirect to custom reset password page
	 *
	 * @param array<string,mixed> $settings User registration settings.
	 * @since 2.5.0
	 * @return void
	 */
	private function maybe_redirect_reset_password_page( $settings ) {
		$custom_reset_password_enabled = ! empty( $settings['srfm_enable_custom_reset_password_page'] );
		$custom_reset_password_page    = ! empty( $settings['srfm_custom_reset_password_page'] ) ?
			Helper::get_string_value( $settings['srfm_custom_reset_password_page'] ) : '';

		// Only redirect if custom reset password is enabled and URL is set.
		if ( ! $custom_reset_password_enabled || empty( $custom_reset_password_page ) ) {
			return;
		}

		// Get the key and login from the URL to pass to the custom page.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed, these are passed from WordPress reset email.
		$key = isset( $_REQUEST['key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['key'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification not needed, these are passed from WordPress reset email.
		$login = isset( $_REQUEST['login'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['login'] ) ) : '';

		// Build the redirect URL with key and login parameters.
		$redirect_url = add_query_arg(
			[
				'key'   => $key,
				'login' => $login,
			],
			$custom_reset_password_page
		);

		// Perform the redirect.
		wp_safe_redirect( $redirect_url );
		exit;
	}
}
