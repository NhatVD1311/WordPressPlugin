<?php
/**
 * Survey - Init class
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Survey;

use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize Survey module.
 *
 * @since 2.8.0
 */
class Init {
	use Get_Instance;

	/**
	 * Survey Init constructor.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function __construct() {
		add_filter( 'srfm_ai_form_generator_body', [ $this, 'add_survey_form_version' ], 10, 2 );
		add_filter( 'srfm_modify_ai_post_metas', [ $this, 'create_metas_for_ai' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
	}

	/**
	 * Add survey version to AI form generator body.
	 *
	 * When the form type is 'survey', adds the version identifier so the
	 * AI middleware selects the survey template.
	 *
	 * @param array<mixed> $body   The body array for AI request.
	 * @param array<mixed> $params The request parameters.
	 * @since 2.8.0
	 * @return array<mixed> Modified body array.
	 */
	public function add_survey_form_version( $body, $params ) {
		$form_type = ! empty( $params['form_type'] ) && is_string( $params['form_type'] ) ? sanitize_text_field( $params['form_type'] ) : '';

		if ( 'survey' === $form_type ) {
			$body['version'] = 'survey';
		}

		return $body;
	}

	/**
	 * Enable survey when a form is created via AI form builder.
	 *
	 * Sets `_srfm_survey_meta` with `status: true` so the survey feature
	 * is automatically enabled on the newly created form.
	 *
	 * @param array<string,mixed> $metas        The metas to set on the new post.
	 * @param object              $form_info_obj The form info object from the AI request.
	 * @hooked srfm_modify_ai_post_metas
	 * @since 2.8.0
	 * @return array<string,mixed> Modified metas array.
	 */
	public function create_metas_for_ai( $metas, $form_info_obj ) {
		if ( ! is_object( $form_info_obj ) || ! isset( $form_info_obj->form_type ) || 'survey' !== $form_info_obj->form_type ) {
			return $metas;
		}

		$encoded = wp_json_encode(
			[
				'status'            => true,
				'show_live_results' => false,
			]
		);

		if ( $encoded ) {
			$metas['_srfm_survey_meta'] = $encoded;
		}

		return $metas;
	}

	/**
	 * Enqueue Survey admin scripts.
	 *
	 * @hooked admin_enqueue_scripts
	 * @param string|null $hook_suffix Current admin page hook suffix.
	 * @since 2.8.0
	 * @return void
	 */
	public function enqueue_admin_scripts( ?string $hook_suffix ) {
		if ( null === $hook_suffix || false === strpos( $hook_suffix, 'sureforms' ) ) {
			return;
		}

		$script = [
			'unique_file'        => 'srfmSurveyAdmin',
			'unique_handle'      => 'srfm-survey-admin',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'],
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep,
			$script_dep_data['version'],
			true
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}
}
