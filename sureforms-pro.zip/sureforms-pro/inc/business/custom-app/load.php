<?php
/**
 * Custom App main class file.
 *
 * @since 1.0.2
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Custom_App;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Post;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Load custom app feature related functionalities.
 *
 * @since 1.0.2
 */
class Load {
	use Get_Instance;

	/**
	 * Maximum number of bytes read from a remote attachment.
	 *
	 * The body is buffered in memory before being emitted, so an unbounded read lets a
	 * remote server exhaust memory_limit with a single oversized response.
	 *
	 * @since 2.12.3
	 */
	public const MAX_ATTACHMENT_BYTES = 26214400; // 25 MB.

	/**
	 * Maximum total bytes held in one "download all" archive.
	 *
	 * ZipArchive::addFromString() keeps every entry in memory until close(), so a per-file
	 * cap alone leaves N x MAX_ATTACHMENT_BYTES as the true ceiling.
	 *
	 * @since 2.12.3
	 */
	public const MAX_ARCHIVE_BYTES = 104857600; // 100 MB.

	/**
	 * Maximum number of attachments placed in one archive.
	 *
	 * @since 2.12.3
	 */
	public const MAX_ARCHIVE_FILES = 25;

	/**
	 * Initialize custom app.
	 *
	 * @since 1.0.2
	 */
	public function __construct() {
		add_action( 'wp', [ $this, 'initialize_custom_app_cookie' ] );
		$this->download_attachment(); // Download attachment file.
		add_action( 'rest_api_init', [ $this, 'init_rest_response_url' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_block_editor_scripts' ] );
		add_action( 'srfm_localize_conditional_logic_data', [ $this, 'enqueue_custom_app_scripts' ] );

		add_filter( 'srfm_suretriggers_integration_data_filter', [ $this, 'add_response_url_on_sample' ], 10, 2 );
		add_filter( 'srfm_form_submit_response', [ $this, 'add_response_url_on_form_submit' ] );

		add_filter( 'register_meta_args', [ $this, 'extend_srfm_form_confirmation_args' ], 10, 4 );
		add_filter( 'srfm_form_confirmation_params', [ $this, 'srfm_form_confirmation_params' ], 10, 2 );

		add_filter( 'srfm_frontend_validation_messages', [ $this, 'add_translatable_strings' ] );
	}

	/**
	 * Initialize custom app cookie if the current post is a form or has a form block.
	 *
	 * @return void
	 * @since 1.9.0
	 */
	public function initialize_custom_app_cookie() {
		if ( is_admin() ) {
			return;
		}

		global $post;

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		$form_id = 0;

		if ( 'sureforms_form' === $post->post_type ) {
			// Case 1: For instant form.
			$form_id = $post->ID;

			if ( Utils::is_custom_app_enabled( $form_id ) ) {
				Utils::get_user_session_id();
			}
		} else {
			// Case 2: For embedded form.
			$blocks = parse_blocks( $post->post_content );

			foreach ( $blocks as $block ) {
				if ( isset( $block['blockName'] ) && 'srfm/form' === $block['blockName'] ) {
					$form_id = isset( $block['attrs']['id'] ) ? (int) $block['attrs']['id'] : 0;

					if ( Utils::is_custom_app_enabled( $form_id ) ) {
						Utils::get_user_session_id();
						break;
					}
				}
			}
		}
	}

	/**
	 * Add the custom app related translatable strings for the frontend.
	 *
	 * @param array<string,string> $translatable_array Default translatable strings array.
	 * @since 1.1.0
	 * @return array<string,string> Extended translatable strings array.
	 */
	public function add_translatable_strings( $translatable_array ) {
		return array_merge(
			$translatable_array,
			[
				'custom_app_audio_files_ready' => __( 'Your audio files are ready!', 'sureforms-pro' ),
				'custom_app_img_files_ready'   => __( 'Your image files are ready!', 'sureforms-pro' ),
				'custom_app_files_ready'       => __( 'Your files are ready!', 'sureforms-pro' ),
				'custom_app_back_btn'          => __( 'Back', 'sureforms-pro' ),
				'custom_app_download_all_btn'  => __( 'Download All', 'sureforms-pro' ),
				'custom_app_copy_text_btn'     => __( 'Copy Text', 'sureforms-pro' ),
				'custom_app_text_copied_btn'   => __( 'Copied', 'sureforms-pro' ),
				'custom_app_error_msg'         => __( 'Something went wrong. We could not get the result at the moment. Please reload the page and try again later.', 'sureforms-pro' ),
			]
		);
	}

	/**
	 * Load and Localize the custom app form confirmation data for JS use.
	 *
	 * @param int $form_id Current form ID.
	 * @since 1.1.0
	 * @return void
	 */
	public function enqueue_custom_app_scripts( $form_id ) {
		if ( ! $form_id ) {
			return;
		}

		if ( ! Utils::is_custom_app_enabled( $form_id ) ) {
			return;
		}

		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '//package/business/';

		// Load the frontend custom app styles.
		wp_enqueue_style( SRFM_PRO_SLUG . '-custom-app', $css_uri . 'custom-app' . $file_prefix . '.css', [], SRFM_PRO_VER );

		// Load markdown library.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-markdown-it',
			SRFM_PRO_URL . 'assets/js/minified/deps/markdown-it.min.js',
			[],
			'14.1.0',
			true
		);

		// Load the frontend custom app script.
		// No 'wp-api-fetch' dependency: the script polls the REST API via a plain
		// fetch() against the absolute URL localized below, not wp.apiFetch(), so
		// it no longer depends on that second script having loaded and executed
		// correctly (see the 'endpoint' comment below).
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-custom-app-frontend', // Handle.
			SRFM_PRO_URL . 'dist/package/business/srfmCustomAppFrontend.js',
			[ 'wp-i18n' ],
			SRFM_PRO_VER,
			true // Enqueue the script in the footer.
		);

		$form_confirmation = Helper::get_array_value( get_post_meta( $form_id, '_srfm_form_confirmation', true ) );

		$confirmation_data = isset( $form_confirmation[0] ) ? Helper::get_array_value( $form_confirmation[0] ) : [];

		if ( ! isset( $confirmation_data['response_loading_text'] ) ) {
			// Sometimes default will not work due to priority order, this will help prevent that scenario.
			$confirmation_data['response_loading_text'] = esc_html__( 'We are generating your response', 'sureforms-pro' );
		}

		if ( ! isset( $confirmation_data['response_wait_time'] ) ) {
			// Sometimes default will not work due to priority order, this will help prevent that scenario.
			$confirmation_data['response_wait_time'] = 30;
		}

		wp_localize_script(
			SRFM_PRO_SLUG . '-custom-app-frontend',
			'srfm_pro_custom_app_' . $form_id,
			[
				'nonce'             => wp_create_nonce( Utils::get_user_session_id() ),
				// Fully resolved absolute URL (not a relative REST path) so the
				// frontend can poll it with a plain fetch() instead of wp.apiFetch().
				// rest_url() accounts for pretty vs. plain permalinks the same way
				// wp.apiFetch's root-URL middleware would, resolved here in PHP
				// instead of depending on that second script loading correctly.
				'endpoint'          => esc_url_raw( add_query_arg( 'session_id', Utils::get_user_session_id(), rest_url( 'sureforms-pro/v1/' . Utils::REST_ROUTE ) ) ),
				// get_custom_app_data() (the GET handler this polls) verifies a
				// standard `wp_rest`-action nonce from the X-WP-Nonce header.
				// wp.apiFetch's nonce middleware injected this header automatically
				// from a value WordPress core localizes wherever 'wp-api-fetch' is
				// enqueued; now that this script no longer declares that dependency,
				// the same nonce is localized here and sent explicitly instead.
				'wp_rest_nonce'     => wp_create_nonce( 'wp_rest' ),
				'session_id'        => Utils::get_user_session_id(),
				'form_confirmation' => $confirmation_data,
			]
		);
	}

	/**
	 * Extends the SRFM form confirmation arguments.
	 *
	 * @param array<string, mixed> $args The extended arguments.
	 * @param array<string, mixed> $defaults The default arguments.
	 * @param string               $object_type The type of object.
	 * @param string               $meta_key The meta key.
	 *
	 * @since 1.1.0
	 * @return array<string, mixed> The extended arguments.
	 */
	public function extend_srfm_form_confirmation_args( $args, $defaults, $object_type, $meta_key ) {
		if ( 'sureforms_form' !== $object_type && '_srfm_form_confirmation' !== $meta_key ) {
			return $args;
		}

		if ( empty( $defaults ) ) {
			return $args;
		}

		$args = array_merge_recursive(
			$args,
			[
				'show_in_rest' => [
					'schema' => [
						'context' => [ 'edit' ],
						'items'   => [
							'properties' => [
								'response_loading_text' => [
									'type' => 'string',
								],
								'response_wait_time'    => [
									'type' => 'number',
								],
								'hide_copy'             => [
									'type' => 'boolean',
								],
								'hide_download_all'     => [
									'type' => 'boolean',
								],
							],
						],
					],
				],
			]
		);

		$args['default'][0]['response_loading_text'] = esc_html__( 'We are generating your response', 'sureforms-pro' );
		$args['default'][0]['response_wait_time']    = 30;
		$args['default'][0]['hide_copy']             = false;
		$args['default'][0]['hide_download_all']     = false;

		return $args;
	}

	/**
	 * Extends the SRFM form confirmation arguments for sanitization.
	 *
	 * @param array<string, mixed> $sanitized The sanitized arguments.
	 * @param array<string, mixed> $item The item data.
	 *
	 * @since 1.7.2
	 * @return array<string, mixed> The sanitized values.
	 */
	public function srfm_form_confirmation_params( $sanitized, $item ) {
		if ( empty( $item ) ) {
			return $sanitized;
		}

		$sanitized_new = [
			'response_loading_text' => isset( $item['response_loading_text'] ) ? sanitize_text_field( Helper::get_string_value( $item['response_loading_text'] ) ) : esc_html( __( 'We are generating your response', 'sureforms-pro' ) ),
			'response_wait_time'    => isset( $item['response_wait_time'] ) ? intval( Helper::get_integer_value( $item['response_wait_time'] ) ) : 30,
			'hide_copy'             => isset( $item['hide_copy'] ) ? filter_var( $item['hide_copy'], FILTER_VALIDATE_BOOLEAN ) : false,
			'hide_download_all'     => isset( $item['hide_download_all'] ) ? filter_var( $item['hide_download_all'], FILTER_VALIDATE_BOOLEAN ) : false,
		];

		return array_merge( $sanitized, $sanitized_new );
	}

	/**
	 * Downloads the file attachment(s) to the user.
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function download_attachment() {
		if ( ! isset( $_GET['srfm-custom-app-download'] ) || ! isset( $_GET['nonce'] ) ) {
			return;
		}

		$form_id      = isset( $_GET['form_id'] ) ? absint( wp_unslash( $_GET['form_id'] ) ) : 0;
		$index        = isset( $_GET['attachment-index'] ) ? absint( wp_unslash( $_GET['attachment-index'] ) ) : false;
		$download_all = isset( $_GET['download-all'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['download-all'] ) );

		if ( ! $form_id || ( ! $download_all && false === $index ) ) {
			return;
		}

		if ( ! Utils::is_custom_app_enabled( $form_id ) ) {
			return;
		}

		$base_url   = remove_query_arg( [ 'attachment-index', 'download-all', 'nonce' ] ); // Downloads base url which can be used for other redirects.
		$session_id = Utils::get_user_session_id();

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), $session_id ) ) {
			wp_safe_redirect( add_query_arg( 'error', __( 'Nonce verification failed.', 'sureforms-pro' ), $base_url ) );
			exit;
		}

		$result = Helper::get_array_value( Utils::get_result_transient( Helper::get_string_value( $session_id ), $form_id ) );

		if ( empty( $result['attachments'] ) || ! is_array( $result['attachments'] ) ) {
			wp_safe_redirect( add_query_arg( 'error', __( 'No attachment files found.', 'sureforms-pro' ), $base_url ) );
			exit;
		}

		// Check if download-all is true.
		if ( $download_all ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				wp_safe_redirect( add_query_arg( 'error', __( 'Your server does not support ZipArchive library.', 'sureforms-pro' ), $base_url ) );
				exit;
			}

			// Create a temporary file for the ZIP archive.
			$temp_zip = tempnam( sys_get_temp_dir(), 'attachments' ) . '.zip';
			$zip      = new \ZipArchive();

			if ( $zip->open( $temp_zip, \ZipArchive::CREATE ) !== true ) {
				wp_safe_redirect( add_query_arg( 'error', __( 'Failed to create ZIP file.', 'sureforms-pro' ), $base_url ) );
				exit;
			}

			$success = 0;

			// ZipArchive::addFromString() holds every entry in memory until close(), so the
			// per-file cap alone leaves N x MAX_ATTACHMENT_BYTES as the real ceiling. Bound
			// the count and track a running budget across the archive.
			$budget_remaining = self::MAX_ARCHIVE_BYTES;
			$attachments      = array_slice( $result['attachments'], 0, self::MAX_ARCHIVE_FILES, true );

			foreach ( $attachments as $key => $attachment ) {
				$attachment_url = esc_url_raw( Helper::get_string_value( $attachment['link'] ) );

				// The URL originates from the public save_custom_app_data() route, so it
				// is untrusted. fetch_attachment_head() layers the ranges core misses
				// (link-local / CGNAT / IPv6 private) on top of wp_safe_remote_head()
				// and refuses to follow redirects.
				$attachment_res = $this->fetch_attachment_head( $attachment_url );

				if ( 200 !== wp_remote_retrieve_response_code( $attachment_res ) ) {
					// We will display errors at once after this foreach by calculating $success.
					continue;
				}

				$content_type = Helper::get_string_value( wp_remote_retrieve_header( $attachment_res, 'content-type' ) );
				$filename     = $this->get_attachment_filename( $attachment_url, $content_type, "-{$form_id}-{$key}-{$session_id}" );

				// Download the file content. The same validation applies to the body fetch,
				// not just the HEAD probe above, and the read is capped so an oversized
				// response cannot exhaust memory_limit while it is buffered.
				$file_body = $this->fetch_attachment_body( $attachment_url );

				// The GET's own status must be checked. wp_remote_retrieve_body() returns a
				// string for every non-WP_Error input and never false, so a `false === $body`
				// test was dead code, and the HEAD's 200 says nothing about what the GET
				// returns. A URL that HEADs 200 and GETs 403 — an expired pre-signed link, or
				// S3's <Error><Code>AccessDenied</Code> — had its ERROR BODY zipped and counted
				// as a success.
				if ( is_wp_error( $file_body ) || 200 !== (int) wp_remote_retrieve_response_code( $file_body ) ) {
					// We will display errors at once after this foreach by calculating $success.
					continue;
				}

				$file_contents = Helper::get_string_value( wp_remote_retrieve_body( $file_body ) );

				// Stop before the archive as a whole exceeds the budget.
				$file_size = strlen( $file_contents );

				if ( $file_size > $budget_remaining ) {
					continue;
				}

				// Add file to the zip.
				if ( $zip->addFromString( $filename, $file_contents ) ) {
					$budget_remaining -= $file_size;
					$success++;
				}
			}

			$zip->close();

			if ( $success > 0 ) {
				// sanitize_file_name() on the composed name: $session_id comes from a cookie
				// through sanitize_text_field(), which strips CRLF but NOT `"` or `;`, so
				// `x"; filename*=UTF-8''evil.html` would break out of the quoted value and add
				// an RFC 6266 `filename*` parameter, which takes precedence. Same class as the
				// single-file download a few lines below.
				$zip_name = sanitize_file_name( "attachments-{$form_id}-{$session_id}.zip" );

				// Set headers to download the zip.
				header( 'Content-Type: application/zip' );
				header( 'Content-Disposition: attachment; filename="' . $zip_name . '"' );
				header( 'X-Content-Type-Options: nosniff' );
				header( 'Content-Length: ' . filesize( $temp_zip ) );

				// Output the zip file.
				readfile( $temp_zip );  // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_readfile -- We are not using WP_Filesystem here as we need readfile functionality.
				unlink( $temp_zip ); // Clean up the temporary zip file.
				exit;
			}

			// Redirect with error message.
			wp_safe_redirect(
				add_query_arg(
					'error',
					sprintf(
						'%1$s %2$s',
						__( 'Failed to zip all the files.', 'sureforms-pro' ),
						sprintf(
							/* Translators: %s is the number of corrupt files. */
							_nx(
								'%s file is either corrupt or does not exist.',
								'%s files are either corrupt or do not exist.',
								count( $result['attachments'] ) - $success,
								'Number of corrupt files',
								'sureforms-pro'
							),
							// The substitution argument was missing, so this sprintf() raised
							// ArgumentCountError on PHP 8 — a WSOD instead of the redirect. Only
							// reachable when every attachment failed, which the status-code check
							// above makes considerably more likely to be hit.
							number_format_i18n( count( $result['attachments'] ) - $success )
						)
					),
					$base_url
				)
			);
			exit;
		}

		// Single file download as before.
		if ( ! isset( $result['attachments'][ $index ] ) ) {
			wp_safe_redirect( add_query_arg( 'error', __( 'Attachment file not found', 'sureforms-pro' ), $base_url ) );
			exit;
		}

		$attachment     = $result['attachments'][ $index ];
		$attachment_url = esc_url_raw( Helper::get_string_value( $attachment['link'] ) );

		// See the note in the ZIP branch above: this URL comes from the public
		// save_custom_app_data() route, so both the probe and the body fetch go through
		// the guarded helpers rather than wp_safe_remote_* directly.
		$attachment_res = $this->fetch_attachment_head( $attachment_url );

		if ( 200 !== wp_remote_retrieve_response_code( $attachment_res ) ) {
			wp_safe_redirect( add_query_arg( 'error', __( 'Selected file is not downloadable or does not exists.', 'sureforms-pro' ), $base_url ) );
			exit;
		}

		$content_type = Helper::get_string_value( wp_remote_retrieve_header( $attachment_res, 'content-type' ) );
		$filename     = $this->get_attachment_filename( $attachment_url, $content_type, "-{$form_id}-{$index}-{$session_id}" );

		// Fetch the body before emitting any headers, so a failed or blocked fetch
		// can still redirect with an error instead of sending a truncated download.
		$file_response = $this->fetch_attachment_body( $attachment_url );

		// As in the ZIP branch: the GET's own status is the discriminator, not the HEAD's.
		// Without this an error body was echoed to the browser as the file.
		if ( is_wp_error( $file_response ) || 200 !== (int) wp_remote_retrieve_response_code( $file_response ) ) {
			wp_safe_redirect( add_query_arg( 'error', __( 'Selected file is not downloadable or does not exists.', 'sureforms-pro' ), $base_url ) );
			exit;
		}

		$file_contents = Helper::get_string_value( wp_remote_retrieve_body( $file_response ) );

		// Set headers to force download. The content type is NOT echoed back from the
		// remote HEAD: that probe and the GET are separate requests, so the server can
		// advertise one type and return a different body. Serving a fixed
		// application/octet-stream plus nosniff keeps the browser from being talked into
		// rendering the response.
		header( 'Content-Type: application/octet-stream' );
		header( 'X-Content-Type-Options: nosniff' );
		header( "Content-disposition: attachment; filename=\"{$filename}\"" );
		// Without a length the browser cannot tell a truncated transfer from a complete one.
		header( 'Content-Length: ' . strlen( $file_contents ) );

		echo $file_contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw file bytes served as an attachment download; escaping would corrupt the file.
		exit;
	}

	/**
	 * Init rest api for the custom app.
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function init_rest_response_url() {
		register_rest_route(
			'sureforms-pro/v1',
			Utils::REST_ROUTE,
			[
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_custom_app_data' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			'sureforms-pro/v1',
			Utils::REST_ROUTE,
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'save_custom_app_data' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	/**
	 * Send the custom app saved data to internal requests.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 1.0.2
	 * @return mixed
	 */
	public function get_custom_app_data( $request ) {
		$nonce = sanitize_text_field( Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) ) );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return false;
		}
		return Utils::get_result_transient(
			sanitize_text_field( wp_unslash( Helper::get_string_value( $request->get_param( 'session_id' ) ) ) ),
			absint( wp_unslash( $request->get_param( 'form_id' ) ) )
		);
	}

	/**
	 * Response URL callback function to save the data sent from OttoKit Platform.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 1.0.2
	 * @return \WP_Error|array Returns WP_Error object on failure or array data on success.
	 */
	public function save_custom_app_data( $request ) {
		$token = Helper::get_string_value( $request->get_param( 'token' ) );

		if ( empty( $token ) ) {
			return new \WP_Error( 'SRFM_EMPTY_TOKEN', __( 'Token cannot be empty. You must provide a valid token.', 'sureforms-pro' ) );
		}

		// NOT a security control. User-Agent is fully attacker-controlled, so this
		// only filters obviously-unintended callers and keeps logs clean — the
		// actual gate is the session-bound nonce check below. Do not add
		// authorization logic that depends on this passing; if the OttoKit channel
		// needs authenticating, use a shared secret or request signature.
		$user_agent = Helper::get_string_value( $request->get_header( 'user_agent' ) );

		if ( 'suretriggers' !== strtolower( $user_agent ) && 'ottokit' !== strtolower( $user_agent ) ) {
			return new \WP_Error( 'SRFM_INVALID_USER_AGENT', __( 'Unexpected request source.', 'sureforms-pro' ) );
		}

		/**
		 * Parsed data from token.
		 *
		 * @var array<string,string> $parsed Parsed data from token.
		 */
		$parsed = json_decode( Helper::get_string_value( base64_decode( $token ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

		if ( empty( $parsed['nonce'] ) || empty( $parsed['session_id'] ) || empty( $parsed['form_id'] ) ) {
			return new \WP_Error( 'SRFM_INVALID_TOKEN', __( 'Provided token seems invalid. You must provide a valid token.', 'sureforms-pro' ) );
		}

		$form_id    = absint( wp_unslash( $parsed['form_id'] ) );
		$session_id = sanitize_text_field( wp_unslash( $parsed['session_id'] ) );

		if ( ! Utils::verify_nonce( $parsed['nonce'], $session_id ) ) {
			return new \WP_Error( 'SRFM_NONCE_VERIFICATION_FAILED', __( 'Nonce verification failed.', 'sureforms-pro' ) );
		}

		$st_body        = Helper::get_string_value( $request->get_param( 'body' ) ); // This "$st_body" will have the data provided by the user ( + OttoKit ) using the editor or text formatter.
		$st_body_raw    = sanitize_text_field( trim( strip_tags( $st_body ) ) ); // phpcs:ignore -- We need strip_tags here. This "$st_body_raw" will have the raw data provided by the user ( + OttoKit ) without any formatting.
		$st_attachments = Helper::get_array_value( $request->get_param( 'attachment' ) );  // Array of attachment URLs.

		if ( empty( $st_body_raw ) && empty( $st_attachments ) ) {
			return new \WP_Error( 'SRFM_EMPTY_RESPONSE_SENT', __( 'Response data body cannot be empty.', 'sureforms-pro' ) );
		}

		$filetypes   = [];
		$attachments = [];

		// Process the attachment if we have attachment URL.
		if ( ! empty( $st_attachments ) && is_array( $st_attachments ) ) {
			foreach ( $st_attachments as $st_attachment ) {
				if ( empty( $st_attachment['sf_response_file'] ) ) {
					continue;
				}

				$attachment_url = esc_url_raw( Helper::get_string_value( $st_attachment['sf_response_file'] ) );

				// This URL is supplied by the caller of this public route.
				// fetch_attachment_head() applies wp_http_validate_url() plus the ranges
				// core misses, so it cannot be used to probe the host's internal network
				// or reach cloud instance metadata.
				$attachment_res = $this->fetch_attachment_head( $attachment_url );
				$response_code  = absint( wp_remote_retrieve_response_code( $attachment_res ) );

				if ( ! is_wp_error( $attachment_res ) && 200 === $response_code ) {
					$content_type   = Helper::get_string_value( wp_remote_retrieve_header( $attachment_res, 'content-type' ) );
					$content_length = Helper::get_integer_value( wp_remote_retrieve_header( $attachment_res, 'content-length' ) );

					// The advertised size was recorded but never enforced. Refuse to store
					// a URL we would later decline to download anyway. Advisory only — the
					// header is remote-controlled — so the read is still capped at fetch
					// time by fetch_attachment_body().
					if ( $content_length > self::MAX_ATTACHMENT_BYTES ) {
						continue;
					}

					$filetype = $this->get_file_type( $content_type );

					$attachments[] = [
						'status'       => wp_remote_retrieve_response_code( $attachment_res ),
						'filetype'     => $filetype,
						'content-type' => $content_type,
						'size'         => [
							'bytes'     => $content_length,
							'formatted' => $content_length ? size_format( $content_length ) : __( 'Unknown File Size', 'sureforms-pro' ),
						],
						'filename'     => $this->get_attachment_filename( $attachment_url, $content_type ),
						'link'         => $attachment_url,
					];

					$filetypes[ $filetype ] = true;
				}
			}
		}

		// The empty-payload check above runs before the attachment filtering, so a request
		// carrying nothing but attachments that were all rejected — oversized, non-200, or
		// pointing into a denied range — would otherwise return HTTP 200 with an empty
		// attachments array. OttoKit sees success and the user sees a blank response panel
		// with no reason given.
		if ( empty( $st_body_raw ) && ! empty( $st_attachments ) && empty( $attachments ) ) {
			return new \WP_Error(
				'SRFM_NO_USABLE_ATTACHMENTS',
				__( 'None of the provided attachments could be retrieved. They may be too large, unreachable, or not allowed.', 'sureforms-pro' )
			);
		}

		$attachments_type = 'none';

		if ( count( $filetypes ) > 1 ) {
			$attachments_type = 'multi';
		} elseif ( count( $filetypes ) === 1 ) {
			$attachments_type = array_keys( $filetypes )[0];
		}

		$data = [
			'body'             => wp_kses_post( $st_body ), // If any markdown is present, it will be parsed by markdown-it JS library.
			'body_raw'         => $st_body_raw,
			'attachments'      => $attachments,
			'attachments_type' => $attachments_type,
		];

		// Temporary saved data for the user.
		Utils::set_result_transient( $session_id, $form_id, $data );

		// Return the formatted data back to the OttoKit platform.
		return $data;
	}

	/**
	 * Hook response URL on the sample data.
	 *
	 * @param array<string,array<string,mixed>> $body Sample data args.
	 * @param int                               $form_id Form id.
	 * @since 1.0.2
	 * @return array Modified sample data args.
	 */
	public function add_response_url_on_sample( $body, $form_id ) {
		if ( ! isset( $body['sample_response'] ) ) {
			// Bail early if proper structure is not provided.
			return $body;
		}

		$form_id = absint( $form_id );

		$session_id = Utils::get_user_session_id();

		Utils::delete_result_transient( $session_id, $form_id );

		$response_url = Utils::get_response_url( $session_id, $form_id );

		if ( ! $response_url ) {
			// Bail if we don't have response url created.
			return $body;
		}

		$body['sample_response']['response_url'] = Utils::get_response_url( $session_id, $form_id );

		return $body;
	}

	/**
	 * Hook response url on form submit.
	 *
	 * @param array<string,array<string,mixed>> $args Form submitted data args.
	 * @since 1.0.2
	 * @return array Modified form submitted data args.
	 */
	public function add_response_url_on_form_submit( $args ) {
		if ( empty( $args['form_id'] ) ) {
			return $args;
		}

		$form_id = absint( $args['form_id'] );

		if ( ! Utils::is_custom_app_enabled( $form_id ) ) {
			return $args;
		}

		$session_id = Utils::get_user_session_id();

		Utils::delete_result_transient( $session_id, $form_id );

		$args['response_url'] = Utils::get_response_url( $session_id, $form_id );

		return $args;
	}

	/**
	 * Enqueue Admin Scripts.
	 *
	 * @return void
	 * @since 1.0.2
	 */
	public function enqueue_block_editor_scripts() {

		$scripts = [
			[
				'unique_file'        => 'srfmCustomApp',
				'unique_handle'      => 'custom-app',
				'extra_dependencies' => [],
			],
		];

		foreach ( $scripts as $script ) {

			$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
			$script_dep_data = file_exists( $script_dep_path )
				? include $script_dep_path
				: [
					'dependencies' => [],
					'version'      => SRFM_PRO_VER,
				];
			$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

			// Scripts.
			wp_enqueue_script(
				SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
				SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
				$script_dep, // Dependencies, defined above.
				$script_dep_data['version'], // SRFM_VER.
				true // Enqueue the script in the footer.
			);

			// Register script translations.
			Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
		}
	}

	/**
	 * Returns files content type prefix.
	 *
	 * @param string $content_type Response header file content type.
	 * @since 1.1.0
	 * @return string Returns file type prefix.
	 */
	protected function get_file_type( $content_type ) {
		if ( ! $content_type ) {
			return '';
		}

		return Helper::get_string_value( strstr( $content_type, '/', true ) );
	}

	/**
	 * Returns the attachment filename according to the provided content type.
	 *
	 * @param string $attachment_url Response attachment file URL.
	 * @param string $content_type Response header file content type.
	 * @param string $suffix Optional. Any suffix you may want to add to the filename.
	 * @since 1.0.2
	 * @return string Returns filename.
	 */
	protected function get_attachment_filename( $attachment_url, $content_type, $suffix = '' ) {
		$pathinfo  = pathinfo( Helper::get_string_value( wp_parse_url( $attachment_url, PHP_URL_PATH ) ) );
		$filename  = ! empty( $pathinfo['filename'] ) ? $pathinfo['filename'] : '';
		$extension = ! empty( $pathinfo['extension'] ) ? $pathinfo['extension'] : '';

		if ( ! $extension ) {
			$extension = ltrim( Helper::get_string_value( strrchr( $content_type, '/' ) ), '/' );
		}

		$prefix = $this->get_file_type( $content_type );

		if ( 'application' === $prefix ) {
			$prefix = 'file';
		}

		// sanitize_file_name() on the COMPOSED name, not just the basename. $extension is
		// attacker-influenced — from pathinfo() on the supplied URL, or from
		// strrchr( $content_type, '/' ) on the remote server's content type — so a value
		// like `x"; filename*=UTF-8''evil.html` would otherwise break out of the quoted
		// value in the Content-Disposition header and add arbitrary parameters (and
		// `filename*` wins over `filename` per RFC 6266). The same string is passed to
		// ZipArchive::addFromString().
		return sanitize_file_name( $prefix . '-' . sanitize_title( $filename ) . $suffix . '.' . $extension );
	}

	/**
	 * Reject an untrusted fetch URL that resolves to any address we will not talk to.
	 *
	 * Core's wp_http_validate_url() denies 127/8, 10/8, 0/8, 172.16/12 and 192.168/16
	 * (wp-includes/http.php) but NOT 169.254.0.0/16 — so cloud instance metadata
	 * (169.254.169.254, and 169.254.170.2 for ECS task credentials, a plain GET with no
	 * special header) stays reachable through wp_safe_remote_*. Because the download path
	 * returns the body to the requester, that is a read SSRF, not a blind one.
	 *
	 * This check is deliberately SELF-CONTAINED rather than additive. It re-denies the
	 * ranges core already covers, because core's private-range block sits behind the
	 * `http_request_host_is_external` filter, `reject_unsafe_urls` behind
	 * `http_request_args`, and core skips the private-IP block entirely when the host
	 * matches the site's own `home` host — all of which any co-installed plugin, host
	 * mu-plugin or containerised setup can change. A guard written because core's coverage
	 * was insufficient must not then lean on core for the rest.
	 *
	 * EVERY resolved address is checked, in both families, and a single denied address
	 * rejects the URL:
	 *
	 * - gethostbyname() returns A records only, so a dual-stack host could be validated on
	 *   its IPv4 address while the transport connected over IPv6 (RFC 6724 prefers it) —
	 *   `A = <public>` plus `AAAA = fd00:ec2::254` reached AWS's IPv6 metadata endpoint
	 *   through both layers.
	 * - gethostbyname() also returns only the FIRST address of an RRset, so a host
	 *   publishing `A = <public>` and `A = 169.254.169.254` simply hands different records
	 *   to different resolutions. There are four per attachment (this guard and the
	 *   transport, at save time and again at download time), so that needs no race and no
	 *   low TTL — just a retry.
	 *
	 * Residual: this resolves, then the transport resolves again, so a genuine
	 * DNS-rebinding window remains. It is narrowed to a rebind between those two
	 * resolutions rather than a round-robin retry. Closing it fully needs the address
	 * pinned via CURLOPT_RESOLVE on `http_api_curl`, which is cURL-transport-specific and
	 * tracked separately.
	 *
	 * @param string $url The untrusted URL about to be fetched.
	 * @since 2.12.3
	 * @return bool True when every resolved address is safe to fetch.
	 */
	protected function is_fetchable_url( $url ) {
		$host = Helper::get_string_value( wp_parse_url( $url, PHP_URL_HOST ) );

		if ( '' === $host ) {
			return false;
		}

		// Bracketed IPv6 literal, e.g. http://[::1]/. Core rejects these before the
		// transport sees them, but this guard does not depend on that.
		$host = trim( $host, '[]' );
		$ips  = $this->resolve_host_addresses( $host );

		if ( empty( $ips ) ) {
			// Nothing resolvable means nothing to fetch. Also covers the AAAA-only host,
			// where gethostbyname() hands back the hostname unchanged.
			return false;
		}

		foreach ( $ips as $ip ) {
			if ( $this->is_denied_ip( $ip ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resolve a host to every address it publishes, in both families.
	 *
	 * @param string $host Hostname or IP literal.
	 * @since 2.12.3
	 * @return array<int,string> Validated addresses; empty when nothing resolves.
	 */
	protected function resolve_host_addresses( $host ) {
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return [ $host ];
		}

		$ips = gethostbynamel( $host );
		$ips = is_array( $ips ) ? $ips : [];

		// gethostbynamel() is A-only, so AAAA has to be asked for separately.
		if ( function_exists( 'dns_get_record' ) ) {
			$records = dns_get_record( $host, DNS_AAAA );

			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( ! empty( $record['ipv6'] ) && is_string( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}

		// Drop anything that is not a real address — notably gethostbyname()-style
		// pass-through of the hostname itself.
		return array_values(
			array_filter(
				$ips,
				static function ( $ip ) {
					return is_string( $ip ) && false !== filter_var( $ip, FILTER_VALIDATE_IP );
				}
			)
		);
	}

	/**
	 * Whether an address falls in a range this plugin refuses to fetch from.
	 *
	 * Binary prefix comparison on inet_pton() output rather than string matching: a regex
	 * over the textual form misses the alternate spellings of the same address (expanded
	 * `0:0:0:0:0:0:0:1`, `::`, IPv4-mapped `::ffff:a.b.c.d`, NAT64 `64:ff9b::`, 6to4
	 * `2002:`), and decimal or octal IPv4 forms like 2130706433 and 0177.0.0.1 resolve to
	 * 127.0.0.1 anyway — so normalising to bytes first is what makes the comparison honest.
	 *
	 * @param string $ip Address to test.
	 * @since 2.12.3
	 * @return bool True when the address must not be fetched.
	 */
	protected function is_denied_ip( $ip ) {
		$packed = inet_pton( $ip );

		if ( false === $packed ) {
			return true;
		}

		// IPv4-mapped (::ffff:0:0/96), NAT64 (64:ff9b::/96) and 6to4 (2002::/16) all carry
		// an IPv4 address inside an IPv6 one. Test the embedded address on its own terms
		// instead of trying to spell every wrapper.
		if ( 16 === strlen( $packed ) ) {
			$embedded = $this->extract_embedded_ipv4( $packed );

			if ( null !== $embedded && $this->is_denied_ip( $embedded ) ) {
				return true;
			}
		}

		$denied = 4 === strlen( $packed )
			? [
				'0.0.0.0/8',        // "this host on this network".
				'10.0.0.0/8',       // RFC 1918.
				'100.64.0.0/10',    // Carrier-grade NAT.
				'127.0.0.0/8',      // Loopback.
				'169.254.0.0/16',   // Link-local — cloud instance metadata.
				'172.16.0.0/12',    // RFC 1918.
				'192.168.0.0/16',   // RFC 1918.
				'224.0.0.0/4',      // Multicast.
				'240.0.0.0/4',      // Reserved.
			]
			: [
				'::/128',           // Unspecified.
				'::1/128',          // Loopback.
				'fc00::/7',         // Unique-local.
				'fe80::/10',        // Link-local.
				'fec0::/10',        // Deprecated site-local.
				'ff00::/8',         // Multicast.
			];

		foreach ( $denied as $cidr ) {
			if ( $this->ip_in_cidr( $packed, $cidr ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Pull the IPv4 address out of an IPv4-mapped, NAT64 or 6to4 IPv6 address.
	 *
	 * @param string $packed 16-byte packed IPv6 address.
	 * @since 2.12.3
	 * @return string|null Dotted-quad IPv4, or null when none is embedded.
	 */
	protected function extract_embedded_ipv4( $packed ) {
		$prefixes = [
			// IPv4-mapped ::ffff:0:0/96 and NAT64 64:ff9b::/96 — last four bytes.
			"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff" => 12,
			"\x00\x64\xff\x9b\x00\x00\x00\x00\x00\x00\x00\x00" => 12,

			/*
			 * Deprecated IPv4-compatible ::a.b.c.d (RFC 4291 2.5.5.1). Same smuggling
			 * shape as the two above and it evaded every range: ::169.254.169.254 is not
			 * ::/128, not ::1/128, and its first byte is 0x00 so it misses fc00::/7,
			 * fe80::/10, fec0::/10 and ff00::/8 alike.
			 *
			 * `::` and `::1` also match this prefix and unwrap to 0.0.0.0 and 0.0.0.1,
			 * which 0.0.0.0/8 already denies — so this only adds denials and cannot flip
			 * an existing verdict. Kept last so the two specific prefixes win.
			 */
			"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" => 12,
		];

		foreach ( $prefixes as $prefix => $offset ) {
			if ( 0 === strncmp( $packed, $prefix, strlen( $prefix ) ) ) {
				$v4 = inet_ntop( substr( $packed, $offset, 4 ) );

				return is_string( $v4 ) ? $v4 : null;
			}
		}

		// 6to4 2002::/16 — the IPv4 address is bytes 2-5.
		if ( "\x20\x02" === substr( $packed, 0, 2 ) ) {
			$v4 = inet_ntop( substr( $packed, 2, 4 ) );

			return is_string( $v4 ) ? $v4 : null;
		}

		return null;
	}

	/**
	 * Whether a packed address falls inside a CIDR block.
	 *
	 * @param string $packed Packed address from inet_pton().
	 * @param string $cidr   CIDR in the same family, e.g. "169.254.0.0/16".
	 * @since 2.12.3
	 * @return bool
	 */
	protected function ip_in_cidr( $packed, $cidr ) {
		[ $subnet, $bits ] = array_pad( explode( '/', $cidr, 2 ), 2, '0' );

		$subnet_packed = inet_pton( $subnet );
		$bits          = (int) $bits;

		if ( false === $subnet_packed || strlen( $subnet_packed ) !== strlen( $packed ) ) {
			return false;
		}

		$whole_bytes = intdiv( $bits, 8 );
		$extra_bits  = $bits % 8;

		if ( $whole_bytes > 0 && 0 !== strncmp( $packed, $subnet_packed, $whole_bytes ) ) {
			return false;
		}

		if ( 0 === $extra_bits ) {
			return true;
		}

		// Keep the high $extra_bits of the final byte, e.g. /10 => 0b11000000.
		$mask = 0xFF << 8 - $extra_bits & 0xFF;

		return ( ord( $packed[ $whole_bytes ] ) & $mask ) === ( ord( $subnet_packed[ $whole_bytes ] ) & $mask );
	}

	/**
	 * Probe an untrusted attachment URL with a HEAD request.
	 *
	 * Follows at most ONE redirect, revalidating the target through is_fetchable_url()
	 * first. Blanket `redirection => 0` was wrong: WP_Http returns the 30x rather than an
	 * error, so the `200 !==` gates rejected it and the attachment became permanently
	 * undownloadable behind a generic message. S3 pre-signed endpoints, Google Drive
	 * `uc?export=download`, Dropbox `dl=1` and most CDN download URLs answer with a
	 * redirect, so refusing them outright breaks real attachments. Following one hop with
	 * the target revalidated keeps the guard intact without that regression — core only
	 * revalidates redirect targets behind `http_request_args`, and with the same
	 * link-local gap, so the revalidation has to happen here.
	 *
	 * @param string $url The untrusted attachment URL.
	 * @since 2.12.3
	 * @return array<mixed>|\WP_Error Response array, or WP_Error when blocked or failed.
	 */
	protected function fetch_attachment_head( $url ) {
		if ( ! $this->is_fetchable_url( $url ) ) {
			return new \WP_Error( 'srfm_blocked_fetch_url', __( 'The attachment URL is not allowed.', 'sureforms-pro' ) );
		}

		$response = wp_safe_remote_head(
			$url,
			[
				'timeout'     => 30,
				'redirection' => 0,
			]
		);

		return $this->follow_one_safe_redirect( $response, 'head' );
	}

	/**
	 * Fetch an untrusted attachment body, capped in size.
	 *
	 * The timeout is raised from WP_Http's 5s default: the code this replaced streamed
	 * under default_socket_timeout (60s), and a 25 MB body inside 5s needs sustained
	 * >40 Mbit/s server-to-server, so the cap and the default timeout contradicted each
	 * other and produced a generic download failure on ordinary files.
	 *
	 * @param string $url The untrusted attachment URL.
	 * @since 2.12.3
	 * @return array<mixed>|\WP_Error Response array, or WP_Error when blocked or failed.
	 */
	protected function fetch_attachment_body( $url ) {
		if ( ! $this->is_fetchable_url( $url ) ) {
			return new \WP_Error( 'srfm_blocked_fetch_url', __( 'The attachment URL is not allowed.', 'sureforms-pro' ) );
		}

		$response = $this->follow_one_safe_redirect(
			wp_safe_remote_get(
				$url,
				[
					'timeout'             => 30,
					'redirection'         => 0,
					'limit_response_size' => self::MAX_ATTACHMENT_BYTES,
				]
			),
			'get'
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// limit_response_size TRUNCATES and keeps going — Requests returns no error — so an
		// oversized body would be served as exactly MAX_ATTACHMENT_BYTES corrupt bytes under
		// a 200, and counted as a success in the ZIP branch. Treat hitting the cap as a
		// failure rather than silently shipping a truncated file.
		if ( strlen( Helper::get_string_value( wp_remote_retrieve_body( $response ) ) ) >= self::MAX_ATTACHMENT_BYTES ) {
			return new \WP_Error( 'srfm_attachment_too_large', __( 'The attachment is too large to download.', 'sureforms-pro' ) );
		}

		return $response;
	}

	/**
	 * Follow at most one redirect, revalidating the target first.
	 *
	 * @param array<mixed>|\WP_Error $response Response from the initial request.
	 * @param string                 $method   'head' or 'get'.
	 * @since 2.12.3
	 * @return array<mixed>|\WP_Error
	 */
	protected function follow_one_safe_redirect( $response, $method ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( ! in_array( (int) wp_remote_retrieve_response_code( $response ), [ 301, 302, 303, 307, 308 ], true ) ) {
			return $response;
		}

		$location = Helper::get_string_value( wp_remote_retrieve_header( $response, 'location' ) );

		if ( '' === $location || ! $this->is_fetchable_url( $location ) ) {
			return new \WP_Error( 'srfm_blocked_fetch_url', __( 'The attachment URL is not allowed.', 'sureforms-pro' ) );
		}

		if ( 'head' === $method ) {
			return wp_safe_remote_head(
				$location,
				[
					'timeout'     => 30,
					'redirection' => 0,
				]
			);
		}

		return wp_safe_remote_get(
			$location,
			[
				'timeout'             => 30,
				'redirection'         => 0,
				'limit_response_size' => self::MAX_ATTACHMENT_BYTES,
			]
		);
	}
}
