<?php
/**
 * Quiz - Editor
 *
 * @since 2.6.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Quiz;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Quiz - Editor
 *
 * Handles editor side of things for the Quiz module.
 * Like meta registration, loading editor script.
 *
 * @since  2.6.0
 * @package sureforms-pro
 */
class Editor {
	use Get_Instance;

	/**
	 * Quiz Editor constructor.
	 *
	 * @since 2.6.0
	 */
	public function __construct() {
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_quiz_meta' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_scripts' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
		add_filter( 'srfm_modify_ai_post_metas', [ $this, 'create_metas_for_ai' ], 10, 2 );
		add_filter( 'srfm_ai_form_generator_body', [ $this, 'add_quiz_form_version' ], 10, 2 );
		add_action( 'rest_after_insert_sureforms_form', [ $this, 'cleanup_orphaned_quiz_questions' ] );
	}

	/**
	 * Register post meta for Quiz.
	 * This function registers a custom meta key  `_srfm_quiz_meta` for storing raw post meta data.
	 * The meta key will store data as a JSON string.
	 *
	 * @hooked srfm_register_additional_post_meta
	 * @since 2.6.0
	 * @return void
	 */
	public function register_quiz_meta() {
		register_post_meta(
			'sureforms_form',
			'_srfm_quiz_meta',
			[
				'type'              => 'string',  // Will store as JSON string.
				'single'            => true,    // Store as single value.
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				// Custom callback to sanitize the data.
				'sanitize_callback' => [ Utils::class, 'quiz_meta_sanitizer' ],
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
			]
		);
	}

	/**
	 * Enqueue Quiz block editor script.
	 *
	 * @hooked enqueue_block_editor_assets
	 * @since 2.6.0
	 * @return void
	 */
	public function enqueue_editor_scripts() {
		$script = [
			'unique_file'        => 'srfmQuizEditor',
			'unique_handle'      => 'srfm-quiz-editor',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		// Scripts.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep, // Dependencies, defined above.
			$script_dep_data['version'], // SRFM_VER.
			true // Enqueue the script in the footer.
		);

		// Register script translations.
		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Enqueue Quiz admin scripts.
	 *
	 * @hooked admin_enqueue_scripts
	 * @since 2.6.0
	 * @return void
	 */
	public function enqueue_admin_scripts() {
		$script = [
			'unique_file'        => 'srfmQuizAdmin',
			'unique_handle'      => 'srfm-quiz-admin',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'],
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep,
			$script_dep_data['version'],
			true
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Add quiz version to AI form generator body.
	 *
	 * When the form type is 'quiz', adds the version identifier so the
	 * AI middleware selects the quiz template.
	 *
	 * @param array<mixed> $body   The body array for AI request.
	 * @param array<mixed> $params The request parameters.
	 * @since 2.6.0
	 * @return array<mixed> Modified body array.
	 */
	public function add_quiz_form_version( $body, $params ) {
		$form_type = ! empty( $params['form_type'] ) && is_string( $params['form_type'] ) ? sanitize_text_field( $params['form_type'] ) : '';

		if ( 'quiz' === $form_type ) {
			$body['version'] = 'quiz';
		}

		return $body;
	}

	/**
	 * Create metas for AI when form type is Quiz.
	 *
	 * Parses the form content to extract block IDs and correct answers from field options,
	 * then builds the _srfm_quiz_meta post meta.
	 *
	 * @param array<string,mixed> $metas The metas.
	 * @param object              $form_info_obj The form info object.
	 *
	 * @hooked srfm_modify_ai_post_metas
	 * @since 2.6.0
	 * @return array<string,mixed>
	 */
	public function create_metas_for_ai( $metas, $form_info_obj ) {
		if ( ! is_object( $form_info_obj ) || ! isset( $form_info_obj->form_type ) || 'quiz' !== $form_info_obj->form_type ) {
			return $metas;
		}

		// Get quiz settings from template_metas (from the AI response's _srfm_quiz_meta).
		$quiz_settings = isset( $form_info_obj->template_metas, $form_info_obj->template_metas->_srfm_quiz_meta )
			? (array) $form_info_obj->template_metas->_srfm_quiz_meta
			: [];

		// Parse form content to extract block IDs and correct answers from options.
		$questions = self::extract_quiz_questions_from_content( $form_info_obj->form_data ?? '' );

		// Build the full quiz meta structure.
		$quiz_meta = [
			'status'               => true,
			'scoreType'            => sanitize_text_field( $quiz_settings['scoreType'] ?? 'correct_incorrect' ),
			'correctAnswerScore'   => absint( $quiz_settings['correctAnswerScore'] ?? 5 ),
			'inCorrectAnswerScore' => intval( $quiz_settings['inCorrectAnswerScore'] ?? 0 ),
			'defaultScore'         => absint( $quiz_settings['defaultScore'] ?? 5 ),
			'gradingSystem'        => sanitize_text_field( $quiz_settings['gradingSystem'] ?? 'default' ),
			'resultOutput'         => sanitize_text_field( $quiz_settings['resultOutput'] ?? 'full_result' ),
			'randomizeQuestions'   => (bool) ( $quiz_settings['randomizeQuestions'] ?? false ),
			'randomizeOptions'     => (bool) ( $quiz_settings['randomizeOptions'] ?? false ),
			'passPercent'          => min( 100, max( 0, absint( $quiz_settings['passPercent'] ?? 50 ) ) ),
			'questions'            => $questions,
			'letterGrades'         => Utils::get_default_letter_grades(),
		];

		// Encode without unicode escapes: wp_insert_post() unslashes meta_input,
		// which would strip the backslash from \uXXXX sequences and corrupt
		// accented answer text, breaking quiz answer matching on submission.
		$metas['_srfm_quiz_meta'] = wp_json_encode( $quiz_meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		return $metas;
	}

	/**
	 * Remove orphaned quiz questions after a form is saved via REST API.
	 *
	 * When a quiz-enabled block is deleted from the editor, its question entry
	 * remains in `_srfm_quiz_meta.questions[]`. This method cleans up those
	 * orphaned entries by comparing saved questions against blocks in post_content.
	 *
	 * @hooked rest_after_insert_sureforms_form
	 * @param \WP_Post $post The post object that was just saved.
	 * @since 2.6.0
	 * @return void
	 */
	public function cleanup_orphaned_quiz_questions( $post ) {
		$raw_meta = get_post_meta( $post->ID, '_srfm_quiz_meta', true );

		if ( empty( $raw_meta ) || ! is_string( $raw_meta ) ) {
			return;
		}

		$quiz_meta = json_decode( $raw_meta, true );

		if ( ! is_array( $quiz_meta ) || empty( $quiz_meta['status'] ) || empty( $quiz_meta['questions'] ) || ! is_array( $quiz_meta['questions'] ) ) {
			return;
		}

		$original_count = count( $quiz_meta['questions'] );

		// Extract block IDs from all quiz-compatible blocks in the current post content.
		$active_block_ids = self::get_quiz_block_ids_from_content( $post->post_content );

		// Keep only questions whose blockId still exists in the content.
		$quiz_meta['questions'] = array_values(
			array_filter(
				$quiz_meta['questions'],
				static function ( $question ) use ( $active_block_ids ) {
					return ! empty( $question['blockId'] ) && in_array( $question['blockId'], $active_block_ids, true );
				}
			)
		);

		// Only update if something was actually removed.
		if ( count( $quiz_meta['questions'] ) < $original_count ) {
			$encoded = wp_json_encode( $quiz_meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

			if ( $encoded ) {
				update_post_meta( $post->ID, '_srfm_quiz_meta', $encoded );
			}
		}
	}

	/**
	 * Extract block IDs from quiz-compatible blocks in post content.
	 *
	 * Recursively parses blocks and collects `block_id` attributes from
	 * `srfm/dropdown`, `srfm/multi-choice`, and `srfm/checkbox` blocks.
	 *
	 * @param string $content The post content to parse.
	 * @since 2.6.0
	 * @return array<string> List of block IDs found in the content.
	 */
	private static function get_quiz_block_ids_from_content( $content ) {
		if ( empty( $content ) ) {
			return [];
		}

		$quiz_block_names = [ 'srfm/dropdown', 'srfm/multi-choice', 'srfm/checkbox' ];
		$blocks           = parse_blocks( $content );
		$block_ids        = [];

		self::collect_quiz_block_ids( $blocks, $quiz_block_names, $block_ids );

		return $block_ids;
	}

	/**
	 * Recursively collect block IDs from quiz-compatible blocks.
	 *
	 * @param array<array<string,mixed>> $blocks           The parsed blocks array.
	 * @param array<string>              $quiz_block_names The quiz-compatible block names.
	 * @param array<string>              $block_ids        Collected block IDs (passed by reference).
	 * @since 2.6.0
	 * @return void
	 */
	private static function collect_quiz_block_ids( $blocks, $quiz_block_names, &$block_ids ) {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];

			if ( in_array( $block['blockName'] ?? '', $quiz_block_names, true ) && ! empty( $attrs['block_id'] ) ) {
				$block_ids[] = $attrs['block_id'];
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_quiz_block_ids( $block['innerBlocks'], $quiz_block_names, $block_ids );
			}
		}
	}

	/**
	 * Extract quiz questions from form content (block HTML).
	 *
	 * Parses the post content to find quiz-compatible blocks (multi-choice, dropdown, checkbox),
	 * extracts their block_id and options with isCorrect data, and builds the questions array.
	 *
	 * @param string $content The form post content containing block HTML.
	 * @since 2.6.0
	 * @return array<array<string,mixed>> The questions array for quiz meta.
	 */
	private static function extract_quiz_questions_from_content( $content ) {
		if ( empty( $content ) ) {
			return [];
		}

		$questions = [];

		// Match quiz-compatible blocks: multi-choice, dropdown, checkbox.
		preg_match_all( '/<!-- wp:srfm\/(?:multi-choice|dropdown|checkbox) ({.*?}) \/-->/', $content, $matches );

		if ( empty( $matches[1] ) ) {
			return [];
		}

		foreach ( $matches[1] as $json ) {
			$block_attrs = json_decode( $json, true );

			if ( ! is_array( $block_attrs ) || empty( $block_attrs['block_id'] ) ) {
				continue;
			}

			$options = $block_attrs['options'] ?? [];

			if ( empty( $options ) || ! is_array( $options ) ) {
				continue;
			}

			$correct_answers = [];

			foreach ( $options as $index => $option ) {
				if ( ! is_array( $option ) ) {
					continue;
				}

				$correct_answers[] = [
					'answer'          => sanitize_text_field( $option['optionTitle'] ?? $option['label'] ?? '' ),
					'index'           => $index,
					'individualScore' => intval( $option['individualScore'] ?? 0 ),
					'isCorrect'       => (bool) ( $option['isCorrect'] ?? false ),
				];
			}

			if ( ! empty( $correct_answers ) ) {
				$questions[] = [
					'status'         => true,
					'blockId'        => sanitize_text_field( $block_attrs['block_id'] ),
					'correctAnswers' => $correct_answers,
				];
			}
		}

		return $questions;
	}

}
