<?php
/**
 * Quiz Module Utils
 *
 * This class handles all the utility functions related to the Quiz module in the SureForms Business plugin.
 *
 * @since 2.6.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Quiz;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Quiz Module Utils
 *
 * @since 2.6.0
 */
class Utils {
	/**
	 * Sanitizes the quiz meta data.
	 *
	 * This function takes a JSON string of quiz meta data, decodes it, validates structure,
	 * sanitizes each field appropriately, and returns a JSON-encoded string of the sanitized data.
	 *
	 * @since 2.6.0
	 *
	 * @param string $data The JSON string containing quiz meta data.
	 * @return string Sanitized JSON string of quiz meta data.
	 */
	public static function quiz_meta_sanitizer( $data ) {
		if ( empty( $data ) || ! is_string( $data ) ) {
			return '';
		}

		$data = json_decode( $data, true );

		if ( ! is_array( $data ) || json_last_error() !== JSON_ERROR_NONE ) {
			return '';
		}

		// Allowed values for validation.
		$allowed_score_types     = [ 'correct_incorrect', 'advanced' ];
		$allowed_grading_systems = [ 'default', 'pass_fail', 'letter' ];
		$allowed_result_outputs  = [ 'default_confirmation', 'show_score', 'full_result' ];

		$sanitized = [
			'status'               => (bool) ( $data['status'] ?? false ),
			'scoreType'            => in_array( $data['scoreType'] ?? '', $allowed_score_types, true )
				? sanitize_text_field( $data['scoreType'] )
				: 'correct_incorrect',
			'correctAnswerScore'   => absint( $data['correctAnswerScore'] ?? 5 ),
			// Keep signed int so incorrect answer penalties can be negative.
			'inCorrectAnswerScore' => intval( $data['inCorrectAnswerScore'] ?? 0 ),
			'defaultScore'         => absint( $data['defaultScore'] ?? 5 ),
			'gradingSystem'        => in_array( $data['gradingSystem'] ?? '', $allowed_grading_systems, true )
				? sanitize_text_field( $data['gradingSystem'] )
				: 'default',
			'resultOutput'         => in_array( $data['resultOutput'] ?? '', $allowed_result_outputs, true )
				? sanitize_text_field( $data['resultOutput'] )
				: 'default_confirmation',
			'randomizeQuestions'   => (bool) ( $data['randomizeQuestions'] ?? false ),
			'randomizeOptions'     => (bool) ( $data['randomizeOptions'] ?? false ),
			'moderateQuestion'     => (bool) ( $data['moderateQuestion'] ?? false ),
			'customizeOptions'     => (bool) ( $data['customizeOptions'] ?? false ),
			'passPercent'          => min( 100, max( 0, absint( $data['passPercent'] ?? 50 ) ) ),
			'questions'            => self::sanitize_quiz_questions( $data['questions'] ?? [], $data['scoreType'] ?? 'correct_incorrect' ),
			'letterGrades'         => self::sanitize_letter_grades( $data['letterGrades'] ?? $data['letterGrading'] ?? [] ),
		];

		$return = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return $return ? $return : '';
	}

	/**
	 * Returns default letter grades configuration.
	 *
	 * @since 2.6.0
	 *
	 * @return array Default letter grades array.
	 */
	public static function get_default_letter_grades() {
		return [
			[
				'grade'      => 'A',
				'percentage' => 100,
			],
			[
				'grade'      => 'B',
				'percentage' => 90,
			],
			[
				'grade'      => 'C',
				'percentage' => 80,
			],
			[
				'grade'      => 'D',
				'percentage' => 70,
			],
			[
				'grade'      => 'E',
				'percentage' => 60,
			],
		];
	}

	/**
	 * Sanitizes quiz questions array.
	 *
	 * @since 2.6.0
	 *
	 * @param array  $questions   The questions array from quiz meta.
	 * @param string $score_type  Quiz score type.
	 * @return array Sanitized questions array.
	 */
	private static function sanitize_quiz_questions( $questions, $score_type = 'correct_incorrect' ) {
		if ( ! is_array( $questions ) ) {
			return [];
		}

		$sanitized  = [];
		$score_type = is_string( $score_type ) ? $score_type : 'correct_incorrect';

		foreach ( $questions as $question ) {
			if ( ! is_array( $question ) ) {
				continue;
			}

			$correct_answers = self::sanitize_correct_answers( $question['correctAnswers'] ?? [] );
			$status          = (bool) ( $question['status'] ?? true );

			// In correct/incorrect mode, disable questions with no selected correct answer.
			if ( 'correct_incorrect' === $score_type && ! self::has_selected_correct_answer( $correct_answers ) ) {
				$status = false;
			}

			$sanitized[] = [
				'status'         => $status,
				'blockId'        => sanitize_text_field( $question['blockId'] ?? '' ),
				'correctAnswers' => $correct_answers,
				'description'    => sanitize_textarea_field( $question['description'] ?? '' ),
			];
		}

		return $sanitized;
	}

	/**
	 * Check whether any answer is selected as correct.
	 *
	 * @since 2.6.0
	 *
	 * @param array $answers Sanitized correct answers.
	 * @return bool True when at least one answer is marked correct.
	 */
	private static function has_selected_correct_answer( $answers ) {
		if ( ! is_array( $answers ) ) {
			return false;
		}

		foreach ( $answers as $answer ) {
			if ( is_array( $answer ) && ! empty( $answer['isCorrect'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Sanitizes correct answers array for a question.
	 *
	 * @since 2.6.0
	 *
	 * @param array $answers The correctAnswers array from a question.
	 * @return array Sanitized correctAnswers array.
	 */
	private static function sanitize_correct_answers( $answers ) {
		if ( ! is_array( $answers ) ) {
			return [];
		}

		$sanitized = [];

		foreach ( $answers as $answer ) {
			if ( ! is_array( $answer ) ) {
				continue;
			}

			$sanitized[] = [
				'answer'          => sanitize_text_field( $answer['answer'] ?? '' ),
				'index'           => absint( $answer['index'] ?? 0 ),
				'individualScore' => intval( $answer['individualScore'] ?? 0 ),
				'isCorrect'       => (bool) ( $answer['isCorrect'] ?? false ),
			];
		}

		return $sanitized;
	}

	/**
	 * Sanitizes letter grades array.
	 *
	 * @since 2.6.0
	 *
	 * @param array $grades The letterGrades array from quiz meta.
	 * @return array Sanitized letterGrades array.
	 */
	private static function sanitize_letter_grades( $grades ) {
		if ( ! is_array( $grades ) ) {
			return self::get_default_letter_grades();
		}

		$sanitized = [];

		foreach ( $grades as $grade ) {
			if ( ! is_array( $grade ) ) {
				continue;
			}

			$sanitized[] = [
				'grade'      => sanitize_text_field( $grade['grade'] ?? '' ),
				'percentage' => min( 100, max( 0, absint( $grade['percentage'] ?? $grade['percent'] ?? 0 ) ) ),
			];
		}

		return ! empty( $sanitized ) ? $sanitized : self::get_default_letter_grades();
	}
}
