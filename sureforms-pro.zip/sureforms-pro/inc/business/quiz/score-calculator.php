<?php
/**
 * Quiz Score Calculator
 *
 * Calculates quiz scores on form submission and resolves quiz smart tags.
 *
 * @since 2.6.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Quiz;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Quiz Score Calculator
 *
 * @since 2.6.0
 */
class Score_Calculator {
	use Get_Instance;

	/**
	 * Cached quiz result for the current submission.
	 *
	 * @var array{score: int, max_score: int, percentage: float|int, pass_fail: string, letter_grade: string, grading_system: string, result_output: string, question_results: array<int, array<string, mixed>>}|null
	 * @since 2.6.0
	 */
	private static $quiz_result = null;

	/**
	 * Quiz configuration for the current form.
	 * Cached to avoid re-fetching from post meta.
	 *
	 * @var array<int, array<string,mixed>>
	 * @since 2.6.0
	 */
	private static $current_quiz_config = [];

	/**
	 * Constructor.
	 *
	 * @since 2.6.0
	 */
	public function __construct() {
		add_filter( 'srfm_form_submit_data', [ $this, 'calculate_score' ] );
		add_filter( 'srfm_smart_tag_list', [ $this, 'add_quiz_smart_tags' ] );
		// Priority 20 to run after other smart tag parsers (e.g., user registration at priority 10)
		// that return null for unrecognized tags, which would overwrite our parsed value.
		add_filter( 'srfm_parse_smart_tags', [ $this, 'parse_quiz_smart_tags' ], 20, 2 );
		add_filter( 'srfm_process_condition_field_value', [ $this, 'resolve_quiz_condition_field' ], 10, 2 );
		add_filter( 'srfm_form_confirmation_data', [ $this, 'append_quiz_result_output' ] );
		add_filter( 'srfm_get_form_post_content', [ $this, 'randomize_questions' ] );
		add_filter( 'srfm_before_entry_data', [ $this, 'store_quiz_result_in_extras' ] );
		// Priority 5 to restore quiz result before webhooks (priority 10) process smart tags.
		add_action( 'srfm_after_submission_process', [ $this, 'restore_quiz_result_from_entry' ], 5 );

		// Temporarily remove quiz tags from the smart tag list during editor localization
		// so they don't appear in the "Generic tags" section of the editor dropdown.
		// The JS quiz filter adds them in a dedicated "Quiz" section instead.
		add_action( 'enqueue_block_editor_assets', [ $this, 'unhook_quiz_smart_tags_for_editor' ], 9 );
		add_action( 'enqueue_block_editor_assets', [ $this, 'rehook_quiz_smart_tags_after_editor' ], 11 );
	}

	/**
	 * Remove quiz smart tags from the smart tag list before editor localization.
	 *
	 * @hooked enqueue_block_editor_assets - priority 9
	 * @since 2.6.0
	 * @return void
	 */
	public function unhook_quiz_smart_tags_for_editor() {
		remove_filter( 'srfm_smart_tag_list', [ $this, 'add_quiz_smart_tags' ] );
	}

	/**
	 * Re-add quiz smart tags to the smart tag list after editor localization.
	 *
	 * @hooked enqueue_block_editor_assets - priority 11
	 * @since 2.6.0
	 * @return void
	 */
	public function rehook_quiz_smart_tags_after_editor() {
		add_filter( 'srfm_smart_tag_list', [ $this, 'add_quiz_smart_tags' ] );
	}

	/**
	 * Get quiz result for the current submission.
	 *
	 * @since 2.6.0
	 * @return array<string,mixed>|null
	 */
	public static function get_quiz_result() {
		return self::$quiz_result;
	}

	/**
	 * Store quiz result in the entry extras column before the entry is saved.
	 *
	 * Persists quiz result alongside the entry so it can be restored in
	 * background processes (e.g., webhook smart tag resolution).
	 *
	 * @hooked srfm_before_entry_data
	 * @since 2.7.0
	 *
	 * @param array<mixed> $entries_data Entry data being saved.
	 * @return array<mixed> Entry data with quiz result in extras.
	 */
	public function store_quiz_result_in_extras( $entries_data ) {
		if ( empty( $entries_data ) || ! is_array( $entries_data ) || null === self::$quiz_result ) {
			return $entries_data;
		}

		$extras                = $entries_data['extras'] ?? [];
		$extras['quiz_result'] = self::$quiz_result;

		$entries_data['extras'] = $extras;

		return $entries_data;
	}

	/**
	 * Restore quiz result from entry extras in background process context.
	 *
	 * When webhooks run in a separate HTTP request, the static quiz result
	 * cache is empty. This method restores it from the entry extras column
	 * so quiz smart tags resolve correctly during webhook processing.
	 *
	 * @hooked srfm_after_submission_process - priority 5
	 * @since 2.7.0
	 *
	 * @param array<mixed> $form_data Form data including form_id and submission_id.
	 * @return void
	 */
	public function restore_quiz_result_from_entry( $form_data ) {
		// Already available in memory (synchronous/GDPR path).
		if ( null !== self::$quiz_result ) {
			return;
		}

		$submission_id = isset( $form_data['submission_id'] )
			? Helper::get_integer_value( $form_data['submission_id'] )
			: 0;

		if ( $submission_id <= 0 ) {
			return;
		}

		$entry_data = Entries::get( $submission_id );

		if ( empty( $entry_data['extras'] ) || ! is_array( $entry_data['extras'] ) ) {
			return;
		}

		$quiz_result = $entry_data['extras']['quiz_result'] ?? null;

		if ( ! empty( $quiz_result ) && is_array( $quiz_result ) ) {
			// @phpstan-ignore-next-line -- Restoring typed array from JSON-decoded extras column.
			self::$quiz_result = $quiz_result;
		}
	}

	/**
	 * Register quiz smart tags so the base plugin recognizes them.
	 * If not added quiz smart tags won't be processed in the frontend.
	 *
	 * @hooked srfm_smart_tag_list
	 * @since 2.6.0
	 *
	 * @param array<string,string> $tags Existing smart tags.
	 * @return array<string,string> Smart tags with quiz tags added.
	 */
	public function add_quiz_smart_tags( $tags ) {
		$tags['{quiz_score}']        = __( 'Quiz Score', 'sureforms-pro' );
		$tags['{quiz_percentage}']   = __( 'Quiz Percentage', 'sureforms-pro' );
		$tags['{quiz_pass_fail}']    = __( 'Quiz Pass/Fail', 'sureforms-pro' );
		$tags['{quiz_letter_grade}'] = __( 'Quiz Letter Grade', 'sureforms-pro' );
		$tags['{quiz_result}']       = __( 'All Quiz Results', 'sureforms-pro' );

		return $tags;
	}

	/**
	 * Calculate quiz score from submitted form data.
	 *
	 * @hooked srfm_form_submit_data
	 * @since 2.6.0
	 *
	 * @param array<string> $form_data Submitted form data.
	 * @return array<string> Unmodified form data (passthrough).
	 */
	public function calculate_score( $form_data ) {
		// Reset static state to prevent stale data when multiple forms
		// are processed in the same PHP process (AJAX batch, REST, cron).
		self::$quiz_result         = null;
		self::$current_quiz_config = [];

		if ( empty( $form_data ) || ! is_array( $form_data ) || empty( $form_data['form-id'] ) ) {
			return $form_data;
		}

		$form_id   = Helper::get_integer_value( $form_data['form-id'] );
		$quiz_data = $this->get_quiz_config( $form_id );

		if ( empty( $quiz_data ) || empty( $quiz_data['questions'] ) ) {
			return $form_data;
		}

		$score_type           = $this->get_string_value( $quiz_data['scoreType'] ?? null, 'correct_incorrect' );
		$correct_answer_score = $this->get_int_value( $quiz_data['correctAnswerScore'] ?? null, 5 );
		$incorrect_score      = $this->get_int_value( $quiz_data['inCorrectAnswerScore'] ?? null, 0 );
		$default_score        = $this->get_int_value( $quiz_data['defaultScore'] ?? null, 5 );
		$randomize_questions  = ! empty( $quiz_data['randomizeQuestions'] );

		$total_score      = 0;
		$max_score        = 0;
		$question_results = [];
		$block_info_map   = $this->get_block_info_map( $form_id );

		// @phpstan-var array<int, array<string, mixed>> $questions
		$questions = is_array( $quiz_data['questions'] ) ? $quiz_data['questions'] : [];
		$questions = $this->get_ordered_questions_for_submission( $questions, $form_data, $randomize_questions );

		foreach ( $questions as $question ) {
			if ( ! is_array( $question ) || empty( $question['status'] ) || empty( $question['blockId'] ) ) {
				continue;
			}

			$block_id        = $this->get_string_value( $question['blockId'] ?? null );
			$correct_answers = is_array( $question['correctAnswers'] ?? null ) ? $question['correctAnswers'] : [];
			$block_info      = $block_info_map[ $block_id ] ?? [];

			$submitted_value  = $this->get_submitted_value_by_block_id( $block_id, $form_data );
			$field_type       = $this->get_string_value( $block_info['type'] ?? null );
			$is_single_choice = isset( $block_info['is_single_choice'] ) ? ! empty( $block_info['is_single_choice'] ) : true;
			$question_options = $this->get_int_value( $block_info['options_count'] ?? null, 0 );

			// Unchecked checkboxes are not submitted, default to false.
			if ( 'checkbox' === $field_type && '' === $submitted_value ) {
				$submitted_value = 'false';
			}

			if ( 'correct_incorrect' === $score_type ) {
				$result     = $this->score_correct_incorrect( $submitted_value, $correct_answers, $correct_answer_score, $incorrect_score );
				$max_score += $correct_answer_score;
			} else {
				$result     = $this->score_advanced( $submitted_value, $correct_answers, $default_score, $is_single_choice, $question_options );
				$max_score += $result['max_score'];
			}

			$result['field_type']  = $field_type;
			$result['label']       = $block_info['label'] ?? '';
			$result['options']     = $block_info['options'] ?? [];
			$result['description'] = $this->get_string_value( $question['description'] ?? null );
			$total_score          += $result['score'];
			$question_results[]    = $result;
		}

		// Clamp at 0 so negative penalty totals do not produce negative percentages.
		$percentage = $max_score > 0 ? max( 0, round( $total_score / $max_score * 100, 2 ) ) : 0;

		$pass_percent  = $this->get_int_value( $quiz_data['passPercent'] ?? null, 50 );
		$letter_grades = is_array( $quiz_data['letterGrades'] ?? null )
			? $quiz_data['letterGrades']
			: ( is_array( $quiz_data['letterGrading'] ?? null ) ? $quiz_data['letterGrading'] : [] );

		self::$quiz_result = [
			'score'            => $total_score,
			'max_score'        => $max_score,
			'percentage'       => $percentage,
			'pass_fail'        => $percentage >= $pass_percent ? 'Pass' : 'Fail',
			'letter_grade'     => $this->get_letter_grade( $percentage, $letter_grades ),
			'grading_system'   => $this->get_string_value( $quiz_data['gradingSystem'] ?? null, 'default' ),
			'result_output'    => $this->get_string_value( $quiz_data['resultOutput'] ?? null, 'default_confirmation' ),
			'question_results' => $question_results,
		];

		return $form_data;
	}

	/**
	 * Resolve quiz smart tags.
	 *
	 * @hooked srfm_parse_smart_tags
	 * @since 2.6.0
	 *
	 * @param mixed               $parsed  Previously parsed value (null if not yet parsed).
	 * @param array<string,mixed> $context Smart tag context with 'tag', 'submission_data', 'form_data'.
	 * @return mixed Parsed value or null to pass through.
	 */
	public function parse_quiz_smart_tags( $parsed, $context ) {
		if ( null === self::$quiz_result ) {
			return $parsed;
		}

		$tag = $context['tag'] ?? '';

		switch ( $tag ) {
			case '{quiz_score}':
				return Helper::get_string_value( self::$quiz_result['score'] ) . ' / ' . Helper::get_string_value( self::$quiz_result['max_score'] );

			case '{quiz_percentage}':
				return self::$quiz_result['percentage'] . '%';

			case '{quiz_letter_grade}':
				return self::$quiz_result['letter_grade'];

			case '{quiz_pass_fail}':
				return self::$quiz_result['pass_fail'];

			case '{quiz_result}':
				return $this->build_quiz_result_markup();

			default:
				return $parsed;
		}
	}

	/**
	 * Resolve quiz field values for conditional logic evaluation.
	 *
	 * When conditional logic rules reference quiz smart tags like {quiz_score},
	 * the field name (without braces) won't exist in $submission_data since
	 * quiz scores are computed values, not form fields. This filter provides
	 * the actual quiz values so conditional logic can evaluate them.
	 *
	 * @hooked srfm_process_condition_field_value
	 * @since 2.6.0
	 *
	 * @param string|null $value           The resolved field value (null if not resolved).
	 * @param string      $field_name      The field name (e.g., 'quiz_score').
	 * @return string|null The resolved value, or null to indicate field not found.
	 */
	public function resolve_quiz_condition_field( $value, $field_name ) {
		if ( null === self::$quiz_result ) {
			return $value;
		}

		switch ( $field_name ) {
			case 'quiz_score':
				return Helper::get_string_value( self::$quiz_result['score'] );

			case 'quiz_percentage':
				return Helper::get_string_value( self::$quiz_result['percentage'] );

			case 'quiz_letter_grade':
				return Helper::get_string_value( self::$quiz_result['letter_grade'] );

			case 'quiz_pass_fail':
				return Helper::get_string_value( self::$quiz_result['pass_fail'] );

			default:
				return $value;
		}
	}

	/**
	 * Append quiz result output to the confirmation message based on the resultOutput setting.
	 *
	 * - 'default_confirmation': No change, use the form's default confirmation as-is.
	 * - 'show_score': Append a score summary (score, percentage, pass/fail, grade).
	 * - 'full_result': Append the full results table with per-question breakdown.
	 *
	 * @hooked srfm_form_confirmation_data
	 * @since 2.6.0
	 *
	 * @param array<mixed> $message The confirmation message data.
	 * @return array<mixed> Modified confirmation message.
	 */
	public function append_quiz_result_output( $message ) {
		if ( null === self::$quiz_result || ! is_array( $message ) ) {
			return $message;
		}

		$result_output = self::$quiz_result['result_output'];

		if ( 'default_confirmation' === $result_output ) {
			return $message;
		}

		$new_message = '';

		if ( 'show_score' === $result_output ) {
			$new_message = $this->build_score_summary_markup();
		} elseif ( 'full_result' === $result_output ) {
			$new_message = $this->build_quiz_result_markup();
		}

		if ( ! empty( $new_message ) && isset( $message[0][0]['message'] ) ) {
			$message[0][0]['message'] = $new_message;
		}

		return $message;
	}

	/**
	 * Randomize quiz question order and/or option order in form content.
	 *
	 * @hooked srfm_get_form_post_content
	 * @since 2.6.0
	 *
	 * @param string $content The form post content with blocks.
	 * @return string Modified content with randomized blocks.
	 */
	public function randomize_questions( $content ) {
		if ( $this->is_preview_request() ) {
			return $content;
		}

		$blocks = parse_blocks( $content );

		$form_id = 0;
		foreach ( $blocks as $block ) {
			if ( ! empty( $block['attrs']['formId'] ) ) {
				$form_id = $block['attrs']['formId'];
				break;
			}
		}

		if ( ! $form_id ) {
			return $content;
		}

		$quiz_config = $this->get_quiz_config( intval( $form_id ) );
		if ( empty( $quiz_config['randomizeQuestions'] ) && empty( $quiz_config['randomizeOptions'] ) ) {
			return $content;
		}

		$questions = is_array( $quiz_config['questions'] ?? null ) ? $quiz_config['questions'] : [];
		if ( empty( $questions ) ) {
			return $content;
		}

		$randomize_questions = ! empty( $quiz_config['randomizeQuestions'] );
		$randomize_options   = ! empty( $quiz_config['randomizeOptions'] );

		$quiz_block_ids = $this->get_quiz_block_ids( $questions );
		$quiz_blocks    = [];
		$quiz_positions = [];

		foreach ( $blocks as $index => $block ) {
			if ( ! $this->is_quiz_block( $block ) ) {
				continue;
			}

			$block_id = $block['attrs']['block_id'] ?? '';
			if ( ! isset( $quiz_block_ids[ $block_id ] ) ) {
				continue;
			}

			// Randomize options within this block independently.
			if ( $randomize_options ) {
				$block            = $this->shuffle_block_options( $block );
				$blocks[ $index ] = $block;
			}

			// Collect blocks independently for question order randomization.
			if ( $randomize_questions ) {
				$quiz_blocks[]    = $block;
				$quiz_positions[] = $index;
			}
		}

		// Shuffle question block order.
		if ( $randomize_questions && count( $quiz_blocks ) > 1 ) {
			$blocks = $this->shuffle_quiz_block_order( $blocks, $quiz_blocks, $quiz_positions );
		}

		return serialize_blocks( $blocks );
	}

	/**
	 * Check if current request is in preview/live-preview mode.
	 *
	 * @since 2.6.0
	 * @return bool True when rendering a preview request.
	 */
	private function is_preview_request() {
		$form_preview = isset( $_GET['form_preview'] ) ? filter_var( sanitize_text_field( wp_unslash( $_GET['form_preview'] ) ), FILTER_VALIDATE_BOOLEAN ) : false; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only preview detection.
		$preview      = isset( $_GET['preview'] ) ? filter_var( sanitize_text_field( wp_unslash( $_GET['preview'] ) ), FILTER_VALIDATE_BOOLEAN ) : false; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only preview detection.
		$live_mode    = Helper::get_instant_form_live_data();

		return $form_preview || $preview || ( is_array( $live_mode ) && ! empty( $live_mode['live_mode'] ) );
	}

	/**
	 * Build HTML markup for the score summary (show_score mode).
	 *
	 * @since 2.6.0
	 *
	 * @return string HTML markup showing score summary.
	 */
	private function build_score_summary_markup() {
		if ( null === self::$quiz_result ) {
			return '';
		}

		return $this->normalize_markup_output( '<div class="srfm-quiz-score-summary">' . $this->build_score_header_markup() . '</div>' );
	}

	/**
	 * Build the shared score header HTML (score, percentage, pass/fail, grade).
	 *
	 * @since 2.6.0
	 *
	 * @return string HTML markup for score header fields.
	 */
	private function build_score_header_markup() {
		$result = self::$quiz_result;

		if ( null === $result ) {
			return '';
		}

		$score_label = esc_html__( 'Score:', 'sureforms-pro' ) . ' ' . esc_html( Helper::get_string_value( $result['score'] ) . ' / ' . Helper::get_string_value( $result['max_score'] ) );
		$output      = '<div style="text-align:center;margin-bottom:12px;color:#374151;display:flex;flex-direction:column;align-items:center;"><span style="font-size:14px;font-weight:400;margin:0 0 4px 0;">' . $score_label . '</span>';

		if ( 'pass_fail' === $result['grading_system'] ) {
			$is_pass              = 'Pass' === $result['pass_fail'];
			$percentage_with_sign = Helper::get_string_value( $result['percentage'] ) . '%';
			if ( $is_pass ) {
				/* translators: %s: percentage value with % sign. */
				$status_text = sprintf( __( 'You passed! with %s', 'sureforms-pro' ), $percentage_with_sign );
			} else {
				/* translators: %s: percentage value with % sign. */
				$status_text = sprintf( __( 'You failed with %s', 'sureforms-pro' ), $percentage_with_sign );
			}
			$output .= '<span style="font-size:14px;margin:0;">' . esc_html( $status_text ) . '</span>';
		}
		if ( 'letter' === $result['grading_system'] && ! empty( $result['letter_grade'] ) ) {
			$output .= '<span style="font-size:14px;margin:4px 0 0 0;">' . esc_html__( 'Grade:', 'sureforms-pro' ) . ' ' . esc_html( Helper::get_string_value( $result['letter_grade'] ) ) . '</span>';
		}
		$output .= '</div>';

		return $this->normalize_markup_output( $output );
	}

	/**
	 * Score a question using correct/incorrect mode.
	 *
	 * @since 2.6.0
	 *
	 * @param string               $submitted_value  The user's submitted answer.
	 * @param array<array<string>> $correct_answers  Array of correct answer objects.
	 * @param int                  $correct_score    Points for a correct answer.
	 * @param int                  $incorrect_score  Points for an incorrect answer.
	 * @return array{score: int, is_correct: bool, submitted: string, correct: string}
	 */
	private function score_correct_incorrect( $submitted_value, $correct_answers, $correct_score, $incorrect_score ) {
		$correct_values = [];
		foreach ( $correct_answers as $answer ) {
			if ( ! empty( $answer['isCorrect'] ) ) {
				$correct_values[] = $answer['answer'] ?? '';
			}
		}

		$is_correct = $this->is_answer_correct( $submitted_value, $correct_values );

		return [
			'score'      => $is_correct ? $correct_score : $incorrect_score,
			'is_correct' => $is_correct,
			'submitted'  => $submitted_value,
			'correct'    => implode( ', ', $correct_values ),
		];
	}

	/**
	 * Score a question using advanced scoring mode.
	 *
	 * @since 2.6.0
	 *
	 * @param string               $submitted_value   The user's submitted answer.
	 * @param array<array<string>> $correct_answers   Array of answer objects with individualScore.
	 * @param int                  $default_score     Default score value.
	 * @param bool                 $is_single_choice  Whether the field allows only one selection.
	 * @param int                  $question_options  Total options available in the question.
	 * @return array{score: int, max_score: int, highest_score: int, submitted: string, correct: string}
	 */
	private function score_advanced( $submitted_value, $correct_answers, $default_score, $is_single_choice = false, $question_options = 0 ) {
		$score           = 0;
		$highest_score   = 0;
		$correct_display = [];
		// Multi-value answers are stored as a pipe-delimited string: "Option A | Option B".
		$submitted_parts  = array_values(
			array_filter(
				array_map( 'trim', explode( '|', $submitted_value ) ),
				static function ( $value ) {
					return '' !== $value;
				}
			)
		);
		$option_scores    = [];
		$answer_score_map = [];

		foreach ( $correct_answers as $answer ) {
			$answer_text      = $answer['answer'] ?? '';
			$individual_score = intval( $answer['individualScore'] ?? $default_score );
			$option_scores[]  = $individual_score;
			$normalized_text  = $this->normalize_value( $answer_text );

			if ( '' !== $normalized_text ) {
				$answer_score_map[ $normalized_text ] = $individual_score;
			}

			// Track the highest single score as fallback.
			if ( $individual_score > $highest_score ) {
				$highest_score = $individual_score;
			}

			// Collect correct answer labels for display.
			if ( ! empty( $answer['isCorrect'] ) ) {
				$correct_display[] = $answer_text;
			}
		}

		// Score selected answers by matching configured options.
		$scored_submitted = [];
		foreach ( $submitted_parts as $submitted_part ) {
			$normalized_submitted = $this->normalize_value( $submitted_part );
			if ( '' === $normalized_submitted || isset( $scored_submitted[ $normalized_submitted ] ) ) {
				continue;
			}

			if ( isset( $answer_score_map[ $normalized_submitted ] ) ) {
				$score += $answer_score_map[ $normalized_submitted ];
			}
			$scored_submitted[ $normalized_submitted ] = true;
		}

		// Fill missing option scores with default score when not all options were explicitly stored.
		$missing_option_scores = max( 0, $question_options - count( $option_scores ) );
		for ( $i = 0; $i < $missing_option_scores; $i++ ) {
			$option_scores[] = $default_score;
		}

		if ( empty( $option_scores ) ) {
			$option_scores[] = $default_score;
		}

		$highest_score = max( $option_scores );

		// Advanced max score:
		// - single-select fields: highest option score.
		// - multi-select fields with known option count: sum of option scores.
		// - fallback (legacy call sites without option count): highest option score.
		if ( $is_single_choice ) {
			$max_score = max( $option_scores );
		} elseif ( $question_options > 0 ) {
			$max_score = array_sum( $option_scores );
		} else {
			$max_score = max( $option_scores );
		}

		return [
			'score'         => $score,
			'max_score'     => $max_score,
			'highest_score' => $highest_score,
			'submitted'     => $submitted_value,
			'correct'       => implode( ', ', $correct_display ),
		];
	}

	/**
	 * Check if the submitted answer matches any correct value.
	 *
	 * Handles both single-value and multi-value (pipe-separated) answers.
	 *
	 * @since 2.6.0
	 *
	 * @param string        $submitted_value The submitted answer string.
	 * @param array<string> $correct_values  Array of correct answer strings.
	 * @return bool True if the answer is correct.
	 */
	private function is_answer_correct( $submitted_value, $correct_values ) {
		if ( empty( $submitted_value ) || empty( $correct_values ) ) {
			return false;
		}

		$submitted_parts = array_map( 'trim', explode( '|', $submitted_value ) );

		// For single correct answer.
		if ( 1 === count( $correct_values ) ) {
			return $this->value_matches( $submitted_parts, $correct_values[0] );
		}

		// For multiple correct answers: all correct values must be present in submitted values
		// and submitted values must exactly match the correct set.
		$submitted_normalized = array_map( [ $this, 'normalize_value' ], $submitted_parts );
		$correct_normalized   = array_map( [ $this, 'normalize_value' ], $correct_values );

		sort( $submitted_normalized );
		sort( $correct_normalized );

		return $submitted_normalized === $correct_normalized;
	}

	/**
	 * Check if any submitted part matches the given answer text.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string> $submitted_parts Array of submitted value parts.
	 * @param string        $answer_text     The answer text to match against.
	 * @return bool True if a match is found.
	 */
	private function value_matches( $submitted_parts, $answer_text ) {
		$normalized_answer = $this->normalize_value( $answer_text );

		foreach ( $submitted_parts as $part ) {
			if ( $this->normalize_value( $part ) === $normalized_answer ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize a string value for comparison.
	 *
	 * @since 2.6.0
	 *
	 * @param string $value The value to normalize.
	 * @return string Normalized value.
	 */
	private function normalize_value( $value ) {
		return strtolower( trim( html_entity_decode( wp_strip_all_tags( $value ) ) ) );
	}

	/**
	 * Convert raw field values to human-readable display strings.
	 *
	 * Checkbox fields store 'true'/'false' internally; this converts them
	 * to localized 'True'/'False' for display in results markup.
	 *
	 * @since 2.6.0
	 *
	 * @param string $value      The raw field value.
	 * @param string $field_type The field type (e.g., 'checkbox').
	 * @return string Display-ready value.
	 */
	private function get_display_value( $value, $field_type = '' ) {
		if ( 'checkbox' === $field_type ) {
			return 'true' === $value ? __( 'True', 'sureforms-pro' ) : __( 'False', 'sureforms-pro' );
		}

		return $value;
	}

	/**
	 * Safely cast a mixed value to string.
	 *
	 * @since 2.6.0
	 *
	 * @param mixed  $value   The value to cast.
	 * @param string $default Default if value is not scalar.
	 * @return string
	 */
	private function get_string_value( $value, $default = '' ) {
		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Safely cast a mixed value to int.
	 *
	 * @since 2.6.0
	 *
	 * @param mixed $value   The value to cast.
	 * @param int   $default Default if value is not scalar.
	 * @return int
	 */
	private function get_int_value( $value, $default = 0 ) {
		return is_scalar( $value ) ? (int) $value : $default;
	}

	/**
	 * Find the submitted value for a given block ID from the form data.
	 *
	 * Form field keys follow patterns like:
	 * - srfm-dropdown-{counter}-{block_id}-lbl-...
	 * - srfm-input-multi-choice-{block_id}-lbl-...
	 * - srfm-checkbox-{block_id}-lbl-...
	 *
	 * @since 2.6.0
	 *
	 * @param string        $block_id  The block ID to search for.
	 * @param array<string> $form_data The submitted form data.
	 * @return string The submitted value, or empty string if not found.
	 */
	private function get_submitted_value_by_block_id( $block_id, $form_data ) {
		$fallback_value = '';

		foreach ( $form_data as $key => $value ) {
			if ( ! is_string( $key ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}

			// Extract the part before -lbl- and check if it ends with the block_id.
			$field_prefix    = explode( '-lbl-', $key )[0];
			$block_id_suffix = '-' . $block_id;

			if ( substr( $field_prefix, -strlen( $block_id_suffix ) ) === $block_id_suffix ) {
				$is_checkbox     = 0 === strpos( $field_prefix, 'srfm-checkbox-' );
				$submitted_value = '';

				// If it is checkbox then convert on to true/false.
				if ( $is_checkbox ) {
					$submitted_value = 'on' === $value ? 'true' : 'false';
				} elseif ( is_array( $value ) ) {
					$submitted_value = implode( ' | ', array_map( [ $this, 'get_string_value' ], $value ) );
				} else {
					$submitted_value = is_string( $value ) ? $value : Helper::get_string_value( $value );
				}

				$submitted_value = trim( $submitted_value );

				// Prefer non-empty values if multiple keys happen to match.
				if ( '' !== $submitted_value || $is_checkbox ) {
					return $submitted_value;
				}

				$fallback_value = $submitted_value;
			}
		}

		return $fallback_value;
	}

	/**
	 * Reorder questions to match the submission order when questions are randomized.
	 *
	 * The submission data preserves the order of form fields as presented to the user,
	 * so we can align the results list with the randomized display order.
	 *
	 * @since 2.6.0
	 *
	 * @param array<int, array<string, mixed>> $questions          Quiz questions.
	 * @param array<string, mixed>             $form_data          Submitted form data.
	 * @param bool                             $randomize_questions Whether question randomization is enabled.
	 * @return array<int, array<string, mixed>> Reordered questions.
	 */
	private function get_ordered_questions_for_submission( $questions, $form_data, $randomize_questions ) {
		if ( ! $randomize_questions || empty( $questions ) || empty( $form_data ) || ! is_array( $form_data ) ) {
			return $questions;
		}

		$submission_order = $this->get_quiz_block_order_from_form_data( $form_data, $questions );
		if ( empty( $submission_order ) ) {
			return $questions;
		}

		$questions_by_id = [];
		foreach ( $questions as $question ) {
			$block_id = $this->get_string_value( $question['blockId'] ?? null );
			if ( empty( $block_id ) ) {
				continue;
			}
			$questions_by_id[ $block_id ] = $question;
		}

		$ordered_questions = [];
		foreach ( $submission_order as $block_id ) {
			if ( isset( $questions_by_id[ $block_id ] ) ) {
				$ordered_questions[] = $questions_by_id[ $block_id ];
				unset( $questions_by_id[ $block_id ] );
			}
		}

		foreach ( $questions as $question ) {
			$block_id = $this->get_string_value( $question['blockId'] ?? null );
			if ( empty( $block_id ) || ! isset( $questions_by_id[ $block_id ] ) ) {
				continue;
			}
			$ordered_questions[] = $question;
			unset( $questions_by_id[ $block_id ] );
		}

		return $ordered_questions;
	}

	/**
	 * Extract quiz block IDs in the order they appear in the submitted form data.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string, mixed>             $form_data Submitted form data.
	 * @param array<int, array<string, mixed>> $questions Quiz questions.
	 * @return array<int, string> Ordered list of quiz block IDs.
	 */
	private function get_quiz_block_order_from_form_data( $form_data, $questions ) {
		$quiz_block_ids = $this->get_quiz_block_ids( $questions );
		$ordered_ids    = [];

		foreach ( $form_data as $key => $value ) {
			if ( ! is_string( $key ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}

			$block_id = Helper::get_block_id_from_key( $key );
			if ( empty( $block_id ) || ! isset( $quiz_block_ids[ $block_id ] ) ) {
				continue;
			}

			if ( ! isset( $ordered_ids[ $block_id ] ) ) {
				$ordered_ids[ $block_id ] = true;
			}
		}

			return array_map(
				'strval',
				array_keys( $ordered_ids )
			);
	}

	/**
	 * Build a map of block_id to field type and label from the form's post content.
	 *
	 * Parses the form blocks to determine each quiz block's type
	 * (e.g., 'checkbox', 'multi-choice', 'dropdown') and its label text.
	 *
	 * @since 2.6.0
	 *
	 * @param int $form_id Form post ID.
	 * @return array<string, array{type: string, label: string, options: array<int,string>, is_single_choice: bool, options_count: int}> Map of block_id => info array.
	 */
	private function get_block_info_map( $form_id ) {
		$content = get_post_field( 'post_content', $form_id );

		if ( empty( $content ) || ! is_string( $content ) ) {
			return [];
		}

		$blocks   = parse_blocks( $content );
		$info_map = [];

		foreach ( $blocks as $block ) {
			if ( ! $this->is_quiz_block( $block ) ) {
				continue;
			}

			$block_id   = $block['attrs']['block_id'] ?? '';
			$block_name = $block['blockName'] ?? '';

			if ( empty( $block_id ) || ! is_string( $block_id ) || ! is_string( $block_name ) ) {
				continue;
			}

			$field_type = str_replace( 'srfm/', '', $block_name );
			$options    = $this->extract_block_options( $block['attrs'] ?? [], $field_type );

			$info_map[ $block_id ] = [
				'type'             => $field_type,
				'label'            => $this->get_string_value( $block['attrs']['label'] ?? ( $block['attrs']['fieldLabel'] ?? null ) ),
				'options'          => $options,
				'is_single_choice' => $this->is_single_choice_field( $block['attrs'] ?? [], $field_type ),
				'options_count'    => 'checkbox' === $field_type ? 2 : count( $options ),
			];
		}

		return $info_map;
	}

	/**
	 * Extract option labels from block attributes.
	 *
	 * Multi-choice blocks use 'optionTitle', dropdown blocks use 'label'.
	 * Checkbox blocks have no options array and return empty.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string,mixed> $attrs      Block attributes.
	 * @param string              $field_type The field type (e.g., 'multi-choice', 'dropdown', 'checkbox').
	 * @return array<int,string> Array of option label strings.
	 */
	private function extract_block_options( $attrs, $field_type ) {
		if ( 'checkbox' === $field_type || empty( $attrs['options'] ) || ! is_array( $attrs['options'] ) ) {
			return [];
		}

		$options = [];
		foreach ( $attrs['options'] as $opt ) {
			if ( ! is_array( $opt ) ) {
				continue;
			}

			// Multi-choice uses 'optionTitle', dropdown uses 'label'.
			$label = $opt['optionTitle'] ?? ( $opt['label'] ?? '' );
			if ( is_string( $label ) && '' !== $label ) {
				$options[] = $label;
			}
		}

		return $options;
	}

	/**
	 * Check whether a quiz field supports only one selected answer.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string,mixed> $attrs      Block attributes.
	 * @param string              $field_type Field type.
	 * @return bool True when field is single-choice.
	 */
	private function is_single_choice_field( $attrs, $field_type ) {
		if ( 'checkbox' === $field_type ) {
			return true;
		}

		if ( 'dropdown' === $field_type ) {
			return ! $this->to_bool( $attrs['multiSelect'] ?? false );
		}

		if ( 'multi-choice' === $field_type ) {
			return $this->to_bool( $attrs['singleSelection'] ?? false );
		}

		return false;
	}

	/**
	 * Convert bool-like values to strict boolean.
	 *
	 * @since 2.6.0
	 *
	 * @param mixed $value Value to normalize.
	 * @return bool
	 */
	private function to_bool( $value ) {
		return true === $value || 'true' === $value || 1 === $value || '1' === $value;
	}

	/**
	 * Determine the letter grade for a given percentage.
	 *
	 * @since 2.6.0
	 *
	 * @param float|int            $percentage    The score percentage.
	 * @param array<array<string>> $letter_grades Array of grade objects with 'grade' and 'percentage' keys.
	 * @return string The letter grade, or empty string if not applicable.
	 */
	private function get_letter_grade( $percentage, $letter_grades ) {
		if ( empty( $letter_grades ) ) {
			return '';
		}

		// Sort grades by percentage descending so we find the highest matching grade.
		usort(
			$letter_grades,
			static function ( $a, $b ) {
				return intval( $b['percentage'] ?? 0 ) - intval( $a['percentage'] ?? 0 );
			}
		);

		$matched_grade = '';
		foreach ( $letter_grades as $grade ) {
			$grade_percent = intval( $grade['percentage'] ?? 0 );
			if ( $percentage >= $grade_percent ) {
				$matched_grade = Helper::get_string_value( $grade['grade'] ?? '' );
				break;
			}
		}

		// If no grade matched (score below all thresholds), assign the lowest grade.
		if ( empty( $matched_grade ) ) {
			$last_grade    = end( $letter_grades );
			$matched_grade = is_array( $last_grade ) ? Helper::get_string_value( $last_grade['grade'] ?? '' ) : '';
		}

		return sanitize_text_field( $matched_grade );
	}

	/**
	 * Build HTML markup for the all quiz results smart tag.
	 *
	 * @since 2.6.0
	 *
	 * @return string HTML markup showing full quiz results.
	 */
	private function build_quiz_result_markup() {
		if ( null === self::$quiz_result ) {
			return '';
		}

		$output  = '<div class="srfm-quiz-results" style="font-size:14px;">';
		$output .= $this->build_score_header_markup();
		$output .= $this->build_question_results_list();
		$output .= '</div>';

		return $this->normalize_markup_output( $output );
	}

	/**
	 * Build HTML markup for per-question results breakdown as a card list.
	 *
	 * @since 2.6.0
	 *
	 * @return string HTML markup, or empty string if no question results.
	 */
	private function build_question_results_list() {
		$question_results = self::$quiz_result['question_results'] ?? [];

		if ( empty( $question_results ) || ! is_array( $question_results ) ) {
			return '';
		}

		$output = '<div style="background:#fafafa;border:1px solid #1E1E1E14;border-radius:8px;padding:12px;text-align:left;display:flex;gap:16px;flex-direction:column;">';
		foreach ( $question_results as $index => $qr ) {
			if ( ! is_array( $qr ) ) {
				continue;
			}
			if ( $index > 0 ) {
				$output .= '<hr style="border:0;border-top:1px solid #E5E7EB;margin:0;" />';
			}

			$is_advanced       = array_key_exists( 'highest_score', $qr );
			$question_label    = $this->get_string_value( $qr['label'] ?? null );
			$field_type        = $this->get_string_value( $qr['field_type'] ?? null );
			$submitted_display = $this->get_display_value( $this->get_string_value( $qr['submitted'] ?? null ), $field_type );
			$is_unanswered     = ! $is_advanced && '' === trim( $submitted_display );
			$question_number   = $index + 1;
			$label_text        = ! empty( $question_label ) ? esc_html( $question_number . '. ' . $question_label ) : esc_html( $question_number . '.' );
			$score_suffix_html = '';
			if ( isset( $qr['score'], $qr['max_score'] ) ) {
				$score_text        = ' (' . esc_html( Helper::get_string_value( $qr['score'] ) ) . '/' . esc_html( Helper::get_string_value( $qr['max_score'] ) ) . ')';
				$score_suffix_html = $is_advanced
					? ' <strong style="font-weight:700;">' . trim( $score_text ) . '</strong>'
					: $score_text;
			}

			$submitted_values = array_values(
				array_filter(
					array_map( 'trim', explode( '|', $this->get_string_value( $qr['submitted'] ?? null ) ) ),
					static function ( $value ) {
						return '' !== $value;
					}
				)
			);
			$correct_values   = array_values(
				array_filter(
					array_map( 'trim', explode( ',', $this->get_string_value( $qr['correct'] ?? null ) ) ),
					static function ( $value ) {
						return '' !== $value;
					}
				)
			);

			$submitted_lookup = [];
			foreach ( $submitted_values as $value ) {
				$submitted_lookup[ $this->normalize_value( $value ) ] = true;
			}
			$correct_lookup = [];
			foreach ( $correct_values as $value ) {
				$correct_lookup[ $this->normalize_value( $value ) ] = true;
			}

			$options = isset( $qr['options'] ) && is_array( $qr['options'] ) ? $qr['options'] : [];

			$output .= '<div style="display:flex;flex-direction:column;gap:8px;"><span style="font-weight:500;font-size:14px;color:#1E1E1E;line-height:20px;">' . $label_text . $score_suffix_html . '</span>';
			if ( ! empty( $options ) ) {
				$output .= '<div style="display:flex;flex-direction:column;gap:4px;">';
				foreach ( $options as $option ) {
					$option_text = $this->get_string_value( $option );
					if ( '' === $option_text ) {
						continue;
					}

					$normalized_option = $this->normalize_value( $option_text );
					$is_selected       = isset( $submitted_lookup[ $normalized_option ] );
					$is_correct_option = isset( $correct_lookup[ $normalized_option ] );
					if ( $is_advanced ) {
						$dot_color = '#A5A5A5';
					} else {
						$dot_color = $is_correct_option ? '#15803D' : ( $is_selected ? '#B91C1C' : '#A5A5A5' );
					}
					$meta = [];

					if ( $is_selected ) {
						$meta[] = esc_html__( 'Selected', 'sureforms-pro' );
					}
					if ( ! $is_advanced && ! $is_selected && $is_correct_option ) {
						$meta[] = esc_html__( 'Correct', 'sureforms-pro' );
					}

					$output .= '<span style="line-height:20px;color:#4A4A4A;display:flex;align-items:flex-start;gap:8px; padding-right:6px; padding-left:6px;"><span style="width:6.33px;height:6.33px;border-radius:9999px;background:' . esc_attr( $dot_color ) . ';display:inline-block;flex-shrink:0;margin-top:6.84px;"></span><span style="flex:1;">' . esc_html( $option_text );
					if ( ! empty( $meta ) ) {
						$output .= ' - <strong style="font-weight:700;">' . esc_html( implode( ', ', $meta ) ) . '</strong>';
					}
					$output .= '</span></span>';
				}
				$output .= '</div>';
			} elseif ( 'checkbox' === $field_type ) {
				$checkbox_options = [ __( 'True', 'sureforms-pro' ), __( 'False', 'sureforms-pro' ) ];
				$output          .= '<div style="display:flex;flex-direction:column;gap:4px;">';
				foreach ( $checkbox_options as $option_text ) {
					$normalized_option = $this->normalize_value( $option_text );
					$is_selected       = isset( $submitted_lookup[ $normalized_option ] );
					$is_correct_option = isset( $correct_lookup[ $normalized_option ] );
					if ( $is_advanced ) {
						$dot_color = '#A5A5A5';
					} else {
						$dot_color = $is_correct_option ? '#15803D' : ( $is_selected ? '#B91C1C' : '#A5A5A5' );
					}
					$meta = [];
					if ( $is_selected ) {
						$meta[] = esc_html__( 'Selected', 'sureforms-pro' );
					}
					if ( ! $is_advanced && ! $is_selected && $is_correct_option ) {
						$meta[] = esc_html__( 'Correct', 'sureforms-pro' );
					}
					$output .= '<span style="line-height:20px;color:#4A4A4A;display:flex;align-items:flex-start;gap:8px;padding-right:6px;padding-left:6px;"><span style="width:6.33px;height:6.33px;border-radius:9999px;background:' . esc_attr( $dot_color ) . ';display:inline-block;flex-shrink:0;margin-top:6.84px;"></span><span style="flex:1;">' . esc_html( $option_text );
					if ( ! empty( $meta ) ) {
						$output .= ' - <strong style="font-weight:600;">' . esc_html( implode( ', ', $meta ) ) . '</strong>';
					}
					$output .= '</span></span>';
				}
				$output .= '</div>';
			} else {
				$output .= '<span style="line-height:20px;color:#4A4A4A;display:flex;align-items:center;flex-wrap:wrap;gap:8px;"><span>' . esc_html__( 'Your Answer:', 'sureforms-pro' ) . '</span>' . ( $is_unanswered ? esc_html__( 'No Answer Selected', 'sureforms-pro' ) : esc_html( $submitted_display ) ) . '</span>';
			}

			$question_description = $this->get_string_value( $qr['description'] ?? null );
			if ( '' !== $question_description ) {
				$output .= '<p style="margin:8px 0 0 0;font-size:13px;color:#6B7280;font-style:italic;">' . nl2br( esc_html( $question_description ) ) . '</p>';
			}

			$output .= '</div>';
		}
		$output .= '</div>';

		return $this->normalize_markup_output( $output );
	}

	/**
	 * Normalize buffered HTML output to avoid layout breaks from extra whitespace/newlines.
	 *
	 * @since 2.6.0
	 *
	 * @param string $markup Raw markup.
	 * @return string Normalized markup.
	 */
	private function normalize_markup_output( $markup ) {
		$normalized = trim( $this->get_string_value( $markup ) );
		$normalized = preg_replace( '/[\r\n\t]+/', '', $normalized );
		$normalized = is_string( $normalized ) ? $normalized : trim( $this->get_string_value( $markup ) );
		$normalized = preg_replace( '/>\s+</', '><', $normalized );
		$normalized = is_string( $normalized ) ? $normalized : trim( $this->get_string_value( $markup ) );
		$replaced   = preg_replace( '/\s{2,}/', ' ', $normalized );

		return is_string( $replaced ) ? $replaced : $normalized;
	}

	/**
	 * Check if a block is a quiz-eligible block type.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string,mixed> $block Parsed block data.
	 * @return bool True if the block is a quiz block type.
	 */
	private function is_quiz_block( $block ) {
		$quiz_block_names = [
			'srfm/multi-choice',
			'srfm/dropdown',
			'srfm/checkbox',
		];

		return in_array( $block['blockName'] ?? '', $quiz_block_names, true );
	}

	/**
	 * Get a lookup map of block IDs that are quiz questions.
	 *
	 * @since 2.6.0
	 *
	 * @param array<int, array<string, mixed>> $questions Quiz question configurations.
	 * @return array<string, true> Map of block_id => true for quick lookup.
	 */
	private function get_quiz_block_ids( $questions ) {
		$ids = [];
		foreach ( $questions as $question ) {
			if ( is_array( $question ) && ! empty( $question['blockId'] ) && is_string( $question['blockId'] ) ) {
				$ids[ $question['blockId'] ] = true;
			}
		}
		return $ids;
	}

	/**
	 * Shuffle the options within a quiz block.
	 *
	 * @since 2.6.0
	 *
	 * @param array<string,mixed> $block The parsed block data.
	 * @return array<string,mixed> Block with shuffled options.
	 */
	private function shuffle_block_options( $block ) {
		$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];

		if ( empty( $attrs['options'] ) || ! is_array( $attrs['options'] ) ) {
			return $block;
		}

		$options = $attrs['options'];

		// @phpstan-var array<int> $option_indices
		$option_indices   = array_keys( $options );
		$shuffled_indices = $option_indices;

		if ( count( $shuffled_indices ) > 1 ) {
			// For two options, allow true random order (50/50).
			if ( 2 === count( $shuffled_indices ) ) {
				if ( 1 === random_int( 0, 1 ) ) {
					$shuffled_indices = [ $option_indices[1], $option_indices[0] ];
				}
			} else {
				$max_attempts = 5;
				$attempts     = 0;

				// Keep retrying until options are reordered, with a deterministic fallback.
				do {
					shuffle( $shuffled_indices );
					++$attempts;
				} while ( $shuffled_indices === $option_indices && $attempts < $max_attempts );

				if ( $shuffled_indices === $option_indices ) {
					$first = array_shift( $shuffled_indices );
					if ( null !== $first ) {
						$shuffled_indices[] = $first;
					}
				}
			}
		}

		$shuffled_options = [];
		foreach ( $shuffled_indices as $i ) {
			$shuffled_options[] = $options[ $i ];
		}

		$attrs['options'] = $shuffled_options;
		$block['attrs']   = $attrs;

		return $block;
	}

	/**
	 * Shuffle quiz blocks into randomized positions within the full blocks array.
	 *
	 * @since 2.6.0
	 *
	 * @param array<array<string,mixed>> $blocks         All parsed blocks.
	 * @param array<array<string,mixed>> $quiz_blocks    Quiz blocks to shuffle.
	 * @param array<int>                 $quiz_positions Original positions of quiz blocks.
	 * @return array<array<string,mixed>> Blocks with quiz blocks in shuffled order.
	 */
	private function shuffle_quiz_block_order( $blocks, $quiz_blocks, $quiz_positions ) {
		$indices = array_keys( $quiz_blocks );
		$this->shuffle_array( $indices );

		$shuffled_blocks = [];
		foreach ( $indices as $i ) {
			$shuffled_blocks[] = $quiz_blocks[ $i ];
		}

		foreach ( $quiz_positions as $i => $position ) {
			$blocks[ $position ] = $shuffled_blocks[ $i ];
		}

		return $blocks;
	}

	/**
	 * Fisher-Yates shuffle algorithm for array randomization.
	 *
	 * Shuffles an array in-place using cryptographically secure random number generation.
	 *
	 * @since 2.6.0
	 *
	 * @param array<int> $array The array to shuffle (modified in-place).
	 * @return void
	 */
	private function shuffle_array( &$array ) {
		$n = count( $array );
		for ( $i = $n - 1; $i > 0; $i-- ) {
			// Use random_int for cryptographically secure randomization.
			$j = random_int( 0, $i );
			// Swap elements at positions $i and $j.
			$temp        = $array[ $i ];
			$array[ $i ] = $array[ $j ];
			$array[ $j ] = $temp;
		}
	}

	/**
	 * Get quiz configuration for a form.
	 *
	 * Caches the quiz configuration to avoid repeated post meta lookups.
	 *
	 * @since 2.6.0
	 *
	 * @param int $form_id Form post ID.
	 * @return array<string,mixed>|null Quiz configuration array or null if not found.
	 */
	private function get_quiz_config( $form_id ) {
		if ( ! is_array( self::$current_quiz_config ) ) {
			self::$current_quiz_config = [];
		}

		if ( isset( self::$current_quiz_config[ $form_id ] ) ) {
			return self::$current_quiz_config[ $form_id ];
		}

		$quiz_meta = get_post_meta( $form_id, '_srfm_quiz_meta', true );

		if ( empty( $quiz_meta ) || ! is_string( $quiz_meta ) ) {
			return null;
		}

		$quiz_data = json_decode( $quiz_meta, true );

		if ( ! is_array( $quiz_data ) || empty( $quiz_data['status'] ) ) {
			return null;
		}

		self::$current_quiz_config[ $form_id ] = $quiz_data;
		return $quiz_data;
	}

}
