<?php
/**
 * Quiz Entries admin and REST endpoints.
 *
 * @package sureforms-pro
 * @since 2.6.0
 */

namespace SRFM_Pro\Inc\Business\Quiz;

use SRFM\Admin\Admin as Core_Admin;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Business\Database\Tables\Quiz;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Quiz Entries class.
 *
 * @since 2.6.0
 */
class Quiz_Entries {
	use Get_Instance;

	/**
	 * Maximum items per page for quiz listing endpoints.
	 *
	 * @since 2.6.0
	 */
	public const MAX_PER_PAGE = 100;

	/**
	 * Allowed columns for quiz list sorting.
	 *
	 * @since 2.6.0
	 */
	public const ALLOWED_ORDERBY = [ 'id', 'form_id', 'created_at', 'updated_at' ];

	/**
	 * Quiz entries page slug.
	 *
	 * @since 2.6.0
	 */
	public const PAGE_SLUG = 'sureforms_quiz_entries';

	/**
	 * Constructor.
	 *
	 * @since 2.6.0
	 */
	public function __construct() {
		add_filter( 'srfm_form_submission_response', [ $this, 'store_quiz_entry' ], 15, 3 );
		add_action( 'admin_menu', [ $this, 'register_menu' ], 30 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_rest_endpoints' ] );
		add_filter( 'srfm_is_dashboard_screen', [ $this, 'add_quiz_entries_screen' ] );
		add_filter( 'srfm_admin_filter', [ $this, 'add_quiz_entries_nav_item' ] );
		add_action( 'srfm_before_delete_entry', [ $this, 'delete_quiz_entry_on_entry_delete' ] );
	}

	/**
	 * Delete quiz entry when its parent form entry is deleted.
	 *
	 * @param int $entry_id The entry being deleted.
	 * @since 2.6.0
	 * @return void
	 */
	public function delete_quiz_entry_on_entry_delete( $entry_id ) {
		if ( empty( $entry_id ) ) {
			return;
		}

		Quiz::delete_by_entry_id( absint( $entry_id ) );
	}

	/**
	 * Store quiz entry after successful submission.
	 *
	 * @param array<mixed>  $response        Submission response.
	 * @param array<string> $form_data       Raw form data.
	 * @param array<mixed>  $submission_data Prepared submission data.
	 * @since 2.6.0
	 * @return array<mixed>
	 */
	public function store_quiz_entry( $response, $form_data, $submission_data ) {
		if ( empty( $response['success'] ) ) {
			return $response;
		}

		$entry_id = $response['data']['submission_id'] ?? 0;
		$form_id  = isset( $form_data['form-id'] ) ? Helper::get_integer_value( $form_data['form-id'] ) : 0;

		if ( ! $entry_id || ! $form_id ) {
			return $response;
		}

		$quiz_result = Score_Calculator::get_quiz_result();
		if ( empty( $quiz_result ) || ! is_array( $quiz_result ) ) {
			return $response;
		}

		$quiz_data              = is_array( $submission_data ) ? $submission_data : [];
		$quiz_data['_entry_id'] = $entry_id;
		$quiz_data['_form_id']  = $form_id;

		$quiz_entry = [
			'form_id'     => $form_id,
			'entry_id'    => $entry_id,
			'quiz_data'   => $quiz_data,
			'quiz_result' => $quiz_result,
			'notes'       => [],
		];

		/**
		 * Filter quiz entry data before saving.
		 *
		 * @param array<string,mixed> $quiz_entry Quiz entry data.
		 * @param array<mixed>        $response   Submission response.
		 * @param array<string>       $form_data  Raw form data.
		 * @param array<mixed>        $submission_data Prepared submission data.
		 */
		$quiz_entry = apply_filters( 'srfm_quiz_entry_data', $quiz_entry, $response, $form_data, $submission_data );

		Quiz::add( $quiz_entry );

		return $response;
	}

	/**
	 * Register admin menu for quiz entries.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public function register_menu() {
		if ( ! Helper::current_user_can() ) {
			return;
		}

		add_submenu_page(
			'sureforms_menu',
			__( 'Quiz Entries', 'sureforms-pro' ),
			__( 'Quizzes', 'sureforms-pro' ) .
					' <span style="color:#4ADE80;font-size:9px;font-weight:600;">' .
					esc_html__( 'New', 'sureforms-pro' ) .
					'</span>',
			'manage_options',
			self::PAGE_SLUG,
			[ $this, 'render_page' ],
			5
		);
	}

	/**
	 * Render quiz entries root.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public function render_page() {
		echo '<div id="srfm-quiz-entries-root" class="srfm-admin-wrapper"></div>';
	}

	/**
	 * Add quiz entries screen to the SureForms dashboard screen check.
	 *
	 * @param bool $is_dashboard_screen Whether the current screen is a SureForms dashboard screen.
	 * @since 2.6.0
	 * @return bool
	 */
	public function add_quiz_entries_screen( $is_dashboard_screen ) {
		if ( $is_dashboard_screen ) {
			return $is_dashboard_screen;
		}

		return Helper::validate_request_context( self::PAGE_SLUG, 'page' );
	}

	/**
	 * Add Quizzes nav item to the header navigation.
	 *
	 * @param array<string,mixed> $localization_data Localization data.
	 * @since 2.6.0
	 * @return array<string,mixed>
	 */
	public function add_quiz_entries_nav_item( $localization_data ) {
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		$site_url = get_site_url();
		if ( ! isset( $localization_data['additional_header_nav_items'] ) || ! is_array( $localization_data['additional_header_nav_items'] ) ) {
			$localization_data['additional_header_nav_items'] = [];
		}

		$localization_data['additional_header_nav_items'][] = [
			'slug' => self::PAGE_SLUG,
			'text' => __( 'Quizzes', 'sureforms-pro' ),
			'link' => $site_url . '/wp-admin/admin.php?page=' . self::PAGE_SLUG,
		];

		return $localization_data;
	}

	/**
	 * Enqueue quiz entries assets.
	 *
	 * @param string $hook_prefix Current admin page hook.
	 * @since 2.6.0
	 * @return void
	 */
	public function enqueue_assets( $hook_prefix ) {
		if ( 'sureforms_page_' . self::PAGE_SLUG !== $hook_prefix ) {
			return;
		}

		$asset_handle      = 'quizEntries';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$script_info['dependencies'],
			$script_info['version'],
			true
		);

		$css_file = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.css';
		if ( file_exists( $css_file ) ) {
			wp_enqueue_style(
				SRFM_PRO_SLUG . '-' . $asset_handle,
				SRFM_PRO_URL . 'dist/' . $asset_handle . '.css',
				[],
				SRFM_PRO_VER
			);
		}

		$is_license_active = false;
		if ( class_exists( '\\SRFM_Pro\\Admin\\Licensing' ) ) {
			$is_license_active = \SRFM_Pro\Admin\Licensing::is_license_active();
		}

		$localization_data = [
			'site_url'                   => get_site_url(),
			'sureforms_dashboard_url'    => admin_url( '/admin.php?page=sureforms_menu' ),
			'plugin_version'             => defined( 'SRFM_VER' ) ? SRFM_VER : '',
			'global_settings_nonce'      => Helper::current_user_can() ? wp_create_nonce( 'wp_rest' ) : '',
			'is_pro_active'              => Helper::has_pro(),
			'is_license_active'          => $is_license_active,
			'is_first_form_created'      => class_exists( Core_Admin::class ) ? Core_Admin::is_first_form_created() : false,
			'check_three_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold() : false,
			'check_eight_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold( 8 ) : false,
			'pro_plugin_version'         => Helper::has_pro() && defined( 'SRFM_PRO_VER' ) ? SRFM_PRO_VER : '',
			'pro_plugin_name'            => Helper::has_pro() && defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Pro',
			'sureforms_pricing_page'     => Helper::get_sureforms_website_url( 'pricing' ),
		];

		$localization_data = apply_filters( 'srfm_admin_filter', $localization_data );
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		wp_add_inline_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'var srfm_admin = window.srfm_admin || {};',
			'before'
		);

		wp_localize_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'srfm_admin',
			$localization_data
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $asset_handle );
	}

	/**
	 * Register REST API endpoints.
	 *
	 * @param array<string,mixed> $endpoints Existing endpoints.
	 * @since 2.6.0
	 * @return array<string,mixed>
	 */
	public function register_rest_endpoints( $endpoints ) {
		$endpoints['quiz-entries/list'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_quiz_entries_list' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'   => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
				'search'    => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
				'date_from' => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
				'date_to'   => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
				'orderby'   => [
					'sanitize_callback' => [ $this, 'sanitize_orderby' ],
					'default'           => 'created_at',
				],
				'order'     => [
					'sanitize_callback' => [ $this, 'sanitize_order' ],
					'default'           => 'DESC',
				],
				'per_page'  => [
					'sanitize_callback' => [ $this, 'sanitize_per_page' ],
					'default'           => 20,
				],
				'page'      => [
					'sanitize_callback' => 'absint',
					'default'           => 1,
				],
			],
		];

		$endpoints['quiz-entries/delete'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'delete_quiz_entries' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'quiz_ids' => [
					'required'          => true,
					'sanitize_callback' => [ $this, 'sanitize_quiz_ids' ],
				],
			],
		];

		$endpoints['quiz-entries/detail'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_quiz_entry_detail' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id' => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		];

		$endpoints['quiz-entries/update-note'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'update_quiz_entry_note' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id'    => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				],
				'notes' => [
					'required'          => false,
					'sanitize_callback' => 'sanitize_textarea_field',
				],
			],
		];

		$endpoints['quiz-entries/(?P<id>\d+)/notes'] = [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_quiz_entry_notes' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'       => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'per_page' => [
						'sanitize_callback' => [ $this, 'sanitize_per_page' ],
						'default'           => 10,
					],
					'page'     => [
						'sanitize_callback' => 'absint',
						'default'           => 1,
					],
				],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_quiz_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'   => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'note' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_textarea_field',
					],
				],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_quiz_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'      => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'note_id' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Get a single quiz entry detail.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_quiz_entry_detail( $request ) {
		$quiz_id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		if ( empty( $quiz_id ) ) {
			return new WP_Error( 'invalid_quiz_id', __( 'Invalid quiz ID.', 'sureforms-pro' ) );
		}

		$entry = Quiz::get( absint( $quiz_id ) );
		if ( empty( $entry ) ) {
			return new WP_Error( 'quiz_not_found', __( 'Quiz entry not found.', 'sureforms-pro' ) );
		}

		$formatted  = $this->format_quiz_entries( [ $entry ] );
		$navigation = Quiz::get_adjacent_entry_ids( absint( $quiz_id ), [ 'form_id' => absint( $entry['form_id'] ?? 0 ) ] );

		return [
			'entry'      => $formatted[0] ?? [],
			'navigation' => [
				'previous_id' => $navigation['previous_id'] ?? null,
				'next_id'     => $navigation['next_id'] ?? null,
			],
		];
	}

	/**
	 * Update quiz entry note.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function update_quiz_entry_note( $request ) {
		$quiz_id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$notes   = $request->get_param( 'notes' );

		if ( empty( $quiz_id ) ) {
			return new WP_Error( 'invalid_quiz_id', __( 'Invalid quiz ID.', 'sureforms-pro' ) );
		}

		$entry        = Quiz::get( absint( $quiz_id ) );
		$notes_list   = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$note_content = is_string( $notes ) ? sanitize_textarea_field( $notes ) : '';
		if ( '' !== $note_content ) {
			$current_user = wp_get_current_user();
			$timestamp    = time();
			array_unshift(
				$notes_list,
				[
					'id'          => $this->generate_note_id(),
					'note'        => $note_content,
					'timestamp'   => $timestamp,
					'author'      => $current_user->ID,
					'author_name' => $current_user->display_name,
				]
			);
		}

		$updated = Quiz::update(
			absint( $quiz_id ),
			[
				'notes' => $notes_list,
			]
		);

		if ( false === $updated ) {
			return new WP_Error( 'quiz_note_update_failed', __( 'Failed to update quiz entry note.', 'sureforms-pro' ) );
		}

		$entry     = Quiz::get( absint( $quiz_id ) );
		$formatted = $this->format_quiz_entries( [ $entry ] );

		return [
			'entry' => $formatted[0] ?? [],
		];
	}

	/**
	 * Get quiz entry notes with pagination support.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_quiz_entry_notes( $request ) {
		$quiz_id  = absint( $request->get_param( 'id' ) );
		$per_page = $this->sanitize_per_page( $request->get_param( 'per_page' ) );
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );

		if ( empty( $quiz_id ) ) {
			return new WP_Error( 'invalid_quiz_id', __( 'Invalid quiz ID.', 'sureforms-pro' ) );
		}

		$entry = Quiz::get( $quiz_id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'quiz_not_found', __( 'Quiz entry not found.', 'sureforms-pro' ) );
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		usort(
			$notes,
			static function( $a, $b ) {
				return ( $b['timestamp'] ?? 0 ) - ( $a['timestamp'] ?? 0 );
			}
		);

		$total_notes = count( $notes );
		$total_pages = ceil( $total_notes / $per_page );
		$offset      = ( $page - 1 ) * $per_page;

		$paginated_notes = array_slice( Helper::get_array_value( $notes ), $offset, $per_page );
		$formatted_notes = [];
		foreach ( $paginated_notes as $note_index => $note ) {
			if ( ! is_array( $note ) ) {
				continue;
			}
			$legacy_index      = $offset + $note_index;
			$formatted_notes[] = [
				'id'          => $note['id'] ?? 'legacy-note-' . $legacy_index,
				'note'        => $note['note'] ?? '',
				'timestamp'   => $note['timestamp'] ?? 0,
				'author'      => $note['author'] ?? 0,
				'author_name' => $note['author_name'] ?? __( 'Unknown', 'sureforms-pro' ),
			];
		}

		return [
			'notes'        => $formatted_notes,
			'current_page' => $page,
			'per_page'     => $per_page,
			'total'        => $total_notes,
			'total_pages'  => $total_pages,
		];
	}

	/**
	 * Add a new note to a quiz entry.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function add_quiz_entry_note( $request ) {
		$quiz_id = absint( $request->get_param( 'id' ) );
		$content = sanitize_textarea_field( Helper::get_string_value( $request->get_param( 'note' ) ) );

		if ( empty( $quiz_id ) ) {
			return new WP_Error( 'invalid_quiz_id', __( 'Invalid quiz ID.', 'sureforms-pro' ) );
		}

		if ( empty( $content ) ) {
			return new WP_Error( 'invalid_quiz_note', __( 'Note content is required.', 'sureforms-pro' ) );
		}

		$entry = Quiz::get( $quiz_id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'quiz_not_found', __( 'Quiz entry not found.', 'sureforms-pro' ) );
		}

		$notes        = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$current_user = wp_get_current_user();
		$timestamp    = time();

		$new_note = [
			'id'          => $this->generate_note_id(),
			'note'        => $content,
			'timestamp'   => $timestamp,
			'author'      => $current_user->ID,
			'author_name' => $current_user->display_name,
		];

		array_unshift( $notes, $new_note );

		$updated = Quiz::update(
			$quiz_id,
			[
				'notes' => $notes,
			]
		);

		if ( false === $updated ) {
			return new WP_Error( 'quiz_note_update_failed', __( 'Failed to add quiz note.', 'sureforms-pro' ) );
		}

		return [
			'success' => true,
		];
	}

	/**
	 * Delete a specific quiz entry note.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function delete_quiz_entry_note( $request ) {
		$quiz_id = absint( $request->get_param( 'id' ) );
		$note_id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'note_id' ) ) );

		if ( empty( $quiz_id ) || empty( $note_id ) ) {
			return new WP_Error( 'invalid_quiz_note', __( 'Quiz ID and Note ID are required.', 'sureforms-pro' ) );
		}

		$entry = Quiz::get( $quiz_id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'quiz_not_found', __( 'Quiz entry not found.', 'sureforms-pro' ) );
		}

		$notes      = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$note_found = false;

		foreach ( $notes as $index => $note ) {
			if ( isset( $note['id'] ) && Helper::get_string_value( $note['id'] ) === Helper::get_string_value( $note_id ) ) {
				array_splice( $notes, $index, 1 );
				$note_found = true;
				break;
			}
		}

		if ( ! $note_found ) {
			return new WP_Error( 'quiz_note_not_found', __( 'Note not found.', 'sureforms-pro' ) );
		}

		$updated = Quiz::update(
			$quiz_id,
			[
				'notes' => $notes,
			]
		);

		if ( false === $updated ) {
			return new WP_Error( 'quiz_note_delete_failed', __( 'Failed to delete quiz note.', 'sureforms-pro' ) );
		}

		return [
			'success' => true,
		];
	}

	/**
	 * Get quiz entries list.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_quiz_entries_list( WP_REST_Request $request ) {
		$args = [
			'form_id'   => absint( $request->get_param( 'form_id' ) ),
			'search'    => Helper::get_string_value( $request->get_param( 'search' ) ),
			'date_from' => Helper::get_string_value( $request->get_param( 'date_from' ) ),
			'date_to'   => Helper::get_string_value( $request->get_param( 'date_to' ) ),
			'orderby'   => $this->sanitize_orderby( $request->get_param( 'orderby' ) ),
			'order'     => $this->sanitize_order( $request->get_param( 'order' ) ),
			'per_page'  => $this->sanitize_per_page( $request->get_param( 'per_page' ) ),
			'page'      => max( 1, absint( $request->get_param( 'page' ) ) ),
		];

		$where_conditions = $this->build_where_conditions( $args );
		$total            = Quiz::get_instance()->get_total_count( $where_conditions );
		$offset           = ( $args['page'] - 1 ) * $args['per_page'];

		$entries = Quiz::get_instance()->get_records_by_args(
			[
				'where'   => $where_conditions,
				'columns' => '*',
				'orderby' => $args['orderby'],
				'order'   => $args['order'],
				'limit'   => $args['per_page'],
				'offset'  => $offset,
			]
		);

		$entries = is_array( $entries ) ? $entries : [];
		$entries = $this->format_quiz_entries( $entries );

		return [
			'entries'      => $entries,
			'total'        => $total,
			'per_page'     => $args['per_page'],
			'current_page' => $args['page'],
			'total_pages'  => $args['per_page'] ? (int) ceil( $total / $args['per_page'] ) : 1,
		];
	}

	/**
	 * Delete quiz entries.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.6.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function delete_quiz_entries( WP_REST_Request $request ) {
		$quiz_ids = $request->get_param( 'quiz_ids' );

		if ( ! is_array( $quiz_ids ) || empty( $quiz_ids ) ) {
			return new WP_Error(
				'srfm_quiz_entries_invalid_ids',
				__( 'No quiz IDs provided.', 'sureforms-pro' ),
				[ 'status' => 400 ]
			);
		}

		$deleted = 0;
		$errors  = [];

		foreach ( $quiz_ids as $quiz_id ) {
			$result = Quiz::delete( $quiz_id );
			if ( false === $result ) {
				$errors[] = sprintf(
					/* translators: %s: quiz entry ID */
					__( 'Failed to delete quiz entry %s.', 'sureforms-pro' ),
					esc_html( $quiz_id )
				);
				continue;
			}
			$deleted++;
		}

		return [
			'success' => $deleted > 0 && empty( $errors ),
			'deleted' => $deleted,
			'errors'  => $errors,
		];
	}

	/**
	 * Sanitize quiz IDs.
	 *
	 * @param mixed $ids Quiz IDs.
	 * @since 2.6.0
	 * @return array<int,string>
	 */
	public function sanitize_quiz_ids( $ids ) {
		if ( is_string( $ids ) ) {
			$decoded = json_decode( $ids, true );
			if ( json_last_error() === JSON_ERROR_NONE ) {
				$ids = $decoded;
			}
		}

		if ( ! is_array( $ids ) ) {
			return [];
		}

		$sanitized = [];
		foreach ( $ids as $id ) {
			$id = sanitize_text_field( $id );
			if ( '' !== $id ) {
				$sanitized[] = $id;
			}
		}

		return array_values( array_unique( $sanitized ) );
	}

	/**
	 * Sanitize per-page value with upper bound to prevent heavy queries.
	 *
	 * @param mixed $per_page Per-page value.
	 * @since 2.6.0
	 * @return int
	 */
	public function sanitize_per_page( $per_page ) {
		$per_page = absint( $per_page );
		if ( 0 === $per_page ) {
			$per_page = 10;
		}
		return min( self::MAX_PER_PAGE, max( 1, $per_page ) );
	}

	/**
	 * Sanitize order-by field against allowed columns.
	 *
	 * @param mixed $orderby Order-by field.
	 * @since 2.6.0
	 * @return string
	 */
	public function sanitize_orderby( $orderby ) {
		$orderby = sanitize_text_field( Helper::get_string_value( $orderby ) );
		return in_array( $orderby, self::ALLOWED_ORDERBY, true ) ? $orderby : 'created_at';
	}

	/**
	 * Sanitize sort order.
	 *
	 * @param mixed $order Sort order.
	 * @since 2.6.0
	 * @return string
	 */
	public function sanitize_order( $order ) {
		return 'ASC' === strtoupper( sanitize_text_field( Helper::get_string_value( $order ) ) ) ? 'ASC' : 'DESC';
	}

	/**
	 * Build where conditions for quiz entries list.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @since 2.6.0
	 * @return array<mixed>
	 */
	private function build_where_conditions( $args ) {
		$where = [];

		if ( ! empty( $args['form_id'] ) ) {
			$where['form_id'] = absint( $args['form_id'] );
		}

		$advanced = [];

		if ( ! empty( $args['search'] ) && is_numeric( $args['search'] ) ) {
			$advanced[] = [
				'key'     => 'id',
				'compare' => '=',
				'value'   => absint( $args['search'] ),
			];
		}

		if ( ! empty( $args['date_from'] ) ) {
			$advanced[] = [
				'key'     => 'created_at',
				'compare' => '>=',
				'value'   => $args['date_from'] . ' 00:00:00',
			];
		}

		if ( ! empty( $args['date_to'] ) ) {
			$advanced[] = [
				'key'     => 'created_at',
				'compare' => '<=',
				'value'   => $args['date_to'] . ' 23:59:59',
			];
		}

		if ( ! empty( $advanced ) ) {
			$where[] = $advanced;
		}

		return $where;
	}

	/**
	 * Format quiz entries for API response.
	 *
	 * @param array<int,array<string,mixed>> $entries Quiz entries.
	 * @since 2.6.0
	 * @return array<int,array<string,mixed>>
	 */
	private function format_quiz_entries( $entries ) {
		$form_titles = [];

		return array_map(
			function ( $entry ) use ( &$form_titles ) {
				$form_id = absint( $entry['form_id'] ?? 0 );
				if ( $form_id && ! isset( $form_titles[ $form_id ] ) ) {
					// Raw title — avoids the_title's wptexturize altering punctuation.
					$form_titles[ $form_id ] = (string) get_post_field( 'post_title', $form_id, 'raw' );
				}

					$raw_result = $entry['quiz_result'] ?? [];
					$raw_data   = $entry['quiz_data'] ?? [];

					$quiz_result = $this->normalize_quiz_payload( $raw_result );
					$quiz_data   = $this->normalize_quiz_payload( $raw_data );

					// Backfill question results for older records where quiz_result did not store per-question data.
				if ( empty( $quiz_result['question_results'] ) || ! is_array( $quiz_result['question_results'] ) ) {
					$quiz_result['question_results'] = $this->build_question_results_from_quiz_data( $quiz_data );
				}

				return [
					'id'          => absint( $entry['id'] ?? 0 ),
					'form_id'     => $form_id,
					'form_title'  => Helper::get_string_value( $form_titles[ $form_id ] ?? '' ),
					'form_url'    => $form_id ? get_permalink( $form_id ) : '',
					'score'       => Helper::get_string_value( $quiz_result['score'] ?? '' ),
					'max_score'   => Helper::get_string_value( $quiz_result['max_score'] ?? '' ),
					'percentage'  => Helper::get_string_value( $quiz_result['percentage'] ?? '' ),
					'notes'       => Helper::get_array_value( $entry['notes'] ?? [] ),
					'created_at'  => Helper::get_string_value( $entry['created_at'] ?? '' ),
					'updated_at'  => Helper::get_string_value( $entry['updated_at'] ?? '' ),
					'quiz_result' => $quiz_result,
					'quiz_data'   => $quiz_data,
				];
			},
			$entries
		);
	}

	/**
	 * Normalize quiz payload values coming from DB.
	 *
	 * Handles legacy/double-encoded formats such as:
	 * - JSON string object.
	 * - Array with a single JSON string at index 0.
	 * - Object-like array with key "0" holding JSON string.
	 *
	 * @param mixed $value Raw payload value.
	 * @since 2.6.0
	 * @return array<string,mixed>
	 */
	private function normalize_quiz_payload( $value ) {
		$payload = [];

		if ( is_array( $value ) ) {
			$payload = $value;
		} elseif ( is_string( $value ) ) {
			$decoded = json_decode( $value, true );
			$payload = is_array( $decoded ) ? $decoded : [];
		}

		for ( $i = 0; $i < 2; $i++ ) {
			if ( isset( $payload[0] ) && is_string( $payload[0] ) ) {
				$decoded = json_decode( $payload[0], true );
				if ( is_array( $decoded ) ) {
					$payload = $decoded;
					continue;
				}
			}

			if ( isset( $payload['0'] ) && is_string( $payload['0'] ) ) {
				$decoded = json_decode( $payload['0'], true );
				if ( is_array( $decoded ) ) {
					$payload = $decoded;
					continue;
				}
			}

			break;
		}

		return is_array( $payload ) ? $payload : [];
	}

	/**
	 * Build fallback question result rows from quiz_data when per-question result is missing.
	 *
	 * @param array<string,mixed> $quiz_data Quiz data payload.
	 * @since 2.6.0
	 * @return array<int,array<string,mixed>>
	 */
	private function build_question_results_from_quiz_data( $quiz_data ) {
		if ( empty( $quiz_data ) || ! is_array( $quiz_data ) ) {
			return [];
		}

		$rows      = [];
		$skip_keys = [
			'_entry_id',
			'_form_id',
			'form-id',
			'form_id',
			'submission_id',
			'sureforms_form_submit',
		];

		foreach ( $quiz_data as $key => $value ) {
			$key_string = is_scalar( $key ) ? (string) $key : '';
			if ( '' === $key_string || in_array( $key_string, $skip_keys, true ) ) {
				continue;
			}

			$submitted = '';
			if ( is_array( $value ) ) {
				$submitted = implode(
					' | ',
					array_filter(
						array_map(
							static function ( $item ) {
								return is_scalar( $item ) ? (string) $item : '';
							},
							$value
						),
						static function ( $item ) {
							return '' !== trim( (string) $item );
						}
					)
				);
			} elseif ( is_scalar( $value ) ) {
				$submitted = (string) $value;
			}

			$submitted = trim( $submitted );
			if ( '' === $submitted ) {
				continue;
			}

			$label  = $this->extract_label_from_quiz_key( $key_string );
			$rows[] = [
				'label'     => $label,
				'submitted' => $submitted,
				'correct'   => '',
				'options'   => [],
			];
		}

		return $rows;
	}

	/**
	 * Extract a human-readable label from a submitted quiz field key.
	 *
	 * @param string $key Raw submission key.
	 * @since 2.6.0
	 * @return string
	 */
	private function extract_label_from_quiz_key( $key ) {
		if ( false === strpos( $key, '-lbl-' ) ) {
			return $key;
		}

		$label_part = explode( '-lbl-', $key, 2 )[1] ?? $key;
		if ( '' === $label_part ) {
			return $key;
		}

		$encoded = explode( '-', $label_part, 2 )[0] ?? '';
		if ( '' !== $encoded ) {
			$base64_url = strtr( $encoded, '-_', '+/' );
			$padding    = strlen( $base64_url ) % 4;
			if ( 0 !== $padding ) {
				$base64_url .= str_repeat( '=', 4 - $padding );
			}
			$decoded = base64_decode( $base64_url, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding a base64url-encoded field label from a structured key, not obfuscating code.
			if ( false !== $decoded ) {
				$decoded = trim( wp_strip_all_tags( (string) $decoded ) );
				if ( '' !== $decoded ) {
					return $decoded;
				}
			}
		}

		$slug = explode( '-', $label_part, 2 )[1] ?? $label_part;
		$slug = trim( str_replace( '-', ' ', $slug ) );
		return '' !== $slug ? $slug : $key;
	}

	/**
	 * Generate unique note ID.
	 *
	 * @since 2.6.0
	 * @return string
	 */
	private function generate_note_id() {
		return function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'quiz-note-', true );
	}
}
