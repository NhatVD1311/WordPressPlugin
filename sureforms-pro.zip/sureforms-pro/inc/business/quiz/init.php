<?php
/**
 * Quiz - Init class
 *
 * @since 2.6.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Quiz;

use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize business package.
 *
 * @since 2.6.0
 */
class Init {
	use Get_Instance;

	/**
	 * Initialize Quiz module.
	 *
	 * @since 2.6.0
	 * @return void
	 */
	public function __construct() {
		Editor::get_instance();
		Score_Calculator::get_instance();
		Quiz_Entries::get_instance();
	}
}
