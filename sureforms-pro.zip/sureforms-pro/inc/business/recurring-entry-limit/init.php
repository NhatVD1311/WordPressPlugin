<?php
/**
 * Recurring Entry Limit - Business-tier feature.
 *
 * Layers daily / weekly / monthly / yearly windows on top of the free
 * plugin's Maximum Number of Entries cap. The cap value, toggle, and
 * "limit reached" message stay owned by the free plugin — this feature
 * only swaps the **count source** that the cap evaluates, from the
 * lifetime total to the count of entries since the start of the
 * configured window.
 *
 * Self-contained on the Pro side: stores the period in its own meta
 * (`_srfm_recurring_entry_limit`) and hooks into two narrowly-scoped
 * extension points exposed by the free plugin:
 *
 *   - `srfm_form_restriction_entries_count`  — PHP filter, swaps the count.
 *   - `srfm_form_restriction_max_entries_after` — JS filter, slots the dropdown.
 *
 * @since 2.8.3
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Recurring_Entry_Limit;

use DateTimeImmutable;
use Exception;
use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

defined( 'ABSPATH' ) || exit;

/**
 * Recurring Entry Limit init class.
 *
 * @since 2.8.3
 */
class Init {
	use Get_Instance;

	/**
	 * Allowed period values.
	 *
	 * `total` keeps the lifetime cap (free plugin's existing behaviour).
	 * The other four switch the count to a window since the start of the
	 * current day / week / month / year in the WordPress site timezone.
	 *
	 * @since 2.8.3
	 */
	private const ALLOWED_PERIODS = [ 'total', 'day', 'week', 'month', 'year' ];

	/**
	 * Constructor.
	 *
	 * @since 2.8.3
	 */
	public function __construct() {
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_meta' ] );
		// Accept all three args the free plugin passes (count, form_id,
		// form_restriction) so future logic can react to the parsed
		// restriction array (e.g. early-return when maxEntries is 0)
		// without another signature bump.
		add_filter( 'srfm_form_restriction_entries_count', [ $this, 'filter_entries_count' ], 10, 3 );
	}

	/**
	 * Register `_srfm_recurring_entry_limit` post meta on the SureForms form CPT.
	 *
	 * Stored as a JSON string with a single key (`period`) so the shape can
	 * grow later without forcing a migration. Default `total` keeps the
	 * lifetime cap behaviour intact for existing forms.
	 *
	 * @hooked srfm_register_additional_post_meta
	 * @since 2.8.3
	 * @return void
	 */
	public function register_meta() {
		$default = [ 'period' => 'total' ];

		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_recurring_entry_limit',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'sanitize_callback' => [ $this, 'sanitize_meta' ],
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
				'default'           => wp_json_encode( $default ),
			]
		);
	}

	/**
	 * Sanitize the JSON-encoded meta value before persisting.
	 *
	 * @since 2.8.3
	 * @param mixed $meta_value Raw meta value (expected JSON string).
	 * @return string Sanitized JSON string.
	 */
	public function sanitize_meta( $meta_value ) {
		if ( ! is_string( $meta_value ) || '' === $meta_value ) {
			$result = wp_json_encode( [ 'period' => 'total' ] );
			return false !== $result ? $result : '{"period":"total"}';
		}

		$data = json_decode( $meta_value, true );
		if ( ! is_array( $data ) ) {
			$result = wp_json_encode( [ 'period' => 'total' ] );
			return false !== $result ? $result : '{"period":"total"}';
		}

		$period = isset( $data['period'] ) && is_string( $data['period'] ) && in_array( $data['period'], self::ALLOWED_PERIODS, true )
			? $data['period']
			: 'total';

		$encoded = wp_json_encode( [ 'period' => $period ] );
		return false !== $encoded ? $encoded : '{"period":"total"}';
	}

	/**
	 * Replace the lifetime entry count with a window-scoped count when the
	 * form has a recurring period configured.
	 *
	 * Hooks into the `srfm_form_restriction_entries_count` filter that the
	 * free plugin invokes from `Form_Restriction::has_entries_limit_reached()`.
	 * Returning a smaller number defers the cap; returning a larger one
	 * trips it sooner. We always return the count of entries created since
	 * the start of the configured period, in `wp_timezone()`.
	 *
	 * @hooked srfm_form_restriction_entries_count
	 * @since 2.8.3
	 * @param int                  $entries_count    Lifetime count from the free plugin.
	 * @param int                  $form_id          Form post ID.
	 * @param array<string, mixed> $form_restriction Parsed `_srfm_form_restriction` settings (unused today; accepted for forward-compat).
	 * @return int
	 */
	public function filter_entries_count( $entries_count, $form_id, $form_restriction = [] ) {
		unset( $form_restriction );

		$form_id = Helper::get_integer_value( $form_id );
		if ( $form_id <= 0 ) {
			return Helper::get_integer_value( $entries_count );
		}

		$period = $this->get_period( $form_id );
		if ( 'total' === $period ) {
			// No recurring window — keep the lifetime count as-is.
			return Helper::get_integer_value( $entries_count );
		}

		$start_ts = $this->get_period_start_timestamp( $period );
		if ( null === $start_ts ) {
			return Helper::get_integer_value( $entries_count );
		}

		return $this->count_entries_since( $start_ts, $form_id );
	}

	/**
	 * Compute the inclusive start of the current period as a Unix timestamp,
	 * in the WordPress site timezone.
	 *
	 * Public to make the boundary math directly testable in PHPUnit. Returns
	 * null for `total` and any other unrecognised period — the caller should
	 * treat null as "no window override, fall back to lifetime".
	 *
	 * @since 2.8.3
	 * @param string $period One of: total, day, week, month, year.
	 * @return int|null
	 */
	public function get_period_start_timestamp( $period ) {
		if ( ! in_array( $period, self::ALLOWED_PERIODS, true ) ) {
			return null;
		}
		if ( 'total' === $period ) {
			return null;
		}

		try {
			$tz  = wp_timezone();
			$now = new DateTimeImmutable( 'now', $tz );
		} catch ( Exception $e ) {
			return null;
		}

		switch ( $period ) {
			case 'day':
				return $now->setTime( 0, 0, 0 )->getTimestamp();

			case 'week':
				// Respect the WordPress `start_of_week` option (0 = Sunday … 6 = Saturday).
				$start_of_week = Helper::get_integer_value( get_option( 'start_of_week', 0 ) );
				$today_dow     = (int) $now->format( 'w' );
				$delta         = ( $today_dow - $start_of_week + 7 ) % 7;
				return $now->modify( "-{$delta} days" )->setTime( 0, 0, 0 )->getTimestamp();

			case 'month':
				return $now->modify( 'first day of this month' )->setTime( 0, 0, 0 )->getTimestamp();

			default:
				// 'year' is the only ALLOWED_PERIODS value left after the cases
				// above; the in_array() guard at the top of the method keeps
				// any other input from reaching the switch.
				return $now->setDate( (int) $now->format( 'Y' ), 1, 1 )->setTime( 0, 0, 0 )->getTimestamp();
		}
	}

	/**
	 * Read the configured period for a form, or `total` if unconfigured.
	 *
	 * @since 2.8.3
	 * @param int $form_id Form post ID.
	 * @return string One of self::ALLOWED_PERIODS.
	 */
	public function get_period( $form_id ) {
		$raw = get_post_meta( Helper::get_integer_value( $form_id ), '_srfm_recurring_entry_limit', true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return 'total';
		}

		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return 'total';
		}

		$period = $decoded['period'] ?? 'total';
		return is_string( $period ) && in_array( $period, self::ALLOWED_PERIODS, true ) ? $period : 'total';
	}

	/**
	 * Count non-trashed entries for a form whose `created_at` falls on or
	 * after the given UTC Unix timestamp.
	 *
	 * Uses `created_at >= FROM_UNIXTIME(%d)` so the existing composite
	 * index `idx_form_id_created_at_status (form_id, created_at, status)`
	 * is sargable — `FROM_UNIXTIME()` of a constant placeholder is folded
	 * by MySQL into a single value, leaving the column un-wrapped on the
	 * left-hand side. Both sides resolve in MySQL's session timezone,
	 * which is the same timezone the column is read/written under, so
	 * the comparison is correct regardless of host timezone configuration.
	 *
	 * Intentionally uncached — the gate runs on every render and submit,
	 * and a stale cached count lets submissions slip past the cap until
	 * the cache expires. The query is a single indexed COUNT, cheap
	 * enough at any plausible form throughput.
	 *
	 * @since 2.8.3
	 * @param int $start_ts UTC Unix timestamp; entries with created_at at or after this point count.
	 * @param int $form_id  Form post ID.
	 * @return int
	 */
	private function count_entries_since( $start_ts, $form_id ) {
		global $wpdb;

		$start_ts = Helper::get_integer_value( $start_ts );
		$form_id  = Helper::get_integer_value( $form_id );

		if ( $start_ts <= 0 || $form_id <= 0 ) {
			return 0;
		}

		// Entries::get_tablename() is a public method on a project-owned
		// singleton (free's Database\Tables\Entries) — assume it succeeds.
		$table = Entries::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cap-evaluation read; caching here would defer count updates and let submissions slip past the cap within the cache window.
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE form_id = %d AND status <> 'trash' AND created_at >= FROM_UNIXTIME( %d )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table comes from Entries::get_tablename(); not user input.
				$form_id,
				$start_ts
			)
		);
	}
}
