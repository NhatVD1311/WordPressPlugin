<?php
/**
 * Dynamic Options main class file.
 *
 * @since 2.5.1
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Dynamic_Options;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize Dynamic Options feature.
 *
 * @since 2.5.1
 */
class Init {
	use Get_Instance;

	/**
	 * Constructor
	 *
	 * @since 2.5.1
	 */
	public function __construct() {
		// Register REST API endpoints.
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_endpoints' ] );

		// Filter options for dynamic options on frontend.
		add_filter( 'srfm_field_options', [ $this, 'filter_dynamic_options' ], 10, 2 );

		// Skip rendering block when dynamic options are empty.
		add_filter( 'srfm_block_field_markup', [ $this, 'skip_empty_dynamic_block' ], 10, 2 );

		// Enqueue editor scripts.
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_scripts' ] );
	}

	/**
	 * Register REST API endpoints.
	 *
	 * @param array<string,array<string,mixed>> $endpoints Existing endpoints.
	 * @return array<string,array<string,mixed>> Modified endpoints.
	 * @since 2.5.1
	 */
	public function register_endpoints( $endpoints ) {
		return array_merge(
			$endpoints,
			[
				'dynamic-options/sources' => [
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_sources' ],
					'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
					'args'                => [
						'source_type' => [
							'required'          => true,
							'type'              => 'string',
							'enum'              => [ 'post_type', 'taxonomy', 'user_role' ],
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
				'dynamic-options/items'   => [
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_source_items' ],
					'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
					'args'                => [
						'source_type' => [
							'required'          => true,
							'type'              => 'string',
							'enum'              => [ 'post_type', 'taxonomy', 'user_role' ],
							'sanitize_callback' => 'sanitize_text_field',
						],
						'source'      => [
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
			]
		);
	}

	/**
	 * REST API callback to get available sources.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 * @since 2.5.1
	 */
	public function get_sources( $request ) {
		$nonce = sanitize_text_field( Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) ) );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Invalid security token. Please refresh the page and try again.', 'sureforms-pro' ),
				],
				403
			);
		}

		$source_type = sanitize_text_field( Helper::get_string_value( $request->get_param( 'source_type' ) ) );
		return rest_ensure_response( Utils::get_available_sources( $source_type ) );
	}

	/**
	 * REST API callback to get items from a source.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 * @since 2.5.1
	 */
	public function get_source_items( $request ) {
		$nonce = sanitize_text_field( Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) ) );

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Invalid security token. Please refresh the page and try again.', 'sureforms-pro' ),
				],
				403
			);
		}

		$source_type = sanitize_text_field( Helper::get_string_value( $request->get_param( 'source_type' ) ) );
		$source      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'source' ) ) );
		return rest_ensure_response( Utils::get_source_items( $source_type, $source ) );
	}

	/**
	 * Filter options to replace static options with dynamic ones.
	 *
	 * @param array|string        $options    Field options from attributes.
	 * @param array<string,mixed> $attributes Block attributes.
	 * @return array|string Modified options.
	 * @since 2.5.1
	 */
	public function filter_dynamic_options( $options, $attributes ) {
		// Use the block type slug from block_args (injected by the core Base class) for block-type
		// identification. The field's `slug` attribute can be prefixed when the block is inside a
		// repeater (e.g. 'srfm-repeater-srfm-dropdown'), making it unreliable for type checking.
		$block_args      = Helper::get_array_value( $attributes['block_args'] ?? [] );
		$block_args_slug = Helper::get_string_value( $block_args['slug'] ?? '' );
		$slug            = '' !== $block_args_slug ? $block_args_slug : Helper::get_string_value( $attributes['slug'] ?? '' );

		// Only process dropdown and multi-choice blocks.
		if ( ! in_array( $slug, [ 'dropdown', 'multi-choice' ], true ) ) {
			return $options;
		}

		// Only process if dynamic source is enabled.
		if ( empty( $attributes['optionsSource'] ) || 'dynamic' !== $attributes['optionsSource'] ) {
			return $options;
		}

		// Get dynamic options.
		$dynamic_options = $this->get_dynamic_options( $attributes );

		if ( empty( $dynamic_options ) ) {
			return $options;
		}

		return $dynamic_options;
	}

	/**
	 * Skip rendering block when dynamic options are empty.
	 *
	 * @param string              $markup  Block markup.
	 * @param array<string,mixed> $context Block context including slug and attributes.
	 * @return string Modified markup or empty string.
	 * @since 2.5.1
	 */
	public function skip_empty_dynamic_block( $markup, $context ) {
		$slug       = Helper::get_string_value( $context['slug'] ?? '' );
		$attributes = Helper::get_array_value( $context['attributes'] ?? [] );

		// Only process dropdown and multi-choice blocks.
		if ( ! in_array( $slug, [ 'dropdown', 'multi-choice' ], true ) ) {
			return $markup;
		}

		// Only process if dynamic source is enabled.
		$options_source = Helper::get_string_value( $attributes['optionsSource'] ?? '' );
		if ( empty( $options_source ) || 'dynamic' !== $options_source ) {
			return $markup;
		}

		// Check if the block has a dynamic source configured.
		$source_type = Helper::get_string_value( $attributes['dynamicSourceType'] ?? '' );
		$source      = Helper::get_string_value( $attributes['dynamicSource'] ?? '' );

		if ( empty( $source_type ) || empty( $source ) ) {
			return $markup;
		}

		// Get dynamic options and check if empty.
		$result = Utils::get_source_items( $source_type, $source );

		if ( empty( $result['items'] ) ) {
			return '';
		}

		return $markup;
	}

	/**
	 * Enqueue editor scripts.
	 *
	 * @since 2.5.1
	 * @return void
	 */
	public function enqueue_editor_scripts() {
		$script = [
			'unique_file'        => 'srfmDynamicOptions',
			'unique_handle'      => 'srfm-dynamic-options',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		// Scripts.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'],
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep,
			$script_dep_data['version'],
			true
		);

		// Register script translations.
		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Get dynamic options based on source type.
	 *
	 * @param array<string,mixed> $attributes Block attributes.
	 * @return array<int,array<string,string>> Dynamic options.
	 * @since 2.5.1
	 */
	private function get_dynamic_options( $attributes ) {
		$source_type = Helper::get_string_value( $attributes['dynamicSourceType'] ?? '' );
		$source      = Helper::get_string_value( $attributes['dynamicSource'] ?? '' );

		if ( empty( $source_type ) || empty( $source ) ) {
			return [];
		}

		$result = Utils::get_source_items( $source_type, $source );
		$items  = is_array( $result['items'] ) ? $result['items'] : [];

		// Add multi-choice compatibility fields.
		$options = [];
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$options[] = [
				'label'       => Helper::get_string_value( $item['label'] ?? '' ),
				'value'       => Helper::get_string_value( $item['value'] ?? '' ),
				'optionTitle' => Helper::get_string_value( $item['label'] ?? '' ), // For multi-choice block compatibility as it uses optionTitle.
			];
		}

		return $options;
	}
}
