<?php
/**
 * Dynamic Options Utils
 *
 * This class handles all the utility functions related to the Dynamic Options module.
 *
 * @since 2.5.1
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business\Dynamic_Options;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Dynamic Options Utils
 *
 * @since 2.5.1
 */
class Utils {
	/**
	 * Cache for source items to avoid duplicate queries within the same request.
	 *
	 * @var array<string,array<string,mixed>>
	 * @since 2.5.1
	 */
	private static $items_cache = [];

	/**
	 * Get available sources based on source type.
	 *
	 * @param string $source_type Source type (post_type, taxonomy, or user_role).
	 * @return array<array<string,string>> Array of sources with value and label.
	 * @since 2.5.1
	 */
	public static function get_available_sources( $source_type ) {
		$sources = [];

		switch ( $source_type ) {
			case 'post_type':
				$post_types = get_post_types( [ 'public' => true ], 'objects' );
				foreach ( $post_types as $post_type ) {
					// Exclude attachments.
					if ( 'attachment' === $post_type->name ) {
						continue;
					}
					$sources[] = [
						'value' => $post_type->name,
						'label' => $post_type->labels->name,
					];
				}
				break;

			case 'taxonomy':
				$taxonomies = get_taxonomies( [ 'public' => true ], 'objects' );
				foreach ( $taxonomies as $taxonomy ) {
					// Exclude post formats.
					if ( 'post_format' === $taxonomy->name ) {
						continue;
					}
					$sources[] = [
						'value' => $taxonomy->name,
						'label' => $taxonomy->labels->name,
					];
				}
				break;

			case 'user_role':
				$sources[] = [
					'value' => 'all',
					'label' => __( 'All', 'sureforms-pro' ),
				];
				$roles     = wp_roles()->roles;
				foreach ( $roles as $role_slug => $role_data ) {
					$sources[] = [
						'value' => $role_slug,
						'label' => translate_user_role( $role_data['name'] ),
					];
				}
				break;
		}

		return $sources;
	}

	/**
	 * Get items from a specific source.
	 *
	 * @param string $source_type Source type (post_type, taxonomy, or user_role).
	 * @param string $source      Source slug.
	 * @return array<string,mixed> Array with items and total count.
	 * @since 2.5.1
	 */
	public static function get_source_items( $source_type, $source ) {
		$cache_key = "{$source_type}_{$source}";

		// Return cached result if available.
		if ( isset( self::$items_cache[ $cache_key ] ) ) {
			return self::$items_cache[ $cache_key ];
		}

		$result = [
			'items' => [],
			'total' => 0,
		];

		switch ( $source_type ) {
			case 'post_type':
				$result = self::get_post_type_items( $source );
				break;

			case 'taxonomy':
				$result = self::get_taxonomy_items( $source );
				break;

			case 'user_role':
				$result = self::get_user_role_items( $source );
				break;
		}

		// Cache the result.
		self::$items_cache[ $cache_key ] = $result;

		return $result;
	}

	/**
	 * Get items from a post type.
	 *
	 * @param string $post_type Post type slug.
	 * @return array<string,mixed> Items and total count.
	 * @since 2.5.1
	 */
	private static function get_post_type_items( $post_type ) {
		/**
		 * Filter the maximum number of posts to fetch for dynamic options.
		 *
		 * @param int    $limit     The maximum number of posts. Default 500.
		 * @param string $post_type The post type being queried.
		 * @since 2.5.1
		 */
		$posts_per_page = apply_filters( 'srfm_pro_dynamic_options_posts_limit', 500, $post_type );
		$posts_per_page = is_numeric( $posts_per_page ) ? (int) $posts_per_page : 500;

		$query = new \WP_Query(
			[
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => $posts_per_page,
				'orderby'        => 'ID',
				'order'          => 'DESC',
			]
		);

		$items = [];

		foreach ( $query->posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$label = $post->post_title;
			if ( empty( trim( $label ) ) ) {
				/* translators: %d: Post ID */
				$label = sprintf( __( '#%d (no title)', 'sureforms-pro' ), $post->ID );
			}
			$items[] = [
				'label' => $label,
				'value' => (string) $post->ID,
			];
		}

		return [
			'items' => $items,
			'total' => $query->found_posts,
		];
	}

	/**
	 * Get items from a taxonomy.
	 *
	 * @param string $taxonomy Taxonomy slug.
	 * @return array<string,mixed> Items and total count.
	 * @since 2.5.1
	 */
	private static function get_taxonomy_items( $taxonomy ) {
		/**
		 * Filter the maximum number of terms to fetch for dynamic options.
		 *
		 * @param int    $limit    The maximum number of terms. Default 500.
		 * @param string $taxonomy The taxonomy being queried.
		 * @since 2.5.1
		 */
		$terms_limit = apply_filters( 'srfm_pro_dynamic_options_terms_limit', 500, $taxonomy );
		$terms_limit = is_numeric( $terms_limit ) ? (int) $terms_limit : 500;

		$terms = get_terms(
			[
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
				'number'     => $terms_limit,
			]
		);

		if ( is_wp_error( $terms ) ) {
			return [
				'items' => [],
				'total' => 0,
			];
		}

		$items       = [];
		$terms_count = count( $terms );

		foreach ( $terms as $term ) {
			$label = $term->name;
			if ( empty( trim( $label ) ) ) {
				/* translators: %d: Term ID */
				$label = sprintf( __( '#%d (no title)', 'sureforms-pro' ), $term->term_id );
			}
			$items[] = [
				'label' => $label,
				'value' => (string) $term->term_id,
			];
		}

		return [
			'items' => $items,
			'total' => $terms_count,
		];
	}

	/**
	 * Get items from a user role.
	 *
	 * @param string $role Role slug.
	 * @return array<string,mixed> Items and total count.
	 * @since 2.6.0
	 */
	private static function get_user_role_items( $role ) {
		/**
		 * Filter the maximum number of users to fetch for dynamic options.
		 *
		 * @param int    $limit The maximum number of users. Default 500.
		 * @param string $role  The user role being queried.
		 * @since 2.6.0
		 */
		$users_limit = apply_filters( 'srfm_pro_dynamic_options_users_limit', 500, $role );
		$users_limit = is_numeric( $users_limit ) ? (int) $users_limit : 500;

		$args = [
			'number'      => $users_limit,
			'orderby'     => 'display_name',
			'order'       => 'ASC',
			'fields'      => [ 'ID', 'display_name', 'user_login', 'user_nicename' ],
			'count_total' => true,
		];

		if ( 'all' !== $role ) {
			if ( ! wp_roles()->is_role( $role ) ) {
				return [
					'items' => [],
					'total' => 0,
				];
			}
			$args['role'] = $role;
		}

		$user_query = new \WP_User_Query( $args );
		$users      = $user_query->get_results();

		$items = [];
		foreach ( $users as $user ) {
			$label = $user->display_name;
			if ( empty( trim( $label ) ) ) {
				/* translators: %s: User login */
				$label = sprintf( __( '%s (no name)', 'sureforms-pro' ), $user->user_login );
			}
			$items[] = [
				'label' => $label,
				'value' => $user->user_nicename,
			];
		}

		return [
			'items' => $items,
			'total' => $user_query->get_total(),
		];
	}
}
