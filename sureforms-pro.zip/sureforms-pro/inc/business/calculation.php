<?php
/**
 * Calculation main class file.
 *
 * @since 1.5.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Load Calculation feature related functionalities.
 *
 * @since 1.5.0
 */
class Calculation {
	use Get_Instance;

	/**
	 * Initialize Calculation.
	 *
	 * @since 1.5.0
	 */
	public function __construct() {
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_block_editor_scripts' ] );
		add_action( 'srfm_enqueue_block_scripts', [ $this, 'enqueue_calculation_scripts' ] );

		// Add calculation class and required config.
		add_filter( 'srfm_field_classes', [ $this, 'add_calculation_class' ], 10, 2 );
		add_filter( 'srfm_field_config', [ $this, 'add_calculation_config' ], 10, 2 );
		add_filter( 'srfm_register_post_meta', [ $this, 'register_submit_button_enable_meta' ] );
		add_filter( 'srfm_show_submit_button', [ $this, 'show_submit_button' ], 10, 2 );
		add_filter( 'render_block', [ $this, 'filter_block_content' ], 10, 2 );

		add_filter( 'srfm_show_options_values', [ $this, 'show_options_values' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
		add_filter( 'srfm_ai_form_generator_body', [ $this, 'add_calculation_form_version' ], 10, 2 );
		add_filter( 'srfm_ai_form_builder_modify_merged_attributes', [ $this, 'map_number_field_attrs' ], 10, 4 );
		add_filter( 'srfm_modify_ai_post_metas', [ $this, 'create_metas_for_ai' ], 10, 2 );
		add_filter( 'srfm_ai_field_modify_field_type', [ $this, 'field_modify_field_type' ], 10, 4 );
		add_filter( 'srfm_ai_field_map_skip_fields', [ $this, 'skip_fields_in_ai_builder' ], 10, 3 );
		add_filter( 'srfm_ai_form_builder_post_content', [ $this, 'modify_post_content' ], 10, 3 );

		// Recompute a calculation-driven payment amount server-side so the charged amount can be
		// validated against the formula result instead of a value submitted with the request.
		add_filter( 'srfm_server_side_variable_amount', [ $this, 'resolve_payment_amount' ], 10, 2 );
	}

	/**
	 * Recompute a variable payment amount server-side from a field's calculation formula.
	 *
	 * Hooked on `srfm_server_side_variable_amount` (fired by the core payment validator). Returns a
	 * numeric amount derived only from server-side configuration and other submitted field values —
	 * never the raw value of the amount field submitted with the request — or null when it cannot be
	 * computed (the core plugin then falls back to the configured minimum-amount floor).
	 *
	 * @param float|null           $amount  Amount resolved by an earlier handler, or null.
	 * @param array<string, mixed> $context Context: source_config, block_config, form_data.
	 * @since 2.11.1
	 * @return float|null Recomputed amount, or null when not computable.
	 */
	public function resolve_payment_amount( $amount, $context ) {
		// Respect a value already resolved by another handler.
		if ( null !== $amount ) {
			return $amount;
		}

		if ( ! is_array( $context ) ) {
			return null;
		}

		$source_config = isset( $context['source_config'] ) && is_array( $context['source_config'] ) ? $context['source_config'] : [];
		$block_config  = isset( $context['block_config'] ) && is_array( $context['block_config'] ) ? $context['block_config'] : [];
		$form_data     = isset( $context['form_data'] ) && is_array( $context['form_data'] ) ? $context['form_data'] : [];

		// Only handle calculation-driven sources here; static/default cases are resolved by core.
		if ( empty( $source_config['enableCalculation'] ) ) {
			return null;
		}

		$formula = isset( $source_config['calculationFormula'] ) && is_string( $source_config['calculationFormula'] ) ? $source_config['calculationFormula'] : '';
		if ( '' === $formula ) {
			return null;
		}

		$result = $this->evaluate_calculation_formula( $formula, $block_config, $form_data );
		if ( null === $result ) {
			return null;
		}

		// Round only when a rounding precision is actually configured, mirroring the front end
		// (which rounds only when calculationRound is set). Otherwise keep full precision so a
		// legitimate non-integer total (e.g. 29.97) is not silently rounded up and then rejected
		// as an amount mismatch.
		if ( isset( $source_config['calculationRound'] ) && is_numeric( $source_config['calculationRound'] ) ) {
			return round( $result, absint( $source_config['calculationRound'] ) );
		}

		return $result;
	}

	/**
	 * Modify post content for calculator form.
	 *
	 * @param string $post_content The post content.
	 * @param bool   $is_conversational The Conversational Form status.
	 * @param string $form_type The form type.
	 *
	 * @since 1.5.0
	 * @return string
	 */
	public function modify_post_content( $post_content, $is_conversational, $form_type ) {
		// Return the original content if the form is conversational or not a calculator form.
		if ( $is_conversational || 'calculator' !== $form_type ) {
			return $post_content;
		}

		// Extract all SRFM form fields from the post content.
		$form_fields = $this->extract_form_fields( $post_content );

		// Retrieve only the formulas from fields that have calculations enabled.
		$calculation_formulas = $this->get_calculation_formulas( $form_fields );

		// Retrieve slugs for fields that do not contain a calculation formula.
		$all_field_slugs = $this->get_all_field_slugs( $form_fields );

		// Determine which slugs are not used in any calculation formula.
		$unused_slugs = $this->get_unused_slugs( $all_field_slugs, $calculation_formulas );

		// Remove any unused fields from the post content.
		return $this->remove_unused_fields_from_content( $post_content, $unused_slugs );
	}

	/**
	 * Extracts SRFM form blocks and decodes their JSON attributes into arrays.
	 *
	 * @param string $post_content The post content.
	 * @return array<array<string,mixed>> An array of form fields.
	 */
	public function extract_form_fields( $post_content ) {
		// Use regex to find all SRFM form blocks in the post content.
		preg_match_all( '/<!-- wp:srfm\/[^ ]+ ({.*?}) \/-->/', $post_content, $matches );

		if ( empty( $matches[1] ) ) {
			return [];
		}

		return array_map(
			static function ( $json ) {
				$decoded = json_decode( $json, true );
				return is_array( $decoded ) ? $decoded : [];
			},
			$matches[1]
		);
	}

	/**
	 * Retrieves calculation formulas from form fields that have calculations enabled.
	 *
	 * @param array $form_fields The form fields.
	 *
	 * @since 1.5.0
	 * @return array<string> An array of calculation formulas.
	 */
	public function get_calculation_formulas( array $form_fields ) {
		return array_column(
			array_filter(
				$form_fields,
				static fn( $field ) => is_array( $field ) && ! empty( $field['enableCalculation'] )
			),
			'calculationFormula'
		);
	}

	/**
	 * Retrieves the slugs of fields that are have no calculation formula.
	 *
	 * @param array $form_fields The form fields.
	 *
	 * @since 1.5.0
	 * @return array An array of field slugs.
	 */
	public function get_all_field_slugs( array $form_fields ) {
		return array_column(
			array_filter(
				$form_fields,
				static fn( $field ) => is_array( $field ) && empty( $field['calculationFormula'] )
			),
			'slug'
		);
	}

	/**
	 * Filters field slugs to determine which ones are unused in any calculation formula.
	 *
	 * @param array $field_slugs The field slugs.
	 * @param array $formulas The calculation formulas.
	 *
	 * @since 1.5.0
	 * @return array<string> An array of unused field slugs.
	 */
	public function get_unused_slugs( array $field_slugs, array $formulas ) {
		return array_filter(
			$field_slugs,
			static function ( $slug ) use ( $formulas ) {
				if ( empty( $slug ) ) {
					return false;
				}

				// Return true only if the slug is not found in any formula.
				return ! array_reduce(
					$formulas,
					static fn( $found, $formula ) => $found || false !== strpos( $formula, '{form:' . Helper::get_string_value( $slug ) . '}' ),
					false
				);
			}
		);
	}

	/**
	 * Removes SRFM blocks from the content if their slugs are in the skip list.
	 *
	 * @param string $content The post content.
	 * @param array  $slugs_to_skip The slugs to skip.
	 *
	 * @since 1.5.0
	 * @return string The modified content.
	 */
	public function remove_unused_fields_from_content( $content, $slugs_to_skip ) {
		$result = preg_replace_callback(
			'/<!-- wp:srfm\/[^ ]+ ({.*?}) \/-->/',
			static function ( $matches ) use ( $slugs_to_skip ) {
				$decoded = json_decode( $matches[1], true );
				return is_array( $decoded ) && in_array( $decoded['slug'] ?? '', $slugs_to_skip, true ) ? '' : $matches[0];
			},
			$content
		);

		return $result ? $result : '';
	}

	/**
	 * Skip fields in AI builder from being added in the calculation form.
	 *
	 * @param array<string,mixed> $skip_fields The skip fields.
	 * @param bool                $is_conversational The Conversational Form status.
	 * @param string              $form_type The form type.
	 *
	 * @since 1.5.0
	 * @return array<string|mixed>
	 */
	public function skip_fields_in_ai_builder( $skip_fields, $is_conversational, $form_type ) {

		if ( $is_conversational || 'calculator' !== $form_type ) {
			return $skip_fields;
		}

		return [
			'checkbox',
			'gdpr',
			'input',
			'email',
			'url',
			'textarea',
			'checkbox',
			'gdpr',
			'phone',
			'dropdown',
			'address',
			'hidden',
			'rating',
			'upload',
			'date-picker',
			'time-picker',
			'page-break',
		];
	}

	/**
	 * Modify field type for Calculator Form.
	 * In case of dropdown field type, if the number of options is less than or equal to 6, then change the field type to multi-choice.
	 *
	 * @param string              $field_type The field type.
	 * @param array<string,mixed> $field_data The field data.
	 * @param bool                $is_conversational The Conversational Form status.
	 * @param string              $form_type The form type.
	 *
	 * @since 1.4.0
	 * @return string
	 */
	public function field_modify_field_type( $field_type, $field_data, $is_conversational, $form_type ) {
		if ( $is_conversational || empty( $form_type ) || 'calculator' !== $form_type ) {
			return $field_type;
		}

		// If the field type is dropdown and the number of options is less than or equal to 6, then change the field type to multi-choice.
		if ( 'dropdown' === $field_type && is_array( $field_data['fieldOptions'] ) && 6 >= count( $field_data['fieldOptions'] ) ) {
			$field_type = 'multi-choice';
		}

		return $field_type;
	}

	/**
	 * Create metas for AI when form type is calculator.
	 *
	 * @param array<string,mixed> $metas The metas.
	 * @param array<string,mixed> $form_info_obj The form info object.
	 *
	 * @since 1.5.0
	 * @return array<string,mixed>
	 */
	public function create_metas_for_ai( $metas, $form_info_obj ) {

		if ( ! is_object( $form_info_obj ) || 'calculator' !== $form_info_obj->form_type ) {
			return $metas;
		}

		return [
			'_srfm_submit_button_disable' => true,
		];
	}

	/**
	 * Map number field attributes for calculations.
	 *
	 * @param array<string,mixed> $merged_attributes Merged field attributes.
	 * @param array<string,mixed> $question contains the field attributes data that comes from AI.
	 * @param bool                $is_conversational Whether the form is conversational or not.
	 * @param string              $form_type The form type.
	 *
	 * @since 1.5.0
	 * @return array<string,mixed>
	 */
	public function map_number_field_attrs( $merged_attributes, $question, $is_conversational, $form_type ) {

		if ( $is_conversational && 'calculator' !== $form_type && 'number' !== $question['fieldType'] ) {
			return $merged_attributes;
		}

		$merged_attributes['prefix'] = ! empty( $question['prefix'] ) ? $question['prefix'] : '';
		$merged_attributes['suffix'] = ! empty( $question['suffix'] ) ? $question['suffix'] : '';

		// when the calculation formula is not empty, enable calculation for that field.
		if ( ! empty( $question['calculationFormula'] ) ) {
			$merged_attributes['enableCalculation']  = true;
			$merged_attributes['calculationFormula'] = ! empty( $question['calculationFormula'] ) ? $question['calculationFormula'] : '';
			$merged_attributes['calculationRound']   = ! empty( $question['calculationRound'] ) ? filter_var( $question['calculationRound'], FILTER_VALIDATE_INT ) : 0;
		}

		return $merged_attributes;
	}

	/**
	 * Enqueue Admin Scripts.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public function enqueue_admin_scripts() {
		$script = [
			'unique_file'        => 'srfmCalculationAdmin',
			'unique_handle'      => 'srfm-calculation-admin',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		// Scripts.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep, // Dependencies, defined above.
			$script_dep_data['version'], // SRFM_VER.
			true // Enqueue the script in the footer.
		);

		// Register script translations.
		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Add calculations form version to the AI form generator request body.
	 *
	 * @param array<string,mixed> $body The body that contains the user prompt.
	 * @param array<string,mixed> $params The parameters related to the AI form generator.
	 *
	 * @since 1.5.0
	 * @return array<string,mixed>
	 */
	public function add_calculation_form_version( $body, $params ) {

		if ( ! is_array( $params ) || 'calculator' !== $params['form_type'] ) {
			return $body;
		}

		return array_merge(
			$body,
			[
				'type'    => 'calculator',
				'version' => 'calculator',
			]
		);
	}

	/**
	 * Enqueue Admin Scripts.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public function enqueue_block_editor_scripts() {
		$script = [
			'unique_file'        => 'srfmCalculation',
			'unique_handle'      => 'srfm-calculation',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/package/business/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		// Scripts.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
			SRFM_PRO_URL . 'dist/package/business/' . $script['unique_file'] . '.js',
			$script_dep, // Dependencies, defined above.
			$script_dep_data['version'], // SRFM_VER.
			true // Enqueue the script in the footer.
		);

		// Register script translations.
		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Enqueue Calculation Scripts.
	 *
	 * @param array<string, mixed> $args Block arguments containing block_name and attr.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public function enqueue_calculation_scripts( $args ) {
		// Static flag to ensure scripts are only enqueued once.
		static $scripts_enqueued = false;

		// Return early if scripts are already enqueued.
		if ( $scripts_enqueued ) {
			return;
		}

		// Check if this block has calculation enabled.
		$is_calculation_enabled = is_array( $args ) && isset( $args['attr'] ) && is_array( $args['attr'] ) && isset( $args['attr']['enableCalculation'] ) && $args['attr']['enableCalculation'];

		// Return early if this block doesn't have calculation enabled.
		if ( ! $is_calculation_enabled ) {
			return;
		}

		// Load the math.js library.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-mathjs', // Handle.
			SRFM_PRO_URL . 'assets/js/minified/deps/math.min.js',
			[],
			SRFM_PRO_VER,
			true // Enqueue the script in the footer.
		);

		// Load the frontend custom app script.
		wp_enqueue_script(
			SRFM_PRO_SLUG . '-calculation-app-frontend', // Handle.
			SRFM_PRO_URL . 'dist/package/business/srfmCalculationFrontend.js',
			[],
			SRFM_PRO_VER,
			true // Enqueue the script in the footer.
		);

		// Mark scripts as enqueued.
		$scripts_enqueued = true;
	}

	/**
	 * Register Submit Button Enable Meta.
	 *
	 * @param array<string, mixed> $meta Meta data.
	 *
	 * @since 1.5.0
	 * @return array
	 */
	public function register_submit_button_enable_meta( $meta ) {
		$meta['_srfm_submit_button_disable'] = 'boolean';

		return $meta;
	}

	/**
	 * Show Submit Button.
	 *
	 * @param bool   $should_show_submit_button Should show submit button.
	 * @param number $id                        Form ID.
	 *
	 * @since 1.5.0
	 * @return bool
	 */
	public function show_submit_button( $should_show_submit_button, $id ) {
		$submit_button_disable = get_post_meta( intval( $id ), '_srfm_submit_button_disable', true );

		return $submit_button_disable ? false : $should_show_submit_button;
	}

	/**
	 * Add Calculation class.
	 *
	 * @param string       $field_classes Field classes.
	 * @param array<mixed> $args          Field args.
	 * @since 1.5.0
	 * @return string $field_classes Field classes.
	 */
	public function add_calculation_class( $field_classes, $args ) {
		if ( is_array( $args ) && isset( $args['attributes']['enableCalculation'] ) && $args['attributes']['enableCalculation'] ) {
			if ( is_string( $field_classes ) && ! empty( $field_classes ) ) {
				$field_classes .= ' srfm-calculation';
			} elseif ( empty( $field_classes ) ) {
				$field_classes = 'srfm-calculation';
			}
		}

		return $field_classes;
	}

	/**
	 * Add Calculation config.
	 *
	 * @param array<mixed> $field_config Field config.
	 * @param array<mixed> $args         Field args.
	 * @since 1.5.0
	 * @return array<mixed> $args Field args.
	 */
	public function add_calculation_config( $field_config, $args ) {
		if ( is_array( $args ) && isset( $args['attributes']['calculationFormula'] ) && is_string( $args['attributes']['calculationFormula'] ) && isset( $args['attributes']['enableCalculation'] ) && $args['attributes']['enableCalculation'] ) {
			$formula = $args['attributes']['calculationFormula'];

			// In the formula we have curly braces, we need to replace them with double curly braces.
			$formula = str_replace( '{', '%{%', $formula );
			$formula = str_replace( '}', '%}%', $formula );

			$field_config['calculationFormula'] = $formula;

			// Add rounding options. attributes.calculationRound should be number.
			if ( isset( $args['attributes']['calculationRound'] ) && is_numeric( $args['attributes']['calculationRound'] ) ) {
				$field_config['calculationRound'] = intval( $args['attributes']['calculationRound'] );
			}

			// If block is 'srfm/advanced-heading' then add the numberFormatType.
			if ( isset( $args['blockName'] ) && 'srfm/advanced-heading' === $args['blockName'] ) {
				$field_config['numberFormatType'] = $args['attributes']['numberFormatType'] ?? '';
			}
		}

		return $field_config;
	}

	/**
	 * Show Options Values.
	 *
	 * @param bool $default_value Should show values.
	 * @param bool $value       Value.
	 *
	 * @since 1.5.0
	 * @return bool
	 */
	public function show_options_values( $default_value, $value ) {
		return $value ? true : $default_value;
	}

	/**
	 * Filter Block Content.
	 *
	 * @param string $block_content Entire Block Content.
	 * @param array  $block         Block Properties As An Array.
	 *
	 * @since 1.5.0
	 * @return string
	 */
	public function filter_block_content( $block_content, $block ) {
		if ( isset( $block['blockName'] ) && 'srfm/advanced-heading' === $block['blockName'] ) {
			/**
			 * This script checks if the block attribute 'enableCalculation' is set to true.
			 * If true, it adds a calculation result span to the block content, which includes a placeholder for the calculation result.
			 */
			if ( isset( $block['attrs']['enableCalculation'] ) && $block['attrs']['enableCalculation'] && false !== strpos( $block_content, '{calculation-result}' ) ) {
				$block_content = str_replace( '{calculation-result}', '<span class="srfm-calculation-result"></span>', $block_content );
			}
		}

		if ( isset( $block['blockName'] ) && 'srfm/html' === $block['blockName'] ) {
			/**
			 * This script checks if the block attribute 'enableCalculation' is set to true for HTML blocks.
			 * If true, it replaces the {calculation-result} placeholder with a span element for dynamic calculation results.
			 */
			if ( isset( $block['attrs']['enableCalculation'] ) && $block['attrs']['enableCalculation'] && false !== strpos( $block_content, '{calculation-result}' ) ) {
				$block_content = str_replace( '{calculation-result}', '<span class="srfm-calculation-result"></span>', $block_content );
			}
		}

		return $block_content;
	}

	/**
	 * Resolve and evaluate a calculation formula to a numeric result.
	 *
	 * Substitutes each `{form:slug}` smart tag with the matching field's submitted numeric value,
	 * then evaluates the resulting arithmetic expression with a restricted, safe parser (no `eval`).
	 *
	 * @param string       $formula      The raw calculation formula (e.g. "{form:price} * 2 + 10").
	 * @param array<mixed> $block_config All block configurations for the form.
	 * @param array<mixed> $form_data    Submitted form data.
	 * @since 2.11.1
	 * @return float|null Numeric result, or null if any token is unresolved or the expression is invalid.
	 */
	private function evaluate_calculation_formula( $formula, $block_config, $form_data ) {
		// Normalize escaped delimiters (%{% ... %}%) back to { ... } if present.
		$formula = str_replace( [ '%{%', '%}%' ], [ '{', '}' ], $formula );

		// Substitute each {type:slug} smart tag with its resolved numeric value. Any token that
		// cannot be resolved (unknown type or missing field) is replaced with an invalid marker so
		// the expression is rejected rather than silently mispriced.
		$substituted = preg_replace_callback(
			'/\{([^:{}]+):([^{}]+)\}/',
			function ( $matches ) use ( $block_config, $form_data ) {
				$type = trim( $matches[1] );
				$slug = trim( $matches[2] );

				if ( 'form' !== $type ) {
					return 'INVALID';
				}

				$value = $this->resolve_field_numeric_value( $slug, $block_config, $form_data );

				if ( null === $value ) {
					return 'INVALID';
				}

				// Format as a plain decimal — NOT (string) $value, which yields
				// scientific notation for large/small floats (e.g. 1.0E+30). The "E"
				// would make the tokenizer reject the whole expression (a null the
				// payment validator then has to fail-safe on, and a legit large total
				// would be wrongly rejected).
				$formatted = rtrim( rtrim( sprintf( '%.10F', $value ), '0' ), '.' );
				return '' === $formatted ? '0' : $formatted;
			},
			$formula
		);

		if ( ! is_string( $substituted ) || false !== strpos( $substituted, 'INVALID' ) ) {
			return null;
		}

		return $this->safe_eval_arithmetic( $substituted );
	}

	/**
	 * Resolve a referenced field's submitted value to a number, mirroring the front-end calculator.
	 *
	 * @param string       $slug         Field slug referenced in the formula.
	 * @param array<mixed> $block_config All block configurations for the form.
	 * @param array<mixed> $form_data    Submitted form data.
	 * @since 2.11.1
	 * @return float|null Numeric value (0 when empty/hidden by conditional logic), or null if non-numeric.
	 */
	private function resolve_field_numeric_value( $slug, $block_config, $form_data ) {
		// Find the referenced field's config first — it gives the field's unique block_id, its
		// block type, and (for numbers) its format. Matching on slug alone is ambiguous.
		$field_config = null;
		foreach ( $block_config as $cfg ) {
			if ( is_array( $cfg ) && isset( $cfg['slug'] ) && $cfg['slug'] === $slug ) {
				$field_config = $cfg;
				break;
			}
		}

		$block_id = is_array( $field_config ) && isset( $field_config['block_id'] ) ? (string) $field_config['block_id'] : '';

		// Resolve the submitted value by the field's unique block_id when known, so a crafted or
		// slug-colliding submitted key (e.g. "price" vs "base-price", or an attacker-injected
		// "...-lbl-...-price" key) cannot shadow the real field and bias the recomputed amount.
		// Fall back to slug lookup only when the field has no recorded block_id.
		$submitted = null;
		if ( '' !== $block_id ) {
			$needle = '-' . $block_id . '-lbl-';
			foreach ( $form_data as $key => $value ) {
				if ( is_string( $key ) && false !== strpos( $key, $needle ) ) {
					$submitted = $value;
					break;
				}
			}
		} else {
			$submitted = \SRFM\Inc\Payments\Payment_Helper::get_submitted_value_by_slug( $slug, $form_data );
		}

		// Empty or absent (e.g. hidden by conditional logic) contributes 0, matching the front end.
		if ( null === $submitted || '' === $submitted ) {
			return 0.0;
		}

		$block_name = is_array( $field_config ) ? ( $field_config['block_name'] ?? ( $field_config['blockName'] ?? '' ) ) : '';

		// Dropdown / multi-choice: the numeric value is the configured option value, not the label.
		if ( ( 'srfm/dropdown' === $block_name || 'srfm/multi-choice' === $block_name ) && is_array( $field_config ) ) {
			return $this->sum_option_values( Helper::get_string_value( $submitted ), $field_config );
		}

		// Numeric fields (number, slider, hidden, etc.): normalize per the field's number format,
		// mirroring the front end. EU style uses comma as the decimal separator.
		$format_type = is_array( $field_config ) && ! empty( $field_config['format_type'] ) ? $field_config['format_type'] : 'us-style';
		$str         = Helper::get_string_value( $submitted );
		if ( 'eu-style' === $format_type ) {
			$str = str_replace( '.', '', $str );
			$str = str_replace( ',', '.', $str );
		} else {
			$str = str_replace( ',', '', $str );
		}

		return is_numeric( $str ) ? floatval( $str ) : null;
	}

	/**
	 * Sum the configured option values matching the submitted label(s) for a choice field.
	 *
	 * @param string       $submitted_value Submitted label, or " | "-joined labels for multi-select.
	 * @param array<mixed> $field_config    The choice field's block config (with options).
	 * @since 2.11.1
	 * @return float Total of the matched option values.
	 */
	private function sum_option_values( $submitted_value, $field_config ) {
		$options = isset( $field_config['options'] ) && is_array( $field_config['options'] ) ? $field_config['options'] : [];
		if ( empty( $options ) ) {
			return 0.0;
		}

		$block_name = $field_config['block_name'] ?? ( $field_config['blockName'] ?? '' );
		$is_multi   = 'srfm/dropdown' === $block_name ? ! empty( $field_config['multi_select'] ) : empty( $field_config['single_selection'] );
		$values     = $is_multi && false !== strpos( $submitted_value, ' | ' ) ? explode( ' | ', $submitted_value ) : [ $submitted_value ];
		$total      = 0.0;

		foreach ( $options as $option ) {
			if ( ! is_array( $option ) ) {
				continue;
			}
			$label = isset( $option['label'] ) ? trim( Helper::get_string_value( $option['label'] ) ) : '';
			foreach ( $values as $value ) {
				if ( trim( Helper::get_string_value( $value ) ) === $label ) {
					$total += floatval( $option['value'] ?? 0 );
					break;
				}
			}
		}

		return $total;
	}

	/**
	 * Safely evaluate an arithmetic expression (no `eval`).
	 *
	 * Supports numbers and the operators `+ - * / ^`, unary minus/plus, and parentheses, with
	 * standard precedence (matching the front-end math library for these operators).
	 *
	 * @param string $expr The arithmetic expression with all tokens already substituted to numbers.
	 * @since 2.11.1
	 * @return float|null The result, or null on any parse/maths error (e.g. division by zero).
	 */
	private function safe_eval_arithmetic( $expr ) {
		$tokens = $this->tokenize_arithmetic( $expr );
		if ( null === $tokens ) {
			return null;
		}

		$pos    = 0;
		$result = $this->parse_expression( $tokens, $pos );

		// Reject parse errors and any trailing/unconsumed tokens.
		if ( null === $result || count( $tokens ) !== $pos || ! is_finite( $result ) ) {
			return null;
		}

		return $result;
	}

	/**
	 * Tokenize an arithmetic expression into numbers and operator characters.
	 *
	 * @param string $expr The expression.
	 * @since 2.11.1
	 * @return array<int, float|string>|null Token list, or null if an invalid character is present.
	 */
	private function tokenize_arithmetic( $expr ) {
		$tokens = [];
		$length = strlen( $expr );
		$index  = 0;

		while ( $index < $length ) {
			$char = $expr[ $index ];

			if ( ctype_space( $char ) ) {
				$index++;
				continue;
			}

			// Operators and grouping. `%` is modulo and `,` separates function
			// arguments (min/max/round/mod/…), matching the front-end math.js grammar.
			if ( false !== strpos( '+-*/^()%,', $char ) ) {
				$tokens[] = $char;
				$index++;
				continue;
			}

			if ( ctype_digit( $char ) || '.' === $char ) {
				$number = '';
				while ( $index < $length && ( ctype_digit( $expr[ $index ] ) || '.' === $expr[ $index ] ) ) {
					$number .= $expr[ $index ];
					$index++;
				}
				if ( ! is_numeric( $number ) ) {
					return null;
				}
				$tokens[] = floatval( $number );
				continue;
			}

			// Function names (min, max, round, abs, sqrt, floor, ceil, mod). Emitted as
			// lowercase string tokens; parse_primary validates them against a strict
			// whitelist, so an unknown identifier still fails safe (returns null).
			if ( ctype_alpha( $char ) ) {
				$name = '';
				while ( $index < $length && ctype_alpha( $expr[ $index ] ) ) {
					$name .= $expr[ $index ];
					$index++;
				}
				$tokens[] = strtolower( $name );
				continue;
			}

			// Any other character makes the expression invalid.
			return null;
		}

		return $tokens;
	}

	/**
	 * Parse an additive expression: term (('+'|'-') term)*.
	 *
	 * @param array<int, float|string> $tokens Token list.
	 * @param int                      $pos    Current position (by reference).
	 * @since 2.11.1
	 * @return float|null
	 */
	private function parse_expression( $tokens, &$pos ) {
		$value = $this->parse_term( $tokens, $pos );
		if ( null === $value ) {
			return null;
		}

		$token_count = count( $tokens );
		while ( $pos < $token_count && ( '+' === $tokens[ $pos ] || '-' === $tokens[ $pos ] ) ) {
			$operator = $tokens[ $pos ];
			$pos++;
			$rhs = $this->parse_term( $tokens, $pos );
			if ( null === $rhs ) {
				return null;
			}
			$value = '+' === $operator ? $value + $rhs : $value - $rhs;
		}

		return $value;
	}

	/**
	 * Parse a multiplicative term: factor (('*'|'/') factor)*.
	 *
	 * @param array<int, float|string> $tokens Token list.
	 * @param int                      $pos    Current position (by reference).
	 * @since 2.11.1
	 * @return float|null
	 */
	private function parse_term( $tokens, &$pos ) {
		$value = $this->parse_factor( $tokens, $pos );
		if ( null === $value ) {
			return null;
		}

		$token_count = count( $tokens );
		while ( $pos < $token_count && ( '*' === $tokens[ $pos ] || '/' === $tokens[ $pos ] || '%' === $tokens[ $pos ] ) ) {
			$operator = $tokens[ $pos ];
			$pos++;
			$rhs = $this->parse_factor( $tokens, $pos );
			if ( null === $rhs ) {
				return null;
			}
			if ( '*' === $operator ) {
				$value *= $rhs;
			} elseif ( '/' === $operator ) {
				if ( 0.0 === (float) $rhs ) {
					return null; // Division by zero.
				}
				$value /= $rhs;
			} else {
				// Modulo, matching math.js: result takes the sign of the divisor
				// (x - y * floor(x / y)), unlike PHP's fmod which uses the dividend.
				if ( 0.0 === (float) $rhs ) {
					return null;
				}
				$value = $value - $rhs * floor( $value / $rhs );
			}
		}

		return $value;
	}

	/**
	 * Parse a factor, handling leading unary plus/minus, then a power expression.
	 *
	 * @param array<int, float|string> $tokens Token list.
	 * @param int                      $pos    Current position (by reference).
	 * @since 2.11.1
	 * @return float|null
	 */
	private function parse_factor( $tokens, &$pos ) {
		if ( $pos < count( $tokens ) && ( '-' === $tokens[ $pos ] || '+' === $tokens[ $pos ] ) ) {
			$operator = $tokens[ $pos ];
			$pos++;
			$value = $this->parse_factor( $tokens, $pos );
			if ( null === $value ) {
				return null;
			}
			return '-' === $operator ? -$value : $value;
		}

		return $this->parse_power( $tokens, $pos );
	}

	/**
	 * Parse a power expression: primary ('^' factor)? (right-associative).
	 *
	 * @param array<int, float|string> $tokens Token list.
	 * @param int                      $pos    Current position (by reference).
	 * @since 2.11.1
	 * @return float|null
	 */
	private function parse_power( $tokens, &$pos ) {
		$base = $this->parse_primary( $tokens, $pos );
		if ( null === $base ) {
			return null;
		}

		if ( $pos < count( $tokens ) && '^' === $tokens[ $pos ] ) {
			$pos++;
			$exponent = $this->parse_factor( $tokens, $pos );
			if ( null === $exponent ) {
				return null;
			}
			return (float) pow( $base, $exponent );
		}

		return $base;
	}

	/**
	 * Parse a primary: a number or a parenthesised expression.
	 *
	 * @param array<int, float|string> $tokens Token list.
	 * @param int                      $pos    Current position (by reference).
	 * @since 2.11.1
	 * @return float|null
	 */
	private function parse_primary( $tokens, &$pos ) {
		if ( $pos >= count( $tokens ) ) {
			return null;
		}

		$token = $tokens[ $pos ];

		if ( is_float( $token ) || is_int( $token ) ) {
			$pos++;
			return (float) $token;
		}

		if ( '(' === $token ) {
			$pos++;
			$value = $this->parse_expression( $tokens, $pos );
			if ( null === $value ) {
				return null;
			}
			if ( $pos >= count( $tokens ) || ')' !== $tokens[ $pos ] ) {
				return null;
			}
			$pos++;
			return $value;
		}

		// Function call: <name> '(' arg (',' arg)* ')'. The name was lowercased by
		// the tokenizer; ctype_alpha distinguishes it from operator tokens.
		if ( is_string( $token ) && ctype_alpha( $token ) ) {
			$name = $token;
			$pos++;
			if ( $pos >= count( $tokens ) || '(' !== $tokens[ $pos ] ) {
				return null; // A bare identifier (no call) is invalid.
			}
			$pos++; // Consume '('.

			$args = [];
			if ( $pos < count( $tokens ) && ')' === $tokens[ $pos ] ) {
				return null; // Empty argument list — none of the supported functions are nullary.
			}
			while ( true ) {
				$arg = $this->parse_expression( $tokens, $pos );
				if ( null === $arg ) {
					return null;
				}
				$args[] = $arg;
				if ( $pos < count( $tokens ) && ',' === $tokens[ $pos ] ) {
					$pos++;
					continue;
				}
				break;
			}
			if ( $pos >= count( $tokens ) || ')' !== $tokens[ $pos ] ) {
				return null;
			}
			$pos++; // Consume ')'.

			return $this->apply_calc_function( $name, $args );
		}

		return null;
	}

	/**
	 * Apply a whitelisted calculation function, mirroring the front-end math.js set.
	 *
	 * Any unsupported name or wrong argument count returns null so the whole
	 * expression fails safe (the caller then rejects the payment rather than
	 * trusting a client-submitted amount).
	 *
	 * @param string            $name Lowercase function name.
	 * @param array<int, float> $args Evaluated numeric arguments.
	 * @since 2.11.1
	 * @return float|null
	 */
	private function apply_calc_function( $name, $args ) {
		$count = count( $args );

		switch ( $name ) {
			case 'min':
				return $count >= 1 ? (float) min( $args ) : null;
			case 'max':
				return $count >= 1 ? (float) max( $args ) : null;
			case 'abs':
				return 1 === $count ? (float) abs( $args[0] ) : null;
			case 'sqrt':
				// sqrt of a negative is NaN -> safe_eval_arithmetic's is_finite check rejects it.
				return 1 === $count ? (float) sqrt( $args[0] ) : null;
			case 'floor':
				return 1 === $count ? (float) floor( $args[0] ) : null;
			case 'ceil':
				return 1 === $count ? (float) ceil( $args[0] ) : null;
			case 'round':
				if ( 1 === $count ) {
					return (float) round( $args[0] );
				}
				if ( 2 === $count ) {
					return (float) round( $args[0], (int) $args[1] );
				}
				return null;
			case 'mod':
				if ( 2 !== $count || 0.0 === (float) $args[1] ) {
					return null;
				}
				// Sign of divisor, matching math.js (see the '%' operator above).
				return (float) ( $args[0] - $args[1] * floor( $args[0] / $args[1] ) );
			default:
				return null;
		}
	}
}
