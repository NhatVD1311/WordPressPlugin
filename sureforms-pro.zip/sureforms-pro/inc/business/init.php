<?php
/**
 * Main class file to initialize all the classes of business package.
 *
 * @since 1.0.2
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Business;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Business\Custom_App\Load;
use SRFM_Pro\Inc\Business\Custom_Post_Type\Init as Custom_Post_Type;
use SRFM_Pro\Inc\Business\Database\Register as DB_Register;
use SRFM_Pro\Inc\Business\Dynamic_Options\Init as Dynamic_Options;
use SRFM_Pro\Inc\Business\Partial_Entries\Init as Partial_Entries_Init;
use SRFM_Pro\Inc\Business\Payments\PayPal\Admin_PayPal_Handler;
use SRFM_Pro\Inc\Business\Payments\PayPal\Frontend as Paypal_Frontend;
use SRFM_Pro\Inc\Business\Payments\PayPal\Settings as Paypal_Settings;
use SRFM_Pro\Inc\Business\Payments\PayPal\Webhook_Listener;
use SRFM_Pro\Inc\Business\Pdf\Pdf;
use SRFM_Pro\Inc\Business\Quiz\Init as Quiz;
use SRFM_Pro\Inc\Business\Recurring_Entry_Limit\Init as Recurring_Entry_Limit;
use SRFM_Pro\Inc\Business\Repeater\Init as Repeater;
use SRFM_Pro\Inc\Business\Survey\Init as Survey;
use SRFM_Pro\Inc\Business\User_Registration\Init as User_Registration_Init;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize business package.
 *
 * @since 1.0.2
 */
class Init {
	use Get_Instance;

	/**
	 * Initialize business package.
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function __construct() {
		$this->load_classes();
	}

	/**
	 * Load the necessary classes of the business package.
	 *
	 * @since 1.0.2
	 * @return void
	 */
	public function load_classes() {
		if ( method_exists( Helper::class, 'is_suretriggers_ready' ) && Helper::is_suretriggers_ready() ) {
			// Only load custom app if SureTriggers plugin is ready.
			Load::get_instance();
		}

		// Load Calculation feature.
		Calculation::get_instance();
		Custom_Post_Type::get_instance();
		Quiz::get_instance();
		Survey::get_instance();

		// Load Dynamic Options feature.
		Dynamic_Options::get_instance();

		// Load Repeater feature.
		Repeater::get_instance();
		// Load Recurring Entry Limit feature (daily/weekly/monthly/yearly caps).
		Recurring_Entry_Limit::get_instance();
		// Load PDF feature.
		Pdf::get_instance();
		// Load User Registration feature.
		User_Registration_Init::get_instance();

		// Load PayPal Settings feature.
		Paypal_Settings::get_instance();
		// Load PayPal Frontend feature.
		Paypal_Frontend::get_instance();
		// Load PayPal Webhook Listener.
		Webhook_Listener::get_instance();

		// Load PayPal Admin Handler for refund operations and payment history filters.
		Admin_PayPal_Handler::get_instance();

		// Load Partial Entries (form abandonment capture).
		Partial_Entries_Init::get_instance();

		// Load database tables.
		DB_Register::init();
	}
}
