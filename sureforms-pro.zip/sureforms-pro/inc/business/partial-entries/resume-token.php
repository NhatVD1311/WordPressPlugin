<?php
/**
 * Resume_Token — HMAC-signed opaque tokens that bind a session_id +
 * form_id pair to an explicit purpose ("resume" or "delete").
 *
 * Replaces two anti-patterns in the partial-entries feature:
 *
 *   1. Sharing the raw `session_id` as a `?pe_token=` URL parameter,
 *      which let any link-holder restore (and overwrite) the saved
 *      data with no scoping at all. The new resume token is
 *      non-expiring (admins want stable resume URLs) but is
 *      HMAC-bound to the (form_id, session_id) pair, so a leaked
 *      link is at least scoped to a single saved entry — and the
 *      underlying session_id never travels in the URL.
 *
 *   2. Trusting the client-supplied `srfm_partial_session_id` hidden
 *      field for cleanup-on-submit. Anyone who learned a victim's
 *      session_id could submit their own form with that id injected
 *      and silently delete the victim's saved partial. The new
 *      delete token is server-issued in the save response, has a
 *      24-hour TTL, is rotated on every save, and is verified
 *      before any cleanup.
 *
 * Token format: `<exp>.<session_id_b64url>.<hex_hmac>` where the
 * HMAC signs `purpose|form_id|session_id|exp` with a plugin-
 * namespaced sub-key derived from `wp_salt('auth')`. Embedding the
 * (already-opaque) session id in the token lets the server resolve
 * it without ever requiring the client to know it — that is the
 * whole point of issuing the token in the first place. The token
 * stays URL-safe and short enough to fit comfortably in a query
 * string.
 *
 * @package SRFM_Pro
 * @since   2.9.0
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Short-lived signed-payload helper for partial-entry resume / delete flows.
 *
 * @since 2.9.0
 */
class Resume_Token {
	/**
	 * Default time-to-live for resume tokens (24 hours).
	 *
	 * Long enough to be useful when an admin emails a resume link to
	 * a customer, short enough that a leaked link is not a permanent
	 * key to that customer's saved data.
	 *
	 * @since 2.9.0
	 */
	public const DEFAULT_TTL = 86400;

	/**
	 * Issue a signed token for the given purpose / form / session.
	 *
	 * @since 2.9.0
	 * @param string $purpose    Intent label — one of `'resume'` or `'delete'`. Tokens issued for one purpose never validate for another.
	 * @param int    $form_id    Form post ID.
	 * @param string $session_id Partial-entry session id.
	 * @param int    $ttl        Lifetime in seconds. Defaults to {@see self::DEFAULT_TTL}.
	 * @return string Token of the form `<exp>.<hex_hmac>`. Empty string on bad input.
	 */
	public static function issue( $purpose, $form_id, $session_id, $ttl = self::DEFAULT_TTL ) {
		$purpose    = (string) $purpose;
		$form_id    = (int) $form_id;
		$session_id = (string) $session_id;
		$ttl        = (int) $ttl;

		if ( '' === $purpose || $form_id <= 0 || '' === $session_id ) {
			return '';
		}

		// `$ttl <= 0` ⇒ non-expiring token. We encode `exp = 0` and
		// the verifier skips the expiry check for that sentinel.
		// `$ttl > 0`  ⇒ floor at 60s so we never issue something
		// that's already expired on arrival.
		if ( $ttl <= 0 ) {
			$exp = 0;
		} else {
			$exp = time() + max( 60, $ttl );
		}
		$mac     = self::sign( $purpose, $form_id, $session_id, $exp );
		$sid_b64 = self::base64url_encode( $session_id );
		return $exp . '.' . $sid_b64 . '.' . $mac;
	}

	/**
	 * Decode and verify a token. Returns the `(form_id, session_id)`
	 * pair encoded in the token after confirming that purpose,
	 * form_id, signature and expiry are all valid.
	 *
	 * The caller supplies `purpose` and `form_id` (the contextual
	 * binding) — `session_id` is read OUT of the token. That's the
	 * core feature: the client never has to know the session id to
	 * authenticate against it.
	 *
	 * @since 2.9.0
	 * @param string $token   Token previously issued by {@see self::issue()}.
	 * @param string $purpose Required purpose label.
	 * @param int    $form_id Required form id.
	 * @return string|false Resolved session_id, or false on invalid/expired/forged token.
	 */
	public static function decode( $token, $purpose, $form_id ) {
		$token   = (string) $token;
		$purpose = (string) $purpose;
		$form_id = (int) $form_id;

		if ( '' === $token || '' === $purpose || $form_id <= 0 ) {
			return false;
		}

		$parts = explode( '.', $token );
		if ( 3 !== count( $parts ) ) {
			return false;
		}
		[ $exp_raw, $sid_b64, $mac ] = $parts;

		$exp = (int) $exp_raw;
		// `$exp === 0` is a deliberate non-expiring token. Any
		// non-zero value MUST still be in the future. Negative
		// values are rejected.
		if ( $exp < 0 ) {
			return false;
		}
		if ( $exp > 0 && $exp <= time() ) {
			return false;
		}

		$session_id = self::base64url_decode( $sid_b64 );
		if ( false === $session_id || '' === $session_id ) {
			return false;
		}

		$expected = self::sign( $purpose, $form_id, $session_id, $exp );
		if ( ! hash_equals( $expected, $mac ) ) {
			return false;
		}

		return $session_id;
	}

	/**
	 * Convenience wrapper — verify a token where the caller already
	 * knows the expected session_id (the cleanup-on-submit flow).
	 *
	 * @since 2.9.0
	 * @param string $token      Token to verify.
	 * @param string $purpose    Required purpose.
	 * @param int    $form_id    Required form id.
	 * @param string $session_id Required session id.
	 * @return bool
	 */
	public static function verify( $token, $purpose, $form_id, $session_id ) {
		$decoded = self::decode( $token, $purpose, $form_id );
		if ( false === $decoded ) {
			return false;
		}
		return hash_equals( (string) $session_id, $decoded );
	}

	/**
	 * URL-safe base64 encode (RFC 4648 §5) — no padding.
	 *
	 * @since 2.9.0
	 * @param string $value Raw bytes.
	 * @return string Encoded value.
	 */
	private static function base64url_encode( $value ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- token payload is opaque; not used to obfuscate code.
		return rtrim( strtr( base64_encode( (string) $value ), '+/', '-_' ), '=' );
	}

	/**
	 * URL-safe base64 decode counterpart.
	 *
	 * @since 2.9.0
	 * @param string $value Encoded value.
	 * @return string|false Raw bytes, or false on malformed input.
	 */
	private static function base64url_decode( $value ) {
		$value = (string) $value;
		$value = strtr( $value, '-_', '+/' );
		$pad   = strlen( $value ) % 4;
		if ( $pad ) {
			$value .= str_repeat( '=', 4 - $pad );
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding our own opaque token; strict mode rejects malformed input.
		$decoded = base64_decode( $value, true );
		if ( false === $decoded ) {
			return false;
		}
		return $decoded;
	}

	/**
	 * Build the HMAC for a `(purpose, form_id, session_id, exp)` tuple.
	 *
	 * The signing key is derived once via HMAC over a fixed
	 * namespace string and `wp_salt('auth')`. Rotating wp-config
	 * secrets invalidates every outstanding token — that's
	 * intentional and matches the behaviour of {@see \SRFM\Inc\Submit_Token}.
	 *
	 * @since 2.9.0
	 * @param string $purpose    Token purpose.
	 * @param int    $form_id    Form id.
	 * @param string $session_id Session id.
	 * @param int    $exp        Expiry timestamp.
	 * @return string 64-char lowercase hex digest.
	 */
	private static function sign( $purpose, $form_id, $session_id, $exp ) {
		$signing_key = hash_hmac( 'sha256', 'srfm-partial-resume-token-v1', wp_salt( 'auth' ) );
		$payload     = implode( '|', [ 'srfm_pe', $purpose, $form_id, $session_id, $exp ] );
		return hash_hmac( 'sha256', $payload, $signing_key );
	}
}
