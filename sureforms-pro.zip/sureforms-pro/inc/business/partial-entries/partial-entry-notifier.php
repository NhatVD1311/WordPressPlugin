<?php
/**
 * Partial Entries — Notifier.
 *
 * Emails a "this form was partially filled" notification when a partial
 * (in-progress) entry is saved, dispatched immediately rather than after an
 * idle delay so the site owner sees it while the visitor is still on the form.
 *
 * Volume is bounded by three limits, because the save endpoint is public and the
 * client autosaves roughly every 2.5s:
 *   1. A per-entry ATOMIC claim on `notified_at`, so concurrent runs cannot
 *      double-send. This is the only hard guarantee. By default the claim is
 *      send-once (one email per row, ever); sites that opt in via
 *      `srfm_partial_entry_notify_repeat` get a time-windowed claim instead,
 *      re-arming every THROTTLE_WINDOW seconds.
 *   2. A per-form daily cap, checked before enqueueing as well as before sending.
 *      The counter is advanced by the worker, so it is eventually consistent: a
 *      burst can still outrun it and queue actions that are later dropped at send
 *      time. It bounds sustained abuse, not an instantaneous spike.
 *   3. Best-effort de-duplication of pending actions per row — a read-then-write,
 *      so it can be raced; it saves action rows, it does not prevent duplicate mail.
 *
 * `notified_at` therefore means "when this row was last claimed for sending",
 * one consistent meaning for both the send-once and windowed modes.
 *
 * Because dispatch is immediate rather than delayed, cancel_on_submit() only wins
 * the race when the queue runner has not yet picked the action up — a visitor who
 * completes the form will usually already have generated one partial-entry email.
 *
 * @package sureforms-pro
 * @since   2.12.3
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

use SRFM\Inc\Form_Submit;
use SRFM\Inc\Global_Settings\Global_Settings;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;
use SRFM_Pro\Inc\Pro\Database\Tables\Save_Resume;

defined( 'ABSPATH' ) || exit;

/**
 * Partial Entry Notifier class.
 *
 * @since 2.12.3
 */
class Partial_Entry_Notifier {
	use Get_Instance;

	/**
	 * Action Scheduler hook for the per-entry notification.
	 *
	 * @since 2.12.3
	 */
	public const HOOK = 'srfm_partial_entry_notify';

	/**
	 * Action Scheduler group — shared with the rest of SureForms.
	 *
	 * @since 2.12.3
	 */
	public const GROUP = 'sureforms';

	/**
	 * Maximum retry attempts for a single partial row before giving up.
	 *
	 * @since 2.12.3
	 */
	private const MAX_RETRIES = 5;

	/**
	 * Delay before retrying a transient send failure, in seconds.
	 *
	 * @since 2.12.3
	 */
	private const RETRY_DELAY = 900;

	/**
	 * Minimum gap between two notifications for the SAME partial row, in seconds.
	 *
	 * The client autosaves at most every 2.5s (MIN_SAVE_INTERVAL in
	 * partial-entries.js) plus a blur debounce, so an unthrottled per-save email
	 * would let a single visitor emit ~24 mails/minute and exhaust the daily cap
	 * within minutes — silencing the feature for every other visitor that day.
	 * One email per row per window keeps "notify while they are filling" useful
	 * without turning an ordinary session into a mail flood.
	 *
	 * @since 2.12.3
	 */
	private const THROTTLE_WINDOW = 900;

	/**
	 * Floor for the throttle window, in seconds.
	 *
	 * The window doubles as the atomic claim's re-claim interval, so it can be shortened
	 * but never removed — at 0 the claim predicate would match every stamped row.
	 *
	 * @since 2.12.3
	 */
	private const MIN_THROTTLE_WINDOW = 60;

	/**
	 * Constructor — registers the send + cancel hooks.
	 *
	 * @since 2.12.3
	 */
	public function __construct() {
		add_action( self::HOOK, [ $this, 'notify' ] );
		// Cancel a pending notification the instant the form is completed — at
		// priority 5, ahead of Init::delete_partial_on_submit() (priority 10) which
		// removes the row. Prevents a queued email for an entry that was submitted.
		add_action( 'srfm_form_submit', [ $this, 'cancel_on_submit' ], 5 );
	}

	/**
	 * Dispatch a notification for this row on save, subject to the throttle.
	 *
	 * Enqueued asynchronously for immediate execution — there is no idle delay,
	 * so the owner is told while the visitor is still filling the form. Every
	 * bound is applied BEFORE the enqueue, because an action row is itself a cost:
	 * the save endpoint is public and rate-limited only to 60 req/min/IP, so
	 * enqueueing first and filtering later would let one IP accrue tens of
	 * thousands of `actionscheduler_actions` rows a day in the shared `sureforms`
	 * group, starving every other async job on the site (WooCommerce included).
	 *
	 * Action Scheduler is a hard dependency (it ships with the free plugin); we
	 * deliberately do NOT fall back to an inline send, which on the public
	 * per-save endpoint would both flood the mailbox and block the request on a
	 * synchronous SMTP transaction an anonymous caller controls.
	 *
	 * @param string $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return void
	 */
	public function notify_on_save( string $uuid ) {
		$uuid = sanitize_text_field( $uuid );
		if ( '' === $uuid ) {
			return;
		}

		$row = Save_Resume::get( $uuid );
		if ( empty( $row ) ) {
			return;
		}

		$form_id = absint( $row['form_id'] ?? 0 );
		if ( 0 === $form_id || ! Init::is_notify_enabled( $form_id ) ) {
			return;
		}

		// Throttle: this row is already settled, so skip. Cheap pre-check only — the
		// authoritative, race-free decision is the claim in notify(). Both sides read
		// the same predicate deliberately: when they drifted apart, the time-based
		// check here kept passing after the send-once claim had become permanently
		// unsatisfiable, so every later autosave enqueued an action that could only
		// ever be refused.
		if ( $this->notification_settled( $row, $uuid ) ) {
			return;
		}

		// Cap BEFORE enqueue. Checking it only at send time (as the shipped code did,
		// where the single delayed action per row made it moot) would let a flood keep
		// creating action rows indefinitely after the cap is reached. Note this counter
		// is advanced by the WORKER, so during a burst the queue can still run ahead of
		// it — this bounds sustained abuse rather than an instantaneous spike.
		if ( $this->daily_cap_reached( $form_id ) ) {
			/**
			 * Fires when a save is dropped because the form hit its daily notification cap.
			 *
			 * Neither cap path reschedules — a notification refused by the cap is
			 * genuinely lost rather than deferred, so this hook exists to make that
			 * observable instead of silent. Retries are reserved for a delivery that
			 * failed, not for one we declined to send.
			 *
			 * @since 2.12.3
			 * @param int    $form_id Form post ID.
			 * @param string $uuid    Partial row UUID that was not notified.
			 */
			do_action( 'srfm_pro_partial_entry_notify_cap_reached', $form_id, $uuid );
			return;
		}

		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}

		// One pending action per row — best-effort, not a hard guarantee: this is a
		// read-then-write, so two simultaneous saves can both pass it. That only costs a
		// duplicate action row; the windowed claim in notify() is what actually prevents
		// a duplicate email. Args-scoped (matches on the UUID) and deliberately NOT
		// Action Scheduler's $unique flag: in the bundled AS (3.7.x) the pending dedupe
		// keys only on (hook, group_id) and ignores args, so $unique = true would
		// collapse every form's partial notification into a single site-wide action and
		// silently drop all but one visitor's email.
		//
		// as_has_scheduled_action() needs AS 3.3+, while the enqueue above only needs
		// 3.0. Treat it as the optimisation it is: if an older Action Scheduler wins
		// version negotiation, skip the de-dupe and let the claim do its job, rather
		// than disabling notifications entirely with no diagnostic.
		if ( function_exists( 'as_has_scheduled_action' )
			&& as_has_scheduled_action( self::HOOK, [ $uuid ], self::GROUP ) ) {
			return;
		}

		as_enqueue_async_action( self::HOOK, [ $uuid ], self::GROUP );
	}

	/**
	 * Send the notification for a partial row. Fired by Action Scheduler shortly
	 * after the save that enqueued it.
	 *
	 * Bails when: the row is gone (form completed / swept), notifications were
	 * turned off after scheduling, or the row was notified inside the current
	 * throttle window. Because this is bound to the public HOOK, re-asserting the
	 * toggle, the throttle and the cap here also bounds anyone who can fire the
	 * hook directly with a chosen UUID.
	 *
	 * @param string $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return void
	 */
	public function notify( $uuid ) {
		$uuid = sanitize_text_field( Helper::get_string_value( $uuid ) );
		if ( '' === $uuid ) {
			return;
		}

		$row = Save_Resume::get( $uuid );
		if ( empty( $row ) ) {
			return;
		}

		$form_id = absint( $row['form_id'] ?? 0 );
		if ( 0 === $form_id ) {
			return;
		}

		// Re-assert the toggle at send time — an admin may have disabled
		// notifications (or capture) after this action was queued.
		if ( ! Init::is_notify_enabled( $form_id ) ) {
			return;
		}

		// Throttle guard, re-asserted at send time: the hook is public, so anyone who
		// can fire it with a chosen UUID is bounded by the same rule as a real save.
		// Cheap pre-check; the claim below is the race-free authority. Uses the shared
		// predicate for the same reason as the enqueue side — all three sites must
		// agree on what "already notified" means.
		if ( $this->notification_settled( $row, $uuid ) ) {
			return;
		}

		// Per-form daily cap. The throttle already limits one email per row, but each
		// abandoned session creates its own row, so an attacker looping the public save
		// endpoint with distinct session ids would otherwise turn every accepted save
		// into a scheduled email. This bounds the mail a single form can emit per day.
		//
		// Drop rather than reschedule. reschedule() writes a two-day
		// srfm_pe_notify_retry_{md5} transient per UUID and queues another Action
		// Scheduler row, so a form sitting at its cap accumulates AS rows plus two
		// non-autoloaded option rows for every distinct session that hits it — growth
		// driven by an unauthenticated endpoint, for mail the cap has already refused to
		// send. Retries are for a delivery that failed, not for one we declined. This
		// mirrors the enqueue-time cap path above, which already fires the hook and
		// returns.
		if ( $this->daily_cap_reached( $form_id ) ) {
			/** This action is documented in the enqueue-time cap branch of notify_on_save(). */
			do_action( 'srfm_pro_partial_entry_notify_cap_reached', $form_id, $uuid );
			return;
		}

		// The partial form_data is already keyed by each field's input name
		// (SureForms' <slug>-lbl-<enc>-<blockid> scheme) — exactly what {all_data} /
		// parse_email_notification_template expect, so it is passed straight through.
		$form_data = is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [];

		$item     = $this->compose_notification_item( $form_id, $uuid );
		$email_to = sanitize_email( Helper::get_string_value( $item['email_to'] ?? '' ) );
		if ( ! is_email( $email_to ) ) {
			return;
		}

		// Claim the row atomically BEFORE sending, so a duplicate or concurrent run can't
		// double-send — but claim rather than simply stamp, so the claim can be released
		// if the send fails. Previously notified_at was committed unconditionally and
		// wp_mail()'s result was discarded, which turned any transient SMTP failure into
		// a permanent "notified" and also consumed a slot in the daily cap.
		//
		// The claim keeps the atomicity guarantee either way (exactly one of N concurrent
		// runs sees a row count of 1); what differs is whether the row becomes claimable
		// again afterwards.
		//
		// SEND-ONCE is the default. A windowed claim re-arms the row every
		// THROTTLE_WINDOW seconds, and because upsert() never clears notified_at, a
		// visitor who leaves the tab open with autosaves landing keeps re-arming it —
		// one abandoned entry emits ~4 notices an hour, ~32 overnight, every one with the
		// same subject and the same deep link. That reads as a mail loop rather than a
		// feature. Sites that genuinely want reminders opt in via the filter below and
		// get the windowed behaviour.
		$claim_stamp = current_time( 'mysql', true );

		// null => claim only while notified_at IS NULL (send-once). Shares
		// repeat_enabled() with the enqueue-side pre-check so the two cannot diverge.
		$reclaim_after = $this->repeat_enabled( $uuid ) ? $this->get_throttle_window() : null;

		if ( ! Save_Resume::claim_for_notification( $uuid, $claim_stamp, $reclaim_after ) ) {
			// Another run owns this row, or it has already been notified.
			return;
		}

		// Count the send BEFORE dispatching it, so a fatal or timeout inside wp_mail()
		// cannot let the ceiling drift upward under exactly the flood the cap exists to
		// stop. A handled failure gives the slot straight back below — see
		// unbump_daily_count() for why leaving it consumed would be worse than the drift.
		$this->bump_daily_count( $form_id );

		$parsed = Form_Submit::parse_email_notification_template( $form_data, $item, [ 'form-id' => $form_id ] );

		// Mirror Form_Submit::send_email(). The parsed headers already carry
		// Content-Type: text/html, but an SMTP plugin filtering wp_mail_content_type
		// overrides them and the body would render as source; the filter re-asserts it at
		// priority 99. The output buffer catches notices echoed (not thrown) by mail
		// plugins — this runs inside the Action Scheduler queue runner, whose response
		// stray output would otherwise corrupt.
		$content_type = static function () {
			return 'text/html';
		};
		add_filter( 'wp_mail_content_type', $content_type, 99 );

		ob_start();

		try {
			$sent = wp_mail( $email_to, $parsed['subject'], $parsed['message'], $parsed['headers'] );
		} finally {
			// try/finally, not a plain sequence: wp_mail() swallows PHPMailer
			// exceptions, but a throwing pre_wp_mail/wp_mail callback from an SMTP
			// plugin propagates straight out of here. Without this, the closure would
			// stay registered and the buffer stay open for the rest of the
			// queue-runner request — forcing text/html onto every other plugin's mail
			// in that run and swallowing their output.
			ob_end_clean();

			// Unlike core, remove it again: this runs in a long-lived queue-runner
			// request that goes on to send other plugins' mail.
			remove_filter( 'wp_mail_content_type', $content_type, 99 );
		}

		if ( ! $sent ) {
			// Nothing was delivered: return the reserved slot, release the claim so the
			// row is eligible again, then retry with a bound.
			$this->unbump_daily_count( $form_id );
			Save_Resume::release_notification_claim( $uuid, $claim_stamp );
			$this->reschedule( $uuid, self::RETRY_DELAY );
			return;
		}

		$this->clear_retry_count( $uuid );
	}

	/**
	 * Cancel a pending notification when the form is completed.
	 *
	 * Hooked to `srfm_form_submit` at priority 5 (before the partial row is
	 * deleted). Resolves the row from the completed submission's session and
	 * unschedules its pending action so a queued email can't fire in the race
	 * window around submission.
	 *
	 * @param mixed $response Submission response passed by srfm_form_submit.
	 * @since 2.12.3
	 * @return void
	 */
	public function cancel_on_submit( $response ) {
		if ( ! function_exists( 'as_unschedule_all_actions' ) ) {
			return;
		}
		if ( ! is_array( $response ) || empty( $response['success'] ) ) {
			return;
		}

		$form_id = isset( $response['form_id'] ) ? absint( $response['form_id'] ) : 0;
		if ( 0 === $form_id ) {
			return;
		}

		// The session id is NOT part of the srfm_form_submit response payload
		// (it carries success/form_id/to_emails/form_name/message/data only) — the
		// client sends it in the submission body. Prefer the parsed REST body, then
		// fall back to $_POST for legacy multipart posts, exactly as the sibling
		// Init::delete_partial_on_submit() does. No ownership token is required here:
		// unlike deletion this only unschedules a pending notice, so a forged id at
		// worst cancels nothing (session ids are random and unguessable).
		$session = '';
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the form submission is HMAC-token authenticated upstream by the core form-submit handler.
		if ( isset( $response['srfm_partial_session_id'] ) ) {
			$session = substr( sanitize_text_field( Helper::get_string_value( $response['srfm_partial_session_id'] ) ), 0, 64 );
		} elseif ( isset( $_POST['srfm_partial_session_id'] ) ) {
			$session = substr( sanitize_text_field( wp_unslash( (string) $_POST['srfm_partial_session_id'] ) ), 0, 64 );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		if ( '' === $session ) {
			return;
		}

		$row  = Save_Resume::get_by_session( $session, $form_id );
		$uuid = is_array( $row ) ? sanitize_text_field( Helper::get_string_value( $row['id'] ?? '' ) ) : '';
		if ( '' === $uuid ) {
			return;
		}

		as_unschedule_all_actions( self::HOOK, [ $uuid ], self::GROUP );
	}

	/**
	 * The address a partial-entry notification goes to when "Send to" is left empty.
	 *
	 * Exposed for the editor, which shows it as help text so the author can see where an
	 * empty field actually resolves — the form's own notification email if it has one,
	 * only otherwise the site admin. Resolving through the real chain avoids the editor
	 * claiming "admin@" for a form that in fact mails someone else.
	 *
	 * Returns a real address, so callers must gate on capability before displaying it.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return string
	 */
	public function get_default_recipient( $form_id ) {
		return $this->resolve_recipient( $form_id );
	}

	/**
	 * Re-enqueue a notification for this row, bounded by MAX_RETRIES.
	 *
	 * Keeps the existing single-argument hook signature ([ $uuid ]) so
	 * cancel_on_submit()'s as_unschedule_all_actions() match still works; the attempt
	 * counter lives in a transient rather than in the action args.
	 *
	 * @param string $uuid  Partial row UUID.
	 * @param int    $delay Seconds to wait before the retry.
	 * @since 2.12.3
	 * @return void
	 */
	private function reschedule( $uuid, $delay ) {
		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		$stored   = get_transient( $this->retry_key( $uuid ) );
		$attempts = is_numeric( $stored ) ? (int) $stored : 0;

		if ( $attempts >= self::MAX_RETRIES ) {
			/**
			 * Fires when a partial-entry notification is abandoned after exhausting retries.
			 *
			 * @since 2.12.3
			 * @param string $uuid     Partial row UUID.
			 * @param int    $attempts Attempts made.
			 */
			do_action( 'srfm_pro_partial_entry_notification_abandoned', $uuid, $attempts );
			return;
		}

		set_transient( $this->retry_key( $uuid ), $attempts + 1, DAY_IN_SECONDS * 2 );

		as_schedule_single_action( time() + max( 60, (int) $delay ), self::HOOK, [ $uuid ], self::GROUP );
	}

	/**
	 * Clear the retry counter for a row once it has been delivered.
	 *
	 * @param string $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return void
	 */
	private function clear_retry_count( $uuid ) {
		delete_transient( $this->retry_key( $uuid ) );
	}

	/**
	 * Transient key holding the retry count for a row.
	 *
	 * @param string $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return string
	 */
	private function retry_key( $uuid ) {
		return 'srfm_pe_notify_retry_' . md5( Helper::get_string_value( $uuid ) );
	}

	/**
	 * Whether repeat notifications are enabled for a row.
	 *
	 * Single evaluation point for the filter, so the enqueue-side pre-check and the
	 * send-side claim can never disagree about which mode is in force.
	 *
	 * @param string $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return bool
	 */
	private function repeat_enabled( $uuid ) {
		/**
		 * Filter whether one partial entry may be notified about more than once.
		 *
		 * Default false: a row is notified exactly once for its lifetime. Return true to
		 * re-notify every `srfm_partial_entry_notify_throttle_window` seconds for as long
		 * as the visitor keeps autosaving.
		 *
		 * @param bool   $repeat Whether repeat notifications are enabled.
		 * @param string $uuid   Partial row UUID.
		 * @since 2.12.3
		 */
		return (bool) apply_filters( 'srfm_partial_entry_notify_repeat', false, $uuid );
	}

	/**
	 * Whether this row can no longer produce a notification.
	 *
	 * Mirrors exactly what `claim_for_notification()` will accept: in send-once mode any
	 * stamp at all is terminal, and in repeat mode only the throttle window applies.
	 *
	 * @param array<string,mixed>|mixed $row  Partial entry row.
	 * @param string                    $uuid Partial row UUID.
	 * @since 2.12.3
	 * @return bool
	 */
	private function notification_settled( $row, $uuid ) {
		if ( ! $this->repeat_enabled( $uuid ) ) {
			// Send-once: the claim only succeeds while notified_at IS NULL.
			return '' !== Helper::get_string_value( is_array( $row ) ? $row['notified_at'] ?? '' : '' );
		}

		return $this->within_throttle_window( $row );
	}

	/**
	 * Whether this row was already notified inside the current throttle window.
	 *
	 * @param array<string,mixed>|mixed $row Partial row.
	 * @since 2.12.3
	 * @return bool
	 */
	private function within_throttle_window( $row ) {
		$last = Helper::get_string_value( is_array( $row ) ? $row['notified_at'] ?? '' : '' );
		if ( '' === $last ) {
			return false;
		}

		$last_ts = strtotime( $last . ' UTC' );
		if ( false === $last_ts ) {
			return false;
		}

		return time() - $last_ts < $this->get_throttle_window();
	}

	/**
	 * Minimum seconds between two notifications for the same partial row.
	 *
	 * @since 2.12.3
	 * @return int
	 */
	private function get_throttle_window() {
		/**
		 * Filter the per-entry notification throttle window, in seconds.
		 *
		 * Lowering this raises the number of emails a single visitor can generate on a
		 * public endpoint. The value is clamped to MIN_THROTTLE_WINDOW and cannot be
		 * disabled: the same window is the re-claim interval of the atomic claim, and a
		 * zero window would make its predicate match every already-stamped row, giving up
		 * the "only one concurrent run sends" guarantee along with the rate limiting.
		 *
		 * @param int $window Seconds between notifications for one partial row.
		 * @since 2.12.3
		 */
		$window = (int) apply_filters( 'srfm_partial_entry_notify_throttle_window', self::THROTTLE_WINDOW );

		return max( self::MIN_THROTTLE_WINDOW, $window );
	}

	/**
	 * Build the email-notification `$item` array for the per-entry notification,
	 * in the shape parse_email_notification_template expects. Starts from the
	 * shared email-notification defaults and overrides the partial-entry fields.
	 *
	 * @param int    $form_id Form post ID.
	 * @param string $uuid    Partial row UUID, used to deep-link the email to the entry.
	 * @since 2.12.3
	 * @return array<string,mixed>
	 */
	private function compose_notification_item( $form_id, $uuid = '' ) {
		$base = Global_Settings::get_default_email_notification_settings();

		// Overlay the site's SAVED sender identity. get_default_email_notification_settings()
		// is a hardcoded array ({site_title} / {admin_email}) and never reads the option the
		// admin actually configured, so without this a partial-entry notice leaves under a
		// different From than every other SureForms email — enough to fail an SPF/DMARC
		// alignment check on a strict host and land the notice in spam. Only the sender
		// fields are taken; recipient/subject/body are this notification's own.
		$saved = get_option( 'srfm_email_notification_settings_options', [] );
		if ( is_array( $saved ) ) {
			foreach ( [ 'from_name', 'from_email' ] as $sender_key ) {
				if ( ! empty( $saved[ $sender_key ] ) && is_string( $saved[ $sender_key ] ) ) {
					$base[ $sender_key ] = $saved[ $sender_key ];
				}
			}
		}

		// Drop the default admin CC/BCC/Reply-To — a partial-entry notice goes only
		// to the resolved recipient, no extra copies.
		unset( $base['email_cc'], $base['email_bcc'], $base['email_reply_to'] );

		$admin_link = $this->admin_entry_url( $uuid );

		$base['status']        = true;
		$base['is_raw_format'] = false;
		$base['email_to']      = $this->resolve_recipient( $form_id );
		$base['subject']       = sprintf(
			/* translators: %s: {form_title} smart tag, replaced with the form's title. */
			__( '%s — new partial entry', 'sureforms-pro' ),
			'{form_title}'
		);
		$base['email_body'] = '{all_data}<p><a href="' . esc_url( $admin_link ) . '">' . esc_html__( 'View partial entry in the dashboard', 'sureforms-pro' ) . '</a></p>';

		return $base;
	}

	/**
	 * Resolve the recipient for a form's partial-entry notification, in order:
	 * the form's configured "Send to" override, then the form's own notification
	 * "email to", then the site admin email.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return string
	 */
	private function resolve_recipient( $form_id ) {
		$form_id  = absint( $form_id );
		$settings = Init::get_notify_settings( $form_id );

		// 1. Explicit "Send to" override.
		$recipient = sanitize_email( Helper::get_string_value( $settings['notify_recipient'] ?? '' ) );
		if ( is_email( $recipient ) ) {
			return $recipient;
		}

		// 2. The form's own notification "email to" (first active notification).
		$form_notify = $this->get_form_notification_email( $form_id );
		if ( is_email( $form_notify ) ) {
			return $form_notify;
		}

		// 3. Site admin.
		$admin_email = sanitize_email( Helper::get_string_value( get_option( 'admin_email' ) ) );
		return is_email( $admin_email ) ? $admin_email : '';
	}

	/**
	 * The literal "email to" address of a form's first active email notification,
	 * or '' when none is a plain address (e.g. it uses a smart tag) — in which
	 * case the caller falls back to the site admin.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return string
	 */
	private function get_form_notification_email( $form_id ) {
		$notifications = get_post_meta( absint( $form_id ), '_srfm_email_notification' );
		if ( ! is_iterable( $notifications ) ) {
			return '';
		}

		foreach ( $notifications as $notification ) {
			if ( ! is_iterable( $notification ) ) {
				continue;
			}
			foreach ( $notification as $item ) {
				if ( ! is_array( $item ) || empty( $item['status'] ) ) {
					continue;
				}
				$candidate = sanitize_email( Helper::get_string_value( $item['email_to'] ?? '' ) );
				if ( is_email( $candidate ) ) {
					return $candidate;
				}
			}
		}

		return '';
	}

	/**
	 * Build an admin URL for the Partial Entries screen. When a row UUID is
	 * supplied, deep-links to that entry via the SPA's HashRouter route
	 * (`#/entry/{uuid}`); otherwise links to the list.
	 *
	 * @param string $uuid Optional partial row UUID.
	 * @since 2.12.3
	 * @return string
	 */
	private function admin_entry_url( $uuid = '' ) {
		$base = admin_url( 'admin.php?page=' . Init::PAGE_SLUG );
		$uuid = sanitize_text_field( $uuid );
		if ( '' !== $uuid ) {
			return $base . '#/entry/' . rawurlencode( $uuid );
		}
		return $base;
	}

	/**
	 * Whether this form has hit its per-day abandonment-email cap.
	 *
	 * Bounds the mail a single form can emit per day so a public form flooded with
	 * distinct-session partial rows can't be turned into a mail relay. Filterable
	 * via `srfm_partial_entry_notify_daily_cap`; a cap of 0 (or less) disables it.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return bool
	 */
	private function daily_cap_reached( $form_id ) {
		/**
		 * Filter the per-form daily cap on partial-entry abandonment emails.
		 *
		 * @param int $cap     Maximum emails per form per day. 0 disables the cap.
		 * @param int $form_id Form post ID.
		 * @since 2.12.3
		 */
		$cap = (int) apply_filters( 'srfm_partial_entry_notify_daily_cap', 100, absint( $form_id ) );
		if ( $cap <= 0 ) {
			return false;
		}

		return $this->get_daily_count( $form_id ) >= $cap;
	}

	/**
	 * Read the per-form daily send counter.
	 *
	 * Must read from wherever bump_daily_count() wrote, so both go through this.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return int
	 */
	private function get_daily_count( $form_id ) {
		$key = $this->daily_count_key( $form_id );

		if ( wp_using_ext_object_cache() ) {
			return absint( wp_cache_get( $key, 'srfm_pe_notify' ) );
		}

		return absint( get_transient( $key ) );
	}

	/**
	 * Increment the per-form daily send counter (rolls over each UTC day).
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return void
	 */
	private function bump_daily_count( $form_id ) {
		$key = $this->daily_count_key( $form_id );

		// Seed-then-increment, mirroring the rate limiter. wp_cache_add() only writes when
		// the key is absent and wp_cache_incr() is atomic, so concurrent Action Scheduler
		// workers cannot lose counts between them — unlike a get/+1/set, where every
		// worker reads the same value and writes the same +1. Seeding with 0 rather than
		// 1 keeps the count correct when several workers race the seed: the add succeeds
		// once, and every worker (winner included) then increments exactly once.
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, 'srfm_pe_notify', DAY_IN_SECONDS );
			wp_cache_incr( $key, 1, 'srfm_pe_notify' );
			return;
		}

		// No persistent object cache: transients are option rows, and add_option() is the
		// only atomic primitive available (the option name is UNIQUE, so exactly one
		// concurrent caller creates it). It cannot make the read-modify-write itself
		// atomic, so a small undercount under heavy concurrency remains possible; the cap
		// is an anti-abuse bound rather than an accounting figure, and the per-entry
		// throttle plus the one-pending-action rule are the primary ceilings.
		set_transient( $key, absint( get_transient( $key ) ) + 1, DAY_IN_SECONDS );
	}

	/**
	 * Give back a slot reserved by bump_daily_count() when the send did not happen.
	 *
	 * The count is taken BEFORE wp_mail() so a fatal or timeout cannot drift the ceiling
	 * upward — but a plain `false` return is a *handled* failure that is going to be
	 * retried, so leaving the slot consumed would let one broken mail transport eat the
	 * whole day. SMTP outages are global rather than per-row: with the default cap of 100
	 * and MAX_RETRIES retries per row, only a handful of rows would otherwise exhaust the
	 * form's entire daily allowance without a single delivered email, and the window only
	 * resets at UTC midnight. Releasing here keeps the retry chain self-healing, and a
	 * genuine fatal still skips this call — which is the safe direction.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return void
	 */
	private function unbump_daily_count( $form_id ) {
		$key = $this->daily_count_key( $form_id );

		// Never write a negative count. WP's own object cache floors decr() at 0, but a
		// Redis drop-in issues DECRBY, which on a key evicted between the bump and this
		// call creates it at -1. get_daily_count() reads through absint(), so a stored -1
		// would come back as 1 and make the cap trip EARLIER — suppressing notifications
		// rather than loosening them. Check before decrementing so that cannot happen.
		if ( wp_using_ext_object_cache() ) {
			if ( absint( wp_cache_get( $key, 'srfm_pe_notify' ) ) > 0 ) {
				wp_cache_decr( $key, 1, 'srfm_pe_notify' );
			}
			return;
		}

		$current = absint( get_transient( $key ) );
		if ( 0 === $current ) {
			return;
		}

		set_transient( $key, $current - 1, DAY_IN_SECONDS );
	}

	/**
	 * Transient key for the per-form daily send counter, namespaced by UTC date.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return string
	 */
	private function daily_count_key( $form_id ) {
		return 'srfm_pe_notify_' . absint( $form_id ) . '_' . gmdate( 'Ymd' );
	}
}
