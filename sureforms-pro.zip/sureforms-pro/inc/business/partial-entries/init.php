<?php
/**
 * Partial Entries — Init.
 *
 * Wires up the whole Partial Entries surface: the public save endpoint,
 * the admin list/detail/delete endpoints, the admin submenu, asset
 * enqueue (frontend capture + admin SPA), and the cleanup hook that
 * deletes an in-progress row once the form is actually submitted.
 *
 * POC scope — deliberately minimal:
 *  - no email abandonment notifications
 *  - no scheduled cleanup cron
 *  - no CSV export, notes, or activity log
 *
 * @package sureforms-pro
 * @since   2.9.0
 */

namespace SRFM_Pro\Inc\Business\Partial_Entries;

use SRFM\Admin\Admin as Core_Admin;
use SRFM\Inc\Helper;
use SRFM\Inc\Submit_Token;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Save_Resume;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Partial Entries Init class.
 *
 * @since 2.9.0
 */
class Init {
	use Get_Instance;

	/**
	 * Admin submenu slug.
	 *
	 * @since 2.9.0
	 */
	public const PAGE_SLUG = 'sureforms_partial_entries';

	/**
	 * Maximum per-page for list endpoint — guards against heavy queries.
	 *
	 * @since 2.9.0
	 */
	public const MAX_PER_PAGE = 100;

	/**
	 * Allowed orderby columns for the list endpoint.
	 *
	 * @since 2.9.0
	 */
	public const ALLOWED_ORDERBY = [ 'id', 'form_id', 'date_created', 'updated_at', 'progress_percent' ];

	/**
	 * Post meta key that stores the per-form feature toggle (JSON:
	 * `{"status":bool}`). Kept in sync with the JS settings module.
	 *
	 * @since 2.9.0
	 */
	public const META_KEY = '_srfm_partial_entries';

	/**
	 * Maximum accepted payload size (bytes) on the public save
	 * endpoint. Stops a runaway signature / base64 paste / huge
	 * textarea from blowing up a row. 64 KB is comfortable for a
	 * fully-filled form but refuses binary blobs.
	 *
	 * @since 2.9.0
	 */
	public const MAX_PAYLOAD_BYTES = 64 * 1024;

	/**
	 * Per-IP rate limit on the public save endpoint. Caps at
	 * `RATE_LIMIT_MAX` saves per `RATE_LIMIT_WINDOW` seconds per
	 * remote address. Sized around the expected normal cadence —
	 * one save per ~2.5 s (MIN_SAVE_INTERVAL on the client) plus
	 * headroom for multiple tabs and the occasional pagehide.
	 *
	 * @since 2.9.0
	 */
	public const RATE_LIMIT_MAX    = 60;
	public const RATE_LIMIT_WINDOW = 60; // seconds.

	/**
	 * Transient key caching the "is any form on this site enabled?"
	 * check. Saves the postmeta LIKE scan on every page load.
	 *
	 * @since 2.9.0
	 */
	public const ANY_ENABLED_TRANSIENT = 'srfm_partial_any_enabled';

	/**
	 * Constructor.
	 *
	 * @since 2.9.0
	 */
	public function __construct() {
		// Per-form enable/disable toggle, persisted as a JSON post_meta.
		// Hooked on the core "register additional meta" action so we
		// register at the same tick as Save & Resume / webhooks —
		// avoids any ordering edge cases with the post-type's own
		// meta registration pass.
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_form_meta' ] );

		// Gutenberg form-settings panel (sidebar toggle).
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ] );

		// Frontend capture asset — enqueued on every form-rendering page,
		// piggybacks on the core `srfm-form-submit` handle.
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_assets' ], 20 );

		// Server-side resume — mirror Save & Resume's pattern: decode the
		// pe_token / read the cookie, look up the entry, and localize
		// `srfmResumeData` so SaveResumeFrontend.initResume() hydrates the
		// form on its own. Priority 20 runs after Save & Resume's own
		// enqueue (default priority 10) so the script handle exists.
		add_action( 'srfm_enqueue_block_scripts', [ $this, 'localize_partial_resume_data' ], 20 );

		// Admin screen — submenu + SPA asset.
		add_action( 'admin_menu', [ $this, 'register_menu' ], 30 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
		add_filter( 'srfm_is_dashboard_screen', [ $this, 'add_partial_entries_screen' ] );
		add_filter( 'srfm_admin_filter', [ $this, 'add_partial_entries_nav_item' ] );

		// REST endpoints.
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_rest_endpoints' ] );

		// Map partial-entries ZIP exports to a friendlier download name.
		add_filter( 'srfm_export_zip_filename', [ $this, 'filter_export_zip_filename' ], 10, 2 );

		// Cleanup on successful submit — prevents a partial row from
		// outliving the completed entry it represents. Verified
		// via the server-issued srfm_partial_delete_token before
		// any row is removed.
		add_action( 'srfm_form_submit', [ $this, 'delete_partial_on_submit' ] );

		// NOTE: time-based auto-deletion is intentionally OFF.
		// Partial entries persist until either (a) the form is
		// successfully submitted (on-submit cleanup above) or
		// (b) an admin removes them via the Partial Entries screen.

		// Bust the "any form enabled" transient whenever our toggle
		// meta changes — so flipping the switch takes effect on the
		// frontend without waiting for the 15-minute TTL.
		$bust = function ( $meta_id, $post_id, $meta_key ) {
			unset( $meta_id, $post_id );
			$this->bust_any_enabled_transient( $meta_key );
		};
		add_action( 'updated_post_meta', $bust, 10, 3 );
		add_action( 'added_post_meta', $bust, 10, 3 );
		add_action( 'deleted_post_meta', $bust, 10, 3 );

		// Cascade-delete partial rows when their parent form (post) is
		// removed. Without this, orphan rows accumulate indefinitely
		// on long-lived sites — listing endpoints would keep showing
		// entries for forms whose post no longer exists.
		add_action( 'before_delete_post', [ $this, 'delete_partials_for_form' ] );

		// Abandonment notifications — instantiate so its Action
		// Scheduler + submit-cancel hooks register.
		Partial_Entry_Notifier::get_instance();
	}

	/**
	 * Delete every partial row attached to a form when the form
	 * post is permanently removed. Hooked to `before_delete_post`
	 * so the cleanup runs while the post id is still valid.
	 *
	 * @since 2.9.0
	 * @param int $post_id Post id about to be deleted.
	 * @return void
	 */
	public function delete_partials_for_form( $post_id ) {
		$post_id = absint( $post_id );
		if ( 0 === $post_id ) {
			return;
		}
		if ( SRFM_FORMS_POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		global $wpdb;
		$table = Save_Resume::get_instance()->get_tablename();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- cascade delete on a single form id.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE form_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- internal table name.
				$post_id
			)
		);
	}

	/**
	 * Delete the `any form enabled` transient when our toggle meta
	 * changes on any form. Called via closure from `updated_post_meta` /
	 * `added_post_meta` / `deleted_post_meta`.
	 *
	 * @param string $meta_key Meta key.
	 * @since 2.9.0
	 * @return void
	 */
	public function bust_any_enabled_transient( $meta_key ) {
		if ( self::META_KEY !== $meta_key ) {
			return;
		}
		delete_transient( self::ANY_ENABLED_TRANSIENT );
	}

	/**
	 * Register the `_srfm_partial_entries` post_meta so the form
	 * editor can read/write the toggle via useEntityProp.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function register_form_meta() {
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			self::META_KEY,
			[
				'type'              => 'string',
				'single'            => true,
				// 'edit' only — never 'view'. This blob holds the notification
				// recipient address; exposing it in the public 'view' REST context
				// would leak the address (and the admin fallback) to anonymous
				// callers of /wp/v2/sureforms_form. Mirrors the free plugin's
				// _srfm_email_notification, which is 'edit'-only for the same reason.
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'default'           => wp_json_encode( self::get_notify_defaults() ),
				'sanitize_callback' => static function ( $value ) {
					// Value may arrive as a JSON string (Gutenberg
					// useEntityProp path) or as an already-decoded
					// array (direct REST writes / CLI). Handle both.
					$decoded = $value;
					if ( is_string( $value ) ) {
						$parsed  = json_decode( $value, true );
						$decoded = is_array( $parsed ) ? $parsed : [];
					}
					if ( ! is_array( $decoded ) ) {
						$decoded = [];
					}

					// "Send to" override. Keep a valid submitted address; otherwise
					// store '' (meaning "use the form's notification email, then the
					// site admin" — resolved at send time). Never bake in admin_email:
					// this value is persisted and would otherwise leak, and an empty
					// field must mean "use default", not "mail the admin". Rewriting
					// '' to the admin address here would also silently re-route any
					// form that deliberately relied on the notification-email fallback,
					// the moment someone opened and saved this tab.
					$recipient = '';
					if ( isset( $decoded['notify_recipient'] ) ) {
						$candidate = sanitize_email( Helper::get_string_value( $decoded['notify_recipient'] ) );
						$recipient = is_email( $candidate ) ? $candidate : '';
					}

					$clean = [
						'status'           => isset( $decoded['status'] )
							? wp_validate_boolean( $decoded['status'] )
							: false,
						'resume'           => isset( $decoded['resume'] )
							? wp_validate_boolean( $decoded['resume'] )
							: false,
						'notify'           => isset( $decoded['notify'] )
							? wp_validate_boolean( $decoded['notify'] )
							: false,
						'notify_recipient' => $recipient,
					];
					return wp_json_encode( $clean );
				},
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
			]
		);
	}

	/**
	 * Default values for the `_srfm_partial_entries` meta blob. Kept in
	 * one place so the meta `default`, the sanitize callback, and
	 * `get_notify_settings()` all agree on shape and fallbacks.
	 *
	 * @since 2.12.3
	 * @return array<string,mixed>
	 */
	public static function get_notify_defaults() {
		// `notify_recipient` intentionally defaults to '' (empty = "use the form's
		// notification email, then the site admin"), and the admin address is NOT baked
		// in here. A registered meta DEFAULT is world-readable regardless of the meta's
		// 'edit' REST context: WP_REST_Meta_Fields copies it into the meta field schema,
		// get_public_item_schema() only strips arg_options from TOP-LEVEL properties, and
		// rest_handle_options_request() runs on rest_pre_dispatch — before any
		// permission_callback. So an unauthenticated `OPTIONS /wp/v2/sureforms_form`
		// would echo the address back under
		// schema.properties.meta.properties._srfm_partial_entries.default.
		// The same value would also ride along in exported form JSON, which is meant to
		// be shared. The editor prefills the field from a localised placeholder instead
		// (see the partial-entries settings script), and resolve_recipient() applies the
		// real fallbacks at send time.
		return [
			'status'           => false,
			'resume'           => false,
			'notify'           => false,
			'notify_recipient' => '',
		];
	}

	/**
	 * Read the abandonment-notification settings for a form, merged
	 * over the defaults so callers always get a complete array.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return array<string,mixed>
	 */
	public static function get_notify_settings( $form_id ) {
		$defaults = self::get_notify_defaults();
		$form_id  = absint( $form_id );
		if ( 0 === $form_id ) {
			return $defaults;
		}
		$raw = get_post_meta( $form_id, self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return $defaults;
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return $defaults;
		}
		return array_merge( $defaults, $decoded );
	}

	/**
	 * Whether per-entry abandonment notifications are active for a form.
	 * Requires capture (status) to also be on — notifying without
	 * capturing is a no-op.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.12.3
	 * @return bool
	 */
	public static function is_notify_enabled( $form_id ) {
		$settings = self::get_notify_settings( $form_id );
		return ! empty( $settings['status'] ) && ! empty( $settings['notify'] );
	}

	/**
	 * Enqueue the Gutenberg sidebar settings panel (toggle tab).
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function enqueue_editor_assets() {
		// Only load on the SureForms form post-type editor.
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || SRFM_FORMS_POST_TYPE !== $screen->post_type ) {
			return;
		}

		$handle = 'package/business/srfmPartialEntriesSettings';
		$asset  = SRFM_PRO_DIR . 'dist/' . $handle . '.asset.php';
		$info   = file_exists( $asset )
			? include $asset
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-partial-entries-settings',
			SRFM_PRO_URL . 'dist/' . $handle . '.js',
			$info['dependencies'],
			$info['version'],
			true
		);

		// Surface where an empty "Send to" actually resolves, as editor HELP TEXT only —
		// never as the registered meta default, which WP publishes through the
		// unauthenticated OPTIONS schema and which rides along in exported form JSON
		// (see get_notify_defaults()).
		//
		// Resolved through the notifier's own chain rather than get_option('admin_email'):
		// a form with its own notification recipient does NOT fall back to the admin, so
		// showing the admin address here would misreport the common case.
		//
		// Gated explicitly rather than relying on the CPT's manage_options mapping — that
		// mapping lives in the free plugin and is reachable by third-party role filters,
		// and the whole point of this change is that the address should not leak.
		$default_recipient = Helper::current_user_can()
			? Partial_Entry_Notifier::get_instance()->get_default_recipient( absint( get_the_ID() ) )
			: '';

		wp_localize_script(
			SRFM_PRO_SLUG . '-partial-entries-settings',
			'srfmPartialEntriesSettings',
			[
				'defaultRecipient' => is_email( $default_recipient ) ? $default_recipient : '',
			]
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-partial-entries-settings' );
	}

	/**
	 * Check whether partial entry capture is enabled for a given form.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.9.0
	 * @return bool
	 */
	public static function is_enabled_for_form( $form_id ) {
		$form_id = absint( $form_id );
		if ( 0 === $form_id ) {
			return false;
		}
		$raw = get_post_meta( $form_id, self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return false;
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) && ! empty( $decoded['status'] );
	}

	/**
	 * Check whether the "Resume from last step" toggle is on for a given form.
	 * Requires capture (status) to also be enabled — resume without capture
	 * is a no-op.
	 *
	 * @param int $form_id Form post ID.
	 * @since 2.9.0
	 * @return bool
	 */
	public static function is_resume_enabled_for_form( $form_id ) {
		if ( ! self::is_enabled_for_form( $form_id ) ) {
			return false;
		}
		$raw = get_post_meta( absint( $form_id ), self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return false;
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) && ! empty( $decoded['resume'] );
	}

	/**
	 * Cheap site-wide check: is any form's `_srfm_partial_entries`
	 * meta currently `status:true`? Cached for 15 minutes. Busted by
	 * the `update_post_meta` / `add_post_meta` hooks for our meta
	 * key so toggling a form takes effect immediately.
	 *
	 * Returning false short-circuits the frontend enqueue — no JS,
	 * no heartbeat, nothing — on sites that haven't turned the
	 * feature on for any form yet.
	 *
	 * @since 2.9.0
	 * @return bool
	 */
	public static function any_form_enabled() {
		$cached = get_transient( self::ANY_ENABLED_TRANSIENT );
		if ( false !== $cached ) {
			return 'yes' === $cached;
		}

		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- cached in transient for 15 min; cheap LIKE scan on postmeta indexed by meta_key.
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s LIMIT 1",
				self::META_KEY,
				'%"status":true%'
			)
		);

		$enabled = ! empty( $found );
		set_transient( self::ANY_ENABLED_TRANSIENT, $enabled ? 'yes' : 'no', 15 * MINUTE_IN_SECONDS );
		return $enabled;
	}

	/**
	 * Enqueue the frontend capture script.
	 *
	 * Registers as a dependency of `srfm-form-submit` + `heartbeat` so
	 * it loads only on pages with a SureForms form and has access to
	 * WP's heartbeat tick.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function enqueue_frontend_assets() {
		if ( is_admin() ) {
			return;
		}

		// Site-wide opt-out: if no form has the toggle on, skip the
		// entire asset bundle + heartbeat. Saves ~5 KB + an extra
		// wp.heartbeat instance on every frontend page. Cached via
		// transient so this costs ~0 on warm hits.
		if ( ! self::any_form_enabled() ) {
			return;
		}

		wp_enqueue_script( 'heartbeat' );

		$asset_handle      = 'partialEntries';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		// Always include srfm-form-submit + heartbeat + jquery so this
		// script can assume the heartbeat tick and the form's HMAC
		// token are both available.
		//
		// We intentionally do NOT declare sureforms-pro-save-resume-frontend
		// as a dep here: this script is enqueued site-wide on
		// wp_enqueue_scripts, but the save-resume bundle is registered
		// per-form on srfm_enqueue_block_scripts. Declaring an unregistered
		// dep would emit doing_it_wrong on pages that render no
		// resume-capable form. Load order is already safe because the
		// /partial-entries/restore fetch always resolves after
		// DOMContentLoaded, by which time SaveResumeFrontend has
		// instantiated itself on window.
		$dependencies = array_unique(
			array_merge(
				(array) $script_info['dependencies'],
				[ 'srfm-form-submit', 'heartbeat', 'jquery' ]
			)
		);

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$dependencies,
			$script_info['version'],
			true
		);

		wp_localize_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'srfm_partial_entries',
			[
				'rest_url'          => esc_url_raw( rest_url( 'sureforms/v1/partial-entries/save' ) ),
				'restore_url'       => esc_url_raw( rest_url( 'sureforms/v1/partial-entries/restore' ) ),
				'heartbeat_key'     => 'srfm_partial_entry',
				// Blur-debounce interval in ms. Surface so QA can tune during manual testing without a rebuild.
				'blur_debounce'     => 400,
				'cookie_prefix'     => 'srfm_partial_resume_',
				'cookie_days'       => 7,
				'forms_with_resume' => $this->get_forms_with_resume_ids(),
				'save_label'        => __( 'Save & Resume Later', 'sureforms-pro' ),
				'saved_message'     => __( 'Progress saved — return any time on this device.', 'sureforms-pro' ),
			]
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $asset_handle );
	}

	/**
	 * Localize the saved partial entry as `srfmResumeData` for the
	 * Save & Resume frontend bundle.
	 *
	 * Mirrors `Save_Resume\Init::handle_resume_request()` +
	 * `localize_resume_data()`. Source-of-truth lookup is:
	 *   1. `pe_token` URL parameter (admin-shared resume link). Verified
	 *      via `Resume_Token::decode` with the rendered form_id, then
	 *      adopted into the per-form cookie so subsequent saves continue
	 *      the same entry on this device.
	 *   2. `srfm_partial_resume_{form_id}` cookie (returning visitor).
	 *
	 * @hooked srfm_enqueue_block_scripts (priority 20, after Save & Resume's
	 *         enqueue at the default priority 10).
	 *
	 * @param array<string,mixed> $args Block render args; `attr.formId` carries the form id.
	 * @since 2.10.0
	 * @return void
	 */
	public function localize_partial_resume_data( $args ) {
		// Per-request guard: only the first rendered form on the page
		// gets the localize. wp_localize_script defines a global, so a
		// second call would either be skipped (same handle/name) or
		// clobber data for the wrong form.
		static $localized = false;
		if ( $localized ) {
			return;
		}

		$form_id = is_array( $args ) && isset( $args['attr'] ) && is_array( $args['attr'] ) && isset( $args['attr']['formId'] )
			? absint( $args['attr']['formId'] )
			: 0;
		if ( 0 === $form_id || ! self::is_resume_enabled_for_form( $form_id ) ) {
			return;
		}

		// Defer to Save & Resume if its URL token already populated resume
		// data for this request. Same global is consumed by the frontend,
		// so first writer wins.
		if ( ! empty( $GLOBALS['srfm_resume_data'] ) ) {
			return;
		}

		$session_id = '';

		// 1) pe_token URL — admin-shared resume link.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public resume link, validated via HMAC inside Resume_Token::decode().
		if ( isset( $_GET['pe_token'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public resume link, validated via HMAC inside Resume_Token::decode().
			$raw_token = sanitize_text_field( wp_unslash( $_GET['pe_token'] ) );
			$decoded   = Resume_Token::decode( $raw_token, 'resume', $form_id );
			if ( false !== $decoded ) {
				$session_id  = (string) $decoded;
				$cookie_name = 'srfm_partial_resume_' . $form_id;
				// Adopt as cookie so subsequent saves on this device
				// continue this entry. Best-effort: if headers are already
				// sent we skip silently — partial-entries.js will still
				// read the same value because we also seed $_COOKIE so any
				// later in-request reads see the new id.
				$_COOKIE[ $cookie_name ] = $session_id;
				if ( ! headers_sent() ) {
					setcookie(
						$cookie_name,
						$session_id,
						[
							'expires'  => time() + ( 7 * DAY_IN_SECONDS ),
							'path'     => defined( 'COOKIEPATH' ) ? COOKIEPATH : '/',
							'domain'   => defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '',
							'secure'   => is_ssl(),
							'httponly' => false, // partial-entries.js needs read access via document.cookie.
							'samesite' => 'Lax',
						]
					);
				}
			}
		}

		// 2) Cookie fallback — returning visitor.
		if ( '' === $session_id ) {
			$cookie_name = 'srfm_partial_resume_' . $form_id;
			if ( isset( $_COOKIE[ $cookie_name ] ) ) {
				$session_id = substr( sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) ), 0, 64 );
			}
		}

		if ( '' === $session_id ) {
			return;
		}

		$entry = Save_Resume::get_by_session( $session_id, $form_id );
		if ( empty( $entry ) ) {
			return;
		}

		$form_data = Helper::get_array_value( $entry['form_data'] ?? [] );

		// Merge `current_page` into form_data under the step-key that
		// SaveResumeFrontend.restoreFormStep() reads, so multi-step
		// forms jump to the user's last position. Conversational vs
		// page-break is determined per-form via the
		// `_srfm_conversational_form` meta.
		$current_page = absint( $entry['current_page'] ?? 0 );
		if ( $current_page > 0 ) {
			$cf_meta           = get_post_meta( $form_id, '_srfm_conversational_form', true );
			$is_conversational = is_array( $cf_meta )
				&& isset( $cf_meta['is_cf_enabled'] )
				&& filter_var( $cf_meta['is_cf_enabled'], FILTER_VALIDATE_BOOLEAN );
			$step_key          = $is_conversational ? 'conversational-current-step' : 'page-break-current-step';

			$form_data[ $step_key ] = $current_page;
		}

		wp_localize_script(
			SRFM_PRO_SLUG . '-save-resume-frontend',
			'srfmResumeData',
			[
				'formId'   => $form_id,
				// SaveResumeFrontend.populateFormFields calls JSON.parse on
				// this string, mirroring Save & Resume's wire shape.
				'formData' => wp_json_encode( $form_data ),
				// Partial Entry uses srfm_partial_session_id, not
				// srfm_continue_token — pass empty so
				// SaveResumeFrontend.addTokenToForm short-circuits.
				'token'    => '',
				'i18n'     => [],
			]
		);

		$localized = true;
	}

	/**
	 * Register the WP admin submenu under SureForms.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function register_menu() {
		if ( ! Helper::current_user_can() ) {
			return;
		}

		// Use the same capability filter the gate above uses, so a
		// site that overrides Helper::current_user_can() doesn't
		// land on the submenu showing then denying access — the
		// menu and the page must agree.
		$capability = apply_filters( 'srfm_partial_entries_admin_capability', 'manage_options' );

		add_submenu_page(
			'sureforms_menu',
			__( 'Partial Entries', 'sureforms-pro' ),
			__( 'Partial Entries', 'sureforms-pro' ) .
				' <span style="color:#4ADE80;font-size:9px;font-weight:600;">' .
				esc_html__( 'New', 'sureforms-pro' ) .
				'</span>',
			$capability,
			self::PAGE_SLUG,
			[ $this, 'render_page' ],
			6
		);
	}

	/**
	 * Render the admin page root — React SPA mounts here.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function render_page() {
		echo '<div id="srfm-partial-entries-root" class="srfm-admin-wrapper"></div>';
	}

	/**
	 * Flag this screen as a SureForms dashboard screen so core's
	 * admin chrome renders around it.
	 *
	 * @param bool $is_dashboard_screen Current state.
	 * @since 2.9.0
	 * @return bool
	 */
	public function add_partial_entries_screen( $is_dashboard_screen ) {
		if ( $is_dashboard_screen ) {
			return $is_dashboard_screen;
		}

		return Helper::validate_request_context( self::PAGE_SLUG, 'page' );
	}

	/**
	 * Append a Partial Entries nav item to the SureForms admin header.
	 *
	 * @param array<string,mixed> $localization_data Current localization data.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function add_partial_entries_nav_item( $localization_data ) {
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		if ( ! isset( $localization_data['additional_header_nav_items'] ) || ! is_array( $localization_data['additional_header_nav_items'] ) ) {
			$localization_data['additional_header_nav_items'] = [];
		}

		$localization_data['additional_header_nav_items'][] = [
			'slug' => self::PAGE_SLUG,
			'text' => __( 'Partial Entries', 'sureforms-pro' ),
			'link' => get_site_url() . '/wp-admin/admin.php?page=' . self::PAGE_SLUG,
		];

		return $localization_data;
	}

	/**
	 * Enqueue the admin SPA on the Partial Entries screen only.
	 *
	 * @param string $hook_prefix Current admin page hook.
	 * @since 2.9.0
	 * @return void
	 */
	public function enqueue_admin_assets( $hook_prefix ) {
		if ( 'sureforms_page_' . self::PAGE_SLUG !== $hook_prefix ) {
			return;
		}

		$asset_handle      = 'partialEntriesAdmin';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$script_info['dependencies'],
			$script_info['version'],
			true
		);

		$css_file = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.css';
		if ( file_exists( $css_file ) ) {
			wp_enqueue_style(
				SRFM_PRO_SLUG . '-' . $asset_handle,
				SRFM_PRO_URL . 'dist/' . $asset_handle . '.css',
				[],
				SRFM_PRO_VER
			);
		}

		// Mirrors the Quiz Entries enqueue pattern verbatim so the
		// shared `<Header />` component (which reads `srfm_admin`
		// globals at module-load) receives the same keys it does on
		// every other SureForms admin screen.
		$is_license_active = class_exists( '\\SRFM_Pro\\Admin\\Licensing' )
			? \SRFM_Pro\Admin\Licensing::is_license_active()
			: false;

		$localization_data = [
			'site_url'                   => get_site_url(),
			'sureforms_dashboard_url'    => admin_url( '/admin.php?page=sureforms_menu' ),
			'plugin_version'             => defined( 'SRFM_VER' ) ? SRFM_VER : '',
			'global_settings_nonce'      => Helper::current_user_can() ? wp_create_nonce( 'wp_rest' ) : '',
			'is_pro_active'              => Helper::has_pro(),
			'is_license_active'          => $is_license_active,
			'is_first_form_created'      => class_exists( Core_Admin::class ) ? Core_Admin::is_first_form_created() : false,
			'check_three_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold() : false,
			'check_eight_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold( 8 ) : false,
			'pro_plugin_version'         => Helper::has_pro() && defined( 'SRFM_PRO_VER' ) ? SRFM_PRO_VER : '',
			'pro_plugin_name'            => Helper::has_pro() && defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Pro',
			'sureforms_pricing_page'     => Helper::get_sureforms_website_url( 'pricing' ),
		];

		$localization_data = apply_filters( 'srfm_admin_filter', $localization_data );
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		wp_add_inline_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'var srfm_admin = window.srfm_admin || {};',
			'before'
		);

		wp_localize_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'srfm_admin',
			$localization_data
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $asset_handle );
	}

	/**
	 * Register REST endpoints via the core `srfm_rest_api_endpoints` filter.
	 *
	 * @param array<string,mixed> $endpoints Existing endpoints.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function register_rest_endpoints( $endpoints ) {
		// Public save endpoint — protected by the form's HMAC submit
		// token, never by a nonce. Matches the core form-submit pattern
		// and stays cache-safe.
		$endpoints['partial-entries/restore'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_restore_data' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'form_id'    => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
				'session_id' => [
					'sanitize_callback' => static function ( $v ) {
						return substr( sanitize_text_field( wp_unslash( Helper::get_string_value( $v ) ) ), 0, 64 );
					},
				],
				'srfm_token' => [
					'sanitize_callback' => 'sanitize_text_field',
				],
				'pe_token'   => [
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		];

		$endpoints['partial-entries/save'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'save_partial_entry' ],
			'permission_callback' => '__return_true',
		];

		$endpoints['partial-entries/list'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_partial_entries_list' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'  => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
				'orderby'  => [
					'sanitize_callback' => [ $this, 'sanitize_orderby' ],
					'default'           => 'updated_at',
				],
				'order'    => [
					'sanitize_callback' => [ $this, 'sanitize_order' ],
					'default'           => 'DESC',
				],
				'per_page' => [
					'sanitize_callback' => [ $this, 'sanitize_per_page' ],
					'default'           => 20,
				],
				'page'     => [
					'sanitize_callback' => 'absint',
					'default'           => 1,
				],
			],
		];

		$endpoints['partial-entries/forms'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_forms_with_partials' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
		];

		$endpoints['partial-entries/detail'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_partial_entry_detail' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id' => [
					'required'          => true,
					'sanitize_callback' => static function ( $v ) {
						return sanitize_text_field( Helper::get_string_value( $v ) );
					},
				],
			],
		];

		$endpoints['partial-entries/(?P<id>[a-f0-9-]+)/notes'] = [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_entry_notes' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'       => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'per_page' => [
						'sanitize_callback' => [ $this, 'sanitize_per_page' ],
						'default'           => 3,
					],
					'page'     => [
						'sanitize_callback' => 'absint',
						'default'           => 1,
					],
				],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'   => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'note' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_textarea_field',
					],
				],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'      => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return sanitize_text_field( Helper::get_string_value( $v ) );
						},
					],
					'note_id' => [
						'required'          => true,
						'sanitize_callback' => static function ( $v ) {
							return substr( sanitize_text_field( Helper::get_string_value( $v ) ), 0, 64 );
						},
						'validate_callback' => static function ( $v ) {
							return is_string( $v ) && '' !== $v && strlen( $v ) <= 64;
						},
					],
				],
			],
		];

		$endpoints['partial-entries/delete'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'delete_partial_entries' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'ids' => [
					'required'          => true,
					'sanitize_callback' => [ $this, 'sanitize_ids' ],
				],
			],
		];

		$endpoints['partial-entries/export'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'export_partial_entries' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'entry_ids' => [
					'sanitize_callback' => [ $this, 'sanitize_ids' ],
					'default'           => [],
				],
				'form_id'   => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Save (upsert) a partial entry from the frontend capture script.
	 *
	 * Authenticated via the form's HMAC submit token — see
	 * `SRFM\Inc\Submit_Token`. No nonce is used (nor expected) because
	 * the endpoint must work on fully cached pages where no session
	 * cookie is set.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function save_partial_entry( WP_REST_Request $request ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- HMAC token auth, not nonce. See Submit_Token.
		$raw_body = $request->get_body();

		// Per-IP rate limit. Comes BEFORE size check + sanitize so a
		// flood of tiny / oversize / malformed requests can't churn
		// CPU on parsing. Uses WP transients — works on any host;
		// drop to object cache when available.
		$rate_check = $this->check_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		// Payload-size guard. Refuse anything over MAX_PAYLOAD_BYTES
		// before we even sanitize — stops a runaway signature /
		// base64 paste from ballooning a row or occupying PHP
		// parsing cycles. 413 is the correct RFC status.
		if ( is_string( $raw_body ) && strlen( $raw_body ) > self::MAX_PAYLOAD_BYTES ) {
			return new WP_Error(
				'srfm_partial_payload_too_large',
				__( 'Partial entry payload is too large.', 'sureforms-pro' ),
				[ 'status' => 413 ]
			);
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$form_id      = isset( $params['form_id'] ) ? absint( $params['form_id'] ) : 0;
		$submit_token = isset( $params['submit_token'] ) ? Helper::get_string_value( $params['submit_token'] ) : '';
		$session_id   = isset( $params['session_id'] ) ? substr( sanitize_text_field( Helper::get_string_value( $params['session_id'] ) ), 0, 64 ) : '';
		$form_data    = isset( $params['form_data'] ) && is_array( $params['form_data'] ) ? $params['form_data'] : [];

		if ( 0 === $form_id || '' === $session_id ) {
			return new WP_Error( 'srfm_partial_invalid', __( 'Missing form or session identifier.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		if ( ! Submit_Token::verify( $submit_token, $form_id ) ) {
			return new WP_Error( 'srfm_partial_auth', __( 'Invalid submission token.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		// Respect the per-form toggle. Silently succeed when disabled
		// so no-op traffic from stale cached scripts doesn't surface
		// as an error to users.
		if ( ! self::is_enabled_for_form( $form_id ) ) {
			return [
				'success' => true,
				'skipped' => true,
			];
		}

		$current_page     = isset( $params['current_page'] ) ? absint( $params['current_page'] ) : 0;
		$progress_percent = isset( $params['progress_percent'] ) ? max( 0, min( 100, absint( $params['progress_percent'] ) ) ) : 0;

		$trigger = isset( $params['last_trigger'] ) ? sanitize_key( Helper::get_string_value( $params['last_trigger'] ) ) : 'input';
		if ( ! in_array( $trigger, Save_Resume::ALLOWED_TRIGGERS, true ) ) {
			$trigger = 'input';
		}

		$sanitized_form_data = $this->sanitize_form_data( $form_data );

		// Don't create a row when no field has a value — prevents ghost
		// entries from heartbeat ticks on forms the user never touched.
		if ( ! $this->has_any_field_value( $sanitized_form_data ) ) {
			return [
				'success' => true,
				'skipped' => true,
			];
		}

		$data = [
			'form_id'          => $form_id,
			'session_id'       => $session_id,
			'form_data'        => $sanitized_form_data,
			'source_url'       => esc_url_raw( wp_get_referer() ? wp_get_referer() : '' ),
			'current_page'     => $current_page,
			'progress_percent' => $progress_percent,
			'last_trigger'     => $trigger,
		];

		$row_id = Save_Resume::upsert( $data );

		if ( false === $row_id ) {
			return new WP_Error( 'srfm_partial_save_failed', __( 'Could not save partial entry.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		// Send the partial-entry notification email for this row on every
		// save/update when per-entry notifications are enabled.
		if ( self::is_notify_enabled( $form_id ) ) {
			Partial_Entry_Notifier::get_instance()->notify_on_save( Helper::get_string_value( $row_id ) );
		}

		// Mint a short-lived signed delete token bound to this
		// (form_id, session_id) pair. The client echoes it back as
		// `srfm_partial_delete_token` on the real form submission
		// so the cleanup hook can verify ownership before deleting
		// — anyone who has merely guessed/leaked the session_id
		// cannot forge this without the server's auth salt.
		return [
			'success'      => true,
			'id'           => Helper::get_string_value( $row_id ),
			'delete_token' => Resume_Token::issue( 'delete', $form_id, $session_id ),
		];
	}

	/**
	 * Return the saved progress for a returning visitor (resume flow).
	 *
	 * Public endpoint — authenticated via the form's HMAC submit token,
	 * same as `save_partial_entry`. Only available when the form's
	 * "Resume from last step" toggle is on.
	 *
	 * Returns only the fields the frontend needs to refill the form:
	 * `form_data` and `current_page`. Everything else (IP, notes,
	 * user_id) is intentionally omitted.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_restore_data( WP_REST_Request $request ) {
		// Per-IP rate limit. Same shared transient bucket as save —
		// a stolen `pe_token` should not be a free oracle for
		// confirming session validity (200 vs 404), and the endpoint
		// returns full PII so DoS-by-restore is also a real risk.
		$rate_check = $this->check_rate_limit();
		if ( is_wp_error( $rate_check ) ) {
			return $rate_check;
		}

		$form_id  = absint( $request->get_param( 'form_id' ) );
		$pe_token = sanitize_text_field( Helper::get_string_value( $request->get_param( 'pe_token' ) ) );

		/*
		 * Two acceptance paths:
		 *   A) Caller supplied `pe_token` — a server-issued resume
		 *      token. We extract the bound (form_id, session_id) and
		 *      verify the HMAC. This is the only path that may be
		 *      reached from a shared resume URL.
		 *   B) Caller supplied `(session_id, srfm_token)` — the
		 *      cookie-driven returning-visitor flow. `srfm_token`
		 *      is a Submit_Token bound to the form.
		 */
		$session_id = '';
		if ( '' !== $pe_token ) {
			if ( 0 === $form_id ) {
				return new WP_Error(
					'srfm_partial_invalid',
					__( 'Missing form identifier.', 'sureforms-pro' ),
					[ 'status' => 400 ]
				);
			}
			// `decode()` extracts the session_id out of the token
			// after verifying the HMAC + expiry — the client never
			// needs to know (or send) the underlying session_id on
			// this path, which is the entire reason the token exists.
			$decoded_session = Resume_Token::decode( $pe_token, 'resume', $form_id );
			if ( false === $decoded_session ) {
				return new WP_Error(
					'srfm_partial_auth',
					__( 'Resume link is invalid or has expired.', 'sureforms-pro' ),
					[ 'status' => 403 ]
				);
			}
			$session_id = $decoded_session;
		} else {
			$session_id   = substr( sanitize_text_field( Helper::get_string_value( $request->get_param( 'session_id' ) ) ), 0, 64 );
			$submit_token = sanitize_text_field( Helper::get_string_value( $request->get_param( 'srfm_token' ) ) );

			if ( 0 === $form_id || '' === $session_id ) {
				return new WP_Error(
					'srfm_partial_invalid',
					__( 'Missing form or session identifier.', 'sureforms-pro' ),
					[ 'status' => 400 ]
				);
			}

			if ( ! Submit_Token::verify( $submit_token, $form_id ) ) {
				return new WP_Error(
					'srfm_partial_auth',
					__( 'Invalid submission token.', 'sureforms-pro' ),
					[ 'status' => 403 ]
				);
			}
		}

		if ( ! self::is_resume_enabled_for_form( $form_id ) ) {
			// Soft-fail with HTTP 200 — every fresh visit pings this
			// endpoint to check for saved progress, and a 404 here would
			// flood the browser console with red error rows for an
			// entirely normal "nothing to restore yet" state.
			return [
				'success' => false,
				'reason'  => 'resume_disabled',
			];
		}

		$entry = Save_Resume::get_by_session( $session_id, $form_id );
		if ( empty( $entry ) ) {
			return [
				'success' => false,
				'reason'  => 'not_found',
			];
		}

		// Audit hook — sites can listen to log redemption attempts
		// (IP, form, redeemed-from-token-yes/no) for compliance.
		do_action( 'srfm_partial_resume_redeemed', $session_id, $form_id, '' !== $pe_token, $this->get_client_ip() );

		return [
			'success'      => true,
			'session_id'   => $session_id,
			'form_data'    => Helper::get_array_value( $entry['form_data'] ?? [] ),
			'current_page' => absint( $entry['current_page'] ?? 0 ),
		];
	}

	/**
	 * List partial entries for the admin screen.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function get_partial_entries_list( WP_REST_Request $request ) {
		$per_page = $this->sanitize_per_page( $request->get_param( 'per_page' ) );
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );
		$form_id  = absint( $request->get_param( 'form_id' ) );

		$where = [];
		if ( $form_id > 0 ) {
			$where['form_id'] = $form_id;
		}

		$total   = Save_Resume::get_instance()->get_total_count( $where );
		$entries = Save_Resume::get_instance()->get_records_by_args(
			[
				'where'   => $where,
				'orderby' => $this->sanitize_orderby( $request->get_param( 'orderby' ) ),
				'order'   => $this->sanitize_order( $request->get_param( 'order' ) ),
				'limit'   => $per_page,
				'offset'  => ( $page - 1 ) * $per_page,
			]
		);

		$entries = is_array( $entries ) ? $entries : [];

		return [
			'entries'      => array_map( [ $this, 'format_entry_for_list' ], $entries ),
			'total'        => $total,
			'per_page'     => $per_page,
			'current_page' => $page,
			'total_pages'  => $per_page ? (int) ceil( $total / $per_page ) : 1,
		];
	}

	/**
	 * Fetch a single partial entry for the detail view.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	/**
	 * Get paginated notes for a partial entry. Mirrors the shape of
	 * the Quiz notes endpoint so the admin UI can reuse the same
	 * list / pagination component.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_entry_notes( WP_REST_Request $request ) {
		$id       = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$per_page = $this->sanitize_per_page( $request->get_param( 'per_page' ) );
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );

		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		usort(
			$notes,
			static function ( $a, $b ) {
				return ( $b['timestamp'] ?? 0 ) - ( $a['timestamp'] ?? 0 );
			}
		);

		$total       = count( $notes );
		$total_pages = $per_page ? (int) ceil( $total / $per_page ) : 1;
		$offset      = ( $page - 1 ) * $per_page;
		$slice       = array_slice( $notes, $offset, $per_page );

		$formatted = [];
		foreach ( $slice as $note ) {
			if ( ! is_array( $note ) ) {
				continue;
			}
			// Legacy notes pre-date the per-note id field. Synthesise a
			// deterministic id from the (note, timestamp) pair so the
			// admin's delete-by-id flow keeps working across pages —
			// the previous `legacy-{$offset+$i}` form mutated with
			// pagination and broke deletion of older notes.
			$fallback_id = 'legacy-' . md5(
				Helper::get_string_value( $note['note'] ?? '' ) . '|' . Helper::get_string_value( $note['timestamp'] ?? '' )
			);
			$formatted[] = [
				'id'          => $note['id'] ?? $fallback_id,
				'note'        => $note['note'] ?? '',
				'timestamp'   => $note['timestamp'] ?? 0,
				'author'      => $note['author'] ?? 0,
				'author_name' => $note['author_name'] ?? __( 'Unknown', 'sureforms-pro' ),
			];
		}

		return [
			'notes'        => $formatted,
			'current_page' => $page,
			'per_page'     => $per_page,
			'total'        => $total,
			'total_pages'  => $total_pages,
		];
	}

	/**
	 * Add a new note to a partial entry.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function add_entry_note( WP_REST_Request $request ) {
		$id      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$content = sanitize_textarea_field( Helper::get_string_value( $request->get_param( 'note' ) ) );

		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}
		if ( '' === $content ) {
			return new WP_Error( 'srfm_partial_note_empty', __( 'Note content is required.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes        = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$current_user = wp_get_current_user();

		$new_note = [
			'id'          => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'srfm-partial-note-', true ),
			'note'        => $content,
			'timestamp'   => time(),
			'author'      => $current_user->ID,
			'author_name' => $current_user->display_name,
		];

		array_unshift( $notes, $new_note );

		if ( false === Save_Resume::update_entry( $id, [ 'notes' => $notes ] ) ) {
			return new WP_Error( 'srfm_partial_note_save_failed', __( 'Could not save note.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		return [ 'success' => true ];
	}

	/**
	 * Delete a specific note by id from a partial entry.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function delete_entry_note( WP_REST_Request $request ) {
		$id      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		$note_id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'note_id' ) ) );

		if ( '' === $id || '' === $note_id ) {
			return new WP_Error( 'srfm_partial_note_invalid', __( 'Entry ID and note ID are required.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		$found = false;
		foreach ( $notes as $index => $note ) {
			if ( isset( $note['id'] ) && Helper::get_string_value( $note['id'] ) === $note_id ) {
				array_splice( $notes, $index, 1 );
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_Error( 'srfm_partial_note_not_found', __( 'Note not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		if ( false === Save_Resume::update_entry( $id, [ 'notes' => $notes ] ) ) {
			return new WP_Error( 'srfm_partial_note_delete_failed', __( 'Could not delete note.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		return [ 'success' => true ];
	}

	/**
	 * Return a `{ form_id => form_title }` map limited to forms that
	 * currently have at least one partial entry row.
	 *
	 * Feeds the admin "form switcher" dropdown so users don't see
	 * every form on the site, only those with abandonment data.
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function get_forms_with_partials() {
		global $wpdb;

		$table = Save_Resume::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is from internal class config; admin-only listing endpoint, caching via HTTP layer is sufficient for POC.
		$form_ids = $wpdb->get_col( "SELECT DISTINCT form_id FROM {$table} WHERE form_id > 0 ORDER BY form_id DESC" );

		$map = [];
		if ( is_array( $form_ids ) ) {
			foreach ( $form_ids as $form_id ) {
				$id = absint( $form_id );
				if ( 0 === $id ) {
					continue;
				}
				// 'raw' + cast, deliberately: the default 'display' context runs the
				// post_title filter, which is a documented public filter that WPML, SEO
				// and product-title plugins do hook — any of them can reintroduce
				// entity-encoded punctuation or inject markup into this payload. The cast
				// is required because get_post_field() returns int|string|int[], while this
				// method declares array<int,string>.
				$title      = (string) get_post_field( 'post_title', $id, 'raw' );
				$map[ $id ] = $title
					? $title
					/* translators: %d: form post ID */
					: sprintf( __( 'SureForms Form #%d', 'sureforms-pro' ), $id );
			}
		}

		return $map;
	}

	/**
	 * Fetch a single partial entry for the detail view.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_partial_entry_detail( WP_REST_Request $request ) {
		$id = sanitize_text_field( Helper::get_string_value( $request->get_param( 'id' ) ) );
		if ( '' === $id ) {
			return new WP_Error( 'srfm_partial_invalid_id', __( 'Invalid entry ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$entry = Save_Resume::get( $id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'srfm_partial_not_found', __( 'Partial entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		// Adjacent IDs for Prev/Next navigation on the detail page.
		// Scoped to the same form so navigation stays inside one
		// form's partials — mirrors the Entries detail behaviour.
		$navigation = Save_Resume::get_adjacent_ids( $id, absint( $entry['form_id'] ?? 0 ) );

		return [
			'entry'      => $this->format_entry_for_detail( $entry ),
			'navigation' => [
				'previous_id' => $navigation['previous_id'] ?? null,
				'next_id'     => $navigation['next_id'] ?? null,
			],
		];
	}

	/**
	 * Delete one or more partial entries.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function delete_partial_entries( WP_REST_Request $request ) {
		$ids = (array) $request->get_param( 'ids' );
		if ( empty( $ids ) ) {
			return [
				'success' => false,
				'deleted' => 0,
			];
		}

		$deleted = 0;
		foreach ( $ids as $id ) {
			$id = sanitize_text_field( Helper::get_string_value( $id ) );
			if ( '' === $id ) {
				continue;
			}
			if ( false !== Save_Resume::delete_entry( $id ) ) {
				$deleted++;
			}
		}

		return [
			'success' => $deleted > 0,
			'deleted' => $deleted,
		];
	}

	/**
	 * Delete any partial row tied to the submitting session once the
	 * full form submission has succeeded. Hooked after core persists
	 * the real entry, so a row appears in `sureforms_entries` whether
	 * or not the partial existed.
	 *
	 * @param array<string,mixed> $response Submission response.
	 * @since 2.9.0
	 * @return void
	 */
	public function delete_partial_on_submit( $response ) {
		if ( ! is_array( $response ) || empty( $response['success'] ) ) {
			return;
		}

		$form_id = isset( $response['form_id'] ) ? absint( $response['form_id'] ) : 0;
		if ( 0 === $form_id ) {
			return;
		}

		// Prefer the parsed REST body (works for JSON submissions);
		// fall back to $_POST for legacy multipart form posts. Both
		// values are client-controlled so we MUST verify ownership
		// via the signed delete token below before acting on them.
		$session_id   = '';
		$delete_token = '';
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- form submission is HMAC-token authenticated upstream by the core form-submit handler; values are also re-verified via Resume_Token::verify a few lines below.
		if ( isset( $response['srfm_partial_session_id'] ) ) {
			$session_id = substr( sanitize_text_field( Helper::get_string_value( $response['srfm_partial_session_id'] ) ), 0, 64 );
		} elseif ( isset( $_POST['srfm_partial_session_id'] ) ) {
			$session_id = substr( sanitize_text_field( wp_unslash( (string) $_POST['srfm_partial_session_id'] ) ), 0, 64 );
		}
		if ( isset( $response['srfm_partial_delete_token'] ) ) {
			$delete_token = sanitize_text_field( Helper::get_string_value( $response['srfm_partial_delete_token'] ) );
		} elseif ( isset( $_POST['srfm_partial_delete_token'] ) ) {
			$delete_token = sanitize_text_field( wp_unslash( (string) $_POST['srfm_partial_delete_token'] ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $session_id ) {
			return;
		}

		// Without a verified delete-token the session_id is just a
		// claim — possibly forged by anyone who learned a victim's
		// id. Refuse to delete in that case rather than silently
		// dropping the victim's saved partial.
		if ( '' === $delete_token || ! Resume_Token::verify( $delete_token, 'delete', $form_id, $session_id ) ) {
			return;
		}

		Save_Resume::delete_by_session( $session_id, $form_id );
	}

	/**
	 * Shape a raw DB row into a list-friendly response.
	 *
	 * @param array<string,mixed> $entry Raw DB row.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function format_entry_for_list( $entry ) {
		$form_id = absint( $entry['form_id'] ?? 0 );
		// Matches Entries' `form_permalink` shape: the post permalink
		// of the form, which — when the form has "Instant Form"
		// enabled — is the instant form page URL (core's
		// `template_redirect` → `srfm_instant_form_redirect`
		// resolves it). An empty string when the form has been
		// deleted so the client can fall back to a plain span.
		$permalink = $form_id ? get_permalink( $form_id ) : '';
		return [
			'id'               => Helper::get_string_value( $entry['id'] ?? '' ),
			'partial_entry_id' => absint( $entry['partial_entry_id'] ?? 0 ),
			'form_id'          => $form_id,
			'form_title'       => $form_id ? (string) get_post_field( 'post_title', $form_id, 'raw' ) : '',
			'form_permalink'   => is_string( $permalink ) ? $permalink : '',
			'current_page'     => absint( $entry['current_page'] ?? 0 ),
			'progress_percent' => absint( $entry['progress_percent'] ?? 0 ),
			'last_trigger'     => Helper::get_string_value( $entry['last_trigger'] ?? '' ),
			'first_value'      => $this->extract_first_value( Helper::get_array_value( $entry['form_data'] ?? [] ) ),
			'date_created'     => Helper::get_string_value( $entry['date_created'] ?? '' ),
			'updated_at'       => Helper::get_string_value( $entry['updated_at'] ?? $entry['date_created'] ?? '' ),
		];
	}

	/**
	 * Shape a raw DB row into the detail-view response.
	 *
	 * `form_data` is returned as an array of `{label, value,
	 * field_name, block_name}` objects — the same shape core's
	 * `/entry/{id}/details` endpoint emits, so the admin SPA can
	 * render rows without any client-side key parsing.
	 *
	 * @param array<string,mixed> $entry Raw DB row.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	public function format_entry_for_detail( $entry ) {
		$base                   = $this->format_entry_for_list( $entry );
		$base['form_data']      = $this->build_labeled_form_data(
			Helper::get_array_value( $entry['form_data'] ?? [] )
		);
		$base['resume_enabled'] = self::is_resume_enabled_for_form( absint( $entry['form_id'] ?? 0 ) );

		// Mint a server-issued, signed-and-bound resume token in place
		// of returning the raw session_id. The admin UI builds the
		// shareable URL from this token; the restore endpoint
		// resolves it back to the underlying session server-side, so
		// the long-lived session id never leaves the database. The
		// token is non-expiring (ttl=0) by design — admins want the
		// resume link to keep working until the entry itself is
		// cleaned up by the daily retention sweep — but it remains
		// HMAC-bound to the (form_id, session_id) pair so a leaked
		// link is still scoped to a single saved entry.
		$session_id = Helper::get_string_value( $entry['session_id'] ?? '' );
		$form_id    = absint( $entry['form_id'] ?? 0 );
		if ( $base['resume_enabled'] && '' !== $session_id && $form_id > 0 ) {
			$base['resume_token'] = Resume_Token::issue( 'resume', $form_id, $session_id, 0 );
		} else {
			$base['resume_token'] = '';
		}
		return $base;
	}

	/**
	 * Clamp per_page into a sane range.
	 *
	 * @param mixed $per_page Raw value.
	 * @since 2.9.0
	 * @return int
	 */
	public function sanitize_per_page( $per_page ) {
		$per_page = absint( $per_page );
		if ( 0 === $per_page ) {
			$per_page = 20;
		}
		return min( self::MAX_PER_PAGE, max( 1, $per_page ) );
	}

	/**
	 * Validate orderby against the allowlist.
	 *
	 * @param mixed $orderby Raw value.
	 * @since 2.9.0
	 * @return string
	 */
	public function sanitize_orderby( $orderby ) {
		$orderby = sanitize_text_field( Helper::get_string_value( $orderby ) );
		return in_array( $orderby, self::ALLOWED_ORDERBY, true ) ? $orderby : 'updated_at';
	}

	/**
	 * Normalize order direction.
	 *
	 * @param mixed $order Raw value.
	 * @since 2.9.0
	 * @return string
	 */
	public function sanitize_order( $order ) {
		return 'ASC' === strtoupper( sanitize_text_field( Helper::get_string_value( $order ) ) ) ? 'ASC' : 'DESC';
	}

	/**
	 * Accept ids as either JSON string or array, reduce to unique non-empty strings.
	 *
	 * @param mixed $ids Raw ids.
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function sanitize_ids( $ids ) {
		if ( is_string( $ids ) ) {
			$decoded = json_decode( $ids, true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$ids = $decoded;
			}
		}

		if ( ! is_array( $ids ) ) {
			return [];
		}

		$clean = [];
		foreach ( $ids as $id ) {
			$id = sanitize_text_field( Helper::get_string_value( $id ) );
			if ( '' !== $id ) {
				$clean[] = $id;
			}
		}
		return array_values( array_unique( $clean ) );
	}

	/**
	 * Map a partial-entries ZIP export to a friendlier download filename.
	 *
	 * Hooked to core's `srfm_export_zip_filename` filter so the AJAX
	 * downloader can serve both core entries and partial-entries
	 * archives without hardcoding either name.
	 *
	 * @param string              $filename  Default ZIP filename.
	 * @param array<string,mixed> $file_info pathinfo() result for the file being served.
	 * @since 2.9.0
	 * @return string
	 */
	public function filter_export_zip_filename( $filename, $file_info ) {
		$base = is_array( $file_info ) && isset( $file_info['filename'] ) ? Helper::get_string_value( $file_info['filename'] ) : '';
		if ( '' !== $base && str_contains( $base, 'partial' ) ) {
			return 'SureForms Partial Entries.zip';
		}
		return is_string( $filename ) ? $filename : 'SureForms Entries.zip';
	}

	/**
	 * Export partial entries as CSV (single form) or ZIP (multiple forms).
	 *
	 * Mirrors `SRFM\Inc\Rest_Api::export_entries` / `Entries_Class::export_entries`
	 * so the download UX and file-streaming path are identical. Reuses the
	 * existing `srfm_download_export` AJAX action.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @since 2.9.0
	 * @return \WP_REST_Response|WP_Error
	 */
	public function export_partial_entries( WP_REST_Request $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Security verification failed. Please refresh the page and try again.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_ids = Helper::get_array_value( $request->get_param( 'entry_ids' ) );
		$form_id   = absint( $request->get_param( 'form_id' ) );

		// Fetch rows — either the selected subset or all rows for the given form filter.
		if ( ! empty( $entry_ids ) ) {
			$rows = Save_Resume::get_instance()->get_results( [ 'id' => $entry_ids ] );
		} else {
			$where = [];
			if ( $form_id > 0 ) {
				$where['form_id'] = $form_id;
			}
			$rows = Save_Resume::get_instance()->get_records_by_args(
				[
					'where'   => $where,
					'orderby' => 'updated_at',
					'order'   => 'DESC',
				],
				false
			);
		}

		$rows = is_array( $rows ) ? $rows : [];

		if ( empty( $rows ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'No partial entries found to export.', 'sureforms-pro' ) ],
				400
			);
		}

		// Group rows by form_id.
		$rows_by_form = [];
		foreach ( $rows as $row ) {
			$fid = absint( $row['form_id'] ?? 0 );
			if ( ! isset( $rows_by_form[ $fid ] ) ) {
				$rows_by_form[ $fid ] = [];
			}
			$rows_by_form[ $fid ][] = $row;
		}

		$is_single_form = count( $rows_by_form ) === 1;

		$temp_dir = wp_normalize_path( trailingslashit( get_temp_dir() ) );

		if ( ! wp_is_writable( $temp_dir ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Temporary directory is not writable.', 'sureforms-pro' ) ],
				500
			);
		}

		$zip       = null;
		$temp_zip  = '';
		$csv_files = [];

		if ( ! $is_single_form ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'ZipArchive class is not available.', 'sureforms-pro' ) ],
					500
				);
			}
			$temp_zip = $temp_dir . 'srfm-partial-entries-export-' . time() . '.zip';
			$zip      = new \ZipArchive();
			if ( ! $zip->open( $temp_zip, \ZipArchive::CREATE ) ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'Unable to create ZIP file.', 'sureforms-pro' ) ],
					500
				);
			}
		}

		$csv_filepath = '';

		foreach ( $rows_by_form as $fid => $form_rows ) {
			// 'raw' avoids the post_title filter (see get_forms_with_partials()), and the
			// cast keeps sanitize_title() below off a non-string return.
			$form_title           = $fid ? (string) get_post_field( 'post_title', $fid, 'raw' ) : '';
			$sanitized_form_title = sanitize_title( $form_title );
			$sanitized_form_title = ! empty( $sanitized_form_title ) ? $sanitized_form_title : "srfm-partial-entries-{$fid}";
			$csv_filename         = 'srfm-partial-entries-' . $sanitized_form_title . '.csv';
			$csv_filepath         = $temp_dir . $csv_filename;

			if ( file_exists( $csv_filepath ) ) {
				unlink( $csv_filepath ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			}

			$stream = fopen( $csv_filepath, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen
			if ( ! is_resource( $stream ) ) {
				continue;
			}
			$csv_files[] = $csv_filepath;

			// Build field label map from all rows for this form.
			$excluded      = Helper::get_excluded_fields();
			$block_key_map = [];
			$block_labels  = [];
			foreach ( $form_rows as $row ) {
				$form_data = is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [];
				foreach ( $form_data as $srfm_key => $value ) {
					if ( in_array( $srfm_key, $excluded, true ) ) {
						continue;
					}
					$block_id = Helper::get_block_id_from_key( $srfm_key );
					if ( empty( $block_id ) ) {
						continue;
					}
					$block_key_map[ $block_id ] = $srfm_key;
					$block_labels[ $block_id ]  = self::get_export_header_label( $srfm_key );
				}
			}

			// Header row.
			$header = array_merge(
				[
					__( 'Entry ID', 'sureforms-pro' ),
					__( 'Form', 'sureforms-pro' ),
					__( 'Date Created', 'sureforms-pro' ),
					__( 'Last Activity', 'sureforms-pro' ),
					__( 'Progress', 'sureforms-pro' ),
					__( 'Step', 'sureforms-pro' ),
					__( 'Last Trigger', 'sureforms-pro' ),
				],
				array_values( $block_labels )
			);
			fputcsv( $stream, $header ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fputcsv

			// Data rows.
			foreach ( $form_rows as $row ) {
				$form_data = is_array( $row['form_data'] ?? null ) ? $row['form_data'] : [];
				$data_row  = [
					absint( $row['partial_entry_id'] ?? 0 ),
					self::csv_escape_formula( $form_title ),
					self::csv_escape_formula( Helper::get_string_value( $row['date_created'] ?? '' ) ),
					self::csv_escape_formula( Helper::get_string_value( $row['updated_at'] ?? $row['date_created'] ?? '' ) ),
					absint( $row['progress_percent'] ?? 0 ) . '%',
					absint( $row['current_page'] ?? 0 ),
					self::csv_escape_formula( Helper::get_string_value( $row['last_trigger'] ?? '' ) ),
				];

				foreach ( $block_key_map as $srfm_key ) {
					$raw      = $form_data[ $srfm_key ] ?? '';
					$filtered = apply_filters( 'srfm_normalize_csv_field_value', $raw, $srfm_key );
					if ( is_string( $filtered ) && $filtered !== $raw ) {
						$data_row[] = self::csv_escape_formula( $filtered );
					} elseif ( is_array( $raw ) ) {
						$data_row[] = self::csv_escape_formula( implode( ', ', array_map( 'sanitize_text_field', $raw ) ) );
					} else {
						$data_row[] = self::csv_escape_formula( sanitize_text_field( Helper::get_string_value( $raw ) ) );
					}
				}

				fputcsv( $stream, $data_row ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fputcsv
			}

			fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose

			if ( ! $is_single_form && $zip && filesize( $csv_filepath ) > 0 ) {
				$zip->addFile( $csv_filepath, $csv_filename );
			}
		}

		// Single form → return CSV directly.
		if ( $is_single_form && '' !== $csv_filepath && file_exists( $csv_filepath ) ) {
			return new \WP_REST_Response(
				[
					'success'      => true,
					'filename'     => basename( $csv_filepath ),
					'filepath'     => $csv_filepath,
					'type'         => 'csv',
					'download_url' => add_query_arg(
						'_wpnonce',
						wp_create_nonce( 'srfm_download_export' ),
						admin_url( 'admin-ajax.php?action=srfm_download_export&file=' . rawurlencode( basename( $csv_filepath ) ) )
					),
				],
				200
			);
		}

		// Multiple forms → return ZIP.
		if ( ! $is_single_form && $zip ) {
			$zip->close();
			foreach ( $csv_files as $csv_file ) {
				if ( file_exists( $csv_file ) ) {
					unlink( $csv_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				}
			}
			return new \WP_REST_Response(
				[
					'success'      => true,
					'filename'     => 'SureForms Partial Entries.zip',
					'filepath'     => $temp_zip,
					'type'         => 'zip',
					'download_url' => add_query_arg(
						'_wpnonce',
						wp_create_nonce( 'srfm_download_export' ),
						admin_url( 'admin-ajax.php?action=srfm_download_export&file=' . rawurlencode( basename( $temp_zip ) ) )
					),
				],
				200
			);
		}

		return new \WP_REST_Response(
			[ 'error' => __( 'Unable to generate export file.', 'sureforms-pro' ) ],
			400
		);
	}

	/**
	 * Return the IDs of all published forms with the resume toggle enabled.
	 * Used to build the `forms_with_resume` list for the frontend script.
	 *
	 * @since 2.9.0
	 * @return array<int>
	 */
	private function get_forms_with_resume_ids() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- LIKE scan on indexed meta_key; only runs when the feature is active on the site.
		$results = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s",
				self::META_KEY,
				'%"resume":true%'
			)
		);
		return is_array( $results ) ? array_map( 'absint', $results ) : [];
	}

	/**
	 * Transform a raw `field_name => value` map into the labeled
	 * `[{label, value, ...}]` shape expected by the admin UI. The
	 * label-extraction logic intentionally matches core Entries
	 * (`Rest_Api::get_entry_details`) so both screens parse field
	 * names identically.
	 *
	 * @param array<string,mixed> $raw_form_data Decoded form data.
	 * @since 2.9.0
	 * @return array<int,array<string,mixed>>
	 */
	private function build_labeled_form_data( $raw_form_data ) {
		$out = [];

		if ( empty( $raw_form_data ) || ! is_array( $raw_form_data ) ) {
			return $out;
		}

		// Same allowlist of internal keys Entries skips, plus our
		// own session-id hidden input which we never want to show.
		$excluded = [
			'srfm-honeypot-field',
			'g-recaptcha-response',
			'srfm-sender-email-field',
			'srfm_partial_session_id',
			'form-id',
		];

		foreach ( $raw_form_data as $field_name => $value ) {
			if ( ! is_string( $field_name ) || in_array( $field_name, $excluded, true ) ) {
				continue;
			}
			if ( false === strpos( $field_name, '-lbl-' ) ) {
				// Fields without the SureForms `-lbl-` marker are
				// either internal or third-party — skip to match
				// Entries' behaviour.
				continue;
			}

			// `srfm-email-<blockId>-lbl-<base64Label>-<slug>` →
			// base64Label is everything up to the next `-`.
			$label = $this->decode_field_label( $field_name );

			// Repeater rows arrive as a nested array —
			// `{0: {child_name: value, ...}, 1: {...}}` — because the
			// client unfolds `foo[0][bar]` bracket notation into real
			// nested structure. Flatten into one detail-page entry
			// per row, labeled `{Repeater Label} {n}`, with its
			// children listed underneath. Mirrors the rendering
			// Entries produces for real submissions.
			if ( is_array( $value ) && $this->is_repeater_value( $value ) ) {
				$row_index = 0;
				// Sort by numeric key so row order is stable.
				$rows = $value;
				ksort( $rows, SORT_NUMERIC );
				foreach ( $rows as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$row_index++;
					$children = [];
					foreach ( $row as $child_name => $child_value ) {
						if ( ! is_string( $child_name ) || false === strpos( $child_name, '-lbl-' ) ) {
							continue;
						}
						$decoded_child_label = $this->decode_field_label( $child_name );
						$children[]          = [
							'field_name' => $child_name,
							'label'      => $decoded_child_label ? $decoded_child_label : $child_name,
							'value'      => $child_value,
							'block_name' => Helper::get_block_name_from_field( $child_name ),
						];
					}
					$out[] = [
						'field_name' => $field_name . '[' . ( $row_index - 1 ) . ']',
						'label'      => sprintf( '%s %d', '' !== $label ? $label : 'Repeater', $row_index ),
						'value'      => $children,
						'block_name' => 'srfm/repeater-row',
					];
				}
				continue;
			}

			$out[] = [
				'field_name' => $field_name,
				'label'      => '' !== $label ? $label : $field_name,
				'value'      => $value,
				'block_name' => Helper::get_block_name_from_field( $field_name ),
			];
		}

		return $out;
	}

	/**
	 * Extract and decode the SureForms `-lbl-` label from a field
	 * name. Shared by the top-level loop and the repeater-row
	 * recursion.
	 *
	 * @param string $field_name Raw field name (`srfm-<type>-<id>-lbl-<b64>-<slug>`).
	 * @since 2.9.0
	 * @return string Decoded human label, or empty string when the
	 *                name has no `-lbl-` marker or the decode fails.
	 */
	private function decode_field_label( $field_name ) {
		if ( ! is_string( $field_name ) || false === strpos( $field_name, '-lbl-' ) ) {
			return '';
		}
		$parts      = explode( '-lbl-', $field_name );
		$label_part = isset( $parts[1] ) ? explode( '-', $parts[1] )[0] : '';
		$label      = $label_part ? Helper::decrypt( $label_part ) : '';
		return is_string( $label ) ? trim( wp_strip_all_tags( $label ) ) : '';
	}

	/**
	 * Detect a repeater-shaped value: an associative array whose
	 * keys are sequential integer indexes and whose leaves are
	 * themselves associative arrays of child fields. Exactly what
	 * PHP's $_POST parser produces for `foo[0][bar]=x` notation.
	 *
	 * Returns false for plain arrays (e.g. multi-select / checkbox
	 * groups) so those still render as a single comma-joined value.
	 *
	 * @param array<mixed> $value Candidate value.
	 * @since 2.9.0
	 * @return bool
	 */
	private function is_repeater_value( $value ) {
		if ( empty( $value ) ) {
			return false;
		}
		foreach ( $value as $k => $v ) {
			// Non-integer key → not a row-indexed repeater.
			if ( ! is_int( $k ) && ! ctype_digit( (string) $k ) ) {
				return false;
			}
			// Each row must itself be an array of children, not a scalar.
			if ( ! is_array( $v ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Pick the first visible string value out of `form_data` for the
	 * list-view "preview" column. Mirrors the Entries screen behaviour.
	 *
	 * @param array<string,mixed> $form_data Decoded form data.
	 * @since 2.9.0
	 * @return string
	 */
	private function extract_first_value( $form_data ) {
		foreach ( $form_data as $key => $value ) {
			// Skip internal keys and non-SureForms fields.
			if ( ! is_string( $key ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}
			if ( is_scalar( $value ) && '' !== trim( (string) $value ) ) {
				return wp_strip_all_tags( (string) $value );
			}
		}
		return '';
	}

	/**
	 * Resolve the CSV header label for a submitted field key.
	 *
	 * The label is decoded out of the field key itself — and the key is accepted
	 * from the public save endpoint without being cross-checked against the form's
	 * block definitions, while `Helper::encrypt`/`decrypt` is unkeyed base64. So a
	 * label is submitter-controlled and must get the same formula neutralisation the
	 * data cells already receive; without it, `=cmd|'/c calc'!A1` lands unescaped in
	 * the header row of a CSV an admin later opens.
	 *
	 * @param string $srfm_key Submitted field key.
	 * @since 2.12.3
	 * @return string
	 */
	private static function get_export_header_label( $srfm_key ) {
		return self::csv_escape_formula( Helper::get_field_label_from_key( $srfm_key ) );
	}

	/**
	 * Prefix a string with a single apostrophe when its first
	 * character is one Excel/Sheets treats as a formula starter
	 * (`=`, `+`, `-`, `@`, tab, carriage return). Without this,
	 * an attacker who submits `=HYPERLINK(...)` into a free-text
	 * field gets formula execution when an admin opens the CSV.
	 *
	 * @param mixed $value Raw scalar to write to CSV.
	 * @since 2.9.0
	 * @return string
	 */
	private static function csv_escape_formula( $value ) {
		$str = Helper::get_string_value( $value );
		if ( '' === $str ) {
			return $str;
		}
		$first = substr( $str, 0, 1 );
		if ( in_array( $first, [ '=', '+', '-', '@', "\t", "\r" ], true ) ) {
			return "'" . $str;
		}
		return $str;
	}

	/**
	 * Enforce the per-IP rate limit on the public save endpoint.
	 *
	 * Returns a `WP_Error` with HTTP 429 when the current remote
	 * address has exceeded `RATE_LIMIT_MAX` saves within the last
	 * `RATE_LIMIT_WINDOW` seconds. Everyone else passes through.
	 *
	 * Sites fronted by a CDN / WAF that already rate-limits can set
	 * `srfm_partial_entries_rate_limit_enabled` to false to skip.
	 *
	 * @since 2.9.0
	 * @return WP_Error|true WP_Error on throttle, true otherwise.
	 */
	private function check_rate_limit() {
		/**
		 * Allow sites with upstream rate-limiting (CDN, WAF) to
		 * disable the transient-based counter.
		 *
		 * @param bool $enabled Whether to enforce the rate limit.
		 * @since 2.9.0
		 */
		if ( ! apply_filters( 'srfm_partial_entries_rate_limit_enabled', true ) ) {
			return true;
		}

		$ip = $this->get_client_ip();
		if ( '' === $ip ) {
			// Can't identify the client — skip rather than blanket-deny.
			return true;
		}

		$key = 'srfm_partial_rl_' . md5( $ip );

		// On sites with a real (persistent) object cache, atomically
		// increment via wp_cache_incr — eliminates the read-then-write
		// TOCTOU window between two concurrent requests. Falls back to
		// the transient pattern when no object cache is present.
		if ( wp_using_ext_object_cache() ) {
			$count = wp_cache_incr( $key, 1, 'srfm_partial_entries' );
			if ( false === $count || 1 === (int) $count ) {
				// First hit in this window — seed the TTL via add()
				// since wp_cache_incr cannot set expiry directly.
				wp_cache_add( $key, 1, 'srfm_partial_entries', self::RATE_LIMIT_WINDOW );
				$count = 1;
			}
			if ( (int) $count > self::RATE_LIMIT_MAX ) {
				return new WP_Error(
					'srfm_partial_rate_limited',
					__( 'Too many requests. Please slow down.', 'sureforms-pro' ),
					[ 'status' => 429 ]
				);
			}
			return true;
		}

		$raw_count = get_transient( $key );
		$count     = is_numeric( $raw_count ) ? (int) $raw_count : 0;

		if ( $count >= self::RATE_LIMIT_MAX ) {
			return new WP_Error(
				'srfm_partial_rate_limited',
				__( 'Too many requests. Please slow down.', 'sureforms-pro' ),
				[ 'status' => 429 ]
			);
		}

		// Re-set with the remaining TTL preserved — WP transients
		// don't expose read-then-touch, so we accept the window
		// sliding forward on each write. Good enough on no-object-cache
		// hosts where wp_cache_incr fall-through to the same transient.
		set_transient( $key, $count + 1, self::RATE_LIMIT_WINDOW );
		return true;
	}

	/**
	 * Best-effort remote-IP lookup. Respects the standard proxy
	 * headers WP already trusts in `WP_Http::is_forwarded` patterns
	 * — but NEVER blindly trusts `X-Forwarded-For` unless the site
	 * has opted in via the filter (trusting it by default lets a
	 * client spoof their way past the rate limit).
	 *
	 * @since 2.9.0
	 * @return string
	 */
	private function get_client_ip() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- IP address validated via filter_var below.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';

		/**
		 * Set to a trusted proxy header name (e.g. `HTTP_X_FORWARDED_FOR`)
		 * ONLY if the site runs behind a reverse proxy that overwrites it.
		 * Trusting it by default would let a client spoof their IP.
		 *
		 * @param string $header Empty = ignore proxy headers.
		 * @since 2.9.0
		 */
		$proxy_header = (string) apply_filters( 'srfm_partial_entries_trusted_proxy_header', '' );
		if ( '' !== $proxy_header && ! empty( $_SERVER[ $proxy_header ] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- IP address validated via filter_var below.
			$forwarded = sanitize_text_field( wp_unslash( (string) $_SERVER[ $proxy_header ] ) );
			// Take the first IP in the list — that's the client.
			$parts = explode( ',', $forwarded );
			$ip    = trim( (string) $parts[0] );
		}

		$ip = filter_var( $ip, FILTER_VALIDATE_IP );
		return is_string( $ip ) ? $ip : '';
	}

	/**
	 * Sanitize the form_data array from the capture payload.
	 *
	 * Accepts only scalar leaves + one level of arrays (multi-select,
	 * checkbox groups). Anything deeper is flattened to string to
	 * keep the payload predictable.
	 *
	 * @param array<string,mixed> $form_data Raw form data.
	 * @since 2.9.0
	 * @return array<string,mixed>
	 */
	private function sanitize_form_data( $form_data ) {
		// Recursive sanitize — preserves nested arrays for repeater
		// rows (shape: `{field: {0: {child: value}, 1: …}}`) while
		// keeping flat multi-value arrays (checkbox groups /
		// multi-select) working the way they did before. Max depth
		// is capped at 4 to defend against pathological payloads.
		$sanitize = static function ( $value, $depth = 0 ) use ( &$sanitize ) {
			if ( $depth >= 4 ) {
				return is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';
			}
			if ( is_array( $value ) ) {
				$out = [];
				foreach ( $value as $k => $v ) {
					$clean_key = is_int( $k ) ? $k : sanitize_text_field( Helper::get_string_value( $k ) );
					if ( '' === $clean_key && 0 !== $clean_key ) {
						continue;
					}
					$out[ $clean_key ] = $sanitize( $v, $depth + 1 );
				}
				return $out;
			}
			if ( is_scalar( $value ) ) {
				return sanitize_textarea_field( (string) $value );
			}
			return '';
		};

		$clean = [];
		foreach ( $form_data as $key => $value ) {
			$clean_key = sanitize_text_field( Helper::get_string_value( $key ) );
			if ( '' === $clean_key ) {
				continue;
			}
			$clean[ $clean_key ] = $sanitize( $value );
		}
		return $clean;
	}

	/**
	 * Returns true when at least one field in the (sanitized) form_data
	 * array has a non-empty value. Handles nested arrays (repeater rows,
	 * checkbox groups) recursively.
	 *
	 * @param array<mixed> $data Sanitized form_data array.
	 * @since 2.9.0
	 * @return bool
	 */
	private function has_any_field_value( array $data ) {
		foreach ( $data as $value ) {
			if ( is_array( $value ) ) {
				if ( $this->has_any_field_value( $value ) ) {
					return true;
				}
			} elseif ( is_scalar( $value ) && '' !== trim( (string) $value ) ) {
				return true;
			}
		}
		return false;
	}

}
