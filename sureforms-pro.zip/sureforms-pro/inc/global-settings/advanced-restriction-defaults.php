<?php
/**
 * Advanced Restriction Global Defaults.
 *
 * Owns the global IP / Country / Keyword Form Restriction settings that were
 * moved out of the free SureForms plugin. Persists to its own option key,
 * one-time migrates legacy data from the free option, and feeds the
 * `_srfm_additional_form_restriction` per-form meta via a
 * `default_post_metadata` filter so new forms inherit the global until the
 * user customises them.
 *
 * @package sureforms-pro
 * @since   2.9.0
 */

namespace SRFM_Pro\Inc\Global_Settings;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Advanced Restriction Defaults.
 *
 * @since 2.9.0
 */
class Advanced_Restriction_Defaults {
	use Get_Instance;

	/**
	 * Pro option key for the moved global settings.
	 */
	public const OPTION_KEY = 'srfm_pro_advanced_restriction_settings';

	/**
	 * Migration flag option key — set once the legacy free option has been
	 * read into the new Pro option, so we never overwrite user-edited values
	 * if the legacy option is later cleared.
	 */
	public const MIGRATED_FLAG = 'srfm_pro_advanced_restriction_migrated';

	/**
	 * Free's legacy option key. We read from it once for migration, then
	 * leave it untouched.
	 */
	public const LEGACY_OPTION_KEY = 'srfm_form_restriction_settings_options';

	/**
	 * Per-form meta key (registered by Additional_Form_Restrictions).
	 */
	public const META_KEY = '_srfm_additional_form_restriction';

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	private $namespace = 'sureforms-pro/v1';

	/**
	 * Constructor.
	 *
	 * @since 2.9.0
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		// Priority 20 — after WP's filter_default_metadata (priority 10) so
		// our global value overrides the static register_post_meta default.
		add_filter( 'default_post_metadata', [ $this, 'inject_global_defaults' ], 20, 4 );
	}

	/**
	 * Default shape for the global option. Mirrors the IP / Country / Keyword
	 * slices of the per-form `_srfm_additional_form_restriction` defaults
	 * registered in Additional_Form_Restrictions.
	 *
	 * @since 2.9.0
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_defaults() {
		return [
			'ip'      => [
				'status'                => false,
				'mode'                  => 'block',
				'ips'                   => '',
				'includeDisallowedKeys' => false,
				'message'               => __( "We're sorry, this form isn't accessible from your IP address.", 'sureforms-pro' ),
			],
			'country' => [
				'status'    => false,
				'mode'      => 'block',
				'countries' => '',
				'message'   => __( "We're sorry, this form isn't available in your region right now.", 'sureforms-pro' ),
			],
			'keyword' => [
				'status'                => false,
				'keywords'              => '',
				'includeDisallowedKeys' => false,
				'message'               => __( 'Your submission contains restricted keywords.', 'sureforms-pro' ),
			],
		];
	}

	/**
	 * Read the current Pro option, running the one-time legacy migration
	 * the first time it is accessed.
	 *
	 * @since 2.9.0
	 * @return array<string, array<string, mixed>>
	 */
	public function get_settings() {
		if ( ! get_option( self::MIGRATED_FLAG ) ) {
			$this->migrate_from_legacy_free_option();
		}

		$stored = get_option( self::OPTION_KEY, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}

		$defaults = self::get_defaults();
		$merged   = [];
		foreach ( $defaults as $group_key => $group_defaults ) {
			$group_value          = isset( $stored[ $group_key ] ) && is_array( $stored[ $group_key ] ) ? $stored[ $group_key ] : [];
			$merged[ $group_key ] = array_merge( $group_defaults, $group_value );
		}

		return $merged;
	}

	/**
	 * One-time migration: read the legacy free option's IP / Country /
	 * Keyword sub-keys, rename them to the Pro shape, and persist to the
	 * Pro option. Idempotent — guarded by the MIGRATED_FLAG option.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function migrate_from_legacy_free_option() {
		// Already migrated.
		if ( get_option( self::MIGRATED_FLAG ) ) {
			return;
		}

		$legacy = get_option( self::LEGACY_OPTION_KEY, [] );
		if ( ! is_array( $legacy ) ) {
			$legacy = [];
		}

		$key_map = [
			'ip'      => 'ip_restriction',
			'country' => 'country_restriction',
			'keyword' => 'keyword_restriction',
		];

		$migrated = [];
		foreach ( $key_map as $new_key => $legacy_key ) {
			if ( isset( $legacy[ $legacy_key ] ) && is_array( $legacy[ $legacy_key ] ) ) {
				$migrated[ $new_key ] = $legacy[ $legacy_key ];
			}
		}

		if ( ! empty( $migrated ) ) {
			// Only write if there's actual legacy data to preserve, so a
			// brand-new install doesn't create an option row prematurely.
			update_option( self::OPTION_KEY, array_merge( self::get_defaults(), $migrated ) );
		}

		// Always set the flag, so a fresh install (no legacy data) doesn't
		// re-run this on every read.
		update_option( self::MIGRATED_FLAG, 1 );
	}

	/**
	 * Persist sanitised settings to the Pro option key.
	 *
	 * @since 2.9.0
	 * @param array<string, mixed> $settings Incoming settings payload.
	 * @return bool Whether the option was updated.
	 */
	public function save_settings( $settings ) {
		$sanitised = $this->sanitise_settings( $settings );

		// Mark migration as resolved so subsequent reads don't try to
		// overlay stale legacy data on top of user-edited values.
		if ( ! get_option( self::MIGRATED_FLAG ) ) {
			update_option( self::MIGRATED_FLAG, 1 );
		}

		return update_option( self::OPTION_KEY, $sanitised );
	}

	/**
	 * Sanitise an incoming settings payload, dropping unknown keys.
	 *
	 * @since 2.9.0
	 * @param array<string, mixed> $settings Raw incoming settings.
	 * @return array<string, array<string, mixed>>
	 */
	public function sanitise_settings( $settings ) {
		$ip      = isset( $settings['ip'] ) && is_array( $settings['ip'] ) ? $settings['ip'] : [];
		$country = isset( $settings['country'] ) && is_array( $settings['country'] ) ? $settings['country'] : [];
		$keyword = isset( $settings['keyword'] ) && is_array( $settings['keyword'] ) ? $settings['keyword'] : [];

		return [
			'ip'      => [
				'status'                => isset( $ip['status'] ) ? (bool) $ip['status'] : false,
				'mode'                  => isset( $ip['mode'] ) && in_array( $ip['mode'], [ 'allow', 'block' ], true ) ? sanitize_text_field( (string) $ip['mode'] ) : 'block',
				'ips'                   => isset( $ip['ips'] ) ? sanitize_text_field( (string) $ip['ips'] ) : '',
				'includeDisallowedKeys' => isset( $ip['includeDisallowedKeys'] ) ? (bool) $ip['includeDisallowedKeys'] : false,
				'message'               => isset( $ip['message'] ) ? sanitize_textarea_field( (string) $ip['message'] ) : '',
			],
			'country' => [
				'status'    => isset( $country['status'] ) ? (bool) $country['status'] : false,
				'mode'      => isset( $country['mode'] ) && in_array( $country['mode'], [ 'allow', 'block' ], true ) ? sanitize_text_field( (string) $country['mode'] ) : 'block',
				'countries' => isset( $country['countries'] ) ? sanitize_text_field( (string) $country['countries'] ) : '',
				'message'   => isset( $country['message'] ) ? sanitize_textarea_field( (string) $country['message'] ) : '',
			],
			'keyword' => [
				'status'                => isset( $keyword['status'] ) ? (bool) $keyword['status'] : false,
				'keywords'              => isset( $keyword['keywords'] ) ? sanitize_text_field( (string) $keyword['keywords'] ) : '',
				'includeDisallowedKeys' => isset( $keyword['includeDisallowedKeys'] ) ? (bool) $keyword['includeDisallowedKeys'] : false,
				'message'               => isset( $keyword['message'] ) ? sanitize_textarea_field( (string) $keyword['message'] ) : '',
			],
		];
	}

	/**
	 * Inject the global IP / Country / Keyword defaults into the per-form
	 * `_srfm_additional_form_restriction` meta when no row exists yet. The
	 * first user edit of the per-form restriction settings creates a real
	 * meta row, after which this filter no longer fires for that key.
	 *
	 * @since 2.9.0
	 * @param mixed  $value     Default value WP would return.
	 * @param int    $object_id Post ID.
	 * @param string $meta_key  Meta key being read.
	 * @param bool   $single    Whether a single value is requested.
	 * @return mixed
	 */
	public function inject_global_defaults( $value, $object_id, $meta_key, $single ) {
		if ( self::META_KEY !== $meta_key ) {
			return $value;
		}

		if ( 'sureforms_form' !== get_post_type( $object_id ) ) {
			return $value;
		}

		$global = $this->get_settings();

		// Decode the existing static default (registered by
		// Additional_Form_Restrictions) so we can overlay only the IP /
		// Country / Keyword slices and preserve the login + password
		// defaults shipped with Pro.
		$existing = is_string( $value ) ? json_decode( $value, true ) : null;
		if ( ! is_array( $existing ) ) {
			// $value can also already be a JSON string wrapped in an array
			// when WP gave us its array-form default. Try the inner value.
			if ( is_array( $value ) && isset( $value[0] ) && is_string( $value[0] ) ) {
				$existing = json_decode( $value[0], true );
			}
		}
		if ( ! is_array( $existing ) ) {
			$existing = [];
		}

		$existing['ip']      = $global['ip'] ?? ( $existing['ip'] ?? [] );
		$existing['country'] = $global['country'] ?? ( $existing['country'] ?? [] );
		$existing['keyword'] = $global['keyword'] ?? ( $existing['keyword'] ?? [] );

		$encoded = wp_json_encode( $existing );
		if ( false === $encoded ) {
			return $value;
		}

		// REST loads meta with $single=false and unwraps via
		// $all_values[0] — match the schema by wrapping the JSON string in
		// an outer array when $single is false.
		return $single ? $encoded : [ $encoded ];
	}

	/**
	 * Register the REST endpoints used by the global settings UI.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function register_routes() {
		$helper = new Helper();

		register_rest_route(
			$this->namespace,
			'/advanced-restriction-settings',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'rest_get_settings' ],
				'permission_callback' => [ $helper, 'get_items_permissions_check' ],
			]
		);

		register_rest_route(
			$this->namespace,
			'/advanced-restriction-settings',
			[
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => [ $this, 'rest_save_settings' ],
				'permission_callback' => [ $helper, 'get_items_permissions_check' ],
			]
		);
	}

	/**
	 * GET /advanced-restriction-settings.
	 *
	 * @since 2.9.0
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get_settings( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new WP_Error( 'srfm_pro_nonce_failed', __( 'Nonce verification failed.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		return new WP_REST_Response( $this->get_settings() );
	}

	/**
	 * POST /advanced-restriction-settings.
	 *
	 * @since 2.9.0
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_save_settings( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new WP_Error( 'srfm_pro_nonce_failed', __( 'Nonce verification failed.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		$settings = $request->get_param( 'settings' );
		if ( ! is_array( $settings ) ) {
			$settings = [];
		}

		$saved = $this->save_settings( $settings );
		if ( ! $saved ) {
			// update_option returns false when the new value matches the old
			// value — treat that as success since the desired state is
			// reached.
			$current = get_option( self::OPTION_KEY );
			if ( false === $current ) {
				return new WP_Error( 'srfm_pro_save_failed', __( 'Failed to save settings.', 'sureforms-pro' ), [ 'status' => 500 ] );
			}
		}

		return new WP_REST_Response(
			[
				'data'     => __( 'Settings Saved Successfully.', 'sureforms-pro' ),
				'settings' => $this->get_settings(),
			]
		);
	}
}
