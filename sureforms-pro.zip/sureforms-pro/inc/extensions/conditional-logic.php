<?php
/**
 * Conditional_Extension Class file.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Conditional logic Class.
 *
 * @since 0.0.1
 */
class Conditional_Logic {
	use Get_Instance;

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function __construct() {
		add_action( 'srfm_register_conditional_logic_post_meta', [ $this, 'register_post_meta' ], 10 );
		add_action( 'srfm_localize_conditional_logic_data', [ $this, 'localize_condition_logic_data' ], 10 );
		add_filter( 'srfm_conditional_logic_classes', [ $this, 'add_conditional_classes' ], 10, 2 );
	}

	/**
	 * Conditional logic
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public static function register_post_meta() {
		register_post_meta(
			'sureforms_form',
			'_srfm_conditional_logic',
			[
				'type'              => 'array',
				'single'            => true,
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				// Operators validated via whitelist instead of sanitize_text_field()
				// because sanitize_text_field() encodes '<' to '&lt;', silently
				// breaking "is less than" and "is less than or equal to" conditions.
				// See self::get_allowed_operators().
				'sanitize_callback' => static function( $meta_value ) {
					if ( ! is_array( $meta_value ) ) {
						return [];
					}
					$allowed_operators = self::get_allowed_operators();
					$sanitized         = [];
					foreach ( $meta_value as $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}
						$sanitized_item = [];
						foreach ( $item as $block_id => $block_data ) {
							$block_id = sanitize_text_field( $block_id );
							if ( ! is_array( $block_data ) ) {
								continue;
							}
							$sanitized_block = [
								'action' => isset( $block_data['action'] ) ? sanitize_text_field( $block_data['action'] ) : '',
							];
							if ( isset( $block_data['logic'] ) && is_array( $block_data['logic'] ) ) {
								$sanitized_logic = [];
								foreach ( $block_data['logic'] as $conditions ) {
									if ( ! is_array( $conditions ) ) {
										continue;
									}
									$sanitized_conditions = [];
									foreach ( $conditions as $condition ) {
										if ( ! is_array( $condition ) ) {
											continue;
										}
										// Decode legacy-encoded operators (older versions stored
										// '<' as '&lt;' and '<=' as '&lt;=' via sanitize_text_field)
										// so that a re-save repairs the value against the whitelist
										// instead of permanently discarding it.
										$raw_operator           = isset( $condition['operator'] ) ? (string) $condition['operator'] : '';
										$decoded_operator       = html_entity_decode( $raw_operator, ENT_QUOTES );
										$operator               = in_array( $decoded_operator, $allowed_operators, true )
											? $decoded_operator
											: '';
										$sanitized_conditions[] = [
											'field'    => isset( $condition['field'] ) ? sanitize_text_field( $condition['field'] ) : '',
											'operator' => $operator,
											'value'    => isset( $condition['value'] )
											? ( is_array( $condition['value'] )
												? array_map( 'sanitize_text_field', $condition['value'] )
												: sanitize_text_field( $condition['value'] ) )
											: '',
											'type'     => isset( $condition['type'] ) ? sanitize_text_field( $condition['type'] ) : '',
										];
									}
									$sanitized_logic[] = $sanitized_conditions;
								}
								$sanitized_block['logic'] = $sanitized_logic;
							} else {
								$sanitized_block['logic'] = [];
							}
							$sanitized_item[ $block_id ] = $sanitized_block;
						}
						$sanitized[] = $sanitized_item;
					}
					return $sanitized;
				},
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'array',
						'context' => [ 'edit' ],
						'items'   => [
							'type'                 => 'object',
							'additionalProperties' => true,
							'properties'           => [
								// NOTE: the real stored shape is a two-level array
								// (OR groups → AND condition objects) and `value` may
								// be an array for in/!in/between. We intentionally keep
								// this schema loose: WordPress runs schema validation
								// BEFORE the sanitize_callback on REST meta writes, so a
								// stricter schema risks rejecting a valid save. The
								// sanitize_callback (above) is the single source of
								// truth for the structure.
								'logic'  => [
									'type'  => 'array',
									'items' => [
										'type'       => 'object',
										'properties' => [
											'field'    => [ 'type' => 'string' ],
											'operator' => [ 'type' => 'string' ],
											'value'    => [ 'type' => 'string' ],
											'type'     => [ 'type' => 'string' ],
										],
									],
								],
								'action' => [ 'type' => 'string' ],
							],
						],
					],
				],
			]
		);
	}

	/**
	 * Operators allowed in conditional logic conditions.
	 *
	 * This list is the server-side mirror of the editor option set defined in
	 * src/conditional-logic/conditional-logic-options.json. The two MUST stay in
	 * sync — Test_Conditional_Logic::test_allowed_operators_match_editor_options
	 * asserts this in CI. If an operator is added to the editor but not here, the
	 * sanitize_callback would silently coerce it to '' on save (the same class of
	 * bug that the '<' / '<=' whitelist fix addresses).
	 *
	 * Operators are validated against this whitelist instead of sanitize_text_field()
	 * because sanitize_text_field() encodes '<' to '&lt;', silently breaking the
	 * "is less than" and "is less than or equal to" conditions.
	 *
	 * @return array<int, string> List of allowed operator tokens.
	 * @since 2.11.0
	 */
	public static function get_allowed_operators() {
		/**
		 * Filters the operators allowed in conditional logic conditions.
		 *
		 * Add-ons that introduce custom operators must register them here, or the
		 * sanitize_callback will drop conditions that use them.
		 *
		 * @param array<int, string> $allowed_operators List of allowed operator tokens.
		 * @since 2.11.0
		 */
		// Cast to array so a third-party filter returning a non-array value
		// can never break the in_array() check in the sanitize_callback.
		return (array) apply_filters(
			'srfm_conditional_logic_allowed_operators',
			[
				'==',
				'!=',
				'null',
				'!null',
				'includes',
				'!includes',
				'startWith',
				'endWith',
				'>',
				'>=',
				'<',
				'<=',
				'between',
				'isChecked',
				'!isChecked',
				'in',
				'!in',
				'isSelected',
				'!isSelected',
				'datePickerIs',
				'timePickerIs',
				'isBefore',
				'isOnOrBefore',
				'isAfter',
				'isOnOrAfter',
				'matchesPattern',
				'doesNotMatchPattern',
			]
		);
	}

	/**
	 * Conditional logic data
	 *
	 * @param int $id form id.
	 * @return void
	 * @since 0.0.1
	 */
	public static function localize_condition_logic_data( $id ) {
		$conditional_data = get_post_meta( $id, '_srfm_conditional_logic' );
		$file_suffix      = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name         = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		wp_enqueue_script( SRFM_PRO_SLUG . '-conditional-logic', SRFM_PRO_URL . 'assets/js/' . $dir_name . '/conditional-logic' . $file_suffix . '.js', [], SRFM_PRO_VER, true );
		wp_localize_script(
			SRFM_PRO_SLUG . '-conditional-logic',
			'srfm_conditional_logic_data_' . $id,
			[
				'data-' . $id => $conditional_data,
			]
		);
	}

	/**
	 * Conditional logic data
	 *
	 * @param int $id form id.
	 * @param int $block_id block id.
	 * @return array<int, string>|string
	 * @since 0.0.1
	 */
	public static function add_conditional_classes( $id, $block_id ) {
		$data = get_post_meta( $id, '_srfm_conditional_logic' );
		if ( ! is_array( $data ) ) {
			return '';
		}
		$result         = [];
		$processed_keys = [];

		foreach ( $data as $level1 ) {
			if ( is_array( $level1 ) ) {
				foreach ( $level1 as $level2 ) {
					if ( is_array( $level2 ) ) {
						foreach ( $level2 as $key => $value ) {
							if ( is_array( $value ) && isset( $value['logic'] ) ) {
								$logic = $value['logic'];

								if ( ! isset( $result[ $key ] ) ) {
									$result[ $key ] = [];
								}

								if ( isset( $value['action'] ) ) {
									$action_class     = 'show' === $value['action'] ? 'srfm-show' : 'srfm-hide';
									$result[ $key ][] = 'conditional-logic ' . $action_class;
								}

								if ( is_array( $logic ) ) {
									foreach ( $logic as $condition ) {
										if ( is_array( $condition ) ) {
											foreach ( $condition as $sub_condition ) {
												if ( is_array( $sub_condition ) && isset( $sub_condition['field'] ) ) {
													$field = $sub_condition['field'];
													if ( ! isset( $processed_keys[ $field ] ) ) {
														if ( ! isset( $result[ $field ] ) ) {
															$result[ $field ] = [];
														}
														$result[ $field ][]       = 'conditional-trigger';
														$processed_keys[ $field ] = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		foreach ( $result as &$values ) {
			$values = implode( ' ', $values );
		}

		return $result[ $block_id ] ?? '';
	}

}
