<?php
/**
 * Migrator_Ninja — Pro-side subscribers for Free's Ninja Forms importer
 * (sureforms#2794). Wires onto the same four `srfm_migrator_*` filter
 * seams Migrator_CF7 / WPForms / Gravity use, discriminated by
 * `$key === 'ninja'`.
 *
 * Adds Pro emitter routing for the Ninja field types Free can't render
 * on its own:
 *
 *   - date          → srfm/date-picker
 *   - file_upload   → srfm/upload         (paid Ninja add-on)
 *   - starrating    → srfm/rating
 *   - hidden        → srfm/hidden
 *   - password      → srfm/input (type=password)
 *   - signature     → srfm/signature
 *   - html / note   → srfm/html
 *   - hr            → srfm/separator (native separator block)
 *
 * @package sureforms-pro
 * @since   2.11.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM_Pro\Inc\Migrator\Block_Templates_Pro;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migrator_Ninja
 *
 * @since 2.11.0
 */
class Migrator_Ninja {
	use Get_Instance;

	/**
	 * Bind subscribers to Free's migrator filters.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_filter( 'srfm_migrator_tag_to_template_map', [ $this, 'extend_field_map' ], 10, 2 );
		add_filter( 'srfm_migrator_unsupported_tags', [ $this, 'reduce_unsupported_tags' ], 10, 2 );
		add_filter( 'srfm_migrator_block_template', [ $this, 'emit_block' ], 10, 4 );
		add_filter( 'srfm_migrator_preprocess_template', [ $this, 'preprocess_template' ], 10, 3 );
	}

	/**
	 * Overlay Ninja Forms field-type → template-method entries.
	 *
	 * The Ninja importer dispatches non-direct types (date / file_upload /
	 * starrating / etc.) through the `srfm_migrator_block_template` filter
	 * with their method name; we just need to make sure the method-→-emitter
	 * dispatch in emit_block() recognises them.
	 *
	 * Free's textbox/email/etc. mappings already live on the importer; this
	 * filter is a no-op for 'ninja' beyond what Free declares.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,string> $map Source-type → template-method map.
	 * @param string               $key Migrator source key.
	 * @return array<string,string>
	 */
	public function extend_field_map( $map, $key ) {
		if ( 'ninja' !== $key || ! is_array( $map ) ) {
			return $map;
		}
		// Nothing to overlay — the Free importer routes Ninja's Pro field
		// types directly through the block-template filter using the
		// method names emit_block() handles below.
		return $map;
	}

	/**
	 * No Ninja type is in Free's default unsupported list — wired for
	 * symmetry.
	 *
	 * @since 2.11.0
	 *
	 * @param array<int,string> $tags Source-side tag names flagged unsupported.
	 * @param string            $key  Migrator source key.
	 * @return array<int,string>
	 */
	public function reduce_unsupported_tags( $tags, $key ) {
		if ( 'ninja' !== $key || ! is_array( $tags ) ) {
			return $tags;
		}
		return $tags;
	}

	/**
	 * Emit Gutenberg markup for the Pro-only template methods we register
	 * for the `ninja` source.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $markup Default empty string.
	 * @param string              $method Template method name.
	 * @param array<string,mixed> $args   Block args.
	 * @param string              $key    Migrator source key.
	 * @return string
	 */
	public function emit_block( $markup, $method, $args, $key ) {
		if ( 'ninja' !== $key || '' !== $markup ) {
			return $markup;
		}
		switch ( $method ) {
			case 'date_time_picker':
				return Block_Templates_Pro::date_time_picker( $args );
			case 'date_picker':
				return Block_Templates_Pro::date_picker( $args );
			case 'upload':
				return Block_Templates_Pro::upload( $args );
			case 'rating':
				return Block_Templates_Pro::rating( $args );
			case 'hidden_field':
				return Block_Templates_Pro::hidden_field( $args );
			case 'password_input':
				return Block_Templates_Pro::password_input( $args );
			case 'signature':
				return Block_Templates_Pro::signature( $args );
			case 'html_block':
				return Block_Templates_Pro::html_block( $args );
			case 'divider':
				return Block_Templates_Pro::divider( $args );
			default:
				return $markup;
		}
	}

	/**
	 * No Ninja-specific preprocessing yet — pass through.
	 *
	 * @since 2.11.0
	 *
	 * @param array<int,array<string,mixed>>|mixed $fields Parsed Ninja field list.
	 * @param string                               $key    Migrator source key.
	 * @param array<string,mixed>                  $form   Source form descriptor (unused).
	 * @return array<int,array<string,mixed>>|mixed
	 */
	public function preprocess_template( $fields, $key, $form ) {
		unset( $key, $form );
		return $fields;
	}
}
