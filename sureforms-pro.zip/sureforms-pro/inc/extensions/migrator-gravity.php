<?php
/**
 * Migrator_Gravity — Pro-side subscribers for Free's Gravity Forms importer
 * (sureforms#2793). Wires onto the same four `srfm_migrator_*` filter
 * seams Migrator_CF7 and Migrator_WPForms use, discriminated by
 * `$key === 'gravity'`.
 *
 * Adds Pro emitter routing for the Gravity field types Free can't render
 * on its own:
 *
 *   - date          → srfm/date-picker
 *   - time          → srfm/time-picker
 *   - fileupload    → srfm/upload
 *   - hidden        → srfm/hidden
 *   - page          → srfm/page-break
 *   - html          → srfm/html
 *   - section       → srfm/separator (native separator block)
 *   - address       → srfm/address (innerBlocks)
 *   - list          → srfm/repeater (innerBlocks)
 *   - signature     → srfm/signature (Signature add-on)
 *
 * @package sureforms-pro
 * @since   2.11.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM_Pro\Inc\Migrator\Block_Templates_Pro;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migrator_Gravity
 *
 * @since 2.11.0
 */
class Migrator_Gravity {
	use Get_Instance;

	/**
	 * Bind subscribers to Free's migrator filters.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_filter( 'srfm_migrator_tag_to_template_map', [ $this, 'extend_field_map' ], 10, 2 );
		add_filter( 'srfm_migrator_unsupported_tags', [ $this, 'reduce_unsupported_tags' ], 10, 2 );
		add_filter( 'srfm_migrator_block_template', [ $this, 'emit_block' ], 10, 4 );
		add_filter( 'srfm_migrator_preprocess_template', [ $this, 'preprocess_template' ], 10, 3 );
	}

	/**
	 * Overlay Gravity-Pro field-type → template-method entries.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,string> $map Gravity field type → method.
	 * @param string               $key Migrator source key.
	 * @return array<string,string>
	 */
	public function extend_field_map( $map, $key ) {
		if ( 'gravity' !== $key || ! is_array( $map ) ) {
			return $map;
		}
		$map['date']       = 'date_picker';
		$map['time']       = 'date_time_picker';
		$map['fileupload'] = 'upload';
		$map['hidden']     = 'hidden_field';
		$map['page']       = 'page_break';
		$map['html']       = 'html_block';
		$map['section']    = 'divider';
		$map['address']    = 'address';
		$map['list']       = 'repeater_container';
		$map['signature']  = 'signature';
		return $map;
	}

	/**
	 * No Gravity type is in Free's default unsupported list — wired for
	 * symmetry with the CF7 / WPForms paths.
	 *
	 * @since 2.11.0
	 *
	 * @param array<int,string> $tags Source-side tag names flagged unsupported.
	 * @param string            $key  Migrator source key.
	 * @return array<int,string>
	 */
	public function reduce_unsupported_tags( $tags, $key ) {
		if ( 'gravity' !== $key || ! is_array( $tags ) ) {
			return $tags;
		}
		return $tags;
	}

	/**
	 * Emit Gutenberg markup for the Pro-only template methods we register
	 * for the `gravity` source. Reuses the existing `Block_Templates_Pro`
	 * emitters shared with CF7 + WPForms.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $markup Default empty string.
	 * @param string              $method Template method name.
	 * @param array<string,mixed> $args   Block args.
	 * @param string              $key    Migrator source key.
	 * @return string
	 */
	public function emit_block( $markup, $method, $args, $key ) {
		if ( 'gravity' !== $key || '' !== $markup ) {
			return $markup;
		}
		switch ( $method ) {
			case 'date_picker':
				return Block_Templates_Pro::date_picker( $args );
			case 'date_time_picker':
				return Block_Templates_Pro::date_time_picker( $args );
			case 'upload':
				return Block_Templates_Pro::upload( $args );
			case 'hidden_field':
				return Block_Templates_Pro::hidden_field( $args );
			case 'page_break':
				return Block_Templates_Pro::page_break( $args );
			case 'html_block':
				return Block_Templates_Pro::html_block( $args );
			case 'divider':
				return Block_Templates_Pro::divider( $args );
			case 'address':
				return Block_Templates_Pro::address( $args );
			case 'repeater_container':
				return Block_Templates_Pro::repeater_container( $args );
			case 'signature':
				return Block_Templates_Pro::signature( $args );
			default:
				return $markup;
		}
	}

	/**
	 * No preprocessing needed for Gravity at this layer — Free's importer
	 * decodes `display_meta` and passes the array through this filter for
	 * subscriber convenience. We pass the data through unchanged.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed>|mixed $data Parsed Gravity display_meta.
	 * @param string                    $key  Migrator source key.
	 * @param array<string,mixed>       $form Source form descriptor (unused — interface).
	 * @return array<string,mixed>|mixed
	 */
	public function preprocess_template( $data, $key, $form ) {
		unset( $key, $form );
		return $data;
	}
}
