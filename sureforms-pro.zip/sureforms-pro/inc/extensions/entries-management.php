<?php
/**
 * Main class to load the entries management related functionalities.
 *
 * @since 1.3.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Entries Management Class.
 *
 * @since 1.3.0
 */
class Entries_Management {
	use Get_Instance;

	/**
	 * Entries Management constructor.
	 *
	 * @since 1.3.0
	 */
	public function __construct() {
		// Action hooks.
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_script' ], 15 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_style' ], 5 );

		// AJAX hooks.
		add_action( 'wp_ajax_sureforms_pro_entry_delete_file', [ $this, 'entry_delete_file' ] );
		add_action( 'wp_ajax_sureforms_pro_entry_retry_trigger', [ $this, 'entry_retry_trigger' ] );
		add_action( 'wp_ajax_sureforms_pro_entry_integration_status', [ $this, 'entry_integration_status' ] );
	}

	/**
	 * Return the per-trigger webhook + native integration statuses stored on an entry.
	 *
	 * Powers the entry-detail "Retry" UI, which lists each trigger and offers a
	 * Retry button for the failed ones.
	 *
	 * @since 2.12.1
	 * @return void
	 */
	public function entry_integration_status() {
		if ( ! check_ajax_referer( '_srfm_entry_retry_trigger', 'security', false ) ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'nonce' ) ] );
		}

		$entry_id = $this->validate_entry_request();
		$entry    = Entries::get( $entry_id );
		$extras   = Helper::get_array_value( $entry['extras'] ?? [] );

		// Resolve each integration bucket through get_array_value so PHPStan keeps
		// a concrete array type for the nested 'triggers' offset access.
		$webhooks_data = Helper::get_array_value( $extras['webhooks'] ?? [] );
		$native_data   = Helper::get_array_value( $extras['native_integrations'] ?? [] );

		$webhooks = isset( $webhooks_data['triggers'] ) && is_array( $webhooks_data['triggers'] )
			? array_values( $webhooks_data['triggers'] )
			: [];
		$native   = isset( $native_data['triggers'] ) && is_array( $native_data['triggers'] )
			? array_values( $native_data['triggers'] )
			: [];

		// Prune status rows for webhooks/workflows that no longer exist in the form
		// config. Trigger rows are persisted on the entry at submission time and are
		// never removed when an integration is later deleted, so without this the
		// retry UI would resurface a deleted integration as retryable (and a retry
		// would then fail with "configuration not found").
		$form_id  = Helper::get_integer_value( $entry['form_id'] ?? 0 );
		$webhooks = $this->filter_triggers_by_ids( $webhooks, $this->get_configured_trigger_ids( $form_id, '_srfm_integrations_webhooks', false ) );
		$native   = $this->filter_triggers_by_ids( $native, $this->get_configured_trigger_ids( $form_id, '_srfm_native_integrations', true ) );

		wp_send_json_success(
			[
				'webhooks' => $webhooks,
				'native'   => $native,
			]
		);
	}

	/**
	 * Enqueue entries management script.
	 *
	 * @param string $hook_prefix The current admin page.
	 * @since 1.3.0
	 * @return void
	 */
	public function enqueue_script( $hook_prefix ) {
		if ( 'sureforms_page_sureforms_entries' !== $hook_prefix ) {
			return;
		}
		$dir_name  = 'dist';
		$file_name = 'entry';
		$js_uri    = SRFM_PRO_URL . $dir_name . '/' . $file_name . '.js';

		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $file_name . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		wp_enqueue_script( SRFM_PRO_SLUG . '-entries', $js_uri, $script_info['dependencies'], $script_info['version'], true );

		wp_localize_script(
			SRFM_PRO_SLUG . '-entries',
			'srfm_pro_entries',
			[
				'nonce'       => wp_create_nonce( '_srfm_entry_delete_file' ),
				'retry_nonce' => wp_create_nonce( '_srfm_entry_retry_trigger' ),
			]
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-entries' );
	}

	/**
	 * Enqueue entries management style.
	 *
	 * @param string $hook_prefix The current admin page.
	 * @since 1.3.0
	 * @return void
	 */
	public function enqueue_style( $hook_prefix ) {
		if ( 'sureforms_page_sureforms_entries' !== $hook_prefix ) {
			return;
		}
		$dir_name  = 'dist/';
		$file_name = 'entry';
		$css_uri   = SRFM_PRO_URL . $dir_name . '/' . $file_name . '.css';

		wp_enqueue_style( SRFM_PRO_SLUG . '-entries', $css_uri, [], SRFM_PRO_VER );
	}

	/**
	 * Deletes a file based on the provided file URL via an AJAX request.
	 *
	 * This method handles the deletion of a file by verifying the AJAX nonce,
	 * checking if the file URL is provided, converting the file URL to a file path,
	 * and then attempting to delete the file from the server.
	 *
	 * @since 1.3.0
	 * @return void
	 */
	public function entry_delete_file() {
		if ( ! check_ajax_referer( '_srfm_entry_delete_file', 'security' ) ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'nonce' ) ] );
		}

		if ( empty( $_POST['file'] ) ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'invalid' ) ] );
		}

		$entry_id  = $this->validate_entry_request();
		$file_path = Helper::convert_fileurl_to_filepath( urldecode( esc_url_raw( wp_unslash( $_POST['file'] ) ) ) );

		if ( ! file_exists( $file_path ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'File not found.', 'sureforms-pro' ) ] );
		}

		$remove_file = Pro_Helper::delete_upload_file_from_subdir( $file_path, 'sureforms/' );

		if ( ! $remove_file ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Failed to delete file.', 'sureforms-pro' ) ] );
		}

		$instance = Entries::get_instance();
		/* translators: %1$s is the file basename and %2$s is the user display name. */
		$instance->add_log( sprintf( esc_html__( 'File "%1$s" deleted by %2$s', 'sureforms-pro' ), esc_html( basename( $file_path ) ), esc_html( wp_get_current_user()->display_name ) ) );
		$instance::update(
			$entry_id,
			[
				'logs' => $instance->get_logs(),
			]
		);
		wp_send_json_success();
	}

	/**
	 * Re-dispatch a single failed webhook or native integration for an entry (manual retry).
	 *
	 * Verifies the AJAX nonce + capability, then delegates to the owning dispatcher's
	 * retry method (which replays the entry's stored submission data and updates the
	 * per-trigger status + activity log). Returns the new status for the UI.
	 *
	 * @since 2.12.1
	 * @return void
	 */
	public function entry_retry_trigger() {
		if ( ! check_ajax_referer( '_srfm_entry_retry_trigger', 'security', false ) ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'nonce' ) ] );
		}

		// Capability check + resolves/validates the entry id.
		$entry_id = $this->validate_entry_request();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$type       = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
		$trigger_id = isset( $_POST['triggerID'] ) ? sanitize_text_field( wp_unslash( $_POST['triggerID'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $trigger_id ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'invalid' ) ] );
		}

		if ( 'webhook' === $type ) {
			$webhooks = \SRFM_Pro\Inc\Integrations\Webhooks::get_instance();
			// get_instance() is typed as object on the shared singleton trait; narrow
			// it so the dispatcher's retry method resolves for static analysis.
			$result = $webhooks instanceof \SRFM_Pro\Inc\Integrations\Webhooks
				? $webhooks->retry_webhook( $entry_id, $trigger_id )
				: [];
		} elseif ( 'native' === $type ) {
			// Reuse the bootstrapped Workflow_Processor instead of constructing a new
			// one (whose constructor would re-register the submission hook).
			$native_integrations = \SRFM_Pro\Inc\Pro\Native_Integrations::get_instance();
			$processor           = $native_integrations instanceof \SRFM_Pro\Inc\Pro\Native_Integrations
				? $native_integrations->get_workflow_processor()
				: null;
			if ( ! $processor ) {
				wp_send_json_error( [ 'message' => $this->get_error_msg( 'invalid' ) ] );
			}
			$result = $processor->retry_workflow( $entry_id, $trigger_id );
		} else {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'invalid' ) ] );
		}

		$message = isset( $result['message'] ) && is_string( $result['message'] ) ? $result['message'] : '';
		$status  = isset( $result['status'] ) && is_string( $result['status'] ) ? $result['status'] : 'failed';

		if ( empty( $result['success'] ) ) {
			wp_send_json_error(
				[
					'message' => '' !== $message ? $message : __( 'Retry failed.', 'sureforms-pro' ),
					'status'  => $status,
				]
			);
		}

		wp_send_json_success(
			[
				'message' => '' !== $message ? $message : __( 'Retried successfully.', 'sureforms-pro' ),
				'status'  => $status,
			]
		);
	}

	/**
	 * Filters the email notifications to only include those that are enabled.
	 *
	 * @param array<int|string,array<string,bool|int|string>> $email_notifications The email notifications to filter.
	 * @since 1.7.1
	 * @return array<int,array<string,bool|int|string>> Sequentially-keyed list of enabled notifications.
	 */
	public static function get_enabled_email_notifications( $email_notifications ) {

		foreach ( $email_notifications as $key => $email_notification ) {
			if ( ! isset( $email_notification['status'] ) || true !== $email_notification['status'] ) {
				unset( $email_notifications[ $key ] );
			}
		}

		// Re-index so the result is always a sequential list. Without this, disabling a
		// notification leaves a gap in the keys (e.g. [1 => ...]) and wp_json_encode() emits
		// a JSON object instead of an array — the entries "Resend Notification" React
		// component then calls .map() on an object and crashes the page.
		return array_values( $email_notifications );
	}

	/**
	 * Helper method to paginate the provided array data.
	 *
	 * @param array<mixed> $array Array item to paginate.
	 * @param int          $current_page Current page number.
	 * @param int          $items_per_page Total items to return per pagination.
	 * @since 1.3.0
	 * @return array<mixed>
	 */
	public static function paginate_array( $array, $current_page, $items_per_page = 3 ) {
		$total_items = count( $array );
		$total_pages = Helper::get_integer_value( ceil( $total_items / $items_per_page ) );

		// Ensure current page is within bounds.
		$current_page = max( 1, min( $total_pages, $current_page ) );

		// Calculate the offset for slicing.
		$offset = ( $current_page - 1 ) * $items_per_page;

		// Get the items for the current page.
		$items = array_slice( $array, $offset, $items_per_page, true );

		// Determine the next and previous page numbers.
		$next_page = $current_page < $total_pages ? $current_page + 1 : false;
		$prev_page = $current_page > 1 ? $current_page - 1 : false;

		return compact(
			'items',
			'offset',
			'next_page',
			'prev_page',
			'total_items',
			'total_pages',
			'current_page',
		);
	}

	/**
	 * Prepares the form blocks for entry editing mode.
	 *
	 * @param \WP_Post|null $post The post object.
	 * @param array<mixed>  $entry The entry data.
	 * @since 1.3.0
	 * @return array
	 */
	public static function prepare_editing_blocks( $post, $entry ) {
		if ( ! $post || ! is_object( $post ) ) {
			return [];
		}

		$parsed_blocks = parse_blocks( $post->post_content );

		if ( ! is_array( $parsed_blocks ) ) {
			return [];
		}

		if ( ! empty( $parsed_blocks ) && is_array( $parsed_blocks ) ) {
			foreach ( $parsed_blocks as &$parsed_block ) {
				self::prepare_editing_blocks_attrs( $parsed_block, $entry );
			}
		}

		return $parsed_blocks;
	}

	/**
	 * Returns the error message based on the error type.
	 *
	 * @param string $type The error type.
	 * @since 1.3.0
	 * @return string
	 */
	protected function get_error_msg( $type ) {
		$messages = [
			'permission' => __( 'You do not have permission to perform this action.', 'sureforms-pro' ),
			'invalid'    => __( 'Invalid request.', 'sureforms-pro' ),
			'nonce'      => __( 'Nonce verification failed.', 'sureforms-pro' ),
		];

		return $messages[ $type ] ?? '';
	}

	/**
	 * Helper method to validate the entry request.
	 *
	 * This method checks if the user has permission to manage options and
	 * if the entry ID is provided in the POST request. It then returns the
	 * sanitized entry ID.
	 *
	 * @since 1.3.0
	 * @return int
	 */
	protected function validate_entry_request() {
		if ( ! Helper::current_user_can() ) {
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'permission' ) ] );
		}

		if ( empty( $_POST['entryID'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- We are checking nonce in the necessary methods.
			wp_send_json_error( [ 'message' => $this->get_error_msg( 'invalid' ) ] );
		}

		return absint( wp_unslash( $_POST['entryID'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- We are checking nonce in the necessary methods.
	}

	/**
	 * Prepares the form blocks for entry editing mode.
	 *
	 * @param array<array<mixed>> $block The block data.
	 * @param array<mixed>        $entry The entry data.
	 * @since 1.3.0
	 * @return void
	 */
	protected static function prepare_editing_blocks_attrs( &$block, $entry ) {
		if ( ! $block['blockName'] ) {
			return;
		}

		if ( empty( $block['attrs']['slug'] ) ) {
			// If we don't have slug then this is invalid block for editing purpose.
			$block['blockName'] = null;
			return;
		}

		$block['attrs']['entryID']   = absint( $entry['ID'] );
		$block['attrs']['isEditing'] = true;

		if ( ! empty( $block['innerBlocks'] ) ) {
			foreach ( $block['innerBlocks'] as &$inner_block ) {
				self::prepare_editing_blocks_attrs( $inner_block, $entry );
			}
			return;
		}

		if ( ! empty( $entry['form_data'] ) && is_array( $entry['form_data'] ) ) {
			foreach ( $entry['form_data'] as $field_name => $value ) {
				if ( false !== strpos( $field_name, "-{$block['attrs']['block_id']}-" ) ) {
					$block['attrs']['fieldName']    = $field_name;
					$block['attrs']['defaultValue'] = $value;
					break;
				}
			}
		}
	}

	/**
	 * Collect the currently-configured trigger ids for a form.
	 *
	 * @param int    $form_id  Form ID.
	 * @param string $meta_key Post-meta key holding the integration config.
	 * @param bool   $is_json  True when the meta is a JSON string (native integrations);
	 *                         false when it is a stored array (webhooks).
	 * @since 2.12.1
	 * @return array<string> Configured trigger ids as strings.
	 */
	private function get_configured_trigger_ids( $form_id, $meta_key, $is_json ) {
		if ( ! $form_id ) {
			return [];
		}

		$raw = get_post_meta( $form_id, $meta_key, true );
		if ( $is_json ) {
			$decoded = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : [];
			$items   = is_array( $decoded ) ? $decoded : [];
		} else {
			$items = Helper::get_array_value( $raw );
		}

		$ids = [];
		foreach ( $items as $item ) {
			if ( is_array( $item ) && isset( $item['id'] ) ) {
				$ids[] = Helper::get_string_value( $item['id'] );
			}
		}
		return $ids;
	}

	/**
	 * Drop trigger status rows whose id is not in the allowed (currently-configured) list.
	 *
	 * @param array<int,mixed> $triggers    Status rows from extras[...]['triggers'].
	 * @param array<string>    $allowed_ids Currently-configured trigger ids.
	 * @since 2.12.1
	 * @return array<int,mixed>
	 */
	private function filter_triggers_by_ids( $triggers, $allowed_ids ) {
		return array_values(
			array_filter(
				$triggers,
				static function ( $trigger ) use ( $allowed_ids ) {
					return is_array( $trigger )
						&& isset( $trigger['id'] )
						&& in_array( Helper::get_string_value( $trigger['id'] ), $allowed_ids, true );
				}
			)
		);
	}
}
