<?php
/**
 * Hooks.
 *
 * All hooks which are required in frontend and backend are managed in this class.
 *
 * @package sureforms-pro.
 * @since 0.0.1
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Form_Submit;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Block_Assets;
use SRFM_Pro\Inc\File_Upload;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Handler;
use SRFM_Pro\Inc\Traits\Get_Instance;
use SRFM_Pro\Inc\Translatable;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Gutenberg_Hooks Class.
 *
 * @since 0.0.1
 */
class Hooks {
	use Get_Instance;

	/**
	 * An associative array used to store custom styling related values.
	 *
	 * @var array<string,mixed>
	 * @since 1.6.3
	 */
	protected $data = [];

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 0.0.1
	 */
	public function __construct() {
		add_filter( 'srfm_register_additional_blocks', [ $this, 'register_pro_blocks' ] );
		add_filter( 'srfm_blocks', [ $this, 'add_pro_blocks' ] );
		add_filter( 'srfm_css_vars_sizes', [ $this, 'merge_pro_block_sizes' ] );
		add_filter( 'srfm_default_dynamic_block_option', [ $this, 'add_default_dynamic_pro_block_values' ], 10, 2 );
		add_filter( 'srfm_general_dynamic_options_to_save', [ $this, 'add_pro_options_to_save' ], 10, 2 );
		add_filter( 'srfm_global_settings_data', [ $this, 'backfill_dynamic_block_option_defaults' ] );
		add_filter( 'srfm_add_button_classes', [ $this, 'add_pro_btn_classes' ], 10, 3 );
		add_filter( 'srfm_add_background_classes', [ $this, 'add_custom_styling_class' ], 10, 3 );
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_starter_post_metas' ] );
		add_filter( 'srfm_import_scalar_meta_keys', [ $this, 'add_pro_import_scalar_meta_keys' ] );
		add_action( 'srfm_form_css_variables', [ $this, 'add_premium_form_styling_variables' ] );

		// Plugin-shipped style presets (baseline, minimal, dark). Each preset has its own
		// schema + defaults, registered in `Form_Presets`. Keeping them in a
		// separate file makes per-preset tuning easier without touching the
		// starter meta or the existing styling hooks above.
		Form_Presets::get_instance();
		// User-created presets (CRUD + per-form working-copy meta). See
		// `User_Presets` for the index + per-preset option storage shape.
		User_Presets::get_instance();
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_entries_endpoints' ] );
		add_filter( 'srfm_extract_form_fields_field_name', [ $this, 'change_field_name' ], 10, 4 );

		/**
		 * Register file upload related hooks.
		 */
		add_filter( 'srfm_form_submit_data', [ $this, 'add_upload_files_to_form_data' ], 10, 1 );
		add_filter( 'srfm_smart_tags_is_block_processed_externally', [ $this, 'process_upload_signature_smart_tags' ], 10, 1 );

		// Append pro meta keys to the form-settings REST allowlist so
		// the per-tab Save flow (`/sureforms/v1/form-settings`) can
		// persist pro meta. The list grows as more pro tabs migrate
		// to the explicit-Save pattern.
		add_filter( 'srfm_form_settings_allowed_meta_keys', [ $this, 'add_pro_form_settings_meta_keys' ] );

		File_Upload::file_upload_hooks();

		/**
		 * Register hooks for translatable class.
		 */
		Translatable::hooks();

		/**
		 * Register hooks for field validation.
		 */
		Field_Validation::get_instance();

		add_action( 'srfm_before_delete_entry', [ $this, 'before_delete_entry' ] );
	}

	/**
	 * Before deleting the entry.
	 *
	 * @param int $entry_id The ID of the entry to delete.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function before_delete_entry( $entry_id ) {
		$entry = Entries::get_entry_data( $entry_id );
		if ( empty( $entry ) ) {
			return;
		}

		// Do action to delete the entry files.
		do_action( 'srfm_pro_before_deleting_entry', $entry );
	}

	/**
	 * Register REST API endpoints for entries management.
	 *
	 * @param array<string, mixed> $endpoints Array of endpoints.
	 * @since 2.0.0
	 * @return array<string, mixed>
	 */
	public function register_entries_endpoints( $endpoints ) {
		$endpoints['entry/(?P<id>\d+)/logs/(?P<log_id>\d+)'] = [
			'methods'             => 'DELETE',
			'callback'            => [ $this, 'delete_entry_log' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id'     => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
				'log_id' => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
			],
		];

		// Fetch, Add, and Delete Entry Notes.
		$endpoints['entry/(?P<id>\d+)/notes'] = [
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_entry_notes' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'       => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'per_page' => [
						'sanitize_callback' => 'absint',
						'default'           => 10,
					],
					'page'     => [
						'sanitize_callback' => 'absint',
						'default'           => 1,
					],
				],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'add_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'   => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'note' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_textarea_field',
					],
				],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ $this, 'delete_entry_note' ],
				'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
				'args'                => [
					'id'      => [
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'note_id' => [
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					],
				],
			],
		];

		// Resend Entry Notification (single or multiple entries).
		$endpoints['entries/resend-notification'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'resend_notification' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'entry_ids'          => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				],
				'form_id'            => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
				'email_notification' => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
				'send_to'            => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => 'default',
				],
				'recipient'          => [
					'sanitize_callback' => 'sanitize_email',
					'default'           => '',
				],
			],
		];

		// Get enabled email notifications for a form.
		$endpoints['entries/(?P<form_id>\d+)/enabled-email-notifications'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_enabled_email_notifications' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id' => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
			],
		];
		// Update Entry Data.
		$endpoints['entry/edit'] = [
			'methods'             => 'PUT',
			'callback'            => [ $this, 'update_entry_data' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'id'        => [
					'required'          => true,
					'sanitize_callback' => 'absint',
				],
				'form_data' => [
					'required'          => true,
					'validate_callback' => [ $this, 'validate_entry_form_data' ],
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Delete a specific entry log.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function delete_entry_log( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_id = absint( $request->get_param( 'id' ) );
		$log_id   = absint( $request->get_param( 'log_id' ) );

		if ( empty( $entry_id ) || ! isset( $log_id ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry ID and Log ID are required.', 'sureforms-pro' ) ],
				400
			);
		}

		$entry = Entries::get( $entry_id );

		if ( ! $entry ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry not found.', 'sureforms-pro' ) ],
				404
			);
		}

		$logs = isset( $entry['logs'] ) && is_array( $entry['logs'] ) ? $entry['logs'] : [];

		if ( ! isset( $logs[ $log_id ] ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Log not found.', 'sureforms-pro' ) ],
				404
			);
		}

		// Remove the log at the specified index.
		unset( $logs[ $log_id ] );
		$logs = array_values( $logs );

		// Update the entry with modified logs.
		$update_result = Entries::get_instance()->use_update(
			[ 'logs' => $logs ],
			[ 'ID' => absint( $entry_id ) ]
		);

		if ( false === $update_result ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Failed to delete log.', 'sureforms-pro' ) ],
				500
			);
		}

		return new \WP_REST_Response( [ 'success' => true ], 200 );
	}

	/**
	 * Delete a specific entry note.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function delete_entry_note( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_id = absint( $request->get_param( 'id' ) );
		$note_id  = sanitize_text_field( Helper::get_string_value( $request->get_param( 'note_id' ) ) );

		if ( empty( $entry_id ) || empty( $note_id ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry ID and Note ID are required.', 'sureforms-pro' ) ],
				400
			);
		}

		$entry = Entries::get( $entry_id );

		if ( ! $entry ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry not found.', 'sureforms-pro' ) ],
				404
			);
		}

		$notes      = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$note_found = false;

		// Find and remove the note with matching ID.
		foreach ( $notes as $index => $note ) {
			if ( isset( $note['id'] ) && Helper::get_string_value( $note['id'] ) === Helper::get_string_value( $note_id ) ) {
				array_splice( $notes, $index, 1 );
				$note_found = true;
				break;
			}
		}

		if ( ! $note_found ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Note not found.', 'sureforms-pro' ) ],
				404
			);
		}

		// Update the entry with modified notes.
		$update_result = Entries::get_instance()->update(
			$entry_id,
			[ 'notes' => $notes ]
		);

		if ( false === $update_result ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Failed to delete note.', 'sureforms-pro' ) ],
				500
			);
		}

		return new \WP_REST_Response( [ 'success' => true ], 200 );
	}

	/**
	 * Get entry notes with pagination support.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function get_entry_notes( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_id = absint( $request->get_param( 'id' ) );
		$per_page = absint( $request->get_param( 'per_page' ) );
		$per_page = $per_page ? $per_page : 3;
		$page     = absint( $request->get_param( 'page' ) );
		$page     = $page ? $page : 1;

		if ( empty( $entry_id ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry ID is required.', 'sureforms-pro' ) ],
				400
			);
		}

		$entry = Entries::get( $entry_id );

		if ( ! $entry ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry not found.', 'sureforms-pro' ) ],
				404
			);
		}

		$notes = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];

		// Sort notes by timestamp in descending order (newest first).
		usort(
			$notes,
			static function( $a, $b ) {
				return ( $b['timestamp'] ?? 0 ) - ( $a['timestamp'] ?? 0 );
			}
		);

		$total_notes = count( $notes );
		$total_pages = ceil( $total_notes / $per_page );
		$offset      = ( $page - 1 ) * $per_page;

		// Paginate notes.
		$paginated_notes = array_slice( Helper::get_array_value( $notes ), $offset, $per_page );

		// Format notes with unique IDs for operations.
		$formatted_notes = [];
		foreach ( $paginated_notes as $note ) {
			if ( ! is_array( $note ) ) {
				continue;
			}
			$formatted_notes[] = [
				'id'          => $note['id'] ?? time(), // Use stored ID or generate one.
				'note'        => $note['note'] ?? '',
				'timestamp'   => $note['timestamp'] ?? time(),
				'author'      => $note['author'] ?? get_current_user_id(),
				'author_name' => $note['author_name'] ?? wp_get_current_user()->display_name,
			];
		}

		$response_data = [
			'notes'        => $formatted_notes,
			'current_page' => $page,
			'per_page'     => $per_page,
			'total'        => $total_notes,
			'total_pages'  => $total_pages,
		];

		return new \WP_REST_Response( $response_data, 200 );
	}

	/**
	 * Add a new note to an entry.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function add_entry_note( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		$entry_id = absint( $request->get_param( 'id' ) );
		$content  = sanitize_textarea_field( Helper::get_string_value( $request->get_param( 'note' ) ) );

		if ( empty( $entry_id ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry ID is required.', 'sureforms-pro' ) ],
				400
			);
		}

		if ( empty( $content ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Note content is required.', 'sureforms-pro' ) ],
				400
			);
		}

		$entry = Entries::get( $entry_id );

		if ( ! $entry ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry not found.', 'sureforms-pro' ) ],
				404
			);
		}

		$notes        = isset( $entry['notes'] ) && is_array( $entry['notes'] ) ? $entry['notes'] : [];
		$current_user = wp_get_current_user();
		$timestamp    = time();

		// Create new note.
		$new_note = [
			'id'          => $timestamp, // Unique ID with timestamp.
			'note'        => $content,
			'timestamp'   => $timestamp,
			'author'      => $current_user->ID,
			'author_name' => $current_user->display_name,
		];

		// Add note to the beginning of the array (newest first).
		array_unshift( $notes, $new_note );

		// Update the entry with new notes.
		$update_result = Entries::get_instance()->update(
			$entry_id,
			[ 'notes' => $notes ]
		);

		if ( false === $update_result ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Failed to add note.', 'sureforms-pro' ) ],
				500
			);
		}

		return new \WP_REST_Response(
			[
				'success' => true,
				'note'    => $new_note,
			],
			201
		);
	}

	/**
	 * Resend notification for single or multiple entries.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function resend_notification( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		if ( ! Helper::current_user_can() ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Permission denied.', 'sureforms-pro' ) ],
				403
			);
		}

		// Get entry IDs from request body (supports single or multiple).
		$entry_ids_param       = $request->get_param( 'entry_ids' );
		$form_id               = absint( $request->get_param( 'form_id' ) );
		$email_notification_id = absint( $request->get_param( 'email_notification' ) );
		$send_to               = sanitize_text_field( Helper::get_string_value( $request->get_param( 'send_to' ) ) );
		$send_to               = $send_to ? $send_to : 'default';
		$recipient             = '';

		// Parse entry IDs (string, array, or single number).
		$entry_ids = [];
		if ( is_string( $entry_ids_param ) ) {
			// Handle comma-separated string or single ID.
			$entry_ids = array_map( 'absint', explode( ',', $entry_ids_param ) );
		} elseif ( is_array( $entry_ids_param ) ) {
			// Handle array of IDs.
			$entry_ids = array_map( 'absint', $entry_ids_param );
		} elseif ( is_numeric( $entry_ids_param ) ) {
			// Handle single numeric ID.
			$entry_ids = [ absint( $entry_ids_param ) ];
		}

		if ( empty( $entry_ids ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Entry ID(s) are required.', 'sureforms-pro' ) ],
				400
			);
		}

		if ( 'other' === $send_to ) {
			$recipient = sanitize_email( Helper::get_string_value( $request->get_param( 'recipient' ) ) );
			if ( ! is_email( $recipient ) ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'You must provide a valid email for the recipient.', 'sureforms-pro' ) ],
					400
				);
			}
		}

		// Get form_id from first entry if not provided.
		if ( ! $form_id ) {
			$first_entry = Entries::get( $entry_ids[0] );
			if ( ! $first_entry ) {
				return new \WP_REST_Response(
					[ 'error' => __( 'Entry not found.', 'sureforms-pro' ) ],
					404
				);
			}
			$form_id = $first_entry['form_id'];
		}

		$email_notifications = Helper::get_array_value( get_post_meta( Helper::get_integer_value( $form_id ), '_srfm_email_notification', true ) );

		if ( empty( $email_notifications ) || ! is_array( $email_notifications ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'No email notifications found for this form.', 'sureforms-pro' ) ],
				404
			);
		}

		$notification_found = false;
		$display_name       = wp_get_current_user()->display_name;

		foreach ( $email_notifications as $notification ) {
			// If email_notification_id is provided, only process that specific notification.
			if ( $email_notification_id && absint( $notification['id'] ) !== $email_notification_id ) {
				continue;
			}

			if ( true !== $notification['status'] ) {
				// Email notification is toggled off, skip it.
				continue;
			}

			$notification_found = true;

			// Process each entry ID.
			foreach ( $entry_ids as $entry_id ) {
				// We don't want the same instance here, instead we need to init new object for each entry id here.
				$entries_db = new Entries();
				$log_key    = $entries_db->add_log(
					sprintf(
						/* translators: Here %1$s is email notification label and %2$s is the user display name. */
						__( 'Resend email notification "%1$s" initiated by %2$s.', 'sureforms-pro' ),
						esc_html( $notification['name'] ),
						esc_html( $display_name )
					)
				);

				$form_data = Helper::get_array_value( $entries_db::get( $entry_id )['form_data'] );
				Block_Assets::prepare_color_picker_email_fields( absint( $form_id ) );
				$parsed = Form_Submit::parse_email_notification_template( $form_data, $notification );

				// Fire the same action as the initial send so extensions (e.g. attach-uploads) can process.
				do_action( 'srfm_before_email_send', $parsed, $form_data, $notification, [ 'form-id' => $form_id ] );

				// If user has provided recipient then reroute email to user provided recipient.
				$email_to = $recipient ? $recipient : $parsed['to'];
				$sent     = wp_mail( $email_to, $parsed['subject'], $parsed['message'], $parsed['headers'] );

				// Log the result.
				/* translators: Here, %s is email address. */
				$log_message = $sent ? sprintf( __( 'Email notification recipient: %s', 'sureforms-pro' ), esc_html( $email_to ) ) : sprintf( __( 'Failed sending email notification to %s', 'sureforms-pro' ), esc_html( $email_to ) );

				if ( is_int( $log_key ) ) {
					$entries_db->update_log( $log_key, null, [ $log_message ] );
				}

				// Update the entry with modified logs.
				$entries_db::update(
					$entry_id,
					[
						'logs' => $entries_db->get_logs(),
					]
				);
			}
		}

		if ( ! $notification_found ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'No active email notifications found.', 'sureforms-pro' ) ],
				404
			);
		}

		return new \WP_REST_Response(
			[
				'success' => true,
				'message' => __( 'Email notification sent successfully.', 'sureforms-pro' ),
			],
			200
		);
	}

	/**
	 * Get enabled email notifications for a form.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response
	 */
	public function get_enabled_email_notifications( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );

		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Nonce verification failed.', 'sureforms-pro' ) ],
				403
			);
		}

		$form_id = absint( $request->get_param( 'form_id' ) );

		if ( empty( $form_id ) ) {
			return new \WP_REST_Response(
				[ 'error' => __( 'Form ID is required.', 'sureforms-pro' ) ],
				400
			);
		}

		/**
		 * Retrieve email notification options from form meta.
		 *
		 * @var array<int|string, array<string, bool|int|string>> $email_notifications Email notification option items.
		 */
		$email_notifications = Helper::get_array_value( get_post_meta( $form_id, '_srfm_email_notification', true ) );

		if ( empty( $email_notifications ) ) {
			return new \WP_REST_Response(
				[ 'enabled_email_notifications' => [] ],
				200
			);
		}

		$enabled_email_notifications = Entries_Management::get_enabled_email_notifications( $email_notifications );

		return new \WP_REST_Response(
			[ 'enabled_email_notifications' => $enabled_email_notifications ],
			200
		);
	}

	/**
	 * Register starter blocks.
	 *
	 * @param array $blocks Blocks.
	 * @return array
	 */
	public function register_pro_blocks( $blocks ) {
		$blocks[] = [
			'dir'       => SRFM_PRO_DIR . 'inc/blocks/**/*.php',
			'namespace' => 'SRFM_PRO\\Inc\\Blocks',
		];
		return $blocks;
	}

	/**
	 * Registers the sureforms metas.
	 *
	 * @return void
	 * @since 1.4.0
	 */
	public function register_starter_post_metas() {
		// Registers metas that are common for the variations of premium plugin.
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_premium_common',
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => static function( $meta_value ) {
					if ( ! is_array( $meta_value ) ) {
						return [];
					}
					return [
						'is_welcome_screen'        => isset( $meta_value['is_welcome_screen'] ) ? filter_var( $meta_value['is_welcome_screen'], FILTER_VALIDATE_BOOLEAN ) : false,
						'welcome_screen_heading'   => isset( $meta_value['welcome_screen_heading'] ) ? sanitize_text_field( $meta_value['welcome_screen_heading'] ) : '',
						'welcome_screen_message'   => isset( $meta_value['welcome_screen_message'] ) ? sanitize_text_field( $meta_value['welcome_screen_message'] ) : '',
						'welcome_screen_image'     => isset( $meta_value['welcome_screen_image'] ) ? esc_url_raw( $meta_value['welcome_screen_image'] ) : '',
						'start_btn_text'           => isset( $meta_value['start_btn_text'] ) ? sanitize_text_field( $meta_value['start_btn_text'] ) : '',
						'heading_text_size'        => isset( $meta_value['heading_text_size'] ) ? floatval( $meta_value['heading_text_size'] ) : 30,
						'heading_text_size_unit'   => isset( $meta_value['heading_text_size_unit'] ) ? sanitize_text_field( $meta_value['heading_text_size_unit'] ) : 'px',
						'heading_line_height'      => isset( $meta_value['heading_line_height'] ) ? floatval( $meta_value['heading_line_height'] ) : 1.4,
						'heading_line_height_unit' => isset( $meta_value['heading_line_height_unit'] ) ? sanitize_text_field( $meta_value['heading_line_height_unit'] ) : 'em',
						'message_text_size'        => isset( $meta_value['message_text_size'] ) ? floatval( $meta_value['message_text_size'] ) : 18,
						'message_text_size_unit'   => isset( $meta_value['message_text_size_unit'] ) ? sanitize_text_field( $meta_value['message_text_size_unit'] ) : 'px',
						'message_line_height'      => isset( $meta_value['message_line_height'] ) ? floatval( $meta_value['message_line_height'] ) : 1.4,
						'message_line_height_unit' => isset( $meta_value['message_line_height_unit'] ) ? sanitize_text_field( $meta_value['message_line_height_unit'] ) : 'em',
					];
				},
				'show_in_rest'      => [
					'schema' => [
						'type'       => 'object',
						'context'    => [ 'edit' ],
						'properties' => [
							'is_welcome_screen'        => [
								'type' => 'boolean',
							],
							'welcome_screen_heading'   => [
								'type' => 'string',
							],
							'welcome_screen_message'   => [
								'type' => 'string',
							],
							'welcome_screen_image'     => [
								'type' => 'string',
							],
							'start_btn_text'           => [
								'type' => 'string',
							],
							// Welcome Screen Heading Size.
							'heading_text_size'        => [
								'type' => 'number',
							],
							'heading_text_size_unit'   => [
								'type' => 'string',
							],
							'heading_line_height'      => [
								'type' => 'number',
							],
							'heading_line_height_unit' => [
								'type' => 'string',
							],
							// Welcome Screen Message Size.
							'message_text_size'        => [
								'type' => 'number',
							],
							'message_text_size_unit'   => [
								'type' => 'string',
							],
							'message_line_height'      => [
								'type' => 'number',
							],
							'message_line_height_unit' => [
								'type' => 'string',
							],
						],
					],
				],
				'default'           => [
					'is_welcome_screen'        => false,
					'welcome_screen_heading'   => __( 'Help Us Gather Valuable Insights!', 'sureforms-pro' ),
					'welcome_screen_message'   => __( 'Answer a few quick questions to share your thoughts and make your voice heard.', 'sureforms-pro' ),
					'welcome_screen_image'     => '',
					'start_btn_text'           => __( 'Get Started', 'sureforms-pro' ),
					// Welcome Screen Heading Size.
					'heading_text_size'        => 30,
					'heading_text_size_unit'   => 'px',
					'heading_line_height'      => 1.4,
					'heading_line_height_unit' => 'em',
					// Welcome Screen Message Size.
					'message_text_size'        => 18,
					'message_text_size_unit'   => 'px',
					'message_line_height'      => 1.4,
					'message_line_height_unit' => 'em',
				],
			]
		);

		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_forms_styling_starter',
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => static function( $meta_value ) {
					return Helper::sanitize_by_type( $meta_value );
				},
				'show_in_rest'      => [
					'schema' => [
						'type'       => 'object',
						'context'    => [ 'edit' ],
						'properties' => [
							'form_theme'                   => [
								'type' => 'string',
							],
							// Background — owned per-preset; see the
							// `get_common_schema_properties()` rationale in
							// `form-presets.php`. Starter (Custom) carries
							// the field so user edits made under Custom persist
							// on this preset only.
							'bg_color'                     => [
								'type' => 'string',
							],
							'bg_type'                      => [
								'type' => 'string',
							],
							// Background gradient fields — mirrored so
							// `--srfm-bg-gradient` and bg-type classes are
							// correct on the frontend when using this preset.
							'bg_gradient'                  => [
								'type' => 'string',
							],
							'bg_gradient_type'             => [
								'type' => 'string',
							],
							'bg_gradient_color_1'          => [
								'type' => 'string',
							],
							'bg_gradient_color_2'          => [
								'type' => 'string',
							],
							'bg_gradient_location_1'       => [
								'type' => 'integer',
							],
							'bg_gradient_location_2'       => [
								'type' => 'integer',
							],
							'bg_gradient_angle'            => [
								'type' => 'integer',
							],
							'bg_gradient_overlay_type'     => [
								'type' => 'string',
							],
							'bg_image_overlay_color'       => [
								'type' => 'string',
							],
							// Background image fields — mirrored so image
							// URL / attachment / repeat / size are preserved
							// when the preset is applied to another form.
							'bg_image'                     => [
								'type' => 'string',
							],
							'bg_image_attachment'          => [
								'type' => 'string',
							],
							'bg_image_repeat'              => [
								'type' => 'string',
							],
							'bg_image_size'                => [
								'type' => 'string',
							],
							'bg_image_size_custom'         => [
								'type' => 'integer',
							],
							'bg_image_size_custom_unit'    => [
								'type' => 'string',
							],
							// Form-level colour scheme — owned per-preset and
							// mirrored into `_srfm_forms_styling` by the JS
							// effect in `src/admin/form-stylings.js` so the
							// user's Background-panel Primary / Text /
							// Text-on-Primary edits land on the active preset
							// only.
							'primary_color'                => [
								'type' => 'string',
							],
							'text_color'                   => [
								'type' => 'string',
							],
							'text_color_on_primary'        => [
								'type' => 'string',
							],
							// Submit button alignment — mirrored so the
							// alignment persists when this preset is applied
							// to another form.
							'submit_button_alignment'      => [
								'type' => 'string',
							],
							'error_color'                  => [
								'type' => 'string',
							],
							'form_row_gap'                 => [
								'type' => 'integer',
							],
							'form_row_gap_type'            => [
								'type' => 'string',
							],
							'form_column_gap'              => [
								'type' => 'integer',
							],
							'form_column_gap_type'         => [
								'type' => 'string',
							],
							// Button Properties.
							'button_padding_top'           => [
								'type' => 'number',
							],
							'button_padding_right'         => [
								'type' => 'number',
							],
							'button_padding_bottom'        => [
								'type' => 'number',
							],
							'button_padding_left'          => [
								'type' => 'number',
							],
							'button_padding_unit'          => [
								'type' => 'string',
							],
							'button_padding_link'          => [
								'type' => 'boolean',
							],
							// Border Width.
							'button_border_style'          => [
								'type' => 'string',
							],
							'button_border_width_top'      => [
								'type' => 'number',
							],
							'button_border_width_right'    => [
								'type' => 'number',
							],
							'button_border_width_bottom'   => [
								'type' => 'number',
							],
							'button_border_width_left'     => [
								'type' => 'number',
							],
							'button_border_width_link'     => [
								'type' => 'boolean',
							],
							// Border Radius.
							'button_border_radius_top'     => [
								'type' => 'number',
							],
							'button_border_radius_right'   => [
								'type' => 'number',
							],
							'button_border_radius_bottom'  => [
								'type' => 'number',
							],
							'button_border_radius_left'    => [
								'type' => 'number',
							],
							'button_border_radius_unit'    => [
								'type' => 'string',
							],
							'button_border_radius_link'    => [
								'type' => 'boolean',
							],
							// Border Color.
							'button_border_color_normal'   => [
								'type' => 'string',
							],
							'button_border_color_hover'    => [
								'type' => 'string',
							],
							// Background Normal.
							'button_text_color_normal'     => [
								'type' => 'string',
							],
							'button_background_type_normal' => [
								'type' => 'string',
							],
							'button_background_color_normal' => [
								'type' => 'string',
							],
							'button_gradient_type_normal'  => [
								'type' => 'string',
							],
							'button_background_gradient_type_normal' => [
								'type' => 'string',
							],
							'button_background_gradient_color_1_normal' => [
								'type' => 'string',
							],
							'button_background_gradient_color_2_normal' => [
								'type' => 'string',
							],
							'button_background_gradient_location_1_normal' => [
								'type' => 'integer',
							],
							'button_background_gradient_location_2_normal' => [
								'type' => 'integer',
							],
							'button_background_gradient_angle_normal' => [
								'type' => 'integer',
							],
							'button_background_gradient_normal' => [
								'type' => 'string',
							],
							// Background Hover.
							'button_text_color_hover'      => [
								'type' => 'string',
							],
							'button_background_type_hover' => [
								'type' => 'string',
							],
							'button_background_color_hover' => [
								'type' => 'string',
							],
							'button_gradient_type_hover'   => [
								'type' => 'string',
							],
							'button_background_gradient_type_hover' => [
								'type' => 'string',
							],
							'button_background_gradient_color_1_hover' => [
								'type' => 'string',
							],
							'button_background_gradient_color_2_hover' => [
								'type' => 'string',
							],
							'button_background_gradient_location_1_hover' => [
								'type' => 'integer',
							],
							'button_background_gradient_location_2_hover' => [
								'type' => 'integer',
							],
							'button_background_gradient_angle_hover' => [
								'type' => 'integer',
							],
							'button_background_gradient_hover' => [
								'type' => 'string',
							],
							// Typography.
							'button_text_size'             => [
								'type' => 'number',
							],
							'button_text_size_unit'        => [
								'type' => 'string',
							],
							'button_line_height'           => [
								'type' => 'number',
							],
							'button_line_height_unit'      => [
								'type' => 'string',
							],
							// Field Properties.
							'field_bg_color'               => [
								'type' => 'string',
							],
							'field_label_color'            => [
								'type' => 'string',
							],
							// Input text color — drives `--srfm-color-input-text`
							// for the standalone form (emitted only when set; see
							// `add_premium_form_styling_variables` below). Declared
							// on starter for parity with the other preset schemas.
							'field_input_color'            => [
								'type' => 'string',
							],
							'field_help_text_color'        => [
								'type' => 'string',
							],
							'field_label_size'             => [
								'type' => 'number',
							],
							'field_label_size_unit'        => [
								'type' => 'string',
							],
							'field_label_line_height'      => [
								'type' => 'number',
							],
							'field_label_line_height_unit' => [
								'type' => 'string',
							],
							'field_help_text_size'         => [
								'type' => 'number',
							],
							'field_help_text_size_unit'    => [
								'type' => 'string',
							],
							'field_help_text_line_height'  => [
								'type' => 'number',
							],
							'field_help_text_line_height_unit' => [
								'type' => 'string',
							],
							'field_border_color'           => [
								'type' => 'string',
							],
							'field_label_gap'              => [
								'type' => 'number',
							],
							'field_label_gap_unit'         => [
								'type' => 'string',
							],
							'field_border_width_top'       => [
								'type' => 'number',
							],
							'field_border_width_right'     => [
								'type' => 'number',
							],
							'field_border_width_bottom'    => [
								'type' => 'number',
							],
							'field_border_width_left'      => [
								'type' => 'number',
							],
							'field_border_width_unit'      => [
								'type' => 'string',
							],
							'field_border_width_link'      => [
								'type' => 'boolean',
							],
							'field_border_radius_top'      => [
								'type' => 'number',
							],
							'field_border_radius_right'    => [
								'type' => 'number',
							],
							'field_border_radius_bottom'   => [
								'type' => 'number',
							],
							'field_border_radius_left'     => [
								'type' => 'number',
							],
							'field_border_radius_unit'     => [
								'type' => 'string',
							],
							'field_border_radius_link'     => [
								'type' => 'boolean',
							],
							'field_box_shadow_color_normal' => [
								'type' => 'string',
							],
							'field_box_shadow_horizontal_offset_normal' => [
								'type' => 'number',
							],
							'field_box_shadow_vertical_offset_normal' => [
								'type' => 'number',
							],
							'field_box_shadow_blur_normal' => [
								'type' => 'number',
							],
							'field_box_shadow_spread_normal' => [
								'type' => 'number',
							],
							'field_box_shadow_position_normal' => [
								'type' => 'string',
							],
							'field_box_shadow_color_focus' => [
								'type' => 'string',
							],
							'field_box_shadow_horizontal_offset_focus' => [
								'type' => 'number',
							],
							'field_box_shadow_vertical_offset_focus' => [
								'type' => 'number',
							],
							'field_box_shadow_blur_focus'  => [
								'type' => 'number',
							],
							'field_box_shadow_spread_focus' => [
								'type' => 'number',
							],
							'field_box_shadow_position_focus' => [
								'type' => 'string',
							],
							// Page Break Buttons.
							'page_break_next_button_text_color_normal' => [
								'type' => 'string',
							],
							'page_break_next_button_background_color_normal' => [
								'type' => 'string',
							],
							'page_break_next_button_border_color_normal' => [
								'type' => 'string',
							],
							'page_break_back_button_text_color_normal' => [
								'type' => 'string',
							],
							'page_break_back_button_background_color_normal' => [
								'type' => 'string',
							],
							'page_break_back_button_border_color_normal' => [
								'type' => 'string',
							],
							'page_break_next_button_text_color_hover' => [
								'type' => 'string',
							],
							'page_break_next_button_background_color_hover' => [
								'type' => 'string',
							],
							'page_break_next_button_border_color_hover' => [
								'type' => 'string',
							],
							'page_break_back_button_text_color_hover' => [
								'type' => 'string',
							],
							'page_break_back_button_background_color_hover' => [
								'type' => 'string',
							],
							'page_break_back_button_border_color_hover' => [
								'type' => 'string',
							],

						],
					],
				],
				'default'           => [
					'form_theme'                       => 'default',
					// Background — mirrored into `_srfm_forms_styling.bg_color`
					// by the JS effect when the user switches to Custom. White
					// matches the historical default that lived on
					// `_srfm_forms_styling.bg_color` alone.
					'bg_color'                         => '#FFFFFF',
					'bg_type'                          => 'color',
					// Background gradient defaults — empty strings / zeros so
					// the free plugin's fallback values are used when no
					// gradient has been configured on this form.
					'bg_gradient'                      => '',
					'bg_gradient_type'                 => 'linear',
					'bg_gradient_color_1'              => '#FFC9B2',
					'bg_gradient_color_2'              => '#C7CBFF',
					'bg_gradient_location_1'           => 0,
					'bg_gradient_location_2'           => 100,
					'bg_gradient_angle'                => 90,
					'bg_gradient_overlay_type'         => '',
					'bg_image_overlay_color'           => '',
					// Background image defaults — empty so the image panel
					// starts with no image selected.
					'bg_image'                         => '',
					'bg_image_attachment'              => 'scroll',
					'bg_image_repeat'                  => 'no-repeat',
					'bg_image_size'                    => 'cover',
					'bg_image_size_custom'             => 100,
					'bg_image_size_custom_unit'        => '%',
					// Submit button alignment.
					'submit_button_alignment'          => 'left',
					// Form-level colour scheme — mirrored into
					// `_srfm_forms_styling` alongside `bg_color`. Values match
					// the JS-side fallbacks the free plugin uses when the
					// form-level meta is empty (primary_color → #111C44,
					// text_color → #1E1E1E, text_color_on_primary → #FFFFFF),
					// so existing Default/Custom forms see no visual change.
					'primary_color'                    => '#111C44',
					'text_color'                       => '#1E1E1E',
					'text_color_on_primary'            => '#FFFFFF',
					'error_color'                      => '#dc2626',
					'form_row_gap'                     => 18,
					'form_row_gap_type'                => 'px',
					'form_column_gap'                  => 16,
					'form_column_gap_type'             => 'px',
					// Button Properties.
					'button_padding_top'               => 10,
					'button_padding_right'             => 14,
					'button_padding_bottom'            => 10,
					'button_padding_left'              => 14,
					'button_padding_unit'              => 'px',
					'button_padding_link'              => false,
					// Border Width.
					'button_border_style'              => 'solid',
					'button_border_width_top'          => 1,
					'button_border_width_right'        => 1,
					'button_border_width_bottom'       => 1,
					'button_border_width_left'         => 1,
					'button_border_width_link'         => true,
					// Border Radius.
					'button_border_radius_top'         => 6,
					'button_border_radius_right'       => 6,
					'button_border_radius_bottom'      => 6,
					'button_border_radius_left'        => 6,
					'button_border_radius_unit'        => 'px',
					'button_border_radius_link'        => true,
					// Border Color.
					'button_border_color_normal'       => '',
					'button_border_color_hover'        => '',
					// Background Normal.
					'button_text_color_normal'         => '',
					'button_background_color_normal'   => '',
					'button_gradient_type_normal'      => 'basic',
					'button_background_gradient_type_normal' => 'linear',
					'button_background_gradient_angle_normal' => 90,
					'button_background_gradient_color_1_normal' => '#FFC9B2',
					'button_background_gradient_color_2_normal' => '#C7CBFF',
					'button_background_gradient_location_1_normal' => 0,
					'button_background_gradient_location_2_normal' => 100,
					// Background Hover.
					'button_text_color_hover'          => '',
					'button_background_color_hover'    => '',
					'button_gradient_type_hover'       => 'basic',
					'button_background_gradient_type_hover' => 'linear',
					'button_background_gradient_angle_hover' => 90,
					'button_background_gradient_color_1_hover' => '#FFC9B2',
					'button_background_gradient_color_2_hover' => '#C7CBFF',
					'button_background_gradient_location_1_hover' => 0,
					'button_background_gradient_location_2_hover' => 100,
					// Typography.
					'button_text_size'                 => 16,
					'button_text_size_unit'            => 'px',
					'button_line_height'               => 1.5,
					'button_line_height_unit'          => 'em',
					// Field Properties.
					// Field colour defaults intentionally LEFT EMPTY on
					// the Custom (starter) preset for the same reason
					// they're empty in `form-presets.php::get_common_default_values()`:
					// without explicit overrides, the free plugin's
					// `text_color`-derived emissions cascade through, so
					// user edits to Text Color in the Background panel
					// propagate to label / input text / description /
					// input bg / border live. Users can still override
					// any of these via the Custom-panel field-colour
					// pickers — when they do, the picker writes the new
					// value into starter meta and the conditional
					// hooks.php emission below (lines ~1760-1773) starts
					// emitting it.
					'field_bg_color'                   => '',
					'field_label_color'                => '',
					'field_help_text_color'            => '',
					'field_label_size'                 => 16,
					'field_label_size_unit'            => 'px',
					'field_label_line_height'          => 1.5,
					'field_label_line_height_unit'     => 'em',
					'field_help_text_size'             => 14,
					'field_help_text_size_unit'        => 'px',
					'field_help_text_line_height'      => 1.4,
					'field_help_text_line_height_unit' => 'em',
					'field_border_color'               => '',
					'field_label_gap'                  => 6,
					'field_label_gap_unit'             => 'px',
					'field_border_width_top'           => 1,
					'field_border_width_right'         => 1,
					'field_border_width_bottom'        => 1,
					'field_border_width_left'          => 1,
					'field_border_width_unit'          => 'px',
					'field_border_width_link'          => true,
					'field_border_radius_top'          => 6,
					'field_border_radius_right'        => 6,
					'field_border_radius_bottom'       => 6,
					'field_border_radius_left'         => 6,
					'field_border_radius_unit'         => 'px',
					'field_border_radius_link'         => true,
					// Field Box Shadow Properties.
					'field_box_shadow_color_normal'    => '',
					'field_box_shadow_horizontal_offset_normal' => 0,
					'field_box_shadow_vertical_offset_normal' => 0,
					'field_box_shadow_blur_normal'     => 0,
					'field_box_shadow_spread_normal'   => 0,
					'field_box_shadow_position_normal' => 'outset',
					'field_box_shadow_color_focus'     => '',
					'field_box_shadow_horizontal_offset_focus' => 0,
					'field_box_shadow_vertical_offset_focus' => 0,
					'field_box_shadow_blur_focus'      => 0,
					'field_box_shadow_spread_focus'    => 3,
					'field_box_shadow_position_focus'  => 'outset',
					// Page Break Button Properties.
					'page_break_next_button_text_color_normal' => '#FFFFFF',
					'page_break_next_button_background_color_normal' => '#434343',
					'page_break_next_button_border_color_normal' => '#434343',
					'page_break_back_button_text_color_normal' => '#FFFFFF',
					'page_break_back_button_background_color_normal' => '#434343',
					'page_break_back_button_border_color_normal' => '#434343',
					'page_break_next_button_text_color_hover' => '#FFFFFFCC',
					'page_break_next_button_background_color_hover' => '#434343CC',
					'page_break_next_button_border_color_hover' => '#434343CC',
					'page_break_back_button_text_color_hover' => '#FFFFFFCC',
					'page_break_back_button_background_color_hover' => '#434343CC',
					'page_break_back_button_border_color_hover' => '#434343CC',
				],
			]
		);
	}

	/**
	 * Add pro-only scalar meta keys to the import allowlist.
	 *
	 * @param array<string> $scalar_metas Existing scalar meta keys.
	 * @since 2.8.0
	 * @return array<string>
	 */
	public function add_pro_import_scalar_meta_keys( $scalar_metas ) {
		$pro_scalar_metas = [
			'_srfm_additional_form_restriction',
			'_srfm_conditional_confirmation',
			'_srfm_email_conditional_meta',
			'_srfm_field_restriction',
			'_srfm_native_integrations',
			'_srfm_partial_entries',
			'_srfm_pdf_meta',
			'_srfm_quiz_meta',
			'_srfm_raw_cpt_meta',
			'_srfm_recurring_entry_limit',
			'_srfm_save_resume',
			'_srfm_submit_button_disable',
		];
		return array_merge( $scalar_metas, $pro_scalar_metas );
	}

	/**
	 * Append pro meta keys to the form-settings REST allowlist so the
	 * per-tab Save flow (`POST /sureforms/v1/form-settings`) can persist
	 * pro meta. The list grows as more pro tabs migrate to the
	 * explicit-Save pattern.
	 *
	 * @hooked srfm_form_settings_allowed_meta_keys
	 *
	 * @param mixed $meta_keys Free's default allowlist (string[]).
	 * @since 2.9.0
	 * @return array<string>
	 */
	public function add_pro_form_settings_meta_keys( $meta_keys ) {
		$existing = is_array( $meta_keys ) ? $meta_keys : [];
		$pro_keys = [
			'_srfm_save_resume',
			'_srfm_conditional_confirmation',
			'_srfm_pdf_meta',
			'_srfm_quiz_meta',
			'_srfm_user_registration_settings',
			'_srfm_raw_cpt_meta',
			'_srfm_survey_meta',
			'_srfm_integrations_webhooks',
			'_srfm_native_integrations',
			'_srfm_additional_form_restriction',
			'_srfm_field_restriction',
			'_srfm_email_attach_uploads_meta',
			'_srfm_email_conditional_meta',
			'_srfm_partial_entries',
		];
		return array_values( array_unique( array_merge( $existing, $pro_keys ) ) );
	}

	/**
	 * Adds the pro blocks in the list free SureForms blocks.
	 *
	 * @param array<string> $blocks SureForms block list.
	 * @since 0.0.1
	 * @return array<string>
	 */
	public function add_pro_blocks( $blocks ) {
		$pro_blocks = [
			// pro blocks.
			'srfm/date-picker',
			'srfm/time-picker',
			'srfm/hidden',
			'srfm/slider',
			'srfm/rating',
			'srfm/upload',
			'srfm/html',
			'srfm/nps',
		];

		return array_merge( $blocks, $pro_blocks );
	}

	/**
	 * Adds css variables for pro blocks.
	 *
	 * @param array<string|mixed> $sizes array of css variables coming from hook 'srfm_css_vars_sizes'.
	 * @since 0.0.1
	 * @return array<string|mixed>
	 */
	public function merge_pro_block_sizes( $sizes ) {
		if ( ! is_array( $sizes ) || empty( $sizes ) ) {
			return $sizes;
		}

		$pro_block_sizes = [
			'small'  => [
				// Upload block variables.
				'--srfm-upload-vertical-padding'       => '24px',
				'--srfm-upload-inner-gap'              => '12px',
				'--srfm-upload-text-line-height'       => '20px',
				'--srfm-upload-file-margin-top'        => '12px',
				'--srfm-upload-preview-size'           => '40px',
				// Slider block variables.
				'--srfm-slider-label-font-size'        => '12px',
				'--srfm-slider-label-line-height'      => '16px',
				'--srfm-slider-label-top-padding'      => '6px',
				'--srfm-slider-error-gap'              => '4px',
				// Page break block variables.
				'--srfm-page-break-row-gap'            => '24px',
				'--srfm-rating-icon-size'              => '24px',
				'--srfm-rating-icon-gap'               => '4px',

				// Datepicker block variables.
				'--srfm-datepicker-dropdown-input-gap' => '4px',
			],
			'medium' => [
				// Upload block variables.
				'--srfm-upload-vertical-padding'       => '28px',
				'--srfm-upload-text-line-height'       => '24px',
				'--srfm-upload-file-margin-top'        => '16px',
				'--srfm-upload-preview-size'           => '42px',
				// Slider block variables.
				'--srfm-slider-label-top-padding'      => '8px',
				'--srfm-slider-error-gap'              => '6px',
				// Page break block variables.
				'--srfm-page-break-row-gap'            => '28px',
				'--srfm-rating-icon-size'              => '28px',
				'--srfm-rating-icon-gap'               => '6px',

				// Datepicker block variables.
				'--srfm-datepicker-dropdown-input-gap' => '4px',
			],
			'large'  => [
				// Upload block variables.
				'--srfm-upload-vertical-padding'       => '32px',
				'--srfm-upload-inner-gap'              => '14px',
				'--srfm-upload-text-line-height'       => '28px',
				'--srfm-upload-file-margin-top'        => '16px',
				'--srfm-upload-preview-size'           => '48px',
				// Slider block variables.
				'--srfm-slider-label-font-size'        => '14px',
				'--srfm-slider-label-line-height'      => '20px',
				'--srfm-slider-label-top-padding'      => '10px',
				'--srfm-slider-error-gap'              => '8px',
				// Page break block variables.
				'--srfm-page-break-row-gap'            => '32px',
				'--srfm-rating-icon-size'              => '36px',
				'--srfm-rating-icon-gap'               => '8px',

				// Datepicker block variables.
				'--srfm-datepicker-dropdown-input-gap' => '6px',
			],
		];

		return array_replace_recursive( $sizes, $pro_block_sizes );
	}
	/**
	 * Add pro block's default error message values.
	 *
	 * @Hooked - srfm_default_dynamic_block_option
	 *
	 * @since 0.0.1
	 * @param array<mixed> $default_values the default values.
	 * @param array<mixed> $common_err_msg the common error message.
	 * @return array<mixed>
	 */
	public static function add_default_dynamic_pro_block_values( $default_values, $common_err_msg ) {

		$default_pro_values = [
			// Note: These password strength messages are prepared for the password block.
			// As of now, the password block is not registered in SureForms. Once registered, these messages should be used.
			// phpcs:ignore
			// 'srfm_password_block_required_text'    => $common_err_msg['required'],
			// phpcs:enable
			'srfm_rating_block_required_text'             => $common_err_msg['required'],
			'srfm_date_picker_block_required_text'        => $common_err_msg['required'],
			'srfm_time_picker_block_required_text'        => $common_err_msg['required'],
			'srfm_upload_block_required_text'             => $common_err_msg['required'],
			'srfm_slider_block_required_text'             => $common_err_msg['required'],
			'srfm_nps_block_required_text'                => $common_err_msg['required'],
			'srfm_input_color_picker_block_required_text' => $common_err_msg['required'],
		];

		return array_merge( $default_values, $default_pro_values );
	}

	/**
	 * Backfill defaults for dynamic block option keys that are missing from a
	 * saved option. Keeps the Validation Settings page backward compatible when
	 * new message keys (e.g. the color picker required text) are introduced after
	 * a site already saved its dynamic block options.
	 *
	 * @Hooked - srfm_global_settings_data
	 *
	 * @since 2.10.0
	 * @param array<mixed> $global_setting_options Global settings payload.
	 * @return array<mixed>
	 */
	public function backfill_dynamic_block_option_defaults( $global_setting_options ) {
		if (
			isset( $global_setting_options['srfm_default_dynamic_block_option'] ) &&
			is_array( $global_setting_options['srfm_default_dynamic_block_option'] )
		) {
			$global_setting_options['srfm_default_dynamic_block_option'] = wp_parse_args(
				$global_setting_options['srfm_default_dynamic_block_option'],
				Helper::default_dynamic_block_option()
			);
		}

		return $global_setting_options;
	}

	/**
	 * Add pro options in the default options to save.
	 *
	 * @Hooked - srfm_general_dynamic_options_to_save
	 *
	 * @since 0.0.1
	 * @param array<mixed> $default_options the default free options.
	 * @param array<mixed> $setting_options the setting options.
	 * @return array<mixed>
	 */
	public static function add_pro_options_to_save( $default_options, $setting_options ) {
		$pro_options_keys = [
			'srfm_rating_block_required_text',
			'srfm_date_picker_block_required_text',
			'srfm_time_picker_block_required_text',
			'srfm_upload_block_required_text',
			'srfm_slider_block_required_text',
			'srfm_nps_block_required_text',
			// Note: These password strength messages are prepared for the password block.
			// As of now, the password block is not registered in SureForms. Once registered, these messages should be used.
			// phpcs:ignore
			/*
			'srfm_password_block_required_text',
			'srfm_password_strength_weak',
			'srfm_password_strength_medium',
			'srfm_password_strength_strong',
			'srfm_password_strength_very_strong',
			*/
			// phpcs:enable
			'srfm_file_size_exceed',
			'srfm_file_type_not_allowed',
			'srfm_file_upload_limit',
			'srfm_input_color_picker_block_required_text',
		];

		$pro_options_to_save = [];

		foreach ( $pro_options_keys as $key ) {
			if ( isset( $setting_options[ $key ] ) ) {
				$pro_options_to_save[ $key ] = $setting_options[ $key ];
			}
		}

		return array_merge( $default_options, $pro_options_to_save );
	}

	/**
	 * Add custom styling css variables.
	 *
	 * @param array<string,string> $params array of values sent by action 'srfm_form_css_variables'.
	 * @since 1.6.3
	 * @return void
	 */
	public function add_premium_form_styling_variables( $params ) {
		if ( empty( $params['id'] ) ) {
			return;
		}

		// Resolve the embed's `formTheme` override. The `srfm/form` block carries
		// its own `formTheme` block attribute so an embed can render with a
		// different theme than the form's saved one:
		// - 'custom'   → embed has per-block customisations; embed-styling.php
		// (priority 20) drives emission from block_attrs, so
		// bail here to avoid double-emitting.
		// - preset slug ('baseline'/'minimal'/'dark') → override the form's
		// saved `form_theme` with the embed's choice; fall
		// through and read that preset's meta below so the
		// form's saved per-preset customisations render.
		// - 'inherit' / missing → use the form's saved `form_theme`.
		$block_attrs = $params['block_attrs'] ?? [];
		$embed_theme = ! empty( $block_attrs ) && isset( $block_attrs['formTheme'] )
			? Helper::get_string_value( $block_attrs['formTheme'] )
			: 'inherit';
		if ( 'custom' === $embed_theme ) {
			return;
		}

		$form_id              = Helper::get_integer_value( $params['id'] );
		$form_styling_starter = Helper::get_array_value( get_post_meta( $form_id, '_srfm_forms_styling_starter', true ) );
		$srfm_premium_common  = Helper::get_array_value( get_post_meta( $form_id, '_srfm_premium_common', true ) );
		$is_welcome_screen    = $srfm_premium_common['is_welcome_screen'] ?? false;

		// Embed override wins when it names a registered preset slug; otherwise
		// the form's saved `form_theme` controls emission.
		if ( 'inherit' !== $embed_theme && null !== Pro_Helper::get_preset_styling_meta_key( $embed_theme ) ) {
			$form_theme = $embed_theme;
		} else {
			$form_theme = Helper::get_string_value( $form_styling_starter['form_theme'] ) ?? 'default';
		}
		$this->data['form_theme'] = $form_theme;

		$welcome_screen_vars = [
			// The welcome screen properties are stored in the _srfm_premium_common post meta.
			// Welcome Screen Properties.
			'--srfm-common-heading-font-size'   => $is_welcome_screen && isset( $srfm_premium_common['heading_text_size'] ) ? sanitize_text_field( "{$srfm_premium_common['heading_text_size']}{$srfm_premium_common['heading_text_size_unit']}" ) : '',
			'--srfm-common-heading-line-height' => $is_welcome_screen && isset( $srfm_premium_common['heading_line_height'] ) ? sanitize_text_field( "{$srfm_premium_common['heading_line_height']}{$srfm_premium_common['heading_line_height_unit']}" ) : '',
			'--srfm-common-message-font-size'   => $is_welcome_screen && isset( $srfm_premium_common['message_text_size'] ) ? sanitize_text_field( "{$srfm_premium_common['message_text_size']}{$srfm_premium_common['message_text_size_unit']}" ) : '',
			'--srfm-common-message-line-height' => $is_welcome_screen && isset( $srfm_premium_common['message_line_height'] ) ? sanitize_text_field( "{$srfm_premium_common['message_line_height']}{$srfm_premium_common['message_line_height_unit']}" ) : '',
		];

		// Resolve the active preset's meta key. Null = no meta-driven styling
		// from a base preset; might still be a user-created preset (stored
		// in wp_options) or plain 'default'.
		$preset_meta_key = Pro_Helper::get_preset_styling_meta_key( $form_theme );
		if ( null === $preset_meta_key ) {
			if ( Pro_Helper::is_user_preset_slug( $form_theme ) ) {
				// Lazy-working-copy model: the per-form
				// `_srfm_forms_styling_user_active` meta exists only when
				// the user has made uncommitted local edits to the preset
				// on this form. When `__dirty=true` AND `__slug` matches,
				// the working copy overrides the global option.
				$working_copy    = Helper::get_array_value(
					get_post_meta( $form_id, '_srfm_forms_styling_user_active', true )
				);
				$bare_slug       = Pro_Helper::get_user_preset_bare_slug( $form_theme );
				$has_local_edits =
					! empty( $working_copy )
					&& ! empty( $working_copy['__dirty'] )
					&& isset( $working_copy['__slug'] )
					&& $working_copy['__slug'] === $bare_slug;

				if ( $has_local_edits ) {
					// Strip bookkeeping fields before consuming as styles.
					unset(
						$working_copy['__dirty'],
						$working_copy['__slug'],
						$working_copy['base_preset']
					);
					// Merge global preset underneath: a working copy can
					// legitimately be partial (only the fields the user
					// actually edited) when the JS lazy-create write
					// landed before the cache fetch resolved. The global
					// option then fills any missing field; the working
					// copy still wins for any field it does set.
					$user_preset_styles   = Pro_Helper::get_user_preset_styles( $form_theme );
					$form_styling_starter = array_merge(
						is_array( $user_preset_styles ) ? $user_preset_styles : [],
						$working_copy
					);
				} else {
					$user_preset_styles = Pro_Helper::get_user_preset_styles( $form_theme );
					if ( empty( $user_preset_styles ) ) {
						// Preset was deleted globally — fall back to free defaults.
						if ( $is_welcome_screen ) {
							Pro_Helper::add_css_variables( $welcome_screen_vars );
						}
						return;
					}
					$form_styling_starter = $user_preset_styles;
				}
			} else {
				// Welcome screen variables still output when the form theme is 'default'.
				if ( $is_welcome_screen ) {
					Pro_Helper::add_css_variables( $welcome_screen_vars );
				}
				return;
			}
		} elseif ( '_srfm_forms_styling_starter' !== $preset_meta_key ) {
			// When the active preset is not 'custom' (i.e. starter), swap the styling source.
			$form_styling_starter = Helper::get_array_value( get_post_meta( $form_id, $preset_meta_key, true ) );
		}

		$error_color = Helper::get_string_value( $form_styling_starter['error_color'] ) ?? '#dc2626';
		$form        = [
			'row_gap'         => Helper::get_integer_value( $form_styling_starter['form_row_gap'] ) ?? 18,
			'row_gap_type'    => Helper::get_string_value( $form_styling_starter['form_row_gap_type'] ) ?? 'px',
			'column_gap'      => Helper::get_integer_value( $form_styling_starter['form_column_gap'] ) ?? 16,
			'column_gap_type' => Helper::get_string_value( $form_styling_starter['form_column_gap_type'] ) ?? 'px',
		];

		// Button Properties.
		$button            = [
			// Padding.
			'padding_top'          => isset( $form_styling_starter['button_padding_top'] ) && is_scalar( $form_styling_starter['button_padding_top'] ) ? floatval( $form_styling_starter['button_padding_top'] ) : 10,
			'padding_right'        => isset( $form_styling_starter['button_padding_right'] ) && is_scalar( $form_styling_starter['button_padding_right'] ) ? floatval( $form_styling_starter['button_padding_right'] ) : 14,
			'padding_bottom'       => isset( $form_styling_starter['button_padding_bottom'] ) && is_scalar( $form_styling_starter['button_padding_bottom'] ) ? floatval( $form_styling_starter['button_padding_bottom'] ) : 10,
			'padding_left'         => isset( $form_styling_starter['button_padding_left'] ) && is_scalar( $form_styling_starter['button_padding_left'] ) ? floatval( $form_styling_starter['button_padding_left'] ) : 14,
			'padding_unit'         => Helper::get_string_value( $form_styling_starter['button_padding_unit'] ) ?? 'px',
			// Border Style.
			'border_style'         => Helper::get_string_value( $form_styling_starter['button_border_style'] ) ?? 'solid',
			// Border Width.
			'border_width_top'     => isset( $form_styling_starter['button_border_width_top'] ) && is_scalar( $form_styling_starter['button_border_width_top'] ) ? floatval( $form_styling_starter['button_border_width_top'] ) : 1,
			'border_width_right'   => isset( $form_styling_starter['button_border_width_right'] ) && is_scalar( $form_styling_starter['button_border_width_right'] ) ? floatval( $form_styling_starter['button_border_width_right'] ) : 1,
			'border_width_bottom'  => isset( $form_styling_starter['button_border_width_bottom'] ) && is_scalar( $form_styling_starter['button_border_width_bottom'] ) ? floatval( $form_styling_starter['button_border_width_bottom'] ) : 1,
			'border_width_left'    => isset( $form_styling_starter['button_border_width_left'] ) && is_scalar( $form_styling_starter['button_border_width_left'] ) ? floatval( $form_styling_starter['button_border_width_left'] ) : 1,
			// Border Radius.
			'border_radius_top'    => isset( $form_styling_starter['button_border_radius_top'] ) && is_scalar( $form_styling_starter['button_border_radius_top'] ) ? floatval( $form_styling_starter['button_border_radius_top'] ) : 6,
			'border_radius_right'  => isset( $form_styling_starter['button_border_radius_right'] ) && is_scalar( $form_styling_starter['button_border_radius_right'] ) ? floatval( $form_styling_starter['button_border_radius_right'] ) : 6,
			'border_radius_bottom' => isset( $form_styling_starter['button_border_radius_bottom'] ) && is_scalar( $form_styling_starter['button_border_radius_bottom'] ) ? floatval( $form_styling_starter['button_border_radius_bottom'] ) : 6,
			'border_radius_left'   => isset( $form_styling_starter['button_border_radius_left'] ) && is_scalar( $form_styling_starter['button_border_radius_left'] ) ? floatval( $form_styling_starter['button_border_radius_left'] ) : 6,
			'border_radius_unit'   => Helper::get_string_value( $form_styling_starter['button_border_radius_unit'] ) ?? 'px',
			// Border Color.
			'border_color'         => Helper::get_string_value( $form_styling_starter['button_border_color_normal'] ) ?? '',
			'border_hover_color'   => Helper::get_string_value( $form_styling_starter['button_border_color_hover'] ) ?? '',
		];
		$border_properties = [];

		// Background Stylings.
		$is_advanced_gradient_normal = isset( $form_styling_starter['button_gradient_type_normal'] ) && 'advanced' === Helper::get_string_value( $form_styling_starter['button_gradient_type_normal'] );
		$btn_bg_normal               = [
			// Background Normal.
			'text_color'                     => isset( $form_styling_starter['button_text_color_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_text_color_normal'] ) : '',
			'background_type'                => isset( $form_styling_starter['button_background_type_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_type_normal'] ) : '',
			'background_color'               => isset( $form_styling_starter['button_background_color_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_color_normal'] ) : '',
			'background_gradient'            => isset( $form_styling_starter['button_background_gradient_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_normal'] ) : 'linear-gradient(90deg, #FFC9B2 0%, #C7CBFF 100%)',
			'background_gradient_type'       => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_type_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_type_normal'] ) : '',
			'background_gradient_color_1'    => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_color_1_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_color_1_normal'] ) : '',
			'background_gradient_color_2'    => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_color_2_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_color_2_normal'] ) : '',
			'background_gradient_location_1' => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_location_1_normal'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_location_1_normal'] ) : 0,
			'background_gradient_location_2' => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_location_2_normal'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_location_2_normal'] ) : 100,
			'background_gradient_angle'      => $is_advanced_gradient_normal && isset( $form_styling_starter['button_background_gradient_angle_normal'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_angle_normal'] ) : 90,
		];
		$bg_advanced_gradient_normal = $is_advanced_gradient_normal ? Helper::get_gradient_css( $btn_bg_normal['background_gradient_type'], $btn_bg_normal['background_gradient_color_1'], $btn_bg_normal['background_gradient_color_2'], $btn_bg_normal['background_gradient_location_1'], $btn_bg_normal['background_gradient_location_2'], $btn_bg_normal['background_gradient_angle'] ) : '';

		$is_advanced_gradient_hover = isset( $form_styling_starter['button_gradient_type_hover'] ) && 'advanced' === Helper::get_string_value( $form_styling_starter['button_gradient_type_hover'] );
		$btn_bg_hover               = [
			// Background Hover.
			'text_color'                     => isset( $form_styling_starter['button_text_color_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_text_color_hover'] ) : '',
			'background_type'                => isset( $form_styling_starter['button_background_type_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_type_hover'] ) : '',
			'background_color'               => isset( $form_styling_starter['button_background_color_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_color_hover'] ) : '',
			'background_gradient'            => isset( $form_styling_starter['button_background_gradient_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_hover'] ) : 'linear-gradient(90deg, #FFC9B2 0%, #C7CBFF 100%)',
			'background_gradient_type'       => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_type_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_type_hover'] ) : '',
			'background_gradient_color_1'    => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_color_1_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_color_1_hover'] ) : '',
			'background_gradient_color_2'    => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_color_2_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_gradient_color_2_hover'] ) : '',
			'background_gradient_location_1' => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_location_1_hover'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_location_1_hover'] ) : 0,
			'background_gradient_location_2' => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_location_2_hover'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_location_2_hover'] ) : 100,
			'background_gradient_angle'      => $is_advanced_gradient_hover && isset( $form_styling_starter['button_background_gradient_angle_hover'] ) ? Helper::get_integer_value( $form_styling_starter['button_background_gradient_angle_hover'] ) : 90,
		];
		$bg_advanced_gradient_hover = $is_advanced_gradient_hover ? Helper::get_gradient_css( $btn_bg_hover['background_gradient_type'], $btn_bg_hover['background_gradient_color_1'], $btn_bg_hover['background_gradient_color_2'], $btn_bg_hover['background_gradient_location_1'], $btn_bg_hover['background_gradient_location_2'], $btn_bg_hover['background_gradient_angle'] ) : '';
		$btn_typography             = [
			'font_size'        => $form_styling_starter['button_text_size'] ?? 16,
			'line_height'      => $form_styling_starter['button_line_height'] ?? 1.5,
			'font_size_unit'   => isset( $form_styling_starter['button_text_size_unit'] ) ? Helper::get_string_value( $form_styling_starter['button_text_size_unit'] ) : 'px',
			'line_height_unit' => isset( $form_styling_starter['button_line_height_unit'] ) ? Helper::get_string_value( $form_styling_starter['button_line_height_unit'] ) : 'em',
		];

		$variables = [
			'--srfm-error-color'                       => sanitize_text_field( $error_color ),
			'--srfm-error-color-border'                => Pro_Helper::get_hsl_notation_from_hex( $error_color, 0.65 ),
			'--srfm-error-color-border-glow'           => Pro_Helper::get_hsl_notation_from_hex( $error_color, 0.15 ),
			'--srfm-row-gap-between-blocks'            => sanitize_text_field( "{$form['row_gap']}{$form['row_gap_type']}" ),
			'--srfm-column-gap-between-blocks'         => sanitize_text_field( "{$form['column_gap']}{$form['column_gap_type']}" ),
			// Button Properties.
			// Padding.
			'--srfm-button-padding-top'                => sanitize_text_field( "{$button['padding_top']}{$button['padding_unit']}" ),
			'--srfm-button-padding-right'              => sanitize_text_field( "{$button['padding_right']}{$button['padding_unit']}" ),
			'--srfm-button-padding-bottom'             => sanitize_text_field( "{$button['padding_bottom']}{$button['padding_unit']}" ),
			'--srfm-button-padding-left'               => sanitize_text_field( "{$button['padding_left']}{$button['padding_unit']}" ),
			// Border Style.
			'--srfm-button-border-style'               => sanitize_text_field( $button['border_style'] ),
			// Background Normal.
			'--srfm-button-text-color-normal'          => sanitize_text_field( $btn_bg_normal['text_color'] ),
			'--srfm-button-background-type-normal'     => sanitize_text_field( $btn_bg_normal['background_type'] ),
			'--srfm-button-background-color-normal'    => sanitize_text_field( $btn_bg_normal['background_color'] ),
			'--srfm-button-background-gradient-normal' => $is_advanced_gradient_normal ? $bg_advanced_gradient_normal : sanitize_text_field( $btn_bg_normal['background_gradient'] ),
			'--srfm-button-text-color-hover'           => sanitize_text_field( $btn_bg_hover['text_color'] ),
			'--srfm-button-background-type-hover'      => sanitize_text_field( $btn_bg_hover['background_type'] ),
			'--srfm-button-background-color-hover'     => sanitize_text_field( $btn_bg_hover['background_color'] ),
			'--srfm-button-background-gradient-hover'  => $is_advanced_gradient_hover ? $bg_advanced_gradient_hover : sanitize_text_field( $btn_bg_hover['background_gradient'] ),
			// Typography.
			'--srfm-btn-font-size'                     => sanitize_text_field( "{$btn_typography['font_size']}{$btn_typography['font_size_unit']}" ),
			'--srfm-btn-line-height'                   => sanitize_text_field( "{$btn_typography['line_height']}{$btn_typography['line_height_unit']}" ),
			// Label Size — defensive `?? <fallback>` matches the pattern used
			// for button properties above; protects against partial preset metas
			// (e.g. a form saved before a `*_unit` key existed) emitting
			// unit-less CSS like `--srfm-label-font-size: 16;`.
			'--srfm-label-font-size'                   => sanitize_text_field( ( $form_styling_starter['field_label_size'] ?? 16 ) . ( $form_styling_starter['field_label_size_unit'] ?? 'px' ) ),
			// Line-height fallbacks intentionally use `em` to match the
			// registered preset defaults in `form-presets.php` and the
			// starter registration. A `px` fallback here would emit
			// `24px` / `20px` on partial metas, visibly diverging from
			// every preset's `1.5em` / `1.4em`.
			'--srfm-label-line-height'                 => sanitize_text_field( ( $form_styling_starter['field_label_line_height'] ?? 1.5 ) . ( $form_styling_starter['field_label_line_height_unit'] ?? 'em' ) ),
			// Help Text Size.
			'--srfm-description-font-size'             => sanitize_text_field( ( $form_styling_starter['field_help_text_size'] ?? 14 ) . ( $form_styling_starter['field_help_text_size_unit'] ?? 'px' ) ),
			'--srfm-description-line-height'           => sanitize_text_field( ( $form_styling_starter['field_help_text_line_height'] ?? 1.4 ) . ( $form_styling_starter['field_help_text_line_height_unit'] ?? 'em' ) ),
			// Help Text Color — only emit when the preset has an explicit
			// value (Dark sets `field_help_text_color = #71717A`; Baseline /
			// Minimal / Custom leave it empty so the free plugin's
			// `text_color @ 65%` derivation cascades through and Text Color
			// edits propagate to the description colour).
			'--srfm-color-input-description'           => ! empty( $form_styling_starter['field_help_text_color'] ) ? sanitize_text_field( $form_styling_starter['field_help_text_color'] ) : '',
			// Label Gap.
			'--srfm-input-label-gap'                   => sanitize_text_field( ( $form_styling_starter['field_label_gap'] ?? 6 ) . ( $form_styling_starter['field_label_gap_unit'] ?? 'px' ) ),
			// Field Background Color — emit base + derived hover/disabled
			// only when `field_bg_color` is explicitly set (Dark). Empty
			// emits empty strings which `Pro_Helper::add_css_variables`
			// skips, letting the free plugin's `text_color @ 2/5/7%`
			// derivations apply for non-Dark presets.
			'--srfm-color-input-background'            => ! empty( $form_styling_starter['field_bg_color'] ) ? sanitize_text_field( $form_styling_starter['field_bg_color'] ) : '',
			'--srfm-color-input-background-hover'      => ! empty( $form_styling_starter['field_bg_color'] ) ? 'hsl( from ' . sanitize_text_field( $form_styling_starter['field_bg_color'] ) . ' h s l / 0.05 )' : '',
			'--srfm-color-input-background-disabled'   => ! empty( $form_styling_starter['field_bg_color'] ) ? 'hsl( from ' . sanitize_text_field( $form_styling_starter['field_bg_color'] ) . ' h s l / 0.05 )' : '',
			// Field Border Color — same conditional pattern as field_bg_color.
			'--srfm-color-input-border'                => ! empty( $form_styling_starter['field_border_color'] ) ? sanitize_text_field( $form_styling_starter['field_border_color'] ) : '',
			'--srfm-color-input-border-disabled'       => ! empty( $form_styling_starter['field_border_color'] ) ? 'hsl( from ' . sanitize_text_field( $form_styling_starter['field_border_color'] ) . ' h s l / 0.15 )' : '',
			// Field Border Radius.
			'--srfm-field-border-radius-top'           => sanitize_text_field( ( $form_styling_starter['field_border_radius_top'] ?? 4 ) . ( $form_styling_starter['field_border_radius_unit'] ?? 'px' ) ),
			'--srfm-field-border-radius-right'         => sanitize_text_field( ( $form_styling_starter['field_border_radius_right'] ?? 4 ) . ( $form_styling_starter['field_border_radius_unit'] ?? 'px' ) ),
			'--srfm-field-border-radius-bottom'        => sanitize_text_field( ( $form_styling_starter['field_border_radius_bottom'] ?? 4 ) . ( $form_styling_starter['field_border_radius_unit'] ?? 'px' ) ),
			'--srfm-field-border-radius-left'          => sanitize_text_field( ( $form_styling_starter['field_border_radius_left'] ?? 4 ) . ( $form_styling_starter['field_border_radius_unit'] ?? 'px' ) ),
			// Field Border Width.
			'--srfm-field-border-width-top'            => sanitize_text_field( ( $form_styling_starter['field_border_width_top'] ?? 1 ) . ( $form_styling_starter['field_border_width_unit'] ?? 'px' ) ),
			'--srfm-field-border-width-right'          => sanitize_text_field( ( $form_styling_starter['field_border_width_right'] ?? 1 ) . ( $form_styling_starter['field_border_width_unit'] ?? 'px' ) ),
			'--srfm-field-border-width-bottom'         => sanitize_text_field( ( $form_styling_starter['field_border_width_bottom'] ?? 1 ) . ( $form_styling_starter['field_border_width_unit'] ?? 'px' ) ),
			'--srfm-field-border-width-left'           => sanitize_text_field( ( $form_styling_starter['field_border_width_left'] ?? 1 ) . ( $form_styling_starter['field_border_width_unit'] ?? 'px' ) ),
			// Field Box Shadow.
			'--srfm-field-box-shadow-normal'           => sanitize_text_field(
				trim(
					sprintf(
						'%s%s %s%s %s%s %s%s %s %s',
						$form_styling_starter['field_box_shadow_horizontal_offset_normal'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_vertical_offset_normal'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_blur_normal'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_spread_normal'] ?? 0,
						'px',
						! empty( $form_styling_starter['field_box_shadow_color_normal'] ) ? Helper::get_string_value( $form_styling_starter['field_box_shadow_color_normal'] ) : 'var(--srfm-color-input-border-focus-glow)',
						isset( $form_styling_starter['field_box_shadow_position_normal'] ) && 'inset' === $form_styling_starter['field_box_shadow_position_normal'] ? 'inset' : ''
					)
				)
			),
			'--srfm-field-box-shadow-focus'            => sanitize_text_field(
				trim(
					sprintf(
						'%s%s %s%s %s%s %s%s %s %s',
						$form_styling_starter['field_box_shadow_horizontal_offset_focus'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_vertical_offset_focus'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_blur_focus'] ?? 0,
						'px',
						$form_styling_starter['field_box_shadow_spread_focus'] ?? 3,
						'px',
						! empty( $form_styling_starter['field_box_shadow_color_focus'] ) ? Helper::get_string_value( $form_styling_starter['field_box_shadow_color_focus'] ) : 'var(--srfm-color-input-border-focus-glow)',
						isset( $form_styling_starter['field_box_shadow_position_focus'] ) && 'inset' === $form_styling_starter['field_box_shadow_position_focus'] ? 'inset' : ''
					)
				)
			),
			// Page Break Button Properties.
			'--srfm-page-break-next-btn-color-normal'  => isset( $form_styling_starter['page_break_next_button_text_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_text_color_normal'] ) : '',
			'--srfm-page-break-next-btn-bg-normal'     => isset( $form_styling_starter['page_break_next_button_background_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_background_color_normal'] ) : '',
			'--srfm-page-break-next-btn-border-color-normal' => isset( $form_styling_starter['page_break_next_button_border_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_border_color_normal'] ) : '',
			'--srfm-page-break-back-btn-color-normal'  => isset( $form_styling_starter['page_break_back_button_text_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_text_color_normal'] ) : '',
			'--srfm-page-break-back-btn-bg-normal'     => isset( $form_styling_starter['page_break_back_button_background_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_background_color_normal'] ) : '',
			'--srfm-page-break-back-btn-border-color-normal' => isset( $form_styling_starter['page_break_back_button_border_color_normal'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_border_color_normal'] ) : '',
			'--srfm-page-break-next-btn-color-hover'   => isset( $form_styling_starter['page_break_next_button_text_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_text_color_hover'] ) : '',
			'--srfm-page-break-next-btn-bg-hover'      => isset( $form_styling_starter['page_break_next_button_background_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_background_color_hover'] ) : '',
			'--srfm-page-break-next-btn-border-color-hover' => isset( $form_styling_starter['page_break_next_button_border_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_next_button_border_color_hover'] ) : '',
			'--srfm-page-break-back-btn-color-hover'   => isset( $form_styling_starter['page_break_back_button_text_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_text_color_hover'] ) : '',
			'--srfm-page-break-back-btn-bg-hover'      => isset( $form_styling_starter['page_break_back_button_background_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_background_color_hover'] ) : '',
			'--srfm-page-break-back-btn-border-color-hover' => isset( $form_styling_starter['page_break_back_button_border_color_hover'] ) ? sanitize_text_field( $form_styling_starter['page_break_back_button_border_color_hover'] ) : '',
		];

		if ( 'none' === $button['border_style'] ) {
			$border_properties = [
				// Border Radius.
				'--srfm-button-border-radius-top'    => sanitize_text_field( "{$button['border_radius_top']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-right'  => sanitize_text_field( "{$button['border_radius_right']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-bottom' => sanitize_text_field( "{$button['border_radius_bottom']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-left'   => sanitize_text_field( "{$button['border_radius_left']}{$button['border_radius_unit']}" ),
			];
		} elseif ( 'default' !== $button['border_style'] ) {
			$border_properties = [
				// Border Width.
				'--srfm-button-border-width-top'     => sanitize_text_field( "{$button['border_width_top']}px" ),
				'--srfm-button-border-width-right'   => sanitize_text_field( "{$button['border_width_right']}px" ),
				'--srfm-button-border-width-bottom'  => sanitize_text_field( "{$button['border_width_bottom']}px" ),
				'--srfm-button-border-width-left'    => sanitize_text_field( "{$button['border_width_left']}px" ),
				// Border Radius.
				'--srfm-button-border-radius-top'    => sanitize_text_field( "{$button['border_radius_top']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-right'  => sanitize_text_field( "{$button['border_radius_right']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-bottom' => sanitize_text_field( "{$button['border_radius_bottom']}{$button['border_radius_unit']}" ),
				'--srfm-button-border-radius-left'   => sanitize_text_field( "{$button['border_radius_left']}{$button['border_radius_unit']}" ),
				// Border Color.
				'--srfm-button-border-color'         => sanitize_text_field( $button['border_color'] ),
				'--srfm-button-border-hover-color'   => sanitize_text_field( $button['border_hover_color'] ),
			];
		}

		// Add the button normal and hover background type to the class variable.
		$this->data['normal'] = $btn_bg_normal['background_type'];
		$this->data['hover']  = $btn_bg_hover['background_type'];

		$variables = array_merge( $variables, $border_properties, $welcome_screen_vars );

		// Field label color only output if explicitly set to avoid overriding free plugin's textColor variables.
		if ( ! empty( $form_styling_starter['field_label_color'] ) ) {
			$variables['--srfm-color-input-label'] = sanitize_text_field( $form_styling_starter['field_label_color'] );
		}

		// Field input text color only output if explicitly set so the free
		// plugin's `text_color`-derived `--srfm-color-input-text` keeps
		// applying when a preset doesn't override it. Dark ships a default
		// here so input text reads as high-contrast against the dark bg.
		if ( ! empty( $form_styling_starter['field_input_color'] ) ) {
			$variables['--srfm-color-input-text'] = sanitize_text_field( $form_styling_starter['field_input_color'] );
		}

		// Background gradient / image / button-alignment CSS variables.
		// The free plugin emits these from `_srfm_forms_styling`, but for
		// user presets the values live in the global option rather than in
		// `_srfm_forms_styling`, so we re-emit them here (coming after the
		// free plugin's emission in the same `<style>` block, these win on
		// last-declaration precedence).
		//
		// Content inside `<style>` is NOT HTML-decoded by the parser, so
		// `esc_html` cannot defend against CSS-meaningful characters
		// (`;`, `}`, `{`, `:`) surviving in user-supplied preset values.
		// All values emitted below are checked against allow-lists or
		// strict shape regexes — anything outside the allow-list falls
		// back to a known-safe default rather than being echoed.
		$css_safe_attachments = [ 'scroll', 'fixed', 'local' ];
		$css_safe_repeats     = [ 'no-repeat', 'repeat', 'repeat-x', 'repeat-y', 'space', 'round' ];
		$css_safe_sizes       = [ 'cover', 'contain', 'auto', 'custom' ];
		$css_safe_units       = [ 'px', '%', 'em', 'rem', 'vw', 'vh' ];
		$css_color_re         = '/^(#[0-9a-fA-F]{3,8}|rgba?\([\d.,\s%\/]+\)|hsla?\([\d.,\s%\/]+\)|transparent|inherit|currentcolor)$/i';
		// Gradient must be a single linear|radial-gradient(...) with no
		// CSS-breaking characters inside the parentheses.
		$css_gradient_re      = '/^(linear|radial)-gradient\([^;{}<>\\\\@\r\n]+\)$/i';
		$css_default_gradient = 'linear-gradient(90deg, #FFC9B2 0%, #C7CBFF 100%)';

		$bg_type_preset = isset( $form_styling_starter['bg_type'] ) ? Helper::get_string_value( $form_styling_starter['bg_type'] ) : '';
		if ( 'gradient' === $bg_type_preset ) {
			$bg_gradient_type        = isset( $form_styling_starter['bg_gradient_type'] ) ? Helper::get_string_value( $form_styling_starter['bg_gradient_type'] ) : 'linear';
			$is_advanced_bg_gradient = 'linear' !== $bg_gradient_type;
			if ( $is_advanced_bg_gradient ) {
				$bg_gradient_css = Helper::get_gradient_css(
					$bg_gradient_type,
					isset( $form_styling_starter['bg_gradient_color_1'] ) ? Helper::get_string_value( $form_styling_starter['bg_gradient_color_1'] ) : '',
					isset( $form_styling_starter['bg_gradient_color_2'] ) ? Helper::get_string_value( $form_styling_starter['bg_gradient_color_2'] ) : '',
					isset( $form_styling_starter['bg_gradient_location_1'] ) ? intval( $form_styling_starter['bg_gradient_location_1'] ) : 0,
					isset( $form_styling_starter['bg_gradient_location_2'] ) ? intval( $form_styling_starter['bg_gradient_location_2'] ) : 100,
					isset( $form_styling_starter['bg_gradient_angle'] ) ? intval( $form_styling_starter['bg_gradient_angle'] ) : 90
				);
			} else {
				$bg_gradient_raw = isset( $form_styling_starter['bg_gradient'] ) ? Helper::get_string_value( $form_styling_starter['bg_gradient'] ) : '';
				$bg_gradient_css = '' !== $bg_gradient_raw ? $bg_gradient_raw : $css_default_gradient;
			}
			// Defense in depth: reject any gradient string that doesn't match
			// the strict shape — drops values smuggled past the JS UI.
			if ( ! preg_match( $css_gradient_re, $bg_gradient_css ) ) {
				$bg_gradient_css = $css_default_gradient;
			}
			echo '--srfm-bg-gradient: ' . esc_html( $bg_gradient_css ) . ';';
		} elseif ( 'image' === $bg_type_preset ) {
			$bg_image_url = isset( $form_styling_starter['bg_image'] ) ? esc_url_raw( $form_styling_starter['bg_image'] ) : '';
			if ( ! empty( $bg_image_url ) ) {
				// Wrap the URL in single quotes so a value containing `)`
				// can't terminate the `url(...)` declaration early.
				// `esc_url_raw` (already applied above) strips quote chars
				// from URL content. We deliberately do NOT use `esc_url()`
				// for the echo because its HTML-encoding step turns `&`
				// into `&amp;`, which is not decoded inside `<style>` and
				// would break URLs containing query strings.
				echo '--srfm-bg-image: url(\'' . $bg_image_url . '\');'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_url_raw above; HTML escaping would corrupt URLs inside <style>.

				$bg_image_attachment_raw = isset( $form_styling_starter['bg_image_attachment'] ) ? sanitize_text_field( $form_styling_starter['bg_image_attachment'] ) : 'scroll';
				$bg_image_repeat_raw     = isset( $form_styling_starter['bg_image_repeat'] ) ? sanitize_text_field( $form_styling_starter['bg_image_repeat'] ) : 'no-repeat';
				$bg_image_size_raw       = isset( $form_styling_starter['bg_image_size'] ) ? sanitize_text_field( $form_styling_starter['bg_image_size'] ) : 'cover';

				$bg_image_attachment = in_array( $bg_image_attachment_raw, $css_safe_attachments, true ) ? $bg_image_attachment_raw : 'scroll';
				$bg_image_repeat     = in_array( $bg_image_repeat_raw, $css_safe_repeats, true ) ? $bg_image_repeat_raw : 'no-repeat';
				$bg_image_size       = in_array( $bg_image_size_raw, $css_safe_sizes, true ) ? $bg_image_size_raw : 'cover';

				if ( 'custom' === $bg_image_size ) {
					$bg_image_size_custom_unit_raw = isset( $form_styling_starter['bg_image_size_custom_unit'] ) ? sanitize_text_field( $form_styling_starter['bg_image_size_custom_unit'] ) : '%';
					$bg_image_size_custom_unit     = in_array( $bg_image_size_custom_unit_raw, $css_safe_units, true ) ? $bg_image_size_custom_unit_raw : '%';
					$bg_size_merged                = intval( $form_styling_starter['bg_image_size_custom'] ?? 100 ) . $bg_image_size_custom_unit;
				} else {
					$bg_size_merged = $bg_image_size;
				}

				echo '--srfm-bg-attachment: ' . esc_html( $bg_image_attachment ) . ';';
				echo '--srfm-bg-repeat: ' . esc_html( $bg_image_repeat ) . ';';
				echo '--srfm-bg-size: ' . esc_html( $bg_size_merged ) . ';';
			}
		}
		$bg_image_overlay_color = isset( $form_styling_starter['bg_image_overlay_color'] ) ? sanitize_text_field( $form_styling_starter['bg_image_overlay_color'] ) : '';
		if ( '' !== $bg_image_overlay_color && preg_match( $css_color_re, $bg_image_overlay_color ) ) {
			echo '--srfm-bg-overlay-color: ' . esc_html( $bg_image_overlay_color ) . ';';
		}

		// Add the form styling variables to the form.
		Pro_Helper::add_css_variables( $variables );
	}

	/**
	 * Add classes to the button based on custom styling.
	 *
	 * @param array<string>       $classes Array of classes.
	 * @param int                 $form_id The form ID.
	 * @param array<string,mixed> $block_attrs Block attributes for per-embed styling.
	 * @since 1.6.3
	 * @return array<string> Final array of classes.
	 */
	public function add_pro_btn_classes( $classes, $form_id = 0, $block_attrs = [] ) {
		$background_type_normal = '';
		$background_type_hover  = '';

		// Check if embed block has custom styling.
		if ( ! empty( $block_attrs ) && 'custom' === ( $block_attrs['formTheme'] ?? '' ) ) {
			// Get background types from embed block attributes.
			// Default to 'color' as that's the JS attribute default (WordPress doesn't save default values).
			$background_type_normal = Helper::get_string_value( $block_attrs['buttonBackgroundTypeNormal'] ?? 'color' );
			$background_type_hover  = Helper::get_string_value( $block_attrs['buttonBackgroundTypeHover'] ?? 'color' );
		} else {
			// Fallback to form meta or $this->data for instant form styling.
			$form_styling_starter = [];
			if ( empty( $this->data ) ) {
				$form_styling_starter = Helper::get_array_value( get_post_meta( Helper::get_integer_value( $form_id ), '_srfm_forms_styling_starter', true ) );
			}
			$background_type_normal = ! empty( $this->data['normal'] ) ? Helper::get_string_value( $this->data['normal'] ) : ( isset( $form_styling_starter['button_background_type_normal'] ) ? Helper::get_string_value( $form_styling_starter['button_background_type_normal'] ) : '' );
			$background_type_hover  = ! empty( $this->data['hover'] ) ? Helper::get_string_value( $this->data['hover'] ) : ( isset( $form_styling_starter['button_background_type_hover'] ) ? Helper::get_string_value( $form_styling_starter['button_background_type_hover'] ) : '' );
		}

		$pro_btn_classes = [
			Pro_Helper::get_button_background_classes( $background_type_normal, $background_type_hover ),
		];

		return array_merge( $classes, $pro_btn_classes );
	}

	/**
	 * Add custom styling class to the form container.
	 *
	 * @param string              $classes Existing classes from generate-form-markup.
	 * @param int                 $form_id The form ID.
	 * @param array<string,mixed> $block_attrs Block attributes for per-embed styling.
	 * @since 1.6.3
	 * @return string Final string of classes joined.
	 */
	public function add_custom_styling_class( $classes, $form_id = 0, $block_attrs = [] ) {
		if ( empty( $form_id ) ) {
			return $classes;
		}

		$form_theme = '';

		// Check block_attrs first for embed block styling.
		// When formTheme is 'inherit', fall through to use the form's own theme setting.
		if ( ! empty( $block_attrs ) && isset( $block_attrs['formTheme'] ) && 'inherit' !== $block_attrs['formTheme'] ) {
			$form_theme = Helper::get_string_value( $block_attrs['formTheme'] );
		} elseif ( ! empty( $this->data ) ) {
			// Check internal data (for instant forms).
			$form_theme = Helper::get_string_value( $this->data['form_theme'] ?? '' );
		} else {
			// Fallback to post meta.
			$form_styling_starter = Helper::get_array_value( get_post_meta( Helper::get_integer_value( $form_id ), '_srfm_forms_styling_starter', true ) );
			$form_theme           = Helper::get_string_value( $form_styling_starter['form_theme'] ) ?? 'default';
		}

		// Skip when the form theme has no meta-driven styling (e.g. 'default').
		// User presets (e.g. `user-my-blue`) flow through the same class
		// pattern; the styling source lives in wp_options but the class
		// is still `srfm-preset-{theme}`.
		if (
			null === Pro_Helper::get_preset_styling_meta_key( $form_theme )
			&& ! Pro_Helper::is_user_preset_slug( $form_theme )
		) {
			return $classes;
		}

		$class_list = [
			$classes,
			'srfm-custom-stylings',
			'srfm-preset-' . sanitize_html_class( $form_theme ),
		];

		// User presets carry their structural CSS via the base preset's
		// SCSS scope (`.srfm-preset-{baseline|minimal|dark}` rules in
		// `sass/presets/_presets.scss`). Append the base-preset class so
		// a user preset derived from Dark still gets Dark's layout /
		// palette tokens. The PHP-emitted inline `<style>` for the user
		// preset's colour edits still wins on specificity.
		if ( Pro_Helper::is_user_preset_slug( $form_theme ) ) {
			$preset      = Pro_Helper::get_user_preset( $form_theme );
			$base_preset = is_array( $preset ) && isset( $preset['base_preset'] )
				? Helper::get_string_value( $preset['base_preset'] )
				: '';
			if ( in_array( $base_preset, [ 'baseline', 'minimal', 'dark', 'custom' ], true ) ) {
				$class_list[] = 'srfm-preset-' . sanitize_html_class( $base_preset );
			}
		}

		return Helper::join_strings( $class_list );
	}

	/**
	 * Add upload files to form data.
	 *
	 * @param array<mixed> $form_data Form data.
	 * @since 1.8.0
	 * @return array<mixed>
	 */
	public function add_upload_files_to_form_data( $form_data ) {
		if ( ! isset( $form_data['form-id'] ) ) {
			return [ 'error' => __( 'Form ID is missing', 'sureforms-pro' ) ];
		}

		$is_error = false;

		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && ! empty( $_FILES ) ) {
			$allowed_file_types = Pro_Helper::get_normalized_file_types();

			// Flatten for MIME validation.
			$all_mimes = ! empty( $allowed_file_types ) ? array_merge( ...array_values( $allowed_file_types ) ) : [];

			if ( empty( $all_mimes ) ) {
				return [ 'error' => __( 'File types are not allowed', 'sureforms-pro' ) ];
			}

			$form_id = absint( $form_data['form-id'] );

			add_filter( 'upload_mimes', [ $this, 'add_extra_upload_mimes' ] );
			add_filter( 'wp_check_filetype_and_ext', [ $this, 'fix_extra_mime_file_check' ], 10, 5 );

			try {
				foreach ( $_FILES as $field => $file ) {
					// Ensure that the field type key is valid for the expected key structure.
					// This prevents uploading invalid upload data.
					// Example: $field = 'srfm-upload-abc123-lbl-upload' will return 'upload' as field type.
					$field_type = Pro_Helper::get_field_type_from_key_with_srfm( $field );
					if ( 'srfm-upload' !== $field_type ) {
						continue;
					}

					if ( is_array( $file['name'] ) ) {
						foreach ( $file['name'] as $key => $filename ) {
							if ( empty( $filename ) || ! is_string( $filename ) ) {
								continue;
							}

							$temp_path  = $file['tmp_name'][ $key ];
							$file_size  = $file['size'][ $key ];
							$file_type  = $file['type'][ $key ];
							$file_error = $file['error'][ $key ];

							// Check if the file type is allowed by WP.
							// Fall back to extension check only for extra MIME types (e.g. STL, ZIP) where browsers
							// send generic MIME types like application/octet-stream.
							if ( ! isset( $file_type ) || ! is_string( $file_type ) || ! in_array( $file_type, $all_mimes, true ) ) {
								$ext         = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
								$extra_mimes = Pro_Helper::get_extra_mimes();
								if ( ! $ext || ! isset( $extra_mimes[ $ext ] ) ) {
									$is_error = true;
									continue;
								}
							}

							if ( ! $temp_path && ! $file_size && ! $file_type ) {
								$form_data[ $field ][] = '';
								continue;
							}

							$file_url = File_Upload::upload_file(
								[
									'name'     => sanitize_file_name( $filename ),
									'type'     => $file_type,
									'tmp_name' => $temp_path,
									'error'    => $file_error,
									'size'     => $file_size,
								],
								$form_id,
								$field
							);

							if ( $file_url ) {
								// Cloud-first: if this field is mapped to third-party storage,
								// upload now and store the cloud URL; otherwise keep the local URL.
								$cloud_url             = File_Storage_Handler::get_instance()->maybe_upload_field_file_to_cloud(
									$form_id,
									$field,
									trailingslashit( File_Upload::get_upload_dir_path() ) . basename( $file_url )
								);
								$form_data[ $field ][] = '' !== $cloud_url ? $cloud_url : $file_url;
							} else {
								$is_error = true;
							}
						}
					} else {
						$form_data[ $field ][] = '';
					}
				}
			} finally {
				remove_filter( 'upload_mimes', [ $this, 'add_extra_upload_mimes' ] );
				remove_filter( 'wp_check_filetype_and_ext', [ $this, 'fix_extra_mime_file_check' ], 10 );
			}
		}

		return $is_error ? [ 'error' => __( 'File is not uploaded', 'sureforms-pro' ) ] : $form_data;
	}

	/**
	 * Add extra MIME types to WordPress upload allowlist.
	 *
	 * @param array<string,string> $mimes Existing MIME types.
	 * @since 2.5.2
	 * @return array<string,string>
	 */
	public function add_extra_upload_mimes( $mimes ) {
		$extra = Pro_Helper::get_extra_mimes();
		foreach ( $extra as $ext => $mime_list ) {
			if ( isset( $mimes[ $ext ] ) ) {
				$current = explode( '|', $mimes[ $ext ] );
				foreach ( $mime_list as $mime ) {
					if ( ! in_array( $mime, $current, true ) ) {
						$current[] = $mime;
					}
				}
				$mimes[ $ext ] = implode( '|', $current );
			} else {
				$mimes[ $ext ] = implode( '|', $mime_list );
			}
		}
		return $mimes;
	}

	/**
	 * Fix file type check for extra MIME types.
	 *
	 * WordPress's wp_check_filetype_and_ext() uses finfo_file() for content verification,
	 * which returns generic MIME types (e.g. application/octet-stream, text/plain) for
	 * non-standard file types like STL. This filter corrects the type/ext when the
	 * extension is in our extra MIME list.
	 *
	 * @param array<string,string> $data File data with ext, type, proper_filename keys.
	 * @param string               $file Full path to the file.
	 * @param string               $filename The name of the file.
	 * @param array<string>|null   $mimes Allowed MIME types keyed by extension.
	 * @param string|false         $real_mime The actual MIME type from finfo.
	 * @since 2.5.2
	 * @return array<string,string>
	 */
	public function fix_extra_mime_file_check( $data, $file, $filename, $mimes, $real_mime ) {
		// Suppress unused parameter warning.
		unset( $mimes );

		if ( ! empty( $data['ext'] ) && ! empty( $data['type'] ) ) {
			return $data;
		}

		$ext   = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		$extra = Pro_Helper::get_extra_mimes();

		if ( ! $ext || ! isset( $extra[ $ext ] ) ) {
			return $data;
		}

		// Validate file content before trusting the extension.
		if ( ! self::validate_extra_mime_content( $file, $ext, $real_mime ) ) {
			return $data;
		}

		$data['ext']  = $ext;
		$data['type'] = $extra[ $ext ][0];

		return $data;
	}

	/**
	 * Process upload and signature blocks for smart tags.
	 *
	 * Converts file URLs to secure download URLs for upload and signature blocks
	 * when they appear in smart tags (emails, integrations, etc.).
	 *
	 * @param array<string,mixed> $args {
	 *     Context data for smart tag processing.
	 *
	 *     @type string $submission_item_key   The field key
	 *     @type mixed  $submission_item_value The field value
	 *     @type string $target_slug          Target field slug
	 *     @type string $block_type           Block type (e.g., 'srfm-upload', 'srfm-signature')
	 *     @type array  $form_data            Form configuration
	 *     @type array  $submission_data      Submission data
	 *     @type string $value                Original smart tag value
	 * }
	 * @since 2.6.0
	 * @return array<string,mixed> Modified args with processed_value if applicable.
	 */
	public function process_upload_signature_smart_tags( $args ) {
		$block_type            = isset( $args['block_type'] ) && is_string( $args['block_type'] ) ? $args['block_type'] : '';
		$submission_item_value = $args['submission_item_value'] ?? '';
		$form_data             = isset( $args['form_data'] ) && is_array( $args['form_data'] ) ? $args['form_data'] : [];
		$upload_format_type    = isset( $form_data['upload_format_type'] ) && is_string( $form_data['upload_format_type'] ) ? $form_data['upload_format_type'] : '';

		// Handle upload blocks.
		if ( 0 === strpos( $block_type, 'srfm-upload' ) && is_array( $submission_item_value ) ) {
			$processed_urls = [];

			// Transform each file URL to secure download URL.
			foreach ( $submission_item_value as $file_url ) {
				if ( empty( $file_url ) || ! is_string( $file_url ) ) {
					continue;
				}
				$processed_urls[] = File_Upload::get_download_url( $file_url );
			}

			// Format the output based on upload_format_type.
			if ( ! empty( $upload_format_type ) && 'raw' === $upload_format_type ) {
				// Raw format: comma-separated URLs.
				$args['processed_value'] = urldecode( implode( ', ', $processed_urls ) );
			} else {
				// HTML format: clickable links.
				if ( count( $processed_urls ) === 1 ) {
					$decoded_value           = urldecode( reset( $processed_urls ) );
					$args['processed_value'] = '<a rel="noopener noreferrer" href="' . esc_url( $decoded_value ) . '" target="_blank">' . esc_html( $decoded_value ) . '</a>';
				} else {
					$args['processed_value'] = '<ul style="margin: 0;">';
					foreach ( $processed_urls as $file_url ) {
						$decoded_value            = urldecode( $file_url );
						$args['processed_value'] .= '<li><a rel="noopener noreferrer" href="' . esc_url( $decoded_value ) . '" target="_blank">' . esc_html( $decoded_value ) . '</a></li>';
					}
					$args['processed_value'] .= '</ul>';
				}
			}

			return $args;
		}

		// Handle signature blocks.
		if ( 0 === strpos( $block_type, 'srfm-signature' ) && is_string( $submission_item_value ) && ! empty( $submission_item_value ) ) {
			// Transform signature URL to secure download URL.
			$secure_url = File_Upload::get_download_url( $submission_item_value );

			// Format as HTML image tag for signature.
			$args['processed_value'] = '<img src="' . esc_url( $secure_url ) . '" alt="' . esc_attr__( 'Signature', 'sureforms-pro' ) . '" style="max-width: 300px; height: auto;" />';

			return $args;
		}

		return $args;
	}

	/**
	 * Validate form data for entry update.
	 *
	 * @param mixed $value   The form data to validate.
	 * @since 2.0.0
	 * @return bool|\WP_Error
	 */
	public function validate_entry_form_data( $value ) {
		if ( ! is_array( $value ) ) {
			return new \WP_Error( 'invalid_form_data', __( 'Form data must be an array.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		return true;
	}

	/**
	 * Update entry data via REST API.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @since 2.0.0
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_entry_data( $request ) {
		$nonce = $request->get_header( 'X-WP-Nonce' );

		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error( 'nonce_verification_failed', __( 'Nonce verification failed.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		$entry_id  = Helper::get_integer_value( $request->get_param( 'id' ) );
		$form_data = Helper::get_array_value( $request->get_param( 'form_data' ) );

		// Verify entry exists.
		$entry = Entries::get( $entry_id );
		if ( empty( $entry ) ) {
			return new \WP_Error( 'entry_not_found', __( 'Entry not found.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		// Sanitize the form data using the same method as the original function.
		$data = Helper::sanitize_by_field_type( $form_data );

		$instance = Entries::get_instance();

		/* translators: Here %s means the users display name. */
		$instance->add_log( sprintf( __( 'Entry edited by %s', 'sureforms-pro' ), wp_get_current_user()->display_name ) );

		$changed        = 0;
		$edited         = [];
		$change_details = [];

		if ( ! empty( $data ) && is_array( $data ) ) {
			$saved_form_data = Helper::get_array_value( $entry['form_data'] );

			// Get the form data and merge it with the submitted data.
			$_data = array_merge( $saved_form_data, $data );

			foreach ( $_data as $field_name => $v ) {
				if ( ! array_key_exists( $field_name, $saved_form_data ) && ( false === strpos( $field_name, '-lbl-' ) ) ) {
					continue;
				}

				/**
				 * Action fired just before updating individual entry field data.
				 *
				 * This action hook allows developers to perform custom operations before a form field
				 * value is updated in the entry logs. Common use cases include:
				 * - Updating entry logs with field-specific change tracking
				 * - Processing complex field types like repeaters or file uploads
				 * - Adding custom validation or data transformation
				 * - Integrating with external systems
				 *
				 * @param array $args {
				 *     Arguments passed to the action hook.
				 *     @type string     $field_name      The name/key of the field being updated
				 *     @type mixed      $field_value     The new value being saved for this field
				 *     @type array      $saved_form_data The existing form data before update
				 *     @type array      $current_data    The complete new form data being saved
				 *     @type object     $entry_instance  Instance of the Entries class
				 *     @type int        $changed         Reference to counter tracking number of changes
				 * }
				 * @since 1.11.0 - Migrated this from the older code added in version 1.11.0 from the entries-management.php file.
				 */
				do_action(
					'srfm_pro_before_update_entry_data',
					[
						'field_name'      => $field_name,
						'field_value'     => $v,
						'saved_form_data' => $saved_form_data,
						'current_data'    => $_data,
						'entry_instance'  => $instance,
						'changed'         => &$changed,
					]
				);

				// If the field is an array, encode the values. This is to add support for multi-upload field.
				if ( is_array( $v ) ) {
					if ( false !== strpos( $field_name, 'srfm-upload' ) ) {
						$edited[ $field_name ] = array_map(
							static function ( $val ) {
								return rawurlencode( esc_url_raw( $val ) );
							},
							$v
						);
						// Skip the rest of the loop if we are handling uploads field.
						continue;
					}

					if ( false !== strpos( $field_name, 'srfm-repeater' ) ) {
						// If the field is a repeater field, then we need to process the repeater field.
						$edited[ $field_name ] = $v;
						continue;
					}

					// Compare submitted array and previously saved array.
					// Retrieve the previously saved value for the field from the database.
					$previous_saved_value = Helper::get_string_value( $saved_form_data[ $field_name ] );

					// Determine the separator used in the saved value for backward compatibility.
					// If the string contains " | ", split it using " | "; otherwise, split it using ",".
					$prev_value = strpos( $previous_saved_value, '|' ) !== false
						? explode( ' | ', $previous_saved_value )
						: explode( ',', $previous_saved_value );

					$current_value = $v;

					// Sort both arrays to compare them.
					sort( $prev_value );
					sort( $current_value );

					// Convert both arrays to string to compare them.
					$prev_value    = implode( ' | ', $prev_value );
					$current_value = implode( ' | ', $current_value );

					if ( md5( $current_value ) === md5( $prev_value ) ) {
						// If both arrays are same then skip the rest of the loop.
						$edited[ $field_name ] = $prev_value;
						continue;
					}
					$edited[ $field_name ] = implode( ' | ', $v );

				} else {
					$edited[ $field_name ] = htmlspecialchars( $v );
				}

				if ( false !== strpos( $field_name, 'srfm-checkbox' ) && empty( $v ) && ! isset( $saved_form_data[ $field_name ] ) ) {
					unset( $edited[ $field_name ] );
					continue;
				}

				$log = is_array( $v ) ? implode( ' | ', $v ) : $v;

				if ( ! isset( $saved_form_data[ $field_name ] ) ) {
					// &#8594; is html entity for arrow -> sign. The label is decoded from the
					// submitted field key, so escape it as text like the modified branch below.
					$instance->update_log( $instance->get_last_log_key(), null, [ '<strong>' . esc_html( Helper::get_field_label_from_key( $field_name ) . ': ' ) . '</strong> "" &#8594; ' . esc_html( $log ) ] );
					$changed++;
					$change_details[] = [
						'field'     => $field_name,
						'label'     => Helper::get_field_label_from_key( $field_name ),
						'old_value' => '',
						'new_value' => $log,
						'type'      => 'added',
					];
					continue;
				}

				if ( $saved_form_data[ $field_name ] === $edited[ $field_name ] ) {
					continue;
				}

				$form_data_log = Helper::get_string_value( $saved_form_data[ $field_name ] );

				// &#8594; is html entity for arrow -> sign. Use HTML template instead of inline HTML string.
				ob_start(); ?>
				<strong><?php echo esc_html( Helper::get_field_label_from_key( $field_name ) . ': ' ); ?></strong> <del><?php echo esc_html( $form_data_log ); ?></del> &#8594; <?php echo esc_html( $log ); ?>
				<?php
				$srfm_formatted_log = ob_get_clean();
				$srfm_formatted_log = is_string( $srfm_formatted_log ) ? $srfm_formatted_log : '';
				$instance->update_log( $instance->get_last_log_key(), null, [ $srfm_formatted_log ] );
				$changed++;
				$change_details[] = [
					'field'     => $field_name,
					'label'     => Helper::get_field_label_from_key( $field_name ),
					'old_value' => $form_data_log,
					'new_value' => $log,
					'type'      => 'modified',
				];
			}
		}

		if ( ! $changed ) {
			// Reset logs to zero if no valid changes are made.
			$instance->reset_logs();
		}

		$update_result = $instance::update(
			$entry_id,
			[
				'form_data' => $edited,
				'logs'      => $instance->get_logs(),
			]
		);

		if ( 0 === $update_result ) {
			return new \WP_REST_Response(
				[
					'success' => true,
					'message' => __( 'No changes detected - entry remains the same.', 'sureforms-pro' ),
				],
				200
			);
		}

		if ( ! $update_result ) {
			return new \WP_Error( 'update_failed', __( 'Failed to update entry data.', 'sureforms-pro' ), [ 'status' => 500 ] );
		}

		// Return success response with details.
		return new \WP_REST_Response(
			[
				'success' => true,
				'message' => __( 'Entry updated successfully.', 'sureforms-pro' ),
				'data'    => [
					'entry_id'      => $entry_id,
					'changes_count' => $changed,
					'changes'       => $change_details,
					'updated_at'    => current_time( 'mysql' ),
					'updated_by'    => wp_get_current_user()->display_name,
				],
			],
			200
		);
	}

	/**
	 * Change the field name for the date picker field.
	 *
	 * @param string $field_name Field name.
	 * @param string $base_field_name Base field name.
	 * @param string $block_type Block type.
	 * @param string $block_id Block ID.
	 *
	 * @since 2.0.0
	 * @return string Field name.
	 */
	public function change_field_name( $field_name, $base_field_name, $block_type, $block_id ) {
		if ( 'date-picker' === $block_type ) {
			$field_name = 'srfm-datepicker-' . $block_id . $base_field_name;
		}

		return $field_name;
	}

	/**
	 * Validate file content for extra MIME types.
	 *
	 * Performs basic content verification to ensure the file content
	 * is consistent with the claimed extension. This prevents uploading
	 * arbitrary content (e.g., PHP webshells) with a trusted extension.
	 *
	 * @param string       $file      Full path to the file.
	 * @param string       $ext       File extension.
	 * @param string|false $real_mime The actual MIME type detected by finfo.
	 * @since 2.5.2
	 * @return bool True if content is valid for the extension.
	 */
	private static function validate_extra_mime_content( $file, $ext, $real_mime ) {
		// Allowlisted real MIME types that are acceptable for non-standard file types.
		// finfo often returns these generic types for binary/text formats it doesn't recognize.
		$safe_generic_mimes = [
			'application/octet-stream',
			'text/plain',
		];

		switch ( $ext ) {
			case 'stl':
				// STL files are either ASCII (starts with "solid") or binary.
				// Reject if finfo detects a known dangerous MIME type.
				if ( $real_mime && ! in_array( $real_mime, $safe_generic_mimes, true ) && 'model/stl' !== $real_mime && 'application/sla' !== $real_mime ) {
					return false;
				}

				// Read first bytes to verify content.
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading local temp file for content verification.
				$header = file_get_contents( $file, false, null, 0, 80 );
				if ( false === $header || '' === $header ) {
					return false;
				}

				// ASCII STL starts with "solid".
				if ( 0 === strncasecmp( $header, 'solid', 5 ) ) {
					// Reject if it contains PHP opening tags — likely a webshell.
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading local temp file for security verification.
					$content = file_get_contents( $file );
					if ( false !== $content && preg_match( '/<\?(php|=)/i', $content ) ) {
						return false;
					}
					return true;
				}

				// Binary STL: 80-byte header + 4-byte triangle count. Minimum valid size is 84 bytes.
				$filesize = filesize( $file );
				if ( false !== $filesize && $filesize >= 84 ) {
					return true;
				}

				return false;

			case 'zip':
				// ZIP files start with PK signature (0x504B).
				if ( $real_mime && ! in_array( $real_mime, $safe_generic_mimes, true ) && 'application/zip' !== $real_mime && 'application/x-zip-compressed' !== $real_mime ) {
					return false;
				}

				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading local temp file for content verification.
				$header = file_get_contents( $file, false, null, 0, 4 );
				if ( false === $header || strlen( $header ) < 2 ) {
					return false;
				}

				return 'PK' === substr( $header, 0, 2 );

			default:
				return false;
		}
	}
}
