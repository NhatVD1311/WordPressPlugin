<?php
/**
 * Migrator_WPForms — Pro-side subscribers for Free's WPForms importer filters.
 *
 * When Pro is active, this class teaches Free's WPForms importer (in PR
 * #2790) to emit Pro-only blocks for the WPForms fields Free can't render
 * on its own. Same filter seams the CF7 importer uses (`srfm_migrator_*`),
 * discriminated by `$key === 'wpforms'`.
 *
 *   - phone                → srfm/phone        (existing Free block)
 *   - url                  → srfm/url          (existing Free block)
 *   - address              → srfm/address      (Pro emitter wrapping Free's block)
 *   - date-time            → srfm/date-picker or srfm/time-picker
 *   - file-upload          → srfm/upload       (reuses CF7 emitter)
 *   - number-slider        → srfm/slider       (reuses CF7 emitter)
 *   - hidden               → srfm/hidden       (reuses CF7 emitter)
 *   - pagebreak            → srfm/page-break   (reuses CF7 emitter)
 *   - rating               → srfm/rating
 *   - net_promoter_score   → srfm/nps
 *   - signature            → srfm/signature
 *   - html / content       → srfm/html
 *   - divider              → srfm/separator    (native separator block)
 *   - richtext             → srfm/textarea     (lossy)
 *   - password             → srfm/input        (no inputType=password yet)
 *   - internal-information → srfm/hidden       (carries `code` as default_value)
 *   - layout               → handled by Free (core/columns)
 *   - repeater             → srfm/repeater     (innerBlocks; recursion handled in Free)
 *
 * @package sureforms-pro
 * @since   2.11.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM_Pro\Inc\Migrator\Block_Templates_Pro;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migrator_WPForms
 *
 * @since 2.11.0
 */
class Migrator_WPForms {
	use Get_Instance;

	/**
	 * Bind subscribers to Free's migrator filters.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_filter( 'srfm_migrator_tag_to_template_map', [ $this, 'extend_field_map' ], 10, 2 );
		add_filter( 'srfm_migrator_block_template', [ $this, 'emit_block' ], 10, 4 );
		add_filter( 'srfm_migrator_preprocess_template', [ $this, 'preprocess_template' ], 10, 3 );
	}

	/**
	 * Overlay WPForms-Pro / addon-field-type → template-method entries.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,string> $map WPForms type → method.
	 * @param string               $key Migrator source key.
	 * @return array<string,string>
	 */
	public function extend_field_map( $map, $key ) {
		if ( 'wpforms' !== $key || ! is_array( $map ) ) {
			return $map;
		}
		$map['phone']                = 'phone';
		$map['url']                  = 'url';
		$map['address']              = 'address';
		$map['date-time']            = 'date_time_picker';
		$map['file-upload']          = 'upload';
		$map['number-slider']        = 'slider';
		$map['hidden']               = 'hidden_field';
		$map['pagebreak']            = 'page_break';
		$map['rating']               = 'rating';
		$map['net_promoter_score']   = 'nps';
		$map['signature']            = 'signature';
		$map['html']                 = 'html_block';
		$map['content']              = 'html_block';
		$map['divider']              = 'divider';
		$map['richtext']             = 'richtext';
		$map['password']             = 'password_input';
		$map['internal-information'] = 'hidden_field';
		$map['repeater']             = 'repeater_container';
		return $map;
	}

	/**
	 * Emit Gutenberg markup for the Pro-only template methods registered by
	 * `extend_field_map()`. Reuses existing `Block_Templates_Pro` emitters
	 * shared with the CF7 importer.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $markup Default empty string.
	 * @param string              $method Template method name.
	 * @param array<string,mixed> $args   Block args.
	 * @param string              $key    Migrator source key.
	 * @return string
	 */
	public function emit_block( $markup, $method, $args, $key ) {
		if ( 'wpforms' !== $key || '' !== $markup ) {
			return $markup;
		}
		switch ( $method ) {
			case 'date_time_picker':
				return Block_Templates_Pro::date_time_picker( $args );
			case 'signature':
				// srfm/signature is registered only when the Pro tier is active
				// (inc/pro/signature/init.php, gated behind Pro\Init), but this
				// migrator loads unconditionally. If the block isn't registered
				// on the target site, emit nothing so Free flags the field as
				// unsupported in the migration summary rather than writing
				// markup that renders as an "invalid content" placeholder.
				if ( ! self::block_registered( 'srfm/signature' ) ) {
					return '';
				}
				return Block_Templates_Pro::signature( $args );
			case 'rating':
				return Block_Templates_Pro::rating( $args );
			case 'nps':
				return Block_Templates_Pro::nps( $args );
			case 'html_block':
				return Block_Templates_Pro::html_block( $args );
			case 'divider':
				return Block_Templates_Pro::divider( $args );
			case 'richtext':
				return Block_Templates_Pro::richtext( $args );
			case 'password_input':
				return Block_Templates_Pro::password_input( $args );
			case 'address':
				return Block_Templates_Pro::address( $args );
			case 'repeater_container':
				// srfm/repeater is registered only when the Business tier is
				// active (inc/business/repeater/init.php, gated behind
				// Business\Init). Same guard rationale as signature above.
				if ( ! self::block_registered( 'srfm/repeater' ) ) {
					return '';
				}
				return Block_Templates_Pro::repeater_container( $args );
			// CF7 already wires up these via Migrator_CF7; the WPForms
			// importer routes through the same filter, so reuse here too.
			case 'date_picker':
				return Block_Templates_Pro::date_picker( $args );
			case 'upload':
				return Block_Templates_Pro::upload( $args );
			case 'hidden_field':
				return Block_Templates_Pro::hidden_field( $args );
			case 'slider':
				return Block_Templates_Pro::slider( $args );
			case 'page_break':
				return Block_Templates_Pro::page_break( $args );
			default:
				return $markup;
		}
	}

	/**
	 * Mirror the WPForms `internal-information.code` field's identifier into
	 * the hidden block's `default_value` so the submission still carries
	 * the marker. Otherwise pass the form_data through verbatim.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,mixed>|mixed $data Parsed WPForms form-data array.
	 * @param string                    $key  Migrator source key.
	 * @param array<string,mixed>       $form Source form descriptor (unused — interface).
	 * @return array<string,mixed>|mixed
	 */
	public function preprocess_template( $data, $key, $form ) {
		unset( $form );
		if ( 'wpforms' !== $key || ! is_array( $data ) ) {
			return $data;
		}
		if ( ! isset( $data['fields'] ) || ! is_array( $data['fields'] ) ) {
			return $data;
		}
		foreach ( $data['fields'] as $id => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			if ( 'internal-information' === ( $field['type'] ?? '' ) && isset( $field['code'] ) ) {
				// Carry the `code` identifier through as the hidden default —
				// keeps the submission marker portable to SureForms.
				$data['fields'][ $id ]['default_value'] = (string) $field['code'];
			}
		}
		return $data;
	}

	/**
	 * Whether a block type is registered on the current site.
	 *
	 * Used to guard tier-gated emit targets (srfm/signature, srfm/repeater):
	 * the migrator loads on every Pro install, but those blocks register only
	 * when their respective tier is active. Migration runs on an admin REST
	 * request, by which point `init` (and thus block registration) has fired,
	 * so the registry is authoritative here.
	 *
	 * @since 2.11.0
	 *
	 * @param string $block_name Fully-qualified block name (e.g. `srfm/signature`).
	 * @return bool
	 */
	private static function block_registered( $block_name ) {
		return \WP_Block_Type_Registry::get_instance()->is_registered( $block_name );
	}
}
