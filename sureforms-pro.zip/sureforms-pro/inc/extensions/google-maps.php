<?php
/**
 * Google Maps Integration.
 *
 * Handles Google Maps API key settings, address autocomplete,
 * and interactive map preview for the address block.
 *
 * @package sureforms-pro
 * @since 2.8.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Google Maps Class.
 *
 * @since 2.8.0
 */
class Google_Maps {
	use Get_Instance;

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'sureforms-pro/v1';

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		add_filter( 'register_block_type_args', [ $this, 'register_address_attributes' ], 10, 2 );
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'localize_api_key' ], 20 );
		add_action( 'srfm_enqueue_block_scripts', [ $this, 'enqueue_autocomplete_script' ] );
		add_filter( 'srfm_address_field_classes', [ $this, 'add_address_classes' ], 10, 2 );
		add_filter( 'srfm_address_block_attributes', [ $this, 'add_block_attributes' ], 10, 2 );
		add_action( 'srfm_address_before_fields', [ $this, 'render_autocomplete_input' ], 10, 2 );
		add_action( 'srfm_address_after_fields', [ $this, 'render_autocomplete_extras' ], 10, 2 );
		add_filter( 'render_block_srfm/input', [ $this, 'inject_address_component_attr' ], 10, 2 );
		add_filter( 'render_block_srfm/dropdown', [ $this, 'inject_address_component_attr' ], 10, 2 );
	}

	/**
	 * Register enableAutocomplete and showMap attributes on the address block.
	 *
	 * @param array<string,mixed> $args Block type arguments.
	 * @param string              $name Block type name.
	 * @return array<string,mixed>
	 * @since 2.8.0
	 */
	public function register_address_attributes( $args, $name ) {
		if ( ! isset( $args['attributes'] ) || ! is_array( $args['attributes'] ) ) {
			$args['attributes'] = [];
		}

		// Address block: autocomplete + map toggle.
		if ( 'srfm/address' === $name ) {
			$args['attributes']['enableAutocomplete'] = [
				'type'    => 'boolean',
				'default' => false,
			];
			$args['attributes']['showMap']            = [
				'type'    => 'boolean',
				'default' => false,
			];
		}

		// Input + Dropdown blocks: address component identifier for autocomplete mapping.
		if ( 'srfm/input' === $name || 'srfm/dropdown' === $name ) {
			$args['attributes']['addressComponent'] = [
				'type'    => 'string',
				'default' => '',
			];
		}

		return $args;
	}

	/**
	 * Inject data-address-component attribute into rendered inner block HTML.
	 *
	 * @param string               $block_content Rendered block HTML.
	 * @param array<string, mixed> $block         Block data including attributes.
	 * @return string Modified block HTML.
	 * @since 2.8.0
	 */
	public function inject_address_component_attr( $block_content, $block ) {
		$block = is_array( $block ) ? $block : [];
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];

		$component = isset( $attrs['addressComponent'] ) && is_string( $attrs['addressComponent'] ) ? $attrs['addressComponent'] : '';

		if ( empty( $component ) ) {
			return $block_content;
		}

		// Inject data-address-component into the first <div tag (limit 1 replacement).
		$result = preg_replace(
			'/(<div\b)/',
			'$1 data-address-component="' . esc_attr( $component ) . '"',
			$block_content,
			1
		);

		return is_string( $result ) ? $result : $block_content;
	}

	/**
	 * Register REST API routes for Google Maps settings.
	 *
	 * @return void
	 * @since 2.8.0
	 */
	public function register_routes() {
		$sureforms_helper = new Helper();

		register_rest_route(
			$this->namespace,
			'/google-maps-settings',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_settings' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'save_settings' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
			]
		);
	}

	/**
	 * Get Google Maps settings.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 * @since 2.8.0
	 */
	public function get_settings( $request ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required by REST API callback signature.
		$settings = get_option( 'srfm_google_maps_settings', [] );
		$settings = is_array( $settings ) ? $settings : [];

		return new WP_REST_Response(
			[
				'srfm_google_maps_api_key' => $settings['srfm_google_maps_api_key'] ?? '',
				'srfm_google_maps_map_id'  => $settings['srfm_google_maps_map_id'] ?? '',
			]
		);
	}

	/**
	 * Save Google Maps settings.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 * @since 2.8.0
	 */
	public function save_settings( $request ) {
		$api_key = $request->get_param( 'srfm_google_maps_api_key' );
		$api_key = is_string( $api_key ) ? sanitize_text_field( $api_key ) : '';

		// Optional Map ID — required only to render Advanced Markers on the map preview.
		$map_id = $request->get_param( 'srfm_google_maps_map_id' );
		$map_id = is_string( $map_id ) ? sanitize_text_field( $map_id ) : '';

		// Read-merge-write so any future keys in this option aren't clobbered by a save
		// that only carries the API key + Map ID.
		$existing = get_option( 'srfm_google_maps_settings', [] );
		$existing = is_array( $existing ) ? $existing : [];

		update_option(
			'srfm_google_maps_settings',
			array_merge(
				$existing,
				[
					'srfm_google_maps_api_key' => $api_key,
					'srfm_google_maps_map_id'  => $map_id,
				]
			)
		);

		return new WP_REST_Response(
			[ 'data' => __( 'Settings Saved Successfully.', 'sureforms-pro' ) ]
		);
	}

	/**
	 * Localize Google Maps API key availability to the block editor.
	 *
	 * @return void
	 * @since 2.8.0
	 */
	public function localize_api_key() {
		$settings = get_option( 'srfm_google_maps_settings', [] );
		$settings = is_array( $settings ) ? $settings : [];
		$has_key  = ! empty( $settings['srfm_google_maps_api_key'] );

		$script_handle = defined( 'SRFM_SLUG' ) ? SRFM_SLUG . '-blocks' : 'sureforms-blocks';
		wp_add_inline_script(
			$script_handle,
			'if ( typeof srfm_block_data !== "undefined" ) { srfm_block_data.google_maps_api_key = ' . wp_json_encode( $has_key ) . '; }',
			'after'
		);
	}

	/**
	 * Enqueue address autocomplete script on the frontend.
	 *
	 * @param array<string,mixed> $args Block data with 'block_name' and 'attr'.
	 * @return void
	 * @since 2.8.0
	 */
	public function enqueue_autocomplete_script( $args ) {
		$args       = is_array( $args ) ? $args : [];
		$block_name = isset( $args['block_name'] ) && is_string( $args['block_name'] ) ? $args['block_name'] : '';
		$attr       = isset( $args['attr'] ) && is_array( $args['attr'] ) ? $args['attr'] : []; // @phpstan-var array<string,mixed> $attr

		if ( 'address' !== $block_name || empty( $attr['enableAutocomplete'] ) ) {
			return;
		}

		$google_api_key = $this->get_api_key();
		if ( empty( $google_api_key ) ) {
			return;
		}

		$is_debug    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG;
		$file_prefix = $is_debug ? '' : '.min';
		$dir_name    = $is_debug ? 'unminified' : 'minified';
		$js_uri      = SRFM_PRO_URL . 'assets/js/' . $dir_name . '/blocks/';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/';
		$rtl         = is_rtl() ? '-rtl' : '';

		wp_enqueue_style(
			'sureforms-pro-address-autocomplete',
			$css_uri . 'blocks/default/frontend' . $file_prefix . $rtl . '.css',
			[],
			SRFM_PRO_VER
		);

		wp_enqueue_script(
			'sureforms-pro-address-autocomplete',
			$js_uri . 'address-autocomplete' . $file_prefix . '.js',
			[],
			SRFM_PRO_VER,
			true
		);

		/**
		 * Filter the default map center and zoom shown before a place is selected.
		 *
		 * @param array{lat: float, lng: float, zoom: int} $default_center Default center coordinates and zoom.
		 * @since 2.8.0
		 */
		$default_center = apply_filters(
			'srfm_maps_default_center',
			[
				'lat'  => 40.7128,
				'lng'  => -74.006,
				'zoom' => 10,
			]
		);

		// Validate filter output.
		$map_lat  = isset( $default_center['lat'] ) && is_numeric( $default_center['lat'] ) ? (float) $default_center['lat'] : 40.7128;
		$map_lng  = isset( $default_center['lng'] ) && is_numeric( $default_center['lng'] ) ? (float) $default_center['lng'] : -74.006;
		$map_zoom = isset( $default_center['zoom'] ) && is_numeric( $default_center['zoom'] ) ? (int) $default_center['zoom'] : 10;

		wp_localize_script(
			'sureforms-pro-address-autocomplete',
			'srfmMapsConfig',
			[
				'apiKey'        => $google_api_key,
				'mapId'         => $this->get_map_id(),
				'defaultCenter' => [
					'lat'  => max( -90.0, min( 90.0, $map_lat ) ),
					'lng'  => max( -180.0, min( 180.0, $map_lng ) ),
					'zoom' => max( 0, min( 21, $map_zoom ) ),
				],
			]
		);
	}

	/**
	 * Add autocomplete CSS class to the address field.
	 *
	 * @param array<string> $classes   Existing CSS classes.
	 * @param array<mixed>  $attributes Block attributes.
	 * @return array<string>
	 * @since 2.8.0
	 */
	public function add_address_classes( $classes, $attributes ) {
		if ( $this->is_autocomplete_enabled( $attributes ) ) {
			$classes[] = 'srfm-address-autocomplete-block';
		}
		return $classes;
	}

	/**
	 * Add data attributes to the address block wrapper.
	 *
	 * @param string       $extra_attrs Existing extra attributes string.
	 * @param array<mixed> $attributes  Block attributes.
	 * @return string
	 * @since 2.8.0
	 */
	public function add_block_attributes( $extra_attrs, $attributes ) {
		if ( ! $this->is_autocomplete_enabled( $attributes ) ) {
			return $extra_attrs;
		}

		$show_map = ! empty( $attributes['showMap'] ) ? 'true' : 'false';

		return $extra_attrs . ' data-autocomplete="true" data-show-map="' . esc_attr( $show_map ) . '"';
	}

	/**
	 * Render the autocomplete search input before the address fields.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @param string       $block_id   Block ID.
	 * @return void
	 * @since 2.8.0
	 */
	public function render_autocomplete_input( $attributes, $block_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Required by srfm_address_before_fields action signature.
		if ( ! $this->is_autocomplete_enabled( $attributes ) ) {
			return;
		}
		?>
		<div class="srfm-address-autocomplete-search-wrap">
			<input
				type="text"
				class="srfm-input-address-autocomplete srfm-input-common"
				placeholder="<?php echo esc_attr__( 'Start typing an address...', 'sureforms-pro' ); ?>"
				autocomplete="new-password"
			/>
			<div class="srfm-error-wrap"></div>
		</div>
		<?php
	}

	/**
	 * Render hidden fields and map container after the address fields.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @param string       $block_id   Block ID.
	 * @return void
	 * @since 2.8.0
	 */
	public function render_autocomplete_extras( $attributes, $block_id ) {
		if ( ! $this->is_autocomplete_enabled( $attributes ) ) {
			return;
		}
		?>
		<input type="hidden" class="srfm-address-autocomplete-structured" name="srfm-address-structured-<?php echo esc_attr( $block_id ); ?>" value="" />
		<input type="hidden" class="srfm-address-autocomplete-place-id" name="srfm-address-place-id-<?php echo esc_attr( $block_id ); ?>" value="" />
		<input type="hidden" class="srfm-address-autocomplete-lat" name="srfm-address-lat-<?php echo esc_attr( $block_id ); ?>" value="" />
		<input type="hidden" class="srfm-address-autocomplete-lng" name="srfm-address-lng-<?php echo esc_attr( $block_id ); ?>" value="" />
		<?php if ( ! empty( $attributes['showMap'] ) ) { ?>
		<div class="srfm-address-autocomplete-map-preview" style="display:none;"></div>
		<?php } ?>
		<?php
	}

	/**
	 * Get the cached Google Maps API key.
	 *
	 * @return string
	 * @since 2.8.0
	 */
	private function get_api_key() {
		static $cached_api_key = null;

		if ( null === $cached_api_key ) {
			$settings       = get_option( 'srfm_google_maps_settings', [] );
			$settings       = is_array( $settings ) ? $settings : [];
			$cached_api_key = isset( $settings['srfm_google_maps_api_key'] )
				? strval( $settings['srfm_google_maps_api_key'] )
				: '';
		}

		return $cached_api_key;
	}

	/**
	 * Get the configured Google Maps Map ID (optional).
	 *
	 * Used to enable Advanced Markers on the address map preview. Empty when not configured,
	 * in which case the frontend falls back to the classic (deprecated) marker.
	 *
	 * @return string
	 * @since 2.11.1
	 */
	private function get_map_id() {
		static $cached_map_id = null;

		if ( null === $cached_map_id ) {
			$settings      = get_option( 'srfm_google_maps_settings', [] );
			$settings      = is_array( $settings ) ? $settings : [];
			$cached_map_id = isset( $settings['srfm_google_maps_map_id'] )
				? strval( $settings['srfm_google_maps_map_id'] )
				: '';
		}

		return $cached_map_id;
	}

	/**
	 * Check if autocomplete is enabled for the given block attributes.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @return bool
	 * @since 2.8.0
	 */
	private function is_autocomplete_enabled( $attributes ) {
		return ! empty( $attributes['enableAutocomplete'] ) && ! empty( $this->get_api_key() );
	}
}
