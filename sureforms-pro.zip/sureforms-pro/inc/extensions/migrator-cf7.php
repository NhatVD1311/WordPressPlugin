<?php
/**
 * Migrator_CF7 — Pro-side subscribers for Free's CF7 migrator filters.
 *
 * When Pro is active, this class teaches Free's CF7 importer to emit Pro
 * blocks for the CF7 tags Free can't render on its own:
 *
 *   - `[date]`     → srfm/date-picker
 *   - `[file]`     → srfm/upload          (also dropped from unsupported list)
 *   - `[hidden]`   → srfm/hidden          (also dropped from unsupported list)
 *   - `[range]`    → srfm/slider          (was srfm/number)
 *   - `[step ...]` → srfm/page-break      (after preprocessing)
 *
 * @package sureforms-pro
 * @since   2.11.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM_Pro\Inc\Migrator\Block_Templates_Pro;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migrator_CF7
 *
 * @since 2.11.0
 */
class Migrator_CF7 {
	use Get_Instance;

	/**
	 * Sentinel tag name used to pipeline `[step]` markers through the regular
	 * tag-parser. The CF7 source `[step]` / `[/step]` strings are rewritten to
	 * a fake `[srfm_page_break ...]` tag during preprocessing so Free's normal
	 * tag parsing can pick them up and dispatch to the `page_break` template.
	 */
	private const PAGE_BREAK_TAG = 'srfm_page_break';

	/**
	 * Bind subscribers to Free's migrator filters.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_filter( 'srfm_migrator_tag_to_template_map', [ $this, 'extend_tag_map' ], 10, 2 );
		add_filter( 'srfm_migrator_unsupported_tags', [ $this, 'reduce_unsupported_tags' ], 10, 2 );
		add_filter( 'srfm_migrator_block_template', [ $this, 'emit_block' ], 10, 4 );
		add_filter( 'srfm_migrator_preprocess_template', [ $this, 'preprocess_template' ], 10, 3 );
	}

	/**
	 * Overlay extra CF7-tag → template-method entries.
	 *
	 * @since 2.11.0
	 *
	 * @param array<string,string> $map CF7 tag → method.
	 * @param string               $key Migrator source key.
	 * @return array<string,string>
	 */
	public function extend_tag_map( $map, $key ) {
		if ( 'cf7' !== $key || ! is_array( $map ) ) {
			return $map;
		}
		$map['date']                 = 'date_picker';
		$map['file']                 = 'upload';
		$map['hidden']               = 'hidden_field';
		$map['range']                = 'slider';
		$map[ self::PAGE_BREAK_TAG ] = 'page_break';
		return $map;
	}

	/**
	 * Drop entries from Free's default unsupported-tags list when Pro can
	 * render them.
	 *
	 * @since 2.11.0
	 *
	 * @param array<int,string> $tags Lower-cased CF7 tag names.
	 * @param string            $key  Migrator source key.
	 * @return array<int,string>
	 */
	public function reduce_unsupported_tags( $tags, $key ) {
		if ( 'cf7' !== $key || ! is_array( $tags ) ) {
			return $tags;
		}
		return array_values( array_diff( $tags, [ 'file', 'hidden' ] ) );
	}

	/**
	 * Emit Gutenberg markup for the Pro-only template methods.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $markup Default empty string.
	 * @param string              $method Template method name.
	 * @param array<string,mixed> $args   Block args (label, required, …).
	 * @param string              $key    Migrator source key.
	 * @return string
	 */
	public function emit_block( $markup, $method, $args, $key ) {
		if ( 'cf7' !== $key || '' !== $markup ) {
			return $markup;
		}
		switch ( $method ) {
			case 'date_picker':
				return Block_Templates_Pro::date_picker( $args );
			case 'upload':
				return Block_Templates_Pro::upload( $args );
			case 'hidden_field':
				return Block_Templates_Pro::hidden_field( $args );
			case 'slider':
				return Block_Templates_Pro::slider( $args );
			case 'page_break':
				return Block_Templates_Pro::page_break( $args );
			default:
				return $markup;
		}
	}

	/**
	 * Rewrite the raw CF7 `_form` template so `[step]` markers (Multi-Step
	 * Forms addon) flow through the tag parser as a synthetic `srfm_page_break`
	 * tag — which the tag-map filter above maps to the page-break template.
	 *
	 * The closing `[/step]` lines are stripped entirely; they have no body and
	 * no SureForms counterpart.
	 *
	 * @since 2.11.0
	 *
	 * @param string              $raw  Raw CF7 template.
	 * @param string              $key  Migrator source key.
	 * @param array<string,mixed> $form Source form descriptor (unused — interface).
	 * @return string
	 */
	public function preprocess_template( $raw, $key, $form ) {
		unset( $form );
		if ( 'cf7' !== $key || ! is_string( $raw ) ) {
			return $raw;
		}
		// Drop close tags entirely — they have no body and no SureForms peer.
		$raw = preg_replace( '/\[\/step\][\s]*/i', '', (string) $raw );

		// Rewrite open tags. When CF7's Multi-Step Forms plugin provides a
		// `heading="..."` attribute, prepend it as the preceding-line label
		// — Free's CF7 importer reads the line above a tag as its label, so
		// this is how we surface the heading on the resulting page-break
		// block. Without a heading we emit a bare synthetic tag and the
		// page-break template falls back to its default copy.
		$raw = preg_replace_callback(
			'/\[step(\s[^\]]*)?\]/i',
			static function ( $matches ) {
				$attrs = $matches[1] ?? '';
				if ( preg_match( '/\bheading\s*=\s*"([^"]+)"/i', $attrs, $h ) ) {
					return $h[1] . "\n[" . self::PAGE_BREAK_TAG . ']';
				}
				return '[' . self::PAGE_BREAK_TAG . ']';
			},
			(string) $raw
		);
		return is_string( $raw ) ? $raw : '';
	}
}
