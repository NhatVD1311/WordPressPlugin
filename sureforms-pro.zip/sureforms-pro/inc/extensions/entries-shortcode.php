<?php
/**
 * Entries Shortcode.
 *
 * Renders [srfm_show_entries id="FORM_ID"] to display a form's collected
 * entries in an HTML table on the frontend.
 *
 * @package sureforms-pro
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Database\Tables\Entries as EntriesTable;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Entries Shortcode class.
 *
 * @since 2.11.0
 */
class Entries_Shortcode {
	use Get_Instance;

	/**
	 * Shortcode tag.
	 *
	 * @since 2.11.0
	 */
	public const SHORTCODE_TAG = 'srfm_show_entries';

	/**
	 * Form meta key storing the Show Entries settings-panel configuration.
	 *
	 * @since 2.11.0
	 */
	public const SETTINGS_META_KEY = '_srfm_show_entries_settings';

	/**
	 * Placeholder shown for fields with no value in an entry.
	 *
	 * @since 2.11.0
	 */
	private const EMPTY_PLACEHOLDER = '—';

	/**
	 * Upper bound on entries fetched/rendered per page.
	 *
	 * Caps the author-supplied `number`/`per_page` attribute so a single public
	 * request can never pull and render an unbounded result set.
	 *
	 * @since 2.11.0
	 */
	private const MAX_PER_PAGE = 500;

	/**
	 * Exact field keys that should never be shown as columns.
	 *
	 * @var array<string>
	 * @since 2.11.0
	 */
	private $excluded_fields = [ 'srfm-honeypot-field', 'g-recaptcha-response', 'srfm-sender-email-field' ];

	/**
	 * Key prefixes whose fields should never be shown as columns.
	 *
	 * @var array<string>
	 * @since 2.11.0
	 */
	private $excluded_prefixes = [ 'srfm-password', 'srfm-hidden' ];

	/**
	 * Constructor.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_shortcode( self::SHORTCODE_TAG, [ $this, 'render' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
		// Send nocache headers BEFORE output starts when a viewer-gated table
		// is on the page — at render time headers are already sent on classic
		// themes, leaving header-based proxies (e.g. plain Varnish) unaware.
		add_action( 'template_redirect', [ $this, 'maybe_send_nocache_headers' ] );
		// Invalidate cached entry lists when a new submission is processed and
		// when an entry is permanently deleted, so removed entries leave the
		// public table promptly. Status changes (read/unread/trash) fall back
		// to the cache TTL.
		add_action( 'srfm_after_submission_process', [ $this, 'flush_cache_on_submission' ] );
		add_action( 'srfm_before_delete_entry', [ $this, 'flush_cache_on_entry_delete' ] );
		// Remove the per-form cache-version option when a form is deleted.
		add_action( 'before_delete_post', [ $this, 'cleanup_cache_version_option' ], 10, 2 );

		// Settings panel: persist the chosen shortcode attributes in form meta
		// and expose a one-click "embed into a page" REST endpoint.
		$this->register_settings_meta();
		add_filter( 'srfm_form_settings_allowed_meta_keys', [ $this, 'allow_settings_meta_key' ] );
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_embed_endpoint' ] );
	}

	/**
	 * Invalidate cached entry lists for a form after a new submission.
	 *
	 * Bumps a per-form cache version included in every transient key, so all
	 * cached pages for that form become unreachable at once.
	 *
	 * @param array<string,mixed> $form_data Submission data (includes form_id).
	 * @since 2.11.0
	 * @return void
	 */
	public function flush_cache_on_submission( $form_data ) {
		$form_id = is_array( $form_data ) && isset( $form_data['form_id'] ) ? absint( $form_data['form_id'] ) : 0;
		$this->bump_cache_version( $form_id );
	}

	/**
	 * Invalidate the cached entry list before an entry is permanently deleted.
	 *
	 * Runs on `srfm_before_delete_entry` while the entry row still exists,
	 * so its form ID can be resolved.
	 *
	 * @param int $entry_id The entry being deleted.
	 * @since 2.11.0
	 * @return void
	 */
	public function flush_cache_on_entry_delete( $entry_id ) {
		$entry = EntriesTable::get( absint( $entry_id ) );
		$this->bump_cache_version( absint( $entry['form_id'] ?? 0 ) );
	}

	/**
	 * Remove the per-form cache-version option when a form post is deleted.
	 *
	 * @param int           $post_id The post being deleted.
	 * @param \WP_Post|null $post    The post object.
	 * @since 2.11.0
	 * @return void
	 */
	public function cleanup_cache_version_option( $post_id, $post = null ) {
		$post_type = $post instanceof \WP_Post ? $post->post_type : get_post_type( $post_id );
		if ( 'sureforms_form' !== $post_type ) {
			return;
		}
		delete_option( 'srfm_show_entries_cache_ver_' . absint( $post_id ) );
	}

	/**
	 * Send nocache headers before output when the queried singular content
	 * contains a viewer-gated entries table (roles/user attributes).
	 *
	 * Runs on template_redirect — before headers are sent — so header-based
	 * proxies honor it too, not only constant-aware page-cache plugins.
	 *
	 * Limitation: this only inspects post_content. For page builders that store
	 * content elsewhere (Elementor/Bricks/etc.), this early pass can't see the
	 * shortcode, so header-based proxies are NOT covered for those layouts on
	 * classic themes (where headers are already sent by render time). The
	 * render-time fallback still sets the DONOTCACHEPAGE constant, which covers
	 * constant-aware page-cache plugins (WP Rocket, LiteSpeed, W3TC) regardless
	 * of where the content is stored.
	 *
	 * @since 2.11.0
	 * @return void
	 */
	public function maybe_send_nocache_headers() {
		if ( ! is_singular() ) {
			return;
		}

		$post = get_post();
		if ( ! $post instanceof \WP_Post || ! has_shortcode( $post->post_content, self::SHORTCODE_TAG ) ) {
			return;
		}

		if ( ! preg_match_all( '/' . get_shortcode_regex( [ self::SHORTCODE_TAG ] ) . '/', $post->post_content, $matches ) ) {
			return;
		}

		foreach ( $matches[3] as $atts_string ) {
			$atts = shortcode_parse_atts( $atts_string );
			if ( ! is_array( $atts ) ) {
				continue;
			}
			// Logged-in-only (the default), per-user, and per-role tables vary per
			// visitor; only an explicitly public, non-per-user, non-per-role table
			// is safe to cache. A public="true" roles="..." table still renders
			// differently for each viewer, so it must not be full-page cached.
			$is_public = $this->attr_is_true( $atts['public'] ?? '' );
			$has_roles = '' !== trim( Helper::get_string_value( $atts['roles'] ?? '' ) );
			if ( ! $is_public || ! empty( $atts['user'] ) || $has_roles ) {
				// DONOTCACHEPAGE is a WordPress-ecosystem standard cache-plugin
				// constant; it is intentionally unprefixed.
				if ( ! defined( 'DONOTCACHEPAGE' ) ) {
					define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Standard cache-plugin constant.
				}
				nocache_headers();
				return;
			}
		}
	}

	/**
	 * Register the frontend assets for the entries table.
	 *
	 * Registration only — actual enqueueing happens in render() so the assets
	 * load solely on pages that output the shortcode, not sitewide.
	 *
	 * @since 2.11.0
	 * @return void
	 */
	public function register_assets() {
		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$rtl         = is_rtl() ? '-rtl' : '';

		wp_register_style(
			SRFM_PRO_SLUG . '-entries-table',
			SRFM_PRO_URL . 'assets/css/' . $dir_name . '/frontend/entries-table' . $file_prefix . $rtl . '.css',
			[],
			SRFM_PRO_VER
		);

		// Powers the clickable, sortable column headers in the entries table.
		wp_register_script(
			SRFM_PRO_SLUG . '-entries-table',
			SRFM_PRO_URL . 'assets/js/' . $dir_name . '/entries-table' . $file_prefix . '.js',
			[],
			SRFM_PRO_VER,
			true
		);

		// When the shortcode is detectable in the post content, enqueue now so
		// the stylesheet lands in <head> (no flash of unstyled table). Page
		// builders storing content elsewhere fall back to the render-time
		// enqueue (footer CSS).
		global $post;
		if ( $post instanceof \WP_Post && has_shortcode( $post->post_content, self::SHORTCODE_TAG ) ) {
			wp_enqueue_style( SRFM_PRO_SLUG . '-entries-table' );
			wp_enqueue_script( SRFM_PRO_SLUG . '-entries-table' );
		}
	}

	/**
	 * Render the entries table shortcode.
	 *
	 * Supported attributes:
	 *  - id         (required) Form ID whose entries to show.
	 *  - roles      Comma-separated user role slugs allowed to view the table. Empty allows any logged-in user (everyone only when public="true").
	 *  - user       Comma-separated user IDs and/or "current" (the logged-in user). Empty shows all.
	 *  - fields     Comma separated list of block IDs / field keys to show as columns.
	 *  - slug       Comma separated field slugs; renders only those columns, in the given order.
	 *  - number     Entries per page (alias of per_page). Defaults to 5.
	 *  - per_page   Entries per page. Overrides number when set.
	 *  - pagination "true" (default) to paginate, "false" for a single capped page.
	 *  - type       Entry status: all (default), read, unread, or trash. The read/unread/trash filters apply for administrators only; other viewers always get the default non-trash view.
	 *  - sort       Block ID / field key to sort rows by (in-memory, current page).
	 *  - order      Sort direction: asc or desc. Defaults to desc.
	 *
	 * Known limitation: columns are derived from the entries on the current
	 * page, so if a form's fields changed over time the column set can vary
	 * between pages. Use the `slug` attribute for a deterministic column set.
	 *
	 * @param array<string,mixed>|string $atts Shortcode attributes.
	 * @since 2.11.0
	 * @return string
	 */
	public function render( $atts ) {
		$atts = shortcode_atts(
			[
				'id'         => 0,
				'public'     => 'false',
				'user'       => '',
				'roles'      => '',
				'fields'     => '',
				'slug'       => '',
				'number'     => 5,
				'per_page'   => 0,
				'pagination' => 'true',
				'type'       => 'all',
				'sort'       => '',
				'order'      => 'desc',
			],
			is_array( $atts ) ? $atts : [],
			self::SHORTCODE_TAG
		);

		$form_id = absint( $atts['id'] );

		if ( ! $form_id ) {
			return '';
		}

		// Validate the form to prevent probing arbitrary post IDs.
		if ( 'sureforms_form' !== get_post_type( $form_id ) || 'publish' !== get_post_status( $form_id ) ) {
			return '';
		}

		$roles_attr = trim( Helper::get_string_value( $atts['roles'] ?? '' ) );
		$user_attr  = trim( Helper::get_string_value( $atts['user'] ?? '' ) );
		// Secure by default: the table is logged-in-only unless the author
		// explicitly opts into a public table with public="true".
		$is_public = $this->attr_is_true( $atts['public'] ?? '' );

		// Unless the table is public (and not per-user, not per-role), its output
		// varies per visitor — tell full-page caches (WP Rocket, LiteSpeed, Varnish
		// via nocache headers) not to capture it, or one viewer's render could be
		// served to another. A public="true" roles="..." table still varies by role.
		if ( ! $is_public || '' !== $user_attr || '' !== $roles_attr ) {
			// DONOTCACHEPAGE is a WordPress-ecosystem standard cache-plugin
			// constant; it is intentionally unprefixed. Setting it here (even
			// when headers are already sent) is what protects gated tables
			// inside page-builder content the template_redirect pass can't see.
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Standard cache-plugin constant.
			}
			// Header-based proxies can only be told here if output hasn't begun;
			// the template_redirect pass covers the post_content case earlier.
			if ( ! headers_sent() ) {
				nocache_headers();
			}
		}

		// Restrict viewing: public tables are open to everyone; otherwise the
		// visitor must be logged in (and hold an allowed role when configured).
		if ( ! $this->viewer_can_view( $roles_attr, $is_public ) ) {
			return '';
		}

		/**
		 * Filter: 'srfm_show_entries_can_view'
		 *
		 * Runs after the built-in access gate (which is logged-in-only unless
		 * the shortcode sets public="true"), so the request has already been
		 * authorized. Return false to hide the table from an otherwise-allowed
		 * viewer; return true to keep it visible.
		 *
		 * @since 2.11.0
		 *
		 * @param bool                $can_view Whether the current request may view the entries.
		 * @param int                 $form_id  The form ID being displayed.
		 * @param array<string,mixed> $atts     The parsed shortcode attributes.
		 */
		if ( ! apply_filters( 'srfm_show_entries_can_view', true, $form_id, $atts ) ) {
			return '';
		}

		$paginate = 'false' !== strtolower( Helper::get_string_value( $atts['pagination'] ) );
		$per_page = absint( $atts['per_page'] );
		if ( ! $per_page ) {
			$per_page = absint( $atts['number'] );
		}
		if ( ! $per_page ) {
			$per_page = 5;
		}
		// Clamp to a sane maximum so an oversized attribute can't trigger an
		// unbounded query + render on a public page.
		$per_page = min( $per_page, self::MAX_PER_PAGE );
		$page     = $paginate ? $this->get_current_page( $form_id ) : 1;

		$result  = $this->get_entries_cached( $form_id, $atts, $per_page, $page, $paginate );
		$entries = $result['entries'];
		$total   = $result['total'];
		// The requested page may have been clamped to the real page count.
		$page = $result['page'];

		if ( empty( $entries ) ) {
			return '<div class="srfm-entries"><p class="srfm-entries-table-empty">' . esc_html__( 'No entries found.', 'sureforms-pro' ) . '</p></div>';
		}

		$columns = $this->build_columns( $entries, Helper::get_string_value( $atts['fields'] ), Helper::get_string_value( $atts['slug'] ), $form_id );

		if ( empty( $columns ) ) {
			return '';
		}

		$entries = $this->maybe_sort_entries( $entries, $atts, $columns );

		$this->enqueue_assets();

		$output = $this->render_table( $entries, $columns, $form_id );

		if ( $paginate && $per_page > 0 ) {
			$output .= $this->render_pagination( $form_id, $page, (int) ceil( $total / $per_page ) );
		}

		// Scoping root: lets the plugin's CSS out-specify theme styles and namespaces the table.
		return '<div class="srfm-entries">' . $output . '</div>';
	}

	/**
	 * Register the Show Entries settings meta on the form post type.
	 *
	 * Stores the settings-panel attribute values as a JSON string so the panel
	 * can rebuild the shortcode and preview on reload.
	 *
	 * @since 2.11.0
	 * @return void
	 */
	public function register_settings_meta() {
		register_post_meta(
			'sureforms_form',
			self::SETTINGS_META_KEY,
			[
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'type'              => 'string',
				'single'            => true,
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
				'sanitize_callback' => [ $this, 'sanitize_settings_config' ],
			]
		);
	}

	/**
	 * Allowlist the settings meta key for the form-settings save endpoint.
	 *
	 * @param array<string> $keys Allowed meta keys.
	 * @since 2.11.0
	 * @return array<string>
	 */
	public function allow_settings_meta_key( $keys ) {
		$keys[] = self::SETTINGS_META_KEY;
		return $keys;
	}

	/**
	 * Sanitize the Show Entries settings meta (a JSON object of attributes).
	 *
	 * @param mixed $meta_value Raw meta value (expected JSON string).
	 * @since 2.11.0
	 * @return string
	 */
	public function sanitize_settings_config( $meta_value ) {
		if ( ! is_string( $meta_value ) || '' === $meta_value ) {
			return '';
		}

		$decoded = json_decode( $meta_value, true );
		if ( ! is_array( $decoded ) ) {
			return '';
		}

		$clean = [];
		foreach ( $decoded as $name => $value ) {
			$name_key = sanitize_key( (string) $name );
			if ( '' === $name_key ) {
				continue;
			}
			if ( is_bool( $value ) ) {
				$clean[ $name_key ] = $value;
			} elseif ( is_scalar( $value ) ) {
				// Strip square brackets too — a value containing "]" would
				// terminate the generated shortcode early.
				$clean[ $name_key ] = str_replace(
					[ '[', ']' ],
					'',
					sanitize_text_field( (string) $value )
				);
			}
		}

		return (string) wp_json_encode( $clean );
	}

	/**
	 * Register the embed-shortcode REST endpoint via the core endpoints filter.
	 *
	 * @param array<string,array<string,mixed>> $endpoints Existing endpoints.
	 * @since 2.11.0
	 * @return array<string,array<string,mixed>>
	 */
	public function register_embed_endpoint( $endpoints ) {
		$endpoints['embed-shortcode'] = [
			'methods'             => 'POST',
			'callback'            => [ $this, 'embed_shortcode' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'shortcode'  => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => static function ( $value ) {
						// Exactly one complete SureForms shortcode.
						return is_string( $value ) && 1 === preg_match( '/^\[(?:sureforms|srfm)[a-z_]*\b[^\]]*\]$/', trim( $value ) );
					},
				],
				'mode'       => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_key',
					'validate_callback' => static function ( $value ) {
						return in_array( $value, [ 'new', 'existing' ], true );
					},
				],
				'page_title' => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
				'page_id'    => [
					'sanitize_callback' => 'absint',
					'default'           => 0,
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Embed a shortcode into a new draft page or append it to an existing page.
	 *
	 * @param \WP_REST_Request<array<string,mixed>> $request REST request.
	 * @since 2.11.0
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function embed_shortcode( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new \WP_Error( 'srfm_nonce_failed', __( 'Nonce verification failed.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		$shortcode = trim( Helper::get_string_value( $request->get_param( 'shortcode' ) ) );
		$mode      = Helper::get_string_value( $request->get_param( 'mode' ) );

		// Wrap the shortcode in a Gutenberg shortcode block.
		$block = "<!-- wp:shortcode -->\n" . $shortcode . "\n<!-- /wp:shortcode -->";

		if ( 'existing' === $mode ) {
			$page_id = absint( Helper::get_integer_value( $request->get_param( 'page_id' ) ) );

			/**
			 * Filter: 'srfm_embed_shortcode_allowed_post_types'
			 *
			 * Post types the embed-shortcode endpoint may append to. Defaults
			 * to pages only — never sureforms_form posts (whose block markup
			 * an appended shortcode block would corrupt).
			 *
			 * @since 2.11.0
			 *
			 * @param array<string> $post_types Allowed post type slugs.
			 */
			$allowed_post_types = (array) apply_filters( 'srfm_embed_shortcode_allowed_post_types', [ 'page' ] );

			if (
				! $page_id ||
				! in_array( get_post_type( $page_id ), $allowed_post_types, true ) ||
				'trash' === get_post_status( $page_id )
			) {
				return new \WP_Error( 'srfm_invalid_page', __( 'The selected page could not be found.', 'sureforms-pro' ), [ 'status' => 404 ] );
			}

			if ( ! current_user_can( 'edit_post', $page_id ) ) {
				return new \WP_Error( 'srfm_cannot_edit', __( 'You are not allowed to edit this page.', 'sureforms-pro' ), [ 'status' => 403 ] );
			}

			$existing_content = (string) get_post_field( 'post_content', $page_id );
			// wp_update_post() unslashes its input — slash so backslashes in the
			// page's existing block JSON survive.
			$updated = wp_update_post(
				[
					'ID'           => $page_id,
					'post_content' => wp_slash( trim( $existing_content . "\n\n" . $block ) ),
				],
				true
			);

			if ( is_wp_error( $updated ) ) {
				return new \WP_Error( 'srfm_update_failed', $updated->get_error_message(), [ 'status' => 500 ] );
			}

			return new \WP_REST_Response(
				[
					'id'       => $page_id,
					'edit_url' => get_edit_post_link( $page_id, 'raw' ),
				],
				200
			);
		}

		// New page.
		if ( ! current_user_can( 'publish_pages' ) && ! current_user_can( 'edit_pages' ) ) {
			return new \WP_Error( 'srfm_cannot_create', __( 'You are not allowed to create pages.', 'sureforms-pro' ), [ 'status' => 403 ] );
		}

		$page_title = Helper::get_string_value( $request->get_param( 'page_title' ) );
		if ( '' === $page_title ) {
			$page_title = __( 'SureForms Page', 'sureforms-pro' );
		}

		$page_id = wp_insert_post(
			[
				'post_title'   => wp_slash( $page_title ),
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_content' => wp_slash( $block ),
			],
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return new \WP_Error( 'srfm_create_failed', $page_id->get_error_message(), [ 'status' => 500 ] );
		}

		return new \WP_REST_Response(
			[
				'id'       => $page_id,
				'edit_url' => get_edit_post_link( $page_id, 'raw' ),
			],
			201
		);
	}

	/**
	 * Detect a field's type from its form_data key prefix.
	 *
	 * Mirrors core's key-prefix convention (e.g. `srfm-input-multi-choice`
	 * before the generic `srfm-input`). More reliable than the 2nd key
	 * segment, which reads multi-choice keys as plain `input`.
	 *
	 * @param string $key Form data field key.
	 * @since 2.11.0
	 * @return string
	 */
	private function detect_field_type( $key ) {
		$type_map = [
			'srfm-input-multi-choice' => 'multi-choice',
			'srfm-dropdown'           => 'dropdown',
			'srfm-checkbox'           => 'checkbox',
			'srfm-gdpr'               => 'gdpr',
			'srfm-upload'             => 'upload',
			'srfm-signature'          => 'signature',
			'srfm-repeater'           => 'repeater',
			'srfm-url'                => 'url',
			'srfm-textarea'           => 'textarea',
			'srfm-email'              => 'email',
			'srfm-phone'              => 'phone',
			'srfm-number'             => 'number',
			'srfm-rating'             => 'rating',
			'srfm-nps'                => 'nps',
			'srfm-slider'             => 'slider',
			'srfm-datepicker'         => 'datepicker',
			'srfm-time-picker'        => 'time-picker',
			'srfm-payment'            => 'payment',
			'srfm-input'              => 'input',
		];

		foreach ( $type_map as $prefix => $type ) {
			if ( 0 === strpos( $key, $prefix ) ) {
				return $type;
			}
		}

		return 'text';
	}

	/**
	 * Whether a field key should be excluded from the table entirely.
	 *
	 * @param string $key Form data field key.
	 * @since 2.11.0
	 * @return bool
	 */
	private function is_excluded_field( $key ) {
		$excluded = in_array( $key, $this->excluded_fields, true );

		if ( ! $excluded ) {
			foreach ( $this->excluded_prefixes as $prefix ) {
				if ( 0 === strpos( $key, $prefix ) ) {
					$excluded = true;
					break;
				}
			}
		}

		/**
		 * Filter: 'srfm_show_entries_is_excluded_field'
		 *
		 * Allows toggling whether a given field is excluded from the table.
		 *
		 * @since 2.11.0
		 *
		 * @param bool   $excluded Whether the field is excluded.
		 * @param string $key      The form data field key.
		 */
		return (bool) apply_filters( 'srfm_show_entries_is_excluded_field', $excluded, $key );
	}

	/**
	 * Run a stored value through core's srfm_entry_value filter.
	 *
	 * Lets signature/upload/payment integrations transform the value exactly
	 * as they do for the admin entry view (e.g. secure download URLs).
	 *
	 * @param string $key   Field key.
	 * @param string $label Decoded field label.
	 * @param mixed  $value Raw stored value.
	 * @since 2.11.0
	 * @return mixed
	 */
	private function filter_value( $key, $label, $value ) {
		return apply_filters(
			'srfm_entry_value',
			$value,
			[
				'field_name'       => $key,
				'label'            => $label,
				'field_block_name' => $this->get_block_name_from_key( $key ),
			]
		);
	}

	/**
	 * Derive a field's block name (e.g. "srfm-upload") from its form_data key.
	 *
	 * Reimplemented here rather than calling the core helper so the shortcode
	 * has no hard dependency on a specific core method revision.
	 *
	 * @param string $key Form data field key.
	 * @since 2.11.0
	 * @return string
	 */
	private function get_block_name_from_key( $key ) {
		$prefix = explode( '-lbl-', $key )[0];
		return implode( '-', array_slice( explode( '-', $prefix ), 0, 2 ) );
	}

	/**
	 * Bump the per-form cache version included in every transient key, making
	 * all cached pages for that form unreachable at once.
	 *
	 * Deduped per request so bulk operations (which fire per-entry hooks)
	 * cost at most one option write per form.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.11.0
	 * @return void
	 */
	private function bump_cache_version( $form_id ) {
		static $bumped = [];

		if ( ! $form_id || isset( $bumped[ $form_id ] ) ) {
			return;
		}
		$bumped[ $form_id ] = true;

		$option = 'srfm_show_entries_cache_ver_' . $form_id;
		update_option( $option, absint( get_option( $option, 0 ) ) + 1, false );
	}

	/**
	 * Enqueue the entries-table assets at render time.
	 *
	 * Re-registers first to cover contexts where `wp_enqueue_scripts` did not
	 * run (e.g. page-builder previews); wp_register_* is a no-op when the
	 * handle already exists. Mid-render styles print in the footer, the
	 * standard trade-off for shortcode-conditional loading.
	 *
	 * @since 2.11.0
	 * @return void
	 */
	private function enqueue_assets() {
		$this->register_assets();
		wp_enqueue_style( SRFM_PRO_SLUG . '-entries-table' );
		wp_enqueue_script( SRFM_PRO_SLUG . '-entries-table' );
	}

	/**
	 * Whether the current visitor may view the table.
	 *
	 * Secure by default: only an explicitly public table (public="true") is
	 * shown to anonymous visitors. Administrators always pass. Otherwise the
	 * visitor must be logged in; when roles are configured they must also hold
	 * at least one of them, and an empty role list allows any logged-in user.
	 *
	 * @param string $roles_attr Comma-separated role slugs.
	 * @param bool   $is_public  Whether the table is explicitly public.
	 * @since 2.11.0
	 * @return bool
	 */
	private function viewer_can_view( $roles_attr, $is_public ) {
		// Explicit opt-in: open to everyone, including anonymous visitors.
		if ( $is_public ) {
			return true;
		}

		// Administrators always pass.
		if ( Helper::current_user_can() ) {
			return true;
		}

		// Secure default: everything below requires a logged-in user.
		if ( ! is_user_logged_in() ) {
			return false;
		}

		$allowed = array_filter( array_map( 'trim', explode( ',', $roles_attr ) ) );

		// No specific roles configured — any logged-in user may view.
		if ( empty( $allowed ) ) {
			return true;
		}

		// Otherwise the user must hold at least one allowed role.
		return (bool) array_intersect( (array) wp_get_current_user()->roles, $allowed );
	}

	/**
	 * Whether a shortcode attribute string represents a literal true.
	 *
	 * @param mixed $value Raw attribute value.
	 * @since 2.11.0
	 * @return bool
	 */
	private function attr_is_true( $value ) {
		return 'true' === strtolower( trim( Helper::get_string_value( $value ) ) );
	}

	/**
	 * Read the current page number for a form from the request.
	 *
	 * Scoped per form so multiple tables on a page paginate independently.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.11.0
	 * @return int
	 */
	private function get_current_page( $form_id ) {
		$key = 'srfm_entries_page_' . $form_id;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination state, no data mutation.
		$page = isset( $_GET[ $key ] ) ? absint( wp_unslash( $_GET[ $key ] ) ) : 1;
		return max( 1, $page );
	}

	/**
	 * Build the nested where-clause for the entries query.
	 *
	 * @param int                 $form_id Form ID.
	 * @param array<string,mixed> $atts    Parsed shortcode attributes.
	 * @since 2.11.0
	 * @return array<int,mixed>|null Null when the request can resolve to no entries (e.g. user="current" while logged out).
	 */
	private function build_where( $form_id, $atts ) {
		$type  = Helper::get_string_value( $atts['type'] );
		$where = [];

		// Filter by status. The read/unread/trash filters are admin-workflow
		// concepts (and trash is a deletion-intent state), so they are honored
		// only for admins — a public or non-admin table must never be able to
		// surface trashed entries via type="trash". Everyone else gets the
		// default non-trash view regardless of the requested type.
		if ( Helper::current_user_can() && in_array( $type, [ 'read', 'unread', 'trash' ], true ) ) {
			$where[] = [
				[
					'key'     => 'status',
					'compare' => '=',
					'value'   => $type,
				],
			];
		} else {
			$where[] = [
				[
					'key'     => 'status',
					'compare' => '!=',
					'value'   => 'trash',
				],
			];
		}

		// Filter by form ID.
		$where[] = [
			[
				'key'     => 'form_id',
				'compare' => '=',
				'value'   => $form_id,
			],
		];

		// Filter by user(s) when requested. Accepts a comma-separated list of
		// user IDs and/or the literal "current".
		$user = Helper::get_string_value( $atts['user'] );
		if ( '' !== $user ) {
			$user_ids = [];
			foreach ( explode( ',', $user ) as $token ) {
				$token = trim( $token );
				if ( '' === $token ) {
					continue;
				}
				if ( 'current' === $token ) {
					if ( is_user_logged_in() ) {
						$user_ids[] = get_current_user_id();
					}
					continue;
				}
				$id = absint( $token );
				if ( $id > 0 ) {
					$user_ids[] = $id;
				}
			}

			$user_ids = array_values( array_unique( $user_ids ) );

			// Requested a user filter but nothing resolved (e.g. only
			// "current" while logged out) — return no entries.
			if ( empty( $user_ids ) ) {
				return null;
			}

			$where[] = [
				[
					'key'     => 'user_id',
					'compare' => 'IN',
					'value'   => $user_ids,
				],
			];
		}

		return $where;
	}

	/**
	 * Query entries for the current page, with the entries list cached in a
	 * transient.
	 *
	 * The total is counted fresh each render (cheap indexed COUNT) so the
	 * requested page can be clamped to the real page count BEFORE the offset
	 * enters the cache key — capping the number of distinct transients an
	 * unauthenticated visitor can create via the page query param. Empty
	 * result sets are never cached for the same reason.
	 *
	 * @param int                 $form_id  Form ID.
	 * @param array<string,mixed> $atts     Parsed shortcode attributes.
	 * @param int                 $per_page Page size.
	 * @param int                 $page     Requested page (1-based).
	 * @param bool                $paginate Whether pagination is enabled.
	 * @since 2.11.0
	 * @return array{entries:array<int,array<string,mixed>>,total:int,page:int}
	 */
	private function get_entries_cached( $form_id, $atts, $per_page, $page, $paginate ) {
		$where = $this->build_where( $form_id, $atts );
		if ( null === $where ) {
			return [
				'entries' => [],
				'total'   => 0,
				'page'    => 1,
			];
		}

		$order = 'asc' === strtolower( Helper::get_string_value( $atts['order'] ) ) ? 'ASC' : 'DESC';

		/**
		 * Filter: 'srfm_show_entries_cache_ttl'
		 *
		 * Transient lifetime (seconds) for cached entry queries. Return 0 to disable caching.
		 *
		 * @since 2.11.0
		 *
		 * @param int $ttl     Cache lifetime in seconds.
		 * @param int $form_id The form ID being displayed.
		 */
		$ttl = (int) apply_filters( 'srfm_show_entries_cache_ttl', 5 * MINUTE_IN_SECONDS, $form_id );

		$version = absint( get_option( 'srfm_show_entries_cache_ver_' . $form_id, 0 ) );

		// Total count, cached under a key with NO page/offset input (flood-
		// safe) and the same version (busts together with the entries cache,
		// so totals and rows can't drift apart within the TTL).
		$total = 0;
		if ( $paginate ) {
			$total_key = 'srfm_set_' . md5( (string) wp_json_encode( [ $form_id, $where, $version ] ) );
			$total     = get_transient( $total_key );
			if ( false === $total ) {
				$total = absint( EntriesTable::get_instance()->get_total_count( $where ) );
				if ( $ttl > 0 ) {
					set_transient( $total_key, $total, $ttl );
				}
			}
			$total = absint( $total );

			// Clamp the requested page BEFORE the offset enters the cache key —
			// caps the distinct cache entries an unauthenticated visitor can create.
			$total_pages = max( 1, (int) ceil( $total / max( 1, $per_page ) ) );
			$page        = min( $page, $total_pages );
		}
		$offset = $paginate ? ( $page - 1 ) * $per_page : 0;

		$cache_key = 'srfm_se_' . md5( (string) wp_json_encode( [ $form_id, $where, $order, $per_page, $offset, $version ] ) );

		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) && isset( $cached['entries'] ) && is_array( $cached['entries'] ) ) {
			return [
				'entries' => $cached['entries'],
				'total'   => $paginate ? $total : count( $cached['entries'] ),
				'page'    => $page,
			];
		}

		$entries = EntriesTable::get_all(
			[
				'where'   => $where,
				'columns' => '*',
				'orderby' => 'created_at',
				'order'   => $order,
				'limit'   => $per_page,
				'offset'  => $offset,
			]
		);
		$entries = is_array( $entries ) ? $entries : [];

		// Empty results are cached too: with the page clamp above the offset
		// is bounded, so the key space stays finite.
		if ( $ttl > 0 ) {
			set_transient( $cache_key, [ 'entries' => $entries ], $ttl );
		}

		return [
			'entries' => $entries,
			'total'   => $paginate ? $total : count( $entries ),
			'page'    => $page,
		];
	}

	/**
	 * Build the column map (block ID => label/type) from the entries.
	 *
	 * Without a whitelist, columns appear in the order fields are encountered.
	 * The `fields` attribute filters by block ID / full field key; the `slug`
	 * attribute filters by field slug and renders those columns in the exact
	 * order the slugs were provided. The two combine (either may match).
	 *
	 * @param array<int,array<string,mixed>> $entries     Entries to scan.
	 * @param string                         $fields_attr Comma separated block IDs / field keys.
	 * @param string                         $slug_attr   Comma separated field slugs.
	 * @param int                            $form_id     Form ID, used to seed columns from the form definition.
	 * @since 2.11.0
	 * @return array<string,array{label:string,type:string,date_format:string}>
	 */
	private function build_columns( $entries, $fields_attr, $slug_attr = '', $form_id = 0 ) {
		$fields_allowed = '' !== $fields_attr ? array_filter( array_map( 'trim', explode( ',', $fields_attr ) ) ) : [];
		$slugs_allowed  = '' !== $slug_attr ? array_filter( array_map( 'trim', explode( ',', $slug_attr ) ) ) : [];

		// Seed from the form definition first so EVERY field gets a column —
		// even ones absent from all displayed entries (e.g. a checkbox left
		// unchecked, which the browser never submits). Entries then fill in
		// any extra fields not in the current form (e.g. deleted fields whose
		// old data still exists). Form-definition order is the natural order.
		$all = $this->get_form_field_columns( $form_id );

		// Second pass: collect every displayable column found in the entries,
		// keyed by block ID (skips fields already seeded from the form).
		foreach ( $entries as $entry ) {
			$form_data = isset( $entry['form_data'] ) && is_array( $entry['form_data'] ) ? $entry['form_data'] : [];
			foreach ( $form_data as $field_key => $value ) {
				if ( ! is_string( $field_key ) || $this->is_excluded_field( $field_key ) ) {
					continue;
				}
				if ( false === strpos( $field_key, '-lbl-' ) ) {
					continue;
				}

				$block_id = Helper::get_block_id_from_key( $field_key );
				if ( '' === $block_id || isset( $all[ $block_id ] ) ) {
					continue;
				}

				$all[ $block_id ] = [
					'label' => Helper::get_field_label_from_key( $field_key ),
					'type'  => $this->detect_field_type( $field_key ),
					'slug'  => $this->get_field_slug_from_key( $field_key ),
					'key'   => $field_key,
				];
			}
		}

		// No whitelist: return everything in encounter order.
		if ( empty( $fields_allowed ) && empty( $slugs_allowed ) ) {
			return array_map( [ $this, 'strip_internal_column_keys' ], $all );
		}

		$columns = [];

		// Slug-selected columns first, in the order the slugs were given.
		foreach ( $slugs_allowed as $slug ) {
			foreach ( $all as $block_id => $column ) {
				if ( $column['slug'] === $slug && ! isset( $columns[ $block_id ] ) ) {
					$columns[ $block_id ] = $column;
				}
			}
		}

		// Then any columns matched by the fields whitelist (encounter order).
		if ( ! empty( $fields_allowed ) ) {
			foreach ( $all as $block_id => $column ) {
				if ( isset( $columns[ $block_id ] ) ) {
					continue;
				}
				if ( in_array( $block_id, $fields_allowed, true ) || in_array( $column['key'], $fields_allowed, true ) ) {
					$columns[ $block_id ] = $column;
				}
			}
		}

		return array_map( [ $this, 'strip_internal_column_keys' ], $columns );
	}

	/**
	 * Reduce an internal column record to the public {label,type} shape.
	 *
	 * @param array<string,mixed> $column Internal column record.
	 * @since 2.11.0
	 * @return array{label:string,type:string,date_format:string}
	 */
	private function strip_internal_column_keys( $column ) {
		return [
			'label'       => Helper::get_string_value( $column['label'] ?? '' ),
			'type'        => Helper::get_string_value( $column['type'] ?? 'text' ),
			// Carry the date format (empty for non-date columns) so render_table()
			// can emit a machine-sortable data-srfm-sort value for date columns.
			'date_format' => ! empty( $column['date_format'] ) ? Helper::get_string_value( $column['date_format'] ) : '',
		];
	}

	/**
	 * Extract a field's slug (the segment after the encrypted label) from its key.
	 *
	 * Mirrors core's submission-mapping extraction.
	 *
	 * @param string $field_key Form data field key.
	 * @since 2.11.0
	 * @return string
	 */
	private function get_field_slug_from_key( $field_key ) {
		if ( false === strpos( $field_key, '-lbl-' ) ) {
			return '';
		}
		$after_label = explode( '-lbl-', $field_key )[1];
		$slug        = implode( '-', array_slice( explode( '-', $after_label ), 1 ) );
		return str_replace( ' ', '_', $slug );
	}

	/**
	 * Build a column map from the form's field definition (parsed blocks).
	 *
	 * Seeds a column for every input field in the form, keyed by block ID, so
	 * fields with no data in any displayed entry (a never-checked checkbox, an
	 * always-empty optional field) still appear as columns.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.11.0
	 * @return array<string,array{label:string,type:string,slug:string,key:string}>
	 */
	private function get_form_field_columns( $form_id ) {
		$form_id = absint( $form_id );
		if ( ! $form_id ) {
			return [];
		}

		$post = get_post( $form_id );
		if ( ! $post instanceof \WP_Post ) {
			return [];
		}

		$columns = [];
		$this->collect_field_columns( parse_blocks( Helper::get_string_value( $post->post_content ) ), $columns, Helper::get_sureforms_blocks() );
		return $columns;
	}

	/**
	 * Recursively collect input-field columns from a list of parsed blocks.
	 *
	 * @param array<int,array<string,mixed>> $blocks       Parsed blocks.
	 * @param array<string,mixed>            $columns      Column map being built (by reference).
	 * @param array<int,string>              $input_blocks SureForms input block names to include.
	 * @since 2.11.0
	 * @return void
	 */
	private function collect_field_columns( $blocks, &$columns, $input_blocks ) {
		if ( ! is_array( $blocks ) ) {
			return;
		}

		/**
		 * Blocks that should never become a column. Mirrors the SureForms
		 * admin entries view: every input field is supported except buttons,
		 * layout/content blocks, hidden, password, and account widgets.
		 *
		 * `srfm/address` is a self-closing wrapper that stores no value of its
		 * own — its parts are separate `srfm/input` blocks (seeded normally),
		 * so the wrapper itself is skipped to avoid an empty column.
		 */
		$skip_blocks = [
			// Custom buttons.
			'srfm/submit',
			'srfm/button',
			'srfm/inline-button',
			// Layout / content blocks.
			'srfm/separator',
			'srfm/advanced-heading',
			'srfm/icon',
			'srfm/html',
			'srfm/page-break',
			// Non-data / security fields.
			'srfm/hidden',
			'srfm/password',
			// Address wrapper (its inputs are seeded separately).
			'srfm/address',
			// User-account widgets (not entry-data columns).
			'srfm/login',
			'srfm/register',
			'srfm/link',
			'srfm/lost-password',
			'srfm/reset-password',
		];

		/**
		 * Filter: 'srfm_show_entries_skip_block_columns'
		 *
		 * Block names excluded from the auto-generated entries-table columns.
		 *
		 * @since 2.11.0
		 *
		 * @param array<int,string> $skip_blocks Block names to skip.
		 */
		$filtered    = apply_filters( 'srfm_show_entries_skip_block_columns', $skip_blocks );
		$skip_blocks = is_array( $filtered ) ? $filtered : $skip_blocks;

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_name = isset( $block['blockName'] ) ? Helper::get_string_value( $block['blockName'] ) : '';
			$attrs      = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];

			if ( '' !== $block_name && in_array( $block_name, $input_blocks, true ) && ! in_array( $block_name, $skip_blocks, true ) ) {
				$block_id = isset( $attrs['block_id'] ) ? Helper::get_string_value( $attrs['block_id'] ) : '';
				$slug     = isset( $attrs['slug'] ) ? Helper::get_string_value( $attrs['slug'] ) : '';

				if ( '' !== $block_id && ! isset( $columns[ $block_id ] ) ) {
					$label                = isset( $attrs['label'] ) ? trim( Helper::get_string_value( $attrs['label'] ) ) : '';
					$columns[ $block_id ] = [
						'label'       => '' !== $label ? $label : $this->humanize_field_label( $slug ),
						'type'        => str_replace( 'srfm/', '', $block_name ),
						'slug'        => str_replace( ' ', '_', $slug ),
						'key'         => '',
						// Capture the date field's configured format so the renderer
						// can emit an unambiguous, locale-independent sort value.
						'date_format' => 'srfm/date-picker' === $block_name
							? ( isset( $attrs['dateFormat'] ) ? Helper::get_string_value( $attrs['dateFormat'] ) : 'mm/dd/yyyy' )
							: '',
					];
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$this->collect_field_columns( $block['innerBlocks'], $columns, $input_blocks );
			}
		}
	}

	/**
	 * Derive a human-readable column label from a field slug.
	 *
	 * Used when a field block carries no explicit label (e.g. the default
	 * "srfm-checkbox" slug becomes "Checkbox").
	 *
	 * @param string $slug Field slug.
	 * @since 2.11.0
	 * @return string
	 */
	private function humanize_field_label( $slug ) {
		$slug = preg_replace( '/^srfm-/', '', (string) $slug );
		$slug = str_replace( [ '-', '_' ], ' ', Helper::get_string_value( $slug ) );
		return ucwords( trim( $slug ) );
	}

	/**
	 * Optionally sort entries in-memory by a chosen field column.
	 *
	 * Sorts ONLY the current page of entries (sorting runs after pagination), and
	 * only when `sort` names a column that is actually visible — given either as a
	 * block ID (column key) or a column slug. An unknown/excluded `sort` (typo, or
	 * a field hidden by the fields/slug whitelist) is ignored so the order falls
	 * back cleanly to the query's created_at ordering instead of silently
	 * collapsing every row to an empty value.
	 *
	 * @param array<int,array<string,mixed>> $entries Entries to sort.
	 * @param array<string,mixed>            $atts    Parsed shortcode attributes.
	 * @param array<string,mixed>            $columns Visible columns keyed by block ID.
	 * @since 2.11.0
	 * @return array<int,array<string,mixed>>
	 */
	private function maybe_sort_entries( $entries, $atts, $columns = [] ) {
		$sort = Helper::get_string_value( $atts['sort'] );
		if ( '' === $sort ) {
			return $entries;
		}

		// Sort only by a visible column. Columns are keyed by block ID, which is
		// also what the value resolver matches on; an unknown key (typo, or a
		// field hidden by the fields/slug whitelist) is ignored so the order falls
		// back to the query's created_at ordering instead of collapsing to ''.
		if ( ! isset( $columns[ $sort ] ) ) {
			return $entries;
		}

		$descending = 'asc' !== strtolower( Helper::get_string_value( $atts['order'] ) );

		usort(
			$entries,
			function ( $a, $b ) use ( $sort, $descending ) {
				$val_a = $this->get_entry_value_for_column( $a, $sort );
				$val_b = $this->get_entry_value_for_column( $b, $sort );
				// Numeric values compare numerically ("10" after "9"),
				// mirroring the client-side header sort; everything else
				// uses a natural, case-insensitive string compare.
				if ( is_numeric( $val_a ) && is_numeric( $val_b ) ) {
					$result = $val_a <=> $val_b;
				} else {
					$result = strnatcasecmp( $val_a, $val_b );
				}
				return $descending ? -$result : $result;
			}
		);

		return $entries;
	}

	/**
	 * Find the stored field (key + raw value) for a column within an entry.
	 *
	 * @param array<string,mixed> $entry  Entry record.
	 * @param string              $column Block ID or full field key.
	 * @since 2.11.0
	 * @return array{key:string,value:mixed}|null
	 */
	private function get_entry_field( $entry, $column ) {
		$form_data = isset( $entry['form_data'] ) && is_array( $entry['form_data'] ) ? $entry['form_data'] : [];
		foreach ( $form_data as $field_key => $value ) {
			if ( ! is_string( $field_key ) ) {
				continue;
			}
			if ( $field_key === $column || Helper::get_block_id_from_key( $field_key ) === $column ) {
				return [
					'key'   => $field_key,
					'value' => $value,
				];
			}
		}
		return null;
	}

	/**
	 * Get the plain-text value for a column, used for in-memory sorting.
	 *
	 * Upload fields resolve to their decoded file name(s) so sorting and
	 * client-side header sorting compare something meaningful.
	 *
	 * @param array<string,mixed> $entry  Entry record.
	 * @param string              $column Block ID or full field key.
	 * @since 2.11.0
	 * @return string
	 */
	private function get_entry_value_for_column( $entry, $column ) {
		$field = $this->get_entry_field( $entry, $column );
		if ( null === $field ) {
			return '';
		}

		$value = $field['value'];

		switch ( $this->detect_field_type( $field['key'] ) ) {
			case 'upload':
				return implode( ', ', array_map( 'wp_basename', $this->get_upload_paths( $value ) ) );
			case 'checkbox':
			case 'gdpr':
				return $this->is_checked( $value )
					? __( 'Yes', 'sureforms-pro' )
					: '';
			case 'multi-choice':
				return is_array( $value )
					? $this->normalize_value( $value )
					: str_replace( '|', ', ', Helper::get_string_value( $value ) );
			default:
				return $this->normalize_value( $value );
		}
	}

	/**
	 * Render the displayable cell content (safe HTML) for a column.
	 *
	 * @param array<string,mixed> $entry  Entry record.
	 * @param string              $column Block ID or full field key.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_cell( $entry, $column ) {
		$field = $this->get_entry_field( $entry, $column );
		if ( null === $field ) {
			return self::EMPTY_PLACEHOLDER;
		}

		$key   = $field['key'];
		$label = Helper::get_field_label_from_key( $key );
		// Let signature/upload/payment integrations transform the value first.
		$value = $this->filter_value( $key, $label, $field['value'] );

		switch ( $this->detect_field_type( $key ) ) {
			case 'upload':
				$html = $this->render_upload_links( $value );
				break;
			case 'signature':
				$html = $this->render_signature( $value );
				break;
			case 'checkbox':
			case 'gdpr':
				$html = $this->render_boolean_value( $value );
				break;
			case 'multi-choice':
				$html = $this->render_choices( $value );
				break;
			case 'url':
				$html = $this->render_url( $value );
				break;
			case 'textarea':
				$html = $this->render_textarea( $value );
				break;
			case 'repeater':
				$html = $this->render_repeater( $value );
				break;
			default:
				$html = esc_html( $this->normalize_value( $value ) );
				break;
		}

		return '' !== trim( $html ) ? $html : self::EMPTY_PLACEHOLDER;
	}

	/**
	 * Render a multi-choice / multi-select value as a list.
	 *
	 * Multi-choice stores selections pipe-delimited ("A|B"); multi-select
	 * dropdowns store an array.
	 *
	 * @param mixed $value Raw stored value.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_choices( $value ) {
		if ( is_array( $value ) ) {
			$options = array_map( [ Helper::class, 'get_string_value' ], $value );
		} else {
			$options = explode( '|', Helper::get_string_value( $value ) );
		}

		$options = array_filter(
			array_map( 'trim', $options ),
			static function ( $option ) {
				return '' !== $option;
			}
		);

		if ( empty( $options ) ) {
			return '';
		}

		$items = '';
		foreach ( $options as $option ) {
			$items .= '<li>' . esc_html( $option ) . '</li>';
		}

		return '<ul class="srfm-entries-choices">' . $items . '</ul>';
	}

	/**
	 * Render a URL value as a clickable link.
	 *
	 * @param mixed $value Raw stored value.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_url( $value ) {
		$url = esc_url( Helper::get_string_value( $value ) );
		if ( '' === $url ) {
			return '';
		}
		return sprintf(
			'<a class="srfm-entries-link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
			$url,
			esc_html( $url )
		);
	}

	/**
	 * Render a textarea value preserving its line breaks.
	 *
	 * @param mixed $value Raw stored value.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_textarea( $value ) {
		$text = Helper::get_string_value( $value );
		if ( '' === trim( $text ) ) {
			return '';
		}
		// Escape first, then restore line breaks. Never html_entity_decode()
		// before sanitizing — decoding stored-safe entities back into live
		// markup is a kses-bypass pattern. esc_html keeps the value inert; the
		// resulting <br> survives the cell's outer wp_kses_post.
		return nl2br( esc_html( $text ) );
	}

	/**
	 * Render a signature value as a thumbnail image linking to the full file.
	 *
	 * The value has already passed through srfm_entry_value, so it is a secure
	 * download URL.
	 *
	 * @param mixed $value Raw/filtered stored value.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_signature( $value ) {
		if ( is_array( $value ) ) {
			$value = reset( $value );
		}
		$url = esc_url( Helper::get_string_value( $value ) );
		if ( '' === $url ) {
			return '';
		}
		return sprintf(
			'<a class="srfm-entries-signature" href="%1$s" target="_blank" rel="noopener noreferrer"><img src="%1$s" alt="%2$s" loading="lazy" /></a>',
			$url,
			esc_attr__( 'Signature', 'sureforms-pro' )
		);
	}

	/**
	 * Render a repeater value as a nested list of its rows and inner fields.
	 *
	 * @param mixed $value Raw stored repeater value (array of rows).
	 * @since 2.11.0
	 * @return string
	 */
	private function render_repeater( $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return esc_html( $this->normalize_value( $value ) );
		}

		$rows_html = '';
		foreach ( $value as $row ) {
			if ( ! is_array( $row ) ) {
				$text = $this->normalize_value( $row );
				if ( '' !== trim( $text ) ) {
					$rows_html .= '<li>' . esc_html( $text ) . '</li>';
				}
				continue;
			}

			$pairs = '';
			foreach ( $row as $inner_key => $inner_val ) {
				$inner_text = $this->normalize_value( $inner_val );
				if ( '' === trim( $inner_text ) ) {
					continue;
				}
				$inner_label = Helper::get_field_label_from_key( Helper::get_string_value( $inner_key ) );
				$label_html  = '' !== $inner_label ? '<strong>' . esc_html( $inner_label ) . ':</strong> ' : '';
				$pairs      .= '<li>' . $label_html . esc_html( $inner_text ) . '</li>';
			}

			if ( '' !== $pairs ) {
				$rows_html .= '<li><ul class="srfm-entries-repeater-row">' . $pairs . '</ul></li>';
			}
		}

		return '' !== $rows_html ? '<ul class="srfm-entries-repeater">' . $rows_html . '</ul>' : '';
	}

	/**
	 * Render a checkbox/GDPR consent value as a "Yes" badge when checked.
	 *
	 * An unchecked/empty value renders nothing, so the cell falls back to the
	 * empty-value placeholder rather than showing "No".
	 *
	 * @param mixed $value Raw stored value.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_boolean_value( $value ) {
		if ( ! $this->is_checked( $value ) ) {
			return '';
		}
		return sprintf(
			'<span class="srfm-entries-bool srfm-entries-bool--yes">%s</span>',
			esc_html__( 'Yes', 'sureforms-pro' )
		);
	}

	/**
	 * Determine whether a checkbox/GDPR value represents a checked state.
	 *
	 * A single checkbox submits "on" when checked and is empty/absent
	 * otherwise; explicit falsy tokens are also treated as unchecked.
	 *
	 * @param mixed $value Raw stored value.
	 * @since 2.11.0
	 * @return bool
	 */
	private function is_checked( $value ) {
		if ( is_array( $value ) ) {
			$value = implode( '', array_map( [ Helper::class, 'get_string_value' ], $value ) );
		}
		$value = strtolower( trim( Helper::get_string_value( $value ) ) );
		if ( '' === $value ) {
			return false;
		}
		return ! in_array( $value, [ '0', 'false', 'no', 'off', 'unchecked' ], true );
	}

	/**
	 * Render upload field value as clickable file links with an icon.
	 *
	 * Upload values are stored as an array of URL-encoded file URLs, so each
	 * must be decoded before output.
	 *
	 * @param mixed $value Raw stored upload value (array or string of encoded URLs).
	 * @since 2.11.0
	 * @return string
	 */
	private function render_upload_links( $value ) {
		$links = [];
		foreach ( $this->get_upload_urls( $value ) as $url ) {
			$href = esc_url( $url );
			if ( '' === $href ) {
				continue;
			}
			$name    = wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
			$name    = '' !== $name ? $name : $url;
			$links[] = sprintf(
				'<a class="srfm-entries-file" href="%1$s" target="_blank" rel="noopener noreferrer" title="%2$s"><span class="srfm-entries-file-icon" aria-hidden="true"></span><span class="srfm-entries-file-name">%3$s</span></a>',
				$href,
				esc_attr( $name ),
				esc_html( $this->truncate_filename( $name ) )
			);
		}
		return implode( ' ', $links );
	}

	/**
	 * Trim a long file name for display while preserving the extension.
	 *
	 * The full name is kept in the link's title attribute for hover/access.
	 *
	 * @param string $name Full file name.
	 * @param int    $max  Maximum displayed length.
	 * @since 2.11.0
	 * @return string
	 */
	private function truncate_filename( $name, $max = 24 ) {
		if ( mb_strlen( $name ) <= $max ) {
			return $name;
		}

		$ext  = '';
		$base = $name;
		$dot  = strrpos( $name, '.' );
		if ( false !== $dot && $dot > 0 ) {
			$ext  = substr( $name, $dot );
			$base = substr( $name, 0, $dot );
		}

		$keep = max( 1, $max - mb_strlen( $ext ) - 1 );
		return mb_substr( $base, 0, $keep ) . '…' . $ext;
	}

	/**
	 * Decode an upload field value into a list of file URLs.
	 *
	 * @param mixed $value Raw stored upload value (array or string of encoded URLs).
	 * @since 2.11.0
	 * @return array<int,string>
	 */
	private function get_upload_urls( $value ) {
		$urls = [];
		foreach ( is_array( $value ) ? $value : [ $value ] as $encoded ) {
			// rawurldecode (not urldecode) so a literal "+" in a filename is
			// preserved rather than turned into a space.
			$decoded = rawurldecode( Helper::get_string_value( $encoded ) );
			if ( '' !== $decoded ) {
				$urls[] = $decoded;
			}
		}
		return $urls;
	}

	/**
	 * Decode an upload field value into a list of URL path components.
	 *
	 * @param mixed $value Raw stored upload value.
	 * @since 2.11.0
	 * @return array<int,string>
	 */
	private function get_upload_paths( $value ) {
		$paths = [];
		foreach ( $this->get_upload_urls( $value ) as $url ) {
			$paths[] = (string) wp_parse_url( $url, PHP_URL_PATH );
		}
		return $paths;
	}

	/**
	 * Convert a stored date-field value to an ISO (Y-m-d) sort key.
	 *
	 * The date field stores its value in the author-configured display format,
	 * which is ambiguous to a client-side sorter (03/02 could be Mar 2 or Feb 3).
	 * Parsing it here with the field's known format yields an unambiguous,
	 * lexicographically-sortable key emitted as data-srfm-sort on the cell.
	 *
	 * @param string $value            Stored date value.
	 * @param string $date_format_attr The field's dateFormat attribute (mm/dd/yyyy, dd/mm/yyyy, yyyy/mm/dd).
	 * @since 2.11.0
	 * @return string ISO date (Y-m-d), or '' when it can't be parsed (caller omits the attribute and the client falls back to text).
	 */
	private function date_to_sortable( $value, $date_format_attr ) {
		$value = trim( Helper::get_string_value( $value ) );
		if ( '' === $value ) {
			return '';
		}

		$format_map = [
			'mm/dd/yyyy' => 'm/d/Y',
			'dd/mm/yyyy' => 'd/m/Y',
			'yyyy/mm/dd' => 'Y/m/d',
		];
		$php_format = $format_map[ $date_format_attr ] ?? '';
		if ( '' === $php_format ) {
			return '';
		}

		// Normalize separators: the stored value may use "-" or "/" depending on
		// the field's rendering, but the format map is slash-based.
		$normalized = str_replace( '-', '/', $value );

		$date = \DateTime::createFromFormat( '!' . $php_format, $normalized );
		if ( ! $date instanceof \DateTime ) {
			return '';
		}

		return $date->format( 'Y-m-d' );
	}

	/**
	 * Normalize a stored field value to a plain string.
	 *
	 * @param mixed $value Raw stored value (string or array).
	 * @since 2.11.0
	 * @return string
	 */
	private function normalize_value( $value ) {
		if ( is_array( $value ) ) {
			$parts = [];
			foreach ( $value as $item ) {
				$part = is_array( $item ) ? $this->normalize_value( $item ) : Helper::get_string_value( $item );
				if ( '' !== $part ) {
					$parts[] = $part;
				}
			}
			$value = implode( ', ', $parts );
		}
		return wp_strip_all_tags( Helper::get_string_value( $value ) );
	}

	/**
	 * Render the entries HTML table.
	 *
	 * @param array<int,array<string,mixed>>                                   $entries Entries to render.
	 * @param array<string,array{label:string,type:string,date_format:string}> $columns Column map (block ID => label + type).
	 * @param int                                                              $form_id Form ID being displayed.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_table( $entries, $columns, $form_id ) {
		// Wrap the table in a horizontal-scroll container so a wide table scrolls
		// WITHIN this wrapper instead of forcing horizontal scroll onto the whole page.
		$output  = '<div class="srfm-entries-table-wrap">';
		$output .= '<table class="srfm-entries-table">';

		$output .= '<thead><tr>';
		foreach ( $columns as $column ) {
			$col_class = 'srfm-entries-col srfm-entries-col--' . sanitize_html_class( $column['type'] );
			// Header is a button so columns can be sorted on click (asc/desc toggle).
			$output .= '<th scope="col" aria-sort="none" class="' . esc_attr( $col_class ) . '">';
			$output .= '<button type="button" class="srfm-entries-sort">';
			$output .= '<span class="srfm-entries-sort-label">' . esc_html( $column['label'] ) . '</span>';
			$output .= '<span class="srfm-entries-sort-icon" aria-hidden="true"></span>';
			$output .= '</button>';
			$output .= '</th>';
		}
		$output .= '</tr></thead>';

		$output .= '<tbody>';
		foreach ( $entries as $entry ) {
			$output .= '<tr>';
			foreach ( $columns as $block_id => $column ) {
				$col_class = 'srfm-entries-col srfm-entries-col--' . sanitize_html_class( $column['type'] );
				$cell      = $this->render_cell( $entry, $block_id );

				/**
				 * Filter: 'srfm_show_entries_field_value'
				 *
				 * Allows modifying a field's rendered cell HTML in the entries
				 * table. The incoming `$cell` is already escaped. The returned
				 * value is re-sanitized with wp_kses_post() before output, so a
				 * filter must return wp_kses_post-safe HTML (tags/attributes not
				 * on the post allowlist will be stripped).
				 *
				 * @since 2.11.0
				 *
				 * @param string              $cell     The rendered (escaped) cell HTML.
				 * @param string              $block_id The column block ID.
				 * @param array<string,mixed> $entry    The entry record.
				 * @param int                 $form_id  The form ID being displayed.
				 */
				$cell = apply_filters( 'srfm_show_entries_field_value', $cell, $block_id, $entry, $form_id );

				// For date columns, emit an unambiguous ISO sort key (parsed with
				// the field's configured format) so the client-side header sort is
				// locale-correct instead of guessing MM/DD vs DD/MM from the text.
				$sort_attr = '';
				if ( ! empty( $column['date_format'] ) ) {
					$iso = $this->date_to_sortable( $this->get_entry_value_for_column( $entry, $block_id ), $column['date_format'] );
					if ( '' !== $iso ) {
						$sort_attr = ' data-srfm-sort="' . esc_attr( $iso ) . '"';
					}
				}

				$output .= '<td class="' . esc_attr( $col_class ) . '"' . $sort_attr . '>' . wp_kses_post( Helper::get_string_value( $cell ) ) . '</td>';
			}
			$output .= '</tr>';
		}
		$output .= '</tbody>';

		$output .= '</table>';
		$output .= '</div>';

		return $output;
	}

	/**
	 * Render the pagination navigation below the table.
	 *
	 * @param int $form_id     Form ID (scopes the page query var).
	 * @param int $page        Current page (1-based).
	 * @param int $total_pages Total number of pages.
	 * @since 2.11.0
	 * @return string
	 */
	private function render_pagination( $form_id, $page, $total_pages ) {
		if ( $total_pages <= 1 ) {
			return '';
		}

		$key  = 'srfm_entries_page_' . $form_id;
		$base = remove_query_arg( $key );

		$output = '<nav class="srfm-entries-pagination" aria-label="' . esc_attr__( 'Entries navigation', 'sureforms-pro' ) . '">';

		if ( $page > 1 ) {
			// Drop the arg entirely for page 1 to keep the URL clean.
			$prev_url = $page - 1 <= 1 ? $base : add_query_arg( $key, $page - 1, $base );
			$output  .= '<a class="srfm-entries-page srfm-entries-page-prev" href="' . esc_url( $prev_url ) . '">' . esc_html__( 'Previous', 'sureforms-pro' ) . '</a>';
		}

		$output .= '<span class="srfm-entries-page-info">' . sprintf(
			/* translators: 1: current page number, 2: total number of pages. */
			esc_html__( 'Page %1$d of %2$d', 'sureforms-pro' ),
			absint( $page ),
			absint( $total_pages )
		) . '</span>';

		if ( $page < $total_pages ) {
			$next_url = add_query_arg( $key, $page + 1, $base );
			$output  .= '<a class="srfm-entries-page srfm-entries-page-next" href="' . esc_url( $next_url ) . '">' . esc_html__( 'Next', 'sureforms-pro' ) . '</a>';
		}

		$output .= '</nav>';

		return $output;
	}
}
