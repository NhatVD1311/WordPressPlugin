<?php
/**
 * Embed Styling - Pro Extension.
 *
 * Outputs Pro CSS variables for embed block styling.
 * Block attributes are added via JS filter (blocks.registerBlockType).
 *
 * @package sureforms-pro
 * @since 2.7.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Embed_Styling Class.
 *
 * @since 2.7.0
 */
class Embed_Styling {
	use Get_Instance;

	/**
	 * Allowed CSS units for size/dimension values.
	 *
	 * @since 2.7.0
	 */
	private const ALLOWED_CSS_UNITS = [ 'px', 'em', 'rem', '%', 'vh', 'vw', 'vmin', 'vmax', 'pt', 'cm', 'mm', 'in', 'ch', 'ex' ];

	/**
	 * Allowed CSS border style values.
	 *
	 * @since 2.7.0
	 */
	private const ALLOWED_BORDER_STYLES = [ 'none', 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset', 'hidden' ];

	/**
	 * Allowed box-shadow position values.
	 *
	 * @since 2.7.0
	 */
	private const ALLOWED_BOX_SHADOW_POSITIONS = [ 'outset', 'inset' ];

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 2.7.0
	 */
	public function __construct() {
		// Priority 20 ensures embed block styling overrides instant form styling (which uses default priority 10).
		add_action( 'srfm_form_css_variables', [ $this, 'output_pro_css_variables' ], 20 );
		add_action( 'srfm_enqueue_preview_styling_scripts', [ $this, 'enqueue_preview_styling_script' ] );
	}

	/**
	 * Enqueue Pro preview styling script.
	 *
	 * @return void
	 * @since 2.7.0
	 */
	public function enqueue_preview_styling_script() {
		// Load from dist directory (webpack output).
		$script_asset_path = SRFM_PRO_DIR . 'dist/previewStylingPro.asset.php';
		$script_asset      = file_exists( $script_asset_path ) ? require $script_asset_path : [ 'version' => SRFM_PRO_VER ];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-preview-styling',
			SRFM_PRO_URL . 'dist/previewStylingPro.js',
			[ defined( 'SRFM_SLUG' ) ? SRFM_SLUG . '-preview-styling' : 'sureforms-preview-styling' ],
			is_array( $script_asset ) && isset( $script_asset['version'] ) ? $script_asset['version'] : SRFM_PRO_VER,
			true
		);
	}

	/**
	 * Output Pro CSS variables for embed styling.
	 *
	 * Only outputs when formTheme is 'custom'.
	 * Uses default values to ensure CSS variables are always output,
	 * since WordPress doesn't save default attribute values to the database.
	 *
	 * @param array<string,mixed> $params Parameters including block_attrs.
	 * @return void
	 * @since 2.7.0
	 */
	public function output_pro_css_variables( $params ) {
		$block_attrs = Helper::get_array_value( $params['block_attrs'] ?? [] );

		// Only output when Custom theme is selected.
		if ( empty( $block_attrs ) || 'custom' !== ( $block_attrs['formTheme'] ?? '' ) ) {
			return;
		}

		$variables = [];

		// Row Gap (default: 18px).
		$row_gap                                    = floatval( Helper::get_string_value( $block_attrs['formRowGap'] ?? 18 ) );
		$row_gap_unit                               = self::sanitize_css_unit( $block_attrs['formRowGapUnit'] ?? 'px' );
		$variables['--srfm-row-gap-between-blocks'] = "{$row_gap}{$row_gap_unit}";

		// Column Gap (default: 16px).
		$column_gap                                    = floatval( Helper::get_string_value( $block_attrs['formColumnGap'] ?? 16 ) );
		$column_gap_unit                               = self::sanitize_css_unit( $block_attrs['formColumnGapUnit'] ?? 'px' );
		$variables['--srfm-column-gap-between-blocks'] = "{$column_gap}{$column_gap_unit}";

		// Button Padding.
		$padding_unit                              = self::sanitize_css_unit( $block_attrs['buttonPaddingUnit'] ?? 'px' );
		$variables['--srfm-button-padding-top']    = floatval( Helper::get_string_value( $block_attrs['buttonPaddingTop'] ?? 10 ) ) . $padding_unit;
		$variables['--srfm-button-padding-right']  = floatval( Helper::get_string_value( $block_attrs['buttonPaddingRight'] ?? 14 ) ) . $padding_unit;
		$variables['--srfm-button-padding-bottom'] = floatval( Helper::get_string_value( $block_attrs['buttonPaddingBottom'] ?? 10 ) ) . $padding_unit;
		$variables['--srfm-button-padding-left']   = floatval( Helper::get_string_value( $block_attrs['buttonPaddingLeft'] ?? 14 ) ) . $padding_unit;

		// Button Border Style (default: solid).
		$variables['--srfm-button-border-style'] = self::sanitize_border_style( $block_attrs['buttonBorderStyle'] ?? 'solid' );

		// Button Border Width (default: 1px each).
		$variables['--srfm-button-border-width-top']    = floatval( Helper::get_string_value( $block_attrs['buttonBorderWidthTop'] ?? 1 ) ) . 'px';
		$variables['--srfm-button-border-width-right']  = floatval( Helper::get_string_value( $block_attrs['buttonBorderWidthRight'] ?? 1 ) ) . 'px';
		$variables['--srfm-button-border-width-bottom'] = floatval( Helper::get_string_value( $block_attrs['buttonBorderWidthBottom'] ?? 1 ) ) . 'px';
		$variables['--srfm-button-border-width-left']   = floatval( Helper::get_string_value( $block_attrs['buttonBorderWidthLeft'] ?? 1 ) ) . 'px';

		// Button Border Radius (default: 6px each).
		$radius_unit                                     = self::sanitize_css_unit( $block_attrs['buttonBorderRadiusUnit'] ?? 'px' );
		$variables['--srfm-button-border-radius-top']    = floatval( Helper::get_string_value( $block_attrs['buttonBorderRadiusTop'] ?? 6 ) ) . $radius_unit;
		$variables['--srfm-button-border-radius-right']  = floatval( Helper::get_string_value( $block_attrs['buttonBorderRadiusRight'] ?? 6 ) ) . $radius_unit;
		$variables['--srfm-button-border-radius-bottom'] = floatval( Helper::get_string_value( $block_attrs['buttonBorderRadiusBottom'] ?? 6 ) ) . $radius_unit;
		$variables['--srfm-button-border-radius-left']   = floatval( Helper::get_string_value( $block_attrs['buttonBorderRadiusLeft'] ?? 6 ) ) . $radius_unit;

		// Button Border Colors (only output if explicitly set).
		if ( ! empty( $block_attrs['buttonBorderColorNormal'] ) ) {
			$variables['--srfm-button-border-color'] = Helper::sanitize_css_value( $block_attrs['buttonBorderColorNormal'] );
		}
		if ( ! empty( $block_attrs['buttonBorderColorHover'] ) ) {
			$variables['--srfm-button-border-hover-color'] = Helper::sanitize_css_value( $block_attrs['buttonBorderColorHover'] );
		}

		// Button Text Colors (only output if explicitly set).
		if ( ! empty( $block_attrs['buttonTextColorNormal'] ) ) {
			$variables['--srfm-button-text-color-normal'] = Helper::sanitize_css_value( $block_attrs['buttonTextColorNormal'] );
		}
		if ( ! empty( $block_attrs['buttonTextColorHover'] ) ) {
			$variables['--srfm-button-text-color-hover'] = Helper::sanitize_css_value( $block_attrs['buttonTextColorHover'] );
		}

		// Button Background Normal (only output if explicitly set).
		// Default to 'color' since WordPress doesn't save default attribute values.
		$bg_type_normal       = Helper::get_string_value( $block_attrs['buttonBackgroundTypeNormal'] ?? 'color' );
		$gradient_type_normal = Helper::get_string_value( $block_attrs['buttonGradientTypeNormal'] ?? 'basic' );

		if ( 'color' === $bg_type_normal && ! empty( $block_attrs['buttonBackgroundColorNormal'] ) ) {
			$variables['--srfm-button-background-color-normal'] = Helper::sanitize_css_value( $block_attrs['buttonBackgroundColorNormal'] );
		} elseif ( 'gradient' === $bg_type_normal ) {
			if ( 'advanced' === $gradient_type_normal ) {
				// Construct gradient CSS from individual values.
				$gradient_css = Helper::get_gradient_css(
					Helper::get_string_value( $block_attrs['buttonBackgroundGradientTypeNormal'] ?? 'linear' ),
					Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientColor1Normal'] ?? '#FFC9B2' ),
					Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientColor2Normal'] ?? '#C7CBFF' ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientLocation1Normal'] ?? 0 ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientLocation2Normal'] ?? 100 ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientAngleNormal'] ?? 90 )
				);
				$variables['--srfm-button-background-gradient-normal'] = $gradient_css;
			} else {
				// Use saved value or default gradient for basic mode.
				$variables['--srfm-button-background-gradient-normal'] = Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientNormal'] ?? 'linear-gradient(90deg, #FFC9B2 0%, #C7CBFF 100%)' );
			}
		}

		// Button Background Hover (only output if explicitly set).
		// Default to 'color' since WordPress doesn't save default attribute values.
		$bg_type_hover       = Helper::get_string_value( $block_attrs['buttonBackgroundTypeHover'] ?? 'color' );
		$gradient_type_hover = Helper::get_string_value( $block_attrs['buttonGradientTypeHover'] ?? 'basic' );

		if ( 'color' === $bg_type_hover && ! empty( $block_attrs['buttonBackgroundColorHover'] ) ) {
			$variables['--srfm-button-background-color-hover'] = Helper::sanitize_css_value( $block_attrs['buttonBackgroundColorHover'] );
		} elseif ( 'gradient' === $bg_type_hover ) {
			if ( 'advanced' === $gradient_type_hover ) {
				// Construct gradient CSS from individual values.
				$gradient_css = Helper::get_gradient_css(
					Helper::get_string_value( $block_attrs['buttonBackgroundGradientTypeHover'] ?? 'linear' ),
					Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientColor1Hover'] ?? '#FFC9B2' ),
					Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientColor2Hover'] ?? '#C7CBFF' ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientLocation1Hover'] ?? 0 ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientLocation2Hover'] ?? 100 ),
					Helper::get_integer_value( $block_attrs['buttonBackgroundGradientAngleHover'] ?? 90 )
				);
				$variables['--srfm-button-background-gradient-hover'] = $gradient_css;
			} else {
				// Use saved value or default gradient for basic mode.
				$variables['--srfm-button-background-gradient-hover'] = Helper::sanitize_css_value( $block_attrs['buttonBackgroundGradientHover'] ?? 'linear-gradient(90deg, #FFC9B2 0%, #C7CBFF 100%)' );
			}
		}

		// Button Typography (defaults: size=16px, lineHeight=1.5em).
		$text_size_unit                      = self::sanitize_css_unit( $block_attrs['buttonTextSizeUnit'] ?? 'px' );
		$line_height_unit                    = self::sanitize_css_unit( $block_attrs['buttonLineHeightUnit'] ?? 'em' );
		$variables['--srfm-btn-font-size']   = floatval( Helper::get_string_value( $block_attrs['buttonTextSize'] ?? 16 ) ) . $text_size_unit;
		$variables['--srfm-btn-line-height'] = floatval( Helper::get_string_value( $block_attrs['buttonLineHeight'] ?? 1.5 ) ) . $line_height_unit;

		// Field Colors.
		$variables['--srfm-color-input-background'] = Helper::sanitize_css_value( $block_attrs['fieldBgColor'] ?? '#FBFBFB' );
		// Label, input, and help-text colors only output if explicitly set to avoid overriding free plugin's textColor-derived variables.
		if ( ! empty( $block_attrs['fieldHelpTextColor'] ) ) {
			$variables['--srfm-color-input-description'] = Helper::sanitize_css_value( $block_attrs['fieldHelpTextColor'] );
		}
		if ( ! empty( $block_attrs['fieldLabelColor'] ) ) {
			$variables['--srfm-color-input-label'] = Helper::sanitize_css_value( $block_attrs['fieldLabelColor'] );
		}
		if ( ! empty( $block_attrs['fieldInputColor'] ) ) {
			$variables['--srfm-color-input-text'] = Helper::sanitize_css_value( $block_attrs['fieldInputColor'] );
		}

		// Field Label Typography (defaults: size=16px, lineHeight=1.5em).
		$label_size_unit                       = self::sanitize_css_unit( $block_attrs['fieldLabelSizeUnit'] ?? 'px' );
		$label_line_height_unit                = self::sanitize_css_unit( $block_attrs['fieldLabelLineHeightUnit'] ?? 'em' );
		$variables['--srfm-label-font-size']   = floatval( Helper::get_string_value( $block_attrs['fieldLabelSize'] ?? 16 ) ) . $label_size_unit;
		$variables['--srfm-label-line-height'] = floatval( Helper::get_string_value( $block_attrs['fieldLabelLineHeight'] ?? 1.5 ) ) . $label_line_height_unit;

		// Field Help Text Typography (defaults: size=14px, lineHeight=1.4em).
		$help_size_unit                              = self::sanitize_css_unit( $block_attrs['fieldHelpTextSizeUnit'] ?? 'px' );
		$help_line_height_unit                       = self::sanitize_css_unit( $block_attrs['fieldHelpTextLineHeightUnit'] ?? 'em' );
		$variables['--srfm-description-font-size']   = floatval( Helper::get_string_value( $block_attrs['fieldHelpTextSize'] ?? 14 ) ) . $help_size_unit;
		$variables['--srfm-description-line-height'] = floatval( Helper::get_string_value( $block_attrs['fieldHelpTextLineHeight'] ?? 1.4 ) ) . $help_line_height_unit;

		// Field Label Gap (default: 6px).
		$label_gap_unit                      = self::sanitize_css_unit( $block_attrs['fieldLabelGapUnit'] ?? 'px' );
		$variables['--srfm-input-label-gap'] = floatval( Helper::get_string_value( $block_attrs['fieldLabelGap'] ?? 6 ) ) . $label_gap_unit;

		// Field Border Color (default: #C4C4C4).
		$variables['--srfm-color-input-border'] = Helper::sanitize_css_value( $block_attrs['fieldBorderColor'] ?? '#C4C4C4' );

		// Field Border Width (default: 1px each).
		$field_border_width_unit                       = self::sanitize_css_unit( $block_attrs['fieldBorderWidthUnit'] ?? 'px' );
		$variables['--srfm-field-border-width-top']    = floatval( Helper::get_string_value( $block_attrs['fieldBorderWidthTop'] ?? 1 ) ) . $field_border_width_unit;
		$variables['--srfm-field-border-width-right']  = floatval( Helper::get_string_value( $block_attrs['fieldBorderWidthRight'] ?? 1 ) ) . $field_border_width_unit;
		$variables['--srfm-field-border-width-bottom'] = floatval( Helper::get_string_value( $block_attrs['fieldBorderWidthBottom'] ?? 1 ) ) . $field_border_width_unit;
		$variables['--srfm-field-border-width-left']   = floatval( Helper::get_string_value( $block_attrs['fieldBorderWidthLeft'] ?? 1 ) ) . $field_border_width_unit;

		// Field Border Radius (default: 6px each).
		$field_border_radius_unit                       = self::sanitize_css_unit( $block_attrs['fieldBorderRadiusUnit'] ?? 'px' );
		$variables['--srfm-field-border-radius-top']    = floatval( Helper::get_string_value( $block_attrs['fieldBorderRadiusTop'] ?? 6 ) ) . $field_border_radius_unit;
		$variables['--srfm-field-border-radius-right']  = floatval( Helper::get_string_value( $block_attrs['fieldBorderRadiusRight'] ?? 6 ) ) . $field_border_radius_unit;
		$variables['--srfm-field-border-radius-bottom'] = floatval( Helper::get_string_value( $block_attrs['fieldBorderRadiusBottom'] ?? 6 ) ) . $field_border_radius_unit;
		$variables['--srfm-field-border-radius-left']   = floatval( Helper::get_string_value( $block_attrs['fieldBorderRadiusLeft'] ?? 6 ) ) . $field_border_radius_unit;

		// Field Box Shadow - Normal.
		$box_shadow_h_normal        = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowHOffsetNormal'] ?? 0 ) );
		$box_shadow_v_normal        = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowVOffsetNormal'] ?? 0 ) );
		$box_shadow_blur_normal     = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowBlurNormal'] ?? 0 ) );
		$box_shadow_spread_normal   = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowSpreadNormal'] ?? 0 ) );
		$box_shadow_color_normal    = ! empty( $block_attrs['fieldBoxShadowColorNormal'] ) ? Helper::sanitize_css_value( $block_attrs['fieldBoxShadowColorNormal'] ) : 'var(--srfm-color-input-border-focus-glow)';
		$box_shadow_position_normal = isset( $block_attrs['fieldBoxShadowPositionNormal'] ) && in_array( $block_attrs['fieldBoxShadowPositionNormal'], self::ALLOWED_BOX_SHADOW_POSITIONS, true ) ? $block_attrs['fieldBoxShadowPositionNormal'] : 'outset';

		$variables['--srfm-field-box-shadow-normal'] = trim(
			sprintf(
				'%spx %spx %spx %spx %s %s',
				$box_shadow_h_normal,
				$box_shadow_v_normal,
				$box_shadow_blur_normal,
				$box_shadow_spread_normal,
				$box_shadow_color_normal,
				'inset' === $box_shadow_position_normal ? 'inset' : ''
			)
		);

		// Field Box Shadow - Focus.
		$box_shadow_h_focus        = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowHOffsetFocus'] ?? 0 ) );
		$box_shadow_v_focus        = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowVOffsetFocus'] ?? 0 ) );
		$box_shadow_blur_focus     = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowBlurFocus'] ?? 0 ) );
		$box_shadow_spread_focus   = floatval( Helper::get_string_value( $block_attrs['fieldBoxShadowSpreadFocus'] ?? 3 ) );
		$box_shadow_color_focus    = ! empty( $block_attrs['fieldBoxShadowColorFocus'] ) ? Helper::sanitize_css_value( $block_attrs['fieldBoxShadowColorFocus'] ) : 'var(--srfm-color-input-border-focus-glow)';
		$box_shadow_position_focus = isset( $block_attrs['fieldBoxShadowPositionFocus'] ) && in_array( $block_attrs['fieldBoxShadowPositionFocus'], self::ALLOWED_BOX_SHADOW_POSITIONS, true ) ? $block_attrs['fieldBoxShadowPositionFocus'] : 'outset';

		$variables['--srfm-field-box-shadow-focus'] = trim(
			sprintf(
				'%spx %spx %spx %spx %s %s',
				$box_shadow_h_focus,
				$box_shadow_v_focus,
				$box_shadow_blur_focus,
				$box_shadow_spread_focus,
				$box_shadow_color_focus,
				'inset' === $box_shadow_position_focus ? 'inset' : ''
			)
		);

		// Error Color (default: #dc2626).
		$error_color                                 = Helper::sanitize_css_value( $block_attrs['errorColor'] ?? '#dc2626' );
		$variables['--srfm-error-color']             = $error_color;
		$variables['--srfm-error-color-border']      = Pro_Helper::get_hsl_notation_from_hex( $error_color, 0.65 );
		$variables['--srfm-error-color-border-glow'] = Pro_Helper::get_hsl_notation_from_hex( $error_color, 0.15 );

		// Field hover/disabled state colors (derived from base colors).
		$field_bg_color                                      = Helper::sanitize_css_value( $block_attrs['fieldBgColor'] ?? '#FBFBFB' );
		$field_border_color                                  = Helper::sanitize_css_value( $block_attrs['fieldBorderColor'] ?? '#C4C4C4' );
		$variables['--srfm-color-input-background-hover']    = 'hsl( from ' . $field_bg_color . ' h s l / 0.05 )';
		$variables['--srfm-color-input-background-disabled'] = 'hsl( from ' . $field_bg_color . ' h s l / 0.05 )';
		$variables['--srfm-color-input-border-disabled']     = 'hsl( from ' . $field_border_color . ' h s l / 0.15 )';

		Pro_Helper::add_css_variables( $variables );
	}

	/**
	 * Sanitize a CSS unit value against an allowlist.
	 *
	 * @param string $unit The unit to validate.
	 * @param string $default The default unit to return if invalid.
	 * @return string A valid CSS unit.
	 * @since 2.7.0
	 */
	private static function sanitize_css_unit( $unit, $default = 'px' ) {
		$unit = strtolower( trim( Helper::get_string_value( $unit ) ) );
		return in_array( $unit, self::ALLOWED_CSS_UNITS, true ) ? $unit : $default;
	}

	/**
	 * Sanitize a CSS border style value against an allowlist.
	 *
	 * @param string $style The border style to validate.
	 * @return string A valid CSS border-style value.
	 * @since 2.7.0
	 */
	private static function sanitize_border_style( $style ) {
		$style = strtolower( trim( Helper::get_string_value( $style ) ) );
		return in_array( $style, self::ALLOWED_BORDER_STYLES, true ) ? $style : 'solid';
	}

}
