<?php
/**
 * Form Presets - Pro Extension.
 *
 * Registers plugin-shipped form-styling presets (Baseline, Minimal, Dark)
 * and the render-time logic that applies them. Designed to be
 * self-contained so the existing `_srfm_forms_styling_starter` meta and
 * the existing styling hooks in `Hooks` are not modified.
 *
 * Each preset has its own dedicated schema and defaults methods
 * (`get_<preset>_schema_properties()` + `get_<preset>_default_values()`)
 * so values can be tuned per preset independently of starter and the
 * other preset.
 *
 * @package sureforms-pro
 * @since   2.10.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Form Presets class.
 *
 * @since 2.10.0
 */
class Form_Presets {
	use Get_Instance;

	/**
	 * Constructor — register the preset metas alongside starter on the same
	 * `srfm_register_additional_post_meta` action that `Hooks` uses.
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_preset_metas' ] );
		add_filter( 'srfm_export_and_import_post_meta_keys', [ $this, 'add_preset_metas_to_export' ] );
	}

	/**
	 * Register the baseline, minimal, and dark preset post metas.
	 *
	 * @since  2.10.0
	 * @hooked srfm_register_additional_post_meta
	 * @return void
	 */
	public function register_preset_metas() {
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_forms_styling_baseline',
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => [ self::class, 'sanitize_preset_meta' ],
				'show_in_rest'      => [
					'schema' => [
						'type'       => 'object',
						'context'    => [ 'edit' ],
						'properties' => $this->get_common_schema_properties(),
					],
				],
				'default'           => $this->get_baseline_default_values(),
			]
		);

		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_forms_styling_minimal',
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => [ self::class, 'sanitize_preset_meta' ],
				'show_in_rest'      => [
					'schema' => [
						'type'       => 'object',
						'context'    => [ 'edit' ],
						'properties' => $this->get_common_schema_properties(),
					],
				],
				'default'           => $this->get_minimal_default_values(),
			]
		);

		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_forms_styling_dark',
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => [ self::class, 'sanitize_preset_meta' ],
				'show_in_rest'      => [
					'schema' => [
						'type'       => 'object',
						'context'    => [ 'edit' ],
						'properties' => $this->get_common_schema_properties(),
					],
				],
				'default'           => $this->get_dark_default_values(),
			]
		);
	}

	/**
	 * Sanitize a preset post-meta payload. Runs the shared type-coercion via
	 * `Helper::sanitize_by_type()` first, then strips any string value that
	 * contains CSS metacharacters (`;`, `}`, `{`, `*`, `<`, `>`). Defense-in-
	 * depth: the `auth_callback` already restricts writes to admins, but
	 * preset colour values flow into inline `hsl( from <value> h s l / … )`
	 * blocks via `Hooks::add_premium_form_styling_variables()`. None of the
	 * legitimate string values in the schema (colours, units, enums, gradient
	 * strings) contain these characters, so blanket-stripping is safe.
	 *
	 * @since 2.10.0
	 * @param  mixed $meta_value Raw meta payload from REST.
	 * @return mixed Sanitized payload; offending strings replaced with ''.
	 */
	public static function sanitize_preset_meta( $meta_value ) {
		$meta_value = Helper::sanitize_by_type( $meta_value );

		if ( ! is_array( $meta_value ) ) {
			return $meta_value;
		}

		array_walk_recursive(
			$meta_value,
			static function( &$value ) {
				// Sanitization here is one of *two* load-bearing layers and
				// both must stay in place:
				// 1. (this layer) Sanitize-on-write — block writes that
				// contain CSS metacharacters (`;`, `}`, `{`, `*`, `<`,
				// `>`) before the value is persisted. Cheap and stops
				// the most obvious CSS-injection shapes at the
				// perimeter.
				// 2. Escape-on-emit — `Pro_Helper::add_css_variables`
				// (`inc/helper.php`) runs every value through
				// `esc_html()` before it lands inside the inline
				// `<style>` block. This catches characters the
				// denylist above misses (e.g. `(`, `)`, `@`, `\`,
				// CR/LF).
				// If either layer is removed in a future refactor the other
				// alone does not fully cover preset colour values flowing
				// into `hsl( from <value> h s l / … )` blocks. A per-key
				// allowlist (hex regex for colours, enum for known-string
				// keys) would be a stronger long-term fix.
				if ( is_string( $value ) && false !== strpbrk( $value, ';}{*<>' ) ) {
					$value = '';
				}
			}
		);

		return $meta_value;
	}

	/**
	 * Append the Baseline / Minimal / Dark preset metas to the
	 * unserialized export/import allowlist so their values survive
	 * `sureforms/inc/export.php`'s round-trip. Without this, the
	 * import-side whitelist check in `import_forms_with_meta()`
	 * silently drops them and exported forms lose every preset-meta
	 * value on re-import.
	 *
	 * `_srfm_forms_styling_starter` (Custom) is already in the free
	 * plugin's hardcoded list, so it doesn't need re-adding here.
	 *
	 * @hooked srfm_export_and_import_post_meta_keys
	 * @since  2.10.0
	 * @param  array<string>|mixed $meta_keys Existing unserialized meta keys.
	 * @return array<string>
	 */
	public function add_preset_metas_to_export( $meta_keys ) {
		$preset_metas = [
			'_srfm_forms_styling_baseline',
			'_srfm_forms_styling_minimal',
			'_srfm_forms_styling_dark',
		];
		return is_array( $meta_keys )
			? array_merge( $meta_keys, $preset_metas )
			: $preset_metas;
	}

	/**
	 * REST schema properties shared by every Pro-shipped preset (Baseline,
	 * Minimal, Dark). Their schemas are byte-identical, so every preset's
	 * `register_post_meta()` `properties` entry calls this directly. When
	 * a preset needs its own schema entries, split this into a per-preset
	 * wrapper at that point — not before.
	 *
	 * @since 2.10.0
	 * @return array<string, array<string, string>>
	 */
	private function get_common_schema_properties() {
		return [
			'form_theme'                                   => [
				'type' => 'string',
			],
			// Background — owned per-preset and mirrored into the free
			// plugin's `_srfm_forms_styling` meta by the JS mirror effects
			// so the Background panel pickers reflect the preset's values.
			'bg_color'                                     => [
				'type' => 'string',
			],
			'bg_type'                                      => [
				'type' => 'string',
			],
			// Background gradient fields — mirrored so `--srfm-bg-gradient`
			// and the bg-type classes are correct on the frontend.
			'bg_gradient'                                  => [
				'type' => 'string',
			],
			'bg_gradient_type'                             => [
				'type' => 'string',
			],
			'bg_gradient_color_1'                          => [
				'type' => 'string',
			],
			'bg_gradient_color_2'                          => [
				'type' => 'string',
			],
			'bg_gradient_location_1'                       => [
				'type' => 'integer',
			],
			'bg_gradient_location_2'                       => [
				'type' => 'integer',
			],
			'bg_gradient_angle'                            => [
				'type' => 'integer',
			],
			'bg_gradient_overlay_type'                     => [
				'type' => 'string',
			],
			'bg_image_overlay_color'                       => [
				'type' => 'string',
			],
			// Background image fields — mirrored so image/attachment/
			// repeat/size are correct on forms that use this preset.
			'bg_image'                                     => [
				'type' => 'string',
			],
			'bg_image_attachment'                          => [
				'type' => 'string',
			],
			'bg_image_repeat'                              => [
				'type' => 'string',
			],
			'bg_image_size'                                => [
				'type' => 'string',
			],
			'bg_image_size_custom'                         => [
				'type' => 'integer',
			],
			'bg_image_size_custom_unit'                    => [
				'type' => 'string',
			],
			// Form-level colour scheme — owned per-preset and mirrored
			// into `_srfm_forms_styling` by the JS effect in
			// `src/admin/form-stylings.js` so the user's Background-panel
			// Primary / Text / Text-on-Primary edits land on the active
			// preset only. The free plugin's emission in
			// `sureforms/inc/generate-form-markup.php` continues to drive
			// the actual CSS variables from `_srfm_forms_styling`.
			'primary_color'                                => [
				'type' => 'string',
			],
			'text_color'                                   => [
				'type' => 'string',
			],
			'text_color_on_primary'                        => [
				'type' => 'string',
			],
			// Submit button alignment — mirrored so the button alignment
			// is preserved when the preset is applied to another form.
			'submit_button_alignment'                      => [
				'type' => 'string',
			],
			'error_color'                                  => [
				'type' => 'string',
			],
			'form_row_gap'                                 => [
				'type' => 'integer',
			],
			'form_row_gap_type'                            => [
				'type' => 'string',
			],
			'form_column_gap'                              => [
				'type' => 'integer',
			],
			'form_column_gap_type'                         => [
				'type' => 'string',
			],
			// Button Properties.
			'button_padding_top'                           => [
				'type' => 'number',
			],
			'button_padding_right'                         => [
				'type' => 'number',
			],
			'button_padding_bottom'                        => [
				'type' => 'number',
			],
			'button_padding_left'                          => [
				'type' => 'number',
			],
			'button_padding_unit'                          => [
				'type' => 'string',
			],
			'button_padding_link'                          => [
				'type' => 'boolean',
			],
			// Border Width.
			'button_border_style'                          => [
				'type' => 'string',
			],
			'button_border_width_top'                      => [
				'type' => 'number',
			],
			'button_border_width_right'                    => [
				'type' => 'number',
			],
			'button_border_width_bottom'                   => [
				'type' => 'number',
			],
			'button_border_width_left'                     => [
				'type' => 'number',
			],
			'button_border_width_link'                     => [
				'type' => 'boolean',
			],
			// Border Radius.
			'button_border_radius_top'                     => [
				'type' => 'number',
			],
			'button_border_radius_right'                   => [
				'type' => 'number',
			],
			'button_border_radius_bottom'                  => [
				'type' => 'number',
			],
			'button_border_radius_left'                    => [
				'type' => 'number',
			],
			'button_border_radius_unit'                    => [
				'type' => 'string',
			],
			'button_border_radius_link'                    => [
				'type' => 'boolean',
			],
			// Border Color.
			'button_border_color_normal'                   => [
				'type' => 'string',
			],
			'button_border_color_hover'                    => [
				'type' => 'string',
			],
			// Background Normal.
			'button_text_color_normal'                     => [
				'type' => 'string',
			],
			'button_background_type_normal'                => [
				'type' => 'string',
			],
			'button_background_color_normal'               => [
				'type' => 'string',
			],
			'button_gradient_type_normal'                  => [
				'type' => 'string',
			],
			'button_background_gradient_type_normal'       => [
				'type' => 'string',
			],
			'button_background_gradient_color_1_normal'    => [
				'type' => 'string',
			],
			'button_background_gradient_color_2_normal'    => [
				'type' => 'string',
			],
			'button_background_gradient_location_1_normal' => [
				'type' => 'integer',
			],
			'button_background_gradient_location_2_normal' => [
				'type' => 'integer',
			],
			'button_background_gradient_angle_normal'      => [
				'type' => 'integer',
			],
			'button_background_gradient_normal'            => [
				'type' => 'string',
			],
			// Background Hover.
			'button_text_color_hover'                      => [
				'type' => 'string',
			],
			'button_background_type_hover'                 => [
				'type' => 'string',
			],
			'button_background_color_hover'                => [
				'type' => 'string',
			],
			'button_gradient_type_hover'                   => [
				'type' => 'string',
			],
			'button_background_gradient_type_hover'        => [
				'type' => 'string',
			],
			'button_background_gradient_color_1_hover'     => [
				'type' => 'string',
			],
			'button_background_gradient_color_2_hover'     => [
				'type' => 'string',
			],
			'button_background_gradient_location_1_hover'  => [
				'type' => 'integer',
			],
			'button_background_gradient_location_2_hover'  => [
				'type' => 'integer',
			],
			'button_background_gradient_angle_hover'       => [
				'type' => 'integer',
			],
			'button_background_gradient_hover'             => [
				'type' => 'string',
			],
			// Typography.
			'button_text_size'                             => [
				'type' => 'number',
			],
			'button_text_size_unit'                        => [
				'type' => 'string',
			],
			'button_line_height'                           => [
				'type' => 'number',
			],
			'button_line_height_unit'                      => [
				'type' => 'string',
			],
			// Field Properties.
			'field_bg_color'                               => [
				'type' => 'string',
			],
			'field_label_color'                            => [
				'type' => 'string',
			],
			// Input text color — drives `--srfm-color-input-text` for
			// the standalone form (emitted only when set, see
			// `inc/extensions/hooks.php::add_premium_form_styling_variables`).
			// Currently only the Dark preset ships a default; the field
			// is declared on the other preset schemas for parity so each
			// preset can override input text colour independently.
			'field_input_color'                            => [
				'type' => 'string',
			],
			'field_help_text_color'                        => [
				'type' => 'string',
			],
			'field_label_size'                             => [
				'type' => 'number',
			],
			'field_label_size_unit'                        => [
				'type' => 'string',
			],
			'field_label_line_height'                      => [
				'type' => 'number',
			],
			'field_label_line_height_unit'                 => [
				'type' => 'string',
			],
			'field_help_text_size'                         => [
				'type' => 'number',
			],
			'field_help_text_size_unit'                    => [
				'type' => 'string',
			],
			'field_help_text_line_height'                  => [
				'type' => 'number',
			],
			'field_help_text_line_height_unit'             => [
				'type' => 'string',
			],
			'field_border_color'                           => [
				'type' => 'string',
			],
			'field_label_gap'                              => [
				'type' => 'number',
			],
			'field_label_gap_unit'                         => [
				'type' => 'string',
			],
			'field_border_width_top'                       => [
				'type' => 'number',
			],
			'field_border_width_right'                     => [
				'type' => 'number',
			],
			'field_border_width_bottom'                    => [
				'type' => 'number',
			],
			'field_border_width_left'                      => [
				'type' => 'number',
			],
			'field_border_width_unit'                      => [
				'type' => 'string',
			],
			'field_border_width_link'                      => [
				'type' => 'boolean',
			],
			'field_border_radius_top'                      => [
				'type' => 'number',
			],
			'field_border_radius_right'                    => [
				'type' => 'number',
			],
			'field_border_radius_bottom'                   => [
				'type' => 'number',
			],
			'field_border_radius_left'                     => [
				'type' => 'number',
			],
			'field_border_radius_unit'                     => [
				'type' => 'string',
			],
			'field_border_radius_link'                     => [
				'type' => 'boolean',
			],
			'field_box_shadow_color_normal'                => [
				'type' => 'string',
			],
			'field_box_shadow_horizontal_offset_normal'    => [
				'type' => 'number',
			],
			'field_box_shadow_vertical_offset_normal'      => [
				'type' => 'number',
			],
			'field_box_shadow_blur_normal'                 => [
				'type' => 'number',
			],
			'field_box_shadow_spread_normal'               => [
				'type' => 'number',
			],
			'field_box_shadow_position_normal'             => [
				'type' => 'string',
			],
			'field_box_shadow_color_focus'                 => [
				'type' => 'string',
			],
			'field_box_shadow_horizontal_offset_focus'     => [
				'type' => 'number',
			],
			'field_box_shadow_vertical_offset_focus'       => [
				'type' => 'number',
			],
			'field_box_shadow_blur_focus'                  => [
				'type' => 'number',
			],
			'field_box_shadow_spread_focus'                => [
				'type' => 'number',
			],
			'field_box_shadow_position_focus'              => [
				'type' => 'string',
			],
			// Page Break Buttons.
			'page_break_next_button_text_color_normal'     => [
				'type' => 'string',
			],
			'page_break_next_button_background_color_normal' => [
				'type' => 'string',
			],
			'page_break_next_button_border_color_normal'   => [
				'type' => 'string',
			],
			'page_break_back_button_text_color_normal'     => [
				'type' => 'string',
			],
			'page_break_back_button_background_color_normal' => [
				'type' => 'string',
			],
			'page_break_back_button_border_color_normal'   => [
				'type' => 'string',
			],
			'page_break_next_button_text_color_hover'      => [
				'type' => 'string',
			],
			'page_break_next_button_background_color_hover' => [
				'type' => 'string',
			],
			'page_break_next_button_border_color_hover'    => [
				'type' => 'string',
			],
			'page_break_back_button_text_color_hover'      => [
				'type' => 'string',
			],
			'page_break_back_button_background_color_hover' => [
				'type' => 'string',
			],
			'page_break_back_button_border_color_hover'    => [
				'type' => 'string',
			],

		];
	}

	/**
	 * Default values for the baseline preset.
	 *
	 * Inherits the common base via `array_merge` and overrides only the
	 * fields that differ from the shared defaults — Baseline's signature
	 * is its bottom-only field border (1.5px on the bottom, 0 elsewhere,
	 * `link: false` so the per-side values stay decoupled) paired with
	 * square corners (radius 0 on all four sides).
	 *
	 * @since 2.10.0
	 * @return array<string, mixed>
	 */
	private function get_baseline_default_values() {
		return array_merge(
			$this->get_common_default_values(),
			[
				'form_theme'                 => 'baseline',
				// Bottom-only field border (overrides the common 1px-all-
				// sides border + 6px corners). `link: false` decouples
				// the per-side values; corners go to 0 to pair naturally
				// with the single-edge border for baseline's sharp,
				// minimal-chrome aesthetic.
				'field_border_width_top'     => 0,
				'field_border_width_right'   => 0,
				'field_border_width_bottom'  => 1.5,
				'field_border_width_left'    => 0,
				'field_border_width_link'    => false,
				'field_border_radius_top'    => 0,
				'field_border_radius_right'  => 0,
				'field_border_radius_bottom' => 0,
				'field_border_radius_left'   => 0,
			]
		);
	}

	/**
	 * Common default values shared by every Pro-shipped preset (Baseline,
	 * Minimal, Dark). Each preset's `get_<preset>_default_values()` is a
	 * thin wrapper that returns
	 * `array_merge( $this->get_common_default_values(), [ … ] )` so the
	 * preset-specific override array stays small and the bulk of the
	 * defaults live in one place.
	 *
	 * Values mirror the starter (Custom) defaults at light-theme JS-side
	 * fallbacks (`#111C44` primary, `#1E1E1E` text, `#FFFFFF` bg / on-
	 * primary, `#dc2626` error). Presets that deviate (Dark especially)
	 * override per-key.
	 *
	 * `form_theme` is intentionally omitted — each preset wrapper sets
	 * its own slug.
	 *
	 * @since 2.10.0
	 * @return array<string, mixed>
	 */
	private function get_common_default_values() {
		return [
			// Background — mirrored into `_srfm_forms_styling.bg_color`
			// by the JS effect so the Background Color picker reflects
			// the active preset's value.
			'bg_color'                                     => '#FFFFFF',
			'bg_type'                                      => 'color',
			// Form-level colour scheme — mirrored into `_srfm_forms_styling`
			// alongside `bg_color`. Values match the JS-side fallbacks the
			// free plugin uses when `_srfm_forms_styling` is empty.
			'primary_color'                                => '#111C44',
			'text_color'                                   => '#1E1E1E',
			'text_color_on_primary'                        => '#FFFFFF',
			'error_color'                                  => '#dc2626',
			'form_row_gap'                                 => 18,
			'form_row_gap_type'                            => 'px',
			'form_column_gap'                              => 16,
			'form_column_gap_type'                         => 'px',
			// Button Properties.
			'button_padding_top'                           => 10,
			'button_padding_right'                         => 14,
			'button_padding_bottom'                        => 10,
			'button_padding_left'                          => 14,
			'button_padding_unit'                          => 'px',
			'button_padding_link'                          => false,
			// Border Width.
			'button_border_style'                          => 'solid',
			'button_border_width_top'                      => 1,
			'button_border_width_right'                    => 1,
			'button_border_width_bottom'                   => 1,
			'button_border_width_left'                     => 1,
			'button_border_width_link'                     => true,
			// Border Radius.
			'button_border_radius_top'                     => 6,
			'button_border_radius_right'                   => 6,
			'button_border_radius_bottom'                  => 6,
			'button_border_radius_left'                    => 6,
			'button_border_radius_unit'                    => 'px',
			'button_border_radius_link'                    => true,
			// Border Color.
			'button_border_color_normal'                   => '',
			'button_border_color_hover'                    => '',
			// Background Normal.
			'button_text_color_normal'                     => '',
			'button_background_color_normal'               => '',
			'button_gradient_type_normal'                  => 'basic',
			'button_background_gradient_type_normal'       => 'linear',
			'button_background_gradient_angle_normal'      => 90,
			'button_background_gradient_color_1_normal'    => '#FFC9B2',
			'button_background_gradient_color_2_normal'    => '#C7CBFF',
			'button_background_gradient_location_1_normal' => 0,
			'button_background_gradient_location_2_normal' => 100,
			// Background Hover.
			'button_text_color_hover'                      => '',
			'button_background_color_hover'                => '',
			'button_gradient_type_hover'                   => 'basic',
			'button_background_gradient_type_hover'        => 'linear',
			'button_background_gradient_angle_hover'       => 90,
			'button_background_gradient_color_1_hover'     => '#FFC9B2',
			'button_background_gradient_color_2_hover'     => '#C7CBFF',
			'button_background_gradient_location_1_hover'  => 0,
			'button_background_gradient_location_2_hover'  => 100,
			// Typography.
			'button_text_size'                             => 16,
			'button_text_size_unit'                        => 'px',
			'button_line_height'                           => 1.5,
			'button_line_height_unit'                      => 'em',
			// Field Properties.
			// Field colour overrides intentionally LEFT EMPTY in the
			// common base. For Baseline / Minimal / Custom these fall
			// through to the free plugin's `text_color`-derived
			// emissions (label = text_color, description = text_color
			// @ 65%, input bg = text_color @ 2%, border = text_color
			// @ 25%, etc.), so the user's Background-panel Text Color
			// edit propagates to every field surface automatically.
			// Dark overrides these with explicit values in
			// `get_dark_default_values()` because its surface palette
			// (input/card layer, white-alpha border, Zinc-500 helper)
			// can't be derived from `text_color`.
			'field_bg_color'                               => '',
			'field_label_color'                            => '',
			'field_help_text_color'                        => '',
			'field_label_size'                             => 16,
			'field_label_size_unit'                        => 'px',
			'field_label_line_height'                      => 1.5,
			'field_label_line_height_unit'                 => 'em',
			'field_help_text_size'                         => 14,
			'field_help_text_size_unit'                    => 'px',
			'field_help_text_line_height'                  => 1.4,
			'field_help_text_line_height_unit'             => 'em',
			'field_border_color'                           => '',
			'field_label_gap'                              => 6,
			'field_label_gap_unit'                         => 'px',
			'field_border_width_top'                       => 1,
			'field_border_width_right'                     => 1,
			'field_border_width_bottom'                    => 1,
			'field_border_width_left'                      => 1,
			'field_border_width_unit'                      => 'px',
			'field_border_width_link'                      => true,
			'field_border_radius_top'                      => 6,
			'field_border_radius_right'                    => 6,
			'field_border_radius_bottom'                   => 6,
			'field_border_radius_left'                     => 6,
			'field_border_radius_unit'                     => 'px',
			'field_border_radius_link'                     => true,
			// Field Box Shadow Properties.
			'field_box_shadow_color_normal'                => '',
			'field_box_shadow_horizontal_offset_normal'    => 0,
			'field_box_shadow_vertical_offset_normal'      => 0,
			'field_box_shadow_blur_normal'                 => 0,
			'field_box_shadow_spread_normal'               => 0,
			'field_box_shadow_position_normal'             => 'outset',
			'field_box_shadow_color_focus'                 => '',
			'field_box_shadow_horizontal_offset_focus'     => 0,
			'field_box_shadow_vertical_offset_focus'       => 0,
			'field_box_shadow_blur_focus'                  => 0,
			'field_box_shadow_spread_focus'                => 3,
			'field_box_shadow_position_focus'              => 'outset',
			// Page Break Button Properties.
			'page_break_next_button_text_color_normal'     => '#FFFFFF',
			'page_break_next_button_background_color_normal' => '#434343',
			'page_break_next_button_border_color_normal'   => '#434343',
			'page_break_back_button_text_color_normal'     => '#FFFFFF',
			'page_break_back_button_background_color_normal' => '#434343',
			'page_break_back_button_border_color_normal'   => '#434343',
			'page_break_next_button_text_color_hover'      => '#FFFFFFCC',
			'page_break_next_button_background_color_hover' => '#434343CC',
			'page_break_next_button_border_color_hover'    => '#434343CC',
			'page_break_back_button_text_color_hover'      => '#FFFFFFCC',
			'page_break_back_button_background_color_hover' => '#434343CC',
			'page_break_back_button_border_color_hover'    => '#434343CC',
		];
	}

	/**
	 * Default values for the minimal preset.
	 *
	 * Inherits the common base via `array_merge` and overrides only the
	 * fields that differ — Minimal currently differs only by its theme
	 * slug, so the override array is `[ 'form_theme' => 'minimal' ]`.
	 *
	 * @since 2.10.0
	 * @return array<string, mixed>
	 */
	private function get_minimal_default_values() {
		return array_merge(
			$this->get_common_default_values(),
			[
				'form_theme' => 'minimal',
			]
		);
	}

	/**
	 * Default values for the dark preset.
	 *
	 * Inherits the common base via `array_merge` and overrides the
	 * colour / surface / focus-glow / page-break entries that diverge
	 * from the light defaults. Override values read from the design
	 * tokens declared at the top of this method (one `$color_*`
	 * variable per Figma `--color-*` custom property) so a token can be
	 * retuned in one place.
	 *
	 * @since 2.10.0
	 * @return array<string, mixed>
	 */
	private function get_dark_default_values() {
		// Design tokens for the Dark preset — single source of truth.
		// Surface palette now anchors on the Tailwind Zinc scale (900
		// container → 800 input → 700 border → 500 helper → 400
		// placeholder → 100 label/text). The canonical `--color-*`
		// reference is mirrored in `sass/presets/_presets.scss` under
		// the `.srfm-preset-dark` scope — keep in sync.
		$color_primary       = '#60A5FA'; // --color-primary
		$color_primary_hover = '#93C5FD'; // --color-primary-hover
		$color_text          = '#F4F4F5'; // --color-text (Zinc-100) — label / input text
		$color_help_text     = '#71717A'; // --color-text-secondary (Zinc-500) — helper text
		// --color-text-on-primary — Dark spec calls for `#FFFFFF`, but
		// the submit button consumes this through the Pro mixin's
		// fallback chain (`color: var(--srfm-button-text-color-normal,
		// var(--srfm-color-scheme-text-on-primary))`) and `#FFFFFF` on
		// `#60A5FA` lands at ~2.4:1 contrast (fails WCAG AA). `#0A0A0A`
		// gives ~8:1 — passes AA comfortably while still tracking any
		// user edits in the Background panel.
		$color_text_on_primary = '#0A0A0A';
		$color_border          = '#3F3F46'; // --color-border (Zinc-700) — solid, visible but not loud
		$color_background      = '#18181B'; // --color-background (Zinc-900) — page / form root
		// --color-input-bg (Zinc-800) — distinct from page bg so fields
		// read as inputs sitting slightly above the dark canvas.
		$color_input_bg = '#27272A';
		$color_error    = '#F87171'; // --color-error
		// Focus ring glow — Primary @ ~22% alpha. Hex 38 → 56/255 ≈ 22%.
		$shadow_focus_color = $color_primary . '38';

		return array_merge(
			$this->get_common_default_values(),
			[
				'form_theme'                               => 'dark',
				// Background, form-level colour scheme, error — all
				// mirrored into `_srfm_forms_styling` by the JS effect
				// so the Background panel pickers reflect Dark's
				// tokens. Free plugin's emission then drives
				// `--srfm-color-scheme-*` and the alpha-derived
				// `--srfm-color-input-*` family from these.
				'bg_color'                                 => $color_background,
				'primary_color'                            => $color_primary,
				'text_color'                               => $color_text,
				'text_color_on_primary'                    => $color_text_on_primary,
				'error_color'                              => $color_error,
				// Field-level Dark surfaces.
				//
				// `field_label_color` and `field_input_color` are
				// INTENTIONALLY LEFT EMPTY — they should track the
				// user's Text Color edit (form-level input). When
				// empty, hooks.php skips emission and the free plugin's
				// `text_color`-derived `--srfm-color-input-{label,text}`
				// applies (Dark's text_color default is `#F4F4F5` via
				// the per-preset mirror, so the default look is the
				// same; editing Text Color now propagates to label /
				// input text live).
				//
				// `field_bg_color`, `field_help_text_color`, and
				// `field_border_color` STAY as explicit Dark tokens
				// because their values (Zinc-800 input layer / Zinc-500
				// helper / Zinc-700 border) can't be derived from
				// `text_color` — they're independent surface choices.
				'field_bg_color'                           => $color_input_bg,
				'field_label_color'                        => '',
				'field_input_color'                        => '',
				'field_help_text_color'                    => $color_help_text,
				'field_border_color'                       => $color_border,
				// Focus ring bloom in --color-primary (per Dark spec
				// "Focus: 1px solid --color-border-focus + --shadow-focus").
				'field_box_shadow_color_focus'             => $shadow_focus_color,
				// `button_background_type_{normal,hover}` flagged
				// 'color' so `Pro_Helper::get_button_background_classes()`
				// emits the `srfm-btn-bg-{color,hover-color}` classes;
				// without them the Pro mixin's background rule wouldn't
				// fire. The colour values themselves stay empty in the
				// common base so the mixin's fallback chain resolves
				// to `--srfm-color-scheme-{primary, text-on-primary}`
				// — i.e. the user's Background-panel values, which
				// Dark seeds to `#60A5FA` and `#0A0A0A`.
				'button_background_type_normal'            => 'color',
				'button_background_type_hover'             => 'color',
				// Page-break buttons get their own concrete fills.
				// Both next and back share the same colours, matching
				// the convention used by the other presets; the Dark
				// spec lifts hover with opaque #93C5FD instead of the
				// alpha dim used elsewhere.
				'page_break_next_button_text_color_normal' => $color_text_on_primary,
				'page_break_next_button_background_color_normal' => $color_primary,
				'page_break_next_button_border_color_normal' => $color_primary,
				'page_break_back_button_text_color_normal' => $color_text_on_primary,
				'page_break_back_button_background_color_normal' => $color_primary,
				'page_break_back_button_border_color_normal' => $color_primary,
				'page_break_next_button_text_color_hover'  => $color_text_on_primary,
				'page_break_next_button_background_color_hover' => $color_primary_hover,
				'page_break_next_button_border_color_hover' => $color_primary_hover,
				'page_break_back_button_text_color_hover'  => $color_text_on_primary,
				'page_break_back_button_background_color_hover' => $color_primary_hover,
				'page_break_back_button_border_color_hover' => $color_primary_hover,
			]
		);
	}
}
