<?php
/**
 * User Presets - Pro Extension.
 *
 * User-created styling presets, complementary to the plugin-shipped
 * presets in `Form_Presets`. Storage is split for frontend perf:
 *
 *   - `srfm_pro_user_presets_index`  (autoload: yes; slug => name)
 *   - `srfm_pro_user_preset_{slug}`  (autoload: no;  full payload)
 *
 * The index is autoloaded once for the dropdown / Manage list; the
 * per-preset option is consulted only when its slug is active on a
 * form, so render cost scales with usage rather than preset count.
 *
 * @package sureforms-pro
 * @since   2.10.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * User Presets class.
 *
 * @since 2.10.0
 */
class User_Presets {
	use Get_Instance;

	/**
	 * REST namespace.
	 *
	 * @since 2.10.0
	 */
	public const REST_NAMESPACE = 'sureforms-pro/v1';

	/**
	 * Index option key (autoload yes, slug => name).
	 *
	 * @since 2.10.0
	 */
	public const INDEX_OPTION = 'srfm_pro_user_presets_index';

	/**
	 * Per-preset option key prefix. Final key is `srfm_pro_user_preset_{slug}`.
	 *
	 * @since 2.10.0
	 */
	public const PRESET_OPTION_PREFIX = 'srfm_pro_user_preset_';

	/**
	 * Per-form working copy meta key written by the editor when a user
	 * preset is the active form theme. Mirrors the base presets'
	 * `_srfm_forms_styling_{slug}` metas.
	 *
	 * @since 2.10.0
	 */
	public const ACTIVE_META = '_srfm_forms_styling_user_active';

	/**
	 * Slugs reserved by plugin-shipped base presets. User presets cannot
	 * be created under these slugs (the UI never offers it, server
	 * rejects defense-in-depth).
	 *
	 * @since 2.10.0
	 */
	public const RESERVED_SLUGS = [ 'default', 'minimal', 'baseline', 'dark', 'custom' ];

	/**
	 * Cron hook used to defer preset propagation for presets in use on
	 * many forms. The REST PUT handler schedules a single event under
	 * this hook so it can return promptly without waiting on N forms'
	 * meta writes.
	 *
	 * @since 2.10.0
	 */
	public const PROPAGATE_HOOK = 'srfm_pro_propagate_user_preset';

	/**
	 * Styling fields that are mirrored between the user-preset global option
	 * and each form's `_srfm_forms_styling` (the free plugin's per-form
	 * background meta). Mirrors the JS `MIRRORED_FIELDS` constant in
	 * `src/admin/user-presets/constants.js`.
	 *
	 * Used by `propagate_preset_to_forms()` to keep per-form metas current
	 * after a global preset update so forms reflect changes without requiring
	 * each form to be re-opened in the editor.
	 *
	 * @since 2.10.0
	 */
	private const MIRRORED_FIELDS = [
		'bg_color',
		'bg_type',
		'bg_gradient',
		'bg_gradient_type',
		'bg_gradient_color_1',
		'bg_gradient_color_2',
		'bg_gradient_location_1',
		'bg_gradient_location_2',
		'bg_gradient_angle',
		'bg_gradient_overlay_type',
		'bg_image_overlay_color',
		'bg_image',
		'bg_image_attachment',
		'bg_image_repeat',
		'bg_image_size',
		'bg_image_size_custom',
		'bg_image_size_custom_unit',
		'primary_color',
		'text_color',
		'text_color_on_primary',
		'submit_button_alignment',
	];

	/**
	 * Form-count threshold above which propagation is deferred to a
	 * scheduled single event instead of running inline in the REST PUT.
	 *
	 * @since 2.10.0
	 */
	private const PROPAGATE_INLINE_LIMIT = 50;

	/**
	 * Hard upper bound on the number of forms a single propagation run will
	 * touch. Guards the (best-effort) meta `LIKE` query from loading an
	 * unbounded set of post IDs into memory on very large installs. Forms
	 * beyond this ceiling pick up the new preset values lazily the next time
	 * they are opened in the editor.
	 *
	 * @since 2.10.0
	 */
	private const MAX_PROPAGATE_FORMS = 5000;

	/**
	 * Constructor — wire actions for REST, meta registration, and the
	 * editor-side localized data.
	 *
	 * @since 2.10.0
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_active_meta' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'localize_to_editor' ], 20 );
		add_action( self::PROPAGATE_HOOK, [ $this, 'propagate_preset_to_forms_handler' ], 10, 1 );
	}

	/**
	 * Register the per-form working-copy meta that holds whichever user
	 * preset is active on the form.
	 *
	 * Permissive schema (no enumerated properties) is intentional —
	 * the canonical schema lives on the global per-preset option and
	 * shape mirrors `Form_Presets::get_common_schema_properties()`. The
	 * working copy is a write-through cache for live preview, so
	 * `sanitize_by_type()` handles validation.
	 *
	 * @since  2.10.0
	 * @hooked srfm_register_additional_post_meta
	 * @return void
	 */
	public function register_active_meta() {
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			self::ACTIVE_META,
			[
				'single'            => true,
				'type'              => 'object',
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => static function( $meta_value ) {
					return Helper::sanitize_by_type( $meta_value );
				},
				'show_in_rest'      => [
					'schema' => [
						'type'                 => 'object',
						'context'              => [ 'edit' ],
						'additionalProperties' => [
							'type' => [ 'string', 'number', 'integer', 'boolean' ],
						],
					],
				],
				'default'           => [],
			]
		);
	}

	/**
	 * Register the REST routes under `sureforms-pro/v1/user-presets`.
	 *
	 * @since  2.10.0
	 * @hooked rest_api_init
	 * @return void
	 */
	public function register_rest_routes() {
		$sureforms_helper = new Helper();

		register_rest_route(
			self::REST_NAMESPACE,
			'/user-presets',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'rest_list' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'rest_create' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
			]
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/user-presets/(?P<slug>[a-z0-9-]+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'rest_get' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'rest_update' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'rest_delete' ],
					'permission_callback' => [ $sureforms_helper, 'get_items_permissions_check' ],
				],
			]
		);
	}

	/**
	 * GET /user-presets — return the index (slug => name).
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_list( $request ) {
		$nonce_check = $this->verify_nonce( $request );
		if ( is_wp_error( $nonce_check ) ) {
			return $nonce_check;
		}
		return new WP_REST_Response( $this->get_index(), 200 );
	}

	/**
	 * GET /user-presets/{slug} — return the full per-preset payload.
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get( $request ) {
		$nonce_check = $this->verify_nonce( $request );
		if ( is_wp_error( $nonce_check ) ) {
			return $nonce_check;
		}
		$slug   = $this->sanitize_slug( $request->get_param( 'slug' ) );
		$preset = $this->get_preset( $slug );
		if ( empty( $preset ) ) {
			return new WP_Error(
				'srfm_preset_not_found',
				__( 'Preset not found.', 'sureforms-pro' ),
				[ 'status' => 404 ]
			);
		}
		return new WP_REST_Response( array_merge( [ 'slug' => $slug ], $preset ), 200 );
	}

	/**
	 * POST /user-presets — create a new preset from the request body.
	 *
	 * Body: `{ name: string, base_preset: string, styles: object }`.
	 * Generates a unique slug from the name (sanitize_title + collision
	 * suffix, rejecting reserved base slugs).
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_create( $request ) {
		$nonce_check = $this->verify_nonce( $request );
		if ( is_wp_error( $nonce_check ) ) {
			return $nonce_check;
		}

		$name = is_string( $request->get_param( 'name' ) )
			? trim( sanitize_text_field( $request->get_param( 'name' ) ) )
			: '';
		if ( '' === $name || mb_strlen( $name ) > 60 ) {
			return new WP_Error(
				'srfm_invalid_name',
				__( 'Preset name must be between 1 and 60 characters.', 'sureforms-pro' ),
				[ 'status' => 400 ]
			);
		}

		// Defense in depth — the JS UI also blocks duplicate names before
		// dispatch, but a direct REST call could bypass that check.
		if ( $this->is_duplicate_name( $name ) ) {
			return new WP_Error(
				'srfm_duplicate_name',
				__( 'A preset with this name already exists. Please choose a different name.', 'sureforms-pro' ),
				[ 'status' => 409 ]
			);
		}

		$base_preset_raw = $request->get_param( 'base_preset' );
		$base_preset     = is_string( $base_preset_raw ) ? sanitize_key( $base_preset_raw ) : '';
		if ( ! in_array( $base_preset, self::RESERVED_SLUGS, true ) ) {
			return new WP_Error(
				'srfm_invalid_base_preset',
				__( 'Unknown base preset.', 'sureforms-pro' ),
				[ 'status' => 400 ]
			);
		}

		$slug = $this->generate_unique_slug( $name );
		if ( '' === $slug ) {
			return new WP_Error(
				'srfm_invalid_name',
				__( 'Preset name must contain at least one letter or number.', 'sureforms-pro' ),
				[ 'status' => 400 ]
			);
		}

		$styles = $request->get_param( 'styles' );
		// Route through the SAME sanitizer the shipped presets use so user
		// presets get the CSS-metacharacter strip (`;}{*<>`) on top of the
		// type coercion. These values are emitted into an inline `<style>`
		// block where `esc_html()` does NOT strip those characters, so without
		// this a manage_options user could inject CSS. See
		// Form_Presets::sanitize_preset_meta().
		$styles = is_array( $styles ) ? Form_Presets::sanitize_preset_meta( $styles ) : [];
		$styles = is_array( $styles ) ? $styles : [];

		$now    = gmdate( 'c' );
		$preset = [
			'name'             => $name,
			'base_preset'      => $base_preset,
			'is_custom_preset' => true,
			'styles'           => $styles,
			'created_at'       => $now,
			'updated_at'       => $now,
		];

		// Re-confirm slug uniqueness immediately before writing. generate_unique_slug()
		// and the index write below are not atomic, so a concurrent create could have
		// claimed this slug in the gap. If so, regenerate from the freshest index.
		if ( ! empty( $this->get_preset( $slug ) ) || isset( $this->get_index()[ $slug ] ) ) {
			$slug = $this->generate_unique_slug( $name );
			if ( '' === $slug ) {
				return new WP_Error(
					'srfm_invalid_name',
					__( 'Preset name must contain at least one letter or number.', 'sureforms-pro' ),
					[ 'status' => 400 ]
				);
			}
		}

		update_option( self::PRESET_OPTION_PREFIX . $slug, $preset, false );

		$index          = $this->get_index();
		$index[ $slug ] = $name;
		$this->save_index( $index );

		return new WP_REST_Response( array_merge( [ 'slug' => $slug ], $preset ), 201 );
	}

	/**
	 * PUT /user-presets/{slug} — update name and/or styles.
	 *
	 * Slug is immutable so forms referencing the preset never lose their
	 * link. Only `name` and `styles` may be patched.
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_update( $request ) {
		$nonce_check = $this->verify_nonce( $request );
		if ( is_wp_error( $nonce_check ) ) {
			return $nonce_check;
		}

		$slug   = $this->sanitize_slug( $request->get_param( 'slug' ) );
		$preset = $this->get_preset( $slug );
		if ( empty( $preset ) ) {
			return new WP_Error(
				'srfm_preset_not_found',
				__( 'Preset not found.', 'sureforms-pro' ),
				[ 'status' => 404 ]
			);
		}

		$updated = false;

		if ( null !== $request->get_param( 'name' ) ) {
			$name_raw = $request->get_param( 'name' );
			$name     = is_string( $name_raw ) ? trim( sanitize_text_field( $name_raw ) ) : '';
			if ( '' === $name || mb_strlen( $name ) > 60 ) {
				return new WP_Error(
					'srfm_invalid_name',
					__( 'Preset name must be between 1 and 60 characters.', 'sureforms-pro' ),
					[ 'status' => 400 ]
				);
			}
			// Allow rename to the same name (no-op) but reject collision
			// with a different preset.
			if ( $this->is_duplicate_name( $name, $slug ) ) {
				return new WP_Error(
					'srfm_duplicate_name',
					__( 'A preset with this name already exists. Please choose a different name.', 'sureforms-pro' ),
					[ 'status' => 409 ]
				);
			}
			$preset['name'] = $name;
			$index          = $this->get_index();
			$index[ $slug ] = $name;
			$this->save_index( $index );
			$updated = true;
		}

		if ( null !== $request->get_param( 'styles' ) ) {
			$styles = $request->get_param( 'styles' );
			// Same CSS-injection-safe sanitizer as rest_create / shipped presets.
			$sanitized        = is_array( $styles ) ? Form_Presets::sanitize_preset_meta( $styles ) : [];
			$preset['styles'] = is_array( $sanitized ) ? $sanitized : [];
			$updated          = true;
		}

		if ( $updated ) {
			$preset['updated_at'] = gmdate( 'c' );
			update_option( self::PRESET_OPTION_PREFIX . $slug, $preset, false );
			// Push the updated styles to every form that uses this preset so
			// the changes are immediately visible without re-opening each form.
			if ( null !== $request->get_param( 'styles' ) && is_array( $preset['styles'] ) ) {
				$this->propagate_preset_to_forms( $slug, $preset['styles'] );
			}
		}

		return new WP_REST_Response( array_merge( [ 'slug' => $slug ], $preset ), 200 );
	}

	/**
	 * DELETE /user-presets/{slug} — remove both the per-preset option
	 * and the index entry. Reserved base slugs are rejected at the
	 * server (the UI never exposes a Delete on base presets).
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_delete( $request ) {
		$nonce_check = $this->verify_nonce( $request );
		if ( is_wp_error( $nonce_check ) ) {
			return $nonce_check;
		}

		$slug = $this->sanitize_slug( $request->get_param( 'slug' ) );
		if ( in_array( $slug, self::RESERVED_SLUGS, true ) ) {
			return new WP_Error(
				'srfm_reserved_slug',
				__( 'Base presets cannot be deleted.', 'sureforms-pro' ),
				[ 'status' => 403 ]
			);
		}

		$preset = $this->get_preset( $slug );
		if ( empty( $preset ) ) {
			return new WP_Error(
				'srfm_preset_not_found',
				__( 'Preset not found.', 'sureforms-pro' ),
				[ 'status' => 404 ]
			);
		}

		delete_option( self::PRESET_OPTION_PREFIX . $slug );
		$index = $this->get_index();
		unset( $index[ $slug ] );
		$this->save_index( $index );

		return new WP_REST_Response(
			[
				'slug'        => $slug,
				'base_preset' => $preset['base_preset'] ?? 'default',
				'deleted'     => true,
			],
			200
		);
	}

	/**
	 * Localize the index + reserved-slug list onto the form-settings
	 * editor script so the Theme dropdown renders user presets without
	 * waiting on an initial REST round-trip.
	 *
	 * @since  2.10.0
	 * @hooked enqueue_block_editor_assets
	 * @return void
	 */
	public function localize_to_editor() {
		// Pre-localize the active form's user preset (if any) so the
		// editor's `globalPresetCache` can hydrate synchronously on
		// mount, avoiding the ~1s flash where the editor preview renders
		// without preset styles while the REST GET is in flight.
		$active_preset = null;
		$post_id       = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $post_id > 0 ) {
			$starter    = Helper::get_array_value(
				get_post_meta( $post_id, '_srfm_forms_styling_starter', true )
			);
			$form_theme = isset( $starter['form_theme'] )
				? Helper::get_string_value( $starter['form_theme'] )
				: '';
			if ( Pro_Helper::is_user_preset_slug( $form_theme ) ) {
				$bare_slug = Pro_Helper::get_user_preset_bare_slug( $form_theme );
				$preset    = $this->get_preset( $bare_slug );
				if ( ! empty( $preset ) ) {
					$active_preset = [
						'slug'        => $bare_slug,
						'base_preset' => isset( $preset['base_preset'] )
							? Helper::get_string_value( $preset['base_preset'] )
							: 'default',
						'styles'      => isset( $preset['styles'] ) && is_array( $preset['styles'] )
							? $preset['styles']
							: [],
					];
				}
			}
		}

		wp_localize_script(
			SRFM_PRO_SLUG . '-form-settings',
			'srfmProUserPresets',
			[
				'index'         => (object) $this->get_index(),
				'reservedSlugs' => self::RESERVED_SLUGS,
				'activeMetaKey' => self::ACTIVE_META,
				// Active form's user preset payload (slug, base_preset,
				// styles) — present only when the form is currently on a
				// user preset. JS pre-seeds `globalPresetCache` from
				// this so the editor doesn't flash without preset styles
				// on first render.
				'activePreset'  => $active_preset,
				// Default value arrays for each base preset. Consumed by
				// the editor's "Save preset" handler to reset the source
				// base preset's per-form meta back to factory defaults
				// when promoting customisations into a new user preset.
				// Read indirectly via `get_registered_meta_keys()` so we
				// don't depend on `Form_Presets` exposing static methods —
				// each preset's `default` is registered via
				// `register_post_meta` in `Form_Presets::register_preset_metas`
				// (baseline/minimal/dark) and `Hooks::register_starter_post_metas`
				// (custom). By the time `enqueue_block_editor_assets`
				// fires, the action `srfm_register_additional_post_meta`
				// has already run, so these reads are populated.
				'baseDefaults'  => [
					'baseline' => self::read_registered_default( '_srfm_forms_styling_baseline' ),
					'minimal'  => self::read_registered_default( '_srfm_forms_styling_minimal' ),
					'dark'     => self::read_registered_default( '_srfm_forms_styling_dark' ),
					'custom'   => self::read_registered_default( '_srfm_forms_styling_starter' ),
				],
			]
		);
	}

	/**
	 * Read the slug => name index. Always returns an array.
	 *
	 * @since 2.10.0
	 * @return array<string, string>
	 */
	public function get_index() {
		$index = get_option( self::INDEX_OPTION, [] );
		return is_array( $index ) ? $index : [];
	}

	/**
	 * Read the full per-preset payload by slug.
	 *
	 * @since 2.10.0
	 * @param string $slug Bare preset slug (without `user-` prefix).
	 * @return array<string, mixed>
	 */
	public function get_preset( $slug ) {
		if ( '' === $slug ) {
			return [];
		}
		$preset = get_option( self::PRESET_OPTION_PREFIX . $slug, [] );
		return is_array( $preset ) ? $preset : [];
	}

	/**
	 * Cron handler that runs deferred propagation. Re-reads the current
	 * preset styles so the freshest values land on the forms even when
	 * multiple Update clicks queue up.
	 *
	 * @since  2.10.0
	 * @hooked srfm_pro_propagate_user_preset
	 * @param  string $slug Bare preset slug (without `user-` prefix).
	 * @return void
	 */
	public function propagate_preset_to_forms_handler( $slug ) {
		$slug   = $this->sanitize_slug( (string) $slug );
		$preset = $this->get_preset( $slug );
		if ( empty( $preset ) || ! is_array( $preset['styles'] ?? null ) ) {
			return;
		}

		$form_ids = $this->find_forms_using_preset( $slug );
		if ( empty( $form_ids ) ) {
			return;
		}

		// Process in chunks to keep memory bounded on very large sites.
		foreach ( array_chunk( $form_ids, 200 ) as $chunk ) {
			$this->apply_propagation( $slug, $preset['styles'], $chunk );
		}
	}

	/**
	 * Persist the slug => name index, ensuring the option is autoloaded.
	 *
	 * The index is read on the frontend (and editor) for the preset
	 * dropdown / Manage list, so it must be autoloaded. The first write
	 * creates the option explicitly with `autoload = yes`; subsequent
	 * writes go through `update_option()` which preserves that flag.
	 *
	 * @since 2.10.0
	 * @param array<string, string> $index Slug => name map.
	 * @return void
	 */
	private function save_index( array $index ) {
		// add_option() is a no-op (returns false) when the option already
		// exists, so on first creation it locks in autoload = yes, and on
		// every later call update_option() handles the write while keeping
		// the existing autoload setting.
		if ( false === get_option( self::INDEX_OPTION, false ) ) {
			add_option( self::INDEX_OPTION, $index, '', 'yes' );
			return;
		}
		update_option( self::INDEX_OPTION, $index );
	}

	/**
	 * Sanitize a slug pulled from a REST URL parameter.
	 *
	 * @since 2.10.0
	 * @param mixed $raw Raw slug from request.
	 * @return string
	 */
	private function sanitize_slug( $raw ) {
		return sanitize_key( is_string( $raw ) ? $raw : '' );
	}

	/**
	 * Generate a unique slug from a human name. Strategy:
	 *   1. `sanitize_title( $name )` for a baseline slug
	 *   2. if reserved or already in use, append `-2`, `-3`, ...
	 *
	 * Empty result means the name had no slug-able characters; caller
	 * should treat this as an invalid name and return a 400.
	 *
	 * @since 2.10.0
	 * @param string $name Display name.
	 * @return string Unique slug, or empty string when name is unusable.
	 */
	private function generate_unique_slug( $name ) {
		$base = sanitize_title( $name );
		if ( '' === $base ) {
			return '';
		}

		$index    = $this->get_index();
		$existing = array_keys( $index );

		$slug    = $base;
		$counter = 2;
		while (
			in_array( $slug, self::RESERVED_SLUGS, true )
			|| in_array( $slug, $existing, true )
			|| ! empty( get_option( self::PRESET_OPTION_PREFIX . $slug, [] ) )
		) {
			$slug = $base . '-' . $counter;
			$counter++;
		}
		return $slug;
	}

	/**
	 * Case-insensitive check for whether a preset name already exists.
	 *
	 * Used by `rest_create` and `rest_update` to reject duplicates at the
	 * server so a direct REST call cannot bypass the JS dialog's check.
	 *
	 * @since 2.10.0
	 * @param string $name        Display name to test.
	 * @param string $ignore_slug Slug to exclude from the comparison
	 *                            (the preset being renamed — allows no-op rename).
	 * @return bool True when another preset already uses this name.
	 */
	private function is_duplicate_name( $name, $ignore_slug = '' ) {
		$needle = mb_strtolower( $name );
		foreach ( $this->get_index() as $existing_slug => $existing_name ) {
			if ( $existing_slug === $ignore_slug ) {
				continue;
			}
			if ( mb_strtolower( (string) $existing_name ) === $needle ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Verify the `X-WP-Nonce` header on a REST request. Mirrors the
	 * shape used by `Global_Settings::save_global_settings()`.
	 *
	 * @since 2.10.0
	 * @param WP_REST_Request $request Request object.
	 * @return true|WP_Error
	 */
	private function verify_nonce( $request ) {
		$nonce = Helper::get_string_value( $request->get_header( 'X-WP-Nonce' ) );
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			return new WP_Error(
				'srfm_invalid_nonce',
				__( 'Nonce verification failed.', 'sureforms-pro' ),
				[ 'status' => 403 ]
			);
		}
		return true;
	}

	/**
	 * Read the `default` value registered against a post meta key on
	 * `sureforms_form`. Used by `localize_to_editor` to ship base-preset
	 * defaults to the JS "Save preset" handler without forcing
	 * `Form_Presets` to expose its private getters statically.
	 *
	 * @since 2.10.0
	 * @param string $meta_key Post meta key to look up.
	 * @return array<string, mixed>
	 */
	private static function read_registered_default( $meta_key ) {
		$registered = get_registered_meta_keys( 'post', SRFM_FORMS_POST_TYPE );
		$default    = $registered[ $meta_key ]['default'] ?? [];
		return is_array( $default ) ? $default : [];
	}

	/**
	 * Propagate updated preset styles to every form that uses this preset.
	 *
	 * Called by `rest_update` after the global preset option is written.
	 * Two operations per form:
	 *   1. Delete the per-form working copy (`_srfm_forms_styling_user_active`)
	 *      so stale local-edit snapshots no longer override the new global
	 *      preset on the frontend or in the editor.
	 *   2. Sync MIRRORED_FIELDS from the updated preset into the form's
	 *      `_srfm_forms_styling` so the free plugin's frontend CSS-variable
	 *      emission immediately reflects the new preset values without the
	 *      user having to re-open each form in the editor.
	 *
	 * Uses a LIKE pre-filter on the JSON-encoded `_srfm_forms_styling_starter`
	 * meta for efficiency, then confirms with an exact PHP check to avoid
	 * acting on forms where the slug appears only as a substring.
	 *
	 * When the match count exceeds `PROPAGATE_INLINE_LIMIT`, the actual
	 * work is deferred to a `wp_schedule_single_event` under the
	 * `PROPAGATE_HOOK` action so the REST PUT can return promptly. The
	 * deferred handler re-reads the preset's current styles, so a follow-up
	 * Update that lands before the cron fires will simply supersede the
	 * earlier run.
	 *
	 * @since 2.10.0
	 * @param string               $slug   Bare preset slug (without `user-` prefix).
	 * @param array<string, mixed> $styles Full styles array of the updated preset.
	 * @return void
	 */
	private function propagate_preset_to_forms( string $slug, array $styles ): void {
		// Only fetch up to one more than the inline limit: that's enough to
		// decide whether to run inline or defer, without loading thousands of
		// post IDs into memory on large installs. The deferred handler re-runs
		// the lookup uncapped (in chunks) when it fires.
		$form_ids = $this->find_forms_using_preset( $slug, self::PROPAGATE_INLINE_LIMIT + 1 );

		if ( empty( $form_ids ) ) {
			return;
		}

		// Defer to a scheduled event for large fan-out so the REST PUT
		// doesn't block while we update hundreds of forms.
		if ( count( $form_ids ) > self::PROPAGATE_INLINE_LIMIT ) {
			if ( ! wp_next_scheduled( self::PROPAGATE_HOOK, [ $slug ] ) ) {
				wp_schedule_single_event( time() + 1, self::PROPAGATE_HOOK, [ $slug ] );
			}
			return;
		}

		$this->apply_propagation( $slug, $styles, $form_ids );
	}

	/**
	 * Locate every form whose `_srfm_forms_styling_starter.form_theme`
	 * equals `user-{slug}`. Uses a `LIKE` pre-filter (the meta value is
	 * a JSON blob) and is therefore best-effort; the exact-match guard
	 * lives in `apply_propagation` to drop substring false positives.
	 *
	 * @since 2.10.0
	 * @param string $slug  Bare preset slug.
	 * @param int    $limit Max number of IDs to fetch. Pass a small value
	 *                      (e.g. PROPAGATE_INLINE_LIMIT + 1) just to decide
	 *                      inline-vs-defer; pass -1 for the full (capped) set.
	 * @return array<int>
	 */
	private function find_forms_using_preset( string $slug, int $limit = -1 ): array {
		$full_slug = 'user-' . $slug;
		// Never fetch an unbounded set: clamp -1 (or anything over the ceiling)
		// to MAX_PROPAGATE_FORMS so a runaway match can't exhaust memory.
		$per_page = $limit > 0 && $limit < self::MAX_PROPAGATE_FORMS ? $limit : self::MAX_PROPAGATE_FORMS;
		return get_posts(
			[
				'post_type'              => SRFM_FORMS_POST_TYPE,
				'posts_per_page'         => $per_page,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'     => '_srfm_forms_styling_starter',
						'value'   => $full_slug,
						'compare' => 'LIKE',
					],
				],
			]
		);
	}

	/**
	 * Apply preset propagation to a specific set of form ids:
	 *   1. Confirm each form actually uses this preset (LIKE → exact).
	 *   2. Delete the per-form working copy so stale local edits don't
	 *      override the freshly-updated preset.
	 *   3. Merge MIRRORED_FIELDS into `_srfm_forms_styling`.
	 *
	 * @since 2.10.0
	 * @param string               $slug     Bare preset slug.
	 * @param array<string, mixed> $styles   Current preset styles.
	 * @param array<int>           $form_ids Form ids to process.
	 * @return void
	 */
	private function apply_propagation( string $slug, array $styles, array $form_ids ): void {
		$full_slug = 'user-' . $slug;

		// Extract only the mirrored fields present in the new styles.
		$mirrored_updates = [];
		foreach ( self::MIRRORED_FIELDS as $key ) {
			if ( array_key_exists( $key, $styles ) ) {
				$mirrored_updates[ $key ] = $styles[ $key ];
			}
		}

		foreach ( $form_ids as $form_id ) {
			$form_id = (int) $form_id;
			$starter = Helper::get_array_value( get_post_meta( $form_id, '_srfm_forms_styling_starter', true ) );
			if ( ( $starter['form_theme'] ?? '' ) !== $full_slug ) {
				continue; // LIKE matched a substring; not actually this preset.
			}

			// 1. Clear the dirty working copy.
			delete_post_meta( $form_id, self::ACTIVE_META );

			// 2. Sync MIRRORED_FIELDS into _srfm_forms_styling.
			if ( empty( $mirrored_updates ) ) {
				continue;
			}
			$forms_styling = Helper::get_array_value(
				get_post_meta( $form_id, '_srfm_forms_styling', true )
			);
			if ( ! is_array( $forms_styling ) ) {
				$forms_styling = [];
			}
			update_post_meta(
				$form_id,
				'_srfm_forms_styling',
				array_merge( $forms_styling, $mirrored_updates )
			);
		}
	}
}
