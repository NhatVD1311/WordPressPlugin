<?php
/**
 * Field Validation Class file.
 *
 * Handles all field validation for SureForms Pro.
 *
 * @package SureForms Pro
 * @since 1.12.2
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM\Inc\Translatable;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Field Validation Class
 */
class Field_Validation {
	use Get_Instance;

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'srfm_field_validation_data', [ $this, 'prepare_field_validation_data' ], 10, 1 );
		add_filter( 'srfm_block_config', [ $this, 'add_block_config' ], 10, 1 );
		add_filter( 'srfm_validate_form_data', [ $this, 'validate_field_data' ], 10, 1 );
		add_filter( 'srfm_block_config_name_with_id', [ $this, 'validate_field_data_for_pro' ], 10, 2 );
	}

	/**
	 * Normalize field names for validation.
	 *
	 * This function normalizes the field names used in validation to ensure consistency
	 * between the configuration and submitted data. Specifically, it handles the case
	 * where the date-picker block name differs between the configuration and the submitted data.
	 *
	 * @param string $name_with_id The original name with ID from the configuration.
	 * @param array  $block        The block data array.
	 * @return string The normalized name with ID for validation.
	 * @since 2.3.0
	 */
	public function validate_field_data_for_pro( $name_with_id, $block ) {
		$normalized_config_name = $name_with_id;
		if ( 'srfm/date-picker' === $block['blockName'] ) {
			$normalized_config_name = str_replace( 'srfm-date-picker', 'srfm-datepicker', $name_with_id );
		}
		return $normalized_config_name;
	}

	/**
	 * Prepare field validation data by merging uploaded files into form data.
	 *
	 * This function checks if there are any uploaded files in the $_FILES superglobal.
	 * If so, it merges the $_FILES array into the provided $form_data array.
	 * This ensures that file upload fields are included in the validation process.
	 *
	 * Example:
	 * - If $form_data = [ 'field1' => 'value1' ] and $_FILES = [ 'upload1' => [ ... ] ],
	 *   the result will be [ 'field1' => 'value1', 'upload1' => [ ... ] ].
	 *
	 * @param array $form_data The submitted form data.
	 * @return array The merged form data including uploaded files.
	 */
	public function prepare_field_validation_data( $form_data ) {
		// If there are uploaded files, merge them into the form data.
		// Example: $_FILES contains file fields, which are added to $form_data for validation.
		if ( ! empty( $_FILES ) ) {
			$form_data = array_merge( $form_data, $_FILES );
		}

		// Return the merged form data, now including any uploaded files.
		return $form_data;
	}

	/**
	 * Process and add configuration for form blocks.
	 *
	 * Processes block configuration, specifically handling upload field blocks.
	 * Validates and extracts relevant attributes from the block and returns a processed
	 * configuration array.
	 *
	 * @param array $block {
	 *     Block data array.
	 *     @type array $block {
	 *         The actual block data.
	 *         @type string $blockName The name of the block.
	 *         @type array  $attrs     Block attributes.
	 *     }
	 * }
	 * @return array|null Returns processed block config array or null if not processed
	 * @since 1.12.2
	 */
	public function add_block_config( $block ) {
		if ( ! isset( $block['block'] ) || ! is_array( $block['block'] ) ) {
			return null;
		}

		$block = $block['block'];

		if ( ! isset( $block['blockName'] ) || ! isset( $block['attrs'] ) ) {
			return null;
		}

		$block_name  = sanitize_text_field( $block['blockName'] );
		$block_attrs = $block['attrs'];

		$processed_value = [];

		// Example: If the block is an upload field, extract and validate its configuration.
		if ( 'srfm/upload' === $block_name ) {
			// Extract and validate upload field configuration attributes.
			$is_required     = isset( $block_attrs['required'] ) ? (bool) $block_attrs['required'] : false;
			$is_multiple     = isset( $block_attrs['multiple'] ) ? (bool) $block_attrs['multiple'] : false;
			$file_size_limit = isset( $block_attrs['fileSizeLimit'] ) ? absint( $block_attrs['fileSizeLimit'] ) : 10;
			$allowed_formats = isset( $block_attrs['allowedFormats'] ) && is_array( $block_attrs['allowedFormats'] )
				? $block_attrs['allowedFormats']
				: [];
			$max_files       = isset( $block_attrs['maxFiles'] ) ? absint( $block_attrs['maxFiles'] ) : 2;
			$slug            = isset( $block_attrs['slug'] ) ? sanitize_text_field( $block_attrs['slug'] ) : '';
			$block_id        = isset( $block_attrs['block_id'] ) ? sanitize_text_field( $block_attrs['block_id'] ) : '';
			$protect_file    = isset( $block_attrs['protectFile'] ) ? (bool) $block_attrs['protectFile'] : false;
			$allowed_users   = isset( $block_attrs['allowedUsers'] ) && is_array( $block_attrs['allowedUsers'] )
				? array_map( 'sanitize_text_field', $block_attrs['allowedUsers'] )
				: [];

			// Example: $processed_value will contain all validated and sanitized attributes.
			$processed_value = [
				'blockName'      => $block_name,
				'required'       => $is_required,
				'multiple'       => $is_multiple,
				'fileSizeLimit'  => $file_size_limit,
				'allowedFormats' => $allowed_formats,
				'maxFiles'       => $max_files,
				'slug'           => $slug,
				'block_id'       => $block_id,
				'protectFile'    => $protect_file,
				'allowedUsers'   => $allowed_users,
			];

			// Store isConditionalLogic flag to detect hidden fields during server-side validation.
			// This allows the validation logic to skip fields that are hidden by conditional logic.
			if ( array_key_exists( 'isConditionalLogic', $block_attrs ) ) {
				$processed_value['isConditionalLogic'] = (bool) $block_attrs['isConditionalLogic'];
			}
		}

		// Process signature field configuration.
		if ( 'srfm/signature' === $block_name ) {
			$is_required   = isset( $block_attrs['required'] ) ? (bool) $block_attrs['required'] : false;
			$slug          = isset( $block_attrs['slug'] ) ? sanitize_text_field( $block_attrs['slug'] ) : '';
			$block_id      = isset( $block_attrs['block_id'] ) ? sanitize_text_field( $block_attrs['block_id'] ) : '';
			$protect_file  = isset( $block_attrs['protectFile'] ) ? (bool) $block_attrs['protectFile'] : false;
			$allowed_users = isset( $block_attrs['allowedUsers'] ) && is_array( $block_attrs['allowedUsers'] )
				? array_map( 'sanitize_text_field', $block_attrs['allowedUsers'] )
				: [];

			$processed_value = [
				'blockName'    => $block_name,
				'required'     => $is_required,
				'slug'         => $slug,
				'block_id'     => $block_id,
				'protectFile'  => $protect_file,
				'allowedUsers' => $allowed_users,
			];

			if ( array_key_exists( 'isConditionalLogic', $block_attrs ) ) {
				$processed_value['isConditionalLogic'] = (bool) $block_attrs['isConditionalLogic'];
			}
		}

		// Process hidden field configuration.
		if ( 'srfm/hidden' === $block_name ) {
			$enable_calculation = ! empty( $block_attrs['enableCalculation'] );
			$slug               = isset( $block_attrs['slug'] ) ? sanitize_text_field( $block_attrs['slug'] ) : '';
			$block_id           = isset( $block_attrs['block_id'] ) ? sanitize_text_field( $block_attrs['block_id'] ) : '';

			// defaultValue, calculationFormula and calculationRound are stored so the payment
			// validator can derive the expected amount server-side (a static default value, or a
			// calculation recomputed from the submitted inputs) instead of trusting the value
			// submitted with the request. @since 2.11.1
			// calculationFormula is intentionally stored raw (only type-checked, not sanitized):
			// it is never echoed or eval'd — it is fed solely to the restricted arithmetic parser.
			// calculationRound is stored as null when unset so the validator (like the front end)
			// rounds only when a precision is explicitly configured.
			$processed_value = [
				'blockName'          => $block_name,
				'enableCalculation'  => $enable_calculation,
				'slug'               => $slug,
				'block_id'           => $block_id,
				'defaultValue'       => isset( $block_attrs['defaultValue'] ) ? sanitize_text_field( $block_attrs['defaultValue'] ) : '',
				'calculationFormula' => isset( $block_attrs['calculationFormula'] ) && is_string( $block_attrs['calculationFormula'] ) ? $block_attrs['calculationFormula'] : '',
				'calculationRound'   => isset( $block_attrs['calculationRound'] ) && is_numeric( $block_attrs['calculationRound'] ) ? absint( $block_attrs['calculationRound'] ) : null,
			];
		}

		// Process date-picker field configuration.
		if ( 'srfm/date-picker' === $block_name ) {
			// Extract and validate date-picker field configuration attributes.
			// Each date string in disabledDates is sanitized; non-string entries are discarded.
			$is_required        = isset( $block_attrs['required'] ) ? (bool) $block_attrs['required'] : false;
			$disable_past_dates = isset( $block_attrs['disablePastDates'] ) ? (bool) $block_attrs['disablePastDates'] : false;
			$date_format        = isset( $block_attrs['dateFormat'] ) ? sanitize_text_field( $block_attrs['dateFormat'] ) : 'mm/dd/yyyy';
			$slug               = isset( $block_attrs['slug'] ) ? sanitize_text_field( $block_attrs['slug'] ) : '';
			$block_id           = isset( $block_attrs['block_id'] ) ? sanitize_text_field( $block_attrs['block_id'] ) : '';
			$disabled_dates     = isset( $block_attrs['disabledDates'] ) && is_array( $block_attrs['disabledDates'] )
				? array_values(
					array_filter(
						array_map( 'sanitize_text_field', $block_attrs['disabledDates'] ),
						static function ( $date ) {
							return is_string( $date ) && '' !== $date;
						}
					)
				)
				: [];

			// Store the date-picker configuration for server-side validation.
			$processed_value = [
				'blockName'        => $block_name,
				'required'         => $is_required,
				'disablePastDates' => $disable_past_dates,
				'disabledDates'    => $disabled_dates,
				'dateFormat'       => $date_format,
				'slug'             => $slug,
				'block_id'         => $block_id,
			];

			// Store isConditionalLogic flag to detect hidden fields during server-side validation.
			if ( array_key_exists( 'isConditionalLogic', $block_attrs ) ) {
				$processed_value['isConditionalLogic'] = (bool) $block_attrs['isConditionalLogic'];
			}
		}

		// Process color picker configuration for the free Text field Pro variant.
		if ( 'srfm/input' === $block_name && ! empty( $block_attrs['isColorPicker'] ) ) {
			$slug     = isset( $block_attrs['slug'] ) ? sanitize_text_field( $block_attrs['slug'] ) : '';
			$block_id = isset( $block_attrs['block_id'] ) ? sanitize_text_field( $block_attrs['block_id'] ) : '';

			$processed_value = [
				'blockName'     => $block_name,
				'isColorPicker' => true,
				'slug'          => $slug,
				'block_id'      => $block_id,
			];

			if ( array_key_exists( 'isConditionalLogic', $block_attrs ) ) {
				$processed_value['isConditionalLogic'] = (bool) $block_attrs['isConditionalLogic'];
			}
		}

		// Example: If $processed_value is not empty, return it wrapped in 'processed_value' key.
		if ( ! empty( $processed_value ) ) {
			return [ 'processed_value' => $processed_value ];
		}

		return null;
	}

	/**
	 * Validate upload field data for SureForms.
	 *
	 * This function validates the uploaded file(s) for a given upload field, checking:
	 * - Required field presence (e.g., if a file is required but not uploaded, validation fails)
	 * - Allowed file types (e.g., only jpg, png, pdf, etc. are accepted; 'exe' would be rejected)
	 * - Maximum number of files (e.g., if maxFiles is 2, uploading 3 files will fail)
	 * - Maximum file size (e.g., if fileSizeLimit is 10MB, a 12MB file will fail)
	 *
	 * @param array<mixed> $field_data Field data.
	 * @return array|void
	 */
	public function validate_field_data( $field_data ) {
		// Validate input structure.
		// Example: $field_data must be an array and contain required keys.
		if (
			! is_array( $field_data ) ||
			! isset( $field_data['field_key'], $field_data['field_value'], $field_data['form_config'], $field_data['block_id'], $field_data['name_with_id'], $field_data['field_name'], $field_data['block_slug'] )
		) {
			return $field_data;
		}

		$field_value  = $field_data['field_value'];
		$block_id     = $field_data['block_id'];
		$form_config  = $field_data['form_config'];
		$name_with_id = $field_data['name_with_id'];
		$field_name   = $field_data['field_name'];
		$block_slug   = $field_data['block_slug'];

		// Process upload fields.
		// Example: Only proceed if $field_name is 'srfm-upload'.
		if ( 'srfm-upload' === $field_name ) {
			// form_id comes from the same filter payload (free field-validation.php) and is
			// needed to re-derive the policy from the form's own markup when the stored
			// config is stale — see resolve_upload_config().
			$form_id = isset( $field_data['form_id'] ) ? absint( $field_data['form_id'] ) : 0;

			return $this->validate_upload_field( $field_value, $block_id, $form_config, $name_with_id, $block_slug, $form_id );
		}

		// Process date-picker fields.
		// Example: Only proceed if $field_name is 'srfm-datepicker'.
		if ( 'srfm-datepicker' === $field_name ) {
			return $this->validate_date_picker_field( $field_data, $field_value, $block_id, $form_config, $name_with_id, $block_slug );
		}

		// Process the color picker variant of the free Text field.
		if ( 'srfm-input' === $field_name ) {
			return $this->validate_input_color_picker_field( $field_data, $field_value, $block_id, $form_config, $block_slug );
		}

		// Process hidden fields — only when calculation is enabled, enforce numeric value.
		if ( 'srfm-hidden' === $field_name ) {
			return $this->validate_hidden_field( $field_data, $field_value, $block_id, $form_config, $block_slug );
		}

		return $field_data;
	}

	/**
	 * Validate color picker variant field data.
	 *
	 * @param array<mixed> $field_data  Field data.
	 * @param mixed        $field_value Field value.
	 * @param string       $block_id    Block ID.
	 * @param array<mixed> $form_config Form configuration.
	 * @param string       $block_slug  Block slug.
	 * @return array<mixed>
	 * @since 2.10.0
	 */
	private function validate_input_color_picker_field( $field_data, $field_value, $block_id, $form_config, $block_slug ) {
		if ( ! isset( $form_config[ $block_id ] ) || ! is_array( $form_config[ $block_id ] ) ) {
			return $field_data;
		}

		$get_form_config = $form_config[ $block_id ];

		if ( empty( $get_form_config['isColorPicker'] ) ) {
			return $field_data;
		}

		if ( isset( $get_form_config['slug'] ) && $get_form_config['slug'] !== $block_slug ) {
			return [
				'validated' => false,
				'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
			];
		}

		if ( '' === $field_value || null === $field_value ) {
			return $field_data;
		}

		if ( ! is_string( $field_value ) || ! preg_match( '/^#[0-9A-Fa-f]{6}$/', trim( $field_value ) ) ) {
			return [
				'validated' => false,
				'error'     => __( 'Please add a proper hex color value.', 'sureforms-pro' ),
			];
		}

		return [
			'validated' => true,
			'error'     => '',
		];
	}

	/**
	 * Validate hidden field data.
	 *
	 * When `enableCalculation` is true for the hidden field, the submitted value must be numeric.
	 * Prevents tampering of a calculation-driven hidden input via DevTools/automation.
	 * When calculation is not enabled, hidden fields accept any text (URL params, referrer, etc.).
	 *
	 * Scope note: this enforces that the submitted value *is* a number — not that it matches the
	 * formula result. A payment block that reads this hidden value will still trust the submitted
	 * amount. Value-level tamper defense (recomputing the formula server-side) is out of scope.
	 *
	 * @param array<mixed> $field_data  Field data.
	 * @param mixed        $field_value Field value.
	 * @param string       $block_id    Block ID.
	 * @param array<mixed> $form_config Form configuration keyed by block_id.
	 * @param string       $block_slug  Block slug.
	 *
	 * @since 2.8.3
	 * @return array<string,mixed>
	 */
	private function validate_hidden_field( $field_data, $field_value, $block_id, $form_config, $block_slug ) {
		// No config for this block — nothing to enforce.
		if ( ! isset( $form_config[ $block_id ] ) || ! is_array( $form_config[ $block_id ] ) ) {
			return $field_data;
		}

		$get_form_config = $form_config[ $block_id ];

		// Slug mismatch — fail closed.
		if ( isset( $get_form_config['slug'] ) && $get_form_config['slug'] !== $block_slug ) {
			return [
				'validated' => false,
				'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
			];
		}

		// Calculation not enabled — any value is acceptable here.
		if ( empty( $get_form_config['enableCalculation'] ) ) {
			return [
				'validated' => true,
				'error'     => '',
			];
		}

		// Empty value is acceptable — required-field checks are handled elsewhere.
		if ( '' === $field_value || null === $field_value ) {
			return [
				'validated' => true,
				'error'     => '',
			];
		}

		// Calculation-enabled hidden fields must carry a numeric value.
		if ( ! is_numeric( $field_value ) ) {
			return [
				'validated' => false,
				'error'     => __( 'Hidden field value must be a number.', 'sureforms-pro' ),
			];
		}

		return [
			'validated' => true,
			'error'     => '',
		];
	}

	/**
	 * Validate upload field data.
	 *
	 * @param mixed        $field_value  Field value.
	 * @param string       $block_id     Block ID.
	 * @param array<mixed> $form_config  Form configuration.
	 * @param string       $name_with_id Name with ID.
	 * @param string       $block_slug   Block slug.
	 * @param int          $form_id      The form being submitted.
	 * @return array
	 * @since 2.3.0
	 */
	private function validate_upload_field( $field_value, $block_id, $form_config, $name_with_id, $block_slug, $form_id = 0 ) {
		/*
		 * FAIL CLOSED unless the per-form policy for this exact block id can be PROVEN.
		 *
		 * Returning $field_data leaves no 'validated' key, and the caller (free
		 * field-validation.php) treats a missing key as a PASS. Every early return here
		 * used to do that, so the guard was bypassable three ways:
		 *
		 * - Reuse the block id of any NON-upload field. `isset( $form_config[ $block_id ] )`
		 *   was then true, so the unknown-id rejection was skipped, and the
		 *   `! isset( slug, name_with_id )` return passed instead. That worked on most real
		 *   forms because free's add_block_config() writes `block_name` (underscore) while
		 *   prepared_validation_data() only injects `name_with_id` for entries carrying
		 *   `blockName` (camelCase) — so no free-produced entry (dropdown, multi-choice,
		 *   number, textarea, payment) ever has `name_with_id`.
		 * - Submit to a form with NO config at all. Free deletes the meta entirely when the
		 *   config is empty, so a Text/Email-only contact form had $form_config === [] and
		 *   the guard was skipped. "No config exists" is not "no policy to enforce"; the
		 *   invariant is whether this form has an upload block with this id.
		 * - Post the field without `[]` so PHP makes $_FILES scalars, which skipped the
		 *   type, count and size loops (all gated on is_array) and fell through to a pass.
		 */
		$get_form_config = $this->resolve_upload_config( $form_config, $block_id, $form_id );

		if ( null === $get_form_config ) {
			return [
				'validated' => false,
				'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
			];
		}

		// A non-array upload payload proves nothing, so it is invalid rather than "nothing
		// to check". Today it only fails to become a file because hooks.php mirrors the same
		// shape check and writes '' — the validator itself was fully bypassed.
		if ( ! is_array( $field_value ) ) {
			return [
				'validated' => false,
				'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
			];
		}

		$return_data = [
			'validated' => false,
			'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
		];

		// Verify the slug.
		if ( $get_form_config['slug'] !== $block_slug ) {
			return $return_data;
		}

		// "name_with_id" should be same as $name_with_id.
		// Example: If config's name_with_id is 'upload-123', $name_with_id must also be 'upload-123'.
		if ( $get_form_config['name_with_id'] !== $name_with_id ) {
			return $return_data;
		}

		$is_required     = ! empty( $get_form_config['required'] );
		$is_multiple     = ! empty( $get_form_config['multiple'] );
		$file_size_limit = isset( $get_form_config['fileSizeLimit'] ) ? absint( $get_form_config['fileSizeLimit'] ) : 10;
		$file_size_limit = $file_size_limit * 1024 * 1024; // Convert MB to bytes. Example: 10 => 10485760 bytes.
		$allowed_formats = isset( $get_form_config['allowedFormats'] ) && is_array( $get_form_config['allowedFormats'] ) && ! empty( $get_form_config['allowedFormats'] )
			? $get_form_config['allowedFormats']
			: [
				[
					'value' => 'jpg',
					'label' => 'jpg',
				],
				[
					'value' => 'jpeg',
					'label' => 'jpeg',
				],
				[
					'value' => 'gif',
					'label' => 'gif',
				],
				[
					'value' => 'png',
					'label' => 'png',
				],
				[
					'value' => 'pdf',
					'label' => 'pdf',
				],
			];

		$max_files = isset( $get_form_config['maxFiles'] ) ? absint( $get_form_config['maxFiles'] ) : 1;

		// Check for required field.
		// Example: If required and no file uploaded, return error.
		if ( $is_required && empty( $get_form_config['isConditionalLogic'] ) ) {
			if ( ! isset( $field_value['name'] ) || ! is_array( $field_value['name'] ) || empty( $field_value['name'][0] ) ) {
				return [
					'validated' => false,
					'error'     => Helper::get_common_err_msg()['required'],
				];
			}
		}

		// Validate file types.
		$allowed_file_types = Pro_Helper::get_normalized_file_types();

		// Extract allowed extensions from the form configuration.
		$allowed_extensions = [];
		foreach ( $allowed_formats as $format ) {
			if ( is_array( $format ) && isset( $format['value'] ) ) {
				$allowed_extensions[] = strtolower( $format['value'] );
			} elseif ( is_string( $format ) ) {
				$allowed_extensions[] = strtolower( $format );
			}
		}

		// Filter MIME types based on allowed extensions from form config.
		$allowed_mimes = [];
		foreach ( $allowed_extensions as $ext ) {
			if ( isset( $allowed_file_types[ $ext ] ) && is_array( $allowed_file_types[ $ext ] ) ) {
				$allowed_mimes = array_merge( $allowed_mimes, $allowed_file_types[ $ext ] );
			}
		}

		// Validate the EXTENSION first, independently of the MIME type.
		//
		// $field_value['type'] is $_FILES[...]['type'] — the client's multipart Content-Type
		// header, which PHP never derives and never verifies. Checking only that made the
		// per-form allowedFormats restriction decorative: an upload block limited to jpg
		// accepted payload.zip sent as `Content-Type: image/jpeg`, and downstream
		// wp_check_filetype_and_ext() then validated `.zip` against WordPress's GLOBAL mime
		// list and wrote it. The extension is part of the name the file is stored under, so
		// it is the property the per-form policy actually needs to constrain. The MIME check
		// below remains as an additional condition, not an alternative.
		if ( ! empty( $allowed_extensions ) && isset( $field_value['name'] ) && is_array( $field_value['name'] ) ) {
			foreach ( $field_value['name'] as $upload_name ) {
				if ( ! is_string( $upload_name ) || '' === $upload_name ) {
					continue;
				}

				$upload_ext = strtolower( pathinfo( $upload_name, PATHINFO_EXTENSION ) );

				if ( '' === $upload_ext || ! in_array( $upload_ext, $allowed_extensions, true ) ) {
					return [
						'validated' => false,
						'error'     => Translatable::dynamic_validation_messages()['srfm_file_type_not_allowed'],
					];
				}
			}
		}

		// Validate file types using MIME type checking.
		// Fall back to extension check for non-standard MIME types (e.g. application/octet-stream for STL).
		if ( ! empty( $field_value['type'] ) && is_array( $field_value['type'] ) ) {
			foreach ( $field_value['type'] as $idx => $file_type ) {
				// Skip if no file uploaded.
				if ( empty( $file_type ) ) {
					continue;
				}

				// Check if the file type is allowed by validating against MIME types.
				if ( ! is_string( $file_type ) || ! in_array( $file_type, $allowed_mimes, true ) ) {
					// Only fall back to extension check for extra MIME types (e.g. STL, ZIP)
					// where browsers may send generic MIME types like application/octet-stream.
					$ext_valid   = false;
					$extra_mimes = Pro_Helper::get_extra_mimes();
					if ( ! empty( $field_value['name'][ $idx ] ) && is_string( $field_value['name'][ $idx ] ) ) {
						$ext = strtolower( pathinfo( $field_value['name'][ $idx ], PATHINFO_EXTENSION ) );
						if ( $ext && isset( $extra_mimes[ $ext ] ) && in_array( $ext, $allowed_extensions, true ) ) {
							$ext_valid = true;
						}
					}
					if ( ! $ext_valid ) {
						return [
							'validated' => false,
							'error'     => Translatable::dynamic_validation_messages()['srfm_file_type_not_allowed'],
						];
					}
				}
			}
		}

		// Validate multiple files.
		// Example: If not multiple and more than one file uploaded, return error.
		if (
			isset( $field_value['name'] ) &&
			is_array( $field_value['name'] ) &&
			! $is_multiple &&
			count( $field_value['name'] ) > 1
		) {
			return [
				'validated' => false,
				'error'     => sprintf( Translatable::dynamic_validation_messages()['srfm_file_upload_limit'], 1 ),
			];
		}

		// Validate max files.
		// Example: If maxFiles is 2 and 3 files uploaded, return error.
		if (
			isset( $field_value['name'] ) &&
			is_array( $field_value['name'] ) &&
			$max_files < count( $field_value['name'] )
		) {
			return [
				'validated' => false,
				'error'     => sprintf( Translatable::dynamic_validation_messages()['srfm_file_upload_limit'], $max_files ),
			];
		}

		// Validate file sizes.
		// Example: If fileSizeLimit is 10MB and a file is 12MB, return error.
		if (
			! empty( $field_value['size'] ) &&
			is_array( $field_value['size'] )
		) {
			foreach ( $field_value['size'] as $file_size ) {
				if ( $file_size_limit < $file_size ) {
					$convert_to_mb = $file_size / 1024 / 1024;
					return [
						'validated' => false,
						'error'     => sprintf( Translatable::dynamic_validation_messages()['srfm_file_size_exceed'], $convert_to_mb ),
					];
				}
			}
		}

		return [
			'validated' => true,
			'error'     => '',
		];
	}

	/**
	 * Validate date-picker field data.
	 *
	 * Checks all server-side date restrictions: disabled specific dates and
	 * the "Disable Past Dates" setting. Both restrictions are enforced independently
	 * so that bypassing one does not silently disable the other.
	 *
	 * @param array<mixed> $field_data   Field data.
	 * @param mixed        $field_value  Field value (the submitted date string).
	 * @param string       $block_id     Block ID.
	 * @param array<mixed> $form_config  Form configuration.
	 * @param string       $name_with_id Name with ID.
	 * @param string       $block_slug   Block slug.
	 * @return array Validation result with 'validated' and 'error' keys.
	 * @since 2.3.0
	 */
	private function validate_date_picker_field( $field_data, $field_value, $block_id, $form_config, $name_with_id, $block_slug ) {
		// Validate that the block config exists.
		if ( ! isset( $form_config[ $block_id ] ) ) {
			return $field_data;
		}

		$get_form_config = $form_config[ $block_id ];

		// Validate that config is an array.
		if ( ! is_array( $get_form_config ) ) {
			return $field_data;
		}

		// Validate config structure.
		if ( ! isset( $get_form_config['slug'] ) || ! isset( $get_form_config['name_with_id'] ) ) {
			return $field_data;
		}

		$return_data = [
			'validated' => false,
			'error'     => __( 'Field is not valid.', 'sureforms-pro' ),
		];

		// Verify the slug matches.
		if ( $get_form_config['slug'] !== $block_slug ) {
			return $return_data;
		}

		// Verify name_with_id matches.
		if ( $get_form_config['name_with_id'] !== $name_with_id ) {
			return $return_data;
		}

		$disable_past_dates = ! empty( $get_form_config['disablePastDates'] );
		$disabled_dates     = isset( $get_form_config['disabledDates'] ) && is_array( $get_form_config['disabledDates'] )
			? $get_form_config['disabledDates']
			: [];

		// If no date restrictions are configured, the field is valid.
		if ( ! $disable_past_dates && empty( $disabled_dates ) ) {
			return [
				'validated' => true,
				'error'     => '',
			];
		}

		// If the field is hidden by conditional logic, skip validation.
		if ( ! empty( $get_form_config['isConditionalLogic'] ) ) {
			return [
				'validated' => true,
				'error'     => '',
			];
		}

		// If field value is empty, it's valid (required validation is handled separately).
		if ( empty( $field_value ) || ! is_string( $field_value ) ) {
			return [
				'validated' => true,
				'error'     => '',
			];
		}

		// Get the date format from configuration (defaults to mm/dd/yyyy for backward compatibility).
		$date_format = $get_form_config['dateFormat'] ?? 'mm/dd/yyyy';

		// Map the frontend date format to PHP DateTime format.
		$format_map = [
			'mm/dd/yyyy' => 'm/d/Y',
			'dd/mm/yyyy' => 'd/m/Y',
			'yyyy/mm/dd' => 'Y/m/d',
		];

		$php_date_format = isset( $format_map[ strtolower( $date_format ) ] )
			? $format_map[ strtolower( $date_format ) ]
			: 'm/d/Y';

		// Create DateTime object from the submitted value using the detected format.
		$date_obj = \DateTime::createFromFormat( $php_date_format, $field_value );

		// Validate that the date was parsed correctly and matches the expected format.
		// This also catches invalid dates like 31/02/2024.
		if ( false === $date_obj || $date_obj->format( $php_date_format ) !== $field_value ) {
			return [
				'validated' => false,
				'error'     => __( 'Invalid date format.', 'sureforms-pro' ),
			];
		}

		// Check if the submitted date matches a specifically disabled date.
		// Normalize to Y/m/d (matches the format stored by the block editor via getFormattedDate).
		if ( ! empty( $disabled_dates ) ) {
			$normalized_date = $date_obj->format( 'Y/m/d' );
			if ( in_array( $normalized_date, $disabled_dates, true ) ) {
				return [
					'validated' => false,
					'error'     => __( 'This date is not available. Please select a different date.', 'sureforms-pro' ),
				];
			}
		}

		// Check if the submitted date is in the past (only when that restriction is enabled).
		if ( $disable_past_dates ) {
			// Normalize to midnight for a day-level comparison.
			$submitted_date_timestamp = $date_obj->setTime( 0, 0, 0 )->getTimestamp();
			$today                    = current_datetime()->setTime( 0, 0, 0 )->getTimestamp();

			if ( $submitted_date_timestamp < $today ) {
				return [
					'validated' => false,
					'error'     => __( 'Past dates are not allowed. Please select today or a future date.', 'sureforms-pro' ),
				];
			}
		}

		// All checks passed.
		return [
			'validated' => true,
			'error'     => '',
		];
	}

	/**
	 * Resolve the per-form upload policy for a block id, or null when it cannot be proven.
	 *
	 * Callers must treat null as a rejection. Returning null rather than a permissive
	 * default is the whole point: the stored config is not a trustworthy allowlist on its
	 * own, because a submitted block id may name a non-upload field or a form whose config
	 * was never built.
	 *
	 * @param array<mixed>|mixed $form_config Stored block config for the form.
	 * @param string|mixed       $block_id    Block id taken from the submitted field key.
	 * @param int                $form_id     The form being submitted.
	 * @since 2.12.3
	 * @return array<mixed>|null Proven upload config, or null.
	 */
	private function resolve_upload_config( $form_config, $block_id, $form_id ) {
		if ( is_array( $form_config ) && isset( $form_config[ $block_id ] ) && is_array( $form_config[ $block_id ] ) ) {
			$cfg = $form_config[ $block_id ];

			// Must actually be an upload block. Without this an upload can be posted under
			// a signature or date-picker block id; those reject today only because the
			// name_with_id comparison happens to fail, which is a coincidence to rely on.
			if ( 'srfm/upload' !== ( $cfg['blockName'] ?? '' ) ) {
				return null;
			}

			// A genuine upload entry always carries both, since Pro writes camelCase
			// `blockName` and free's prepared_validation_data() therefore injects
			// name_with_id. Absence means this is not a usable upload policy.
			if ( ! isset( $cfg['slug'], $cfg['name_with_id'] ) ) {
				return null;
			}

			return $cfg;
		}

		return $this->build_upload_config_from_markup( $form_id, $block_id );
	}

	/**
	 * Re-derive an upload block's policy from the form's own markup.
	 *
	 * Covers the case where the stored config is stale rather than absent: a form last
	 * saved while Pro was inactive has entries for the free blocks but none for the upload
	 * block, and free's get_or_migrate_block_config_for_legacy_form() short-circuits on a
	 * non-empty config so it never re-migrates. Without this, failing closed would reject
	 * every upload on such a form with no diagnostic until an admin re-saves it.
	 *
	 * The markup is authoritative and server-side, so deriving from it enforces the real
	 * policy rather than waiving it.
	 *
	 * @param int          $form_id  The form being submitted.
	 * @param string|mixed $block_id Block id taken from the submitted field key.
	 * @since 2.12.3
	 * @return array<mixed>|null Config derived from markup, or null when no such block exists.
	 */
	private function build_upload_config_from_markup( $form_id, $block_id ) {
		$form_id  = absint( $form_id );
		$block_id = is_string( $block_id ) ? $block_id : '';

		if ( $form_id <= 0 || '' === $block_id || ! function_exists( 'parse_blocks' ) ) {
			return null;
		}

		$post = get_post( $form_id );

		if ( ! $post instanceof \WP_Post || SRFM_FORMS_POST_TYPE !== $post->post_type || '' === $post->post_content ) {
			return null;
		}

		$block = $this->find_upload_block( parse_blocks( $post->post_content ), $block_id );

		if ( null === $block ) {
			// No upload block with this id exists on this form, so nothing may be uploaded
			// against it — regardless of what the stored config does or does not say.
			return null;
		}

		$built = $this->add_block_config( [ 'block' => $block ] );
		$cfg   = is_array( $built ) && isset( $built['processed_value'] ) && is_array( $built['processed_value'] )
			? $built['processed_value']
			: null;

		if ( null === $cfg || 'srfm/upload' !== ( $cfg['blockName'] ?? '' ) || ! isset( $cfg['slug'] ) ) {
			return null;
		}

		// free's prepared_validation_data() builds this from the block name and id; the
		// same derivation applies here since both inputs are known.
		$cfg['name_with_id'] = str_replace( '/', '-', 'srfm/upload' ) . '-' . $block_id;

		return $cfg;
	}

	/**
	 * Find an `srfm/upload` block by its block id, recursing into inner blocks and
	 * expanding `core/block` reusable/synced pattern references.
	 *
	 * The pattern expansion mirrors free's get_known_field_block_ids(), which walks the
	 * same tree for the same reason. Without it a form whose upload field lives inside a
	 * synced pattern resolves to null here, and validate_upload_field() — which fails
	 * CLOSED as of 2.12.3 — rejects every upload with "Field is not valid.". A cycle
	 * guard on the reference ids prevents infinite recursion between patterns.
	 *
	 * @param array<mixed>|mixed $blocks   Parsed blocks.
	 * @param string             $block_id Block id to find.
	 * @param array<int,true>    $visited  Reference ids already expanded (cycle guard).
	 * @since 2.12.3
	 * @return array<mixed>|null The matching block, or null.
	 */
	private function find_upload_block( $blocks, $block_id, &$visited = [] ) {
		if ( ! is_array( $blocks ) ) {
			return null;
		}

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_name = $block['blockName'] ?? '';
			$attrs      = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];

			if (
				'srfm/upload' === $block_name
				&& isset( $attrs['block_id'] )
				&& is_string( $attrs['block_id'] )
				&& $attrs['block_id'] === $block_id
			) {
				return $block;
			}

			// Expand a reusable/synced pattern into its wp_block post.
			if ( 'core/block' === $block_name && ! empty( $attrs['ref'] ) && is_scalar( $attrs['ref'] ) ) {
				$ref = absint( $attrs['ref'] );

				if ( $ref > 0 && ! isset( $visited[ $ref ] ) ) {
					$visited[ $ref ] = true;
					$ref_post        = get_post( $ref );

					if ( $ref_post instanceof \WP_Post && ! empty( $ref_post->post_content ) ) {
						$found = $this->find_upload_block( parse_blocks( $ref_post->post_content ), $block_id, $visited );

						if ( null !== $found ) {
							return $found;
						}
					}
				}
			}

			// Upload blocks can sit inside containers, columns or a repeater.
			if ( ! empty( $block['innerBlocks'] ) ) {
				$found = $this->find_upload_block( $block['innerBlocks'], $block_id, $visited );

				if ( null !== $found ) {
					return $found;
				}
			}
		}

		return null;
	}
}
