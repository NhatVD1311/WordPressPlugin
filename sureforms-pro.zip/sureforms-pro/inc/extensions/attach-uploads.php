<?php
/**
 * Attach Uploads Class.
 *
 * Adds per-field upload attachment selection to email notifications.
 * Stores configuration in a separate meta (_srfm_email_attach_uploads_meta)
 * using the notification ID as a foreign key — matching the conditional-emails pattern.
 *
 * @package sureforms-pro.
 * @since 2.8.0
 */

namespace SRFM_Pro\Inc\Extensions;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\File_Upload;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Attach_Uploads Class.
 *
 * @since 2.8.0
 */
class Attach_Uploads {
	use Get_Instance;

	/**
	 * Meta key for storing attach uploads configuration.
	 *
	 * @since 2.8.0
	 */
	public const META_KEY = '_srfm_email_attach_uploads_meta';

	/**
	 * Class constructor.
	 *
	 * @return void
	 * @since 2.8.0
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_post_metas' ] );
		add_action( 'srfm_before_email_send', [ $this, 'maybe_attach_uploads' ], 10, 4 );
	}

	/**
	 * Registers the attach uploads meta.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function register_post_metas() {
		register_post_meta(
			'sureforms_form',
			self::META_KEY,
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'sanitize_callback' => [ $this, 'sanitize_attach_uploads_data' ],
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
			]
		);
	}

	/**
	 * Sanitize the attach uploads meta data.
	 *
	 * @param string $data The raw data to sanitize.
	 * @since 2.8.0
	 * @return string Sanitized JSON string.
	 */
	public function sanitize_attach_uploads_data( $data ) {
		if ( empty( $data ) || ! is_string( $data ) ) {
			return strval( wp_json_encode( [] ) );
		}

		$decoded = json_decode( $data, true );
		if ( ! is_array( $decoded ) ) {
			return strval( wp_json_encode( [] ) );
		}

		$sanitized = [];
		foreach ( $decoded as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
				continue;
			}

			$entry = [
				'id'                   => absint( $item['id'] ),
				'attach_uploads'       => ! empty( $item['attach_uploads'] ),
				'attach_upload_fields' => [],
			];

			if ( ! empty( $item['attach_upload_fields'] ) && is_array( $item['attach_upload_fields'] ) ) {
				$entry['attach_upload_fields'] = array_values(
					array_filter(
						array_map( 'sanitize_text_field', $item['attach_upload_fields'] ),
						static function ( $v ) {
							return 1 === preg_match( '/^[a-f0-9]{8}$/', $v );
						}
					)
				);
			}

			$sanitized[] = $entry;
		}

		return strval( wp_json_encode( $sanitized ) );
	}

	/**
	 * Enqueue Admin Scripts.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function enqueue_admin_scripts() {
		$script = [
			'unique_file'        => 'srfmAttachUploads',
			'unique_handle'      => 'srfm-attach-uploads',
			'extra_dependencies' => [],
		];

		$script_dep_path = SRFM_PRO_DIR . 'dist/' . $script['unique_file'] . '.asset.php';
		$script_dep_data = file_exists( $script_dep_path )
			? include $script_dep_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];
		$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $script['unique_handle'],
			SRFM_PRO_URL . 'dist/' . $script['unique_file'] . '.js',
			$script_dep,
			$script_dep_data['version'],
			true
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
	}

	/**
	 * Collect and inject file attachments into the upcoming wp_mail() call.
	 *
	 * Hooked to `srfm_before_email_send` which fires immediately before wp_mail().
	 * Reads the separate meta by notification ID and sets up a one-time wp_mail
	 * filter to inject attachments.
	 *
	 * @param array<string,string> $parsed          Parsed email data.
	 * @param array<mixed>         $submission_data Form submission data.
	 * @param array<mixed>         $item            Email notification configuration.
	 * @param array<mixed>         $form_data       Form context data (must contain 'form-id' key).
	 * @since 2.8.0
	 * @return void
	 */
	public function maybe_attach_uploads( $parsed, $submission_data, $item, $form_data ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundBeforeLastUsed -- $parsed required by action signature.
		$form_id         = absint( $form_data['form-id'] ?? 0 );
		$notification_id = isset( $item['id'] ) && is_numeric( $item['id'] ) ? intval( $item['id'] ) : 0;

		if ( ! $form_id || ! $notification_id ) {
			return;
		}

		// Read the separate meta.
		$raw  = get_post_meta( $form_id, self::META_KEY, true );
		$meta = is_string( $raw ) ? json_decode( $raw, true ) : [];

		if ( ! is_array( $meta ) ) {
			return;
		}

		// Find config by notification ID (foreign key).
		$config = null;
		foreach ( $meta as $entry ) {
			if ( is_array( $entry ) && isset( $entry['id'] ) && intval( $entry['id'] ) === $notification_id ) {
				$config = $entry;
				break;
			}
		}

		if ( ! $config || empty( $config['attach_uploads'] ) ) {
			return;
		}

		$selected_block_ids = ! empty( $config['attach_upload_fields'] ) && is_array( $config['attach_upload_fields'] )
			? $config['attach_upload_fields']
			: [];

		$attachments = $this->get_email_attachments( $submission_data, $selected_block_ids, $form_id );

		if ( empty( $attachments ) ) {
			return;
		}

		// Initialize as no-op for cross-referencing; reassigned to the real closure below.
		$cleanup_callback = static function ( $should_send ) {
			return $should_send;
		};

		// One-time wp_mail filter to inject attachments.
		$filter_callback = static function ( $args ) use ( &$filter_callback, &$cleanup_callback, $attachments ) {
			$args['attachments'] = array_merge(
				is_array( $args['attachments'] ) ? $args['attachments'] : [],
				$attachments
			);
			remove_filter( 'wp_mail', $filter_callback, 99 );
			remove_filter( 'srfm_should_send_email', $cleanup_callback, 999 );
			return $args;
		};

		add_filter( 'wp_mail', $filter_callback, 99 );

		// Cleanup: remove wp_mail filter if sending is suppressed (e.g. by conditional-emails).
		$cleanup_callback = static function ( $should_send, $notif_id ) use ( &$filter_callback, &$cleanup_callback, $notification_id ) {
			if ( intval( $notif_id ) === $notification_id ) {
				if ( ! wp_validate_boolean( $should_send ) ) {
					remove_filter( 'wp_mail', $filter_callback, 99 );
				}
				remove_filter( 'srfm_should_send_email', $cleanup_callback, 999 );
			}
			return $should_send;
		};
		add_filter( 'srfm_should_send_email', $cleanup_callback, 999, 2 );
	}

	/**
	 * Extract validated file paths from upload field submission data.
	 *
	 * @param array<mixed>  $submission_data    Form submission data.
	 * @param array<string> $selected_block_ids Block IDs to include (empty = all).
	 * @param int           $form_id            Current form ID for ownership validation.
	 * @since 2.8.0
	 * @return array<string> Validated absolute file paths.
	 */
	private function get_email_attachments( $submission_data, $selected_block_ids = [], $form_id = 0 ) {
		if ( empty( $submission_data ) || ! is_array( $submission_data ) ) {
			return [];
		}

		// Build allowed upload directories for containment check.
		$upload_dir   = wp_upload_dir();
		$allowed_dirs = [];
		foreach ( [ '/sureforms', '/sureforms-private' ] as $subdir ) {
			$resolved = realpath( $upload_dir['basedir'] . $subdir );
			if ( false !== $resolved ) {
				$allowed_dirs[] = $resolved;
			}
		}

		if ( empty( $allowed_dirs ) ) {
			return [];
		}

		$attachments = [];

		foreach ( $submission_data as $key => $value ) {
			$parts = explode( '-lbl-', $key );
			if ( empty( $parts[0] ) ) {
				continue;
			}

			$fields = explode( '-', $parts[0] );
			if ( ! isset( $fields[1] ) || 'upload' !== $fields[1] ) {
				continue;
			}

			// Filter by selected block IDs if specified.
			$block_id = $fields[2] ?? '';
			if ( ! empty( $selected_block_ids ) && ! in_array( $block_id, $selected_block_ids, true ) ) {
				continue;
			}

			if ( empty( $value ) || ! is_array( $value ) ) {
				continue;
			}

			foreach ( $value as $encoded_url ) {
				$file_url = urldecode( Helper::get_string_value( $encoded_url ) );
				if ( empty( $file_url ) ) {
					continue;
				}

				$file_path      = Helper::convert_fileurl_to_filepath( $file_url );
				$real_file_path = realpath( $file_path );

				if ( false === $real_file_path ) {
					continue;
				}

				// Containment check.
				$is_allowed = false;
				foreach ( $allowed_dirs as $dir ) {
					if ( 0 === strpos( $real_file_path, $dir . DIRECTORY_SEPARATOR ) ) {
						$is_allowed = true;
						break;
					}
				}

				if ( $is_allowed ) {
					// Validate form ownership: new-format filenames encode the form ID.
					// Legacy files (pre-2.6.0) return form_id=0 and bypass this check —
					// intentional for backward compat, tracked for removal in #1113.
					$file_form_id = File_Upload::get_form_id_from_filename( basename( $real_file_path ) );
					if ( $file_form_id && $file_form_id !== $form_id ) {
						continue;
					}

					$attachments[] = $real_file_path;
				}
			}
		}

		return $attachments;
	}
}
