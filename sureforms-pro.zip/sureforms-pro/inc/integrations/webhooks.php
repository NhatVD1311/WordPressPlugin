<?php
/**
 * Sureforms Webhooks.
 *
 * @package sureforms.
 * @since 0.0.1
 */

namespace SRFM_Pro\Inc\Integrations;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM\Inc\Smart_Tags;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Sureforms Webhooks Class.
 *
 * @since 0.0.1
 */
class Webhooks {
	use Get_Instance;

	/**
	 * Skip reason: webhook is disabled.
	 *
	 * Sentinel returned by {@see trigger_webhook()} and matched in several places;
	 * kept as a constant so the untranslated string can't drift between call sites.
	 *
	 * @since 2.12.1
	 */
	public const SKIP_DISABLED = 'disabled';

	/**
	 * Skip reason: webhook trigger conditions were not met.
	 *
	 * @since 2.12.1
	 */
	public const SKIP_CONDITIONS_NOT_MET = 'trigger conditions not met';

	/**
	 * Submission Data.
	 *
	 * @var array<mixed>
	 * @since  0.0.1
	 */
	public $submission_data = [];

	/**
	 * Form Id.
	 *
	 * @var int
	 * @since  0.0.1
	 */
	protected $form_id = 0;

	/**
	 * Unprocessed form data.
	 *
	 * @var array<mixed>
	 * @since  0.0.1
	 */
	protected $form_data = [];

	/**
	 * Submission Id.
	 *
	 * @var int
	 * @since  0.0.1
	 */
	protected $submission_id = 0;
	/**
	 * Webhooks Settings.
	 *
	 * @var array<mixed>
	 * @since  0.0.1
	 */
	protected $webhook_settings = [];

	/**
	 * Constructor
	 *
	 * @since  0.0.1
	 */
	public function __construct() {
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_post_meta' ], 10 );
		add_action( 'srfm_after_submission_process', [ $this, 'after_submission_process' ] );
	}

	/**
	 * Post meta related to Webhooks Integration.
	 *
	 * @since 0.0.1
	 * @return void
	 */
	public static function register_post_meta() {

		register_post_meta(
			'sureforms_form',
			'_srfm_integrations_webhooks',
			[
				'single'            => true,
				'type'              => 'array',
				'default'           => [],
				'auth_callback'     => static function() {
					return Helper::current_user_can();
				},
				'sanitize_callback' => static function( $meta_value ) {
					if ( ! is_array( $meta_value ) ) {
						return [];
					}
					$sanitized = [];
					foreach ( $meta_value as $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}
						$sanitized_item = [
							'id'                      => isset( $item['id'] ) ? intval( $item['id'] ) : 0,
							'status'                  => isset( $item['status'] ) ? filter_var( $item['status'], FILTER_VALIDATE_BOOLEAN ) : false,
							'name'                    => isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '',
							// Webhooks fan out HTTP requests to the stored URL on every
							// form submission. `esc_url_raw`'s default scheme list
							// includes `gopher`, `file`, `mailto` and others that are
							// useful SSRF gadgets; restrict to `http` and `https`
							// only. An invalid URL after restriction sanitizes to
							// empty — the webhook firing code already short-circuits
							// on empty `url` so this fails closed.
							'url'                     => isset( $item['url'] ) ? esc_url_raw( $item['url'], [ 'http', 'https' ] ) : '',
							'method'                  => isset( $item['method'] ) && in_array( $item['method'], [ 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ], true ) ? $item['method'] : 'POST',
							'format'                  => isset( $item['format'] ) && in_array( $item['format'], [ 'JSON', 'FORM' ], true ) ? $item['format'] : 'JSON',
							'has_custom_headers'      => isset( $item['has_custom_headers'] ) ? filter_var( $item['has_custom_headers'], FILTER_VALIDATE_BOOLEAN ) : false,
							'custom_headers'          => isset( $item['custom_headers'] ) && is_array( $item['custom_headers'] ) ? Helper::sanitize_recursively( 'sanitize_text_field', $item['custom_headers'] ) : [],
							'has_custom_data_filters' => isset( $item['has_custom_data_filters'] ) ? filter_var( $item['has_custom_data_filters'], FILTER_VALIDATE_BOOLEAN ) : false,
							'custom_data_filters'     => isset( $item['custom_data_filters'] ) && is_array( $item['custom_data_filters'] ) ? Helper::sanitize_recursively( 'sanitize_text_field', $item['custom_data_filters'] ) : [],
							'has_trigger_conditions'  => isset( $item['has_trigger_conditions'] ) ? filter_var( $item['has_trigger_conditions'], FILTER_VALIDATE_BOOLEAN ) : false,
							'trigger_conditions'      => isset( $item['trigger_conditions'] ) && is_array( $item['trigger_conditions'] ) ? Helper::sanitize_recursively( 'sanitize_text_field', $item['trigger_conditions'] ) : [],
							'created_at'              => isset( $item['created_at'] ) ? sanitize_text_field( (string) $item['created_at'] ) : '',
							'updated_at'              => isset( $item['updated_at'] ) ? sanitize_text_field( (string) $item['updated_at'] ) : '',
						];
						$sanitized[]    = $sanitized_item;
					}
					return $sanitized;
				},
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'array',
						'context' => [ 'edit' ],
						'items'   => [
							'type'       => 'object',
							'properties' => [
								'id'                      => [
									'type' => 'integer',
								],
								'status'                  => [
									'type' => 'boolean',
								],
								'name'                    => [
									'type' => 'string',
								],
								'url'                     => [
									'type' => 'string',
								],
								'method'                  => [
									'type' => 'string',
								],
								'format'                  => [
									'type' => 'string',
								],
								'has_custom_headers'      => [
									'type' => 'boolean',
								],
								'custom_headers'          => [
									'type' => 'array',
								],
								'has_custom_data_filters' => [
									'type' => 'boolean',
								],
								'custom_data_filters'     => [
									'type' => 'array',
								],
								'has_trigger_conditions'  => [
									'type' => 'boolean',
								],
								'created_at'              => [
									'type' => 'string',
								],
								'updated_at'              => [
									'type' => 'string',
								],
								'trigger_conditions'      => [
									'type'       => 'object',
									'properties' => [
										'timestamp'  => [
											'type' => 'string',
										],
										'type'       => [
											'type' => 'string',
										],
										'operator'   => [
											'type' => 'string',
										],
										'conditions' => [
											'type' => 'array',
										],
									],
								],
							],
						],
					],
				],
			]
		);
	}

	/**
	 * Register 'After Submission' background process
	 *
	 * @param array<mixed> $form_data form data related to submission.
	 * @since 0.0.1
	 * @return void
	 */
	public function after_submission_process( $form_data ) {

		$integration_settings = Helper::get_array_value( get_option( 'srfm_pro_integration_settings', [] ) );

		if ( isset( $integration_settings['webhooks_enabled'] ) && empty( $integration_settings['webhooks_enabled'] ) ) {
			return;
		}

		$this->form_id = isset( $form_data['form_id'] )
		? Helper::get_integer_value( $form_data['form_id'] )
		: 0;

		$this->submission_id = isset( $form_data['submission_id'] )
		? Helper::get_integer_value( $form_data['submission_id'] )
		: 0;

		$this->form_data = array_filter(
			$form_data,
			static function ( $key ) {
				return 'form_id' !== Helper::get_string_value( $key ) && 'submission_id' !== Helper::get_string_value( $key );
			},
			ARRAY_FILTER_USE_KEY
		);

		$this->submission_data = Helper::map_slug_to_submission_data( $this->form_data );

		/**
		 * Filter the webhook submission data before it is dispatched.
		 *
		 * Allows transforming mapped slug => value pairs (e.g. converting raw
		 * upload/signature storage URLs to secure download URLs) without
		 * coupling the webhook layer to specific field types.
		 *
		 * @param array<mixed> $submission_data Mapped slug => value pairs.
		 * @param array<mixed> $form_data       Original form data with full block-type-prefixed keys.
		 * @param int          $form_id         Form ID.
		 * @since 2.9.0
		 */
		$this->submission_data = Helper::get_array_value(
			apply_filters( 'srfm_webhook_submission_data', $this->submission_data, $this->form_data, $this->form_id )
		);

		// Inject entry_id so {entry_id} smart tag resolves in webhook custom data filters.
		if ( 0 < $this->submission_id ) {
			$this->form_data['entry_id'] = $this->submission_id;
		}

		if ( ! ( 0 < $this->form_id ) ) {
			return;
		}

		$this->webhook_settings = Helper::get_array_value( get_post_meta( $this->form_id, '_srfm_integrations_webhooks', true ) );

		if ( ! is_array( $this->webhook_settings ) || empty( $this->webhook_settings ) ) {
			return;
		}

		$log     = $this->process_webhook_settings();
		$success = ! in_array(
			false,
			array_map(
				static function ( $log_item ) {
					return is_array( $log_item ) && isset( $log_item['status'] ) ? $log_item['status'] : false;
				},
				$log
			),
			true
		);

		if ( 0 < $this->submission_id ) {
			// Get existing extras data to preserve other data like PDF links.
			$entry_data      = Entries::get( $this->submission_id );
			$existing_extras = Helper::get_array_value( $entry_data['extras'] ) ?? [];

			// Merge webhook data with existing extras. `triggers` is a per-webhook
			// status map (keyed by webhook id) the entry UI reads to render status
			// and a Retry button for failed webhooks.
			$webhooks_data = [
				'webhooks' => [
					'log'      => $log,
					'status'   => $success,
					'triggers' => $this->build_webhook_trigger_statuses( $log ),
				],
			];

			$updated_extras = array_merge( $existing_extras, $webhooks_data );

			Entries::update(
				$this->submission_id,
				[
					'extras' => $updated_extras,
				]
			);
		}
	}

	/**
	 * Process webhook_settings.
	 *
	 * @since  0.0.1
	 * @return array<mixed>
	 */
	public function process_webhook_settings() {
		$log = [];
		foreach ( $this->webhook_settings as $webhook ) {
			if ( is_array( $webhook ) ) {
				[ $status, $response ] = $this->trigger_webhook( $webhook );
				$log[]                 = array_merge(
					$webhook,
					[
						'request_status' => $status,
						'response'       => $response,
					]
				);

				$this->add_webhook_status_in_entry_logs( $webhook, $response );
			}
		}
		return $log;
	}

	/**
	 * Build a per-webhook status map (keyed by webhook id) from a processed log.
	 *
	 * This is the single source the entry UI reads to render each webhook's
	 * status and a Retry button for the failed ones.
	 *
	 * @param array<mixed> $log Result of process_webhook_settings().
	 * @since 2.12.1
	 * @return array<int|string,array<string,mixed>> Keyed by webhook id (numeric ids become int array keys).
	 */
	public function build_webhook_trigger_statuses( $log ) {
		$triggers = [];
		foreach ( $log as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$status = $this->format_webhook_status(
				$item,
				! empty( $item['request_status'] ),
				$item['response'] ?? null
			);
			// Skip rows with no id: a missing webhook id sanitizes to 0/'' and would
			// collide into a single map entry, silently dropping a failed webhook from
			// the retry UI. Mirrors build_workflow_trigger_statuses().
			if ( '' === $status['id'] ) {
				continue;
			}
			$triggers[ $status['id'] ] = $status;
		}
		return $triggers;
	}

	/**
	 * Normalize a single webhook result into a status row for the entry UI.
	 *
	 * @param array<mixed> $webhook  Webhook config (must include id/name).
	 * @param bool         $success  Whether the request returned a 2xx response.
	 * @param mixed        $response Raw response (or a skip-reason string).
	 * @since 2.12.1
	 * @return array<string,mixed>
	 */
	public function format_webhook_status( $webhook, $success, $response ) {
		$state = 'failed';
		if ( in_array( $response, [ self::SKIP_DISABLED, self::SKIP_CONDITIONS_NOT_MET ], true ) ) {
			$state = 'skipped';
		} elseif ( $success ) {
			$state = 'success';
		}

		$http_code = is_array( $response ) ? (int) wp_remote_retrieve_response_code( $response ) : 0;
		$name      = isset( $webhook['name'] ) ? sanitize_text_field( Helper::get_string_value( $webhook['name'] ) ) : __( '(no title)', 'sureforms-pro' );

		return [
			'id'              => isset( $webhook['id'] ) ? Helper::get_string_value( $webhook['id'] ) : '',
			'name'            => $name,
			'status'          => $state,
			'http_code'       => $http_code,
			'message'         => $this->generate_webhook_log_message( $name, $response ),
			'last_attempt_at' => current_time( 'mysql' ),
		];
	}

	/**
	 * Re-dispatch a single failed webhook for a stored entry (manual retry).
	 *
	 * Rebuilds the exact dispatch payload from the entry's stored form_data
	 * (identical to how Background_Process replays srfm_after_submission_process),
	 * re-sends the webhook, updates its per-trigger status in entry extras, and
	 * appends an activity log.
	 *
	 * @param int        $submission_id Entry ID.
	 * @param int|string $webhook_id    The webhook id to retry.
	 * @since 2.12.1
	 * @return array<string,mixed> { success: bool, status: string, message: string }
	 */
	public function retry_webhook( $submission_id, $webhook_id ) {
		$submission_id = Helper::get_integer_value( $submission_id );
		$entry         = Entries::get( $submission_id );

		if ( empty( $entry ) || empty( $entry['form_id'] ) ) {
			return [
				'success' => false,
				'status'  => 'failed',
				'message' => __( 'Entry not found.', 'sureforms-pro' ),
			];
		}

		$form_id = Helper::get_integer_value( $entry['form_id'] );

		// Rebuild dispatch state from the stored entry (same data the original
		// submission dispatched — see Background_Process::handle_after_submission).
		$this->form_id               = $form_id;
		$this->submission_id         = $submission_id;
		$this->form_data             = Helper::get_array_value( $entry['form_data'] );
		$this->submission_data       = Helper::get_array_value(
			apply_filters( 'srfm_webhook_submission_data', Helper::map_slug_to_submission_data( $this->form_data ), $this->form_data, $form_id )
		);
		$this->form_data['entry_id'] = $submission_id;

		$webhooks = Helper::get_array_value( get_post_meta( $form_id, '_srfm_integrations_webhooks', true ) );
		$target   = null;
		foreach ( $webhooks as $webhook ) {
			if ( is_array( $webhook ) && isset( $webhook['id'] ) && Helper::get_string_value( $webhook['id'] ) === Helper::get_string_value( $webhook_id ) ) {
				$target = $webhook;
				break;
			}
		}

		if ( null === $target ) {
			return [
				'success' => false,
				'status'  => 'failed',
				'message' => __( 'Webhook configuration not found for this form.', 'sureforms-pro' ),
			];
		}

		[ $success, $response ] = $this->trigger_webhook( $target );

		$this->add_webhook_status_in_entry_logs( $target, $response, true );
		$trigger_status = $this->format_webhook_status( $target, $success, $response );
		$this->update_webhook_trigger_status( $submission_id, $trigger_status );

		// On success, drop the retry tag from the original failed log row(s) so they
		// no longer show a Retry button for an already-resolved webhook.
		if ( $success ) {
			Pro_Helper::clear_log_retry_tag( $submission_id, 'webhook', Helper::get_string_value( $webhook_id ) );
		}

		return [
			'success' => (bool) $success,
			'status'  => $trigger_status['status'],
			'message' => $trigger_status['message'],
		];
	}

	/**
	 * Update a single webhook's status row in the entry's extras['webhooks']['triggers'].
	 *
	 * @param int                 $submission_id  Entry ID.
	 * @param array<string,mixed> $trigger_status Status row from format_webhook_status().
	 * @since 2.12.1
	 * @return void
	 */
	public function update_webhook_trigger_status( $submission_id, $trigger_status ) {
		$entry  = Entries::get( $submission_id );
		$extras = Helper::get_array_value( $entry['extras'] ?? [] );

		if ( ! isset( $extras['webhooks'] ) || ! is_array( $extras['webhooks'] ) ) {
			$extras['webhooks'] = [];
		}
		if ( ! isset( $extras['webhooks']['triggers'] ) || ! is_array( $extras['webhooks']['triggers'] ) ) {
			$extras['webhooks']['triggers'] = [];
		}

		$extras['webhooks']['triggers'][ $trigger_status['id'] ] = $trigger_status;

		// Keep the aggregate status in sync for any existing consumers.
		$extras['webhooks']['status'] = ! in_array(
			'failed',
			array_column( $extras['webhooks']['triggers'], 'status' ),
			true
		);

		Entries::update( $submission_id, [ 'extras' => $extras ] );
	}

	/**
	 * Add webhook status in entry logs.
	 *
	 * @param array<mixed> $webhook  webhook setting.
	 * @param mixed        $response response from webhook.
	 * @param bool         $is_retry Whether this log is for a manual retry; when true the
	 *                               acting admin is recorded in the message ("who did it").
	 * @since  1.6.1
	 * @return void
	 */
	public function add_webhook_status_in_entry_logs( $webhook, $response, $is_retry = false ) {
		$entry_id = $this->submission_id;

		if ( empty( $entry_id ) || ! is_array( $webhook ) || self::SKIP_DISABLED === $response ) {
			return;
		}

		$webhook_name = isset( $webhook['name'] ) ?
			sanitize_text_field( Helper::get_string_value( $webhook['name'] ) )
			: __( '(no title)', 'sureforms-pro' );

		$log_message = $this->generate_webhook_log_message( $webhook_name, $response );

		// On manual retry, record who performed it (acceptance criterion of #2895).
		if ( $is_retry ) {
			$log_message .= Pro_Helper::get_retry_actor_note();
		}

		// Attach retry metadata to FAILED webhook logs only (not success, not a
		// skip), so the entry activity log can offer a per-row "Retry" for that
		// specific webhook. Success = a 2xx response; skips never reach a retry.
		$retry      = [];
		$code       = is_array( $response ) ? (int) wp_remote_retrieve_response_code( $response ) : 0;
		$is_success = $code >= 200 && $code < 300;
		$is_skip    = in_array( $response, [ self::SKIP_DISABLED, self::SKIP_CONDITIONS_NOT_MET ], true );
		$webhook_id = isset( $webhook['id'] ) ? Helper::get_string_value( $webhook['id'] ) : '';
		if ( ! $is_success && ! $is_skip && '' !== $webhook_id ) {
			$retry = [
				'type' => 'webhook',
				'id'   => $webhook_id,
			];
		}

		$this->update_entry_logs( $entry_id, $log_message, $retry );
	}

	/**
	 * Generate webhook log message.
	 *
	 * @param string $webhook_name webhook name.
	 * @param mixed  $response     webhook response.
	 * @since  1.6.1
	 * @return string
	 */
	public function generate_webhook_log_message( $webhook_name, $response ) {
		if ( self::SKIP_CONDITIONS_NOT_MET === $response ) {
			return sprintf(
				/* translators: Here %1$s is webhook name */
				__( 'Webhook "%1$s" was not triggered - conditions not met.', 'sureforms-pro' ),
				$webhook_name
			);
		}

		$response_code    = '0';
		$response_message = __( 'No message', 'sureforms-pro' );

		if ( is_array( $response ) && isset( $response['response'] ) && is_array( $response['response'] ) ) {
			if ( isset( $response['response']['code'] ) ) {
				$response_code = sanitize_text_field( Helper::get_string_value( $response['response']['code'] ) );
			}

			if ( isset( $response['response']['message'] ) ) {
				$response_message = sanitize_text_field( Helper::get_string_value( $response['response']['message'] ) );
			}
		}

		if ( '200' === $response_code ) {
			return sprintf(
				/* translators: Here %1$s is webhook name */
				__( 'Webhook "%1$s" triggered successfully.', 'sureforms-pro' ),
				$webhook_name
			);
		}

		return sprintf(
			/* translators: Here %1$s is webhook name, %2$s is webhook response code and %3$s is webhook response message. */
			__( 'Webhook "%1$s" failed to trigger - Response code: %2$s, Message: "%3$s".', 'sureforms-pro' ),
			$webhook_name,
			$response_code,
			$response_message
		);
	}

	/**
	 * Update entry logs.
	 *
	 * @param int                 $entry_id    entry id.
	 * @param string              $log_message log message.
	 * @param array<string,mixed> $retry       Optional retry metadata ([ 'type' => 'webhook', 'id' => <webhook id> ]) tagged onto the log row for failed webhooks so the entry UI can offer a per-row Retry. Empty for success/skip.
	 * @since 1.6.1
	 * @return void
	 */
	public function update_entry_logs( $entry_id, $log_message, $retry = [] ) {
		$entries_db = new Entries();

		$log_key = $entries_db->add_log( __( 'Webhook status notification', 'sureforms-pro' ) );

		if ( is_int( $log_key ) ) {
			$entries_db->update_log( $log_key, null, [ $log_message ] );
		}

		$logs = $entries_db->get_logs();

		// Tag the log row with retry metadata so the entry UI can offer a per-row
		// Retry button for this specific failed webhook. Entries::update merges this
		// log with the existing ones, so the extra key is preserved verbatim.
		if ( ! empty( $retry ) && is_int( $log_key ) && isset( $logs[ $log_key ] ) && is_array( $logs[ $log_key ] ) ) {
			$logs[ $log_key ]['retry'] = $retry;
		}

		$entries_db::update(
			$entry_id,
			[
				'logs' => $logs,
			]
		);
	}

	/**
	 * Trigger Webhook
	 *
	 * @param array<mixed> $webhook webhook setting.
	 * @return array{ bool, mixed }
	 */
	public function trigger_webhook( $webhook ) {
		if ( ! $webhook['status'] ) {
			return [ false, self::SKIP_DISABLED ];
		}

		if ( ! $this->check_trigger_conditions( $webhook ) ) {
			return [ false, self::SKIP_CONDITIONS_NOT_MET ];
		}

		$url = $webhook['url'];

		$headers = [];

		$method = $webhook['method'];

		$body = '';

		$data = $this->add_data_filters( $webhook );

		switch ( $webhook['method'] ) {
			case 'GET':
				// Structured smart-tag values (survey/poll results) are arrays;
				// add_query_arg() would explode them into field[key]= bracket params.
				// JSON-encode array values so each maps to a single query param.
				$query_data = is_array( $data ) ? array_map(
					static function ( $value ) {
						if ( ! is_array( $value ) ) {
							return $value;
						}
						$encoded = wp_json_encode( $value );
						return false !== $encoded ? $encoded : '';
					},
					$data
				) : $data;
				$url        = add_query_arg( $query_data, $url );
				break;
			default:
				$body = wp_json_encode( $data );
				break;
		}

		if ( isset( $webhook['format'] ) && 'FORM' === $webhook['format'] ) {
			$headers['Content-type'] = 'multipart/form-data';
		} else {
			$headers['Content-type'] = 'application/json';
		}

		$headers = $this->add_custom_headers( $headers, $webhook );

		$response = wp_remote_request(
			$url,
			[
				'method'  => Helper::get_string_value( $method ),
				'headers' => $headers,
				'body'    => Helper::get_string_value( $body ),
			]
		);

		if ( is_wp_error( $response ) ) {
			return [ false, $response ];
		}

		// A webhook is only successful on a 2xx response. Previously this returned
		// false unconditionally, so success was never tracked — which the retry
		// feature relies on to know which webhooks actually failed.
		$response_code = (int) wp_remote_retrieve_response_code( $response );
		$is_success    = $response_code >= 200 && $response_code < 300;

		return [ $is_success, $response ];
	}

	/**
	 * Add custom headers
	 *
	 * @param array<mixed> $headers request header.
	 * @param array<mixed> $webhook webhook setting.
	 * @since  0.0.1
	 * @return array<mixed>
	 */
	public function add_custom_headers( $headers, $webhook ) {

		$has_custom_headers = $webhook['has_custom_headers'] ?? false;

		if ( $has_custom_headers &&
			is_array( $webhook['custom_headers'] ) &&
			! empty( $webhook['custom_headers'] )
		) {
			foreach ( $webhook['custom_headers'] as $custom_header ) {
				$custom_header_key   = Helper::get_string_value( array_keys( $custom_header )[0] );
				$custom_header_value = Helper::get_string_value( array_values( $custom_header )[0] );
				if ( ! empty( $custom_header_key ) ) {
					$headers[ $custom_header_key ] = $custom_header_value;
				}
			}
		}
		return $headers;
	}

	/**
	 * Filter submission data
	 *
	 * @param array<mixed> $webhook webhook setting.
	 * @since  0.0.1
	 * @return array<mixed>
	 */
	public function add_data_filters( $webhook ) {
		$filtered_data = [];
		$smart_tags    = new Smart_Tags();

		$has_custom_data_filters = $webhook['has_custom_data_filters'] ?? false;

		if ( $has_custom_data_filters &&
			is_array( $webhook['custom_data_filters'] ) &&
			! empty( $webhook['custom_data_filters'] )
		) {
			// Add a flag to identify that this data is being processed for webhooks.
			// This helps determine the data format during smart tags processing.
			$this->form_data['_is_webhook_processing'] = true;

			// Form context for smart tags. Includes form-id so {form_title}, {entry_id},
			// and {survey-form:*} / {poll_results} can resolve in webhook bodies. The
			// _is_webhook_processing flag tells Survey_Smart_Tags to emit a structured
			// object payload instead of the HTML bar-chart used for emails/confirmations.
			$form_context = [
				'form-id'                => $this->form_id,
				'entry_id'               => $this->submission_id,
				'_is_webhook_processing' => true,
			];

			foreach ( $webhook['custom_data_filters'] as $custom_data_filter ) {
				$custom_data_filter_key   = Helper::get_string_value( array_keys( $custom_data_filter )[0] );
				$custom_data_filter_value = Helper::get_string_value( array_values( $custom_data_filter )[0] );
				if ( ! empty( $custom_data_filter_key ) ) {
					$filtered_data[ $custom_data_filter_key ] = $smart_tags->process_smart_tags( $custom_data_filter_value, $this->form_data, $form_context );
				}
			}

			// Resolve {pdf:slug} smart tags from entry extras.
			$filtered_data = $this->resolve_pdf_smart_tags( $filtered_data );
		}
		return empty( $filtered_data ) ? $this->submission_data : $filtered_data;
	}

	/**
	 * Check conditional logic for trigger
	 *
	 * @param array<mixed> $webhook webhook setting.
	 * @since  1.2.2
	 * @return bool
	 */
	public function check_trigger_conditions( $webhook ) {
		$trigger = true;

		$has_trigger_conditions = $webhook['has_trigger_conditions'] ?? false;

		if ( $has_trigger_conditions &&
			is_array( $webhook['trigger_conditions'] ) &&
			! empty( $webhook['trigger_conditions'] ) && ! empty( $webhook['trigger_conditions']['operator'] ) &&
			! empty( $webhook['trigger_conditions']['conditions'] )
		) {
			return $this->process_logic( $webhook['trigger_conditions'] );
		}
		return $trigger;
	}

	/**
	 * Process conditional logic.
	 *
	 * @param array{operator: string, conditions: array<array{field: string, operator: string, value: string}>} $rules Schema of conditional logic.
	 * @since  1.2.2
	 * @return bool
	 */
	public function process_logic( $rules ) {
		// By default trigger is true.
		$trigger = true;

		// Check conditions in the rules. if conditions are not empty then process the conditions.
		switch ( $rules['operator'] ) {
			case '_AND_':
				foreach ( $rules['conditions'] as $rule ) {
					if ( ! $this->process_condition( $rule ) ) {
						$trigger = false;
						break;
					}
				}
				break;
			case '_OR_':
				foreach ( $rules['conditions'] as $rule ) {
					if ( true === $this->process_condition( $rule ) ) {
						$trigger = true;
						break;
					}
					if ( false === $this->process_condition( $rule ) ) {
						$trigger = false;
					}
				}
				break;
		}

		return $trigger;
	}

	/**
	 * Process conditional logic.
	 *
	 * Delegates to Pro_Helper::process_condition() to avoid duplicating
	 * operator evaluation logic (including regex matching).
	 *
	 * @param array<string> $rule logical conditions.
	 * @since  1.2.2
	 * @return bool|string
	 */
	public function process_condition( $rule ) {
		return Pro_Helper::process_condition( $rule, $this->submission_data );
	}

	/**
	 * Resolve {pdf:slug} smart tags in filtered data using entry extras.
	 *
	 * Example input $filtered_data:
	 * [
	 *     'field_1' => 'John Doe',
	 *     'field_2' => 'Download: {pdf:invoice-pdf}',
	 *     'field_3' => '{pdf:receipt-pdf}',
	 * ]
	 *
	 * Example entry extras pdf_links structure (from Entries::get()):
	 * [
	 *     [
	 *         'slug' => 'pdf:invoice-pdf',
	 *         'link' => 'https://example.com/wp-content/uploads/sureforms/pdfs/invoice-pdf-123.pdf',
	 *     ],
	 *     [
	 *         'slug' => 'pdf:receipt-pdf',
	 *         'link' => 'https://example.com/wp-content/uploads/sureforms/pdfs/receipt-pdf-456.pdf',
	 *     ],
	 * ]
	 *
	 * Example output $filtered_data after replacement:
	 * [
	 *     'field_1' => 'John Doe',
	 *     'field_2' => 'Download: https://example.com/wp-content/uploads/sureforms/pdfs/invoice-pdf-123.pdf',
	 *     'field_3' => 'https://example.com/wp-content/uploads/sureforms/pdfs/receipt-pdf-456.pdf',
	 * ]
	 *
	 * @param array<mixed> $filtered_data The filtered webhook data.
	 * @since 2.7.0
	 * @return array<mixed> Modified filtered data with PDF tags resolved.
	 */
	private function resolve_pdf_smart_tags( $filtered_data ) {
		if ( ! ( $this->submission_id > 0 ) ) {
			return $filtered_data;
		}

		// Check if any values contain {pdf: tags before querying DB.
		$has_pdf_tags = false;
		foreach ( $filtered_data as $value ) {
			if ( is_string( $value ) && false !== strpos( $value, '{pdf:' ) ) {
				$has_pdf_tags = true;
				break;
			}
		}

		if ( ! $has_pdf_tags ) {
			return $filtered_data;
		}

		// Fetch entry data and extract pdf_links from extras.
		$entry_data = Entries::get( $this->submission_id );
		$extras     = isset( $entry_data['extras'] ) && is_array( $entry_data['extras'] ) ? $entry_data['extras'] : [];
		$pdf_links  = isset( $extras['pdf_links'] ) && is_array( $extras['pdf_links'] ) ? $extras['pdf_links'] : [];

		if ( empty( $pdf_links ) ) {
			return $filtered_data;
		}

		// Build slug-to-URL map from entry extras.
		// Result: [ 'pdf:invoice-pdf' => 'https://example.com/.../invoice-pdf-123.pdf', ... ].
		$slug_to_url = [];
		foreach ( $pdf_links as $pdf_data ) {
			if ( is_array( $pdf_data ) && ! empty( $pdf_data['slug'] ) && ! empty( $pdf_data['link'] ) ) {
				$slug_to_url[ $pdf_data['slug'] ] = $pdf_data['link'];
			}
		}

		// Replace {pdf:slug} tags in filtered data values.
		// e.g. '{pdf:invoice-pdf}' => 'https://example.com/.../invoice-pdf-123.pdf'.
		foreach ( $filtered_data as $key => $value ) {
			if ( ! is_string( $value ) || false === strpos( $value, 'pdf:' ) ) {
				continue;
			}
			foreach ( $slug_to_url as $slug => $url ) {
				$value = str_replace( '{' . $slug . '}', $url, $value );
			}
			$filtered_data[ $key ] = $value;
		}

		return $filtered_data;
	}
}
