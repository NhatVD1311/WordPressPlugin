<?php
/**
 * Signature field class for SureForms
 *
 * @package sureforms.
 * @since 1.6.0
 */

namespace SRFM_Pro\Inc\Pro\Signature;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\File_Upload;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Handler;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers\Google_Drive_Provider;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Signature field class for SureForms
 *
 * @since 1.6.0
 */
class Init {
	use Get_Instance;

	/**
	 * Associative array to keep the count of block that requires scripts to work.
	 *
	 * @var array<int>
	 * @since 1.6.0
	 */
	public static $script_dep_blocks = [
		'signature' => 0,
	];

	/**
	 * Constructor
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public function __construct() {
		add_filter( 'srfm_register_additional_blocks', [ $this, 'register_field' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_admin_scripts' ] );
		add_action( 'enqueue_block_assets', [ $this, 'enqueue_styles' ] );
		add_filter( 'render_block', [ $this, 'generate_render_script' ], 10, 2 );
		add_filter( 'srfm_css_vars_sizes', [ $this, 'cf_spacing_variables' ] );
		add_filter( 'srfm_dynamic_validation_messages', [ $this, 'add_signature_messages' ] );
		add_filter( 'srfm_general_dynamic_options_to_save', [ $this, 'add_signature_validation_messages_to_save' ], 10, 2 );
		add_filter( 'srfm_allowed_block_types', [ $this, 'allow_signature_block_in_sureforms' ], 10, 1 );
		add_filter( 'srfm_default_dynamic_block_option', [ $this, 'add_signature_default_dynamic_pro_block_values' ], 10, 2 );
		add_filter( 'srfm_before_prepare_submission_data', [ $this, 'store_signature_as_image' ], 10, 2 );
		add_filter( 'srfm_blocks', [ $this, 'allow_signature_block_in_sureforms' ] );
		add_action( 'srfm_enqueue_common_field_assets', [ $this, 'get_signature_assets' ] );
		add_filter( 'srfm_pro_updater_callbacks', [ $this, 'add_signature_dynamic_option_callback' ] );
		add_filter( 'srfm_smart_tag_view_link', [ $this, 'render_signature_image' ], 10, 2 );
		add_filter( 'srfm_email_template_render_url', [ $this, 'render_signature_image' ], 10, 2 );
		add_filter( 'srfm_entry_value', [ $this, 'transform_signature_urls' ], 10, 2 );

		// Transform signature URLs in {all_data} smart tag email rendering.
		add_action( 'srfm_before_processing_all_data_field', [ $this, 'render_signature_field_in_all_data_email' ] );
		add_filter( 'srfm_all_data_field_row', [ $this, 'should_skip_signature_field_row_in_email' ], 10, 2 );

		// Transform signature URL in default webhook submission data (no custom data filters).
		// `accepted_args = 3` to receive the optional `$form_id` passed by webhooks.php.
		add_filter( 'srfm_webhook_submission_data', [ $this, 'transform_signature_url_in_webhook_data' ], 10, 3 );
	}

	/**
	 * Render signature as image form smart tag or email template.
	 * Instead of returning the view link, it returns an image link if the field is a signature field.
	 *
	 * @param string $view_link The view link.
	 * @param array  $args Arguments passed to the filter.
	 *
	 * @return string|false
	 * @since 1.10.1
	 */
	public function render_signature_image( $view_link, $args ) {
		// return an image link if the field is a signature field.
		if (
			isset( $args['block_type'] )
			&& strpos( $args['block_type'], 'srfm-signature' ) !== false
			&& ! empty( $args['submission_item_value'] )
		) {
			$url = wp_http_validate_url( (string) $args['submission_item_value'] );
			if ( $url ) {
				// Google Drive serves its thumbnail URL via a redirect that mPDF
				// cannot fetch server-side, so embedding it in a generated PDF
				// renders a broken image. For the PDF, fall back to the default
				// link view (the same way an upload field is shown). Browsers and
				// email clients load the thumbnail directly, so they keep the image.
				$is_pdf = is_array( $args['form_data'] ?? null ) && ! empty( $args['form_data']['pdf_generation'] );
				if ( $is_pdf && '' !== Google_Drive_Provider::file_id_from_url( $url ) ) {
					return $view_link;
				}

				ob_start();
				?>
					<a target="_blank"
					href="<?php echo esc_url( $url ); ?>"
				style="outline: none;"
				rel="noopener noreferrer"
				title="<?php echo esc_attr__( 'Opens signature image in a new window', 'sureforms-pro' ); ?>">
					<img src="<?php echo esc_url( $url ); ?>" alt="<?php echo esc_attr__( 'Signature Image', 'sureforms-pro' ); ?>" width="70%" />
				</a>
				<?php
				return ob_get_clean();
			}
		}
		return $view_link;
	}

	/**
	 * Add signature field dynamic option callback.
	 *
	 * @param array<string> $callbacks Array of callbacks.
	 *
	 * @since 1.6.0
	 * @return array<mixed>
	 */
	public function add_signature_dynamic_option_callback( $callbacks ) {
		$callbacks['1.6.0'] = [ 'SRFM_Pro\Inc\Pro\Signature\Init::add_signature_default_dynamic_options' ];
		return $callbacks;
	}

	/**
	 * Add signature field dynamic option callback.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public static function add_signature_default_dynamic_options() {
		$previous_options = get_option( 'srfm_default_dynamic_block_option' );

		if ( ! empty( $previous_options ) && is_array( $previous_options ) ) {
			$required_message = Helper::get_common_err_msg();
			$current_options  = self::add_signature_messages();
			$current_options  = self::add_signature_default_dynamic_pro_block_values( $current_options, $required_message );

			// Iterate $current_options and update the options.
			foreach ( $current_options as $key => $value ) {
				if ( ! isset( $previous_options[ $key ] ) ) {
					$previous_options[ $key ] = $value;
				}
			}
			update_option( 'srfm_default_dynamic_block_option', $previous_options );
		}
	}

	/**
	 * Store signature as image.
	 *
	 * @param array<mixed>        $submission_data Processed form submission data.
	 * @param array<string,mixed> $context {
	 *     Additional context for the submission.
	 *
	 *     @type int $form_id The ID of the form being submitted.
	 * }
	 *
	 * @return array<mixed>
	 * @since 1.6.0
	 * @since 2.6.0 Accept $context array instead of reading form-id from $submission_data.
	 */
	public function store_signature_as_image( $submission_data, $context = [] ) {
		global $wp_filesystem;
		$upload_dir = wp_upload_dir();
		$tmp_dir    = $upload_dir['basedir'] . '/sureforms/tmp/';
		$directory  = trailingslashit( $upload_dir['basedir'] ) . File_Upload::$upload_dir . '/' . File_Upload::$signature_subdir . '/';

		// Tmp directory is transient (files are moved out immediately), wp_mkdir_p() is sufficient.
		if ( ! file_exists( $tmp_dir ) ) {
			wp_mkdir_p( $tmp_dir );
		}

		// Signature directory stores protected files — use maybe_create_upload_dir()
		// to create .htaccess and index.php protection, consistent with File_Upload.
		File_Upload::maybe_create_upload_dir( $directory );

		$form_id = isset( $context['form_id'] ) ? absint( $context['form_id'] ) : 0;

		foreach ( $submission_data as $key => $value ) {
			if ( strpos( $key, 'srfm-signature' ) === false ) {
				continue;
			}

			// if value does not contain data:image/ then for now skip to the next iteration.
			if ( strpos( Helper::get_string_value( $value ), 'data:image/' ) === false ) {
				continue;
			}

			// Decode base64 image data.
			$image_data = Pro_Helper::srfm_base64_decode( Helper::get_string_value( preg_replace( '#^data:image/\w+;base64,#i', '', Helper::get_string_value( $value ) ) ) );
			if ( ! $image_data ) {
				continue;
			}

			$filename  = $this->generate_signature_file_name( $key, $form_id );
			$file_path = $tmp_dir . $filename;

			// Save the image file.
			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			WP_Filesystem();
			$wp_filesystem->put_contents( $file_path, $image_data, FS_CHMOD_FILE );

			$check_file = wp_check_filetype_and_ext( $file_path, $filename, null );

			// Check if the file is an image.
			if ( ! $check_file['type'] || strpos( $check_file['type'], 'image' ) === false ) {
				unlink( $file_path );
				continue;
			}

			$temp_dile_path = $file_path;

			// Move the file to the final directory.
			rename( $file_path, $directory . $filename );

			// Remove the file from the tmp directory.
			if ( file_exists( $temp_dile_path ) ) {
				unlink( $temp_dile_path );
			}

			// Replace base64 data with file path (local URL).
			$local_url = $this->get_file_url( $file_path );

			// Cloud-first: upload to third-party storage when this field is mapped;
			// otherwise keep the local URL.
			$cloud_url               = File_Storage_Handler::get_instance()->maybe_upload_field_file_to_cloud( $form_id, $key, $directory . $filename );
			$submission_data[ $key ] = '' !== $cloud_url ? $cloud_url : $local_url;
		}

		return $submission_data;
	}

	/**
	 * Get file URL.
	 *
	 * @param string $file_path File path.
	 *
	 * @return string
	 * @since 1.6.0
	 */
	public function get_file_url( $file_path ) {
		$upload_dir = wp_upload_dir();
		$upload_url = trailingslashit( $upload_dir['baseurl'] ) . File_Upload::$upload_dir . '/' . File_Upload::$signature_subdir . '/';
		$file_name  = basename( $file_path );
		return $upload_url . $file_name;
	}

	/**
	 * Transform real signature file URLs to secure download URLs.
	 *
	 * Called via the srfm_entry_value filter when displaying entry data.
	 * Handles both new (sureforms-private/signature/) and legacy (sureforms/signature/) URLs:
	 * - New files  → sureforms-download URL with block-level access control.
	 * - Legacy files → sureforms-download URL via backward-compat path (no access control).
	 *
	 * @param mixed        $value   The entry field value.
	 * @param array<mixed> $context Context array with field_name, label, field_block_name.
	 * @since 2.6.0
	 * @return mixed Modified value with download URL, or original value for non-signature fields.
	 */
	public function transform_signature_urls( $value, $context ) {
		if ( empty( $context['field_block_name'] ) || 'srfm-signature' !== $context['field_block_name'] ) {
			return $value;
		}

		if ( empty( $value ) || ! \is_string( $value ) ) {
			return $value;
		}

		return self::get_download_url( $value );
	}

	/**
	 * Transform signature URL to a secure download URL in webhook submission data.
	 *
	 * Hooked to `srfm_webhook_submission_data`. Default webhook payloads bypass the
	 * per-field `srfm_entry_value` filter, so raw private signature URLs would
	 * otherwise leak into webhook bodies. This callback walks the original form
	 * data for signature-block keys, derives the matching slug used in
	 * `Helper::map_slug_to_submission_data`, and replaces the value with its secure
	 * download URL.
	 *
	 * Notes for maintainers:
	 * - The `srfm-signature-` prefix is the block-type prefix and is reserved for
	 *   the signature field at the registration layer. No other block type can
	 *   produce a key starting with this prefix, so a `strpos === 0` check is
	 *   sufficient.
	 * - Repeater inner blocks are restricted to a fixed whitelist that does not
	 *   include signature, so nested handling is intentionally omitted.
	 * - `self::get_download_url()` validates URL shape internally (decodes,
	 *   short-circuits via `is_backward_compatible_url`, and falls through to the
	 *   legacy handler for non-private URLs), so an upstream input check would
	 *   only duplicate that work.
	 * - Slug derivation is delegated to `Helper::map_slug_to_submission_data` so
	 *   any future change to the canonical derivation flows through automatically
	 *   instead of drifting out of sync with this method's inline logic.
	 * - Webhook trigger conditions (`Webhooks::process_logic`) evaluate AFTER this
	 *   filter runs — condition rules should be authored against the
	 *   `sureforms-download` URL form, not the pre-transform private path.
	 *
	 * Expected shapes:
	 * - $submission_data: array<string,mixed> — mapped slug => value pairs.
	 * - $form_data:       array<string,mixed> — original keys including the
	 *   `srfm-{type}-{block_id}-lbl-{label}` prefix.
	 * - $form_id:         int — provided by the filter for callbacks that need it,
	 *   currently unused here but accepted for API stability.
	 *
	 * @param mixed $submission_data Mapped slug => value pairs.
	 * @param mixed $form_data       Original form data with full block-type-prefixed keys.
	 * @param mixed $form_id         Form ID (currently unused).
	 * @since 2.9.0
	 * @return mixed
	 */
	public function transform_signature_url_in_webhook_data( $submission_data, $form_data, $form_id = 0 ) {
		unset( $form_id );

		if ( ! is_array( $submission_data ) || ! is_array( $form_data ) ) {
			return $submission_data;
		}

		foreach ( $form_data as $key => $value ) {
			// Block-type-specific prefix — see header note. Reserved for the signature field.
			if ( ! is_string( $key ) || 0 !== strpos( $key, 'srfm-signature-' ) || false === strpos( $key, '-lbl-' ) ) {
				continue;
			}

			// Reuse the canonical slug derivation by feeding a single-key submission
			// through `Helper::map_slug_to_submission_data`.
			$single_mapped = Helper::map_slug_to_submission_data( [ $key => $value ] );
			if ( empty( $single_mapped ) || ! is_array( $single_mapped ) ) {
				continue;
			}

			$slug = (string) array_key_first( $single_mapped );
			if ( '' === $slug || empty( $submission_data[ $slug ] ) || ! is_string( $submission_data[ $slug ] ) ) {
				continue;
			}

			$submission_data[ $slug ] = self::get_download_url( $submission_data[ $slug ] );
		}

		return $submission_data;
	}

	/**
	 * Render signature field rows with secure download URLs in the {all_data} email section.
	 *
	 * Hooked to `srfm_before_processing_all_data_field`. The core email template renders
	 * signature URLs as plain links via `srfm_email_template_render_url`. This method
	 * replaces that rendering by outputting a signature image with a secure download URL.
	 * The default row is then skipped via `should_skip_signature_field_row_in_email()`.
	 *
	 * @param array<string,mixed> $args {
	 *     Field data passed by the action.
	 *
	 *     @type mixed  $value           The field value (signature file URL string).
	 *     @type string $label           The field name/key.
	 *     @type string $block_name      The block type identifier.
	 *     @type string $processed_label The decrypted human-readable label.
	 * }
	 * @since 2.6.0
	 * @return void
	 */
	public function render_signature_field_in_all_data_email( $args ) {
		if ( empty( $args['block_name'] ) || 'srfm-signature' !== $args['block_name'] ) {
			return;
		}

		if ( empty( $args['value'] ) || ! \is_string( $args['value'] ) ) {
			return;
		}

		$td_style     = 'font-weight: 500;font-size: 14px;line-height: 20px;padding: 12px;text-align:left;word-break: break-word;border-bottom: 1px solid #E5E7EB;';
		$field_label  = isset( $args['processed_label'] ) && is_string( $args['processed_label'] ) ? $args['processed_label'] : '';
		$download_url = isset( $args['value'] ) && is_string( $args['value'] ) ? self::get_download_url( $args['value'] ) : '';

		?>
		<tr class="field-label">
			<th style="<?php echo esc_attr( $td_style ); ?>color: #1E293B;background-color: #F1F5F9;">
				<?php // The label is decoded from the submitted field key, so it is attacker-controllable — escape it as text, never as markup. ?>
				<strong><?php echo esc_html( html_entity_decode( $field_label ) ); ?>:</strong>
			</th>
		</tr>
		<tr class="field-value">
			<td style="<?php echo esc_attr( $td_style ); ?>color: #475569;">
				<a target="_blank"
					href="<?php echo esc_url( $download_url ); ?>"
					style="outline: none;"
					rel="noopener noreferrer"
					title="<?php echo esc_attr__( 'Opens signature image in a new window', 'sureforms-pro' ); ?>">
					<img src="<?php echo esc_url( $download_url ); ?>" alt="<?php echo esc_attr__( 'Signature Image', 'sureforms-pro' ); ?>" width="70%" />
				</a>
			</td>
		</tr>
		<?php
	}

	/**
	 * Skip the default email row rendering for signature fields in {all_data}.
	 *
	 * Since `render_signature_field_in_all_data_email()` already outputs the signature
	 * field rows with secure download URLs, this filter prevents the core email
	 * template from rendering the same field again with raw storage URLs.
	 *
	 * @param bool         $should_add_field_row Whether the field row should be added.
	 * @param array<mixed> $args                 Arguments containing field information.
	 * @since 2.6.0
	 * @return bool
	 */
	public function should_skip_signature_field_row_in_email( $should_add_field_row, $args ) {
		if ( isset( $args['block_name'] ) && 'srfm-signature' === $args['block_name'] ) {
			return false;
		}

		return $should_add_field_row;
	}

	/**
	 * Convert a real file URL (possibly URL-encoded) to a secure download URL.
	 *
	 * Note on code similarity with File_Upload::get_download_url():
	 * Both methods share the same URL-to-download-URL transformation logic.
	 * This is intentional — signature and upload file management are kept as
	 * separate, self-contained modules so that each can evolve independently
	 * (e.g. different filename formats, storage paths, or access-control rules).
	 * Coupling Signature to File_Upload's internal URL logic would create a
	 * fragile cross-dependency. The same reasoning applies to the companion
	 * methods is_backward_compatible_url() and get_backward_compatible_download_url().
	 *
	 * @param string $file_url The real file URL (may be URL-encoded).
	 * @since 2.6.0
	 * @return string The secure download URL.
	 */
	public static function get_download_url( $file_url ) {
		$decoded_url = rawurldecode( $file_url );

		// External (cloud storage) URL — uploaded directly to a provider during
		// submission. Not under the WordPress uploads directory, so leave it untouched.
		// Compare by path (host-agnostic).
		$srfm_upload_dir = wp_upload_dir();
		$srfm_base_url   = isset( $srfm_upload_dir['baseurl'] ) && is_string( $srfm_upload_dir['baseurl'] ) ? $srfm_upload_dir['baseurl'] : '';
		$srfm_base_path  = '' !== $srfm_base_url ? Helper::get_string_value( wp_parse_url( $srfm_base_url, PHP_URL_PATH ) ) : '';
		$srfm_url_path   = Helper::get_string_value( wp_parse_url( $decoded_url, PHP_URL_PATH ) );
		if (
			'' !== $srfm_base_path
			&& false === strpos( $srfm_url_path, $srfm_base_path )
			&& false === strpos( $decoded_url, '/' . File_Upload::$download_slug . '/' )
		) {
			return $decoded_url;
		}

		// Idempotency guard: if the URL already points at the secure download
		// handler, return it unchanged. Prevents double-encoding when the same
		// value flows through this method twice (e.g. a future code path or a
		// third-party filter that re-applies `srfm_webhook_submission_data`).
		if ( false !== strpos( $decoded_url, '/' . File_Upload::$download_slug . '/' ) ) {
			return $decoded_url;
		}

		// Route legacy URLs through the backward-compatible handler.
		if ( self::is_backward_compatible_url( $decoded_url ) ) {
			return self::get_backward_compatible_download_url( $decoded_url );
		}

		$filename = basename( $decoded_url );

		// Extract form ID from filename format: {name}-{random-id}-{form-id}.{ext}.
		$name_without_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$parts            = explode( '-', $name_without_ext );
		$form_id          = end( $parts );

		$encoded_filename = Pro_Helper::srfm_base64_encode( $filename );

		return home_url( File_Upload::$download_slug . '/' . $encoded_filename . '/' . $form_id . '/' );
	}

	/**
	 * Determine whether a file URL uses the legacy (pre-2.5.0) public storage path.
	 *
	 * New files are stored in the protected /uploads/sureforms-private/ directory.
	 * Old files lived in the public /uploads/sureforms/ directory (no access control).
	 * If the URL does not contain the private directory segment it is considered a
	 * backward-compatible (legacy) URL.
	 *
	 * @param string $url The file URL to inspect.
	 * @since 2.6.0
	 * @return bool True if the URL is a legacy (non-private) file URL.
	 */
	public static function is_backward_compatible_url( $url ) {
		return false === strpos( $url, '/' . File_Upload::$upload_dir . '/' );
	}

	/**
	 * Add pro block's default error message values.
	 *
	 * @param array<mixed> $default_values the default values.
	 * @param array<mixed> $common_err_msg the common error message.
	 * @since 1.6.0
	 * @return array<mixed>
	 */
	public static function add_signature_default_dynamic_pro_block_values( $default_values, $common_err_msg ) {

		$default_pro_values = [
			'srfm_signature_block_required_text'    => $common_err_msg['required'],
			/* translators: %s represents the maximum file size allowed in MB */
			'srfm_signature_block_size_exceed'      => __( 'File size should not exceed %s MB.', 'sureforms-pro' ),
			'srfm_signature_block_type_not_allowed' => __( 'File type not allowed.', 'sureforms-pro' ),
			'srfm_signature_block_invalid_value'    => __( 'Please enter a valid signature!', 'sureforms-pro' ),
		];

		return array_merge( $default_values, $default_pro_values );
	}

	/**
	 * Allow signature block in sureforms.
	 *
	 * @param array<string> $blocks Array of blocks.
	 *
	 * @since 1.6.0
	 * @return array<string>
	 */
	public function allow_signature_block_in_sureforms( $blocks ) {
		return array_merge(
			$blocks,
			[
				'srfm/signature',
			]
		);
	}

	/**
	 * Add signature field messages.
	 *
	 * @param array<string> $default_options Default options.
	 * @param array<string> $setting_options Setting options.
	 *
	 * @since 1.6.0
	 * @return array<string>
	 */
	public function add_signature_validation_messages_to_save( $default_options, $setting_options ) {
		$pro_options_keys    = [
			'srfm_signature_block_required_text',
			'srfm_signature_block_size_exceed',
			'srfm_signature_block_type_not_allowed',
			'srfm_signature_block_invalid_value',
		];
		$pro_options_to_save = [];
		foreach ( $pro_options_keys as $key ) {
			if ( isset( $setting_options[ $key ] ) ) {
				$pro_options_to_save[ $key ] = $setting_options[ $key ];
			}
		}
		return array_merge( $default_options, $pro_options_to_save );
	}

	/**
	 * Retrieve default dynamic validation messages.
	 *
	 * @param array<string, string> $default_value Associative array of translated validation messages for frontend use.
	 * @since 1.6.0
	 * @return array Associative array of translated validation messages for frontend use.
	 */
	public static function add_signature_messages( $default_value = [] ) {
		$translatable_array = [
			'srfm_signature_block_required_text'    => __( 'This field is required.', 'sureforms-pro' ),
			/* translators: %s represents the maximum file size allowed in MB */
			'srfm_signature_block_size_exceed'      => __( 'File size should not exceed %s MB.', 'sureforms-pro' ),
			'srfm_signature_block_type_not_allowed' => __( 'File type not allowed.', 'sureforms-pro' ),
			'srfm_signature_block_invalid_value'    => __( 'Please enter a valid signature value!', 'sureforms-pro' ),
		];

		return ! empty( $default_value ) && is_array( $default_value ) ? array_merge( $default_value, $translatable_array ) : $translatable_array;
	}

	/**
	 * Render function.
	 *
	 * @param string $block_content Entire Block Content.
	 * @param array  $block Block Properties As An Array.
	 * @since 1.6.0
	 * @return string
	 */
	public function generate_render_script( $block_content, $block ) {
		if ( isset( $block['blockName'] ) && 'srfm/signature' === $block['blockName'] ) {
			self::enqueue_frontend_assets( $block['blockName'] );
		}
		return $block_content;
	}

	/**
	 * Enqueue required styles for the signature field in the editor and frontend.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public function enqueue_styles() {
		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/package/pro/';
		// This checks the text direction of the site, if it is RTL then it will load the RTL version of the CSS file.
		$rtl = is_rtl() ? '-rtl' : '';

		// Load the frontend custom app styles.
		wp_enqueue_style( SRFM_PRO_SLUG . '-signature', $css_uri . 'signature' . $file_prefix . $rtl . '.css', [], SRFM_PRO_VER );
	}

	/**
	 * Register signature field.
	 *
	 * @param array<mixed> $blocks Array of blocks.
	 *
	 * @since 1.6.0
	 * @return array<mixed>
	 */
	public function register_field( $blocks ) {
		$blocks[] = [
			'dir'       => SRFM_PRO_DIR . 'inc/pro/signature/block.php',
			'namespace' => 'SRFM_PRO\\Inc\\Blocks',
		];

		return $blocks;
	}

	/**
	 * Enqueue signature form admin scripts.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public function enqueue_admin_scripts() {
		$this->enqueue_styles();
		$scripts = [
			[
				'unique_file'        => 'signatureAdmin',
				'unique_handle'      => 'signature-admin',
				'extra_dependencies' => [ 'srfm-blocks', SRFM_PRO_SLUG . '-block-editor' ],
			],
		];
		$this->enqueue_scripts( $scripts );
	}

	/**
	 * Enqueue signature form frontend scripts.
	 *
	 * @param string $block_type Block type.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public function enqueue_frontend_assets( $block_type = '' ) {
		$block_name = str_replace( 'srfm/', '', $block_type );

		// Check if block is in the array and check if block is already enqueued.
		if (
			in_array( $block_name, array_keys( self::$script_dep_blocks ), true ) &&
			0 === self::$script_dep_blocks[ $block_name ]
		) {
			self::$script_dep_blocks[ $block_name ] += 1;
			$this->get_signature_assets();
		}
	}

	/**
	 * Get signature assets.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	public function get_signature_assets() {
		$this->enqueue_styles();
		// enqueue signature pad library.
		wp_enqueue_script( 'srfm-pro-signature-pad-lib', SRFM_PRO_URL . 'assets/js/minified/deps/signature_pad.umd.min.js', [], SRFM_PRO_VER, true );
		$scripts = [
			[
				'unique_file'        => 'signatureFrontend',
				'unique_handle'      => 'signature-frontend',
				'extra_dependencies' => [ 'srfm-pro-signature-pad-lib' ],
			],
		];
		$this->enqueue_scripts( $scripts );
	}

	/**
	 * Replace the spacing variables with values for the signature block.
	 * This is used in the frontend.
	 *
	 * @param array<string|mixed> $sizes array of css variables coming from 'srfm_css_vars_sizes' filter.
	 * @since 1.6.0
	 * @return array<string|mixed>
	 */
	public function cf_spacing_variables( $sizes ) {
		return array_replace_recursive(
			$sizes,
			[
				'small'  => [
					'--srfm-signature-canvas-height' => '120px',
					'--srfm-signature-button-bottom' => '12px',
				],
				'medium' => [
					'--srfm-signature-canvas-height' => '140px',
					'--srfm-signature-button-bottom' => '14px',
				],
				'large'  => [
					'--srfm-signature-canvas-height' => '160px',
					'--srfm-signature-button-bottom' => '16px',
				],
			]
		);
	}

	/**
	 * Generate a secure signature file name.
	 *
	 * Format: signature-{random_id}-signature-{block_id}-{form_id}.png
	 * Mirrors the format used by File_Upload::generate_file_name().
	 *
	 * @param string $field_key The field key (format: srfm-signature-{block_id}-lbl-{label}).
	 * @param int    $form_id   The form ID.
	 * @since 2.6.0
	 * @return string The generated file name.
	 */
	private function generate_signature_file_name( $field_key, $form_id ) {
		$random_id = strtolower( wp_generate_password( 8, false ) );
		$block_id  = Pro_Helper::get_block_id( $field_key );
		return "signature-{$random_id}-signature-{$block_id}-" . absint( $form_id ) . '.png';
	}

	/**
	 * Build a backward-compatible secure download URL for a legacy (pre-2.5.0) file.
	 *
	 * Legacy files were stored in the public /uploads/sureforms/ directory and had no
	 * access-control. To serve them through the unified sureforms-download handler without
	 * breaking existing entry data, the path relative to the uploads base URL is base64-
	 * encoded and placed in the download URL. The form-id segment is set to 0 because
	 * legacy filenames carry no embedded form-id; the handler detects the presence of a
	 * path separator ('/') in the decoded value and serves the file directly from the
	 * uploads directory without enforcing block-level permissions.
	 *
	 * Example:
	 *   Input:  "http://site.com/wp-content/uploads/sureforms/img-1-1.jpg"
	 *   Encoded path: base64("sureforms/img-1-1.jpg")
	 *   Output: "http://site.com/sureforms-download/{base64}/0/"
	 *
	 * @param string $decoded_url The decoded (non-URL-encoded) legacy file URL.
	 * @since 2.6.0
	 * @return string The secure download URL for the legacy file.
	 */
	private static function get_backward_compatible_download_url( $decoded_url ) {
		// Extract the path relative to the WordPress uploads base URL.
		// e.g. "http://site.com/wp-content/uploads/sureforms/img-1-1.jpg"
		// → "sureforms/img-1-1.jpg".
		$upload_base_url = trailingslashit( wp_upload_dir()['baseurl'] );
		$relative_path   = ltrim( str_replace( $upload_base_url, '', $decoded_url ), '/' );

		$encoded_path = Pro_Helper::srfm_base64_encode( $relative_path );

		// form-id is 0 — legacy files have no embedded form-id.
		return home_url( File_Upload::$download_slug . '/' . $encoded_path . '/0/' );
	}

	/**
	 * Enqueue scripts.
	 *
	 * @param array<array<string, mixed>> $scripts Array of scripts to enqueue.
	 *
	 * @since 1.6.0
	 * @return void
	 */
	private function enqueue_scripts( $scripts ) {
		foreach ( $scripts as $script ) {
			$script_dep_path = SRFM_PRO_DIR . 'dist/package/pro/' . $script['unique_file'] . '.asset.php';
			$script_dep_data = file_exists( $script_dep_path )
				? include $script_dep_path
				: [
					'dependencies' => [],
					'version'      => SRFM_PRO_VER,
				];

			// Ensure dependencies are arrays.
			$script_dep = array_merge(
				is_array( $script_dep_data['dependencies'] ) ? $script_dep_data['dependencies'] : [],
				is_array( $script['extra_dependencies'] ) ? $script['extra_dependencies'] : []
			);

			// Enqueue script.
			wp_enqueue_script(
				SRFM_PRO_SLUG . '-' . $script['unique_handle'], // Handle.
				SRFM_PRO_URL . 'dist/package/pro/' . $script['unique_file'] . '.js',
				$script_dep, // Dependencies.
				$script_dep_data['version'], // Version.
				true // Enqueue the script in the footer.
			);

			// Register script translations.
			Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
		}
	}
}
