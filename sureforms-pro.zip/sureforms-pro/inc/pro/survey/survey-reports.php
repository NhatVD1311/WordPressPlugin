<?php
/**
 * Survey Reports admin page and REST API endpoints.
 *
 * @package sureforms-pro
 * @since 2.8.0
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM\Admin\Admin as Core_Admin;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;
use WP_Error;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Survey Reports class.
 *
 * @since 2.8.0
 */
class Survey_Reports {
	use Get_Instance;

	/**
	 * Page slug.
	 *
	 * @since 2.8.0
	 */
	public const PAGE_SLUG = 'sureforms_survey_reports';

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ], 30 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_filter( 'srfm_rest_api_endpoints', [ $this, 'register_rest_endpoints' ] );
		add_filter( 'srfm_is_dashboard_screen', [ $this, 'add_survey_reports_screen' ] );
		add_filter( 'srfm_admin_filter', [ $this, 'add_survey_reports_nav_item' ] );
	}

	/**
	 * Register admin menu for survey reports.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function register_menu() {
		if ( ! Helper::current_user_can() ) {
			return;
		}

		add_submenu_page(
			'sureforms_menu',
			__( 'Survey Reports', 'sureforms-pro' ),
			__( 'Survey Reports', 'sureforms-pro' ) .
				' <span style="color:#4ADE80;font-size:9px;font-weight:600;">' .
				esc_html__( 'New', 'sureforms-pro' ) .
				'</span>',
			'manage_options',
			self::PAGE_SLUG,
			[ $this, 'render_page' ],
			6
		);
	}

	/**
	 * Render survey reports root.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function render_page() {
		echo '<div id="srfm-survey-reports-root" class="srfm-admin-wrapper"></div>';
	}

	/**
	 * Hide the survey reports submenu item from the sidebar.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function hide_menu_item() {
		remove_submenu_page( 'sureforms_menu', self::PAGE_SLUG );
	}

	/**
	 * Add survey reports screen to the SureForms dashboard screen check.
	 *
	 * Needed so core enqueues the shared Header CSS/JS and localizes srfm_admin data.
	 *
	 * @param bool $is_dashboard_screen Whether the current screen is a SureForms dashboard screen.
	 * @since 2.8.0
	 * @return bool
	 */
	public function add_survey_reports_screen( $is_dashboard_screen ) {
		if ( $is_dashboard_screen ) {
			return $is_dashboard_screen;
		}

		return Helper::validate_request_context( self::PAGE_SLUG, 'page' );
	}

	/**
	 * Add Survey Reports nav item to the header navigation.
	 *
	 * @param array<string,mixed> $localization_data Localization data.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function add_survey_reports_nav_item( $localization_data ) {
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		if ( ! isset( $localization_data['additional_header_nav_items'] ) || ! is_array( $localization_data['additional_header_nav_items'] ) ) {
			$localization_data['additional_header_nav_items'] = [];
		}

		$localization_data['additional_header_nav_items'][] = [
			'slug' => self::PAGE_SLUG,
			'text' => __( 'Survey Reports', 'sureforms-pro' ),
			'link' => admin_url( 'admin.php?page=' . self::PAGE_SLUG ),
		];

		return $localization_data;
	}

	/**
	 * Enqueue survey reports assets.
	 *
	 * @param string $hook_prefix Current admin page hook.
	 * @since 2.8.0
	 * @return void
	 */
	public function enqueue_assets( $hook_prefix ) {
		if ( 'sureforms_page_' . self::PAGE_SLUG !== $hook_prefix ) {
			return;
		}

		$asset_handle      = 'surveyReports';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$script_info['dependencies'],
			$script_info['version'],
			true
		);

		$css_file = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.css';
		if ( file_exists( $css_file ) ) {
			wp_enqueue_style(
				SRFM_PRO_SLUG . '-' . $asset_handle,
				SRFM_PRO_URL . 'dist/' . $asset_handle . '.css',
				[],
				SRFM_PRO_VER
			);
		}

		$is_license_active = false;
		if ( class_exists( '\\SRFM_Pro\\Admin\\Licensing' ) ) {
			$is_license_active = \SRFM_Pro\Admin\Licensing::is_license_active();
		}

		$localization_data = [
			'site_url'                   => get_site_url(),
			'sureforms_dashboard_url'    => admin_url( '/admin.php?page=sureforms_menu' ),
			'plugin_version'             => defined( 'SRFM_VER' ) ? SRFM_VER : '',
			'global_settings_nonce'      => Helper::current_user_can() ? wp_create_nonce( 'wp_rest' ) : '',
			'is_pro_active'              => Helper::has_pro(),
			'is_license_active'          => $is_license_active,
			'is_first_form_created'      => class_exists( Core_Admin::class ) ? Core_Admin::is_first_form_created() : false,
			'check_three_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold() : false,
			'check_eight_days_threshold' => class_exists( Core_Admin::class ) ? Core_Admin::check_first_form_creation_threshold( 8 ) : false,
			'pro_plugin_version'         => Helper::has_pro() && defined( 'SRFM_PRO_VER' ) ? SRFM_PRO_VER : '',
			'pro_plugin_name'            => Helper::has_pro() && defined( 'SRFM_PRO_PRODUCT' ) ? SRFM_PRO_PRODUCT : 'SureForms Pro',
			'sureforms_pricing_page'     => Helper::get_sureforms_website_url( 'pricing' ),
		];

		$localization_data = apply_filters( 'srfm_admin_filter', $localization_data );
		if ( ! is_array( $localization_data ) ) {
			$localization_data = [];
		}

		wp_add_inline_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'var srfm_admin = window.srfm_admin || {};',
			'before'
		);

		wp_localize_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			'srfm_admin',
			$localization_data
		);

		Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $asset_handle );
	}

	/**
	 * Register REST API endpoints.
	 *
	 * @param array<string,mixed> $endpoints Existing endpoints.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function register_rest_endpoints( $endpoints ) {
		$validate_form_id = static function ( $value ) {
			return absint( $value ) > 0;
		};

		$validate_date = static function ( $value ) {
			return '' === $value || (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value );
		};

		$validate_non_empty_string = static function ( $value ) {
			return is_string( $value ) && '' !== $value;
		};

		$endpoints['survey-results/(?P<form_id>\d+)'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_survey_results' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'   => [
					'required'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => $validate_form_id,
				],
				'date_from' => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
				'date_to'   => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
			],
		];

		$endpoints['survey-results/(?P<form_id>\d+)/nps'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_nps_results' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id' => [
					'required'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => $validate_form_id,
				],
			],
		];

		$endpoints['survey-results/(?P<form_id>\d+)/trends'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_trends' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'   => [
					'required'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => $validate_form_id,
				],
				'period'    => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => static function ( $value ) {
						return in_array( $value, [ 'daily', 'weekly', 'monthly' ], true );
					},
					'default'           => 'daily',
				],
				'date_from' => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
				'date_to'   => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
			],
		];

		$endpoints['survey-results/(?P<form_id>\d+)/drilldown'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'get_drilldown' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'      => [
					'required'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => $validate_form_id,
				],
				'field_slug'   => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_non_empty_string,
				],
				'filter_value' => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_non_empty_string,
				],
				'filter_type'  => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => static function ( $value ) {
						return in_array( $value, [ 'nps_category', 'exact', 'contains' ], true );
					},
				],
				'fields'       => [
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_non_empty_string,
				],
				'page'         => [
					'sanitize_callback' => 'absint',
					'validate_callback' => static function ( $value ) {
						return absint( $value ) > 0;
					},
					'default'           => 1,
				],
				'per_page'     => [
					'sanitize_callback' => 'absint',
					'validate_callback' => static function ( $value ) {
						return absint( $value ) > 0;
					},
					'default'           => 20,
				],
				'date_from'    => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
				'date_to'      => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
			],
		];

		$endpoints['survey-results/(?P<form_id>\d+)/export'] = [
			'methods'             => 'GET',
			'callback'            => [ $this, 'export_results' ],
			'permission_callback' => [ Helper::class, 'get_items_permissions_check' ],
			'args'                => [
				'form_id'    => [
					'required'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => $validate_form_id,
				],
				'date_from'  => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
				'date_to'    => [
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => $validate_date,
					'default'           => '',
				],
				'field_slug' => [
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				],
			],
		];

		return $endpoints;
	}

	/**
	 * Get full aggregated survey results.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.8.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_survey_results( WP_REST_Request $request ) {
		$form_id   = absint( $request->get_param( 'form_id' ) );
		$date_from = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_from' ) ) );
		$date_to   = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_to' ) ) );

		if ( ! $form_id ) {
			return new WP_Error( 'invalid_form_id', __( 'Invalid form ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$error = $this->validate_survey_form( $form_id );
		if ( $error ) {
			return $error;
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		$result     = $this->normalize_results( $aggregator->aggregate( $form_id, $date_from, $date_to ) );

		// Raw title: the_title's wptexturize would render a hyphen as an en-dash in
		// the report payload and the CSV export.
		$result['form_title'] = (string) get_post_field( 'post_title', $form_id, 'raw' );
		$result['truncated']  = $aggregator->is_truncated();

		return $result;
	}

	/**
	 * Get NPS breakdown.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.8.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_nps_results( WP_REST_Request $request ) {
		$form_id = absint( $request->get_param( 'form_id' ) );

		if ( ! $form_id ) {
			return new WP_Error( 'invalid_form_id', __( 'Invalid form ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$error = $this->validate_survey_form( $form_id );
		if ( $error ) {
			return $error;
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		return $aggregator->get_nps_breakdown( $form_id );
	}

	/**
	 * Get response trends.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.8.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_trends( WP_REST_Request $request ) {
		$form_id   = absint( $request->get_param( 'form_id' ) );
		$period    = sanitize_text_field( Helper::get_string_value( $request->get_param( 'period' ) ) );
		$date_from = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_from' ) ) );
		$date_to   = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_to' ) ) );

		if ( ! $form_id ) {
			return new WP_Error( 'invalid_form_id', __( 'Invalid form ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$error = $this->validate_survey_form( $form_id );
		if ( $error ) {
			return $error;
		}

		$valid_periods = [ 'daily', 'weekly', 'monthly' ];
		if ( ! in_array( $period, $valid_periods, true ) ) {
			$period = 'daily';
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		return [
			'form_id'   => $form_id,
			'period'    => $period,
			'trends'    => $aggregator->get_response_trends( $form_id, $period, $date_from, $date_to ),
			'truncated' => $aggregator->is_truncated(),
		];
	}

	/**
	 * Export results as CSV data with per-field breakdown.
	 *
	 * When field_slug is provided, exports just that field.
	 * Otherwise exports all fields separated by blank rows.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.8.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function export_results( WP_REST_Request $request ) {
		$form_id    = absint( $request->get_param( 'form_id' ) );
		$date_from  = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_from' ) ) );
		$date_to    = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_to' ) ) );
		$field_slug = sanitize_text_field( Helper::get_string_value( $request->get_param( 'field_slug' ) ) );

		if ( ! $form_id ) {
			return new WP_Error( 'invalid_form_id', __( 'Invalid form ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$error = $this->validate_survey_form( $form_id );
		if ( $error ) {
			return $error;
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		$results    = $aggregator->aggregate( $form_id, $date_from, $date_to );
		$entries    = $aggregator->get_form_entries( $form_id, $date_from, $date_to );

		$fields = isset( $results['fields'] ) && is_array( $results['fields'] ) ? $results['fields'] : [];

		// Filter to single field if field_slug is provided.
		if ( ! empty( $field_slug ) ) {
			$fields = array_filter(
				$fields,
				static function ( $field ) use ( $field_slug ) {
					if ( ! is_array( $field ) ) {
						return false;
					}
					$slugs = isset( $field['block_slugs'] ) && is_array( $field['block_slugs'] ) ? $field['block_slugs'] : [];
					return in_array( $field_slug, $slugs, true ) || ( $field['block_slug'] ?? '' ) === $field_slug;
				}
			);
		}

		$csv_rows = [];
		$is_first = true;

		foreach ( $fields as $slug => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			// Blank row separator between fields.
			if ( ! $is_first ) {
				$csv_rows[] = [];
			}
			$is_first = false;

			$label     = isset( $field['label'] ) && is_string( $field['label'] ) ? $field['label'] : $slug;
			$type      = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : 'text';
			$total     = isset( $field['total_responses'] ) && is_int( $field['total_responses'] ) ? $field['total_responses'] : 0;
			$responses = isset( $field['responses'] ) && is_array( $field['responses'] ) ? $field['responses'] : [];

			// ── Header section ──
			// $label is base64-decoded out of a submitted field key
			// (Results_Aggregator::extract_label()), so it is attacker-forgeable and gets the
			// same neutralisation as the option/response cells below.
			// $type comes from detect_field_type()'s closed prefix whitelist — one of twelve
			// fixed strings, defaulting to 'text' — so a submitter picks which member, never
			// its content, and none can begin with a formula starter. Escaping it is a no-op
			// today; applied for symmetry in case that mapping ever returns a decoded value.
			$csv_rows[] = [ __( 'Field', 'sureforms-pro' ), $this->sanitize_csv_value( $label ) ];
			$csv_rows[] = [ __( 'Type', 'sureforms-pro' ), $this->sanitize_csv_value( $type ) ];
			// $total, and likewise nps_score / average / $count / $pct below, are ints, floats,
			// gmdate() or __() output and are deliberately left raw. Wrapping them would turn
			// every count in the sheet into text — do not "finish the job" here.
			$csv_rows[] = [ __( 'Total Responses', 'sureforms-pro' ), $total ];

			// ── NPS summary ──
			if ( 'nps' === $type ) {
				$nps        = Results_Aggregator::categorize_nps_responses( $responses );
				$csv_rows[] = [ __( 'NPS Score', 'sureforms-pro' ), $nps['nps_score'] ];
				$csv_rows[] = [];
			}

			// ── Average for rating/number ──
			if ( isset( $field['average'] ) ) {
				$csv_rows[] = [ __( 'Average', 'sureforms-pro' ), $field['average'] ];
				$csv_rows[] = [];
			}

			// ── Option/Distribution breakdown ──
			$option_counts = isset( $field['option_counts'] ) && is_array( $field['option_counts'] ) ? $field['option_counts'] : [];
			$distribution  = isset( $field['distribution'] ) && is_array( $field['distribution'] ) ? $field['distribution'] : [];

			if ( ! empty( $option_counts ) ) {
				$csv_rows[] = [];
				$csv_rows[] = [ __( 'Option', 'sureforms-pro' ), __( 'Count', 'sureforms-pro' ), __( 'Percentage', 'sureforms-pro' ) ];
				foreach ( $option_counts as $option => $count ) {
					$pct        = $total > 0 ? round( $count / $total * 100 ) : 0;
					$csv_rows[] = [ $this->sanitize_csv_value( $option ), $count, $pct . '%' ];
				}
			} elseif ( ! empty( $distribution ) ) {
				$csv_rows[] = [];
				$header     = 'nps' === $type
					? __( 'Score', 'sureforms-pro' )
					: __( 'Value', 'sureforms-pro' );
				$csv_rows[] = [ $header, __( 'Count', 'sureforms-pro' ), __( 'Percentage', 'sureforms-pro' ) ];
				foreach ( $distribution as $value => $count ) {
					$pct        = $total > 0 ? round( intval( $count ) / $total * 100 ) : 0;
					$csv_rows[] = [ $this->sanitize_csv_value( $value ), $count, $pct . '%' ];
				}
			}

			// ── Individual responses ──
			if ( ! empty( $responses ) ) {
				$csv_rows[] = [];
				$csv_rows[] = [ '#', __( 'Response', 'sureforms-pro' ), __( 'Date', 'sureforms-pro' ) ];

				$entry_dates = $this->build_response_dates( $entries, $slug );
				foreach ( $responses as $idx => $response ) {
					$csv_rows[] = [
						$idx + 1,
						$this->sanitize_csv_value( is_scalar( $response ) ? strval( $response ) : '' ),
						$entry_dates[ $idx ] ?? '',
					];
				}
			}
		}

		return [
			'form_id'    => $form_id,
			'form_title' => (string) get_post_field( 'post_title', $form_id, 'raw' ),
			'csv_data'   => $csv_rows,
			'truncated'  => $aggregator->is_truncated(),
		];
	}

	/**
	 * Get drilldown data for a specific field value.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @since 2.8.0
	 * @return array<string,mixed>|WP_Error
	 */
	public function get_drilldown( WP_REST_Request $request ) {
		$form_id      = absint( $request->get_param( 'form_id' ) );
		$field_slug   = sanitize_text_field( Helper::get_string_value( $request->get_param( 'field_slug' ) ) );
		$filter_value = sanitize_text_field( Helper::get_string_value( $request->get_param( 'filter_value' ) ) );
		$filter_type  = sanitize_text_field( Helper::get_string_value( $request->get_param( 'filter_type' ) ) );
		$fields_param = sanitize_text_field( Helper::get_string_value( $request->get_param( 'fields' ) ) );
		$date_from    = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_from' ) ) );
		$date_to      = sanitize_text_field( Helper::get_string_value( $request->get_param( 'date_to' ) ) );
		$page         = absint( $request->get_param( 'page' ) );
		$page         = $page > 0 ? $page : 1;
		$per_page     = absint( $request->get_param( 'per_page' ) );
		$per_page     = $per_page > 0 ? $per_page : 20;

		if ( ! $form_id ) {
			return new WP_Error( 'invalid_form_id', __( 'Invalid form ID.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$error = $this->validate_survey_form( $form_id );
		if ( $error ) {
			return $error;
		}

		if ( empty( $field_slug ) || empty( $filter_value ) || empty( $fields_param ) ) {
			return new WP_Error( 'missing_params', __( 'Missing required parameters.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		$valid_filter_types = [ 'nps_category', 'exact', 'contains' ];
		if ( ! in_array( $filter_type, $valid_filter_types, true ) ) {
			$filter_type = 'exact';
		}

		$requested_slugs = array_map( 'sanitize_title', array_filter( explode( ',', $fields_param ) ) );

		if ( empty( $requested_slugs ) ) {
			return new WP_Error( 'no_fields', __( 'No fields specified.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		// Cap per_page to prevent abuse.
		$per_page = min( $per_page, 100 );

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		$result     = $aggregator->get_field_drilldown( $form_id, $field_slug, $filter_value, $filter_type, $requested_slugs, $page, $per_page, $date_from, $date_to );

		$result['truncated'] = $aggregator->is_truncated();

		return $result;
	}

	/**
	 * Validate that a form ID belongs to a published survey/poll form.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.8.0
	 * @return WP_Error|null WP_Error if invalid, null if valid.
	 */
	private function validate_survey_form( $form_id ) {
		if ( 'sureforms_form' !== get_post_type( $form_id ) ) {
			return new WP_Error( 'invalid_form', __( 'Invalid form.', 'sureforms-pro' ), [ 'status' => 404 ] );
		}

		if ( ! Init::is_survey_form( $form_id ) ) {
			return new WP_Error( 'not_survey', __( 'This form is not a survey or poll.', 'sureforms-pro' ), [ 'status' => 400 ] );
		}

		return null;
	}

	/**
	 * Sanitize a value for CSV export to prevent formula injection.
	 *
	 * Prefixes cells starting with a formula starter with a single quote so
	 * spreadsheet applications treat them as text.
	 *
	 * Numeric values return unchanged, matching free's Entries::escape_csv_formula().
	 * Without that, a negative distribution key — `-5` from a number, rating or slider
	 * field — exported as `'-5` and landed in the sheet as text rather than a number.
	 *
	 * The starter set matches src/admin/survey-reports/utils/csv.js and includes `|`
	 * for the DDE `|cmd` variant some LibreOffice builds evaluate, plus LF and a
	 * leading space. Those last two are not exploitable through the shipped download,
	 * because every cell is unconditionally wrapped in double quotes and importers only
	 * trim leading whitespace on unquoted fields — but that is a CSV parsing side
	 * effect, not a control, and it stops protecting the moment quoting becomes
	 * conditional. Consumers of the raw REST payload get no quoting at all.
	 *
	 * A leading apostrophe is deliberately absent from the set: the JS layer escapes
	 * this payload again, and adding `'` here would make an already-neutralised cell
	 * pick up a second apostrophe.
	 *
	 * @param mixed $value Cell value.
	 * @since 2.8.0
	 * @return string
	 */
	private function sanitize_csv_value( $value ) {
		$value = is_scalar( $value ) ? strval( $value ) : '';

		if ( '' === $value || is_numeric( $value ) ) {
			return $value;
		}

		if ( in_array( $value[0], [ '=', '+', '-', '@', "\t", "\r", "\n", ' ', '|' ], true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Build a list of dates for each response index of a field.
	 *
	 * Maps response index to the created_at date of the entry that produced it.
	 *
	 * @param array<int,array<string,mixed>> $entries    Raw entries.
	 * @param string                         $field_slug Field slug (prefix before -lbl-).
	 * @since 2.8.0
	 * @return array<int,string>
	 */
	private function build_response_dates( $entries, $field_slug ) {
		$dates = [];
		$idx   = 0;

		foreach ( $entries as $entry ) {
			$raw_data  = $entry['form_data'] ?? '';
			$form_data = is_string( $raw_data )
				? json_decode( $raw_data, true )
				: $raw_data;

			if ( ! is_array( $form_data ) ) {
				continue;
			}

			foreach ( $form_data as $key => $value ) {
				$extracted = sanitize_title( explode( '-lbl-', $key, 2 )[0] ?? $key );
				if ( $extracted === $field_slug ) {
					$created_at    = isset( $entry['created_at'] ) && is_scalar( $entry['created_at'] ) ? strval( $entry['created_at'] ) : '';
					$timestamp     = ! empty( $created_at ) ? strtotime( $created_at ) : false;
					$dates[ $idx ] = false !== $timestamp ? gmdate( 'Y-m-d H:i', $timestamp ) : '';
					++$idx;
					break;
				}
			}
		}

		return $dates;
	}

	/**
	 * Normalize aggregated results — convert fields from associative to indexed array.
	 *
	 * @param array<string,mixed> $results Raw aggregated results.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	private function normalize_results( $results ) {
		if ( empty( $results['fields'] ) || ! is_array( $results['fields'] ) ) {
			$results['fields'] = [];
			return $results;
		}

		$fields = [];
		foreach ( $results['fields'] as $slug => $field ) {
			$field['slug'] = $slug;
			$fields[]      = $field;
		}
		$results['fields'] = $fields;

		return $results;
	}
}
