<?php
/**
 * Survey Module Init.
 *
 * Bootstraps all survey sub-classes.
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Survey Init class.
 *
 * @since 2.8.0
 */
class Init {
	use Get_Instance;

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		Editor::get_instance();
		Results_Aggregator::get_instance();
		Results_Shortcode::get_instance();
		Survey_Smart_Tags::get_instance();
		Survey_Reports::get_instance();

		// Append live results to confirmation (priority 30 to run after quiz at default).
		add_filter( 'srfm_form_confirmation_data', [ $this, 'override_with_live_results' ], 30, 2 );

		// Force inline submission mode when live results are shown.
		add_filter( 'srfm_form_submission_response', [ $this, 'force_inline_submission_mode' ], 30, 2 );

		// Pre-load survey results CSS when a survey/poll form is rendered.
		add_action( 'srfm_localize_conditional_logic_data', [ $this, 'maybe_enqueue_results_styles' ] );

		// Flag analytics change when a survey form receives a submission or is saved.
		add_action( 'srfm_form_submit', [ $this, 'flag_survey_data_changed' ] );
		add_action( 'save_post_sureforms_form', [ $this, 'flag_survey_meta_changed' ], 10, 2 );
	}

	/**
	 * Get survey meta for a form.
	 *
	 * Decodes the _srfm_survey_meta JSON and returns the parsed array.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.8.0
	 * @return array{status:bool,show_live_results:bool}
	 */
	public static function get_survey_meta( $form_id ) {
		$defaults = [
			'status'            => false,
			'show_live_results' => false,
		];

		$raw = get_post_meta( absint( $form_id ), '_srfm_survey_meta', true );

		if ( empty( $raw ) || ! is_string( $raw ) ) {
			return $defaults;
		}

		$decoded = json_decode( $raw, true );

		if ( ! is_array( $decoded ) ) {
			return $defaults;
		}

		return [
			'status'            => ! empty( $decoded['status'] ),
			'show_live_results' => ! empty( $decoded['show_live_results'] ),
		];
	}

	/**
	 * Check if a form is in survey or poll mode.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.8.0
	 * @return bool
	 */
	public static function is_survey_form( $form_id ) {
		$meta = self::get_survey_meta( $form_id );
		return $meta['status'];
	}

	/**
	 * Flag that survey data changed when a survey form receives a submission.
	 *
	 * @param array<string,mixed> $response Form submit response data.
	 * @since 2.8.0
	 * @return void
	 */
	public function flag_survey_data_changed( $response ) {
		$form_id = isset( $response['form_id'] ) ? absint( $response['form_id'] ) : 0;
		if ( $form_id && self::is_survey_form( $form_id ) ) {
			set_transient( 'srfm_survey_data_changed', 1, MONTH_IN_SECONDS );
		}
	}

	/**
	 * Flag that survey data changed when a survey form is saved.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @since 2.8.0
	 * @return void
	 */
	public function flag_survey_meta_changed( $post_id, $post ) {
		if ( 'publish' !== $post->post_status ) {
			return;
		}

		if ( self::is_survey_form( $post_id ) ) {
			set_transient( 'srfm_survey_data_changed', 1, MONTH_IN_SECONDS );
		}
	}

	/**
	 * Enqueue survey results CSS for survey/poll forms with live results enabled.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.8.0
	 * @return void
	 */
	public function maybe_enqueue_results_styles( $form_id ) {
		$meta = self::get_survey_meta( absint( $form_id ) );

		if ( ! $meta['status'] || ! $meta['show_live_results'] ) {
			return;
		}

		Results_Shortcode::enqueue_results_assets();
	}

	/**
	 * Append live results to the confirmation message.
	 *
	 * @hooked srfm_form_confirmation_data
	 * @param array<mixed> $confirmation The confirmation data array.
	 * @param int          $form_id      The form ID.
	 * @since 2.8.0
	 * @return array<mixed>
	 */
	public function override_with_live_results( $confirmation, $form_id ) {
		$form_id = absint( $form_id );

		if ( ! $form_id || ! is_array( $confirmation ) ) {
			return $confirmation;
		}

		$meta = self::get_survey_meta( $form_id );

		if ( ! $meta['status'] || ! $meta['show_live_results'] ) {
			return $confirmation;
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Shortcode $shortcode */
		$shortcode = Results_Shortcode::get_instance();
		$output    = $shortcode->render_report_shortcode( [ 'id' => $form_id ] );

		// Only override if the output contains actual field results, not the
		// "No responses yet." fallback (which has no srfm-survey-field-result).
		if ( ! empty( $output ) && false !== strpos( $output, 'srfm-survey-field-result' ) && isset( $confirmation[0][0] ) ) {
			$existing = $confirmation[0][0]['message'] ?? '';

			// Append after quiz results when present; otherwise replace the
			// default confirmation so users see charts, not "Thank you!" text.
			if ( false !== strpos( $existing, 'srfm-quiz-results' ) ) {
				$confirmation[0][0]['message'] = $existing . $output;
			} else {
				$confirmation[0][0]['message'] = $output;
			}

			$confirmation[0][0]['confirmation_type'] = 'inline';
		}

		return $confirmation;
	}

	/**
	 * Force submission mode to 'same page' when live results are shown.
	 *
	 * The frontend JS uses submission_settings.submission_mode to decide
	 * whether to redirect or show the inline message. Without this override,
	 * a redirect confirmation type would cause the JS to skip showing results.
	 *
	 * @hooked srfm_form_submission_response
	 * @param array<string,mixed> $response  The form submission response.
	 * @param array<string,mixed> $form_data The submitted form data.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function force_inline_submission_mode( $response, $form_data ) {
		$form_id = ! empty( $form_data['form-id'] ) ? absint( $form_data['form-id'] ) : 0;

		if ( ! $form_id ) {
			return $response;
		}

		$meta = self::get_survey_meta( $form_id );

		if ( ! $meta['status'] || ! $meta['show_live_results'] ) {
			return $response;
		}

		// Force inline display so the JS shows the message instead of redirecting.
		$response['redirect_url'] = '';

		if ( ! isset( $response['data'] ) || ! is_array( $response['data'] ) ) {
			$response['data'] = [];
		}

		$response['data']['submission_settings'] = [
			'submission_mode'  => 'same page',
			'after_submission' => 'hide form',
		];

		return $response;
	}
}
