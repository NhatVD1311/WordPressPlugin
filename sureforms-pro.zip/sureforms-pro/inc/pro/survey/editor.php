<?php
/**
 * Survey Editor.
 *
 * Handles survey/poll post meta registration and sanitization for the editor.
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Survey Editor class.
 *
 * @since 2.8.0
 */
class Editor {
	use Get_Instance;

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		add_action( 'srfm_register_additional_post_meta', [ $this, 'register_post_metas' ] );
	}

	/**
	 * Register survey/poll post metas.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function register_post_metas() {
		register_post_meta(
			SRFM_FORMS_POST_TYPE,
			'_srfm_survey_meta',
			[
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => [
					'schema' => [
						'type'    => 'string',
						'context' => [ 'edit' ],
					],
				],
				'sanitize_callback' => [ self::class, 'sanitize_survey_meta' ],
				'auth_callback'     => static function () {
					return Helper::current_user_can();
				},
			]
		);
	}

	/**
	 * Sanitize survey meta data.
	 *
	 * @param mixed $data Raw meta value.
	 * @since 2.8.0
	 * @return string Sanitized JSON string or empty string.
	 */
	public static function sanitize_survey_meta( $data ) {
		if ( empty( $data ) || ! is_string( $data ) ) {
			return '';
		}

		$decoded = json_decode( $data, true );

		if ( ! is_array( $decoded ) || json_last_error() !== JSON_ERROR_NONE ) {
			return '';
		}

		$sanitized = [
			'status'            => isset( $decoded['status'] ) ? wp_validate_boolean( $decoded['status'] ) : false,
			'show_live_results' => isset( $decoded['show_live_results'] ) ? wp_validate_boolean( $decoded['show_live_results'] ) : false,
		];

		$return = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return $return ? $return : '';
	}
}
