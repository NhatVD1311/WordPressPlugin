<?php
/**
 * Results Shortcode.
 *
 * Renders [sureforms_survey_results id="FORM_ID"] shortcode with CSS-only charts.
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Results Shortcode class.
 *
 * @since 2.8.0
 */
class Results_Shortcode {
	use Get_Instance;

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		add_shortcode( 'sureforms_survey_results', [ $this, 'render_report_shortcode' ] );
	}

	/**
	 * Render the survey results shortcode.
	 *
	 * Supports optional `field` attribute to filter results by field type
	 * and optional `slug` attribute to filter by block slug.
	 *
	 * @param array<string,mixed>|string $atts Shortcode attributes.
	 * @since 2.8.0
	 * @return string
	 */
	public function render_report_shortcode( $atts ) {
		$atts = shortcode_atts(
			[
				'id'    => 0,
				'field' => '',
				'slug'  => '',
			],
			is_array( $atts ) ? $atts : [],
			'sureforms_survey_results'
		);

		$form_id = absint( $atts['id'] );

		// Both filters accept a comma-separated list of values.
		$parse_list = static function ( $raw ) {
			return array_values(
				array_filter(
					array_map(
						static function ( $item ) {
							return sanitize_text_field( trim( $item ) );
						},
						explode( ',', (string) $raw )
					),
					static function ( $item ) {
						return '' !== $item;
					}
				)
			);
		};

		$field_types = $parse_list( $atts['field'] ?? '' );
		$field_slugs = $parse_list( $atts['slug'] ?? '' );

		if ( ! $form_id ) {
			return '';
		}

		// Validate post type and publish status to prevent IDOR.
		if ( 'sureforms_form' !== get_post_type( $form_id ) || 'publish' !== get_post_status( $form_id ) ) {
			return '';
		}

		// Check if form is in survey/poll mode.
		if ( ! Init::is_survey_form( $form_id ) ) {
			return '';
		}

		// Respect the show_live_results setting; admins can always preview results.
		$meta = Init::get_survey_meta( $form_id );
		if ( ! $meta['show_live_results'] && ! Helper::current_user_can() ) {
			return '';
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		$results    = $aggregator->aggregate_public( $form_id );

		$fields          = isset( $results['fields'] ) && is_array( $results['fields'] ) ? $results['fields'] : [];
		$total_responses = isset( $results['total_responses'] ) && is_int( $results['total_responses'] ) ? $results['total_responses'] : 0;

		if ( empty( $fields ) ) {
			return '<div class="srfm-survey-results"><p>' . esc_html__( 'No responses yet.', 'sureforms-pro' ) . '</p></div>';
		}

		// Filter fields by type(s) if the field attribute is set.
		if ( ! empty( $field_types ) ) {
			$fields = array_filter(
				$fields,
				static function ( $field ) use ( $field_types ) {
					return is_array( $field ) && in_array( $field['type'] ?? '', $field_types, true );
				}
			);
		}

		// Filter fields by block slug(s) if the slug attribute is set.
		// Match against all slugs the field has ever used (handles slug edits).
		if ( ! empty( $field_slugs ) ) {
			$fields = array_filter(
				$fields,
				static function ( $field ) use ( $field_slugs ) {
					if ( ! is_array( $field ) ) {
						return false;
					}
					$all_slugs = isset( $field['block_slugs'] ) && is_array( $field['block_slugs'] ) ? $field['block_slugs'] : [];
					if ( array_intersect( $field_slugs, $all_slugs ) ) {
						return true;
					}
					return in_array( $field['block_slug'] ?? '', $field_slugs, true );
				}
			);
		}

		if ( empty( $fields ) ) {
			return '<div class="srfm-survey-results-empty">' . esc_html__( 'No responses yet.', 'sureforms-pro' ) . '</div>';
		}

		self::enqueue_results_assets();

		$output = '<div class="srfm-survey-results">';

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$output .= $this->render_field_results( $field, $total_responses );
		}

		$output .= '</div>';

		return $output;
	}

	/**
	 * Enqueue frontend styles and scripts for results display.
	 *
	 * Shared by shortcode rendering and CSS pre-loading in Init.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public static function enqueue_results_assets() {
		$file_prefix = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? '' : '.min';
		$dir_name    = defined( 'SRFM_DEBUG' ) && SRFM_DEBUG ? 'unminified' : 'minified';
		$rtl         = is_rtl() ? '-rtl' : '';
		$css_uri     = SRFM_PRO_URL . 'assets/css/' . $dir_name . '/';

		wp_enqueue_style(
			SRFM_PRO_SLUG . '-survey-results',
			$css_uri . 'frontend/survey-results' . $file_prefix . $rtl . '.css',
			[],
			SRFM_PRO_VER
		);

		$asset_handle      = 'surveyResultsFrontend';
		$script_asset_path = SRFM_PRO_DIR . 'dist/' . $asset_handle . '.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => SRFM_PRO_VER,
			];

		wp_enqueue_script(
			SRFM_PRO_SLUG . '-' . $asset_handle,
			SRFM_PRO_URL . 'dist/' . $asset_handle . '.js',
			$script_info['dependencies'],
			$script_info['version'],
			true
		);
	}

	/**
	 * Render results for a single field.
	 *
	 * @param array<string,mixed> $field           Field aggregation data.
	 * @param int                 $total_responses Total form responses.
	 * @since 2.8.0
	 * @return string
	 */
	public function render_field_results( $field, $total_responses ) {
		$type    = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : 'text';
		$label   = isset( $field['label'] ) && is_string( $field['label'] ) ? $field['label'] : '';
		$output  = '<table class="srfm-survey-field-result" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom:24px;border:1px solid #e5e7eb;border-radius:8px;background-color:#ffffff;border-collapse:separate;">';
		$output .= '<tr><td style="padding:16px;">';
		$output .= '<h4 class="srfm-survey-field-label" style="font-size:15px;font-weight:500;color:#111827;margin:0 0 12px;">' . esc_html( $label ) . '</h4>';

		$option_counts   = isset( $field['option_counts'] ) && is_array( $field['option_counts'] ) ? $field['option_counts'] : [];
		$distribution    = isset( $field['distribution'] ) && is_array( $field['distribution'] ) ? $field['distribution'] : [];
		$field_responses = isset( $field['total_responses'] ) && is_int( $field['total_responses'] ) ? $field['total_responses'] : 0;

		if ( in_array( $type, [ 'multi-choice', 'dropdown', 'checkbox', 'slider' ], true ) && ! empty( $option_counts ) ) {
			$output .= $this->render_bar_chart( $option_counts, $total_responses );
		} elseif ( 'nps' === $type && ! empty( $distribution ) ) {
			$output .= $this->render_nps_bar( $field );
		} elseif ( 'rating' === $type && isset( $field['average'] ) ) {
			$output .= '<table cellpadding="0" cellspacing="0" border="0" style="margin-bottom:12px;"><tr>';
			$output .= '<td style="font-size:28px;font-weight:600;color:#111827;vertical-align:baseline;padding-right:8px;">' . esc_html( Helper::get_string_value( $field['average'] ) ) . '</td>';
			$output .= '<td style="font-size:14px;color:#6b7280;vertical-align:baseline;">' . esc_html__( 'average rating', 'sureforms-pro' ) . '</td>';
			$output .= '</tr></table>';
			if ( ! empty( $distribution ) ) {
				$output .= $this->render_bar_chart( $distribution, max( 1, $field_responses ) );
			}
		} else {
			$output .= '<p class="srfm-survey-text-label" style="font-size:14px;color:#6b7280;margin:0 0 12px;">' . sprintf(
				/* translators: %d: number of text responses. */
				esc_html( _n( '%d text response collected', '%d text responses collected', $field_responses, 'sureforms-pro' ) ),
				$field_responses
			) . '</p>';

			// Show latest 3 responses when available.
			if ( isset( $field['responses'] ) && is_array( $field['responses'] ) && ! empty( $field['responses'] ) ) {
				$latest_responses = array_slice( array_reverse( $field['responses'] ), 0, 3 );
				foreach ( $latest_responses as $response ) {
					$output .= '<div class="srfm-survey-text-response" style="padding:12px 16px;background-color:#f9fafb;border-radius:6px;font-size:14px;color:#111827;line-height:1.5;margin-bottom:8px;">' . esc_html( $response ) . '</div>';
				}
			}
		}

		return $output . '</td></tr></table>';
	}

	/**
	 * Render a CSS-only horizontal bar chart.
	 *
	 * @param array<string,int> $option_counts Option counts.
	 * @param int               $total         Total responses for percentage.
	 * @since 2.8.0
	 * @return string
	 */
	private function render_bar_chart( $option_counts, $total ) {
		$total  = max( 1, $total );
		$output = '<div class="srfm-survey-bar-chart" style="display:flex;flex-direction:column;gap:8px;">';

		foreach ( $option_counts as $option => $count ) {
			$pct     = round( $count / $total * 100 );
			$output .= '<div class="srfm-survey-bar-row" style="display:flex;align-items:center;gap:8px;">';
			$output .= '<span class="srfm-survey-bar-label" style="width:160px;min-width:160px;font-size:13px;color:#4b5563;overflow-wrap:break-word;">' . esc_html( $option ) . '</span>';
			$output .= '<div class="srfm-survey-bar-track" style="flex:1;height:20px;background-color:#f3f4f6;border-radius:4px;overflow:hidden;">';
			$output .= '<div class="srfm-survey-bar-fill" style="height:100%;background-color:#fcbfa5;border-radius:4px;min-width:2px;width:' . esc_attr( $pct . '%' ) . '">&nbsp;</div>';
			$output .= '</div>';
			$output .= '<span class="srfm-survey-bar-count" style="min-width:24px;text-align:right;font-size:13px;color:#6b7280;">' . absint( $count ) . '</span> ';
			$output .= '<span class="srfm-survey-bar-pct" style="min-width:36px;text-align:right;font-size:13px;font-weight:500;color:#374151;">' . absint( $pct ) . '%</span>';
			$output .= '</div>';
		}

		$output .= '</div>';

		return $output;
	}

	/**
	 * Render NPS segmented bar.
	 *
	 * @param array<string,mixed> $field NPS field data.
	 * @since 2.8.0
	 * @return string
	 */
	private function render_nps_bar( $field ) {
		// Use pre-computed distribution when raw responses are stripped (public mode).
		$distribution = isset( $field['distribution'] ) && is_array( $field['distribution'] ) ? $field['distribution'] : [];
		$responses    = isset( $field['responses'] ) && is_array( $field['responses'] ) ? $field['responses'] : [];

		if ( ! empty( $responses ) ) {
			$nps_data = Results_Aggregator::categorize_nps_responses( $responses );
		} else {
			// Reconstruct from distribution: keys are score strings, values are counts.
			$promoters  = 0;
			$passives   = 0;
			$detractors = 0;
			$total      = 0;
			foreach ( $distribution as $score_str => $count ) {
				// Skip empty keys — unanswered NPS fields.
				if ( '' === (string) $score_str ) {
					continue;
				}
				$score  = absint( $score_str );
				$cnt    = absint( $count );
				$total += $cnt;
				if ( $score >= 9 ) {
					$promoters += $cnt;
				} elseif ( $score >= 7 ) {
					$passives += $cnt;
				} else {
					$detractors += $cnt;
				}
			}
			$nps_score = $total > 0
				? intval( round( $promoters / $total * 100 ) - round( $detractors / $total * 100 ) )
				: 0;
			$nps_data  = [
				'promoters'  => $promoters,
				'passives'   => $passives,
				'detractors' => $detractors,
				'nps_score'  => $nps_score,
				'total'      => $total,
			];
		}

		$total        = max( 1, $nps_data['total'] );
		$promoters    = $nps_data['promoters'];
		$passives     = $nps_data['passives'];
		$detractors   = $nps_data['detractors'];
		$nps_score    = $nps_data['nps_score'];
		$promoter_pct = round( $promoters / $total * 100 );
		$passive_pct  = round( $passives / $total * 100 );
		$detract_pct  = round( $detractors / $total * 100 );

		$output  = '<div class="srfm-survey-nps">';
		$output .= '<p style="font-size:14px;color:#374151;margin:0 0 8px;">' . esc_html__( 'NPS Score:', 'sureforms-pro' ) . ' <strong style="font-size:20px;">' . intval( $nps_score ) . '</strong></p>';

		// NPS segmented bar — table-based for email compatibility.
		$output .= '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:separate;border-radius:6px;overflow:hidden;margin-bottom:8px;"><tr style="height:28px;">';
		if ( $detract_pct > 0 ) {
			$output .= '<td style="background-color:#ef4444;color:#ffffff;font-size:12px;font-weight:500;text-align:center;vertical-align:middle;width:' . esc_attr( $detract_pct . '%' ) . '" title="' . esc_attr__( 'Detractors', 'sureforms-pro' ) . '">' . absint( $detract_pct ) . '%</td>';
		}
		if ( $passive_pct > 0 ) {
			$output .= '<td style="background-color:#f59e0b;color:#ffffff;font-size:12px;font-weight:500;text-align:center;vertical-align:middle;width:' . esc_attr( $passive_pct . '%' ) . '" title="' . esc_attr__( 'Passives', 'sureforms-pro' ) . '">' . absint( $passive_pct ) . '%</td>';
		}
		if ( $promoter_pct > 0 ) {
			$output .= '<td style="background-color:#10b981;color:#ffffff;font-size:12px;font-weight:500;text-align:center;vertical-align:middle;width:' . esc_attr( $promoter_pct . '%' ) . '" title="' . esc_attr__( 'Promoters', 'sureforms-pro' ) . '">' . absint( $promoter_pct ) . '%</td>';
		}
		$output .= '</tr></table>';

		// Legend — CSS classes for frontend, Unicode dot + inline styles for email.
		// The dot span contains &#9679; so email clients don't collapse it.
		// On frontend, SCSS sizes the dot via width/height and hides overflow.
		$output .= '<div class="srfm-survey-nps-legend" style="display:flex;gap:16px;flex-wrap:wrap;margin-top:4px;">';
		$output .= '<span class="srfm-nps-legend-item" style="display:inline-flex;align-items:center;gap:4px;font-size:13px;color:#4b5563;margin-right:16px;"><span class="srfm-nps-dot srfm-nps-detractor-bg" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:#ef4444;vertical-align:middle;font-size:10px;line-height:10px;color:#ef4444;overflow:hidden;">&#9679;</span> ' . esc_html__( 'Detractors', 'sureforms-pro' ) . ' (' . absint( $detractors ) . ')</span>';
		$output .= '<span class="srfm-nps-legend-item" style="display:inline-flex;align-items:center;gap:4px;font-size:13px;color:#4b5563;margin-right:16px;"><span class="srfm-nps-dot srfm-nps-passive-bg" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:#f59e0b;vertical-align:middle;font-size:10px;line-height:10px;color:#f59e0b;overflow:hidden;">&#9679;</span> ' . esc_html__( 'Passives', 'sureforms-pro' ) . ' (' . absint( $passives ) . ')</span>';
		$output .= '<span class="srfm-nps-legend-item" style="display:inline-flex;align-items:center;gap:4px;font-size:13px;color:#4b5563;"><span class="srfm-nps-dot srfm-nps-promoter-bg" style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:#10b981;vertical-align:middle;font-size:10px;line-height:10px;color:#10b981;overflow:hidden;">&#9679;</span> ' . esc_html__( 'Promoters', 'sureforms-pro' ) . ' (' . absint( $promoters ) . ')</span>';
		$output .= '</div></div>';

		return $output;
	}
}
