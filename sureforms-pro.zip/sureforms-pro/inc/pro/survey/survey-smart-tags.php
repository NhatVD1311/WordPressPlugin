<?php
/**
 * Survey Smart Tags.
 *
 * Registers and resolves smart tags for survey/poll results.
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Survey Smart Tags class.
 *
 * @since 2.8.0
 */
class Survey_Smart_Tags {
	use Get_Instance;

	/**
	 * Whether to hide survey tags from the block editor smart tag picker.
	 *
	 * @since 2.8.0
	 * @var bool
	 */
	private bool $hide_from_editor = false;

	/**
	 * Whether to include the current in-flight submission in aggregation.
	 *
	 * True during email notification rendering (before entry save). Set to
	 * false by the srfm_before_entry_data filter, which fires right before
	 * Entries::add() — ensuring confirmation smart tags use the DB (which
	 * now includes the saved entry) instead of double-counting.
	 *
	 * @since 2.8.0
	 * @var bool
	 */
	private bool $include_in_flight_submission = true;

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		add_filter( 'srfm_smart_tag_list', [ $this, 'add_survey_smart_tags' ] );
		add_filter( 'srfm_parse_smart_tags', [ $this, 'parse_survey_smart_tags' ], 20, 2 );
		add_filter( 'srfm_is_valid_smart_tag', [ $this, 'validate_dynamic_survey_tag' ], 10, 2 );
		add_filter( 'srfm_is_smart_tag_value_verified_as_array', [ $this, 'allow_array_value_for_integrations' ], 10, 2 );

		// Hide survey tags from the editor smart tag picker.
		// Core localizes at priority 10 on enqueue_block_editor_assets.
		add_action( 'enqueue_block_editor_assets', [ $this, 'set_hide_from_editor' ], 9 );
		add_action( 'enqueue_block_editor_assets', [ $this, 'unset_hide_from_editor' ], 11 );

		// Track whether the current submission has been saved to the DB.
		// Before entry save: include in-flight submission in aggregation (for emails).
		// After entry save: let the DB handle it (for confirmations).
		add_action( 'srfm_before_submission', [ $this, 'on_before_submission' ] );
		add_filter( 'srfm_before_entry_data', [ $this, 'on_before_entry_save' ] );
	}

	/**
	 * Reset the in-flight flag at the start of each form submission.
	 *
	 * Hooked to srfm_before_submission which fires before send_email(),
	 * ensuring email smart tags can include the current submission.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function on_before_submission() {
		$this->include_in_flight_submission = true;
	}

	/**
	 * Clear the in-flight flag right before the entry is persisted.
	 *
	 * Hooked to srfm_before_entry_data which fires after send_email()
	 * but before Entries::add(). After this point, the DB contains the
	 * entry and aggregate_public() will include it automatically.
	 *
	 * @param array<string,mixed> $entries_data Entry data about to be saved.
	 * @since 2.8.0
	 * @return array<string,mixed> Unmodified entry data (passthrough filter).
	 */
	public function on_before_entry_save( $entries_data ) {
		$this->include_in_flight_submission = false;
		return $entries_data;
	}

	/**
	 * Set flag to hide survey smart tags before editor localization.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function set_hide_from_editor() {
		$this->hide_from_editor = true;
	}

	/**
	 * Unset flag after editor localization so tags work on frontend.
	 *
	 * @since 2.8.0
	 * @return void
	 */
	public function unset_hide_from_editor() {
		$this->hide_from_editor = false;
	}

	/**
	 * Allow {survey_results:*} tags to pass core's smart tag validation.
	 *
	 * @param bool   $is_valid Whether the tag is valid.
	 * @param string $tag      The smart tag.
	 * @since 2.8.0
	 * @return bool
	 */
	public function validate_dynamic_survey_tag( $is_valid, $tag ) {
		if ( $is_valid || ! is_string( $tag ) ) {
			return $is_valid;
		}

		if ( 0 === strpos( $tag, '{survey-form:' ) ) {
			return true;
		}

		return $is_valid;
	}

	/**
	 * Register survey smart tags.
	 *
	 * @param array<string,string> $tags Existing smart tags.
	 * @since 2.8.0
	 * @return array<string,string>
	 */
	public function add_survey_smart_tags( $tags ) {
		if ( $this->hide_from_editor ) {
			return $tags;
		}

		$tags['{poll_results}'] = __( 'All Survey Results', 'sureforms-pro' );

		return $tags;
	}

	/**
	 * Resolve survey smart tags.
	 *
	 * Uses aggregate_public() to work in public (unauthenticated) context.
	 *
	 * @param mixed               $parsed  Previously parsed value.
	 * @param array<string,mixed> $context Smart tag context.
	 * @since 2.8.0
	 * @return mixed
	 */
	public function parse_survey_smart_tags( $parsed, $context ) {
		$tag     = isset( $context['tag'] ) && is_string( $context['tag'] ) ? $context['tag'] : '';
		$form_id = $this->get_form_id_from_context( $context );

		if ( ! $form_id || ! Init::is_survey_form( $form_id ) ) {
			return $parsed;
		}

		// In integration context (Webhook, OttoKit, Native Integrations) emit a
		// structured array payload that survives wp_json_encode(); fall back to
		// the HTML bar-chart for emails, confirmations, and on-page renders.
		$is_integration = $this->is_integration_context( $context );

		// When smart tags are resolved before Entries::add() (e.g. during email
		// notification rendering), the current submission is not yet in the DB.
		// Pass it as a pending entry so aggregate_public() includes it, keeping
		// email results consistent with the post-save confirmation results.
		//
		// Integrations always resolve AFTER the entry is persisted (the async
		// after-submission request), so the DB already contains it — never add it
		// again, or total_responses double-counts (e.g. shows 2 on the first
		// submission). That request also doesn't fire the hooks that would reset
		// the in-flight flag, so guard explicitly on integration context here.
		$pending_entry = [];
		if ( $this->include_in_flight_submission && ! $is_integration ) {
			$pending_entry = isset( $context['submission_data'] ) && is_array( $context['submission_data'] ) ? $context['submission_data'] : [];
		}

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Aggregator $aggregator */
		$aggregator = Results_Aggregator::get_instance();
		$results    = $aggregator->aggregate_public( $form_id, $pending_entry );
		$fields     = isset( $results['fields'] ) && is_array( $results['fields'] ) ? $results['fields'] : [];

		$total_responses = isset( $results['total_responses'] ) && is_int( $results['total_responses'] ) ? $results['total_responses'] : 0;

		if ( '{poll_results}' === $tag ) {
			return $is_integration
				? $this->build_all_fields_payload( $fields, $total_responses )
				: $this->render_all_fields( $fields, $total_responses );
		}

		// Handle dynamic {survey-form:field_slug} tags.
		if ( is_string( $tag ) && 0 === strpos( $tag, '{survey-form:' ) ) {
			return $is_integration
				? $this->build_single_field_payload( $tag, $fields, '{survey-form:' )
				: $this->render_single_field( $tag, $fields, $total_responses, '{survey-form:' );
		}

		return $parsed;
	}

	/**
	 * Allow Smart_Tags::process_smart_tags() to return our array payloads
	 * unchanged (instead of casting them to the literal string "Array").
	 *
	 * Only verifies array values produced by {poll_results} or
	 * {survey-form:*} — leaves repeater and other handlers alone.
	 *
	 * @param bool                $is_verified Current verification state.
	 * @param array<string,mixed> $args        Filter args (tag, value, ...).
	 * @since 2.10.0
	 * @return bool
	 */
	public function allow_array_value_for_integrations( $is_verified, $args ) {
		if ( $is_verified ) {
			return $is_verified;
		}

		$tag   = isset( $args['tag'] ) && is_string( $args['tag'] ) ? $args['tag'] : '';
		$value = $args['value'] ?? null;

		if ( ! is_array( $value ) ) {
			return $is_verified;
		}

		if ( '{poll_results}' === $tag || 0 === strpos( $tag, '{survey-form:' ) ) {
			return true;
		}

		return $is_verified;
	}

	/**
	 * Render all fields using the shortcode bar-chart renderer.
	 *
	 * Produces the same HTML as [sureforms_survey_results] — CSS bar charts
	 * with labels, counts, and percentages for each field.
	 *
	 * @param array<string,mixed> $fields          Aggregated fields.
	 * @param int                 $total_responses Total form responses.
	 * @since 2.8.0
	 * @return string
	 */
	private function render_all_fields( $fields, $total_responses ) {
		if ( empty( $fields ) ) {
			return '';
		}

		Results_Shortcode::enqueue_results_assets();

		// phpcs:ignore Generic.Commenting.DocComment.MissingShort
		/** @var Results_Shortcode $renderer */
		$renderer = Results_Shortcode::get_instance();
		$output   = '<div class="srfm-survey-results">';

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$output .= $renderer->render_field_results( $field, $total_responses );
		}

		return $output . '</div>';
	}

	/**
	 * Render a single field's results using the shortcode bar-chart renderer.
	 *
	 * Matches the field by block_slug or block_slugs history, then delegates
	 * to the same render_field_results() used by the shortcode.
	 *
	 * @param string              $tag             The smart tag.
	 * @param array<string,mixed> $fields          Aggregated fields.
	 * @param int                 $total_responses Total form responses.
	 * @param string              $prefix          Tag prefix to strip.
	 * @since 2.8.0
	 * @return string
	 */
	private function render_single_field( $tag, $fields, $total_responses, $prefix = '{survey-form:' ) {
		$field_slug = sanitize_title( substr( $tag, strlen( $prefix ), -1 ) );

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$block_slug  = isset( $field['block_slug'] ) && is_string( $field['block_slug'] ) ? $field['block_slug'] : '';
			$block_slugs = isset( $field['block_slugs'] ) && is_array( $field['block_slugs'] ) ? $field['block_slugs'] : [];

			if ( $block_slug !== $field_slug && ! in_array( $field_slug, $block_slugs, true ) ) {
				continue;
			}

			Results_Shortcode::enqueue_results_assets();

			// phpcs:ignore Generic.Commenting.DocComment.MissingShort
			/** @var Results_Shortcode $renderer */
			$renderer = Results_Shortcode::get_instance();
			return '<div class="srfm-survey-results">' . $renderer->render_field_results( $field, $total_responses ) . '</div>';
		}

		return '';
	}

	/**
	 * Extract form ID from smart tag context.
	 *
	 * @param array<string,mixed> $context Smart tag context.
	 * @since 2.8.0
	 * @return int
	 */
	private function get_form_id_from_context( $context ) {
		$form_data = isset( $context['form_data'] ) && is_array( $context['form_data'] ) ? $context['form_data'] : [];

		if ( ! empty( $form_data['form-id'] ) ) {
			return absint( $form_data['form-id'] );
		}

		return 0;
	}

	/**
	 * Detect that the smart tag is being resolved for an integration payload
	 * (Webhook, OttoKit, Native Integrations) rather than email/confirmation HTML.
	 *
	 * @param array<string,mixed> $context Smart tag context.
	 * @since 2.10.0
	 * @return bool
	 */
	private function is_integration_context( $context ) {
		$form_data = isset( $context['form_data'] ) && is_array( $context['form_data'] ) ? $context['form_data'] : [];

		return ! empty( $form_data['_is_webhook_processing'] ) || ! empty( $form_data['_is_integration_processing'] );
	}

	/**
	 * Convert a single aggregated field into the rich-object payload sent to
	 * webhooks/integrations.
	 *
	 * Shape:
	 *   [
	 *     'type'    => 'multi-choice|nps|rating|number|...',
	 *     'label'   => 'Favorite color',
	 *     'total'   => 8,
	 *     'options' => [
	 *       [ 'value' => 'Red',  'count' => 5, 'percent' => 62.5 ],
	 *       ...
	 *     ],
	 *     'average' => 4.3,   // numeric fields only.
	 *   ]
	 *
	 * Security/PII boundary: this reads ONLY aggregated keys (option_counts,
	 * distribution, average, total_responses). It must never read the raw
	 * `responses[]` array — doing so would leak individual free-text answers
	 * (PII) to third-party integration endpoints. Keep it aggregate-only.
	 *
	 * @param array<string,mixed> $field Aggregated field row from Results_Aggregator.
	 * @since 2.10.0
	 * @return array<string,mixed>
	 */
	private function build_field_payload( $field ) {
		$type  = isset( $field['type'] ) && is_scalar( $field['type'] ) ? (string) $field['type'] : 'text';
		$label = isset( $field['label'] ) && is_scalar( $field['label'] ) ? (string) $field['label'] : '';
		$total = isset( $field['total_responses'] ) && is_numeric( $field['total_responses'] ) ? (int) $field['total_responses'] : 0;

		$payload = [
			'type'  => $type,
			'label' => $label,
			'total' => $total,
		];

		$source = [];
		if ( isset( $field['option_counts'] ) && is_array( $field['option_counts'] ) ) {
			$source = $field['option_counts'];
		} elseif ( isset( $field['distribution'] ) && is_array( $field['distribution'] ) ) {
			$source = $field['distribution'];
		}

		$options = [];
		foreach ( $source as $value => $count ) {
			$count_int = (int) $count;
			$options[] = [
				'value'   => (string) $value,
				'count'   => $count_int,
				'percent' => $total > 0 ? round( $count_int / $total * 100, 2 ) : 0,
			];
		}
		$payload['options'] = $options;

		if ( isset( $field['average'] ) && is_numeric( $field['average'] ) ) {
			$payload['average'] = (float) $field['average'];
		}

		return $payload;
	}

	/**
	 * Build the payload for a single {survey-form:field_slug} tag.
	 *
	 * @param string                  $tag    The smart tag (e.g. '{survey-form:my-field}').
	 * @param array<int|string,mixed> $fields Aggregated fields keyed by slug.
	 * @param string                  $prefix Tag prefix to strip (e.g. '{survey-form:').
	 * @since 2.10.0
	 * @return array<string,mixed>
	 */
	private function build_single_field_payload( $tag, $fields, $prefix = '{survey-form:' ) {
		$field_slug = sanitize_title( substr( $tag, strlen( $prefix ), -1 ) );

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$block_slug  = isset( $field['block_slug'] ) && is_string( $field['block_slug'] ) ? $field['block_slug'] : '';
			$block_slugs = isset( $field['block_slugs'] ) && is_array( $field['block_slugs'] ) ? $field['block_slugs'] : [];

			if ( $block_slug === $field_slug || in_array( $field_slug, $block_slugs, true ) ) {
				return $this->build_field_payload( $field );
			}
		}

		// No match — return an empty-but-valid shape so the integration receives
		// a predictable JSON object instead of null.
		return [
			'type'    => '',
			'label'   => '',
			'total'   => 0,
			'options' => [],
		];
	}

	/**
	 * Build the {poll_results} payload covering every aggregated field.
	 *
	 * @param array<int|string,mixed> $fields          Aggregated fields keyed by slug.
	 * @param int                     $total_responses Total form responses.
	 * @since 2.10.0
	 * @return array<string,mixed>
	 */
	private function build_all_fields_payload( $fields, $total_responses ) {
		// Free-text fields (text/input, textarea, number) don't aggregate into
		// survey/poll results, so they are excluded from the integration payload.
		$excluded_types = [ 'input', 'text', 'textarea', 'number' ];

		$payload = [
			'total_responses' => (int) $total_responses,
			'fields'          => [],
		];

		foreach ( $fields as $slug => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$field_type = isset( $field['type'] ) && is_scalar( $field['type'] ) ? (string) $field['type'] : '';
			if ( in_array( $field_type, $excluded_types, true ) ) {
				continue;
			}
			$key = is_string( $slug ) ? $slug : ( isset( $field['block_slug'] ) && is_string( $field['block_slug'] ) ? $field['block_slug'] : '' );
			if ( '' === $key ) {
				continue;
			}
			$payload['fields'][ $key ] = $this->build_field_payload( $field );
		}

		return $payload;
	}
}
