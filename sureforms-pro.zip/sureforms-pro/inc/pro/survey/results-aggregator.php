<?php
/**
 * Survey Results Aggregator.
 *
 * Computes aggregations from existing wp_srfm_entries table with per-request memoization.
 *
 * @since 2.8.0
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Survey;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Results Aggregator class.
 *
 * @since 2.8.0
 */
class Results_Aggregator {
	use Get_Instance;

	/**
	 * Maximum number of entries to load into memory.
	 *
	 * @since 2.8.0
	 */
	private const MAX_ENTRIES = 10000;

	/**
	 * Whether the last get_form_entries() call was truncated at MAX_ENTRIES.
	 *
	 * @since 2.8.0
	 * @var bool
	 */
	private bool $is_truncated = false;

	/**
	 * Number of entries that contributed at least one real field in the last
	 * build_field_data() call. Used as the response count so internal-only
	 * entries (e.g. carrying just entry_id / _is_webhook_processing) are not
	 * counted as responses.
	 *
	 * @since 2.10.0
	 * @var int
	 */
	private int $counted_responses = 0;

	/**
	 * Constructor.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
	}

	/**
	 * Aggregate results for a form.
	 *
	 * @param int    $form_id   Form ID.
	 * @param string $date_from Start date filter (YYYY-MM-DD).
	 * @param string $date_to   End date filter (YYYY-MM-DD).
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function aggregate( $form_id, $date_from = '', $date_to = '' ) {
		$form_id   = absint( $form_id );
		$date_from = $this->validate_date( $date_from );
		$date_to   = $this->validate_date( $date_to );

		if ( ! Helper::current_user_can() ) {
			return [
				'form_id'         => $form_id,
				'total_responses' => 0,
				'fields'          => [],
			];
		}

		$entries = $this->get_form_entries( $form_id, $date_from, $date_to );

		if ( empty( $entries ) ) {
			return [
				'form_id'         => $form_id,
				'total_responses' => 0,
				'fields'          => [],
			];
		}

		$field_data        = $this->build_field_data( $entries );
		$field_data        = $this->sync_block_slugs_with_post_content( $form_id, $field_data );
		$aggregated_fields = [];

		foreach ( $field_data as $slug => $data ) {
			$aggregated_fields[ $slug ] = $this->aggregate_field( $data );
		}

		return [
			'form_id'         => $form_id,
			'total_responses' => $this->counted_responses,
			'fields'          => $aggregated_fields,
		];
	}

	/**
	 * Aggregate results for public display.
	 *
	 * Skips capability check (for shortcode/live results) but strips raw text
	 * responses to prevent PII exposure. Only returns aggregated counts/averages.
	 *
	 * @param int                 $form_id       Form ID.
	 * @param array<string,mixed> $pending_entry Optional in-flight submission data to include
	 *                                           in aggregation before the entry is saved to DB.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function aggregate_public( $form_id, $pending_entry = [] ) {
		$form_id = absint( $form_id );
		$entries = $this->get_form_entries( $form_id );

		// Include an in-flight submission that has not yet been persisted.
		// This is used during email notification rendering where smart tags
		// are resolved before Entries::add() saves the row to the database.
		if ( ! empty( $pending_entry ) ) {
			$entries[] = [ 'form_data' => $pending_entry ];
		}

		if ( empty( $entries ) ) {
			return [
				'form_id'         => $form_id,
				'total_responses' => 0,
				'fields'          => [],
			];
		}

		$field_data        = $this->build_field_data( $entries );
		$field_data        = $this->sync_block_slugs_with_post_content( $form_id, $field_data );
		$aggregated_fields = [];

		foreach ( $field_data as $slug => $data ) {
			$aggregated = $this->aggregate_field( $data );
			// Strip raw responses for public display to minimize PII exposure.
			// For numeric types (NPS, rating, etc.) remove responses entirely so
			// the shortcode renderer uses the complete distribution counts instead.
			if ( isset( $aggregated['responses'] ) && is_array( $aggregated['responses'] ) ) {
				$type = isset( $aggregated['type'] ) && is_string( $aggregated['type'] ) ? $aggregated['type'] : '';
				if ( in_array( $type, [ 'nps', 'rating', 'number', 'slider' ], true ) ) {
					$aggregated['responses'] = [];
				} else {
					$aggregated['responses'] = array_slice( $aggregated['responses'], -3 );
				}
			}
			$aggregated_fields[ $slug ] = $aggregated;
		}

		return [
			'form_id'         => $form_id,
			'total_responses' => $this->counted_responses,
			'fields'          => $aggregated_fields,
		];
	}

	/**
	 * Categorize NPS responses into promoters, passives, and detractors.
	 *
	 * @param array<int,string|int> $responses Array of NPS score values (0–10).
	 * @since 2.8.0
	 * @return array{promoters:int,passives:int,detractors:int,nps_score:int,total:int}
	 */
	public static function categorize_nps_responses( array $responses ) {
		$promoters  = 0;
		$passives   = 0;
		$detractors = 0;
		$total      = count( $responses );

		if ( 0 === $total ) {
			return [
				'promoters'  => 0,
				'passives'   => 0,
				'detractors' => 0,
				'nps_score'  => 0,
				'total'      => 0,
			];
		}

		$skipped = 0;
		foreach ( $responses as $value ) {
			// Skip empty/blank responses — they are unanswered, not detractors.
			if ( '' === $value || null === $value ) {
				++$skipped;
				continue;
			}
			$score = absint( $value );
			if ( $score >= 9 ) {
				++$promoters;
			} elseif ( $score >= 7 ) {
				++$passives;
			} else {
				++$detractors;
			}
		}

		$total -= $skipped;

		$nps_score = $total > 0
			? round( $promoters / $total * 100 ) - round( $detractors / $total * 100 )
			: 0;

		return [
			'promoters'  => $promoters,
			'passives'   => $passives,
			'detractors' => $detractors,
			'nps_score'  => intval( $nps_score ),
			'total'      => $total,
		];
	}

	/**
	 * Get NPS breakdown for a form.
	 *
	 * @param int $form_id Form ID.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function get_nps_breakdown( $form_id ) {
		$form_id = absint( $form_id );
		$results = $this->aggregate( $form_id );

		$fields = isset( $results['fields'] ) && is_array( $results['fields'] ) ? $results['fields'] : [];

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$type = isset( $field['type'] ) ? strval( $field['type'] ) : '';
			if ( 'nps' !== $type ) {
				continue;
			}

			$responses = isset( $field['responses'] ) && is_array( $field['responses'] ) ? $field['responses'] : [];
			return self::categorize_nps_responses( $responses );
		}

		return [
			'promoters'  => 0,
			'passives'   => 0,
			'detractors' => 0,
			'nps_score'  => 0,
			'total'      => 0,
		];
	}

	/**
	 * Get per-field aggregation results.
	 *
	 * @param int    $form_id    Form ID.
	 * @param string $field_slug Field slug to get results for.
	 * @since 2.8.0
	 * @return array<string,mixed>|null
	 */
	public function get_field_results( $form_id, $field_slug ) {
		$form_id    = absint( $form_id );
		$field_slug = sanitize_text_field( $field_slug );
		$results    = $this->aggregate( $form_id );

		$fields = isset( $results['fields'] ) && is_array( $results['fields'] ) ? $results['fields'] : [];

		if ( ! isset( $fields[ $field_slug ] ) ) {
			return null;
		}

		$field = $fields[ $field_slug ];
		return is_array( $field ) ? $field : null;
	}

	/**
	 * Get response trends grouped by date.
	 *
	 * @param int    $form_id   Form ID.
	 * @param string $period    Period: 'daily', 'weekly', or 'monthly'.
	 * @param string $date_from Start date filter (YYYY-MM-DD).
	 * @param string $date_to   End date filter (YYYY-MM-DD).
	 * @since 2.8.0
	 * @return array<string,int>
	 */
	public function get_response_trends( $form_id, $period = 'daily', $date_from = '', $date_to = '' ) {
		$form_id   = absint( $form_id );
		$period    = in_array( $period, [ 'daily', 'weekly', 'monthly' ], true ) ? $period : 'daily';
		$date_from = $this->validate_date( $date_from );
		$date_to   = $this->validate_date( $date_to );

		if ( ! Helper::current_user_can() ) {
			return [];
		}

		$entries = $this->get_form_entries( $form_id, $date_from, $date_to );
		$trends  = [];

		foreach ( $entries as $entry ) {
			$created_at = isset( $entry['created_at'] ) && is_scalar( $entry['created_at'] ) ? strval( $entry['created_at'] ) : '';
			if ( empty( $created_at ) ) {
				continue;
			}

			$timestamp = strtotime( $created_at );
			if ( false === $timestamp ) {
				continue;
			}

			switch ( $period ) {
				case 'weekly':
					$key = gmdate( 'Y-\WW', $timestamp );
					break;
				case 'monthly':
					$key = gmdate( 'Y-m', $timestamp );
					break;
				default:
					$key = gmdate( 'Y-m-d', $timestamp );
					break;
			}

			if ( ! isset( $trends[ $key ] ) ) {
				$trends[ $key ] = 0;
			}
			++$trends[ $key ];
		}

		ksort( $trends );

		return $trends;
	}

	/**
	 * Get all entries for a form filtered by survey/poll mode.
	 *
	 * @param int    $form_id   Form ID.
	 * @param string $date_from Start date filter (YYYY-MM-DD).
	 * @param string $date_to   End date filter (YYYY-MM-DD).
	 * @since 2.8.0
	 * @return array<int,array<string,mixed>>
	 */
	public function get_form_entries( $form_id, $date_from = '', $date_to = '' ) {
		$this->is_truncated = false;

		if ( ! class_exists( Entries::class ) ) {
			return [];
		}

		if ( is_admin() ) {
			wp_raise_memory_limit( 'admin' );
		}

		$entries_table = Entries::get_instance();
		$batch_size    = 500;
		$offset        = 0;
		$all_entries   = [];

		// Build where conditions — push date filtering into the DB query.
		$conditions = [
			[
				'key'     => 'status',
				'compare' => '!=',
				'value'   => 'trash',
			],
		];

		if ( ! empty( $date_from ) ) {
			$conditions[] = [
				'key'     => 'created_at',
				'compare' => '>=',
				'value'   => sanitize_text_field( $date_from ) . ' 00:00:00',
			];
		}

		if ( ! empty( $date_to ) ) {
			$conditions[] = [
				'key'     => 'created_at',
				'compare' => '<=',
				'value'   => sanitize_text_field( $date_to ) . ' 23:59:59',
			];
		}

		do {
			$batch = $entries_table->get_records_by_args(
				[
					'where'   => [
						'form_id' => absint( $form_id ),
						$conditions,
					],
					'columns' => 'ID, form_data, created_at',
					'orderby' => 'created_at',
					'order'   => 'ASC',
					'limit'   => $batch_size,
					'offset'  => $offset,
				]
			);

			if ( ! is_array( $batch ) || empty( $batch ) ) {
				break;
			}

			$batch_count = count( $batch );
			array_push( $all_entries, ...$batch );
			$offset += $batch_size;

			// Hard cap to prevent memory exhaustion on high-volume forms.
			if ( count( $all_entries ) >= self::MAX_ENTRIES ) {
				$this->is_truncated = true;
				break;
			}
		} while ( $batch_count === $batch_size );

		return $all_entries;
	}

	/**
	 * Whether the last get_form_entries() call was truncated at the MAX_ENTRIES cap.
	 *
	 * @since 2.8.0
	 * @return bool
	 */
	public function is_truncated(): bool {
		return $this->is_truncated;
	}

	/**
	 * Get drilldown data for a specific field value.
	 *
	 * Filters entries matching the given field+value, then extracts only the
	 * requested field slugs for a cross-tabulated view with pagination.
	 *
	 * @param int               $form_id         Form ID.
	 * @param string            $field_slug      Field slug to filter by.
	 * @param string            $filter_value    Value or category to match.
	 * @param string            $filter_type     Match type: 'nps_category', 'exact', or 'contains'.
	 * @param array<int,string> $requested_slugs Field slugs to include in the response.
	 * @param int               $page            Current page (1-based).
	 * @param int               $per_page        Items per page.
	 * @param string            $date_from       Start date filter (YYYY-MM-DD).
	 * @param string            $date_to         End date filter (YYYY-MM-DD).
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	public function get_field_drilldown( $form_id, $field_slug, $filter_value, $filter_type, $requested_slugs, $page = 1, $per_page = 20, $date_from = '', $date_to = '' ) {
		$form_id         = absint( $form_id );
		$field_slug      = sanitize_text_field( $field_slug );
		$filter_value    = sanitize_text_field( $filter_value );
		$filter_type     = in_array( $filter_type, [ 'nps_category', 'exact', 'contains' ], true ) ? $filter_type : 'exact';
		$requested_slugs = array_map( 'sanitize_text_field', $requested_slugs );
		$page            = max( 1, absint( $page ) );
		$per_page        = min( 100, max( 1, absint( $per_page ) ) );
		$date_from       = $this->validate_date( $date_from );
		$date_to         = $this->validate_date( $date_to );

		if ( ! Helper::current_user_can() ) {
			return [
				'columns'     => [],
				'entries'     => [],
				'total'       => 0,
				'page'        => $page,
				'per_page'    => $per_page,
				'total_pages' => 0,
			];
		}

		$entries = $this->get_form_entries( $form_id, $date_from, $date_to );

		if ( empty( $entries ) ) {
			return [
				'columns'     => [],
				'entries'     => [],
				'total'       => 0,
				'page'        => $page,
				'per_page'    => $per_page,
				'total_pages' => 0,
			];
		}

		// Build column definitions from first entry to discover labels.
		$column_map = $this->build_column_map( $entries, $requested_slugs );

		// Filter entries matching the field value.
		$filtered = [];
		foreach ( $entries as $entry ) {
			$form_data = $this->parse_form_data( $entry );
			if ( empty( $form_data ) ) {
				continue;
			}

			$match_value = $this->find_field_value( $form_data, $field_slug );
			if ( null === $match_value ) {
				continue;
			}

			if ( ! $this->matches_filter( $match_value, $filter_value, $filter_type ) ) {
				continue;
			}

			// Extract requested field values.
			$fields = [];
			foreach ( $requested_slugs as $slug ) {
				$fields[ $slug ] = $this->find_field_value( $form_data, $slug );
			}

			$entry_id   = isset( $entry['ID'] ) && is_numeric( $entry['ID'] ) ? intval( $entry['ID'] ) : 0;
			$created_at = isset( $entry['created_at'] ) && is_scalar( $entry['created_at'] ) ? strval( $entry['created_at'] ) : '';

			$filtered[] = [
				'entry_id'     => $entry_id,
				'filter_value' => $match_value,
				'created_at'   => $created_at,
				'fields'       => $fields,
			];
		}

		$total       = count( $filtered );
		$total_pages = intval( ceil( $total / $per_page ) );
		$offset      = ( $page - 1 ) * $per_page;
		$paged       = array_slice( $filtered, $offset, $per_page );

		// Build columns array.
		$columns = [];
		foreach ( $requested_slugs as $slug ) {
			if ( isset( $column_map[ $slug ] ) ) {
				$columns[] = $column_map[ $slug ];
			}
		}

		return [
			'columns'     => $columns,
			'entries'     => $paged,
			'total'       => $total,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => $total_pages,
		];
	}

	/**
	 * Build a map of field slug => column definition from entries.
	 *
	 * @param array<int,array<string,mixed>> $entries         All form entries.
	 * @param array<int,string>              $requested_slugs Slugs to include.
	 * @since 2.8.0
	 * @return array<string,array<string,string>>
	 */
	private function build_column_map( $entries, $requested_slugs ) {
		$column_map = [];

		foreach ( $entries as $entry ) {
			$form_data = $this->parse_form_data( $entry );
			if ( empty( $form_data ) ) {
				continue;
			}

			foreach ( $form_data as $key => $value ) {
				if ( $this->is_system_key( $key ) ) {
					continue;
				}

				$slug = $this->extract_field_slug( $key );
				if ( ! in_array( $slug, $requested_slugs, true ) || isset( $column_map[ $slug ] ) ) {
					continue;
				}

				$column_map[ $slug ] = [
					'slug'  => $slug,
					'label' => $this->extract_label( $key ),
					'type'  => $this->detect_field_type( $key ),
				];
			}

			// Stop early if all requested slugs are found.
			if ( count( $column_map ) >= count( $requested_slugs ) ) {
				break;
			}
		}

		return $column_map;
	}

	/**
	 * Find a field's value in parsed form_data by its slug.
	 *
	 * @param array<string,mixed> $form_data Parsed form data.
	 * @param string              $slug      Field slug to find.
	 * @since 2.8.0
	 * @return string|null
	 */
	private function find_field_value( $form_data, $slug ) {
		foreach ( $form_data as $key => $value ) {
			if ( $this->is_system_key( $key ) ) {
				continue;
			}

			if ( $this->extract_field_slug( $key ) === $slug ) {
				if ( is_array( $value ) ) {
					$string_values = [];
					foreach ( $value as $v ) {
						$string_values[] = is_scalar( $v ) ? strval( $v ) : '';
					}
					return implode( ' | ', $string_values );
				}
				return is_scalar( $value ) ? strval( $value ) : '';
			}
		}

		return null;
	}

	/**
	 * Check if a field value matches the filter criteria.
	 *
	 * @param string $value        The actual field value.
	 * @param string $filter_value The filter to match against.
	 * @param string $filter_type  Match type: 'nps_category', 'exact', or 'contains'.
	 * @since 2.8.0
	 * @return bool
	 */
	private function matches_filter( $value, $filter_value, $filter_type ) {
		switch ( $filter_type ) {
			case 'nps_category':
				$score      = absint( $value );
				$categories = [
					'detractors' => [ 0, 6 ],
					'passives'   => [ 7, 8 ],
					'promoters'  => [ 9, 10 ],
				];

				$range = $categories[ $filter_value ] ?? null;
				if ( null === $range ) {
					return false;
				}

				return $score >= $range[0] && $score <= $range[1];

			case 'contains':
				$parts = array_map( 'trim', explode( '|', $value ) );
				return in_array( $filter_value, $parts, true );

			case 'exact':
			default:
				return $value === $filter_value;
		}
	}

	/**
	 * Build field data from entries.
	 *
	 * Shared logic for aggregate() and aggregate_public().
	 *
	 * @param array<int,array<string,mixed>> $entries Form entries.
	 * @since 2.8.0
	 * @return array<string,array<string,mixed>>
	 */
	private function build_field_data( $entries ) {
		$field_data = [];
		// Maps block_slug → field_slug for deduplication (same field, different key prefix).
		$block_slug_index        = [];
		$this->counted_responses = 0;

		foreach ( $entries as $entry ) {
			$form_data = $this->parse_form_data( $entry );

			if ( empty( $form_data ) ) {
				continue;
			}

			$has_real_field = false;

			foreach ( $form_data as $key => $value ) {
				if ( $this->is_system_key( $key ) ) {
					continue;
				}

				$has_real_field = true;

				$field_slug         = $this->extract_field_slug( $key );
				$field_type         = $this->detect_field_type( $key );
				$current_block_slug = $this->extract_block_slug( $key );

				// Deduplicate: if this block_slug already exists under a different
				// field_slug key, merge into that existing entry instead. This
				// prevents the same field appearing twice when the key prefix
				// varies across entries (e.g. conversational forms).
				if ( '' !== $current_block_slug && isset( $block_slug_index[ $current_block_slug ] ) && $block_slug_index[ $current_block_slug ] !== $field_slug ) {
					$field_slug = $block_slug_index[ $current_block_slug ];
				}

				if ( ! isset( $field_data[ $field_slug ] ) ) {
					$field_data[ $field_slug ] = [
						'label'       => $this->extract_label( $key ),
						'type'        => $field_type,
						'block_slug'  => $current_block_slug,
						'block_slugs' => '' !== $current_block_slug ? [ $current_block_slug ] : [],
						'responses'   => [],
					];
					if ( '' !== $current_block_slug ) {
						$block_slug_index[ $current_block_slug ] = $field_slug;
					}
				} elseif ( '' !== $current_block_slug && ! in_array( $current_block_slug, $field_data[ $field_slug ]['block_slugs'], true ) ) {
					$field_data[ $field_slug ]['block_slugs'][] = $current_block_slug;
					// Update to the latest slug (entries are ordered ASC by created_at).
					$field_data[ $field_slug ]['block_slug'] = $current_block_slug;
					$block_slug_index[ $current_block_slug ] = $field_slug;
				}

				if ( is_array( $value ) ) {
					$field_data[ $field_slug ]['responses'][] = implode( ' | ', array_map( 'strval', $value ) );
				} else {
					$field_data[ $field_slug ]['responses'][] = is_scalar( $value ) ? strval( $value ) : '';
				}
			}

			// Only entries with at least one real field count as responses;
			// internal-only entries (e.g. just entry_id / _is_webhook_processing) are skipped.
			if ( $has_real_field ) {
				++$this->counted_responses;
			}
		}

		return $field_data;
	}

	/**
	 * Parse form_data from an entry.
	 *
	 * @param array<string,mixed> $entry Entry data.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	private function parse_form_data( $entry ) {
		$form_data = $entry['form_data'] ?? [];

		if ( is_string( $form_data ) ) {
			$decoded = json_decode( $form_data, true );
			return is_array( $decoded ) ? $decoded : [];
		}

		return is_array( $form_data ) ? $form_data : [];
	}

	/**
	 * Aggregate data for a single field.
	 *
	 * @param array<string,mixed> $data Field data with type, label, and responses.
	 * @since 2.8.0
	 * @return array<string,mixed>
	 */
	private function aggregate_field( $data ) {
		$type      = isset( $data['type'] ) && is_string( $data['type'] ) ? $data['type'] : 'text';
		$responses = isset( $data['responses'] ) && is_array( $data['responses'] ) ? $data['responses'] : [];
		$total     = count( $responses );

		$result = [
			'label'           => isset( $data['label'] ) && is_string( $data['label'] ) ? $data['label'] : '',
			'type'            => $type,
			'block_slug'      => isset( $data['block_slug'] ) && is_string( $data['block_slug'] ) ? $data['block_slug'] : '',
			'block_slugs'     => isset( $data['block_slugs'] ) && is_array( $data['block_slugs'] ) ? $data['block_slugs'] : [],
			'total_responses' => $total,
			'responses'       => $responses,
		];

		$is_numeric_type = in_array( $type, [ 'rating', 'nps', 'number' ], true )
			|| ( 'slider' === $type && $this->is_numeric_slider( $responses ) );

		if ( in_array( $type, [ 'multi-choice', 'dropdown', 'checkbox' ], true )
			|| ( 'slider' === $type && ! $this->is_numeric_slider( $responses ) )
		) {
			$option_counts = [];
			foreach ( $responses as $response ) {
				$response_str = is_scalar( $response ) ? strval( $response ) : '';
				$parts        = array_map( 'trim', explode( '|', $response_str ) );
				foreach ( $parts as $part ) {
					if ( '' === $part ) {
						continue;
					}
					if ( ! isset( $option_counts[ $part ] ) ) {
						$option_counts[ $part ] = 0;
					}
					++$option_counts[ $part ];
				}
			}
			arsort( $option_counts );
			$result['option_counts'] = $option_counts;
		} elseif ( $is_numeric_type ) {
			$values       = [];
			$distribution = [];
			foreach ( $responses as $response ) {
				$str_val = is_scalar( $response ) ? strval( $response ) : '';
				// Skip empty/blank responses for numeric fields.
				if ( '' === $str_val ) {
					--$total;
					continue;
				}
				$values[]  = is_numeric( $response ) ? floatval( $response ) : 0.0;
				$label_key = $str_val;
				if ( ! isset( $distribution[ $label_key ] ) ) {
					$distribution[ $label_key ] = 0;
				}
				++$distribution[ $label_key ];
			}
			$result['total_responses'] = $total;
			$result['average']         = $total > 0 ? round( array_sum( $values ) / $total, 2 ) : 0;
			$result['distribution']    = $distribution;
			ksort( $result['distribution'] );
		} else {
			$result['response_count'] = $total;
		}

		return $result;
	}

	/**
	 * Check if all slider responses are numeric (number slider).
	 *
	 * @param array<int,string> $responses Slider response values.
	 * @since 2.8.0
	 * @return bool
	 */
	private function is_numeric_slider( $responses ) {
		foreach ( $responses as $response ) {
			if ( ! is_numeric( $response ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Validate and sanitize a date string to YYYY-MM-DD format.
	 *
	 * @param string $date Raw date string.
	 * @since 2.8.0
	 * @return string Validated date or empty string.
	 */
	private function validate_date( $date ) {
		$date = sanitize_text_field( strval( $date ) );
		if ( '' !== $date && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return '';
		}

		if ( '' !== $date ) {
			$parts = explode( '-', $date );
			if ( ! checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] ) ) {
				return '';
			}
		}

		return $date;
	}

	/**
	 * Check if a form data key is a system key that should be skipped.
	 *
	 * @param string $key Form data key.
	 * @since 2.8.0
	 * @return bool
	 */
	private function is_system_key( $key ) {
		if ( ! is_string( $key ) ) {
			return true;
		}

		$system_keys = array_merge(
			[
				'form-id',
				'form_id',
				'sureforms_form_submit',
				'_entry_id',
				'_form_id',
				'submission_id',
				// Injected by core for the {entry_id} smart tag; not a real field.
				'entry_id',
			],
			Helper::get_excluded_fields()
		);

		if ( in_array( $key, $system_keys, true ) ) {
			return true;
		}

		// Internal/meta flags are underscore-prefixed (e.g. _is_webhook_processing).
		return 0 === strpos( $key, '_' );
	}

	/**
	 * Extract a human-readable field slug from a submission key.
	 *
	 * @param string $key Form data key.
	 * @since 2.8.0
	 * @return string
	 */
	private function extract_field_slug( $key ) {
		// Pattern: srfm-{type}-{counter}-{block_id}-lbl-{encoded_label}-{slug}.
		if ( false !== strpos( $key, '-lbl-' ) ) {
			$parts = explode( '-lbl-', $key, 2 );
			return sanitize_title( $parts[0] ?? $key );
		}
		return sanitize_title( $key );
	}

	/**
	 * Extract the block slug from a submission key.
	 *
	 * Keys follow: srfm-{type}-{id}-lbl-{base64_label}-{block_slug}
	 * The base64 part has no dashes, so the first dash after -lbl- separates
	 * the encoded label from the block slug.
	 *
	 * @param string $key Form data key.
	 * @since 2.8.0
	 * @return string
	 */
	private function extract_block_slug( $key ) {
		if ( false === strpos( $key, '-lbl-' ) ) {
			return '';
		}

		$label_part = explode( '-lbl-', $key, 2 )[1] ?? '';
		$parts      = explode( '-', $label_part, 2 );

		return sanitize_title( $parts[1] ?? '' );
	}

	/**
	 * Sync block_slug values with the current post_content.
	 *
	 * Entry-based block_slugs can become stale when a user renames a field
	 * without new submissions. This reads the form's post_content to get
	 * the current slug for each block (matched via immutable block_id).
	 *
	 * @param int                        $form_id    Form ID.
	 * @param array<string,array<mixed>> $field_data Field data keyed by field_slug.
	 * @since 2.8.0
	 * @return array<string,array<mixed>>
	 */
	private function sync_block_slugs_with_post_content( $form_id, array $field_data ) {
		$post_content = get_post_field( 'post_content', $form_id );

		if ( empty( $post_content ) || ! is_string( $post_content ) ) {
			return $field_data;
		}

		$blocks           = parse_blocks( $post_content );
		$block_id_to_slug = [];
		$this->collect_block_slugs( $blocks, $block_id_to_slug );

		if ( empty( $block_id_to_slug ) ) {
			return $field_data;
		}

		foreach ( $field_data as $field_slug => &$field ) {
			foreach ( $block_id_to_slug as $block_id => $current_slug ) {
				if ( '' === $block_id || false === strpos( $field_slug, $block_id ) ) {
					continue;
				}

				$field['block_slug'] = $current_slug;

				if ( ! in_array( $current_slug, $field['block_slugs'], true ) ) {
					$field['block_slugs'][] = $current_slug;
				}

				break;
			}
		}
		unset( $field );

		return $field_data;
	}

	/**
	 * Recursively collect block_id → slug mappings from parsed blocks.
	 *
	 * @param array<int,array<string,mixed>> $blocks Parsed blocks.
	 * @param array<string,string>           $map    Block ID to slug map (by reference).
	 * @since 2.8.0
	 * @return void
	 */
	private function collect_block_slugs( array $blocks, array &$map ) {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$this->collect_block_slugs( $block['innerBlocks'], $map );
			}

			$name = isset( $block['blockName'] ) && is_string( $block['blockName'] ) ? $block['blockName'] : '';

			if ( 0 !== strpos( $name, 'srfm/' ) ) {
				continue;
			}

			$attrs    = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : [];
			$block_id = isset( $attrs['block_id'] ) && is_string( $attrs['block_id'] ) ? $attrs['block_id'] : '';
			$slug     = isset( $attrs['slug'] ) && is_string( $attrs['slug'] ) ? $attrs['slug'] : '';

			if ( '' !== $block_id && '' !== $slug ) {
				$map[ $block_id ] = $slug;
			}
		}
	}

	/**
	 * Extract the label from a submission key.
	 *
	 * Uses Helper::decrypt() from the core plugin for base64 decoding consistency.
	 *
	 * @param string $key Form data key.
	 * @since 2.8.0
	 * @return string
	 */
	private function extract_label( $key ) {
		if ( false === strpos( $key, '-lbl-' ) ) {
			return sanitize_text_field( $key );
		}

		$label_part = explode( '-lbl-', $key, 2 )[1] ?? '';
		if ( '' === $label_part ) {
			return sanitize_text_field( $key );
		}

		$encoded = explode( '-', $label_part, 2 )[0] ?? '';
		if ( '' !== $encoded ) {
			$decoded = Helper::decrypt( $encoded );
			if ( '' !== $decoded ) {
				return sanitize_text_field( $decoded );
			}
		}

		return sanitize_text_field( $key );
	}

	/**
	 * Detect field type from submission key prefix.
	 *
	 * @param string $key Form data key.
	 * @since 2.8.0
	 * @return string
	 */
	private function detect_field_type( $key ) {
		// Specific prefixes before generic ones (e.g. srfm-input-multi-choice before srfm-input).
		$type_map = [
			'srfm-input-multi-choice' => 'multi-choice',
			'srfm-dropdown'           => 'dropdown',
			'srfm-rating'             => 'rating',
			'srfm-nps'                => 'nps',
			'srfm-textarea'           => 'textarea',
			'srfm-checkbox'           => 'checkbox',
			'srfm-number'             => 'number',
			'srfm-slider'             => 'slider',
			'srfm-datepicker'         => 'datepicker',
			'srfm-time-picker'        => 'time-picker',
			'srfm-input'              => 'input',
		];

		foreach ( $type_map as $prefix => $type ) {
			if ( 0 === strpos( $key, $prefix ) ) {
				return $type;
			}
		}

		return 'text';
	}
}
