<?php
/**
 * SureForms Pro Save and Resume Database Table Class.
 *
 * @link       https://sureforms.com
 * @since      2.2.0
 * @package    sureforms-pro
 */

namespace SRFM_Pro\Inc\Pro\Database\Tables;

use SRFM\Inc\Database\Base;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * SureForms Pro Save and Resume Database Table Class.
 *
 * @since 2.2.0
 */
class Save_Resume extends Base {
	use Get_Instance;

	/**
	 * Allowed trigger sources for a partial-entry upsert.
	 *
	 * @since 2.9.0
	 */
	public const ALLOWED_TRIGGERS = [ 'heartbeat', 'pagebreak', 'input', 'pagehide', 'saved' ];

	/**
	 * {@inheritDoc}
	 *
	 * @var string
	 */
	protected $table_suffix = 'draft_submissions';

	/**
	 * {@inheritDoc}
	 *
	 * @var int
	 */
	protected $table_version = 12;

	/**
	 * {@inheritDoc}
	 */
	public function get_schema() {
		return [
			// Unique identifier for each draft.
			'id'               => [
				'type' => 'string',
			],
			// Sequential human-readable counter (1, 2, 3 …). Assigned by
			// MySQL via AUTO_INCREMENT — concurrent INSERTs never collide
			// (the previous MAX+1 read-then-write was racy). Acceptable
			// gap-on-delete tradeoff for an admin-facing display id.
			'partial_entry_id' => [
				'type'    => 'number',
				'default' => 0,
			],
			// Email address if the user chooses to receive the resume link.
			'email'            => [
				'type' => 'string',
			],
			// When the draft was saved.
			'date_created'     => [
				'type' => 'datetime',
			],
			// IP address of the user.
			'ip'               => [
				'type' => 'string',
			],
			// URL of the form.
			'source_url'       => [
				'type' => 'string',
			],
			// Identifier of the form.
			'form_id'          => [
				'type' => 'number',
			],
			// Serialized snapshot of form state.
			'form_data'        => [
				'type'    => 'array',
				'default' => [],
			],
			// Frontend session identifier (ties save+resume rows together).
			'session_id'       => [
				'type'    => 'string',
				'default' => '',
			],
			// Step/page the user was on when the entry was captured.
			'current_page'     => [
				'type'    => 'number',
				'default' => 0,
			],
			// 0-100 completion estimate shown in the admin list.
			'progress_percent' => [
				'type'    => 'number',
				'default' => 0,
			],
			// What event caused the save (heartbeat, pagebreak, input, pagehide, saved).
			'last_trigger'     => [
				'type'    => 'string',
				'default' => 'saved',
			],
			// Admin notes stored as a JSON array.
			'notes'            => [
				'type'    => 'array',
				'default' => [],
			],
			// Last time the row was touched (auto-updated by MySQL).
			'updated_at'       => [
				'type' => 'datetime',
			],
			// When this row was last CLAIMED for a partial-entry notification.
			// NULL until the first claim. The notifier claims it conditionally —
			// either once ever, or once per throttle window — so this doubles as
			// the concurrency guard and the "last notified" record.
			'notified_at'      => [
				'type' => 'datetime',
			],
		];
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns_definition() {
		return [
			'id CHAR(36) NOT NULL',
			'partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT',
			'email VARCHAR(255)',
			'date_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP',
			'ip VARCHAR(45)',
			'source_url TEXT',
			'form_id BIGINT(20) UNSIGNED',
			'form_data LONGTEXT',
			'session_id VARCHAR(64) NOT NULL',
			'current_page SMALLINT UNSIGNED NOT NULL DEFAULT 0',
			'progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0',
			'last_trigger VARCHAR(20) NOT NULL',
			'notes LONGTEXT',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			// Nullable: NULL until the row is first claimed for notification.
			'notified_at DATETIME NULL DEFAULT NULL',
			// AUTO_INCREMENT requires the column to be a key — make
			// partial_entry_id the PRIMARY KEY (so MySQL can mint sequential
			// values atomically) and demote `id` to a UNIQUE secondary key.
			'PRIMARY KEY (partial_entry_id)',
			'UNIQUE KEY uniq_id (id)',
			'INDEX idx_session_form (session_id, form_id)',
			'INDEX idx_updated_at (updated_at)',
			'INDEX idx_trigger_updated (last_trigger, updated_at)',
		];
	}

	/**
	 * Column definitions for the DB upgrade path (ALTER TABLE ADD COLUMN).
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	public function get_new_columns_definition() {
		return [
			'session_id VARCHAR(64) NOT NULL AFTER form_data',
			'current_page SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER session_id',
			'progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER current_page',
			'last_trigger VARCHAR(20) NOT NULL AFTER progress_percent',
			'notes LONGTEXT AFTER last_trigger',
			'updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER notes',
			// v12: notification claim stamp for partial entries.
			// Plain ADD COLUMN (no accompanying index) so the ALTER converges on
			// every DB engine; the Base skips it when already present.
			'notified_at DATETIME NULL DEFAULT NULL AFTER updated_at',
		];
	}

	/**
	 * {@inheritDoc}
	 *
	 * Migration to schema v10:
	 *   - Drop the legacy `partial_entry_id BIGINT DEFAULT 0` column
	 *     (added in v9 and never released) and re-add it as the
	 *     AUTO_INCREMENT primary key. The original MAX+1 read-then-
	 *     write pattern produced duplicate display IDs under
	 *     concurrent inserts; AUTO_INCREMENT eliminates the race.
	 *   - Demote `id` (UUID) to a UNIQUE secondary key.
	 *
	 * Idempotent — only runs if the column already exists with the
	 * old (non-AUTO_INCREMENT) shape.
	 *
	 * @param array<string> $new_columns Column / index definitions.
	 * @since 2.9.0
	 * @return int|bool
	 */
	public function maybe_add_new_columns( $new_columns = [] ) {
		$existing_columns = $this->get_columns();
		$table            = $this->get_tablename();

		if ( ! empty( $existing_columns ) ) {
			$pe_id_meta = $existing_columns['partial_entry_id'] ?? null;
			$extra_raw  = is_array( $pe_id_meta ) && isset( $pe_id_meta['Extra'] )
				? $pe_id_meta['Extra']
				: '';
			$is_auto    = is_string( $extra_raw ) && false !== stripos( $extra_raw, 'auto_increment' );

			// Internal table name — interpolation here is safe because
			// `$table` comes from `get_tablename()`, not user input.
			$table_safe = esc_sql( $table );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- one-shot schema migration with an esc_sql-escaped internal table name; no user input flows into these statements.
			if ( ! isset( $existing_columns['partial_entry_id'] ) ) {
				// Column was never present (fresh post-v10 install hitting
				// upgrade by accident) — backfill as AUTO_INCREMENT PK.
				$this->wpdb->query( "ALTER TABLE `{$table_safe}` DROP PRIMARY KEY, ADD COLUMN partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (partial_entry_id), ADD UNIQUE KEY uniq_id (id)" );
			} elseif ( ! $is_auto ) {
				// Column exists from v9 but lacks AUTO_INCREMENT.
				// Step 1 — backfill any existing rows whose
				// `partial_entry_id` is 0 / NULL (legacy default or
				// rows inserted before the MAX+1 logic existed) with
				// sequential values starting after the current MAX.
				// Without this, the AUTO_INCREMENT PRIMARY KEY ALTER
				// below fails with a duplicate-key error on duplicate
				// zeros and silently leaves the column unchanged —
				// the admin would keep seeing "Partial Entry #" with
				// no number after it.
				$max = (int) $this->wpdb->get_var( "SELECT COALESCE(MAX(partial_entry_id),0) FROM `{$table_safe}` WHERE partial_entry_id > 0" );

				// Initialise the rownum counter to the current MAX
				// so the backfill picks up where real values left off.
				$set_query = $this->wpdb->prepare( 'SET @srfm_pe_rownum := %d', $max );
				if ( is_string( $set_query ) ) {
					$this->wpdb->query( $set_query );
				}
				$this->wpdb->query( "UPDATE `{$table_safe}` SET partial_entry_id = ( @srfm_pe_rownum := @srfm_pe_rownum + 1 ) WHERE partial_entry_id = 0 OR partial_entry_id IS NULL ORDER BY date_created ASC, id ASC" );

				// Step 2 — drop the old PK on `id`, re-key on
				// `partial_entry_id`, and flip the column to
				// AUTO_INCREMENT. Now that every row has a unique
				// non-zero value the ALTER cannot collide.
				$this->wpdb->query( "ALTER TABLE `{$table_safe}` DROP PRIMARY KEY, MODIFY partial_entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, ADD UNIQUE KEY uniq_id (id)" );
			}
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		}

		return parent::maybe_add_new_columns( $new_columns );
	}

	/**
	 * Add a new draft submission to the database.
	 *
	 * @param array<mixed> $data An associative array of data for the new draft submission. Must include 'id'.
	 * @since 2.2.0
	 * @return int|false The number of rows inserted, or false if the insertion fails.
	 */
	public static function add( $data ) {
		if ( ! is_array( $data ) || empty( $data['id'] ) ) {
			return false;
		}
		// Basic sanitisation of individual fields.
		$data['id'] = sanitize_text_field( $data['id'] );
		if ( isset( $data['email'] ) ) {
			$data['email'] = sanitize_email( $data['email'] );
		}
		if ( isset( $data['ip'] ) ) {
			$data['ip'] = sanitize_text_field( $data['ip'] );
		}
		if ( isset( $data['source_url'] ) ) {
			$data['source_url'] = esc_url_raw( $data['source_url'] );
		}
		if ( isset( $data['form_id'] ) ) {
			$data['form_id'] = absint( $data['form_id'] );
		}
		// Serialize form_data if it's an array.
		if ( isset( $data['form_data'] ) && is_array( $data['form_data'] ) ) {
			$data['form_data'] = wp_json_encode( $data['form_data'] );
		}
		return self::get_instance()->use_insert( $data );
	}

	/**
	 * Retrieve a specific draft submission from the database.
	 *
	 * @param string $id The id of the draft submission to retrieve.
	 * @since 2.2.0
	 * @return array<mixed> An associative array representing the draft submission, or an empty array if not found.
	 */
	public static function get( $id ) {
		if ( empty( $id ) ) {
			return [];
		}

		return self::get_by( 'id', sanitize_text_field( $id ) );
	}

	/**
	 * Update a draft submission by id.
	 *
	 * @param string              $id Draft id.
	 * @param array<string,mixed> $data Data to update.
	 * @since 2.2.0
	 * @return int|false The number of rows updated, or false on error.
	 */
	public static function update( $id, $data = [] ) {
		if ( empty( $id ) ) {
			return false;
		}

		// Serialize form_data if it's an array.
		if ( isset( $data['form_data'] ) && is_array( $data['form_data'] ) ) {
			$data['form_data'] = wp_json_encode( $data['form_data'] );
		}

		return self::get_instance()->use_update( $data, [ 'id' => sanitize_text_field( $id ) ] );
	}

	/**
	 * Atomically claim a draft for notification.
	 *
	 * Sets notified_at in a single CONDITIONAL UPDATE and reports whether THIS caller won
	 * the claim, so two concurrent notifier runs (the hook is public, and Action Scheduler
	 * can replay) cannot both send: exactly one sees a row count of 1. The condition is
	 * "never claimed" by default, or "not claimed within $reclaim_after seconds" when a
	 * window is supplied — see below.
	 *
	 * Pair with release_notification_claim() so a failed send does not leave the row
	 * permanently marked as notified.
	 *
	 * Repeat notifications: pass $reclaim_after to make the claim time-windowed —
	 * the row becomes claimable again once its last stamp is older than that many
	 * seconds. This keeps one unambiguous meaning for `notified_at` ("when this row
	 * was last claimed for sending") and keeps the claim atomic, so a row that may
	 * be emailed more than once still cannot be double-sent by concurrent runs.
	 * Omit it (the default) for the send-once behaviour: NULL means never claimed,
	 * and a stamped row is never claimable again.
	 *
	 * @param string   $id            Draft id.
	 * @param string   $stamp         UTC mysql-format timestamp to write.
	 * @param int|null $reclaim_after Seconds after which a stamped row may be re-claimed.
	 *                                Null (default) = claim only once, ever.
	 * @since 2.12.3
	 * @return bool True when this caller claimed the row, false when it was already claimed.
	 */
	public static function claim_for_notification( $id, $stamp, $reclaim_after = null ) {
		global $wpdb;

		if ( empty( $id ) ) {
			return false;
		}

		$table = self::get_instance()->get_tablename();
		$stamp = sanitize_text_field( $stamp );
		$id    = sanitize_text_field( $id );

		if ( null === $reclaim_after ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Conditional UPDATE is the claim primitive; $table comes from get_tablename(), not from input.
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET notified_at = %s WHERE id = %s AND notified_at IS NULL", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
					$stamp,
					$id
				)
			);

			return 1 === (int) $claimed;
		}

		// Windowed claim. The cutoff is derived from the caller's own stamp rather than
		// the DB clock so the comparison uses one consistent time source (both are UTC
		// mysql strings written by current_time( 'mysql', true )).
		//
		// Fail CLOSED on a stamp we cannot parse. This is a public static entry point, so
		// a future caller could pass something malformed; silently falling back to epoch
		// would turn the predicate into "claim anything" and remove the throttle without
		// any signal.
		$stamp_ts = strtotime( $stamp . ' UTC' );
		if ( false === $stamp_ts ) {
			return false;
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', max( 0, $stamp_ts - absint( $reclaim_after ) ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET notified_at = %s WHERE id = %s AND ( notified_at IS NULL OR notified_at <= %s )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
				$stamp,
				$id,
				$cutoff
			)
		);

		return 1 === (int) $claimed;
	}

	/**
	 * Release a notification claim taken by claim_for_notification().
	 *
	 * Only clears the stamp this caller wrote, so a later successful run's stamp is never
	 * wiped by a straggler's failure path.
	 *
	 * @param string $id    Draft id.
	 * @param string $stamp The exact stamp this caller wrote.
	 * @since 2.12.3
	 * @return bool True when the claim was released.
	 */
	public static function release_notification_claim( $id, $stamp ) {
		global $wpdb;

		if ( empty( $id ) ) {
			return false;
		}

		$table = self::get_instance()->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Mirror of the claim above.
		$released = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET notified_at = NULL WHERE id = %s AND notified_at = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- See above.
				sanitize_text_field( $id ),
				sanitize_text_field( $stamp )
			)
		);

		return 1 === (int) $released;
	}

	/**
	 * Delete a draft submission by id.
	 *
	 * @param string $id Draft id to delete.
	 * @since 2.2.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete( $id ) {
		if ( empty( $id ) ) {
			return false;
		}

		return self::get_instance()->use_delete( [ 'id' => sanitize_text_field( $id ) ], [ '%s' ] );
	}

	/**
	 * Delete draft submissions older than specified days.
	 *
	 * @since 2.2.0
	 * @return int|false The number of rows deleted, or false on error.
	 */
	public static function delete_old_drafts() {
		global $wpdb;

		$instance = self::get_instance();

		// Number of days is filterable via 'srfm_delete_old_drafts_days' filter (default: 30 days).
		$days = apply_filters( 'srfm_delete_old_drafts_days', 30 );

		// If days is not a positive integer, use default of 30 days.
		if ( ! is_int( $days ) || $days <= 0 ) {
			$days = 30;
		}

		// Calculate the date threshold.
		$timestamp = strtotime( "-{$days} days" );
		if ( false === $timestamp ) {
			return false;
		}
		$threshold_date = gmdate( 'Y-m-d H:i:s', $timestamp );

		// Scope deletion to legacy Save & Resume rows (last_trigger
		// is empty or 'saved'). Partial-entries rows use other
		// triggers (heartbeat / pagebreak / input / pagehide) and
		// are swept by `Init::cleanup_stale_partials()` with its own
		// retention filter — running this query without the trigger
		// scope would cross-delete partial entries at the
		// save-resume retention window, ignoring the dedicated
		// `srfm_partial_entries_retention_days` filter.
		$table = $instance->get_tablename();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- scheduled maintenance, intentionally uncached; table name from internal config.
		return $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE date_created < %s AND ( last_trigger = %s OR last_trigger = '' OR last_trigger IS NULL )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is internal.
				$threshold_date,
				'saved'
			)
		);
	}

	/**
	 * Insert or update a row keyed by session_id + form_id.
	 *
	 * Returns the UUID `id` of the affected row on success, false on failure.
	 *
	 * @param array<string,mixed> $data Row data. Must include `form_id` and `session_id`.
	 * @since 2.9.0
	 * @return string|false UUID on success, false on failure.
	 */
	public static function upsert( $data ) {
		if ( empty( $data['form_id'] ) || empty( $data['session_id'] ) ) {
			return false;
		}

		$instance   = self::get_instance();
		$session_id = sanitize_text_field( Helper::get_string_value( $data['session_id'] ) );
		$form_id    = absint( $data['form_id'] );

		$existing = $instance->get_results(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			'id',
			[ 'LIMIT 1' ],
			false
		);

		if ( ! empty( $existing[0]['id'] ) ) {
			$existing_id = sanitize_text_field( Helper::get_string_value( $existing[0]['id'] ) );
			unset( $data['id'], $data['date_created'], $data['notes'] );
			$result = $instance->use_update( $data, [ 'id' => $existing_id ] );
			return false === $result ? false : $existing_id;
		}

		// `partial_entry_id` is the AUTO_INCREMENT primary key —
		// MySQL assigns it atomically on INSERT. Strip any value the
		// caller may have supplied so we never override the engine.
		unset( $data['partial_entry_id'] );

		// Generate a UUID for the new row.
		$data['id'] = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0x0fff ) | 0x4000,
			wp_rand( 0, 0x3fff ) | 0x8000,
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff ),
			wp_rand( 0, 0xffff )
		);
		$new_id     = $data['id'];
		unset( $data['date_created'] );
		$inserted = $instance->use_insert( $data );
		if ( false !== $inserted ) {
			return $new_id;
		}

		// Race condition — duplicate session+form. Re-lookup.
		$recheck = $instance->get_results(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			'id',
			[ 'LIMIT 1' ],
			false
		);
		if ( empty( $recheck[0]['id'] ) ) {
			return false;
		}
		$existing_id = sanitize_text_field( Helper::get_string_value( $recheck[0]['id'] ) );
		unset( $data['id'], $data['date_created'], $data['notes'] );
		$result = $instance->use_update( $data, [ 'id' => $existing_id ] );
		return false === $result ? false : $existing_id;
	}

	/**
	 * Retrieve the single row matching a session_id + form_id pair.
	 *
	 * @param string $session_id Session identifier (max 64 chars).
	 * @param int    $form_id    Form post ID.
	 * @since 2.9.0
	 * @return array<mixed> Row data or empty array if not found.
	 */
	public static function get_by_session( $session_id, $form_id ) {
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		$form_id    = absint( $form_id );
		if ( '' === $session_id || 0 === $form_id ) {
			return [];
		}
		$results = self::get_instance()->get_results(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			'*',
			[ 'LIMIT 1' ]
		);
		$row     = isset( $results[0] ) && is_array( $results[0] ) ? $results[0] : [];
		// Decode form_data JSON string so the restore endpoint gets an array.
		if ( ! empty( $row['form_data'] ) && is_string( $row['form_data'] ) ) {
			$decoded = json_decode( $row['form_data'], true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$row['form_data'] = $decoded;
			}
		}
		return $row;
	}

	/**
	 * Delete the row matching a session_id + form_id pair.
	 *
	 * @param string $session_id Session identifier.
	 * @param int    $form_id    Form post ID.
	 * @since 2.9.0
	 * @return int|false Number of rows deleted, or false on error.
	 */
	public static function delete_by_session( $session_id, $form_id ) {
		$session_id = sanitize_text_field( Helper::get_string_value( $session_id ) );
		$form_id    = absint( $form_id );
		if ( '' === $session_id || 0 === $form_id ) {
			return false;
		}
		return self::get_instance()->use_delete(
			[
				'session_id' => $session_id,
				'form_id'    => $form_id,
			],
			[ '%s', '%d' ]
		);
	}

	/**
	 * Delete a single row by its UUID primary key.
	 *
	 * @param string $id Row UUID.
	 * @since 2.9.0
	 * @return int|false Number of rows deleted, or false on error.
	 */
	public static function delete_entry( $id ) {
		$id = sanitize_text_field( Helper::get_string_value( $id ) );
		if ( '' === $id ) {
			return false;
		}
		return self::get_instance()->use_delete( [ 'id' => $id ], [ '%s' ] );
	}

	/**
	 * Update a single row by its UUID primary key.
	 *
	 * @param string              $id   Row UUID.
	 * @param array<string,mixed> $data Column => value pairs to update.
	 * @since 2.9.0
	 * @return int|false Number of rows updated, or false on error.
	 */
	public static function update_entry( $id, $data = [] ) {
		$id = sanitize_text_field( Helper::get_string_value( $id ) );
		if ( '' === $id ) {
			return false;
		}
		return self::get_instance()->use_update( $data, [ 'id' => $id ] );
	}

	/**
	 * Return the UUIDs of the previous (older) and next (newer) rows
	 * relative to `$current_id`, ordered by `updated_at`.
	 *
	 * Optionally scoped to a single form when `$form_id > 0`.
	 *
	 * @param string $current_id UUID of the current row.
	 * @param int    $form_id    Optional form scope (0 = site-wide).
	 * @since 2.9.0
	 * @return array{previous_id: string|null, next_id: string|null}
	 */
	public static function get_adjacent_ids( $current_id, $form_id = 0 ) {
		$result     = [
			'previous_id' => null,
			'next_id'     => null,
		];
		$current_id = sanitize_text_field( Helper::get_string_value( $current_id ) );
		if ( '' === $current_id ) {
			return $result;
		}
		$form_id = absint( $form_id );

		global $wpdb;
		$table = self::get_instance()->get_tablename();

		$form_clause = '';
		if ( $form_id > 0 ) {
			$form_clause = $wpdb->prepare( ' AND form_id = %d', $form_id ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$current_ts = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT updated_at FROM {$table} WHERE id = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_id
			)
		);

		if ( ! is_string( $current_ts ) || '' === $current_ts ) {
			return $result;
		}

		// Previous = older.
		$previous_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE (( updated_at < %s ) OR ( updated_at = %s AND id < %s )){$form_clause} ORDER BY updated_at DESC, id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_ts,
				$current_ts,
				$current_id
			)
		);

		// Next = newer.
		$next_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE (( updated_at > %s ) OR ( updated_at = %s AND id > %s )){$form_clause} ORDER BY updated_at ASC, id ASC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$current_ts,
				$current_ts,
				$current_id
			)
		);

		return [
			'previous_id' => is_string( $previous_id ) && '' !== $previous_id ? $previous_id : null,
			'next_id'     => is_string( $next_id ) && '' !== $next_id ? $next_id : null,
		];
	}

	/**
	 * Allowed columns for ORDER BY clauses — guards against SQL injection.
	 *
	 * @since 2.9.0
	 * @return array<int,string>
	 */
	protected function get_allowed_orderby_columns() {
		return [ 'id', 'form_id', 'date_created', 'progress_percent', 'updated_at' ];
	}

	/**
	 * Retrieve draft submission data by a given condition.
	 *
	 * @param string     $key Lookup key (e.g., 'id', 'form_id').
	 * @param int|string $value Lookup value.
	 * @return array<mixed> Draft submission data or empty array if not found.
	 */
	private static function get_by( $key, $value ) {
		if ( empty( $key ) || empty( $value ) ) {
			return [];
		}

		$results = self::get_instance()->get_results(
			[
				$key => $value,
			]
		);

		$draft = isset( $results[0] ) && is_array( $results[0] ) ? Helper::get_array_value( $results[0] ) : [];

		// Decode form_data if it exists and is JSON.
		if ( ! empty( $draft['form_data'] ) && is_string( $draft['form_data'] ) ) {
			$decoded_data = json_decode( $draft['form_data'], true );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				$draft['form_data'] = $decoded_data;
			}
		}

		return $draft;
	}

}
