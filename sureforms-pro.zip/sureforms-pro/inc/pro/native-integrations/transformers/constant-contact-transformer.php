<?php
/**
 * Constant Contact Payload Transformer
 *
 * Transforms form data to Constant Contact sign_up_form API format.
 * Handles custom fields array structure, street address nesting,
 * and list_memberships array wrapping.
 *
 * @package SureForms
 * @since 2.7.1
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Transformers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Native_Integrations\Interfaces\Payload_Transformer;
use SRFM_Pro\Inc\Pro\Native_Integrations\Services\Workflow_Processor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Constant Contact Transformer class.
 *
 * @since 2.7.1
 */
class Constant_Contact_Transformer implements Payload_Transformer {
	/**
	 * Integration name
	 *
	 * @var string
	 * @since 2.7.1
	 */
	private $integration_name = 'constant-contact';

	/**
	 * Standard fields that map directly to the sign_up_form endpoint.
	 *
	 * @var array
	 * @since 2.7.1
	 */
	private $standard_fields = [
		'email_address',
		'first_name',
		'last_name',
		'job_title',
		'company_name',
		'phone_number',
		'birthday_month',
		'birthday_day',
		'anniversary',
	];

	/**
	 * Address fields that get nested into the street_address object.
	 *
	 * @var array
	 * @since 2.7.1
	 */
	private $address_fields = [
		'street',
		'city',
		'state',
		'postal_code',
		'country',
	];

	/**
	 * Get integration name this transformer handles
	 *
	 * @return string Integration name.
	 * @since 2.7.1
	 */
	public function get_integration_name() {
		return $this->integration_name;
	}

	/**
	 * Transform payload for Constant Contact sign_up_form endpoint
	 *
	 * Transforms flat form data into the required structure:
	 * - Wraps list_memberships in an array if needed
	 * - Builds street_address nested object from address fields
	 * - Converts dynamic custom fields to [{custom_field_id, value}] array
	 * - Casts birthday_month and birthday_day to integers
	 *
	 * @param array $form_data Original form data.
	 * @param array $field_mappings Field mappings configuration.
	 * @param array $context Additional context data.
	 * @return array Transformed payload.
	 * @since 2.7.1
	 */
	public function transform( $form_data, $field_mappings = [], $context = [] ) {
		unset( $field_mappings );
		unset( $context );

		$payload = [];

		// Handle standard fields that map directly.
		foreach ( $this->standard_fields as $field ) {
			if ( empty( $form_data[ $field ] ) ) {
				continue;
			}

			// Skip birthday fields here — handled separately below.
			if ( 'birthday_month' === $field || 'birthday_day' === $field ) {
				continue;
			}

			$payload[ $field ] = Helper::get_string_value( $form_data[ $field ] );
		}

		// Birthday fields must both be present — API rejects if only one is sent.
		if ( ! empty( $form_data['birthday_month'] ) && ! empty( $form_data['birthday_day'] ) ) {
			$payload['birthday_month'] = intval( $form_data['birthday_month'] );
			$payload['birthday_day']   = intval( $form_data['birthday_day'] );
		}

		// Handle list_ids → list_memberships mapping.
		// multi-select-async values arrive as [{value, label}] objects.
		// The API expects list_memberships as a flat array of UUID strings.
		if ( ! empty( $form_data['list_ids'] ) ) {
			$payload['list_memberships'] = $this->extract_multi_select_values( $form_data['list_ids'] );
		}

		// Build street_address object from individual address fields.
		$street_address    = [];
		$has_address_field = false;
		foreach ( $this->address_fields as $addr_field ) {
			if ( ! empty( $form_data[ $addr_field ] ) ) {
				$street_address[ $addr_field ] = Helper::get_string_value( $form_data[ $addr_field ] );
				$has_address_field             = true;
			}
		}

		if ( $has_address_field ) {
			$street_address['kind']    = 'home';
			$payload['street_address'] = $street_address;
		}

		// Collect all non-standard fields as custom fields.
		$all_known_fields = array_merge(
			$this->standard_fields,
			$this->address_fields,
			[ 'list_ids' ]
		);

		$custom_fields = [];
		foreach ( $form_data as $field_key => $field_value ) {
			if ( in_array( $field_key, $all_known_fields, true ) || empty( $field_value ) ) {
				continue;
			}

			$custom_fields[] = [
				'custom_field_id' => $field_key,
				'value'           => Helper::get_string_value( $field_value ),
			];
		}

		if ( ! empty( $custom_fields ) ) {
			$payload['custom_fields'] = $custom_fields;
		}

		return $payload;
	}

	/**
	 * Prepare test payload with sample data
	 *
	 * @param array $workflow_fields Fields from the workflow configuration.
	 * @param array $field_definitions Field definitions from the action configuration.
	 * @return array Test payload.
	 * @since 2.7.1
	 */
	public function prepare_test_payload( $workflow_fields, $field_definitions ) {
		$payload = Workflow_Processor::prepare_test_payload( $workflow_fields, $field_definitions );

		return $this->transform( $payload );
	}

	/**
	 * Extract plain values from multi-select-async field data.
	 *
	 * Handles both formats:
	 * - Array of {value, label} objects: [{value: "uuid", label: "Name"}, ...]
	 * - Array of plain IDs: ["uuid1", "uuid2"]
	 * - Comma-separated string: "uuid1,uuid2"
	 *
	 * @param mixed $raw_value Raw multi-select value.
	 * @return array Flat array of string values.
	 * @since 2.7.1
	 */
	private function extract_multi_select_values( $raw_value ) {
		if ( is_string( $raw_value ) ) {
			return array_values( array_filter( array_map( 'trim', explode( ',', $raw_value ) ) ) );
		}

		if ( ! is_array( $raw_value ) ) {
			return [];
		}

		$values = [];
		foreach ( $raw_value as $item ) {
			if ( is_array( $item ) && isset( $item['value'] ) ) {
				$values[] = Helper::get_string_value( $item['value'] );
			} elseif ( is_string( $item ) && ! empty( $item ) ) {
				$values[] = $item;
			}
		}

		return $values;
	}
}
