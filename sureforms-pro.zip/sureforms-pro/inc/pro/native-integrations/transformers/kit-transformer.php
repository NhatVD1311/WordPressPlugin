<?php
/**
 * Kit Transformer
 *
 * Custom transformer for Kit (formerly ConvertKit) integration
 * Handles pre-processing: create subscriber, apply tags, add to sequences, and add to forms
 *
 * @package SureForms
 * @since 1.13.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Transformers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\Interfaces\Payload_Transformer;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Kit Transformer class.
 *
 * @since 1.13.0
 */
class Kit_Transformer implements Payload_Transformer {
	/**
	 * Integration name
	 *
	 * @var string
	 */
	private $integration_name = 'kit';

	/**
	 * Get integration name this transformer handles
	 *
	 * @return string Integration name.
	 * @since 1.13.0
	 */
	public function get_integration_name() {
		return $this->integration_name;
	}

	/**
	 * Transform payload for Kit integration
	 *
	 * Executes all preprocessing steps before the framework's final subscriber upsert:
	 * 1. Create/update subscriber (with custom fields)
	 * 2. Apply each tag (if tag_ids provided)
	 * 3. Add to each sequence (if sequence_ids provided)
	 * 4. Add to form (if form_id provided)
	 *
	 * Returns a minimal payload for the framework's idempotent POST /v4/subscribers call.
	 *
	 * @param array $form_data Original form data.
	 * @param array $field_mappings Field mappings configuration.
	 * @param array $context Additional context data.
	 * @return array Transformed payload for final API call.
	 * @since 1.13.0
	 */
	public function transform( $form_data, $field_mappings = [], $context = [] ) {
		// The variables are not used anywhere further but are required in the interface.
		unset( $field_mappings );
		unset( $context );
		// Execute pre-processing steps (create subscriber, apply tags, add to sequences and forms).
		$this->execute_preprocessing( $form_data );

		// Return simplified payload for the framework's final idempotent subscriber upsert.
		$final_payload = [
			'email_address' => $form_data['email_address'] ?? '',
		];

		if ( ! empty( $form_data['first_name'] ) ) {
			$final_payload['first_name'] = $form_data['first_name'];
		}

		return $final_payload;
	}

	/**
	 * Prepare test payload with sample data
	 *
	 * @param array $workflow_fields Fields from the workflow configuration.
	 * @param array $field_definitions Field definitions from the action configuration.
	 * @return array Test payload.
	 * @since 1.13.0
	 */
	public function prepare_test_payload( $workflow_fields, $field_definitions ) {
		$payload = [];

		// Generate test payload.
		foreach ( $field_definitions as $field_def ) {
			$field_key = $field_def['key'] ?? '';

			if ( empty( $field_key ) ) {
				continue;
			}

			// Skip fields that are excluded from payload.
			$exclude_from_payload = $field_def['exclude_from_payload'] ?? false;
			if ( $exclude_from_payload ) {
				continue;
			}

			// Get field value or generate test data.
			if ( isset( $workflow_fields[ $field_key ] ) && ! empty( $workflow_fields[ $field_key ] ) ) {
				$payload[ $field_key ] = $workflow_fields[ $field_key ];
			} else {
				$payload[ $field_key ] = $this->generate_test_value( $field_def );
			}
		}

		// Handle custom fields - move to nested 'fields' object.
		$kit_reserved  = [ 'email_address', 'first_name', 'form_id', 'tag_ids', 'sequence_ids', 'tag_id' ];
		$custom_fields = [];
		foreach ( $payload as $key => $value ) {
			if ( ! in_array( $key, $kit_reserved, true ) ) {
				$custom_fields[ $key ] = $value;
				unset( $payload[ $key ] );
			}
		}

		if ( ! empty( $custom_fields ) ) {
			$payload['fields'] = $custom_fields;
		}

		return $payload;
	}

	/**
	 * Execute preprocessing steps: create subscriber, apply tags, and add to sequences
	 *
	 * @param array $form_data Form data.
	 * @return void
	 * @since 1.13.0
	 */
	private function execute_preprocessing( $form_data ) {
		$credentials = $this->get_integration_credentials();

		if ( ! $credentials ) {
			return;
		}

		try {
			// Step 1: Create/update subscriber.
			$subscriber_result = $this->create_subscriber( $form_data, $credentials );

			if ( ! $subscriber_result['success'] ) {
				return;
			}

			$email = Helper::get_string_value( $form_data['email_address'] ?? '' );

			// Backwards compat: support old singular key from existing saved workflows.
			$tag_ids      = $form_data['tag_ids'] ?? $form_data['tag_id'] ?? '';
			$sequence_ids = $form_data['sequence_ids'] ?? '';

			// Step 2: Apply each tag if provided (comma-separated IDs).
			foreach ( $this->parse_ids( $tag_ids ) as $tag_id ) {
				$this->post_subscriber_to_endpoint(
					$email,
					"https://api.kit.com/v4/tags/{$tag_id}/subscribers",
					$credentials,
					'tag application'
				);
			}

			// Step 3: Add to each sequence if provided (comma-separated IDs).
			foreach ( $this->parse_ids( $sequence_ids ) as $sequence_id ) {
				$this->post_subscriber_to_endpoint(
					$email,
					"https://api.kit.com/v4/sequences/{$sequence_id}/subscribers",
					$credentials,
					'sequence subscription'
				);
			}
		} catch ( \Exception $e ) {
			return;
		}
	}

	/**
	 * Create or update subscriber in Kit
	 *
	 * @param array $form_data Form data (custom fields expected in nested 'fields' object).
	 * @param array $credentials Integration credentials.
	 * @return array API response.
	 * @since 1.13.0
	 */
	private function create_subscriber( $form_data, $credentials ) {
		// Build a clean subscriber payload — only Kit-recognised fields.
		$subscriber_payload = [
			'email_address' => $form_data['email_address'] ?? '',
		];

		if ( ! empty( $form_data['first_name'] ) ) {
			$subscriber_payload['first_name'] = $form_data['first_name'];
		}

		if ( ! empty( $form_data['fields'] ) && is_array( $form_data['fields'] ) ) {
			$subscriber_payload['fields'] = $form_data['fields'];
		}

		$encoded_data = wp_json_encode( $subscriber_payload );
		$args         = [
			'method'  => 'POST',
			'headers' => [
				'Content-Type'  => 'application/json',
				'X-Kit-Api-Key' => $credentials['api_key'] ?? '',
				'Accept'        => 'application/json',
				'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
			],
			'body'    => $encoded_data ? $encoded_data : '',
			'timeout' => 30,
		];

		$response = wp_remote_post( 'https://api.kit.com/v4/subscribers', $args );

		return $this->process_api_response( $response, 'subscriber creation' );
	}

	/**
	 * Parse a comma-separated string of IDs into an array of validated integers.
	 *
	 * @param string $ids Comma-separated IDs.
	 * @return array<int> Sanitized, non-zero IDs.
	 * @since 2.8.2
	 */
	private function parse_ids( $ids ) {
		if ( empty( $ids ) ) {
			return [];
		}

		return array_filter( array_map( 'absint', explode( ',', $ids ) ) );
	}

	/**
	 * Post a subscriber to a Kit API endpoint.
	 *
	 * Shared helper for tag application, sequence subscription, and form subscription.
	 *
	 * @param string $email_address Subscriber email.
	 * @param string $url Full Kit API endpoint URL.
	 * @param array  $credentials Integration credentials.
	 * @param string $operation Operation name for error messages.
	 * @return array API response.
	 * @since 2.8.2
	 */
	private function post_subscriber_to_endpoint( $email_address, $url, $credentials, $operation ) {
		$payload = wp_json_encode(
			[
				'email_address' => Helper::get_string_value( $email_address ),
			]
		);

		$args = [
			'method'  => 'POST',
			'headers' => [
				'Content-Type'  => 'application/json',
				'X-Kit-Api-Key' => $credentials['api_key'] ?? '',
				'Accept'        => 'application/json',
				'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
			],
			'body'    => $payload ? $payload : '',
			'timeout' => 30,
		];

		$response = wp_remote_post( $url, $args );

		return $this->process_api_response( $response, $operation );
	}

	/**
	 * Process API response
	 *
	 * @param array|\WP_Error $response API response.
	 * @param string          $operation Operation name for error messages.
	 * @return array Processed response.
	 * @since 1.13.0
	 */
	private function process_api_response( $response, $operation ) {
		if ( is_wp_error( $response ) ) {
			return [
				'success' => false,
				'message' => sprintf(
					/* translators: %1$s: operation name, %2$s: error message */
					__( 'Kit %1$s failed: %2$s', 'sureforms-pro' ),
					$operation,
					$response->get_error_message()
				),
			];
		}

		$status_code   = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( $status_code >= 200 && $status_code < 300 ) {
			return [
				'success' => true,
				'message' => sprintf(
					/* translators: %s: operation name */
					__( 'Kit %s completed successfully.', 'sureforms-pro' ),
					$operation
				),
				'data'    => $response_data,
			];
		}

		// Handle error response.
		$error_message = '';
		if ( is_array( $response_data ) ) {
			$error_message = $response_data['message'] ?? $response_data['error'] ?? '';
		}

		if ( empty( $error_message ) ) {
			$error_message = sprintf(
				/* translators: %d: HTTP status code */
				__( 'HTTP %d error', 'sureforms-pro' ),
				$status_code
			);
		}

		return [
			'success' => false,
			'message' => sprintf(
				/* translators: %1$s: operation name, %2$s: error message */
				__( 'Kit %1$s failed: %2$s', 'sureforms-pro' ),
				$operation,
				$error_message
			),
			'data'    => $response_data,
		];
	}

	/**
	 * Get Kit integration credentials
	 *
	 * @return array|false Credentials array or false if not found.
	 * @since 1.13.0
	 */
	private function get_integration_credentials() {
		$integration_data = Integrations::get_by_type( $this->integration_name );

		if ( empty( $integration_data ) || empty( $integration_data['data'] ) ) {
			return false;
		}

		return Integrations::decrypt_sensitive_data( Helper::get_array_value( $integration_data['data'] ) );
	}

	/**
	 * Generate test value for field definition
	 *
	 * @param array $field_def Field definition.
	 * @return mixed Test value.
	 * @since 1.13.0
	 */
	private function generate_test_value( $field_def ) {
		$field_type = $field_def['type'] ?? 'text';
		$field_key  = $field_def['key'] ?? '';

		// Special handling for email fields.
		if ( false !== strpos( $field_key, 'email' ) || 'email' === $field_type ) {
			return 'noreply@sureforms.com';
		}

		// Special handling for name fields.
		if ( false !== strpos( $field_key, 'name' ) ) {
			return 'Test User';
		}

		switch ( $field_type ) {
			case 'email':
				return 'noreply@sureforms.com';

			case 'number':
				return 123;

			case 'textarea':
				return 'This is a test Kit integration from SureForms.';

			case 'text':
			default:
				return 'Test Value';
		}
	}
}
