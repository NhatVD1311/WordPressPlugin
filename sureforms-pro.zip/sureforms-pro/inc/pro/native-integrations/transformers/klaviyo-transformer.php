<?php
/**
 * Klaviyo Payload Transformer
 *
 * Transforms form data to Klaviyo's JSON:API format.
 * Handles profile creation/update, list subscription, and unsubscription.
 *
 * @package SureForms
 * @since 2.7.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Transformers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\Interfaces\Payload_Transformer;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Klaviyo Transformer class.
 *
 * @since 2.7.0
 */
class Klaviyo_Transformer implements Payload_Transformer {
	/**
	 * Integration name
	 *
	 * @var string
	 * @since 2.7.0
	 */
	private $integration_name = 'klaviyo';

	/**
	 * Standard profile attribute fields
	 *
	 * @var array
	 * @since 2.7.0
	 */
	private $standard_fields = [
		'email',
		'first_name',
		'last_name',
		'phone_number',
		'organization',
		'title',
		'image',
	];

	/**
	 * Location-related fields
	 *
	 * @var array
	 * @since 2.7.0
	 */
	private $location_fields = [
		'address1',
		'address2',
		'city',
		'region',
		'zip',
		'country',
	];

	/**
	 * Control fields excluded from API payload
	 *
	 * @var array
	 * @since 2.7.0
	 */
	private $control_fields = [
		'action_type',
		'list_id',
		'consent_type',
	];

	/**
	 * Credentials from framework context
	 *
	 * @var array|null
	 * @since 2.7.0
	 */
	private $context_credentials = null;

	/**
	 * Get integration name this transformer handles
	 *
	 * @return string Integration name.
	 * @since 2.7.0
	 */
	public function get_integration_name() {
		return $this->integration_name;
	}

	/**
	 * Transform payload for Klaviyo integration
	 *
	 * Routes to the appropriate transformation method based on the action type:
	 * - add_update_profile: Builds JSON:API payload for profile-import endpoint
	 * - subscribe_to_list: Pre-processes profile-import, then builds subscription payload
	 * - unsubscribe_from_list: Builds unsubscription payload
	 *
	 * @param array $form_data Original form data.
	 * @param array $field_mappings Field mappings configuration.
	 * @param array $context Additional context data.
	 * @return array Transformed payload.
	 * @since 2.7.0
	 */
	public function transform( $form_data, $field_mappings = [], $context = [] ) {
		unset( $field_mappings );

		// Store context credentials for use in preprocessing API calls.
		$this->context_credentials = $context['credentials'] ?? null;

		// Use action_id from framework context (reliable) with form_data fallback.
		$action_type = $context['action_id'] ?? $form_data['action_type'] ?? 'add_update_profile';

		switch ( $action_type ) {
			case 'subscribe_to_list':
				return $this->transform_subscribe( $form_data );
			case 'unsubscribe_from_list':
				return $this->transform_unsubscribe( $form_data );
			default:
				return $this->transform_profile_import( $form_data );
		}
	}

	/**
	 * Prepare test payload with sample data
	 *
	 * @param array $workflow_fields Fields from the workflow configuration.
	 * @param array $field_definitions Field definitions from the action configuration.
	 * @return array Test payload.
	 * @since 2.7.0
	 */
	public function prepare_test_payload( $workflow_fields, $field_definitions ) {
		$payload = [];

		foreach ( $field_definitions as $field_def ) {
			$field_key = $field_def['key'] ?? '';

			if ( empty( $field_key ) ) {
				continue;
			}

			// Skip fields excluded from payload.
			if ( ! empty( $field_def['exclude_from_payload'] ) ) {
				continue;
			}

			// Use workflow value, field default, or generate test data.
			if ( isset( $workflow_fields[ $field_key ] ) && ! empty( $workflow_fields[ $field_key ] ) ) {
				$payload[ $field_key ] = $workflow_fields[ $field_key ];
			} elseif ( isset( $field_def['default'] ) && '' !== $field_def['default'] ) {
				$payload[ $field_key ] = $field_def['default'];
			} else {
				$payload[ $field_key ] = $this->generate_test_value( $field_def );
			}
		}

		// Apply the same transformation as the real transform method.
		return $this->transform( $payload );
	}

	/**
	 * Transform payload for profile-import endpoint
	 *
	 * Builds the JSON:API payload for POST /api/profile-import.
	 *
	 * @param array $form_data Form data.
	 * @return array JSON:API formatted payload.
	 * @since 2.7.0
	 */
	private function transform_profile_import( $form_data ) {
		$attributes = [];

		// Map standard profile fields.
		foreach ( $this->standard_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$attributes[ $field ] = Helper::get_string_value( $form_data[ $field ] );
			}
		}

		// Build location object from address fields.
		$location = $this->build_location( $form_data );
		if ( ! empty( $location ) ) {
			$attributes['location'] = $location;
		}

		// Collect custom properties (any field not in standard, location, or control fields).
		$properties = $this->collect_custom_properties( $form_data );
		if ( ! empty( $properties ) ) {
			$attributes['properties'] = $properties;
		}

		return [
			'data' => [
				'type'       => 'profile',
				'attributes' => $attributes,
			],
		];
	}

	/**
	 * Transform payload for subscribe-to-list action
	 *
	 * Executes the subscription API call first (so the profile is created and subscribed
	 * to the list in one call), then returns a profile-import payload for the framework
	 * to send — this updates the profile with additional fields (name, address, properties).
	 *
	 * @param array $form_data Form data.
	 * @return array JSON:API formatted profile-import payload.
	 * @since 2.7.0
	 */
	private function transform_subscribe( $form_data ) {
		$credentials = $this->get_credentials();
		$list_id     = sanitize_text_field( Helper::get_string_value( $form_data['list_id'] ?? '' ) );

		if ( ! $credentials ) {
			// Without credentials, preprocessing API calls cannot run — return profile-import
			// as a safe fallback so the framework's main request still creates/updates the profile.
			return $this->transform_profile_import( $form_data );
		}

		// Step 1: Create/update profile via profile-import — returns profile ID.
		$profile_id = $this->import_profile_and_get_id( $form_data, $credentials );

		// Step 2: Add profile to list (direct membership — no opt-in required).
		if ( ! empty( $profile_id ) && ! empty( $list_id ) ) {
			$this->add_profile_to_list( $profile_id, $list_id, $credentials );
		}

		// Step 3: Return consent payload — framework sends this as the main request.
		return $this->build_consent_payload( $form_data, $list_id );
	}

	/**
	 * Build the subscription consent payload
	 *
	 * @param array  $form_data Form data.
	 * @param string $list_id Klaviyo list ID.
	 * @return array JSON:API formatted consent payload.
	 * @since 2.7.0
	 */
	private function build_consent_payload( $form_data, $list_id ) {
		$email              = Helper::get_string_value( $form_data['email'] ?? '' );
		$consent_type       = $form_data['consent_type'] ?? 'email';
		$consented_at       = gmdate( 'Y-m-d\TH:i:sP', time() - HOUR_IN_SECONDS );
		$profile_attributes = [
			'email' => $email,
		];

		// Only include phone_number when SMS consent is selected.
		if ( ! empty( $form_data['phone_number'] ) && in_array( $consent_type, [ 'sms', 'both' ], true ) ) {
			$profile_attributes['phone_number'] = Helper::get_string_value( $form_data['phone_number'] );
		}

		$subscriptions = $this->build_subscriptions( $consent_type, $consented_at );
		if ( ! empty( $subscriptions ) ) {
			$profile_attributes['subscriptions'] = $subscriptions;
		}

		$payload = [
			'data' => [
				'type'       => 'profile-subscription-bulk-create-job',
				'attributes' => [
					'historical_import' => true,
					'profiles'          => [
						'data' => [
							[
								'type'       => 'profile',
								'attributes' => $profile_attributes,
							],
						],
					],
				],
			],
		];

		if ( ! empty( $list_id ) ) {
			$payload['data']['relationships'] = [
				'list' => [
					'data' => [
						'type' => 'list',
						'id'   => $list_id,
					],
				],
			];
		}

		return $payload;
	}

	/**
	 * Import profile and return the Klaviyo profile ID
	 *
	 * @param array $form_data Form data.
	 * @param array $credentials Integration credentials.
	 * @return string|null Profile ID or null on failure.
	 * @since 2.7.0
	 */
	private function import_profile_and_get_id( $form_data, $credentials ) {
		$profile_payload = $this->transform_profile_import( $form_data );
		$encoded_payload = wp_json_encode( $profile_payload );

		$response = wp_remote_post(
			'https://a.klaviyo.com/api/profile-import',
			[
				'headers' => $this->build_api_headers( $credentials ),
				'body'    => $encoded_payload ? $encoded_payload : '',
				'timeout' => 30,
			]
		);

		$result = $this->process_api_response( $response, 'profile import' );

		if ( ! empty( $result['data']['data']['id'] ) ) {
			return $result['data']['data']['id'];
		}

		return null;
	}

	/**
	 * Add a profile to a list via direct list membership
	 *
	 * Uses POST /api/lists/{list_id}/relationships/profiles which immediately
	 * adds the profile to the list without requiring opt-in confirmation.
	 *
	 * @param string $profile_id Klaviyo profile ID.
	 * @param string $list_id Klaviyo list ID.
	 * @param array  $credentials Integration credentials.
	 * @return array API response result.
	 * @since 2.7.0
	 */
	private function add_profile_to_list( $profile_id, $list_id, $credentials ) {
		$payload = wp_json_encode(
			[
				'data' => [
					[
						'type' => 'profile',
						'id'   => sanitize_text_field( $profile_id ),
					],
				],
			]
		);

		$response = wp_remote_post(
			'https://a.klaviyo.com/api/lists/' . sanitize_text_field( $list_id ) . '/relationships/profiles',
			[
				'headers' => $this->build_api_headers( $credentials ),
				'body'    => $payload ? $payload : '',
				'timeout' => 30,
			]
		);

		return $this->process_api_response( $response, 'add to list' );
	}

	/**
	 * Build standard Klaviyo API headers
	 *
	 * @param array $credentials Integration credentials.
	 * @return array Headers array.
	 * @since 2.7.0
	 */
	private function build_api_headers( $credentials ) {
		return [
			'Authorization' => 'Klaviyo-API-Key ' . ( $credentials['api_key'] ?? '' ),
			'Content-Type'  => 'application/json',
			'Accept'        => 'application/json',
			'revision'      => '2024-10-15',
		];
	}

	/**
	 * Get credentials from context or database
	 *
	 * @return array|false Credentials array or false.
	 * @since 2.7.0
	 */
	private function get_credentials() {
		return ! empty( $this->context_credentials ) ? $this->context_credentials : $this->get_integration_credentials();
	}

	/**
	 * Transform payload for unsubscribe-from-list action
	 *
	 * @param array $form_data Form data.
	 * @return array JSON:API formatted unsubscription payload.
	 * @since 2.7.0
	 */
	private function transform_unsubscribe( $form_data ) {
		$email   = Helper::get_string_value( $form_data['email'] ?? '' );
		$list_id = Helper::get_string_value( $form_data['list_id'] ?? '' );

		$payload = [
			'data' => [
				'type'       => 'profile-subscription-bulk-delete-job',
				'attributes' => [
					'profiles' => [
						'data' => [
							[
								'type'       => 'profile',
								'attributes' => [
									'email' => $email,
								],
							],
						],
					],
				],
			],
		];

		// Add list relationship — important to avoid global unsubscribe.
		if ( ! empty( $list_id ) ) {
			$payload['data']['relationships'] = [
				'list' => [
					'data' => [
						'type' => 'list',
						'id'   => $list_id,
					],
				],
			];
		}

		return $payload;
	}

	/**
	 * Build location object from form data
	 *
	 * @param array $form_data Form data.
	 * @return array Location object or empty array.
	 * @since 2.7.0
	 */
	private function build_location( $form_data ) {
		$location = [];

		foreach ( $this->location_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$location[ $field ] = Helper::get_string_value( $form_data[ $field ] );
			}
		}

		return $location;
	}

	/**
	 * Collect custom properties from form data
	 *
	 * Any field not in standard, location, or control fields is treated as a custom property.
	 *
	 * @param array $form_data Form data.
	 * @return array Custom properties key-value pairs.
	 * @since 2.7.0
	 */
	private function collect_custom_properties( $form_data ) {
		$all_known_fields = array_merge( $this->standard_fields, $this->location_fields, $this->control_fields );
		$properties       = [];

		foreach ( $form_data as $field_key => $field_value ) {
			if ( in_array( $field_key, $all_known_fields, true ) || empty( $field_value ) ) {
				continue;
			}
			$properties[ $field_key ] = Helper::get_string_value( $field_value );
		}

		return $properties;
	}

	/**
	 * Build subscriptions object based on consent type
	 *
	 * @param string $consent_type Consent type: 'email', 'sms', or 'both'.
	 * @param string $consented_at ISO 8601 timestamp of when consent was given. Optional.
	 * @return array Subscriptions object.
	 * @since 2.7.0
	 */
	private function build_subscriptions( $consent_type, $consented_at = '' ) {
		$subscriptions = [];

		$marketing_consent = [
			'marketing' => [
				'consent' => 'SUBSCRIBED',
			],
		];

		if ( ! empty( $consented_at ) ) {
			$marketing_consent['marketing']['consented_at'] = $consented_at;
		}

		if ( 'email' === $consent_type || 'both' === $consent_type ) {
			$subscriptions['email'] = $marketing_consent;
		}

		if ( 'sms' === $consent_type || 'both' === $consent_type ) {
			$subscriptions['sms'] = $marketing_consent;
		}

		return $subscriptions;
	}

	/**
	 * Process API response
	 *
	 * @param array|\WP_Error $response API response.
	 * @param string          $operation Operation name for error messages.
	 * @return array Processed response.
	 * @since 2.7.0
	 */
	private function process_api_response( $response, $operation ) {
		if ( is_wp_error( $response ) ) {
			return [
				'success' => false,
				'message' => sprintf(
					/* translators: %1$s: operation name, %2$s: error message */
					__( 'Klaviyo %1$s failed: %2$s', 'sureforms-pro' ),
					$operation,
					$response->get_error_message()
				),
			];
		}

		$status_code   = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( $status_code >= 200 && $status_code < 300 ) {
			return [
				'success' => true,
				'message' => sprintf(
					/* translators: %s: operation name */
					__( 'Klaviyo %s completed successfully.', 'sureforms-pro' ),
					$operation
				),
				'data'    => $response_data,
			];
		}

		// Handle error response.
		$error_message = '';
		if ( is_array( $response_data ) ) {
			// Klaviyo returns errors in JSON:API format.
			if ( ! empty( $response_data['errors'][0]['detail'] ) ) {
				$error_message = $response_data['errors'][0]['detail'];
			} elseif ( ! empty( $response_data['message'] ) ) {
				$error_message = $response_data['message'];
			}
		}

		if ( empty( $error_message ) ) {
			$error_message = sprintf(
				/* translators: %d: HTTP status code */
				__( 'HTTP %d error', 'sureforms-pro' ),
				$status_code
			);
		}

		return [
			'success' => false,
			'message' => sprintf(
				/* translators: %1$s: operation name, %2$s: error message */
				__( 'Klaviyo %1$s failed: %2$s', 'sureforms-pro' ),
				$operation,
				$error_message
			),
			'data'    => $response_data,
		];
	}

	/**
	 * Get Klaviyo integration credentials
	 *
	 * @return array|false Credentials array or false if not found.
	 * @since 2.7.0
	 */
	private function get_integration_credentials() {
		$integration_data = Integrations::get_by_type( $this->integration_name );

		if ( empty( $integration_data ) || empty( $integration_data['data'] ) ) {
			return false;
		}

		return Integrations::decrypt_sensitive_data( Helper::get_array_value( $integration_data['data'] ) );
	}

	/**
	 * Generate test value for field definition
	 *
	 * @param array $field_def Field definition.
	 * @return mixed Test value.
	 * @since 2.7.0
	 */
	private function generate_test_value( $field_def ) {
		$field_type = $field_def['type'] ?? 'text';
		$field_key  = $field_def['key'] ?? '';

		// Special handling for email fields.
		if ( false !== strpos( $field_key, 'email' ) || 'email' === $field_type ) {
			return 'noreply@sureforms.com';
		}

		// Special handling for name fields.
		if ( false !== strpos( $field_key, 'name' ) ) {
			return 'Test User';
		}

		switch ( $field_type ) {
			case 'email':
				return 'noreply@sureforms.com';
			case 'number':
				return 123;
			case 'textarea':
				return 'Test Klaviyo integration from SureForms.';
			case 'tel':
				return '+1234567890';
			case 'url':
				return 'https://example.com';
			case 'select':
				// Return first option value if available.
				if ( ! empty( $field_def['options'][0]['value'] ) ) {
					return $field_def['options'][0]['value'];
				}
				return $field_def['default'] ?? '';
			case 'text':
			default:
				return 'Test Value';
		}
	}
}
