<?php
/**
 * Workflow Processor Service
 *
 * Handles form workflow processing for native integrations.
 *
 * @package SureForms
 * @since 1.13.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Services;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\Factories\Transformer_Factory;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Handler;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Registry;
use SRFM_Pro\Inc\Pro\Native_Integrations\OAuth_Handler;
use SRFM_Pro\Inc\Pro\Native_Integrations\Provider_Factory;
use SRFM_Pro\Inc\Pro\Native_Integrations\Utils\Integration_Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Workflow Processor Service class.
 *
 * @since 1.13.0
 */
class Workflow_Processor {
	/**
	 * Original form data context for enhanced transformations
	 *
	 * @var array
	 * @since 1.13.0
	 */
	private $original_form_data_context = [];
	/**
	 * Config Manager instance
	 *
	 * @var Config_Manager
	 */
	private $config_manager;

	/**
	 * OAuth Handler instance
	 *
	 * @var OAuth_Handler
	 * @since 2.1.0
	 */
	private $oauth_handler;

	/**
	 * Constructor
	 *
	 * @param Config_Manager $config_manager Config manager instance.
	 * @param OAuth_Handler  $oauth_handler OAuth handler instance.
	 * @since 1.13.0
	 */
	public function __construct( Config_Manager $config_manager, OAuth_Handler $oauth_handler ) {
		$this->config_manager = $config_manager;
		$this->oauth_handler  = $oauth_handler;
		add_action( 'srfm_after_submission_process', [ $this, 'process_form_workflows' ] );
	}

	/**
	 * Process form workflows
	 *
	 * @param array $form_data Form submission data.
	 * @return void
	 * @since 1.13.0
	 */
	public function process_form_workflows( $form_data ) {
		$form_id = absint( $form_data['form_id'] ?? 0 );

		// Get native integrations meta for this form.
		$workflows_json = get_post_meta( $form_id, '_srfm_native_integrations', true );
		$workflows      = [];

		if ( ! empty( $workflows_json ) && is_string( $workflows_json ) ) {
			$decoded   = json_decode( $workflows_json, true );
			$workflows = is_array( $decoded ) ? $decoded : [];
		}

		if ( empty( $workflows ) ) {
			return; // No workflows configured.
		}

		// Prepare submission data for processing.
		$filtered_form_data = array_filter(
			$form_data,
			static function ( $key ) {
				return ! in_array( $key, [ 'form_id', 'submission_id' ], true );
			},
			ARRAY_FILTER_USE_KEY
		);

		$submission_id = absint( $form_data['submission_id'] ?? 0 );

		$workflow_logs = [];

		// Process each workflow.
		foreach ( $workflows as $workflow ) {
			if ( ! $this->is_workflow_enabled( $workflow ) ) {
				continue; // Skip disabled workflows.
			}

			$result                = $this->process_single_workflow( $workflow, $filtered_form_data, $form_id, $submission_id );
			$result['id']          = isset( $workflow['id'] ) ? Helper::get_string_value( $workflow['id'] ) : '';
			$result['integration'] = $result['integration'] ?? ( $workflow['integration'] ?? '' );
			$workflow_logs[]       = $result;
		}

		// Save workflow results to database or log.
		if ( ! empty( $workflow_logs ) ) {
			$this->save_workflow_results( $form_data['submission_id'] ?? 0, $workflow_logs );
		}
	}

	/**
	 * Test workflow configuration
	 *
	 * @param \WP_REST_Request $request The REST request.
	 * @return \WP_REST_Response
	 * @since 1.13.0
	 */
	public function test_workflow( $request ) {
		$integration = $request->get_param( 'integration' );
		$workflow    = $request->get_param( 'workflow' );

		if ( empty( $integration ) || empty( $workflow ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Integration and workflow configuration are required.', 'sureforms-pro' ),
				],
				400
			);
		}

		// The unified file-upload workflow has no connection record or
		// endpoint of its own — "testing" it means verifying the selected
		// provider is connected and its folders are reachable.
		if ( File_Storage_Handler::INTEGRATION === $integration ) {
			return $this->test_file_upload_workflow( is_array( $workflow ) ? $workflow : [] );
		}

		try {
			// Load integration configuration.
			$integration_config = $this->config_manager->load_integration_config( Helper::get_string_value( $integration ) );
			if ( ! $integration_config ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Integration configuration not found.', 'sureforms-pro' ),
					],
					404
				);
			}

			// Find action configuration.
			$action        = is_array( $workflow ) && isset( $workflow['action'] ) ? Helper::get_string_value( $workflow['action'] ) : '';
			$action_config = $this->config_manager->find_action_config( $integration_config, $action );
			if ( ! $action_config ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Action configuration not found.', 'sureforms-pro' ),
					],
					404
				);
			}

			// Get integration credentials from database.
			$integration_data = Integrations::get_by_type( sanitize_key( Helper::get_string_value( $integration ) ) );

			if ( empty( $integration_data ) || empty( $integration_data['status'] ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Integration is not configured or enabled.', 'sureforms-pro' ),
					],
					400
				);
			}

			// Get decrypted credentials with OAuth validation.
			$integration_type = sanitize_key( Helper::get_string_value( $integration ) );
			$auth_config      = $integration_config['auth'] ?? [];
			$credentials      = Integration_Utils::get_stored_credentials( $integration_type, $auth_config, $this->oauth_handler );
			if ( is_wp_error( $credentials ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => sprintf(
							/* translators: %s: Error message */
							__( 'Failed to get credentials: %s', 'sureforms-pro' ),
							$credentials->get_error_message()
						),
					],
					400
				);
			}

			// Check if this is a WordPress plugin integration.
			$provider = $integration_config['provider'] ?? 'generic';

			// phpcs:ignore WordPress.WP.CapitalPDangit.Misspelled -- Configuration uses lowercase.
			if ( 'wordpress' === strtolower( $provider ) ) {
				return $this->test_wordpress_plugin_workflow( $integration_config, $action_config, Helper::get_array_value( $workflow ) );
			}

			// Prepare the test payload for API integrations.
			$endpoint_config = $action_config['endpoint'] ?? [];

			if ( empty( $endpoint_config['url'] ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'No endpoint URL configured for this action.', 'sureforms-pro' ),
					],
					400
				);
			}

			$workflow_fields = is_array( $workflow ) && isset( $workflow['fields'] ) && is_array( $workflow['fields'] ) ? $workflow['fields'] : [];
			$action_fields   = isset( $action_config['fields'] ) && is_array( $action_config['fields'] ) ? $action_config['fields'] : [];

			// Prepare test data for all fields (both for payload and URL processing).
			$all_test_fields = $this->prepare_all_test_data( $workflow_fields, $action_fields, false );

			// Process URL template variables with enhanced processing BEFORE payload building
			// so that resolved lookups (e.g., contact_id) are available for the payload.
			$all_test_data    = array_merge( $all_test_fields, $credentials );
			$resolved_lookups = [];
			$url              = $this->process_url_with_enhanced_config(
				$endpoint_config['url'],
				$all_test_data,
				$endpoint_config['url_processing'] ?? [],
				$resolved_lookups
			);

			// Early exit if a required lookup failed.
			if ( ! empty( $resolved_lookups['__lookup_failed'] ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => $resolved_lookups['__lookup_error'] ?? __( 'Required field lookup failed.', 'sureforms-pro' ),
					],
					400
				);
			}

			// Merge resolved lookup values into test fields for payload building.
			$lookup_values = array_filter( $resolved_lookups, static fn( $k ) => strpos( $k, '__' ) !== 0, ARRAY_FILTER_USE_KEY );
			if ( ! empty( $lookup_values ) ) {
				$all_test_fields = array_merge( $all_test_fields, $lookup_values );
			}

			// Use generic test payload preparation.
			$payload = $this->prepare_test_payload( $all_test_fields, $action_fields, false );

			// Apply optional specific transformer enhancement for test payload (if available).
			$integration_name = $this->get_integration_name_from_action( $action_config );
			if ( $integration_name ) {
				$transformer = Transformer_Factory::create( $integration_name );
				if ( $transformer ) {
					$payload = $transformer->prepare_test_payload( $all_test_fields, $action_fields );
				}
			}

			// Prepare request args.
			$args = [
				'method'  => $endpoint_config['method'] ?? 'POST',
				'headers' => Integration_Utils::build_auth_headers(
					$credentials,
					$integration_config,
					[
						'default_headers' => [
							'User-Agent' => 'SureForms Pro/' . SRFM_PRO_VER,
						],
					]
				),
				'timeout' => 30,
			];

			// Add payload based on method and payload type.
			$payload_type = $endpoint_config['payload_type'] ?? 'json';
			if ( in_array( $args['method'], [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				if ( 'json' === $payload_type ) {
					// Apply payload transformations if configured.
					if ( ! empty( $action_config['payload_transformation'] ) ) {
						$payload = $this->apply_payload_transformations( $payload, $action_config['payload_transformation'] );
					}
					$json_body                       = wp_json_encode( $payload );
					$args['body']                    = false !== $json_body ? $json_body : '{}';
					$args['headers']['Content-Type'] = 'application/json';
				} else {
					$args['body'] = $this->form_encode_payload( $payload );
				}
			}

			// Make the test request.
			$response = wp_safe_remote_request( $url, $args );

			if ( is_wp_error( $response ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => sprintf(
							/* translators: %s: Error message from the API response */
							__( 'Test failed: %s', 'sureforms-pro' ),
							$response->get_error_message()
						),
					],
					500
				);
			}

			$status_code   = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );

			// Consider 2xx status codes as success.
			if ( $status_code >= 200 && $status_code < 300 ) {
				// Execute post-actions for test workflow if configured.
				$post_action_errors = [];
				if ( ! empty( $action_config['post_actions'] ) ) {
					$post_action_errors = $this->execute_post_actions(
						$action_config['post_actions'],
						$response_body,
						$all_test_fields,
						$credentials,
						$integration_config
					);
				}

				$test_message = sprintf(
					/* translators: %s: Workflow name */
					__( 'Workflow "%s" tested successfully! The integration is working correctly.', 'sureforms-pro' ),
					is_array( $workflow ) && isset( $workflow['name'] ) ? Helper::get_string_value( $workflow['name'] ) : __( 'Unnamed workflow', 'sureforms-pro' )
				);

				// Append post-action errors to the test response message.
				if ( ! empty( $post_action_errors ) ) {
					$test_message .= ' | ' . implode( ' | ', $post_action_errors );
				}

				return new \WP_REST_Response(
					[
						'success'  => true,
						'warnings' => $post_action_errors,
						'message'  => $test_message,
						'details'  => [
							'status_code' => $status_code,
							'response'    => wp_strip_all_tags( $response_body ),
						],
					],
					200
				);
			}

			// Parse error message from response.
			$error_data    = json_decode( $response_body, true );
			$error_message = '';
			if ( ! is_array( $error_data ) && ! empty( $response_body ) && is_string( $response_body ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => wp_strip_all_tags( $response_body ),
					],
					500
				);
			}

			if ( is_array( $error_data ) ) {
				$error_message = $error_data['message'] ?? $error_data['error'] ?? $error_data['detail'] ?? '';

				// Support JSON:API error format (e.g., Klaviyo).
				if ( empty( $error_message ) && ! empty( $error_data['errors'][0]['detail'] ) ) {
					$error_message = $error_data['errors'][0]['detail'];
				}

				// Support indexed array error format (e.g., Constant Contact).
				if ( empty( $error_message ) && ! empty( $error_data[0]['error_message'] ) ) {
					$error_message = $error_data[0]['error_message'];
				}
			}

			if ( empty( $error_message ) ) {
				/* translators: %d: HTTP status code */
				$error_message = sprintf( __( 'HTTP %d error', 'sureforms-pro' ), $status_code );
			}

				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => sprintf(
							/* translators: %1$s: Error message, %2$d: HTTP status code */
							__( 'Test failed: %1$s (HTTP %2$d)', 'sureforms-pro' ),
							$error_message,
							$status_code
						),
						'details' => [
							'status_code' => $status_code,
							'response'    => wp_strip_all_tags( $response_body ),
						],
					],
					400
				);

		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => sprintf(
						/* translators: %s: Exception error message */
						__( 'Test failed: %s', 'sureforms-pro' ),
						$e->getMessage()
					),
				],
				500
			);
		}
	}

	/**
	 * Process template variables in a string
	 *
	 * @param string $template Template string with variables like {{variable}}.
	 * @param array  $fields Field values.
	 * @param array  $credentials Credential values.
	 * @return string Processed string.
	 * @since 1.13.0
	 */
	public static function process_template_variables( $template, $fields, $credentials = [] ) {
		// Ensure template is a string.
		$template = Helper::get_string_value( $template );

		// Merge fields and credentials for variable replacement.
		$variables = array_merge( $fields, $credentials );

		// Replace {{variable}} patterns.
		$result = preg_replace_callback(
			'/\{\{([^}]+)\}\}/',
			static function ( $matches ) use ( $variables ) {
				$key = trim( $matches[1] );

				// Handle special case for base64 encoding.
				if ( 0 === strpos( $key, 'base64(' ) && ')' === substr( $key, -1 ) ) {
					// Extract the expression inside base64().
					$expression = substr( $key, 7, -1 );

					// Handle username:password pattern.
					if ( false !== strpos( $expression, ':' ) ) {
						[ $user_key, $pass_key ] = explode( ':', $expression, 2 );
						$username                = $variables[ trim( $user_key ) ] ?? '';
						$password                = $variables[ trim( $pass_key ) ] ?? '';
						// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Used for HTTP Basic Auth encoding, not obfuscation.
						return base64_encode( $username . ':' . $password );
					}
				}

				// Default: return the variable value or keep the placeholder.
				return $variables[ $key ] ?? $matches[0];
			},
			$template
		);

		// Ensure we always return a string.
		return is_string( $result ) ? $result : $template;
	}

	/**
	 * Get nested value from array using dot notation path
	 *
	 * @param array  $data Array to search.
	 * @param string $path Dot notation path (e.g., 'merge_fields.BIRTHDAY').
	 * @return mixed Value at path or null if not found.
	 * @since 1.13.0
	 */
	public static function get_nested_value( $data, $path ) {
		$keys  = explode( '.', $path );
		$value = $data;

		foreach ( $keys as $key ) {
			// Handle array indices (e.g., "0", "1", etc.).
			if ( is_numeric( $key ) ) {
				$key = (int) $key;
			}

			if ( is_array( $value ) && isset( $value[ $key ] ) ) {
				$value = $value[ $key ];
			} else {
				return null;
			}
		}

		return $value;
	}

	/**
	 * Generate test value based on field definition
	 *
	 * @param array $field Field definition.
	 * @return mixed Test value.
	 * @since 1.13.0
	 */
	public static function generate_test_value( $field ) {
		$field_type = $field['type'] ?? 'text';
		$field_key  = $field['key'] ?? '';

		if ( isset( $field['test_value'] ) ) {
			return $field['test_value'];
		}

		// Skip dropdown/select fields since they should only contain valid API options.
		if ( in_array( $field_type, [ 'select', 'dropdown', 'select-async' ], true ) ) {
			return null;
		}

		// Special handling for email fields.
		if ( false !== strpos( $field_key, 'email' ) || false !== strpos( $field_key, 'mail' ) ) {
			return 'noreply@sureforms.com';
		}

		// Special handling for name fields.
		if ( false !== strpos( $field_key, 'name' ) && 'name' === $field_key ) {
			return 'Test User';
		}
		if ( false !== strpos( $field_key, 'ipaddress' ) ) {
			return '192.168.1.1';
		}

		switch ( $field_type ) {
			case 'email':
				return 'noreply@sureforms.com';

			case 'number':
				return 123;

			case 'textarea':
				return 'This is a test workflow submission from SureForms.';

			case 'checkbox':
				return true;
			case 'date':
				return '1970-01-01';
			case 'datetime':
			case 'datetime-local':
				// Offset "end" datetime fields by an hour so APIs that require end > start (e.g., Bigin events) accept the test payload.
				if ( false !== stripos( $field_key, 'end' ) ) {
					return '1970-01-01T11:00:00';
				}
				return '1970-01-01T10:00:00';

			case 'text':
			default:
				// Return a contextual test value based on field key.
				if ( false !== strpos( $field_key, 'phone' ) ) {
					return '+1234567890';
				}
				if ( false !== strpos( $field_key, 'url' ) || false !== strpos( strtolower( $field_key ), 'website' ) ) {
					return 'https://sureforms.com';
				}
				if ( false !== strpos( $field_key, 'address' ) ) {
					return '123 Test Street';
				}
				if ( false !== strpos( $field_key, 'city' ) ) {
					return 'Test City';
				}
				if ( false !== strpos( $field_key, 'state' ) ) {
					return 'CA';
				}
				if ( false !== strpos( $field_key, 'zip' ) || false !== strpos( $field_key, 'postal' ) ) {
					return '12345';
				}
				if ( false !== strpos( $field_key, 'country' ) ) {
					return 'US';
				}

				return 'Test Value';
		}
	}

	/**
	 * Prepare test payload with sample data
	 *
	 * @param array $workflow_fields Fields from the workflow configuration.
	 * @param array $field_definitions Field definitions from the action configuration.
	 * @param bool  $is_wordpress_action Whether this is a WordPress plugin action.
	 * @return array Test payload.
	 * @since 1.13.0
	 */
	public static function prepare_test_payload( $workflow_fields, $field_definitions, $is_wordpress_action = false ) {
		$payload          = [];
		$processed_fields = [];
		// First, process fields defined in the action configuration.
		foreach ( $field_definitions as $field_def ) {
			$field_key = $field_def['key'] ?? '';

			if ( empty( $field_key ) ) {
				continue;
			}

			// Check if field should be excluded from payload.
			$exclude_from_payload = $field_def['exclude_from_payload'] ?? false;

			if ( $exclude_from_payload ) {
				$processed_fields[ $field_key ] = true; // Mark as processed but don't include in payload.
				continue; // Skip excluded fields in generic test payload.
			}

			// Get field value (from workflow or generate test data).
			$field_value = null;
			if ( isset( $workflow_fields[ $field_key ] ) && ! empty( $workflow_fields[ $field_key ] ) ) {
				$field_value = $workflow_fields[ $field_key ];
			} else {
				// For WordPress actions, only generate test values for required fields.
				$is_required = ! empty( $field_def['required'] );
				if ( $is_wordpress_action && ! $is_required ) {
					continue; // Skip unconfigured optional fields for WordPress actions.
				}
				$field_value = self::generate_test_value( $field_def );
			}

			// Add to payload if not null.
			if ( null !== $field_value ) {
				$payload[ $field_key ] = $field_value;
			}

			$processed_fields[ $field_key ] = true; // Mark as processed.
		}

		// Second, process any additional workflow fields not defined in action config (e.g., dynamic fields).
		foreach ( $workflow_fields as $field_key => $field_value ) {
			// Skip if already processed or if value is empty.
			if ( isset( $processed_fields[ $field_key ] ) || empty( $field_value ) ) {
				continue;
			}

			// Add dynamic field to payload.
			$payload[ $field_key ] = $field_value;
		}

		return $payload;
	}

	/**
	 * Re-dispatch a single failed native-integration workflow for a stored entry.
	 *
	 * Replays the workflow using the entry's stored form_data (the same payload the
	 * original submission dispatched), updates its per-workflow status + activity
	 * log, and returns the outcome.
	 *
	 * @param int        $submission_id Entry ID.
	 * @param int|string $workflow_id   The workflow id to retry.
	 * @since 2.12.1
	 * @return array<string,mixed> { success: bool, status: string, message: string }
	 */
	public function retry_workflow( $submission_id, $workflow_id ) {
		$submission_id = Helper::get_integer_value( $submission_id );
		$entry         = Entries::get( $submission_id );

		if ( empty( $entry ) || empty( $entry['form_id'] ) ) {
			return [
				'success' => false,
				'status'  => 'failed',
				'message' => __( 'Entry not found.', 'sureforms-pro' ),
			];
		}

		$form_id        = Helper::get_integer_value( $entry['form_id'] );
		$workflows_json = get_post_meta( $form_id, '_srfm_native_integrations', true );
		$workflows      = [];
		if ( ! empty( $workflows_json ) && is_string( $workflows_json ) ) {
			$decoded   = json_decode( $workflows_json, true );
			$workflows = is_array( $decoded ) ? $decoded : [];
		}

		$target = null;
		foreach ( $workflows as $workflow ) {
			if ( is_array( $workflow ) && isset( $workflow['id'] ) && Helper::get_string_value( $workflow['id'] ) === Helper::get_string_value( $workflow_id ) ) {
				$target = $workflow;
				break;
			}
		}

		if ( null === $target ) {
			return [
				'success' => false,
				'status'  => 'failed',
				'message' => __( 'Workflow configuration not found for this form.', 'sureforms-pro' ),
			];
		}

		$form_data = Helper::get_array_value( $entry['form_data'] );

		$result                = $this->process_single_workflow( $target, $form_data, $form_id, $submission_id );
		$result['id']          = Helper::get_string_value( $workflow_id );
		$result['integration'] = $result['integration'] ?? ( $target['integration'] ?? '' );

		// Reuse save_workflow_results so the activity log and the per-workflow
		// status map are updated consistently (it merges, preserving other workflows).
		$this->save_workflow_results( $submission_id, [ $result ], true );

		// On success, drop the retry tag from the original failed log row(s) so they
		// no longer show a Retry button for an already-resolved workflow.
		if ( ! empty( $result['success'] ) ) {
			Pro_Helper::clear_log_retry_tag( $submission_id, 'native', Helper::get_string_value( $workflow_id ) );
		}

		$status = $this->format_workflow_status( $result );

		return [
			'success' => ! empty( $result['success'] ),
			'status'  => $status['status'],
			'message' => $status['message'],
		];
	}

	/**
	 * Form-encode a payload for non-JSON (application/x-www-form-urlencoded) requests.
	 *
	 * Form-encoded APIs expect scalar field values. A structured smart-tag value
	 * (e.g. survey/poll results emitted by Survey_Smart_Tags for integrations)
	 * resolves to an array, which http_build_query() would otherwise explode into
	 * `field[key]=...` bracket notation. JSON-encode any array value first so each
	 * field serializes as a single string. JSON payloads are unaffected — they keep
	 * the nested array via wp_json_encode().
	 *
	 * @param mixed $payload Field => value map, or a scalar body.
	 * @return string Form-encoded request body.
	 * @since 2.10.0
	 */
	private function form_encode_payload( $payload ) {
		if ( ! is_array( $payload ) ) {
			return Helper::get_string_value( $payload );
		}

		$flattened = array_map(
			static function ( $value ) {
				if ( ! is_array( $value ) ) {
					return $value;
				}
				$encoded = wp_json_encode( $value );
				return false !== $encoded ? $encoded : '';
			},
			$payload
		);

		return http_build_query( $flattened );
	}

	/**
	 * Test WordPress plugin workflow configuration
	 *
	 * @param array $integration_config Integration configuration.
	 * @param array $action_config Action configuration.
	 * @param array $workflow Workflow configuration.
	 * @return \WP_REST_Response
	 * @since 1.13.0
	 */
	private function test_wordpress_plugin_workflow( $integration_config, $action_config, $workflow ) {
		try {
			// Create provider instance.
			$provider = Provider_Factory::create( $integration_config['integration']['name'] ?? '', $integration_config );

			if ( ! $provider ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Failed to create provider instance for testing.', 'sureforms-pro' ),
					],
					500
				);
			}

			// Check if plugin is active first.
			if ( ! method_exists( $provider, 'is_plugin_active' ) || ! $provider->is_plugin_active() ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => sprintf(
							/* translators: %s: Plugin name */
							__( '%s plugin is not installed or not active.', 'sureforms-pro' ),
							$integration_config['integration']['name'] ?? 'Plugin'
						),
					],
					400
				);
			}

			// Prepare test data.
			$workflow_fields = is_array( $workflow ) && isset( $workflow['fields'] ) && is_array( $workflow['fields'] ) ? $workflow['fields'] : [];
			$action_fields   = isset( $action_config['fields'] ) && is_array( $action_config['fields'] ) ? $action_config['fields'] : [];

			// Generate comprehensive test data.
			$is_wordpress_action = ( $integration_config['provider'] ?? '' ) === 'wordpress'; // phpcs:ignore WordPress.WP.CapitalPDangit.Misspelled -- Configuration uses lowercase.
			$test_data           = $this->prepare_all_test_data( $workflow_fields, $action_fields, $is_wordpress_action );

			// Execute the action in test mode.
			$action_name = $action_config['name'] ?? '';

			// Add test mode flag to prevent real data creation.
			$test_data['_test_mode'] = true;

			if ( ! method_exists( $provider, 'execute_action' ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Provider does not support action execution.', 'sureforms-pro' ),
					],
					500
				);
			}

			// Execute the action.
			$result = $provider->execute_action( $action_name, $test_data );

			if ( ! is_array( $result ) ) {
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => __( 'Invalid response from action execution.', 'sureforms-pro' ),
					],
					500
				);
			}

			$success = $result['success'] ?? false;
			$message = $result['message'] ?? __( 'No response message available.', 'sureforms-pro' );

			if ( $success ) {
				return new \WP_REST_Response(
					[
						'success' => true,
						'message' => sprintf(
							/* translators: %s: Workflow name */
							__( 'WordPress plugin workflow "%s" tested successfully! The integration is working correctly.', 'sureforms-pro' ),
							is_array( $workflow ) && isset( $workflow['name'] ) ? Helper::get_string_value( $workflow['name'] ) : __( 'Unnamed workflow', 'sureforms-pro' )
						),
						'details' => [
							'test_data' => $test_data,
							'result'    => $result,
						],
					],
					200
				);
			}
				return new \WP_REST_Response(
					[
						'success' => false,
						'message' => sprintf(
							/* translators: %s: Error message */
							__( 'WordPress plugin workflow test failed: %s', 'sureforms-pro' ),
							$message
						),
						'details' => [
							'test_data' => $test_data,
							'result'    => $result,
						],
					],
					400
				);

		} catch ( \Exception $e ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => sprintf(
						/* translators: %s: Exception error message */
						__( 'WordPress plugin workflow test failed: %s', 'sureforms-pro' ),
						$e->getMessage()
					),
				],
				500
			);
		}
	}

	/**
	 * Check if workflow is enabled
	 *
	 * @param array $workflow Workflow configuration.
	 * @return bool True if enabled, false otherwise.
	 * @since 1.13.0
	 */
	private function is_workflow_enabled( $workflow ) {
		return isset( $workflow['status'] ) &&
			( 'enabled' === $workflow['status'] || true === $workflow['status'] );
	}

	/**
	 * Test the unified file-upload workflow.
	 *
	 * Verifies the selected storage provider is connected and its folders
	 * are reachable — the meaningful equivalent of a connection test for a
	 * workflow that has no endpoint of its own.
	 *
	 * @param array<string,mixed> $workflow Workflow config (expects `fields.provider`).
	 * @return \WP_REST_Response
	 * @since 2.11.0
	 */
	private function test_file_upload_workflow( $workflow ) {
		$fields       = isset( $workflow['fields'] ) && is_array( $workflow['fields'] ) ? $workflow['fields'] : [];
		$provider_key = Helper::get_string_value( $fields['provider'] ?? '' );

		if ( '' === $provider_key ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Select a storage source before testing.', 'sureforms-pro' ),
				],
				400
			);
		}

		$provider = File_Storage_Registry::get_instance()->get( $provider_key );
		if ( ! $provider instanceof File_Storage_Provider || ! $provider->is_connected() ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => sprintf(
						/* translators: %s: provider key. */
						__( 'The selected storage provider (%s) is not connected.', 'sureforms-pro' ),
						$provider_key
					),
				],
				400
			);
		}

		$credentials = $provider->get_credentials();
		if ( is_wp_error( $credentials ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => sprintf(
						/* translators: 1: provider label. 2: error message. */
						__( 'Could not load credentials for %1$s: %2$s', 'sureforms-pro' ),
						$provider->get_label(),
						$credentials->get_error_message()
					),
				],
				400
			);
		}

		$container = Helper::get_string_value( $fields['bucket'] ?? '' );
		$folders   = $provider->list_folders( $credentials, $container );

		return new \WP_REST_Response(
			[
				'success' => true,
				'message' => sprintf(
					/* translators: 1: provider label. 2: folder count. */
					__( 'Connected to %1$s. %2$d folder(s) available.', 'sureforms-pro' ),
					$provider->get_label(),
					count( $folders )
				),
			],
			200
		);
	}

	/**
	 * Check whether an integration is enabled/configured.
	 *
	 * @param string $integration_type Integration type.
	 * @return bool
	 * @since 1.13.0
	 */
	private function is_integration_enabled( $integration_type ) {
		// The synthetic "Third Party File Upload" workflow has no connection
		// record of its own — it is enabled whenever at least one file-storage
		// provider (Dropbox, Google Drive, AWS) is connected.
		if ( File_Storage_Handler::INTEGRATION === $integration_type ) {
			return File_Storage_Registry::get_instance()->has_any_connected();
		}

		$integration = Integrations::get_by_type( $integration_type );

		if ( empty( $integration ) ) {
			return false;
		}

		return isset( $integration['status'] ) && '1' === $integration['status'];
	}

	/**
	 * Process a single workflow
	 *
	 * @param array $workflow Workflow configuration.
	 * @param array $submission_data Form submission data.
	 * @param int   $form_id Form ID.
	 * @param int   $submission_id Entry record ID for the current submission (0 if unknown).
	 * @return array Processing result.
	 * @throws \Exception When integration or action configuration is not found.
	 * @since 1.13.0
	 */
	private function process_single_workflow( $workflow, $submission_data, $form_id, $submission_id = 0 ) {
		$integration_type = $workflow['integration'];

		// Check if integration is enabled.
		if ( ! $this->is_integration_enabled( $integration_type ) ) {
			return [
				'workflow_name' => $workflow['name'] ?? 'Unnamed',
				'integration'   => $integration_type,
				'success'       => false,
				'message'       => __( 'Integration is disabled or not configured.', 'sureforms-pro' ),
			];
		}

		// Check conditional logic before processing workflow.
		if ( ! empty( $workflow['conditionalLogic'] ) && ! empty( $workflow['conditionalLogic']['status'] ) ) {
			// Map submission data to the format expected by conditional logic checker.
			$submission_mapped = Helper::map_slug_to_submission_data( $submission_data );

			// Evaluate conditional logic.
			if ( ! Pro_Helper::check_trigger_conditions( $workflow, $submission_mapped ) ) {
				return [
					'workflow_name' => $workflow['name'] ?? __( 'Unnamed', 'sureforms-pro' ),
					'integration'   => $integration_type,
					'success'       => false,
					'message'       => __( 'Workflow was not triggered - conditions not met.', 'sureforms-pro' ),
					'skipped'       => true,
				];
			}
		}

		// The unified "Third Party File Upload" workflow does not use the
		// generic endpoint/credential machinery — it resolves the selected
		// provider and pushes files directly. Dispatch it to its handler.
		if ( File_Storage_Handler::INTEGRATION === $integration_type ) {
			$result = File_Storage_Handler::get_instance()->handle_workflow( $workflow, $submission_data, $form_id, $submission_id );
			if ( ! empty( $result['success'] ) ) {
				$this->increment_workflow_run_count( $form_id, $workflow['id'] ?? '' );
			}
			return $result;
		}

		try {
			// Load integration configuration.
			$integration_config = $this->config_manager->load_integration_config( $integration_type );
			if ( ! $integration_config ) {
				throw new \Exception( __( 'Integration configuration not found.', 'sureforms-pro' ) );
			}

			// Get action configuration.
			$action_config = $this->get_action_config( $integration_config, $workflow['action'] ?? '' );
			if ( ! $action_config ) {
				throw new \Exception( __( 'Action configuration not found.', 'sureforms-pro' ) );
			}

			// Get integration credentials with OAuth validation.
			$auth_config = $integration_config['auth'] ?? [];
			$credentials = Integration_Utils::get_stored_credentials( $integration_type, $auth_config, $this->oauth_handler );
			if ( is_wp_error( $credentials ) ) {
				return [
					'success' => false,
					'message' => sprintf(
						/* translators: %s: Error message */
						__( 'Failed to get credentials: %s', 'sureforms-pro' ),
						$credentials->get_error_message()
					),
				];
			}

			// Process workflow fields (replace smart tags, etc.).
			$workflow_fields  = isset( $workflow['fields'] ) && is_array( $workflow['fields'] ) ? $workflow['fields'] : [];
			$processed_fields = $this->process_workflow_fields( $workflow_fields, $submission_data, $form_id );

			// Execute the workflow.
			$result = $this->execute_workflow( $integration_config, $action_config, $credentials, $processed_fields, $submission_data, $workflow, $submission_id );

			// Update run count if workflow executed successfully.
			if ( $result['success'] ) {
				$this->increment_workflow_run_count( $form_id, $workflow['id'] ?? '' );

				$delay = absint( $action_config['delay_after_execution'] ?? 0 );
				if ( $delay > 0 ) {
					sleep( $delay );
				}
			}

			return [
				'workflow_name' => $workflow['name'] ?? 'Unnamed',
				'integration'   => $integration_type,
				'success'       => $result['success'],
				'message'       => $result['message'],
				'response'      => $result['response'] ?? null,
			];

		} catch ( \Exception $e ) {
			return [
				'workflow_name' => $workflow['name'] ?? 'Unnamed',
				'integration'   => $integration_type,
				'success'       => false,
				'message'       => $e->getMessage(),
			];
		}
	}

	/**
	 * Get action configuration from integration config
	 *
	 * @param array  $integration_config Integration configuration.
	 * @param string $action_value Action value to find.
	 * @return array|null Action configuration or null if not found.
	 * @since 1.13.0
	 */
	private function get_action_config( $integration_config, $action_value ) {
		if ( ! isset( $integration_config['actions'] ) || ! is_array( $integration_config['actions'] ) ) {
			return null;
		}

		foreach ( $integration_config['actions'] as $action ) {
			// Generate action value from name (same logic as API callback).
			$generated_action_value = sanitize_key( str_replace( ' ', '_', strtolower( $action['name'] ?? '' ) ) );

			if ( $action_value === $generated_action_value ) {
				return $action;
			}
		}

		return null;
	}

	/**
	 * Process workflow fields (replace smart tags, etc.)
	 *
	 * @param array $fields Workflow field mappings.
	 * @param array $submission_data Form submission data.
	 * @param int   $form_id Form ID.
	 * @return array Processed fields.
	 * @since 1.13.0
	 */
	private function process_workflow_fields( $fields, $submission_data, $form_id ) {
		$processed = [];

		// Always provide form context so {form_title}, {entry_id}, and survey/poll
		// smart tags ({survey-form:*}, {poll_results}) can resolve. The integration
		// flag tells Survey_Smart_Tags to emit a structured object instead of HTML.
		$form_data = [
			'form-id'                    => $form_id,
			'_is_integration_processing' => true,
		];

		foreach ( $fields as $key => $value ) {
			if ( ! is_string( $value ) ) {
				$processed[ $key ] = $value;
				continue;
			}

			// Process smart tags using SureForms Smart_Tags class.
			if ( class_exists( 'SRFM\Inc\Smart_Tags' ) && method_exists( 'SRFM\Inc\Smart_Tags', 'get_instance' ) ) {
				$smart_tags        = \SRFM\Inc\Smart_Tags::get_instance();
				$processed[ $key ] = $smart_tags->process_smart_tags( $value, $submission_data, $form_data );
			} else {
				// Fallback: return the value as-is if Smart_Tags is not available.
				$processed[ $key ] = $value;
			}
		}

		return $processed;
	}

	/**
	 * Execute a workflow (API call or WordPress plugin action)
	 *
	 * @param array $integration_config Integration configuration.
	 * @param array $action_config Action configuration.
	 * @param array $credentials Integration credentials.
	 * @param array $processed_fields Processed field data.
	 * @param array $original_submission_data Original form submission data.
	 * @param array $workflow Workflow configuration data.
	 * @param int   $submission_id Entry record ID for the current submission (0 if unknown).
	 * @return array Execution result.
	 * @since 1.13.0
	 */
	private function execute_workflow( $integration_config, $action_config, $credentials, $processed_fields, $original_submission_data = [], $workflow = [], $submission_id = 0 ) {

		// Check if this is a WordPress plugin integration.
		$provider = $integration_config['provider'] ?? 'generic';

		// phpcs:ignore WordPress.WP.CapitalPDangit.Misspelled -- Configuration uses lowercase.
		if ( 'wordpress' === strtolower( $provider ) ) {
			return Integration_Utils::execute_wordpress_plugin_action( $integration_config, $action_config, $processed_fields, $original_submission_data );
		}

		// For API integrations, require endpoint configuration.
		if ( empty( $action_config['endpoint'] ) ) {
			return [
				'success' => false,
				'message' => 'No endpoint configured for action',
			];
		}

		$endpoint_config = $action_config['endpoint'];

		// Extract endpoint properties.
		$url              = $endpoint_config['url'] ?? '';
		$method           = $endpoint_config['method'] ?? 'POST';
		$payload_type     = $endpoint_config['payload_type'] ?? 'json';
		$endpoint_headers = $endpoint_config['headers'] ?? [];

		// Process URL template variables with enhanced processing.
		$all_data         = array_merge( $processed_fields, $credentials );
		$resolved_lookups = [];
		$url              = $this->process_url_with_enhanced_config(
			$url,
			$all_data,
			$endpoint_config['url_processing'] ?? [],
			$resolved_lookups
		);

		// Early exit if a required lookup failed.
		if ( ! empty( $resolved_lookups['__lookup_failed'] ) ) {
			return [
				'success' => false,
				'message' => $resolved_lookups['__lookup_error'] ?? __( 'Required field lookup failed.', 'sureforms-pro' ),
			];
		}

		// Merge resolved lookup values (e.g., contact_id) into processed fields for payload building.
		$lookup_values = array_filter( $resolved_lookups, static fn( $k ) => strpos( $k, '__' ) !== 0, ARRAY_FILTER_USE_KEY );
		if ( ! empty( $lookup_values ) ) {
			$processed_fields = array_merge( $processed_fields, $lookup_values );
		}

		// Prepare request data.
		$request_data = $this->prepare_request_data( $action_config, $processed_fields, $original_submission_data, $credentials );

		// Apply payload transformations if configured.
		if ( ! empty( $action_config['payload_transformation'] ) ) {
			$request_data = $this->apply_payload_transformations( $request_data, $action_config['payload_transformation'] );
		}

		// Apply optional specific transformer enhancement (if available).
		$integration_name = $this->get_integration_name_from_action( $action_config );
		if ( $integration_name ) {
			$transformer = Transformer_Factory::create( $integration_name );
			if ( $transformer ) {
				$context      = [
					'original_form_data' => $original_submission_data,
					'action_name'        => $action_config['name'] ?? '',
					'workflow'           => $workflow,
					'integration_config' => $integration_config,
					'action_config'      => $action_config,
					'credentials'        => $credentials,
				];
				$request_data = $transformer->transform( $request_data, [], $context );
			}
		}

		// Prepare headers (merge auth headers with endpoint-specific headers).
		$headers = Integration_Utils::build_auth_headers(
			$credentials,
			$integration_config,
			[
				'default_headers'  => [
					'User-Agent' => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'endpoint_headers' => $endpoint_headers,
			]
		);

		// Allow integrations to short-circuit the standard JSON HTTP call.
		// A handler returning an array (with at least `success` + `message`)
		// bypasses make_api_request entirely. Used by Dropbox for binary
		// file uploads which can't be expressed as a JSON request body.
		$pre_request_context = [
			'integration_name'   => $integration_name,
			'action_id'          => $action_config['id'] ?? '',
			'request_data'       => $request_data,
			'url'                => $url,
			'method'             => $method,
			'headers'            => $headers,
			'payload_type'       => $payload_type,
			'credentials'        => $credentials,
			'processed_fields'   => $processed_fields,
			'original_form_data' => $original_submission_data,
			'submission_id'      => $submission_id,
			'integration_config' => $integration_config,
			'action_config'      => $action_config,
		];
		$short_circuited     = apply_filters( 'srfm_pro_native_integration_pre_request', null, $pre_request_context );

		if ( is_array( $short_circuited ) && isset( $short_circuited['success'] ) ) {
			// A short-circuit handler must supply `success`; default the other
			// keys the downstream code reads so a partial result can't trigger
			// an undefined-index warning.
			$result = wp_parse_args(
				$short_circuited,
				[
					'message'  => '',
					'response' => '',
				]
			);
		} else {
			// Make the API request.
			$result = $this->make_api_request( $url, $method, $request_data, $headers, $payload_type );
		}

		// Execute post-actions if main action succeeded and post_actions are configured.
		if ( $result['success'] && ! empty( $action_config['post_actions'] ) ) {
			$post_action_errors = $this->execute_post_actions(
				$action_config['post_actions'],
				$result['response'] ?? '',
				$processed_fields,
				$credentials,
				$integration_config
			);

			// Append post-action errors to the result message so they appear in the entry log.
			if ( ! empty( $post_action_errors ) ) {
				$result['message'] .= ' | ' . implode( ' | ', $post_action_errors );
			}
		}

		return $result;
	}

	/**
	 * Execute post-actions after a successful main API request
	 *
	 * Post-actions are follow-up API calls defined in the action config that run
	 * after the main action succeeds. Used for operations like subscribing a contact
	 * to a list or adding tags after contact creation.
	 *
	 * @param array  $post_actions Array of post-action configurations.
	 * @param string $main_response JSON response body from the main API request.
	 * @param array  $fields Processed field data.
	 * @param array  $credentials Integration credentials.
	 * @param array  $integration_config Full integration configuration.
	 * @return array<string> Array of error messages from failed post-actions (empty if all succeeded).
	 * @since 2.7.0
	 */
	private function execute_post_actions( $post_actions, $main_response, $fields, $credentials, $integration_config ) {
		$decoded       = json_decode( $main_response, true );
		$response_data = is_array( $decoded ) ? $decoded : [];
		$all_data      = array_merge( $fields, $credentials );
		$errors        = [];

		foreach ( $post_actions as $post_action ) {
			// Check condition — skip if condition field is specified but empty.
			$condition_field = $post_action['condition_field'] ?? '';
			if ( ! empty( $condition_field ) && empty( $fields[ $condition_field ] ) ) {
				continue;
			}

			$url     = Integration_Utils::replace_placeholders( $post_action['url'] ?? '', $all_data );
			$method  = $post_action['method'] ?? 'POST';
			$headers = Integration_Utils::build_auth_headers(
				$credentials,
				$integration_config,
				[
					'endpoint_headers' => $post_action['headers'] ?? [],
				]
			);

			// Check if this is an iterate action (e.g., one call per tag).
			$iterate_config = $post_action['iterate'] ?? null;

			if ( $iterate_config ) {
				$iterate_field = $iterate_config['field'] ?? '';
				$values        = $fields[ $iterate_field ] ?? [];

				if ( is_string( $values ) ) {
					$delimiter = $iterate_config['delimiter'] ?? ',';
					$values    = array_map( 'trim', explode( $delimiter, $values ) );
				}

				if ( ! is_array( $values ) ) {
					$values = [ $values ];
				}

				// Filter out empty values.
				$values = array_filter( $values, static fn( $v ) => '' !== $v && null !== $v );

				foreach ( $values as $single_value ) {
					$iter_data             = array_merge( $all_data, [ 'iterate_value' => $single_value ] );
					$iter_data['response'] = $response_data;
					$raw_payload           = $post_action['payload'] ?? [];
					$payload               = is_array( $raw_payload ) ? $this->build_post_action_payload( $raw_payload, $iter_data, $response_data ) : [];
					$result                = $this->make_api_request( $url, $method, $payload, $headers, 'json' );

					if ( ! $result['success'] ) {
						$errors[] = sprintf(
							/* translators: 1: Post-action name, 2: Error message */
							__( 'Post-action "%1$s" failed: %2$s', 'sureforms-pro' ),
							$post_action['name'] ?? __( 'Unknown', 'sureforms-pro' ),
							$result['message'] ?? __( 'Unknown error', 'sureforms-pro' )
						);
					}
				}
			} else {
				$pa_data     = array_merge( $all_data, [ 'response' => $response_data ] );
				$raw_payload = $post_action['payload'] ?? [];
				$payload     = is_array( $raw_payload ) ? $this->build_post_action_payload( $raw_payload, $pa_data, $response_data ) : [];
				$result      = $this->make_api_request( $url, $method, $payload, $headers, 'json' );

				if ( ! $result['success'] ) {
					$errors[] = sprintf(
						/* translators: 1: Post-action name, 2: Error message */
						__( 'Post-action "%1$s" failed: %2$s', 'sureforms-pro' ),
						$post_action['name'] ?? __( 'Unknown', 'sureforms-pro' ),
						$result['message'] ?? __( 'Unknown error', 'sureforms-pro' )
					);
				}
			}
		}

		return $errors;
	}

	/**
	 * Build payload for a post-action by replacing template tokens
	 *
	 * Recursively processes a payload template array, replacing tokens like
	 * {{response.contact.id}}, {{select_list}}, and {{iterate_value}}.
	 *
	 * @param array $template Payload template with placeholder tokens.
	 * @param array $field_data Merged field + credential data (includes iterate_value).
	 * @param array $response_data Decoded JSON response from the main API call.
	 * @return array Processed payload with tokens replaced.
	 * @since 2.7.0
	 */
	private function build_post_action_payload( $template, $field_data, $response_data ) {
		$result = [];

		foreach ( $template as $key => $value ) {
			if ( is_array( $value ) ) {
				// Recursively process nested arrays.
				$result[ $key ] = $this->build_post_action_payload( $value, $field_data, $response_data );
			} elseif ( is_string( $value ) ) {
				// Replace {{response.path.to.value}} tokens with values from the API response.
				$processed = preg_replace_callback(
					'/\{\{response\.([^}]+)\}\}/',
					static function ( $matches ) use ( $response_data ) {
						$nested_value = Integration_Utils::get_nested_value( $response_data, $matches[1] );
						return null !== $nested_value ? Helper::get_string_value( $nested_value ) : $matches[0];
					},
					$value
				);

				// Replace {{field_name}} tokens with field/credential data.
				$result[ $key ] = Integration_Utils::replace_placeholders( Helper::get_string_value( $processed ), $field_data );
			} else {
				$result[ $key ] = $value;
			}
		}

		return $result;
	}

	/**
	 * Prepare request data based on action configuration
	 *
	 * @param array $action_config Action configuration.
	 * @param array $processed_fields Processed field data.
	 * @param array $original_submission_data Original form submission data.
	 * @param array $credentials User credentials.
	 * @return array Request data.
	 * @since 1.13.0
	 */
	private function prepare_request_data( $action_config, $processed_fields, $original_submission_data = [], $credentials = [] ) {
		// Set original form data context for enhanced transformations.
		$this->set_original_form_data_context( $original_submission_data );

		// Use the processed fields as the base data.
		$request_data = $processed_fields;

		// Add any additional data from action config.
		if ( isset( $action_config['additional_data'] ) && is_array( $action_config['additional_data'] ) ) {
			// Process placeholders in additional_data using credentials.
			$processed_additional_data = [];
			foreach ( $action_config['additional_data'] as $key => $value ) {
				if ( is_string( $value ) ) {
					$processed_additional_data[ $key ] = Integration_Utils::replace_placeholders( $value, $credentials );
				} else {
					$processed_additional_data[ $key ] = $value;
				}
			}
			$request_data = array_merge( $request_data, $processed_additional_data );
		}

		// Handle field exclusion.
		$fields_config = $action_config['fields'] ?? [];
		foreach ( $fields_config as $field_config ) {
			$field_key = $field_config['key'] ?? '';
			$exclude   = $field_config['exclude_from_payload'] ?? false;

			if ( $exclude && isset( $request_data[ $field_key ] ) ) {
				unset( $request_data[ $field_key ] );
			}
		}

		return $request_data;
	}

	/**
	 * Get integration name from action config for optional transformer enhancement
	 *
	 * @param array $action_config Action configuration.
	 * @return string|null Integration name or null if not found.
	 * @since 1.13.0
	 */
	private function get_integration_name_from_action( $action_config ) {
		$provider = $action_config['provider'] ?? 'generic';

		// Return specific provider name if not generic, null for generic.
		return 'generic' !== $provider ? $provider : null;
	}

	/**
	 * Make API request
	 *
	 * @param string $endpoint API endpoint URL.
	 * @param string $method HTTP method.
	 * @param array  $data Request data.
	 * @param array  $headers Request headers.
	 * @param string $payload_type Payload type (json, form).
	 * @return array Response array with success, message, and response data.
	 * @since 1.13.0
	 */
	private function make_api_request( $endpoint, $method, $data, $headers, $payload_type = 'json' ) {
		// Prepare request arguments.
		$args = [
			'method'    => strtoupper( $method ),
			'headers'   => $headers,
			'timeout'   => 30,
			'sslverify' => true,
		];

		// Add body for POST/PUT/PATCH requests.
		if ( in_array( $args['method'], [ 'POST', 'PUT', 'PATCH' ], true ) ) {
			if ( 'json' === $payload_type ) {
				$json_body    = wp_json_encode( $data );
				$args['body'] = false !== $json_body ? $json_body : '{}';
			} else {
				$args['body'] = $this->form_encode_payload( $data );
			}
		}

		// Make the request using wp_safe_remote_request to prevent SSRF.
		$response = wp_safe_remote_request( $endpoint, $args );

		// Handle WordPress HTTP errors.
		if ( is_wp_error( $response ) ) {
			return [
				'success'  => false,
				'message'  => sprintf(
					/* translators: %s: HTTP error message */
					__( 'HTTP request failed: %s', 'sureforms-pro' ),
					$response->get_error_message()
				),
				'response' => null,
			];
		}

		$status_code   = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		// Consider 2xx status codes as success.
		if ( $status_code >= 200 && $status_code < 300 ) {
			return [
				'success'  => true,
				'message'  => __( 'Request completed successfully.', 'sureforms-pro' ),
				'response' => $response_body,
			];
		}
			// Parse error message from response.
			$error_data    = json_decode( $response_body, true );
			$error_message = '';

		if ( is_array( $error_data ) ) {
			$error_message = $error_data['message'] ?? $error_data['error'] ?? $error_data['detail'] ?? '';

			// Support JSON:API error format (e.g., Klaviyo).
			if ( empty( $error_message ) && ! empty( $error_data['errors'][0]['detail'] ) ) {
				$error_message = $error_data['errors'][0]['detail'];
			}

			// Support indexed array error format (e.g., Constant Contact).
			if ( empty( $error_message ) && ! empty( $error_data[0]['error_message'] ) ) {
				$error_message = $error_data[0]['error_message'];
			}
		}

		if ( empty( $error_message ) ) {
			/* translators: %d: HTTP status code */
			$error_message = sprintf( __( 'HTTP %d error', 'sureforms-pro' ), $status_code );
		}

			return [
				'success'  => false,
				'message'  => $error_message,
				'response' => $response_body,
			];
	}

	/**
	 * Prepare all test data by converting smart tags to test values
	 *
	 * @param array $workflow_fields Fields from workflow configuration.
	 * @param array $field_definitions Field definitions from action config.
	 * @param bool  $is_wordpress_action Whether this is a WordPress plugin action.
	 * @return array Test data with smart tags replaced.
	 * @since 1.13.0
	 */
	private function prepare_all_test_data( $workflow_fields, $field_definitions, $is_wordpress_action = false ) {
		$test_data = [];

		// First, convert any smart tags in workflow fields to test data.
		foreach ( $workflow_fields as $key => $value ) {
			if ( is_string( $value ) && $this->is_smart_tag( $value ) ) {
				// Find matching field definition to get proper test data.
				$field_def = null;
				foreach ( $field_definitions as $def ) {
					if ( isset( $def['key'] ) && $def['key'] === $key ) {
						$field_def = $def;
						break;
					}
				}

				if ( $field_def ) {
					$test_data[ $key ] = self::generate_test_value( $field_def );
				} else {
					// Generate contextual test data based on field key.
					$test_data[ $key ] = $this->generate_test_value_by_key( $key );
				}
			} else {
				$test_data[ $key ] = $value;
			}
		}

		// Also generate test data for any fields that might be referenced in URLs but not in workflow.
		foreach ( $field_definitions as $field_def ) {
			$field_key   = $field_def['key'] ?? '';
			$field_type  = $field_def['type'] ?? 'text';
			$is_required = ! empty( $field_def['required'] );

			// Skip dropdown/select fields since they should only contain valid API options.
			if ( in_array( $field_type, [ 'select', 'dropdown', 'select-async', 'multi-select-async' ], true ) ) {
				continue;
			}

			// For WordPress actions, only generate test data for required fields that aren't already set.
			if ( $is_wordpress_action && ! $is_required && ! isset( $test_data[ $field_key ] ) ) {
				continue;
			}

			if ( ! empty( $field_key ) && ! isset( $test_data[ $field_key ] ) ) {
				$test_data[ $field_key ] = self::generate_test_value( $field_def );
			}
		}

		return $test_data;
	}

	/**
	 * Check if a value is a smart tag
	 *
	 * @param string $value Value to check.
	 * @return bool True if it's a smart tag.
	 * @since 1.13.0
	 */
	private function is_smart_tag( $value ) {
		return is_string( $value ) && (
			preg_match( '/^\{[^}]+\}$/', $value ) || // field_id.
			preg_match( '/^\{[^}]+_[^}]+\}$/', $value ) || // field_id_value.
			strpos( $value, '{' ) === 0 // Any other smart tag format.
		);
	}

	/**
	 * Generate test value based on field key when no field definition is available
	 *
	 * @param string $field_key Field key.
	 * @return mixed Test value.
	 * @since 1.13.0
	 */
	private function generate_test_value_by_key( $field_key ) {
		$field_key = strtolower( $field_key );
		// Special handling for common field keys.
		if ( false !== strpos( $field_key, 'email' ) || false !== strpos( $field_key, 'mail' ) ) {
			return 'test@example.com';
		}
		if ( false !== strpos( $field_key, 'name' ) ) {
			return 'Test User';
		}
		if ( false !== strpos( $field_key, 'phone' ) ) {
			return '+1234567890';
		}
		if ( false !== strpos( $field_key, 'address' ) ) {
			return '123 Test Street';
		}
		if ( false !== strpos( $field_key, 'city' ) ) {
			return 'Test City';
		}
		if ( false !== strpos( $field_key, 'zip' ) || false !== strpos( $field_key, 'postal' ) ) {
			return '12345';
		}
		if ( false !== strpos( $field_key, 'date' ) ) {
			return gmdate( 'Y-m-d' );
		}
		if ( false !== strpos( $field_key, 'ipaddress' ) ) {
			return '192.168.1.1';
		}
		if ( false !== strpos( $field_key, 'amount' ) || false !== strpos( $field_key, 'price' ) || false !== strpos( $field_key, 'cost' ) || false !== strpos( $field_key, 'total' ) || false !== strpos( $field_key, 'fee' ) ) {
			return 100;
		}

		// Default test value.
		return 'Test Value';
	}

	/**
	 * Save workflow execution results to entry logs
	 *
	 * This method saves the results of workflow executions to the entry's logs table.
	 * Each workflow execution creates a log entry with:
	 * - Title: Overall success/failure status
	 * - Messages: Individual workflow results with status icons
	 * - Timestamp: When the workflows were executed
	 *
	 * The logs can be viewed in the admin interface and provide a complete audit trail
	 * of all integration attempts for each form submission.
	 *
	 * @param int   $submission_id Submission ID.
	 * @param array $workflow_logs Workflow execution logs.
	 * @param bool  $is_retry      Whether this save is for a manual retry; when true the
	 *                             acting admin is recorded in the log message ("who did it").
	 * @return void
	 * @since 1.13.0
	 */
	private function save_workflow_results( $submission_id, $workflow_logs, $is_retry = false ) {
		if ( empty( $submission_id ) || empty( $workflow_logs ) ) {
			return;
		}

		// On manual retry, record who performed it (acceptance criterion of #2895).
		$actor_note = $is_retry ? Pro_Helper::get_retry_actor_note() : '';

		$entry_data = Entries::get( $submission_id );
		if ( empty( $entry_data ) ) {
			return;
		}

		// Write one activity-log entry PER workflow (instead of one aggregate log),
		// tagging FAILED workflows with retry metadata so the entry UI can offer a
		// per-row "Retry" for that specific workflow. Entries::update merges these
		// with the existing logs, preserving the extra `retry` key verbatim.
		$logs_to_add = [];
		foreach ( $workflow_logs as $workflow_log ) {
			if ( ! is_array( $workflow_log ) ) {
				continue;
			}

			$workflow_name = sanitize_text_field( Helper::get_string_value( $workflow_log['workflow_name'] ?? __( 'Unknown Workflow', 'sureforms-pro' ) ) );
			$message       = $workflow_log['message'] ?? __( 'No details available', 'sureforms-pro' );
			$is_success    = ! empty( $workflow_log['success'] );
			$is_skipped    = ! empty( $workflow_log['skipped'] );

			if ( $is_skipped ) {
				$status_text = __( 'Skipped', 'sureforms-pro' );
			} elseif ( $is_success ) {
				$status_text = __( 'Success', 'sureforms-pro' );
			} else {
				$status_text = __( 'Failed', 'sureforms-pro' );
			}

			$log = [
				'title'     => sprintf(
					/* translators: %s: integration/workflow name */
					__( 'Native Integration: %s', 'sureforms-pro' ),
					$workflow_name
				),
				'messages'  => [
					sprintf( '%1$s - %2$s', $status_text, $message ) . $actor_note,
				],
				'timestamp' => current_time( 'mysql' ), // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp -- Match the WordPress timezone, consistent with Entries::add_log().
			];

			$workflow_id = isset( $workflow_log['id'] ) ? Helper::get_string_value( $workflow_log['id'] ) : '';
			if ( ! $is_success && ! $is_skipped && '' !== $workflow_id ) {
				$log['retry'] = [
					'type' => 'native',
					'id'   => $workflow_id,
				];
			}

			$logs_to_add[] = $log;
		}

		// Build the per-workflow status map (keyed by workflow id) for the entry's
		// extras so the entry UI can render each integration's status and a Retry
		// button for the failed ones. Merge so retrying one workflow doesn't wipe
		// the statuses of the others.
		$extras = Helper::get_array_value( $entry_data['extras'] ?? [] );
		if ( ! isset( $extras['native_integrations'] ) || ! is_array( $extras['native_integrations'] ) ) {
			$extras['native_integrations'] = [];
		}
		$existing = isset( $extras['native_integrations']['triggers'] ) && is_array( $extras['native_integrations']['triggers'] )
			? $extras['native_integrations']['triggers']
			: [];

		$extras['native_integrations']['triggers'] = array_merge( $existing, $this->build_workflow_trigger_statuses( $workflow_logs ) );
		$extras['native_integrations']['status']   = ! in_array(
			'failed',
			array_column( $extras['native_integrations']['triggers'], 'status' ),
			true
		);

		// Single DB write: Entries::update() merges 'logs' with the existing logs and
		// replaces 'extras'.
		$update_data = [ 'extras' => $extras ];
		if ( ! empty( $logs_to_add ) ) {
			$update_data['logs'] = $logs_to_add;
		}
		Entries::update( $submission_id, $update_data );
	}

	/**
	 * Build a per-workflow status map (keyed by workflow id) from workflow results.
	 *
	 * @param array<mixed> $workflow_logs Results from process_single_workflow().
	 * @since 2.12.1
	 * @return array<int|string,array<string,mixed>> Keyed by workflow id (numeric ids become int array keys).
	 */
	private function build_workflow_trigger_statuses( $workflow_logs ) {
		$triggers = [];
		foreach ( $workflow_logs as $log ) {
			if ( ! is_array( $log ) ) {
				continue;
			}
			$status = $this->format_workflow_status( $log );
			if ( '' === $status['id'] ) {
				continue;
			}
			$triggers[ $status['id'] ] = $status;
		}
		return $triggers;
	}

	/**
	 * Normalize a single workflow result into a status row for the entry UI.
	 *
	 * @param array<mixed> $result Result from process_single_workflow().
	 * @since 2.12.1
	 * @return array<string,mixed>
	 */
	private function format_workflow_status( $result ) {
		$state = 'failed';
		if ( ! empty( $result['skipped'] ) ) {
			$state = 'skipped';
		} elseif ( ! empty( $result['success'] ) ) {
			$state = 'success';
		}

		return [
			'id'              => isset( $result['id'] ) ? Helper::get_string_value( $result['id'] ) : '',
			'name'            => sanitize_text_field( Helper::get_string_value( $result['workflow_name'] ?? __( 'Unnamed', 'sureforms-pro' ) ) ),
			'integration'     => $result['integration'] ?? '',
			'status'          => $state,
			'message'         => $result['message'] ?? '',
			'last_attempt_at' => current_time( 'mysql' ),
		];
	}

	/**
	 * Enhanced URL processing with configuration support
	 *
	 * @param string $url URL template.
	 * @param array  $data Data for replacements.
	 * @param array  $url_processing URL processing configuration.
	 * @param array  $resolved_lookups Optional. Array to capture resolved lookup values (payload_key mappings).
	 * @return string Processed URL.
	 * @since 1.13.0
	 */
	private function process_url_with_enhanced_config( $url, $data, $url_processing, &$resolved_lookups = [] ) {
		// Start with enhanced template variable processing.
		$processed_url = Integration_Utils::replace_placeholders( $url, $data );

		// Apply datacenter extraction if configured.
		if ( ! empty( $url_processing['datacenter_extraction']['enabled'] ) ) {
			$processed_url = $this->apply_datacenter_extraction( $processed_url, $data, $url_processing['datacenter_extraction'] );
		}

		// Apply hash generation if configured.
		if ( ! empty( $url_processing['hash_generation']['enabled'] ) ) {
			$processed_url = $this->apply_hash_generation( $processed_url, $data, $url_processing['hash_generation'] );
		}

		// Apply field lookup if configured.
		if ( ! empty( $url_processing['field_lookup']['enabled'] ) ) {
			$processed_url = Compatibility_Utils::apply_field_lookup( $processed_url, $data, $url_processing['field_lookup'], $resolved_lookups );
		}

		return $processed_url;
	}

	/**
	 * Apply datacenter extraction from API key
	 *
	 * @param string $url URL template.
	 * @param array  $data Data containing source field.
	 * @param array  $config Datacenter extraction configuration.
	 * @return string URL with datacenter replaced.
	 * @since 1.13.0
	 */
	private function apply_datacenter_extraction( $url, $data, $config ) {
		$source_field      = $config['source_field'] ?? '';
		$pattern           = $config['pattern'] ?? '';
		$replacement_token = $config['replacement_token'] ?? '';

		if ( empty( $source_field ) || empty( $pattern ) || empty( $replacement_token ) ) {
			return $url;
		}

		$source_value = Helper::get_string_value( $data[ $source_field ] ?? '' );
		if ( '' === $source_value ) {
			return $url;
		}

		// Extract datacenter using regex pattern.
		$matches = [];
		if ( 1 === preg_match( '/' . $pattern . '/', $source_value, $matches ) ) {
			$datacenter = $matches[1] ?? '';
			if ( ! empty( $datacenter ) ) {
				$url = str_replace( $replacement_token, $datacenter, $url );
			}
		}

		return $url;
	}

	/**
	 * Apply hash generation for URLs
	 *
	 * @param string $url URL template.
	 * @param array  $data Data containing source field.
	 * @param array  $config Hash generation configuration.
	 * @return string URL with hash replaced.
	 * @since 1.13.0
	 */
	private function apply_hash_generation( $url, $data, $config ) {
		$source_field      = $config['source_field'] ?? '';
		$hash_type         = $config['hash_type'] ?? 'md5';
		$replacement_token = $config['replacement_token'] ?? '';

		if ( empty( $source_field ) || empty( $replacement_token ) ) {
			return $url;
		}

		$source_value = $data[ $source_field ] ?? '';
		if ( empty( $source_value ) ) {
			return $url;
		}

		// Generate hash.
		$hash = '';
		switch ( $hash_type ) {
			case 'md5':
				$hash = md5( strtolower( trim( $source_value ) ) );
				break;
			case 'sha1':
				$hash = sha1( strtolower( trim( $source_value ) ) );
				break;
			case 'sha256':
				$hash = hash( 'sha256', strtolower( trim( $source_value ) ) );
				break;
		}

		if ( ! empty( $hash ) ) {
			$url = str_replace( $replacement_token, $hash, $url );
		}

		return $url;
	}

	/**
	 * Apply payload transformations based on JSON configuration
	 *
	 * @param array $payload Original payload data.
	 * @param array $transformation_config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function apply_payload_transformations( $payload, $transformation_config ) {
		if ( empty( $transformation_config['enabled'] ) || empty( $transformation_config['transformations'] ) ) {
			return $payload;
		}

		foreach ( $transformation_config['transformations'] as $transformation ) {
			$type = $transformation['type'] ?? '';

			switch ( $type ) {
				case 'array_conversion':
					$payload = $this->transform_array_conversion( $payload, $transformation );
					break;

				case 'nested_object':
					$payload = $this->transform_nested_object( $payload, $transformation );
					break;

				case 'tag_array_conversion':
					$payload = $this->transform_tag_array_conversion( $payload, $transformation );
					break;

				case 'conditional_field':
					$payload = $this->transform_conditional_field( $payload, $transformation );
					break;

				case 'field_format':
					$payload = $this->transform_field_format( $payload, $transformation );
					break;

				case 'structure_conversion':
					$payload = $this->transform_structure_conversion( $payload, $transformation );
					break;
				case 'extract_url':
					$payload = $this->transform_extract_url( $payload, $transformation );
					break;
				case 'dynamic_field_conversion':
					$payload = Compatibility_Utils::transform_dynamic_field_conversion( $payload, $transformation );
					break;

				case 'wrap_in_array':
					$payload = $this->transform_wrap_in_array( $payload, $transformation );
					break;
			}
		}

		return $payload;
	}

	/**
	 * Transform comma-separated values to arrays
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_array_conversion( $payload, $config ) {
		$field     = $config['field'] ?? '';
		$target    = $config['target'] ?? $field; // Use target if specified, otherwise use source field.
		$delimiter = $config['delimiter'] ?? ',';

		if ( empty( $field ) || ! isset( $payload[ $field ] ) ) {
			return $payload;
		}

		$value           = $payload[ $field ];
		$converted_array = [];

		if ( is_string( $value ) && ! empty( $value ) ) {
			// Handle string values that need to be split by delimiter.
			$converted_array = array_map( 'trim', explode( $delimiter, $value ) );
		} elseif ( ! is_array( $value ) && ! empty( $value ) ) {
			// Handle single values (integer/string) that need to be wrapped in an array.
			$converted_array = [ is_numeric( $value ) ? (int) $value : $value ];
		}

		if ( ! empty( $converted_array ) ) {
			// If target is different from source field, create new field and remove old one.
			if ( $target !== $field ) {
				$payload[ $target ] = $converted_array;
				unset( $payload[ $field ] );
			} else {
				$payload[ $field ] = $converted_array;
			}
		}

		return $payload;
	}

	/**
	 * Transform fields into nested objects
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_nested_object( $payload, $config ) {
		$target         = $config['target'] ?? '';
		$source_pattern = $config['source_pattern'] ?? '';
		$exclude_fields = $config['exclude_fields'] ?? [];
		$exclude_empty  = $config['exclude_empty'] ?? false; // Default to false for backward compatibility.
		$field_mapping  = $config['field_mapping'] ?? [];

		if ( empty( $target ) || empty( $source_pattern ) ) {
			return $payload;
		}

		$nested_data = [];

		// Handle field_mapping if provided - this creates a specific nested structure.
		if ( ! empty( $field_mapping ) ) {
			foreach ( $field_mapping as $nested_key => $template ) {
				// Replace template variables with actual payload values.
				$processed_value            = Integration_Utils::replace_placeholders( $template, $payload );
				$nested_data[ $nested_key ] = $processed_value;
			}

			// Remove the source fields that were used in the mapping.
			foreach ( $payload as $key => $value ) {
				if ( fnmatch( $source_pattern, $key ) ) {
					unset( $payload[ $key ] );
				}
			}
		} else {
			// Original behavior - find fields matching the pattern and move them.
			foreach ( $payload as $key => $value ) {
				// Skip excluded fields.
				if ( in_array( $key, $exclude_fields, true ) ) {
					continue;
				}

				// Skip empty fields if exclude_empty is enabled.
				if ( $exclude_empty && Integration_Utils::is_empty_field_value( $value ) ) {
					unset( $payload[ $key ] );
					continue;
				}

				if ( fnmatch( $source_pattern, $key ) ) {
					if ( '*' === $source_pattern ) {
						// Move all non-excluded fields as-is.
						$nested_data[ $key ] = $value;
					} else {
						// Remove pattern prefix for specific patterns like MERGE*.
						$nested_key                 = str_replace( rtrim( $source_pattern, '*' ), '', $key );
						$nested_data[ $nested_key ] = $value;
					}
					unset( $payload[ $key ] );
				}
			}
		}

		if ( ! empty( $nested_data ) ) {
			$payload[ $target ] = $nested_data;
		}

		return $payload;
	}

	/**
	 * Transform tags to integration-specific tag array format
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_tag_array_conversion( $payload, $config ) {
		$source_field     = $config['source_field'] ?? '';
		$target_structure = $config['target_structure'] ?? '';
		$tag_format       = $config['tag_format'] ?? [];

		if ( empty( $source_field ) || empty( $target_structure ) || ! isset( $payload[ $source_field ] ) ) {
			return $payload;
		}

		$tags_value = $payload[ $source_field ];
		$tags_array = [];

		if ( is_string( $tags_value ) && ! empty( $tags_value ) ) {
			$tag_names = array_map( 'trim', explode( ',', $tags_value ) );

			foreach ( $tag_names as $tag_name ) {
				if ( ! empty( $tag_name ) ) {
					$tag_object = [];
					foreach ( $tag_format as $key => $value ) {
						$tag_object[ $key ] = str_replace( '{{tag_name}}', $tag_name, $value );
					}
					$tags_array[] = $tag_object;
				}
			}
		}

		if ( ! empty( $tags_array ) ) {
			$payload[ $target_structure ] = $tags_array;
		}

		// Remove the original field.
		unset( $payload[ $source_field ] );

		return $payload;
	}

	/**
	 * Add conditional fields based on other field values
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_conditional_field( $payload, $config ) {
		$field     = $config['field'] ?? '';
		$condition = $config['condition'] ?? '';

		if ( empty( $field ) || empty( $condition ) ) {
			return $payload;
		}

		// Only add the field if the condition field has a value.
		if ( isset( $payload[ $condition ] ) && ! empty( $payload[ $condition ] ) ) {
			// For now, just add an empty object. This can be enhanced based on specific needs.
			$payload[ $field ] = [];
		}

		return $payload;
	}

	/**
	 * Wrap a field's value or the entire payload in an array
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_wrap_in_array( $payload, $config ) {
		$target_field = $config['target_field'] ?? '';
		$source_field = $config['source_field'] ?? '';

		// If target_field is specified, wrap that specific field's value in an array.
		if ( ! empty( $target_field ) ) {
			if ( isset( $payload[ $target_field ] ) && ! is_array( $payload[ $target_field ] ) ) {
				$payload[ $target_field ] = [ $payload[ $target_field ] ];
			} elseif ( isset( $payload[ $target_field ] ) && is_array( $payload[ $target_field ] ) ) {
				// Check if it's already an indexed array, if not wrap it.
				if ( ! isset( $payload[ $target_field ][0] ) ) {
					$payload[ $target_field ] = [ $payload[ $target_field ] ];
				}
			}
		} elseif ( ! empty( $source_field ) && ! empty( $config['target_field_name'] ) ) {
			// If source_field is specified, take that field's value and wrap it in target_field array.
			$target_field_name = $config['target_field_name'];
			if ( isset( $payload[ $source_field ] ) ) {
				$value = $payload[ $source_field ];
				// If value is an array and it's associative (not indexed), wrap it in an array.
				if ( is_array( $value ) ) {
					$payload[ $target_field_name ] = isset( $value[0] ) ? $value : [ $value ];
				} else {
					$payload[ $target_field_name ] = [ $value ];
				}
				unset( $payload[ $source_field ] );
			}
		} else {
			// Otherwise, wrap the entire payload in an array (for cases where the API expects an array of objects).
			$payload = [ $payload ];
		}

		return $payload;
	}

	/**
	 * Generic field format transformation based on JSON rules
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_field_format( $payload, $config ) {
		$field_rules = $config['field_rules'] ?? [];

		foreach ( $field_rules as $rule ) {
			$fields      = $rule['fields'] ?? [];
			$format_type = $rule['format_type'] ?? '';

			foreach ( $fields as $field_pattern ) {
				$matching_fields = $this->find_fields_by_pattern( $payload, $field_pattern );

				foreach ( $matching_fields as $field_path ) {
					$value = Integration_Utils::get_nested_value( $payload, $field_path );

					if ( empty( $value ) ) {
						continue;
					}

					if ( 'date' === $format_type ) {
						$processed_value = $this->apply_date_format_rule( $value, $rule );
					} elseif ( 'string' === $format_type ) {
						$processed_value = $this->apply_string_format_rule( $value, $rule );
					} elseif ( 'numeric_cast' === $format_type ) {
						$numeric_value = $value;
						if ( is_string( $value ) ) {
							$has_comma  = false !== strpos( $value, ',' );
							$has_period = false !== strpos( $value, '.' );
							if ( $has_comma && $has_period ) {
								// Both separators: the one that appears last is the decimal point.
								// 1,123.9 → strip commas; 1.123,9 → strip periods + comma→period.
								if ( strrpos( $value, ',' ) > strrpos( $value, '.' ) ) {
									$numeric_value = str_replace( '.', '', $value );
									$numeric_value = str_replace( ',', '.', $numeric_value );
								} else {
									$numeric_value = str_replace( ',', '', $value );
								}
							} elseif ( $has_comma ) {
								// Comma only: thousands separator if it matches \d{1,3},\d{3} pattern
								// (e.g. 1,000 or 1,123), otherwise treat as decimal (e.g. 1,5).
								if ( preg_match( '/^\d{1,3}(,\d{3})+$/', $value ) ) {
									$numeric_value = str_replace( ',', '', $value );
								} else {
									$numeric_value = str_replace( ',', '.', $value );
								}
							}
						}
						if ( is_numeric( $numeric_value ) ) {
							$processed_value = $numeric_value + 0;
						} else {
							$processed_value = $value;
						}
					} else {
						$processed_value = $value;
					}

					$payload = Integration_Utils::set_nested_value( $payload, $field_path, $processed_value );
				}
			}
		}

		return $payload;
	}

	/**
	 * Generic structure conversion transformation based on JSON rules
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_structure_conversion( $payload, $config ) {
		$conversions = $config['conversions'] ?? [];

		foreach ( $conversions as $conversion ) {
			$field_patterns          = $conversion['fields'] ?? [];
			$target_structure        = $conversion['target_structure'] ?? [];
			$auto_detect             = $conversion['auto_detect'] ?? [];
			$use_original_form_data  = $conversion['use_original_form_data'] ?? false;
			$fallback_to_field_value = $conversion['fallback_to_field_value'] ?? false;

			foreach ( $field_patterns as $field_pattern ) {
				$matching_fields = $this->find_fields_by_pattern( $payload, $field_pattern );

				foreach ( $matching_fields as $field_path ) {
					$value = Integration_Utils::get_nested_value( $payload, $field_path );

					if ( Integration_Utils::is_empty_field_value( $value ) ) {
						continue;
					}

					$converted_value = $this->apply_enhanced_structure_conversion_rule(
						$value,
						$target_structure,
						$auto_detect,
						$payload,
						$use_original_form_data,
						$fallback_to_field_value
					);
					$payload         = Integration_Utils::set_nested_value( $payload, $field_path, $converted_value );
				}
			}
		}

		return $payload;
	}

	/**
	 * Extract URL from processed smart tag containing anchor tag
	 *
	 * @param array $payload Payload data.
	 * @param array $config Transformation configuration.
	 * @return array Transformed payload.
	 * @since 1.13.0
	 */
	private function transform_extract_url( $payload, $config ) {
		$field  = $config['field'] ?? '';
		$target = $config['target'] ?? $field; // Use target if specified, otherwise use source field.

		if ( empty( $field ) || ! isset( $payload[ $field ] ) ) {
			return $payload;
		}

		$value = $payload[ $field ];

		// Check if value is a string and contains an anchor tag.
		if ( is_string( $value ) && ! empty( $value ) ) {
			// Extract URL from anchor tag using regex.
			if ( preg_match( '/<a[^>]+href=[\'"](.*?)[\'"][^>]*>/', $value, $matches ) ) {
				$extracted_url = $matches[1];

				// If target is different from source field, create new field and optionally remove old one.
				if ( $target !== $field ) {
					$payload[ $target ] = $extracted_url;
					// Don't remove the original field in case it's needed elsewhere.
				} else {
					$payload[ $field ] = $extracted_url;
				}
			}
			// If no anchor tag found, keep the original value.
		}

		return $payload;
	}

	/**
	 * Find fields in payload matching a pattern (supports nested objects)
	 *
	 * @param array  $payload Payload data.
	 * @param string $pattern Field pattern (supports wildcards).
	 * @return array Array of matching field paths (e.g., ['field1', 'nested.field2']).
	 * @since 1.13.0
	 */
	private function find_fields_by_pattern( $payload, $pattern ) {
		return $this->find_fields_recursive( $payload, $pattern, '' );
	}

	/**
	 * Recursively find fields matching a pattern in nested structures
	 *
	 * @param array  $data Data to search.
	 * @param string $pattern Field pattern (supports wildcards).
	 * @param string $prefix Current nesting prefix.
	 * @return array Array of matching field paths.
	 * @since 1.13.0
	 */
	private function find_fields_recursive( $data, $pattern, $prefix = '' ) {
		$matching_fields = [];

		if ( ! is_array( $data ) ) {
			return $matching_fields;
		}

		// Convert pattern to regex if it contains wildcards.
		$use_regex     = false !== strpos( $pattern, '*' );
		$regex_pattern = '';
		if ( $use_regex ) {
			$regex_pattern = '/^' . str_replace( '*', '.*', preg_quote( $pattern, '/' ) ) . '$/i';
		}

		foreach ( $data as $key => $value ) {
			$field_path = empty( $prefix ) ? $key : $prefix . '.' . $key;

			// Check if current field matches the pattern.
			$matches = false;
			if ( $use_regex ) {
				$matches = preg_match( $regex_pattern, $key );
			} else {
				$matches = $key === $pattern;
			}

			if ( $matches ) {
				$matching_fields[] = $field_path;
			}

			// Recursively search nested arrays/objects.
			if ( is_array( $value ) ) {
				$nested_matches  = $this->find_fields_recursive( $value, $pattern, $field_path );
				$matching_fields = array_merge( $matching_fields, $nested_matches );
			}
		}

		return $matching_fields;
	}

	/**
	 * Apply date formatting rule from JSON configuration
	 *
	 * @param mixed $value Input value.
	 * @param array $rule Formatting rule.
	 * @return string Formatted value.
	 * @since 1.13.0
	 */
	private function apply_date_format_rule( $value, $rule ) {
		if ( empty( $value ) ) {
			return '';
		}

		$value_str        = Helper::get_string_value( $value );
		$input_formats    = $rule['input_formats'] ?? [];
		$output_format    = $rule['output_format'] ?? 'Y-m-d';
		$validation_regex = $rule['validation_regex'] ?? '';

		// Check if already in correct format.
		if ( ! empty( $validation_regex ) && preg_match( '/' . $validation_regex . '/', $value_str ) ) {
			return $value_str;
		}

		// Try to parse using defined input formats.
		foreach ( $input_formats as $format ) {
			$date = \DateTime::createFromFormat( $format, $value_str );
			if ( false !== $date ) {
				return $date->format( $output_format );
			}
		}

		// Try fallback regex if provided.
		$fallback_regex = $rule['fallback_regex'] ?? '';
		if ( ! empty( $fallback_regex ) && preg_match( '/' . $fallback_regex . '/', $value_str, $matches ) ) {
			$processed_value = $rule['fallback_replacement'] ?? '';
			foreach ( $matches as $i => $match ) {
				$processed_value = str_replace( "{{$i}}", $match, $processed_value );
			}
			return $processed_value;
		}

		// Return original value if no transformation possible.
		return $value_str;
	}

	/**
	 * Apply string formatting rule from JSON configuration
	 *
	 * @param mixed $value Input value.
	 * @param array $rule Formatting rule.
	 * @return string Formatted value.
	 * @since 1.13.0
	 */
	private function apply_string_format_rule( $value, $rule ) {
		$value_str       = Helper::get_string_value( $value );
		$transformations = $rule['transformations'] ?? [];

		foreach ( $transformations as $transformation ) {
			$type = $transformation['type'] ?? '';

			switch ( $type ) {
				case 'uppercase':
					$value_str = strtoupper( Helper::get_string_value( $value_str ) );
					break;
				case 'lowercase':
					$value_str = strtolower( Helper::get_string_value( $value_str ) );
					break;
				case 'trim':
					$value_str = trim( Helper::get_string_value( $value_str ) );
					break;
				case 'regex_replace':
					$pattern     = $transformation['pattern'] ?? '';
					$replacement = $transformation['replacement'] ?? '';
					if ( ! empty( $pattern ) ) {
						$value_str = preg_replace( '/' . $pattern . '/', $replacement, Helper::get_string_value( $value_str ) );
					}
					break;
			}
		}

		return Helper::get_string_value( $value_str );
	}

	/**
	 * Apply enhanced structure conversion rule from JSON configuration
	 *
	 * @param mixed $value Input value.
	 * @param array $target_structure Target structure template.
	 * @param array $auto_detect Auto-detection rules.
	 * @param array $payload Full payload for context.
	 * @param bool  $use_original_form_data Whether to use original form data for detection.
	 * @param bool  $fallback_to_field_value Whether to fallback to field value if detection fails.
	 * @return array Converted structure.
	 * @since 1.13.0
	 */
	private function apply_enhanced_structure_conversion_rule( $value, $target_structure, $auto_detect, $payload, $use_original_form_data = false, $fallback_to_field_value = false ) {
		// If already an array, return as-is.
		if ( is_array( $value ) ) {
			return $value;
		}

		$result    = [];
		$value_str = Helper::get_string_value( $value );

		// Get original form data if available and requested.
		$original_form_data = [];
		if ( $use_original_form_data ) {
			$original_form_data = $this->get_original_form_data_context();
		}

		// Process target structure template.
		foreach ( $target_structure as $key => $template ) {
			if ( '{{field_value}}' === $template ) {
				$result[ $key ] = $value_str;
			} elseif ( 0 === strpos( $template, '{{auto_detect_original:' ) ) {
				// Extract detection key for original form data.
				preg_match( '/\{\{auto_detect_original:([^}]+)\}\}/', $template, $matches );
				$detect_key = $matches[1] ?? '';

				if ( isset( $auto_detect[ $detect_key ] ) ) {
					$detected_value = $this->auto_detect_field_value( $original_form_data, $auto_detect[ $detect_key ] );

					// Fallback to field value if detection fails and fallback is enabled.
					if ( empty( $detected_value ) && $fallback_to_field_value ) {
						$detected_value = $value_str;
					}

					$result[ $key ] = $detected_value;
				} else {
					$result[ $key ] = $fallback_to_field_value ? $value_str : '';
				}
			} elseif ( 0 === strpos( $template, '{{auto_detect:' ) ) {
				// Extract detection key for payload data (original behavior).
				preg_match( '/\{\{auto_detect:([^}]+)\}\}/', $template, $matches );
				$detect_key = $matches[1] ?? '';

				if ( isset( $auto_detect[ $detect_key ] ) ) {
					$result[ $key ] = $this->auto_detect_field_value( $payload, $auto_detect[ $detect_key ] );
				} else {
					$result[ $key ] = '';
				}
			} else {
				$result[ $key ] = $template;
			}
		}

		return $result;
	}

	/**
	 * Auto-detect field value from payload using detection keywords
	 *
	 * @param array $payload Full payload.
	 * @param array $keywords Detection keywords.
	 * @return string Detected value or empty string.
	 * @since 1.13.0
	 */
	private function auto_detect_field_value( $payload, $keywords ) {
		foreach ( $payload as $field => $value ) {
			$field_lower = strtolower( $field );

			foreach ( $keywords as $keyword ) {
				if ( false !== strpos( $field_lower, strtolower( $keyword ) ) ) {
					return Helper::get_string_value( $value );
				}
			}
		}

		return '';
	}

	/**
	 * Get original form data context for enhanced transformations
	 *
	 * @return array Original form data.
	 * @since 1.13.0
	 */
	private function get_original_form_data_context() {
		return $this->original_form_data_context;
	}

	/**
	 * Set original form data context for enhanced transformations
	 *
	 * @param array $original_form_data Original form data.
	 * @return void
	 * @since 1.13.0
	 */
	private function set_original_form_data_context( $original_form_data ) {
		$this->original_form_data_context = $original_form_data;
	}

	/**
	 * Increment workflow run count
	 *
	 * @param int    $form_id Form ID.
	 * @param string $workflow_id Workflow ID.
	 * @return void
	 * @since 1.13.0
	 */
	private function increment_workflow_run_count( $form_id, $workflow_id ) {
		if ( empty( $form_id ) || empty( $workflow_id ) ) {
			return;
		}

		// Get current workflows from meta.
		$workflows_json = get_post_meta( $form_id, '_srfm_native_integrations', true );
		$workflows      = [];

		if ( ! empty( $workflows_json ) && is_string( $workflows_json ) ) {
			$decoded   = json_decode( $workflows_json, true );
			$workflows = is_array( $decoded ) ? $decoded : [];
		}

		// Find and update the specific workflow.
		$updated = false;
		foreach ( $workflows as &$workflow ) {
			if ( isset( $workflow['id'] ) && $workflow['id'] === $workflow_id ) {
				$workflow['run_count'] = ( $workflow['run_count'] ?? 0 ) + 1;
				$workflow['last_run']  = time() * 1000; // Store in milliseconds like other timestamps.
				$updated               = true;
				break;
			}
		}

		// Save updated workflows back to meta.
		if ( $updated ) {
			update_post_meta( $form_id, '_srfm_native_integrations', wp_json_encode( $workflows ) );
		}
	}

}
