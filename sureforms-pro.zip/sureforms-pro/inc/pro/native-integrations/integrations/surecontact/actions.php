<?php
/**
 * SureContact Integration Handler
 *
 * Handles all SureContact integration functionality including filters and actions.
 *
 * @package SureForms
 * @since 2.5.1
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Integrations\Surecontact;

use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * SureContact Integration Handler Class
 *
 * @since 2.5.1
 */
class Surecontact_Integration {
	use Get_Instance;

	/**
	 * Constructor
	 *
	 * @since 2.5.1
	 */
	public function __construct() {
		$this->register_filters();
	}

	/**
	 * Register filters for SureContact integration.
	 *
	 * @since 2.5.1
	 * @return void
	 */
	public function register_filters() {
		add_filter( 'srfm_integrated_plugins', [ $this, 'add_surecontact_settings_url' ] );
	}

	/**
	 * Add settings URL for SureContact integration.
	 *
	 * @param array<string, array<string, mixed>> $integrations The integrations array.
	 * @since 2.5.1
	 * @return array<string, array<string, mixed>>
	 */
	public function add_surecontact_settings_url( $integrations ) {
		if ( isset( $integrations['sure_contact'] ) ) {
			$integrations['sure_contact']['settings_url'] = empty( get_option( 'surecontact_workspace_uuid', '' ) )
				? admin_url( 'admin.php?page=surecontact-dashboard' )
				: admin_url( 'admin.php?page=surecontact-dashboard#/integrations' );
		}
		return $integrations;
	}

	/**
	 * Check if SureContact plugin is active.
	 *
	 * @since 2.5.1
	 * @return bool
	 */
	public function is_plugin_active() {
		return class_exists( 'SureContact' ) || defined( 'SURECONTACT_VERSION' );
	}
}

/**
 * Register filters for this integration.
 *
 * @since 2.5.1
 * @return void
 */
function register_filters() {
	Surecontact_Integration::get_instance();
}
