<?php
/**
 * MailPoet Add Subscriber Action
 *
 * Handles adding/updating subscribers in MailPoet through SureForms.
 *
 * @package SureForms
 * @since 2.1.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\Integrations\MailPoet\Actions;

use SRFM_Pro\Inc\Pro\Native_Integrations\Integrations\MailPoet\MailPoet_Integration;
use SRFM_Pro\Inc\Pro\Native_Integrations\WordPress_Action;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Add Subscriber Action Class
 *
 * @since 2.1.0
 */
class Add_Subscriber extends WordPress_Action {
	use Get_Instance;

	/**
	 * Integration name
	 *
	 * @var string
	 * @since 2.1.0
	 */
	protected $integration = 'mailpoet';

	/**
	 * Action name
	 *
	 * @var string
	 * @since 2.1.0
	 */
	protected $action = 'add_subscriber';

	/**
	 * Execute the add subscriber action
	 *
	 * @param array $data Form submission data.
	 * @return array Action result.
	 * @throws \Exception If subscriber creation fails.
	 * @since 2.1.0
	 */
	protected function execute( $data ) {
		// Ensure MailPoet APIException class exists.
		if ( ! class_exists( '\MailPoet\API\MP\v1\APIException' ) ) {
			return [
				'success' => false,
				'message' => __( 'MailPoet API is unavailable. Please ensure MailPoet is installed and activated.', 'sureforms-pro' ),
			];
		}

		try {
			// Validate required API.
			if ( ! class_exists( '\MailPoet\API\API' ) ) {
				throw new \Exception( 'MailPoet plugin is not installed or activated.' );
			}

			// Validate email.
			if ( empty( $data['email'] ) || ! is_email( $data['email'] ) ) {
				throw new \Exception( 'Invalid email address.' );
			}

			// Get MailPoet API.
			$mailpoet_api = \MailPoet\API\API::MP( 'v1' );

			// Prepare subscriber data.
			$subscriber_data = [
				'email' => sanitize_email( $data['email'] ),
			];

			if ( ! empty( $data['first_name'] ) ) {
				$subscriber_data['first_name'] = sanitize_text_field( $data['first_name'] );
			}

			if ( ! empty( $data['last_name'] ) ) {
				$subscriber_data['last_name'] = sanitize_text_field( $data['last_name'] );
			}

			// Process list IDs.
			$list_ids   = [];
			$list_names = [];
			if ( ! empty( $data['list_ids'] ) ) {
				$list_ids = MailPoet_Integration::process_lists( $data['list_ids'], $list_names );
			}

			if ( empty( $list_ids ) ) {
				throw new \Exception( 'Please select at least one list.' );
			}

			// Confirmation email option.
			$send_confirmation = isset( $data['send_confirmation_email'] ) && '1' === $data['send_confirmation_email'];

			$options = [
				'send_confirmation_email' => $send_confirmation,
			];

			// Check if subscriber already exists.
			$existing_subscriber = null;
			try {
				$existing_subscriber = $mailpoet_api->getSubscriber( $subscriber_data['email'] );
			} catch ( \MailPoet\API\MP\v1\APIException $e ) {
				// phpcs:ignore -- this is added to prevent an empty catch block warning.
				$e = $e;
				// Subscriber doesn't exist - continue to create.
			}

			if ( ! empty( $existing_subscriber['id'] ) ) {
				/*
				 * An existing subscriber is still added to the selected lists, because
				 * the address existing somewhere in MailPoet says nothing about whether
				 * it is on the list this action targets.
				 *
				 * This previously returned early without subscribing, which broke any
				 * form that both registers a user and subscribes them: user registration
				 * runs on `srfm_before_submission` while integrations run later on
				 * `srfm_after_submission_process`, so by the time this action executes
				 * MailPoet has already created a subscriber for the new WordPress user
				 * through its WordPress Users sync. The address therefore "already
				 * exists" and the selected list was silently skipped, while a
				 * subscribe-only form on the same site worked.
				 *
				 * Mirrors the FluentCRM action, which creates or updates rather than
				 * bailing out.
				 */
				$mailpoet_api->subscribeToLists(
					$existing_subscriber['id'],
					$list_ids,
					$options
				);

				$subscriber = $mailpoet_api->getSubscriber( $subscriber_data['email'] );

				return [
					'success' => true,
					'message' => __( 'Subscriber added to the selected list(s) successfully!', 'sureforms-pro' ),
					'data'    => [
						'subscriber_id' => $subscriber['id'] ?? $existing_subscriber['id'],
						'email'         => $subscriber['email'] ?? $subscriber_data['email'],
						'first_name'    => $subscriber['first_name'] ?? '',
						'last_name'     => $subscriber['last_name'] ?? '',
						'status'        => $subscriber['status'] ?? '',
						'list_names'    => implode( ', ', $list_names ),
					],
				];
			}

			// Create new subscriber.
			$new_subscriber = $mailpoet_api->addSubscriber( $subscriber_data, $list_ids, $options );

			$return_data = [
				'subscriber_id' => $new_subscriber['id'],
				'email'         => $new_subscriber['email'],
				'first_name'    => $new_subscriber['first_name'] ?? '',
				'last_name'     => $new_subscriber['last_name'] ?? '',
				'status'        => $new_subscriber['status'] ?? '',
				'list_names'    => implode( ', ', $list_names ),
			];

			return [
				'success' => true,
				'message' => __( 'Subscriber added successfully!', 'sureforms-pro' ),
				'data'    => $return_data,
			];
		} catch ( \MailPoet\API\MP\v1\APIException $e ) {
			return [
				'success' => false,
				'message' => sprintf(
					// translators: %s: Error message.
					__( 'MailPoet API error: %s', 'sureforms-pro' ),
					$e->getMessage()
				),
			];
		} catch ( \Exception $e ) {
			return [
				'success' => false,
				'message' => sprintf(
					// translators: %s: Error message.
					__( 'Failed to add subscriber: %s', 'sureforms-pro' ),
					$e->getMessage()
				),
			];
		}
	}

	/**
	 * Check if MailPoet plugin is active
	 *
	 * @return bool True if MailPoet is active, false otherwise.
	 * @since 2.1.0
	 */
	protected function is_plugin_active() {
		return class_exists( '\MailPoet\Config\Activator' );
	}
}

// Initialize the class.
Add_Subscriber::get_instance();
