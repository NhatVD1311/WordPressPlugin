<?php
/**
 * Cloud upload entry display filter.
 *
 * Swaps the local SureForms download URL(s) with the stored cloud URL(s) on
 * the entry detail view, for any field uploaded by the unified "Third Party
 * File Upload" workflow (Upload and Signature fields, any provider).
 *
 * Hook chain:
 *   1. `rest_request_before_callbacks` — capture the entry ID from the REST
 *      request (the `srfm_entry_value` filter carries no entry context).
 *   2. `srfm_entry_value` — replace the field's value(s) with the cloud
 *      URL(s) recorded in the `_srfm_cloud_uploads` entry bucket.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Entry display filter for cloud uploads.
 *
 * @since 2.11.0
 */
class Entry_Display_Filter {
	use Get_Instance;

	/**
	 * Field block names whose values may have been routed to cloud storage.
	 */
	private const SUPPORTED_BLOCKS = [ 'srfm-upload', 'srfm-signature' ];

	/**
	 * Entry ID for the current REST request, captured at
	 * `rest_request_before_callbacks` so the context-less `srfm_entry_value`
	 * filter can find the matching metadata.
	 *
	 * Safe as request-scoped static: the entry-detail endpoint resolves a
	 * single entry per request, so there is no cross-entry bleed within a
	 * request, and PHP state does not persist across requests.
	 *
	 * @var int
	 */
	private static $current_entry_id = 0;

	/**
	 * Per-request cache of resolved provider credentials, keyed by provider.
	 *
	 * Avoids re-decrypting credentials for every file when an entry has many
	 * uploads from the same provider. Value is the credentials array or a
	 * WP_Error (cached so a failure is not retried per file).
	 *
	 * @var array<string,array<string,mixed>|\WP_Error>
	 */
	private $credentials_cache = [];

	/**
	 * Constructor — register hooks.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		add_filter( 'rest_request_before_callbacks', [ $this, 'capture_entry_id' ], 10, 3 );
		add_filter( 'srfm_entry_value', [ $this, 'maybe_swap_url' ], 20, 2 );
	}

	/**
	 * Capture the entry ID for any REST request hitting an entry-detail endpoint.
	 *
	 * @param mixed                  $response Current response (passed through).
	 * @param array                  $handler  Route handler.
	 * @param \WP_REST_Request|mixed $request  Current request.
	 * @return mixed Untouched $response.
	 * @since 2.11.0
	 */
	public function capture_entry_id( $response, $handler, $request ) {
		unset( $handler ); // Required positional arg of the filter; not used here.
		if ( $request instanceof \WP_REST_Request ) {
			$route = (string) $request->get_route();
			if ( false !== strpos( $route, '/sureforms/v1/entry/' ) ) {
				$entry_id = absint( $request->get_param( 'id' ) );
				if ( $entry_id > 0 ) {
					self::$current_entry_id = $entry_id;
				}
			}
		}
		return $response;
	}

	/**
	 * Swap the field's URL value(s) with the stored cloud URL(s).
	 *
	 * @param mixed $value   Original value (string or array of strings).
	 * @param array $context Filter context: `field_name`, `label`, `field_block_name`.
	 * @return mixed Possibly-replaced value.
	 * @since 2.11.0
	 */
	public function maybe_swap_url( $value, $context = [] ) {
		if ( ! self::$current_entry_id ) {
			return $value;
		}

		$field_block_name = is_array( $context ) ? Helper::get_string_value( $context['field_block_name'] ?? '' ) : '';
		if ( ! in_array( $field_block_name, self::SUPPORTED_BLOCKS, true ) ) {
			return $value;
		}

		$entry = Entries::get( self::$current_entry_id );
		if ( empty( $entry ) ) {
			return $value;
		}

		$extras = is_array( $entry['extras'] ?? null ) ? $entry['extras'] : [];
		$bucket = is_array( $extras[ File_Storage_Handler::ENTRY_META_KEY ] ?? null ) ? $extras[ File_Storage_Handler::ENTRY_META_KEY ] : [];
		if ( empty( $bucket ) ) {
			return $value;
		}

		$field_name = Helper::get_string_value( $context['field_name'] ?? '' );
		$entries    = is_array( $bucket[ $field_name ] ?? null ) ? $bucket[ $field_name ] : [];
		if ( '' === $field_name || empty( $entries ) ) {
			return $value;
		}

		// Collect the cloud URL for each file routed from this field, asking
		// the provider to resolve it (S3 regenerates a fresh presigned URL;
		// Dropbox/Drive return the stored permanent link).
		$urls = [];
		foreach ( $entries as $item ) {
			$url = $this->resolve_display_url( is_array( $item ) ? $item : [], $field_block_name );
			if ( '' !== $url ) {
				$urls[] = $url;
			}
		}

		if ( empty( $urls ) ) {
			return $value;
		}

		// Upload fields carry an array of URLs; signature fields a single
		// string. Preserve the original value's shape.
		if ( is_array( $value ) ) {
			return $urls;
		}
		return $urls[0];
	}

	/**
	 * Resolve a viewable URL for a single stored upload item.
	 *
	 * Delegates to the originating provider's {@see File_Storage_Provider::get_display_url()}
	 * so providers with expiring links (S3 presigned URLs) regenerate them at
	 * view time, falling back to the stored `url` when the provider is
	 * unavailable or its credentials cannot be resolved.
	 *
	 * @param array<string,mixed> $item             Stored upload metadata.
	 * @param string              $field_block_name Originating field block (e.g. `srfm-signature`).
	 * @return string
	 * @since 2.11.0
	 */
	private function resolve_display_url( $item, $field_block_name = '' ) {
		// Signatures are images — prefer the stored inline thumbnail (e.g. Google
		// Drive) so the entry view renders the signature rather than a viewer link.
		if ( 'srfm-signature' === $field_block_name ) {
			$thumbnail = Helper::get_string_value( $item['thumbnail_url'] ?? '' );
			if ( '' !== $thumbnail ) {
				return $thumbnail;
			}
		}

		$fallback     = Helper::get_string_value( $item['url'] ?? '' );
		$provider_key = Helper::get_string_value( $item['provider'] ?? '' );
		if ( '' === $provider_key ) {
			return $fallback;
		}

		$provider = File_Storage_Registry::get_instance()->get( $provider_key );
		if ( ! $provider instanceof File_Storage_Provider ) {
			return $fallback;
		}

		if ( ! array_key_exists( $provider_key, $this->credentials_cache ) ) {
			$this->credentials_cache[ $provider_key ] = $provider->get_credentials();
		}
		$credentials = $this->credentials_cache[ $provider_key ];
		if ( is_wp_error( $credentials ) ) {
			return $fallback;
		}

		$url = Helper::get_string_value( $provider->get_display_url( $item, $credentials ) );
		return '' !== $url ? $url : $fallback;
	}
}
