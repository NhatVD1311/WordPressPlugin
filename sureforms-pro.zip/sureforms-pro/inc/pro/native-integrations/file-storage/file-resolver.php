<?php
/**
 * File Resolver.
 *
 * Provider-agnostic helpers for the unified "Third Party File Upload"
 * workflow: enumerate the file-bearing values in a submission (upload +
 * signature fields) and resolve each to an absolute local filesystem path.
 *
 * The path-resolution logic is provider-agnostic so every provider resolves
 * source files identically.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

use SRFM\Inc\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Resolves submission file fields to local paths.
 *
 * @since 2.11.0
 */
class File_Resolver {
	/**
	 * Enumerate uploaded files in a submission, grouped by source field.
	 *
	 * Scans for `srfm-upload-*` (value: array of URLs) and `srfm-signature-*`
	 * (value: single URL) keys. Repeater-nested fields cannot be upload or
	 * signature blocks, so a flat scan of the submission is sufficient.
	 *
	 * @param array<string,mixed> $submission_data Raw submission data.
	 * @return array<int,array{field_key:string,block_id:string,type:string,files:array<int,array{path:string,filename:string}>}>
	 *   One entry per field that yielded at least one resolvable file.
	 * @since 2.11.0
	 */
	public static function get_uploaded_files( $submission_data ) {
		$result = [];

		foreach ( (array) $submission_data as $key => $value ) {
			if ( ! is_string( $key ) || ! preg_match( '/^srfm-(upload|signature)-(.+?)-lbl-/', $key, $matches ) ) {
				continue;
			}

			$type     = $matches[1];
			$block_id = $matches[2];
			$urls     = is_array( $value ) ? $value : [ $value ];
			$files    = [];

			foreach ( $urls as $url ) {
				$url = self::extract_url_from_html( Helper::get_string_value( $url ) );
				if ( '' === $url ) {
					continue;
				}
				$path = self::resolve_local_file_path( $url );
				if ( '' === $path || ! is_readable( $path ) ) {
					continue;
				}
				$files[] = [
					'path'     => $path,
					'filename' => basename( $path ),
				];
			}

			if ( ! empty( $files ) ) {
				$result[] = [
					'field_key' => $key,
					'block_id'  => $block_id,
					'type'      => $type,
					'files'     => $files,
				];
			}
		}

		return $result;
	}

	/**
	 * Resolve a local filesystem path from a public URL or already-local path.
	 *
	 * Handles URL-encoded values, SureForms private download URLs
	 * (`/sureforms-download/<base64>/<form_id>/`), absolute paths, and site
	 * URLs that map into wp-content/uploads/.
	 *
	 * @param string $url_or_path Resolved value of the file field.
	 * @return string Absolute filesystem path, or empty string if not resolvable.
	 * @since 2.11.0
	 */
	public static function resolve_local_file_path( $url_or_path ) {
		$value = trim( $url_or_path );
		if ( '' === $value ) {
			return '';
		}

		// Decode if the smart-tag value was URL-encoded.
		if ( false !== stripos( $value, '%3a%2f%2f' ) ) {
			$value = rawurldecode( $value );
		}

		// SureForms-private download URL → wp-content/uploads/sureforms-private/.
		if ( preg_match( '#/sureforms-download/([A-Za-z0-9+/=_-]+)/(\d+)/?#', $value, $matches ) ) {
			$encoded = strtr( $matches[1], '-_', '+/' );
			$padded  = $encoded . str_repeat( '=', ( 4 - ( strlen( $encoded ) % 4 ) ) % 4 );
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding the SureForms download-token filename, not obfuscation.
			$decoded = base64_decode( $padded, true );
			if ( is_string( $decoded ) && '' !== $decoded ) {
				$candidates = [];
				if ( function_exists( 'wp_upload_dir' ) ) {
					$uploads = wp_upload_dir();
					if ( ! empty( $uploads['basedir'] ) ) {
						$candidates[] = rtrim( $uploads['basedir'], '/' ) . '/sureforms-private/' . $decoded;
					}
				}
				$candidates[] = rtrim( ABSPATH, '/' ) . '/wp-content/uploads/sureforms-private/' . $decoded;
				foreach ( $candidates as $candidate ) {
					if ( file_exists( $candidate ) && is_file( $candidate ) && self::within_uploads( $candidate ) ) {
						return $candidate;
					}
				}
			}
		}

		// Already an absolute filesystem path.
		if ( '/' === substr( $value, 0, 1 ) && file_exists( $value ) && self::within_uploads( $value ) ) {
			return $value;
		}

		// Map site URL → ABSPATH.
		$relative = function_exists( 'wp_make_link_relative' ) ? wp_make_link_relative( $value ) : '';
		if ( '' === $relative || $relative === $value ) {
			$parsed_path = wp_parse_url( $value, PHP_URL_PATH );
			$relative    = is_string( $parsed_path ) ? $parsed_path : '';
		}
		if ( '' === $relative ) {
			return '';
		}
		$relative = '/' . ltrim( $relative, '/' );

		$candidate = rtrim( ABSPATH, '/' ) . $relative;
		if ( file_exists( $candidate ) && is_file( $candidate ) && self::within_uploads( $candidate ) ) {
			return $candidate;
		}

		// Fallback: locate within the WP uploads directory by relative path.
		if ( function_exists( 'wp_upload_dir' ) ) {
			$uploads = wp_upload_dir();
			if ( ! empty( $uploads['basedir'] ) && false !== strpos( $relative, '/uploads/' ) ) {
				$rel_to_uploads = substr( $relative, strpos( $relative, '/uploads/' ) + strlen( '/uploads/' ) );
				$candidate      = rtrim( $uploads['basedir'], '/' ) . '/' . $rel_to_uploads;
				if ( file_exists( $candidate ) && is_file( $candidate ) && self::within_uploads( $candidate ) ) {
					return $candidate;
				}
			}
		}

		return '';
	}

	/**
	 * Whether a resolved path lies inside the WordPress uploads directory.
	 *
	 * Containment guard for {@see self::resolve_local_file_path()}: a crafted
	 * submission value must never resolve to a file outside
	 * `wp-content/uploads/` (where every SureForms upload lives), preventing
	 * traversal-based reads/deletes of arbitrary server files. Also re-applied
	 * at the cloud-upload retry sink, which re-reads a stored local path.
	 *
	 * @param string $path Absolute filesystem path to validate.
	 * @return bool True when $path resolves within the uploads base directory.
	 * @since 2.11.0
	 */
	public static function within_uploads( $path ) {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return false;
		}
		$uploads = wp_upload_dir();
		$base    = ! empty( $uploads['basedir'] ) ? realpath( $uploads['basedir'] ) : false;
		$real    = realpath( $path );
		if ( false === $base || false === $real ) {
			return false;
		}
		return 0 === strpos( $real, $base . DIRECTORY_SEPARATOR );
	}

	/**
	 * Extract a clean URL from a value that may contain an HTML anchor tag.
	 *
	 * SureForms' smart-tag substitution for file fields often returns a full
	 * `<a href="...">...</a>` string rather than a raw URL.
	 *
	 * @param string $value Possibly HTML-wrapped URL.
	 * @return string Plain URL.
	 * @since 2.11.0
	 */
	private static function extract_url_from_html( $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		if ( false !== strpos( $value, '<a' ) && preg_match( '/href=["\']([^"\']+)["\']/i', $value, $matches ) ) {
			return trim( $matches[1] );
		}
		return $value;
	}
}
