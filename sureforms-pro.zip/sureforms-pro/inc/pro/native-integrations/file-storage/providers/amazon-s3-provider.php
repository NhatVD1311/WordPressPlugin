<?php
/**
 * Amazon S3 file-storage provider.
 *
 * Implements the {@see File_Storage_Provider} contract for Amazon S3 without
 * the AWS SDK: every request is signed directly with AWS Signature Version 4
 * (SigV4) over `wp_remote_*`. Buckets are the container layer (chosen per
 * form), top-level key prefixes are the folders, objects are uploaded with a
 * single PUT, and entry-view links are short-lived presigned GET URLs minted
 * fresh on view (objects stay private).
 *
 * Driven by the unified "Third Party File Upload" workflow, alongside the
 * other providers (Dropbox, and the future Google Drive).
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\Services\Config_Manager;
use SRFM_Pro\Inc\Pro\Native_Integrations\Utils\Integration_Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Amazon S3 provider.
 *
 * @since 2.11.0
 */
class Amazon_S3_Provider implements File_Storage_Provider {
	/**
	 * Provider machine key (matches the global connection `type` and the
	 * `amazons3` value the connection-tester branches on).
	 */
	public const KEY = 'amazons3';

	/**
	 * AWS service name used in the SigV4 credential scope.
	 */
	private const SERVICE = 's3';

	/**
	 * SigV4 algorithm identifier.
	 */
	private const ALGORITHM = 'AWS4-HMAC-SHA256';

	/**
	 * Default region when the stored connection omits one.
	 */
	private const DEFAULT_REGION = 'us-east-1';

	/**
	 * Lifetime (seconds) of the presigned GET URLs shown on the entry view.
	 */
	private const PRESIGN_EXPIRES = 3600;

	/**
	 * Single-shot PUT upload limit in bytes.
	 *
	 * S3 itself allows 5 GB per PUT, but the whole object is buffered in PHP
	 * memory for the request body, so this is capped far lower; larger files
	 * need multipart upload (a future addition). The memory guard in
	 * {@see self::upload_file()} is the primary protection on bounded-memory
	 * hosts — this is the absolute ceiling.
	 */
	private const MAX_SINGLE_UPLOAD_BYTES = 1073741824;

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_key() {
		return self::KEY;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_label() {
		return __( 'Amazon S3', 'sureforms-pro' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return bool
	 * @since 2.11.0
	 */
	public function is_connected() {
		$row = Integrations::get_by_type( self::KEY );
		return ! empty( $row ) && isset( $row['status'] ) && 1 === Helper::get_integer_value( $row['status'] );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string,mixed>|\WP_Error
	 * @since 2.11.0
	 */
	public function get_credentials() {
		$config_manager     = new Config_Manager();
		$integration_config = $config_manager->load_integration_config( self::KEY );
		$auth_config        = is_array( $integration_config ) ? Helper::get_array_value( $integration_config['auth'] ?? [] ) : [];

		return Integration_Utils::get_stored_credentials( self::KEY, $auth_config, null, $config_manager );
	}

	/**
	 * {@inheritDoc}
	 *
	 * Returns the account's buckets (the S3 container layer). Requires the
	 * `s3:ListAllMyBuckets` permission; returns an empty array on failure so
	 * the workflow degrades gracefully.
	 *
	 * @param array<string,mixed> $credentials Decrypted S3 credentials.
	 * @return array<int,array{value:string,label:string}>
	 * @since 2.11.0
	 */
	public function list_containers( $credentials ) {
		$creds = $this->extract_creds( $credentials );
		if ( '' === $creds['access_key'] || '' === $creds['secret_key'] || ! $this->is_valid_region( $creds['region'] ) ) {
			return [];
		}

		$response = $this->signed_request( 'GET', $this->service_host( $creds['region'] ), '/', [], '', $creds );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return [];
		}

		$options = [];
		foreach ( $this->parse_list_buckets( wp_remote_retrieve_body( $response ) ) as $name ) {
			$options[] = [
				'value' => $name,
				'label' => $name,
			];
		}
		return $options;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Lists the top-level key prefixes ("folders") inside the chosen bucket
	 * via `ListObjectsV2` with `delimiter=/`. Always offers a bucket-root
	 * option (value `/`).
	 *
	 * @param array<string,mixed> $credentials Decrypted S3 credentials.
	 * @param string              $container   Selected bucket.
	 * @return array<int,array{value:string,label:string}>
	 * @since 2.11.0
	 */
	public function list_folders( $credentials, $container = '' ) {
		$bucket  = trim( Helper::get_string_value( $container ) );
		$options = [
			[
				'value' => '/',
				'label' => __( 'Bucket root (/)', 'sureforms-pro' ),
			],
		];

		if ( '' === $bucket || ! $this->is_valid_bucket( $bucket ) ) {
			return $options;
		}

		$creds = $this->extract_creds( $credentials );
		if ( '' === $creds['access_key'] || '' === $creds['secret_key'] || ! $this->is_valid_region( $creds['region'] ) ) {
			return $options;
		}

		$response = $this->signed_request(
			'GET',
			$this->bucket_host( $bucket, $creds['region'] ),
			'/',
			[
				'list-type' => '2',
				'delimiter' => '/',
			],
			'',
			$creds
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return $options;
		}

		foreach ( $this->parse_common_prefixes( wp_remote_retrieve_body( $response ) ) as $prefix ) {
			$options[] = [
				'value' => $prefix,
				'label' => $prefix,
			];
		}
		return $options;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string              $file_path   Absolute local file path.
	 * @param string              $folder      Destination prefix ("/" for bucket root).
	 * @param array<string,mixed> $credentials Decrypted S3 credentials.
	 * @param array<string,mixed> $context     Extra context — expects `container` (the bucket).
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	public function upload_file( $file_path, $folder, $credentials, $context = [] ) {
		$creds = $this->extract_creds( $credentials );
		if ( '' === $creds['access_key'] || '' === $creds['secret_key'] ) {
			return $this->failure( __( 'Amazon S3 credentials are missing — please reconnect the integration.', 'sureforms-pro' ) );
		}

		$bucket = trim( Helper::get_string_value( $context['container'] ?? '' ) );
		if ( '' === $bucket ) {
			return $this->failure( __( 'No Amazon S3 bucket selected for this workflow.', 'sureforms-pro' ) );
		}
		if ( ! $this->is_valid_bucket( $bucket ) || ! $this->is_valid_region( $creds['region'] ) ) {
			return $this->failure( __( 'The Amazon S3 bucket or region for this workflow is invalid.', 'sureforms-pro' ) );
		}

		$size = filesize( $file_path );
		if ( false === $size || $size <= 0 ) {
			return $this->failure( __( 'Uploaded file is empty.', 'sureforms-pro' ) );
		}
		if ( $size > self::MAX_SINGLE_UPLOAD_BYTES ) {
			return $this->failure(
				sprintf(
					/* translators: %d max bytes (5GB). */
					__( 'File is too large for a single Amazon S3 upload (max %d bytes). Larger files require multipart upload, which is not yet supported.', 'sureforms-pro' ),
					self::MAX_SINGLE_UPLOAD_BYTES
				)
			);
		}

		// The whole file is held in memory for the request body, so guard
		// against files larger than the available PHP memory (~2x headroom for
		// the bytes plus the HTTP request copy). Skipped when the limit is
		// unlimited/unknown.
		$mem_limit = wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) );
		if ( $mem_limit > 0 && $size * 2 > $mem_limit - memory_get_usage( true ) ) {
			return $this->failure( __( 'The uploaded file is too large for the available server memory to send to Amazon S3.', 'sureforms-pro' ) );
		}

		$body = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $body ) {
			return $this->failure( __( 'Failed to read the uploaded file from disk.', 'sureforms-pro' ) );
		}

		$key = $this->build_object_key( $folder, basename( $file_path ) );
		if ( '' === $key ) {
			return $this->failure( __( 'Could not determine the destination key for the Amazon S3 upload.', 'sureforms-pro' ) );
		}

		$payload_hash = hash( 'sha256', $body );
		$response     = $this->signed_request(
			'PUT',
			$this->bucket_host( $bucket, $creds['region'] ),
			'/' . $this->uri_encode( $key, false ),
			[],
			$body,
			$creds,
			[ 'Content-Type' => $this->guess_content_type( $file_path ) ],
			$payload_hash
		);

		if ( is_wp_error( $response ) ) {
			return $this->failure(
				sprintf(
					/* translators: %s error message. */
					__( 'Network error uploading to Amazon S3: %s', 'sureforms-pro' ),
					$response->get_error_message()
				)
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body_str    = wp_remote_retrieve_body( $response );

		if ( 200 !== $status_code ) {
			$error_code = $this->parse_s3_error_code( $body_str );
			return [
				'success'  => false,
				'message'  => sprintf(
					/* translators: 1: HTTP status. 2: S3 error code (may be empty). */
					__( 'Amazon S3 returned HTTP %1$d%2$s.', 'sureforms-pro' ),
					$status_code,
					'' !== $error_code ? ': ' . $error_code : ''
				),
				'meta'     => [],
				// Never propagate the raw upstream body; cap + strip a snippet.
				'response' => mb_substr( wp_strip_all_tags( $body_str ), 0, 300 ),
			];
		}

		$etag = trim( Helper::get_string_value( wp_remote_retrieve_header( $response, 'etag' ) ), '"' );

		return [
			'success'  => true,
			'message'  => __( 'File uploaded to Amazon S3 successfully.', 'sureforms-pro' ),
			'meta'     => [
				'provider' => self::KEY,
				'bucket'   => $bucket,
				'region'   => $creds['region'],
				'path'     => $key,
				'url'      => $this->presign_get( $bucket, $key, $creds, self::PRESIGN_EXPIRES ),
				'filename' => basename( $key ),
				'file_id'  => $etag,
			],
			'response' => $body_str,
		];
	}

	/**
	 * {@inheritDoc}
	 *
	 * S3 objects are private, so a stored presigned URL would expire. This
	 * regenerates a fresh short-lived presigned GET URL from the stored
	 * bucket/region/key on every entry view.
	 *
	 * @param array<string,mixed> $meta        Stored upload metadata.
	 * @param array<string,mixed> $credentials Decrypted S3 credentials (resolved if empty).
	 * @return string
	 * @since 2.11.0
	 */
	public function get_display_url( $meta, $credentials = [] ) {
		$fallback = Helper::get_string_value( $meta['url'] ?? '' );
		$bucket   = Helper::get_string_value( $meta['bucket'] ?? '' );
		$key      = Helper::get_string_value( $meta['path'] ?? '' );
		if ( '' === $bucket || '' === $key || ! $this->is_valid_bucket( $bucket ) ) {
			return $fallback;
		}

		if ( empty( $credentials ) ) {
			$credentials = $this->get_credentials();
			if ( is_wp_error( $credentials ) ) {
				return $fallback;
			}
		}

		$creds = $this->extract_creds( $credentials );
		// Sign against the region the object was stored in, not the (possibly
		// changed) connection default.
		$stored_region   = Helper::get_string_value( $meta['region'] ?? '' );
		$creds['region'] = '' !== $stored_region ? $this->normalize_region( $stored_region ) : $creds['region'];
		if ( '' === $creds['access_key'] || '' === $creds['secret_key'] || ! $this->is_valid_region( $creds['region'] ) ) {
			return $fallback;
		}

		return $this->presign_get( $bucket, $key, $creds, self::PRESIGN_EXPIRES );
	}

	/**
	 * Validate a set of credentials by listing buckets (used by the
	 * connection-test backend before the api_key Connect flow saves).
	 *
	 * Treats an authenticated-but-unauthorized response (HTTP 403 AccessDenied)
	 * as a pass: the signature was accepted, so the keys are valid even though
	 * the IAM user cannot enumerate buckets.
	 *
	 * @param array<string,mixed> $credentials Raw credentials from the connect form.
	 * @return array{success:bool,message:string}
	 * @since 2.11.0
	 */
	public function test_connection( $credentials ) {
		$creds = $this->extract_creds( $credentials );
		if ( '' === $creds['access_key'] || '' === $creds['secret_key'] ) {
			return [
				'success' => false,
				'message' => __( 'Enter your Access Key ID and Secret Access Key.', 'sureforms-pro' ),
			];
		}
		if ( ! $this->is_valid_region( $creds['region'] ) ) {
			return [
				'success' => false,
				'message' => __( 'Enter a valid AWS region, e.g. us-east-1.', 'sureforms-pro' ),
			];
		}

		$response = $this->signed_request( 'GET', $this->service_host( $creds['region'] ), '/', [], '', $creds );
		if ( is_wp_error( $response ) ) {
			return [
				'success' => false,
				'message' => sprintf(
					/* translators: %s: error message. */
					__( 'Could not reach Amazon S3: %s', 'sureforms-pro' ),
					$response->get_error_message()
				),
			];
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 === $status_code ) {
			return [
				'success' => true,
				'message' => __( 'Connected to Amazon S3 successfully.', 'sureforms-pro' ),
			];
		}

		$error_code = $this->parse_s3_error_code( wp_remote_retrieve_body( $response ) );

		// Authenticated, but the IAM user lacks s3:ListAllMyBuckets — the keys
		// themselves are valid, so allow the connection to save.
		if ( 403 === $status_code && 'AccessDenied' === $error_code ) {
			return [
				'success' => true,
				'message' => __( 'Credentials are valid, but this IAM user cannot list buckets (s3:ListAllMyBuckets). Grant that permission to choose a bucket from a dropdown when configuring a form.', 'sureforms-pro' ),
			];
		}

		return [
			'success' => false,
			'message' => $this->describe_s3_error( $status_code, $error_code ),
		];
	}

	/**
	 * Normalize and extract the three credential fields.
	 *
	 * @param array<string,mixed> $credentials Decrypted credentials.
	 * @return array{access_key:string,secret_key:string,region:string}
	 * @since 2.11.0
	 */
	private function extract_creds( $credentials ) {
		$credentials = is_array( $credentials ) ? $credentials : [];
		return [
			'access_key' => trim( Helper::get_string_value( $credentials['access_key_id'] ?? '' ) ),
			'secret_key' => trim( Helper::get_string_value( $credentials['secret_access_key'] ?? '' ) ),
			'region'     => $this->normalize_region( Helper::get_string_value( $credentials['region'] ?? '' ) ),
		];
	}

	/**
	 * Normalize a region string, defaulting when blank.
	 *
	 * @param string $region Raw region.
	 * @return string
	 * @since 2.11.0
	 */
	private function normalize_region( $region ) {
		$region = strtolower( trim( $region ) );
		return '' === $region ? self::DEFAULT_REGION : $region;
	}

	/**
	 * Whether a region is well-formed.
	 *
	 * Guards against host injection — the region is interpolated into the
	 * request host, so it must be restricted to the AWS region charset and
	 * cannot contain `/`, `:`, `#`, `@`, dots or whitespace.
	 *
	 * @param string $region Normalized region.
	 * @return bool
	 * @since 2.11.0
	 */
	private function is_valid_region( $region ) {
		return is_string( $region ) && 1 === preg_match( '/^[a-z0-9-]{1,32}$/', $region );
	}

	/**
	 * Whether a bucket name is well-formed for a virtual-hosted-style host.
	 *
	 * Enforces the S3 bucket-name grammar (3-63 chars, lowercase alphanumerics,
	 * dots and hyphens) which also blocks any character that could break out of
	 * the request host.
	 *
	 * @param string $bucket Bucket name.
	 * @return bool
	 * @since 2.11.0
	 */
	private function is_valid_bucket( $bucket ) {
		return is_string( $bucket ) && 1 === preg_match( '/^[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]$/', $bucket );
	}

	/**
	 * Virtual-hosted-style host for a bucket.
	 *
	 * @param string $bucket Bucket name.
	 * @param string $region Region.
	 * @return string
	 * @since 2.11.0
	 */
	private function bucket_host( $bucket, $region ) {
		return $bucket . '.s3.' . $region . '.amazonaws.com';
	}

	/**
	 * Account-level service host (for ListBuckets).
	 *
	 * @param string $region Region.
	 * @return string
	 * @since 2.11.0
	 */
	private function service_host( $region ) {
		return 's3.' . $region . '.amazonaws.com';
	}

	/**
	 * Build an S3 object key from a folder prefix and file name.
	 *
	 * @param string $folder    Selected prefix ("/" for root, "sub/" or "/sub").
	 * @param string $file_name File basename.
	 * @return string Object key (no leading slash).
	 * @since 2.11.0
	 */
	private function build_object_key( $folder, $file_name ) {
		$folder    = trim( Helper::get_string_value( $folder ), '/' );
		$file_name = ltrim( $file_name, '/' );
		return '' === $folder ? $file_name : $folder . '/' . $file_name;
	}

	/**
	 * Guess a Content-Type for an upload from its file name.
	 *
	 * @param string $file_path Local file path.
	 * @return string
	 * @since 2.11.0
	 */
	private function guess_content_type( $file_path ) {
		$checked = wp_check_filetype( basename( $file_path ) );
		$mime    = is_array( $checked ) ? Helper::get_string_value( $checked['type'] ?? '' ) : '';
		return '' !== $mime ? $mime : 'application/octet-stream';
	}

	/**
	 * Perform a SigV4-signed (header-auth) request to S3.
	 *
	 * @param string                                                   $method        HTTP method.
	 * @param string                                                   $host          Request host.
	 * @param string                                                   $canonical_uri Already URI-encoded absolute path (e.g. `/` or `/folder/file.png`).
	 * @param array<string,string>                                     $query         Query parameters (raw, unencoded).
	 * @param string                                                   $body          Request body (empty for GET).
	 * @param array{access_key:string,secret_key:string,region:string} $creds  Credentials.
	 * @param array<string,string>                                     $extra_headers Extra headers to sign (e.g. Content-Type).
	 * @param string|null                                              $payload_hash  Precomputed hex SHA-256 of the body, or null to compute.
	 * @return array<string,mixed>|\WP_Error
	 * @since 2.11.0
	 */
	private function signed_request( $method, $host, $canonical_uri, $query, $body, $creds, $extra_headers = [], $payload_hash = null ) {
		$amz_date   = gmdate( 'Ymd\THis\Z' );
		$date_stamp = gmdate( 'Ymd' );

		if ( null === $payload_hash ) {
			$payload_hash = hash( 'sha256', is_string( $body ) ? $body : '' );
		}

		$headers = [
			'Host'                 => $host,
			'x-amz-content-sha256' => $payload_hash,
			'x-amz-date'           => $amz_date,
		];
		foreach ( $extra_headers as $name => $value ) {
			$headers[ $name ] = $value;
		}

		// Canonical headers: lowercased names, trimmed values, sorted by name.
		$canonical_map = [];
		foreach ( $headers as $name => $value ) {
			$canonical_map[ strtolower( $name ) ] = trim( (string) $value );
		}
		ksort( $canonical_map );

		$canonical_headers = '';
		foreach ( $canonical_map as $name => $value ) {
			$canonical_headers .= $name . ':' . $value . "\n";
		}
		$signed_headers  = implode( ';', array_keys( $canonical_map ) );
		$canonical_query = $this->canonical_query( $query );

		$canonical_request = implode(
			"\n",
			[
				$method,
				$canonical_uri,
				$canonical_query,
				$canonical_headers,
				$signed_headers,
				$payload_hash,
			]
		);

		$scope          = $date_stamp . '/' . $creds['region'] . '/' . self::SERVICE . '/aws4_request';
		$string_to_sign = implode(
			"\n",
			[
				self::ALGORITHM,
				$amz_date,
				$scope,
				hash( 'sha256', $canonical_request ),
			]
		);

		$signing_key = $this->signing_key( $creds['secret_key'], $date_stamp, $creds['region'] );
		$signature   = hash_hmac( 'sha256', $string_to_sign, $signing_key );

		// Authorization and User-Agent are added AFTER the canonical headers are
		// built, so they are intentionally not part of SignedHeaders (S3 does
		// not require them to be signed).
		$headers['Authorization'] = self::ALGORITHM . ' Credential=' . $creds['access_key'] . '/' . $scope
			. ', SignedHeaders=' . $signed_headers
			. ', Signature=' . $signature;
		$headers['User-Agent']    = 'SureForms Pro/' . SRFM_PRO_VER;

		$url = 'https://' . $host . $canonical_uri;
		if ( '' !== $canonical_query ) {
			$url .= '?' . $canonical_query;
		}

		$args = [
			'method'    => $method,
			'headers'   => $headers,
			'timeout'   => 'PUT' === $method ? 60 : 30,
			'sslverify' => true,
		];
		if ( 'PUT' === $method && is_string( $body ) ) {
			$args['body'] = $body;
		}

		// wp_safe_remote_request validates the URL and blocks redirects to
		// private/loopback hosts — defence-in-depth against host injection
		// (the region/bucket are also charset-validated before reaching here).
		return wp_safe_remote_request( $url, $args );
	}

	/**
	 * Build a presigned (query-auth) GET URL for an object.
	 *
	 * @param string                                                   $bucket  Bucket name.
	 * @param string                                                   $key     Object key.
	 * @param array{access_key:string,secret_key:string,region:string} $creds Credentials.
	 * @param int                                                      $expires Lifetime in seconds.
	 * @return string
	 * @since 2.11.0
	 */
	private function presign_get( $bucket, $key, $creds, $expires ) {
		$host          = $this->bucket_host( $bucket, $creds['region'] );
		$canonical_uri = '/' . $this->uri_encode( $key, false );
		$amz_date      = gmdate( 'Ymd\THis\Z' );
		$date_stamp    = gmdate( 'Ymd' );
		$scope         = $date_stamp . '/' . $creds['region'] . '/' . self::SERVICE . '/aws4_request';

		$query           = [
			'X-Amz-Algorithm'     => self::ALGORITHM,
			'X-Amz-Credential'    => $creds['access_key'] . '/' . $scope,
			'X-Amz-Date'          => $amz_date,
			'X-Amz-Expires'       => (string) $expires,
			'X-Amz-SignedHeaders' => 'host',
		];
		$canonical_query = $this->canonical_query( $query );

		$canonical_request = implode(
			"\n",
			[
				'GET',
				$canonical_uri,
				$canonical_query,
				'host:' . $host . "\n",
				'host',
				'UNSIGNED-PAYLOAD',
			]
		);

		$string_to_sign = implode(
			"\n",
			[
				self::ALGORITHM,
				$amz_date,
				$scope,
				hash( 'sha256', $canonical_request ),
			]
		);

		$signing_key = $this->signing_key( $creds['secret_key'], $date_stamp, $creds['region'] );
		$signature   = hash_hmac( 'sha256', $string_to_sign, $signing_key );

		// $canonical_query is always non-empty here (five fixed X-Amz-* params),
		// so the `?…&X-Amz-Signature=` concatenation is always well-formed.
		return 'https://' . $host . $canonical_uri . '?' . $canonical_query . '&X-Amz-Signature=' . $signature;
	}

	/**
	 * Derive the SigV4 signing key.
	 *
	 * @param string $secret     Secret access key.
	 * @param string $date_stamp `Ymd` date.
	 * @param string $region     Region.
	 * @return string Raw binary signing key.
	 * @since 2.11.0
	 */
	private function signing_key( $secret, $date_stamp, $region ) {
		$k_date    = hash_hmac( 'sha256', $date_stamp, 'AWS4' . $secret, true );
		$k_region  = hash_hmac( 'sha256', $region, $k_date, true );
		$k_service = hash_hmac( 'sha256', self::SERVICE, $k_region, true );
		return hash_hmac( 'sha256', 'aws4_request', $k_service, true );
	}

	/**
	 * Build a canonical (sorted, URI-encoded) query string.
	 *
	 * @param array<string,string> $query Query parameters.
	 * @return string
	 * @since 2.11.0
	 */
	private function canonical_query( $query ) {
		if ( empty( $query ) ) {
			return '';
		}
		$encoded = [];
		foreach ( $query as $name => $value ) {
			$encoded[ rawurlencode( (string) $name ) ] = rawurlencode( (string) $value );
		}
		ksort( $encoded );
		$pairs = [];
		foreach ( $encoded as $name => $value ) {
			$pairs[] = $name . '=' . $value;
		}
		return implode( '&', $pairs );
	}

	/**
	 * URI-encode a path the way S3 expects (RFC 3986, single-encoded).
	 *
	 * @param string $path         Raw path/key.
	 * @param bool   $encode_slash Whether to encode `/` (false keeps key separators).
	 * @return string
	 * @since 2.11.0
	 */
	private function uri_encode( $path, $encode_slash = true ) {
		$encoded = rawurlencode( $path );
		if ( ! $encode_slash ) {
			$encoded = str_replace( '%2F', '/', $encoded );
		}
		return $encoded;
	}

	// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- S3 XML elements (Buckets, Bucket, Name, CommonPrefixes, Prefix, Code) are PascalCase per the AWS spec and must be accessed verbatim.
	/**
	 * Parse bucket names out of a `ListBuckets` XML response.
	 *
	 * @param string $xml_string Response body.
	 * @return array<int,string>
	 * @since 2.11.0
	 */
	private function parse_list_buckets( $xml_string ) {
		$xml = $this->load_xml( $xml_string );
		if ( null === $xml || ! isset( $xml->Buckets->Bucket ) ) {
			return [];
		}
		$names = [];
		foreach ( $xml->Buckets->Bucket as $bucket ) {
			$name = Helper::get_string_value( (string) $bucket->Name );
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}
		return $names;
	}

	/**
	 * Parse `CommonPrefixes` out of a `ListObjectsV2` XML response.
	 *
	 * @param string $xml_string Response body.
	 * @return array<int,string>
	 * @since 2.11.0
	 */
	private function parse_common_prefixes( $xml_string ) {
		$xml = $this->load_xml( $xml_string );
		if ( null === $xml || ! isset( $xml->CommonPrefixes ) ) {
			return [];
		}
		$prefixes = [];
		foreach ( $xml->CommonPrefixes as $node ) {
			$prefix = Helper::get_string_value( (string) $node->Prefix );
			if ( '' !== $prefix ) {
				$prefixes[] = $prefix;
			}
		}
		return $prefixes;
	}

	/**
	 * Extract the S3 `<Error><Code>` from an error response body.
	 *
	 * @param string $xml_string Response body.
	 * @return string Error code, or '' when absent.
	 * @since 2.11.0
	 */
	private function parse_s3_error_code( $xml_string ) {
		$xml = $this->load_xml( $xml_string );
		if ( null === $xml || ! isset( $xml->Code ) ) {
			return '';
		}
		return Helper::get_string_value( (string) $xml->Code );
	}
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

	/**
	 * Safely parse an S3 XML response (network entity loading disabled).
	 *
	 * @param string $xml_string Raw XML.
	 * @return \SimpleXMLElement|null
	 * @since 2.11.0
	 */
	private function load_xml( $xml_string ) {
		$xml_string = (string) $xml_string;
		if ( '' === trim( $xml_string ) ) {
			return null;
		}
		$previous = libxml_use_internal_errors( true );
		$xml      = simplexml_load_string( $xml_string, 'SimpleXMLElement', LIBXML_NONET );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		return false === $xml ? null : $xml;
	}

	/**
	 * Map an S3 error to a user-facing message.
	 *
	 * @param int    $status_code HTTP status.
	 * @param string $error_code  S3 error code (may be empty).
	 * @return string
	 * @since 2.11.0
	 */
	private function describe_s3_error( $status_code, $error_code ) {
		switch ( $error_code ) {
			case 'InvalidAccessKeyId':
				return __( 'The Access Key ID is not valid.', 'sureforms-pro' );
			case 'SignatureDoesNotMatch':
				return __( 'The Secret Access Key is incorrect.', 'sureforms-pro' );
			case 'AuthorizationHeaderMalformed':
				return __( 'The region appears to be incorrect for these credentials.', 'sureforms-pro' );
			case 'AccessDenied':
				return __( 'Access denied — check the IAM permissions for these credentials.', 'sureforms-pro' );
		}
		return sprintf(
			/* translators: 1: HTTP status. 2: S3 error code (may be empty). */
			__( 'Amazon S3 connection failed (HTTP %1$d%2$s).', 'sureforms-pro' ),
			$status_code,
			'' !== $error_code ? ': ' . $error_code : ''
		);
	}

	/**
	 * Build a failure result.
	 *
	 * @param string $message Failure message.
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	private function failure( $message ) {
		return [
			'success'  => false,
			'message'  => $message,
			'meta'     => [],
			'response' => '',
		];
	}
}
