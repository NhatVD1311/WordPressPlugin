<?php
/**
 * Google Drive file-storage provider.
 *
 * Implements the {@see File_Storage_Provider} contract for Google Drive: lists
 * the connected account's folders, and pushes a single local file via a
 * multipart upload into a chosen folder. Authenticates with the OAuth access
 * token issued through the SureForms middleware (Model A — user-provided
 * Google Cloud credentials, mirroring Google Sheets).
 *
 * Driven by the unified "Third Party File Upload" workflow, alongside the
 * other providers (Dropbox, Amazon S3).
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\Services\Config_Manager;
use SRFM_Pro\Inc\Pro\Native_Integrations\Utils\Integration_Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Google Drive provider.
 *
 * @since 2.11.0
 */
class Google_Drive_Provider implements File_Storage_Provider {
	/**
	 * Provider machine key (matches the global connection `type`).
	 */
	public const KEY = 'googledrive';

	/**
	 * Drive API endpoint for listing files/folders.
	 */
	private const FILES_URL = 'https://www.googleapis.com/drive/v3/files';

	/**
	 * Drive media upload endpoint.
	 */
	private const UPLOAD_URL = 'https://www.googleapis.com/upload/drive/v3/files';

	/**
	 * Single-shot multipart upload limit in bytes.
	 *
	 * The whole object is buffered in memory for the multipart body, so this
	 * is capped well below Drive's true ceiling; larger files need a resumable
	 * (chunked) upload — a future addition. The memory guard in
	 * {@see self::upload_file()} is the primary protection on bounded-memory
	 * hosts; this is the absolute ceiling.
	 */
	private const MAX_SINGLE_UPLOAD_BYTES = 104857600;

	/**
	 * Maximum folder-listing pages to walk (100 folders per page).
	 */
	private const MAX_LIST_PAGES = 10;

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_key() {
		return self::KEY;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_label() {
		return __( 'Google Drive', 'sureforms-pro' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return bool
	 * @since 2.11.0
	 */
	public function is_connected() {
		$row = Integrations::get_by_type( self::KEY );
		return ! empty( $row ) && isset( $row['status'] ) && 1 === Helper::get_integer_value( $row['status'] );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string,mixed>|\WP_Error
	 * @since 2.11.0
	 */
	public function get_credentials() {
		$config_manager     = new Config_Manager();
		$integration_config = $config_manager->load_integration_config( self::KEY );
		$auth_config        = is_array( $integration_config ) ? Helper::get_array_value( $integration_config['auth'] ?? [] ) : [];

		// OAuth tokens are auto-refreshed via the middleware inside this call.
		return Integration_Utils::get_stored_credentials( self::KEY, $auth_config, null, $config_manager );
	}

	/**
	 * {@inheritDoc}
	 *
	 * Google Drive has no container layer above its folders, so the workflow
	 * goes straight to the folder pickers (like Dropbox).
	 *
	 * @param array<string,mixed> $credentials Decrypted Google Drive credentials.
	 * @return array<int,array{value:string,label:string}> Always empty.
	 * @since 2.11.0
	 */
	public function list_containers( $credentials ) {
		unset( $credentials ); // No container layer for Google Drive.
		return [];
	}

	/**
	 * {@inheritDoc}
	 *
	 * Lists the connected account's folders (paginated) for the folder pickers,
	 * always offering a "My Drive (root)" option with the native `root` alias.
	 *
	 * @param array<string,mixed> $credentials Decrypted Google Drive credentials.
	 * @param string              $container   Unused — Google Drive has no container layer.
	 * @return array<int,array{value:string,label:string}>
	 * @since 2.11.0
	 */
	public function list_folders( $credentials, $container = '' ) {
		unset( $container );

		$access_token = Helper::get_string_value( $credentials['access_token'] ?? '' );
		// Root is always available, even when the API call fails. `root` is the
		// Drive alias for My Drive (a non-empty value so the handler does not
		// treat it as "keep local").
		$options = [
			[
				'value' => 'root',
				'label' => __( 'My Drive (root)', 'sureforms-pro' ),
			],
		];

		if ( '' === $access_token ) {
			return $options;
		}

		$page_token = '';
		$pages      = 0;
		do {
			$query = [
				'q'                         => "mimeType='application/vnd.google-apps.folder' and trashed=false",
				'fields'                    => 'files(id,name),nextPageToken',
				'pageSize'                  => '100',
				'orderBy'                   => 'name',
				'supportsAllDrives'         => 'true',
				'includeItemsFromAllDrives' => 'true',
			];
			if ( '' !== $page_token ) {
				$query['pageToken'] = $page_token;
			}

			$response = wp_safe_remote_get(
				add_query_arg( array_map( 'rawurlencode', $query ), self::FILES_URL ),
				[
					'headers'   => [
						'Authorization' => 'Bearer ' . $access_token,
						'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
					],
					'timeout'   => 30,
					'sslverify' => true,
				]
			);

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				break;
			}

			$data = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( ! is_array( $data ) ) {
				break;
			}

			$files = isset( $data['files'] ) && is_array( $data['files'] ) ? $data['files'] : [];
			foreach ( $files as $file ) {
				if ( ! is_array( $file ) ) {
					continue;
				}
				$id   = Helper::get_string_value( $file['id'] ?? '' );
				$name = Helper::get_string_value( $file['name'] ?? '' );
				if ( '' !== $id && '' !== $name ) {
					$options[] = [
						'value' => $id,
						'label' => $name,
					];
				}
			}

			$page_token = Helper::get_string_value( $data['nextPageToken'] ?? '' );
			$pages++;
		} while ( '' !== $page_token && $pages < self::MAX_LIST_PAGES );

		return $options;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string              $file_path   Absolute local file path.
	 * @param string              $folder      Destination folder ID ("root" for My Drive root).
	 * @param array<string,mixed> $credentials Decrypted Google Drive credentials.
	 * @param array<string,mixed> $context     Extra context (unused for Drive).
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	public function upload_file( $file_path, $folder, $credentials, $context = [] ) {
		unset( $context ); // Drive has no container layer.

		$access_token = Helper::get_string_value( $credentials['access_token'] ?? '' );
		if ( '' === $access_token ) {
			return $this->failure( __( 'Google Drive access token is missing — please reconnect the integration.', 'sureforms-pro' ) );
		}

		$folder = Helper::get_string_value( $folder );
		if ( '' === $folder ) {
			return $this->failure( __( 'No Google Drive folder selected for this field.', 'sureforms-pro' ) );
		}

		$size = filesize( $file_path );
		if ( false === $size || $size <= 0 ) {
			return $this->failure( __( 'Uploaded file is empty.', 'sureforms-pro' ) );
		}
		if ( $size > self::MAX_SINGLE_UPLOAD_BYTES ) {
			return $this->failure(
				sprintf(
					/* translators: %d max bytes. */
					__( 'File is too large for a single Google Drive upload (max %d bytes). Larger files require a resumable upload, which is not yet supported.', 'sureforms-pro' ),
					self::MAX_SINGLE_UPLOAD_BYTES
				)
			);
		}

		// The whole file is held in memory for the multipart body, so guard
		// against files larger than the available PHP memory (~2x headroom for
		// the bytes plus the HTTP request copy). Skipped when the limit is
		// unlimited/unknown.
		$mem_limit = wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) );
		if ( $mem_limit > 0 && $size * 2 > $mem_limit - memory_get_usage( true ) ) {
			return $this->failure( __( 'The uploaded file is too large for the available server memory to send to Google Drive.', 'sureforms-pro' ) );
		}

		$bytes = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $bytes ) {
			return $this->failure( __( 'Failed to read the uploaded file from disk.', 'sureforms-pro' ) );
		}

		$filename = basename( $file_path );
		$metadata = wp_json_encode(
			[
				'name'    => $filename,
				'parents' => [ $folder ],
			]
		);
		if ( false === $metadata ) {
			return $this->failure( __( 'Failed to encode Google Drive upload metadata.', 'sureforms-pro' ) );
		}

		$boundary = 'srfm-' . wp_generate_uuid4();
		$eol      = "\r\n";
		$body     = '--' . $boundary . $eol
			. 'Content-Type: application/json; charset=UTF-8' . $eol . $eol
			. $metadata . $eol
			. '--' . $boundary . $eol
			. 'Content-Type: ' . $this->guess_content_type( $filename ) . $eol . $eol
			. $bytes . $eol
			. '--' . $boundary . '--';

		$response = wp_safe_remote_post(
			add_query_arg(
				[
					'uploadType' => 'multipart',
					'fields'     => 'id,name,webViewLink',
				],
				self::UPLOAD_URL
			),
			[
				'headers'   => [
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'multipart/related; boundary=' . $boundary,
					'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'body'      => $body,
				'timeout'   => 60,
				'sslverify' => true,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $this->failure(
				sprintf(
					/* translators: %s error message. */
					__( 'Network error uploading to Google Drive: %s', 'sureforms-pro' ),
					$response->get_error_message()
				)
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body_str    = wp_remote_retrieve_body( $response );

		if ( 200 !== $status_code ) {
			$detail = mb_substr( wp_strip_all_tags( $body_str ), 0, 300 );
			return [
				'success'  => false,
				'message'  => sprintf(
					/* translators: 1: HTTP status. 2: response body. */
					__( 'Google Drive returned HTTP %1$d: %2$s', 'sureforms-pro' ),
					$status_code,
					$detail
				),
				'meta'     => [],
				'response' => $detail,
			];
		}

		$metadata_out = json_decode( $body_str, true );
		$metadata_out = is_array( $metadata_out ) ? $metadata_out : [];

		$file_id  = Helper::get_string_value( $metadata_out['id'] ?? '' );
		$name_out = Helper::get_string_value( $metadata_out['name'] ?? $filename );
		$web_url  = Helper::get_string_value( $metadata_out['webViewLink'] ?? '' );

		// Drive uploads are private to the connected account by default, so the
		// webViewLink/thumbnail would not render for email recipients, the entry
		// view or generated PDFs. Grant "anyone with the link" read access.
		if ( '' !== $file_id ) {
			$this->make_file_public( $file_id, $access_token );
		}

		return [
			'success'  => true,
			'message'  => __( 'File uploaded to Google Drive successfully.', 'sureforms-pro' ),
			'meta'     => [
				'provider'      => self::KEY,
				'path'          => $folder,
				'url'           => $web_url,
				'thumbnail_url' => self::build_thumbnail_url( $file_id ),
				'filename'      => $name_out,
				'file_id'       => $file_id,
			],
			'response' => $body_str,
		];
	}

	/**
	 * {@inheritDoc}
	 *
	 * Google Drive `webViewLink`s are permanent, so the stored URL is returned
	 * as-is — with the file name appended as a `#<filename>` fragment. The
	 * webViewLink carries neither a name nor an extension in its path, so the
	 * entry view reads the fragment to label the file (Drive ignores the
	 * fragment when the link is opened).
	 *
	 * @param array<string,mixed> $meta        Stored upload metadata.
	 * @param array<string,mixed> $credentials Unused — Drive links do not expire.
	 * @return string
	 * @since 2.11.0
	 */
	public function get_display_url( $meta, $credentials = [] ) {
		unset( $credentials );
		$url      = Helper::get_string_value( $meta['url'] ?? '' );
		$filename = Helper::get_string_value( $meta['filename'] ?? '' );
		if ( '' !== $url && '' !== $filename && false === strpos( $url, '#' ) ) {
			$url .= '#' . rawurlencode( $filename );
		}
		return $url;
	}

	/**
	 * Extract a Google Drive file id from one of its URLs.
	 *
	 * Recognises the thumbnail/`open`/`uc` forms (`…?id=<id>`) and the
	 * `…/file/d/<id>/…` viewer form.
	 *
	 * @param string $url Google Drive URL.
	 * @since 2.11.0
	 * @return string File id, or '' when none can be parsed.
	 */
	public static function file_id_from_url( $url ) {
		$url = Helper::get_string_value( $url );
		if ( '' === $url ) {
			return '';
		}

		$query = Helper::get_string_value( wp_parse_url( $url, PHP_URL_QUERY ) );
		if ( '' !== $query ) {
			$params = [];
			parse_str( $query, $params );
			if ( ! empty( $params['id'] ) && is_string( $params['id'] ) ) {
				return $params['id'];
			}
		}

		if ( preg_match( '#/file/d/([^/]+)#', $url, $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Resolve a single HTTP redirect and return its validated target URL.
	 *
	 * Issues a no-follow HEAD request so the 3xx response is returned instead of
	 * being followed, then reads and validates the `Location` header.
	 *
	 * @param string $url URL expected to answer with a 3xx redirect.
	 * @since 2.11.0
	 * @return string Validated redirect target, or '' when none is available.
	 */
	public static function resolve_redirect_url( $url ) {
		$response = wp_safe_remote_head(
			$url,
			[
				'redirection' => 0, // Capture the 3xx instead of following it.
				'timeout'     => 5,
				'sslverify'   => true,
				'user-agent'  => 'SureForms Pro/' . SRFM_PRO_VER,
			]
		);
		if ( is_wp_error( $response ) ) {
			return '';
		}

		$location = Helper::get_string_value( wp_remote_retrieve_header( $response, 'location' ) );
		if ( '' === $location ) {
			return '';
		}

		$location = wp_http_validate_url( $location );
		return $location ? $location : '';
	}

	/**
	 * Build a Google Drive inline-thumbnail URL for a file.
	 *
	 * The `drive.google.com/thumbnail?id=…` endpoint answers with a 302 redirect to
	 * a direct googleusercontent.com image URL. Browsers and email clients follow it
	 * transparently, but server-side PDF renderers (mPDF) do not, so the thumbnail
	 * rendered as a broken image in generated PDFs. We resolve that redirect once,
	 * here at upload time, and store the final direct URL — which renders everywhere
	 * (emails, the entry view and PDFs). The redirect target is read live rather than
	 * assembled from a hardcoded host so the integration is not tied to an
	 * undocumented googleusercontent URL shape. Falls back to the thumbnail endpoint
	 * if the redirect cannot be resolved.
	 *
	 * Unlike the webViewLink (which opens the Drive viewer page), this URL renders
	 * the file as an image — ideal for signatures and image uploads embedded via
	 * smart tags.
	 *
	 * @param string $file_id Google Drive file id.
	 * @since 2.11.0
	 * @return string Direct thumbnail image URL, or '' when no file id is available.
	 */
	private static function build_thumbnail_url( $file_id ) {
		$file_id = Helper::get_string_value( $file_id );
		if ( '' === $file_id ) {
			return '';
		}

		$thumbnail_url = 'https://drive.google.com/thumbnail?id=' . rawurlencode( $file_id ) . '&sz=w1000';
		$resolved      = self::resolve_redirect_url( $thumbnail_url );

		return '' !== $resolved ? $resolved : $thumbnail_url;
	}

	/**
	 * Grant "anyone with the link" reader access to an uploaded file.
	 *
	 * Drive uploads are private to the connected account by default, so their
	 * webViewLink/thumbnail only render for someone signed into that account
	 * (e.g. the admin viewing an entry) and fail server-side (PDF generation)
	 * and for email recipients. Best-effort: a failure is non-fatal — the file
	 * simply stays private.
	 *
	 * @param string $file_id      Drive file id.
	 * @param string $access_token OAuth access token.
	 * @since 2.11.0
	 * @return void
	 */
	private function make_file_public( $file_id, $access_token ) {
		wp_safe_remote_post(
			self::FILES_URL . '/' . rawurlencode( $file_id ) . '/permissions',
			[
				'headers'   => [
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
					'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'body'      => (string) wp_json_encode(
					[
						'role' => 'reader',
						'type' => 'anyone',
					]
				),
				'timeout'   => 30,
				'sslverify' => true,
			]
		);
	}

	/**
	 * Guess a Content-Type for an upload from its file name.
	 *
	 * @param string $file_name File name.
	 * @return string
	 * @since 2.11.0
	 */
	private function guess_content_type( $file_name ) {
		$checked = wp_check_filetype( $file_name );
		$mime    = is_array( $checked ) ? Helper::get_string_value( $checked['type'] ?? '' ) : '';
		return '' !== $mime ? $mime : 'application/octet-stream';
	}

	/**
	 * Build a failure result.
	 *
	 * @param string $message Failure message.
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	private function failure( $message ) {
		return [
			'success'  => false,
			'message'  => $message,
			'meta'     => [],
			'response' => '',
		];
	}
}
