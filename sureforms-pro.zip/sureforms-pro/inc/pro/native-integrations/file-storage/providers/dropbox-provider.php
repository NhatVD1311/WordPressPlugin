<?php
/**
 * Dropbox file-storage provider.
 *
 * Implements the {@see File_Storage_Provider} contract for Dropbox: lists
 * folders inside the App folder, and pushes a single local file directly to
 * /2/files/upload (the binary content endpoint) so files whose URLs are not
 * publicly reachable — typical for local/private SureForms uploads — still
 * reach Dropbox. After a successful upload it generates a public shared link.
 *
 * Driven by the unified "Third Party File Upload" workflow, alongside the
 * future providers (Google Drive, AWS).
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers;

use SRFM\Inc\Helper;
use SRFM_Pro\Inc\Pro\Database\Tables\Integrations;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\File_Storage_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\Services\Config_Manager;
use SRFM_Pro\Inc\Pro\Native_Integrations\Utils\Integration_Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Dropbox provider.
 *
 * @since 2.11.0
 */
class Dropbox_Provider implements File_Storage_Provider {
	/**
	 * Provider machine key (matches the global connection `type`).
	 */
	private const KEY = 'dropbox';

	/**
	 * Dropbox content-host upload endpoint (raw bytes).
	 */
	private const UPLOAD_URL = 'https://content.dropboxapi.com/2/files/upload';

	/**
	 * Dropbox API endpoint for listing folder contents.
	 */
	private const LIST_FOLDER_URL = 'https://api.dropboxapi.com/2/files/list_folder';

	/**
	 * Dropbox API endpoint for creating a public shared link.
	 */
	private const SHARED_LINK_URL = 'https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings';

	/**
	 * Single-shot upload limit in bytes (Dropbox docs: 150 MB).
	 */
	private const MAX_SINGLE_UPLOAD_BYTES = 157286400;

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_key() {
		return self::KEY;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_label() {
		return __( 'Dropbox', 'sureforms-pro' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return bool
	 * @since 2.11.0
	 */
	public function is_connected() {
		$row = Integrations::get_by_type( self::KEY );
		return ! empty( $row ) && isset( $row['status'] ) && 1 === Helper::get_integer_value( $row['status'] );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string,mixed>|\WP_Error
	 * @since 2.11.0
	 */
	public function get_credentials() {
		$config_manager     = new Config_Manager();
		$integration_config = $config_manager->load_integration_config( self::KEY );
		$auth_config        = is_array( $integration_config ) ? Helper::get_array_value( $integration_config['auth'] ?? [] ) : [];

		return Integration_Utils::get_stored_credentials( self::KEY, $auth_config, null, $config_manager );
	}

	/**
	 * {@inheritDoc}
	 *
	 * Dropbox has no container layer above its App folder, so the workflow
	 * goes straight to the folder pickers.
	 *
	 * @param array<string,mixed> $credentials Decrypted Dropbox credentials.
	 * @return array<int,array{value:string,label:string}> Always empty.
	 * @since 2.11.0
	 */
	public function list_containers( $credentials ) {
		unset( $credentials ); // No container layer for Dropbox.
		return [];
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param array<string,mixed> $credentials Decrypted Dropbox credentials.
	 * @param string              $container   Unused — Dropbox has no container layer.
	 * @return array<int,array{value:string,label:string}>
	 * @since 2.11.0
	 */
	public function list_folders( $credentials, $container = '' ) {
		unset( $container ); // Dropbox lists folders within the single App folder.
		$access_token = Helper::get_string_value( $credentials['access_token'] ?? '' );
		// Root option is always available, even when the API call fails or
		// the App folder has no subfolders yet.
		$options = [
			[
				'value' => '/',
				'label' => __( 'App folder root (/Apps/SureForms/)', 'sureforms-pro' ),
			],
		];

		if ( '' === $access_token ) {
			return $options;
		}

		$payload = wp_json_encode(
			[
				'path'                           => '',
				'recursive'                      => true,
				'include_deleted'                => false,
				'include_mounted_folders'        => false,
				'include_non_downloadable_files' => false,
			]
		);
		if ( false === $payload ) {
			return $options;
		}

		$response = wp_remote_post(
			self::LIST_FOLDER_URL,
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
					'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'body'    => $payload,
				'timeout' => 30,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $options;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) || ! isset( $data['entries'] ) || ! is_array( $data['entries'] ) ) {
			return $options;
		}

		foreach ( $data['entries'] as $entry ) {
			if ( ! is_array( $entry ) || 'folder' !== ( $entry['.tag'] ?? '' ) ) {
				continue;
			}
			$path = Helper::get_string_value( $entry['path_display'] ?? '' );
			if ( '' === $path ) {
				continue;
			}
			$options[] = [
				'value' => $path,
				'label' => $path,
			];
		}

		return $options;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string              $file_path   Absolute local file path.
	 * @param string              $folder      Destination folder ("/" for root).
	 * @param array<string,mixed> $credentials Decrypted Dropbox credentials.
	 * @param array<string,mixed> $context     Extra context (`autorename`).
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	public function upload_file( $file_path, $folder, $credentials, $context = [] ) {
		$access_token = Helper::get_string_value( $credentials['access_token'] ?? '' );
		if ( '' === $access_token ) {
			return $this->failure( __( 'Dropbox access token is missing — please reconnect the integration.', 'sureforms-pro' ) );
		}

		$dropbox_path = $this->build_dropbox_path( $folder, basename( $file_path ) );
		if ( '' === $dropbox_path || '/' === $dropbox_path ) {
			return $this->failure( __( 'Could not determine the destination path for Dropbox upload.', 'sureforms-pro' ) );
		}

		$size = filesize( $file_path );
		if ( false === $size || $size <= 0 ) {
			return $this->failure( __( 'Uploaded file is empty.', 'sureforms-pro' ) );
		}
		if ( $size > self::MAX_SINGLE_UPLOAD_BYTES ) {
			return $this->failure(
				sprintf(
					/* translators: %d max bytes (150MB). */
					__( 'File is too large for a single Dropbox upload (max %d bytes). Larger files require chunked upload, which is not yet supported.', 'sureforms-pro' ),
					self::MAX_SINGLE_UPLOAD_BYTES
				)
			);
		}

		// The whole file is held in memory for the request body, so guard
		// against files larger than the available PHP memory (~2x headroom
		// for the bytes plus the HTTP request copy). Skipped when the limit
		// is unlimited/unknown.
		$mem_limit = wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) );
		if ( $mem_limit > 0 && $size * 2 > $mem_limit - memory_get_usage( true ) ) {
			return $this->failure( __( 'The uploaded file is too large for the available server memory to send to Dropbox.', 'sureforms-pro' ) );
		}

		$body = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $body ) {
			return $this->failure( __( 'Failed to read the uploaded file from disk.', 'sureforms-pro' ) );
		}

		$args_json = wp_json_encode(
			[
				'path'            => $dropbox_path,
				'mode'            => 'add',
				'autorename'      => ! empty( $context['autorename'] ),
				'mute'            => false,
				'strict_conflict' => false,
			],
			JSON_UNESCAPED_SLASHES
		);
		if ( false === $args_json ) {
			return $this->failure( __( 'Failed to encode Dropbox API args.', 'sureforms-pro' ) );
		}

		$response = wp_remote_post(
			self::UPLOAD_URL,
			[
				'headers' => [
					'Authorization'   => 'Bearer ' . $access_token,
					'Content-Type'    => 'application/octet-stream',
					// Dropbox-API-Arg header must be ASCII-only.
					'Dropbox-API-Arg' => $this->escape_non_ascii( $args_json ),
					'User-Agent'      => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'body'    => $body,
				'timeout' => 60,
			]
		);

		if ( is_wp_error( $response ) ) {
			return $this->failure(
				sprintf(
					/* translators: %s error message. */
					__( 'Network error uploading to Dropbox: %s', 'sureforms-pro' ),
					$response->get_error_message()
				)
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body_str    = wp_remote_retrieve_body( $response );

		if ( 200 !== $status_code ) {
			// Surface a sanitized, length-capped snippet of the upstream body
			// in the user-facing message (never raw API output).
			$detail = mb_substr( wp_strip_all_tags( $body_str ), 0, 300 );
			return [
				'success'  => false,
				'message'  => sprintf(
					/* translators: 1: HTTP status. 2: response body. */
					__( 'Dropbox returned HTTP %1$d: %2$s', 'sureforms-pro' ),
					$status_code,
					$detail
				),
				'meta'     => [],
				'response' => $body_str,
			];
		}

		$metadata = json_decode( $body_str, true );
		$metadata = is_array( $metadata ) ? $metadata : [];

		$path_display = Helper::get_string_value( $metadata['path_display'] ?? '' );
		$filename     = Helper::get_string_value( $metadata['name'] ?? basename( $path_display ) );
		$file_id      = Helper::get_string_value( $metadata['id'] ?? '' );

		// Generate a public shared link so the entry view shows a URL that
		// works for anyone. Fall back to the in-Dropbox web URL otherwise.
		$share_path   = Helper::get_string_value( $metadata['path_lower'] ?? $path_display );
		$share_result = $this->create_shared_link( $share_path, $access_token );
		$shared_url   = Helper::get_string_value( $share_result['url'] ?? '' );
		$share_error  = Helper::get_string_value( $share_result['error'] ?? '' );
		$public_url   = '' !== $shared_url ? $shared_url : $this->build_web_url( $path_display );

		$message = __( 'File uploaded to Dropbox successfully.', 'sureforms-pro' );
		if ( '' === $shared_url ) {
			if ( 'missing_scope' === $share_error ) {
				$message .= ' ' . __( 'Note: public share link could not be created — the Dropbox app\'s `sharing.write` scope is not granted. Tick that scope on the Dropbox app\'s Permissions tab, click Submit, then reconnect the Dropbox integration to surface a public URL on future entries.', 'sureforms-pro' );
			} else {
				$message .= ' ' . __( 'Note: public share link could not be created. The entry shows an in-Dropbox URL that may require a login.', 'sureforms-pro' );
			}
		}

		return [
			'success'  => true,
			'message'  => $message,
			'meta'     => [
				'provider'   => self::KEY,
				'path'       => $path_display,
				'url'        => $public_url,
				'shared_url' => $shared_url,
				'filename'   => $filename,
				'file_id'    => $file_id,
			],
			'response' => $body_str,
		];
	}

	/**
	 * {@inheritDoc}
	 *
	 * Dropbox shared links are permanent, so the stored URL is returned as-is.
	 *
	 * @param array<string,mixed> $meta        Stored upload metadata.
	 * @param array<string,mixed> $credentials Unused — Dropbox links do not expire.
	 * @return string
	 * @since 2.11.0
	 */
	public function get_display_url( $meta, $credentials = [] ) {
		unset( $credentials );
		return Helper::get_string_value( $meta['url'] ?? '' );
	}

	/**
	 * Build a Dropbox destination path from a folder and file name.
	 *
	 * @param string $folder    Selected folder ("/" or "/sub", leading slash optional).
	 * @param string $file_name File basename.
	 * @return string Final Dropbox path beginning with `/`.
	 * @since 2.11.0
	 */
	private function build_dropbox_path( $folder, $file_name ) {
		$folder    = '/' . trim( $folder, '/' );
		$file_name = ltrim( $file_name, '/' );
		if ( '/' === $folder ) {
			return '/' . $file_name;
		}
		return $folder . '/' . $file_name;
	}

	/**
	 * Create a public shared link for an uploaded file.
	 *
	 * @param string $path         Dropbox path (typically `path_lower`).
	 * @param string $access_token OAuth access token.
	 * @return array{url:string,error:string} `url` is the public URL on
	 *   success; `error` is '' (success), 'missing_scope', 'network' or 'unknown'.
	 * @since 2.11.0
	 */
	private function create_shared_link( $path, $access_token ) {
		if ( '' === $path || '' === $access_token ) {
			return [
				'url'   => '',
				'error' => 'unknown',
			];
		}

		$payload = wp_json_encode( [ 'path' => $path ] );
		if ( false === $payload ) {
			return [
				'url'   => '',
				'error' => 'unknown',
			];
		}

		$response = wp_remote_post(
			self::SHARED_LINK_URL,
			[
				'headers' => [
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
					'User-Agent'    => 'SureForms Pro/' . SRFM_PRO_VER,
				],
				'body'    => $payload,
				'timeout' => 30,
			]
		);

		if ( is_wp_error( $response ) ) {
			return [
				'url'   => '',
				'error' => 'network',
			];
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$body_str = wp_remote_retrieve_body( $response );
		$data     = json_decode( $body_str, true );

		if ( 200 === $status && is_array( $data ) && ! empty( $data['url'] ) ) {
			return [
				'url'   => Helper::get_string_value( $data['url'] ),
				'error' => '',
			];
		}

		// Dropbox returns 409 when a shared link already exists; the existing
		// link metadata is nested inside the error payload.
		if ( 409 === $status && is_array( $data ) ) {
			$existing = $data['error']['shared_link_already_exists']['metadata']['url'] ?? '';
			if ( '' !== $existing ) {
				return [
					'url'   => Helper::get_string_value( $existing ),
					'error' => '',
				];
			}
		}

		// Dropbox signals a missing OAuth scope via the error tag / summary
		// (HTTP 401 for auth-policy errors, 400 for bad input). Parse the
		// decoded payload, falling back to a raw-body check.
		$error_tag        = is_array( $data ) && isset( $data['error']['.tag'] ) ? Helper::get_string_value( $data['error']['.tag'] ) : '';
		$error_summary    = is_array( $data ) ? Helper::get_string_value( $data['error_summary'] ?? '' ) : '';
		$is_missing_scope = 'missing_scope' === $error_tag
			|| false !== stripos( $error_summary, 'missing_scope' )
			|| false !== stripos( $body_str, 'sharing.write' );

		return [
			'url'   => '',
			'error' => $is_missing_scope ? 'missing_scope' : 'unknown',
		];
	}

	/**
	 * Build the Dropbox web UI URL for a file inside the App folder.
	 *
	 * @param string $path_display Dropbox `path_display` (App-folder-relative).
	 * @return string Absolute Dropbox web UI URL.
	 * @since 2.11.0
	 */
	private function build_web_url( $path_display ) {
		$path_display = '/' . ltrim( $path_display, '/' );
		$segments     = array_map( 'rawurlencode', explode( '/', ltrim( $path_display, '/' ) ) );
		return 'https://www.dropbox.com/home/Apps/SureForms/' . implode( '/', $segments );
	}

	/**
	 * Escape non-ASCII characters as `\uXXXX` for the Dropbox-API-Arg header.
	 *
	 * @param string $json A UTF-8 JSON string.
	 * @return string ASCII-safe JSON string.
	 * @since 2.11.0
	 */
	private function escape_non_ascii( $json ) {
		return (string) preg_replace_callback(
			'/[\x{0080}-\x{FFFF}]/u',
			static function ( $match ) {
				return sprintf( '\\u%04x', mb_ord( $match[0], 'UTF-8' ) );
			},
			$json
		);
	}

	/**
	 * Build a failure result.
	 *
	 * @param string $message Failure message.
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 * @since 2.11.0
	 */
	private function failure( $message ) {
		return [
			'success'  => false,
			'message'  => $message,
			'meta'     => [],
			'response' => '',
		];
	}
}
