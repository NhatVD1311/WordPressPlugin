<?php
/**
 * File Storage Provider contract.
 *
 * A File Storage Provider encapsulates everything a cloud destination
 * (Dropbox, Google Drive, AWS S3, …) needs to back the unified
 * "Third Party File Upload" workflow: reporting whether it is connected,
 * resolving its stored credentials, listing the folders a user can target,
 * and pushing a single local file into a chosen folder.
 *
 * Implementations live under `file-storage/providers/` and are registered
 * with the {@see File_Storage_Registry}. The provider is deliberately
 * unaware of SureForms form fields, submission records or local cleanup —
 * the workflow handler resolves files and persists entry metadata in a
 * provider-agnostic way; the provider only speaks to its own cloud API.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Contract for a cloud file-storage destination.
 *
 * @since 2.11.0
 */
interface File_Storage_Provider {
	/**
	 * Stable machine key for this provider.
	 *
	 * Must match the integration `type` used for the global connection
	 * record (e.g. `dropbox`, `google-drive`, `aws`).
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_key();

	/**
	 * Human-readable label shown in the source dropdown (e.g. "Dropbox").
	 *
	 * @return string
	 * @since 2.11.0
	 */
	public function get_label();

	/**
	 * Whether this provider currently has an enabled global connection.
	 *
	 * @return bool
	 * @since 2.11.0
	 */
	public function is_connected();

	/**
	 * Resolve the stored (decrypted) credentials for this provider.
	 *
	 * @return array<string,mixed>|\WP_Error Credentials array on success,
	 *   WP_Error when the connection is missing or cannot be decrypted.
	 * @since 2.11.0
	 */
	public function get_credentials();

	/**
	 * List selectable "containers" that sit above folders (e.g. S3 buckets).
	 *
	 * Most providers have a single implicit container (the connected account)
	 * and return an empty array — the workflow then skips the container picker
	 * and goes straight to folders. Providers that expose multiple containers
	 * (Amazon S3 buckets) return them so the workflow can show a bucket select
	 * before the per-field folder pickers.
	 *
	 * @param array<string,mixed> $credentials Decrypted provider credentials.
	 * @return array<int,array{value:string,label:string}> Container options,
	 *   or an empty array when the provider has no container layer.
	 * @since 2.11.0
	 */
	public function list_containers( $credentials );

	/**
	 * List selectable destination folders for the folder pickers.
	 *
	 * @param array<string,mixed> $credentials Decrypted provider credentials.
	 * @param string              $container   Selected container (e.g. the S3
	 *   bucket). Ignored by providers without a container layer.
	 * @return array<int,array{value:string,label:string}> Option list
	 *   (always includes a root option). Empty array on failure.
	 * @since 2.11.0
	 */
	public function list_folders( $credentials, $container = '' );

	/**
	 * Upload one local file into a destination folder.
	 *
	 * The provider performs its own API upload and (where supported)
	 * generates a publicly viewable URL. It MUST NOT delete the local file
	 * or write to the entry record — the handler owns those steps so they
	 * stay consistent across providers.
	 *
	 * @param string              $file_path   Absolute local filesystem path of the source file.
	 * @param string              $folder      Destination folder within the provider's scope ("/" for root).
	 * @param array<string,mixed> $credentials Decrypted provider credentials.
	 * @param array<string,mixed> $context     Extra context (e.g. `autorename`).
	 * @return array{success:bool,message:string,meta:array<string,mixed>,response:string}
	 *   On success `meta` contains at least: `provider`, `path`, `url`
	 *   (public/viewer URL), `filename`, `file_id`. Providers whose links
	 *   expire MAY add provider-specific keys needed to regenerate the URL in
	 *   {@see self::get_display_url()} — e.g. Amazon S3 adds `bucket` and
	 *   `region` (with `path` holding the object key).
	 * @since 2.11.0
	 */
	public function upload_file( $file_path, $folder, $credentials, $context = [] );

	/**
	 * Resolve a viewable URL for a stored upload at entry-display time.
	 *
	 * Providers whose stored URL is permanent (Dropbox shared links, Drive
	 * web links) just return the saved `url`. Providers whose links expire —
	 * notably Amazon S3 presigned URLs — regenerate a fresh URL from the
	 * stored object reference plus credentials, so the entry view never shows
	 * a stale/expired link.
	 *
	 * @param array<string,mixed> $meta        Stored upload metadata (as persisted on the entry).
	 * @param array<string,mixed> $credentials Decrypted provider credentials.
	 * @return string Viewable URL, or '' when one cannot be produced.
	 * @since 2.11.0
	 */
	public function get_display_url( $meta, $credentials = [] );
}
