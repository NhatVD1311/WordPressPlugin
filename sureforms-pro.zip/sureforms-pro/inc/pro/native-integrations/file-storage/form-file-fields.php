<?php
/**
 * Form file-field enumerator.
 *
 * Lists the file-bearing fields of a form — Upload (`srfm/upload`) and
 * Signature (`srfm/signature`) — so the unified "Third Party File Upload"
 * workflow can render one destination-folder picker per field at edit time
 * and route each field's file(s) at run time.
 *
 * Upload and signature blocks are not permitted inside a Repeater, so a
 * straightforward block-tree walk captures every eligible field with no
 * special repeater handling required.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

use SRFM\Inc\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Enumerates a form's upload + signature fields.
 *
 * @since 2.11.0
 */
class Form_File_Fields {
	/**
	 * Supported block names mapped to their short field type.
	 */
	private const SUPPORTED = [
		'srfm/upload'    => 'upload',
		'srfm/signature' => 'signature',
	];

	/**
	 * Get the upload + signature fields for a form.
	 *
	 * @param int $form_id Form (post) ID.
	 * @return array<int,array{id:string,label:string,type:string,slug:string}>
	 *   One entry per eligible field. `id` is the block_id, used to build the
	 *   per-field mapping key (`folder_map__<id>`).
	 * @since 2.11.0
	 */
	public static function get( $form_id ) {
		$form_id = absint( $form_id );
		if ( $form_id <= 0 ) {
			return [];
		}

		$content = get_post_field( 'post_content', $form_id );
		if ( ! is_string( $content ) || '' === $content ) {
			return [];
		}

		$fields = [];
		self::walk( parse_blocks( $content ), $fields );
		return $fields;
	}

	/**
	 * Recursively collect eligible blocks from a parsed block tree.
	 *
	 * @param array<int,array<string,mixed>>  $blocks Parsed blocks.
	 * @param array<int,array<string,string>> $fields Accumulator (by reference).
	 * @return void
	 * @since 2.11.0
	 */
	private static function walk( $blocks, &$fields ) {
		foreach ( (array) $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = Helper::get_string_value( $block['blockName'] ?? '' );
			if ( isset( self::SUPPORTED[ $name ] ) ) {
				$attrs    = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];
				$block_id = Helper::get_string_value( $attrs['block_id'] ?? '' );

				if ( '' !== $block_id ) {
					$type  = self::SUPPORTED[ $name ];
					$label = Helper::get_string_value( $attrs['label'] ?? '' );

					$fields[] = [
						'id'    => $block_id,
						'label' => '' !== $label ? $label : ucfirst( $type ),
						'type'  => $type,
						'slug'  => Helper::get_string_value( $attrs['slug'] ?? '' ),
					];
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk( $block['innerBlocks'], $fields );
			}
		}
	}
}
