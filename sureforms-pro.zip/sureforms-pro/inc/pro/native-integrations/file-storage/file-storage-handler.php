<?php
/**
 * File Storage Handler.
 *
 * Runtime dispatcher for the unified "Third Party File Upload" workflow.
 * Given a configured workflow it resolves the selected provider, enumerates
 * the submission's upload + signature files, routes each file to its mapped
 * (or default) folder via the provider, records a provider-agnostic entry
 * metadata bucket, and removes the local copy on success.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

use SRFM\Inc\Database\Tables\Entries;
use SRFM\Inc\Helper;
use SRFM\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Dispatches uploads for the unified file-upload workflow.
 *
 * @since 2.11.0
 */
class File_Storage_Handler {
	use Get_Instance;

	/**
	 * Integration id of the synthetic unified workflow.
	 */
	public const INTEGRATION = 'thirdpartyfileupload';

	/**
	 * Entry `extras` key holding provider-agnostic upload metadata.
	 *
	 * Each record carries a `status`: `success` records hold
	 * `[ provider, url, shared_url, filename, path, file_id, bucket, region, uploaded_at ]`;
	 * `failed` records hold `[ provider, error, filename, local_path, folder,
	 * container, attempts, last_attempt_at ]` so the upload can be retried from
	 * the entry view. A missing `status` is treated as `success` (back-compat).
	 */
	public const ENTRY_META_KEY = '_srfm_cloud_uploads';

	/**
	 * Entry `extras` flag set when the synchronous cloud upload handled a
	 * submission, so the async workflow skips it (avoids double-upload).
	 */
	public const SYNC_DONE_KEY = '_srfm_cloud_sync_complete';

	/**
	 * Cloud records produced by the synchronous upload, keyed by field key,
	 * buffered until the entry is created (entry id is unknown at upload time).
	 *
	 * @var array<string,array<int,array<string,mixed>>>
	 */
	private $sync_cloud_records = [];

	/**
	 * Whether the synchronous cloud path was active (a connected file-storage
	 * workflow was found) for the current submission.
	 *
	 * @var bool
	 */
	private $sync_active = false;

	/**
	 * Per-form file-storage context cache (provider/credentials/container/fields),
	 * or null when the form has no usable file-storage workflow.
	 *
	 * @var array<int,array<string,mixed>|null>
	 */
	private $form_context_cache = [];

	/**
	 * Handle a unified file-upload workflow.
	 *
	 * @param array<string,mixed> $workflow        Workflow config (expects `fields.provider`
	 *                                              and a `fields.folder_map__<id>` per mapped field).
	 * @param array<string,mixed> $submission_data Raw submission data.
	 * @param int                 $form_id         Form ID.
	 * @param int                 $submission_id   Entry record ID (0 if unknown).
	 * @return array<string,mixed> Standard workflow result.
	 * @since 2.11.0
	 */
	public function handle_workflow( $workflow, $submission_data, $form_id, $submission_id = 0 ) {
		unset( $form_id ); // Reserved for future per-form smart-tag folder templating.

		// Skip when the synchronous cloud upload already handled this submission
		// during form processing (success → cloud, failure → kept local on purpose).
		if ( $submission_id > 0 ) {
			$done_entry  = Entries::get( absint( $submission_id ) );
			$done_extras = is_array( $done_entry['extras'] ?? null ) ? $done_entry['extras'] : [];
			if ( ! empty( $done_extras[ self::SYNC_DONE_KEY ] ) ) {
				$sync_name   = Helper::get_string_value( $workflow['name'] ?? __( 'Cloud File Storage', 'sureforms-pro' ) );
				$sync_bucket = is_array( $done_extras[ self::ENTRY_META_KEY ] ?? null ) ? $done_extras[ self::ENTRY_META_KEY ] : [];
				$uploaded    = 0;
				$failed      = 0;
				foreach ( $sync_bucket as $records ) {
					foreach ( (array) $records as $record ) {
						if ( ! is_array( $record ) ) {
							continue;
						}
						if ( 'failed' === ( $record['status'] ?? 'success' ) ) {
							++$failed;
						} else {
							++$uploaded;
						}
					}
				}

				if ( $failed > 0 ) {
					return $this->result(
						$sync_name,
						false,
						sprintf(
							/* translators: %d: number of files that failed to upload. */
							_n(
								'%d file failed to upload to cloud storage during submission and was kept on this site.',
								'%d files failed to upload to cloud storage during submission and were kept on this site.',
								$failed,
								'sureforms-pro'
							),
							$failed
						)
					);
				}

				return $this->result(
					$sync_name,
					true,
					0 === $uploaded
						? __( 'No mapped files to upload to cloud storage.', 'sureforms-pro' )
						: __( 'Files were uploaded to cloud storage during submission.', 'sureforms-pro' )
				);
			}
		}

		$fields       = isset( $workflow['fields'] ) && is_array( $workflow['fields'] ) ? $workflow['fields'] : [];
		$name         = Helper::get_string_value( $workflow['name'] ?? __( 'Cloud File Storage', 'sureforms-pro' ) );
		$provider_key = Helper::get_string_value( $fields['provider'] ?? '' );
		// Container (e.g. S3 bucket) for providers with a container layer; ''
		// for providers (Dropbox) that have a single implicit container.
		$container = Helper::get_string_value( $fields['bucket'] ?? '' );

		if ( '' === $provider_key ) {
			return $this->result( $name, false, __( 'No storage provider selected for this workflow.', 'sureforms-pro' ) );
		}

		$provider = File_Storage_Registry::get_instance()->get( $provider_key );
		if ( ! $provider instanceof File_Storage_Provider || ! $provider->is_connected() ) {
			return $this->result(
				$name,
				false,
				sprintf(
					/* translators: %s: provider key. */
					__( 'The selected storage provider (%s) is not connected.', 'sureforms-pro' ),
					$provider_key
				)
			);
		}

		$credentials = $provider->get_credentials();
		if ( is_wp_error( $credentials ) ) {
			return $this->result(
				$name,
				false,
				sprintf(
					/* translators: 1: provider label. 2: error message. */
					__( 'Could not load credentials for %1$s: %2$s', 'sureforms-pro' ),
					$provider->get_label(),
					$credentials->get_error_message()
				)
			);
		}

		$file_groups = File_Resolver::get_uploaded_files( $submission_data );
		if ( empty( $file_groups ) ) {
			return $this->result( $name, false, __( 'No uploaded files found in this submission to send.', 'sureforms-pro' ) );
		}

		$uploaded   = 0;
		$failed     = 0;
		$kept_local = 0;
		$notes      = [];

		foreach ( $file_groups as $group ) {
			$folder = Helper::get_string_value( $fields[ 'folder_map__' . $group['block_id'] ] ?? '' );

			// No folder mapped for this field → keep its file(s) in WordPress
			// (do not upload, retain the local copy).
			if ( '' === $folder ) {
				$kept_local += count( $group['files'] );
				continue;
			}

			foreach ( $group['files'] as $file ) {
				$res = $provider->upload_file(
					$file['path'],
					$folder,
					$credentials,
					[
						'autorename' => false,
						'container'  => $container,
					]
				);

				if ( ! empty( $res['success'] ) ) {
					$uploaded++;
					$this->save_cloud_metadata( $submission_id, $group['field_key'], is_array( $res['meta'] ?? null ) ? $res['meta'] : [] );
					$this->delete_local_file( $file['path'] );
				} else {
					$failed++;
					// Record the failure (the local copy is retained above) so it
					// can be retried from the entry view.
					$this->save_failure_metadata(
						$submission_id,
						$group['field_key'],
						[
							'provider'   => $provider_key,
							'filename'   => basename( $file['path'] ),
							'local_path' => $file['path'],
							'folder'     => $folder,
							'container'  => $container,
							'error'      => Helper::get_string_value( $res['message'] ?? '' ),
						]
					);
				}

				$note = Helper::get_string_value( $res['message'] ?? '' );
				if ( '' !== $note ) {
					$notes[] = $note;
				}
			}
		}

		// A run with no failures is a success, even if every field was kept
		// local (nothing mapped) — that is a valid configuration.
		$success = 0 === $failed && ( $uploaded > 0 || $kept_local > 0 );
		$summary = sprintf(
			/* translators: 1: number of files. 2: provider label. */
			_n( '%1$d file uploaded to %2$s.', '%1$d files uploaded to %2$s.', $uploaded, 'sureforms-pro' ),
			$uploaded,
			$provider->get_label()
		);
		if ( $kept_local > 0 ) {
			$summary .= ' ' . sprintf(
				/* translators: %d: number of files kept in WordPress. */
				_n( '%d file kept in WordPress.', '%d files kept in WordPress.', $kept_local, 'sureforms-pro' ),
				$kept_local
			);
		}
		if ( $failed > 0 ) {
			$summary .= ' ' . sprintf(
				/* translators: %d: number of failed files. */
				_n( '%d file failed.', '%d files failed.', $failed, 'sureforms-pro' ),
				$failed
			);
		}

		$message = trim( $summary . ' ' . implode( ' ', array_unique( $notes ) ) );

		return $this->result( $name, $success, $message );
	}

	/**
	 * Return the entry's failed cloud-upload count, grouped by provider.
	 *
	 * Backs the entry-view "retry failed uploads" notice (admin REST route).
	 *
	 * @param \WP_REST_Request $request REST request (expects `entry_id`).
	 * @return \WP_REST_Response
	 * @since 2.11.0
	 */
	public function get_cloud_upload_status( $request ) {
		$entry_id = absint( $request->get_param( 'entry_id' ) );
		if ( $entry_id <= 0 ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'A valid entry ID is required.', 'sureforms-pro' ),
				],
				400
			);
		}

		$counts = [];
		foreach ( $this->collect_failed_records( $entry_id ) as $record ) {
			$key            = Helper::get_string_value( $record['provider'] ?? '' );
			$counts[ $key ] = ( $counts[ $key ] ?? 0 ) + 1;
		}

		$providers = [];
		$registry  = File_Storage_Registry::get_instance();
		foreach ( $counts as $key => $count ) {
			$provider    = $registry->get( $key );
			$providers[] = [
				'provider' => $key,
				'label'    => $provider instanceof File_Storage_Provider ? $provider->get_label() : $key,
				'count'    => $count,
			];
		}

		return new \WP_REST_Response(
			[
				'success'      => true,
				'failed_count' => array_sum( $counts ),
				'providers'    => $providers,
			],
			200
		);
	}

	/**
	 * Re-attempt every failed cloud upload recorded on an entry.
	 *
	 * Each still-present local file is re-sent to its originally-mapped
	 * provider/folder/container; on success the record flips to `success`
	 * (and the local copy is removed), otherwise its attempt count and error
	 * are updated.
	 *
	 * @param \WP_REST_Request $request REST request (expects `entry_id`).
	 * @return \WP_REST_Response
	 * @since 2.11.0
	 */
	public function retry_cloud_uploads( $request ) {
		$entry_id = absint( $request->get_param( 'entry_id' ) );
		if ( $entry_id <= 0 ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'A valid entry ID is required.', 'sureforms-pro' ),
				],
				400
			);
		}

		$entry = Entries::get( $entry_id );
		if ( empty( $entry ) ) {
			return new \WP_REST_Response(
				[
					'success' => false,
					'message' => __( 'Entry not found.', 'sureforms-pro' ),
				],
				404
			);
		}

		$extras = is_array( $entry['extras'] ?? null ) ? $entry['extras'] : [];
		$bucket = is_array( $extras[ self::ENTRY_META_KEY ] ?? null ) ? $extras[ self::ENTRY_META_KEY ] : [];

		$registry    = File_Storage_Registry::get_instance();
		$creds_cache = [];
		$retried     = 0;
		$succeeded   = 0;
		$failed      = 0;
		$notes       = [];

		foreach ( $bucket as $field_key => $records ) {
			if ( ! is_array( $records ) ) {
				continue;
			}
			foreach ( $records as $index => $record ) {
				if ( ! is_array( $record ) || 'failed' !== ( $record['status'] ?? '' ) ) {
					continue;
				}
				$retried++;
				$provider_key = Helper::get_string_value( $record['provider'] ?? '' );
				$provider     = $registry->get( $provider_key );
				$local_path   = Helper::get_string_value( $record['local_path'] ?? '' );

				if ( ! $provider instanceof File_Storage_Provider || ! $provider->is_connected() ) {
					$error = sprintf(
						/* translators: %s: provider key. */
						__( 'The storage provider (%s) is not connected.', 'sureforms-pro' ),
						$provider_key
					);
				} elseif ( '' === $local_path || ! file_exists( $local_path ) || ! File_Resolver::within_uploads( $local_path ) ) {
					// Re-validate containment at the sink: only re-upload/delete a
					// file that still resolves inside the uploads directory, never
					// an arbitrary path (defence-in-depth against a tampered record).
					$error = __( 'The local file is no longer available to retry.', 'sureforms-pro' );
				} else {
					if ( ! isset( $creds_cache[ $provider_key ] ) ) {
						$creds_cache[ $provider_key ] = $provider->get_credentials();
					}
					$credentials = $creds_cache[ $provider_key ];
					if ( is_wp_error( $credentials ) ) {
						$error = $credentials->get_error_message();
					} else {
						$res = $provider->upload_file(
							$local_path,
							Helper::get_string_value( $record['folder'] ?? '' ),
							$credentials,
							[
								'autorename' => false,
								'container'  => Helper::get_string_value( $record['container'] ?? '' ),
							]
						);
						if ( ! empty( $res['success'] ) ) {
							$succeeded++;
							$records[ $index ] = $this->success_record( is_array( $res['meta'] ?? null ) ? $res['meta'] : [] );
							$this->delete_local_file( $local_path );
							continue;
						}
						$error = Helper::get_string_value( $res['message'] ?? '' );
					}
				}

				// Still failing — bump the attempt counter and record the error.
				$failed++;
				$records[ $index ]['attempts']        = absint( $record['attempts'] ?? 1 ) + 1;
				$records[ $index ]['last_attempt_at'] = time();
				$records[ $index ]['error']           = $error;
				if ( '' !== $error ) {
					$notes[] = $error;
				}
			}
			$bucket[ $field_key ] = $records;
		}

		$extras[ self::ENTRY_META_KEY ] = $bucket;
		$update                         = [ 'extras' => $extras ];

		$message = 0 === $retried
			? __( 'No failed uploads to retry.', 'sureforms-pro' )
			: sprintf(
				/* translators: 1: succeeded count. 2: retried count. */
				_n( '%1$d of %2$d file uploaded.', '%1$d of %2$d files uploaded.', $retried, 'sureforms-pro' ),
				$succeeded,
				$retried
			);
		if ( $failed > 0 && ! empty( $notes ) ) {
			$message .= ' ' . implode( ' ', array_unique( $notes ) );
		}

		// Record a log entry on the submission so the retry shows up in the
		// entry's "Entry Logs". Pass ONLY the new log — Entries::update() merges
		// it with the entry's existing logs (passing them back would duplicate).
		if ( $retried > 0 ) {
			$update['logs'] = $this->build_retry_log( $retried, $succeeded, $failed, $notes );
		}

		Entries::update( $entry_id, $update );

		return new \WP_REST_Response(
			[
				'success'   => true,
				'retried'   => $retried,
				'succeeded' => $succeeded,
				'failed'    => $failed,
				'message'   => $message,
			],
			200
		);
	}

	/**
	 * Synchronously upload one already-saved local file to cloud storage.
	 *
	 * Called during form processing (before the entry exists). When the field is
	 * mapped to a cloud folder on a connected provider, the file is uploaded and
	 * its cloud record buffered (persisted to the entry via {@see self::persist_sync_records()}),
	 * the local copy deleted, and the permanent/shared cloud URL returned for storage
	 * in `form_data`. Returns '' when not cloud-mapped or the upload fails (caller keeps local).
	 *
	 * @param int    $form_id    Form ID.
	 * @param string $field_key  Submission field key (srfm-upload-… / srfm-signature-…).
	 * @param string $local_path Absolute path to the saved local file.
	 * @since 2.11.0
	 * @return string Cloud URL on success, '' otherwise.
	 */
	public function maybe_upload_field_file_to_cloud( $form_id, $field_key, $local_path ) {
		$form_id    = absint( $form_id );
		$field_key  = Helper::get_string_value( $field_key );
		$local_path = Helper::get_string_value( $local_path );
		if ( ! $form_id || '' === $field_key || '' === $local_path || ! file_exists( $local_path ) ) {
			return '';
		}

		$context = $this->get_form_file_storage_context( $form_id );
		if ( null === $context ) {
			return '';
		}

		$provider = $context['provider'] ?? null;
		if ( ! $provider instanceof File_Storage_Provider ) {
			return '';
		}

		// The connected file-storage workflow is active for this form.
		$this->sync_active = true;

		$fields      = is_array( $context['fields'] ?? null ) ? $context['fields'] : [];
		$credentials = is_array( $context['credentials'] ?? null ) ? $context['credentials'] : [];
		if ( ! preg_match( '/^srfm-(?:upload|signature)-(.+?)-lbl-/', $field_key, $matches ) ) {
			return '';
		}
		$folder = Helper::get_string_value( $fields[ 'folder_map__' . $matches[1] ] ?? '' );
		if ( '' === $folder ) {
			return ''; // Field not mapped to a folder → keep local.
		}

		$res = $provider->upload_file(
			$local_path,
			$folder,
			$credentials,
			[
				'autorename' => false,
				'container'  => Helper::get_string_value( $context['container'] ?? '' ),
			]
		);

		if ( empty( $res['success'] ) ) {
			// Upload failed → keep the local copy as fallback, but record the
			// failure so the entry reflects it (accurate log + retry from the
			// entry view). Mirrors save_failure_metadata()'s record shape.
			$this->sync_cloud_records[ $field_key ][] = [
				'provider'        => Helper::get_string_value( $context['provider_key'] ?? '' ),
				'status'          => 'failed',
				'error'           => Helper::get_string_value( $res['message'] ?? '' ),
				'filename'        => basename( $local_path ),
				'local_path'      => $local_path,
				'folder'          => $folder,
				'container'       => Helper::get_string_value( $context['container'] ?? '' ),
				'attempts'        => 1,
				'last_attempt_at' => time(),
			];
			return '';
		}

		$meta                                     = is_array( $res['meta'] ?? null ) ? $res['meta'] : [];
		$this->sync_cloud_records[ $field_key ][] = $this->success_record( $meta );
		$this->delete_local_file( $local_path );

		// Signature fields are images — prefer the provider's inline thumbnail
		// URL (e.g. Google Drive) so the smart tag / email render the signature
		// image instead of a viewer-page link.
		if ( 0 === strpos( $field_key, 'srfm-signature-' ) ) {
			$thumbnail = Helper::get_string_value( $meta['thumbnail_url'] ?? '' );
			if ( '' !== $thumbnail ) {
				return $thumbnail;
			}

			// A Dropbox shared link (`dl=0`) opens the viewer page, which an
			// `<img>` cannot render. Its raw form (`raw=1`) serves the image
			// bytes, so the signature previews in smart tags / emails / PDFs.
			$raw_url = self::dropbox_raw_url( Helper::get_string_value( $meta['shared_url'] ?? '' ) );
			if ( '' !== $raw_url ) {
				return $raw_url;
			}
		}

		// Prefer a permanent/shared link for what gets stored in form_data/email.
		$url = Helper::get_string_value( $meta['shared_url'] ?? '' );
		return '' !== $url ? $url : Helper::get_string_value( $meta['url'] ?? '' );
	}

	/**
	 * Convert a Dropbox shared link to its raw (direct media) form.
	 *
	 * A Dropbox shared link points at the web viewer page (`dl=0`), which an
	 * `<img>` tag cannot render. Replacing the `dl` parameter with `raw=1`
	 * makes Dropbox serve the file bytes instead, so the URL is embeddable
	 * in smart tags, emails and PDFs.
	 *
	 * @param string $url Shared-link URL as stored by the Dropbox provider.
	 * @since 2.11.0
	 * @return string The raw-form URL, or '' when the URL is not a Dropbox link.
	 */
	public static function dropbox_raw_url( $url ) {
		$url  = Helper::get_string_value( $url );
		$host = strtolower( Helper::get_string_value( wp_parse_url( $url, PHP_URL_HOST ) ) );
		if ( ! in_array( $host, [ 'www.dropbox.com', 'dropbox.com' ], true ) ) {
			return '';
		}

		return add_query_arg( 'raw', '1', remove_query_arg( 'dl', $url ) );
	}

	/**
	 * Persist buffered synchronous cloud records onto the entry being created.
	 *
	 * Hooked to `srfm_before_entry_data` (the entry id is unknown while files are
	 * uploaded). Merges the buffered records into `extras['_srfm_cloud_uploads']`
	 * and flags the entry so the async workflow skips it.
	 *
	 * @param array<string,mixed> $entries_data Entry data being saved.
	 * @param array<string,mixed> $context      Filter context (unused).
	 * @since 2.11.0
	 * @return array<string,mixed>
	 */
	public function persist_sync_records( $entries_data, $context = [] ) {
		unset( $context );

		if ( ! is_array( $entries_data ) || ! $this->sync_active ) {
			return $entries_data;
		}

		$extras = is_array( $entries_data['extras'] ?? null ) ? $entries_data['extras'] : [];
		$bucket = is_array( $extras[ self::ENTRY_META_KEY ] ?? null ) ? $extras[ self::ENTRY_META_KEY ] : [];

		foreach ( $this->sync_cloud_records as $field_key => $records ) {
			$existing             = is_array( $bucket[ $field_key ] ?? null ) ? $bucket[ $field_key ] : [];
			$bucket[ $field_key ] = array_merge( $existing, $records );
		}

		$extras[ self::ENTRY_META_KEY ] = $bucket;
		$extras[ self::SYNC_DONE_KEY ]  = true;
		$entries_data['extras']         = $extras;

		// Reset for any subsequent submission in the same request.
		$this->sync_cloud_records = [];
		$this->sync_active        = false;

		return $entries_data;
	}

	/**
	 * Resolve a form's connected file-storage workflow context (provider/credentials/folders).
	 *
	 * @param int $form_id Form ID.
	 * @since 2.11.0
	 * @return array<string,mixed>|null Context array, or null when unavailable.
	 */
	private function get_form_file_storage_context( $form_id ) {
		$form_id = absint( $form_id );
		if ( array_key_exists( $form_id, $this->form_context_cache ) ) {
			return $this->form_context_cache[ $form_id ];
		}
		$this->form_context_cache[ $form_id ] = null;

		$workflows_json = get_post_meta( $form_id, '_srfm_native_integrations', true );
		if ( empty( $workflows_json ) || ! is_string( $workflows_json ) ) {
			return null;
		}
		$workflows = json_decode( $workflows_json, true );
		if ( ! is_array( $workflows ) ) {
			return null;
		}

		foreach ( $workflows as $workflow ) {
			if ( ! is_array( $workflow ) || self::INTEGRATION !== ( $workflow['integration'] ?? '' ) ) {
				continue;
			}
			$status = $workflow['status'] ?? '';
			if ( 'enabled' !== $status && true !== $status ) {
				continue;
			}

			$fields       = is_array( $workflow['fields'] ?? null ) ? $workflow['fields'] : [];
			$provider_key = Helper::get_string_value( $fields['provider'] ?? '' );
			if ( '' === $provider_key ) {
				continue;
			}

			$provider = File_Storage_Registry::get_instance()->get( $provider_key );
			if ( ! $provider instanceof File_Storage_Provider || ! $provider->is_connected() ) {
				continue;
			}

			$credentials = $provider->get_credentials();
			if ( is_wp_error( $credentials ) ) {
				continue;
			}

			$this->form_context_cache[ $form_id ] = [
				'provider'     => $provider,
				'provider_key' => $provider_key,
				'credentials'  => $credentials,
				'container'    => Helper::get_string_value( $fields['bucket'] ?? '' ),
				'fields'       => $fields,
			];
			return $this->form_context_cache[ $form_id ];
		}

		return null;
	}

	/**
	 * Build the retry-result log entry to merge into the submission's logs.
	 *
	 * Returns just the NEW log (mirroring {@see \SRFM\Inc\Database\Tables\Entries::add_log()}'s
	 * `title`/`messages`/`timestamp` shape). {@see \SRFM\Inc\Database\Tables\Entries::update()}
	 * merges it with the entry's existing logs, so the existing logs must NOT be
	 * passed back here (doing so duplicates them).
	 *
	 * @param int               $retried   Number of uploads re-attempted.
	 * @param int               $succeeded Number that succeeded.
	 * @param int               $failed    Number still failing.
	 * @param array<int,string> $notes     Error messages from this run.
	 * @return array<int,array<string,mixed>> A single-element list with the retry log.
	 * @since 2.11.0
	 */
	private function build_retry_log( $retried, $succeeded, $failed, $notes ) {
		$icon  = 0 === $failed ? '✓' : '✗';
		$title = 0 === $failed
			? __( 'Cloud File Storage - retry: all uploads succeeded', 'sureforms-pro' )
			: __( 'Cloud File Storage - retry: some uploads still failed', 'sureforms-pro' );

		$messages = [
			$icon . ' ' . sprintf(
				/* translators: 1: succeeded count. 2: retried count. */
				_n( '%1$d of %2$d file re-uploaded successfully.', '%1$d of %2$d files re-uploaded successfully.', $retried, 'sureforms-pro' ),
				$succeeded,
				$retried
			),
		];
		foreach ( array_unique( $notes ) as $note ) {
			if ( '' !== $note ) {
				$messages[] = '✗ ' . $note;
			}
		}

		return [
			[
				'title'     => $title,
				'messages'  => $messages,
				'timestamp' => current_time( 'mysql' ), // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp -- Mirrors Entries::add_log() to match the WordPress timezone.
			],
		];
	}

	/**
	 * Persist a successful provider upload onto the entry record.
	 *
	 * @param int                 $submission_id Entry ID.
	 * @param string              $field_key     Submission field key (e.g. `srfm-upload-…`).
	 * @param array<string,mixed> $meta          Provider upload meta (`provider`, `url`, `filename`, `path`).
	 * @return void
	 * @since 2.11.0
	 */
	private function save_cloud_metadata( $submission_id, $field_key, $meta ) {
		$submission_id = absint( $submission_id );
		if ( $submission_id <= 0 || '' === $field_key || '' === Helper::get_string_value( $meta['url'] ?? '' ) ) {
			return;
		}
		$this->append_record( $submission_id, $field_key, $this->success_record( $meta ) );
	}

	/**
	 * Persist a failed provider upload so it can be retried from the entry view.
	 *
	 * @param int                 $submission_id Entry ID.
	 * @param string              $field_key     Submission field key.
	 * @param array<string,mixed> $context       `provider`, `filename`, `local_path`, `folder`, `container`, `error`.
	 * @return void
	 * @since 2.11.0
	 */
	private function save_failure_metadata( $submission_id, $field_key, $context ) {
		$submission_id = absint( $submission_id );
		if ( $submission_id <= 0 || '' === $field_key ) {
			return;
		}
		$this->append_record(
			$submission_id,
			$field_key,
			[
				'provider'        => Helper::get_string_value( $context['provider'] ?? '' ),
				'status'          => 'failed',
				'error'           => Helper::get_string_value( $context['error'] ?? '' ),
				'filename'        => Helper::get_string_value( $context['filename'] ?? '' ),
				'local_path'      => Helper::get_string_value( $context['local_path'] ?? '' ),
				'folder'          => Helper::get_string_value( $context['folder'] ?? '' ),
				'container'       => Helper::get_string_value( $context['container'] ?? '' ),
				'attempts'        => 1,
				'last_attempt_at' => time(),
			]
		);
	}

	/**
	 * Build a `success` upload record for the entry metadata bucket.
	 *
	 * @param array<string,mixed> $meta Provider upload meta.
	 * @return array<string,mixed>
	 * @since 2.11.0
	 */
	private function success_record( $meta ) {
		return [
			'provider'      => Helper::get_string_value( $meta['provider'] ?? '' ),
			'status'        => 'success',
			'url'           => Helper::get_string_value( $meta['url'] ?? '' ),
			'shared_url'    => Helper::get_string_value( $meta['shared_url'] ?? '' ),
			// Inline image URL (e.g. Google Drive thumbnail) preferred for
			// signatures/images embedded via smart tags and the entry view.
			'thumbnail_url' => Helper::get_string_value( $meta['thumbnail_url'] ?? '' ),
			'filename'      => Helper::get_string_value( $meta['filename'] ?? '' ),
			'path'          => Helper::get_string_value( $meta['path'] ?? '' ),
			'file_id'       => Helper::get_string_value( $meta['file_id'] ?? '' ),
			// Container reference for providers whose links expire (S3) and
			// must regenerate a presigned URL on view; empty for others.
			'bucket'        => Helper::get_string_value( $meta['bucket'] ?? '' ),
			'region'        => Helper::get_string_value( $meta['region'] ?? '' ),
			'uploaded_at'   => time(),
		];
	}

	/**
	 * Append a record to an entry's `_srfm_cloud_uploads` field bucket.
	 *
	 * @param int                 $submission_id Entry ID.
	 * @param string              $field_key     Submission field key.
	 * @param array<string,mixed> $record        The record to append.
	 * @return void
	 * @since 2.11.0
	 */
	private function append_record( $submission_id, $field_key, $record ) {
		$entry = Entries::get( $submission_id );
		if ( empty( $entry ) ) {
			return;
		}

		$extras = is_array( $entry['extras'] ?? null ) ? $entry['extras'] : [];
		$bucket = is_array( $extras[ self::ENTRY_META_KEY ] ?? null ) ? $extras[ self::ENTRY_META_KEY ] : [];
		$list   = is_array( $bucket[ $field_key ] ?? null ) ? $bucket[ $field_key ] : [];

		$list[]                         = $record;
		$bucket[ $field_key ]           = $list;
		$extras[ self::ENTRY_META_KEY ] = $bucket;

		Entries::update( $submission_id, [ 'extras' => $extras ] );
	}

	/**
	 * Collect all `failed` upload records across an entry's field buckets.
	 *
	 * @param int $entry_id Entry ID.
	 * @return array<int,array<string,mixed>>
	 * @since 2.11.0
	 */
	private function collect_failed_records( $entry_id ) {
		$entry = Entries::get( absint( $entry_id ) );
		if ( empty( $entry ) ) {
			return [];
		}

		$extras = is_array( $entry['extras'] ?? null ) ? $entry['extras'] : [];
		$bucket = is_array( $extras[ self::ENTRY_META_KEY ] ?? null ) ? $extras[ self::ENTRY_META_KEY ] : [];

		$failed = [];
		foreach ( $bucket as $records ) {
			if ( ! is_array( $records ) ) {
				continue;
			}
			foreach ( $records as $record ) {
				if ( is_array( $record ) && 'failed' === ( $record['status'] ?? '' ) ) {
					$failed[] = $record;
				}
			}
		}
		return $failed;
	}

	/**
	 * Delete the local copy of an uploaded file after a successful transfer.
	 *
	 * @param string $file_path Absolute filesystem path.
	 * @return void
	 * @since 2.11.0
	 */
	private function delete_local_file( $file_path ) {
		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return;
		}
		if ( ! function_exists( 'wp_delete_file' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		wp_delete_file( $file_path );
	}

	/**
	 * Build a standard workflow result array.
	 *
	 * @param string $name    Workflow name.
	 * @param bool   $success Whether the workflow succeeded.
	 * @param string $message Result message.
	 * @return array<string,mixed>
	 * @since 2.11.0
	 */
	private function result( $name, $success, $message ) {
		return [
			'workflow_name' => $name,
			'integration'   => self::INTEGRATION,
			'success'       => $success,
			'message'       => $message,
			'response'      => '',
		];
	}
}
