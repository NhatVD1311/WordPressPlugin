<?php
/**
 * File Storage Registry.
 *
 * Central registry of the cloud destinations available to the unified
 * "Third Party File Upload" workflow. Providers register themselves here;
 * the rest of the system asks the registry which providers exist, which are
 * connected, and resolves a provider instance by key.
 *
 * @package SureForms
 * @since 2.11.0
 */

namespace SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage;

use SRFM\Inc\Traits\Get_Instance;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers\Amazon_S3_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers\Dropbox_Provider;
use SRFM_Pro\Inc\Pro\Native_Integrations\File_Storage\Providers\Google_Drive_Provider;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * File storage provider registry (singleton).
 *
 * @since 2.11.0
 */
class File_Storage_Registry {
	use Get_Instance;

	/**
	 * Registered providers keyed by machine key.
	 *
	 * @var array<string,File_Storage_Provider>
	 */
	private $providers = [];

	/**
	 * Register the built-in providers.
	 *
	 * @since 2.11.0
	 */
	public function __construct() {
		$this->register( new Dropbox_Provider() );
		$this->register( new Amazon_S3_Provider() );
		$this->register( new Google_Drive_Provider() );
	}

	/**
	 * Register a provider.
	 *
	 * @param File_Storage_Provider $provider Provider instance.
	 * @return void
	 * @since 2.11.0
	 */
	public function register( File_Storage_Provider $provider ) {
		$this->providers[ $provider->get_key() ] = $provider;
	}

	/**
	 * Resolve a provider by key.
	 *
	 * @param string $key Provider machine key (e.g. `dropbox`).
	 * @return File_Storage_Provider|null
	 * @since 2.11.0
	 */
	public function get( $key ) {
		return $this->providers[ $key ] ?? null;
	}

	/**
	 * Option list of currently-connected providers, for the source dropdown.
	 *
	 * @return array<int,array{value:string,label:string}>
	 * @since 2.11.0
	 */
	public function get_connected_options() {
		$options = [];
		foreach ( $this->providers as $key => $provider ) {
			if ( $provider->is_connected() ) {
				$options[] = [
					'value' => $key,
					'label' => $provider->get_label(),
				];
			}
		}
		return $options;
	}

	/**
	 * Whether at least one file-storage provider is connected.
	 *
	 * Gates the visibility of the "Third Party File Upload" workflow in
	 * single-form settings.
	 *
	 * @return bool
	 * @since 2.11.0
	 */
	public function has_any_connected() {
		foreach ( $this->providers as $provider ) {
			if ( $provider->is_connected() ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Map of every registered provider's key to its current connection state.
	 *
	 * Lets analytics report all providers dynamically — newly registered
	 * providers are included automatically without touching the reporting code.
	 *
	 * @return array<string,bool> Provider key => connected.
	 * @since 2.10.0
	 */
	public function get_connection_states() {
		$states = [];
		foreach ( $this->providers as $key => $provider ) {
			$states[ $key ] = $provider->is_connected();
		}
		return $states;
	}
}
