<?php
/**
 * SureContact Integration - Script Enqueue.
 *
 * Handles enqueuing the SureContact integration JS for the admin.
 *
 * @package SureForms Pro
 * @since 2.5.1
 */

namespace SRFM_Pro\Inc\Pro;

use SRFM_Pro\Inc\Helper as Pro_Helper;
use SRFM_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SureContact Integration Class
 *
 * @since 2.5.1
 */
class Surecontact_Integration {
	use Get_Instance;

	/**
	 * Constructor
	 *
	 * @since 2.5.1
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Enqueue scripts for SureContact integration.
	 *
	 * @since 2.5.1
	 * @return void
	 */
	public function enqueue_assets() {
		$scripts = [
			[
				'unique_file'        => 'surecontactIntegration',
				'unique_handle'      => 'surecontactIntegration',
				'extra_dependencies' => [],
			],
		];

		foreach ( $scripts as $script ) {
			$script_dep_path = SRFM_PRO_DIR . 'dist/package/pro/' . $script['unique_file'] . '.asset.php';
			$script_dep_data = file_exists( $script_dep_path )
				? include $script_dep_path
				: [
					'dependencies' => [],
					'version'      => SRFM_PRO_VER,
				];
			$script_dep      = array_merge( $script_dep_data['dependencies'], $script['extra_dependencies'] );

			wp_enqueue_script(
				SRFM_PRO_SLUG . '-' . $script['unique_handle'],
				SRFM_PRO_URL . 'dist/package/pro/' . $script['unique_file'] . '.js',
				$script_dep,
				$script_dep_data['version'],
				true
			);

			Pro_Helper::register_script_translations( SRFM_PRO_SLUG . '-' . $script['unique_handle'] );
		}
	}
}
