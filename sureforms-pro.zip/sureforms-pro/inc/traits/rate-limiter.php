<?php
/**
 * Shared rate-limiting helpers for public routes.
 *
 * @since 2.12.3
 * @package sureforms-pro
 */

namespace SRFM_Pro\Inc\Traits;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Rate_Limiter trait.
 *
 * Extracted so the save-resume and partial-entries limiters cannot drift apart again.
 * The save-resume route originally reimplemented this and lost three properties the
 * partial-entries version already had: atomicity, IP validation, and failing open when the
 * client cannot be identified.
 *
 * @since 2.12.3
 */
trait Rate_Limiter {
	/**
	 * Count a hit against a bucket and report whether the limit is exceeded.
	 *
	 * Atomic where a persistent object cache is available. `get_transient()` followed by
	 * `set_transient()` is read-then-write: a parallel burst all reads the same count and
	 * all passes, which makes a limiter that looks correct in sequence useless against the
	 * concurrency an abuser actually generates. `wp_cache_incr()` closes that window; the
	 * transient path remains as a fallback for hosts with no object cache, where the
	 * window is accepted rather than pretended away.
	 *
	 * @param string $bucket  Fully-qualified cache/transient key for this bucket.
	 * @param int    $max     Maximum hits allowed in the window.
	 * @param int    $window  Window length in seconds.
	 * @param string $group   Object-cache group.
	 * @param string $code    WP_Error code to return when the limit is exceeded.
	 * @param string $message Human-readable message for the error.
	 * @since 2.12.3
	 * @return WP_Error|true WP_Error when the limit is exceeded, true otherwise.
	 */
	protected function count_against_limit( $bucket, $max, $window, $group, $code, $message ) {
		if ( wp_using_ext_object_cache() ) {
			$count = wp_cache_incr( $bucket, 1, $group );

			if ( false === $count || 1 === (int) $count ) {
				// First hit in this window. wp_cache_incr() cannot set a TTL, so seed it
				// with add() — which is a no-op if another request won the race.
				wp_cache_add( $bucket, 1, $group, $window );
				$count = 1;
			}

			if ( (int) $count > $max ) {
				return new WP_Error( $code, $message, [ 'status' => 429 ] );
			}

			return true;
		}

		$raw_count = get_transient( $bucket );
		$count     = is_numeric( $raw_count ) ? (int) $raw_count : 0;

		if ( $count >= $max ) {
			return new WP_Error( $code, $message, [ 'status' => 429 ] );
		}

		set_transient( $bucket, $count + 1, $window );

		return true;
	}

	/**
	 * Best-effort client IP, validated.
	 *
	 * Returns '' when no valid IP can be determined, and callers must then fail OPEN. A
	 * raw `REMOTE_ADDR` is not usable as a bucket key: `md5('')` is the same key for every
	 * request that lacks one (WP-CLI, some FastCGI/socket configurations), and behind a
	 * CDN that does not rewrite `REMOTE_ADDR` every visitor shares one bucket — which
	 * turns a rate limit into a denial-of-service against the feature, holdable at zero
	 * from a single host.
	 *
	 * `X-Forwarded-For` is NOT trusted by default; a client can set it freely and would
	 * otherwise spoof past the limit. Sites behind a proxy that overwrites it opt in.
	 *
	 * @param string $proxy_filter Filter name used to name a trusted proxy header.
	 * @since 2.12.3
	 * @return string Validated IP, or '' when it cannot be determined.
	 */
	protected function get_limiter_client_ip( $proxy_filter ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- validated via filter_var below.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- variable hook name; callers pass an srfm_-prefixed filter.
		$proxy_header = (string) apply_filters( $proxy_filter, '' );

		if ( '' !== $proxy_header && ! empty( $_SERVER[ $proxy_header ] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- validated via filter_var below.
			$forwarded = sanitize_text_field( wp_unslash( (string) $_SERVER[ $proxy_header ] ) );
			$parts     = explode( ',', $forwarded );
			$ip        = trim( (string) $parts[0] );
		}

		$ip = filter_var( $ip, FILTER_VALIDATE_IP );

		return is_string( $ip ) ? $ip : '';
	}
}
