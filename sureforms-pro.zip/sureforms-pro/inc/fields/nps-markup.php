<?php
/**
 * NPS Markup Class file.
 *
 * @package sureforms-pro.
 * @since 2.8.0
 */

namespace SRFM_Pro\Inc\Fields;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * NPS Markup Class.
 *
 * @since 2.8.0
 */
class Nps_Markup extends Base {
	/**
	 * Low label text (0-6 range).
	 *
	 * @var string
	 * @since 2.8.0
	 */
	protected $low_label;

	/**
	 * High label text (9-10 range).
	 *
	 * @var string
	 * @since 2.8.0
	 */
	protected $high_label;

	/**
	 * Initialize the properties based on block attributes.
	 *
	 * @param array<mixed> $attributes Block attributes.
	 * @since 2.8.0
	 */
	public function __construct( $attributes ) {
		$this->set_properties( $attributes );
		$this->set_error_msg( 'srfm_nps_block_required_text', $attributes );
		$this->set_input_label( __( 'NPS', 'sureforms-pro' ) );
		$this->help       = $attributes['help'] ?? '';
		$this->low_label  = $attributes['lowLabel'] ?? __( 'Not Likely', 'sureforms-pro' );
		$this->high_label = $attributes['highLabel'] ?? __( 'Extremely likely', 'sureforms-pro' );
		$this->slug       = 'nps';
		$this->set_markup_properties();
		$this->set_aria_described_by();
	}

	/**
	 * Render HTML markup of the NPS block.
	 *
	 * @since 2.8.0
	 * @return string|bool
	 */
	public function markup() {
		$input_id   = "srfm-nps-{$this->block_id}";
		$input_name = "{$input_id}{$this->field_name}";

		$wrapper_class = "srfm-block-single srfm-block srfm-nps-block srfm-nps-{$this->block_id}-block{$this->block_width}{$this->classname} {$this->conditional_class}";

		ob_start(); ?>
		<div data-block-id="<?php echo esc_attr( $this->block_id ); ?>" class="<?php echo esc_attr( $wrapper_class ); ?>">
			<?php echo wp_kses_post( $this->label_markup ); ?>
			<?php echo wp_kses_post( $this->help_markup ); ?>
			<div class="srfm-block-wrap">
				<input
					id="<?php echo esc_attr( $input_id ); ?>"
					type="hidden"
					class="srfm-input-common srfm-input-nps"
					name="<?php echo esc_attr( $input_name ); ?>"
					data-required="<?php echo esc_attr( $this->data_require_attr ); ?>"
					value=""
				/>
				<div class="srfm-nps-buttons" role="radiogroup" aria-label="<?php echo esc_attr( $this->label ); ?>">
					<?php
					for ( $i = 0; $i <= 10; $i++ ) {
						$zone_class = 'srfm-nps-detractor';
						if ( $i >= 7 && $i <= 8 ) {
							$zone_class = 'srfm-nps-passive';
						} elseif ( $i >= 9 ) {
							$zone_class = 'srfm-nps-promoter';
						}
						?>
						<button
							type="button"
							class="srfm-nps-btn <?php echo esc_attr( $zone_class ); ?>"
							role="radio"
							tabindex="<?php echo 0 === $i ? '0' : '-1'; ?>"
							aria-checked="false"
							aria-label="<?php echo esc_attr( strval( $i ) ); ?>"
							data-value="<?php echo esc_attr( strval( $i ) ); ?>"
							<?php if ( 0 === $i ) { ?>
								aria-required="<?php echo esc_attr( $this->data_require_attr ); ?>"
								aria-describedby="srfm-label-<?php echo esc_attr( $this->block_id ); ?><?php echo ! empty( $this->aria_described_by ) ? ' ' . esc_attr( trim( $this->aria_described_by ) ) : ''; ?>"
							<?php } ?>
						><?php echo esc_html( strval( $i ) ); ?></button>
					<?php } ?>
				</div>
				<div class="srfm-nps-labels">
					<span class="srfm-nps-label-low"><?php echo esc_html( $this->low_label ); ?></span>
					<span class="srfm-nps-label-high"><?php echo esc_html( $this->high_label ); ?></span>
				</div>
			</div>
			<div class="srfm-error-wrap">
				<?php echo wp_kses_post( $this->error_msg_markup ); ?>
			</div>
		</div>
		<?php
		$markup = ob_get_clean();

		return apply_filters(
			'srfm_block_field_markup',
			$markup,
			[
				'slug'       => $this->slug,
				'field_name' => $this->field_name,
				'is_editing' => $this->is_editing,
				'attributes' => $this->attributes,
			]
		);
	}
}
