<?php
namespace Jet_Elements\Endpoints;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Clear_Cache extends Base {

	public function get_name() {
		return 'clear-cache';
	}

	public function get_method() {
		return 'POST';
	}

	public function permission_callback( $request ) {
		$nonce = $request->get_header( 'X-Jet-Elements-Cache-Nonce' );

		return current_user_can( 'manage_options' )
			&& is_string( $nonce )
			&& (bool) wp_verify_nonce( $nonce, 'jet-elements-clear-cache' );
	}

	public function callback( $request ) {
		if ( ! \Jet_Elements_Cache::clear() ) {
			return new \WP_Error(
				'jet_elements_cache_error',
				__( 'Unable to clear JetElements cache.', 'jet-elements' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response( array( 'status' => 'success' ) );
	}
}
