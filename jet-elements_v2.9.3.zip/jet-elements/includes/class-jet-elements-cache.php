<?php
/** JetElements content cache invalidation. */
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Jet_Elements_Cache {

	const GENERATION_OPTION = 'jet_elements_cache_generation';

	private static $generation = null;

	/**
	 * Use a request-stable generation for transients and persistent object caches.
	 * Old entries expire naturally; no shared or unidentifiable legacy keys are deleted.
	 */
	public static function key( $key ) {
		if ( null === self::$generation ) {
			self::$generation = get_option( self::GENERATION_OPTION, 'initial' );
		}

		return 'jet-elements-' . md5( self::$generation . ':' . $key );
	}

	/** Invalidate content caches without flushing other plugins' data. */
	public static function clear() {
		$status = \Jet_Cache\Manager::get_instance()->db_manager->delete_cache_by_source( 'jet-elements' );

		// Zero affected rows means the cache was already empty.
		if ( false === $status ) {
			return false;
		}

		$generation = wp_generate_uuid4();
		if ( ! update_option( self::GENERATION_OPTION, $generation, false ) ) {
			return false;
		}

		self::$generation = $generation;
		return true;
	}
}
