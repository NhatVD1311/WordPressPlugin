<!-- template="page" -->
<form>
  <table width="99%" style="display: none">
    <tbody id="mla-thumbnail-generation">
      <tr id="mla-bulk-thumbnail" class="inline-edit-row inline-edit-row-attachment inline-edit-attachment bulk-thumbnail-row bulk-thumbnail-row-attachment bulk-thumbnail-attachment" style="display: none">
        <td colspan="[+colspan+]" class="colspanchange">
          <fieldset class="inline-edit-col-left">
            <div class="inline-edit-col">
              <h4>[+Generate Thumbnails+]</h4>
              <div id="mla-thumbnail-title-div">
                <div id="mla-thumbnail-titles"></div>
              </div>
            </div>
          </fieldset>
          <fieldset id="mla-thumbnail-settings" class="inline-edit-col-right">
            <div class="inline-edit-col">
            <h4>([+See Documentation+])</h4>
            <div class="inline-edit-group clear">
			<table><tr>
              <td><label> <span class="title">[+Width+]</span>
                <input name="mla_thumbnail_options[width]" id="mla-thumbnail-options-width" type="text" size="5" value="" />
              </label></td>
              <td><label> <span class="title">[+Height+]</span>
                <input name="mla_thumbnail_options[height]" id="mla-thumbnail-options-height" type="text" size="5" value="" />
              </label></td>
              <td class="textleft"><label>
                <input name="mla_thumbnail_options[best_fit]" id="mla-thumbnail-options-best-fit" type="checkbox" value="checked" />
                [+Best Fit+]
              </label></td>
			  </tr><tr>
              <td><label class="alignleft"> <span class="title">[+Page+]</span>
                <input name="mla_thumbnail_options[page]" id="mla-thumbnail-options-page" type="text" size="5" value="" />
              </label></td>
              <td><label> <span class="title">[+Resolution+]</span>
                <input name="mla_thumbnail_options[resolution]" id="mla-thumbnail-options-resolution" type="text" size="5" value="" />
              </label></td>
              <td><label> <span class="title">[+Quality+]</span>
                <input name="mla_thumbnail_options[quality]" id="mla-thumbnail-options-quality" type="text" size="5" value="" />
              </label></td>
			  </tr><tr>
              <td><label>
            <span class="title">[+Type+]</span>
            <span [+WP Style+]> <input type="radio" name="mla_thumbnail_options[type]" id="mla-thumbnail-options-jpg" [+WP Checked+] value="WordPress" />
            WP&nbsp;&nbsp;</span>
            <input type="radio" name="mla_thumbnail_options[type]" id="mla-thumbnail-options-jpg" [+JPG Checked+] value="image/jpeg" />
            JPG&nbsp;&nbsp;
            <input type="radio" name="mla_thumbnail_options[type]" id="mla-thumbnail-options-png" value="image/png" />
            PNG&nbsp;&nbsp;
            <input type="radio" name="mla_thumbnail_options[type]" id="mla-thumbnail-options-none" value="None" />
            [+None+]&nbsp;&nbsp;
			        </label></td>
              <td colspan=2>&nbsp;<label> <span class="title">[+Suffix+]</span>
                <input name="mla_thumbnail_options[suffix]" id="mla-thumbnail-options-suffix" type="text" size="15" value="[+default_suffix+]" />
              </label></td>
			  </tr><tr>
              <td><label class="alignleft"> <span class="title">[+Existing Features+]</span>
            <select name="mla_thumbnail_options[existing_features]" id="mla-thumbnail-options-existing-features">
                <option selected="selected" value="keep">[+Keep+]</option>
                <option value="ignore">[+Ignore+]</option>
                <option value="remove">[+Remove+]</option>
                <option [+Trash Style+] value="trash">[+Trash+]</option>
                <option value="delete">[+Delete+]</option>
            </select>
              </label></td>
              <td colspan=2>&nbsp;<label class="alignleft"> <span class="title">[+Existing Thumbnails+]</span>
            <select name="mla_thumbnail_options[existing_thumbnails]" id="mla-thumbnail-options-existing-thumbnails">
                <option selected="selected" value="keep">[+Keep+]</option>
                <option value="ignore">[+Ignore+]</option>
                <option value="delete">[+Delete+]</option>
            </select>
              </label></td>
			  </tr></table>
			  <p>&nbsp;&nbsp;[+WP Help+]</p>
            </div> <!-- inline-edit-group -->
            </div> <!-- inline-edit-col -->
          </fieldset>
          <p class="submit inline-edit-save"> <a accesskey="c" href="#mla-generate-thumbnail" title="[+Cancel+]" class="button-secondary cancel alignleft">[+Cancel+]</a>
            <input type="submit" name="mla-generate-thumbnail" id="mla-generate-thumbnail-submit" class="button-primary alignright" value="[+Generate Thumbnails+]" />
            <input type="hidden" name="page" value="mla-menu" />
            <input type="hidden" name="screen" value="media_page_mla-menu" />
            <span class="error" style="display:none;"></span> <br class="clear" />
          </p>
        </td>
      </tr>
    </tbody>
  </table>
</form>
