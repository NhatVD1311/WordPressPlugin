/* eslint-disable no-mixed-operators */

/**
 * Small UI building blocks for structured content editors in the builders,
 * first used by the Table element: a dropdown menu in the look of the
 * builder's "more options" menu, and a floating toolbar for the Live Editor
 * preview in the look of the inline editor's toolbar.
 *
 * Neither knows anything about tables, so the same pieces can drive editors
 * for other structured content later (tabs, toggles, lists).
 *
 * @since 1.0
 */
window.AWBEditorUI = ( function() {
	'use strict';

	/**
	 * Escapes text for markup.
	 *
	 * @param {string} value - The text.
	 * @return {string}
	 */
	function esc( value ) {
		return String( value ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
	}

	/**
	 * A dropdown menu.
	 *
	 * Items: { action, label, icon, disabled, checked } for entries,
	 * 'separator' for a divider and { html } for custom rows (form fields).
	 *
	 * @param {Element}  container - Element the menu is placed in (positioned).
	 * @param {Function} onAction  - Called with ( action, button, event ).
	 */
	function Menu( container, onAction ) {
		var self = this;

		this.container = container;
		this.onAction  = onAction;
		this.owner     = null;
		this.el        = container.ownerDocument.createElement( 'div' );

		this.el.className = 'awb-editor-menu';
		this.el.setAttribute( 'role', 'menu' );
		this.el.hidden = true;
		container.appendChild( this.el );

		this.el.addEventListener( 'click', function( event ) {
			var item = event.target.closest( '[data-action]' );

			if ( item && ! item.disabled && ! item.classList.contains( 'is-disabled' ) ) {
				self.onAction( item.getAttribute( 'data-action' ), item, event );
			}
		} );

		this.el.addEventListener( 'keydown', function( event ) {
			var items = Array.prototype.slice.call( self.el.querySelectorAll( '[data-action]:not([disabled]), input' ) ),
				index = items.indexOf( container.ownerDocument.activeElement );

			event.stopPropagation();

			if ( 'Escape' === event.key ) {
				event.preventDefault();
				self.close( true );
			} else if ( ( 'ArrowDown' === event.key || 'ArrowUp' === event.key ) && 'INPUT' !== event.target.tagName && items.length ) {
				event.preventDefault();
				items[ ( index + ( 'ArrowDown' === event.key ? 1 : -1 ) + items.length ) % items.length ].focus();
			}
		} );

		this.onOutside = function( event ) {
			if ( ! self.el.hidden && ! self.el.contains( event.target ) && ( ! self.owner || ! self.owner.contains( event.target ) ) ) {
				self.close();
			}
		};
		container.ownerDocument.addEventListener( 'mousedown', this.onOutside, true );
	}

	Menu.prototype = {

		/**
		 * Markup for the items.
		 *
		 * @param {Array} items - The items.
		 * @return {string}
		 */
		itemsHtml: function( items ) {
			var html = '<ul class="awb-editor-menu-items">';

			items.forEach( function( item ) {
				if ( 'separator' === item ) {
					html += '</ul><div class="awb-editor-menu-separator" role="separator"></div><ul class="awb-editor-menu-items">';
				} else if ( item.html ) {
					html += '<li class="awb-editor-menu-custom">' + item.html + '</li>';
				} else {
					html += '<li class="awb-editor-menu-item' + ( item.danger ? ' is-danger' : '' ) + '">' +
						'<button type="button" data-action="' + esc( item.action ) + '" role="' + ( 'undefined' === typeof item.checked ? 'menuitem' : 'menuitemcheckbox' ) + '"' +
							( 'undefined' === typeof item.checked ? '' : ' aria-checked="' + ( item.checked ? 'true' : 'false' ) + '"' ) +
							( item.disabled ? ' disabled' : '' ) + '>' +
							'<span class="' + esc( item.icon || '' ) + '" aria-hidden="true"></span>' + esc( item.label ) +
							( item.checked ? '<span class="fusiona-check awb-editor-menu-check" aria-hidden="true"></span>' : '' ) +
						'</button>' +
					'</li>';
				}
			} );

			return html + '</ul>';
		},

		/**
		 * Opens the menu under an element or at a point.
		 *
		 * @param {Array}   items - The items.
		 * @param {Element} owner - Element to open under, or null.
		 * @param {number}  x     - Client x when there is no owner.
		 * @param {number}  y     - Client y when there is no owner.
		 * @return {void}
		 */
		open: function( items, owner, x, y ) {
			var box = this.container.getBoundingClientRect(),
				rect,
				left,
				first;

			this.close();

			this.el.innerHTML = this.itemsHtml( items );
			this.el.hidden    = false;
			this.owner        = owner || null;

			if ( owner ) {
				rect = owner.getBoundingClientRect();
				x    = rect.left;
				y    = rect.bottom + 4;
				owner.setAttribute( 'aria-expanded', 'true' );
			}

			left = Math.max( 0, Math.min( x - box.left, this.container.clientWidth - this.el.offsetWidth ) );

			this.el.style.left = left + 'px';
			this.el.style.top  = ( y - box.top + this.container.scrollTop ) + 'px';

			first = this.el.querySelector( '[data-action]:not([disabled])' );
			if ( first ) {
				first.focus( { preventScroll: true } );
			}
		},

		/**
		 * Whether the menu is open.
		 *
		 * @return {boolean}
		 */
		isOpen: function() {
			return ! this.el.hidden;
		},

		/**
		 * Closes the menu.
		 *
		 * @param {boolean} refocus - Whether to move focus back to the owner.
		 * @return {void}
		 */
		close: function( refocus ) {
			if ( this.el.hidden ) {
				return;
			}

			if ( this.owner ) {
				this.owner.setAttribute( 'aria-expanded', 'false' );

				if ( refocus ) {
					this.owner.focus();
				}
			}

			this.el.hidden    = true;
			this.el.innerHTML = '';
			this.owner        = null;
		},

		destroy: function() {
			this.container.ownerDocument.removeEventListener( 'mousedown', this.onOutside, true );
			this.el.remove();
		}
	};

	/**
	 * A floating toolbar in the Live Editor preview, styled like the inline
	 * editor's toolbar (dark buttons with tooltips).
	 *
	 * @param {Element}  host      - Positioned element the toolbar is placed in.
	 * @param {Array}    buttons   - [ { command, icon, label } ].
	 * @param {Function} onCommand - Called with the command name.
	 */
	function CanvasToolbar( host, buttons, onCommand ) {
		var doc  = host.ownerDocument,
			html = '<ul>';

		buttons.forEach( function( button ) {
			html += '<li data-command="' + esc( button.command ) + '" role="button" tabindex="-1" aria-label="' + esc( button.label ) + '">' +
				'<span class="' + esc( button.icon ) + '" aria-hidden="true"></span>' +
				'<span class="fusion-element-tooltip"><span class="fusion-tooltip-text">' + esc( button.label ) + '</span></span>' +
			'</li>';
		} );

		this.host = host;
		this.el   = doc.createElement( 'div' );

		this.el.className = 'fusion-builder-context-menu fusion-builder-inline-context-menu fusion-builder-inline-context-menu-loaded awb-canvas-toolbar';
		this.el.innerHTML = html + '</ul>';
		host.appendChild( this.el );

		// Keep focus, text selection and element dragging out of it.
		this.el.addEventListener( 'mousedown', function( event ) {
			event.preventDefault();
			event.stopPropagation();
		} );

		this.el.addEventListener( 'click', function( event ) {
			var item = event.target.closest( '[data-command]' );

			event.preventDefault();
			event.stopPropagation();

			if ( item && ! item.classList.contains( 'is-disabled' ) ) {
				onCommand( item.getAttribute( 'data-command' ) );
			}
		} );
	}

	CanvasToolbar.prototype = {

		/**
		 * Enables or disables a button.
		 *
		 * @param {string}  command - The command.
		 * @param {boolean} state   - Whether it is enabled.
		 * @return {void}
		 */
		setEnabled: function( command, state ) {
			var item = this.el.querySelector( '[data-command="' + command + '"]' );

			if ( item ) {
				item.classList.toggle( 'is-disabled', ! state );
				item.setAttribute( 'aria-disabled', state ? 'false' : 'true' );
			}
		},

		/**
		 * Places the toolbar above a rectangle (client coordinates of the same document).
		 *
		 * @param {DOMRect} rect - Usually the selected cell.
		 * @return {void}
		 */
		placeAbove: function( rect ) {
			var host = this.host.getBoundingClientRect();

			// It may rise above the host, but not out of the window.
			this.el.style.top  = Math.max( -host.top, rect.top - host.top - this.el.offsetHeight - 8 ) + 'px';
			this.el.style.left = Math.max( 0, Math.min( rect.left - host.left, host.width - this.el.offsetWidth ) ) + 'px';
		},

		remove: function() {
			this.el.remove();
		}
	};

	return {
		Menu: Menu,
		CanvasToolbar: CanvasToolbar,
		esc: esc
	};
}() );
