/* global AWBTable */
/* eslint-disable no-mixed-operators */

/**
 * Table model shared by the table editor (settings panel), the on-canvas
 * table editing in the Live Editor and the Live Editor preview.
 *
 * The saved format stays plain table markup inside the element content:
 *
 * <div><table>
 *   <caption>…</caption>
 *   <colgroup><col data-align="center" data-hide="small" data-highlight="1" data-filter="1" style="width:20%"></colgroup>
 *   <thead>…</thead><tbody>…</tbody><tfoot>…</tfoot>
 * </table></div>
 *
 * Column settings live on the col elements, so they travel with the column
 * when it is inserted, moved or deleted.
 *
 * Internally a table is a grid of slots. A merged cell occupies several
 * slots that all hold the same cell object, so spans never need to be
 * bookkept separately and every structural operation stays simple.
 *
 * @since 1.0
 */
window.AWBTable = ( function() {
	'use strict';

	var SECTION_HEAD = 'head',
		SECTION_BODY = 'body',
		SECTION_FOOT = 'foot',
		HIDE_VALUES  = [ 'small', 'medium', 'large' ];

	/**
	 * Creates a cell.
	 *
	 * @param {string} tag  - Either th or td.
	 * @param {string} html - The cell content.
	 * @param {Object} attrs - Extra attributes to keep.
	 * @return {Object}
	 */
	function createCell( tag, html, attrs ) {
		return {
			tag: 'th' === tag ? 'th' : 'td',
			html: 'string' === typeof html ? html : '',
			attrs: attrs || {}
		};
	}

	/**
	 * Creates a column definition.
	 *
	 * @return {Object}
	 */
	function createColumn() {
		return {
			align: '',
			width: '',
			hide: [],
			highlight: false,
			filter: false,
			attrs: {}
		};
	}

	/**
	 * Collects the attributes of an element, minus the ones we manage.
	 *
	 * @param {Element} el      - The element.
	 * @param {Array}   exclude - Attribute names to skip.
	 * @return {Object}
	 */
	function getAttrs( el, exclude ) {
		var attrs = {},
			i;

		exclude = exclude || [];

		for ( i = 0; i < el.attributes.length; i++ ) {
			if ( -1 === exclude.indexOf( el.attributes[ i ].name ) ) {
				attrs[ el.attributes[ i ].name ] = el.attributes[ i ].value;
			}
		}

		return attrs;
	}

	/**
	 * Escapes an attribute value.
	 *
	 * @param {string} value - The value.
	 * @return {string}
	 */
	function escAttr( value ) {
		return String( value ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
	}

	/**
	 * Escapes text content.
	 *
	 * @param {string} value - The value.
	 * @return {string}
	 */
	function escHtml( value ) {
		return String( value ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
	}

	/**
	 * Builds an attribute string.
	 *
	 * @param {Object} attrs - The attributes.
	 * @return {string}
	 */
	function attrString( attrs ) {
		var out = '';

		Object.keys( attrs ).forEach( function( name ) {
			if ( null === attrs[ name ] || 'undefined' === typeof attrs[ name ] ) {
				return;
			}
			out += ' ' + name + ( '' === attrs[ name ] ? '' : '="' + escAttr( attrs[ name ] ) + '"' );
		} );

		return out;
	}

	/**
	 * Undoes the &amp; the browser adds to ampersands inside shortcode attributes when serializing.
	 *
	 * @param {string} html - Serialized markup.
	 * @return {string}
	 */
	function restoreShortcodes( html ) {
		return html.replace( /\[[^\[\]]*\]/g, function( shortcode ) {
			return shortcode.replace( /&amp;/g, '&' );
		} );
	}

	/**
	 * Parses markup into a detached element tree.
	 *
	 * @param {string} html - The markup.
	 * @return {DocumentFragment}
	 */
	function toFragment( html ) {
		var template = document.createElement( 'template' );

		template.innerHTML = html;

		return template.content;
	}

	/**
	 * Gets the direct child elements matching tag names.
	 *
	 * @param {Element} el   - The parent.
	 * @param {Array}   tags - Lowercase tag names.
	 * @return {Array}
	 */
	function childrenByTag( el, tags ) {
		return Array.prototype.filter.call( el.children, function( child ) {
			return -1 !== tags.indexOf( child.tagName.toLowerCase() );
		} );
	}

	/**
	 * Maps the cells of table rows to grid positions, honouring colspan and rowspan.
	 *
	 * Spans never leave their section (thead/tbody/tfoot), as in the HTML spec.
	 *
	 * @param {Array} sections - [ { section: 'head', rows: [ tr, … ] }, … ].
	 * @return {Object} { rows: [ { tr, section, cells: [ { el, row, col, rowspan, colspan } ] } ], columns }
	 */
	function mapGrid( sections ) {
		var out     = { rows: [], columns: 0 },
			rowBase = 0;

		sections.forEach( function( group ) {
			var occupied = [],
				count    = group.rows.length;

			group.rows.forEach( function( tr, localRow ) {
				var row   = { tr: tr, section: group.section, cells: [] },
					col   = 0;

				occupied[ localRow ] = occupied[ localRow ] || [];

				childrenByTag( tr, [ 'th', 'td' ] ).forEach( function( el ) {
					var colspan = Math.max( 1, Math.min( 1000, parseInt( el.getAttribute( 'colspan' ), 10 ) || 1 ) ),
						rowspan = parseInt( el.getAttribute( 'rowspan' ), 10 ),
						r, c;

					// rowspan="0" spans to the end of the section.
					rowspan = 0 === rowspan ? count - localRow : Math.max( 1, rowspan || 1 );
					rowspan = Math.min( rowspan, count - localRow );

					while ( occupied[ localRow ][ col ] ) {
						col++;
					}

					for ( r = localRow; r < localRow + rowspan; r++ ) {
						occupied[ r ] = occupied[ r ] || [];
						for ( c = col; c < col + colspan; c++ ) {
							occupied[ r ][ c ] = true;
						}
					}

					row.cells.push( { el: el, row: rowBase + localRow, col: col, rowspan: rowspan, colspan: colspan } );
					col += colspan;
					out.columns = Math.max( out.columns, col );
				} );

				out.columns = Math.max( out.columns, occupied[ localRow ].length );
				out.rows.push( row );
			} );

			rowBase += count;
		} );

		return out;
	}

	/**
	 * Finds the table and its wrapper in content.
	 *
	 * @param {DocumentFragment} fragment - The parsed content.
	 * @return {Object|false} { wrapper, table }
	 */
	function findTable( fragment ) {
		var first = fragment.firstElementChild,
			table = fragment.querySelector( 'table' );

		if ( ! table ) {
			return false;
		}

		return {
			wrapper: first && 'DIV' === first.tagName && first.contains( table ) ? first : null,
			table: table
		};
	}

	/**
	 * Groups the rows of a table element by section.
	 *
	 * @param {Element} table - The table.
	 * @return {Array}
	 */
	function getSections( table ) {
		var head = [],
			body = [],
			foot = [];

		Array.prototype.forEach.call( table.children, function( child ) {
			var tag = child.tagName.toLowerCase();

			if ( 'thead' === tag ) {
				head = head.concat( childrenByTag( child, [ 'tr' ] ) );
			} else if ( 'tfoot' === tag ) {
				foot = foot.concat( childrenByTag( child, [ 'tr' ] ) );
			} else if ( 'tbody' === tag ) {
				body = body.concat( childrenByTag( child, [ 'tr' ] ) );
			} else if ( 'tr' === tag ) {
				body.push( child );
			}
		} );

		return [
			{ section: SECTION_HEAD, rows: head },
			{ section: SECTION_BODY, rows: body },
			{ section: SECTION_FOOT, rows: foot }
		];
	}

	/**
	 * Reads the column definitions from colgroup/col elements.
	 *
	 * @param {Element} table - The table.
	 * @return {Array}
	 */
	function readColumns( table ) {
		var columns = [];

		childrenByTag( table, [ 'colgroup' ] ).forEach( function( colgroup ) {
			var cols = childrenByTag( colgroup, [ 'col' ] );

			if ( ! cols.length ) {
				return;
			}

			cols.forEach( function( col ) {
				var span   = Math.max( 1, parseInt( col.getAttribute( 'span' ), 10 ) || 1 ),
					width  = col.style.width || ( col.getAttribute( 'width' ) || '' ),
					i, def;

				for ( i = 0; i < span; i++ ) {
					def           = createColumn();
					def.align     = col.getAttribute( 'data-align' ) || '';
					def.width     = width;
					def.hide      = ( col.getAttribute( 'data-hide' ) || '' ).split( ',' ).filter( function( item ) {
						return -1 !== HIDE_VALUES.indexOf( item );
					} );
					def.highlight = '1' === col.getAttribute( 'data-highlight' );
					def.filter    = '1' === col.getAttribute( 'data-filter' );
					def.attrs     = getAttrs( col, [ 'span', 'width', 'data-align', 'data-hide', 'data-highlight', 'data-filter', 'style' ] );
					columns.push( def );
				}
			} );
		} );

		return columns;
	}

	/**
	 * The table model.
	 *
	 * @param {string} html - Optional markup to load.
	 */
	function Table( html ) {
		this.rows         = [];
		this.columns      = [];
		this.headRows     = 0;
		this.footRows     = 0;
		this.caption      = '';
		this.attrs        = {};
		this.wrapperAttrs = {};
		this.valid        = true;

		if ( 'string' === typeof html ) {
			this.load( html );
		}
	}

	Table.prototype = {

		/**
		 * Loads markup into the model.
		 *
		 * @param {string} html - The markup.
		 * @return {boolean} Whether a table was found.
		 */
		load: function( html ) {
			var self     = this,
				found    = findTable( toFragment( html || '' ) ),
				sections,
				grid,
				caption;

			this.rows     = [];
			this.columns  = [];
			this.headRows = 0;
			this.footRows = 0;
			this.caption  = '';

			if ( ! found ) {
				this.valid = false;
				return false;
			}

			this.valid = true;

			if ( found.wrapper ) {
				this.wrapperAttrs = getAttrs( found.wrapper );
			}

			this.attrs = getAttrs( found.table );

			caption = childrenByTag( found.table, [ 'caption' ] )[ 0 ];
			this.caption = caption ? restoreShortcodes( caption.innerHTML.trim() ) : '';

			sections      = getSections( found.table );
			grid          = mapGrid( sections );
			this.headRows = sections[ 0 ].rows.length;
			this.footRows = sections[ 2 ].rows.length;
			this.columns  = readColumns( found.table );

			grid.rows.forEach( function() {
				self.rows.push( { attrs: {}, slots: [] } );
			} );

			grid.rows.forEach( function( row, r ) {
				self.rows[ r ].attrs = getAttrs( row.tr );

				row.cells.forEach( function( info ) {
					var cell = createCell( info.el.tagName.toLowerCase(), restoreShortcodes( info.el.innerHTML ), getAttrs( info.el, [ 'colspan', 'rowspan', 'scope' ] ) ),
						i, j;

					for ( i = info.row; i < info.row + info.rowspan; i++ ) {
						for ( j = info.col; j < info.col + info.colspan; j++ ) {
							self.rows[ i ].slots[ j ] = cell;
						}
					}
				} );
			} );

			this.fill( grid.columns );
			this.migrateAlignAttributes();

			return true;
		},

		/**
		 * Makes the grid rectangular and the column list as wide as the grid.
		 *
		 * @param {number} columns - Minimum column count.
		 * @return {void}
		 */
		fill: function( columns ) {
			var self = this,
				max  = columns || 0;

			this.rows.forEach( function( row ) {
				max = Math.max( max, row.slots.length );
			} );

			this.rows.forEach( function( row, r ) {
				var c;

				for ( c = 0; c < max; c++ ) {
					if ( ! row.slots[ c ] ) {
						row.slots[ c ] = createCell( self.getSection( r ) === SECTION_HEAD ? 'th' : 'td', '' );
					}
				}
			} );

			while ( this.columns.length < max ) {
				this.columns.push( createColumn() );
			}

			// A colgroup wider than the table has nothing to describe.
			if ( this.rows.length ) {
				this.columns.length = max;
			}
		},

		/**
		 * Moves the legacy align="…" cell attributes to the column, where possible.
		 *
		 * The old generator put align="left" on every cell, which also defeated
		 * right to left layouts, so a plain "left" is simply dropped.
		 *
		 * @return {void}
		 */
		migrateAlignAttributes: function() {
			var self = this;

			this.columns.forEach( function( column, c ) {
				var values = [];

				self.eachAnchor( function( cell, r, cc ) {
					if ( cc === c && 1 === self.getSpan( r, cc ).colspan ) {
						values.push( ( cell.attrs.align || '' ).toLowerCase() );
					}
				} );

				if ( values.length && '' === column.align && values.every( function( value ) {
					return value === values[ 0 ] && ( 'center' === value || 'right' === value );
				} ) ) {
					column.align = values[ 0 ];
				}
			} );

			this.eachAnchor( function( cell, r, c ) {
				var align = ( cell.attrs.align || '' ).toLowerCase();

				if ( 'undefined' === typeof cell.attrs.align ) {
					return;
				}

				if ( 'left' === align || '' === align || align === self.columns[ c ].align ) {
					delete cell.attrs.align;
				}
			} );

			// width="100%" is what the table gets by default anyway.
			if ( '100%' === this.attrs.width ) {
				delete this.attrs.width;
			}
		},

		/**
		 * Number of columns.
		 *
		 * @return {number}
		 */
		columnCount: function() {
			return this.rows.length ? this.rows[ 0 ].slots.length : this.columns.length;
		},

		/**
		 * Number of rows.
		 *
		 * @return {number}
		 */
		rowCount: function() {
			return this.rows.length;
		},

		/**
		 * Gets the section a row belongs to.
		 *
		 * @param {number} r - Row index.
		 * @return {string}
		 */
		getSection: function( r ) {
			if ( r < this.headRows ) {
				return SECTION_HEAD;
			}

			if ( r >= this.rows.length - this.footRows ) {
				return SECTION_FOOT;
			}

			return SECTION_BODY;
		},

		/**
		 * Gets the cell in a slot.
		 *
		 * @param {number} r - Row index.
		 * @param {number} c - Column index.
		 * @return {Object|null}
		 */
		getCell: function( r, c ) {
			return this.rows[ r ] && this.rows[ r ].slots[ c ] ? this.rows[ r ].slots[ c ] : null;
		},

		/**
		 * Gets the area a cell covers.
		 *
		 * @param {number} r - Row index of any slot of the cell.
		 * @param {number} c - Column index of any slot of the cell.
		 * @return {Object} { row, col, rowspan, colspan }
		 */
		getSpan: function( r, c ) {
			var cell = this.getCell( r, c ),
				top = r, left = c, bottom = r, right = c;

			if ( ! cell ) {
				return { row: r, col: c, rowspan: 1, colspan: 1 };
			}

			while ( 0 < top && this.getCell( top - 1, c ) === cell ) {
				top--;
			}
			while ( 0 < left && this.getCell( r, left - 1 ) === cell ) {
				left--;
			}
			while ( this.getCell( bottom + 1, c ) === cell ) {
				bottom++;
			}
			while ( this.getCell( r, right + 1 ) === cell ) {
				right++;
			}

			return { row: top, col: left, rowspan: bottom - top + 1, colspan: right - left + 1 };
		},

		/**
		 * Whether a slot is the top left slot of its cell.
		 *
		 * @param {number} r - Row index.
		 * @param {number} c - Column index.
		 * @return {boolean}
		 */
		isAnchor: function( r, c ) {
			var cell = this.getCell( r, c );

			return !! cell && ( 0 === r || this.getCell( r - 1, c ) !== cell ) && ( 0 === c || this.getCell( r, c - 1 ) !== cell );
		},

		/**
		 * Runs a callback for every cell once, at its top left slot.
		 *
		 * @param {Function} callback - Receives cell, row, column.
		 * @return {void}
		 */
		eachAnchor: function( callback ) {
			var self = this;

			this.rows.forEach( function( row, r ) {
				row.slots.forEach( function( cell, c ) {
					if ( self.isAnchor( r, c ) ) {
						callback( cell, r, c );
					}
				} );
			} );
		},

		/**
		 * Whether the line above row r cuts through a merged cell.
		 *
		 * @param {number} r - Row index.
		 * @return {boolean}
		 */
		rowLineCrossed: function( r ) {
			var self = this;

			if ( 0 >= r || r >= this.rows.length ) {
				return false;
			}

			return this.rows[ r ].slots.some( function( cell, c ) {
				return self.getCell( r - 1, c ) === cell;
			} );
		},

		/**
		 * Whether the line left of column c cuts through a merged cell.
		 *
		 * @param {number} c - Column index.
		 * @return {boolean}
		 */
		columnLineCrossed: function( c ) {
			if ( 0 >= c || c >= this.columnCount() ) {
				return false;
			}

			return this.rows.some( function( row ) {
				return row.slots[ c ] === row.slots[ c - 1 ];
			} );
		},

		/**
		 * The tag a new cell gets at a position.
		 *
		 * @param {number} r - Row index.
		 * @param {number} c - Column index.
		 * @return {string}
		 */
		defaultTag: function( r, c ) {
			return SECTION_HEAD === this.getSection( r ) || ( 0 === c && SECTION_BODY === this.getSection( r ) && this.hasHeaderColumn() ) ? 'th' : 'td';
		},

		/**
		 * Inserts a row.
		 *
		 * Rows inserted inside a merged cell extend it. A new row placed
		 * right after the header (or right before the footer) joins the body.
		 *
		 * @param {number} at - Index the new row gets.
		 * @param {string} section - Optional section to put the row in.
		 * @return {void}
		 */
		insertRow: function( at, section ) {
			var self   = this,
				cols   = this.columnCount() || 1,
				slots  = [],
				c, above, below;

			at = Math.max( 0, Math.min( at, this.rows.length ) );

			if ( ! section ) {
				section = this.rows.length ? this.getSection( Math.min( at, this.rows.length - 1 ) ) : SECTION_BODY;
				if ( at === this.headRows && SECTION_HEAD !== section ) {
					section = SECTION_BODY;
				}
				if ( at === this.rows.length && this.footRows ) {
					section = SECTION_FOOT;
				}
			}

			for ( c = 0; c < cols; c++ ) {
				above = 0 < at ? this.getCell( at - 1, c ) : null;
				below = this.getCell( at, c );

				slots[ c ] = above && above === below ? above : null;
			}

			if ( SECTION_HEAD === section && at <= this.headRows ) {
				this.headRows++;
			} else if ( SECTION_FOOT === section && at >= this.rows.length - this.footRows ) {
				this.footRows++;
			}

			this.rows.splice( at, 0, { attrs: {}, slots: slots } );

			slots.forEach( function( cell, cc ) {
				if ( ! cell ) {
					slots[ cc ] = createCell( self.defaultTag( at, cc ), '' );
				}
			} );

			if ( ! this.columns.length ) {
				this.columns.push( createColumn() );
			}
		},

		/**
		 * Deletes a row. Merged cells crossing it shrink.
		 *
		 * @param {number} r - Row index.
		 * @return {void}
		 */
		deleteRow: function( r ) {
			if ( ! this.rows[ r ] ) {
				return;
			}

			if ( SECTION_HEAD === this.getSection( r ) ) {
				this.headRows--;
			} else if ( SECTION_FOOT === this.getSection( r ) ) {
				this.footRows--;
			}

			this.rows.splice( r, 1 );
		},

		/**
		 * Inserts a column. Columns inserted inside a merged cell extend it.
		 *
		 * @param {number} at - Index the new column gets.
		 * @return {void}
		 */
		insertColumn: function( at ) {
			var self = this;

			at = Math.max( 0, Math.min( at, this.columnCount() ) );

			if ( ! this.rows.length ) {
				this.insertRow( 0 );
				return;
			}

			this.rows.forEach( function( row, r ) {
				var left  = 0 < at ? row.slots[ at - 1 ] : null,
					right = row.slots[ at ],
					cell  = left && left === right ? left : createCell( SECTION_HEAD === self.getSection( r ) ? 'th' : 'td', '' );

				row.slots.splice( at, 0, cell );
			} );

			// Cells created in the same new column on several rows are all distinct, which is what we want.
			this.columns.splice( at, 0, createColumn() );
		},

		/**
		 * Deletes a column. Merged cells crossing it shrink.
		 *
		 * @param {number} c - Column index.
		 * @return {void}
		 */
		deleteColumn: function( c ) {
			if ( c < 0 || c >= this.columnCount() ) {
				return;
			}

			this.rows.forEach( function( row ) {
				row.slots.splice( c, 1 );
			} );

			this.columns.splice( c, 1 );

			// A table without columns has no rows either.
			if ( 0 === this.columnCount() ) {
				this.rows     = [];
				this.headRows = 0;
				this.footRows = 0;
			}
		},

		/**
		 * Duplicates a row below itself.
		 *
		 * @param {number} r - Row index.
		 * @return {boolean} False when a merged cell crosses the row.
		 */
		duplicateRow: function( r ) {
			var row = this.rows[ r ],
				copies = new Map();

			if ( ! row || this.rowLineCrossed( r ) || this.rowLineCrossed( r + 1 ) ) {
				return false;
			}

			this.rows.splice( r + 1, 0, {
				attrs: Object.assign( {}, row.attrs ),
				slots: row.slots.map( function( cell ) {
					if ( ! copies.has( cell ) ) {
						copies.set( cell, createCell( cell.tag, cell.html, Object.assign( {}, cell.attrs ) ) );
					}
					return copies.get( cell );
				} )
			} );

			if ( SECTION_HEAD === this.getSection( r ) && r < this.headRows ) {
				this.headRows++;
			} else if ( SECTION_FOOT === this.getSection( r ) ) {
				this.footRows++;
			}

			return true;
		},

		/**
		 * Duplicates a column to its right.
		 *
		 * @param {number} c - Column index.
		 * @return {boolean} False when a merged cell crosses the column.
		 */
		duplicateColumn: function( c ) {
			var copies = new Map();

			if ( c < 0 || c >= this.columnCount() || this.columnLineCrossed( c ) || this.columnLineCrossed( c + 1 ) ) {
				return false;
			}

			this.rows.forEach( function( row ) {
				var cell = row.slots[ c ];

				if ( ! copies.has( cell ) ) {
					copies.set( cell, createCell( cell.tag, cell.html, Object.assign( {}, cell.attrs ) ) );
				}

				row.slots.splice( c + 1, 0, copies.get( cell ) );
			} );

			this.columns.splice( c + 1, 0, JSON.parse( JSON.stringify( this.columns[ c ] || createColumn() ) ) );

			return true;
		},

		/**
		 * Duplicates a block of rows below itself, keeping merged cells inside the block.
		 *
		 * @param {number} r1 - First row.
		 * @param {number} r2 - Last row.
		 * @return {boolean} False when a merged cell crosses the block's edges.
		 */
		duplicateRows: function( r1, r2 ) {
			var copies = new Map(),
				block;

			if ( ! this.rows[ r1 ] || ! this.rows[ r2 ] || this.rowLineCrossed( r1 ) || this.rowLineCrossed( r2 + 1 ) ) {
				return false;
			}

			block = this.rows.slice( r1, r2 + 1 ).map( function( row ) {
				return {
					attrs: Object.assign( {}, row.attrs ),
					slots: row.slots.map( function( cell ) {
						if ( ! copies.has( cell ) ) {
							copies.set( cell, createCell( cell.tag, cell.html, Object.assign( {}, cell.attrs ) ) );
						}
						return copies.get( cell );
					} )
				};
			} );

			if ( SECTION_HEAD === this.getSection( r2 ) ) {
				this.headRows += block.length;
			} else if ( SECTION_FOOT === this.getSection( r2 ) ) {
				this.footRows += block.length;
			}

			Array.prototype.splice.apply( this.rows, [ r2 + 1, 0 ].concat( block ) );

			return true;
		},

		/**
		 * Duplicates a block of columns to its right, with their settings.
		 *
		 * @param {number} c1 - First column.
		 * @param {number} c2 - Last column.
		 * @return {boolean} False when a merged cell crosses the block's edges.
		 */
		duplicateColumns: function( c1, c2 ) {
			var copies = new Map(),
				self   = this;

			if ( 0 > c1 || c2 >= this.columnCount() || this.columnLineCrossed( c1 ) || this.columnLineCrossed( c2 + 1 ) ) {
				return false;
			}

			this.rows.forEach( function( row ) {
				var block = row.slots.slice( c1, c2 + 1 ).map( function( cell ) {
					if ( ! copies.has( cell ) ) {
						copies.set( cell, createCell( cell.tag, cell.html, Object.assign( {}, cell.attrs ) ) );
					}
					return copies.get( cell );
				} );

				Array.prototype.splice.apply( row.slots, [ c2 + 1, 0 ].concat( block ) );
			} );

			Array.prototype.splice.apply( this.columns, [ c2 + 1, 0 ].concat( this.columns.slice( c1, c2 + 1 ).map( function( column ) {
				return JSON.parse( JSON.stringify( column || createColumn() ) );
			} ) ) );

			return self.columnCount() === this.columns.length;
		},

		/**
		 * Whether a row can be moved to a position.
		 *
		 * @param {number} from - Row index.
		 * @param {number} to   - Target index (position after removal).
		 * @return {boolean}
		 */
		canMoveRow: function( from, to ) {
			var copy;

			if ( from === to || ! this.rows[ from ] || 0 > to || to >= this.rows.length ) {
				return false;
			}

			// Rows stay in their section; the header and footer toggles move rows between them.
			if ( this.getSection( from ) !== this.getSection( to ) ) {
				return false;
			}

			// The row itself must not share a merged cell with its neighbours.
			if ( this.rowLineCrossed( from ) || this.rowLineCrossed( from + 1 ) ) {
				return false;
			}

			copy = this.clone();
			copy.rows.splice( from, 1 );

			return ! copy.rowLineCrossed( to );
		},

		/**
		 * Moves a row, keeping the section sizes.
		 *
		 * @param {number} from - Row index.
		 * @param {number} to   - Target index.
		 * @return {boolean}
		 */
		moveRow: function( from, to ) {
			var row;

			if ( ! this.canMoveRow( from, to ) ) {
				return false;
			}

			row = this.rows.splice( from, 1 )[ 0 ];
			this.rows.splice( to, 0, row );

			return true;
		},

		/**
		 * Whether a column can be moved to a position.
		 *
		 * @param {number} from - Column index.
		 * @param {number} to   - Target index (position after removal).
		 * @return {boolean}
		 */
		canMoveColumn: function( from, to ) {
			var copy;

			if ( from === to || 0 > from || from >= this.columnCount() || 0 > to || to >= this.columnCount() ) {
				return false;
			}

			if ( this.columnLineCrossed( from ) || this.columnLineCrossed( from + 1 ) ) {
				return false;
			}

			copy = this.clone();
			copy.rows.forEach( function( row ) {
				row.slots.splice( from, 1 );
			} );

			return ! copy.columnLineCrossed( to );
		},

		/**
		 * Moves a column together with its settings.
		 *
		 * @param {number} from - Column index.
		 * @param {number} to   - Target index.
		 * @return {boolean}
		 */
		moveColumn: function( from, to ) {
			if ( ! this.canMoveColumn( from, to ) ) {
				return false;
			}

			this.rows.forEach( function( row ) {
				row.slots.splice( to, 0, row.slots.splice( from, 1 )[ 0 ] );
			} );

			this.columns.splice( to, 0, this.columns.splice( from, 1 )[ 0 ] );

			return true;
		},

		/**
		 * Grows a range until no merged cell sticks out of it.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {Object}
		 */
		expandRange: function( range ) {
			var out     = this.normalizeRange( range ),
				changed = true,
				r, c, span;

			while ( changed ) {
				changed = false;

				for ( r = out.r1; r <= out.r2; r++ ) {
					for ( c = out.c1; c <= out.c2; c++ ) {
						span = this.getSpan( r, c );

						if ( span.row < out.r1 || span.col < out.c1 || span.row + span.rowspan - 1 > out.r2 || span.col + span.colspan - 1 > out.c2 ) {
							out.r1  = Math.min( out.r1, span.row );
							out.c1  = Math.min( out.c1, span.col );
							out.r2  = Math.max( out.r2, span.row + span.rowspan - 1 );
							out.c2  = Math.max( out.c2, span.col + span.colspan - 1 );
							changed = true;
						}
					}
				}
			}

			return out;
		},

		/**
		 * Orders range corners.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {Object}
		 */
		normalizeRange: function( range ) {
			return {
				r1: Math.max( 0, Math.min( range.r1, range.r2 ) ),
				c1: Math.max( 0, Math.min( range.c1, range.c2 ) ),
				r2: Math.min( this.rows.length - 1, Math.max( range.r1, range.r2 ) ),
				c2: Math.min( this.columnCount() - 1, Math.max( range.c1, range.c2 ) )
			};
		},

		/**
		 * Whether a range can be merged into one cell.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {boolean}
		 */
		canMerge: function( range ) {
			var out = this.expandRange( range );

			if ( out.r1 === out.r2 && out.c1 === out.c2 ) {
				return false;
			}

			// The whole range already is a single cell.
			if ( this.getCell( out.r1, out.c1 ) === this.getCell( out.r2, out.c2 ) ) {
				return false;
			}

			// Cells can't span from the header into the body, and so on.
			return this.getSection( out.r1 ) === this.getSection( out.r2 );
		},

		/**
		 * Merges a range into one cell. Content of all non-empty cells is kept, one per line.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {Object|false} The merged range.
		 */
		merge: function( range ) {
			var out    = this.expandRange( range ),
				anchor = this.getCell( out.r1, out.c1 ),
				parts  = [],
				seen   = [],
				r, c, cell;

			if ( ! this.canMerge( range ) ) {
				return false;
			}

			for ( r = out.r1; r <= out.r2; r++ ) {
				for ( c = out.c1; c <= out.c2; c++ ) {
					cell = this.getCell( r, c );

					if ( -1 === seen.indexOf( cell ) ) {
						seen.push( cell );

						if ( '' !== cell.html.replace( /&nbsp;|\s|<br\s*\/?>/gi, '' ) ) {
							parts.push( cell.html.trim() );
						}
					}
				}
			}

			anchor.html = parts.join( '<br>' );

			for ( r = out.r1; r <= out.r2; r++ ) {
				for ( c = out.c1; c <= out.c2; c++ ) {
					this.rows[ r ].slots[ c ] = anchor;
				}
			}

			return out;
		},

		/**
		 * Splits every merged cell touching a range back into single cells.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {boolean} Whether anything was split.
		 */
		split: function( range ) {
			var self  = this,
				out   = this.normalizeRange( range ),
				done  = [],
				split = false,
				r, c, cell, span;

			for ( r = out.r1; r <= out.r2; r++ ) {
				for ( c = out.c1; c <= out.c2; c++ ) {
					cell = this.getCell( r, c );

					if ( -1 !== done.indexOf( cell ) ) {
						continue;
					}

					done.push( cell );
					span = this.getSpan( r, c );

					if ( 1 < span.rowspan || 1 < span.colspan ) {
						split = true;
						this.forRange( { r1: span.row, c1: span.col, r2: span.row + span.rowspan - 1, c2: span.col + span.colspan - 1 }, function( rr, cc ) {
							if ( rr !== span.row || cc !== span.col ) {
								self.rows[ rr ].slots[ cc ] = createCell( cell.tag, '', {} );
							}
						} );
					}
				}
			}

			return split;
		},

		/**
		 * Whether a range touches a merged cell.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {boolean}
		 */
		hasMergedCells: function( range ) {
			var self  = this,
				found = false;

			this.forRange( this.normalizeRange( range ), function( r, c ) {
				var span = self.getSpan( r, c );

				if ( 1 < span.rowspan || 1 < span.colspan ) {
					found = true;
				}
			} );

			return found;
		},

		/**
		 * Runs a callback for every slot in a range.
		 *
		 * @param {Object}   range    - { r1, c1, r2, c2 }.
		 * @param {Function} callback - Receives row, column.
		 * @return {void}
		 */
		forRange: function( range, callback ) {
			var r, c;

			for ( r = range.r1; r <= range.r2; r++ ) {
				for ( c = range.c1; c <= range.c2; c++ ) {
					callback( r, c );
				}
			}
		},

		/**
		 * Sets the content of the cell in a slot.
		 *
		 * @param {number} r    - Row index.
		 * @param {number} c    - Column index.
		 * @param {string} html - The content.
		 * @return {void}
		 */
		setCellHtml: function( r, c, html ) {
			var cell = this.getCell( r, c );

			if ( cell ) {
				cell.html = html;
			}
		},

		/**
		 * Clears the content of all cells in a range.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {void}
		 */
		clearRange: function( range ) {
			var self = this;

			this.forRange( this.normalizeRange( range ), function( r, c ) {
				self.setCellHtml( r, c, '' );
			} );
		},

		/**
		 * Number of header rows (thead), clamped so no merged cell crosses into the body.
		 *
		 * @param {number} count - Rows to use as header.
		 * @return {void}
		 */
		setHeadRows: function( count ) {
			var headerCol = this.hasHeaderColumn(),
				old       = this.headRows;

			count = Math.max( 0, Math.min( count, this.rows.length - this.footRows ) );

			if ( this.rowLineCrossed( count ) ) {
				this.split( { r1: count - 1, c1: 0, r2: count, c2: this.columnCount() - 1 } );
			}

			this.headRows = count;
			this.retag( Math.min( old, count ), Math.max( old, count ), headerCol );
		},

		/**
		 * Number of footer rows (tfoot).
		 *
		 * @param {number} count - Rows to use as footer.
		 * @return {void}
		 */
		setFootRows: function( count ) {
			var line;

			count = Math.max( 0, Math.min( count, this.rows.length - this.headRows ) );
			line  = this.rows.length - count;

			if ( count && this.rowLineCrossed( line ) ) {
				this.split( { r1: line - 1, c1: 0, r2: line, c2: this.columnCount() - 1 } );
			}

			this.footRows = count;
		},

		/**
		 * Gives the cells of rows that changed section the tag of their new section.
		 *
		 * @param {number}  from      - First row.
		 * @param {number}  to        - Row after the last one.
		 * @param {boolean} headerCol - Whether the first column holds row headers.
		 * @return {void}
		 */
		retag: function( from, to, headerCol ) {
			var self = this,
				r;

			for ( r = from; r < to; r++ ) {
				this.rows[ r ].slots.forEach( function( cell, c ) {
					if ( SECTION_HEAD === self.getSection( r ) ) {
						cell.tag = 'th';
					} else {
						cell.tag = 0 === c && headerCol ? 'th' : 'td';
					}
				} );
			}
		},

		/**
		 * Whether the first column holds row headers (th in the body).
		 *
		 * @return {boolean}
		 */
		hasHeaderColumn: function() {
			var self   = this,
				bodies = 0,
				all    = true;

			this.rows.forEach( function( row, r ) {
				if ( SECTION_BODY !== self.getSection( r ) || ! row.slots[ 0 ] ) {
					return;
				}
				if ( self.isAnchor( r, 0 ) ) {
					bodies++;
					all = all && 'th' === row.slots[ 0 ].tag;
				}
			} );

			return 0 < bodies && all;
		},

		/**
		 * Turns the first column into row headers, or back.
		 *
		 * @param {boolean} state - Whether the first column holds headers.
		 * @return {void}
		 */
		setHeaderColumn: function( state ) {
			var self = this;

			this.rows.forEach( function( row, r ) {
				if ( SECTION_BODY === self.getSection( r ) && row.slots[ 0 ] ) {
					row.slots[ 0 ].tag = state ? 'th' : 'td';
				}
			} );
		},

		/**
		 * Sets a column property.
		 *
		 * @param {number} c     - Column index.
		 * @param {string} prop  - align, width, hide, highlight or filter.
		 * @param {mixed}  value - The value.
		 * @return {void}
		 */
		setColumnProp: function( c, prop, value ) {
			if ( ! this.columns[ c ] ) {
				return;
			}

			this.columns[ c ][ prop ] = value;
		},

		/**
		 * The height of a row, from its style.
		 *
		 * @param {number} r - Row index.
		 * @return {string}
		 */
		getRowHeight: function( r ) {
			var match = this.rows[ r ] && this.rows[ r ].attrs.style ? this.rows[ r ].attrs.style.match( /(?:^|;)\s*height\s*:\s*([^;]+)/i ) : null;

			return match ? match[ 1 ].trim() : '';
		},

		/**
		 * Sets the height of a row; an empty height leaves it to the content.
		 *
		 * @param {number} r      - Row index.
		 * @param {string} height - A CSS length.
		 * @return {void}
		 */
		setRowHeight: function( r, height ) {
			var row   = this.rows[ r ],
				style;

			if ( ! row ) {
				return;
			}

			style = ( row.attrs.style || '' ).split( ';' ).map( function( item ) {
				return item.trim();
			} ).filter( function( item ) {
				return item && ! /^height\s*:/i.test( item );
			} );

			if ( height ) {
				style.push( 'height:' + height );
			}

			if ( style.length ) {
				row.attrs.style = style.join( ';' );
			} else {
				delete row.attrs.style;
			}
		},

		/**
		 * Whether a row is highlighted.
		 *
		 * @param {number} r - Row index.
		 * @return {boolean}
		 */
		isRowHighlighted: function( r ) {
			return !! this.rows[ r ] && '1' === this.rows[ r ].attrs[ 'data-highlight' ];
		},

		/**
		 * Highlights a row.
		 *
		 * @param {number}  r     - Row index.
		 * @param {boolean} state - Whether to highlight.
		 * @return {void}
		 */
		setRowHighlight: function( r, state ) {
			if ( ! this.rows[ r ] ) {
				return;
			}

			// Saved as data-highlight, as columns are on their col; the render adds the row modifier.
			if ( state ) {
				this.rows[ r ].attrs[ 'data-highlight' ] = '1';
			} else {
				delete this.rows[ r ].attrs[ 'data-highlight' ];
			}
		},

		/**
		 * Writes a two dimensional array of contents into the grid, growing it when needed.
		 *
		 * @param {number} r    - Top row.
		 * @param {number} c    - Left column.
		 * @param {Array}  data - Rows of cell contents (html).
		 * @return {Object} The range that was written.
		 */
		writeData: function( r, c, data ) {
			var self = this,
				rows = data.length,
				cols = 0;

			data.forEach( function( line ) {
				cols = Math.max( cols, line.length );
			} );

			if ( ! rows || ! cols ) {
				return false;
			}

			// New rows go to the end of the section the data starts in, so a footer stays last.
			while ( this.rows.length < r + rows ) {
				if ( SECTION_FOOT === this.getSection( r ) || ! this.footRows ) {
					this.insertRow( this.rows.length, this.rows.length ? this.getSection( this.rows.length - 1 ) : SECTION_BODY );
				} else {
					this.insertRow( this.rows.length - this.footRows, SECTION_BODY );
				}
			}

			while ( this.columnCount() < c + cols ) {
				this.insertColumn( this.columnCount() );
			}

			data.forEach( function( line, i ) {
				line.forEach( function( html, j ) {
					var span = self.getSpan( r + i, c + j );

					// Only the top left slot of a merged cell takes a value.
					if ( span.row === r + i && span.col === c + j ) {
						self.setCellHtml( r + i, c + j, html );
					}
				} );
			} );

			return { r1: r, c1: c, r2: r + rows - 1, c2: c + cols - 1 };
		},

		/**
		 * Reads a range as a two dimensional array of contents.
		 *
		 * @param {Object} range - { r1, c1, r2, c2 }.
		 * @return {Array}
		 */
		readData: function( range ) {
			var out = [],
				r, c, line, span;

			range = this.normalizeRange( range );

			for ( r = range.r1; r <= range.r2; r++ ) {
				line = [];
				for ( c = range.c1; c <= range.c2; c++ ) {
					span = this.getSpan( r, c );
					line.push( span.row === r && span.col === c ? this.getCell( r, c ).html : '' );
				}
				out.push( line );
			}

			return out;
		},

		/**
		 * Replaces the whole table with data.
		 *
		 * @param {Array}   data   - Rows of cell contents (html).
		 * @param {boolean} header - Whether the first row is the header.
		 * @return {void}
		 */
		replaceData: function( data, header ) {
			var cols = 0;

			data.forEach( function( line ) {
				cols = Math.max( cols, line.length );
			} );

			this.rows     = [];
			this.headRows = 0;
			this.footRows = 0;
			this.columns  = this.columns.slice( 0, cols );

			this.writeData( 0, 0, data );

			if ( header ) {
				this.setHeadRows( 1 );
			}
		},

		/**
		 * Appends data rows to the body.
		 *
		 * @param {Array} data - Rows of cell contents (html).
		 * @return {Object} The range that was written.
		 */
		appendData: function( data ) {
			var at = this.rows.length - this.footRows,
				i;

			for ( i = 0; i < data.length; i++ ) {
				this.insertRow( at + i, SECTION_BODY );
			}

			return this.writeData( at, 0, data );
		},

		/**
		 * Deep copy.
		 *
		 * @return {Table}
		 */
		clone: function() {
			var copy = new Table();

			copy.load( this.toHTML() );
			copy.wrapperAttrs = JSON.parse( JSON.stringify( this.wrapperAttrs ) );

			return copy;
		},

		/**
		 * Serializes the model.
		 *
		 * @param {Object} options - { wrapper: bool (default true) }.
		 * @return {string}
		 */
		toHTML: function( options ) {
			var self      = this,
				html      = '',
				sections  = [
					{ tag: 'thead', from: 0, to: this.headRows },
					{ tag: 'tbody', from: this.headRows, to: this.rows.length - this.footRows },
					{ tag: 'tfoot', from: this.rows.length - this.footRows, to: this.rows.length }
				],
				colgroup  = '',
				useCols   = false;

			options = options || {};

			if ( '' !== this.caption ) {
				html += '<caption>' + this.caption + '</caption>';
			}

			this.columns.forEach( function( column ) {
				var attrs = Object.assign( {}, column.attrs );

				if ( column.align ) {
					attrs[ 'data-align' ] = column.align;
				}

				if ( column.hide && column.hide.length ) {
					attrs[ 'data-hide' ] = column.hide.join( ',' );
				}

				if ( column.highlight ) {
					attrs[ 'data-highlight' ] = '1';
				}

				if ( column.filter ) {
					attrs[ 'data-filter' ] = '1';
				}

				if ( column.width ) {
					attrs.style = 'width:' + column.width;
				}

				if ( Object.keys( attrs ).length ) {
					useCols = true;
				}

				colgroup += '<col' + attrString( attrs ) + '>';
			} );

			if ( useCols ) {
				html += '<colgroup>' + colgroup + '</colgroup>';
			}

			sections.forEach( function( section ) {
				var r, rowsHtml = '';

				// A table always gets a body, even an empty one keeps the markup valid.
				if ( section.from >= section.to && 'tbody' !== section.tag ) {
					return;
				}

				for ( r = section.from; r < section.to; r++ ) {
					rowsHtml += '<tr' + attrString( self.rows[ r ].attrs ) + '>';

					self.rows[ r ].slots.forEach( function( cell, c ) {
						var span, attrs, tag;

						if ( ! self.isAnchor( r, c ) ) {
							return;
						}

						span  = self.getSpan( r, c );
						attrs = Object.assign( {}, cell.attrs );
						tag   = 'thead' === section.tag ? 'th' : cell.tag;

						if ( 1 < span.colspan ) {
							attrs.colspan = String( span.colspan );
						}

						if ( 1 < span.rowspan ) {
							attrs.rowspan = String( span.rowspan );
						}

						if ( 'th' === tag ) {
							attrs.scope = 'thead' === section.tag ? ( 1 < span.colspan ? 'colgroup' : 'col' ) : ( 1 < span.rowspan ? 'rowgroup' : 'row' );
						}

						rowsHtml += '<' + tag + attrString( attrs ) + '>' + cell.html + '</' + tag + '>';
					} );

					rowsHtml += '</tr>';
				}

				html += '<' + section.tag + '>' + rowsHtml + '</' + section.tag + '>';
			} );

			html = '<table' + attrString( this.attrs ) + '>' + html + '</table>';

			if ( false !== options.wrapper ) {
				html = '<div' + attrString( this.wrapperAttrs ) + '>' + html + '</div>';
			}

			return html;
		}
	};

	/**
	 * Creates an empty table.
	 *
	 * @param {number}  rows    - Body rows.
	 * @param {number}  columns - Columns.
	 * @param {boolean} header  - Whether to add a header row.
	 * @return {Table}
	 */
	function create( rows, columns, header ) {
		var table = new Table(),
			r;

		for ( r = 0; r < rows + ( header ? 1 : 0 ); r++ ) {
			table.insertRow( r, SECTION_BODY );
		}

		while ( table.columnCount() < columns ) {
			table.insertColumn( table.columnCount() );
		}

		if ( header ) {
			table.setHeadRows( 1 );
		}

		return table;
	}

	/**
	 * Parses delimiter separated text (CSV, TSV) into rows, honouring quotes.
	 *
	 * @param {string} text      - The text.
	 * @param {string} delimiter - Optional; detected when omitted.
	 * @return {Array}
	 */
	function parseDelimited( text, delimiter ) {
		var rows   = [],
			row    = [],
			field  = '',
			quoted = false,
			i, ch, firstLine;

		text = String( text || '' ).replace( /\r\n?/g, '\n' );

		if ( ! delimiter ) {
			firstLine = text.split( '\n' )[ 0 ];
			delimiter = -1 !== firstLine.indexOf( '\t' ) ? '\t' : ( firstLine.split( ';' ).length > firstLine.split( ',' ).length ? ';' : ',' );
		}

		for ( i = 0; i < text.length; i++ ) {
			ch = text[ i ];

			if ( quoted ) {
				if ( '"' === ch && '"' === text[ i + 1 ] ) {
					field += '"';
					i++;
				} else if ( '"' === ch ) {
					quoted = false;
				} else {
					field += ch;
				}
			} else if ( '"' === ch && '' === field ) {
				quoted = true;
			} else if ( ch === delimiter ) {
				row.push( field );
				field = '';
			} else if ( '\n' === ch ) {
				row.push( field );
				rows.push( row );
				row   = [];
				field = '';
			} else {
				field += ch;
			}
		}

		if ( '' !== field || row.length ) {
			row.push( field );
			rows.push( row );
		}

		// Spreadsheets add a trailing line break.
		while ( rows.length && 1 === rows[ rows.length - 1 ].length && '' === rows[ rows.length - 1 ][ 0 ] ) {
			rows.pop();
		}

		return rows;
	}

	/**
	 * Turns plain text into cell markup.
	 *
	 * @param {string} text - The text.
	 * @return {string}
	 */
	function textToHtml( text ) {
		return escHtml( text ).replace( /\n/g, '<br>' );
	}

	/**
	 * Reads data out of pasted markup that contains a table (Excel, Sheets, Docs, web pages).
	 *
	 * Spans are kept by repeating nothing: covered slots stay empty.
	 *
	 * @param {string} html - The markup.
	 * @return {Array|false}
	 */
	function dataFromHtml( html ) {
		var found = findTable( toFragment( html ) ),
			grid,
			data  = [];

		if ( ! found ) {
			return false;
		}

		grid = mapGrid( getSections( found.table ) );

		grid.rows.forEach( function( row, r ) {
			data[ r ] = data[ r ] || [];
		} );

		grid.rows.forEach( function( row ) {
			row.cells.forEach( function( info ) {
				data[ info.row ][ info.col ] = cleanPastedHtml( info.el );
			} );
		} );

		return data.map( function( line ) {
			var out = [],
				c;

			for ( c = 0; c < grid.columns; c++ ) {
				out.push( line[ c ] || '' );
			}

			return out;
		} );
	}

	/**
	 * Keeps only simple inline formatting from pasted cells.
	 *
	 * @param {Element} el - The pasted cell.
	 * @return {string}
	 */
	function cleanPastedHtml( el ) {
		var allowed = { B: 'strong', STRONG: 'strong', I: 'em', EM: 'em', U: 'u', A: 'a', BR: 'br', SUB: 'sub', SUP: 'sup', CODE: 'code' };

		function walk( node ) {
			var out = '';

			Array.prototype.forEach.call( node.childNodes, function( child ) {
				var tag, inner, href;

				if ( 3 === child.nodeType ) {
					out += escHtml( child.nodeValue.replace( /\s+/g, ' ' ) );
				} else if ( 1 === child.nodeType ) {
					tag   = allowed[ child.tagName ];
					inner = walk( child );

					if ( 'br' === tag ) {
						out += '<br>';
					} else if ( 'a' === tag ) {
						href = child.getAttribute( 'href' ) || '';
						out += /^(https?:|mailto:|tel:|\/|#)/i.test( href ) ? '<a href="' + escAttr( href ) + '">' + inner + '</a>' : inner;
					} else if ( tag ) {
						out += '' !== inner.trim() ? '<' + tag + '>' + inner + '</' + tag + '>' : inner;
					} else if ( /^(P|DIV|LI)$/.test( child.tagName ) && out && '<br>' !== out.slice( -4 ) ) {
						out += '<br>' + inner;
					} else {
						out += inner;
					}
				}
			} );

			return out;
		}

		return walk( el ).replace( /^(\s|<br>)+|(\s|<br>)+$/g, '' );
	}

	/**
	 * Adds the render time attributes to table markup: th scope, column
	 * alignment, visibility, highlight and alternate column classes and
	 * stack mode labels.
	 *
	 * Mirrors FusionSC_FusionTable::enhance_content() in PHP.
	 *
	 * @param {string} html    - The element content.
	 * @param {Object} options - { labels: bool, alternateColumns: bool, sortHeads: bool, markLabels: { yes, no, partial }, tableClass: string, captionClass: string }.
	 * @return {string}
	 */
	function enhance( html, options ) {
		var fragment = toFragment( html || '' ),
			found    = findTable( fragment ),
			columns, grid, labels = [], headRows = [];

		options = options || {};

		if ( ! found ) {
			return html;
		}

		columns = readColumns( found.table );
		grid    = mapGrid( getSections( found.table ) );

		// The part classes of the table's own nodes, never of tables nested in its cells.
		addClasses( found.table, options.tableClass || 'awb-table__table' );

		childrenByTag( found.table, [ 'caption' ] ).forEach( function( caption ) {
			addClasses( caption, options.captionClass || 'awb-table__caption' );
		} );

		grid.rows.forEach( function( row ) {
			if ( SECTION_HEAD === row.section ) {
				headRows.push( row );
			}
		} );

		// Labels for stacked cells come from the last header cell above each column.
		headRows.forEach( function( row ) {
			row.cells.forEach( function( info ) {
				var c;

				for ( c = info.col; c < info.col + info.colspan; c++ ) {
					labels[ c ] = info.el.textContent.replace( /\[[^\]]*\]/g, '' ).replace( /\s+/g, ' ' ).trim();
				}
			} );
		} );

		// The header cell that sorts its column: the last one above it, spanning only it.
		if ( options.sortHeads ) {
			headRows.reduce( function( last, row ) {
				row.cells.forEach( function( info ) {
					var c;

					for ( c = info.col; c < info.col + info.colspan; c++ ) {
						last[ c ] = 1 === info.colspan ? info.el : null;
					}
				} );
				return last;
			}, [] ).forEach( function( el ) {
				if ( el ) {
					el.sortHead = true;
				}
			} );
		}

		grid.rows.forEach( function( row ) {
			var firstCol = row.cells.length ? row.cells[ 0 ].col : 0;

			// Highlighted rows are saved as data-highlight, as columns are on their col.
			addClasses( row.tr, 'awb-table__row' + ( '1' === row.tr.getAttribute( 'data-highlight' ) ? ' awb-table__row--highlight' : '' ) );

			row.cells.forEach( function( info, index ) {
				var el      = info.el,
					column  = columns[ info.col ],
					classes = [ 'awb-table__cell' ],
					hidden;

				if ( SECTION_HEAD === row.section ) {
					classes.push( 'awb-table__cell--head' );
				} else if ( 'TH' === el.tagName ) {
					classes.push( 'awb-table__cell--row-header' );
				}

				if ( SECTION_FOOT === row.section ) {
					classes.push( 'awb-table__cell--foot' );
				}

				if ( 'TH' === el.tagName && ! el.hasAttribute( 'scope' ) ) {
					el.setAttribute( 'scope', SECTION_HEAD === row.section ? ( 1 < info.colspan ? 'colgroup' : 'col' ) : ( 1 < info.rowspan ? 'rowgroup' : 'row' ) );
				}

				if ( column ) {
					if ( -1 !== [ 'left', 'center', 'right' ].indexOf( column.align ) ) {
						classes.push( 'awb-table__cell--align-' + column.align );
					}

					// Header cells too; whether they show it is the Highlight Header Cell option.
					if ( column.highlight ) {
						classes.push( 'awb-table__cell--highlight' );
					}

					hidden = column.hide.filter( function( size ) {
						var c;

						// A merged cell only hides when every column it covers does.
						for ( c = info.col + 1; c < info.col + info.colspan; c++ ) {
							if ( ! columns[ c ] || -1 === columns[ c ].hide.indexOf( size ) ) {
								return false;
							}
						}
						return true;
					} );

				}

				// The first cell of a row that does not start the row, as a rowspan above covers column 0.
				if ( 0 === index && 0 < firstCol ) {
					classes.push( 'awb-table__cell--indent' );
				}

				// Alternate columns, counted on real columns, as merged cells defeat :nth-child().
				if ( options.alternateColumns && SECTION_HEAD !== row.section && 1 === info.col % 2 ) {
					classes.push( 'awb-table__cell--alternate' );
				}

				if ( el.sortHead ) {
					classes.push( 'awb-table__cell--sort' );
					delete el.sortHead;
				}

				addClasses( el, classes.join( ' ' ) );

				if ( hidden ) {
					hidden.forEach( function( size ) {
						el.classList.add( 'fusion-no-' + size + '-visibility' );
					} );
				}

				if ( options.labels && SECTION_HEAD !== row.section && labels[ info.col ] && ! el.hasAttribute( 'data-label' ) ) {
					el.setAttribute( 'data-label', labels[ info.col ] );
				}
			} );
		} );

		// Marks get a name for assistive technology.
		if ( options.markLabels ) {
			found.table.querySelectorAll( 'span.awb-table__mark[data-mark]' ).forEach( function( mark ) {
				var label = options.markLabels[ mark.getAttribute( 'data-mark' ) ];

				if ( label && ! mark.hasAttribute( 'aria-label' ) ) {
					mark.setAttribute( 'role', 'img' );
					mark.setAttribute( 'aria-label', label );
				}
			} );
		}

		return restoreShortcodes( found.wrapper ? found.wrapper.outerHTML : found.table.outerHTML );
	}

	/**
	 * Adds a string of classes to an element, after the classes it has.
	 *
	 * @param {Element} el      - The element.
	 * @param {string}  classes - Space separated classes.
	 * @return {void}
	 */
	function addClasses( el, classes ) {
		classes.split( ' ' ).forEach( function( name ) {
			if ( name ) {
				el.classList.add( name );
			}
		} );
	}

	/**
	 * Grid positions of the cells of a rendered table element.
	 *
	 * @param {Element} table - The table.
	 * @return {Array} [ { el, row, col, rowspan, colspan } ]
	 */
	function mapTable( table ) {
		var cells = [];

		mapGrid( getSections( table ) ).rows.forEach( function( row ) {
			cells = cells.concat( row.cells );
		} );

		return cells;
	}

	return {
		Table: Table,
		create: create,
		mapTable: mapTable,
		parse: function( html ) {
			return new Table( html );
		},
		parseDelimited: parseDelimited,
		dataFromHtml: dataFromHtml,
		textToHtml: textToHtml,
		escHtml: escHtml,
		escAttr: escAttr,
		enhance: enhance,
		hideValues: HIDE_VALUES
	};
}() );
