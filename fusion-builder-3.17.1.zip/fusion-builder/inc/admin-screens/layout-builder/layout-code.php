<?php
/**
 * An underscore.js template: the layout Code Fields modal.
 *
 * @package fusion-builder
 * @since 3.17
 */

$awb_layout_code_fields = [
	'tracking_code'    => __( 'Tracking Code', 'fusion-builder' ),
	'space_head_close' => __( 'Space Before </head>', 'fusion-builder' ),
	'space_body_open'  => __( 'Space After <body>', 'fusion-builder' ),
	'space_body_close' => __( 'Space Before </body>', 'fusion-builder' ),
];
?>
<script type="text/template" id="fusion-layout-code">
	<div class="fusion-layout-overlay"></div>
	<div class="layoutbox fusion-layout-options awb-layout-code">
		<!-- heading -->
		<div class="layoutbox-heading">
			<div class="layoutbox-title">
				<?php esc_html_e( 'Code Fields', 'fusion-builder' ); ?>
			</div>
			<div class="layoutbox-controls layoutbox-controls-right">
				<span style="display:none;" class="loader"><?php esc_html_e( 'Saving code', 'fusion-builder' ); ?></span>
				<a class="control close fusiona-layout-close" href="#" aria-label="<?php esc_attr_e( 'Close Modal', 'fusion-builder' ); ?>"></a>
			</div>
		</div>
		<!-- content -->
		<form class="layoutbox-content awb-layout-code__form">
			<p class="awb-layout-code__note"><?php esc_html_e( 'Runs on every page this layout applies to, after the Global Options code and before the page code.', 'fusion-builder' ); ?></p>
			<?php foreach ( $awb_layout_code_fields as $awb_field => $awb_label ) : ?>
				<label class="awb-layout-code__label" for="awb-layout-code-<?php echo esc_attr( $awb_field ); ?>"><?php echo esc_html( $awb_label ); ?></label>
				<textarea class="awb-layout-code__field" id="awb-layout-code-<?php echo esc_attr( $awb_field ); ?>" name="<?php echo esc_attr( $awb_field ); ?>" spellcheck="false">{{ code.<?php echo esc_attr( $awb_field ); ?> }}</textarea>
			<?php endforeach; ?>
			<div class="awb-layout-code__actions">
				<span class="awb-layout-code__error" style="display:none;"><?php esc_html_e( 'The code could not be saved.', 'fusion-builder' ); ?></span>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'fusion-builder' ); ?></button>
			</div>
		</form>
	</div>
</script>
