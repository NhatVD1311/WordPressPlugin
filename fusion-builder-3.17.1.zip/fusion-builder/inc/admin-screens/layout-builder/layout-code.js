/* eslint no-empty-function: ["error", { "allow": ["functions"] }] */

var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	// Layout Code Fields View: saved in the layout's post-meta, apart from the conditions and sections.
	FusionPageBuilder.LayoutCodeView = Backbone.View.extend( {
		template: FusionPageBuilder.template( jQuery( '#fusion-layout-code' ).html() ),
		events: {
			'click .close,.fusion-layout-overlay': 'closeModal',
			'submit .awb-layout-code__form': 'save'
		},

		/**
		 * Render the template.
		 *
		 * @since 3.17
		 * @return {Object} this.
		 */
		render: function() {
			var code = _.extend( {
				tracking_code: '',
				space_head_close: '',
				space_body_open: '',
				space_body_close: ''
			}, this.model.get( 'code' ) );

			this.$el.html( this.template( { code: code } ) );

			return this;
		},

		/**
		 * Saves the code. Kept open on a failure, so the code is not lost.
		 *
		 * @since 3.17
		 * @param {Object} event - The event.
		 * @return {void}
		 */
		save: function( event ) {
			var self    = this,
				code    = {},
				$button = this.$el.find( '.awb-layout-code__actions button' );

			event.preventDefault();

			this.$el.find( '.awb-layout-code__field' ).each( function() {
				code[ this.name ] = this.value;
			} );

			$button.prop( 'disabled', true );
			this.$el.find( '.loader' ).show();
			this.$el.find( '.awb-layout-code__error' ).hide();

			this.model.doAjax( {
				action: 'fusion_admin_layout_update',
				action_type: 'update_code',
				layout_id: this.model.get( 'id' ),
				code: code,
				security: jQuery( '.fusion-template-builder #_wpnonce' ).val()
			}, function( response ) {
				if ( response && response.data && response.data.code ) {
					self.model.set( 'code', response.data.code );
					self.remove();
					return;
				}

				$button.prop( 'disabled', false );
				self.$el.find( '.loader' ).hide();
				self.$el.find( '.awb-layout-code__error' ).show();
			} );
		},

		/**
		 * Close the modal.
		 *
		 * @since 3.17
		 * @param {Object} event - The event.
		 * @return {void}
		 */
		closeModal: function( event ) {
			event.preventDefault();
			this.remove();
		}
	} );

}( jQuery ) );
