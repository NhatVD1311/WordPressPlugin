<?php
/**
 * Avada Demo Import
 *
 * @package Avada-Builder
 * @since 3.5
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * AWB Demo class.
 *
 * @since 3.5
 */
class AWB_Demo_Import {

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @access private
	 * @since 3.5
	 * @var object
	 */
	private static $instance;

	/**
	 * Location.
	 *
	 * @access private
	 * @since 3.5
	 * @var object
	 */
	private $location;

	/**
	 * URL to fetch for demo data.
	 *
	 * @access private
	 * @since 3.5
	 * @var boolean
	 */
	private $demo_url = 'https://updates.theme-fusion.com';

	/**
	 * The demo data.
	 *
	 * @access public
	 * @since 3.5
	 * @var mixed
	 */
	public $demo_data = null;

	/**
	 * URL to fetch for page data.
	 *
	 * @access private
	 * @since 3.5
	 * @var boolean
	 */
	private $page_url = 'https://classic.avada.com';

	/**
	 * The global elements fetched for the page being imported, by their ID on the prebuilt website.
	 *
	 * @access private
	 * @since 3.17.1
	 * @var array
	 */
	private $global_elements = [];

	/**
	 * Class constructor.
	 *
	 * @since 3.5
	 * @access private
	 */
	private function __construct() {

		add_action( 'wp_ajax_awb_load_websites', [ $this, 'get_ajax_website_data' ] );
		add_action( 'wp_ajax_awb_load_websites_page', [ $this, 'load_website_page' ] );

		add_action( 'fusion_builder_load_templates', [ $this, 'library_template' ] );
		add_action( 'fusion_builder_after', [ $this, 'library_template' ] );

		$this->location = true === Fusion_App()->is_builder || ( isset( $_POST ) && isset( $_POST['fusion_front_end'] ) && $_POST['fusion_front_end'] ) ? 'front' : 'back'; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
	}

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @access public
	 * @since 3.5
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new AWB_Demo_Import();
		}
		return self::$instance;
	}

	/**
	 * Get the data for ajax website requests.
	 *
	 * @access public
	 * @since 3.5
	 * @return void
	 */
	public function get_ajax_website_data() {
		check_ajax_referer( 'fusion_load_nonce', 'fusion_load_nonce' );

		echo wp_json_encode( $this->get_website_data() );

		wp_die();
	}

	/**
	 * Return the demo URL.
	 *
	 * @access public
	 * @since 3.5
	 * @return string
	 */
	public function get_demo_url() {
		return $this->demo_url;
	}

	/**
	 * Get the demo data from REST endpoint.
	 *
	 * @access public
	 * @since 3.5
	 * @return array
	 */
	public function get_website_data() {
		if ( null !== $this->demo_data ) {
			return $this->demo_data;
		}

		if ( false !== get_transient( 'awb_library_demo' ) ) {
			$this->demo_data = get_transient( 'awb_library_demo' );
			return $this->demo_data;
		}

		$response = wp_remote_get( $this->get_demo_url() . '/wp-json/demo/full', [ 'timeout' => 60 ] );

		// Exit if error.
		if ( is_wp_error( $response ) ) {
			return;
		}

		// Get the body.
		$resources = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( is_array( $resources ) && ! isset( $resources['tags'] ) ) {
			return;
		}

		set_transient( 'awb_library_demo', $resources, DAY_IN_SECONDS );

		return $resources;
	}

	/**
	 * Load website page.
	 *
	 * @access public
	 * @since 3.5
	 * @return void
	 */
	public function load_website_page() {

		check_ajax_referer( 'fusion_load_nonce', 'fusion_load_nonce' );

		if ( ! isset( $_POST['post_id'] ) && '' === $_POST['post_id'] ) {
			die( -1 );
		}

		if ( ! isset( $_POST['demo_name'] ) && '' === $_POST['demo_name'] ) {
			die( -1 );
		}

		if ( ! isset( $_POST['page_id'] ) && '' === $_POST['page_id'] ) {
			die( -1 );
		}

		$demo_name = sanitize_text_field( wp_unslash( $_POST['demo_name'] ) );
		$demo_name = str_replace( '_', '-', $demo_name );
		$post_id   = (int) $_POST['post_id'];
		$page_id   = (int) $_POST['page_id'];
		$data      = [
			'success' => true,
			'post_id' => $post_id,
		];

		$page_ep = $this->page_url . '/' . $demo_name . '/wp-json/wp/v2/pages/' . $page_id . '/';

		$response = wp_remote_get( $page_ep, [ 'timeout' => 60 ] );
		// Exit if error.
		if ( is_wp_error( $response ) ) {
			$data['success'] = false;
			echo wp_json_encode( $data );
			die();
		}

		// Get the body.
		$resources = json_decode( wp_remote_retrieve_body( $response ), true );

		// Set post_content.
		if ( isset( $resources['content'] ) && isset( $resources['content']['raw'] ) ) {
			$data['post_content'] = $resources['content']['raw'];
		} else {
			$data['success'] = false; // required to have post_content otherwise flag it as error.
		}

		// Set page template.
		if ( isset( $resources['template'] ) && ! empty( $resources['template'] ) ) {
			$data['page_template'] = $resources['template'];
		}

		$media = isset( $resources['avada_media'] ) && is_array( $resources['avada_media'] ) ? $resources['avada_media'] : [];

		// The page's global elements are library items of the prebuilt website, bring in their content and media.
		if ( isset( $data['post_content'] ) ) {
			$this->global_elements = [];
			$data['post_content']  = $this->add_global_elements( (string) $data['post_content'], AWB_Demo_Page_Source::from_name( $demo_name ), $media );
		}

		// TODO: data meta.
		if ( $media ) {
			$data['avada_media'] = $media;

			// The builder sends this data back with each media request: what the page references is
			// imported from this prebuilt website ( AWB_Demo_Page_Source ), not from the Studio server.
			$data['demo_name'] = $demo_name;
		}

		$json_data = wp_json_encode( $data );

		die( $json_data ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/**
	 * Replaces the global element placeholders in a prebuilt website page with the elements' content.
	 *
	 * [fusion_global id="891"] points to a library item of the prebuilt website. On this site that ID is
	 * another post or nothing, so each element is fetched from the prebuilt website and imported as regular
	 * content, and its avada_media is added to the page's. A placeholder that can't be fetched is removed.
	 *
	 * @access protected
	 * @since 3.17.1
	 * @param string                    $content The page content.
	 * @param AWB_Demo_Page_Source|null $source  The prebuilt website.
	 * @param array                     $media   The page's avada_media, the elements' media is added to it.
	 * @param int                       $depth   Nesting level: a global element can hold other global elements.
	 * @return string
	 */
	protected function add_global_elements( $content, $source, &$media, $depth = 0 ) {

		// An element from the editor knows which global element it came from; here that ID is the prebuilt website's.
		$content = preg_replace( '/\sfusion_global=(["\']?)\d+\1/', '', $content );

		if ( false === strpos( $content, '[fusion_global' ) ) {
			return $content;
		}

		return preg_replace_callback(
			'/' . get_shortcode_regex( [ 'fusion_global' ] ) . '/',
			function ( $matches ) use ( $source, &$media, $depth ) {

				// An escaped [[fusion_global]] is text.
				if ( '[' === $matches[1] && ']' === $matches[6] ) {
					return $matches[0];
				}

				$atts    = shortcode_parse_atts( $matches[3] );
				$element = $source && 5 > $depth && is_array( $atts ) && isset( $atts['id'] ) ? $this->get_global_element( (int) $atts['id'], $source ) : false;

				if ( ! $element ) {
					return '';
				}

				$media = $this->merge_media( $media, $element['avada_media'] );

				return $this->add_global_elements( $element['content'], $source, $media, $depth + 1 );
			},
			$content
		);
	}

	/**
	 * Fetches a global element ( library item ) from a prebuilt website.
	 *
	 * @access protected
	 * @since 3.17.1
	 * @param int                  $id     The element's ID on the prebuilt website.
	 * @param AWB_Demo_Page_Source $source The prebuilt website.
	 * @return array|false Its content and avada_media, false when it can't be fetched.
	 */
	protected function get_global_element( $id, $source ) {
		if ( 0 >= $id ) {
			return false;
		}

		if ( isset( $this->global_elements[ $id ] ) ) {
			return $this->global_elements[ $id ];
		}

		// A page has a handful, more than that is not a prebuilt website's.
		if ( 30 <= count( $this->global_elements ) ) {
			return false;
		}

		$this->global_elements[ $id ] = false;

		$response = $source->get( 'wp/v2/fusion_element/' . $id . '/' );

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$element = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $element ) || ! isset( $element['content']['raw'] ) || ! is_string( $element['content']['raw'] ) ) {
			return false;
		}

		$this->global_elements[ $id ] = [
			'content'     => $element['content']['raw'],
			'avada_media' => isset( $element['avada_media'] ) && is_array( $element['avada_media'] ) ? $element['avada_media'] : [],
		];

		return $this->global_elements[ $id ];
	}

	/**
	 * Adds avada_media to another one: images, forms, post cards, … that aren't in it yet.
	 *
	 * @access protected
	 * @since 3.17.1
	 * @param array $media The avada_media.
	 * @param array $add   The avada_media to add.
	 * @return array
	 */
	protected function merge_media( $media, $add ) {
		foreach ( $add as $type => $items ) {
			if ( ! is_array( $items ) || ! $items ) {
				continue;
			}

			if ( ! isset( $media[ $type ] ) || ! is_array( $media[ $type ] ) ) {
				$media[ $type ] = [];
			}

			foreach ( $items as $key => $value ) {
				if ( ! isset( $media[ $type ][ $key ] ) ) {
					$media[ $type ][ $key ] = $value;
				} elseif ( is_array( $media[ $type ][ $key ] ) && is_array( $value ) ) {

					// An image's attributes to replace: the elements can use it with other attributes than the page.
					$media[ $type ][ $key ] += $value;
				}
			}
		}

		return $media;
	}

	/**
	 * Template used for website layouts.
	 *
	 * @access public
	 * @since 3.5
	 * @return void
	 */
	public function library_template() {
		?>
		<script type="text/html" id="tmpl-fusion_website_tags">
			<# var total = _.size( data ); #>
			<h3 class="awb-sites-heading-primary"><?php esc_html_e( 'Import Websites Pages', 'fusion-builder' ); ?></h3>
			<div class="awb-sites-search-wrapper">
				<span class="fusiona-search"></span>
				<input type="text" id="awb_sites_search_demos" placeholder="<?php esc_html_e( 'Paste page URL', 'fusion-builder' ); ?>">
			</div>
			<h4 class="awb-sites-heading-secondary"><?php esc_html_e( 'Filter Websites', 'fusion-builder' ); ?></h4>
			<ul>
				<li data-slug="all" class="current"><?php esc_html_e( 'All', 'fusion-builder' ); ?> <span>{{ total }}</span></li>
				<# _.each( tags, function( tag, slug ) { #>
				<li data-slug="{{ slug }}">{{{ tag.name }}} <span>{{ tag.count }}</span></li>
				<# } );#>
			</ul>
		</script>

		<script type="text/html" id="tmpl-fusion_website_layout">
			<#
			var slugs       = '';
			if ( 'object' === typeof tags ) {
				_.each( tags, function( tag ) {
					slugs += tag + ' ';
				} );
				slugs.trim();
			}

			#>
			<li class="fusion-page-layout awb-demo-pages-layout" data-website_id="{{ slug }}" data-website_title="{{{ post_title }}}" data-slug="{{ slugs }}">
				<div class="preview lazy-load">
					<# if ( 'undefined' !== typeof thumbnail ) { #>
					<img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%27{{ thumbnail.width }}%27%20height%3D%27{{ thumbnail.height }}%27%20viewBox%3D%270%200%20{{ thumbnail.width }}%20{{ thumbnail.height }}%27%3E%3Crect%20width%3D%27{{ thumbnail.width }}%27%20height%3D%273{{ thumbnail.height }}%27%20fill-opacity%3D%220%22%2F%3E%3C%2Fsvg%3E" alt="" width="{{ thumbnail.width }}" height="{{ thumbnail.height }}" data-src="{{ thumbnail.url }}" data-alt="{{ post_title }}"/>
					<# } #>
				</div>
				<div class="bar">
					<span class="fusion_module_title">{{ post_title }}</span>
				</div>
			</li>
		</script>

		<script type="text/html" id="tmpl-fusion_website_pages">
			<div class="awb-page-item demo-{{{ slug }}} hidden" data-website_id="{{ slug }}" data-website_title="{{{ post_title }}}">
				<div class="awb-page-wrap">
					<ul class="awb-website-pages">
						<#
						if ( 'undefined' !== typeof pages ) {
							_.each( pages, function( page, page_key ) {
								var site_link = page.link.replace( /^(https?):\/\//, '' );
						#>
								<li class="awb-demo-page-link" data-page-link="{{{ site_link }}}"><span>{{{ page.name }}}</span> <a href="{{{ page.link }}}" class="awb-sites-preview" target="_blank"><span class="fusiona-eye"></span> <?php esc_html_e( 'Preview', 'fusion-builder' ); ?></a> <a href="#" data-demo-name="{{{ slug }}}" data-page-name="{{ page_key }}" data-page-id="{{ page.ID }}" data-post-id="{{ <?php echo ( 'front' === $this->location ) ? '0' : 'fusionBuilderConfig.post_id'; ?> }}" class="button button-primary awb-sites-import-js"><?php esc_html_e( 'Import', 'fusion-builder' ); ?></a></li>
						<#
							} );
						} #>
					</ul>
					<# if ( 'undefined' !== typeof thumbnail ) { #>
					<img width="240" src="{{{ thumbnail.url }}}">
					<# } #>
				</div>
			</div>
		</script>

		<script type="text/template" id="fusion-builder-demo-import-modal">
			<div class="awb-admin-modal-wrap">
				<div class="awb-admin-modal-inner">

					<div class="awb-admin-modal-content">

						<h2 class="awb-studio-modal-title">
							<i class="fusiona-exclamation-sign"></i>
							<span><?php echo esc_html( __( 'Importing Prebuilt Page Content', 'fusion-builder' ) ); ?></span>
						</h2>

						<div class="awb-studio-modal-text">
							<?php echo esc_html( __( 'Your prebuilt page content is now being imported. This includes the layout, and any associated images and videos. The import process should only take a few seconds, depending on the amount of content to be imported.', 'fusion-builder' ) ); ?>
						</div>
					</div>

					<div class="awb-admin-modal-status-bar">
						<div class="awb-admin-modal-status-bar-label"><span></span></div>
						<div class="awb-admin-modal-status-bar-progress-bar"></div>

						<a class="button-done-demo demo-update-modal-close" href="#"><?php esc_html_e( 'Done' ); ?></a>
					</div>
				</div>

				<a href="#" class="awb-admin-modal-corner-close"><span class="dashicons dashicons-no-alt"></span></a>
			</div>

			<div class="awb-modal-overlay"></div>
		</script>
		<?php
	}
}

/**
 * Instantiates the AWB_Demo_Import class.
 * Make sure the class is properly set-up.
 *
 * @since object 3.0
 * @return object AWB_Demo_Import
 */
function AWB_Demo_Import() { // phpcs:ignore WordPress.NamingConventions
	return AWB_Demo_Import::get_instance();
}
AWB_Demo_Import();

/**
 * A prebuilt website as the source of what one of its pages references, for AWB_Studio_Import::set_source().
 *
 * A page loaded from the Websites tab references the global elements, forms, Post Cards and icon sets of its
 * prebuilt website by their IDs there. Those are fetched from that website, not from the Studio server, where
 * the same IDs are other items or nothing.
 *
 * @since 3.17.1
 */
class AWB_Demo_Page_Source {

	/**
	 * Where the prebuilt websites are.
	 *
	 * @var string
	 */
	const BASE_URL = 'https://classic.avada.com';

	/**
	 * The prebuilt website, its path on BASE_URL: business-coach.
	 *
	 * @access private
	 * @var string
	 */
	private $demo;

	/**
	 * Constructor, see from_name().
	 *
	 * @access private
	 * @since 3.17.1
	 * @param string $demo The prebuilt website's path.
	 */
	private function __construct( $demo ) {
		$this->demo = $demo;
	}

	/**
	 * A source for a prebuilt website's name as the Websites tab has it ( business_coach or business-coach ),
	 * or null when it isn't one. The name comes back from the browser with each media request, so it is
	 * only ever a path on BASE_URL.
	 *
	 * @access public
	 * @since 3.17.1
	 * @param mixed $name The name.
	 * @return AWB_Demo_Page_Source|null
	 */
	public static function from_name( $name ) {
		if ( ! is_string( $name ) || ! preg_match( '/^[a-z0-9]+(?:[_-][a-z0-9]+)*$/', $name ) || 64 < strlen( $name ) ) {
			return null;
		}

		return new self( str_replace( '_', '-', $name ) );
	}

	/**
	 * The prebuilt website's name.
	 *
	 * @access public
	 * @since 3.17.1
	 * @return string
	 */
	public function get_name() {
		return $this->demo;
	}

	/**
	 * Keeps imports from prebuilt websites apart from the Studio server's, and from each other's.
	 *
	 * @access public
	 * @since 3.17.1
	 * @return string
	 */
	public function key_prefix() {
		return 'demo-' . $this->demo . '-';
	}

	/**
	 * Fetch a REST path from the prebuilt website.
	 *
	 * @access public
	 * @since 3.17.1
	 * @param string $path Path after /wp-json/, e.g. wp/v2/fusion_form/12/.
	 * @return array|WP_Error As wp_remote_get().
	 */
	public function get( $path ) {
		$path = ltrim( (string) $path, '/' );

		// The prebuilt websites have the posts only, not the Studio server's menu and image routes.
		if ( 0 !== strpos( $path, 'wp/v2/' ) ) {
			return new WP_Error( 'awb_demo_route', __( 'The prebuilt website does not provide this item.', 'fusion-builder' ) );
		}

		$response = wp_safe_remote_get( self::BASE_URL . '/' . $this->demo . '/wp-json/' . $path, [ 'timeout' => 60 ] );

		// An icon set can only be installed with its package: without it, it would be an empty set.
		if ( ! is_wp_error( $response ) && 0 === strpos( $path, 'wp/v2/fusion_icons/' ) ) {
			$body  = json_decode( wp_remote_retrieve_body( $response ), true );
			$media = is_array( $body ) && isset( $body['avada_media'] ) && is_array( $body['avada_media'] ) ? $body['avada_media'] : [];

			if ( empty( $media['package_url'] ) ) {
				return new WP_Error( 'awb_demo_icon_set', __( 'The icon set could not be imported from the prebuilt website.', 'fusion-builder' ) );
			}
		}

		return $response;
	}
}
