<?php
/**
 * The Rich Text form field: what its submitted HTML may contain, and its images.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://avada.com
 * @package    Avada Builder
 * @subpackage forms
 * @since      3.17
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Server side of the Rich Text field.
 *
 * The field submits HTML. Which fields are rich text, and which tools they have, is read from the form
 * itself, never from what the browser says, so no other field can be made to accept HTML. What a rich
 * text value may contain, as far as the field's tools offer it:
 * - paragraphs, line breaks, bold, italic, links, level 2, 3 and 4 headings, lists and quotes;
 * - placeholders for elements, marked with data-awb-el: an image (a figure), a button (a paragraph
 *   holding a link), a checklist (a list) and the read more mark (a line, once);
 * - text colours from the global palette and the alignment of paragraphs, headings and quotes, as
 *   data attributes the style is built from here: no submitted style attribute is ever kept;
 * - images only as files uploaded with the same submission: a submitted src is always removed.
 * Shortcode brackets are encoded, so a value can never run a shortcode wherever it ends up.
 *
 * @since 3.17
 */
class AWB_Form_Rich_Text {

	/**
	 * The field's shortcode.
	 */
	const SHORTCODE = 'fusion_form_rich_text';

	/**
	 * The image types the field accepts.
	 */
	const IMAGE_EXTENSIONS = [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ];

	/**
	 * The longest value accepted, in bytes of HTML.
	 */
	const MAX_LENGTH = 100000;

	/**
	 * The alignments a block can have.
	 */
	const ALIGNMENTS = [ 'left', 'center', 'right' ];

	/**
	 * The rich text fields of the forms looked up, by form ID.
	 *
	 * @static
	 * @access private
	 * @var array
	 */
	private static $fields = [];

	/**
	 * The name of the file input holding a field's images.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param string $name The field name.
	 * @return string
	 */
	public static function images_name( $name ) {
		return $name . '_images';
	}

	/**
	 * The HTML a value may contain: paragraphs and line breaks, and what the field's tools add.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param array $tools The field's tools, see get_tools().
	 * @return array As wp_kses() takes it.
	 */
	public static function get_allowed_html( $tools ) {
		$element = [ 'data-awb-el' => true ];
		$align   = [ 'data-awb-align' => true ];
		$allowed = [
			'p'  => [],
			'br' => [],
		];
		$by_tool = [
			'bold'      => [ 'strong' => [], 'b' => [] ],
			'italic'    => [ 'em' => [], 'i' => [] ],
			'heading'   => [ 'h2' => [], 'h3' => [], 'h4' => [] ],
			'lists'     => [ 'ul' => [], 'ol' => [], 'li' => [] ],
			'quote'     => [ 'blockquote' => [] ],
			'link'      => [ 'a' => [ 'href' => true ] ],
			'image'     => [ 'figure' => $element, 'img' => [ 'alt' => true, 'data-awb-file' => true ] ],
			'button'    => [ 'p' => $element, 'a' => [ 'href' => true ] ],
			'checklist' => [ 'ul' => $element, 'li' => [] ],
			'color'     => [ 'span' => [ 'data-awb-color' => true ] ],
			'align'     => [ 'p' => $align, 'h2' => $align, 'h3' => $align, 'h4' => $align, 'blockquote' => $align ],
			'more'      => [ 'hr' => $element ],
		];
		foreach ( $tools as $tool ) {
			foreach ( isset( $by_tool[ $tool ] ) ? $by_tool[ $tool ] : [] as $tag => $attributes ) {
				$allowed[ $tag ] = array_merge( isset( $allowed[ $tag ] ) ? $allowed[ $tag ] : [], $attributes );
			}
		}

		/**
		 * Filters the HTML a Rich Text form field may submit.
		 *
		 * @since 3.17
		 * @param array $allowed As wp_kses() takes it.
		 * @param array $tools   The field's tools.
		 */
		return apply_filters( 'awb_form_rich_text_allowed_html', $allowed, $tools );
	}

	/**
	 * The rich text fields of a form, read from its content.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param int $form_id The form's post ID.
	 * @return array Field name => [ tools: array, images: bool, max_images: int, upload_size: float (MB) ].
	 */
	public static function get_fields( $form_id ) {
		$form_id = (int) $form_id;
		if ( isset( self::$fields[ $form_id ] ) ) {
			return self::$fields[ $form_id ];
		}

		$fields = [];
		$form   = $form_id ? get_post( $form_id ) : null;
		if ( $form && 'fusion_form' === $form->post_type && false !== strpos( $form->post_content, '[' . self::SHORTCODE ) ) {
			preg_match_all( '/\[' . self::SHORTCODE . '\s+([^\]]*)\]/i', $form->post_content, $matches );
			foreach ( $matches[1] as $attributes ) {
				$atts = shortcode_parse_atts( rtrim( $attributes, '/ ' ) );
				if ( empty( $atts['name'] ) ) {
					continue;
				}
				$toolbar = isset( $atts['toolbar'] ) ? explode( ',', $atts['toolbar'] ) : self::get_default_toolbar();

				$fields[ $atts['name'] ] = [
					'tools'       => array_values( array_intersect( array_map( 'trim', $toolbar ), array_keys( self::get_tools() ) ) ),
					'images'      => in_array( 'image', $toolbar, true ),
					'max_images'  => isset( $atts['max_images'] ) ? max( 1, (int) $atts['max_images'] ) : 5,
					'upload_size' => isset( $atts['upload_size'] ) ? max( 0.1, (float) $atts['upload_size'] ) : 2.0,
				];
			}
		}

		self::$fields[ $form_id ] = $fields;
		return $fields;
	}

	/**
	 * The toolbar buttons, by key.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @return array Key => label.
	 */
	public static function get_tools() {
		return [
			'bold'      => esc_attr__( 'Bold', 'fusion-builder' ),
			'italic'    => esc_attr__( 'Italic', 'fusion-builder' ),
			'color'     => esc_attr__( 'Text Color', 'fusion-builder' ),
			'heading'   => esc_attr__( 'Headings', 'fusion-builder' ),
			'lists'     => esc_attr__( 'Lists', 'fusion-builder' ),
			'quote'     => esc_attr__( 'Quote', 'fusion-builder' ),
			'align'     => esc_attr__( 'Alignment', 'fusion-builder' ),
			'link'      => esc_attr__( 'Link', 'fusion-builder' ),
			'image'     => esc_attr__( 'Image', 'fusion-builder' ),
			'button'    => esc_attr__( 'Button', 'fusion-builder' ),
			'checklist' => esc_attr__( 'Checklist', 'fusion-builder' ),
		];
	}

	/**
	 * The toolbar buttons a field has unless chosen otherwise: the main ones. Text colour, alignment and
	 * read more are added by the form's author.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @return array
	 */
	public static function get_default_toolbar() {
		return array_values( array_diff( array_keys( self::get_tools() ), [ 'color', 'align', 'more' ] ) );
	}

	/**
	 * The text colours offered: the global palette's.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @return array Palette key => [ label, color ].
	 */
	public static function get_colors() {
		$colors = [];
		if ( function_exists( 'AWB_Global_Colors' ) ) {
			foreach ( AWB_Global_Colors()->get_palette() as $key => $color ) {
				if ( is_array( $color ) && isset( $color['color'] ) && preg_match( '/^[a-z0-9_]+$/', $key ) ) {
					$colors[ $key ] = [
						'label' => isset( $color['label'] ) ? $color['label'] : $key,
						'color' => $color['color'],
					];
				}
			}
		}
		return $colors;
	}

	/**
	 * Cleans a submitted value down to the allowed HTML.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param mixed $value The submitted value.
	 * @param array $tools The field's tools: only what they add is kept.
	 * @return string
	 */
	public static function sanitize( $value, $tools ) {
		if ( ! is_string( $value ) ) {
			return '';
		}

		$html = wp_check_invalid_utf8( $value );
		if ( strlen( $html ) > self::MAX_LENGTH ) {
			$html = force_balance_tags( substr( $html, 0, self::MAX_LENGTH ) );
		}

		$html = self::strip_comments( wp_kses( self::strip_comments( $html ), self::get_allowed_html( $tools ) ) );

		// Only the element placeholders of the field's tools keep their marker, each on its own tag.
		$markers = [
			'image'     => 'FIGURE',
			'button'    => 'P',
			'checklist' => 'UL',
			'more'      => 'HR',
		];
		$colors  = in_array( 'color', $tools, true ) ? self::get_colors() : [];
		$tags    = new WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag() ) {
			$element = $tags->get_attribute( 'data-awb-el' );
			if ( null !== $element && ( ! isset( $markers[ $element ] ) || $markers[ $element ] !== $tags->get_tag() || ! in_array( $element, $tools, true ) ) ) {
				$tags->remove_attribute( 'data-awb-el' );
			}

			// The style comes from a palette colour or an alignment only, built here.
			$color = $tags->get_attribute( 'data-awb-color' );
			if ( null !== $color ) {
				if ( is_string( $color ) && isset( $colors[ $color ] ) ) {
					$tags->set_attribute( 'style', self::get_color_style( $color, $colors[ $color ]['color'] ) );
				} else {
					$tags->remove_attribute( 'data-awb-color' );
				}
			}
			$align = $tags->get_attribute( 'data-awb-align' );
			if ( null !== $align ) {
				if ( is_string( $align ) && in_array( $align, self::ALIGNMENTS, true ) ) {
					$tags->set_attribute( 'style', 'text-align:' . $align );
				} else {
					$tags->remove_attribute( 'data-awb-align' );
				}
			}

			// Links go to web or mail addresses only: kses leaves what's after a removed protocol behind.
			$href = 'A' === $tags->get_tag() ? $tags->get_attribute( 'href' ) : null;
			if ( is_string( $href ) && ! preg_match( '#^(https?://|mailto:)#i', $href ) ) {
				$tags->remove_attribute( 'href' );
			}
		}
		$html = $tags->get_updated_html();

		// One read more mark, and no other lines.
		if ( false !== stripos( $html, '<hr' ) ) {
			$more = false;
			$html = preg_replace_callback(
				'/<hr\b[^>]*>/i',
				function ( $match ) use ( &$more ) {
					if ( ! $more && false !== strpos( $match[0], 'data-awb-el="more"' ) ) {
						$more = true;
						return '<hr data-awb-el="more" />';
					}
					return '';
				},
				$html
			);
		}

		// Shortcodes stay text, wherever the value ends up.
		$html = str_replace( [ '[', ']' ], [ '&#91;', '&#93;' ], $html );

		return self::is_empty( $html ) ? '' : trim( $html );
	}

	/**
	 * Removes HTML comments, which kses keeps whatever it allows. A block comment ("<!-- wp:... -->")
	 * would become a block wherever the value is put into content. Removed until none are left, so
	 * that taking one out can't join two halves into another.
	 *
	 * @static
	 * @access private
	 * @since 3.17
	 * @param string $html The HTML.
	 * @return string
	 */
	private static function strip_comments( $html ) {
		do {
			$before = $html;
			$html   = (string) preg_replace( '/<!--.*?(?:-->|$)/s', '', $html );
		} while ( $before !== $html );

		return $html;
	}

	/**
	 * The style of a palette colour: its value for where the site's colour variables don't exist (an
	 * email), then the variable, so the text follows the palette on the site.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param string $key   The palette key.
	 * @param string $value The colour's value.
	 * @return string
	 */
	public static function get_color_style( $key, $value ) {
		$style = '';
		if ( is_string( $value ) && preg_match( '/^(#[0-9a-f]{3,8}|(rgba?|hsla?)\([0-9.,%\s\/-]+\))$/i', trim( $value ) ) ) {
			$style = 'color:' . trim( $value ) . ';';
		}
		return $style . 'color:var(--awb-' . $key . ')';
	}

	/**
	 * Gives the value's images the URLs of the files uploaded with it, in the order they were added.
	 * Images without an uploaded file are removed, along with figures left empty.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param string $html    The sanitized value.
	 * @param string $name    The field name.
	 * @param array  $uploads The uploaded files' URLs, by upload name (field@|@number, or field for one file).
	 * @return string
	 */
	public static function attach_images( $html, $name, $uploads ) {
		if ( false === strpos( $html, '<img' ) ) {
			return $html;
		}

		$base = self::images_name( $name );
		$tags = new WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag( 'img' ) ) {
			$number = absint( $tags->get_attribute( 'data-awb-file' ) );
			$url    = '';
			if ( $number && isset( $uploads[ $base . '@|@' . $number ] ) ) {
				$url = $uploads[ $base . '@|@' . $number ];
			} elseif ( 1 === $number && isset( $uploads[ $base ] ) ) {
				$url = $uploads[ $base ];
			}

			$tags->remove_attribute( 'data-awb-file' );
			if ( $url ) {
				$tags->set_attribute( 'src', esc_url_raw( $url ) );
			}
		}
		$html = $tags->get_updated_html();

		// The images left without a file, then the figures they leave empty.
		$html = preg_replace( '/<img(?![^>]*\ssrc=)[^>]*>/i', '', $html );
		$html = preg_replace( '/<figure[^>]*>\s*<\/figure>/i', '', $html );

		return trim( $html );
	}

	/**
	 * Whether a value has no text and no images.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param string $html The value.
	 * @return bool
	 */
	public static function is_empty( $html ) {
		return '' === trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ), " \t\n\r\0\x0B\xC2\xA0" ) && false === stripos( $html, '<img' );
	}
}
