<?php
/**
 * Lightbox options.
 *
 * @package Fusion-Library
 * @since 3.17
 */

/**
 * Carries the iLightbox options over to the lightbox that replaced it.
 *
 * The scripts load through the fusion-lightbox handle, which elements already enqueue: it is the compat script, which
 * gives their iLightbox markup the current lightbox attributes, and it depends on the lightbox loader.
 *
 * @since 3.17
 */
class AWB_Lightbox {

	/**
	 * The one true instance.
	 *
	 * @static
	 * @access private
	 * @since 3.17
	 * @var AWB_Lightbox|null
	 */
	private static $instance = null;

	/**
	 * Gets the instance.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @return AWB_Lightbox
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * The class constructor.
	 *
	 * @access private
	 * @since 3.17
	 */
	private function __construct() {
		add_action( 'admin_init', [ $this, 'migrate_options' ] );
	}

	/**
	 * Moves values saved under the iLightbox options to the new ones, once, so the options panel shows what the front
	 * end uses: Animation Speed to Opening Speed, Thumbnails Position ( vertical / horizontal ) to the new positions and
	 * the Slide Direction, and the iLightbox skins to the color schemes.
	 *
	 * @access public
	 * @since 3.17
	 * @return void
	 */
	public function migrate_options() {
		if ( ! class_exists( 'Avada' ) ) {
			return;
		}

		$name  = Avada::get_option_name();
		$saved = get_option( $name );

		if ( ! is_array( $saved ) ) {
			return;
		}

		$old = [
			'lightbox_opening_speed'   => isset( $saved['lightbox_animation_speed'] ) && ! isset( $saved['lightbox_opening_speed'] ),
			'lightbox_thumbs_position' => isset( $saved['lightbox_path'] ) && ! isset( $saved['lightbox_thumbs_position'] ),
			'lightbox_direction'       => isset( $saved['lightbox_path'] ) && ! isset( $saved['lightbox_direction'] ),
			'lightbox_skin'            => isset( $saved['lightbox_skin'] ) && ! in_array( $saved['lightbox_skin'], [ 'light', 'dark', 'colors' ], true ),
		];

		if ( ! in_array( true, $old, true ) ) {
			return;
		}

		foreach ( array_keys( array_filter( $old ) ) as $id ) {
			$saved[ $id ] = (string) self::get_option( $id );
		}

		update_option( $name, $saved );
	}

	/**
	 * Gets a lightbox option. Values saved under the iLightbox options are carried over until the new option is saved:
	 * Animation Speed ( fast / normal / slow ), Thumbnails Position ( vertical / horizontal ), which also set the slide
	 * direction in iLightbox, and the iLightbox skins.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param string $id The option ID.
	 * @return mixed
	 */
	public static function get_option( $id ) {
		$saved = class_exists( 'Avada' ) ? get_option( Avada::get_option_name() ) : [];
		$saved = is_array( $saved ) ? $saved : [];
		$value = fusion_library()->get_option( $id );

		if ( 'lightbox_opening_speed' === $id && ! isset( $saved[ $id ] ) && isset( $saved['lightbox_animation_speed'] ) ) {
			$speeds = [
				'fast'   => 100,
				'normal' => 400,
				'slow'   => 800,
			];
			$value  = $speeds[ $saved['lightbox_animation_speed'] ] ?? 400;
		} elseif ( 'lightbox_thumbs_position' === $id && ! isset( $saved[ $id ] ) && isset( $saved['lightbox_path'] ) ) {
			$value = 'horizontal' === $saved['lightbox_path'] ? 'bottom' : 'right';
		} elseif ( 'lightbox_direction' === $id && ! isset( $saved[ $id ] ) && isset( $saved['lightbox_path'] ) ) {
			$value = 'horizontal' === $saved['lightbox_path'] ? 'horizontal' : 'vertical';
		} elseif ( 'lightbox_skin' === $id && ! in_array( $value, [ 'light', 'dark', 'colors' ], true ) ) {
			$value = in_array( $value, [ 'metro-black', 'parade', 'smooth' ], true ) ? 'dark' : 'light';
		}

		return $value;
	}

	/**
	 * Gets the srcset of a lightbox link to an attachment's full image, for its data-awb-lightbox-srcset attribute.
	 * Phones then load a smaller file than the original. Empty when the link goes elsewhere.
	 *
	 * @static
	 * @access public
	 * @since 3.17
	 * @param int    $attachment_id The attachment ID.
	 * @param string $url           The link's URL.
	 * @return string
	 */
	public static function get_srcset( $attachment_id, $url ) {
		$full = $attachment_id ? wp_get_attachment_image_src( (int) $attachment_id, 'full' ) : false;

		if ( ! $full || $full[0] !== $url ) {
			return '';
		}

		return (string) wp_get_attachment_image_srcset( (int) $attachment_id, 'full' );
	}
}
