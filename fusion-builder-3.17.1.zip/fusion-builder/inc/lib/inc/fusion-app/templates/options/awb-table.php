<?php
/**
 * Underscore.js template.
 *
 * The table editor (fusion-builder js/awb-table-editor.js) builds itself inside
 * the container and keeps the textarea in sync with the table markup. Features
 * the param switches off, ex: 'features' => [ 'marks' => false ], are left out.
 *
 * @since 3.17
 * @package fusion-library
 */

?>
<div class="awb-table-editor" data-param="{{ param.param_name }}"<# if ( param.features ) { #> data-features="{{ JSON.stringify( param.features ) }}"<# } #>></div>
<textarea
	name="{{ param.param_name }}"
	id="{{ param.param_name }}"
	class="awb-table-editor-value"
	hidden
>{{ option_value }}</textarea>
