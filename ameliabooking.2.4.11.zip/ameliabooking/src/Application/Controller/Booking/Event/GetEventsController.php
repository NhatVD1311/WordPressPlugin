<?php

namespace AmeliaBooking\Application\Controller\Booking\Event;

use AmeliaBooking\Application\Commands\Booking\Event\GetEventsCommand;
use AmeliaBooking\Application\Controller\Controller;
use AmeliaVendor\Psr\Http\Message\ServerRequestInterface as Request;

/**
 * Class GetEventsController
 *
 * @package AmeliaBooking\Application\Controller\Booking\Event
 */
class GetEventsController extends Controller
{
    /**
     * Instantiates the Get Events command to hand it over to the Command Handler
     *
     * @param Request $request
     * @param         $args
     *
     * @return GetEventsCommand
     * @throws \RuntimeException
     */
    protected function instantiateCommand(Request $request, $args)
    {
        $command = new GetEventsCommand($args);

        $params = (array)$request->getQueryParams();

        if (isset($params['source'])) {
            $command->setPage($params['source']);
            unset($params['source']);
        }

        $this->setArrayParams($params);

        if (isset($params['events'])) {
            $params['events'] = array_map('intval', $params['events']);
        }

        if (isset($params['excludeIds'])) {
            $params['excludeIds'] = array_map('intval', $params['excludeIds']);
        }

        $command->setField('params', $params);

        $command->setToken($request);

        return $command;
    }
}
