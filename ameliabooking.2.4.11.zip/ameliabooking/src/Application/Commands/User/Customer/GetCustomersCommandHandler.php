<?php

namespace AmeliaBooking\Application\Commands\User\Customer;

use AmeliaBooking\Application\Commands\CommandHandler;
use AmeliaBooking\Application\Commands\CommandResult;
use AmeliaBooking\Application\Common\Exceptions\AccessDeniedException;
use AmeliaBooking\Application\Services\CustomField\AbstractCustomFieldApplicationService;
use AmeliaBooking\Domain\Collection\Collection;
use AmeliaBooking\Domain\Common\Exceptions\InvalidArgumentException;
use AmeliaBooking\Domain\Entity\Entities;
use AmeliaBooking\Domain\Entity\User\AbstractUser;
use AmeliaBooking\Domain\Factory\User\UserFactory;
use AmeliaBooking\Domain\Services\Settings\SettingsService;
use AmeliaBooking\Infrastructure\Common\Exceptions\QueryExecutionException;
use AmeliaBooking\Infrastructure\Repository\Booking\Appointment\CustomerBookingRepository;
use AmeliaBooking\Infrastructure\Repository\CustomField\CustomFieldRepository;
use AmeliaBooking\Infrastructure\Repository\User\CustomerRepository;
use AmeliaBooking\Infrastructure\Repository\User\UserRepository;
use Exception;

/**
 * Class GetCustomersCommandHandler
 *
 * @package AmeliaBooking\Application\Commands\User\Customer
 */
class GetCustomersCommandHandler extends CommandHandler
{
    /**
     * @param GetCustomersCommand $command
     *
     * @return CommandResult
     * @throws InvalidArgumentException
     * @throws QueryExecutionException
     * @throws Exception
     * @throws AccessDeniedException
     */
    public function handle(GetCustomersCommand $command)
    {
        /** @var AbstractUser $user */
        $user = $this->container->get('logged.in.user');

        if (!$command->getPermissionService()->currentUserCanRead(Entities::CUSTOMERS)) {
            $user = $command->authorize(Entities::PROVIDER);
        }

        $result = new CommandResult();

        /** @var CustomerRepository $customerRepository */
        $customerRepository = $this->getContainer()->get('domain.users.customers.repository');

        /** @var UserRepository $userRepository */
        $userRepository = $this->container->get('domain.users.repository');

        /** @var CustomFieldRepository $customFieldRepository */
        $customFieldRepository = $this->container->get('domain.customField.repository');

        /** @var SettingsService $settingsService */
        $settingsService = $this->container->get('domain.settings.service');

        $rolesSettings = $settingsService->getCategorySettings('roles');

        $params = $command->getField('params');

        $countParams = [];

        $itemsPerPage = !empty($params['limit']) ? (int)$params['limit'] : 10;

        $allowedCustomerIds = null;

        if (
            $user !== null &&
            $user->getType() === Entities::PROVIDER &&
            empty($rolesSettings['allowReadAllCustomers'])
        ) {
            /** @var Collection $providerCustomers */
            $providerCustomers = $userRepository->getProviderAllowedCustomers(
                $user->getId()->getValue()
            );

            $allowedCustomerIds = $providerCustomers->keys();

            $params['customers'] = empty($params['customers'])
                ? $allowedCustomerIds
                : array_intersect(
                    array_map('intval', $params['customers']),
                    $allowedCustomerIds
                );

            $countParams['customers'] = $params['customers'];
        }

        $users = $customerRepository->getFiltered(
            array_merge($params, ['ignoredBookings' => empty($params['noShow'])]),
            $itemsPerPage
        );

        if (!empty($params['includeCustomers'])) {
            $includeCustomerIds = $params['includeCustomers'];

            // Apply provider allowlist if restricted
            if ($allowedCustomerIds !== null) {
                $includeCustomerIds = array_values(array_intersect(
                    array_map('intval', $includeCustomerIds),
                    $allowedCustomerIds
                ));
            }

            if (!empty($includeCustomerIds)) {
                $additionalCustomers = $customerRepository->getFiltered(
                    [
                        'customers'       => $includeCustomerIds,
                        'ignoredBookings' => empty($params['noShow'])
                    ]
                );

                foreach ($additionalCustomers as $customerId => $customerData) {
                    if (!isset($users[$customerId])) {
                        $users[$customerId] = $customerData;
                    }
                }
            }
        }

        if (!empty($users)) {
            $usersWithBookingsStats = $customerRepository->getFiltered(
                array_merge($params, ['ignoredBookings' => false, 'customers' => array_keys($users)]),
                null
            );

            foreach ($users as $key => $user) {
                $users[$key] = $usersWithBookingsStats[$key];
            }
        }

        $customersNoShowCount = [];

        $noShowTagEnabled = $settingsService->isFeatureEnabled('noShowTag');

        if ($noShowTagEnabled && $users) {
            /** @var CustomerBookingRepository $bookingRepository */
            $bookingRepository = $this->container->get('domain.booking.customerBooking.repository');

            $usersIds = array_map(
                function ($user) {
                    return $user['id'];
                },
                $users
            );

            $customersNoShowCount =  $usersIds ? $bookingRepository->countByNoShowStatus($usersIds) : [];

            $customersNoShowCount = $customersNoShowCount ? array_values($customersNoShowCount) : [];
        }

        /** @var AbstractCustomFieldApplicationService $customFieldService */
        $customFieldService = $this->container->get('application.customField.service');

        /** @var Collection $customFieldsCollection */
        $customFieldsCollection = $customFieldRepository->getAll([], false);

        $users = array_values($users);

        foreach ($users as $key => &$user) {
            $user['wpUserPhotoUrl'] = $this->container->get('user.avatar')->getAvatar($user['externalId']);

            if ($noShowTagEnabled) {
                $user['noShowCount'] = $customersNoShowCount[$key]['count'];
            }

            $customFields = [];

            if (!empty($user['customFields'])) {
                $user['customFields'] = $customFieldService->reformatCustomField(UserFactory::create($user), $customFields, $customFieldsCollection);
            }

            $user = array_map(
                function ($v) {
                    return (null === $v) ? '' : $v;
                },
                $user
            );
        }

        $users = apply_filters('amelia_get_customers_filter', $users);

        do_action('amelia_get_customers', $users);

        $resultData = [
            Entities::USER . 's' => $users,
        ];

        if (empty($params['skipCount'])) {
            $resultData['filteredCount'] = (int)$customerRepository->getCount($params);

            $resultData['totalCount'] = (int)$customerRepository->getCount($countParams);
        }

        $result->setResult(CommandResult::RESULT_SUCCESS);
        $result->setMessage('Successfully retrieved users.');
        $result->setData($resultData);

        return $result;
    }
}
