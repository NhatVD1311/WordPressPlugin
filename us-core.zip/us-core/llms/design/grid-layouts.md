# Grid Layout authoring

A Grid Layout is the card template of a list: it decides what one item looks like in `[us_post_list]`, `[us_product_list]`, `[us_user_list]`, `[us_term_list]` and their carousels (`[us_post_carousel]`, …). Custom layouts are `us_grid_layout` records holding a Grid Builder JSON config, **not** shortcode markup, so the generic `create-post` / `update-post` tools refuse them. Use these tools instead:

- `upsolution-list-grid-layouts` — custom records (numeric id) and built-in templates (keys like `blog_1`). Each item has a `selector`.
- `upsolution-get-grid-layout` — one layout, fully expanded. Works for both families; templates come back with `read_only: true`. **Read this immediately before `update-grid-layout`** — element ids, the order in each cell and the current values all come from here.
- `upsolution-create-grid-layout` — new record from a template, as a copy of a record, or `blank`.
- `upsolution-update-grid-layout` — transactional edit (elements / options / layout).
- `upsolution-delete-grid-layout` — trash.

Built-in templates are **read-only**: `update` / `delete` with a template key fail with 400. To customise one, copy it: `create-grid-layout { title, source: "blog_1" }`, then edit the new record.

## Using a layout in a list

A list picks its card with the `items_layout` attribute; the value is the layout's `selector` (a record id like `items_layout="1234"` or a template key like `items_layout="blog_1"`). Setting it on an existing list is a content edit — change the shortcode attribute via `upsolution-update-post`. Editing a layout changes every list that uses it, immediately.

If a record is trashed, lists that use it fall back to their element's default template (`blog_1` for Post List, `shop_standard` for Product List, `user_1` for User List) until it is restored. A trashed record can't be edited — restore it from wp-admin first.

## The settings shape

```jsonc
{
  "selector": 1234, "source": "post", "title": "Product card", "read_only": false,
  "options": { "color_bg": "", "border_radius": "", "box_shadow": "0.3rem", … },   // every option, defaults filled in
  "layout": {
    "middle_center": ["post_image:1", "post_title:1", "hwrapper:1", "btn:1"], // the card, top to bottom
    "hwrapper:1": ["post_date:1", "post_taxonomy:1"],                         // children of a container
    "hidden": []                                                              // in data but not placed — not shown
  },
  "elements": [ { "elm_id": "post_title:1", "type": "post_title", "params": { "tag": "h2", … } }, … ]
}
```

- **One cell.** A card has a single cell, `middle_center`; its array order is the render order (top to bottom). Unlike headers there are no responsive states for the layout — responsive differences go into each element's `css` (see Design below).
- **Containers** are elements whose id is also a layout key holding their children: `hwrapper` (horizontal row), `vwrapper` (vertical stack), `vc_tta_tabs` / `vc_tta_accordion` / `vc_tta_tour` (hold `vc_tta_section` only) and `vc_tta_section` (holds regular elements).
- **Element ids** are `type:N` (`post_title:1`, `btn:2`). The number is a per-type counter; ids are stable once created.
- `get-grid-layout` and `update-grid-layout` return every option and every editable param with its current value (defaults included), so you can see what is set.

## Layout options (`set_options`)

Flat `{ option: value }`. Colors accept the `upsolution-set-palette` syntax (hex, `rgb()/rgba()`, `transparent`, a palette token `"_slug"` such as `_content_bg_alt`, `linear-gradient(...)` on `color_bg`) and a custom field color `"{{field_name}}"`. Switches are `1` / `0`.

- `color_bg`, `color_text` — card background / text color. `ignore_us_tile_colors` — ignore per-post colors from the post's Additional Settings.
- `border_radius` — CSS length, e.g. `"0.5rem"`. `box_shadow`, `box_shadow_hover` — shadow size, `"0rem"`–`"3rem"` (e.g. `"0.3rem"`, `"1rem"` on hover).
- `fixed` + `aspect_ratio` — fixed card proportions (`"1"`, `"4/3"`, `"16/9"`); `overflow` — hide overflowing content (when not fixed).
- `bg_img_source` — `none` | `media` (then `bg_img` = attachment id) | `featured` | `us_tile_additional_image` | an image custom field key; with `bg_file_size`, `bg_img_size` (`cover` | `contain`), `bg_img_position` (e.g. `"center center"`), `bg_img_repeat`.
- `el_class` — extra CSS class on the list.

## Element catalog

Each element's params are validated against the theme's element config. `get-grid-layout` shows every param of every instance — read it to see exact names and current values. Below are the params you will usually set.

**Universal params — every element also accepts:**
- `css` — the **Design** settings, a responsive map `{ "<state>": { "<css-prop>": "<value>" } }` with states `default`, `laptops`, `tablets`, `mobiles`. This is how you set font size, weight, color, margins, padding, borders and so on for one element: `{"css":{"default":{"font-size":"1.2rem","margin-bottom":"0.5rem"},"mobiles":{"font-size":"1rem"}}}`. Pass `""` to clear. Values may use palette tokens (`"_content_faded"`) and custom fields (`"{{field_name}}"`).
- `hide_on_states` — CSS-hides the element on the listed states, e.g. `["mobiles"]`.
- `el_class` / `el_id`, `conditions` / `conditions_operator` (display logic).

Post data:
- **`post_title`** — `tag` (`h1`…`h6` / `div` / `p` / `span`), `link` (default: the post), `color_link`, `align`, `shorten_length` + `shorten_length_count`, `show_count` (product count for terms).
- **`post_image`** — `thumbnail_size` (any registered size slug), `link`, `placeholder`, `media_preview` (video / gallery preview), `circle`, `stretch`, `disable_lazy_loading`.
- **`post_date`** — `type` (`published` | `modified`), `format` (`smart` | `time_diff` | `default` | `jS F Y` | `j M, G:i` | `m/d/Y` | `j.m.y` | `custom` + `format_custom`), `icon`, `text_before`, `text_after`.
- **`post_taxonomy`** — `taxonomy_name` (a taxonomy slug: `category`, `post_tag`, `product_cat`, …), `style` (`simple` | `badge`, then `btn_style`), `separator`, `link`, `color_link`, `icon`, `text_before` / `text_after`.
- **`post_content`** — `type` (`excerpt_content` | `excerpt_only` | `part_content` | `full_content`), `excerpt_length` / `length`, `show_more_toggle`.
- **`post_custom_field`** — `key` = a custom field key (ACF field names, `us_tile_*`, …; `custom` + `custom_key` for any other meta key), `tag`, `icon`, `text_before` / `text_after`, `hide_empty`, `link`; image fields: `display_type`, `thumbnail_size`.
- **`post_author`** — `avatar`, `avatar_width`, `avatar_pos`, `posts_count`, `website`, `info`, `link`. **`post_comments`** — `number`, `hide_zero`, `link`, `icon`.
- **`event_date`** — event start / end date (The Events Calendar): `type`, `format`, `icon`, `text_before` / `text_after`.
- **`post_views`** — view count (Post Views Counter plugin only).

WooCommerce (only when active):
- **`product_field`** — `type` (`price` | `rating` | `sku` | `sale_badge` | `weight` | `dimensions` | `attributes` | `stock` | `default_actions`), `sale_text`.
- **`add_to_cart`** — the Add to Cart button; `view_cart_link`.

User lists:
- **`user_data`** — `type` (`display_name` | `first_name` | `last_name` | `nickname` | `user_email` | `user_url` | `description` | `role` | `user_registered` | `post_count` | `custom` + `custom_field`), `tag`, `link`. **`user_picture`** — `width`, `circle`, `default_avatar`, `link`.

General:
- **`btn`** — `label`, `link`, `style` (button style id — `upsolution-list-button-styles`), `icon`, `iconpos`.
- **`text`** — `text` (may contain `{{dynamic values}}`), `tag`, `link`, `icon`.
- **`image`** — `img` (attachment id, image URL or `{{the_thumbnail}}` / an image custom field), `size`, `style`, `link`.
- **`image_slider`** — `ids` (comma-separated attachment ids) or `include_post_thumbnail` / `meta` (the post's gallery), `img_size`, `img_fit`, `arrows`, `nav`.
- **`separator`** — spacing or a line: `size` (`small` | `medium` | `large` | `huge` | `custom` + `height`), `show_line`, `line_width`, `style`, `color`.
- **`html`** — `content` (raw HTML). `get-grid-layout` returns HTML params encoded — always send plain HTML.
- **`add_to_favs`**, **`popup`**, **`vc_video`** — specialised; read their params via `get-grid-layout`.

Containers:
- **`hwrapper`** — a row: `alignment` (`none` | `left` | `center` | `right` | `justify`), `valign`, `inner_items_gap` (e.g. `"0.5rem"`), `wrap`, `stack_on_mobiles`, `link`.
- **`vwrapper`** — a stack: `alignment`, `valign`, `inner_items_gap`, `link`. Combine it with `css` padding to build a text block under a full-bleed image.
- **`vc_tta_tabs` / `vc_tta_accordion` / `vc_tta_tour`** hold **`vc_tta_section`** only (`title`, `icon`, `active`); a section holds regular elements.

The available types on a site come from `add_element`'s error message; `product_field` / `add_to_cart` exist only with WooCommerce, `post_views` only with Post Views Counter.

## Links and dynamic values

A `link` param is an **object**, the tool encodes it:

- `{ "type": "post" }` — the item itself (post / term / user). Also `"popup_post"` (open it in a popup), `"post_comments"`, `"archive"`, `"author_page"`, `"author_website"`, `"homepage"`, `"popup_image"`, `"elm_value"` (the element's own value as an email / phone / URL).
- `{ "type": "custom_field", "custom_field": "<key>" }` — a URL stored in a custom field.
- `{ "url": "https://example.com", "target": "_blank" }` — a fixed URL. A plain URL string is wrapped as `{ "url": "…" }`. Pass `""` to clear.

Text params, `css` values and colors accept dynamic values `{{field_name}}` — the same tokens the Grid Builder offers (custom fields including ACF, `{{the_thumbnail}}` for images). They are resolved per item at render time.

## Editing — `update-grid-layout`

`{ id, title?, operations: { … } }`. Everything is validated against an in-memory copy first; if any check fails, nothing is saved. Operation groups (all optional, applied in this order):

1. **`add_element`** — `[ { type, params?, placement: { cell, position? } } ]`. `cell` is `middle_center` or a container id, including a container added earlier in the same call. `position` is the 0-based index in that cell; omitted, negative or past the end appends. Returns the new ids in `added_ids`.
2. **`update_element`** — `{ "<elm_id>": { "<param>": value | null } }`. `null` resets a param to the element default. Unknown params are rejected.
3. **`remove_element`** — `[ "<elm_id>" ]`. Removing a container removes everything inside it (listing its children too is fine).
4. **`set_options`** — `{ "<option>": value | null }`. `null` reverts to the default.
5. **`set_layout`** — `{ "<cell>": [ "<elm_id>", … ] }`. Sets the order of a cell; listed ids are moved out of wherever they were. Each id may appear only once across the whole `set_layout`. An element left in no cell goes to `hidden` and is not shown. A container cannot be moved into itself.

Example — add a date row and a button under the title, round the card and add a shadow:

```jsonc
{ "id": 1234, "operations": {
  "add_element": [
    { "type": "hwrapper", "params": { "inner_items_gap": "0.5rem" }, "placement": { "cell": "middle_center", "position": 2 } },
    { "type": "post_date", "params": { "css": { "default": { "font-size": "0.85rem", "color": "_content_faded" } } }, "placement": { "cell": "hwrapper:1" } },
    { "type": "post_taxonomy", "params": { "taxonomy_name": "category" }, "placement": { "cell": "hwrapper:1" } },
    { "type": "btn", "params": { "label": "Read more", "link": { "type": "post" } }, "placement": { "cell": "middle_center" } }
  ],
  "set_options": { "border_radius": "0.5rem", "box_shadow": "0.3rem", "box_shadow_hover": "1rem" }
} }
```

## Workflow

1. `upsolution-read-doc design/grid-layouts` (this doc) — once per session.
2. `upsolution-list-grid-layouts` → find a close starting point; `upsolution-get-grid-layout { id: "<template key>" }` to inspect it.
3. `upsolution-create-grid-layout { title, source: "<template key>" | <record id> | "blank" }`.
4. `upsolution-get-grid-layout { id }` → element ids and current values.
5. `upsolution-update-grid-layout` with the operation groups.
6. Point a list at it: `items_layout="<selector>"` on the list shortcode via `upsolution-update-post`.

## Anti-patterns

- Don't edit a `us_grid_layout` with `update-post` / `create-post` — that overwrites the JSON and breaks the card.
- Don't try to update or delete a built-in template — copy it first.
- Don't send a full settings object — use the operation groups.
- Don't encode links or HTML yourself — send a link object and plain HTML.
- Don't put a `vc_tta_section` anywhere except Tabs / Accordion / Vertical Tabs, or regular elements directly into them. Don't nest Tabs / Accordion / Vertical Tabs (or a wrapper holding one) inside a section of another one — the Grid Builder refuses that, so does the tool.
- Don't expect per-breakpoint reordering — the card has one layout; use `css` per state or `hide_on_states` for responsive tweaks.
