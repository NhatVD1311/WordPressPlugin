# Header Builder authoring

Build and edit site headers (`us_header` post type). A header is **not** shortcode markup — it is a Header Builder JSON config stored in the post's content, so the generic `create-post` / `update-post` tools refuse it. Use these tools instead:

- `upsolution-list-headers` — existing headers (id, slug, title). Resolve a name to an id.
- `upsolution-list-header-templates` — built-in starting points for `create-header`.
- `upsolution-get-header` — one header as the fully-expanded settings + element list. **Read this immediately before `update-header`** — element ids, per-state cell order and current values all come from here.
- `upsolution-create-header` — new header from a template (or `blank`).
- `upsolution-update-header` — transactional edit (options / elements / layout).
- `upsolution-delete-header` — trash.

A header is assigned either as the **site / per-post-type default** — the Header picker in `upsolution-set-site-layout` (`pages_layout` section; read it with `upsolution-get-site-layout`) — or **per page** via the `us_header_id` meta set with `upsolution-update-post` (the page's meta whitelist includes it). Editing a header changes every place it is used, immediately.

## The settings shape

```jsonc
{
  "default": { "options": { … }, "layout": { "middle_left": ["image:1"], "middle_right": ["menu:1"], … } },
  "laptops": { "options": { … } },          // diffs vs default; layout omitted = inherit default's
  "tablets": { "options": { … } },
  "mobiles": { "options": { … }, "layout": { … } },
  "data": {
    "image:1": { "img": 123, "link": "%7B%22url%22%3A%22%2F%22%7D" },   // only params that differ from the element default
    "menu:1":  { "source": "main-menu" }
  }
}
```

- **Storage is sparse.** Only values that differ from the defaults are stored; everything else is filled in at load time. You never have to send a complete object — `update-header` reads the expanded settings, applies your operations, and re-collapses on save. `get-header` always returns the **expanded** view (every option / param present) so you can see current values.
- **`data`** is a flat map of element instances, keyed `type:N` (`image:1`, `menu:1`, `btn:2`). The number is just a per-type counter; ids are stable once created.
- **`layout`** places element ids into cells, in order. Cells: `top_left`, `top_center`, `top_right`, `middle_left`, `middle_center`, `middle_right`, `bottom_left`, `bottom_center`, `bottom_right`, plus `hidden` (the tray for elements present in `data` but not placed in a state). Each cell is an **ordered array** — the array order is the render order left-to-right (or top-to-bottom for a vertical header).

## Responsive states

Four states, in this order: **`default`** (desktops), **`laptops`**, **`tablets`**, **`mobiles`**. Each carries its own `options` and `layout`.

- **Options are per state.** `set_options` changes an option only in the state(s) you name; setting a key to `null` reverts it to the default state's current value. (The tool stores the full option set in every state — you don't hand-manage inheritance, and storage is intentionally not collapsed to "= default".)
- **Layout is effectively per-state show/hide — NOT reorder.** The theme builds the header DOM **once from the `default` state** and then only toggles element visibility per breakpoint with CSS (`l-header.php`); it does not re-place or re-order elements per state at render. Consequences:
  - The visual order and cell placement come from the **default** state — set the arrangement you want there.
  - **To hide an element on a breakpoint, move it into that state's `hidden` tray** — this is the builder's "Hidden Elements" for that state, and it's the native/expected way. Do it with `set_layout`, e.g. hide the search on phones: `set_layout { "mobiles": { "hidden": ["search:1"] } }`. The element stays visible in the states where it's still in a cell, and shows up under Hidden Elements for the state you moved it out of. (Equivalently, the stock templates hide buttons on mobile by giving the mobile state a layout that omits them.)
  - There is also an element-level **`hide_on_states`** param, but it only **CSS-hides** the element while leaving it in its cell — it does NOT move it to Hidden Elements. Prefer the `hidden` tray for "hide on mobile"; reach for `hide_on_states` (or `hide_below` / `hide_above`, `hide_for_sticky`) only when you specifically want a pure CSS hide without changing the layout.
  - Do **not** expect a different left/right placement or a different element order per breakpoint — that is a Header Builder limitation the API cannot work around.

## Header options (`set_options`)

Keyed by state, then by option name. Colors accept the same syntax as `upsolution-set-palette`: hex (`#rrggbb` / `#rrggbbaa`), `rgb()/rgba()`, `transparent`, a palette token `"_slug"` (e.g. `_header_middle_bg`), and `linear-gradient(...)` only on fields that allow gradients (the background fields). Sliders/lengths are strings like `"80px"`. Switches are `1` / `0` (or `true` / `false`).

Global:
- `orientation` — `hor` | `ver`.
- `sticky` — fix the header on scroll. `sticky_auto_hide` — hide it when scrolling down. `scroll_breakpoint` — px scrolled before the sticky header shrinks.
- `transparent` — transparent at the top of the page (uses the `*_transparent_*` colors).
- `shadow` — `none` | `thin` | `wide`.
- `width`, `elm_align` — vertical-header only.
- `custom_breakpoint` + `breakpoint` — override the global breakpoint at which this state switches.

Per area — replace `<area>` with `top`, `middle`, or `bottom`:
- `<area>_show` — enable the area (`top`/`bottom` are off by default; `middle` is always shown).
- `<area>_height`, `<area>_sticky_height` — area height (and its height once sticky), e.g. `"80px"`.
- `<area>_width` — `default` | `full` | `full_with_indents` | `custom`; `<area>_width_custom` when `custom`.
- `<area>_centering` — center the middle cell.
- `<area>_bg_color`, `<area>_text_color`, `<area>_text_hover_color`.
- `<area>_transparent_bg_color`, `<area>_transparent_text_color`, `<area>_transparent_text_hover_color` — used when `transparent` is on.
- Middle area only: `bg_img` (attachment id), `bg_img_size`, `bg_img_repeat`, `bg_img_position`, `bg_img_attachment`.

(The exact option set is read live from the theme config; `get-header` shows every current value, and `update-header` rejects unknown keys with the allowed list.)

## Element catalog

Each element's params are validated against the theme's element config. **`get-header` returns every instance's current params — read it to discover the exact param names and values for an element before editing** (the lists below are the ones you'll usually set, not exhaustive). Colors / switches / selects follow the same rules as options. A param marked responsive (e.g. menu `indents`) accepts either a scalar or an object `{ default, laptops?, tablets?, mobiles? }`.

**Universal params — every element also accepts:**
- `css` — the **Design** settings (font-size, padding, margins, colors, borders…). This is how you control an element's size/spacing when there's no dedicated param. See "Sizing, spacing & colors" below.
- `hide_on_states` — CSS-hides the element on the listed states (`["laptops","tablets","mobiles"]`) while leaving it in its cell. For a normal "hide on mobile" prefer moving the element to that state's `hidden` tray via `set_layout` (see Responsive states) — that matches the builder's "Hidden Elements". Also `hide_below` / `hide_above` (CSS length), `hide_for_sticky` / `hide_for_not_sticky` (switch).
- `el_class` / `el_id` — extra CSS class / id. `enable_custom_html_atts` + `custom_html_atts` (group of `{name,value}`) — extra HTML attributes.
- `conditions` / `conditions_operator` — display-logic rules (advanced).

- **`image`** (logo) — `img` (attachment id from `upsolution-list-media`, or an image URL), `link` (see Links), `size` (a registered image size slug — `thumbnail` / `medium` / `large` / `full` or a theme/custom size; the value is validated against the sizes registered on the site, the error message lists them), `height_default` / `height_laptops` / `height_tablets` / `height_mobiles` and `height_sticky*` (logo heights, `"30px"`), `dark_img` / `img_transparent` (alternate logos), `disable_lazy_loading`.
- **`menu`** (main nav) — `source` = a menu **slug** (from `upsolution-list-menus`; create one with `upsolution-create-menu`), or `location:us_main_menu` = the menu assigned to that theme location (`upsolution-set-menu-location`). `indents` (gap between items, responsive), `hover_effect` (`simple` | `underline`), `dropdown_arrow`, `spread`, `vstretch`; colors `color_hover_text`, `color_hover_bg`, `color_active_text`, `color_active_bg`, `color_drop_bg`, `color_drop_text`, and their `color_transparent_*` variants; dropdown `dropdown_font_size`, `dropdown_shadow`, `dropdown_open` (`hover` | `click`); mobile menu `mobile_width`, `mobile_icon_style`, `mobile_layout` (`dropdown` | `panel` | `fullscreen`), `mobile_font_size`.
- **`additional_menu`** (simple menu) — `source` (slug), `layout` (`hor` | `ver`), `responsive_width`.
- **`search`** — `layout` (`simple` | `modern` | `fullwidth` | `fullscreen` etc.), `text` (placeholder), `icon`, `field_bg_color`, `field_text_color`, `field_width`, `search_post_type`.
- **`btn`** — `label`, `link` (see Links), `style` (button style id — `upsolution-list-button-styles`), `align`, `icon`, `iconpos`.
- **`text`** — `text` (may contain inline HTML), `link`, `tag` (`div` / `span` / `h1`…), `icon`.
- **`breadcrumbs`** — the site path: `items` is a repeater of sources (`custom` — own `label` + `link`, `page` — a selected page, `taxonomy` — the post's term chain, `auto` — the post's own ancestors), `show_current` + `link_current` + `show_page_number`, `separator_type` (`icon` | `custom`) with `separator_icon` / `separator_symbol`. Never renders on the front page.
- **`highlighted_heading`** — a heading with per-word accents (gradient text fill, highlighter-style background, italic / custom weight). `items` is a repeater (see below) — one row per word/segment; `tag` (`h1`…`h6` / `div` / `p` / `span`, default `h1`). Per-row `text_color` / `bg_color` take a gradient-preset key (`prism`, `ocean`, `gold`, `primary_secondary`, …) or `custom` (then set `custom_text_color` / `custom_bg_color` to a palette token, HEX/RGBA, or CSS gradient). Full preset list and per-row keys are in the content doc `shortcodes/highlighted_heading`.
- **`socials`** — `items` (array of `{ type, url, icon, title, color }`), `shape` (`none` | `square` | `rounded` | `circle`), `style`, `gap`.
- **`dropdown`** — a custom dropdown trigger: `source` (`own` custom `links` | `sidebar` widget area | `wpml` | `polylang`), `links` (array of `{ label, url, icon }`), `link_title`, `link_icon`.
- **`html`** — `content` (raw HTML).
- **`hwrapper` / `vwrapper`** — layout containers grouping other elements horizontally / vertically.
- **`popup`**, **`color_scheme_switch`**, **`favs_counter`**, **`countdown_timer`**, **`cart`** (WooCommerce) — specialised triggers/widgets; read current params via `get-header`.

The exact available types on a given site come from `add_element`'s error message and from `get-header`; `cart` exists only with WooCommerce.

### Sizing, spacing & colors — the `css` Design param

When an element has no dedicated size param, control it through `css`. The value is a **responsive map of CSS declarations**: `{ "<state>": { "<css-prop>": "<value>" } }`. It applies to that element instance only.

```jsonc
// shrink a countdown timer's digits (they render large by default), smaller on mobile:
update_element { "countdown_timer:1": { "css": { "default": { "font-size": "28px" }, "mobiles": { "font-size": "18px" } } } }
// shrink a color-scheme switch / any element:
update_element { "color_scheme_switch:1": { "css": { "default": { "font-size": "14px" } } } }
```

Any CSS property works (`font-size`, `padding`, `margin`, `color`, `line-height`, `gap`, …). Pass `""` to clear. Some elements also expose **dedicated** size params — prefer them when present: `image` → `height_default`/`height_laptops`/`height_tablets`/`height_mobiles` (+ `height_sticky*`); `search` → `icon_size*` / `field_width*`; `menu` → `indents`, `dropdown_font_size`, `mobile_font_size`; `countdown_timer` → `label_size`; `btn`/`text` are best sized via `css` `font-size`/`padding`.

### Wrappers (`hwrapper` / `vwrapper`)

A wrapper groups other elements (horizontally / vertically). The wrapper element itself sits in a normal cell; its **children live under a layout key named after the wrapper's id** (e.g. `layout["vwrapper:1"] = ["text:2","text:3"]`). `get-header` shows this key.

To use wrappers, the wrapper id acts as a **placement target** (a "cell"):
- Add a wrapper into a cell, then add elements into it:
  ```jsonc
  add_element [
    { "type": "vwrapper", "placement": { "cell": "middle_center" } },          // → vwrapper:1
    { "type": "text", "params": { "text": "Line A" }, "placement": { "cell": "vwrapper:1" } },
    { "type": "text", "params": { "text": "Line B" }, "placement": { "cell": "vwrapper:1" } }
  ]
  ```
- `set_layout` also accepts a wrapper id as the cell to reorder/move children: `set_layout { "default": { "vwrapper:1": ["text:3","text:2"] } }`.
- Removing a wrapper (`remove_element`) drops its container; its children survive in `data` and fall into `hidden` (re-place them or remove them too).
- Wrapper element params (alignment, vertical align, inner gap) are edited like any element via `update_element`.

### Repeater fields (`group`): socials items, dropdown links, …

Some params are **repeaters** — an ordered array of row objects. Pass the whole array; each row's keys are validated against that repeater's sub-fields (read current rows from `get-header` to see the shape).

```jsonc
// socials element — items: each row { type, url, icon?, title?, color? }; url is a link object
update_element { "socials:1": { "items": [
  { "type": "custom", "url": { "url": "https://t.me/acme", "target": "_blank" }, "icon": "fab|telegram", "title": "Telegram" },
  { "type": "facebook", "url": { "url": "https://facebook.com/acme" } }
] } }

// dropdown element (source "own") — links: each row { label, url, icon? }
update_element { "dropdown:1": { "links": [
  { "label": "Docs", "url": { "url": "/docs/" }, "icon": "fas|book" },
  { "label": "Blog", "url": { "url": "/blog/" } }
] } }

// highlighted_heading — items: each row { text, text_color?, custom_text_color?, animate_text?,
//   bg_color?, custom_bg_color?, animate_bg?, bg_start_indent?, bg_end_indent?, font_weight?, font_family?, italic? }
update_element { "highlighted_heading:1": { "items": [
  { "text": "Create Your" },
  { "text": "Modern", "text_color": "prism", "animate_text": 1 },
  { "text": "Website" }
] } }
```

A `url` sub-field follows the Links rules below. Pass `[]` to empty a repeater.

### Links

A `link` param is stored as a rawurlencoded JSON object. Pass it as an **object** and the tool encodes it: `{ "url": "/" }`, `{ "url": "https://example.com", "target": "_blank" }`. A plain URL string is wrapped as `{ "url": "…" }`. Pass `""` to clear.

## Editing — `update-header`

`{ id, title?, operations: { … } }`. Everything is validated against an in-memory copy first; if any check fails, nothing is saved. Operation groups (all optional, applied in this order):

1. **`add_element`** — `[ { type, params?, placement: { cell, position?, state? }, all_states? } ]`. Allocates the next `type:N` id and places it. `all_states` defaults to `true` (same cell/position in every state); set `false` to place only in `placement.state` (default `default`) — the element then sits in `hidden` in the other states. Returns the assigned ids in `added_ids`.
2. **`update_element`** — `{ "<elm_id>": { "<param>": value | null } }`. Edits an existing element. `null` resets a param to its element default. Unknown params for that element type are rejected.
3. **`remove_element`** — `[ "<elm_id>" ]`. Deletes the element from `data` and from every state's layout.
4. **`set_options`** — `{ "<state>": { "<option_key>": value | null } }`. `null` reverts the key (non-default states then inherit default).
5. **`set_layout`** — `{ "<state>": { "<cell>": [ "<elm_id>", … ] } }`. Sets the ordered placement of a cell in one state. This is the move / reorder primitive — per state. Ids not placed in any cell of that state fall into its `hidden`.

## Workflow

1. `upsolution-read-doc design/headers` (this doc) — once per session.
2. `upsolution-list-header-templates` → pick one → `upsolution-create-header { title, template }`. For an empty canvas use `template: "blank"`.
3. Need a menu? `upsolution-create-menu { name }` → `upsolution-set-menu-items` to add items.
4. `upsolution-get-header { id }` — read element ids and current values.
5. `upsolution-update-header`:
   - `update_element { "menu:1": { source: "<menu slug>" } }` to wire the menu in;
   - `set_options { default: { sticky: 1, middle_height: "70px" }, mobiles: { middle_height: "56px" } }`;
   - `add_element` / `set_layout` to place and reorder (use a per-state `set_layout` for a different mobile order).
6. Assign it: per page via `upsolution-update-post { post_type, id, meta: { us_header_id: <header id> } }`, or as the site / per-post-type default via `upsolution-set-site-layout` (the Header picker in `pages_layout`).

## Anti-patterns

- Don't edit a `us_header` with `update-post` / `create-post` — it overwrites the JSON and breaks the header.
- Don't try to send a full settings object — use the operation groups; the tool handles the sparse encoding and inheritance.
- Don't set the same option in every state — set it in `default` and override only where it must differ; use `null` to drop a stale per-state override.
- A header's Menu element references a menu by **slug**, not id. Get the slug from `list-menus` / `create-menu`.
- `top` and `bottom` areas are hidden until you set `<area>_show: 1`.
