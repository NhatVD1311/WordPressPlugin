# UpSolution — Post Types & Hierarchy Guide

> Reference for `upsolution-list-post-types` / `list-posts` / `get-post` / `create-post` / `update-post` / `duplicate-post` / `delete-post` — all the CRUD tools take a required `post_type` argument; there are no per-type tool variants. Tells you which `post_type` to pick, which optional input fields apply (`excerpt`, `featured_image_id`, `terms`, `meta`, `parent`, `menu_order`), and which taxonomies / meta keys are accepted.

The shortcode body in `content=` follows the same rules for every type — see [composition-rules.md](composition-rules.md) and [shortcodes.md](shortcodes.md). What changes per type is the surrounding metadata.

## The type set is DYNAMIC — discover it, don't assume it

This server edits **the post types the site surfaces in its admin menu**, not a fixed list. The set mirrors the "Post List" element: the post types shown as its *Post Type* checkboxes (built-in `page` / `post`, `us_portfolio`, `us_testimonial`, most custom post types, WooCommerce `product`, …), plus the two UpSolution authoring types that list hides — `us_content_template` ("Page Templates") and `us_page_block` ("Reusable Blocks"). The assignable taxonomies are the ones in its *Posts with specific taxonomies* dropdown, intersected per type. (A public type registered with `show_in_menu=false` is not surfaced, so it won't appear — `upsolution-list-post-types` is the source of truth for what is editable here.)

Because this varies per install, **call `upsolution-list-post-types` first** when you touch anything other than `page` / `post`. It returns, for each editable type:

- `slug`, `label`;
- `hierarchical` — whether it forms a parent/child tree (gates the `parent` field);
- `public` — whether it has a public front-end URL;
- `supports_excerpt`, `supports_thumbnail`;
- `taxonomies` — `[{ slug, label, hierarchical }]` you may assign terms from;
- `meta_keys` — the whitelisted meta keys: **built-in Impreza** keys (see groups below) plus the site's **ACF fields** (see [ACF custom fields](#acf-custom-fields));
- `meta_fields` — one entry per `meta_keys` key: `key`, `type`, and when relevant `values` (enum / list), `post_types`, `item_type` (list), `min` / `max`, `format`, `sub_fields` (Group / Repeater), `layouts` (Flexible Content), `label` / `description` (for ACF — the field label and instructions).

Optional input fields (`excerpt`, `featured_image_id`, `terms`, `meta`, `parent`) sent for a type that does not support them are **silently ignored** — except `terms` / `meta` keys that fail the whitelist and a non-zero `parent` on a flat type, which return 400.

### The built-in types

| `post_type`            | What it is                                                                 | Public URL? | Excerpt | Featured img            | Hierarchical |
|------------------------|-----------------------------------------------------------------------------|-------------|---------|--------------------------|--------------|
| `page`                 | Standard WP page (landing pages, marketing pages, "About us", …)            | yes         | no      | yes                      | **yes**      |
| `post`                 | Standard WP blog post                                                       | yes         | yes     | yes                      | no           |
| `us_portfolio`         | Portfolio item (a "case", project, work sample)                             | yes         | yes     | yes                      | no           |
| `us_testimonial`       | Single testimonial / quote                                                  | no (admin)  | —       | **yes — = author photo** | no           |
| `us_content_template`  | "Page Template" — layout assigned to single / archive / shop in Theme Opts  | no (admin)  | —       | —                        | no           |
| `us_page_block`        | "Reusable Block" — included by id from pages or templates                   | no (admin)  | —       | —                        | no           |

Custom post types add their own rows; check `upsolution-list-post-types` for their flags and bound taxonomies. A custom type may be hierarchical (behaves like `page`) or flat (behaves like `post`).

## Page vs Content Template vs Reusable Block

These three get confused often. Quick decider:

- **`page`** — has its own URL, shown to visitors directly. Each is a one-off layout. Use this when the user asks for "an About page", "a landing page for product X", etc.
- **`us_content_template`** ("Page Templates" in admin) — a *layout* reused across many real posts. The template itself is not visited; instead it's bound to single-post / archive / shop / 404 / search layouts via **Theme Options → Pages Layout / Archives Layout / Shop Layout**. Includes special template-context shortcodes (`[us_post_content]`, `[us_post_title]`, `[us_post_taxonomy]`, …) that resolve against the loop post at render time. **Edit one template → every post that uses it re-renders with the new layout.**
- **`us_page_block`** ("Reusable Blocks" in admin) — a fragment included into other pages / templates via `[us_page_block id="N"]` or via the per-type Theme Options ("Before page content" / "After page content" / etc.). Good for repeated sections (CTAs, footers-within-content, "as featured in" strips). **Edit one block → every place it's included updates.**

If the user wants "a footer that shows on every blog post", that's a Reusable Block referenced from the single-post Content Template — not a Page.

For `us_content_template` and `us_page_block`, `status` is the inclusion gate — `publish` makes them available to the inclusion mechanisms, `draft` hides them. (Neither type has a public URL, so the difference is invisible to visitors.)

## Publication date & scheduling

`create-post` / `update-post` take an optional `date` (the post's publication time) and accept a `future` status. Together they schedule a post to go live later.

- **Schedule for later** — pass a **future** `date`. WordPress automatically switches the status to `future` and publishes the post at that time; you do not have to set `status` yourself. Setting `status: "future"` explicitly works too, but WordPress derives the real status from the date — `future` with a missing or past `date` is published immediately — so always pair `status: "future"` with a future `date`.
- **Publish now** — omit `date` (or pass a past one) with `status: "publish"` (the create default for users who may publish the type; without that capability the default is `draft`, and an explicit `publish` / `future` / `private` is rejected).
- **Back-date** — pass a past `date` with `status: "publish"`.

`date` is an ISO 8601 string:

| Form                                                   | Read as                                            |
|--------------------------------------------------------|----------------------------------------------------|
| `2026-07-01T09:00:00+03:00` / `2026-07-01T06:00:00Z`   | absolute instant (carries its own offset / `Z`)    |
| `2026-07-01 09:00:00` / `2026-07-01T09:00:00`          | site-local wall-clock time                         |
| `2026-07-01`                                           | site-local midnight                                |

On `update-post`, omit `date` to keep the stored publication date; pass it to move the post earlier or later. Switching a scheduled post to `status: "publish"` before its date publishes it right away; switching it to `draft` unschedules it.

`get-post` / `list-posts` return `date` (ISO 8601 GMT) next to `status`, so a `status: "future"` post shows when it will go live. List the scheduled queue with `list-posts({ status: "future" })`.

## Hierarchy (parent / menu_order)

Hierarchical types (`page` and any custom post type whose `hierarchical` flag is `true` in `upsolution-list-post-types`) form a parent/child tree. Two fields control it on `create-post` / `update-post`:

- **`parent`** — the parent post's id. `0` = top level. The parent must be an existing post of the **same** `post_type`, and must not be the post itself or one of its descendants (that returns 400, no write). Sending a non-zero `parent` for a **flat** type returns 400.
- **`menu_order`** — manual sort position among siblings (lower sorts first; default 0).

`get-post` / `list-posts` always return `parent` and `menu_order`, so you can read the current tree. To walk it level by level:

```jsonc
// top-level pages, in their manual order
list-posts({ post_type: "page", parent: 0, orderby: "menu_order" })
// → [{ id: 10, title: "Company", parent: 0, menu_order: 0 }, …]

// children of page 10
list-posts({ post_type: "page", parent: 10, orderby: "menu_order" })

// create a child under page 10
create-post({ post_type: "page", title: "Team", parent: 10 })

// move a page to the top level
update-post({ post_type: "page", id: 42, parent: 0 })
```

`menu_order` only changes a post's own position; it does not re-order siblings for you — set each sibling's value explicitly if you need a specific sequence. Slugs (`slug` / `new_slug`) are independent of the tree: a child keeps its single-segment slug, but `get-post` / resolution by slug also accepts a `"parent/child"` path for hierarchical types.

## Duplicating a post

`duplicate-post` makes a server-side copy in **one call** — you do not have to `get-post` first and re-send the body. It clones, from the source:

- `post_content`, `excerpt`, and the page attributes (parent, menu order, comment / ping status). The copy is authored by the current user (the source author is kept only for users who may edit others' posts);
- **every** taxonomy term (all taxonomies of the type, not just the ones in the table below);
- the featured image (by reference — the same attachment, no media re-upload);
- **all** custom meta — builder data, Page Layout / SEO / Additional Settings, and any third-party custom fields. This is broader than the `create-post` / `update-post` `meta` whitelist on purpose: a duplicate is meant to be faithful.

WordPress-internal bookkeeping meta (edit locks, old-slug / old-date history, trash markers) is **not** copied.

Defaults that keep a duplicate safe and distinct:

- `status` → `draft` (a copy never publishes itself; override with `status` / schedule with a future `date`);
- `title` → `"<source title> (copy)"` (override with `title`);
- slug → a fresh unique slug derived from the title (override with `new_slug`).

```jsonc
duplicate-post({ post_type: "page", id: 451 })
// → new draft "<title> (copy)", same content + meta + terms, plus source_id: 451

duplicate-post({ post_type: "post", slug: "launch", title: "Launch v2", status: "draft" })
```

## Per-type meta whitelist

`update-post` / `create-post` accept a `meta` object whose keys are restricted per type. Sending other keys → 400. The whitelist holds the **built-in Impreza meta** (the `config/meta-boxes.php` metabox fields, minus composite fields the agent cannot reliably encode — multi-uploads, link blobs) and the site's **ACF fields** (next section). **Other third-party meta is NOT writable** — e.g. a WooCommerce `product`'s price/SKU are not in its `meta_keys`; manage those through WooCommerce's own tools. (A site developer can add or remove keys with the `us_mcp_post_type_meta_whitelist` PHP filter — whatever it adds shows up in `meta_keys` / `meta_fields` like any other key.)

The exact `meta_keys` for a type come from `upsolution-list-post-types`. The groups below explain what the built-in keys mean.

### ACF custom fields

When Advanced Custom Fields is active, the fields of every active ACF field group whose Location rules can apply to a post type are added to that type's `meta_keys` automatically. Groups located on Options pages, taxonomy terms, users, menus, widgets, comments or blocks never appear. A group limited to a page template, parent page, term, etc. still appears for the whole type — check the field's `label` / `description` in `meta_fields` to see what it is for.

The field **name** is the meta key. A first-level sub field of a **Group** field is keyed `{group}_{sub}` (group `hero`, sub field `title` → `hero_title`), composite sub fields included. If an ACF field has the same name as a built-in key, the built-in key wins and the ACF field is not exposed.

Values are the **raw stored** ACF values, not the formatted "Return Format" output — `get-post` returns them in exactly the shape you write:

| ACF field type                                          | `type` in `meta_fields` | What you send / read                                                                  |
|---------------------------------------------------------|--------------------------|---------------------------------------------------------------------------------------|
| Text, Text Area, WYSIWYG, Email, URL, oEmbed            | `string`                 | a string                                                                              |
| Number, Range                                           | `number`                 | a number, within `min` / `max` when the field sets them                               |
| True / False                                            | `bool_01`                | `0` / `1`                                                                              |
| Select (single), Radio, Button Group                    | `enum`                   | one of `values` — the choice **keys**, not their labels (Radio with "Other": `string`) |
| Date Picker                                             | `date`                   | `Ymd`, e.g. `"20261031"`                                                               |
| Date Time Picker                                        | `datetime`               | `Y-m-d H:i:s`, e.g. `"2026-10-31 18:30:00"`                                            |
| Time Picker                                             | `time`                   | `H:i:s`, e.g. `"18:30:00"`                                                             |
| Color Picker                                            | `color`                  | hex `#rrggbb`, or `rgba(r,g,b,a)` when `format` is `hex or rgba()`. No gradients, no palette tokens |
| Image                                                   | `attachment`             | id of an existing image in the media library; resolve via `upsolution-list-media`     |
| File                                                    | `attachment`             | id of an existing media file of any type                                               |
| Post Object (single)                                    | `post`                   | id of an existing post (of the field's allowed `post_types`); resolve via `list-posts` |
| Checkbox, Select (multiple)                             | `list`                   | array of choice keys from `values`, e.g. `["red", "blue"]` (with "Allow Custom" / "Create Options": any strings) |
| Post Object (multiple), Relationship                    | `list`                   | array of ids of existing posts of the allowed `post_types`, `min` / `max` items        |
| Gallery                                                 | `list`                   | array of ids of existing images, `min` / `max` items                                   |
| Link                                                    | `link`                   | `{ "url": "/contact", "title": "Contact", "target": "" }` — `target` is `""` or `"_blank"`; stored the same way for any Return Format |
| Repeater                                                | `rows`                   | array of rows, each `{ sub field name: value }`; `sub_fields` describes them, `min` / `max` rows |
| Flexible Content                                        | `layouts`                | array of blocks, each `{ "acf_fc_layout": layout name, sub field name: value }`; `layouts` lists `name`, `label`, `min` / `max`, `sub_fields` |
| Group inside a Repeater / Flexible Content / Group      | `group`                  | object `{ sub field name: value }`, described in `sub_fields`                           |

Sub fields of rows, blocks and groups take the same formats as top-level keys, nested Repeaters included. `get-post` returns only the ids as integers, no titles or content of the linked posts. Restrictions set on the field in ACF apply as well: allowed file types, file size and image dimensions of Image / File / Gallery, "Filter by Taxonomy" of Post Object / Relationship. They apply to the whole value you send, so a stored value that no longer matches them (a linked post that lost the term, an image smaller than a minimum set later) fails the write even if you did not change it: remove or replace it. Inside lists and rows, ids of deleted posts / media and values removed from the field choices are left out (read as `""`), as wp-admin drops them on the next save.

A Flexible Content block may also carry `"acf_fc_layout_disabled": true` (the block is hidden on the site, as with the "Disable layout" toggle in wp-admin) and `"acf_fc_layout_custom_label": "…"` (its title in the editor). `get-post` returns them when set; keep them when you send the blocks back. Both need ACF PRO 6.5 or later.

Not exposed: Password, User, Taxonomy, Page Link, Google Map, Clone and fields added by other plugins. A Repeater, Flexible Content or Group with such a sub field is not exposed at all: rows are stored by position, so rewriting them without that sub field would move its values to other rows.

**Writing a list / rows field replaces its whole value** — there is no per-row update. A sub field missing from a row is emptied. To change one row: read the field with `get-post`, edit that row, send the whole array back. `max` items / rows always apply, `min` only on publish.

`null` or `""` (or `[]` for a list / rows field) clears an ACF field the way emptying it in wp-admin does: an empty value is stored (`0` for True / False), so the field's Default Value does not come back.

On top of the type check, each value goes through the field's own ACF validation, as when the post is saved in wp-admin: Email / URL values must be valid, Text length and Number min / max apply. A failure returns 400 with the ACF message; for a value inside rows the message gives its path, e.g. `Meta "team" → row 3 → "photo": …`.

**Required fields** (`required: true` in `meta_fields`) are enforced the way ACF does it — only for published posts. `create-post` / `update-post` with a resulting status `publish` returns 400 while a required field is empty (neither sent in `meta` nor already stored); a `draft` saves fine. A required True / False must be `1`, a required Link needs a `url`, a required Group needs all its sub fields (for a top-level Group each `{group}_{sub}` key is marked `required`). Required sub fields of rows and the `min` counts are checked only on publish, and only for the values sent in `meta`. A field shown by ACF Conditional Logic is not enforced as required.

```jsonc
update-post({
  post_type: "post",
  id: 42,
  meta: { event_date: "20261031", event_price: 49.9, is_featured: 1, hero_title: "Autumn sale" }
})

update-post({
  post_type: "page",
  id: 57,
  meta: {
    // Repeater: 2 rows
    team: [
      { name: "Ann", photo: 812, linkedin: { url: "https://linkedin.com/in/ann", title: "LinkedIn", target: "_blank" } },
      { name: "Bob", photo: 813, linkedin: null }
    ],
    // Flexible Content: blocks in order, the "faq" block holds a nested Repeater
    sections: [
      { acf_fc_layout: "hero", title: "Welcome", gallery: [812, 815] },
      { acf_fc_layout: "faq", items: [ { question: "Shipping?", answer: "2-3 days" } ] }
    ],
    related_posts: [101, 102]
  }
})
```

### Shared groups

The next two groups are reused across types — the matrix at the end shows which types get which.

#### Page Layout (`us_page_settings` metabox)

Per-post overrides to the site's Theme Options. Most values are switches or selects; the `*_id` fields are post-id references.

| Key                                  | Type             | Notes                                                                                                  |
|--------------------------------------|------------------|--------------------------------------------------------------------------------------------------------|
| `us_header_id`                       | string           | `__defaults__` (use Theme Options) / `"0"` (do not display) / id of a `us_header` post.                |
| `us_header_sticky_override`          | `0` / `1`        | Enable per-post override of Sticky Header.                                                             |
| `us_header_sticky`                   | string           | Comma-joined responsive-state slugs (e.g. `default,tablets,mobiles`) where sticky is ON.               |
| `us_header_transparent_override`     | `0` / `1`        | Enable per-post override of Transparent Header.                                                        |
| `us_header_transparent`              | string           | Comma-joined responsive-state slugs where transparent is ON.                                           |
| `us_header_shadow`                   | `0` / `1`        | `1` removes the header shadow.                                                                         |
| `us_remove_header_offset_override`   | `0` / `1`        | Enable per-post override of content offset.                                                            |
| `us_remove_header_offset`            | string           | Comma-joined responsive-state slugs where the content offset is removed.                               |
| `us_header_sticky_pos`               | string           | `""` (top) / `bottom` / `above` / `below` — initial position of the sticky header relative to content. |
| `us_titlebar_id`                     | string           | `__defaults__` (use Theme Options) / `"0"` (do not display) / id of a `us_page_block` (only if Theme Options exposes per-post titlebar). |
| `us_content_id`                      | string           | `__defaults__` (use Theme Options) / `"0"` (no Page Template) / id of a `us_content_template` ("Page Template"). |
| `us_sidebar_id`                      | string           | `__defaults__` (use Theme Options) / `"0"` (no sidebar) / sidebar slug OR `us_page_block` id, depending on Theme Options. |
| `us_sidebar_pos`                     | `left` / `right` | Sidebar position. Only meaningful when `us_sidebar_id` is set.                                         |
| `us_footer_id`                       | string           | `__defaults__` (use Theme Options) / `"0"` (do not display) / id of a `us_page_block`.                 |

Post-id references (`us_header_id`, `us_titlebar_id`, `us_content_id`, `us_footer_id`, `us_sidebar_id` when sidebars are Reusable Blocks) need an actual post id. Resolve via `list-posts` against the relevant type before writing. `us_header` is not exposed via this server — pick the id from admin or rely on `__defaults__`.

##### `*_id` value semantics — what each value does

Applies to `us_header_id`, `us_titlebar_id`, `us_content_id`, `us_sidebar_id`, `us_footer_id`:

| Value you send       | What is stored        | Effect at render                                                                                       |
|----------------------|-----------------------|---------------------------------------------------------------------------------------------------------|
| key omitted          | (unchanged)           | whatever was stored before.                                                                              |
| `null` or `""`       | **meta key deleted**  | Theme Options defaults — same as a post that never had the override.                                     |
| `"__defaults__"`     | `__defaults__`        | Theme Options defaults (explicit "no per-post override"); equivalent to a deleted key.                    |
| `"0"`                | `"0"`                 | **Do not display** this area on the post.                                                                |
| `"123"` (post id)    | `"123"`               | Use that entity. The id must be a **published** post of the right type — a draft / trashed / deleted id is silently ignored at render and the area falls back to Theme Options. |
| sidebar slug (`us_sidebar_id` only) | the slug | That registered sidebar; an unregistered slug is silently ignored.                                        |

Legacy caveat: content saved with theme versions ≤ 8.14 may store `""` in these keys, and at render an **existing** empty value also means "do not display". You cannot author that state via this server (`""` deletes the key) — send `"0"` instead.

#### SEO meta (`us_seo_settings` metabox, only when Theme Options' `og_enabled` is on)

| Key                   | Type    | Notes                                                                                       |
|-----------------------|---------|---------------------------------------------------------------------------------------------|
| `us_meta_title`       | string  | Override `<title>` for the post. Empty = use the default.                                   |
| `us_meta_description` | string  | `<meta name="description">`.                                                                |
| `us_meta_robots`      | string  | Robots directives, e.g. `noindex`, `nofollow`, `none`.                                      |
| `us_meta_itemtype`    | string  | schema.org type override, e.g. `FAQPage`, `QAPage`, `Person`. Empty = default.              |

#### Additional Settings (metabox id `us_portfolio_settings`, kept for legacy reasons)

The metabox's `post_types` come from the `additional_settings_post_types` theme option which defaults to **all public post types**. So these keys apply to `page`, `post`, and `us_portfolio` — they affect how the post is rendered as a tile inside a grid that displays it (portfolio grid, post grid, etc.).

Composite fields excluded: `us_tile_additional_image` (multi-upload, use the WP media REST API), `us_tile_link` (composite link blob).

| Key                  | Type   | Notes                                                                                  |
|----------------------|--------|----------------------------------------------------------------------------------------|
| `us_tile_icon`       | string | Icon class (e.g. `fas|star`). See [composition-rules.md §3.6](composition-rules.md#36-icon--icon-picker) for the icon picker spec. |
| `us_tile_size`       | string | One of `1x1` (default), `2x1`, `1x2`, `2x2`. Custom tile size in masonry / grid grids. |
| `us_tile_bg_color`   | string | Hex / rgba.                                                                            |
| `us_tile_text_color` | string | Hex / rgba.                                                                            |

For `us_portfolio`, the portfolio gallery image is the **featured image** — set via `featured_image_id`, not `meta`.

### Per-type meta

#### `us_testimonial` (`us_testimonials_settings`)

Composite field excluded: `us_testimonial_link` (link blob).

| Key                      | Type   | Notes                                                              |
|--------------------------|--------|--------------------------------------------------------------------|
| `us_testimonial_author`  | string | Author's name (e.g. "John Doe").                                   |
| `us_testimonial_role`    | string | Author's role / job title.                                         |
| `us_testimonial_company` | string | Author's company.                                                  |
| `us_testimonial_rating`  | string | One of `none`, `1`, `2`, `3`, `4`, `5`. Renders the star rating.   |

The testimonial body is the **post content** — write the quote as shortcode markup. The author **photo** is the **featured image** (`featured_image_id`).

#### `us_content_template` (`us_content_template_settings`)

| Key                              | Type      | Notes                                                                      |
|----------------------------------|-----------|----------------------------------------------------------------------------|
| `us_header_transparent_override` | `0` / `1` | Enable transparent-header override for posts that use this Page Template.  |
| `us_header_transparent`          | string    | Comma-joined responsive-state slugs where transparent is ON.               |

### Per-type whitelist matrix

| `post_type`           | Page Layout | SEO meta | Additional Settings | Type-specific                        |
|-----------------------|:-----------:|:--------:|:-------------------:|--------------------------------------|
| `page`                | ✓           | ✓        | ✓                   | —                                    |
| `post`                | ✓           | ✓        | ✓                   | —                                    |
| `us_portfolio`        | ✓           | ✓        | ✓                   | —                                    |
| `us_testimonial`      | —           | —        | —                   | Testimonial author fields            |
| `us_content_template` | —           | —        | —                   | Transparent-header override (2 keys) |
| `us_page_block`       | —           | —        | —                   | — (no per-post meta)                 |

**Custom post types** follow the same rule as `page` / `post` / `us_portfolio`: any **public** CPT gets the Page Layout + SEO + Additional Settings groups; a non-public CPT gets none. ACF fields come on top of this matrix for any type. Confirm with `upsolution-list-post-types` (`meta_keys`).

## Assigning taxonomy terms

`terms` is `{ taxonomy_slug: [term_id, …] }`. The taxonomy slug **must** match one bound to the post type — check `upsolution-list-post-types` (`taxonomies`) for the type you are editing; unknown taxonomy keys return 400.

You almost never know term ids up front. Use **`upsolution-list-terms`** first:

```jsonc
// 1. Resolve "Web Design" → id
list-terms({ taxonomy: "us_portfolio_category", search: "Web Design" })
// → [{ id: 17, name: "Web Design", slug: "web-design", parent: 0, count: 12 }]

// 2. Use it
update-post({
  post_type: "us_portfolio",
  id: 451,
  terms: { us_portfolio_category: [17] }
})
```

Passing `terms` **replaces** the existing assignment for that taxonomy (there is no "append" mode — to add a term, send the full desired list). Omit a taxonomy key to leave its assignments untouched. Send `[]` to clear all terms in a taxonomy.

If the term you need does not exist yet, call **`upsolution-create-term`** (`{ taxonomy, name, slug?, description?, parent? }` → same id/name/slug/parent/count shape as `list-terms`). To remove a term entirely, **`upsolution-delete-term`** (`{ taxonomy, id }`) — note this is a hard delete, not a trash.

## Featured image

`featured_image_id` is an attachment id (from WP's media library). This server does **not** upload media — use the standard `POST /wp-json/wp/v2/media` REST endpoint outside MCP for that, then pass the resulting id here.

- `featured_image_id: 1234` — set the thumbnail to attachment 1234.
- `featured_image_id: null` (or `0`) — clear the thumbnail.
- Omit the key entirely — leave the thumbnail untouched.

`get-post` returns both `featured_image_id` (int|null) and `featured_image_url` (string|null) for types that support thumbnails.
