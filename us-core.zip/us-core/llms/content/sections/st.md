---
title: Steps (section templates)
audience: content
source: us.api / impreza / st
generated: 2026-10-20 by scripts/llms/build.php
---

<!--
  GENERATED FILE — do not edit directly.
  Snapshot of category `st` from the UpSolution us.api template library.
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=sections
  Direct edits here will be lost on the next regeneration.
-->

# Steps

> Pre-built section templates from the UpSolution library, category `st` (theme: impreza). 20 template(s) in this snapshot.
>
> Live preview page: <https://templates.us-themes.com/steps/>

> Shortcode markup is reproduced verbatim from `us.api`. Image placeholders are kept as `use:placeholder` markers (the live builder rewrites those to install-specific URLs at insert time).

### `01`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-01>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-1.jpg> (700×210)

```text
[vc_row columns="1"][vc_column][us_text text="How We Work" tag="h2" css="%7B%22default%22%3A%7B%22text-align%22%3A%22center%22%2C%22font-weight%22%3A%22500%22%7D%7D"][us_separator][vc_row_inner columns="3" laptops_columns="2"][vc_column_inner width="1/3"][us_hwrapper][us_text text="1" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_bg%22%2C%22text-align%22%3A%22center%22%2C%22line-height%22%3A%223%22%2C%22background-color%22%3A%22_content_heading%22%2C%22min-width%22%3A%223em%22%2C%22border-radius%22%3A%2250%25%22%7D%7D"][vc_column_text]
<h4>High Quality</h4>
Objectively innovate empowered manufactured products whereas parallel platforms. Holisticly predominate extensible testing procedures for chains.

[/vc_column_text][/us_hwrapper][/vc_column_inner][vc_column_inner width="1/3"][us_hwrapper][us_text text="2" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_bg%22%2C%22text-align%22%3A%22center%22%2C%22line-height%22%3A%223%22%2C%22background-color%22%3A%22_content_heading%22%2C%22min-width%22%3A%223em%22%2C%22border-radius%22%3A%2250%25%22%7D%7D"][vc_column_text]
<h4>Good Support</h4>
Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.

[/vc_column_text][/us_hwrapper][/vc_column_inner][vc_column_inner width="1/3"][us_hwrapper][us_text text="3" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_bg%22%2C%22text-align%22%3A%22center%22%2C%22line-height%22%3A%223%22%2C%22background-color%22%3A%22_content_heading%22%2C%22min-width%22%3A%223em%22%2C%22border-radius%22%3A%2250%25%22%7D%7D"][vc_column_text]
<h4>Individual approach</h4>
Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.

[/vc_column_text][/us_hwrapper][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `02`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-02>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-2.jpg> (700×339)

```text
[vc_row columns="1-3" tablets_columns="1" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%7D%7D"][vc_column width="1/4"][us_text text="How We Work" tag="h2"][/vc_column][vc_column width="3/4"][vc_row_inner columns="2" laptops_columns="1"][vc_column_inner width="1/2"][us_text text="01" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Request for prices online</h4>
Organically grow the holistic world view of disruptive innovation.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="02" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Individual calculation</h4>
User generated content in real-time will have multiple touchpoints for offshoring.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="03" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Optional prepayment</h4>
Capitalize on low hanging fruit to identify a ballpark value added activity to beta test.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="04" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Logistics to your warehouse</h4>
Nanotechnology immersion along the information highway will close the loop.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="05" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Payment in cryptocurrency</h4>
Podcasting operational change management inside of workflows to establish a framework

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="06" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%201.5rem%20%2B%201.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-family%22%3A%22h1%22%2C%22margin-bottom%22%3A%221rem%22%7D%7D"][vc_column_text]
<h4>Auto-order via B2B portal</h4>
Dramatically visualize customer directed convergence without revolutionary ROI.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `03`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-03>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-3.jpg> (700×335)

```text
[vc_row width="custom" width_custom="750px" height="medium" columns="1"][vc_column][us_text text="Our Hiring Pipeline" tag="h3"][us_separator size="small"][us_timeline marker_style="icon" section_gap="2.5rem" line_thickness="2px" hide_line_endings="1" line_style="dotted" marker_circle_scale="1.8" marker_icon="material|check" marker_size="14px" marker_background_color="#4fad3d" marker_text_color="#ffffff" marker_border_width="0px" line_offset="1rem" marker_border_color=""][us_timeline_section][us_hwrapper valign="baseline" inner_items_gap="1rem"][us_text text="Application Review" tag="h4"][us_text text="2-3 days" tag="span" icon="fas|calendar-week" iconpos="left" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%7D%7D"][/us_hwrapper][vc_column_text]A recruiter checks your background against the role before anything else happens.[/vc_column_text][/us_timeline_section][us_timeline_section][us_hwrapper valign="baseline" inner_items_gap="1rem"][us_text text="Screening Call" tag="h4"][us_text text="30 min" tag="span" icon="fas|calendar-week" iconpos="left" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%7D%7D"][/us_hwrapper][vc_column_text]A quick call with a recruiter to talk through your experience and expectations.[/vc_column_text][/us_timeline_section][us_timeline_section][us_hwrapper valign="baseline" inner_items_gap="1rem"][us_text text="Skills Interview" tag="h4"][us_text text="60 min" tag="span" icon="fas|calendar-week" iconpos="left" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%7D%7D"][/us_hwrapper][vc_column_text]A working session with the team you would join, focused on real problems.[/vc_column_text][/us_timeline_section][us_timeline_section marker_text_color="_content_bg"][us_hwrapper valign="baseline" inner_items_gap="1rem"][us_text text="Final Interview" tag="h4"][us_text text="45 min" tag="span" icon="fas|calendar-week" iconpos="left" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%7D%7D"][/us_hwrapper][vc_column_text]A conversation with the hiring manager and a peer from a different team.[/vc_column_text][/us_timeline_section][us_timeline_section][us_hwrapper valign="baseline" inner_items_gap="1rem"][us_text text="Offer" tag="h4"][us_text text="1-2 days" tag="span" icon="fas|calendar-week" iconpos="left" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%7D%7D"][/us_hwrapper][vc_column_text]If it is a match on both sides, you get a written offer within two business days.[/vc_column_text][/us_timeline_section][/us_timeline][/vc_column][/vc_row]
```

### `04`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-04>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-4.jpg> (700×423)

```text
[vc_row height="medium" columns="1"][vc_column width="1/1" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_bg%22%2C%22background-color%22%3A%22_content_primary%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%226%25%22%2C%22padding-bottom%22%3A%226%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%2216px%22%7D%7D"][us_text text="Card and Sticky Markers" tag="div" css="%7B%22default%22%3A%7B%22color%22%3A%22rgba%28255%2C255%2C255%2C0.75%29%22%2C%22text-align%22%3A%22center%22%2C%22font-size%22%3A%220.9rem%22%2C%22letter-spacing%22%3A%221px%22%2C%22font-weight%22%3A%22600%22%2C%22text-transform%22%3A%22uppercase%22%7D%7D"][us_text text="<strong>Order Fulfillment</strong> Timeline" tag="h2" css="%7B%22default%22%3A%7B%22text-align%22%3A%22center%22%2C%22margin-top%22%3A%220.5rem%22%7D%7D"][us_separator size="small"][us_timeline marker_style="icon" marker_background_color="_content_bg" marker_text_color="_content_primary" line_color="rgba(255,255,255,0.35)" section_gap="2.5rem" css="%7B%22default%22%3A%7B%22max-width%22%3A%22500px%22%2C%22margin-left%22%3A%22auto%22%2C%22margin-right%22%3A%22auto%22%7D%7D" line_thickness="2px" marker_border_color="_content_primary" marker_border_width="3px" marker_circle_scale="2.8" marker_size="clamp(18px, 2.4vw, 26px)" hide_line_endings="1"][us_timeline_section marker_icon="material|shopping_cart"][us_text text="Order Placed" tag="h4"][vc_column_text]Your order is confirmed and a receipt is on its way to your inbox.[/vc_column_text][/us_timeline_section][us_timeline_section marker_icon="material|sync"][us_text text="Processing" tag="h4"][vc_column_text]We pick, pack and quality-check every item before it leaves the warehouse.[/vc_column_text][/us_timeline_section][us_timeline_section marker_icon="material|local_shipping"][us_text text="Shipped" tag="h4"][vc_column_text]A tracking number is issued the moment the courier scans your package.[/vc_column_text][/us_timeline_section][us_timeline_section marker_icon="material|home"][us_text text="Delivered" tag="h4"][vc_column_text]Signed, sealed and on your doorstep, usually within two to four business days.[/vc_column_text][/us_timeline_section][/us_timeline][/vc_column][/vc_row]
```

### `05`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-05>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-5.jpg> (700×245)

```text
[vc_row tablets_columns="1" columns_reverse="1" content_placement="middle" columns="2-3"][vc_column width="2/5"][us_text text="Design Review Process" tag="h2" css="%7B%22default%22%3A%7B%22font-size%22%3A%22var%28--h3-font-size%29%22%7D%7D"][us_separator size="small"][us_btn label="See our design process" icon="fas|arrow-right" iconpos="right" style="2"][/vc_column][vc_column width="3/5"][us_timeline marker_style="diamond" section_gap="2rem" hide_line_endings="1" line_offset="1rem" marker_background_color="_content_border" marker_size="15px" marker_valign="middle"][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%201.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Kickoff%20and%20creative%20brief%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%202.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22First%20concepts%2C%20two%20directions%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%203.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Feedback%20round%20with%20stakeholders%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%204.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Revisions%20and%20refinement%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%205.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Second%20review%20and%20sign-off%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%206.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Final%20files%20prepared%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][us_timeline_section][us_highlighted_heading items="%5B%7B%22text%22%3A%22Step%207.%22%2C%22text_color%22%3A%22custom%22%2C%22custom_text_color%22%3A%22linear-gradient%2890deg%2C%20_content_border%200%25%2C_content_primary%20100%25%29%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%2C%7B%22text%22%3A%22Handoff%20to%20engineering%22%2C%22text_color%22%3A%22%22%2C%22custom_text_color%22%3A%22_content_primary%22%2C%22animate_text%22%3A0%2C%22bg_color%22%3A%22%22%2C%22custom_bg_color%22%3A%22_content_bg_alt%22%2C%22animate_bg%22%3A0%2C%22bg_start_indent%22%3A%220.2em%22%2C%22bg_end_indent%22%3A%220.2em%22%2C%22font_family%22%3A%22%22%2C%22font_weight%22%3A%22%22%2C%22italic%22%3A%22%22%7D%5D" tag="h4"][/us_timeline_section][/us_timeline][/vc_column][/vc_row]
```

### `06`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-06>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-6.jpg> (700×955)

```text
[vc_row columns="1"][vc_column][us_text text="Product Launch Roadmap" tag="h2" css="%7B%22default%22%3A%7B%22text-align%22%3A%22center%22%7D%7D"][us_separator][us_timeline marker_style="number" section_gap="4rem" marker_size="1.5rem" sticky_markers="1" marker_text_color="_content_text" line_pos="center" marker_hide_screen_width="600px"][us_timeline_section][us_text text="2008" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%22var%28--h4-font-size%29%22%2C%22line-height%22%3A%22var%28--h4-line-height%29%22%7D%7D"][us_text tag="h3" text="From a garage to a global team"][vc_column_text]It started with <strong>three engineers</strong>, one second-hand server and a shared belief that the tools everyone used every day could be far simpler. We shipped the first rough version from a rented garage and onboarded our earliest users entirely by hand.</p>
<p>Those first months taught us to listen more than we talked. Every <strong>bug report</strong> and every feature request went straight onto the wall, and the product slowly took the shape its users actually needed.[/vc_column_text][us_separator size="small"][us_btn label="Read our story" style="4" css="%7B%22default%22%3A%7B%22font-size%22%3A%2214px%22%7D%7D"][/us_timeline_section][us_timeline_section][us_text text="2012" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%22var%28--h4-font-size%29%22%2C%22line-height%22%3A%22var%28--h4-line-height%29%22%2C%22margin-bottom%22%3A%221%22%7D%7D"][us_text tag="h3" text="Building the product people asked for" css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"][vc_column_text]With a small but vocal community behind us, we rebuilt the <strong>core editor</strong> from the ground up. Speed became a feature in its own right, and we started measuring every interaction in milliseconds.</p>
<p>By the end of that year the product no longer felt like an experiment. It felt like something teams could <strong>quietly depend</strong> on every single day.[/vc_column_text][us_separator size="small"][us_btn label="Explore the features" style="4" css="%7B%22default%22%3A%7B%22font-size%22%3A%2214px%22%7D%7D"][/us_timeline_section][us_timeline_section][us_text text="2019" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%22var%28--h4-font-size%29%22%2C%22line-height%22%3A%22var%28--h4-line-height%29%22%2C%22margin-bottom%22%3A%221%22%7D%7D"][us_text tag="h3" text="Scaling to a million customers worldwide" css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"][vc_column_text]
<p>Growth stopped being a trickle and became a wave. We opened <strong>regional offices</strong>, translated the interface into a dozen languages and rebuilt our infrastructure to stay fast under far heavier load.</p>
<p>Reliability turned into the promise behind the brand. Customers across every time zone expected the same calm, <strong>responsive experience</strong>, and meeting that bar shaped every decision we made.</p>
[/vc_column_text][us_separator size="small"][us_btn label="See the numbers" css="%7B%22default%22%3A%7B%22font-size%22%3A%2214px%22%7D%7D" style="4"][/us_timeline_section][us_timeline_section][us_text text="2025" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%22var%28--h4-font-size%29%22%2C%22line-height%22%3A%22var%28--h4-line-height%29%22%2C%22margin-bottom%22%3A%221%22%7D%7D"][us_text tag="h3" text="Where we are heading next" css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"][vc_column_text]
<p>The next chapter is about doing more with less effort. We are weaving <strong>intelligent assistance</strong> through the product so the routine work fades into the background and people can focus on the decisions that matter.</p>
<p>We are also opening up a <strong>public API</strong> and a marketplace, so the community can extend the platform in directions we have not even imagined yet.</p>
[/vc_column_text][us_separator size="small"][/us_timeline_section][/us_timeline][us_separator size="small"][us_btn label="View the full roadmap" css="%7B%22default%22%3A%7B%22font-size%22%3A%2214px%22%7D%7D" align="center"][/vc_column][/vc_row]
```

### `07`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-07>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-7.jpg> (700×389)

```text
[vc_row css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%7D%7D" tablets_columns="1" columns="2" columns_gap_source="custom" columns_gap="%7B%22default%22%3A%228%25%22%2C%22laptops%22%3A%228%25%22%2C%22tablets%22%3A%222rem%22%2C%22mobiles%22%3A%222rem%22%7D" columns_reverse="1"][vc_column width="1/2"][us_timeline line_pos="right" marker_style="number" section_gap="3rem" hide_line_endings="1" marker_background_color="_content_bg" marker_circle_scale="2.8" marker_size="1.3rem"][us_timeline_section][us_text text="Kickoff Call" tag="h4"][vc_column_text css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"]Thirty minutes to align on goals, timeline and who is on point from each side.[/vc_column_text][/us_timeline_section][us_timeline_section][us_text text="Account Setup" tag="h4"][vc_column_text css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"]We provision your workspace and connect the tools your team already uses.[/vc_column_text][/us_timeline_section][us_timeline_section][us_text text="Data Migration" tag="h4"][vc_column_text css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"]We import your existing records with zero downtime, then verify every field before anyone signs in.[/vc_column_text][/us_timeline_section][us_timeline_section][us_text text="Team Training" tag="h4"][vc_column_text css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"]A live walkthrough with your team, recorded for anyone who cannot join live.[/vc_column_text][/us_timeline_section][us_timeline_section][us_text text="Go Live" tag="h4"][vc_column_text css="%7B%22default%22%3A%7B%22text-wrap%22%3A%22balance%22%7D%7D"]You are fully onboarded, with a dedicated channel open for the first thirty days.[/vc_column_text][/us_timeline_section][/us_timeline][/vc_column][vc_column width="1/2" sticky="1"][us_text text="Two Column and Numbered" tag="div" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22text-align%22%3A%22left%22%2C%22font-size%22%3A%220.9rem%22%2C%22letter-spacing%22%3A%221px%22%2C%22font-weight%22%3A%22600%22%2C%22text-transform%22%3A%22uppercase%22%7D%7D"][us_text text="How Client Onboarding Works" tag="h2" css="%7B%22default%22%3A%7B%22margin-top%22%3A%220.5rem%22%7D%7D"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.05rem%22%2C%22line-height%22%3A%221.7%22%2C%22max-width%22%3A%22420px%22%7D%7D"]From the first call to your first login, here is exactly what happens and when.[/vc_column_text][us_separator size="small"][us_btn label="Start onboarding" icon="fas|arrow-right" iconpos="right" style="1"][/vc_column][/vc_row]
```

### `08`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-08>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-8.jpg> (700×397)

```text
[vc_row columns="2" tablets_columns="1"][vc_column width="1/2" sticky="1"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.2rem%22%2C%22line-height%22%3A%221.7%22%2C%22max-width%22%3A%22500px%22%7D%7D"]<h2>It’s My Process</h2>
I’m a creative developer with years of experience in building and appealing web products.[/vc_column_text][/vc_column][vc_column width="1/2"][us_timeline line_offset="2rem" section_gap="3rem" hide_line_endings="1"][us_timeline_section][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22500px%22%7D%7D"]<h3><strong>Creative</strong> Approach</h3>
Try to learn as much as I can before designing. This means really understanding the problem at hand through research and anything else I can do to connect to the project.[/vc_column_text][/us_timeline_section][us_timeline_section][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22500px%22%7D%7D"]<h3><strong>Working</strong> Design</h3>
I pull together a few design directions, create prototypes, and really get a feel for the product before going into development.[/vc_column_text][/us_timeline_section][us_timeline_section][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22500px%22%7D%7D"]<h3><strong>Smooth</strong> Production</h3>
I collaborate with developers to implement the final project. This means running through quality assurance and testing to make sure we have the best possible solution.[/vc_column_text][/us_timeline_section][us_timeline_section][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22500px%22%7D%7D"]<h3><strong>Easy</strong> Implementation</h3>
Try to learn as much as I can before designing. This means really understanding the problem at hand through research and anything else I can do to connect to the client.[/vc_column_text][/us_timeline_section][/us_timeline][/vc_column][/vc_row]
```

### `09`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-09>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-9.jpg> (700×414)

```text
[vc_row columns="1"][vc_column][us_text text="How It Works" tag="h2" css="%7B%22default%22%3A%7B%22text-align%22%3A%22center%22%2C%22font-weight%22%3A%22600%22%7D%7D"][us_separator][vc_row_inner columns="2" tablets_columns="1" columns_gap="2.5rem" columns_gap_source="custom"][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="01" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="Backup & Recovery" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from immersion along the highway will close the loop.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="02" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="Network Service" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Podcasting operational change management inside of workflows to establish a framework. Taking seamless key performance indicators offline to maximise the long tail. Keeping your eye on the ball.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="03" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="Stability Fixes" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="04" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="System Administration" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="05" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="Server Migration" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer.

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2" css="%7B%22default%22%3A%7B%22padding-top%22%3A%222.5rem%22%2C%22border-style%22%3A%22solid%22%2C%22border-top-width%22%3A%221px%22%7D%7D"][us_hwrapper valign="baseline" inner_items_gap="1.5rem"][us_text text="06" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_faded%22%2C%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22300%22%7D%7D"][us_text text="Technical Consultation" tag="h4"][/us_hwrapper][us_separator size="small"][vc_column_text]

Objectively innovate empowered manufactured products whereas parallel platforms. Holisticly predominate extensible testing procedures for reliable supply chains.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `10`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-10>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-10.jpg> (700×297)

```text
[vc_row columns_gap="4rem" columns="1" columns_gap_source="custom"][vc_column width="1/1" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_bg%22%2C%22background-color%22%3A%22_content_primary%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%228%25%22%2C%22padding-bottom%22%3A%228%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%2210px%22%7D%7D"][vc_column_text]<h2><strong>Only Three</strong> Steps to Success</h2>[/vc_column_text][us_separator size="large"][vc_row_inner columns="3" ignore_columns_stacking="1" tablets_columns="1"][vc_column_inner width="1/3"][us_text text="01" css="%7B%22default%22%3A%7B%22color%22%3A%22rgba%28255%2C255%2C255%2C0.20%29%22%2C%22font-size%22%3A%2210rem%22%2C%22font-weight%22%3A%22700%22%2C%22margin-top%22%3A%222rem%22%2C%22margin-bottom%22%3A%22-2rem%22%7D%7D"][vc_column_text]<h4>Make Your Business<br />Visible Online</h4><p>Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.</p>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/3"][us_text text="02" css="%7B%22default%22%3A%7B%22color%22%3A%22rgba%28255%2C255%2C255%2C0.20%29%22%2C%22font-size%22%3A%2210rem%22%2C%22font-weight%22%3A%22700%22%2C%22margin-top%22%3A%222rem%22%2C%22margin-bottom%22%3A%22-2rem%22%7D%7D"][vc_column_text]<h4>Make Your eCommerce<br />Website Easily</h4><p>Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.</p>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/3"][us_text text="03" css="%7B%22default%22%3A%7B%22color%22%3A%22rgba%28255%2C255%2C255%2C0.20%29%22%2C%22font-size%22%3A%2210rem%22%2C%22font-weight%22%3A%22700%22%2C%22margin-top%22%3A%222rem%22%2C%22margin-bottom%22%3A%22-2rem%22%7D%7D"][vc_column_text]<h4>Make Your Portfolio<br />Really Impressive</h4><p>Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `11`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-11>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-11.jpg> (700×378)

```text
[vc_row columns="1" width="custom" width_custom="800px"][vc_column width="1/1"][vc_column_text]<h2><strong>Fine-tuned</strong> Process</h2>[/vc_column_text][us_separator show_line="1" icon="fas|arrow-down" align="none" breakpoint_1_height="4rem" breakpoint_2_height="4rem" css="%7B%22default%22%3A%7B%22font-size%22%3A%222rem%22%7D%7D"][vc_row_inner columns="1-3"][vc_column_inner width="1/4"][us_text text="Discover" tag="h3" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%7D%7D"][/vc_column_inner][vc_column_inner width="3/4"][vc_column_text]<p>With over 25 years of experience, we have crafted thousands of strategic discovery process.</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][us_separator show_line="1" icon="fas|arrow-down" align="none" breakpoint_1_height="4rem" breakpoint_2_height="4rem" css="%7B%22default%22%3A%7B%22font-size%22%3A%222rem%22%7D%7D"][vc_row_inner columns="1-3"][vc_column_inner width="1/4"][us_text text="Prototype" tag="h3" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%7D%7D"][/vc_column_inner][vc_column_inner width="3/4"][vc_column_text]Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.[/vc_column_text][/vc_column_inner][/vc_row_inner][us_separator show_line="1" icon="fas|arrow-down" align="none" breakpoint_1_height="4rem" breakpoint_2_height="4rem" css="%7B%22default%22%3A%7B%22font-size%22%3A%222rem%22%7D%7D"][vc_row_inner columns="1-3"][vc_column_inner width="1/4"][us_text text="Create" tag="h3" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%7D%7D"][/vc_column_inner][vc_column_inner width="3/4"][vc_column_text]<p>Performing at the junction of minimalism and mathematics to craft experiences that go beyond design.</p>[/vc_column_text][/vc_column_inner][/vc_row_inner][us_separator show_line="1" icon="fas|arrow-down" align="none" breakpoint_1_height="4rem" breakpoint_2_height="4rem" css="%7B%22default%22%3A%7B%22font-size%22%3A%222rem%22%7D%7D"][vc_row_inner columns="1-3"][vc_column_inner width="1/4"][us_text text="Sell Online" tag="h3" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%7D%7D"][/vc_column_inner][vc_column_inner width="3/4"][vc_column_text]Imagination is more important than knowledge. Knowledge is limited. Imagination encircles the world.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `12`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-12>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-12.jpg> (700×349)

```text
[vc_row columns_gap="0rem" tablets_columns="1" columns="1" columns_gap_source="custom"][vc_column width="1/1"][us_text tag="h2" text="Main Services" css="%7B%22default%22%3A%7B%22font-weight%22%3A%22600%22%7D%7D"][us_separator][vc_tta_tour layout="trendy" remove_indents="1" title_weight="600" title_size="1.5rem" title_lineheight="1" title_tag="h3" css="%7B%22default%22%3A%7B%22max-width%22%3A%22900px%22%7D%7D"][vc_tta_section title="1. Expertise"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.2rem%22%2C%22line-height%22%3A%221.7%22%7D%7D"]<p>At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution.</p><p>User generated content in real-time will have multiple touchpoints for offshoring. Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.</p><p>Override the digital divide with additional clickthroughs from DevOps. Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.</p>[/vc_column_text][/vc_tta_section][vc_tta_section title="2. Consulting"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.2rem%22%2C%22line-height%22%3A%221.7%22%7D%7D"]

User generated content in real-time will have multiple touchpoints for offshoring. Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.

Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution.

Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service.

[/vc_column_text][/vc_tta_section][vc_tta_section title="3. Insurance"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.2rem%22%2C%22line-height%22%3A%221.7%22%7D%7D"]

Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.Capitalize on low hanging fruit to identify a ballpark value added activity to beta test.

Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.

[/vc_column_text][/vc_tta_section][vc_tta_section title="4. Taxation"][vc_column_text css="%7B%22default%22%3A%7B%22font-size%22%3A%221.2rem%22%2C%22line-height%22%3A%221.7%22%7D%7D"]<p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution.</p><p>User generated content in real-time will have multiple touchpoints for offshoring. Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps.</p><p>Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service.</p>[/vc_column_text][/vc_tta_section][/vc_tta_tour][us_separator][us_text text="View All Service" link="%7B%22url%22%3A%22%23%22%7D" css="%7B%22default%22%3A%7B%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22600%22%7D%2C%22laptops%22%3A%7B%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22600%22%7D%2C%22tablets%22%3A%7B%22font-size%22%3A%221.5rem%22%2C%22font-weight%22%3A%22600%22%7D%2C%22mobiles%22%3A%7B%22font-size%22%3A%221rem%22%2C%22font-weight%22%3A%22600%22%7D%7D" icon="fas|arrow-right" iconpos="right"][/vc_column][/vc_row]
```

### `13`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-13>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-13.jpg> (700×317)

```text
[vc_row columns="3-2" laptops_columns="1" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%7D%7D" content_placement="middle"][vc_column width="3/5"][vc_row_inner columns="2"][vc_column_inner width="1/2"][us_text text="01" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%202.5rem%20%2B%202.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-weight%22%3A%22600%22%7D%7D"][us_separator size="small"][vc_column_text]<h3>Contact Us</h3><p>Leverage agile frameworks to provide a robust synopsis for high level overviews</p>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="02" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%202.5rem%20%2B%202.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-weight%22%3A%22600%22%7D%7D"][us_separator size="small"][vc_column_text]
<h3>Conversation</h3>
Iterative approaches to corporate strategy foster collaborative thinking

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="03" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%202.5rem%20%2B%202.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-weight%22%3A%22600%22%7D%7D"][us_separator size="small"][vc_column_text]
<h3>Contract</h3>
Bring to the table win-win survival strategies to ensure proactive domination

[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_text text="04" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22font-size%22%3A%22calc%28%202.5rem%20%2B%202.5vmax%20%29%22%2C%22line-height%22%3A%221%22%2C%22font-weight%22%3A%22600%22%7D%7D"][us_separator size="small"][vc_column_text]
<h3>Work!</h3>
Capitalize on low hanging fruit to identify a ballpark value added activity

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="2/5"][us_image align="center" image="5786" css="%7B%22default%22%3A%7B%22border-radius%22%3A%2210px%22%2C%22aspect-ratio%22%3A%221%22%7D%7D" style="circle"][/vc_column][/vc_row]
```

### `14`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-14>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-14.jpg> (700×560)

```text
[vc_row columns_gap="0px" columns="1" columns_gap_source="custom"][vc_column][us_separator size="custom" height="2rem" show_line="1"][vc_row_inner columns="2" columns_gap="30px" content_placement="bottom" columns_gap_source="custom"][vc_column_inner width="1/2"][us_text text="01" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_border%22%2C%22font-size%22%3A%22max%28%206rem%2C%206vw%20%29%22%2C%22line-height%22%3A%221%22%7D%7D"][us_text text="Years of Development" tag="h3"][/vc_column_inner][vc_column_inner width="1/2"][us_image image="5786" css="%7B%22default%22%3A%7B%22aspect-ratio%22%3A%2216%5C%2F9%22%7D%7D"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column][us_separator size="custom" height="2rem" show_line="1"][vc_row_inner columns="2" columns_gap="30px" content_placement="bottom" columns_gap_source="custom"][vc_column_inner width="1/2"][us_text text="02" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_border%22%2C%22font-size%22%3A%22max%28%206rem%2C%206vw%20%29%22%2C%22line-height%22%3A%221%22%7D%7D"][us_text text="Professional Managers" tag="h3"][/vc_column_inner][vc_column_inner width="1/2"][us_image image="5787" css="%7B%22default%22%3A%7B%22aspect-ratio%22%3A%2216%5C%2F9%22%7D%7D"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column][us_separator size="custom" height="2rem" show_line="1"][vc_row_inner columns="2" columns_gap="30px" content_placement="bottom" columns_gap_source="custom"][vc_column_inner width="1/2"][us_text text="03" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_border%22%2C%22font-size%22%3A%22max%28%206rem%2C%206vw%20%29%22%2C%22line-height%22%3A%221%22%7D%7D"][us_text text="High Visual Quality" tag="h3"][/vc_column_inner][vc_column_inner width="1/2"][us_image image="2460" css="%7B%22default%22%3A%7B%22aspect-ratio%22%3A%2216%5C%2F9%22%7D%7D"][/vc_column_inner][/vc_row_inner][us_separator size="custom" height="2rem" show_line="1"][/vc_column][/vc_row]
```

### `15`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-15>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-15.jpg> (700×181)

```text
[vc_row columns="4" columns_gap="1.5rem" ignore_columns_stacking="1" tablets_columns="2" equal_columns_height="1" columns_gap_source="custom"][vc_column width="1/4" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][us_iconbox icon="fas|user-shield" title="1. Register" size="3rem" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg%22%2C%22padding-left%22%3A%222rem%22%2C%22padding-top%22%3A%222rem%22%2C%22padding-bottom%22%3A%222rem%22%2C%22padding-right%22%3A%222rem%22%2C%22border-radius%22%3A%220.3rem%22%2C%22box-shadow-v-offset%22%3A%225px%22%2C%22box-shadow-blur%22%3A%2230px%22%2C%22box-shadow-color%22%3A%22rgba%280%2C0%2C0%2C0.08%29%22%7D%7D" title_tag="h5" alignment="none"]<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>[/us_iconbox][/vc_column][vc_column width="1/4" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][us_iconbox icon="fas|pencil-ruler" title="2. Design" size="3rem" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg%22%2C%22padding-left%22%3A%222rem%22%2C%22padding-top%22%3A%222rem%22%2C%22padding-bottom%22%3A%222rem%22%2C%22padding-right%22%3A%222rem%22%2C%22border-radius%22%3A%220.3rem%22%2C%22box-shadow-v-offset%22%3A%225px%22%2C%22box-shadow-blur%22%3A%2230px%22%2C%22box-shadow-color%22%3A%22rgba%280%2C0%2C0%2C0.08%29%22%7D%7D" title_tag="h5" alignment="none"]<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>[/us_iconbox][/vc_column][vc_column width="1/4" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][us_iconbox icon="fas|shipping-fast" title="3. Deliver" size="3rem" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg%22%2C%22padding-left%22%3A%222rem%22%2C%22padding-top%22%3A%222rem%22%2C%22padding-bottom%22%3A%222rem%22%2C%22padding-right%22%3A%222rem%22%2C%22border-radius%22%3A%220.3rem%22%2C%22box-shadow-v-offset%22%3A%225px%22%2C%22box-shadow-blur%22%3A%2230px%22%2C%22box-shadow-color%22%3A%22rgba%280%2C0%2C0%2C0.08%29%22%7D%7D" title_tag="h5" alignment="none"]<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>[/us_iconbox][/vc_column][vc_column width="1/4" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][us_iconbox icon="fas|thumbs-up" title="4. Like" size="3rem" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg%22%2C%22padding-left%22%3A%222rem%22%2C%22padding-top%22%3A%222rem%22%2C%22padding-bottom%22%3A%222rem%22%2C%22padding-right%22%3A%222rem%22%2C%22border-radius%22%3A%220.3rem%22%2C%22box-shadow-v-offset%22%3A%225px%22%2C%22box-shadow-blur%22%3A%2230px%22%2C%22box-shadow-color%22%3A%22rgba%280%2C0%2C0%2C0.08%29%22%7D%7D" title_tag="h5" alignment="none"]<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>[/us_iconbox][/vc_column][/vc_row]
```

### `16`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-16>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-16.jpg> (700×327)

```text
[vc_row columns="1" width="custom" width_custom="1400px"][vc_column][vc_row_inner columns="4" tablets_columns="2" columns_gap="0rem" columns_type="1" css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg%22%2C%22box-shadow-blur%22%3A%2250px%22%2C%22box-shadow-color%22%3A%22rgba%280%2C0%2C0%2C0.10%29%22%7D%7D" columns_gap_source="custom"][vc_column_inner width="1/4"][vc_column_text]<h2><strong>1</strong></h2><h3>Register Easily</h3>[/vc_column_text][/vc_column_inner][vc_column_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_border%22%2C%22background-image%22%3A%22use%3Aplaceholder%22%2C%22background-position%22%3A%2250%25%22%2C%22background-size%22%3A%22cover%22%7D%7D" hide_on_states="mobiles" width="1/4"][/vc_column_inner][vc_column_inner width="1/4"][vc_column_text]<h2><strong>3</strong></h2><h3>Deliver Fastly</h3>[/vc_column_text][/vc_column_inner][vc_column_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_border%22%2C%22background-image%22%3A%22use%3Aplaceholder%22%2C%22background-position%22%3A%2250%25%22%2C%22background-size%22%3A%22cover%22%7D%7D" hide_on_states="mobiles" width="1/4"][/vc_column_inner][vc_column_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_border%22%2C%22background-image%22%3A%22use%3Aplaceholder%22%2C%22background-position%22%3A%2250%25%22%2C%22background-size%22%3A%22cover%22%7D%7D" hide_on_states="mobiles" width="1/4"][/vc_column_inner][vc_column_inner width="1/4"][vc_column_text]<h2><strong>2</strong></h2><h3>Design Together</h3>[/vc_column_text][/vc_column_inner][vc_column_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_border%22%2C%22background-image%22%3A%22use%3Aplaceholder%22%2C%22background-position%22%3A%2250%25%22%2C%22background-size%22%3A%22cover%22%7D%7D" hide_on_states="mobiles" width="1/4"][/vc_column_inner][vc_column_inner width="1/4"][vc_column_text]<h2><strong>4</strong></h2><h3>Like and Share</h3>[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
```

### `17`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-17>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-17.jpg> (700×347)

```text
[vc_row columns="3" tablets_columns="2" ignore_columns_stacking="1" columns_gap="4vw" equal_columns_height="1" columns_gap_source="custom"][vc_column width="1/3"][us_text text="1" tag="h1" css="%7B%22default%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22laptops%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22tablets%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22mobiles%22%3A%7B%22font-size%22%3A%226rem%22%2C%22font-weight%22%3A%22400%22%7D%7D"][us_image image="5786" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%2C%22aspect-ratio%22%3A%221%22%7D%7D"][us_separator size="small"][vc_column_text]<p>Credibly innovate granular internal or "organic" sources whereas high standards in web-readiness. Energistically scale future-proof core competencies impactful experiences.</p>[/vc_column_text][/vc_column][vc_column width="1/3"][us_text text="2" tag="h1" css="%7B%22default%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22laptops%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22tablets%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22mobiles%22%3A%7B%22font-size%22%3A%226rem%22%2C%22font-weight%22%3A%22400%22%7D%7D"][us_image image="5783" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%2C%22aspect-ratio%22%3A%221%22%7D%7D"][us_separator size="small"][vc_column_text]<p>Credibly innovate granular internal or "organic" sources whereas high standards in web-readiness. Energistically scale future-proof core competencies impactful experiences.</p>[/vc_column_text][/vc_column][vc_column width="1/3"][us_text text="3" tag="h1" css="%7B%22default%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22laptops%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22tablets%22%3A%7B%22font-weight%22%3A%22400%22%7D%2C%22mobiles%22%3A%7B%22font-size%22%3A%226rem%22%2C%22font-weight%22%3A%22400%22%7D%7D"][us_image image="5789" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%2C%22aspect-ratio%22%3A%221%22%7D%7D"][us_separator size="small"][vc_column_text]<p>Credibly innovate granular internal or "organic" sources whereas high standards in web-readiness. Energistically scale future-proof core competencies impactful experiences.</p>[/vc_column_text][/vc_column][/vc_row]
```

### `18`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-18>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-18.jpg> (700×355)

```text
[vc_row columns="1"][vc_column][us_text text="How We Teach" tag="h2"][us_separator][vc_tta_tabs layout="timeline2" title_font="h1" tabs_alignment="justify" title_size="1.8rem"][vc_tta_section title="1" active="1"][vc_row_inner content_placement="middle" columns="2"][vc_column_inner width="1/2"][vc_column_text]
<h3>Structured Educational Programs</h3>
In our courses, we strive to combine all aspects you need for your project, including:
<ul>
 	<li>Analytics of possible solutions</li>
 	<li>Training of practical skills</li>
 	<li>Project management</li>
 	<li>Promotion &amp; Marketing</li>
</ul>
[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_image image="7660" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="2"][vc_row_inner content_placement="middle" columns_reverse="1" columns="2"][vc_column_inner width="1/2"][us_image image="5787" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_column_inner][vc_column_inner width="1/2"][vc_column_text]
<h3>Easy to Start</h3>
Our courses are adjusted for all levels of knowledge, from a complete newbie to an advanced level of skills.

We got all aspects covered and will help you improve your expertise in any theme you choose.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="3"][vc_row_inner content_placement="middle" columns="2"][vc_column_inner width="1/2"][vc_column_text]
<h3>Real Projects Practice</h3>
Along with training exercises, we provide training in real projects, so you can see the actual effect and results of solutions and skills you gain as you learn[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][us_image image="5786" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="4"][vc_row_inner content_placement="middle" columns_reverse="1" columns="2"][vc_column_inner width="1/2"][us_image image="2460" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_column_inner][vc_column_inner width="1/2"][vc_column_text]
<h3>Certification &amp; Real Job Opportunities</h3>
Your final test will be a real task for the ongoing project, allowing you to see your actual contribution and prove your expertise.

A successful final project opens wide opportunities for becoming an employee in one of our partner companies.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][/vc_tta_tabs][/vc_column][/vc_row]
```

### `19`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-19>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-19.jpg> (700×403)

```text
[vc_row columns="1"][vc_column][us_text text="what we do" css="%7B%22default%22%3A%7B%22color%22%3A%22_content_primary%22%2C%22text-align%22%3A%22center%22%2C%22font-size%22%3A%221.2rem%22%2C%22letter-spacing%22%3A%221px%22%2C%22text-transform%22%3A%22uppercase%22%7D%7D"][us_text text="Work Algorithm" tag="h2" css="%7B%22default%22%3A%7B%22text-align%22%3A%22center%22%7D%7D"][us_separator size="small"][vc_tta_tabs layout="simple3" tabs_alignment="center" remove_indents="1" c_align="center"][vc_tta_section title="First Step" bg_color="_content_bg"][vc_row_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%225%25%22%2C%22padding-bottom%22%3A%225%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D" columns="1"][vc_column_inner][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%7D%7D"]
<h3>Audit and Analysis of Competitors</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fames tristique rutrum porta at eu tempus. Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.
<ul>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
 	<li>Lorem ipsum dolor sit amet</li>
 	<li>Faucibus dolor mauris nascetur ut feugia</li>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
</ul>
Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="Second Step"][vc_row_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%225%25%22%2C%22padding-bottom%22%3A%225%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D" columns="1"][vc_column_inner][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%7D%7D"]
<h3>Implementation of the first changes</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fames tristique rutrum porta at eu tempus. Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.

Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="Third Step"][vc_row_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%225%25%22%2C%22padding-bottom%22%3A%225%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D" columns="1"][vc_column_inner][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%7D%7D"]
<h3>Integrated development</h3>
Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.
<ul>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
 	<li>Lorem ipsum dolor sit amet</li>
 	<li>Faucibus dolor mauris nascetur ut feugia</li>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
</ul>
[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="Fourth Step"][vc_row_inner css="%7B%22default%22%3A%7B%22background-color%22%3A%22_content_bg_alt%22%2C%22padding-left%22%3A%228%25%22%2C%22padding-top%22%3A%225%25%22%2C%22padding-bottom%22%3A%225%25%22%2C%22padding-right%22%3A%228%25%22%2C%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D" columns="1"][vc_column_inner][vc_column_text css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%7D%7D"]
<h3>First results</h3>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fames tristique rutrum porta at eu tempus. Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.
<ul>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
 	<li>Lorem ipsum dolor sit amet</li>
 	<li>Faucibus dolor mauris nascetur ut feugia</li>
 	<li>Egestas aliquet ullamcorper nunc sed pellentesque</li>
</ul>
Egestas aliquet ullamcorper nunc sed pellentesque. Faucibus dolor mauris nascetur ut feugiat hac rutrum tempor congue. Egestas eget adipiscing scelerisque.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][/vc_tta_tabs][/vc_column][/vc_row]
```

### `20`

**Category**: `st` — Steps
**Preview**: <https://templates.us-themes.com/steps/#section-20>
**Thumbnail**: <https://templates.us-themes.com/wp-content/uploads/2026/09/steps-20.jpg> (700×360)

```text
[vc_row width="full" height="auto" columns="1"][vc_column][vc_tta_tabs layout="modern" title_font="h1" title_size="calc( 15px + 1vw )" accordion_at_width="1024px" title_tag="h4" scrolling="" tabs_alignment="center" title_lineheight="2.5" title_weight="400"][vc_tta_section title="01. Register" css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%2C%22margin-left%22%3A%22auto%22%2C%22margin-right%22%3A%22auto%22%7D%7D"][vc_column_text]<h3 style="text-align: center;"><strong>Register Your Account</strong></h3><p style="text-align: center;">Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</p>[/vc_column_text][us_separator][vc_video overlay_image="5783" overlay_icon_bg_color="_content_primary" overlay_icon_size="1.2rem" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_tta_section][vc_tta_section title="02. Deploy" css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%2C%22margin-left%22%3A%22auto%22%2C%22margin-right%22%3A%22auto%22%7D%7D"][vc_column_text]<h3 style="text-align: center;"><strong>Deploy Your Goods</strong></h3><p style="text-align: center;">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships.</p>[/vc_column_text][us_separator][vc_video overlay_image="5786" overlay_icon_bg_color="_content_primary" overlay_icon_size="1.2rem" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_tta_section][vc_tta_section title="03. Analyze" css="%7B%22default%22%3A%7B%22max-width%22%3A%22800px%22%2C%22margin-left%22%3A%22auto%22%2C%22margin-right%22%3A%22auto%22%7D%7D"][vc_column_text]<h3 style="text-align: center;"><strong>Analyze Your Data</strong></h3><p style="text-align: center;">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships.</p>[/vc_column_text][us_separator][vc_video overlay_image="7658" overlay_icon_bg_color="_content_primary" overlay_icon_size="1.2rem" css="%7B%22default%22%3A%7B%22border-radius%22%3A%22var%28--site-border-radius%29%22%7D%7D"][/vc_tta_section][/vc_tta_tabs][/vc_column][/vc_row]
```

