---
title: `us_gmaps` — Map
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/gmaps.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/gmaps.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=gmaps
  Direct edits here will be lost on the next regeneration.
-->

# `us_gmaps` — Map

**When to use**: an interactive map embed pointing to one (or several) addresses, with optional info-window text. Typical placement: a contact page, a "find us" footer block, a multi-location showroom list.

**Avoid when**:
- you only need a static map image — Google's static API or a screenshot is lighter;
- you want a route / directions widget — `us_gmaps` only renders pins, not navigation;
- the only purpose is to surface the address text — use `[us_contacts address="…"]` (no map JS, no API needed).

**Providers**: two backends are supported via `provider`:
- `google` (default) — requires a Google Maps API key configured at **Theme Options → General → Google Maps API Key**. Without it, the embed renders the "for development purposes only" watermark.
- `osm` — OpenStreetMap (Leaflet). No API key required for the default OSM tiles; third-party tile styles in `layer_style` may need one (see below).

**Key parameters**

**Main marker**

| Param | What it does |
|-------|--------------|
| `marker_address` | Address or geo-coordinates (e.g. `38.6774156, 34.8520661`) for the primary pin. Required. |
| `marker_text` | HTML body for the marker's info window. **Must be base64-encoded** (the param's config has `encoded => TRUE`). `{{address}}` inside the body is replaced by the resolved address string. |
| `show_infowindow` | `1` opens the info window on load (rather than only on click). |
| `custom_marker_img` | Media-library ID (or URL) of a custom pin image. PNG/JPG/SVG. |
| `custom_marker_size` | Pin image size — one of `20`/`30`/`40`/`50`/`60`/`70`/`80` (pixels). Default `30`. |
| `markers` | Group of additional pins. JSON list; each item has `marker_address`, `marker_text` (textarea, not encoded), `marker_img`, `marker_size`. |

**Appearance**

| Param | What it does |
|-------|--------------|
| `provider` | `google` (default) or `osm`. Switches API and toggles which extra params apply. |
| `type` | (`provider="google"` only) Tile style — `roadmap` (default), `terrain`, `satellite`, `hybrid`. |
| `zoom` | Map zoom level 1–20. Default `14`. |
| `hide_controls` | `1` hides all map controls (zoom buttons, fullscreen). |
| `disable_zoom` | `1` disables zoom on mouse-wheel scroll. **Strongly recommended** when the map is in the page flow — otherwise visitors who scroll over it get trapped. |
| `disable_dragging` | `1` disables one-finger dragging on touch screens (visitor must use two fingers). |
| `map_style_json` | (`provider="google"` only) Snazzymaps-style JSON to recolor the map. **Base64-encoded**. |
| `layer_style` | (`provider="osm"` only) Tile-server URL template, e.g. `https://tile.openstreetmap.org/{z}/{x}/{y}.png` (the default when empty). See leaflet-providers for the catalog. Some providers need an API key inside the URL — CARTO tiles (`basemaps.cartocdn.com`) render an "API key required" watermark without `?key=<key>`, e.g. `https://basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png?key=<key>`. Never emit a CARTO URL without a key the user supplied. |

**Sizing**

The map height comes from the Design Options group (custom CSS `height`). There is no `height` shortcode attribute — set it via the builder's Design panel or wrap the shortcode in a fixed-height container.

**Minimal example**

```text
[us_gmaps marker_address="1600 Amphitheatre Parkway, Mountain View, CA" zoom="15" disable_zoom="1"]
```

**Common combinations**

OpenStreetMap, no API key needed:

```text
[us_gmaps provider="osm" marker_address="55.7558, 37.6173" zoom="13" disable_zoom="1"]
```

With an info window (note the base64-encoded body):

```text
[us_gmaps marker_address="Berlin, Germany" show_infowindow="1" marker_text="PGgyPkJlcmxpbiBPZmZpY2U8L2gyPjxwPllvdXIgdHJ1c3RlZCB0ZWFtLjwvcD4="]
```

(`marker_text` decodes to `<h2>Berlin Office</h2><p>Your trusted team.</p>`.)

**Anti-patterns**

- Forgetting `disable_zoom="1"` — the map captures mouse-wheel scroll and visitors can't continue down the page.
- Pasting raw HTML into `marker_text` — it must be base64-encoded; non-encoded HTML reads as literal text and breaks the info window.
- Embedding the map without configuring a Google API key (with `provider="google"`) — the embed renders a "for development purposes only" watermark.
- Using `markers` for a single pin — use the top-level `marker_*` params; the group is for **additional** pins.

## Parameters pending manual description (auto-extracted)

> The parameters below exist in `plugins/us-core/config/elements/gmaps.php` but are not yet covered by the curated body above. Names / types / defaults / enum keys are authoritative; usage prose is missing — prefer the documented parameters when both can express the intent.
> Maintainers: describe these in `scripts/llms/manual/shortcodes/gmaps.md`, then refresh the baseline (`build.php --only=content-shortcodes --update-params-baseline`).

| Param | Type | Default | Options | Show if | Title |
|-------|------|---------|---------|---------|-------|
| `marker_source` | select | addresses | addresses / posts / current_wp_query | — | Marker Source |
| `coords_field` | select | — | — | `marker_source` != addresses | Coordinates Field |
| `post_type` | checkboxes | post | — | `marker_source` = posts | Post Type |
| `apply_url_params` | switch | 0 | — | `marker_source` = posts | Use URL params to show results |
| `marker_click` | select | grid_layout | none / post_link / grid_layout | `marker_source` != addresses | Marker Click |
| `items_layout` | select | map_marker_1 | — | `marker_source` != addresses AND `marker_click` = grid_layout | Marker Popup Layout |
| `infowindow_width` | text | 300px | — | `marker_source` != addresses AND `marker_click` = grid_layout | Marker Popup Width |
| `marker_style` | select | pin | default / pin / dot / ring / label / image | — | Marker Style |
| `marker_label` | text | {{the_title}} | — | `marker_style` = label | — |
| `marker_color` | color | _content_primary | — | `marker_style` = [`pin`, `dot`, `ring`, `label`] | Marker Color |
| `marker_image` | upload | — | — | `marker_style` = image | — |
| `fade_visited_markers` | switch | 0 | — | [["marker_source","!=","addresses"],"an… | Fade visited markers |
| `visited_marker_contrast` | slider | 50% | % | [["fade_visited_markers","=",1],"and",[… | Visited Marker Contrast |
| `cluster_markers` | switch | 0 | — | `marker_source` != addresses | Group markers into clusters |
| `cluster_color` | color | _content_secondary | — | `cluster_markers` = 1 | Cluster Color |


## Legacy / fallback attributes (auto-extracted)

> The attributes below were removed from the builder UI of `gmaps` and moved to the element's `fallback_params` in `plugins/us-core/config/elements/gmaps.php`. They are still parsed for backward compatibility but are **deprecated** — do not use them in new content; prefer the current controls. If the curated body above still documents one as a current parameter, that prose is now stale.
> Maintainers: describe these as legacy (or drop the stale rows) in `scripts/llms/manual/shortcodes/gmaps.md`, then refresh the baseline (`build.php --only=content-shortcodes --update-params-baseline`).

| Legacy attribute | Status |
|------------------|--------|
| `custom_marker_img` | moved to `fallback_params` — deprecated, still accepted |
