---
title: `us_html` — Raw HTML
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/html.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/html.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=html
  Direct edits here will be lost on the next regeneration.
-->

# `us_html` — Raw HTML

**When to use**: paste arbitrary HTML/JS/CSS into the page — third-party embed snippets (Calendly, Typeform, custom map widgets), inline `<script>`/`<style>` for one-off pages, structured-data JSON-LD.

**Avoid when**:
- you have a single styled paragraph or heading — `us_text` is the right call;
- the content is rich-edited prose — `vc_column_text`;
- the snippet is large and needs editor highlighting — keep it in a child-theme template and just place an anchor here.

**Body — encoded, not raw.** The markup is the shortcode's **inner content**, and it is stored **base64-encoded** (`'encoded' => TRUE` in the config). At render time `templates/elements/html.php` runs `rawurldecode( base64_decode( … ) )`, so the body you write must be `base64_encode( rawurlencode( $your_html ) )` — in that order. Pasting raw HTML between the tags decodes to garbage and the block renders empty; that failure is silent.

Encode with one of:

```text
PHP         base64_encode( rawurlencode( $html ) )
JS          btoa( encodeURIComponent( html ) )
PowerShell  [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes([Uri]::EscapeDataString($html)))
```

The decoded content is then run through the dynamic-value resolver and `do_shortcode()`, so `{{…}}` tokens and nested shortcodes work inside it.

**Key parameters**

| Param | What it does |
|-------|--------------|
| `content` | The encoded body described above — written between the tags, never as an attribute. |
| `el_id` | Optional `id` on the wrapping `<div class="w-html">`. |

**Minimal example**

`<div id="widget-host"></div>`, encoded:

```text
[us_html]JTNDZGl2JTIwaWQlM0QlMjJ3aWRnZXQtaG9zdCUyMiUzRSUzQyUyRmRpdiUzRQ==[/us_html]
```

**Anti-patterns**

- Writing an `html="…"` attribute, or pasting raw unencoded markup between the tags — neither reaches the page.
- Pasting tracking scripts that should live in `<head>` site-wide — put them in Theme Options → Code instead.
- Inline `<style>` that overrides theme variables on every page — extract to a child-theme stylesheet.
- Using `us_html` for everything — you lose the structured editing benefits of UpSolution shortcodes.
