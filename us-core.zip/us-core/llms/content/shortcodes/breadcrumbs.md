---
title: `us_breadcrumbs` — Breadcrumbs
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/breadcrumbs.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/breadcrumbs.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=breadcrumbs
  Direct edits here will be lost on the next regeneration.
-->

> **Section context — where to use these.**
>
> Every shortcode in this section is **designed for Page Templates** (`us_content_template`). See [post-types.md](post-types.md) for the Page vs Template distinction.
>
> Each element looks up its value on the **current post in the loop**:
>
> - on a single post, page or CPT — the post being viewed;
> - on an archive / search / Grid Layout card — the post for the current loop iteration;
> - on a term archive — the term being viewed (the title / content elements adapt to term data).
>
> Using them **outside a Page Template** (e.g. dropped directly into the body of a regular page or post) is **not forbidden** — the parser will run them — but rarely useful: the "current post" resolves to the hosting page itself, so `[us_post_title]` on a page named "About" just outputs "About", `[us_post_taxonomy]` outputs that page's terms (usually none), and `[us_post_navigation]` walks the page hierarchy instead of a post sequence. Reach for these only when you know which post the loop will resolve to and that's the value you want surfaced.
>
> The one element with a hard gate is `us_post_content` — the builder UI only exposes it when editing a `us_content_template`. The rest is technically droppable anywhere; the guidance above is editorial, not enforced.

# `us_breadcrumbs` — Breadcrumbs

**When to use**: a "Home › Section › Subsection › *current page*" trail at the top of any post / page / archive. The default trail is **assembled for you** — a "Home" link followed by the automatically computed ancestor path of the current view (parent categories, parent pages, date archives, the CPT's taxonomy chain). In most cases you just drop `[us_breadcrumbs]` and configure the rest in the builder. Typical placement: just under the site header, inside a slim row with a small bottom margin.

**Avoid when**:
- the site is a single landing page — there's no hierarchy worth showing;
- you want a free-form nav unrelated to the page hierarchy — write the markup directly in `us_text` or use `vc_widget_sidebar` with a custom-menu widget.

**How the trail is built — the `items` group.** The crumbs are an ordered list of *items*, each with a `source`. The default list is one **Custom** crumb ("Home" → homepage) followed by one **Auto** crumb, i.e. `Home › <computed ancestor path>`. The four sources:

| `source` | What that crumb outputs |
|----------|-------------------------|
| `auto` | The automatic ancestor path of the current view: parent categories on a category archive, parent pages on a child page, year/month on a date archive, the taxonomy chain on a single CPT post. Renders nothing when the view has no ancestors. This is the classic "smart" breadcrumb. |
| `custom` | A fixed crumb from your own `label` + `link`. The default first item is a Custom "Home" crumb. An **empty link** renders the label as plain text (no anchor); an **empty label** drops the crumb entirely. `label` and `link` support dynamic-value tokens. |
| `page` | A specific, manually chosen published page, linked by its title. Trashed / draft / private / missing pages output nothing. |
| `taxonomy` | The term hierarchy of a chosen taxonomy — the queried term's ancestors on that taxonomy's archive, or the post's term chain (first term) on a singular post. Outputs nothing on unrelated views. |

`items` is edited in the builder as a **sortable list** — that's the intended way to compose the trail. When you *do* set it as a shortcode attribute it is a **URL-encoded JSON** group value (like every group param); never paste raw single-quoted JSON, it gets mangled and the element silently falls back to the default trail. For hand-written shortcodes, leave `items` at its default and control the trail through the element-level params below.

**Key parameters**

| Param | What it does |
|-------|--------------|
| `items` | The ordered crumb list (group param, see above). Default = `Home` (custom) + `auto` computed trail. Leave as-is unless you need to insert a fixed page/link or a taxonomy chain; edit it in the builder, not by hand. |
| `show_current` | `1` appends the current page's title as the last crumb (plain text). `0` (default) stops one level earlier. |
| `link_current` | `1` makes that last crumb a link to the current page instead of plain text. Only takes effect with `show_current="1"`. Default `0`. |
| `show_page_number` | `1` (default) appends ` (Page N)` on paginated archive views. Only takes effect with `show_current="1"`. Set `0` to suppress it. |
| `separator_type` | `icon` (default) or `custom` (a typed symbol). |
| `separator_icon` | Icon between crumbs when `separator_type="icon"`. Default `far|angle-right`. Format `<style>|<name>`. |
| `separator_symbol` | Text between crumbs when `separator_type="custom"`. Default `/`. Common alternatives: ` › `, ` » `, ` &middot; `, ` | `. |

**Legacy attributes** (still accepted for backward compatibility — do **not** use in new content):
- `home` — the old homepage-label attribute. The Home crumb is now the first Custom item of `items`; its label lives there. Third-party trails (WooCommerce / bbPress) still read this label from the first custom item.
- `align` — the old alignment attribute (`left` / `center` / `right`), a fallback since 9.0.1. Alignment is now part of the element's design options; set it there instead.

**Behavior notes** (not attributes):
- The element never renders on the site front page, and never inside a loop/Grid-Layout card item.
- WooCommerce and bbPress replace the whole trail with their own when active.
- When the theme's Schema Markup option is on, the trail emits `schema.org/BreadcrumbList` microdata.

**Minimal example**

```text
[us_breadcrumbs]
```

**Common combinations**

Show the current page as a plain last crumb, with `›` separators:

```text
[us_breadcrumbs show_current="1" separator_type="custom" separator_symbol=" › "]
```

Current page shown **and** linked, chevron icon separator, no `(Page N)` suffix on paged archives:

```text
[us_breadcrumbs show_current="1" link_current="1" show_page_number="0" separator_type="icon" separator_icon="fas|chevron-right"]
```

**Anti-patterns**

- Passing `items` as raw single-quoted JSON in a shortcode — group params must be URL-encoded, otherwise the value is mangled and the trail silently reverts to `Home › auto`. Compose `items` in the builder instead.
- `link_current="1"` or `show_page_number="0"` without `show_current="1"` — both are gated on the current crumb being shown, so they do nothing on their own.
- `show_current="1"` on a page where the title is already in the H1 directly above — the page title appears twice, two characters apart, looking like a bug.
- Reaching for the legacy `home=""` to hide the homepage crumb — edit (or remove) the first Custom item in `items` instead; the `home` attribute is a compatibility shim, not the current control.
- Custom `separator_symbol=" - "` with literal spaces — the surrounding values lean too close; use ` - ` with non-breaking spaces or switch to `separator_type="icon"`.
