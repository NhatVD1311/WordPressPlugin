---
title: `us_cta` — Call To Action
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/cta.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/cta.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=cta
  Direct edits here will be lost on the next regeneration.
-->

# `us_cta` — Call To Action

**When to use**: a compact promotional block — large heading, sub-text and one (or two) buttons, framed as a section break inviting action. Typical pre-footer block.

**Avoid when**:
- the page already has a clear hero CTA — multiple `us_cta` blocks dilute focus;
- you only need a button — `[us_btn]`;
- you need a feature card — `[us_iconbox]`.

**Body**: the sub-text is the shortcode's **inner content**, not an attribute — always write the pair `[us_cta …]Sub-text[/us_cta]`. It accepts HTML and nested shortcodes and is run through the dynamic-value resolver. Leave the body empty (`[us_cta …][/us_cta]`) for a heading-plus-buttons block; the closing tag is still required.

**Key parameters**

| Param | What it does |
|-------|--------------|
| `title` | Headline. Newlines inside the value are kept, so a two-line headline is written literally. |
| `title_tag` | `h2` (default), `h1`, `h3`–`h6`, `div`, `p`, `span`. |
| `title_size` | Custom CSS font-size for the headline (e.g. `max( 2rem, 4.5vh )`). |
| `color` | Color scheme of the block — `primary` (default), `secondary`, `light`. It is a scheme name, **not** a CSS color; for a specific background use `css=`'s `background-color` (composition-rules §3.3). |
| `controls` | Where the buttons sit relative to the text — `right` (default) or `bottom`. |

**Primary button**

| Param | What it does |
|-------|--------------|
| `btn_label` | Button text. |
| `btn_link` | URL-encoded JSON (see composition-rules §3.1). |
| `btn_style` | Per-site button style from Theme Options → Buttons (`1`, `2`, …). |
| `btn_size` | Custom CSS font-size for the button. |
| `btn_icon` | Icon, `set|name` (composition-rules §3.6). |
| `btn_iconpos` | `left` (default) or `right`. |

**Second button** — set `second_button="1"`, then the `btn2_*` twins apply: `btn2_label`, `btn2_link`, `btn2_style`, `btn2_size`, `btn2_icon`, `btn2_iconpos`. Same shapes as above.

**Minimal example**

```text
[us_cta title="Ready to start?" btn_label="Start now" btn_link="%7B%22url%22%3A%22%23signup%22%7D"]Free for 14 days, no credit card.[/us_cta]
```

**Common combinations**

Two buttons, stacked under the text, on the light scheme:

```text
[us_cta title="Ready to dive in?" controls="bottom" color="light" btn_label="Get started" btn_link="%7B%22url%22%3A%22%23%22%7D" second_button="1" btn2_label="Learn more" btn2_style="2" btn2_link="%7B%22url%22%3A%22%2Fdocs%22%7D"][/us_cta]
```

**Anti-patterns**

- Writing `text="…"`, `controls_align="…"`, `color_bg="…"` or `second_btn_*` — none of those exist. The sub-text is the body, the buttons' position is `controls`, the background goes in `css=`, and the second button's params are `btn2_*`.
- Self-closing the tag (`[us_cta …]` with no `[/us_cta]`) — the block needs its closing tag even with an empty body.
- Vague titles (`Get started today!`) without saying what — pair with concrete value (`Start your free 14-day trial`).
- Two CTAs pointing to the same URL — one is enough.
