---
title: `us_separator` — Separator
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/separator.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/separator.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=separator
  Direct edits here will be lost on the next regeneration.
-->

# `us_separator` — Separator

**When to use**: introduce vertical space or a visible divider between content blocks. Two roles:

- **Spacer** — invisible vertical gap (no line);
- **Divider** — horizontal line with optional thickness/color, or a full-height vertical line with rotated text (e.g. a "Scroll down" side label).

**Avoid when**:
- you just need spacing inside a horizontal/vertical wrapper — use the `gap` param on `us_hwrapper`/`us_vwrapper`;
- you want a decorative shape between sections — use `vc_row.us_shape_*` (shape dividers).

**Key parameters**

| Param | What it does |
|-------|--------------|
| `layout` | `horizontal` (default) or `vertical`. Horizontal is a spacer/line with its own height (`size`/`height`); vertical takes the full height of its container instead — size it via Design settings (width/height), not `size`. |
| `size` | Vertical space size — preset (`small`/`medium`/`large`/`huge`) or `custom`. Horizontal layout only. |
| `height` | Custom CSS height when `size="custom"` (e.g. `60px`, `4rem`). Horizontal layout only. |
| `show_line` | `1` to draw a visible line, `0` for invisible spacer. |
| `line_width` | Width of the line (`100%`, `50%`, `200px`). Horizontal layout only. |
| `thick` | Line thickness in px. |
| `style` | Line style — `solid` / `dashed` / `dotted` / `double`. |
| `color` | Line color preset — `border` (default, theme border color) / `text` / `primary` / `secondary` / `custom`. |
| `line_color` | Custom line color (HEX/RGBA/palette token); only used when `color="custom"`. |
| `align` | Title alignment (`none`/`left`/`center`/`right`). Horizontal layout only. |
| `text_orient` | Vertical layout only, when a `text` is set: reading direction of the rotated title — `down` (default, top-to-bottom) or `up`. |
| `valign` | Vertical layout only, when a `text` is set: position of the title along the line — `top` / `middle` (default) / `bottom`. |

**Minimal example**

```text
[us_separator size="medium" show_line="1"]
```

Vertical divider with a rotated label, e.g. inside a `us_vwrapper` in a hero section:

```text
[us_separator layout="vertical" show_line="1" text="Scroll down" text_orient="down" valign="bottom"]
```

**Anti-patterns**

- Using multiple consecutive `us_separator` blocks to "tune" spacing — set one `size="custom" height="..."` instead.
- Heavy decorative lines between every section — kills visual hierarchy. Use sparingly.
- Setting `size`/`height`/`align` on a `layout="vertical"` separator — they're ignored there (show_if gates them to horizontal); use the container's height and `valign`/`text_orient` instead.
