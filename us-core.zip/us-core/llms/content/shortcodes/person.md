---
title: `us_person` — Team Member Card
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/person.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/person.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=person
  Direct edits here will be lost on the next regeneration.
-->

# `us_person` — Team Member Card

**When to use**: a profile card on Team / About / Authors pages — portrait, name, role, short bio, optional social links.

**Avoid when**:
- you want a testimonial (different layout) — consider a styled `us_iconbox` or custom layout;
- you only need a name + photo as plain text — `us_text` + `us_image`.

**Key parameters**

**Content**

| Param | What it does |
|-------|--------------|
| `image` | Portrait media ID. Supports dynamic values (`{{the_thumbnail}}`, `{{us_tile_additional_image}}`, an ACF image field). |
| `image_hover` | Second media ID, cross-faded in on hover. Optional; same dynamic-value support as `image`. |
| `name` | Person name. Default `John Doe`. |
| `name_tag` | Name HTML tag — `h4` (default), `h1`–`h6`, `div`, `span`, `p`. |
| `name_size` | Custom CSS font-size for the name (e.g. `1.4rem`). |
| `role` | Job title or role. Default `UpSolution Team`. |
| `content` | Short bio — this is the "Description" field. Multi-line, supports dynamic values. **Not** `description`. |

**Layout / appearance**

| Param | What it does |
|-------|--------------|
| `layout` | `circle` (default — compact, rounded photo) / `square` (compact) / `simple` / `simple_circle` / `modern` / `trendy` / `cards`. |
| `effect` | Photo effect — `none` (default), `sepia`, `bw`, `faded`, `colored`. |
| `img_size` | WP image size preset — `large` (default), `thumbnail`, `medium`, `full`, or any registered custom size. |
| `link` | Wraps the name and the photo in a link. URL-encoded JSON (see composition-rules §3.1); the dynamic enum adds `homepage` and `popup_image`. |

**Social links** — each is its own attribute, **not** a group/`items` array. An empty one is skipped.

| Param | What it does |
|-------|--------------|
| `email` | Email address; rendered as `mailto:` when it is a valid address. |
| `facebook` / `twitter` / `google_plus` / `linkedin` | Full profile URLs. Opened in a new tab with `rel="nofollow"`. `twitter` is labelled "X (Twitter)" in the UI; `google_plus` renders the Google icon. |
| `custom_link` | One extra link of your own. URL-encoded JSON, same shape as `link`. |
| `custom_icon` | Icon for `custom_link` — `set|name`, default `fas|star`. Visible when `custom_link` is set. |

**Minimal example**

```text
[us_person image="123" name="Jane Doe" role="Lead Designer" content="Builds the UI you actually want to use."]
```

**Common combinations**

Card layout with a hover portrait and two socials:

```text
[us_person image="123" image_hover="124" name="Jane Doe" role="Lead Designer" layout="cards" effect="bw" linkedin="https://linkedin.com/in/janedoe" email="jane@example.com"]
```

A row of three team cards — one `vc_column width="1/3"` per person (see composition-rules §2).

**Anti-patterns**

- Writing `description="…"`, `style="…"` or a `socials="[…]"` array — none of those params exist. The bio is `content`, the visual style is `layout`, and every social network is a separate attribute.
- Inconsistent photo crops across cards in the same row — pre-crop to a single ratio in the media library, or pin `img_size` and an `aspect-ratio` via `css=`.
- Listing all of someone's titles — pick the most relevant one for this page.
