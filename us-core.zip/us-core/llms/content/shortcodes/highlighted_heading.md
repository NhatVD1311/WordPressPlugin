---
title: `us_highlighted_heading` — Highlighted Heading
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/highlighted_heading.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/highlighted_heading.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=highlighted_heading
  Direct edits here will be lost on the next regeneration.
-->

# `us_highlighted_heading` — Highlighted Heading

**When to use**: a heading where individual words carry their own accent — a gradient text fill, a highlighter-style background swash, a different font/weight, or italics — while the rest of the line stays in the theme's heading style. Ideal for hero headlines and section titles where one or two words should pop ("Create Your **Modern** Website").

**Avoid when**:
- the whole heading shares one style — use a plain `[us_text]` with a heading `tag`, it's far simpler;
- you need a word/phrase that *cycles* through alternatives (animated swap) — that's `[us_itext]`, not this;
- you're writing body copy — this is a single-line heading element, not a paragraph.

**Structure**: the heading text lives entirely in the `items` group — one entry per word or word-group, in reading order. Each entry is styled independently. There is **no** plain `text` attribute on the element itself; an element with an empty `items` renders nothing on the front end.

**Key parameters**

| Param | What it does |
|-------|--------------|
| `items` (group) | The words that make up the heading, in order. URL-encoded JSON array in double quotes (composition-rules §3.5). Per-item keys below. |
| `tag` | Wrapping HTML tag — `h1` (default), `h2`–`h6`, `div`, `p`, `span`. Pick by document outline, not by size. |

**Per-item keys** (each object inside `items`):

| Key | What it does |
|-----|--------------|
| `text` | The word(s) for this segment. Supports dynamic values and a small inline-tag allowlist (`<br> <i> <strong> <sub> <sup>`); everything else is stripped. Empty-text items are skipped. |
| `text_color` | Text fill. Empty = inherit the heading color. A preset gradient key, or `custom`. Presets — theme-based: `primary_secondary`, `current_primary`, `current_secondary`, `current_faded`; fixed: `pastel`, `ocean`, `azure`, `iris`, `nebula`, `prism`, `synthwave`, `red_burst`, `flame`, `tropical`, `lemonade`, `mint`, `deep_sea`, `silver`, `gold`. |
| `custom_text_color` | Used only when `text_color="custom"`. A solid color (palette token like `_content_primary`, or HEX/RGBA) or a custom CSS gradient. |
| `animate_text` | `1` slowly animates the text gradient. Only meaningful when `text_color` is set (a gradient). |
| `bg_color` | Highlighter-style background behind the word. Empty = none. Same preset keys / `custom` as `text_color`. |
| `custom_bg_color` | Used only when `bg_color="custom"`. Solid color or gradient, same format as `custom_text_color`. Default `_content_bg_alt`. |
| `animate_bg` | `1` animates the background gradient. Only when `bg_color` is set. |
| `bg_start_indent` / `bg_end_indent` | How far the background swash extends past the word on the left / right, in `em` (0–0.5, default `0.2em`). Only when `bg_color` is set. |
| `font_weight` | Numeric weight (e.g. `700`) or keyword for this segment only. |
| `font_family` | Font for this segment — a typography tag (`body`, `h1`…) mapping to the theme font var, or a specific font name. Empty = inherit. |
| `italic` | `italic` renders the segment in italics; empty = upright. |

Effects, Display Logic and Design parameter groups apply to the element as a whole (auto-linked below).

**Minimal example**

Three segments; the middle word gets the animated "Prism" gradient text fill:

```text
[us_highlighted_heading tag="h1" items="%5B%7B%22text%22%3A%22Create%20Your%22%7D%2C%7B%22text%22%3A%22Modern%22%2C%22text_color%22%3A%22prism%22%2C%22animate_text%22%3A%221%22%7D%2C%7B%22text%22%3A%22Website%22%7D%5D"]
```

Decoded `items` value (author it as JSON, then URL-encode before putting it in the attribute):

```text
[{"text":"Create Your"},{"text":"Modern","text_color":"prism","animate_text":"1"},{"text":"Website"}]
```

**Common combinations**

- **Highlighter swash** — accent a word with a background instead of a text gradient: give that item `"bg_color":"custom","custom_bg_color":"_content_primary"` (or a preset key). Tune `bg_start_indent` / `bg_end_indent` so the swash hugs the word.
- **Brand-tinted keyword** — `"text_color":"custom","custom_text_color":"_content_link"` keeps the accent on-palette across color schemes; prefer the theme-based presets (`primary_secondary`, `current_primary`) when you want it to adapt automatically.
- **Mixed typography** — set `italic` and/or a heavier `font_weight` on one segment for a stylistic contrast without changing color.

**Anti-patterns**

- Accenting every word — the emphasis lands nowhere. Keep one, maybe two highlighted segments per heading.
- Reaching for a full-line static heading — use `[us_text]`; this element exists for the per-word styling.
- Putting the whole sentence in a single `items` entry — you lose the point of the element; split it so only the accent word carries `text_color` / `bg_color`.
- Hand-writing the `items` JSON without URL-encoding — single-quoted raw JSON gets mangled and the element falls back to defaults. Encode it, keep it in double quotes.
- Literal HEX for accents that must survive a color-scheme switch — use palette tokens or the theme-based gradient presets instead.
