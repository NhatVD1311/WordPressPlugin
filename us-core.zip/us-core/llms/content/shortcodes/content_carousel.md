---
title: `us_content_carousel` — Content Carousel
audience: content
source: us-core 9.5
generated: 2026-10-20 by scripts/llms/build.php (body from scripts/llms/manual/shortcodes/content_carousel.md)
---

<!--
  GENERATED FILE — do not edit directly.
  Body comes from scripts/llms/manual/shortcodes/content_carousel.md
  Rebuild:  php scripts/llms/build.php --wp-load=… --only=content-shortcodes --only-shortcode=content_carousel
  Direct edits here will be lost on the next regeneration.
-->

# `us_content_carousel` — Content Carousel

**When to use**: a horizontally-rotating slider of arbitrary children (icon boxes, person cards, CTA blocks, testimonial cards…). Anything you can put inside a `vc_column` you can put inside one slide here.

**Avoid when**:
- the children are all images — `[us_image_slider]` is purpose-built for that (smaller markup, fullscreen view, thumb nav);
- the children are post entries — `[us_post_list]` / `[us_post_carousel]` know how to query them;
- you only need a static row — `[us_hwrapper]` or two `vc_column`s avoid the JS init cost.

**Children**: any leaf element. **Not allowed as children** (the container blocks them): `vc_column`, other carousels (`us_carousel`, `us_content_carousel`, `us_post_carousel`…), `vc_tta_*` tabs/accordions, `us_gmaps`, `us_cform`, `us_dropdown`, `us_search`, `us_login`, `us_page_block`, `us_separator`, `us_gallery`, `us_image_slider`. Each direct child becomes one slide.

**Key parameters**

**Slides**

| Param | What it does |
|-------|--------------|
| `items` | Slides visible at once — `auto`, or `1`…`10`. Default `3`. A plain count, not a JSON: per-breakpoint overrides live in `responsive`. |
| `items_gap` | Gap between slides, **px only** (default `30px`). Unlike other carousels this one has no rem/em option. |
| `next_item_offset` | How much of the next slide peeks in, px (default `0px`). |
| `items_valign` | `stretch` (default), `top`, `middle`, `bottom`. |
| `center_item` | `1` keeps the current slide centred. Needs a known count — ignored when `items="auto"` or `items="1"`. |
| `slide_by_one` | `1` (default) advances one slide at a time instead of a whole page. |
| `reverse_direction` | `1` runs the carousel the other way — the first item sits on the right, the slides move left to right. Applies to every screen width. |
| `autoheight` | `1` lets the carousel height follow the current slide. Only when `items="1"`. |

**Rotation**

| Param | What it does |
|-------|--------------|
| `loop` | `1` wraps around at the ends. Default `0` — stops at first/last. |
| `autoplay` | `1` enables auto-rotation. The three below only apply when it is on. |
| `autoplay_timeout` | Interval between advances, in seconds (default `3s`). |
| `autoplay_pause_on_hover` | `1` pauses while the cursor is over the carousel. |
| `autoplay_continual` | `1` scrolls continuously (marquee-style) instead of slide-by-slide. |
| `transition_speed` | Slide transition duration in ms (default `350ms`). |
| `transition_animation` | `none` (default — slide) or `fade`. Fade is single-slide only: with `items` ≠ `1` it silently falls back to sliding. |

**Arrows / dots**

| Param | What it does |
|-------|--------------|
| `arrows` | `1` (default) shows prev/next arrows. |
| `arrows_style` | `circle` (default), `square`, `1`, `2`. |
| `arrows_size` | Arrow size — `1.5rem` (default), any px/rem/em value. |
| `arrows_ver_pos` | `middle` (default), `stretch`, `top_outside`, `top_inside`, `bottom_outside`, `bottom_inside`. |
| `arrows_hor_pos` | `on_sides_outside` (default), `on_sides_inside`, `left_inside`, `center`, `right_inside`. |
| `arrows_ver_offset` / `arrows_hor_offset` | Nudge the arrows from that position (px/rem/em/%). |
| `arrows_gap` | Space between the two arrows when they sit together (`left_inside` / `center` / `right_inside`). |
| `arrows_disabled` | What a dead arrow looks like at the end of a non-looping carousel — `hide` (default) or `fade`. |
| `dots` | `1` shows pagination dots under the slides. |
| `dots_style` | `circle` (default), `diamond`, `dash`, `smudge`. |

**Drag**

| Param | What it does |
|-------|--------------|
| `mouse_drag` | `1` (default) lets visitors drag-swipe with the mouse. |
| `touch_drag` | `1` (default) enables touch swipe. |

**Responsive**

| Param | What it does |
|-------|--------------|
| `responsive` | JSON array of breakpoint overrides — each entry `{ "breakpoint": "laptops"\|"tablets"\|"mobiles"\|"custom", "breakpoint_width": "1024px", "items": "1", "center_item": 0, "autoheight": 0, "loop": 0, "autoplay": 0, "arrows": 0, "dots": 0 }`. Settings apply below the chosen width. URL-encoded in DOUBLE quotes — single-quoted raw JSON is mangled by `wptexturize`, see composition-rules §3.5. |

**Legacy** — `arrows_pos`, `arrows_offset` and `items_offset` were replaced by the `arrows_*_pos` / `arrows_*_offset` / `next_item_offset` controls above. Still parsed for old content; do not write them.

**Minimal example**

```text
[us_content_carousel items="3" arrows="1" dots="1"]
  [us_iconbox icon="fas|star" title="Fast" content="Loads in under 1s."]
  [us_iconbox icon="fas|shield" title="Secure" content="End-to-end encryption."]
  [us_iconbox icon="fas|bolt" title="Scalable" content="From 1 to 1M users."]
[/us_content_carousel]
```

**Common combinations**

Testimonials rotation, one card at a time, auto-advance every 6s, single-up on tablets and phones:

```text
[us_content_carousel items="1" autoplay="1" autoplay_timeout="6s" loop="1" arrows="1" dots="1" responsive="%5B%7B%22breakpoint%22%3A%22tablets%22%2C%22items%22%3A%221%22%7D%2C%7B%22breakpoint%22%3A%22mobiles%22%2C%22items%22%3A%221%22%2C%22arrows%22%3A%220%22%7D%5D"]
  [us_person name="Anna Lee" role="CTO, Acme" content="..." image="123"]
  [us_person name="Mark Yu" role="Lead, Beta" content="..." image="124"]
[/us_content_carousel]
```

**Anti-patterns**

- Writing `items_quantity` / `auto_play` / `timeout` / `touch_swipe` — none of those exist. The names are `items`, `autoplay`, `autoplay_timeout`, `touch_drag`.
- Putting a per-breakpoint JSON in `items` — `items` is a plain count; breakpoints go in `responsive`.
- Wrapping a single child — there's nothing to carousel; use the child directly.
- Putting `vc_column` inside (the container's `except` list blocks it — the markup will render but the column won't behave as a slide).
- `items_gap` written as `1rem` — only `px` is accepted here.
- Leaving `items="4"` with no `responsive` entry — four slides are unreadable on a phone.
