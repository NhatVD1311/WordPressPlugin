<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * TEXT settings of Design options
 *
 * Used both by Design options of every element and by Theme Options > Typography > Text Styles,
 * so that a style always contains exactly the same set of settings as an element has.
 *
 * DEV: property keys MUST be written with a hyphen, as they are compiled into css as is.
 */

$misc = us_config( 'elements_misc' );

return array(
	'color' => array(
		'title' => us_translate( 'Color' ),
		'type' => 'color',
		'clear_pos' => 'right',
		'with_gradient' => FALSE,
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	// Note: When using responsive design, the default value will be `inherit`
	// for the possibility of canceling other values.
	'text-align' => array(
		'title' => us_translate( 'Alignment' ),
		'type' => 'radio',
		'labels_as_icons' => 'fas fa-align-*',
		'options' => array(
			'inherit' => us_translate( 'Default' ),
			'left' => us_translate( 'Left' ),
			'center' => us_translate( 'Center' ),
			'right' => us_translate( 'Right' ),
			'justify' => us_translate( 'Justify' ),
		),
		'std' => 'inherit',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'font-size' => array(
		'title' => __( 'Font Size', 'us' ),
		'description' => $misc['desc_font_size'],
		'type' => 'text',
		'std' => '',
		'group' => us_translate( 'Text' ),
	),
	'line-height' => array(
		'title' => __( 'Line height', 'us' ),
		'description' => $misc['desc_line_height'],
		'type' => 'text',
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'letter-spacing' => array(
		'title' => __( 'Letter Spacing', 'us' ),
		'description' => $misc['desc_letter_spacing'],
		'type' => 'text',
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'font-family' => array(
		'title' => __( 'Font', 'us' ),
		'type' => 'select',
		// The list of fonts is only needed where the params are edited
		'options' => ( us_is_elm_editing_page() OR us_is_theme_options_page() )
			? us_get_fonts_for_selection()
			: array(),
		'std' => '',
		'group' => us_translate( 'Text' ),
	),
	'font-weight' => array(
		'title' => __( 'Font Weight', 'us' ),
		'description' => $misc['desc_font_weight'],
		'type' => 'text',
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'text-transform' => array(
		'title' => __( 'Text Transform', 'us' ),
		'type' => 'select',
		'options' => array(
			'' => '– ' . us_translate( 'Default' ) . ' –',
			'none' => us_translate( 'None' ),
			'uppercase' => 'UPPERCASE',
			'lowercase' => 'lowercase',
			'capitalize' => 'Capitalize',
		),
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'text-wrap' => array(
		'title' => __( 'Text Wrap', 'us' ),
		'type' => 'select',
		'options' => array(
			'' => '– ' . us_translate( 'Default' ) . ' –',
			'balance' => 'Balance',
		),
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
	'font-style' => array(
		'title' => __( 'Font Style', 'us' ),
		'type' => 'select',
		'options' => array(
			'' => '– ' . us_translate( 'Default' ) . ' –',
			'normal' => __( 'normal', 'us' ),
			'italic' => __( 'italic', 'us' ),
		),
		'std' => '',
		'cols' => 2,
		'group' => us_translate( 'Text' ),
	),
);
