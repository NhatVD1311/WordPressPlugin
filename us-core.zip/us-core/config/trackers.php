<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Patterns of the known tracking code, which is loaded only after the visitor's consent, see us_block_trackers()
 *
 * Note: every pattern is a part of a regular expression matched against the attributes and the content of a <script>
 * or <noscript> tag, case-insensitively. The "us_config_trackers" filter allows to add the trackers of a particular site
 *
 * Note: the patterns match the code, which loads a tracker, not the calls of a tracker like gtag() or fbq(), as a script
 * with such a call may hold other code of the site, which would never run without the consent. A script with the calls
 * only can be marked with the data-us-consent attribute
 */

return array(

	// Google Analytics, Google Tag Manager, Google Ads
	'google-analytics\.com',
	'googletagmanager\.com',
	'googleadservices\.com',
	'GoogleAnalyticsObject',

	// Meta Pixel
	'connect\.facebook\.net',

	// Microsoft Clarity, Microsoft Ads
	'clarity\.ms',
	'bat\.bing\.com',

	// Hotjar
	'hotjar\.com',

	// Yandex Metrica
	'mc\.yandex\.ru',

	// Matomo, Piwik
	'matomo\.js',
	'piwik\.js',

	// LinkedIn Insight Tag, X Pixel, TikTok Pixel, Pinterest Tag
	'snap\.licdn\.com',
	'static\.ads-twitter\.com',
	'analytics\.tiktok\.com',
	'pinimg\.com/ct',

	// HubSpot tracking code
	'js\.hs-scripts\.com',
);
