<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Predefined gradient presets for the "Highlighted Heading" element.
 *
 * Each preset: 'key' => array( 'title' => visible name, 'gradient' => CSS value ).
 * The same config is read both in the element config (to build the select options)
 * and in the template (to resolve a chosen preset to its CSS value).
 *
 * NOTE: keys must be unique — duplicate array keys silently overwrite each other.
 *
 * @filter us_config_highlighted-heading-gradients
 */

return array(

	// Theme-color based (adapt to the active color scheme / current text color)
	'primary_secondary' => array(
		'title' => sprintf( '%s → %s', __( 'Primary Color', 'us' ), __( 'Secondary Color', 'us' ) ),
		'gradient' => 'linear-gradient(45deg, var(--color-content-primary), var(--color-content-secondary))',
	),
	'current_primary' => array(
		'title' => sprintf( '%s → %s', __( 'Current Color', 'us' ), __( 'Primary Color', 'us' ) ),
		'gradient' => 'linear-gradient(90deg, currentColor, var(--color-content-primary))',
	),
	'current_secondary' => array(
		'title' => sprintf( '%s → %s', __( 'Current Color', 'us' ), __( 'Secondary Color', 'us' ) ),
		'gradient' => 'linear-gradient(90deg, currentColor, var(--color-content-secondary))',
	),
	'current_faded' => array(
		'title' => sprintf( '%s → %s', __( 'Current Color', 'us' ), __( 'Faded Text', 'us' ) ),
		'gradient' => 'linear-gradient(90deg, currentColor, var(--color-content-faded))',
	),

	// Fixed-color presets
	'pastel' => array(
		'title' => 'Pastel',
		'gradient' => 'linear-gradient(90deg, #b7e9ff, #ffdbbd)',
	),
	'ocean' => array(
		'title' => 'Ocean',
		'gradient' => 'linear-gradient(70deg, #18719a 0%, #b9ebff 17%, #ade3f7 26%, #0c6694 50%, #80c5ea 66%, #abd9ff 71%, #0b496e 100%)',
	),
	'azure' => array(
		'title' => 'Azure',
		'gradient' => 'linear-gradient(325deg, #399adb 20%, #4feaff 44%, #42a7ff 56%, #21539e 100%)',
	),
	'iris' => array(
		'title' => 'Iris',
		'gradient' => 'linear-gradient(70deg, #53dbf2 0%, #ce9eec 30%, #3a7ff2 100%)',
	),
	'nebula' => array(
		'title' => 'Nebula',
		'gradient' => 'linear-gradient(90deg, #0e0725 0%, #5c03bc 25%, #e536ab 80%, #f4e5f0 100%)',
	),
	'prism' => array(
		'title' => 'Prism',
		'gradient' => 'linear-gradient(90deg, #0ab6f8 0%, #520eb0 33%, #ed4ee8 67%, #ffa81c 100%)',
	),
	'synthwave' => array(
		'title' => 'Synthwave',
		'gradient' => 'linear-gradient(90deg, #cb4fff, #ff7146, #ff0080)',
	),
	'red_burst' => array(
		'title' => 'Red Burst',
		'gradient' => 'linear-gradient(90deg, currentColor 0%, #E02B25 33%, #E02B25 66%, currentColor 100%)',
	),
	'flame' => array(
		'title' => 'Flame',
		'gradient' => 'linear-gradient(100deg, #f02913 0%, #ff9300 33%, #ffd138 80%, #ffffff 100%)',
	),
	'tropical' => array(
		'title' => 'Tropical',
		'gradient' => 'linear-gradient(100deg, #3bcfd4 0%, #fc9305 50%, #f20094 100%)',
	),
	'lemonade' => array(
		'title' => 'Lemonade',
		'gradient' => 'linear-gradient(100deg, #00c6ff, #fff600)',
	),
	'mint' => array(
		'title' => 'Mint',
		'gradient' => 'linear-gradient(45deg, #3bcfd4 0%, #32c852 25%, #0bb98c 50%, #2feaa8 100%)',
	),
	'deep_sea' => array(
		'title' => 'Deep Sea',
		'gradient' => 'linear-gradient(325deg, #051937 0%, #004d7a 25%, #008793 50%, #00bf72 70%, #005878 90%)',
	),
	'silver' => array(
		'title' => 'Silver',
		'gradient' => 'linear-gradient(70deg, #eee 0%, #ddd 25%, #bbb 75%, #ffffff 100%)',
	),
	'gold' => array(
		'title' => 'Gold',
		'gradient' => 'linear-gradient(70deg, #faf0a0 10%, #d3b15f 20%, #b17b32 40%, #e1b453 70%, #a4692a 85%, #faf0a0 100%)',
	),
);
