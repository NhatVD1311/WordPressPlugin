<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for shortcode: separator
 */

$misc = us_config( 'elements_misc' );
$conditional_params = us_config( 'elements_conditional_options' );
$design_options_params = us_config( 'elements_design_options' );
$effect_options_params = us_config( 'elements_effect_options' );
$hover_options_params = us_config( 'elements_hover_options' );

/**
 * @return array
 */
return array(
	'title' => __( 'Separator', 'us' ),
	'description' => __( 'Gap between elements', 'us' ),
	'category' => __( 'Basic', 'us' ),
	'icon' => 'fas fa-grip-lines',
	'params' => us_set_params_weight(

		// General section
		array(
			'layout' => array(
				'title' => us_translate( 'Layout' ),
				'type' => 'radio',
				'options' => array(
					'horizontal' => __( 'Horizontal', 'us' ),
					'vertical' => __( 'Vertical', 'us' ),
				),
				'std' => 'horizontal',
				'admin_label' => TRUE,
				'usb_preview' => TRUE,
			),
			'size' => array(
				'title' => us_translate( 'Height' ),
				'type' => 'radio',
				'options' => array(
					'small' => 'S',
					'medium' => 'M',
					'large' => 'L',
					'huge' => 'XL',
					'custom' => __( 'Custom', 'us' ),
				),
				'std' => 'medium',
				'admin_label' => TRUE,
				'show_if' => array( 'layout', '=', 'horizontal' ),
				'usb_preview' => array(
					'mod' => 'size',
				),
			),
			'height' => array(
				'description' => __( 'Examples:', 'us' ) . ' <span class="usof-example">30px</span>, <span class="usof-example">2rem</span>, <span class="usof-example">5vh</span>',
				'type' => 'text',
				'std' => '',
				'holder' => 'div',
				'classes' => 'for_above',
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'size', '=', 'custom' ),
				),
				'usb_preview' => array(
					'css' => 'height',
				),
			),
			'show_line' => array(
				'type' => 'switch',
				'switch_text' => __( 'Show line', 'us' ),
				'std' => 0,
				'usb_preview' => TRUE,
			),
			'line_width' => array(
				'title' => __( 'Line Width', 'us' ),
				'type' => 'select',
				'options' => array(
					'default' => '100%',
					'30' => '30%',
					'50' => '50%',
					'screen' => __( 'Full Width', 'us' ),
				),
				'std' => 'default',
				'cols' => 2,
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'show_line', '=', 1 ),
				),
				'usb_preview' => TRUE,
			),
			'style' => array(
				'title' => __( 'Line Style', 'us' ),
				'type' => 'select',
				'options' => array(
					'solid' => __( 'Solid', 'us' ),
					'dashed' => __( 'Dashed', 'us' ),
					'dotted' => __( 'Dotted', 'us' ),
					'double' => __( 'Double', 'us' ),
				),
				'std' => 'solid',
				'cols' => 2,
				'show_if' => array( 'show_line', '=', 1 ),
				'usb_preview' => array(
					'mod' => 'style',
				),
			),
			'thick' => array(
				'title' => __( 'Line Thickness', 'us' ),
				'type' => 'slider',
				'options' => array(
					'px' => array(
						'min' => 1,
						'max' => 5,
					),
				),
				'std' => '1px',
				'show_if' => array( 'show_line', '=', 1 ),
				'usb_preview' => array(
					'css' => '--line-thickness',
				),
			),
			'color' => array(
				'title' => __( 'Line Color', 'us' ),
				'type' => 'select',
				'options' => array(
					'border' => __( 'Border (theme color)', 'us' ),
					'text' => __( 'Text (theme color)', 'us' ),
					'primary' => __( 'Primary (theme color)', 'us' ),
					'secondary' => __( 'Secondary (theme color)', 'us' ),
					'custom' => __( 'Custom', 'us' ),
				),
				'std' => 'border',
				'show_if' => array( 'show_line', '=', 1 ),
				'usb_preview' => array(
					'mod' => 'color',
				),
			),
			'line_color' => array(
				'type' => 'color',
				'with_gradient' => FALSE,
				'std' => '_content_border',
				'classes' => 'for_above',
				'show_if' => array( 'color', '=', 'custom' ),
				'usb_preview' => array(
					'css' => '--line-color',
				),
			),
		),

		// Icon and Title
		array(
			'icon' => array(
				'title' => __( 'Icon', 'us' ),
				'type' => 'icon',
				'std' => '',
				'show_if' => array( 'show_line', '=', 1 ),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => TRUE,
			),
			'text' => array(
				'title' => us_translate( 'Title' ),
				'type' => 'text',
				'dynamic_values' => TRUE,
				'std' => '',
				'holder' => 'div',
				'show_if' => array( 'show_line', '=', 1 ),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => TRUE,
			),
			'link' => array(
				'title' => us_translate( 'Link' ),
				'type' => 'link',
				'dynamic_values' => TRUE,
				'std' => '{"url":""}',
				'show_if' => array( 'text', '!=', '' ),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => TRUE,
			),
			'title_tag' => array(
				'title' => __( 'Title HTML tag', 'us' ),
				'type' => 'select',
				'options' => $misc['html_tag_values'],
				'std' => 'h6',
				'show_if' => array( 'text', '!=', '' ),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => array(
					'attr' => 'tag',
					'elm' => '.w-separator-text',
				),
			),
			'align' => array(
				'title' => us_translate( 'Alignment' ),
				'type' => 'radio',
				'labels_as_icons' => 'fas fa-align-*',
				'options' => array(
					'none' => us_translate( 'Default' ),
					'left' => us_translate( 'Left' ),
					'center' => us_translate( 'Center' ),
					'right' => us_translate( 'Right' ),
				),
				'std' => 'center',
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'show_line', '=', 1 ),
				),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => array(
					'mod' => 'align',
				),
			),
			'text_orient' => array(
				'title' => __( 'Text Orientation', 'us' ),
				'type' => 'radio',
				'labels_as_icons' => 'fas fa-arrow-*',
				'options' => array(
					'down' => __( 'Top to bottom', 'us' ),
					'up' => __( 'Bottom to top', 'us' ),
				),
				'std' => 'down',
				'show_if' => array(
					array( 'layout', '=', 'vertical' ),
					'and',
					array( 'show_line', '=', 1 ),
				),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => array(
					'mod' => 'text_orient',
				),
			),
			'valign' => array(
				'title' => us_translate( 'Alignment' ),
				'type' => 'radio',
				'options' => array(
					'top' => us_translate( 'Top' ),
					'middle' => us_translate( 'Middle' ),
					'bottom' => us_translate( 'Bottom' ),
				),
				'std' => 'middle',
				'show_if' => array(
					array( 'layout', '=', 'vertical' ),
					'and',
					array( 'show_line', '=', 1 ),
				),
				'group' => __( 'Icon and Title', 'us' ),
				'usb_preview' => array(
					'mod' => 'valign',
				),
			),
		),

		// Responsive Options section
		array(
			'breakpoint_1_width' => array(
				'title' => __( 'Below screen width', 'us' ),
				'type' => 'slider',
				'options' => array(
					'px' => array(
						'min' => 600,
						'max' => 1200,
					),
				),
				'std' => '1025px',
				'cols' => 2,
				'group' => __( 'Responsive', 'us' ),
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'size', '=', 'custom' ),
				),
				'usb_preview' => TRUE,
			),
			'breakpoint_1_height' => array(
				'title' => us_translate( 'Height' ),
				'description' => __( 'Examples:', 'us' ) . ' <span class="usof-example">10px</span>, <span class="usof-example">1rem</span>, <span class="usof-example">3vh</span>',
				'type' => 'text',
				'std' => '',
				'cols' => 2,
				'group' => __( 'Responsive', 'us' ),
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'size', '=', 'custom' ),
				),
				'usb_preview' => TRUE,
			),
			'breakpoint_2_width' => array(
				'title' => __( 'Below screen width', 'us' ),
				'type' => 'slider',
				'options' => array(
					'px' => array(
						'min' => 300,
						'max' => 900,
					),
				),
				'std' => '601px',
				'cols' => 2,
				'group' => __( 'Responsive', 'us' ),
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'size', '=', 'custom' ),
				),
				'usb_preview' => TRUE,
			),
			'breakpoint_2_height' => array(
				'title' => us_translate( 'Height' ),
				'description' => __( 'Examples:', 'us' ) . ' <span class="usof-example">10px</span>, <span class="usof-example">1rem</span>, <span class="usof-example">3vh</span>',
				'type' => 'text',
				'std' => '',
				'cols' => 2,
				'group' => __( 'Responsive', 'us' ),
				'show_if' => array(
					array( 'layout', '=', 'horizontal' ),
					'and',
					array( 'size', '=', 'custom' ),
				),
				'usb_preview' => TRUE,
			),
		),

		$effect_options_params,
		$conditional_params,
		$design_options_params,
		$hover_options_params
	),
);
