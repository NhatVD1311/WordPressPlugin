<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for shortcode: breadcrumbs
 */

$misc = us_config( 'elements_misc' );
$conditional_params = us_config( 'elements_conditional_options' );
$design_options_params = us_config( 'elements_design_options' );

/**
 * @return array
 */
return array(
	'title' => __( 'Breadcrumbs', 'us' ),
	'icon' => 'fas fa-angle-double-right',
	'category' => __( 'Post Elements', 'us' ),
	'params' => us_set_params_weight(

		// General section
		array(
			'items' => array(
				'type' => 'group',
				'show_controls' => TRUE,
				'is_sortable' => TRUE,
				'is_accordion' => TRUE,
				// Show the source label, then the value of the field that source controls
				// (hidden / empty sub-fields are dropped by the accordion-title builder)
				'accordion_title' => 'source - label - page - taxonomy',
				'params' => array(
					'source' => array(
						'title' => __( 'Data Source', 'us' ),
						'type' => 'select',
						'options' => array(
							'custom' => us_translate( 'Custom Link' ),
							'page' => __( 'Manually selected page', 'us' ),
							'taxonomy' => us_translate( 'Taxonomy' ),
							'auto' => us_translate_x( 'Auto', 'auto preload' ),
						),
						'std' => 'auto',
						'admin_label' => TRUE,
					),
					'label' => array(
						'title' => us_translate( 'Label' ),
						'type' => 'text',
						'std' => '',
						'dynamic_values' => TRUE,
						'show_if' => array( 'source', '=', 'custom' ),
					),
					'link' => array(
						'title' => us_translate( 'Link' ),
						'type' => 'link',
						'std' => '{"url":""}',
						'dynamic_values' => TRUE,
						'show_if' => array( 'source', '=', 'custom' ),
					),
					'page' => array(
						'title' => us_translate( 'Page' ),
						'type' => 'select',
						'options' => us_is_elm_editing_page()
							? us_array_merge(
								array( '' => '&ndash; ' . us_translate( 'None' ) . ' &ndash;' ),
								us_get_posts_titles_for( 'page' )
							)
							: array(),
						'std' => '',
						'show_if' => array( 'source', '=', 'page' ),
					),
					'taxonomy' => array(
						'type' => 'select',
						'options' => us_is_elm_editing_page() ? us_get_taxonomies() : array(),
						'std' => 'category',
						'classes' => 'for_above',
						'show_if' => array( 'source', '=', 'taxonomy' ),
					),
				),
				'std' => array(
					array(
						'source' => 'custom',
						'label' => us_translate( 'Home' ),
						'link' => '{"url":"' . home_url( '/' ) . '"}',
					),
					array(
						'source' => 'auto',
					),
				),
				'usb_preview' => TRUE,
			),
			'show_current' => array(
				'type' => 'switch',
				'switch_text' => __( 'Show current page', 'us' ),
				'std' => 0,
				'usb_preview' => TRUE,
			),
			'link_current' => array(
				'type' => 'switch',
				'switch_text' => __( 'Add link to current page', 'us' ),
				'std' => 0,
				'show_if' => array( 'show_current', '=', 1 ),
				'usb_preview' => TRUE,
			),
			'show_page_number' => array(
				'type' => 'switch',
				'switch_text' => __( 'Show pagination number', 'us' ),
				'std' => 1,
				'show_if' => array( 'show_current', '=', 1 ),
			),
			'separator_type' => array(
				'title' => __( 'Separator between items', 'us' ),
				'type' => 'radio',
				'options' => array(
					'icon' => __( 'Icon', 'us' ),
					'custom' => __( 'Custom', 'us' ),
				),
				'std' => 'icon',
				'usb_preview' => TRUE,
			),
			'separator_icon' => array(
				'type' => 'icon',
				'std' => 'far|angle-right',
				'classes' => 'for_above',
				'show_if' => array( 'separator_type', '=', 'icon' ),
				'usb_preview' => TRUE,
			),
			'separator_symbol' => array(
				'type' => 'text',
				'std' => '/',
				'classes' => 'for_above',
				'show_if' => array( 'separator_type', '=', 'custom' ),
				'usb_preview' => array(
					'attr' => 'html',
					'elm' => '.g-breadcrumbs-separator',
				),
			),
		),

		$conditional_params,
		$design_options_params
	),
	'fallback_params' => array(
		'home',
		'align',
	),
);
