<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for shortcode: gmaps
 */

$misc = us_config( 'elements_misc' );
$conditional_params = us_config( 'elements_conditional_options' );
$design_options_params = us_config( 'elements_design_options' );

$post_type_options = $coords_field_options = array();

if ( us_is_elm_editing_page() ) {
	$post_type_options = us_get_loop_post_types( TRUE );
	unset( $post_type_options['attachment'] );

	// ACF fields that can keep coordinates
	if ( function_exists( 'us_acf_get_fields' ) ) {
		$coords_field_options = us_acf_get_fields( array( 'google_map', 'text' ), /* to_list */ TRUE, /* include_options_page */ FALSE );
	}
}

/**
 * @return array
 */
return array(
	'title' => __( 'Map', 'us' ),
	'icon' => 'fas fa-map-marked-alt',
	'params' => us_set_params_weight(

		// General section
		array(
			'marker_source' => array(
				'title' => __( 'Marker Source', 'us' ),
				'type' => 'select',
				'options' => array(
					'addresses' => __( 'Custom Addresses', 'us' ),
					'posts' => us_translate( 'All Posts' ),
					'current_wp_query' => __( 'Posts of the current query (archives and search results)', 'us' ),
				),
				'std' => 'addresses',
				'admin_label' => TRUE,
				'usb_preview' => TRUE,
			),
			'coords_field' => array(
				'title' => __( 'Coordinates Field', 'us' ),
				'description' => sprintf( __( 'ACF field of the "%s" or "%s" type. The text field should contain geo coordinates.', 'us' ), 'Google Map', 'Text' ),
				'type' => 'select',
				'options' => array( '' => '– ' . us_translate( 'None' ) . ' –' ) + $coords_field_options,
				'std' => '',
				'show_if' => array( 'marker_source', '!=', 'addresses' ),
				'usb_preview' => TRUE,
			),
			'post_type' => array(
				'title' => __( 'Post Type', 'us' ),
				'type' => 'checkboxes',
				'options' => $post_type_options,
				'std' => 'post',
				'show_if' => array( 'marker_source', '=', 'posts' ),
				'usb_preview' => TRUE,
			),
			'apply_url_params' => array(
				'type' => 'switch',
				'switch_text' => __( 'Use URL params to show results', 'us' ),
				'std' => 0,
				'show_if' => array( 'marker_source', '=', 'posts' ),
			),

			'marker_address' => array(
				'title' => __( 'Address', 'us' ),
				'description' => __( 'Specify address in accordance with the format used by the national postal service of the country concerned.', 'us' ) . ' ' . __( 'Or use geo coordinates, for example:', 'us' ) . ' <span class="usof-example">41.8900, 12.4922</span>',
				'type' => 'text',
				'std' => '48.858276, 2.294591',
				'dynamic_values' => array(
					'global' => array(),
					'post' => array(),
					'term' => array(),
					'acf_types' => array( 'text', 'google_map' ),
				),
				'admin_label' => TRUE,
				'show_if' => array( 'marker_source', '=', 'addresses' ),
				'usb_preview' => TRUE,
			),
			'marker_text' => array(
				'title' => __( 'Marker Text', 'us' ),
				'description' => __( 'HTML tags are allowed.', 'us' ) . ' ' . sprintf( __( 'Use %s to show the address value.', 'us' ), '<span class="usof-example">{{address}}</span>' ),
				'type' => 'html',
				'encoded' => TRUE,
				'std' => base64_encode( '<h6>Hey, we are here!</h6><p>We will be glad to see you in our office.</p>' ),
				'classes' => 'vc_col-sm-12 pretend_textfield', // appearance fix in WPBakery editing window
				'dynamic_values' => TRUE,
				'show_if' => array( 'marker_source', '=', 'addresses' ),
				'usb_preview' => TRUE,
			),
			'show_infowindow' => array(
				'type' => 'switch',
				'switch_text' => __( 'Show Marker Text when map is loaded', 'us' ),
				'std' => 0,
				'show_if' => array(
					array( 'marker_source', '=', 'addresses' ),
					'and',
					array( 'marker_text', '!=', '' ),
				),
				'usb_preview' => TRUE,
			),

			// Click on markers of posts
			'marker_click' => array(
				'title' => __( 'Marker Click', 'us' ),
				'type' => 'select',
				'options' => array(
					'none' => '– ' . us_translate( 'None' ) . ' –',
					'post_link' => __( 'Open Post in a New Tab', 'us' ),
					'grid_layout' => __( 'Show Marker Popup', 'us' ),
				),
				'std' => 'grid_layout',
				'show_if' => array( 'marker_source', '!=', 'addresses' ),
				'usb_preview' => TRUE,
			),

			// The popup by the Grid Layout, the same setting as Post List has, so the layout is detected
			// in the "Used in" column and by the assets optimization by the items_layout="ID" string.
			// Custom Grid Layouts and the templates of the map only, other templates don't suit marker popups
			'items_layout' => array(
				'title' => __( 'Marker Popup Layout', 'us' ),
				'description' => $misc['desc_grid_layout'],
				'type' => 'select',
				'options' => us_is_elm_editing_page() ? us_get_grid_layouts_for_selection( array( 'map_' ) ) : array(),
				'std' => 'map_marker_1',
				'classes' => 'for_grid_layouts',
				'settings' => array(
					'html-data' => array(
						'edit_link' => admin_url( '/post.php?post=%d&action=edit' ),
					),
				),
				'show_if' => array(
					array( 'marker_source', '!=', 'addresses' ),
					'and',
					array( 'marker_click', '=', 'grid_layout' ),
				),
				'usb_preview' => TRUE,
			),
			'infowindow_width' => array(
				'title' => __( 'Marker Popup Width', 'us' ),
				'description' => __( 'Examples:', 'us' ) . ' <span class="usof-example">300px</span>, <span class="usof-example">20rem</span>, <span class="usof-example">min(400px, 80vw)</span>',
				'type' => 'text',
				'std' => '300px',
				'show_if' => array(
					array( 'marker_source', '!=', 'addresses' ),
					'and',
					array( 'marker_click', '=', 'grid_layout' ),
				),
				'usb_preview' => TRUE,
			),

			// Additional Markers
			'markers' => array(
				'type' => 'group',
				'show_controls' => TRUE,
				'is_sortable' => TRUE,
				'is_accordion' => TRUE,
				'accordion_title' => 'marker_address',
				'params' => array(
					'marker_address' => array(
						'title' => __( 'Address', 'us' ),
						'description' => __( 'Specify address in accordance with the format used by the national postal service of the country concerned.', 'us' ) . ' ' . __( 'Or use geo coordinates, for example:', 'us' ) . ' <span class="usof-example">41.8900, 12.4922</span>',
						'type' => 'text',
						'std' => '',
						'dynamic_values' => array(
							'global' => array(),
							'post' => array(),
							'term' => array(),
							'acf_types' => array( 'text', 'google_map' ),
						),
						'admin_label' => TRUE,
					),
					'marker_text' => array(
						'title' => __( 'Marker Text', 'us' ),
						'description' => __( 'HTML tags are allowed.', 'us' ) . ' ' . sprintf( __( 'Use %s to show the address value.', 'us' ), '<span class="usof-example">{{address}}</span>' ),
						'type' => 'textarea',
						'std' => '',
						'classes' => 'vc_col-sm-12 pretend_textfield', // appearance fix in shortcode editing window
					),
					'marker_img' => array(
						'title' => __( 'Custom Marker Image', 'us' ),
						'type' => 'upload',
						'cols' => 2,
						'extension' => 'png,jpg,jpeg,gif,svg',
					),
					'marker_size' => array(
						'title' => __( 'Marker Image Size', 'us' ),
						'type' => 'slider',
						'options' => array(
							'px' => array(
								'min' => 20,
								'max' => 60,
								'step' => 2,
							),
						),
						'std' => '30px',
						'show_if' => array( 'marker_img', '!=', '' ),
						'cols' => 2,
					),
				),
				'std' => array(),
				'show_if' => array( 'marker_source', '=', 'addresses' ),
				'group' => __( 'Additional Markers', 'us' ),
				'usb_preview' => TRUE,
			),
		),

		// Appearance
		array(
			'marker_style' => array(
				'title' => __( 'Marker Style', 'us' ),
				'type' => 'select',
				'options' => array(
					'default' => us_translate( 'Default' ),
					'pin' => __( 'Pin', 'us' ),
					'dot' => __( 'Dot', 'us' ),
					'ring' => __( 'Ring', 'us' ),
					'label' => __( 'Custom Text', 'us' ),
					'image' => __( 'Custom Image', 'us' ),
				),
				'std' => 'pin',
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'marker_label' => array(
				'type' => 'text',
				'std' => '{{the_title}}',
				'classes' => 'for_above',
				'dynamic_values' => TRUE,
				'show_if' => array( 'marker_style', '=', 'label' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'marker_color' => array(
				'title' => __( 'Marker Color', 'us' ),
				'type' => 'color',
				'with_gradient' => FALSE,
				'std' => '_content_primary',
				'show_if' => array( 'marker_style', '=', array( 'pin', 'dot', 'ring', 'label' ) ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			// The old 'custom_marker_img' param is replaced by this one, @see us_fallback_atts_us_gmaps()
			'marker_image' => array(
				'type' => 'upload',
				'classes' => 'for_above',
				'extension' => 'png,jpg,jpeg,gif,svg',
				'show_if' => array( 'marker_style', '=', 'image' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'custom_marker_size' => array(
				'title' => __( 'Marker Size', 'us' ),
				'type' => 'slider',
				'options' => array(
					'px' => array(
						'min' => 20,
						'max' => 60,
						'step' => 2,
					),
				),
				'std' => '30px',
				'show_if' => array( 'marker_style', '!=', 'default' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			// Markers of posts are visited by the click, which opens the popup or the post
			'fade_visited_markers' => array(
				'type' => 'switch',
				'switch_text' => __( 'Fade visited markers', 'us' ),
				'description' => __( 'A marker becomes visited after it is clicked, until the page is reloaded.', 'us' ),
				'std' => 0,
				// OpenStreetMap fades markers of any style by the CSS filter, while Google Maps draws markers
				// of built-in styles only with the faded colors, its default marker and the custom image stay as is
				'show_if' => array(
					array( 'marker_source', '!=', 'addresses' ),
					'and',
					array( 'marker_click', '!=', 'none' ),
					'and',
					array(
						array( 'provider', '=', 'osm' ),
						'or',
						array( 'marker_style', '=', array( 'pin', 'dot', 'ring', 'label' ) ),
					),
				),
				'group' => us_translate( 'Appearance' ),
			),
			'visited_marker_contrast' => array(
				'title' => __( 'Visited Marker Contrast', 'us' ),
				'type' => 'slider',
				'options' => array(
					'%' => array(
						'min' => 30,
						'max' => 90,
						'step' => 5,
					),
				),
				'std' => '50%',
				'show_if' => array(
					array( 'fade_visited_markers', '=', 1 ),
					'and',
					array( 'marker_source', '!=', 'addresses' ),
					'and',
					array( 'marker_click', '!=', 'none' ),
					'and',
					array(
						array( 'provider', '=', 'osm' ),
						'or',
						array( 'marker_style', '=', array( 'pin', 'dot', 'ring', 'label' ) ),
					),
				),
				'group' => us_translate( 'Appearance' ),
			),
			'cluster_markers' => array(
				'type' => 'switch',
				'switch_text' => __( 'Group markers into clusters', 'us' ),
				'std' => 0,
				'show_if' => array( 'marker_source', '!=', 'addresses' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'cluster_color' => array(
				'title' => __( 'Cluster Color', 'us' ),
				'type' => 'color',
				'with_gradient' => FALSE,
				'std' => '_content_secondary',
				'show_if' => array( 'cluster_markers', '=', 1 ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'provider' => array(
				'title' => __( 'Map Provider', 'us' ),
				'type' => 'radio',
				'options' => array(
					'google' => __( 'Google Maps', 'us' ),
					'osm' => 'OpenStreetMap',
				),
				'std' => 'google',
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'type' => array(
				'title' => __( 'Map Type', 'us' ),
				'type' => 'select',
				'options' => array(
					'roadmap' => __( 'Roadmap', 'us' ),
					'terrain' => __( 'Roadmap + Terrain', 'us' ),
					'satellite' => __( 'Satellite', 'us' ),
					'hybrid' => __( 'Satellite + Roadmap', 'us' ),
				),
				'std' => 'roadmap',
				'show_if' => array( 'provider', '=', 'google' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'zoom' => array(
				'title' => __( 'Map Zoom', 'us' ),
				'description' => __( 'For markers of posts, it is the maximum zoom when the map fits all markers.', 'us' ),
				'type' => 'slider',
				'options' => array(
					'' => array(
						'min' => 1,
						'max' => 20,
					),
				),
				'std' => '14',
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'hide_controls' => array(
				'type' => 'switch',
				'switch_text' => __( 'Hide all map controls', 'us' ),
				'std' => 0,
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'disable_zoom' => array(
				'type' => 'switch',
				'switch_text' => __( 'Disable map zoom on mouse wheel scroll', 'us' ),
				'std' => 0,
				'group' => us_translate( 'Appearance' ),
			),
			'disable_dragging' => array(
				'type' => 'switch',
				'switch_text' => __( 'Disable dragging on touch screens', 'us' ),
				'std' => 0,
				'group' => us_translate( 'Appearance' ),
			),
			'map_style_json' => array(
				'title' => __( 'Map Style', 'us' ),
				'description' => sprintf( __( 'Check available styles on %s.', 'us' ), '<a href="https://snazzymaps.com/" target="_blank">snazzymaps.com</a>' ),
				'type' => 'html',
				'std' => '',
				'encoded' => TRUE,
				'show_if' => array( 'provider', '=', 'google' ),
				'dynamic_values' => TRUE,
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'layer_style' => array(
				'title' => __( 'Map Style', 'us' ),
				'description' => sprintf( __( 'Check available styles on %s.', 'us' ), '<a href="https://leaflet-extras.github.io/leaflet-providers/preview/" target="_blank">Leaflet Provider Demo</a>' ) . ' ' . sprintf( __( 'Some providers require an API key in the URL, e.g. %s.', 'us' ), '<a href="https://carto.com/basemaps/apikey" target="_blank">CARTO</a>' ) . ' ' . __( 'Examples:', 'us' ) . ' <span class="usof-example">https://basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png?key=YOUR_KEY</span>',
				'type' => 'text',
				'std' => '',
				'show_if' => array( 'provider', '=', 'osm' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
		),

		$conditional_params,
		$design_options_params
	),

	// Not used params, required for correct fallback
	'fallback_params' => array(
		'source',
		'custom_marker_img',
	),

	'usb_init_js' => '$elm.filter(\'.w-map.provider_google\').wGmaps();$elm.filter(\'.w-map.provider_osm\').wLmaps()',
);
