<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for shortcode: [us_list_order]
 */

$misc = us_config( 'elements_misc' );
$conditional_params = us_config( 'elements_conditional_options' );
$design_options_params = us_config( 'elements_design_options' );

$orderby_options = array();

if ( us_is_elm_editing_page() ) {
	$_group = '';

	foreach( us_get_list_orderby_params() as $name => $param ) {
		if ( $_group != $param['group'] ) {
			$_group = $param['group'];
		}
		$orderby_options[ $_group ][ $name ] = $param['label'];
	}
}

$orderby_options['custom'] = __( 'Custom Field', 'us' );

/**
 * @return array
 */
return array(
	'title' => __( 'List Order', 'us' ),
	'category' => __( 'Lists', 'us' ),
	'icon' => 'fas fa-sort-amount-down',
	'params' => us_set_params_weight(

		// General section
		array(
			'orderby_items' => array(
				'title' => __( 'Order by', 'us' ),
				'type' => 'group',
				'show_controls' => TRUE,
				'is_sortable' => TRUE,
				'is_accordion' => TRUE,
				'accordion_title' => 'value',
				'params' => array(
					'value' => array(
						'type' => 'select',
						'options' => $orderby_options,
						'std' => 'date',
						'admin_label' => TRUE,
					),
					'custom_field' => array(
						'description' => __( 'Enter custom field name to order items by its value', 'us' ),
						'type' => 'text',
						'std' => '',
						'placeholder' => 'my_custom_field',
						'classes' => 'for_above',
						'admin_label' => TRUE,
						'show_if' => array( 'value', '=', 'custom' ),
					),
					'custom_field_numeric' => array(
						'type' => 'switch',
						'switch_text' => __( 'Order by numeric values', 'us' ),
						'std' => 0,
						'classes' => 'for_above',
						'show_if' => array( 'value', '=', 'custom' ),
					),
					'invert' => array(
						'type' => 'switch',
						'switch_text' => __( 'Invert order', 'us' ),
						'std' => 0,
						'classes' => 'for_above',
					),
					'label' => array(
						'title' => us_translate( 'Title' ),
						'description' => __( 'Leave blank to use the default.', 'us' ),
						'type' => 'text',
						'std' => '',
						'admin_label' => TRUE,
					),
				),
				'std' => array(
					array(
						'value' => 'date',
						'custom_field' => '',
						'custom_field_numeric' => 0,
						'invert' => 0,
						'label' => '',
					),
				),
				'usb_preview' => TRUE,
			),
		),

		// Appearance section
		array(
			'text_before' => array(
				'title' => us_translate( 'Title' ),
				'type' => 'text',
				'std' => '',
				'admin_label' => TRUE,
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => array(
					array(
						'elm' => '.w-order-label',
						'toggle_class_inverse' => 'hidden',
					),
					array(
						'elm' => '.w-order-label',
						'attr' => 'text',
					),
				),
			),
			'first_label' => array(
				'title' => __( 'First Value Label', 'us' ),
				'type' => 'text',
				'std' => us_translate( 'Default' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),

			'selection_type' => array(
				'title' => __( 'Selection Type', 'us' ),
				'type' => 'select',
				'options' => array(
					'dropdown' => __( 'Dropdown', 'us' ),
					'radio' => __( 'Radio buttons', 'us' ),
				),
				'std' => 'dropdown',
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'values_as_btn' => array(
				'type' => 'switch',
				'switch_text' => __( 'Values as buttons', 'us' ),
				'std' => 0,
				'show_if' => array( 'selection_type', '=', 'radio' ),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'values_btn_style' => array(
				'title' => __( 'Button Style', 'us' ),
				'description' => $misc['desc_btn_styles'],
				'type' => 'select',
				'options' =>
					array(
						'style_1' => sprintf( '&ndash; %s 1 &ndash;', us_translate( 'Style' ) ),
						'style_2' => sprintf( '&ndash; %s 2 &ndash;', us_translate( 'Style' ) ),
						'style_3' => sprintf( '&ndash; %s 3 &ndash;', us_translate( 'Style' ) ),
					) + us_get_btn_styles(),
				'std' => 'style_1',
				'show_if' => array(
					array( 'selection_type', '=', 'radio' ),
					'and',
					array( 'values_as_btn', '=', '1' ),
				),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => TRUE,
			),
			'values_btn_cols' => array(
				'title' => __( 'Number of buttons in a row', 'us' ),
				'type' => 'select',
				'options' => array(
					'auto' => us_translate_x( 'Auto', 'auto preload' ),
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
				),
				'std' => 'auto',
				'show_if' => array(
					array( 'selection_type', '=', 'radio' ),
					'and',
					array( 'values_as_btn', '=', '1' ),
				),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => array(
					'mod' => 'btns_in_row',
				),
			),
			'us_field_style' => array(
				'title' => __( 'Field Style', 'us' ),
				'description' => $misc['desc_field_styles'],
				'type' => 'select',
				'options' => us_get_field_styles(),
				'std' => 'default',
				'show_if' => array(
					array( 'selection_type', '=', 'dropdown' ),
					'or',
					array( 'values_as_btn', '!=', '1' ),
				),
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => array(
					'mod' => 'us-field-style',
				),
			),
			'width_full' => array(
				'switch_text' => __( 'Stretch to the full width', 'us' ),
				'type' => 'switch',
				'std' => 0,
				'group' => us_translate( 'Appearance' ),
				'usb_preview' => array(
					'toggle_class' => 'width_full',
				),
			),
			'change_url_params' => array(
				'switch_text' => __( 'Change URL params', 'us' ),
				'type' => 'switch',
				'std' => 1,
				'group' => us_translate( 'Appearance' ),
			),
			'scroll_to_list' => array(
				'type' => 'switch',
				'switch_text' => __( 'Scroll to List', 'us' ),
				'std' => 1,
				'group' => us_translate( 'Appearance' ),
			),
		),

		$conditional_params,
		$design_options_params
	),

	'usb_init_js' => '$elm.usListOrder()',
);
