<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Configuration for shortcode: highlighted_heading
 */

$misc = us_config( 'elements_misc' );
$conditional_params = us_config( 'elements_conditional_options' );
$design_options_params = us_config( 'elements_design_options' );
$effect_options_params = us_config( 'elements_effect_options' );

// Build the grouped color-select options (shared by Text Color and Background Color)
// from the presets config. Presets that use theme color variables only (no hex color)
// go to the "Theme-color based" group, the rest go to "Predefined".
$theme_group = __( 'Theme-color based gradients', 'us' );
$predef_group = __( 'Predefined gradients', 'us' );

$grouped_presets = array(
	$theme_group => array(),
	$predef_group => array()
);

foreach ( us_config( 'highlighted-heading-gradients', array() ) as $preset_key => $preset_data ) {
	$group = ( strpos( $preset_data['gradient'], '#' ) === FALSE ) ? $theme_group : $predef_group;
	$grouped_presets[ $group ][ $preset_key ] = $preset_data['title'];
}

$color_options = array(
	'' => '– ' . us_translate( 'None' ) . ' –',
	'custom' => __( 'Custom', 'us' ),
);

foreach ( $grouped_presets as $group_label => $group_options ) {
	if ( ! empty( $group_options ) ) {
		$color_options[ $group_label ] = $group_options;
	}
}

/**
 * @return array
 */
return array(
	'title' => __( 'Highlighted Heading', 'us' ),
	'category' => __( 'Basic', 'us' ),
	'icon' => 'fas fa-highlighter',
	'class' => 'show_new_badge',
	'params' => us_set_params_weight(

		// General section
		array(
			'items' => array(
				'type' => 'group',
				'show_controls' => TRUE,
				'is_duplicate' => TRUE,
				'is_sortable' => TRUE,
				'is_accordion' => TRUE,
				'accordion_title' => 'text',
				'params' => array(

					'text' => array(
						'title' => us_translate( 'Text' ),
						'type' => 'text',
						'std' => us_translate( 'Text' ),
						'dynamic_values' => TRUE,
						'admin_label' => TRUE,
					),

					// Text color: preset gradient, or a custom solid color / gradient
					'text_color' => array(
						'title' => __( 'Text Color', 'us' ),
						'type' => 'select',
						'options' => $color_options,
						'std' => '',
					),
					'custom_text_color' => array(
						'type' => 'color',
						'clear_pos' => 'right',
						'with_gradient' => TRUE,
						'std' => '_content_primary',
						'classes' => 'for_above',
						'show_if' => array( 'text_color', '=', 'custom' ),
					),
					'animate_text' => array(
						'type' => 'switch',
						'switch_text' => __( 'Animate text gradient', 'us' ),
						'std' => 0,
						'show_if' => array( 'text_color', '!=', '' ),
					),

					// Background color: preset gradient, or a custom solid color / gradient
					'bg_color' => array(
						'title' => __( 'Background Color', 'us' ),
						'type' => 'select',
						'options' => $color_options,
						'std' => '',
					),
					'custom_bg_color' => array(
						'type' => 'color',
						'clear_pos' => 'right',
						'with_gradient' => TRUE,
						'std' => '_content_bg_alt',
						'classes' => 'for_above',
						'show_if' => array( 'bg_color', '=', 'custom' ),
					),
					'animate_bg' => array(
						'type' => 'switch',
						'switch_text' => __( 'Animate background gradient', 'us' ),
						'std' => 0,
						'show_if' => array( 'bg_color', '!=', '' ),
					),
					'bg_start_indent' => array(
						'title' => __( 'Background left indent', 'us' ),
						'type' => 'slider',
						'std' => '0.2em',
						'options' => array(
							'em' => array(
								'min' => 0.0,
								'max' => 0.5,
								'step' => 0.05,
							),
						),
						'show_if' => array( 'bg_color', '!=', '' ),
					),
					'bg_end_indent' => array(
						'title' => __( 'Background right indent', 'us' ),
						'type' => 'slider',
						'std' => '0.2em',
						'options' => array(
							'em' => array(
								'min' => 0.0,
								'max' => 0.5,
								'step' => 0.05,
							),
						),
						'show_if' => array( 'bg_color', '!=', '' ),
					),

					// Typography
					'font_family' => array(
						'title' => __( 'Font', 'us' ),
						'type' => 'select',
						'options' => us_is_elm_editing_page() ? us_get_fonts_for_selection() : array(),
						'std' => '',
						'cols' => 2,
					),
					'font_weight' => array(
						'title' => __( 'Font Weight', 'us' ),
						'description' => $misc['desc_font_weight'],
						'type' => 'text',
						'std' => '',
						'cols' => 2,
					),
					'italic' => array(
						'type' => 'checkboxes',
						'options' => array(
							'italic' => __( 'Italic', 'us' ),
						),
						'std' => '',
					),
				),
				'std' => array(
					array(
						'text' => _x( 'Make Your Ideas', 'Part of the phrase: Make Your Ideas Shine', 'us' ),
					),
					array(
						'text' => _x( 'Shine', 'Part of the phrase: Make Your Ideas Shine', 'us' ),
						'text_color' => 'prism',
						'animate_text' => 1,
					),
				),
				'usb_preview' => TRUE,
			),

			'tag' => array(
				'title' => __( 'HTML tag', 'us' ),
				'type' => 'select',
				'options' => $misc['html_tag_values'],
				'std' => 'h1',
				'admin_label' => TRUE,
				'usb_preview' => array(
					'attr' => 'tag',
				),
			),
		),

		$effect_options_params,
		$conditional_params,
		$design_options_params
	),
);
