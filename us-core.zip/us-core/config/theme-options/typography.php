<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Theme Options > Typography
 */

global $usof_options;

$misc = us_config( 'elements_misc' );

$live_buider_is_enabled = ! empty( $usof_options['live_builder'] ) ? TRUE : FALSE;

/**
 * Check if "uploads" directory is writable, as the locally stored Google Fonts go there
 *
 * Note: the check is limited to the Theme Options page, the only place its result is shown,
 * as this config is required in many other contexts, where it is made for nothing
 */
$upload_dir_not_writable = ( us_is_theme_options_page() AND ! us_uploads_dir_is_writable() );

// Get Uploaded Fonts for selection
$uploaded_fonts_options = array();
if ( isset( $usof_options['uploaded_fonts'] ) AND $uploaded_fonts = $usof_options['uploaded_fonts'] ) {
	foreach ( $uploaded_fonts as $uploaded_font ) {
		$uploaded_font_name = us_sanitize_font_family( $uploaded_font['name'] );
		if (
			empty( $uploaded_font_name )
			OR empty( $uploaded_font['files'] )
		) {
			continue;
		}
		$uploaded_fonts_options[ __( 'Uploaded Fonts', 'us' ) ][ $uploaded_font_name ] = $uploaded_font_name;
	}
}

// Adobe Fonts
$adobe_fonts_options = array();
foreach ( us_get_adobe_fonts() as $font_slug => $font_name ) {
	$adobe_fonts_options[ __( 'Adobe Fonts (loaded from Adobe servers)', 'us' ) ][ $font_slug ] = $font_name;
}

// Get Web Safe fonts for selection
foreach ( us_config( 'web-safe-fonts' ) as $web_safe_font ) {
	$websafe_fonts_options[ __( 'Web safe font combinations (do not need to be loaded)', 'us' ) ][ $web_safe_font ] = $web_safe_font;
}

// Generate Typography settings for Headings 1-6
$typography_heading_settings = array();
for ( $h = 1; $h <= 6; $h++ ) {

	// Separate first options for Heading 1 and Headings 2-5
	if ( $h == 1 ) {
		$first_font_family_option = array( 'inherit' => '– ' . __( 'As in Global Text', 'us' ) . ' –', );
		$first_text_transform_option = array();
		$first_font_style_option = array();
	} else {
		$first_font_family_option = array(
			'inherit' => '– ' . __( 'As in Global Text', 'us' ) . ' –',
			'var(--h1-font-family)' => '– ' . __( 'As in Heading 1', 'us' ) . ' –',
			);
		$first_text_transform_option = array( 'var(--h1-text-transform)' => '– ' . __( 'As in Heading 1', 'us' ) . ' –', );
		$first_font_style_option = array( 'var(--h1-font-style)' => '– ' . __( 'As in Heading 1', 'us' ) . ' –', );
	}

	// Default font-size value based on heading number
	$default_font_sizes = array(
		1 => 'clamp(2rem, 4vw, 3rem)',
		2 => 'clamp(1.6rem, 3.5vw, 2rem)',
		3 => 'clamp(1.3rem, 3vw, 1.5rem)',
		4 => '1.2rem',
		5 => '1rem',
		6 => '0.85rem',
	);

	$typography_heading_settings[ 'h' . $h ] = array(
		'title' => sprintf( __( 'Heading %s', 'us' ), $h ),
		'type' => 'typography_options',
		'fields' => array(
			'font-family' => array(
				'title' => __( 'Font', 'us' ),
				'type' => 'autocomplete',
				'preview_text' => usb_is_builder_page() ? FALSE : array(
					'text' => sprintf( __( 'Heading %s preview', 'us' ), $h ),
					'typography_tag' => 'h' . $h,
				),
				// TODO: improve autocomplete logic: no need to take separator into account for non-multiple
				'value_separator' => '/',
				'options' => us_array_merge(
					$first_font_family_option,
					$adobe_fonts_options,
					$uploaded_fonts_options,
					$websafe_fonts_options
				),
				// The Google Fonts list is the same in every typography field, so it is output once
				'shared_options' => array(
					'id' => 'google_fonts',
					'options' => us_get_all_google_fonts(),
				),
				'std' => ( $h == 1 ) ? 'inherit' : 'var(--h1-font-family)',
			),
			'font-size' => array(
				'title' => __( 'Font Size', 'us' ),
				'description' => $misc['desc_font_size'],
				'type' => 'text',
				'std' => $default_font_sizes[ $h ],
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'line-height' => array(
				'title' => __( 'Line height', 'us' ),
				'type' => 'slider',
				'std' => '1.2',
				'options' => array(
					'' => array(
						'min' => 1.00,
						'max' => 2.00,
						'step' => 0.01,
					),
					'px' => array(
						'min' => 20,
						'max' => 100,
					),
				),
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'font-weight' => array(
				'title' => __( 'Font Weight', 'us' ),
				'type' => 'text',
				'std' => ( $h == 1 ) ? '400' : 'var(--h1-font-weight)',
				// Available values are filled by JS
				'description' => __( 'Available values:', 'us' ) . ' '
					. ( $h == 1 ? '' : '<span class="usof-example">var(--h1-font-weight)</span>' )
					. '<span class="us-typography-axis" data-axis="wght"></span>',
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'bold-font-weight' => array(
				'title' => __( 'Bold Text Font Weight', 'us' ),
				'type' => 'text',
				'std' => ( $h == 1 ) ? '700' : 'var(--h1-bold-font-weight)',
				// Available values are filled by JS
				'description' => __( 'Available values:', 'us' ) . ' '
					. ( $h == 1 ? '' : '<span class="usof-example">var(--h1-bold-font-weight)</span>' )
					. '<span class="us-typography-axis" data-axis="wght"></span>',
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'font-stretch' => array(
				'title' => __( 'Font Stretch', 'us' ),
				'type' => 'text',
				'std' => '100%',
				// Available values are filled by JS
				'description' => __( 'Available values:', 'us' ) . ' '
					. ( $h == 1 ? '' : '<span class="usof-example">var(--h1-font-stretch)</span>' )
					. '<span class="us-typography-axis" data-axis="wdth"></span>',
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'text-transform' => array(
				'title' => __( 'Text Transform', 'us' ),
				'type' => 'select',
				'options' => us_array_merge(
					$first_text_transform_option,
					array(
						'none' => us_translate( 'None' ),
						'uppercase' => 'UPPERCASE',
						'lowercase' => 'lowercase',
						'capitalize' => 'Capitalize',
					)
				),
				'std' => ( $h == 1 ) ? 'none' : 'var(--h1-text-transform)',
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'font-style' => array(
				'title' => __( 'Font Style', 'us' ),
				'type' => 'select',
				'options' => us_array_merge(
					$first_font_style_option,
					array(
						'normal' => __( 'normal', 'us' ),
						'italic' => __( 'italic', 'us' ),
					)
				),
				'std' => ( $h == 1 ) ? 'normal' : 'var(--h1-font-style)',
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'letter-spacing' => array(
				'title' => __( 'Letter Spacing', 'us' ),
				'type' => 'slider',
				'std' => '0em',
				'options' => array(
					'em' => array(
						'min' => - 0.10,
						'max' => 0.20,
						'step' => 0.01,
					),
				),
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'margin-bottom' => array(
				'title' => __( 'Bottom indent', 'us' ),
				'type' => 'slider',
				'std' => '1.5rem',
				'options' => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
					'em' => array(
						'min' => 0.0,
						'max' => 5.0,
						'step' => 0.1,
					),
					'rem' => array(
						'min' => 0.0,
						'max' => 5.0,
						'step' => 0.1,
					),
				),
				'is_responsive' => TRUE,
				'cols' => 2,
			),
			'color' => array(
				'title' => us_translate( 'Color' ),
				'type' => 'color',
				'clear_pos' => 'right',
				'with_gradient' => TRUE,
				'exclude_dynamic_colors' => 'custom_field',
				'std' => '',
				'usb_preview' => TRUE,
				'cols' => 2,
			),
			'color_override' => array(
				'type' => 'checkboxes',
				'options' => array(
					'1' => __( 'Override color globally', 'us' ),
				),
				'std' => '',
				'classes' => 'for_above',
				'usb_preview' => TRUE,
			),
		),
		'usb_preview' => array(
			'elm' => '#' . US_BUILDER_TYPOGRAPHY_TAG_ID,
			'typography' => TRUE,
		),
	);
}

// Params of Text Styles are the same as in Design options of elements, but with the responsive states
// Note: the `color` field type has no support for responsive states, so colors stay the same on all screens
$text_style_params = us_config( 'elements_text_options', array() );
foreach ( $text_style_params as &$text_style_param ) {
	if ( $text_style_param['type'] != 'color' ) {
		$text_style_param['is_responsive'] = TRUE;
	}
}
unset( $text_style_param );

// New styles get the font size of Heading 4
$text_style_params['font-size']['std'] = 'var(--h4-font-size)';

// Create edit link for Typography in Live
$front_page_id = (int) get_option( 'page_on_front' );
$usb_edit_typography_link = usb_get_edit_link(
	$front_page_id,
	array(
		'action' => 'us-site-settings',
		'group' => 'typography'
	)
);

return array(
	'title' => __( 'Typography', 'us' ),
	'edit_live_link' => $live_buider_is_enabled ? $usb_edit_typography_link : '',
	'fields' => array_merge(

		array(

			// Text Styles
			'h_text_styles' => array(
				'title' => __( 'Text Styles', 'us' ),
				'description' => __( 'Create reusable text styles and apply them in the "Text Style" setting on the Design tab of any element.', 'us' ),
				'type' => 'heading',
				'classes' => 'desc_4',
			),
			'text_styles' => array(
				'type' => 'group',
				'preview' => 'text_style',
				'preview_class_format' => 'us-text-style_%s',
				'is_accordion' => TRUE,
				'is_duplicate' => TRUE,
				'is_sortable' => TRUE,
				'show_controls' => TRUE,
				'accordion_title' => 'name',
				'params' => array_merge(
					array(
						'id' => array(
							'type' => 'hidden',
							'std' => NULL,
						),
					),
					$text_style_params,
					array(
						'name' => array(
							'title' => __( 'Text Style Name', 'us' ),
							'type' => 'text',
							'std' => us_translate( 'Style' ),
							'cols' => 2,
						),
						'class' => array(
							'title' => __( 'Extra class', 'us' ),
							'description' => __( 'Will be added to the container with this style', 'us' ),
							'type' => 'text',
							'std' => '',
							'cols' => 2,
							'classes' => 'desc_4',
						),
					)
				),

				// No styles are created by default
				'std' => array(),
			),

			// Global Text
			'h_typography_body' => array(
				'title' => __( 'Global Text', 'us' ),
				'type' => 'heading',
			),
			'body' => array(
				'title' => __( 'Global Text', 'us' ),
				'type' => 'typography_options',
				'fields' => array(
					'font-family' => array(
						'title' => __( 'Font', 'us' ),
						'type' => 'autocomplete',
						'preview_text' => usb_is_builder_page() ? FALSE : array(
							'text' => __( 'Here\'s a preview of what your website\'s text will look like <strong>by default</strong>. You can also adjust the typography of most elements separately. Note that the Font Size setting affects all the sizes defined in "rem" units, that is, almost all areas of your site.', 'us' ),
							'typography_tag' => 'body',
						),
						// TODO: improve autocomplete logic: no need to take separator into account for non-multiple
						'value_separator' => '/',
						'options' => us_array_merge(
							array( 'none' => __( 'No font specified', 'us' ) ),
							$uploaded_fonts_options,
							$adobe_fonts_options,
							$websafe_fonts_options
						),
						// The Google Fonts list is the same in every typography field, so it is output once
						'shared_options' => array(
							'id' => 'google_fonts',
							'options' => us_get_all_google_fonts(),
						),
						'std' => 'Georgia, serif',
					),
					'font-size' => array(
						'title' => __( 'Font Size', 'us' ),
						'description' => $misc['desc_font_size'],
						'type' => 'text',
						'std' => '16px',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'line-height' => array(
						'title' => __( 'Line height', 'us' ),
						'type' => 'slider',
						'std' => '28px',
						'options' => array(
							'' => array(
								'min' => 1.00,
								'max' => 2.00,
								'step' => 0.01,
							),
							'px' => array(
								'min' => 20,
								'max' => 100,
							),
						),
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'font-weight' => array(
						'title' => __( 'Font Weight', 'us' ),
						'type' => 'text',
						'std' => '400',
						// Available values are filled by JS
						'description' => __( 'Available values:', 'us' ) . ' <span class="us-typography-axis" data-axis="wght"></span>',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'bold-font-weight' => array(
						'title' => __( 'Bold Text Font Weight', 'us' ),
						'type' => 'text',
						'std' => '700',
						// Available values are filled by JS
						'description' => __( 'Available values:', 'us' ) . ' <span class="us-typography-axis" data-axis="wght"></span>',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'font-stretch' => array(
						'title' => __( 'Font Stretch', 'us' ),
						'type' => 'text',
						'std' => '100%',
						// Available values are filled by JS
						'description' => __( 'Available values:', 'us' ) . ' <span class="us-typography-axis" data-axis="wdth"></span>',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'text-transform' => array(
						'title' => __( 'Text Transform', 'us' ),
						'type' => 'select',
						'options' => array(
							'none' => '– ' . us_translate( 'None' ) . ' –',
							'uppercase' => 'UPPERCASE',
							'lowercase' => 'lowercase',
							'capitalize' => 'Capitalize',
						),
						'std' => 'none',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'font-style' => array(
						'title' => __( 'Font Style', 'us' ),
						'type' => 'select',
						'options' => array(
							'normal' => __( 'normal', 'us' ),
							'italic' => __( 'italic', 'us' ),
						),
						'std' => 'normal',
						'is_responsive' => TRUE,
						'cols' => 2,
					),
					'letter-spacing' => array(
						'title' => __( 'Letter Spacing', 'us' ),
						'type' => 'slider',
						'std' => '0em',
						'options' => array(
							'em' => array(
								'min' => - 0.10,
								'max' => 0.20,
								'step' => 0.01,
							),
						),
						'is_responsive' => TRUE,
						'cols' => 2,
					),
				),
				'usb_preview' => array(
					'elm' => '#' . US_BUILDER_TYPOGRAPHY_TAG_ID,
					'typography' => TRUE,
				),
			),
		),
		$typography_heading_settings,
		array(

			// Additional Google Fonts
			'h_typography_3' => array(
				'title' => __( 'Additional Google Fonts', 'us' ),
				'description' => __( 'In case when you need more Google Fonts in theme elements.', 'us' ),
				'type' => 'heading',
			),
			'custom_font' => array(
				'type' => 'group',
				'accordion_title' => 'font_family',
				'is_accordion' => FALSE,
				'is_duplicate' => FALSE,
				'show_controls' => TRUE,
				'std' => array(),
				'params' => array(
					'font_family' => array(
						'type' => 'font',
						'preview_text' => array(
							'text' => __( 'Google Font Preview', 'us' ),
						),
						// Displayed only for variable fonts. Available values are filled by JS
						'description' => '<span class="us-font-variable-note"'
							. ' data-label="' . __( 'Variable Font', 'us' ) . '."'
							. ' data-weights-label="' . __( 'Available Font Weights:', 'us' ) . '"></span>',
						'std' => 'Open Sans',
					),
				),
			),

			// Local Google Fonts
			'h_typography_local_gfonts' => array(
				'title' => __( 'Local Google Fonts', 'us' ),
				'description' => __( 'Allows you to remove the connection between your site and the Google font servers.', 'us' ),
				'type' => 'heading',
			),
			'store_gfonts_locally' => array(
				'type' => 'switch',
				'switch_text' => __( 'Store Google Fonts locally', 'us' ),
				'description' => __( 'When this option is ON, all Google Fonts used above are downloaded to your site after saving the changes.', 'us' ),
				'std' => 0,
				'classes' => 'for_above desc_2',
				'disabled' => $upload_dir_not_writable,
			),
			'store_gfonts_locally_not_writable' => array(
				'description' => __( 'Your uploads folder is not writable. Change your server permissions to use this option.', 'us' ),
				'type' => 'message',
				'classes' => 'string',
				'place_if' => $upload_dir_not_writable,
			),

			// Uploaded Fonts
			'h_typography_4' => array(
				'title' => __( 'Uploaded Fonts', 'us' ),
				'description' => sprintf( __( 'Add custom fonts via uploading %s files.', 'us' ), '<strong>woff2</strong>' ) . ' <a target="_blank" href="' . US_HELP_PORTAL_URL . '/' . strtolower( US_THEMENAME ) . '/typography/#uploaded-fonts">' . __( 'Learn more', 'us' ) . '</a>.',
				'type' => 'heading',
			),
			'uploaded_fonts' => array(
				'type' => 'group',
				'accordion_title' => 'name',
				'is_accordion' => FALSE,
				'is_duplicate' => FALSE,
				'show_controls' => TRUE,
				'std' => array(),
				'params' => array(
					'name' => array(
						'title' => __( 'Font Name', 'us' ),
						'type' => 'text',
						'std' => 'Uploaded Font',
					),
					'variable_font' => array(
						'type' => 'checkboxes',
						'options' => array(
							'variable_font' => __( 'Variable Font', 'us' ),
						),
						'std' => '',
						'classes' => 'for_above',
					),
					'italic' => array(
						'type' => 'checkboxes',
						'options' => array(
							'italic' => __( 'Italic', 'us' ),
						),
						'std' => '',
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '!=', 'variable_font' ),
					),
					'weight' => array(
						'title' => __( 'Font Weight', 'us' ),
						'type' => 'slider',
						'std' => 400,
						'options' => array(
							'' => array(
								'min' => 100,
								'max' => 900,
								'step' => 100,
							),
						),
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '!=', 'variable_font' ),
					),
					'wght_min' => array(
						'title' => sprintf( '%s: %s (wght)', __( 'Font Weight', 'us' ), __( 'Min Value', 'us' ) ),
						'type' => 'text',
						'placeholder' => '100',
						'std' => '',
						'cols' => 2,
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '=', 'variable_font' ),
					),
					'wdth_min' => array(
						'title' => sprintf( '%s: %s (wdth)', __( 'Font Stretch', 'us' ), __( 'Min Value', 'us' ) ),
						'type' => 'text',
						'placeholder' => '75',
						'std' => '',
						'cols' => 2,
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '=', 'variable_font' ),
					),
					'wght_max' => array(
						'title' => sprintf( '%s: %s (wght)', __( 'Font Weight', 'us' ), __( 'Max Value', 'us' ) ),
						'type' => 'text',
						'placeholder' => '900',
						'std' => '',
						'cols' => 2,
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '=', 'variable_font' ),
					),
					'wdth_max' => array(
						'title' => sprintf( '%s: %s (wdth)', __( 'Font Stretch', 'us' ), __( 'Max Value', 'us' ) ),
						'type' => 'text',
						'placeholder' => '125',
						'std' => '',
						'cols' => 2,
						'classes' => 'for_above',
						'show_if' => array( 'variable_font', '=', 'variable_font' ),
					),
					'files' => array(
						'title' => __( 'Font Files', 'us' ),
						'type' => 'upload',
						'is_multiple' => TRUE,
						'preview_type' => 'text',
					),
				),
			),

			// Font Display
			'h_typography_5' => array(
				'title' => __( 'Font Display', 'us' ),
				'description' => __( 'Sets behavior of fonts rendering.', 'us' ) . ' <a href="https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display" target="_blank">' . __( 'Learn more', 'us' ) . '</a>.',
				'type' => 'heading',
			),
			'font_display' => array(
				'type' => 'radio',
				'options' => array(
					'block' => 'block',
					'swap' => 'swap',
					'fallback' => 'fallback',
					'optional' => 'optional',
				),
				'std' => 'swap',
				'classes' => 'for_above',
			),

			// Adobe Fonts
			'h_typography_6' => array(
				'title' => __( 'Adobe Fonts', 'us' ),
				'description' => sprintf( __( 'Paste the Project ID from your %sAdobe Web Project%s.', 'us' ), ' <a href="https://fonts.adobe.com/my_fonts#web_projects-section" target="_blank">', '</a>' ) . ' ' . __( 'Examples:', 'us' ) . ' abc9def, zyx8wuv',
				'type' => 'heading',
			),
			'adobe_fonts' => array(
				'type' => 'adobe_fonts',
				'classes' => 'for_above',
			),
		)
	),
);
