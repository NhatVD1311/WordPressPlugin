<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Helper functions for the Map element, which shows markers of posts
 */

if ( ! function_exists( 'us_gmaps_has_grid_layout_popup' ) ) {
	/**
	 * Check if the Map element opens popups of posts by the Grid Layout on the marker click, e.g. for the assets
	 * optimization, @see config/assets.php
	 *
	 * Note: the builder omits attributes with default values, so the defaults are taken for absent ones
	 *
	 * @param array $atts The element attributes
	 * @return bool
	 */
	function us_gmaps_has_grid_layout_popup( $atts ) {
		return (
			in_array( us_arr_path( $atts, 'marker_source', 'addresses' ), array( 'posts', 'current_wp_query' ), TRUE )
			AND us_arr_path( $atts, 'marker_click', 'grid_layout' ) === 'grid_layout'
		);
	}
}

if ( ! function_exists( 'us_gmaps_get_posts_query_args' ) ) {
	/**
	 * Get arguments of the posts query for the Map element without List Filter and List Search params
	 *
	 * The arguments are got on the page render only, AJAX requests of List Filter and List Search
	 * take them signed from the page, because the current query doesn't exist there.
	 *
	 * @param array $atts The element settings
	 * @return array Query arguments, empty if the field with coordinates isn't set
	 *
	 * @filter 'us_gmaps_markers_limit' Allows to change the maximum quantity of markers, 1000 by default, -1 removes the limit
	 * @filter 'us_gmaps_query_args' Allows to change arguments of the posts query
	 *
	 * Note: the filters are applied on the page render only, the result is signed and reused by AJAX requests
	 * of List Filter and List Search, so it can't depend on the request, e.g. the current user
	 */
	function us_gmaps_get_posts_query_args( $atts ) {

		$marker_source = (string) us_arr_path( $atts, 'marker_source', 'posts' );

		// @see us_gmaps_get_posts_markers()
		$coords_fields = array_values( array_filter( (array) us_arr_path( $atts, 'coords_field' ) ) );

		if ( ! $coords_fields ) {
			return array();
		}

		// Markers of posts are output without pagination, while every marker is passed to the page and drawn on the map,
		// so their quantity is limited
		$markers_limit = (int) apply_filters( 'us_gmaps_markers_limit', 1000, $atts );

		$query_args = array(
			'ignore_sticky_posts' => TRUE,
			'no_found_rows' => TRUE,
			'posts_per_page' => $markers_limit > 0 ? $markers_limit : -1,

			// The whole meta of posts isn't needed, required values are got below via a single query
			'update_post_meta_cache' => FALSE,

			// When TRUE, applies URL params of List Filter, List Order, List Search elements on the page load
			'apply_list_url_params' => ( us_arr_path( $atts, 'apply_url_params' ) OR $marker_source == 'current_wp_query' ),
		);

		if ( $marker_source == 'current_wp_query' ) {

			// Live Builder can't show the current query, so the output is imitated by the latest posts
			if ( ! usb_is_preview() ) {
				global $wp_query;
				$query_args += $wp_query->query_vars;

				// Markers are shown without pagination, while the WP_Query uses 'posts_per_archive_page'
				// instead of 'posts_per_page' on archives
				unset(
					$query_args['paged'],
					$query_args['offset'],
					$query_args['nopaging'],
					$query_args['posts_per_archive_page']
				);
			}

		} else {
			$query_args['post_type'] = explode( ',', (string) us_arr_path( $atts, 'post_type', 'post' ) );
		}

		// Post status is required, because the query of AJAX requests can show draft posts
		if ( current_user_can( 'read_private_posts' ) ) {
			$query_args['post_status'] = array( 'publish', 'private' );
		} else {
			$query_args['post_status'] = 'publish';
		}

		// Posts without coordinates should not take places within the markers limit, both fields are required
		// for separate fields of latitude and longitude
		$coords_meta_query = array_map( function( $field ) {
			return array(
				'key' => $field,
				'value' => '',
				'compare' => '!=',
			);
		}, $coords_fields );
		if ( ! empty( $query_args['meta_query'] ) AND is_array( $query_args['meta_query'] ) ) {
			$query_args['meta_query'] = array(
				'relation' => 'AND',
				$query_args['meta_query'],
				$coords_meta_query,
			);
		} else {
			$query_args['meta_query'] = $coords_meta_query;
		}

		return (array) apply_filters( 'us_gmaps_query_args', $query_args, $atts );
	}
}

if ( ! function_exists( 'us_gmaps_get_posts_markers' ) ) {
	/**
	 * Get markers of posts for the Map element
	 *
	 * @param array $query_args Arguments of the posts query, @see us_gmaps_get_posts_query_args()
	 * @param array $atts The element settings, 'coords_field' is the field or separate fields of latitude and longitude,
	 *                    @see templates/elements/gmaps.php
	 * @return array List of markers, each one is [ 'id' => int, 'lat' => float, 'lng' => float ], with 'url' => string
	 *               of the post for the 'post_link' click and 'label' => string for the label with dynamic values.
	 *               Popups by the Grid Layout are loaded on the marker click, @see us_ajax_map_infowindow()
	 *
	 * @filter 'us_gmaps_marker_coords' Allows to change coordinates of the post: an array with 'lat' and 'lng' keys
	 *                                  (or the [ latitude, longitude ] pair) or the text like "38.6774156, 34.8520661".
	 *                                  It's applied in AJAX requests of List Filter and List Search as well, so it should
	 *                                  be added without conditions of the page, like is_page()
	 */
	function us_gmaps_get_posts_markers( $query_args, $atts ) {

		$coords_fields = array_values( array_filter( (array) us_arr_path( $atts, 'coords_field' ) ) );

		if ( empty( $query_args ) OR ! $coords_fields ) {
			return array();
		}

		// The post link is opened on the marker click, @see common/js/elements/gmaps.js and lmaps.js
		$has_post_link = ( us_arr_path( $atts, 'marker_click' ) == 'post_link' );

		// The label with dynamic values is got for every post, otherwise it's the same for all markers,
		// @see templates/elements/gmaps.php
		$marker_label = '';
		if ( us_arr_path( $atts, 'marker_style' ) == 'label' ) {
			$marker_label = (string) us_arr_path( $atts, 'marker_label', '' );
		}
		$label_is_per_post = ( strpos( $marker_label, '{{' ) !== FALSE );

		// The post title is inserted without the loop context, it's needed for other dynamic values only, because
		// setup_postdata() fires the "the_post" hook, where WooCommerce loads every product with all its meta
		$label_has_dynamic_values = ( strpos( str_replace( '{{the_title}}', '', $marker_label ), '{{' ) !== FALSE );

		$posts = ( new WP_Query( $query_args ) )->posts;

		if ( empty( $posts ) ) {
			return array();
		}

		$post_ids = array_map( 'intval', wp_list_pluck( $posts, 'ID' ) );

		// Get coordinates via a single query, because update_meta_cache() loads all the meta of posts,
		// e.g. dozens of rows per WooCommerce product
		global $wpdb;
		$meta_rows = $wpdb->get_results(
			$wpdb->prepare(
				"
				SELECT post_id, meta_key, meta_value
				FROM {$wpdb->postmeta}
				WHERE post_id IN (" . implode( ',', $post_ids ) . ")
				AND meta_key IN (" . implode( ',', array_fill( 0, count( $coords_fields ), '%s' ) ) . ")
				ORDER BY meta_id ASC
				",
				$coords_fields
			)
		);

		$meta_values = array();
		foreach ( $meta_rows as $row ) {
			if ( ! isset( $meta_values[ $row->post_id ][ $row->meta_key ] ) ) {
				$meta_values[ $row->post_id ][ $row->meta_key ] = $row->meta_value;
			}
		}

		// Custom fields in dynamic values read the whole meta of every post, so load it at once
		if ( $label_has_dynamic_values AND us_gmaps_dynamic_values_need_meta( $marker_label ) ) {
			update_postmeta_cache( $post_ids );
		}

		// Save globals changed by setup_postdata() and the "the_post" hook to restore them after the loop,
		// as the current post may be empty, e.g. on archives without results
		$loop_globals = array( 'post', 'id', 'authordata', 'currentday', 'currentmonth', 'page', 'pages', 'multipage', 'more', 'numpages', 'product', 'us_in_the_loop', 'us_loop_item_type' );
		$original_globals = array();
		if ( $label_has_dynamic_values ) {
			foreach ( $loop_globals as $global_name ) {
				$original_globals[ $global_name ] = $GLOBALS[ $global_name ] ?? NULL;
			}
			$GLOBALS['us_in_the_loop'] = TRUE;
			$GLOBALS['us_loop_item_type'] = 'post';
		}

		$markers = array();

		foreach ( $posts as $_post ) {
			$meta = $meta_values[ $_post->ID ] ?? array();

			// Separate fields of latitude and longitude, or a single field with both of them
			$coords = isset( $coords_fields[1] )
				? array( $meta[ $coords_fields[0] ] ?? '', $meta[ $coords_fields[1] ] ?? '' )
				: maybe_unserialize( $meta[ $coords_fields[0] ] ?? '' );

			$coords = us_gmaps_parse_coords( apply_filters( 'us_gmaps_marker_coords', $coords, $_post->ID, $atts ) );
			if ( ! $coords ) {
				continue;
			}

			// Set the loop context to get dynamic values of the post
			if ( $label_has_dynamic_values ) {
				$GLOBALS['post'] = $_post;
				setup_postdata( $_post );
			}

			$marker = array(
				'id' => $_post->ID,
				'lat' => $coords[ /* latitude */ 0 ],
				'lng' => $coords[ /* longitude */ 1 ],
			);
			if ( $has_post_link ) {
				$marker['url'] = get_permalink( $_post );
			}
			if ( $label_is_per_post ) {
				$marker['label'] = us_gmaps_get_marker_label( $marker_label, $_post );
			}
			$markers[] = $marker;
		}

		foreach ( $original_globals as $global_name => $global_value ) {
			$GLOBALS[ $global_name ] = $global_value;
		}

		return $markers;
	}
}

if ( ! function_exists( 'us_gmaps_parse_coords' ) ) {
	/**
	 * Get coordinates from a raw value of the ACF "Google Map" field, the [ latitude, longitude ] pair
	 * or a text like "38.6774156, 34.8520661"
	 *
	 * @param mixed $value The raw meta value
	 * @return array|FALSE Returns [ latitude, longitude ] or FALSE if the value doesn't have valid coordinates
	 */
	function us_gmaps_parse_coords( $value ) {
		$value = maybe_unserialize( $value );

		// ACF "Google Map" field or the pair
		if ( is_array( $value ) ) {
			$latitude = $value['lat'] ?? $value[0] ?? '';
			$longitude = $value['lng'] ?? $value[1] ?? '';

			// Text value, the same regular expression is used in JS, @see common/js/elements/gmaps.js
		} elseif (
			is_string( $value )
			AND preg_match( '/^(-?[\d\.]+),(-?[\d\.]+)$/', preg_replace( '/\s+/', '', $value ), $matches )
		) {
			$latitude = $matches[ /* latitude */ 1 ];
			$longitude = $matches[ /* longitude */ 2 ];

		} else {
			return FALSE;
		}

		if ( ! is_numeric( $latitude ) OR ! is_numeric( $longitude ) ) {
			return FALSE;
		}

		$latitude = (float) $latitude;
		$longitude = (float) $longitude;

		if ( abs( $latitude ) > 90 OR abs( $longitude ) > 180 ) {
			return FALSE;
		}

		return array( $latitude, $longitude );
	}
}

if ( ! function_exists( 'us_gmaps_get_marker_label' ) ) {
	/**
	 * Get the label of the marker of the "Label" style: the plain text with replaced dynamic values
	 *
	 * @param string $label The label from the element settings
	 * @param WP_Post $post The post of the marker, its title replaces {{the_title}} directly, without the loop context
	 * @return string
	 */
	function us_gmaps_get_marker_label( $label, $post = NULL ) {

		// The title isn't a source of other dynamic values, so it's inserted after replacing them
		$parts = $post ? explode( '{{the_title}}', $label ) : array( $label );
		foreach ( $parts as &$part ) {
			$part = (string) us_replace_dynamic_value( $part );
		}
		unset( $part );
		$label = implode( $post ? get_the_title( $post ) : '', $parts );

		$label = html_entity_decode( $label, ENT_QUOTES, 'UTF-8' );

		// Only tags are removed, unlike wp_strip_all_tags(), which removes "<" of the text with everything after it,
		// like in "<100 €". The label is inserted as a text on the JS side, so it's safe.
		$label = preg_replace( '/<\/?[a-z][^>]*>/i', '', $label );

		return trim( preg_replace( '/\s+/', ' ', $label ) );
	}
}

if ( ! function_exists( 'us_gmaps_dynamic_values_need_meta' ) ) {
	/**
	 * Check if dynamic values of the marker label read custom fields of posts
	 *
	 * Taxonomies, dates, titles and other predefined values don't need the meta of posts, @see us_replace_dynamic_value()
	 *
	 * @param string $text The text with dynamic values
	 * @return bool
	 */
	function us_gmaps_dynamic_values_need_meta( $text ) {
		if ( ! preg_match_all( '/{{([^{}]+)}}/', $text, $matches ) ) {
			return FALSE;
		}

		$values_without_meta = array(
			'comment_count',
			'current_id',
			'favs_count',
			'now',
			'post_count',
			'post_type_plural',
			'post_type_singular',
			'site_icon',
			'site_title',
			'taxonomy_label_plural',
			'taxonomy_label_singular',
			'the_title',
			'today',
			'today_now',
			'user_count',
		);

		foreach ( $matches[1] as $value_name ) {
			if (
				! preg_match( '/^(tax|date|user|option)[|\/]/', $value_name )
				AND ! in_array( $value_name, $values_without_meta, TRUE )
			) {
				return TRUE;
			}
		}

		return FALSE;
	}
}
