<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

if ( ! function_exists( 'us_get_tr_home_url' ) ) {
	/**
	 * Site home URL, translated for the current language when a multilingual plugin is active.
	 *
	 * @return string Trailing-slashed home URL
	 */
	function us_get_tr_home_url() {
		return ( has_filter( 'us_tr_home_url' ) )
			? trailingslashit( apply_filters( 'us_tr_home_url', NULL ) )
			: trailingslashit( home_url() );
	}
}

if ( ! function_exists( 'us_breadcrumbs_is_same_url' ) ) {
	/**
	 * Whether two URLs point to the same location, ignoring the scheme and the trailing slash.
	 *
	 * @param string $url_1
	 * @param string $url_2
	 * @return bool FALSE if any of the URLs is empty
	 */
	function us_breadcrumbs_is_same_url( $url_1, $url_2 ) {
		if ( (string) $url_1 === '' OR (string) $url_2 === '' ) {
			return FALSE;
		}

		return untrailingslashit( preg_replace( '#^https?:#', '', $url_1 ) ) === untrailingslashit( preg_replace( '#^https?:#', '', $url_2 ) );
	}
}

if ( ! function_exists( 'us_breadcrumbs_get_custom' ) ) {
	/**
	 * Label and link of the "Custom Link" breadcrumbs item.
	 *
	 * @param array $item Breadcrumbs path item
	 * @return array|NULL Array with 'title' and 'link' (empty when the item has no link), or NULL for an empty label
	 */
	function us_breadcrumbs_get_custom( $item ) {
		$label = strip_tags( us_replace_dynamic_value( us_arr_path( $item, 'label', '' ) ) );
		if ( $label === '' ) {
			return NULL;
		}

		$link_atts = us_generate_link_atts( us_arr_path( $item, 'link', '' ) );
		$href = us_arr_path( $link_atts, 'href', '' );

		// The Home link is baked into the item at save time; re-resolve it through the multilingual
		// filter when it points to the site home, so it stays language-aware on WPML / Polylang sites.
		// Match scheme-insensitively (the baked value may differ in http/https from the stored option)
		// and against home_url() as well, so a home link saved in another language is still recognized.
		if (
			has_filter( 'us_tr_home_url' )
			AND (
				us_breadcrumbs_is_same_url( $href, get_option( 'home' ) )
				OR us_breadcrumbs_is_same_url( $href, home_url() )
			)
		) {
			$href = us_get_tr_home_url();
		}

		return array( 'title' => $label, 'link' => $href );
	}
}

if ( ! function_exists( 'us_breadcrumbs_get_page' ) ) {
	/**
	 * Title and link of the "Manually selected page" breadcrumbs item.
	 *
	 * @param array $item Breadcrumbs path item
	 * @return array|NULL Array with 'title' and 'link', or NULL for a missing / not published / untitled page
	 */
	function us_breadcrumbs_get_page( $item ) {
		$page_id = (int) us_arr_path( $item, 'page', 0 );
		if ( ! $page_id ) {
			return NULL;
		}

		if ( has_filter( 'us_tr_object_id' ) ) {
			$page_id = apply_filters( 'us_tr_object_id', $page_id, 'page', TRUE );
		}

		// Only a publicly available page (skip trashed / draft / private / missing)
		if ( get_post_status( $page_id ) !== 'publish' ) {
			return NULL;
		}

		// Not get_the_title(): it prefixes the title of a password-protected page with "Protected:"
		$title = apply_filters( 'the_title', get_post_field( 'post_title', $page_id, 'raw' ), $page_id );
		if ( $title === '' ) {
			return NULL;
		}

		return array( 'title' => $title, 'link' => get_permalink( $page_id ) );
	}
}

if ( ! function_exists( 'us_breadcrumbs_get_home' ) ) {
	/**
	 * Home crumb for third-party trails (WooCommerce / bbPress) that render their own Home crumb:
	 * the first "Custom Link" or "Manually selected page" item that resolves to a non-empty label.
	 *
	 * @param array $items Breadcrumbs path items
	 * @return array|NULL Array with plain-text 'title' and 'link' (may be empty), or NULL when there is no such item
	 */
	function us_breadcrumbs_get_home( $items ) {
		if ( ! is_array( $items ) ) {
			return NULL;
		}
		foreach ( $items as $item ) {
			$source = us_arr_path( $item, 'source' );
			if ( $source === 'custom' ) {
				$crumb = us_breadcrumbs_get_custom( $item );
			} elseif ( $source === 'page' ) {
				$crumb = us_breadcrumbs_get_page( $item );
			} else {
				continue;
			}
			if ( ! $crumb ) {
				continue;
			}

			// Third-party trails output the label as plain text
			$crumb['title'] = strip_tags( $crumb['title'] );
			if ( $crumb['title'] !== '' ) {
				return $crumb;
			}
		}

		return NULL;
	}
}

/**
 * Breadcrumbs
 *
 * @param $delimiter string
 * @param $items array List of path items, each with a "source" (custom / page / taxonomy / auto)
 * @param $item_before string
 * @param $item_after string
 * @param $link_attr string
 * @param $name_attr string
 * @param $position_attr string
 * @param $show_current bool Append the current-page crumb
 * @param $link_current bool Output the current crumb as a link
 * @param $show_page_number bool Output the "Page N" pagination crumb
 *
 * @return string
 */
class US_Breadcrumbs {

	protected $config;
	protected $counter;
	protected $crumbs_count = 0; // number of the rendered crumbs

	public function __construct(
		$delimiter,
		$items,
		$item_before,
		$item_after,
		$link_attr,
		$name_attr,
		$position_attr,
		$show_current = FALSE,
		$link_current = FALSE,
		$show_page_number = TRUE
	) {
		$this->config['items'] = is_array( $items ) ? $items : array();
		$this->config['delimiter'] = $delimiter ?? ' > ';
		$this->config['before'] = $item_before ?? '';
		$this->config['after'] = $item_after ?? '';
		$this->config['link_attr'] = $link_attr ?? '';
		$this->config['name_attr'] = $name_attr ?? '';
		$this->config['name_before'] = $this->config['name_after'] = '';

		if ( ! empty( $this->config['name_attr'] ) ) {
			$this->config['name_before'] = '<span' . $this->config['name_attr'] . '>';
			$this->config['name_after'] = '</span>';
		}

		$this->config['position_attr'] = $position_attr ?? '';
		$this->config['show_current'] = (bool) $show_current;
		$this->config['link_current'] = (bool) $link_current;
		$this->config['show_page_number'] = (bool) $show_page_number;

		// Predefined text
		$this->config['text']['search'] = __( 'Search Results', 'us' ); // text for a search results page
		$this->config['text']['404'] = us_translate( 'Page not found' ); // text for the 404 page

		$this->counter = 1;
	}

	private function replace_callback( $matches ) {
		return $matches[1] . '<meta ' . $this->config['position_attr'] . ' content="' . $this->counter++ . '"/>';
	}

	private function get_breadcrumb_with_markup( $input = NULL ) {
		// No microdata - no position markup
		if ( empty( $this->config['position_attr'] ) ) {
			return (string) $input;
		}

		if ( ! $input ) {
			return '<meta' . $this->config['position_attr'] . ' content="' . $this->counter++ . '"/>';
		}

		return preg_replace_callback( '#(<\/a>)#', array( $this, 'replace_callback' ), $input );
	}

	private function get_breadcrumb( $link, $name, $extra_link_atts = '' ) {
		$this->crumbs_count++;

		$output = $this->config['before'];
		$output .= '<a' . $this->config['link_attr'] . $extra_link_atts . ' href="' . $link . '">';
		$output .= $this->config['name_before'] . $name . $this->config['name_after'];
		$output .= '</a>';
		$output .= $this->get_breadcrumb_with_markup();
		$output .= $this->config['after'];

		return $output;
	}

	/**
	 * Output the current (last) crumb. Rendered as plain text unless "Link current page" is enabled.
	 * Marked with aria-current="page" to identify the current location (WAI-ARIA APG breadcrumb pattern).
	 */
	private function get_current_breadcrumb( $link, $name ) {
		if ( $this->config['link_current'] AND ! empty( $link ) ) {
			return $this->get_breadcrumb( $link, $name, ' aria-current="page"' );
		}

		$this->crumbs_count++;

		// Plain-text current crumb: put aria-current on the crumb wrapper (the opening item tag)
		$output = preg_replace( '/^<(\w+)/', '<$1 aria-current="page"', $this->config['before'], 1 );
		$output .= $this->config['name_before'] . $name . $this->config['name_after'];
		$output .= $this->get_breadcrumb_with_markup();
		$output .= $this->config['after'];

		return $output;
	}

	/**
	 * Format a term hierarchy list
	 */
	private function format_term_chain( $chain ) {
		// Bail out on an empty chain or a WP_Error (e.g. get_category_parents on an invalid term)
		if ( ! is_string( $chain ) OR $chain === '' ) {
			return '';
		}
		$this->crumbs_count += substr_count( $chain, '</a>' );

		// Strip the trailing separator (preg_quote: the separator may contain a custom symbol with regex metacharacters)
		$chain = preg_replace( "#^(.+)" . preg_quote( $this->config['delimiter'], '#' ) . "$#", "$1", $chain );
		$chain = preg_replace( '#(<a\shref[^>]+>)([^<\/]+)(<\/a>)#', '${1}' . $this->config['name_before'] . '${2}' . $this->config['name_after'] . '${3}', $chain );
		$chain = str_replace( '<a', $this->config['before'] . '<a' . $this->config['link_attr'], $chain );
		$chain = str_replace( '</a>', '</a>' . $this->config['after'], $chain );
		$chain = $this->get_breadcrumb_with_markup( $chain );

		return $chain;
	}

	/**
	 * SOURCE: Custom Link
	 */
	private function render_custom( $item ) {
		$custom = us_breadcrumbs_get_custom( $item );
		if ( ! $custom ) {
			return '';
		}

		if ( $custom['link'] === '' ) {
			$this->crumbs_count++;

			$output = $this->config['before'];
			$output .= $this->config['name_before'] . $custom['title'] . $this->config['name_after'];
			$output .= $this->get_breadcrumb_with_markup();
			$output .= $this->config['after'];

			return $output;
		}

		return $this->get_breadcrumb( esc_url( $custom['link'] ), $custom['title'] );
	}

	/**
	 * SOURCE: Manually selected page
	 */
	private function render_page( $item ) {
		$page = us_breadcrumbs_get_page( $item );

		return $page ? $this->get_breadcrumb( esc_url( $page['link'] ), $page['title'] ) : '';
	}

	/**
	 * SOURCE: Taxonomy tree - the term hierarchy for the chosen taxonomy.
	 * - On a term archive of this taxonomy: the ancestors of the queried term (the term itself is
	 *   the current entity, added by "Show current page").
	 * - On a singular post: the post's term hierarchy (deepest term + ancestors; the first term is
	 *   used when the post has several terms on the same level).
	 */
	private function render_taxonomy( $item ) {
		// Dummy chain in Live Preview for better UX
		if ( usb_is_preview() ) {
			return $this->get_breadcrumb( '#', us_translate( 'Parent Category' ) )
				. $this->config['delimiter']
				. $this->get_breadcrumb( '#', us_translate( 'Category' ) );
		}

		$taxonomy = us_arr_path( $item, 'taxonomy', '' );
		if ( empty( $taxonomy ) OR ! taxonomy_exists( $taxonomy ) ) {
			return '';
		}

		$queried = get_queried_object();

		// Term archive of this taxonomy - show the queried term's ancestors only
		if ( $queried instanceof WP_Term AND $queried->taxonomy === $taxonomy ) {
			if ( ! $queried->parent ) {
				return ''; // top-level term has no ancestors
			}
			$term = $queried->parent;

		} elseif ( is_singular() ) {
			$post_id = get_queried_object_id();
			if ( ! $post_id ) {
				return '';
			}
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( ! is_array( $terms ) OR count( $terms ) < 1 ) {
				return '';
			}
			$term = $terms[0];

			// Neither a matching term archive nor a singular view - nothing to show
		} else {
			return '';
		}

		$chain = get_term_parents_list(
			$term, $taxonomy, array(
				'separator' => $this->config['delimiter'],
				'link' => TRUE,
				'format' => 'name',
			)
		);
		if ( empty( $chain ) OR is_wp_error( $chain ) ) {
			return '';
		}

		return $this->format_term_chain( $chain );
	}

	public function render() {
		$parts = array();

		foreach ( $this->config['items'] as $item ) {
			$source = us_arr_path( $item, 'source', 'auto' );

			if ( $source === 'custom' ) {
				$chunk = $this->render_custom( $item );
			} elseif ( $source === 'page' ) {
				$chunk = $this->render_page( $item );
			} elseif ( $source === 'taxonomy' ) {
				$chunk = $this->render_taxonomy( $item );
			} else {
				$chunk = $this->render_ancestors();
			}

			if ( $chunk !== '' ) {
				$parts[] = $chunk;
			}
		}

		// Current-page crumb - element-level, appended once at the end regardless of the items composition
		if ( $this->config['show_current'] ) {
			$entity = $this->get_current_entity();
			if ( ! empty( $entity ) AND $entity['name'] !== '' ) {
				$parts[] = $this->get_current_breadcrumb( $entity['link'], $entity['name'] );
			}
		}

		// A trail of a single crumb makes no sense - hide the element
		if ( $this->crumbs_count < 2 ) {
			return '';
		}

		$output = implode( $this->config['delimiter'], $parts );

		// Pagination "Page N" - only alongside the current page
		if (
			$this->config['show_current']
			AND $this->config['show_page_number']
			AND get_query_var( 'paged' )
		) {
			$page_num = us_translate_x( 'Page', 'post type singular name' ) . ' ' . get_query_var( 'paged' );
			$output .= sprintf( ' (%s)', $page_num );
		}

		return $output;
	}

	/**
	 * Resolve the post type of a queried object.
	 * Note: The Events Calendar overrides the `$post` global, which may contain the wrong object.
	 */
	private function detect_post_type( $queried ) {
		if ( $queried instanceof WP_Post ) {
			return $queried->post_type;
		} elseif ( $queried instanceof WP_Post_Type ) {
			return $queried->name;
		}

		return 'page';
	}

	/**
	 * Whether we're within Events Calendar archive
	 */
	private function is_events_calendar_archive() {
		if (
			function_exists( 'tribe_is_month' )
			AND function_exists( 'tribe_is_upcoming' )
			AND function_exists( 'tribe_is_past' )
			AND function_exists( 'tribe_is_day' )
		) {
			return ( tribe_is_month() OR tribe_is_upcoming() OR tribe_is_past() OR tribe_is_day() );
		}

		return FALSE;
	}

	/**
	 * SOURCE: Auto - the automatic ancestor path of the current view
	 * (categories, CPT archive, page/date parents)
	 */
	private function render_ancestors() {

		// Always show dummy ancestors in Live Preview for better UX
		if ( usb_is_preview() ) {
			return $this->get_breadcrumb( '#', us_translate( 'Parent Category' ) )
				. $this->config['delimiter']
				. $this->get_breadcrumb( '#', us_translate( 'Category' ) );
		}

		$post = get_queried_object();
		$post_type = $this->detect_post_type( $post );

		$output = '';

		// Category - parent categories
		if ( is_category() ) {
			$thisCat = get_category( get_query_var( 'cat' ), FALSE );
			if ( $thisCat->parent != 0 ) {
				$cats = get_category_parents( $thisCat->parent, TRUE, $this->config['delimiter'] );
				$output .= $this->format_term_chain( $cats );
			}

			// Day - year + month
		} elseif ( is_day() ) {
			$output .= $this->get_breadcrumb( get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) );
			$output .= $this->config['delimiter'];
			$output .= $this->get_breadcrumb( get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ), __( get_the_time( 'F' ), 'us' ) );

			// Month - year
		} elseif ( is_month() ) {
			$output .= $this->get_breadcrumb( get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ) );

			// The Events Calendar taxonomy archive - events archive link
		} elseif ( is_post_type_archive( 'tribe_events' ) AND $this->is_events_calendar_archive() AND is_tax() ) {
			$post_type_obj = get_post_type_object( 'tribe_events' );
			$output .= $this->get_breadcrumb( esc_url( tribe_get_events_link() ), $post_type_obj->labels->name );

			// Single post type
		} elseif ( is_singular() ) {

			// Portfolio Pages
			if ( $post_type == 'us_portfolio' AND us_get_option( 'portfolio_breadcrumbs_page' ) ) {

				if ( $portfolio_breadcrumbs_page = get_post( us_get_option( 'portfolio_breadcrumbs_page' ) ) ) {
					$portfolio_breadcrumbs_page_ID = $portfolio_breadcrumbs_page->ID;

					if ( has_filter( 'us_tr_object_id' ) ) {
						$portfolio_breadcrumbs_page_ID = apply_filters(
							'us_tr_object_id',
							$portfolio_breadcrumbs_page->ID,
							$portfolio_breadcrumbs_page->post_type,
							/* return_original_if_missing */ TRUE
						);
					}

					$portfolio_breadcrumbs_page_title = get_the_title( $portfolio_breadcrumbs_page_ID );
					$output .= $this->get_breadcrumb( get_permalink( $portfolio_breadcrumbs_page_ID ), $portfolio_breadcrumbs_page_title );
				}

				// Posts
			} elseif ( $post_type == 'post' ) {
				$cat = get_the_category();
				if ( $cat = us_arr_path( $cat, '0' ) ) {
					$cats = get_category_parents( $cat, TRUE, $this->config['delimiter'] );
					$output .= $this->format_term_chain( $cats );
				}

				// The Events Calendar
			} elseif ( $post_type == 'tribe_events' ) {
				$post_type_obj = get_post_type_object( $post_type );
				$output .= $this->get_breadcrumb( esc_url( tribe_get_events_link() ), $post_type_obj->labels->name );

				// Page - parent pages only (never taxonomy terms, even if a plugin registers a public taxonomy for pages)
			} elseif ( $post_type == 'page' ) {
				if ( $post->post_parent ) {
					$output .= $this->build_parent_chain( $post );
				}

				// CPT
			} else {
				$taxonomies_found = FALSE;
				$taxonomy_names = get_object_taxonomies( $post_type, 'objects' );

				if ( $taxonomy_names != NULL ) {
					foreach ( $taxonomy_names as $taxonomy_name ) {
						if ( ! $taxonomy_name->public ) {
							continue;
						}
						$post_taxonomy = get_the_terms( get_the_ID(), $taxonomy_name->name );
						if ( is_array( $post_taxonomy ) AND count( $post_taxonomy ) > 0 ) {
							$post_taxonomy = $post_taxonomy[0];
							$post_taxonomies = get_term_parents_list(
								$post_taxonomy, $taxonomy_name->name, array(
									'separator' => $this->config['delimiter'],
									'link' => TRUE,
									'format' => 'name',
								)
							);
							$output .= $this->format_term_chain( $post_taxonomies );
							$taxonomies_found = TRUE;
							break;
						}
					}
				}

				if ( ! $taxonomies_found ) {

					// Hierarchy check
					if ( $post->post_parent ) {
						$output .= $this->build_parent_chain( $post );

						// Post Type Archive check
					} elseif (
						$cpt_post_type = get_post_type_object( $post_type )
						AND $cpt_post_type->has_archive
						AND ! empty( $cpt_post_type->labels->name )
					) {
						$cpt_slug = is_string( $cpt_post_type->has_archive )
							? $cpt_post_type->has_archive
							: $cpt_post_type->name;
						$output .= $this->get_breadcrumb( get_option( 'siteurl' ) . '/' . $cpt_slug . '/', $cpt_post_type->labels->name );
					}
				}
			}

			// WooCommerce Shop page - parent pages
		} elseif ( function_exists( 'is_shop' ) AND is_shop() AND $post->post_parent ) {
			$output .= $this->build_parent_chain( $post );
		}

		return $output;
	}

	/**
	 * Build a crumbs chain of the post ancestors (top → bottom), without a trailing separator.
	 */
	private function build_parent_chain( $post ) {
		$front_page_id = (int) get_option( 'page_on_front' );

		$breadcrumbs = array();
		// get_post_ancestors() returns ancestor IDs nearest → topmost; reverse for a top → bottom trail.
		// It stops on a missing parent and guards against cyclic post_parent references on its own.
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $id ) {
			// Skip the front page
			if ( $id == $front_page_id ) {
				continue;
			}
			$breadcrumbs[] = $this->get_breadcrumb( get_permalink( $id ), get_the_title( $id ) );
		}

		return implode( $this->config['delimiter'], $breadcrumbs );
	}

	/**
	 * Show current page
	 */
	private function get_current_entity() {

		// Dummy current crumb in Live Preview
		if ( usb_is_preview() ) {
			return array( 'link' => get_permalink(), 'name' => get_the_title() );
		}

		$post = get_queried_object();
		$post_type = $this->detect_post_type( $post );

		// Posts page
		if ( is_home() ) {
			$home_page_id = get_option( 'page_for_posts' );

			return array( 'link' => get_permalink( $home_page_id ), 'name' => get_the_title( $home_page_id ) );

			// Category
		} elseif ( is_category() ) {
			return array(
				'link' => get_category_link( get_query_var( 'cat' ) ),
				'name' => single_cat_title( '', FALSE ),
			);

			// Tag
		} elseif ( is_tag() ) {
			return array(
				'link' => get_term_link( get_query_var( 'tag_id' ) ),
				'name' => single_tag_title( '', FALSE ),
			);

			// Author
		} elseif ( is_author() ) {
			global $author;
			$userdata = get_userdata( $author );
			if ( ! $userdata instanceof WP_User ) {
				return NULL;
			}

			return array( 'link' => get_author_posts_url( $userdata->ID ), 'name' => $userdata->display_name );

			// 404 page
		} elseif ( is_404() ) {
			return array( 'link' => '', 'name' => $this->config['text']['404'] );

			// Search Results
		} elseif ( is_search() ) {
			return array( 'link' => '', 'name' => $this->config['text']['search'] );

			// Day
		} elseif ( is_day() ) {
			return array(
				'link' => get_day_link( get_the_time( 'Y' ), get_the_time( 'm' ), get_the_time( 'd' ) ),
				'name' => get_the_time( 'd' ),
			);

			// Month
		} elseif ( is_month() ) {
			return array(
				'link' => get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ),
				'name' => __( get_the_time( 'F' ), 'us' ),
			);

			// Year
		} elseif ( is_year() ) {
			return array( 'link' => get_year_link( get_the_time( 'Y' ) ), 'name' => get_the_time( 'Y' ) );

			// The Events Calendar archive
		} elseif ( is_post_type_archive( 'tribe_events' ) AND $this->is_events_calendar_archive() ) {
			if ( is_tax() ) {
				return array(
					'link' => esc_url( get_term_link( get_queried_object() ) ),
					'name' => get_queried_object()->name,
				);
			} elseif ( tribe_is_month() OR tribe_is_past() OR tribe_is_upcoming() OR tribe_is_day() ) {
				$post_type_obj = get_post_type_object( 'tribe_events' );

				return array( 'link' => esc_url( tribe_get_events_link() ), 'name' => $post_type_obj->labels->name );
			}

			return NULL;

			// Single post / CPT / product
		} elseif ( is_single() ) {
			return array( 'link' => get_permalink( $post->ID ?? 0 ), 'name' => get_the_title( $post->ID ?? 0 ) );

			// WooCommerce Shop page
		} elseif ( function_exists( 'is_shop' ) AND is_shop() ) {
			return array( 'link' => '', 'name' => get_the_title() );

			// Page
		} elseif ( is_page() ) {
			return array( 'link' => get_permalink( $post->ID ), 'name' => get_the_title( $post->ID ) );

			// Any other term
		} elseif ( $post instanceof WP_Term ) {
			return array( 'link' => '', 'name' => $post->name );

			// Any other archive
		} else {
			$post_type_obj = get_post_type_object( $post_type );
			if ( isset( $post_type_obj->labels->name ) ) {
				return array( 'link' => '', 'name' => $post_type_obj->labels->name );
			}
		}

		return NULL;
	}
}
