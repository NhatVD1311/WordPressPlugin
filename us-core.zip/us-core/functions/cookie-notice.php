<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Output cookie notice bar
 */
if ( ! function_exists( 'us_cookie_notice_output' ) ) {
	// Note: the notice is output to every visitor, as page caches serve the same HTML to all of them, and is hidden
	// on the client for the visitor who decided already, see us_output_privacy_script() and _general.js
	if ( in_array( us_get_option( 'cookie_consent_mode', 'none' ), array( 'notice', 'consent' ) ) ) {
		add_action( 'wp_footer', 'us_cookie_notice_output', 90 );
	}

	function us_cookie_notice_output() {

		// Do nothing since AMP-consent works only via SSL
		if ( us_amp() AND ! is_ssl() ) {
			return FALSE;
		}

		$output = '';

		$is_consent = ( us_get_option( 'cookie_consent_mode', 'none' ) == 'consent' );

		$cookie_message = us_get_option( 'cookie_message', '' );

		// Add link to Privacy Policy page, WordPress gives it only for the page published in Settings > Privacy
		if (
			! empty( us_get_option( 'cookie_privacy' ) )
			AND $privacy_policy_link = get_the_privacy_policy_link()
		) {
			// The page opens in a new tab, so the visitor can decide on the notice after reading it
			$cookie_message .= ' ' . str_replace( '<a ', '<a target="_blank" ', $privacy_policy_link );
		}

		// Output bar, only if the message is not empty, the notice with Accept and Reject is output anyway,
		// as the visitor can't accept without it
		if ( $cookie_message OR $is_consent ) {

			// Use specific component for AMP https://amp.dev/documentation/components/amp-consent/
			if ( us_amp() ) {
				$consent_data = array(
					'consentInstanceId' => 'us_cookie_notice_check_consent',
					'promptUI' => 'us_cookie_ui',
					'consentRequired' => TRUE,
					'onUpdateHref' => add_query_arg( 'action', 'us_cookie_set_amp_cookie', admin_url( 'admin-ajax.php' ) ),
				);
				$output .= '<amp-consent id="us_cookie" layout="nodisplay">';
				$output .= '<script type="application/json">';
				$output .= wp_json_encode( $consent_data );
				$output .= '</script>';
				$output .= '<div id="us_cookie_ui" class="l-cookie pos_' . us_get_option( 'cookie_message_pos', 'bottom' ) . ' ">';
				if ( $cookie_message ) {
					$output .= '<div class="l-cookie-message">' . $cookie_message . '</div>';
				}

				// Reject button
				if ( $is_consent ) {
					$output .= '<button type="button" on="tap:us_cookie.reject" class="w-btn ' . us_get_btn_class( us_get_option( 'cookie_reject_btn_style', '1' ) ) . '">';
					$output .= '<span>' . strip_tags( us_get_option( 'cookie_reject_btn_label', __( 'Reject', 'us' ) ) ) . '</span>';
					$output .= '</button>';
				}

				// Accept button
				$output .= '<button type="button" on="tap:us_cookie.accept" class="w-btn ' . us_get_btn_class( us_get_option( 'cookie_btn_style', '1' ) ) . '">';
				$output .= '<span>' . strip_tags( us_get_option( 'cookie_btn_label', __( 'Accept', 'us' ) ) ) . '</span>';
				$output .= '</button>';

				$output .= '</div>';
				$output .= '</amp-consent>';

			} else {
				// The "for_consent" class tells _general.js to store "accepted" or "rejected" instead of "true"
				$output .= '<div class="l-cookie pos_' . us_get_option( 'cookie_message_pos', 'bottom' ) . ( $is_consent ? ' for_consent' : '' ) . '">';
				if ( $cookie_message ) {
					$output .= '<div class="l-cookie-message">' . $cookie_message . '</div>';
				}

				// Reject button, in the mode with the blocked content only, as there is nothing to reject otherwise
				if ( $is_consent ) {
					$reject_btn_params = array(
						'html_atts' => array(
							'class' => 'w-btn ' . us_get_btn_class( us_get_option( 'cookie_reject_btn_style', '1' ) ),
							'id' => 'us-reject-cookie',
						),
						'label' => us_get_option( 'cookie_reject_btn_label', __( 'Reject', 'us' ) ),
					);

					$reject_btn_params['html_atts'] = apply_filters( 'us_cookie_notice_reject_btn_atts', $reject_btn_params['html_atts'] );

					$output .= us_get_btn( $reject_btn_params );
				}

				$btn_params = array(
					'html_atts' => array(
						'class' => 'w-btn ' . us_get_btn_class( us_get_option( 'cookie_btn_style', '1' ) ),
						'id' => 'us-set-cookie',
					),
					'label' => us_get_option( 'cookie_btn_label', __( 'Accept', 'us' ) ),
				);

				$btn_params['html_atts'] = apply_filters( 'us_cookie_notice_btn_atts', $btn_params['html_atts'] );

				$output .= us_get_btn( $btn_params );

				$output .= '</div>';
			}
		}

		echo $output;
	}
}

if ( ! function_exists( 'us_output_privacy_script' ) ) {
	add_action( 'wp_head', 'us_output_privacy_script' );

	/**
	 * Hide the notice and the privacy blocks for the visitor who decided already, before the page is shown
	 *
	 * The decision is checked on the client, as page caches serve the same HTML to all visitors, so without this
	 * script the notice and the "Load" placeholders would blink until _general.js and the elements scripts run.
	 * Note: the notice with Accept and Reject is hidden by its own values only, as the "true" of the informing notice
	 * is not the consent, see $ush.isLoadConfirmed()
	 */
	function us_output_privacy_script() {
		$cookie_consent_mode = us_get_option( 'cookie_consent_mode', 'none' );
		if ( $cookie_consent_mode == 'none' OR us_amp() ) {
			return;
		}
		?>
		<script id="us_privacy_style">
			!function( cookie, rules ) {
				var blocks = [];
				if ( /; us_cookie_notice_accepted=<?= ( $cookie_consent_mode == 'consent' ) ? '(accepted|rejected)' : '' ?>/.test( cookie ) ) {
					rules.push( ".l-cookie{display:none!important}" );
				}
				if ( /; us_cookie_notice_accepted=accepted/.test( cookie ) ) {
					blocks.push( ".confirm_by_notice" );
				}
				cookie.replace( /; (\w+_load_confirmed)=/g, function( _, name ) {
					blocks.push( '[data-cookie-name="' + name + '"]' );
				} );
				blocks.forEach( function( block ) {
					rules.push( block + " .w-video-privacy," + block + " .w-map-privacy{visibility:hidden}" );
				} );
				if ( rules.length ) {
					var style = document.createElement( "style" );
					style.textContent = rules.join( "" );
					document.head.appendChild( style );
				}
			}( "; " + document.cookie, [] );
		</script>
		<?php
	}
}
