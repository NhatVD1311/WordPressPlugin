<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Theme Options: USOF + UpSolution extendings
 *
 * Should be included in global context.
 */

add_action( 'usof_after_save', 'us_generate_asset_files', 10, 2 );
add_action( 'usof_ajax_mega_menu_save_settings', 'us_generate_asset_files' );
add_action( 'update_option_siteurl', 'us_generate_asset_files' );
add_action( 'update_option_home', 'us_generate_asset_files' );

if ( ! function_exists( 'us_exclude_magnific_popup_asset' ) ) {

	add_filter( 'us_config_assets', 'us_exclude_magnific_popup_asset' );

	/**
	 * Exclude the Magnific Popup CSS component from:
	 * front-end enqueue, generated assets files, Auto Optimize checkboxes table.
	 * Note: the explicit default in us_get_option() avoids usof_defaults() -> us_config() recursion
	 *
	 * @param array $config
	 * @return array
	 */
	function us_exclude_magnific_popup_asset( $config ) {
		if ( ! us_get_option( 'enable_magnific_popup', 1 ) ) {
			unset( $config['magnific_popup'] );
		}
		return $config;
	}
}

/**
 * Generate the CSS and JS files of the "Optimize assets" option, or the CSS of the Theme Options without it
 *
 * Note: the JS file is a join of the components of the "assets" config, so it changes with a few options only,
 * and it is left as it is when the "usof_after_save" action says none of them changed, see usof_save_options().
 * The CSS file has the values of most of the options in it, so it is always regenerated
 *
 * @param mixed $updated_options The new options on "usof_after_save", whatever the other actions pass otherwise
 * @param array $changed_options The options, which values changed, when they are known
 */
function us_generate_asset_files( $updated_options = NULL, $changed_options = NULL ) {

	// The options, which the JS file depends on: the components and the assets added by the options, see us_generate_asset_file()
	// Note: the "us_config_assets" filters read "enable_magnific_popup", but that component has no JS
	$js_options = array(
		'optimize_assets',
		'assets',
		'ripple_effect',
	);
	$generate_js = (
		! is_array( $changed_options )
		OR array_intersect_key( $changed_options, array_flip( $js_options ) )
	);

	$subdomains = array();
	// Empty array without code for default language
	$language_domains[] = '';

	// Is WPML installed and activated
	if ( class_exists( 'SitePress' ) AND has_filter( 'us_tr_setting' ) ) {
		$default_lang = apply_filters( 'us_tr_default_language', NULL );
		// get negotiation type, '2' is different domain per language
		$language_negotiation_type = apply_filters( 'us_tr_setting', 'language_negotiation_type', FALSE );

		// Create extra styles and js only if selected different domain per language negotiation type
		if ( ! empty( $default_lang ) AND $language_negotiation_type == '2' ) {
			$language_domains = array_merge( $language_domains, apply_filters( 'us_tr_setting', 'language_domains', array() ) );
		}
	}

	// Support for subdomain asset files for Polylang
	if ( function_exists( 'pll_languages_list' ) ) {
		$default_lang = apply_filters( 'us_tr_default_language', NULL );
		$pll_domains = apply_filters( 'us_tr_setting', 'domains', array() );

		// get negotiation type, 3 is different domain per language
		$language_negotiation_type = apply_filters( 'us_tr_setting', 'force_lang', 0 );

		if ( $language_negotiation_type == 3 ) {
			foreach ( $pll_domains as $pll_key => $pll_domain ) {
				// Remove protocols for consistency
				$pll_domains[ $pll_key ] = preg_replace( '#^https?://#', '', $pll_domain );

				if ( $pll_key == $default_lang ) {
					// Remove default domain for consistency
					$pll_domains[ $pll_key ] = '';
				}
			}

			$language_domains = $pll_domains;
		}
	}

	foreach ( $language_domains as $custom_language_domain ) {

		// Temporarily replacing template directory URI for CSS file for custom language domain
		if ( $custom_language_domain != '' ) {
			global $us_template_directory_uri;

			// Generating URL of custom language domain
			$custom_language_domain_url = '';
			if ( us_get_option( 'keep_url_protocol', 1 ) ) {
				$custom_language_domain_url .= is_ssl() ? 'https:' : 'http:';
			}
			$custom_language_domain_url .= '//' . $custom_language_domain;

			// Getting URL for main language domain
			$main_language_domain_url = get_site_url();

			// Storing template directory URI in temporary variable
			$default_us_template_directory_uri = $us_template_directory_uri;

			// Replacing main language domain with custom one in template directory URI
			$us_template_directory_uri = str_replace( $main_language_domain_url, $custom_language_domain_url, $us_template_directory_uri );
		}

		us_generate_asset_file( 'css', $custom_language_domain );
		if ( $generate_js ) {
			us_generate_asset_file( 'js', $custom_language_domain );
		}

		// Restoring original template directory URI
		if ( $custom_language_domain != '' ) {
			$us_template_directory_uri = $default_us_template_directory_uri;
		}
	}

	us_generate_editor_styles();
}

/**
 * Regenerate asset files once after the "US Core" version changes
 *
 * Note: front-end requests do it as well, as a site with the scheduled tasks off, whose
 * admin doesn't log in after an update, would otherwise keep the files of the old version
 * for good — the missing-file fallback of the enqueue only covers their absence
 */
add_action( 'init', 'us_regenerate_assets_on_version_change' );
function us_regenerate_assets_on_version_change() {
	if ( ! defined( 'US_CORE_VERSION' ) ) {
		return;
	}

	if ( wp_doing_ajax() ) {
		return;
	}

	if ( get_option( 'us_assets_generated_version' ) === US_CORE_VERSION ) {
		return;
	}

	us_generate_asset_files();
	update_option( 'us_assets_generated_version', US_CORE_VERSION, /* autoload */TRUE );
}

/* Get asset file path */
function us_get_asset_file( $ext, $url = FALSE, $custom_language_domain = '' ) {
	if ( empty( $ext ) ) {
		return FALSE;
	}

	// Set specific file name for editor styles
	if ( $ext == 'tinymce' ) {
		$file_name = 'tinymce-editor-style';
		$ext = 'css';

	} elseif ( $ext == 'gutenberg' ) {
		$file_name = 'gutenberg-editor-style';
		$ext = 'css';

		// Set specific file name for locally stored Google Fonts
	} elseif ( $ext == 'gfonts' ) {
		$file_name = 'google-fonts';
		$ext = 'css';

		// Set file name based on site name
	} else {
		$site_url_parts = wp_parse_url( site_url() );
		$file_name = ( ! empty( $site_url_parts['host'] ) ) ? $site_url_parts['host'] : '';
		$file_name .= ( ! empty( $site_url_parts['path'] ) ) ? str_replace( '/', '_', $site_url_parts['path'] ) : '';
	}

	$file = '';
	$upload_dir = wp_get_upload_dir();

	if ( $url ) {
		$file = $upload_dir['baseurl'] . '/us-assets/' . $file_name . '.' . $ext;
		// remove protocols for better compatibility with caching plugins and services
		if ( ! us_get_option( 'keep_url_protocol' ) ) {
			$file = str_replace( array( 'http:', 'https:' ), '', $file );
		}
	} else {
		// Create file directory
		$file_dir = wp_normalize_path( $upload_dir['basedir'] . '/us-assets' );
		if ( ! is_dir( $file_dir ) ) {
			wp_mkdir_p( trailingslashit( $file_dir ) );
		}
		//check is this file for custom domain
		$file_name = ! empty( $custom_language_domain ) ? $custom_language_domain : $file_name;
		$file = trailingslashit( $file_dir ) . $file_name . '.' . $ext;
	}

	return $file;
}

/**
 * Generate main FRONTEND assets (JS or CSS)
 *
 * @param string $ext file type (JS/CSS)
 * @param string $custom_language_domain
 * @return bool whether file was successfully created
 */
function us_generate_asset_file( $ext, $custom_language_domain = '' ) {
	if ( empty( $ext ) ) {
		return FALSE;
	}

	global $usof_options, $us_template_directory;
	usof_load_options_once();

	if ( us_arr_path( $usof_options, 'optimize_assets', FALSE ) ) {
		$content = $first_content = '';

		// Add assets specified in Theme Options
		// Note: the config is rebuilt, as its "us_config_assets" filters read the options, which may have been
		// changed by the very save this generation belongs to, see us_exclude_magnific_popup_asset()
		$assets_config = us_config( 'assets', array(), /* reload */TRUE );
		$icon_css_files = array();
		foreach ( $assets_config as $component => $component_atts ) {

			// Skip assets that have no files for the current file extension
			if ( empty( $component_atts[ $ext ] ) ) {
				continue;
			}

			// Include asset's files if it is included by default or checked by user in Theme Options
			if (
				! empty( $component_atts['include_if'] )
				OR ! isset( $usof_options['assets'] )
				OR ! isset( $usof_options['assets'][ $component ] )
				OR $usof_options['assets'][ $component ] == 1
			) {
				$asset_filename = $us_template_directory . $component_atts[ $ext ];
				if ( $ext == 'js' ) {
					$asset_filename = str_replace( '.js', '.min.js', $asset_filename );
				}

				// Move assets to the top of generated file if set
				if ( ! empty( $component_atts['include_first'] ) ) {
					$first_content .= file_get_contents( $asset_filename );
					$first_content .= ( $ext == 'js' ) ? ';' : '';
				} else {
					$content .= file_get_contents( $asset_filename );
					$content .= ( $ext == 'js' ) ? ';' : '';
				}
			}

			// Get icon CSS files which used for generating icons styles AND disabled in Theme Options
			if ( ! empty( $component_atts['search_icons'] ) AND empty( $usof_options['assets'][ $component ] ) ) {
				$icon_css_files[ $component ] = us_arr_path( $component_atts, 'css' );
			}
		}

		// Combine first content with other
		$content = $first_content . $content;

		// Add "Ripple Effect" assets separately, if option is enabled
		if ( $usof_options['ripple_effect'] ) {
			$min = ( $ext == 'js' ) ? 'min.' : '';
			$content .= file_get_contents( $us_template_directory . '/common/' . $ext . '/base/ripple.' . $min . $ext );
		}

		// For CSS
		if ( $ext == 'css' ) {

			// Prepend Google Fonts styles, so they are not loaded by a separate render-blocking request

			/**
			 * Fonts are stored locally: take their styles from the file, without any remote request
			 *
			 * Note: the read itself is the check of the file, as us_reset_local_google_fonts()
			 * drops it on the very save this generation belongs to
			 */
			if (
				! empty( $usof_options['store_gfonts_locally'] )
				AND $local_gfonts_css = @file_get_contents( us_get_asset_file( 'gfonts' ) )
			) {
				$content = $local_gfonts_css . $content;

				/**
				 * The fonts are not stored locally, so their styles are taken from Google
				 *
				 * Note: with the "Store Google Fonts locally" option on this is skipped, as the styles refer
				 * to the Google servers and the visitors would request the fonts from there — the front-end
				 * shows the fallback fonts until the local copy is ready
				 */
			} elseif (
				empty( $usof_options['store_gfonts_locally'] )
				AND $gfont_file_url = us_enqueue_google_fonts( /* return url */TRUE, /* remote */TRUE )
			) {
				if ( $gfonts_css = us_get_google_fonts_remote_file( $gfont_file_url ) ) {
					$content = $gfonts_css . $content;
				} else {
					$gfonts_css_merge_failed = TRUE;
				}
			}

			// If the styles couldn't be taken from Google, the front-end loads them separately (see enqueue.php),
			// otherwise the site would show the fallback fonts until the next generation
			// Note: the option is kept with 0 instead of deleting, so reading it takes no extra DB query
			update_option( 'us_gfonts_css_merge_failed', empty( $gfonts_css_merge_failed ) ? 0 : 1, /* autoload */TRUE );

			// add theme-options styles
			delete_option( 'us_theme_options_css' );
			$content .= us_get_template( 'templates/css-theme-options' );

			// add user custom styles
			if ( $us_custom_css = us_get_option( 'custom_css' ) ) {
				$content .= $us_custom_css;
			}

			// Add styles of only USED ICONS from Font Awesome CSS files
			if (
				! empty( $icon_css_files )
				AND $used_icons = US_Get_Used_Icons::get_data( 'icons' )
			) {
				$icons_css = array();
				foreach ( $icon_css_files as $fonticon_name => $filepath ) {

					// Pattern for extracting all icons from a CSS file
					$_pattern = '/((\.fad)?\.fa-([\w\-\_]+):([before|after]+){([^\}]+)})/';
					if (
						$file_content = file_get_contents( $us_template_directory . $filepath )
						AND preg_match_all( $_pattern, $file_content, $matches )
					) {
						$keys = array_flip( $matches[3] );
						$icons_styles = $matches[0];

						foreach ( $used_icons as $icon ) {
							if ( strpos( $icon, '|' ) === FALSE ) {
								continue;
							}

							// Get the icon_set and icon_name of the icon
							$_icon = explode( '|', $icon, 2 );
							array_map( 'trim', $_icon );
							list( $icon_set, $icon_name ) = $_icon;

							// Skip "material" icons, because they don't need css styles
							if ( $icon_set === 'material' ) {
								continue;
							}

							// Skip Font Awesome Kit icons — the kit loader delivers them, they don't need
							// the theme's FA5 CSS; the by-name lookup below would otherwise inject FA5
							// rules for kit icon names that also exist in fontawesome.css
							if ( strpos( $icon_set, 'fakit-' ) === 0 ) {
								continue;
							}

							// Skip fallback icons for Solid, Regular, Light icon sets
							if ( in_array(
									$icon_set, array(
										'fas',
										'far',
										'fal',
									)
								) AND us_is_fallback_icon( $icon_name ) ) {
								continue;
							}

							// Skip "font-awesome-duotone.css" file, if the icon is not "Duotone"
							if ( $icon_set !== 'fad' AND $fonticon_name == 'font-awesome-duotone' ) {
								continue;
							}

							// Skip "Duotone" icons styles, if they don't exist (in Zephyr theme) or if "Font Awesome Duotone" set is disabled
							if (
								$icon_set === 'fad'
								AND (
									! isset( $usof_options['icons_fad'] )
									OR $usof_options['icons_fad'] == 'none'
								)
							) {
								continue;
							}

							// Add css code for every used icon, which exists in CSS file
							if ( isset( $keys[ $icon_name ] ) ) {
								$icon_index = $keys[ $icon_name ];
								$icons_css[] = $icons_styles[ $icon_index ];
							}
						}

						unset( $keys, $icons_styles );
					}
				}

				// Add used icons styles to main file
				if ( $icons_css ) {
					$icons_css = array_unique( $icons_css );
					$content .= implode( '', $icons_css );
				}
			}

			// minify
			$content = us_minify_css( $content );
		}

		// Break if content is empty
		if ( empty( $content ) ) {
			return FALSE;
		}

		// Locate asset file
		$file = us_get_asset_file( $ext, FALSE, $custom_language_domain );

		// Generate file in directory
		if (
			(
				// First check if the file is not created yet ...
				! file_exists( $file )
				// ... or if it is created and writeable ...
				OR (
					is_writable( $file )
					AND is_file( $file )
				)
			)
			// ... then try to open it ...
			AND $handle = fopen( $file, 'w' )
		) {
			// ... and try to write contents to it
			if ( ! fwrite( $handle, $content ) ) {
				return FALSE;
			}
			fclose( $handle );

			return TRUE;
		}

		return FALSE;

	} elseif ( $ext == 'css' ) {
		update_option( 'us_theme_options_css', us_minify_css( us_get_template( 'templates/css-theme-options' ) ), /* autoload */TRUE );
	}

	return FALSE;
}

/**
 * Request a file from the Google Fonts servers
 *
 * Note: the browser user agent is required, as Google returns the modern styles (Variable
 * Fonts in woff2) to modern browsers only, while the default WordPress one gets static ttf
 *
 * @param string $url The URL of the styles or of a single font file
 * @param int $timeout The amount of seconds the request may take
 * @return string|bool The response body, or FALSE when the request failed
 */
function us_get_google_fonts_remote_file( $url, $timeout = 15 ) {
	$response = wp_remote_get(
		$url, array(
			'timeout' => $timeout,
			'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
		)
	);

	if ( is_wp_error( $response ) OR wp_remote_retrieve_response_code( $response ) != 200 ) {
		return FALSE;
	}

	return wp_remote_retrieve_body( $response );
}

/**
 * Get the state of the locally stored Google Fonts: where they are kept, which set of them
 * the site uses now, and whether the stored styles belong to that very set
 *
 * Note: the writer and the readers of a stored set must agree on the paths, on the marker
 * and on the way the two are compared, so all of it is defined in this single place
 *
 * @return array The "file", "dir" and "marker" values, the "remote_url" of the used set,
 *               which is FALSE when nothing is to be stored, and the "is_current" flag
 */
function us_get_local_google_fonts_state() {
	$file = us_get_asset_file( 'gfonts' );

	/**
	 * The URL of the set the site uses now: FALSE both when the option is off and when the
	 * Typography settings use no Google Font at all, as nothing is to be stored either way
	 */
	$remote_url = us_get_option( 'store_gfonts_locally', /* default */0 )
		? us_enqueue_google_fonts( /* return url */TRUE, /* remote */TRUE )
		: FALSE;

	$dir = dirname( $file ) . '/google-fonts';
	$marker = '/*' . md5( (string) $remote_url ) . '*/';

	/**
	 * The stored styles begin with the marker of the set they were downloaded for
	 *
	 * Note: only the first bytes of the file are read, as it may weigh hundreds of kilobytes
	 * while the marker is a few dozen of them
	 *
	 * Note: the directory of the font files is required as well, as the styles alone are of
	 * no use — a set whose files were removed by hand, by a cleanup plugin or by a migration
	 * has to be downloaded anew, and the styles are never stored without at least one file
	 */
	$is_current = FALSE;
	if ( $remote_url AND is_dir( $dir ) AND $handle = @fopen( $file, 'rb' ) ) {
		$is_current = ( fread( $handle, strlen( $marker ) ) === $marker );
		fclose( $handle );
	}

	return array(
		'file' => $file,
		'dir' => $dir,
		'marker' => $marker,
		'remote_url' => $remote_url,
		'is_current' => $is_current,
	);
}

/**
 * Remove the stored font files, except the ones that are still in use
 *
 * @param string $dir The directory of the stored font files
 * @param array $keep_names The names of the files to keep, as keys
 */
function us_remove_local_google_fonts_files( $dir, $keep_names = array() ) {
	foreach ( glob( $dir . '/*' ) ?: array() as $stored_file ) {
		if ( ! isset( $keep_names[ basename( $stored_file ) ] ) ) {
			@unlink( $stored_file );
		}
	}
}

/**
 * Download the used Google Fonts styles and font files into the "uploads/us-assets" directory
 *
 * Note: only the url() values of the Google styles are changed, so all the Variable Fonts
 * settings (weight and width ranges, italic, optical size and other axes) keep working
 *
 * The styles file is written only after all the font files are downloaded, so the site always
 * uses a complete set of fonts, while an interrupted download continues from the same place
 *
 * @return array|bool The amounts of the remaining and of all the font files, or FALSE on failure
 */
function us_download_local_google_fonts() {
	$result = array( 'remaining' => 0, 'total' => 0 );

	/**
	 * The call works within a time budget and leaves the rest of the files to the next one,
	 * so that neither a large set of fonts nor a weak server can make a single request run
	 * into the "max_execution_time" of PHP
	 *
	 * Note: 0 means no limit at all, and even such a server is given a budget, so that the
	 * page waiting for the answer receives it in a reasonable time
	 */
	$time_limit = (int) ini_get( 'max_execution_time' );
	$started_at = microtime( TRUE );

	$state = us_get_local_google_fonts_state();

	/**
	 * Nothing is to be downloaded: the option is off, the site uses no Google Fonts, or the
	 * very same set is already stored, as only a changed set is downloaded anew
	 */
	if ( ! $state['remote_url'] OR $state['is_current'] ) {
		return $result;
	}

	/**
	 * The "downloading" state is stored before any remote request, as this very call may be
	 * killed in the middle of the work: a download that never reported a complete set is an
	 * unfinished one, and the options page continues it as soon as it finds this state
	 */
	update_option( 'us_gfonts_download_state', 'downloading', /* autoload */TRUE );

	if ( ! $css = us_get_google_fonts_remote_file( $state['remote_url'] ) ) {
		return FALSE;
	}

	/**
	 * Only woff2 files are returned for modern browsers, so their absence means a legacy
	 * answer with static fonts instead of Variable ones: such styles must not be stored
	 */
	if ( ! preg_match_all( '~url\((https://fonts\.gstatic\.com/[^)\'"]+\.woff2)\)~', $css, $matches ) ) {
		return FALSE;
	}

	wp_mkdir_p( $state['dir'] );

	$font_urls = array_unique( $matches[1] );
	$result['total'] = count( $font_urls );

	$downloaded = 0;
	$stored_names = array();

	foreach ( $font_urls as $font_url ) {

		/**
		 * The URL hash keeps the names unique, as the file name alone does not: it is the
		 * last part of a versioned per-family path, and two of them may well match
		 */
		$file_name = substr( md5( $font_url ), 0, 8 ) . '-'
			. sanitize_file_name( basename( (string) wp_parse_url( $font_url, PHP_URL_PATH ) ) );
		$font_file = $state['dir'] . '/' . $file_name;
		$stored_names[ $file_name ] = TRUE;

		if ( ! file_exists( $font_file ) ) {

			// The time the call may still spend on requests, with a reserve for the rest of it
			$time_left = ( $time_limit > 0 ? $time_limit : 60 ) - ( microtime( TRUE ) - $started_at ) - 5;

			/**
			 * The part is over, so the rest of the files are downloaded by the next call: it
			 * holds a limited amount of them, which keeps every request short and the progress
			 * on the page moving, and ends earlier when the time budget is spent
			 *
			 * Note: at least one file is taken by every call, however small the budget is, as
			 * a call that downloads nothing would make the page repeat it for good
			 */
			if ( $downloaded >= 20 OR ( $downloaded AND $time_left < 5 ) ) {
				$result['remaining']++;
				continue;
			}

			/**
			 * The file is written under a temporary name and renamed when complete, so that an
			 * interrupted download never leaves a partial file that the next call would take
			 * for a stored one
			 */
			$temp_file = $font_file . '.tmp';
			$font_content = us_get_google_fonts_remote_file( $font_url, min( 15, max( 5, $time_left ) ) );
			if (
				$font_content === FALSE
				OR file_put_contents( $temp_file, $font_content ) !== strlen( $font_content )
				OR ! rename( $temp_file, $font_file )
			) {
				@unlink( $temp_file );

				return FALSE;
			}
			$downloaded++;
		}

		/**
		 * The relative path is resolved against the styles file itself, so it stays correct
		 * for http/https, domain changes, merged CSS and per-domain files of WPML and Polylang
		 */
		$css = str_replace( $font_url, 'google-fonts/' . $file_name, $css );
	}

	/**
	 * The styles are written only when every file they refer to is stored, so a partial set
	 * is never used: until then the front-end shows the fallback fonts
	 */
	if ( $result['remaining'] ) {
		return $result;
	}

	/**
	 * Every link of the stored styles must lead to a local file: one that has stayed on the
	 * Google servers would be requested by the browsers of the visitors, which is exactly
	 * what the option is there to prevent, so such a set is not stored at all
	 */
	if ( strpos( $css, 'fonts.gstatic.com' ) !== FALSE ) {
		return FALSE;
	}

	$content = $state['marker'] . $css;
	if ( file_put_contents( $state['file'], $content ) !== strlen( $content ) ) {
		@unlink( $state['file'] );

		return FALSE;
	}

	// Remove the files of the previous sets, which the stored styles don't refer to any more
	us_remove_local_google_fonts_files( $state['dir'], $stored_names );

	// Note: the generated CSS file includes the fonts styles, so it is updated as well, the JS file doesn't depend on them
	if ( us_get_option( 'optimize_assets' ) ) {
		us_generate_asset_files( /* updated_options */NULL, /* changed_options */array( 'store_gfonts_locally' => 1 ) );
	}

	return $result;
}

/**
 * Reset the locally stored Google Fonts on saving the Theme Options
 *
 * The stored styles are the ones that get loaded whenever their file exists, so keeping an
 * outdated set would show the fonts of the previous Typography settings: the file is dropped
 * here, and the new set is downloaded by the requests the options page sends right after
 *
 * Note: the merged CSS carries its own copy of the stored styles, so it has to be rebuilt —
 * on "usof_after_save" that is done by us_generate_asset_files() of the next priority, which
 * is why this one is hooked with the lower 9
 */
add_action( 'usof_after_save', 'us_reset_local_google_fonts', 9 );
function us_reset_local_google_fonts() {

	// The stored state is the one of the previous set, which is about to be downloaded anew
	delete_option( 'us_gfonts_download_state' );

	$state = us_get_local_google_fonts_state();

	/**
	 * Nothing is to be stored any more: the option is off, or the Typography settings use no
	 * Google Font at all, so the whole stored set is of no use and only takes the disk space
	 */
	if ( ! $state['remote_url'] ) {
		if ( file_exists( $state['file'] ) OR is_dir( $state['dir'] ) ) {
			@unlink( $state['file'] );
			us_remove_local_google_fonts_files( $state['dir'] );
			@rmdir( $state['dir'] );
		}

		return;
	}

	// The same set of fonts is already stored, so it keeps being used as it is
	if ( $state['is_current'] ) {
		return;
	}

	/**
	 * The set has changed, so its styles are dropped, while the font files are kept: the ones
	 * the new set uses as well are taken from the disk instead of being downloaded anew, and
	 * the rest are removed by us_download_local_google_fonts() on storing the new styles
	 */
	@unlink( $state['file'] );
}

/**
 * Download a part of the font files, until the options page reports no remaining ones
 *
 * The download is split into parts, so that neither a large set of fonts nor a weak server
 * can make a single request take too long
 *
 * Note: the fonts follow the Typography settings, so the options page calls this after every
 * save, and continues an unfinished download on every load; nothing else does, so a download
 * that keeps failing leaves the site on the fallback fonts, with its message on the page
 */
add_action( 'wp_ajax_us_download_gfonts', 'us_ajax_download_gfonts' );
function us_ajax_download_gfonts() {
	if (
		! current_user_can( 'manage_options' )
		OR ! check_ajax_referer( 'usof-actions', '_wpnonce', /* die */FALSE )
	) {
		wp_send_json_error(
			array(
				'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
			)
		);
	}

	$result = us_download_local_google_fonts();

	if ( $result === FALSE ) {
		update_option( 'us_gfonts_download_state', 'failed', /* autoload */TRUE );

		wp_send_json_error(
			array(
				'message' => us_arr_path( us_get_gfonts_messages(), 'failed' ),
			)
		);
	}

	// The whole set is stored now, or there was nothing to store at all
	if ( empty( $result['remaining'] ) ) {
		delete_option( 'us_gfonts_download_state' );
	}

	wp_send_json_success( $result );
}

/**
 * Texts of the locally stored Google Fonts states, shown in the Theme Options header
 *
 * Note: all of them are defined here, as they are used both by the options page markup and
 * by the answers of the download requests
 *
 * @return array
 */
function us_get_gfonts_messages() {
	return array(
		'downloading' => __( 'Downloading Google Fonts', 'us' ),
		'done' => __( 'All used Google Fonts are now stored on your site.', 'us' ),
		'failed' => __( 'Google Fonts could not be downloaded. Please reload the page and save the options again.', 'us' ),
	);
}

/* Generate 2 CSS files, for Gutenberg and for TinyMCE */
function us_generate_editor_styles() {
	foreach ( array( 'tinymce', 'gutenberg' ) as $editor ) {

		// Get styles from the template
		$content = us_get_template( 'templates/css-editor-style', array( 'editor' => $editor ) );

		// Minify styles
		$content = us_minify_css( $content );

		// Break if content is empty
		if ( empty( $content ) ) {
			return FALSE;
		}

		// Locate asset file
		$file = us_get_asset_file( $editor );

		// Generate file in directory
		if (
			(
				// First check if the file is not created yet ...
				! file_exists( $file )
				// ... or if it is created and writeable ...
				OR (
					is_writable( $file )
					AND is_file( $file )
				)
			)
			// ... then try to open it ...
			AND $handle = fopen( $file, 'w' )
		) {
			if ( ! fwrite( $handle, $content ) ) {
				return FALSE;
			}
			fclose( $handle );
		} else {
			return FALSE;
		}
	}

	return TRUE;
}

// Flushing WP rewrite rules on portfolio slug changes
add_action( 'usof_after_save', 'us_maybe_flush_rewrite_rules', 10, 2 );
function us_maybe_flush_rewrite_rules( $updated_options, $changed_options = array() ) {

	// The options, which the portfolio rewrite rules are made of, see functions/post-types.php
	$rewrite_options = array(
		'enable_portfolio',
		'portfolio_slug',
		'portfolio_category_slug',
		'portfolio_tag_slug',
		'portfolio_slug_ignore_prefix',
	);
	if ( array_intersect_key( (array) $changed_options, array_flip( $rewrite_options ) ) ) {
		// The rules are flushed at the next request, when the post type is registered with the new slug,
		// see functions/post-types.php
		update_option( 'us_flush_rules', TRUE, /* autoload */TRUE );
	}
}

// Allow to change Site Icon via Theme Options page
add_action( 'usof_after_save', 'us_update_site_icon_from_options' );
function us_update_site_icon_from_options( $updated_options ) {
	if ( isset( $updated_options['site_icon'] ) AND $updated_options['site_icon'] != get_option( 'site_icon' ) ) {
		update_option( 'site_icon', $updated_options['site_icon'] );
	}
}

// Get Site Icon to display on Theme Options page
add_filter( 'usof_load_options_once', 'us_get_site_icon_for_options' );
function us_get_site_icon_for_options( $usof_options ) {
	$wp_site_icon = get_option( 'site_icon' );

	$usof_options['site_icon'] = $wp_site_icon;

	return $usof_options;
}

// Replace WP logo with Site Icon on wp-login screen
if ( ! function_exists( 'us_replace_login_logo' ) ) {
	add_action( 'login_head', 'us_replace_login_logo' );
	function us_replace_login_logo() {
		$site_icon_url = get_site_icon_url( 150 ); // returns thumbnail size

		// Replace icon specified in White Label settings
		if ( us_get_option( 'white_label' ) AND $white_label_icon = us_get_option( 'white_label_login_icon' ) ) {
			// DEV: old values keep the image size after a vertical bar, like "123|full",
			// which WordPress 7.1 no longer casts to the leading ID on its own
			$white_label_icon = us_replace_dynamic_value( $white_label_icon, /* acf_format */ FALSE, /* single_id */ TRUE );
			$site_icon_url = wp_get_attachment_image_url( $white_label_icon, 'medium' );
		}

		if ( empty( $site_icon_url ) ) {
			return;
		}

		echo '<style>
		.login h1 a {
			background-image: url(' . $site_icon_url . ') !important;
			background-size: contain !important;
			width: auto !important;
			}
		</style>';
	}
}

// Replace "wordpress.org" link on wp-login screen (when it has a custom icon)
if ( ! function_exists( 'us_replace_login_logo_url' ) ) { 
	if ( get_site_icon_url() ) {
		add_filter( 'login_headerurl', 'us_replace_login_logo_url' );
	}
	function us_replace_login_logo_url() {
		return home_url();
	}
}

// Using USOF for theme options
$usof_directory = US_CORE_DIR . 'usof';
require $usof_directory . '/usof.php';

// Exclude pages that are set as Search results / Posts page / 404 not found
add_action( 'pre_get_posts', 'us_exclude_special_pages_from_search' );
function us_exclude_special_pages_from_search( $query ) {
	if ( $query->is_search && $query->is_main_query() ) {
		$special_pages = array();
		$special_pages_names = array( 'search_page', 'page_404' );
		foreach ( $special_pages_names as $special_page_name ) {
			$special_page_id = (int) us_get_option( $special_page_name, 'default' );
			if ( $special_page_id != 'default' AND $special_page_id > 0 ) {
				$special_pages[] = $special_page_id;
			}
		}

		// Exclude Posts page
		if ( $posts_page = (int) get_option( 'page_for_posts' ) ) {
			$special_pages[] = $posts_page;
		}

		if ( count( $special_pages ) > 0 ) {
			$post__not_in = $query->get( 'post__not_in' );
			if ( ! is_array( $post__not_in ) ) {
				$post__not_in = array();
			}
			$post__not_in = array_merge( $post__not_in, $special_pages );
			$query->set( 'post__not_in', $post__not_in );
		}
	}
}

if ( ! function_exists( 'us_activate_maintenance_mode_for_dev_license' ) ) {
	add_action( 'init', 'us_activate_maintenance_mode_for_dev_license' );
	/**
	 * Always activate the maintenance mode for developer license
	 */
	function us_activate_maintenance_mode_for_dev_license() {
		// Note: the option is autoloaded when it exists, so it is read from the loaded ones, as get_option()
		// would query the DB on every request of the sites without it, see common/admin/functions/about.php
		$alloptions = wp_load_alloptions();
		if ( ! empty( $alloptions['us_license_dev_activated'] ) AND ! us_get_option( 'maintenance_mode' ) ) {
			us_update_option( 'maintenance_mode', 1 );
		}
	}
}

if (
	is_admin()
	AND has_filter( 'us_tr_default_language' )
) {
	/**
	 * Add redirect for Theme Options page, so it is always displayed in default language
	 */
	$current_language = apply_filters( 'us_tr_current_language', NULL );
	$default_language = apply_filters( 'us_tr_default_language', NULL );
	if (
		$current_language != $default_language
		AND us_is_theme_options_page()
	) {
		// Keep the requested section, which the page outputs right away
		$section = ! empty( $_GET['section'] ) ? sanitize_key( $_GET['section'] ) : '';
		wp_redirect( add_query_arg( 'lang', $default_language, us_theme_options_url( $section ) ) );
		exit;
	}
}
