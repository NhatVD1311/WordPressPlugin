<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Markers of posts for the Map element, filtered by List Filter and List Search
 */
if ( ! function_exists( 'us_ajax_map_markers' ) ) {

	add_action( 'wp_ajax_nopriv_us_ajax_map_markers', 'us_ajax_map_markers' );
	add_action( 'wp_ajax_us_ajax_map_markers', 'us_ajax_map_markers' );

	function us_ajax_map_markers() {

		if ( ! us_is_valid_ajax_referer() ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid referer of the request.',
				)
			);
		}

		// Security: the query arguments and the element settings come from the request, while they define
		// the query and the output, e.g. the coordinates field would let read any meta of any post.
		// So only the data signed on the page render is accepted, @see templates/elements/gmaps.php
		// The raw string is verified as is, because json_encode() of the decoded array may differ from it.
		// The action is signed along with the data, so signatures of other handlers aren't valid here.
		$json_data = '';
		if ( isset( $_POST['map_data'] ) AND is_string( $_POST['map_data'] ) ) {
			$json_data = stripslashes( $_POST['map_data'] );
		}
		if ( ! $json_data OR ! us_verify_data_signature( array( 'us_ajax_map_markers', $json_data ) ) ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid signature of the map data.',
				)
			);
		}

		$map_data = json_decode( $json_data, TRUE );
		if ( ! is_array( $map_data ) ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid map data.',
				)
			);
		}

		$query_args = us_remove_private_statuses_from_signed_query_args( (array) us_arr_path( $map_data, 'query_args', array() ) );

		// The params of List Filter and List Search are taken from the request below, the same way as Post List does,
		// @see us_ajax_post_list(). The signed 'apply_list_url_params' flag is kept as it is, because integrations
		// check it on the query, e.g. Relevanssi search and Post Views Counter order, so the filtered markers are
		// got the same way as on the page load. The hooks of the flag read the same request params, so they don't
		// change the result, @see us_list_filter_for_current_wp_query()

		// The search text stays slashed the same way as for Post List, because WP_Query unslashes it on its own
		if ( ! empty( $_POST['_s'] ) AND is_string( $_POST['_s'] ) ) {
			$query_args['s'] = sanitize_text_field( $_POST['_s'] );
		}

		// Arguments for post count of Faceted Filtering, before applying the order and filter params,
		// @see templates/elements/post_list.php
		$query_args_unfiltered = $query_args;

		// The order comes from URL params of the page load only, the map doesn't react to List Order,
		// but it keeps the same posts within the markers limit, @see templates/elements/gmaps.php
		if ( ! empty( $_POST['_orderby'] ) AND is_string( $_POST['_orderby'] ) ) {
			us_apply_orderby_to_list_query( $query_args, wp_unslash( $_POST['_orderby'] ) );
		}

		if ( $list_filter = us_get_filter_params_from_request() ) {
			us_apply_filtering_to_list_query( $query_args, $list_filter );
		}

		// Check the content the same way as on the page render: it depends on the author of the post,
		// which contains the map, while there is no post context in AJAX requests at all
		global $us_page_block_ids;
		$us_page_block_ids = (array) $us_page_block_ids;
		array_unshift( $us_page_block_ids, (int) us_arr_path( $map_data, 'source_id', 0 ) );

		$response = array(
			'markers' => us_gmaps_get_posts_markers( $query_args, (array) us_arr_path( $map_data, 'atts', array() ) ),
		);

		// Post count for Faceted Filtering, when List Filter applies to the map instead of a list
		if ( $list_filters = us_get_HTTP_POST_json( 'list_filters' ) ) {
			$response['facetedFilter'] = array(
				'post_count' => us_list_filter_get_post_count( $query_args_unfiltered, $list_filters ),
			);
		}

		wp_send_json_success( $response );
	}
}

/**
 * Marker popup of a post by the Grid Layout for the Map element, it's loaded on the marker click
 */
if ( ! function_exists( 'us_ajax_map_infowindow' ) ) {

	add_action( 'wp_ajax_nopriv_us_ajax_map_infowindow', 'us_ajax_map_infowindow' );
	add_action( 'wp_ajax_us_ajax_map_infowindow', 'us_ajax_map_infowindow' );

	function us_ajax_map_infowindow() {

		if ( ! us_is_valid_ajax_referer() ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid referer of the request.',
				)
			);
		}

		// Security: the layout and the post the map comes from define the output, so only the data signed
		// on the page render is accepted: the same data as for markers, signed along with this action,
		// @see templates/elements/gmaps.php and us_ajax_map_markers()
		$json_data = '';
		if ( isset( $_POST['map_data'] ) AND is_string( $_POST['map_data'] ) ) {
			$json_data = stripslashes( $_POST['map_data'] );
		}
		if ( ! $json_data OR ! us_verify_data_signature( array( 'us_ajax_map_infowindow', $json_data ) ) ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid signature of the map data.',
				)
			);
		}

		$map_data = json_decode( $json_data, TRUE );
		$atts = (array) us_arr_path( $map_data, 'atts', array() );

		if ( ! is_array( $map_data ) OR us_arr_path( $atts, 'marker_click' ) !== 'grid_layout' ) {
			wp_send_json_error(
				array(
					'message' => 'Invalid map data.',
				)
			);
		}

		// The post ID comes from the clicked marker, or post IDs of markers come from the preload of popups in the
		// background, up to the batch size, @see common/js/elements/maps.js. A forged value must not expose posts,
		// which the visitor can't view: their content and meta would leak through elements of the layout.
		// The same checks as for popups of list items, @see us_list_item_popup_content()
		$is_batch = isset( $_POST['post_ids'] );
		if ( $is_batch ) {
			$post_ids = array_slice( array_map( 'intval', (array) $_POST['post_ids'] ), 0, /* batch size */ 50 );
		} else {
			$post_ids = array( (int) ( $_POST['post_id'] ?? 0 ) );
		}

		$allowed_post_statuses = (array) get_post_stati( array( 'public' => TRUE ) );
		if ( is_user_logged_in() AND current_user_can( 'read_private_posts' ) ) {
			$allowed_post_statuses += (array) get_post_stati( array( 'private' => TRUE ) );
		}

		// Post types of the map query are signed, so the post should be of one of them. The query has no post types
		// for the "Posts of the current query" source on the blog, archives and search results, which show public
		// post types only
		$query_post_types = us_arr_path( $map_data, 'query_args.post_type' );
		if ( empty( $query_post_types ) OR $query_post_types === 'any' ) {
			$query_post_types = get_post_types( array( 'public' => TRUE ) );
		}

		// The status alone is not enough: posts of some types are never shown to visitors while being published,
		// like the "Inbound Messages" with the form submissions, so only the post types of lists are accepted.
		// The signed post types are checked as well, because an author gets the signature in the preview of the own
		// post, where the map can have any post types
		// The post types are explicit, because the "any" type skips types excluded from search, which lists show
		$post_types = array_intersect( (array) $query_post_types, array_keys( us_get_loop_post_types() ) );
		$posts = array();
		if ( $post_types ) {
			$found_posts = get_posts(
				array(
					'post__in' => $post_ids,
					'post_type' => array_values( $post_types ),
					'post_status' => $allowed_post_statuses,
					'posts_per_page' => count( $post_ids ),
				)
			);
			foreach ( $found_posts as $post ) {
				$posts[ $post->ID ] = $post;
			}
		}

		// The clicked post, which isn't available, is an error, while such posts of the preload are skipped
		if ( ! $is_batch AND empty( $posts ) ) {
			wp_send_json_error(
				array(
					'message' => 'The post is not available.',
				)
			);
		}

		// Check the content the same way as on the page render: it depends on the author of the post,
		// which contains the map, while there is no post context in AJAX requests at all
		global $us_page_block_ids;
		$us_page_block_ids = (array) $us_page_block_ids;
		array_unshift( $us_page_block_ids, (int) us_arr_path( $map_data, 'source_id', 0 ) );

		// The layout is checked on the page render, @see templates/elements/gmaps.php
		$items_layout = (string) us_arr_path( $atts, 'items_layout', 'map_marker_1' );

		if ( $is_batch ) {
			$items = array();
			foreach ( $posts as $post_id => $post ) {
				$items[ $post_id ] = us_get_grid_layout_post_html( $post, $items_layout );
			}
			wp_send_json_success(
				array(
					'items' => $items,
				)
			);
		}

		wp_send_json_success(
			array(
				'html' => us_get_grid_layout_post_html( reset( $posts ), $items_layout ),
			)
		);
	}
}
