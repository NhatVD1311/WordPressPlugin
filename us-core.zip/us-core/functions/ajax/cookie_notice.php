<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );


add_action( 'wp_ajax_nopriv_us_cookie_set_amp_cookie', 'us_cookie_set_amp_cookie' );
add_action( 'wp_ajax_us_cookie_set_amp_cookie', 'us_cookie_set_amp_cookie' );
function us_cookie_set_amp_cookie() {

	// AMP sends the decision as JSON, it's stored the same way as on regular pages, see _general.js
	// Note: the "consentState" boolean is checked for older versions of AMP, which had no "consentStateValue"
	$request = json_decode( (string) file_get_contents( 'php://input' ), TRUE );
	$is_rejected = (
		us_arr_path( $request, 'consentStateValue' ) === 'rejected'
		OR us_arr_path( $request, 'consentState' ) === FALSE
	);

	// The notice with one button only informs, so its decision is never taken as the consent
	if ( us_get_option( 'cookie_consent_mode', 'none' ) == 'consent' ) {
		$cookie_value = $is_rejected ? 'rejected' : 'accepted';
	} else {
		$cookie_value = 'true';
	}

	$cookie_status = setcookie(
		'us_cookie_notice_accepted',
		$cookie_value,
		strtotime( $is_rejected ? '+180 days' : '+365 days' ),
		'/',
		'',
		is_ssl()
	);

	wp_send_json( [ 'cookie_set' => $cookie_status ], 200 );
}
