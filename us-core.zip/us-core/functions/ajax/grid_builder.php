<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

if ( ! function_exists( 'usgb_check_ajax_access' ) ) {
	/**
	 * Stop the request, if the current user may not edit Grid Layouts
	 *
	 * The handlers below output the whole Grid Builder interface, whose fields hold lists of the
	 * site content (custom fields, taxonomies, Reusable Blocks), and every "wp_ajax_" action is
	 * reachable by any logged-in user, so the capability of the edited post type is required here.
	 */
	function usgb_check_ajax_access() {
		$post_type_object = get_post_type_object( 'us_grid_layout' );
		if (
			! $post_type_object
			OR ! current_user_can( $post_type_object->cap->edit_posts )
		) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'Sorry, you are not allowed to edit this item.' ),
				)
			);
		}
	}
}

/**
 * Load elements list HTML to choose from
 */
add_action( 'wp_ajax_usgb_get_elist_html', 'ajax_usgb_get_elist_html' );
function ajax_usgb_get_elist_html() {
	usgb_check_ajax_access();

	us_load_template( 'usof/templates/window_add', array(
		'elements' => us_config( 'grid-settings.elements', array() ),
	) );

	// We don't use JSON to reduce data size
	die;
}

/**
 * Load shortcode builder elements forms
 */
add_action( 'wp_ajax_usgb_get_ebuilder_html', 'ajax_usgb_get_ebuilder_html' );
function ajax_usgb_get_ebuilder_html() {
	usgb_check_ajax_access();

	$template_vars = array(
		'titles' => array(),
		'body' => '',
	);

	// Loading all the forms HTML
	foreach ( us_config( 'grid-settings.elements', array() ) as $type ) {
		$elm = us_config( 'elements/' . $type, array() );
		$template_vars['titles'][ $type ] = isset( $elm['title'] ) ? $elm['title'] : $type;
		$template_vars['body'] .= us_get_template( 'usof/templates/edit_form', array(
			'type' => $type,
			'params' => $elm['params'],
			'context' => 'grid',
		) );
	}

	us_load_template( 'usof/templates/window_edit', $template_vars );

	// We don't use JSON to reduce data size
	die;
}

/**
 * Load grid template selector forms
 */
add_action( 'wp_ajax_usgb_get_gtemplates_html', 'ajax_usgb_get_gtemplates_html' );
function ajax_usgb_get_gtemplates_html() {
	usgb_check_ajax_access();

	us_load_template( 'usof/templates/window_templates' );

	// We don't use JSON to reduce data size
	die;
}

/**
 * Save header
 */
add_action( 'wp_ajax_usgb_save', 'ajax_usgb_save' );
function ajax_usgb_save() {
	$post = array(
		'ID' => isset( $_POST['ID'] ) ? (int) $_POST['ID'] : NULL,
		'post_title' => isset( $_POST['post_title'] ) ? $_POST['post_title'] : NULL,
		'post_content' => isset( $_POST['post_content'] ) ? $_POST['post_content'] : NULL,
	);

	if ( ! check_admin_referer( 'usgb-update' ) OR ! current_user_can( 'edit_post', $post['ID'] ) ) {
		wp_send_json_error(
			array(
				'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
			)
		);
	}

	if ( ! $post['ID'] ) {
		wp_send_json_error(
			array(
				'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
			)
		);
	}

	if ( wp_update_post( $post ) !== $post['ID'] ) {
		wp_send_json_error(
			array(
				'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
			)
		);
	}

	// Fix: Save translations for Polylang
	if ( function_exists( 'pll_set_post_language' ) ) {
		if ( ! empty( $_POST['post_lang_choice'] ) ) {
			pll_set_post_language( $post['ID'], sanitize_text_field( $_POST['post_lang_choice'] ) );
		}
		if ( ! empty( $_POST['post_tr_lang'] ) AND is_array( $_POST['post_tr_lang'] ) ) {
			$translations = array();
			foreach ( (array) us_arr_path( $_POST, 'post_tr_lang', array() ) as $lang_code => $post_id ) {
				$translations[ $lang_code ] = (int) $post_id;
			}
			// Save translations for post
			if ( ! empty( $translations ) AND function_exists( 'PLL' )) {
				PLL()->model->post->save_translations( $post['ID'], array_map( 'absint', $translations ) );
			}
		}
	}

	wp_send_json_success(
		array(
			'message' => us_translate( 'Changes saved.' ),
		)
	);
}
