<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Font Awesome Kit support (hosted-kit / CDN embed).
 *
 * A site owner connects their OWN Font Awesome Kit using their OWN API Token. We use the API
 * only to authenticate and let them pick which kit to use; the kit's icons are then delivered by
 * Font Awesome's own kit loader (https://kit.fontawesome.com/<code>.js), which we enqueue on the
 * site. Icons render as regular Font Awesome 6/7 markup (e.g. <i class="fa-solid fa-star">), which
 * the kit's runtime turns into the actual glyphs — including the user's custom uploaded icons
 * (<i class="fa-kit fa-...">).
 *
 * Stored value format in shortcodes/options/meta:  fakit-<style>|<name>   e.g.  fakit-solid|star
 * The "fakit-" prefix keeps kit icons distinct from the theme's bundled Font Awesome 5 sets
 * (fas/far/...), so the same icon name can be used from FA5 and from the kit on one page.
 *
 * Coexistence note: kit icons use Font Awesome 6/7 class names (fa-solid, fa-light, fa-kit, ...),
 * while the theme's FA5 uses fas/far/.... These do not collide as long as the kit does NOT have
 * v4/v5 compatibility enabled (which would redefine .fas/.far). This is surfaced to the user in
 * Theme Options.
 *
 * Subscription note: when loaded from the CDN, official Pro icons stop rendering once the
 * subscription lapses (same as Font Awesome's own plugin). Custom uploaded icons keep working
 * only while the kit is served. We do not extract or cache Pro vectors (the API forbids it).
 */
if ( ! class_exists( 'US_FA_Kit' ) ) {

	class US_FA_Kit {

		/** Slug prefix for every kit-provided icon set, e.g. "fakit-solid" */
		const SLUG_PREFIX = 'fakit-';

		/** WP option holding the connection state */
		const OPTION = 'us_fa_kit';

		/** Font Awesome API endpoints */
		const TOKEN_ENDPOINT = 'https://api.fontawesome.com/token';
		const GRAPHQL_ENDPOINT = 'https://api.fontawesome.com';

		/** Hosted kit loader base URL */
		const KIT_CDN = 'https://kit.fontawesome.com/';

		/** Enqueue handle for the kit loader script */
		const SCRIPT_HANDLE = 'us-fa-kit';

		/** @var US_FA_Kit */
		protected static $instance;

		/**
		 * @var bool Whether to print the FA5 guard script with the kit tag. Set when the kit is
		 * enqueued from a UI context (usof admin pages, builders) — see enqueue_kit().
		 */
		protected $print_fa5_guard = FALSE;

		public static function instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		protected function __construct() {

			// Stay completely dormant while the official Font Awesome plugin is active: register no
			// hooks, so we never load Font Awesome twice or conflict with it. (The connector field's
			// own admin script is enqueued via config/assets-admin.php — independent of these hooks —
			// so the Theme Options field still renders, with its warning, while dormant.)
			if ( ! self::is_active() ) {
				return;
			}

			// Expose the kit's icon sets to the icon picker / rendering (only when a kit is connected)
			add_filter( 'us_config_icon-sets', array( $this, 'register_icon_sets' ) );

			// Load the kit loader for actual icon rendering on the frontend, and wherever usof controls
			// (incl. the icon picker) render — Theme Options, the classic editor, the header/grid
			// builders (usof_print_scripts), and the Live Builder (usb_enqueue_assets_for_builder) —
			// so control previews get the kit webfont too.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_kit' ) );
			add_action( 'usof_print_scripts', array( $this, 'enqueue_kit' ) );
			add_action( 'usb_enqueue_assets_for_builder', array( $this, 'enqueue_kit' ) );

			// Filter the kit's <script> tag: add crossorigin, and — for Web Fonts kits — append the
			// theme's own Font Awesome 5 stylesheet right after it. A Web Fonts kit injects FA6/7 CSS
			// that overrides the theme's FA5 — notably its .fa-*:before { content } glyph mappings —
			// breaking the theme/UI icons. Emitting fontawesome.css immediately after the kit <script>
			// makes its FA5 rules win the cascade in every context (a normally enqueued style would
			// print in the styles block, before the kit script, and lose). SVG kits don't inject that
			// CSS, so the override is skipped for them (see filter_kit_script_tag).
			add_filter( 'script_loader_tag', array( $this, 'filter_kit_script_tag' ), 10, 2 );

			// Connect / select / disconnect are admin-only operations
			if ( is_admin() ) {
				add_action( 'wp_ajax_us_fa_kit_connect', array( $this, 'ajax_connect' ) );
				add_action( 'wp_ajax_us_fa_kit_select', array( $this, 'ajax_select' ) );
				add_action( 'wp_ajax_us_fa_kit_refresh', array( $this, 'ajax_refresh' ) );
				add_action( 'wp_ajax_us_fa_kit_disconnect', array( $this, 'ajax_disconnect' ) );
			}
		}

		/* ---------------------------------------------------------------------
		 * Connection state (WP option)
		 * ------------------------------------------------------------------- */

		/**
		 * Note: the option is autoloaded and exists (empty) on a site without a kit, so no request queries it,
		 * as get_option() would on every request otherwise. The first request of a site, which has none yet,
		 * creates it, or makes the one of the versions, which did not autoload it, autoloaded.
		 *
		 * @return array Keys: api_token, kit_token, name, version, license, technology, styles, connected_at
		 */
		public function get_data() {
			$alloptions = wp_load_alloptions();
			if ( ! isset( $alloptions[ self::OPTION ] ) ) {
				if ( get_option( self::OPTION ) === FALSE ) {
					add_option( self::OPTION, array(), '', /* autoload */ TRUE );
				} elseif ( function_exists( 'wp_set_option_autoload' ) ) {
					wp_set_option_autoload( self::OPTION, TRUE );
				}
			}
			$data = get_option( self::OPTION, array() );
			return is_array( $data ) ? $data : array();
		}

		public function update_data( $data ) {
			update_option( self::OPTION, (array) $data, /* autoload */ TRUE );
		}

		/**
		 * @return bool Whether a kit is connected
		 */
		public function is_connected() {
			$data = $this->get_data();
			return (bool) us_arr_path( $data, 'kit_token' );
		}

		/** Font Awesome dashboard URL for a given kit token (empty string when no token). */
		public static function kit_url_for( $token ) {
			$token = (string) $token;
			return $token !== '' ? 'https://fontawesome.com/kits/' . rawurlencode( $token ) : '';
		}

		/** Font Awesome dashboard URL for the currently connected kit (empty string when none). */
		public function kit_page_url() {
			$data = $this->get_data();
			return self::kit_url_for( us_arr_path( $data, 'kit_token', '' ) );
		}

		/**
		 * Whether the official Font Awesome WordPress plugin is active. Running it alongside this
		 * feature double-loads Font Awesome and causes conflicts, so connecting is blocked while
		 * it is active.
		 *
		 * @return bool
		 */
		public static function official_plugin_active() {
			if ( class_exists( 'FortAwesome\\FontAwesome' ) ) {
				return TRUE;
			}
			// is_plugin_active() is an admin helper; the class check above already covers the
			// frontend (an active plugin defines its class on load), so only fall back in admin/AJAX
			if ( is_admin() OR wp_doing_ajax() ) {
				if ( ! function_exists( 'is_plugin_active' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				return is_plugin_active( 'font-awesome/index.php' );
			}
			return FALSE;
		}

		/**
		 * Whether this feature should operate at all. It stays fully dormant while the official
		 * Font Awesome plugin is active, to avoid loading Font Awesome twice and conflicting.
		 *
		 * @return bool
		 */
		public static function is_active() {
			static $active = NULL;
			if ( $active === NULL ) {
				$active = ! self::official_plugin_active();
			}
			return $active;
		}

		/* ---------------------------------------------------------------------
		 * Styles & class mapping
		 * ------------------------------------------------------------------- */

		/**
		 * Map a Font Awesome family + style (as returned by the API) to our normalized style slug.
		 * e.g. classic/solid => "solid", classic/brands => "brands",
		 *      sharp/regular => "sharp-regular", sharp-duotone/light => "sharp-duotone-light".
		 *
		 * @param string $family
		 * @param string $style
		 * @return string
		 */
		public static function family_style_to_slug( $family, $style ) {
			$family = strtolower( trim( (string) $family ) );
			$style = strtolower( trim( (string) $style ) );
			if ( $family === '' OR $family === 'classic' ) {
				return $style;
			}
			return $style !== '' ? ( $family . '-' . $style ) : $family;
		}

		/** Human label for a style slug, e.g. "sharp-duotone-light" => "Sharp Duotone Light" */
		public static function style_label( $slug ) {
			if ( $slug === 'custom' ) {
				return __( 'Custom', 'us' );
			}
			return ucwords( str_replace( '-', ' ', (string) $slug ) );
		}

		/**
		 * Map a kit style slug to its Font Awesome 6/7 CSS classes.
		 * e.g. "solid" => "fa-solid", "sharp-solid" => "fa-sharp fa-solid",
		 *      "custom" => "fa-kit", "custom-duotone" => "fa-kit-duotone".
		 *
		 * @param string $slug Style slug WITHOUT the "fakit-" prefix
		 * @return string
		 */
		public static function style_to_classes( $slug ) {
			$slug = (string) $slug;
			if ( $slug === 'custom' ) {
				return 'fa-kit';
			}
			if ( $slug === 'custom-duotone' ) {
				return 'fa-kit-duotone';
			}
			$parts = explode( '-', $slug );
			$style = array_pop( $parts );
			$family = implode( '-', $parts );
			return ( $family !== '' ? 'fa-' . $family . ' ' : '' ) . 'fa-' . $style;
		}

		/**
		 * Build the <i> tag for a kit icon. Called from us_prepare_icon_tag().
		 *
		 * @param string $style_slug Style slug WITHOUT the "fakit-" prefix, e.g. "solid"
		 * @param string $name       Icon name, e.g. "star" (with or without leading "fa-")
		 * @param string $inline_css Pre-built attribute string, e.g. ' style="font-size:2rem;"'
		 * @return string
		 */
		public static function render_icon_tag( $style_slug, $name, $inline_css = '' ) {
			$name = (string) $name;
			if ( substr( $name, 0, 3 ) !== 'fa-' ) {
				$name = 'fa-' . $name;
			}
			$classes = self::style_to_classes( $style_slug );
			return '<i class="' . $classes . ' ' . $name . '"' . $inline_css . '></i>';
		}

		/* ---------------------------------------------------------------------
		 * Icon set registration (us_config_icon-sets filter)
		 * ------------------------------------------------------------------- */

		/**
		 * Append the connected kit's styles as icon sets so they show up in the icon picker.
		 * These carry 'kit' => TRUE so the theme's webfont/@font-face generators skip them
		 * (the kit's own loader provides the fonts).
		 *
		 * @param array $sets Existing icon-sets config
		 * @return array
		 */
		public function register_icon_sets( $sets ) {
			if ( ! $this->is_connected() ) {
				return $sets;
			}

			$kit_page_url = $this->kit_page_url();
			$kit_url = $kit_page_url !== '' ? $kit_page_url . '/icons' : 'https://fontawesome.com/kits';

			$data = $this->get_data();
			$styles = (array) us_arr_path( $data, 'styles', array() );
			foreach ( $styles as $slug => $label ) {
				$sets[ self::SLUG_PREFIX . $slug ] = array(
					'set_name' => 'FA Kit: ' . $label,
					'set_url' => $kit_url,
					'kit' => TRUE,
				);
			}

			return $sets;
		}

		/* ---------------------------------------------------------------------
		 * Asset loading (the kit loader script)
		 * ------------------------------------------------------------------- */

		public function kit_script_url() {
			$data = $this->get_data();
			$token = us_arr_path( $data, 'kit_token', '' );
			return $token ? self::KIT_CDN . rawurlencode( $token ) . '.js' : '';
		}

		/**
		 * Load the kit loader. Hooked on the frontend (wp_enqueue_scripts) and wherever usof controls
		 * render (usof_print_scripts / usb_enqueue_assets_for_builder), so the icon-picker preview
		 * gets the kit webfont too. The preview's class mapping for kit sets lives in
		 * usof/js/field_icon.js (bundled).
		 */
		public function enqueue_kit() {
			if ( ! $this->is_connected() ) {
				return;
			}
			// The FA5 guard is only needed in UI contexts (usof fields, builder panels), where markup
			// emits plain <i class="fas ..."> dynamically. Frontend markup gets the marker server-side
			// via us_prepare_icon_tag(), so plain page views skip the guard and its DOM observer.
			if ( current_action() !== 'wp_enqueue_scripts' ) {
				$this->print_fa5_guard = TRUE;
			}
			// In <head> (last arg FALSE) so webfont icons don't flash
			wp_enqueue_script( self::SCRIPT_HANDLE, $this->kit_script_url(), array(), FALSE, FALSE );
		}

		/**
		 * Filter the kit loader's <script> tag:
		 *  - add crossorigin="anonymous" (the kit loader requires it);
		 *  - in UI contexts only ($print_fa5_guard, set when enqueued via usof_print_scripts /
		 *    usb_enqueue_assets_for_builder), prepend a guard script that pre-marks every theme FA5
		 *    icon (.fas/.far/.fal/.fad/.fab) with FA's own "already processed" attribute
		 *    (data-fa-i2svg), so an SVG kit's i2svg runtime never converts them into FA6 SVGs /
		 *    "missing icon" boxes. Plenty of UI markup emits plain <i class="fas ..."> (usof radio
		 *    labels_as_icons, dynamic-value buttons, builder panels, JS-inserted icons) — guarding
		 *    centrally here covers them all, current and future, instead of chasing every emission
		 *    site. The guard observes the DOM before the kit loader runs: MutationObserver callbacks
		 *    fire in registration order, so ours marks new/re-classed nodes before FA's observer
		 *    processes them. Kit icons (fa-solid, fa-kit, ...) don't match the selector and keep
		 *    rendering via the kit. Frontend page views skip the guard — their markup is marked
		 *    server-side by us_prepare_icon_tag() and the us_icon_tag filters.
		 *  - for Web Fonts kits only, append the theme's own Font Awesome 5 stylesheet right after it,
		 *    so its .fa-*:before { content } glyph mappings and base classes win the cascade over the
		 *    FA6/7 webfont CSS the kit injects at that point. Placing it immediately after the kit
		 *    <script> guarantees the correct order in every context (head or footer, frontend / admin /
		 *    builder); a normally enqueued stylesheet would print in the styles block, before the kit
		 *    script, and lose. Kit icons use FA6/7 classes (.fa-solid, .fa-kit, ...) and are untouched.
		 *    SVG kits inject no webfont CSS, so there is nothing to win back — the theme icons are
		 *    protected from their i2svg runtime by data-fa-i2svg markers instead, and the override is
		 *    skipped (~90 KB saved on every page). Unknown technology (older stored connections, failed
		 *    detection) emits the override: a needless one costs bytes, a wrong skip breaks icons.
		 *    Theme-agnostic: get_template_directory_uri() resolves to Impreza or Zephyr.
		 */
		public function filter_kit_script_tag( $tag, $handle ) {
			if ( $handle !== self::SCRIPT_HANDLE ) {
				return $tag;
			}
			if ( strpos( $tag, 'crossorigin' ) === FALSE ) {
				$tag = str_replace( ' src=', ' crossorigin="anonymous" src=', $tag );
			}

			// The FA5 guard (see the doc comment above). Must be registered before the kit script runs.
			// Marks only still-unmarked icons (:not([data-fa-i2svg])) and counts fresh marks: Font
			// Awesome's own observer samples ONLY addedNodes[0] of a childList record — once we mark
			// that first node (e.g. a "fab" social icon), FA drops the whole record, and unmarked kit
			// icons inserted in the same batch (the header builder's Social Links chip glues standard
			// and kit icons into one .html() call) would never get converted. So whenever we marked
			// something, we re-run i2svg on the record's container explicitly: it respects the markers
			// (skips FA5 icons) and converts the kit ones. No-op for webfont kits (no window.FontAwesome)
			// and before the kit runtime loads (its startup scan covers everything present by then).
			if ( $this->print_fa5_guard ) {
				$guard = '<script id="us-fa-kit-fa5-guard">'
					. '!function(){'
					. 'var s=".fas,.far,.fal,.fad,.fab".split(",").map(function(c){return c+":not([data-fa-i2svg])"}).join(",");'
					. 'function m(r){'
					. 'var n=0;'
					. 'if(!r.querySelectorAll)return n;'
					. 'if(r.matches&&r.matches(s)){r.setAttribute("data-fa-i2svg","");n++}'
					. 'r.querySelectorAll(s).forEach(function(e){e.setAttribute("data-fa-i2svg","");n++});'
					. 'return n'
					. '}'
					. 'new MutationObserver(function(l){'
					. 'l.forEach(function(x){'
					. 'if(x.type==="attributes"){m(x.target);return}'
					. 'var n=0;'
					. 'x.addedNodes.forEach(function(e){if(e.nodeType===1)n+=m(e)});'
					. 'if(n&&window.FontAwesome&&FontAwesome.dom&&FontAwesome.dom.i2svg){FontAwesome.dom.i2svg({node:x.target})}'
					. '})'
					. '}).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:["class"]});'
					. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){m(document.documentElement)})}'
					. 'else{m(document.documentElement)}'
					. '}();'
					. '</script>' . "\n";
				$tag = $guard . $tag;
			}

			$data = $this->get_data();
			if ( us_arr_path( $data, 'technology' ) === 'svg' ) {
				return $tag;
			}
			$href = get_template_directory_uri() . '/common/css/base/fontawesome.css';
			if ( defined( 'US_THEMEVERSION' ) ) {
				$href .= '?ver=' . US_THEMEVERSION;
			}
			$tag .= '<link rel="stylesheet" id="us-fa-kit-fa5-override-css" href="' . esc_url( $href ) . '" media="all">' . "\n";
			return $tag;
		}

		/* =====================================================================
		 * CONNECT  (admin only) — authenticate, list kits, store the chosen one.
		 * No icon vectors are fetched or cached (the kit loader delivers them).
		 * ================================================================== */

		/**
		 * Exchange a long-lived API Token for a short-lived access token.
		 *
		 * @param string $api_token
		 * @return string|WP_Error access token on success
		 */
		public function exchange_token( $api_token ) {
			$api_token = trim( (string) $api_token );
			if ( $api_token === '' ) {
				return new WP_Error( 'us_fa_kit', 'API Token is empty.' );
			}

			$response = wp_remote_post( self::TOKEN_ENDPOINT, array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_token,
					'Content-Type' => 'application/json',
				),
			) );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), TRUE );

			if ( $code === 401 OR $code === 403 ) {
				return new WP_Error( 'us_fa_kit_auth', 'Invalid or expired Font Awesome API Token.' );
			}
			if ( $code < 200 OR $code >= 300 OR empty( $body['access_token'] ) ) {
				return new WP_Error( 'us_fa_kit', 'Could not authenticate with Font Awesome.' );
			}

			return (string) $body['access_token'];
		}

		/**
		 * Run a GraphQL query against the Font Awesome API.
		 *
		 * @param string $query
		 * @param string $access_token
		 * @return array|WP_Error Decoded "data" node on success
		 */
		public function graphql( $query, $access_token, $variables = NULL ) {
			$payload = array( 'query' => $query );
			if ( ! empty( $variables ) ) {
				$payload['variables'] = $variables;
			}
			$response = wp_remote_post( self::GRAPHQL_ENDPOINT, array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type' => 'application/json',
				),
				'body' => wp_json_encode( $payload ),
			) );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), TRUE );

			if ( $code < 200 OR $code >= 300 ) {
				return new WP_Error( 'us_fa_kit', sprintf( 'Font Awesome API error (HTTP %d).', $code ) );
			}
			if ( ! empty( $body['errors'] ) ) {
				$msg = us_arr_path( $body, 'errors.0.message', 'GraphQL query failed.' );
				return new WP_Error( 'us_fa_kit_graphql', $msg );
			}
			if ( ! isset( $body['data'] ) OR ! is_array( $body['data'] ) ) {
				return new WP_Error( 'us_fa_kit', 'Unexpected Font Awesome API response.' );
			}

			return $body['data'];
		}

		/**
		 * List the kits available on the account.
		 *
		 * @param string $access_token
		 * @return array|WP_Error List of array( token, name, version, license )
		 */
		public function fetch_kits( $access_token ) {
			$data = $this->graphql( 'query { me { kits { token name version licenseSelected } } }', $access_token );
			if ( is_wp_error( $data ) ) {
				return $data;
			}

			$kits = array();
			foreach ( (array) us_arr_path( $data, 'me.kits', array() ) as $kit ) {
				if ( empty( $kit['token'] ) ) {
					continue;
				}
				$kits[] = array(
					'token' => (string) $kit['token'],
					'name' => (string) us_arr_path( $kit, 'name', $kit['token'] ),
					'version' => (string) us_arr_path( $kit, 'version', '' ),
					'license' => (string) us_arr_path( $kit, 'licenseSelected', '' ),
				);
			}

			return $kits;
		}

		/**
		 * Union the distinct style slugs from a list of searchKit `icons` into $slugs (keys = slug).
		 *
		 * @param array $icons searchKit().icons list
		 * @param array $slugs Accumulator, modified in place (slug => TRUE)
		 */
		protected static function collect_variant_slugs( $icons, &$slugs ) {
			foreach ( (array) $icons as $icon ) {
				if ( us_arr_path( $icon, '__typename' ) !== 'IconWithVariants' ) {
					continue;
				}
				foreach ( (array) us_arr_path( $icon, 'variants', array() ) as $variant ) {
					$slug = self::family_style_to_slug(
						us_arr_path( $variant, 'familyStyle.family', '' ),
						us_arr_path( $variant, 'familyStyle.style', '' )
					);
					if ( $slug !== '' ) {
						$slugs[ $slug ] = TRUE;
					}
				}
			}
		}

		/**
		 * Discover the styles the kit actually contains, so the picker offers exactly those. Strategy
		 * depends on the kit's subsetType (Font Awesome's searchKit is kit-scoped but needs a query):
		 *
		 *  - AUTO / FULL (whole-style / whole-library kits): searchKit with an EMPTY query returns every
		 *    official icon in the kit, so we paginate it. These kits list every style on nearly every
		 *    icon, so the set of styles saturates within the first pages — we stop once several
		 *    consecutive pages add nothing new instead of walking a whole library to the end.
		 *  - CUSTOM (hand-picked kits): the empty query returns nothing, so we sweep each letter a-z and
		 *    union the styles. No early-exit — a rare style (e.g. Duotone Solid) may sit on a single icon
		 *    whose name only matches a late letter; hand-picked kits are small, so the sweep stays cheap.
		 *
		 * Any API error fails the whole discovery (WP_Error) instead of silently producing an empty or
		 * partial styles list — the user simply retries.
		 *
		 * Adds the "custom" style when the kit has uploads.
		 *
		 * @param string $access_token
		 * @param string $kit_token
		 * @return array|WP_Error Map of style slug => human label
		 */
		public function fetch_kit_styles( $access_token, $kit_token ) {
			$kit_token = (string) $kit_token;

			// One request: subset type (picks the strategy) + whether the kit has custom uploads.
			$meta = $this->graphql(
				'query($t:String!){ me { kit(token:$t){ subsetType iconUploads { name } } } }',
				$access_token, array( 't' => $kit_token )
			);
			if ( is_wp_error( $meta ) ) {
				return $meta;
			}
			$subset = strtoupper( (string) us_arr_path( $meta, 'me.kit.subsetType', '' ) );
			$has_custom = ! empty( us_arr_path( $meta, 'me.kit.iconUploads', array() ) );

			$query = 'query($t:String!,$q:String!,$p:Int!){ me { kit(token:$t){'
				. ' searchKit(query:$q, page:$p, pageSize:50, searchMode:OFFICIAL){'
				. ' totalPageCount icons { __typename'
				. ' ... on IconWithVariants { variants { familyStyle { family style } } } } } } } }';

			$slugs = array();

			if ( $subset === 'AUTO' OR $subset === 'FULL' ) {
				// Paginate the empty query through the kit's icons. Styles are dense on whole-style kits,
				// so stop once several consecutive pages add no new style — otherwise a whole-library kit
				// means dozens of sequential requests in one AJAX call, tripping PHP/gateway time limits.
				// $max_pages stays as a hard bound for pathological kits.
				$page = 1;
				$max_pages = 60;
				$pages_without_new = 0;
				do {
					$data = $this->graphql( $query, $access_token, array( 't' => $kit_token, 'q' => '', 'p' => $page ) );
					if ( is_wp_error( $data ) ) {
						return $data;
					}
					$sk = us_arr_path( $data, 'me.kit.searchKit', array() );
					$found_before = count( $slugs );
					self::collect_variant_slugs( us_arr_path( $sk, 'icons', array() ), $slugs );
					$pages_without_new = ( count( $slugs ) > $found_before ) ? 0 : $pages_without_new + 1;
					$total_pages = (int) us_arr_path( $sk, 'totalPageCount', 0 );
					$page++;
				} while ( $page <= $total_pages AND $page <= $max_pages AND $pages_without_new < 3 );

			} else {
				foreach ( str_split( 'abcdefghijklmnopqrstuvwxyz' ) as $term ) {
					$data = $this->graphql( $query, $access_token, array( 't' => $kit_token, 'q' => $term, 'p' => 1 ) );
					if ( is_wp_error( $data ) ) {
						return $data;
					}
					self::collect_variant_slugs( us_arr_path( $data, 'me.kit.searchKit.icons', array() ), $slugs );
				}
			}

			$slugs = array_keys( $slugs );
			sort( $slugs );
			$styles = array();
			foreach ( $slugs as $slug ) {
				$styles[ $slug ] = self::style_label( $slug );
			}
			if ( $has_custom ) {
				$styles['custom'] = self::style_label( 'custom' );
			}

			return $styles;
		}

		/**
		 * Detect how the kit is actually delivered, from the kit loader's own embedded config:
		 * "method":"css" = Web Fonts, "method":"js" = SVG. This is ground truth — the API's
		 * technologySelected reflects the dashboard setting, not what the CDN actually serves
		 * (e.g. kits with whole styles can be force-delivered as Web Fonts).
		 *
		 * @param string $kit_token
		 * @return string 'webfonts' | 'svg' | '' when detection fails (treated as webfonts — the safe default)
		 */
		protected function fetch_kit_technology( $kit_token ) {
			$response = wp_remote_get( self::KIT_CDN . rawurlencode( (string) $kit_token ) . '.js', array( 'timeout' => 20 ) );
			if ( is_wp_error( $response ) OR (int) wp_remote_retrieve_response_code( $response ) !== 200 ) {
				return '';
			}
			if ( preg_match( '/"method"\s*:\s*"(js|css)"/', (string) wp_remote_retrieve_body( $response ), $matches ) ) {
				return $matches[1] === 'css' ? 'webfonts' : 'svg';
			}
			return '';
		}

		/**
		 * Store the chosen kit. Re-validates the token and confirms the kit exists.
		 *
		 * @param string $api_token
		 * @param string $kit_token
		 * @return array|WP_Error Stored kit meta on success
		 */
		public function select_kit( $api_token, $kit_token ) {
			$access_token = $this->exchange_token( $api_token );
			if ( is_wp_error( $access_token ) ) {
				return $access_token;
			}

			$kits = $this->fetch_kits( $access_token );
			if ( is_wp_error( $kits ) ) {
				return $kits;
			}

			$meta = NULL;
			foreach ( $kits as $kit ) {
				if ( $kit['token'] === (string) $kit_token ) {
					$meta = $kit;
					break;
				}
			}
			if ( $meta === NULL ) {
				return new WP_Error( 'us_fa_kit', 'The selected kit was not found on this account.' );
			}

			$styles = $this->fetch_kit_styles( $access_token, $meta['token'] );
			if ( is_wp_error( $styles ) ) {
				return $styles;
			}
			if ( empty( $styles ) ) {
				// A kit with no discoverable styles would register no icon sets — surface that instead
				// of storing a "connected" kit that adds nothing to the icon picker.
				return new WP_Error( 'us_fa_kit', 'No icon styles found in this kit. Check its contents at fontawesome.com and try again.' );
			}

			// Delivery technology gates the FA5 cascade override (see filter_kit_script_tag). Non-fatal:
			// unknown ('') falls back to emitting the override — a needless override only costs bytes,
			// a wrong skip would break the theme icons. Re-detected on every kit change / Refresh.
			$technology = $this->fetch_kit_technology( $meta['token'] );

			$this->update_data( array(
				'api_token' => (string) $api_token,
				'kit_token' => $meta['token'],
				'name' => $meta['name'],
				'version' => $meta['version'],
				'license' => $meta['license'],
				'technology' => $technology,
				'styles' => $styles,
				'connected_at' => time(),
			) );

			$meta['styles'] = $styles;
			return $meta;
		}

		/**
		 * Remove the connection.
		 *
		 * Note: the option is kept empty, not deleted, so it stays among the autoloaded ones, see get_data()
		 */
		public function disconnect() {
			$this->update_data( array() );
		}

		/* ---------------------------------------------------------------------
		 * AJAX endpoints (Theme Options > Icons)
		 * ------------------------------------------------------------------- */

		protected function verify_ajax() {
			check_ajax_referer( 'usof-actions' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => 'Sorry, you are not allowed to do that.' ) );
			}
		}

		protected function block_if_plugin_active() {
			if ( self::official_plugin_active() ) {
				wp_send_json_error( array(
					'message' => __( 'Deactivate the official Font Awesome plugin to connect a Kit here.', 'us' ),
				) );
			}
		}

		/**
		 * Validate an API Token and return the list of kits to choose from.
		 */
		public function ajax_connect() {
			$this->verify_ajax();
			$this->block_if_plugin_active();

			$api_token = isset( $_POST['api_token'] ) ? sanitize_text_field( wp_unslash( $_POST['api_token'] ) ) : '';
			$access_token = $this->exchange_token( $api_token );
			if ( is_wp_error( $access_token ) ) {
				wp_send_json_error( array( 'message' => $access_token->get_error_message() ) );
			}

			$kits = $this->fetch_kits( $access_token );
			if ( is_wp_error( $kits ) ) {
				wp_send_json_error( array( 'message' => $kits->get_error_message() ) );
			}
			if ( empty( $kits ) ) {
				wp_send_json_error( array( 'message' => 'No kits found on this Font Awesome account.' ) );
			}

			wp_send_json_success( array( 'kits' => $kits ) );
		}

		/**
		 * Store the chosen kit.
		 */
		public function ajax_select() {
			$this->verify_ajax();
			$this->block_if_plugin_active();

			$api_token = isset( $_POST['api_token'] ) ? sanitize_text_field( wp_unslash( $_POST['api_token'] ) ) : '';
			$kit_token = isset( $_POST['kit_token'] ) ? sanitize_text_field( wp_unslash( $_POST['kit_token'] ) ) : '';
			if ( $api_token === '' ) {
				$stored = $this->get_data();
				$api_token = (string) us_arr_path( $stored, 'api_token', '' );
			}
			if ( $api_token === '' OR $kit_token === '' ) {
				wp_send_json_error( array( 'message' => 'Select a Font Awesome kit.' ) );
			}

			$meta = $this->select_kit( $api_token, $kit_token );
			if ( is_wp_error( $meta ) ) {
				wp_send_json_error( array( 'message' => $meta->get_error_message() ) );
			}

			wp_send_json_success( array(
				'name' => $meta['name'],
				'version' => $meta['version'],
				'license' => $meta['license'],
				'url' => self::kit_url_for( us_arr_path( $meta, 'token', '' ) ),
				'styles' => array_keys( (array) us_arr_path( $meta, 'styles', array() ) ),
			) );
		}

		/**
		 * Re-sync the currently connected kit using the stored token (no token re-entry needed).
		 */
		public function ajax_refresh() {
			$this->verify_ajax();
			$this->block_if_plugin_active();

			$data = $this->get_data();
			$api_token = (string) us_arr_path( $data, 'api_token', '' );
			$kit_token = (string) us_arr_path( $data, 'kit_token', '' );
			if ( $api_token === '' OR $kit_token === '' ) {
				wp_send_json_error( array( 'message' => 'Connect a Font Awesome kit first.' ) );
			}

			$meta = $this->select_kit( $api_token, $kit_token );
			if ( is_wp_error( $meta ) ) {
				wp_send_json_error( array( 'message' => $meta->get_error_message() ) );
			}

			wp_send_json_success( array(
				'name' => $meta['name'],
				'version' => $meta['version'],
				'license' => $meta['license'],
				'url' => self::kit_url_for( us_arr_path( $meta, 'token', '' ) ),
				'styles' => array_keys( (array) us_arr_path( $meta, 'styles', array() ) ),
				'message' => __( 'Kit refreshed.', 'us' ),
			) );
		}

		/**
		 * Disconnect the kit.
		 */
		public function ajax_disconnect() {
			$this->verify_ajax();
			$this->disconnect();
			wp_send_json_success( array( 'message' => 'Font Awesome kit disconnected.' ) );
		}
	}

	US_FA_Kit::instance();
}
