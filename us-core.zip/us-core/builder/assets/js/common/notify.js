/**
 * Global window objects for the USBuilder ecosystem:
 * - $usb: Core mounting and extension initialization.
 * - $usbcore: Builder and extension helper functions.
 * - $ush: UpSolution Helper Library.
 */
! function( $, _undefined ) {

	const _window = window;

	if ( ! _window.$usb ) {
		return;
	}

	_window.$ush = _window.$ush || {};
	_window.$usbcore = _window.$usbcore || {};

	// Types of notifications.
	// const NOTIFY_TYPE = {
	// 	ERROR: 'error',
	// 	INFO: 'info',
	// 	SUCCESS: 'success'
	// };

	/**
	 * Notify - Notification system.
	 */
	function Notify() {
		const self = this;

		// Bindable events
		self._events = {
			close: self._close.bind( self )
		};

		$( () => {

			// Elements
			self.$container = $( '.usb-notification' );

			// Close notification handler
			$usb.$document.on( 'click', '.usb_action_notification_close', self._events.close );
		});
	}

	// Notify API
	$.extend( Notify.prototype, {
		/**
		 * Determines if ready
		 *
		 * @return {Boolean} True if ready, False otherwise
		 */
		isReady: function() {
			return ! $ush.isUndefined( this.$container );
		},

		/**
		 * Add and display a notification
		 *
		 * @param {String} message The message
		 * @param {String} type The type
		 * TODO: Add display multiple notifications as a list!
		 */
		add: function( message, type ) {
			const self = this;

			var delayAutoClose = 4000, // 4s
				$notification = self.$container
					.clone()
					.removeClass( 'hidden' );

			// Set notification type
			if ( !! type && $usbcore.indexOf( type, NOTIFY_TYPE ) > -1 ) {
				$notification
					.addClass( 'type_' + type );
			}
			// If the notification type is not an error, then add a close timer
			if ( type !== NOTIFY_TYPE.ERROR ) {
				$notification
					.addClass( 'auto_close' )
					.data( 'handle', $ush.timeout( () => {
						$notification
							.find( '.usb_action_notification_close' )
							.trigger( 'click' );
					}, delayAutoClose ) );
			}
			// Add message to notification
			$notification
				.find( 'span' )
				.html( '' + message );

			// Add notification
			$usb.$panel
				.append( $notification );
		},

		/**
		 * Close notification handler
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_close: function( e ) {
			var $notification = $( e.target ).closest( '.usb-notification' ),
				handle = $notification.data( 'handle' );
			if ( !! handle ) {
				$ush.clearTimeout( handle );
			}
			$notification.fadeOut( 'fast', () => {
				$notification.remove();
			} );
		},

		/**
		 * Closes all notifications
		 */
		closeAll: function() {
			$( '.usb-notification', $usb.$body ).fadeOut( 'fast', function() {
				$( this ).remove();
			} );
		}
	} );

	$usb.notify = new Notify();

}( jQuery );
