/**
 * Global window objects:
 * - $usbp: USBPreview class instance.
 * - parent.$usb: Core mounting and extension initialization.
 * - parent.$usbcore: Builder and extension helper functions.
 * - parent.usGlobalData: Context data for USBuilder import.
 * - usGlobalData: Context data for USBuilderPreview import.
 * - $ush: UpSolution Helper Library.
 * - $us: UpSolution Theme Core JS.
 *
 * CSS Classes:
 * - "usb_skip_elmSelected": Skips element-selected editing event.
 */
! function( $, _undefined ) {

	const _window = window;
	const _document = document;

	const parent = _window.parent || {};

	if ( ! parent.$usb ) {
		return;
	}

	const abs = Math.abs;
	const pow = Math.pow;
	const ceil = Math.ceil;
	const floor = Math.floor;

	const $usb = parent.$usb;
	const $usof = parent.$usof || {};
	const $usbcore = parent.$usbcore || {}; // $usbcore helpers

	_window.$us = _window.$us || {};
	_window.usGlobalData = _window.usGlobalData || {};
	_window.$ush = _window.$ush || parent.$ush || {};
	_window.usofColorAPI = _window.usofColorAPI || parent.usofColorAPI || {};

	// Direction constants
	const DIRECTION = {
		BOTTOM: 'bottom',
		LEFT: 'left',
		RIGHT: 'right',
		TOP: 'top',
		UNKNOWN: '' // Fallback value when the target is invalid or direction cannot be determined
	};

	// 2D coordinate system axis identifiers.
	const AXIS_2D = {
		X: 'x-axis',
		Y: 'y-axis'
	};

	// Supported container hierarchy types (e.g., for Visual Composer elements).
	const CONTAINER_TYPE = {
		ANY: 'any',		// any first container
		CHILD: 'child', // child container, for example: vc_column, vc_column_inner, vc_tta_section, etc
		ROOT: 'root'	// root container, for example: vc_row, vc_row_inner, vc_tabs etc
	};

	/**
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/button#value
	 *
	 * NOTE: main button pressed, usually the left button or the un-initialized state
	*/
	const MOUSE_EVENT_MAIN_BUTTON = 0;

	/**
	 * USBPreview - The class displays page settings and shortcode changes
	 */
	function USBPreview() {
		const self = this;

		// Private "Variables"
		self.fps = 1000 / 200;
		self.activePreloaders = {};
		self._highlights = {}; // all highlights
		self._placeholderRoots = new Set; // nodes to check for placeholders, the root container means the whole editable area
		// Scripts can render the content of placeholders later (e.g. embeds), then they are checked again
		self._placeholderObserver = new MutationObserver( ( records ) => {
			records.forEach( ( { target } ) => {
				const node = $( target ).closest( '.usb_placeholder_elm' )[0];
				if ( node ) {
					self.checkPlaceholders( node );
				}
			} );
		} );

		// Elements
		self.$document = $( _document );
		self.$body = $( _document.body );
		self.$htmlBody = $( 'html,body' );
		self.highlight = $( '.usb-hover' )[0];

		const elmDefaultRootContainer = self.getElmNode( $usb.builder.defaultRootContainer );
		const postContentRootContainer = $usb.builder.postContentRootContainer;

		self.elmRootContainer = (
			elmDefaultRootContainer || self.getElmNode( postContentRootContainer )
		);

		if ( ! elmDefaultRootContainer ) {
			$usb.builder.setRootContainer( postContentRootContainer );
			$usb.builder.isRemoveRows = $usbcore.$hasClass( self.elmRootContainer, 'remove_rows-1' );
		}

		// Bindable events
		self._events = {
			// Track Drag & Drop events
			clickedControlsHoverPanel: self._clickedControlsHoverPanel.bind( self ),
			endDrag: self._endDrag.bind( self ),
			maybeDrag: self._maybeDrag.bind( self ),
			maybeStartDrag: self._maybeStartDrag.bind( self ),

			DOMContentLoaded: self._DOMContentLoaded.bind( self ),
			elmAnimationEnd: self._elmAnimationEnd.bind( self ),
			elmAnimationStart: self._elmAnimationStart.bind( self ),
			elmCopy: self._elmCopy.bind( self ),
			elmDelete: self._elmDelete.bind( self ),
			elmDuplicate: self._elmDuplicate.bind( self ),
			elmMove: self._elmMove.bind( self ),
			elmPaste: self._elmPaste.bind( self ),
			elmSelected: self._elmSelected.bind( self ),
			linkClickHandler: self._linkClickHandler.bind( self ),
			saveToFavorites: self._saveToFavorites.bind( self ),

			// Alias for call on events
			autoSetHighlightsPosition: $ush.debounce( self.setHighlightsPosition.bind( self ), self.fps ),
			markPlaceholders: $ush.debounce( self.markPlaceholders.bind( self ), 50 )
		};

		// This event is needed to get various data from the iframe
		_window.onmessage = $usb._onMessage.bind( self );

		// When leave the window with the cursor
		_window.onmouseout = $ush.debounce( ( e ) => {
			e = e || _window.event;
			const node = e.relatedTarget || e.toElement;
			if ( ! node || $ush.toLowerCase( node.nodeName ) === 'html' ) {
				self._mouseLeavesIframe.call( self, e );
			}
		}, 1 );

		// Highlight position updates on window resize or page scroll
		_window.onresize = () => {
			self._events.autoSetHighlightsPosition();
			self.checkPlaceholders(); // the visibility of elements depends on the screen width
		};
		_document.onscroll = self._events.autoSetHighlightsPosition;

		self.$body.attr( 'draggable', 'false' );

		// Events
		self.$document
			// The event fires when the initial HTML document has been completely loaded and parsed,
			// without wait for stylesheets, images, and subframes to finish load
			.ready( self._events.DOMContentLoaded )
			// Capture keyboard shortcuts
			.on( 'keydown', $usb._events.keydown )
			// Disabled dragstart from default
			.on( 'dragstart', () => { return false } )
			// Highlight actions
			.on( 'pointerdown', '.usb-hover-panel', self._events.clickedControlsHoverPanel )
			.on( 'pointerup', '.ui-icon_duplicate', self._events.elmDuplicate )
			.on( 'pointerup', '.ui-icon_add_to_fav', self._events.saveToFavorites )
			.on( 'pointerup', '.ui-icon_copy', self._events.elmCopy )
			.on( 'pointerup', '.ui-icon_paste', self._events.elmPaste )
			.on( 'pointerup', '.ui-icon_delete', self._events.elmDelete )
			// Track Drag & Drop events
			.on( 'pointerdown', self._events.maybeStartDrag )
			.on( 'pointermove', self._events.maybeDrag )
			.on( 'pointerup', $ush.debounce( self._events.endDrag, 2 ) ) // call after `_events.elmSelected`
			// Other events
			.on( 'pointerup', '[data-usbid]', $ush.debounce( self._events.elmSelected, 1 ) ) // call before `_events.endDrag`
			.on( 'pointermove', $ush.debounce( self._events.elmMove, 5 ) )
			.on( 'pointerleave', $ush.debounce( self._events.elmLeave, self.fps ) )
			// Handlers for css animation in elements
			.on( 'animationstart', '[data-usbid]', $ush.debounce( self._events.elmAnimationStart, 1 ) )
			.on( 'animationend', '[data-usbid]', $ush.debounce( self._events.elmAnimationEnd, 1 ) )
			// When the cursor is within `header` or `footer` then hide all highlights
			.on( 'pointerenter', '.l-header, .l-footer', $ush.debounce( self.hideHighlight.bind( self ), 100 ) )
			// Watch content changes (via us scripts)
			.on( 'contentChange', '.l-canvas:first', self._events.autoSetHighlightsPosition )
			// Show placeholders for elements without visible output
			// NOTE: Some scripts pass the changed container (e.g. tabs, popup), so check it only
			.on( 'contentChange', ( e, data ) => self.checkPlaceholders( ( ( data || {} ).elm || [] )[0] || e.target ) )
			.on( 'usb.contentChange', ( e ) => self.checkPlaceholders( e.target ) );

		self.$body
			.on( 'click', 'a', self._events.linkClickHandler );

		// Private events
		for ( const handler in self._$events ) {
			if ( typeof self._$events[ handler ] === 'function' ) {
				self.on( handler, self._$events[ handler ].bind( self ) );
			}
		}

		// Dropzone in preview.
		self.initDropzoneSection();
	};

	/**
	 * Transports for send messages between windows or objects
	 */
	$.extend( USBPreview.prototype, $ush.mixinEvents, {
		/**
		 * Send a message to the parent window
		 *
		 * @param {String} eventType A string contain event type
		 * @param {[]} extraParams Additional parameters to pass along to the event handler
		 */
		postMessage: function( eventType, extraParams ) {
			parent.postMessage( JSON.stringify( [ 'usb', eventType, extraParams ] ) );
		}
	} );

	// The minimum movement threshold in pixels to initiate dragging.
	const DRAG_SHIFT_THRESHOLD = 8;

	/**
	 * Functionality for implement Drag & Drop
	 * All the necessary methods that are somehow involved in this approach
	 */
	$.extend( USBPreview.prototype, {

		/**
		 * Get all data from the event that is needed for Drag & Drop.
		 *
		 * @param {Event} e
		 * @return {{}} The event data
		 */
		_extractEventData: function( { clientX, clientY, pageX, pageY, target } ) {
			return { clientX, clientY, pageX, pageY, target };
		},

		/**
		 * Event handler for click on any element in the highlight controls on HoverPanel.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_clickedControlsHoverPanel: function( e ) {
			const self = this;
			const elmId = $usbcore.$attr( $( e.currentTarget ).closest( '.usb-hover' )[0], 'data-elmid' );
			if ( ! elmId ) {
				return;
			}

			// Set element data on click on hover panel
			self.hoveredElmId = elmId;
			self.hoveredElm = self.getElmNode( elmId );

			// The we activate observations to start move the element
			$( self.hoveredElm ).trigger( 'pointerdown', [ e.pageX, e.pageY ] );
		},

		/**
		 * Handler for check movement.
		 *
		 * @event handler
		 * @param {Event} e
		 * @param {Number} pageX [optional] The coordinate at which the mouse was clicked, relative to the left edge of the document
		 * @param {Number} pageY [optional] The coordinate at which the mouse was clicked, relative to the top edge of the document
		 */
		_maybeStartDrag: function( e, pageX, pageY ) {
			const self = this;

			e.stopPropagation();

			if (
				// Stop process for preview mode
				! $usb.panel.isVisible()
				// If there drag in the parent window, then we will exit this method
				|| $usb.builder.draggingFromPanel()
				// Don't start move start for all buttons except left mouse button or trackpad
				|| e.button !== MOUSE_EVENT_MAIN_BUTTON
			) {
				return;
			}

			// Define the element to move
			var target = ( self.hoveredElm && $usbcore.$hasClass( e.target, 'usb-hover-panel-name' ) )
				? self.hoveredElm
				: self._getNearestNode( e.target );
			if ( ! target ) {
				return;
			}

			// Destroy all previous cache data if any
			self.clearDragData();
			// Save cache intermediate data at the time of Drag & Drop
			$usbcore.cache( 'iframeDrag' ).set( {
				currentId: null, // id of the element being moved (has an alias if given)
				currentParentId: null, // parent element id relative to currentId
				isDragging: false, // active when the element is in the process of being moved
				isParentTab: false, // move happens in the context of tabs (Tabs/Tour)
				isDragStarted: true,
				startX: e.pageX || pageX || 0,
				startY: e.pageY || pageY || 0,
				target: target // the node of the element being moved
			} );

			// NOTE: Firefox has problems using the "mousemove" event where it is not possible to
			// get the element that is under the cursor if it has "overflow: hidden".
			if ( $ush.isFirefox ) {
				[ target ].concat( $ush.toArray( target.getElementsByTagName( '*' ) ) ).forEach( ( node ) => {
					if ( ! $ush.isNode( node ) || $usbcore.$hasClass( node, 'usb_firefox_clip' ) ) {
						return;
					}
					if ( _window.getComputedStyle( node, /* pseudoElt */null ).getPropertyValue( 'overflow' ) === 'hidden' ) {
						$usbcore.$addClass( node, 'usb_firefox_clip' );
					}
				} );
			}
		},

		/**
		 * Position selection handler for move element
		 *
		 * NOTE: The method is called many times, so performance is important here!
		 *
		 * @event handler
		 * @param {Event} e
		 *
		 * TODO: Improve id structure consider aliases
		 */
		_maybeDrag: function( e ) {
			const self = this;

			var target = e.target,
				currentPreviewOffset = $usb.preview.getCurrentOffset(),
				// Get offset for transit
				transit = {
					pageX: ceil( currentPreviewOffset.x + e.pageX - _window.scrollX ), // x-axis
					pageY: ceil( currentPreviewOffset.y + e.pageY - _window.scrollY ) // y-axis
				};

			if ( ! $ush.isFirefox && $usb.builder.draggingFromPanel() ) {
				// Determination of the place where the element can fall
				self._maybeDrop( self._extractEventData( e ) );
				// Set position for transit when add a new element
				$usb.builder.setTransitPosition( transit.pageX, transit.pageY );
				return;
			}

			// Get cache data
			var dragData = $usbcore.cache( 'iframeDrag' ).data();
			if ( $.isEmptyObject( dragData ) || ! dragData.isDragStarted || ! dragData.target ) {
				return;
			}

			// Get offsets from origin along axis X and Y
			const diffX = abs( dragData.startX - e.pageX );
			const diffY = abs( dragData.startY - e.pageY );

			// Check minimum movement threshold in pixels to initiate dragging.
			if ( diffX >= DRAG_SHIFT_THRESHOLD || diffY >= DRAG_SHIFT_THRESHOLD ) {

				// Get and current id
				dragData.currentId = $usb.builder.getElmId( dragData.target );

				// Get base currentId without alias
				var baseCurrentId = $usb.builder.isAliasElmId( dragData.currentId )
					? $usb.builder.removeAliasFromId( dragData.currentId )
					: dragData.currentId;

				if ( $usb.builder.isMode( 'edit' ) ) {

					// Flush active move data
					$usbcore.cache( 'dragProcessData' ).flush();

					// Select mode of move elements
					$usb.builder.setMode( 'drag_from_preview' );
					// Add flag that drag is activated
					dragData.isDragging = true;
					// Get parent element id
					dragData.currentParentId = $usb.builder.getElmParentId( baseCurrentId );
					// Move in sections in the context of Tabs/Tour
					dragData.isParentTab = (
						!! $usb.builder.isElmTab( dragData.currentParentId )
						// NOTE: Tabs can turn into accordions on different window sizes
						&& ! $usbcore.$hasClass( self.getElmNode( dragData.currentParentId ), 'accordion' )
					);
					// Show the transit
					$usb.builder.showTransit( dragData.currentId );
					// Add helpers classes for visual control
					$usbcore
						.$addClass( dragData.target, 'usb_transit' )
						.$addClass( _document.body, 'usb_dragging' );
					// Hide all highlights
					self.hideEditableHighlight();
				}

				if (
					! $usb.builder.isMode( 'drag_from_preview' )
					// Do not move sections in the context of tabs (only buttons are allowed to move)
					|| ( dragData.isParentTab && ! $usb.builder.isAliasElmId( dragData.currentId ) )
					// Elements outside of the container, such as the header, footer, or sidebar
					|| $usb.builder.isOutsideRootContainer( baseCurrentId )
				) {
					self.clearDragData();
					return;
				}

				// Temporarily removes an element from the active map and stashes it.
				$usb.builder.excludeElement( baseCurrentId );

				// Determination of the place where the element can fall
				self._maybeDrop( self._extractEventData( e ) );

				// Set position for transit when move element
				$usb.builder.setTransitPosition( transit.pageX, transit.pageY );
			}
		},

		/**
		 *
		 * Determines the location where the element will be drag
		 * This method is called from both the current window and the parent.window
		 *
		 * NOTE: The method is called many times, so performance is important here!
		 *
		 * @param {{}} data The data from event
		 */
		_maybeDrop: function( data ) {
			const self = this;
			if (
				! data
				|| ! data.target
				|| ! $usb.builder.isDragMode()
				|| $usb.builder.hasDragScrolling() // skip target search when scroll
			) {
				return;
			}

			// Get data from temporary storage (usually intermediate data)
			const dragData = $usbcore.cache( 'iframeDrag' ).data();

			// This is the id of the new or moved element
			var currentId;
			if (  $usb.builder.isMode( 'drag_new_element' ) ) {
				currentId = $usb.builder.getNewElmId();
			} else {
				currentId = dragData.currentId;
			}

			var // The target the cursor is over
				target = self._getNearestNode( data.target ) || self.elmRootContainer,
				// The real ID of the target the cursor is over
				targetId = $usb.builder.getElmId( target ),
				// The first parent container of the target that the cursor is over
				targetContainer,
				// ID of the container within which the element will be added or moved
				targetContainerId,
				// Border direction for container edge detection (initialized as UNKNOWN)
				borderContainerToCursor = DIRECTION.UNKNOWN;

			// Get the target when move elements strictly attached to
			// the parent, move only in the context of the parent
			if (
				$usb.builder.isChildElmContainer( currentId )
				&& $usb.builder.isValidId( dragData.currentParentId )
			) {
				targetContainerId = dragData.currentParentId;
				targetContainer = self.getElmNode( targetContainerId );

				// Get the container the cursor is over
			} else if ( $usb.builder.isElmContainer( targetId ) ) {
				targetContainerId = targetId;
				targetContainer = target;

				// Get containers based on the current target the cursor
				// is over, if the target is not a container
			} else {
				targetContainer = self._getNearestNode( target,
					$usb.builder.isChildElmContainer( currentId )
						? CONTAINER_TYPE.ROOT
						: CONTAINER_TYPE.ANY
				);
				targetContainerId = $usb.builder.getElmId( targetContainer );
			}

			// Get a valid container element (on error it's elmRootContainer)
			targetContainer = targetContainer || self.elmRootContainer;

			// If element and target are `vc_row` then change target to root container
			if (
				$usb.builder.isRow( targetContainerId )
				&& (
					$usb.builder.isRow( currentId )
					|| $usb.templates.isTemplate( currentId ) // for section templates
					|| $usb.favorites.isFavoriteSection( currentId ) // for favorite sections
				)
			) {
				targetContainerId = $usb.builder.rootContainer;
			}

			// Remove alias from target container ID
			if ( $usb.builder.isAliasElmId( targetContainerId ) ) {
				targetContainerId = $usb.builder.removeAliasFromId( targetContainerId );
			}

			// Get a list of all children of the container where mouse movement occurs
			var children = $usb.builder.getElmChildren( targetContainerId );

			// Logic for define cursor on container borders
			if ( $usb.builder.isElmContainer( targetContainerId ) ) {
				// Get the root container in which the location of the cursor on
				// the borders will be determined
				var _parentTargetContainerId = targetContainerId;
				for ( var i = 3; i > 0; i-- ) {
					if ( ! $usb.builder.isChildElmContainer( _parentTargetContainerId ) ) {
						break;
					}
					_parentTargetContainerId = $usb.builder.getElmParentId( _parentTargetContainerId );
				}
				// Get a valid container ID
				_parentTargetContainerId = $usb.builder.getValidContainerId( _parentTargetContainerId );

				var targetHeight = $ush.parseInt( $ush.$rect( target ).height ),
					// If there are elements in the container and the latter is greater than 50, then increase
					// the boundary, which will help improve the user interface
					// NOTE: For empty containers, do not set a large value, as this can lead to problems
					borderAround = ( children.length && targetHeight >= 50 ? 15 : 5 );

				// Get the border of the container if the cursor is in it
				borderContainerToCursor = self.getCursorOnTargetBorder(
					self.getElmNode( _parentTargetContainerId ),
					data.clientX,
					data.clientY,
					borderAround
				);

				// If the cursor is on the border of the container, then redefine targets
				// to support add before and after the container
				if ( DIRECTION.UNKNOWN !== borderContainerToCursor ) {
					// Get a valid container ID (on error it's rootContainer)
					_parentTargetContainerId = $usb.builder.getValidContainerId(
						$usb.builder.getElmParentId( _parentTargetContainerId )
					);
					// Redefine target container
					targetContainer = self.getElmNode( _parentTargetContainerId );
					targetContainerId = _parentTargetContainerId;
				}
			}

			// Get alias and base currentId without alias
			var aliasId, baseCurrentId = currentId;
			if ( $usb.builder.isAliasElmId( currentId ) ) {
				aliasId = $usb.builder.getAliasFromId( currentId );
				baseCurrentId = $usb.builder.removeAliasFromId( currentId );
			}

			// Skip adding rows to content
			if ( $usb.builder.isRemoveRows && $usb.builder.isRow( baseCurrentId ) ) {
				return;
			}

			// Determine if it is a descendant of itself
			if ( $usb.builder.hasSameTypeParent( baseCurrentId, targetContainerId ) ) {
				return;
			}

			// Strict mode is a hard dependency between elements!
			const strictMode = (
				// The check if the moved element is a tab, accordion, tour or vc_column(_inner), if so, then enable strict mode
				$usb.builder.isChildElmContainer( baseCurrentId )
				// Allow add any non-row element to the container only if there is no content
				|| (
					! $usb.builder.isEmptyContent()
					&& $usb.builder.isDefaultRootContainer( targetContainerId )
					&& ! (
						$usb.builder.isRow( baseCurrentId )
						|| $usb.templates.isTemplate( baseCurrentId ) // for section templates
						|| $usb.favorites.isFavoriteSection( currentId ) // for favorite sections
					)
				)
			);

			// Check if the element can be a child of the hover element
			if ( ! $usb.builder.canBeChildOf( baseCurrentId, targetContainerId, strictMode ) ) {
				return;
			}

			var // Determine if the target container is a tab
				// NOTE: Tabs have the ability to turn into accordions, so you need to check
				// for the presence of classes, since the usbis can be for tabs
				targetContainerIsTab = (
					$usb.builder.isElmTab( targetContainerId )
					&& ! $usbcore.$hasClass( targetContainer, 'accordion' )
				),
				insertIndex = 0;

			// Update data as target have been changed
			if ( DIRECTION.UNKNOWN !== borderContainerToCursor ) {
				children = $usb.builder.getElmChildren( targetContainerId );
			}

			// If there is an alias and it is a tab button then add an alias to all children,
			// this is necessary to determine the position of the tab buttons
			if ( aliasId && aliasId === $usb.config( 'aliases.tab' ) ) {
				children = children.map( ( id ) => {
					return $usb.builder.addAliasToElmId( aliasId, id );
				} );
			}

			// Stabilizers provide more stable operation when move columns, especially for multi-line cases
			if ( $usb.builder.isMode( 'drag_from_preview' ) && $usb.builder.isColumn( baseCurrentId ) ) {
				// Exit if cursor is out of row
				if ( ! self.isInsideNode( self.getElmNode( dragData.currentParentId ), data.pageX, data.pageY ) ) {
					return;
				}
				// Exit if cursor is within element
				if (
					$usbcore.$hasClass( dragData.target, 'usb_transit' )
					&& self.isInsideNode( dragData.target, data.pageX, data.pageY )
				) {
					return;
				}
			}

			// Positional calculations are based on the distance of the cursor from the children
			if ( children.length ) {
				var _nearestSegment;

				for ( var elmIndex = 0, len = children.length; elmIndex < len; elmIndex++ ) {
					var elmId = children[ elmIndex ],
						elm = self.getElmNode( elmId );
					if ( ! elm ) {
						continue;
					}
					// Get the coordinates of an element, taking into account all scrolls
					var elmRect = $ush.$rect( elm ),
						elmX = ( elmRect.x + _window.scrollX ),
						elmY = ( elmRect.y + _window.scrollY );

					// Fixed a case where an element has an additional indent
					// on the X-axis, which violates the calculation of the
					// formula `(y2 - y1)² + (x2 - x1)²`
					elmX -= $ush.parseInt( ( elm.currentStyle || _window.getComputedStyle( elm ) ).marginLeft );

					// All columns that are not on the same line will be skipped
					// NOTE: Stabilizer when work with columns
					if (
						$usb.builder.isColumn( baseCurrentId )
						&& ! ( data.pageY >= elmY && data.pageY <= ( elmY + elmRect.height ) )
					) {
						continue;
					}

					// The formula `(y2 - y1)² + (x2 - x1)²` allows you to determine the nearest element
					var _segmentLength = Math.sqrt( pow( data.pageY - elmY, 2 ) + pow( data.pageX - elmX, 2 ) );
					if ( ! _nearestSegment || _nearestSegment > _segmentLength ) {
						_nearestSegment = _segmentLength;
						insertIndex = elmIndex; // save nearest index to cursor
					}
				}
			}

			var currentIndex = insertIndex;

			// Single-slide content carousel
			if ( $usb.builder.isContentCarouselSingleSlide( targetContainerId ) ) {
				var borderContentCarousel = self.getCursorOnTargetBorder(
					self.getElmNode( targetContainerId ),
					data.clientX,
					data.clientY,
					100 // borderAround: 50
				);
				if ( borderContentCarousel === DIRECTION.LEFT && insertIndex > 0 ) {
					insertIndex--;
				} else if ( borderContentCarousel === DIRECTION.RIGHT ) {
					insertIndex++;
				}
				if ( insertIndex && currentIndex === insertIndex ) {
					insertIndex--;
				}
			}

			// Positional calculations for all elements, where the position of
			// the cursor relative to the target is determined
			if (
				insertIndex === children.length -1
				|| $usb.builder.isColumn( baseCurrentId )
			) {
				var only_x_axis = $usb.config( 'moving_only_x_axis', [] )
					.includes( $usb.builder.getElmName( targetContainerId ) );

				// NOTE: Tabs have the ability to turn into accordions, so you need to check
				// for the presence of classes, since the usbis can be for tabs
				if (
					$usb.builder.isElmTab( targetContainerId )
					&& $usbcore.$hasClass( targetContainer, 'accordion' )
				) {
					only_x_axis = false;
				}

				// Get current cursor direction in target
				var currentCursorSector = self.getCursorSector(
					self.getElmNode( children[ insertIndex ] ),
					data.clientX,
					data.clientY,
					AXIS_2D[ only_x_axis ? 'X' : 'Y' ]
				);

				// If the cursor is more towards the bottom of the element then put the
				// index after it, otherwise the index will be before the element
				if ( [ DIRECTION.BOTTOM, DIRECTION.RIGHT ].includes( currentCursorSector ) ) {
					insertIndex += 1;
				}
			}

			// If the target container is a TTA section and it is hidden,
			// then all elements will be appended to the end
			if ( self.tabIsHidden( targetContainerId ) ) {
				insertIndex = children.length;
			}

			// Save the last found container
			if ( dragData.lastFoundContainer !== targetContainer ) {
				$usbcore
					.$removeClass( dragData.lastFoundContainer, 'usb_dropcontainer' )
					.$addClass( targetContainer, 'usb_dropcontainer' );
				dragData.lastFoundContainer = targetContainer;
			}

			// Get base targetContainerId without alias
			if ( $usb.builder.isAliasElmId( targetContainerId ) ) {
				targetContainerId = $usb.builder.removeAliasFromId( targetContainerId );
			}

			// Save insert data to a temp variable
			dragData.parentId = targetContainerId;
			dragData.currentId = baseCurrentId;
			dragData.insertIndex = insertIndex;

			// Save data for Firefox and Safari 17+ since endDrag in the frame window does not work
			if ( $ush.isFirefox || $ush.safariVersion() >= 17 ) {
				$usbcore.cache( 'drag' ).set( {
					parentId: targetContainerId,
					currentId: currentId,
					insertIndex: insertIndex
				} );
			}

			const insert = $usb.builder.getInsertPosition( targetContainerId, insertIndex );

			// Additional check for `insert` changes to reduce the number of document calls
			if ( $ush.comparePlainObject( insert, dragData.lastInsert ) ) {
				return;
			}
			dragData.lastInsert = $ush.clone( insert );

			// Content carousel with a single-slide, the possible position is shown before or after,
			// although the slide is actually in a different position.
			if ( $usb.builder.isContentCarouselSingleSlide( targetContainerId ) ) {
				insert.parent = baseCurrentId;
				if ( insertIndex < currentIndex ) {
					insert.position = 'before';
				} else if ( insertIndex ) {
					insert.position = 'after';
				}
			}

			// Create new dropplace element
			if ( $usb.builder.isColumn( currentId ) ) {
				dragData.place = self.getElmNode( currentId );
			} else {
				$usbcore.$remove( dragData.place ); // remove old dropplace node
				dragData.place = _document.createElement( 'div' );
				dragData.place.className = 'usb_dropplace';

				// This is where additional settings are added for the vertical line when move containers
				var isHorizontalWrapper = $usb.builder.getElmName( targetContainerId ) === 'hwrapper';
				if ( isHorizontalWrapper ) {
					var node;
					if ( $usbcore.$hasClass( targetContainer, 'wrap' ) ) {
						node = ( $usb.builder.isMode( 'drag_new_element' ) && children.length )
							? self.getElmNode( children[0] )
							: dragData.target;
					}
					dragData.place.style.height = $ush.$rect( node || targetContainer ).height + 'px';
				}
			}

			// Explicit target replacement for elements of type Tabs that allows
			// you to display the movement of the tab buttons
			if ( dragData.isParentTab && aliasId ) {
				if ( $usb.builder.isValidId( insert.parent ) ) {
					insert.parent = [ 'prepend', 'append' ].includes( insert.position )
						? self.getElmNode( currentId ).parentNode || targetContainer
						: $usb.builder.addAliasToElmId( aliasId, insert.parent );
				}
			}

			// Add a temporary container at the location where the item will be added.
			self.trigger( 'insertElement', [ insert.parent, insert.position, dragData.place ] );
		},

		/**
		 * End a drag
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_endDrag: function( e ) {
			const self = this;
			const acceptableModes = [
				'drag_new_element',
				'drag_from_preview',
				'edit' // for FF mode "drag_new_element"
			];

			// Check if the mode is correct
			if ( ! $usb.builder.isMode( acceptableModes ) ) {
				return;
			}

			/**
			 * Kill current event
			 * NOTE: For FF and Safari 17+, we ignore stop since the transmitted object is data, not an event object,
			 * all due to the peculiarities of the FF and Safari 17+ from work the iframe
			 */
			if ( ! ( $ush.isFirefox || $ush.safariVersion() >= 17 ) ) {
				e.preventDefault();
				e.stopPropagation();
			}

			// Reset the hover element, this will cancel the open of mode
			if ( $usb.builder.isDragMode() ) {
				self.hoveredElm = null;
			}

			const dragData = $usbcore.cache( 'iframeDrag' ).data();

			// NOTE: With a quick change of events, it may turn out that the code in the
			// intermediate event may not have time to be executed or during the renderer
			// or other factors, so we will do a control check
			if ( $usb.builder.isAliasElmId( dragData.currentId ) ) {
				dragData.currentId = $usb.builder.removeAliasFromId( dragData.currentId );
			}

			// Duplicate the signal in the parent window for correct completion
			if ( $usb.builder.draggingFromPanel() ) {
				// Move the data to add a new element
				$usbcore.cache( 'drag' ).set( {
					parentId: dragData.parentId,
					currentId: dragData.currentId,
					insertIndex: dragData.insertIndex
				} );
				self.postMessage( 'builder.endDrag' );
				self.clearDragData();
				return;
			}

			// Reset all data
			$usb.builder.setMode( 'edit' );

			// If the move is not activated or not started then clear all assets
			if ( ! dragData.isDragStarted || ! dragData.isDragging ) {
				// Clear all asset and temporary data to move
				self.clearDragData();
				// Select an element for edit
				if (
					! dragData.isDragging
					&& $usbcore.$hasClass( e.target, 'usb-hover-panel-name' )
				) {
					// Hide highlight for editable element
					self.hideEditableHighlight();
					// Run a trigger to initialize shortcode mode
					var $highlight = $( e.target ).closest( '.usb-hover' );
					if ( $highlight.length ) {
						var elmId = $usbcore.$attr( $highlight[0], 'data-elmid' );
						self.hoveredElm = self.getElmNode( elmId );
						$( self.hoveredElm ).trigger( 'pointerup' );
					}
				}
				// End execution
				return;
			}

			// Move the element to a new position
			if ( !! dragData.parentId && !! dragData.currentId ) {
				$usb.builder.moveElm( dragData.currentId, dragData.parentId, dragData.insertIndex || 0 );
				// If the final container is a TTA section then open this section
				if ( $usb.builder.isElmSection( dragData.parentId ) ) {
					self.openSectionById( dragData.parentId );
				}
				// Trigger the content change event
				// NOTE: Bind on `.l-canvas` — listeners (highlights, waypoints, sticky, charts)
				// are attached there and jQuery events bubble up, so triggering on <body> misses them.
				$us.$canvas.trigger( 'contentChange' );
			}

			// Clear all asset and temporary data to move
			self.clearDragData();
		},

		/**
		 * Clear iframe drag-and-drop UI states, classes, and cached drag data.
		 *
		 * @param {boolean} keepData - If true, resets visual styles but preserves the cached data.
		 */
		clearDragData: function( keepData ) {
			const self = this;

			// Get drag data
			const dragData = $usbcore.cache( 'iframeDrag' ).data();
			if ( $.isEmptyObject( dragData ) ) {
				return;
			}

			$usbcore
				.$removeClass( dragData.target, 'usb_transit' )
				.$removeClass( dragData.lastFoundContainer, 'usb_dropcontainer' )
				.$removeClass( _document.body, 'usb_dragging' );

			// Remove dropplace element
			// NOTE: Row columns are not deleted as they are pointers
			if ( ! $usb.builder.isColumn( dragData.currentId ) ) {
				$usbcore.$remove( dragData.place );
			}

			if ( keepData ) {
				return;
			}

			$usb.builder.hideTransit();
			$usbcore.cache( 'iframeDrag' ).flush();

			// When the element is moved and the cursor leaves the preview area,
			// the text may be captured, so when clear the data, clear the buffer
			if ( $usb.builder.isMode( 'drag_from_preview' ) ) {
				if ( _window.getSelection ) {
					_window.getSelection().removeAllRanges();
				} else if ( _document.selection ) {
					_document.selection.empty();
				}
			}
		},

		/**
		 * Auto-scroll while drag
		 *
		 * NOTE: The method is called many times, so performance is important here!
		 *
		 * @event handler
		 * @param {*} direction The scroll direction
		 * @param {Number} acceleration The scroll acceleration
		 */
		_scrollDragging: $ush.debounce( function( direction, acceleration ) {
			var self = this,
				scrollHeight = $ush.parseInt( _document.body.scrollHeight ),
				scrollTo = _undefined, // No value does not start animation
				scrollTop = $ush.parseInt( _window.scrollY );

			// Stop the animation here
			if ( self.$htmlBody.is( ':animated' ) ) {
				self.$htmlBody.stop( /* clearQueue */true );
			}

			if ( direction === DIRECTION.TOP && scrollHeight && scrollTop > 0 ) {
				scrollTo = 0; // up of page
			}
			else if (
				direction === DIRECTION.BOTTOM
				&& scrollTop < $ush.parseInt( scrollHeight - _window.innerHeight )
			) {
				scrollTo = scrollHeight; // down the page
			}

			if ( typeof scrollTo !== 'number' ) {
				$usb.builder.removeDragScrollData(); // remove a drag scroll data
				return;
			}

			var duration = 2000, // duration without acceleration to end point
				maxAcceleration = 4; // multiplicity of maximum acceleration

			// Get acceleration and check max {acceleration}x
			acceleration = $ush.parseInt( acceleration );
			if ( acceleration > maxAcceleration ) {
				acceleration = maxAcceleration;
			}

			// The initiate animation
			self.$htmlBody.animate(
				{ scrollTop: scrollTo },
				{
					// Duration with acceleration
					duration: floor( duration / ( acceleration || 1 ) ),
					// After the animation is complete, call the scroll completion handler
					complete: $usb.builder.stopDragScrolling.bind( $usb )
				}
			);

			self.hideHighlight();
		}, 1 )
	} );

	/**
	 * Functionality for the implementation of visual highlights in the preview area.
	 * Optimizations applied: Vanilla JS DOM checks, element pooling, and inline style updates.
	 */
	$.extend( USBPreview.prototype, {

		// Cached DOM elements pool to prevent repetitive cloneNode operations.
		_highlightPool: [],

		/**
		 * Display highlights for the currently hovered element and its ancestors.
		 * Performance-critical: Executed frequently on pointer movement.
		 */
		showHighlight: $ush.throttle( function() {
			const self = this;

			if (
				! $usb.builder.isMode( 'edit' )
				|| ! $usb.builder.isValidId( self.hoveredElmId )
			) {
				return;
			}
			var parentId = self.hoveredElmId,
				iteration = 0;

			if ( $usb.builder.isAliasElmId( parentId ) ) {
				parentId = $usb.builder.removeAliasFromId( parentId );
			}

			const rootContainer = $usb.builder.rootContainer;
			while ( parentId !== rootContainer && parentId !== null ) {
				if ( iteration++ >= 1000 ) {
					break;
				}

				self._createHighlight( parentId );

				const item = self._highlights[ parentId ];

				const node = self.getElmNode( parentId );
				if ( node && ( node.offsetWidth > 0 || node.offsetHeight > 0 || node.getClientRects().length > 0 ) ) {
					item.active = true;
					item.highlight.style.display = 'block';
				}

				parentId = $usb.builder.getElmParentId( parentId );
			}

			self.setHighlightsPosition.call( self );
		}, 1 ),

		/**
		 * Deactivate and hide all active element highlights.
		 */
		hideHighlight: $ush.throttle( function() {
			const self = this;
			if ( $.isEmptyObject( self._highlights ) ) {
				return;
			}
			for ( const elmId in self._highlights ) {
				const item = self._highlights[ elmId ];
				item.active = false;
				item.highlight.style.display = 'none';
			}
			self.hoveredElm = null;
			self.hoveredElmId = null;
		}, 1 ),

		/**
		 * Recalculate and update the absolute DOM positions of active highlights.
		 * Performance-critical: Uses Vanilla JS styles directly to avoid jQuery overhead.
		 */
		setHighlightsPosition: function() {
			const self = this;

			if ( ! $usb.builder.isMode( 'edit' ) || $.isEmptyObject( self._highlights ) ) {
				return;
			}

			const winPageXOffset = _window.pageXOffset || 0;
			const winPageYOffset = _window.pageYOffset || 0;
			const winInnerWidth = _window.innerWidth;

			// READ PHASE: measure every element first, with no style writes in between, so we
			// don't force a synchronous reflow on each iteration (per-highlight read→write→read
			// layout thrash). Highlights are absolutely-positioned overlays, so batching the
			// writes afterwards can't affect the measured geometry.
			const updates = [];
			for ( const elmId in self._highlights ) {
				if ( ! $usb.builder.isValidId( elmId ) ) {
					continue;
				}
				const item = self._highlights[ elmId ];
				const element = self.getElmNode( elmId );
				if (
					! $ush.isNode( element )
					|| (
						! item.active
						&& ! item.editable
					)
				) {
					continue;
				}

				const offsetTop = element.offsetTop;
				const offsetLeft = element.offsetLeft;
				const negativeTop = offsetTop < 0 ? abs( offsetTop ) : 0;
				const negativeLeft = offsetLeft < 0 ? abs( offsetLeft ) : 0;
				const elmRect = $ush.$rect( element );

				const width = elmRect.width - negativeLeft;

				if ( width > winInnerWidth ) {
					continue;
				}

				updates.push( {
					highlight: item.highlight,
					width: width,
					height: elmRect.height - negativeTop,
					left: elmRect.left + negativeLeft + ( winPageXOffset || element.scrollLeft ),
					top: elmRect.top + negativeTop + ( winPageYOffset || element.scrollTop ),
					isSmall: ( elmRect.width < 100 ),
				} );
			}

			// WRITE PHASE: apply all collected styles at once.
			for ( var i = 0; i < updates.length; i++ ) {
				const update = updates[ i ];
				const style = update.highlight.style;
				style.height = update.height + 'px';
				style.left = update.left + 'px';
				style.top = update.top + 'px';
				style.width = update.width + 'px';

				$usbcore.$toggleClass( update.highlight, 'small', update.isSmall );
			}
		},

		/**
		 * Highlight an explicitly selected or currently editable element.
		 *
		 * @param {String} id Shortcode's unique ID (e.g., "us_btn:1")
		 */
		showEditableHighlight: function( id ) {
			const self = this;

			if ( ! $usb.builder.isValidId( id ) ) {
				return;
			}

			self.hideEditableHighlight();

			var item = self._highlights[ id ];
			if ( ! item ) {
				self.hideHighlight();
				item = self._createHighlight( id );
				if ( item ) {
					item.active = true;
				}
				self.setHighlightsPosition();
			}

			if ( item ) {
				item.editable = true;
				$usbcore.$addClass( item.highlight, 'usb_editable' );
			}
		},

		/**
		 * Clear the editable styling from specific or all active highlights.
		 *
		 * @param {String} [id] Optional shortcode unique ID (e.g., "us_btn:1")
		 */
		hideEditableHighlight: function( id ) {
			const self = this;

			if ( $.isEmptyObject( self._highlights ) ) {
				return;
			}

			var highlights = self._highlights;
			if ( id && self.hasEditableHighlight( id ) ) {
				highlights = { [id]: self._highlights[ id ] };
			}

			for ( const elmId in highlights ) {
				const item = highlights[ elmId ];
				if ( item && item.editable ) {
					// Reset the flag too, otherwise the entry stays "editable" forever: it keeps
					// being repositioned by setHighlightsPosition() and hasEditableHighlight()
					// keeps reporting an outline that is no longer shown.
					item.editable = false;
					$usbcore.$removeClass( item.highlight, 'usb_editable' );
				}
			}
			self.selectedElmId = null;
		},

		/**
		 * Check whether a specific highlight structure is flagged as editable.
		 *
		 * @param {String} id Shortcode's unique ID (e.g., "us_btn:1")
		 * @return {Boolean} True if marked as editable, false otherwise.
		 */
		hasEditableHighlight: function( id ) {
			return !! ( this._highlights[ id ] || {} ).editable;
		},

		/**
		 * Initialize a MutationObserver to update positions when the target element changes.
		 *
		 * @see https://mozilla.org
		 * @param {String} id Shortcode's unique ID (e.g., "us_btn:1")
		 * @return {MutationObserver|undefined}
		 */
		_getMutationObserver: function( id ) {
			const self = this;
			var target;
			if (
				! $usb.builder.isValidId( id )
				|| ! ( target = self.getElmNode( id ) )
			) {
				return;
			}
			const observer = new MutationObserver( $ush.debounce( self.setHighlightsPosition.bind( self ), 1 ) );
			observer.observe( target, {
				characterData: true,
				childList: true,
				subtree: true
			} );
			return observer;
		},

		/**
		 * Generate or recycle a highlight overlay element for the given ID.
		 *
		 * @param {String} id Shortcode's unique ID (e.g., "us_btn:1")
		 * @return {Object|null} Internal highlight reference metadata or null.
		 */
		_createHighlight: function( id ) {
			const self = this;

			if (
				! $usb.builder.isValidId( id )
				|| self._highlights[ id ]
				|| ! $ush.isNode( self.highlight )
				|| $usb.builder.isAliasElmId( id )
			) {
				return null;
			}

			var highlightElm;
			if ( self._highlightPool && self._highlightPool.length > 0 ) {
				highlightElm = self._highlightPool.pop();
				highlightElm.style.display = 'none';
				highlightElm.className = self.highlight.className;
				// A recycled node keeps the jQuery data cache of the element it was used for before,
				// and `.data()` never re-reads the attribute after the first access. Drop the cache so
				// the `data-elmid` set below is the only source of truth for this node.
				$( highlightElm ).removeData();
			} else {
				highlightElm = self.highlight.cloneNode( true );
				self.highlight.after( highlightElm );
			}

			var dataHighlight = $ush.toPlainObject( $usbcore.$attr( self.getElmNode( id ), 'data-usb-highlight' ) );

			if ( ! $.isPlainObject( dataHighlight ) ) {
				dataHighlight = {};
			}

			highlightElm
				.querySelector( '.usb-hover-panel-name' )
				.innerText = $usb.builder.getElmTitle( id );

			const node = highlightElm.querySelector( '.usb-hover-panel-edit' );
			if ( node ) {
				if ( dataHighlight.edit_permalink && dataHighlight.edit_label ) {
					node.innerText = dataHighlight.edit_label;
					$usbcore.$attr( node, 'href', dataHighlight.edit_permalink );
					node.style.display = '';
				} else {
					node.style.display = 'none';
				}
			}

			const elmType = $usb.builder.getElmType( id );

			$usbcore
				.$attr( highlightElm, 'data-elmid', id )
				.$addClass( highlightElm, `elm_${elmType}` )
				.$toggleClass( highlightElm, 'usb_disable_controls', !! dataHighlight.disable_controls );

			const parentId = $usb.builder.getElmParentId( id );

			if ( $usb.builder.isElmWrapper( id ) && $usb.builder.isElmWrapper( parentId ) ) {
				$usbcore.$addClass( highlightElm, 'offset_panel' );
			}

			var zIndex = 9999;
			if ( $usb.builder.isChildElmContainer( id ) ) {
				zIndex -= 1;
			} else if ( $usb.builder.isRootElmContainer( id ) ) {
				zIndex -= 2;
			}
			highlightElm.style.zIndex = zIndex;

			return self._highlights[ id ] = {
				active: false,
				editable: false,
				highlight: highlightElm,
				MutationObserver: self._getMutationObserver( id )
			};
		},

		/**
		 * Detach highlights from elements and move their DOM nodes back to the recycling pool.
		 *
		 * @param {Boolean} force Enforce clearing of all recorded highlights.
		 */
		removeHighlights: function( force ) {
			const self = this;

			if ( $.isEmptyObject( self._highlights ) ) {
				return;
			}

			if ( ! self._highlightPool ) {
				self._highlightPool = [];
			}

			for ( const elmId in self._highlights ) {
				if ( ! $usb.builder.isValidId( elmId ) ) {
					continue;
				}
				if ( force || self.getElmNode( elmId ) === null ) {
					const data = self._highlights[ elmId ];

					if ( data.MutationObserver instanceof MutationObserver ) {
						data.MutationObserver.disconnect();
					}

					// `.usb_editable` is styled with `display: block !important`, so the inline
					// `display: none` below cannot hide a parked node that still carries the class —
					// the outline of the just deleted element would stay on screen until the node
					// happens to be reused. Reset the node to the template state before pooling it.
					data.highlight.className = self.highlight.className;
					data.highlight.style.display = 'none';
					self._highlightPool.push( data.highlight );

					delete self._highlights[ elmId ];
				}
			}
		},

		// Cached icon glyphs by icon class name, e.g. { "fas fa-code": "\uf121" }
		_iconGlyphs: {},

		/**
		 * Schedule the check of elements without visible output.
		 * NOTE: Only the editable area is checked, so page components (header, footer) are skipped.
		 *
		 * @param {Node} [node] The changed node, the check is limited to it and its children, otherwise the whole editable area is checked
		 */
		checkPlaceholders: function( node ) {
			const self = this;
			const rootContainer = self.elmRootContainer;
			if ( ! $ush.isNode( node ) || node.contains( rootContainer ) ) {
				node = rootContainer;
			} else if ( ! rootContainer.contains( node ) ) {
				return;
			}
			self._placeholderRoots.add( node );
			self._events.markPlaceholders();
		},

		/**
		 * Mark elements without visible output as placeholders, so they can be hovered, selected and dragged.
		 * NOTE: Elements hidden by their parents (inactive tabs, popups) are skipped.
		 */
		markPlaceholders: function() {
			const self = this;
			const className = 'usb_placeholder_elm';
			const rootContainer = self.elmRootContainer;

			const roots = self._placeholderRoots.has( rootContainer )
				? [ rootContainer ]
				: [ ...self._placeholderRoots ].filter( ( node ) => node.isConnected );
			self._placeholderRoots.clear();

			// With the panel hidden builder styles are not applied, so measurements would be wrong
			// NOTE: The whole editable area is checked again when the panel is shown (see `changeSwitchPanel`)
			if ( ! self.$body.hasClass( 'usb_preview' ) ) {
				return;
			}

			// Own changes of placeholders must not be caught as changes of their content
			self._placeholderObserver.disconnect();

			// Reset placeholders to measure the own state of elements
			const resetNode = ( node ) => {
				node.classList.remove( className );
				[ 'data-usb-title', 'data-usb-icon', 'data-usb-icon-set' ].forEach( ( name ) => node.removeAttribute( name ) );
			};
			const nodes = new Set;
			roots.forEach( ( root ) => {
				resetNode( root );
				if ( root.hasAttribute( 'data-usbid' ) ) {
					nodes.add( root );
				}
				root.querySelectorAll( `.${className}` ).forEach( resetNode );
				root.querySelectorAll( '[data-usbid]' ).forEach( ( node ) => {
					nodes.add( node );
				} );
			} );

			// READ PHASE: measure all elements before any class is added
			const emptyNodes = [ ...nodes ].filter( ( node ) => {
				const id = $usbcore.$attr( node, 'data-usbid' );
				return (
					$usb.builder.isValidId( id )
					&& ! $usb.builder.isAliasElmId( id )
					&& ! $usb.builder.isElmContainer( id )
					&& node.parentElement.getClientRects().length > 0
					&& self._hasNoOutput( node )
				);
			} );

			// Icons are loaded before any class is added, so styles are recalculated only once
			const items = emptyNodes.map( ( node ) => {
				const id = $usbcore.$attr( node, 'data-usbid' );
				return {
					id,
					node,
					iconClass: $usb.config( `elm_icons.${$usb.builder.getElmName( id )}`, '' ),
				};
			} );
			self._loadIconGlyphs( items.map( ( item ) => item.iconClass ) );

			// WRITE PHASE
			items.forEach( ( { id, node, iconClass } ) => {
				const icon = self._iconGlyphs[ iconClass ];

				node.classList.add( className );
				$usbcore.$attr( node, 'data-usb-title', $usb.builder.getElmTitle( id ) );
				if ( icon ) {
					$usbcore
						.$attr( node, 'data-usb-icon', icon )
						.$attr( node, 'data-usb-icon-set', iconClass.split( ' ' )[0] );
				}
			} );

			// Watch all placeholders, including the ones outside the checked nodes
			rootContainer.querySelectorAll( `.${className}` ).forEach( ( node ) => {
				self._placeholderObserver.observe( node, {
					attributeFilter: [ 'class', 'style', 'hidden' ],
					characterData: true,
					childList: true,
					subtree: true,
				} );
			} );

			// Placeholders change the size of elements
			self.setHighlightsPosition();
		},

		/**
		 * Check if the element has no visible output.
		 *
		 * @param {Node} node The element node
		 * @return {Boolean} True if nothing is rendered, otherwise false
		 */
		_hasNoOutput: function( node ) {
			const hasBox = ( node ) => {
				const rect = node.getBoundingClientRect();
				return rect.width > 0 && rect.height > 0;
			};

			// Media may have zero size until loaded (e.g. lazy images without dimensions), so a rendered one is an output
			const isRenderedMedia = ( node ) => [ 'IMG', 'PICTURE', 'VIDEO', 'IFRAME', 'svg' ].includes( node.nodeName ) && node.getClientRects().length > 0;

			// Hidden by own CSS (`display: none`), so descendants can't be visible either
			if ( ! node.getClientRects().length ) {
				return true;
			}

			// Zero size (e.g. empty), but descendants may still be visible (absolute, floats)
			if ( ! hasBox( node ) ) {
				return ! Array.prototype.some.call( node.querySelectorAll( '*' ), ( child ) => hasBox( child ) || isRenderedMedia( child ) );
			}

			// The element has a size (e.g. `min-height`), but its children are never rendered, e.g. Custom HTML with <script>
			return node.children.length > 0 && Array.prototype.every.call( node.childNodes, ( child ) => {
				if ( child.nodeType === Node.ELEMENT_NODE ) {
					return [ 'SCRIPT', 'STYLE', 'TEMPLATE', 'NOSCRIPT', 'LINK' ].includes( child.nodeName );
				}
				return child.nodeType !== Node.TEXT_NODE || ! child.data.trim();
			} );
		},

		/**
		 * Load glyphs of Font Awesome icons to show them via CSS `content: attr()`.
		 * NOTE: All icons are added at once, so styles are recalculated only once.
		 *
		 * @param {String[]} iconClasses The icon class names, e.g. [ "fas fa-code" ]
		 */
		_loadIconGlyphs: function( iconClasses ) {
			const self = this;
			// Icon sets disabled in Theme Options have no font, so their glyphs can't be shown
			const availableIconSets = $usb.config( 'available_icon_sets', [] );
			const icons = [];
			new Set( iconClasses ).forEach( ( iconClass ) => {
				if ( ! $ush.isUndefined( self._iconGlyphs[ iconClass ] ) ) {
					return;
				}
				const iconSet = iconClass.split( ' ' )[0];
				// Placeholders have fonts for these sets only (see builder-preview.css)
				if ( ! [ 'fas', 'far', 'fab' ].includes( iconSet ) || ! availableIconSets.includes( iconSet ) ) {
					self._iconGlyphs[ iconClass ] = '';
					return;
				}
				const icon = _document.createElement( 'i' );
				icon.className = iconClass;
				icons.push( icon );
			} );
			if ( ! icons.length ) {
				return;
			}
			_document.body.append( ...icons );
			icons.forEach( ( icon ) => {
				// The content is returned with quotes, e.g. `"\uf121"`, or `none` for unknown icons
				const content = _window.getComputedStyle( icon, '::before' ).content;
				self._iconGlyphs[ icon.className ] = /^["'].+["']$/.test( content ) ? content.slice( 1, -1 ) : '';
			} );
			icons.forEach( ( icon ) => icon.remove() );
		}
	} );

	/**
	 * Functionality for handle events
	 */
	$.extend( USBPreview.prototype, {

		/**
		 * The event fires when the initial HTML document has been completely loaded and parsed,
		 * without waiting for stylesheets, images, and subframes to finish load.
		 */
		_DOMContentLoaded: function() {
			this.$body.addClass( 'usb_content_ready' );
			this.checkPlaceholders();
		},

		/**
		 * Link click handler.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_linkClickHandler: function( e ) {
			const self = this;
			const $target = $( e.currentTarget );
			const href = $ush.toLowerCase( $target.attr( 'href' ) || '' );

			// Anyth to exclude from open in a new window
			if (
				href.charAt(0) == '#'
				|| href.substr( 0, 'javascript:'.length ) == 'javascript:'
				|| $target.is( '[ref=magnificPopup]' )
				|| $target.hasClass( '.w-tabs-item' ) // exclude all TTA buttons
			) {
				return;
			}

			e.preventDefault();
			e.stopPropagation();

			_window.open( href, '_blank' );
		},

		/**
		 * Handler for start css animation in element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmAnimationStart: function( e ) {
			const self = this;
			if ( ! $usbcore.$attr( e.target, 'data-usbid' ) ) {
				return;
			}
			if ( self.selectedElmId ) {
				self.hideEditableHighlight();
			}
		},

		/**
		 * Handler for end css animation in element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmAnimationEnd: function( e ) {
			const self = this;
			if ( ! $usbcore.$attr( e.target, 'data-usbid' ) ) {
				return;
			}
			if ( $usb.builder.isValidId( self.selectedElmId ) ) {
				self.showEditableHighlight( self.selectedElmId );
				self.setHighlightsPosition();
			}
		},

		/**
		 * Handles cursor leaving the iframe window.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_mouseLeavesIframe: function( e ) {
			const self = this;
			if ( $usb.panel.isVisible() ) {
				self.hideHighlight();
			}
			self.clearDragData( /* keepData */true );
		},

		/**
		 * Selected element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmSelected: function( e ) {
			const self = this;

			// Check the `editor` mode (Only in mode we can select elements to change)
			if (
				! $usb.builder.isMode( 'edit' )
				|| ! $usb.panel.isVisible()
				|| $usbcore.$hasClass( e.target, 'usb_skip_elmSelected' )
			) {
				return;
			}

			const node = self._getNearestNode( e.target );
			if ( ! $ush.isNode( node ) ) {
				return;
			}

			var elmId = $usb.builder.getElmId( node );
			if ( $usb.builder.isAliasElmId( elmId ) ) {
				elmId = $usb.builder.removeAliasFromId( elmId );
			}
			self.selectedElmId = elmId;

			self.postMessage( 'builder.elmSelected', elmId );
			self.postMessage( 'navigator.scrollTo', elmId );
			self.showEditableHighlight( elmId );
		},

		/**
		 * Handler when the cursor enters the bounds of an element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmMove: function( e ) {
			const self = this;
			if ( ! $usb.panel.isVisible() ) {
				return;
			}

			const element = self._getNearestNode( e.target );
			if ( element && element !== self.hoveredElm ) {
				self.hideHighlight();
				self.hoveredElm = element;
				self.hoveredElmId = $usb.builder.getElmId( element );
				self.showHighlight();
			}
		},

		/**
		 * Handler when the cursor moves out of the bounds of an element.
		 *
		 * @param {Event} e
		 */
		_elmLeave: function( e ) {
			const self = this;
			if ( ! $usb.panel.isVisible() ) {
				return;
			}
			if ( $ush.isNode( self._getNearestNode( e.target ) ) ) {
				self.hoveredElm = null;
				self.hoveredElmId = null;
			}
		},

		/**
		 * Creates a duplicate of an element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmDuplicate: function( e ) {
			const self = this;
			const $highlight = $( e.currentTarget ).closest( '.usb-hover' );
			const elmId = $usbcore.$attr( $highlight[0], 'data-elmid' );
			if ( ! elmId ) {
				return;
			}
			self.postMessage( 'navigator.showPreloader', elmId );
			self.postMessage( 'builder.elmDuplicate', elmId );
		},

		/**
		 * Remove the class for the copy button, used instead of timeout to simplify logic.
		 *
		 * NOTE: The code is moved to a separate function since `debounced` must be initialized before call.
		 *
		 * @param {Function} fn The function to be executed
		 * @type debounced
		 */
		__removeClassInCopiedElm: $ush.debounce( $ush.fn, 1000 * 4 ),

		/**
		 * Copy shortcode to clipboard.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmCopy: function( e ) {
			const self = this;
			const $target = $( e.currentTarget );
			const elmId = $usbcore.$attr( $target.closest( '.usb-hover' )[0], 'data-elmid' );
			if ( ! elmId ) {
				return;
			}
			self.postMessage( 'builder.elmCopy', elmId );

			$target.addClass( 'copied' );

			self.__removeClassInCopiedElm( () => $target.removeClass( 'copied' ) );
		},

		/**
		 * Paste shortcode to content.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmPaste: function( e ) {
			const elmId = $usbcore.$attr( $( e.currentTarget ).closest( '.usb-hover' )[0], 'data-elmid' );
			if ( elmId ) {
				this.postMessage( 'builder.elmPaste', elmId );
			}
		},

		/**
		 * Removes an element.
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_elmDelete: function( e ) {
			const self = this;
			const elmId = $usbcore.$attr( $( e.currentTarget ).closest( '.usb-hover' )[0], 'data-elmid' );
			if ( elmId ) {
				// The highlight entry may already be pruned by removeHighlights() (element node
				// replaced or removed) — its absence must not block deleting the element itself.
				const item = self._highlights[ elmId ];
				if ( item ) {
					if ( item.MutationObserver instanceof MutationObserver ) {
						item.MutationObserver.disconnect();
					}
					$usbcore.$remove( item.highlight || null );
					delete self._highlights[ elmId ];
				}
				self.postMessage( 'builder.elmDelete', elmId );
			}
		},

		/**
		 * Opens popup "Save to favorites".
		 *
		 * @event handler
		 * @param {Event} e
		 */
		_saveToFavorites: function( e ) {
			const elmId = $usbcore.$attr( $( e.currentTarget ).closest( '.usb-hover' )[0], 'data-elmid' );
			if ( elmId ) {
				this.postMessage( 'favorites.saveToFavorites', elmId );
			}
		}
	});

	/**
	 * Functionality for the implementation of Design options
	 * TODO: Make refactoring and transfer functionality to $usb.cssCompiler()
	 */
	$.extend( USBPreview.prototype, {
		/**
		 * Delayed start of CSS animation
		 *
		 * NOTE: The code is moved to a separate function since `debounced` must be initialized before call
		 *
		 * @type debounced
		 */
		__startAnimation: $ush.debounce( function( node ) {
			$usbcore.$addClass( node, 'start' );
		}, 1 ),

		/**
		 * Add or update custom styles in a document
		 *
		 * @param {String} id Shortcode's usbid, e.g. "us_btn:1"
		 * @param {String} jsoncss The line of design settings from the $usof.field[ 'design_options' ]
		 * @param {{}} specificClasses List of specific classes that will be added if there is a value by key name
		 */
		_addDesignOptions: function( id, jsoncss, specificClasses ) {
			const self = this;

			var $style;

			if ( ! $usb.builder.isValidId( id ) ) {
				return;
			}

			jsoncss += '';

			// Find element of styles for shortcode
			_document.querySelectorAll( `style[data-for="${id}"][data-classname]` ).forEach( ( style, i ) => {
				if ( i === 0 ) {
					return $style = style;
				}
				$usbcore.$remove( style );
			} );

			// Get animated properties in one line
			const getAnimateProps = ( node ) => {
				if ( ! $ush.isNode( node ) ) {
					return;
				}
				var style = _window.getComputedStyle( node ),
					name = style.getPropertyValue( 'animation-name' ),
					delay = style.getPropertyValue( 'animation-delay' );
				if ( name && name !== 'none' ) {
					return name + delay;
				}
				return;
			};

			var node = self.getElmNode( id );

			// Get the first child for the Button element only
			if ( $usb.builder.getElmType( id ) === 'us_btn' && $ush.isNode( node ) ) {
				node = node.firstChild || node;
			}

			// Apply Design settings to the section content only, to match the frontend output
			if ( $usb.builder.getElmType( id ) === 'vc_tta_section' && $ush.isNode( node ) ) {
				node = node.querySelector( ':scope > .w-tabs-section-content' ) || node;
			}
			if ( $usb.builder.getElmType( id ) === 'us_timeline_section' && $ush.isNode( node ) ) {
				node = node.querySelector( ':scope > .w-timeline-section-h > .w-timeline-section-content' ) || node;
			}

			// If there is no style element then create a new one
			if ( ! $style ) {
				var // Custom prefix
					customPrefix = $usb.config( 'designOptions.customPrefix', 'us_custom_' ),
					// Generate unique class name
					className = $ush.uniqid( customPrefix );
				// If the element is absent then we will complete the action
				if ( ! $ush.isNode( node ) ) {
					return;
				}
				$style = $( '<style data-for="'+ id +'" data-classname="'+ className +'"></style>' )[0];
				// Add a new style element to the page
				node.before( $style );
				// Remove the old custom class in the absence of a style element `<style data-for="..." data-classname="..."></style>`
				if ( node.className.indexOf( customPrefix ) > -1 ) {
					node.className = node.className.replace(
						new RegExp( '(' + $ush.escapePcre( customPrefix ) + '\\w+)' ),
						''
					);
				}

				$usbcore.$addClass( node, className );
			}

			// Text Style assigns the classes of the style created on Theme Options, including its Extra class
			if ( $ush.isNode( node ) ) {
				const oldTextStyle = ( node.className.match( /(?:^|\s)us-text-style_([\w-]+)/ ) || [] )[1];
				if ( oldTextStyle ) {
					// Note: the classes, which the element also has in its own Extra class, stay
					const elmClasses = $ush.toString( $usb.builder.getElmValue( id, 'el_class', '' ) ).split( /\s+/ );
					$usb.config( `text_styles.${oldTextStyle}.class`, 'us-text-style_' + oldTextStyle ).split( /\s+/ ).forEach( ( className ) => {
						if ( ! elmClasses.includes( className ) ) {
							$usbcore.$removeClass( node, className );
						}
					} );
				}
				const textStyle = self._getTextStyle( jsoncss );
				if ( textStyle ) {
					// Note: the unknown styles get no class, same as on the frontend
					$usb.config( `text_styles.${textStyle}.class`, '' ).split( /\s+/ ).forEach( ( className ) => {
						$usbcore.$addClass( node, className );
					} );
				}
			}

			// Determine the presence of an animation name
			var hasAnimateName = jsoncss.indexOf( 'animation-name' ) > -1,
				oldAnimateProp;

			// Compile and add styles to document
			if ( $style ) {
				var _className = $usbcore.$attr( $style, 'data-classname' );
				// If there are animation settings, keep the old value
				if ( hasAnimateName ) {
					oldAnimateProp = getAnimateProps( node );
				}
				$style.innerText = self.setDesignStyles( _className, jsoncss );
			}

			// Check classes and restart animation
			if ( hasAnimateName ) {
				var currentAnimateProps = getAnimateProps( node );
				if ( currentAnimateProps && currentAnimateProps !== oldAnimateProp ) {
					// Adjust classes for normal animation work
					$usbcore.$addClass( node, 'us_animate_this' );
					$usbcore.$removeClass( node, 'start' );
					// Delayed start of CSS animation
					self.__startAnimation( node );
				}

			} else if ( $usbcore.$hasClass( node, 'us_animate_this' ) ) {
				$usbcore.$removeClass( node, 'us_animate_this start' );
			}

			// Switch specific design classes depend on the given properties
			self._toggleDesignSpecificClasses.apply( self, arguments );
		},

		/**
		 * Remove design styles for elements that do not exist
		 */
		_removeDesignForElmsNotExist: function() {
			const self = this;
			_document.querySelectorAll( 'style[data-for]' ).forEach( ( style ) => {
				const id = $usbcore.$attr( style, 'data-for' );
				if ( id && self.getElmNode( id ) === null ) {
					$usbcore.$remove( style );
				}
			} );
		},

		/**
		 * Remove style tag by element ID
		 *
		 * @param {String} id Shortcode's usbid, e.g. "us_btn:1"
		 */
		_removeDesignById: function( id ) {
			_document.querySelectorAll( `style[data-for="${id}"]` ).forEach( ( style ) => {
				$usbcore.$remove( style );
			} );
		},

		/**
		 * Set design styles to document,
		 *
		 * @param {String} className The unique name of the class attached to the element
		 * @param {{}} jsoncss The jsoncss object
		 * @return {String} Compiled css string
		 */
		setDesignStyles: function( className, jsoncss ) {
			const self = this;
			const collections = {};

			jsoncss = $ush.toPlainObject( jsoncss );
			if ( $.isEmptyObject( jsoncss ) ) {
				return '';
			}

			// Create a collection for different screens
			$usb.config( 'responsiveStates', [] ).map( ( screen ) => {
				if ( !! jsoncss[ screen ] ) {
					collections[ screen ] = self._normalizeJsoncss( jsoncss[ screen ] );
				}
			} );

			var result = '';

			// Generates result
			for ( const screen in collections ) {
				if ( $.isEmptyObject( collections[ screen ] ) ) {
					continue;
				}
				var inlineCss = '', // final inline css
					collection = self._buildBackground( collections[ screen ] ),
					breakpoint = $usb.config( `designOptions.breakpoints.${screen}`, '' );
				// Collection to inline css
				for ( var prop in collection ) {
					var value = collection[ prop ];
					if ( ! prop || ! value ) {
						continue;
					}
					inlineCss += prop + ':' + value + '!important;';
					// Cancel transparency for an element without animation
					// when using animation on different screens
					if ( prop === 'animation-name' && value === 'none' ) {
						inlineCss += 'opacity:1!important;';
					}
				}
				if ( inlineCss ) {
					inlineCss = '.' + className + '{' + inlineCss + '}';
				}
				result += ( breakpoint )
					? '@media ' + breakpoint + ' {' + inlineCss + '}'
					: inlineCss;
			}
			return result;
		},

		/**
		 * This helper method is for normalize css options ( jsoncss option -> css option )
		 * TODO: Minimal functionality provide only style applications without optimizations
		 *
		 * @param {{}} cssOptions The css options
		 * @return {{}}
		 */
		_normalizeJsoncss: function( options ) {
			const self = this;

			if ( $.isEmptyObject( options ) ) {
				return options;
			}

			// For background-image get an image URL by attachment ID (Preliminary check)
			if ( !! options[ 'background-image' ] ) {
				const url = $usb.getAttachmentUrl( options[ 'background-image' ] );
				if ( !! url ) {
					options[ 'background-image' ] = `url(${url})`;
				}
			}

			// Normalization of css parameters
			for ( var prop in options ) {
				if ( ! prop || ! options[ prop ] ) {
					continue;
				}

				// Params with the "_" prefix are not css properties, e.g. `_text_style`
				if ( prop.indexOf( '_' ) === 0 ) {
					delete options[ prop ];
					continue;
				}
				var value = options[ prop ];

				/**
				 * If the name contains the text color and the values start from the underscore,
				 * try to get the css variable
				 *
				 * Example: color, background-color, border-color, box-shadow-color etc
				 */
				if ( /(^color|-color$)/.test( prop ) ) {
					value = usofColorAPI.valueToPreview( value );
					// Remove gradient for text color
					if ( prop == 'color' && usofColorAPI.isGradient( value ) ) {
						value = value.replace( '-grad', '' );
					}
					options[ prop ] = value;
				}

				// Generate correct font-family value
				if ( prop === 'font-family' ) {
					var font_name = $usb.config( `designOptions.fontVars.${value}`, value );

					// Add quotes, if custom font is uploaded
					if ( value.indexOf( ' ' ) > -1 && value.indexOf( ',' ) == -1 ) {
						font_name = '"' + font_name + '"';
					}
					options[ prop ] = font_name;
				}
				// border-style to border-{position}-style provided that there is a width of this border
				if ( prop === 'border-style' ) {
					[ 'left', 'top', 'right', 'bottom' ].map( ( position ) => {
						var borderWidth = options[ `border-${position}-width` ];
						if ( ! $ush.isUndefined( borderWidth ) && borderWidth !== '' ) {
							options[ `border-${position}-style` ] = '' + value;
						}
					} );
					delete options[ prop ];
				}
				// Check for line space
				if ( prop === 'font-height' ) {
					if ( !! value ) {
						options[ 'line-height' ] = value;
					}
					delete options[ prop ];
				}
			}

			// Form `box-shadow` from the list of parameters
			if (
				!! options
				&& (
					!! options[ 'box-shadow-h-offset' ]
					|| !! options[ 'box-shadow-v-offset' ]
					|| !! options[ 'box-shadow-blur' ]
					|| !! options[ 'box-shadow-spread' ]
				)
			) {
				var _boxShadow = [];
				// Value map for `box-shadow` this map is needed to turn the list into a string,
				// the order is also very important here!
				[ 'h-offset', 'v-offset', 'blur', 'spread', 'color' ].map( ( key ) => {
					var value = options[ `box-shadow-${key}` ];
					if ( $ush.isUndefined( value ) ) {
						value = ( key === 'color' )
							? 'currentColor' // the default color
							: '0';
					}
					_boxShadow.push( value );
					delete options[ `box-shadow-${key}` ];
				} );
				if ( _boxShadow.length ) {
					options[ 'box-shadow' ] = _boxShadow.join( ' ' );
				}
			}

			// Form `text-shadow` from the list of parameters
			if (
				!! options
				&& (
					!! options[ 'text-shadow-h-offset' ]
					|| !! options[ 'text-shadow-v-offset' ]
					|| !! options[ 'text-shadow-blur' ]
				)
			) {
				var _textShadow = [];
				// Value map for `text-shadow` this map is needed to turn the list into a string,
				// the order is also very important here!
				[ 'h-offset', 'v-offset', 'blur', 'color' ].map( ( key ) => {
					var value = options[ `text-shadow-${key}` ];
					if ( $ush.isUndefined( value ) ) {
						value = ( key === 'color' )
							? 'currentColor' // the default color
							: '0';
					}
					_textShadow.push( value );
					delete options[ `text-shadow-${key}` ];
				} );
				if ( _textShadow.length ) {
					options[ 'text-shadow' ] = _textShadow.join( ' ' );
				}
			}

			return options;
		},

		/**
		 * Build background CSS property.
		 *
		 * @link https://www.w3.org/TR/css-backgrounds-3/#background
		 *
		 * @param {{}} collection The collection.
		 * @return {{}} Returns a collection of properties.
		 */
		_buildBackground: function( collection ) {
			const self = this;
			collection = $ush.toPlainObject( collection );
			// NOTE: do not change the order!
			var names = [ 'color', 'image', 'repeat', 'attachment', 'position', 'size' ],
				props = {},
				background = '';
			// Set properties by mask names
			for ( var i in names ) {
				var name = names[ i ],
					propName = 'background-' + name;
				if ( collection[ propName ] ) {
					props[ name ] = collection[ propName ];
					delete collection[ propName ];
				}
			}
			var colorGradient = '';
			if ( props['image'] && usofColorAPI.isGradient( props['color'] ) ) {
				colorGradient = props['color'];
				delete props['color'];
			}
			if ( props['size'] ) {
				// Set the size and position in the desired order
				if ( ! props['position'] ) {
					props['position'] = 'left top';
				}
				props['size'] = '/ ' + props['size'];
			}
			for ( var i in names ) {
				var name = names[ i ];
				if ( props[ name ] ) {
					background += ' ' + props[ name ];
				}
			}
			// Set the gradient
			if ( colorGradient ) {
				background += ', ' + colorGradient;
			}
			collection[ 'background' ] = background.trim();
			return collection;
		},

		/**
		 * Switch specific design classes depend on the given properties
		 *
		 * @param {String} id Shortcode's usbid, e.g. "us_btn:1"
		 * @param {String} jsoncss The line of design settings from the $usof.field[ 'design_options' ]
		 * @param {{}} specificClasses List of specific classes that will be added if there is a value by key name
		 */
		_toggleDesignSpecificClasses: function( id, jsoncss, specificClasses ) {
			const self = this;

			if ( ! $.isPlainObject( specificClasses ) ) {
				return {};
			}

			var node = self.getElmNode( id );

			// Get the first child for the Button element only
			if ( $usb.builder.getElmType( id ) === 'us_btn' && $ush.isNode( node ) ) {
				node = node.firstChild || node;
			}

			// Apply Design settings to the section content only, to match the frontend output
			if ( $usb.builder.getElmType( id ) === 'vc_tta_section' && $ush.isNode( node ) ) {
				node = node.querySelector( ':scope > .w-tabs-section-content' ) || node;
			}
			if ( $usb.builder.getElmType( id ) === 'us_timeline_section' && $ush.isNode( node ) ) {
				node = node.querySelector( ':scope > .w-timeline-section-h > .w-timeline-section-content' ) || node;
			}

			// The props of the assigned Text Style affect the element the same way as its own ones
			const textStyle = self._getTextStyle( jsoncss ),
				styleProps = textStyle ? $usb.config( `text_styles.${textStyle}.props`, [] ) : [];

			if ( jsoncss ) {
				jsoncss = unescape( '' + jsoncss ) || '{}';
			}

			for ( const prop in specificClasses ) {
				const state = (
					jsoncss.indexOf( '"'+ prop +'"' ) > -1
					|| styleProps.indexOf( prop ) > -1
				);
				$usbcore.$toggleClass( node, specificClasses[ prop ], state );
			}
		},

		/**
		 * Get the Text Style assigned in Design settings
		 * Note: the value may be a number when the settings are pasted or imported
		 *
		 * @param {String} jsoncss The line of design settings from the $usof.field[ 'design_options' ]
		 * @return {String} Returns the style ID, empty if no style is assigned
		 */
		_getTextStyle: function( jsoncss ) {
			return $ush.toString( ( $ush.toPlainObject( jsoncss ).default || {} )['_text_style'] ).trim();
		},
	} );

	/**
	 * Functionality for the implementation of Main API
	 */
	$.extend( USBPreview.prototype, {

		/**
		 * Detects cursor position within the element’s inner border area.
		 *
		 * @param {Node} target Target DOM node.
		 * @param {number} clientX Cursor X-coordinate.
		 * @param {number} clientY Cursor Y-coordinate.
		 * @param {number} [borderSize=5] Inner border size in pixels.
		 * @returns {string} Active edge direction or UNKNOWN if outside.
		 *
		 * TODO:Optimize and simplify logic.
		 */
		getCursorOnTargetBorder: function( target, clientX, clientY, borderSize ) {
			const self = this;
			if (
				! $ush.isNode( target )
				|| target === self.elmRootContainer
				|| typeof clientX !== 'number'
				|| typeof clientY !== 'number'
			) {
				return DIRECTION.UNKNOWN;
			}

			var // Get sizes — getBoundingClientRect returns viewport-relative coords
				elmRect = $ush.$rect( target ),
				elmLeft = floor( elmRect.x ),
				elmTop = floor( elmRect.y ),
				elmRight = floor( elmLeft + elmRect.width ),
				elmBottom = floor( elmTop + elmRect.height );

			// If the value is not a number, then set the default value
			if ( typeof borderSize !== 'number' ) {
				borderSize = 5;
			}

			// Top border
			if ( clientY > elmTop && clientY <= ( elmTop + borderSize ) ) {
				return DIRECTION.TOP;
			}
			// Bottom border
			else if ( clientY < elmBottom && clientY >= ( elmBottom - borderSize ) ) {
				return DIRECTION.BOTTOM;
			}
			// Left border
			else if ( clientX > elmLeft && clientX <= ( elmLeft + borderSize ) ) {
				return DIRECTION.LEFT;
			}
			// Right border
			else if ( clientX < elmRight && clientX >= ( elmRight - borderSize ) ) {
				return DIRECTION.RIGHT;
			}

			return DIRECTION.UNKNOWN;
		},

		/**
		 * Calculates cursor direction relative to the target element center.
		 *
		 * @param {Node} target Reference DOM node.
		 * @param {number} clientX Cursor X-coordinate.
		 * @param {number} clientY Cursor Y-coordinate.
		 * @param {'x'|'y'} axis Axis used for direction detection.
		 * @returns {string} Direction constant (LEFT, RIGHT, TOP, BOTTOM).
		 *
		 * Direction mapping:
		 *  -180        -90         0         90        180
		 *   LEFT       TOP       CENTER    BOTTOM     RIGHT
		 *
		 * TODO: Replace with $ush.getCursorDirection().
		 */
		getCursorSector: function( target, clientX, clientY, axis ) {
			// Check if the target is a node
			if ( ! $ush.isNode( target ) ) {
				return DIRECTION.UNKNOWN;
			}
			const self = this;
			// Radius to Degree
			const  RAD_TO_DEG = 180 / Math.PI;
			// Get the size of the container and its position relative to the viewport
			const rect = $ush.$rect( target );
			// Get the center of the container
			const center = {
				x: rect.width / 2 + rect.left,
				y: rect.height / 2 + rect.top
			};
			// Get a vector relative to the target (container)
			const vector = {
				x: clientX - center.x,
				y: clientY - center.y
			};
			// Get a vector length
			const vectorLength = Math.sqrt( vector.x * vector.x + vector.y * vector.y );
			// Get a directions
			const direction = {
				x: vector.x / vectorLength,
				y: vector.y / vectorLength
			};
			// Get current cursor movement angle
			const angle = Math.atan2( direction.y, direction.x ) * RAD_TO_DEG;

			// Get the name of the axis on which you want to get directions
			if ( $usbcore.indexOf( axis, AXIS_2D ) < 0 ) {
				axis = AXIS_2D.Y;
			}
			// Definition by x-axis
			if ( axis === AXIS_2D.X ) {
				return ( angle > -180 && angle <= -130 || angle <= 180 && angle > 130 )
					? DIRECTION.LEFT
					: DIRECTION.RIGHT;
			}
			// Definition by y-axis ( default )
			return ( angle < 0 )
				? DIRECTION.TOP
				: DIRECTION.BOTTOM;
		},

		/**
		 * Determines if coordinates are inside a node
		 *
		 * @param {Node} node The node
		 * @param {Number} pageX The X coordinate of the mouse pointer relative to the whole document
		 * @param {Number} pageY The Y coordinate of the mouse pointer relative to the whole document
		 * @return {Boolean} True if inside node, False otherwise
		 */
		isInsideNode: function( node, pageX, pageY ) {
			if (
				! $ush.isNode( node )
				|| $ush.isUndefined( pageX )
				|| $ush.isUndefined( pageY )
			) {
				return false;
			}
			var nodeRect = $ush.$rect( node ),
				offsetTop = ( nodeRect.x + _window.scrollX ),
				offsetLeft = ( nodeRect.y + _window.scrollY );
			return (
				pageX >= offsetTop
				&& pageX <= ( offsetTop + nodeRect.width )
				&& pageY >= offsetLeft
				&& pageY <= ( offsetLeft + nodeRect.height )
			);
		},

		/**
		 * Get the nearest node
		 *
		 * NOTE: The method is called many times, so performance is important here!
		 *
		 * @param {Node} node The node
		 * @param {String} asContainer Filter to get the desired container, the follow values are available:
		 *     `any|root|child`
		 * @return {*} Returns the node or `null` on failure
		 */
		_getNearestNode: function( node, asContainer ) {
			const self = this;
			const args = arguments;

			if ( ! $ush.isNode( node ) ) {
				return null;
			}

			var foundId;

			// Finds the first ID in the node tree
			while ( ! ( foundId = $usbcore.$attr( node, 'data-usbid' ) ) ) {
				if ( ! node.parentNode ) {
					return null;
				}
				node = node.parentNode;
			}
			// If the filter is not set, then return the element if found
			if ( ! asContainer ) {
				return self.getElmNode( foundId || $usb.builder.rootContainer );
			}
			// Check the correctness of the filter
			if ( $usbcore.indexOf( asContainer, CONTAINER_TYPE ) < 0 ) {
				$usb.log( 'Error: The asContainer value is invalid:', args );
				return null;
			}

			// Get the id of the element that matches the filters
			const _filter = function( currentId ) {
				const args = arguments;
				const parentId = $usb.builder.getElmParentId( currentId );
				if ( ! parentId ) {
					return null;
				}
				var recursionLevel = $ush.parseInt( args[1] );
				if ( recursionLevel >= 20 ) {
					$usb.log( 'Notice: Exceeded number of levels in recursion:', args );
					return null;
				}
				if (
					// Any first container
					( asContainer === CONTAINER_TYPE.ANY && $usb.builder.isElmContainer( parentId ) )
					// Root container, for example: vc_row, vc_row_inner, vc_tabs etc
					|| ( asContainer === CONTAINER_TYPE.ROOT && $usb.builder.isRootElmContainer( parentId ) )
					// Child container, for example: vc_column, vc_column_inner, vc_tta_section, etc
					|| ( asContainer === CONTAINER_TYPE.CHILD && $usb.builder.isChildElmContainer( parentId ) )
				) {
					return parentId;
				}
				// Recursively check the prev parent
				return _filter( parentId, recursionLevel++ );
			};

			return self.getElmNode( _filter( foundId ) || $usb.builder.rootContainer );
		},

		/**
		 * Get the target element
		 *
		 * @param {String} targetId Shortcode's usbid, e.g. "us_btn:1" or `root_container`
		 * @param {String} position The position
		 * @return {*}
		 */
		_getTargetElm: function( targetId, position ) {
			const self = this;

			// Check the correctness of the data in the variables
			if (
				! targetId
				|| ! $usb
				|| ! [ 'before', 'prepend', 'append', 'after' ].includes( position )
			) {
				return;
			}

			const isRootContainer = $usb.builder.isRootContainer( targetId );

			// TODO:Optimize and implement without jQuery
			var $element = $( self.getElmNode( isRootContainer ? $usb.builder.rootContainer : targetId ) );

			if ( [ 'before', 'after' ].includes( position ) ) {
				return $element;
			}

			/**
			 * NOTE: All searches for the location of the root element
			 * are strictly tied to the structure and classes.
			 */
			if ( ! isRootContainer && $element.length ) {
				const rootSelector = $usb.config( 'rootContainerSelectors.' + $usb.builder.getElmName( targetId ) );

				if ( rootSelector ) {

					// Find element by selector, example: ".container, .container > *"
					const $newElement = $( rootSelector, $element ).first();

					if ( $newElement.length ) {
						$element = $newElement;
					}
				}
			}

			return $element;
		},

		/**
		 * Get an node or nodes by ID
		 * NOTE: The method is called many times, so performance is important here!
		 *
		 * @param {String|[]} id Shortcode's usbid, e.g. "us_btn:1"
		 * @return {null|Node|[Node...]}
		 */
		getElmNode: function( id ) {
			const self = this;

			if ( ! id ) {
				return;
			}

			var ids = id;

			// The convert to a single type to data
			if ( ! Array.isArray( ids ) ) {
				ids = [ ids ];
			}

			// Check if the ID's is correct
			ids = ids.filter( ( id ) => {
				return $usb.builder.isValidId( id ) || $usb.builder.isRootContainer( id );
			} );

			// Convert ID's to selectors
			ids = ids.map( ( id ) => {
				return `[data-usbid="${id}"]`;
			} );

			// The get one node
			if ( $.type( id ) === 'string' && ids.length === 1 ) {
				return _document.querySelector( ids[0] );

			}
			// The get an array of nodes
			if ( Array.isArray( id ) && ids.length ) {
				return $ush.toArray( _document.querySelectorAll( ids.join( ',' ) ) );
			}

			return null;
		},

		/**
		 * Get all html for a node include styles
		 *
		 * @param {String|[]} id Shortcode's usbid, e.g. "us_btn:1"
		 * @return {String}
		 */
		getElmOuterHtml: function( id ) {
			const node = this.getElmNode( id );
			if ( $ush.isNode( node ) ) {
				return ( ( _document.querySelector( `style[data-for="${id}"]` ) || {} ).outerHTML || '' ) + node.outerHTML;
			}
			return '';
		},

		/**
		 * Determines whether the specified identifier is hidden tab.
		 *
		 * @param {String} id The id e.g. "vc_tta_section:1".
		 * @return {Boolean} True if the specified identifier is hidden tab, False otherwise.
		 */
		tabIsHidden: function( id ) {
			return $usb.builder.isElmSection( id ) && ! $( '.w-tabs-section-content:first', this.getElmNode( id ) ).is( ':visible' );
		},

		/**
		 * Opens a section by ID
		 *
		 * @param {String} id The id e.g. "vc_tta_section:1"
		 */
		openSectionById: function( id ) {
			const self = this;
			if ( self.tabIsHidden( id ) ) {
				$( '.w-tabs-section-header:first', self.getElmNode( id ) ).trigger( 'click' );
			}
		},

		/**
		 * Scroll to an item if it is outside the window
		 *
		 * @param {String} id The id e.g. "vc_row:1"
		 */
		scrollToOutsideElm: function( id ) {
			const self = this;
			if ( ! $usb.builder.isValidId( id ) ) {
				return;
			}
			// Get the node and
			var node = self.getElmNode( id );
			if ( ! $ush.isNode( node ) ) {
				return;
			}
			// If the element is not outside the view, then exit
			const rect = $ush.$rect( node );
			if (
				! ( rect.top < 0 || rect.bottom > ( _window.innerHeight || rect.height ) )
			) {
				return;
			}
			// NOTE: If there is $us.scroll use it, because there are a lot
			// of nuances related to the header, basement, etc
			if (
				! $ush.isUndefined( $us.scroll )
				&& typeof $us.scroll.scrollTo === 'function'
			) {
				$us.scroll.scrollTo( $( node ), /*animate*/true );
			}
			// Alternative way of scrolling to the node
			else {
				self.$htmlBody
					.stop( true, false )
					.animate( { scrollTop: $( node ).offset().top + 'px' } );
			}
		},

		/**
		 * Set the highlights position
		 *
		 * NOTE: The code is moved to a separate function since `debounced` must be initialized before call
		 *
		 * @type debounced
		 */
		__setHighlightsPosition: $ush.debounce( function() {
			this.setHighlightsPosition();
		}, 10 ),

		/**
		 * Handlers for private events
		 */
		_$events: {

			/**
			 * The handler is called every time the panel display changes
			 *
			 * @event handler
			 */
			changeSwitchPanel: function() {
				const self = this;
				const isPanelVisible = $usb.panel.isVisible();

				self.$body.toggleClass( 'usb_preview', isPanelVisible );

				// Placeholders are not measured with the panel hidden (see `markPlaceholders`)
				if ( isPanelVisible ) {
					self.checkPlaceholders();
				}

				// With the panel hidden the page must be shown as is, without any outlines. The
				// parent window only drops the editable one (see `builderPanel._switchPanel`), so
				// the hover highlights of the element under the cursor at the moment of the switch
				// stayed displayed — the cursor leaves the iframe towards the switcher, and
				// `_mouseLeavesIframe()` skips hiding them once the panel is already hidden.
				if ( ! isPanelVisible ) {
					self.hideEditableHighlight();
					self.hideHighlight();
				}
			},

			/**
			 * Show the load
			 *
			 * @event handler
			 * @param {String} targetId Shortcode's usbid, e.g. "us_btn:1"
			 * @param {String} position The position ( possible values: before, prepend, append, after )
			 * @param {Boolean} isContainer If these values are true, then a container class will be added for customization
			 * @param {String} newTargetId [optional]
			 */
			showPreloader: function( targetId, position, isContainer, newTargetId ) {
				const self = this;

				// The replace element
				if ( $ush.isUndefined( position ) ) {
					$( self.getElmNode( targetId ) ).addClass( $usb.config( 'className.elmLoad', '' ) );
					return;
				}

				// Don't add preloader, if container have
				if (
					targetId === $usb.builder.rootContainer
					&& ! $ush.isUndefined( self.activePreloaders[ newTargetId || targetId ] )
				) {
					return;
				}

				// Create a new preloader
				var $preloader = $( '<div class="g-preloader type_1 for_usbuilder"></div>' )
					// If a container is added to the tucked place, then we add a class to be able to customize the display
					.toggleClass( 'usb-loading-container', !! isContainer );

				self.activePreloaders[ newTargetId || targetId ] = $preloader.get(0);

				self.trigger( 'insertElement', [ targetId, position, $preloader ] );
			},

			/**
			 * Hide the load
			 *
			 * @event handler
			 * @param {String} id Shortcode's usbid, e.g. "us_btn:1"
			 */
			hidePreloader: function( id ) {
				const self = this;
				if ( ! id ) {
					return;
				}

				// NOTE: The class-based preloader (see showPreloader called without `position`)
				// leaves no entry in `activePreloaders` — it used to disappear only because a
				// successful render replaces the whole node. When the render fails there is no
				// replacement, so the element stays dimmed for good, and `commitChange` then
				// refuses to record history for an element whose preview still carries the class.
				$( self.getElmNode( id ) ).removeClass( $usb.config( 'className.elmLoad', '' ) );

				if ( self.activePreloaders[ id ] ) {
					$usbcore.$remove( self.activePreloaders[ id ] );
					delete self.activePreloaders[ id ];
				}
			},

			/**
			 * Remove an element from a document by its ID
			 *
			 * @event handler
			 * @param {String|[]} id The element that is being removed, e.g. "us_btn:1"
			 */
			removeHtmlById: function ( removeId ) {
				const self = this;

				if ( ! removeId ) {
					return;
				}
				if ( ! Array.isArray( removeId ) ) {
					removeId = [ removeId ];
				}

				const nodes = self.getElmNode( removeId ) || [];
				if ( ! nodes.length ) {
					return;
				}

				nodes.map( ( node ) => {
					if ( ! $ush.isNode( node ) ) {
						return;
					}
					var $node = $( node ),
						$tabs = $node.closest( '.w-tabs' );

					$node
						// Trigger events about the remove of an element to track changes in the elements
						.trigger( 'usb.removeHtml' )
						.remove();

					// Remove a button and open a free section
					if ( $usb.builder.isReloadParentElm( node ) ) {
						$( '[aria-controls="content-'+ $node.attr( 'id' ) +'"]:first', $tabs )
							.remove();
						$( '.w-tabs-list a:first, .w-tabs-section-title:first', $tabs )
							.trigger('click'); // open the first visible section
					}

					// Remove highlights. Refactoring in #2313
					self.removeHighlights();
					// Remove design styles for elements that do not exist. Refactoring in #2313
					self._removeDesignForElmsNotExist();
				} );
			},

			/**
			 * Add new item to document
			 *
			 * @event handler
			 * @param {String|Node} parent Shortcode's usbid, e.g. "us_btn:1" or `root_container`
			 * @param {String} position The position ( possible values: before, prepend, append, after )
			 * @param {String} html The html
			 * @param {Boolean} scrollIntoView If the True are set, then after add the scroll to the new node
			 */
			insertElement: function( parent, position, html, scrollIntoView ) {
				const self = this;

				var $parent;
				if ( $usb.builder.isRootContainer( parent ) && position === 'append' ) {
					$parent = self.$dropzoneSection;
					position = 'before';
				} else if ( ! $ush.isNode( parent ) ) {
					$parent = self._getTargetElm( parent, position );
				} else {
					$parent = $( parent );
				}

				// TODO: This code is often called when move or add a new item, so you need to implement in VanillaJS
				if ( $parent instanceof $ ) {
					var $html = $( html );

					$( '.us_animate_this:not(.start)', $html ).addClass( 'start' );

					$parent[ position ]( $html );

					// Init its JS if needed
					$( '[data-usbid]', $html ).each( ( _, node ) => {
						self.trigger( 'maybeInitElmJS', [ $usbcore.$attr( node, 'data-usbid' ) ] );
					} );

					$( '[data-us-scroll]', $html ).usScrollEffects();
					$us.$canvas.trigger( 'contentChange' );

					// Scrolls the current container of the parent of the element so that the new element is visible to the user
					if ( scrollIntoView ) {
						const $firstNode = $( '*:first:not(style)', $html );
						if ( $firstNode.length ) {
							$ush.timeout( () => {
								$firstNode[0].scrollIntoView();
							}, 100 );
						}
					}
				}
			},

			/**
			 * Move element on preview page
			 *
			 * @event handler
			 * @param {String} parent Shortcode's usbid, e.g. "us_btn:1" or `root_container`
			 * @param {String} position The position ( possible values: before, prepend, append, after )
			 * @param {String} elmId Shortcode's usbid, e.g. "us_btn:1"
			 */
			moveElm: function( parent, position, elmId ) {
				const self = this;

				var $parent;
				if ( $usb.builder.isRootContainer( parent ) && position === 'append' ) {
					$parent = self.$dropzoneSection;
					position = 'before';
				} else {
					$parent = self._getTargetElm( parent, position )
				}

				const $target = $( self.getElmNode( elmId ) );

				if ( $parent instanceof $ && $target.length ) {
					$parent[ position ]( $target );
					// Since we always have custom styles after the elements, when we
					// move the element, we will move the styles if any
					var $style = $( `style[data-for="${elmId}"]:first`, self.$body );
					if ( $style.length ) {
						$target.before( $style );
					}
					// Synchronization of the button order of tabs and sections
					// NOTE: Tab buttons must always match the order of the sections otherwise crashes may occur!
					var parentId = $usb.builder.getElmParentId( elmId );
					if ( parentId && $usb.builder.isElmTab( parentId ) ) {
						var elmNode = self.getElmNode( $usb.builder.addAliasToElmId( 'tab-button', elmId ) ),
							parentNode = $usb.builder.isElmTab( parent )
								? elmNode.parentNode
								: self.getElmNode( $usb.builder.addAliasToElmId( 'tab-button', parent ) );
						$( parentNode )[ position ]( elmNode );
					}
					// The element could be moved from/to a hidden container
					self.checkPlaceholders( $target[0] );
				}
			},

			/**
			 * Updates the selected element on the page
			 *
			 * @event handler
			 * @param {String} id Shortcode's usbid, e.g. "us_btn:1"
			 * @param {String} html This is the html code of the element and additionally,
			 * 				   if necessary, the styles in a separate tag after the element
			 */
			updateSelectedElm: function( id, html ) {
				const self = this;

				if ( ! id ) {
					return;
				}

				const node = self.getElmNode( id );
				if ( ! $ush.isNode( node ) ) {
					return;
				}

				// Fire events when the entire node is updated to track changes to elements.
				$( node ).trigger( 'usb.refreshedEntireNode' );

				// Remove style tag by element ID
				self._removeDesignById( id );
				node.outerHTML = '' + html; // refresh entire node

				// Init its JS if needed
				self.trigger( 'maybeInitElmJS', [ id ] );

				const $node = $( self.getElmNode( id ) );
				if ( $node.hasClass( 'us_animate_this' ) && ! $node.hasClass( 'start' ) ) {
					$node.addClass( 'start' );
				}
				$( '.us_animate_this:not(.start)', $node ).addClass( 'start' );

				// Event for react in extensions, e.g. the background parallax, it also checks the placeholders
				// Note: the element may be rendered without its node, then the whole editable area is checked
				( $node.length ? $node : $( self.elmRootContainer ) ).trigger( 'usb.contentChange' );
				self.__setHighlightsPosition();
			},

			/**
			 * Update custom css on the preview page
			 *
			 * @param {String} css The css
			 */
			updatePageCustomCss: function( css ) {
				const self = this;
				const keyCustomCss = $usb.config( 'settings.keyCustomCss', 'usb_post_custom_css' );

				// NOTE: Since this is outputed inside the WPBakery Page Builder, we can correct it here.
				// The server renders this tag as `<style id="usb_post_custom_css">` (see USBuilder.class.php),
				// so we must match it by id — otherwise a stale server tag is left behind and duplicated.
				var $style = $( `style[id="${keyCustomCss}"]`, self.$document );

				if ( ! $style.length ) {
					$style = $( `<style id="${keyCustomCss}">` );
					$( 'head', self.$document ).append( $style );
				}
				$style.text( css || '' );

				// Custom CSS can hide or show elements
				self.checkPlaceholders();
			},

			/**
			 * Update element content
			 *
			 * NOTE: This method is only for update content
			 *
			 * @param {String|Node} selector The selector to find nodes
			 * @param {String} content Text or HTML content to be installed
			 * @param {String} method Method to be used
			 */
			updateElmContent: function( selector, content, method ) {
				const self = this;
				if ( ! [ 'text', 'html' ].includes( method ) ) {
					method = 'text';
				}
				$( selector, self.$document )[ method ]( '' + content )
					// The new content can make an element empty or not
					.each( ( _, node ) => self.checkPlaceholders( node.closest( '[data-usbid]' ) || node ) );
			},

			/**
			 * Init its JS if needed
			 *
			 * @param {String} targetId Shortcode's usbid, e.g. "vc_row:1"
			 */
			maybeInitElmJS: function( targetId ) {
				const self = this;
				const initMethods = $.isPlainObject( _window.usGlobalData.elmsInitJSMethods )
					? _window.usGlobalData.elmsInitJSMethods
					: {};
				const elmType = $usb.builder.getElmType( targetId );
				if (
					! $ush.isUndefined( initMethods[ elmType ] )
					&& typeof initMethods[ elmType ] === 'function'
				) {
					var $node = $( self.getElmNode( targetId ) );
					// If an element has a common wrapper, then we get the element node, not the wrapper
					if ( $node.length && $usbcore.indexOf( elmType, $usb.config( 'shortcode.with_wrappers', [] ) ) > -1 ) {
						$node = $( ':first', $node );
					}
					initMethods[ elmType ]( $node );
				}
			},

			/**
			 * Apply changes to the element
			 *
			 * instruction: `
			 * {
			 * 		'attr': 'html|text|tag|{attribute}(style|class|...)',
			 * 		'css': '{selectors}',
			 * 		'format': '{template with {%value%}}', // for 'css' and 'attr'
			 * 		'elm': '{selectors}',
			 * 		'elm_parent': '{selectors}',
			 * 		'mod': '{name}',
			 * 		'toggle_atts': {
			 * 			'attribute': '{value}',
			 * 			'attribute2': '{value2}',
			 * 		},
			 * 		'toggle_class': '{class name}',
			 * 		'toggle_class_inverse': '{class name}',
			 * 		'design_options': {
			 * 			// List of specific classes that will be added if there is a value by key name
			 * 			color: 'has_text_color',
			 * 			width: 'has_width',
			 * 			height: 'has_height',
			 * 			...
			 * 		},
			 * 		'scroll_effects' => true,
			 * 		'trigger' => 'click',
			 * }`
			 * or array instructions: `
			 * [
			 *        {...},
			 *        {...}
			 * ]`
			 *
			 * @event handler
			 * @param {String} targetId Shortcode's usbid, e.g. "us_btn:1"
			 * @param {{}} instructions The are instructions for update elements
			 * @param {*} value The value
			 * @param {String} fieldType Field type
			 * @param {Boolean} isResponsiveValue Determine adaptive value format or not (by
			 *     $usof.field.isResponsiveValue)
			 *
			 * TODO: Add responsive value support for all instruction types!
			 */
			onPreviewParamChange: function( targetId, instructions, value, fieldType, isResponsiveValue ) {
				const self = this;

				var $target = $( self.getElmNode( targetId ) );
				if ( ! $target.length ) {
					return;
				}

				// Get responsive states
				const states = $usb.config('responsiveStates', [] ) || '';

				if ( $ush.isUndefined( instructions[0] ) ) {
					instructions = [ instructions || {} ];
				}

				// Get color values for variables
				if ( fieldType === 'color' ) {
					value = usofColorAPI.valueToPreview( value );
				}

				for ( const i in instructions ) {
					const instruction = instructions[ i ];

					var $node = $target;
					if ( ! $ush.isUndefined( instruction[ 'elm' ] ) ) {
						$node = $target.find( instruction[ 'elm' ] );

						// Find the ancestor of an element given a selector in elm_parent
					} else if ( ! $ush.isUndefined( instruction[ 'elm_parent' ] ) ) {
						$node = $target.closest( instruction[ 'elm_parent' ] );
					}

					if ( ! $node.length ) {
						continue;
					}

					// Fix for elements in carousel context ../themes/{Impreza,Zephyr}/common/js/elements/content-carousel.js#65
					if ( $node.hasClass( 'owl-item' ) ) {
						$node = $( '> *', $node );
					}

					// Change the class modifier of an element
					if ( ! $ush.isUndefined( instruction[ 'mod' ] ) ) {
						const mod = '' + instruction[ 'mod' ];

						// Expression for remove classes, include those with prefixes for responsive modes
						const pcre = new RegExp( '((^|\\s)(('+ states.join('|') +')_)?'+ $ush.escapePcre( mod ) + '[a-zA-Z0-9\_\-]+)', 'g' );

						// Remove all classes from modifier
						$node.each( ( _, elm ) => {
							elm.className = elm.className.replace( pcre, '' );
						} );

						if ( isResponsiveValue ) {
							$.each( value || [], ( state, value ) => {
								if ( value ) {
									$node.addClass( state + '_' + mod + '_' + value );
								}
							} );

						} else {
							// If the value is not responsive, check for a set and turn it into an array
							value = Array.isArray( value ) ? value : $ush.toString( value ).split( ',' );
							$.each( value || [], ( _, value ) => {
								if ( value ) {
									$node.addClass( mod + '_' + value );
								}
							} );
						}
					}

					// Change the inline parameter
					if ( ! $ush.isUndefined( instruction[ 'css' ] ) ) {
						// For the font-family property, check for the presence of global keys `body`, 'h1`, `h2` etc
						if ( 'font-family' === instruction[ 'css' ] ) {
							value = $usb.config( 'designOptions.fontVars.' + value, /* default */value );
						}
						// The value is inserted into the template instead of `{%value%}`, e.g. `url("…/{%value%}.svg")`
						const cssValue = ! $ush.isUndefined( instruction[ 'format' ] )
							? $usb.buildString( instruction[ 'format' ], { value: value } )
							: value;
						$node.css( instruction[ 'css' ], cssValue );

						/*
						 * Ugly hack for Safari compatibility:
						 * since it would not re-render element after change grid-gap CSS property,
						 * force re-render by change opacity property
						 */
						if ( $ush.isSafari && 'grid-gap' === instruction[ 'css' ] ) {
							$node.css( 'opacity', '0.99' );
							$ush.timeout( () => {
								$node.css( 'opacity', '' );
							}, 50 );
						}
					}

					// Change some attribute (or embedded text, html)
					if ( ! $ush.isUndefined( instruction[ 'attr' ] ) ) {
						const attr_name = $ush.toString( instruction[ 'attr' ] );
						// The value is inserted into the template instead of `{%value%}`, like for `css` above
						let attrValue = ! $ush.isUndefined( instruction[ 'format' ] )
							? $usb.buildString( instruction[ 'format' ], { value: value } )
							: value;
						switch ( attr_name ) {
							case 'html':
								$node.html( attrValue );
								break;
							case 'text':
								$node.text( attrValue );
								break;
							case 'tag':
								$node.replaceWith( function() {
									var that = this,
										$tag = $( '<' + attrValue + '>' ).html( $( that ).html() );
									for ( var i = that.attributes.length - 1; i >= 0; -- i ) {
										const item = that.attributes[ i ];
										$tag.attr( item.name, item.value );
									}
									return $tag;
								} );
								break;
							case 'class':
								$node
									.removeClass( $node.data( 'last-classname' ) || '' )
									.addClass( attrValue )
									.data( 'last-classname', attrValue );
								break;
							case 'onclick':
								// If there are errors in custom JS, an error message will be displayed
								// in the console, and this will not break the work of the site
								if ( attrValue ) {
									attrValue = `try{${attrValue}}catch(err){}`;
								}
								// NOTE: no break; here, so default: code is executed too
							default:
								$node.attr( attr_name, attrValue );
						}
					}

					// Execute all handlers and behaviors attached to the matched elements for the given event type
					if ( ! $ush.isUndefined( instruction[ 'trigger' ] ) ) {
						$node.trigger( instruction[ 'trigger' ] );
					}

					// Attribute toggles
					if ( ! $ush.isUndefined( instruction[ 'toggle_atts' ] ) ) {
						for ( const k in instruction[ 'toggle_atts' ] ) {
							if ( value == true ) {
								$node.attr( k, instruction[ 'toggle_atts' ][ k ] );
							} else {
								$node.removeAttr( k );
							}
						}
					}

					// Turn on/off css class
					if ( ! $ush.isUndefined( instruction[ 'toggle_class' ] ) ) {
						$node.toggleClass( instruction[ 'toggle_class' ], !! value );
					}

					// Turn on/off css class (inverse)
					if ( ! $ush.isUndefined( instruction[ 'toggle_class_inverse' ] ) ) {
						$node.toggleClass( instruction[ 'toggle_class_inverse' ], ! value );
					}

					// Compile and update design styles
					if ( ! $ush.isUndefined( instruction[ 'design_options' ] ) ) {
						self._addDesignOptions( targetId, value, /* specific classes */instruction[ 'design_options' ] );
					}

					// Apply setting for scroll effects
					if ( ! $ush.isUndefined( instruction[ 'scroll_effects' ] ) ) {
						$( self.getElmNode( targetId ) ).usScrollEffects();
					}

					// Refresh node (Allows you to reload an element to apply attributes, such as for vide or audio nodes)
					if ( ! $ush.isUndefined( instruction[ 'refresh' ] ) ) {
						$node.replaceWith( $node.clone() );
					}
				}

				// Event for react in extensions
				$target.trigger( 'usb.contentChange' );

				self.setHighlightsPosition();
			},

			/**
			 * Called when a new element is added and gets the coordinates of the mouse
			 *
			 * @event handler
			 * @param {String} method The event name
			 * @param {{}} data The mouse event data
			 */
			onParentEventData: function( method, data ) {
				if ( ! method ) {
					return;
				}
				// Determination of the element that is under the coordinates, and obtain all additional data
				data = $.extend( /* default */{ eventX: 0, eventY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0 }, data || {} );
				data.target = _document.elementFromPoint( data.eventX, data.eventY );
				this.trigger( 'doAction', [ method, data ] );
			},

			/**
			 * This method calls another method that is specified in
			 * the parameters and, if necessary, passes arguments
			 *
			 * @event handler
			 * @param {String} name Method name to run
			 * @param {{}} args Arguments to be passed to the method
			 */
			doAction: function( name, args ) {
				const self = this;
				if ( ! name || typeof self[ name ] !== 'function' ) {
					return;
				}
				args = args || [];
				self[ name ].apply( self, Array.isArray( args ) ? args : [ args ] );
			},

			/**
			 * This handler is called every time the column/column_inner in change
			 *
			 * NOTE: At the moment, the same distribution of space between the columns is implemented
			 *
			 * @event handler
			 * @param {String} rootContainerId Shortcode's usbid, e.g. "vc_row:1", "vc_row_inner:1"
			 */
			vcColumnChanged: function( rootContainerId ) {
				const self = this;
				if ( ! rootContainerId || ! $usb.builder.isValidId( rootContainerId ) ) {
					return;
				}

				const columns = $usb.builder.getElmChildren( rootContainerId );
				$( columns.map( ( usbid ) => { return `[data-usbid="${usbid}"]` } ).join(','), self.$body )
					.each( ( i, column ) => {
						// Get width depend on columns CSS type grid/flex
						var width = '' + $usb.builder.getElmValue( columns[i], 'width' );
						if ( /(\d+)\/(\d+)/.test( width ) ) {
							const isGridColumnsLayout = $usb.config( 'isGridColumnsLayout', /* default */false );
							if ( ! isGridColumnsLayout && width.indexOf( '/5') != -1 ) { // specific to classes 1/5, 2/5, N/5
								// do noth
							} else {
								const parts = width.split( '/' );
								width = ceil( parts[ /*x*/0 ] / parts[ /*y*/1 ] * 12 );
							}
						}
						if ( ! width ) {
							return;
						}
						for ( var i = 3; i > -1; i-- ) {
							var prefix = [ 'xs', 'sm', 'md', 'lg' ][ i ],
								matches = ( new RegExp( '(vc_col)-('+ prefix +')-[0-9\\/]+' ) ).exec( column.className );
							if ( ! matches ) {
								continue;
							}
							// TODO: Change the algorithm to calculate the width without change the already exist columns
							column.className = column.className.replace( matches[0], matches[1] + '-' + prefix + '-' + width );
						}
					} );
			},
		}
	} );

	/**
	 * Dropzone in preview.
	 */
	$.extend( USBPreview.prototype, {

		initDropzoneSection: function() {
			const self = this;

			// Bindable events
			$.extend( self._events, {
				dropzoneAddRow: self.dropzoneAddRow.bind( self ),
				dropzoneOpenPastePanel: self.dropzoneOpenPastePanel.bind( self ),
				dropzonePasteHere: self.dropzonePasteHere.bind( self ),
				showPanelGeneralTab: self.showPanelGeneralTab.bind( self ),
				toggleDropzoneVisibility: self.toggleDropzoneVisibility.bind( self ),
			} );

			// Elements
			// Note: the dropzone is searched inside the root container and the last one is taken,
			// since the root container's dropzone always follows all of its content, while other
			// dropzones may come from the Post Content elements used inside the content
			self.$dropzoneSection = $( '[id="usb-dropzone-section"]', self.elmRootContainer ).last();
			if ( ! self.$dropzoneSection.length ) {
				self.$dropzoneSection = $( '[id="usb-dropzone-section"]' ).last();
			}

			$ush.timeout( () => self.toggleDropzoneVisibility(), 15 );

			// Events
			self.$dropzoneSection
				.on( 'click', 'span[class*="show_tab_"]', self._events.showPanelGeneralTab )
				.on( 'click', '.usbp_action_add_row', self._events.dropzoneAddRow )
				.on( 'click', '.usbp_action_paste_here', self._events.dropzonePasteHere )
				.on( 'click', '.usbp_action_open_paste_panel', self._events.dropzoneOpenPastePanel );

			// Bindable events
			self._events.syncDropzoneNavigation = self.syncDropzoneNavigation.bind( self );

			// Private events
			self.on( 'builderPanel.tabSwitched', self._events.syncDropzoneNavigation );
			$usb.on( 'builder.contentChange', self._events.toggleDropzoneVisibility );
		},

		/**
		 * Check the dropzone is visible.
		 *
		 * @return {Boolean} true if the dropzone is visible.
		 */
		isDropzoneShown: function() {
			return this.$dropzoneSection.is( ':visible' );
		},

		/**
		 * Toggle the dropzone visibility.
		 *
		 * @event
		 */
		toggleDropzoneVisibility: function() {
			const self = this;
			if ( $usb.builder.isEmptyContent() ) {
				self.showDropzone();
			} else {
				self.hideDropzone();
			}
		},

		/**
		 * Show the dropzone.
		 */
		showDropzone: function() {
			const self = this;
			self.$dropzoneSection.removeClass( 'hidden' );
			self.syncDropzoneNavigation( $usb.builderPanel.getActiveTabName() );
		},

		/**
		 * Hide the dropzone.
		 */
		hideDropzone: function() {
			this.$dropzoneSection.addClass( 'hidden' );
		},

		/**
		 * Sync dropzone navigation links with left panel tabs.
		 *
		 * @event
		 */
		syncDropzoneNavigation: function( tabName ) {
			const self = this;

			if ( ! self.isDropzoneShown() ) {
				return;
			}

			const $nodes = $( 'span[class*="show_tab_"]', self.$dropzoneSection )
				.removeClass( 'active' );

			if ( tabName ) {
				$nodes.filter( `.show_tab_${tabName}` ).addClass( 'active' );
			}
		},

		/**
		 * Select and show the tab section in the left panel.
		 *
		 * @event
		 * @param {Event} e
		 */
		showPanelGeneralTab: function( e ) {
			const self = this;
			const $target = $( e.currentTarget );

			if ( $target.hasClass( 'show_tab_elements' ) ) {
				self.postMessage( 'panel.showElementsSection' );

			} else if ( $target.hasClass( 'show_tab_templates' ) ) {
				self.postMessage( 'templates.showTemplatesSection' );

			} else if ( $target.hasClass( 'show_tab_favorites' ) ) {
				self.postMessage( 'favorites.showFavoritesSection' );
			}
		},

		/**
		 * Add Row/Section.
		 *
		 * @event
		 */
		dropzoneAddRow: function() {
			this.postMessage( 'builder.dropzoneAddRow' );
		},

		/**
		 * Paste from this site.
		 *
		 * @event
		 */
		dropzonePasteHere: function() {
			this.postMessage( 'builder.elmPaste', $usb.builder.rootContainer );
		},

		/**
		 * Paste from other site.
		 *
		 *  @event
		 */
		dropzoneOpenPastePanel: function() {
			this.postMessage( 'panel.showImportContent' );
		},

	} );

	$( () => _window.$usbp = new USBPreview() );

}( jQuery );
