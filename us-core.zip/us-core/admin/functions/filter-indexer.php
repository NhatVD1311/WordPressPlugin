<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

if ( ! class_exists( 'US_Filter_Indexer' ) ) {
	/**
	 * Class for indexing filters.
	 */
	class US_Filter_Indexer {

		/**
		 * Number of posts to index before updating progress.
		 *
		 * @var int
		 */
		protected $chunk_size = 50;

		/**
		 * Number of seconds without a progress update after which an indexing is considered
		 * left behind by a process that is gone. The progress is touched once per chunk of posts.
		 *
		 * @var int
		 */
		protected $stale_timeout = 300;

		/**
		 * Name of the table the index is written to: the live one, or the temporary
		 * table of the indexing in progress.
		 *
		 * @var string
		 */
		private $table;

		/**
		 * wp_insert_post running?
		 *
		 * @var bool
		 */
		private $is_post_saving = FALSE;

		/**
		 * Cached terms hierarchy
		 *
		 * @var array
		 */
		public $term_hierarchy_cache;

		/**
		 * Constructs a new instance.
		 */
		function __construct() {
			global $wpdb;

			$is_cli = ( defined( 'WP_CLI' ) AND WP_CLI );

			if (
				is_admin()
				OR ( defined( 'DOING_CRON' ) AND DOING_CRON )
				OR $is_cli
			) {

				/**
				 * An indexing whose process is gone would route the updates below into its
				 * temporary table forever, so it is stopped as soon as it is noticed.
				 */
				if ( $this->is_stalled() ) {
					$this->reset_indexing();
				}

				// While an indexing is in progress, the updates go to its temporary table
				if ( $token = $this->get_indexing_token() ) {
					$this->table = $this->get_temp_table( $token );
				} else {
					$this->table = $wpdb->prefix . 'us_filter_index';
				}

				$this->check_create_table();

				// do_action( 'us_filter_indexer_(save|delete)_post', $post_id );
				add_action( 'us_filter_index_save_post', array( $this, 'save_post' ) );
				add_action( 'us_filter_index_delete_post', array( $this, 'delete_post' ) );

				/**
				 * The listeners below belong to the web context only: under WP-CLI they would
				 * index every post of a bulk operation one by one, turning an import or a
				 * generation of test posts into hours of work.
				 */
				if ( $is_cli ) {
					return;
				}

				// Event listeners.
				if ( us_get_option( 'enable_auto_filter_reindex', FALSE ) ) {
					add_action( 'save_post', array( $this, 'save_post' ) );
					add_action( 'delete_post', array( $this, 'delete_post' ) );
					add_action( 'edited_term', array( $this, 'edit_term' ), 10, 3 );
					add_action( 'delete_term', array( $this, 'delete_term' ), 10, 3 );
					add_action( 'set_object_terms', array( $this, 'set_object_terms' ) );
					add_action( 'wp_insert_post_parent', array( $this, 'is_wp_insert_post' ) );
				}
			}
		}

		/**
		 * @return self Returns an instance of the current class.
		 */
		static function instance() {
			static $instance;
			if ( ! isset( $instance ) ) {
				$instance = new self;
			}

			return $instance;
		}

		/**
		 * Determines if indexing.
		 *
		 * @return bool True if indexing, False otherwise.
		 */
		function is_indexing() {
			return $this->get_indexing_token() !== '';
		}

		/**
		 * Get the token of the indexing in progress.
		 *
		 * The token is set by the process that started the indexing, see index(): a process
		 * whose token is gone from the option was stopped or superseded, and must not
		 * touch the index anymore.
		 *
		 * @return string The token, or an empty string when nothing is being indexed.
		 */
		private function get_indexing_token() {
			return (string) get_option( 'us_filter_indexer_indexing', '' );
		}

		/**
		 * Determines if the indexing still belongs to the process with the given token.
		 *
		 * Read from the database on purpose: the option can be autoloaded, and then
		 * get_option() serves it from the alloptions cache that this process loaded
		 * at its start, so a token set by another process never arrives.
		 *
		 * @param string $token The token of this process.
		 * @return bool True if the indexing was neither stopped nor taken over.
		 */
		private function owns_indexing( $token ) {
			return $this->read_indexing_token() === $token;
		}

		/**
		 * Get the token of the indexing in progress straight from the database.
		 *
		 * @return string The token, or an empty string when nothing is being indexed.
		 */
		private function read_indexing_token() {
			global $wpdb;

			$sql = "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'us_filter_indexer_indexing'";

			return (string) $wpdb->get_var( $sql );
		}

		/**
		 * Get the name of the temporary table of an indexing.
		 *
		 * Every indexing gets its own table, so a superseded process cannot leave
		 * its rows in the table of the process that took over.
		 *
		 * @param string $token The indexing token.
		 * @return string
		 */
		private function get_temp_table( $token ) {
			global $wpdb;

			return $wpdb->prefix . 'us_filter_index_temp_' . $token;
		}

		/**
		 * Determines if an indexing was left behind by a process that is gone,
		 * so its data can be deleted.
		 *
		 * @return bool True if indexing, but nothing has touched the progress for a long time.
		 */
		function is_stalled() {
			if ( ! $this->is_indexing() ) {
				return FALSE;
			}

			$touch = (int) $this->get_transient( 'touch' );

			return ( ( time() - $touch ) > $this->stale_timeout );
		}

		/**
		 * Store the indexing progress, which also marks the process as alive.
		 *
		 * @param int $num_indexed Number of posts indexed so far.
		 * @param int $num_total Number of posts to index.
		 */
		private function touch_progress( $num_indexed, $num_total ) {
			$transients = array(
				'num_indexed' => $num_indexed,
				'num_total' => $num_total,
				'touch' => time(),
			);

			update_option( 'us_filter_indexer_transients', json_encode( $transients ), 'no' );
		}

		/**
		 * Stop an unfinished indexing, so the next one starts over.
		 *
		 * The running process, if any, notices the missing token at its next chunk of
		 * posts, deletes its temporary table and exits without touching the live index.
		 * The table isn't deleted here on purpose: until then the process keeps writing
		 * to it, and every write to a deleted table is a database error. The table of a
		 * process that is gone is deleted by the next indexing, see drop_temp_tables().
		 */
		function reset_indexing() {
			global $wpdb;

			update_option( 'us_filter_indexer_transients', '', 'no' );
			update_option( 'us_filter_indexer_indexing', '', 'no' );

			$this->table = $wpdb->prefix . 'us_filter_index';
		}

		/**
		 * Determines if table created.
		 *
		 * @return bool True if table created, False otherwise.
		 */
		static function is_table_created() {
			static $is_created;
			if ( ! isset( $is_created ) ) {
				global $wpdb;
				$is_created = $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}us_filter_index'" ) !== NULL;
			}

			return $is_created;
		}

		/**
		 * Check if the table is created, if not, it will create it.
		 */
		private function check_create_table() {
			global $wpdb;

			if ( get_option( 'us_filter_index_table_is_created', FALSE ) ) {
				return;
			}

			if ( static::is_table_created() ) {
				update_option( 'us_filter_index_table_is_created', TRUE, TRUE );
				return;
			}

			$int = apply_filters( 'us_filter_indexer_use_bigint', FALSE ) ? 'bigint' : 'int';

			$charset_collate = $wpdb->get_charset_collate();

			$table_structure = "
				CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}us_filter_index` (
					`id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
					`post_id` $int UNSIGNED,
					`filter_name` varchar(70) DEFAULT NULL,
					`filter_value` varchar(70) DEFAULT NULL,
					`term_id` $int UNSIGNED DEFAULT '0',
					`parent_id` $int UNSIGNED DEFAULT '0',
					`depth` tinyint UNSIGNED DEFAULT '0',
					`variation_id` $int UNSIGNED DEFAULT '0',
					PRIMARY KEY (`id`),
					INDEX `post_id` (`post_id`),
					INDEX `filter_name` (`filter_name`),
					INDEX `term_id` (`term_id`)
				) $charset_collate
			";

			if ( ! function_exists( 'dbDelta' ) ) {
				require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			}

			dbDelta( $table_structure );

			update_option( 'us_filter_index_table_is_created', TRUE, TRUE );
		}

		/**
		 * Create the temporary table of an indexing and direct the index writes to it.
		 *
		 * @param string $token The indexing token.
		 */
		private function create_temp_table( $token ) {
			global $wpdb;

			$this->table = $this->get_temp_table( $token );

			$wpdb->query( "CREATE TABLE `{$this->table}` LIKE `{$wpdb->prefix}us_filter_index`" );
		}

		/**
		 * Replace the live index with the temporary table of this process.
		 *
		 * The tables are swapped with a single RENAME, which is atomic: the readers see
		 * either the old index or the new one, never an empty or a half-filled table,
		 * it takes milliseconds whatever the size, and a missing temporary table leaves
		 * the live index untouched.
		 */
		private function replace_index() {
			global $wpdb;

			$table = $wpdb->prefix . 'us_filter_index';

			// Left by a process that died between the RENAME and the DROP
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}_old`" );

			$wpdb->query( "RENAME TABLE `$table` TO `{$table}_old`, `{$this->table}` TO `$table`" );

			$wpdb->query( "DROP TABLE IF EXISTS `{$table}_old`" );

			// The temporary table has become the live one
			$this->table = $table;
		}

		/**
		 * Delete the temporary tables left by the processes that are gone.
		 *
		 * A process writes to its table until it notices that it lost the indexing, which
		 * takes a chunk of posts, so the tables that may still be written to are kept: the
		 * one of the indexing in progress, and the one of the token given.
		 *
		 * @param string $keep_token The token of the indexing that was just taken over, if any.
		 */
		private function drop_temp_tables( $keep_token = '' ) {
			global $wpdb;

			$like = $wpdb->esc_like( $wpdb->prefix . 'us_filter_index_temp' ) . '%';

			$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );

			/**
			 * The token is read after the listing: a process sets its token before creating its
			 * table, so the table of a process that started meanwhile is either not listed yet,
			 * or its token is the one read here.
			 */
			$keep_tables = array(
				$this->get_temp_table( $this->read_indexing_token() ),
				$this->get_temp_table( $keep_token ),
			);

			foreach ( array_diff( $tables, $keep_tables ) as $table ) {
				$wpdb->query( "DROP TABLE IF EXISTS `$table`" );
			}
		}

		/**
		 * Get indexer transient variables.
		 *
		 * @param mixed $name
		 * @return mixed
		 */
		function get_transient( $name = FALSE ) {
			$transients = get_option( 'us_filter_indexer_transients' );

			if ( ! empty( $transients ) ) {
				$transients = json_decode( $transients, TRUE );
				if ( $name ) {
					return $transients[ $name ] ?? FALSE;
				}

				return $transients;
			}

			return FALSE;
		}

		/**
		 * Get last indexed date
		 *
		 * @return string
		 */
		function get_last_indexed() {
			$last_indexed = get_option( 'us_filter_indexer_last_indexed' );
			if ( $last_indexed ) {
				return sprintf( us_translate( '%s ago' ), human_time_diff( $last_indexed ) );
			}
			return '&ndash;';
		}

		/**
		 * Get amount of database table rows.
		 *
		 * @return string
		 */
		function get_row_count() {
			global $wpdb;
			if ( static::is_table_created() ) {
				return number_format( $wpdb->get_var( "SELECT COUNT(*) FROM `{$wpdb->prefix}us_filter_index`" ) );
			}
			return 0;
		}

		/**
		 * Get an array of post IDs to index.
		 *
		 * @param mixed $post_id
		 */
		private function get_post_ids_to_index( $post_id = FALSE ) {

			$post_types = array_keys( us_get_loop_post_types( TRUE, FALSE ) );

			$query_args = array(
				'post_type' => $post_types,
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'fields' => 'ids',
				'orderby' => 'ID',
				'cache_results' => FALSE,
				'no_found_rows' => TRUE,
				'suppress_filters' => TRUE,
			);

			if ( is_int( $post_id ) ) {
				$query_args['p'] = $post_id;
				$query_args['posts_per_page'] = 1;
			}

			$query_args = apply_filters( 'us_filter_indexer_query_args', $query_args );

			$query = new WP_Query( $query_args );

			return (array) $query->posts;
		}

		/**
		 * Get filter params used on a website
		 *
		 * @param array
		 */
		function get_used_filter_params() {

			static $params = array();
			if ( ! empty( $params ) ) {
				return $params;
			}

			$used_params = array();

			// Check in database the relevant postmeta
			global $wpdb;
			$sql = "
				SELECT meta_value
				FROM {$wpdb->postmeta}
				WHERE meta_key = '_us_faceted_filter_items'
			";
			foreach( $wpdb->get_results( $sql, ARRAY_A ) as $result ) {
				$used_params = array_merge( $used_params, maybe_unserialize( $result['meta_value'] ) );
			}
			$used_params = array_unique( $used_params );

			if ( empty( $used_params ) ) {
				return array();
			}

			foreach( us_get_list_filter_params() as $name => $param ) {
				if ( in_array( $name, $used_params ) ) {
					$params[ $name ] = $param;
				}
			}

			return $params;
		}

		/**
		 * Get the indexing completion percentage.
		 *
		 * @return mixed The decimal percentage, or -1.
		 */
		function get_progress() {
			$return = -1;

			$num_indexed = (int) $this->get_transient( 'num_indexed' );
			$num_total = (int) $this->get_transient( 'num_total' );

			// Calculate the percent completion
			if ( $num_total > 0 AND $num_indexed != $num_total ) {
				$return = floor( 100 * ( $num_indexed / $num_total ) );
			}

			return $return;
		}

		/**
		 * Get an array of terms hierarchy
		 * @param string $taxonomy The taxonomy name
		 * @return array Term information
		 */
		private function get_term_hierarchy( $taxonomy ) {

			// Empty result if taxonomy is not hierarchical
			if ( $tax = get_taxonomy( $taxonomy ) AND ! $tax->hierarchical ) {
				return array();
			}

			if ( isset( $this->term_hierarchy_cache[ $taxonomy ] ) ) {
				return $this->term_hierarchy_cache[ $taxonomy ];
			}

			$result = array();
			$parents = array();

			global $wpdb;
			$sql = "
				SELECT
					`t`.`term_id`, `t`.`name`, `t`.`slug`, `tt`.`parent`
				FROM `{$wpdb->term_taxonomy}` tt
				INNER JOIN `{$wpdb->terms}` t
					ON `t`.`term_id` = `tt`.`term_id`
				WHERE `tt`.`taxonomy` = %s
			";

			$terms = $wpdb->get_results( $wpdb->prepare( $sql, $taxonomy ) );

			// Get term parents
			foreach ( $terms as $term ) {
				$parents[ $term->term_id ] = $term->parent;
			}

			// Build the term array
			foreach ( $terms as $term ) {
				$result[ $term->term_id ] = array(
					'term_id' => $term->term_id,
					'slug' => $term->slug,
					'parent_id' => $term->parent,
					'depth' => 0,
				);

				$current_parent = $term->parent;

				while ( 0 < (int) $current_parent ) {
					$current_parent = $parents[ $current_parent ];
					$result[ $term->term_id ]['depth']++;

					// Prevent an infinite loop
					if ( 30 < $result[ $term->term_id ]['depth'] ) {
						break;
					}
				}
			}

			$this->term_hierarchy_cache[ $taxonomy ] = $result;

			return $result;
		}

		/**
		 * Update the index when posts get saved.
		 *
		 * @param int $post_id The post id.
		 */
		function save_post( int $post_id ) {

			if (
				( defined( 'DOING_AUTOSAVE' ) AND DOING_AUTOSAVE )
				OR get_post_status( $post_id ) === 'auto-draft'
				OR wp_is_post_revision( $post_id ) !== FALSE
			) {
				return;
			}

			$this->index( $post_id );
			$this->is_post_saving = FALSE;
		}

		/**
		 * Update the index when posts get deleted.
		 *
		 * @param int $post_id The post id.
		 */
		function delete_post( int $post_id ) {
			global $wpdb;

			$where = apply_filters( 'us_filter_indexer_delete_where', "post_id = $post_id", $post_id );

			$wpdb->query( "DELETE FROM {$this->table} WHERE $where" );
		}

		/**
		 * Update the index when terms get saved.
		 *
		 * @param int $term_id Term id.
		 * @param int $tt_id Term taxonomy ID.
		 * @param string $taxonomy The taxonomy.
		 */
		function edit_term( $term_id, $tt_id, $taxonomy ) {
			global $wpdb;

			$used_params = $this->get_used_filter_params();

			// TODO: param_name can be differ from taxonomy name
			if ( ! isset( $used_params[ $taxonomy ] ) ) {
				return;
			}

			$term = get_term( $term_id, $taxonomy );

			$update_indexes_query = "
				UPDATE `{$this->table}`
				SET `filter_value` = %s, `parent_id` = %d
				WHERE `filter_name` = %s AND `term_id` = %d
			";
			$wpdb->query( $wpdb->prepare( $update_indexes_query, rawurldecode( $term->slug ), $term->parent, $taxonomy, $term_id ) );
		}

		/**
		 * Update the index when terms get deleted.
		 *
		 * @param int $term_id Term id.
		 * @param int $tt_id Term taxonomy ID.
		 * @param string $taxonomy The taxonomy.
		 */
		function delete_term( $term_id, $tt_id, $taxonomy ) {
			global $wpdb;

			$wpdb->query( "DELETE FROM {$this->table} WHERE term_id = $term_id" );
		}

		/**
		 * We're hijacking wp_insert_post_parent.
		 *
		 * @param WP_Post $post_parent The post parent.
		 * @return WP_Post
		 */
		function is_wp_insert_post( $post_parent ) {
			$this->is_post_saving = TRUE;
			return $post_parent;
		}

		/**
		 * Support for manual taxonomy associations.
		 *
		 * @param int $object_id The object id.
		 */
		function set_object_terms( $object_id ) {
			if ( $this->is_post_saving ) {
				return;
			}
			$this->index( $object_id );
		}

		/**
		 * Build the index.
		 *
		 * A full indexing takes over any indexing in progress: the previous process
		 * notices the new token at its next chunk of posts and exits.
		 *
		 * @param mixed $post_id The post ID (set to FALSE to index everything).
		 * @return bool True if the index was updated, False if the indexing was stopped or taken over.
		 */
		function index( $post_id = FALSE ) {
			global $wpdb;

			$index_all = ( $post_id === FALSE );

			if ( $index_all ) {

				// Query Monitor to cease operating for the remainder of the page generation.
				// It will detach itself from further data collection, discard any data
				// it’s collected so far, and skip the output of its information.
				if ( class_exists( 'QueryMonitor' ) ) {
					do_action( 'qm/cease' );
				}

				do_action( 'us_filter_indexer_index_all' );

				// PHP sessions are blocking, so close if active
				if ( session_status() === PHP_SESSION_ACTIVE ) {
					session_write_close();
				}

				// Bypass the PHP timeout
				ini_set( 'max_execution_time', 0 );

				// Index a single post
			} else if ( is_int( $post_id ) ) {

				// Clear table values
				$this->delete_post( $post_id );

				// Exit
			} else {
				return FALSE;
			}

			$post_ids = $this->get_post_ids_to_index( $post_id );

			// Count total posts
			$num_total = count( $post_ids );

			if ( $index_all ) {
				$token = uniqid();
				$prev_token = $this->read_indexing_token();

				/**
				 * The progress is stored before the token, so that a request arriving in between
				 * doesn't take the indexing for a stalled one, see is_stalled().
				 */
				$this->touch_progress( 0, $num_total );

				// Take over the indexing, see owns_indexing()
				update_option( 'us_filter_indexer_indexing', $token, 'no' );

				$this->create_temp_table( $token );

				// Tables left by the processes that are gone, except the one that was just taken over
				$this->drop_temp_tables( $prev_token );
			}

			do_action( 'us_filter_indexer_index_start', $num_total, $index_all );

			foreach ( $post_ids as $counter => $post_id ) {

				// Update the progress bar
				if ( $index_all AND ( $counter % $this->chunk_size ) === 0 ) {

					// Stopped from the admin page or taken over
					if ( ! $this->owns_indexing( $token ) ) {
						$this->drop_own_temp_table();

						return FALSE;
					}

					$this->touch_progress( $counter, $num_total );
				}

				$this->index_post( $post_id );
			}

			// Indexing complete
			if ( $index_all ) {
				if ( ! $this->owns_indexing( $token ) ) {
					$this->drop_own_temp_table();

					return FALSE;
				}

				$this->replace_index();

				update_option( 'us_filter_indexer_last_indexed', time(), 'no' );
				update_option( 'us_filter_indexer_transients', '', 'no' );

				/**
				 * Release the indexing only if it is still ours: a plain update would wipe the token
				 * of a process that took over meanwhile, and its indexing would never complete.
				 */
				$sql = "UPDATE {$wpdb->options} SET option_value = '' WHERE option_name = 'us_filter_indexer_indexing' AND option_value = %s";
				$wpdb->query( $wpdb->prepare( $sql, $token ) );

				// The raw query bypasses the options cache
				wp_cache_delete( 'us_filter_indexer_indexing', 'options' );
				wp_cache_delete( 'alloptions', 'options' );

				// The processes taken over during this indexing have noticed it long ago
				$this->drop_temp_tables();
			}

			do_action( 'us_filter_indexer_complete' );

			return TRUE;
		}

		/**
		 * Delete the temporary table of this process and direct the index writes
		 * back to the live table.
		 */
		private function drop_own_temp_table() {
			global $wpdb;

			$wpdb->query( "DROP TABLE IF EXISTS `{$this->table}`" );

			$this->table = $wpdb->prefix . 'us_filter_index';
		}

		/**
		 * Index an individual post.
		 *
		 * @param int $post_id
		 * @param array $filter_items
		 */
		protected function index_post( int $post_id ) {

			// Force WPML to change the language
			do_action( 'us_filter_indexer_index_post', array( 'post_id' => $post_id ) );

			// Set default insert_row() values
			$defaults = array(
				'post_id' => $post_id,
				'filter_name' => '',
				'filter_value' => '',
				'term_id' => 0,
				'parent_id' => 0,
				'depth' => 0,
				'variation_id' => 0,
			);

			// Bypass default indexing
			$bypass = apply_filters( 'us_filter_indexer_is_post_indexing', $post_id );
			if ( empty( $bypass ) ) {
				return;
			}

			$indexes = array();

			foreach( $this->get_used_filter_params() as $name => $param ) {

				$source_type = $param['source_type'] ?? '';
				$source_name = $param['source_name'] ?? '';

				// Bypass source indexing
				$bypass = apply_filters( 'us_filter_indexer_index_source', $post_id, $source_name, $source_type );
				if ( empty( $bypass ) ) {
					continue;
				}

				// Taxonomy Terms indexing
				if ( $source_type == 'tax' ) {
					$used_terms = array();

					$term_objects = wp_get_object_terms( $post_id, $source_name );
					if ( is_wp_error( $term_objects ) ) {
						continue;
					}

					// Get the hierarchy of taxonomy terms
					$term_hierarchy = $this->get_term_hierarchy( $source_name );

					foreach ( $term_objects as $term ) {

						// Prevent duplicate terms
						if ( isset( $used_terms[ $term->term_id ] ) ) {
							continue;
						}
						$used_terms[ $term->term_id ] = TRUE;

						// Handle hierarchical taxonomies
						$depth = 0;
						if ( $term_hierarchy ) {
							$term_info = $term_hierarchy[ $term->term_id ];
							$depth = $term_info['depth'];
						}

						$indexes[] = array_merge(
							$defaults,
							array(
								'filter_name' => $name,
								'filter_value' => rawurldecode( $term->slug ), // decode cyrillic slugs
								'term_id' => $term->term_id,
								'parent_id' => $term->parent,
								'depth' => $depth,
							)
						);

						// Index parents
						while ( $depth > 0 ) {
							$term_id = $term_info['parent_id'];
							$term_info = $term_hierarchy[ $term_id ];
							$depth = $depth - 1;

							if ( ! isset( $used_terms[ $term_id ] ) ) {
								$used_terms[ $term_id ] = TRUE;

								$indexes[] = array_merge(
									$defaults,
									array(
										'filter_name' => $name,
										'filter_value' => rawurldecode( $term_info['slug'] ), // decode cyrillic slugs
										'term_id' => $term_id,
										'parent_id' => $term_info['parent_id'],
										'depth' => $depth,
									)
								);
							}
						}
					}

					// Post Attributes
				} elseif ( $source_type == 'post' ) {
					if ( $post = get_post( $post_id ) ) {
						$indexes[] = array_merge(
							$defaults,
							array(
								'filter_name' => $name,
								'filter_value' => $post->{$name},
							)
						);
					}

					// Custom Fields indexing
				} elseif ( $source_type == 'meta' ) {
					if ( empty( $source_name ) ) {
						continue;
					}

					$values = get_post_meta( $post_id, $source_name, FALSE );

					foreach ( $values as $value ) {

						// TODO: add support for fields with 'value_type' => 'bool'

						// The value can be array, so we need to extract its values
						if ( ! is_array( $value ) ) {
							$value = array( $value );
						}

						foreach ( $value as $val ) {
							if ( $val === '' ) {
								continue;
							}

							$val = apply_filters( 'us_filter_indexer_meta_value', $val, $source_name );

							$indexes[] = array_merge(
								$defaults,
								array(
									'filter_name' => $name,
									'filter_value' => $val,
								)
							);
						}
					}
				}
			}

			// Allow for custom indexing
			$indexes = (array) apply_filters( 'us_filter_indexer_insert_indexes', $indexes, $defaults );

			// Allow hooks to bypass the indexes insertion
			if ( empty( $indexes ) ) {
				return;
			}

			global $wpdb;

			// Prepare values
			foreach( $indexes as &$index ) {
				$index = $wpdb->prepare( '(%d, %s, %s, %d, %d, %d, %d)',
					$index['post_id'],
					$index['filter_name'],
					$index['filter_value'],
					$index['term_id'],
					$index['parent_id'],
					$index['depth'],
					$index['variation_id']
				);
			}
			unset( $index );

			// Save indexes to DB
			$wpdb->query( "
				INSERT INTO `{$this->table}` (`post_id`, `filter_name`, `filter_value`, `term_id`, `parent_id`, `depth`, `variation_id`)
				VALUES " . implode( ',', $indexes ) . ";
			" );
		}
	}

	add_action( 'init', 'US_Filter_Indexer::instance', 10 );
}

if ( ! function_exists( 'us_define_tables_in_wpdb' ) ) {
	add_action( 'init', 'us_define_tables_in_wpdb' );

	/**
	 * Add tables to $wpdb object.
	 */
	function us_define_tables_in_wpdb() {
		global $wpdb;

		// List of tables without prefixes.
		$tables = array(
			'us_filter_index',
		);

		foreach ( $tables as $name ) {
			$wpdb->$name = $wpdb->prefix . $name;
		}
	}
}

if ( ! function_exists( 'us_index_filters_by_ajax' ) ) {

	if ( wp_doing_ajax() ) {
		add_action( 'wp_ajax_us_index_filters', 'us_index_filters_by_ajax' );
	}

	/**
	 * Indexing process by AJAX.
	 */
	function us_index_filters_by_ajax() {
		if ( ! check_ajax_referer( __FUNCTION__, '_nonce', FALSE ) ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		$us_filter_indexer = US_Filter_Indexer::instance();

		// Get indexer action
		$indexerAction = (string) us_arr_path( $_POST, 'indexerAction' );
		if ( ! in_array( $indexerAction, array( 'start-index', 'heartbeat' ) ) ) {
			$indexerAction = 'stop-index';
		}

		$response = array();

		// Rebuild the index table
		if ( $indexerAction == 'start-index' ) {

			if ( $us_filter_indexer->index() ) {
				$response['status'] = 'completed';

			} else {
				$response = array(
					'message' => __( 'Indexing cancelled', 'us' ),
					'last_indexed' => $us_filter_indexer->get_last_indexed(),
					'status' => 'cancelled',
				);
			}

			// Keep track of indexing progress
		} else if ( $indexerAction == 'heartbeat' ) {

			// Nobody is going to finish an indexing whose process is gone
			if ( $us_filter_indexer->is_stalled() ) {
				$us_filter_indexer->reset_indexing();

				$response = array(
					'message' => __( 'Indexing cancelled', 'us' ),
					'last_indexed' => $us_filter_indexer->get_last_indexed(),
					'status' => 'cancelled',
				);

			} else if ( ( $progress = $us_filter_indexer->get_progress() ) !== -1 ) {
				$response['message'] = sprintf( __( 'Indexing', 'us' ) . ' %s%%', $progress );

			} else {
				$response['status'] = 'completed';
			}

			// Stop indexing filters
		} else {
			$us_filter_indexer->reset_indexing();

			$response = array(
				'message' => __( 'Indexing cancelled', 'us' ),
				'last_indexed' => $us_filter_indexer->get_last_indexed(),
				'status' => 'cancelled',
			);
		}

		// Indexing completed
		if ( us_arr_path( $response, 'status' ) == 'completed' ) {
			$response += array(
				'message' => __( 'Indexing completed', 'us' ),
				'last_indexed' => $us_filter_indexer->get_last_indexed(),
				'row_count' => $us_filter_indexer->get_row_count(),
			);
		}

		wp_send_json_success( $response );
	}
}

if ( defined( 'WP_CLI' ) AND WP_CLI AND ! class_exists( 'US_Filter_Index_Command' ) ) {

	class US_Filter_Index_Command {

		/**
		 * Number of posts after which the runtime object cache is flushed.
		 *
		 * @var int
		 */
		protected $cache_flush_size = 500;

		/**
		 * Rebuild the Faceted Filtering index
		 *
		 * Runs the whole indexing in the current process, without HTTP requests
		 * to admin-ajax.php, so it isn't limited by the web server timeouts.
		 *
		 * ## OPTIONS
		 *
		 * [--force]
		 * : Take over an indexing that is in progress: it stops at its next chunk
		 * of posts, and its temporary data is deleted.
		 *
		 * ## EXAMPLES
		 *
		 *     wp us-filter-index
		 *     wp us-filter-index --force
		 *
		 * @param array $args Positional arguments
		 * @param array $assoc_args Associative arguments
		 */
		public function __invoke( $args, $assoc_args ) {

			$indexer = US_Filter_Indexer::instance();

			if ( $indexer->is_indexing() ) {

				// The data of a process that is gone is deleted by index() itself
				if ( $indexer->is_stalled() ) {
					WP_CLI::warning( 'An interrupted indexing was found, starting over.' );

				} elseif ( empty( $assoc_args['force'] ) ) {
					WP_CLI::error(
						sprintf(
							'Another indexing is in progress (last activity %s ago). Run with --force to take it over.',
							human_time_diff( (int) $indexer->get_transient( 'touch' ) )
						)
					);

				} else {
					WP_CLI::warning( 'Another indexing is in progress, it stops at its next chunk of posts.' );
				}
			}

			$progress = NULL;
			$num_indexed = 0;

			add_action( 'us_filter_indexer_index_start', function( $num_total, $index_all ) use ( &$progress ) {
				if ( $index_all ) {
					$progress = WP_CLI\Utils\make_progress_bar( 'Indexing', $num_total );
				}
			}, 10, 2 );

			add_action( 'us_filter_indexer_index_post', function() use ( &$progress, &$num_indexed ) {
				$num_indexed++;

				if ( $progress !== NULL ) {
					$progress->tick();
				}

				// Keep the memory flat on large sites: the object cache grows with every post
				if ( $num_indexed % $this->cache_flush_size === 0 AND function_exists( 'wp_cache_flush_runtime' ) ) {
					wp_cache_flush_runtime();
				}
			} );

			$is_completed = $indexer->index();

			if ( $progress !== NULL ) {
				$progress->finish();
			}

			if ( ! $is_completed ) {
				WP_CLI::error( 'Indexing was interrupted: it was stopped from the admin page or another indexing took it over.' );
			}

			WP_CLI::success(
				sprintf(
					'Indexing completed: %s rows.',
					$indexer->get_row_count()
				)
			);
		}
	}

	WP_CLI::add_command( 'us-filter-index', 'US_Filter_Index_Command' );
}
