<?php

if ( ! class_exists( 'US_Regenerate_Thumbnails' ) ) {
	/**
	 * Class for regenerate thumbnails in background.
	 */
	class US_Regenerate_Thumbnails extends WP_Background_Process {

		/**
		 * Prefix for action.
		 *
		 * @var string
		 */
		protected $prefix = 'us';

		/**
		 * Action for request.
		 *
		 * @var string
		 */
		protected $action = 'regenerate_thumbnails_background_process';

		/**
		 * ID of the current process chain, when it is started by the theme itself.
		 *
		 * @var string
		 */
		protected $us_chain_id;

		/**
		 * Get the ID of the current process chain.
		 *
		 * The parent asks for the nonce of the background process whenever a chain starts
		 * inside an ajax request, and kills the request with `-1` and 403 when there is
		 * none. That fits its own entry point, but the theme starts the queue from its own
		 * ajax actions — the Setup Wizard and the Theme Options save — where that nonce
		 * does not exist and never will.
		 *
		 * @return string
		 */
		public function get_chain_id() {

			// The entry point of the process itself: the parent knows what to do there
			if ( isset( $_REQUEST['action'] ) AND $_REQUEST['action'] === $this->get_identifier() ) {
				return parent::get_chain_id();
			}

			if ( empty( $this->us_chain_id ) ) {
				$this->us_chain_id = wp_generate_uuid4();
			}

			return $this->us_chain_id;
		}

		/**
		 * @return self Returns an instance of the current class.
		 */
		public static function instance() {
			static $instance;
			if ( ! isset( $instance ) ) {
				$instance = new self;
			}

			return $instance;
		}

		/**
		 * Get option name for statistics.
		 *
		 * @return string
		 */
		private function get_stats_key() {
			return $this->identifier . '_data';
		}

		/**
		 * Set data for statistics.
		 *
		 * @param integer $count The all count
		 * @param array $sizes The sizes
		 * @return self
		 */
		public function set_stats_data( $count ) {
			update_option(
				$this->get_stats_key(), array(
				'created' => date( 'U' ),
				'count_tasks' => (int) $count,
			)
			);

			return $this;
		}

		/**
		 * Get data for statistics.
		 *
		 * @return array
		 */
		public function get_stats_data() {
			if ( $stats_data = get_option( $this->get_stats_key() ) ) {
				if ( ! empty( $stats_data['count_tasks'] ) ) {
					$batch = $this->get_batch();
					$outstanding_tasks = count( $batch->data );
					$stats_data['completed_tasks'] = 0;

					if ( $stats_data['count_tasks'] > $outstanding_tasks AND $outstanding_tasks ) {
						$stats_data['completed_tasks'] = $stats_data['count_tasks'] - $outstanding_tasks;
					} elseif ( $stats_data['count_tasks'] != $outstanding_tasks ) {
						$stats_data['completed_tasks'] = $stats_data['count_tasks'];
					}
				}

				return $stats_data;
			}

			return array();
		}

		/**
		 * Task
		 *
		 * @param mixed $item_id Queue item to iterate over
		 * @return false
		 */
		protected function task( $item_id ) {

			// Get image path
			$image_path = function_exists( 'wp_get_original_image_path' )
				? wp_get_original_image_path( ( int ) $item_id )
				: get_attached_file( (int) $item_id );

			// Complete actions if there is no image or for a placeholder
			if (
				empty( $image_path )
				OR strpos( $image_path, 'woocommerce-placeholder' ) !== FALSE
				OR strpos( $image_path, 'us-placeholder' ) !== FALSE
			) {
				return FALSE;
			}

			$dirname = pathinfo( $image_path, PATHINFO_DIRNAME ) . DIRECTORY_SEPARATOR;
			$image_metadata = wp_get_attachment_metadata( $item_id );
			if ( ! is_array( $image_metadata ) ) {
				$image_metadata = array();
			}
			$image_metadata_sizes = $used_image_thumbnails = $thumbnail_sizes = array();

			// Get all thumbnail sizes
			foreach ( array_keys( us_get_image_sizes_list() ) as $size_name ) {
				$thumbnail_sizes[ $size_name ] = us_get_image_size_params( $size_name );
			}

			$changed = FALSE;

			// Regenerate thumbnails
			foreach ( $thumbnail_sizes as $size_name => $thumbnail_size ) {
				$crop = ! empty( $thumbnail_size['crop'] );

				// Obtaining real thumbnail sizes
				// Note: Size `full` has no width or height
				$width = (int) $thumbnail_size['width'];
				$height = (int) $thumbnail_size['height'];

				if ( ! $width OR ! $height ) {
					continue;
				}

				// Create new thumbnail
				$img_editor = wp_get_image_editor( $image_path );
				if ( ! is_wp_error( $img_editor ) ) {

					// The image is smaller than the size: WordPress does not upscale, neither do we
					if ( is_wp_error( $img_editor->resize( $width, $height, $crop ) ) ) {
						continue;
					}

					$img_editor_size = $img_editor->get_size();
					$img_fullpath_filename = $img_editor->generate_filename();
					$img_filename = wp_basename( $img_fullpath_filename );

					$used_image_thumbnails[] = $img_filename;

					if ( ! file_exists( $img_fullpath_filename ) ) {
						if ( is_wp_error( $img_editor->save( $img_fullpath_filename ) ) ) {
							continue;
						}
						$changed = TRUE;
					}

					/**
					 * The size goes to the metadata under its registered name, the way
					 * WordPress does it: `wp_get_attachment_image( $id, $size_name )` and
					 * the rest of the API look it up by the name, not by the real dimensions,
					 * which differ from the requested ones for every non cropped size
					 */
					$size_metadata = array(
						'file' => $img_filename,
						'width' => $img_editor_size['width'],
						'height' => $img_editor_size['height'],
						'mime-type' => wp_get_image_mime( $img_fullpath_filename ),
					);

					if ( us_arr_path( $image_metadata, 'sizes.' . $size_name ) != $size_metadata ) {
						$image_metadata_sizes[ $size_name ] = $size_metadata;
						$changed = TRUE;
					}
				}
			}

			// Delete unused image thumbnails
			if ( us_get_option( 'delete_unused_images', FALSE ) ) {
				$existing_sizes = apply_filters(
					'intermediate_image_sizes_advanced',
					wp_get_registered_image_subsizes(),
					$image_metadata,
					$item_id
				);

				foreach ( us_arr_path( $image_metadata, 'sizes', array() ) as $size_name => $size_data ) {
					if (
						! isset( $existing_sizes[ $size_name ] )
						// Prevent deletion of original images.
						AND wp_basename( $image_metadata['file'] ) !== $size_data['file']
					) {
						unset( $image_metadata['sizes'][ $size_name ] );
						unlink( $dirname . $size_data['file'] );
						$changed = TRUE;
					}
				}
			}

			// Update attachment metadata
			if ( $changed ) {
				$image_metadata['sizes'] = array_merge(
					(array) us_arr_path( $image_metadata, 'sizes', array() ), $image_metadata_sizes
				);
				wp_update_attachment_metadata( $item_id, $image_metadata );
			}

			return FALSE;
		}

		/**
		 * Complete
		 */
		protected function complete() {
			parent::complete();
			delete_option( $this->get_stats_key() );
		}


	}

	// Init regenerate thumbnails.
	US_Regenerate_Thumbnails::instance();

	// For debugging url: http://host/wp-admin/?us_dev_debug=regenerate_thumbnails_process
	if (
		defined( 'US_DEV' )
		AND isset( $_GET['us_dev_debug'] )
		AND $_GET['us_dev_debug'] === 'regenerate_thumbnails_process'
	) {
		var_dump( US_Regenerate_Thumbnails::instance()->get_stats_data() );
		exit;
	}
}

if ( ! function_exists( 'us_after_ajax_save_regenerate_thumbnails_process' ) ) {
	/**
	 * Checks for size updates and, if necessary, start regenerate thumbnails
	 */
	function us_after_ajax_save_regenerate_thumbnails_process() {

		$post_usof_options = us_get_HTTP_POST_json( 'usof_options' );
		if ( empty( $post_usof_options ) ) {
			return;
		}

		if (
			isset( $post_usof_options['img_size'] )
			OR ( isset( $post_usof_options['delete_unused_images'] ) AND $post_usof_options['delete_unused_images'] )
		) {
			global $wpdb;

			$us_regenerate_thumbnails = US_Regenerate_Thumbnails::instance();

			// Get all image IDs
			$images_query = "
				SELECT
					ID AS image_id
				FROM {$wpdb->posts}
				WHERE 1=1
					AND (
						post_mime_type = 'image/jpeg'
						OR post_mime_type = 'image/gif'
						OR post_mime_type = 'image/png'
						OR post_mime_type = 'image/webp'
					)
					AND post_type = 'attachment'
					AND post_status = 'inherit'
			";

			$results = $wpdb->get_results( $images_query );

			// Add tasks and run background process.
			if ( ! empty( $results ) ) {
				foreach ( $results as $image ) {
					$us_regenerate_thumbnails->push_to_queue( $image->image_id );
				}

				/**
				 * Write the statistics BEFORE dispatching: dispatch() is non-blocking, so a
				 * short queue can complete and delete the option while we are still running
				 */
				$us_regenerate_thumbnails->set_stats_data( count( $results ) );

				$us_regenerate_thumbnails->save()->dispatch();
			}
		}
	}

	if ( apply_filters( 'us_regenerate_thumbnails_is_enabled', TRUE ) ) {
		add_action( 'usof_after_ajax_save', 'us_after_ajax_save_regenerate_thumbnails_process', 100 );
	}
}
