<?php
/**
 * UpSolution MCP — site front page and posts page (Settings → Reading).
 *
 *   upsolution-get-front-page — current show_on_front / page_on_front /
 *                               page_for_posts with page titles.
 *   upsolution-set-front-page — change any of the three; validates the pages
 *                               and writes nothing if a check fails.
 *
 * The other Reading settings (posts per page, search engine visibility) are
 * out of scope.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Current Reading state in the output shape of both abilities.
 *
 * @return array{show_on_front: string, page_on_front: array|null, page_for_posts: array|null}
 */
function us_mcp_reading_state() {
	$page = function ( $option ) {
		$page_id = (int) get_option( $option );
		// get_post( 0 ) falls back to the global post, so an unset page must not reach it
		$post = $page_id ? get_post( $page_id ) : NULL;
		if ( ! $post ) {
			return NULL;
		}

		return array(
			'id' => (int) $post->ID,
			'title' => get_the_title( $post ),
		);
	};

	return array(
		'show_on_front' => get_option( 'show_on_front' ) === 'page' ? 'page' : 'posts',
		'page_on_front' => $page( 'page_on_front' ),
		'page_for_posts' => $page( 'page_for_posts' ),
	);
}

add_action( 'wp_abilities_api_init', function () {
	$page_schema = array(
		'type' => array( 'object', 'null' ),
		'properties' => array(
			'id' => array( 'type' => 'integer' ),
			'title' => array( 'type' => 'string' ),
		),
	);
	$output_schema = array(
		'type' => 'object',
		'required' => array( 'show_on_front', 'page_on_front', 'page_for_posts' ),
		'properties' => array(
			'show_on_front' => array(
				'type' => 'string',
				'enum' => array( 'posts', 'page' ),
				'description' => '"posts" = the front page shows latest posts; "page" = it shows page_on_front.',
			),
			'page_on_front' => $page_schema + array( 'description' => 'Static front page, or null when none is set.' ),
			'page_for_posts' => $page_schema + array( 'description' => 'Page that lists the posts (blog), or null when none is set.' ),
		),
	);

	wp_register_ability( 'upsolution/get-front-page', array(
		'label' => 'Read the site front page settings',
		'description' => 'Read Settings → Reading: what the front page shows. Returns {show_on_front: "posts"|"page", page_on_front: {id, title}|null, page_for_posts: {id, title}|null}. Change them with upsolution-set-front-page.',
		'category' => 'upsolution',
		// No input — call with no params.
		'output_schema' => $output_schema,
		'execute_callback' => 'us_mcp_reading_state',
		'permission_callback' => 'us_mcp_theme_option_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/set-front-page', array(
		'label' => 'Set the site front page and posts page',
		'description' => 'Change Settings → Reading: the front page and the posts (blog) page. Every field is optional — omitted ones keep their current value. For a static front page pass show_on_front "page" plus page_on_front (page id from upsolution-list-posts). Pages must be published pages (post_type "page"); the front page and the posts page cannot be the same page; show_on_front "page" requires a front page. If any check fails, nothing is changed (400). Returns the resulting state, same shape as upsolution-get-front-page. With Polylang / WPML set the page of the default language — the plugin maps its translations itself.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'additionalProperties' => FALSE,
			'properties' => array(
				'show_on_front' => array(
					'type' => 'string',
					'enum' => array( 'posts', 'page' ),
					'description' => '"posts" = latest posts on the front page; "page" = a static page (page_on_front).',
				),
				'page_on_front' => array(
					'type' => 'integer',
					'minimum' => 0,
					'description' => 'Published page id for the static front page; 0 unsets it.',
				),
				'page_for_posts' => array(
					'type' => 'integer',
					'minimum' => 0,
					'description' => 'Published page id that lists the posts; 0 unsets it.',
				),
			),
		),
		'output_schema' => $output_schema,
		'execute_callback' => 'us_mcp_ability_set_front_page',
		'permission_callback' => 'us_mcp_theme_option_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_set_front_page( $input ) {
	$input = (array) $input;
	$changes = array();

	if ( array_key_exists( 'show_on_front', $input ) ) {
		if ( ! in_array( $input['show_on_front'], array( 'posts', 'page' ), TRUE ) ) {
			return new WP_Error(
				'us_mcp_reading_bad_show_on_front',
				'`show_on_front` must be "posts" or "page".',
				array( 'status' => 400 )
			);
		}
		$changes['show_on_front'] = $input['show_on_front'];
	}

	foreach ( array( 'page_on_front', 'page_for_posts' ) as $key ) {
		if ( ! array_key_exists( $key, $input ) ) {
			continue;
		}
		// The input_schema declares the field as a non-negative integer, so the Abilities API has checked the type
		$page_id = (int) $input[ $key ];
		if ( $page_id ) {
			$post = get_post( $page_id );
			if ( ! $post OR $post->post_type !== 'page' OR $post->post_status !== 'publish' ) {
				return new WP_Error(
					'us_mcp_reading_bad_page',
					sprintf(
						'`%s`: id=%d is not a published page%s. Use the id of a published page from upsolution-list-posts (post_type "page").',
						$key,
						$page_id,
						$post ? sprintf( ' (post_type "%s", status "%s")', $post->post_type, $post->post_status ) : ' (not found)'
					),
					array( 'status' => 400 )
				);
			}
		}
		$changes[ $key ] = $page_id;
	}

	// Validate the resulting state, not just the input: a passed value may clash with a stored one.
	$final = $changes + array(
		'show_on_front' => get_option( 'show_on_front' ),
		'page_on_front' => (int) get_option( 'page_on_front' ),
		'page_for_posts' => (int) get_option( 'page_for_posts' ),
	);
	if ( $final['show_on_front'] === 'page' AND ! $final['page_on_front'] ) {
		return new WP_Error(
			'us_mcp_reading_no_front_page',
			'`show_on_front` "page" needs a front page — pass `page_on_front` with a published page id.',
			array( 'status' => 400 )
		);
	}
	if ( $final['page_on_front'] AND $final['page_on_front'] === $final['page_for_posts'] ) {
		return new WP_Error(
			'us_mcp_reading_same_page',
			sprintf( 'Page id=%d cannot be both the front page and the posts page.', $final['page_on_front'] ),
			array( 'status' => 400 )
		);
	}

	foreach ( $changes as $option => $value ) {
		/**
		 * Core flushes rewrite rules on a front page change via a hook from
		 * wp-admin/includes/admin-filters.php (update_home_siteurl), which an
		 * MCP request does not load — do the same here.
		 */
		if ( update_option( $option, $value ) AND $option === 'page_on_front' ) {
			flush_rewrite_rules();
		}
	}

	return us_mcp_reading_state();
}
