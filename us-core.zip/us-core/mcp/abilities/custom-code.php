<?php
/**
 * UpSolution MCP — Theme Options → Custom Code editor.
 *
 * Single ability `upsolution-set-custom-code`: replaces or appends to one of
 * the site-wide code fields (tracking snippets, chat widgets, custom CSS):
 *
 *   custom_html_head   printed just before </head>
 *   custom_html_body   printed just after <body>
 *   custom_html        printed just before </body>
 *   custom_css         printed inside <style> / bundled into the CSS asset
 *
 * Reading the current values uses the existing upsolution-get-theme-option
 * tool (name = one of the keys above).
 *
 * Permission gate is stricter than the shared Theme Options one: the three HTML
 * fields are printed unescaped on every page, i.e. they are arbitrary JS. Custom
 * CSS cannot break out of its <style> tag (us_minify_css() escapes `</`), but it
 * still reaches every visitor and can pull remote resources via url() / @import.
 * So `unfiltered_html` is required on top of manage_options — on multisite only
 * super admins hold it.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * @return string[]
 */
function us_mcp_custom_code_fields() {
	return array( 'custom_html_head', 'custom_html_body', 'custom_html', 'custom_css' );
}

/**
 * @return bool
 */
function us_mcp_custom_code_permission_callback() {
	return us_mcp_theme_option_permission_callback() AND current_user_can( 'unfiltered_html' );
}

add_action( 'wp_abilities_api_init', function () {
	wp_register_ability( 'upsolution/set-custom-code', array(
		'label'               => 'Write a Theme Options → Custom Code field',
		'description'         => 'Write site-wide custom code (Theme Options → Custom Code): Google Analytics / GTM / pixels / chat widgets / custom CSS. Fields: "custom_html_head" (printed just before </head>), "custom_html_body" (just after <body>), "custom_html" (just before </body>), "custom_css" (CSS only, no <style> tags). HTML fields are printed as is on every page — wrap JavaScript in <script></script>. Use mode="append" to add a tracker next to the already installed ones (a retry never duplicates it), mode="replace" to overwrite the field. Read the current value first with upsolution-get-theme-option (name = field). Requires the unfiltered_html capability — on 403 ask the user to paste the code in Theme Options → Custom Code themselves.',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'       => 'object',
			'required'   => array( 'field', 'value' ),
			'properties' => array(
				'field' => array(
					'type'        => 'string',
					'enum'        => us_mcp_custom_code_fields(),
					'description' => 'Which Custom Code field to write.',
				),
				'value' => array(
					'type'        => 'string',
					'description' => 'Code to write (replace) or to add after the existing code (append).',
				),
				'mode'  => array(
					'type'        => 'string',
					'enum'        => array( 'replace', 'append' ),
					'description' => 'replace (default): overwrite the field. append: add on a new line after the existing code.',
					'default'     => 'replace',
				),
			),
		),
		'output_schema'       => array(
			'type'       => 'object',
			'required'   => array( 'field', 'mode', 'changed', 'before', 'value' ),
			'properties' => array(
				'field'   => array( 'type' => 'string' ),
				'mode'    => array( 'type' => 'string' ),
				'changed' => array( 'type' => 'boolean', 'description' => 'False when nothing was saved: the value equals the current content, or (append) the code is already in the field.' ),
				'before'  => array( 'type' => 'string', 'description' => 'Field content before the write — pass it back with mode="replace" to undo.' ),
				'value'   => array( 'type' => 'string', 'description' => 'Resulting field content after the write.' ),
			),
		),
		'execute_callback'    => 'us_mcp_ability_set_custom_code',
		'permission_callback' => 'us_mcp_custom_code_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/**
 * @param array $input
 * @return array|WP_Error
 */
function us_mcp_ability_set_custom_code( $input ) {
	$input = (array) $input;
	$field = isset( $input['field'] ) ? (string) $input['field'] : '';
	$value = isset( $input['value'] ) ? (string) $input['value'] : '';
	$mode  = isset( $input['mode'] ) ? (string) $input['mode'] : 'replace';
	// Note: field and mode are checked against the input_schema enums by the Abilities API before this callback runs

	if ( ! function_exists( 'usof_save_options' ) OR ! function_exists( 'usof_load_options_once' ) ) {
		return new WP_Error(
			'us_mcp_custom_code_core_not_loaded',
			'usof_save_options() / usof_load_options_once() are not available — us-core usof loader did not run.',
			array( 'status' => 503 )
		);
	}

	global $usof_options;
	usof_load_options_once();
	if ( ! is_array( $usof_options ) ) {
		// Saving would replace the whole options row with this one field, so refuse instead of starting from scratch
		return new WP_Error(
			'us_mcp_custom_code_options_unreadable',
			'Theme Options could not be loaded as an array — nothing was written.',
			array( 'status' => 503 )
		);
	}
	$updated_options = $usof_options;
	$before = isset( $updated_options[ $field ] ) ? (string) $updated_options[ $field ] : '';

	if ( $mode === 'append' ) {
		/*
		 * A retried call must not install the same snippet twice, even after other snippets were added
		 * in between: skip when the code is already in the field as whole lines (an append always starts
		 * on a new line), so `.btn{}` after `.footer .btn{}` still goes in. Line endings are normalized
		 * for the comparison only, so a retry with CRLF matches a stored LF copy
		 */
		$snippet = trim( str_replace( "\r\n", "\n", $value ) );
		$haystack = "\n" . trim( str_replace( "\r\n", "\n", $before ) ) . "\n";
		if (
			$snippet === ''
			OR strpos( $haystack, "\n" . $snippet . "\n" ) !== FALSE
		) {
			$value = $before;
		} else {
			$value = ( $before !== '' AND substr( $before, -1 ) !== "\n" )
				? $before . "\n" . $value
				: $before . $value;
		}
	}

	$changed = ( $value !== $before );
	if ( $changed ) {
		$updated_options[ $field ] = $value;

		// Runs the usof_after_save chain, which regenerates the CSS asset for custom_css
		usof_save_options( $updated_options );
	}

	return array(
		'field'   => $field,
		'mode'    => $mode,
		'changed' => $changed,
		'before'  => $before,
		'value'   => $value,
	);
}
