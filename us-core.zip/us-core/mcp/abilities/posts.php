<?php
/**
 * UpSolution MCP — generic post CRUD abilities.
 *
 * Six abilities for editing any of the UpSolution-authored post types via
 * the builder shortcode pipeline:
 *
 *   upsolution-list-posts
 *   upsolution-get-post
 *   upsolution-create-post
 *   upsolution-update-post
 *   upsolution-duplicate-post
 *   upsolution-delete-post
 *
 * Every tool requires a `post_type` argument constrained to the registry in
 * us_mcp_post_types(). For each registered type the registry records which
 * optional payload fields make sense:
 *
 *   - supports_excerpt   — include excerpt in input / output
 *   - supports_thumbnail — accept featured_image_id (= attachment id), return
 *                         featured_image_id and featured_image_url
 *   - taxonomies         — taxonomy slugs whose terms may be assigned via the
 *                         `terms` input and returned in the `terms` output
 *
 * The meta keys the agent may read / write per type (testimonial author
 * fields, Additional Settings, ACF fields, etc.) come from
 * us_mcp_post_type_meta_whitelist().
 *
 * Per-type capability comes from the registered post type object's `cap`
 * mapping, so testimonials (capability_type=page) require edit_pages, while
 * portfolio (default capability_type=post) requires edit_posts, etc. White-
 * label remapping of template post types is honoured automatically.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Registry of post types this server exposes, plus the optional payload fields
 * that apply to each.
 *
 * Built dynamically from the live site so the agent can edit the post types the
 * theme surfaces in the admin menu, not a hardcoded handful. The set mirrors
 * the "Post List" element exactly:
 *   - post types  = us_get_loop_post_types() (the checkboxes under
 *                   "Post List → Post Type"), minus `attachment`, PLUS the two
 *                   UpSolution authoring types that list deliberately skips but
 *                   this server has always supported (us_content_template,
 *                   us_page_block).
 *   - taxonomies  = the per-type object taxonomies intersected with
 *                   us_get_taxonomies() (the "Posts with specific taxonomies"
 *                   dropdown) — so only taxonomies the theme treats as
 *                   archive-capable are assignable.
 *
 * Scope caveat: it is NOT literally every registered type. The base set comes
 * from us_get_loop_post_types(), which only lists types with show_in_menu=TRUE,
 * and the enum is snapshotted when the abilities register on
 * wp_abilities_api_init — so a public type registered with show_in_menu=FALSE,
 * or on `init` at a priority later than that hook, will not appear. This still
 * covers WooCommerce products and the usual custom post types.
 *
 * Keys are real WP post-type slugs. Values:
 *   supports_excerpt   bool   — post_type_supports( $pt, 'excerpt' )
 *   supports_thumbnail bool   — post_type_supports( $pt, 'thumbnail' )
 *   hierarchical       bool   — is_post_type_hierarchical( $pt ); gates the
 *                               `parent` field on create / update.
 *   taxonomies         string[]  taxonomy slugs available for term assignment
 *
 * The meta keys of a type are not part of the registry — see
 * us_mcp_post_type_meta_whitelist(), built only when a tool needs them.
 *
 * @return array<string, array{supports_excerpt: bool, supports_thumbnail: bool, hierarchical: bool, taxonomies: string[]}>
 */
function us_mcp_post_types() {
	// Memoised for the request: the registry is consulted many times (permission
	// gate, every validator, the payload serializer, the registration loops) and
	// each build queries the post-type / taxonomy registries. Cache the assembled
	// result. Safe because PHP returns arrays by value, so a caller mutating its
	// copy can't reach this static.
	static $types = NULL;
	if ( $types !== NULL ) {
		return $types;
	}

	// Base slug set — same source as the Post List element. Guarded so an early
	// hook (before the theme helpers load) still yields the legacy core set
	// rather than fataling.
	if ( function_exists( 'us_get_loop_post_types' ) ) {
		$slugs = array_keys( us_get_loop_post_types( TRUE ) );
	} else {
		$slugs = array( 'page', 'post', 'us_portfolio', 'us_testimonial' );
	}
	// post_list.php drops `attachment`; do the same (media is handled by the
	// dedicated media abilities, not the post CRUD surface). Inbound Messages are
	// not authored content but visitors' contact form submissions, stored as
	// published posts — read_post would hand their personal data to any author.
	$slugs = array_values( array_diff( $slugs, array( 'attachment', 'us_cform_inbound' ) ) );
	// UpSolution authoring types the loop list skips but this server supports.
	foreach ( array( 'us_content_template', 'us_page_block' ) as $extra ) {
		if ( ! in_array( $extra, $slugs, TRUE ) ) {
			$slugs[] = $extra;
		}
	}

	// Archive-capable taxonomies the theme exposes — the closed set the agent
	// may assign terms from. When us_get_taxonomies() is available we honour its
	// result verbatim (even an empty one) so the assignable set never widens
	// beyond the theme's archive-capable taxonomies; only when the helper is
	// missing entirely (an early hook, before the theme loads) do we fall back
	// to every object taxonomy for the type.
	$restrict_tax = function_exists( 'us_get_taxonomies' );
	$available_tax = $restrict_tax
		? array_keys( us_get_taxonomies( /* public_only */ FALSE, /* show_slug */ FALSE ) )
		: array();

	$types = array();
	foreach ( $slugs as $pt ) {
		if ( ! post_type_exists( $pt ) ) {
			continue;
		}

		$obj_tax = get_object_taxonomies( $pt );
		$taxonomies = $restrict_tax
			? array_values( array_intersect( $obj_tax, $available_tax ) )
			: array_values( $obj_tax );

		$types[ $pt ] = array(
			'supports_excerpt' => (bool) post_type_supports( $pt, 'excerpt' ),
			'supports_thumbnail' => (bool) post_type_supports( $pt, 'thumbnail' ),
			'hierarchical' => (bool) is_post_type_hierarchical( $pt ),
			'taxonomies' => $taxonomies,
		);
	}

	return $types;
}

/**
 * The enum used in input_schema for every `post_type` field.
 *
 * @return string[]
 */
function us_mcp_post_type_enum() {
	return array_keys( us_mcp_post_types() );
}

// Register the MCP discovery-UI category that every UpSolution ability lives in.
add_action( 'wp_abilities_api_categories_init', function () {
	wp_register_ability_category( 'upsolution', array(
		'label' => 'UpSolution',
		'description' => 'Post / page / portfolio / testimonial / template authoring and theme inspection for the Impreza / Zephyr themes.',
	) );
} );

add_action( 'wp_abilities_api_init', 'us_mcp_register_post_abilities' );

/**
 * Register the generic CRUD abilities.
 *
 * @return void
 */
function us_mcp_register_post_abilities() {
	$type_enum = us_mcp_post_type_enum();

	// Union of taxonomies across every registered post type — used as the
	// enum on the list-posts `taxonomy` filter, so the agent sees the closed
	// set up front rather than getting a 400 only after the call lands.
	// (Per-post-type validity is checked at runtime in the execute callback.)
	$taxonomy_union = array();
	foreach ( us_mcp_post_types() as $pt_spec ) {
		foreach ( $pt_spec['taxonomies'] as $tax_slug ) {
			$taxonomy_union[ $tax_slug ] = TRUE;
		}
	}
	$taxonomy_enum = array_keys( $taxonomy_union );

	// -----------------------------------------------------------------
	// list-post-types  (discovery — the per-site matrix)
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/list-post-types', array(
		'label' => 'List editable post types',
		'description' => 'Discovery tool: list every post type this server can edit on THIS site, with its capabilities. The set is built from the theme (the same post types the "Post List" element offers, plus Page Templates and Reusable Blocks) and varies per install — custom post types and WooCommerce products appear here when present. For each type returns: slug, label, whether it is hierarchical (supports a parent / tree), whether it is public, whether it supports an excerpt and a featured image, the taxonomies you may assign terms from (slug + label + hierarchical), and the whitelist of meta keys you may read / write (`meta_keys`, with the value format of each in `meta_fields`) — built-in Impreza meta plus the site\'s ACF custom fields (single values, lists, links, Repeater and Flexible Content rows). Call this FIRST when working with a non-default type, so you know which taxonomies are bound to it and which optional fields apply. Other third-party meta (e.g. WooCommerce price) is not listed.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'properties' => array(), // no inputs (the adapter strips the empty map)
		),
		'output_schema' => array(
			'type' => 'array',
			'items' => array(
				'type' => 'object',
				'properties' => array(
					'slug' => array( 'type' => 'string' ),
					'label' => array( 'type' => 'string' ),
					'hierarchical' => array(
						'type' => 'boolean',
						'description' => 'TRUE when the type forms a parent/child tree — create-post / update-post accept `parent` only for these.',
					),
					'public' => array(
						'type' => 'boolean',
						'description' => 'TRUE when the type has a public front-end URL.',
					),
					'supports_excerpt' => array( 'type' => 'boolean' ),
					'supports_thumbnail' => array( 'type' => 'boolean' ),
					'taxonomies' => array(
						'type' => 'array',
						'description' => 'Taxonomies whose terms may be assigned to this type via the `terms` input.',
						'items' => array(
							'type' => 'object',
							'properties' => array(
								'slug' => array( 'type' => 'string' ),
								'label' => array( 'type' => 'string' ),
								'hierarchical' => array( 'type' => 'boolean' ),
							),
						),
					),
					'meta_keys' => array(
						'type' => 'array',
						'description' => 'Whitelisted meta keys readable / writable via the `meta` input on create-post / update-post: built-in Impreza keys plus the site\'s ACF fields. See `meta_fields` for the value format of each key.',
						'items' => array( 'type' => 'string' ),
					),
					'meta_fields' => array(
						'type' => 'array',
						'description' => 'One entry per key in `meta_keys`, describing the value to send. `type`: string; int; number (int or float, within `min` / `max` when present); bool_01 (0 / 1); enum (one of `values`); color (`format` "hex" = #rrggbb, "hex or rgba()" also allows rgba(r,g,b,a), "palette" = the syntax upsolution-set-palette accepts); date / datetime / time (exact `format`, e.g. date "20261031"); attachment / post / user (id of an existing media file / post / user — list-media, list-posts; `post_types` limits a post); list (array of `item_type` values: enum keys from `values`, post / attachment ids, or strings; `min` / `max` items); link (object {url, title, target}, target "" or "_blank"); group (object {sub field name: value}, see `sub_fields`); rows (Repeater: array of objects {sub field name: value}, sub fields described in `sub_fields` the same way as top-level keys; `min` / `max` rows); layouts (Flexible Content: array of blocks {"acf_fc_layout": layout name, sub field name: value}, optional "acf_fc_layout_disabled": true hides a block on the site, "acf_fc_layout_custom_label" titles it in the editor; see `layouts`). Writing a list / rows field replaces its whole value; `min` counts apply on publish only. `required`: the key must hold a value before the post can be published (a draft may leave it empty). For ACF fields `label` and `description` are the field label and instructions.',
						'items' => array(
							'type' => 'object',
							'properties' => array(
								'key' => array( 'type' => 'string' ),
								'type' => array( 'type' => 'string' ),
								'values' => array(
									'type' => 'array',
									'items' => array( 'type' => 'string' ),
								),
								'min' => array( 'type' => 'number' ),
								'max' => array( 'type' => 'number' ),
								'format' => array( 'type' => 'string' ),
								'required' => array( 'type' => 'boolean' ),
								'label' => array( 'type' => 'string' ),
								'description' => array( 'type' => 'string' ),
								'item_type' => array( 'type' => 'string' ),
								'post_types' => array(
									'type' => 'array',
									'items' => array( 'type' => 'string' ),
								),
								'sub_fields' => array(
									'type' => 'array',
									'description' => 'group / rows: the sub fields, each described like a `meta_fields` entry.',
								),
								'layouts' => array(
									'type' => 'array',
									'description' => 'layouts: {name, label, min, max, sub_fields} per Flexible Content layout.',
								),
							),
						),
					),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_list_post_types',
		'permission_callback' => 'us_mcp_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// list-posts
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/list-posts', array(
		'label' => 'List posts of a given type',
		'description' => 'List posts of the given post_type (the `post_type` enum lists every type editable on this site — call upsolution-list-post-types for the full per-type matrix), optionally filtered by status, free-text search, a taxonomy term, or parent. Returns a compact list of id/slug/title/modified/status/link/parent/menu_order suitable for picking a record to edit or walking a hierarchy tree.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type' ),
			'properties' => array(
				'post_type' => array(
					'type' => 'string',
					'description' => 'Which post type to list. Use upsolution-get-theme-option with name "enable_portfolio" / "enable_testimonials" if you are unsure whether the type is active on this site.',
					'enum' => $type_enum,
				),
				'status' => array(
					'type' => 'string',
					'description' => 'Comma-separated WP post statuses (e.g. "publish,draft", "future" to list scheduled posts, or "any"). Default: "publish,draft". Unknown statuses are rejected. Users who cannot edit others\' posts of the type see everyone\'s published posts but only their OWN drafts / pending / scheduled / trashed posts.',
					'default' => 'publish,draft',
				),
				'search' => array(
					'type' => 'string',
					'description' => 'Optional. Forwarded to WP_Query\'s full-text search (`s`): matches against post_title, post_content AND post_excerpt, and splits the query into space-separated terms required to ALL match. Caveat: post_content holds raw shortcode markup, so a query like "primary" matches every post whose markup contains color="_content_primary", and "row" matches everything with a [vc_row]. For exact lookup of a known title, prefer upsolution-get-post with `slug` (or `id`).',
				),
				'taxonomy' => array(
					'type' => 'string',
					'description' => 'Restrict to posts assigned to the given term. Taxonomy slug; the enum lists every taxonomy registered for ANY exposed post type, but the slug must also be registered for the post_type you pass (otherwise 400). Call upsolution-list-post-types for the per-type taxonomy matrix.',
					'enum' => $taxonomy_enum,
				),
				'term_id' => array(
					'type' => 'integer',
					'description' => 'Term id to filter by. Required together with `taxonomy`.',
				),
				'parent' => array(
					'type' => 'integer',
					'description' => 'Restrict to direct children of this parent post id (post_parent). Pass 0 to list only top-level posts. Combine with orderby="menu_order" to walk a hierarchical type (page / hierarchical CPT) level by level.',
				),
				'orderby' => array(
					'type' => 'string',
					'enum' => array( 'modified', 'menu_order' ),
					'default' => 'modified',
					'description' => '"modified" (default) sorts most-recently-edited first; "menu_order" sorts by the manual sibling order ascending (then title) — the natural order for displaying a hierarchy tree.',
				),
				'per_page' => array(
					'type' => 'integer',
					'description' => 'Maximum number of posts to return (default 20, max 100).',
					'default' => 20,
					'minimum' => 1,
					'maximum' => 100,
				),
			),
		),
		'output_schema' => array(
			'type' => 'array',
			'items' => array(
				'type' => 'object',
				'properties' => array(
					'id' => array( 'type' => 'integer' ),
					'post_type' => array( 'type' => 'string' ),
					'slug' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'modified' => array( 'type' => array( 'string', 'null' ) ),
					'date' => array( 'type' => array( 'string', 'null' ) ),
					'status' => array( 'type' => 'string' ),
					'link' => array( 'type' => 'string' ),
					'parent' => array( 'type' => 'integer' ),
					'menu_order' => array( 'type' => 'integer' ),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_list_posts',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// get-post
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/get-post', array(
		'label' => 'Get a single post',
		'description' => 'Fetch the full record for one post of the given type. Returns the shortcode `content`, plus excerpt / featured_image_id / featured_image_url / terms / meta when the type supports them. Pass either `id` or `slug` together with `post_type` (slugs can collide between types, so post_type is required).',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type' ),
			'properties' => array(
				'post_type' => array( 'type' => 'string', 'enum' => $type_enum ),
				'id' => array( 'type' => 'integer', 'description' => 'Post id. Either id or slug is required.' ),
				'slug' => array(
					'type' => 'string',
					'description' => 'Post slug. For flat (non-hierarchical) types pass a single segment (no slashes). For hierarchical types (page and any hierarchical custom post type) the resolver walks the tree, so a "parent/child" path is accepted too. Either id or slug is required.',
				),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'properties' => us_mcp_post_output_properties( /* include_content */ TRUE ),
		),
		'execute_callback' => 'us_mcp_ability_get_post',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// create-post
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/create-post', array(
		'label' => 'Create a post',
		'description' => 'Create a new post of the given type with UpSolution shortcode markup. Defaults to status "publish" when the user may publish this type, otherwise to "draft" (an explicit "publish" / "future" / "private" without that capability is rejected); to schedule it for future publication pass a future `date` (ISO 8601) — WordPress sets the status to "future" and publishes it automatically at that time. By default the response is a small status stub (id/title/status/modified/link/...); pass return_content=true to echo the saved post_content back. Authoring rules and the required pre-read docs are in the server instructions; per-element design (color / spacing / borders / typography) goes in the css="..." attribute as URL-encoded JSON in DOUBLE quotes, color_scheme is a fixed enum only. Optional fields (excerpt / featured_image_id / terms / meta) are silently ignored when the chosen post_type does not support them — call upsolution-list-post-types for the per-type matrix (supported fields, bound taxonomies, hierarchy). `parent` builds a tree and is accepted only for hierarchical types.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type', 'title' ),
			'properties' => us_mcp_post_input_properties( /* for_create */ TRUE, $type_enum ),
		),
		'output_schema' => array(
			'type' => 'object',
			'properties' => array_merge(
				us_mcp_post_output_properties( /* include_content */ FALSE ),
				us_mcp_markup_normalized_output_property()
			),
		),
		'execute_callback' => 'us_mcp_ability_create_post',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// update-post
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/update-post', array(
		'label' => 'Update a post',
		'description' => 'Update an existing post of the given type. Lookup is by id or slug; any of title/new_slug/status/date/content/excerpt/parent/menu_order/featured_image_id/terms/meta may be changed. Omitted fields are left untouched. `parent` re-parents a hierarchical post (0 = top level); it is rejected for flat types — call upsolution-list-post-types to check. A future `date` (ISO 8601) schedules the post for later publication (status becomes "future"); a past `date` back-dates it. By default the response is a small status stub (id/title/status/modified/link/...); pass return_content=true to echo the saved post_content back. Authoring rules and the required pre-read docs are in the server instructions; per-element design goes in css="..." as URL-encoded JSON in DOUBLE quotes.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type' ),
			'properties' => us_mcp_post_input_properties( /* for_create */ FALSE, $type_enum ),
		),
		'output_schema' => array(
			'type' => 'object',
			'properties' => array_merge(
				us_mcp_post_output_properties( /* include_content */ FALSE ),
				array(
					'patches_applied' => array(
						'type' => 'array',
						'description' => 'Present when `patches` was used. Per-patch report of what was applied.',
						'items' => array(
							'type' => 'object',
							'properties' => array(
								'index' => array( 'type' => 'integer' ),
								'matches' => array( 'type' => 'integer' ),
								'bytes_before' => array( 'type' => 'integer' ),
								'bytes_after' => array( 'type' => 'integer' ),
							),
						),
					),
					'content_bytes' => array(
						'type' => 'integer',
						'description' => 'Present when `patches` was used. Size of the resulting post_content in bytes — lets callers track page size without echoing the body.',
					),
				),
				us_mcp_markup_normalized_output_property()
			),
		),
		'execute_callback' => 'us_mcp_ability_update_post',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// duplicate-post
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/duplicate-post', array(
		'label' => 'Duplicate a post',
		'description' => 'Server-side copy of an existing post of the given type in one call, without reading it first. Clones post_content, excerpt, page attributes (parent / menu order / comment + ping status), EVERY taxonomy term, the featured image, and ALL custom meta (builder data, page / SEO settings, custom fields). The copy defaults to status "draft" and a "<title> (copy)" title so a duplicate never goes live unexpectedly; override title / new_slug / status / date as needed. The copy is authored by the current user (the source author is kept only for users who may edit others\' posts). WordPress-internal bookkeeping meta (edit locks, old-slug / old-date history, trash markers) is intentionally not copied. Returns the new post stub plus source_id; pass return_content=true to echo the copied body.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type' ),
			'properties' => array(
				'post_type' => array( 'type' => 'string', 'enum' => $type_enum ),
				'id' => array( 'type' => 'integer', 'description' => 'Source post id. Either id or slug is required.' ),
				'slug' => array(
					'type' => 'string',
					'description' => 'Source post slug — single segment (no slashes) for flat types; hierarchical types (page and hierarchical CPTs) also accept a "parent/child" path. Either id or slug is required.',
				),
				'title' => array(
					'type' => 'string',
					'description' => 'Title for the copy. Default: the source title with " (copy)" appended.',
				),
				'new_slug' => array(
					'type' => 'string',
					'description' => 'Slug for the copy — single segment, no slashes. Default: derived from the title by WordPress and kept unique.',
				),
				'status' => array(
					'type' => 'string',
					'enum' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
					'default' => 'draft',
					'description' => 'Status of the copy. Default "draft" so duplicates do not publish themselves. "future" + a future `date` schedules it.',
				),
				'date' => array(
					'type' => 'string',
					'description' => 'Publication date/time for the copy as an ISO 8601 string (same forms as create-post / update-post). A future value schedules the copy; omit to use the current time.',
				),
				'return_content' => array(
					'type' => 'boolean',
					'description' => 'Echo the copied post_content back in the response. Default false.',
					'default' => FALSE,
				),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'properties' => array_merge(
				us_mcp_post_output_properties( /* include_content */ FALSE ),
				array(
					'source_id' => array( 'type' => 'integer', 'description' => 'Id of the post that was copied.' ),
				)
			),
		),
		'execute_callback' => 'us_mcp_ability_duplicate_post',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	// -----------------------------------------------------------------
	// delete-post
	// -----------------------------------------------------------------
	wp_register_ability( 'upsolution/delete-post', array(
		'label' => 'Move a post to the trash',
		'description' => 'Move a post of the given type to the trash. This is the only deletion this tool performs — permanent deletion is intentionally NOT available via MCP, so a removed post can always be restored from wp-admin (Trash). Calling it on an already-trashed post is a no-op that still reports trashed=true (idempotent — safe to retry).',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'post_type' ),
			'properties' => array(
				'post_type' => array( 'type' => 'string', 'enum' => $type_enum ),
				'id' => array( 'type' => 'integer', 'description' => 'Post id. Either id or slug is required.' ),
				'slug' => array(
					'type' => 'string',
					'description' => 'Single-segment post slug (no slashes) for flat types; hierarchical types (page and hierarchical CPTs) accept "parent/child" paths. Either id or slug is required.',
				),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'deleted' => array(
					'type' => 'boolean',
					'description' => 'Always false — this tool never permanently deletes. Kept for response-shape stability.',
				),
				'trashed' => array(
					'type' => 'boolean',
					'description' => 'True once the post is in the trash (or already was).',
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_delete_post',
		'permission_callback' => 'us_mcp_post_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
}

// ---------------------------------------------------------------------
// Schema helpers
// ---------------------------------------------------------------------

/**
 * Properties for the get/create/update response. Marker fields that only
 * make sense for some types (excerpt, featured_image_*, terms, meta) are
 * declared at top level — agents inspecting the schema see what *can* be
 * returned; runtime payloads only populate them when the actual type
 * supports the field.
 *
 * @param bool $include_content Whether `content` (the shortcode body) is part of the response.
 * @return array<string, array>
 */
function us_mcp_post_output_properties( $include_content ) {
	$props = array(
		'id' => array( 'type' => 'integer' ),
		'post_type' => array( 'type' => 'string' ),
		'slug' => array( 'type' => 'string' ),
		'title' => array( 'type' => 'string' ),
		'status' => array( 'type' => 'string' ),
		'modified' => array(
			'type' => array( 'string', 'null' ),
			'description' => 'ISO 8601 GMT timestamp, or null in the rare case the post has no valid modification or insertion timestamp on record.',
		),
		'date' => array(
			'type' => array( 'string', 'null' ),
			'description' => 'ISO 8601 GMT publication date. For a scheduled post (status "future") this is when it will go live; null when the post has no valid date on record.',
		),
		'link' => array( 'type' => 'string' ),
		'edit_link' => array( 'type' => 'string' ),
		'parent' => array(
			'type' => 'integer',
			'description' => 'Id of the parent post (0 = top level). Only ever non-zero for hierarchical types (page and hierarchical custom post types).',
		),
		'menu_order' => array(
			'type' => 'integer',
			'description' => 'Manual sort position among siblings (lower sorts first). Relevant for hierarchical types and any list ordered by menu_order.',
		),
	);
	if ( $include_content ) {
		$props['content'] = array( 'type' => 'string' );
		$props['excerpt'] = array(
			'type' => 'string',
			'description' => 'Present only when the type supports excerpts (see supports_excerpt in upsolution-list-post-types).',
		);
		$props['featured_image_id'] = array(
			'type' => array( 'integer', 'null' ),
			'description' => 'Attachment id, or null when no thumbnail set. Present only when the type supports thumbnails.',
		);
		$props['featured_image_url'] = array(
			'type' => array( 'string', 'null' ),
			'description' => 'Full-size attachment URL. For us_testimonial this is the author photo.',
		);
		$props['terms'] = array(
			'type' => 'object',
			'description' => 'Map of taxonomy slug → [{id, name, slug}]. Only taxonomies registered for the post type appear.',
		);
		$props['meta'] = array(
			'type' => 'object',
			'description' => 'Whitelisted meta keys for the post type (e.g. us_testimonial_author / us_tile_icon, plus the site\'s ACF fields) with their raw stored values — the same format create-post / update-post accept, see `meta_fields` in upsolution-list-post-types. ACF lists, links, Groups, Repeater and Flexible Content come as arrays / objects; post and media ids are returned as integers, without titles or content.',
		);
	}

	return $props;
}

/**
 * Output property reporting what the write normalized in the submitted markup
 * (see shortcode-markup.php). Shared by create-post and update-post.
 *
 * @return array<string, array>
 */
function us_mcp_markup_normalized_output_property() {
	return array(
		'markup_normalized' => array(
			'type' => 'object',
			'description' => 'Present only when the saved post_content differs from the markup you sent: line breaks between a tag\'s attributes were joined and/or [ ] inside quoted attribute values were escaped as `{` / `}` — the form Live Builder saves. Counts, affected tags and a note.',
			'properties' => array(
				'line_breaks_joined' => array( 'type' => 'integer' ),
				'brackets_escaped' => array( 'type' => 'integer' ),
				'tags' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'note' => array( 'type' => 'string' ),
			),
		),
	);
}

/**
 * Properties for create-post / update-post input schemas. `for_create` adds
 * the `title` requirement implicitly (handled by the caller's `required` list).
 *
 * @param bool $for_create
 * @param string[] $type_enum
 * @return array<string, array>
 */
function us_mcp_post_input_properties( $for_create, $type_enum ) {
	$props = array(
		'post_type' => array( 'type' => 'string', 'enum' => $type_enum ),
	);
	if ( $for_create ) {
		$props['title'] = array( 'type' => 'string', 'description' => 'Human-readable title.' );
		$props['slug'] = array(
			'type' => 'string',
			'description' => 'Optional lowercase-hyphenated slug — a single segment, no slashes (stored as post_name; the position in a hierarchy tree is set separately via the `parent` field). Derived from the title if omitted.',
		);
		$props['status'] = array(
			'type' => 'string',
			'enum' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
			'default' => 'publish',
			'description' => 'Post status. Default "publish" if the user may publish this post type, otherwise "draft"; "publish" / "future" / "private" require the publish capability. Use "future" together with a future `date` to schedule the post for later publication — WordPress publishes it automatically at that time. (Passing a future `date` with status "publish" schedules it too.)',
		);
		$props['content'] = array(
			'type' => 'string',
			'description' => 'Body — UpSolution shortcode markup (e.g. [vc_row]...[/vc_row]). Saved in the form Live Builder writes: line breaks between a tag\'s attributes are joined and [ ] inside quoted attribute values are escaped as `{` / `}`; `markup_normalized` in the response reports it.',
		);
	} else {
		$props['id'] = array( 'type' => 'integer', 'description' => 'Post id. Either id or slug is required.' );
		$props['slug'] = array(
			'type' => 'string',
			'description' => 'Single-segment post slug for flat types; hierarchical types (page and hierarchical CPTs) accept "parent/child" paths (the resolver walks the tree). Either id or slug is required.',
		);
		$props['title'] = array( 'type' => 'string' );
		$props['new_slug'] = array(
			'type' => 'string',
			'description' => 'New slug — single segment, no slashes. Renames the post_name only; to move the post within a hierarchy use the `parent` field.',
		);
		$props['status'] = array(
			'type' => 'string',
			'enum' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
			'description' => 'Post status. "future" + a future `date` schedules publication (the post auto-publishes at that time). Omit to leave the status unchanged.',
		);
		$props['content'] = array(
			'type' => 'string',
			'description' => 'Full replacement body. Normalized like create-post `content` (attribute line breaks joined, [ ] in quoted values escaped); the same applies to the result of `patches`.',
		);
		$props['patches'] = array(
			'type' => 'array',
			'description' => 'Sequential literal find/replace patches applied to post_content. Byte-exact match (not regex), case-sensitive. Each patch must occur exactly `expect_matches` times in the current content or the WHOLE call is rejected with no DB write (atomic). Patches are applied in array order; later patches see the result of earlier ones. Mutually exclusive with `content` — pass one or the other. Use this instead of resending the whole body for small edits.',
			'maxItems' => 50,
			'items' => array(
				'type' => 'object',
				'required' => array( 'find', 'replace' ),
				'properties' => array(
					'find' => array(
						'type' => 'string',
						'minLength' => 1,
						'description' => 'Literal byte-exact substring to find in the raw post_content (not regex, case-sensitive). Mind UpSolution attribute encoding: link= JSON, css= JSON, and group attributes (items= / responsive= / tax_query= / …) are stored URL-encoded in double quotes — match `link="%7B%22url%22%3A%22%2Fsignup%22%7D"`, `css="%7B%22color%22%3A..."`, NOT the decoded form. Content saved before us-core 8.16 may still carry the legacy pipe form (`link="url:%2Fsignup"`) — match the bytes actually present. JSON `\\"` is one level of escaping — in the matched content it is a single literal `"`. The body may also contain hand-edited single-quoted attribute values; match the exact bytes present rather than what you would emit from scratch.',
					),
					'replace' => array(
						'type' => 'string',
						'description' => 'Replacement (empty string deletes the matched range).',
					),
					'expect_matches' => array(
						'type' => 'integer',
						'minimum' => 1,
						'default' => 1,
						'description' => 'Number of times `find` must occur in the current post_content before this patch is applied. Default 1 — asserts uniqueness. Set higher for an intentional bulk replace.',
					),
				),
			),
		);
	}
	$props['date'] = array(
		'type' => 'string',
		'description' => 'Intended publication date/time as an ISO 8601 string. A value WITH an explicit offset or trailing "Z" (e.g. "2026-07-01T09:00:00+03:00", "2026-07-01T06:00:00Z") is read as an absolute instant; a bare datetime WITHOUT an offset (e.g. "2026-07-01 09:00:00", "2026-07-01") is read as the site\'s local time. A FUTURE value schedules the post for later publication — WordPress sets the status to "future" and publishes it automatically at that time (you may also set status "future" explicitly). A PAST value back-dates the post. Omit to publish now (create) or keep the existing date (update).',
	);
	$props['return_content'] = array(
		'type' => 'boolean',
		'description' => 'Echo the saved post_content back in the response. Default false — most callers do not need the body returned after a successful write; check `modified` to confirm the write landed.',
		'default' => FALSE,
	);
	$props['excerpt'] = array(
		'type' => 'string',
		'description' => 'Plain-text excerpt. Ignored for types that do not support excerpts.',
	);
	$props['featured_image_id'] = array(
		'type' => array( 'integer', 'null' ),
		'description' => 'Attachment id to use as the featured image. Pass null to clear an existing thumbnail. Ignored for types without thumbnail support. For us_testimonial this sets the author photo.',
	);
	$props['terms'] = array(
		'type' => 'object',
		'description' => 'Map of taxonomy slug → array of term ids to assign. Only taxonomies registered for the post type are accepted; unknown keys return 400. Use upsolution-list-terms to resolve names to ids.',
		'additionalProperties' => array(
			'type' => 'array',
			'items' => array( 'type' => 'integer' ),
		),
	);
	$props['meta'] = array(
		'type' => 'object',
		'description' => 'Map of whitelisted meta key → value. The whitelist is `meta_keys` in upsolution-list-post-types — built-in Impreza keys plus the site\'s ACF fields; `meta_fields` there gives each key\'s value type and format (ACF dates / numbers / choices / media ids are validated against it). Values are type-checked against the per-key spec: bool fields accept TRUE/FALSE/0/1 (normalised to 0|1), enum fields require a value from the allowed set (e.g. us_testimonial_rating ∈ {none,1,2,3,4,5}; us_tile_size ∈ {1x1,2x1,1x2,2x2}; us_sidebar_pos ∈ {left,right}; us_header_sticky_pos ∈ {"",bottom,above,below}), built-in color fields use the same syntax upsolution-set-palette accepts (hex / rgba / linear-gradient / palette token `_slug` — hsl/hsla and non-linear gradients are NOT supported). ACF list / link / group / Repeater / Flexible Content fields take an array or object in the format of `meta_fields` (the same structure get-post returns); writing one REPLACES its whole value — to change one row, read the field, edit it and send the full array. Pass null (or "") to clear a key: the stored meta is DELETED and the post reverts to Theme Options / defaults for that setting. For the page-layout `*_id` keys (us_header_id / us_titlebar_id / us_content_id / us_sidebar_id / us_footer_id) clearing means "use defaults" — to hide the area instead, send "0"; full value-semantics table in the `post-types` doc (upsolution-read-doc). Unknown keys return 400; bad value types return 400.',
		'additionalProperties' => array( 'type' => array( 'string', 'number', 'boolean', 'null', 'array', 'object' ) ),
	);
	$props['parent'] = array(
		'type' => 'integer',
		'description' => 'Parent post id, for building a page / hierarchy tree. Pass 0 to move the post to the top level. ONLY accepted for hierarchical post types (page and hierarchical custom post types) — sending a non-zero parent for a flat type returns 400. The parent must be an existing post of the SAME post_type and must not be the post itself. Use upsolution-list-post-types to check whether a type is hierarchical, and list-posts (optionally with the `parent` filter) to find candidate parent ids.',
	);
	$props['menu_order'] = array(
		'type' => 'integer',
		'description' => 'Manual sort position among siblings (lower sorts first; defaults to 0). Mainly useful for ordering hierarchical posts (pages / hierarchical CPTs) and any list ordered by menu_order. Omit to leave unchanged.',
	);

	return $props;
}

// ---------------------------------------------------------------------
// Permission callback
// ---------------------------------------------------------------------

/**
 * Permission callback for every generic post ability. Reads `post_type` from
 * the input and consults the registered post-type object's capability map,
 * so capability_type=page (us_testimonial), default `post` (us_portfolio),
 * and the white-label-aware caps on us_content_template / us_page_block are
 * all honoured without hardcoding.
 *
 * For mutating operations the per-post check happens inside the execute
 * callback after the post has been resolved (we cannot resolve id/slug here
 * without doing the work twice). This callback gates broad type access.
 *
 * @param array|object $input
 * @return bool
 */
function us_mcp_post_permission_callback( $input ) {
	$input = (array) $input;
	$post_type = isset( $input['post_type'] ) ? (string) $input['post_type'] : '';
	if ( $post_type === '' OR ! isset( us_mcp_post_types()[ $post_type ] ) ) {
		// Caught later by execute callback with a clearer error message;
		// here we just reject obvious bad input at the transport layer.
		return current_user_can( 'edit_posts' );
	}
	if ( ! post_type_exists( $post_type ) ) {
		return FALSE;
	}
	$pt_obj = get_post_type_object( $post_type );
	if ( ! $pt_obj OR ! isset( $pt_obj->cap->edit_posts ) ) {
		return FALSE;
	}

	return current_user_can( $pt_obj->cap->edit_posts );
}

// ---------------------------------------------------------------------
// Execute helpers
// ---------------------------------------------------------------------

/**
 * Validate post_type input. Returns a normalised slug or WP_Error.
 *
 * @param array $input
 * @return string|WP_Error
 */
function us_mcp_validate_post_type( array $input ) {
	$type = isset( $input['post_type'] ) ? (string) $input['post_type'] : '';
	$registry = us_mcp_post_types();
	if ( $type === '' ) {
		return new WP_Error( 'us_mcp_posts_missing_post_type', 'Provide post_type.', array( 'status' => 400 ) );
	}
	if ( ! isset( $registry[ $type ] ) ) {
		return new WP_Error(
			'us_mcp_posts_unsupported_post_type',
			sprintf( 'post_type "%s" is not exposed via MCP. Supported: %s.', $type, implode( ', ', array_keys( $registry ) ) ),
			array( 'status' => 400 )
		);
	}
	if ( ! post_type_exists( $type ) ) {
		// e.g. us_portfolio with enable_portfolio=0
		return new WP_Error(
			'us_mcp_posts_post_type_disabled',
			sprintf( 'post_type "%s" is not enabled on this site (check Theme Options).', $type ),
			array( 'status' => 400 )
		);
	}

	return $type;
}

/**
 * Resolve an `id`/`slug` input pair to a post of the given type that the
 * current user may read (see us_mcp_user_can_read_post()).
 *
 * @param string $post_type
 * @param array $input
 * @return WP_Post|WP_Error
 */
function us_mcp_resolve_post( $post_type, array $input ) {
	$id = isset( $input['id'] ) ? (int) $input['id'] : 0;
	$slug = isset( $input['slug'] ) ? (string) $input['slug'] : '';

	if ( ! $id AND $slug === '' ) {
		return new WP_Error( 'us_mcp_posts_missing_identifier', 'Provide either id or slug.', array( 'status' => 400 ) );
	}

	// The "not found" answer is deliberately the same whether the post does not
	// exist or exists but the caller may not read it (another author's draft /
	// private / trashed post): the type-level permission_callback only checks
	// edit_posts, so a distinct 403 here would let a low-privilege caller probe
	// ids / slugs to enumerate other authors' non-public posts.
	$not_found = new WP_Error(
		'us_mcp_posts_post_not_found',
		$id ? sprintf( 'No %s with id %d.', $post_type, $id ) : sprintf( 'No %s with slug "%s".', $post_type, $slug ),
		array( 'status' => 404 )
	);

	if ( ! $id ) {
		// get_page_by_path works for any post type, not just `page`.
		$post = get_page_by_path( $slug, OBJECT, $post_type );
		if ( ! $post ) {
			return $not_found;
		}
		$id = (int) $post->ID;
	}

	$post = get_post( $id );
	if ( ! $post OR $post->post_type !== $post_type OR ! us_mcp_user_can_read_post( $post ) ) {
		return $not_found;
	}

	return $post;
}

/**
 * Validate the optional `parent` input (post_parent) for hierarchy edits.
 *
 * Returns:
 *   - NULL        `parent` not supplied — leave the post's parent unchanged.
 *   - int >= 0    the post_parent to store (0 = top level).
 *   - WP_Error    invalid input (400).
 *
 * `parent` is rejected for non-hierarchical types (only page and hierarchical
 * custom post types form a tree). The parent must be an existing post of the
 * SAME type, must not be the post itself, and must not be a descendant of the
 * post being updated (which would create a loop).
 *
 * @param array $input
 * @param string $post_type
 * @param bool $hierarchical Whether the post type is hierarchical.
 * @param int $self_id Id of the post being updated (0 on create).
 * @return int|null|WP_Error
 */
function us_mcp_validate_parent_input( array $input, $post_type, $hierarchical, $self_id = 0 ) {
	if ( ! array_key_exists( 'parent', $input ) ) {
		return NULL;
	}
	$parent = (int) $input['parent'];
	// 0 = top level: always valid (a harmless no-op for flat types).
	if ( $parent === 0 ) {
		return 0;
	}
	if ( ! $hierarchical ) {
		return new WP_Error(
			'us_mcp_posts_not_hierarchical',
			sprintf( 'post_type "%s" is not hierarchical, so `parent` must be 0 or omitted.', $post_type ),
			array( 'status' => 400 )
		);
	}
	if ( $self_id AND $parent === (int) $self_id ) {
		return new WP_Error( 'us_mcp_posts_bad_parent', 'A post cannot be its own parent.', array( 'status' => 400 ) );
	}
	$parent_post = get_post( $parent );
	if ( ! $parent_post OR $parent_post->post_type !== $post_type ) {
		return new WP_Error(
			'us_mcp_posts_bad_parent',
			sprintf( 'parent %d is not an existing %s.', $parent, $post_type ),
			array( 'status' => 400 )
		);
	}
	// Reject obvious cycles: the chosen parent must not sit below the post being
	// updated. Walk up the parent's ancestry; stop if we loop on pre-existing
	// bad data.
	if ( $self_id ) {
		$ancestor = $parent_post;
		$seen = array();
		while ( $ancestor AND (int) $ancestor->post_parent ) {
			$next = (int) $ancestor->post_parent;
			if ( $next === (int) $self_id ) {
				return new WP_Error(
					'us_mcp_posts_bad_parent',
					sprintf( 'parent %d is a descendant of post %d — that would create a loop.', $parent, $self_id ),
					array( 'status' => 400 )
				);
			}
			if ( isset( $seen[ $next ] ) ) {
				break;
			}
			$seen[ $next ] = TRUE;
			$ancestor = get_post( $next );
		}
	}

	return $parent;
}

/**
 * Per-post capability check. Returns TRUE or a WP_Error with 403.
 *
 * @param string $cap
 * @param int $post_id
 * @return true|WP_Error
 */
function us_mcp_require_cap( $cap, $post_id ) {
	if ( current_user_can( $cap, $post_id ) ) {
		return TRUE;
	}

	return new WP_Error( 'us_mcp_posts_forbidden', sprintf( 'You do not have permission to %s this post.', $cap ), array( 'status' => 403 ) );
}

/**
 * Guard elevated post statuses behind the post type's publish capability.
 *
 * The create / update / duplicate abilities gate on edit_posts / edit_post,
 * which by themselves let a contributor publish. Publishing, scheduling
 * (future) or privately publishing requires publish_posts in core, so enforce
 * it here for those statuses; draft / pending stay allowed.
 *
 * Mirrors core's _wp_translate_postdata() exception for updates: a post that
 * is already published / scheduled may stay in that group (publish <-> future)
 * without publish_posts, because the caller has already passed edit_post on it.
 * Likewise re-sending an unchanged "private" is not a status change.
 *
 * @param string $publish_cap The type's publish_posts capability.
 * @param string $status Requested status.
 * @param string $previous_status Current status when updating; '' for a new post.
 * @return true|WP_Error
 */
function us_mcp_require_publish_cap( $publish_cap, $status, $previous_status = '' ) {
	if ( ! in_array( $status, array( 'publish', 'future', 'private' ), TRUE ) ) {
		return TRUE;
	}
	if ( $status === $previous_status ) {
		return TRUE;
	}
	$published = array( 'publish', 'future' );
	if ( in_array( $status, $published, TRUE ) AND in_array( $previous_status, $published, TRUE ) ) {
		return TRUE;
	}
	if ( current_user_can( $publish_cap ) ) {
		return TRUE;
	}

	return new WP_Error(
		'us_mcp_posts_forbidden',
		sprintf( 'You do not have permission to set status "%s" for this post type.', $status ),
		array( 'status' => 403 )
	);
}

/**
 * Per-post read check used by the resolver.
 *
 * For types with mapped meta caps the `read_post` meta cap does the right thing
 * per status / author (own drafts, others' private posts via read_private_posts,
 * trashed posts via their pre-trash status). Third-party types registered with
 * a custom capability map and map_meta_cap=false would require the primitive
 * `read_<type>` cap, which such plugins rarely grant even to administrators —
 * for those the type's edit_post primitive (the same one update-post gates on)
 * is the usable proxy.
 *
 * read_post grants every published post to anyone with `read`, which is only
 * right for content the front end shows as is. A password-protected post, or a
 * post of a type with no public URL, is not public content even when published:
 * wp-admin shows its body only in the editor, so require edit_post there too.
 *
 * @param WP_Post $post
 * @return bool
 */
function us_mcp_user_can_read_post( WP_Post $post ) {
	$pt_obj = get_post_type_object( $post->post_type );
	if ( $pt_obj AND ! $pt_obj->map_meta_cap ) {
		return current_user_can( $pt_obj->cap->edit_post, $post->ID );
	}

	if (
		$pt_obj
		AND (
			(string) $post->post_password !== ''
			OR ! is_post_type_viewable( $pt_obj )
		)
	) {
		return current_user_can( $pt_obj->cap->edit_post, $post->ID );
	}

	return current_user_can( 'read_post', $post->ID );
}

/**
 * Format a GMT timestamp (with a local-time fallback) as an ISO 8601 string,
 * or NULL when both are the zeroed sentinel. Shared by the `modified` and
 * `date` payload fields.
 *
 * wp_insert_post() leaves the *_gmt column = '0000-00-00 00:00:00' for posts
 * inserted with a non-publish status (it mirrors post_date_gmt, which WP
 * intentionally zeroes for drafts / pending / auto-drafts). In that case fall
 * back to the local-time column (always set on insert), converted to GMT via
 * get_gmt_from_date(); if both are zeroed return NULL (shouldn't happen in
 * practice but keeps the contract explicit).
 *
 * The stored value is interpreted explicitly as UTC and emitted as a true GMT
 * ISO 8601 string ("...+00:00") regardless of the site's configured timezone —
 * mysql2date() would read it in the site timezone and mislabel the offset on a
 * non-UTC install.
 *
 * @param string $gmt A *_gmt column value (post_date_gmt / post_modified_gmt).
 * @param string $local The matching local-time column (post_date / post_modified).
 * @return string|null
 */
function us_mcp_format_gmt_date( $gmt, $local ) {
	$gmt = (string) $gmt;
	if ( $gmt === '' OR $gmt === '0000-00-00 00:00:00' ) {
		$local = (string) $local;
		if ( $local === '' OR $local === '0000-00-00 00:00:00' ) {
			return NULL;
		}
		$gmt = get_gmt_from_date( $local );
	}
	try {
		return ( new DateTimeImmutable( $gmt, new DateTimeZone( 'UTC' ) ) )->format( 'c' );
	}
	catch ( Exception $e ) {
		return NULL;
	}
}

/**
 * Parse the optional `date` input (an intended publication date) into the
 * post_date / post_date_gmt pair WordPress stores.
 *
 * Accepted forms:
 *   - ISO 8601 WITH an explicit offset or trailing "Z"
 *     ("2026-07-01T09:00:00+03:00", "2026-07-01T06:00:00Z") — read as an
 *     absolute instant, then split into the site-local post_date and the UTC
 *     post_date_gmt.
 *   - A bare datetime WITHOUT an offset ("2026-07-01 09:00:00",
 *     "2026-07-01T09:00:00") — read as SITE-LOCAL wall-clock time (the
 *     WordPress convention), then converted to GMT.
 *   - A date-only value ("2026-07-01") — treated as local midnight.
 *
 * @param mixed $value
 * @return array{post_date: string, post_date_gmt: string}|WP_Error
 */
function us_mcp_parse_date_input( $value ) {
	if ( ! is_scalar( $value ) ) {
		return new WP_Error( 'us_mcp_posts_bad_date', '`date` must be an ISO 8601 datetime string.', array( 'status' => 400 ) );
	}
	$raw = trim( (string) $value );
	if ( $raw === '' ) {
		return new WP_Error( 'us_mcp_posts_bad_date', '`date` must not be empty.', array( 'status' => 400 ) );
	}

	// Does the string carry its own UTC offset / "Z"? If so it is an absolute
	// instant; otherwise it is wall-clock time in the site timezone.
	$has_offset = (bool) preg_match( '~(?:Z|[+-]\d{2}:?\d{2})$~', $raw );

	try {
		if ( $has_offset ) {
			$gmt = ( new DateTimeImmutable( $raw ) )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );

			return array(
				'post_date' => get_date_from_gmt( $gmt ),
				'post_date_gmt' => $gmt,
			);
		}
		// No offset: a wall-clock value in the site timezone. Normalise it to
		// "Y-m-d H:i:s" (this also validates it) and derive GMT from there.
		$local = ( new DateTimeImmutable( $raw ) )->format( 'Y-m-d H:i:s' );

		return array(
			'post_date' => $local,
			'post_date_gmt' => get_gmt_from_date( $local ),
		);
	}
	catch ( Exception $e ) {
		return new WP_Error(
			'us_mcp_posts_bad_date',
			sprintf( 'Could not parse `date` "%s" as an ISO 8601 datetime.', $raw ),
			array( 'status' => 400 )
		);
	}
}

/**
 * Serialize a post into the response shape used by get/create/update.
 *
 * @param WP_Post $post
 * @param bool $include_content
 * @return array
 */
function us_mcp_post_to_payload( WP_Post $post, $include_content = FALSE ) {
	$registry = us_mcp_post_types();
	$spec = isset( $registry[ $post->post_type ] ) ? $registry[ $post->post_type ] : NULL;

	$out = array(
		'id' => (int) $post->ID,
		'post_type' => $post->post_type,
		'slug' => $post->post_name,
		'title' => $post->post_title,
		'status' => $post->post_status,
		'modified' => us_mcp_format_gmt_date( $post->post_modified_gmt, $post->post_modified ),
		'date' => us_mcp_format_gmt_date( $post->post_date_gmt, $post->post_date ),
		'link' => get_permalink( $post ),
		'edit_link' => admin_url( 'post.php?post=' . $post->ID . '&action=edit' ),
		'parent' => (int) $post->post_parent,
		'menu_order' => (int) $post->menu_order,
	);

	if ( ! $include_content OR ! $spec ) {
		return $out;
	}

	$out['content'] = $post->post_content;

	if ( $spec['supports_excerpt'] ) {
		$out['excerpt'] = $post->post_excerpt;
	}
	if ( $spec['supports_thumbnail'] ) {
		$thumb_id = (int) get_post_thumbnail_id( $post );
		$out['featured_image_id'] = $thumb_id ?: NULL;
		$out['featured_image_url'] = $thumb_id ? wp_get_attachment_url( $thumb_id ) : NULL;
	}
	if ( ! empty( $spec['taxonomies'] ) ) {
		$terms_out = array();
		foreach ( $spec['taxonomies'] as $tax ) {
			$terms = get_the_terms( $post, $tax );
			if ( is_wp_error( $terms ) OR empty( $terms ) ) {
				$terms_out[ $tax ] = array();
				continue;
			}
			$terms_out[ $tax ] = array_map( function ( $t ) {
				return array( 'id' => (int) $t->term_id, 'name' => $t->name, 'slug' => $t->slug );
			}, $terms );
		}
		$out['terms'] = $terms_out;
	}
	$meta_whitelist = us_mcp_post_type_meta_whitelist( $post->post_type );
	if ( ! empty( $meta_whitelist ) ) {
		$meta_out = array();
		foreach ( $meta_whitelist as $key => $meta_spec ) {
			$meta_out[ $key ] = us_mcp_get_meta_value( $post->ID, $key, $meta_spec );
		}
		$out['meta'] = $meta_out;
	}

	return $out;
}

/**
 * Validate / apply the optional `terms` input. Returns null on no-op, an
 * array of [taxonomy => int[]] to assign, or WP_Error on bad input.
 *
 * @param array $input
 * @param array $spec Registry entry for the post type.
 * @return array|null|WP_Error
 */
function us_mcp_validate_terms_input( array $input, array $spec ) {
	if ( ! array_key_exists( 'terms', $input ) ) {
		return NULL;
	}
	$terms = $input['terms'];
	if ( ! is_array( $terms ) ) {
		return new WP_Error( 'us_mcp_posts_bad_terms', 'terms must be an object of {taxonomy: [term_id, ...]}.', array( 'status' => 400 ) );
	}
	$allowed = $spec['taxonomies'];
	$out = array();
	foreach ( $terms as $tax => $ids ) {
		if ( ! in_array( $tax, $allowed, TRUE ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_terms',
				sprintf( 'Taxonomy "%s" is not registered for this post type. Allowed: %s.', $tax, $allowed ? implode( ', ', $allowed ) : '(none)' ),
				array( 'status' => 400 )
			);
		}
		// Editing the post does not by itself allow assigning its terms: wp-admin
		// and the REST API check the taxonomy's assign_terms cap as well.
		$tax_obj = get_taxonomy( $tax );
		if ( ! $tax_obj OR ! current_user_can( $tax_obj->cap->assign_terms ) ) {
			return new WP_Error(
				'us_mcp_posts_forbidden',
				sprintf( 'You do not have permission to assign terms of taxonomy "%s".', $tax ),
				array( 'status' => 403 )
			);
		}
		if ( ! is_array( $ids ) ) {
			return new WP_Error( 'us_mcp_posts_bad_terms', sprintf( 'terms["%s"] must be an array of integer term ids.', $tax ), array( 'status' => 400 ) );
		}
		$out[ $tax ] = array_values( array_map( 'intval', $ids ) );
	}

	return $out;
}

/**
 * Validate the optional extras (terms / meta / featured image) WITHOUT touching
 * the database. Split out from the apply step so create-post / update-post can
 * reject a bad value BEFORE the post write — otherwise wp_insert_post() leaves
 * an orphaned record (and wp_update_post() a half-applied one) when, say, a meta
 * enum or featured_image_id turns out invalid.
 *
 * Returns a normalised directive consumed by us_mcp_apply_post_extras():
 *   terms     => array<taxonomy, int[]> | null   null = field not supplied
 *   meta      => array<key, scalar|null> | null   null = field not supplied
 *   thumbnail => array{action:'clear'} | array{action:'set', id:int} | null
 *
 * @param array $input
 * @param array $spec
 * @param string $post_type
 * @param string $status The post status after the write.
 * @param int $post_id The post being updated, 0 on create.
 * @return array{terms: ?array, meta: ?array, thumbnail: ?array}|WP_Error
 */
function us_mcp_validate_post_extras( array $input, array $spec, $post_type, $status, $post_id = 0 ) {
	$terms = us_mcp_validate_terms_input( $input, $spec );
	if ( is_wp_error( $terms ) ) {
		return $terms;
	}

	$meta = us_mcp_validate_meta_input( $input, $post_type, $status === 'publish', $post_id );
	if ( is_wp_error( $meta ) ) {
		return $meta;
	}

	$thumbnail = NULL;
	if ( array_key_exists( 'featured_image_id', $input ) AND $spec['supports_thumbnail'] ) {
		$thumb = $input['featured_image_id'];
		// All four shapes mean "clear the thumbnail" — null, int 0, the strings
		// "0" and "". Without the '' branch a UI sending an empty string
		// dropped into `(int) '' = 0` and erroneously surfaced as 400
		// "0 is not an attachment".
		if ( $thumb === NULL OR $thumb === 0 OR $thumb === '0' OR $thumb === '' ) {
			$thumbnail = array( 'action' => 'clear' );
		} else {
			$thumb_id = (int) $thumb;
			// read_post as in get-media: the response echoes featured_image_url, so
			// a file of someone else's draft / private post must not be settable.
			if ( ! $thumb_id OR get_post_type( $thumb_id ) !== 'attachment' OR ! current_user_can( 'read_post', $thumb_id ) ) {
				return new WP_Error(
					'us_mcp_posts_bad_thumbnail',
					sprintf( 'featured_image_id %d is not an attachment.', $thumb_id ),
					array( 'status' => 400 )
				);
			}
			$thumbnail = array( 'action' => 'set', 'id' => $thumb_id );
		}
	}

	return array(
		'terms' => is_array( $terms ) ? $terms : NULL,
		'meta' => is_array( $meta ) ? $meta : NULL,
		'thumbnail' => $thumbnail,
	);
}

/**
 * Apply pre-validated terms / meta / thumbnail to a post. Takes the directive
 * produced by us_mcp_validate_post_extras() — every value here is already known
 * to be well-formed, so the only errors this can surface are storage-level
 * failures (e.g. wp_set_object_terms() hitting a DB error), which legitimately
 * happen after the post write regardless.
 *
 * @param WP_Post $post
 * @param array $extras Result of us_mcp_validate_post_extras().
 * @return true|WP_Error
 */
function us_mcp_apply_post_extras( WP_Post $post, array $extras ) {
	// terms
	if ( isset( $extras['terms'] ) AND is_array( $extras['terms'] ) ) {
		foreach ( $extras['terms'] as $tax => $ids ) {
			$res = wp_set_object_terms( $post->ID, $ids, $tax, /* append */ FALSE );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
		}
	}

	if ( isset( $extras['meta'] ) AND is_array( $extras['meta'] ) ) {
		us_mcp_write_meta_values( $post, $extras['meta'] );
	}

	// featured image
	if ( ! empty( $extras['thumbnail'] ) AND is_array( $extras['thumbnail'] ) ) {
		if ( $extras['thumbnail']['action'] === 'clear' ) {
			delete_post_thumbnail( $post );
		} else {
			set_post_thumbnail( $post, (int) $extras['thumbnail']['id'] );
		}
	}

	return TRUE;
}

// ---------------------------------------------------------------------
// Execute callbacks
// ---------------------------------------------------------------------

function us_mcp_ability_list_post_types( $input ) {
	$out = array();
	foreach ( us_mcp_post_types() as $pt => $spec ) {
		$obj = get_post_type_object( $pt );
		if ( ! $obj ) {
			continue;
		}
		$taxonomies = array();
		foreach ( $spec['taxonomies'] as $tax ) {
			$tax_obj = get_taxonomy( $tax );
			$taxonomies[] = array(
				'slug' => $tax,
				'label' => $tax_obj ? $tax_obj->labels->name : $tax,
				'hierarchical' => $tax_obj ? (bool) $tax_obj->hierarchical : FALSE,
			);
		}
		$meta_whitelist = us_mcp_post_type_meta_whitelist( $pt );
		$meta_fields = array();
		foreach ( $meta_whitelist as $key => $meta_spec ) {
			$meta_fields[] = us_mcp_meta_field_info( $key, $meta_spec );
		}
		$out[] = array(
			'slug' => $pt,
			'label' => $obj->labels->name,
			'hierarchical' => (bool) $spec['hierarchical'],
			// Whether the type has a real public front-end URL. is_post_type_viewable()
			// is the right signal, not $obj->public: admin-only authoring types
			// (us_content_template / us_page_block / us_testimonial) register
			// public=TRUE but publicly_queryable=FALSE and have no front-end URL.
			'public' => (bool) is_post_type_viewable( $obj ),
			'supports_excerpt' => (bool) $spec['supports_excerpt'],
			'supports_thumbnail' => (bool) $spec['supports_thumbnail'],
			'taxonomies' => $taxonomies,
			'meta_keys' => array_keys( $meta_whitelist ),
			'meta_fields' => $meta_fields,
		);
	}

	return $out;
}

function us_mcp_ability_list_posts( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}

	$status_csv = isset( $input['status'] ) ? (string) $input['status'] : 'publish,draft';
	$statuses = array_filter( array_map( 'sanitize_key', explode( ',', $status_csv ) ) );
	if ( empty( $statuses ) ) {
		$statuses = array( 'publish', 'draft' );
	}
	// Reject unknown statuses with a 400 rather than forwarding them: WP_Query
	// only builds a status clause for registered statuses, so a typo like
	// "published" would drop the status filter entirely and return every post
	// of the type (trash and auto-drafts included). "any" is expanded to the
	// concrete list WP_Query would use so the author scoping below can see it.
	$known_statuses = array_keys( get_post_stati() );
	$unknown = array_diff( $statuses, $known_statuses, array( 'any' ) );
	if ( $unknown ) {
		return new WP_Error(
			'us_mcp_posts_bad_status',
			sprintf( 'Unknown post status: %s. Allowed: any, %s.', implode( ', ', $unknown ), implode( ', ', $known_statuses ) ),
			array( 'status' => 400 )
		);
	}
	if ( in_array( 'any', $statuses, TRUE ) ) {
		$statuses = array_keys( get_post_stati( array( 'exclude_from_search' => FALSE ) ) );
	}
	$per_page = isset( $input['per_page'] ) ? (int) $input['per_page'] : 20;
	$per_page = max( 1, min( 100, $per_page ) );

	$args = array(
		'post_type' => $post_type,
		'post_status' => $statuses,
		'posts_per_page' => $per_page,
		'orderby' => 'modified',
		'order' => 'DESC',
	);
	// `menu_order` ordering is the natural one for walking a hierarchy tree
	// (siblings in their manual order, ascending); default stays "most recently
	// modified first".
	if ( isset( $input['orderby'] ) AND (string) $input['orderby'] === 'menu_order' ) {
		$args['orderby'] = 'menu_order title';
		$args['order'] = 'ASC';
	}
	if ( isset( $input['search'] ) AND trim( (string) $input['search'] ) !== '' ) {
		$args['s'] = (string) $input['search'];
	}
	// Restrict to direct children of a given parent (0 = top-level only) — lets
	// the agent walk a page / hierarchical-CPT tree level by level.
	if ( array_key_exists( 'parent', $input ) ) {
		$args['post_parent'] = (int) $input['parent'];
	}
	// The taxonomy filter is all-or-nothing: `taxonomy` and `term_id` go
	// together. Reject `taxonomy` without a usable `term_id` with a 400 rather
	// than silently dropping the filter — otherwise the caller gets an
	// unfiltered list back believing it was restricted to that term.
	if ( ! empty( $input['taxonomy'] ) ) {
		$tax = (string) $input['taxonomy'];
		$term_id = isset( $input['term_id'] ) ? (int) $input['term_id'] : 0;
		if ( $term_id < 1 ) {
			return new WP_Error(
				'us_mcp_posts_missing_term_id',
				'A positive `term_id` is required together with `taxonomy`.',
				array( 'status' => 400 )
			);
		}
		$spec = us_mcp_post_types()[ $post_type ];
		if ( ! in_array( $tax, $spec['taxonomies'], TRUE ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_taxonomy',
				sprintf( 'Taxonomy "%s" is not registered for post_type "%s". Allowed: %s.', $tax, $post_type, $spec['taxonomies'] ? implode( ', ', $spec['taxonomies'] ) : '(none)' ),
				array( 'status' => 400 )
			);
		}
		$args['tax_query'] = array(
			array( 'taxonomy' => $tax, 'field' => 'term_id', 'terms' => array( $term_id ) ),
		);
	}

	// Prevent enumeration of other authors' non-public posts: a user who can't edit
	// others' posts of this type only sees their own drafts / pending / future /
	// trashed posts, while the published rows (and private ones, given
	// read_private_posts) stay unrestricted so cross-author linking still works —
	// including for the default "publish,draft" listing. WP_Query's `perm` arg
	// can't express this (it author-scopes the whole requested status group), so
	// the OR is added to the WHERE clause directly.
	$pt_obj = get_post_type_object( $post_type );
	$visible_to_all = array_keys( get_post_stati( array( 'public' => TRUE ) ) );
	if ( current_user_can( $pt_obj->cap->read_private_posts ) ) {
		$visible_to_all = array_merge( $visible_to_all, array_keys( get_post_stati( array( 'private' => TRUE ) ) ) );
	}
	$own_only_where = '';
	if ( ! current_user_can( $pt_obj->cap->edit_others_posts ) AND array_diff( $statuses, $visible_to_all ) ) {
		global $wpdb;
		$own_only_where = $wpdb->prepare(
			" AND ( {$wpdb->posts}.post_author = %d OR {$wpdb->posts}.post_status IN ('" . implode( "','", array_map( 'esc_sql', $visible_to_all ) ) . "') )",
			get_current_user_id()
		);
	}
	$own_only_filter = function ( $where ) use ( $own_only_where ) {
		return $where . $own_only_where;
	};
	if ( $own_only_where !== '' ) {
		add_filter( 'posts_where', $own_only_filter );
	}

	$query = new WP_Query( $args );
	if ( $own_only_where !== '' ) {
		remove_filter( 'posts_where', $own_only_filter );
	}
	$out = array();
	foreach ( $query->posts as $post ) {
		$out[] = array(
			'id' => (int) $post->ID,
			'post_type' => $post->post_type,
			'slug' => $post->post_name,
			'title' => $post->post_title,
			'modified' => us_mcp_format_gmt_date( $post->post_modified_gmt, $post->post_modified ),
			'date' => us_mcp_format_gmt_date( $post->post_date_gmt, $post->post_date ),
			'status' => $post->post_status,
			'link' => get_permalink( $post ),
			'parent' => (int) $post->post_parent,
			'menu_order' => (int) $post->menu_order,
		);
	}

	return $out;
}

function us_mcp_ability_get_post( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}
	// The resolver already applies the per-post read gate (the type-level
	// permission_callback only checks edit_posts).
	$post = us_mcp_resolve_post( $post_type, $input );
	if ( is_wp_error( $post ) ) {
		return $post;
	}

	return us_mcp_post_to_payload( $post, /* include_content */ TRUE );
}

function us_mcp_ability_create_post( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}
	$spec = us_mcp_post_types()[ $post_type ];

	// Up-front cap check for create — at this stage there's no post id to
	// gate on, so the type's create_posts cap is the right one (it equals
	// edit_posts unless the type forbids creating posts, as wp-admin and the
	// REST API check it).
	$pt_obj = get_post_type_object( $post_type );
	if ( ! current_user_can( $pt_obj->cap->create_posts ) ) {
		return new WP_Error( 'us_mcp_posts_forbidden', 'You do not have permission to create this post type.', array( 'status' => 403 ) );
	}

	// Publishing (or scheduling / privately publishing) additionally requires the
	// type's publish capability - edit_posts alone must not bypass publish_posts.
	// When no status is given, default to "publish" only for callers who may
	// publish; everyone else gets a draft instead of a 403 for a status they
	// never asked for (same as the REST API's default).
	if ( isset( $input['status'] ) ) {
		$status = (string) $input['status'];
	} else {
		$status = current_user_can( $pt_obj->cap->publish_posts ) ? 'publish' : 'draft';
	}
	$status_cap = us_mcp_require_publish_cap( $pt_obj->cap->publish_posts, $status );
	if ( is_wp_error( $status_cap ) ) {
		return $status_cap;
	}

	// Validate the optional extras BEFORE inserting, so a bad terms / meta /
	// featured_image value rejects the call without leaving an orphaned post.
	$extras = us_mcp_validate_post_extras( $input, $spec, $post_type, $status );
	if ( is_wp_error( $extras ) ) {
		return $extras;
	}

	$markup = us_mcp_normalize_shortcode_markup( isset( $input['content'] ) ? (string) $input['content'] : '' );

	$args = array(
		'post_type' => $post_type,
		'post_title' => isset( $input['title'] ) ? (string) $input['title'] : '',
		'post_content' => $markup['content'],
		'post_status' => $status,
	);
	if ( $spec['supports_excerpt'] AND array_key_exists( 'excerpt', $input ) ) {
		$args['post_excerpt'] = (string) $input['excerpt'];
	}
	if ( ! empty( $input['slug'] ) ) {
		$args['post_name'] = sanitize_title( (string) $input['slug'] );
	}

	// Optional scheduled / back-dated publication date. A future date makes
	// WordPress schedule the post (it sets the status to "future" itself); a
	// past date back-dates it. Parse before inserting so a bad value rejects
	// the call without leaving an orphaned post.
	if ( array_key_exists( 'date', $input ) AND trim( (string) $input['date'] ) !== '' ) {
		$date = us_mcp_parse_date_input( $input['date'] );
		if ( is_wp_error( $date ) ) {
			return $date;
		}
		$args['post_date'] = $date['post_date'];
		$args['post_date_gmt'] = $date['post_date_gmt'];
	}

	// Optional hierarchy. Validate `parent` before inserting so a bad value
	// rejects the call without leaving an orphaned post.
	$parent = us_mcp_validate_parent_input( $input, $post_type, $spec['hierarchical'], /* self_id */ 0 );
	if ( is_wp_error( $parent ) ) {
		return $parent;
	}
	if ( $parent !== NULL ) {
		$args['post_parent'] = $parent;
	}
	if ( array_key_exists( 'menu_order', $input ) ) {
		$args['menu_order'] = (int) $input['menu_order'];
	}

	$id = wp_insert_post( $args, /* wp_error */ TRUE );
	if ( is_wp_error( $id ) ) {
		return $id;
	}

	$post = get_post( $id );

	$applied = us_mcp_apply_post_extras( $post, $extras );
	if ( is_wp_error( $applied ) ) {
		return $applied;
	}

	// Re-fetch so the payload reflects post-meta / post-term changes.
	$post = get_post( $id );

	$payload = us_mcp_post_to_payload( $post, /* include_content */ ! empty( $input['return_content'] ) );
	$markup_report = us_mcp_shortcode_markup_report( $markup['changes'] );
	if ( $markup_report !== NULL ) {
		$payload['markup_normalized'] = $markup_report;
	}

	return $payload;
}

/**
 * When a patch fails to match, probe a few plausible encoding variants of the
 * caller's `find` string. If any of them matches the current content, return
 * a short hint identifying which transform turns the caller's input into a
 * real substring of the body. Returns '' when nothing helpful is found.
 *
 * Why bother: the model has to track two stacked encodings — JSON for the
 * MCP transport (\" inside "..."), AND UpSolution's own per-attribute
 * scheme (URL-encoded JSON in double quotes for link= / css= / group
 * attributes — the canonical authoring form across the codebase). Without
 * a hint, a `0 occurrences` response forces a full get-post round-trip.
 * With the hint, the model fixes the encoding and retries.
 *
 * Variants probed (first hit wins, message stays short):
 *   1. rawurldecode($find) — model over-encoded literal chars.
 *   2. rawurlencode($find) — model passed a fully-decoded blob for an attr
 *      that is stored URL-encoded end-to-end (rare but cheap to check).
 *   3. $find with `/` → `%2F`, ` ` → `%20` — typical link="url:..." path
 *      under-encoding; whole-string urlencode is too aggressive here
 *      because it would also encode the surrounding `link="`.
 *   4. $find with `"` → `'` — caller wrote double-quoted attribute style
 *      but the body has a hand-edited single-quoted value. The canonical
 *      authoring form is double quotes everywhere; we keep this variant
 *      because real pages can drift from canonical and the hint is cheap.
 *
 * @param string $content
 * @param string $find
 * @return string  Empty string if no useful hint; otherwise a single
 *                 sentence prefixed with a leading space, ready to be
 *                 appended to the no-match error message.
 */
function us_mcp_patch_no_match_hint( $content, $find ) {
	$variants = array(
		array( 'URL-decoded form', rawurldecode( $find ) ),
		array( 'URL-encoded form', rawurlencode( $find ) ),
		array( "form with '/' and ' ' URL-encoded", str_replace( array( '/', ' ' ), array( '%2F', '%20' ), $find ) ),
		array( 'form with `\"` swapped to `\'`', str_replace( '"', "'", $find ) ),
		array( 'saved form (attribute line breaks joined, [ ] in quoted values escaped as `{` / `}`)', us_mcp_normalize_shortcode_markup( $find )['content'] ),
	);
	foreach ( $variants as $v ) {
		list( $label, $candidate ) = $v;
		if ( $candidate === $find OR $candidate === '' ) {
			continue;
		}
		$n = substr_count( $content, $candidate );
		if ( $n > 0 ) {
			return sprintf(
				' Hint: the %s of your `find` matches %d time%s — re-check the encoding (canonical authoring form: URL-encoded JSON in double quotes for link= / css= / group attrs).',
				$label, $n, ( $n === 1 ? '' : 's' )
			);
		}
	}

	return '';
}

/**
 * Apply a sequence of literal find/replace patches to a content string.
 *
 * All-or-nothing: returns WP_Error on the first patch whose match count
 * doesn't equal its `expect_matches`. Patches are applied in order to a
 * single in-memory buffer, so later patches see the result of earlier ones.
 *
 * Byte-exact match (substr_count / str_replace) — UTF-8 safe because
 * shortcode markup is stored as bytes and the caller's `find` came from a
 * prior byte-exact get-post payload.
 *
 * @param string $original
 * @param array $patches Already known to be a non-empty array.
 * @return array|WP_Error  On success: { content: string, report: array }.
 */
function us_mcp_apply_content_patches( $original, array $patches ) {
	if ( count( $patches ) > 50 ) {
		return new WP_Error(
			'us_mcp_posts_bad_patches',
			sprintf( 'Too many patches: %d (max 50).', count( $patches ) ),
			array( 'status' => 400 )
		);
	}
	$s = (string) $original;
	$report = array();
	foreach ( $patches as $i => $p ) {
		$p = (array) $p;
		$find = isset( $p['find'] ) ? (string) $p['find'] : '';
		$replace = isset( $p['replace'] ) ? (string) $p['replace'] : '';
		$expect = isset( $p['expect_matches'] ) ? (int) $p['expect_matches'] : 1;
		if ( $find === '' ) {
			return new WP_Error(
				'us_mcp_posts_bad_patches',
				sprintf( 'patches[%d]: `find` is empty.', $i ),
				array( 'status' => 400 )
			);
		}
		if ( $expect < 1 ) {
			return new WP_Error(
				'us_mcp_posts_bad_patches',
				sprintf( 'patches[%d]: `expect_matches` must be >= 1, got %d.', $i, $expect ),
				array( 'status' => 400 )
			);
		}
		$count = substr_count( $s, $find );
		if ( $count !== $expect ) {
			$hint = ( $count === 0 ) ? us_mcp_patch_no_match_hint( $s, $find ) : '';

			return new WP_Error(
				'us_mcp_posts_patch_no_match',
				sprintf( 'patches[%d]: `find` occurred %d times in the current post_content, expected %d. Re-read the post or adjust expect_matches.%s', $i, $count, $expect, $hint ),
				array( 'status' => 400 )
			);
		}
		$before = strlen( $s );
		$s = str_replace( $find, $replace, $s );
		$after = strlen( $s );
		$report[] = array(
			'index' => $i,
			'matches' => $count,
			'bytes_before' => $before,
			'bytes_after' => $after,
		);
	}

	return array( 'content' => $s, 'report' => $report );
}

function us_mcp_ability_update_post( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}
	$spec = us_mcp_post_types()[ $post_type ];

	$post = us_mcp_resolve_post( $post_type, $input );
	if ( is_wp_error( $post ) ) {
		return $post;
	}

	$pt_obj = get_post_type_object( $post_type );
	$cap_check = us_mcp_require_cap( $pt_obj->cap->edit_post, $post->ID );
	if ( is_wp_error( $cap_check ) ) {
		return $cap_check;
	}

	// Changing the status to publish / future / private additionally requires the
	// type's publish capability, so edit_post alone can't bypass publish_posts.
	// Keeping an already published / scheduled / private post in its current
	// state is not a status change and stays allowed (core behaves the same).
	if ( array_key_exists( 'status', $input ) ) {
		$status_cap = us_mcp_require_publish_cap( $pt_obj->cap->publish_posts, (string) $input['status'], $post->post_status );
		if ( is_wp_error( $status_cap ) ) {
			return $status_cap;
		}
	}

	// Validate the optional extras BEFORE any write, so an invalid terms / meta /
	// featured_image value rejects the whole call before title / content / status
	// or patches land — keeping the update atomic.
	$new_status = array_key_exists( 'status', $input ) ? (string) $input['status'] : $post->post_status;
	$extras = us_mcp_validate_post_extras( $input, $spec, $post_type, $new_status, $post->ID );
	if ( is_wp_error( $extras ) ) {
		return $extras;
	}

	$args = array( 'ID' => (int) $post->ID );
	if ( array_key_exists( 'title', $input ) ) {
		$args['post_title'] = (string) $input['title'];
	}
	$markup_changes = array();
	if ( array_key_exists( 'content', $input ) ) {
		$markup = us_mcp_normalize_shortcode_markup( (string) $input['content'] );
		$args['post_content'] = $markup['content'];
		$markup_changes = $markup['changes'];
	}
	if ( array_key_exists( 'status', $input ) ) {
		$args['post_status'] = (string) $input['status'];
	}
	if ( array_key_exists( 'new_slug', $input ) AND trim( (string) $input['new_slug'] ) !== '' ) {
		$args['post_name'] = sanitize_title( (string) $input['new_slug'] );
	}
	if ( $spec['supports_excerpt'] AND array_key_exists( 'excerpt', $input ) ) {
		$args['post_excerpt'] = (string) $input['excerpt'];
	}

	// Optional scheduled / back-dated publication date. A future date makes
	// WordPress schedule the post (it sets the status to "future" itself); a
	// past date back-dates it. `edit_date` tells wp_update_post() to honour the
	// new date instead of preserving the stored one. Validate before any write
	// so a bad value rejects the whole call.
	if ( array_key_exists( 'date', $input ) AND trim( (string) $input['date'] ) !== '' ) {
		$date = us_mcp_parse_date_input( $input['date'] );
		if ( is_wp_error( $date ) ) {
			return $date;
		}
		$args['post_date'] = $date['post_date'];
		$args['post_date_gmt'] = $date['post_date_gmt'];
		$args['edit_date'] = TRUE;
	}

	// Optional hierarchy. Validate `parent` (against this post's own type and
	// against loops with itself) before any write so a bad value rejects the
	// whole call atomically.
	$parent = us_mcp_validate_parent_input( $input, $post_type, $spec['hierarchical'], /* self_id */ (int) $post->ID );
	if ( is_wp_error( $parent ) ) {
		return $parent;
	}
	if ( $parent !== NULL ) {
		$args['post_parent'] = $parent;
	}
	if ( array_key_exists( 'menu_order', $input ) ) {
		$args['menu_order'] = (int) $input['menu_order'];
	}

	$patches_report = NULL;
	if ( array_key_exists( 'patches', $input ) ) {
		if ( array_key_exists( 'content', $input ) ) {
			return new WP_Error(
				'us_mcp_posts_patches_conflict_with_content',
				'Pass either `content` (full rewrite) or `patches` (incremental), not both.',
				array( 'status' => 400 )
			);
		}
		if ( ! is_array( $input['patches'] ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_patches',
				'`patches` must be an array.',
				array( 'status' => 400 )
			);
		}
		if ( empty( $input['patches'] ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_patches',
				'`patches` must contain at least one entry.',
				array( 'status' => 400 )
			);
		}
		$applied = us_mcp_apply_content_patches( $post->post_content, $input['patches'] );
		if ( is_wp_error( $applied ) ) {
			return $applied;
		}
		// Normalize the patched body as a whole: a patch may introduce a
		// wrapped tag or a raw bracket anywhere. Content stored before this
		// normalization existed gets canonicalized on its first patch too.
		$markup = us_mcp_normalize_shortcode_markup( $applied['content'] );
		$args['post_content'] = $markup['content'];
		$markup_changes = $markup['changes'];
		$patches_report = $applied['report'];
	}

	$has_extras = (
		array_key_exists( 'terms', $input )
		OR array_key_exists( 'meta', $input )
		OR array_key_exists( 'featured_image_id', $input )
	);

	if ( count( $args ) === 1 AND ! $has_extras ) {
		return new WP_Error(
			'us_mcp_posts_no_changes',
			'No mutable fields supplied (title / content / patches / status / date / new_slug / excerpt / parent / menu_order / featured_image_id / terms / meta).',
			array( 'status' => 400 )
		);
	}

	if ( count( $args ) > 1 ) {
		$result = wp_update_post( $args, /* wp_error */ TRUE );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}

	$extras_applied = us_mcp_apply_post_extras( $post, $extras );
	if ( is_wp_error( $extras_applied ) ) {
		return $extras_applied;
	}

	$post = get_post( $post->ID );
	$payload = us_mcp_post_to_payload( $post, /* include_content */ ! empty( $input['return_content'] ) );
	if ( $patches_report !== NULL ) {
		$payload['patches_applied'] = $patches_report;
		$payload['content_bytes'] = strlen( $post->post_content );
	}
	$markup_report = us_mcp_shortcode_markup_report( $markup_changes );
	if ( $markup_report !== NULL ) {
		$payload['markup_normalized'] = $markup_report;
	}

	return $payload;
}

/**
 * Copy every taxonomy-term assignment and all custom meta from one post to
 * another (used by duplicate-post). Terms are copied for every taxonomy
 * attached to the source's post type; meta is copied verbatim except for the
 * WordPress-internal bookkeeping keys that must never travel to a fresh copy
 * (edit locks, old-slug / old-date history, trash markers, moderation flags).
 *
 * get_post_meta( $id ) with no key returns the RAW (still-serialized) stored
 * strings, so each value is run back through maybe_unserialize() and then
 * wp_slash()'d — the Meta API unslashes on write, so without the re-slash a
 * value containing backslashes would be corrupted. add_post_meta() (not
 * update_post_meta) is used so multi-value meta keys are preserved.
 *
 * @param WP_Post $source
 * @param int $target_id
 * @return true|WP_Error
 */
function us_mcp_copy_post_terms_and_meta( WP_Post $source, $target_id ) {
	// Terms — across every taxonomy registered for the type (categories, tags,
	// post_format, custom taxonomies), for a faithful copy.
	foreach ( get_object_taxonomies( $source->post_type ) as $tax ) {
		$term_ids = wp_get_object_terms( $source->ID, $tax, array( 'fields' => 'ids' ) );
		if ( is_wp_error( $term_ids ) ) {
			return $term_ids;
		}
		if ( ! empty( $term_ids ) ) {
			$set = wp_set_object_terms( $target_id, array_map( 'intval', $term_ids ), $tax, /* append */ FALSE );
			if ( is_wp_error( $set ) ) {
				return $set;
			}
		}
	}

	// Meta — everything except WP-internal bookkeeping. _thumbnail_id is copied
	// here too, so the featured image carries over by reference.
	$skip = array(
		'_edit_lock',
		'_edit_last',
		'_wp_old_slug',
		'_wp_old_date',
		'_wp_trash_meta_status',
		'_wp_trash_meta_time',
		'_pingme',
		'_encloseme',
	);
	$all_meta = get_post_meta( $source->ID );
	if ( is_array( $all_meta ) ) {
		foreach ( $all_meta as $key => $values ) {
			if ( in_array( $key, $skip, TRUE ) ) {
				continue;
			}
			foreach ( (array) $values as $value ) {
				add_post_meta( $target_id, $key, wp_slash( maybe_unserialize( $value ) ) );
			}
		}
	}

	return TRUE;
}

function us_mcp_ability_duplicate_post( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}

	// A duplicate is a new post of the type — gate on the create cap, same as
	// create-post (there is no target post id to gate on yet).
	$pt_obj = get_post_type_object( $post_type );
	if ( ! current_user_can( $pt_obj->cap->create_posts ) ) {
		return new WP_Error( 'us_mcp_posts_forbidden', 'You do not have permission to create this post type.', array( 'status' => 403 ) );
	}

	// The copy's status still can't exceed the caller's publish capability.
	// Checked before resolving the source: it depends on the input only.
	$status = isset( $input['status'] ) ? (string) $input['status'] : 'draft';
	$status_cap = us_mcp_require_publish_cap( $pt_obj->cap->publish_posts, $status );
	if ( is_wp_error( $status_cap ) ) {
		return $status_cap;
	}

	// The resolver applies the per-post read gate on the source, so a user with
	// only type-level edit_posts can't copy (and thus read) another author's
	// draft / private post.
	$source = us_mcp_resolve_post( $post_type, $input );
	if ( is_wp_error( $source ) ) {
		return $source;
	}

	// The copy belongs to the caller unless they may edit others' posts, in which
	// case the source author is kept (the REST / wp-admin rule for setting a
	// foreign author). Otherwise a copy of a colleague's published post would be
	// a draft its creator can neither read, edit nor list — or, with
	// publish_posts, content published under the colleague's name.
	$author_id = current_user_can( $pt_obj->cap->edit_others_posts ) ? (int) $source->post_author : get_current_user_id();

	$title = $source->post_title . ' (copy)';
	if ( array_key_exists( 'title', $input ) AND trim( (string) $input['title'] ) !== '' ) {
		$title = (string) $input['title'];
	}

	$args = array(
		'post_type' => $post_type,
		'post_title' => $title,
		'post_content' => $source->post_content,
		'post_excerpt' => $source->post_excerpt,
		'post_status' => $status,
		'post_author' => $author_id,
		'post_parent' => $source->post_parent,
		'menu_order' => $source->menu_order,
		'comment_status' => $source->comment_status,
		'ping_status' => $source->ping_status,
	);
	if ( array_key_exists( 'new_slug', $input ) AND trim( (string) $input['new_slug'] ) !== '' ) {
		$args['post_name'] = sanitize_title( (string) $input['new_slug'] );
	}

	// Optional scheduled / back-dated date for the copy (parsed before insert).
	if ( array_key_exists( 'date', $input ) AND trim( (string) $input['date'] ) !== '' ) {
		$date = us_mcp_parse_date_input( $input['date'] );
		if ( is_wp_error( $date ) ) {
			return $date;
		}
		$args['post_date'] = $date['post_date'];
		$args['post_date_gmt'] = $date['post_date_gmt'];
	}

	// wp_slash the content / excerpt: wp_insert_post() unslashes its input, so
	// the raw source body (which may contain backslashes inside shortcode JSON)
	// has to be re-slashed to survive the round-trip unchanged.
	$args['post_content'] = wp_slash( $args['post_content'] );
	$args['post_excerpt'] = wp_slash( $args['post_excerpt'] );
	$args['post_title'] = wp_slash( $args['post_title'] );

	$new_id = wp_insert_post( $args, /* wp_error */ TRUE );
	if ( is_wp_error( $new_id ) ) {
		return $new_id;
	}

	$copied = us_mcp_copy_post_terms_and_meta( $source, (int) $new_id );
	if ( is_wp_error( $copied ) ) {
		return $copied;
	}

	$new_post = get_post( $new_id );
	$payload = us_mcp_post_to_payload( $new_post, /* include_content */ ! empty( $input['return_content'] ) );
	$payload['source_id'] = (int) $source->ID;

	return $payload;
}

function us_mcp_ability_delete_post( $input ) {
	$input = (array) $input;
	$post_type = us_mcp_validate_post_type( $input );
	if ( is_wp_error( $post_type ) ) {
		return $post_type;
	}
	$post = us_mcp_resolve_post( $post_type, $input );
	if ( is_wp_error( $post ) ) {
		return $post;
	}

	$pt_obj = get_post_type_object( $post_type );
	$cap_check = us_mcp_require_cap( $pt_obj->cap->delete_post, $post->ID );
	if ( is_wp_error( $cap_check ) ) {
		return $cap_check;
	}

	// Idempotent path: trashing a post that is already in the trash is a no-op.
	// wp_trash_post() returns FALSE in that case; treat it as success since the
	// post-condition "this id is trashed" already holds, so callers can retry
	// safely.
	if ( $post->post_status === 'trash' ) {
		return array(
			'id' => (int) $post->ID,
			'deleted' => FALSE,
			'trashed' => TRUE,
		);
	}

	// Permanent deletion is never performed here. When the site has the trash
	// disabled (EMPTY_TRASH_DAYS = 0), wp_trash_post() would silently fall
	// through to a permanent wp_delete_post() — which this tool must not do.
	// Refuse instead, so a removal can never become irreversible via MCP.
	if ( ! EMPTY_TRASH_DAYS ) {
		return new WP_Error(
			'us_mcp_posts_trash_disabled',
			sprintf( 'Cannot move %s id %d to the trash: this site has the trash disabled (EMPTY_TRASH_DAYS = 0), and permanent deletion is not allowed via MCP. Delete it from wp-admin if that is truly intended.', $post_type, $post->ID ),
			array( 'status' => 409 )
		);
	}

	$result = wp_trash_post( (int) $post->ID );
	if ( ! $result ) {
		return new WP_Error( 'us_mcp_posts_delete_failed', sprintf( 'Could not move %s id %d to the trash.', $post_type, $post->ID ), array( 'status' => 500 ) );
	}

	return array(
		'id' => (int) $post->ID,
		'deleted' => FALSE,
		'trashed' => TRUE,
	);
}
