<?php
/**
 * UpSolution MCP — Grid Layouts (us_grid_layout) + built-in templates.
 *
 * Exposes the Grid Layout tools:
 *
 *   upsolution-list-grid-layouts   — custom records + built-in templates
 *   upsolution-get-grid-layout     — one layout (record or template) expanded
 *   upsolution-create-grid-layout  — new record from a template, a copy or blank
 *   upsolution-update-grid-layout  — transactional edit (elements / options / layout)
 *   upsolution-delete-grid-layout  — trash
 *
 * list-grid-layouts:
 *
 * Resolves a human-readable Grid Layout name to the identifier accepted by
 * the `items_layout="…"` attribute on the list-family shortcodes —
 * [us_post_list] / [us_product_list] / [us_user_list] / [us_term_list]
 * and their *_carousel aliases registered in config/shortcodes.php.
 *
 * Two families share the same attribute:
 *
 *   - custom records of the `us_grid_layout` post type (numeric id);
 *   - built-in templates declared in config/grid-templates.php
 *     (string keys like "blog_1", "portfolio_3").
 *
 * us_get_grid_layout_settings() in functions/list.php:165-194 resolves both:
 * it checks the templates config first, then falls back to a post lookup.
 * The admin selector (us_get_grid_layouts_for_selection, list.php:320)
 * presents both families in one dropdown, custom records first, then
 * built-in templates by group. This tool mirrors that mental model — set
 * `source` if you want to narrow to one family.
 *
 * The `us_grid_layout` post type itself is registered with
 * `'supports' => FALSE` and `'capability_type' => $templates_capability`
 * (white-label-aware) in functions/post-types.php. Its `post_content` is a
 * JSON config produced by the Grid Builder (see functions/list.php:187-189:
 * `json_decode( $grid_layout_post->post_content, TRUE )`), NOT shortcode
 * markup, so the generic upsolution-create-post / update-post pipeline
 * must not be used on it. The generic CRUD's `post_type` enum already
 * excludes `us_grid_layout` for this reason. Built-in templates live in a
 * PHP config file and are read-only.
 *
 * The get / create / update tools speak the Grid Builder JSON shape documented
 * in llms/design/grid-layouts.md (served via upsolution-read-doc as
 * design/grid-layouts). The record is stored FULL (every option, every element
 * param), exactly like the Grid Builder saves it (admin/js/grid-builder.js),
 * because the front-end loader us_get_grid_layout_settings() does not
 * re-normalise a record. Values are validated with the shared USOF field
 * checks from mcp/builder-fields.php.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

add_action( 'wp_abilities_api_init', function () {
	wp_register_ability( 'upsolution/list-grid-layouts', array(
		'label'               => 'List Grid Layouts',
		'description'         => 'List Grid Layouts so the agent can resolve a human-readable name to the identifier required by the `items_layout="…"` attribute on [us_post_list] / [us_product_list] / [us_user_list] / [us_term_list] (and their *_carousel aliases). Returns BOTH families that this attribute accepts: custom us_grid_layout records (numeric id) and built-in templates from config/grid-templates.php (string keys like "blog_1"). Set `source` to narrow. Each item carries its `source` tag plus a `selector` field — pass selector verbatim into the shortcode attribute. Custom records store a Grid Builder JSON config in post_content, so the generic CRUD tools refuse this type — read / author them with upsolution-get-grid-layout, upsolution-create-grid-layout, upsolution-update-grid-layout and upsolution-delete-grid-layout. Built-in templates are read-only: copy one with upsolution-create-grid-layout to customise it.',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'       => 'object',
			'properties' => array(
				'source'   => array(
					'type'        => 'string',
					'enum'        => array( 'all', 'posts', 'presets' ),
					'description' => 'Which family to return. "posts" → only custom us_grid_layout records. "presets" → only built-in templates from config/grid-templates.php. "all" (default) → both, custom records first then presets grouped by config order.',
					'default'     => 'all',
				),
				'search'   => array(
					'type'        => 'string',
					'description' => 'Optional. Behaviour differs by family. For the "posts" family (custom us_grid_layout records): forwarded to WP_Query\'s full-text search (`s`), which matches against post_title, post_content AND post_excerpt; us_grid_layout.post_content is a Grid Builder JSON blob, so search terms can hit JSON keys (e.g. "row", "column", "items") and surface false positives. For the "presets" family (config/grid-templates.php): real case-insensitive substring match against `title` + preset key. For exact custom-record lookup, call with no `search` and pick by selector / title client-side.',
				),
				'status'   => array(
					'type'        => 'string',
					'description' => 'Comma-separated WP post statuses (e.g. "publish,draft"). Applies to the "posts" family only; ignored for presets. Default: "publish,draft".',
					'default'     => 'publish,draft',
				),
				'per_page' => array(
					'type'        => 'integer',
					'description' => 'Maximum number of records to return overall (default 50, max 200). With source="all" this cap is shared across both families.',
					'default'     => 50,
					'minimum'     => 1,
					'maximum'     => 200,
				),
			),
		),
		'output_schema'       => array(
			'type'  => 'array',
			'items' => array(
				'type'       => 'object',
				'properties' => array(
					'selector'  => array(
						'type'        => array( 'integer', 'string' ),
						'description' => 'The value to put inside items_layout="…" — integer for custom records (e.g. 42), string key for built-in templates (e.g. "blog_1").',
					),
					'source'    => array(
						'type'        => 'string',
						'enum'        => array( 'post', 'preset' ),
						'description' => '"post" for a custom us_grid_layout record, "preset" for a built-in template.',
					),
					'title'     => array( 'type' => 'string' ),
					'group'     => array( 'type' => 'string', 'description' => 'Preset group label (e.g. "Blog Templates (for several columns)"). Empty string for the "post" source.' ),
					'slug'      => array( 'type' => 'string', 'description' => 'Post slug. Empty string for the "preset" source.' ),
					'status'    => array( 'type' => 'string', 'description' => 'Empty string for the "preset" source.' ),
					'modified'  => array( 'type' => 'string', 'description' => 'Empty string for the "preset" source.' ),
					'edit_link' => array( 'type' => array( 'string', 'null' ), 'description' => 'wp-admin URL of the Grid Builder for custom records. NULL for presets — they are read-only.' ),
				),
			),
		),
		'execute_callback'    => 'us_mcp_ability_list_grid_layouts',
		'permission_callback' => 'us_mcp_grid_layout_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/**
 * Permission gate for the grid-layout tools. Consults the registered
 * post-type object's edit_posts cap, because us_grid_layout uses
 * $templates_capability (white-label-aware) at registration — hardcoding
 * edit_posts would bypass the white-label remap.
 *
 * Shared by every ability declared in this file. Mutating callbacks also do
 * a per-post `edit_post` / `delete_post` check after resolving the id.
 *
 * @return bool
 */
function us_mcp_grid_layout_permission_callback() {
	if ( ! post_type_exists( 'us_grid_layout' ) ) {
		return current_user_can( 'edit_posts' );
	}
	$pt_obj = get_post_type_object( 'us_grid_layout' );
	if ( ! $pt_obj OR ! isset( $pt_obj->cap->edit_posts ) ) {
		return FALSE;
	}
	return current_user_can( $pt_obj->cap->edit_posts );
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_list_grid_layouts( $input ) {
	$input = (array) $input;

	$source = isset( $input['source'] ) ? (string) $input['source'] : 'all';
	if ( ! in_array( $source, array( 'all', 'posts', 'presets' ), TRUE ) ) {
		$source = 'all';
	}
	$per_page = isset( $input['per_page'] ) ? (int) $input['per_page'] : 50;
	$per_page = max( 1, min( 200, $per_page ) );
	$search   = isset( $input['search'] ) ? trim( (string) $input['search'] ) : '';

	$out = array();

	// --- Custom records (us_grid_layout) ---------------------------------
	if ( $source === 'all' OR $source === 'posts' ) {
		if ( ! post_type_exists( 'us_grid_layout' ) ) {
			// Hard fail only when the caller explicitly asked for posts; in
			// "all" mode silently skip and return presets only.
			if ( $source === 'posts' ) {
				return new WP_Error(
					'us_mcp_grid_layouts_disabled',
					'"us_grid_layout" is not registered on this site.',
					array( 'status' => 400 )
				);
			}
		} else {
			$status_csv = isset( $input['status'] ) ? (string) $input['status'] : 'publish,draft';
			$statuses   = array_filter( array_map( 'trim', explode( ',', $status_csv ) ) );
			if ( empty( $statuses ) ) {
				$statuses = array( 'publish', 'draft' );
			}

			$args = array(
				'post_type'      => 'us_grid_layout',
				'post_status'    => $statuses,
				'posts_per_page' => $per_page,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			);
			if ( $search !== '' ) {
				$args['s'] = $search;
			}

			$query = new WP_Query( $args );
			foreach ( $query->posts as $post ) {
				$out[] = array(
					'selector'  => (int) $post->ID,
					'source'    => 'post',
					'title'     => $post->post_title,
					'group'     => '',
					'slug'      => $post->post_name,
					'status'    => $post->post_status,
					'modified'  => mysql2date( 'c', $post->post_modified_gmt, FALSE ),
					'edit_link' => admin_url( 'post.php?post=' . $post->ID . '&action=edit' ),
				);
			}
		}
	}

	// --- Built-in templates (config/grid-templates.php) ------------------
	if ( $source === 'all' OR $source === 'presets' ) {
		$remaining = $per_page - count( $out );
		if ( $remaining > 0 ) {
			$current_group = '';
			$search_lc     = $search !== '' ? mb_strtolower( $search ) : '';
			foreach ( us_config( 'grid-templates', array(), TRUE ) as $key => $tpl ) {
				if ( ! is_array( $tpl ) ) {
					continue;
				}
				// `group` is sticky in the config — only the first entry of a
				// group declares it; later entries inherit the last seen
				// label. us_get_grid_layouts_for_selection() does the same.
				if ( ! empty( $tpl['group'] ) AND $tpl['group'] !== $current_group ) {
					$current_group = (string) $tpl['group'];
				}
				$title = isset( $tpl['title'] ) ? (string) $tpl['title'] : (string) $key;
				if ( $search_lc !== '' ) {
					$haystack = mb_strtolower( $title . ' ' . $key );
					if ( strpos( $haystack, $search_lc ) === FALSE ) {
						continue;
					}
				}
				$out[] = array(
					'selector'  => (string) $key,
					'source'    => 'preset',
					'title'     => $title,
					'group'     => $current_group,
					'slug'      => '',
					'status'    => '',
					'modified'  => '',
					'edit_link' => NULL,
				);
				if ( count( $out ) >= $per_page ) {
					break;
				}
			}
		}
	}

	return $out;
}

/* -------------------------------------------------------------------------
 * Grid Layout authoring tools — registration
 * ---------------------------------------------------------------------- */

add_action( 'wp_abilities_api_init', function () {

	// Expanded layout shape shared by get-grid-layout and update-grid-layout
	$layout_output_schema = array(
		'type'                 => 'object',
		'additionalProperties' => TRUE,
		'required'             => array( 'selector', 'source', 'title', 'options', 'layout', 'elements' ),
		'properties'           => array(
			'selector'  => array(
				'type'        => array( 'integer', 'string' ),
				'description' => 'Record id or template key — the value for items_layout="…".',
			),
			'source'    => array( 'type' => 'string', 'enum' => array( 'post', 'preset' ) ),
			'title'     => array( 'type' => 'string' ),
			'status'    => array( 'type' => 'string', 'description' => 'Empty string for a preset.' ),
			'read_only' => array( 'type' => 'boolean', 'description' => 'TRUE for built-in templates.' ),
			'edit_link' => array( 'type' => array( 'string', 'null' ) ),
			'options'   => array(
				'type'                 => 'object',
				'additionalProperties' => TRUE,
				'description'          => 'Grid Layout options (background, border radius, shadow, aspect ratio, …) with defaults filled in.',
			),
			'layout'    => array(
				'type'                 => 'object',
				'additionalProperties' => TRUE,
				'description'          => 'Ordered element ids: "middle_center" (the card), one key per container id (its children), "hidden" (elements not placed, not shown).',
			),
			'elements'  => array(
				'type'        => 'array',
				'description' => 'One entry per element instance: { elm_id, type, params } with defaults filled in.',
				'items'       => array( 'type' => 'object', 'additionalProperties' => TRUE ),
			),
		),
	);

	wp_register_ability( 'upsolution/get-grid-layout', array(
		'label'               => 'Read one Grid Layout',
		'description'         => 'Return one Grid Layout as the fully-expanded Grid Builder settings: `options` (layout settings with defaults), `layout` (ordered element ids in the "middle_center" cell and inside each container) and `elements` (each instance\'s elm_id / type / params with defaults filled in). Accepts a custom record id or a built-in template key (e.g. "blog_1") from upsolution-list-grid-layouts — templates are read-only (`read_only: true`), use them as a reference or copy one with upsolution-create-grid-layout. Read this immediately before upsolution-update-grid-layout. MANDATORY pre-read: the design/grid-layouts doc (upsolution-read-doc).',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'                 => 'object',
			'required'             => array( 'id' ),
			'additionalProperties' => FALSE,
			'properties'           => array(
				'id' => array(
					'type'        => array( 'integer', 'string' ),
					'description' => 'Custom record id, or a built-in template key — the `selector` from upsolution-list-grid-layouts.',
				),
			),
		),
		'output_schema'       => $layout_output_schema,
		'execute_callback'    => 'us_mcp_ability_get_grid_layout',
		'permission_callback' => 'us_mcp_grid_layout_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/create-grid-layout', array(
		'label'               => 'Create a Grid Layout',
		'description'         => 'Create a new Grid Layout (us_grid_layout) from a built-in template (its key, e.g. "blog_1"), as a copy of an existing record (its id — the copy is independent), or "blank". Returns { id, title, selector, edit_link }: pass `selector` as items_layout="…" on [us_post_list] / [us_product_list] / [us_user_list] / [us_term_list] (or a carousel) via upsolution-update-post. Then read it with upsolution-get-grid-layout and customise with upsolution-update-grid-layout. MANDATORY pre-read: the design/grid-layouts doc.',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'                 => 'object',
			'required'             => array( 'title' ),
			'additionalProperties' => FALSE,
			'properties'           => array(
				'title'  => array( 'type' => 'string', 'description' => 'Grid Layout name (shown in the Grid Layouts list and the items_layout selector).' ),
				'source' => array(
					'type'        => array( 'integer', 'string' ),
					'description' => 'Starting point: a built-in template key, an existing record id (copied), or "blank" for an empty card. Default: "blank".',
					'default'     => 'blank',
				),
				'status' => array(
					'type'        => 'string',
					'enum'        => array( 'publish', 'draft', 'private', 'pending' ),
					'description' => 'WP post status. Default: "publish".',
					'default'     => 'publish',
				),
			),
		),
		'output_schema'       => array(
			'type'       => 'object',
			'required'   => array( 'id', 'title', 'selector', 'edit_link' ),
			'properties' => array(
				'id'        => array( 'type' => 'integer' ),
				'title'     => array( 'type' => 'string' ),
				'selector'  => array( 'type' => 'integer', 'description' => 'The value for items_layout="…".' ),
				'edit_link' => array( 'type' => 'string' ),
			),
		),
		'execute_callback'    => 'us_mcp_ability_create_grid_layout',
		'permission_callback' => 'us_mcp_grid_layout_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/update-grid-layout', array(
		'label'               => 'Edit one Grid Layout',
		'description'         => 'Edit one custom Grid Layout (us_grid_layout) by applying operation groups as a single transaction — validated against an in-memory copy first; if any check fails, nothing is saved. Built-in templates are read-only (copy one with upsolution-create-grid-layout first). Read the current state with upsolution-get-grid-layout immediately before calling. MANDATORY pre-read: the design/grid-layouts doc (upsolution-read-doc) — element types & params, options, containers, dynamic values and full detail on every operation below.' . "\n\n"
			. 'operations groups (all optional, applied in this order):' . "\n"
			. '  - add_element:    [ { type, params?:{…}, placement:{ cell, position? } } ] — add an element (post_title, post_image, post_date, post_taxonomy, btn, text, hwrapper / vwrapper, …). Allocates the next free "type:N" id. cell is "middle_center" or a container id (also one added earlier in the same call).' . "\n"
			. '  - update_element: { "<elm_id>": { "<param>": value | null } } — edit params. Size / spacing / colors via the `css` Design param, e.g. {"css":{"default":{"font-size":"1.2rem"}}}. null resets to default.' . "\n"
			. '  - remove_element: [ "<elm_id>" ] — delete elements; a container is deleted with everything inside it.' . "\n"
			. '  - set_options:    { "<option_key>": value | null } — card settings (color_bg, color_text, border_radius, box_shadow, box_shadow_hover, fixed + aspect_ratio, overflow, bg_img_source, …). null reverts to the default. Colors use upsolution-set-palette syntax.' . "\n"
			. '  - set_layout:     { "<cell>": [ "<elm_id>", … ] } — ordered placement of a cell ("middle_center" or a container id); listed ids move here from wherever they were.',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'                 => 'object',
			'required'             => array( 'id', 'operations' ),
			'additionalProperties' => FALSE,
			'properties'           => array(
				'id'         => array( 'type' => array( 'integer', 'string' ), 'description' => 'Custom record id (a template key is refused — templates are read-only).' ),
				'title'      => array( 'type' => 'string', 'description' => 'Optional: rename the Grid Layout.' ),
				'operations' => array(
					'type'                 => 'object',
					'additionalProperties' => TRUE,
					'description'          => 'Any of: add_element (array), update_element (object), remove_element (array), set_options (object), set_layout (object). See the tool description for shapes.',
					'properties'           => array(
						'add_element'    => array(
							'type'  => 'array',
							'items' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						),
						'update_element' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						'remove_element' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
						'set_options'    => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						'set_layout'     => array( 'type' => 'object', 'additionalProperties' => TRUE ),
					),
				),
			),
		),
		'output_schema'       => array_merge_recursive( $layout_output_schema, array(
			'properties' => array(
				'added_ids' => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Element ids assigned by add_element operations, in order.',
				),
			),
		) ),
		'execute_callback'    => 'us_mcp_ability_update_grid_layout',
		'permission_callback' => 'us_mcp_grid_layout_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/delete-grid-layout', array(
		'label'               => 'Delete a Grid Layout',
		'description'         => 'Move a custom Grid Layout (us_grid_layout) to the trash (not permanent — restore from wp-admin). Idempotent. Lists that select it in items_layout="…" switch to their element\'s default template (e.g. "blog_1" for [us_post_list], "shop_standard" for [us_product_list]) until it is restored — re-point them to another layout via upsolution-update-post if needed. Built-in templates cannot be deleted.',
		'category'            => 'upsolution',
		'input_schema'        => array(
			'type'                 => 'object',
			'required'             => array( 'id' ),
			'additionalProperties' => FALSE,
			'properties'           => array(
				'id' => array( 'type' => array( 'integer', 'string' ), 'description' => 'Custom record id.' ),
			),
		),
		'output_schema'       => array(
			'type'       => 'object',
			'required'   => array( 'id', 'trashed' ),
			'properties' => array(
				'id'      => array( 'type' => 'integer' ),
				'trashed' => array( 'type' => 'boolean' ),
			),
		),
		'execute_callback'    => 'us_mcp_ability_delete_grid_layout',
		'permission_callback' => 'us_mcp_grid_layout_permission_callback',
		'meta'                => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/* -------------------------------------------------------------------------
 * Grid Layout authoring tools — helpers
 * ---------------------------------------------------------------------- */

/**
 * Container element types of the Grid Builder: their elm_id doubles as a layout key holding child ids.
 *
 * @return string[]
 */
function us_mcp_grid_layout_container_types() {
	$types = array();
	foreach ( (array) us_config( 'grid-settings.elements', array() ) as $type ) {
		if ( us_config( 'elements/' . $type . '.is_container' ) ) {
			$types[] = $type;
		}
	}

	return $types;
}

/**
 * Tabs, Accordion and Vertical Tabs accept sections only (same rule as the Grid Builder).
 *
 * @return string[]
 */
function us_mcp_grid_layout_tta_types() {
	$types = array();
	foreach ( (array) us_config( 'grid-settings.elements', array() ) as $type ) {
		if ( us_config( 'elements/' . $type . '.as_parent.only' ) === 'vc_tta_section' ) {
			$types[] = $type;
		}
	}

	return $types;
}

/**
 * Valid placement targets: "middle_center" plus every container instance present in `data`.
 *
 * @param array $settings
 * @return string[]
 */
function us_mcp_grid_layout_target_cells( $settings ) {
	$cells = array( 'middle_center' );
	$container_types = us_mcp_grid_layout_container_types();
	foreach ( array_keys( (array) us_arr_path( $settings, 'data', array() ) ) as $elm_id ) {
		if ( in_array( strtok( $elm_id, ':' ), $container_types, TRUE ) ) {
			$cells[] = $elm_id;
		}
	}

	return $cells;
}

/**
 * Check that an element of $type may be placed into $cell: a section goes into
 * Tabs / Accordion / Vertical Tabs only, and those accept sections only.
 *
 * @param string $cell
 * @param string $type
 * @param string $label
 * @return true|WP_Error
 */
function us_mcp_grid_layout_check_nesting( $cell, $type, $label ) {
	$parent_is_tta = in_array( strtok( $cell, ':' ), us_mcp_grid_layout_tta_types(), TRUE );
	if ( ( $type === 'vc_tta_section' ) !== $parent_is_tta ) {
		return new WP_Error(
			'us_mcp_grid_layout_bad_nesting',
			sprintf( '%s: "%s" cannot go into "%s" — vc_tta_section goes only into Tabs / Accordion / Vertical Tabs (%s), and those accept only vc_tta_section.', $label, $type, $cell, implode( ', ', us_mcp_grid_layout_tta_types() ) ),
			array( 'status' => 400 )
		);
	}

	return TRUE;
}

/**
 * Find Tabs / Accordion / Vertical Tabs placed inside another one at any depth —
 * the Grid Builder refuses such a drop (admin/js/grid-builder.js, _canDropTo).
 *
 * @param array $layout
 * @return string Id of the nested TTA element, or empty string
 */
function us_mcp_grid_layout_find_nested_tta( $layout ) {
	$tta_types = us_mcp_grid_layout_tta_types();
	$parents = array();
	foreach ( $layout as $cell => $ids ) {
		foreach ( (array) $ids as $child_id ) {
			$parents[ (string) $child_id ] = (string) $cell;
		}
	}
	foreach ( $parents as $elm_id => $parent ) {
		if ( ! in_array( strtok( $elm_id, ':' ), $tta_types, TRUE ) ) {
			continue;
		}
		$seen = array();
		for ( $id = $parent; strpos( $id, ':' ) !== FALSE AND ! isset( $seen[ $id ] ); $id = $parents[ $id ] ?? '' ) {
			$seen[ $id ] = TRUE;
			if ( in_array( strtok( $id, ':' ), $tta_types, TRUE ) ) {
				return (string) $elm_id;
			}
		}
	}

	return '';
}

/**
 * The element ids nested in a container, at any depth.
 *
 * @param array $layout
 * @param string $elm_id
 * @return string[]
 */
function us_mcp_grid_layout_descendants( $layout, $elm_id ) {
	$ids = array();
	foreach ( (array) ( $layout[ $elm_id ] ?? array() ) as $child_id ) {
		$ids[] = $child_id;
		$ids = array_merge( $ids, us_mcp_grid_layout_descendants( $layout, $child_id ) );
	}

	return $ids;
}

/**
 * Find a container that ends up inside itself (e.g. a wrapper moved into its own child).
 *
 * @param array $layout
 * @return string Container id or empty string when there are no cycles
 */
function us_mcp_grid_layout_find_cycle( $layout ) {
	$visit = function ( $elm_id, $path ) use ( &$visit, $layout ) {
		if ( isset( $path[ $elm_id ] ) ) {
			return $elm_id;
		}
		$path[ $elm_id ] = TRUE;
		foreach ( (array) ( $layout[ $elm_id ] ?? array() ) as $child_id ) {
			if ( $found = $visit( $child_id, $path ) ) {
				return $found;
			}
		}

		return '';
	};
	foreach ( array_keys( $layout ) as $key ) {
		if ( strpos( $key, ':' ) !== FALSE AND $found = $visit( $key, array() ) ) {
			return $found;
		}
	}

	return '';
}

/**
 * Resolve a Grid Layout reference: a custom record id or a built-in template key.
 *
 * @param mixed $ref
 * @param bool $allow_template FALSE for mutating tools — templates are read-only
 * @return array|WP_Error { post: WP_Post|null, template: string, config: array }
 */
function us_mcp_grid_layout_resolve( $ref, $allow_template ) {
	$ref = is_string( $ref ) ? trim( $ref ) : $ref;
	// 0 must not reach get_post(), which falls back to the global post for an empty id
	if ( $ref === '' OR $ref === NULL OR ( is_numeric( $ref ) AND (int) $ref <= 0 ) ) {
		return new WP_Error( 'us_mcp_grid_layout_no_ref', 'Pass a Grid Layout reference: a custom record id or a built-in template key (see upsolution-list-grid-layouts).', array( 'status' => 400 ) );
	}

	// Built-in template
	if ( ! is_numeric( $ref ) ) {
		$templates = us_config( 'grid-templates', array(), TRUE );
		if ( ! isset( $templates[ $ref ] ) OR ! is_array( $templates[ $ref ] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_not_found', sprintf( 'No Grid Layout "%s": pass a custom record id or a built-in template key from upsolution-list-grid-layouts.', $ref ), array( 'status' => 404 ) );
		}
		if ( ! $allow_template ) {
			return new WP_Error(
				'us_mcp_grid_layout_read_only',
				sprintf( '"%s" is a built-in template and is read-only. Create an editable copy with upsolution-create-grid-layout { "title": "…", "source": "%s" } and edit that record instead.', $ref, $ref ),
				array( 'status' => 400 )
			);
		}

		return array( 'post' => NULL, 'template' => (string) $ref, 'config' => $templates[ $ref ] );
	}

	if ( ! post_type_exists( 'us_grid_layout' ) ) {
		return new WP_Error( 'us_mcp_grid_layouts_disabled', '"us_grid_layout" is not registered on this site.', array( 'status' => 400 ) );
	}
	$post = get_post( (int) $ref );
	if ( ! $post OR $post->post_type !== 'us_grid_layout' ) {
		return new WP_Error( 'us_mcp_grid_layout_not_found', sprintf( 'No us_grid_layout with id=%d (see upsolution-list-grid-layouts).', (int) $ref ), array( 'status' => 404 ) );
	}
	$config = array();
	if ( strpos( (string) $post->post_content, '{' ) === 0 ) {
		$config = (array) json_decode( $post->post_content, TRUE );
	}

	return array( 'post' => $post, 'template' => '', 'config' => $config );
}

/**
 * Expand stored settings (or a template config) the way the Grid Builder loads them
 * (usof/templates/fields/grid_builder.php), reduced to the stored keys.
 *
 * @param array $config
 * @return array { data, default: { layout, options } }
 */
function us_mcp_grid_layout_expand( $config ) {
	$settings = us_fix_grid_layout_settings( $config );
	foreach ( $settings['data'] as $elm_id => $params ) {
		$settings['data'][ $elm_id ] = apply_filters( 'us_edit_atts_fallback_us_' . strtok( $elm_id, ':' ), $params );
	}
	$settings = us_grid_layout_settings_fallback( $settings );

	return array(
		'data' => (array) $settings['data'],
		'default' => array(
			'layout' => (array) us_arr_path( $settings, 'default.layout', array() ),
			'options' => (array) us_arr_path( $settings, 'default.options', array() ),
		),
	);
}

/**
 * Encode settings for post_content. wp_insert_post() / wp_update_post() run wp_unslash()
 * on their input, so the JSON is wp_slash()'d to keep its escaped quotes intact
 * (the title is wp_slash()'d at the call sites for the same reason).
 *
 * @param array $settings
 * @return string
 */
function us_mcp_grid_layout_encode( $settings ) {
	// An empty data map must stay a JSON object, the builder adds elements to it by key
	$settings['data'] = (object) $settings['data'];

	return wp_slash( wp_json_encode( $settings ) );
}

/**
 * Build the get / update response body.
 *
 * @param array $ref resolved reference
 * @param array $settings expanded
 * @return array
 */
function us_mcp_grid_layout_present( $ref, $settings ) {
	$post = $ref['post'];
	$elements = array();
	foreach ( $settings['data'] as $elm_id => $params ) {
		$type = strtok( $elm_id, ':' );
		$elements[] = array(
			'elm_id' => (string) $elm_id,
			'type' => $type,
			// The stored record holds every param of the element config, show only the ones the Grid Builder edits
			'params' => array_intersect_key( (array) $params, us_mcp_builder_element_param_spec( $type, 'grid' ) ),
		);
	}

	return array(
		'selector' => $post ? (int) $post->ID : $ref['template'],
		'source' => $post ? 'post' : 'preset',
		'title' => $post ? $post->post_title : (string) us_arr_path( $ref, 'config.title', $ref['template'] ),
		'status' => $post ? $post->post_status : '',
		'read_only' => ! $post,
		'edit_link' => $post ? admin_url( 'post.php?post=' . $post->ID . '&action=edit' ) : NULL,
		'options' => $settings['default']['options'],
		'layout' => $settings['default']['layout'],
		'elements' => $elements,
	);
}

/**
 * Apply the update-grid-layout operation groups to an expanded working copy.
 * Validates everything; returns the assigned ids, or a WP_Error (nothing is
 * persisted by the caller on error).
 *
 * @param array $settings expanded working copy (mutated)
 * @param array $operations
 * @return array{added_ids:string[]}|WP_Error
 */
function us_mcp_grid_layout_apply_operations( &$settings, $operations ) {
	$operations = (array) $operations;
	$added_ids = array();
	$valid_types = (array) us_config( 'grid-settings.elements', array() );
	$layout = &$settings['default']['layout'];

	// 1) add_element
	if ( isset( $operations['add_element'] ) ) {
		if ( ! is_array( $operations['add_element'] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_op', '`add_element` must be an array.', array( 'status' => 400 ) );
		}
		foreach ( $operations['add_element'] as $i => $op ) {
			$op = (array) $op;
			$label = sprintf( 'add_element[%d]', $i );
			$type = isset( $op['type'] ) ? (string) $op['type'] : '';
			if ( ! in_array( $type, $valid_types, TRUE ) ) {
				return new WP_Error( 'us_mcp_grid_layout_bad_type', sprintf( '%s: unknown element type "%s". Allowed: %s.', $label, $type, implode( ', ', $valid_types ) ), array( 'status' => 400 ) );
			}
			$cell = (string) us_arr_path( $op, 'placement.cell', '' );
			// Recomputed each iteration, so a container added earlier in this call is a valid target
			$valid_cells = us_mcp_grid_layout_target_cells( $settings );
			if ( ! in_array( $cell, $valid_cells, TRUE ) ) {
				return new WP_Error( 'us_mcp_grid_layout_bad_cell', sprintf( '%s: placement.cell "%s" is not "middle_center" or a container id (%s).', $label, $cell, implode( ', ', $valid_cells ) ), array( 'status' => 400 ) );
			}
			$nesting = us_mcp_grid_layout_check_nesting( $cell, $type, $label );
			if ( is_wp_error( $nesting ) ) {
				return $nesting;
			}

			$param_spec = us_mcp_builder_element_param_spec( $type, 'grid' );
			$values = us_get_elm_defaults( $type, 'grid' );
			foreach ( (array) us_arr_path( $op, 'params', array() ) as $pname => $pval ) {
				if ( ! isset( $param_spec[ $pname ] ) ) {
					return new WP_Error( 'us_mcp_grid_layout_bad_param', sprintf( '%s: "%s" is not a param of element "%s".', $label, $pname, $type ), array( 'status' => 400 ) );
				}
				$checked = us_mcp_builder_check_param( $param_spec[ $pname ], $pval, $type . '.' . $pname );
				if ( is_wp_error( $checked ) ) {
					return $checked;
				}
				$values[ $pname ] = $checked;
			}

			$elm_id = us_mcp_builder_next_elm_id( $settings, $type );
			$settings['data'][ $elm_id ] = $values;
			$added_ids[] = $elm_id;

			$ids = array_values( (array) ( $layout[ $cell ] ?? array() ) );
			$position = us_arr_path( $op, 'placement.position' );
			// No position, a negative one ("last") or past the end appends
			if ( $position === NULL OR (int) $position < 0 OR (int) $position >= count( $ids ) ) {
				$ids[] = $elm_id;
			} else {
				array_splice( $ids, (int) $position, 0, $elm_id );
			}
			$layout[ $cell ] = $ids;

			// A new element has no children yet, so only a TTA element itself can end up nested in another one
			if ( in_array( $type, us_mcp_grid_layout_tta_types(), TRUE ) AND us_mcp_grid_layout_find_nested_tta( $layout ) ) {
				return new WP_Error( 'us_mcp_grid_layout_bad_nesting', sprintf( '%s: "%s" cannot go into "%s" — Tabs / Accordion / Vertical Tabs cannot be nested inside another one.', $label, $type, $cell ), array( 'status' => 400 ) );
			}
		}
	}

	// 2) update_element
	if ( isset( $operations['update_element'] ) ) {
		if ( ! is_array( $operations['update_element'] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_op', '`update_element` must be an object.', array( 'status' => 400 ) );
		}
		foreach ( $operations['update_element'] as $elm_id => $patch ) {
			if ( ! isset( $settings['data'][ $elm_id ] ) ) {
				return new WP_Error( 'us_mcp_grid_layout_elm_not_found', sprintf( 'update_element: no element "%s" in this Grid Layout (see upsolution-get-grid-layout).', $elm_id ), array( 'status' => 404 ) );
			}
			$type = strtok( $elm_id, ':' );
			$param_spec = us_mcp_builder_element_param_spec( $type, 'grid' );
			$defaults = us_get_elm_defaults( $type, 'grid' );
			foreach ( (array) $patch as $pname => $pval ) {
				if ( ! isset( $param_spec[ $pname ] ) ) {
					return new WP_Error( 'us_mcp_grid_layout_bad_param', sprintf( 'update_element "%s": "%s" is not a param of element "%s".', $elm_id, $pname, $type ), array( 'status' => 400 ) );
				}
				if ( $pval === NULL ) {
					$settings['data'][ $elm_id ][ $pname ] = $defaults[ $pname ] ?? '';
					continue;
				}
				$checked = us_mcp_builder_check_param( $param_spec[ $pname ], $pval, $elm_id . '.' . $pname );
				if ( is_wp_error( $checked ) ) {
					return $checked;
				}
				$settings['data'][ $elm_id ][ $pname ] = $checked;
			}
		}
	}

	// 3) remove_element — a container goes together with everything inside it, like in the Grid Builder
	if ( isset( $operations['remove_element'] ) ) {
		if ( ! is_array( $operations['remove_element'] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_op', '`remove_element` must be an array of ids.', array( 'status' => 400 ) );
		}
		$removed_in_call = array();
		foreach ( $operations['remove_element'] as $elm_id ) {
			$elm_id = (string) $elm_id;
			// Already removed together with a container listed earlier
			if ( isset( $removed_in_call[ $elm_id ] ) ) {
				continue;
			}
			if ( ! isset( $settings['data'][ $elm_id ] ) ) {
				return new WP_Error( 'us_mcp_grid_layout_elm_not_found', sprintf( 'remove_element: no element "%s" in this Grid Layout.', $elm_id ), array( 'status' => 404 ) );
			}
			$removed = array_merge( array( $elm_id ), us_mcp_grid_layout_descendants( $layout, $elm_id ) );
			foreach ( $removed as $removed_id ) {
				unset( $settings['data'][ $removed_id ], $layout[ $removed_id ] );
				$removed_in_call[ $removed_id ] = TRUE;
			}
			foreach ( $layout as $cell => $ids ) {
				$layout[ $cell ] = array_values( array_diff( (array) $ids, $removed ) );
			}
		}
	}

	// 4) set_options
	if ( isset( $operations['set_options'] ) ) {
		if ( ! is_array( $operations['set_options'] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_op', '`set_options` must be an object of option => value.', array( 'status' => 400 ) );
		}
		$option_spec = us_mcp_builder_option_spec( 'grid-settings.options' );
		foreach ( $operations['set_options'] as $key => $val ) {
			if ( ! isset( $option_spec[ $key ] ) ) {
				return new WP_Error( 'us_mcp_grid_layout_bad_option', sprintf( 'set_options: "%s" is not a Grid Layout option (%s).', $key, implode( ', ', array_keys( $option_spec ) ) ), array( 'status' => 400 ) );
			}
			if ( $val === NULL ) {
				$settings['default']['options'][ $key ] = $option_spec[ $key ]['std'];
				continue;
			}
			$checked = us_mcp_builder_check_scalar( $option_spec[ $key ], $val, $key );
			if ( is_wp_error( $checked ) ) {
				return $checked;
			}
			$settings['default']['options'][ $key ] = $checked;
		}
	}

	// 5) set_layout
	if ( isset( $operations['set_layout'] ) ) {
		if ( ! is_array( $operations['set_layout'] ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_op', '`set_layout` must be an object of cell => [elm_id, …].', array( 'status' => 400 ) );
		}
		/**
		 * Validate every cell / id first and collect the placed ids, so they can be pulled out
		 * of their previous place — an element lives in exactly one cell.
		 */
		$assignments = $placed = array();
		$valid_cells = us_mcp_grid_layout_target_cells( $settings );
		foreach ( $operations['set_layout'] as $cell => $ids ) {
			if ( ! in_array( $cell, $valid_cells, TRUE ) ) {
				return new WP_Error( 'us_mcp_grid_layout_bad_cell', sprintf( 'set_layout: "%s" is not "middle_center" or a container id (%s).', $cell, implode( ', ', $valid_cells ) ), array( 'status' => 400 ) );
			}
			$ids = array_map( 'strval', array_values( (array) $ids ) );
			foreach ( $ids as $elm_id ) {
				if ( ! isset( $settings['data'][ $elm_id ] ) ) {
					return new WP_Error( 'us_mcp_grid_layout_elm_not_found', sprintf( 'set_layout[%s]: no element "%s" in this Grid Layout.', $cell, $elm_id ), array( 'status' => 404 ) );
				}
				if ( isset( $placed[ $elm_id ] ) ) {
					return new WP_Error( 'us_mcp_grid_layout_bad_layout', sprintf( 'set_layout[%s]: "%s" is listed more than once — an element is placed in exactly one cell.', $cell, $elm_id ), array( 'status' => 400 ) );
				}
				$nesting = us_mcp_grid_layout_check_nesting( $cell, strtok( $elm_id, ':' ), 'set_layout[' . $cell . ']' );
				if ( is_wp_error( $nesting ) ) {
					return $nesting;
				}
				$placed[ $elm_id ] = TRUE;
			}
			$assignments[ $cell ] = $ids;
		}
		foreach ( $layout as $cell => $ids ) {
			$layout[ $cell ] = array_values( array_filter( (array) $ids, function ( $elm_id ) use ( $placed ) {
				return ! isset( $placed[ $elm_id ] );
			} ) );
		}
		foreach ( $assignments as $cell => $ids ) {
			$layout[ $cell ] = $ids;
		}
		if ( $cycle_id = us_mcp_grid_layout_find_cycle( $layout ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_nesting', sprintf( 'set_layout: container "%s" would end up inside itself.', $cycle_id ), array( 'status' => 400 ) );
		}
		// Checked on the final layout, so a wrapper holding Tabs moved into a section is caught too
		if ( $nested_id = us_mcp_grid_layout_find_nested_tta( $layout ) ) {
			return new WP_Error( 'us_mcp_grid_layout_bad_nesting', sprintf( 'set_layout: "%s" would end up inside another Tabs / Accordion / Vertical Tabs — they cannot be nested.', $nested_id ), array( 'status' => 400 ) );
		}
	}

	return array( 'added_ids' => $added_ids );
}

/* -------------------------------------------------------------------------
 * Grid Layout authoring tools — execute callbacks
 * ---------------------------------------------------------------------- */

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_get_grid_layout( $input ) {
	$input = (array) $input;
	$ref = us_mcp_grid_layout_resolve( $input['id'] ?? NULL, /* allow_template */ TRUE );
	if ( is_wp_error( $ref ) ) {
		return $ref;
	}
	if ( $ref['post'] AND ! current_user_can( 'edit_post', $ref['post']->ID ) ) {
		return new WP_Error( 'us_mcp_grid_layout_forbidden', sprintf( 'You cannot read Grid Layout id=%d.', $ref['post']->ID ), array( 'status' => 403 ) );
	}

	return us_mcp_grid_layout_present( $ref, us_mcp_grid_layout_expand( $ref['config'] ) );
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_create_grid_layout( $input ) {
	$input = (array) $input;
	if ( ! post_type_exists( 'us_grid_layout' ) ) {
		return new WP_Error( 'us_mcp_grid_layouts_disabled', '"us_grid_layout" is not registered on this site.', array( 'status' => 400 ) );
	}
	$title = isset( $input['title'] ) ? trim( (string) $input['title'] ) : '';
	if ( $title === '' ) {
		return new WP_Error( 'us_mcp_grid_layout_bad_title', '`title` is required.', array( 'status' => 400 ) );
	}

	/**
	 * Same rules as create-post: the type's create_posts cap, and its publish
	 * cap for a published / scheduled / private record.
	 */
	$pt_obj = get_post_type_object( 'us_grid_layout' );
	if ( ! current_user_can( $pt_obj->cap->create_posts ) ) {
		return new WP_Error( 'us_mcp_grid_layout_forbidden', 'You do not have permission to create Grid Layouts.', array( 'status' => 403 ) );
	}
	if ( isset( $input['status'] ) ) {
		$status = sanitize_key( (string) $input['status'] );
	} else {
		$status = current_user_can( $pt_obj->cap->publish_posts ) ? 'publish' : 'draft';
	}
	$status_cap = us_mcp_require_publish_cap( $pt_obj->cap->publish_posts, $status );
	if ( is_wp_error( $status_cap ) ) {
		return $status_cap;
	}

	$source = $input['source'] ?? 'blank';
	if ( $source === 'blank' OR $source === '' ) {
		$config = array();
	} else {
		$ref = us_mcp_grid_layout_resolve( $source, /* allow_template */ TRUE );
		if ( is_wp_error( $ref ) ) {
			return $ref;
		}
		if ( $ref['post'] AND ! current_user_can( 'edit_post', $ref['post']->ID ) ) {
			return new WP_Error( 'us_mcp_grid_layout_forbidden', sprintf( 'You cannot copy Grid Layout id=%d.', $ref['post']->ID ), array( 'status' => 403 ) );
		}
		$config = $ref['config'];
	}

	$post_id = wp_insert_post( array(
		'post_type' => 'us_grid_layout',
		'post_status' => $status,
		'post_title' => wp_slash( $title ),
		'post_content' => us_mcp_grid_layout_encode( us_mcp_grid_layout_expand( $config ) ),
	), TRUE );
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}

	return array(
		'id' => (int) $post_id,
		'title' => get_post( $post_id )->post_title,
		'selector' => (int) $post_id,
		'edit_link' => admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' ),
	);
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_update_grid_layout( $input ) {
	$input = (array) $input;
	$ref = us_mcp_grid_layout_resolve( $input['id'] ?? NULL, /* allow_template */ FALSE );
	if ( is_wp_error( $ref ) ) {
		return $ref;
	}
	$post = $ref['post'];
	if ( ! current_user_can( 'edit_post', $post->ID ) ) {
		return new WP_Error( 'us_mcp_grid_layout_forbidden', sprintf( 'You cannot edit Grid Layout id=%d.', $post->ID ), array( 'status' => 403 ) );
	}
	// Lists don't use a trashed record, so edits to it would not show anywhere
	if ( $post->post_status === 'trash' ) {
		return new WP_Error( 'us_mcp_grid_layout_trashed', sprintf( 'Grid Layout id=%d is in the trash — restore it from wp-admin before editing.', $post->ID ), array( 'status' => 409 ) );
	}

	$settings = us_mcp_grid_layout_expand( $ref['config'] );
	// A cyclic layout (hand-edited JSON, import) would send the descendant walks of the operations into endless recursion
	if ( $cycle_id = us_mcp_grid_layout_find_cycle( $settings['default']['layout'] ) ) {
		return new WP_Error( 'us_mcp_grid_layout_corrupt', sprintf( 'Grid Layout id=%d is corrupt: container "%s" is nested inside itself. Fix it in the Grid Builder (wp-admin) before editing it via MCP.', $post->ID, $cycle_id ), array( 'status' => 409 ) );
	}
	$result = us_mcp_grid_layout_apply_operations( $settings, $input['operations'] ?? array() );
	if ( is_wp_error( $result ) ) {
		return $result;
	}

	/**
	 * Reset the hidden tray so us_fix_grid_layout_settings() recomputes it from
	 * "every element not placed", without stale or duplicate entries.
	 */
	$settings['default']['layout']['hidden'] = array();
	$settings = us_mcp_grid_layout_expand( $settings );

	$postarr = array(
		'ID' => $post->ID,
		'post_content' => us_mcp_grid_layout_encode( $settings ),
	);
	if ( isset( $input['title'] ) AND trim( (string) $input['title'] ) !== '' ) {
		$postarr['post_title'] = wp_slash( (string) $input['title'] );
	}
	$updated = wp_update_post( $postarr, TRUE );
	if ( is_wp_error( $updated ) ) {
		return $updated;
	}

	$ref['post'] = get_post( $post->ID );
	$out = us_mcp_grid_layout_present( $ref, $settings );
	$out['added_ids'] = $result['added_ids'];

	return $out;
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_delete_grid_layout( $input ) {
	$input = (array) $input;
	$ref = us_mcp_grid_layout_resolve( $input['id'] ?? NULL, /* allow_template */ FALSE );
	if ( is_wp_error( $ref ) ) {
		return $ref;
	}
	$post = $ref['post'];
	if ( ! current_user_can( 'delete_post', $post->ID ) ) {
		return new WP_Error( 'us_mcp_grid_layout_forbidden', sprintf( 'You cannot delete Grid Layout id=%d.', $post->ID ), array( 'status' => 403 ) );
	}
	if ( $post->post_status === 'trash' ) {
		return array( 'id' => (int) $post->ID, 'trashed' => TRUE );
	}
	/**
	 * With the trash disabled (EMPTY_TRASH_DAYS = 0) wp_trash_post() deletes permanently,
	 * which this tool must not do (same rule as delete-post)
	 */
	if ( ! EMPTY_TRASH_DAYS ) {
		return new WP_Error(
			'us_mcp_grid_layout_trash_disabled',
			sprintf( 'Cannot move Grid Layout id=%d to the trash: this site has the trash disabled (EMPTY_TRASH_DAYS = 0), and permanent deletion is not allowed via MCP. Delete it from wp-admin if that is truly intended.', $post->ID ),
			array( 'status' => 409 )
		);
	}

	return array( 'id' => (int) $post->ID, 'trashed' => (bool) wp_trash_post( $post->ID ) );
}
