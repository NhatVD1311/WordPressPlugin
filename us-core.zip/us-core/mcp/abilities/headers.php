<?php
/**
 * UpSolution MCP — Headers (us_header).
 *
 * Currently exposes one read-only ability:
 *
 *   upsolution-list-headers
 *
 * Resolves a human-readable Header name to its post id. The id is used by
 * meta `us_header_id` on page / post / us_portfolio (whitelisted in the
 * post-types registry) to assign a custom header to a single record via
 * upsolution-update-post.
 *
 * The `us_header` post type is registered with `'supports' => FALSE` and
 * `'capability_type' => $templates_capability` (white-label-aware) in
 * functions/post-types.php. Its `post_content` is a JSON config produced by
 * the Header Builder (see functions/header.php: `json_decode(
 * $header->post_content, TRUE )`), NOT shortcode markup, so the generic
 * upsolution-create-post / update-post pipeline must not be used on it —
 * doing so would overwrite valid JSON and silently break the header. The
 * generic CRUD's `post_type` enum already excludes `us_header` for this
 * reason.
 *
 * Full header authoring now lives in this file alongside list-headers:
 *
 *   upsolution-list-header-templates  — built-in starting points
 *   upsolution-get-header             — read the expanded settings + elements
 *   upsolution-create-header          — new us_header from a template (or blank)
 *   upsolution-update-header          — transactional edit (options / elements / layout)
 *   upsolution-delete-header          — trash
 *
 * All of them speak the Header Builder JSON shape documented in
 * llms/design/headers.md (served via upsolution-read-doc as design/headers).
 * The settings are reconstructed / validated with us_fix_header_settings()
 * and persisted with a plain wp_update_post(), exactly like the admin builder
 * AJAX save (functions/ajax/header_builder.php). Option and element param
 * values are checked with the shared USOF validators in mcp/builder-fields.php.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

add_action( 'wp_abilities_api_init', function () {
	wp_register_ability( 'upsolution/list-headers', array(
		'label' => 'List Headers',
		'description' => 'List Headers (us_header) so the agent can resolve a human-readable name to a numeric id. Pass the returned id as meta `us_header_id` on upsolution-update-post (whitelisted on page / post / us_portfolio) to assign a custom header to that record. Read-only — us_header stores a custom Header Builder JSON config in post_content (not shortcode markup), so the generic CRUD tools refuse this type. Returns id / slug / title / status / modified / edit_link.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'properties' => array(
				'search' => array(
					'type' => 'string',
					'description' => 'Optional. Forwarded to WP_Query\'s full-text search (`s`): matches against post_title, post_content AND post_excerpt; multi-word queries are AND\'d across terms. Caveat: us_header.post_content is a Header Builder JSON blob, so search terms collide with JSON keys (e.g. "sticky", "transparent", "position" will hit configuration tokens, not just human-readable labels). For narrow lookup, pass an empty `search` and filter the returned list by title client-side, or call with no params and pick by id.',
				),
				'status' => array(
					'type' => 'string',
					'description' => 'Comma-separated WP post statuses (e.g. "publish,draft"). Default: "publish,draft".',
					'default' => 'publish,draft',
				),
				'per_page' => array(
					'type' => 'integer',
					'description' => 'Maximum number of records to return (default 20, max 100).',
					'default' => 20,
					'minimum' => 1,
					'maximum' => 100,
				),
			),
		),
		'output_schema' => array(
			'type' => 'array',
			'items' => array(
				'type' => 'object',
				'properties' => array(
					'id' => array(
						'type' => 'integer',
						'description' => 'Post id. Pass this as meta `us_header_id` on upsolution-update-post.',
					),
					'post_type' => array( 'type' => 'string' ),
					'slug' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'status' => array( 'type' => 'string' ),
					'modified' => array( 'type' => 'string' ),
					'edit_link' => array(
						'type' => 'string',
						'description' => 'wp-admin URL of the Header Builder for this record.',
					),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_list_headers',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/**
 * Permission gate for the headers tools. Consults the registered post-type
 * object's edit_posts cap, because us_header uses $templates_capability
 * (white-label-aware) at registration — hardcoding edit_posts would bypass
 * the white-label remap.
 *
 * Shared by every ability declared in this file so a future CRUD does not
 * have to re-derive the cap. Mutating callbacks should still do a per-post
 * `edit_post` / `delete_post` check after resolving the id.
 *
 * @return bool
 */
function us_mcp_header_permission_callback() {
	if ( ! post_type_exists( 'us_header' ) ) {
		return current_user_can( 'edit_posts' );
	}
	$pt_obj = get_post_type_object( 'us_header' );
	if ( ! $pt_obj OR ! isset( $pt_obj->cap->edit_posts ) ) {
		return FALSE;
	}

	return current_user_can( $pt_obj->cap->edit_posts );
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_list_headers( $input ) {
	$input = (array) $input;
	if ( ! post_type_exists( 'us_header' ) ) {
		return new WP_Error(
			'us_mcp_headers_disabled',
			'"us_header" is not registered on this site.',
			array( 'status' => 400 )
		);
	}

	$status_csv = isset( $input['status'] ) ? (string) $input['status'] : 'publish,draft';
	$statuses = array_filter( array_map( 'trim', explode( ',', $status_csv ) ) );
	if ( empty( $statuses ) ) {
		$statuses = array( 'publish', 'draft' );
	}
	$per_page = isset( $input['per_page'] ) ? (int) $input['per_page'] : 20;
	$per_page = max( 1, min( 100, $per_page ) );

	$args = array(
		'post_type' => 'us_header',
		'post_status' => $statuses,
		'posts_per_page' => $per_page,
		'orderby' => 'modified',
		'order' => 'DESC',
	);
	if ( isset( $input['search'] ) AND trim( (string) $input['search'] ) !== '' ) {
		$args['s'] = (string) $input['search'];
	}

	$query = new WP_Query( $args );
	$out = array();
	foreach ( $query->posts as $post ) {
		$out[] = array(
			'id' => (int) $post->ID,
			'post_type' => $post->post_type,
			'slug' => $post->post_name,
			'title' => $post->post_title,
			'status' => $post->post_status,
			'modified' => mysql2date( 'c', $post->post_modified_gmt, FALSE ),
			'edit_link' => admin_url( 'post.php?post=' . $post->ID . '&action=edit' ),
		);
	}

	return $out;
}

/* -------------------------------------------------------------------------
 * Header authoring tools — registration
 * ---------------------------------------------------------------------- */

add_action( 'wp_abilities_api_init', function () {

	wp_register_ability( 'upsolution/list-header-templates', array(
		'label' => 'List header templates',
		'description' => 'List the built-in Header Builder templates that upsolution-create-header can start from (the same presets the admin builder\'s "Templates" picker shows). Returns id / label / summary (which areas and element types it uses) / preview_image_url. Read-only.',
		'category' => 'upsolution',
		'output_schema' => array(
			'type' => 'object',
			'required' => array( 'templates' ),
			'properties' => array(
				'templates' => array(
					'type' => 'array',
					'items' => array(
						'type' => 'object',
						'properties' => array(
							'id' => array(
								'type' => 'string',
								'description' => 'Pass as `template` to upsolution-create-header.',
							),
							'label' => array( 'type' => 'string' ),
							'summary' => array(
								'type' => 'string',
								'description' => 'Areas shown and element types placed by this template.',
							),
							'preview_image_url' => array( 'type' => 'string' ),
						),
					),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_list_header_templates',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/get-header', array(
		'label' => 'Read one header',
		'description' => 'Return one Header (us_header) as the fully-expanded Header Builder settings: per responsive state (default / laptops / tablets / mobiles) the effective `options` and the `layout` (ordered element ids per cell, plus `hidden`), and an `elements` list giving each instance\'s id / type / current params (element defaults merged with the header\'s overrides). Use this immediately before upsolution-update-header — element ids, the per-state cell order and the current option / param values all come from here. MANDATORY pre-read: the design/headers doc (upsolution-read-doc).',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'properties' => array(
				'id' => array(
					'type' => 'integer',
					'description' => 'us_header post id (from upsolution-list-headers).',
				),
				'slug' => array( 'type' => 'string', 'description' => 'us_header slug — alternative to id.' ),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'additionalProperties' => TRUE,
			'required' => array( 'id', 'title', 'states', 'elements' ),
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'slug' => array( 'type' => 'string' ),
				'title' => array( 'type' => 'string' ),
				'states' => array(
					'type' => 'object',
					'additionalProperties' => TRUE,
					'description' => 'Keyed by state: { options:{…}, layout:{ cell: [elm_id…], …, hidden:[…] } }.',
				),
				'elements' => array(
					'type' => 'array',
					'description' => 'One entry per element instance: { elm_id, type, params }.',
					'items' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_get_header',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/create-header', array(
		'label' => 'Create a header',
		'description' => 'Create a new Header (us_header) from a built-in template (upsolution-list-header-templates) or from "blank". Returns { id, slug, title, edit_link }. After creating: read it with upsolution-get-header, then customise with upsolution-update-header (place / edit elements, set a menu element\'s source to a menu slug, tune per-state options). To make a page use this header, set meta `us_header_id` to the returned id via upsolution-update-post (or set it as the site default in Theme Options). MANDATORY pre-read: the design/headers doc.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'title' ),
			'additionalProperties' => FALSE,
			'properties' => array(
				'title' => array( 'type' => 'string', 'description' => 'Header name (shown in the Headers list).' ),
				'template' => array(
					'type' => 'string',
					'description' => 'Template id from upsolution-list-header-templates, or "blank" for an empty header. Default: "simple_1".',
					'default' => 'simple_1',
				),
				'status' => array(
					'type' => 'string',
					'description' => 'WP post status. Default: "publish".',
					'default' => 'publish',
				),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'required' => array( 'id', 'slug', 'title', 'edit_link' ),
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'slug' => array( 'type' => 'string' ),
				'title' => array( 'type' => 'string' ),
				'edit_link' => array( 'type' => 'string' ),
			),
		),
		'execute_callback' => 'us_mcp_ability_create_header',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/update-header', array(
		'label' => 'Edit one header',
		'description' => 'Edit one Header (us_header) by applying operation groups as a single transaction — validated against an in-memory copy first; if any check fails, nothing is saved. Get the header id from upsolution-list-headers and its current state from upsolution-get-header immediately before calling. MANDATORY pre-read: the design/headers doc (upsolution-read-doc) — option keys, element types & params, the JSON shape, per-state inheritance, and full detail on every operation below.' . "\n\n"
			. 'operations groups (all optional, applied in this order — see doc §Editing for shapes, §Element catalog / §Sizing / §Repeater fields for update_element, §Header options for set_options, §Responsive states for set_layout):' . "\n"
			. '  - add_element:    [ { type, params?:{…}, placement:{ cell, position?, state? }, all_states?:bool } ] — add an element (image, menu, text, btn, search, socials, hwrapper/vwrapper, …). Allocates the next free "type:N" id. cell is one of the 9 cells or a wrapper id.' . "\n"
			. '  - update_element: { "<elm_id>": { "<param>": value | null } } — edit an element\'s params. No dedicated size param? Use the `css` Design param, e.g. {"css":{"default":{"font-size":"18px"}}}. Repeaters (socials `items`, dropdown `links`) take a row array. null resets to default.' . "\n"
			. '  - remove_element: [ "<elm_id>" ] — delete elements (removed from every state\'s layout too).' . "\n"
			. '  - set_options:    { "<state>": { "<option_key>": value | null } } — header / area settings per responsive state (sticky, transparent, shadow, <area>_show/_height/_width/_bg_color/_text_color, …). null reverts to the inherited value. Colors use upsolution-set-palette syntax.' . "\n"
			. '  - set_layout:     { "<state>": { "<cell>": [ "<elm_id>", … ] } } — ordered element placement for a cell in ONE state. NOTE: the DOM renders once from `default` — other states only show/hide via that state\'s `hidden` tray (e.g. {"mobiles":{"hidden":["search:1"]}}), they do not reorder.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'id', 'operations' ),
			'additionalProperties' => FALSE,
			'properties' => array(
				'id' => array( 'type' => 'integer', 'description' => 'us_header post id.' ),
				'title' => array( 'type' => 'string', 'description' => 'Optional: rename the header.' ),
				'operations' => array(
					'type' => 'object',
					'additionalProperties' => TRUE,
					'description' => 'Any of: add_element (array), update_element (object), remove_element (array), set_options (object), set_layout (object). See the tool description for shapes.',
					'properties' => array(
						'add_element' => array(
							'type' => 'array',
							'items' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						),
						'update_element' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						'remove_element' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
						'set_options' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
						'set_layout' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
					),
				),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'additionalProperties' => TRUE,
			'required' => array( 'id', 'title', 'states', 'elements' ),
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'title' => array( 'type' => 'string' ),
				'added_ids' => array(
					'type' => 'array',
					'items' => array( 'type' => 'string' ),
					'description' => 'Element ids assigned by add_element operations, in order.',
				),
				'states' => array(
					'type' => 'object',
					'additionalProperties' => TRUE,
					'description' => 'Expanded post-save state (same shape as upsolution-get-header).',
				),
				'elements' => array(
					'type' => 'array',
					'items' => array( 'type' => 'object', 'additionalProperties' => TRUE ),
				),
			),
		),
		'execute_callback' => 'us_mcp_ability_update_header',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );

	wp_register_ability( 'upsolution/delete-header', array(
		'label' => 'Delete a header',
		'description' => 'Move a Header (us_header) to the trash (not permanent — restore from wp-admin). Idempotent. Pages that referenced it via meta `us_header_id` fall back to the site default header.',
		'category' => 'upsolution',
		'input_schema' => array(
			'type' => 'object',
			'required' => array( 'id' ),
			'additionalProperties' => FALSE,
			'properties' => array(
				'id' => array( 'type' => 'integer', 'description' => 'us_header post id.' ),
			),
		),
		'output_schema' => array(
			'type' => 'object',
			'required' => array( 'id', 'trashed' ),
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'trashed' => array( 'type' => 'boolean' ),
			),
		),
		'execute_callback' => 'us_mcp_ability_delete_header',
		'permission_callback' => 'us_mcp_header_permission_callback',
		'meta' => array( 'mcp' => array( 'public' => TRUE ) ),
	) );
} );

/* -------------------------------------------------------------------------
 * Shared helpers
 * ---------------------------------------------------------------------- */

/**
 * The nine placement cells plus the hidden tray.
 *
 * @return string[]
 */
function us_mcp_header_layout_cells() {
	return array(
		'top_left',
		'top_center',
		'top_right',
		'middle_left',
		'middle_center',
		'middle_right',
		'bottom_left',
		'bottom_center',
		'bottom_right',
		'hidden',
	);
}

/**
 * Element types the Header Builder supports on this install (cart only with
 * WooCommerce, etc. — read straight from the same config the builder uses).
 *
 * @return string[]
 */
function us_mcp_header_element_types() {
	return array_values( (array) us_config( 'header-settings.elements', array() ) );
}

/**
 * Resolve { id | slug } into a us_header WP_Post.
 *
 * @param array $input
 * @param bool $allow_slug
 * @return WP_Post|WP_Error
 */
function us_mcp_header_resolve( $input, $allow_slug = TRUE ) {
	if ( ! post_type_exists( 'us_header' ) ) {
		return new WP_Error( 'us_mcp_headers_disabled', '"us_header" is not registered on this site.', array( 'status' => 400 ) );
	}
	$post = NULL;
	if ( isset( $input['id'] ) AND (int) $input['id'] > 0 ) {
		$post = get_post( (int) $input['id'] );
	} elseif ( $allow_slug AND isset( $input['slug'] ) AND trim( (string) $input['slug'] ) !== '' ) {
		$found = get_posts( array(
			'post_type' => 'us_header',
			'name' => sanitize_title( (string) $input['slug'] ),
			'post_status' => 'any',
			'posts_per_page' => 1,
		) );
		$post = $found ? $found[0] : NULL;
	} else {
		return new WP_Error( 'us_mcp_header_no_ref', 'Provide `id` (or `slug`) of the header.', array( 'status' => 400 ) );
	}
	if ( ! $post OR $post->post_type !== 'us_header' ) {
		return new WP_Error( 'us_mcp_header_not_found', 'No us_header found for the given id / slug (see upsolution-list-headers).', array( 'status' => 404 ) );
	}

	return $post;
}

/**
 * Decode + normalise a header's stored JSON into the fully-expanded working copy.
 *
 * @param WP_Post $post
 * @return array
 */
function us_mcp_header_read_settings( $post ) {
	$settings = array();
	$raw = (string) $post->post_content;
	if ( $raw !== '' AND strpos( $raw, '{' ) === 0 ) {
		$decoded = json_decode( $raw, TRUE );
		if ( is_array( $decoded ) ) {
			$settings = $decoded;
		}
	}
	if ( function_exists( 'us_header_settings_fallback' ) AND ! empty( $settings['default'] ) ) {
		$settings = us_header_settings_fallback( $settings );
	}

	return us_fix_header_settings( $settings );
}

/**
 * Collapse the expanded settings into the JSON shape stored in post_content.
 *
 * IMPORTANT: options and layout are stored FULL (every key, every cell, every
 * state); only element `data` params are sparsed (down to what differs from the
 * element defaults). The reason is the front-end load path: us_load_header_settings()
 * runs only us_header_settings_fallback() on the decoded JSON — it does NOT call
 * us_fix_header_settings() — and us_get_header_option() back-fills config defaults
 * for *color* options only. So any non-color option that is absent from the stored
 * JSON resolves to NULL at render time: e.g. a dropped `orientation` (== std "hor")
 * sends css-header.php down the vertical branch, the `--header-height` rules are
 * never emitted, and the header collapses ("missing styles in us-current-header-css").
 * Element data is safe to sparse because us_get_header_elms_of_a_type() merges each
 * instance over us_get_elm_defaults() at render time.
 *
 * @param array $settings expanded (post us_fix_header_settings)
 * @return array
 */
function us_mcp_header_sparse( $settings ) {
	$out = us_mcp_header_state_views( $settings );

	// Element data — keep only params that differ from the element defaults.
	$out['data'] = array();
	foreach ( (array) us_arr_path( $settings, 'data', array() ) as $elm_id => $params ) {
		$type = strtok( $elm_id, ':' );
		$defaults = us_get_elm_defaults( $type, 'header' );
		$sparse = array();
		foreach ( (array) $params as $key => $val ) {
			$def = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : NULL;
			if ( ! us_mcp_builder_values_equal( $val, $def ) ) {
				$sparse[ $key ] = $val;
			}
		}
		$out['data'][ $elm_id ] = $sparse;
	}

	return $out;
}

/**
 * Normalise a layout array: every cell present, ids reindexed.
 *
 * @param array $layout
 * @return array
 */
function us_mcp_header_normalise_layout( $layout ) {
	$layout = (array) $layout;
	$out = array();
	foreach ( us_mcp_header_layout_cells() as $cell ) {
		$ids = ( isset( $layout[ $cell ] ) AND is_array( $layout[ $cell ] ) ) ? array_values( $layout[ $cell ] ) : array();
		$out[ $cell ] = $ids;
	}
	// Preserve wrapper container keys (e.g. "vwrapper:1" / "hwrapper:1") whose
	// value is the ordered list of child element ids placed inside that wrapper.
	// These are NOT among the 9 fixed cells, so dropping them would erase a
	// wrapper's entire contents on every create / update round-trip.
	foreach ( $layout as $key => $ids ) {
		if ( array_key_exists( $key, $out ) OR ! is_array( $ids ) OR strpos( (string) $key, ':' ) === FALSE ) {
			continue;
		}
		$out[ $key ] = array_values( $ids );
	}

	return $out;
}

/**
 * Element types that act as containers — their layout key holds child element ids.
 *
 * @return string[]
 */
function us_mcp_header_wrapper_types() {
	return array( 'hwrapper', 'vwrapper' );
}

/**
 * Valid placement targets for a header: the 9 cells + hidden, plus every
 * wrapper instance present in `data` (whose id doubles as a container key).
 *
 * @param array $settings expanded
 * @return string[]
 */
function us_mcp_header_target_cells( $settings ) {
	$cells = us_mcp_header_layout_cells();
	foreach ( array_keys( (array) us_arr_path( $settings, 'data', array() ) ) as $elm_id ) {
		if ( in_array( strtok( $elm_id, ':' ), us_mcp_header_wrapper_types(), TRUE ) ) {
			$cells[] = $elm_id;
		}
	}

	return $cells;
}

/**
 * The per-state { options, layout } view shared by the stored JSON shape
 * (us_mcp_header_sparse) and the get-header / update-header response
 * (us_mcp_header_present): options verbatim (full), layout normalised to all
 * cells. Keeping it in one place keeps storage and response in sync.
 *
 * @param array $settings expanded
 * @return array<string, array{options:array, layout:array}>
 */
function us_mcp_header_state_views( $settings ) {
	$views = array();
	foreach ( us_mcp_builder_states() as $state ) {
		$views[ $state ] = array(
			'options' => (array) us_arr_path( $settings, array( $state, 'options' ), array() ),
			'layout' => us_mcp_header_normalise_layout(
				(array) us_arr_path( $settings, array(
					$state,
					'layout',
				), array() )
			),
		);
	}

	return $views;
}

/**
 * Build the get-header / update-header response body from expanded settings.
 *
 * @param WP_Post $post
 * @param array $settings expanded
 * @return array
 */
function us_mcp_header_present( $post, $settings ) {
	$elements = array();
	foreach ( (array) us_arr_path( $settings, 'data', array() ) as $elm_id => $params ) {
		$elements[] = array(
			'elm_id' => $elm_id,
			'type' => strtok( $elm_id, ':' ),
			'params' => (array) $params,
		);
	}

	return array(
		'id' => (int) $post->ID,
		'slug' => $post->post_name,
		'title' => $post->post_title,
		'states' => us_mcp_header_state_views( $settings ),
		'elements' => $elements,
	);
}

/* -------------------------------------------------------------------------
 * Operation application
 * ---------------------------------------------------------------------- */

/**
 * Apply the update-header operation groups to an expanded working copy.
 * Validates everything; returns the mutated settings + assigned ids, or a
 * WP_Error (nothing is persisted by the caller on error).
 *
 * @param array $settings expanded working copy (mutated)
 * @param array $operations
 * @return array{added_ids:string[]}|WP_Error
 */
function us_mcp_header_apply_operations( &$settings, $operations ) {
	$operations = (array) $operations;
	$added_ids = array();
	$states = us_mcp_builder_states();
	$valid_types = us_mcp_header_element_types();

	// 1) add_element
	if ( isset( $operations['add_element'] ) ) {
		if ( ! is_array( $operations['add_element'] ) ) {
			return new WP_Error( 'us_mcp_header_bad_op', '`add_element` must be an array.', array( 'status' => 400 ) );
		}
		foreach ( $operations['add_element'] as $i => $op ) {
			$op = (array) $op;
			$type = isset( $op['type'] ) ? (string) $op['type'] : '';
			if ( ! in_array( $type, $valid_types, TRUE ) ) {
				return new WP_Error( 'us_mcp_header_bad_type', sprintf( 'add_element[%d]: unknown element type "%s". Allowed: %s.', $i, $type, implode( ', ', $valid_types ) ), array( 'status' => 400 ) );
			}
			$placement = (array) us_arr_path( $op, 'placement', array() );
			$cell = isset( $placement['cell'] ) ? (string) $placement['cell'] : '';
			// Targets include wrapper ids already in data (recomputed each iteration
			// so a wrapper added earlier in this same call is a valid container).
			$valid_cells = us_mcp_header_target_cells( $settings );
			if ( ! in_array( $cell, $valid_cells, TRUE ) ) {
				return new WP_Error( 'us_mcp_header_bad_cell', sprintf( 'add_element[%d]: placement.cell "%s" is not a layout cell or wrapper id (%s).', $i, $cell, implode( ', ', $valid_cells ) ), array( 'status' => 400 ) );
			}
			$position = isset( $placement['position'] ) ? max( 0, (int) $placement['position'] ) : NULL;
			$one_state = isset( $placement['state'] ) ? (string) $placement['state'] : 'default';
			if ( ! in_array( $one_state, $states, TRUE ) ) {
				return new WP_Error( 'us_mcp_header_bad_state', sprintf( 'add_element[%d]: placement.state "%s" is not valid (%s).', $i, $one_state, implode( ', ', $states ) ), array( 'status' => 400 ) );
			}
			$all_states = array_key_exists( 'all_states', $op ) ? (bool) $op['all_states'] : TRUE;

			// Validate params against the element spec.
			$param_spec = us_mcp_builder_element_param_spec( $type, 'header' );
			$values = us_get_elm_defaults( $type, 'header' );
			foreach ( (array) us_arr_path( $op, 'params', array() ) as $pname => $pval ) {
				if ( ! isset( $param_spec[ $pname ] ) ) {
					return new WP_Error( 'us_mcp_header_bad_param', sprintf( 'add_element[%d]: "%s" is not a param of element "%s".', $i, $pname, $type ), array( 'status' => 400 ) );
				}
				$checked = us_mcp_builder_check_param( $param_spec[ $pname ], $pval, $type . '.' . $pname );
				if ( is_wp_error( $checked ) ) {
					return $checked;
				}
				$values[ $pname ] = $checked;
			}

			$elm_id = us_mcp_builder_next_elm_id( $settings, $type );
			$settings['data'][ $elm_id ] = $values;
			$added_ids[] = $elm_id;

			$target_states = $all_states ? $states : array( $one_state );
			foreach ( $target_states as $st ) {
				if ( ! isset( $settings[ $st ]['layout'][ $cell ] ) OR ! is_array( $settings[ $st ]['layout'][ $cell ] ) ) {
					$settings[ $st ]['layout'][ $cell ] = array();
				}
				$arr = array_values( $settings[ $st ]['layout'][ $cell ] );
				if ( $position === NULL OR $position >= count( $arr ) ) {
					$arr[] = $elm_id;
				} else {
					array_splice( $arr, $position, 0, $elm_id );
				}
				$settings[ $st ]['layout'][ $cell ] = $arr;
			}
		}
	}

	// 2) update_element
	if ( isset( $operations['update_element'] ) ) {
		if ( ! is_array( $operations['update_element'] ) ) {
			return new WP_Error( 'us_mcp_header_bad_op', '`update_element` must be an object.', array( 'status' => 400 ) );
		}
		foreach ( $operations['update_element'] as $elm_id => $patch ) {
			if ( ! isset( $settings['data'][ $elm_id ] ) ) {
				return new WP_Error( 'us_mcp_header_elm_not_found', sprintf( 'update_element: no element "%s" in this header (see upsolution-get-header).', $elm_id ), array( 'status' => 404 ) );
			}
			$type = strtok( $elm_id, ':' );
			$param_spec = us_mcp_builder_element_param_spec( $type, 'header' );
			$defaults = us_get_elm_defaults( $type, 'header' );
			foreach ( (array) $patch as $pname => $pval ) {
				if ( ! isset( $param_spec[ $pname ] ) ) {
					return new WP_Error( 'us_mcp_header_bad_param', sprintf( 'update_element "%s": "%s" is not a param of element "%s".', $elm_id, $pname, $type ), array( 'status' => 400 ) );
				}
				if ( $pval === NULL ) {
					$settings['data'][ $elm_id ][ $pname ] = array_key_exists( $pname, $defaults ) ? $defaults[ $pname ] : '';
					continue;
				}
				$checked = us_mcp_builder_check_param( $param_spec[ $pname ], $pval, $elm_id . '.' . $pname );
				if ( is_wp_error( $checked ) ) {
					return $checked;
				}
				$settings['data'][ $elm_id ][ $pname ] = $checked;
			}
		}
	}

	// 3) remove_element
	if ( isset( $operations['remove_element'] ) ) {
		if ( ! is_array( $operations['remove_element'] ) ) {
			return new WP_Error( 'us_mcp_header_bad_op', '`remove_element` must be an array of ids.', array( 'status' => 400 ) );
		}
		foreach ( $operations['remove_element'] as $elm_id ) {
			$elm_id = (string) $elm_id;
			if ( ! isset( $settings['data'][ $elm_id ] ) ) {
				return new WP_Error( 'us_mcp_header_elm_not_found', sprintf( 'remove_element: no element "%s" in this header.', $elm_id ), array( 'status' => 404 ) );
			}
			$is_wrapper = in_array( strtok( $elm_id, ':' ), us_mcp_header_wrapper_types(), TRUE );
			unset( $settings['data'][ $elm_id ] );
			foreach ( $states as $st ) {
				// Strip the id from every cell AND wrapper container of this state.
				foreach ( array_keys( (array) $settings[ $st ]['layout'] ) as $cell ) {
					if ( is_array( $settings[ $st ]['layout'][ $cell ] ) ) {
						$settings[ $st ]['layout'][ $cell ] = array_values( array_diff( $settings[ $st ]['layout'][ $cell ], array( $elm_id ) ) );
					}
				}
				// Removing a wrapper drops its container key; its children become
				// unplaced and us_fix_header_settings() moves them to `hidden`.
				if ( $is_wrapper AND isset( $settings[ $st ]['layout'][ $elm_id ] ) ) {
					unset( $settings[ $st ]['layout'][ $elm_id ] );
				}
			}
		}
	}

	// 4) set_options
	if ( isset( $operations['set_options'] ) ) {
		if ( ! is_array( $operations['set_options'] ) ) {
			return new WP_Error( 'us_mcp_header_bad_op', '`set_options` must be an object keyed by state.', array( 'status' => 400 ) );
		}
		$option_spec = us_mcp_builder_option_spec( 'header-settings.options' );
		foreach ( $operations['set_options'] as $state => $opts ) {
			if ( ! in_array( $state, $states, TRUE ) ) {
				return new WP_Error( 'us_mcp_header_bad_state', sprintf( 'set_options: "%s" is not a responsive state (%s).', $state, implode( ', ', $states ) ), array( 'status' => 400 ) );
			}
			foreach ( (array) $opts as $key => $val ) {
				if ( ! isset( $option_spec[ $key ] ) ) {
					return new WP_Error( 'us_mcp_header_bad_option', sprintf( 'set_options[%s]: "%s" is not a header option.', $state, $key ), array( 'status' => 400 ) );
				}
				if ( $val === NULL ) {
					// Revert: default state -> config std; other states -> the default state's value (inherit).
					$std_val = $option_spec[ $key ]['std'] ?? '';
					$settings[ $state ]['options'][ $key ] = ( $state === 'default' )
						? $std_val
						: ( $settings['default']['options'][ $key ] ?? $std_val );
					continue;
				}
				$checked = us_mcp_builder_check_scalar( $option_spec[ $key ], $val, $key );
				if ( is_wp_error( $checked ) ) {
					return $checked;
				}
				$settings[ $state ]['options'][ $key ] = $checked;
			}
		}
	}

	// 5) set_layout
	if ( isset( $operations['set_layout'] ) ) {
		if ( ! is_array( $operations['set_layout'] ) ) {
			return new WP_Error( 'us_mcp_header_bad_op', '`set_layout` must be an object keyed by state.', array( 'status' => 400 ) );
		}
		foreach ( $operations['set_layout'] as $state => $state_cells ) {
			if ( ! in_array( $state, $states, TRUE ) ) {
				return new WP_Error( 'us_mcp_header_bad_state', sprintf( 'set_layout: "%s" is not a responsive state (%s).', $state, implode( ', ', $states ) ), array( 'status' => 400 ) );
			}
			// Validate every cell/id first and collect the placed ids, so we can
			// pull them out of any OTHER cell of this state — an element lives in
			// exactly one cell per state, never duplicated across cells.
			$assignments = array();
			$placed = array();
			$valid_cells = us_mcp_header_target_cells( $settings );
			foreach ( (array) $state_cells as $cell => $ids ) {
				if ( ! in_array( $cell, $valid_cells, TRUE ) ) {
					return new WP_Error( 'us_mcp_header_bad_cell', sprintf( 'set_layout[%s]: "%s" is not a layout cell or wrapper id (%s).', $state, $cell, implode( ', ', $valid_cells ) ), array( 'status' => 400 ) );
				}
				$ids = array_map( 'strval', array_values( (array) $ids ) );
				foreach ( $ids as $elm_id ) {
					if ( ! isset( $settings['data'][ $elm_id ] ) ) {
						return new WP_Error( 'us_mcp_header_elm_not_found', sprintf( 'set_layout[%s][%s]: no element "%s" in this header.', $state, $cell, $elm_id ), array( 'status' => 404 ) );
					}
					$placed[ $elm_id ] = TRUE;
				}
				$assignments[ $cell ] = $ids;
			}
			// Strip the placed ids from every existing cell / wrapper of this state.
			foreach ( array_keys( (array) $settings[ $state ]['layout'] ) as $cell ) {
				if ( empty( $settings[ $state ]['layout'][ $cell ] ) OR ! is_array( $settings[ $state ]['layout'][ $cell ] ) ) {
					continue;
				}
				$kept = array();
				foreach ( $settings[ $state ]['layout'][ $cell ] as $elm_id ) {
					if ( ! isset( $placed[ (string) $elm_id ] ) ) {
						$kept[] = (string) $elm_id;
					}
				}
				$settings[ $state ]['layout'][ $cell ] = $kept;
			}
			// Apply the requested cell orders.
			foreach ( $assignments as $cell => $ids ) {
				$settings[ $state ]['layout'][ $cell ] = $ids;
			}
		}
	}

	return array( 'added_ids' => $added_ids );
}

/* -------------------------------------------------------------------------
 * Execute callbacks
 * ---------------------------------------------------------------------- */

/**
 * @return array
 */
function us_mcp_ability_list_header_templates() {
	$templates = array();
	$uri = function_exists( 'get_template_directory_uri' ) ? get_template_directory_uri() : '';
	foreach ( (array) us_config( 'header-templates', array() ) as $name => $tpl ) {
		$types = array();
		$areas = array();
		foreach ( (array) us_arr_path( $tpl, array( 'default', 'layout' ), array() ) as $cell => $ids ) {
			if ( empty( $ids ) OR $cell === 'hidden' ) {
				continue;
			}
			$areas[ strtok( $cell, '_' ) ] = TRUE;
			foreach ( (array) $ids as $elm_id ) {
				$types[ strtok( $elm_id, ':' ) ] = TRUE;
			}
		}
		$summary = sprintf(
			'areas: %s; elements: %s',
			$areas ? implode( ', ', array_keys( $areas ) ) : 'middle',
			$types ? implode( ', ', array_keys( $types ) ) : '(none)'
		);
		$templates[] = array(
			'id' => (string) $name,
			'label' => ucwords( str_replace( array( '_', '-' ), ' ', (string) $name ) ),
			'summary' => $summary,
			'preview_image_url' => $uri . '/common/admin/img/header-templates/' . $name . '.png',
		);
	}

	return array( 'templates' => $templates );
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_get_header( $input ) {
	$input = (array) $input;
	$post = us_mcp_header_resolve( $input, /* allow_slug */ TRUE );
	if ( is_wp_error( $post ) ) {
		return $post;
	}
	$settings = us_mcp_header_read_settings( $post );

	return us_mcp_header_present( $post, $settings );
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_create_header( $input ) {
	$input = (array) $input;
	if ( ! post_type_exists( 'us_header' ) ) {
		return new WP_Error( 'us_mcp_headers_disabled', '"us_header" is not registered on this site.', array( 'status' => 400 ) );
	}
	$title = isset( $input['title'] ) ? trim( (string) $input['title'] ) : '';
	if ( $title === '' ) {
		return new WP_Error( 'us_mcp_header_bad_title', '`title` is required.', array( 'status' => 400 ) );
	}
	$template = isset( $input['template'] ) ? (string) $input['template'] : 'simple_1';

	// Same rules as create-post: the type's create_posts cap, and its publish
	// cap for a published / scheduled / private header (edit_posts, which the
	// permission callback checks, must not be enough to publish).
	$pt_obj = get_post_type_object( 'us_header' );
	if ( ! current_user_can( $pt_obj->cap->create_posts ) ) {
		return new WP_Error( 'us_mcp_header_forbidden', 'You do not have permission to create headers.', array( 'status' => 403 ) );
	}
	if ( isset( $input['status'] ) ) {
		$status = sanitize_key( (string) $input['status'] );
	} else {
		$status = current_user_can( $pt_obj->cap->publish_posts ) ? 'publish' : 'draft';
	}
	$status_cap = us_mcp_require_publish_cap( $pt_obj->cap->publish_posts, $status );
	if ( is_wp_error( $status_cap ) ) {
		return $status_cap;
	}

	if ( $template === 'blank' OR $template === '' ) {
		$settings = us_fix_header_template_settings( array() );
	} else {
		$all = (array) us_config( 'header-templates', array() );
		if ( ! isset( $all[ $template ] ) ) {
			return new WP_Error(
				'us_mcp_header_bad_template',
				sprintf( 'Unknown template "%s". Available: %s, or "blank".', $template, implode( ', ', array_keys( $all ) ) ),
				array( 'status' => 400 )
			);
		}
		$settings = us_fix_header_template_settings( $all[ $template ] );
	}

	// wp_insert_post() runs wp_unslash() on $postarr, so the JSON must be
	// wp_slash()'d first — otherwise the escaped quotes wp_json_encode() emits
	// (\") get unslashed back to bare " and the stored JSON becomes invalid.
	$json = wp_slash( wp_json_encode( us_mcp_header_sparse( $settings ) ) );
	$post_id = wp_insert_post( array(
		'post_type' => 'us_header',
		'post_status' => $status,
		'post_title' => $title,
		'post_content' => $json,
	), TRUE );
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	$post = get_post( $post_id );

	return array(
		'id' => (int) $post_id,
		'slug' => $post->post_name,
		'title' => $post->post_title,
		'edit_link' => admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' ),
	);
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_update_header( $input ) {
	$input = (array) $input;
	$post = us_mcp_header_resolve( $input, /* allow_slug */ FALSE );
	if ( is_wp_error( $post ) ) {
		return $post;
	}
	if ( ! current_user_can( 'edit_post', $post->ID ) ) {
		return new WP_Error( 'us_mcp_header_forbidden', sprintf( 'You cannot edit header id=%d.', $post->ID ), array( 'status' => 403 ) );
	}

	$settings = us_mcp_header_read_settings( $post );

	$result = us_mcp_header_apply_operations( $settings, isset( $input['operations'] ) ? $input['operations'] : array() );
	if ( is_wp_error( $result ) ) {
		return $result;
	}

	// Reset each state's hidden tray so us_fix_header_settings() recomputes it
	// fresh from "every element not placed in a visible cell" — otherwise stale
	// entries left over from the expanded read could be re-merged as duplicates.
	foreach ( us_mcp_builder_states() as $st ) {
		$settings[ $st ]['layout']['hidden'] = array();
	}

	// Re-normalise (recompute hidden, fill any gaps) then collapse to storage shape.
	$settings = us_fix_header_settings( $settings );
	// wp_slash so wp_update_post()'s internal wp_unslash() leaves the escaped
	// JSON quotes intact (see create-header for the same reasoning).
	$json = wp_slash( wp_json_encode( us_mcp_header_sparse( $settings ) ) );

	$postarr = array( 'ID' => $post->ID, 'post_content' => $json );
	if ( isset( $input['title'] ) AND trim( (string) $input['title'] ) !== '' ) {
		$postarr['post_title'] = (string) $input['title'];
	}
	$updated = wp_update_post( $postarr, TRUE );
	if ( is_wp_error( $updated ) ) {
		return $updated;
	}

	// Build the response from the in-memory settings we just persisted (already
	// us_fix_header_settings()-expanded) rather than re-fetching and re-expanding
	// the post — same data, no extra DB round-trip. Reflect a title change onto
	// the cached post object for the response.
	if ( isset( $postarr['post_title'] ) ) {
		$post->post_title = $postarr['post_title'];
	}
	$out = us_mcp_header_present( $post, $settings );
	$out['added_ids'] = $result['added_ids'];

	return $out;
}

/**
 * @param array|object $input
 * @return array|WP_Error
 */
function us_mcp_ability_delete_header( $input ) {
	$input = (array) $input;
	$post = us_mcp_header_resolve( $input, /* allow_slug */ FALSE );
	if ( is_wp_error( $post ) ) {
		return $post;
	}
	if ( ! current_user_can( 'delete_post', $post->ID ) ) {
		return new WP_Error( 'us_mcp_header_forbidden', sprintf( 'You cannot delete header id=%d.', $post->ID ), array( 'status' => 403 ) );
	}
	if ( get_post_status( $post->ID ) === 'trash' ) {
		return array( 'id' => (int) $post->ID, 'trashed' => TRUE );
	}
	$trashed = wp_trash_post( $post->ID );

	return array( 'id' => (int) $post->ID, 'trashed' => (bool) $trashed );
}
