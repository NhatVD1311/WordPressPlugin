<?php
/**
 * UpSolution MCP — post meta values.
 *
 * The meta keys agents may read and write per post type (the built-in Impreza keys and
 * whatever the `us_mcp_post_type_meta_whitelist` filter adds, ACF fields included), the
 * validation of written values against their specs and the export of stored values in
 * the format the agent writes. Used by the post abilities (abilities/posts.php).
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Theme-integration meta fields shared across multiple post types in
 * config/meta-boxes.php. Each helper corresponds to one metabox group.
 *
 * Each entry is keyed by the meta key and carries a value-type spec:
 *
 *   type       string  — one of: 'string' / 'int' / 'bool_01' / 'enum' / 'color'.
 *   values     ?array  — for type='enum', the accepted values (as strings).
 *   gradient   ?bool   — for type='color', whether the renderer accepts a
 *                        *-gradient(…) value (defaults to FALSE).
 *
 * Value-type validation runs in us_mcp_validate_meta_value() — see comments
 * there for the per-type semantics. Agents that pass the wrong type get a 400
 * with a precise error rather than a silent admin-side fall through to the
 * default.
 *
 * Composite fields (`type=upload` multi, `type=link` rawurlencode'd JSON) are
 * intentionally excluded from MVP — they need bespoke encoding the agent
 * cannot infer from a JSON schema. Display-only `type=message` fields are
 * skipped too (no real value to read or write).
 *
 * Per-install field availability is gated by Theme Options at runtime
 * (`enable_sidebar_titlebar`, `enable_additional_settings`,
 * `additional_settings_post_types`, `og_enabled`). The MCP whitelist is the
 * UNION across all settings — if Theme Options hides a field in the admin
 * UI, the meta key is still harmless to write.
 *
 * @return array<string, array{type: string, values?: string[], gradient?: bool}>
 */
function us_mcp_meta_group_page_layout() {
	// `us_page_settings` metabox in config/meta-boxes.php — applied to every
	// public post type by `array_keys( $public_post_types )`. Covers Header,
	// Titlebar, Page Template, Sidebar and Footer overrides per post.
	//
	// The *_id keys (us_header_id / us_titlebar_id / us_content_id /
	// us_sidebar_id / us_footer_id) are stored as strings because the admin
	// `select` accepts both numeric ids AND special markers '__defaults__'
	// (inherit from Theme Options) and '0' (none).
	//
	// us_header_sticky / us_header_transparent / us_remove_header_offset are
	// `checkboxes` over the responsive states — stored as a comma-separated
	// string like "default,laptops". String here; the renderer parses it.
	return array(
		'us_header_id' => array( 'type' => 'string' ),
		'us_header_sticky_override' => array( 'type' => 'bool_01' ),
		'us_header_sticky' => array( 'type' => 'string' ),
		'us_header_transparent_override' => array( 'type' => 'bool_01' ),
		'us_header_transparent' => array( 'type' => 'string' ),
		'us_header_shadow' => array( 'type' => 'bool_01' ),
		'us_remove_header_offset_override' => array( 'type' => 'bool_01' ),
		'us_remove_header_offset' => array( 'type' => 'string' ),
		'us_header_sticky_pos' => array( 'type' => 'enum', 'values' => array( '', 'bottom', 'above', 'below' ) ),
		'us_titlebar_id' => array( 'type' => 'string' ),
		'us_content_id' => array( 'type' => 'string' ),
		'us_sidebar_id' => array( 'type' => 'string' ),
		'us_sidebar_pos' => array( 'type' => 'enum', 'values' => array( 'left', 'right' ) ),
		'us_footer_id' => array( 'type' => 'string' ),
	);
}

/**
 * @return array<string, array{type: string, values?: string[], gradient?: bool}>
 */
function us_mcp_meta_group_seo() {
	// `us_seo_settings` metabox — config/seo-meta-fields.php. Applies to
	// every public post type when `og_enabled` is on (default).
	//
	// us_meta_robots / us_meta_itemtype are deliberately free-form strings —
	// the admin UI shows examples but doesn't constrain (a Schema.org type
	// catalogue is huge; robots directives compose with commas).
	return array(
		'us_meta_title' => array( 'type' => 'string' ),
		'us_meta_description' => array( 'type' => 'string' ),
		'us_meta_robots' => array( 'type' => 'string' ),
		'us_meta_itemtype' => array( 'type' => 'string' ),
	);
}

/**
 * @return array<string, array{type: string, values?: string[], gradient?: bool}>
 */
function us_mcp_meta_group_additional_settings() {
	// "Additional Settings" metabox (id `us_portfolio_settings` for legacy
	// reasons). The metabox `post_types` come from the
	// `additional_settings_post_types` theme option, which defaults to ALL
	// public post types — so these keys apply to page / post / us_portfolio
	// (and any custom public type the site adds), not just us_portfolio.
	// us_tile_additional_image (multi-upload) and us_tile_link (composite
	// link JSON) excluded from MVP.
	//
	// us_tile_icon stores the icon ident (e.g. "fab|youtube"); free-form string.
	// us_tile_bg_color / us_tile_text_color go through the same palette color
	// validator as Theme Options pickers — the admin field is type=color with
	// no `with_gradient` flag, so gradients are not accepted.
	return array(
		'us_tile_icon' => array( 'type' => 'string' ),
		'us_tile_size' => array( 'type' => 'enum', 'values' => array( '1x1', '2x1', '1x2', '2x2' ) ),
		'us_tile_bg_color' => array( 'type' => 'color', 'gradient' => TRUE ),
		'us_tile_text_color' => array( 'type' => 'color', 'gradient' => FALSE ),
	);
}

/**
 * @return array<string, array{type: string, values?: string[], gradient?: bool}>
 */
function us_mcp_meta_group_testimonial() {
	// `us_testimonials_settings` metabox — author metadata rendered by the
	// testimonial element. us_testimonial_link (composite link JSON) excluded.
	//
	// us_testimonial_rating is a `radio` field — note "none" is the explicit
	// "no rating" value, NOT an empty string.
	return array(
		'us_testimonial_author' => array( 'type' => 'string' ),
		'us_testimonial_role' => array( 'type' => 'string' ),
		'us_testimonial_company' => array( 'type' => 'string' ),
		'us_testimonial_rating' => array( 'type' => 'enum', 'values' => array( 'none', '1', '2', '3', '4', '5' ) ),
	);
}

/**
 * @return array<string, array{type: string, values?: string[], gradient?: bool}>
 */
function us_mcp_meta_group_content_template_header() {
	// `us_content_template_settings` metabox — transparent-header override
	// applied to posts that render through this Page Template.
	return array(
		'us_header_transparent_override' => array( 'type' => 'bool_01' ),
		'us_header_transparent' => array( 'type' => 'string' ),
	);
}

/**
 * Meta keys readable AND writable via MCP for a post type of the registry, each
 * carrying a value-type spec (see us_mcp_meta_group_* and
 * us_mcp_validate_meta_value()): the Impreza built-in keys, plus whatever the
 * `us_mcp_post_type_meta_whitelist` filter adds — ACF fields are added by
 * plugins-support/acf.php. Other third-party meta (e.g. WooCommerce price) is
 * NOT exposed unless a site adds it through that filter.
 *
 * Built-in maps reproduce the config/meta-boxes.php assignment logic: public
 * post types get Page Layout + SEO + Additional Settings; us_testimonial and
 * us_content_template get their own group; everything else gets none. We take
 * the UNION across Theme Options toggles (og_enabled, …) rather than gating on
 * them — writing a key the admin currently hides is harmless.
 *
 * Kept out of us_mcp_post_types() and built lazily: the registry is built on
 * every REST request (the abilities register on rest_api_init), while the meta
 * keys — which may walk every ACF field group — are only needed by the tools
 * that read or write meta.
 *
 * @param string $pt Post type slug.
 * @return array<string, array{type: string}>
 */
function us_mcp_post_type_meta_whitelist( $pt ) {
	// Memoised per user and type: the filter may depend on who asks (ACF location
	// rules on the user role).
	static $cache = array();
	$cache_key = get_current_user_id() . '|' . $pt;
	if ( isset( $cache[ $cache_key ] ) ) {
		return $cache[ $cache_key ];
	}

	$meta = array();
	if ( isset( us_mcp_post_types()[ $pt ] ) ) {
		// Public types get the shared Impreza metaboxes (matches meta-boxes.php,
		// which keys those groups off us_get_public_post_types()).
		$public = function_exists( 'us_get_public_post_types' )
			? us_get_public_post_types()
			: array( 'page' => 1, 'post' => 1 );

		if ( $pt === 'us_testimonial' ) {
			$meta = us_mcp_meta_group_testimonial();
		} elseif ( $pt === 'us_content_template' ) {
			$meta = us_mcp_meta_group_content_template_header();
		} elseif ( isset( $public[ $pt ] ) ) {
			$meta = array_merge(
				us_mcp_meta_group_page_layout(),
				us_mcp_meta_group_seo(),
				us_mcp_meta_group_additional_settings()
			);
		}

		/**
		 * Filters the meta keys MCP agents may read and write for a post type.
		 *
		 * Each entry is `meta_key => spec`, where spec is an array with:
		 *   type        — 'string' / 'int' / 'number' / 'bool_01' / 'enum' / 'color'
		 *                 / 'date' (Ymd) / 'datetime' (Y-m-d H:i:s) / 'time' (H:i:s)
		 *                 / 'attachment' / 'post' / 'user' (object id), or for an
		 *                 array / object value 'list' / 'link' / 'group' / 'rows'
		 *                 (Repeater) / 'layouts' (Flexible Content). An unknown
		 *                 type is treated as 'string';
		 *   values      — for 'enum', the accepted values (strings);
		 *   min / max   — optional bounds for 'number'; the items / rows count of
		 *                 'list' / 'rows' / 'layouts' (`max` is checked, `min` only
		 *                 by ACF on publish);
		 *   item        — for 'list', the spec of each item, e.g. {type: 'post'};
		 *   sub_fields  — for 'group' / 'rows', sub field specs keyed by name;
		 *   layouts     — for 'layouts', layout name => {label, sub_fields, min, max};
		 *   acf         — the ACF field key, or array( group_key, sub_key ) for a
		 *                 sub field of a top-level Group: the value is validated by
		 *                 ACF and written through update_field(). Sub field specs
		 *                 carry the sub field key. A 'group' / 'rows' / 'layouts'
		 *                 spec must cover every named sub field of the ACF field:
		 *                 rows are stored by position, so an uncovered sub field
		 *                 would move to other rows;
		 *   required    — optional, the key must hold a value once the post is
		 *                 published (drafts may leave it empty);
		 *   label / description — optional, shown to the agent in list-post-types;
		 *   other type flags (color gradient / plain / alpha, attachment image,
		 *   post post_types, user roles) — see us_mcp_validate_meta_value().
		 * Entries of any other shape are dropped.
		 *
		 * ACF fields are added at priority 5 (plugins-support/acf.php), so a
		 * callback at the default priority can also remove them.
		 *
		 * The filter runs when an MCP tool first needs the meta keys of the type
		 * (after the request user is known), and the result is memoised for the
		 * rest of the request.
		 *
		 * Security: a listed key becomes writable for anyone who can edit the post
		 * through MCP (edit_posts plus the per-post checks) — this includes
		 * protected keys starting with "_". Its value is also returned by get-post
		 * to anyone who can read the post, i.e. to every MCP user for published
		 * public posts, so leave out (or remove) fields holding internal data.
		 *
		 * @param array $meta Meta specs keyed by meta key.
		 * @param string $pt Post type slug.
		 */
		$filtered_meta = apply_filters( 'us_mcp_post_type_meta_whitelist', $meta, $pt );
		$meta = array();
		foreach ( (array) $filtered_meta as $key => $spec ) {
			if (
				is_string( $key )
				AND $key !== ''
				AND is_array( $spec )
				AND isset( $spec['type'] )
				AND is_string( $spec['type'] )
			) {
				$meta[ $key ] = $spec;
			}
		}
	}

	return $cache[ $cache_key ] = $meta;
}

/**
 * Read a whitelisted meta key of a post in the format the agent writes.
 *
 * @param int $post_id
 * @param string $key
 * @param array $spec
 * @return mixed
 */
function us_mcp_get_meta_value( $post_id, $key, array $spec ) {
	// The stored meta of a Repeater is a row count, of Flexible Content a list of layout names
	if ( us_mcp_meta_is_composite( $spec ) AND isset( $spec['acf'] ) ) {
		// The export checks each post / media id of lists and rows: load them all at once
		_prime_post_caches( array_unique( array_filter( us_mcp_meta_stored_ids( $post_id, $key, $spec ) ) ), FALSE, FALSE );

		return us_mcp_export_meta_value( $post_id, $key, $spec );
	}
	$value = get_post_meta( $post_id, $key, TRUE );
	// Ids are integers, as in lists
	if ( in_array( us_arr_path( $spec, 'type' ), array( 'post', 'attachment' ), TRUE ) AND is_numeric( $value ) ) {
		$value = (int) $value;
	}

	return $value;
}

/**
 * Read an ACF list / link / group / rows field of a post in the format the agent writes.
 *
 * Values are the raw stored ones (list ids as integers). Rows are read straight from the
 * meta ACF stores them in ("{name}_{i}_{sub}"), not through acf_get_value(): outside
 * wp-admin ACF skips the disabled Flexible Content blocks, and writing the rows back
 * would delete them. Blocks of a layout removed from the field are skipped.
 *
 * @param int $post_id
 * @param string $name Meta key the value is stored under.
 * @param array $spec
 * @return mixed
 */
function us_mcp_export_meta_value( $post_id, $name, array $spec ) {
	$value = get_post_meta( $post_id, $name, TRUE );

	switch ( us_arr_path( $spec, 'type' ) ) {
		case 'list':
			$item_spec = (array) us_arr_path( $spec, 'item', array() );
			$items = array();
			foreach ( (array) $value as $item ) {
				// An emptied Checkbox is stored as ""
				if ( is_scalar( $item ) AND ( $item = us_mcp_export_meta_scalar( $item, $item_spec ) ) !== '' ) {
					$items[] = in_array( us_arr_path( $item_spec, 'type' ), array( 'post', 'attachment' ), TRUE ) ? (int) $item : (string) $item;
				}
			}

			return $items;

		case 'link':
			// A Link saved by old ACF versions may be a plain URL
			if ( is_string( $value ) AND $value !== '' ) {
				$value = array( 'url' => $value );
			}
			if ( ! is_array( $value ) OR empty( $value['url'] ) ) {
				return NULL;
			}

			return array(
				'url' => (string) $value['url'],
				'title' => (string) us_arr_path( $value, 'title', '' ),
				'target' => (string) us_arr_path( $value, 'target', '' ),
			);

		case 'group':
			return us_mcp_export_meta_sub_values( $post_id, $name . '_', (array) us_arr_path( $spec, 'sub_fields', array() ) );

		case 'rows':
			$out = array();
			foreach ( us_mcp_meta_stored_rows( $name, $value, $spec ) as $prefix => $sub_specs ) {
				$out[] = us_mcp_export_meta_sub_values( $post_id, $prefix, $sub_specs );
			}

			return $out;

		case 'layouts':
			$layout_meta = get_post_meta( $post_id, '_' . $name . '_layout_meta', TRUE );
			$rows = us_mcp_meta_stored_rows( $name, $value, $spec );
			$out = array();
			foreach ( (array) $value as $i => $layout ) {
				if ( ! isset( $rows["{$name}_{$i}_"] ) ) {
					continue;
				}
				$block = array( 'acf_fc_layout' => $layout );
				if ( in_array( $i, (array) us_arr_path( $layout_meta, 'disabled', array() ) ) ) {
					$block['acf_fc_layout_disabled'] = TRUE;
				}
				if ( $custom_label = (string) us_arr_path( $layout_meta, array( 'renamed', $i ), '' ) ) {
					$block['acf_fc_layout_custom_label'] = $custom_label;
				}
				$out[] = $block + us_mcp_export_meta_sub_values( $post_id, "{$name}_{$i}_", $rows["{$name}_{$i}_"] );
			}

			return $out;
	}

	return $value;
}

/**
 * Get the stored rows of a Repeater / Flexible Content / Group field: the meta key
 * prefix of each row with the specs of its sub fields. Blocks of a layout removed
 * from the field are left out.
 *
 * @param string $name Meta key the field is stored under.
 * @param mixed $value The stored meta of the field: a row count, a list of layout names, or anything for a Group.
 * @param array $spec
 * @return array Sub field specs keyed by the meta key prefix of each row, e.g. "team_2_".
 */
function us_mcp_meta_stored_rows( $name, $value, array $spec ) {
	$rows = array();
	switch ( us_arr_path( $spec, 'type' ) ) {
		case 'group':
			$rows[ $name . '_' ] = (array) us_arr_path( $spec, 'sub_fields', array() );
			break;
		case 'rows':
			for ( $i = 0; $i < (int) $value; $i++ ) {
				$rows["{$name}_{$i}_"] = (array) us_arr_path( $spec, 'sub_fields', array() );
			}
			break;
		case 'layouts':
			foreach ( (array) $value as $i => $layout ) {
				if ( is_string( $layout ) AND isset( $spec['layouts'][ $layout ] ) ) {
					$rows["{$name}_{$i}_"] = (array) us_arr_path( $spec, array( 'layouts', $layout, 'sub_fields' ), array() );
				}
			}
			break;
	}

	return $rows;
}

/**
 * Get the post / media ids stored in a field at any depth (lists, rows, blocks,
 * Groups), so the caller can load them at once before the export checks them
 * one by one.
 *
 * @param int $post_id
 * @param string $name Meta key the field is stored under.
 * @param array $spec
 * @return int[]
 */
function us_mcp_meta_stored_ids( $post_id, $name, array $spec ) {
	$type = us_arr_path( $spec, 'type' );
	$value = get_post_meta( $post_id, $name, TRUE );
	if ( in_array( $type, array( 'post', 'attachment' ), TRUE ) ) {
		return is_numeric( $value ) ? array( (int) $value ) : array();
	}
	if ( $type === 'list' ) {
		return in_array( us_arr_path( $spec, 'item.type' ), array( 'post', 'attachment' ), TRUE )
			? array_map( 'intval', array_filter( (array) $value, 'is_numeric' ) )
			: array();
	}

	$ids = array();
	foreach ( us_mcp_meta_stored_rows( $name, $value, $spec ) as $prefix => $sub_specs ) {
		foreach ( $sub_specs as $sub_name => $sub_spec ) {
			$ids = array_merge( $ids, us_mcp_meta_stored_ids( $post_id, $prefix . $sub_name, (array) $sub_spec ) );
		}
	}

	return $ids;
}

/**
 * Get the post / media ids of a meta input value at any depth (lists, rows,
 * blocks, Groups), so the caller can load them at once before
 * us_mcp_validate_meta_value() checks them one by one.
 *
 * @param mixed $value The input value, sub fields keyed by name.
 * @param array $spec
 * @return int[]
 */
function us_mcp_meta_input_ids( $value, array $spec ) {
	$type = us_arr_path( $spec, 'type' );
	if ( in_array( $type, array( 'post', 'attachment' ), TRUE ) ) {
		return ( is_int( $value ) OR ( is_string( $value ) AND ctype_digit( $value ) ) ) ? array( (int) $value ) : array();
	}
	if ( ! is_array( $value ) OR ! in_array( $type, array( 'list', 'group', 'rows', 'layouts' ), TRUE ) ) {
		return array();
	}

	$ids = array();
	if ( $type === 'list' ) {
		foreach ( $value as $item ) {
			$ids = array_merge( $ids, us_mcp_meta_input_ids( $item, (array) us_arr_path( $spec, 'item', array() ) ) );
		}

		return $ids;
	}
	// A Group value is a single row
	foreach ( ( $type === 'group' ) ? array( $value ) : $value as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		if ( $type === 'layouts' ) {
			$layout = us_arr_path( $row, 'acf_fc_layout' );
			$sub_specs = is_string( $layout ) ? (array) us_arr_path( $spec, array( 'layouts', $layout, 'sub_fields' ), array() ) : array();
		} else {
			$sub_specs = (array) us_arr_path( $spec, 'sub_fields', array() );
		}
		foreach ( $sub_specs as $sub_name => $sub_spec ) {
			if ( isset( $row[ $sub_name ] ) ) {
				$ids = array_merge( $ids, us_mcp_meta_input_ids( $row[ $sub_name ], (array) $sub_spec ) );
			}
		}
	}

	return $ids;
}

/**
 * Load at once the posts / media referenced by a meta input value, with their
 * meta (wp_attachment_is_image() reads the attached file) and the parents of
 * attachments (read_post of an attachment checks its parent).
 *
 * @param mixed $value
 * @param array $spec
 * @return void
 */
function us_mcp_prime_meta_input_ids( $value, array $spec ) {
	$ids = array_unique( array_filter( us_mcp_meta_input_ids( $value, $spec ) ) );
	if ( ! $ids ) {
		return;
	}
	_prime_post_caches( $ids, FALSE, TRUE );
	$parent_ids = array();
	foreach ( $ids as $id ) {
		// The cache, not get_post(): an id that does not exist would be queried again
		$post = wp_cache_get( $id, 'posts' );
		if ( $post AND ! empty( $post->post_parent ) ) {
			$parent_ids[] = (int) $post->post_parent;
		}
	}
	_prime_post_caches( array_unique( $parent_ids ), FALSE, FALSE );
}

/**
 * Read the sub field values of one row / block / Group, see us_mcp_export_meta_value().
 *
 * @param int $post_id
 * @param string $prefix Meta key prefix of the sub fields, e.g. "team_2_".
 * @param array $sub_specs Sub field specs keyed by name.
 * @return array
 */
function us_mcp_export_meta_sub_values( $post_id, $prefix, array $sub_specs ) {
	$out = array();
	foreach ( $sub_specs as $name => $sub_spec ) {
		$out[ $name ] = us_mcp_meta_is_composite( (array) $sub_spec )
			? us_mcp_export_meta_value( $post_id, $prefix . $name, (array) $sub_spec )
			: us_mcp_export_meta_scalar( get_post_meta( $post_id, $prefix . $name, TRUE ), (array) $sub_spec );
	}

	return $out;
}

/**
 * Get a stored scalar of rows / lists in the format the agent writes.
 *
 * Ids of deleted posts / media and values removed from the choices read as "",
 * as the ACF metabox drops them on the next save. Without that, writing the rows
 * back would fail on a value the agent did not touch. Ids are integers, other
 * values stay as stored, like single-value fields.
 *
 * @param mixed $value
 * @param array $spec
 * @return mixed
 */
function us_mcp_export_meta_scalar( $value, array $spec ) {
	$type = us_arr_path( $spec, 'type' );
	// An array is left from a former multi-value type of the field
	if ( $value === '' OR ! is_scalar( $value ) ) {
		return '';
	}
	if ( in_array( $type, array( 'post', 'attachment' ), TRUE ) ) {
		return get_post_type( (int) $value ) ? (int) $value : '';
	}
	if ( $type === 'enum' AND ! in_array( (string) $value, (array) us_arr_path( $spec, 'values', array() ), TRUE ) ) {
		return '';
	}

	return $value;
}

/**
 * Storage formats of the date-like meta types (the formats ACF stores), shared
 * by the validator and the `format` hint of list-post-types.
 *
 * @return array<string, string> Meta type => date() format.
 */
function us_mcp_meta_date_formats() {
	return array(
		'date' => 'Ymd',
		'datetime' => 'Y-m-d H:i:s',
		'time' => 'H:i:s',
	);
}

/**
 * Validate one supplied meta value against its per-key spec from the registry.
 * Returns the normalised value ready for update_post_meta(), or a WP_Error.
 *
 * Per-type semantics:
 *   string  — coerce any scalar to string (booleans become '1' / '').
 *   int     — accept int or numeric string; reject bool (FALSE != 0 here).
 *             An empty string normalises to '' and, like null, is treated as
 *             "clear" (delete the key) at apply time — see
 *             us_mcp_write_meta_values(). There is no way to persist a literal
 *             empty value: '' ALWAYS means clear, for every meta type.
 *   bool_01 — accept TRUE/FALSE/0/1/'0'/'1'/''; normalise to int 0 or 1, the
 *             same shape the admin `switch` field stores.
 *   number  — int or float (or a numeric string), optionally bounded by
 *             `spec['min']` / `spec['max']`; '' clears, as for int.
 *   enum    — coerce to string and require it appears in `spec['values']`.
 *   color   — delegate to us_mcp_palette_check_color() — same syntaxes that
 *             work in upsolution-set-palette work here. `spec['gradient']`
 *             gates gradient acceptance. With `spec['plain']` (ACF color
 *             picker) only a hex value is accepted, plus rgb() / rgba() when
 *             `spec['alpha']` is set — no gradients, no palette tokens.
 *   date / datetime / time — a string in the exact format Ymd /
 *             Y-m-d H:i:s / H:i:s (the formats ACF stores).
 *   attachment / post / user — the id of an existing object; for attachment
 *             `spec['image']` requires an image, for post `spec['post_types']`
 *             restricts the type, for user `spec['roles']` the role.
 *   list    — an array of values, each checked against `spec['item']`, at most
 *             `spec['max']` of them; empty items are skipped, an empty array clears.
 *   link    — an object {url, title, target} (the ACF Link storage format).
 *   group   — an object {sub field name: value}, see us_mcp_validate_meta_sub_values().
 *   rows / layouts — Repeater rows / Flexible Content blocks, see
 *             us_mcp_validate_meta_rows().
 *   The `min` count of list / rows is checked by ACF, on publish only.
 *
 * Nested values report the path to the bad value in place of the key, e.g.
 * `Meta "team" → row 3 → "photo" must be …`.
 *
 * A missing spec falls back to a generic scalar accept — safer than rejecting,
 * since the registry is the single source of truth.
 *
 * @param string $key
 * @param mixed $value
 * @param array $spec {type: …, values?: …, gradient?: …}
 * @return string|int|float|array|WP_Error
 */
function us_mcp_validate_meta_value( $key, $value, array $spec ) {
	$type = isset( $spec['type'] ) ? (string) $spec['type'] : 'string';

	$is_array = is_array( $value );
	if ( $is_array !== us_mcp_meta_is_composite( $spec ) ) {
		return new WP_Error(
			'us_mcp_posts_bad_meta',
			sprintf( 'Meta "%s" must be %s.', $key, $is_array ? 'a scalar or null' : 'an array / object or null, see `meta_fields`' ),
			array( 'status' => 400 )
		);
	}
	switch ( $type ) {
		case 'list':
			if ( ! wp_is_numeric_array( $value ) ) {
				return new WP_Error( 'us_mcp_posts_bad_meta', sprintf( 'Meta "%s" must be an array of values.', $key ), array( 'status' => 400 ) );
			}
			$items = array();
			foreach ( array_values( $value ) as $i => $item ) {
				if ( $item === NULL OR $item === '' ) {
					continue;
				}
				$item = us_mcp_validate_meta_value( sprintf( '%s" → item "%d', $key, $i + 1 ), $item, (array) us_arr_path( $spec, 'item', array() ) );
				if ( is_wp_error( $item ) ) {
					return $item;
				}
				$items[] = $item;
			}
			$items = array_values( array_unique( $items, SORT_REGULAR ) );
			$max_error = us_mcp_validate_meta_max( $key, count( $items ), $spec, 'items' );

			return $max_error ?: ( $items ?: '' );

		case 'link':
			$unknown = array_diff( array_keys( $value ), array( 'url', 'title', 'target' ) );
			$url = us_arr_path( $value, 'url', '' );
			$title = us_arr_path( $value, 'title', '' );
			$target = us_arr_path( $value, 'target', '' );
			if (
				$unknown
				OR ! is_string( $url ) OR trim( $url ) === ''
				OR ! is_string( $title )
				OR ! in_array( $target, array( '', '_blank' ), TRUE )
			) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be an object {url, title, target}: url is a non-empty string, title a string, target "" or "_blank".', $key ),
					array( 'status' => 400 )
				);
			}

			// The ACF Link storage format
			return array(
				'title' => $title,
				'url' => trim( $url ),
				'target' => $target,
			);

		case 'group':
			return us_mcp_validate_meta_sub_values( $key . '"', $value, (array) us_arr_path( $spec, 'sub_fields', array() ) );

		case 'rows':
		case 'layouts':
			return us_mcp_validate_meta_rows( $key, $value, $spec );

		case 'number':
			if ( $value === '' ) {
				return '';
			}
			if ( is_bool( $value ) OR ! is_numeric( $value ) ) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be a number (got %s).', $key, var_export( $value, TRUE ) ),
					array( 'status' => 400 )
				);
			}
			$number = $value + 0;
			if (
				( isset( $spec['min'] ) AND is_numeric( $spec['min'] ) AND $number < $spec['min'] )
				OR ( isset( $spec['max'] ) AND is_numeric( $spec['max'] ) AND $number > $spec['max'] )
			) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf(
						'Meta "%s" must be within %s..%s (got %s).',
						$key,
						isset( $spec['min'] ) ? $spec['min'] : '-∞',
						isset( $spec['max'] ) ? $spec['max'] : '∞',
						$number
					),
					array( 'status' => 400 )
				);
			}

			return $number;

		case 'date':
		case 'datetime':
		case 'time':
			if ( $value === '' ) {
				return '';
			}
			$formats = us_mcp_meta_date_formats();
			$raw = is_bool( $value ) ? '' : (string) $value;
			$parsed = DateTime::createFromFormat( '!' . $formats[ $type ], $raw );
			if ( ! $parsed OR $parsed->format( $formats[ $type ] ) !== $raw ) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be a %s in the format "%s" (got %s).', $key, $type, $formats[ $type ], var_export( $value, TRUE ) ),
					array( 'status' => 400 )
				);
			}

			return $raw;

		case 'attachment':
		case 'post':
		case 'user':
			if ( $value === '' ) {
				return '';
			}
			$id = ( is_int( $value ) OR ( is_string( $value ) AND ctype_digit( $value ) ) ) ? (int) $value : 0;
			if ( $type === 'user' ) {
				$user = $id ? get_userdata( $id ) : FALSE;
				$exists = (
					$user
					AND (
						empty( $spec['roles'] )
						OR array_intersect( (array) $spec['roles'], (array) $user->roles )
					)
				);
			} else {
				$post_type = $id ? get_post_type( $id ) : FALSE;
				// read_post as for featured_image_id: an agent must not be able to
				// point a field at someone else's draft / private record.
				$exists = ( $post_type AND current_user_can( 'read_post', $id ) );
				if ( $type === 'attachment' ) {
					$exists = (
						$exists
						AND $post_type === 'attachment'
						AND ( empty( $spec['image'] ) OR wp_attachment_is_image( $id ) )
					);
				} else {
					$exists = (
						$exists
						AND $post_type !== 'attachment'
						AND (
							empty( $spec['post_types'] )
							OR in_array( $post_type, (array) $spec['post_types'], TRUE )
						)
					);
				}
			}
			if ( ! $exists ) {
				$kind = ( $type === 'attachment' AND ! empty( $spec['image'] ) ) ? 'image attachment' : $type;
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be the id of an existing %s you can access (got %s).', $key, $kind, var_export( $value, TRUE ) ),
					array( 'status' => 400 )
				);
			}

			return $id;

		case 'int':
			if ( $value === '' ) {
				return '';
			}
			if ( is_bool( $value ) OR ! is_numeric( $value ) ) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be an integer (got %s).', $key, is_scalar( $value ) ? var_export( $value, TRUE ) : gettype( $value ) ),
					array( 'status' => 400 )
				);
			}

			return (int) $value;

		case 'bool_01':
			if ( $value === '' OR $value === FALSE OR $value === 0 OR $value === '0' ) {
				return 0;
			}
			if ( $value === TRUE OR $value === 1 OR $value === '1' ) {
				return 1;
			}

			return new WP_Error(
				'us_mcp_posts_bad_meta',
				sprintf( 'Meta "%s" must be a boolean / 0 / 1 (got %s).', $key, var_export( $value, TRUE ) ),
				array( 'status' => 400 )
			);

		case 'enum':
			$values = isset( $spec['values'] ) ? (array) $spec['values'] : array();
			$coerced = is_bool( $value ) ? ( $value ? '1' : '' ) : (string) $value;
			if ( ! in_array( $coerced, $values, TRUE ) ) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be one of: %s (got "%s").', $key, implode( ', ', array_map( function ( $v ) {
						return $v === '' ? '""' : $v;
					}, $values ) ), $coerced ),
					array( 'status' => 400 )
				);
			}

			return $coerced;

		case 'color':
			// Plain CSS color for pickers outside the theme (ACF): they understand
			// neither gradients nor the palette `_slug` tokens.
			if ( ! empty( $spec['plain'] ) ) {
				$color = is_string( $value ) ? trim( $value ) : '';
				if ( $value === '' ) {
					return '';
				}
				$rgb = '\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*';
				if (
					preg_match( '/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i', $color )
					OR (
						! empty( $spec['alpha'] )
						AND preg_match( '/^rgba?\(' . $rgb . '(?:,\s*(?:0|1|0?\.\d+|1\.0+)\s*)?\)$/i', $color )
					)
				) {
					return $color;
				}

				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf(
						'Meta "%s" must be a hex color like #1a2b3c%s (got %s).',
						$key,
						! empty( $spec['alpha'] ) ? ' or rgba(26,43,60,0.5)' : '',
						var_export( $value, TRUE )
					),
					array( 'status' => 400 )
				);
			}

			$allows_gradient = ! empty( $spec['gradient'] );
			if ( ! function_exists( 'us_mcp_palette_check_color' ) ) {
				// Defensive — palette validator ships in the same package and
				// is required by the bootstrap. Without it, accept scalars.
				return is_scalar( $value ) ? (string) $value : new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s" must be a color string.', $key ),
					array( 'status' => 400 )
				);
			}

			return us_mcp_palette_check_color( $value, $allows_gradient, $key );

		case 'string':
		default:
			// Booleans coerce to '1' / '' — same shape admin switch fields use.
			if ( is_bool( $value ) ) {
				return $value ? '1' : '';
			}

			return (string) $value;
	}
}

/**
 * Check if a meta value is missing for the "required" check: NULL, "" or an empty
 * array (0 is a value, except for an unchecked True / False), a Link without a URL,
 * or a Group with a missing sub field value, as ACF requires every sub field of a
 * required Group shown in the form.
 *
 * @param mixed $value The normalised value (a Group keyed by sub field keys) or the stored one (keyed by names).
 * @param array $spec
 * @return bool
 */
function us_mcp_meta_is_missing( $value, array $spec ) {
	if ( $value === NULL OR $value === '' OR $value === array() ) {
		return TRUE;
	}
	$type = us_arr_path( $spec, 'type' );
	// A required True / False must be checked, as in ACF
	if ( $type === 'bool_01' ) {
		return empty( $value );
	}
	if ( $type === 'link' ) {
		return empty( $value['url'] );
	}
	if ( $type === 'group' AND is_array( $value ) ) {
		foreach ( (array) us_arr_path( $spec, 'sub_fields', array() ) as $name => $sub_spec ) {
			$sub_key = us_arr_path( $sub_spec, 'acf', $name );
			$sub_value = array_key_exists( $sub_key, $value ) ? $value[ $sub_key ] : us_arr_path( $value, $name );
			// A sub field with Conditional Logic is required only while shown
			if ( empty( $sub_spec['conditional'] ) AND us_mcp_meta_is_missing( $sub_value, (array) $sub_spec ) ) {
				return TRUE;
			}
		}
	}

	return FALSE;
}

/**
 * Check if a meta spec holds an array / object value rather than a scalar.
 *
 * @param array $spec
 * @return bool
 */
function us_mcp_meta_is_composite( array $spec ) {
	return in_array( us_arr_path( $spec, 'type' ), array( 'list', 'link', 'group', 'rows', 'layouts' ), TRUE );
}

/**
 * Check the count of list items / rows against `max` of the spec.
 *
 * ACF checks it only in the browser. `min` is checked by ACF on the server, on
 * publish only, see us_acf_mcp_validate_value().
 *
 * @param string $key Meta key or path.
 * @param int $count
 * @param array $spec
 * @param string $noun "items", "rows" or "blocks".
 * @return WP_Error|null
 */
function us_mcp_validate_meta_max( $key, $count, array $spec, $noun ) {
	$max = (int) us_arr_path( $spec, 'max', 0 );
	if ( $max AND $count > $max ) {
		return new WP_Error(
			'us_mcp_posts_bad_meta',
			sprintf( 'Meta "%s" must have at most %d %s (got %d).', $key, $max, $noun, $count ),
			array( 'status' => 400 )
		);
	}

	return NULL;
}

/**
 * Empty value stored for a cleared field, as the ACF metabox does: 0 for True / False,
 * and for a Group its emptied sub fields (ACF ignores a Group value that is not an array).
 *
 * @param array $spec
 * @return string|int|array
 */
function us_mcp_meta_empty_value( array $spec ) {
	$type = us_arr_path( $spec, 'type' );
	if ( $type === 'bool_01' ) {
		return 0;
	}
	if ( $type === 'group' ) {
		$value = array();
		foreach ( (array) us_arr_path( $spec, 'sub_fields', array() ) as $name => $sub_spec ) {
			$value[ us_arr_path( $sub_spec, 'acf', $name ) ] = us_mcp_meta_empty_value( (array) $sub_spec );
		}

		return $value;
	}

	return '';
}

/**
 * Validate Repeater rows (spec type "rows") or Flexible Content blocks (type "layouts").
 *
 * Each row is an object {sub field name: value}. A block also has "acf_fc_layout"
 * with the layout name, and optionally "acf_fc_layout_disabled" (the block is
 * hidden on the site) and "acf_fc_layout_custom_label" (its title in the editor),
 * which ACF reads from the written value.
 *
 * @param string $key Meta key or path.
 * @param array $value
 * @param array $spec
 * @return array|WP_Error
 */
function us_mcp_validate_meta_rows( $key, array $value, array $spec ) {
	$is_layouts = ( $spec['type'] === 'layouts' );
	$noun = $is_layouts ? 'block' : 'row';
	if ( ! wp_is_numeric_array( $value ) ) {
		return new WP_Error( 'us_mcp_posts_bad_meta', sprintf( 'Meta "%s" must be an array of %s objects.', $key, $noun ), array( 'status' => 400 ) );
	}

	$layouts = (array) us_arr_path( $spec, 'layouts', array() );
	// Counts of enabled rows: '' for all of them, then per layout (ACF does not count disabled blocks)
	$counts = array( '' => 0 );
	$out = array();
	foreach ( array_values( $value ) as $i => $row ) {
		// Goes after the opening quote of `Meta "%s"`, see us_mcp_validate_meta_value()
		$path = sprintf( '%s" → %s %d', $key, $noun, $i + 1 );
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'us_mcp_posts_bad_meta', sprintf( 'Meta "%s must be an object.', $path ), array( 'status' => 400 ) );
		}
		$out_row = array();

		if ( $is_layouts ) {
			$layout = us_arr_path( $row, 'acf_fc_layout' );
			if ( ! is_string( $layout ) OR ! isset( $layouts[ $layout ] ) ) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s must have "acf_fc_layout" set to one of: %s.', $path, implode( ', ', array_keys( $layouts ) ) ),
					array( 'status' => 400 )
				);
			}
			$out_row['acf_fc_layout'] = $layout;

			$disabled = us_mcp_validate_meta_value( $path . ' → "acf_fc_layout_disabled', us_arr_path( $row, 'acf_fc_layout_disabled', 0 ), array( 'type' => 'bool_01' ) );
			$custom_label = us_arr_path( $row, 'acf_fc_layout_custom_label', '' );
			if ( is_wp_error( $disabled ) ) {
				return $disabled;
			}
			if ( ! is_string( $custom_label ) ) {
				return new WP_Error( 'us_mcp_posts_bad_meta', sprintf( 'Meta "%s → "acf_fc_layout_custom_label" must be a string.', $path ), array( 'status' => 400 ) );
			}
			// Older versions save such a block as a regular visible one
			if (
				( $disabled OR trim( $custom_label ) !== '' )
				AND defined( 'ACF_VERSION' )
				AND version_compare( ACF_VERSION, '6.5', '<' )
			) {
				return new WP_Error(
					'us_mcp_posts_bad_meta',
					sprintf( 'Meta "%s: "acf_fc_layout_disabled" and "acf_fc_layout_custom_label" need ACF PRO 6.5 or later.', $path ),
					array( 'status' => 400 )
				);
			}
			if ( $disabled ) {
				$out_row['acf_fc_layout_disabled'] = 1;
			} else {
				$counts['']++;
				$counts[ $layout ] = us_arr_path( $counts, $layout, 0 ) + 1;
			}
			if ( trim( $custom_label ) !== '' ) {
				$out_row['acf_fc_layout_custom_label'] = trim( $custom_label );
			}
			unset( $row['acf_fc_layout'], $row['acf_fc_layout_disabled'], $row['acf_fc_layout_custom_label'] );
			$sub_specs = (array) us_arr_path( $layouts, array( $layout, 'sub_fields' ), array() );
		} else {
			$counts['']++;
			$sub_specs = (array) us_arr_path( $spec, 'sub_fields', array() );
		}

		$sub_values = us_mcp_validate_meta_sub_values( $path, $row, $sub_specs );
		if ( is_wp_error( $sub_values ) ) {
			return $sub_values;
		}
		$out[] = $out_row + $sub_values;
	}

	$max_error = us_mcp_validate_meta_max( $key, $counts[''], $spec, $noun . 's' );
	foreach ( $layouts as $name => $layout ) {
		if ( ! $max_error ) {
			$max_error = us_mcp_validate_meta_max( sprintf( '%s" → layout "%s', $key, $name ), us_arr_path( $counts, $name, 0 ), $layout, 'blocks' );
		}
	}

	return $max_error ?: $out;
}

/**
 * Validate the sub field values of one row / block / Group object.
 *
 * Sub fields take the same formats as top-level keys, nested rows included. The
 * result addresses sub fields by their ACF field key (ACF validates rows only in
 * that form) and holds every sub field of the spec: a missing one gets the empty
 * value, because ACF keeps the old value of a sub field absent from a written
 * row, and writing a field replaces it whole.
 *
 * @param string $path Path of the object, after the opening quote of `Meta "%s"`:
 *                     'team" → row 3' or, for a Group, 'hero"'.
 * @param array $value
 * @param array $sub_specs Sub field specs keyed by name.
 * @return array|WP_Error
 */
function us_mcp_validate_meta_sub_values( $path, array $value, array $sub_specs ) {
	if ( $unknown = array_diff( array_keys( $value ), array_keys( $sub_specs ) ) ) {
		return new WP_Error(
			'us_mcp_posts_bad_meta',
			sprintf( 'Meta "%s has unknown sub field "%s". Allowed: %s.', $path, reset( $unknown ), $sub_specs ? implode( ', ', array_keys( $sub_specs ) ) : '(none)' ),
			array( 'status' => 400 )
		);
	}

	$out = array();
	foreach ( $sub_specs as $name => $sub_spec ) {
		$sub_spec = (array) $sub_spec;
		$sub_value = us_arr_path( $value, $name );
		if (
			$sub_value === NULL
			OR $sub_value === ''
			OR ( $sub_value === array() AND us_mcp_meta_is_composite( $sub_spec ) )
		) {
			$sub_value = us_mcp_meta_empty_value( $sub_spec );
		} else {
			$sub_value = us_mcp_validate_meta_value( $path . ' → "' . $name, $sub_value, $sub_spec );
		}
		if ( is_wp_error( $sub_value ) ) {
			return $sub_value;
		}
		$out[ us_arr_path( $sub_spec, 'acf', $name ) ] = $sub_value;
	}

	return $out;
}

/**
 * Validate the optional `meta` input against the type's whitelist.
 *
 * Keys flagged `required` in their spec (required ACF fields) must hold a value
 * once the post is published — the supplied one, or the stored one on update.
 * Like ACF itself, a draft / pending / scheduled post may leave them empty.
 *
 * @param array $input
 * @param string $post_type
 * @param bool $publishing Whether the post is published after the write.
 * @param int $post_id The post being updated, 0 on create.
 * @return array|null|WP_Error
 */
function us_mcp_validate_meta_input( array $input, $post_type, $publishing = FALSE, $post_id = 0 ) {
	$allowed_specs = us_mcp_post_type_meta_whitelist( $post_type );
	$out = us_mcp_validate_meta_values( $input, $allowed_specs, $publishing );
	if ( is_wp_error( $out ) OR ! $publishing ) {
		return $out;
	}

	foreach ( $allowed_specs as $key => $spec ) {
		if ( empty( $spec['required'] ) ) {
			continue;
		}
		if ( is_array( $out ) AND array_key_exists( $key, $out ) ) {
			$value = $out[ $key ];
		} else {
			$value = $post_id ? us_mcp_get_meta_value( $post_id, $key, $spec ) : '';
		}
		// Like ACF, disabled Flexible Content blocks do not count
		if ( us_arr_path( $spec, 'type' ) === 'layouts' AND is_array( $value ) ) {
			$value = array_filter( $value, function ( $block ) {
				return empty( $block['acf_fc_layout_disabled'] );
			} );
		}
		if ( us_mcp_meta_is_missing( $value, $spec ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_meta',
				sprintf( 'Meta "%s" is required to publish the post: pass a value in `meta`, or save the post as a draft.', $key ),
				array( 'status' => 400 )
			);
		}
	}

	return $out;
}

/**
 * Validate the values of the `meta` input against the whitelist specs.
 *
 * @param array $input
 * @param array $allowed_specs Result of us_mcp_post_type_meta_whitelist().
 * @param bool $publishing Whether the post is published after the write.
 * @return array|null|WP_Error NULL when `meta` is not supplied.
 */
function us_mcp_validate_meta_values( array $input, array $allowed_specs, $publishing = FALSE ) {
	if ( ! array_key_exists( 'meta', $input ) ) {
		return NULL;
	}
	$meta = $input['meta'];
	if ( ! is_array( $meta ) ) {
		return new WP_Error( 'us_mcp_posts_bad_meta', 'meta must be an object of {key: value}.', array( 'status' => 400 ) );
	}
	$out = array();
	foreach ( $meta as $key => $value ) {
		if ( ! array_key_exists( $key, $allowed_specs ) ) {
			return new WP_Error(
				'us_mcp_posts_bad_meta',
				sprintf( 'Meta key "%s" is not on the whitelist for this post type. Allowed: %s.', $key, $allowed_specs ? implode( ', ', array_keys( $allowed_specs ) ) : '(none)' ),
				array( 'status' => 400 )
			);
		}
		$spec = $allowed_specs[ $key ];
		/**
		 * NULL and "" (and an empty array of a list / rows field) are the explicit
		 * "clear" intent for every type — let the apply step delete the meta key
		 * without funnelling them through value validation, where per-type
		 * validators would reject them (or, for bool_01, turn "" into a stored 0).
		 */
		if (
			$value === NULL
			OR $value === ''
			OR ( $value === array() AND us_mcp_meta_is_composite( $spec ) )
		) {
			$normalised = NULL;
		} else {
			us_mcp_prime_meta_input_ids( $value, $spec );
			$normalised = us_mcp_validate_meta_value( $key, $value, $spec );
			if ( is_wp_error( $normalised ) ) {
				return $normalised;
			}
			// An array of empty items clears as well
			if ( $normalised === '' ) {
				$normalised = NULL;
			}
		}
		/**
		 * ACF fields also go through the field's own validation (email / URL
		 * format, text length, number range, acf/validate_value hooks), as they
		 * would when saved from the ACF metabox. Required of the field itself is
		 * checked separately — see us_mcp_validate_meta_input().
		 */
		if ( isset( $spec['acf'] ) AND function_exists( 'us_acf_mcp_validate_value' ) ) {
			$acf_valid = us_acf_mcp_validate_value( $key, $spec['acf'], $normalised, $publishing );
			if ( is_wp_error( $acf_valid ) ) {
				return $acf_valid;
			}
		}
		$out[ $key ] = $normalised;
	}

	return $out;
}

/**
 * Write validated meta values to a post.
 *
 * For EVERY whitelisted key, an empty string ALWAYS means "clear", identical to
 * null: the stored meta is deleted and the post reverts to its Theme Options /
 * default for that setting. This surface intentionally can NOT persist a literal
 * empty-string meta value; it isn't a loss, because a deleted key and a stored ''
 * read back identically through get_post_meta() (including the enum keys whose
 * value set contains '', e.g. us_header_sticky_pos). Non-empty scalars (including
 * the string "0", which is the "none/hide" marker for the *_id keys) are written
 * verbatim. ACF fields are the exception: they store an empty value instead, see
 * us_acf_mcp_write_value().
 *
 * @param WP_Post $post
 * @param array $meta Result of us_mcp_validate_meta_input().
 * @return void
 */
function us_mcp_write_meta_values( WP_Post $post, array $meta ) {
	$whitelist = us_mcp_post_type_meta_whitelist( $post->post_type );
	foreach ( $meta as $key => $value ) {
		if (
			isset( $whitelist[ $key ]['acf'] )
			AND function_exists( 'us_acf_mcp_write_value' )
			AND us_acf_mcp_write_value( $post->ID, $key, $whitelist[ $key ], $value )
		) {
			continue;
		}
		if ( $value === NULL OR $value === '' ) {
			delete_post_meta( $post->ID, $key );
		} else {
			// update_metadata() unslashes the value
			update_post_meta( $post->ID, $key, wp_slash( $value ) );
		}
	}
}

/**
 * Get the numeric `min` / `max` of a spec or a Flexible Content layout spec.
 *
 * @param array $spec
 * @return array
 */
function us_mcp_meta_field_bounds( array $spec ) {
	$bounds = array();
	foreach ( array( 'min', 'max' ) as $bound ) {
		if ( isset( $spec[ $bound ] ) AND is_numeric( $spec[ $bound ] ) ) {
			$bounds[ $bound ] = $spec[ $bound ] + 0;
		}
	}

	return $bounds;
}

/**
 * Describe the value format of a whitelisted meta key for list-post-types;
 * sub fields of rows / layouts are described the same way.
 *
 * @param string $key Meta key, or sub field name.
 * @param array $spec
 * @return array
 */
function us_mcp_meta_field_info( $key, array $spec ) {
	$type = (string) us_arr_path( $spec, 'type', 'string' );
	$field = array(
		'key' => (string) $key,
		'type' => $type,
	);
	// A list takes the values / post types of its items
	$source = $spec;
	if ( $type === 'list' ) {
		$source = (array) us_arr_path( $spec, 'item', array() );
		$field['item_type'] = (string) us_arr_path( $source, 'type', 'string' );
	}
	if ( isset( $source['values'] ) AND us_arr_path( $source, 'type' ) === 'enum' ) {
		$field['values'] = array_values( array_map( 'strval', (array) $source['values'] ) );
	}
	if ( ! empty( $source['post_types'] ) ) {
		$field['post_types'] = array_values( array_map( 'strval', (array) $source['post_types'] ) );
	}
	$field += us_mcp_meta_field_bounds( $spec );
	$date_formats = us_mcp_meta_date_formats();
	if ( isset( $date_formats[ $type ] ) ) {
		$field['format'] = $date_formats[ $type ];
	} elseif ( $type === 'color' AND ! empty( $spec['plain'] ) ) {
		$field['format'] = empty( $spec['alpha'] ) ? 'hex' : 'hex or rgba()';
	} elseif ( $type === 'color' ) {
		$field['format'] = empty( $spec['gradient'] ) ? 'palette' : 'palette or linear-gradient()';
	}
	if ( ! empty( $spec['required'] ) ) {
		$field['required'] = TRUE;
	}
	foreach ( array( 'label', 'description' ) as $text ) {
		if ( isset( $spec[ $text ] ) AND is_string( $spec[ $text ] ) AND $spec[ $text ] !== '' ) {
			$field[ $text ] = $spec[ $text ];
		}
	}
	if ( $type === 'rows' OR $type === 'group' ) {
		$field['sub_fields'] = array();
		foreach ( (array) us_arr_path( $spec, 'sub_fields', array() ) as $name => $sub_spec ) {
			$field['sub_fields'][] = us_mcp_meta_field_info( $name, (array) $sub_spec );
		}
	}
	if ( $type === 'layouts' ) {
		$field['layouts'] = array();
		foreach ( (array) us_arr_path( $spec, 'layouts', array() ) as $name => $layout ) {
			$layout_info = array(
				'name' => (string) $name,
				'label' => (string) us_arr_path( $layout, 'label', '' ),
			) + us_mcp_meta_field_bounds( (array) $layout );
			$layout_info['sub_fields'] = array();
			foreach ( (array) us_arr_path( $layout, 'sub_fields', array() ) as $sub_name => $sub_spec ) {
				$layout_info['sub_fields'][] = us_mcp_meta_field_info( $sub_name, (array) $sub_spec );
			}
			$field['layouts'][] = $layout_info;
		}
	}

	return $field;
}
