<?php
/**
 * UpSolution MCP — data for the "connect your AI client" field.
 *
 * Arrays only: the markup lives in usof/templates/fields/mcp_connect.php. The
 * client registry is declarative, so adding a client is a data change.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * US_CORE_DIR, not US_CORE_MCP_DIR: reachable before mcp/bootstrap.php defines
 * the constant. For the same reason nothing here may assume the tables exist.
 */
require_once US_CORE_DIR . 'mcp/oauth/oauth.php';
us_mcp_oauth_load();

/**
 * On a local-dev host the snippets use plain http: the certificate is
 * self-signed and node-based MCP clients refuse it.
 *
 * @return array url, is_local, snippet_url, server_name.
 */
function us_mcp_connect_endpoint_info() {
	static $info = NULL;

	if ( $info !== NULL ) {
		return $info;
	}

	$url = rest_url( 'upsolution/v1/mcp' );
	$parts = (array) parse_url( $url );
	$host = strtolower( (string) ( $parts['host'] ?? '' ) );
	$scheme = (string) ( $parts['scheme'] ?? 'https' );
	$is_local = us_mcp_oauth_is_local_host( $host );

	// Scheme swap only: the path may be empty and the endpoint may live in the
	// query string (?rest_route=…) on a Plain-permalink install, and the https
	// port never carries over to http.
	$snippet_url = ( $is_local AND $scheme === 'https' )
		? 'http://' . $host . ( $parts['path'] ?? '' )
		. ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' )
		: $url;

	// Server key for the client's config file.
	$server_name = preg_replace( array( '/^www\./', '/[^a-z0-9]+/' ), array( '', '-' ), $host );
	$server_name = trim( (string) $server_name, '-' );
	if ( strlen( $server_name ) > 24 ) {
		$server_name = rtrim( substr( $server_name, 0, 24 ), '-' );
	}
	if ( $server_name === '' ) {
		$server_name = 'us-site';
	}

	$info = array(
		'url' => $url,
		'is_local' => $is_local,
		'snippet_url' => $snippet_url,
		'server_name' => $server_name,
	);

	return $info;
}

/**
 * Whether the one-click flow can work at all.
 *
 * Plain permalinks are fatal, not cosmetic: WP_Rewrite::mod_rewrite_rules()
 * returns an empty ruleset when no permalink structure is set, so Apache writes
 * no rewrite block and 404s /.well-known/… and /us-mcp-oauth/authorize before
 * PHP is reached. Discovery and the consent screen never run.
 *
 * @return bool
 */
function us_mcp_connect_oauth_ready() {
	return (
		/** This filter is documented in mcp/oauth/oauth.php */
		apply_filters( 'us_mcp_oauth_enabled', TRUE )
		AND us_mcp_oauth_is_secure()
		AND (string) get_option( 'permalink_structure', '' ) !== ''
	);
}

/**
 * The client registry.
 *
 * Keys the template understands, all optional except label and auth:
 *
 *   label     string  Picker caption.
 *   auth      string  'oauth' (URL is enough) or 'apppw' (manual path).
 *   copy      array   label + value for a copy-to-clipboard row.
 *   deeplink  array   label + url + scheme for a one-click install button.
 *   steps     string[] Numbered instructions. Printed raw by the template, so
 *                     some carry a <code> tag; anything interpolated into them
 *                     must be escaped at the point it is inserted.
 *   notes     string[] Plain-text paragraphs shown under the steps.
 *   snippet   string  Config fragment shown in a <pre>.
 *
 * Nothing on this screen is translatable. It is a walkthrough of other vendors'
 * English interfaces — "Settings → Connectors", "Streamable HTTP" — which a
 * localisation would have to keep verbatim anyway, and which every redesign on
 * their side invalidates in all languages at once. Only values taken from
 * WordPress core via us_translate() carry a translation, for free.
 *
 * @return array
 */
function us_mcp_connect_clients() {
	$info = us_mcp_connect_endpoint_info();

	$cursor_config = wp_json_encode( array( 'url' => $info['url'] ), JSON_UNESCAPED_SLASHES );
	$vscode_config = wp_json_encode(
		array( 'name' => $info['server_name'], 'type' => 'http', 'url' => $info['url'] ),
		JSON_UNESCAPED_SLASHES
	);

	return array(
		'claude' => array(
			'label' => 'Claude — web & desktop',
			'auth' => 'oauth',
			'copy' => array( 'label' => 'MCP server URL', 'value' => $info['url'] ),
			'steps' => array(
				'In Claude, open Settings → Connectors.',
				'Click "Add custom connector" and paste the URL above.',
				'Click Connect and approve the connection on this site.',
			),
		),

		'claude-code' => array(
			'label' => 'Claude Code — CLI',
			'auth' => 'oauth',
			'copy' => array(
				'label' => 'Run this in your terminal',
				'value' => sprintf( 'claude mcp add --transport http %s %s', $info['server_name'], $info['url'] ),
			),
			'steps' => array(
				'Run the command above in any project directory.',
				sprintf(
					'Start Claude Code and run %s, then choose Authenticate.',
					'<code>/mcp</code>'
				),
				'Approve the connection in the browser window that opens.',
			),
		),

		'chatgpt' => array(
			'label' => 'ChatGPT Web',
			'auth' => 'oauth',
			'copy' => array( 'label' => 'MCP server URL', 'value' => $info['url'] ),
			'steps' => array(
				'In ChatGPT, open Settings → Plugins and turn on Developer Mode.',
				'Go to the Plugins page and click "+" to add a plugin.',
				'Paste the URL above and choose OAuth when asked how to authenticate.',
				'Approve the connection on this site.',
			),
			'notes' => array(
				'Developer Mode is not available on every ChatGPT plan.',
			),
		),

		'codex' => array(
			'label' => 'ChatGPT / Codex — desktop',
			'auth' => 'oauth',
			'copy' => array( 'label' => 'MCP server URL', 'value' => $info['url'] ),
			'steps' => array(
				'In the ChatGPT desktop app, open Settings and select Plugins.',
				'Click Add and pick "Add MCP Server".',
				'Enter any name, choose Streamable HTTP, and paste the URL above.',
				'Save the server, then click Authenticate and approve the connection on this site.',
			),
			'notes' => array(
				'The ChatGPT desktop app, Codex CLI and the IDE extension share one configuration file, so setting up any of them connects the other two.',
			),
		),

		'codex-cli' => array(
			'label' => 'Codex — CLI',
			'auth' => 'oauth',
			'copy' => array(
				'label' => 'Run this in your terminal',
				'value' => sprintf( 'codex mcp add %s --url %s', $info['server_name'], $info['url'] ),
			),
			'steps' => array(
				'Run the command above — Codex registers the server and probes it for OAuth support.',
				sprintf(
					'Run %s to authorize. Codex opens a browser window.',
					'<code>codex mcp login ' . esc_html( $info['server_name'] ) . '</code>'
				),
				'Approve the connection on this site.',
			),
			'notes' => array(
				'The ChatGPT desktop app, Codex CLI and the IDE extension share one configuration file, so setting up any of them connects the other two.',
			),
		),

		'grok' => array(
			'label' => 'Grok',
			'auth' => 'oauth',
			'copy' => array( 'label' => 'MCP server URL', 'value' => $info['url'] ),
			'steps' => array(
				'Open <code>grok.com/connectors</code> and click New Connector.',
				'Choose Custom and paste the URL above.',
				'Complete the sign-in Grok asks for, then approve the connection on this site.',
			),
			'notes' => array(
				'Grok reaches the server from xAI\'s own machines, so it rejects localhost and private-network addresses — a local site needs a tunnel.',
			),
		),

		'cursor' => array(
			'label' => 'Cursor',
			'auth' => 'oauth',
			'deeplink' => array(
				'label' => 'Connect to Cursor',
				'scheme' => 'cursor',
				'url' => 'cursor://anysphere.cursor-deeplink/mcp/install?name=' . rawurlencode( $info['server_name'] )
					. '&config=' . rawurlencode( base64_encode( (string) $cursor_config ) ),
			),
			'notes' => array(
				'If the button does nothing, add this entry to mcpServers in your Cursor MCP settings instead:',
			),
			'snippet' => '"' . $info['server_name'] . '": ' . wp_json_encode(
					array( 'url' => $info['url'] ),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
				),
		),

		'vscode' => array(
			'label' => 'VS Code',
			'auth' => 'oauth',
			'deeplink' => array(
				'label' => 'Connect to VS Code',
				'scheme' => 'vscode',
				'url' => 'vscode:mcp/install?' . rawurlencode( (string) $vscode_config ),
			),
			'steps' => array(
				'Click the button above, then click Install in VS Code.',
				'Confirm the prompts VS Code shows, including the one that opens this site in your browser.',
				'Approve the connection on this site.',
			),
			'notes' => array(
				'If the button does nothing, run this in your terminal instead — VS Code will ask for the same confirmations:',
			),
			// Quoted by hand, not with escapeshellarg(): the command runs in the
			// user's shell, so PHP's host OS must not pick the quoting style.
			'copy' => array( 'value' => "code --add-mcp '" . str_replace( "'", "'\\''", (string) $vscode_config ) . "'" ),
		),

		'other' => array(
			'label' => __( 'Other client — manual setup', 'us' ),
			'auth' => 'apppw',
		),
	);
}

/**
 * __AUTH__ is substituted in the browser, so the Application Password never
 * travels back to the server.
 *
 * @return array http, stdio.
 */
function us_mcp_connect_manual_templates() {
	$info = us_mcp_connect_endpoint_info();

	$http = '"' . $info['server_name'] . '": ' . wp_json_encode(
			array(
				'url' => $info['snippet_url'],
				'headers' => array( 'Authorization' => '__AUTH__' ),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

	$stdio_args = array( '-y', 'mcp-remote', $info['snippet_url'], '--header', 'Authorization: __AUTH__' );
	if ( $info['is_local'] ) {
		// mcp-remote refuses a non-localhost http URL without this.
		$stdio_args[] = '--allow-http';
	}

	$stdio = '"' . $info['server_name'] . '": ' . wp_json_encode(
			array( 'command' => 'npx', 'args' => $stdio_args ),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

	return array( 'http' => $http, 'stdio' => $stdio );
}

/**
 * Only conditions that actually apply — a permanent wall of caveats teaches
 * people to skip the box entirely.
 *
 * One sentence each: what is wrong and what to do. The reasoning behind each
 * one is on the help portal, which every block already links to.
 *
 * @return array[] text + type ('error' or 'warning').
 */
function us_mcp_connect_warnings() {
	$info = us_mcp_connect_endpoint_info();
	$out = array();

	// Every other condition below is about the sign-in flow, so none applies.
	/** This filter is documented in mcp/oauth/oauth.php */
	if ( ! apply_filters( 'us_mcp_oauth_enabled', TRUE ) ) {
		$out[] = array(
			'type' => 'warning',
			'text' => 'One-click connection is turned off on this site by the us_mcp_oauth_enabled filter. Connect with an Application Password.',
		);

		return $out;
	}

	if ( ! us_mcp_oauth_is_secure() ) {
		$out[] = array(
			'type' => 'error',
			'text' => 'This site is not served over HTTPS, so it cannot authorize AI clients. Connect with an Application Password instead.',
		);
	}

	if ( (string) get_option( 'permalink_structure', '' ) === '' ) {
		$out[] = array(
			'type' => 'error',
			'text' => 'Permalinks are set to Plain, which the sign-in flow cannot work with. Choose any other structure in Settings → Permalinks, or connect with an Application Password.',
		);
	}

	if ( (string) parse_url( home_url( '/' ), PHP_URL_PATH ) !== '/' ) {
		$out[] = array(
			'type' => 'warning',
			'text' => 'WordPress runs in a subdirectory, so one-click connection also needs the /.well-known/ paths at the domain root.',
		);
	}

	foreach ( array( 'us-mcp-oauth', 'us-mcp-oauth/authorize' ) as $slug ) {
		if ( get_page_by_path( $slug ) ) {
			$out[] = array(
				'type' => 'warning',
				'text' => sprintf(
					'The page "%s" is shadowed by the connection endpoint. Rename it to make it reachable again.',
					$slug
				),
			);
			break;
		}
	}

	if ( $info['is_local'] ) {
		$out[] = array(
			'type' => 'warning',
			'text' => 'This site is local, so cloud clients such as Claude and ChatGPT on the web cannot reach it.',
		);
	}

	return $out;
}

/**
 * @return array[] family_id, name, meta — flattened for display.
 */
function us_mcp_connect_connections() {
	$date_format = get_option( 'date_format' );
	$out = array();

	foreach ( us_mcp_oauth_connections() as $connection ) {
		$user = get_userdata( (int) $connection['user_id'] );

		$meta = array(
			sprintf(
				'%s: %s',
				us_translate( 'User' ),
				// The account is normally gone only if deleted_user did not fire —
				// direct DB removal, or a multisite blog removal. The bare id is
				// both more useful for tracing that and one string fewer.
				$user ? $user->user_login : '#' . (int) $connection['user_id']
			),
		);

		// Both labels are core's own, from the Application Passwords list table —
		// the same kind of list, so the wording already matches what the user sees
		// on their profile screen, and it costs no translation.
		if ( $connection['last_used_at'] ) {
			$meta[] = sprintf(
				'%s: %s',
				us_translate( 'Last Used' ),
				sprintf(
					us_translate( '%s ago' ),
					human_time_diff( (int) strtotime( (string) $connection['last_used_at'] . ' UTC' ) )
				)
			);
		} else {
			$meta[] = sprintf(
				'%s: %s',
				us_translate( 'Created' ),
				wp_date( $date_format, (int) strtotime( (string) $connection['created_at'] . ' UTC' ) )
			);
		}

		$out[] = array(
			'family_id' => (string) $connection['family_id'],
			// Core's own placeholder for a record with no title — same idea, and
			// already translated everywhere.
			'name' => (string) $connection['client_name'] !== ''
				? (string) $connection['client_name']
				: us_translate( '(no title)' ),
			'meta' => implode( ' · ', $meta ),
		);
	}

	return $out;
}

/**
 * Everything field_mcp_connect.js needs, for us_pass_data_to_js().
 *
 * @return array
 */
function us_mcp_connect_js_data() {
	$templates = us_mcp_connect_manual_templates();

	return array(
		'login' => wp_get_current_user()->user_login,
		'tplHttp' => $templates['http'],
		'tplStdio' => $templates['stdio'],
		// Shown when the AJAX call itself fails, so core's generic wording fits and
		// costs nothing — it is the same text the nonce check already returns.
		'i18n' => array(
			'testFailed' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
		),
	);
}

/**
 * @return string Documentation link, or '' when the constants are unavailable.
 */
function us_mcp_connect_help_url() {
	if ( ! defined( 'US_HELP_PORTAL_URL' ) OR ! defined( 'US_THEMENAME' ) ) {
		return '';
	}

	return US_HELP_PORTAL_URL . '/' . strtolower( US_THEMENAME )
		. '/mcp-server/#how-to-connect-your-ai-application-to-mcp';
}
