<?php
/**
 * AJAX handlers for the MCP OAuth integration
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

add_action( 'wp_ajax_usof_mcp_revoke', 'us_mcp_ajax_revoke' );
add_action( 'wp_ajax_usof_mcp_selftest', 'us_mcp_ajax_selftest' );

/**
 * Disconnect one application.
 *
 * edit_theme_options is the capability that opens the Theme Options submenu,
 * and anyone who can reach that screen can already switch the whole MCP server
 * off — a narrower rule here would be theatre.
 */
function us_mcp_ajax_revoke() {
	// check_ajax_referer with $stop = FALSE returns instead of dying, so the
	// caller gets JSON rather than wp_nonce_ays()'s HTML page.
	if ( ! check_ajax_referer( 'usof-actions', '_wpnonce', FALSE ) ) {
		wp_send_json_error( array(
			'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
		) );
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => us_translate( 'Sorry, you are not allowed to do that.' ) ) );
	}

	$family_id = isset( $_POST['family_id'] ) ? sanitize_text_field( wp_unslash( $_POST['family_id'] ) ) : '';

	if ( ! preg_match( '/^[a-f0-9]{32}$/', $family_id ) ) {
		wp_send_json_error( array( 'message' => 'Unknown connection.' ) );
	}

	us_mcp_oauth_family_revoke( $family_id );

	wp_send_json_success( array( 'message' => 'The application was disconnected.' ) );
}

/**
 * Report a self-test outcome.
 *
 * One sentence for every diagnosis. What differs between them is a fixed machine
 * code plus the offending URL or server message, and the help portal explains
 * each code in full — so the hosting advice can change without touching this
 * file, and support can ask for the code rather than a paraphrase.
 *
 * @param string $code Machine code, e.g. 'auth-header-stripped'.
 * @param string $detail Offending URL or upstream error.
 */
function us_mcp_selftest_fail( $code, $detail = '' ) {
	// Only the failure path needs the connect-screen data file, and no field
	// renders on an admin-ajax request — so pull it in here rather than at load.
	require_once US_CORE_DIR . 'mcp/admin/connect-ui.php';

	$message = sprintf(
		'The endpoint test failed: %s',
		$code . ( $detail !== '' ? ' — ' . $detail : '' )
	);

	// Appended, not interpolated: the result is rendered as plain text, and an
	// empty documentation URL would otherwise leave a hole in the sentence.
	if ( $help = us_mcp_connect_help_url() ) {
		$message .= ' ' . $help;
	}

	wp_send_json_success( array( 'code' => (string) $code, 'message' => $message ) );
}

/**
 * Prove from the outside that the three things that silently break OAuth on
 * shared hosting actually work: the discovery documents are reachable, the MCP
 * endpoint answers 401 with a challenge, and the Authorization header survives
 * the web server.
 *
 * The probe token is deliberate garbage and is rejected like any other — there
 * is no test-only bypass anywhere in the auth path.
 */
function us_mcp_ajax_selftest() {
	if ( ! check_ajax_referer( 'usof-actions', '_wpnonce', FALSE ) ) {
		wp_send_json_error( array(
			'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
		) );
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => us_translate( 'Sorry, you are not allowed to do that.' ) ) );
	}

	$args = array(
		'timeout' => 15,
		'redirection' => 0,
		'sslverify' => ! us_mcp_oauth_is_local_host( (string) parse_url( home_url(), PHP_URL_HOST ) ),
	);

	foreach ( array( us_mcp_oauth_resource_metadata_url(), us_mcp_oauth_as_metadata_url() ) as $url ) {
		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			us_mcp_selftest_fail( 'discovery-unreachable', $url . ' — ' . $response->get_error_message() );
		}

		if ( (int) wp_remote_retrieve_response_code( $response ) !== 200 OR ! is_array( json_decode( wp_remote_retrieve_body( $response ), TRUE ) ) ) {
			us_mcp_selftest_fail( 'discovery-blocked', $url );
		}
	}

	/**
	 * The probe marker is compared by timestamp rather than cleared first: a
	 * delete_transient() here would add the key to this request's `notoptions`
	 * cache, and every later read would then short-circuit to false — hiding
	 * the value the loopback request is about to write. Reading only after the
	 * probe, and only accepting a marker at least as new as it, is stale-proof
	 * without touching the cache.
	 */
	$probe_started = time();

	$probe = wp_remote_post(
		us_mcp_oauth_resource_url(), $args + array(
			'headers' => array(
				'Authorization' => 'Bearer us-mcp-selftest-probe',
				'Content-Type' => 'application/json',
				'Accept' => 'application/json',
			),
			'body' => wp_json_encode( array(
				'jsonrpc' => '2.0',
				'id' => 1,
				'method' => 'initialize',
				'params' => new stdClass(),
			) ),
		)
	);

	if ( is_wp_error( $probe ) ) {
		us_mcp_selftest_fail( 'endpoint-unreachable', $probe->get_error_message() );
	}

	if ( (int) get_transient( 'us_mcp_oauth_auth_header_seen' ) < $probe_started ) {
		us_mcp_selftest_fail( 'auth-header-stripped' );
	}

	if ( (int) wp_remote_retrieve_response_code( $probe ) !== 401 ) {
		us_mcp_selftest_fail( 'unexpected-status', (string) (int) wp_remote_retrieve_response_code( $probe ) );
	}

	if ( ! wp_remote_retrieve_header( $probe, 'www-authenticate' ) ) {
		us_mcp_selftest_fail( 'no-challenge' );
	}

	wp_send_json_success( array( 'message' => 'Everything checks out.' ) );
}
