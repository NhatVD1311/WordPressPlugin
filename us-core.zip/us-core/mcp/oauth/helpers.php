<?php
/**
 * UpSolution MCP OAuth — URLs, crypto, PKCE, redirect-URI policy, rate limiting.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

// -----------------------------------------------------------------
// URLs
// -----------------------------------------------------------------

/**
 * Origin of home_url() with the path stripped — that is what keeps the RFC 8414
 * document at the plain /.well-known/ path even on a subdirectory install.
 *
 * @return string
 */
function us_mcp_oauth_issuer() {
	static $issuer = NULL;

	if ( $issuer === NULL ) {
		$parts = (array) parse_url( home_url( '/' ) );
		$issuer = ( $parts['scheme'] ?? 'https' ) . '://' . strtolower( (string) ( $parts['host'] ?? '' ) );
		if ( ! empty( $parts['port'] ) ) {
			$issuer .= ':' . (int) $parts['port'];
		}
	}

	return $issuer;
}

/**
 * @return string The protected resource — the MCP endpoint itself.
 */
function us_mcp_oauth_resource_url() {
	return untrailingslashit( rest_url( 'upsolution/v1/mcp' ) );
}

/**
 * @return string RFC 9728 §3.1 path-insertion form.
 */
function us_mcp_oauth_resource_metadata_url() {
	$path = (string) parse_url( us_mcp_oauth_resource_url(), PHP_URL_PATH );

	return us_mcp_oauth_issuer() . '/.well-known/oauth-protected-resource' . $path;
}

function us_mcp_oauth_as_metadata_url() {
	return us_mcp_oauth_issuer() . '/.well-known/oauth-authorization-server';
}

/**
 * From home_url(), not the issuer: this one must route through WordPress.
 *
 * @return string
 */
function us_mcp_oauth_authorize_url() {
	return home_url( '/' . US_MCP_OAUTH_AUTHORIZE_SLUG );
}

function us_mcp_oauth_token_url() {
	return rest_url( 'upsolution/v1/oauth/token' );
}

function us_mcp_oauth_register_url() {
	return rest_url( 'upsolution/v1/oauth/register' );
}

function us_mcp_oauth_revoke_url() {
	return rest_url( 'upsolution/v1/oauth/revoke' );
}

// -----------------------------------------------------------------
// Host / transport policy
// -----------------------------------------------------------------

/**
 * Loopback, private LAN, or a *.local / *.test name. Shared with the connect UI.
 *
 * @param string $host
 * @return bool
 */
function us_mcp_oauth_is_local_host( $host ) {
	$host = strtolower( trim( (string) $host, '[]' ) );

	return (bool) (
		$host === 'localhost'
		OR $host === '::1'
		OR preg_match( '/\.(local|test|localhost)$/', $host )
		OR preg_match( '/^(127\.|192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $host )
	);
}

function us_mcp_oauth_is_loopback_host( $host ) {
	return in_array( strtolower( trim( (string) $host, '[]' ) ), array( 'localhost', '127.0.0.1', '::1' ), TRUE );
}

/**
 * Whether OAuth may run at all.
 *
 * home_url()'s scheme rather than is_ssl(): it stays correct behind a
 * TLS-terminating proxy and cannot be spoofed by a request. Local-dev hosts are
 * exempt so the feature is testable over plain http.
 *
 * @return bool
 */
function us_mcp_oauth_is_secure() {
	$parts = (array) parse_url( home_url( '/' ) );

	if ( ( $parts['scheme'] ?? '' ) === 'https' ) {
		return TRUE;
	}

	return us_mcp_oauth_is_local_host( $parts['host'] ?? '' );
}

// -----------------------------------------------------------------
// Crypto
// -----------------------------------------------------------------

/**
 * 256-bit CSPRNG secret, hex-encoded.
 *
 * @param string $prefix
 * @return string Empty string when the platform RNG is unavailable.
 */
function us_mcp_oauth_random_token( $prefix = '' ) {
	try {
		return (string) $prefix . bin2hex( random_bytes( 32 ) );
	}
	catch ( \Throwable $e ) {
		return '';
	}
}

/**
 * Identifier for a client or a token family: 32 hex chars.
 *
 * @return string Empty string when the platform RNG is unavailable.
 */
function us_mcp_oauth_random_id() {
	try {
		return bin2hex( random_bytes( 16 ) );
	}
	catch ( \Throwable $e ) {
		return '';
	}
}

/**
 * Storage form of every secret we hold.
 *
 * Plain SHA-256, not a password KDF: these are 256-bit CSPRNG values with
 * nothing to guess, and a per-row-salted KDF would turn lookup-by-token into a
 * full table scan.
 *
 * @param string $secret
 * @return string 64 hex chars.
 */
function us_mcp_oauth_hash( $secret ) {
	return hash( 'sha256', (string) $secret );
}

/**
 * RFC 7636 §4.1 character set and length for both verifier and challenge.
 *
 * @param string $value
 * @return bool
 */
function us_mcp_oauth_is_valid_pkce_value( $value ) {
	return (bool) preg_match( '/^[A-Za-z0-9\-._~]{43,128}$/', (string) $value );
}

/**
 * S256 only — `plain` is never accepted and never advertised.
 *
 * @param string $verifier
 * @param string $challenge
 * @return bool
 */
function us_mcp_oauth_verify_pkce( $verifier, $challenge ) {
	if ( ! us_mcp_oauth_is_valid_pkce_value( $verifier ) ) {
		return FALSE;
	}

	$computed = rtrim( strtr( base64_encode( hash( 'sha256', (string) $verifier, TRUE ) ), '+/', '-_' ), '=' );

	return hash_equals( (string) $challenge, $computed );
}

// -----------------------------------------------------------------
// Redirect URIs
// -----------------------------------------------------------------

/**
 * https — any host. http — loopback only (RFC 8252 §7.3). Private-use schemes
 * (cursor://, vscode://) pass because scheme ownership is unverifiable anyway;
 * byte-exact matching at /authorize and the PKCE binding compensate.
 *
 * @param string $uri
 * @return bool
 */
function us_mcp_oauth_validate_redirect_uri( $uri ) {
	$uri = (string) $uri;

	if ( $uri === '' OR strlen( $uri ) > 255 ) {
		return FALSE;
	}

	// RFC 6749 §3.1.2: the endpoint URI must not include a fragment.
	if ( strpos( $uri, '#' ) !== FALSE ) {
		return FALSE;
	}

	// Browsers read "\" as "/" and drop tabs and newlines, so parse_url() would
	// see a different host than the one the user is sent to — e.g. claude.ai in
	// https://evil.com\@claude.ai, which defeats the host allowlist below.
	if ( preg_match( '/[\\\\\s\x00-\x1f\x7f]/', $uri ) ) {
		return FALSE;
	}

	$parts = parse_url( $uri );
	if ( ! is_array( $parts ) OR empty( $parts['scheme'] ) ) {
		return FALSE;
	}

	$scheme = strtolower( (string) $parts['scheme'] );
	if ( ! preg_match( '/^[a-z][a-z0-9+.\-]*$/', $scheme ) ) {
		return FALSE;
	}

	$denied = (array) apply_filters(
		'us_mcp_oauth_denied_redirect_schemes',
		array( 'javascript', 'data', 'vbscript', 'file', 'about', 'blob', 'view-source' )
	);
	if ( in_array( $scheme, $denied, TRUE ) ) {
		return FALSE;
	}

	$host = strtolower( (string) ( $parts['host'] ?? '' ) );

	if ( $scheme === 'https' ) {
		if ( $host === '' ) {
			return FALSE;
		}

		/**
		 * Optional hard allowlist for https redirect hosts; empty means "any".
		 * Exact lowercase host names, no subdomain matching. Loopback http is not
		 * affected, and private-use schemes have their own filter below.
		 *
		 * Checked at /authorize as well, so it also locks out clients registered
		 * before it was added.
		 *
		 * @param string[] $hosts e.g. array( 'claude.ai', 'chatgpt.com' ).
		 */
		$allowed_hosts = (array) apply_filters( 'us_mcp_oauth_allowed_redirect_hosts', array() );

		return ( empty( $allowed_hosts ) OR in_array( $host, $allowed_hosts, TRUE ) );
	}

	if ( $scheme === 'http' ) {
		return us_mcp_oauth_is_loopback_host( $host );
	}

	// Optional hard allowlist for private-use schemes; empty means "any".
	$allowed = (array) apply_filters( 'us_mcp_oauth_allowed_redirect_schemes', array() );

	return ( empty( $allowed ) OR in_array( $scheme, $allowed, TRUE ) );
}

/**
 * Byte-exact, except a loopback URI matches ignoring the port: VS Code and
 * Cursor bind an ephemeral callback port per launch, so comparing it would mean
 * "works once, then never again" (RFC 8252 §7.3).
 *
 * @param string[] $registered
 * @param string $presented
 * @return bool
 */
function us_mcp_oauth_redirect_uri_matches( $registered, $presented ) {
	$presented = (string) $presented;

	foreach ( (array) $registered as $uri ) {
		if ( hash_equals( (string) $uri, $presented ) ) {
			return TRUE;
		}
	}

	$p = parse_url( $presented );
	if (
		! is_array( $p )
		OR strtolower( (string) ( $p['scheme'] ?? '' ) ) !== 'http'
		OR ! us_mcp_oauth_is_loopback_host( $p['host'] ?? '' )
	) {
		return FALSE;
	}

	$host = strtolower( trim( (string) ( $p['host'] ?? '' ), '[]' ) );
	$path = (string) ( $p['path'] ?? '' );

	foreach ( (array) $registered as $uri ) {
		$r = parse_url( (string) $uri );
		if (
			is_array( $r )
			AND strtolower( (string) ( $r['scheme'] ?? '' ) ) === 'http'
			AND strtolower( trim( (string) ( $r['host'] ?? '' ), '[]' ) ) === $host
			AND (string) ( $r['path'] ?? '' ) === $path
		) {
			return TRUE;
		}
	}

	return FALSE;
}

// -----------------------------------------------------------------
// Abuse control
// -----------------------------------------------------------------

/**
 * REMOTE_ADDR only: X-Forwarded-For is attacker-controlled, and trusting it
 * would let one attacker both evade the limit and poison an innocent IP's
 * bucket. Behind a proxy the limit collapses to global — it fails closed.
 *
 * @return string
 */
function us_mcp_oauth_client_ip() {
	return (string) apply_filters( 'us_mcp_oauth_client_ip', $_SERVER['REMOTE_ADDR'] ?? '' );
}

/**
 * Fixed window. Transients are safe here: losing a counter only relaxes the
 * limit, unlike codes and tokens where eviction would break correctness.
 *
 * @param string $bucket Caller-defined key, e.g. 'register:1.2.3.4'.
 * @param int $limit Allowed hits per window.
 * @param int $window Window length in seconds.
 * @return true|int TRUE when allowed, otherwise seconds until the window resets.
 */
function us_mcp_oauth_rate_limit( $bucket, $limit, $window ) {
	$key = 'us_mcp_oauth_rl_' . md5( (string) $bucket );
	$now = time();

	$data = get_transient( $key );
	if ( ! is_array( $data ) OR (int) ( $data['reset'] ?? 0 ) <= $now ) {
		$data = array( 'hits' => 0, 'reset' => $now + (int) $window );
	}

	$data['hits'] = (int) $data['hits'] + 1;
	set_transient( $key, $data, max( 1, (int) $data['reset'] - $now ) );

	if ( $data['hits'] <= (int) $limit ) {
		return TRUE;
	}

	return max( 1, (int) $data['reset'] - $now );
}

/**
 * Same capability as us_mcp_permission_callback(), so consent can never mint a
 * token the transport would reject.
 *
 * @param int $user_id
 * @return bool
 */
function us_mcp_oauth_user_may_connect( $user_id ) {
	$user = get_userdata( (int) $user_id );

	return (bool) ( $user AND user_can( $user, 'edit_posts' ) );
}

/**
 * Security events only — replayed codes, refresh reuse, lost rotation races.
 *
 * Safelist: pass opaque ids and hardcoded text. NEVER a token, code,
 * code_verifier, client secret or raw request body.
 *
 * @param string $message
 */
function us_mcp_oauth_log( $message ) {
	error_log( '[us-core MCP OAuth] ' . (string) $message );
}

// -----------------------------------------------------------------
// Raw HTTP output (used by the do_parse_request handlers)
// -----------------------------------------------------------------

/** Vary keeps a page cache from serving one caller's response to another. */
function us_mcp_oauth_no_store() {
	if ( headers_sent() ) {
		return;
	}
	header( 'Cache-Control: no-store, no-cache, must-revalidate, private' );
	header( 'Pragma: no-cache' );
	header( 'Vary: Authorization' );
}

/**
 * Emit a JSON body and stop. Only the discovery documents pass $cacheable.
 *
 * @param array $data
 * @param int $status
 * @param bool $cacheable
 */
function us_mcp_oauth_json_out( $data, $status = 200, $cacheable = FALSE ) {
	if ( ! headers_sent() ) {
		status_header( (int) $status );
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );

		if ( $cacheable ) {
			header( 'Cache-Control: public, max-age=3600' );
			header( 'Access-Control-Allow-Origin: *' );
		} else {
			us_mcp_oauth_no_store();
		}
	}

	echo wp_json_encode( $data );
	exit;
}
