<?php
/**
 * UpSolution MCP OAuth — machine-to-machine endpoints.
 *
 *   POST /oauth/register   RFC 7591 dynamic registration
 *   POST /oauth/token      authorization_code + refresh_token
 *   POST /oauth/revoke     RFC 7009
 *
 * Only the browser-facing /authorize is not a REST route — see authorize.php.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Public by design: open registration is what makes zero-config connect
 * possible, and /token authenticates by grant material, not WordPress identity.
 */
function us_mcp_oauth_register_rest_routes() {
	$common = array(
		'methods' => 'POST',
		'permission_callback' => '__return_true',
		'show_in_index' => FALSE,
	);

	register_rest_route( 'upsolution/v1', '/oauth/register', $common + array( 'callback' => 'us_mcp_oauth_handle_register' ) );
	register_rest_route( 'upsolution/v1', '/oauth/token', $common + array( 'callback' => 'us_mcp_oauth_handle_token' ) );
	register_rest_route( 'upsolution/v1', '/oauth/revoke', $common + array( 'callback' => 'us_mcp_oauth_handle_revoke' ) );
}

// -----------------------------------------------------------------
// Response helpers
// -----------------------------------------------------------------

/**
 * @param WP_REST_Response $response
 * @return WP_REST_Response
 */
function us_mcp_oauth_rest_headers( $response ) {
	$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, private' );
	$response->header( 'Pragma', 'no-cache' );

	// Safe without credentials, and browser-hosted MCP clients need these.
	$response->header( 'Access-Control-Allow-Origin', '*' );

	return $response;
}

/**
 * RFC 6749 §5.2 error body.
 *
 * @param string $error
 * @param string $description Never a secret or a raw request body.
 * @param int $status
 * @return WP_REST_Response
 */
function us_mcp_oauth_rest_error( $error, $description = '', $status = 400 ) {
	$body = array( 'error' => (string) $error );
	if ( $description !== '' ) {
		$body['error_description'] = (string) $description;
	}

	return us_mcp_oauth_rest_headers( new WP_REST_Response( $body, (int) $status ) );
}

/**
 * @param string $bucket
 * @param int $limit
 * @param int $window
 * @return WP_REST_Response|NULL 429 response when the limit is exceeded.
 */
function us_mcp_oauth_rest_rate_limit( $bucket, $limit, $window ) {
	$retry = us_mcp_oauth_rate_limit( $bucket . ':' . us_mcp_oauth_client_ip(), $limit, $window );

	if ( $retry === TRUE ) {
		return NULL;
	}

	$response = us_mcp_oauth_rest_error( 'temporarily_unavailable', 'Too many requests. Try again later.', 429 );
	$response->header( 'Retry-After', (string) (int) $retry );

	return $response;
}

/**
 * @return WP_REST_Response|NULL
 */
function us_mcp_oauth_rest_require_https() {
	if ( us_mcp_oauth_is_secure() ) {
		return NULL;
	}

	return us_mcp_oauth_rest_error(
		'invalid_request',
		'OAuth requires the site address to use HTTPS. Set the WordPress Address and Site Address to https:// or connect with an Application Password instead.'
	);
}

// -----------------------------------------------------------------
// POST /oauth/register — RFC 7591
// -----------------------------------------------------------------

/**
 * Registration is open, so the abuse controls are the whole defence: body cap
 * before json_decode, per-IP rate limit, pruning of clients that never
 * authorized, and a ceiling on stored rows. RFC 7592 client management is
 * deliberately absent — it would be a second unauthenticated surface.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_handle_register( WP_REST_Request $request ) {
	if ( $error = us_mcp_oauth_rest_require_https() ) {
		return $error;
	}

	if ( $limited = us_mcp_oauth_rest_rate_limit( 'register', 5, HOUR_IN_SECONDS ) ) {
		return $limited;
	}

	$body = (string) $request->get_body();
	if ( strlen( $body ) > US_MCP_OAUTH_REG_BODY_MAX ) {
		return us_mcp_oauth_rest_error( 'invalid_client_metadata', 'Registration payload too large.' );
	}

	$data = json_decode( $body, TRUE );
	if ( ! is_array( $data ) ) {
		return us_mcp_oauth_rest_error( 'invalid_client_metadata', 'Expected a JSON object.' );
	}

	// Nested arrays are dropped, not passed to strval() — it would warn and
	// yield the literal "Array".
	$uris = array_values(
		array_unique(
			array_filter(
				array_map(
					function ( $uri ) {
						return is_scalar( $uri ) ? (string) $uri : '';
					},
					(array) ( $data['redirect_uris'] ?? array() )
				)
			)
		)
	);
	if ( empty( $uris ) OR count( $uris ) > 5 ) {
		return us_mcp_oauth_rest_error( 'invalid_redirect_uri', 'Provide between 1 and 5 redirect_uris.' );
	}

	foreach ( $uris as $uri ) {
		if ( ! us_mcp_oauth_validate_redirect_uri( $uri ) ) {
			return us_mcp_oauth_rest_error(
				'invalid_redirect_uri',
				'Redirect URIs must be https, a loopback http address, or a private-use scheme, must not contain a fragment, and must be allowed by this site.'
			);
		}
	}

	us_mcp_oauth_client_prune();
	if ( us_mcp_oauth_client_count() >= US_MCP_OAUTH_MAX_CLIENTS ) {
		$response = us_mcp_oauth_rest_error( 'temporarily_unavailable', 'The client registry is full. Try again later.', 429 );
		$response->header( 'Retry-After', (string) HOUR_IN_SECONDS );

		return $response;
	}

	$client_name = is_scalar( $data['client_name'] ?? NULL )
		? mb_substr( sanitize_text_field( (string) $data['client_name'] ), 0, 191 )
		: '';

	// client_uri, logo_uri and software_id are accepted by RFC 7591 and dropped
	// on purpose: nothing renders them, and a stored URL the client controls is a
	// liability the moment someone decides to display it.
	$client = us_mcp_oauth_client_insert( array(
		'client_name' => $client_name,
		'redirect_uris' => $uris,
		'token_endpoint_auth_method' => (string) ( $data['token_endpoint_auth_method'] ?? 'none' ),
	) );

	if ( ! $client ) {
		return us_mcp_oauth_rest_error( 'server_error', 'Could not store the client registration.', 500 );
	}

	$out = array(
		'client_id' => $client['client_id'],
		'client_id_issued_at' => time(),
		'client_name' => $client_name,
		'redirect_uris' => $uris,
		'grant_types' => array( 'authorization_code', 'refresh_token' ),
		'response_types' => array( 'code' ),
		'token_endpoint_auth_method' => $client['client_secret'] !== '' ? 'client_secret_post' : 'none',
	);

	if ( $client['client_secret'] !== '' ) {
		$out['client_secret'] = $client['client_secret'];
		$out['client_secret_expires_at'] = 0;
	}

	return us_mcp_oauth_rest_headers( new WP_REST_Response( $out, 201 ) );
}

// -----------------------------------------------------------------
// POST /oauth/token
// -----------------------------------------------------------------

/**
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_handle_token( WP_REST_Request $request ) {
	if ( $error = us_mcp_oauth_rest_require_https() ) {
		return $error;
	}

	if ( $limited = us_mcp_oauth_rest_rate_limit( 'token', 30, 5 * MINUTE_IN_SECONDS ) ) {
		return $limited;
	}

	$grant = (string) $request->get_param( 'grant_type' );

	if ( $grant === 'authorization_code' ) {
		return us_mcp_oauth_token_authorization_code( $request );
	}

	if ( $grant === 'refresh_token' ) {
		return us_mcp_oauth_token_refresh( $request );
	}

	return us_mcp_oauth_rest_error( 'unsupported_grant_type', 'Supported grants: authorization_code, refresh_token.' );
}

/**
 * Authenticate the client for a token request.
 *
 * @param array $client
 * @param WP_REST_Request $request
 * @return bool
 */
function us_mcp_oauth_client_authenticated( $client, WP_REST_Request $request ) {
	if ( (string) $client['token_endpoint_auth_method'] !== 'client_secret_post' ) {
		return TRUE;
	}

	$secret = (string) $request->get_param( 'client_secret' );

	return ( $secret !== '' AND hash_equals( (string) $client['secret_hash'], us_mcp_oauth_hash( $secret ) ) );
}

/**
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_token_authorization_code( WP_REST_Request $request ) {
	$code = (string) $request->get_param( 'code' );
	$client_id = (string) $request->get_param( 'client_id' );
	$verifier = (string) $request->get_param( 'code_verifier' );
	$redirect_uri = (string) $request->get_param( 'redirect_uri' );

	if ( $code === '' OR $client_id === '' OR $verifier === '' OR $redirect_uri === '' ) {
		return us_mcp_oauth_rest_error( 'invalid_request', 'code, client_id, redirect_uri and code_verifier are all required.' );
	}

	$client = us_mcp_oauth_client_get( $client_id );
	if ( ! $client ) {
		return us_mcp_oauth_rest_error( 'invalid_client', 'Unknown client.', 401 );
	}

	if ( ! us_mcp_oauth_client_authenticated( $client, $request ) ) {
		return us_mcp_oauth_rest_error( 'invalid_client', 'Client authentication failed.', 401 );
	}

	$row = us_mcp_oauth_code_claim( $code );

	if ( ! $row ) {
		// A miss means unknown, expired or already redeemed. Only the last case
		// has a family to kill (RFC 6749 §4.1.2).
		$replayed = us_mcp_oauth_code_find( $code );
		if ( $replayed AND (int) $replayed['used'] === 1 AND $replayed['family_id'] !== '' ) {
			us_mcp_oauth_family_revoke( (string) $replayed['family_id'] );
			us_mcp_oauth_log( sprintf( 'authorization code replayed, revoked family %s', $replayed['family_id'] ) );
		}

		return us_mcp_oauth_rest_error( 'invalid_grant', 'The authorization code is unknown, expired or already used.' );
	}

	if ( ! hash_equals( (string) $row['client_id'], $client_id ) ) {
		return us_mcp_oauth_rest_error( 'invalid_grant', 'The authorization code was issued to a different client.' );
	}

	if ( ! hash_equals( (string) $row['redirect_uri'], $redirect_uri ) ) {
		return us_mcp_oauth_rest_error( 'invalid_grant', 'redirect_uri does not match the one used to obtain the code.' );
	}

	if ( ! us_mcp_oauth_verify_pkce( $verifier, (string) $row['code_challenge'] ) ) {
		return us_mcp_oauth_rest_error( 'invalid_grant', 'PKCE verification failed.' );
	}

	if ( ! us_mcp_oauth_user_may_connect( (int) $row['user_id'] ) ) {
		return us_mcp_oauth_rest_error( 'invalid_grant', 'The authorizing account can no longer be used.' );
	}

	$pair = us_mcp_oauth_token_issue_pair( array(
		'client_id' => $client_id,
		'user_id' => (int) $row['user_id'],
		'resource' => (string) $row['resource'],
	) );

	if ( ! $pair ) {
		return us_mcp_oauth_rest_error( 'server_error', 'Could not issue tokens.', 500 );
	}

	us_mcp_oauth_code_link_family( (int) $row['id'], $pair['family_id'] );
	us_mcp_oauth_client_touch( $client_id );

	return us_mcp_oauth_token_response( $pair, (string) $row['resource'] );
}

/**
 * Rotation with reuse detection: presenting an already-rotated token, or losing
 * the race for it, revokes the whole family. A stolen refresh token is usable
 * at most once, and the theft surfaces as an immediate disconnect.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_token_refresh( WP_REST_Request $request ) {
	$refresh = (string) $request->get_param( 'refresh_token' );
	$client_id = (string) $request->get_param( 'client_id' );

	if ( $refresh === '' OR $client_id === '' ) {
		return us_mcp_oauth_rest_error( 'invalid_request', 'refresh_token and client_id are required.' );
	}

	$client = us_mcp_oauth_client_get( $client_id );
	if ( ! $client ) {
		return us_mcp_oauth_rest_error( 'invalid_client', 'Unknown client.', 401 );
	}

	if ( ! us_mcp_oauth_client_authenticated( $client, $request ) ) {
		return us_mcp_oauth_rest_error( 'invalid_client', 'Client authentication failed.', 401 );
	}

	$row = us_mcp_oauth_token_find( $refresh, 'refresh' );
	if ( ! $row ) {
		return us_mcp_oauth_rest_error( 'invalid_grant', 'Unknown refresh token.' );
	}

	if ( (int) $row->revoked === 1 OR $row->rotated_at !== NULL ) {
		us_mcp_oauth_family_revoke( (string) $row->family_id );
		us_mcp_oauth_log( sprintf( 'refresh token reuse detected, revoked family %s', $row->family_id ) );

		return us_mcp_oauth_rest_error( 'invalid_grant', 'This refresh token has already been used.' );
	}

	if ( $row->expires_at <= us_mcp_oauth_now() ) {
		us_mcp_oauth_family_revoke( (string) $row->family_id );

		return us_mcp_oauth_rest_error( 'invalid_grant', 'The refresh token has expired.' );
	}

	if ( ! hash_equals( (string) $row->client_id, $client_id ) ) {
		us_mcp_oauth_family_revoke( (string) $row->family_id );

		return us_mcp_oauth_rest_error( 'invalid_grant', 'The refresh token was issued to a different client.' );
	}

	if ( ! us_mcp_oauth_token_claim_rotation( (int) $row->id ) ) {
		us_mcp_oauth_family_revoke( (string) $row->family_id );
		us_mcp_oauth_log( sprintf( 'concurrent refresh rotation, revoked family %s', $row->family_id ) );

		return us_mcp_oauth_rest_error( 'invalid_grant', 'This refresh token has already been used.' );
	}

	if ( ! us_mcp_oauth_user_may_connect( (int) $row->user_id ) ) {
		us_mcp_oauth_family_revoke( (string) $row->family_id );

		return us_mcp_oauth_rest_error( 'invalid_grant', 'The authorizing account can no longer be used.' );
	}

	$pair = us_mcp_oauth_token_issue_pair( array(
		'client_id' => $client_id,
		'user_id' => (int) $row->user_id,
		'resource' => (string) $row->resource,
		'family_id' => (string) $row->family_id,
		'family_created_at' => (string) $row->family_created_at,
	) );

	if ( ! $pair ) {
		return us_mcp_oauth_rest_error( 'server_error', 'Could not issue tokens.', 500 );
	}

	us_mcp_oauth_client_touch( $client_id );

	return us_mcp_oauth_token_response( $pair, (string) $row->resource );
}

/**
 * The previous access token stays alive until its own expiry — revoking it here
 * would break requests already in flight.
 *
 * @param array $pair
 * @param string $resource
 * @return WP_REST_Response
 */
function us_mcp_oauth_token_response( $pair, $resource = '' ) {
	$body = array(
		'access_token' => $pair['access_token'],
		'token_type' => 'Bearer',
		'expires_in' => (int) $pair['expires_in'],
		'refresh_token' => $pair['refresh_token'],
		'scope' => US_MCP_OAUTH_SCOPE,
	);

	if ( $resource !== '' ) {
		$body['resource'] = $resource;
	}

	return us_mcp_oauth_rest_headers( new WP_REST_Response( $body, 200 ) );
}

// -----------------------------------------------------------------
// POST /oauth/revoke — RFC 7009
// -----------------------------------------------------------------

/**
 * Revokes the whole family, so either token of a pair disconnects the client.
 * RFC 7009 §2.2 requires 200 even for an unknown token, so this never reveals
 * whether a value was valid.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_handle_revoke( WP_REST_Request $request ) {
	if ( $error = us_mcp_oauth_rest_require_https() ) {
		return $error;
	}

	if ( $limited = us_mcp_oauth_rest_rate_limit( 'revoke', 30, 5 * MINUTE_IN_SECONDS ) ) {
		return $limited;
	}

	$token = (string) $request->get_param( 'token' );
	$client_id = (string) $request->get_param( 'client_id' );

	if ( $token !== '' ) {
		$row = us_mcp_oauth_token_find( $token, 'refresh' );
		if ( ! $row ) {
			$row = us_mcp_oauth_token_find( $token, 'access' );
		}

		if ( $row AND ( $client_id === '' OR hash_equals( (string) $row->client_id, $client_id ) ) ) {
			us_mcp_oauth_family_revoke( (string) $row->family_id );
		}
	}

	return us_mcp_oauth_rest_headers( new WP_REST_Response( NULL, 200 ) );
}
