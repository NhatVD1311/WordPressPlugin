<?php
/**
 * UpSolution MCP OAuth — the browser-facing authorization endpoint.
 *
 * Not a REST route: rest_cookie_check_errors() calls wp_set_current_user( 0 )
 * for a REST request with a login cookie but no X-WP-Nonce, so a consent screen
 * under wp-json could never see the logged-in user.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * GET on the initial redirect, POST from the consent form — which carries every
 * parameter forward as a hidden field, to be re-validated, never trusted.
 *
 * @return array
 */
function us_mcp_oauth_authorize_params() {
	$source = ( strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) === 'POST' ) ? $_POST : $_GET;

	// Non-scalars are dropped rather than cast: a caller can send any parameter
	// as an array, and (string) on one emits a PHP warning on a public endpoint.
	$get = function ( $key ) use ( $source ) {
		return ( isset( $source[ $key ] ) AND is_scalar( $source[ $key ] ) )
			? trim( (string) wp_unslash( $source[ $key ] ) )
			: '';
	};

	return array(
		'response_type' => $get( 'response_type' ),
		'client_id' => $get( 'client_id' ),
		'redirect_uri' => $get( 'redirect_uri' ),
		'state' => mb_substr( $get( 'state' ), 0, 512 ),
		'code_challenge' => $get( 'code_challenge' ),
		'code_challenge_method' => $get( 'code_challenge_method' ),
		'resource' => mb_substr( $get( 'resource' ), 0, 255 ),
	);
}

/**
 * Rebuilt for the round-trip through wp-login.php.
 *
 * @param array $params
 * @return string
 */
function us_mcp_oauth_authorize_self_url( $params ) {
	return add_query_arg( array_map( 'rawurlencode', array_filter( $params, 'strlen' ) ), us_mcp_oauth_authorize_url() );
}

/**
 * Stop with a page and no Location header. Reached only while the client or the
 * redirect URI is unproven — OAuth 2.1 §4.1.2.1 forbids delivering an error to
 * an unvalidated redirect_uri, or the endpoint becomes an open redirect.
 *
 * @param string $message
 */
function us_mcp_oauth_authorize_die( $message ) {
	us_mcp_oauth_no_store();

	wp_die(
		esc_html( $message ),
		'Connection request rejected',
		array( 'response' => 400 )
	);
}

/**
 * Only callable once the client and the redirect URI have been validated.
 *
 * @param string $redirect_uri
 * @param string $state
 * @param string $error
 * @param string $description
 */
function us_mcp_oauth_authorize_error( $redirect_uri, $state, $error, $description = '' ) {
	$args = array( 'error' => $error, 'iss' => us_mcp_oauth_issuer() );

	if ( $description !== '' ) {
		$args['error_description'] = $description;
	}
	if ( $state !== '' ) {
		$args['state'] = $state;
	}

	us_mcp_oauth_no_store();

	// wp_redirect, not wp_safe_redirect: the target is an external client
	// callback, already matched against the client's registered list.
	wp_redirect( add_query_arg( array_map( 'rawurlencode', $args ), $redirect_uri ) );
	exit;
}

/**
 * Entry point for both GET and POST on /us-mcp-oauth/authorize.
 */
function us_mcp_oauth_handle_authorize() {
	$is_post = ( strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) === 'POST' );

	if ( ! us_mcp_oauth_is_secure() ) {
		us_mcp_oauth_authorize_die( 'This site is not served over HTTPS, so it cannot authorize AI clients. Connect with an Application Password instead.' );
	}

	$retry = us_mcp_oauth_rate_limit( 'authorize:' . us_mcp_oauth_client_ip(), 30, 5 * MINUTE_IN_SECONDS );
	if ( $retry !== TRUE ) {
		us_mcp_oauth_authorize_die( 'Too many authorization attempts. Please wait a few minutes and try again.' );
	}

	$params = us_mcp_oauth_authorize_params();

	// -------------------------------------------------------------
	// Phase 1 — nothing may be redirected until both of these pass.
	// -------------------------------------------------------------
	$client = ( $params['client_id'] !== '' ) ? us_mcp_oauth_client_get( $params['client_id'] ) : NULL;
	if ( ! $client ) {
		us_mcp_oauth_authorize_die( 'Unknown application. Ask the AI client to register again, then retry the connection.' );
	}

	if (
		$params['redirect_uri'] === ''
		OR ! us_mcp_oauth_redirect_uri_matches( $client['redirect_uris'], $params['redirect_uri'] )
	) {
		us_mcp_oauth_authorize_die( 'The return address supplied by the application is not one it registered. The connection was refused.' );
	}

	// Re-checked against the current policy: a redirect allowlist added after
	// registration must lock out clients that registered before it.
	if ( ! us_mcp_oauth_validate_redirect_uri( $params['redirect_uri'] ) ) {
		us_mcp_oauth_authorize_die( 'This site does not accept connections that return to this address. The connection was refused.' );
	}

	// -------------------------------------------------------------
	// Phase 2 — a signed-in user must be behind the request before anything is
	// sent to the client. Registration is open, so redirecting an anonymous
	// caller — even only to deliver an error — would turn this endpoint into an
	// open redirect for anyone able to register a client of their own.
	// -------------------------------------------------------------
	if ( ! is_user_logged_in() ) {
		us_mcp_oauth_no_store();
		wp_safe_redirect( wp_login_url( us_mcp_oauth_authorize_self_url( $params ) ) );
		exit;
	}

	if ( ! current_user_can( 'edit_posts' ) ) {
		us_mcp_oauth_render_consent( $params, $client, FALSE );
	}

	// -------------------------------------------------------------
	// Phase 3 — the request itself, with errors now allowed to go back.
	// -------------------------------------------------------------
	if ( $params['response_type'] !== 'code' ) {
		us_mcp_oauth_authorize_error( $params['redirect_uri'], $params['state'], 'unsupported_response_type', 'Only response_type=code is supported.' );
	}

	if (
		$params['code_challenge_method'] !== 'S256'
		OR ! us_mcp_oauth_is_valid_pkce_value( $params['code_challenge'] )
	) {
		us_mcp_oauth_authorize_error( $params['redirect_uri'], $params['state'], 'invalid_request', 'PKCE with code_challenge_method=S256 is required.' );
	}

	if ( ! $is_post ) {
		us_mcp_oauth_render_consent( $params, $client, TRUE );
	}

	// -------------------------------------------------------------
	// Phase 4 — the consent form came back.
	// -------------------------------------------------------------
	check_admin_referer( 'us_mcp_oauth_consent' );

	$retry = us_mcp_oauth_rate_limit( 'consent:' . get_current_user_id(), 10, 5 * MINUTE_IN_SECONDS );
	if ( $retry !== TRUE ) {
		us_mcp_oauth_authorize_die( 'Too many authorization attempts. Please wait a few minutes and try again.' );
	}

	if ( empty( $_POST['us_mcp_authorize'] ) ) {
		us_mcp_oauth_authorize_error( $params['redirect_uri'], $params['state'], 'access_denied', 'The user declined the connection.' );
	}

	$code = us_mcp_oauth_code_insert( array(
		'client_id' => $client['client_id'],
		'user_id' => get_current_user_id(),
		'redirect_uri' => $params['redirect_uri'],
		'code_challenge' => $params['code_challenge'],
		'resource' => $params['resource'] !== '' ? $params['resource'] : us_mcp_oauth_resource_url(),
	) );

	if ( ! $code ) {
		us_mcp_oauth_authorize_error( $params['redirect_uri'], $params['state'], 'server_error', 'The authorization code could not be stored.' );
	}

	us_mcp_oauth_client_touch( $client['client_id'] );

	$args = array( 'code' => $code, 'iss' => us_mcp_oauth_issuer() );
	if ( $params['state'] !== '' ) {
		$args['state'] = $params['state'];
	}

	us_mcp_oauth_no_store();
	wp_redirect( add_query_arg( array_map( 'rawurlencode', $args ), $params['redirect_uri'] ) );
	exit;
}

/**
 * @param array $params
 * @param array $client
 * @param bool $may_authorize FALSE renders the "account cannot be used" variant.
 */
function us_mcp_oauth_render_consent( $params, $client, $may_authorize ) {
	if ( ! headers_sent() ) {
		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );

		// Consent screens are the classic clickjacking target.
		header( 'X-Frame-Options: DENY' );
		header( "Content-Security-Policy: frame-ancestors 'none'" );

		us_mcp_oauth_no_store();
	}

	$user = wp_get_current_user();

	$view = array(
		'params' => $params,
		'user' => $user,
		'may_authorize' => (bool) $may_authorize,
		'action' => us_mcp_oauth_authorize_url(),
		// Not translated, like the rest of the consent screen — a localised
		// fallback would be the one non-English phrase on an English page.
		'client_name' => (string) $client['client_name'] !== ''
			? (string) $client['client_name']
			: 'An unnamed application',
		'redirect_host' => (string) parse_url( $params['redirect_uri'], PHP_URL_HOST ),
		'site_name' => get_bloginfo( 'name' ),
		'cancel_url' => add_query_arg(
			array_map( 'rawurlencode', array_filter( array(
				'error' => 'access_denied',
				'iss' => us_mcp_oauth_issuer(),
				'state' => $params['state'],
			), 'strlen' ) ),
			$params['redirect_uri']
		),
		'switch_user_url' => wp_logout_url( us_mcp_oauth_authorize_self_url( $params ) ),
	);

	require US_CORE_MCP_DIR . 'oauth/templates/consent.php';
	exit;
}
