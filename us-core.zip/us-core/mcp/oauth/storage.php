<?php
/**
 * UpSolution MCP OAuth — persistence.
 *
 * Tables, not transients: with a persistent object cache an LRU eviction
 * between /authorize and /token would silently destroy a code, and reuse
 * detection needs durable state. Rate-limit counters stay in transients, where
 * loss only relaxes the limit.
 *
 * Secrets are stored as SHA-256 only. All datetimes are UTC.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * @param string $name One of 'clients', 'codes', 'tokens'.
 * @return string
 */
function us_mcp_oauth_table( $name ) {
	global $wpdb;

	return $wpdb->prefix . 'us_mcp_oauth_' . $name;
}

/** @return string Current UTC time, MySQL datetime format. */
function us_mcp_oauth_now() {
	return gmdate( 'Y-m-d H:i:s' );
}

/**
 * @param int $seconds
 * @return string
 */
function us_mcp_oauth_expiry( $seconds ) {
	return gmdate( 'Y-m-d H:i:s', time() + (int) $seconds );
}

/**
 * Create or upgrade the schema. Guarded by an autoloaded option, so the common
 * path is a cache read. Not tied to an activation hook — the feature is toggled
 * from Theme Options long after activation.
 */
function us_mcp_oauth_maybe_install() {
	if ( (int) get_option( 'us_mcp_oauth_db_version', 0 ) >= US_MCP_OAUTH_DB_VERSION ) {
		return;
	}

	global $wpdb;

	$charset_collate = $wpdb->get_charset_collate();
	$clients = us_mcp_oauth_table( 'clients' );
	$codes = us_mcp_oauth_table( 'codes' );
	$tokens = us_mcp_oauth_table( 'tokens' );

	// dbDelta parses this literally: one column per line, KEY not INDEX, two
	// spaces after PRIMARY KEY. Otherwise a version bump cannot alter in place.
	$schema = "
		CREATE TABLE `{$clients}` (
			`id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
			`client_id` char(32) NOT NULL,
			`secret_hash` char(64) DEFAULT NULL,
			`client_name` varchar(191) NOT NULL DEFAULT '',
			`redirect_uris` text NOT NULL,
			`token_endpoint_auth_method` varchar(32) NOT NULL DEFAULT 'none',
			`created_at` datetime NOT NULL,
			`last_used_at` datetime DEFAULT NULL,
			PRIMARY KEY  (`id`),
			UNIQUE KEY `client_id` (`client_id`),
			KEY `created_at` (`created_at`),
			KEY `last_used_at` (`last_used_at`)
		) $charset_collate;
		CREATE TABLE `{$codes}` (
			`id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
			`code_hash` char(64) NOT NULL,
			`client_id` char(32) NOT NULL,
			`user_id` bigint UNSIGNED NOT NULL,
			`redirect_uri` varchar(255) NOT NULL,
			`code_challenge` varchar(128) NOT NULL,
			`resource` varchar(255) NOT NULL DEFAULT '',
			`family_id` char(32) NOT NULL DEFAULT '',
			`used` tinyint UNSIGNED NOT NULL DEFAULT 0,
			`expires_at` datetime NOT NULL,
			`created_at` datetime NOT NULL,
			PRIMARY KEY  (`id`),
			UNIQUE KEY `code_hash` (`code_hash`),
			KEY `expires_at` (`expires_at`),
			KEY `user_id` (`user_id`)
		) $charset_collate;
		CREATE TABLE `{$tokens}` (
			`id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
			`token_hash` char(64) NOT NULL,
			`type` varchar(8) NOT NULL DEFAULT 'access',
			`family_id` char(32) NOT NULL,
			`family_created_at` datetime NOT NULL,
			`client_id` char(32) NOT NULL,
			`user_id` bigint UNSIGNED NOT NULL,
			`resource` varchar(255) NOT NULL DEFAULT '',
			`revoked` tinyint UNSIGNED NOT NULL DEFAULT 0,
			`rotated_at` datetime DEFAULT NULL,
			`expires_at` datetime NOT NULL,
			`created_at` datetime NOT NULL,
			`last_used_at` datetime DEFAULT NULL,
			PRIMARY KEY  (`id`),
			UNIQUE KEY `token_hash` (`token_hash`),
			KEY `family_id` (`family_id`),
			KEY `user_client` (`user_id`,`client_id`),
			KEY `expires_at` (`expires_at`),
			KEY `type_revoked` (`type`,`revoked`)
		) $charset_collate;
	";

	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}

	dbDelta( $schema );

	update_option( 'us_mcp_oauth_db_version', US_MCP_OAUTH_DB_VERSION, TRUE );
}

// -----------------------------------------------------------------
// Clients
// -----------------------------------------------------------------

/**
 * @param string $client_id
 * @return array|NULL Client row with redirect_uris decoded, or NULL.
 */
function us_mcp_oauth_client_get( $client_id ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'clients' );
	$row = $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM `{$table}` WHERE `client_id` = %s LIMIT 1", (string) $client_id ),
		ARRAY_A
	);

	if ( ! $row ) {
		return NULL;
	}

	$uris = json_decode( (string) $row['redirect_uris'], TRUE );
	$row['redirect_uris'] = is_array( $uris ) ? $uris : array();

	return $row;
}

/**
 * Register a client (RFC 7591). Public clients get no secret.
 *
 * @param array $data client_name, redirect_uris, token_endpoint_auth_method.
 * @return array|NULL client_id + client_secret ('' for public), NULL on failure.
 */
function us_mcp_oauth_client_insert( $data ) {
	global $wpdb;

	$client_id = us_mcp_oauth_random_id();
	if ( $client_id === '' ) {
		return NULL;
	}

	$auth_method = ( ( $data['token_endpoint_auth_method'] ?? 'none' ) === 'client_secret_post' )
		? 'client_secret_post'
		: 'none';

	$client_secret = '';
	$secret_hash = NULL;
	if ( $auth_method === 'client_secret_post' ) {
		$client_secret = us_mcp_oauth_random_token();
		if ( $client_secret === '' ) {
			return NULL;
		}
		$secret_hash = us_mcp_oauth_hash( $client_secret );
	}

	$inserted = $wpdb->insert(
		us_mcp_oauth_table( 'clients' ),
		array(
			'client_id' => $client_id,
			'secret_hash' => $secret_hash,
			'client_name' => (string) ( $data['client_name'] ?? '' ),
			'redirect_uris' => (string) wp_json_encode( array_values( (array) ( $data['redirect_uris'] ?? array() ) ) ),
			'token_endpoint_auth_method' => $auth_method,
			'created_at' => us_mcp_oauth_now(),
		)
	);

	if ( ! $inserted ) {
		return NULL;
	}

	return array(
		'client_id' => $client_id,
		'client_secret' => $client_secret,
	);
}

/**
 * Marks the client as having completed an authorization, which is what keeps it
 * out of the "registered but never used" prune.
 *
 * @param string $client_id
 */
function us_mcp_oauth_client_touch( $client_id ) {
	global $wpdb;

	$wpdb->update(
		us_mcp_oauth_table( 'clients' ),
		array( 'last_used_at' => us_mcp_oauth_now() ),
		array( 'client_id' => (string) $client_id )
	);
}

/**
 * Drop clients that never authorized, and long-dormant ones with no tokens.
 * Runs after every registration so open DCR cannot grow the table forever.
 *
 * @return int Rows removed.
 */
function us_mcp_oauth_client_prune() {
	global $wpdb;

	$clients = us_mcp_oauth_table( 'clients' );
	$tokens = us_mcp_oauth_table( 'tokens' );

	$removed = (int) $wpdb->query(
		$wpdb->prepare(
			"DELETE FROM `{$clients}` WHERE `last_used_at` IS NULL AND `created_at` < %s",
			gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
		)
	);

	$removed += (int) $wpdb->query(
		$wpdb->prepare(
			"DELETE c FROM `{$clients}` c
		 LEFT JOIN `{$tokens}` t ON t.client_id = c.client_id AND t.revoked = 0 AND t.expires_at > %s
		 WHERE c.last_used_at IS NOT NULL AND c.last_used_at < %s AND t.id IS NULL",
			us_mcp_oauth_now(),
			gmdate( 'Y-m-d H:i:s', time() - 180 * DAY_IN_SECONDS )
		)
	);

	return $removed;
}

/**
 * @return int
 */
function us_mcp_oauth_client_count() {
	global $wpdb;

	$table = us_mcp_oauth_table( 'clients' );

	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
}

// -----------------------------------------------------------------
// Authorization codes
// -----------------------------------------------------------------

/**
 * @param array $args client_id, user_id, redirect_uri, code_challenge, scope, resource.
 * @return string|NULL The plaintext code, or NULL on failure.
 */
function us_mcp_oauth_code_insert( $args ) {
	global $wpdb;

	$code = us_mcp_oauth_random_token();
	if ( $code === '' ) {
		return NULL;
	}

	$inserted = $wpdb->insert(
		us_mcp_oauth_table( 'codes' ),
		array(
			'code_hash' => us_mcp_oauth_hash( $code ),
			'client_id' => (string) $args['client_id'],
			'user_id' => (int) $args['user_id'],
			'redirect_uri' => (string) $args['redirect_uri'],
			'code_challenge' => (string) $args['code_challenge'],
			'resource' => (string) ( $args['resource'] ?? '' ),
			'expires_at' => us_mcp_oauth_expiry( US_MCP_OAUTH_CODE_TTL ),
			'created_at' => us_mcp_oauth_now(),
		)
	);

	return $inserted ? $code : NULL;
}

/**
 * The UPDATE is the claim: checking rows_affected makes concurrent redemption
 * impossible without an explicit transaction, unlike SELECT-then-UPDATE.
 *
 * @param string $code
 * @return array|NULL Row, or NULL when unknown, expired or already used.
 */
function us_mcp_oauth_code_claim( $code ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'codes' );
	$hash = us_mcp_oauth_hash( $code );

	$wpdb->query(
		$wpdb->prepare(
			"UPDATE `{$table}` SET `used` = 1 WHERE `code_hash` = %s AND `used` = 0 AND `expires_at` > %s",
			$hash,
			us_mcp_oauth_now()
		)
	);

	if ( (int) $wpdb->rows_affected !== 1 ) {
		return NULL;
	}

	return $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM `{$table}` WHERE `code_hash` = %s LIMIT 1", $hash ),
		ARRAY_A
	);
}

/**
 * Raw lookup — only for detecting replay of an already-redeemed code.
 *
 * @param string $code
 * @return array|NULL
 */
function us_mcp_oauth_code_find( $code ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'codes' );

	return $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM `{$table}` WHERE `code_hash` = %s LIMIT 1", us_mcp_oauth_hash( $code ) ),
		ARRAY_A
	);
}

/**
 * Lets a later replay of the same code revoke exactly what it issued
 * (RFC 6749 §4.1.2).
 *
 * @param int $code_row_id
 * @param string $family_id
 */
function us_mcp_oauth_code_link_family( $code_row_id, $family_id ) {
	global $wpdb;

	$wpdb->update(
		us_mcp_oauth_table( 'codes' ),
		array( 'family_id' => (string) $family_id ),
		array( 'id' => (int) $code_row_id )
	);
}

// -----------------------------------------------------------------
// Tokens
// -----------------------------------------------------------------

/**
 * Passing an existing family_id makes this a rotation, not a new connection.
 *
 * @param array $args client_id, user_id, resource, family_id, family_created_at.
 * @return array|NULL access_token, refresh_token, family_id, expires_in.
 */
function us_mcp_oauth_token_issue_pair( $args ) {
	global $wpdb;

	$family_id = (string) ( $args['family_id'] ?? '' );
	if ( $family_id === '' ) {
		$family_id = us_mcp_oauth_random_id();
	}

	$access = us_mcp_oauth_random_token( 'usmcp_at_' );
	$refresh = us_mcp_oauth_random_token( 'usmcp_rt_' );

	if ( $family_id === '' OR $access === '' OR $refresh === '' ) {
		return NULL;
	}

	$now = us_mcp_oauth_now();
	$common = array(
		'family_id' => $family_id,
		'family_created_at' => (string) ( $args['family_created_at'] ?? $now ),
		'client_id' => (string) $args['client_id'],
		'user_id' => (int) $args['user_id'],
		'resource' => (string) ( $args['resource'] ?? '' ),
		'created_at' => $now,
	);

	$table = us_mcp_oauth_table( 'tokens' );

	$ok = (bool) $wpdb->insert(
		$table, $common + array(
			'token_hash' => us_mcp_oauth_hash( $access ),
			'type' => 'access',
			'expires_at' => us_mcp_oauth_expiry( US_MCP_OAUTH_ACCESS_TTL ),
		)
	);

	if ( $ok ) {
		$ok = (bool) $wpdb->insert(
			$table, $common + array(
				'token_hash' => us_mcp_oauth_hash( $refresh ),
				'type' => 'refresh',
				'expires_at' => us_mcp_oauth_expiry( US_MCP_OAUTH_REFRESH_TTL ),
			)
		);
	}

	if ( ! $ok ) {
		us_mcp_oauth_family_revoke( $family_id );

		return NULL;
	}

	return array(
		'access_token' => $access,
		'refresh_token' => $refresh,
		'family_id' => $family_id,
		'expires_in' => (int) US_MCP_OAUTH_ACCESS_TTL,
	);
}

/**
 * Returns revoked and expired rows too — reuse detection needs to see those.
 *
 * @param string $secret
 * @param string $type 'access' or 'refresh'.
 * @return object|NULL
 */
function us_mcp_oauth_token_find( $secret, $type ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'tokens' );

	return $wpdb->get_row(
		$wpdb->prepare(
			"SELECT * FROM `{$table}` WHERE `token_hash` = %s AND `type` = %s LIMIT 1",
			us_mcp_oauth_hash( $secret ),
			(string) $type
		)
	);
}

/**
 * Usable tokens only. Used by the bearer resolver.
 *
 * @param string $secret
 * @param string $type
 * @return object|NULL
 */
function us_mcp_oauth_token_get_by_secret( $secret, $type = 'access' ) {
	$row = us_mcp_oauth_token_find( $secret, $type );

	if (
		! $row
		OR (int) $row->revoked === 1
		OR $row->rotated_at !== NULL
		OR $row->expires_at <= us_mcp_oauth_now()
	) {
		return NULL;
	}

	return $row;
}

/**
 * Throttled to once per 5 minutes: this only feeds the "last used" column and
 * is not worth a write on every MCP call.
 *
 * @param object $row
 */
function us_mcp_oauth_token_touch( $row ) {
	global $wpdb;

	if ( $row->last_used_at !== NULL AND $row->last_used_at > gmdate( 'Y-m-d H:i:s', time() - 5 * MINUTE_IN_SECONDS ) ) {
		return;
	}

	$wpdb->update(
		us_mcp_oauth_table( 'tokens' ),
		array( 'last_used_at' => us_mcp_oauth_now() ),
		array( 'id' => (int) $row->id )
	);
}

/**
 * A zero row count means another request already rotated it — concurrent
 * redemption of a single-use credential, which the caller treats as replay.
 *
 * @param int $row_id
 * @return bool
 */
function us_mcp_oauth_token_claim_rotation( $row_id ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'tokens' );

	$wpdb->query(
		$wpdb->prepare(
			"UPDATE `{$table}` SET `rotated_at` = %s, `revoked` = 1 WHERE `id` = %d AND `rotated_at` IS NULL AND `revoked` = 0",
			us_mcp_oauth_now(),
			(int) $row_id
		)
	);

	return ( (int) $wpdb->rows_affected === 1 );
}

/**
 * @param string $family_id
 * @return int Rows affected — both types, live and rotated.
 */
function us_mcp_oauth_family_revoke( $family_id ) {
	global $wpdb;

	$table = us_mcp_oauth_table( 'tokens' );

	return (int) $wpdb->query(
		$wpdb->prepare(
			"UPDATE `{$table}` SET `revoked` = 1 WHERE `family_id` = %s",
			(string) $family_id
		)
	);
}

/**
 * One row per connection that still has a usable token. family_created_at is
 * carried on every row so "connected since" survives pruning of rotated rows.
 *
 * @return array[]
 */
function us_mcp_oauth_connections() {
	global $wpdb;

	// The connect UI calls this while the feature may still be off, and querying
	// a missing table would throw a database error onto the options screen.
	if ( (int) get_option( 'us_mcp_oauth_db_version', 0 ) < 1 ) {
		return array();
	}

	$tokens = us_mcp_oauth_table( 'tokens' );
	$clients = us_mcp_oauth_table( 'clients' );

	return (array) $wpdb->get_results(
		$wpdb->prepare(
			"SELECT t.family_id,
		        t.client_id,
		        t.user_id,
		        MIN(t.family_created_at) AS created_at,
		        MAX(t.last_used_at) AS last_used_at,
		        MAX(c.client_name) AS client_name,
		        SUM( CASE WHEN t.revoked = 0 AND t.expires_at > %s THEN 1 ELSE 0 END ) AS live
		 FROM `{$tokens}` t
		 LEFT JOIN `{$clients}` c ON c.client_id = t.client_id
		 GROUP BY t.family_id, t.client_id, t.user_id
		 HAVING live > 0
		 ORDER BY created_at DESC",
			us_mcp_oauth_now()
		), ARRAY_A
	);
}

/**
 * Hooked on deleted_user.
 *
 * @param int $user_id
 */
function us_mcp_oauth_purge_user( $user_id ) {
	global $wpdb;

	$tokens = us_mcp_oauth_table( 'tokens' );
	$codes = us_mcp_oauth_table( 'codes' );

	$wpdb->delete( $tokens, array( 'user_id' => (int) $user_id ), array( '%d' ) );
	$wpdb->delete( $codes, array( 'user_id' => (int) $user_id ), array( '%d' ) );
}

/**
 * Revoke without deleting the trail. Hooked on set_user_role when the new role
 * can no longer edit posts.
 *
 * @param int $user_id
 */
function us_mcp_oauth_revoke_user( $user_id ) {
	global $wpdb;

	$tokens = us_mcp_oauth_table( 'tokens' );

	$wpdb->query(
		$wpdb->prepare(
			"UPDATE `{$tokens}` SET `revoked` = 1 WHERE `user_id` = %d AND `revoked` = 0",
			(int) $user_id
		)
	);
}

/**
 * Revoked rows linger a week so reuse detection still fires on a stolen token
 * replayed shortly after the theft.
 */
function us_mcp_oauth_cleanup_expired() {
	global $wpdb;

	$codes = us_mcp_oauth_table( 'codes' );
	$tokens = us_mcp_oauth_table( 'tokens' );
	$now = us_mcp_oauth_now();
	$week_ago = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );

	$wpdb->query( $wpdb->prepare( "DELETE FROM `{$codes}` WHERE `expires_at` < %s", $now ) );

	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM `{$tokens}` WHERE `expires_at` < %s AND ( `revoked` = 0 OR `created_at` < %s )",
			$now,
			$week_ago
		)
	);

	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM `{$tokens}` WHERE `revoked` = 1 AND `created_at` < %s",
			gmdate( 'Y-m-d H:i:s', time() - ( US_MCP_OAUTH_REFRESH_TTL + 7 * DAY_IN_SECONDS ) )
		)
	);

	us_mcp_oauth_client_prune();
}
