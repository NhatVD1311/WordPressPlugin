<?php
/**
 * UpSolution MCP OAuth — constants, loader and hook wiring.
 *
 * Lets clients connect with nothing but the server URL. The MCP server itself
 * is untouched: the bearer is resolved to a WordPress user on
 * `determine_current_user`, so the existing transport gate and every
 * per-ability capability check apply unchanged. Application Passwords keep
 * working alongside.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

// The connect UI loads this file directly and may get here before bootstrap.
if ( ! defined( 'US_CORE_MCP_DIR' ) ) {
	define( 'US_CORE_MCP_DIR', US_CORE_DIR . 'mcp/' );
}

/** Bump to alter the schema; dbDelta then migrates in place. */
const US_MCP_OAUTH_DB_VERSION = 1;

/** Long enough for a browser redirect to reach the client, and no longer. */
const US_MCP_OAUTH_CODE_TTL = 5 * MINUTE_IN_SECONDS;

const US_MCP_OAUTH_ACCESS_TTL = HOUR_IN_SECONDS;
const US_MCP_OAUTH_REFRESH_TTL = 30 * DAY_IN_SECONDS;

/** One scope: the real boundary is the consenting user's WordPress role. */
const US_MCP_OAUTH_SCOPE = 'mcp';

/** Path form, not a query var: some clients append '?' + params blindly. */
const US_MCP_OAUTH_AUTHORIZE_SLUG = 'us-mcp-oauth/authorize';

const US_MCP_OAUTH_MAX_CLIENTS = 500;
const US_MCP_OAUTH_REG_BODY_MAX = 8192;

/**
 * Pull in the OAuth layer without registering anything — the connect UI needs
 * the helpers even when the MCP feature is off.
 */
function us_mcp_oauth_load() {
	static $loaded = FALSE;

	if ( $loaded ) {
		return;
	}
	$loaded = TRUE;

	require_once US_CORE_MCP_DIR . 'oauth/helpers.php';
	require_once US_CORE_MCP_DIR . 'oauth/storage.php';
	require_once US_CORE_MCP_DIR . 'oauth/authentication.php';
	require_once US_CORE_MCP_DIR . 'oauth/discovery.php';
	require_once US_CORE_MCP_DIR . 'oauth/endpoints.php';
	require_once US_CORE_MCP_DIR . 'oauth/authorize.php';
}

/**
 * Load and activate. Called from mcp/bootstrap.php only once the feature is on,
 * which is also what makes switching it off stop every live token: the resolver
 * below is simply never registered. The us_mcp_oauth_enabled filter works the
 * same way.
 */
function us_mcp_oauth_boot() {
	us_mcp_oauth_load();

	// Ahead of the switch: Disconnect must keep working with OAuth off, since
	// switching it back on revives every connection still listed.
	if ( is_admin() ) {
		require_once US_CORE_DIR . 'mcp/admin/connect-ajax.php';
	}

	/**
	 * Filters whether the MCP server offers OAuth sign-in: discovery documents,
	 * the consent screen and the register / token / revoke endpoints. Off, they
	 * all 404, tokens already issued stop working, and the server keeps working
	 * through Application Passwords only. Read on after_setup_theme, so add it
	 * from a plugin or the child theme's functions.php.
	 *
	 * Turning it back on revives every connection whose refresh token has not
	 * expired — disconnect them in Theme Options first if that is not wanted.
	 *
	 * @param bool $enabled
	 */
	if ( ! apply_filters( 'us_mcp_oauth_enabled', TRUE ) ) {
		return;
	}

	us_mcp_oauth_maybe_install();

	// Priority 30 — after core's auth cookie (10) and application password (20)
	// callbacks, so cookie and Basic auth always win.
	add_filter( 'determine_current_user', 'us_mcp_oauth_determine_current_user', 30 );

	// Priority 0: before rewrite matching, independent of the permalink setting.
	add_filter( 'do_parse_request', 'us_mcp_oauth_route_public_request', 0 );

	add_action( 'rest_api_init', 'us_mcp_oauth_register_rest_routes' );
	add_filter( 'rest_authentication_errors', 'us_mcp_oauth_bypass_rest_auth', 1 );
	add_filter( 'rest_pre_dispatch', 'us_mcp_oauth_enforce_bearer_route', 5, 3 );
	add_filter( 'rest_pre_dispatch', 'us_mcp_oauth_check_mcp_origin', 10, 3 );
	add_filter( 'rest_post_dispatch', 'us_mcp_oauth_filter_mcp_response', 10, 3 );

	add_action( 'deleted_user', 'us_mcp_oauth_purge_user' );
	add_action( 'set_user_role', 'us_mcp_oauth_handle_role_change', 10, 2 );

	add_action( 'init', 'us_mcp_oauth_schedule_cleanup', 20 );
	add_action( 'us_mcp_oauth_cleanup', 'us_mcp_oauth_cleanup_expired' );
}

/**
 * Serve the discovery documents and the consent screen from the site root.
 *
 * Prefix matching covers both the bare paths and the RFC 9728 / RFC 8414
 * path-insertion forms — correct because the site hosts exactly one resource.
 * When OAuth cannot run the paths fall through to a normal 404, so clients
 * conclude "no OAuth here" instead of starting a flow that cannot finish.
 *
 * @param bool $continue
 * @return bool
 */
function us_mcp_oauth_route_public_request( $continue ) {
	$path = (string) parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
	if ( $path === '' ) {
		return $continue;
	}

	if ( strpos( $path, '/.well-known/oauth-protected-resource' ) === 0 ) {
		if ( us_mcp_oauth_is_secure() ) {
			us_mcp_oauth_serve_protected_resource_metadata();
		}

		return $continue;
	}

	if ( strpos( $path, '/.well-known/oauth-authorization-server' ) === 0 ) {
		if ( us_mcp_oauth_is_secure() ) {
			us_mcp_oauth_serve_as_metadata();
		}

		return $continue;
	}

	if ( rtrim( $path, '/' ) === us_mcp_oauth_authorize_path() ) {
		us_mcp_oauth_handle_authorize();
	}

	return $continue;
}

/**
 * @return string Authorize path, no trailing slash.
 */
function us_mcp_oauth_authorize_path() {
	static $path = NULL;

	if ( $path === NULL ) {
		$path = rtrim( (string) parse_url( us_mcp_oauth_authorize_url(), PHP_URL_PATH ), '/' );
	}

	return $path;
}

/**
 * A role change that drops edit_posts kills that user's connections. Belt and
 * braces — refresh and the transport re-check the capability anyway.
 *
 * @param int $user_id
 * @param string $role
 */
function us_mcp_oauth_handle_role_change( $user_id, $role ) {
	if ( ! us_mcp_oauth_user_may_connect( $user_id ) ) {
		us_mcp_oauth_revoke_user( $user_id );
	}
}

/** Daily prune of expired codes and tokens. */
function us_mcp_oauth_schedule_cleanup() {
	if ( ! wp_next_scheduled( 'us_mcp_oauth_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'us_mcp_oauth_cleanup' );
	}
}
