<?php
/**
 * UpSolution MCP OAuth — RFC 9728 / RFC 8414 discovery documents.
 *
 * Served from do_parse_request, not rewrite rules: a rewrite needs a flush we
 * cannot reliably trigger and does nothing on Plain permalinks. Matching
 * REQUEST_URI works on stock nginx at any permalink setting, and on Apache
 * whenever a permalink structure is set — with Plain permalinks Apache never
 * routes these paths to index.php, which is why us_mcp_connect_oauth_ready()
 * treats that setting as fatal rather than cosmetic.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * @return string
 */
function us_mcp_oauth_documentation_url() {
	if ( ! defined( 'US_HELP_PORTAL_URL' ) OR ! defined( 'US_THEMENAME' ) ) {
		return '';
	}

	return US_HELP_PORTAL_URL . '/' . strtolower( US_THEMENAME ) . '/mcp-server/';
}

/**
 * RFC 9728 — which authorization server protects this MCP endpoint. Answered
 * identically for the bare and path-insertion forms: one resource per site.
 */
function us_mcp_oauth_serve_protected_resource_metadata() {
	$metadata = array(
		'resource' => us_mcp_oauth_resource_url(),
		'authorization_servers' => array( us_mcp_oauth_issuer() ),
		'scopes_supported' => array( US_MCP_OAUTH_SCOPE ),
		'bearer_methods_supported' => array( 'header' ),
		'resource_name' => sprintf(
			'UpSolution %s — %s',
			defined( 'US_THEMENAME' ) ? US_THEMENAME : 'MCP',
			(string) parse_url( us_mcp_oauth_issuer(), PHP_URL_HOST )
		),
	);

	if ( $docs = us_mcp_oauth_documentation_url() ) {
		$metadata['resource_documentation'] = $docs;
	}

	us_mcp_oauth_json_out( apply_filters( 'us_mcp_oauth_protected_resource_metadata', $metadata ), 200, TRUE );
}

/**
 * RFC 8414 — the authorization server itself.
 *
 * The issuer is the site origin, so this sits at the plain path clients try
 * first, while the endpoints it declares live under the plugin's REST
 * namespace. RFC 8414 fixes only where this document is found, which is why
 * /authorize and /token need not squat the site root and collide with pages.
 */
function us_mcp_oauth_serve_as_metadata() {
	$metadata = array(
		'issuer' => us_mcp_oauth_issuer(),
		'authorization_endpoint' => us_mcp_oauth_authorize_url(),
		'token_endpoint' => us_mcp_oauth_token_url(),
		'registration_endpoint' => us_mcp_oauth_register_url(),
		'revocation_endpoint' => us_mcp_oauth_revoke_url(),
		'revocation_endpoint_auth_methods_supported' => array( 'none', 'client_secret_post' ),
		'scopes_supported' => array( US_MCP_OAUTH_SCOPE ),
		'response_types_supported' => array( 'code' ),
		'response_modes_supported' => array( 'query' ),
		'grant_types_supported' => array( 'authorization_code', 'refresh_token' ),

		// client_secret_basic is absent on purpose: WordPress 401s a failed HTTP
		// Basic attempt before our handler runs.
		'token_endpoint_auth_methods_supported' => array( 'none', 'client_secret_post' ),

		'code_challenge_methods_supported' => array( 'S256' ),
		'authorization_response_iss_parameter_supported' => TRUE,
	);

	if ( $docs = us_mcp_oauth_documentation_url() ) {
		$metadata['service_documentation'] = $docs;
	}

	us_mcp_oauth_json_out( apply_filters( 'us_mcp_oauth_as_metadata', $metadata ), 200, TRUE );
}
