<?php
/**
 * UpSolution MCP OAuth — consent screen.
 *
 * Standalone document: it does not boot the theme and enqueues nothing, so no
 * theme or plugin can break the one screen the whole security model rests on.
 *
 * @var array $view Prepared by us_mcp_oauth_render_consent().
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title>Connect an AI assistant</title>
	<style>
		body {
			margin: 0;
			padding: 20px;
			display: flex;
			align-items: center;
			min-height: calc( 100vh - 40px );
			font: 15px/1.6 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			color: #1d2327;
			background: #f0f0f1;
		}
		.us-mcp-card {
			max-width: 400px;
			margin: 0 auto;
			padding: 2rem;
			background: #fff;
			border: 1px solid #dcdcde;
			border-radius: 5px;
			box-shadow: 0 1px 3px rgba(0, 0, 0, .06);
		}
		.us-mcp-card h1 {
			margin: 0 0 1rem;
			font-size: 20px;
			line-height: 1.3;
			font-weight: 600;
		}
		.us-mcp-card p {
			margin: 0 0 1rem;
		}
		.us-mcp-actions {
			display: flex;
			gap: 10px;
			align-items: center;
			margin-top: 1rem;
		}
		.us-mcp-btn {
			flex: 1 1 auto;
			padding: 10px 20px;
			border: 0;
			border-radius: 2px;
			font-size: inherit;
			line-height: inherit;
			font-weight: 600;
			text-align: center;
			text-decoration: none;
			cursor: pointer;
			background: #3858e9;
			color: #fff;
		}
		.us-mcp-btn:hover {
			background: #2145e6;
		}
		.us-mcp-link {
			flex: 0 0 auto;
			padding: 10px 20px;
			background: #f0f0f1;
			border-radius: 2px;
			color: inherit;
			text-decoration: none;
		}
		.us-mcp-link:hover {
			background: #ddd;
		}
	</style>
</head>
<body>
<div class="us-mcp-card">

	<?php if ( ! $view['may_authorize'] ) : ?>

		<h1>This account cannot connect</h1>
		<p>
			<?php
			printf(
				'You are signed in as %s, which cannot edit content, so the connection was not granted.',
				'<strong>' . esc_html( $view['user']->user_login ) . '</strong>'
			);
			?>
		</p>

		<div class="us-mcp-actions">
			<a class="us-mcp-btn" href="<?= esc_url( $view['switch_user_url'] ) ?>">Sign in as a different user</a>
			<a class="us-mcp-link" href="<?= esc_url( $view['cancel_url'] ) ?>">Cancel</a>
		</div>

	<?php else : ?>

		<h1>
			<?php
			printf(
				'%s wants to connect to "%s"',
				'<strong>' . esc_html( $view['client_name'] ) . '</strong>',
				esc_html( $view['site_name'] )
			);
			?>
		</h1>
		<p>
			<?php
			printf(
				'Approving this gives the application the same access to your site that you have as %s.',
				'<strong>' . esc_html( $view['user']->user_login ) . '</strong>'
			);
			?>
		</p>
		<p>
			<?php
			printf(
				'Approving sends the result to %s — cancel if that is not the app you expected.',
				'<strong>' . esc_html( $view['redirect_host'] ) . '</strong>'
			);
			?>
		</p>
		<p>You can disconnect it at any time in Theme Options.</p>

		<form method="post" action="<?= esc_url( $view['action'] ) ?>">
			<?php
			wp_nonce_field( 'us_mcp_oauth_consent' );

			// Every parameter is carried forward and re-validated on POST — the
			// checks already passed on GET are not treated as proven.
			foreach ( $view['params'] as $key => $value ) {
				if ( (string) $value === '' ) {
					continue;
				}
				printf(
					'<input type="hidden" name="%s" value="%s">',
					esc_attr( $key ),
					esc_attr( $value )
				);
			}
			?>
			<div class="us-mcp-actions">
				<button class="us-mcp-btn" type="submit" name="us_mcp_authorize" value="1">Authorize</button>
				<a class="us-mcp-link" href="<?= esc_url( $view['cancel_url'] ) ?>">Cancel</a>
			</div>
		</form>

	<?php endif; ?>

</div>
</body>
</html>
