<?php
/**
 * UpSolution MCP OAuth — bearer token to WordPress user.
 *
 * The whole integration with the existing MCP server: resolving the bearer on
 * `determine_current_user` means that by the time the transport gate and the
 * ability callbacks run, the consenting user is simply the current user.
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Current REST route in WP_REST_Server's form ('/upsolution/v1/mcp'), or ''.
 *
 * Must agree with what WP_REST_Server actually dispatches, or the bearer would
 * authenticate a route it was never scoped to. Sources, in WP::parse_request()'s
 * own order of precedence:
 *
 *   1. $wp->query_vars['rest_route'] — the value that gets dispatched. Only
 *      populated once parse_request() has run, which is AFTER WP::init() calls
 *      wp_get_current_user() and thus after determine_current_user fires.
 *   2. $_POST, then $_GET — core prefers both over the rewrite match, so
 *      reading only $_GET here would let a POST body redirect the dispatch
 *      while this function still reported the URL's route.
 *   3. The REQUEST_URI path minus the rest_url() prefix — the rewrite match.
 *      Derived from rest_url() rather than a hardcoded '/wp-json' to survive
 *      subdirectory installs and a filtered rest_url_prefix.
 *
 * @return string
 */
function us_mcp_oauth_current_rest_route() {
	static $route = NULL;
	static $is_final = FALSE;

	// Cache only the authoritative answer: an early caller must not freeze a
	// guess that parse_request() is about to contradict.
	if ( $route !== NULL AND $is_final ) {
		return $route;
	}

	$raw = NULL;

	if ( isset( $GLOBALS['wp'] ) AND isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
		$raw = $GLOBALS['wp']->query_vars['rest_route'];
		$is_final = TRUE;

	} elseif ( isset( $_POST['rest_route'] ) ) {
		$raw = $_POST['rest_route'];

	} elseif ( isset( $_GET['rest_route'] ) ) {
		$raw = $_GET['rest_route'];
	}

	if ( $raw !== NULL ) {
		// Present but not a string: not a route we can match, and casting an
		// array would emit a warning on a path that runs for every request.
		$route = is_scalar( $raw ) ? '/' . ltrim( (string) $raw, '/' ) : '';

	} else {
		$prefix = rtrim( (string) parse_url( rest_url( '/' ), PHP_URL_PATH ), '/' );
		$path = (string) parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );

		$route = ( $prefix !== '' AND strpos( $path, $prefix . '/' ) === 0 )
			? '/' . ltrim( substr( $path, strlen( $prefix ) ), '/' )
			: '';
	}

	$route = rtrim( $route, '/' );

	return $route;
}

/**
 * @return bool
 */
function us_mcp_oauth_is_mcp_request() {
	return ( us_mcp_oauth_current_rest_route() === '/upsolution/v1/mcp' );
}

/**
 * @return bool
 */
function us_mcp_oauth_is_own_rest_request() {
	return ( strpos( us_mcp_oauth_current_rest_route(), '/upsolution/v1/oauth/' ) === 0 );
}

/**
 * Whether this request can actually reach WP_REST_Server.
 *
 * `rest_route` is only ever dispatched from the front controller, because that
 * is the one entry point where WP::parse_request() runs. Other entry points —
 * admin-ajax.php above all — still resolve the current user, so without this
 * check a bearer token would authenticate any request that merely *names* the
 * MCP route in $_GET / $_POST, escaping the endpoint it is scoped to.
 *
 * REQUEST_URI is the raw request line, while the web server runs the script
 * its normalised path maps to: /wp-json/../wp-admin/admin-ajax.php passes the
 * prefix check below and still executes admin-ajax.php. So dot segments (also
 * percent-encoded) and the entry points that never dispatch REST are refused.
 *
 * @return bool
 */
function us_mcp_oauth_is_front_controller_request() {
	$path = rtrim( (string) parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );

	if (
		is_admin()
		OR wp_doing_ajax()
		OR wp_doing_cron()
		OR ( defined( 'XMLRPC_REQUEST' ) AND XMLRPC_REQUEST )
		OR preg_match( '~(^|[/\\\\])\.\.?([/\\\\]|$)~', rawurldecode( $path ) )
	) {
		return FALSE;
	}

	// Pretty-permalink form: everything under the rest_url() prefix.
	$prefix = rtrim( (string) parse_url( rest_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $prefix !== '' AND ( $path === $prefix OR strpos( $path, $prefix . '/' ) === 0 ) ) {
		return TRUE;
	}

	// Query-string form (?rest_route=…): the site root, index.php or not.
	$home = rtrim( (string) parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );

	return ( $path === $home OR $path === $home . '/index.php' );
}

/**
 * Three sources: CGI/FastCGI and some Apache configs drop the Authorization
 * header from $_SERVER but leave it visible to getallheaders().
 *
 * @return string
 */
function us_mcp_oauth_read_bearer_header() {
	$header = '';

	foreach ( array( 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ) as $key ) {
		if ( ! empty( $_SERVER[ $key ] ) ) {
			$header = (string) $_SERVER[ $key ];
			break;
		}
	}

	if ( $header === '' AND function_exists( 'getallheaders' ) ) {
		foreach ( (array) getallheaders() as $name => $value ) {
			if ( strtolower( (string) $name ) === 'authorization' ) {
				$header = (string) $value;
				break;
			}
		}
	}

	if ( stripos( $header, 'Bearer ' ) !== 0 ) {
		return '';
	}

	return trim( substr( $header, 7 ) );
}

/**
 * Request-scoped flag: a bearer arrived and was rejected. Drives
 * error="invalid_token" and the self-test's header probe.
 *
 * A flag rather than an inline transient write: the resolver runs inside
 * _wp_get_current_user(), where an option write could re-enter user resolution
 * through another plugin's update_option hook.
 *
 * @param bool $set
 * @return bool
 */
function us_mcp_oauth_invalid_token_flag( $set = FALSE ) {
	static $flag = FALSE;

	if ( $set ) {
		$flag = TRUE;
	}

	return $flag;
}

/**
 * Request-scoped flag: the current user was resolved from a bearer token.
 *
 * @param bool $set
 * @return bool
 */
function us_mcp_oauth_bearer_user_flag( $set = FALSE ) {
	static $flag = FALSE;

	if ( $set ) {
		$flag = TRUE;
	}

	return $flag;
}

/**
 * Resolve `Authorization: Bearer …` to the consenting user.
 *
 * The token's own user and nothing else — there is deliberately no fallback to
 * an administrator, so every `current_user_can()` downstream evaluates against
 * a real identity. `edit_posts` is not checked here either: that stays
 * single-sourced in us_mcp_permission_callback(), which gives a demoted user a
 * correct 403 rather than a misleading 401.
 *
 * @param int|false $user_id
 * @return int|false
 */
function us_mcp_oauth_determine_current_user( $user_id ) {
	if (
		! empty( $user_id )
		OR ! us_mcp_oauth_is_front_controller_request()
		OR ! us_mcp_oauth_is_mcp_request()
	) {
		return $user_id;
	}

	$bearer = us_mcp_oauth_read_bearer_header();
	if ( $bearer === '' ) {
		return $user_id;
	}

	$row = us_mcp_oauth_token_get_by_secret( $bearer, 'access' );
	if ( ! $row OR ! get_userdata( (int) $row->user_id ) ) {
		us_mcp_oauth_invalid_token_flag( TRUE );

		return $user_id;
	}

	us_mcp_oauth_token_touch( $row );
	us_mcp_oauth_bearer_user_flag( TRUE );

	return (int) $row->user_id;
}

/**
 * Confine a bearer-resolved user to the MCP route.
 *
 * us_mcp_oauth_current_rest_route() has to guess at determine_current_user
 * time, because WP::init() resolves the user before parse_request() knows the
 * route. This runs once the route is settled and $request->get_route() is the
 * value WP_REST_Server is actually about to dispatch, so it cannot be
 * desynchronised from the URL by any request parameter.
 *
 * @param mixed            $result
 * @param WP_REST_Server   $server
 * @param WP_REST_Request  $request
 * @return mixed
 */
function us_mcp_oauth_enforce_bearer_route( $result, $server, $request ) {
	if ( $result !== NULL OR ! us_mcp_oauth_bearer_user_flag() ) {
		return $result;
	}

	if ( rtrim( (string) $request->get_route(), '/' ) === '/upsolution/v1/mcp' ) {
		return $result;
	}

	wp_set_current_user( 0 );
	us_mcp_oauth_log( sprintf( 'bearer token presented on non-MCP route %s', $request->get_route() ) );

	return new WP_Error(
		'us_mcp_forbidden_route',
		'This token is only valid for the MCP endpoint.',
		array( 'status' => 401 )
	);
}

/**
 * RFC 9728 §5.1 challenge. Without resource_metadata, clients such as Claude
 * and ChatGPT treat the 401 as a dead end instead of starting the flow.
 *
 * @return string
 */
function us_mcp_oauth_www_authenticate_value() {
	$value = sprintf(
		'Bearer realm="%s", resource_metadata="%s"',
		esc_attr( (string) parse_url( us_mcp_oauth_issuer(), PHP_URL_HOST ) ),
		esc_url_raw( us_mcp_oauth_resource_metadata_url() )
	);

	if ( us_mcp_oauth_invalid_token_flag() ) {
		$value .= ', error="invalid_token", error_description="The access token is expired, revoked or unknown."';
	}

	return $value;
}

/**
 * Attach the challenge and the cache headers the MCP route needs.
 *
 * The adapter adds its own rest_post_dispatch closure from inside dispatch(),
 * i.e. before this hook runs, so both callbacks fire.
 *
 * @param WP_REST_Response $response
 * @param WP_REST_Server $server
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function us_mcp_oauth_filter_mcp_response( $response, $server, $request ) {
	if ( ! ( $response instanceof WP_REST_Response ) ) {
		return $response;
	}

	$route = rtrim( (string) $request->get_route(), '/' );
	if ( $route !== '/upsolution/v1/mcp' ) {
		return $response;
	}

	$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, private' );
	$response->header( 'Vary', 'Authorization' );

	if ( (int) $response->get_status() === 401 ) {
		$response->header( 'WWW-Authenticate', us_mcp_oauth_www_authenticate_value() );
	}

	// Deferred out of the resolver — see us_mcp_oauth_invalid_token_flag().
	if ( us_mcp_oauth_invalid_token_flag() ) {
		set_transient( 'us_mcp_oauth_auth_header_seen', time(), MINUTE_IN_SECONDS );
	}

	return $response;
}

/**
 * DNS-rebinding guard. Every target client reaches the endpoint server-side and
 * sends no Origin, so this costs nothing and stops a browser page being pointed
 * at a local install through a rebound hostname.
 *
 * @param mixed $result
 * @param WP_REST_Server $server
 * @param WP_REST_Request $request
 * @return mixed
 */
function us_mcp_oauth_check_mcp_origin( $result, $server, $request ) {
	if ( $result !== NULL ) {
		return $result;
	}

	$route = rtrim( (string) $request->get_route(), '/' );
	if ( $route !== '/upsolution/v1/mcp' ) {
		return $result;
	}

	$origin = trim( (string) $request->get_header( 'origin' ) );
	if ( $origin === '' OR strtolower( $origin ) === 'null' ) {
		return $result;
	}

	$parts = (array) parse_url( $origin );
	$normalised = strtolower( (string) ( $parts['scheme'] ?? '' ) ) . '://' . strtolower( (string) ( $parts['host'] ?? '' ) );
	if ( ! empty( $parts['port'] ) ) {
		$normalised .= ':' . (int) $parts['port'];
	}

	$allowed = (array) apply_filters( 'us_mcp_allowed_origins', array( us_mcp_oauth_issuer() ) );
	foreach ( $allowed as $candidate ) {
		if ( strcasecmp( (string) $candidate, $normalised ) === 0 ) {
			return $result;
		}
	}

	return new WP_Error(
		'us_mcp_forbidden_origin',
		'Requests from this origin are not accepted.',
		array( 'status' => 403 )
	);
}

/**
 * Without this, rest_application_password_check_errors() (priority 90) turns a
 * client sending HTTP Basic credentials to /token into a hard 401 before our
 * handler runs. A non-empty value at priority 1 makes it return early.
 *
 * @param WP_Error|true|null $result
 * @return WP_Error|true|null
 */
function us_mcp_oauth_bypass_rest_auth( $result ) {
	global $wp_rest_application_password_status;

	if ( $result !== NULL OR ! us_mcp_oauth_is_own_rest_request() ) {
		return $result;
	}

	// Only short-circuit when core is actually about to 401 over a failed HTTP
	// Basic attempt. Returning TRUE unconditionally would also skip
	// rest_cookie_check_errors() at priority 100 — the REST nonce check, which
	// is core's only CSRF defence for cookie-authenticated requests.
	if ( ! is_wp_error( $wp_rest_application_password_status ) ) {
		return $result;
	}

	return TRUE;
}
