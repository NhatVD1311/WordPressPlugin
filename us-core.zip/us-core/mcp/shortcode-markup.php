<?php
/**
 * UpSolution MCP — canonical form of hand-written shortcode markup.
 *
 * Agents write post_content by hand, and two habits that look harmless break
 * WordPress's parsing silently (no notice, the page still loads):
 *
 *   1. A raw `]` inside a quoted attribute value. get_shortcode_regex() does
 *      not respect quotes, so the tag ends at that `]`: the rest of the
 *      attribute list prints on the page as text and the element falls back
 *      to defaults. Live Builder stores brackets as `{` / `}` (backtick, brace,
 *      backtick), which the shortcode handler decodes before rendering.
 *   2. Attributes wrapped onto separate lines. wpautop() turns each line break
 *      between attributes into `<br />`, and shortcode_parse_atts() drops every
 *      attribute that is followed by it.
 *
 * us_mcp_normalize_shortcode_markup() rewrites both into the form Live Builder
 * saves. It only touches the opening tags of `us_*` / `vc_*` shortcodes; line
 * breaks inside a quoted value (us_itext `texts`) and content between tags are
 * kept byte for byte. Brackets are escaped only in values that contain a `]`
 * (those are broken anyway), so a value with a lone `[` — which parses fine and
 * which code reading raw attributes may rely on — is left as it is.
 *
 * Pure PHP, no WordPress calls: the docs lint (scripts/llms) loads this file
 * too and flags every fenced example the function would change.
 */

/**
 * @param string $content Shortcode markup.
 * @return array {
 *     @type string $content The canonical markup (equal to the input when nothing changed).
 *     @type array  $changes One entry per fix: { type: 'line_break'|'bracket', tag: string, offset: int }.
 *                           `offset` is the byte offset in the INPUT string.
 * }
 */
function us_mcp_normalize_shortcode_markup( $content ) {
	$s = (string) $content;
	$len = strlen( $s );
	$out = '';
	$changes = array();
	$i = 0;

	while ( $i < $len ) {
		$open = strpos( $s, '[', $i );
		if ( $open === FALSE ) {
			$out .= substr( $s, $i );
			break;
		}
		$out .= substr( $s, $i, $open - $i );
		if ( ! preg_match( '~\G\[((?:us|vc)_[A-Za-z0-9_-]*)~', $s, $m, 0, $open ) ) {
			$out .= '[';
			$i = $open + 1;
			continue;
		}
		$tag = $m[1];
		$out .= $m[0];
		$j = $open + strlen( $m[0] );
		$after_eq = FALSE; // the last non-whitespace character was `=`

		// Walk the attribute list up to the `]` that closes the opening tag.
		while ( $j < $len ) {
			$c = $s[ $j ];

			if ( $c === ']' ) {
				$out .= ']';
				$j ++;
				break;
			}

			// Whitespace run between attributes: a line break in it is the
			// wpautop trap — collapse the run to one space (none before `]`).
			if ( strpos( " \t\r\n", $c ) !== FALSE ) {
				$run = strspn( $s, " \t\r\n", $j );
				$ws = substr( $s, $j, $run );
				if ( strpbrk( $ws, "\r\n" ) !== FALSE ) {
					$next = $s[ $j + $run ] ?? '';
					$out .= ( $next === ']' ) ? '' : ' ';
					$changes[] = array( 'type' => 'line_break', 'tag' => $tag, 'offset' => $j );
				} else {
					$out .= $ws;
				}
				$j += $run;
				continue;
			}

			// Quoted value: copy it, escaping brackets when it holds a raw `]`.
			// Only a quote right after `=` opens a value (as in shortcode_parse_atts()),
			// so a stray quote elsewhere in the tag is copied as a plain character.
			if ( ( $c === '"' OR $c === "'" ) AND $after_eq ) {
				$after_eq = FALSE;
				$close = strpos( $s, $c, $j + 1 );
				if ( $close === FALSE ) {
					// Unterminated value — the markup is broken beyond repair here.
					$out .= substr( $s, $j );
					$j = $len;
					break;
				}
				$value = substr( $s, $j + 1, $close - $j - 1 );
				// A "value" holding another tag means an unescaped quote inside the
				// real value made it run past the tag end — escaping would swallow
				// the following shortcodes, so treat the quote as a plain character.
				if ( preg_match( '~\[(?:us_|vc_|/)~', $value ) ) {
					$out .= $c;
					$j ++;
					continue;
				}
				if ( strpos( $value, ']' ) !== FALSE ) {
					for ( $k = 0, $vl = strlen( $value ); $k < $vl; $k ++ ) {
						if ( $value[ $k ] === '[' OR $value[ $k ] === ']' ) {
							$changes[] = array( 'type' => 'bracket', 'tag' => $tag, 'offset' => $j + 1 + $k );
						}
					}
					$value = str_replace( array( '[', ']' ), array( '`{`', '`}`' ), $value );
				}
				$out .= $c . $value . $c;
				$j = $close + 1;
				continue;
			}

			$after_eq = ( $c === '=' );
			$out .= $c;
			$j ++;
		}
		$i = $j;
	}

	return array( 'content' => $out, 'changes' => $changes );
}

/**
 * Short agent-facing summary of what us_mcp_normalize_shortcode_markup() fixed,
 * or NULL when it changed nothing.
 *
 * @param array $changes
 * @return array|NULL { line_breaks_joined: int, brackets_escaped: int, tags: string[], note: string }
 */
function us_mcp_shortcode_markup_report( array $changes ) {
	if ( empty( $changes ) ) {
		return NULL;
	}
	$joined = $escaped = 0;
	$tags = array();
	foreach ( $changes as $change ) {
		if ( $change['type'] === 'line_break' ) {
			$joined ++;
		} else {
			$escaped ++;
		}
		$tags[ $change['tag'] ] = TRUE;
	}

	$fixes = array();
	if ( $joined ) {
		$fixes[] = 'line breaks between a tag\'s attributes were joined (wpautop would turn them into <br /> and drop those attributes)';
	}
	if ( $escaped ) {
		$fixes[] = '[ ] inside quoted values were escaped as `{` / `}` (a raw ] ends the shortcode)';
	}

	return array(
		'line_breaks_joined' => $joined,
		'brackets_escaped' => $escaped,
		'tags' => array_keys( $tags ),
		'note' => 'The saved post_content differs from what you sent: ' . implode( ' and ', $fixes ) . '. Write markup in this form next time; re-read the post before patching the touched tags.',
	);
}
