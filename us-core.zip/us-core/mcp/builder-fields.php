<?php
/**
 * UpSolution MCP — shared USOF field validation for the JSON builders.
 *
 * The Header Builder (abilities/headers.php) and the Grid Builder
 * (abilities/grid-layouts.php) store element params and builder options as
 * USOF field values. Both validate agent input against the same field configs
 * (config/elements/<type>.php, config/header-settings.php,
 * config/grid-settings.php), so the spec builders and value checkers live here.
 *
 * @package usCore\Mcp
 */

defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Ordered responsive state keys: default, laptops, tablets, mobiles.
 *
 * @return string[]
 */
function us_mcp_builder_states() {
	return (array) us_get_responsive_states( /* only_keys */ TRUE );
}

/**
 * Read a config the way the builder's edit form sees it.
 *
 * Some option lists are built only on an editing page (ACF fields of the custom field select,
 * image sizes, taxonomies — see us_is_elm_editing_page()), so in the MCP request they are empty
 * or incomplete and valid values would be rejected. The config is reloaded once per request
 * with the editing context forced on, together with the shared param packs element configs
 * include (config/elements_*.php, e.g. the custom field list of display conditions), since
 * those may already be cached in the non-editing form.
 *
 * @param string $path us_config() path, e.g. "elements/post_custom_field" or "grid-settings.options"
 * @param mixed $default
 * @return mixed
 */
function us_mcp_builder_editing_config( $path, $default = array() ) {
	static $reloaded = array();
	$config_names = array( strtok( $path, '.' ) );
	if ( empty( $reloaded ) ) {
		foreach ( (array) glob( US_CORE_DIR . 'config/elements_*.php' ) as $file ) {
			array_unshift( $config_names, basename( $file, '.php' ) );
		}
	}
	// Own callback, so removing it never drops the same filter added by someone else
	$force_editing = function () {
		return TRUE;
	};
	add_filter( 'usb_is_builder_page', $force_editing );
	foreach ( $config_names as $config_name ) {
		if ( ! isset( $reloaded[ $config_name ] ) ) {
			us_config( $config_name, array(), /* reload */ TRUE );
			$reloaded[ $config_name ] = TRUE;
		}
	}
	remove_filter( 'usb_is_builder_page', $force_editing );

	return us_config( $path, $default );
}

/**
 * Build a validation spec from one USOF field config. Returns NULL for
 * presentational fields that carry no stored value. Recurses into `group`
 * repeaters (socials items, dropdown links, conditions, custom_html_atts).
 *
 * @param array $field
 * @return array|null
 */
function us_mcp_builder_field_spec( $field ) {
	$field = (array) $field;
	$type = isset( $field['type'] ) ? (string) $field['type'] : 'text';
	if ( in_array( $type, array( 'heading', 'message', 'wrapper_start', 'wrapper_end', 'hr', 'copy_paste' ), TRUE ) ) {
		return NULL;
	}

	// Grouped selects (optgroups, e.g. the custom field select) are flattened to one key list
	$options = array();
	foreach ( (array) ( $field['options'] ?? array() ) as $key => $label ) {
		if ( is_array( $label ) ) {
			unset( $label['__group_label__'] );
			$options += $label;
		} else {
			$options[ $key ] = $label;
		}
	}

	$spec = array(
		'type' => $type,
		'options' => $options,
		'with_gradient' => ! ( array_key_exists( 'with_gradient', $field ) AND $field['with_gradient'] === FALSE ),
		'is_responsive' => ! empty( $field['is_responsive'] ),
		'is_multiple' => ! empty( $field['is_multiple'] ),
		'dynamic_values' => ! empty( $field['dynamic_values'] ),
		'exclude_dynamic_colors' => (string) ( $field['exclude_dynamic_colors'] ?? '' ),
		'std' => $field['std'] ?? '',
	);
	if ( $type === 'group' ) {
		$spec['sub'] = array();
		foreach ( (array) us_arr_path( $field, 'params', array() ) as $sub_name => $sub_field ) {
			$sub_spec = us_mcp_builder_field_spec( $sub_field );
			if ( $sub_spec !== NULL ) {
				$spec['sub'][ $sub_name ] = $sub_spec;
			}
		}
	}

	return $spec;
}

/**
 * Validation spec for builder options (header-settings.options / grid-settings.options),
 * flattened across option groups and keyed by option name.
 *
 * @param string $config_path
 * @return array
 */
function us_mcp_builder_option_spec( $config_path ) {
	static $cache = array();
	if ( isset( $cache[ $config_path ] ) ) {
		return $cache[ $config_path ];
	}
	$spec = array();
	foreach ( (array) us_mcp_builder_editing_config( $config_path ) as $group => $opts ) {
		foreach ( (array) $opts as $name => $opt ) {
			$fspec = us_mcp_builder_field_spec( $opt );
			if ( $fspec !== NULL ) {
				$spec[ $name ] = $fspec;
			}
		}
	}

	return $cache[ $config_path ] = $spec;
}

/**
 * Validation spec for one element type's params in a builder context
 * ("header" or "grid"). Params limited to other contexts are left out,
 * the same way the builder's edit form hides them.
 *
 * @param string $type
 * @param string $context
 * @return array
 */
function us_mcp_builder_element_param_spec( $type, $context ) {
	static $cache = array();
	if ( isset( $cache[ $context ][ $type ] ) ) {
		return $cache[ $context ][ $type ];
	}
	$spec = array();
	foreach ( (array) us_mcp_builder_editing_config( 'elements/' . $type . '.params' ) as $name => $field ) {
		if ( isset( $field['context'] ) AND ! in_array( $context, (array) $field['context'], TRUE ) ) {
			continue;
		}
		$fspec = us_mcp_builder_field_spec( $field );
		if ( $fspec !== NULL ) {
			$spec[ $name ] = $fspec;
		}
	}

	return $cache[ $context ][ $type ] = $spec;
}

/**
 * Whether the value is a dynamic value token like "{{the_thumbnail}}" or "{{acf_field}}".
 *
 * @param mixed $value
 * @return bool
 */
function us_mcp_builder_is_dynamic_token( $value ) {
	return is_string( $value ) AND preg_match( '/^\{\{[^{}]+\}\}$/', trim( $value ) );
}

/**
 * Validate / normalise a single scalar value against a USOF field spec.
 *
 * @param array $spec one entry from an option / element param spec
 * @param mixed $value
 * @param string $label human-readable field name for error messages
 * @return mixed|WP_Error
 */
function us_mcp_builder_check_scalar( $spec, $value, $label ) {
	$type = isset( $spec['type'] ) ? $spec['type'] : 'text';
	switch ( $type ) {
		case 'switch':
			if ( is_bool( $value ) ) {
				return $value ? 1 : 0;
			}
			if ( $value === 1 OR $value === 0 ) {
				return $value;
			}
			if ( $value === '1' OR $value === '0' ) {
				return (int) $value;
			}
			if ( $value === '' OR $value === NULL ) {
				return 0;
			}

			return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s" is a switch — pass 1/0 or true/false.', $label ), array( 'status' => 400 ) );

		case 'radio':
		case 'select':
			$keys = array_map( 'strval', array_keys( (array) $spec['options'] ) );
			if ( empty( $keys ) ) {
				/**
				 * Some selects have no option list even in the editing context (built elsewhere in JS),
				 * we can't enforce the enum here — fall back to mild string validation.
				 */
				return us_mcp_builder_check_text( $value, $label );
			}
			$sval = is_scalar( $value ) ? (string) $value : NULL;
			if ( $sval === NULL OR ! in_array( $sval, $keys, TRUE ) ) {
				return new WP_Error(
					'us_mcp_field_bad_value',
					sprintf( 'Field "%s" must be one of: %s.', $label, implode( ', ', $keys ) ),
					array( 'status' => 400 )
				);
			}

			return $sval;

		case 'color':
			// A custom field color like "{{color_field}}", offered by the builder's color list
			if (
				us_mcp_builder_is_dynamic_token( $value )
				AND $spec['exclude_dynamic_colors'] !== 'all'
				AND strpos( $spec['exclude_dynamic_colors'], 'custom_field' ) === FALSE
			) {
				return trim( $value );
			}
			if ( ! function_exists( 'us_mcp_palette_check_color' ) ) {
				return is_scalar( $value ) ? (string) $value : '';
			}

			return us_mcp_palette_check_color( $value, ! empty( $spec['with_gradient'] ), $label );

		case 'upload':
			if ( $value === '' OR $value === NULL ) {
				return '';
			}
			if ( ! empty( $spec['dynamic_values'] ) AND us_mcp_builder_is_dynamic_token( $value ) ) {
				return trim( $value );
			}
			if ( is_int( $value ) OR ( is_string( $value ) AND ctype_digit( $value ) ) ) {
				return (int) $value;
			}
			// Multiple images (e.g. image_slider ids) are stored as comma-separated attachment ids
			if ( ! empty( $spec['is_multiple'] ) ) {
				$ids = is_array( $value ) ? $value : explode( ',', (string) $value );
				$ids = array_map( 'trim', $ids );
				if ( $ids AND count( array_filter( $ids, 'ctype_digit' ) ) === count( $ids ) ) {
					return implode( ',', $ids );
				}
			}
			if ( is_string( $value ) AND ( strpos( $value, 'http' ) === 0 OR strpos( $value, '/' ) === 0 ) ) {
				return $value;
			}

			return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s" must be an attachment id (upsolution-list-media) or an image URL.', $label ), array( 'status' => 400 ) );

		case 'link':
			return us_mcp_builder_encode_link( $value, $label );

		case 'design_options':
			/**
			 * The element "Design" CSS param: a responsive map { state: { css-prop: value } },
			 * stored verbatim as a nested array. This is how per-element font-size / padding /
			 * colors are controlled. Pass "" / {} to clear.
			 */
			if ( $value === '' OR $value === NULL OR $value === array() ) {
				return '';
			}
			if ( ! is_array( $value ) ) {
				return new WP_Error( 'us_mcp_field_bad_css', sprintf( 'Field "%s" (Design css) must be an object keyed by responsive state, e.g. {"default":{"font-size":"18px"}}.', $label ), array( 'status' => 400 ) );
			}
			$css_states = us_mcp_builder_states();
			$css = array();
			foreach ( $value as $css_state => $props ) {
				if ( ! in_array( $css_state, $css_states, TRUE ) ) {
					return new WP_Error( 'us_mcp_field_bad_state', sprintf( 'Field "%s": "%s" is not a responsive state (%s).', $label, $css_state, implode( ', ', $css_states ) ), array( 'status' => 400 ) );
				}
				if ( ! is_array( $props ) ) {
					return new WP_Error( 'us_mcp_field_bad_css', sprintf( 'Field "%s": state "%s" must be an object of CSS property => value.', $label, $css_state ), array( 'status' => 400 ) );
				}
				$clean = array();
				foreach ( $props as $prop => $pval ) {
					if ( ! is_scalar( $pval ) ) {
						return new WP_Error( 'us_mcp_field_bad_css', sprintf( 'Field "%s": "%s.%s" must be a string or number.', $label, $css_state, $prop ), array( 'status' => 400 ) );
					}
					$pval = trim( (string) $pval );
					if ( preg_match( '/[\r\n\t]/', $pval ) ) {
						return new WP_Error( 'us_mcp_field_bad_css', sprintf( 'Field "%s": "%s.%s" must not contain line breaks or tabs.', $label, $css_state, $prop ), array( 'status' => 400 ) );
					}
					$clean[ (string) $prop ] = $pval;
				}
				if ( $clean ) {
					$css[ $css_state ] = $clean;
				}
			}

			return $css;

		case 'checkboxes':
			/**
			 * A set of option keys (e.g. hide_on_states). Accept an array or a comma-separated
			 * string; store comma-separated (the USOF shape).
			 */
			if ( $value === '' OR $value === NULL OR $value === array() ) {
				return '';
			}
			$tokens = is_array( $value ) ? $value : explode( ',', (string) $value );
			$allowed = array_map( 'strval', array_keys( (array) $spec['options'] ) );
			$picked = array();
			foreach ( $tokens as $tok ) {
				$tok = trim( (string) $tok );
				if ( $tok === '' ) {
					continue;
				}
				if ( $allowed AND ! in_array( $tok, $allowed, TRUE ) ) {
					return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s": "%s" is not an allowed option (%s).', $label, $tok, implode( ', ', $allowed ) ), array( 'status' => 400 ) );
				}
				$picked[] = $tok;
			}

			return implode( ',', $picked );

		case 'html':
			/**
			 * HTML fields are stored as base64( rawurlencode( html ) ) — the shape the USOF
			 * html field writes and templates/elements/html.php decodes.
			 */
			if ( $value === '' OR $value === NULL ) {
				return '';
			}
			if ( ! is_scalar( $value ) ) {
				return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s" must be an HTML string.', $label ), array( 'status' => 400 ) );
			}

			return base64_encode( rawurlencode( (string) $value ) );

		case 'textarea':
		case 'editor':
			// Multi-line text, line breaks are allowed
			if ( $value === NULL ) {
				return '';
			}
			if ( ! is_scalar( $value ) ) {
				return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s" must be a string.', $label ), array( 'status' => 400 ) );
			}

			return trim( (string) $value );

		case 'slider':
		case 'text':
		case 'icon':
		default:
			return us_mcp_builder_check_text( $value, $label );
	}
}

/**
 * Mild string validation shared by slider / text / icon fields and by
 * option-less selects: coerce a scalar to a trimmed string, reject line
 * breaks / tabs, and treat null as "clear".
 *
 * @param mixed $value
 * @param string $label
 * @return string|WP_Error
 */
function us_mcp_builder_check_text( $value, $label ) {
	if ( $value === NULL ) {
		return '';
	}
	if ( ! is_scalar( $value ) ) {
		return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Field "%s" must be a string or number.', $label ), array( 'status' => 400 ) );
	}
	$value = trim( (string) $value );
	if ( preg_match( '/[\r\n\t]/', $value ) ) {
		return new WP_Error( 'us_mcp_field_bad_value_chars', sprintf( 'Field "%s" must not contain line breaks or tabs.', $label ), array( 'status' => 400 ) );
	}

	return $value;
}

/**
 * Validate a param value, transparently handling responsive { state: value }
 * inputs (stored as rawurlencode(json) the way us_get_responsive_values reads).
 *
 * @param array $spec
 * @param mixed $value
 * @param string $label
 * @return mixed|WP_Error
 */
function us_mcp_builder_check_param( $spec, $value, $label ) {
	if ( isset( $spec['type'] ) AND $spec['type'] === 'group' ) {
		return us_mcp_builder_check_group( $spec, $value, $label );
	}
	if ( ! empty( $spec['is_responsive'] ) AND is_array( $value ) ) {
		$states = us_mcp_builder_states();
		$out = array();
		foreach ( $value as $state => $v ) {
			if ( ! in_array( $state, $states, TRUE ) ) {
				return new WP_Error( 'us_mcp_field_bad_state', sprintf( 'Field "%s": "%s" is not a responsive state (%s).', $label, $state, implode( ', ', $states ) ), array( 'status' => 400 ) );
			}
			$cv = us_mcp_builder_check_scalar( $spec, $v, $label . ' [' . $state . ']' );
			if ( is_wp_error( $cv ) ) {
				return $cv;
			}
			$out[ $state ] = $cv;
		}
		if ( ! isset( $out['default'] ) ) {
			return new WP_Error( 'us_mcp_field_bad_value', sprintf( 'Responsive field "%s" must include a "default" state.', $label ), array( 'status' => 400 ) );
		}

		return rawurlencode( wp_json_encode( $out ) );
	}

	return us_mcp_builder_check_scalar( $spec, $value, $label );
}

/**
 * Validate a `group` repeater value (socials items, dropdown links,
 * custom_html_atts, conditions): an ordered list of rows, each row an object
 * whose keys are validated against the group's sub-param spec. Stored as a
 * plain array of associative arrays (matching the builder). Pass "" / [] to clear.
 *
 * @param array $spec group spec with a `sub` map
 * @param mixed $value
 * @param string $label
 * @return array|WP_Error
 */
function us_mcp_builder_check_group( $spec, $value, $label ) {
	if ( $value === '' OR $value === NULL OR $value === array() ) {
		return array();
	}
	if ( ! is_array( $value ) ) {
		return new WP_Error( 'us_mcp_field_bad_group', sprintf( 'Field "%s" must be an array of rows (objects).', $label ), array( 'status' => 400 ) );
	}
	$sub = isset( $spec['sub'] ) ? (array) $spec['sub'] : array();
	$rows = array();
	foreach ( array_values( $value ) as $i => $row ) {
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'us_mcp_field_bad_group', sprintf( 'Field "%s": row %d must be an object.', $label, $i ), array( 'status' => 400 ) );
		}
		$clean = array();
		foreach ( $row as $k => $v ) {
			if ( $sub AND ! isset( $sub[ $k ] ) ) {
				return new WP_Error( 'us_mcp_field_bad_group', sprintf( 'Field "%s": row %d has unknown key "%s" (allowed: %s).', $label, $i, $k, implode( ', ', array_keys( $sub ) ) ), array( 'status' => 400 ) );
			}
			$sub_spec = isset( $sub[ $k ] ) ? $sub[ $k ] : array( 'type' => 'text' );
			$cv = us_mcp_builder_check_param( $sub_spec, $v, $label . '[' . $i . '].' . $k );
			if ( is_wp_error( $cv ) ) {
				return $cv;
			}
			$clean[ (string) $k ] = $cv;
		}
		$rows[] = $clean;
	}

	return $rows;
}

/**
 * Encode a link value into the rawurlencoded-JSON shape builder elements store.
 * Dynamic links are plain objects too, e.g. {"type":"post"} or
 * {"type":"custom_field","custom_field":"…"}.
 *
 * @param mixed $value array {url,…} | JSON string | plain URL | ''
 * @param string $label
 * @return string|WP_Error
 */
function us_mcp_builder_encode_link( $value, $label ) {
	if ( $value === '' OR $value === NULL ) {
		return '';
	}
	if ( is_array( $value ) ) {
		return rawurlencode( wp_json_encode( $value ) );
	}
	if ( is_string( $value ) ) {
		$t = trim( $value );
		if ( $t === '' ) {
			return '';
		}
		if ( $t[0] === '{' ) {
			if ( json_decode( $t, TRUE ) === NULL ) {
				return new WP_Error( 'us_mcp_field_bad_link', sprintf( 'Field "%s": link JSON could not be parsed.', $label ), array( 'status' => 400 ) );
			}

			return rawurlencode( $t );
		}
		if ( stripos( $t, '%7b' ) === 0 ) {
			return $t; // already rawurlencoded JSON
		}

		return rawurlencode( wp_json_encode( array( 'url' => $t ) ) );
	}

	return new WP_Error( 'us_mcp_field_bad_link', sprintf( 'Field "%s": link must be an object {url,…}, a JSON string or a URL.', $label ), array( 'status' => 400 ) );
}

/**
 * Equality test tolerant of array values (socials items, dropdown links, …):
 * scalars compare as strings, arrays compare by their JSON encoding.
 *
 * @param mixed $a
 * @param mixed $b
 * @return bool
 */
function us_mcp_builder_values_equal( $a, $b ) {
	if ( is_array( $a ) OR is_array( $b ) ) {
		return wp_json_encode( $a ) === wp_json_encode( $b );
	}

	return (string) $a === (string) $b;
}

/**
 * Next free "type:N" id for a given element type in a settings array.
 *
 * @param array $settings expanded settings
 * @param string $type
 * @return string
 */
function us_mcp_builder_next_elm_id( $settings, $type ) {
	$max = 0;
	foreach ( array_keys( (array) us_arr_path( $settings, 'data', array() ) ) as $elm_id ) {
		if ( strtok( $elm_id, ':' ) === $type ) {
			$n = (int) substr( $elm_id, strlen( $type ) + 1 );
			if ( $n > $max ) {
				$max = $n;
			}
		}
	}

	return $type . ':' . ( $max + 1 );
}
