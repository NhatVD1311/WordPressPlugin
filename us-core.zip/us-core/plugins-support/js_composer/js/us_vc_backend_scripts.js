/**
 * Since WPBakery's customization options are limited, it implements
 * add-on functionality on side JS. This approach is not stable,
 * but there are no other solutions yet.
 */
! function( $, _undefined ) {
	"use strict";

	$( () => {

		// Fixed error when "win.getSelection()" returns null #4423, #4866
		if ( $ush.isFirefox && typeof window.init_textarea_html === 'function' ) {
			window.init_textarea_html = $ush.debounce( window.init_textarea_html, 700 );
		}

	} );

	/**
	 * The handler is called every time the panel for adding elements is opened.
	 *
	 * Note: The implementation of this functionality is based on the inner workings
	 * of the script and has no public documentation or support.
	 *
	 * @deps /wp-content/plugins/js_composer/assets/js/dist/backend.min.js
	 */
	function showAddElementPanel() {
		const self = this;
		var model = self.model,
			iteration = 0;
		// Get all parents relative to current tag
		var parents = [];
		while( !! model && iteration++ < /* number of max iterations */1000 ) {
			const tag = model.get( 'shortcode' );
			if ( ( vc.getMapped( tag ) || {} ).is_container ) {
				parents.push( tag );
			}
			model = vc.shortcodes.get( model.get( 'parent_id' ) ); // next parent model
		}
		// Hide all containers of the same type since nesting in itself is prohibited
		$( '[data-vc-ui-element][data-is-container=true]', self.$el ).each( ( _, node ) => {
			const $node = $( node );
			var tag = $node.data( 'element' );
			// Check the nesting of elements `vc_tta_*`
			// if ( tag.indexOf( 'vc_tta_' ) > -1 && parents.join().indexOf( 'vc_tta_' ) > -1 ) {
			// 	$node.css( 'display', 'none' );
			// 	return;
			// }
			// Support for nesting of the second row through `vc_row_inner`
			if ( tag === 'vc_row' && parents.includes( tag ) ) {
				tag = 'vc_row_inner';
			}
			if ( tag.indexOf( 'vc_row' ) > -1 ) {
				const isVisible = ! parents.includes( tag );
				$node.toggleClass( 'vc_visible', isVisible ).data( 'us_fixVisible', isVisible );
			}
		} );
	}

	/**
	 * Category switching in the elements panel.
	 *
	 * @deps showAddElementPanel()
	 */
	function categorySwitchingInElementsPanel() {
		const self = this;
		const $rowElement = $( 'li[data-element=vc_row]', self.$content );

		// Specifies whether the `vc_row` element should be displayed within a category.
		if ( $rowElement.hasClass( 'vc_visible' ) && $rowElement.data( 'us_fixVisible' ) === false ) {
			$rowElement.removeClass( 'vc_visible' );
		}
	}

	$( () => {
		// Check loaded Visual Composer
		if ( $ush.isUndefined( window.vc ) ) {
			return;
		}

		// After initialization, subscribe to WPBakery events.
		vc.events.on( 'app.render', () => {
			vc.add_element_block_view
				.on( 'show', showAddElementPanel )
				.on( 'tabChange', $ush.debounce( categorySwitchingInElementsPanel, 10 ) )

			// Copied the functionality from the 'attach_image' field type to 'us_upload'
			// for displaying a preview image for admin. Note: Important field name must be 'image'
			if ( vc.atts[ 'attach_image' ] ) {
				vc.atts[ 'us_upload' ] = _.clone( vc.atts[ 'attach_image' ] );
			}

			var cancelSortable = false;

			// Undo dragging "vc_row_inner" to "vc_row_inner" for Visual Composer
			// https://api.jqueryui.com/sortable
			vc.app.$content
				.on( 'sortbeforestop', ( _, ui ) => {
					cancelSortable = (
						ui.item.data( 'element_type' ) === 'vc_row_inner'
						&& $ush.toArray( ui.placeholder.closest( '[data-element_type=vc_row_inner]' ) ).length
					);
				} )
				.on( 'sortstop', ( e ) => {
					if ( cancelSortable ) {
						e.preventDefault();
					}
				} );
		} );

		// Disabled preview of element with parameter "conditions_operator=never"
		vc.events.on( 'shortcodes:sync shortcodes:update', ( shortcode ) => {
			const $viewEl = shortcode.view.$el;
			const className = 'usb_display_never';

			if ( shortcode.getParam( 'conditions_operator' ) === 'never' ) {
				$viewEl.addClass( className );

			} else if ( $viewEl.hasClass( className ) ) {
				$viewEl.removeClass( className )
			}
		} );

	} );

	// Toggle the group item settings by a click on its bar, as WPBakery binds that only to the arrow control
	$( document ).on( 'click', '.vc_param_group-controls', function( e ) {
		// Skip the drag icon and the buttons, as those have their own handlers
		if ( $( e.target ).closest( '.vc_move-param, .vc_row_edit_clone_delete' ).length ) {
			return;
		}
		$( '.vc_control.column_toggle', this ).trigger( 'click' );
	} );

	// Support for adding examples to the field for Visual Composer
	$( document ).on( 'click', '.usof-example', ( e ) => {
		e.preventDefault();
		e.stopPropagation();

		var $target = $( e.target ).closest( 'span' );
		$( 'input[type="text"]', $target.closest( '.edit_form_line:not(.usof-not-live)' ) )
			.val( $target.html() )
			.trigger( 'change' );
	} );

}( jQuery );

/**
 * Drag and drop fixes for WPBakery Page Builder since version 9.0,
 * where the drag and drop was rewritten.
 *
 * Note: The implementation of this functionality is based on the inner workings
 * of the script and has no public documentation or support.
 *
 * @deps /wp-content/plugins/js_composer/assets/js/dist/backend.min.js
 */
! function( $ ) {
	"use strict";

	$( () => {

		/**
		 * Allow moving elements into and out of theme containers, like Wrapper.
		 *
		 * WPBakery shows the drop line only if the target container has the same shortcode
		 * as the current parent of the moved element, with several hardcoded exceptions for
		 * its own columns and tabs. So the check is extended by any container that outputs
		 * the ".wpb_column_container" area for children and accepts the moved element.
		 */
		if ( typeof WpbDOMElement !== 'undefined' ) {
			const originalIsChild = WpbDOMElement.prototype.isChild;
			WpbDOMElement.prototype.isChild = function( target ) {
				if ( originalIsChild.apply( this, arguments ) ) {
					return true;
				}
				const movedModel = this.options.model,
					targetModel = target ? target.options.model : null;
				if (
					! movedModel
					|| ! targetModel
					|| ! target.$node.find( '> * > .wpb_column_container' ).length
				) {
					return false;
				}
				return !! vc.checkRelevance( targetModel.get( 'shortcode' ), movedModel.get( 'shortcode' ) );
			};
		}

		/**
		 * Skip the check of the moved element position, when the pointer position is unknown.
		 *
		 * WPBakery runs that check on every page scroll, even before the first mouse move,
		 * which throws "elementFromPoint" errors on non-finite coordinates.
		 */
		if ( typeof WpbDndDataSet !== 'undefined' ) {
			const originalCheckItems = WpbDndDataSet.prototype.checkItems;
			WpbDndDataSet.prototype.checkItems = function( point ) {
				if ( ! point || ! Number.isFinite( point.x ) || ! Number.isFinite( point.y ) ) {
					return;
				}
				return originalCheckItems.apply( this, arguments );
			};
		}

	} );

}( jQuery );

/**
 * Paste Section for WPBakery Page Builder.
 */
! function( $, undefined ) {
	"use strict";

	/**
	 * @class US_VC_PasteSection - Class for import shortcodes into the WPBakery Page Builder.
	 */
	function US_VC_PasteSection() {
		const self = this;

		// Elements
		self.$window = $( '.us-paste-section-window:first' );
		self.$pasteButton = $( '.vc_ui-button-action', self.$window );
		self.$input = $( 'textarea', self.$window );
		self.$errMessage = $( '.vc_description', self.$window );

		// Private "Variables"
		self.data = $ush.toPlainObject( $ush.getPassedData( self.$window ) );

		// Bindable events
		self._events = {
			showPopup: self.showPopup.bind( self ),
			hidePopup: self.hidePopup.bind( self ),
			insertShortcodeToContent: self.insertShortcodeToContent.bind( self ),
		};

		// Event
		$( document )
			.on( 'click', '.vc_icon-btn.for_us_paste_section', self._events.showPopup )
			.on( 'click', '.vc_ui-button-action', self._events.insertShortcodeToContent )
			.on( 'click', '.us-paste-section-window:first .vc_ui-close-button', self._events.hidePopup );
	};

	// US_VC_PasteSection API
	US_VC_PasteSection.prototype = {

		/**
		 * Show popup to enter copied code.
		 *
		 * @event handler
		 * @param {Event} e The Event interface represents an event which takes place in the DOM.
		 */
		showPopup: function( e ) {
			const self = this;

			self._hideError();
			self.$window.show();
			self.$input[0].focus();

			// Prevent execution of WPBakery paste action while our Paste Row/Section window is open
			// Note: adding event to #wpwrap since WPBakery adding its event to body. This way we ensure our event fires first
			$( '#wpwrap' ).on( 'paste.upsolution', ( e ) => {
				if ( $( e.target ).closest( '#wpb_wpbakery, .vc_ui-panel-window' ).length ) {
					e.stopPropagation();
					e.preventDefault();
				}
			} );

			// WPBakery is checking if it should add its Paste action on each click,
			// so we trigger a click on our input to disable their Paste action
			self.$input.trigger( 'click' );

			e.stopPropagation();
			e.preventDefault();
		},

		/**
		 * Hide popup to enter copied code.
		 *
		 * @event handler
		 */
		hidePopup: function() {
			const self = this;
			self.$window.hide();
			self.$input.val( '' );
			if ( self.$pasteButton.hasClass( 'loading' ) ) {
				self.$input.prop( 'disabled', false );
				self.$pasteButton.removeClass( 'loading' );
			}

			// Remove our execution block for WPBakery Paste action (added in the showPopup function)
			$( '#wpwrap' ).off( 'paste.upsolution' );
		},

		/**
		 * Insert shortcode at the end of the post_content.
		 *
		 * @event handler
		 */
		insertShortcodeToContent: function() {
			const self = this;
			var value = $ush.toString( self.$input.val() ).trim();
			if ( ! self.isValueValid( value ) ) {
				return;
			}
			value = self.applyFilters( value );
			$.each( vc.storage.parseContent( {}, value ), ( _, model ) => {
				if ( model && model.hasOwnProperty( 'shortcode' ) ) {
					vc.shortcodes.create( model ); // insert content
					self.hidePopup();
				}
			} );
		},

		/**
		 * Apply filters to value.
		 *
		 * @return {String} Returns values after applying filters.
		 */
		applyFilters: function( value ) {
			const self = this;
			const placeholder = $ush.toString( self.data.placeholder );

			value = $ush.toString( value )
				// Search and replace use:placeholder
				.replace( /use:placeholder/g, placeholder )
				// Replace images for new design options
				.replace( /css="([^\"]+)"/g, ( matches, match ) => {
					if ( match ) {
						var jsoncss = $ush.toString( $ush.rawurldecode( match ) )
							.replace( /("background-image":")(.*?)(")/g, ( _, before, id, after ) => {
								if ( id && ! $ush.parseInt( id ) ) {
									id = placeholder;
								}
								return before + id + after;
							} );
						return 'css="' + $ush.rawurlencode( jsoncss ) + '"';
					}
					return matches;
				} )
				// Check the post_type parameter
				.replace( /\s?post_type="(.*?)"/g, ( match, post_type ) => {
					if ( self.data.grid_post_types.indexOf( post_type ) === - 1 ) {
						return ' post_type="post"'; // default
					}
					return match;
				} );

			// Remove [us_post_content..] if post_type is not us_content_template
			if ( self.data.post_type !== 'us_content_template' ) {
				value = value.replace( /(\[us_post_content.*?])/g, '' );
			}

			// Import grid layout
			value = value.replace( /(grid_layout_data="([^"]+)")/g, ( text ) => {
				const matches = text.match( /grid_layout_data="([^"]+)/i );
				return 'items_layout="' + self.importShortcodeData( $ush.toString( matches[1] ) ) + '"';
			} );

			return value;
		},

		/**
		 * Import Shortcode Data.
		 *
		 * @param {String} post_content The post content.
		 * @return {String} Returns imported content.
		 */
		importShortcodeData: function( post_content ) {
			const self = this;
			var output = '';
			self.$input.prop( 'disabled', true );
			self.$pasteButton.addClass( 'loading' );
			$.ajax( {
				type: 'POST',
				url: $usof.ajaxUrl,
				async: false,
				data: {
					_nonce: $ush.toString( self.$window.data( 'nonce' ) ),
					action: 'us_import_shortcode_data',
					post_type: 'us_grid_layout',
					post_content: post_content,
				},
				dataType: 'json',
				success: ( res ) => {
					if ( res.success || res.hasOwnProperty( 'data' ) ) {
						output = $ush.toString( res.data );
					}
				},
				error: console.error
			} );
			return output;
		},

		/**
		 * Check if the value is valid.
		 *
		 * @param {String} value The value to check.
		 * @return {Boolean} True if valid, False otherwise.
		 */
		isValueValid: function( value ) {
			const self = this;
			// Add notice if the text is empty
			if ( value === '' ) {
				self._showError( self.data.errors.empty );
				return false;
			}
			// Add a notification if the text does not contain the shortcode [vc_row ... [/vc_row]
			if ( !/\[vc_row([\s\S]*)\/vc_row\]/gim.test( value ) ) {
				self._showError( self.data.errors.not_valid );
				return false;
			}
			self._hideError();
			return true;
		},

		/**
		 * Show error message.
		 *
		 * @param {String} message Error text.
		 */
		_showError: function( message ) {
			this.$errMessage.text( message ).show();
		},

		/**
		 * Hide error message.
		 */
		_hideError: function() {
			this.$errMessage.text( '' ).hide();
		}
	};

	// Init US_VC_PasteSection
	$( () => new US_VC_PasteSection );

}( jQuery );
