/**
 * Compatibility and support for USOF in WPBakery Page Builder.
 */
! function( $, _undefined ) {
	"use strict";

	window.$usof = window.$usof || {};

	/**
	 * @type {RegExp} Regular expression for find space.
	 */
	const REGEXP_SPACE = /\p{Zs}/gu;

	/**
	 * @type {[]} All initialized usofField objects.
	 */
	var _allFieldObjects = {};

	// Functionality for $usof.field compatibility in WPBakery.
	if ( typeof $usof.field === 'function' ) {
		/**
		 * Get the related field.
		 *
		 * @return {$usof.field|undefined} Returns the related field object, otherwise undefined.
		 */
		$usof.field.prototype.getRelatedField = function() {
			const self = this;

			var relatedOn = $ush.toString( self.relatedOn );
			if ( ! relatedOn ) {
				return; // undefined
			}

			// WPBakery, the fields in the group contain a prefix of the group name, so we adjust it for compatibility.
			// relatedOn: `{group_name}|{param_name}` to `{group_name}_{param_name}`
			var $field = self.$row.closest( '.vc_shortcode-param' ),
				$relatedField = $( `[data-name="${relatedOn.replace( '|', '_' )}"]:first`, $field.parent() ),
				usofField = $relatedField.data( 'usofField' );
			// Set name without a group? relatedOn: {group_name}|{param_name}
			if ( relatedOn.indexOf( '|' ) > -1 ) {
				usofField.name = relatedOn.split( '|' )[/* param_name */1] || relatedOn;
			}

			return usofField;
		};

		/**
		 * Get field object by its name.
		 *
		 * @param {String} name The name.
		 * @return {$usof.field|undefined} Returns a reference to a field object by its name, otherwise undefined.
		 */
		$usof.field.prototype.getFieldByName = ( name ) => {
			if ( name && _allFieldObjects[ name ] instanceof $usof.field ) {
				return _allFieldObjects[ name ];
			}
			return;
		};
	}

	/**
	 * Initializes the usof Field.
	 */
	function initField() {
		const $usofField = $( this );
		if ( $usofField.data( 'usofField' ) ) {
			return;
		}
		const usofField = $usofField.usofField();
		if ( usofField instanceof $usof.field ) {

			// Force value for WPBakery Page Builder.
			if ( usofField.type === 'design_options' ) {
				usofField.forceWPBValue()
			}

			usofField.trigger( 'beforeShow' );
			usofField.setValue( usofField.$input.val() );

			// For related fields, we fire an event to apply the value from this field.
			// Note: In $usof.field['autocomplete'] loads the default items.
			if ( usofField.relatedOn ) {
				var relatedField = usofField.getRelatedField();
				if ( relatedField instanceof $usof.field ) {
					relatedField.trigger( 'change' );
				}
			}

			// Run click event to initialize all group settings
			if ( $( 'input.wpb_vc_param_value[name=offset]' ).length == 0 ) {
				var isActive = false;
				$.each( $( '.vc_ui-tabs-line button' ).toArray().reverse(), () => {
					if ( isActive ) {
						return;
					}
					var $tabButton = $( this ),
						vcElementTarget = $tabButton.data( 'vc-ui-element-target' );
					if ( $ush.isUndefined( vcElementTarget ) ) {
						return;
					}
					if ( $( vcElementTarget ).hasClass( 'vc_active' ) ) {
						$tabButton.trigger( 'click' );
						isActive = true;
					}
				} );
			}

			// Save a reference to the field object by name.
			_allFieldObjects[ usofField.name ] = usofField;

			// Support usof fields for the "Auto Save" feature.
			// Fields that keep their value in a hidden input (autocomplete, color, design_options)
			// change it without a DOM event, so WPBakery never learns about the edit and does not
			// save it. For such fields we relay the usof event to the edit form.
			if ( window.vc_auto_save ) {
				// The value WPBakery already knows about, so the relay is skipped both for the
				// events of the panel initialization and for the fields that fire a DOM event
				// on their own, which WPBakery listens to without any help.
				var lastKnownValue = usofField.$input.val();
				usofField.$input.on( 'change', () => {
					lastKnownValue = usofField.$input.val();
				} );
				// Note: The delay lets the DOM event of the field fire first, if the field has one.
				usofField.on( 'change', $ush.debounce( () => {
					var value = usofField.$input.val();
					if ( value === lastKnownValue ) {
						return;
					}
					lastKnownValue = value;
					usofField.$row.closest( '.vc_edit-form-tab' ).trigger( 'change' );
				}, 1 ) );
			}
		}
	}
	$( '.vc_ui-panel-window.vc_active [data-name]' ).each( initField );

	/**
	 * Apply compound `show_if` conditions, e.g. [ [ 'param_1', '=', 'value' ], 'and', [ 'param_2', '!=', 'value' ] ].
	 * A WPBakery dependency describes a relation to a single other field, so such conditions come
	 * in the `us_show_if` param setting and are evaluated by the USOF condition engine here.
	 */
	function applyCompoundShowIf() {
		const fieldset = ( $usof.mixins || {} ).Fieldset;
		if ( $ush.isUndefined( fieldset ) ) {
			return;
		}
		const $panel = $( '.vc_ui-panel-window.vc_active' );
		$( '.vc_shortcode-param', $panel ).each( ( _, param ) => {
			const $param = $( param ),
				settings = $param.data( 'param_settings' ) || {};
			if ( $ush.isUndefined( settings.us_show_if ) ) {
				return;
			}
			// The fields of a group item have the group name prefix, e.g. "items_source",
			// and only the fields of the same item are used for the condition
			const $groupItem = $param.closest( '.vc_param_group-wrapper' ),
				$scope = $groupItem.length ? $groupItem : $panel,
				prefix = $groupItem.length
					? ( $groupItem.closest( '.wpb_el_type_param_group' ).data( 'param_settings' ) || {} ).param_name + '_'
					: '',
				$input = ( name ) => $( `[name="${prefix}${name}"]`, $scope );

			// USOF fields keep their value in a hidden input, which fires "change" for WPBakery
			const getValue = ( name ) => $input( name ).val(),
				updateVisibility = () => {
					$param.toggleClass( 'vc_dependent-hidden', ! fieldset.executeShowIf( settings.us_show_if, getValue ) );
				},
				eventName = 'change.us_show_if_' + settings.param_name;

			fieldset.getShowIfVariables( settings.us_show_if ).forEach( ( name ) => {
				$input( name )
					.off( eventName )
					.on( eventName, updateVisibility );
			} );

			updateVisibility();
		} );
	}
	applyCompoundShowIf();

	/**
	 * This handler is required to initialize the USOF fields in each new element of the group.
	 * Note: This handler is an internal callback mechanism that is not documented and is subject to change.
	 *
	 * @type {Function}
	 * @param {Node} $newParam This is a new group param.
	 * @param {String} action The action name.
	 */
	window._usVcParamGroupAfterAddParam = $ush.debounce( ( $newParam, action ) => {
		if ( action == 'new' || action == 'clone' ) {
			$( '.usof-form-row[data-name]', $newParam ).each( initField );
			applyCompoundShowIf();
		}
	}, 1 );

	/**
	 * @type {Function} Handler that implements the `show_if: [ 'param_name', 'str_contains', 'value' ]` functionality on the WPBakery side.
	 */
	window.us_str_contains_callback = function() {
		$( '.vc_ui-panel-window.vc_active .vc_shortcode-param' ).each( ( i, field ) => {
			var $field = $( field ),
				field_settings = $field.data( 'param_settings' );
			if (
				! $ush.isUndefined( field_settings.dependency )
				&& ! $ush.isUndefined( field_settings.dependency.callback )
				&& field_settings.dependency.callback == 'us_str_contains_callback'
			) {
				// Found the field that has this callback
				var relatedFieldName = field_settings.dependency.callback_element,
					$relatedField = $( `.vc_ui-panel-window.vc_active [name="${relatedFieldName}"]` ),
					needle = field_settings.dependency.needle;

				$relatedField.on( 'change', () => {
					var relatedValue = $relatedField.val();
					$field.toggleClass( 'vc_dependent-hidden', ! relatedValue.includes( needle ) );
				} );

				$relatedField.trigger( 'change' );
			}
		} );
	};

	// Finds all fields of WPBakery Page Builder type `param_group`
	$( '.vc_ui-panel-window.vc_active .wpb_el_type_param_group' ).each( function( _, node ) {
		// Slight delay to get data after initialization
		$ush.timeout( () => {
			var vcParamObject = $( node ).data( 'vcParamObject' ) || {};
			if ( $.isPlainObject( vcParamObject.options ) ) {
				$.extend( vcParamObject.options, {
					param: {
						callbacks: {
							after_add: '_usVcParamGroupAfterAddParam'
						}
					}
				} );
			}
		}, 800 );
	} );

	/**
	 * @class USIconSetValue USOF Field: Icon for WPBakery Page Builder.
	 * @param {Node} $container The container.
	 */
	function USIconSetValue( $container ) {
		var $select = $( '.us-icon-select', $container ),
			$input = $( '.us-icon-text', $container ),
			$value = $( '.us-icon-value', $container ),
			$previewWrap = $( '.us-icon-preview', $container ),
			icon_set = $select.val(),
			icon_name = $input.val().trim(),
			icon_val = '';
		if ( icon_name != '' ) {
			if ( icon_set == 'material' ) {
				icon_name = icon_name.replace( REGEXP_SPACE, '_' );
			}
			icon_val = icon_set + '|' + icon_name;
		}
		// Rebuild the preview <i> from scratch via the shared builder (usof/js/_general.js), which maps
		// fakit-* sets to their real FA6/7 classes and tags theme FA5 icons with data-fa-i2svg. Mutating
		// the cached <i> in place broke with a connected SVG/JS-mode kit — its loader replaces the node
		// with an <svg>, so the cached reference went stale — and raw fakit-* slugs aren't CSS classes.
		var previewTag = '';
		if ( icon_name != '' && $usof.mixins && $usof.mixins.Fieldset ) {
			previewTag = $usof.mixins.Fieldset.prepareIconTag( icon_set + '|' + icon_name.replace( /fa-\dx/gi, ' ' ) );
		}
		$previewWrap.html( previewTag || '<i class="material-icons"></i>' );
		$value.val( icon_val );
	};

	$( '.us-icon-select' ).off( 'change' ).on( 'change', function() {
		var $select = $( this ),
			$container = $select.closest( '.us-icon' ),
			$descContainer = $container.siblings( '.us-icon-desc:first' ),
			$selectedOption = $( ":selected", $select ),
			$setLink = $( '.us-icon-set-link', $descContainer );
		if ( $selectedOption.length ) {
			$setLink.attr( 'href', $selectedOption.data( 'info-url' ) );
		}
		USIconSetValue( $container );
	} );

	$( '.us-icon-text' ).off( 'change keyup' ).on( 'change keyup', function() {
		var $input = $( this ),
			$container = $input.closest( '.us-icon' ),
			val = $input.val();
		if ( val.toLowerCase().replace( REGEXP_SPACE, '' ) !== val ) {
			$input.val( $ush.toLowerCase( val ).trim() );
		}
		USIconSetValue( $container );
	} );

}( jQuery );
