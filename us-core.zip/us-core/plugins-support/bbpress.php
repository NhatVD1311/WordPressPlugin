<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * bbPress Support
 *
 * @link https://bbpress.org/
 */

if ( ! class_exists( 'bbPress' ) ) {
	return;
}

add_action( 'wp_enqueue_scripts', 'us_bbpress_enqueue_styles', 14 );
function us_bbpress_enqueue_styles( $styles ) {
	wp_dequeue_style( 'bbp-default' );

	global $us_template_directory_uri;
	$min_ext = defined( 'US_DEV' ) ? '' : '.min';
	if (
		defined( 'US_DEV' )
		OR ! us_get_option( 'optimize_assets' )
		OR usb_is_post_preview()
	) {
		wp_enqueue_style( 'us-bbpress', $us_template_directory_uri . '/common/css/plugins/bbpress' . $min_ext . '.css', array(), US_THEMEVERSION, 'all' );
	}
}

// Remove Forum summaries
add_filter( 'bbp_get_single_forum_description', '__return_false', 10, 2 );
add_filter( 'bbp_get_single_topic_description', '__return_false', 10, 2 );

// Output the bbPress trail for the [us_breadcrumbs] element on forum / topic / reply pages
if ( ! function_exists( 'us_bbp_breadcrumbs_output' ) ) {

	add_filter( 'us_breadcrumbs_output', 'us_bbp_breadcrumbs_output', 10, 2 );

	/**
	 * @param string|null $output The output provided by another handler (if any)
	 * @param array $ctx Breadcrumbs context passed from the element template
	 * @return string|null Rendered trail, or the untouched $output when not a bbPress singular page
	 */
	function us_bbp_breadcrumbs_output( $output, $ctx ) {
		if ( ! function_exists( 'bbp_get_breadcrumb' ) OR ! is_singular( array( 'topic', 'forum', 'reply' ) ) ) {
			return $output;
		}

		$atts = $ctx['atts'];
		$item_atts = $ctx['item_atts'];

		// bbPress builds its own trail and doesn't honor "Show current page" — hide the last crumb via CSS
		$show_current = ! empty( $ctx['show_current'] );
		if ( ! $show_current ) {
			$atts['class'] .= ' hide_current';
		}

		// Microdata markup (BreadcrumbList), same as the theme trail
		if ( ! empty( $ctx['schema'] ) ) {
			$atts['itemscope'] = '';
			$atts['itemtype'] = 'http://schema.org/BreadcrumbList';

			$item_atts['itemscope'] = '';
			$item_atts['itemprop'] = 'itemListElement';
			$item_atts['itemtype'] = 'http://schema.org/ListItem';
		}

		$item_before = '<div' . us_implode_atts( $item_atts ) . '>';

		/**
		 * bbPress glues crumbs as "sep + crumb_after + crumb_before", i.e. the separator ends up inside the item,
		 * so the item wrappers are moved into the separator itself to keep the theme markup:
		 * item, separator, item... (the separator must be a direct child of the nav for the theme CSS)
		 */
		$bbp_args = array(
			'before' => '<nav' . us_implode_atts( $atts ) . '>' . $item_before,
			'after' => '</div></nav>',
			'sep' => '</div>' . $ctx['delimiter'] . $item_before,
			'sep_before' => '',
			'sep_after' => '',
			'pad_sep' => 0,
			'crumb_before' => '',
			'crumb_after' => '',
		);

		/**
		 * Adjust the bbPress trail to the element settings, same as the WooCommerce one:
		 * - the Home crumb is the first "Custom Link" or "Manually selected page" item (its label and link),
		 *   otherwise the bbPress default Home crumb is kept;
		 * - the bbPress crumb that duplicates the Home one is skipped (e.g. the Forums page selected as Home);
		 * - a trail of a single visible crumb is not output at all.
		 */
		$home = us_breadcrumbs_get_home( $ctx['items'] );
		$crumbs_filter = function ( $crumbs ) use ( $home, $show_current ) {
			if ( $home AND strpos( $crumbs[0] ?? '', 'bbp-breadcrumb-home' ) !== FALSE ) {
				$crumbs[0] = ( $home['link'] !== '' )
					? '<a href="' . esc_url( $home['link'] ) . '" class="bbp-breadcrumb-home">' . esc_html( $home['title'] ) . '</a>'
					: esc_html( $home['title'] );

				if (
					preg_match( '#href="([^"]*)"#', $crumbs[1] ?? '', $matches )
					AND us_breadcrumbs_is_same_url( html_entity_decode( $matches[1] ), $home['link'] )
				) {
					array_splice( $crumbs, 1, 1 );
				}
			}

			// The last (current) crumb is hidden via CSS when "Show current page" is off
			$visible_count = count( $crumbs ) - ( $show_current ? 0 : 1 );

			return ( $visible_count < 2 ) ? array() : $crumbs;
		};

		add_filter( 'bbp_breadcrumbs', $crumbs_filter );
		try {
			$output = bbp_get_breadcrumb( $bbp_args );
		}
		finally {
			remove_filter( 'bbp_breadcrumbs', $crumbs_filter );
		}

		return $output;
	}
}

// Adding BBPress post type support in grids for regular visitors on front
if (
	function_exists( 'bbp_get_forum_post_type' )
	AND function_exists( 'bbp_get_forum_post_type_labels' )
) {
	add_filter( 'us_get_loop_post_types', function( $posts_types ) {

		$post_type = bbp_get_forum_post_type();
		if ( ! isset( $posts_types[ $post_type ] ) ) {
			$labels = bbp_get_forum_post_type_labels();
			$posts_types[ $post_type ] = $labels['name'] . ' (' . $post_type . ')';
		}

		return $posts_types;
	} );
}

if ( ! function_exists( 'us_bbp_after_theme_compat_reset_post_parse_args' ) ) {
	/**
	 * Add filter to override global objects
	 *
	 * Filter mask: `bbp_after_{theme_compat_reset_post}_parse_args`
	 * @link https://github.com/bbpress/bbPress/blob/trunk/src/includes/common/functions.php#L1641
	 */
	add_filter( 'bbp_after_theme_compat_reset_post_parse_args', 'us_bbp_after_theme_compat_reset_post_parse_args', 1, 1 );

	/**
	 * Cancels redefinition of global objects
	 *
	 * Note: bbPress hard and force redefinition of global objects, which breaks
	 * standard methods WordPress.
	 *
	 * @link https://github.com/bbpress/bbPress/blob/trunk/src/includes/core/theme-compat.php#L362
	 *
	 * @param array $reset_post A specific post data array that does not exist
	 * @return mixed
	 */
	function us_bbp_after_theme_compat_reset_post_parse_args( $reset_post ) {
		if (
			is_archive()
			AND function_exists( 'us_get_page_area_id' )
			AND us_get_page_area_id( 'content' )
		) {
			return NULL;
		}
		return $reset_post;
	}
}
