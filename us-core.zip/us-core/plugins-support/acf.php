<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Advanced Custom Fields
 *
 * @link https://www.advancedcustomfields.com
 *
 * TODO: Globally replace the architecture of storing and working fields,
 * use an identifier instead of a name, since now there is a problem if fields in
 * different groups have the same name does not work correctly.
 */

if ( ! class_exists( 'ACF' ) ) {
	return;
}

// Register Google Maps API key
// https://www.advancedcustomfields.com/resources/google-map/
if ( ! function_exists( 'us_acf_google_map_api' ) ) {

	add_filter( 'acf/fields/google_map/api', 'us_acf_google_map_api' );

	function us_acf_google_map_api( $api ) {
		// Get the Google Maps API key from the Theme Options
		$gmaps_api_key = trim( esc_attr( us_get_option('gmaps_api_key', '') ) );
		/*
		 * Set the API key for ACF only if it is not empty,
		 * to prevent possible erase of the same value set in other plugins
		 */
		if ( ! empty( $gmaps_api_key ) ) {
			$api['key'] = $gmaps_api_key;
		}

		return $api;
	}
}

// Removing custom plugin messages for ACF Pro
if ( ! function_exists( 'us_acf_pro_remove_update_message' ) ) {

	add_action( 'init', 'us_acf_pro_remove_update_message', 30 );

	function us_acf_pro_remove_update_message() {
		if ( class_exists( 'ACF_Updates' ) ) {
			$class = new ACF_Updates();
			remove_filter( 'pre_set_site_transient_update_plugins', array( $class, 'modify_plugins_transient' ), 15 );
		}

		// Remove additional messages for buying license
		if (
			function_exists( 'acf_get_setting' )
			AND $acf_basename = acf_get_setting( 'basename' )
		) {
			remove_all_actions( 'in_plugin_update_message-' . $acf_basename );
		}
	}
}

if ( ! function_exists( 'us_acf_get_fields' ) ) {
	/**
	 * Get ACF fields grouped by their group name
	 *
	 * @param string|array $types The field types to get
	 * @param bool $to_list If true, the result will be [ key => value ]
	 * @param bool $include_options_page If false, the result will not include fields assigned to any Options page
	 * @param string $options_page_prefix The prefix used to differentiate fields assigned to any Options page, can be 'option|' or 'option/'
	 * @return array Returns a list of fields
	 */
	function us_acf_get_fields( $types = array(), $to_list = FALSE, $include_options_page = TRUE, $options_page_prefix = 'option|' ) {

		if ( ! is_array( $types ) AND ! empty( $types ) ) {
			$types = array( $types );
		}
		$result = array();

		foreach ( (array) acf_get_field_groups() as $group ) {

			/**
			 * If the group is used in ACF Options page, use the predefined prefix or abort
			 * @link https://www.advancedcustomfields.com/resources/get-values-from-an-options-page/
			 */
			$field_name_prefix = '';
			if ( is_array( $group['location'] ) ) {
				foreach ( $group['location'] as $location_or ) {
					foreach ( $location_or as $location_and ) {
						if ( $location_and['param'] === 'options_page' AND $location_and['operator'] === '==' ) {
							if ( $include_options_page ) {
								$field_name_prefix = $options_page_prefix;
								break 2;
							} else {
								continue 3;
							}
						}
					}
				}
			}

			// Get all the fields of the group and generating the result.
			$fields = array();
			foreach( (array) acf_get_fields( $group['ID'] ) as $field ) {

				if ( $types AND ! in_array( $field['type'], array_merge( $types, array( 'group' ) ) ) ) {
					continue;
				}

				$field['name'] = $field_name_prefix . $field['name'];

				if ( $to_list ) {

					// Get sub fields from "Group" type
					if ( $field['type'] == 'group' ) {
						foreach( $field['sub_fields'] as $sub_field ) {
							if ( $types AND ! in_array( $sub_field['type'], $types ) ) {
								continue;
							}
							$fields[ $field['name'] . '_' . $sub_field['name'] ] = $field['label'] . ': ' . $sub_field['label'];
						}

					} else {
						$fields[ $field['name'] ] = $field['label'];
					}

				} else {
					$fields[] = $field;
				}
			}

			if ( count( $fields ) ) {
				// This is the full name of the group that can be used for output in dropdowns or other controls
				$result[ $group['ID'] ] = array( '__group_label__' => $group['title'] );
				$result[ $group['ID'] ] += $fields;
			}
		}
		return $result;
	}
}

if ( ! function_exists( 'us_acf_get_custom_field' ) ) {

	add_filter( 'us_get_custom_field', 'us_acf_get_custom_field', 2, 5 );

	/**
	 * Filters a custom field value to apply the ACF return format
	 *
	 * @param mixed $value
	 * @param string $name
	 * @param int|string $current_id
	 * @param string|null $meta_type
	 * @param bool $acf_format Applies the ACF "Return Format" to the returned value, if FALSE - the function returns the raw value
	 *
	 * @return mixed Returns a value given specific fields
	 */
	function us_acf_get_custom_field( $value, $name, $current_id, $meta_type = NULL, $acf_format = TRUE ) {

		if ( $acf_format === FALSE ) {
			return $value;
		}

		// Built-in fields where the name starts with us_ are returned unchanged
		if ( strpos( $name, 'us_' ) === 0 ) {
			return $value;
		}

		// Use the meta slug as prefix in the current id for ACF functions
		// https://www.advancedcustomfields.com/resources/get_field/#get-a-value-from-different-objects
		if (
			$meta_type == 'term'
			AND $term = get_term( $current_id )
			AND $term instanceof WP_Term
		) {
			$current_id = $term->taxonomy . '_' . $current_id;
		}
		if ( $meta_type == 'user' ) {
			$current_id = 'user_' . $current_id;
		}

		// Get field object https://www.advancedcustomfields.com/resources/get_field_object/
		$field = get_field_object( $name, $current_id );

		// In case the field is not exist in ACF return the initial value
		// This allows getting values for non-ACF custom fields correctly (_wp_attachment_image_alt, etc.)
		if ( $field === FALSE ) {
			return $value;
		}

		// Return value from a field object
		return us_arr_path( $field, 'value', /* default */$value );
	}
}

if ( ! function_exists( 'us_acf_link_dynamic_values' ) ) {

	add_filter( 'us_link_dynamic_values', 'us_acf_link_dynamic_values' );

	/**
	 * Append ACF predefined field types to link dynamic values
	 *
	 * @param array $dynamic_values Groups of dynamic values
	 * @return array Returns an expanded array of variables
	 */
	function us_acf_link_dynamic_values( $dynamic_values ) {

		// Skip adding values if it's not edit mode
		if ( ! us_is_elm_editing_page() OR empty( $dynamic_values['acf_types'] ) ) {
			return $dynamic_values;
		}

		$acf_dynamic_values = array();

		foreach( us_acf_get_fields( $dynamic_values['acf_types'], TRUE, TRUE, 'option/' ) as $fields ) {
			$group_label = (string) us_arr_path( $fields, '__group_label__' );
			foreach ( $fields as $field_key => $field_name ) {
				if ( $field_key == '__group_label__' ) {
					continue;
				}
				$acf_dynamic_values[ $group_label ][ 'custom_field|' . $field_key ] = $field_name;
			}
		}

		return array_merge( $dynamic_values, $acf_dynamic_values );
	}
}

if ( ! function_exists( 'us_acf_dynamic_values' ) ) {

	add_filter( 'us_text_dynamic_values', 'us_acf_dynamic_values' );
	add_filter( 'us_image_dynamic_values', 'us_acf_dynamic_values' );
	add_filter( 'us_html_dynamic_values', 'us_acf_dynamic_values' );
	add_filter( 'us_textarea_dynamic_values', 'us_acf_dynamic_values' );

	/**
	 * Append ACF predefined field types to text dynamic values
	 *
	 * @param array $dynamic_values Groups of dynamic values
	 * @return array Returns an expanded array of variables
	 */
	function us_acf_dynamic_values( $dynamic_values ) {

		// Skip adding values if it's not edit mode
		if ( ! us_is_elm_editing_page() OR empty( $dynamic_values['acf_types'] ) ) {
			return $dynamic_values;
		}

		$acf_dynamic_values = array();

		foreach( us_acf_get_fields( $dynamic_values['acf_types'], TRUE, TRUE, 'option/' ) as $fields ) {
			$group_label = (string) us_arr_path( $fields, '__group_label__' );
			foreach ( $fields as $field_key => $field_name ) {
				if ( $field_key == '__group_label__' ) {
					continue;
				}
				$acf_dynamic_values[ $group_label ][ '{{' . $field_key . '}}' ] = $field_name;
			}
		}

		return array_merge( $dynamic_values, $acf_dynamic_values );

	}
}

if ( ! function_exists( 'us_acf_color_dynamic_values' ) ) {

	add_filter( 'usof_get_color_vars', 'us_acf_color_dynamic_values', 1, 1 );

	/**
	 * Append ACF predefined field types to color dynamic values
	 *
	 * @param array $result The dynamic colors.
	 * @return array Returns an array of dynamic colors.
	 */
	function us_acf_color_dynamic_values( $result ) {

		foreach( us_acf_get_fields( 'color_picker', TRUE, TRUE, 'option/' ) as $fields ) {
			$group_label = (string) us_arr_path( $fields, '__group_label__' );
			foreach ( $fields as $field_key => $field_name ) {
				if ( $field_key == '__group_label__' ) {
					continue;
				}
				$result[ $group_label ][] = array(
					'name' => sprintf( '{{%s}}', $field_key ),
					'title' => $field_name,
					'type' => 'cf_colors',
				);
			}
		}

		return $result;
	}
}

if ( ! function_exists( 'us_add_acf_orderby_params' ) ) {

	add_filter( 'us_get_list_orderby_params', 'us_add_acf_orderby_params', 101 );

	/**
	 * Append ACF predefined field types to List Orderby options
	 */
	function us_add_acf_orderby_params( $params ) {

		$supported_types = array(
			'text',
			'number',
			'range',
			'select',
			'radio',
			'button_group',
			'date_picker',
			'date_time_picker',
		);

		foreach( us_acf_get_fields( $supported_types, FALSE, FALSE ) as $fields ) {
			$group_label = (string) us_arr_path( $fields, '__group_label__' );

			foreach ( $fields as $field_key => $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}

				// If field name is already used in previous params (e.g. 'date', 'title', 'menu_order'), append the count suffix to make it unique
				$unique_name = in_array( $field['name'], array_keys( $params ) )
					? $field['name'] . count( $params )
					: $field['name'];
				$unique_name = sanitize_title( $unique_name );

				$params[ $unique_name ] = array(
					'label' => $field['label'],
					'group' => $group_label,
					'orderby_param' => 'meta_value',
					'meta_key' => $field['name'],
				);

				// ACF types for numeric values
				if ( in_array( $field['type'], array( 'number', 'range' ) ) ) {
					$params[ $unique_name ]['orderby_param'] = 'meta_value_num';
				}
			}
		}

		return $params;
	}
}

if ( ! function_exists( 'us_add_acf_filter_params' ) ) {

	add_filter( 'us_get_list_filter_params', 'us_add_acf_filter_params' );

	/**
	 * Append ACF predefined field types to List Filter
	 */
	function us_add_acf_filter_params( $params ) {

		$acf_relevant_fields = array();

		$supported_types = array(
			'text',
			'number',
			'range',
			'select',
			'checkbox',
			'radio',
			'button_group',
			'true_false',
			'date_picker',
			'date_time_picker',
		);

		foreach ( (array) acf_get_field_groups() as $group ) {

			// Skip groups that used for Options page
			if ( is_array( $group['location'] ) ) {
				foreach ( $group['location'] as $location_or ) {
					foreach ( $location_or as $location_and ) {
						if ( $location_and['param'] === 'options_page' AND $location_and['operator'] === '==' ) {
							continue 3;
						}
					}
				}
			}

			foreach ( (array) acf_get_fields( $group['ID'] ) as $field ) {
				if ( ! in_array( $field['type'], array_merge( $supported_types, array( 'group' ) ) ) ) {
					continue;
				}

				// Get sub fields from "Group" type
				if ( $field['type'] == 'group' ) {
					foreach( $field['sub_fields'] as $sub_field ) {
						if ( ! in_array( $sub_field['type'], $supported_types ) ) {
							continue;
						}
						$acf_relevant_fields[ $field['name'] . '_' . $sub_field['name'] ] = array(
							'group_title' => $group['title'],
							'label' => $field['label'] . ': ' . $sub_field['label'],
							'type' => $sub_field['type'],
							'choices' => $sub_field['choices'] ?? NULL,
							'message' => $sub_field['message'] ?? NULL,
							'multiple' => $sub_field['multiple'] ?? NULL,
						);
					}

				} else {
					$acf_relevant_fields[ $field['name'] ] = array(
						'group_title' => $group['title'],
						'label' => $field['label'],
						'type' => $field['type'],
						'choices' => $field['choices'] ?? NULL,
						'message' => $field['message'] ?? NULL,
						'multiple' => $field['multiple'] ?? NULL,
					);
				}
			}
		}

		foreach ( $acf_relevant_fields as $name => $field ) {

			// If field name is already used in previous params (e.g. 'category', 'price', 'featured'), append the count suffix to make it unique
			$unique_name = in_array( $name, array_merge( array_keys( $params ), array( 'orderby', 's' ) ) )
				? $name . count( $params )
				: $name;

			$params[ $unique_name ] = array(
				'label' => $field['label'],
				'group' => $field['group_title'],
				'source_type' => 'meta',
				'source_name' => $name,
			);

			// ACF types with predefined choices (used to prevent parsing values from database)
			if ( in_array( $field['type'], array( 'button_group', 'checkbox', 'radio', 'select' ) ) ) {
				$params[ $unique_name ]['choices'] = $field['choices'];
			}

			// ACF types for numeric values
			if ( in_array( $field['type'], array( 'number', 'range' ) ) ) {
				$params[ $unique_name ]['value_type'] = 'numeric';
			}

			// ACF types for bool values
			if ( $field['type'] == 'true_false' ) {
				$params[ $unique_name ]['value_type'] = 'bool';
				$params[ $unique_name ]['bool_value_label'] = $field['message'];
			}

			// ACF types for date values
			if ( $field['type'] == 'date_picker' ) {
				$params[ $unique_name ]['value_type'] = 'date';
			}

			// ACF types for date_time values
			if ( $field['type'] == 'date_time_picker' ) {
				$params[ $unique_name ]['value_type'] = 'date_time';
			}

			// ACF Checkbox keeps its value as serialized array, that's why only 'LIKE' meta compare is possible
			if ( $field['type'] == 'checkbox' ) {
				$params[ $unique_name ]['value_compare'] = 'like';
			}

			// ACF Select keeps its value as serialized array, if multiple is enabled, that's why only 'LIKE' meta compare is possible
			if ( $field['type'] == 'select' AND $field['multiple'] == '1' ) {
				$params[ $unique_name ]['value_compare'] = 'like';
			}
		}

		return $params;
	}
}

if ( ! function_exists( 'us_acf_post_list_element_config' ) ) {

	add_filter( 'us_config_elements/post_list', 'us_acf_post_list_element_config', 501, 1 );

	/**
	 * Extends the configuration of the "Post List" element to output posts from ACF.
	 *
	 * @param array $config The configuration.
	 * @return array Returns the extended configuration.
	 */
	function us_acf_post_list_element_config( $config ) {
		if (
			! isset( $config['params'], $config['params']['source'] )
			OR ! is_array( $config['params']['source']['options'] )
		) {
			return $config;
		}

		// Get a list of all fields of type "Post Object" and "Relationship"
		$field_list = array(
			'' => '– ' . us_translate( 'None' ) . ' –',
		);
		foreach ( us_acf_get_fields( array( 'post_object', 'relationship' ), TRUE ) as $field ) {
			$group_label = (string) us_arr_path( $field, '__group_label__' );
			foreach ( $field as $field_key => $field_name ) {
				if ( $field_key !== '__group_label__' ) {
					$field_list[ $field_key ] = $group_label . ': ' . $field_name;
				}
			}
		}
		$config['params']['source']['options']['custom_field_posts'] = __( 'Posts from ACF custom field', 'us' );
		$config['params'] = us_array_merge_insert(
			$config['params'],
			array(
				'custom_field_name' => array(
					'type' => 'select',
					'options' => $field_list,
					'std' => '',
					'classes' => 'for_above',
					'show_if' => array( 'source', '=', 'custom_field_posts' ),
					'usb_preview' => TRUE,
				)
			),
			'after',
			'source'
		);
		foreach ( $config['params'] as &$param ) {
			if ( isset( $param['weight'] ) ) {
				unset( $param['weight'] );
			}
		}
		unset( $param );
		$config['params'] = us_set_params_weight( $config['params'] );
		return $config;
	}
}

if ( ! function_exists( 'us_acf_posts_from_custom_field' ) ) {

	add_filter( 'us_post_list_query_args', 'us_acf_posts_from_custom_field', 501, 2 );
	add_filter( 'us_post_list_query_args_unfiltered', 'us_acf_posts_from_custom_field', 501, 2 );

	/**
	 * Modify the post list query to return posts from ACF custom field.
	 *
	 * @param array $query_args The query arguments.
	 * @param array $filled_atts The filled atts.
	 * @return array Returns array of arguments passed to WP_Query.
	 */
	function us_acf_posts_from_custom_field( $query_args, $filled_atts ) {
		if (
			us_arr_path( $filled_atts, 'source' ) == 'custom_field_posts'
			AND $field_name = us_arr_path( $filled_atts, 'custom_field_name' )
			AND ! usb_is_template_preview()
		) {
			if ( wp_doing_ajax() ) {
				$object_id = (int) us_arr_path( $_POST, 'object_id' );
				$meta_type = (string) us_arr_path( $_POST, 'meta_type' );

				// Validate string
				if ( ! in_array( $meta_type, array( 'post', 'term', 'user' ) ) ) {
					$meta_type = 'post';
				}

			} else {
				$object_id = us_get_current_id();
				$meta_type = us_get_current_meta_type();
			}

			if ( ! $post_ids = us_get_custom_field( $field_name, /*acf_format*/FALSE, $object_id, $meta_type ) ) {
				$post_ids = array( 0 ); // Use the non-existing id to get no results, because empty 'post__in' is ignored by query
			}
			$query_args['post__in'] = (array) $post_ids;
		}
		return $query_args;
	}
}

if ( ! function_exists( 'us_acf_tta_source_options' ) ) {

	add_filter( 'us_tta_source_options', 'us_acf_tta_source_options' );

	/**
	 * Add the sources into Accordion/Tabs/Vertical Tabs elements to output data from ACF Repeater.
	 *
	 * @return array Returns the options.
	 */
	function us_acf_tta_source_options( $options ) {

		foreach ( us_acf_get_fields( array( 'repeater' ), TRUE ) as $field ) {
			$group_label = (string) us_arr_path( $field, '__group_label__' );
			foreach ( $field as $field_key => $field_name ) {
				if ( $field_key !== '__group_label__' ) {
					$options[ $field_key ] = $group_label . ': ' . $field_name;
				}
			}
		}

		return $options;
	}
}

if ( ! function_exists( 'us_acf_tta_content' ) ) {

	add_filter( 'us_vc_tta_tabs_content', 'us_acf_tta_content', 10, 2 );

	/**
	 * Change the content of Accordion/Tabs/Vertical Tabs to output data from ACF Repeater.
	 *
	 * @return string Returns the content.
	 */
	function us_acf_tta_content( $content, $atts ) {

		if ( empty( $atts['data_source'] ) ) {
			return $content;
		}

		if ( $rows = us_get_custom_field( $atts['data_source'] ) AND is_array( $rows ) ) {

			$sections_atts = array();

			// Get section settings
			if ( preg_match_all( '/' . get_shortcode_regex( array( 'vc_tta_section' ) ) . '/', $content, $matches ) ) {
				foreach( $matches[3] as $text_atts ) {
					$sections_atts[] = array_merge( $sections_atts[0] ?? array(), shortcode_parse_atts( $text_atts ) );
				}

				// Sections of Grid Layout come already rendered instead of the content, see us_output_builder_elms()
			} elseif ( ! empty( $atts['grid_sections'] ) AND is_array( $atts['grid_sections'] ) ) {
				$section_defaults = us_get_elm_defaults( 'vc_tta_section', 'grid' );

				foreach ( $atts['grid_sections'] as $grid_section ) {
					$grid_section_atts = (array) us_arr_path( $grid_section, 'atts', array() );

					/**
					 * Grid Layout sections keep all settings including default ones, so take only changed settings,
					 * others are inherited from the first section, same as for shortcodes.
					 */
					if ( isset( $sections_atts[0] ) ) {
						$grid_section_atts = array_filter( $grid_section_atts, function( $value, $name ) use ( $section_defaults ) {
							// cleared Design or Display Logic may be stored as an empty array
							return ! array_key_exists( $name, $section_defaults ) OR ! ( $value == $section_defaults[ $name ] OR ( $value === array() AND empty( $section_defaults[ $name ] ) ) );
						}, ARRAY_FILTER_USE_BOTH );

						/**
						 * Design is applied via the section usg_ class, so the classes are inherited along with the design.
						 * Own "Extra class" replaces the first section one, same as for shortcodes.
						 */
						if ( ! array_intersect_key( $grid_section_atts, array_flip( array( 'css', 'hide_below', 'hide_above' ) ) ) ) {
							unset( $grid_section_atts['tab_item_class'] );
							$first_classes = array_diff( explode( ' ', $sections_atts[0]['classes'] ?? '' ), explode( ' ', $sections_atts[0]['el_class'] ?? '' ) );
							$grid_section_atts['classes'] = ' ' . trim( implode( ' ', $first_classes ) ) . ' ' . ( $grid_section_atts['el_class'] ?? $sections_atts[0]['el_class'] ?? '' );
						}
					}
					$grid_section_atts = array_merge( $sections_atts[0] ?? array(), $grid_section_atts );

					// Grid Layout keeps design options, conditions etc. as arrays, encode them as in shortcodes
					foreach ( $grid_section_atts as &$grid_section_att ) {
						if ( is_array( $grid_section_att ) ) {
							$grid_section_att = rawurlencode( json_encode( $grid_section_att ) );
						}
					}
					unset( $grid_section_att );

					$sections_atts[] = $grid_section_atts;
				}
			}

			$content = '';

			$title_source = $atts['title_source'] ?? '';
			$content_source = $atts['content_source'] ?? '';

			foreach( $rows as $i => $row ) {

				$section_atts = $sections_atts[ $i ] ?? $sections_atts[0] ?? array();

				$section_title = $row[ trim( $title_source ) ] ?? '';
				if ( ! is_scalar( $section_title ) ) {
					$section_title = 'Unsupported format';
				}
				$section_atts['title'] = $section_title;

				$section_content = $row[ trim( $content_source ) ] ?? '';
				if ( ! is_scalar( $section_content ) ) {
					$section_content = 'Unsupported format';
				}

				$section_content = apply_filters( 'us_acf_tta_section_content', $section_content, $row );

				$section_atts = us_implode_atts( $section_atts, /* for_shortcode */TRUE );

				$tta_section = sprintf( '[vc_tta_section%s]%s[/vc_tta_section]', $section_atts, $section_content );

				// Converts unclosed parentheses to entities
				$content .= preg_replace_callback( '/<(?![^<>]*>)/', function( $matches ) {
					return htmlspecialchars( $matches[0] );
				}, $tta_section );
			}
		}

		return $content;
	}
}

if ( ! function_exists( 'us_conditions_custom_field_acf_format' ) ) {

	add_filter( 'us_conditions_custom_field_acf_format', 'us_conditions_custom_field_acf_format', 10, 4 );

	/**
	 * Disable the ACF value format for specific field types
	 *
	 * @param bool $acf_format format is on or off
	 * @param string $meta_key The meta key
	 * @param int|string $current_id The object ID
	 * @param string|null $meta_type Type of object metadata is for: 'post', 'term', 'user'
	 *
	 * @return bool $acf_format format is on or off
	 */
	function us_conditions_custom_field_acf_format( $acf_format, $meta_key, $current_id, $meta_type = NULL ) {

		// Use the meta slug as prefix in the current id for ACF functions
		// https://www.advancedcustomfields.com/resources/get_field/#get-a-value-from-different-objects
		if (
			$meta_type == 'term'
			AND $term = get_term( $current_id )
			AND $term instanceof WP_Term
		) {
			$current_id = $term->taxonomy . '_' . $current_id;
		}
		if ( $meta_type == 'user' ) {
			$current_id = 'user_' . $current_id;
		}

		if (
			$field_object = get_field_object( $meta_key, $current_id )
			AND isset( $field_object['type'] )
			AND in_array( $field_object['type'], array( 'date_picker', 'date_time_picker', 'time_picker' ) )
		) {
			$acf_format = FALSE;
		}
		return $acf_format;
	}
}

if ( ! function_exists( 'us_acf_mcp_meta_whitelist' ) ) {

	// Priority before the default 10, so site callbacks see the ACF keys and can remove them
	add_filter( 'us_mcp_post_type_meta_whitelist', 'us_acf_mcp_meta_whitelist', 5, 2 );

	/**
	 * Add ACF fields of the groups located on a post type to the MCP meta whitelist
	 *
	 * Only fields with a supported value format are exposed (see us_acf_mcp_field_spec()),
	 * first-level sub fields of a Group field under the "{group}_{sub}" key.
	 * A built-in key wins over an ACF field of the same name, and of two ACF fields
	 * with the same name the one from the earlier group wins.
	 *
	 * @param array $whitelist Meta specs keyed by meta key
	 * @param string $post_type The post type slug
	 * @return array Returns the whitelist with ACF fields added
	 */
	function us_acf_mcp_meta_whitelist( $whitelist, $post_type ) {
		foreach ( us_acf_mcp_field_groups() as $group ) {
			if ( ! us_acf_mcp_group_applies_to( $group, $post_type ) ) {
				continue;
			}
			foreach ( $group['mcp_specs'] as $key => $spec ) {
				if ( ! isset( $whitelist[ $key ] ) ) {
					$whitelist[ $key ] = $spec;
				}
			}
		}

		return $whitelist;
	}

	/**
	 * Get the active ACF field groups with the MCP specs of their fields
	 *
	 * Built once per request: the whitelist filter runs for every post type, and only
	 * the Location check differs between them.
	 *
	 * @return array Returns the field groups, each with 'mcp_specs' => [ meta key => spec ]
	 */
	function us_acf_mcp_field_groups() {
		static $groups = NULL;
		if ( $groups !== NULL ) {
			return $groups;
		}
		$groups = array();
		if ( ! function_exists( 'acf_get_field_groups' ) ) {
			return $groups;
		}

		// No filter argument: ACF matches it against the Location rules as the current screen
		foreach ( (array) acf_get_field_groups() as $group ) {
			if ( empty( $group['active'] ) ) {
				continue;
			}

			$specs = array();

			// Pass the group itself, not its ID: groups registered in PHP / JSON have no ID
			foreach ( (array) acf_get_fields( $group ) as $field ) {
				if ( empty( $field['name'] ) ) {
					continue;
				}

				if ( $field['type'] == 'group' ) {
					foreach ( (array) us_arr_path( $field, 'sub_fields', array() ) as $sub_field ) {
						$key = $field['name'] . '_' . us_arr_path( $sub_field, 'name' );
						if (
							empty( $sub_field['name'] )
							OR isset( $specs[ $key ] )
							OR ! $spec = us_acf_mcp_field_spec( $sub_field )
						) {
							continue;
						}
						// A required Group makes all its sub fields required, as ACF does on validation
						if (
							! empty( $field['required'] )
							AND empty( $field['conditional_logic'] )
							AND empty( $sub_field['conditional_logic'] )
						) {
							$spec['required'] = TRUE;
						}
						$spec['acf'] = array( $field['key'], $sub_field['key'] );
						$spec['label'] = $field['label'] . ': ' . $sub_field['label'];
						$specs[ $key ] = $spec;
					}
					continue;
				}

				if (
					isset( $specs[ $field['name'] ] )
					OR ! $spec = us_acf_mcp_field_spec( $field )
				) {
					continue;
				}
				$spec['acf'] = $field['key'];
				$spec['label'] = $field['label'];
				$specs[ $field['name'] ] = $spec;
			}

			if ( $specs ) {
				$group['mcp_specs'] = $specs;
				$groups[] = $group;
			}
		}

		return $groups;
	}

	/**
	 * Get the MCP meta spec of an ACF field, in the format the agent writes and reads the raw stored value
	 *
	 * Repeater, Flexible Content and Group specs hold the specs of their sub fields, built by this function.
	 *
	 * @param array $field The ACF field
	 * @return array|null Returns the spec, or NULL for a field without a supported value format
	 */
	function us_acf_mcp_field_spec( $field ) {
		$type = (string) us_arr_path( $field, 'type' );

		// A type of ACF PRO or another plugin that is not active now: ACF would store the raw value
		if ( function_exists( 'acf_get_field_type' ) AND ! acf_get_field_type( $type ) ) {
			return NULL;
		}

		if ( in_array( $type, array( 'text', 'textarea', 'wysiwyg', 'email', 'url', 'oembed' ) ) ) {
			$spec = array( 'type' => 'string' );

		} elseif ( in_array( $type, array( 'number', 'range' ) ) ) {
			$spec = array( 'type' => 'number' );
			foreach ( array( 'min', 'max' ) as $bound ) {
				if ( isset( $field[ $bound ] ) AND is_numeric( $field[ $bound ] ) ) {
					$spec[ $bound ] = $field[ $bound ] + 0;
				}
			}
			// Range falls back to 0..100 when a bound is not set, same as its slider
			if ( $type == 'range' ) {
				$spec += array( 'min' => 0, 'max' => 100 );
			}

		} elseif ( $type == 'true_false' ) {
			$spec = array( 'type' => 'bool_01' );

		} elseif (
			$type == 'checkbox'
			OR ( $type == 'select' AND ! empty( $field['multiple'] ) )
		) {
			// Checkbox "Allow Custom" and Select "Create Options" (works only with "Stylized UI") store any typed text
			if (
				! empty( $field['allow_custom'] )
				OR ( ! empty( $field['create_options'] ) AND ! empty( $field['ui'] ) )
			) {
				$item = array( 'type' => 'string' );
			} else {
				$item = array(
					'type' => 'enum',
					'values' => us_acf_mcp_choice_values( $field ),
				);
			}
			$spec = array(
				'type' => 'list',
				'item' => $item,
			);

		} elseif ( in_array( $type, array( 'select', 'radio', 'button_group' ) ) ) {
			// Radio with the "Other" choice stores any typed text
			if ( $type == 'radio' AND ! empty( $field['other_choice'] ) ) {
				$spec = array( 'type' => 'string' );
			} else {
				$spec = array(
					'type' => 'enum',
					'values' => us_acf_mcp_choice_values( $field ),
				);
			}

		} elseif ( $type == 'date_picker' ) {
			$spec = array( 'type' => 'date' );

		} elseif ( $type == 'date_time_picker' ) {
			$spec = array( 'type' => 'datetime' );

		} elseif ( $type == 'time_picker' ) {
			$spec = array( 'type' => 'time' );

		} elseif ( $type == 'color_picker' ) {
			$spec = array(
				'type' => 'color',
				'plain' => TRUE,
				'alpha' => ! empty( $field['enable_opacity'] ),
			);

		} elseif ( $type == 'image' ) {
			$spec = array(
				'type' => 'attachment',
				'image' => TRUE,
			);

		} elseif ( $type == 'file' ) {
			$spec = array( 'type' => 'attachment' );

		} elseif ( in_array( $type, array( 'post_object', 'relationship' ) ) ) {
			$post_spec = array(
				'type' => 'post',
				'post_types' => array_values( array_filter( (array) us_arr_path( $field, 'post_type', array() ) ) ),
			);
			if ( $type == 'post_object' AND empty( $field['multiple'] ) ) {
				$spec = $post_spec;
			} else {
				$spec = array(
					'type' => 'list',
					'item' => $post_spec,
				);
				if ( $type == 'relationship' ) {
					$spec += us_acf_mcp_count_bounds( $field );
				}
			}

		} elseif ( $type == 'gallery' ) {
			$spec = array(
				'type' => 'list',
				'item' => array(
					'type' => 'attachment',
					'image' => TRUE,
				),
			) + us_acf_mcp_count_bounds( $field );

		} elseif ( $type == 'link' ) {
			$spec = array( 'type' => 'link' );

		} elseif ( $type == 'repeater' OR $type == 'group' ) {
			if ( ! $sub_fields = us_acf_mcp_sub_field_specs( us_arr_path( $field, 'sub_fields', array() ) ) ) {
				return NULL;
			}
			$spec = array(
				'type' => ( $type == 'group' ) ? 'group' : 'rows',
				'sub_fields' => $sub_fields,
			);
			if ( $type == 'repeater' ) {
				$spec += us_acf_mcp_count_bounds( $field );
			}

		} elseif ( $type == 'flexible_content' ) {
			$layouts = array();
			foreach ( (array) us_arr_path( $field, 'layouts', array() ) as $layout ) {
				if ( empty( $layout['name'] ) ) {
					continue;
				}
				// Blocks store only the layout name, so ACF cannot tell such layouts apart
				if ( isset( $layouts[ $layout['name'] ] ) ) {
					return NULL;
				}
				// A layout without sub fields stays: it is a valid empty block
				$sub_fields = us_acf_mcp_sub_field_specs( us_arr_path( $layout, 'sub_fields', array() ) );
				if ( $sub_fields === NULL ) {
					return NULL;
				}
				$layouts[ $layout['name'] ] = array(
					'label' => (string) us_arr_path( $layout, 'label' ),
					'sub_fields' => $sub_fields,
				) + us_acf_mcp_count_bounds( $layout );
			}
			if ( ! $layouts ) {
				return NULL;
			}
			$spec = array(
				'type' => 'layouts',
				'layouts' => $layouts,
			) + us_acf_mcp_count_bounds( $field );

		} else {
			/**
			 * password (would be returned by get-post), user (validating an id tells whether
			 * the user exists and has the role), taxonomy (may sync the post terms),
			 * page_link, google_map, clone, display-only types (message, tab, accordion)
			 * and types added by other plugins
			 */
			return NULL;
		}

		/**
		 * ACF checks required fields only when the post is published, see us_mcp_validate_meta_input().
		 * A field with Conditional Logic is required only while shown, which depends on other values.
		 */
		if ( ! empty( $field['required'] ) AND empty( $field['conditional_logic'] ) ) {
			$spec['required'] = TRUE;
		}
		// For the check of a required Group, which needs all its sub fields shown in the form
		if ( ! empty( $field['conditional_logic'] ) ) {
			$spec['conditional'] = TRUE;
		}

		if ( $instructions = trim( wp_strip_all_tags( (string) us_arr_path( $field, 'instructions' ) ) ) ) {
			$spec['description'] = $instructions;
		}

		return $spec;
	}

	/**
	 * Get the choice values of a Select / Checkbox field
	 *
	 * @param array $field The ACF field
	 * @return string[] Returns the values; grouped choices (optgroup label => [ value => label ]) are flattened
	 */
	function us_acf_mcp_choice_values( $field ) {
		$values = array();
		foreach ( (array) us_arr_path( $field, 'choices', array() ) as $value => $label ) {
			if ( is_array( $label ) ) {
				$values = array_merge( $values, array_map( 'strval', array_keys( $label ) ) );
			} else {
				$values[] = (string) $value;
			}
		}
		return $values;
	}

	/**
	 * Get the items / rows count bounds of a field or a Flexible Content layout
	 *
	 * @param array $field The ACF field or layout
	 * @return array Returns 'min' / 'max' when set, an empty or 0 bound means "no limit"
	 */
	function us_acf_mcp_count_bounds( $field ) {
		$bounds = array();
		foreach ( array( 'min', 'max' ) as $bound ) {
			if ( ! empty( $field[ $bound ] ) AND is_numeric( $field[ $bound ] ) ) {
				$bounds[ $bound ] = (int) $field[ $bound ];
			}
		}
		return $bounds;
	}

	/**
	 * Get the specs of the sub fields of a Repeater, Flexible Content layout or Group
	 *
	 * ACF stores rows by position and keeps the old value of a sub field missing from a written row,
	 * so a sub field without a supported format would end up in another row once rows are removed
	 * or moved. A field with such a sub field is left out entirely.
	 *
	 * @param array $sub_fields The ACF sub fields
	 * @return array|null Returns the specs keyed by sub field name, or NULL when a sub field has no supported format
	 */
	function us_acf_mcp_sub_field_specs( $sub_fields ) {
		$specs = array();
		foreach ( (array) $sub_fields as $sub_field ) {
			// Fields without a name and layout-only types (Tab, Message, Accordion) store no value
			if (
				empty( $sub_field['name'] )
				OR in_array( us_arr_path( $sub_field, 'type' ), array( 'tab', 'message', 'accordion' ), TRUE )
				OR isset( $specs[ $sub_field['name'] ] )
			) {
				continue;
			}
			if ( ! $spec = us_acf_mcp_field_spec( $sub_field ) ) {
				return NULL;
			}
			$spec['acf'] = $sub_field['key'];
			$spec['label'] = (string) us_arr_path( $sub_field, 'label' );
			$specs[ $sub_field['name'] ] = $spec;
		}
		return $specs;
	}

	/**
	 * Check if an ACF field group can be shown on a post of the given type
	 *
	 * True when at least one OR branch of the group Location rules can match a post of the type.
	 * Rules on a specific post (status, term, parent, format, one of the type's templates) count as matching:
	 * the whitelist is built per type, and a value written to a post where ACF
	 * currently hides the field breaks nothing.
	 *
	 * @param array $group The ACF field group
	 * @param string $post_type The post type slug
	 * @return bool
	 */
	function us_acf_mcp_group_applies_to( $group, $post_type ) {
		foreach ( (array) us_arr_path( $group, 'location', array() ) as $location_or ) {
			if ( empty( $location_or ) OR ! is_array( $location_or ) ) {
				continue;
			}
			foreach ( $location_or as $location_and ) {
				if ( ! us_acf_mcp_location_rule_applies_to( (array) $location_and, $post_type ) ) {
					continue 2;
				}
			}
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * Check if a single ACF Location rule can match a post of the given type
	 *
	 * @param array $rule The rule: param, operator, value
	 * @param string $post_type The post type slug
	 * @return bool
	 */
	function us_acf_mcp_location_rule_applies_to( $rule, $post_type ) {
		$param = (string) us_arr_path( $rule, 'param' );
		$value = (string) us_arr_path( $rule, 'value' );
		$is_equal = ( us_arr_path( $rule, 'operator' ) !== '!=' );

		switch ( $param ) {
			case 'post_type':
				return ( $value === 'all' OR $value === $post_type ) === $is_equal;

			case 'page_type':
				// Only pages can be the front page or the posts page
				if ( in_array( $value, array( 'front_page', 'posts_page' ) ) ) {
					return ! $is_equal OR $post_type === 'page';
				}
				// Any post is "top level" in a flat type, only hierarchical types have parents / children
				if ( $value === 'top_level' ) {
					return $is_equal OR is_post_type_hierarchical( $post_type );
				}
				return ! $is_equal OR is_post_type_hierarchical( $post_type );

			// The value is a post id: a post of that type, or a child of it (children share the parent type)
			case 'page':
			case 'page_parent':
			case 'post':
				return ! $is_equal OR get_post_type( (int) $value ) === $post_type;

			// ACF matches both via the templates of each post type (acf_get_post_templates())
			case 'page_template':
			case 'post_template':
				// "Default Template" of the "Page Template" rule is scoped to pages
				if ( $param == 'page_template' AND $value === 'default' AND $post_type !== 'page' ) {
					return FALSE;
				}
				$post_templates = function_exists( 'acf_get_post_templates' ) ? acf_get_post_templates() : array();
				if ( ! isset( $post_templates[ $post_type ] ) ) {
					return FALSE;
				}
				return ! $is_equal OR $value === 'default' OR isset( $post_templates[ $post_type ][ $value ] );

			// ACF matches "Post Category" as the "category" taxonomy
			case 'post_category':
			case 'post_taxonomy':
				if ( ! $is_equal ) {
					return TRUE;
				}
				$term = acf_decode_term( $value );
				return $term AND is_object_in_taxonomy( $post_type, $term['taxonomy'] );

			case 'post_format':
				return ! $is_equal OR post_type_supports( $post_type, 'post-formats' );

			// User rules are checked for the MCP user, as in the admin post editor
			case 'current_user':
				if ( $value === 'logged_in' ) {
					$result = is_user_logged_in();
				} else {
					$result = ( $value === 'viewing_back' );
				}
				return $result === $is_equal;

			case 'current_user_role':
				if ( $value === 'super_admin' ) {
					$result = is_super_admin();
				} else {
					$result = in_array( $value, (array) wp_get_current_user()->roles, TRUE );
				}
				return $result === $is_equal;

			// Locations of objects other than posts
			case 'options_page':
			case 'taxonomy':
			case 'user_form':
			case 'user_role':
			case 'attachment':
			case 'nav_menu':
			case 'nav_menu_item':
			case 'widget':
			case 'comment':
			case 'block':
				return FALSE;
		}

		// Location types added by other plugins: skip the ones for non-post objects,
		// consider others (post status, ...) as matching
		if (
			function_exists( 'acf_get_location_type' )
			AND $location_type = acf_get_location_type( $param )
			AND ! empty( $location_type->object_type )
			AND $location_type->object_type !== 'post'
		) {
			return FALSE;
		}

		return TRUE;
	}

	/**
	 * Resolve the `acf` reference of a meta spec to the ACF field stored under the
	 * given meta key.
	 *
	 * Returns NULL when the field no longer exists, or it is stored under another name — e.g. a stale or mistyped key added through the
	 * `us_mcp_post_type_meta_whitelist` filter. Such a key is then read and written
	 * as plain post meta, instead of ACF writing the value under the name of a
	 * placeholder field.
	 *
	 * @param string $key Meta key.
	 * @param string|string[] $acf Field key, or array( group_key, sub_key ) for a
	 *                             first-level sub field of a Group field.
	 * @return array|null The field, with `name` set to the stored meta key.
	 */
	function us_acf_mcp_get_field( $key, $acf ) {
		if ( is_array( $acf ) ) {
			$group = isset( $acf[0] ) ? acf_get_field( $acf[0] ) : FALSE;
			$field = isset( $acf[1] ) ? acf_get_field( $acf[1] ) : FALSE;
			if ( ! $group OR ! $field ) {
				return NULL;
			}
			// The Group field type stores its sub fields as "{group}_{sub}"
			$field['name'] = $group['name'] . '_' . $field['name'];
		} else {
			$field = acf_get_field( (string) $acf );
			if ( ! $field ) {
				return NULL;
			}
		}

		return ( $field['name'] === $key ) ? $field : NULL;
	}

	/**
	 * Run the ACF field's own validation on a value about to be written, as ACF does
	 * when the post is saved from its metabox: email / URL format, text length,
	 * number range, plus any acf/validate_value hooks of the site. Then the checks
	 * ACF runs for its REST API, see us_acf_mcp_rest_error().
	 *
	 * "Required" of the field itself is left out: ACF enforces it only on publish,
	 * which us_mcp_validate_meta_input() checks for the resulting post as a whole.
	 * Required sub fields of rows and the `min` count of list / rows are checked
	 * here, also only on publish: the ACF metabox does not validate a draft.
	 *
	 * @param string $key Meta key.
	 * @param string|string[] $acf The spec's `acf` reference.
	 * @param mixed $value Normalised value; NULL means "clear".
	 * @param bool $publishing Whether the post is published after the write.
	 * @return true|WP_Error
	 */
	function us_acf_mcp_validate_value( $key, $acf, $value, $publishing = FALSE ) {
		$field = us_acf_mcp_get_field( $key, $acf );
		if ( ! $field ) {
			return TRUE;
		}
		// Both also turn off the Repeater pagination, see us_acf_mcp_field_no_pagination()
		$field = $publishing ? us_acf_mcp_field_for_publish( $field ) : us_acf_mcp_field_for_draft( $field );

		$input = 'acf[' . $field['key'] . ']';
		if ( acf_validate_value( $value === NULL ? '' : $value, $field, $input ) AND ! acf_get_validation_errors() ) {
			return us_acf_mcp_rest_error( $field, $value, '"' . $key . '"' ) ?: TRUE;
		}

		/**
		 * Sub field errors of rows come with the input "acf[field_x][0][field_y]",
		 * reported as the path `"team" → row 1 → "photo"`
		 */
		$message = sprintf( 'Meta "%s" failed the ACF field validation.', $key );
		foreach ( (array) acf_get_validation_errors() as $error ) {
			if (
				! isset( $error['input'], $error['message'] )
				OR ( $error['input'] !== $input AND strpos( $error['input'], $input . '[' ) !== 0 )
			) {
				continue;
			}
			$path = '"' . $key . '"';
			preg_match_all( '/\[([^\]]+)\]/', substr( $error['input'], strlen( $input ) ), $segments );
			$parent = $field;
			foreach ( $segments[1] as $segment ) {
				if ( is_numeric( $segment ) ) {
					$noun = ( us_arr_path( $parent, 'type' ) === 'flexible_content' ) ? 'block' : 'row';
					$path .= ' → ' . $noun . ' ' . ( $segment + 1 );
				} else {
					$parent = acf_get_field( $segment );
					$path .= ' → "' . ( $parent ? $parent['name'] : $segment ) . '"';
				}
			}
			$message = sprintf( 'Meta %s: %s', $path, wp_strip_all_tags( $error['message'] ) );
			break;
		}
		acf_reset_validation_errors();

		return new WP_Error( 'us_mcp_posts_bad_meta', $message, array( 'status' => 400 ) );
	}

	/**
	 * Run the acf/validate_rest_value checks on a value and on the values of its sub fields
	 *
	 * ACF runs them for values written through its REST API, and only for top-level fields.
	 * Used for the settings our own checks lack: "Filter by Taxonomy" of Post Object /
	 * Relationship, allowed file types, file size and image dimensions of Image / File / Gallery.
	 * They run only for fields with such settings, see us_acf_mcp_needs_rest_check(): the file
	 * check prepares the whole attachment for JS for each id. Other checks are skipped: the Select
	 * one rejects choices without a label when other choices have one, the Flexible Content one
	 * counts disabled blocks into the layout min / max. Disabled blocks are skipped, as ACF does
	 * when it validates the metabox.
	 *
	 * @param array $field The ACF field
	 * @param mixed $value The normalised value, rows keyed by sub field keys
	 * @param string $path The path for the error message, e.g. '"team" → row 2 → "photo"'
	 * @return WP_Error|null Returns the first error found
	 */
	function us_acf_mcp_rest_error( $field, $value, $path ) {
		if (
			$value === NULL
			OR $value === ''
			OR $value === array()
			OR ! us_acf_mcp_needs_rest_check( $field )
		) {
			return NULL;
		}
		$type = us_arr_path( $field, 'type' );
		if ( in_array( $type, array( 'post_object', 'relationship', 'image', 'file', 'gallery' ) ) ) {
			$valid = apply_filters( 'acf/validate_rest_value/type=' . $type, TRUE, $value, $field );
			if ( ! is_wp_error( $valid ) ) {
				return NULL;
			}
			// ACF messages contain the input name, e.g. "acf[photo] requires a valid attachment ID."
			$param = sprintf( '%s[%s]', us_arr_path( $field, 'prefix' ), us_arr_path( $field, 'name' ) );
			$message = ltrim( str_replace( $param, '', $valid->get_error_message() ), ' -' );
			return new WP_Error( 'us_mcp_posts_bad_meta', sprintf( 'Meta %s: %s', $path, $message ), array( 'status' => 400 ) );
		}
		if ( ! in_array( $type, array( 'repeater', 'flexible_content', 'group' ) ) ) {
			return NULL;
		}

		$layouts = array_column( (array) us_arr_path( $field, 'layouts', array() ), NULL, 'name' );
		// A Group value is a single row
		foreach ( ( $type == 'group' ) ? array( $value ) : $value as $i => $row ) {
			$row_path = $path;
			$sub_fields = us_arr_path( $field, 'sub_fields', array() );
			if ( $type == 'repeater' ) {
				$row_path .= ' → row ' . ( $i + 1 );
			} elseif ( $type == 'flexible_content' ) {
				if ( ! empty( $row['acf_fc_layout_disabled'] ) ) {
					continue;
				}
				$row_path .= ' → block ' . ( $i + 1 );
				$sub_fields = us_arr_path( $layouts, array( us_arr_path( $row, 'acf_fc_layout' ), 'sub_fields' ), array() );
			}
			foreach ( (array) $sub_fields as $sub_field ) {
				if (
					isset( $row[ $sub_field['key'] ] )
					AND $error = us_acf_mcp_rest_error( $sub_field, $row[ $sub_field['key'] ], $row_path . ' → "' . $sub_field['name'] . '"' )
				) {
					return $error;
				}
			}
		}

		return NULL;
	}

	/**
	 * Check if the acf/validate_rest_value checks of us_acf_mcp_rest_error() add anything
	 * for a field or for its sub fields at any depth
	 *
	 * Without "Filter by Taxonomy" a Post Object / Relationship check repeats ours (the post
	 * exists and has an allowed type), and without file restrictions an Image / File / Gallery
	 * check only confirms the attachment exists.
	 *
	 * @param array $field The ACF field
	 * @return bool
	 */
	function us_acf_mcp_needs_rest_check( $field ) {
		static $cache = array();
		$key = (string) us_arr_path( $field, 'key', '' );
		if ( $key !== '' AND isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$type = us_arr_path( $field, 'type' );
		$needs = FALSE;
		if ( in_array( $type, array( 'post_object', 'relationship' ), TRUE ) ) {
			$needs = (bool) array_filter( (array) us_arr_path( $field, 'taxonomy', array() ) );

		} elseif ( in_array( $type, array( 'image', 'file', 'gallery' ), TRUE ) ) {
			foreach ( array( 'mime_types', 'min_size', 'max_size', 'min_width', 'max_width', 'min_height', 'max_height' ) as $setting ) {
				if ( ! empty( $field[ $setting ] ) ) {
					$needs = TRUE;
					break;
				}
			}

		} else {
			$sub_fields = (array) us_arr_path( $field, 'sub_fields', array() );
			foreach ( (array) us_arr_path( $field, 'layouts', array() ) as $layout ) {
				$sub_fields = array_merge( $sub_fields, (array) us_arr_path( $layout, 'sub_fields', array() ) );
			}
			foreach ( $sub_fields as $sub_field ) {
				if ( us_acf_mcp_needs_rest_check( (array) $sub_field ) ) {
					$needs = TRUE;
					break;
				}
			}
		}

		if ( $key !== '' ) {
			$cache[ $key ] = $needs;
		}

		return $needs;
	}

	/**
	 * Apply a callback to an ACF field and to its sub fields at any depth (Repeater,
	 * Flexible Content layouts, Group).
	 *
	 * @param array $field
	 * @param callable $callback Takes and returns a field.
	 * @return array
	 */
	function us_acf_mcp_walk_field( array $field, $callback ) {
		$field = call_user_func( $callback, $field );
		foreach ( (array) us_arr_path( $field, 'sub_fields', array() ) as $i => $sub_field ) {
			$field['sub_fields'][ $i ] = us_acf_mcp_walk_field( (array) $sub_field, $callback );
		}
		foreach ( (array) us_arr_path( $field, 'layouts', array() ) as $i => $layout ) {
			foreach ( (array) us_arr_path( $layout, 'sub_fields', array() ) as $j => $sub_field ) {
				$field['layouts'][ $i ]['sub_fields'][ $j ] = us_acf_mcp_walk_field( (array) $sub_field, $callback );
			}
		}

		return $field;
	}

	/**
	 * Turn off the pagination of an ACF Repeater and of the Repeaters in its sub fields.
	 *
	 * ACF Pro saves a paginated Repeater as a set of row edits ("row-N" keys) once
	 * acf/save_post has run in the request, and does not check its `min` rows.
	 * That action runs not only for the ACF metabox: ACF Pro calls acf_save_post()
	 * on save_post for a post with ACF blocks that keep their values in post meta,
	 * i.e. inside wp_insert_post() before the meta is written. Rows written then
	 * would be appended to the stored ones.
	 *
	 * @param array $field
	 * @return array
	 */
	function us_acf_mcp_field_no_pagination( array $field ) {
		return us_acf_mcp_walk_field( $field, function ( $field ) {
			$field['pagination'] = 0;
			return $field;
		} );
	}

	/**
	 * Prepare an ACF field for the validation on publish: "required" of the field itself is
	 * checked by us_mcp_validate_meta_input(), and a sub field with Conditional Logic is
	 * required only while shown, which depends on other values. Repeater pagination is
	 * turned off in the same walk, see us_acf_mcp_field_no_pagination().
	 *
	 * @param array $field
	 * @return array
	 */
	function us_acf_mcp_field_for_publish( array $field ) {
		$field = us_acf_mcp_walk_field( $field, function ( $field ) {
			$field['pagination'] = 0;
			/**
			 * A required Group makes all its sub fields required on validation, including
			 * the ones with Conditional Logic: do it here, so they can be skipped below.
			 */
			if ( us_arr_path( $field, 'type' ) === 'group' AND ! empty( $field['required'] ) ) {
				foreach ( (array) us_arr_path( $field, 'sub_fields', array() ) as $i => $sub_field ) {
					$field['sub_fields'][ $i ]['required'] = 1;
				}
				$field['required'] = 0;
			}
			if ( ! empty( $field['conditional_logic'] ) ) {
				$field['required'] = 0;
			}
			return $field;
		} );
		$field['required'] = 0;

		return $field;
	}

	/**
	 * Turn off "required" and the `min` items / rows count of an ACF field and of its
	 * sub fields at any depth, as ACF does not validate a draft. Repeater pagination is
	 * turned off in the same walk, see us_acf_mcp_field_no_pagination().
	 *
	 * @param array $field
	 * @return array
	 */
	function us_acf_mcp_field_for_draft( array $field ) {
		return us_acf_mcp_walk_field( $field, function ( $field ) {
			$field['pagination'] = 0;
			$field['required'] = 0;
			// For Number / Range `min` is the lowest value, which applies to drafts too
			if ( in_array( us_arr_path( $field, 'type' ), array( 'repeater', 'flexible_content', 'relationship', 'gallery' ), TRUE ) ) {
				$field['min'] = 0;
			}
			foreach ( (array) us_arr_path( $field, 'layouts', array() ) as $i => $layout ) {
				$field['layouts'][ $i ]['min'] = 0;
			}
			return $field;
		} );
	}

	/**
	 * Write (or clear, for NULL / '') one ACF field value through the ACF API, so
	 * ACF stores the `_{name} => field_key` reference next to the value and runs
	 * its acf/update_value hooks. Without the reference get_field() falls back to
	 * looking the field up by name, which picks the wrong field when two groups
	 * use the same name.
	 *
	 * ACF writes the value with update_metadata(), which unslashes it (the metabox
	 * passes the slashed $_POST), so the value is slashed here to keep backslashes.
	 *
	 * Clearing stores an empty value, as the ACF metabox does for an emptied field
	 * (0 for an unchecked True / False), instead of deleting the meta: ACF shows the
	 * field's Default Value when there is no meta at all, so a deleted True / False
	 * with the default "on" would come back checked.
	 *
	 * @param int $post_id
	 * @param string $key Meta key.
	 * @param array $spec The whitelist spec with the `acf` reference.
	 * @param mixed $value
	 * @return bool FALSE when the reference does not resolve (see
	 *              us_acf_mcp_get_field()) and the caller should write plain meta.
	 */
	function us_acf_mcp_write_value( $post_id, $key, array $spec, $value ) {
		$acf = $spec['acf'];
		if ( ! $field = us_acf_mcp_get_field( $key, $acf ) ) {
			return FALSE;
		}
		if ( $value === NULL OR $value === '' ) {
			$value = us_mcp_meta_empty_value( $spec );
		}

		if ( is_array( $acf ) ) {
			// update_sub_field() addresses repeater rows (parent, row, sub) and cannot
			// reach a Group sub field. Saving the Group with only this sub field in its
			// value is what the ACF metabox does: the Group field type writes the sub
			// fields present in the value (under "{group}_{sub}") and leaves the others
			// untouched.
			$field = acf_get_field( $acf[0] );
			$value = array( $acf[1] => $value );
		}

		// What update_field() does, with Repeater pagination turned off
		acf_update_value( wp_slash( $value ), $post_id, us_acf_mcp_field_no_pagination( $field ) );

		return TRUE;
	}
}

if ( ! function_exists( 'us_change_acf_date_format' ) ) {

	add_filter( 'us_filter_indexer_meta_value', 'us_change_acf_date_format', 10, 2 );

	/**
	 * Format dates from YYYYMMDD to YYYY-MM-DD
	 */
	function us_change_acf_date_format( $value, $meta_key ) {

		$date_picker_fields = array();

		foreach ( (array) acf_get_field_groups() as $group ) {
			foreach ( (array) acf_get_fields( $group['ID'] ) as $field ) {
				if ( $field['type'] == 'date_picker' ) {
					$date_picker_fields[] = $field['name'];
				}
			}
		}

		if (
			in_array( $meta_key, $date_picker_fields )
			AND strlen( $value ) == 8
			AND ctype_digit( $value )
		) {
			$value = substr( $value, 0, 4 ) . '-' . substr( $value, 4, 2 ) . '-' . substr( $value, 6, 2 );
		}
		return $value;
	}
}
