<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Yoast SEO Support
 *
 * @link https://yoast.com
 */


if ( ! function_exists( 'yoast_breadcrumb' ) ) {
	return FALSE;
}

if ( ! function_exists( 'us_wpseo_sitemap_urlimages' ) ) {
	/**
	 * Checking and adding images from Reusable Blocks
	 *
	 * @param array $images
	 * @param integer $post_id
	 * @return array
	 */
	function us_wpseo_sitemap_urlimages( $images, $post_id ) {
		if ( ! function_exists( 'us_get_recursive_page_blocks' ) ) {
			return $images;
		}
		$post = get_post( (int) $post_id );
		us_get_recursive_page_blocks(
			$post, function( $post ) use ( &$images ) {
			if ( preg_match_all( '/\[us_image\simage="(\d+)"/', $post->post_content, $matches ) ) {
				foreach ( us_arr_path( $matches, '1', array() ) as $attachment_id ) {
					$images[] = array(
						'alt' => get_post_meta( $attachment_id, '_wp_attachment_image_alt', TRUE ),
						'src' => wp_get_attachment_image_src( $attachment_id, 'full' )[0],
						'title' => get_the_title( $attachment_id ),
					);
				}
			}
		}
		);
		return $images;
	}
	add_filter( 'wpseo_sitemap_urlimages', 'us_wpseo_sitemap_urlimages', 10, 2 );
}

if ( ! function_exists( 'us_wpseo_indexable_excluded_post_types' ) ) {
	/**
	 * Exclude the theme's templates from Yoast indexables
	 *
	 * These post types have no pages of their own and are meant to be output inside other posts,
	 * so indexing them produces useless SEO data and may lead to infinite recursion
	 * of the Post Content element
	 *
	 * @param array $excluded_post_types The currently excluded post types
	 * @return array
	 */
	function us_wpseo_indexable_excluded_post_types( $excluded_post_types ) {
		if ( ! is_array( $excluded_post_types ) ) {
			$excluded_post_types = array();
		}

		return array_merge(
			$excluded_post_types, array(
				'us_content_template',
				'us_grid_layout',
				'us_header',
				'us_page_block',
			)
		);
	}
	add_filter( 'wpseo_indexable_excluded_post_types', 'us_wpseo_indexable_excluded_post_types' );
}
