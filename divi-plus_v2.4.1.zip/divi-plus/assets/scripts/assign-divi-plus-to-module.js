if ( window.vendor?.wp?.hooks ) {
    window.vendor.wp.hooks.addFilter('divi.moduleLibrary.moduleMapping', 'divi', modules => {

    //console.log(modules);
    // A path to select and modify in the `modules` object
    //const path = ['dipl/bar-counter', 'metadata'];
    const path = ['divi/audio', 'metadata'];

    // Helper functions and constants
    const { get, has } = window.lodash;
    const target = get(modules, path, {});

    //console.log(target);

    if (has(modules, path)) {
      target.folder = 'divi-plus';
    } else {
      console.warn(`Path ${path.join('.')} does not exist in modules.`);
    }

    // Return the modified modules
    return modules;
    });
} else {
  console.error('Required dependencies are not available.');
}