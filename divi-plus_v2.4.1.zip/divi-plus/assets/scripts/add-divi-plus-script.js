if ( window.divi?.moduleLibrary ) {
    console.log('test');
    window.divi.moduleLibrary.registerFolder({
        name: 'divi-plus',
        path: '',
        title: 'Divi Plus',
        icon: '',
        category: 'module',
    });
} else {
    console.error('Required dependencies are not available.');
}
