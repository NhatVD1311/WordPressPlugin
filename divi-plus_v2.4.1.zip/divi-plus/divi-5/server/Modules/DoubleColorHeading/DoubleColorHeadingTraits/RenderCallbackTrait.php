<?php
namespace DIPL\Modules\DoubleColorHeading\DoubleColorHeadingTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\DoubleColorHeading\DoubleColorHeading;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;

trait RenderCallbackTrait {
    public static function render_callback( $attrs, $content, $block, $elements ) {

        $display_in_stack       = $attrs['module']['advanced']['inStack']['desktop']['value'] ?? 'off';
        $wrapper_level          = $attrs['wrapper']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h2';

        $pre_part = $elements->render(
            [
                'attrName' => 'headingPrePart',
            ]
        );
        $pre_part = DynamicData::get_processed_dynamic_data($pre_part);

        $main_part = $elements->render(
            [
                'attrName' => 'headingMainPart',
            ]
        );
        $main_part = DynamicData::get_processed_dynamic_data($main_part);

        $post_part = $elements->render(
            [
                'attrName' => 'headingPostPart',
            ]
        );
        $post_part = DynamicData::get_processed_dynamic_data($post_part);


        if ( 'on' === $display_in_stack ) {
            $pre_part = HTMLUtility::render(
                [
                    'tag'               => 'span',
                    'attributes'        => [
                        'class' => 'dipl_text_stack dipl_pre_text_stack',
                    ],
                    'children'          => $pre_part,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
            $main_part = HTMLUtility::render(
                [
                    'tag'               => 'span',
                    'attributes'        => [
                        'class' => 'dipl_text_stack dipl_main_text_stack',
                    ],
                    'children'          => $main_part,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
            $post_part = HTMLUtility::render(
                [
                    'tag'               => 'span',
                    'attributes'        => [
                        'class' => 'dipl_text_stack dipl_post_text_stack',
                    ],
                    'children'          => $post_part,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
        }

        $wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => 'dipl_text_wrapper',
                ],
                'children'          => HTMLUtility::render(
                    [
                        'tag'               => $wrapper_level,
                        'children'          => $pre_part . $main_part . $post_part,
                        'childrenSanitizer' => 'et_core_esc_previously',
                    ]
                ),
                'childrenSanitizer' => 'et_core_esc_previously',
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'attrs'               => $attrs,
                'elements'            => $elements,
                'id'                  => $block->parsed_block['id'],
                'moduleClassName'     => '',
                'name'                => $block->block_type->name,
                'classnamesFunction'  => [ DoubleColorHeading::class, 'module_classnames' ],
                'moduleCategory'      => $block->block_type->category,
                'stylesComponent'     => [ DoubleColorHeading::class, 'module_styles' ],
                'scriptDataComponent' => [ DoubleColorHeading::class, 'module_script_data' ],
                'parentAttrs'         => $parent->attrs ?? [],
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $wrapper,
            ]
        );
    }
}
