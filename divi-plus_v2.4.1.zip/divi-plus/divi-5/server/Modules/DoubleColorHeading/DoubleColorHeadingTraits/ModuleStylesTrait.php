<?php
namespace DIPL\Modules\DoubleColorHeading\DoubleColorHeadingTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\DoubleColorHeading\DoubleColorHeading;

trait ModuleStylesTrait {

    use CustomCssTrait;

    public static function module_styles( $args ) {
        $attrs          = $args['attrs'] ?? [];
        $order_class    = $args['orderClass'];
        $elements       = $args['elements'];
        $settings       = $args['settings'] ?? [];

        $use_pre_part_background    = $attrs['headingPrePartBackground']['advanced']['use']['desktop']['value'] ?? 'off';
        $use_main_part_background   = $attrs['headingMainPartBackground']['advanced']['use']['desktop']['value'] ?? 'off';
        $use_post_part_background   = $attrs['headingPostPartBackground']['advanced']['use']['desktop']['value'] ?? 'off';

        $styles = [
            // Element: Module.
            $elements->style([
                'attrName'   => 'module',
                'styleProps' => [
                    'disabledOn' => [
                        'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                    ],
                ],
            ]),

            CssStyle::style([
                'selector'  => $args['orderClass'],
                'attr'      => $attrs['css'] ?? [],
                'cssFields' => self::custom_css(),
            ]),

            // Element: Wrapper.
            $elements->style([
                'attrName' => 'wrapper',
            ]),

            // Element: Pre Part.
            $elements->style([
                'attrName' => 'headingPrePart',
            ]),

            // Element: Main Part
            $elements->style([
                'attrName' => 'headingMainPart',
            ]),

            // Element: Post Part
            $elements->style([
                'attrName' => 'headingPostPart',
            ])
        ];

        if ( 'on' === $use_pre_part_background ) {
            array_push(
                $styles,
                $elements->style([
                    'attrName' => 'headingPrePartBackground',
                ])
            );
        }

        if ( 'on' === $use_main_part_background ) {
            array_push(
                $styles,
                $elements->style([
                    'attrName' => 'headingMainPartBackground',
                ])
            );
        }

        if ( 'on' === $use_post_part_background ) {
            array_push(
                $styles,
                $elements->style([
                    'attrName' => 'headingPostPartBackground',
                ])
            );
        }

        Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => $styles,
        ]);
    }
}