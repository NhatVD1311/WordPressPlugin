<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\DoubleColorHeading;
 */

namespace DIPL\Modules\DoubleColorHeading;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\DoubleColorHeading\DoubleColorHeadingTraits;

/**
 * Class DoubleColorHeading
 *
 * @package DIPL\Modules\DoubleColorHeading
 */
class DoubleColorHeading implements DependencyInterface {

    use DoubleColorHeadingTraits\RenderCallbackTrait;
    use DoubleColorHeadingTraits\ModuleClassnamesTrait;
    use DoubleColorHeadingTraits\ModuleStylesTrait;
    use DoubleColorHeadingTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/double-color-heading';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ DoubleColorHeading::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}