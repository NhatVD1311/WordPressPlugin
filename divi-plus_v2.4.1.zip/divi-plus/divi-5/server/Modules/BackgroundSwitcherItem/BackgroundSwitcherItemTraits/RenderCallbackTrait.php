<?php
namespace DIPL\Modules\BackgroundSwitcherItem\BackgroundSwitcherItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\BackgroundSwitcherItem\BackgroundSwitcherItem;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$show_button = $attrs['button']['advanced']['show']['desktop']['value'] ?? 'off';

		$title = $elements->render( [
			'attrName' => 'title',
		] );
		$description = $elements->render( [
			'attrName' => 'description',
		] );

		$render_button = '';
		if ( 'on' === $show_button ) {
			$render_button = $elements->render( [
				'attrName' => 'button',
			] );
			if ( ! empty( $render_button ) ) {
				$render_button = sprintf(
					'<div class="et_pb_button_wrapper dipl-bg-switcher-btn-wrap">%1$s</div>',
					et_core_esc_previously( $render_button )
				);
			}
		}

		$render_hover_content = '';
		if ( ! empty( $description ) || ! empty( $render_button ) ) {
			$render_hover_content = sprintf(
				'<div class="dipl_bg_switcher_hover_content">%1$s %2$s</div>',
				et_core_esc_previously( $description ),
				et_core_esc_previously( $render_button )
			);
		}

		// Final render output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'dipl_bg_switcher_item_wrap' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_bg_switcher_content">%1$s %2$s</div>',
				et_core_esc_previously( $title ),
				et_core_esc_previously( $render_hover_content )
			)
		] );

		// Module background.
		$background = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'dipl_background_switcher_image' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => '<div class="dipl_switcher_item_background"></div>'
		] );
		
		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent   = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ BackgroundSwitcherItem::class, 'module_classnames' ],
			'stylesComponent'     => [ BackgroundSwitcherItem::class, 'module_styles' ],
			'scriptDataComponent' => [ BackgroundSwitcherItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] ) . et_core_esc_previously( $background );
	}
}
