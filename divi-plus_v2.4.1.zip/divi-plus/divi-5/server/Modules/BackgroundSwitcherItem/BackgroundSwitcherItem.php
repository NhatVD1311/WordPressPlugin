<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BackgroundSwitcherItem;
 */
namespace DIPL\Modules\BackgroundSwitcherItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BackgroundSwitcherItem\BackgroundSwitcherItemTraits;

/**
 * Class BackgroundSwitcherItem
 *
 * @package DIPL\Modules\BackgroundSwitcherItem
 */
class BackgroundSwitcherItem implements DependencyInterface {

	use BackgroundSwitcherItemTraits\RenderCallbackTrait;
	use BackgroundSwitcherItemTraits\ModuleClassnamesTrait;
	use BackgroundSwitcherItemTraits\ModuleStylesTrait;
	use BackgroundSwitcherItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/background-switcher-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BackgroundSwitcherItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
