<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\AccordionSliderItem;
 */
namespace DIPL\Modules\AccordionSliderItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AccordionSliderItem\AccordionSliderItemTraits;

/**
 * Class AccordionSliderItem
 *
 * @package DIPL\Modules\AccordionSliderItem
 */
class AccordionSliderItem implements DependencyInterface {

	use AccordionSliderItemTraits\RenderCallbackTrait;
	use AccordionSliderItemTraits\ModuleClassnamesTrait;
	use AccordionSliderItemTraits\ModuleStylesTrait;
	use AccordionSliderItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/accordion-slider-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AccordionSliderItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
