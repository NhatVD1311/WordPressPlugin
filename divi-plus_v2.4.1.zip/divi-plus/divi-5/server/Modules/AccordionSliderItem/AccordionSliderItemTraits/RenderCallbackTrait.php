<?php
namespace DIPL\Modules\AccordionSliderItem\AccordionSliderItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\AccordionSliderItem\AccordionSliderItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get parent attrs.
		$parent                    = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_default_attributes = ModuleRegistration::get_default_attrs( 'dipl/accordion-slider' );
		$parent_attrs              = $parent->attrs ?? [];
		$parent_attrs_with_default = array_replace_recursive( $parent_default_attributes, $parent_attrs );

		// Slide Image.
		$disable_lazy_loading = $parent_attrs_with_default['image']['advanced']['disableLazyLoading']['desktop']['value'] ?? 'off';
		$image_classnames     = 'dipl_accordion_slider_item_image';
		if ( 'on' === $disable_lazy_loading ) {
			$image_classnames .= ' no-lazyload skip-lazy';
		}
		$slide_image = $elements->render( [
			'attrName'   => 'image',
			'attributes' => [ 'class' => $image_classnames ],
		] );

		// Icon.
		$use_icon  = $attrs['icon']['advanced']['useIcon']['desktop']['value'] ?? 'off';
		$icon      = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
		$icon_html = '';
		if ( 'on' === $use_icon && ! empty( $icon ) ) {
			$icon_html = HTMLUtility::render( [
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'et-pb-icon dipl_hover_list_icon' ],
				'childrenSanitizer' => 'esc_html',
				'children'          => Utils::process_font_icon( $icon ),
			] );
			if ( ! empty( $icon_html ) ) {
				$icon_html = sprintf(
					'<div class="dipl_accordion_slider_item_icon">%1$s</div>',
					et_core_esc_previously( $icon_html )
				);
			}
		}

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );
		// Render content.
		$description = $elements->render( [
			'attrName' => 'description',
		] );

		// Show button.
		$show_button = $attrs['button']['advanced']['show']['desktop']['value'] ?? 'off';
		$button      = '';
		if ( 'on' === $show_button ) {
			$button = $elements->render( [
				'attrName' => 'button',
			] );
		}

		// Append title, description, icon, button to slide image.
		$content_wrapper = '';
		if ( ! empty( $title ) || ! empty( $description ) || ! empty( $button ) ) {
			$content_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_accordion_slider_item_content' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => sprintf(
					'<div class="dipl_accordion_slider_item_content_inner">
						%1$s %2$s %3$s %4$s
					</div>',
					et_core_esc_previously( $icon_html ),
					et_core_esc_previously( $title ),
					et_core_esc_previously( $description ),
					et_core_esc_previously( $button )
				)
			] );
		}

		// Final render output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'dipl_accordion_slider_item_wrapper' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_accordion_slider_item_inner">
					%1$s %2$s
				</div>',
				et_core_esc_previously( $slide_image ),
				et_core_esc_previously( $content_wrapper )
			)
		] );
		
		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AccordionSliderItem::class, 'module_classnames' ],
			'stylesComponent'     => [ AccordionSliderItem::class, 'module_styles' ],
			'scriptDataComponent' => [ AccordionSliderItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
