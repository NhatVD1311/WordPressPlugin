<?php
namespace DIPL\Modules\AccordionSliderItem\AccordionSliderItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DIPL\Modules\AccordionSliderItem\AccordionSliderItem;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => "{$order_class}",
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),
			TextStyle::style( [
				'selector' => "{$order_class}",
				'attr'     => $attrs['module']['advanced']['text'] ?? [], //orientation.
			] ),

			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'description',
			] ),
		);

		// Icon style.
		$use_icon = $attrs['icon']['advanced']['useIcon']['desktop']['value'] ?? 'off';
		if ( 'on' === $use_icon ) {
			array_push( $styles, CommonStyle::style( [
				'selector'            => "{$order_class} .dipl_accordion_slider_item_icon .et-pb-icon",
				'attr'                => $attrs['icon']['innerContent'] ?? [],
				'declarationFunction' => [ AccordionSliderItem::class, 'icon_font_declaration' ],
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['fontSize'] ?? [],
				'property'  => 'font-size',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['color'] ?? [],
				'property'  => 'color',
			] ) );
		}
		
		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
