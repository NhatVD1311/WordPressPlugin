<?php
namespace DIPL\Modules\AdvancedTooltip\AdvancedTooltipTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\AdvancedTooltip\AdvancedTooltip;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			// Tooltip styling.
			$elements->style( [
				'attrName' => 'tooltip',
			] ),
			$elements->style( [
				'attrName' => 'tooltipContent',
			] )
        );

		// Trigger element wise style.
		$trigger_element = $attrs['configuration']['advanced']['triggerElement']['desktop']['value'] ?? 'button';
		if ( 'button' === $trigger_element ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'triggerButton',
			] ) );
		} elseif ( 'image' === $trigger_element ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'triggerImage',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_tooltip_trigger_element_wrap.trigger_type_image",
				'attr'     => $attrs['triggerImage']['advanced']['alignment'] ?? [],
				'property' => 'text-align',
			] ) );
		} elseif ( 'icon' === $trigger_element ) {
			array_push( $styles, CommonStyle::style( [
				'selector'            => "{$order_class} .dipl_tooltip_trigger_icon",
				'attr'                => $attrs['triggerIcon']['innerContent'] ?? [],
				'declarationFunction' => [ AdvancedTooltip::class, 'icon_font_declaration' ],
			] ) );

			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_tooltip_trigger_element_wrap.trigger_type_icon",
				'attr'     => $attrs['triggerIcon']['advanced']['alignment'] ?? [],
				'property' => 'text-align',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_tooltip_trigger_icon",
				'attr'     => $attrs['triggerIcon']['advanced']['fontsize'] ?? [],
				'property' => 'font-size',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_tooltip_trigger_icon",
				'attr'     => $attrs['triggerIcon']['advanced']['color'] ?? [],
				'property' => 'color',
			] ) );
		} elseif ( 'text' === $trigger_element ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'triggerText',
			] ) );
		}

		// Content selector.
		$tp_theme_class = esc_attr( $order_class ) . '_0';
		$tp_box_class   = ".tippy-box[data-theme=\"{$tp_theme_class}\"]";

		// Show speach bubble.
		$showSpeechBubble = $attrs['tooltip']['advanced']['showSpeechBubble']['desktop']['value'] ?? 'on';
		if ( 'on' === $showSpeechBubble ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}, {$tp_box_class}:before",
				'attr'      => [ 'desktop' => [ 'value' => 'visible' ] ],
				'property'  => 'overflow',
				'important' => true
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}:before",
				'attr'      => [ 'desktop' => [ 'value' => "\"\"" ] ],
				'property'  => 'content',
				'important' => true
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}[data-placement^='top']",
				'attr'      => [ 'desktop' => [ 'value' => '15px' ] ],
				'property'  => 'margin-bottom',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}[data-placement^='bottom']",
				'attr'      => [ 'desktop' => [ 'value' => '15px' ] ],
				'property'  => 'margin-top',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}[data-placement^='right']",
				'attr'      => [ 'desktop' => [ 'value' => '15px' ] ],
				'property'  => 'margin-left',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$tp_box_class}[data-placement^='left']",
				'attr'      => [ 'desktop' => [ 'value' => '15px' ] ],
				'property'  => 'margin-right',
			] ) );
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
