<?php
namespace DIPL\Modules\AdvancedTooltip\AdvancedTooltipTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Helpers\DIPLUtils;
use DIPL\Modules\AdvancedTooltip\AdvancedTooltip;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Get order class.
		$order_class = ModuleUtils::get_module_order_class_name(
			$block->parsed_block['id'],
			$block->parsed_block['storeInstance']
		);
		if ( empty( $order_class ) && ! empty( $elements->order_index ) ) {
			$order_class = 'dipl_advanced_tooltip_' . esc_attr( $elements->order_index );
		}

		// Get the attrs.
		$trigger_element = $attrs['configuration']['advanced']['triggerElement']['desktop']['value'] ?? 'button';
		$trigger_icon    = $attrs['triggerIcon']['innerContent']['desktop']['value'] ?? [];
		$content_type    = $attrs['tooltipContent']['advanced']['type']['desktop']['value'] ?? 'text';
		$layout_id       = $attrs['tooltipContent']['advanced']['library']['desktop']['value'] ?? 0;

		// Get render element.
		$render_element = '';
		if ( 'button' === $trigger_element ) {
			$render_element = $elements->render( [
				'attrName' => 'triggerButton',
			] );
		} elseif ( 'image' === $trigger_element ) {
			$render_element = $elements->render( [
				'attrName' => 'triggerImage',
			] );
		} elseif ( 'icon' === $trigger_element ) {
			$render_element = HTMLUtility::render( [
				'tag'               => 'span',
				'attributes'        => [ 'class' => 'dipl_tooltip_trigger_element dipl_tooltip_trigger_icon et-pb-icon' ],
				'childrenSanitizer' => 'esc_html',
				'children'          => Utils::process_font_icon( $trigger_icon ),
			] );
		} elseif ( 'text' === $trigger_element ) {
			$render_element = $elements->render( [
				'attrName' => 'triggerText',
			] );
		}

		// Get render tooltip content.
		$tooltip_content = '';
		if ( 'text' === $content_type ) {
			$tooltip_content = $elements->render( [
				'attrName' => 'tooltipContent',
			] );
		} elseif ( 'image' === $content_type ) {
			$tooltip_content = $elements->render( [
				'attrName' => 'tooltipImage',
			] );
		} elseif ( 'layout' === $content_type && ! empty( $layout_id ) ) {
			// $tooltip_content = do_shortcode( get_the_content( null, false, $layout_id ) );
			// $tooltip_content = apply_filters( 'the_content', $tooltip_content );
			$tooltip_content = DIPLUtils::load_library_content( $layout_id, $order_class );
		}

		// Final output.
		$rendered_output = '';
		if ( ! empty( $render_element ) || ( 'id' === $trigger_element || 'class' === $trigger_element ) ) {

			$tooltip_placement_desktop = $attrs['configuration']['advanced']['tooltipPlacement']['desktop']['value'] ?? 'auto';
			$tooltip_placement_tablet  = $attrs['configuration']['advanced']['tooltipPlacement']['tablet']['value'] ?? $tooltip_placement_desktop;
			$tooltip_placement_phone   = $attrs['configuration']['advanced']['tooltipPlacement']['phone']['value'] ?? $tooltip_placement_tablet;

			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'class'                  => 'dipl_tooltip_trigger_element_wrap trigger_type_' . esc_attr( $trigger_element ),
					'data-trigger-action'    => $attrs['configuration']['advanced']['triggerAction']['desktop']['value'] ?? 'mouseenter',
					'data-animation'         => $attrs['tooltip']['advanced']['entranceAnimation']['desktop']['value'] ?? 'fade',
					'data-durartion'         => $attrs['tooltip']['advanced']['animationDurartion']['desktop']['value'] ?? '350ms',
					'data-interactive'       => $attrs['tooltip']['advanced']['interactive']['desktop']['value'] ?? 'off',
					'data-tooltip-width'     => $attrs['tooltip']['advanced']['width']['desktop']['value'] ?? '350px',
					'data-trigger-element'   => esc_attr( $trigger_element ),
					'data-trigger-selector'  => $attrs['configuration']['advanced']['triggerSelector']['desktop']['value'] ?? '',
					'data-placement-desktop' => esc_attr( $tooltip_placement_desktop ),
					'data-placement-tablet'  => esc_attr( $tooltip_placement_tablet ),
					'data-placement-phone'   => esc_attr( $tooltip_placement_phone ),
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => et_core_esc_previously( $render_element )
			] );
		}

		// Add tooltip content.
		if ( ! empty( $tooltip_content ) ) {

			// Load style and scripts.
			wp_enqueue_script( 'tippy-tooltip' );
			if ( ! empty( $entrance_animation ) && 'fade' !== $entrance_animation ) {
				wp_enqueue_style( 'tippy-anim-' . esc_attr( $entrance_animation ) );
			}

			$rendered_output .= HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'id'    => esc_attr( $order_class ) . '_content_wrap',
					'class' => 'dipl_advanced_tooltip_content_wrap'
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => sprintf(
					'<div class="dipl_advanced_tooltip_content %1$s_content">%2$s</div>',
					esc_attr( $order_class ),
					et_core_esc_previously( $tooltip_content )
				)
			] );
		}

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AdvancedTooltip::class, 'module_classnames' ],
			'stylesComponent'     => [ AdvancedTooltip::class, 'module_styles' ],
			'scriptDataComponent' => [ AdvancedTooltip::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
