<?php
/**
 * Advanced Tooltip Module class.
 *
 * @author     Elicus <hello@elicus.com>
 * @link       https://www.elicus.com/
 * @copyright  2025 Elicus Technologies Private Limited
 * @version    1.17.0
 * 
 * @package DIPL\Modules\AdvancedTooltip;
 */
namespace DIPL\Modules\AdvancedTooltip;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AdvancedTooltip\AdvancedTooltipTraits;

/**
 * Class AdvancedTooltip
 *
 * @package DIPL\Modules\AdvancedTooltip
 */
class AdvancedTooltip implements DependencyInterface {

	use AdvancedTooltipTraits\RenderCallbackTrait;
	use AdvancedTooltipTraits\ModuleClassnamesTrait;
	use AdvancedTooltipTraits\ModuleStylesTrait;
	use AdvancedTooltipTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/advanced-tooltip';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AdvancedTooltip::class, 'render_callback' ] ]
				);
			}
		);
	}
}
