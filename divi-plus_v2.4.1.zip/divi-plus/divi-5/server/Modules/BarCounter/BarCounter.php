<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BarCounter;
 */

namespace DIPL\Modules\BarCounter;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BarCounter\BarCounterTraits;

/**
 * Class BarCounter
 *
 * @package DIPL\Modules\BarCounter
 */
class BarCounter implements DependencyInterface {

    use BarCounterTraits\RenderCallbackTrait;
    use BarCounterTraits\ModuleClassnamesTrait;
    use BarCounterTraits\ModuleStylesTrait;
    use BarCounterTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/bar-counter';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ BarCounter::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}