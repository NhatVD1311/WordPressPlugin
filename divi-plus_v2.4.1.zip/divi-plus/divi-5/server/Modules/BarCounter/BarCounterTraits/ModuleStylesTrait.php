<?php
namespace DIPL\Modules\BarCounter\BarCounterTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\BarCounter\BarCounter;

trait ModuleStylesTrait {

	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs          = $args['attrs'] ?? [];
		$order_class    = $args['orderClass'];
		$elements       = $args['elements'];
		$settings       = $args['settings'] ?? [];

		$bar_layout                 = $attrs['barLayout']['desktop']['value'] ?? 'layout1';
		$percent                    = absint( $attrs['percent']['desktop']['value'] ) ?? '50';
		$show_empty_bar             = $attrs['showEmptyBar']['desktop']['value'] ?? 'off';
		$use_stripes                = $attrs['useStripes']['desktop']['value'] ?? 'off';
		$use_animated_stripes       = $attrs['useAnimatedStripes']['desktop']['value'] ?? 'off';
		$animation_speed            = floatval( $attrs['animationSpeed']['desktop']['value'] ) . 's';
		$stripe_color               = $attrs['stripeColor']['desktop']['value'] ?? 'rgba(255,255,255,.15)';
		$enable_custom_chunks_size  = $attrs['enableCustomChunksSize']['desktop']['value'] ?? 'off';
		$chunks_width               = $attrs['chunksWidth']['desktop']['value'] ?? 'auto';
		$chunks_height              = $attrs['chunksHeight']['desktop']['value'] ?? 'auto';

		$width = ( intval( round( $percent/10 ) ) * 10 ) . '%';
	
		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $args['orderClass'],
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			// Element: Title.
			$elements->style( [
				'attrName' => 'title',
			] ),
			// Element: Percent.
			$elements->style( [
				'attrName' => 'percent',
			] ),
			// Element: Bar Counter Bar/Bar Chunks Background
			$elements->style( [
				'attrName' => 'bar',
			] ),
			// Element: Filled Bar Counter Bar/Filled Bar Chunks Background
			$elements->style( [
				'attrName' => 'filledBar',
			] ),
		];

		if ( 'layout2' === $bar_layout ) {
			if ( 'off' === $show_empty_bar ) {
				$width = array();
				$width['desktop']['value'] = ( intval( round( $percent/10 ) ) * 10 ) . '%';
				if (
					'off' === $enable_custom_chunks_size ||
					( ( '' === $chunks_width || 'auto' === $chunks_width ) && ( '' === $chunks_height || 'auto' === $chunks_height ) )
				) {
					array_push( $styles, CommonStyle::style( [
						'selector'  => "{$order_class} .layout2 .dipl_bar_counter_filled_bar_wrapper",
						'attr'      => $width,
						'property'  => 'width',
						'important' => true,
					] ) );
				}
			}

			if ( 'on' === $enable_custom_chunks_size &&
				(
					( '' !== $chunks_width && 'auto' !== $chunks_width ) ||
					( '' !== $chunks_height && 'auto' !== $chunks_height )
				)
			) {
				array_push(
					$styles,
					CommonStyle::style( [
						'selector' => "{$order_class} .layout2 .dipl_bar_counter_filled_bar_wrapper",
						'attr'     => array( 'desktop' => array( 'value' => 'center' ) ),
						'property' => 'align-items',
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_bar_counter_chunks",
						'attr'     =>  $attrs['chunksWidth'],
						'property' => 'width',
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_bar_counter_chunks",
						'attr'     =>  $attrs['chunksHeight'],
						'property' => 'height',
					] )
				);

				if ( '' !== $chunks_width && 'auto' !== $chunks_width ) {
					array_push( $styles, CommonStyle::style( [
						'selector' => "{$order_class} .dipl_bar_counter_chunks",
						'attr'     =>  array( 'desktop' => array( 'value' => '0' ) ),
						'property' => 'flex-grow',
					] ) );
				}
			}
		}

		array_push(
			$styles,
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_bar_counter_animated_striped_bar:before",
				'attr'     => array( 'desktop' => array( 'value' => $animation_speed ) ),
				'property' => 'animation-duration',
			] ),      
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_bar_counter_striped_bar:before, {$order_class} .dipl_bar_counter_animated_striped_bar:before",
				'attr'     => array( 'desktop' => array( 'value' => sprintf( '-webkit-linear-gradient(135deg, %1$s 25%%, transparent 25%%, transparent 50%%, %1$s 50%%, %1$s 75%%, transparent 75%%, transparent)', esc_attr( $stripe_color ) ) ) ),
				'property' => 'background-image',
				'important' => true,
			] ),
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_bar_counter_striped_bar:before, {$order_class} .dipl_bar_counter_animated_striped_bar:before",
				'attr'     => array( 'desktop' => array( 'value' => sprintf( '-moz-linear-gradient(135deg, %1$s 25%%, transparent 25%%, transparent 50%%, %1$s 50%%, %1$s 75%%, transparent 75%%, transparent)', esc_attr( $stripe_color ) ) ) ),
				'property' => 'background-image',
				'important' => true,
			] ),
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_bar_counter_striped_bar:before, {$order_class} .dipl_bar_counter_animated_striped_bar:before",
				'attr'     => array( 'desktop' => array( 'value' => sprintf( '-moz-linear-gradient(135deg, %1$s 25%%, transparent 25%%, transparent 50%%, %1$s 50%%, %1$s 75%%, transparent 75%%, transparent)', esc_attr( $stripe_color ) ) ) ),
				'property' => 'background-image',
				'important' => true,
			] )
		);

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
