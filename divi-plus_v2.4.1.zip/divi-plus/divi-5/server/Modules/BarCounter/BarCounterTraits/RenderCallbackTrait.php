<?php
namespace DIPL\Modules\BarCounter\BarCounterTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\BarCounter\BarCounter;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;

trait RenderCallbackTrait {
    public static function render_callback( $attrs, $content, $block, $elements ) {

        $bar_layout                 = $attrs['barLayout']['desktop']['value'] ?? 'layout1';
        $percent                    = absint( $attrs['percent']['desktop']['value'] ) ?? '50';
        $show_empty_bar             = $attrs['showEmptyBar']['desktop']['value'] ?? 'off';
        $use_stripes                = $attrs['useStripes']['desktop']['value'] ?? 'off';
        $use_animated_stripes       = $attrs['useAnimatedStripes']['desktop']['value'] ?? 'off';
        $animation_speed            = floatval( $attrs['animationSpeed']['desktop']['value'] ) ?? '1';

        $title = $elements->render(
            [
                'attrName' => 'title',
            ]
        );

        $title = DynamicData::get_processed_dynamic_data($title);

        if ( $percent > 100 ) {
            $percent = 100;
        }

        $bar_wrapper = '';
        
        if ( 'layout1' === $bar_layout ) {
            $stripe_class =  'on' === $use_stripes ? 'on' === $use_animated_stripes ? 'dipl_bar_counter_animated_striped_bar' : 'dipl_bar_counter_striped_bar' : '';
            $filled_bar = HTMLUtility::render(
                [
                    'tag'               => 'div',
                    'attributes'        => [
                        'data-percent' => esc_attr( $percent ),
                        'class' => 'dipl_bar_counter_filled_bar_wrapper',
                    ],
                    'children'          => HTMLUtility::render(
                        [
                            'tag'               => 'div',
                            'attributes'        => [
                                'class' => "dipl_bar_counter_filled_bar $stripe_class",
                            ],
                        ]
                    ) . HTMLUtility::render(
                        [
                            'tag'               => 'div',
                            'attributes'        => [
                                'class' => "dipl_bar_counter_percent",
                            ],
                            'children'          => $percent . '%',
                            'childrenSanitizer' => 'esc_html',
                        ]
                    ),
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
            
            if ( 'on' === $show_empty_bar ) {
                $bar = HTMLUtility::render(
                    [
                        'tag'               => 'div',
                        'attributes'        => [
                            'class' => "dipl_bar_counter_bar",
                        ],
                        'children'          => $filled_bar,
                        'childrenSanitizer' => 'et_core_esc_previously',
                    ]
                );
            }

            $bar_wrapper = HTMLUtility::render(
                [
                    'tag'               => 'div',
                    'attributes'        => [
                        'class' => "dipl_bar_counter_bar_wrapper",
                    ],
                    'children'          => 'on' === $show_empty_bar ? $bar : $filled_bar,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
        }

        if ( 'layout2' === $bar_layout ) {
            $filled_chunks = absint( round( $percent/10 ) );
            $filled_chunks = $filled_chunks < 1 ? 1 : $filled_chunks;
            $chunks        = '';
            for ( $i=1; $i <= $filled_chunks; $i++ ) {
                $chunks .= HTMLUtility::render(
                    [
                        'tag'               => 'div',
                        'attributes'        => [
                            'class' => "dipl_bar_counter_chunks dipl_bar_counter_filled_chunks",
                        ]
                    ]
                );
            }
            
            if ( 'on' === $show_empty_bar ) {
                $empty_chunks  = 10 - $filled_chunks;
                if ( $empty_chunks > 0 ) {
                    for ( $i=1; $i <= $empty_chunks; $i++ ) {
                        $chunks .= HTMLUtility::render(
                            [
                                'tag'               => 'div',
                                'attributes'        => [
                                    'class' => "dipl_bar_counter_chunks dipl_bar_counter_empty_chunks",
                                ]
                            ]
                        );
                    }
                }
            }

            $chunks .= HTMLUtility::render(
                [
                    'tag'               => 'span',
                    'attributes'        => [
                        'class' => "dipl_bar_counter_percent",
                    ],
                    'children'          => $percent . '%',
                    'childrenSanitizer' => 'esc_html',
                ]
            );

            $filled_bar = HTMLUtility::render(
                [
                    'tag'               => 'div',
                    'attributes'        => [
                        'data-percent' => esc_attr( $percent ),
                        'class' => 'dipl_bar_counter_filled_bar_wrapper',
                    ],
                    'children'          => $chunks,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );

            $bar_wrapper = HTMLUtility::render(
                [
                    'tag'               => 'div',
                    'attributes'        => [
                        'class' => 'dipl_bar_counter_bar_wrapper',
                    ],
                    'children'          => $filled_bar,
                    'childrenSanitizer' => 'et_core_esc_previously',
                ]
            );
        }

        $wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => "dipl_bar_counter_wrapper $bar_layout",
                ],
                'children'          => $title . $bar_wrapper,
                'childrenSanitizer' => 'et_core_esc_previously',
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'attrs'               => $attrs,
                'elements'            => $elements,
                'id'                  => $block->parsed_block['id'],
                'moduleClassName'     => '',
                'name'                => $block->block_type->name,
                'classnamesFunction'  => [ BarCounter::class, 'module_classnames' ],
                'moduleCategory'      => $block->block_type->category,
                'stylesComponent'     => [ BarCounter::class, 'module_styles' ],
                'scriptDataComponent' => [ BarCounter::class, 'module_script_data' ],
                'parentAttrs'         => $parent->attrs ?? [],
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $wrapper,
            ]
        );
    }
}
