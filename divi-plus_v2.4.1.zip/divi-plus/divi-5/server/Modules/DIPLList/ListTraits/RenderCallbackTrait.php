<?php
namespace DIPL\Modules\DIPLList\ListTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use DIPL\Modules\DIPLList\DIPLList;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$layout            = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'default';
		$hide_last_divider = $attrs['divider']['advanced']['hideLast']['desktop']['value'] ?? 'off';

		// Final output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'dipl_list_wrapper' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_list_layout dipl_list_%1$s %2$s">%3$s</div>',
				esc_attr( $layout ),
				( 'on' === $hide_last_divider ) ? 'dipl_hide_last_divider' : '',
				et_core_intentionally_unescaped( $content, 'html' )
			)
		] );
		
		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ DIPLList::class, 'module_classnames' ],
			'stylesComponent'     => [ DIPLList::class, 'module_styles' ],
			'scriptDataComponent' => [ DIPLList::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
