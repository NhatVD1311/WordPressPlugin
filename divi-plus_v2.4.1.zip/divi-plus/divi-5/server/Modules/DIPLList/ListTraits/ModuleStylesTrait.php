<?php
namespace DIPL\Modules\DIPLList\ListTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\DIPLList\DIPLList;

trait ModuleStylesTrait {

	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'itemText',
			] ),
			$elements->style( [
				'attrName' => 'image',
			] ),
			$elements->style( [
				'attrName' => 'divider',
			] ),

			// Icon.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list-icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['fontsize'] ?? [],
				'property'  => 'font-size',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list-icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['width'] ?? [],
				'property'  => 'width',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list-icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['color'] ?? [],
				'property'  => 'color',
			] ),

			// Divider.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list-divider",
				'attr'      => $attrs['divider']['advanced']['style'] ?? [],
				'property'  => 'border-style',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list-divider",
				'attr'      => $attrs['divider']['advanced']['color'] ?? [],
				'property'  => 'border-color',
			] ),
		];

		$layout = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'default';

		// Alignment.
		$alignment = $attrs['module']['advanced']['alignment'] ?? [];
		foreach ( $alignment as $devide => &$val ) {
			if ( ! empty($val['value']) ) {
				$val['value'] = str_replace( array( 'left', 'right' ), array( 'flex-start', 'flex-end' ), $val['value'] );
			}
		}
		if ( 'inline' === $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list_layout.dipl_list_inline",
				'attr'      => $alignment,
				'property'  => 'justify-content',
			] ) );
		} else {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_list_layout.dipl_list_default",
				'attr'      => $alignment,
				'property'  => 'align-items',
			] ) );
		}

		// Divider size.
		$divider_size = $attrs['divider']['advanced']['size'] ?? [];
		foreach ( $divider_size as $devide => &$val ) {
			if ( ! empty($val['value']) ) {
				$val['value'] = intval( $val['value'] ) . 'px';
			}
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_list-divider",
			'attr'      => $divider_size,
			'property'  => ( 'inline' === $layout ) ? 'border-right-width' : 'border-top-width',
		] ) );

		// Text Indent.
		$item_text_indent = $attrs['itemText']['advanced']['indent'] ?? [];
		foreach ( $item_text_indent as $devide => &$val ) {
			if ( ! empty($val['value']) ) {
				$val['value'] = intval( $val['value'] ) . 'px';
			}
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_list-item_text",
			'attr'      => $item_text_indent,
			'property'  => 'text-indent',
		] ) );

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
