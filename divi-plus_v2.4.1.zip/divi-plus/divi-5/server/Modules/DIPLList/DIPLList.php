<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\DIPLList;
 */
namespace DIPL\Modules\DIPLList;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\DIPLList\ListTraits;

/**
 * Class DIPLList
 *
 * @package DIPL\Modules\DIPLList
 */
class DIPLList implements DependencyInterface {

	use ListTraits\RenderCallbackTrait;
	use ListTraits\ModuleClassnamesTrait;
	use ListTraits\ModuleStylesTrait;
	use ListTraits\ModuleScriptDataTrait;
	
	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/dipl-list';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ DIPLList::class, 'render_callback' ] ]
				);
			}
		);
	}
}
