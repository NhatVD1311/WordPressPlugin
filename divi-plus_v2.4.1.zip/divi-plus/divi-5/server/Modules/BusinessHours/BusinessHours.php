<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BusinessHours;
 */

namespace DIPL\Modules\BusinessHours;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\BusinessHours\BusinessHoursTraits;

/**
 * Class BusinessHours
 *
 * @package DIPL\Modules\BusinessHours
 */
class BusinessHours implements DependencyInterface {

  use BusinessHoursTraits\RenderCallbackTrait;
  use BusinessHoursTraits\ModuleClassnamesTrait;
  use BusinessHoursTraits\ModuleStylesTrait;
  use BusinessHoursTraits\ModuleScriptDataTrait;

  public function load() {
    $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/business-hours';

    add_action(
      'init',
      function() use ( $module_json_folder_path ) {
        ModuleRegistration::register_module(
          $module_json_folder_path,
          [
            'render_callback' => [ BusinessHours::class, 'render_callback' ],
          ]
        );
      }
    );
  }
}