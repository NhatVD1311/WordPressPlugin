<?php
namespace DIPL\Modules\BusinessHours\BusinessHoursTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

trait ModuleStylesTrait {

  use CustomCssTrait;

  public static function module_styles( $args ) {
    $attrs       = $args['attrs'] ?? [];
    $order_class = $args['orderClass'];
    $elements    = $args['elements'];
    $settings    = $args['settings'] ?? [];


    Style::add(
      [
        'id'            => $args['id'],
        'name'          => $args['name'],
        'orderIndex'    => $args['orderIndex'],
        'storeInstance' => $args['storeInstance'],
        'styles'        => [
          // Element: Module.
          $elements->style(
            [
              'attrName'   => 'module',
              'styleProps' => [
                'disabledOn' => [
                  'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                ],
              ],
            ]
          ),
          CssStyle::style(
            [
              'selector'  => $order_class,
              'attr'      => $attrs['css'] ?? [],
              'cssFields' => self::custom_css(),
            ]
          ),

          // Element: Day.
          $elements->style(
              [
                  'attrName' => 'day',
              ]
          ),

          // Element: Time.
          $elements->style(
              [
                  'attrName' => 'time',
              ]
          ),
        ],
      ]
    );
  }
}