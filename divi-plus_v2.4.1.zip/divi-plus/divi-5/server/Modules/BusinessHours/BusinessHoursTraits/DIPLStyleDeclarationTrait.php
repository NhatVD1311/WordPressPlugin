<?php
/**
 * DynamicMasonryGallery::icon_style_declaration().
 *
 * @package Builder\Packages\ModuleLibrary
 * @since 2.0.0
 */

namespace DIPL\Modules\BusinessHours\BusinessHoursTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

trait DIPLStyleDeclarationTrait {
	/**
	 * Icon Font declaration.
	 *
	 * This function will declare icon font for Child module.
	 *
	 * @param array $params {
	 *     An array of arguments.
	 *
	 *     @type array      $attrValue  The value (breakpoint > state > value) of module attribute.
	 *     @type bool|array $important  If set to true, the CSS will be added with !important.
	 *     @type string     $returnType This is the type of value that the function will return. Can be either string or key_value_pair.
	 * }
	 *
	 * @return string
	 * @since 2.0.0
	 */
	public static function icon_font_declaration( $params ) {
		$icon_attr = $params['attrValue'] ?? [];

		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
			'important'  => [
				'font-family' => true,
				// 'content'  => true,
			],
		] );

		if ( ! empty( $icon_attr['unicode'] ) ) {
			$style_declarations->add( 'content', "'" . Utils::escape_font_icon( Utils::process_font_icon( $icon_attr ) ) . "'" );
			$font_family = isset( $icon_attr['type'] ) && 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', $font_family );
		}

		return $style_declarations->value();
	}
}