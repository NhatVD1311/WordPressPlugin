<?php
/**
 * Content Toggle Module Controller.
 *
 * @package DIPL\Modules\FilterableGallery;
 */
namespace DIPL\Modules\FilterableGallery;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Controllers\RESTController;
use ET\Builder\Framework\UserRole\UserRole;
use DIPL\Modules\FilterableGallery\FilterableGallery;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Class FilterableGalleryController
 *
 * @package DIPL\Modules\FilterableGallery
 */
class FilterableGalleryController extends RESTController {

	/**
	 * Return data for the Dynamic Module.
	 *
	 * @param WP_REST_Request $request REST request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public static function index( WP_REST_Request $request ): WP_REST_Response {
		$args   = array(
			'number_of_images'   => $request->get_param( 'number_of_images' ),
			'include_categories' => $request->get_param( 'include_categories' ),
			'offset_number'      => $request->get_param( 'offset_number' ),
			'order_by'           => $request->get_param( 'order_by' ),
			'order'              => $request->get_param( 'order' ),
			'image_size'         => $request->get_param( 'image_size' ),
		);

		$response = [
			'data' => FilterableGallery::get_gallery_images_data( $args ),
		];

		return self::response_success( $response );
	}

	/**
	 * Index action arguments.
	 *
	 * Endpoint arguments as used in `register_rest_route()`.
	 *
	 * @return array
	 */
	public static function index_args(): array {
		return [
			'id' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_html( $value );
				},
			],
		];
	}

	/**
	 * Index action permission.
	 *
	 * Endpoint permission callback as used in `register_rest_route()`.
	 *
	 * @return bool
	 */
	public static function index_permission(): bool {
		return UserRole::can_current_user_use_visual_builder();
	}
}
