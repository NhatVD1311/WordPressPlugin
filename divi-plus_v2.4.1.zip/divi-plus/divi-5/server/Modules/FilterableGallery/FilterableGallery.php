<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FilterableGallery;
 */
namespace DIPL\Modules\FilterableGallery;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\FilterableGallery\FilterableGalleryTraits;

/**
 * Class FilterableGallery
 *
 * @package DIPL\Modules\FilterableGallery
 */
class FilterableGallery implements DependencyInterface {

	use FilterableGalleryTraits\RenderCallbackTrait;
	use FilterableGalleryTraits\RenderContentTrait;
	use FilterableGalleryTraits\ModuleClassnamesTrait;
	use FilterableGalleryTraits\ModuleStylesTrait;
	use FilterableGalleryTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/filterable-gallery';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FilterableGallery::class, 'render_callback' ] ]
				);
			}
		);
	}
}
