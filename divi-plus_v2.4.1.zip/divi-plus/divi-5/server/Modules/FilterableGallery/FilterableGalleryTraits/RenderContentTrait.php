<?php
namespace DIPL\Modules\FilterableGallery\FilterableGalleryTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {
	public static function get_gallery_images_data( $atts ) {
		$defaults = array(
			'number_of_images'   => '20',
			'include_categories' => '',
			'offset_number'      => '0',
			'order_by'           => 'date',
			'order'              => 'DESC',
			'image_size'         => 'medium',
		);

		$atts = wp_parse_args( $atts, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $atts, $key, $default ) );
		}

		$number_of_images   = ( 0 === $number_of_images || '' === $number_of_images ) ? 20 : (int) $number_of_images;
		$include_categories = !empty( $include_categories ) ? array_map( 'intval', explode( ',', $include_categories ) ) : [];

		$images_args = array(
			'post_type'      => 'attachment',
			'posts_per_page' => $number_of_images,
			'post_status'	 => 'any',
			'orderby'        => sanitize_text_field( $order_by ),
			'order'          => sanitize_text_field( $order ),
			'offset'		 => intval( $offset_number ),
			'post_mime_type' => 'image/jpeg,image/gif,image/jpg,image/png,image/webp',
		);

		if ( ! empty( $include_categories ) ) {
			$images_args['tax_query'] = array( array(
				'taxonomy' => 'attachment-category',
				'field'    => 'term_id',
				'terms'    => $include_categories,
				'operator' => 'IN',
			) );
		}

		$query = new \WP_Query( $images_args );

		$filter_categories = array();
		$items             = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$image_id = get_the_ID();

				// Get image categories.
				$categories = get_the_terms( $image_id, 'attachment-category' );
				$image_cats = array();
				if ( ! empty( $categories ) ) {
					foreach ( $categories as $category ) {
						$image_cats[] = array(
							'id'   => $category->term_id,
							'slug' => $category->slug,
							'name' => $category->name
						);
					}
				}

				$items[] = array(
					'image_id'   => $image_id,
					'image_url'  => wp_get_attachment_image_url( get_the_ID(), $image_size ),
					'categories' => $image_cats,
					'title'      => trim( wptexturize( get_the_title( get_the_ID() ) ) ),
					'caption'    => trim( wp_get_attachment_caption( get_the_ID() ) ),
					'link'       => get_post_meta( $image_id, 'dge_attachment_link', true ),
				);
			}
			wp_reset_postdata();

			$terms = get_terms( array(
				'orderby'    => 'term_order',
				'taxonomy'   => 'attachment-category',
				'hide_empty' => true,
			) );
			if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						if ( empty( $include_categories ) || in_array( $term->term_id, $include_categories ) ) {
							$filter_categories[ $term->term_id ] = $term->name;
						}
					}
				}
		   	}
		}

		// Get the total pages.
		if ( -1 === $number_of_images ) {
			$total_pages = 1;
		} elseif ( ! empty( $offset_number ) ) {
			$total_pages = intval( ceil( ( $query->found_posts - $offset_number ) / $number_of_images ) );
		} else {
			$total_pages = intval( ceil( $query->found_posts / $number_of_images ) );
		}

		return array(
			'categories'  => $filter_categories,
			'items'       => $items,
			'total_pages' => $total_pages,
			'nonce'       => wp_create_nonce( 'elicus-divi-plus-filterable-gallery-nonce' )
		);
	}
}
