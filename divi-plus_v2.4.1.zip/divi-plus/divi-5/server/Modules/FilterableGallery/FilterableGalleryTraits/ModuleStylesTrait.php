<?php
namespace DIPL\Modules\FilterableGallery\FilterableGalleryTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\FormField\FormFieldStyle;
use DIPL\Modules\FilterableGallery\FilterableGallery;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'images',
			] ),
			$elements->style( [
				'attrName' => 'category',
			] ),
			$elements->style( [
				'attrName' => 'activeCategory',
			] )
        );

		// Number of column, width and column spacing calculation.
		$number_of_columns = $attrs['configurations']['advanced']['numberOfColumns'] ?? [ "desktop" => [ "value" => "4" ] ];
		$column_spacing    = $attrs['configurations']['advanced']['columnSpacing'] ?? [ "desktop" => [ "value" => "15px" ] ];

		$number_of_columns['tablet'] = ! empty( $number_of_columns['tablet']['value'] ) ? $number_of_columns['tablet'] : $number_of_columns['desktop'];
		$number_of_columns['phone']  = ! empty( $number_of_columns['phone']['value'] ) ? $number_of_columns['phone'] : $number_of_columns['tablet'];
		$column_spacing['tablet']    = ! empty( $column_spacing['tablet']['value'] ) ? $column_spacing['tablet'] : $column_spacing['desktop'];
		$column_spacing['phone']     = ! empty( $column_spacing['phone']['value'] ) ? $column_spacing['phone'] : $column_spacing['tablet'];

		$breakpoints = array( 'desktop', 'tablet', 'phone' );
		$width       = array();
		foreach ( $breakpoints as $breakpoint ) {
			if ( 1 === absint( $number_of_columns[$breakpoint]['value'] ) ) {
				$width[$breakpoint] = [ 'value' => '100%' ];
			} else {
				$divided_width = 100 / absint( $number_of_columns[$breakpoint]['value'] );
				if ( 0.0 !== floatval( $column_spacing[$breakpoint]['value'] ) ) {
					$gutter = floatval( ( floatval( $column_spacing[$breakpoint]['value'] ) * ( absint( $number_of_columns[$breakpoint]['value'] ) - 1 ) ) / absint( $number_of_columns[$breakpoint]['value'] ) );
					$width[$breakpoint] = [ 'value' => 'calc(' . $divided_width . '% - ' . $gutter . 'px)' ];
				} else {
					$width[$breakpoint] = [ 'value' => $divided_width . '%' ];
				}
			}
		}

		// Width and spacing.
		array_push( $styles,
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item",
				'attr'     => $width,
				'property' => 'width'
			] ),
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item",
				'attr'     => $column_spacing,
				'property' => 'margin-bottom'
			] ),
			CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item_gutter",
				'attr'     => $column_spacing,
				'property' => 'width'
			] )
		);

		$show_title   = $attrs['elements']['advanced']['showTitle']['desktop']['value'] ?? 'off';
		$title_area   = $attrs['elements']['advanced']['titleArea']['desktop']['value'] ?? 'lightbox';
		$show_caption = $attrs['elements']['advanced']['showCaption']['desktop']['value'] ?? 'off';
		$caption_area = $attrs['elements']['advanced']['captionArea']['desktop']['value'] ?? 'lightbox';

		if ( 'on' === $show_title ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'title',
			] ) );
		}
		if ( 'on' === $show_caption ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'caption',
			] ) );
		}

		if ( 'off' === $show_title && 'off' === $show_caption ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_title_caption_wrapper",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		} elseif ( 'off' === $show_title ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item_title",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		} elseif ( 'off' === $show_caption ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item_caption",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		}

		if ( 'lightbox' === $title_area && 'lightbox' === $caption_area ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_title_caption_wrapper",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		} elseif ( 'lightbox' === $title_area ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item_title",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		} elseif ( 'lightbox' === $caption_area ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item_caption",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		}

		if ( ! in_array( $title_area, array('lightbox', 'both') ) && ! in_array( $caption_area, array('lightbox', 'both') ) ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class}_lightbox .mfp-bottom-bar",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		} elseif ( ! in_array( $title_area, array('lightbox', 'both') ) ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class}_lightbox .dipl_filterable_gallery_item_title",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class}_lightbox .dipl_filterable_gallery_item_title + .dipl_filterable_gallery_item_caption",
				'attr'     => [ "desktop" => [ "value" => "10px" ] ],
				'property' => 'padding'
			] ) );
		} elseif ( ! in_array( $caption_area, array('lightbox', 'both') ) ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class}_lightbox .dipl_filterable_gallery_item_caption",
				'attr'     => [ "desktop" => [ "value" => "none" ] ],
				'property' => 'display'
			] ) );
		}

		if ( 'overlay' === $title_area && 'overlay' === $caption_area ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_title_caption_wrapper",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "position: absolute; top: 70%; left: 50%; z-index: 99; width: 100%; padding: 10px; visibility: hidden; opacity: 0; transform: translate(-50%, -50%); transition: all 300ms ease;";
					}
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item:hover .dipl_filterable_gallery_title_caption_wrapper",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "top: 50%; visibility: visible; opacity: 1;";
					}
				] )
			);
		} elseif ( 'overlay' === $title_area ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item_title",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "position: absolute; top: 70%; left: 50%; z-index: 99; width: 100%; padding: 10px; visibility: hidden; opacity: 0; transform: translate(-50%, -50%); transition: all 300ms ease;";
					}
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item:hover .dipl_filterable_gallery_item_title",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "top: 50%; visibility: visible; opacity: 1;";
					}
				] )
			);
		} elseif ( 'overlay' === $title_area ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item_caption",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "position: absolute; top: 70%; left: 50%; z-index: 99; width: 100%; padding: 10px; visibility: hidden; opacity: 0; transform: translate(-50%, -50%); transition: all 300ms ease;";
					}
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item:hover .dipl_filterable_gallery_item_caption",
					'attr'                => $attrs['elements']['advanced']['titleArea'],
					'declarationFunction' => function( $attr_value ) {
						return "top: 50%; visibility: visible; opacity: 1;";
					}
				] )
			);
		}

		$enable_overlay = $attrs['overlay']['advanced']['enable']['desktop']['value'] ?? 'off';
		$overlay_icon   = $attrs['overlay']['innerContent']['desktop']['value'] ?? [];
		if ( 'overlay' === $title_area || 'overlay' === $caption_area ) {
			if ( 'on' === $enable_overlay && empty( $overlay_icon['unicode'] ) ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_filterable_gallery_item .et_overlay:before",
					'attr'     => [ "desktop" => [ "value" => '""' ] ],
					'property' => 'content'
				] ) );
			}
		}

		// Overlay icon.
		if ( 'on' === $enable_overlay ) {
			array_push( $styles,
				$elements->style( [
					'attrName' => 'overlay',
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .et_overlay:before",
					'attr'                => $attrs['overlay']['innerContent'] ?? [],
					'declarationFunction' => [ FilterableGallery::class, 'icon_font_declaration' ]
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_filterable_gallery_item .et_overlay",
					'attr'                => $attrs['overlay']['advanced']['backgroundColor'],
					'property'            => 'background-color'
				] )
			);
		}

		// Pagination.
		$show_pagination = $attrs['pagination']['advanced']['show']['desktop']['value'] ?? 'off';
		if ( 'on' === $show_pagination ) {
			array_push( $styles,
				$elements->style( [
					'attrName' => 'pagination',
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_filterable_gallery_pagination li a",
					'attr'     => $attrs['pagination']['advanced']['linkBackgroundColor'],
					'property' => 'background'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_filterable_gallery_pagination li a",
					'attr'     => $attrs['pagination']['advanced']['linkColor'],
					'property' => 'color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_filterable_gallery_pagination li.active a",
					'attr'     => $attrs['pagination']['advanced']['activeLinkBackgroundColor'],
					'property' => 'background'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_filterable_gallery_pagination li.active a",
					'attr'     => $attrs['pagination']['advanced']['activeLinkColor'],
					'property' => 'color'
				] )
			);
		}

		// Lightbox.
		$lightbox_effect     = $attrs['lightbox']['advanced']['effect']['desktop']['value'] ?? 'none';
		$transition_duration = $attrs['lightbox']['advanced']['transitionDuration']['desktop']['value'] ?? '300';
		$on_click_trigger    = $attrs['configurations']['advanced']['onClickTrigger']['desktop']['value'] ?? 'none';
		if ( 'lightbox' === $on_click_trigger ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class}_lightbox.mfp-bg",
					'attr'     => $attrs['lightbox']['advanced']['backgroundColor'],
					'property' => 'background-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class}_lightbox .dipl_filterable_gallery_item_title, {$order_class}_lightbox .dipl_filterable_gallery_item_caption",
					'attr'     => $attrs['lightbox']['advanced']['metaBackgroundColor'],
					'property' => 'background-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class}_lightbox .mfp-arrow:after",
					'attr'     => $attrs['lightbox']['advanced']['closeIconColor'],
					'property' => 'color'
				] )
			);
			if ( 'none' !== $lightbox_effect ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class}_lightbox .mfp-container, {$order_class}_lightbox.mfp-bg, {$order_class}_lightbox.mfp-wrap .mfp-content",
					'attr'     => [ 'desktop' => [ 'value' => $transition_duration . 'ms' ] ],
					'property' => 'transition-duration'
				] ) );
			}
		}
		if ( 'none' !== $on_click_trigger ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_filterable_gallery_item",
				'attr'     => [ 'desktop' => [ 'value' => 'pointer' ] ],
				'property' => 'cursor'
			] ) );
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
