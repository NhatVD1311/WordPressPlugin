<?php
namespace DIPL\Modules\FilterableGallery\FilterableGalleryTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\FilterableGallery\FilterableGallery;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$include_categories_arr  = $attrs['configurations']['advanced']['includeCategories']['desktop']['value'] ?? [];

		$args = array(
			'number_of_images'   => $attrs['configurations']['advanced']['numberOfImages']['desktop']['value'] ?? 20,
			'offset_number'      => $attrs['configurations']['advanced']['offsetNumber']['desktop']['value'] ?? 0,
			'order_by'           => $attrs['configurations']['advanced']['orderBy']['desktop']['value'] ?? 'date',
			'order'              => $attrs['configurations']['advanced']['order']['desktop']['value'] ?? 'DESC',
			'image_size'         => $attrs['configurations']['advanced']['imageSize']['desktop']['value'] ?? 'medium',
			'include_categories' => implode( ',', $include_categories_arr ),
		);

		// Args array to variables.
		foreach ( $args as $key => $value ) {
			${$key} = esc_html( $value );
		}

		// Get response.
		$response = FilterableGallery::get_gallery_images_data( $args );

		$rendered_output = '';
		if ( ! empty( $response['items'] ) ) {

			// Get attrs.
			$enable_overlay       = $attrs['overlay']['advanced']['enable']['desktop']['value'] ?? 'off';
			$show_overlay_icon    = $attrs['overlay']['advanced']['showIcon']['desktop']['value'] ?? 'off';
			$overlay_icon         = $attrs['overlay']['innerContent']['desktop']['value'] ?? [];

			$show_title           = $attrs['elements']['advanced']['showTitle']['desktop']['value'] ?? 'off';
			$show_caption         = $attrs['elements']['advanced']['showCaption']['desktop']['value'] ?? 'off';
			$link_target          = $attrs['configurations']['advanced']['linkTarget']['desktop']['value'] ?? 'off';
			$title_head_tag       = $attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4';
			$on_click_trigger     = $attrs['configurations']['advanced']['onClickTrigger']['desktop']['value'] ?? 'none';
			$disable_lazy_loading = $attrs['configurations']['advanced']['disableLazyLoading']['desktop']['value'] ?? 'on';

			// Overlay render.
			$render_overlay = '';
			if ( 'on' === $enable_overlay ) {
				$render_overlay = sprintf(
					'<span class="et_overlay et_pb_inline_icon" data-icon="%1$s" />',
					Utils::process_font_icon( $overlay_icon )
				);
			}

			// Loop the images.
			$gallery_items = '';
			foreach ( $response['items'] as $item ) {

				$image_id = $item['image_id'];

				$title = '';
				if ( 'on' === $show_title && ! empty( $item['title'] ) ) {
					$title = $item['title'];
					if ( ! empty( $item['link'] ) ) {
						$title = sprintf(
							'<a href="%1$s" %2$s>%3$s</a>',
							esc_url( $item['link'] ),
							( 'on' === $link_target ) ? 'target="_blank"' : '',
							esc_html( $title )
						);
					}
					$title = HTMLUtility::render( [
						'tag'               => $title_head_tag,
						'attributes'        => [ 'class' => 'dipl_filterable_gallery_item_title' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $title,
					] );
				}

				$caption = '';
				if ( 'on' === $show_caption && ! empty( $item['caption'] ) ) {
					$caption = $item['caption'];
					if ( ! empty( $item['link'] ) ) {
						$caption = sprintf(
							'<a href="%1$s" %2$s>%3$s</a>',
							esc_url( $item['link'] ),
							( 'on' === $link_target ) ? 'target="_blank"' : '',
							esc_html( $caption )
						);
					}
					$caption = HTMLUtility::render( [
						'tag'               => 'p',
						'attributes'        => [ 'class' => 'dipl_filterable_gallery_item_caption' ],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => $caption,
					] );
				}

				$content_wrap = '';
				if ( ! empty( $title ) || ! empty( $caption ) ) {
					$content_wrap = sprintf(
						'<div class="dipl_filterable_gallery_title_caption_wrapper">%1$s %2$s</div>',
						et_core_esc_previously( $title ),
						et_core_esc_previously( $caption )
					);
				}

				// Image classes.
				$image_atts    = array();
				$image_classes = [
					"dipl_filterable_gallery_module__image",
					"attachment-" . $image_size,
					"size-" . $image_size,
				];
				if ( 'on' === $disable_lazy_loading ) {
					array_push( $image_classes, 'no-lazyload', 'skip-lazy' );
				}
				if ( ! empty( $item['categories'] ) ) {
					$categories_ids = wp_list_pluck( $item['categories'], 'id' );
					$categories 	= wp_list_pluck( $item['categories'], 'slug' );
					$image_classes	= array_merge( $image_classes, $categories );

					$image_atts['data-categories'] = implode( ',', $categories_ids );
				}
				$image_atts['class'] = implode( ' ', $image_classes );
				
				// Get the image
				$image = wp_get_attachment_image( $image_id, sanitize_text_field( $image_size ), false, $image_atts );

				// If link enabled, then link it.
				if ( 'link' === $on_click_trigger && ! empty( $item['link'] ) ) {
					$image = sprintf(
						'<a href="%1$s" %2$s>%3$s</a>',
						esc_url( $item['link'] )
						( 'on' === $link_target ) ? 'target="_blank"' : '',
						$image
					);
				}

				$gallery_items .= sprintf(
					'<div class="dipl_filterable_gallery_item dipl_filterable_gallery_item_page_1" %4$s>
						<div class="dipl_filterable_gallery_image_wrapper">
							%1$s %2$s
						</div>
						%3$s
					</div>',
					et_core_esc_previously( $image ),
					et_core_esc_previously( $render_overlay ),
					et_core_esc_previously( $content_wrap ),
					( 'lightbox' === $on_click_trigger ) ? sprintf( 'data-mfp-src="%1$s"', wp_get_attachment_url( $image_id ) ) : '',
				);
			}

			$lightbox_effect         = $attrs['lightbox']['advanced']['effect']['desktop']['value'] ?? 'none';
			$enable_navigation       = $attrs['lightbox']['advanced']['enableNavigation']['desktop']['value'] ?? 'on';
			$lightbox_trans_duration = $attrs['lightbox']['advanced']['transitionDuration']['desktop']['value'] ?? '300';
			$transition_duration     = $attrs['configurations']['advanced']['transitionDuration']['desktop']['value'] ?? '400';

			// Wrap items.
			$gallery_items = HTMLUtility::render( [
				'tag'               => 'div',
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => '<div class="dipl_filterable_gallery_item_gutter"></div>' . $gallery_items,
				'attributes'        => [
					'class'  => 'dipl_filterable_gallery_wrapper',
					'data-on_click_trigger'             => $on_click_trigger,
					'data-lightbox_effect'              => $lightbox_effect,
					'data-enable_navigation'            => $enable_navigation,
					'data-isotope_transition_duration'  => $lightbox_trans_duration,
					'data-lightbox_transition_duration' => $transition_duration
				],
			] );
			
			// Gallery Filter.
			$show_all_filter = $attrs['elements']['advanced']['showAllFilter']['desktop']['value'] ?? 'on';
			$all_images_text = $attrs['elements']['advanced']['allImagesText']['desktop']['value'] ?? esc_html__( 'All', 'divi-plus' );
			$filter          = '';
			if ( ! empty( $response['categories'] ) ) {
				$filter_items = '';
				if ( 'on' === $show_all_filter ) {
					$filter_items .= sprintf( 
						'<li class="dipl_filterable_gallery_active_category" data-category="">%1$s</li>',
						esc_html( $all_images_text )
					);
				}
				foreach ( $response['categories'] as $cat_id => $cat ) {
					$filter_items .= sprintf( '<li class="" data-category="%1$s">%2$s</li>', $cat_id, $cat );
				}
				if ( ! empty( $filter_items ) ) {
					$filter = sprintf(
						'<div class="dipl_filterable_gallery_filter_wrapper"
							data-number_of_images="%2$s"
							data-offset_number="%3$s"
							data-gallery_order_by="%4$s"
							data-gallery_order="%5$s"
							data-include_categories="%6$s"
							data-image_size="%7$s"
							data-on_click_trigger="%8$s"
							data-link_target="%9$s"
							data-enable_overlay="%10$s"
							data-show_title="%11$s"
							data-show_caption="%12$s"
							data-disable_lazy_loading="%13$s"
							data-title_level="%14$s"
						>
							<ul class="dipl_filterable_gallery_filter_categories">%1$s</ul>
						</div>',
						$filter_items,
						esc_attr( $number_of_images ),
						esc_attr( $offset_number ),
						esc_attr( $order_by ),
						esc_attr( $order ),
						esc_attr( $include_categories ),
						esc_attr( $image_size ),
						esc_attr( $on_click_trigger ),
						esc_attr( $link_target ),
						esc_attr( $enable_overlay ),
						esc_attr( $show_title ),
						esc_attr( $show_caption ),
						esc_attr( $disable_lazy_loading ),
						esc_attr( $title_head_tag )
					);
				}
			}

			$show_pagination = $attrs['pagination']['advanced']['show']['desktop']['value'] ?? 'off';
			$show_prev_next  = $attrs['pagination']['advanced']['showPrevNext']['desktop']['value'] ?? 'off';
			$next_text       = $attrs['pagination']['advanced']['nextText']['desktop']['value'] ?? esc_html__( 'Next', 'divi-plus' );
			$prev_text       = $attrs['pagination']['advanced']['prevText']['desktop']['value'] ?? esc_html__( 'Prev', 'divi-plus' );
			$pagination      = '';
			if ( 'on' === $show_pagination ) {
				$pagination = sprintf(
					'<div class="dipl_filterable_gallery_pagination_wrapper"
						data-total_pages="%1$s"
						data-overlay_icon="%2$s"
						data-number_of_images="%3$s"
						data-offset_number="%4$s"
						data-gallery_order_by="%5$s"
						data-gallery_order="%6$s"
						data-include_categories="%7$s"
						data-image_size="%8$s"
						data-on_click_trigger="%9$s"
						data-link_target="%10$s"
						data-enable_overlay="%11$s"
						data-show_overlay_icon="%12$s"
						data-show_title="%13$s"
						data-show_caption="%14$s"
						data-disable_lazy_loading="%15$s"
						data-title_level="%16$s"
						data-show_prev_next="%17$s"
						data-next_text="%18$s"
						data-prev_text="%19$s"
					><ul></ul></div>',
					isset( $response['total_pages'] ) ? $response['total_pages'] : 1,
					Utils::process_font_icon( $overlay_icon ),
					esc_attr( $number_of_images ),
					esc_attr( $offset_number ),
					esc_attr( $order_by ),
					esc_attr( $order ),
					esc_attr( $include_categories ),
					esc_attr( $image_size ),
					esc_attr( $on_click_trigger ),
					esc_attr( $link_target ),
					esc_attr( $enable_overlay ),
					esc_attr( $show_overlay_icon ),
					esc_attr( $show_title ),
					esc_attr( $show_caption ),
					esc_attr( $disable_lazy_loading ),
					esc_attr( $title_head_tag ),
					esc_attr( $show_prev_next ),
					esc_attr( $next_text ),
					esc_attr( $prev_text )
				);
			}

			// Final render all elements.
			$rendered_output = sprintf( 
				'%1$s %2$s %3$s
				<input type="hidden" class="dipl_filterable_gallery_nonce" value="%4$s" />',
				$filter, $gallery_items, $pagination,
				$response['nonce']
			);

		} else {
			$no_result_text  = $attrs['configurations']['advanced']['noGalleryText']['desktop']['value'] ?? esc_html__( 'No Gallery Found!!', 'divi-plus' );
			$rendered_output = HTMLUtility::render( [
				'tag'      => 'h5',
				'children' => esc_html( $no_result_text ),
			] );
		}

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'classnamesFunction'  => [ FilterableGallery::class, 'module_classnames' ],
			'moduleCategory'      => $block->block_type->category,
			'stylesComponent'     => [ FilterableGallery::class, 'module_styles' ],
			'scriptDataComponent' => [ FilterableGallery::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
