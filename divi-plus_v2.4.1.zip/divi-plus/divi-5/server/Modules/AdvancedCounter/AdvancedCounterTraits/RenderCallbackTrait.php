<?php
namespace DIPL\Modules\AdvancedCounter\AdvancedCounterTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\AdvancedCounter\AdvancedCounter;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attributes.
		$layout         = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$use_icon       = $attrs['icon']['advanced']['use']['desktop']['value'] ?? 'off';
		$counter_number = $attrs['counterNumber']['innerContent']['desktop']['value'] ?? '90+';
		
		// Alert Box Image.
		$image_icon = '';
		if ( 'on' === $use_icon ) {
			$icon = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
			if ( ! empty( $icon ) ) {
				$image_icon = HTMLUtility::render( [
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'et-pb-icon' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => Utils::process_font_icon( $icon ),
				] );	
			}
		} else {
			$image_icon = $elements->render( [
				'attrName' => 'image',
			] );
		}

		// Counter number.
		$number = sprintf(
			'<div class="dipl_advanced_counter_number" data-target="%1$s">00</div>',
			esc_attr( $counter_number )
		);

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );

		// Render description.
		$content = $elements->render( [
			'attrName' => 'description',
		] );

		// Get html by layout.
		$counter_output = '';
		if ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AdvancedCounter/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AdvancedCounter/layouts/' . sanitize_file_name( $layout ) . '.php';
		}

		// Final rendering.
		$rendered_output = sprintf(
			'<div class="dipl_advanced_counter_wrapper %1$s">%2$s</div>',
			esc_attr( $layout ),
			et_core_esc_previously( $counter_output )
		);

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AdvancedCounter::class, 'module_classnames' ],
			'stylesComponent'     => [ AdvancedCounter::class, 'module_styles' ],
			'scriptDataComponent' => [ AdvancedCounter::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
