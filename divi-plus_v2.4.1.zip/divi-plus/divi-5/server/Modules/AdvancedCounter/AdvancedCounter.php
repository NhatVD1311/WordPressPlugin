<?php
/**
 * Alert Box Module class.
 *
 * @package DIPL\Modules\AdvancedCounter;
 */
namespace DIPL\Modules\AdvancedCounter;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AdvancedCounter\AdvancedCounterTraits;

/**
 * Class AdvancedCounter
 *
 * @package DIPL\Modules\AdvancedCounter
 */
class AdvancedCounter implements DependencyInterface {

	use AdvancedCounterTraits\RenderCallbackTrait;
	use AdvancedCounterTraits\ModuleClassnamesTrait;
	use AdvancedCounterTraits\ModuleStylesTrait;
	use AdvancedCounterTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/advanced-counter';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AdvancedCounter::class, 'render_callback' ] ]
				);
			}
		);
	}
}
