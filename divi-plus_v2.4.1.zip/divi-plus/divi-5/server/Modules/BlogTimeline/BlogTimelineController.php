<?php
/**
 *
 * @package DIPL\Modules\BlogTimeline;
 */
namespace DIPL\Modules\BlogTimeline;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Controllers\RESTController;
use ET\Builder\Framework\UserRole\UserRole;
use DIPL\Modules\BlogTimeline\BlogTimeline;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Class BlogTimelineController
 *
 * @package DIPL\Modules\BlogTimeline
 */
class BlogTimelineController extends RESTController {

	/**
	 * Return data for the Instagram Module.
	 *
	 * @param WP_REST_Request $request REST request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public static function index( WP_REST_Request $request ): WP_REST_Response {
		$args = array(	
			'layout'                        => $request->get_param( 'layout' ),
			'layout_option'                 => $request->get_param( 'layoutOption' ),
			'posts_number'                  => $request->get_param( 'postsNumber' ),
			'order_by'                      => $request->get_param( 'orderBy' ),
			'order'                         => $request->get_param( 'order' ),
			'offset'                        => $request->get_param( 'offset' ),
			'include_categories'            => $request->get_param( 'includeCategories' ),
			'post_date'                     => $request->get_param( 'dateFormat' ),
			'show_content'                  => $request->get_param( 'showContent' ),
			'show_categories'               => $request->get_param( 'showCategories' ),
			'show_comments'                 => $request->get_param( 'showComments' ),
			'show_author'                   => $request->get_param( 'showAuthor' ),
			'show_date'                     => $request->get_param( 'showDate' ),
			'excerpt_length'                => $request->get_param( 'excerptLength' ),
			'ignore_sticky_posts'           => $request->get_param( 'ignoreStickyPosts' ),
			'show_thumbnail'                => $request->get_param( 'showFeaturedImage' ),
			'featured_image_size'           => $request->get_param( 'featuredImageSize' ),
			'title_header_level'            => $request->get_param( 'titleHeaderLevel' ),
			'show_read_more'                => $request->get_param( 'showReadMore' ),
			'read_more_text'                => $request->get_param( 'readMoreText' ),
			'read_more_button_icon_desktop' => $request->get_param( 'readMoreButtonIconDesktop' ),
			'read_more_button_icon_tablet'  => $request->get_param( 'readMoreButtonIconTablet' ),
			'read_more_button_icon_phone'   => $request->get_param( 'readMoreButtonIconPhone' ),
			'timeline_icon'                 => $request->get_param( 'icon' )
		);
		
		$response = [
			'data' => BlogTimeline::render_content( $args ),
		];

		return self::response_success( $response );
	}

	/**
	 * Index action arguments.
	 *
	 * Endpoint arguments as used in `register_rest_route()`.
	 *
	 * @return array
	 */
	public static function index_args(): array {
		return [
			'layout' => [
				'type'              => 'string',
				'default'           => 'layout1',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'layoutOption' => [
				'type'              => 'string',
				'default'           => 'dipl_blog_timeline_alternate',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'postsNumber' => [
				'type'              => 'string',
				'default'           => '10',
				'sanitize_callback' => function( $value, $request, $param ) {
					return intval( $value );
				},
			],
			'orderBy' => [
				'type'              => 'string',
				'default'           => 'date',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'order' => [
				'type'              => 'string',
				'default'           => 'DESC',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'offset' => [
				'type'              => 'string',
				'default'           => '0',
				'sanitize_callback' => function( $value, $request, $param ) {
					return intval( $value );
				},
			],
			'includeCategories' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showContent' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showCategories' => [
				'type'				=> 'string',
				'default'			=> 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showComments' => [
				'type'				=> 'string',
				'default'			=> 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showAuthor' => [
				'type'				=> 'string',
				'default'			=> 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showDate' => [
				'type'				=> 'string',
				'default'			=> 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'dateFormat' => [
				'type'				=> 'string',
				'default'			=> 'M j, Y',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'ignoreStickyPosts' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showFeaturedImage' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'featuredImageSize' => [
				'type'              => 'string',
				'default'           => 'large',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'titleHeaderLevel' => [
				'type'              => 'string',
				'default'           => 'h3',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'showReadMore' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'readMoreText' => [
				'type'              => 'string',
				'default'           => esc_html__( 'Read More', 'divi-plus' ),
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'readMoreButtonIconDesktop' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_attr( $value );
				},
			],
			'readMoreButtonIconTablet' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_attr( $value );
				},
			],
			'readMoreButtonIconPhone' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_attr( $value );
				},
			],
			'icon' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_attr( $value );
				},
			]
		];
	}

	/**
	 * Index action permission.
	 *
	 * Endpoint permission callback as used in `register_rest_route()`.
	 *
	 * @return bool
	 */
	public static function index_permission(): bool {
		return UserRole::can_current_user_use_visual_builder();
	}
}