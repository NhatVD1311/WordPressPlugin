<?php
namespace DIPL\Modules\BlogTimeline\BlogTimelineTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {

	public static function render_content( $attrs = array() ) {
        $defaults = array(
        	'layout'                        => 'layout1',
        	'layout_option'                 => 'dipl_blog_timeline_alternate',
			'posts_number'                  => '10',
			'order_by'                      => 'date',
			'order'                         => 'DESC',
			'offset'                        => '0',
			'include_categories'            => '',
			'show_content'                  => 'off',
			'show_categories'               => 'on',
			'show_author'                   => 'on',
			'show_comments'                 => 'on',
			'show_date'                     => 'on',
			'post_date'                     => 'M j, Y',
			'title_header_level'            => 'h3',
			'excerpt_length'                => '270',
			'ignore_sticky_posts'           => 'off',
			'show_thumbnail'                => 'on',
			'featured_image_size'           => 'large',
			'show_read_more'                => 'off',
			'read_more_text'                => esc_html__( 'Read More', 'divi-plus' ),
			'read_more_button_icon_desktop' => '',
			'read_more_button_icon_tablet'  => '',
			'read_more_button_icon_phone'   => '',
			'timeline_icon'                 => '',
		);

		$attrs = wp_parse_args( $attrs, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = sanitize_text_field( et_()->array_get( $attrs, $key, $default ) );
		}

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => intval( $posts_number ),
			'post_status'    => 'publish',
			'offset'         => 0,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( is_user_logged_in() ) {
			$args['post_status'] = array( 'publish', 'private' );
		}
		if ( 'on' === $ignore_sticky_posts ) {
			$args['ignore_sticky_posts'] = true;
		}
		if ( '' !== $include_categories ) {
			$args['cat'] = sanitize_text_field( $include_categories );
		}
		if ( '' !== $offset && ! empty( $offset ) ) {
			$args['offset'] = intval( $offset );
		}
		if ( '' !== $args['offset'] && -1 === intval( $args['posts_per_page'] ) ) {
			$count_posts            = wp_count_posts( 'post', 'readable' );
			$published_posts        = $count_posts->publish;
			$args['posts_per_page'] = intval( $published_posts );
		}
		if ( isset( $order_by ) && '' !== $order_by ) {
			$args['orderby'] = sanitize_text_field( $order_by );
		}
		if ( isset( $order ) && '' !== $order ) {
			$args['order'] = sanitize_text_field( $order );
		}
		if ( is_single() && ! isset( $args['post__not_in'] ) ) {
			$args['post__not_in'] = array( intval( get_the_ID() ) );
		}

		global $wp_the_query;
		$query_backup = $wp_the_query;

		$query = new WP_Query( $args );

		$output = '';
		$html = '';
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();

				$post_id = intval( get_the_ID() );

				$data_atts = array();
				if ( '' !== $read_more_button_icon_desktop ) {
					array_push( $data_atts, 'data-icon="'. esc_attr( $read_more_button_icon_desktop ) .'"' );
				}
				if ( '' !== $read_more_button_icon_tablet ) {
					array_push( $data_atts, 'data-icon-tablet="'. esc_attr( $read_more_button_icon_tablet ) .'"' );
				}
				if ( '' !== $read_more_button_icon_phone ) {
					array_push( $data_atts, 'data-icon-phone="'. esc_attr( $read_more_button_icon_phone ) .'"' );
				}

				$data_atts = implode(' ', $data_atts);

				$read_more_button = sprintf(
					'<a href="%1$s" class="et_pb_button" %3$s>%2$s</a>',
					esc_url( get_permalink( $post_id ) ),
					et_core_esc_previously( $read_more_text ),
					esc_attr( $data_atts )
				);

				$thumb          = dipl_get_post_thumbnail( $post_id, esc_html( $featured_image_size ), 'dipl_blog_timeline_post_image' );
				$no_thumb_class = ( '' === $thumb || 'off' === $show_thumbnail ) ? ' dipl_blog_timeline_no_thumb' : '';

				$post_classes = array_map( 'sanitize_html_class', get_post_class( 'dipl_blog_timeline_post' . $no_thumb_class ) );
				$post_classes = implode( ' ', $post_classes );
				
				if ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogTimeline/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogTimeline/layouts/' . sanitize_file_name( $layout ) . '.php';
				}
			}
			wp_reset_postdata();

			$html = sprintf(
				'<div class="dipl_blog_timeline_wrapper %1$s %2$s">
					%3$s
					<div class="dipl_stem_wrapper %2$s_stem">
						<div class="dipl_blog_stem"></div>
					</div>
				</div>',
				'' !== $layout ? $layout : 'layout1',
				'' !== $layout_option ? $layout_option : 'dipl_blog_timeline_alternate',
				$output
			);
		}

		return $html;
	}
}
