<?php
namespace DIPL\Modules\BlogTimeline\BlogTimelineTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\BlogTimeline\BlogTimeline;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$include_categories_arr = $attrs['posts']['advanced']['includeCategories']['desktop']['value'] ?? [];
		$include_categories     = is_array( $include_categories_arr ) ? implode( ',', $include_categories_arr ) : $include_categories_arr;

		$readmore_button        = $attrs['readMore']['decoration']['button'] ?? [];
		$timeline_icon          = $attrs['icon']['innerContent']['desktop']['value'] ?? [];

		$args = array(	
			'layout'                        => $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1',
			'layout_option'                 => $attrs['module']['advanced']['layoutOption']['desktop']['value'] ?? 'dipl_blog_timeline_alternate',
			'posts_number'                  => $attrs['posts']['advanced']['postsNumber']['desktop']['value'] ?? '10',
			'order_by'                      => $attrs['posts']['advanced']['orderBy']['desktop']['value'] ?? 'date',
			'order'                         => $attrs['posts']['advanced']['order']['desktop']['value'] ?? 'DESC',
			'offset'                        => $attrs['posts']['advanced']['offset']['desktop']['value'] ?? '0',
			'include_categories'            => $include_categories,
			'post_date'                     => $attrs['posts']['advanced']['dateFormat']['desktop']['value'] ?? 'M j, Y',
			'show_content'                  => $attrs['posts']['advanced']['showContent']['desktop']['value'] ?? 'off',
			'show_categories'               => $attrs['posts']['advanced']['showCategories']['desktop']['value'] ?? 'on',
			'show_comments'                 => $attrs['posts']['advanced']['showComments']['desktop']['value'] ?? 'on',
			'show_author'                   => $attrs['posts']['advanced']['showAuthor']['desktop']['value'] ?? 'on',
			'show_date'                     => $attrs['posts']['advanced']['showDate']['desktop']['value'] ?? 'on',
			'excerpt_length'                => $attrs['posts']['advanced']['excerptLength']['desktop']['value'] ?? '270',
			'ignore_sticky_posts'           => $attrs['posts']['advanced']['ignoreStickyPosts']['desktop']['value'] ?? 'off',
			'show_thumbnail'                => $attrs['posts']['advanced']['showFeaturedImage']['desktop']['value'] ?? 'on',
			'featured_image_size'           => $attrs['posts']['advanced']['featuredImageSize']['desktop']['value'] ?? 'large',
			'title_header_level'            => $attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h3',
			'show_read_more'                => $attrs['readMore']['advanced']['show']['desktop']['value'] ?? 'off',
			'read_more_text'                => $attrs['readMore']['innerContent']['desktop']['value'] ?? __( 'Read More', 'divi-plus' ),
			'read_more_button_icon_desktop' => ! empty( $readmore_button['desktop']['value'] ) ? Utils::process_font_icon( $readmore_button['desktop']['value'] ) : '',
			'read_more_button_icon_tablet'  => ! empty( $readmore_button['tablet']['value'] ) ? Utils::process_font_icon( $readmore_button['tablet']['value'] ) : '',
			'read_more_button_icon_phone'   => ! empty( $readmore_button['phone']['value'] ) ? Utils::process_font_icon( $readmore_button['phone']['value'] ) : '',
			'timeline_icon'                 => ! empty( $timeline_icon ) ? Utils::process_font_icon( $timeline_icon ) : '',
		);

		$response = BlogTimeline::render_content( $args );

		$rendered_output = '';
		if ( ! empty( $response ) ) {
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_module_inner' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $response
			] );
		} else {
			$no_result_text  = $attrs['posts']['advanced']['noResultText']['desktop']['value'] ?? esc_html__( 'The posts you requested could not be found. Try changing your module settings or create some new posts.', 'divi-plus' );
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'entry' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $rendered_output
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ BlogTimeline::class, 'module_classnames' ],
			'stylesComponent'     => [ BlogTimeline::class, 'module_styles' ],
			'scriptDataComponent' => [ BlogTimeline::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
