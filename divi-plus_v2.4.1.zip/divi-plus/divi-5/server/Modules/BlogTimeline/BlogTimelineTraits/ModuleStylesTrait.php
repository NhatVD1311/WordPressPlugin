<?php
namespace DIPL\Modules\BlogTimeline\BlogTimelineTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\BlogTimeline\BlogTimeline;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'posts',
			] ),
			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'content',
			] ),
			$elements->style( [
				'attrName' => 'meta',
			] ),
			$elements->style( [
				'attrName' => 'readMore',
			] )
		];

		// Post meta text align.
		$postmeta_textalign = $attrs['meta']['decoration']['font']['font'] ?? [];
		$postmeta_flexalign = [];
		foreach ( $postmeta_textalign as $device => $value ) {
			if ( ! empty( $value['value']['textAlign'] ) ) {
				$postmeta_flexalign[ $device ] = [
					'value' => str_replace( array( 'left', 'justify', 'right' ), array( 'flex-start', 'flex-start', 'flex-end' ), $value['value']['textAlign'] )
				];
			}
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_blog_timeline_meta",
			'attr'      => $postmeta_flexalign,
			'property'  => 'justify-content',
		] ) );

		// Timeline icon.
		array_push( $styles, $elements->style( [
			'attrName' => 'icon',
		] ) );
		array_push( $styles, CommonStyle::style( [
			'selector'            => "{$order_class} .dipl_blog_timeline_post_icon.et-pb-icon",
			'attr'                => $attrs['icon']['innerContent'],
			'declarationFunction' => [ BlogTimeline::class, 'icon_font_declaration' ],
		] ) );
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_blog_timeline_post_icon.et-pb-icon.dipl_icon_fill",
			'attr'      => $attrs['icon']['advanced']['fillColor'] ?? [],
			'property'  => 'color',
		] ) );

		$icon_fontsize     = $attrs['icon']['decoration']['icon'] ?? [ 'desktop' => [ 'value' => [ 'size' => '32px' ] ] ];
		$icon_shape        = $attrs['icon']['advanced']['shape']['desktop']['value'] ?? 'none';
		$use_shapeBorder   = $attrs['icon']['advanced']['shapeBorder']['desktop']['value'] ?? 'off';
		$shape_border_size = $attrs['icon']['advanced']['shapeBorderSize'] ?? [ 'desktop' => [ 'value' => '2px' ] ];

		// Collect responsive fontsize.
		$icon_fontsize['tablet'] = ! empty( $icon_fontsize['tablet']['value']['size'] ) ? $icon_fontsize['tablet'] : $icon_fontsize['desktop'];
		$icon_fontsize['phone']  = ! empty( $icon_fontsize['phone']['value']['size'] ) ? $icon_fontsize['phone'] : $icon_fontsize['tablet'];
		
		$shape_border_size = $shape_border_size['desktop']['value'] ?? '32px';
		$icon_size = [];
		foreach ( $icon_fontsize as $device => $val ) {
			$this_size = $val['value']['size'];
			if ( 'none' === $icon_shape ) {
				$icon_size[ $device ] = [ 'value' => intval( $this_size ) . 'px' ];
			} else {
				if ( 'on' === $use_shapeBorder ) {
					$this_shape_border_size = $shape_border_size[ $device ]['value'] ?? $shape_border_size;
					$icon_size[ $device ]   = [ 'value' => ( intval( $this_size ) + ( 2 * intval( $shape_border_size ) ) + 20 ) . 'px' ];
				} else {
					$icon_size[ $device ]   = [ 'value' => ( intval( $this_size ) + 20 ) . 'px' ];
				}
			}
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_blog_timeline_stem_center",
			'attr'      => $icon_size,
			'property'  => 'width',
		] ) );
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_blog_timeline_stem_center",
			'attr'      => $icon_size,
			'property'  => 'height',
		] ) );

		$layout        = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$layout_option = $attrs['module']['advanced']['layoutOption']['desktop']['value'] ?? 'dipl_blog_timeline_alternate';

		$icon_position = [];
		foreach ( $icon_size as $device => $val ) {
			if ( ! empty( $val['value'] ) ) {
				$icon_position[ $device ] = [ 'value' => ( floatval( $val['value'] ) / 2 ) . 'px' ];
			}
		}
		if ( 'dipl_blog_timeline_alternate' === $layout_option ) {
			array_push( $styles, CommonStyle::style( [
				'selector'            => "{$order_class} .dipl_blog_timeline_alternate .dipl_stem_wrapper",
				'attr'                => $icon_position,
				'declarationFunction' => function( $attr_val ) {
					if ( ! empty( $attr_val['breakpoint'] ) && 'phone' === $attr_val['breakpoint'] ) {
						return $attr_val['attrValue'] ?? '';
					}
					return '';
				}
			] ) );
		}
		if ( 'dipl_blog_timeline_right' === $layout_option && 'layout1' === $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_timeline_right .dipl_stem_wrapper",
				'attr'      => $icon_position,
				'property'  => 'left',
			] ) );
		}
		if ( 'dipl_blog_timeline_left' === $layout_option && 'layout1' === $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_timeline_left .dipl_stem_wrapper",
				'attr'      => $icon_position,
				'property'  => 'right',
			] ) );
		}

		if ( 'none' !== $icon_shape ) {
			if ( 'use_circle' === $icon_shape ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
					'attr'      => [ 'desktop' => [ 'value' => '50%' ] ],
					'property'  => 'border-radius',
				] ) );
			} else {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
					'attr'      => [ 'desktop' => [ 'value' => '0' ] ],
					'property'  => 'border-radius',
				] ) );
			}
			array_push( $styles,
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
					'attr'      => [ 'desktop' => [ 'value' => '10px' ] ],
					'property'  => 'padding',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
					'attr'      => $attrs['icon']['advanced']['shapeColor'] ?? [],
					'property'  => 'background-color',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_timeline_post_icon.dipl_icon_fill",
					'attr'      => $attrs['icon']['advanced']['shapeFillColor'] ?? [],
					'property'  => 'background-color',
				] )
			);
			$use_shape_border = $attrs['icon']['advanced']['shapeBorder']['desktop']['value'] ?? 'off';
			if ( 'on' === $use_shape_border ) {
				array_push( $styles,
					CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
						'attr'      => [ 'desktop' => [ 'value' => 'solid' ] ],
						'property'  => 'border-style',
					] ),
					CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
						'attr'      => $attrs['icon']['advanced']['shapeBorderColor'] ?? [],
						'property'  => 'border-color',
					] ),
					CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_blog_timeline_post_icon.dipl_icon_fill",
						'attr'      => $attrs['icon']['advanced']['shapeBorderFillColor'] ?? [],
						'property'  => 'border-color',
					] ),
					CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_blog_timeline_post_icon",
						'attr'      => $attrs['icon']['advanced']['shapeBorderSize'] ?? [],
						'property'  => 'border-width',
					] )
				);
			}
		}

		array_push( $styles,
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_stem_wrapper",
				'attr'      => $attrs['timelineStem']['advanced']['size'] ?? [],
				'property'  => 'width',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_stem_wrapper",
				'attr'      => $attrs['timelineStem']['advanced']['color'] ?? [],
				'property'  => 'background',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_stem",
				'attr'      => $attrs['timelineStem']['advanced']['fillColor'] ?? [],
				'property'  => 'background',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_timeline_content_wrapper",
				'attr'      => $attrs['posts']['advanced']['borderRadius'] ?? [],
				'property'  => 'border-radius',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_timeline_image_wrapper .dipl_blog_timeline_image_link",
				'attr'      => $attrs['posts']['advanced']['featuredImageWidth'] ?? [],
				'property'  => 'width',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_timeline_image_wrapper",
				'attr'      => $attrs['posts']['advanced']['featuredImageAlignment'] ?? [],
				'property'  => 'justify-content',
			] )
		);

		// Date styling.
		$show_date = $attrs['posts']['advanced']['showDate']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_date ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'date',
			] ) );
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
