<?php
/**
 *
 * @package DIPL\Modules\BlogTimeline;
 */

namespace DIPL\Modules\BlogTimeline;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\BlogTimeline\BlogTimelineTraits;

/**
 * Class BlogTimeline
 *
 * @package DIPL\Modules\BlogTimeline
 */
class BlogTimeline implements DependencyInterface {

    use BlogTimelineTraits\RenderCallbackTrait;
    use BlogTimelineTraits\RenderContentTrait;
    use BlogTimelineTraits\ModuleClassnamesTrait;
    use BlogTimelineTraits\ModuleStylesTrait;
    use BlogTimelineTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/blog-timeline';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ BlogTimeline::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}