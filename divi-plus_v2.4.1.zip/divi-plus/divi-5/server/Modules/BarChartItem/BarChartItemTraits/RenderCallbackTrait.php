<?php
namespace DIPL\Modules\BarChartItem\BarChartItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\BarChartItem\BarChartItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Won’t render this, but parent will still get props.
		// Return null to avoid any rendering.
		return null;
	}
}
