<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BarChartItem;
 */
namespace DIPL\Modules\BarChartItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BarChartItem\BarChartItemTraits;

/**
 * Class BarChartItem
 *
 * @package DIPL\Modules\BarChartItem
 */
class BarChartItem implements DependencyInterface {

	use BarChartItemTraits\RenderCallbackTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/bar-chart-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BarChartItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
