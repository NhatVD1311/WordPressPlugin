<?php
namespace DIPL\Modules\ComparisonList\ComparisonListTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\ComparisonList\ComparisonList;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$rendered_output = '';
		if ( ! empty( $content ) ) {

			// Get attrs.
			$feature_values = $attrs['featureValues']['innerContent']['desktop']['value'] ?? '';

			// Render feature title.
			$feature_title = $elements->render( [
				'attrName' => 'featureTitle',
			] );

			// Split header titles.
			$header_values = array_map( 'trim', explode( '|', $feature_values ) );
			$values_html   = '';
			foreach ( $header_values as $item ) {
				if ( empty( trim( $item ) ) ) {
					continue;
				}
				$values_html .= sprintf(
					'<div class="dipl_comparison_list_column">%1$s</div>',
					et_core_esc_previously( $item )
				);
			}
			
			// Render final output.
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_comparison_list_wrapper' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => sprintf(
					'<div class="dipl_comparison_list_header">
						%1$s %2$s
					</div>%3$s',
					et_core_esc_previously( $feature_title ),
					et_core_esc_previously( $values_html ),
					et_core_esc_previously( $content )
				)
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ ComparisonList::class, 'module_classnames' ],
			'stylesComponent'     => [ ComparisonList::class, 'module_styles' ],
			'scriptDataComponent' => [ ComparisonList::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
