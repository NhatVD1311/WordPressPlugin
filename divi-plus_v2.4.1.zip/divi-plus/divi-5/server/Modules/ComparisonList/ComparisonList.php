<?php
/**
 * Comparison List class.
 *
 * @package DIPL\Modules\ComparisonList;
 */
namespace DIPL\Modules\ComparisonList;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\ComparisonList\ComparisonListTraits;

/**
 * Class ComparisonList
 *
 * @package DIPL\Modules\ComparisonList
 */
class ComparisonList implements DependencyInterface {

	use ComparisonListTraits\RenderCallbackTrait;
	use ComparisonListTraits\ModuleClassnamesTrait;
	use ComparisonListTraits\ModuleStylesTrait;
	use ComparisonListTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/comparison-list';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ ComparisonList::class, 'render_callback' ] ]
				);
			}
		);
	}
}
