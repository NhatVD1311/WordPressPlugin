<?php
namespace DIPL\Modules\ContentToggle\ContentToggleTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Helpers\DIPLUtils;
use DIPL\Modules\ContentToggle\ContentToggle;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Get order class.
		$order_class = ModuleUtils::get_module_order_class_name(
			$block->parsed_block['id'],
			$block->parsed_block['storeInstance']
		);

		$layout             = $attrs['toggleSwitch']['advanced']['layout']['desktop']['value'] ?? 'dipl_toggle_layout_one';
		$content_one_type   = $attrs['contentOne']['advanced']['type']['desktop']['value'] ?? 'dipl_content_one_text';
		$content_two_type   = $attrs['contentTwo']['advanced']['type']['desktop']['value'] ?? 'dipl_content_two_text';

		$content_one_layout = $attrs['contentOne']['advanced']['layout']['desktop']['value'] ?? '-1';
		$content_two_layout = $attrs['contentTwo']['advanced']['layout']['desktop']['value'] ?? '-1';

		$content_one_title  = $attrs['contentOne']['innerContent']['title']['desktop']['value'] ?? '';
		$content_two_title  = $attrs['contentTwo']['innerContent']['title']['desktop']['value'] ?? '';

		$content_one_text   = $attrs['contentOne']['innerContent']['content']['desktop']['value'] ?? '';
		$content_two_text   = $attrs['contentTwo']['innerContent']['content']['desktop']['value'] ?? '';

		// Get switch alignment.
		$toggle_alignment   = $attrs['toggleSwitch']['advanced']['alignment']['desktop']['value'] ?? 'center';
		$title_head_level   = $attrs['toggleTitle']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h5';

		$render_toggle_layout = '';
		if ( 'dipl_toggle_layout_one' === $layout ) {
			$render_toggle_layout = sprintf(
				'<div class="dipl_toggle_button_wrapper dipl_toggle_layout_one dipl_toggle_%4$s">
					<div class="dipl_toggle_title_value dipl_toggle_off_value">
						<%3$s class="dipl-toggle-title">%1$s</%3$s>
					</div>
					<div class="dipl_toggle_button">
						<div class="dipl_toggle_button_inner">
							<input class="dipl_toggle_field" type="checkbox" value="" />
							<div class="dipl_switch"></div>
							<div class="dipl_toggle_bg"></div>
						</div>
					</div>
					<div class="dipl_toggle_title_value dipl_toggle_on_value">
						<%3$s class="dipl-toggle-title">%2$s</%3$s>
					</div>
				</div>',
				esc_html( $content_one_title ),
				esc_html( $content_two_title ),
				esc_attr( $title_head_level ),
				esc_attr( $toggle_alignment )
			);
		} elseif  ( 'dipl_toggle_layout_two' === $layout ) {
			$render_toggle_layout = sprintf(
				'<div class="dipl_toggle_button_wrapper dipl_toggle_layout_two dipl_toggle_%3$s">
					<input class="dipl_toggle_field" id="%4$s" type="checkbox" value="" />
					<label class="dipl_switch" for="%4$s">
						<div class="dipl_switch_trigger dipl_switch_one dipl_active" data-value="%1$s"></div>
					    <div class="dipl_switch_trigger dipl_switch_two dipl_inactive" data-value="%2$s"></div>
					</label>
				</div>',
				esc_html( $content_one_title ),
				esc_html( $content_two_title ),
				esc_attr( $toggle_alignment ),
				wp_rand()
			);
		}

		$render_content_one = '';
		if ( 'dipl_content_one_text' === $content_one_type && ! empty( $content_one_text ) ) {
			$render_content_one = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_content_one_toggle dipl_content_toggle_text' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content_one_text,
			] );
		} elseif ( 'dipl_content_one_layout' === $content_one_type && ! empty( $content_one_layout ) && '-1' !== $content_one_layout ) {
			// $layout_one_content = do_shortcode( get_the_content( null, false, intval( $content_one_layout ) ) );
			// $layout_one_content = apply_filters( 'the_content', $layout_one_content );
			$render_content_one = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_content_one_toggle dipl_content_toggle_layout' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => DIPLUtils::load_library_content( $content_one_layout, $order_class . '_one' ),
			] );
		}

		$render_content_two = '';
		if ( 'dipl_content_two_text' === $content_two_type && ! empty( $content_two_text ) ) {
			$render_content_two = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_content_two_toggle dipl_content_toggle_text' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content_two_text,
			] );
		} elseif ( 'dipl_content_two_layout' === $content_two_type && ! empty( $content_two_layout ) && '-1' !== $content_two_layout ) {
			// $layout_two_content = do_shortcode( get_the_content( null, false, intval( $content_two_layout ) ) );
			// $layout_two_content = apply_filters( 'the_content', $layout_two_content );
			$render_content_two = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_content_two_toggle dipl_content_toggle_layout' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => DIPLUtils::load_library_content( $content_two_layout, $order_class . '_two' ),
			] );
		}

		// Final output.
		$rendered_output = '';
		if ( ! empty( $render_content_one ) || ! empty( $render_content_two ) ) {
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class'  => 'dipl_content_toggle_wrapper' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $render_toggle_layout . $render_content_one . $render_content_two,
			] );
		}

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'classnamesFunction'  => [ ContentToggle::class, 'module_classnames' ],
			'moduleCategory'      => $block->block_type->category,
			'stylesComponent'     => [ ContentToggle::class, 'module_styles' ],
			'scriptDataComponent' => [ ContentToggle::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
