<?php
namespace DIPL\Modules\ContentToggle\ContentToggleTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\FormField\FormFieldStyle;
use DIPL\Modules\ContentToggle\ContentToggle;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			// Toggle Switch.
			$elements->style( [
				'attrName'   => 'toggleSwitch',
			] ),

			// Toggle Content.
			$elements->style( [
				'attrName'   => 'contentOne',
			] ),
			$elements->style( [
				'attrName'   => 'contentTwo',
			] ),

			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_toggle_layout_one .dipl_switch::before, {$order_class} .dipl_toggle_layout_two .dipl_switch::before",
				'attr'      => $attrs['toggleSwitch']['advanced']['switchColorOff'],
				'property'  => 'background-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_toggle_layout_one .dipl_toggle_bg, {$order_class} .dipl_toggle_layout_two .dipl_switch",
				'attr'      => $attrs['toggleSwitch']['advanced']['switchBgColorOff'],
				'property'  => 'background-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_toggle_layout_one .dipl_toggle_field:checked + .dipl_switch::before",
				'attr'      => $attrs['toggleSwitch']['advanced']['switchColorOn'],
				'property'  => 'background-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_toggle_layout_one .dipl_toggle_field:checked ~ .dipl_toggle_bg",
				'attr'      => $attrs['toggleSwitch']['advanced']['switchBgColorOn'],
				'property'  => 'background-color',
			] ),
        );

		$layout = $attrs['toggleSwitch']['advanced']['layout']['desktop']['value'] ?? 'dipl_toggle_layout_one';
		if ( 'dipl_toggle_layout_one' === $layout ) {
			array_push( $styles, $elements->style( [
				'attrName'   => 'toggleTitle',
			] ) );
		} else {
			array_push( $styles,
				$elements->style( [
					'attrName'   => 'layoutTwoLabel',
				] ),
				$elements->style( [
					'attrName'   => 'layoutTwoActiveLabel',
				] )
			);
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
