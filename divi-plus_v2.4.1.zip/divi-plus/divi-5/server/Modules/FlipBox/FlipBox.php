<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FlipBox;
 */

namespace DIPL\Modules\FlipBox;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FlipBox\FlipBoxTraits;

/**
 * Class FlipBox
 *
 * @package DIPL\Modules\FlipBox
 */
class FlipBox implements DependencyInterface {

    use FlipBoxTraits\RenderCallbackTrait;
    use FlipBoxTraits\ModuleClassnamesTrait;
    use FlipBoxTraits\ModuleStylesTrait;
    use FlipBoxTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/flip-box';
        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [ 'render_callback' => [ FlipBox::class, 'render_callback' ] ]
                );
            }
        );
    }
}
