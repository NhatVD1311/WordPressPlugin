<?php
namespace DIPL\Modules\FlipBox\FlipBoxTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

trait StyleDeclarationTrait {

	public static function icon_font_declaration( $params ) {
		$icon_attr = $params['attrValue'] ?? [];

		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
			'important'  => [
				'font-family' => true,
				'font-weight' => true,
			],
		] );

		if ( ! empty( $icon_attr ) ) {
			$font_family = isset( $icon_attr['type'] ) && 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', '"' . $font_family . '"' );

			if ( isset( $icon_attr['weight'] ) ) {
				$style_declarations->add( 'font-weight', $icon_attr['weight'] );
			}
		}

		return $style_declarations->value();
	}

	public static function image_alignment_style_declaration( array $args ): string {
		$attr_value = $args['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'margin-left'  => true,
					'margin-right' => true,
				],
			]
		);

		switch( $attr_value ) {
	  		case 'center':
	  			$style_declarations->add( 'margin-left', 'auto' );
	  			$style_declarations->add( 'margin-right', 'auto' );
	  			$style_declarations->add( 'text-align', 'center' );
	  			break;

	  		case 'left':
	  			$style_declarations->add( 'margin-left', '0' );
	  			$style_declarations->add( 'margin-right', 'auto' );
	  			$style_declarations->add( 'text-align', 'left' );
	  			break;

	  		case 'right':
	  			$style_declarations->add( 'margin-left', 'auto' );
	  			$style_declarations->add( 'margin-right', '0' );
	  			$style_declarations->add( 'text-align', 'right' );
	  			break;

	  		default:
	  			break;
	  	}

		return $style_declarations->value();
	}

	public static function layout_one_flip_speed_declaration( array $args ): string {
		$attr_value 	= intval($args['attrValue']) ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);
		
		$style_declarations->add( '-webkit-transition', "all {$attr_value}ms cubic-bezier(.5, .3, .3, 1)" );
		$style_declarations->add( '-moz-transition', "all {$attr_value}ms cubic-bezier(.5, .3, .3, 1)" );
		$style_declarations->add( 'transition', "all {$attr_value}ms cubic-bezier(.5, .3, .3, 1)" );

		return $style_declarations->value();
	}

	public static function layout_one_shake_effect_declaration( array $args ): string {
		$attr_value 	= intval($args['attrValue']) ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);
		
		$style_declarations->add( '-webkit-transition', "transform {$attr_value}ms cubic-bezier(0.3, 0.9, 0.40, 1.3)" );
		$style_declarations->add( '-moz-transition', "transform {$attr_value}ms cubic-bezier(0.3, 0.9, 0.40, 1.3)" );
		$style_declarations->add( 'transition', "transform {$attr_value}ms cubic-bezier(0.3, 0.9, 0.40, 1.3)" );

		return $style_declarations->value();
	}

	public static function layout_two_flip_speed_declaration( array $args ): string {
		$attr_value = intval($args['attrValue']) ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);
		
		$style_declarations->add( '-webkit-transition', "transform {$attr_value}ms ease" );
		$style_declarations->add( '-moz-transition', "transform {$attr_value}ms ease" );
		$style_declarations->add( 'transition', "transform {$attr_value}ms ease" );

		return $style_declarations->value();
	}

	public static function layout_one_3d_depth_declaration( array $args ): string {
		$attr_value = $args['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);
		
		if ( 'on' === $attr_value ) {
			$style_declarations->add( '-webkit-transform', "translateZ(50px) scale(0.95)" );
			$style_declarations->add( '-moz-transform', "translateZ(50px) scale(0.95)" );
			$style_declarations->add( 'transform', "translateZ(50px) scale(0.95)" );
		}

		return $style_declarations->value();
	}
}