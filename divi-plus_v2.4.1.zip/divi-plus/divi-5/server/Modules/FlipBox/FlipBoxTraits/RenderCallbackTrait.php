<?php
namespace DIPL\Modules\FlipBox\FlipBoxTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\FlipBox\FlipBox;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;

trait RenderCallbackTrait {

	public static function render_image_icon( $icon, $icon_classnames, $animation) {
		$font_icon          = Utils::process_font_icon( $icon['innerContent']['desktop']['value'] ?? [] );
		$style_icon         = $icon['advanced']['styleIcon']['desktop']['value'] ?? 'off';
		$icon_shape         = $icon['advanced']['shape']['desktop']['value'] ?? 'use_square';
		$use_shape_border   = $icon['advanced']['useShapeBorder']['desktop']['value'] ?? 'off';
		$icon_wrapper       = '';

		if ( 'on' === $style_icon ) {
			switch ( $icon_shape ) {
				case 'use_square' :
					array_push( $icon_classnames, 'el-icon-square', "et-animated et_pb_animation_{$animation}" );
					if ( 'on' === $use_shape_border ) {
						array_push( $icon_classnames, 'el-icon-shape-border' );
					}
				break;
				case 'use_circle' :
					array_push( $icon_classnames, 'el-icon-circle', "et-animated et_pb_animation_{$animation}" );
					if ( 'on' === $use_shape_border ) {
						array_push( $icon_classnames, 'el-icon-shape-border' );
					}
				break;
				case 'use_hexagon' :
					array_push( $icon_classnames, 'el-icon-hexagon' );
					$rendered_icon = HTMLUtility::render( [
						'tag'               => 'span',
						'attributes'        => [ 'class' => implode( ' ', $icon_classnames ), ],
						'childrenSanitizer' => 'esc_html',
						'children'          => $font_icon,
					] );
					$icon_container = HTMLUtility::render( [
						'tag'               => 'div',
						'attributes'        => [
							'class' => "hexagon-wrapper et-animated et_pb_animation_{$animation}",
						],
						'childrenSanitizer' => 'et_core_esc_previously',
						'children'          => HTMLUtility::render( [
							'tag'               => 'div',
							'attributes'        => [ 'class' => 'hex' ],
							'childrenSanitizer' => 'et_core_esc_previously',
							'children'          => HTMLUtility::render( [
								'tag'               => 'div',
								'attributes'        => [
									'class' => 'on' === $use_shape_border ? 'hexagon et-pb-icon-shape-border' : 'hexagon',
								],
								'children'          => $rendered_icon,
								'childrenSanitizer' => 'et_core_esc_previously',
							] ),
						] ),
					] );
					break;
				default:
					break;
			}

			if ( 'use_hexagon' !== $icon_shape ) {
				$icon_container = HTMLUtility::render( [
					'tag'               => 'span',
					'attributes'        => [
						'class' => implode( ' ', $icon_classnames ),
					],
					'childrenSanitizer' => 'esc_html',
					'children'          => $font_icon,
				] );
			}

			$icon_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'class' => "et_pb_main_flipbox_image use_icon {$icon_shape}",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_container,
			] );
		} else {
			array_push( $icon_classnames, "et-animated et_pb_animation_{$animation}" );
			$icon_container = HTMLUtility::render( [
				'tag'               => 'span',
				'attributes'        => [ 'class' => implode( ' ', $icon_classnames ) ],
				'childrenSanitizer' => 'esc_html',
				'children'          => $font_icon,
			] );
			$icon_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'class' => "et_pb_main_flipbox_image use_icon",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_container,
			] );
		}

		return $icon_wrapper;
	}

	public static function render_callback( $attrs, $content, $block, $elements ) {
		$layout                 = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$layout1_flip_style     = $attrs['module']['advanced']['layoutOneFlipStyle']['desktop']['value'] ?? 'top';
		$layout2_flip_style     = $attrs['module']['advanced']['layoutTwoFlipStyle']['desktop']['value'] ?? 'top';
		$use_front_icon         = $attrs['frontIcon']['advanced']['use']['desktop']['value'] ?? 'off';
		$use_back_icon          = $attrs['backIcon']['advanced']['use']['desktop']['value'] ?? 'off';
		$front_icon_placement   = $attrs['frontIcon']['advanced']['placement']['desktop']['value'] ?? 'top';
		$back_icon_placement    = $attrs['backIcon']['advanced']['placement']['desktop']['value'] ?? 'top';
		$front_content_align    = $attrs['frontSide']['advanced']['contentAlign']['desktop']['value'] ?? 'center';
		$back_content_align     = $attrs['backSide']['advanced']['contentAlign']['desktop']['value'] ?? 'center';
		$animation              = $attrs['module']['advanced']['iconAnimation']['desktop']['value'] ?? 'top';
		$display_button         = $attrs['backButton']['advanced']['use']['desktop']['value'] ?? 'off';
		$icon_classnames        = array( 'et-pb-icon' );
		$image_classnames       = "et-animated et_pb_animation_{$animation}";
		$front_icon_wrapper     = '';
		$back_icon_wrapper      = '';
		$back_button_wrapper    = '';
		$wrapper                = '';
		
		// Front Title.
		$front_title = $elements->render( [
			'attrName' => 'frontTitle',
		] );
		$front_title = DynamicData::get_processed_dynamic_data( $front_title );
		if ( $front_title ) {
			$front_title = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_flipbox_heading' ],
				'children'          => $front_title,
				'childrenSanitizer' => 'et_core_esc_previously',
			] );
		}

		// Front Content.
		$front_content = $elements->render( [
			'attrName' => 'frontContent',
		] );
		$front_content = DynamicData::get_processed_dynamic_data( $front_content );

		// Back Title.
		$back_title = $elements->render( [
			'attrName' => 'backTitle',
		] );
		$back_title = DynamicData::get_processed_dynamic_data( $back_title );
		if ( $back_title ) {
			$back_title = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_flipbox_heading_back' ],
				'children'          => $back_title,
				'childrenSanitizer' => 'et_core_esc_previously',
			] );
		}

		// Back Content.
		$back_content = $elements->render( [
			'attrName' => 'backContent',
		] );
		$back_content = DynamicData::get_processed_dynamic_data($back_content);

		// Front Image.
		$front_image = $elements->render( [
			'attrName' => 'frontImage',
			'attributes' => [ 'class' => $image_classnames ]
		] );

		// Back Image.
		$back_image = $elements->render( [
			'attrName' => 'backImage',
			'attributes' => [
				'class' => $image_classnames
			]
		] );

		// Back button.
		if ( 'on' === $display_button ) {
			$back_button = $elements->render( [
				'attrName' => 'backButton'
			] );
			$back_button_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_flipbox_button_back' ],
				'children'          => $back_button,
				'childrenSanitizer' => 'et_core_esc_previously',
			] );
		}

		if ( 'off' !== $animation ) {
			array_push( $icon_classnames, 'et-animated' );
		}

		if ( 'on' === $use_front_icon ) {
			$front_icon_wrapper = FlipBox::render_image_icon( $attrs['frontIcon'], $icon_classnames, $animation );
		} else {
			$front_icon_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_main_flipbox_image' ],
				'children'          => $front_image,
				'childrenSanitizer' => 'et_core_esc_previously',
			] );
		}

		if ( 'on' === $use_back_icon ) {
			$back_icon_wrapper = FlipBox::render_image_icon( $attrs['backIcon'], $icon_classnames, $animation );
		} else {
			$back_icon_wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'et_pb_main_flipbox_image' ],
				'children'          => $back_image,
				'childrenSanitizer' => 'et_core_esc_previously',
			] );
		}

		$front = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class' => "flipbox_side flipbox_front flipbox_position_{$front_icon_placement} flipbox_content_{$front_content_align}",
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => "flipbox_inner" ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $front_icon_wrapper . HTMLUtility::render( [
					'tag'               => 'div',
					'attributes'        => [ 'class' => "flipbox_front_content_wrapper" ],
					'children'          => $front_title . $front_content,
					'childrenSanitizer' => 'et_core_esc_previously',
				] ),
			] ),
		] );

		$back = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class' => "flipbox_side flipbox_back flipbox_position_{$back_icon_placement} flipbox_content_{$back_content_align}",
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => "flipbox_inner" ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $back_icon_wrapper . HTMLUtility::render( [
					'tag'               => 'div',
					'attributes'        => [ 'class' => "flipbox_front_content_wrapper" ],
					'children'          => $back_title . $back_content . $back_button_wrapper,
					'childrenSanitizer' => 'et_core_esc_previously',
				] ),
			] ),
		] );

		$wrapper = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class' => "dipl_flipbox_wrapper {$layout}",
				'data-direction' => 'layout1' === $layout ? $layout1_flip_style : $layout2_flip_style,
			],
			'children'          => $front . $back,
			'childrenSanitizer' => 'et_core_esc_previously',
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ FlipBox::class, 'module_classnames' ],
			'stylesComponent'     => [ FlipBox::class, 'module_styles' ],
			'scriptDataComponent' => [ FlipBox::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module' ]
									) . $wrapper,
		] );
	}
}
