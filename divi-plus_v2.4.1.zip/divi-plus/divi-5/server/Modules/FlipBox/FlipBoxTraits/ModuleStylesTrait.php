<?php
namespace DIPL\Modules\FlipBox\FlipBoxTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Icon\IconStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\FlipBox\FlipBox;

trait ModuleStylesTrait {

    use CustomCssTrait;
    use StyleDeclarationTrait;

    public static function module_styles( $args ) {
        $attrs          = $args['attrs'] ?? [];
        $order_class    = $args['orderClass'];
        $elements       = $args['elements'];
        $settings       = $args['settings'] ?? [];

        $flip_speed = intval( $attrs['module']['advanced']['flipSpeed']['desktop']['value'] ) . 'ms';

        $styles = [
            // Element: Module.
            $elements->style([
                'attrName'   => 'module',
                'styleProps' => [
                    'disabledOn' => [
                        'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                    ],
                ],
            ]),
            $elements->style([
                'attrName'   => 'frontTitle',
            ]),
            $elements->style([
                'attrName'   => 'backTitle',
            ]),
            $elements->style([
                'attrName'   => 'frontContent',
            ]),
            $elements->style([
                'attrName'   => 'backContent',
            ]),
            $elements->style([
                'attrName'   => 'backImage',
            ]),
            $elements->style([
                'attrName'   => 'contentMaxWidth',
            ]),
            $elements->style([
                'attrName'   => 'flipBoxMinHeight',
            ]),
            $elements->style([
                'attrName'   => 'frontSide',
            ]),
            $elements->style([
                'attrName'   => 'backSide',
            ]),
            $elements->style([
                'attrName'   => 'backButton',
            ]),
            CssStyle::style([
                'selector'  => $args['orderClass'],
                'attr'      => $attrs['css'] ?? [],
                'cssFields' => self::custom_css(),
            ]),
        ];

        if ( 'on' === $attrs['frontIcon']['advanced']['use']['desktop']['value'] ) {
            array_push(
                $styles,
                CommonStyle::style( [
                    'selector' => "{$order_class} .flipbox_front .et-pb-icon",
                    'attr'     => $attrs['frontIcon']['innerContent'],
                    'declarationFunction' => [ FlipBox::class, 'icon_font_declaration' ]
                ] ),
                $elements->style([
                    'attrName'   => 'frontIcon',
                ])
            );

            if ( 'on' === $attrs['frontIcon']['advanced']['styleIcon']['desktop']['value'] ) {   
                if ( 'use_hexagon' === $attrs['frontIcon']['advanced']['shape']['desktop']['value'] ) {
                    array_push(
                        $styles,
                        CommonStyle::style( [
                            'selector' => "{$order_class} .flipbox_front .hexagon",
                            'attr'     => $attrs['frontIcon']['advanced']['shapeColor'],
                            'property' => "background-color"
                        ] )
                    );
                } else {
                    array_push(
                        $styles,
                        CommonStyle::style( [
                            'selector' => "{$order_class} .flipbox_front .et-pb-icon",
                            'attr'     => $attrs['frontIcon']['advanced']['shapeColor'],
                            'property' => "background-color"
                        ] )
                    );
                }

                if ( 'on' === $attrs['frontIcon']['advanced']['useShapeBorder']['desktop']['value'] ) {
                    if ( 'use_hexagon' ===  $attrs['frontIcon']['advanced']['shape']['desktop']['value'] ) {
                        array_push(
                            $styles,
                            CommonStyle::style( [
                                'selector' => "{$order_class} .flipbox_front .hex .et-pb-icon-shape-border",
                                'attr'     => $attrs['frontIcon']['advanced']['shapeBorderColor'],
                                'property' => "border-color"
                            ] )
                        );
                    } else {
                        array_push(
                            $styles,
                            CommonStyle::style( [
                                'selector' => "{$order_class} .flipbox_front .et-pb-icon",
                                'attr'     => $attrs['frontIcon']['advanced']['shapeBorderColor'],
                                'property' => "border-color"
                            ] )
                        );
                    }
                }
            }
        }

        if ( 'on' === $attrs['backIcon']['advanced']['use']['desktop']['value'] ) {
            array_push(
                $styles,
                CommonStyle::style( [
                    'selector' => "{$order_class} .flipbox_back .et-pb-icon",
                    'attr'     => $attrs['backIcon']['innerContent'],
                    'declarationFunction' => [ FlipBox::class, 'icon_font_declaration' ]
                ] ),
                $elements->style([
                    'attrName'   => 'backIcon',
                ])
            );

            if ( 'on' === $attrs['backIcon']['advanced']['styleIcon']['desktop']['value'] ) {   
                if ( 'use_hexagon' === $attrs['backIcon']['advanced']['shape']['desktop']['value'] ) {
                    array_push(
                        $styles,
                        CommonStyle::style( [
                            'selector' => "{$order_class} .flipbox_back .hexagon",
                            'attr'     => $attrs['backIcon']['advanced']['shapeColor'],
                            'property' => "background-color"
                        ] )
                    );
                } else {
                    array_push(
                        $styles,
                        CommonStyle::style( [
                            'selector' => "{$order_class} .flipbox_back .et-pb-icon",
                            'attr'     => $attrs['backIcon']['advanced']['shapeColor'],
                            'property' => "background-color"
                        ] )
                    );
                }

                if ( 'on' === $attrs['backIcon']['advanced']['useShapeBorder']['desktop']['value'] ) {
                    if ( 'use_hexagon' ===  $attrs['backIcon']['advanced']['shape']['desktop']['value'] ) {
                        array_push(
                            $styles,
                            CommonStyle::style( [
                                'selector' => "{$order_class} .flipbox_back .hex .et-pb-icon-shape-border",
                                'attr'     => $attrs['backIcon']['advanced']['shapeBorderColor'],
                                'property' => "border-color"
                            ] )
                        );
                    } else {
                        array_push(
                            $styles,
                            CommonStyle::style( [
                                'selector' => "{$order_class} .flipbox_back .et-pb-icon",
                                'attr'     => $attrs['backIcon']['advanced']['shapeBorderColor'],
                                'property' => "border-color"
                            ] )
                        );
                    }
                }
            }
        }

        if ( 'off' === $attrs['frontIcon']['advanced']['use']['desktop']['value'] ) {
            array_push(
                $styles,
                $elements->style([
                    'attrName'   => 'frontImage',
                ])
            );
            if ( 'top' === $attrs['backIcon']['advanced']['placement']['desktop']['value'] ) {
                array_push(
                    $styles,
                    CommonStyle::style( [
                        'selector' => "{$order_class} .flipbox_front .et_pb_main_flipbox_image:not(.use_icon)",
                        'attr'     => $attrs['frontImage']['advanced']['alignment'],
                        'declarationFunction' => [ FlipBox::class, 'image_alignment_style_declaration' ]
                    ] )
                );
            }
        }

        if ( 'off' === $attrs['backIcon']['advanced']['use']['desktop']['value'] ) {
            array_push(
                $styles,
                $elements->style([
                    'attrName'   => 'backImage',
                ])
            );
            if ( 'top' === $attrs['frontIcon']['advanced']['placement']['desktop']['value'] ) {
                array_push(
                    $styles,
                    CommonStyle::style( [
                        'selector' => "{$order_class} .flipbox_back .et_pb_main_flipbox_image:not(.use_icon)",
                        'attr'     => $attrs['backImage']['advanced']['alignment'],
                        'declarationFunction' => [ FlipBox::class, 'image_alignment_style_declaration' ]
                    ] )
                );
            }
        }

        if (  'layout1' === $attrs['module']['advanced']['layout']['desktop']['value'] ) {
            $shake_effect = $attrs['module']['advanced']['layoutOneShakeEffect']['desktop']['value'] ?? 'off';
            array_push(
                $styles,
                CommonStyle::style( [
                    'selector' => "{$order_class} .flipbox_side.el-transition, {$order_class} .layout1.el-transition",
                    'attr'     => $attrs['module']['advanced']['flipSpeed'],
                    'declarationFunction' => 'off' == $shake_effect ? [ FlipBox::class, 'layout_one_flip_speed_declaration' ] : [ FlipBox::class, 'layout_one_shake_effect_declaration' ]
                ] ),
                CommonStyle::style( [
                    'selector' => "{$order_class} .dipl_flipbox_wrapper .flipbox_inner",
                    'attr'     => $attrs['module']['advanced']['layoutOne3dDepth'],
                    'declarationFunction' => [ FlipBox::class, 'layout_one_3d_depth_declaration' ]
                ] )
            );
        } else {
            array_push(
                $styles,
                CommonStyle::style( [
                    'selector' => "{$order_class} .layout2.el-transition, {$order_class}:hover .layout2.el-transition",
                    'attr'     => $attrs['module']['advanced']['flipSpeed'],
                    'declarationFunction' => [ FlipBox::class, 'layout_two_flip_speed_declaration' ]
                ] )
            );
        }

        Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => $styles,
        ]);
    }
}