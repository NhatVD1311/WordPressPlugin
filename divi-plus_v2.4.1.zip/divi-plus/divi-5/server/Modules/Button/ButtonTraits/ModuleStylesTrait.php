<?php
namespace DIPL\Modules\Button\ButtonTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DIPL\Modules\Button\Button;

trait ModuleStylesTrait {

    use CustomCssTrait;
    //use StyleDeclarationTrait;

    public static function module_styles( $args ) {
        $attrs          = $args['attrs'] ?? [];
        $order_class    = $args['orderClass'];
        $elements       = $args['elements'];
        $settings       = $args['settings'] ?? [];

        $styles = [
            // Element: Module.
            $elements->style( [
                'attrName'   => 'module',
                'styleProps' => [
                    'disabledOn' => [
                        'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                    ],
                ],
            ] ),

            $elements->style( [
                'attrName' => 'button',
            ] ),

            CssStyle::style([
                'selector'  => $args['orderClass'],
                'attr'      => $attrs['css'] ?? [],
                'cssFields' => self::custom_css(),
            ]),

            CommonStyle::style( [
                'selector' => $order_class,
                'attr'     => $attrs['module']['advanced']['alignment'] ?? [],
                'property' => 'text-align'
            ] ),

            CommonStyle::style( [
                'selector' => "{$order_class} .dipl_button_icon:before, {$order_class} .dipl_button_icon:after",
                'attr'     => $attrs['button']['advanced']['iconColor'] ?? [],
                'property' => 'color'
            ] ),

            CommonStyle::style( [
                'selector' => "{$order_class} .dipl_button_item",
                'attr'     => $attrs['module']['advanced']['inlineButtons'] ?? [],
                'declarationFunction' => function ($attr) {
                    $attrValue    = $attr['attrValue'];
                    $declarations = new StyleDeclarations( [
                        'returnType' => 'string',
                    ] );
                    if ( 'on' === $attrValue ) {
                        $declarations->add( 'display', 'inline-block' );
                    }

                    return $declarations->value();
                }
            ] ),
        ];

        Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => $styles,
        ]);
    }
}