<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\Button;
 */

namespace DIPL\Modules\Button;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\Button\ButtonTraits;

/**
 * Class Button
 *
 * @package DIPL\Modules\Button
 */
class Button implements DependencyInterface {

    use ButtonTraits\RenderCallbackTrait;
    use ButtonTraits\ModuleClassnamesTrait;
    use ButtonTraits\ModuleStylesTrait;
    use ButtonTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/button';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ Button::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}