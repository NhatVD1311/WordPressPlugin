<?php
/**
 * Advanced Table Item class.
 *
 * @package DIPL\Modules\AdvancedTableItem;
 */
namespace DIPL\Modules\AdvancedTableItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AdvancedTableItem\AdvancedTableItemTraits;

/**
 * Class AdvancedTableItem
 *
 * @package DIPL\Modules\AdvancedTableItem
 */
class AdvancedTableItem implements DependencyInterface {

	use AdvancedTableItemTraits\RenderCallbackTrait;
	use AdvancedTableItemTraits\ModuleClassnamesTrait;
	use AdvancedTableItemTraits\ModuleStylesTrait;
	use AdvancedTableItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/advanced-table-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AdvancedTableItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
