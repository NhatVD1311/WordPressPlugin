<?php
namespace DIPL\Modules\AdvancedTableItem\AdvancedTableItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

trait CustomCssTrait {
	public static function custom_css() {
		return \WP_Block_Type_Registry::get_instance()->get_registered( 'dipl/advanced-table-item' )->customCssFields;
	}
}
