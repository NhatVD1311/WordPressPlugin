<?php
namespace DIPL\Modules\ButtonItem\ButtonItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Background\BackgroundStyle;

use DIPL\Modules\ButtonItem\ButtonItem;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		// $button_icon_color = [];
		// foreach ( $attrs['button']['decoration']['button'] as $breakpoint => $data ) {
		// 	if ( ! empty( $data['value']['icon']['color'] ) ) {
		// 		$button_icon_color[$breakpoint]['value'] = $data['value']['icon']['color'];
		// 	}
		// }

		$fill_style = $attrs['button']['advanced']['background']['desktop']['value']['hoverStyle'];

		$styles = [
			// Element: Module.
			$elements->style([
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			TextStyle::style( [
				'selector'  => "{$order_class} .dipl_button_link",
				'attr'      => $attrs['button']['advanced']['text'] ?? [],
			] ),
			CssStyle::style( [
				'selector'  => "{$order_class}",
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_button_wrapper",
				'attr'      => $attrs['button']['advanced']['alignment'] ?? [],
				'property'  => 'text-align',
				'important' => true,
			] ),

			BackgroundStyle::style( [
				'selector' 	=> "{$order_class} .dipl_button_link",
				'selectorFunction' => function( $params ) use ( $fill_style, $order_class ) {
					$selector = "{$order_class} .dipl_button_link";
					if ( 'hover' === $params['state'] ) {
						if ( 'default_fill' !== $fill_style ) {
							if ( 'vertical_shutter_fill' === $fill_style || 'horizontal_shutter_fill' === $fill_style ) {
								$selector = "{$order_class} .dipl_button_link:hover .dipl_background_effect_wrap:before, {$order_class} .dipl_button_link:hover .dipl_background_effect_wrap:after";
							} else {
								$selector = "{$order_class} .dipl_button_link:hover .dipl_background_effect_wrap:before";	
							}
						} else {
							$selector = "{$order_class} .dipl_button_link:hover";
						}
					}
					return $selector;
				},
				'attr' => $attrs['button']['advanced']['background'] ?? [],
			] ),

			// REMOVED: mouse hover it's changed the padding, when custom padding applied.
			// $elements->style( [
			// 	'attrName' => 'button',
			// 	'styleProps' => [
            //     	'advancedStyles' => [
	        //             [
	        //                 'componentName' => 'divi/common',
	        //                 'props'         => [
			// 					'selectors'  => [
			// 						'desktop' => [
			// 							'value'  => "{$order_class} .dipl_button_icon:before, {$order_class} .dipl_button_icon:after",
			// 							'hover'  => "{$order_class} .dipl_button_link{{:hover}} .dipl_button_icon:before, {$order_class} .dipl_button_link{{:hover}} .dipl_button_icon:after",
			// 						]
			// 					],
			// 				    'attr'     => $attrs['button']['decoration']['button'] ?? [],
			// 				    'declarationFunction' => [ ButtonItem::class, 'icon_style_declaration' ]
	        //                 ]
	        //             ]
	        //         ]
	        //     ]
			// ] ),
			$elements->style( [
				'attrName' => 'buttonText',
			] ),
			$elements->style( [
				'attrName' => 'secondaryText',
			] )
		];

		$button_type            = $attrs['button']['advanced']['type']['desktop']['value'] ?? 'classic';
		$button_text            = $attrs['buttonText']['innerContent']['desktop']['value'] ?? '';
		$secondary_text         = $attrs['secondaryText']['innerContent']['desktop']['value'] ?? '';
		$button_text_font       = $attrs['buttonText']['decoration']['font']['font'] ?? [];
		$secondary_text_font    = $attrs['secondaryText']['decoration']['font']['font'] ?? [];
		$button_object          = $attrs['button']['decoration']['button']['desktop']['value'] ?? '';
		$button_object_hover    = $attrs['button']['decoration']['button']['desktop']['hover'] ?? [];
		$use_icon               = $button_object['icon']['enable'] ?? 'off';
		$icon_on_hover          = $button_object['icon']['onHover'] ?? 'on';
		$icon_placement         = $button_object['icon']['placement'] ?? 'right';
		$icon_object_hover      = $button_object_hover['icon']['settings'] ?? '';
		$icon_placement_hover   = $button_object_hover['icon']['placement'] ?? '';
		$text_alignment         = $attrs['button']['advanced']['text']['text'] ?? [];
		$breakpoints            = array('desktop','tablet','phone');
	
		if ( empty( $button_text_font['desktop']['value']['size'] ) ) {
			$button_text_font['desktop']['value']['size'] = '18px';
		}

		if ( empty( $secondary_text_font ) ) {
			$secondary_text_font = array(
				'desktop' => array(
					'value' => '14px'
				)
			);
		}

		if ( 'on' === $use_icon ) {
			/* Positioning of icon when show icon only on hover */
			$icon_pseudo_selector   = 'left' === $icon_placement ? ':before'  : ':after';
			$negation_sign          = 'left' === $icon_placement ? '-'       : '';

			if ( 'on' === $icon_on_hover && '' !== $button_text ) {
				$placement_selector = "{$order_class} .dipl_button_icon{$icon_pseudo_selector}";
				$translate_selector = "{$order_class} .dipl_button_icon";
				$translate_values   = [ 'desktop' => [ 'value' => 'translateX('. $negation_sign .'12px)' ] ];
				$position_values    = array();
				foreach( $button_text_font as $breakpoint => $data ) {
					if ( ! empty( $data['value']['size'] ) ) {

						$position_values[$breakpoint]['value'] = $data['value']['size'];

						$unit  = str_replace( floatval( $data['value']['size'] ), '', $data['value']['size'] );
						$value = ( floatval( $data['value']['size'] ) / 2 ) + 3;
						$value = 'translateX(' . $negation_sign . $value . $unit . ')';
						
						$translate_values[$breakpoint]['value'] = $value;
					}
				}

				array_push(
					$styles,
					CommonStyle::style( [
						'selector'  => $placement_selector,
						'attr'      => $position_values,
						'property'  => $icon_placement,
						'important' => true,
					] ),
					CommonStyle::style( [
						'selector'  => $translate_selector,
						'attr'      => $translate_values,
						'property'  => "transform",
						'important' => true,
					] ),
					CommonStyle::style( [
						'selector'  => $translate_selector,
						'attr'      => [ 'desktop' => [ 'value' => 'color 300ms linear, transform 300ms linear' ] ],
						'property'  => "transition",
						'important' => true,
					] )
				);
				
				if ( 'conversion' === $button_type ) {
					$secondary_translate_values = array();
					if ( '' !== $secondary_text ) {
						foreach( $breakpoints as $breakpoint ) {
							switch( $breakpoint ) {
								case 'desktop':
									$width          = $button_text_font['desktop']['value']['size'];
									$unit           = str_replace( floatval( $width ), '', $width );
									$width          = ( floatval( $width ) / 2 ) + 3;
									$width          = $width . $unit;
									$orientation    = $text_alignment['desktop']['value']['orientation'];
									$secondary_translate_values['desktop']['value']['width'] = $width;
									$secondary_translate_values['desktop']['value']['orientation'] = $orientation;
									break;

								case 'tablet':
									if ( isset( $button_text_font['tablet']['value']['size'] ) ) {
										$width  = $button_text_font['tablet']['value']['size'];
										$unit   = str_replace( floatval( $width ), '', $width );
										$width  = ( floatval( $width ) / 2 ) + 3;
										$width  = $width . $unit;
									} else {
										$width  = $secondary_translate_values['desktop']['value']['width'];
									}
									if ( isset( $text_alignment['tablet']['value']['orientation'] ) ) {
										$orientation = $text_alignment['tablet']['value']['orientation'];
									} else {
										$orientation = $secondary_translate_values['desktop']['value']['orientation'];
									}
									$secondary_translate_values['tablet']['value']['width'] = $width;
									$secondary_translate_values['tablet']['value']['orientation'] = $orientation;
									break;

								case 'phone':
									if ( isset( $button_text_font['phone']['value']['size'] ) ) {
										$width  = $button_text_font['phone']['value']['size'];
										$unit   = str_replace( floatval( $width ), '', $width );
										$width  = ( floatval( $width ) / 2 ) + 3;
										$width  = $width . $unit;
									} else {
										$width  = $secondary_translate_values['tablet']['value']['width'];
									}
									if ( isset( $text_alignment['phone']['value']['orientation'] ) ) {
										$orientation = $text_alignment['phone']['value']['orientation'];
									} else {
										$orientation = $secondary_translate_values['tablet']['value']['orientation'];
									}
									$secondary_translate_values['phone']['value']['width'] = $width;
									$secondary_translate_values['phone']['value']['orientation'] = $orientation;
									break;
							}
						}

						array_push(
							$styles,
							CommonStyle::style( [
								'selector' => "{$order_class}",
								'attr'     => $secondary_translate_values,
								'declarationFunction' => [ ButtonItem::class, 'secondary_text_translation_declaration' ],
								'selectorFunction' => function( $params ) {
									$attr_breakpoint    = $params['breakpoint'];
									$attr_state         = $params['state'] ?? 'value';
									$orientation        = $params['attr'][$attr_breakpoint][$attr_state]['orientation'];
									if ( 'center' !== $orientation ) {
										$left_oriented      = in_array( $orientation, array( 'left', 'justified' ), true );
										$secondary_pseudo_selector = $left_oriented ? ':before' : ':after';
										$secondary_pseudo_selector_hover = $left_oriented ? ':after'  : ':before';
										$selector = "{$params['selector']} .dipl_button_secondary_text{$secondary_pseudo_selector}, {$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text{$secondary_pseudo_selector_hover}";
									} else {
										$selector = "{$params['selector']} .dipl_button_secondary_text:before, {$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text:before, {$params['selector']} .dipl_button_secondary_text:after, {$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text:after";
									}
									
									$params['selector'] = $selector;
									return $params['selector'];
								}
							] ),
							CommonStyle::style( [
								'selectors' => ['desktop' => [ 'hover' => "{$order_class}" ] ],
								'attr'     	=> $secondary_translate_values,
								'declarationFunction' => [ ButtonItem::class, 'secondary_text_translation_declaration' ],
								'selectorFunction' => function( $params ) {
									$breakpoint    = $params['breakpoint'];
									$orientation   = $params['attr'][$breakpoint]['value']['orientation'];
									if ( 'center' !== $orientation ) {
										$left_oriented      		= in_array( $orientation, array( 'left', 'justified' ), true );
										$secondary_pseudo_selector 	= $left_oriented ? ':after'  : ':before';
										$selector = "{$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text{$secondary_pseudo_selector}";
									} else {
										$selector = "{$params['selector']} .dipl_button_secondary_text:before, {$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text:before, {$params['selector']} .dipl_button_secondary_text:after, {$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text:after";
									}
									
									$params['selector'] = $selector;
									return $params['selector'];
								}
							] ),
							CommonStyle::style( [
								'selector' => "{$order_class}",
								'attr'     => $secondary_translate_values,
								'declarationFunction' => [ ButtonItem::class, 'secondary_text_hover_translation_declaration' ],
								'selectorFunction' => function( $params ) {
									$attr_breakpoint    = $params['breakpoint'];
									$attr_state         = $params['state'] ?? '';
									$orientation        = $params['attr'][$attr_breakpoint][$attr_state]['orientation'];
									$left_oriented      = in_array( $orientation, array( 'left', 'justified' ), true );
									$secondary_pseudo_selector = $left_oriented ? ':before' : ':after';
									$secondary_pseudo_selector_hover = $left_oriented ? ':after'  : ':before';
									$selector = "{$params['selector']} .dipl_button_link:hover .dipl_button_secondary_text{$secondary_pseudo_selector}";
									$params['selector'] = $selector;
									return $params['selector'];
								}
							] )
						);
					}
				}
			}
			array_push(
				$styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_button_icon{$icon_pseudo_selector}",
					'attr'     => $attrs['button']['decoration']['button'],
					'declarationFunction' => [ ButtonItem::class, 'icon_font_declaration' ]
				] ),
			);

			if ( $icon_placement_hover ) {
				$placement_selector_hover = "{$order_class} .dipl_button_link:not(.dipl_button_no_text):hover .dipl_button_icon:{$icon_pseudo_selector}";
				$translate_selector_hover = "{$order_class} .dipl_button_link:not(.dipl_button_no_text):hover .dipl_button_icon";
				$translate_values_hover   = [];

				foreach( $button_text_font as $breakpoint => $data ) {
					if ( ! empty( $data ) ) {
						$unit  = str_replace( floatval( $data['value']['size'] ), '', $data['value']['size'] );
						$value = floatval( $data['value']['size'] ) + 6;
						$value = 'translateX(' . $negation_sign . $value . $unit . ')';
						$translate_values_hover[$breakpoint]['value'] = $value;
					}
				}

				array_push(
					$styles,
					CommonStyle::style( [
						'selector'  => $placement_selector_hover,
						'attr'      => array( 'desktop' => array( 'value' => '100%' ) ),
						'property'  => $icon_placement,
						'important' => true
					] ),
					CommonStyle::style( [
						'selector' => $placement_selector_hover,
						'attr'     => array( 'desktop' => array( 'value' => '0' ) ),
						'property' => 'padding',
						'important' => true
					] ),
					CommonStyle::style( [
						'selector' => $placement_selector_hover,
						'attr'     => array( 'desktop' => array( 'value' => '6px' ) ),
						'property' => "padding-{$icon_placement}",
						'important' => true
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_button_link:not(.dipl_button_no_text) .dipl_button_icon:{$icon_pseudo_selector}",
						'attr'     => array( 'desktop' => array( 'value' => "{$icon_placement} 300ms linear" ) ),
						'property' => "transition",
						'important' => true
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_button_link:not(.dipl_button_no_text) .dipl_button_icon",
						'attr'     => array( 'desktop' => array( 'value' => "transform 300ms linear" ) ),
						'property' => "transition",
						'important' => true
					] ),
					CommonStyle::style( [
						'selector'  => $translate_selector_hover,
						'attr'      => $translate_values_hover,
						'property'  => "transform",
						'important' => true
					] ),
				);
			}

			/* Icon on Hover */
			if ( ! empty( $icon_object_hover ) ) {
				$icon_selector_hover = "{$order_class} .dipl_button_link:hover .dipl_button_icon:{$icon_pseudo_selector}";
				array_push(
					$styles,
					CommonStyle::style( [
						'selector'  => $icon_selector_hover,
						'attr'      => array( 'desktop' => array( 'value' => "diplChangeIcon" ) ),
						'property'  => "animation-name",
						'important' => true
					] ),
					CommonStyle::style( [
						'selector'  => $icon_selector_hover,
						'attr'      => array( 'desktop' => array( 'value' => "forwards" ) ),
						'property'  => "animation-fill-mode",
						'important' => true
					] ),
					CommonStyle::style( [
						'selector'  => $icon_selector_hover,
						'attr'      => array( 'desktop' => array( 'value' => "100ms" ) ),
						'property'  => "animation-delay",
						'important' => true
					] )
				);
			}
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}