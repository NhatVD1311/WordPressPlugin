<?php
namespace DIPL\Modules\ButtonItem\ButtonItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\FrontEnd\Assets\DynamicAssetsUtils;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;
use DIPL\Modules\ButtonItem\ButtonItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$button_type            = $attrs['button']['advanced']['type']['desktop']['value'] ?? 'classic';
		$button_text_str        = $attrs['buttonText']['innerContent']['desktop']['value'] ?? '';
		$button_object          = $attrs['button']['decoration']['button']['desktop']['value'] ?? '';
		$button_object_hover    = $attrs['button']['decoration']['button']['desktop']['hover'] ?? $button_object;
		$use_icon               = $button_object['icon']['enable'] ?? 'off';
		$icon_on_hover          = $button_object['icon']['onHover'] ?? 'on';
		$icon_object            = $button_object['icon']['settings'] ?? '';
		$icon_object_hover      = $button_object_hover['icon']['settings'] ?? $icon_object;
		$icon_placement         = $button_object['icon']['placement'] ?? 'right';
		$fill_style             = $attrs['button']['advanced']['background']['desktop']['value']['hoverStyle'] ?? 'default_fill';
		$button_custom_class    = $attrs['module']['advanced']['htmlAttributes']['desktop']['value']['class'] ?? '';
		$button_custom_id       = $attrs['module']['advanced']['htmlAttributes']['desktop']['value']['id'] ?? '';
		$button_link            = $attrs['module']['advanced']['link']['desktop']['value']['url'] ?? '#';
		$button_target          = $attrs['module']['advanced']['link']['desktop']['value']['target'] ?? 'off';
		$button_link_target     = 'on' === $button_target ? '_blank' : '_self';
		$icon_html_attr         = array();
		// $button_classes         = 'dipl_button_text';
		$button_text_class      = 'dipl_button_text';
		$button_inner_wrap      = array();

		if ( '' === $button_text_str && 'off' === $use_icon ) {
			$wrapper = '';
		} else {

			$button_text_attr = array();
			if ( 'on' === $use_icon ) {
				$icon               = Utils::process_font_icon( $icon_object );
				$icon_hover         = Utils::process_font_icon( $icon_object_hover );
				$button_text_class .= ' dipl_button_icon';
				
				$icon_html_attr     = array(
					'data-icon'       => $icon,
					'data-icon-hover' => $icon_hover
				);
				/*
				$button_text_attr[] = "data-icon='{$icon}'";
				$button_text_attr[] = "data-icon-hover='{$icon_hover}'";
				*/
			}

			$attributes = array_merge(
			    array( 'class' => $button_text_class ),
			    $icon_html_attr
			);

			$button_text = $elements->render( [
			    'attrName'   => 'buttonText',
			    'attributes' => $attributes,
			    'forceRender' => true
			] );

			//$button_text_attr[] = "class='{$button_text_class}'";

			/*
			$button_text = '';
			if ( ! empty( $button_text_str ) || ! empty( $button_text_attr ) ) {
				/*if ( 'Add to Wishlist' === $button_text_str ) {
					print_r($button_text_attr);
					echo implode( ' ', $button_text_attr );
				}
				$button_text = sprintf(
					'<span %1$s>%2$s</span>',
					implode( ' ', $button_text_attr ),
					esc_html( $button_text_str )
				);
			}*/

			if ( 'conversion' === $button_type ) {
				$secondary_text = $elements->render( [
					'attrName' => 'secondaryText',
				] );
				$button_text .= $secondary_text;
			}

			$button_classes = array(
				'dipl_button_link',
				"dipl_button_{$fill_style}",
			);
			if ( '' === $button_text_str ) {
				array_push( $button_classes, 'dipl_button_no_text' );
			}
			
			if ( 'on' === $use_icon && '' !== $icon ) {
				if ( 'on' === $icon_on_hover && '' !== $button_text_str ) {
					array_push( $button_classes, 'dipl_button_icon_on_hover' );
				}
				array_push( $button_classes, "dipl_button_icon_{$icon_placement}" );
			}

			if ( '' !== $button_custom_class ) {
				array_push( $button_classes, esc_attr( $button_custom_class ) );
			}

			$background_wrap = '';
			if ( 'default_fill' !== $fill_style ) {
				$background_wrap = HTMLUtility::render( [
					'tag'        => 'span',
					'attributes' => [
						'class' => 'dipl_background_effect_wrap'
					]
				] );
			}

			$button = HTMLUtility::render( [
				'tag'               => 'a',
				'attributes'        => [
					'id'     => '' !== $button_custom_id ? esc_attr( $button_custom_id ) : null,
					'class'  => $button_classes,
					'href'   => esc_url( $button_link ),
					'target' => esc_attr( $button_link_target )
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $button_text . $background_wrap,
			] );

			$wrapper = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'class' => "dipl_button_wrapper dipl_button_{$button_type}",
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $button,
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ ButtonItem::class, 'module_classnames' ],
			'stylesComponent'     => [ ButtonItem::class, 'module_styles' ],
			'scriptDataComponent' => [ ButtonItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components( [
										'attrName' => 'module',
									] ) . $wrapper,
		] );
	}
}
