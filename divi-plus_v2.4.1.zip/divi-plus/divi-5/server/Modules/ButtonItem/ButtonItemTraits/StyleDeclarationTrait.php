<?php
namespace DIPL\Modules\ButtonItem\ButtonItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

trait StyleDeclarationTrait {

	public static function icon_style_declaration( $params ) {
		$color = $params['attrValue']['icon']['color'] ?? '';

		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
			'important'  => [
				'color' => true,
			],
		] );

		if ( '' !== $color ) {
			$style_declarations->add( 'color', $color );
		}

		return $style_declarations->value();
	}

	public static function icon_font_declaration( $params ) {
		$icon_attr 	= $params['attrValue']['icon']['settings'] ?? [];
		$icon_color = $params['attrValue']['icon']['color'] ?? '';

		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
			'important'  => [
				'font-family' => true,
				'font-weight' => true,
				'color' => true,
			],
		] );
		
		if ( ! empty( $icon_attr ) ) {
			$font_family = isset( $icon_attr['type'] ) && 'fa' === $icon_attr['type'] ? 'FontAwesome' : 'ETmodules';
			$style_declarations->add( 'font-family', '"' . $font_family . '"' );

			if ( isset( $icon_attr['weight'] ) ) {
				$style_declarations->add( 'font-weight', $icon_attr['weight'] );
			}
		}

		if ( $icon_color ) {
			$style_declarations->add( 'color', $icon_color );
		}

		return $style_declarations->value();
	}

	public static function secondary_text_translation_declaration( array $args ): string {
		
		$width 			= $args['attrValue']['width'] ?? '';
		$orientation 	= $args['attrValue']['orientation'] ?? 'left';
		
		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
				'important'  => [
					'width' => true
				]
			]
		);

		if ( 'center' !== $orientation ) {
			$style_declarations->add( 'width', $width );
		} else {
			$style_declarations->add( 'width', '0' );
		}
	  	
		return $style_declarations->value();
	}

	public static function secondary_text_hover_translation_declaration( array $args ): string {
		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
			'important'  => [
				'width' => true,
			]
		] );

	  	$style_declarations->add( 'width', '0' );
	  	
		return $style_declarations->value();
	}

	
}
