<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\ButtonItem;
 */

namespace DIPL\Modules\ButtonItem;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\ButtonItem\ButtonItemTraits;

/**
 * Class Button
 *
 * @package DIPL\Modules\Button
 */
class ButtonItem implements DependencyInterface {

    use ButtonItemTraits\RenderCallbackTrait;
    use ButtonItemTraits\ModuleClassnamesTrait;
    use ButtonItemTraits\ModuleStylesTrait;
    use ButtonItemTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/button-item';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ ButtonItem::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}