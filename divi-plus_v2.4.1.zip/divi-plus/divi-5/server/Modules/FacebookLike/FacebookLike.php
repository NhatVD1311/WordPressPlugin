<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookLike;
 */

namespace DIPL\Modules\FacebookLike;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookLike\FacebookLikeTraits;

/**
 * Class FacebookLike
 *
 * @package DIPL\Modules\FacebookLike
 */
class FacebookLike implements DependencyInterface {

    use FacebookLikeTraits\RenderCallbackTrait;
    use FacebookLikeTraits\ModuleClassnamesTrait;
    use FacebookLikeTraits\ModuleStylesTrait;
    use FacebookLikeTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-like';
        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [ 'render_callback' => [ FacebookLike::class, 'render_callback' ] ]
                );
            }
        );
    }
}
