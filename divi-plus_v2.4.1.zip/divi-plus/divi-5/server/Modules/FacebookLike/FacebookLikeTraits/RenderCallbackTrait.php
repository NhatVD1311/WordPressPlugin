<?php
namespace DIPL\Modules\FacebookLike\FacebookLikeTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\FacebookLike\FacebookLike;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$plugin_options = get_option( ELICUS_DIVI_PLUS_OPTION );
		
		$app_id       = $attrs['module']['advanced']['appID']['desktop']['value'] ?? '';
		$app_id       = ! empty( $app_id ) ? $app_id : ( $plugin_options['dipl-facebook-app-id'] ?? '' );
		$url          = $attrs['module']['advanced']['pageURL']['desktop']['value'] ?? '';
		$action       = $attrs['module']['advanced']['action']['desktop']['value'] ?? 'like';
		$layout       = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'standard';
		$size         = $attrs['module']['advanced']['size']['desktop']['value'] ?? 'small';
		$share_button = $attrs['module']['advanced']['displayShareButton']['desktop']['value'] ?? 'off';
		$lazy_loading = $attrs['module']['advanced']['lazyLoading']['desktop']['value'] ?? 'off';
		$share_button = 'on' === $share_button ? true : false;
		$lazy_loading = 'on' === $lazy_loading ? true : false;

		$wrapper = HTMLUtility::render( [
				'tag'        => 'div',
				'attributes' => [
					'class' => "dipl_fb_like_button",
				],
				'children' => HTMLUtility::render( [
					'tag'        => 'div',
					'attributes' => [
						'class' => "fb-like",
						'data-href' => esc_url( $url ),
						'data-layout' => esc_attr( $layout ),
						'data-lazy' => esc_attr( $lazy_loading ),
						'data-action' => esc_attr( $action ),
						'data-size' => esc_attr( $size ),
						'data-share' => esc_attr( $share_button )
					]
				] ),
			'childrenSanitizer' => 'et_core_esc_previously',
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		if ( '' !== $app_id ) {
			wp_enqueue_script( 'facebook-sdk', 'https://connect.facebook.net/en_us/sdk.js#xfbml=1&version=v13.0&appId=' . $app_id, array('jquery'), null, true );
		}

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ FacebookLike::class, 'module_classnames' ],
			'stylesComponent'     => [ FacebookLike::class, 'module_styles' ],
			'scriptDataComponent' => [ FacebookLike::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components( [
										'attrName' => 'module',
									] ) . $wrapper,
		] );
	}
}
