<?php
namespace DIPL\Modules\BusinessHoursItem\BusinessHoursItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

trait ModuleStylesTrait {

  use CustomCssTrait;

  public static function module_styles( $args ) {
    $attrs       = $args['attrs'] ?? [];
    $order_class = $args['orderClass'];
    $elements    = $args['elements'];
    $settings    = $args['settings'] ?? [];


    Style::add(
      [
        'id'            => $args['id'],
        'name'          => $args['name'],
        'orderIndex'    => $args['orderIndex'],
        'storeInstance' => $args['storeInstance'],
        'styles'        => [
          // Element: Module.
          $elements->style(
            [
              'attrName'   => 'module',
              'styleProps' => [
                'disabledOn' => [
                  'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                ],
              ],
            ]
          ),
          CssStyle::style(
            [
              'selector'  => $order_class,
              'attr'      => $attrs['css'] ?? [],
              'cssFields' => self::custom_css(),
            ]
          ),

          CommonStyle::style(
              [
                  'selector' => "{$order_class} .dipl_business_hour_wrapper .dipl_business_day, {$order_class} .dipl_business_hour_wrapper .dipl_business_time",
                  'attr' => $attrs['module']['advanced']['fullWidth'] ?? [],
                  'declarationFunction' => function ($attrValue) {
                      $attrValue = $attrValue['attrValue'];
                      $declarations = new StyleDeclarations([
                          'returnType' => 'string',
                          'important' => 'width'
                      ]);

                      if ("on" === $attrValue) {
                          $declarations->add('width', '100%');
                      } else {
                          $declarations->add('width', '50%');
                      }

                      return $declarations->value();
                  },
              ]
          ),

          CommonStyle::style(
              [
                  'selector' => "{$order_class} .dipl_business_hour_wrapper",
                  'attr' => $attrs['module']['advanced']['fullWidth'] ?? [],
                  'declarationFunction' => function ($attrValue) {
                      $attrValue = $attrValue['attrValue'];
                      $declarations = new StyleDeclarations([
                          'returnType' => 'string',
                          'important' => 'display'
                      ]);

                      if ("on" === $attrValue) {
                          $declarations->add('display', 'block');
                      }

                      return $declarations->value();
                  },
              ]
          ),
          // Element: Day.
          $elements->style(
              [
                  'attrName' => 'day',
              ]
          ),

          // Element: Time.
          $elements->style(
              [
                  'attrName' => 'time',
              ]
          ),
        ],
      ]
    );
  }
}