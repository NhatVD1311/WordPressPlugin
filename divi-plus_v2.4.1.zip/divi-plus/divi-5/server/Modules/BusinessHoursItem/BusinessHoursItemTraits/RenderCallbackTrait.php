<?php
namespace DIPL\Modules\BusinessHoursItem\BusinessHoursItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\BusinessHoursItem\BusinessHoursItem;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
    
    public static function render_callback( $attrs, $content, $block, $elements ) {

        // Image.
        $day = $elements->render(
            [
                'attrName' => 'day',
            ]
        );


        // Title.
        $time = $elements->render(
            [
                'attrName' => 'time',
            ]
        );

        $wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => "dipl_business_hour_wrapper",
                ],
                'children'          => $day . $time,
                'childrenSanitizer' => 'et_core_esc_previously',
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        return Module::render(
          [
            // FE only.
            'orderIndex'          => $block->parsed_block['orderIndex'],
            'storeInstance'       => $block->parsed_block['storeInstance'],

            // VB equivalent.
            'attrs'               => $attrs,
            'elements'            => $elements,
            'id'                  => $block->parsed_block['id'],
            'moduleClassName'     => '',
            'name'                => $block->block_type->name,
            'classnamesFunction'  => [ BusinessHoursItem::class, 'module_classnames' ],
            'moduleCategory'      => $block->block_type->category,
            'stylesComponent'     => [ BusinessHoursItem::class, 'module_styles' ],
            'scriptDataComponent' => [ BusinessHoursItem::class, 'module_script_data' ],
            'parentAttrs'         => $parent->attrs ?? [],
            'parentId'            => $parent->id ?? '',
            'parentName'          => $parent->blockName ?? '',
            'children'            => $elements->style_components(
                        [
                            'attrName' => 'module',
                        ]
                    ) .$wrapper,
          ]
        );
    }
}
