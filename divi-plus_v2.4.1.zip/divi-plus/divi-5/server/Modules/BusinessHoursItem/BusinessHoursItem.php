<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BusinessHoursItem;
 */

namespace DIPL\Modules\BusinessHoursItem;

if ( ! defined( 'ABSPATH' ) ) {
		die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\BusinessHoursItem\BusinessHoursItemTraits;

/**
 * Class BusinessHoursItem
 *
 * @package DIPL\Modules\BusinessHoursItem
 */
class BusinessHoursItem implements DependencyInterface {

	use BusinessHoursItemTraits\RenderCallbackTrait;
	use BusinessHoursItemTraits\ModuleClassnamesTrait;
	use BusinessHoursItemTraits\ModuleStylesTrait;
	use BusinessHoursItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/business-hours-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BusinessHoursItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
