<?php
namespace DIPL\Modules\FacebookPage\FacebookPageTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\FacebookPage\FacebookPage;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$plugin_options     = get_option( ELICUS_DIVI_PLUS_OPTION );

		$app_id        = $attrs['module']['advanced']['appID']['desktop']['value'] ?? '';
		$app_id        = ! empty( $app_id ) ? $app_id : ( $plugin_options['dipl-facebook-app-id'] ?? '' );
		$url           = $attrs['module']['advanced']['pageURL']['desktop']['value'] ?? '';
		$frame_width   = $attrs['module']['advanced']['frameWidth']['desktop']['value'] ?? '280';
		$frame_height  = $attrs['module']['advanced']['frameHeight']['desktop']['value'] ?? '500';
		$show_facepile = $attrs['module']['advanced']['showFacePile']['desktop']['value'] ?? 'on';
		$hide_cover    = $attrs['module']['advanced']['hideCover']['desktop']['value'] ?? 'off';
		$small_header  = $attrs['module']['advanced']['smallHeader']['desktop']['value'] ?? 'off';
		$hide_cta      = $attrs['module']['advanced']['hideCTA']['desktop']['value'] ?? 'off';
		$lazy_loading  = $attrs['module']['advanced']['lazyLoading']['desktop']['value'] ?? 'off';
		// $tabs       = $attrs['module']['advanced']['tabs']['desktop']['value'] ?? [ 'timeline' ];
		$tabs          = dipl_process_checkboxes_string( $attrs['module']['advanced']['tabs']['desktop']['value'] ?? [ 'timeline' ], [ 'timeline' ] );

		$show_facepile = 'on' === $show_facepile ? true : false;
		$lazy_loading  = 'on' === $lazy_loading ? true : false;
		$hide_cover    = 'on' === $hide_cover ? true : false;
		$small_header  = 'on' === $small_header ? true : false;
		$hide_cta      = 'on' === $hide_cta ? true : false;
		$tabs          = implode( ',', $tabs );

		$wrapper = HTMLUtility::render( [
				'tag'        => 'div',
				'attributes' => [
					'class'  => "dipl_facebook_embedded_page",
				],
				'children'   => HTMLUtility::render( [
					'tag'        => 'div',
					'attributes' => [
						'class'              => "fb-page",
						'data-href'          => esc_url( $url ),
						'data-width'         => intval( $frame_width ),
						'data-height'        => intval( $frame_height ),
						'data-tabs'          => esc_attr( $tabs ),
						'data-lazy'          => esc_attr( $lazy_loading ),
						'data-small-header'  => esc_attr( $small_header ),
						'data-hide-cover'    => esc_attr( $hide_cover ),
						'data-show-facepile' => esc_attr( $show_facepile ),
						'data-hide-cta'      => esc_attr( $hide_cta ),
						'data-adapt-container-width' => 1
					]
				] ),
			'childrenSanitizer' => 'et_core_esc_previously',
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		if ( '' !== $app_id ) {
			wp_enqueue_script( 'facebook-sdk', 'https://connect.facebook.net/en_us/sdk.js#xfbml=1&version=v13.0&appId=' . $app_id, array('jquery'), null, true );
		}

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'classnamesFunction'  => [ FacebookPage::class, 'module_classnames' ],
			'moduleCategory'      => $block->block_type->category,
			'stylesComponent'     => [ FacebookPage::class, 'module_styles' ],
			'scriptDataComponent' => [ FacebookPage::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
				[
					'attrName' => 'module',
				]
			) . $wrapper,
		] );
	}
}
