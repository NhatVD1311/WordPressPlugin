<?php
namespace DIPL\Modules\FacebookPage\FacebookPageTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DIPL\Modules\FacebookPage\FacebookPage;

trait ModuleStylesTrait {

    use CustomCssTrait;

    public static function module_styles( $args ) {
        $attrs          = $args['attrs'] ?? [];
        $order_class    = $args['orderClass'];
        $elements       = $args['elements'];
        $settings       = $args['settings'] ?? [];

        $styles = [
            // Element: Module.
            $elements->style([
                'attrName'   => 'module',
                'styleProps' => [
                    'disabledOn' => [
                        'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
                    ],
                ],
            ]),

            $elements->style([
                'attrName'   => 'page'
            ]),

            TextStyle::style([
                'selector' => $args['orderClass'],
                'attr'     => $attrs['module']['advanced']['text'] ?? [],
            ]),

            CssStyle::style([
                'selector'  => $args['orderClass'],
                'attr'      => $attrs['css'] ?? [],
                'cssFields' => self::custom_css(),
            ])

        ];

        Style::add([
            'id'            => $args['id'],
            'name'          => $args['name'],
            'orderIndex'    => $args['orderIndex'],
            'storeInstance' => $args['storeInstance'],
            'styles'        => $styles,
        ]);
    }
}