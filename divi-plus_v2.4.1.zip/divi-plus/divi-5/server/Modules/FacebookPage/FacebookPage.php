<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookPage;
 */

namespace DIPL\Modules\FacebookPage;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookPage\FacebookPageTraits;

/**
 * Class FacebookPage
 *
 * @package DIPL\Modules\FacebookPage
 */
class FacebookPage implements DependencyInterface {

	use FacebookPageTraits\RenderCallbackTrait;
	use FacebookPageTraits\ModuleClassnamesTrait;
	use FacebookPageTraits\ModuleStylesTrait;
	use FacebookPageTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-page';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FacebookPage::class, 'render_callback' ] ]
				);
			}
		);
	}
}
