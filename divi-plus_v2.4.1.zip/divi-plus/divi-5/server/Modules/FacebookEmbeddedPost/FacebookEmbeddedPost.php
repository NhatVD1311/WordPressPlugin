<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookEmbeddedPost;
 */

namespace DIPL\Modules\FacebookEmbeddedPost;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookEmbeddedPost\FacebookEmbeddedPostTraits;

/**
 * Class FacebookEmbeddedPost
 *
 * @package DIPL\Modules\FacebookEmbeddedPost
 */
class FacebookEmbeddedPost implements DependencyInterface {

	use FacebookEmbeddedPostTraits\RenderCallbackTrait;
	use FacebookEmbeddedPostTraits\ModuleClassnamesTrait;
	use FacebookEmbeddedPostTraits\ModuleStylesTrait;
	use FacebookEmbeddedPostTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-embedded-post';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FacebookEmbeddedPost::class, 'render_callback' ] ]
				);
			}
		);
	}
}
