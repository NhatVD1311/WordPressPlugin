<?php
namespace DIPL\Modules\FacebookEmbeddedPost\FacebookEmbeddedPostTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\FacebookEmbeddedPost\FacebookEmbeddedPost;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
    public static function render_callback( $attrs, $content, $block, $elements ) {

        $plugin_options = get_option( ELICUS_DIVI_PLUS_OPTION );
        
        $app_id         = $attrs['module']['advanced']['appID']['desktop']['value'] ?? '';
        $app_id         = ! empty( $app_id ) ? $app_id : ( $plugin_options['dipl-facebook-app-id'] ?? '' );
        $url            = $attrs['module']['advanced']['postURL']['desktop']['value'] ?? '';
        $frame_width    = $attrs['module']['advanced']['frameWidth']['desktop']['value'] ?? '';
        $show_text      = $attrs['module']['advanced']['showText']['desktop']['value'] ?? 'off';
        $lazy_loading   = $attrs['module']['advanced']['lazyLoading']['desktop']['value'] ?? 'off';
        $show_text      = 'on' === $show_text ? true : false;
        $lazy_loading   = 'on' === $lazy_loading ? true : false;

        $wrapper = HTMLUtility::render(
                [
                    'tag'               => 'div',
                    'attributes'        => [
                        'class' => "dipl_fb_embedded_post_wrapper",
                    ],
                    'children'          => HTMLUtility::render(
                        [
                            'tag'               => 'div',
                            'attributes'        => [
                                'class' => "fb-post",
                                'data-href' => esc_url( $url ),
                                'data-show-text' => esc_attr( $show_text ),
                                'data-lazy' => esc_attr( $lazy_loading ),
                                'data-width' => intval( $frame_width )
                            ]
                        ]
                    ),
                'childrenSanitizer' => 'et_core_esc_previously',
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        if ( '' !== $app_id ) {
            wp_enqueue_script( 'facebook-sdk', 'https://connect.facebook.net/en_us/sdk.js#xfbml=1&version=v13.0&appId=' . $app_id, array('jquery'), null, true );
        }

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'attrs'               => $attrs,
                'elements'            => $elements,
                'id'                  => $block->parsed_block['id'],
                'moduleClassName'     => '',
                'name'                => $block->block_type->name,
                'classnamesFunction'  => [ FacebookEmbeddedPost::class, 'module_classnames' ],
                'moduleCategory'      => $block->block_type->category,
                'stylesComponent'     => [ FacebookEmbeddedPost::class, 'module_styles' ],
                'scriptDataComponent' => [ FacebookEmbeddedPost::class, 'module_script_data' ],
                'parentAttrs'         => $parent->attrs ?? [],
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $wrapper,
            ]
        );
    }
}
