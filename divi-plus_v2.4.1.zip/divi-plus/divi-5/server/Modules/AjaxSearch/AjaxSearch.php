<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\AjaxSearch;
 */
namespace DIPL\Modules\AjaxSearch;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AjaxSearch\AjaxSearchTraits;

/**
 * Class AjaxSearch
 *
 * @package DIPL\Modules\AjaxSearch
 */
class AjaxSearch implements DependencyInterface {

	use AjaxSearchTraits\RenderCallbackTrait;
	use AjaxSearchTraits\ModuleClassnamesTrait;
	use AjaxSearchTraits\ModuleStylesTrait;
	use AjaxSearchTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/ajax-search';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AjaxSearch::class, 'render_callback' ] ]
				);
			}
		);
	}
}
