<?php
namespace DIPL\Modules\AjaxSearch\AjaxSearchTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\FormField\FormFieldStyle;
use DIPL\Modules\AjaxSearch\AjaxSearch;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			// Form field style.
			FormFieldStyle::style( [
				'selector'  => "{$order_class} .dipl_ajax_search_field_wrap .dipl_ajax_search_field",
				'attr'      => $attrs['searchField'] ?? [],
			] ),

			// Loader style.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_ajax_search_loader:after",
				'attr'      => $attrs['loader']['advanced']['size'],
				'property'  => 'width',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_ajax_search_loader:after",
				'attr'      => $attrs['loader']['advanced']['size'],
				'property'  => 'height',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_ajax_search_loader:after",
				'attr'      => $attrs['loader']['advanced']['color'],
				'property'  => 'border-top-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_ajax_search_loader:after",
				'attr'      => $attrs['loader']['advanced']['color'],
				'property'  => 'border-bottom-color',
			] ),

			$elements->style( [
				'attrName' => 'resultBox',
			] ),
			$elements->style( [
				'attrName' => 'resultBox',
			] ),
			$elements->style( [
				'attrName' => 'noResult',
			] )
        );

		// Search icon size.
		$show_search_icon = $attrs['display']['advanced']['showSearchIcon']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_search_icon ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_ajax_search_icon:after",
					'attr'      => $attrs['searchIcon']['advanced']['fontSize'],
					'property'  => 'font-size',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_ajax_search_icon:after",
					'attr'      => $attrs['searchIcon']['advanced']['color'],
					'property'  => 'color',
				] )
			);
		}

		// Search icon size.
		// $display_fields = $attrs['display']['advanced']['showFields']['desktop']['value'] ?? [];
		$display_fields = dipl_process_checkboxes_string( $attrs['display']['advanced']['showFields']['desktop']['value'] ?? [], [] );
		if ( in_array( 'title', $display_fields ) ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'searchItemTitle',
			] ) );
		}
		if ( in_array( 'excerpt', $display_fields ) ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'searchItemExcerpt',
			] ) );
		}
		if ( in_array( 'product_price', $display_fields ) ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'searchItemPrice',
			] ) );
		}
		if ( in_array( 'featured_image', $display_fields ) ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'images',
			] ) );
		}

		// Scrollbar.
		$show_search_icon = $attrs['display']['advanced']['scrollbar']['desktop']['value'] ?? 'default';
		if ( 'hide' === $show_search_icon ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_ajax_search_results::-webkit-scrollbar",
					'attr'      => [ 'desktop' => [ 'value' => 'none' ] ],
					'property'  => 'display',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_ajax_search_results",
					'attr'      => [ 'desktop' => [ 'value' => 'none' ] ],
					'property'  => 'scrollbar-width',
				] )
			);
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
