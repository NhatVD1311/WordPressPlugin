<?php
namespace DIPL\Modules\AjaxSearch\AjaxSearchTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\AjaxSearch\AjaxSearch;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$placeholder       = $attrs['configurations']['advanced']['placeholder']['desktop']['value'] ?? esc_html__( 'Search', 'divi-plus' );
		$show_search_icon  = $attrs['display']['advanced']['showSearchIcon']['desktop']['value'] ?? 'on';
		$search_post_type  = $attrs['searchArea']['advanced']['includePostTypes']['desktop']['value'] ?? '';
		$url_new_window    = $attrs['module']['advanced']['linkTarget']['desktop']['value'] ?? 'off';
		$number_of_results = $attrs['configurations']['advanced']['numberOfResults']['desktop']['value'] ?? '10';
		$no_result_text    = $attrs['configurations']['advanced']['noResultText']['desktop']['value'] ?? esc_html__( 'No results found!!', 'divi-plus' );
		$order_by          = $attrs['configurations']['advanced']['orderBy']['desktop']['value'] ?? 'post_date';
		$order             = $attrs['configurations']['advanced']['order']['desktop']['value'] ?? 'DESC';
		$use_masonry       = $attrs['display']['advanced']['useMasonry']['desktop']['value'] ?? 'off';
		$number_of_columns = $attrs['display']['advanced']['numberOfColumns']['desktop']['value'] ?? '1';
		$exclude_protected = $attrs['searchArea']['advanced']['excludeProtectedPosts']['desktop']['value'] ?? 'off';
		// $display_fields = $attrs['display']['advanced']['showFields']['desktop']['value'] ?? [];
		// $search_in      = $attrs['searchArea']['advanced']['searchIn']['desktop']['value'] ?? [];
		$display_fields    = dipl_process_checkboxes_string( $attrs['display']['advanced']['showFields']['desktop']['value'] ?? [], [] );
		$search_in         = dipl_process_checkboxes_string( $attrs['searchArea']['advanced']['searchIn']['desktop']['value'] ?? [], [] );

		if ( '1' !== $number_of_columns && 'on' === $use_masonry ) {
			wp_enqueue_script( 'imagesloaded' );
			wp_enqueue_script( 'isotope' );
		}

		$search_field = sprintf(
			'<div class="dipl_ajax_search_field_wrap%1$s">
				<input type="search" class="dipl_ajax_search_field" placeholder="%2$s"
					data-search-in="%3$s" data-search-post-type="%4$s" data-display-fields="%5$s" 
					data-url-new-window="%6$s" data-number-of-results="%7$s" data-no-result-text="%8$s"
					data-orderby="%9$s" data-order="%10$s" data-use-masonry="%11$s"
					data-exclude_protected_posts="%15$s"
				/>
				<input type="hidden" class="dipl_ajax_search_nonce" value="%12$s" />
			</div>
			<div class="dipl_ajax_search_results_wrap dipl_ajax_search_result_%13$s_cols%14$s"></div>',
			( 'on' === $show_search_icon ) ? ' dipl_ajax_search_icon' : '',
			esc_html( $placeholder ),
			is_array( $search_in ) ? esc_attr( implode( ',', $search_in ) ) : $search_in,
			esc_attr( $search_post_type ),
			is_array( $display_fields ) ? esc_attr( implode( ',', $display_fields ) ) : $display_fields,
			esc_attr( $url_new_window ),
			esc_attr( $number_of_results ),
			esc_attr( $no_result_text ),
			esc_html( $order_by ),
			esc_attr( $order ),
			'1' !== $number_of_columns && 'on' === $use_masonry ? 'on' : 'off',
			wp_create_nonce( 'elicus-divi-plus-ajax-search-nonce' ),
			intval( $number_of_columns ),
			( 'featured_image' === implode( ',', $display_fields ) ) ? ' dipl_ajax_search_only_featured_image' : '',
			esc_attr( $exclude_protected )
		);

		$rendered_output = HTMLUtility::render( [
			'tag'               => 'h5',
			'attributes'        => [ 'class' => 'dipl_ajax_search_wrap' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => $search_field
		] );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AjaxSearch::class, 'module_classnames' ],
			'stylesComponent'     => [ AjaxSearch::class, 'module_styles' ],
			'scriptDataComponent' => [ AjaxSearch::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
