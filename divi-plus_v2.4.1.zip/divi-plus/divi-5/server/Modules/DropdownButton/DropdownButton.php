<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\DropdownButton;
 */
namespace DIPL\Modules\DropdownButton;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\DropdownButton\DropdownButtonTraits;

/**
 * Class DropdownButton
 *
 * @package DIPL\Modules\DropdownButton
 */
class DropdownButton implements DependencyInterface {

	use DropdownButtonTraits\RenderCallbackTrait;
	use DropdownButtonTraits\ModuleClassnamesTrait;
	use DropdownButtonTraits\ModuleStylesTrait;
	use DropdownButtonTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/dropdown-button';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ DropdownButton::class, 'render_callback' ] ]
				);
			}
		);
	}
}
