<?php
namespace DIPL\Modules\DropdownButton\DropdownButtonTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\DropdownButton\DropdownButton;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attrs.
		$trigger_type = $attrs['display']['advanced']['triggerType']['desktop']['value'] ?? 'click';
		$direction    = $attrs['display']['advanced']['dropdownDirection']['desktop']['value'] ?? 'bottom';

		$render_button = $elements->render( [
			'attrName' => 'dropdownButton',
		] );

		// Render final output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class'             => 'dipl_dropdown_button_wrap',
				'data-trigger-type' => esc_attr( $trigger_type ),
				'data-direction'    => esc_attr( $direction )
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_dropdown_button_inner">
					%1$s<div class="dipl_dropdown_menu_items">%2$s</div>
				</div>',
				et_core_esc_previously( $render_button ),
				et_core_esc_previously( $content )
			)
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ DropdownButton::class, 'module_classnames' ],
			'stylesComponent'     => [ DropdownButton::class, 'module_styles' ],
			'scriptDataComponent' => [ DropdownButton::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
