<?php
namespace DIPL\Modules\FAQPageSchema\FAQPageSchemaTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\FAQPageSchema\FAQPageSchema;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$layout           = $attrs['configuration']['advanced']['layout']['desktop']['value'] ?? "dipl_faq_accordion";
		$use_masonry      = $attrs['configuration']['advanced']['useMasonry']['desktop']['value'] ?? 'off';
		$first_active     = $attrs['configuration']['advanced']['firstActive']['desktop']['value'] ?? 'off';
		$number_of_column = $attrs['configuration']['advanced']['numberOfColumn']['desktop']['value'] ?? '1';

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );
		if ( ! empty( $title ) ) {
			$title = sprintf( '<div class="dipl_faq_title">%1$s</div>', et_core_esc_previously( $title ) );
		}

		// Wrapper class.
		$wrapper_classes = array( 'dipl_faq_wrapper', esc_attr( $layout ), "dipl_faq_col_{$number_of_column}" );
		// Accordion class.
		if ( 'dipl_faq_toggle' === $layout ) {
			$wrapper_classes[] = 'dipl_faq_accordion';
		}
		// Masonry class.
		if ( 'dipl_faq_grid' === $layout && 'on' === $use_masonry ) {
			$wrapper_classes[] = 'dipl_faq_masonry_container';
		}
		
		// Final output.
		$rendered_output = sprintf(
			'%1$s
			<div class="%2$s" %3$s itemscope itemtype="https://schema.org/FAQPage">
				%4$s
			</div>',
			et_core_esc_previously( $title ),
			esc_attr( implode( ' ', $wrapper_classes ) ),
			( 'dipl_faq_grid' !== $layout && 'on' === $first_active ) ? 'data-first_item_active="on"' : '',
			et_core_esc_previously( $content )
		);
		
		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ FAQPageSchema::class, 'module_classnames' ],
			'stylesComponent'     => [ FAQPageSchema::class, 'module_styles' ],
			'scriptDataComponent' => [ FAQPageSchema::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
