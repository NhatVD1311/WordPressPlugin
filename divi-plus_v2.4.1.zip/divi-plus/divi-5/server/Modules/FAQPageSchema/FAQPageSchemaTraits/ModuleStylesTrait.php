<?php
namespace DIPL\Modules\FAQPageSchema\FAQPageSchemaTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\FAQPageSchema\FAQPageSchema;

trait ModuleStylesTrait {

	use StyleDeclarationTrait;
	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'question',
			] ),
			$elements->style( [
				'attrName' => 'activeQuestion',
			] ),
			$elements->style( [
				'attrName' => 'answer',
			] ),

			// Accordion Background.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_faq_accordion .dipl_question_wrapper, {$order_class} .dipl_faq_grid .dipl_question_wrapper",
				'attr'      => $attrs['question']['advanced']['backgroundColor'] ?? [],
				'property'  => 'background-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_answer_wrapper, {$order_class} .dipl_faq_accordion .dipl_faq_page_schema_item.dipl_active .dipl_question_wrapper, {$order_class} .dipl_faq_grid .dipl_answer_wrapper",
				'attr'      => $attrs['answer']['advanced']['backgroundColor'] ?? [],
				'property'  => 'background-color',
			] ),
		]; 

		// Get attrs.
		$layout              = $attrs['configuration']['advanced']['layout']['desktop']['value'] ?? "dipl_faq_accordion";
		$closed_icon         = $attrs['closedIcon']['innerContent']['desktop']['value'] ?? [];
		$closed_use_fontsize = $attrs['closedIcon']['advanced']['useFontsize']['desktop']['value'] ?? "off";
		$open_icon           = $attrs['openIcon']['innerContent']['desktop']['value'] ?? [];
		$open_use_fontsize   = $attrs['openIcon']['advanced']['useFontsize']['desktop']['value'] ?? "off";

		// Close and Open Icons.
		if ( 'dipl_faq_accordion' === $layout || 'dipl_faq_toggle' === $layout ) {
			// Close state icon.
			if ( ! empty( $closed_icon['unicode'] ) ) {
				array_push( $styles, CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_faq_accordion .dipl_question_wrapper::after",
					'attr'                => $attrs['closedIcon']['innerContent'] ?? [],
					'declarationFunction' => [ FAQPageSchema::class, 'icon_font_declaration' ],
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_faq_accordion .dipl_question_wrapper::after",
					'attr'      => $attrs['closedIcon']['advanced']['color'] ?? [],
					'property'  => 'color',
				] ) );
				if ( 'on' === $closed_use_fontsize ) {
					array_push( $styles, CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_faq_accordion .dipl_question_wrapper::after",
						'attr'      => $attrs['closedIcon']['advanced']['fontsize'] ?? [],
						'property'  => 'font-size',
					] ) );
				}
			}
			// Open state icon.
			if ( ! empty( $open_icon['unicode'] ) ) {
				array_push( $styles, CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_faq_page_schema_item.dipl_active .dipl_question_wrapper::after",
					'attr'                => $attrs['openIcon']['innerContent'] ?? [],
					'declarationFunction' => [ FAQPageSchema::class, 'icon_font_declaration' ],
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_faq_page_schema_item.dipl_active .dipl_question_wrapper::after",
					'attr'      => $attrs['openIcon']['advanced']['color'] ?? [],
					'property'  => 'color',
				] ) );
				if ( 'on' === $open_use_fontsize ) {
					array_push( $styles, CommonStyle::style( [
						'selector'  => "{$order_class} .dipl_faq_page_schema_item.dipl_active .dipl_question_wrapper::after",
						'attr'      => $attrs['openIcon']['advanced']['fontsize'] ?? [],
						'property'  => 'font-size',
					] ) );
				}
			}
		}
		
		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
