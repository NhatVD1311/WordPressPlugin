<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FAQPageSchema;
 */

namespace DIPL\Modules\FAQPageSchema;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\FAQPageSchema\FAQPageSchemaTraits;

/**
 * Class FAQPageSchema
 *
 * @package DIPL\Modules\FAQPageSchema
 */
class FAQPageSchema implements DependencyInterface {

	use FAQPageSchemaTraits\RenderCallbackTrait;
	use FAQPageSchemaTraits\ModuleClassnamesTrait;
	use FAQPageSchemaTraits\ModuleStylesTrait;
	use FAQPageSchemaTraits\ModuleScriptDataTrait;
	
	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/faq-page-schema';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FAQPageSchema::class, 'render_callback' ] ]
				);
			}
		);
	}
}
