<?php
/**
 * Alert Box Module class.
 *
 * @package DIPL\Modules\AlertBox;
 */
namespace DIPL\Modules\AlertBox;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AlertBox\AlertBoxTraits;

/**
 * Class AlertBox
 *
 * @package DIPL\Modules\AlertBox
 */
class AlertBox implements DependencyInterface {

	use AlertBoxTraits\RenderCallbackTrait;
	use AlertBoxTraits\ModuleClassnamesTrait;
	use AlertBoxTraits\ModuleStylesTrait;
	use AlertBoxTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/alert-box';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AlertBox::class, 'render_callback' ] ]
				);
			}
		);
	}
}
