<?php
namespace DIPL\Modules\AlertBox\AlertBoxTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\AlertBox\AlertBox;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attributes.
		$layout            = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$use_image         = $attrs['image']['advanced']['use']['desktop']['value'] ?? 'off';
		$icon              = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
		$show_button       = $attrs['button']['advanced']['show']['desktop']['value'] ?? 'off';
		$show_close_button = $attrs['closeButton']['advanced']['show']['desktop']['value'] ?? 'on';

		// Alert Box Image.
		$image_icon = '';
		if ( 'on' === $use_image ) {
			$image_icon = $elements->render( [
				'attrName' => 'image',
			] );
		} else {
			// Icon.
			$icon = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
			if ( ! empty( $icon ) ) {
				$image_icon = HTMLUtility::render( [
					'tag'               => 'span',
					'attributes'        => [ 'class' => 'et-pb-icon' ],
					'childrenSanitizer' => 'esc_html',
					'children'          => Utils::process_font_icon( $icon ),
				] );	
			}
		}

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );

		// Render title.
		$description = $elements->render( [
			'attrName' => 'description',
		] );

		// Render button.
		$button = '';
		if ( 'on' === $show_button ) {
			$button = $elements->render( [
				'attrName' => 'button',
			] );
		}

		// Close button.
		$close_button = '';
		if ( 'on' === $show_close_button ) {
			$close_icon   = [ 'unicode' => '&#x4d;', 'type' => 'divi', 'weight' => '400' ]; // 'M' icon from Divi Icons.
			$close_button = sprintf(
				'<a href="#" class="dipl-alert-box-close-btn">
					<span class="et-pb-icon">%1$s</span>
				</a>',
				Utils::process_font_icon( $close_icon )
			);
		}

		// Alert box.
		$alert_output = '';
		if ( file_exists( get_stylesheet_directory() . '/divi-plus/layouts/alert-box/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include get_stylesheet_directory() . '/divi-plus/layouts/alert-box/' . sanitize_file_name( $layout ) . '.php';
		} elseif ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AlertBox/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AlertBox/layouts/' . sanitize_file_name( $layout ) . '.php';
		}

		// Final output.
		$rendered_output = sprintf(
			'<div class="dipl_alert_box_wrapper %1$s">%2$s</div>',
			esc_attr( $layout ),
			et_core_esc_previously( $alert_output )
		);

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AlertBox::class, 'module_classnames' ],
			'stylesComponent'     => [ AlertBox::class, 'module_styles' ],
			'scriptDataComponent' => [ AlertBox::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
