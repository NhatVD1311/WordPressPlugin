<?php
namespace DIPL\Modules\AlertBox\AlertBoxTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DIPL\Modules\AlertBox\AlertBox;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles.
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),
			TextStyle::style( [
				'selector' => "{$order_class}",
				'attr'     => $attrs['module']['advanced']['text'] ?? [],
			] ),

			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'description',
			] ),
			$elements->style( [
				'attrName' => 'image',
			] ),

			// Content align.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_alert_box_inner",
				'attr'      => $attrs['module']['advanced']['alertValign'] ?? [],
				'property'  => 'align-items',
				'important' => true,
			] ),

			// Image/Icon.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_alert_box_image_wrap .dipl-alert-box-image-icon",
				'attr'      => $attrs['image']['advanced']['backgroundColor'] ?? [],
				'property'  => 'background-color',
			] ),
		);

		// Get attributes.
		$use_image         = $attrs['image']['advanced']['use']['desktop']['value'] ?? 'off';
		$show_button       = $attrs['button']['advanced']['show']['desktop']['value'] ?? 'off';
		$show_close_button = $attrs['closeButton']['advanced']['show']['desktop']['value'] ?? 'on';

		// Icon image style.
		if ( 'on' === $use_image ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_alert_box_image_wrap.dipl-used-image img",
				'attr'      => $attrs['image']['advanced']['width'] ?? [],
				'property'  => 'width',
			] ) );
		} else {
			array_push( $styles, CommonStyle::style( [
				'selector'            => "{$order_class} .dipl_alert_box_image_wrap .et-pb-icon",
				'attr'                => $attrs['icon']['innerContent'] ?? [],
				'declarationFunction' => [ AlertBox::class, 'icon_font_declaration' ],
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_alert_box_image_wrap .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['fontsize'] ?? [],
				'property'  => 'font-size',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_alert_box_image_wrap .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['color'] ?? [],
				'property'  => 'color',
			] ) );
		}
		
		// Button.
		if ( 'on' === $show_button ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'button',
			] )	);
		}

		// Close button.
		if ( 'on' === $show_close_button ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-alert-box-close-btn .et-pb-icon",
				'attr'      => $attrs['closeButton']['advanced']['fontsize'] ?? [],
				'property'  => 'font-size',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-alert-box-close-btn .et-pb-icon",
				'attr'      => $attrs['closeButton']['advanced']['color'] ?? [],
				'property'  => 'color',
			] ) );
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
};
