<?php
/**
 * Blog Categories Module class.
 *
 * @package DIPL\Modules\BlogCategories;
 */
namespace DIPL\Modules\BlogCategories;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BlogCategories\BlogCategoriesTraits;

/**
 * Class BlogCategories
 *
 * @package DIPL\Modules\BlogCategories
 */
class BlogCategories implements DependencyInterface {

	use BlogCategoriesTraits\RenderContentTrait;
	use BlogCategoriesTraits\RenderCallbackTrait;
	use BlogCategoriesTraits\ModuleClassnamesTrait;
	use BlogCategoriesTraits\ModuleStylesTrait;
	use BlogCategoriesTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/blog-categories';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BlogCategories::class, 'render_callback' ] ]
				);
			}
		);
	}
}
