<?php
namespace DIPL\Modules\BlogCategories\BlogCategoriesTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DIPL\Modules\BlogCategories\BlogCategories;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles.
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'item',
			] ),
			$elements->style( [
				'attrName' => 'title',
			] ),
		);

		// Number of Columns.
		array_push( $styles, CommonStyle::style( [
			'selector'            => "{$order_class} .dipl_blog_categories_inner",
			'attr'                => $attrs['content']['advanced']['numberOfColumns'] ?? [],
			'declarationFunction' => function( $attrValue ) {
				$attrValue    = $attrValue['attrValue'];
				$declarations = new StyleDeclarations( [
					'returnType' => 'string',
					'important'  => 'grid-template-columns'
				] );
				$declarations->add( 'grid-template-columns', "repeat({$attrValue}, 1fr)" );

				return $declarations->value();
			}
		] ) );

		// Item gap.
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_blog_categories_inner",
			'attr'      => $attrs['content']['advanced']['itemsGap'] ?? [],
			'property'  => 'gap',
			'important' => true,
		] ) );

		// Post count.
		$show_post_count = $attrs['postCount']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_post_count ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'postCount',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_blog_category_item .dipl_blog_category_count",
				'selectors' => [ 'desktop' => [
					'value' => "{$order_class} .dipl_blog_category_item .dipl_blog_category_count",
					'hover' => "{$order_class} .dipl_blog_category_item:hover .dipl_blog_category_count"
				] ],
				'attr'      => $attrs['postCount']['advanced']['backgroundColor'] ?? [],
				'property'  => 'background',
			] ) );
		}
		
		// attribute: layout.
		$layout        = $attrs['content']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$enable_width  = $attrs['thumbnail']['advanced']['enableWidth']['desktop']['value'] ?? 'off';
		$enable_height = $attrs['thumbnail']['advanced']['enableHeight']['desktop']['value'] ?? 'off';
		if ( 'layout1' !== $layout ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'thumbnail',
			] ) );
			array_push( $styles, $elements->style( [
				'attrName' => 'itemOverlay',
			] ) );
			// Image width.
			if ( 'on' === $enable_width ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_category_item .dipl_category_image_wrapper img",
					'attr'      => $attrs['thumbnail']['advanced']['width'] ?? [],
					'property'  => 'width',
					'important' => true,
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_category_item .dipl_category_image_wrapper img",
					'attr'      => $attrs['thumbnail']['advanced']['width'] ?? [],
					'property'  => 'min-width',
					'important' => true,
				] ) );
			}
			// Image height.
			if ( 'on' === $enable_height ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_blog_category_item .dipl_category_image_wrapper img",
					'attr'      => $attrs['thumbnail']['advanced']['height'] ?? [],
					'property'  => 'height',
					'important' => true,
				] ) );
			}
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
};
