<?php
namespace DIPL\Modules\BlogCategories\BlogCategoriesTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\BlogCategories\BlogCategories;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get rest api related attrs.
		$layout               = $attrs['content']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$number_of_categories = $attrs['content']['advanced']['numberOfCategories']['desktop']['value'] ?? '10';
		$include_categories   = $attrs['content']['advanced']['includesCategories']['desktop']['value'] ?? [];
		$order_by             = $attrs['content']['advanced']['orderBy']['desktop']['value'] ?? 'name';
		$order                = $attrs['content']['advanced']['order']['desktop']['value'] ?? 'ASC';
		$hide_empty           = $attrs['content']['advanced']['hideEmpty']['desktop']['value'] ?? 'off';

		$show_post_count       = $attrs['postCount']['advanced']['show']['desktop']['value'] ?? 'on';
		$show_sup_number       = $attrs['postCount']['advanced']['showSupNumber']['desktop']['value'] ?? 'woocommerce_thumbnail';
		$post_count_text       = $attrs['postCount']['innerContent']['desktop']['value'] ?? esc_html__( 'Articles', 'divi-plus' );

		$title_level          = $attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4';

		// Get the brands item.
		$response = BlogCategories::get_blog_categories_output( array(
			'layout'               => $layout,
			'number_of_categories' => $number_of_categories,
			'include_categories'   => is_array( $include_categories ) ? implode( ',', $include_categories ) : $include_categories,
			'order_by'             => $order_by,
			'order'                => $order,
			'hide_empty'           => $hide_empty,
			'show_post_count'      => $show_post_count,
			'show_sup_number'      => $show_sup_number,
			'post_count_text'      => $post_count_text,
			'title_level'          => $title_level,
		) );
		
		$rendered_output = '';
		if ( ! empty( $response['items'] ) ) {

			// Final output.
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'childrenSanitizer' => 'et_core_esc_previously',
				'attributes'        => array(
					'class' => 'dipl_blog_categories_wrapper ' . esc_html( $layout ),
				),
				'children'          => sprintf(
					'<div class="dipl_blog_categories_inner">%s</div>',
					implode( '', $response['items'] )
				)
			] );

		} else {
			$no_result_text = $attrs['content']['advanced']['noResultText']['desktop']['value'] ?? '';
			$rendered_output = HTMLUtility::render( [
				'tag'        => 'div',
				'attributes' => [ 'class' => 'entry' ],
				'children'   => esc_html( $no_result_text )
			] );
		}

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ BlogCategories::class, 'module_classnames' ],
			'stylesComponent'     => [ BlogCategories::class, 'module_styles' ],
			'scriptDataComponent' => [ BlogCategories::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
