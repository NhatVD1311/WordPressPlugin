<?php
namespace DIPL\Modules\BlogCategories\BlogCategoriesTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {
	public static function get_blog_categories_output( $atts = array() ) {
		$defaults = array(
			'layout'               => 'layout1',
			'number_of_categories' => '10',
			'include_categories'   => '',
			'order_by'             => 'name',
			'order'                => 'ASC',
			'hide_empty'           => 'off',
			'show_post_count'      => 'on',
			'show_sup_number'      => 'off',
			'post_count_text'      => '',
			'title_level'          => 'h4',
		);
		$args = wp_parse_args( $atts, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $atts, $key, $default ) );
		}

		// Get the terms.
		$query_args = array(
			'taxonomy'   => 'category',
			'number'     => absint( $number_of_categories ),
			'orderby'    => $order_by,
			'order'      => $order,
			'include'    => $include_categories,
			'hide_empty' => ( 'on' === $hide_empty ) ? true : false,
		);
		$categories = get_terms( $query_args );

		$output_array = array();
		if ( $categories && ! is_wp_error( $categories ) ) {
			foreach ( $categories as $category ) {

				$category_link = get_category_link( $category );
				$thumbnail_id  = get_term_meta( $category->term_id, 'dipl_category_thumbnail', true );

				$image_url = '';
				if ( 'layout1' === $layout && ! empty( $thumbnail_id ) ) {
					$image_url = wp_get_attachment_image_url( $thumbnail_id, 'full' );
				}

				$category_items = sprintf(
					'<div id="dipl_blog_category_%1$s" class="dipl_blog_category_item category_%2$s" %3$s>',
					esc_attr( $category->term_id ),
					esc_attr( $category->slug ),
					( 'layout1' === $layout && ! empty( $image_url ) ) ? "style='background-image: url($image_url);'" : ''
				);
				if ( file_exists( get_stylesheet_directory() . '/divi-plus/layouts/blog-categories/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include get_stylesheet_directory() . '/divi-plus/layouts/blog-categories/' . sanitize_file_name( $layout ) . '.php';
				} elseif ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogCategories/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogCategories/layouts/' . sanitize_file_name( $layout ) . '.php';
				}
				$category_items .= '</div>';

				array_push( $output_array, $category_items );
			}
		}

		return array(
			'success' => true,
			'items'   => $output_array
		);
	}
}
