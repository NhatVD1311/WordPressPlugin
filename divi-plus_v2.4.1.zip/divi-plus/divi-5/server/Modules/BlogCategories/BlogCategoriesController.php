<?php
/**
 * Blog Categories Module Controller.
 *
 * @package DIPL\Modules\BlogCategories;
 */
namespace DIPL\Modules\BlogCategories;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Controllers\RESTController;
use ET\Builder\Framework\UserRole\UserRole;
use DIPL\Modules\BlogCategories\BlogCategories;
use WP_REST_Request;
use WP_REST_Response;


/**
 * Class BlogCategoriesController
 *
 * @package DIPL\Modules\WooProductGallery
 */
class BlogCategoriesController extends RESTController {

	/**
	 * Return data for the Dynamic Module.
	 *
	 * @param WP_REST_Request $request REST request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public static function index( WP_REST_Request $request ): WP_REST_Response {
		$args = array(
			'layout'               => $request->get_param( 'layout' ),
            'number_of_categories' => $request->get_param( 'number_of_categories' ),
			'include_categories'   => $request->get_param( 'include_categories' ),
			'order_by'             => $request->get_param( 'order_by' ),
			'order'                => $request->get_param( 'order' ),
			'hide_empty'           => $request->get_param( 'hide_empty' ),
			'show_post_count'      => $request->get_param( 'show_post_count' ),
			'show_sup_number'      => $request->get_param( 'show_sup_number' ),
			'post_count_text'      => $request->get_param( 'post_count_text' ),
			'title_level'          => $request->get_param( 'title_level' ),
		);

		$response = [
			'data' => BlogCategories::get_blog_categories_output( $args ),
		];

		return self::response_success( $response );
	}

	/**
	 * Index action arguments.
	 * Endpoint arguments as used in `register_rest_route()`.
	 *
	 * @return array
	 */
	public static function index_args(): array {
		return [
			'layout' => [
				'type'              => 'string',
				'default'           => 'layout1',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
            'number_of_categories' => [
				'type'              => 'string',
				'default'           => 10,
				'sanitize_callback' => function( $value, $request, $param ) {
					return intval( $value );
				},
			],
			'include_categories' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'order_by' => [
				'type'              => 'string',
				'default'           => 'name',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'order' => [
				'type'              => 'string',
				'default'           => 'ASC',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'hide_empty' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_post_count' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_sup_number' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'post_count_text' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'title_level' => [
				'type'              => 'string',
				'default'           => 'h4',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
		];
	}

	/**
	 * Index action permission.
	 * Endpoint permission callback as used in `register_rest_route()`.
	 *
	 * @return bool
	 */
	public static function index_permission(): bool {
		return UserRole::can_current_user_use_visual_builder();
	}
}
