<?php
namespace DIPL\Modules\DIPLListItem\ListItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Assets\DynamicAssetsUtils;
use DIPL\Modules\DIPLListItem\DIPLListItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attrs.
		$item_option_type = $attrs['image']['advanced']['option']['desktop']['value'] ?? 'use_icon';
		$icon             = $attrs['icon']['innerContent']['desktop']['value'] ?? [];
		$icon_style       = $attrs['icon']['advanced']['style']['desktop']['value'] ?? 'off';
		$icon_shape       = $attrs['icon']['advanced']['shape']['desktop']['value'] ?? 'use_square';
		$use_shape_border = $attrs['icon']['advanced']['useShapeBorder']['desktop']['value'] ?? 'off';

		// Icon or Image.
		$icon_image = '';
		if ( 'use_image' === $item_option_type ) {
			$icon_image = $elements->render( [
				'attrName' => 'image',
			] );
		} elseif ( ! empty( $icon['unicode'] ) ) {
			// Icon classes.
			$icon_classes = array( 'et-pb-icon' );
			if ( 'on' === $icon_style ) {

				$icon_classes[] = esc_attr( $icon_shape );

				// Class based on shape.
				if ( 'use_circle' === $icon_shape ) {
					$icon_classes[] = 'el-icon-circle';
				} elseif ( 'use_square' === $icon_shape ) {
					$icon_classes[] = 'el-icon-square';
				} elseif ( 'use_hexagon' === $icon_shape ) {
					$icon_classes[] = 'el-icon-hexagon';
				}

				// Icons shape and border class.
				if ( 'on' === $use_shape_border && 'use_hexagon' !== $icon_shape ) {
					$icon_classes[] = 'et-pb-icon-shape-border';
				}
			}

			// icon image.
			$icon_image = sprintf(
				'<span class="%1$s">%2$s</span>',
				implode( ' ', $icon_classes ),
				Utils::process_font_icon( $icon )
			);

			// if hexagone, wrap it.
			if ( 'on' === $icon_style && 'use_hexagon' === $icon_shape ) {
				$icon_image = sprintf(
					'<div class="hexagon-wrapper"><div class="hex">
						<div class="hexagon %1$s">%2$s</div>
					</div></div>',
					( 'on' === $use_shape_border ) ? 'et-pb-icon-shape-border' : '',
					et_core_esc_previously( $icon_image )
				);
			}

			// Wrap icon.
			$icon_image = sprintf(
				'<div class="dipl_list-icon use_icon %1$s">%2$s</div>',
				( 'on' === $icon_style ) ? esc_attr( $icon_shape ) : '',
				et_core_esc_previously( $icon_image )
			);
		}

		// Item name/text.
		$item_text = $elements->render( [
			'attrName' => 'itemText',
		] );

		// Final output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [ 'class' => 'dipl-list-item-wrap' ],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'%1$s %2$s <div class="dipl_list-divider"></div>',
				et_core_esc_previously( $icon_image ),
				et_core_esc_previously( $item_text )
			)
		] );

		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent   = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ DIPLListItem::class, 'module_classnames' ],
			'stylesComponent'     => [ DIPLListItem::class, 'module_styles' ],
			'scriptDataComponent' => [ DIPLListItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
