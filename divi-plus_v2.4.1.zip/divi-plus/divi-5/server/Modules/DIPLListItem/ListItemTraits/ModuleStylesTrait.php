<?php
namespace DIPL\Modules\DIPLListItem\ListItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\DIPLListItem\DIPLListItem;

trait ModuleStylesTrait {

	use StyleDeclarationTrait;
	use CustomCssTrait;

	/**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => ".dipl_list {$order_class}",
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'itemText',
			] ),
		];

		// Get attrs.
		$item_option_type = $attrs['image']['advanced']['option']['desktop']['value'] ?? 'use_icon';
		$icon_style       = $attrs['icon']['advanced']['style']['desktop']['value'] ?? 'off';
		$icon_shape       = $attrs['icon']['advanced']['shape']['desktop']['value'] ?? 'use_square';
		$use_shape_border = $attrs['icon']['advanced']['useShapeBorder']['desktop']['value'] ?? 'off';

		// Icon style.
		if ( 'use_icon' === $item_option_type ) {
			
			// Icon fonts.
			array_push( $styles, CommonStyle::style( [
				'selector'            => ".dipl_list {$order_class} .dipl_list-icon .et-pb-icon",
				'attr'                => $attrs['icon']['innerContent'] ?? [],
				'declarationFunction' => [ DIPLListItem::class, 'icon_font_declaration' ],
			] ) );

			// Shape icons style.
			if ( 'on' === $icon_style ) {
				// Icon color.
				array_push( $styles, CommonStyle::style( [
					'selector'  => ".dipl_list {$order_class} .dipl_list-icon .et-pb-icon",
					'attr'      => $attrs['icon']['advanced']['color'] ?? [],
					'property'  => 'color',
				] ) );
				// Hex selector.
				$hex_selector = ( 'use_hexagon' === $icon_shape ) ? '.hexagon' : '.et-pb-icon';
				array_push( $styles, CommonStyle::style( [
					'selector'  => ".dipl_list {$order_class} .dipl_list-icon " . esc_attr( $hex_selector ),
					'attr'      => $attrs['icon']['advanced']['shapeBgColor'] ?? [],
					'property'  => 'background-color',
				] ) );
				if ( 'on' === $use_shape_border ) {
					array_push( $styles, CommonStyle::style( [
						'selector'  => ".dipl_list {$order_class} .dipl_list-icon " . esc_attr( $hex_selector ),
						'attr'      => $attrs['icon']['advanced']['shapeBorderColor'] ?? [],
						'property'  => 'border-color',
					] ) );
				}
			}
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
	}
}
