<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\DIPLListItem;
 */

namespace DIPL\Modules\DIPLListItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\DIPLListItem\ListItemTraits;

/**
 * Class DIPLListItem
 *
 * @package DIPL\Modules\DIPLListItem
 */
class DIPLListItem implements DependencyInterface {

	use ListItemTraits\RenderCallbackTrait;
	use ListItemTraits\ModuleClassnamesTrait;
	use ListItemTraits\ModuleStylesTrait;
	use ListItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/dipl-list-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ DIPLListItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
