<?php
namespace DIPL\Modules\FAQPageSchemaItem\FAQPageSchemaItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\FAQPageSchemaItem\FAQPageSchemaItem;

trait ModuleStylesTrait {

	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => ".dipl_faq_page_schema {$order_class}",
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'question',
			] ),
			$elements->style( [
				'attrName' => 'answer',
			] ),
		]; 
	
		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
