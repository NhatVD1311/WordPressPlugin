<?php
namespace DIPL\Modules\FAQPageSchemaItem\FAQPageSchemaItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\FAQPageSchemaItem\FAQPageSchemaItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Render Question.
		$question = $elements->render( [
			'attrName'   => 'question',
			'attributes' => array(
				'itemprop' => 'name'
			)
		] );

		// Render Answer.
		$answer = $elements->render( [
			'attrName'   => 'answer',
			'attributes' => array(
				'itemprop' => 'text'
			)
		] );

		// Final render output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class'     => 'dipl_faq_item_wrapper',
				'itemscope' => '',
				'itemprop'  => 'mainEntity',
				'itemtype'  => 'https://schema.org/Question'
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_question_wrapper">%1$s</div>
				<div class="dipl_answer_wrapper" itemScope itemProp="acceptedAnswer" itemType="https://schema.org/Answer">
					%2$s
				</div>',
				et_core_esc_previously( $question ),
				et_core_esc_previously( $answer )
			)
		] );
	
		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent   = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ FAQPageSchemaItem::class, 'module_classnames' ],
			'stylesComponent'     => [ FAQPageSchemaItem::class, 'module_styles' ],
			'scriptDataComponent' => [ FAQPageSchemaItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
