<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BlogSlider;
 */

namespace DIPL\Modules\BlogSlider;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BlogSlider\BlogSliderTraits;

/**
 * Class BlogSlider
 *
 * @package DIPL\Modules\BlogSlider
 */
class BlogSlider implements DependencyInterface {

    use BlogSliderTraits\RenderCallbackTrait;
    use BlogSliderTraits\RenderContentTrait;
    use BlogSliderTraits\ModuleClassnamesTrait;
    use BlogSliderTraits\ModuleStylesTrait;
    use BlogSliderTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/blog-slider';
        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [ 'render_callback' => [ BlogSlider::class, 'render_callback' ] ]
                );
            }
        );
    }
}