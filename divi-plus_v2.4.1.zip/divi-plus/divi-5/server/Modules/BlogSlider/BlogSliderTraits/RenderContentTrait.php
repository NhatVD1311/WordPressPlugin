<?php
namespace DIPL\Modules\BlogSlider\BlogSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {
	public static function render_blog_data( $attrs =array() ) {
        $defaults = array(
			'layout'                => 'layout1',
			'posts_number'          => '10',
			'offset_number'         => '0',
			'include_categories'    => '',
			'post_order'            => 'DESC',
			'post_order_by'         => 'date',

			'post_date'             => 'M j, Y',
			'show_content'          => 'off',
			'excerpt_length'        => '200',
			'ignore_sticky_posts'   => 'off',
			'show_title'            => 'on',
			'show_thumbnail'        => 'on',
			'featured_image_size'   => 'large',
			'show_author'           => 'on',
			'show_date'             => 'on',
			'show_categories'       => 'on',
			'show_comments'         => 'on',
			'show_read_more'        => 'on',
			'read_more_text'        => esc_html__( 'Read More', 'divi-plus' ),
			'processed_title_level' => 'h2',
		);

		$attrs = wp_parse_args( $attrs, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $attrs, $key, $default ) );
		}
		
		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => intval( $posts_number ),
			'post_status'    => 'publish',
			'offset'         => 0,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( is_user_logged_in() ) {
			$args['post_status'] = array( 'publish', 'private' );
		}
		if ( 'on' === $ignore_sticky_posts ) {
			$args['ignore_sticky_posts'] = true;
		}
		if ( ! empty( $include_categories ) ) {
			$args['cat'] = sanitize_text_field( $include_categories );
		}
		if ( ! empty( $offset_number ) ) {
			$args['offset'] = intval( $offset_number );
		}
		if ( ! empty( $args['offset'] ) && -1 === intval( $args['posts_per_page'] ) ) {
			$count_posts            = wp_count_posts( 'post', 'readable' );
			$published_posts        = $count_posts->publish;
			$args['posts_per_page'] = intval( $published_posts );
		}
		if ( ! empty( $post_order_by ) ) {
			$args['orderby'] = sanitize_text_field( $post_order_by );
		}
		if ( ! empty( $post_order ) ) {
			$args['order'] = sanitize_text_field( $post_order );
		}
		if ( is_single() && ! isset( $args['post__not_in'] ) ) {
			$args['post__not_in'] = array( intval( get_the_ID() ) );
		}

		global $wp_the_query;
		$query_backup = $wp_the_query; // phpcs:ignore WordPress,Variables,GlobalVariables,OverrideProhibited.

		$query = new WP_Query( $args );

		$output_array = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();

				$post_id = get_the_ID();

				$read_more_button = sprintf(
					'<a href="%1$s" class="et_pb_button">%2$s</a>',
					esc_url( get_permalink( $post_id ) ),
					et_core_esc_previously( $read_more_text )
				);
				
				$thumb          = dipl_get_post_thumbnail( $post_id, esc_html( $featured_image_size ), 'dipl_blog_slider_post_image' );
				$no_thumb_class = ( '' === $thumb || 'off' === $show_thumbnail ) ? ' dipl_blog_slider_no_thumb' : '';

				$post_classes   = array_map( 'sanitize_html_class', get_post_class( 'dipl_blog_slider_post' . $no_thumb_class ) );
				$post_classes   = implode( ' ', $post_classes );

				$output = '';
				if ( file_exists( get_stylesheet_directory() . '/divi-plus/blog-slider/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include get_stylesheet_directory() . '/divi-plus/blog-slider/layouts/' . sanitize_file_name( $layout ) . '.php';
				} elseif ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogSlider/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include ( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/BlogSlider/layouts/' . sanitize_file_name( $layout ) . '.php' );
				}

				array_push( $output_array, $output );
			}
			wp_reset_postdata();

			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited.
			$wp_the_query = $query_backup; // phpcs:ignore WordPress,Variables,GlobalVariables,OverrideProhibited.
		}

		return array(
			'success' => true,
			'items'   => $output_array,
		);
	}
}
