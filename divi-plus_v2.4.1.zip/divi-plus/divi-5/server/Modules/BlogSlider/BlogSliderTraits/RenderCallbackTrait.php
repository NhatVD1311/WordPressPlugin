<?php
namespace DIPL\Modules\BlogSlider\BlogSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\BlogSlider\BlogSlider;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attrs.
		$layout                 = $attrs['content']['advanced']['layout']['desktop']['value'] ?? 'layout1';

		$include_categories_arr = $attrs['content']['advanced']['includeCategories']['desktop']['value'] ?? [];
		$include_categories     = is_array( $include_categories_arr ) ? implode( ',', $include_categories_arr ) : $include_categories_arr;

		$args = array(
			'layout'              => esc_attr( $layout ),
			'posts_number'        => $attrs['content']['advanced']['postsNumber']['desktop']['value'] ?? '10',
			'offset_number'       => $attrs['content']['advanced']['offsetNumber']['desktop']['value'] ?? '0',
			'include_categories'  => $include_categories,
			'post_order'          => $attrs['content']['advanced']['postOrderBy']['desktop']['value'] ?? 'DESC',
			'post_order_by'       => $attrs['content']['advanced']['postOrder']['desktop']['value'] ?? 'date',
			
			'post_date'           => $attrs['elements']['advanced']['postDate']['desktop']['value'] ?? 'M j, Y',
			'show_content'        => $attrs['elements']['advanced']['showContent']['desktop']['value'] ?? 'off',
			'excerpt_length'      => $attrs['elements']['advanced']['excerptLength']['desktop']['value'] ?? '200',
			'ignore_sticky_posts' => $attrs['elements']['advanced']['ignoreStickyPosts']['desktop']['value'] ?? 'off',
			'show_title'          => $attrs['elements']['advanced']['showTitle']['desktop']['value'] ?? 'on',
			'show_thumbnail'      => $attrs['elements']['advanced']['showThumbnail']['desktop']['value'] ?? 'on',
			'featured_image_size' => $attrs['elements']['advanced']['featuredImageSize']['desktop']['value'] ?? 'large',
			'show_author'         => $attrs['elements']['advanced']['showAuthor']['desktop']['value'] ?? 'on',
			'show_date'           => $attrs['elements']['advanced']['showDate']['desktop']['value'] ?? 'on',
			'show_categories'     => $attrs['elements']['advanced']['showCategories']['desktop']['value'] ?? 'on',
			'show_comments'       => $attrs['elements']['advanced']['showComments']['desktop']['value'] ?? 'on',
			'show_read_more'      => $attrs['readMore']['advanced']['show']['desktop']['value'] ?? 'on',
			'read_more_text'      => $attrs['readMore']['innerContent']['desktop']['value']['text'] ?? esc_html__( 'Read More','divi-plus' ),
		);

		// Get output.
		$response = BlogSlider::render_blog_data( $args );

		$rendered_output = '';
		if ( ! empty( $response['items'] ) ) {

			// Get the items.
			$render_items = '';
			foreach ( $response['items'] as $key => $item ) {
				$render_items .= sprintf(
					'<div class="dipl_blog_post_slide swiper-slide">%1$s</div>',
					et_core_esc_previously( $item )
				);
			}

			// Other attrs.
			$show_arrow        = $attrs['sliderArrows']['advanced']['show']['desktop']['value'] ?? 'on';
			$show_control_dot  = $attrs['slider']['advanced']['showControlDot']['desktop']['value'] ?? 'on';
			$control_dot_style = $attrs['slider']['advanced']['controlDotStyle']['desktop']['value'] ?? 'solid_dot';

			$prev_icon         = $attrs['sliderArrows']['advanced']['previousIcon']['desktop']['value'] ?? [];
			$next_icon         = $attrs['sliderArrows']['advanced']['nextIcon']['desktop']['value'] ?? [];

			$arrows_wrapper = '';
			$control_dots   = '';
			if ( 'on' === $show_arrow ) {
				$prev_arrow = sprintf(
					'<div class="swiper-button-prev" data-next_slide_arrow="%1$s"></div>',
					Utils::process_font_icon( $prev_icon )
				);
				$next_arrow = sprintf(
					'<div class="swiper-button-next" data-next_slide_arrow="%1$s"></div>',
					Utils::process_font_icon( $next_icon )
				);

				$arr_pos = $attrs['sliderArrows']['advanced']['position'] ?? [];
				$arrows_wrapper = sprintf( 
					'<div class="dipl_swiper_navigation" %3$s%4$s%5$s>%1$s%2$s</div>',
					$next_arrow,
					$prev_arrow,
					! empty( $arr_pos['desktop']['value'] ) ? sprintf( 'data-arrows_desktop="%1$s"', $arr_pos['desktop']['value'] ) : '',
					! empty( $arr_pos['tablet']['value'] ) ? sprintf( 'data-arrows_tablet="%1$s"', $arr_pos['tablet']['value'] ) : '',
					! empty( $arr_pos['phone']['value'] ) ? sprintf( 'data-arrows_phone="%1$s"', $arr_pos['phone']['value'] ) : ''
				);
			}
			if ( 'on' === $show_control_dot ) {
				$control_dots = sprintf(
					'<div class="dipl_swiper_pagination"><div class="swiper-pagination %1$s"></div></div>',
					esc_attr( $control_dot_style )
				);
			}

			// Final output.
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'childrenSanitizer' => 'et_core_esc_previously',
				'attributes'        => array_merge( [
					'class' => 'dipl_swiper_wrapper ' . esc_attr( $layout ),
				], self::get_wrapper_slider( $attrs ) ),
				'children'          => sprintf(
					'<div class="dipl_blog_slider_container dipl_swiper_inner_wrap">
						<div class="swiper-container">
							<div class="swiper-wrapper">%1$s</div>
						</div><!-- /.swiper-container -->
						%2$s
					</div>%3$s',
					et_core_esc_previously( $render_items ),
					et_core_esc_previously( $arrows_wrapper ),
					et_core_esc_previously( $control_dots )
				)
			] );
		} else {
			$no_result_text = $attrs['content']['advanced']['noResultText']['desktop']['value'] ?? '';
			$rendered_output = HTMLUtility::render( [
				'tag'        => 'div',
				'attributes' => [ 'class' => 'entry' ],
				'children'   => esc_html( $no_result_text )
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ BlogSlider::class, 'module_classnames' ],
			'stylesComponent'     => [ BlogSlider::class, 'module_styles' ],
			'scriptDataComponent' => [ BlogSlider::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}

	/**
	 * Wrapper attributes.
	 */
	public static function get_wrapper_slider( $attrs ) {

		$per_slide            = $attrs['slider']['advanced']['perSlide'];
		$per_slide_desktop    = ! empty( $per_slide['desktop']['value'] ) ? $per_slide['desktop']['value'] : '3';
		$per_slide_tablet     = ! empty( $per_slide['tablet']['value'] ) ? $per_slide['tablet']['value'] : $per_slide_desktop;
		$per_slide_phone      = ! empty( $per_slide['phone']['value'] ) ? $per_slide['phone']['value'] : $per_slide_tablet;

		$per_group            = $attrs['slider']['advanced']['perGroup'];
		$per_group_desktop    = ! empty( $per_group['desktop']['value'] ) ? $per_group['desktop']['value'] : '1';
		$per_group_tablet     = ! empty( $per_group['tablet']['value'] ) ? $per_group['tablet']['value'] : $per_group_desktop;
		$per_group_phone      = ! empty( $per_group['phone']['value'] ) ? $per_group['phone']['value'] : $per_group_tablet;

		$space_slides         = $attrs['slider']['advanced']['spaceBetweenSlides'];
		$space_slides_desktop = ! empty( $space_slides['desktop']['value'] ) ? $space_slides['desktop']['value'] : '20px';
		$space_slides_tablet  = ! empty( $space_slides['tablet']['value'] ) ? $space_slides['tablet']['value'] : $space_slides_desktop;
		$space_slides_phone   = ! empty( $space_slides['phone']['value'] ) ? $space_slides['phone']['value'] : $space_slides_tablet;

		return array(
			'data-slide_effect'                => $attrs['slider']['advanced']['slideEffect']['desktop']['value'] ?? 'slide',
			'data-enable_coverflow_shadow'     => $attrs['slider']['advanced']['enableCoverflowShadow']['desktop']['value'] ?? 'off',
			'data-coverflow_rotate'            => $attrs['slider']['advanced']['coverflowRotate']['desktop']['value'] ?? '40',
			'data-coverflow_depth'             => $attrs['slider']['advanced']['coverflowDepth']['desktop']['value'] ?? '100',
			'data-auto_height_slider'          => $attrs['slider']['advanced']['autoHeightSlider']['desktop']['value'] ?? 'off',

			'data-show_arrow'                  => $attrs['sliderArrows']['advanced']['show']['desktop']['value'] ?? 'on',
			'data-show_control_dot'            => $attrs['slider']['advanced']['showControlDot']['desktop']['value'] ?? 'on',
			'data-slider_loop'                 => $attrs['slider']['advanced']['sliderLoop']['desktop']['value'] ?? 'off',
			'data-autoplay'                    => $attrs['slider']['advanced']['autoplay']['desktop']['value'] ?? 'on',
			'data-autoplay_speed'              => $attrs['slider']['advanced']['autoplaySpeed']['desktop']['value'] ?? '3000',
			'data-transition_duration'         => $attrs['slider']['advanced']['transitionDuration']['desktop']['value'] ?? '1000',
			'data-pause_on_hover'              => $attrs['slider']['advanced']['pauseOnHover']['desktop']['value'] ?? 'on',
			'data-enable_dynamic_dots'         => $attrs['slider']['advanced']['enableDynamicDots']['desktop']['value'] ?? 'off',

			'data-per_view'                    => $per_slide_desktop,
			'data-per_view_tablet'             => $per_slide_tablet,
			'data-per_view_phone'              => $per_slide_phone,
			'data-per_group'                   => $per_group_desktop,
			'data-per_group_tablet'            => $per_group_tablet,
			'data-per_group_phone'             => $per_group_phone,
			'data-space_between_slides'        => $space_slides_desktop,
			'data-space_between_slides_tablet' => $space_slides_tablet,
			'data-space_between_slides_phone'  => $space_slides_phone
		);
	}
}
