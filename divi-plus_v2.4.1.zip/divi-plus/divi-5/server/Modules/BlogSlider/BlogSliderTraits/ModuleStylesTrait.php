<?php
namespace DIPL\Modules\BlogSlider\BlogSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DIPL\Modules\BlogSlider\BlogSlider;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $args['orderClass'],
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'sliderContainer',
			] ),
			$elements->style( [
				'attrName' => 'postContent',
			] ),
			$elements->style( [
				'attrName' => 'body',
			] ),
			$elements->style( [
				'attrName' => 'metaText',
			] ),
			$elements->style( [
				'attrName' => 'singlePost',
			] ),
		];

		$layout     = $attrs['content']['advanced']['layout']['desktop']['value'] ?? 'layout1';

		// Title.
		$show_title = $attrs['elements']['advanced']['showTitle']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_title ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'title',
			] ) );
		}

		// Read more button.
		$show_read_more = $attrs['readMore']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_read_more ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'readMore',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_read_more_link",
				'attr'     => $attrs['readMore']['decoration']['sizing'] ?? [],
				'declarationFunction' => function( $attrValue ) {
					if ( ! empty( $attrValue['attrValue']['alignment'] ) ) {
						return "text-align: {$attrValue['attrValue']['alignment']};";
					}
					return '';
				}
			] ) );
		}

		// Thumbnail/image.
		$show_thumbnail = $attrs['elements']['advanced']['showThumbnail']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_thumbnail ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'image',
			] ) );
			// Image height.
			if ( 'layout3' === $layout ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .layout3 .dipl_blog_slider_image_wrapper",
					'attr'     => $attrs['image']['advanced']['height'] ?? [],
					'property' => 'height'
				] ) );
			}
		}

		// Meta icon.
		if ( 'layout2' === $layout || 'layout3' === $layout || 'layout4' === $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_meta .et-pb-icon",
				'attr'     => $attrs['metaIcon']['advanced']['fontsize'] ?? [],
				'property' => 'font-size'
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_meta .et-pb-icon",
				'attr'     => $attrs['metaIcon']['advanced']['color'] ?? [],
				'property' => 'color'
			] ) );
			// Comment meta icon.
			if ( 'layout4' === $layout ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .layout4 .dipl_blog_slider_meta .comments .et-pb-icon",
					'attr'     => $attrs['metaIcon']['advanced']['commentIconFontsize'] ?? [],
					'property' => 'font-size'
				] ) );
			}
		}

		// Categories.
		$show_categories = $attrs['elements']['advanced']['showCategories']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_categories ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'category',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_post_categories a",
				'attr'     => $attrs['category']['advanced']['backgroundColor'] ?? [],
				'declarationFunction' => function ($attr) {
					$attrValue    = $attr['attrValue'];
					$declarations = new StyleDeclarations( [
						'returnType' => 'string',
						'important' => [
							'background-color' => $attrValue
						]
					] );
					if ( ! empty( $attrValue ) ) {
						$declarations->add( 'background-color', esc_attr( $attrValue ) );
						$declarations->add( 'padding', '2px 4px' );
						$declarations->add( 'margin', '0 2px 5px 0' );
					}
					return $declarations->value();
				}
			] ) );
		}

		// Meta separator.
		if ( 'layout3' === $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .layout3 .dipl_blog_slider_meta",
				'attr'     => $attrs['postContent']['advanced']['metaSeparatorColor'] ?? [],
				'property' => 'border-top-color'
			] ) );
		}

		// Equalize slide height.
		$equal_height = $attrs['slider']['advanced']['equalHeight']['desktop']['value'] ?? 'on';
		$per_slide    = $attrs['slider']['advanced']['perSlide']['desktop']['value'] ?? '3';
		if ( 'on' === $equal_height ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .swiper-wrapper",
				'attr'     => [ 'desktop' => [ 'value' => 'stretch' ] ],
				'property' => 'align-items',
				'important' => true,
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .swiper-slide",
				'attr'     => [ 'desktop' => [ 'value' => 'auto' ] ],
				'property' => 'height',
				'important' => true,
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_post",
				'attr'     => [ 'desktop' => [ 'value' => '100%' ] ],
				'property' => 'height',
				'important' => true,
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_slider_read_more_link",
				'attr'     => $attrs['slider']['advanced']['equalHeight'] ?? [],
				'declarationFunction' => function ($attr) {
					return 'display: flex; align-items: flex-end; flex-grow: 1;';
				}
			] ) );
		} elseif ( 1 === intval( $per_slide ) ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .swiper-wrapper",
				'attr'     => [ 'desktop' => [ 'value' => 'center' ] ],
				'property' => 'align-items',
				'important' => true,
			] ) );
		}

		// Check show arrows.
		$show_arrow = $attrs['sliderArrows']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_arrow ) {
			array_push( $styles,
				$elements->style( [
					'attrName' => 'sliderArrows',
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-prev:after",
					'attr'                => $attrs['sliderArrows']['advanced']['previousIcon'] ?? [],
					'declarationFunction' => [ BlogSlider::class, 'icon_font_declaration' ]
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-next:after",
					'attr'                => $attrs['sliderArrows']['advanced']['nextIcon'] ?? [],
					'declarationFunction' => [ BlogSlider::class, 'icon_font_declaration' ]
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev:after, {$order_class} .dipl_swiper_navigation .swiper-button-next:after",
					'attr'     => $attrs['sliderArrows']['advanced']['fontsize'] ?? [],
					'property' => 'font-size'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'     => $attrs['sliderArrows']['advanced']['color'] ?? [],
					'property' => 'color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'     => $attrs['sliderArrows']['advanced']['backgroundColor'] ?? [],
					'property' => 'background'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'     => $attrs['sliderArrows']['advanced']['borderSize'] ?? [],
					'property' => 'border-width'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'     => $attrs['sliderArrows']['advanced']['borderRadius'] ?? [],
					'property' => 'border-radius'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'     => $attrs['sliderArrows']['advanced']['borderColor'] ?? [],
					'property' => 'border-color'
				] ),
			);
			$show_arrow_on_hover = $attrs['sliderArrows']['advanced']['showOnHover']['desktop']['value'] ?? 'off';
			if ( 'on' === $show_arrow_on_hover ) {
				array_push( $styles,
					CommonStyle::style( [
						'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
						'attr'                => $attrs['sliderArrows']['advanced']['showOnHover'],
						'declarationFunction' => function() {
							return "visibility: hidden; opacity: 0; transition: all 300ms ease;";
						}
					] ),
					CommonStyle::style( [
						'selector'            => "{$order_class}:hover .dipl_swiper_navigation .swiper-button-prev, {$order_class}:hover .dipl_swiper_navigation .swiper-button-next",
						'attr'                => $attrs['sliderArrows']['advanced']['showOnHover'],
						'declarationFunction' => function() {
							return "visibility: visible; opacity: 1;";
						}
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_swiper_navigation .swiper-button-prev.swiper-button-disabled, {$order_class}:hover .dipl_swiper_navigation .swiper-button-next.swiper-button-disabled",
						'attr'     => [ 'desktop' => [ 'value' => '0.35' ] ],
						'property' => 'opacity'
					] ),
					// Outside Slider.
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_outside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '50px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_outside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '50px' ] ],
						'property' => 'right'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_outside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '0' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_outside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '0' ] ],
						'property' => 'right'
					] ),
					// Inside Slider.
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_inside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '-50px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_inside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '-50px' ] ],
						'property' => 'right'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_inside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '0' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_inside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '0' ] ],
						'property' => 'right'
					] )
				);
			}
		}

		// Pagination CSS.
		$show_control_dot    = $attrs['slider']['advanced']['showControlDot']['desktop']['value'] ?? 'on';
		$control_dot_style   = $attrs['slider']['advanced']['controlDotStyle']['desktop']['value'] ?? 'solid_dot';
		$transition_duration = $attrs['slider']['advanced']['transitionDuration']['desktop']['value'] ?? '1000';
		$enable_dynamic_dots = $attrs['slider']['advanced']['enableDynamicDots']['desktop']['value'] ?? 'off';
		if ( 'on' === $show_control_dot ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_pagination .swiper-pagination-bullet",
					'attr'     => $attrs['slider']['advanced']['controlDotInActiveColor'],
					'property' => 'background'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .transparent_dot .swiper-pagination-bullet",
					'attr'     => $attrs['slider']['advanced']['controlDotInActiveColor'],
					'property' => 'border-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_swiper_pagination .swiper-pagination-bullet-active",
					'attr'     => $attrs['slider']['advanced']['controlDotActiveColor'],
					'property' => 'background'
				] )
			);
			if ( 'stretched_dot' === $control_dot_style ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .stretched_dot .swiper-pagination-bullet",
					'attr'     => [ 'desktop' => [ 'value' => sprintf( 'all %1$sms ease', $transition_duration ) ] ],
					'property' => 'transition'
				] ) );
			}
			if ( 'off' === $enable_dynamic_dots ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .swiper-pagination-bullets-dynamic .swiper-pagination-bullet",
					'attr'     => [ 'desktop' => [ 'value' => 'scale(1)' ] ],
					'property' => 'transform'
				] ) );
			}
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .swiper-pagination .swiper-pagination-bullet.number-bullet",
				'attr'     => $attrs['slider']['advanced']['numberDotTextColor'] ?? [],
				'property' => 'color'
			] ) );
		}

		// Coverflow slider effect.
		$enable_coverflow_shadow = $attrs['slider']['advanced']['enableCoverflowShadow']['desktop']['value'] ?? 'off';
		$coverflow_shadow_color  = $attrs['slider']['advanced']['coverflowShadowColor']['desktop']['value'] ?? '#cccccc';
		if ( 'on' === $enable_coverflow_shadow ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'  => "{$order_class} .swiper-container-3d .swiper-slide-shadow-left",
					'attr'      => [ 'desktop' => [ 'value' => sprintf( 'linear-gradient( to left, %1$s, rgba(0,0,0,0) )', $coverflow_shadow_color ) ] ],
					'property'  => 'background-image',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .swiper-container-3d .swiper-slide-shadow-right",
					'attr'      => [ 'desktop' => [ 'value' => sprintf( 'linear-gradient( to right, %1$s, rgba(0,0,0,0) )', $coverflow_shadow_color ) ] ],
					'property'  => 'background-image',
				] )
			);
		} else {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .swiper-container-3d .swiper-slide-shadow-left, {$order_class} .swiper-container-3d .swiper-slide-shadow-right",
				'attr'      => [ 'desktop' => [ 'value' => 'none' ] ],
				'property'  => 'background-image',
			] ) );
		}

		// Linear transition.
		$enable_linear_transition = $attrs['slider']['advanced']['enableLinearTransition']['desktop']['value'] ?? 'off';
		if ( 'on' === $enable_linear_transition ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .swiper-wrapper",
				'attr'      => [ 'desktop' => [ 'value' => 'linear' ] ],
				'property'  => 'transition-timing-function',
			] ) );
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
