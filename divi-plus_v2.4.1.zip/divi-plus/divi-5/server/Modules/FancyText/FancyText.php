<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FancyText;
 */

namespace DIPL\Modules\FancyText;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FancyText\FancyTextTraits;

/**
 * Class FancyText
 *
 * @package DIPL\Modules\FancyText
 */
class FancyText implements DependencyInterface {

    use FancyTextTraits\RenderCallbackTrait;
    use FancyTextTraits\ModuleClassnamesTrait;
    use FancyTextTraits\ModuleStylesTrait;
    use FancyTextTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/fancy-text';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [ 'render_callback' => [ FancyText::class, 'render_callback' ] ]
                );
            }
        );
    }
}