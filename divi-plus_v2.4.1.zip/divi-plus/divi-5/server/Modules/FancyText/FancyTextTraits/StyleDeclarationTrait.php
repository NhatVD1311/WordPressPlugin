<?php
namespace DIPL\Modules\FancyText\FancyTextTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

trait StyleDeclarationTrait {

	public static function gradient_declaration( array $args ): string {
		$attr_value 	= $args['attrValue'] ?? '';
		$default_attrs  = ModuleRegistration::get_default_attrs( 'dipl/fancy-text', 'default' );

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);

		$type 				= $attr_value['type'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['type'];
		$colorOne 			= $attr_value['colorOne'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['colorOne'];
		$colorTwo 			= $attr_value['colorTwo'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['colorTwo'];
		$linearDirection 	= $attr_value['linearDirection'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['linearDirection'];
        $radialDirection 	= $attr_value['radialDirection'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['radialDirection'];
        $startPosition 		= $attr_value['startPosition'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['startPosition'];
        $endPosition 		= $attr_value['endPosition'] ?? $default_attrs['fancyText']['advanced']['gradient']['desktop']['value']['endPosition'];
  		
	  	switch( $type ) {
	  		case 'linear-gradient':
	  			$style_declarations->add( 'background-image', "linear-gradient({$linearDirection}, {$colorOne} {$startPosition}, {$colorTwo} {$endPosition})" );
	  			break;

	  		case 'radial-gradient':
	  			$style_declarations->add( 'background-image', "radial-gradient({$radialDirection}, {$colorOne} {$startPosition}, {$colorTwo} {$endPosition})" );
	  			break;

	  		default:
	  			break;
	  	}

		return $style_declarations->value();
	}

	public static function background_declaration( array $args ): string {
		$attr_value = $args['attrValue'] ?? '';
		$style_declarations = new StyleDeclarations( [
			'returnType' => 'string',
		] );

		$url      = $attr_value['url'];
		$size     = $attr_value['size'];
		$position = $attr_value['position'];
		$repeat   = $attr_value['repeat'];

		$url      = ( is_array( $url ) && ! empty( $url['src'] ) ) ? $url['src'] : $url;
  	
	  	$style_declarations->add( 'background-image', "url({$url})" );
	  	$style_declarations->add( 'background-size', $size );
		$style_declarations->add( 'background-position', $position );
		$style_declarations->add( 'background-repeat', $repeat );

		return $style_declarations->value();
	}

	public static function overlay_background_declaration( array $args ): string {
		$attr_value = $args['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);

		$style_declarations->add( 'content', '\'\'' );
	  	$style_declarations->add( 'background-size', 'inherit' );
		$style_declarations->add( 'background-position', 'inherit' );
		$style_declarations->add( 'background-repeat', 'inherit' );

		return $style_declarations->value();
	}

	public static function overlay_declaration( array $args ): string {
		$attr_value 	= $args['attrValue'] ?? '';
		$default_attrs  = ModuleRegistration::get_default_attrs( 'dipl/fancy-text', 'default' );

		$style_declarations = new StyleDeclarations(
			[
				'returnType' => 'string',
			]
		);

		$style 				= $attr_value['style'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['style'];
		$color 				= $attr_value['color'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['color'];
		$type 				= $attr_value['type'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['type'];
		$colorOne 			= $attr_value['colorOne'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['colorOne'];
		$colorTwo 			= $attr_value['colorTwo'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['colorTwo'];
		$linearDirection 	= $attr_value['linearDirection'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['linearDirection'];
        $radialDirection 	= $attr_value['radialDirection'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['radialDirection'];
        $startPosition 		= $attr_value['startPosition'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['startPosition'];
        $endPosition 		= $attr_value['endPosition'] ?? $default_attrs['fancyText']['advanced']['overlay']['desktop']['value']['endPosition'];
	  	
	  	if ( 'gradient' === $style ) {
	  		switch( $type ) {
		  		case 'linear-gradient':
		  			$style_declarations->add( 'background-image', "linear-gradient({$linearDirection}, {$colorOne} {$startPosition}, {$colorTwo} {$endPosition})" );
		  			break;

		  		case 'radial-gradient':
		  			$style_declarations->add( 'background-image', "radial-gradient({$radialDirection}, {$colorOne} {$startPosition}, {$colorTwo} {$endPosition})" );
		  			break;

		  		default:
		  			break;
		  	}
	  	}

	  	if ( 'color' === $style ) {
	  		$style_declarations->add( 'background-color', $color );
	  	}

	  	if ( 'none' !== $style ) {
	  		$style_declarations->add( 'content', '\'\'' );
	  	}

		return $style_declarations->value();
	}
}
