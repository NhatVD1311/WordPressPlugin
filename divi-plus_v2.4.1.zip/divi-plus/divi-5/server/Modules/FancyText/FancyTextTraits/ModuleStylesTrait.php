<?php
namespace DIPL\Modules\FancyText\FancyTextTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\FancyText\FancyText;

trait ModuleStylesTrait {

	use CustomCssTrait;
	use StyleDeclarationTrait;

	public static function module_styles( $args ) {
		$attrs          = $args['attrs'] ?? [];
		$order_class    = $args['orderClass'];
		$elements       = $args['elements'];
		$settings       = $args['settings'] ?? [];

		$styles = [
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $args['orderClass'],
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			// Element: Fancy Text.
			$elements->style( [
				'attrName' => 'fancyTitle',
			] ),
			$elements->style( [
				'attrName' => 'fancyText',
			] ),
		];

		$fancy_text_style = $attrs['fancyText']['advanced']['style']['desktop']['value'] ?? 'dipl_gradient';
		$background_image = $attrs['fancyText']['advanced']['clipImage']['desktop']['value']['url'] ?? '';
		$overlay_style    = $attrs['fancyText']['advanced']['overlay']['desktop']['value']['style'] ?? 'none';

		if ( 'dipl_gradient' === $fancy_text_style ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_gradient_text",
				'attr'     =>  $attrs['fancyText']['advanced']['gradient'],
				'declarationFunction' => [ FancyText::class, 'gradient_declaration' ]
			] ) );
		} else {
			if ( $background_image ) {
				array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl_clipping_text",
					'attr'     =>  $attrs['fancyText']['advanced']['clipImage'],
					'declarationFunction' => [ FancyText::class, 'background_declaration' ]
				] ) );
			}
			if ( 'none' !== $overlay_style ) {
				array_push(
					$styles,
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_clipping_text:before",
						'attr'     =>  $attrs['fancyText']['advanced']['overlay'],
						'declarationFunction' => [ FancyText::class, 'overlay_background_declaration' ]
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_clipping_text:after",
						'attr'     =>  $attrs['fancyText']['advanced']['overlay'],
						'declarationFunction' => [ FancyText::class, 'overlay_declaration' ]
					] ),
					$elements->style([
						'attrName' => 'overlaySpacing',
					] )
				);
			}
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
