<?php
namespace DIPL\Modules\FancyText\FancyTextTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\FancyText\FancyText;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;

trait RenderCallbackTrait {
    public static function render_callback( $attrs, $content, $block, $elements ) {
        
        $fancy_text_style = $attrs['fancyText']['advanced']['style']['desktop']['value'] ?? '';
        $fancy_text_style = esc_attr( $fancy_text_style );

        $fancy_text = $elements->render(
            [
                'attrName' => 'fancyText',
            ]
        );
        $fancy_text = DynamicData::get_processed_dynamic_data($fancy_text);

        $wrapper = HTMLUtility::render(
            [
                'tag'               => 'div',
                'attributes'        => [
                    'class' => $fancy_text_style,
                ],
                'children'          => HTMLUtility::render(
                    [
                        'tag'               => 'div',
                        'attributes'        => [
                            'class' => 'dipl-text-wrapper',
                        ],
                        'children'          => HTMLUtility::render(
                            [
                                'tag'               => 'div',
                                'attributes'        => [
                                    'class' => "dipl-text-wrapper-inner {$fancy_text_style}_text",
                                ],
                                'children'          => $fancy_text,
                                'childrenSanitizer' => 'et_core_esc_previously',
                            ]
                        ),
                        'childrenSanitizer' => 'et_core_esc_previously',
                    ]
                ),
                'childrenSanitizer' => 'et_core_esc_previously',
            ]
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'attrs'               => $attrs,
                'elements'            => $elements,
                'id'                  => $block->parsed_block['id'],
                'moduleClassName'     => '',
                'name'                => $block->block_type->name,
                'classnamesFunction'  => [ FancyText::class, 'module_classnames' ],
                'moduleCategory'      => $block->block_type->category,
                'stylesComponent'     => [ FancyText::class, 'module_styles' ],
                'scriptDataComponent' => [ FancyText::class, 'module_script_data' ],
                'parentAttrs'         => $parent->attrs ?? [],
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $wrapper,
            ]
        );
    }
}
