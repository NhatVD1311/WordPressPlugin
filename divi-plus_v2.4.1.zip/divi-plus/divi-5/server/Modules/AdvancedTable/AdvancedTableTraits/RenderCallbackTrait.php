<?php
namespace DIPL\Modules\AdvancedTable\AdvancedTableTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use DIPL\Modules\AdvancedTable\AdvancedTable;
use WP_Block_Type_Registry;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// Get child blocks.
		$inner_blocks = $block->parsed_block['innerBlocks'] ?? [];
		$children_ids = $inner_blocks ? array_map(
			function( $inner_block ) {
				return $inner_block['id'];
			},
			$inner_blocks
		) : [];

		$rendered_output = '';
		if ( ! empty( $inner_blocks ) ) {

			$columns_number = $attrs['configuration']['advanced']['columnsNumber']['desktop']['value'] ?? 4;

			// All rows.
			$rows = array_chunk( $inner_blocks, $columns_number );

			// Get header cells.
			$header_cells = array_shift( $rows );
			$header_attrs = array();
			$header_row   = '';
			if ( ! empty( $header_cells ) ) {
				$header_items = '';
				foreach ( $header_cells as $i => $item ) {
					$child_attrs = $item['attrs'] ?? [];

					// Get item class.
					$item_index  = isset( $item['orderIndex'] ) ? esc_attr( $item['orderIndex'] ) : 'i' . esc_attr( $i );
					$item_class  = 'dipl_advanced_table_item_' . esc_attr( $item_index );

					$header_attrs[] = array(
						'cell_value' => wpautop( wp_strip_all_tags( $child_attrs['cellText']['innerContent']['desktop']['value'] ) ) ?? '',
						'item_class' => esc_attr( $item_class )
					);

					// Render header item.
					$header_items .= sprintf(
						'<div class="dipl_advanced_table_item_cell_wrap %1$s_cell_wrap dipl-at-header-cell">
							<div class="dipl_advanced_table-row-cell">%2$s</div>
						</div>',
						esc_attr( $item_class ),
						et_core_esc_previously( render_block( $item ) )
					);
				}
				$header_row = sprintf(
					'<div class="dipl_advanced_table-row dipl-at-header-row">%1$s</div>',
					et_core_esc_previously( $header_items )
				);
			}

			// Row items.
			$item_rows = '';
			if ( ! empty( $rows ) ) {
				foreach ( $rows as $row_index => $row_cells ) {
					$row_html = '';
					foreach ( $row_cells as $cell_index => $cell ) {
						// Responsive heading (per column).
						$responsive_heading = '';
						if ( ! empty( $header_attrs[ $cell_index ]['cell_value'] ) ) {
							$responsive_heading = sprintf(
								'<div class="dipl_advanced_table_item_responsive_heading %1$s_responsive_heading">%2$s</div>',
								et_core_esc_previously( $header_attrs[ $cell_index ]['item_class'] ?? '' ),
								et_core_esc_previously( $header_attrs[ $cell_index ]['cell_value'] )
							);
						}

						// Get item class.
						$item_index  = isset( $cell['orderIndex'] ) ? esc_attr( $cell['orderIndex'] ) : 'i' . esc_attr( $i );
						$item_class  = 'dipl_advanced_table_item_' . esc_attr( $item_index );

						$row_html .= sprintf(
							'<div class="dipl_advanced_table_item_cell_wrap %1$s_cell_wrap">%2$s
								<div class="dipl_advanced_table-row-cell">%3$s</div>
							</div>',
							esc_attr( $item_class ),
							et_core_esc_previously( $responsive_heading ),
							et_core_esc_previously( render_block( $cell ) )
						);
					}
					$item_rows .= sprintf(
						'<div class="dipl_advanced_table-row">%1$s</div>',
						et_core_esc_previously( $row_html )
					);
				}
			}

			// Render final output.
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [ 'class' => 'dipl_advanced_table_wrap' ],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => sprintf(
					'%1$s %2$s',
					et_core_esc_previously( $header_row ),
					et_core_esc_previously( $item_rows )
				)
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AdvancedTable::class, 'module_classnames' ],
			'stylesComponent'     => [ AdvancedTable::class, 'module_styles' ],
			'scriptDataComponent' => [ AdvancedTable::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
