<?php
namespace DIPL\Modules\AdvancedTable\AdvancedTableTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\AdvancedTable\AdvancedTable;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 *     @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 *     @type string $name Module name.
	 *     @type string $attrs Module attributes.
	 *     @type string $parentAttrs Parent attrs.
	 *     @type string $orderClass Selector class name.
	 *     @type string $parentOrderClass Parent selector class name.
	 *     @type string $wrapperOrderClass Wrapper selector class name.
	 *     @type string $settings Custom settings.
	 *     @type string $state Attributes state.
	 *     @type string $mode Style mode.
	 *     @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'header',
			] ),
			$elements->style( [
				'attrName' => 'headerText',
			] ),

			$elements->style( [
				'attrName' => 'tableCell',
			] ),
			$elements->style( [
				'attrName' => 'tableCellText',
			] ),

			// Column spacing.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_advanced_table-row",
				'attr'      => $attrs['configuration']['advanced']['columnSpacing'] ?? [],
				'property'  => 'gap',
			] ),
			
			// Row spacing.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_advanced_table-row:not(:last-child)",
				'attr'      => $attrs['configuration']['advanced']['rowSpacing'] ?? [],
				'property'  => 'margin-bottom',
			] ),
		);

		// Columns.
		$columns_number = $attrs['configuration']['advanced']['columnsNumber']['desktop']['value'] ?? 4;
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_advanced_table-row",
			'attr'      => [ 'desktop' => [ 'value' => 'repeat(' . esc_attr( $columns_number ) . ', 1fr)' ] ],
			'property'  => 'grid-template-columns',
		] ) );
		
        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
