<?php
/**
 * Advanced Table Module class.
 *
 * @package DIPL\Modules\AdvancedTable;
 */
namespace DIPL\Modules\AdvancedTable;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AdvancedTable\AdvancedTableTraits;

/**
 * Class AdvancedTable
 *
 * @package DIPL\Modules\AdvancedTable
 */
class AdvancedTable implements DependencyInterface {

	use AdvancedTableTraits\RenderCallbackTrait;
	use AdvancedTableTraits\ModuleClassnamesTrait;
	use AdvancedTableTraits\ModuleStylesTrait;
	use AdvancedTableTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/advanced-table';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AdvancedTable::class, 'render_callback' ] ]
				);
			}
		);
	}
}
