<?php
namespace DIPL\Modules\AccordionSlider\AccordionSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use DIPL\Modules\AccordionSlider\AccordionSlider;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),
			TextStyle::style( [
				'selector' => "{$order_class}",
				'attr'     => $attrs['module']['advanced']['text'] ?? [],
			] ),

			$elements->style( [
				'attrName' => 'sliderContainer',
			] ),
			
			$elements->style( [
				'attrName' => 'item',
			] ),
			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'description',
			] ),

			// Icon.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['fontSize'] ?? [],
				'property'  => 'font-size',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_icon .et-pb-icon",
				'attr'      => $attrs['icon']['advanced']['color'] ?? [],
				'property'  => 'color',
			] ),

			// Item.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_inner",
				'attr'      => $attrs['item']['advanced']['height'] ?? [],
				'property'  => 'height',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_content",
				'attr'      => $attrs['item']['advanced']['valign'] ?? [],
				'property'  => 'justify-content',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_accordion_slider_item_content",
				'attr'      => $attrs['item']['advanced']['contentBackgroundColor'] ?? [],
				'property'  => 'background-color',
			] ),
		);

		// Slider arrows.
		$show_arrow    = $attrs['sliderArrows']['advanced']['show']['desktop']['value'] ?? 'off';
		$show_on_hover = $attrs['sliderArrows']['advanced']['showOnHover']['desktop']['value'] ?? 'off';
		if ( 'on' === $show_arrow ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'sliderArrows',
			] ) );
			array_push( $styles,
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-prev::after",
					'attr'                => $attrs['sliderArrows']['advanced']['previousArrow'] ?? [],
					'declarationFunction' => [ AccordionSlider::class, 'icon_font_declaration' ],
				] ),
				CommonStyle::style( [
					'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-next::after",
					'attr'                => $attrs['sliderArrows']['advanced']['nextArrow'] ?? [],
					'declarationFunction' => [ AccordionSlider::class, 'icon_font_declaration' ],
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_swiper_navigation .swiper-button-prev::after, {$order_class} .dipl_swiper_navigation .swiper-button-next::after",
					'attr'      => $attrs['sliderArrows']['advanced']['color'] ?? [],
					'property'  => 'color',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_swiper_navigation .swiper-button-prev::after, {$order_class} .dipl_swiper_navigation .swiper-button-next::after",
					'attr'      => $attrs['sliderArrows']['advanced']['fontSize'] ?? [],
					'property'  => 'font-size',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
					'attr'      => $attrs['sliderArrows']['advanced']['backgroundColor'] ?? [],
					'property'  => 'background',
				] )
			);
			if ( 'on' === $show_on_hover ) {
				array_push( $styles,
					CommonStyle::style( [
						'selector'            => "{$order_class} .dipl_swiper_navigation .swiper-button-prev, {$order_class} .dipl_swiper_navigation .swiper-button-next",
						'attr'                => $attrs['sliderArrows']['advanced']['showOnHover'] ?? [],
						'declarationFunction' => function() {
							return "visibility: hidden; opacity: 0; transition: all 300ms ease;";
						}
					] ),
					CommonStyle::style( [
						'selector'            => "{$order_class}:hover .dipl_swiper_navigation .swiper-button-prev, {$order_class}:hover .dipl_swiper_navigation .swiper-button-next",
						'attr'                => $attrs['sliderArrows']['advanced']['showOnHover'] ?? [],
						'declarationFunction' => function() {
							return "visibility: visible; opacity: 1;";
						}
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_swiper_navigation .swiper-button-prev.swiper-button-disabled, {$order_class}:hover .dipl_swiper_navigation .swiper-button-next.swiper-button-disabled",
						'attr'     => [ 'desktop' => [ 'value' => '0.35' ] ],
						'property' => 'opacity'
					] ),
					// Outside Slider.
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_outside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '50px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_outside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '50px' ] ],
						'property' => 'right'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_outside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '0px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_outside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '0px' ] ],
						'property' => 'right'
					] ),
					// Inside Slider.
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_inside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '-50px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl_arrows_inside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '-50px' ] ],
						'property' => 'right'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_inside .swiper-button-prev",
						'attr'     => [ 'desktop' => [ 'value' => '0px' ] ],
						'property' => 'left'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class}:hover .dipl_arrows_inside .swiper-button-next",
						'attr'     => [ 'desktop' => [ 'value' => '0px' ] ],
						'property' => 'right'
					] ),
				);
			}
		}

		// Pagination CSS.
		$show_control        = $attrs['slider']['advanced']['showControlDot']['desktop']['value'] ?? 'on';
		$control_dot_style   = $attrs['slider']['advanced']['controlDotStyle']['desktop']['value'] ?? 'solid_dot';
		$transition_duration = $attrs['slider']['advanced']['transitionDuration']['desktop']['value'] ?? '1000';
		$enable_dynamic_dots = $attrs['slider']['advanced']['enableDynamicDots']['desktop']['value'] ?? 'off';
		if ( 'on' === $show_control ) {
			array_push( $styles,
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_swiper_pagination .swiper-pagination-bullet",
					'attr'      => $attrs['slider']['advanced']['controlDotInactiveColor'] ?? [],
					'property'  => 'background',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .transparent_dot .swiper-pagination-bullet",
					'attr'      => $attrs['slider']['advanced']['controlDotInactiveColor'] ?? [],
					'property'  => 'border-color',
				] ),
				CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_swiper_pagination .swiper-pagination-bullet-active",
					'attr'      => $attrs['slider']['advanced']['controlDotActiveColor'] ?? [],
					'property'  => 'background',
				] )
			);
			if ( 'stretched_dot' === $control_dot_style && ! empty( $transition_duration ) ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .stretched_dot .swiper-pagination-bullet",
					'attr'      => [ 'desktop' => [ 'value' => sprintf( 'all %1$sms ease', $transition_duration ) ] ],
					'property'  => 'transition',
				] ) );
			}
			if ( 'off' === $enable_dynamic_dots ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .swiper-pagination-bullets-dynamic .swiper-pagination-bullet",
					'attr'      => [ 'desktop' => [ 'value' => 'scale(1)' ] ],
					'property'  => 'transform',
				] ) );
			}
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .swiper-pagination .swiper-pagination-bullet.number-bullet",
				'attr'      => $attrs['slider']['advanced']['numberDotTextColor'] ?? [],
				'property'  => 'color',
			] ) );
		}
		
        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
