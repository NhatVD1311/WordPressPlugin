<?php
namespace DIPL\Modules\AccordionSlider\AccordionSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\AccordionSlider\AccordionSlider;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$rendered_output = '';
		if ( ! empty( $content ) ) {

			$show_arrows          = $attrs['sliderArrows']['advanced']['show']['desktop']['value'] ?? 'off';
			$arrows_position      = $attrs['sliderArrows']['advanced']['position'] ?? [];
			
			$show_control         = $attrs['slider']['advanced']['showControlDot']['desktop']['value'] ?? 'off';
			$control_dot_style    = $attrs['slider']['advanced']['controlDotStyle']['desktop']['value'] ?? 'solid_dot';
			$enable_dynamic_dots  = $attrs['slider']['advanced']['enableDynamicDots']['desktop']['value'] ?? 'off';

			$slider_arrows = '';
			if ( 'on' === $show_arrows ) {
				$previous_arrow = $attrs['sliderArrows']['advanced']['previousArrow']['desktop']['value'] ?? [];
				$next_arrow     = $attrs['sliderArrows']['advanced']['nextArrow']['desktop']['value'] ?? [];

				$next = sprintf(
					'<div class="swiper-button-next"%1$s></div>',
					! empty( $next_arrow ) ?
					sprintf( ' data-next_slide_arrow="%1$s"', Utils::process_font_icon( $next_arrow ) ) : ''
				);
				$prev = sprintf(
					'<div class="swiper-button-prev"%1$s></div>',
					! empty( $previous_arrow ) ?
					sprintf( ' data-previous_slide_arrow="%1$s"', Utils::process_font_icon( $previous_arrow ) ) : ''
				);

				$arrows_position_data = '';
				if ( ! empty( $arrows_position ) ) {
					foreach( $arrows_position as $device => $value ) {
						$arrows_position_data .= ' data-arrows_' . $device . '="' . $value['value'] . '"';
					}
				}
				$slider_arrows .= sprintf(
					'<div class="dipl_swiper_navigation"%3$s>%1$s %2$s</div>', $next, $prev,
					! empty( $arrows_position ) ? $arrows_position_data : ''
				);
			}
			
			$slider_dots = '';
			if ( 'on' === $show_control ) {
				$slider_dots = sprintf(
					'<div class="dipl_swiper_pagination">
						<div class="swiper-pagination %1$s"></div>
					</div>',
					$control_dot_style
				);
			}

			$collapsed_width        = $attrs['slider']['advanced']['collapsedWidth']['desktop']['value'] ?? '150px';
			$collapsed_width_tablet = $attrs['slider']['advanced']['collapsedWidth']['tablet']['value'] ?? $collapsed_width;
			$collapsed_width_phone  = $attrs['slider']['advanced']['collapsedWidth']['phone']['value'] ?? $collapsed_width_tablet;

			$gap                    = $attrs['slider']['advanced']['gap']['desktop']['value'] ?? '20px';
			$gap_tablet             = $attrs['slider']['advanced']['gap']['tablet']['value'] ?? $gap;
			$gap_phone              = $attrs['slider']['advanced']['gap']['phone']['value'] ?? $gap_tablet;

			$autoplay        = $attrs['slider']['advanced']['autoplay']['desktop']['value'] ?? 'on';
			$autoplay_speed  = $attrs['slider']['advanced']['autoplaySpeed']['desktop']['value'] ?? 3000;
			$pause_on_hover  = $attrs['slider']['advanced']['pauseOnHover']['desktop']['value'] ?? 'on';

			// Render final output.
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'attributes'        => [
					'class' => 'dipl_accordion_slider_wrapper dipl_swiper_wrapper',
					'data-collapsed_width'        => esc_attr( $collapsed_width ),
					'data-collapsed_width_tablet' => esc_attr( $collapsed_width_tablet ),
					'data-collapsed_width_phone'  => esc_attr( $collapsed_width_phone ),
					'data-gap'                    => esc_attr( $gap ),
					'data-gap_tablet'             => esc_attr( $gap_tablet ),
					'data-gap_phone'              => esc_attr( $gap_phone ),
					'data-autoplay'               => esc_attr( $autoplay ),
					'data-autoplay_speed'         => esc_attr( $autoplay_speed ),
					'data-pause_on_hover'         => esc_attr( $pause_on_hover ),
					'data-show_arrow'             => esc_attr( $show_arrows ),
					'data-show_control_dots'      => esc_attr( $show_control ),
					'data-enable_dynamic_dots'    => esc_attr( $enable_dynamic_dots ),
				],
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => sprintf(
					'<div class="dipl_swiper_inner_wrap dipl-accordion-slider-layout">
						<div class="swiper-container"><div class="swiper-wrapper">
							%1$s
						</div></div>%2$s
					</div>%3$s',
					et_core_esc_previously( $content ),
					et_core_esc_previously( $slider_arrows ),
					et_core_esc_previously( $slider_dots )
				)
			] );
		}

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AccordionSlider::class, 'module_classnames' ],
			'stylesComponent'     => [ AccordionSlider::class, 'module_styles' ],
			'scriptDataComponent' => [ AccordionSlider::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
