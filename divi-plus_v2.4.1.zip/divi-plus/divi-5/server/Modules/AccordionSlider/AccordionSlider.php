<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\AccordionSlider;
 */
namespace DIPL\Modules\AccordionSlider;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AccordionSlider\AccordionSliderTraits;

/**
 * Class AccordionSlider
 *
 * @package DIPL\Modules\AccordionSlider
 */
class AccordionSlider implements DependencyInterface {

	use AccordionSliderTraits\RenderCallbackTrait;
	use AccordionSliderTraits\ModuleClassnamesTrait;
	use AccordionSliderTraits\ModuleStylesTrait;
	use AccordionSliderTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/accordion-slider';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AccordionSlider::class, 'render_callback' ] ]
				);
			}
		);
	}
}
