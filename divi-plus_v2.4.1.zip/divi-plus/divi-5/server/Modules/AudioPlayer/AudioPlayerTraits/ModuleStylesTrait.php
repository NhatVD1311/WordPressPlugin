<?php
namespace DIPL\Modules\AudioPlayer\AudioPlayerTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DIPL\Modules\AudioPlayer\AudioPlayer;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles.
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),
			
			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'artist',
			] ),
			$elements->style( [
				'attrName' => 'player',
			] ),
			$elements->style( [
				'attrName' => 'playPauseButton',
			] ),

			// Player.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-audio-card",
				'attr'      => $attrs['player']['advanced']['height'] ?? [],
				'property'  => 'height',
				'important' => true
			] ),

			// Play button.
			CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-play .et-pb-icon, {$order_class} .jp-controls .jp-pause .et-pb-icon",
				'attr'      => $attrs['playPauseButton']['advanced']['iconSize'] ?? [],
				'property'  => 'font-size',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-play .et-pb-icon, {$order_class} .jp-controls .jp-pause .et-pb-icon",
				'attr'      => $attrs['playPauseButton']['advanced']['iconColor'] ?? [],
				'property'  => 'color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-play, {$order_class} .jp-controls .jp-pause",
				'attr'      => $attrs['playPauseButton']['advanced']['buttonSize'] ?? [],
				'property'  => 'width',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-play, {$order_class} .jp-controls .jp-pause",
				'attr'      => $attrs['playPauseButton']['advanced']['buttonSize'] ?? [],
				'property'  => 'height',
			] ),
		);

		// Seek bar.
		$show_seek_bar = $attrs['seekBar']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_seek_bar ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-audio-card .jp-progress",
				'attr'      => $attrs['seekBar']['advanced']['color'] ?? [],
				'property'  => 'background',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-audio-card .jp-play-bar",
				'attr'      => $attrs['seekBar']['advanced']['activeColor'] ?? [],
				'property'  => 'background',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-progress, {$order_class} .jp-play-bar",
				'attr'      => $attrs['seekBar']['advanced']['height'] ?? [],
				'property'  => 'height',
			] ) );
		}

		// Current time.
		$show_current_time = $attrs['currentTime']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_current_time ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'currentTime',
			] )	);
		}

		// Volume button.
		$show_volume_button = $attrs['volumeButton']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_volume_button ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'volumeButton',
			] )	);
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-mute .et-pb-icon, {$order_class} .jp-controls .jp-unmute .et-pb-icon",
				'attr'      => $attrs['volumeButton']['advanced']['iconSize'] ?? [],
				'property'  => 'font-size',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-mute .et-pb-icon, {$order_class} .jp-controls .jp-unmute .et-pb-icon",
				'attr'      => $attrs['volumeButton']['advanced']['iconColor'] ?? [],
				'property'  => 'color',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-mute, {$order_class} .jp-controls .jp-unmute",
				'attr'      => $attrs['volumeButton']['advanced']['buttonSize'] ?? [],
				'property'  => 'width',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-controls .jp-mute, {$order_class} .jp-controls .jp-unmute",
				'attr'      => $attrs['volumeButton']['advanced']['buttonSize'] ?? [],
				'property'  => 'height',
			] ) );
		}

		// Volume bar.
		$show_volume_bar = $attrs['volumeBar']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_volume_bar ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-audio-card .jp-volume-bar",
				'attr'      => $attrs['volumeBar']['advanced']['color'] ?? [],
				'property'  => 'background',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl-audio-card .jp-volume-bar-value",
				'attr'      => $attrs['volumeBar']['advanced']['activeColor'] ?? [],
				'property'  => 'background',
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .jp-volume-bar, {$order_class} .jp-volume-bar-value",
				'attr'      => $attrs['volumeBar']['advanced']['height'] ?? [],
				'property'  => 'height',
			] ) );
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
};
