<?php
namespace DIPL\Modules\AudioPlayer\AudioPlayerTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\AudioPlayer\AudioPlayer;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$order_class        = ModuleUtils::get_module_order_class_name( $block->parsed_block['id'] );
		$layout             = $attrs['player']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$audio_src          = $attrs['audio']['innerContent']['desktop']['value']['src'] ?? '';
		$image_src          = $attrs['image']['innerContent']['desktop']['value']['src'] ?? '';

		$show_current_time  = $attrs['currentTime']['advanced']['show']['desktop']['value'] ?? 'on';
		$show_seek_bar      = $attrs['seekBar']['advanced']['show']['desktop']['value'] ?? 'on';
		$show_duration      = $attrs['duration']['advanced']['show']['desktop']['value'] ?? 'on';
		$show_volume_button = $attrs['volumeButton']['advanced']['show']['desktop']['value'] ?? 'on';
		$show_volume_bar    = $attrs['volumeBar']['advanced']['show']['desktop']['value'] ?? 'on';

		$player_id          = 'jquery_jplayer_' . esc_attr( $order_class );
		$container_id       = 'jp_container_' . esc_attr( $order_class );

		// Static icons.
		$play_icon          = Utils::process_font_icon( array( 'unicode' => "&#xf04b;", 'type' => "fa", 'weight' => "900" ) );
		$pause_icon         = Utils::process_font_icon( array( 'unicode' => "&#xf04c;", 'type' => "fa", 'weight' => "900" ) );

		$mute_icon          = Utils::process_font_icon( array( 'unicode' => "&#xe069;", 'type' => "divi", 'weight' => "400" ) );
		$unmute_icon        = Utils::process_font_icon( array( 'unicode' => "&#xe067;", 'type' => "divi", 'weight' => "400" ) );

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );

		// Render artist.
		$artist = $elements->render( [
			'attrName' => 'artist',
		] );

		// Render image.
		$image = '';
		if ( ! empty( $image_src ) ) {
			$image = $elements->render( [
				'attrName' => 'image',
			] );
		}

		// Audio player.
		$audio_player = '';
		if ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AudioPlayer/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/AudioPlayer/layouts/' . sanitize_file_name( $layout ) . '.php';
		}

		// Final output.
		$rendered_output = et_core_intentionally_unescaped( $audio_player, 'html' );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ AudioPlayer::class, 'module_classnames' ],
			'stylesComponent'     => [ AudioPlayer::class, 'module_styles' ],
			'scriptDataComponent' => [ AudioPlayer::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
