<?php
/**
 * The Template for displaying Layout 1
 *
 * @author     Elicus Technologies <hello@elicus.com>
 * @link       https://www.elicus.com/
 * @copyright  2025 Elicus Technologies Private Limited
 * @version    1.20.0
 */

// if no audio url, return.
if ( empty( $audio_src ) ) {
	return '';
}

// Current time.
$current_time = '';
if ( 'on' === $show_current_time ) {
	$current_time = '<div class="jp-current-time"></div>';
}

// Seek bar.
$seek_bar = '';
if ( 'on' === $show_seek_bar ) {
	$seek_bar = '<div class="jp-progress">
		<div class="jp-seek-bar"><div class="jp-play-bar"></div></div>
	</div>';
}

// Duration.
$duration = '';
if ( 'on' === $show_duration ) {
	$duration = '<div class="jp-duration"></div>';
}

// Volumn button.
$volume_button = '';
if ( 'on' === $show_volume_button ) {
	$volume_button = sprintf(
		'<button class="jp-mute" role="button" tabindex="0">
			<span class="et-pb-icon et-pb-normal-icon">%1$s</span>
		</button>
		<button class="jp-unmute" role="button" tabindex="0">
			<span class="et-pb-icon et-pb-normal-icon">%2$s</span>
		</button>',
		et_core_esc_previously( $mute_icon ),
		et_core_esc_previously( $unmute_icon )
	);
}

// Volumn bar.
$volume_bar = '';
if ( 'on' === $show_volume_bar ) {
	$volume_bar = '<div class="jp-volume-bar">
		<div class="jp-volume-bar-value"></div>
	</div>';
}

// Image.
if ( ! empty( $image ) ) {
	$image = sprintf( '<div class="dipl-audio-image">%1$s</div>', et_core_esc_previously( $image ) );
}

// Final audio player html.
$audio_player = sprintf(
	'<div class="dipl-audio-card %1$s" data-audio-src="%2$s" data-player-id="%3$s" data-container-id="%4$s">
		<div class="dipl-audio-info">
			%5$s %6$s
			<div id="%3$s" class="jp-jplayer"></div>
			<div id="%4$s" class="jp-audio" role="application" aria-label="media player">
				<div class="jp-controls">
					<button class="jp-play et_pb_icon_wrap" role="button" tabindex="0">
						<span class="et-pb-icon et-pb-fa-icon et-pb-black-icon">%7$s</span>
					</button>
					<button class="jp-pause" role="button" tabindex="0">
						<span class="et-pb-icon et-pb-fa-icon et-pb-black-icon">%8$s</span>
					</button>
					%9$s %10$s %11$s %12$s %13$s
				</div>
			</div>
		</div>
		%14$s
	</div>',
	esc_attr( $layout ),
	esc_attr( $audio_src ),
	esc_attr( $player_id ), // %3$s.
	esc_attr( $container_id ),
	et_core_esc_previously( $title ), // %5$s.
	et_core_esc_previously( $artist ),
	html_entity_decode( $play_icon ),
	html_entity_decode( $pause_icon ),
	et_core_esc_previously( $current_time ),
	et_core_esc_previously( $seek_bar ), // %10$s.
	et_core_esc_previously( $duration ),
	et_core_esc_previously( $volume_button ),
	et_core_esc_previously( $volume_bar ),
	et_core_esc_previously( $image )
);
