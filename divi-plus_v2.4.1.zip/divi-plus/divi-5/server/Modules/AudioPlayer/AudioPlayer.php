<?php
/**
 * Audio Player Module class.
 *
 * @package DIPL\Modules\AudioPlayer;
 */
namespace DIPL\Modules\AudioPlayer;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\AudioPlayer\AudioPlayerTraits;

/**
 * Class AudioPlayer
 *
 * @package DIPL\Modules\AudioPlayer
 */
class AudioPlayer implements DependencyInterface {

	use AudioPlayerTraits\RenderCallbackTrait;
	use AudioPlayerTraits\ModuleClassnamesTrait;
	use AudioPlayerTraits\ModuleStylesTrait;
	use AudioPlayerTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/audio-player';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ AudioPlayer::class, 'render_callback' ] ]
				);
			}
		);
	}
}
