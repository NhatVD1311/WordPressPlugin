<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookShare;
 */

namespace DIPL\Modules\FacebookShare;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookShare\FacebookShareTraits;

/**
 * Class FacebookShare
 *
 * @package DIPL\Modules\FacebookShare
 */
class FacebookShare implements DependencyInterface {

    use FacebookShareTraits\RenderCallbackTrait;
    use FacebookShareTraits\ModuleClassnamesTrait;
    use FacebookShareTraits\ModuleStylesTrait;
    use FacebookShareTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-share';
        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [ 'render_callback' => [ FacebookShare::class, 'render_callback' ] ]
                );
            }
        );
    }
}
