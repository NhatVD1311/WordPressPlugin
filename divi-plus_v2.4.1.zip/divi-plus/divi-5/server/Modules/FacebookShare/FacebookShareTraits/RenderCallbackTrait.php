<?php
namespace DIPL\Modules\FacebookShare\FacebookShareTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\FacebookShare\FacebookShare;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Framework\Utility\HTMLUtility;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {
		
		$plugin_options = get_option( ELICUS_DIVI_PLUS_OPTION );

		$app_id       = $attrs['module']['advanced']['appID']['desktop']['value'] ?? '';
		$app_id       = ! empty( $app_id ) ? $app_id : ( $plugin_options['dipl-facebook-app-id'] ?? '' );
		$url          = $attrs['module']['advanced']['pageURL']['desktop']['value'] ?? '';
		$layout       = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'button';
		$size         = $attrs['module']['advanced']['size']['desktop']['value'] ?? 'small';
		$lazy_loading = $attrs['module']['advanced']['lazyLoading']['desktop']['value'] ?? 'off';
		$lazy_loading = 'on' === $lazy_loading ? true : false;

		$wrapper = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class' => "fb-share-button",
				'data-href' => esc_url( $url ),
				'data-layout' => esc_attr( $layout ),
				'data-lazy' => esc_attr( $lazy_loading ),
				'data-size' => esc_attr( $size )
			]
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		if ( '' !== $app_id ) {
			wp_enqueue_script( 'facebook-sdk', 'https://connect.facebook.net/en_us/sdk.js#xfbml=1&version=v13.0&appId=' . $app_id, array('jquery'), null, true );
		}

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ FacebookShare::class, 'module_classnames' ],
			'stylesComponent'     => [ FacebookShare::class, 'module_styles' ],
			'scriptDataComponent' => [ FacebookShare::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components( [
										'attrName' => 'module',
									] ) . $wrapper,
		] );
	}
}
