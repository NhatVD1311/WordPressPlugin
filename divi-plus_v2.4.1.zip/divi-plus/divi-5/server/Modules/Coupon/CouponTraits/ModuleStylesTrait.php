<?php
namespace DIPL\Modules\Coupon\CouponTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DIPL\Modules\Coupon\Coupon;

trait ModuleStylesTrait {

	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles.
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'couponCode',
			] ),
			$elements->style( [
				'attrName' => 'description',
			] ),
		);

		$layout      = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$show_offer  = $attrs['offerDiscount']['advanced']['show']['desktop']['value'] ?? 'on';
		$enable_copy = $attrs['couponCode']['advanced']['enableCopy']['desktop']['value'] ?? 'off';

		// Copy-to-clipboard "copied" feedback colors.
		if ( 'on' === $enable_copy ) {
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_coupon_code.dipl-copied",
				'attr'      => $attrs['couponCode']['advanced']['copiedBackgroundColor'] ?? [],
				'property'  => 'background-color',
				'important' => true,
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_coupon_code.dipl-copied",
				'attr'      => $attrs['couponCode']['advanced']['copiedBorderColor'] ?? [],
				'property'  => 'border-color',
				'important' => true,
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_coupon_code.dipl-copied .dipl_coupon_code_text",
				'attr'      => $attrs['couponCode']['advanced']['copiedTextColor'] ?? [],
				'property'  => 'color',
				'important' => true,
			] ) );
		}

		// Offer styling.
		if ( 'on' === $show_offer ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'offerDiscount',
			] )	);
			array_push( $styles, $elements->style( [
				'attrName' => 'offerLabel',
			] )	);
			array_push( $styles, CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_coupon_wrapper .dipl_coupon_offer_wrapper",
				'attr'      => $attrs['offerDiscount']['advanced']['backgroundColor'] ?? [],
				'property'  => 'background-color',
			] ) );
			// On Layout, for offer box.
			if ( 'layout2' !== $layout ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_coupon_wrapper .dipl_coupon_offer_label",
					'attr'      => $attrs['offerLabel']['advanced']['backgroundColor'] ?? [],
					'property'  => 'background-color',
				] ) );
			}
			// Offer box vertical alignment (layout 3 only, side-by-side flex layout).
			if ( 'layout3' === $layout ) {
				array_push( $styles, CommonStyle::style( [
					'selector'  => "{$order_class} .dipl_coupon_wrapper.layout3 .dipl_coupon_inner",
					'attr'      => $attrs['offerDiscount']['advanced']['verticalAlign'] ?? [],
					'property'  => 'align-items',
				] ) );
			}
		}

		// Expiry date.
		$show_expiry_date = $attrs['expiryDate']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_expiry_date ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'expiryDate',
			] )	);
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
};
