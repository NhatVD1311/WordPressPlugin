<?php
namespace DIPL\Modules\Coupon\CouponTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use DIPL\Modules\Coupon\Coupon;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$layout             = $attrs['module']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$show_offer         = $attrs['offerDiscount']['advanced']['show']['desktop']['value'] ?? 'on';
		$offer_discount     = $attrs['offerDiscount']['innerContent']['desktop']['value'] ?? '';
		$show_expiry_date   = $attrs['expiryDate']['advanced']['show']['desktop']['value'] ?? 'on';
		$expiry_date        = $attrs['expiryDate']['advanced']['date']['desktop']['value'] ?? '';
		$expiry_date_format = $attrs['expiryDate']['advanced']['format']['desktop']['value'] ?? 'M j, Y';
		$enable_copy        = $attrs['couponCode']['advanced']['enableCopy']['desktop']['value'] ?? 'off';

		// Offer discount.
		$offer_discount       = '';
		$offer_discount_label = '';
		if ( 'on' === $show_offer ) {
			// Get offer discount.
			$offer_discount = $elements->render( [
				'attrName' => 'offerDiscount',
			] );
			$offer_discount_label = $elements->render( [
				'attrName' => 'offerLabel',
			] );
		}

		// Render title.
		$title = $elements->render( [
			'attrName' => 'title',
		] );

		// Render title.
		$description = $elements->render( [
			'attrName' => 'description',
		] );

		// Render coupon code.
		$coupon_code = $elements->render( [
			'attrName' => 'couponCode',
		] );
		if ( ! empty( $coupon_code ) ) {
			if ( 'on' === $enable_copy ) {
				$coupon_code = sprintf(
					'<div class="dipl_coupon_code dipl-copy-enabled" title="%1$s" data-copied-text="%2$s">%3$s</div>',
					esc_attr__( 'Click to copy code', 'divi-plus' ),
					esc_attr__( 'Copied!', 'divi-plus' ),
					et_core_esc_previously( $coupon_code )
				);
			} else {
				$coupon_code = sprintf(
					'<div class="dipl_coupon_code">%1$s</div>',
					et_core_esc_previously( $coupon_code )
				);
			}
		}

		// Expiration date/message.
		$expiry_message = '';
		if ( 'on' === $show_expiry_date && ! empty( $expiry_date ) ) {
			// Convert both dates to timestamps using WordPress time zone.
			$expiry_timestamp  = strtotime( $expiry_date );
			$current_timestamp = current_time( 'timestamp' );
			// Check if expired.
			if ( $current_timestamp > $expiry_timestamp ) {
				// Expired date message.
				$expiry_message = sprintf(
					'<div class="dipl_coupon_expiry_message date-expired">%1$s</div>',
					esc_html__( 'Expired', 'divi-plus' )
				);
			} else {
				// Active date message.
				$expiry_message = sprintf(
					'<div class="dipl_coupon_expiry_message date-active">%1$s %2$s</div>',
					esc_html__( 'Expires On', 'divi-plus' ),
					date_i18n( $expiry_date_format, strtotime( $expiry_date ) )
				);
			}
		}

		// Based on layout get the coupon html.
		$render_coupon = '';
		if ( file_exists( get_stylesheet_directory() . '/divi-plus/layouts/coupon/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include get_stylesheet_directory() . '/divi-plus/layouts/coupon/' . sanitize_file_name( $layout ) . '.php';
		} elseif ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/Coupon/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
			include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/Coupon/layouts/' . sanitize_file_name( $layout ) . '.php';
		}

		// Final rendering.
		$rendered_output = sprintf(
			'<div class="dipl_coupon_wrapper %1$s">%2$s</div>',
			esc_attr( $layout ),
			et_core_esc_previously( $render_coupon )
		);

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ Coupon::class, 'module_classnames' ],
			'stylesComponent'     => [ Coupon::class, 'module_styles' ],
			'scriptDataComponent' => [ Coupon::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
