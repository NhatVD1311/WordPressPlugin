<?php
/**
 * Coupon Module class.
 *
 * @package DIPL\Modules\Coupon;
 */
namespace DIPL\Modules\Coupon;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\Coupon\CouponTraits;

/**
 * Class Coupon
 *
 * @package DIPL\Modules\Coupon
 */
class Coupon implements DependencyInterface {

	use CouponTraits\RenderCallbackTrait;
	use CouponTraits\ModuleClassnamesTrait;
	use CouponTraits\ModuleStylesTrait;
	use CouponTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/coupon';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ Coupon::class, 'render_callback' ] ]
				);
			}
		);
	}
}
