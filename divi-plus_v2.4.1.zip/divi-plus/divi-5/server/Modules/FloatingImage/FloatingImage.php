<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FloatingImage;
 */

namespace DIPL\Modules\FloatingImage;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FloatingImage\FloatingImageTraits;

/**
 * Class FloatingImage
 *
 * @package DIPL\Modules\FloatingImage
 */
class FloatingImage implements DependencyInterface {

	use FloatingImageTraits\RenderCallbackTrait;
	use FloatingImageTraits\ModuleClassnamesTrait;
	use FloatingImageTraits\ModuleStylesTrait;
	use FloatingImageTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/floating-image';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FloatingImage::class, 'render_callback' ] ]
				);
			}
		);
	}
}
