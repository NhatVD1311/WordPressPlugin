<?php
/**
 * Comparison List Item class.
 *
 * @package DIPL\Modules\ComparisonListItem;
 */
namespace DIPL\Modules\ComparisonListItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\ComparisonListItem\ComparisonListItemTraits;

/**
 * Class ComparisonListItem
 *
 * @package DIPL\Modules\ComparisonListItem
 */
class ComparisonListItem implements DependencyInterface {

	use ComparisonListItemTraits\RenderCallbackTrait;
	use ComparisonListItemTraits\ModuleClassnamesTrait;
	use ComparisonListItemTraits\ModuleStylesTrait;
	use ComparisonListItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/comparison-list-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ ComparisonListItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
