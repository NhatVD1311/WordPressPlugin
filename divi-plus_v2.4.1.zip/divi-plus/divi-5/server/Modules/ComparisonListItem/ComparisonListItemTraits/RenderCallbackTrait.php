<?php
namespace DIPL\Modules\ComparisonListItem\ComparisonListItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\ComparisonListItem\ComparisonListItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attrs.
		$title       = $attrs['title']['innerContent']['desktop']['value'] ?? '';
		$item_values = $attrs['itemValues']['innerContent']['desktop']['value'] ?? '';

		$close_icon  = '<span class="et-pb-icon dipl_comparison_list_icon_close"></span>';
		$open_icon   = '<span class="et-pb-icon dipl_comparison_list_icon_check"></span>';

		// Render content.
		$description = $elements->render( [
			'attrName' => 'description',
		] );

		// Get the values.
		$values      = explode( '|', $item_values );
		$valuesItems = '';
		if ( ! empty( $values ) ) {
			foreach ( $values as $value ) {
				if ( empty( trim( $value ) ) ) {
					continue;
				}
				$valuesItems .= sprintf(
					'<div class="dipl_comparison_list_column">
						<span class="dipl_comparison_list_text">%1$s</span>
					</div>',
					str_replace( array( '{0}', '{1}' ), array( $close_icon, $open_icon ), trim( $value ) )
				);
			}
		}

		// Final render output.
		$rendered_output = sprintf(
			'<div class="dipl_comparison_list_content_row">
				<div class="dipl_comparison_list_column dipl_comparison_list_item_title">
					<span class="et-pb-icon dipl_toggle_icon"></span>%1$s
				</div>
				%2$s
			</div>%3$s',
			esc_html( $title ),
			et_core_esc_previously( $valuesItems ),
			et_core_esc_previously( $description )
		);
		
		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent   = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ ComparisonListItem::class, 'module_classnames' ],
			'stylesComponent'     => [ ComparisonListItem::class, 'module_styles' ],
			'scriptDataComponent' => [ ComparisonListItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
