<?php
/**
 * Masonry Gallery Module Controller.
 *
 * @package DIPL\Modules\Breadcrumb;
 */
namespace DIPL\Modules\Breadcrumb;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Controllers\RESTController;
use ET\Builder\Framework\UserRole\UserRole;
use DIPL\Modules\Breadcrumb\Breadcrumb;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Class BreadcrumbController
 *
 * @package DIPL\Modules\Breadcrumb
 */
class BreadcrumbController extends RESTController {

	/**
	 * Return data for the Dynamic Module.
	 *
	 * @param WP_REST_Request $request REST request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public static function index( WP_REST_Request $request ): WP_REST_Response {
		$args = array(
			'current_post_id' => $request->get_param( 'current_post_id' ),
		);
		
		// Get the content.
		$response = [
			'data' => Breadcrumb::get_breadcrumb_data( $args ),
		];

		return self::response_success( $response );
	}

	/**
	 * Index action arguments.
	 *
	 * Endpoint arguments as used in `register_rest_route()`.
	 *
	 * @return array
	 */
	public static function index_args(): array {
		return [
			'layout' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return esc_html( $value );
				},
			],
		];
	}

	/**
	 * Index action permission.
	 *
	 * Endpoint permission callback as used in `register_rest_route()`.
	 *
	 * @return bool
	 */
	public static function index_permission(): bool {
		return UserRole::can_current_user_use_visual_builder();
	}
}
