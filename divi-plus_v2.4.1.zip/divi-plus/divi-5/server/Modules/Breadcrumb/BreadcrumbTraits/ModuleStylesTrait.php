<?php
namespace DIPL\Modules\Breadcrumb\BreadcrumbTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\FormField\FormFieldStyle;
use DIPL\Modules\Breadcrumb\Breadcrumb;

trait ModuleStylesTrait {
	
	use StyleDeclarationTrait;
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$order_class = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

        // Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'global',
			] ),
			$elements->style( [
				'attrName' => 'text',
			] ),
			$elements->style( [
				'attrName' => 'link',
			] )
		);

		$global_styles = $attrs['global']['decoration']['font']['font'] ?? [];

		$text_align = [];
		foreach ( $global_styles as $device => $value ) {
			$this_align = ! empty( $value['value']['textAlign'] ) ? $value['value']['textAlign'] : '';
			$text_align[ $device ] = [
				'value' => str_replace( array( 'left', 'right', 'justify' ), array( 'flex-start', 'flex-end', 'flex-start' ), $this_align )
			];
		}

		array_push( $styles, CommonStyle::style( [
			'selector' => "{$order_class} .dipl-breadcrumb-wrapper",
			'attr'     => $text_align,
			'property' => 'justify-content'
		] ) );

		$use_icon = $attrs['homeLink']['advanced']['useIcon']['desktop']['value'] ?? 'off';
		if ( 'on' === $use_icon ) {

			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl-breadcrumb-wrapper li .breadcrumb-home-icon",
				'attr'     => $attrs['homeLink']['advanced']['icon'] ?? [],
				'declarationFunction' => [ Breadcrumb::class, 'icon_font_declaration' ]
			] ) );
		
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper li .breadcrumb-home-icon",
					'attr'     => $attrs['homeLink']['advanced']['iconSize'] ?? [],
					'property' => 'font-size'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper li .breadcrumb-home-icon",
					'attr'     => $attrs['homeLink']['advanced']['iconColor'] ?? [],
					'property' => 'color'
				] )
			);
		}

		$layout = $attrs['breadcrumb']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		if ( 'layout1' === $layout ) {
			// Spacing.
			$spacing       = $attrs['breadcrumb']['decoration']['spacing'] ?? [];
			$padding_left  = [];
			$padding_right = [];
			foreach ( $spacing as $device => $value ) {
				$this_padding             = $value['value']['padding'];
				$padding_left[ $device ]  = isset( $this_padding['left'] ) ? array( 'value' => $this_padding['left'] ) : '';
				$padding_right[ $device ] = isset( $this_padding['right'] ) ? array( 'value' => $this_padding['right'] ) : '';
			}
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page",
					'attr'     => $padding_left,
					'property' => 'padding-left'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page",
					'attr'     => $padding_right,
					'property' => 'padding-right'
				] )
			);

			// Background.
			$nav_bg_color = $attrs['breadcrumb']['advanced']['backgroundColor'] ?? [];
			$after_color  = [];
			$before_color = [];
			foreach ( $nav_bg_color as $device => $value ) {
				if ( isset( $value['value'] ) ) {
					$after_color[ $device ]  = array( 'value' => sprintf( 'transparent transparent transparent %1$s', esc_html( $value['value'] ) ) );
					$before_color[ $device ] = array( 'value' => sprintf( '%1$s %1$s %1$s transparent', esc_html( $value['value'] ) ) );
					if ( isset( $value['hover'] ) ) {
						$after_color[ $device ]['hover']  = sprintf( 'transparent transparent transparent %1$s', esc_html( $value['hover'] ) );
						$before_color[ $device ]['hover'] = sprintf( '%1$s %1$s %1$s transparent', esc_html( $value['hover'] ) );
					}
				}
			}
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page",
					'attr'     => $nav_bg_color,
					'property' => 'background-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .layout1 li .breadcrumb-page::after",
					'attr'     => $after_color,
					'property' => 'border-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .layout1 li .breadcrumb-page::before",
					'attr'     => $before_color,
					'property' => 'border-color'
				] )
			);

			// Last item background.
			$last_nav_bg_enable = $attrs['breadcrumb']['advanced']['lastItemEnableDifferentBg']['desktop']['value'] ?? 'off';
			$last_nav_bg_color  = $attrs['breadcrumb']['advanced']['lastItemBackground'] ?? [];
			$last_after_color   = [];
			$last_before_color  = [];
			foreach ( $last_nav_bg_color as $device => $value ) {
				if ( isset( $value['value'] ) ) {
					$last_after_color[ $device ]  = array( 'value' => sprintf( 'transparent transparent transparent %1$s', esc_html( $value['value'] ) ) );
					$last_before_color[ $device ] = array( 'value' => sprintf( '%1$s %1$s %1$s transparent', esc_html( $value['value'] ) ) );
					if ( isset( $value['hover'] ) ) {
						$last_after_color[ $device ]['hover']  = sprintf( 'transparent transparent transparent %1$s', esc_html( $value['hover'] ) );
						$last_before_color[ $device ]['hover'] = sprintf( '%1$s %1$s %1$s transparent', esc_html( $value['hover'] ) );
					}
				}
			}
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page.dipl-last-page",
					'attr'     => $last_nav_bg_color,
					'property' => 'background-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .layout1 li .breadcrumb-page.dipl-last-page::after",
					'attr'     => $last_after_color,
					'property' => 'border-color'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .layout1 li .breadcrumb-page.dipl-last-page::before",
					'attr'     => $last_before_color,
					'property' => 'border-color'
				] )
			);

			// Height wise border.
			$height_css = [];
			$border_css = [];
			foreach ( $global_styles as $device => $value ) {
				if ( ! empty( $value['value']['size'] ) ) {
					$padding_top    = $spacing[ $device ]['value']['padding']['top'] ?? '0px';
					$padding_bottom = $spacing[ $device ]['value']['padding']['bottom'] ?? '0px';
					if ( ! empty( $value['value']['size'] ) ) {
						$height   = ( intval( $value['value']['size'] ) + intval( $padding_top ) + intval( $padding_bottom ) ) . 'px';
						$height_f = floor( intval( $height ) / 2 ) . 'px';
						$height_c = ceil( intval( $height ) / 2 ) . 'px';

						$height_css[ $device ] = array( 'value' => $height );
						$border_css[ $device ] = array( 'value' => sprintf( '%1$s 10px %2$s 10px' , $height_f, $height_c ) );
					}
				}
			}
			array_push( $styles,
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page",
					'attr'     => $height_css,
					'property' => 'height'
				] ),
				CommonStyle::style( [
					'selector' => "{$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page::before, {$order_class} .dipl-breadcrumb-wrapper.layout1 li .breadcrumb-page::after",
					'attr'     => $border_css,
					'property' => 'border-width'
				] )
			);
		} elseif ( 'layout2' === $layout ) {

			// Separator type.
			$separator_type = $attrs['breadcrumb']['advanced']['separatorType']['desktop']['value'] ?? 'text_separator';
			if ( 'text_separator' === $separator_type ) {
				if ( ! empty( $attrs['breadcrumb']['advanced']['separatorText'] ) ) {
					$sep_content = [];
					foreach ( $attrs['breadcrumb']['advanced']['separatorText'] as $device => $val ) {
						if ( isset( $val['value'] ) ) {
							$sep_content[ $device ] = array( 'value' => sprintf( '"%1$s"', $val['value'] ) );
						}
					}
					array_push( $styles, CommonStyle::style( [
						'selector' => "{$order_class} .dipl-breadcrumb-inner li:after",
						'attr'     => $sep_content,
						'property' => 'content'
					] ) );
				}
			} else {
				array_push( $styles,
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl-breadcrumb-inner li:after",
						'attr'     => [ 'desktop' => [ 'value' => 'attr(data-icon)' ] ],
						'property' => 'content'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl-breadcrumb-inner li:after",
						'attr'     => $attrs['breadcrumb']['advanced']['separatorIcon'],
						'declarationFunction' => [ Breadcrumb::class, 'icon_font_declaration' ]
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl-breadcrumb-inner li:after",
						'attr'     => $attrs['breadcrumb']['advanced']['separatorSize'],
						'property' => 'font-size'
					] ),
					CommonStyle::style( [
						'selector' => "{$order_class} .dipl-breadcrumb-inner li:after",
						'attr'     => $attrs['breadcrumb']['advanced']['separatorColor'],
						'property' => 'color'
					] )
				);
			}
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
