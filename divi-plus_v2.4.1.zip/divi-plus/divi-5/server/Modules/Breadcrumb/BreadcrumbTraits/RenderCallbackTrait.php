<?php
namespace DIPL\Modules\Breadcrumb\BreadcrumbTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DIPL\Modules\Breadcrumb\Breadcrumb;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$layout         = $attrs['breadcrumb']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$home_icon      = $attrs['homeLink']['advanced']['icon']['desktop']['value'] ?? [];
		$separator_icon = $attrs['breadcrumb']['advanced']['separatorIcon']['desktop']['value'] ?? [];

		$breadcrumb = self::traverse_breadcrumbs();

		$rendered_output = '';
		if ( ! empty( $breadcrumb ) ) {

			$args = array(
				'link_target'    => $attrs['breadcrumb']['advanced']['linkTarget']['desktop']['value'] ?? 'off',
				'enable_fade'    => $attrs['breadcrumb']['advanced']['enableFade']['desktop']['value'] ?? 'off',
				'fade_range'     => $attrs['breadcrumb']['advanced']['fadeRange']['desktop']['value'] ?? '0.01',
				
				'home_link_text' => $attrs['homeLink']['advanced']['customText']['desktop']['value'] ?? esc_html__( 'Home', 'divi-plus' ),
				'use_home_icon'  => $attrs['homeLink']['advanced']['useIcon']['desktop']['value'] ?? 'off',
				'home_icon'      => Utils::process_font_icon( $home_icon ),
				'hide_home_text' => $attrs['homeLink']['advanced']['hideText']['desktop']['value'] ?? 'off',

				'separator_icon' => Utils::process_font_icon( $separator_icon ),
			);

			if ( 'layout2' === $layout ) {
				$breadcrumb_list = self::render_layout_two( $breadcrumb, $args );
			} else {
				$breadcrumb_list = self::render_layout_one( $breadcrumb, $args );
			}

			$rendered_output = sprintf(
				'<div class="dipl-breadcrumb-wrapper %1$s">
					<ol class="dipl-breadcrumb-inner" vocab="https://schema.org/" typeof="BreadcrumbList">
						%2$s
					</ol>
				</div>',
				$layout,
				$breadcrumb_list
			);
		}

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ Breadcrumb::class, 'module_classnames' ],
			'stylesComponent'     => [ Breadcrumb::class, 'module_styles' ],
			'scriptDataComponent' => [ Breadcrumb::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }

	/**
	 * Create breadcrumb,
	 *
	 * @return array breadcrumb
	 */
	public static function traverse_breadcrumbs( $args = array(), $current_page = array() ) {
		global $paged, $wp_query;

		$defaults = array(
			'home_link_text' => '',
		);

		$args     = wp_parse_args( $args, $defaults );
		$page_id  = isset( $current_page['id'] ) ? (int) $current_page['id'] : 0;

		$home_link_text = $args['home_link_text'];
		$query_object   = $wp_query->get_queried_object();

		$breadcrumb     = array();
		if ( ! is_front_page() || ! is_home() ) {
			$breadcrumb[] = array(
				$home_link_text => get_home_url(),
			);

			// Is single page.
			if ( is_singular() ) {
				$post_object = get_post( $page_id );
				$post_type   = $post_object->post_type;
				$post_parent = $post_object->post_parent;

				// If is post.
				if ( 'post' === $post_type ) {
					$categories = get_the_category( $post_object->ID );
					if ( ! empty( $categories ) ) {
						$indexed_categories = array_values( $categories );
						$category           = end( $indexed_categories );
						$category_parent    = $category->parent;
						$category_trail[]   = array( $category->name => get_term_link( $category->term_id ) );

						if ( 0 !== $category_parent ) {
							while ( $category_parent ) {
								$parent_category  = get_term( $category_parent, 'category' );
								$category_trail[] = array( $parent_category->name => get_term_link( $parent_category->term_id ) );
								$category_parent  = $parent_category->parent;
							}
							$category_trail = array_reverse( $category_trail );
						}
						$category_trail_size = (int) count( $category_trail );
						for ( $i = 0; $category_trail_size > $i; $i++ ) {
							array_push( $breadcrumb, $category_trail[ $i ] );
						}
					}
				}

				// If other post type.
				if ( ! in_array( $post_type, array( 'post', 'page', 'attachment' ), true ) ) {
					$post_type_object = get_post_type_object( $post_type );
					$archive_link     = esc_url( get_post_type_archive_link( $post_type ) );
					$archive_trail    = array( $post_type_object->labels->singular_name => $archive_link );
					array_push( $breadcrumb, $archive_trail );
				}

				// Check for parent page.
				if ( 0 !== $post_parent ) {
					$post_trail[] = array( $post_object->post_title => get_permalink( $post_object ) );
					while ( $post_parent ) {
						$parent       = get_post( $post_parent );
						$post_trail[] = array( get_the_title( $parent->ID ) => esc_url( get_permalink( $parent->ID ) ) );
						$post_parent  = wp_get_post_parent_id( $parent->ID );
					}

					$post_trail      = array_reverse( $post_trail );
					$post_trail_size = (int) count( $post_trail );
					for ( $i = 0; $post_trail_size > $i; $i++ ) {
						array_push( $breadcrumb, $post_trail[ $i ] );
					}
				} else {
					if ( ! is_front_page( $post_object ) ) {
						$breadcrumb[] = array( $post_object->post_title => get_permalink( $post_object ) );
					}
				}
			}

			// If is archive.
			if ( is_archive() ) {
				if ( is_category() || is_tag() || is_tax() ) {
					$term_object   = get_term( $query_object );
					$taxonomy      = $term_object->taxonomy;
					$terms_name    = $term_object->name;
					$term_parent   = $term_object->parent;
					$term_link     = get_term_link( $term_object->term_id );
					$terms_trail[] = array( $term_object->name => get_term_link( $term_object->term_id ) );
					if ( 0 !== $term_parent ) {
						while ( $term_parent ) {
							$term          = get_term( $term_parent, $taxonomy );
							$terms_trail[] = array( $term->name => get_term_link( $term->term_id ) );
							$term_parent   = $term->parent;
						}
						$terms_trail = array_reverse( $terms_trail );
					}
					$terms_trail_size = (int) count( $terms_trail );
					for ( $i = 0; $terms_trail_size > $i; $i++ ) {
						array_push( $breadcrumb, $terms_trail[ $i ] );
					}
				} elseif ( is_author() || et_fb_conditional_tag( 'is_author', $conditional_tags ) ) {
					global $author;
					$author_data  = get_userdata( $author );
					$breadcrumb[] = array( 'Author archive for: ' . $author_data->display_name => '#' );
				} elseif ( is_day() || et_fb_conditional_tag( 'is_day', $conditional_tags ) ) {
					$breadcrumb[] = array( get_the_time( 'Y' ) => get_year_link( get_the_time( 'Y' ) ) );
					$breadcrumb[] = array( get_the_time( 'M' ) . ' Archives' => get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ) );
					$breadcrumb[] = array( get_the_time( 'j' ) . ' ' . get_the_time( 'M' ) . ' Archives' => '#' );
				} elseif ( is_month() || et_fb_conditional_tag( 'is_month', $conditional_tags ) ) {
					$breadcrumb[] = array( get_the_time( 'Y' ) . ' Archives' => get_year_link( get_the_time( 'Y' ) ) );
					$breadcrumb[] = array( get_the_time( 'M' ) . ' Archives' => '#' );
				} elseif ( is_year() || et_fb_conditional_tag( 'is_year', $conditional_tags ) ) {
					$breadcrumb[] = array( get_the_time( 'Y' ) . ' Archives' => '#' );
				} elseif ( is_post_type_archive() || et_fb_conditional_tag( 'is_post_type_archive', $conditional_tags ) ) {
					$post_type        = $wp_query->query_vars['post_type'];
					$post_type_object = get_post_type_object( $post_type );
					$breadcrumb[]     = array( $post_type_object->labels->singular_name => '#' );
				}
			}

			if ( is_paged() ) {
				$current_page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : get_query_var( 'page' );
				$breadcrumb[] = array( 'Page ' . number_format_i18n( absint( $current_page ) ) => '#' );
			}
			if ( is_search() ) {
				$breadcrumb[] = array( 'Search results for: ' . get_search_query() => '#' );
			}
			if ( is_404() ) {
				$breadcrumb[] = array( 'Error 404' => '#' );
			}
		} else {
			$breadcrumb = '';
		}

		return $breadcrumb;
	}

	/**
	 * Render breadcrumb layout one.
	 */
	public static function render_layout_one( $breadcrumb, $args = array() ) {
		$defaults = array(
			'home_link_text' => '',
			'link_target'    => 'off',
			'use_home_icon'  => 'off',
			'home_icon'      => '',
			'hide_home_text' => 'off',
			'enable_fade'    => 'off',
			'fade_range'     => '0.01'
		);

		$args = wp_parse_args( $args, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $args, $key, $default ) );
		}

		$rendered_home_icon = '';
		if ( 'on' === $use_home_icon && ! empty( $home_icon ) ) {
			$rendered_home_icon = sprintf( '<span class="breadcrumb-home-icon et-pb-icon">%1$s</span>', $home_icon );
		}

		$opacity         = 1;
		$opacity_style   = '';
		$breadcrumb_size = (int) esc_attr( count( $breadcrumb ) );

		$breadcrumb_list = '';
		for ( $i = 0; $i < $breadcrumb_size; $i++ ) {

			$breadcrumbs_keys = array_keys( $breadcrumb[ $i ] );
			$title            = $breadcrumbs_keys[0];
			$link             = $breadcrumb[ $i ][ $title ];

			if ( 'on' === $enable_fade && ! empty( $fade_range ) ) {
				$opacity_style = sprintf( 'style="opacity: %1$s;"', esc_attr( $opacity ) );
				$opacity       = ( $opacity > $fade_range ) ? $opacity - floatval( $fade_range ) : $opacity;
			}

			// If home page.
			if ( 0 === $i ) {
				$title = ( ! empty( $title ) ) ? $title : $home_link_text;
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" %6$s>
						<a class="breadcrumb-item dipl-home-page" href="%1$s" property="item" typeof="WebPage" %4$s>
							<span class="breadcrumb-page" property="name">%5$s %2$s</span>
						</a>
						<meta property="position" content="%3$s" />
					</li>',
					$link,
					( 'off' === $hide_home_text ) ? $title : '',
					( $i + 1 ),
					( 'on' === $link_target ) ? 'target="_blank"' : '',
					$rendered_home_icon,
					$opacity_style
				);
			} elseif ( ( $i + 1 ) === $breadcrumb_size ) {
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" %3$s>
						<span class="breadcrumb-page dipl-last-page" property="name">%1$s</span>
						<meta property="position" content="%2$s" />
					</li>',
					$title,
					( $i + 1 ),
					$opacity_style
				);
			} else {
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" %5$s>
						<a class="breadcrumb-item" href="%1$s" property="item" typeof="WebPage" %4$s>
							<span class="breadcrumb-page" property="name">%2$s</span>
						</a>
						<meta property="position" content="%3$s" />
					</li>',
					$link,
					$title,
					( $i + 1 ),
					$link_target,
					$opacity_style
				);
			}
		}

		return $breadcrumb_list;
	}

	/**
	 * Render breadcrumb layout two.
	 */
	public static function render_layout_two( $breadcrumb, $args = array() ) {
		$defaults = array(
			'home_link_text' => '',
			'link_target'    => 'off',
			'use_home_icon'  => 'off',
			'home_icon'      => '',
			'hide_home_text' => 'off',
			'separator_icon' => '',
		);

		$args = wp_parse_args( $args, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $args, $key, $default ) );
		}

		$rendered_home_icon = '';
		if ( 'on' === $use_home_icon && ! empty( $home_icon ) ) {
			$rendered_home_icon = sprintf( '<span class="breadcrumb-home-icon et-pb-icon">%1$s</span>', $home_icon );
		}

		$breadcrumb_size = (int) esc_attr( count( $breadcrumb ) );

		$breadcrumb_list = '';
		for ( $i = 0; $i < $breadcrumb_size; $i++ ) {

			$breadcrumbs_keys = array_keys( $breadcrumb[ $i ] );
			$title            = $breadcrumbs_keys[0];
			$link             = $breadcrumb[ $i ][ $title ];

			// If home page.
			if ( 0 === $i ) {
				$title = ( ! empty( $title ) ) ? $title : $home_link_text;
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" data-icon="%6$s">
						<a class="breadcrumb-item dipl-home-page" href="%1$s" property="item" typeof="WebPage" %4$s>
							<span class="breadcrumb-page" property="name">%5$s %2$s</span>
						</a>
						<meta property="position" content="%3$s" />
					</li>',
					$link,
					( 'off' === $hide_home_text ) ? $title : '',
					( $i + 1 ),
					( 'on' === $link_target ) ? 'target="_blank"' : '',
					$rendered_home_icon,
					$separator_icon
				);
			} elseif ( ( $i + 1 ) === $breadcrumb_size ) {
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" data-icon="%3$s">
						<span class="breadcrumb-page dipl-last-page" property="name">%1$s</span>
						<meta property="position" content="%2$s" />
					</li>',
					$title,
					( $i + 1 ),
					$separator_icon
				);
			} else {
				$breadcrumb_list .= sprintf(
					'<li property="itemListElement" typeof="ListItem" data-icon="%5$s">
						<a class="breadcrumb-item" href="%1$s" property="item" typeof="WebPage" %4$s>
							<span class="breadcrumb-page" property="name">%2$s</span>
						</a>
						<meta property="position" content="%3$s" />
					</li>',
					$link,
					$title,
					( $i + 1 ),
					$link_target,
					$separator_icon
				);
			}
		}

		return $breadcrumb_list;
	}
}
