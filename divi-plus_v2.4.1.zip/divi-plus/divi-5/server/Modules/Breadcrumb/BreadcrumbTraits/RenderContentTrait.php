<?php
namespace DIPL\Modules\Breadcrumb\BreadcrumbTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {
	public static function get_breadcrumb_data( $atts ) {
		global $post;

		$post_id = $atts['current_post_id'];

		// setup_postdata( $post_id );

		// echo "ID<pre>";
		// print_r( $post_id );
		// echo "</pre>";

		// if( is_single( $post_id ) ) {
		// 	echo "<pre>";
		// 	print_r('yes is single');
		// 	echo "</pre>";
		// }

		// if ( is_page( $post_id ) ) {
		// 	echo "<pre>";
		// 	print_r('yes is page');
		// 	echo "</pre>";
		// }

	}

}
