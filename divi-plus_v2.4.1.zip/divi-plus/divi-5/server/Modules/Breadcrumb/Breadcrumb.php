<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\Breadcrumb;
 */
namespace DIPL\Modules\Breadcrumb;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\Breadcrumb\BreadcrumbTraits;

/**
 * Class Breadcrumb
 *
 * @package DIPL\Modules\Breadcrumb
 */
class Breadcrumb implements DependencyInterface {

    use BreadcrumbTraits\RenderContentTrait;
	use BreadcrumbTraits\RenderCallbackTrait;
	use BreadcrumbTraits\ModuleClassnamesTrait;
	use BreadcrumbTraits\ModuleStylesTrait;
	use BreadcrumbTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/breadcrumb';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ Breadcrumb::class, 'render_callback' ] ]
				);
			}
		);
	}
}

