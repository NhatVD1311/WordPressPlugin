<?php
namespace DIPL\Modules\BackgroundSwitcher\BackgroundSwitcherTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use DIPL\Modules\BackgroundSwitcher\BackgroundSwitcher;
use ET\Builder\Packages\Module\Options\Text\TextStyle;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					],
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),
			
			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'description',
			] ),

			// Item style.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_background_switcher_item",
				'attr'      => $attrs['display']['advanced']['itemHeight'] ?? [],
				'property'  => 'height',
				'important' => true
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_background_switcher_item",
				'attr'      => $attrs['display']['advanced']['itemHeight'] ?? [],
				'property'  => 'min-height',
				'important' => true
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_bg_switcher_item_wrap",
				'attr'      => $attrs['display']['advanced']['contentValign'] ?? [],
				'property'  => 'justify-content',
			] ),

			// Other display settings.
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_background_switcher_image::after",
				'attr'      => $attrs['display']['advanced']['overlayBgColor'] ?? [],
				'property'  => 'background-color',
			] ),
			CommonStyle::style( [
				'selector'  => "{$order_class} .dipl_background_switcher_image",
				'attr'      => $attrs['display']['advanced']['transitionDuration'] ?? [],
				'property'  => 'transition-duration',
			] ),
		);

		// Switcher Orientation.
		$switcher_orientation = $attrs['display']['advanced']['switcherOrientation'] ?? [ 'desktop' => [ 'value' => "horizontal" ] ];
		foreach ( $switcher_orientation as &$orientation ) {
			$orientation = str_replace( array( 'horizontal', 'vertical' ), array( 'row', 'column' ), $orientation );
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_background_switcher_inner",
			'attr'      => $switcher_orientation,
			'property'  => 'flex-direction',
		] ) );

		$hover_blur_level = $attrs['display']['advanced']['hoverBlurLevel'] ?? [ 'desktop' => [ 'value' => "5px" ] ];
		$blur_style       = [];
		foreach ( $hover_blur_level as $device => $blur_level ) {
			if ( ! empty( $blur_level['value'] ) ) {
				$hover_blur_level[ $device ] = [ 'value' => sprintf( 'blur( %1$s )', $blur_level['value'] ) ];
			}
		}
		array_push( $styles, CommonStyle::style( [
			'selector'  => "{$order_class} .dipl_background_switcher_item:hover",
			'attr'      => $hover_blur_level,
			'property'  => 'backdrop-filter',
			'important' => true
		] ) );
		
        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
}
