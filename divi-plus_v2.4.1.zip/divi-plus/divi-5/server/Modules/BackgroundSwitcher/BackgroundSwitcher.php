<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BackgroundSwitcher;
 */
namespace DIPL\Modules\BackgroundSwitcher;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BackgroundSwitcher\BackgroundSwitcherTraits;

/**
 * Class BackgroundSwitcher
 *
 * @package DIPL\Modules\BackgroundSwitcher
 */
class BackgroundSwitcher implements DependencyInterface {

	use BackgroundSwitcherTraits\RenderCallbackTrait;
	use BackgroundSwitcherTraits\ModuleClassnamesTrait;
	use BackgroundSwitcherTraits\ModuleStylesTrait;
	use BackgroundSwitcherTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/background-switcher';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BackgroundSwitcher::class, 'render_callback' ] ]
				);
			}
		);
	}
}
