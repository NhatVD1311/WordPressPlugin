<?php
namespace DIPL\Modules\DropdownButtonItem\DropdownButtonItemTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\DropdownButtonItem\DropdownButtonItem;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		// Get attributes.
		$link_text   = $attrs['dropdown']['innerContent']['desktop']['value'] ?? 'Dropdown Item';
		$link_url    = $attrs['dropdown']['advanced']['linkUrl']['desktop']['value'] ?? '';
		$link_target = $attrs['dropdown']['advanced']['linkTarget']['desktop']['value'] ?? 'off';
		
		// Final render output.
		$rendered_output = '';
		if ( ! empty( $link_url ) ) {
			$rendered_output = sprintf(
				'<a href="%1$s"%3$s>%2$s</a>',
				esc_url( $link_url ),
				esc_html( $link_text ),
				( 'on' === $link_target ) ? ' target="_blank"' : ''
			);
		}
		
		$is_first = BlockParserStore::is_first( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent   = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'moduleClassName'     => '',
			'isFirst'             => $is_first,
			'id'                  => $block->parsed_block['id'],
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ DropdownButtonItem::class, 'module_classnames' ],
			'stylesComponent'     => [ DropdownButtonItem::class, 'module_styles' ],
			'scriptDataComponent' => [ DropdownButtonItem::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
