<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\DropdownButtonItem;
 */
namespace DIPL\Modules\DropdownButtonItem;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\DropdownButtonItem\DropdownButtonItemTraits;

/**
 * Class DropdownButtonItem
 *
 * @package DIPL\Modules\DropdownButtonItem
 */
class DropdownButtonItem implements DependencyInterface {

	use DropdownButtonItemTraits\RenderCallbackTrait;
	use DropdownButtonItemTraits\ModuleClassnamesTrait;
	use DropdownButtonItemTraits\ModuleStylesTrait;
	use DropdownButtonItemTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/dropdown-button-item';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ DropdownButtonItem::class, 'render_callback' ] ]
				);
			}
		);
	}
}
