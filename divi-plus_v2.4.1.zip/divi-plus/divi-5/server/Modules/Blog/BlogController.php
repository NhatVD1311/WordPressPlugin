<?php
/**
 * Blog Module Controller.
 *
 * @package DIPL\Modules\Blog;
 */
namespace DIPL\Modules\Blog;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Controllers\RESTController;
use ET\Builder\Framework\UserRole\UserRole;
use DIPL\Modules\Blog\Blog;
use WP_REST_Request;
use WP_REST_Response;


/**
 * Class BlogController
 *
 * @package DIPL\Modules\WooProductGallery
 */
class BlogController extends RESTController {

	/**
	 * Return data for the Dynamic Module.
	 *
	 * @param WP_REST_Request $request REST request object.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public static function index( WP_REST_Request $request ): WP_REST_Response {
		$args = array(
			'layout'              => $request->get_param( 'layout' ),
            'posts_number'        => $request->get_param( 'posts_number' ),
			'offset_number'       => $request->get_param( 'offset_number' ),
			'include_categories'  => $request->get_param( 'include_categories' ),
			'post_order'          => $request->get_param( 'post_order' ),
			'post_order_by'       => $request->get_param( 'post_order_by' ),
			'ignore_sticky_posts' => $request->get_param( 'ignore_sticky_posts' ),

			'show_thumbnail'      => $request->get_param( 'show_thumbnail' ),
			'featured_image_size' => $request->get_param( 'featured_image_size' ),
			'show_content'        => $request->get_param( 'show_content' ),
			'excerpt_length'      => $request->get_param( 'excerpt_length' ),
			'show_author'         => $request->get_param( 'show_author' ),
			'show_date'           => $request->get_param( 'show_date' ),
			'date_format'         => $request->get_param( 'date_format' ),
			'show_categories'     => $request->get_param( 'show_categories' ),
			'show_comments'       => $request->get_param( 'show_comments' ),

			'show_read_more'      => $request->get_param( 'show_read_more' ),
			'read_more_text'      => $request->get_param( 'read_more_text' ),
			'title_level'         => $request->get_param( 'title_level' ),
		);

		$response = [
			'data' => Blog::get_blog_output( $args ),
		];

		return self::response_success( $response );
	}

	/**
	 * Index action arguments.
	 * Endpoint arguments as used in `register_rest_route()`.
	 *
	 * @return array
	 */
	public static function index_args(): array {
		return [
			'layout' => [
				'type'              => 'string',
				'default'           => 'layout1',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'posts_number' => [
				'type'              => 'string',
				'default'           => '10',
				'sanitize_callback' => function( $value, $request, $param ) {
					return intval( $value );
				},
			],
			'offset_number' => [
				'type'              => 'string',
				'default'           => '0',
				'sanitize_callback' => function( $value, $request, $param ) {
					return intval( $value );
				},
			],
			'include_categories' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'post_order' => [
				'type'              => 'string',
				'default'           => 'DESC',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'post_order_by' => [
				'type'              => 'string',
				'default'           => 'date',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'ignore_sticky_posts' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_thumbnail' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'featured_image_size' => [
				'type'              => 'string',
				'default'           => 'large',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_content' => [
				'type'              => 'string',
				'default'           => 'off',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'excerpt_length' => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_author' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_date' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'date_format' => [
				'type'              => 'string',
				'default'           => 'M j, Y',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_categories' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_comments' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'show_read_more' => [
				'type'              => 'string',
				'default'           => 'on',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'read_more_text' => [
				'type'              => 'string',
				'default'           => esc_html__( 'Read more', 'divi-plus' ),
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
			'title_level' => [
				'type'              => 'string',
				'default'           => 'h2',
				'sanitize_callback' => function( $value, $request, $param ) {
					return sanitize_text_field( $value );
				},
			],
		];
	}

	/**
	 * Index action permission.
	 * Endpoint permission callback as used in `register_rest_route()`.
	 *
	 * @return bool
	 */
	public static function index_permission(): bool {
		return UserRole::can_current_user_use_visual_builder();
	}
}
