<?php
namespace DIPL\Modules\Blog\BlogTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\Blog\Blog;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$layout             = $attrs['layout']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$include_categories = $attrs['query']['advanced']['includeCategories']['desktop']['value'] ?? [];

		// Attributes.
		$blogAttrs = array(
			'layout'              => $layout,
			'posts_number'        => $attrs['query']['advanced']['postsNumber']['desktop']['value'] ?? '10',
			'offset_number'       => $attrs['query']['advanced']['offsetNumber']['desktop']['value'] ?? '0',
			'include_categories'  => is_array( $include_categories ) ? implode( ',', $include_categories ) : $include_categories,
			'post_order'          => $attrs['query']['advanced']['postOrder']['desktop']['value'] ?? 'DESC',
			'post_order_by'       => $attrs['query']['advanced']['postOrderBy']['desktop']['value'] ?? 'date',
			'ignore_sticky_posts' => $attrs['query']['advanced']['ignoreStickyPosts']['desktop']['value'] ?? 'off',

			'show_thumbnail'      => $attrs['display']['advanced']['showThumbnail']['desktop']['value'] ?? 'on',
			'featured_image_size' => $attrs['display']['advanced']['featuredImageSize']['desktop']['value'] ?? 'large',
			'show_content'        => $attrs['display']['advanced']['showContent']['desktop']['value'] ?? 'off',
			'excerpt_length'      => $attrs['display']['advanced']['excerptLength']['desktop']['value'] ?? '',
			'show_author'         => $attrs['display']['advanced']['showAuthor']['desktop']['value'] ?? 'on',
			'show_date'           => $attrs['display']['advanced']['showDate']['desktop']['value'] ?? 'on',
			'post_date'           => $attrs['display']['advanced']['dateFormat']['desktop']['value'] ?? 'M j, Y',
			'show_categories'     => $attrs['display']['advanced']['showCategories']['desktop']['value'] ?? 'on',
			'show_comments'       => $attrs['display']['advanced']['showComments']['desktop']['value'] ?? 'on',

			'show_read_more'      => $attrs['readMore']['advanced']['show']['desktop']['value'] ?? 'on',
			'read_more_text'      => $attrs['readMore']['innerContent']['desktop']['value']['text'] ?? esc_html__( 'Read more', 'divi-plus' ),
			'title_level'         => $attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h2',
		);

		// Get items.
		$response = Blog::get_blog_output( $blogAttrs );

		// If response.
		$rendered_output = '';
		if ( ! empty( $response['items'] ) ) {

			// Other attrs.
			$use_masonry     = $attrs['layout']['advanced']['useMasonry']['desktop']['value'] ?? 'off';
			$show_pagination = $attrs['pagination']['advanced']['show']['desktop']['value'] ?? 'off';
			$show_prev_next  = $attrs['pagination']['advanced']['showPrevNext']['desktop']['value'] ?? 'off';

			// some themes do not include these styles/scripts so we need to enqueue them in this module to support audio post format.
			wp_enqueue_style( 'wp-mediaelement' );
			wp_enqueue_script( 'wp-mediaelement' );

			// include easyPieChart which is required for loading Blog module content via ajax correctly.
			wp_enqueue_script( 'easypiechart' );

			// include ET Shortcode scripts.
			wp_enqueue_script( 'et-shortcodes-js' );

			// remove all filters from WP audio shortcode to make sure current theme doesn't add any elements into audio module.
			remove_all_filters( 'wp_audio_shortcode_library' );
			remove_all_filters( 'wp_audio_shortcode' );
			remove_all_filters( 'wp_audio_shortcode_class' );

			$use_masonry = $attrs['layout']['advanced']['useMasonry']['desktop']['value'] ?? 'off';

			// Get items.
			$items = et_core_esc_previously( implode( '', $response['items'] ) );

			// Isotope gutter.
			$gutter = '';
			if ( 'on' === $use_masonry ) {
				$items = sprintf(
					'<div class="dipl_blog_isotope_container">
						<div class="dipl_blog_isotope_item_gutter"></div>%1$s
					</div>',
					et_core_esc_previously( $items )
				);
			}

			// Final output,
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'childrenSanitizer' => 'et_core_esc_previously',
				'attributes'        => array(
					'class' => 'dipl_blog_wrapper dipl_blog_' . esc_html( $layout ),
				),
				'children'          => et_core_esc_previously( $items )
			] );

			// Paginatin.
			if ( 'on' === $show_pagination ) {
				// Optional attrs.
				$pagin_attrs = array_combine(
					array_map( fn($key) => 'data-' . $key, array_keys( $blogAttrs ) ),
					$blogAttrs
				);
				if ( 'on' === $show_prev_next ) {
					$pagin_attrs['data-show_prev_next'] = esc_attr( $show_prev_next );
					$pagin_attrs['data-next_text']      = $attrs['pagination']['advanced']['nextText']['desktop']['value'] ?? esc_html__( 'Next', 'divi-plus' );
					$pagin_attrs['data-prev_text']      = $attrs['pagination']['advanced']['prevText']['desktop']['value'] ?? esc_html__( 'Prev', 'divi-plus' );
				}

				// Nonce field.
				$nonce_field = sprintf(
					'<input type="hidden" id="dipl_blog_ajax_nonce" class="dipl_blog_ajax_nonce" value="%1$s" />',
					wp_create_nonce( 'elicus-divi-plus-blog-nonce' )
				);

				// Add pagination to render output.
				$rendered_output .= HTMLUtility::render( [
					'tag'               => 'div',
					'childrenSanitizer' => 'et_core_esc_previously',
					'attributes'        => array_merge( array(
						'class'                  => 'dipl_blog_pagination_wrapper',
						'data-total_pages'       => $response['total_pages'] ?? '1',
						'data-is_user_logged_in' => is_user_logged_in(),
						'data-is_single'         => is_single(),
						'data-current_post_id'   => is_single() ? intval( get_the_ID() ) : intval( 0 )
					), $pagin_attrs ),
					'children'          => '<ul></ul>' . et_core_esc_previously( $nonce_field )
				] );
			}
		} else {
			// Empty items text.
			$no_result_text  = $attrs['content']['advanced']['noResultText']['desktop']['value'] ?? '';
			$rendered_output = HTMLUtility::render( [
				'tag'               => 'div',
				'childrenSanitizer' => 'et_core_esc_previously',
				'attributes'        => array( 'class' => 'entry' ),
				'children'          => et_core_esc_previously( $no_result_text )
			] );
		}
		
        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ Blog::class, 'module_classnames' ],
			'stylesComponent'     => [ Blog::class, 'module_styles' ],
			'scriptDataComponent' => [ Blog::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
    }
}
