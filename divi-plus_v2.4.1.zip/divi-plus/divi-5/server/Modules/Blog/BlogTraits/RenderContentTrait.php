<?php
namespace DIPL\Modules\Blog\BlogTraits;

if ( ! defined( 'ABSPATH' ) ) {
  die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use \WP_Query;

trait RenderContentTrait {
	public static function get_blog_output( $atts = array() ) {
		$defaults = array(
			'layout'              => 'layout1',
			'posts_number'        => '10',
			'offset_number'       => '0',
			'include_categories'  => '',
			'post_order'          => 'DESC',
			'post_order_by'       => 'date',
			'ignore_sticky_posts' => 'off',

			'show_thumbnail'      => 'on',
			'featured_image_size' => 'large',
			'show_content'        => 'off',
			'excerpt_length'      => '',
			'show_author'         => 'on',
			'show_date'           => 'on',
			'post_date'           => 'M j, Y',
			'show_categories'     => 'on',
			'show_comments'       => 'on',

			'show_read_more'      => 'on',
			'read_more_text'      => esc_html__( 'Read more', 'divi-plus' ),
			'title_level'         => 'h2',
			'is_user_logged_in'   => false,
			'is_single'           => false,
		);
		$args = wp_parse_args( $atts, $defaults );
		foreach ( $defaults as $key => $default ) {
			${$key} = esc_html( et_()->array_get( $atts, $key, $default ) );
		}

		// Excerpt length.
		if ( 'on' !== $show_content ) {
			$excerpt_length = ( '' === $excerpt_length ) ? 270 : intval( $excerpt_length );
		}

		$processed_title_level = et_pb_process_header_level( $title_level, 'h2' );
		$processed_title_level = esc_html( $processed_title_level );

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => intval( $posts_number ),
			'post_status'    => 'publish',
			'offset'         => 0,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( $is_user_logged_in ) {
			$args['post_status'] = array( 'publish', 'private' );
		}
		if ( 'on' === $ignore_sticky_posts ) {
			$query_args['ignore_sticky_posts'] = true;
		}
		if ( '' !== $include_categories ) {
			$args['cat'] = sanitize_text_field( $include_categories );
		}
		if ( '' !== $offset_number && ! empty( $offset_number ) ) {
			$args['offset'] = intval( $offset_number );
		}
		if ( 0 !== $args['offset'] && -1 === intval( $args['posts_per_page'] ) ) {
			$count_posts            = wp_count_posts( 'post', 'readable' );
			$published_posts        = $count_posts->publish;
			$args['posts_per_page'] = intval( $published_posts );
		}
		if ( isset( $post_order_by ) && '' !== $post_order_by ) {
			$args['orderby'] = sanitize_text_field( $post_order_by );
		}
		if ( isset( $post_order ) && '' !== $post_order ) {
			$args['order'] = sanitize_text_field( $post_order );
		}
		if ( $is_single && ! isset( $args['post__not_in'] ) ) {
			$args['post__not_in'] = array( intval( get_the_ID() ) );
		}
		
		$query = new WP_Query( $args );

		$total_pages  = 1;
		$output_array = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();

				$post_id        = get_the_ID();
				$thumb          = dipl_get_post_thumbnail( $post_id, esc_html( $featured_image_size ), 'dipl_blog_post_image' );
				$no_thumb_class = ( '' === $thumb || 'off' === $show_thumbnail ) ? ' dipl_blog_post_no_thumb' : '';

				$post_classes   = array_map( 'sanitize_html_class', get_post_class( 'dipl_blog_post' . $no_thumb_class ) );
				$post_classes   = implode( ' ', $post_classes );

				$read_more_button = sprintf(
					'<div class="et_pb_button_wrapper dipl_blog_post_read_more_link">
						<a href="%1$s" class="et_pb_button">%2$s</a>
					</div>',
					esc_url( get_permalink( $post_id ) ),
					sprintf( esc_html__( '%s', 'divi-plus' ), esc_html( $read_more_text ) )
				);

				$output = '';
				if ( file_exists( get_stylesheet_directory() . '/divi-plus/layouts/blog/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include get_stylesheet_directory() . '/divi-plus/layouts/blog/' . sanitize_file_name( $layout ) . '.php';
				} elseif ( file_exists( ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/Blog/layouts/' . sanitize_file_name( $layout ) . '.php' ) ) {
					include ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/Blog/layouts/' . sanitize_file_name( $layout ) . '.php';
				}

				array_push( $output_array, $output );
			}

			// Calculate total pages.
			if ( -1 === intval( $posts_number ) ) {
				$total_pages = 1;
			} else if ( '' !== $offset_number && ! empty( $offset_number ) ) {
				$total_pages = intval( ceil( ( $query->found_posts - $offset_number ) / intval( $posts_number ) ) );
			} else {
				$total_pages = intval( ceil( $query->found_posts / intval( $posts_number ) ) );
			}

			// Reset wp post query.
			wp_reset_postdata();
		}

		return array(
			'success'     => true,
			'items'       => $output_array,
			'total_pages' => $total_pages,
		);
	}
}
