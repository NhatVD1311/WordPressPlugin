<?php
namespace DIPL\Modules\Blog\BlogTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DIPL\Modules\Blog\Blog;

trait ModuleStylesTrait {
	
	use CustomCssTrait;

    /**
	 * Child Module's style components.
	 *
	 * This function is equivalent of JS function ModuleStyles located in
	 * src/components/child-module/styles.tsx.
	 *
	 * @param array $args {
	 *     An array of arguments.
	 *
	 * @type string $id Module ID. In VB, the ID of module is UUIDV4. In FE, the ID is order index.
	 * @type string $name Module name.
	 * @type string $attrs Module attributes.
	 * @type string $parentAttrs Parent attrs.
	 * @type string $orderClass Selector class name.
	 * @type string $parentOrderClass Parent selector class name.
	 * @type string $wrapperOrderClass Wrapper selector class name.
	 * @type string $settings Custom settings.
	 * @type string $state Attributes state.
	 * @type string $mode Style mode.
	 * @type ModuleElements $elements ModuleElements instance.
	 * }
	 * @since 2.0.0
	 */
	public static function module_styles( $args ) {
		$attrs        = $args['attrs'] ?? [];
		$order_class  = $args['orderClass'];
		$elements     = $args['elements'];
		$settings     = $args['settings'] ?? [];

		// Styles.
		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $order_class,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			$elements->style( [
				'attrName' => 'singlePost',
			] ),
			$elements->style( [
				'attrName' => 'title',
			] ),
			$elements->style( [
				'attrName' => 'body',
			] ),
			$elements->style( [
				'attrName' => 'postContent',
			] ),	
		);

		$layout            = $attrs['layout']['advanced']['layout']['desktop']['value'] ?? 'layout1';
		$use_masonry       = $attrs['layout']['advanced']['useMasonry']['desktop']['value'] ?? 'off';

		// Number of column, width and column spacing calculation.
		$number_of_columns = $attrs['layout']['advanced']['numberOfColumns'] ?? [ "desktop" => [ "value" => "3" ] ];
		$column_spacing    = $attrs['layout']['advanced']['columnSpacing'] ?? [ "desktop" => [ "value" => "15px" ] ];

		$number_of_columns['tablet'] = ! empty( $number_of_columns['tablet']['value'] ) ? $number_of_columns['tablet'] : $number_of_columns['desktop'];
		$number_of_columns['phone']  = ! empty( $number_of_columns['phone']['value'] ) ? $number_of_columns['phone'] : $number_of_columns['tablet'];
		$column_spacing['tablet']    = ! empty( $column_spacing['tablet']['value'] ) ? $column_spacing['tablet'] : $column_spacing['desktop'];
		$column_spacing['phone']     = ! empty( $column_spacing['phone']['value'] ) ? $column_spacing['phone'] : $column_spacing['tablet'];

		$breakpoints = array( 'desktop', 'tablet', 'phone' );
		$width       = array();
		$item_margin = array();
		$wrap_margin = array();
		foreach ( $breakpoints as $breakpoint ) {
			if ( 1 === absint( $number_of_columns[$breakpoint]['value'] ) ) {
				$width[$breakpoint]       = [ 'value' => '100%' ];
				$item_margin[$breakpoint] = [ 'value' => '0px' ];
				$wrap_margin[$breakpoint] = [ 'value' => '0px' ];
			} else {
				$divided_width = 100 / absint( $number_of_columns[$breakpoint]['value'] );
				if ( 0.0 !== floatval( $column_spacing[$breakpoint]['value'] ) ) {
					$gutter = $column_spacing[ $breakpoint ]['value'];
					$width[$breakpoint]       = [ 'value' => 'calc(' . $divided_width . '% - ' . $gutter . ')' ];
					$item_margin[$breakpoint] = [ 'value' => 'calc( ' . $column_spacing[ $breakpoint ]['value'] . '/2 )' ];
					$wrap_margin[$breakpoint] = [ 'value' => 'calc( -' . $column_spacing[ $breakpoint ]['value'] . '/2 )' ];
				} else {
					$width[$breakpoint]       = [ 'value' => $divided_width . '%' ];
					$item_margin[$breakpoint] = [ 'value' => '0px' ];
					$wrap_margin[$breakpoint] = [ 'value' => '0px' ];
				}
			}
		}

		// Layout 2 is list view, no column spacing there.
		if ( 'layout2' !== $layout ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_post",
				'attr'     => $width,
				'property' => 'width'
			] ) );

			// If mansonry.
			if ( 'on' === $use_masonry ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_isotope_item_gutter",
					'attr'     => $column_spacing,
					'property' => 'width'
				] ) );
			} else {
				// Item margin.
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post",
					'attr'     => $item_margin,
					'property' => 'margin-left'
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post",
					'attr'     => $item_margin,
					'property' => 'margin-right'
				] ) );

				// Wrapper margin.
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_wrapper",
					'attr'     => $wrap_margin,
					'property' => 'margin-left'
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_wrapper",
					'attr'     => $wrap_margin,
					'property' => 'margin-right'
				] ) );
			}
		}

		// If not masonry with any layout.
		if ( 'on' !== $use_masonry ) {
			array_push( $styles, CommonStyle::style( [
				'selector'            => "{$order_class} .dipl_blog_wrapper",
				'attr'                => $number_of_columns,
				'declarationFunction' => function() {
					return "display: flex; flex-wrap: wrap;";
				}
			] ) );
		}

		// Maring bottom.
		array_push( $styles, CommonStyle::style( [
			'selector' => "{$order_class} .dipl_blog_post",
			'attr'     => $attrs['layout']['advanced']['rowSpacing'] ?? [],
			'property' => 'margin-bottom'
		] ) );

		// Thumbnail.
		$show_thumbnail = $attrs['display']['advanced']['showThumbnail']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_thumbnail ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'image',
			] ) );
		}

		// Post meta.
		$show_author   = $attrs['display']['advanced']['showAuthor']['desktop']['value'] ?? 'on';
		$show_date     = $attrs['display']['advanced']['showDate']['desktop']['value'] ?? 'on';
		$show_comments = $attrs['display']['advanced']['showComments']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_author || 'on' === $show_date || 'on' === $show_comments ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'postMeta',
			] ) );

			// Post meta icons.
			if ( 'layout2' === $layout ) {
				array_push( $styles, $elements->style( [
					'attrName' => 'postMetaIcon',
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post_meta .et-pb-icon",
					'attr'     => $attrs['postMetaIcon']['advanced']['fontsize'] ?? [],
					'property' => 'font-size'
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post_meta .et-pb-icon",
					'attr'     => $attrs['postMetaIcon']['advanced']['color'] ?? [],
					'property' => 'color'
				] ) );
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post_meta .et-pb-icon",
					'attr'     => $attrs['postMetaIcon']['advanced']['backgroundColor'] ?? [],
					'property' => 'background-color'
				] ) );
			}

			// Meta seperator color.
			if ( 'layout1' === $layout || 'layout2' === $layout ) {
				array_push( $styles, CommonStyle::style( [
					'selector' => "{$order_class} .dipl_blog_post_meta",
					'attr'     => $attrs['postMeta']['advanced']['separatorColor'] ?? [],
					'property' => 'border-top-color'
				] ) );
			}
		}

		// Categories.
		$show_categories = $attrs['display']['advanced']['showCategories']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_categories ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'category',
			] ) );
		}

		// Pagination.
		$show_pagination = $attrs['pagination']['advanced']['show']['desktop']['value'] ?? 'off';
		if ( 'on' === $show_pagination ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_pagination_wrapper li a",
				'attr'     => $attrs['pagination']['advanced']['linkBgColor'] ?? [],
				'property' => 'background-color'
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_pagination_wrapper li a",
				'attr'     => $attrs['pagination']['advanced']['linkColor'] ?? [],
				'property' => 'color'
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_pagination_wrapper li.active a",
				'attr'     => $attrs['pagination']['advanced']['activeLinkBgColor'] ?? [],
				'property' => 'background-color'
			] ) );
			array_push( $styles, CommonStyle::style( [
				'selector' => "{$order_class} .dipl_blog_pagination_wrapper li.active a",
				'attr'     => $attrs['pagination']['advanced']['activeLinkColor'] ?? [],
				'property' => 'color'
			] ) );
		}

		// Read more.
		$show_read_more = $attrs['readMore']['advanced']['show']['desktop']['value'] ?? 'on';
		if ( 'on' === $show_read_more ) {
			array_push( $styles, $elements->style( [
				'attrName' => 'readMore',
			] ) );
		}

        Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles
		] );
    }
};
