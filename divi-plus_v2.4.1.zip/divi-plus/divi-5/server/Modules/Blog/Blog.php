<?php
/**
 * Blog Module class.
 *
 * @package DIPL\Modules\Blog;
 */
namespace DIPL\Modules\Blog;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\Blog\BlogTraits;

/**
 * Class Blog
 *
 * @package DIPL\Modules\Blog
 */
class Blog implements DependencyInterface {

	use BlogTraits\RenderContentTrait;
	use BlogTraits\RenderCallbackTrait;
	use BlogTraits\ModuleClassnamesTrait;
	use BlogTraits\ModuleStylesTrait;
	use BlogTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/blog';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ Blog::class, 'render_callback' ] ]
				);
			}
		);
	}
}
