<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookComments;
 */

namespace DIPL\Modules\FacebookComments;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookComments\FacebookCommentsTraits;

/**
 * Class FacebookComments
 *
 * @package DIPL\Modules\FacebookComments
 */
class FacebookComments implements DependencyInterface {

	use FacebookCommentsTraits\RenderCallbackTrait;
	use FacebookCommentsTraits\ModuleClassnamesTrait;
	use FacebookCommentsTraits\ModuleStylesTrait;
	use FacebookCommentsTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-comments';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FacebookComments::class, 'render_callback' ] ]
				);
			}
		);
	}
}
