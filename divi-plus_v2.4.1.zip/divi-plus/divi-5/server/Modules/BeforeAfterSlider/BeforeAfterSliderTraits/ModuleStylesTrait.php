<?php
namespace DIPL\Modules\BeforeAfterSlider\BeforeAfterSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

trait ModuleStylesTrait {

	use CustomCssTrait;

	public static function module_styles( $args ) {
		$attrs       = $args['attrs'] ?? [];
		$orderClass  = $args['orderClass'];
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? [];

		$showBeforeLabel              = $attrs['beforeLabel']['advanced']['enable'];
		$showAfterLabel               = $attrs['afterLabel']['advanced']['enable'];
		$beforeLabel                  = array_key_exists( 'innerContent', $attrs['beforeLabel'] ) ? $attrs['beforeLabel']['innerContent']['desktop']['value'] : '';
		$afterLabel                   = array_key_exists( 'innerContent', $attrs['afterLabel'] ) ? $attrs['afterLabel']['innerContent']['desktop']['value'] : '';
		$overlayType                  = $attrs['overlay']['advanced']['type']['desktop']['value'];
		$beforeLabelBg                = $attrs['beforeLabel']['advanced']['backgroundColor'] ?? [];
		$afterLabelBg                 = $attrs['afterLabel']['advanced']['backgroundColor'] ?? [];
		$showSliderOverlay            = $attrs['overlay']['advanced']['use']['desktop']['value'] ?? '';
		$sliderOverlayType            = $attrs['overlay']['advanced']['type']['desktop']['value'] ?? '';
		$overlayGradientType          = $attrs['overlay']['advanced']['gradientType']['desktop']['value'] ?? 'linear-gradient';
		$overlayGradientColor1        = $attrs['overlay']['advanced']['gradientColor1']['desktop']['value'] ?? '';
		$overlayGradientColor2        = $attrs['overlay']['advanced']['gradientColor2']['desktop']['value'] ?? '';
		$overlayLinearDirection       = $attrs['overlay']['advanced']['linearDirection']['desktop']['value'] ?? '';
		$overlayRadialDirection       = $attrs['overlay']['advanced']['radialDirection']['desktop']['value'] ?? '';
		$overlayGradientStartPosition = $attrs['overlay']['advanced']['gradientStartPosition']['desktop']['value'] ?? '';
		$overlayGradientEndPosition   = $attrs['overlay']['advanced']['gradientEndPosition']['desktop']['value'] ?? '';
		$showBeforeLabelOnHover       = $attrs['beforeLabel']['advanced']['enableOnHover'] ?? [];
		$showAfterLabelOnHover        = $attrs['afterLabel']['advanced']['enableOnHover'] ?? [];

		$styles = array(
			// Element: Module.
			$elements->style( [
				'attrName'   => 'module',
				'styleProps' => [
					'disabledOn' => [
						'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
					]
				],
			] ),
			CssStyle::style( [
				'selector'  => $orderClass,
				'attr'      => $attrs['css'] ?? [],
				'cssFields' => self::custom_css(),
			] ),

			CommonStyle::style( [
				'selector'  => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-handle",
				'attr'      => $attrs['slider']['advanced']['handleColor'] ?? [],
				'important' => true,
				'property'  => 'border-color'
			] ),
			CommonStyle::style( [
				'selector'  => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-handle::before, " . $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-handle::after",
				'attr'      => $attrs['slider']['advanced']['handleColor'] ?? [],
				'important' => true,
				'property'  => 'background'
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-right-arrow",
				'attr'     => $attrs['slider']['advanced']['handleColor'] ?? [],
				'property' => 'border-left-color'
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-left-arrow",
				'attr'     => $attrs['slider']['advanced']['handleColor'] ?? [],
				'property' => 'border-right-color'
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-up-arrow",
				'attr'     => $attrs['slider']['advanced']['handleColor'] ?? [],
				'property' => 'border-bottom-color'
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-down-arrow",
				'attr'     => $attrs['slider']['advanced']['handleColor'] ?? [],
				'property' => 'border-top-color'
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .twentytwenty-before-label:before",
				'attr'     => $beforeLabelBg,
				'property' => "background"
			] ),
			CommonStyle::style( [
				'selector' => $orderClass . " .twentytwenty-after-label:before",
				'attr'     => $afterLabelBg,
				'property' => "background"
			] ),
			CommonStyle::style( [
				'selector'            => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-overlay .twentytwenty-before-label",
				'attr'                => $showBeforeLabel,
				'declarationFunction' => function ( $attrValue ) {
					$attrValue    = $attrValue['attrValue'];
					$declarations = new StyleDeclarations( [
						'returnType'=> 'string'
					] );

					if ( 'on' === $attrValue ) {
						$declarations->add( 'opacity', '1' );
					} else {
						$declarations->add( 'opacity', '0' );
					}

					return $declarations->value();
				}
			] ),
			CommonStyle::style( [
				'selector'            => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-after-label",
				'attr'                => $showAfterLabel,
				'declarationFunction' => function ( $attrValue ) {
					$attrValue = $attrValue['attrValue'];
					$declarations = new StyleDeclarations( [
						'returnType' => 'string'
					] );

					if ('on' === $attrValue) {
						$declarations->add('opacity', '1');
					} else {
						$declarations->add('opacity', '0');
					}

					return $declarations->value();
				}
			] ),
			CommonStyle::style( [
				'selector'            => $orderClass . " .twentytwenty-before-label",
				'attr'                => $showBeforeLabelOnHover,
				'important'           => true,
				'declarationFunction' => function ( $attrValue ) use ($showBeforeLabel) {
					$attrValue    = $attrValue['attrValue'];
					$declarations = new StyleDeclarations([
						'returnType' => 'string',
						'important'  => [
							'opacity' => '1',
							'opacity' => '0',
						]
					] );

					if ( 'on' === $showBeforeLabel['desktop']['value'] ) {
						if ('on' === $attrValue) {
							$declarations->add( 'opacity', '0 !important' );
						} else {
							$declarations->add( 'opacity', '1 !important' );
						}
					}

					return $declarations->value();
				}
			] ),
			CommonStyle::style( [
				'selector'            => $orderClass . " .twentytwenty-after-label",
				'attr'                => $showAfterLabelOnHover,
				'important'           => true,
				'declarationFunction' => function ( $attrValue ) use ($showAfterLabel) {
					$attrValue    = $attrValue['attrValue'];
					$declarations = new StyleDeclarations( [
						'returnType' => 'string',
						'important' => [
						'opacity' => '1',
						'opacity' => '0',
						]
					] );

					if ( 'on' === $showAfterLabel['desktop']['value'] ) {
						if ( 'on' === $attrValue ) {
							$declarations->add( 'opacity', '0 !important' );
						} else {
							$declarations->add( 'opacity', '1 !important' );
						}
					}

					return $declarations->value();
				}
			] ),
			// Element: Content wrapper.
			$elements->style( [
				'attrName' => 'beforeLabel',
			] ),
		);

		if ( 'on' === $showSliderOverlay ) {
			array_push( $styles, CommonStyle::style( [
				'selector' => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-overlay:hover",
				'attr'     => $attrs['overlay']['advanced']['color'] ?? [],
				'property' => "background-color"
			] ) );
			if ( 'gradient' === $overlayType ) {
				$gradientType = $overlayGradientType;
				if ( 'linear-gradient' === $gradientType ) {
					$gradient = "linear-gradient( ".$overlayLinearDirection.", ". $overlayGradientColor1." ".$overlayGradientStartPosition.", ".$overlayGradientColor2." ".$overlayGradientEndPosition." )";
					array_push( $styles, CommonStyle::style( [
						'selector'            => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-overlay:hover, " . $orderClass . " .dipl-before-after-slider-wrapper .dipl-image-wrapper:has(.twentytwenty-handle:hover) .twentytwenty-overlay ",
						'attr'                => $attrs['overlay']['advanced']['gradientColor1'],
						'declarationFunction' => function ( $attrValue ) use($gradient) {
							$attrValue    = $attrValue['attrValue'];
							$declarations = new StyleDeclarations( [
								'returnType' => 'string',
								'important'  => [
									'background-image' => true
								]
							] );
		
							$declarations->add( 'background-image', $gradient );
		
							return $declarations->value();
						} 
					] ) );
				} else if ( 'radial-gradient' === $gradientType ) {
					$gradient = "radial-gradient( circle at ".$overlayRadialDirection.", ".$overlayGradientColor1." ". $overlayGradientStartPosition.", ".$overlayGradientColor2." ". $overlayGradientEndPosition." )";
					array_push( $styles, CommonStyle::style( [
						'selector'            => $orderClass . " .dipl-before-after-slider-wrapper .twentytwenty-overlay:hover, " . $orderClass . " .dipl-before-after-slider-wrapper .dipl-image-wrapper:has(.twentytwenty-handle:hover) .twentytwenty-overlay ",
						'attr'                => $attrs['overlay']['advanced']['gradientColor1'],
						'declarationFunction' => function ( $attrValue ) use($gradient) {
							$attrValue    = $attrValue['attrValue'];
							$declarations = new StyleDeclarations( [
								'returnType'=> 'string',
								'important'  => [
									'background-image' => true
								]
							] );
		
							$declarations->add( 'background-image', $gradient );
		
							return $declarations->value;
						}
					] ) );
				}
			}
		}

		Style::add( [
			'id'            => $args['id'],
			'name'          => $args['name'],
			'orderIndex'    => $args['orderIndex'],
			'storeInstance' => $args['storeInstance'],
			'styles'        => $styles,
		] );
	}
}
