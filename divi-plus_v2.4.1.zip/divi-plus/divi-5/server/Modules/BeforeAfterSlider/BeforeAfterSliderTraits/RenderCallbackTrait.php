<?php
namespace DIPL\Modules\BeforeAfterSlider\BeforeAfterSliderTraits;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use DIPL\Modules\BeforeAfterSlider\BeforeAfterSlider;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Module;

trait RenderCallbackTrait {
    public static function render_callback( $attrs, $content, $block, $elements ) {

        $showBeforeLabel              = $attrs['beforeLabel']['advanced']['enable']['desktop']['value'];
        $showAfterLabel               = $attrs['afterLabel']['advanced']['enable']['desktop']['value'];
        $beforeLabel                  = array_key_exists( 'innerContent', $attrs['beforeLabel'] ) ? $attrs['beforeLabel']['innerContent']['desktop']['value'] : '';
        $afterLabel                   = array_key_exists( 'innerContent', $attrs['afterLabel'] ) ? $attrs['afterLabel']['innerContent']['desktop']['value'] : '';
        $beforeLabelBg                = array_key_exists( 'beforeLabelBg', $attrs['beforeLabel'] ) ? $attrs['beforeLabel']['decoration']['background']['desktop']['value']['color'] : '';
        $afterLabelBg                 = array_key_exists( 'afterLabelBg', $attrs['afterLabel'] ) ? $attrs['afterLabel']['decoration']['background']['desktop']['value']['color'] : '';
        $showSliderOverlay            = $attrs['overlay']['advanced']['use']['desktop']['value'];
        $sliderOverlayType            = $attrs['overlay']['advanced']['type']['desktop']['value'];
        $sliderOverlayBgColor         = $attrs['overlay']['advanced']['color']['desktop']['value'];
        $overlayGradientType          = $attrs['overlay']['advanced']['gradientType']['desktop']['value'];
        $overlayGrandientColor1       = $attrs['overlay']['advanced']['gradientColor1']['desktop']['value'];
        $overlayGrandientColor2       = $attrs['overlay']['advanced']['gradientColor2']['desktop']['value'];
        $overlayLinearDirection       = $attrs['overlay']['advanced']['linearDirection']['desktop']['value'];
        $overlayRadialDirection       = $attrs['overlay']['advanced']['radialDirection']['desktop']['value'];
        $overlayGradientStartPosition = $attrs['overlay']['advanced']['gradientStartPosition']['desktop']['value'];
        $overlayGradientEndPosition   = $attrs['overlay']['advanced']['gradientEndPosition']['desktop']['value'];
        $sliderHandleColor            = $attrs['slider']['advanced']['handleColor']['desktop']['value'];
        $showBeforeLabelOnHover       = array_key_exists( 'enableOnHover', $attrs['beforeImage'] ) ? $attrs['beforeImage']['advanced']['enableOnHover']['desktop']['value'] : 'off';
        $showAfterLabelOnHover        = array_key_exists( 'enableOnHover', $attrs['afterImage'] ) ? $attrs['afterImage']['advanced']['enableOnHover']['desktop']['value'] : 'off';
        
        $orderClass                   = $elements->id;
        $offset                       = $attrs['slider']['advanced']['handleOffset']['desktop']['value'];
        $orientation                  = $attrs['slider']['advanced']['orientation']['desktop']['value'];
        $moveSliderOnHover            = ( 'on' === $attrs['slider']['advanced']['moveOnHover']['desktop']['value']) ? true : false;
        $clickToMove                  = ( 'on' === $attrs['slider']['advanced']['moveOnClick']['desktop']['value']) ? true : false;
        $beforeImageWrapper           = '';
        $afterImageWrapper            = '';

        $disableLazyLoading           = $attrs['beforeImage']['advanced']['disableLazyLoading']['desktop']['value'] ?? 'on';
        $beforeImageClassnames        = 'dipl-before-img';
        $afterImageClassnames         = 'dipl-after-img';
        if ( 'on' === $disableLazyLoading ) {
            $beforeImageClassnames .= ' no-lazyload skip-lazy';
            $afterImageClassnames  .= ' no-lazyload skip-lazy';
        }

        $beforeImageWrapper           = $elements->render(
            [
                'attrName'   => 'beforeImage',
                'attributes' => [ 'class' => $beforeImageClassnames ],
            ]
        );
        $afterImageWrapper           = $elements->render(
            [
                'attrName'   => 'afterImage',
                'attributes' => [ 'class' => $afterImageClassnames ],
            ]
        );


        $wrapper = sprintf(
            '<div class="dipl-before-after-slider-wrapper">
                <div class="dipl-image-wrapper">
                    %1$s%2$s
                </div>
            </div>%3$s',
            $beforeImageWrapper,
            $afterImageWrapper,
            BeforeAfterSlider::init_slider($attrs, $elements)
        );

        $parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

        return Module::render(
            [
                // FE only.
                'orderIndex'          => $block->parsed_block['orderIndex'],
                'storeInstance'       => $block->parsed_block['storeInstance'],

                // VB equivalent.
                'attrs'               => $attrs,
                'elements'            => $elements,
                'id'                  => $block->parsed_block['id'],
                'moduleClassName'     => '',
                'name'                => $block->block_type->name,
                'classnamesFunction'  => [ BeforeAfterSlider::class, 'module_classnames' ],
                'moduleCategory'      => $block->block_type->category,
                'stylesComponent'     => [ BeforeAfterSlider::class, 'module_styles' ],
                'scriptDataComponent' => [ BeforeAfterSlider::class, 'module_script_data' ],
                'parentAttrs'         => $parent->attrs ?? [],
                'parentId'            => $parent->id ?? '',
                'parentName'          => $parent->blockName ?? '',
                'children'            => $elements->style_components(
                    [
                        'attrName' => 'module',
                    ]
                ) . $wrapper,
            ]
        );
    }
    public static function init_slider($attrs, $elements ) {

        $props                = $attrs;
        $offset               = ( '' !== $props['slider']['advanced']['handleOffset']['desktop']['value'] ) ? $props['slider']['advanced']['handleOffset']['desktop']['value'] : 0.5;
        $orientation          = ( '' !== $props['slider']['advanced']['orientation']['desktop']['value'] ) ? $props['slider']['advanced']['orientation']['desktop']['value'] : 'horizontal';
        $move_slider_on_hover = ( 'on' === $props['slider']['advanced']['moveOnHover']['desktop']['value'] ) ? true : false;
        $click_to_move        = ( 'on' === $props['slider']['advanced']['moveOnClick']['desktop']['value'] && ! $move_slider_on_hover ) ? true : false;
        $order_class          = str_replace(array("-","/"),"_",$elements->id);

        if ( 'on' === $props['beforeLabel']['advanced']['enable']['desktop']['value'] ) {
            $before_label = ( array_key_exists('innerContent', $props['beforeLabel'] ) && '' !== $props['beforeLabel']['innerContent']['desktop']['value'] ) ? sprintf( esc_html( '%s' ), esc_html( $props['beforeLabel']['innerContent']['desktop']['value'] ) ) : '';
        } else {
            $before_label = '';
        }
        if ( 'on' === $props['afterLabel']['advanced']['enable']['desktop']['value'] ) {
            $after_label = ( array_key_exists('innerContent', $props['afterLabel'] ) && '' !== $props['afterLabel']['innerContent']['desktop']['value'] ) ? sprintf( esc_html( '%s' ), esc_html( $props['afterLabel']['innerContent']['desktop']['value'] ) ) : '';
        } else {
            $after_label = '';
        }


        return '<script type="text/javascript">
                jQuery(function($) {
                    $(".' . esc_attr( $order_class ) . ' .dipl-image-wrapper").twentytwenty({
                        default_offset_pct: "' . esc_attr( $offset ) . '",
                        orientation: "' . esc_attr( $orientation ) . '",
                        before_label: "' . esc_attr( $before_label ) . '",
                        after_label: "' . esc_attr( $after_label ) . '",
                        move_slider_on_hover: "' . esc_attr( $move_slider_on_hover ) . '",
                        move_with_handle_only: true,
                        click_to_move: "' . esc_attr( $click_to_move ) . '"
                    });
                });
            </script>';
    }
    
}
