<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BeforeAfterSlider;
 */

namespace DIPL\Modules\BeforeAfterSlider;

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\BeforeAfterSlider\BeforeAfterSliderTraits;

/**
 * Class BeforeAfterSlider
 *
 * @package DIPL\Modules\BeforeAfterSlider
 */
class BeforeAfterSlider implements DependencyInterface {

    use BeforeAfterSliderTraits\RenderCallbackTrait;
    use BeforeAfterSliderTraits\ModuleClassnamesTrait;
    use BeforeAfterSliderTraits\ModuleStylesTrait;
    use BeforeAfterSliderTraits\ModuleScriptDataTrait;

    public function load() {
        $module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/before-after-slider';

        add_action(
            'init',
            function() use ( $module_json_folder_path ) {
                ModuleRegistration::register_module(
                    $module_json_folder_path,
                    [
                        'render_callback' => [ BeforeAfterSlider::class, 'render_callback' ],
                    ]
                );
            }
        );
    }
}