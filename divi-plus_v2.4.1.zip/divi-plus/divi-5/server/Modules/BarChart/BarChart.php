<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\BarChart;
 */
namespace DIPL\Modules\BarChart;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\Module\Script;
use DIPL\Modules\BarChart\BarChartTraits;

/**
 * Class BarChart
 *
 * @package DIPL\Modules\BarChart
 */
class BarChart implements DependencyInterface {

	use BarChartTraits\RenderCallbackTrait;
	use BarChartTraits\ModuleClassnamesTrait;
	use BarChartTraits\ModuleStylesTrait;
	use BarChartTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/bar-chart';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ BarChart::class, 'render_callback' ] ]
				);
			}
		);
	}
}
