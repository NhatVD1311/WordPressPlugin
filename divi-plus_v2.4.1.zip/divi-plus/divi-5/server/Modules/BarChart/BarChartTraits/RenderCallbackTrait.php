<?php
namespace DIPL\Modules\BarChart\BarChartTraits;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\Module\Module;
use DIPL\Modules\BarChart\BarChart;

trait RenderCallbackTrait {
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$order_class     = ModuleUtils::get_module_order_class_name( $block->parsed_block['id'] );

		// Get attrs.
		$title           = $attrs['title']['innerContent']['desktop']['value'] ?? '';
		$bar_border_size = $attrs['module']['advanced']['barBorderSize']['desktop']['value'] ?? '0';

		// Get child blocks.
		$inner_blocks = $block->parsed_block['innerBlocks'] ?? [];
		$children_ids = $inner_blocks ? array_map(
			function( $inner_block ) {
				return $inner_block['id'];
			},
			$inner_blocks
		) : [];

		// Get chart data from child attributes.
		$labels      = [];
		$values      = [];
		$bgColor     = [];
		$borderColor = [];
		foreach ( $inner_blocks as $key => $inner_block ) {
			$child_attrs = $inner_block['attrs'] ?? [];

			// Get attributes.
			$label = $child_attrs['barLabel']['innerContent']['desktop']['value'] ?? '';
			$value = $child_attrs['barValue']['innerContent']['desktop']['value'] ?? '';
			if ( ! empty( $label ) && ! empty( $value ) ) {
				$labels[]      = esc_html__( $label, 'divi-plus' );
				$values[]      = esc_attr( $value );
				$bgColor[]     = esc_attr( $child_attrs['bar']['advanced']['backgroundColor']['desktop']['value'] ?? 'rgba(54,162,235,0.2)' );
				$borderColor[] = esc_attr( $child_attrs['bar']['advanced']['borderColor']['desktop']['value'] ?? '#36a2eb' );
			}
		}

		// Get chart data.
		$chart_data = array(
			'labels'   => $labels,
			'datasets' => array( array(
				'label'           => esc_html__( $title, 'divi-plus' ),
				'data'            => $values,
				'backgroundColor' => $bgColor,
				'borderColor'     => $borderColor,
				'borderWidth'     => $bar_border_size,
			) )
		);

		// Get chart height.
		$chart_height        = $attrs['module']['advanced']['chartHeight']['desktop']['value'] ?? '400';
		$chart_height_tablet = $attrs['module']['advanced']['chartHeight']['tablet']['value'] ?? intval( $chart_height );
		$chart_height_phone  = $attrs['module']['advanced']['chartHeight']['phone']['value'] ?? intval( $chart_height_tablet );

		// Get show legend. An empty title has no legend text worth showing,
		// so it's hidden regardless of the toggle to avoid a blank swatch.
		$show_legend = $attrs['module']['advanced']['showLegend']['desktop']['value'] ?? 'on';
		if ( '' === trim( $title ) ) {
			$show_legend = 'off';
		}

		// Get show grid lines.
		$show_grid = $attrs['module']['advanced']['showGridLines']['desktop']['value'] ?? 'on';

		// Get legend box customization.
		$hide_legend_box       = $attrs['module']['advanced']['hideLegendBox']['desktop']['value'] ?? 'off';
		$legend_bg_color       = $attrs['module']['advanced']['legendBackgroundColor']['desktop']['value'] ?? '';
		$legend_border_color   = $attrs['module']['advanced']['legendBorderColor']['desktop']['value'] ?? '';

		// Get grid line color.
		$grid_color = $attrs['module']['advanced']['gridColor']['desktop']['value'] ?? '';

		// Get value prefix/suffix.
		$value_prefix = $attrs['module']['advanced']['valuePrefix']['desktop']['value'] ?? '';
		$value_suffix = $attrs['module']['advanced']['valueSuffix']['desktop']['value'] ?? '';

		// Render final output.
		$rendered_output = HTMLUtility::render( [
			'tag'               => 'div',
			'attributes'        => [
				'class'                      => 'dipl_bar_chart_wrapper',
				'data-chart'                 => htmlspecialchars( json_encode( $chart_data ), ENT_QUOTES, 'UTF-8' ),
				'data-chart_height'          => esc_attr( $chart_height ),
				'data-chart_height_tablet'   => esc_attr( $chart_height_tablet ),
				'data-chart_height_phone'    => esc_attr( $chart_height_phone ),
				'data-show_legend'           => esc_attr( $show_legend ),
				'data-show_grid'             => esc_attr( $show_grid ),
				'data-hide_legend_box'       => esc_attr( $hide_legend_box ),
				'data-legend_bg_color'       => esc_attr( $legend_bg_color ),
				'data-legend_border_color'   => esc_attr( $legend_border_color ),
				'data-value_prefix'          => esc_attr( $value_prefix ),
				'data-value_suffix'          => esc_attr( $value_suffix ),
				'data-grid_color'            => esc_attr( $grid_color ),
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'children'          => sprintf(
				'<div class="dipl_bar_chart_inner">
					<canvas id="%1$s--canvas"></canvas>
				</div>',
				esc_attr( $order_class )
			)
		] );

		$parent = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );

		return Module::render( [
			// FE only.
			'orderIndex'          => $block->parsed_block['orderIndex'],
			'storeInstance'       => $block->parsed_block['storeInstance'],

			// VB equivalent.
			'attrs'               => $attrs,
			'elements'            => $elements,
			'id'                  => $block->parsed_block['id'],
			'moduleClassName'     => '',
			'name'                => $block->block_type->name,
			'moduleCategory'      => $block->block_type->category,
			'classnamesFunction'  => [ BarChart::class, 'module_classnames' ],
			'stylesComponent'     => [ BarChart::class, 'module_styles' ],
			'scriptDataComponent' => [ BarChart::class, 'module_script_data' ],
			'parentAttrs'         => $parent->attrs ?? [],
			'parentId'            => $parent->id ?? '',
			'parentName'          => $parent->blockName ?? '',
			'childrenIds'         => $children_ids,
			'children'            => $elements->style_components(
										[ 'attrName' => 'module', ]
									) . $rendered_output,
		] );
	}
}
