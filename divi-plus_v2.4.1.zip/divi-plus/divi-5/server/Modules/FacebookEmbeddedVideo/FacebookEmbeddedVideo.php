<?php
/**
 * Static Module class.
 *
 * @package DIPL\Modules\FacebookEmbeddedVideo;
 */

namespace DIPL\Modules\FacebookEmbeddedVideo;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DIPL\Modules\FacebookEmbeddedVideo\FacebookEmbeddedVideoTraits;

/**
 * Class FacebookEmbeddedVideo
 *
 * @package DIPL\Modules\FacebookEmbeddedVideo
 */
class FacebookEmbeddedVideo implements DependencyInterface {

	use FacebookEmbeddedVideoTraits\RenderCallbackTrait;
	use FacebookEmbeddedVideoTraits\ModuleClassnamesTrait;
	use FacebookEmbeddedVideoTraits\ModuleStylesTrait;
	use FacebookEmbeddedVideoTraits\ModuleScriptDataTrait;

	public function load() {
		$module_json_folder_path = dirname( __DIR__, 3 ) . '/visual-builder/modules-json/facebook-embedded-video';
		add_action(
			'init',
			function() use ( $module_json_folder_path ) {
				ModuleRegistration::register_module(
					$module_json_folder_path,
					[ 'render_callback' => [ FacebookEmbeddedVideo::class, 'render_callback' ] ]
				);
			}
		);
	}
}
