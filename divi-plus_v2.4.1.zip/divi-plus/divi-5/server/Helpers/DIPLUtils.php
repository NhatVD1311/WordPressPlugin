<?php
namespace DIPL\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Assets\DetectFeature;
use ET\Builder\FrontEnd\Module\Style;

class DIPLUtils {

	/**
	 * Get library content.
	 * 
	 * To prevent break/conflict the style of modules,
	 * due to duplicate module id in the page.
	 *
	 * @param integer $library_id library layout id.
	 * @param string $module module name
	 * @return string content of library layout
	 */
	public static function load_library_content( $library_id, $module ) {
		$library_id = absint( $library_id );
		if ( ! $library_id ) {
			return '';
		}

		$post_content           = et_strip_shortcodes( get_the_content( null, false, $library_id ) );
		$detected_module_names  = DetectFeature::get_block_names( get_the_content( null, false, $library_id ) );
		$filtered_module_names  = array_filter(
			$detected_module_names,
			function ( $module_name ) {
				return ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ], true );
			}
		);

		// Set detected module types for inner content rendering.
		Style::set_detected_module_types_for_inner_content( $filtered_module_names );
		$post_content  = et_core_intentionally_unescaped( BlockParserStore::render_inner_content( $post_content ), 'html' );

		// Capture styles generated during content rendering for this post.
		// Match VB approach: capture styles under 'post' key and output inline.
		$content_styles = Style::render( 'default', 'preset', $module )
			. Style::render( 'default', 'module', $module );

		// Include global color CSS variables inline.
		// Global colors are output in footer (when Dynamic Assets disabled) or head (when enabled),
		// but blog post content renders before footer, so we need to include them inline.
		$global_color_css = Style::get_global_colors_style();
		if ( ! empty( $global_color_css ) ) {
			// Prepend global color CSS variables before the styles that use them.
			$content_styles = $global_color_css . $content_styles;
		}

		// Clear detected module types after rendering to prevent affecting other posts.
		Style::set_detected_module_types_for_inner_content( [] );

		// Return styles via reference if not appending to content.
		if ( ! empty( $content_styles ) ) {
			// Append inline styles to content if styles were generated.
			$post_content .= sprintf(
				'<style id="el-divi-%s-layout-%d">%s</style>',
				$module,
				$library_id,
				$content_styles
			);
		}

		return $post_content;
	}
}