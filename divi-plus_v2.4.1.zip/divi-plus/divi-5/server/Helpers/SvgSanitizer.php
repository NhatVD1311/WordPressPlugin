<?php
namespace DIPL\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * `wp_kses()` on this WordPress version parses via `WP_HTML_Tag_Processor`
 * (see `wp_kses_attr()` in wp-includes/kses.php) and preserves the original
 * case of tag and attribute names in its output — only the *lookup* against
 * the allowed-list below has to be lowercase. Verified by reading that file
 * directly before relying on it here; older `wp_kses()` implementations were
 * known to lowercase attributes like `viewBox`, which would silently break
 * every SVG passed through them.
 *
 * `wp_kses()` also runs `href`/`xlink:href` values through its own protocol
 * allowlist regardless of tag, so `javascript:`/`data:text/html` URIs are
 * already stripped without this class doing anything extra for them.
 *
 * Deliberately excluded from the allowed-list, not just left off by omission:
 * `script`, `style` (the tag — a `style` *attribute* is allowed and goes
 * through `safecss_filter_attr()`), `foreignObject`, `iframe`, `embed`,
 * `object`, and every SMIL animation element (`animate`, `animateTransform`,
 * `set`, …) whose own event attributes (`onbegin`, `onend`) are a known SVG
 * XSS vector.
 */
class SvgSanitizer {

	/**
	 * Sanitizes a string of SVG markup.
	 *
	 * @param string $svg Raw SVG markup.
	 *
	 * @return string Sanitized SVG markup, or an empty string when the input
	 *                is empty or every tag stripped down to nothing.
	 */
	public static function sanitize( $svg ) {
		$svg = trim( (string) $svg );
		if ( '' === $svg ) {
			return '';
		}

		$clean = wp_kses( $svg, self::allowed_html() );

		// A pasted fragment that starts mid-tag, or a file that turned out not
		// to be an SVG at all, can strip down to nothing usable.
		if ( false === stripos( $clean, '<svg' ) ) {
			return '';
		}

		return $clean;
	}

	/**
	 * The allowed-list handed to `wp_kses()`. Every key is lowercase — that is
	 * the axis `wp_kses()` matches on — but the *output* keeps whatever case
	 * the source SVG actually used.
	 *
	 * @return array
	 */
	private static function allowed_html() {
		$common = array(
			'id'                => true,
			'class'             => true,
			'style'             => true,
			'transform'         => true,
			'fill'              => true,
			'fill-opacity'      => true,
			'fill-rule'         => true,
			'stroke'            => true,
			'stroke-width'      => true,
			'stroke-linecap'    => true,
			'stroke-linejoin'   => true,
			'stroke-dasharray'  => true,
			'stroke-dashoffset' => true,
			'stroke-opacity'    => true,
			'opacity'           => true,
			'clip-path'         => true,
			'mask'              => true,
		);

		return array(
			'svg' => array_merge( $common, array(
				'xmlns'               => true,
				'xmlns:xlink'         => true,
				'viewbox'             => true,
				'width'               => true,
				'height'              => true,
				'preserveaspectratio' => true,
				'version'             => true,
				'role'                => true,
				'aria-hidden'         => true,
				'aria-label'          => true,
				'focusable'           => true,
			) ),
			'g'              => $common,
			'defs'           => array(),
			'title'          => array(),
			'desc'           => array(),
			'path'           => array_merge( $common, array( 'd' => true, 'fill-rule' => true ) ),
			'circle'         => array_merge( $common, array( 'cx' => true, 'cy' => true, 'r' => true ) ),
			'ellipse'        => array_merge( $common, array( 'cx' => true, 'cy' => true, 'rx' => true, 'ry' => true ) ),
			'rect'           => array_merge( $common, array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true ) ),
			'line'           => array_merge( $common, array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true ) ),
			'polyline'       => array_merge( $common, array( 'points' => true ) ),
			'polygon'        => array_merge( $common, array( 'points' => true ) ),
			'use'            => array_merge( $common, array( 'href' => true, 'xlink:href' => true, 'x' => true, 'y' => true, 'width' => true, 'height' => true ) ),
			'symbol'         => array_merge( $common, array( 'viewbox' => true ) ),
			'text'           => array_merge( $common, array( 'x' => true, 'y' => true, 'dx' => true, 'dy' => true, 'text-anchor' => true, 'font-family' => true, 'font-size' => true, 'font-weight' => true ) ),
			'tspan'          => array_merge( $common, array( 'x' => true, 'y' => true, 'dx' => true, 'dy' => true ) ),
			'lineargradient' => array_merge( $common, array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true, 'gradientunits' => true, 'gradienttransform' => true ) ),
			'radialgradient' => array_merge( $common, array( 'cx' => true, 'cy' => true, 'r' => true, 'fx' => true, 'fy' => true, 'gradientunits' => true, 'gradienttransform' => true ) ),
			'stop'           => array_merge( $common, array( 'offset' => true, 'stop-color' => true, 'stop-opacity' => true ) ),
			'clippath'       => $common,
			'mask'           => $common,
			'pattern'        => array_merge( $common, array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'patternunits' => true, 'patterntransform' => true ) ),
		);
	}
}
