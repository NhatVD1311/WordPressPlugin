<?php
/**
 * Divi WhatsApp Chat Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_WhatsApp_Chat extends DiviPlusExtensions{
	public function __construct() {
		// Add whatsapp button on footer.
		add_action( 'wp_footer', array( __class__, 'enable_whatsapp_chat_button' ), 100 );

		// Add whatsapp button styles.
		add_action( 'wp_head',   array( __class__, 'output_whatsapp_chat_styles' ), 99 );
	}

	/**
	 * Load WhatsApp Chat button.
	 */
	public static function enable_whatsapp_chat_button() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-whatsapp-chat-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		// Get attributes.
		$phone   = self::get_extension_option( 'dipl-whatsapp-chat-phone' );
		$message = self::get_extension_option( 'dipl-whatsapp-chat-pre-message' );
		$tooltip = self::get_extension_option( 'dipl-whatsapp-chat-tooltip-label' );
		$delay   = absint( self::get_extension_option( 'dipl-whatsapp-chat-delay' ), 0 );

		// Not phone, thn return.
		if ( empty( $phone ) ) {
			return;
		}

		// WhatsApp URL.
		$whatsapp_url = sprintf(
			'https://wa.me/%1$s%2$s',
			preg_replace( '/[^0-9]/', '', $phone ),
			$message ? '?text=' . rawurlencode( sanitize_text_field( $message ) ) : ''
		);

		// Tooltip label.
		$tooltip_label = '';
		if ( $tooltip ) {
			$tooltip_label = sprintf( '<span class="dipl-whatsapp-chat-tooltip">%1$s</span>', esc_html( $tooltip ) );
		}

		// WhatsApp button.
		$whatsapp_button = sprintf(
			'<div id="dipl-whatsapp-chat-btn-wrap" class="%5$s" data-delay="%1$s">
				%2$s
				<a id="dipl-whatsapp-chat-btn-link" href="%3$s" aria-label="%4$s" target="_blank" rel="noopener noreferrer">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true">
						<path d="M16 2.667C8.637 2.667 2.667 8.637 2.667 16c0 2.347.619 4.549 1.693 6.464L2.667 29.333l7.12-1.653A13.287 13.287 0 0 0 16 29.333C23.363 29.333 29.333 23.363 29.333 16S23.363 2.667 16 2.667zm0 2.4C21.875 5.067 26.933 10.125 26.933 16S21.875 26.933 16 26.933a10.9 10.9 0 0 1-5.467-1.467l-.387-.24-4.08.96.987-3.947-.267-.4A10.9 10.9 0 0 1 5.067 16C5.067 10.125 10.125 5.067 16 5.067zm-3.6 5.6c-.213 0-.56.08-.853.4-.293.32-1.12 1.093-1.12 2.667 0 1.573 1.147 3.093 1.307 3.307.16.213 2.24 3.52 5.493 4.8 2.72 1.08 3.253.853 3.84.8.587-.053 1.867-.773 2.133-1.52.267-.747.267-1.387.187-1.52-.08-.133-.293-.213-.613-.373-.32-.16-1.893-.933-2.187-1.04-.293-.107-.507-.16-.72.16-.213.32-.827 1.04-.987 1.253-.16.213-.32.24-.64.08-.32-.16-1.36-.48-2.587-1.547-.96-.827-1.6-1.853-1.787-2.173-.187-.32-.02-.48.14-.64.147-.147.32-.373.48-.56.16-.187.213-.32.32-.533.107-.213.053-.4-.027-.56-.08-.16-.72-1.76-.987-2.4-.267-.64-.533-.533-.72-.533z"/>
					</svg>
				</a>
			</div>',
			esc_attr( $delay * 1000 ),
			et_core_esc_previously( $tooltip_label ),
			esc_url( $whatsapp_url ),
			esc_attr__( 'Chat on WhatsApp', 'divi-plus' ),
			empty( $delay ) ? ' dipl-wa-visible' : ''
		);

		// Add whatsapp button script, if delay is there.
		if ( ! empty( $delay ) ) {
			$whatsapp_button .= "<script>
				( function() {
					var btn = document.getElementById( 'dipl-whatsapp-chat-btn-wrap' );
					if ( ! btn ) { return; }
					var delay = parseInt( btn.getAttribute( 'data-delay' ), 10 ) || 0;
					function show() { btn.classList.add( 'dipl-wa-visible' ); }
					delay > 0 ? setTimeout( show, delay ) : show();
				} )();
			</script>";
		}

		echo et_core_intentionally_unescaped( $whatsapp_button, 'html' );
	}

	/**
	 * WhatsApp Chat styling.
	 */
	public static function output_whatsapp_chat_styles() {

		$position      = self::get_extension_option( 'dipl-whatsapp-chat-button-pos', 'bottom-right' );
		$bg_color      = self::get_extension_option( 'dipl-whatsapp-chat-button-bg-color', '#25D366' );
		$icon_color    = self::get_extension_option( 'dipl-whatsapp-chat-button-icon-color', '#ffffff' );
		$button_size   = self::get_extension_option( 'dipl-whatsapp-chat-button-size', '54' );
		$offset_top    = self::get_extension_option( 'dipl-whatsapp-chat-offset__top' );
		$offset_bottom = self::get_extension_option( 'dipl-whatsapp-chat-offset__bottom' );
		$offset_left   = self::get_extension_option( 'dipl-whatsapp-chat-offset__left' );
		$offset_right  = self::get_extension_option( 'dipl-whatsapp-chat-offset__right' );
		$hide_mobile   = self::get_extension_option( 'dipl-whatsapp-chat-hide-on-mobile' );
		$hide_desktop  = self::get_extension_option( 'dipl-whatsapp-chat-hide-on-desktop' );

		$mobile_css    = ( 'on' === $hide_mobile ) ? '@media(max-width:980px){#dipl-whatsapp-chat-btn-wrap{display:none!important;}}' : '';
		$desktop_css   = ( 'on' === $hide_desktop ) ? '@media(min-width:981px){#dipl-whatsapp-chat-btn-wrap{display:none!important;}}' : '';

		// Get position style.
		$position_style = '';
		if ( 'bottom-left' === $position ) {
			$position_style = 'left: 0; right: auto;';
		} else {
			$position_style = 'left: auto; right: 0;';
		}

		// Offside styling.
		$offset_styling  = ! empty( $offset_top ) ? 'margin-top: ' . intval( $offset_top ) . 'px;' : '';
		$offset_styling .= ! empty( $offset_bottom ) ? 'margin-bottom: ' . intval( $offset_bottom ) . 'px;' : '';
		$offset_styling .= ! empty( $offset_left ) ? 'margin-left: ' . intval( $offset_left ) . 'px;' : '';
		$offset_styling .= ! empty( $offset_right ) ? 'margin-right: ' . intval( $offset_right ) . 'px;' : '';

		$is_left        = ( 'bottom-left' === $position );
		$tooltip_pos    = $is_left ? "left:calc(100% + 12px);right:auto;" : "right:calc(100% + 12px);left:auto;";
		$tooltip_slide  = $is_left ? '-6px' : '6px';
		?>
		<style id="dipl-whatsapp-chat-extension-css">
			#dipl-whatsapp-chat-btn-wrap{
				position: fixed;
				z-index: 99998;
				display: flex;
				align-items: center;
				opacity: 0;
				visibility: hidden;
				transform: scale(.5);
				transition: opacity .35s ease, visibility .35s ease, transform .35s cubic-bezier(.34,1.56,.64,1);
				bottom: 0;
				<?php echo esc_html( $position_style ); ?>
				<?php echo esc_html( $offset_styling ); ?>
			}
			#dipl-whatsapp-chat-btn-wrap.dipl-wa-visible{
				opacity: 1;
				visibility: visible;
				transform: scale(1);
			}
			#dipl-whatsapp-chat-btn-link{
				display: flex;
				align-items: center;
				justify-content: center;
				width: <?php echo absint( $button_size ); ?>px;
				height: <?php echo absint( $button_size ); ?>px;
				border-radius: 50%;
				box-shadow: 0 4px 14px rgba(0, 0, 0, 0.22);
				text-decoration: none;
				color: #ffffff;
				position: relative;
				transition: transform .2s ease,box-shadow .2s ease;
				flex-shrink: 0;
				background: <?php echo esc_attr( $bg_color ); ?>;
			}
			#dipl-whatsapp-chat-btn-link:hover{
				transform: scale(1.09);
				box-shadow: 0 6px 22px rgba(0,0,0,.3);
			}
			#dipl-whatsapp-chat-btn-link svg{
				width: <?php echo absint( $button_size ) / 2 + 5 ?>px;
				height: <?php echo absint( $button_size ) / 2 + 5 ?>px;
				fill: <?php echo esc_attr( $icon_color ); ?>;
				flex-shrink: 0;
			}
			#dipl-whatsapp-chat-btn-link::before{
				content:'';
				position:absolute;
				inset:0;
				border-radius:50%;
				background:<?php echo esc_attr( $bg_color ); ?>;
				opacity:0;
				animation:dipl-wa-pulse 2.8s ease-out infinite;
			}
			@keyframes dipl-wa-pulse{
				0%{transform:scale(1);opacity:.5}
				100%{transform:scale(1.8);opacity:0}
			}
			.dipl-whatsapp-chat-tooltip{
				position:absolute;
				top:50%;
				<?php echo esc_html( $tooltip_pos ); ?>
				transform:translateY(-50%) translateX(<?php echo esc_attr( $tooltip_slide ); ?>);
				white-space:nowrap;
				background:rgba(0,0,0,.72);
				color:#fff;
				font-size:12px;
				line-height:1;
				padding:6px 10px;
				border-radius:4px;
				pointer-events:none;
				opacity:0;
				transition:opacity .2s ease,transform .2s ease;
			}
			#dipl-whatsapp-chat-btn-wrap:hover .dipl-whatsapp-chat-tooltip{
				opacity:1;
				transform:translateY(-50%) translateX(0);
			}
			<?php echo esc_html( $mobile_css . $desktop_css ); ?>
		</style>
		<?php
	}
}

new DIPL_WhatsApp_Chat;
