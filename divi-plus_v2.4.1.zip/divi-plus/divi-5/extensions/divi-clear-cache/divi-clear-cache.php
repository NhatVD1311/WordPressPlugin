<?php
/**
 * Divi Clear Cache Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Divi_Clear_Cache extends DiviPlusExtensions{
	public function __construct() {
		// Add admin bar menu.
		add_action( 'admin_bar_menu', array( __class__, 'add_toolbar_button' ), 100 );

		// Handle clear cache action in adminbar.
		add_action( 'admin_post_dipl_clear_divi_cache', array( __class__, 'handle_divi_clear_cache_action' ) );
		add_action( 'admin_head', array( __CLASS__, 'maintenance_admin_bar_style' ) );
		add_action( 'wp_head', array( __CLASS__, 'maintenance_admin_bar_style' ) );
	}

	/**
	 * Add clear cache toolbar button.
	 */
	public static function add_toolbar_button( $wp_admin_bar ) {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-divi-clear-cache-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// If current user is not admin.
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Generate action URL.
		$url = wp_nonce_url(
			admin_url( 'admin-post.php?action=dipl_clear_divi_cache' ),
			'dipl_clear_divi_cache'
		);

		// Add adminbar note.
		$wp_admin_bar->add_node( array(
			'id'    => 'dipl-clear-divi-cache',
			'href'  => esc_url( $url ),
			'title' => sprintf(
				'<span class="ab-icon" aria-hidden="true"></span><span class="ab-label">%1$s</span>',
				esc_html__( 'Clear Divi Cache', 'divi-plus' )
			),
		) );
	}

	/**
	 * Handle clear cache.
	 */
	public static function handle_divi_clear_cache_action() {
		// Check if current user have access.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'divi-plus' ) );
		}
		check_admin_referer( 'dipl_clear_divi_cache' );

		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-divi-clear-cache-enable' );
		if ( 'on' !== $is_enable ) {
			wp_die( esc_html__( 'Divi Plus: You do not have permission to perform this action.', 'divi-plus' ) );
		}

		// Clear cache.
		self::clear_divi_cache();

		// Redirect back to current screen.
		$redirect = wp_get_referer();
		if ( ! $redirect ) {
			$redirect = admin_url();
		}

		wp_safe_redirect( add_query_arg( 'dipl-cache-cleared', '1', $redirect ) );
		exit;
	}

	/**
	 * Admin bar notice style.
	 */
	public static function maintenance_admin_bar_style() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-divi-clear-cache-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		} ?>
		<style>
			#wpadminbar #wp-admin-bar-dipl-clear-divi-cache .ab-icon:before {
				content: "\f463";
				top: 2px;
				display: inline-block;
			}
			#wpadminbar #wp-admin-bar-dipl-clear-divi-cache:hover .ab-icon:before {
				animation: dipl-animate-spin 2s linear infinite;
			}
			@keyframes dipl-animate-spin{
				from { transform: rotate(0deg); }
				to { transform: rotate(360deg); }
			}
		</style>
		<?php
	}

	/**
	 * Clear divi cache.
	 */
	public static function clear_divi_cache() {
		// Use Divi's built-in clear function if available (Divi 4+).
		if ( function_exists( 'et_core_clear_cache' ) ) {
			et_core_clear_cache();
			return;
		}

		// Use the PageResource static method if available.
		if ( class_exists( 'ET_Core_PageResource' )
			&& method_exists( 'ET_Core_PageResource', 'remove_static_resources' ) ) {
			ET_Core_PageResource::remove_static_resources( 'all', 'all' );
			return;
		}

		// Fallback: delete files in the et-cache directory.
		$cache_dir = trailingslashit( WP_CONTENT_DIR ) . 'et-cache/';
		if ( ! is_dir( $cache_dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $cache_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() ) {
				wp_delete_file( $file->getRealPath() );
			}
		}
	}
}

new DIPL_Divi_Clear_Cache;
