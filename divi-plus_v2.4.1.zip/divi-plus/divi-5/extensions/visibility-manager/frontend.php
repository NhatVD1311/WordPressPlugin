<?php
/**
 * Particle Background Extension Class.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DiplVisibilityManagerExtension {

	/**
	 * Alter frontend render.
	 */
	public static function render( $module_wrapper, $args, $enable_areas ) {
		$module_name     = $args['name'] ?? '';
		$module_attrs    = $args['attrs'] ?? '';
		$module_elements = $args['elements'] ?? '';

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $module_wrapper;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $module_wrapper;
		}

		// Check if extension enabled.
		$ext_attr         = $module_attrs['diplVisibilityManager']['advanced'] ?? [];
		$enable_extension = $ext_attr['enable']['desktop']['value'] ?? 'off';

		// if not enabled.
		if ( 'on' !== $enable_extension ) {
			return $module_wrapper;
		}

		// Get attrs.
		$show_hide  = $ext_attr['showHide']['desktop']['value'] ?? 'show';
		$user_type  = $ext_attr['userType']['desktop']['value'] ?? 'all';
		$user_roles = $ext_attr['userRoles']['desktop']['value'] ?? 'all';

		if ( 'logged-in' === $user_type ) {
			if ( is_user_logged_in() ) {
				$current_user = wp_get_current_user();
				if ( $current_user->roles[0] === $user_roles || 'all' === $user_roles ) {
					if ( 'show' === $show_hide ) {
						return $module_wrapper;
					} else {
						return '';
					}
				} else {
					if ( 'show' === $show_hide ) {
						return '';
					} else {
						return $module_wrapper;
					}
				}
			} else {
				if ( 'show' === $show_hide ) {
					return '';
				} else {
					return $module_wrapper;
				}
			}
		} elseif ( 'logged-out' === $user_type ) {
			if ( ! is_user_logged_in() ) {
				if ( 'show' === $show_hide ) {
					return $module_wrapper;
				} else {
					return '';
				}
			} else {
				if ( 'show' === $show_hide ) {
					return '';
				} else {
					return $module_wrapper;
				}
			}
		} else {
			if ( 'show' === $show_hide ) {
				return $module_wrapper;
			} else {
				return '';
			}
		}

		return $module_wrapper;
	}

	/**
	 * Alter attributes.
	 */
	public static function attributes( $settings, $enable_areas ) {
		$module_name       = $settings['name'] ?? '';
		$module_attributes = $settings['attributes'] ?? false;

		if ( ! $module_attributes ) {
			return $settings;
		}

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $settings;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $settings;
		}

		$settings['attributes']['diplVisibilityManager'] = [
			'type'     => 'object',
			'settings' => [
				'advanced' => [
					'visibilityEnable' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplVisibilityManager',
							'attrName'    => 'diplVisibilityManager.advanced.enable',
							'label'       => 'Enable visibility Manager',
							'description' => 'Here you can choose whether it will be visible or not.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							]
						]
					],
					'visibilityShowHide' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplVisibilityManager',
							'attrName'    => 'diplVisibilityManager.advanced.showHide',
							'label'       => 'Show or Hide',
							'description' => 'Here you can choose whether to show or hide it.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'show' => [ 'label' => 'Show' ],
										'hide' => [ 'label' => 'Hide' ],
									]
								]
							]
						]
					],
					'visibilityUserType' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplVisibilityManager',
							'attrName'    => 'diplVisibilityManager.advanced.userType',
							'label'       => 'Set visibility for',
							'description' => 'Here you can choose whether to show or hide it for paticular set of users.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'all'         => [ 'label' => 'All Users' ],
										'logged-in'   => [ 'label' => 'Logged In Users' ],
										'logged-out'  => [ 'label' => 'Logged Out Users' ],
									]
								]
							]
						]
					],
					'visibilityUserRoles' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplVisibilityManager',
							'attrName'    => 'diplVisibilityManager.advanced.userRoles',
							'label'       => 'User Roles',
							'description' => 'Here you can choose whether to show or hide it for paticular set of user role users.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => []
								]
							]
						]
					],
				]
			]
		];

		return $settings;
	}

}
