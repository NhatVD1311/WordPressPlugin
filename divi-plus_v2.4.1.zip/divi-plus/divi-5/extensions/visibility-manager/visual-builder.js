/**
 * Visibility Manager Extension Class.
 */
class DiplVisibilityManagerExtension {

	constructor() {
		const { addFilter } = window.vendor.wp.hooks;

		// Add module groups, this will add to row, columns and section.
		addFilter( 'divi.moduleLibrary.moduleSettings.groups', 'divi-plus', this.groups.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleAttributes', 'divi-plus', this.attributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleDefaultAttributes', 'divi-plus', this.defaultAttributes.bind( this ) );
	}

	// Add group for the attributes.
	groups( groups, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return groups;
		}		

		groups.diplVisibilityManager = {
			groupName: 'diplVisibilityManager',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Visibility Manager',
				}
			}
		}

		// Return the modified groups.
		return groups;
	}

	// Add attributes.
	attributes( attributes, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return attributes;
		}

		// Get user roles.
		const { user_roles } = window?.DiplVisibilityManagerExtData || {};
		const userRolesOpt   = Object.fromEntries(
			Object.entries(user_roles).map( ( [ key, value ] ) => [ key, { label: value } ] ) 
		);

		attributes.diplVisibilityManager = {
			type: "object",
			settings: {
				advanced: {
					visibilityEnable: {
						groupType: "group-item",
						item: {
							groupSlug: "diplVisibilityManager",
							attrName: "diplVisibilityManager.advanced.enable",
							label: "Enable visibility Manager",
							description: 'Here you can choose whether it will be visible or not.',
							render: true,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					visibilityShowHide: {
						groupType: "group-item",
						item: {
							groupSlug: "diplVisibilityManager",
							attrName: "diplVisibilityManager.advanced.showHide",
							label: "Show or Hide",
							description: 'Here you can choose whether to show or hide it.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										show: { label: 'Show' },
										hide: { label: 'Hide' },
									}
								}
							}
						}
					},
					visibilityUserType: {
						groupType: "group-item",
						item: {
							groupSlug: "diplVisibilityManager",
							attrName: "diplVisibilityManager.advanced.userType",
							label: "Set visibility for",
							description: 'Here you can choose whether to show or hide it for paticular set of users.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										'all'        : { label: 'All Users' },
										'logged-in'  : { label: 'Logged In Users' },
										'logged-out' : { label: 'Logged Out Users' },
									}
								}
							}
						}
					},
					visibilityUserRoles: {
						groupType: "group-item",
						item: {
							groupSlug: "diplVisibilityManager",
							attrName: "diplVisibilityManager.advanced.userRoles",
							label: "User Roles",
							description: 'Here you can choose whether to show or hide it for paticular set of user role users.',
							render: true,
							visible: this.enableUserRolesCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: userRolesOpt || {}
								}
							}
						}
					}
				}
			}
		};

		return attributes;
	}

	// Default attributes.
	defaultAttributes( defaultAttrs, config, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return defaultAttrs;
		}

		const newDefaultAttrs = {
			diplVisibilityManager: {
				advanced: {
					enable: {
						desktop: { value: "off" }
					},
					showHide: {
						desktop: { value: "show" }
					},
					userType: {
						desktop: { value: "all" }
					},
					userRoles: {
						desktop: { value: "all" }
					}
				}
			}
		};

		// Return the modified default attributes.
		return {
			...defaultAttrs,
			...newDefaultAttrs,
		};
	}

	// Check if extension enabled or not.
	enableExtCallback( {
		attrs,
		attrName,
		responsiveMode,
		stateMode,
	} ) {
		return 'on' === ( attrs?.diplVisibilityManager?.advanced?.enable?.desktop?.value || 'off' );
	}
	enableUserRolesCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplVisibilityManager?.advanced?.enable?.desktop?.value || 'off' ) &&
			'logged-in' === ( attrs?.diplVisibilityManager?.advanced?.userType?.desktop?.value || 'all' )
		);
	};

	// Check if extension enabled for the module.
	isModuleExtensionEnabled( moduleName ) {
		const { enable_areas, dipl_modules } = window?.DiplVisibilityManagerExtData || {};

		// Check if enabled or not for section, row, column.
		if (
			( moduleName === 'divi/section' && ! enable_areas?.includes( 'sections' ) ) ||
			( moduleName === 'divi/row' && ! enable_areas?.includes( 'rows' ) ) ||
			( moduleName === 'divi/column' && ! enable_areas?.includes( 'columns' ) )
		) {
			return false;
		}
		
		// Check if enabled or not for modules.
		if (
			! [ 'divi/section', 'divi/row', 'divi/column' ].includes( moduleName ) &&
			( ! enable_areas?.includes( 'modules' ) || ! dipl_modules?.includes( moduleName ) )
		) {
			return false;
		}

		return true;
	}
}

new DiplVisibilityManagerExtension();
