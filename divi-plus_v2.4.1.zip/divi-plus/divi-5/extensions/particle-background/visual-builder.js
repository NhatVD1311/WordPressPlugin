/**
 * Particle Background Extension Class.
 */
class DiplParticleBackgroundExtension {

	constructor() {
		const { addFilter } = window.vendor.wp.hooks;
		
		// Add module groups, this will add to row, columns and section.
		addFilter( 'divi.moduleLibrary.moduleSettings.groups', 'divi-plus', this.groups.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleAttributes', 'divi-plus', this.attributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleDefaultAttributes', 'divi-plus', this.defaultAttributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.conversion.moduleConversionOutline', 'divi-plus', this.conversionOutline.bind( this ) );
	}

	// Add group for the attributes.
	groups( groups, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return groups;
		}		

		groups.diplParticleBackground = {
			groupName: 'diplParticleBackground',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Particle Background',
				}
			}
		}

		// Return the modified groups.
		return groups;
	}

	// Add attributes.
	attributes( attributes, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return attributes;
		}

		attributes.particleBackground = {
			type: "object",
			selector: "{{selector}} .particles-js-canvas-el",
			settings: {
				advanced: {
					particleEnable: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.enable",
							label: "Enable Particle Background",
							description: 'Here you can choose whether to use particle background.',
							render: true,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					disabledOn: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.disabledOn",
							label: "Hide Particle Background On",
							description: 'Here you can choose to hide particle background on device.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/checkboxes",
								props: {
									options: [
										{ label: 'Phone', value: 'phone' },
										{ label: 'Tablet', value: 'tablet' },
										{ label: 'Desktop', value: 'desktop' }
									]
								}
							}
						}
					},
					type: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.type",
							label: "Particle Type",
							description: 'Here you can choose the type of particle.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										circle: { label: 'Circle' },
										edge: { label: 'Edge' },
										triangle: { label: 'Triangle' },
										star: { label: 'Star' }
									}
								}
							}
						}
					},
					number: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.number",
							label: "Particles Number",
							description: 'Here you can enter the number of particles you want to show.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 10,
									max: 300,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					density: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.density",
							label: "Particles Density",
							description: 'Here you can enter the density area for particles.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 100,
									max: 1000,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					size: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.size",
							label: "Particles Size",
							description: 'Here you can enter the size for particles.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 100,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					color: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.color",
							label: "Particles Color",
							description: 'Here you can enter the color for particles.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/color-picker",
							}
						}
					},
					enableLinkedLine: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.enableLinkedLine",
							label: "Enable Linked Line",
							description: 'Here you can choose whether to use linked lines.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					linkedLineSize: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.linkedLineSize",
							label: "Linked Line Size",
							description: 'HeHere you can enter the size for linked lines.',
							render: true,
							visible: this.enableLinkedLineCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 10,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					linkedLineColor: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.linkedLineColor",
							label: "Linked Line Color",
							description: 'Here you can enter the color for linked lines.',
							render: true,
							visible: this.enableLinkedLineCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/color-picker",
							}
						}
					},
					enableMovement: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.enableMovement",
							label: "Enable Particle Movement",
							description: 'Here you can choose whether to enable or disable particle movement.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					movementDirection: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.movementDirection",
							label: "Direction",
							description: 'Here you can choose the direction of particle movement.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										'none': { label: 'None' },
										'top': { label: 'Top' },
										'top-left': { label: 'Top Left' },
										'top-right': { label: 'Top Right' },
										'bottom': { label: 'Bottom' },
										'bottom-left': { label: 'Bottom Left' },
										'bottom-right': { label: 'Bottom Right' },
									}
								}
							}
						}
					},
					movementSpeed: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.movementSpeed",
							label: "Speed",
							description: 'Here you can enter the movement speed of particles.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 10,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					enableHoverInteractivity: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.enableHoverInteractivity",
							label: "Enable OnHover Interactivity",
							description: 'Here you can choose whether to enable hover interactivity.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					hoverMode: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.hoverMode",
							label: "Hover mode",
							description: 'Here you can choose the on hover mode.',
							render: true,
							visible: this.enableHoverInteractivityCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										grab: { label: 'Grab' },
										bubble: { label: 'Bubble' },
										repulse: { label: 'Repulse' }
									}
								}
							}
						}
					},
					enableClickInteractivity: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.enableClickInteractivity",
							label: "Enable OnClick Interactivity",
							description: 'Here you can choose whether to enable click interactivity.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					clickMode: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.clickMode",
							label: "Hover mode",
							description: 'Here you can choose the on hover mode.',
							render: true,
							visible: this.enableClickInteractivityCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										push: { label: 'Push' },
										bubble: { label: 'Bubble' },
										repulse: { label: 'Repulse' },
										remove: { label: 'Remove' }
									}
								}
							}
						}
					},
					grabLinkedLineOpacity: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.grabLinkedLineOpacity",
							label: "Grab Mode Linked Line Opacity",
							description: 'Here you can choose the grab linked line opacity.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 0,
									max: 1,
									step: 0.1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					pushParticlesNumber: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.pushParticlesNumber",
							label: "Push Mode Particles Number",
							description: 'Here you can choose the push mode particles number.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 50,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					bubbleSize: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.bubbleSize",
							label: "Bubble Mode Bubble Size",
							description: 'Here you can choose the bubble size.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 20,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					},
					removeParticlesNumber: {
						groupType: "group-item",
						item: {
							groupSlug: "diplParticleBackground",
							attrName: "particleBackground.advanced.removeParticlesNumber",
							label: "Remove Mode Particles Number",
							description: 'Here you can choose the remove mode particles number.',
							render: true,
							visible: this.enableMovementCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 50,
									step: 1,
									allowedUnits: [ '' ],
									defaultUnit: '',
								}
							}
						}
					}
				}
			}
		};

		return attributes;
	}

	// Default attributes.
	defaultAttributes( defaultAttrs, config, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return defaultAttrs;
		}
		const newDefaultAttrs = {
			particleBackground: {
				advanced: {
					enable: {
						desktop: { value: "off" }
					},
					disabledOn: {
						desktop: { value: [] }
					},
					type: {
						desktop: { value: "circle" }
					},
					number: {
						desktop: { value: 80 }
					},
					density: {
						desktop: { value: 400 }
					},
					size: {
						desktop: { value: 3 }
					},
					color: {
						desktop: { value: "#ffffff" }
					},
					enableLinkedLine: {
						desktop: { value: "on" }
					},
					linkedLineSize: {
						desktop: { value: 1 }
					},
					linkedLineColor: {
						desktop: { value: "#ffffff" }
					},
					enableMovement: {
						desktop: { value: "on" }
					},
					movementDirection: {
						desktop: { value: "none" }
					},
					movementSpeed: {
						desktop: { value: 4 }
					},
					enableHoverInteractivity: {
						desktop: { value: "off" }
					},
					hoverMode: {
						desktop: { value: "grab" }
					},
					enableClickInteractivity: {
						desktop: { value: "off" }
					},
					clickMode: {
						desktop: { value: "push" }
					},
					grabLinkedLineOpacity: {
						desktop: { value: 0.5 }
					},
					pushParticlesNumber: {
						desktop: { value: 10 }
					},
					bubbleSize: {
						desktop: { value: 5 }
					},
					removeParticlesNumber: {
						desktop: { value: 10 }
					}
				}
			}
		};

		// Return the modified default attributes.
		return {
			...defaultAttrs,
			...newDefaultAttrs,
		};
	}

	// Module conversation outline.
	// https://devalpha.elegantthemes.com/docs/tutorials/module/advanced/customize-module-settings-output/convert-d4-custom-setting-values-continued#example-usage
	conversionOutline( conversionOutline, moduleName ) {
		// Here it return moduleName of divi 4, let do not check it enable or not,
		// simply convert it.
		// Check if the module name is 'et_pb_audio'.
		// if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
		// 	return defaultAttrs;
		// }

		// If not conversation outline data.
		if ( ! moduleName || ! conversionOutline?.module ) {
			return conversionOutline;
		}

		// Add the attrs to conversion.
		conversionOutline.module.dipl_enable_particle_background  = 'particleBackground.advanced.enable.*';
		conversionOutline.module.dipl_disabled_on                 = 'particleBackground.advanced.disabledOn.*'; // array.
		conversionOutline.module.dipl_particle_type               = 'particleBackground.advanced.type.*';
		conversionOutline.module.dipl_particle_number             = 'particleBackground.advanced.number.*';
		conversionOutline.module.dipl_particle_density            = 'particleBackground.advanced.density.*';
		conversionOutline.module.dipl_particle_size               = 'particleBackground.advanced.size.*';
		conversionOutline.module.dipl_particle_color              = 'particleBackground.advanced.color.*';
		conversionOutline.module.dipl_enable_linked_line          = 'particleBackground.advanced.enableLinkedLine.*';
		conversionOutline.module.dipl_linked_line_size            = 'particleBackground.advanced.linkedLineSize.*';
		conversionOutline.module.dipl_linked_line_color           = 'particleBackground.advanced.linkedLineColor.*';
		conversionOutline.module.dipl_enable_particle_movement    = 'particleBackground.advanced.enableMovement.*';
		conversionOutline.module.dipl_particle_movement_direction = 'particleBackground.advanced.movementDirection.*';
		conversionOutline.module.dipl_particle_movement_speed     = 'particleBackground.advanced.movementSpeed.*';
		conversionOutline.module.dipl_enable_hover_interactivity  = 'particleBackground.advanced.enableHoverInteractivity.*';
		conversionOutline.module.dipl_hover_mode                  = 'particleBackground.advanced.hoverMode.*';
		conversionOutline.module.dipl_enable_click_interactivity  = 'particleBackground.advanced.enableClickInteractivity.*';
		conversionOutline.module.dipl_click_mode                  = 'particleBackground.advanced.clickMode.*';
		conversionOutline.module.dipl_grab_linked_line_opacity    = 'particleBackground.advanced.grabLinkedLineOpacity.*';
		conversionOutline.module.dipl_push_particles_number       = 'particleBackground.advanced.pushParticlesNumber.*';
		conversionOutline.module.dipl_bubble_size                 = 'particleBackground.advanced.bubbleSize.*';
		conversionOutline.module.dipl_remove_particles_number     = 'particleBackground.advanced.removeParticlesNumber.*';

		// Use spread operator to merge with existing functions instead of overriding them.
		// This preserves any existing conversion functions while adding our custom icon converter.
		conversionOutline.valueExpansionFunctionMap = {
			...( conversionOutline.valueExpansionFunctionMap || {} ),
			dipl_disabled_on: 'window.divi.module.diplConvertParticleBgDisabledOn',
			// dipl_disabled_on: 'diplConvertParticleBgDisabledOn',
		};

		// Return the modified conversion outline.
		return conversionOutline;
	}

	// Check if extension enabled or not.
	enableExtCallback( {
		attrs,
		attrName,
		responsiveMode,
		stateMode,
	} ) {
		return 'on' === ( attrs?.particleBackground?.advanced?.enable?.desktop?.value || 'off' );
	}
	// Check if linked line enabled.
	enableLinkedLineCallback( { attrs } ) {
		return (
			'on' === ( attrs?.particleBackground?.advanced?.enable?.desktop?.value || 'off' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableLinkedLine?.desktop?.value || 'on' )
		);
	}
	enableMovementCallback( { attrs } ) {
		return (
			'on' === ( attrs?.particleBackground?.advanced?.enable?.desktop?.value || 'off' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableMovement?.desktop?.value || 'on' )
		);
	}
	enableHoverInteractivityCallback( { attrs } ) {
		return (
			'on' === ( attrs?.particleBackground?.advanced?.enable?.desktop?.value || 'off' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableMovement?.desktop?.value || 'on' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableHoverInteractivity?.desktop?.value || 'off' )
		);
	}
	enableClickInteractivityCallback( { attrs } ) {
		return (
			'on' === ( attrs?.particleBackground?.advanced?.enable?.desktop?.value || 'off' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableMovement?.desktop?.value || 'on' ) &&
			'on' === ( attrs?.particleBackground?.advanced?.enableClickInteractivity?.desktop?.value || 'off' )
		);
	}

	// Check if extension enabled for the module.
	isModuleExtensionEnabled( moduleName ) {
		const { enable_areas, dipl_modules } = window?.DiplParticleBackgroundExtData || {};

		// Check if enabled or not for section, row, column.
		if (
			( moduleName === 'divi/section' && ! enable_areas?.includes( 'sections' ) ) ||
			( moduleName === 'divi/row' && ! enable_areas?.includes( 'rows' ) ) ||
			( moduleName === 'divi/column' && ! enable_areas?.includes( 'columns' ) )
		) {
			return false;
		}
		
		// Check if enabled or not for modules.
		if (
			! [ 'divi/section', 'divi/row', 'divi/column' ].includes( moduleName ) &&
			( ! enable_areas?.includes( 'modules' ) || ! dipl_modules?.includes( moduleName ) )
		) {
			return false;
		}

		return true;
	}
}

new DiplParticleBackgroundExtension();
