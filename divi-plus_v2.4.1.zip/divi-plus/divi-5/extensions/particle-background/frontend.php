<?php
/**
 * Particle Background Extension Class.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DiplParticleBackgroundExtension {

	/**
	 * Alter frontend render.
	 */
	public static function render( $module_wrapper, $args, $enable_areas ) {
		$module_name     = $args['name'] ?? '';
		$module_attrs    = $args['attrs'] ?? '';
		$module_elements = $args['elements'] ?? '';

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $module_wrapper;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $module_wrapper;
		}

		// Check if extension enabled.
		$ext_attr         = $module_attrs['particleBackground']['advanced'] ?? [];
		$enable_extension = $ext_attr['enable']['desktop']['value'] ?? 'off';

		// if not enabled.
		if ( 'on' !== $enable_extension ) {
			return $module_wrapper;
		}
		
		// Get other attrs.
		$particle_type               = $ext_attr['type']['desktop']['value'] ?? 'circle';
		$particle_number             = $ext_attr['number']['desktop']['value'] ?? 80;
		$particle_density            = $ext_attr['density']['desktop']['value'] ?? 400;
		$particle_size               = $ext_attr['size']['desktop']['value'] ?? 3;
		$particle_color              = $ext_attr['color']['desktop']['value'] ?? '#ffffff';
		$enable_linked_line          = ( 'on' === ( $ext_attr['enableLinkedLine']['desktop']['value'] ?? 'on' ) ) ? 'true' : 'false';
		$linked_line_size            = $ext_attr['linkedLineSize']['desktop']['value'] ?? 1;
		$linked_line_color           = $ext_attr['linkedLineColor']['desktop']['value'] ?? '#ffffff';
		$enable_particle_movement    = ( 'on' === ( $ext_attr['enableMovement']['desktop']['value'] ?? 'on' ) ) ? 'true' : 'false';
		$particle_movement_direction = $ext_attr['movementDirection']['desktop']['value'] ?? 'none';
		$particle_movement_speed     = $ext_attr['movementSpeed']['desktop']['value'] ?? 4;
		$enable_hover_interactivity  = ( 'on' === ( $ext_attr['enableHoverInteractivity']['desktop']['value'] ?? 'on' ) ) ? 'true' : 'false';
		$hover_mode                  = $ext_attr['hoverMode']['desktop']['value'] ?? 'grab';
		$enable_click_interactivity  = ( 'on' === ( $ext_attr['enableClickInteractivity']['desktop']['value'] ?? 'on' ) ) ? 'true' : 'false';
		$click_mode                  = $ext_attr['clickMode']['desktop']['value'] ?? 'push';
		$grab_linked_line_opacity    = $ext_attr['grabLinkedLineOpacity']['desktop']['value'] ?? 0.5;
		$push_particles_number       = $ext_attr['pushParticlesNumber']['desktop']['value'] ?? 1;
		$bubble_size                 = $ext_attr['bubbleSize']['desktop']['value'] ?? 5;
		$remove_particles_number     = $ext_attr['removeParticlesNumber']['desktop']['value'] ?? 10;

		// Get order class.
		$order_class = $module_elements->order_class ?? '';
		if ( strpos( $order_class, '.' ) === 0 ) {
			$order_class = substr( $order_class, 1 );
		}

		// Load js.
		wp_enqueue_script( 'elicus-particle-script' );

		// Render script.
		$script = '<script>jQuery( document ).ready( function( $ ) {
				var element_id = $(".' . esc_attr( $order_class ) . '").attr("id");
				if ( typeof(element_id) === "undefined" || "" === element_id ) {
					element_id = "' . esc_attr( $order_class ) . '_particles";
					$(".' . esc_attr( $order_class ) . '").attr("id", element_id);
				}
			particlesJS( element_id, {
				"particles": {
					"number": {
						"value": '. $particle_number .',
						"density": {
							"enable": true,
							"value_area": '. $particle_density .'
						}
					},
					"color": {
						"value": "'. $particle_color .'"
					},
					"shape": {
						"type": "'. $particle_type .'",
						"stroke": {
							"width": 0,
							"color": "#000000"
						},
						"polygon": {
							"nb_sides": 5
						},
					},
					"opacity": {
						"value": 0.5,
						"random": false,
						"anim": {
							"enable": false,
							"speed": 1,
							"opacity_min": 0.1,
							"sync": false
						}
					},
					"size": {
						"value": '. $particle_size .',
						"random": true,
						"anim": {
							"enable": false,
							"speed": 40,
							"size_min": 0.1,
							"sync": false
						}
					},
					"line_linked": {
						"enable": '. $enable_linked_line .',
						"distance": 150,
						"color": "'. $linked_line_color .'",
						"opacity": 0.4,
						"width": '. $linked_line_size .'
					},
					"move": {
						"enable": '. $enable_particle_movement .',
						"speed": '. $particle_movement_speed .',
						"direction": "'. $particle_movement_direction .'",
						"random": false,
						"straight": false,
						"out_mode": "out",
						"bounce": false,
						"attract": {
							"enable": false,
							"rotateX": 600,
							"rotateY": 1200
						}
					}
				},
				"interactivity": {
					"detect_on": "canvas",
					"events": {
						"onhover": {
							"enable": '. $enable_hover_interactivity .',
							"mode": "'. $hover_mode .'"
						},
						"onclick": {
							"enable": '. $enable_click_interactivity .',
							"mode": "'. $click_mode .'"
						},
						"resize": true
					},
					"modes": {
						"grab": {
							"distance": 140,
							"line_linked": {
								"opacity": '. $grab_linked_line_opacity .'
							}
						},
						"bubble": {
							"distance": 400,
							"size": '. $bubble_size .',
							"duration": 2,
							"opacity": 8,
							"speed": 3
						},
						"repulse": {
							"distance": 200,
							"duration": 0.4
						},
						"push": {
							"particles_nb": '. $push_particles_number .'
						},
						"remove": {
							"particles_nb": '. $remove_particles_number .'
						}
					}
				},
				"retina_detect": true
			} );
		} );</script>';

		// Add style.
		self::style( $module_wrapper, $args );
		
		return $module_wrapper . $script;
	}

	/**
	 * Hook into module wrappers rendering process to add the additional module styles.
 	 *
	 * Unlike the implementation in VB, we don't need to modify the module wrapper output to render
	 * the additional module styles. We just need to hook into the target module wrapper rendering
	 * process to access all the necessary data to add the additional module styles using the
	 * `Style::add` class method.
	 *
	 * @param string $module_wrapper The module wrapper output.
	 * @param array  $args           The filter arguments.
	 *
	 * @return string The module wrapper output
	 */
	public static function style( $module_wrapper, $args ) {
		$module_id             = $args['id'] ?? '';
		$module_name           = $args['name'] ?? '';
		$module_order_index    = $args['orderIndex'] ?? 0;
		$module_store_instance = $args['storeInstance'] ?? 0;
		$module_attrs          = $args['attrs'] ?? [];
		$module_elements       = $args['elements'] ?? null;

		// Check if extension enabled.
		$ext_attr = $module_attrs['particleBackground']['advanced'] ?? [];
		$hide_on  = $ext_attr['disabledOn']['desktop']['value'] ?? [];

		$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
			'selector'            => "{$module_elements->order_class} canvas.particles-js-canvas-el",
			'attr'                => $ext_attr['enable'] ?? [],
			'declarationFunction' => function( $params ) {
				return 'position: absolute; top: 0; left: 0; width: 100%; height: 100%;';
			}
		] );

		// Hide on device.
		if ( ! empty( $hide_on ) && is_array( $hide_on ) ) {
			$hide_on_attr = [
				'desktop' => [ 'value' => in_array( 'desktop', $hide_on ) ? 'none' : 'block' ],
				'tablet'  => [ 'value' => in_array( 'tablet', $hide_on ) ? 'none' : 'block' ],
				'phone'   => [ 'value' => in_array( 'phone', $hide_on ) ? 'none' : 'block' ],
			];
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class} canvas.particles-js-canvas-el",
				'attr'     => $hide_on_attr,
				'property' => 'display'
			] );
		}

		// Additional module styles for the target module. The main module styles also use the
		// `Style::add` method to add the module and its elements styles.
		\ET\Builder\FrontEnd\Module\Style::add( [
			'id'            => $module_id,
			'name'          => $module_name,
			'orderIndex'    => $module_order_index,
			'storeInstance' => $module_store_instance,
			'styles'        => $additional_styles,
		] );

		return et_core_esc_previously( $module_wrapper );
	}

	/**
	 * Alter attributes.
	 */
	public static function attributes( $settings, $enable_areas ) {
		$module_name       = $settings['name'] ?? '';
		$module_attributes = $settings['attributes'] ?? false;

		if ( ! $module_attributes ) {
			return $settings;
		}

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $settings;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $settings;
		}

		$settings['attributes']['particleBackground'] = [
			'type'     => 'object',
			'selector' => '{{selector}} .particles-js-canvas-el',
			'settings' => [
				'advanced' => [
					'particleEnable' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.enable',
							'label'       => 'Enable Particle Background',
							'description' => 'Here you can choose whether to use particle background.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							],
						],
					],
					'disabledOn' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.disabledOn',
							'label'       => 'Hide Particle Background On',
							'description' => 'Here you can choose to hide particle background on device.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/checkboxes',
								'props' => [
									'options' => [
										[ 'label' => 'Phone', 'value' => 'phone' ],
										[ 'label' => 'Tablet', 'value' => 'tablet' ],
										[ 'label' => 'Desktop', 'value' => 'desktop' ],
									],
								],
							],
						],
					],
					'type' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.type',
							'label'       => 'Particle Type',
							'description' => 'Here you can choose the type of particle.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'circle'   => [ 'label' => 'Circle' ],
										'edge'     => [ 'label' => 'Edge' ],
										'triangle' => [ 'label' => 'Triangle' ],
										'star'     => [ 'label' => 'Star' ],
									],
								],
							],
						],
					],
					'number' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.number',
							'label'       => 'Particles Number',
							'description' => 'Here you can enter the number of particles you want to show.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'          => 10,
									'max'          => 300,
									'step'         => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								],
							],
						],
					],
					'density' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.density',
							'label'       => 'Particles Density',
							'description' => 'Here you can enter the density area for particles.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'          => 100,
									'max'          => 1000,
									'step'         => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								],
							],
						],
					],
					'size' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.size',
							'label'       => 'Particles Size',
							'description' => 'Here you can enter the size for particles.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'          => 1,
									'max'          => 100,
									'step'         => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								],
							],
						],
					],
					'color' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.color',
							'label'       => 'Particles Color',
							'description' => 'Here you can enter the color for particles.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/color-picker',
							],
						],
					],
					'enableLinkedLine' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.enableLinkedLine',
							'label'       => 'Enable Linked Line',
							'description' => 'Here you can choose whether to use linked lines.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							],
						],
					],
					'linkedLineSize' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.linkedLineSize',
							'label'       => 'Linked Line Size',
							'description' => 'HeHere you can enter the size for linked lines.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'          => 1,
									'max'          => 10,
									'step'         => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								],
							],
						],
					],
					'linkedLineColor' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.linkedLineColor',
							'label'       => 'Linked Line Color',
							'description' => 'Here you can enter the color for linked lines.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/color-picker',
							],
						],
					],
					'enableMovement' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.enableMovement',
							'label'       => 'Enable Particle Movement',
							'description' => 'Here you can choose whether to enable or disable particle movement.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							],
						],
					],
					'movementDirection' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.movementDirection',
							'label'       => 'Direction',
							'description' => 'Here you can choose the direction of particle movement.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'none'         => [ 'label' => 'None' ],
										'top'          => [ 'label' => 'Top' ],
										'top-left'     => [ 'label' => 'Top Left' ],
										'top-right'    => [ 'label' => 'Top Right' ],
										'bottom'       => [ 'label' => 'Bottom' ],
										'bottom-left'  => [ 'label' => 'Bottom Left' ],
										'bottom-right' => [ 'label' => 'Bottom Right' ],
									],
								],
							],
						],
					],
					'movementSpeed' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.movementSpeed',
							'label'       => 'Speed',
							'description' => 'Here you can enter the movement speed of particles.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'          => 1,
									'max'          => 10,
									'step'         => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								],
							],
						],
					],
					'enableHoverInteractivity' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.enableHoverInteractivity',
							'label'       => 'Enable OnHover Interactivity',
							'description' => 'Here you can choose whether to enable hover interactivity.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							],
						],
					],
					'hoverMode' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.hoverMode',
							'label'       => 'Hover mode',
							'description' => 'Here you can choose the on hover mode.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'grab'    => [ 'label' => 'Grab' ],
										'bubble'  => [ 'label' => 'Bubble' ],
										'repulse' => [ 'label' => 'Repulse' ],
									],
								],
							],
						],
					],
					'enableClickInteractivity' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.enableClickInteractivity',
							'label'       => 'Enable OnClick Interactivity',
							'description' => 'Here you can choose whether to enable click interactivity.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							],
						],
					],
					'clickMode' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.clickMode',
							'label'       => 'Hover mode',
							'description' => 'Here you can choose the on hover mode.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/toggle',
								'props' => [
									'options' => [
										'push'    => [ 'label' => 'Push' ],
										'bubble'  => [ 'label' => 'Bubble' ],
										'repulse' => [ 'label' => 'Repulse' ],
										'remove'  => [ 'label' => 'Remove' ]
									]
								]
							]
						]
					],
					'grabLinkedLineOpacity' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.grabLinkedLineOpacity',
							'label'       => 'Grab Mode Linked Line Opacity',
							'description' => 'Here you can choose the grab linked line opacity.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => "field",
								'name'  => "divi/range",
								'props' => [
									'min'  => 0,
									'max'  => 1,
									'step' => 0.1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								]
							]
						]
					],
					'pushParticlesNumber' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.pushParticlesNumber',
							'label'       => 'Push Mode Particles Number',
							'description' => 'Here you can choose the push mode particles number.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'  => 1,
									'max'  => 50,
									'step' => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								]
							]
						]
					],
					'bubbleSize' => [
						'groupType' => "group-item",
						'item'      => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.bubbleSize',
							'label'       => 'Bubble Mode Bubble Size',
							'description' => 'Here you can choose the bubble size.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'  => 1,
									'max'  => 20,
									'step' => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								]
							]
						]
					],
					'removeParticlesNumber' => [
						'groupType' => "group-item",
						'item' => [
							'groupSlug'   => 'diplParticleBackground',
							'attrName'    => 'particleBackground.advanced.removeParticlesNumber',
							'label'       => 'Remove Mode Particles Number',
							'description' => 'Here you can choose the remove mode particles number.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'  => 1,
									'max'  => 50,
									'step' => 1,
									'allowedUnits' => [ '' ],
									'defaultUnit'  => '',
								]
							]
						]
					]
				]
			]
		];

		return $settings;
	}
}
