<?php
/**
 * Divi Particle Background Class.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Particle_Background extends DiviPlusExtensions{

	// Background areas.
	public static $areas = '';

	public function __construct() {
		$pb_areas    = self::get_extension_option( 'dipl-particle-background-areas' );
		self::$areas = ! empty( $pb_areas ) && ! is_array( $pb_areas ) ? explode( ',', $pb_areas ) : [];

		// Load js file for visual builder.
		add_action( 'divi_visual_builder_assets_before_enqueue_scripts', array( __class__, 'enqueue_extention_package_assets' ) );
		add_filter( 'block_type_metadata_settings', array( __class__, 'register_frontend_attributes' ) );
		add_filter( 'divi_module_wrapper_render', array( __class__, 'filter_module_output_render' ), 10, 2 );
		add_filter( 'divi.moduleLibrary.conversion.moduleConversionOutline', array( __class__, 'conversion_outline' ), 10, 2 );
	}

	/**
	 * Load visual builder package manager file,
	 * to manage extention attributes, and render. 
	 */
	public static function enqueue_extention_package_assets() {
		// Bail early if either Divi 5 or Visual Builder is not enabled.
		if ( ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
			return;
		}

		$ext_data = array(
			'enable_areas' => self::$areas,
			'dipl_modules' => DiviPlusExtensions::dipl_get_modules(),
		);

		// Load script.
		\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
			'name'    => 'dipl-particle-background-ext',
			'version' => null,
			'script'  => [
				'src' => ELICUS_DIVI_PLUS_DIR_URL . 'divi-5/extensions/particle-background/visual-builder.js',
				'deps' => [
					'divi-module-library',
					'divi-vendor-wp-hooks',
					'divi-vendor-react',
					'jquery-core',
					'divi-rest',
					'wp-hooks',
				],
				'enqueue_top_window' => false,
				'enqueue_app_window' => true,
				'data_app_window'    => $ext_data,
				'args'               => [
					'in_footer' => false,
				],
			],
		] );
	}

	/**
	 * Register custom option field attributes (OPTIONAL).
	 *
	 * Only needed if you want to access the attribute definition on the server side
	 * (e.g., for front-end rendering or accessing field definitions).
	 * If you only need the setting in Visual Builder, you can skip this PHP hook.
	 *
	 * @param array $settings The module metadata settings.
	 *
	 * @return array The modified module metadata settings.
	 */
	public static function register_frontend_attributes( $settings ) {
		// Load frontend file.
		if ( ! class_exists( 'DiplParticleBackgroundExtension' ) ) {
			require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/particle-background/frontend.php';
		}

		return DiplParticleBackgroundExtension::attributes( $settings, self::$areas );
	}

	/**
	 * Modify the Audio module wrapper to add a new icon element and genre meta information.
	 * 
	 * ref: devalpha.elegantthemes.com/docs/tutorials/module/advanced/
	 * /customize-module-settings-output/modifying-module-output/
	 *
	 * @param string $module_wrapper The module wrapper output.
	 * @param array  $args           The filter arguments.
	 *
	 * @return string The modified module wrapper output.
	 */
	public static function filter_module_output_render( $module_wrapper, $args ) {
		// Load frontend file.
		if ( ! class_exists( 'DiplParticleBackgroundExtension' ) ) {
			require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/particle-background/frontend.php';
		}

		return DiplParticleBackgroundExtension::render( $module_wrapper, $args, self::$areas );
	}

	/**
	 * converts particle background
	 * attributes from d4 to d5.
	 */
	public static function conversion_outline( $conversion_outline, $module_name ) {

		$enabled_areas = self::$areas;

		if ( empty( $enabled_areas ) ) {
		    return $conversion_outline;
		}

		$modules         = DiviPlusExtensions::dipl_get_modules();
		$enabled_modules = in_array( 'modules', $enabled_areas, true ) ? $modules : [];

		$map = [
		    'sections' => 'divi/section',
		    'rows'     => 'divi/row',
		    'columns'  => 'divi/column',
		];

		foreach ( $map as $area => $module ) {
		    if ( in_array( $area, $enabled_areas, true ) ) {
		        $enabled_modules[] = $module;
		    }
		}

		if ( ! in_array( $module_name, $enabled_modules, true ) ) {
            return $conversion_outline;
        }

        if ( ! isset( $conversion_outline['module'] ) ) {
            $conversion_outline['module'] = [];
        }

        $map = [
		    'dipl_enable_particle_background'  => 'enable',
		    'dipl_disabled_on'                 => 'disabledOn',
		    'dipl_particle_type'               => 'type',
		    'dipl_particle_number'             => 'number',
		    'dipl_particle_density'            => 'density',
		    'dipl_particle_size'               => 'size',
		    'dipl_particle_color'              => 'color',
		    'dipl_enable_linked_line'          => 'enableLinkedLine',
		    'dipl_linked_line_size'            => 'linkedLineSize',
		    'dipl_linked_line_color'           => 'linkedLineColor',
		    'dipl_enable_particle_movement'    => 'enableMovement',
		    'dipl_particle_movement_direction' => 'movementDirection',
		    'dipl_particle_movement_speed'     => 'movementSpeed',
		    'dipl_enable_hover_interactivity'  => 'enableHoverInteractivity',
		    'dipl_hover_mode'                  => 'hoverMode',
		    'dipl_enable_click_interactivity'  => 'enableClickInteractivity',
		    'dipl_click_mode'                  => 'clickMode',
		    'dipl_grab_linked_line_opacity'    => 'grabLinkedLineOpacity',
		    'dipl_push_particles_number'       => 'pushParticlesNumber',
		    'dipl_bubble_size'                 => 'bubbleSize',
		    'dipl_remove_particles_number'     => 'removeParticlesNumber',
		];

		foreach ( $map as $key => $value ) {
		    $conversion_outline['module'][ $key ] = "particleBackground.advanced.{$value}.*";
		}

		$particle_background_function_map = [
			'dipl_disabled_on' => 'diplConvertParticleBgDisabledOn'
		];

		// Use `array_merge` to preserve existing functions instead of overriding them.
        // This ensures existing conversion functions are preserved while adding our custom icon converter.
        $conversion_outline['valueExpansionFunctionMap'] = array_merge(
            $conversion_outline['valueExpansionFunctionMap'] ?? [],
            $particle_background_function_map
        );

        // Return the modified conversion outline.
        return $conversion_outline;
	}
}

new DIPL_Particle_Background;
