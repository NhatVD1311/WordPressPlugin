<?php
/**
 * Divi Maintenance Mode Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Maintenance_Mode extends DiviPlusExtensions{

	public function __construct() {
		// Enable maintanance mode and load template.
		add_action( 'template_redirect', array( __class__, 'enable_maintenance_mode' ), 0 );
		add_action( 'admin_bar_menu', array( __class__, 'add_admin_bar_notice' ), 100 );
		add_action( 'admin_head', array( __CLASS__, 'maintenance_admin_bar_style' ) );
		add_action( 'wp_head', array( __CLASS__, 'maintenance_admin_bar_style' ) );
	}

	/**
	 * Load maintanance mode template.
	 */
	public static function enable_maintenance_mode() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-maintenance-mode-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// Allow admins.
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}
		// Allow admin, ajax, rest, login.
		if ( is_admin() || wp_doing_ajax() || defined( 'REST_REQUEST' ) ) {
			return;
		}

		// Get templates.
		$source = self::get_extension_option( 'dipl-maintenance-mode-layout-source' );
		$lib_id = self::get_extension_option( 'dipl-maintenance-mode-divi-lib-layout' );

		// Proper maintenance headers.
		status_header( 503 );
		nocache_headers();

		if ( 'divi_library' === $source && ! empty( $lib_id ) ) {
			include_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/maintenance-mode/templates/divi-library.php';
		} else {
			include_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/maintenance-mode/templates/custom.php';
		}
		exit;
	}

	/**
	 * Add admin bar notice.
	 */
	public static function add_admin_bar_notice( $wp_admin_bar ) {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-maintenance-mode-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings_url = admin_url( 'admin.php?page=divi-plus-options&menu=extensions&submenu=maintenance-mode' );
		$wp_admin_bar->add_node( array(
			'id'    => 'dipl-maintenance-active',
			'title' => '&#9888; ' . esc_html__( 'Maintenance Mode Active', 'divi-plus' ),
			'href'  => $settings_url,
			'meta'  => array(
				'title' => esc_attr__( 'Visitors currently see the maintenance page. Click to manage settings.', 'divi-plus' ),
			),
		) );
	}

	/**
	 * Admin bar notice style.
	 */
	public static function maintenance_admin_bar_style() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-maintenance-mode-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		} ?>
		<style>
			#wpadminbar #wp-admin-bar-dipl-maintenance-active > .ab-item {
				background-color: #dc3232 !important;
				color: #fff !important;
				font-weight: 600;
			}
			#wpadminbar #wp-admin-bar-dipl-maintenance-active:hover > .ab-item {
				background-color: #b32d2e !important;
				color: #fff !important;
			}
		</style>
		<?php
	}
}

new DIPL_Maintenance_Mode;
