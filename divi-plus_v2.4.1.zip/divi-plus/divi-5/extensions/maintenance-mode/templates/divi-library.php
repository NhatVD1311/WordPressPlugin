<?php
/**
 * Maintenance Mode — Divi Library template.
 *
 * This file is loaded by WordPress's template loader when Divi Library mode is active.
 * This replacing the $post with the selected library layout,
 * so wp_head() enqueues Divi's builder assets for that layout.
 */

defined( 'ABSPATH' ) || exit;

global $post, $wp_query;

$post = get_post( $lib_id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Intentional: this template replaces the global $post/$wp_query to render a Divi Library layout in place of the maintenance page content.
$wp_query->posts             = array( $post );
$wp_query->post              = $post;
$wp_query->found_posts       = 1;
$wp_query->post_count        = 1;
$wp_query->is_singular       = true;
$wp_query->is_page           = true;
$wp_query->is_404            = false;
$wp_query->queried_object    = $post;
$wp_query->queried_object_id = $lib_id;

setup_postdata( $post );
$wp_query->rewind_posts();
    
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'dipl-maintenance-layout-divi_library' ); ?>>
    <?php wp_body_open(); ?>
    <?php
    if ( $wp_query->have_posts() ) :
        $wp_query->the_post();
        the_content();
    endif;
    wp_reset_postdata(); ?>
<?php wp_footer(); ?>
</body>
</html>
