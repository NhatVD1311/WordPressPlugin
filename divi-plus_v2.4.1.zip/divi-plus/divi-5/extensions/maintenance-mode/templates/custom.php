<?php
/**
 * Maintenance Mode — Custom template.
 *
 * This file is loaded by WordPress's template loader when custom is active.
 */

defined( 'ABSPATH' ) || exit;

$page_title    = self::get_extension_option( 'dipl-maintenance-mode-page-title' );
$message       = self::get_extension_option( 'dipl-maintenance-mode-message' );

$page_bg_color = self::get_extension_option( 'dipl-maintenance-mode-bg-color' ) ?? '#ffffff';
$title_color   = self::get_extension_option( 'dipl-maintenance-mode-page-title-color' ) ?? '#000000';
$text_color    = self::get_extension_option( 'dipl-maintenance-mode-text-color' ) ?? '#333333';

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html( $page_title ); ?></title>
    <style>
    *,*::before,*::after{
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    html,body{ height: 100%; }
    body{
        background: <?php echo esc_html( $page_bg_color ); ?>;
        color: <?php echo esc_html( $text_color ); ?>;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 40px 20px;
        text-align: center;
        font-size: 1.25rem;
        line-height: 1.65;
    }
    .dipl-maintenance-mode-wrap{ max-width: 600px; }
    .dipl-maintenance-mode-icon{
        width: 75px;
        height: 75px;
        margin: 0 auto 28px;
        border-radius: 50%;
        border: 3px solid currentColor;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.7;
    }
    .dipl-maintenance-mode-icon svg{
        width: 38px;
        height: 38px;
    }
    h1{
        font-size: 2.1rem;
        font-weight: 700;
        margin-bottom: 14px;
        line-height: 1.3;
        color: <?php echo esc_html( $title_color ); ?>;
    }
    </style>
</head>
<body <?php body_class( 'dipl-maintenance-layout-custom' ); ?>>
    <?php wp_body_open(); ?>
    <div class="dipl-maintenance-mode-wrap">
        <div class="dipl-maintenance-mode-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
        </div>
        <h1><?php echo esc_html( $title ); ?></h1>
        <p><?php echo esc_html( $message ); ?></p>
    </div>
</body>
</html>
