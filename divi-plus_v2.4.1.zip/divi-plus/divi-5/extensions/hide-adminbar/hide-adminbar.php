<?php
/**
 * Hide Adminbar Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Hide_Adminbar extends DiviPlusExtensions{
	public function __construct() {
		add_action( 'after_setup_theme', array( __class__, 'handle_hide_adminbar' ) );
	}

	/**
	 * Handle Hide Adminbar
	 */
	public static function handle_hide_adminbar() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-hide-adminbar-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		// Not logged-in, no adminbar.
		if ( ! is_user_logged_in() ) {
			return;
		}

		// Check if user role wise hide.
		$user_roles   = self::get_extension_option( 'dipl-hide-adminbar-role' );
		$target_roles = array_filter( array_map( 'trim', explode( ',', $user_roles ) ) );
		if ( ! empty( $target_roles ) ) {
			// Explode the target roles, by comma seperated.
			$user = wp_get_current_user();
			foreach ( $target_roles as $role ) {
				if ( in_array( $role, (array) $user->roles, true ) ) {
					add_filter( 'show_admin_bar', '__return_false' );
					return;
				}
			}
			// Return if, adminbar is not to hide for current role.
			return;
		}

		add_filter( 'show_admin_bar', '__return_false' );
		return;
	}
}

new DIPL_Hide_Adminbar;
