<?php
/**
 * Divi Library Shortcode.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Divi_Library_Shortcode extends DiviPlusExtensions{
	public function __construct() {
		$divi_library_shortcodes = $this->get_extension_option( 'dipl-enable-divi-library-shortcodes' );
		if ( 'on' === $divi_library_shortcodes ) {
			add_filter( 'manage_et_pb_layout_posts_columns', array( $this, 'dipl_add_column_title' ) );
			add_action( 'manage_et_pb_layout_posts_custom_column' , array( $this, 'dipl_add_column_content' ), 10, 2 );
		}
		add_shortcode( 'dipl_divi_shortcode', array( $this, 'dipl_divi_shortcode' ) );
	}

    /**
     * Add library post column
     *
     * @param array $columns
     * @return array updated column
     */
	public function dipl_add_column_title( $columns ) {
		$columns['dipl_divi_shortcode'] = esc_html__( 'Shortcode', 'divi-plus' );
		return $columns;
	}

    /**
     * Return column value.
     *
     * @param string $column
     * @param int $post_id
     * @return string shortcode string
     */
	public function dipl_add_column_content( $column, $post_id ) {
		switch ( $column ) {
			case 'dipl_divi_shortcode':
				$shortcode = sprintf( '[%s id="%d"]', 'dipl_divi_shortcode', esc_attr( $post_id ) );
				echo esc_attr( $shortcode );
			break;
		}
	}

    /**
     * Shortcode for library.
     *
     * @param $atts
     * @return string html
     */
	public function dipl_divi_shortcode( $atts ) {
	    $atts = shortcode_atts( array(
	        'id' => '',
	    ), $atts, 'dipl_divi_shortcode' );

	    $layout_id = intval( $atts['id'] );
	    if ( 0 === $layout_id || '' === $layout_id ) {
	    	return '';
	    }

        // Shortcode or block to html.
        $content = do_shortcode( get_the_content( null, false, $layout_id ) );
        $content = apply_filters( 'the_content', $content );
		
		return $content;
	}
}

new DIPL_Divi_Library_Shortcode;
