<?php
/**
 * Divi Unfold Class.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Unfold extends DiviPlusExtensions{

	// Background areas.
	public static $areas = '';

	public function __construct() {

		// This is simple value, this not an array.
		self::$areas = self::get_extension_option( 'dipl-unfold-areas' );

        // Load js file for visual builder.
		add_action( 'divi_visual_builder_assets_before_enqueue_scripts', array( __class__, 'enqueue_extention_package_assets' ) );
		add_filter( 'block_type_metadata_settings', array( __class__, 'register_frontend_attributes' ) );
		add_filter( 'divi_module_library_module_default_attributes', array( __class__, 'register_frontend_default_attributes' ), 10, 2 );
		add_filter( 'divi_module_library_module_default_printed_style_attributes', array( __class__, 'register_frontend_default_attributes' ), 10, 2 );
		add_filter( 'divi_module_wrapper_render', array( __class__, 'filter_module_output_render' ), 10, 2 );
		add_filter( 'divi.moduleLibrary.conversion.moduleConversionOutline', array( __class__, 'conversion_outline' ), 10, 2 );
    }

    /**
	 * Load visual builder package manager file,
	 * to manage extention attributes, and render. 
	 */
	public static function enqueue_extention_package_assets() {
		// Bail early if either Divi 5 or Visual Builder is not enabled.
		if ( ! et_builder_d5_enabled() || ! et_core_is_fb_enabled() ) {
			return;
		}

		$ext_data = array(
			'enable_areas' => self::$areas,
			'dipl_modules' => DiviPlusExtensions::dipl_get_modules(),
		);

		// Load script.
		\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
			'name'    => 'dipl-unfold-ext',
			'version' => null,
			'script'  => [
				'src' => ELICUS_DIVI_PLUS_DIR_URL . 'divi-5/extensions/unfold/visual-builder.js',
				'deps' => [
					'divi-module-library',
					'divi-vendor-wp-hooks',
					'divi-vendor-react',
					'jquery-core',
					'divi-rest',
					'wp-hooks',
				],
				'enqueue_top_window' => false,
				'enqueue_app_window' => true,
				'data_app_window'    => $ext_data,
				'args'               => [
					'in_footer' => false,
				],
			],
		] );
	}

	/**
	 * Register custom option field attributes (OPTIONAL).
	 *
	 * Only needed if you want to access the attribute definition on the server side
	 * (e.g., for front-end rendering or accessing field definitions).
	 * If you only need the setting in Visual Builder, you can skip this PHP hook.
	 *
	 * @param array $settings The module metadata settings.
	 *
	 * @return array The modified module metadata settings.
	 */
	public static function register_frontend_attributes( $settings ) {
		// Load frontend file.
		if ( ! class_exists( 'DiplUnfoldExtension' ) ) {
			require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/unfold/frontend.php';
		}

		return DiplUnfoldExtension::attributes( $settings, self::$areas );
	}

	/**
	 *  Override the modules default attributes.
	 *
	 * @param array $default_attributes The module default attributes.
	 * @param array $metadata           The module metadata.
	 *
	 * @return array The modified module default attributes.
	 */
	public static function register_frontend_default_attributes( $default_attributes, $metadata ) {
		// Load frontend file.
		if ( ! class_exists( 'DiplUnfoldExtension' ) ) {
			require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/unfold/frontend.php';
		}

		return DiplUnfoldExtension::default_attributes( $default_attributes, $metadata, self::$areas );
	}

	/**
	 * Modify the Audio module wrapper to add a new icon element and genre meta information.
	 * 
	 * ref: devalpha.elegantthemes.com/docs/tutorials/module/advanced/
	 * /customize-module-settings-output/modifying-module-output/
	 *
	 * @param string $module_wrapper The module wrapper output.
	 * @param array  $args           The filter arguments.
	 *
	 * @return string The modified module wrapper output.
	 */
	public static function filter_module_output_render( $module_wrapper, $args ) {
		// Load frontend file.
		if ( ! class_exists( 'DiplUnfoldExtension' ) ) {
			require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/extensions/unfold/frontend.php';
		}

		return DiplUnfoldExtension::render( $module_wrapper, $args, self::$areas );
	}

	/**
	 * converts particle background
	 * attributes from d4 to d5.
	 */
	public static function conversion_outline( $conversion_outline, $module_name ) {
		
		$enabled_areas = self::$areas;

		if ( 'off' === $enabled_areas ) {
		    return $conversion_outline;
		}

		$modules         = DiviPlusExtensions::dipl_get_modules();
		$enabled_modules = $modules;

		if ( ! in_array( $module_name, $enabled_modules, true ) ) {
            return $conversion_outline;
        }

        if ( ! isset( $conversion_outline['module'] ) ) {
            $conversion_outline['module'] = [];
        }
        
        $conversion_outline['module']['dipl_enable_unfold']                 = 'diplUnfold.advanced.enable.*';
		$conversion_outline['module']['unfold_height']                      = 'diplUnfold.advanced.height.*';

		$conversion_outline['module']['unfold_background_1']                = 'diplUnfold.advanced.backgroundOne.*';
		$conversion_outline['module']['unfold_background_2']                = 'diplUnfold.advanced.backgroundTwo.*';
		$conversion_outline['module']['unfold_gradient_type']               = 'diplUnfold.advanced.gradientType.*';
		$conversion_outline['module']['unfold_linear_direction']            = 'diplUnfold.advanced.linearDirection.*';
		$conversion_outline['module']['unfold_radial_direction']            = 'diplUnfold.advanced.radialDirection.*';
		$conversion_outline['module']['unfold_gradient_start_position']     = 'diplUnfold.advanced.startPosition.*';
		$conversion_outline['module']['unfold_gradient_end_position']       = 'diplUnfold.advanced.endPosition.*';
		
		// $conversion_outline['module']['unfold_background_1']        		= 'diplUnfold.decoration.background.*.gradient.stops.0.color';
		// $conversion_outline['module']['unfold_background_2']        		= 'diplUnfold.decoration.background.*.gradient.stops.1.color';
		// $conversion_outline['module']['unfold_gradient_type']       		= 'diplUnfold.decoration.background.*.gradient.type';
		// $conversion_outline['module']['unfold_linear_direction']     	= 'diplUnfold.decoration.background.*.gradient.direction';
		// $conversion_outline['module']['unfold_radial_direction']       	= 'diplUnfold.decoration.background.*.gradient.directionRadial';
		// $conversion_outline['module']['unfold_gradient_start_position'] 	= 'diplUnfold.decoration.background.*.gradient.stops.0.position';
		// $conversion_outline['module']['unfold_gradient_end_position']   	= 'diplUnfold.decoration.background.*.gradient.stops.1.position';
		
		$conversion_outline['module']['unfold_container_custom_padding'] 	= 'diplUnfold.decoration.spacing.*.padding';
		
		$conversion_outline['module']['unfold_btn_text']             		= 'diplUnfoldButton.innerContent.*.text';
		$conversion_outline['module']['unfold_btn_custom_styling']   		= 'diplUnfoldButton.decoration.button.*.enable';
		$conversion_outline['module']['unfold_btn_font']            		= 'diplUnfoldButton.decoration.font.font.*';
		$conversion_outline['module']['unfold_btn_font_size']        		= 'diplUnfoldButton.decoration.font.font.*.size';
		$conversion_outline['module']['unfold_btn_color']            		= 'diplUnfoldButton.decoration.font.font.*.color';
		$conversion_outline['module']['unfold_btn_background']       		= 'diplUnfoldButton.decoration.background.*.color';
		$conversion_outline['module']['unfold_btn_border_size']      		= 'diplUnfoldButton.decoration.border.*.styles.all.width';
		$conversion_outline['module']['unfold_btn_border_color']     		= 'diplUnfoldButton.decoration.border.*.styles.all.color';
		$conversion_outline['module']['unfold_btn_border_radius']    		= 'diplUnfoldButton.decoration.border.*.radius';
		$conversion_outline['module']['unfold_button_use_icon']      		= 'diplUnfoldButton.decoration.button.*.icon.enable';
		$conversion_outline['module']['unfold_button_icon']          		= 'diplUnfoldButton.decoration.button.*.icon.settings';
		$conversion_outline['module']['unfold_button_icon_color']    		= 'diplUnfoldButton.decoration.button.*.icon.color';
		$conversion_outline['module']['unfold_button_icon_placement'] 		= 'diplUnfoldButton.decoration.button.*.icon.placement';
		$conversion_outline['module']['unfold_button_on_hover']      		= 'diplUnfoldButton.decoration.button.*.icon.onHover';
		$conversion_outline['module']['unfold_button_custom_padding'] 		= 'diplUnfoldButton.decoration.spacing.*.padding';
		$conversion_outline['module']['unfold_button_custom_margin'] 		= 'diplUnfoldButton.decoration.spacing.*.margin';

		$unfold_function_map = [
			'unfold_container_custom_padding' => 'convertSpacing',
			'unfold_button_custom_padding' => 'convertSpacing',
			'unfold_button_custom_margin' => 'convertSpacing',
			'unfold_button_icon' => 'convertFontIcon',
			// 'unfold_gradient_start_position' => 'diplConvertLegacyGradientProperty',
        	// 'unfold_gradient_end_position' => 'diplConvertLegacyGradientProperty',
        	'unfold_btn_border_radius' => 'diplConvertBorderRadii',
        	// 'unfold_gradient_type' => 'diplConvertManualGradientType',
        	// 'unfold_radial_direction' => 'diplConvertManualRadialGradient',
        	'unfold_btn_font' => 'diplConvertFont',
		];

		// Use `array_merge` to preserve existing functions instead of overriding them.
        // This ensures existing conversion functions are preserved while adding our custom icon converter.
        $conversion_outline['valueExpansionFunctionMap'] = array_merge(
            $conversion_outline['valueExpansionFunctionMap'] ?? [],
            $unfold_function_map
        );

		// Return the modified conversion outline.
		return $conversion_outline;
    }
}

new DIPL_Unfold;
