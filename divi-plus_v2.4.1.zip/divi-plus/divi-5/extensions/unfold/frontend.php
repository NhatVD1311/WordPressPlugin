<?php
/**
 * Particle Background Extension Class.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DiplUnfoldExtension {

	/**
	 * Alter attributes.
	 */
	public static function attributes( $settings, $enable_areas ) {
		$module_name       = $settings['name'] ?? '';
		$module_attributes = $settings['attributes'] ?? false;

		if ( ! $module_attributes ) {
			return $settings;
		}

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled, and it's only enable for modules.
		if ( 'on' !== $enable_areas || in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) ) {
			return $settings;
		}
		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, $dipl_modules ) ) {
			return $settings;
		}

		$settings['attributes']['diplUnfold'] = array(
			'type'     => 'object',
			'selector' => '{{selector}}__dipl-unfold',
			'settings' => [
				'decoration' => [
					// 'background' => [
					// 	'groupType' => 'group-item',
					// 	'item'      => [
					// 		'groupSlug' => 'diplUnfold',
					// 		'attrName'  => 'diplUnfold.decoration.background',
					// 		'render'    => true,
					// 		'priority'  => 30,
					// 		'component' => [
					// 			'type'  => 'group',
					// 			'name'  => 'divi/background',
					// 			'props' => [
					// 				'grouped'    => false,
					// 				'fieldLabel' => 'Unfold', // Label for the sub-group.
					// 				'hidePanels' => [ 'image', 'video', 'pattern', 'mask' ],
					// 			]
					// 		]
					// 	]
					// ],
					'spacing' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug' => 'diplUnfold',
							'attrName' => 'diplUnfold.decoration.spacing',
							'render' => true,
							'priority' => 35,
							'component' => [
								'type' => 'group',
								'name' => 'divi/spacing',
								'props' => [
									'grouped' => false,
									'fieldLabel' => 'Unfold Container',
									'fields' => [ 'margin' => [ 'render' => false ] ],
								],
							],
						]
					]
				],
				'advanced' => [
					'unfoldEnable' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplUnfold',
							'attrName'    => 'diplUnfold.advanced.enable',
							'label'       => 'Enable Unfold',
							'description' => 'Here you can choose whether it will show or hide on the unfold.',
							'render'      => true,
							'priority'    => 10,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							]
						]
					],
					'height' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplUnfold',
							'attrName'    => 'diplUnfold.advanced.height',
							'label'       => 'Unfold Box Max Height',
							'description' => 'Here you can enter the number of particles you want to show.',
							'render'      => true,
							'priority'    => 15,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/range',
								'props' => [
									'min'  => 10,
									'max'  => 1000,
									'step' => 1,
									'allowedUnits' => [ 'px' ],
									'defaultUnit'  => 'px',
								]
							]
						]
					],
					// Off by default so existing Unfold sections keep their current one-shot
					// expand behavior untouched unless explicitly opted into.
					'enableShrink' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplUnfold',
							'attrName'    => 'diplUnfold.advanced.enableShrink',
							'label'       => 'Enable Shrink Button',
							'description' => 'Here you can choose whether to show a button that collapses the content back after it has been unfolded.',
							'render'      => true,
							'priority'    => 20,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							]
						]
					],
					'scrollOnShrink' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplUnfold',
							'attrName'    => 'diplUnfold.advanced.scrollOnShrink',
							'label'       => 'Scroll To Top On Shrink',
							'description' => 'Here you can choose whether the page should automatically scroll back up to this section when it is collapsed again.',
							'render'      => true,
							'priority'    => 25,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/toggle',
							]
						]
					]
				]
			],
			'styleProps' => [
				'spacing' => [ 'important' => true ]
			]
		);
		$settings['attributes']['diplUnfoldButton'] = array(
			'type'         => 'object',
			'selector'     => '{{selector}}__dipl-unfold .et_pb_button',
			'elementType'  => 'button',
			'tagName'      => 'a',
			'elementProps' => [
				'hasWrapper' => false,
				'allowEmptyUrl' => true,
				'renderIconAsDataAttribute' => true
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'settings' => [
				'innerContent'  => [
					'groupType' => 'into-multiple-groups',
					'groups'    => [
						'text'  => [
							'groupType' => 'group-item',
							'item'      => [
								'groupSlug'   => 'diplUnfoldButton',
								'attrName'    => 'diplUnfoldButton.innerContent',
								'subName'     => 'text',
								'label'       => esc_html__( 'Unfold Expand Button Text', 'divi-plus' ),
								'description' => esc_html__( 'Define the text of the form submit button.', 'divi-plus' ),
								'render'      => true,
								'priority'    => 10,
								'component'   => [
									'type' => 'field',
									'name' => 'divi/text',
								]
							]
						]
					]
				],
				'decoration' => [
					'button' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug' => 'diplUnfoldButton',
							'render'    => true,
							'priority'  => 10,
							'component' => [
								'type'  => 'group',
								'name'  => 'divi/button',
								'props' => [
									'grouped'    => false,
									'attrName'   => 'diplUnfoldButton',
									'fieldLabel' => esc_html__( 'Unfold Expand Button', 'divi-plus' ),
									'fields'     => [ 'alignment' => [ 'render' => false ] ]
								],
							]
						]
					]
				]
			]
		);
		// New — mirrors diplUnfoldButton exactly. Only rendered/used when
		// diplUnfold.advanced.enableShrink is on (see render()); the field itself is only
		// shown in the panel when that toggle is on, via visual-builder.js's visibility
		// callback, matching how diplUnfoldButton's sibling fields are conditionally shown.
		$settings['attributes']['diplUnfoldShrinkButton'] = array(
			'type'         => 'object',
			'selector'     => '{{selector}}__dipl-unfold-shrink .et_pb_button',
			'elementType'  => 'button',
			'tagName'      => 'a',
			'elementProps' => [
				'hasWrapper' => false,
				'allowEmptyUrl' => true,
				'renderIconAsDataAttribute' => true
			],
			'childrenSanitizer' => 'et_core_esc_previously',
			'settings' => [
				'innerContent'  => [
					'groupType' => 'into-multiple-groups',
					'groups'    => [
						'text'  => [
							'groupType' => 'group-item',
							'item'      => [
								'groupSlug'   => 'diplUnfoldShrinkButton',
								'attrName'    => 'diplUnfoldShrinkButton.innerContent',
								'subName'     => 'text',
								'label'       => esc_html__( 'Unfold Shrink Button Text', 'divi-plus' ),
								'description' => esc_html__( 'Define the text of the form submit button.', 'divi-plus' ),
								'render'      => true,
								'priority'    => 10,
								'component'   => [
									'type' => 'field',
									'name' => 'divi/text',
								]
							]
						]
					]
				],
				'decoration' => [
					'button' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug' => 'diplUnfoldShrinkButton',
							'render'    => true,
							'priority'  => 10,
							'component' => [
								'type'  => 'group',
								'name'  => 'divi/button',
								'props' => [
									'grouped'    => false,
									'attrName'   => 'diplUnfoldShrinkButton',
									'fieldLabel' => esc_html__( 'Unfold Shrink Button', 'divi-plus' ),
									'fields'     => [ 'alignment' => [ 'render' => false ] ]
								],
							]
						]
					]
				]
			]
		);

    	return $settings;
	}

	/**
	 * Alter default attributes.
	 */
	public static function default_attributes( $default_attributes, $metadata, $enable_areas ) {
		$module_name = $metadata['name'] ?? '';

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled, and it's only enable for modules.
		if ( 'on' !== $enable_areas || in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) ) {
			return $default_attributes;
		}
		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, $dipl_modules ) ) {
			return $default_attributes;
		}

		$default_attributes['diplUnfold'] = array(
			'decoration' => [
				// 'background' => [
				// 	'desktop' => [
				// 		'gradient' => [
				// 			'enabled' => 'on',
				// 			'stops' => []
				// 		]
				// 	]
				// ],
				'spacing' => [
					'desktop' => [ 'value' => [
						'padding' => [
							'top'            => "150px",
							'bottom'         => "10px",
							'left'           => "",
							'right'          => "",
							'syncHorizontal' => "on",
							'syncVertical'   => "on"
						]
					] ]
				]
			],
			'advanced' => [
				'enable' => [
					'desktop' => [ 'value' => 'off' ]
				],
				'height' => [
					'desktop' => [ 'value' => '350px' ]
				],
				'backgroundOne' => [
					'desktop' => [ 'value' => 'rgba( 255, 255, 255, 0 )' ]
				],
				'backgroundTwo' => [
					'desktop' => [ 'value' => '#ffffff' ]
				],
				'gradientType' => [
					'desktop' => [ 'value' => 'linear-gradient' ]
				],
				'linearDirection' => [
					'desktop' => [ 'value' => '180deg' ]
				],
				'radialDirection' => [
					'desktop' => [ 'value' => 'circle at center' ]
				],
				'gradientStart' => [
					'desktop' => [ 'value' => '0%' ]
				],
				'gradientEnd' => [
					'desktop' => [ 'value' => '100%' ]
				],
				'enableShrink' => [
					'desktop' => [ 'value' => 'off' ]
				],
				'scrollOnShrink' => [
					'desktop' => [ 'value' => 'on' ]
				]
			]
		);

		$default_attributes['diplUnfoldButton'] = array(
			'innerContent' => [
				'desktop' => [ 'value' => [
					'text'       => esc_html__( 'View more', 'divi-plus' ),
					'linkUrl'    => '#',
					'linkTarget' => 'off'
				] ]
			]
		);

		$default_attributes['diplUnfoldShrinkButton'] = array(
			'innerContent' => [
				'desktop' => [ 'value' => [
					'text'       => esc_html__( 'View less', 'divi-plus' ),
					'linkUrl'    => '#',
					'linkTarget' => 'off'
				] ]
			]
		);

		return $default_attributes;
	}

	/**
	 * Alter frontend render.
	 */
	public static function render( $module_wrapper, $args, $enable_areas ) {
		$module_name     = $args['name'] ?? '';
		$module_attrs    = $args['attrs'] ?? '';
		$module_elements = $args['elements'] ?? '';

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled, and it's only enable for modules.
		if ( 'on' !== $enable_areas || in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) ) {
			return $module_wrapper;
		}
		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, $dipl_modules ) ) {
			return $module_wrapper;
		}

		// Check if unfold enabled.
		$unfold_enable = $module_attrs['diplUnfold']['advanced']['enable']['desktop']['value'] ?? 'off';
		if ( 'on' !== $unfold_enable ) {
			return $module_wrapper;
		}

		// Get order class.
		$order_class = $module_elements->base_order_class ?? ( $module_elements->order_class ?? '' );
		if ( strpos( $order_class, '.' ) === 0 ) {
			$order_class = substr( $order_class, 1 );
		}

		// Add custom link URL, and make sure the button always has text. The registered
		// default ("View more") is only used by the Visual Builder as a field placeholder —
		// it's never actually merged into the stored attrs unless the field is touched, so an
		// instance nobody has customized yet renders an empty, textless button without this
		// fallback. Doesn't affect the appearance or behavior of any instance that already has
		// text saved (which is every currently-published Unfold section).
		$expand_text_default = esc_html__( 'View more', 'divi-plus' );
		if ( empty( $module_attrs['diplUnfoldButton']['innerContent'] ) ) {
			$module_attrs['diplUnfoldButton']['innerContent'] = [
				'desktop' => [ 'value' => [ 'text' => $expand_text_default ] ],
			];
		}
		foreach ( $module_attrs['diplUnfoldButton']['innerContent'] as $device => &$val ) {
			if ( empty( $val['value'] ) ) {
				$val['value'] = [];
			}
			if ( empty( $val['value']['text'] ) ) {
				$val['value']['text'] = $expand_text_default;
			}
			$val['value']['linkUrl'] = '#' . esc_attr( $order_class );
		}
		unset( $val );

		// Render button. `elementAttr` is passed explicitly (not left to fall back to
		// $module_elements's own internal attrs) so the text fallback above actually reaches
		// the render — ModuleElements::render() ignores the local $module_attrs array
		// entirely unless the attrs for this element are supplied this way.
		$viewmore_btn = $module_elements->render( [
			'attrName'   => 'diplUnfoldButton',
			'elementAttr' => $module_attrs['diplUnfoldButton'],
			'attributes' => array(
				'href'                => '#' . esc_attr( $order_class ),
				'data-target-element' => '#' . esc_attr( $order_class )
			)
		] );

		// Shrink button is opt-in — off by default, so every existing Unfold section keeps
		// running through the exact same destructive one-shot expand it always has, below.
		$enable_shrink = $module_attrs['diplUnfold']['advanced']['enableShrink']['desktop']['value'] ?? 'off';

		if ( 'on' !== $enable_shrink ) {
			$module_wrapper = sprintf(
				'<div class="dipl-unfold-wrap %1$s__dipl-unfold_wrap">
					%2$s
					<div class="dipl-unfold-button %1$s__dipl-unfold">%3$s</div>
				</div>',
				esc_attr( $order_class ),
				$module_wrapper,
				$viewmore_btn
			);

			// Script.
			$module_wrapper .= '<script>jQuery( function($) {
				$( ".' . esc_attr( $order_class ) . '__dipl-unfold_wrap" ).on( "click", ".dipl-unfold-button .et_pb_button", function(e) {
					e.preventDefault();
					var thisObj   = $( this ),
						unfoldEle = ( thisObj.attr( "data-target-element" ) ).replace( "#", "" );

					thisObj.parents("." + unfoldEle + "__dipl-unfold_wrap").css( "cssText", "max-height: none !important;" );
					thisObj.parent().remove();

					return false;
		 		} );
			});</script>';
		} else {
			// Shrink Button on — non-destructive expand/collapse toggle instead: nothing is
			// ever removed from the DOM, a class is toggled on the wrap so the state can be
			// reversed.
			$scroll_on_shrink = $module_attrs['diplUnfold']['advanced']['scrollOnShrink']['desktop']['value'] ?? 'on';

			// Add custom link URL for the shrink button too, and make sure it always has text.
			// This is a brand new attribute group, so an instance that had Shrink switched on
			// before this field was ever touched can have genuinely empty stored text — and
			// Divi's button element renders nothing at all when text is empty, so without this
			// fallback the button would silently fail to appear. Doesn't affect the Expand
			// button or the existing default (off) path at all.
			$shrink_text_default = esc_html__( 'View less', 'divi-plus' );
			if ( empty( $module_attrs['diplUnfoldShrinkButton']['innerContent'] ) ) {
				$module_attrs['diplUnfoldShrinkButton']['innerContent'] = [
					'desktop' => [ 'value' => [ 'text' => $shrink_text_default ] ],
				];
			}
			foreach ( $module_attrs['diplUnfoldShrinkButton']['innerContent'] as $device => &$val ) {
				if ( empty( $val['value'] ) ) {
					$val['value'] = [];
				}
				if ( empty( $val['value']['text'] ) ) {
					$val['value']['text'] = $shrink_text_default;
				}
				$val['value']['linkUrl'] = '#' . esc_attr( $order_class );
			}
			unset( $val );

			$shrink_btn = $module_elements->render( [
				'attrName'    => 'diplUnfoldShrinkButton',
				'elementAttr' => $module_attrs['diplUnfoldShrinkButton'],
				'attributes'  => array(
					'href'                => '#' . esc_attr( $order_class ),
					'data-target-element' => '#' . esc_attr( $order_class )
				)
			] );

			$module_wrapper = sprintf(
				'<div class="dipl-unfold-wrap %1$s__dipl-unfold_wrap">
					%2$s
					<div class="dipl-unfold-button %1$s__dipl-unfold">%3$s</div>
					<div class="dipl-unfold-shrink-button %1$s__dipl-unfold-shrink">%4$s</div>
				</div>',
				esc_attr( $order_class ),
				$module_wrapper,
				$viewmore_btn,
				$shrink_btn
			);

			$scroll_js = ( 'on' === $scroll_on_shrink )
				? 'wrapEl.get(0).scrollIntoView( { behavior: "smooth", block: "start" } );'
				: '';

			// Script.
			$module_wrapper .= '<script>jQuery( function($) {
				$( ".' . esc_attr( $order_class ) . '__dipl-unfold_wrap" ).on( "click", ".dipl-unfold-button .et_pb_button", function(e) {
					e.preventDefault();
					$( this ).closest( ".dipl-unfold-wrap" ).addClass( "dipl-unfold-expanded" );
					return false;
				} );
				$( ".' . esc_attr( $order_class ) . '__dipl-unfold_wrap" ).on( "click", ".dipl-unfold-shrink-button .et_pb_button", function(e) {
					e.preventDefault();
					var wrapEl = $( this ).closest( ".dipl-unfold-wrap" );
					wrapEl.removeClass( "dipl-unfold-expanded" );
					' . $scroll_js . '
					return false;
				} );
			});</script>';
		}

		// Add style.
		self::style( $module_wrapper, $args );

		return $module_wrapper;
	}

	/**
	 * Hook into module wrappers rendering process to add the additional module styles.
 	 *
	 * Unlike the implementation in VB, we don't need to modify the module wrapper output to render
	 * the additional module styles. We just need to hook into the target module wrapper rendering
	 * process to access all the necessary data to add the additional module styles using the
	 * `Style::add` class method.
	 *
	 * @param string $module_wrapper The module wrapper output.
	 * @param array  $args           The filter arguments.
	 *
	 * @return string The module wrapper output
	 */
	public static function style( $module_wrapper, $args ) {
		$module_id             = $args['id'] ?? '';
		$module_name           = $args['name'] ?? '';
		$module_order_index    = $args['orderIndex'] ?? 0;
		$module_store_instance = $args['storeInstance'] ?? 0;
		$module_attrs          = $args['attrs'] ?? [];
		$module_elements       = $args['elements'] ?? null;

		// Check if extension enabled.
		$ext_attr = $module_attrs['diplUnfold']['advanced'] ?? [];

		// Wrapper styling.
		$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
			'selector'            => "{$module_elements->order_class}__dipl-unfold_wrap",
			'attr'                => $ext_attr['enable'] ?? [],
			'declarationFunction' => function( $params ) {
				return 'position: relative; overflow: hidden;';
			}
		] );
		$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
			'selector'            => "{$module_elements->order_class}__dipl-unfold",
			'attr'                => $ext_attr['enable'] ?? [],
			'declarationFunction' => function( $params ) {
				return 'position: absolute; display: flex; justify-content: center; padding-top: 150px; padding-bottom: 10px;
				width: 100%; bottom: 0; left: 0; transition: all .3s; z-index: 11;';
			}
		] );
		$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
			'selector' => "{$module_elements->order_class}__dipl-unfold .et_pb_button",
			'attr'     => [ 'desktop' => [ 'value' => 'inline-block' ] ],
			'property' => 'display'
		] );

		// Unfold section height.
		$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
			'selector' => "{$module_elements->order_class}__dipl-unfold_wrap",
			'attr'     => $module_attrs['diplUnfold']['advanced']['height'] ?? [ 'desktop' => [ 'value' => '350px' ] ],
			'property' => 'max-height'
		] );

		// Background of section.
		$gradient_type        = $module_attrs['diplUnfold']['advanced']['gradientType']['desktop']['value'] ?? 'linear-gradient';
		$background_one       = $module_attrs['diplUnfold']['advanced']['backgroundOne']['desktop']['value'] ?? 'rgba( 255, 255, 255, 0 )';
		$background_two       = $module_attrs['diplUnfold']['advanced']['backgroundTwo']['desktop']['value'] ?? '#ffffff';
		$background_hover_one = $module_attrs['diplUnfold']['advanced']['backgroundOne']['hover']['value'] ?? '';
		$background_hover_two = $module_attrs['diplUnfold']['advanced']['backgroundTwo']['hover']['value'] ?? '';

		$start_positions      = $module_attrs['diplUnfold']['advanced']['startPosition'] ?? [ 'desktop' => [ 'value' => '0%' ] ];
		$end_positions        = $module_attrs['diplUnfold']['advanced']['endPosition'] ?? [ 'desktop' => [ 'value' => '100%' ] ];
		if ( 'linear-gradient' === $gradient_type ) {
			// Linear direction.
			$linear_directions = $module_attrs['diplUnfold']['advanced']['linearDirection'] ?? [ 'desktop' => [ 'value' => '180deg' ] ];

			// Get breakpoints.
			$breakpoints = array_unique( array_merge(
				array_keys( $linear_directions ),
				array_keys( $start_positions ),
				array_keys( $end_positions )
			) );

			// default values.
			$linear_direction = '180deg';
			$start_position   = '0%';
			$end_position     = '100%';

			$bg_style = $bg_hover_style = [];
			foreach ( $breakpoints as $breakpoint ) {

				$linear_direction = $linear_directions[$breakpoint]['value'] ?? $linear_direction;
				$start_position   = $start_positions[$breakpoint]['value'] ?? $start_position;
				$end_position     = $end_positions[$breakpoint]['value'] ?? $end_position;

				$bg_style[ $breakpoint ] = [ 'value' => sprintf(
					'linear-gradient(%1$s, %2$s %3$s, %4$s %5$s);',
					esc_attr( $linear_direction ),
					esc_attr( $background_one ),
					esc_attr( $start_position ),
					esc_attr( $background_two ),
					esc_attr( $end_position )
				) ];
				if ( ! empty( $background_hover_one ) && ! empty( $background_hover_two ) ) {
					$bg_hover_style[ $breakpoint ] = [ 'value' => sprintf(
						'linear-gradient(%1$s, %2$s %3$s, %4$s %5$s);',
						esc_attr( $linear_direction ),
						esc_attr( $background_hover_one ),
						esc_attr( $start_position ),
						esc_attr( $background_hover_two ),
						esc_attr( $end_position )
					) ];
				}
			}

			// Add style.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class}__dipl-unfold",
				'attr'     => $bg_style,
				'property' => 'background'
			] );
			// Add hover style.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class}__dipl-unfold:hover",
				'attr'     => $bg_hover_style,
				'property' => 'background'
			] );
		}
		if ( 'radial-gradient' === $gradient_type ) {
			// Linear direction.
			$radial_directions = $module_attrs['diplUnfold']['advanced']['linearDirection'] ?? [ 'desktop' => [ 'value' => 'circle at center' ] ];

			// Get breakpoints.
			$breakpoints = array_unique( array_merge(
				array_keys( $radial_directions ),
				array_keys( $start_positions ),
				array_keys( $end_positions )
			) );

			// default values.
			$radial_direction = 'circle at center';
			$start_position   = '0%';
			$end_position     = '100%';

			$bg_style = $bg_hover_style = [];
			foreach ( $breakpoints as $breakpoint ) {

				$radial_direction = $radial_directions[$breakpoint]['value'] ?? $radial_direction;
				$start_position   = $start_positions[$breakpoint]['value'] ?? $start_position;
				$end_position     = $end_positions[$breakpoint]['value'] ?? $end_position;

				$bg_style[ $breakpoint ] = [ 'value' => sprintf(
					'radial-gradient(%1$s, %2$s %3$s, %4$s %5$s);',
					esc_attr( $radial_direction ),
					esc_attr( $background_one ),
					esc_attr( $start_position ),
					esc_attr( $background_two ),
					esc_attr( $end_position )
				) ];
				// Add hover style.
				if ( ! empty( $background_hover_one ) && ! empty( $background_hover_two ) ) {
					$bg_hover_style[ $breakpoint ] = [ 'value' => sprintf(
						'radial-gradient(%1$s, %2$s %3$s, %4$s %5$s);',
						esc_attr( $radial_direction ),
						esc_attr( $background_hover_one ),
						esc_attr( $start_position ),
						esc_attr( $background_hover_two ),
						esc_attr( $end_position )
					) ];
				}
			}

			// Add style.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class}__dipl-unfold",
				'attr'     => $bg_style,
				'property' => 'background'
			] );
			// Add hover style.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class}__dipl-unfold:hover",
				'attr'     => $bg_hover_style,
				'property' => 'background'
			] );
		}

		// Advanced style.
		$additional_styles[] = $module_elements->style( [
			'attrName' => 'diplUnfold',
		] );
		$additional_styles[] = $module_elements->style( [
			'attrName' => 'diplUnfoldButton',
		] );

		// Shrink Button styles — only added when it's actually on, so instances with it off
		// (the default) get no extra CSS at all, identical to before this feature existed.
		if ( 'on' === ( $ext_attr['enableShrink']['desktop']['value'] ?? 'off' ) ) {
			// Expanded state: remove the height clamp.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector'            => "{$module_elements->order_class}__dipl-unfold_wrap.dipl-unfold-expanded",
				'attr'                => $ext_attr['enableShrink'] ?? [],
				'declarationFunction' => function( $params ) {
					return 'max-height: none !important;';
				}
			] );
			// Expanded state: hide the Expand button + gradient overlay.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector'            => "{$module_elements->order_class}__dipl-unfold_wrap.dipl-unfold-expanded {$module_elements->order_class}__dipl-unfold",
				'attr'                => $ext_attr['enableShrink'] ?? [],
				'declarationFunction' => function( $params ) {
					return 'display: none;';
				}
			] );
			// Resting (collapsed) state: hide the Shrink button until expanded.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector'            => "{$module_elements->order_class}__dipl-unfold_wrap:not(.dipl-unfold-expanded) {$module_elements->order_class}__dipl-unfold-shrink",
				'attr'                => $ext_attr['enableShrink'] ?? [],
				'declarationFunction' => function( $params ) {
					return 'display: none;';
				}
			] );
			// Expanded state: position the Shrink button the same way the Expand button/gradient
			// is positioned at rest, so it visually replaces it in place rather than appearing
			// somewhere new.
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector'            => "{$module_elements->order_class}__dipl-unfold_wrap.dipl-unfold-expanded {$module_elements->order_class}__dipl-unfold-shrink",
				'attr'                => $ext_attr['enableShrink'] ?? [],
				'declarationFunction' => function( $params ) {
					return 'position: relative; display: flex; justify-content: center; padding-top: 10px; padding-bottom: 10px; width: 100%;';
				}
			] );
			$additional_styles[] = \ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle::style( [
				'selector' => "{$module_elements->order_class}__dipl-unfold-shrink .et_pb_button",
				'attr'     => [ 'desktop' => [ 'value' => 'inline-block' ] ],
				'property' => 'display'
			] );

			$additional_styles[] = $module_elements->style( [
				'attrName' => 'diplUnfoldShrinkButton',
			] );
		}

		// Additional module styles for the target module. The main module styles also use the
		// `Style::add` method to add the module and its elements styles.
		\ET\Builder\FrontEnd\Module\Style::add( [
			'id'            => $module_id,
			'name'          => $module_name,
			'orderIndex'    => $module_order_index,
			'storeInstance' => $module_store_instance,
			'styles'        => $additional_styles,
		] );

		return et_core_esc_previously( $module_wrapper );
	}
}
