/**
 * Unfold Extension Class.
 */
class DiplUnfoldExtension {

	constructor() {
		const { addFilter } = window.vendor.wp.hooks;

		// Add module groups, this will add to row, columns and section.
		addFilter( 'divi.moduleLibrary.moduleSettings.groups', 'divi-plus', this.groups.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleAttributes', 'divi-plus', this.attributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleDefaultAttributes', 'divi-plus', this.defaultAttributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleDefaultPrintedStyleAttributes', 'divi-plus', this.defaultAttributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.conversion.moduleConversionOutline', 'divi-plus', this.conversionOutline.bind( this ) );
	}

	// Add group for the attributes.
	groups( groups, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return groups;
		}		

		groups.diplUnfold = {
			groupName: 'diplUnfold',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Unfold Settings',
				}
			}
		}
		groups.diplUnfoldButton = {
			groupName: 'diplUnfoldButton',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Unfold Expand Button',
					visible: this.enableExtCallback,
				}
			}
		}
		groups.diplUnfoldShrinkButton = {
			groupName: 'diplUnfoldShrinkButton',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Unfold Shrink Button',
					visible: this.enableShrinkCallback,
				}
			}
		}

		// Return the modified groups.
		return groups;
	}

	// Add attributes.
	attributes( attributes, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return attributes;
		}

		// Unfold attrs.
		attributes.diplUnfold = {
			type: "object",
			selector: "{{selector}}__dipl-unfold",
			settings: {
				decoration: {
					// background: {
					// 	groupType: "group-item",
					// 	item: {
					// 		groupSlug: "diplUnfold",
					// 		attrName: "diplUnfold.decoration.background",
					// 		render: true,
					// 		priority: 30,
					// 		component: {
					// 			type: "group",
					// 			name: "divi/background",
					// 			props: {
					// 				grouped: false,
					// 				fieldLabel: 'Unfold', // Label for the sub-group.
					// 				hidePanels: [ 'image', 'video', 'pattern', 'mask' ],
					// 				visible: this.enableExtCallback,
					// 			}
					// 		}
					// 	}
					// },
					spacing: {
						groupType: 'group-item',
						item: {
							groupSlug: 'diplUnfold',
							attrName: 'diplUnfold.decoration.spacing',
							render: true,
							priority: 35,
							component: {
								type: 'group',
								name: 'divi/spacing',
								props: {
									grouped: false,
									fieldLabel: 'Unfold Container',
									fields: { margin: { render: false } },
									visible: this.enableExtCallback,
								},
							},
						}
					}
				},
				advanced: {
					unfoldEnable: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.enable",
							label: "Enable Unfold",
							description: 'Here you can choose whether it will show or hide on the unfold.',
							render: true,
							priority: 10,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					height: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.height",
							label: "Unfold Box Max Height",
							description: 'Here you can enter the number of particles you want to show.',
							render: true,
							priority: 15,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: true, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 10,
									max: 1000,
									step: 1,
									allowedUnits: [ 'px' ],
									defaultUnit: 'px',
								}
							}
						}
					},
					backgroundOne: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.backgroundOne",
							label: "Unfold Box Gradient Color 1",
							description: 'Customize the background style of the unfold box background by adjusting the background color, gradient.',
							render: true,
							priority: 20,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: true },
							component: {
								type: "field",
								name: "divi/color-picker"
							}
						}
					},
					backgroundTwo: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.backgroundTwo",
							label: "Unfold Box Gradient Color 2",
							description: 'Customize the background style of the unfold box background by adjusting the background color, gradient.',
							render: true,
							priority: 20,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: true },
							component: {
								type: "field",
								name: "divi/color-picker"
							}
						}
					},
					gradientType: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.gradientType",
							label: "Unfold Box Gradient Type",
							description: 'Here you can select Gradient Type.',
							render: true,
							priority: 20,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										'linear-gradient': { label: 'Linear' },
										'radial-gradient': { label: 'Radial' },
									}
								}
							}
						}
					},
					linearDirection: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.linearDirection",
							label: "Unfold Box Gradient Direction",
							description: 'Here you can select Linear Gradient Direction.',
							render: true,
							priority: 20,
							visible: this.enableLinearGradientCallback,
							features: { sticky: false, responsive: true, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 1,
									max: 360,
									step: 1,
									allowedUnits: [ 'deg' ],
									defaultUnit: 'deg',
								}
							}
						}
					},
					radialDirection: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.radialDirection",
							label: "Unfold Box Gradient Direction",
							description: 'Here you can select Linear Gradient Direction.',
							render: true,
							priority: 20,
							visible: this.enableradialGradientCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										'circle at center'       : { label: 'Center' },
										'circle at top left'     : { label: 'Top Left' },
										'circle at top'          : { label: 'Top' },
										'circle at top right'    : { label: 'Top Right' },
										'circle at bottom right' : { label: 'Bottom Right' },
										'circle at bottom'       : { label: 'Bottom' },
										'circle at bottom left'  : { label: 'Bottom Left' },
										'circle at left'         : { label: 'Left' },
									}
								}
							}
						}
					},
					startPosition: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.startPosition",
							label: "Gradient Start Position",
							description: 'Here you can select Unfold Box Gradient Start Position.',
							render: true,
							priority: 20,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: true, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 0,
									max: 100,
									step: 1,
									allowedUnits: [ '%' ],
									defaultUnit: '%',
								}
							}
						}
					},
					endPosition: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.endPosition",
							label: "Gradient End Position",
							description: 'Here you can select Unfold Box Gradient End Position.',
							render: true,
							priority: 20,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: true, hover: false },
							component: {
								type: "field",
								name: "divi/range",
								props: {
									min: 0,
									max: 100,
									step: 1,
									allowedUnits: [ '%' ],
									defaultUnit: '%',
								}
							}
						}
					},
					// Off by default so existing Unfold sections keep their current one-shot
					// expand behavior untouched unless explicitly opted into.
					enableShrink: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.enableShrink",
							label: "Enable Shrink Button",
							description: 'Here you can choose whether to show a button that collapses the content back after it has been unfolded.',
							render: true,
							priority: 35,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					scrollOnShrink: {
						groupType: "group-item",
						item: {
							groupSlug: "diplUnfold",
							attrName: "diplUnfold.advanced.scrollOnShrink",
							label: "Scroll To Top On Shrink",
							description: 'Here you can choose whether the page should automatically scroll back up to this section when it is collapsed again.',
							render: true,
							priority: 37,
							visible: this.enableShrinkCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
				}
			},
			styleProps: {
				spacing: { important: true }
			}
		};

		// Unfold button.
		attributes.diplUnfoldButton = {
			type: "object",
			elementType: "button",
			selector: "{{selector}}__dipl-unfold .et_pb_button",
			childrenSanitizer: 'et_core_esc_previously',
			elementProps: {
				hasWrapper: false,
				allowEmptyUrl: true,
				renderIconAsDataAttribute: true
			},
			settings: {
				innerContent: {
					groupType: "into-multiple-groups",
					groups: {
						text: {
							groupType: 'group-item',
							item: {
								groupSlug: "diplUnfoldButton",
								attrName: "diplUnfoldButton.innerContent",
								subName: "text",
								label: "Unfold Expand Button Text",
								description: 'Here you can enter the number of particles you want to show.',
								render: true,
								priority: 10,
								visible: this.enableExtCallback,
								features: { sticky: false, responsive: false, hover: false },
								component: {
									type: "field",
									name: "divi/text"
								}
							}
						},
						// linkUrl: {
						// 	groupType: 'group-item',
						// 	item: {
						// 		groupSlug: "diplUnfoldButton",
						// 		attrName: "diplUnfoldButton.innerContent",
						// 		subName: "linkUrl",
						// 		label: "Unfold Button Link",
						// 		description: 'Here you can enter the number of particles you want to show.',
						// 		render: true,
						// 		priority: 10,
						// 		visible: this.enableExtCallback,
						// 		features: { sticky: false, responsive: false, hover: false },
						// 		component: {
						// 			type: "field",
						// 			name: "divi/text"
						// 		}
						// 	}
						// }
					}
				},
				decoration: {
					button: {
						groupType: 'group-item',
						item: {
							groupSlug: 'diplUnfoldButton',
							render: true,
							priority: 20,
							component: {
								type: 'group',
								name: 'divi/button',
								props: {
									grouped: false,
									attrName: 'diplUnfoldButton',
									fieldLabel: 'Unfold Expand Button',
									visible: this.enableExtCallback,
									fields: { alignment: { render: false } }
								},
							}
						}
					}
				}
			}
		};

		// Unfold shrink button — mirrors diplUnfoldButton exactly, only shown when
		// diplUnfold.advanced.enableShrink is on (see enableShrinkCallback).
		attributes.diplUnfoldShrinkButton = {
			type: "object",
			elementType: "button",
			selector: "{{selector}}__dipl-unfold-shrink .et_pb_button",
			childrenSanitizer: 'et_core_esc_previously',
			elementProps: {
				hasWrapper: false,
				allowEmptyUrl: true,
				renderIconAsDataAttribute: true
			},
			settings: {
				innerContent: {
					groupType: "into-multiple-groups",
					groups: {
						text: {
							groupType: 'group-item',
							item: {
								groupSlug: "diplUnfoldShrinkButton",
								attrName: "diplUnfoldShrinkButton.innerContent",
								subName: "text",
								label: "Unfold Shrink Button Text",
								description: 'Here you can enter the number of particles you want to show.',
								render: true,
								priority: 10,
								visible: this.enableShrinkCallback,
								features: { sticky: false, responsive: false, hover: false },
								component: {
									type: "field",
									name: "divi/text"
								}
							}
						},
					}
				},
				decoration: {
					button: {
						groupType: 'group-item',
						item: {
							groupSlug: 'diplUnfoldShrinkButton',
							render: true,
							priority: 20,
							component: {
								type: 'group',
								name: 'divi/button',
								props: {
									grouped: false,
									attrName: 'diplUnfoldShrinkButton',
									fieldLabel: 'Unfold Shrink Button',
									visible: this.enableShrinkCallback,
									fields: { alignment: { render: false } }
								},
							}
						}
					}
				}
			}
		};

		return attributes;
	}

	// Default attributes.
	defaultAttributes( defaultAttrs, config, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return defaultAttrs;
		}

		const newDefaultAttrs = {
			diplUnfold: {
				decoration: {
					// background: {
					// 	desktop: { value: {
					// 		gradient: {
					// 			enabled: 'on',
					// 			stops: {}
					// 		}
					// 	} }
					// },
					spacing: {
						desktop: { value: {
							padding: {
								top            : "150px",
								bottom         : "10px",
								left           : "",
								right          : "",
								syncHorizontal : "on",
								syncVertical   : "off"
							}
						} }
					}
				},
				advanced: {
					enable: {
						desktop: { value: "off" }
					},
					height: {
						desktop: { value: "350px" }
					},
					backgroundOne: {
						desktop: { value: "rgba( 255, 255, 255, 0 )" }
					},
					backgroundTwo: {
						desktop: { value: "#ffffff" }
					},
					gradientType: {
						desktop: { value: "linear-gradient" }
					},
					linearDirection: {
						desktop: { value: "180deg" }
					},
					radialDirection: {
						desktop: { value: "circle at center" }
					},
					startPosition: {
						desktop: { value: "0%" }
					},
					endPosition: {
						desktop: { value: "100%" }
					},
					enableShrink: {
						desktop: { value: "off" }
					},
					scrollOnShrink: {
						desktop: { value: "on" }
					}
				}
			},
			diplUnfoldButton: {
				innerContent: {
					desktop: { value: {
						text: "View more",
						linkUrl: "#",
						linkTarget: "off"
					} }
				},
				decoration: {
					button: {
						desktop: { value: {
							enable: "off",
							icon: { enable: "off" }
						} }
					}
				}
			},
			diplUnfoldShrinkButton: {
				innerContent: {
					desktop: { value: {
						text: "View less",
						linkUrl: "#",
						linkTarget: "off"
					} }
				},
				decoration: {
					button: {
						desktop: { value: {
							enable: "off",
							icon: { enable: "off" }
						} }
					}
				}
			}
		};

		// Return the modified default attributes.
		return {
			...defaultAttrs,
			...newDefaultAttrs,
		};
	}

	conversionOutline( conversionOutline, moduleName ) {
		// If not conversation outline data.
		if ( ! moduleName || ! conversionOutline?.module ) {
			return conversionOutline;
		}

		conversionOutline.module.dipl_enable_unfold              = 'diplUnfold.advanced.enable.*';
		conversionOutline.module.unfold_height                   = 'diplUnfold.advanced.height.*';

		conversionOutline.module.unfold_background_1             = 'diplUnfold.advanced.backgroundOne.*';
		conversionOutline.module.unfold_background_2             = 'diplUnfold.advanced.backgroundTwo.*';
		conversionOutline.module.unfold_gradient_type            = 'diplUnfold.advanced.gradientType.*';
		conversionOutline.module.unfold_linear_direction         = 'diplUnfold.advanced.linearDirection.*';
		conversionOutline.module.unfold_radial_direction         = 'diplUnfold.advanced.radialDirection.*';
		conversionOutline.module.unfold_gradient_start_position  = 'diplUnfold.advanced.startPosition.*';
		conversionOutline.module.unfold_gradient_end_position    = 'diplUnfold.advanced.endPosition.*';
		
		// conversionOutline.module.unfold_background_1             = 'diplUnfold.decoration.background.*.gradient.stops[0].color';
		// conversionOutline.module.unfold_background_2             = 'diplUnfold.decoration.background.*.gradient.stops[1].color';
		// conversionOutline.module.unfold_gradient_type            = 'diplUnfold.decoration.background.*.gradient.type';
		// conversionOutline.module.unfold_linear_direction         = 'diplUnfold.decoration.background.*.gradient.direction';
		// conversionOutline.module.unfold_radial_direction         = 'diplUnfold.decoration.background.*.gradient.directionRadial';
		// conversionOutline.module.unfold_gradient_start_position  = 'diplUnfold.decoration.background.*.gradient.stops[0].position';
		// conversionOutline.module.unfold_gradient_end_position    = 'diplUnfold.decoration.background.*.gradient.stops[1].position';
		
		conversionOutline.module.unfold_container_custom_padding = 'diplUnfold.decoration.spacing.*.padding';
		
		conversionOutline.module.unfold_btn_text                 = 'diplUnfoldButton.innerContent.*.text';
		conversionOutline.module.unfold_btn_custom_styling       = 'diplUnfoldButton.decoration.button.*.enable';
		conversionOutline.module.unfold_btn_font                 = 'diplUnfoldButton.decoration.font.font.*';
		conversionOutline.module.unfold_btn_font_size            = 'diplUnfoldButton.decoration.font.font.*.size';
		conversionOutline.module.unfold_btn_color                = 'diplUnfoldButton.decoration.font.font.*.color';
		conversionOutline.module.unfold_btn_background           = 'diplUnfoldButton.decoration.background.*.color';
		conversionOutline.module.unfold_btn_border_size          = 'diplUnfoldButton.decoration.border.*.styles.all.width';
		conversionOutline.module.unfold_btn_border_color         = 'diplUnfoldButton.decoration.border.*.styles.all.color';
		conversionOutline.module.unfold_btn_border_radius        = 'diplUnfoldButton.decoration.border.*.radius';
		conversionOutline.module.unfold_button_use_icon          = 'diplUnfoldButton.decoration.button.*.icon.enable';
		conversionOutline.module.unfold_button_icon              = 'diplUnfoldButton.decoration.button.*.icon.settings';
		conversionOutline.module.unfold_button_icon_color        = 'diplUnfoldButton.decoration.button.*.icon.color';
		conversionOutline.module.unfold_button_icon_placement    = 'diplUnfoldButton.decoration.button.*.icon.placement';
		conversionOutline.module.unfold_button_on_hover          = 'diplUnfoldButton.decoration.button.*.icon.onHover';
		conversionOutline.module.unfold_button_custom_padding    = 'diplUnfoldButton.decoration.spacing.*.padding';
		conversionOutline.module.unfold_button_custom_margin     = 'diplUnfoldButton.decoration.spacing.*.margin';

		// Use spread operator to merge with existing functions instead of overriding them.
		// This preserves any existing conversion functions while adding our custom icon converter.
		conversionOutline.valueExpansionFunctionMap = {
    		...(conversionOutline.valueExpansionFunctionMap || {}),
		    unfold_container_custom_padding: 'window.divi.module.convertSpacing',
		    unfold_button_custom_padding: 'window.divi.module.convertSpacing',
		    unfold_button_custom_margin: 'window.divi.module.convertSpacing',
		    unfold_button_icon: 'window.divi.module.convertFontIcon',
		    // unfold_gradient_start_position: 'window.divi.module.diplConvertLegacyGradientProperty',
		    // unfold_gradient_end_position: 'window.divi.module.diplConvertLegacyGradientProperty',
		    unfold_btn_border_radius: 'window.divi.module.diplConvertBorderRadii',
		    unfold_btn_font: 'window.divi.module.diplConvertFont',
		};

		// Return the modified conversion outline.
		return conversionOutline;
	}

	// Check if extension enabled or not.
	enableExtCallback( {
		attrs,
		attrName,
		responsiveMode,
		stateMode,
	} ) {
		return 'on' === ( attrs?.diplUnfold?.advanced?.enable?.desktop?.value || 'off' );
	}
	enableLinearGradientCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplUnfold?.advanced?.enable?.desktop?.value || 'off' ) &&
			'linear-gradient' === ( attrs?.diplUnfold?.advanced?.gradientType?.desktop?.value || 'linear-gradient' )
		);
	}
	enableradialGradientCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplUnfold?.advanced?.enable?.desktop?.value || 'off' ) &&
			'radial-gradient' === ( attrs?.diplUnfold?.advanced?.gradientType?.desktop?.value || 'linear-gradient' )
		);
	}
	enableShrinkCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplUnfold?.advanced?.enable?.desktop?.value || 'off' ) &&
			'on' === ( attrs?.diplUnfold?.advanced?.enableShrink?.desktop?.value || 'off' )
		);
	}

	// Check if extension enabled for the module.
	isModuleExtensionEnabled( moduleName ) {
		const { enable_areas, dipl_modules } = window?.DiplUnfoldExtData || {};

		// This extension only for module.
		if ( [ 'divi/section', 'divi/row', 'divi/column' ].includes( moduleName ) ) {
			return false;
		}

		// Check if enabled or not for modules.
		if ( 'on' !== enable_areas || ! dipl_modules?.includes( moduleName ) ) {
			return false;
		}

		return true;
	}
}

new DiplUnfoldExtension();
