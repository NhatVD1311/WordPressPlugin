<?php
defined( 'ABSPATH' ) || exit;

$req       = get_option( 'require_name_email' );
$commenter = wp_get_current_commenter();
$user      = wp_get_current_user();
$logged_in = is_user_logged_in();

return array(

	// Wrapper div.
	'id_container'    => 'respond', // [WP-RULE] never change.
	'class_container' => 'comment-respond dipl-comment-box-ext dipl-cb-layout-3', // [WP-RULE] keep comment-respond, append your classes after.

	// Form element.
	'id_form'    => 'commentform',  // [WP-RULE] never change.
	'class_form' => 'comment-form', // [WP-RULE] keep comment-form, append your classes after.
	'action'     => site_url( '/wp-comments-post.php' ), // [WP-RULE] never change.

	// Title area.
	'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title">', // [WP-RULE] keep id="reply-title".
	'title_reply'        => __( 'Leave a Reply', 'divi-plus' ),
	'title_reply_to'     => __( 'Leave a Reply to %s', 'divi-plus' ),
	'title_reply_after'  => '</h3>',

	// Cancel reply.
	'cancel_reply_before' => ' <small>',
	'cancel_reply_after'  => '</small>',
	'cancel_reply_link'   => __( 'Cancel reply', 'divi-plus' ),

	// Logged in / must log in.
	'logged_in_as' => $logged_in
		? '<p class="logged-in-as">' .
			sprintf(
				__( 'Logged in as %2$s. <a href="%1$s">Edit your profile</a>. <a href="%3$s">Log out?</a>', 'divi-plus' ),
				esc_url( admin_url( 'profile.php' ) ),
				esc_html( $user->display_name ),
				esc_url( wp_logout_url( get_permalink() ) )
			) .
			( $req
				? ' ' . sprintf( __( 'Required fields are marked %s', 'divi-plus' ), '<span class="required">*</span>' )
				: ''
			) .
		  '</p>'
		: '',

	'must_log_in' => '<p class="must-log-in">' .
		sprintf(
			__( 'You must be <a href="%s">logged in</a> to post a comment.', 'divi-plus' ),
			esc_url( wp_login_url( get_permalink() ) )
		) .
	'</p>',

	'comment_notes_before' => '<p class="comment-notes">' .
		__( 'Your email address will not be published.', 'divi-plus' ) .
		( $req
			? ' ' . sprintf( __( 'Required fields are marked %s', 'divi-plus' ), '<span class="required">*</span>' )
			: ''
		) .
	'</p>',
	'comment_notes_after' => '',

	// Comment_field emptied — textarea moved into fields array below.
	'comment_field' => '',

	'fields' => array(

		// Textarea positioned here — after url, before cookies.
		'comment_box' => '<p class="comment-form-comment">' .
			'<label for="comment">' . __( 'Your Comment', 'divi-plus' ) . ' <span class="required">*</span></label>' .
			'<textarea id="comment" name="comment" cols="45" rows="' . absint( $textarea_rows ) . '" maxlength="65525" placeholder="" required></textarea>' .
		'</p>',
		// [WP-RULE] id="comment" name="comment" are fixed.

		'author' => '<div class="dipl-input-field-wrap"><p class="comment-form-author">' .
			'<label for="author">' . __( 'Your Name', 'divi-plus' ) . ( $req ? ' <span class="required">*</span>' : '' ) . '</label>' .
			'<input id="author" name="author" type="text"
				value="' . esc_attr( $commenter['comment_author'] ) . '"
				size="30" maxlength="245"' . ( $req ? ' required' : '' ) . ' />' .
		'</p></div>',

		'email' => '<div class="dipl-input-field-wrap"><p class="comment-form-email">' .
			'<label for="email">' . __( 'Your Email', 'divi-plus' ) . ( $req ? ' <span class="required">*</span>' : '' ) . '</label>' .
			'<input id="email" name="email" type="email"
				value="' . esc_attr( $commenter['comment_author_email'] ) . '"
				size="30" maxlength="100"' . ( $req ? ' required' : '' ) . ' />' .
		'</p></div>',

		'url' => '<div class="dipl-input-field-wrap"><p class="comment-form-url">' .
			'<label for="url">' . __( 'Website', 'divi-plus' ) . '</label>' .
			'<input id="url" name="url" type="url"
				value="' . esc_attr( $commenter['comment_author_url'] ) . '"
				size="30" maxlength="200" />' .
		'</p></div>',

		'cookies' => '<p class="comment-form-cookies-consent">' .
			'<input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent"
				type="checkbox" value="yes"' .
				( $commenter['comment_author_email'] ? ' checked' : '' ) . ' />' .
			'<label for="wp-comment-cookies-consent">' . __( 'Save my name, email, and website in this browser for the next time I comment.', 'divi-plus' ) . '</label>' .
		'</p>',
	),

	'submit_button' => '<input name="submit" type="submit" id="submit" class="submit et_pb_button" value="%4$s" />',
	'submit_field'  => '<p class="form-submit">%1$s %2$s</p>',
	'label_submit'  => __( 'Post Comment', 'divi-plus' ),
);
