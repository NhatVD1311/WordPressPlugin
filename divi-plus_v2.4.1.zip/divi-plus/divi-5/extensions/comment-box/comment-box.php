<?php
/**
 * Comment Box Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Comment_Box extends DiviPlusExtensions{
	public function __construct() {
		add_filter( 'comment_form_defaults', array( __class__, 'comment_box_apply_template' ), 99 );

		// Add cookie notice styles.
		add_action( 'wp_head',   array( __class__, 'output_comment_box_styles' ), 99 );
		add_action( 'wp_footer',   array( __class__, 'output_comment_box_script' ), 99 );
	}

	/**
	 * Comment form update.
	 */
	public static function comment_box_apply_template( $defaults ) {
		// Is singular or comment box is open.
		if ( ! is_singular() || ! comments_open() ) {
			return;
		}
		// Do not apply on WooCommerce product review form.
		if ( function_exists( 'is_product' ) && is_product() ) {
			return;
		}

		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-comment-box-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		$template      = self::get_extension_option( 'dipl-comment-box-layout', 'layout1' );
		$textarea_rows = self::get_extension_option( 'dipl-comment-box-textarea-rows', '8' );
		$file          = ELICUS_DIVI_PLUS_DIR_PATH . "divi-5/extensions/comment-box/templates/{$template}.php";
		if ( ! file_exists( $file ) ) {
			return $defaults; // Fallback to WP defaults if template file missing.
		}

		// Each template file returns an array of comment_form_defaults keys to override.
		$overrides = include $file;
		if ( is_array( $overrides ) ) {
			$defaults = array_merge( $defaults, $overrides );
		}

		return $defaults;
	}

	/**
	 * Comment box styling.
	 */
	public static function output_comment_box_styles() {
		// Is singular or comment box is open.
		if ( ! is_singular() || ! comments_open() ) {
			return;
		}
		// Do not apply on WooCommerce product review form.
		if ( function_exists( 'is_product' ) && is_product() ) {
			return;
		}

		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-comment-box-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		$layout = self::get_extension_option( 'dipl-comment-box-layout', 'layout1' );

		// Input attrs.
		$input_bg_color          = self::get_extension_option( 'dipl-comment-box-input-bg-color', 'transparent' );
		$input_bg_color_focus    = self::get_extension_option( 'dipl-comment-box-input-bg-color-focus', 'transparent' );
		$input_color             = self::get_extension_option( 'dipl-comment-box-input-text-color' );
		$input_color_focus       = self::get_extension_option( 'dipl-comment-box-input-text-color-focus' );
		$input_fontsize          = self::get_extension_option( 'dipl-comment-box-input-fontsize' );
		$input_padding_top       = self::get_extension_option( 'dipl-comment-box-input-padding__top' );
		$input_padding_bottom    = self::get_extension_option( 'dipl-comment-box-input-padding__bottom' );
		$input_padding_left      = self::get_extension_option( 'dipl-comment-box-input-padding__left' );
		$input_padding_right     = self::get_extension_option( 'dipl-comment-box-input-padding__right' );
		// Textarea attrs.
		$textarea_overwrite      = self::get_extension_option( 'dipl-comment-box-textarea-overwrite', 'off' );
		$textarea_fontsize       = self::get_extension_option( 'dipl-comment-box-textarea-fontsize' );
		$textarea_bg_color       = self::get_extension_option( 'dipl-comment-box-textarea-bg-color' );
		$textarea_text_color     = self::get_extension_option( 'dipl-comment-box-textarea-text-color' );
		$textarea_padding_top    = self::get_extension_option( 'dipl-comment-box-textarea-padding__top' );
		$textarea_padding_bottom = self::get_extension_option( 'dipl-comment-box-textarea-padding__bottom' );
		$textarea_padding_left   = self::get_extension_option( 'dipl-comment-box-textarea-padding__left' );
		$textarea_padding_right  = self::get_extension_option( 'dipl-comment-box-textarea-padding__right' );
		$textarea_fc_bg_color    = self::get_extension_option( 'dipl-comment-box-textarea-bg-color-focus' );
		$textarea_fc_text_color  = self::get_extension_option( 'dipl-comment-box-textarea-text-color-focus' );
		// Button attrs.
		$btn_bg_color            = self::get_extension_option( 'dipl-comment-box-submit-bg-color' );
		$btn_bg_color_hover      = self::get_extension_option( 'dipl-comment-box-submit-bg-color-hover' );
		$btn_txt_color           = self::get_extension_option( 'dipl-comment-box-submit-text-color' );
		$btn_txt_color_hover     = self::get_extension_option( 'dipl-comment-box-submit-text-color-hover' );
		$btn_border_size         = self::get_extension_option( 'dipl-comment-box-submit-border-size' );
		$btn_border_color        = self::get_extension_option( 'dipl-comment-box-submit-border-color' );
		$btn_border_radius       = self::get_extension_option( 'dipl-comment-box-submit-border-radius' );
		$btn_padding_top         = self::get_extension_option( 'dipl-comment-box-submit-padding__top' );
		$btn_padding_bottom      = self::get_extension_option( 'dipl-comment-box-submit-padding__bottom' );
		$btn_padding_left        = self::get_extension_option( 'dipl-comment-box-submit-padding__left' );
		$btn_padding_right       = self::get_extension_option( 'dipl-comment-box-submit-padding__right' );

		// Textarea style.
		$textarea_style = '';
		$textarea_focus_style = '';
		if ( 'on' === $textarea_overwrite ) {
			$textarea_style .= ! empty( $textarea_fontsize ) ? "font-size: {$textarea_fontsize}px;" : '';
			$textarea_style .= ! empty( $textarea_bg_color ) ? "background: {$textarea_bg_color};" : '';
			$textarea_style .= ! empty( $textarea_text_color ) ? "color: {$textarea_text_color};" : '';

			$textarea_style .= ! empty( $textarea_padding_top ) ? "padding-top: {$textarea_padding_top}px;" : '';
			$textarea_style .= ! empty( $textarea_padding_bottom ) ? "padding-bottom: {$textarea_padding_bottom}px;" : '';
			$textarea_style .= ! empty( $textarea_padding_left ) ? "padding-left: {$textarea_padding_left}px;" : '';
			$textarea_style .= ! empty( $textarea_padding_right ) ? "padding-right: {$textarea_padding_right}px;" : '';

			$textarea_focus_style .= ! empty( $textarea_fc_bg_color ) ? "background: {$textarea_fc_bg_color};" : '';
			$textarea_focus_style .= ! empty( $textarea_fc_text_color ) ? "color: {$textarea_fc_text_color};" : '';
		}
		
		// Button style.
		$button_style  = '';
		$button_style .= ! empty( $btn_bg_color ) ? "background: {$btn_bg_color};" : '';
		$button_style .= ! empty( $btn_txt_color ) ? "color: {$btn_txt_color};" : '';

		$button_style .= ( ! empty( $btn_border_size ) || 0 === intval( $btn_border_size ) ) ? "border-width: {$btn_border_size}px;" : '';
		$button_style .= ! empty( $btn_border_color ) ? "border-color: {$btn_border_color};" : '';
		$button_style .= ( ! empty( $btn_border_radius ) || 0 === intval( $btn_border_radius ) ) ? "border-radius: {$btn_border_radius}px;" : '';

		$button_style .= ! empty( $btn_padding_top ) ? "padding-top: {$btn_padding_top}px;" : '';
		$button_style .= ! empty( $btn_padding_bottom ) ? "padding-bottom: {$btn_padding_bottom}px;" : '';
		$button_style .= ! empty( $btn_padding_left ) ? "padding-left: {$btn_padding_left}px;" : '';
		$button_style .= ! empty( $btn_padding_right ) ? "padding-right: {$btn_padding_right}px;" : '';

		?>
		<style id="dipl-comment-box-extension-css">
			<?php
			// Layout 1 and layout 2 both have same style.
			if ( 'layout1' === $layout || 'layout2' === $layout ) {
				echo self::comment_box_layout1_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns pre-built, static/trusted CSS markup; escaping here would break the <style> output.
			} elseif ( 'layout3' === $layout ) {
				echo self::comment_box_layout3_style(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns pre-built, static/trusted CSS markup; escaping here would break the <style> output.
			} ?>
			.dipl-comment-box-ext #commentform p input[type="text"],
			.dipl-comment-box-ext #commentform p input[type="email"],
			.dipl-comment-box-ext #commentform p input[type="url"],
			.dipl-comment-box-ext #commentform p textarea{
				background: <?php echo esc_attr( $input_bg_color ); ?>;
				<?php echo ! empty( $input_color ) ? 'color: ' . esc_attr( $input_color ) . ';' : ''; ?>
				<?php echo ! empty( $input_fontsize ) ? 'font-size: ' . absint( $input_fontsize ) . 'px;' : ''; ?>
				<?php echo ! empty( $input_padding_top ) ? 'padding-top: ' . intval( $input_padding_top ) . 'px;' : ''; ?>
				<?php echo ! empty( $input_padding_bottom ) ? 'padding-bottom: ' . intval( $input_padding_bottom ) . 'px;' : ''; ?>
				<?php echo ! empty( $input_padding_left ) ? 'padding-left: ' . intval( $input_padding_left ) . 'px;' : ''; ?>
				<?php echo ! empty( $input_padding_right ) ? 'padding-right: ' . intval( $input_padding_right ) . 'px;' : ''; ?>
			}
			<?php
			if ( 'on' === $textarea_overwrite && ! empty( $textarea_style ) ) { ?>
				.dipl-comment-box-ext #commentform p textarea{
					<?php echo esc_attr( $textarea_style ); ?>
				}
			<?php } ?>
			.dipl-comment-box-ext #commentform p input[type="text"]:focus,
			.dipl-comment-box-ext #commentform p input[type="email"]:focus,
			.dipl-comment-box-ext #commentform p input[type="url"]:focus,
			.dipl-comment-box-ext #commentform p textarea:focus{
				<?php echo ! empty( $input_bg_color_focus ) ? 'background: ' . esc_attr( $input_bg_color_focus ) . ';' : ''; ?>
				<?php echo ! empty( $input_color_focus ) ? 'color: ' . esc_attr( $input_color_focus ) . ';' : ''; ?>
			}
			<?php
			if ( 'on' === $textarea_overwrite && ! empty( $textarea_focus_style ) ) { ?>
				.dipl-comment-box-ext #commentform p textarea:focus{
					<?php echo esc_attr( $textarea_focus_style ); ?>
				}
			<?php }
			// Button style.
			if ( ! empty( $button_style ) ) { ?>
				.dipl-comment-box-ext #commentform p.form-submit .submit{
					<?php echo esc_attr( $button_style ); ?>
				}
			<?php } ?>
			.dipl-comment-box-ext #commentform p.form-submit .submit:hover{
				<?php echo ! empty( $btn_bg_color_hover ) ? 'background: ' . esc_attr( $btn_bg_color_hover ) . ';' : ''; ?>
				<?php echo ! empty( $btn_txt_color_hover ) ? 'color: ' . esc_attr( $btn_txt_color_hover ) . ';' : ''; ?>
			}
		</style>
	<?php
	}

	/**
	 * Comment box script.
	 */
	public static function output_comment_box_script() {
		// Is singular or comment box is open.
		if ( ! is_singular() || ! comments_open() ) {
			return;
		}
		// Do not apply on WooCommerce product review form.
		if ( function_exists( 'is_product' ) && is_product() ) {
			return;
		}

		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-comment-box-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		$layout = self::get_extension_option( 'dipl-comment-box-layout', 'layout1' );
		?>
		<script id="dipl-comment-box-extension-js">
			<?php
			// Layout 3 style.
			if ( 'layout3' === $layout ) {
				echo self::comment_box_layout3_script(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns pre-built, static/trusted JS markup; escaping here would break the <script> output.
			} ?>
		</script>
	<?php
	}

	/**
	 * Layout 1 and 2 style.
	 */
	public static function comment_box_layout1_style() {
		return (
			'.dipl-comment-box-ext #commentform .comment-form-comment,
			.dipl-comment-box-ext #commentform .comment-form-author,
			.dipl-comment-box-ext #commentform .comment-form-email,
			.dipl-comment-box-ext #commentform .comment-form-url{
				padding: 0; margin-bottom: 30px;
			}
			.dipl-comment-box-ext #commentform p input[type="text"]::placeholder,
			.dipl-comment-box-ext #commentform p input[type="email"]::placeholder,
			.dipl-comment-box-ext #commentform p input[type="url"]::placeholder,
			.dipl-comment-box-ext #commentform p textarea::placeholder{
				font-style: italic;
			}
			.dipl-comment-box-ext #commentform .dipl-input-field-wrap{
				display: flex; gap: 20px;
			}
			.dipl-comment-box-ext #commentform .dipl-input-field-wrap > p{
				flex: 1;
			}
			.dipl-comment-box-ext #commentform p input[type="text"],
			.dipl-comment-box-ext #commentform p input[type="email"],
			.dipl-comment-box-ext #commentform p input[type="url"],
			.dipl-comment-box-ext #commentform p textarea{
				display: block; width: 100%; border: 1px solid #d7d7d7;
			}
			.dipl-comment-box-ext .form-submit{ text-align: left; }
			.dipl-comment-box-ext .comment-form-cookies-consent{ font-size: 16px; margin-bottom: 10px; }
			.dipl-comment-box-ext .comment-form-cookies-consent input{
				width: 22px; height: 22px; margin: 0 10px 3px 1px; vertical-align: middle;
			}'
		);
	}

	/**
	 * Layout 3 style.
	 */
	public static function comment_box_layout3_style() {
		return (
			'.dipl-comment-box-ext .form-submit{ text-align: left; }
			.dipl-comment-box-ext #commentform .comment-form-comment,
			.dipl-comment-box-ext #commentform .comment-form-author,
			.dipl-comment-box-ext #commentform .comment-form-email,
			.dipl-comment-box-ext #commentform .comment-form-url{
				padding: 0; margin-bottom: 35px;
			}
			.dipl-comment-box-ext #commentform p input[type="text"],
			.dipl-comment-box-ext #commentform p input[type="email"],
			.dipl-comment-box-ext #commentform p input[type="url"],
			.dipl-comment-box-ext #commentform p textarea{
				display: block; width: 100%; border-bottom: 1px solid #d7d7d7;
				background: transparent;
			}
			.dipl-comment-box-ext p label:not([for="wp-comment-cookies-consent"]){
				display: block; text-transform: uppercase; font-weight: 600;
			}
			.dipl-comment-box-ext .comment-form-cookies-consent{ font-size: 16px; margin-bottom: 10px; }
			.dipl-comment-box-ext .comment-form-cookies-consent input{
				width: 22px; height: 22px; margin: 0 10px 3px 1px; vertical-align: middle;
			}'
		);
	}

	/**
	 * Layout 3 script.
	 */
	public static function comment_box_layout3_script() {
		return (
			'// Run after Divi\'s DOMContentLoaded — using window.load to ensure Divi runs first.
			window.addEventListener( "load", function() {
				var form = document.getElementById( "commentform" );
				if ( ! form ) return;
				form.querySelectorAll( "input[type="text"], input[type="email"], input[type="url"], textarea" ).forEach( function(el) {
					var label = el.parentNode.querySelector( "label" );
					// Divi sets input value = label text — we clear it only if it matches.
					if ( label && el.value === label.textContent.trim() ) {
						el.value = "";
					}
				} );
			} );'
		);
	}
}

new DIPL_Comment_Box;
