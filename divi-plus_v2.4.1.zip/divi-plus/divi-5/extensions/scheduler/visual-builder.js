/**
 * Scheduler Extension Class.
 */
class DiplSchedulerExtension {

	constructor() {
		const { addFilter } = window.vendor.wp.hooks;

		// Add module groups, this will add to row, columns and section.
		addFilter( 'divi.moduleLibrary.moduleSettings.groups', 'divi-plus', this.groups.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleAttributes', 'divi-plus', this.attributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.moduleDefaultAttributes', 'divi-plus', this.defaultAttributes.bind( this ) );
		addFilter( 'divi.moduleLibrary.conversion.moduleConversionOutline', 'divi-plus', this.conversionOutline.bind( this ) );
	}

	// Add group for the attributes.
	groups( groups, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return groups;
		}		

		groups.diplScheduler = {
			groupName: 'diplScheduler',
			panel: 'advanced',
			priority: 100,
			multiElements: true,
			component: {
				name: 'divi/composite',
				props: {
					groupLabel: 'Scheduler',
				}
			}
		}

		// Return the modified groups.
		return groups;
	}

	// Add attributes.
	attributes( attributes, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return attributes;
		}

		attributes.diplScheduler = {
			type: "object",
			// selector: "{{selector}} .particles-js-canvas-el",
			settings: {
				advanced: {
					schedulerEnable: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.enable",
							label: "Enable Scheduler",
							description: 'Here you can choose whether it will show or hide on the scheduled date or time.',
							render: true,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/toggle",
							}
						}
					},
					schedulerShowHide: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.showHide",
							label: "Show or Hide",
							description: 'Here you can choose whether to show or hide it.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										show: { label: 'Show' },
										hide: { label: 'Hide' },
									}
								}
							}
						}
					},
					schedulerDateType: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.dateType",
							label: "Dates",
							description: 'Here you can choose whether to show or hide it.',
							render: true,
							visible: this.enableExtCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/select",
								props: {
									options: {
										from_date: { label: 'From Date' },
										between_dates: { label: 'Between Dates' },
									}
								}
							}
						}
					},
					fromDateTime: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.fromDateTime",
							label: "From Date and Time",
							description: 'Here you can choose From date and time.',
							render: true,
							visible: this.enableFromDateTimeCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/timepicker",
							}
						}
					},
					startDateTime: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.startDateTime",
							label: "Start Date and Time",
							description: 'Here you can choose start date and time.',
							render: true,
							visible: this.enableStartDateTimeCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/timepicker",
							}
						}
					},
					endDateTime: {
						groupType: "group-item",
						item: {
							groupSlug: "diplScheduler",
							attrName: "diplScheduler.advanced.endDateTime",
							label: "End Date and Time",
							description: 'Here you can choose end date and time.',
							render: true,
							visible: this.enableStartDateTimeCallback,
							features: { sticky: false, responsive: false, hover: false },
							component: {
								type: "field",
								name: "divi/timepicker",
							}
						}
					}
				}
			}
		};

		return attributes;
	}

	// Default attributes.
	defaultAttributes( defaultAttrs, config, metadata ) {
		// Check if enabled.
		const moduleName = metadata.name ?? '';
		if ( ! this.isModuleExtensionEnabled( moduleName ) ) {
			return defaultAttrs;
		}

		const newDefaultAttrs = {
			diplScheduler: {
				advanced: {
					enable: {
						desktop: { value: "off" }
					},
					showHide: {
						desktop: { value: "show" }
					},
					dateType: {
						desktop: { value: "from_date" }
					},
					fromDateTime: {
						desktop: { value: "" }
					},
					startDateTime: {
						desktop: { value: "" }
					},
					endDateTime: {
						desktop: { value: "" }
					}
				}
			}
		};

		// Return the modified default attributes.
		return {
			...defaultAttrs,
			...newDefaultAttrs,
		};
	}

	// Module conversation outline.
	conversionOutline( conversionOutline, moduleName ) {
		// If not conversation outline data.
		if ( ! moduleName || ! conversionOutline?.module ) {
			return conversionOutline;
		}

		// Add the attrs to conversion.
		conversionOutline.module.dipl_enable_scheduler         = 'diplScheduler.advanced.enable.*';
		conversionOutline.module.dipl_scheduler_show_hide      = 'diplScheduler.advanced.showHide.*';
		conversionOutline.module.dipl_scheduler_dates          = 'diplScheduler.advanced.dateType.*';
		conversionOutline.module.dipl_scheduler_from_datetime  = 'diplScheduler.advanced.fromDateTime.*';
		conversionOutline.module.dipl_scheduler_start_datetime = 'diplScheduler.advanced.startDateTime.*';
		conversionOutline.module.dipl_scheduler_end_datetime   = 'diplScheduler.advanced.endDateTime.*';

		// Return the modified conversion outline.
		return conversionOutline;
	}

	// Check if extension enabled or not.
	enableExtCallback( {
		attrs,
		attrName,
		responsiveMode,
		stateMode,
	} ) {
		return 'on' === ( attrs?.diplScheduler?.advanced?.enable?.desktop?.value || 'off' );
	}
	enableFromDateTimeCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplScheduler?.advanced?.enable?.desktop?.value || 'off' ) &&
			'from_date' === ( attrs?.diplScheduler?.advanced?.dateType?.desktop?.value || 'from_date' )
		);
	}
	enableStartDateTimeCallback( { attrs } ) {
		return (
			'on' === ( attrs?.diplScheduler?.advanced?.enable?.desktop?.value || 'off' ) &&
			'between_dates' === ( attrs?.diplScheduler?.advanced?.dateType?.desktop?.value || 'from_date' )
		);
	}

	// Check if extension enabled for the module.
	isModuleExtensionEnabled( moduleName ) {
		const { enable_areas, dipl_modules } = window?.DiplSchedulerExtData || {};

		// Check if enabled or not for section, row, column.
		if (
			( moduleName === 'divi/section' && ! enable_areas?.includes( 'sections' ) ) ||
			( moduleName === 'divi/row' && ! enable_areas?.includes( 'rows' ) ) ||
			( moduleName === 'divi/column' && ! enable_areas?.includes( 'columns' ) )
		) {
			return false;
		}

		// Check if enabled or not for modules.
		if (
			! [ 'divi/section', 'divi/row', 'divi/column' ].includes( moduleName ) &&
			( ! enable_areas?.includes( 'modules' ) || ! dipl_modules?.includes( moduleName ) )
		) {
			return false;
		}

		return true;
	}
}

new DiplSchedulerExtension();
