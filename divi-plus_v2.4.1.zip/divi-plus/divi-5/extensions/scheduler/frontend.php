<?php
/**
 * Particle Background Extension Class.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DiplSchedulerExtension {

	/**
	 * Alter frontend render.
	 */
	public static function render( $module_wrapper, $args, $enable_areas ) {
		$module_name     = $args['name'] ?? '';
		$module_attrs    = $args['attrs'] ?? '';
		$module_elements = $args['elements'] ?? '';

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $module_wrapper;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $module_wrapper;
		}

		// Check if extension enabled.
		$ext_attr         = $module_attrs['diplScheduler']['advanced'] ?? [];
		$enable_extension = $ext_attr['enable']['desktop']['value'] ?? 'off';

		// if not enabled.
		if ( 'on' !== $enable_extension ) {
			return $module_wrapper;
		}

		// Get other attrs.
		$show_hide      = $ext_attr['showHide']['desktop']['value'] ?? 'show';
		$date_type      = $ext_attr['dateType']['desktop']['value'] ?? 'from_date';
		$from_datetime  = $ext_attr['fromDateTime']['desktop']['value'] ?? '';
		$start_datetime = $ext_attr['startDateTime']['desktop']['value'] ?? '';
		$end_datetime   = $ext_attr['endDateTime']['desktop']['value'] ?? '';
		$current_date   = wp_date( 'Y-m-d H:i:s' );

		// If from date to hide/show.
		if ( 'from_date' === $date_type && ! empty( $from_datetime ) ) {
			if ( $current_date >= $from_datetime ) {
				if ( 'show' === $show_hide ) {
					return $module_wrapper;
				} else {
					return '';
				}
			} else {
				if ( 'show' === $show_hide ) {
					return '';
				} else {
					return $module_wrapper;
				}
			}
		}

		// If between dates to hide/show.
		if ( 'between_dates' === $date_type ) {
			if ( $current_date >= $start_datetime && $current_date <= $end_datetime ) {
				if ( 'show' === $show_hide ) {
					return $module_wrapper;
				} else {
					return '';
				}
			} else {
				if ( 'show' === $show_hide ) {
					return '';
				} else {
					return $module_wrapper;
				}
			}
		}

		return $module_wrapper;
	}

	/**
	 * Alter attributes.
	 */
	public static function attributes( $settings, $enable_areas ) {
		$module_name       = $settings['name'] ?? '';
		$module_attributes = $settings['attributes'] ?? false;

		if ( ! $module_attributes ) {
			return $settings;
		}

		// Get all modules list, where modules needs to be enabled.
		$dipl_modules = DiviPlusExtensions::dipl_get_modules();

		// Check if enabled or not, for section, tow and column.
		if (
			( 'divi/section' === $module_name && ! in_array( 'sections', $enable_areas ) ) ||
			( 'divi/row' === $module_name && ! in_array( 'rows', $enable_areas ) ) ||
			( 'divi/column' === $module_name && ! in_array( 'columns', $enable_areas ) )
		) {
			return $settings;
		}

		// Check if enabled or not, for modules.
		if ( ! in_array( $module_name, [ 'divi/section', 'divi/row', 'divi/column' ] ) &&
			( ! in_array( 'modules', $enable_areas ) || ! in_array( $module_name, $dipl_modules ) )
		) {
			return $settings;
		}

		$settings['attributes']['diplScheduler'] = [
			'type'     => 'object',
			'settings' => [
				'advanced' => [
					'schedulerEnable' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.enable',
							'label'       => 'Enable Scheduler',
							'description' => 'Here you can choose whether it will show or hide on the scheduled date or time.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => "field",
								'name' => "divi/toggle",
							]
						]
					],
					'schedulerShowHide' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.showHide',
							'label'       => 'Show or Hide',
							'description' => 'Here you can choose whether to show or hide it.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => 'field',
								'name'  => 'divi/select',
								'props' => [
									'options' => [
										'show' => [ 'label' => 'Show' ],
										'hide' => [ 'label' => 'Hide' ],
									]
								]
							]
						]
					],
					'schedulerDateType' => [
						'groupType' => "group-item",
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.dateType',
							'label'       => 'Dates',
							'description' => 'Here you can choose whether to show or hide it.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type'  => "field",
								'name'  => "divi/select",
								'props' => [
									'options' => [
										'from_date'     => [ 'label' => 'From Date' ],
										'between_dates' => [ 'label' => 'Between Dates' ],
									]
								]
							]
						]
					],
					'fromDateTime' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.fromDateTime',
							'label'       => 'From Date and Time',
							'description' => 'Here you can choose From date and time.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => "divi/timepicker",
							]
						]
					],
					'startDateTime' => [
						'groupType' => 'group-item₹',
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.startDateTime',
							'label'       => 'Start Date and Time',
							'description' => 'Here you can choose start date and time.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/timepicker',
							]
						]
					],
					'endDateTime' => [
						'groupType' => 'group-item',
						'item'      => [
							'groupSlug'   => 'diplScheduler',
							'attrName'    => 'diplScheduler.advanced.endDateTime',
							'label'       => 'End Date and Time',
							'description' => 'Here you can choose end date and time.',
							'render'      => true,
							'features'    => [ 'sticky' => false, 'responsive' => false, 'hover' => false ],
							'component'   => [
								'type' => 'field',
								'name' => 'divi/timepicker',
							]
						]
					]
				]
			]
		];

		return $settings;
	}

}
