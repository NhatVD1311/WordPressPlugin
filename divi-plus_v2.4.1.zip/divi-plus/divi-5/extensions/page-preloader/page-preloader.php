<?php
/**
 * Page Preloader Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Page_Preloader extends DiviPlusExtensions{
	public function __construct() {
		// Add cookie notice on footer.
		add_action( 'wp_body_open', array( __class__, 'enable_page_preloader' ), 5 );

		// Add cookie notice styles.
		add_action( 'wp_head', array( __class__, 'output_page_preloader_styles' ), 99 );
		add_action( 'wp_footer', array( __class__, 'output_page_preloader_script' ), 99 );
	}

	/**
	 * Load back to top.
	 */
	public static function enable_page_preloader() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-page-preloader-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		// Get attrs.
		$spinner = self::get_extension_option( 'dipl-page-preloader-spinner', 'circle_01' );

		// Spinner html.
		$spinner_html = '';
		if ( 'none' !== $spinner ) {
			$dots_inner = '';
			if ( 'dots_01' === $spinner ) {
				$dots_inner = '<span></span><span></span><span></span>';
			}
			// Spinner HTML.
			$spinner_html = sprintf(
				'<div class="dipl-page-preloader-spinner dipl-pp-%1$s">%2$s</div>',
				esc_attr( $spinner ),
				et_core_esc_previously( $dots_inner )
			);
		}

		// Logo.
		$logo_url = self::get_extension_option( 'dipl-page-preloader-logo-url', '' );
		$logo_img = '';
		if ( ! empty( $logo_url ) ) {
			$logo_img = sprintf(
				'<img src="%1$s" alt="%2$s" class="dipl-page-preloader-logo" draggable="false" />',
				esc_url_raw( $logo_url ),
				esc_html__( 'Page Loader...', 'divi-plus' )
			);
		}

		// Page Preloader.
		$page_preloader = sprintf(
			'<div id="dipl-page-preloader" aria-hidden="true" role="presentation">
				%1$s %2$s
			</div>',
			et_core_esc_previously( $logo_img ),
			et_core_esc_previously( $spinner_html )
		);

		echo et_core_intentionally_unescaped( $page_preloader, 'html' );
	}

	/**
	 * Output styles.
	 */
	public static function output_page_preloader_styles() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-page-preloader-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		$spinner       = self::get_extension_option( 'dipl-page-preloader-spinner', 'circle_01' );
		$spinner_color = self::get_extension_option( 'dipl-page-preloader-spinner-color', '#326bff' );
		$spinner_size  = max( 16, absint( self::get_extension_option( 'dipl-page-preloader-spinner-size', 48 ) ) );

		$page_bg       = self::get_extension_option( 'dipl-page-preloader-page-bg-color', '#ffffff' );
		$fade          = self::get_extension_option( 'dipl-page-preloader-fade-duration', '400' );
		$logo_url      = self::get_extension_option( 'dipl-page-preloader-logo-url', '' );
		$logo_width    = max( 20, absint( self::get_extension_option( 'dipl-page-preloader-logo-size', 120 ) ) );
		?>
		<style id="dipl-page-preloader-extension-css">
			#dipl-page-preloader {
				position: fixed;
				inset: 0;
				z-index: 9999999;
				background: <?php echo esc_attr( $page_bg ); ?>;
				display: flex;
				align-items: center;
				justify-content: center;
				flex-direction: column;
				gap: 22px;
				opacity: 1;
				visibility: visible;
				transition: opacity <?php echo absint( $fade ); ?>ms ease, visibility <?php echo absint( $fade ); ?>ms ease;
			}
			#dipl-page-preloader.dipl-pp-hidden {
				opacity: 0;
				visibility: hidden;
				pointer-events: none;
			}
			<?php
			if ( ! empty( $logo_url ) ) { ?>
				.dipl-page-preloader-logo{
					display: block;
					width: <?php echo intval( $logo_width ); ?>px;
					margin-top: calc(<?php echo '-' . intval( $logo_width ); ?>px/2);
					height: auto;
					max-width: 80vw;
				}
			<?php } ?>
		</style>
		<?php
		// Add/update to match your admin dropdown options exactly.
		$allowed_spinners = array(
			'bars_01', 'bars_02', 'circle_01', 'circle_02', 'dots_01', 'dots_02',
			'progress_01', 'progress_02', 'pulse_01', 'pulse_02'
		);
		if ( in_array( $spinner, $allowed_spinners, true ) ) {
			$spinner_file = ELICUS_DIVI_PLUS_DIR_PATH . "divi-5/extensions/page-preloader/styles/{$spinner}.php";
			if ( file_exists( $spinner_file ) ) {
				include_once $spinner_file;
			}
		}
	}

	/**
	 * Output script.
	 */
	public static function output_page_preloader_script() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-page-preloader-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		$hide_on  = self::get_extension_option( 'dipl-page-preloader-hide-on', 'load' );
		$delay_ms = max( 0, absint( self::get_extension_option( 'dipl-page-preloader-hide-on-delay', 2000 ) ) );
		$fade_ms  = max( 100, absint( self::get_extension_option( 'dipl-page-preloader-fade-duration', 400 ) ) );
		?>
		<script id="dipl-page-preloader-extension-js">
			( function() {
				var el = document.getElementById( 'dipl-page-preloader' );
				if ( ! el ) {
					return;
				}

				// Hide scrollbar while preloader is active
				document.documentElement.style.overflow = 'hidden';
				document.body.style.overflow = 'hidden';

				function hide() {
					// Restore scrolling.
					document.documentElement.style.overflow = '';
					document.body.style.overflow = '';

					el.classList.add( 'dipl-pp-hidden' );
					setTimeout( function() {
						if ( el && el.parentNode ) el.parentNode.removeChild( el );
					}, <?php echo (int) ( $fade_ms + 50 ); ?> );
				}

				<?php if ( 'delay' === $hide_on ) : ?>
					setTimeout( hide, <?php echo (int) $delay_ms; ?> );
				<?php else : ?>
				if ( document.readyState === 'complete' ) {
					hide();
				} else {
					window.addEventListener( 'load', hide, { once: true } );
					// Safety fallback — never block the user for more than 8 seconds.
					setTimeout( hide, 8000 );
				}
				<?php endif; ?>
			} )();
		</script>
		<?php
	}

}

new DIPL_Page_Preloader;
