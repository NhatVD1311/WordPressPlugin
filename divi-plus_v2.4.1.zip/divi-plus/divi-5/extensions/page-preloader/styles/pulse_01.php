<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-pulse_01{
		width: <?php echo absint( $spinner_size ); ?>px;
		height: <?php echo absint( $spinner_size ); ?>px;
		background: <?php echo esc_attr( $spinner_color ); ?>;
		border-radius: 50%;
		animation: dipl-pp-pulse_01 1.1s ease-in-out infinite;
		flex-shrink: 0;
	}
	@keyframes dipl-pp-pulse_01{
		0%, 100% { transform: scale(0.75); opacity: 0.55; }
		50% { transform: scale(1.1);  opacity: 1; }
	}
</style>
