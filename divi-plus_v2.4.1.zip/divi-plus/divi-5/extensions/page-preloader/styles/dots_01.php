<?php
/**
 * Dots spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-dots_01{
		display: flex;
		align-items: center;
		justify-content: center;
		width: <?php echo absint( $spinner_size ); ?>px;
		gap: 7px;
	}
	.dipl-page-preloader-spinner.dipl-pp-dots_01 span{
		display: block;
		width: 33%;
		aspect-ratio: 1;
		background: <?php echo esc_attr( $spinner_color ); ?>;
		border-radius: 50%;
		animation: dipl-pp-dots_01 1.2s ease-in-out infinite;
	}
	.dipl-page-preloader-spinner.dipl-pp-dots_01 span:nth-child(1) { animation-delay: -0.32s; }
	.dipl-page-preloader-spinner.dipl-pp-dots_01 span:nth-child(2) { animation-delay: -0.16s; }
	.dipl-page-preloader-spinner.dipl-pp-dots_01 span:nth-child(3) { animation-delay: 0s; }
	@keyframes dipl-pp-dots_01 {
		0%, 80%, 100% { transform: scale(0.4); opacity: 0.35; }
		40% { transform: scale(1);   opacity: 1; }
	}
</style>
