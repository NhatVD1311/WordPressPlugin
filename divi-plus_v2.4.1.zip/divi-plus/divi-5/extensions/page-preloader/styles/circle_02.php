<?php
/**
 * Circle 02 spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-circle_02{
		width: <?php echo intval( $spinner_size ); ?>px;
		aspect-ratio: 1;
		border-radius: 50%;
		border: 8px solid;
		border-color: <?php echo esc_attr( $spinner_color ); ?> #0000;
		animation: dipl-pp-circle_02 0.75s linear infinite;
	}
	@keyframes dipl-pp-circle_02{ to{ transform: rotate( .5turn ) } }
</style>
