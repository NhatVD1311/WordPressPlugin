<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-bars_01{
		width: <?php echo absint( $spinner_size ); ?>px;
		aspect-ratio: 1;
		--c: no-repeat linear-gradient(<?php echo esc_attr( $spinner_color ); ?> 0 0);
		background: 
			var(--c) 0%   50%,
			var(--c) 50%  50%,
			var(--c) 100% 50%;
		background-size: 20% 100%;
		animation: dipl-pp-bars_01 1s infinite linear;
	}
	@keyframes dipl-pp-bars_01 {
		0%  { background-size: 20% 100%,20% 100%,20% 100% }
		33% { background-size: 20% 10% ,20% 100%,20% 100% }
		50% { background-size: 20% 100%,20% 10% ,20% 100% }
		66% { background-size: 20% 100%,20% 100%,20% 10% }
		100%{ background-size: 20% 100%,20% 100%,20% 100% }
	}
</style>
