<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-pulse_02{
		position: relative;
		width: <?php echo intval( $spinner_size ); ?>px;
		aspect-ratio: 1;
		border-radius: 50%;
		margin: 10px;
		background: <?php echo esc_attr( $spinner_color ); ?>;
		box-shadow: 0 0 0 0 <?php echo esc_attr( $spinner_color ); ?>;
		animation: dipl-pp-pulse_02 1.5s infinite linear;
	}
	.dipl-page-preloader-spinner.dipl-pp-pulse_02:before,
	.dipl-page-preloader-spinner.dipl-pp-pulse_02:after {
		content: "";
		position: absolute;
		inset: 0;
		border-radius: inherit;
		box-shadow: 0 0 0 0 <?php echo esc_attr( $spinner_color ); ?>;
		animation: inherit;
		animation-delay: -0.5s;
	}
	.dipl-page-preloader-spinner.dipl-pp-pulse_02:after {
		animation-delay: -1s;
	}
	@keyframes dipl-pp-pulse_02{
		100% { box-shadow: 0 0 0 40px #0000 }
	}
</style>
