<?php
/**
 * Dots spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-dots_02{
		width: <?php echo absint( $spinner_size ); ?>px;
		color: <?php echo esc_attr( $spinner_color ); ?>;
		aspect-ratio: 1.154;
		--_g: no-repeat radial-gradient( farthest-side, <?php echo esc_attr( $spinner_color ); ?> 90%, #0000 );
		background: var(--_g) 50%  0, var(--_g) 0 100%, var(--_g) 100% 100%;
		background-size: 35% calc( 35% * 1.154 );
		animation: dipl-pp-dots_02 .8s infinite;
	}
	@keyframes dipl-pp-dots_02 {
		50%, 100% { background-position: 100% 100%,50% 0,0 100% } 
	}
</style>
