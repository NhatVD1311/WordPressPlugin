<?php
/**
 * Circle spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-circle_01{
		width: <?php echo absint( $spinner_size ); ?>px;
		height: <?php echo absint( $spinner_size ); ?>px;
		border: <?php echo absint( max( 2, absint( $spinner_size / 12 ) ) ); ?>px solid rgba(0,0,0,0.1);
		border-top-color: <?php echo esc_attr( $spinner_color ); ?>;
		border-radius: 50%;
		animation: dipl-pp-circle_01 0.75s linear infinite;
		flex-shrink: 0;
	}
	@keyframes dipl-pp-circle_01{
		to { transform: rotate( 360deg ); }
	}
</style>
