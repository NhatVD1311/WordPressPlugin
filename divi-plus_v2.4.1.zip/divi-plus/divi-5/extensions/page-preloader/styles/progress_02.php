<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-progress_02{
		width: <?php echo absint( $spinner_size ); ?>px;
		aspect-ratio: 1;
		background: linear-gradient(<?php echo esc_attr( $spinner_color ); ?> 0 0) bottom/100% 0% no-repeat #eee;
		-webkit-mask: 
			radial-gradient( circle at 60% 65%, #000 62%, #0000 65% ) top left, 
			radial-gradient( circle at 40% 65%, #000 62%, #0000 65% ) top right, 
			linear-gradient( to bottom left, #000 42%,#0000 43% ) bottom left , 
			linear-gradient( to bottom right,#000 42%,#0000 43% ) bottom right;
		-webkit-mask-size: 50% 50%;
		-webkit-mask-repeat: no-repeat;
		animation: dipl-pp-progress_02 2s infinite linear;
	}
	@keyframes dipl-pp-progress_02{
		90%,100% { background-size: 100% 100%; }
	}
</style>
