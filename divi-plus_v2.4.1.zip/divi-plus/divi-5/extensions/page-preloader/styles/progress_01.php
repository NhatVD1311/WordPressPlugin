<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$light_spinner_color = dipl_hex_to_lighten_color( $spinner_color );
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-progress_01{
		height: 5px;
		width: <?php echo absint( $spinner_size ); ?>px;
		--c: no-repeat linear-gradient( <?php echo esc_attr( $spinner_color ); ?> 0 0 );
		background: var(--c),var(--c), <?php echo esc_attr( $light_spinner_color ); ?>;
		background-size: 60% 100%;
		animation: dipl-pp-progress_01 3s infinite;
	}
	@keyframes dipl-pp-progress_01{
		0%   { background-position: -150% 0,-150% 0 }
		66%  { background-position: 250% 0,-150% 0 }
		100% { background-position: 250% 0, 250% 0 }
	}
</style>
