<?php
/**
 * Pulse spinner style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<style id="dipl-page-preloader-extension-spinner-css">
	.dipl-page-preloader-spinner.dipl-pp-bars_02{
		width: <?php echo absint( $spinner_size ); ?>px;
		aspect-ratio: 1;
		--c: no-repeat linear-gradient( <?php echo esc_attr( $spinner_color ); ?> 0 0 );
		background: var(--c), var(--c), var(--c);
		animation: 
			dipl-pp-bars_02_a 1s infinite,
			dipl-pp-bars_02_b 1s infinite;
	}
	@keyframes dipl-pp-bars_02_a {
		0%,100% { background-size: 20% 100%; }
		33%,66% { background-size: 20% 20%; }
	}
	@keyframes dipl-pp-bars_02_b {
		0%,33%   { background-position: 0 0, 50% 50%, 100% 100% }
		66%,100% { background-position: 100% 0, 50% 50%, 0 100% }
	}
</style>
