<?php
/**
 * Divi Floating Button Class.
 * 
 * @since  2.2.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Floating_Button extends DiviPlusExtensions{

	private static $icons = array(
		'plus'       => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
		'phone'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.6a16 16 0 0 0 6 6l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
		'email'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
		'whatsapp'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="currentColor" aria-hidden="true"><path d="M16 2.667C8.637 2.667 2.667 8.637 2.667 16c0 2.347.619 4.549 1.693 6.464L2.667 29.333l7.12-1.653A13.287 13.287 0 0 0 16 29.333C23.363 29.333 29.333 23.363 29.333 16S23.363 2.667 16 2.667zm0 2.4C21.875 5.067 26.933 10.125 26.933 16S21.875 26.933 16 26.933a10.9 10.9 0 0 1-5.467-1.467l-.387-.24-4.08.96.987-3.947-.267-.4A10.9 10.9 0 0 1 5.067 16C5.067 10.125 10.125 5.067 16 5.067zm-3.6 5.6c-.213 0-.56.08-.853.4-.293.32-1.12 1.093-1.12 2.667 0 1.573 1.147 3.093 1.307 3.307.16.213 2.24 3.52 5.493 4.8 2.72 1.08 3.253.853 3.84.8.587-.053 1.867-.773 2.133-1.52.267-.747.267-1.387.187-1.52-.08-.133-.293-.213-.613-.373-.32-.16-1.893-.933-2.187-1.04-.293-.107-.507-.16-.72.16-.213.32-.827 1.04-.987 1.253-.16.213-.32.24-.64.08-.32-.16-1.36-.48-2.587-1.547-.96-.827-1.6-1.853-1.787-2.173-.187-.32-.02-.48.14-.64.147-.147.32-.373.48-.56.16-.187.213-.32.32-.533.107-.213.053-.4-.027-.56-.08-.16-.72-1.76-.987-2.4-.267-.64-.533-.533-.72-.533z"/></svg>',
		'chat'       => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
		'link'       => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
		'scroll-top' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="18 15 12 9 6 15"/></svg>',
		'map'        => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
		'calendar'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
		'download'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
		'share'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
		'star'       => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
	);

	public function __construct() {
		// Add whatsapp button on footer.
		add_action( 'wp_footer', array( __class__, 'enable_floating_button' ), 100 );

		// Add whatsapp button styles.
		add_action( 'wp_head',   array( __class__, 'output_floating_button_styles' ), 99 );
	}

	private static function get_icon( $name ) {
		return isset( self::$icons[ $name ] ) ? self::$icons[ $name ] : self::$icons['link'];
	}

	/**
	 * Load WhatsApp Chat button.
	 */
	public static function enable_floating_button() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-floating-button-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// To skip builder side output.
		if ( et_core_is_fb_enabled() ) {
			return;
		}

		// attributes.
		$trigger               = self::get_extension_option( 'dipl-floating-button-open-trigger' );
		$floating_btn_position = self::get_extension_option( 'dipl-floating-button-position' );

		// Buttons.
		$buttons = self::get_extension_option( 'dipl-floating-button-action-buttons' );
		$buttons = wp_specialchars_decode( $buttons, ENT_COMPAT );
		$buttons = wp_unslash( $buttons );
		$buttons = json_decode( $buttons, true );

		// Get total buttons.
		$total_btns  = intval( $buttons['counter'] ?? '1' );

		// Loop buttons.
		$action_buttons = '';
		for ( $i = 1; $i <= $total_btns; $i++ ) {

			// Get attributes.
			$icon   = self::get_extension_option( 'action-btn-icon-' . intval( $i ) ) ?? 'link';
			$label  = self::get_extension_option( 'action-btn-label-' . intval( $i ) );
			$action = self::get_extension_option( 'action-btn-action-' . intval( $i ) ) ?? 'link';
			$url    = self::get_extension_option( 'action-btn-url-' . intval( $i ) );
			$target = self::get_extension_option( 'action-btn-link-target-' . intval( $i ) ) ?? '_blank';

			$icon_color         = self::get_extension_option( 'action-btn-icon-color-' . intval( $i ) );
			$icon_color_hover   = self::get_extension_option( 'action-btn-icon-color-' . intval( $i ) . '-hover' );
			$btn_bg_color       = self::get_extension_option( 'action-btn-bg-color-' . intval( $i ) );
			$btn_bg_color_hover = self::get_extension_option( 'action-btn-bg-color-' . intval( $i ) . '-hover' );

			$action_url = self::generate_action_url( $action, $url );

			$action_buttons .= sprintf(
				'<div class="dipl-floating-button-item" style="--index:%1$d;" data-action="%2$s">
					<a href="%3$s" aria-label="%4$s" class="dipl-floating-button-item-btn"%5$s
						style="--icon-color: %6$s; --icon-color-hover: %7$s;--button-color: %8$s; --button-color-hover: %9$s;"
					>%10$s</a>
					<span class="dipl-floating-button-item-label">%4$s</span>
				</div>',
				intval( $i ),
				esc_attr( $icon ),
				esc_url_raw( $action_url ),
				esc_html( $label ), // #4.
				( 'scroll-top' !== $action && '_self' !== $target ) ? 'target="_blank"' : '',
				esc_attr( $icon_color ),
				esc_attr( $icon_color_hover ),
				esc_attr( $btn_bg_color ), // #8.
				esc_attr( $btn_bg_color_hover ),
				self::get_icon( $icon )
			);
		}

		// If no action buttons.
		if ( empty( $action_buttons ) ) {
			return;
		}

		$floating_button = sprintf(
			'<div class="dipl-floating-button-ext dipl-position-%4$s" data-open-on="%1$s">
				<div class="dipl-floating-button-ext-inner">
					%2$s
				</div>
				<button class="dipl-floating-button-main" aria-label="%3$s" aria-expanded="false">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">
						<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
					</svg>
				</button>
			</div>',
			esc_attr( $trigger ),
			et_core_esc_previously( $action_buttons ),
			esc_attr__( 'Open actions', 'divi-plus' ),
			esc_attr( $floating_btn_position )
		);

		echo et_core_intentionally_unescaped( $floating_button, 'html' );
		self::render_script();
	}

	/**
	 * WhatsApp Chat styling.
	 */
	public static function output_floating_button_styles() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-floating-button-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// To skip builder side output.
		if ( et_core_is_fb_enabled() ) {
			return;
		}

		$floating_btn_bg_color       = self::get_extension_option( 'dipl-floating-button-btn-bg-color' );
		$floating_btn_bg_color_hover = self::get_extension_option( 'dipl-floating-button-btn-bg-color-hover' );

		$floating_btn_top            = self::get_extension_option( 'dipl-floating-button-offset__top' );
		$floating_btn_bottom         = self::get_extension_option( 'dipl-floating-button-offset__bottom' );
		$floating_btn_left           = self::get_extension_option( 'dipl-floating-button-offset__left' );
		$floating_btn_right          = self::get_extension_option( 'dipl-floating-button-offset__right' );

		$floating_btn_position       = self::get_extension_option( 'dipl-floating-button-position' );
		$floating_btn_size           = self::get_extension_option( 'dipl-floating-button-size' ) ?? '52';

		$hide_mobile                 = 'on' === self::get_extension_option( 'dipl-floating-button-hide-on-mobile' );
		$hide_desktop                = 'on' === self::get_extension_option( 'dipl-floating-button-hide-on-desktop' );

		$mobile_css                  = $hide_mobile  ? '@media(max-width:980px){.dipl-floating-button-ext{display:none!important;}}' : '';
		$desktop_css                 = $hide_desktop ? '@media(min-width:981px){.dipl-floating-button-ext{display:none!important;}}' : '';
		?>
		<style id="dipl-floating-button-extension-css">
			.dipl-floating-button-main{
				display: flex;
				align-items: center;
				justify-content: center;
				padding: 12px;
				border-radius: 50%;
				box-shadow: 0 4px 14px rgba(0, 0, 0, .22);
				cursor: pointer;
				border: none;
				outline: none;
				color: #ffffff;
				transition: transform .25s ease, box-shadow .25s ease;
				flex-shrink: 0;
				width: <?php echo absint( $floating_btn_size ); ?>px;
				height: <?php echo absint( $floating_btn_size ); ?>px;
				background: <?php echo esc_attr( $floating_btn_bg_color ); ?>;
			}
			.dipl-floating-button-main:hover{
				transform: scale(1.07);
				box-shadow: 0 6px 20px rgba(0, 0, 0, .3);
				<?php echo ! empty( $floating_btn_bg_color_hover ) ? 'background: ' . esc_attr( $floating_btn_bg_color_hover ) . ';' : ''; ?>
			}
			.dipl-floating-button-ext svg{
				transition: transform .3s ease;
				flex-shrink: 0;
			}
			.dipl-floating-button-ext.dipl-fab-open .dipl-floating-button-main svg{
				transform: rotate(45deg);
			}
			.dipl-floating-button-ext{
				position: fixed;
				display: flex;
				flex-direction: column;
				align-items: center;
				gap: 15px;
				left: auto;
				z-index: 99997;
				bottom: 0;
				<?php echo ( 'bottom-right' === $floating_btn_position ) ? 'right: 0;' : 'left: 0;'; ?>
				<?php echo ! empty( $floating_btn_top ) ? 'margin-top: ' . intval( $floating_btn_top ) . 'px;' : ''; ?>
				<?php echo ! empty( $floating_btn_bottom ) ? 'margin-bottom: ' . intval( $floating_btn_bottom ) . 'px;' : ''; ?>
				<?php echo ! empty( $floating_btn_left ) ? 'margin-left: ' . intval( $floating_btn_left ) . 'px;' : ''; ?>
				<?php echo ! empty( $floating_btn_right ) ? 'margin-right: ' . intval( $floating_btn_right ) . 'px;' : ''; ?>
			}
			.dipl-floating-button-ext-inner{
				display: flex;
				flex-direction: column-reverse;
				align-items: flex-end;
				gap: 10px;
			}
			.dipl-floating-button-item{
				position: relative;
				display: flex;
				align-items: center;
				opacity: 0;
				visibility: hidden;
				transform: scale(.4) translateY(8px);
				pointer-events: none;
				transition: opacity .22s ease, transform .22s cubic-bezier(.34, 1.56, .64, 1);
			}
			.dipl-floating-button-ext.dipl-fab-open .dipl-floating-button-item{
				opacity: 1;
				visibility: visible;
				transform: scale(1) translateY(0);
				pointer-events: auto;
				transition-delay: calc(var(--index) * 0.05s);
			}
			.dipl-floating-button-item-btn{
				display: flex;
				align-items: center;
				justify-content: center;
				width: 40px;
				height: 40px;
				border-radius: 50%;
				box-shadow: 0 3px 10px rgba(0, 0, 0, .2);
				text-decoration: none;
				transition: transform .2s ease, box-shadow .2s ease;
				flex-shrink: 0;
				background: var( --button-color );
				color: var( --icon-color );
			}
			.dipl-floating-button-item-btn:hover{
				background: var( --button-color-hover );
				color: var( --icon-color-hover );
			}
			.dipl-floating-button-item-btn svg{
				width: 18px;
				height: 18px;
				flex-shrink: 0;
			}
			.dipl-floating-button-item-label{
				position: absolute;
				top: 50%;
				transform: translateY(-50%);
				right: calc(100% + 10px);
				left: auto;
				white-space: nowrap;
				background: rgba(0, 0, 0, .72);
				color: #ffffff;
				font-size: 12px;
				font-weight: 500;
				line-height: 1;
				padding: 5px 9px;
				border-radius: 4px;
				pointer-events: none;
				opacity: 0;
				visibility: hidden;
				transition: opacity .15s ease-in-out;
			}
			.dipl-position-bottom-right .dipl-floating-button-item-label{
				right: calc(100% + 10px);
				left: auto;
			}
			.dipl-position-bottom-left .dipl-floating-button-item-label{
				left: calc(100% + 10px);
				right: auto;
			}
			.dipl-floating-button-item-btn:hover ~ .dipl-floating-button-item-label{
				opacity: 1;
				visibility: visible;
			}
			<?php echo esc_html( $mobile_css . $desktop_css ); ?>
		</style>
		<?php
	}

	public static function render_script() {
		?>
		<script>
			jQuery( document ).ready( function() {
				var wrap = document.querySelector( '.dipl-floating-button-ext' );
				var main = wrap ? wrap.querySelector( '.dipl-floating-button-main' ) : null;
				if ( ! wrap || ! main ) { return; }

				var openOn = wrap.getAttribute( 'data-open-on' );
				function open()  {
					wrap.classList.add( 'dipl-fab-open' );
					main.setAttribute( 'aria-expanded', 'true' );
				}
				function close() {
					wrap.classList.remove( 'dipl-fab-open' );
					main.setAttribute( 'aria-expanded', 'false' );
				}
				function toggle() {
					wrap.classList.contains( 'dipl-fab-open' ) ? close() : open();
				}

				if ( 'hover' === openOn ) {
					main.addEventListener( 'mouseenter', open );
					wrap.addEventListener( 'mouseleave', close );
				} else {
					main.addEventListener( 'click', function( e ) {
						e.stopPropagation();
						toggle();
					} );
					document.addEventListener( 'click', function( e ) {
						if ( ! wrap.contains( e.target ) ) { close(); }
					} );
				}

				// Scroll-to-top action buttons.
				wrap.querySelectorAll( '[href="#scrollTop"]' ).forEach( function( btn ) {
					btn.addEventListener( 'click', function( e ) {
						e.preventDefault();
						window.scrollTo( { top: 0, behavior: 'smooth' } );
						close();
					} );
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Generate action button url.
	 *
	 * @param string $type type or action.
	 * @param string/integer $value value of action url.
	 * 
	 * @return string generated url.
	 */
	public static function generate_action_url( $type, $value ) {
		switch ( $type ) {
			case 'tel':
				$num = preg_replace( '/[^0-9+]/', '', $value );
				return $num ? 'tel:' . $num : '#';
			case 'mailto':
				$email = sanitize_email( $value );
				return $email ? 'mailto:' . $email : '#';
			case 'whatsapp':
				$num = preg_replace( '/[^0-9]/', '', $value );
				return $num ? 'https://wa.me/' . $num : '#';
			case 'scroll-top':
				return '#scrollTop';
			default: // url
				return $value ? esc_url_raw( $value ) : '#';
		}
	}
}

new DIPL_Floating_Button;
