<?php
/**
 * Divi Cookie Notice Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Cookie_Notice extends DiviPlusExtensions{
	public function __construct() {
		// Add cookie notice on footer.
		add_action( 'wp_footer', array( $this, 'enable_cookie_notice' ) );

		// Add cookie notice styles.
		add_action( 'wp_head',   array( __class__, 'output_cookie_notice_styles' ), 99 );
	}

	/**
	 * Load Cookie Notice.
	 */
	public static function enable_cookie_notice() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-cookie-notice-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// Already consented — skip output entirely (server-side check).
		if ( isset( $_COOKIE['dipl_cookie_consent'] ) && '1' === $_COOKIE['dipl_cookie_consent'] ) {
			return;
		}

		// Get attrinutes.
		$title   = self::get_extension_option( 'dipl-cookie-notice-title' );
		$message = self::get_extension_option( 'dipl-cookie-notice-message' );

		// Wrap title.
		if ( ! empty( $title ) ) {
			$title = sprintf( '<h3 class="dipl-cookie-notice-title">%1$s</h3>', esc_html( $title ) );
		}
		// Wrap message.
		if ( ! empty( $message ) ) {
			$message = sprintf(
				'<p class="dipl-cookie-notice-message">%1$s</p>',
				wp_kses( $message, array(
					'a'      => array( 'href' => [], 'target' => [], 'rel' => [] ),
					'strong' => [],
					'em'     => [],
					'br'     => [],
				) )
			);
		}

		// Learn more link.
		$learn_link_text   = self::get_extension_option( 'dipl-cookie-notice-learn-link-text' );
		$learn_link_url    = self::get_extension_option( 'dipl-cookie-notice-learn-link-url' );
		$learn_link_target = self::get_extension_option( 'dipl-cookie-notice-learn-link-target' );
		$learn_link        = '';
		if ( ! empty( $learn_link_text ) && ! empty( $learn_link_url ) ) {
			$learn_link = sprintf(
				'<a href="%1$s" target="%2$s" class="dipl-cookie-notice-learn-more" rel="noopener noreferrer">%3$s</a>',
				esc_url( $learn_link_url ),
				esc_attr( $learn_link_target ),
				esc_html( $learn_link_text )
			);
		}

		// Accept button.
		$accept_btn_text = self::get_extension_option( 'dipl-cookie-notice-accept-btn-text', esc_html__( 'Accept', 'divi-plus' ) );
		$accept_btn      = sprintf(
			'<button id="dipl-cookie-notice-accept-btn" type="button">%1$s</button>',
			esc_html( $accept_btn_text )
		);

		// Cookie notice.
		$cookie_notice = sprintf(
			'<div id="dipl-cookie-notice-wrap" role="dialog" aria-live="polite" aria-label="%1$s">
				<div class="dipl-cookie-notice-inner">
					<div class="dipl-cookie-notice-content-wrap">
						%2$s %3$s
					</div>
					<div class="dipl-cookie-notice-actions">
						%4$s %5$s
					</div>
				</div>
			</div>',
			esc_attr__( 'Cookie Notice', 'divi-plus' ),
			et_core_esc_previously( $title ),
			et_core_esc_previously( $message ),
			et_core_esc_previously( $learn_link ),
			et_core_esc_previously( $accept_btn )
		);

		echo et_core_intentionally_unescaped( $cookie_notice, 'html' );
		self::render_script();
	}

	/**
	 * Cookie notice styling.
	 */
	public static function output_cookie_notice_styles() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-cookie-notice-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}
		// Already consented — skip output entirely (server-side check).
		if ( isset( $_COOKIE['dipl_cookie_consent'] ) && '1' === $_COOKIE['dipl_cookie_consent'] ) {
			return;
		}

		// Get attributes.
		$position      = self::get_extension_option( 'dipl-cookie-notice-position', 'bottom' );
		$bg_color      = self::get_extension_option( 'dipl-cookie-notice-bg-color', '#1a1a1a' );
		$title_color   = self::get_extension_option( 'dipl-cookie-notice-title-color', '#ffffff' );
		$text_color    = self::get_extension_option( 'dipl-cookie-notice-message-color', '#f7f7f7' );

		$btn_bg_color  = self::get_extension_option( 'dipl-cookie-notice-accept-btn-bg-color', '#326bff' );
		$btn_txt_color = self::get_extension_option( 'dipl-cookie-notice-accept-btn-text-color', '#ffffff' );
		$learn_color   = self::get_extension_option( 'dipl-cookie-notice-learn-link-color', '#f2f2f2' );

		// Get content width;
		$content_width = 1400;
		if ( function_exists( 'et_get_option' ) ) {
			et_get_option( 'content_width', '1400' );
		}

		$translate_hidden = ( 'top' === $position ) ? 'translateY(-110%)' : 'translateY(110%)';

		// Wrap style.
		$wrap_style  = '';
		$wrap_style .= ( 'top' === $position ) ? 'top:0;' : 'bottom:0;';
		$wrap_style .= sprintf( 'background-color: %1$s;', esc_attr( $bg_color ) );
		$wrap_style .= sprintf( 'color: %1$s;', esc_attr( $text_color ) );
		$wrap_style .= sprintf(
			'box-shadow: %1$s;',
			( 'top' === $position ) ? '0 2px 14px rgba(0,0,0,0.18)' : '0 -2px 14px rgba(0,0,0,0.18)'
		);
		$wrap_style .= sprintf( 'transform: %1$s;', esc_attr( $translate_hidden ) );

		?>
		<style id="dipl-cookie-notice-extension-css">
			#dipl-cookie-notice-wrap{
				position: fixed;
				left: 0;
				right: 0;
				font-size: 13px;
				line-height: 1.5;
				padding: 15px 0;
				z-index: 999999;
				transition: transform 0.4s cubic-bezier(0.22, 1, 0.36, 1);
				<?php echo esc_attr( $wrap_style ); ?>
			}
			#dipl-cookie-notice-wrap.dipl-cn-visible {
				transform: translateY(0);
			}
			#dipl-cookie-notice-wrap.dipl-cn-hiding {
				transform: <?php echo esc_attr( $translate_hidden ); ?>;
			}
			.dipl-cookie-notice-inner{
				width: 80%; /* .container style from the divi. */
				max-width: <?php echo absint( $content_width ); ?>px;
				margin: 0 auto;
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 20px;
				flex-wrap: wrap;
			}
			.dipl-cookie-notice-title{
				font-size: 1rem;
				padding: 0;
				margin: 0 0 5px 0;
				color: <?php echo esc_attr( $title_color ); ?>
			}
			.dipl-cookie-notice-message{
				margin: 0;
				flex: 1;
				min-width: 200px;
				opacity: 0.9;
			}
			.dipl-cookie-notice-actions{
				display: flex;
				align-items: center;
				gap: 16px;
				flex-shrink: 0;
			}
			.dipl-cookie-notice-learn-more{
				color: <?php echo esc_attr( $learn_color ); ?> !important;
				font-size: 13px;
				opacity: 0.7;
				text-decoration: underline !important;
				white-space: nowrap;
			}
			.dipl-cookie-notice-learn-more:hover{
				opacity: 1;
			}
			#dipl-cookie-notice-accept-btn{
				background: <?php echo esc_attr( $btn_bg_color ); ?>;
				color: <?php echo esc_attr( $btn_txt_color ); ?>;
				border: none;
				border-radius: 3px;
				padding: 8px 22px;
				font-size: 13px;
				font-weight: 600;
				cursor: pointer;
				font-family: inherit;
				white-space: nowrap;
				line-height: 1.4;
				transition: opacity 0.2s;
			}
			#dipl-cookie-notice-accept-btn:hover{
				opacity: 0.9;
			}
			@media (max-width: 600px) {
				.dipl-cookie-notice-inner{
					flex-direction: column;
					align-items: flex-start;
					gap: 12px;
				}
				.dipl-cookie-notice-actions{ width: 100%; }
			}
		</style>
		<?php
	}

	public static function render_script() {
		// Get attrinutes.
		$expiry = max( 1, absint( self::get_extension_option( 'dipl-cookie-notice-expiry-days', 365 ) ) );
		?>
		<script>
			( function() {
				var banner = document.getElementById( 'dipl-cookie-notice-wrap' );
				if ( ! banner ) {
					return
				};
				function getCookie(name) {
					var ca = document.cookie.split(";");
					for (var i = 0; i < ca.length; i++) {
						var c = ca[i].trim();
						if (c.indexOf(name + "=") === 0) return c.substring(name.length + 1);
					}
					return '';
				}
				if ( getCookie('dipl_cookie_consent') === '1' ) {
					return;
				}
				// Animate in after two rAF ticks so the initial transform is painted first.
				requestAnimationFrame( function() {
					requestAnimationFrame( function() {
						banner.classList.add( 'dipl-cn-visible' );
					} );
				} );
				document.getElementById( 'dipl-cookie-notice-accept-btn' ).addEventListener( 'click', function() {
					var expires = new Date();
					expires.setTime( expires.getTime() + (<?php echo (int) $expiry; ?> * 86400000) );
					document.cookie = "dipl_cookie_consent=1;expires=" + expires.toUTCString()
						+ ";path=/;SameSite=Lax";

					banner.classList.remove( 'dipl-cn-visible' );
					banner.classList.add( 'dipl-cn-hiding' );
					setTimeout( function() { banner.style.display = 'none'; }, 420 );
				} );
			} )();
		</script>
	<?php
	}
}

new DIPL_Cookie_Notice;
