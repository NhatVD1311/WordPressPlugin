<?php
/**
 * Back To Top Class.
 * 
 * @since  2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DIPL_Back_To_Top extends DiviPlusExtensions{
	public function __construct() {
		// Add cookie notice on footer.
		add_action( 'wp_footer', array( __class__, 'enable_back_to_top' ) );

		// Add cookie notice styles.
		add_action( 'wp_head', array( __class__, 'output_back_to_top_styles' ), 99 );
	}

	/**
	 * Load back to top.
	 */
	public static function enable_back_to_top() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-back-to-top-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		// Chevron-up SVG — works without any font dependency.
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="18 15 12 9 6 15"></polyline></svg>';

		// Get the label.
		$label_text   = self::get_extension_option( 'dipl-back-to-top-label' );
		$button_label = '';
		if ( ! empty( $label_text ) ) {
			$button_label = sprintf( '<span class="dipl-btt-label">%1$s</span>', esc_html( $label_text ) );
		}
		
		// Back to top button.
		$back_to_top = sprintf(
			'<button id="dipl-back-to-top-btn" aria-label="%1$s">%2$s %3$s</button>',
			esc_attr__( 'Back to top', 'divi-plus' ),
			et_core_esc_previously( $svg ),
			et_core_esc_previously( $button_label )
		);

		echo et_core_intentionally_unescaped( $back_to_top, 'html' );
		self::render_script();
	}

	/**
	 * Cookie notice styling.
	 */
	public static function output_back_to_top_styles() {
		// Check is enabled.
		$is_enable = self::get_extension_option( 'dipl-back-to-top-enable' );
		if ( 'on' !== $is_enable ) {
			return;
		}

		// Get attrinutes.
		$label_text          = self::get_extension_option( 'dipl-back-to-top-label' );
		$position            = self::get_extension_option( 'dipl-back-to-top-position', 'bottom-right' );
		$animation           = self::get_extension_option( 'dipl-back-to-top-animation', 'fade' );
		$offset_top          = self::get_extension_option( 'dipl-back-to-top-btn-offset__top' );
		$offset_bottom       = self::get_extension_option( 'dipl-back-to-top-btn-offset__bottom' );
		$offset_left         = self::get_extension_option( 'dipl-back-to-top-btn-offset__left' );
		$offset_right        = self::get_extension_option( 'dipl-back-to-top-btn-offset__right' );
		$button_size         = self::get_extension_option( 'dipl-back-to-top-btn-size', 45 );
		$border_size         = self::get_extension_option( 'dipl-back-to-top-btn-border-size' );
		$border_color        = self::get_extension_option( 'dipl-back-to-top-btn-border-color' );
		$border_radius       = self::get_extension_option( 'dipl-back-to-top-btn-border-radius' );
		$btn_bg_color        = self::get_extension_option( 'dipl-back-to-top-btn-bg-color' );
		$btn_bg_color_hover  = self::get_extension_option( 'dipl-back-to-top-btn-bg-color-hover' );
		$btn_txt_color       = self::get_extension_option( 'dipl-back-to-top-btn-text-color' );
		$btn_txt_color_hover = self::get_extension_option( 'dipl-back-to-top-btn-text-color-hover' );
		$show_mobile         = self::get_extension_option( 'dipl-back-to-top-show-on-mobile', 'on' );

		$button_style = '';

		// Button Position.
		if ( 'bottom-left' === $position ) {
			$button_style .= 'left: 0; right: auto;';
		} else if ( 'bottom-center' === $position ) {
			$button_style .= 'left:50%; right: auto;';
		} else {
			$button_style .= 'left: auto; right: 0;';
		}

		// Width: text style grows with content; others are fixed square.
		$button_style .= ! empty( $label_text ) ? 'width: auto;' : "width: {$button_size}px;";
		$button_style .= "height: {$button_size}px;";
		$button_style .= ! empty( $label_text ) ? 'padding: 0 20px;' : "padding: 0;";

		// Button offset.
		$button_style .= ! empty( $offset_top ) ? "margin-top: {$offset_top}px;" : '';
		$button_style .= ! empty( $offset_bottom ) ? "margin-bottom: {$offset_bottom}px;" : '';
		$button_style .= ! empty( $offset_left ) ? "margin-left: {$offset_left}px;" : '';
		$button_style .= ! empty( $offset_right ) ? "margin-right: {$offset_right}px;" : '';

		// Button Border.
		$button_style .= ( ! empty( $border_size ) || 0 === intval( $border_size ) ) ? "border-width: {$border_size}px;" : '';
		$button_style .= ! empty( $border_color ) ? "border-color: {$border_color};" : '';
		$button_style .= ! empty( $border_radius ) ? "border-radius: {$border_radius}px;" : '';

		// Background and text color.
		$button_style .= ! empty( $btn_bg_color ) ? "background: {$btn_bg_color};" : '';
		$button_style .= ! empty( $btn_txt_color ) ? "color: {$btn_txt_color};" : '';

		// Button animation style.
		$transform_hidden  = '';
		$transform_visible = '';
		if ( 'slide-top' === $animation ) {
			$transform_hidden  = 'translateY(100%)';
			$transform_visible = 'translateY(0)';
		} elseif ( 'slide-bottom' === $animation ) {
			$transform_hidden  = 'translateY(-100%)';
			$transform_visible = 'translateY(0)';
		} elseif ( 'slide-left' === $animation ) {
			$transform_hidden  = 'translateX(100%)';
			$transform_visible = 'translateX(0)';
		} elseif ( 'slide-right' === $animation ) {
			$transform_hidden  = 'translateX(-100%)';
			$transform_visible = 'translateX(0)';
		} elseif ( 'zoom' === $animation ) {
			$transform_hidden  = 'scale(0.3)';
			$transform_visible = 'scale(1)';
		}

		// Add animation to button style.
		$button_style .= sprintf(
			'transform: %1$s%2$s',
			( 'bottom-center' === $position ) ? 'translateX(-50%) ' : '',
			esc_attr( $transform_hidden )
		);

		// Transform visible style.
		$transform_visible = ( ( 'bottom-center' === $position ) ? 'translateX(-50%) ' : '' ) . $transform_visible;

		// Icon SVG size (60% of button size, min 14px).
		$icon_size = max( 14, round( absint( $button_size ) * 0.42 ) );

		// Mobile CSS.
		$mobile_css = ( 'on' !== $show_mobile )
			? '@media (max-width:980px){ #dipl-back-to-top-btn{ display: none! important; } }'
		: '';
		?>
		<style id="dipl-back-to-top-extension-css">
			/* Hide native Divi Back to Top button. */
			.et_pb_scroll_top{ display: none !important; }
			#dipl-back-to-top-btn{
				position: fixed;
				gap: 6px;
				bottom: 0;
				outline: none;
				cursor: pointer;
				z-index: 999999;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				text-decoration: none;
				font-family: inherit;
				font-size: 14px;
				box-sizing: border-box;
				pointer-events: none;
				opacity: 0;
				visibility: hidden;
				transition: background-color .3s ease, color .3s ease, opacity .4s ease, visibility .4s ease, transform .4s ease;
				<?php
				// button dynamic styling.
				echo et_core_esc_previously( $button_style ); ?>
			}
			#dipl-back-to-top-btn:hover{
				<?php echo ! empty( $btn_bg_color_hover ) ? 'background: ' . esc_attr( $btn_bg_color_hover ) . ';' : ''; ?>
				<?php echo ! empty( $btn_txt_color_hover ) ? 'color: ' . esc_attr( $btn_txt_color_hover ) . ';' : ''; ?>
			}
			#dipl-back-to-top-btn.dipl-btt-visible{
				opacity: 1;
				visibility: visible;
				pointer-events: auto;
				transform: <?php echo esc_attr( $transform_visible ); ?>;
			}
			#dipl-back-to-top-btn:hover{
				background-color: '';
				color: '';
			}
			#dipl-back-to-top-btn svg{
				width: <?php echo absint( $icon_size ); ?>px;
				height: <?php echo absint( $icon_size ); ?>px;
				flex-shrink: 0;
			}
			<?php echo et_core_esc_previously( $mobile_css ); ?>
		</style>
	<?php
	}

	public static function render_script() {
		$threshold = self::get_extension_option( 'dipl-back-to-top-scroll-threshold', 300 );
		$duration  = self::get_extension_option( 'dipl-back-to-top-scroll-duration', 500 );
		?>
		<script>
			( function() {
				var btn       = document.getElementById( 'dipl-back-to-top-btn' );
				var threshold = <?php echo absint( max( 1, absint( $threshold ) ) ); ?>;
				var duration  = <?php echo absint( max( 1, absint( $duration ) ) ); ?>;

				if ( ! btn ) { return; }

				// Show / hide on scroll.
				window.addEventListener( 'scroll', function() {
					if ( window.pageYOffset > threshold ) {
						btn.classList.add( 'dipl-btt-visible' );
					} else {
						btn.classList.remove( 'dipl-btt-visible' );
					}
				}, { passive: true } );

				// Smooth scroll to top using requestAnimationFrame.
				btn.addEventListener( 'click', function() {
					var start     = window.pageYOffset;
					var startTime = null;
					function easeInOutQuad( t ) {
						return t < 0.5 ? 2 * t * t : -1 + ( 4 - 2 * t ) * t;
					}
					function step( currentTime ) {
						if ( ! startTime ) { startTime = currentTime; }
						var elapsed  = currentTime - startTime;
						var progress = Math.min( elapsed / duration, 1 );
						window.scrollTo( 0, Math.round( start * ( 1 - easeInOutQuad( progress ) ) ) );
						if ( progress < 1 ) {
							requestAnimationFrame( step );
						}
					}
					requestAnimationFrame( step );
				} );
			} )();
		</script>
	<?php
	}
}

new DIPL_Back_To_Top;
