<?php
/**
 * The file that handles the module conversion,
 * when divi migration run to convert modules,
 * from divi 4 to divi 5.
 *
 * @link       https://elicus.com
 * @since      1.0.0
 *
 * @package    DiviRestroMenu
 * @subpackage DiviRestroMenu/divi-5
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || die( 'No script kiddies please!' );

if ( ! class_exists( 'Dipl_Module_Conversion' ) ) {
	class Dipl_Module_Conversion {
		
		/**
		 * AIOC_Module_Conversion constructor.
		 */
		public function __construct() {
			add_filter( 'divi.moduleLibrary.conversion.valueExpansionFunctionMap', array( __class__, 'dipl_map_conversion_functions' ) );
		}

		/**
		 * Manage/map custom conversion functions.
		 */
		static function dipl_map_conversion_functions( $valueExpansionFunctionMapping ) {

			$valueExpansionFunctionMapping['diplConvertCategories']               = array( __class__, 'diplConvertCategories' );
			$valueExpansionFunctionMapping['diplConvertFacebookPageTab']          = array( __class__, 'diplConvertFacebookPageTab' );
			$valueExpansionFunctionMapping['diplConvertBorderRtoRadii']           = array( __class__, 'diplConvertBorderRtoRadii' );
			$valueExpansionFunctionMapping['diplConvertXChromeValues']            = array( __class__, 'diplConvertXChromeValues' );
			$valueExpansionFunctionMapping['diplConvertBackgroundStops']          = array( __class__, 'diplConvertBackgroundStops' );
			$valueExpansionFunctionMapping['diplConvertBackgroundPosition']       = array( __class__, 'diplConvertBackgroundPosition' );
			$valueExpansionFunctionMapping['diplConvertLegacyGradientProperty']   = array( __class__, 'diplConvertLegacyGradientProperty' );
			$valueExpansionFunctionMapping['diplAjaxSearchConvertSearchInFields'] = array( __class__, 'diplAjaxSearchConvertSearchInFields' );
			$valueExpansionFunctionMapping['diplAjaxSearchConvertDisplayFields']  = array( __class__, 'diplAjaxSearchConvertDisplayFields' );
			$valueExpansionFunctionMapping['diplImageAccConvertInactiveDisplay']  = array( __class__, 'diplImageAccConvertInactiveDisplay' );
			$valueExpansionFunctionMapping['diplHowtoSchemaConvertStepItem']      = array( __class__, 'diplHowtoSchemaConvertStepItem' );
			$valueExpansionFunctionMapping['diplWooProdAccConvertInactiveState']  = array( __class__, 'diplWooProdAccConvertInactiveState' );
			$valueExpansionFunctionMapping['diplConvertBorderRadii']              = array( __class__, 'diplConvertBorderRadii' );
			$valueExpansionFunctionMapping['diplConvertModalAnimDirection']       = array( __class__, 'diplConvertModalAnimDirection' );
			
			// Extension conversation.
			$valueExpansionFunctionMapping['diplConvertParticleBgDisabledOn']     = array( __class__, 'diplConvertParticleBgDisabledOn' );
			$valueExpansionFunctionMapping['diplConvertFont']    				  = array( __class__, 'diplConvertFont' );
			$valueExpansionFunctionMapping['diplConvertManualGradientType']    	  = array( __class__, 'diplConvertManualGradientType' );
			$valueExpansionFunctionMapping['diplConvertManualRadialGradient']     = array( __class__, 'diplConvertManualRadialGradient' );

			// Team Grid.
			$valueExpansionFunctionMapping['diplTeamGridConvertDisplayInPopup']   = array( __class__, 'diplTeamGridConvertDisplayInPopup' );

			return $valueExpansionFunctionMapping;
		}

		static function diplConvertManualGradientType( $value ) {
			$map = [
		        'linear-gradient' => 'linear',
		        'radial-gradient' => 'circular',
		    ];

		    return $map[ $value ] ?? $value;
		}

		static function diplConvertManualRadialGradient( $value ) {
			$map = [
		        'circle at center'       => 'center',
		        'circle at top left'     => 'top left',
		        'circle at top'          => 'top',
		        'circle at top right'    => 'top right',
		        'circle at bottom right' => 'bottom right',
		        'circle at bottom'       => 'bottom',
		        'circle at bottom left'  => 'bottom left',
		        'circle at left'         => 'left',
		    ];

		    return $map[ $value ] ?? $value;
		}

		/**
		 * Convert module font value.
		 */
		static function diplConvertFont($value) {
			// When D4 value is 8 empty pipes, return early with an empty style array.
	        // This is necessary to override preset styles or larger breakpoint styles.
			if ( '||||||||' === $value ) {
				return [
					'style' => [],
				];
			}

	        $valueArray = explode('|', $value);

	        $fontStyle = [];
	        if (isset($valueArray[2]) && strpos($valueArray[2], 'on') === 0) {
	            $fontStyle[] = 'italic';
	        }
	        if (isset($valueArray[3]) && strpos($valueArray[3], 'on') === 0) {
	            $fontStyle[] = 'uppercase';
	        }
	        if (isset($valueArray[4]) && strpos($valueArray[4], 'on') === 0) {
	            $fontStyle[] = 'underline';
	        }
	        if (isset($valueArray[5]) && strpos($valueArray[5], 'on') === 0) {
	            $fontStyle[] = 'capitalize';
	        }
	        if (isset($valueArray[6]) && strpos($valueArray[6], 'on') === 0) {
	            $fontStyle[] = 'strikethrough';
	        }

	        $font = [];

	        $fontFamily = isset($valueArray[0]) ? $valueArray[0] : '';
	        $fontWeight = isset($valueArray[1]) ? $valueArray[1] : '';
	        $fontLineColor = isset($valueArray[7]) ? $valueArray[7] : '';
	        $fontLineStyle = isset($valueArray[8]) ? $valueArray[8] : '';

	        if (!empty($fontFamily)) {
	            $font['family'] = $fontFamily;
	        }

	        if (!empty($fontWeight)) {
	            $font['weight'] = 'on' === $fontWeight ? '700' : $fontWeight;
	        }

	        if (!empty($fontStyle)) {
	            $font['style'] = $fontStyle;
	        }

	        if (!empty($fontLineColor)) {
	            $font['lineColor'] = $fontLineColor;
	        }

	        if (!empty($fontLineStyle)) {
	            $font['lineStyle'] = $fontLineStyle;
	        }

	        return $font;
	    }

		/**
		 * Convert module categories value.
		 */
		static function diplConvertCategories( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			return explode( ',', $value );
		}

		/**
		 * Convert module facebook page tabs value.
		 */
		static function diplConvertFacebookPageTab( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}
			$keys        = array( 'timeline', 'events', 'messages' );
			$value_array = explode( '|', $value ?? '' );

			return array_values( array_filter( $keys, function( $key, $index ) use ( $value_array ) {
				return isset( $value_array[ $index ] ) && $value_array[ $index ] === 'on';
			}, ARRAY_FILTER_USE_BOTH ) );
		}

		/**
		 * Convert module single border radius to,
		 * all corner border radius.
		 */
		static function diplConvertBorderRtoRadii( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			return array(
				'sync'        => 'on',
				'topLeft'     => $value,
				'topRight'    => $value,
				'bottomRight' => $value,
				'bottomLeft'  => $value
			);
		}

		/**
		 * Convert twitter/X chrome value.
		 */
		static function diplConvertXChromeValues( $value ) {
			$keys       = [ 'noheader', 'nofooter', 'noborders', 'transparent' ];
			$valueArray = explode( '|', $value ?? '' );
			
			$result = [];
			foreach ( $keys as $index => $key ) {
				if ( isset($valueArray[$index]) && $valueArray[$index] === 'on' ) {
					$result[] = $key;
				}
			}

			return $result;
		}

		/**
		 * Convert module gradient background stops.
		 */
		static function diplConvertBackgroundStops( $value ) {
			$valueArray = explode('|', $value);
	        $stops = [];

	        foreach ($valueArray as $stop) {
	            $stop = trim($stop);
	            
	            // Use regex to split on the last space to handle colors with spaces (like RGBA)
	            if (preg_match('/^(.+)\s+(\d+%?)$/', $stop, $matches)) {
	                $color = trim($matches[1]);
	                $position = $matches[2];
	            } else {
	                // Fallback to original method for backward compatibility
	                $stopsData = explode(' ', $stop);
	                $position = array_pop($stopsData);
	                $color = implode(' ', $stopsData);
	            }

	            $stops[] = [
	                'position' => (int) $position,
	                'color' => $color,
	            ];
	        }

	        return $stops;
		}

		/**
	     * Convert D4 Border Radii to D5 format.
	     *
	     * @param string $value Shortcode attribute value for Border radius.
	     * @return array D5 Border radius value.
	     */
	    public static function diplConvertBorderRadii($value) {
	        $valueArray = explode('|', $value);

	        // Button border radius has single value with Range field in D4.
	        // In D5 it will use border radius field: https://elegantthemes.slack.com/archives/C01CW343ZJ9/p1648087767334689
	        $isSingleValue = (strpos($value, '|') === false);

	        return [
	            'sync' => $isSingleValue ? 'on' : ($valueArray[0] ?? ''),
	            'topLeft' => $isSingleValue ? $value : ($valueArray[1] ?? ''),
	            'topRight' => $isSingleValue ? $value : ($valueArray[2] ?? ''),
	            'bottomRight' => $isSingleValue ? $value : ($valueArray[3] ?? ''),
	            'bottomLeft' => $isSingleValue ? $value : ($valueArray[4] ?? ''),
	        ];
	    }

		/**
		 * Modal Popup Animation Conversion.
		 *
		 * @param string $value divi 4 attr value
		 * @return string divi 5 attr value
		 */
		static function diplConvertModalAnimDirection( $value ) {
			$map = [
				'left'   => 'right',
				'right'  => 'left',
				'up'     => 'bottom',
				'down'   => 'top',
				'center' => 'center',
			];
			return $map[$value] ?? $value;
		}

		/**
		 * Convert module gradient background property.
		 */
		static function diplConvertLegacyGradientProperty( $value ) {
			return strval( intval( $value ) );
		}

		/**
		 * Convert module background position.
		 */
		static function diplConvertBackgroundPosition( $value ) {
			// Mapping of D4 background position values to D5 format.
			$positionMap = [
				'top_left'      => 'left top',
				'top_center'    => 'center top',
				'top_right'     => 'right top',
				'center_left'   => 'left center',
				'center'        => 'center',
				'center_right'  => 'right center',
				'bottom_left'   => 'left bottom',
				'bottom_center' => 'center bottom',
				'bottom_right'  => 'right bottom',
			];

			// Convert the value if mapping exists, otherwise return the original value.
			return isset( $positionMap[$value] ) ? $positionMap[$value] : $value;
		}

		/**
		 * Convert ajax search search in field value.
		 */
		static function diplAjaxSearchConvertSearchInFields( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			$map   = [ 'post_title', 'post_content', 'post_excerpt' ];
			$flags = explode( '|', $value );
			
			$result = [];
			foreach ( $flags as $index => $flag ) {
				if ( 'on' === $flag && isset( $map[ $index ] ) ) {
					$result[] = $map[ $index ];
				}
			}

			return $result;
		}

		/**
		 * Convert ajax search display field value.
		 */
		static function diplAjaxSearchConvertDisplayFields( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			$map   = [ 'title', 'excerpt', 'featured_image', 'product_price' ];
			$flags = explode( '|', $value );
			
			$result = [];
			foreach ( $flags as $index => $flag ) {
				if ( 'on' === $flag && isset( $map[ $index ] ) ) {
					$result[] = $map[ $index ];
				}
			}

			return $result;
		}

		/**
		 * Convert extension disable on value.
		 */
		static function diplConvertParticleBgDisabledOn( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			$map   = [ 'phone', 'tablet', 'desktop' ];
			$flags = explode( '|', $value );
	
			$result = [];
			foreach ( $flags as $index => $flag ) {
				if ( 'on' === $flag && isset( $map[ $index ] ) ) {
					$result[] = $map[ $index ];
				}
			}

			return $result;
		}

		/**
		 * Image accordion inactive state.
		 */
		static function diplImageAccConvertInactiveDisplay( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			$map   = [ 'title', 'icon' ];
			$flags = explode( '|', $value );
			
			$result = [];
			foreach ( $flags as $index => $flag ) {
				if ( 'on' === $flag && isset( $map[ $index ] ) ) {
					$result[] = $map[ $index ];
				}
			}

			return $result;
		}

		/**
		 * How-to Schema tools, supplies json convert.
	 	*/
		static function diplHowtoSchemaConvertStepItem( $value ) {
			if ( empty( $value ) || ! is_string( $value ) ) {
				return $value;
			}

			// URL decode.
			$value = urldecode( $value );

			// Fix invalid UTF-8 characters.
			$value = mb_convert_encoding( $value, 'UTF-8', 'UTF-8' );

			// Remove first and last character manually.
			$value = substr( $value, 1, -1 );

			// Wrap in brackets.
			$value = '[' . $value . ']';

			// Decode JSON.
			$decoded_json = json_decode( $value, true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded_json ) ) {
				return $decoded_json;
			}

			return $value;
		}

		/**
		 * Convert woo products accordion,
		 * inactive state value.
		 */
		static function diplWooProdAccConvertInactiveState( $value ) {
			$keys       = [ 'categories', 'title', 'description' ];
			$valueArray = explode( '|', $value ?? '' );
			
			$result = [];
			foreach ( $keys as $index => $key ) {
				if ( isset($valueArray[$index]) && $valueArray[$index] === 'on' ) {
					$result[] = $key;
				}
			}

			return $result;
		}

		/**
		 * Convert ajax search search in field value.
		 */
		static function diplTeamGridConvertDisplayInPopup( $value ) {
			if ( ! is_string( $value ) ) {
				return $value;
			}

			$map   = [ 'image', 'designation', 'social_icons', 'content', 'skills_bars' ];
			$flags = explode( '|', $value );
			
			$result = [];
			foreach ( $flags as $index => $flag ) {
				if ( 'on' === $flag && isset( $map[ $index ] ) ) {
					$result[] = $map[ $index ];
				}
			}

			return $result;
		}
	}
}

return new Dipl_Module_Conversion();
