<?php
/**
 * Divi 5 main file,
 * manages divi 5 file loading.
 */
// Exit if accessed directly.
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

// Require php files.
require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/vendor/autoload.php';
require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/server/Modules/Modules.php';

/**
 * Enqueue Divi 5 Visual Builder Assets
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'dipl_divi5_enqueue_visual_builder_assets' ) ) {
	function dipl_divi5_enqueue_visual_builder_assets() {
		if ( et_core_is_fb_enabled() && et_builder_d5_enabled() ) {
			
			// get plugin options.
			$plugin_options = get_option( ELICUS_DIVI_PLUS_OPTION );

			// Get app data.
			$app_data = array(
				'restUrl'          => esc_url_raw( rest_url() ),
				'facebook_app_id'  => esc_attr( $plugin_options['dipl-facebook-app-id'] ?? '' ),
				'twitter_username' => esc_attr( $plugin_options['dipl-twitter-username'] ?? '' ),
			);

			$modules_list = DiviPlus::get_registered_modules_list();

			$enabled_modules = [];
			if ( isset( $plugin_options['dipl-modules'] ) ) {
				$enabled_modules = explode( ',', $plugin_options['dipl-modules'] );
				$filtered_modules = [];
				if ( ! empty( $enabled_modules ) ) {
					foreach ( $modules_list as $slug => $module ) {
						$check_slug = $slug;
						// Remove `_item` if present for matching.
						if ( strpos( $check_slug, '_item' ) !== false ) {
							$check_slug = str_replace( '_item', '', $check_slug );
						}
						if ( in_array( $check_slug, $enabled_modules, true ) ) {
							$filtered_modules[ $slug ] = $module;
						}
					}
				}
			    $app_data['DIPL_Modules'] = wp_json_encode( $filtered_modules );
			}

			\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build( [
				'name'    => 'divi-plus-divi5-visual-builder',
				'version' => ELICUS_DIVI_PLUS_VERSION,
				'script'  => [
					'src'  => ELICUS_DIVI_PLUS_DIR_URL . 'divi-5/visual-builder/build/build.js',
					'deps' => [
						'divi-module-library',
						'divi-vendor-wp-hooks',
						'divi-vendor-react',
						'jquery-core',
						'divi-rest',
						'wp-hooks',
					],
					'enqueue_top_window' => false,
					'enqueue_app_window' => true,
					'data_app_window'    => $app_data
				]
			] );
		}
	}
	add_action( 'divi_visual_builder_assets_before_enqueue_scripts', 'dipl_divi5_enqueue_visual_builder_assets' );
	// You must use this hook to enqueue your assets for the Divi 5 Visual Builder.	
}

// Load module conversion class file.
require_once ELICUS_DIVI_PLUS_DIR_PATH . 'divi-5/class-module-conversion.php';

// Add post meta to the REST API response
// function add_meta_to_rest_response($data, $post, $request) {
//     $meta = get_post_meta($post->ID);
//     $data->data['meta'] = $meta;
//     return $data;
// }
// add_filter('rest_prepare_dipl-team-member', 'add_meta_to_rest_response', 10, 3);

if ( ! function_exists( 'dipl_legacy_attribute_names' ) ) {
	function dipl_legacy_attribute_names( $attributes ) {
		$plugin_attributes = [
	    	'buttons_bg_color_gradient_start',
	        'buttons_bg_color_gradient_end',
	        'submit_bg_color_gradient_start',
	        'submit_bg_color_gradient_end',
	        'reset_bg_color_gradient_start',
	        'reset_bg_color_gradient_end'
	    ];
	    return array_merge( $attributes, $plugin_attributes );
	}
	add_filter( 'divi.conversion.legacyAttributeNames', 'dipl_legacy_attribute_names' );
}
