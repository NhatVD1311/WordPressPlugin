<?php
/**
 * @author     Elicus <hello@elicus.com>
 * @link       https://www.elicus.com/
 * @copyright  2025 Elicus Technologies Private Limited
 * @version    2.0.0
 */
class DIPL_AdvancedTable extends ET_Builder_Module {
	public $slug       = 'dipl_advanced_table';
	public $child_slug = 'dipl_advanced_table_item';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://diviextended.com/product/divi-plus/',
		'author'     => 'Elicus',
		'author_uri' => 'https://elicus.com/',
	);

	public function init() {
		$this->name             = esc_html__( 'DP Advanced Table', 'divi-plus' );
		$this->child_item_text  = esc_html__( 'Table Cell', 'divi-plus' );
		$this->main_css_element = '%%order_class%%';
		add_filter( 'et_builder_processed_range_value', array( $this, 'dipl_builder_processed_range_value' ), 10, 3 );
	}

	public function get_settings_modal_toggles() {
		return array(
			'general'  => array(
				'toggles' => array(
					'main_content' => esc_html__( 'Configuration', 'divi-plus' ),
				),
			),
			'advanced' => array(
				'toggles' => array(
					'header'          => esc_html__( 'Header', 'divi-plus' ),
					'header_text'     => esc_html__( 'Header Text', 'divi-plus' ),
					'table_cell'      => esc_html__( 'Table Cell', 'divi-plus' ),
					'table_cell_text' => esc_html__( 'Table Cell Text', 'divi-plus' ),
				),
			),
		);
	}

	public function get_advanced_fields_config() {
		return array(
			'fonts' => array(
				'header_text' => array(
					'label'     => esc_html__( 'Header', 'divi-plus' ),
					'font_size' => array(
						'default' => '16px',
					),
					'hide_text_align' => true,
					'css'             => array(
						'main'      => "{$this->main_css_element} .dipl-at-header-cell .dipl_advanced_table_item_cell, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading",
						'important' => 'all',
					),
					'tab_slug'        => 'advanced',
					'toggle_slug'     => 'header_text',			
				),
				'table_cell_text' => array(
					'label'     => esc_html__( 'Table Cell Text', 'divi-plus' ),
					'font_size' => array(
						'default' => '14px',
					),
					'hide_text_align' => true,
					'css'             => array(
						'main' => "{$this->main_css_element} .dipl_advanced_table_item_cell_wrap:not(.dipl-at-header-cell) .dipl_advanced_table_item_cell",
					),
					'tab_slug'    => 'advanced',
					'toggle_slug' => 'table_cell_text',			
				)
			),
			'borders' => array(
				'header' => array(
					'label_prefix' => esc_html__( 'Header', 'divi-plus' ),
					'css'          => array(
						'main' => array(
							'border_radii'  => "{$this->main_css_element} .dipl_advanced_table-row.dipl-at-header-row .dipl_advanced_table_item, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading",
							'border_styles' => "{$this->main_css_element} .dipl_advanced_table-row.dipl-at-header-row .dipl_advanced_table_item, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading",
						),
						'important' => 'all',
					),
					'tab_slug'     => 'advanced',
					'toggle_slug'  => 'header'
				),
				'table_cell' => array(
					'label_prefix' => esc_html__( 'Table Cell', 'divi-plus' ),
					'css'          => array(
						'main' => array(
							'border_radii'  => "%%order_class%% .dipl_advanced_table-row:not( .dipl-at-header-row ) .dipl_advanced_table_item",
							'border_styles' => "%%order_class%% .dipl_advanced_table-row:not( .dipl-at-header-row ) .dipl_advanced_table_item",
						),
						'important' => 'all',
					),
					'tab_slug'     => 'advanced',
					'toggle_slug'  => 'table_cell'
				),
				'default' => array(
					'css' => array(
						'main' => array(
							'border_styles' => '%%order_class%%',
							'border_radii'  => '%%order_class%%',
						),
					),
				),
			),
			'advanced_table_spacing' => array(
				'header' => array(
					'margin_padding' => array(
						'css' => array(
							'use_margin' => false,
							'padding'    => "{$this->main_css_element} .dipl_advanced_table-row.dipl-at-header-row .dipl_advanced_table_item, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading",
						),
					),
				),
				'table_cell' => array(
					'margin_padding' => array(
						'css' => array(
							'use_margin' => false,
							'padding'    => "{$this->main_css_element} .dipl_advanced_table-row:not( .dipl-at-header-row ) .dipl_advanced_table_item",
						),
					),
				)
			),
			'margin_padding' => array(
				'css'     => array(
					'important' => 'all',
				),
				'default' => array(
					'css' => array(
						'main'      => '%%order_class%%',
						'important' => 'all',
					),
				),
			),
			'text'         => false,
			'text_shadow'  => false,
			'link_options' => false,
		);
	}

	public function get_fields() {
		return array_merge(
			array(
				'columns_number' => array(
					'label'            => esc_html__( 'Number Of Columns', 'divi-plus' ),
					'type'             => 'range',
					'option_category'  => 'basic_option',
					'range_settings'   => array(
						'min'  => '1',
						'max'  => '100',
						'step' => '1',
					),
					'default'          => '4',
					'default_on_front' => '4',
					'default_unit'     => '',
					'allowed_units'    => false,
					'tab_slug'         => 'general',
					'toggle_slug'      => 'main_content',
					'description'      => esc_html__( 'Choose how many columns should be displayed in the table.', 'divi-plus' ),
				),
				'comparison_header_notice' => array(
					'label'           => '',
					'type'            => 'warning',
					'option_category' => 'configuration',
					'value'           => true,
					'display_if'      => true,
					'message'         => esc_html__( '<strong>Tip:</strong> The first set of table cells will be treated as column headers. The number of header cells is determined by the column count specified in this settings. All remaining cells will be rendered as standard table cells.', 'divi-plus' ),
					'toggle_slug'      => 'main_content',
				),
				'column_spacing' => array(
					'label'            => esc_html__( 'Column Spacing', 'divi-plus' ),
					'type'             => 'range',
					'option_category'  => 'basic_option',
					'range_settings'   => array(
						'min'  => '0',
						'max'  => '100',
						'step' => '1',
					),
					'default'          => '0px',
					'default_on_front' => '0px',
					'default_unit'     => 'px',
					'allowed_units'    => 'px',
					'mobile_options'   => true,
					'tab_slug'         => 'general',
					'toggle_slug'      => 'main_content',
					'description'      => esc_html__( 'Choose the spacing between columns.', 'divi-plus' ),
				),
				'row_spacing' => array(
					'label'            => esc_html__( 'Row Spacing', 'divi-plus' ),
					'type'             => 'range',
					'option_category'  => 'basic_option',
					'range_settings'   => array(
						'min'  => '0',
						'max'  => '100',
						'step' => '1',
					),
					'default'          => '0px',
					'default_on_front' => '0px',
					'default_unit'     => 'px',
					'allowed_units'    => 'px',
					'mobile_options'   => true,
					'tab_slug'         => 'general',
					'toggle_slug'      => 'main_content',
					'description'      => esc_html__( 'Choose the spacing between rows.', 'divi-plus' ),
				),
				'header_bg_color' => array(
					'label'             => esc_html__( 'Header Background', 'divi-plus' ),
					'type'              => 'background-field',
					'base_name'         => 'header_bg',
					'context'           => 'header_bg_color',
					'option_category'   => 'button',
					'custom_color'      => true,
					'background_fields' => $this->generate_background_options( 'header_bg', 'button', 'advanced', 'header', 'header_bg_color' ),
					'hover'             => 'tabs',
					'tab_slug'          => 'advanced',
					'toggle_slug'       => 'header',
					'description'       => esc_html__( 'Here you can adjust the background style of the table header by customizing the background color, gradient, and image.', 'divi-plus' ),
				),
				'header_custom_padding' => array(
					'label'            => esc_html__( 'Header Padding', 'divi-plus' ),
					'type'             => 'custom_padding',
					'option_category'  => 'layout',
					'default'		   => '20px|20px|20px|20px|on|on',
					'default_on_front' => '20px|20px|20px|20px|on|on',
					'mobile_options'   => true,
					'hover'            => false,
					'tab_slug'         => 'advanced',
					'toggle_slug'      => 'header',
					'description'      => esc_html__( 'Padding adds extra space to the inside of the element, increasing the distance between the edge of the element and its inner contents.', 'divi-plus' )
				),
				'table_cell_bg_color' => array(
					'label'             => esc_html__( 'Table Cell Background', 'divi-plus' ),
					'type'              => 'background-field',
					'base_name'         => 'table_cell_bg',
					'context'           => 'table_cell_bg_color',
					'option_category'   => 'button',
					'custom_color'      => true,
					'background_fields' => $this->generate_background_options( 'table_cell_bg', 'button', 'advanced', 'table_cell', 'table_cell_bg_color' ),
					'hover'             => 'tabs',
					'tab_slug'          => 'advanced',
					'toggle_slug'       => 'table_cell',
					'description'       => esc_html__( 'Here you can adjust the background style of the table cell by customizing the background color, gradient, and image.', 'divi-plus' ),
				),
				'table_cell_custom_padding' => array(
					'label'            => esc_html__( 'Table Cell Padding', 'divi-plus' ),
					'type'             => 'custom_padding',
					'option_category'  => 'layout',
					'mobile_options'   => true,
					'hover'            => false,
					'default'		   => '20px|20px|20px|20px|on|on',
					'default_on_front' => '20px|20px|20px|20px|on|on',
					'tab_slug'         => 'advanced',
					'toggle_slug'      => 'table_cell',
					'description'      => esc_html__( 'Padding adds extra space to the inside of the element, increasing the distance between the edge of the element and its inner contents.', 'divi-plus' )
				),
			),
			$this->generate_background_options( 'header_bg', 'skip', 'advanced', 'header', 'header_bg_color' ),
			$this->generate_background_options( 'table_cell_bg', 'skip', 'advanced', 'table_cell', 'table_cell_bg_color' ),
		);
	}

	public function render( $attrs, $content, $render_slug ) {

		$columns_number = $this->props['columns_number'] ?? 4;

		$render_output = '';
		if ( ! empty( $content ) ) {

			// Load style and scripts.
			wp_enqueue_style( 'divi-plus-advanced-table' );

			// Convert the html to array.
			$content_array = et_pb_parse_shortcode_to_array( $content );

			// All rows.
			$rows = array_chunk( $content_array, $columns_number );

			// Get header cells.
			$header_cells = array_shift( $rows );
			$header_attrs = [];
			$header_row   = '';
			if ( ! empty( $header_cells ) ) {
				$header_items = '';
				foreach ( $header_cells as $i => $item ) {

					$shortcode_html = do_shortcode( et_fb_process_to_shortcode( array( $item ) ) );
					preg_match( '/dipl_advanced_table_item_(\d+)/', $shortcode_html, $item_class );

					$item_class     = ! empty( $item_class[0] ) ? $item_class[0] : 'dipl_advanced_table_item_i' . esc_attr( $i );
					$header_attrs[] = array(
						'cell_value' => wpautop( wp_strip_all_tags( $item['attrs']['cell_value'] ) ) ?? '',
						'item_class' => esc_attr( $item_class )
					);

					$header_items  .= sprintf(
						'<div class="dipl_advanced_table_item_cell_wrap %1$s_cell_wrap dipl-at-header-cell">
							<div class="dipl_advanced_table-row-cell">%2$s</div>
						</div>',
						esc_attr( $item_class ),
						et_core_esc_previously( $shortcode_html )
					);
				}
				$header_row = sprintf(
					'<div class="dipl_advanced_table-row dipl-at-header-row">%1$s</div>',
					et_core_esc_previously( $header_items )
				);
			}

			// Row items.
			$item_rows = '';
			if ( ! empty( $rows ) ) {
				foreach ( $rows as $row_index => $row_cells ) {
					$row_html = '';
					foreach ( $row_cells as $cell_index => $cell ) {
						// Responsive heading (per column).
						$responsive_heading = '';
						if ( ! empty( $header_attrs[ $cell_index ]['cell_value'] ) ) {
							$responsive_heading = sprintf(
								'<div class="dipl_advanced_table_item_responsive_heading %1$s_responsive_heading">%2$s</div>',
								et_core_esc_previously( $header_attrs[ $cell_index ]['item_class'] ?? '' ),
								et_core_esc_previously( $header_attrs[ $cell_index ]['cell_value'] )
							);
						}

						$shortcode_html = do_shortcode( et_fb_process_to_shortcode( array( $cell ) ) );
						preg_match( '/dipl_advanced_table_item_(\d+)/', $shortcode_html, $item_class );

						$row_html .= sprintf(
							'<div class="dipl_advanced_table_item_cell_wrap %1$s_cell_wrap">%2$s
								<div class="dipl_advanced_table-row-cell">%3$s</div>
							</div>',
							! empty( $item_class[0] ) ? $item_class[0] : 'dipl_advanced_table_item_i' . esc_attr( $i ),
							et_core_esc_previously( $responsive_heading ),
							et_core_esc_previously( $shortcode_html )
						);
					}
					$item_rows .= sprintf(
						'<div class="dipl_advanced_table-row">%1$s</div>',
						et_core_esc_previously( $row_html )
					);
				}
			}

			// Final output.
			$render_output = sprintf(
				'<div class="dipl_advanced_table_wrap">%1$s %2$s</div>',
				et_core_esc_previously( $header_row ),
				et_core_esc_previously( $item_rows )
			);

			// Table columns.
			// self::set_style( $render_slug, array(
			// 	'selector'    => '%%order_class%% .dipl_advanced_table-row-cell',
			// 	'declaration' => "flex: 0 0 calc(100% / {$columns_number});",
			// ) );
			self::set_style( $render_slug, array(
				'selector'    => '%%order_class%% .dipl_advanced_table-row',
				'declaration' => "grid-template-columns: repeat({$columns_number}, 1fr);",
			) );

			// Column spacing.
			$column_spacing = et_pb_responsive_options()->get_property_values( $this->props, 'column_spacing' );
			if ( ! empty( array_filter( $column_spacing ) ) ) {
				et_pb_responsive_options()->generate_responsive_css( $column_spacing, '%%order_class%% .dipl_advanced_table-row', 'gap', $render_slug, '!important;', 'range' );
			}

			// Row spacing.
			$row_spacing = et_pb_responsive_options()->get_property_values( $this->props, 'row_spacing' );
			if ( ! empty( array_filter( $row_spacing ) ) ) {
				et_pb_responsive_options()->generate_responsive_css( $row_spacing, '%%order_class%% .dipl_advanced_table-row:not(:last-child)', 'margin-bottom', $render_slug, '!important;', 'range' );
			}

			$args = array(
				'render_slug'	=> $render_slug,
				'props'			=> $this->props,
				'fields'		=> $this->fields_unprocessed,
				'module'		=> $this,
				'backgrounds' 	=> array(
					'header_bg' => array(
						'normal' => "{$this->main_css_element} .dipl_advanced_table-row.dipl-at-header-row .dipl_advanced_table_item, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading",
						'hover' => "{$this->main_css_element} .dipl_advanced_table-row.dipl-at-header-row .dipl_advanced_table_item:hover, {$this->main_css_element} .dipl_advanced_table_item_responsive_heading:hover",
					),
					'table_cell_bg' => array(
						'normal' => "{$this->main_css_element} .dipl_advanced_table-row:not( .dipl-at-header-row ) .dipl_advanced_table_item",
						'hover' => "{$this->main_css_element} .dipl_advanced_table-row:not( .dipl-at-header-row ) .dipl_advanced_table_item:hover",
					)
				),
			);
			DiviPlusHelper::process_background( $args );
		
			$fields = array( 'advanced_table_spacing' );
			DiviPlusHelper::process_advanced_margin_padding_css( $this, $render_slug, $this->margin_padding, $fields );
		}

		return et_core_intentionally_unescaped( $render_output, 'html' );
	}

	public function dipl_builder_processed_range_value( $result, $range, $range_string ) {
		if ( false !== strpos( $result, '0calc' ) ) {
			return $range;
		}
		return $result;
	}
}

$plugin_options = DiviPlus::get_plugin_options();
if ( isset( $plugin_options['dipl-modules'] ) ) {
	$modules = explode( ',', $plugin_options['dipl-modules'] );
	if ( in_array( 'dipl_advanced_table', $modules ) ) {
		new DIPL_AdvancedTable();
	}
} else {
	new DIPL_AdvancedTable();
}
