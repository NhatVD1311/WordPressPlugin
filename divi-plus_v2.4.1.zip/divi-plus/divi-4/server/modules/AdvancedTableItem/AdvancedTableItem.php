<?php
/**
 * @author     Elicus <hello@elicus.com>
 * @link       https://www.elicus.com/
 * @copyright  2025 Elicus Technologies Private Limited
 * @version    2.0.0
 */
class DIPL_AdvancedTableItem extends ET_Builder_Module {
	public $slug       = 'dipl_advanced_table_item';
	public $type       = 'child';
	public $vb_support = 'on';

	protected $module_credits = array(
		'module_uri' => 'https://diviextended.com/product/divi-plus/',
		'author'     => 'Elicus',
		'author_uri' => 'https://elicus.com/',
	);

	public function init() {
		$this->name                        = esc_html__( 'DP Advanced Table Item', 'divi-plus' );
		$this->advanced_setting_title_text = esc_html__( 'Table Cell', 'divi-plus' );
		$this->child_title_var             = 'cell_value';
		$this->main_css_element            = '.dipl_advanced_table .dipl_advanced_table-row %%order_class%%';
	}

	public function get_settings_modal_toggles() {
		return array(
			'general'  => array(
				'toggles' => array(
					'main_content' => array(
						'title'    => esc_html__( 'Content', 'divi-plus' ),
						'priority' => 1,
						'tab'      => 'active',
					),
				),
			),
			'advanced' => array(
				'toggles' => array(
					'cell_text' => esc_html__( 'Cell Text', 'divi-plus' ),
				),
			),
		);
	}

	public function get_advanced_fields_config() {
		return array(
			'fonts' => array(
				'cell_text' => array(
					'label'     => esc_html__( 'Cell Text', 'divi-plus' ),
					'font_size' => array(
						'range_settings' => array(
							'min'  => '1',
							'max'  => '100',
							'step' => '1',
						),
						'validate_unit'  => true,
					),
					'line_height' => array(
						'range_settings' => array(
							'min'  => '0.1',
							'max'  => '10',
							'step' => '0.1',
						),
					),
					'hide_text_align' => true,
					'css' => array(
						'main'      => ".dipl_advanced_table .dipl_advanced_table_item_cell_wrap .dipl_advanced_table-row-cell %%order_class%% .dipl_advanced_table_item_cell, .dipl_advanced_table %%order_class%%_responsive_heading",
						'important' => 'all',
					),
					'tab_slug'    => 'advanced',
					'toggle_slug' => 'cell_text',			
				),
			),
			'borders' => array(
				'default' => array(
					'css' => array(
						'main' => array(
							'border_styles' => "{$this->main_css_element}",
							'border_radii'  => "{$this->main_css_element}",
						),
						'important' => 'all',
					),
				),
			),
			'margin_padding' => array(
				'use_margin' => false,
				'css'     => array(
					'main'      => "{$this->main_css_element}",
					'important' => 'all',
				),
				'default' => array(
					'css' => array(
						'main'      => "{$this->main_css_element}",
						'important' => 'all',
					),
				),
			),
			'background' => array(
				'use_background_video' => false,
				'css' => array(
					'main'      => ".dipl_advanced_table .dipl_advanced_table-row .dipl_advanced_table-row-cell %%order_class%%",
					'important' => 'all',
				),
			),
			'text'        => false,
			'module'      => false,
			'text_shadow' => false,
		);
	}

	public function get_fields() {
		$et_accent_color = et_builder_accent_color();
		return array(
			'cell_value' => array(
				'label'           => esc_html__( 'Table Cell Value', 'divi-plus' ),
				'type'            => 'tiny_mce',
				'option_category' => 'basic_option',
				'dynamic_content' => 'text',
				'tab_slug'        => 'general',
				'toggle_slug'     => 'main_content',
				'description'     => esc_html__( 'Here you can enter table single cell value.', 'divi-plus' ),
			),
		);
	}

	public function render( $attrs, $content, $render_slug ) {
		$render_output = '';
		if ( ! empty( $this->props['cell_value'] ) ) {
			$render_output = sprintf(
				'<div class="dipl_advanced_table_item_cell">%1$s</div>',
				et_core_esc_previously( wpautop( wp_strip_all_tags( $this->props['cell_value'] ) ) )
			);
		}
		
		return $render_output;
	}
}

$plugin_options = DiviPlus::get_plugin_options();
if ( isset( $plugin_options['dipl-modules'] ) ) {
	$modules = explode( ',', $plugin_options['dipl-modules'] );
	if ( in_array( 'dipl_advanced_table', $modules ) ) {
		new DIPL_AdvancedTableItem();
	}
} else {
	new DIPL_AdvancedTableItem();
}
