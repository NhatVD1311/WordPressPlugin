<?php
/**
 * @author     Elicus <hello@elicus.com>
 * @link       https://www.elicus.com/
 * @copyright  2025 Elicus Technologies Private Limited
 * @version    1.20.0
 */
class DIPL_PieChart extends ET_Builder_Module {
	public $slug       = 'dipl_pie_chart';
	public $child_slug = 'dipl_pie_chart_item';
	public $vb_support = 'on';  

	/**
	 * Track if the module is currently rendering,
	 * to prevent unnecessary rendering and recursion.
	 *
	 * @var bool
	 */
	protected static $rendering = false;

	protected $module_credits = array(
		'module_uri' => 'https://diviextended.com/product/divi-plus/',
		'author'     => 'Elicus',
		'author_uri' => 'https://elicus.com/',
	);

	public function init() {
		$this->name 			= esc_html__( 'DP Pie Chart', 'divi-plus' );
		$this->child_item_text  = esc_html__( 'Pie Chart Item', 'divi-plus' );
		$this->main_css_element = '%%order_class%%';
		add_filter( 'et_builder_processed_range_value', array( $this, 'dipl_builder_processed_range_value' ), 10, 3 );
	}

	public function get_settings_modal_toggles() {
		return array(
			'advanced' => array(
				'toggles' => array(
					'pie_chart' => esc_html__( 'Pie Chart', 'divi-plus' )
				)
			)
		);
	}

	public function get_advanced_fields_config() {
		return array(
			'fonts'   => false,
			'borders' => array(
				'default' => array(
					'css' => array(
						'main' => array(
							'border_styles' => "{$this->main_css_element}",
							'border_radii'  => "{$this->main_css_element}",
						),
					),
				),
			),
			'box_shadow' => array(
				'default' => array(
					'css' => array(
						'main' => "{$this->main_css_element}",
					),
				)
			),
			'margin_padding' => array(
				'css' => array(
					'main'      => "{$this->main_css_element}",
					'important' => 'all',
				),
			),
			'text'        => false,
			'text_shadow' => false,
			'background'  => array(
				'use_background_video' => false,
			),
		);
	}

	public function get_fields() {
		return array(
			'chart_height' => array(
				'label'            => esc_html__( 'Pie Chart Height', 'divi-plus' ),
				'type'             => 'range',
				'option_category'  => 'font_option',
				'range_settings'   => array(
					'min'  => '100',
					'max'  => '1000',
					'step' => '1',
				),
				'default'          => '400',
				'unitless'         => true,
				'mobile_options'   => true,
				'tab_slug'         => 'advanced',
				'toggle_slug'      => 'pie_chart',
				'description'      => esc_html__( 'Control the size of the icon by increasing or decreasing the font size.', 'divi-plus' ),
			),
			'chart_border_size' => array(
				'label'            => esc_html__( 'Pie Border Size', 'divi-plus' ),
				'type'             => 'range',
				'option_category'  => 'font_option',
				'range_settings'   => array(
					'min'  => '0',
					'max'  => '20',
					'step' => '1',
				),
				'default'          => '1',
				'unitless'         => true,
				'mobile_options'   => false,
				'tab_slug'         => 'advanced',
				'toggle_slug'      => 'pie_chart',
				'description'      => esc_html__( 'Control the size of the icon by increasing or decreasing the font size.', 'divi-plus' ),
			),
		);
	}

	public function before_render() {
		global $dipl_pie_chart_item_data;
		$dipl_pie_chart_item_data = array();

		$this->props['chart_height']        = ! empty( $this->props['chart_height'] ) ? $this->props['chart_height'] : '400';
		$this->props['chart_height_tablet'] = ! empty( $this->props['chart_height_tablet'] ) ? $this->props['chart_height_tablet'] : $this->props['chart_height'];
		$this->props['chart_height_phone']  = ! empty( $this->props['chart_height_phone'] ) ? $this->props['chart_height_phone'] : $this->props['chart_height_tablet'];
	}

	public function render( $attrs, $content, $render_slug ) {
		if ( self::$rendering ) {
			// We are trying to render a Blog module while a Blog module is already being rendered
			// which means we have most probably hit an infinite recursion. While not necessarily
			// the case, rendering a post which renders a Blog module which renders a post
			// which renders a Blog module is not a sensible use-case.
			return '';
		}

		global $dipl_pie_chart_item_data;

		// Get order class.
		$order_class       = $this->get_module_order_class( $render_slug );

		$chart_border_size = sanitize_text_field( $this->props['chart_border_size'] ) ?? '1';

		// Get data from childern.
		$render_output = '';
		if ( ! empty( $dipl_pie_chart_item_data ) ) {

			// Load style and script files.
			wp_enqueue_script( 'chart-js' );
			wp_enqueue_script( 'divi-plus-pie-chart' );

			$labels      = [];
			$values      = [];
			$bgColor     = [];
			$borderColor = [];
			foreach ( $dipl_pie_chart_item_data as $child ) {
				if ( $child['title'] && $child['value'] ) {
					$labels[]      = esc_html__( $child['title'], 'divi-plus' );
					$values[]      = esc_attr( $child['value'] );
					$bgColor[]     = esc_attr( $child['pie_bg_color'] ) ?? 'rgba(0,0,0,0.2)';
					$borderColor[] = esc_attr( $child['pie_border_color'] ) ?? 'rgb(0,0,0)';
				}
			}

			// Get chart data.
			$chart_data = array(
				'labels'   => $labels,
				'datasets' => array( array(
					'data'            => $values,
					'backgroundColor' => $bgColor,
					'borderColor'     => $borderColor,
					'borderWidth'     => $chart_border_size,
				) )
			);

			// Get chart height.
			$chart_height = et_pb_responsive_options()->get_property_values( $this->props, 'chart_height' );

			// Final output.
			$render_output = sprintf(
				'<div class="dipl_pie_chart_wrapper"
					data-chart="%1$s"
					data-chart_height="%2$s"
					data-chart_height_tablet="%3$s"
					data-chart_height_phone="%4$s"
				>
					<div class="dipl_pie_chart_inner">
						<canvas id="%5$s--canvas"></canvas>
					</div>
				</div>',
				htmlspecialchars( wp_json_encode( $chart_data ), ENT_QUOTES, 'UTF-8' ),
				esc_attr( $chart_height['desktop'] ),
				esc_attr( $chart_height['tablet'] ),
				esc_attr( $chart_height['phone'] ),
				esc_attr( $order_class )
			);
		}

		self::$rendering = false;
		return et_core_intentionally_unescaped( $render_output, 'html' );
	}
	public function dipl_builder_processed_range_value( $result, $range, $range_string ) {
		if ( false !== strpos( $result, '0calc' ) ) {
			return $range;
		}
		return $result;
	}
}

$plugin_options = DiviPlus::get_plugin_options();
if ( isset( $plugin_options['dipl-modules'] ) ) {
	$modules = explode( ',', $plugin_options['dipl-modules'] );
	if ( in_array( 'dipl_pie_chart', $modules, true ) ) {
		new DIPL_PieChart();
	}
} else {
	new DIPL_PieChart();
}
