<?php
namespace Jet_Engine\Blocks_Views\Dynamic_Content\Blocks;

abstract class Base {

	private $parser = null;

	/**
	 * Set current block parser
	 * 
	 * @param [type] $parser [description]
	 */
	public function set_parser( $parser ) {
		$this->parser = $parser;
	}

	/**
	 * Set current block parser
	 * 
	 * @param [type] $parser [description]
	 */
	public function get_parser() {
		return $this->parser;
	}

	/**
	 * Returns block name to register dynamic attributes for
	 *
	 * @return string
	 */
	abstract public function block_name();

	/**
	 * Returns attributes array
	 *
	 * @return array
	 */
	abstract public function get_attrs();

	/**
	 * Returns blocks attributes prepared to use in JS object
	 *
	 * @return array
	 */
	public function get_block_atts() {

		$raw_atts = $this->get_attrs();
		$result   = array();

		foreach ( $raw_atts as $attr ) {

			unset( $attr['replace_callback'], $attr['sanitize_callback'] );

			$result[] = $attr;
		}

		return $result;

	}

	/**
	 * Sanitize a dynamic value as post content.
	 *
	 * @param mixed $value  Dynamic value.
	 * @param array $attr   Dynamic attribute definition.
	 * @param object $parser Dynamic block parser.
	 * @return mixed
	 */
	public function sanitize_post_content( $value, $attr = array(), $parser = null ) {
		$parser = $parser ? $parser : $this->get_parser();

		return $parser ? $parser->kses( $value ) : $value;
	}

	/**
	 * Sanitize a dynamic value for an HTML attribute.
	 *
	 * @param mixed $value  Dynamic value.
	 * @param array $attr   Dynamic attribute definition.
	 * @param object $parser Dynamic block parser.
	 * @return mixed
	 */
	public function sanitize_attribute( $value, $attr = array(), $parser = null ) {
		$parser = $parser ? $parser : $this->get_parser();

		return $parser ? $parser->esc_attr( $value ) : $value;
	}

	/**
	 * Sanitize a dynamic URL value.
	 *
	 * @param mixed $value  Dynamic value.
	 * @param array $attr   Dynamic attribute definition.
	 * @param object $parser Dynamic block parser.
	 * @return mixed
	 */
	public function sanitize_url( $value, $attr = array(), $parser = null ) {
		$parser = $parser ? $parser : $this->get_parser();

		return $parser ? $parser->esc_url( $value ) : $value;
	}

	/**
	 * Returns new DOM parser instance for given content
	 *
	 * @param  string $content Content to parse
	 * @return DOM_Parser DOM_Parser
	 */
	public function get_parser_instance( $content = '' ) {

		if ( ! class_exists( __NAMESPACE__ . '\DOM_Parser' ) ) {
			require jet_engine()->blocks_views->component_path( 'dynamic-content/dom-parser.php' );
		}

		return new DOM_Parser( $content );
	}

	/**
	 * Find and replace block attribute with dynamic value in the block content
	 *
	 * @param  string $attr        Attribute name/key to find and replace
	 * @param  string $value       Dynamic value to insert
	 * @param  string $content     Block content
	 * @param  array  $block_attrs Parsed block attributes
	 * @return string - content with dynamic values applied
	 */
	public function replace_attr_content( $attr = null, $value = null, $content = '', $dynamic_attrs = array(), $parsed_attrs = array() ) {

		$raw_atts = $this->get_attrs();

		foreach ( $raw_atts as $attr_data ) {

			if ( $attr_data['attr'] !== $attr ) {
				continue;
			}

			if ( ! empty( $attr_data['replace_callback'] ) && is_callable( $attr_data['replace_callback'] ) ) {
				return call_user_func( 
					$attr_data['replace_callback'],
					$value,
					$content,
					$dynamic_attrs,
					$parsed_attrs
				);
			} elseif ( ! empty( $attr_data['replace'] ) ) {



				$parser                = $this->get_parser_instance( $content );
				$replace_data          = $attr_data['replace'];
				$replace_data['value'] = $value;

				return $parser->replace( $replace_data );

			}

		}

		return $content;
	}

}
