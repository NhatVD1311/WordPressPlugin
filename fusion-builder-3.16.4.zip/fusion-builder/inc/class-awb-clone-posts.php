<?php
/**
 * Avada Clone Posts
 *
 * @package Avada-Builder
 * @since 3.9
 */

/**
 * AWB Clone Posts class.
 *
 * @since 3.9
 */
class AWB_Clone_Posts {

	/**
	 * Class instance.
	 *
	 * @var AWB_Clone_Posts|null
	 */
	private static $instance = null;

	/**
	 * The post types that get the clone action when nothing else is set.
	 *
	 * @var array
	 */
	public static $default_post_types = [ 'post', 'page', 'avada_portfolio', 'avada_faq' ];

	/**
	 * Get the singleton instance.
	 *
	 * @since 3.9
	 * @return AWB_Clone_Posts
	 */
	public static function get_instance() {
		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new AWB_Clone_Posts();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 3.9
	 */
	public function __construct() {
		$fusion_settings       = class_exists( 'Fusion_Settings' ) ? awb_get_fusion_settings() : false;
		$cloning_posts_enabled = intval( $fusion_settings && '' !== $fusion_settings->get( 'cloning_posts' ) ? $fusion_settings->get( 'cloning_posts' ) : '0' );

		if ( $cloning_posts_enabled ) {
			add_filter( 'post_row_actions', 'AWB_Clone_Posts::add_clone_option_to_row', 10, 2 );
			add_filter( 'page_row_actions', 'AWB_Clone_Posts::add_clone_option_to_row', 10, 2 );
			add_action( 'admin_action_awb_clone_post', 'AWB_Clone_Posts::handle_clone_post' );
		}
	}

	/**
	 * Add clone action to post row.
	 *
	 * @since 3.9
	 * @param array   $actions The current actions for post.
	 * @param WP_Post $post The Post.
	 * @return array
	 */
	public static function add_clone_option_to_row( $actions, $post ) {
		if ( ! self::can_clone_post( $post ) ) {
			return $actions;
		}

		$url = self::get_clone_url( $post );

		$title_attr_args = [
			'post' => $post,
			'echo' => false,
		];
		/* translators: %s - A post/page title. */
		$aria_label    = wptexturize( sprintf( __( 'Clone "%s"', 'fusion-builder' ), the_title_attribute( $title_attr_args ) ) );
		$button_action = __( 'Clone', 'fusion-builder' );

		$actions['awb-clone'] = '<a href="' . esc_url( $url ) . '" aria-label="' . esc_attr( $aria_label ) . '">' . esc_html( $button_action ) . '</a>';

		return $actions;
	}

	/**
	 * Function that gets called when clone button is clicked.
	 *
	 * @since 3.9
	 * @return void
	 */
	public static function handle_clone_post() {
		$message = __( 'No post to clone or no permission.', 'fusion-builder' );
		if ( ! ( isset( $_GET['item'], $_GET['_awb_clone_post_nonce'], $_GET['action'] ) ) || ! check_admin_referer( 'awb_clone_post', '_awb_clone_post_nonce' ) ) {
			wp_die( esc_html( $message ) );
		}

		$post_id = (int) $_GET['item'];
		if ( ! is_numeric( $post_id ) || ! $post_id > 0 ) {
			wp_die( esc_html( $message ) );
		}

		$post = get_post( $post_id );
		if ( ! ( $post instanceof WP_Post ) ) {
			wp_die( esc_html( $message ) );
		}

		if ( ! self::can_clone_post( $post ) ) {
			wp_die( esc_html( $message ) );
		}

		self::clone_post( $post );

		$referer = fusion_get_referer();
		if ( $referer ) {
			wp_safe_redirect( $referer );
			exit;
		}
	}

	/**
	 * Duplicate a post.
	 *
	 * @since 3.9
	 * @param WP_Post $post The post to clone.
	 * @return void
	 */
	private static function clone_post( $post ) {
		$new_post = [];

		$new_post['post_type']    = $post->post_type;
		$new_post['post_content'] = $post->post_content;
		/* translators: The post title. */
		$new_post['post_title']     = sprintf( esc_attr__( '%s ( Cloned )', 'fusion-builder' ), $post->post_title );
		$new_post['post_excerpt']   = $post->post_excerpt;
		$new_post['comment_status'] = $post->comment_status;
		$new_post['ping_status']    = $post->ping_status;
		$new_post['post_password']  = $post->post_password;
		$new_post['to_ping']        = $post->to_ping;
		$new_post['post_parent']    = $post->post_parent;
		$new_post['menu_order']     = $post->menu_order;
		$new_post['post_mime_type'] = $post->post_mime_type;
		$new_post['page_template']  = $post->page_template;

		$new_post['post_category'] = $post->post_category;
		$new_post['tags_input']    = $post->tags_input;
		$new_post['tax_input']     = self::get_taxonomies_clone( $post );

		$new_post['post_status'] = 'draft';

		$new_post['meta_input'] = self::get_cloned_post_meta( $post );

		$new_post = apply_filters( 'awb_clone_post_to_insert', $new_post, $post );

		wp_insert_post( $new_post );
	}

	/**
	 * Helper to get post additional taxonomies.
	 *
	 * @since 3.9
	 * @param WP_Post $post The post to get all taxonomies.
	 * @return array
	 */
	private static function get_taxonomies_clone( $post ) {
		$clone_taxonomies = [];

		$post_taxonomies = get_object_taxonomies( $post );
		foreach ( $post_taxonomies as $post_taxonomy ) {
			$taxonomy_names = wp_get_object_terms( $post->ID, $post_taxonomy, [ 'fields' => 'ids' ] );
			if ( ! empty( $taxonomy_names ) ) {
				$clone_taxonomies[ $post_taxonomy ] = $taxonomy_names;
			}
		}

		return $clone_taxonomies;
	}

	/**
	 * Get the meta for the cloned element.
	 *
	 * @since 3.9
	 * @param WP_Post $post The post.
	 * @return array
	 */
	private static function get_cloned_post_meta( $post ) {
		$post_meta        = get_post_meta( $post->ID );
		$new_post_meta    = [];
		$ignore_meta_keys = apply_filters( 'awb_clone_post_ignored_meta_keys', [ '_edit_last', '_edit_lock', 'avada_post_views_count', 'avada_today_post_views_count', 'avada_post_views_count_today_date' ], $post );

		foreach ( $post_meta as $meta_key => $meta_value ) {
			if ( isset( $meta_value[0] ) && ! in_array( $meta_key, $ignore_meta_keys, true ) ) {
				$new_post_meta[ $meta_key ] = get_post_meta( $post->ID, $meta_key, true ); // needed to unserialize values.
			}
		}

		return $new_post_meta;
	}

	/**
	 * Get the url for the clone button.
	 *
	 * @since 3.9
	 * @param WP_Post $post The post.
	 * @return string
	 */
	private static function get_clone_url( $post ) {
		$args = [
			'_awb_clone_post_nonce' => wp_create_nonce( 'awb_clone_post' ),
			'item'                  => $post->ID,
			'action'                => 'awb_clone_post',
		];

		return add_query_arg( $args );
	}

	/**
	 * Check if a post can be cloned: its post type is enabled and the user may clone it.
	 *
	 * @since 3.16.3
	 * @param WP_Post $post The post object.
	 * @return bool
	 */
	public static function can_clone_post( $post ) {
		return in_array( $post->post_type, self::get_allowed_post_types(), true ) && self::user_can_clone_post( $post );
	}

	/**
	 * Check if user can clone a post. The clone copies the full post and its meta,
	 * so the user has to be able to edit the source and to create posts of its type.
	 * These are the post type's own capabilities, as custom post types don't map to a Role Manager area.
	 *
	 * @since 3.9
	 * @param object $post The post object.
	 * @return bool
	 */
	private static function user_can_clone_post( $post ) {
		$post_type_object = get_post_type_object( $post->post_type );

		if ( null === $post_type_object ) {
			return false;
		}

		return current_user_can( 'edit_post', $post->ID ) && current_user_can( $post_type_object->cap->create_posts );
	}

	/**
	 * Get the post types that get the clone action.
	 *
	 * @since 3.16.3
	 * @return array
	 */
	public static function get_allowed_post_types() {
		$fusion_settings = class_exists( 'Fusion_Settings' ) ? awb_get_fusion_settings() : false;
		$post_types      = $fusion_settings ? $fusion_settings->get( 'cloning_post_types' ) : '';

		if ( ! is_array( $post_types ) ) {
			$post_types = self::$default_post_types;
		}

		$post_types = array_values( array_filter( $post_types, [ __CLASS__, 'is_clonable_post_type' ] ) );

		return (array) apply_filters( 'awb_allowed_clone_post_types', $post_types );
	}

	/**
	 * Get the post types that can be selected for cloning, for the Global Options.
	 *
	 * @since 3.16.3
	 * @return array
	 */
	public static function get_post_type_choices() {
		$choices = [];

		// Avada's own post types set show_ui from the Role Manager, so public ones are included too.
		foreach ( get_post_types( [], 'objects' ) as $post_type => $post_type_object ) {
			if ( ( $post_type_object->show_ui || $post_type_object->public ) && self::is_clonable_post_type( $post_type ) ) {
				$choices[ $post_type ] = $post_type_object->labels->name;
			}
		}
		asort( $choices );

		return $choices;
	}

	/**
	 * Check if a post type can be cloned with a plain copy of the post, its meta and its terms.
	 * Post types that keep data in child posts or custom tables, or come with their own clone, can't.
	 *
	 * @since 3.16.3
	 * @param string $post_type The post type.
	 * @return bool
	 */
	public static function is_clonable_post_type( $post_type ) {
		$excluded = apply_filters(
			'awb_clone_excluded_post_types',
			[
				// Avada, these have their own clone.
				'fusion_template',
				'fusion_element',
				'fusion_tb_layout',
				'fusion_tb_section',
				'fusion_form',
				'awb_off_canvas',
				'fusion_icons',
				'awb_emails',

				// WooCommerce.
				'product',
				'product_variation',
				'shop_order',
				'shop_order_refund',
				'shop_order_placehold',
				'shop_coupon',
				'shop_subscription',

				// ACF.
				'acf-field-group',
				'acf-field',
				'acf-post-type',
				'acf-taxonomy',
				'acf-ui-options-page',

				// The Events Calendar and Event Tickets.
				'tribe_events',
				'tec_tc_order',
				'tribe_rsvp_tickets',
				'tec_tc_ticket',
				'tribe_tpp_orders',
				'tribe_tpp_tickets',
			]
		);

		return is_string( $post_type ) && 'attachment' !== $post_type && 0 !== strpos( $post_type, 'wp_' ) && ! in_array( $post_type, $excluded, true );
	}
}

new AWB_Clone_Posts();
