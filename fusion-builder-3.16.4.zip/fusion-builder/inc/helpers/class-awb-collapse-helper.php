<?php
/**
 * Shared logic for the Collapsible / Read More feature used by the
 * Container and Column elements: option defaults, option params, the clip
 * CSS variables, the built-in trigger markup, and the element attributes.
 *
 * @package fusion-builder
 * @since 7.15.6
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

if ( ! class_exists( 'AWB_Collapse_Helper' ) ) {

	/**
	 * Collapsible feature helper.
	 *
	 * @since 7.15.6
	 */
	class AWB_Collapse_Helper {

		/**
		 * Whether the collapsible feature is enabled for the given args.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return bool
		 */
		public static function is_enabled( $args ) {
			return isset( $args['collapse'] ) && '' !== $args['collapse'];
		}

		/**
		 * Screen sizes the element is collapsible on (subset of small/medium/large).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return array
		 */
		public static function get_screens( $args ) {
			if ( ! self::is_enabled( $args ) ) {
				return [];
			}
			return array_filter( array_map( 'trim', explode( ',', (string) $args['collapse'] ) ) );
		}

		/**
		 * Whether the built-in button overlays the collapsed content (vs. below it).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return bool
		 */
		public static function is_overlay( $args ) {
			return self::is_enabled( $args ) && isset( $args['collapse_button_position'] ) && 'overlay' === $args['collapse_button_position'];
		}

		/**
		 * Option defaults, merged into each element's get_element_defaults().
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @return array
		 */
		public static function get_defaults() {
			return [
				'collapse'                    => '',
				'collapsed_height'            => '',
				'collapsed_height_medium'     => '',
				'collapsed_height_small'      => '',
				'collapse_trigger'            => 'button',
				'collapse_more_text'          => 'Read More',
				'collapse_less_text'          => 'Read Less',
				'collapse_less_button'        => 'yes',
				'collapse_button_position'    => 'below',
				'collapse_button_align'       => 'center',
				'collapse_button_offset'      => '',
				'collapse_speed'              => '400',
				'collapse_fade'               => 'none',
				'collapse_fade_color'         => '#ffffff',
				'collapse_fade_height'        => '',
				'collapse_fade_height_medium' => '',
				'collapse_fade_height_small'  => '',
			];
		}	

		/**
		 * Option params for the element options.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args The placeholder arguments.
		 * @return array
		 */
		public static function get_params( $args ) {
			$element = isset( $args['element'] ) ? $args['element'] : '';
			$el      = 'column' === $element ? esc_attr__( 'column', 'fusion-builder' ) : esc_attr__( 'container', 'fusion-builder' );
			$fb_edit = isset( $_GET['fb-edit'] ); // phpcs:ignore WordPress.Security.NonceVerification

			$dep_on = [
				[
					'element'  => 'collapse',
					'value'    => '',
					'operator' => '!=',
				],
			];

			return [
				[
					'type'        => 'checkbox_button_set',
					'heading'     => esc_attr__( 'Collapsible / Read More', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Clip the %s to a set height on the chosen screen sizes and reveal the rest with a "Read More" toggle. Leave all unchecked to disable.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse',
					'default'     => '',
					'value'       => [
						'small'  => $fb_edit ? '<span class="fusiona-mobile"></span>|' . esc_attr__( 'Small Screen', 'fusion-builder' ) : esc_attr__( 'Small Screen', 'fusion-builder' ),
						'medium' => $fb_edit ? '<span class="fusiona-tablet"></span>|' . esc_attr__( 'Medium Screen', 'fusion-builder' ) : esc_attr__( 'Medium Screen', 'fusion-builder' ),
						'large'  => $fb_edit ? '<span class="fusiona-desktop"></span>|' . esc_attr__( 'Large Screen', 'fusion-builder' ) : esc_attr__( 'Large Screen', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
				],
				[
					'type'        => 'textfield',
					'heading'     => esc_attr__( 'Collapsed Height', 'fusion-builder' ),
					'description' => esc_attr__( 'The visible height when collapsed. Enter a value (px, %, vh, em, rem). Leave empty to use the default.', 'fusion-builder' ),
					'param_name'  => 'collapsed_height',
					'value'       => '',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => $dep_on,
					'responsive'  => [
						'state'             => 'large',
						'additional_states' => [ 'medium', 'small' ],
					],
				],
				[
					'type'        => 'radio_button_set',
					'heading'     => esc_attr__( 'Collapsed Fade Effect', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Add a fade at the bottom of the collapsed area. "To Transparent" dissolves the content itself, revealing whatever is behind it (and also fades the %1$s\'s own background/border) — best over background images, gradients or transparent sections. "To Color" lays a gradient over the content toward a chosen solid color, keeping the background intact — best when blending into a known background color.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_fade',
					'default'     => 'none',
					'value'       => [
						'none'  => esc_attr__( 'None', 'fusion-builder' ),
						'fade'  => esc_attr__( 'To Transparent', 'fusion-builder' ),
						'color' => esc_attr__( 'To Color', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => $dep_on,
				],
				[
					'type'        => 'colorpickeralpha',
					'heading'     => esc_attr__( 'Collapsed Fade Color', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'The color the content fades into. Set this to match the background behind the %s.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_fade_color',
					'value'       => '#ffffff',
					'default'     => '#ffffff',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_fade',
							'value'    => 'color',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'textfield',
					'heading'     => esc_attr__( 'Collapsed Fade Height', 'fusion-builder' ),
					'description' => esc_attr__( 'Height of the fade at the bottom of the collapsed area, e.g. 60px. Leave empty for the default.', 'fusion-builder' ),
					'param_name'  => 'collapse_fade_height',
					'value'       => '',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'responsive'  => [
						'state'             => 'large',
						'additional_states' => [ 'medium', 'small' ],
					],
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_fade',
							'value'    => 'none',
							'operator' => '!=',
						],
					],
				],
				[
					'type'        => 'radio_button_set',
					'heading'     => esc_attr__( 'Collapse Trigger', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Use the built-in button, or control the toggle from any external link/button via the "Toggle/Open/Close Collapse" dynamic data link actions (target this %s by its Element ID).', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_trigger',
					'default'     => 'button',
					'value'       => [
						'button'   => esc_attr__( 'Built-in Button', 'fusion-builder' ),
						'external' => esc_attr__( 'External Link', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => $dep_on,
				],
				[
					'type'        => 'textfield',
					'heading'     => esc_attr__( 'Expand Button Text', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Text shown on the button while the %s is collapsed.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_more_text',
					'value'       => esc_attr__( 'Read More', 'fusion-builder' ),
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'radio_button_set',
					'heading'     => esc_attr__( 'Collapse Button', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Show a button to collapse the %s again after it has been expanded. Set to No for a one-way reveal — the button fades out once expanded.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_less_button',
					'default'     => 'yes',
					'value'       => [
						'yes' => esc_attr__( 'Yes', 'fusion-builder' ),
						'no'  => esc_attr__( 'No', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'textfield',
					'heading'     => esc_attr__( 'Collapse Button Text', 'fusion-builder' ),
					/* translators: %s: element type (column/container). */
					'description' => sprintf( esc_attr__( 'Text shown on the button while the %s is expanded.', 'fusion-builder' ), $el ),
					'param_name'  => 'collapse_less_text',
					'value'       => esc_attr__( 'Read Less', 'fusion-builder' ),
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
						[
							'element'  => 'collapse_less_button',
							'value'    => 'yes',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'radio_button_set',
					'heading'     => esc_attr__( 'Expand/Collapse Button Position', 'fusion-builder' ),
					'description' => esc_attr__( 'Where the built-in button(s) sit(s). "Below Content" places it in its own row beneath the collapsed area. "Overlay On Content" floats it over the bottom of the collapsed area (on top of the fade).', 'fusion-builder' ),
					'param_name'  => 'collapse_button_position',
					'default'     => 'below',
					'value'       => [
						'below'   => esc_attr__( 'Below Content', 'fusion-builder' ),
						'overlay' => esc_attr__( 'Overlay On Content', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'radio_button_set',
					'heading'     => esc_attr__( 'Expand/Collapse Button Alignment', 'fusion-builder' ),
					'description' => esc_attr__( 'Horizontal alignment of the built-in button(s).', 'fusion-builder' ),
					'param_name'  => 'collapse_button_align',
					'default'     => 'center',
					'value'       => [
						'left'   => esc_attr__( 'Left', 'fusion-builder' ),
						'center' => esc_attr__( 'Center', 'fusion-builder' ),
						'right'  => esc_attr__( 'Right', 'fusion-builder' ),
					],
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'textfield',
					'heading'     => esc_attr__( 'Expand/Collapse Button Offset', 'fusion-builder' ),
					'description' => esc_attr__( 'Fine-tune the button(s) position. With "Below Content" it sets the gap above the button(s). With "Overlay On Content" it lifts the button(s) up from the bottom edge. Note: "To Transparent" fades via a mask, so the button only stays fully visible if the offset is at least the Fade Height. Enter a value with a unit, e.g. 20px.', 'fusion-builder' ),
					'param_name'  => 'collapse_button_offset',
					'value'       => '',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => [
						[
							'element'  => 'collapse',
							'value'    => '',
							'operator' => '!=',
						],
						[
							'element'  => 'collapse_trigger',
							'value'    => 'button',
							'operator' => '==',
						],
					],
				],
				[
					'type'        => 'range',
					'heading'     => esc_attr__( 'Expand/Collapse Animation Speed', 'fusion-builder' ),
					'description' => esc_attr__( 'Duration of the expand/collapse animation in milliseconds.', 'fusion-builder' ),
					'param_name'  => 'collapse_speed',
					'value'       => '400',
					'min'         => '0',
					'max'         => '5000',
					'step'        => '50',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'dependency'  => $dep_on,
				],
			];
		}

		/**
		 * Resolve the element id a trigger/link targets: the user's Element ID
		 * when set, otherwise the supplied auto-generated id.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array  $args    Element args.
		 * @param string $auto_id Fallback id.
		 * @return string
		 */
		public static function resolve_target_id( $args, $auto_id ) {
			return ! empty( $args['id'] ) ? $args['id'] : $auto_id;
		}

		/**
		 * Inline clip CSS variables (height + speed) for the clipped content element.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_clip_styles( $args ) {
			$sanitize = fusion_library()->sanitize;
			$style    = '';
			$map      = [
				'collapsed_height'        => '--awb-collapsed-height',
				'collapsed_height_medium' => '--awb-collapsed-height-medium',
				'collapsed_height_small'  => '--awb-collapsed-height-small',
			];

			foreach ( $map as $arg => $var ) {
				if ( isset( $args[ $arg ] ) && '' !== $args[ $arg ] ) {
					$style .= $var . ':' . $sanitize->get_value_with_unit( $args[ $arg ] ) . ';';
				}
			}

			$speed  = isset( $args['collapse_speed'] ) ? intval( $args['collapse_speed'] ) : 400;
			$speed  = 0 < $speed ? $speed : 400;
			$style .= '--awb-collapse-speed:' . $speed . 'ms;';

			return $style;
		}

		/**
		 * Inline fade CSS variables (height + color) for whichever element renders
		 * the fade — the inner content for a column, the outer root for a container
		 * (whose background/pattern live on the root, not the content).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_fade_styles( $args ) {
			if ( '' === self::get_fade( $args ) ) {
				return '';
			}

			$sanitize = fusion_library()->sanitize;
			$style    = '';
			$heights  = [
				'collapse_fade_height'        => '--awb-collapse-fade-height',
				'collapse_fade_height_medium' => '--awb-collapse-fade-height-medium',
				'collapse_fade_height_small'  => '--awb-collapse-fade-height-small',
			];

			foreach ( $heights as $arg => $var ) {
				if ( isset( $args[ $arg ] ) && '' !== $args[ $arg ] ) {
					$style .= $var . ':' . $sanitize->get_value_with_unit( $args[ $arg ] ) . ';';
				}
			}

			if ( 'color' === $args['collapse_fade'] && '' !== $args['collapse_fade_color'] ) {
				$style .= '--awb-collapse-fade-color:' . $args['collapse_fade_color'] . ';';
			}

			return $style;
		}

		/**
		 * Inline CSS variables for the clipped content element (clip + fade). Used
		 * where the same element both clips and renders the fade (the column).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_content_styles( $args ) {
			return self::get_clip_styles( $args ) . self::get_fade_styles( $args );
		}

		/**
		 * The button-offset CSS variable, or '' when unset. Drives the trigger's
		 * `bottom` (overlay) / `margin-top` (below).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_offset_styles( $args ) {
			if ( ! isset( $args['collapse_button_offset'] ) || '' === $args['collapse_button_offset'] ) {
				return '';
			}
			return '--awb-collapse-button-offset:' . fusion_library()->sanitize->get_value_with_unit( $args['collapse_button_offset'] ) . ';';
		}

		/**
		 * The fade mode for the data attribute, or '' when off.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_fade( $args ) {
			return ( isset( $args['collapse_fade'] ) && 'none' !== $args['collapse_fade'] ) ? $args['collapse_fade'] : '';
		}

		/**
		 * Add collapsible markers (class, speed, id) to the OUTER element attrs.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @param array $attr Outer element attributes.
		 * @return array
		 */
		public static function outer_attributes( $args, $attr ) {
			if ( ! self::is_enabled( $args ) ) {
				return $attr;
			}

			$speed                           = isset( $args['collapse_speed'] ) ? intval( $args['collapse_speed'] ) : 400;
			$attr['class']                   = ( isset( $attr['class'] ) ? $attr['class'] : '' ) . ' awb-collapsible';
			$attr['data-awb-collapse-speed'] = (string) ( 0 < $speed ? $speed : 400 );

			if ( self::is_overlay( $args ) ) {
				$attr['class'] .= ' awb-collapse-overlay';
			}

			// Per-breakpoint: mark the screens it is NOT collapsible on so the media CSS
			// can neutralise the clip there (mirrors the fusion-no-*-visibility pattern).
			$screens = self::get_screens( $args );
			foreach ( [ 'small', 'medium', 'large' ] as $bp ) {
				if ( ! in_array( $bp, $screens, true ) ) {
					$attr['class'] .= ' awb-collapse-not-' . $bp;
				}
			}

			// Button offset var — inherited by the trigger when it lives inside the root.
			$offset = self::get_offset_styles( $args );
			if ( '' !== $offset ) {
				$attr['style'] = ( isset( $attr['style'] ) ? $attr['style'] : '' ) . $offset;
			}

			// Addressable by the trigger / external link actions.
			if ( empty( $attr['id'] ) && ! empty( $args['collapse_target_id'] ) ) {
				$attr['id'] = esc_attr( $args['collapse_target_id'] );
			}

			return $attr;
		}

		/**
		 * Add clip markers (class, style vars, fade) to the CONTENT element attrs.
		 * Used where the clipped element is an existing wrapper (e.g. the column).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @param array $attr Content element attributes.
		 * @return array
		 */
		public static function content_attributes( $args, $attr ) {
			if ( ! self::is_enabled( $args ) ) {
				return $attr;
			}

			$attr['class'] = ( isset( $attr['class'] ) ? $attr['class'] : '' ) . ' awb-collapsible-content';

			$style = self::get_content_styles( $args );
			if ( '' !== $style ) {
				$attr['style'] = ( isset( $attr['style'] ) ? $attr['style'] : '' ) . $style;
			}

			$fade = self::get_fade( $args );
			if ( '' !== $fade ) {
				$attr['data-awb-collapse-fade'] = $fade;
			}

			return $attr;
		}

		/**
		 * Clip-only style attribute string for the container's inner clip div. The
		 * fade goes on the root instead (see root_fade_attributes()).
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function content_attr_string( $args ) {
			$out   = '';
			$style = self::get_clip_styles( $args );
			if ( '' !== $style ) {
				$out .= ' style="' . esc_attr( $style ) . '"';
			}

			return $out;
		}

		/**
		 * Add the fade markers (data attr + fade vars) to the container root, so the
		 * mask/overlay covers the section bg + pattern/mask, not just the inner content.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @param array $attr Root element attributes.
		 * @return array
		 */
		public static function root_fade_attributes( $args, $attr ) {
			$fade = self::get_fade( $args );
			if ( ! self::is_enabled( $args ) || '' === $fade ) {
				return $attr;
			}

			$attr['data-awb-collapse-fade'] = $fade;

			$style = self::get_fade_styles( $args );
			if ( '' !== $style ) {
				$attr['style'] = ( isset( $attr['style'] ) ? $attr['style'] : '' ) . $style;
			}

			return $attr;
		}

		/**
		 * Default themed button class list, built from the global button options.
		 *
		 * Mirrors how the Content Boxes / Tagline elements render a themed button
		 * (hand-built classes rather than the full Button element) so the markup
		 * can be produced identically in PHP and in the front-end builder JS.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @return string
		 */
		public static function get_button_classes() {
			$settings = awb_get_fusion_settings();
			$type     = strtolower( (string) $settings->get( 'button_type' ) );
			$shape    = strtolower( (string) $settings->get( 'button_shape' ) );

			$classes = 'awb-collapse-trigger fusion-button button-default fusion-button-default-size';
			if ( '' !== $shape ) {
				$classes .= ' button-' . $shape;
			}
			if ( '' !== $type ) {
				$classes .= ' button-' . $type;
			}

			return $classes;
		}

		/**
		 * Markup for the built-in trigger, or '' when the trigger is external.
		 *
		 * A real <button> with the theme's default button classes (see
		 * get_button_classes()); the JS toggles the closest collapsible.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @param array $args Element args.
		 * @return string
		 */
		public static function get_button( $args, $detached = false ) {
			if ( ! self::is_enabled( $args ) || 'button' !== $args['collapse_trigger'] ) {
				return '';
			}

			$align     = in_array( $args['collapse_button_align'], [ 'left', 'center', 'right' ], true ) ? $args['collapse_button_align'] : 'center';
			$more_text = '' !== $args['collapse_more_text'] ? $args['collapse_more_text'] : esc_html__( 'Read More', 'fusion-builder' );
			$wrap_cls  = 'awb-collapse-trigger-wrapper awb-collapse-align-' . esc_attr( $align );

			// One-way reveal: mark the wrapper so it fades out once expanded.
			if ( isset( $args['collapse_less_button'] ) && 'no' === $args['collapse_less_button'] ) {
				$wrap_cls .= ' awb-collapse-no-less';
			}

			// Offset is normally inherited from the root; a detached button (container
			// "below", rendered outside .fusion-fullwidth) is a sibling, so inline it.
			$wrap_style = '';
			if ( $detached ) {
				$offset = self::get_offset_styles( $args );
				if ( '' !== $offset ) {
					$wrap_style = ' style="' . esc_attr( $offset ) . '"';
				}
			}

			return '<div class="' . $wrap_cls . '"' . $wrap_style . ' data-more-text="' . esc_attr( $args['collapse_more_text'] ) . '" data-less-text="' . esc_attr( $args['collapse_less_text'] ) . '">' .
				'<button type="button" class="' . esc_attr( self::get_button_classes() ) . '" aria-expanded="false">' .
				'<span class="fusion-button-text">' . esc_html( $more_text ) . '</span>' .
				'</button></div>';
		}

		/**
		 * Enqueue the toggle script when the feature is in use.
		 *
		 * @static
		 * @access public
		 * @since 7.15.6
		 * @return void
		 */
		public static function enqueue_script() {
			Fusion_Dynamic_JS::enqueue_script( 'awb-collapse' );
		}
	}
}
