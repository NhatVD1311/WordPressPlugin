<?php // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
/**
 * Handles the database table manipulation.
 *
 * @package fusion-builder
 * @since 3.1
 */

/**
 * Handles the database table.
 *
 * @since 3.1
 */
class Fusion_Form_DB {

	/**
	 * The object cache group.
	 *
	 * @since 3.16.3
	 * @var string
	 */
	const CACHE_GROUP = 'awb_forms_cache';

	/**
	 * The Constructor.
	 *
	 * @since 3.1
	 * @access public
	 */
	public function __construct() {
	}

	/**
	 * Run $wpdb->query().
	 *
	 * Used for writes, so the result is never cached and cached reads are invalidated.
	 *
	 * @access public
	 * @since 3.1
	 * @param string $query The query we want to run.
	 * @return int|bool Returns the query results.
	 */
	public function query( $query ) {
		global $wpdb;

		$result = $wpdb->query( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		self::invalidate_cache();

		return $result;
	}

	/**
	 * Invalidate all cached queries, by changing the cache key salt.
	 * Persistent object caches keep the group, so every write to the form tables has to call this.
	 *
	 * @static
	 * @access public
	 * @since 3.16.3
	 * @return void
	 */
	public static function invalidate_cache() {
		wp_cache_delete( 'last_changed', self::CACHE_GROUP );
	}

	/**
	 * Get cached $wpdb->get_var().
	 *
	 * An alias of the get_cached_query abstraction.
	 *
	 * @access public
	 * @since 3.1
	 * @param string $query The query we want to cache.
	 * @return mixed Returns the query results.
	 */
	public function get_var( $query ) {
		return $this->get_cached_query( 'get_var', $query );
	}

	/**
	 * Get cached $wpdb->get_results().
	 *
	 * An alias of the get_cached_query abstraction.
	 *
	 * @access public
	 * @since 3.1
	 * @param string $query The query we want to cache.
	 * @return mixed Returns the query results.
	 */
	public function get_results( $query ) {
		return $this->get_cached_query( 'get_results', $query );
	}

	/**
	 * Get cached query.
	 *
	 * @access public
	 * @since 3.1
	 * @param string $method The $wpdb method we want to run.
	 * @param string $query  The query we want to cache.
	 * @return mixed Returns the query results.
	 */
	public function get_cached_query( $method, $query ) {
		global $wpdb;

		// Writes are never cached.
		if ( 'get_var' !== $method && 'get_results' !== $method ) {
			return $this->query( $query );
		}

		// Build a unique cache key for this query, salted with the time of the last write.
		$cache_key = "{$method}_" . md5( $query ) . ':' . wp_cache_get_last_changed( self::CACHE_GROUP );

		// Check if we have a cached result for this query.
		$result = wp_cache_get( $cache_key, self::CACHE_GROUP );

		// No cache was found, run the query and cache it.
		if ( false === $result ) {
			if ( 'get_var' === $method ) {
				$result = $wpdb->get_var( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			} else {
				$result = $wpdb->get_results( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			}

			// Set the cache.
			wp_cache_set( $cache_key, $result, self::CACHE_GROUP );
		}

		return $result;
	}
}
