<?php
/**
 * Shared base for the navigation list elements.
 *
 * @package fusion-builder
 * @since 3.16.2
 */

if ( ! class_exists( 'AWB_Nav_List_Element' ) ) {

	/**
	 * Base class for elements that render a queried set of links as a nested
	 * list, as a native select, or as both with a responsive swap.
	 *
	 * Subclasses supply the items and a handful of labels. Everything past that
	 * -- the tree, the markup, the styling vars and the assets -- lives here, so
	 * the two elements cannot drift apart.
	 *
	 * @package fusion-builder
	 * @since 3.16.2
	 */
	abstract class AWB_Nav_List_Element extends Fusion_Element {

		/**
		 * The shortcode name.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @var string
		 */
		protected $shortcode = '';

		/**
		 * The BEM block, used for every class name and every asset path.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @var string
		 */
		protected $block = '';

		/**
		 * The param prefix of the secondary text shown next to a label.
		 *
		 * Categories calls it the count, the post list calls it the meta. It
		 * drives the param names, the CSS var names and the element class.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @var string
		 */
		protected $meta_param = 'meta';

		/**
		 * The element counter.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @var int
		 */
		protected $element_counter = 1;

		/**
		 * The IDs to mark as current, cached per instance.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @var array|null
		 */
		protected $current_ids = null;

		/**
		 * Constructor.
		 *
		 * @access public
		 * @since 3.16.2
		 */
		public function __construct() {
			parent::__construct();

			add_filter( 'fusion_attr_' . $this->block . '-shortcode', [ $this, 'attr' ] );

			add_shortcode( $this->shortcode, [ $this, 'render' ] );

			// Ajax mechanism for query related part.
			add_action( 'wp_ajax_get_' . $this->shortcode, [ $this, 'ajax_query' ] );
		}

		/**
		 * Gets the items to render, in flat order.
		 *
		 * Each item is an array with the 'id', 'parent', 'label', 'url', 'meta',
		 * 'image' and 'object' keys. An empty 'url' means the item has no link:
		 * it is skipped in the select and rendered as a dead anchor in the list,
		 * which is what the term version has always done.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return array
		 */
		abstract protected function get_items();

		/**
		 * Gets the IDs that should be marked as current.
		 *
		 * Only called when highlighting is on, and only once per instance.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return array
		 */
		abstract protected function get_current_item_ids();

		/**
		 * Gets the URL used for the "all" item.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		abstract protected function get_all_link_url();

		/**
		 * Gets the placeholder copy shown when the query comes back empty.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		abstract protected function get_empty_message();

		/**
		 * Gets the default label of the empty first select option.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		abstract protected function get_select_default_label();

		/**
		 * Element specific wrapper classes, each with a leading space.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		protected function get_extra_classes() {
			return '';
		}

		/**
		 * Gets the taxonomy of a post type that fits a list of terms best.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param string $post_type  The post type name.
		 * @param array  $taxonomies The taxonomies to pick from, keyed by name.
		 * @return string
		 */
		protected function get_post_type_taxonomy( $post_type, $taxonomies ) {
			$best  = '';
			$score = 0;

			// No taxonomy is marked as the main one, so they are ranked. Hierarchical alone is
			// not enough: products have brands next to categories, and those are a tree too.
			foreach ( get_object_taxonomies( $post_type ) as $name ) {
				if ( ! isset( $taxonomies[ $name ] ) ) {
					continue;
				}

				$rank = 1;

				if ( $taxonomies[ $name ]->hierarchical ) {
					$rank = 2;
				}

				// Named as the categories of its post type: product_cat, portfolio_category.
				if ( false !== strpos( $name, 'categor' ) || '_cat' === substr( $name, -4 ) ) {
					$rank = 3;
				}

				if ( 'category' === $name ) {
					$rank = 4;
				}

				if ( $rank > $score ) {
					$score = $rank;
					$best  = $name;
				}
			}

			return $best;
		}

		/**
		 * Resolves the element specific args.
		 *
		 * Runs after the defaults are set and before the shared guards, so a
		 * subclass can rewrite args that everything downstream reads.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return void
		 */
		protected function set_element_args() {}

		/**
		 * Sets the args from the attributes.
		 *
		 * @access public
		 * @since 3.16.2
		 * @param array $args Element attributes.
		 * @return void
		 */
		public function set_args( $args ) {
			$this->defaults = static::get_element_defaults();
			$this->args     = FusionBuilder::set_shortcode_defaults( $this->defaults, $args, $this->shortcode );

			// Reset the per instance cache, the query can differ between instances.
			$this->current_ids = null;

			$this->set_element_args();

			// Nesting only makes sense in a stacked list.
			if ( 'inline' === $this->args['layout'] && 'list' === $this->args['display_type'] ) {
				$this->args['hierarchical'] = 'no';
			}
		}

		/**
		 * Render the shortcode.
		 *
		 * @access public
		 * @since 3.16.2
		 * @param  array  $args    Shortcode parameters.
		 * @param  string $content Content between shortcode.
		 * @return string          HTML output.
		 */
		public function render( $args, $content = '' ) {

			$this->set_element_id( $this->element_counter );

			$this->set_args( $args );

			$html = '<div ' . FusionBuilder::attributes( $this->block . '-shortcode' ) . '>' . $this->get_element_html() . '</div>';

			$this->element_counter++;

			$this->on_render();

			return apply_filters( $this->shortcode . '_content', $html, $args );
		}

		/**
		 * Builds the attributes array.
		 *
		 * @access public
		 * @since 3.16.2
		 * @return array
		 */
		public function attr() {

			$attr = [
				'class' => $this->block . ' ' . $this->block . '-' . $this->element_id,
				'style' => '',
			];

			$attr['class'] .= ' ' . $this->block . '--' . $this->args['display_type'];

			if ( 'list' === $this->args['display_type'] ) {
				$attr['class'] .= ' ' . $this->block . '--' . $this->args['layout'];

				if ( 'yes' === $this->args['hierarchical'] ) {
					$attr['class'] .= ' ' . $this->block . '--hierarchical ' . $this->block . '--subs-' . $this->args['sub_display'];
					$attr['class'] .= ' ' . $this->block . '--indent-' . $this->args['sub_indent_style'];

					if ( 'yes' === $this->args['sub_grouped'] ) {
						$attr['class'] .= ' ' . $this->block . '--subs-grouped';
					}

					// With "space between" the toggle is already at the edge, and moving the
					// alignment to the row would pull the meta away from it.
					if ( 'content' === $this->args['toggle_position'] && 'accordion' === $this->args['sub_display'] && 'space-between' !== $this->args['item_align'] ) {
						$attr['class'] .= ' ' . $this->block . '--toggle-content';
					}
				}

				if ( 'never' !== $this->args['collapse_to_select'] ) {
					$attr['class'] .= ' ' . $this->block . '--collapse-' . $this->args['collapse_to_select'];
				}
			}

			if ( '' !== $this->args['icon'] ) {
				$attr['class'] .= ' ' . $this->block . '--has-icon';
			}

			if ( 'yes' === $this->args['show_image'] ) {
				$attr['class'] .= ' ' . $this->block . '--has-image';
			}

			$attr['class'] .= $this->get_extra_classes();

			if ( $this->args['id'] ) {
				$attr['id'] = $this->args['id'];
			}

			if ( $this->args['class'] ) {
				$attr['class'] .= ' ' . $this->args['class'];
			}

			$attr = fusion_builder_visibility_atts( $this->args['hide_on_mobile'], $attr );

			if ( $this->args['animation_type'] ) {
				$attr = Fusion_Builder_Animation_Helper::add_animation_attributes( $this->args, $attr );
			}

			$attr['style'] .= $this->get_style_variables();

			return $attr;
		}

		/**
		 * Gets the query data for the live editor.
		 *
		 * @access public
		 * @since 3.16.2
		 * @param array $defaults An array of defaults.
		 * @return void
		 */
		public function ajax_query( $defaults ) {
			check_ajax_referer( 'fusion_load_nonce', 'fusion_load_nonce' );

			// From Ajax Request.
			if ( isset( $_POST['model'] ) && ! apply_filters( 'fusion_builder_live_request', false ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$defaults = wp_unslash( $_POST['model']['params'] ); // phpcs:ignore WordPress.Security
				add_filter( 'fusion_builder_live_request', '__return_true' );
			}

			$this->set_args( $defaults );

			echo wp_json_encode( [ 'output' => $this->get_element_html() ] );
			wp_die();
		}

		/**
		 * Builds the full inner HTML of the element.
		 *
		 * @access public
		 * @since 3.16.2
		 * @return string
		 */
		public function get_element_html() {
			$items = $this->get_items();

			if ( empty( $items ) ) {
				return sprintf( '<div class="fusion-builder-placeholder">%s</div>', esc_html( $this->get_empty_message() ) );
			}

			$tree = $this->build_tree( $items );

			if ( empty( $tree ) ) {
				return sprintf( '<div class="fusion-builder-placeholder">%s</div>', esc_html( $this->get_empty_message() ) );
			}

			$number = (int) $this->args['number'];
			if ( 0 < $number ) {
				$tree = array_slice( $tree, 0, $number );
			}

			$html = '';

			// The list is always rendered unless the element is a pure select.
			if ( 'select' !== $this->args['display_type'] ) {
				$html .= $this->get_list_html( $tree );
			}

			// The select is rendered for the select type and for the responsive collapse.
			if ( 'select' === $this->args['display_type'] || 'never' !== $this->args['collapse_to_select'] ) {
				$html .= $this->get_select_html( $tree );
			}

			return $html;
		}

		/**
		 * Gets the IDs that should be marked as current, cached.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return array
		 */
		protected function get_current_ids() {
			if ( null !== $this->current_ids ) {
				return $this->current_ids;
			}

			$this->current_ids = [];

			if ( 'yes' !== $this->args['highlight_current'] ) {
				return $this->current_ids;
			}

			$this->current_ids = $this->get_current_item_ids();

			return $this->current_ids;
		}

		/**
		 * Builds a tree out of a flat list of items.
		 *
		 * Items whose parent is not part of the result set are treated as roots,
		 * so a scoped query (children of X) still renders from its own top level.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $items The flat list of items.
		 * @return array
		 */
		protected function build_tree( $items ) {
			$flat = [];

			foreach ( $items as $item ) {
				$flat[ $item['id'] ] = [
					'item'     => $item,
					'children' => [],
				];
			}

			if ( 'yes' !== $this->args['hierarchical'] ) {
				return array_values( $flat );
			}

			$tree = [];

			foreach ( $flat as $id => $node ) {
				$parent = (int) $node['item']['parent'];

				if ( $parent && isset( $flat[ $parent ] ) ) {
					$flat[ $parent ]['children'][] = &$flat[ $id ];
				} else {
					$tree[] = &$flat[ $id ];
				}
			}

			unset( $node );

			return $tree;
		}

		/**
		 * Builds the list markup.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $tree The item tree.
		 * @return string
		 */
		protected function get_list_html( $tree ) {
			$html = '<ul class="' . $this->block . '__list">';

			if ( 'yes' === $this->args['show_all_link'] ) {
				$html .= $this->get_all_link_html();
			}

			$html .= $this->get_items_html( $tree, 1 );
			$html .= '</ul>';

			return $html;
		}

		/**
		 * Recursively builds the list items.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $nodes The tree nodes.
		 * @param int   $depth The current depth, starting at 1.
		 * @return string
		 */
		protected function get_items_html( $nodes, $depth ) {
			$max_depth = (int) $this->args['max_depth'];
			$html      = '';

			foreach ( $nodes as $node ) {
				$item     = $node['item'];
				$children = $node['children'];
				$classes  = [ $this->block . '__item' ];

				$has_children = ! empty( $children ) && ( 0 === $max_depth || $depth < $max_depth );
				$state        = $this->get_item_state( $item, $children );

				if ( $has_children ) {
					$classes[] = $this->block . '__item--has-children';
				}

				if ( $state ) {
					$classes[] = $this->block . '__item--' . $state;
				}

				$is_accordion = $has_children && 'accordion' === $this->args['sub_display'] && 'yes' === $this->args['hierarchical'];
				$is_open      = 'current' === $state || 'current-ancestor' === $state;

				if ( $is_accordion && $is_open ) {
					$classes[] = $this->block . '__item--open';
				}

				// The shared classes are what the frontend script binds to, so the
				// two elements can run off one file.
				$classes[] = 'awb-nav-list__item';

				// The depth drives the indentation when the item background spans the full width.
				$depth_style = 1 < $depth ? ' style="--awb-depth:' . ( $depth - 1 ) . ';"' : '';

				$row_class = $is_accordion ? $this->block . '__row ' . $this->block . '__row--has-toggle awb-nav-list__row' : $this->block . '__row awb-nav-list__row';

				$html .= '<li class="' . esc_attr( implode( ' ', $classes ) ) . '"' . $depth_style . '>';
				$html .= '<div class="' . esc_attr( $row_class ) . '">';
				$html .= $this->get_link_html( $item, 'current' === $state );

				if ( $is_accordion ) {
					$html .= sprintf(
						'<button type="button" class="%1$s__toggle awb-nav-list__toggle" aria-expanded="%2$s" aria-label="%3$s"><i class="awb-icon-angle-down" aria-hidden="true"></i></button>',
						$this->block,
						$is_open ? 'true' : 'false',
						/* translators: The item label. */
						esc_attr( sprintf( __( 'Toggle sub items of %s', 'fusion-builder' ), $item['label'] ) )
					);
				}

				$html .= '</div>';

				if ( $has_children ) {
					$html .= '<ul class="' . $this->block . '__sub-list awb-nav-list__sub-list">';
					$html .= $this->get_items_html( $children, $depth + 1 );
					$html .= '</ul>';
				}

				$html .= '</li>';
			}

			return $html;
		}

		/**
		 * Gets the highlight state of an item.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $item     The item.
		 * @param array $children The child nodes of the item.
		 * @return string Either 'current', 'current-ancestor' or an empty string.
		 */
		protected function get_item_state( $item, $children ) {
			$current_ids = $this->get_current_ids();

			if ( empty( $current_ids ) ) {
				return '';
			}

			if ( in_array( (int) $item['id'], array_map( 'absint', $current_ids ), true ) ) {
				return 'current';
			}

			foreach ( $children as $child ) {
				if ( $this->get_item_state( $child['item'], $child['children'] ) ) {
					return 'current-ancestor';
				}
			}

			return '';
		}

		/**
		 * Builds a single item link.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $item       The item.
		 * @param bool  $is_current Whether the item is the current one.
		 * @return string
		 */
		protected function get_link_html( $item, $is_current ) {
			$link = '' !== $item['url'] ? $item['url'] : '#';

			$html  = '<a class="' . $this->block . '__link" href="' . esc_url( $link ) . '"' . ( $is_current ? ' aria-current="page"' : '' ) . $this->get_link_extra_attributes( $item ) . '>';
			$html .= $this->get_link_inner_html( $item );
			$html .= '</a>';

			return $html;
		}

		/**
		 * Element specific attributes of a single item link, each with a leading space.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $item The item.
		 * @return string
		 */
		protected function get_link_extra_attributes( $item ) {
			return '';
		}

		/**
		 * Builds what sits inside a single item link.
		 *
		 * Split out so an element can regroup the label and its meta without having to
		 * restate the anchor itself.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $item The item.
		 * @return string
		 */
		protected function get_link_inner_html( $item ) {
			$html  = '<span class="' . $this->block . '__text">';
			$html .= $this->get_icon_html();
			$html .= $this->get_image_html( $item );
			$html .= '<span class="' . $this->block . '__label">' . esc_html( $item['label'] ) . '</span>';
			$html .= '</span>';

			if ( '' !== $item['meta'] ) {
				$html .= '<span class="' . $this->block . '__' . $this->meta_param . '">' . esc_html( $item['meta'] ) . '</span>';
			}

			return $html;
		}

		/**
		 * Builds the element icon markup.
		 *
		 * The icon is set on the element, not per item, so the "all" item gets it
		 * too and its label stays aligned with the rest.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		protected function get_icon_html() {
			if ( '' === $this->args['icon'] ) {
				return '';
			}

			return '<span class="' . $this->block . '__media ' . $this->block . '__icon"><i class="' . esc_attr( fusion_font_awesome_name_handler( $this->args['icon'] ) ) . '" aria-hidden="true"></i></span>';
		}

		/**
		 * Builds the item image markup.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $item The item.
		 * @return string
		 */
		protected function get_image_html( $item ) {
			if ( 'yes' !== $this->args['show_image'] || empty( $item['image']['id'] ) ) {
				return '';
			}

			// The image is served responsively, so the display width is all that is needed.
			$width      = '' !== $this->args['image_width'] ? (int) $this->args['image_width'] : 24;
			$image_html = wp_get_attachment_image(
				$item['image']['id'],
				$item['image']['size'],
				false,
				[
					'alt'   => $item['label'],
					'sizes' => '(max-width: ' . $width . 'px) 100vw, ' . $width . 'px',
				]
			);

			if ( ! $image_html ) {
				return '';
			}

			return '<span class="' . $this->block . '__media ' . $this->block . '__image">' . $image_html . '</span>';
		}

		/**
		 * Builds the "all" list item.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		protected function get_all_link_html() {
			$url = $this->get_all_link_url();

			if ( ! $url ) {
				return '';
			}

			$label = '' !== $this->args['all_link_text'] ? $this->args['all_link_text'] : __( 'All', 'fusion-builder' );

			// The icon is element level, so the "all" item gets it too and stays aligned.
			return sprintf(
				'<li class="%1$s__item %1$s__item--all awb-nav-list__item"><div class="%1$s__row awb-nav-list__row"><a class="%1$s__link" href="%2$s"><span class="%1$s__text">%3$s<span class="%1$s__label">%4$s</span></span></a></div></li>',
				$this->block,
				esc_url( $url ),
				$this->get_icon_html(),
				esc_html( $label )
			);
		}

		/**
		 * Builds the select markup.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $tree The item tree.
		 * @return string
		 */
		protected function get_select_html( $tree ) {
			$label = '' !== $this->args['select_label'] ? $this->args['select_label'] : $this->get_select_default_label();

			$html  = '<div class="' . $this->block . '__select-wrapper avada-select-parent">';
			$html .= '<select class="' . $this->block . '__select awb-nav-list__select" aria-label="' . esc_attr( $label ) . '">';
			$html .= '<option value="">' . esc_html( $label ) . '</option>';

			if ( 'yes' === $this->args['show_all_link'] ) {
				$all_url = $this->get_all_link_url();

				if ( $all_url ) {
					$all_label = '' !== $this->args['all_link_text'] ? $this->args['all_link_text'] : __( 'All', 'fusion-builder' );
					$html     .= '<option value="' . esc_url( $all_url ) . '">' . esc_html( $all_label ) . '</option>';
				}
			}

			$html .= $this->get_options_html( $tree, 0 );
			$html .= '</select>';
			$html .= '<div class="' . $this->block . '__select-arrow" aria-hidden="true">&#xe61f;</div>';
			$html .= '</div>';

			return $html;
		}

		/**
		 * Recursively builds the select options.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @param array $nodes The tree nodes.
		 * @param int   $depth The current depth, starting at 0.
		 * @return string
		 */
		protected function get_options_html( $nodes, $depth ) {
			$max_depth   = (int) $this->args['max_depth'];
			$current_ids = array_map( 'absint', $this->get_current_ids() );
			$html        = '';

			foreach ( $nodes as $node ) {
				$item = $node['item'];

				if ( '' === $item['url'] ) {
					continue;
				}

				$label = str_repeat( '&nbsp;&nbsp;&nbsp;', $depth ) . esc_html( $item['label'] );

				if ( '' !== $item['meta'] ) {
					$label .= ' ' . esc_html( $item['meta'] );
				}

				$html .= sprintf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_url( $item['url'] ),
					in_array( (int) $item['id'], $current_ids, true ) ? ' selected="selected"' : '',
					$label
				);

				if ( ! empty( $node['children'] ) && ( 0 === $max_depth || $depth + 1 < $max_depth ) ) {
					$html .= $this->get_options_html( $node['children'], $depth + 1 );
				}
			}

			return $html;
		}

		/**
		 * Get the style variables.
		 *
		 * @access protected
		 * @since 3.16.2
		 * @return string
		 */
		protected function get_style_variables() {
			$meta = $this->meta_param;

			$css_vars_options = [
				'max_width'                  => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'max_width_medium'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'max_width_small'            => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_top'                 => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_right'               => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_bottom'              => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_left'                => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_top_medium'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_right_medium'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_bottom_medium'       => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_left_medium'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_top_small'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_right_small'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_bottom_small'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'margin_left_small'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_padding_top'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_padding_right'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_padding_bottom'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_padding_left'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_border_top'            => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_border_right'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_border_bottom'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_border_left'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'border_radius_top_left'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'border_radius_top_right'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'border_radius_bottom_right' => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'border_radius_bottom_left'  => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_gap'                   => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'sub_indent'                 => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'separator_size'             => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'icon_size'                  => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'image_width'                => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'image_border_radius'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'media_gap'                  => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'select_border_radius'       => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'select_height'              => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_font_size'             => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_letter_spacing'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				$meta . '_font_size'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				$meta . '_letter_spacing'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
				'item_align',
				'inline_justify',
				'separator_style',
				'separator_color',
				'item_color',
				'item_hover_color',
				'item_bgcolor',
				'item_hover_bgcolor',
				'item_border_style',
				'item_border_color',
				'item_hover_border_color',
				$meta . '_color',
				$meta . '_hover_color',
				'icon_color',
				'icon_hover_color',
				'toggle_color',
				'toggle_hover_color',
				'select_color',
				'select_bgcolor',
				'select_border_color',
				'select_focus_border_color',
				'item_line_height',
				'item_text_transform',
				$meta . '_line_height',
				$meta . '_text_transform',
			];

			$styles = $this->get_css_vars_for_options( $css_vars_options );

			$styles .= $this->get_font_styling_vars( 'item_font' );
			$styles .= $this->get_font_styling_vars( $meta . '_font' );

			return $styles;
		}

		/**
		 * Sets the necessary scripts.
		 *
		 * @access public
		 * @since 3.16.2
		 * @return void
		 */
		public function on_first_render() {
			Fusion_Dynamic_JS::enqueue_script(
				'awb-nav-list',
				FusionBuilder::$js_folder_url . '/general/awb-nav-list.js',
				FusionBuilder::$js_folder_path . '/general/awb-nav-list.js',
				[ 'jquery' ],
				FUSION_BUILDER_VERSION,
				true
			);
		}

		/**
		 * Load base CSS.
		 *
		 * @access public
		 * @since 3.16.2
		 * @return void
		 */
		public function add_css_files() {
			FusionBuilder()->add_element_css( FUSION_BUILDER_PLUGIN_DIR . 'assets/css/shortcodes/' . $this->block . '.min.css' );

			if ( class_exists( 'Avada' ) ) {
				$version = Avada::get_theme_version();

				Fusion_Media_Query_Scripts::$media_query_assets[] = [
					$this->block . '-md',
					FUSION_BUILDER_PLUGIN_DIR . 'assets/css/media/' . $this->block . '-md.min.css',
					[],
					$version,
					Fusion_Media_Query_Scripts::get_media_query_from_key( 'fusion-max-medium' ),
				];
				Fusion_Media_Query_Scripts::$media_query_assets[] = [
					$this->block . '-sm',
					FUSION_BUILDER_PLUGIN_DIR . 'assets/css/media/' . $this->block . '-sm.min.css',
					[],
					$version,
					Fusion_Media_Query_Scripts::get_media_query_from_key( 'fusion-max-small' ),
				];
			}
		}
	}
}
