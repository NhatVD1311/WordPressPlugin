/* global fusionAppConfig, fusionBuilderConfig, fusionBuilderText, fusionAllElements */

/**
 * Post Card import helper, shared by the live editor and the back-end builder.
 *
 * Sections copied from another site can carry the Post Card designs they use,
 * as those are library posts which only exist on the source site. Without them
 * a pasted Post Cards element renders empty.
 *
 * The payload travels as a base64 encoded HTML comment appended to the shortcode,
 * so it cannot be mistaken for shortcode content by the paste parser. It is never
 * imported silently: the user always gets to read the full content first.
 *
 * @since 3.16.1
 */
window.AwbPostCardImport = {

	/**
	 * Decode a base64 string into UTF-8 text.
	 *
	 * @since 3.16.1
	 * @param {String} encoded - The base64 string.
	 * @return {String} The decoded text.
	 */
	b64Decode: function( encoded ) {
		var binary = window.atob( encoded ),
			bytes  = new Uint8Array( binary.length ),
			i;

		for ( i = 0; i < binary.length; i++ ) {
			bytes[ i ] = binary.charCodeAt( i );
		}

		return new TextDecoder( 'utf-8' ).decode( bytes );
	},

	/**
	 * Encode UTF-8 text as base64.
	 *
	 * @since 3.16.1
	 * @param {String} text - The text to encode.
	 * @return {String} The base64 string.
	 */
	b64Encode: function( text ) {
		var bytes  = new TextEncoder().encode( text ),
			binary = '',
			i;

		for ( i = 0; i < bytes.length; i++ ) {
			binary += String.fromCharCode( bytes[ i ] );
		}

		return window.btoa( binary );
	},

	/**
	 * Get the i18n string for a key, with a fallback.
	 *
	 * @since 3.16.1
	 * @param {String} key - The string key.
	 * @param {String} fallback - The fallback text.
	 * @return {String} The text.
	 */
	t: function( key, fallback ) {
		if ( 'undefined' !== typeof fusionBuilderText && 'undefined' !== typeof fusionBuilderText[ key ] ) {
			return fusionBuilderText[ key ];
		}
		return fallback;
	},

	/**
	 * Get the ajax url and nonce, from whichever builder context we are in.
	 *
	 * @since 3.16.1
	 * @return {Object|Boolean} The config, or false.
	 */
	getConfig: function() {
		if ( 'undefined' !== typeof fusionAppConfig && fusionAppConfig.fusion_load_nonce ) {
			return {
				ajaxurl: fusionAppConfig.ajaxurl,
				nonce: fusionAppConfig.fusion_load_nonce
			};
		}

		if ( 'undefined' !== typeof fusionBuilderConfig && fusionBuilderConfig.fusion_load_nonce ) {
			return {
				ajaxurl: 'undefined' !== typeof window.ajaxurl ? window.ajaxurl : fusionBuilderConfig.ajaxurl,
				nonce: fusionBuilderConfig.fusion_load_nonce
			};
		}

		return false;
	},

	/**
	 * Split the import payloads out of clipboard content.
	 *
	 * Copying a whole page joins several sections together, and each one carries
	 * its own payload, so they can sit anywhere in the string, not just at the end.
	 * All of them are removed and their cards collected, keyed by ID so a card used
	 * by more than one section is only imported once.
	 *
	 * @since 3.16.1
	 * @param {String} clipboardContent - The clipboard text.
	 * @return {Object} The clipboard content without the payloads, and the cards.
	 */
	parsePayload: function( clipboardContent ) {
		var self   = this,
			result = {
				content: clipboardContent,
				cards: false,
				source: ''
			},
			cards  = [],
			seen   = {};

		if ( 'string' !== typeof clipboardContent || -1 === clipboardContent.indexOf( '<!--awb-import:' ) ) {
			return result;
		}

		// Always drop the payload comments, even the ones which cannot be read.
		result.content = clipboardContent.replace( /<!--awb-import:([A-Za-z0-9+/=]+)-->/g, function( match, encoded ) {
			var payload;

			try {
				payload = JSON.parse( self.b64Decode( encoded ) );
			} catch ( e ) {
				return '';
			}

			if ( ! payload || 1 !== payload.v || ! Array.isArray( payload.cards ) ) {
				return '';
			}

			if ( '' === result.source && 'string' === typeof payload.source ) {
				result.source = payload.source;
			}

			payload.cards.forEach( function( card ) {

				// Only keep entries which really carry content, and only once each.
				if ( card && card.id && 'string' === typeof card.content && '' !== card.content && ! seen[ card.id ] ) {
					seen[ card.id ] = true;
					cards.push( card );
				}
			} );

			return '';
		} );

		result.cards = cards.length ? cards : false;

		return result;
	},

	/**
	 * Point the post card params of a section at the newly imported cards.
	 *
	 * @since 3.16.1
	 * @param {String} content - The section shortcode.
	 * @param {Object} idMap - Map of original card ID to new local ID.
	 * @return {String} The section shortcode, with remapped card IDs.
	 */
	remap: function( content, idMap ) {
		var self = this;

		if ( ! idMap || ! Object.keys( idMap ).length ) {
			return content;
		}

		// Directly referenced cards.
		content = content.replace( /(post_card|post_card_list_view)="(\d+)"/g, function( match, param, id ) {
			return 'undefined' !== typeof idMap[ id ] ? param + '="' + idMap[ id ] + '"' : match;
		} );

		// Alternate cards are stored as a base64 encoded JSON array.
		content = content.replace( /alternate_post_cards="([^"]+)"/g, function( match, encoded ) {
			var alternates;

			try {
				alternates = JSON.parse( self.b64Decode( encoded ) );
			} catch ( e ) {
				return match;
			}

			if ( ! Array.isArray( alternates ) ) {
				return match;
			}

			alternates.forEach( function( alternate ) {
				if ( alternate && alternate.alternate_post_card && 'undefined' !== typeof idMap[ alternate.alternate_post_card ] ) {
					alternate.alternate_post_card = String( idMap[ alternate.alternate_post_card ] );
				}
			} );

			try {
				return 'alternate_post_cards="' + self.b64Encode( JSON.stringify( alternates ) ) + '"';
			} catch ( e ) {
				return match;
			}
		} );

		return content;
	},

	/**
	 * Ask the user what to do with the post cards a pasted section references.
	 * The full content of each card is shown, it is never imported sight unseen.
	 *
	 * @since 3.16.1
	 * @param {Array} cards - The post cards from the payload.
	 * @param {String} source - The host the section was copied from.
	 * @param {Function} onPaste - Called with an ID map, or false to paste as is.
	 * @return {void}
	 */
	confirm: function( cards, source, onPaste ) {
		var self     = this,
			$dialog  = jQuery( '<div class="awb-import-cards"></div>' ),
			$panel   = jQuery( '<div class="awb-import-cards__panel"></div>' ),
			$list    = jQuery( '<div class="awb-import-cards__list"></div>' ),
			$actions = jQuery( '<div class="awb-import-cards__actions"></div>' ),
			intro    = this.t( 'import_post_cards_intro', 'This section uses Post Card designs which do not exist on this site. Review them below, they will be added to your Avada Library.' ),
			$import,
			$without,
			$cancel;

		$panel.append( jQuery( '<h3></h3>' ).text( this.t( 'import_post_cards', 'Import Post Card Designs?' ) ) );

		if ( source ) {
			intro += ' ' + this.t( 'import_post_cards_source', 'Copied from:' ) + ' ' + source;
		}

		$panel.append( jQuery( '<p class="awb-import-cards__intro"></p>' ).text( intro ) );

		// Never use html() here, the content comes from another site.
		cards.forEach( function( card ) {
			var $item = jQuery( '<div class="awb-import-cards__item"></div>' ),
				title = card.title ? card.title : self.t( 'import_post_cards_untitled', 'Untitled Post Card' );

			$item.append( jQuery( '<div class="awb-import-cards__title"></div>' ).text( self.t( 'import_post_cards_label', 'Post Card:' ) + ' ' + title ) );
			$item.append( jQuery( '<textarea class="awb-import-cards__content" readonly rows="7" spellcheck="false"></textarea>' ).val( card.content ) );

			$list.append( $item );
		} );

		$panel.append( $list );

		$cancel  = jQuery( '<button type="button" class="awb-import-cards__cancel"></button>' ).text( this.t( 'cancel', 'Cancel' ) );
		$without = jQuery( '<button type="button" class="awb-import-cards__skip"></button>' ).text( this.t( 'import_post_cards_skip', 'Paste Without' ) );
		$import  = jQuery( '<button type="button" class="awb-import-cards__submit"></button>' ).text( this.t( 'import_post_cards_submit', 'Import & Paste' ) );

		$actions.append( $cancel ).append( $without ).append( $import );
		$panel.append( $actions );
		$dialog.append( $panel ).appendTo( 'body' );

		function close() {
			jQuery( document ).off( 'keydown.awbImportCards' );
			$dialog.remove();
		}

		$cancel.on( 'click', close );

		$dialog.on( 'click', function( event ) {
			if ( jQuery( event.target ).is( '.awb-import-cards' ) ) {
				close();
			}
		} );

		jQuery( document ).on( 'keydown.awbImportCards', function( event ) {
			if ( 'Escape' === event.key ) {
				close();
			}
		} );

		$without.on( 'click', function() {
			close();
			onPaste( false );
		} );

		$import.on( 'click', function() {
			$import.prop( 'disabled', true ).text( self.t( 'import_post_cards_working', 'Importing…' ) );

			self.importCards( cards, function( idMap ) {
				close();
				onPaste( idMap );
			} );
		} );

		$import.trigger( 'focus' );
	},

	/**
	 * Add an imported card to the post card options, so the element settings
	 * show it right away instead of falling back to "None". Without this the
	 * select and its quick edit button only know the cards which existed on load.
	 *
	 * @since 3.16.1
	 * @param {Number} id - The new local post card ID.
	 * @param {String} title - The post card title.
	 * @param {String} permalink - The post card edit permalink.
	 * @return {void}
	 */
	registerImportedCard: function( id, title, permalink ) {
		var names = [ 'post_card', 'post_card_list_view', 'alternate_post_card' ];

		if ( 'undefined' === typeof fusionAllElements || ! id ) {
			return;
		}

		// Post card params sit at different depths, e.g. the alternate cards are a nested repeater.
		function walk( node, depth ) {
			if ( ! node || 'object' !== typeof node || 6 < depth ) {
				return;
			}

			if ( node.param_name && -1 !== names.indexOf( node.param_name ) ) {
				if ( node.value && 'object' === typeof node.value ) {
					node.value[ id ] = title;
				}

				if ( permalink && node.quick_edit && node.quick_edit.items && 'object' === typeof node.quick_edit.items ) {
					node.quick_edit.items[ id ] = permalink;
				}
			}

			jQuery.each( node, function( key, child ) {

				// No need to walk into the choices themselves.
				if ( 'value' !== key && 'quick_edit' !== key && child && 'object' === typeof child ) {
					walk( child, depth + 1 );
				}
			} );
		}

		jQuery.each( fusionAllElements, function( type, element ) {
			if ( element && element.params ) {
				walk( element.params, 0 );
			}
		} );
	},

	/**
	 * Create the post cards on this site.
	 *
	 * @since 3.16.1
	 * @param {Array} cards - The post cards from the payload.
	 * @param {Function} onDone - Called with a map of original ID to new local ID.
	 * @return {void}
	 */
	importCards: function( cards, onDone ) {
		var self     = this,
			config   = this.getConfig(),
			idMap    = {},
			requests = [];

		if ( ! config ) {
			onDone( idMap );
			return;
		}

		cards.forEach( function( card ) {

			// jQuery.when() rejects as soon as one request fails, which would leave the
			// requests still in flight out of the map. Each one resolves on its own instead,
			// so a failing card can never cut the others short.
			var done = jQuery.Deferred();

			requests.push( done );

			jQuery.ajax( {
				type: 'POST',
				url: config.ajaxurl,
				data: {
					action: 'awb_import_post_card',
					fusion_load_nonce: config.nonce,
					title: card.title ? card.title : '',
					content: card.content
				}
			} ).done( function( response ) {
				if ( response && response.success && response.data && response.data.id ) {
					idMap[ card.id ] = response.data.id;

					self.registerImportedCard( response.data.id, response.data.title ? response.data.title : card.title, response.data.permalink );
				}
			} ).always( function() {
				done.resolve();
			} );
		} );

		// A partial import still pastes, unmapped cards keep their original ID.
		jQuery.when.apply( jQuery, requests ).always( function() {
			onDone( idMap );
		} );
	}
};
