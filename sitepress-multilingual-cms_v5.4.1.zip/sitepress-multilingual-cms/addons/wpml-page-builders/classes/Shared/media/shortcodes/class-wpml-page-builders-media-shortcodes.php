<?php

class WPML_Page_Builders_Media_Shortcodes {

	const TYPE_URL = 'media-url';
	const TYPE_IDS = 'media-ids';
	const TYPE_CSS = 'media-css';

	private $media_translate;

	private $target_lang;

	private $source_lang;

	private $config;

	private $tag_name;

	private $attribute_name = '';

	private $css_images;

	public function __construct( IWPML_PB_Media_Find_And_Translate $media_translate, array $config, ?\WPML\PB\Media\CssImages $css_images = null ) {
		$this->media_translate = $media_translate;
		$this->config          = $config;
		$this->css_images      = $css_images ?: new \WPML\PB\Media\CssImages( $media_translate );
	}

	public function translate( $content ) {
		$urls = $this->extract_media_urls_from_content( $content );
		if ( ! empty( $urls ) ) {
			$this->media_translate->prefetch_media_urls( $urls, $this->source_lang );
		}

		foreach ( $this->config as $shortcode ) {
			$shortcode = $this->sanitize_shortcode( $shortcode );
			$tag_name  = isset( $shortcode['tag']['name'] ) ? $shortcode['tag']['name'] : '';

			$this->tag_name = $tag_name;

			if ( ! empty( $shortcode['attributes'] ) ) {
				$content = $this->translate_attributes( $content, $tag_name, $shortcode['attributes'] );
			}

			if ( ! empty( $shortcode['content'] ) ) {
				$content = $this->translate_content( $content, $tag_name, $shortcode['content'] );
			}
		}

		return $content;
	}

	private function extract_media_urls_from_content( $content ) {
		$urls = array();

		foreach ( $this->config as $shortcode ) {
			$shortcode = $this->sanitize_shortcode( $shortcode );
			$tag_name  = isset( $shortcode['tag']['name'] ) ? $shortcode['tag']['name'] : '';

			if ( ! $tag_name ) {
				continue;
			}

			if ( ! empty( $shortcode['attributes'] ) ) {
				$urls = array_merge( $urls, $this->extract_urls_from_shortcode_attributes( $content, $tag_name, $shortcode['attributes'] ) );
			}

			if ( ! empty( $shortcode['content'] ) && isset( $shortcode['content']['type'] ) && self::TYPE_URL === $shortcode['content']['type'] ) {
				$urls = array_merge( $urls, $this->extract_urls_from_shortcode_content( $content, $tag_name ) );
			}
		}

		return array_values( array_unique( array_filter( $urls ) ) );
	}

	private function extract_urls_from_shortcode_attributes( $content, $tag_name, array $attributes ) {
		$urls = array();

		foreach ( $attributes as $attribute => $data ) {
			$type = isset( $data['type'] ) ? $data['type'] : '';
			if ( self::TYPE_URL !== $type && self::TYPE_CSS !== $type ) {
				continue;
			}
			$pattern = $this->get_attribute_pattern( $tag_name, $attribute );
			if ( ! preg_match_all( $pattern, $content, $matches ) || empty( $matches[2] ) ) {
				continue;
			}
			$urls = self::TYPE_CSS === $type
				? array_merge( $urls, ...array_map( [ $this->css_images, 'findImageUrls' ], $matches[2] ) )
				: array_merge( $urls, $matches[2] );
		}

		return $urls;
	}

	private function extract_urls_from_shortcode_content( $content, $tag_name ) {
		$pattern = $this->get_content_pattern( $tag_name );
		if ( preg_match_all( $pattern, $content, $matches ) ) {
			return array_map( 'trim', $matches[2] );
		}

		return array();
	}

	public function has_media_shortcode( $content ) {
		if ( false === strpos( $content, '[' ) ) {
			return false;
		};

		foreach ( $this->config as $shortcode ) {
			$shortcode = $this->sanitize_shortcode( $shortcode );
			$tag_name  = isset( $shortcode['tag']['name'] ) ? $shortcode['tag']['name'] : '';

			if ( $tag_name && false !== strpos( $content, '[' . $tag_name ) ) {
				return true;
			}
		}

		return false;
	}

	private function sanitize_shortcode( array $shortcode ) {
		$defaults = array(
			'attributes' => null,
		);

		return array_merge( $defaults, $shortcode );
	}

	private function get_attribute_pattern( $tag, $attribute ) {
		$start = '\[' . preg_quote( $tag, '/' ) . '(?: [^\]]* | )' . preg_quote( $attribute, '/' ) . '=';

		if ( \WPML\Compatibility\WPBakery\ImageLinks::isImageAttribute( $tag, $attribute ) ) {
			return '/(?|(' . $start . '")([^"]*)|(' . $start . '\')([^"\']*))/';
		}

		return '/(' . $start . '(?:"|\'))([^"\']*)/';
	}

	private function get_content_pattern( $tag ) {
		return '/(\[(?:' . preg_quote( $tag, '/' ) . ')[^\]]*\])([^\[]+)/';
	}

	private function translate_attributes( $content, $tag, array $attributes ) {
		foreach ( $attributes as $attribute => $data ) {
			$pattern = $this->get_attribute_pattern( $tag, $attribute );
			$type    = isset( $data['type'] ) ? $data['type'] : '';

			$this->attribute_name = $attribute;
			$content              = preg_replace_callback( $pattern, $this->get_callback( $type ), $content );
		}

		$this->attribute_name = '';

		return $content;
	}

	private function translate_content( $content, $tag, array $data ) {
		$pattern = $this->get_content_pattern( $tag );
		$type    = isset( $data['type'] ) ? $data['type'] : '';
		return preg_replace_callback( $pattern, $this->get_callback( $type ), $content );
	}

	private function get_callback( $type ) {
		if ( self::TYPE_URL === $type ) {
			return [ $this, 'replace_url_callback' ];
		}

		if ( self::TYPE_CSS === $type ) {
			return [ $this, 'replace_css_callback' ];
		}

		return [ $this, 'replace_ids_callback' ];
	}

	private function replace_url_callback( array $matches ) {
		$translated_url = $this->media_translate->translate_image_url( $matches[2], $this->target_lang, $this->source_lang, $this->tag_name );

		return $matches[1] . $translated_url;
	}

	private function replace_css_callback( array $matches ) {
		return $matches[1] . $this->css_images->translate( $matches[2], $this->target_lang, $this->source_lang, $this->tag_name );
	}

	private function replace_ids_callback( array $matches ) {
		$is_image_links = \WPML\Compatibility\WPBakery\ImageLinks::isImageAttribute( $this->tag_name, $this->attribute_name )
			&& null !== \WPML\Compatibility\WPBakery\ImageLinks::decodeMap( $matches[2] );

		if ( ! $is_image_links && ! \WPML\PB\Media\MediaIds::isList( $matches[2] ) ) {
			return $matches[0];
		}

		$translate_id = function ( $id ) {
			return $this->media_translate->translate_id( $id, $this->target_lang );
		};

		return $is_image_links
			? $matches[1] . \WPML\Compatibility\WPBakery\ImageLinks::translateIds( $matches[2], $translate_id )
			: $matches[1] . \WPML\PB\Media\MediaIds::translate( $matches[2], $translate_id );
	}

	public function set_target_lang( $target_lang ) {
		$this->target_lang = $target_lang;
		return $this;
	}

	public function set_source_lang( $source_lang ) {
		$this->source_lang = $source_lang;
		return $this;
	}

	public function get_media() {
		return $this->media_translate->get_used_media_in_post();
	}
}
