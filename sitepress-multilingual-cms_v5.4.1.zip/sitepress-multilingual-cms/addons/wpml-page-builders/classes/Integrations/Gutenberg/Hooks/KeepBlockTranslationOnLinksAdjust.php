<?php

namespace WPML\PB\Gutenberg\Hooks;

class KeepBlockTranslationOnLinksAdjust implements \WPML\PB\Gutenberg\Integration {

	private $pbIntegration;

	private $keptTranslation;

	public function __construct( \WPML_PB_Integration $pbIntegration ) {
		$this->pbIntegration = $pbIntegration;
	}

	public function add_hooks() {
		add_filter( 'wpml_links_adjust_rebuilds_translation', [ $this, 'keepBlockPageTranslation' ], 10, 2 );
		add_filter( 'wpml_links_adjust_writer_without_rebuild', [ $this, 'writeLinksWithoutResave' ], 10, 2 );
	}

	public function keepBlockPageTranslation( $rebuild, $translation ) {
		if ( ! $rebuild ) {
			return $rebuild;
		}

		$keep                  = $this->isBlockPageTranslation( $translation );
		$this->keptTranslation = $keep ? $translation : null;

		return ! $keep;
	}

	public function writeLinksWithoutResave( $writeLinks, $translation ) {
		$isKept                = null !== $this->keptTranslation && $translation === $this->keptTranslation;
		$this->keptTranslation = null;

		if ( ! $isKept || ! is_callable( $writeLinks ) ) {
			return $writeLinks;
		}

		return function () use ( $writeLinks ) {
			return $this->pbIntegration->without_resave( $writeLinks );
		};
	}

	private function isBlockPageTranslation( $translation ): bool {
		if ( ! $translation instanceof \WPML_Post_Element ) {
			return false;
		}

		$original = $translation->get_source_element();

		return $original && $this->isBlockPage( (int) $original->get_id() );
	}

	private function isBlockPage( int $originalId ): bool {
		$packages = (array) apply_filters( 'wpml_st_get_post_string_packages', [], $originalId );
		if ( ! $packages ) {
			return false;
		}

		foreach ( $packages as $package ) {
			if ( ! $package instanceof \WPML_Package || \WPML_Gutenberg_Integration::PACKAGE_ID !== $package->kind ) {
				return false;
			}
		}

		return true;
	}
}
