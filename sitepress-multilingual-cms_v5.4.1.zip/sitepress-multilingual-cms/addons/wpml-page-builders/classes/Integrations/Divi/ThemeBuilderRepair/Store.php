<?php

namespace WPML\Compatibility\Divi\ThemeBuilderRepair;

use WPML\Compatibility\Divi\Hooks\ThemeBuilderOneList;

class Store {

	const ELEMENT_TYPE = 'post_et_theme_builder';

	const LIBRARY_META = '_et_library_theme_builder';

	const TEMPLATES_META = '_et_template';

	const RECORD_META = '_wpml_divi_theme_builder_repair';

	const LAST_OPTION = 'wpml_divi_theme_builder_repair_last';

	const LINKS_OPTION = 'wpml_divi_theme_builder_layout_links';

	const TEMPLATE_KEYS = [
		'_et_use_on',
		'_et_exclude_from',
		'_et_default',
		'_et_header_layout_id',
		'_et_body_layout_id',
		'_et_footer_layout_id',
	];

	private $wpdb;

	private $sitepress;

	public function __construct( $wpdb, $sitepress ) {
		$this->wpdb      = $wpdb;
		$this->sitepress = $sitepress;
	}

	public function defaultLanguage() {
		return (string) $this->sitepress->get_default_language();
	}

	public function publishedThemeBuilderPosts() {
		$wpdb = $this->wpdb;

		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID AS id, p.post_title AS title, p.post_date AS date, t.language_code AS language
				FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->prefix}icl_translations t ON t.element_id = p.ID AND t.element_type = %s
				LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = %s AND m.meta_id IS NULL
				ORDER BY p.post_date DESC, p.ID DESC",
				self::ELEMENT_TYPE,
				self::LIBRARY_META,
				'et_theme_builder',
				'publish'
			)
		);

		$posts = [];
		foreach ( $rows as $row ) {
			$posts[] = [
				'id'       => (int) $row->id,
				'title'    => (string) $row->title,
				'date'     => (string) $row->date,
				'language' => null === $row->language || '' === $row->language ? null : (string) $row->language,
			];
		}

		return $posts;
	}

	public function repairedThemeBuilderPosts() {
		$wpdb = $this->wpdb;

		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID AS id, p.post_title AS title, p.post_date AS date, m.meta_value AS record
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = %s
				ORDER BY p.post_date DESC, p.ID DESC",
				self::RECORD_META,
				'et_theme_builder',
				'draft'
			)
		);

		$posts = [];
		foreach ( $rows as $row ) {
			$record   = \WPML\Utils\Unserialize::maybe( $row->record );
			$language = is_array( $record ) && isset( $record['language'] ) && is_string( $record['language'] ) && '' !== $record['language'] ? $record['language'] : null;
			$posts[]  = [
				'id'       => (int) $row->id,
				'title'    => (string) $row->title,
				'date'     => (string) $row->date,
				'language' => $language,
			];
		}

		return $posts;
	}

	public function templateFacts( $templateId ) {
		$wpdb = $this->wpdb;
		$keys = self::TEMPLATE_KEYS;

		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key IN (" . implode( ',', array_fill( 0, count( $keys ), '%s' ) ) . ')',
				array_merge( [ (int) $templateId ], $keys )
			)
		);

		$useOn   = [];
		$exclude = [];
		$single  = [];
		foreach ( $rows as $row ) {
			if ( '_et_use_on' === $row->meta_key ) {
				$useOn[] = (string) $row->meta_value;
			} elseif ( '_et_exclude_from' === $row->meta_key ) {
				$exclude[] = 'exclude:' . $row->meta_value;
			} else {
				$single[ $row->meta_key ] = (string) $row->meta_value;
			}
		}
		sort( $useOn );
		sort( $exclude );

		$trid = $this->sitepress->get_element_trid( (int) $templateId, 'post_et_template' );

		return [
			'trid'       => $trid ? (int) $trid : null,
			'default'    => isset( $single['_et_default'] ) && '1' === $single['_et_default'],
			'conditions' => array_merge( $useOn, $exclude ),
			'layouts'    => [
				'header' => isset( $single['_et_header_layout_id'] ) ? (int) $single['_et_header_layout_id'] : 0,
				'body'   => isset( $single['_et_body_layout_id'] ) ? (int) $single['_et_body_layout_id'] : 0,
				'footer' => isset( $single['_et_footer_layout_id'] ) ? (int) $single['_et_footer_layout_id'] : 0,
			],
		];
	}

	public function isTranslatable( $postType ) {
		return (bool) $this->sitepress->is_translated_post_type( $postType );
	}

	public function layoutRow( $layoutId, $postType ) {
		$wpdb = $this->wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT p.post_type AS type, t.trid, t.language_code AS language,
					( SELECT COUNT(*) FROM {$wpdb->prefix}icl_translations g WHERE g.trid = t.trid AND g.element_type = t.element_type ) AS members
				FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->prefix}icl_translations t ON t.element_id = p.ID AND t.element_type = %s
				WHERE p.ID = %d",
				'post_' . $postType,
				(int) $layoutId
			)
		);

		if ( ! is_object( $row ) || $postType !== $row->type ) {
			return null;
		}

		return [
			'type'     => (string) $row->type,
			'trid'     => $row->trid ? (int) $row->trid : null,
			'language' => null === $row->language || '' === $row->language ? null : (string) $row->language,
			'members'  => (int) $row->members,
		];
	}

	public function translationIn( $trid, $postType, $language ) {
		$wpdb = $this->wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE trid = %d AND element_type = %s AND language_code = %s LIMIT 1",
				(int) $trid,
				'post_' . $postType,
				$language
			)
		);
	}

	public function link( $layoutId, $postType, $trid, $language, $sourceLanguage ) {
		$result = $this->sitepress->set_element_language_details( (int) $layoutId, 'post_' . $postType, (int) $trid, $language, $sourceLanguage );

		do_action( 'wpml_cache_clear' );

		return (bool) $result;
	}

	public function linkedTranslation( $layoutId, $originalId, $postType ) {
		$wpdb = $this->wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT l.translation_id, l.trid, l.language_code, l.source_language_code,
					o.trid AS original_trid, o.language_code AS original_language, o.source_language_code AS original_source,
					s.rid
				FROM {$wpdb->prefix}icl_translations l
				LEFT JOIN {$wpdb->prefix}icl_translations o ON o.element_id = %d AND o.element_type = l.element_type
				LEFT JOIN {$wpdb->prefix}icl_translation_status s ON s.translation_id = l.translation_id
				WHERE l.element_id = %d AND l.element_type = %s",
				(int) $originalId,
				(int) $layoutId,
				'post_' . $postType
			)
		);

		if ( ! is_object( $row ) || ! $row->translation_id ) {
			return null;
		}

		$linked = $row->original_trid
			&& (int) $row->original_trid === (int) $row->trid
			&& null === $row->original_source
			&& null !== $row->source_language_code
			&& (string) $row->source_language_code === (string) $row->original_language;

		return [
			'translation' => (int) $row->translation_id,
			'language'    => (string) $row->language_code,
			'linked'      => (bool) $linked,
			'status'      => null !== $row->rid,
		];
	}

	public function writeCompleteStatus( $translationId, $originalId ) {
		list( $rid ) = wpml_load_core_tm()->update_translation_status(
			[
				'translation_id'      => (int) $translationId,
				'status'              => ICL_TM_COMPLETE,
				'translator_id'       => 0,
				'needs_update'        => 0,
				'md5'                 => '',
				'translation_service' => 'local',
			]
		);

		return (bool) $rid;
	}

	public function markEditedByHand( $layoutId, $originalId ) {
		$wroteEditMark = ! \WPML_PB_Last_Translation_Edit_Mode::is_native_editor( (int) $layoutId );
		if ( $wroteEditMark ) {
			\WPML_PB_Last_Translation_Edit_Mode::set_native_editor( (int) $layoutId );
		}

		$editorKey         = \WPML\Core\SharedKernel\Component\Post\Domain\TranslationEditorPreference::POST_META_KEY_EDITOR;
		$native            = \WPML\Core\SharedKernel\Component\Post\Domain\TranslationEditorPreference::EDITOR_NATIVE;
		$previous          = (string) get_post_meta( (int) $originalId, $editorKey, true );
		$wroteEditorChoice = $native !== $previous;
		if ( $wroteEditorChoice ) {
			update_post_meta( (int) $originalId, $editorKey, $native );
		}

		$wrote = [
			'wrote_editor_choice' => $wroteEditorChoice,
			'wrote_edit_mark'     => $wroteEditMark,
		];
		if ( $wroteEditorChoice && '' !== $previous ) {
			$wrote['previous_editor_choice'] = $previous;
		}

		return $wrote;
	}

	public function keepsOwnContent( $layoutId ) {
		$layoutId = (int) $layoutId;

		if ( \WPML_PB_Last_Translation_Edit_Mode::is_native_editor( $layoutId ) ) {
			return true;
		}

		if ( \WPML_PB_Last_Translation_Edit_Mode::is_translation_editor( $layoutId ) ) {
			return false;
		}

		return $this->newestJobKeepsOwnContent( $layoutId );
	}

	private function newestJobKeepsOwnContent( $layoutId ) {
		$wpdb = $this->wpdb;

		$hasPackages    = \WPML\Upgrade\SchemaFacts::hasTable( 'icl_string_packages' );
		$packageStrings = $hasPackages
			? "CASE WHEN job.job_id IS NULL OR job.editor IS NULL OR job.editor IN ( '', 'none' ) THEN EXISTS (
					SELECT 1
					FROM {$wpdb->prefix}icl_translations original
					INNER JOIN {$wpdb->prefix}icl_string_packages package ON package.post_id = original.element_id
					INNER JOIN {$wpdb->prefix}icl_strings string ON string.string_package_id = package.ID
					INNER JOIN {$wpdb->prefix}icl_string_translations string_translation
						ON string_translation.string_id = string.id
					WHERE original.trid = translations.trid AND original.source_language_code IS NULL
						AND string_translation.language = translations.language_code
				) ELSE 0 END"
			: '0';

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT translation_status.rid, job.job_id, job.editor, {$packageStrings} AS has_package_translation
				FROM {$wpdb->prefix}icl_translations translations
				LEFT JOIN {$wpdb->prefix}icl_translation_status translation_status
					ON translation_status.translation_id = translations.translation_id
				LEFT JOIN {$wpdb->prefix}icl_translate_job job
					ON job.job_id = (
						SELECT MAX(latest.job_id)
						FROM {$wpdb->prefix}icl_translate_job latest
						WHERE latest.rid = translation_status.rid
					)
				WHERE translations.element_id = %d
					AND translations.element_type LIKE %s
					AND translations.source_language_code IS NOT NULL
				LIMIT 1",
				$layoutId,
				$wpdb->esc_like( 'post_' ) . '%'
			)
		);

		if ( ! is_object( $row ) ) {
			return true;
		}

		if ( empty( $row->rid ) || empty( $row->job_id ) ) {
			return empty( $row->has_package_translation );
		}

		$editor = isset( $row->editor ) ? (string) $row->editor : '';

		if ( \WPML_TM_Editors::WP === $editor ) {
			return true;
		}

		if ( \WPML_TM_Editors::ATE === $editor || \WPML_TM_Editors::WPML === $editor ) {
			return false;
		}

		if ( '' === $editor || \WPML_TM_Editors::NONE === $editor ) {
			return empty( $row->has_package_translation );
		}

		return false;
	}

	public function links() {
		return (array) get_option( self::LINKS_OPTION, [] );
	}

	public function replaceLinks( array $links ) {
		update_option( self::LINKS_OPTION, $links, false );
	}

	public function writeLinks( array $links ) {
		$all  = (array) get_option( self::LINKS_OPTION, [] );
		$time = gmdate( 'Y-m-d H:i:s' );
		foreach ( $links as $link ) {
			$all[] = $link + [ 'time' => $time ];
		}

		update_option( self::LINKS_OPTION, $all, false );
	}

	public function templates( $themeBuilderId ) {
		$templates = [];
		foreach ( (array) get_post_meta( $themeBuilderId, self::TEMPLATES_META, false ) as $templateId ) {
			$templateId = (int) $templateId;
			if ( $templateId > 0 ) {
				$templates[] = [
					'id'    => $templateId,
					'title' => (string) get_the_title( $templateId ),
				];
			}
		}

		return $templates;
	}

	public function languageRowCount() {
		$wpdb = $this->wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}icl_translations WHERE element_type = %s", self::ELEMENT_TYPE )
		);
	}

	public function storedModes() {
		$sync     = (array) $this->sitepress->get_setting( ThemeBuilderOneList::SYNC_OPTION, [] );
		$unlocked = (array) $this->sitepress->get_setting( ThemeBuilderOneList::UNLOCK_OPTION, [] );

		$modes = [];
		foreach ( ThemeBuilderOneList::POST_TYPES as $postType ) {
			$modes[ $postType ] = [
				'mode'     => isset( $sync[ $postType ] ) ? (int) $sync[ $postType ] : ThemeBuilderOneList::MODE_NOT_TRANSLATABLE,
				'unlocked' => ! empty( $unlocked[ $postType ] ),
			];
		}

		return $modes;
	}

	public function unpublish( $themeBuilderId, array $record ) {
		update_post_meta( $themeBuilderId, self::RECORD_META, $record );

		$result = wp_update_post(
			[
				'ID'          => $themeBuilderId,
				'post_status' => 'draft',
			],
			true
		);

		return ! is_wp_error( $result ) && 0 !== $result;
	}

	public function deleteLanguageRows() {
		$deleted = $this->wpdb->delete(
			$this->wpdb->prefix . 'icl_translations',
			[ 'element_type' => self::ELEMENT_TYPE ],
			[ '%s' ]
		);

		do_action( 'wpml_cache_clear' );

		return (int) $deleted;
	}

	public function resetModes() {
		$sync     = (array) $this->sitepress->get_setting( ThemeBuilderOneList::SYNC_OPTION, [] );
		$unlocked = (array) $this->sitepress->get_setting( ThemeBuilderOneList::UNLOCK_OPTION, [] );

		foreach ( ThemeBuilderOneList::POST_TYPES as $postType ) {
			$sync[ $postType ]     = ThemeBuilderOneList::MODE_NOT_TRANSLATABLE;
			$unlocked[ $postType ] = 0;
		}

		$this->sitepress->set_setting( ThemeBuilderOneList::SYNC_OPTION, $sync );
		$this->sitepress->set_setting( ThemeBuilderOneList::UNLOCK_OPTION, $unlocked, true );
	}

	public function writeLast( array $last ) {
		update_option( self::LAST_OPTION, $last, false );
	}

	public function log( $line ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( 'WPML Divi Theme Builder repair: ' . $line );
		}
	}
}
