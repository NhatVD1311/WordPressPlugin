<?php

namespace Bricksforge;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Maintenance Handler
 */
class Maintenance
{

    public function __construct()
    {
        $this->init();
    }

    public function init()
    {
        if ($this->activated() === true) {
            add_filter('template_redirect', [$this, 'configure']);
        }
    }

    /**
     * Get a value from settings - handles both object and array formats
     */
    private function get_setting_value($settings, $key, $default = null)
    {
        if (is_object($settings) && isset($settings->$key)) {
            return $settings->$key;
        } elseif (is_array($settings) && isset($settings[$key])) {
            return $settings[$key];
        }
        return $default;
    }

    public function activated()
    {

        if (!get_option('brf_activated_tools') || !in_array(4, get_option('brf_activated_tools')) || !get_option('brf_maintenance')) {
            return false;
        }

        $settings = get_option('brf_maintenance');
        if (!isset($settings[0])) {
            return false;
        }

        $settings_item = $settings[0];
        $is_activated = $this->get_setting_value($settings_item, 'isActivated', false);

        if (!$is_activated) {
            return false;
        }

        return true;
    }

    /**
     * Token proving the maintenance password was entered.
     *
     * Derived from the password and the site's auth salt, so it cannot be
     * guessed or forged by a visitor, and it changes automatically when the
     * password is changed -- which invalidates cookies handed out earlier.
     *
     * @param string $password Configured maintenance password.
     * @return string
     */
    private function unlock_token($password)
    {
        return hash_hmac('sha256', (string) $password, wp_salt('auth'));
    }

    public function configure()
    {
        $settings = get_option('brf_maintenance');

        if (!isset($settings[0])) {
            return;
        }

        $settings_item = $settings[0];
        $excluded_roles = $this->get_setting_value($settings_item, 'exclude', false);
        $status_code = $this->get_setting_value($settings_item, 'statusCode', 302);
        $allowed = true;

        $page = $this->get_setting_value($settings_item, 'page');

        if (!$page) {
            return;
        }

        /**
         * Check for password
         * @since 0.9.3
         */
        $unlock_with_password = $this->get_setting_value($settings_item, 'unlockWithPassword', false);
        $password = $this->get_setting_value($settings_item, 'password');

        // SECURITY: the unlock cookie used to be accepted on its own existence,
        // with no value checked, so setting brf-unlock-maintenance to anything
        // at all walked past maintenance mode without knowing the password.
        // The cookie now has to carry a token derived from the password and
        // the site's auth salt, which a visitor cannot produce.
        if ($unlock_with_password && $password) {
            $expected_token = $this->unlock_token($password);

            if (isset($_COOKIE['brf-unlock-maintenance'])
                && hash_equals($expected_token, (string) $_COOKIE['brf-unlock-maintenance'])) {
                return;
            }

            $found_password = isset($_GET['password']) && $_GET['password'] ? $_GET['password'] : false;

            if ($found_password && hash_equals((string) $password, (string) $found_password)) {
                setcookie(
                    'brf-unlock-maintenance',
                    $expected_token,
                    [
                        'expires'  => strtotime('+365 days'),
                        'path'     => '/',
                        'secure'   => is_ssl(),
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]
                );

                return;
            }
        }

        $is_logged_in = is_user_logged_in();

        if (!$is_logged_in || $excluded_roles === false) {
            $this->redirect($page, $status_code);
            return;
        }

        $user = wp_get_current_user();
        foreach ($excluded_roles as $role) {
            if (in_array($role, $user->roles)) {
                $allowed = false;
            }
        }

        if ($allowed === true) {
            if (!is_page($page)) {
                wp_redirect(get_page_link($page), $status_code);
                exit();
            }
        }
    }

    public function redirect($page, $status_code)
    {
        if (!is_page($page)) {
            wp_redirect(get_page_link($page), $status_code);
            exit();
        }
    }
}
