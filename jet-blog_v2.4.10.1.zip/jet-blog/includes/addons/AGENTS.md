# Addon maintenance

- Elementor widget settings are persisted input. Do not trust a control type as output sanitization.
- When a setting determines a CSS class token, allowlist its supported values before composing the token.
- For HTML attributes, apply filters to canonical values first, then escape the final attribute value at the output boundary.
- The Video Playlist root classes are produced by `Jet_Blog_Video_Playlist::_container_classes()` and consumed by `templates/jet-blog-video-playlist/global/index.php`.
- Run `php tests/video-playlist-container-classes-regression.php` after changing that helper or its related controls.
