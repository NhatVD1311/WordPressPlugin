<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

namespace ThemePunch\SR\Platform\WordPress;

use ThemePunch\SR\Ports;

if(!defined('ABSPATH')) exit();

/**
 * wp_mail behind the Mailer port, so an SMTP or mail log plugin sees every form mail.
 * @since 7.2.12
 */
class Mailer implements Ports\Mailer {

	public function send($to, $subject, $text, $reply_to = ''){
		if(empty($to)) $to = [get_option('admin_email')];
		$headers = ['Content-Type: text/plain; charset=UTF-8'];
		if($reply_to !== '') $headers[] = 'Reply-To: ' . $reply_to;

		return (bool)wp_mail($to, $subject, $text, $headers);
	}
}
