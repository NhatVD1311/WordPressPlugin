<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

if(!defined('ABSPATH')) exit();

/**
 * A menu list (settings.menus, SR7.F.buildMenus) set to read a WordPress menu: its entries are the menu's top level, put
 * in before the module reaches the page. The editor shows the same entries from SR7.E.menus.
 * @since 7.2.11
 */
class RevSliderWpMenus {

	public static function init(){
		add_filter('sr_get_full_slider_JSON', ['RevSliderWpMenus', 'fill'], 10, 4);
	}

	/**
	 * The top level of a WordPress menu as list entries: a link to a place on the same page scrolls there
	 * @param int|string $menu term id
	 * @return array [['id', 't', 'l', 'nw']]
	 */
	public static function items($menu){
		$items = wp_get_nav_menu_items((int)$menu);
		if(empty($items) || !is_array($items)) return [];

		$out = [];
		foreach($items as $item){
			if((int)$item->menu_item_parent !== 0) continue;
			$url = (string)$item->url;
			//Polylang's language switcher is one item that becomes one per language, '123-de': (int) would make them one id
			$out[] = ['id' => 'wp' . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$item->ID), 't' => wp_strip_all_tags($item->title), 'l' => (strpos($url, '#') === 0) ? $url : esc_url_raw($url), 'nw' => $item->target === '_blank'];
		}

		return $out;
	}

	/**
	 * the menus of the site with their entries, for the editor
	 * @return array
	 */
	public static function all(){
		$out = [];
		foreach(wp_get_nav_menus() as $menu) $out[] = ['id' => (string)$menu->term_id, 'name' => $menu->name, 'items' => self::items($menu->term_id)];

		return $out;
	}

	/**
	 * sr_get_full_slider_JSON: a list that reads a menu gets its entries; an empty or deleted menu leaves the list its own
	 * @return array
	 */
	public static function fill($obj, $slider = null, $raw = false, $modify = false){
		if($modify !== true || empty($obj['settings']['menus']) || !is_array($obj['settings']['menus'])) return $obj;

		foreach($obj['settings']['menus'] as $key => $list){
			if(($list['src'] ?? 'own') !== 'wp' || empty($list['wp'])) continue;
			$items = self::items(self::in_language((int)$list['wp']));
			if(!empty($items)) $obj['settings']['menus'][$key]['items'] = $items;
		}

		return $obj;
	}

	/**
	 * WPML and Polylang keep one menu per language, the list names the one it was set up with; without either the id stays.
	 * Polylang ties its menus to theme locations: the location holding this menu in one language names the current one's
	 * @return int
	 */
	private static function in_language($id){
		if(!function_exists('pll_current_language')) return (int)apply_filters('wpml_object_id', $id, 'nav_menu', true);

		$lang	= pll_current_language();
		$opt	= get_option('polylang', []);
		foreach((array)($opt['nav_menus'][get_stylesheet()] ?? []) as $langs){
			if(!empty($langs[$lang]) && in_array($id, array_map('intval', (array)$langs), true)) return (int)$langs[$lang];
		}

		return $id;
	}
}
