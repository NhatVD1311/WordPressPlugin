<!-- channel visual fields end --> <!-- channel settings fields -->
    <?php if (!in_array($social['slug'], ["Contact_Us", "Link", "Custom_Link", "Custom_Link_3", "Custom_Link_4", "Custom_Link_5", "Custom_Link_6"])) { ?>
        <?php
        $imgClass = "";
        $value['agent_fa_icon'] = isset($value['agent_fa_icon']) ? $value['agent_fa_icon'] : "";
        $value['agent_image_id'] = isset($value['agent_image_id']) ? $value['agent_image_id'] : "";
        if (!empty($value['agent_fa_icon'])) {
            $imgClass = "icon-active";
        } else {
            if (!empty($value['agent_image_id'])) {
                $imageUrl = wp_get_attachment_image_src($value['agent_image_id'], "full")[0];
                // get custom image URL if exists
                if ($imageUrl == "") {
                    $imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
                    // Initialize with default image if custom image is not exists
                } else {
                    $imgClass = "img-active";
                }
            }
        }

        if (!isset($value['agent_bg_color'])) {
            $value['agent_bg_color'] = $social['color'];
        }

        if ($social['slug'] == "Twitter" && ($value['agent_bg_color'] == "#1ab2e8" || $value['agent_bg_color'] == "rgb(26, 178, 232)")) {
            $value['agent_bg_color'] = "#000000";
        }
        $value['agent_bg_color'] = $this->validate_color($value['agent_bg_color'], $social['color']);

        if (!isset($value['agent_head_bg_color'])) {
            $value['agent_head_bg_color'] = $social['color'];
        }

        if ($social['slug'] == "Instagram" && $value['agent_head_bg_color'] == "#ffffff") {
            $value['agent_head_bg_color'] = "#704DC9";
        }
        $value['agent_head_bg_color'] = $this->validate_color($value['agent_head_bg_color'], $social['color']);

        if (!isset($value['agent_head_text_color'])) {
            $value['agent_head_text_color'] = "#ffffff";
        }
        $value['agent_head_text_color'] = $this->validate_color($value['agent_head_text_color'], "#ffffff");

        if (!isset($value['agent_title'])) {
            $value['agent_title'] = $social['title'];
        }

        if (!isset($value['agent_header_text'])) {
            $value['agent_header_text'] = "Hello";
        }

        if (!isset($value['agent_sub_header_text'])) {
            $value['agent_sub_header_text'] = "How can we help?";
        }

        if (!isset($value['is_agent_desktop'])) {
            $value['is_agent_desktop'] = "checked";
        }

        if (!isset($value['is_agent_mobile'])) {
            $value['is_agent_mobile'] = "checked";
        }
        ?>
    <div class="chaty-agent-form">
        <!-- agent settings start -->
        <div class="chaty-agent-setting">
            <div class="border border-solid border-cht-primary rounded-lg" style="background-color: #F7F2FD">
                <header class="flex items-center gap-2 sm:gap-0 px-2 sm:pr-5 sm:pl-3 py-6 flex-wrap">
                    <!-- header left with move icon and agent image -->
                    <div class="flex items-center space-x-1 mr-4">
                        <div class="move-icon">
                            <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>"/>
                        </div>
                        <div class="agent-icon inline-flex <?php echo esc_attr($imgClass) ?>" id="image_agent_data_agent-<?php echo esc_attr($social['slug']) ?>">
                                    <span style="background-color: <?php echo esc_attr($value['agent_bg_color']) ?>" class="custom-agent-image overflow-hidden rounded-full custom-agent-image-<?php echo esc_attr($social['slug']) ?>">
                                        <img class="agent-image h-full object-cover w-full" src="<?php echo esc_url($imageUrl) ?>"/>
                                        <span class="remove-agent-img"></span>
                                        <input class="image-id" id="cht_social_agent_image_agent-<?php echo esc_attr($social['slug']); ?>" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_image_id]" value="<?php echo esc_attr($value['agent_image_id']) ?>"/> </span>
                            <span class="default-agent-icon <?php echo (isset($value['fa_icon']) && !empty($value['fa_icon'])) ? "has-fa-icon" : "" ?> custom-agent-icon-<?php echo esc_attr($social['slug']) ?> default_agent_image_<?php echo esc_attr($social['slug']) ?>"> <?php echo $svg_icon; ?> </span>
                            <span style="background-color: <?php echo esc_attr($value['agent_bg_color']) ?>" class="facustom-icon flex items-center justify-center">
                                        <i class="<?php echo esc_attr($value['agent_fa_icon']) ?>"></i>
                                    </span>
                            <input class="fa-icon" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_fa_icon]" value="<?php echo esc_attr($value['agent_fa_icon']) ?>">
                            <span class="remove-icon-img remove-img-icon" data-slug="agent-<?php echo esc_attr($social['slug']) ?>"></span>
                        </div>
                    </div>
                    <!-- header middle with device and customizer button -->
                    <div class="agent-header-info flex flex-wrap sm:items-center gap-2 sm:gap-4">
                        <div class="agent-head-top text-base font-primary text-cht-gray-150">
                            <?php esc_html_e("Agent launcher", "chaty") ?>
                        </div>
                        <div class="flex items-center">
                            <div class="agent-devices flex items-center space-x-1">
                                <label class="text-sm font-primary text-cht-gray-150/80">
                                    <?php esc_html_e('Show on', 'chaty') ?>
                                </label>
                                <div class="device-box">
                                    <!-- setting for desktop -->
                                    <label class="device_view cursor-pointer" for="<?php echo esc_attr($slug); ?>Desktop-agent">
                                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_agent_desktop]" value=""/>
                                        <input type="checkbox" id="<?php echo esc_attr($slug); ?>Desktop-agent" class="channels__view-check agent-desktop-device" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_agent_desktop]" value="checked" <?php echo esc_attr($value['is_agent_desktop']) ?> />
                                        <span class="device-view-txt">
                                                    <svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M13.3333 10.0001C14.0667 10.0001 14.6667 9.40008 14.6667 8.66675V2.00008C14.6667 1.26675 14.0667 0.666748 13.3333 0.666748H2.66667C1.93333 0.666748 1.33333 1.26675 1.33333 2.00008V8.66675C1.33333 9.40008 1.93333 10.0001 2.66667 10.0001H0.666667C0.3 10.0001 0 10.3001 0 10.6667C0 11.0334 0.3 11.3334 0.666667 11.3334H15.3333C15.7 11.3334 16 11.0334 16 10.6667C16 10.3001 15.7 10.0001 15.3333 10.0001H13.3333ZM3.33333 2.00008H12.6667C13.0333 2.00008 13.3333 2.30008 13.3333 2.66675V8.00008C13.3333 8.36675 13.0333 8.66675 12.6667 8.66675H3.33333C2.96667 8.66675 2.66667 8.36675 2.66667 8.00008V2.66675C2.66667 2.30008 2.96667 2.00008 3.33333 2.00008Z"/>
                                                    </svg>
                                                </span>
                                        <span class="device-tooltip">
                                                    <span class="on">
                                                        <?php esc_html_e("Hide on desktop", "chaty") ?>
                                                    </span>
                                                    <span class="off">
                                                        <?php esc_html_e("Show on desktop", "chaty") ?>
                                                    </span>
                                                </span>
                                    </label>
                                    <!-- setting for mobile -->
                                    <label class="device_view cursor-pointer" for="<?php echo esc_attr($slug); ?>Mobile-agent">
                                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_agent_mobile]" value=""/>
                                        <input type="checkbox" id="<?php echo esc_attr($slug); ?>Mobile-agent" class="channels__view-check agent-mobile-device" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_agent_mobile]" value="checked" <?php echo esc_attr($value['is_agent_mobile']) ?> />
                                        <span class="device-view-txt">
                                                    <svg width="9" height="16" viewBox="0 0 9 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M7.33301 0.666748H1.99967C1.07967 0.666748 0.333008 1.41341 0.333008 2.33341V13.6667C0.333008 14.5867 1.07967 15.3334 1.99967 15.3334H7.33301C8.25301 15.3334 8.99967 14.5867 8.99967 13.6667V2.33341C8.99967 1.41341 8.25301 0.666748 7.33301 0.666748ZM4.66634 14.6667C4.11301 14.6667 3.66634 14.2201 3.66634 13.6667C3.66634 13.1134 4.11301 12.6667 4.66634 12.6667C5.21967 12.6667 5.66634 13.1134 5.66634 13.6667C5.66634 14.2201 5.21967 14.6667 4.66634 14.6667ZM7.66634 12.0001H1.66634V2.66675H7.66634V12.0001Z"></path>
                                                    </svg>
                                                </span>
                                        <span class="device-tooltip">
                                                    <span class="on">
                                                        <?php esc_html_e("Hide on mobile", "chaty") ?>
                                                    </span>
                                                    <span class="off">
                                                        <?php esc_html_e("Show on mobile", "chaty") ?>
                                                    </span>
                                                </span>
                                    </label>
                                </div>
                            </div>
                            <!-- customize button for agent -->
                            <div class="agent-customize-button ml-2">
                                <button type="button" class="customize-agent-button bg-white">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M8 10C9.10457 10 10 9.10457 10 8C10 6.89543 9.10457 6 8 6C6.89543 6 6 6.89543 6 8C6 9.10457 6.89543 10 8 10Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M12.9327 9.99999C12.8439 10.2011 12.8175 10.4241 12.8567 10.6404C12.8959 10.8566 12.999 11.0562 13.1527 11.2133L13.1927 11.2533C13.3166 11.3772 13.415 11.5242 13.4821 11.6861C13.5492 11.8479 13.5837 12.0214 13.5837 12.1967C13.5837 12.3719 13.5492 12.5454 13.4821 12.7072C13.415 12.8691 13.3166 13.0162 13.1927 13.14C13.0689 13.264 12.9218 13.3623 12.7599 13.4294C12.5981 13.4965 12.4246 13.531 12.2493 13.531C12.0741 13.531 11.9006 13.4965 11.7388 13.4294C11.5769 13.3623 11.4298 13.264 11.306 13.14L11.266 13.1C11.1089 12.9463 10.9093 12.8432 10.6931 12.804C10.4768 12.7648 10.2538 12.7912 10.0527 12.88C9.8555 12.9645 9.68734 13.1048 9.56889 13.2837C9.45044 13.4625 9.38687 13.6721 9.38601 13.8867V14C9.38601 14.3536 9.24554 14.6927 8.99549 14.9428C8.74544 15.1928 8.4063 15.3333 8.05268 15.3333C7.69906 15.3333 7.35992 15.1928 7.10987 14.9428C6.85982 14.6927 6.71935 14.3536 6.71935 14V13.94C6.71419 13.7193 6.64276 13.5053 6.51436 13.3258C6.38595 13.1463 6.2065 13.0095 5.99935 12.9333C5.79827 12.8446 5.57522 12.8181 5.35896 12.8573C5.14269 12.8965 4.94313 12.9996 4.78601 13.1533L4.74601 13.1933C4.62218 13.3173 4.47513 13.4156 4.31327 13.4827C4.1514 13.5498 3.9779 13.5844 3.80268 13.5844C3.62746 13.5844 3.45396 13.5498 3.29209 13.4827C3.13023 13.4156 2.98318 13.3173 2.85935 13.1933C2.73538 13.0695 2.63703 12.9224 2.56994 12.7606C2.50284 12.5987 2.4683 12.4252 2.4683 12.25C2.4683 12.0748 2.50284 11.9013 2.56994 11.7394C2.63703 11.5775 2.73538 11.4305 2.85935 11.3067L2.89935 11.2667C3.05304 11.1095 3.15614 10.91 3.19535 10.6937C3.23456 10.4775 3.20809 10.2544 3.11935 10.0533C3.03484 9.85614 2.89452 9.68798 2.71566 9.56953C2.5368 9.45108 2.32721 9.38751 2.11268 9.38666H1.99935C1.64573 9.38666 1.30659 9.24618 1.05654 8.99613C0.806491 8.74608 0.666016 8.40694 0.666016 8.05332C0.666016 7.6997 0.806491 7.36056 1.05654 7.11051C1.30659 6.86046 1.64573 6.71999 1.99935 6.71999H2.05935C2.28001 6.71483 2.49402 6.6434 2.67355 6.515C2.85308 6.38659 2.98983 6.20715 3.06602 5.99999C3.15476 5.79891 3.18123 5.57586 3.14202 5.3596C3.10281 5.14333 2.99971 4.94378 2.84602 4.78666L2.80602 4.74666C2.68205 4.62283 2.5837 4.47577 2.5166 4.31391C2.4495 4.15205 2.41497 3.97854 2.41497 3.80332C2.41497 3.6281 2.4495 3.4546 2.5166 3.29274C2.5837 3.13087 2.68205 2.98382 2.80602 2.85999C2.92985 2.73602 3.0769 2.63768 3.23876 2.57058C3.40063 2.50348 3.57413 2.46894 3.74935 2.46894C3.92457 2.46894 4.09807 2.50348 4.25994 2.57058C4.4218 2.63768 4.56885 2.73602 4.69268 2.85999L4.73268 2.89999C4.8898 3.05368 5.08936 3.15678 5.30562 3.19599C5.52189 3.23521 5.74494 3.20873 5.94601 3.11999H5.99935C6.19653 3.03548 6.36469 2.89516 6.48314 2.7163C6.60159 2.53744 6.66516 2.32785 6.66601 2.11332V1.99999C6.66601 1.64637 6.80649 1.30723 7.05654 1.05718C7.30659 0.807132 7.64573 0.666656 7.99935 0.666656C8.35297 0.666656 8.69211 0.807132 8.94216 1.05718C9.1922 1.30723 9.33268 1.64637 9.33268 1.99999V2.05999C9.33354 2.27451 9.3971 2.48411 9.51555 2.66297C9.634 2.84183 9.80217 2.98215 9.99935 3.06666C10.2004 3.1554 10.4235 3.18187 10.6397 3.14266C10.856 3.10345 11.0556 3.00035 11.2127 2.84666L11.2527 2.80666C11.3765 2.68269 11.5236 2.58434 11.6854 2.51724C11.8473 2.45014 12.0208 2.41561 12.196 2.41561C12.3712 2.41561 12.5447 2.45014 12.7066 2.51724C12.8685 2.58434 13.0155 2.68269 13.1393 2.80666C13.2633 2.93049 13.3617 3.07754 13.4288 3.2394C13.4959 3.40127 13.5304 3.57477 13.5304 3.74999C13.5304 3.92521 13.4959 4.09871 13.4288 4.26058C13.3617 4.42244 13.2633 4.56949 13.1393 4.69332L13.0993 4.73332C12.9457 4.89044 12.8426 5.09 12.8033 5.30626C12.7641 5.52253 12.7906 5.74558 12.8793 5.94666V5.99999C12.9639 6.19717 13.1042 6.36533 13.283 6.48378C13.4619 6.60223 13.6715 6.6658 13.886 6.66666H13.9993C14.353 6.66666 14.6921 6.80713 14.9422 7.05718C15.1922 7.30723 15.3327 7.64637 15.3327 7.99999C15.3327 8.35361 15.1922 8.69275 14.9422 8.9428C14.6921 9.19285 14.353 9.33332 13.9993 9.33332H13.9393C13.7248 9.33418 13.5152 9.39774 13.3364 9.51619C13.1575 9.63464 13.0172 9.80281 12.9327 9.99999V9.99999Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <?php esc_html_e("Customize", 'chaty') ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- header right with remoave all agent button -->
                    <button data-id="<?php echo esc_attr($social['slug']); ?>" type="button" class="remove-agents-button flex items-center text-xs font-primary text-cht-gray-150 space-x-1 bg-white border border-solid border-cht-gray-150/40 rounded-md px-2 py-1 hover:bg-cht-red/10 hover:text-cht-red hover:border-cht-red self-center sm:ml-auto" data-social="<?php echo esc_attr($social['slug']); ?>">
                        <svg width="16" height="18" viewBox="0 0 18 18" fill="none">
                            <path d="M5.5 7.5H10.5C10.6326 7.5 10.7598 7.55268 10.8536 7.64645C10.9473 7.74021 11 7.86739 11 8C11 8.13261 10.9473 8.25979 10.8536 8.35355C10.7598 8.44732 10.6326 8.5 10.5 8.5H5.5C5.36739 8.5 5.24021 8.44732 5.14645 8.35355C5.05268 8.25979 5 8.13261 5 8C5 7.86739 5.05268 7.74021 5.14645 7.64645C5.24021 7.55268 5.36739 7.5 5.5 7.5Z" fill="currentColor"/> <path d="M8 14C8.78793 14 9.56815 13.8448 10.2961 13.5433C11.0241 13.2417 11.6855 12.7998 12.2426 12.2426C12.7998 11.6855 13.2417 11.0241 13.5433 10.2961C13.8448 9.56815 14 8.78793 14 8C14 7.21207 13.8448 6.43185 13.5433 5.7039C13.2417 4.97595 12.7998 4.31451 12.2426 3.75736C11.6855 3.20021 11.0241 2.75825 10.2961 2.45672C9.56815 2.15519 8.78793 2 8 2C6.4087 2 4.88258 2.63214 3.75736 3.75736C2.63214 4.88258 2 6.4087 2 8C2 9.5913 2.63214 11.1174 3.75736 12.2426C4.88258 13.3679 6.4087 14 8 14ZM8 15C6.14348 15 4.36301 14.2625 3.05025 12.9497C1.7375 11.637 1 9.85652 1 8C1 6.14348 1.7375 4.36301 3.05025 3.05025C4.36301 1.7375 6.14348 1 8 1C9.85652 1 11.637 1.7375 12.9497 3.05025C14.2625 4.36301 15 6.14348 15 8C15 9.85652 14.2625 11.637 12.9497 12.9497C11.637 14.2625 9.85652 15 8 15Z" fill="currentColor"/>
                        </svg>
                        <span>
                                    <?php esc_html_e('Remove All Agent', 'chaty') ?>
                                </span>
                    </button>
                </header>
                <!-- agent customizer field start -->
                <main class="chaty-channel-setting hidden chaty-channel-main-settings space-y-4 px-5 md:px-24 border-t border-solid border-cht-gray-150/10 py-5">
                    <!-- hover text and icon background -->
                    <div class="grid grid-cols-2 gap-5"> <div>
                            <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                <?php esc_html_e("On Hover Text", "chaty"); ?>
                                <span class="header-tooltip">
                                            <span class="header-tooltip-text text-center">
                                                <?php esc_html_e('The text that will appear next to your channel when a visitor hovers over it', 'chaty'); ?>
                                            </span>
                                            <span class="ml-1">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                    <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                        </span>
                            </label>
                            <input type="text" id="cht_social_agent_text_<?php echo esc_attr($social['slug']); ?>" class="chaty-agent-title" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_title]" value="<?php echo esc_attr($value['agent_title']) ?>">
                        </div>
                        <div>
                            <label class="ont-priamry text-cht-gray-150 text-base mb-2 block">
                                <?php esc_html_e("Icon Appearance", "chaty"); ?>
                            </label>
                            <input type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_bg_color]" class="chaty-color-field agent-bg-color" value="<?php echo esc_attr($value['agent_bg_color']) ?>"/>
                        </div>
                    </div>
                    <!-- custom image and custom icon -->
                    <div class="flex items-start space-x-5 mt-6">
                        <div>
                            <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                <?php esc_html_e("Custom Image", "chaty"); ?>
                            </label>
                            <a onclick="upload_chaty_agent_image('agent-<?php echo esc_attr($social['slug']); ?>')" href="#" class="upload-chaty-icon bg-white border border-solid border-gray-150 inline-block py-1 px-3 rounded-md text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60">
                                <?php esc_html_e('Upload Image', 'chaty') ?>
                            </a>
                        </div>
                        <div>
                            <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                <?php esc_html_e("Change Icon", "chaty"); ?>
                            </label>
                            <div class="icon-picker-wrap bg-white border border-solid border-gray-150 py-1 px-3 rounded-md text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60" id="icon-picker-agent-<?php echo esc_attr($social['slug']); ?>" data-slug="agent-<?php echo esc_attr($social['slug']); ?>">
                                <div id='select-icon-agent-<?php echo esc_attr($social['slug']); ?>' class="select-icon">
                                            <span class="custom-icon">
                                                <?php esc_html_e('Select Icon', 'chaty') ?>
                                            </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- headers area -->
                    <div>
                        <label class="font-priamry text-cht-gray-150 text-base mb-2 mt-6 block">
                            <?php esc_html_e('Header Area', 'chaty') ?>
                        </label>
                        <div class="p-4 sm:p-6 rounded-lg border border-solid border-cht-primary/50" style="background-color: #FAF6FE">
                            <!-- header color and text appearance -->
                            <div class="grid grid-cols-2 gap-5">
                                <!-- header color -->
                                <div>
                                    <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                        <?php esc_html_e("Header Color", "chaty"); ?>
                                        <div class="html-tooltip small top">
                                                    <span>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path d="M8 10.6667V8" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path d="M8 5.33203H8.00667" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </span>
                                            <span class="tooltip-text top">
                                                        <?php esc_html_e("Clicking the agent launcher shows a popup with all the agents. Change the popup's header color", "chaty"); ?>
                                                        <img src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/agent-section.jpeg"/>
                                                    </span>
                                        </div>
                                    </label>
                                    <input type="text" class="chaty-color-field" id="agent_head_bg_color_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_head_bg_color]" value="<?php echo esc_attr($value['agent_head_bg_color']) ?>">
                                </div>
                                <!-- text appearance -->
                                <div>
                                    <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                        <?php esc_html_e("Text Appearance", "chaty"); ?>
                                        <div class="html-tooltip small top">
                                                    <span>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path d="M8 10.6667V8" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path d="M8 5.33203H8.00667" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                    </span>
                                            <span class="tooltip-text top">
                                                        <?php esc_html_e("Clicking the agent launcher shows a popup with all the agents. Change the popup's header text color", "chaty"); ?>
                                                        <img src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/agent-section.jpeg"/>
                                                    </span>
                                        </div>
                                    </label>
                                    <input type="text" class="chaty-color-field" id="agent_head_text_color_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_head_text_color]" value="<?php echo esc_attr($value['agent_head_text_color']) ?>">
                                </div>
                            </div>
                            <!-- header text -->
                            <div class="mt-6">
                                <label class="font-priamry text-cht-gray-150 text-sm mb-2 block">
                                    <?php esc_html_e("Header Text", "chaty"); ?>
                                    <div class="html-tooltip small top">
                                                <span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M8 10.6667V8" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M8 5.33203H8.00667" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span>
                                        <span class="tooltip-text top">
                                                    <?php esc_html_e("Add the header text which will be displayed as the heading of the agent launcher popup", "chaty"); ?>
                                                    <img src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/agent-section.jpeg"/>
                                                </span>
                                    </div>
                                </label>
                                <input type="text" id="cht_social_agent_title_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_header_text]" value="<?php echo esc_attr($value['agent_header_text']) ?>">
                            </div>
                            <!-- sub header text -->
                            <div class="mt-6">
                                <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Sub-Header Text", "chaty"); ?>
                                    <div class="html-tooltip small top">
                                                <span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M8 10.6667V8" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M8 5.33203H8.00667" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span>
                                        <span class="tooltip-text small top">
                                                    <?php esc_html_e("Add the sub-header text which will be displayed as the heading of the agent launcher popup", "chaty"); ?>
                                                    <img src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/agent-section.jpeg"/>
                                                </span>
                                    </div>
                                </label>
                                <input type="text" id="cht_social_agent_sub_title_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_sub_header_text]" value="<?php echo esc_attr($value['agent_sub_header_text']) ?>">
                            </div>
                        </div>
                    </div>
                    <!-- header area end -->
                </main>
                <!-- agent customizer field end -->
            </div>
        </div> <!-- agent settings end -->
        <div class="chaty-agent-advance-setting">
            <?php $agentData = isset($value['agent_data']) && is_array($value['agent_data']) && count($value['agent_data']) > 0 ? $value['agent_data'] : []; ?>
            <div class="chaty-agents" data-count="<?php echo(count($agentData) + 1) ?>">
                <div class="chaty-agent-list">
                    <ul class="agent-list" id="agent-list-<?php echo esc_attr($slug) ?>">
                        <?php
                        if (!empty($agentData)) {
                            $count = 1;
                            foreach ($agentData as $key => $agent) {
                                if (is_numeric($key) && $key != "<?php echo esc_attr($count) ?>") { $image_id = isset($agent['image_id']) ? $agent['image_id'] : 0; $value = isset($agent['value']) ? $agent['value'] : ''; $is_desktop = isset($agent['is_desktop']) ? $agent['is_desktop'] : ""; $is_mobile = isset($agent['is_mobile']) ? $agent['is_mobile'] : ""; $agent_bg_color = $this->validate_color((isset($agent['agent_bg_color']) ? $agent['agent_bg_color'] : $social['color']), $social['color']);
                                    $agent_fa_icon = isset($agent['agent_fa_icon']) ? $agent['agent_fa_icon'] : '';
                                    $agent_title = isset($agent['agent_title']) ? $agent['agent_title'] : '';

                                    $imgClass = "";
                                    $imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
                                    // Initialize with default image if custom image is not exists
                                    if (!empty($agent_fa_icon)) {
                                        $imgClass = "icon-active";
                                    } else {
                                        if (!empty($image_id)) {
                                            $imageUrl = wp_get_attachment_image_src($image_id, "full")[0];
                                            // get custom image URL if exists
                                            if ($imageUrl == "") {
                                                $imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
                                                // Initialize with default image if custom image is not exists
                                            } else {
                                                $imgClass = "img-active";
                                            }
                                        }
                                    }

                                    if (($social['slug'] == "Whatsapp") && !empty($value)) {
                                        if ($value[1] == "0") {
                                            $value[1] = " ";
                                            $value = str_replace(' ', '', $value);
                                        }
                                    }
                                    ?>
                                    <li class="agent-info">
                                        <div class="agent-channel-setting" id="agent-<?php echo esc_attr($slug) ?>-<?php echo esc_attr($count) ?>" data-item="<?php echo esc_attr($count) ?>">
                                            <div class="agent-channel-setting-top px-2 sm:pl-3 sm:pr-5">
                                                <div class="flex items-center">
                                                    <div class="move-channel-icon transition duration-200 opacity-0 ">
                                                        <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>"/>
                                                    </div>
                                                    <div class="agent-icon <?php echo esc_attr($imgClass) ?>" id="image_agent_data_<?php echo esc_attr($social['slug']) ?>-<?php echo esc_attr($count) ?>">
                                                                <span style="" class="custom-agent-image overflow-hidden rounded-full custom-agent-image-<?php echo esc_attr($social['slug']) ?>-<?php echo esc_attr($count) ?>">
                                                                    <img class="agent-image w-full h-full object-cover" src="<?php echo esc_url($imageUrl) ?>"/>
                                                                    <span class="remove-agent-img"></span>
                                                                    <input class="image-id" id="cht_social_agent_image_<?php echo esc_attr($social['slug']); ?>-<?php echo esc_attr($count) ?>" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][image_id]" value="<?php echo esc_attr($image_id) ?>"/>
                                                                </span>
                                                        <span class="default-agent-icon custom-agent-icon-<?php echo esc_attr($social['slug']) ?>-<?php echo esc_attr($count) ?> default_agent_image_<?php echo esc_attr($social['slug']) ?>-<?php echo esc_attr($count) ?>">
                                                                    <?php echo $svg_icon; ?>
                                                                </span>
                                                        <span class="facustom-icon flex items-center justify-center" style="background-color: <?php echo esc_attr($agent_bg_color) ?>">
                                                                    <i class="<?php echo esc_attr($agent_fa_icon) ?>"></i>
                                                                </span>
                                                        <span class="agent-info-image header-tooltip">
                                                                    <span class="header-tooltip-text text-center">
                                                                        <?php if (isset($social['header_help'])) {
                                                                            echo "<span class='agent-viber-note'>" . esc_attr($social['header_help']) . "</span>";
                                                                        } ?>
                                                                        <?php esc_html_e("This channel is an instance of the main channel", "chaty") ?>
                                                                    </span>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                    </svg>
                                                                </span>
                                                        <span class="remove-icon-img remove-img-icon" data-slug="<?php echo esc_attr($social['slug']) ?>-<?php echo esc_attr($count) ?>"></span>
                                                        <input class="fa-icon" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][agent_fa_icon]" value="<?php echo esc_attr($agent_fa_icon) ?>">
                                                    </div>
                                                </div>

                                                <div class="flex-auto">
                                                    <div class="agent-channel-input">
                                                        <div class="p-relative agent-<?php echo esc_attr($social['slug']) ?>-btn test-btn">
                                                            <input placeholder="<?php echo esc_attr($social['example']); ?>" class="agent-input-value <?php echo ($social['slug'] == "") ? "chaty-whatsapp-phone" : "" ?> custom-agent-channel-<?php echo esc_attr($social['slug']) ?>" id="cht_social_agent_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($count) ?>" data-id="<?php echo esc_attr($count) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][value]" value="<?php echo esc_attr($value) ?>">
                                                            <?php if ($social['slug'] == 'Whatsapp') { ?>
                                                                <span class="header-tooltip-text text-center leading-zero-msg">
                                                                            <span class="close-msg-box">
                                                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 1L1 11M1 1L11 11" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                                                            </span>
                                                                            You entered the phone number with a leading zero. We've fixed it for you
                                                                        </span>
                                                            <?php } ?>
                                                            <?php if ($social['slug'] == 'Whatsapp' || $social['slug'] == 'Facebook_Messenger') { ?>
                                                                <button type="button" class="wf-test-button <?php echo !empty($value) ? "active" : "" ?>" data-slug="<?php echo esc_attr($social['slug']) ?>"><?php esc_html_e('Test', 'chaty') ?></button>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="chaty-agent-setting-col">
                                                            <?php $placeholder = ($social['slug'] == 'Discord') ? esc_html__('Agent Name & Title or Channel Name', 'chaty') : esc_html__('Agent Name & Title', 'chaty'); ?>
                                                            <div>
                                                                <!-- input for custom title -->
                                                                <input type="text" placeholder="<?php echo esc_attr($placeholder); ?>" class="chaty-agent-name" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][agent_title]" value="<?php echo esc_attr($agent_title) ?>">
                                                            </div>
                                                        </div>
                                                        <div class="clear clearfix"></div>
                                                    </div>
                                                    <div class="agent-channel-setting-btn mt-2 inline-block">
                                                        <button type="button" class="agent-channel-setting-button">
                                                            <span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e("Settings", 'chaty') ?>
                                                        </button>
                                                    </div>
                                                </div>

                                                <button type="button" class="remove-agent-btn absolute -top-1 right-2 text-cht-gray-150 hover:text-cht-red">
                                                    <svg class="pointer-events-none" data-v-1cf7b632="" width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" svg-inline="" focusable="false" tabindex="-1">
                                                        <path data-v-1cf7b632="" d="M2 4h12M5.333 4V2.667a1.333 1.333 0 011.334-1.334h2.666a1.333 1.333 0 011.334 1.334V4m2 0v9.333a1.334 1.334 0 01-1.334 1.334H4.667a1.334 1.334 0 01-1.334-1.334V4h9.334z" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </button>
                                            </div>
                                            <div class="agent-channel-setting-advance hidden">
                                                <div class="grid grid-cols-2 gap-5">

                                                    <div>
                                                        <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Custom Image", "chaty") ?></label>
                                                        <a onclick="upload_chaty_agent_image('<?php echo esc_attr($social['slug']); ?>-<?php echo esc_attr($count) ?>')" href="#" class="upload-chaty-icon bg-white border border-solid border-gray-150 py-1 px-3 inline-block rounded-md text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60">Upload
                                                            Image</a>
                                                    </div>

                                                    <!-- input for custom color -->
                                                    <div>
                                                        <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Icon Appearance", "chaty") ?></label>
                                                        <input type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][agent_bg_color]" class="chaty-color-field agent-icon-color" value="<?php echo esc_attr($agent_bg_color) ?>"/>
                                                    </div>

                                                    <div>
                                                        <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Change Icon", "chaty") ?></label>
                                                        <div class="icon-picker-wrap bg-white border border-solid border-gray-150 py-1 px-3 rounded-md text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60 inline-block" id="icon-picker-<?php echo esc_attr($social['slug']); ?>-<?php echo esc_attr($count) ?>" data-slug="<?php echo esc_attr($social['slug']); ?>-<?php echo esc_attr($count) ?>">
                                                            <div id='select-icon-<?php echo esc_attr($social['slug']); ?>-<?php echo esc_attr($count) ?>' class="select-icon">
                                                                <span class="custom-icon">Select Icon</span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- linkedin options -->
                                                    <?php if ($social['slug'] == "Linkedin") { ?>
                                                        <?php $is_checked = isset($agent['link_type']) ? $agent['link_type'] : "personal"; ?>
                                                        <!-- Advance setting for Custom Link -->
                                                        <div>
                                                            <label class="font-primary text-sm text-cht-gray-150"><?php esc_html_e("LinkedIn", "chaty") ?></label>
                                                            <div class="linkedIn-setting sm:flex space-x-0 sm:space-x-3 space-y-3 sm:space-y-0 items-center">
                                                                <label class="flex items-center font-primary text-cht-gray-150">
                                                                    <input type="radio" <?php checked($is_checked, "personal") ?> name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][link_type]" value="personal">
                                                                    <?php esc_html_e("Personal", "chaty") ?>
                                                                </label>
                                                                <label class="flex items-center font-primary text-cht-gray-150">
                                                                    <input type="radio" <?php checked($is_checked, "company") ?> name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][link_type]" value="company">
                                                                    <?php esc_html_e("Company", "chaty") ?>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                                <?php if ($social['slug'] == "Whatsapp") { ?>
                                                    <div class="Whatsapp-settings advanced-settings">
                                                        <div class="chaty-setting-col flex flex-col gap-1 mt-5">
                                                            <label class="font-primary text-sm text-cht-gray-150">
                                                                <span class="text-cht-gray-150"><?php esc_html_e("Pre Set Message", "chaty") ?></span>
                                                                <span class="icon label-tooltip inline-tooltip" data-title="Add your own pre-set message that's automatically added to the user's message.You can also use merge tags and add the URL or the title of the current visitor's page.E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you">
                                                                    <span>
                                                                        <svg xmlns="http://www.w3.org/2000/svg" class="inline-block" width="20" height="27" viewBox="0 0 20 20" fill="none">
                                                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                                        </svg>
                                                                    </span>
                                                                </span>
                                                            </label>
                                                            <div class="group-custom custom-input-tags relative w-full">
                                                                <div class="pre-message-whatsapp inline-flex relative w-full max-w-[320px]">
                                                                    <?php $pre_set_message = isset($agent['pre_set_message']) ? $agent['pre_set_message'] : ""; ?>
                                                                    <div class="inline-flex relative w-full">
                                                                        <input id="cht_social_message_<?php echo esc_attr($social['slug']); ?>_pre_set_message_agent<?php echo esc_attr($count) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][pre_set_message]" class="pre-set-message-whatsapp add-custom-tags chaty-input-text <?php echo esc_attr(!$this->is_pro() ? 'pointer-events-none' : '') ?>" value="<?php echo esc_attr($pre_set_message) ?>" <?php echo esc_attr(!$this->is_pro() ? 'disabled' : '') ?> >
                                                                        <button data-button="cht_social_message_<?php echo esc_attr($social['slug']); ?>" class="wp-pre-set-emoji-agent" id="wp_pre_set_emoji_agent" type="button">
                                                                            <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/icon-picker.png"); ?>" alt="icon picker">
                                                                        </button>
                                                                    </div>
                                                                </div>

                                                                <?php include "custom-tags.php" ?>
                                                                <?php if (!$this->is_pro()) : ?>
                                                                    <div class="backdrop-blur-sm absolute left-0 top-0 w-full h-full opacity-0 group-custom-hover:opacity-100">
                                                                        <a class="bg-cht-primary focus:text-white text-base py-1.5 px-2 rounded-[4px] text-white hover:text-white text-center w-[208px] absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                                                            <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                                                        </a>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php $use_whatsapp_web = isset($agent['use_whatsapp_web']) ? $agent['use_whatsapp_web'] : "yes"; ?>
                                                    <div class="Whatsapp-settings advanced-settings">
                                                        <div class="chaty-setting-col flex flex-col gap-1 mt-3">
                                                            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][use_whatsapp_web]" value="no"/>
                                                            <label class="flex mt-1 items-center chaty-switch text-sm text-cht-gray-150 full-width" for="cht_social_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($count) ?>_use_whatsapp_web_agent">
                                                                <input class="sr-only" type="checkbox" id="cht_social_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($count) ?>_use_whatsapp_web_agent" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][<?php echo esc_attr($count) ?>][use_whatsapp_web]" value="yes" <?php echo checked($use_whatsapp_web, "yes") ?> />
                                                                <div class="chaty-slider round"></div>
                                                                <?php esc_html_e("Use Whatsapp Web directly on desktop", "chaty") ?>
                                                                <span class="header-tooltip">
                                                                    <span class="header-tooltip-text text-center"><?php esc_html_e("If unchecked, visitors will be redirected to chat with you via the WhatsApp desktop app. Please note if they don't have it installed, they'll be redirected to WhatsApp Web", 'chaty');?></span>
                                                                    <span>
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                                        </svg>
                                                                    </span>
                                                                </span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </li>
                                    <?php
                                    $count++;
                                }//end if
                            }//end foreach
                        }//end if
                        ?>
                    </ul>
                </div>
                <div class="add-agent-button">
                    <button type="button" class="add-new-button space-x-2 flex items-center bg-white border border-solid border-gray-150 py-2.5 px-3.5 rounded-lg text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60" data-slug="<?php echo esc_attr($social['slug']) ?>">
                        <svg width="20" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M7 2C5.073 2 3.5 3.573 3.5 5.5C3.5 6.705 4.115 7.776 5.047 8.4065C3.2635 9.1715 2 10.94 2 13H3C3 10.785 4.785 9 7 9C7.688 9 8.327 9.179 8.89 9.485C8.31402 10.1966 7.99984 11.0845 8 12C8 14.203 9.797 16 12 16C14.203 16 16 14.203 16 12C16 9.797 14.203 8 12 8C11.1575 8.00113 10.337 8.26892 9.656 8.765C9.435 8.6265 9.196 8.51 8.953 8.406C9.42886 8.08508 9.81873 7.65233 10.0884 7.14568C10.3582 6.63904 10.4995 6.07396 10.5 5.5C10.5 3.573 8.927 2 7 2ZM7 3C8.3865 3 9.5 4.1135 9.5 5.5C9.5 6.8865 8.3865 8 7 8C5.6135 8 4.5 6.8865 4.5 5.5C4.5 4.1135 5.6135 3 7 3ZM12 9C13.663 9 15 10.337 15 12C15 13.663 13.663 15 12 15C10.337 15 9 13.663 9 12C9 10.337 10.337 9 12 9ZM11.5 10V11.5H10V12.5H11.5V14H12.5V12.5H14V11.5H12.5V10H11.5Z" fill="currentColor"/>
                        </svg>
                        <span>
                            <?php
                            $button_text = ($social['slug'] == 'Discord') ? esc_html__('Add new Agent or Channel', 'chaty') : esc_html__('Add new Agent', 'chaty');
                            echo esc_html($button_text);
                            ?>
                        </span>
                    </button>
                </div>
            </div>
            <div style="display: none" class="default-agent-setting">
                <div class="agent-channel-setting" id="agent-<?php echo esc_attr($slug) ?>-__count__" data-item="__count__">
                    <div class="agent-channel-setting-top px-2 sm:pl-3 sm:pr-5">

                        <div class="flex items-center">
                            <div class="move-channel-icon transition duration-200">
                                <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>"/>
                            </div>
                            <div class="agent-icon" id="image_agent_data_<?php echo esc_attr($social['slug']) ?>-__count__">
                                        <span style="" class="custom-agent-image rounded-full overflow-hidden custom-agent-image-<?php echo esc_attr($social['slug']) ?>-__count__">
                                            <img class="agent-image w-full h-full object-cover" src="<?php echo esc_url($imageUrl) ?>"/>
                                            <span class="remove-agent-img"></span>
                                            <input class="image-id" id="cht_social_agent_image_<?php echo esc_attr($social['slug']); ?>-__count__" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][image_id]" value=""/>
                                        </span>
                                <span class="default-agent-icon custom-agent-icon-<?php echo esc_attr($social['slug']) ?>-__count__ default_agent_image_<?php echo esc_attr($social['slug']) ?>-__count__">
                                            <?php echo $svg_icon; ?>
                                        </span>
                                <span class="facustom-icon flex items-center justify-center" style="background-color: <?php echo esc_attr($social['color']) ?>"></span>
                                <span class="agent-info-image header-tooltip">
                                            <span class="header-tooltip-text text-center">
                                                <?php if (isset($social['header_help'])) {
                                                    echo "<span class='agent-viber-note'>" . esc_attr($social['header_help']) . "</span>";
                                                } ?>
                                                <?php esc_html_e("This channel is an instance of the main channel", "chaty") ?>
                                            </span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span>
                                <input class="fa-icon" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][agent_fa_icon]" value="">
                                <span class="remove-icon-img remove-img-icon" data-slug="<?php echo esc_attr($social['slug']) ?>-__count__"></span>
                            </div>
                        </div>

                        <div class="flex-auto">
                            <div class="agent-channel-input">
                                <div class="p-relative agent-<?php echo esc_attr($social['slug']) ?>-btn test-btn">
                                    <input placeholder="<?php echo esc_attr($social['example']); ?>" class="agent-input-value <?php echo ($social['slug'] == "") ? "chaty-whatsapp-phone-alt" : "" ?> custom-agent-channel-<?php echo esc_attr($social['slug']) ?>" id="cht_social_agent_<?php echo esc_attr($social['slug']); ?>___count__" data-id="__count__" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][value]">
                                    <?php if ($social['slug'] == 'Whatsapp') { ?>
                                        <span class="header-tooltip-text text-center leading-zero-msg">
                                            <span class="close-msg-box">
                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 1L1 11M1 1L11 11" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            </span>
                                            You entered the phone number with a leading zero. We've fixed it for you
                                        </span>
                                    <?php } ?>
                                    <?php if ($social['slug'] == 'Whatsapp' || $social['slug'] == 'Facebook_Messenger') { ?>
                                        <button type="button" class="wf-test-button" data-slug="<?php echo esc_attr($social['slug']) ?>"><?php esc_html_e('Test', 'chaty') ?></button>
                                    <?php } ?>
                                </div>
                                <div class="chaty-agent-setting-col">
                                    <div>
                                        <!-- input for custom title -->
                                        <?php $placeholder = ($social['slug'] == 'Discord') ? esc_html__('Agent Name & Title or Channel Name', 'chaty') : esc_html__('Agent Name & Title', 'chaty'); ?>
                                        <input placeholder="<?php echo esc_attr($placeholder); ?>" type="text" class="chaty-agent-name" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][agent_title]" value="">
                                    </div>
                                </div>
                                <div class="clear clearfix"></div>
                            </div>
                            <div class="agent-channel-setting-btn mt-2 inline-block">
                                <button type="button" class="agent-channel-setting-button">
                                    <span class="dashicons dashicons-admin-generic"></span>
                                    <?php esc_html_e("Settings", 'chaty') ?>
                                </button>
                            </div>
                        </div>

                        <button type="button" class="remove-agent-btn absolute right-2 -top-1 text-cht-gray-150 hover:text-cht-red">
                            <svg class="pointer-events-none" data-v-1cf7b632="" width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" svg-inline="" focusable="false" tabindex="-1">
                                <path data-v-1cf7b632="" d="M2 4h12M5.333 4V2.667a1.333 1.333 0 011.334-1.334h2.666a1.333 1.333 0 011.334 1.334V4m2 0v9.333a1.334 1.334 0 01-1.334 1.334H4.667a1.334 1.334 0 01-1.334-1.334V4h9.334z" stroke="#49687E" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="agent-channel-setting-advance hidden">
                        <div class="grid grid-cols-2 gap-5">

                            <div>
                                <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Custom Image", "chaty") ?></label>
                                <a onclick="upload_chaty_agent_image('<?php echo esc_attr($social['slug']); ?>-__count__')" href="#" class="upload-chaty-icon bg-white border border-solid border-gray-150 py-1 px-3 rounded-md text-sm text-cht-gray-150 cursor-pointer inline-block hover:border-cht-gray-150/60">Upload
                                    Image</a>
                            </div>

                            <div>
                                <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Icon Appearance", "chaty") ?></label>
                                <input type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][agent_bg_color]" class="chaty-color-field-agent agent-icon-color" value="<?php echo esc_attr($social['color']) ?>"/>
                            </div>

                            <div>
                                <label class="font-priamry text-cht-gray-150 text-sm mb-2 block"><?php esc_html_e("Change Icon", "chaty") ?></label>
                                <div class="icon-picker-wrap-agent bg-white border border-solid border-gray-150 py-1 px-3 rounded-md text-sm text-cht-gray-150 cursor-pointer hover:border-cht-gray-150/60 inline-block" id="agent-icon-picker-<?php echo esc_attr($social['slug']); ?>-__count__" data-slug="<?php echo esc_attr($social['slug']); ?>-__count__">
                                    <div id='select-agent-icon-<?php echo esc_attr($social['slug']); ?>-__count__' class="select-icon">
                                        <span class="custom-icon">Select Icon</span>
                                    </div>
                                </div>
                            </div>

                            <?php if ($social['slug'] == "Linkedin") { ?>                                    <div>
                                <label class="font-primary text-sm text-cht-gray-150"><?php esc_html_e("LinkedIn", "chaty") ?></label>
                                <div class="linkedIn-setting sm:flex space-x-0 sm:space-x-3 space-y-3 sm:space-y-0">
                                    <label class="flex items-center font-primary text-cht-gray-150">
                                        <input type="radio" checked name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][link_type]" value="personal">
                                        <?php esc_html_e("Personal", "chaty") ?>
                                    </label>
                                    <label class="flex items-center font-primary text-cht-gray-150">
                                        <input type="radio" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][link_type]" value="company">
                                        <?php esc_html_e("Company", "chaty") ?>
                                    </label>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <?php if ($social['slug'] == "Whatsapp") { ?>
                            <div class="Whatsapp-settings advanced-settings">
                                <div class="chaty-setting-col flex flex-col gap-1 mt-5">
                                    <label class="font-primary text-sm text-cht-gray-150">
                                        <span class="text-cht-gray-150"><?php esc_html_e("Pre Set Message", "chaty") ?></span>
                                        <span class="icon label-tooltip inline-tooltip" data-title="Add your own pre-set message that's automatically added to the user's message.You can also use merge tags and add the URL or the title of the current visitor's page.E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you">
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" class="inline-block" width="20" height="27" viewBox="0 0 20 20" fill="none">
                                                    <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </span>
                                        </span>
                                    </label>
                                    <div class="group-custom custom-input-tags relative w-full">
                                        <div class="pre-message-whatsapp inline-flex relative w-full max-w-[320px]">
                                            <input id="cht_social_message_<?php echo esc_attr($social['slug']); ?>_pre_set_message_agent__count__" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][pre_set_message]" class="pre-set-message-whatsapp add-custom-tags chaty-input-text <?php echo esc_attr(!$this->is_pro() ? 'pointer-events-none' : '') ?>" value="" <?php echo esc_attr(!$this->is_pro() ? 'disabled' : '') ?> >
                                            <button data-button="cht_social_message_<?php echo esc_attr($social['slug']); ?>" class="wp-pre-set-emoji-agent" id="wp_pre_set_emoji_agent" type="button">
                                                <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/icon-picker.png"); ?>" alt="icon picker">
                                            </button>
                                        </div>

                                        <?php include "custom-tags.php" ?>
                                        <?php if (!$this->is_pro()) : ?>
                                            <div class="backdrop-blur-sm absolute left-0 top-0 w-full h-full opacity-0 group-custom-hover:opacity-100">
                                                <a class="bg-cht-primary focus:text-white text-base py-1.5 px-2 rounded-[4px] text-white hover:text-white text-center w-[208px] absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                                    <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="Whatsapp-settings advanced-settings">
                                <div class="chaty-setting-col flex flex-col gap-1 mt-3">
                                    <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][use_whatsapp_web]" value="no"/>
                                    <label class="flex mt-1 items-center chaty-switch text-sm text-cht-gray-150 full-width" for="cht_social_<?php echo esc_attr($social['slug']); ?>___count___use_whatsapp_web_agent">
                                        <input class="sr-only" type="checkbox" id="cht_social_<?php echo esc_attr($social['slug']); ?>___count___use_whatsapp_web_agent" name="cht_social_<?php echo esc_attr($social['slug']); ?>[agent_data][__count__][use_whatsapp_web]" value="yes" />
                                        <div class="chaty-slider round"></div>
                                        <?php esc_html_e("Use Whatsapp Web directly on desktop", "chaty") ?>
                                        <span class="header-tooltip">
                                            <span class="header-tooltip-text text-center"><?php esc_html_e("If unchecked, visitors will be redirected to chat with you via the WhatsApp desktop app. Please note if they don't have it installed, they'll be redirected to WhatsApp Web", 'chaty');?></span>
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                    <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
?>