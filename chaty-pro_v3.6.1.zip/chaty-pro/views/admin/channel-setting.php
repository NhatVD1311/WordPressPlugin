<?php

$imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
if (empty($value)) {
    // Initialize default values if not found
    $value = [
        'value' => '',
        'is_mobile' => 'checked',
        'is_desktop' => 'checked',
        'image_id' => '',
        'title' => $social['title'],
        'bg_color' => "",
    ];
}

$is_pro = $this->is_pro();
$disabled = "";
if (!$is_pro) {
    $disabled = "disabled";
}

if (!isset($value['value'])) {
    $value['value'] = "";
}

if (!isset($value['bg_color']) || empty($value['bg_color'])) {
    $value['bg_color'] = $social['color'];
    // Initialize background color value if not exists. 2.1.0 change
}

if ($social['slug'] == "Twitter" && ($value['bg_color'] == "#1ab2e8" || $value['bg_color'] == "rgb(26, 178, 232)")) {
    $value['bg_color'] = "#000000";
}
$value['bg_color'] = $this->validate_color($value['bg_color'], $social['color']);

if (!isset($value['image_id'])) {
    $value['image_id'] = '';
    // Initialize custom image id if not exists. 2.1.0 change
}

if (!isset($value['title'])) {
    $value['title'] = $social['title'];
    // Initialize title if not exists. 2.1.0 change
}

if (!isset($value['fa_icon'])) {
    $value['fa_icon'] = "";
    // Initialize title if not exists. 2.1.0 change
}

$is_agent = 0;
if (isset($value['is_agent'])) {
    $is_agent = $value['is_agent'];
    // Initialize title if not exists. 2.1.0 change
}

$color = "";
if (!empty($value['bg_color'])) {
    $color = "background-color: " . esc_attr($value['bg_color']);
    // set background color of icon it it is exists
}

if ($social['slug'] == "Whatsapp") {
//    $val            = $value['value'];
//    $val            = str_replace("+", "", $val);
//    $value['value'] = $val;
} else if ($social['slug'] == "Facebook_Messenger") {
    $val = $value['value'];
    $val = str_replace("facebook.com", "m.me", $val);
    // Replace facebook.com with m.me version 2.0.1 change
    $val = str_replace("www.", "", $val);
    // Replace www. with blank version 2.0.1 change
    $value['value'] = $val;

    $val = trim($val, "/");
    $val_array = explode("/", $val);
    $total = (count($val_array) - 1);
    $last_value = $val_array[$total];
    $last_value = explode("-", $last_value);
    $total_text = (count($last_value) - 1);
    $total_text = $last_value[$total_text];

    if (is_numeric($total_text)) {
        $val_array[$total] = $total_text;
        $value['value'] = implode("/", $val_array);
    }
}//end if

$value['value'] = esc_attr(wp_unslash($value['value']));
$value['title'] = esc_attr(wp_unslash($value['title']));

$svg_icon = $social['svg'];

$help_title = "";
$help_text = "";
$help_link = "";

if ((isset($social['help']) && !empty($social['help'])) || isset($social['help_link'])) {
    $help_title = isset($social['help_title']) ? $social['help_title'] : "Doesn't work?";
    $help_text = isset($social['help']) ? $social['help'] : "";
    if (isset($social['help_link']) && !empty($social['help_link'])) {
        $help_link = $social['help_link'];
    }
}

$channel_type = "";
$placeholder = $social['example'];
if ($social['slug'] == "Link" || $social['slug'] == "Custom_Link" || $social['slug'] == "Custom_Link_3" || $social['slug'] == "Custom_Link_4" || $social['slug'] == "Custom_Link_5") {
    if (isset($value['channel_type'])) {
        $channel_type = esc_attr(wp_unslash($value['channel_type']));
    }

    if (!empty($channel_type)) {
        foreach ($this->socials as $icon) {
            if ($icon['slug'] == $channel_type) {
                $svg_icon = $icon['svg'];

                $placeholder = $icon['example'];

                if ((isset($icon['help']) && !empty($icon['help'])) || isset($icon['help_link'])) {
                    $help_title = isset($icon['help_title']) ? $icon['help_title'] : "Doesn't work?";
                    $help_text = isset($icon['help']) ? $icon['help'] : "";
                    if (isset($icon['help_link']) && !empty($icon['help_link'])) {
                        $help_link = $icon['help_link'];
                    }
                }
            }
        }
    }
}//end if

if (empty($channel_type)) {
    $channel_type = $social['slug'];
}

$imageId = $value['image_id'];
$value['fa_icon'] = isset($value['fa_icon']) ? $value['fa_icon'] : "";
$imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
$imgClass = "";
if (!empty($value['fa_icon'])) {
    $imgClass = "icon-active";
} else {
    if (!empty($imageId)) {
        $imageUrl = wp_get_attachment_image_src($imageId, "full")[0];
        // get custom image URL if exists
        if ($imageUrl == "") {
            $imageUrl = CHT_PLUGIN_URL . "admin/assets/images/chaty-default.png";
            // Initialize with default image if custom image is not exists
        } else {
            $imgClass = "img-active";
        }
    }
}

// Check if the 'value' field is not empty
if (!empty($value['value'])) {

    // Extract the social slug for readability
    $socialSlug = $social['slug'];

    // Check if the social slug is one of the specified values
    if ($socialSlug == "Whatsapp" || $socialSlug == "Phone" || $socialSlug == "SMS") {
        // Clean the 'value' field for numbers
        $value['value'] = $this->cleanStringForNumbers($value['value']);
    }

    // Check if the social slug is "Whatsapp"
    if ($socialSlug == "Whatsapp") {
        // Remove leading '+' and then prepend '+'
        $value['value'] = "+" . ltrim($value['value'], "+");
    }

    // Social slugs that require numeric formatting
    $numericSocials = ["Whatsapp", "SMS", "Viber"];

    // Social slugs that require username formatting
    $usernameSocials = ["Telegram", "Snapchat", "TikTok"];

    // Check if the current social slug requires numeric formatting
    if (in_array($socialSlug, $numericSocials)) {
        // Remove unwanted characters and prepend '+'
        $val = str_replace(["+", "-", " "], "", $value['value']);

        if (is_numeric($val)) {
            $value['value'] = "+" . $val;
        }
    }
}
$allowedTags = array(
    'a' => [
        'href' => [],
        'title' => [],
        'target' => []
    ],
    'br' => [],
    'em' => [],
    'strong' => [],
);
?>
<!-- Social media setting box: start -->
<li data-id="<?php echo esc_attr($social['slug']) ?>" class="chaty-channel group <?php echo ($is_agent == 1) ? "has-agent-view" : "" ?>" data-type="<?php echo esc_attr($social['slug']) ?>" data-channel="<?php echo esc_attr($channel_type) ?>" id="chaty-social-<?php echo esc_attr($social['slug']) ?>">
    <!-- channel visual fields start -->
    <div class="channels-selected__item <?php echo esc_attr(($this->is_pro()) ? 'pro' : 'free'); ?> 1 available">
        <div class="chaty-default-settings flex gap-3">
            <div class="flex relative">
                <!-- draggable element -->
                <div class="move-icon mt-2 mr-1 transition duration-200 self-start opacity-0 group-hover:opacity-100">
                    <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>">
                </div>

                <div class="icon chaty-icon icon-md active <?php echo esc_attr($imgClass) ?>" data-title="<?php echo esc_attr($social['title']); ?>" id="chaty_image_<?php echo esc_attr($social['slug']) ?>">
                    <span style="" class="custom-chaty-image custom-image-<?php echo esc_attr($social['slug']) ?>" id="image_data_<?php echo esc_attr($social['slug']) ?>">
                        <img src="<?php echo esc_url($imageUrl) ?>"/>
                    </span>
                    <span class="default-chaty-icon chaty-main-svg">
                        <?php echo $svg_icon; ?>
                    </span>
                    <span class="facustom-icon flex items-center justify-center" style="background-color: <?php echo esc_attr($value['bg_color']) ?>">
                        <i class="<?php echo esc_attr($value['fa_icon']) ?>"></i>
                    </span>
                    <span onclick="remove_chaty_image('<?php echo esc_attr($social['slug']) ?>')" class="remove-icon-img"></span>
                    <input class="fa-icon" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[fa_icon]" value="<?php echo esc_attr($value['fa_icon']) ?>">
                </div>

                <?php if (isset($social['header_help']) && !empty($social['header_help'])) { ?>
                    <span class="header-tooltip header-icon-tooltip">
                        <span class="header-tooltip-text text-center"><?php echo esc_attr($social['header_help']) ?></span>
                        <span class="ml-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </span>
                <?php } ?>
            </div>

            <div class="flex-auto space-y-1">
                <?php if ($social['slug'] != 'Contact_Us') { ?>
                    <?php if (($social['slug'] == "Whatsapp" || $channel_type == "Whatsapp") && !empty($value['value'])) {
                        if ($value['value'][1] == "0") {
                            $value['value'][1] = " ";
                            $value['value'] = str_replace(' ', '', $value['value']);
                        }
                    } ?>
                    <!-- Social Media input  -->
                    <div class="channels__input-box mb-1">
                        <div class="p-relative test-btn">
                            <input data-label="<?php echo esc_attr($social['title']) ?>" placeholder="<?php echo esc_attr($placeholder); ?>" type="text" class="w-11/12 channels__input custom-channel-<?php echo esc_attr($channel_type) ?> <?php echo isset($social['attr']) ? esc_attr($social['attr']) : "" ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[value]" value="<?php echo esc_attr(wp_unslash($value['value'])); ?>" data-gramm_editor="false" id="channel_input_<?php echo esc_attr($social['slug']); ?>"/>
                            <?php if ($social['slug'] == "Whatsapp") { ?>
                                <span class="header-tooltip-text text-center leading-zero-msg">
                                    <span class="close-msg-box">
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 1L1 11M1 1L11 11" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                    </span>
                                    You entered the phone number with a leading zero. We've fixed it for you
                                </span>
                            <?php } ?>
                            <?php if ($social['slug'] == 'Whatsapp' || $social['slug'] == 'Facebook_Messenger') { ?>
                                <button type="button" class="wf-test-button <?php echo !empty($value['value']) ? "active" : "" ?>" data-slug="<?php echo esc_attr($social['slug']) ?>"><?php esc_html_e('Test', 'chaty') ?></button>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- checking for extra help message for social media -->

                    <?php if ((isset($social['help']) && !empty($social['help'])) || isset($social['help_link'])) { ?>
                        <div class="help-section inline-block relative">
                            <div class="viber-help">
                                <?php if (isset($help_link) && !empty($help_link)) { ?>
                                    <a class="help-link" href="<?php echo esc_url($help_link) ?>" target="_blank"><?php echo esc_attr($help_title); ?></a>
                                <?php } else if (isset($help_text) && !empty($help_text)) { ?>
                                    <span class="help-text"><?php echo wp_kses($help_text, $allowedTags); ?></span>
                                    <span class="help-title"><?php echo esc_attr($help_title); ?></span>
                                <?php } ?>
                            </div>
                        </div>
                    <?php
                    }
                }//end if
                include 'contact-form-settings.php';
                ?>
            </div>
        </div>
        <?php if ($social['slug'] == 'Contact_Us') { ?>
            <div class="custom-field-setting chaty-contact-form-field-option">
                <a class="flex items-center space-x-1.5 add-custom-field" href="#" data-isactive="<?php echo (!$is_pro) ? "0" : "1"; ?>" data-active-page-url="<?php echo (!$is_pro) ? esc_url($this->getUpgradeMenuItemUrl()) : ''; ?>">
                    <span>
                        <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10 6V14M6 10H14M5.8 19H14.2C15.8802 19 16.7202 19 17.362 18.673C17.9265 18.3854 18.3854 17.9265 18.673 17.362C19 16.7202 19 15.8802 19 14.2V5.8C19 4.11984 19 3.27976 18.673 2.63803C18.3854 2.07354 17.9265 1.6146 17.362 1.32698C16.7202 1 15.8802 1 14.2 1H5.8C4.11984 1 3.27976 1 2.63803 1.32698C2.07354 1.6146 1.6146 2.07354 1.32698 2.63803C1 3.27976 1 4.11984 1 5.8V14.2C1 15.8802 1 16.7202 1.32698 17.362C1.6146 17.9265 2.07354 18.3854 2.63803 18.673C3.27976 19 4.11984 19 5.8 19Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>
                    </span>
                    <span>Add Custom Field</span>
                </a>
            </div>
        <?php } ?>
        <?php include 'whatsapp-settings.php'; ?>
        <!-- device/agent/settings -->
        <div class="device-agent-settings mt-2">
            <div class="channels__device-box ml-2 chaty-setting-col flex flex-row items-center gap-1">
                <label class="font-primary text-sm text-cht-gray-150"><?php esc_html_e("Show on", "chaty") ?></label>
                <div class="device-box">
                    <?php
                    $slug = esc_attr($this->del_space($social['slug']));
                    $slug = str_replace(' ', '_', $slug);
                    $is_desktop = isset($value['is_desktop']) && $value['is_desktop'] == "checked" ? "checked" : '';
                    $is_mobile = isset($value['is_mobile']) && $value['is_mobile'] == "checked" ? "checked" : '';
                    ?>
                    <!-- setting for desktop -->
                    <label class="device_view cursor-pointer" for="<?php echo esc_attr($slug); ?>Desktop">
                        <input type="checkbox" id="<?php echo esc_attr($slug); ?>Desktop" class="channels__view-check sr-only js-chanel-icon js-chanel-desktop" data-type="<?php echo esc_attr(str_replace(' ', '_', strtolower(esc_attr($this->del_space($social['slug']))))); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_desktop]" value="checked" data-gramm_editor="false" <?php echo esc_attr($is_desktop) ?> />
                        <span class="device-view-txt">
                            <svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.3333 10.0001C14.0667 10.0001 14.6667 9.40008 14.6667 8.66675V2.00008C14.6667 1.26675 14.0667 0.666748 13.3333 0.666748H2.66667C1.93333 0.666748 1.33333 1.26675 1.33333 2.00008V8.66675C1.33333 9.40008 1.93333 10.0001 2.66667 10.0001H0.666667C0.3 10.0001 0 10.3001 0 10.6667C0 11.0334 0.3 11.3334 0.666667 11.3334H15.3333C15.7 11.3334 16 11.0334 16 10.6667C16 10.3001 15.7 10.0001 15.3333 10.0001H13.3333ZM3.33333 2.00008H12.6667C13.0333 2.00008 13.3333 2.30008 13.3333 2.66675V8.00008C13.3333 8.36675 13.0333 8.66675 12.6667 8.66675H3.33333C2.96667 8.66675 2.66667 8.36675 2.66667 8.00008V2.66675C2.66667 2.30008 2.96667 2.00008 3.33333 2.00008Z"/>
                            </svg>
                        </span>
                        <span class="device-tooltip">
                            <span class="on"><?php esc_html_e("Hide on desktop", "chaty") ?></span>
                            <span class="off"><?php esc_html_e("Show on desktop", "chaty") ?></span>
                        </span>
                    </label>

                    <!-- setting for mobile -->
                    <label class="device_view cursor-pointer" for="<?php echo esc_attr($slug); ?>Mobile">
                        <input type="checkbox" id="<?php echo esc_attr($slug); ?>Mobile" class="channels__view-check sr-only js-chanel-icon js-chanel-mobile" data-type="<?php echo esc_attr(str_replace(' ', '_', strtolower(esc_attr($this->del_space($social['slug']))))); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_mobile]" value="checked" data-gramm_editor="false" <?php echo esc_attr($is_mobile) ?> >
                        <span class="device-view-txt">
                            <svg width="9" height="16" viewBox="0 0 9 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.33301 0.666748H1.99967C1.07967 0.666748 0.333008 1.41341 0.333008 2.33341V13.6667C0.333008 14.5867 1.07967 15.3334 1.99967 15.3334H7.33301C8.25301 15.3334 8.99967 14.5867 8.99967 13.6667V2.33341C8.99967 1.41341 8.25301 0.666748 7.33301 0.666748ZM4.66634 14.6667C4.11301 14.6667 3.66634 14.2201 3.66634 13.6667C3.66634 13.1134 4.11301 12.6667 4.66634 12.6667C5.21967 12.6667 5.66634 13.1134 5.66634 13.6667C5.66634 14.2201 5.21967 14.6667 4.66634 14.6667ZM7.66634 12.0001H1.66634V2.66675H7.66634V12.0001Z"/>
                            </svg>
                        </span>
                        <span class="device-tooltip">
                            <span class="on"><?php esc_html_e("Hide on mobile", "chaty") ?></span>
                            <span class="off"><?php esc_html_e("Show on mobile", "chaty") ?></span>
                        </span>
                    </label>
                </div>
            </div>

            <?php if ($this->is_pro()) { ?>
                <?php if ($slug != 'YouTube' && $slug != 'Custom_Link' && $slug != 'Custom_Link_3' && $slug != 'Custom_Link_4' && $slug != 'Custom_Link_5' && $slug != 'Contact_Us' && $slug != 'Link') { ?>
                    <div class="channels__agent-box header-tooltip-show">
                        <a href="#" class="agent-button-action">
                            <svg class="inline" width="14" height="12" viewBox="0 0 14 12" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.25 5.14286C6.69975 5.14286 7.875 3.99159 7.875 2.57143C7.875 1.15127 6.69975 0 5.25 0C3.80025 0 2.625 1.15127 2.625 2.57143C2.625 3.99159 3.80025 5.14286 5.25 5.14286Z" fill="currentColor"/>
                                <path d="M5.25 6.85714C8.1495 6.85714 10.5 9.15968 10.5 12H0C0 9.15968 2.35051 6.85714 5.25 6.85714Z" fill="currentColor"/>
                                <path d="M12.25 3.42857C12.25 2.95518 11.8582 2.57143 11.375 2.57143C10.8918 2.57143 10.5 2.95518 10.5 3.42857V4.28571H9.625C9.14175 4.28571 8.75 4.66947 8.75 5.14286C8.75 5.61624 9.14175 6 9.625 6H10.5V6.85714C10.5 7.33053 10.8918 7.71429 11.375 7.71429C11.8582 7.71429 12.25 7.33053 12.25 6.85714V6H13.125C13.6082 6 14 5.61624 14 5.14286C14 4.66947 13.6082 4.28571 13.125 4.28571H12.25V3.42857Z" fill="currentColor"/>
                            </svg> <?php esc_html_e("Add Agents", "chaty"); ?>
                        </a>
                    </div>
                <?php } else { ?>
                    <div class="channels__agent-box transparent hidden header-tooltip-show">
                        <a href="#" class="agent-button-action">
                            <svg width="14" height="12" viewBox="0 0 14 12" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.25 5.14286C6.69975 5.14286 7.875 3.99159 7.875 2.57143C7.875 1.15127 6.69975 0 5.25 0C3.80025 0 2.625 1.15127 2.625 2.57143C2.625 3.99159 3.80025 5.14286 5.25 5.14286Z" fill="currentColor"/>
                                <path d="M5.25 6.85714C8.1495 6.85714 10.5 9.15968 10.5 12H0C0 9.15968 2.35051 6.85714 5.25 6.85714Z" fill="currentColor"/>
                                <path d="M12.25 3.42857C12.25 2.95518 11.8582 2.57143 11.375 2.57143C10.8918 2.57143 10.5 2.95518 10.5 3.42857V4.28571H9.625C9.14175 4.28571 8.75 4.66947 8.75 5.14286C8.75 5.61624 9.14175 6 9.625 6H10.5V6.85714C10.5 7.33053 10.8918 7.71429 11.375 7.71429C11.8582 7.71429 12.25 7.33053 12.25 6.85714V6H13.125C13.6082 6 14 5.61624 14 5.14286C14 4.66947 13.6082 4.28571 13.125 4.28571H12.25V3.42857Z" fill="currentColor"/>
                            </svg> <?php esc_html_e("Add Agents", "chaty"); ?>
                        </a>
                    </div>
                <?php }//end if
                ?>
            <?php } else { ?>
                <?php if ($slug != 'Custom_Link' && $slug != 'Custom_Link_3' && $slug != 'Custom_Link_4' && $slug != 'Custom_Link_5' && $slug != 'Contact_Us' && $slug != 'Link') { ?>
                    <div class="channels__agent-box relative">
                        <a class="pro-button-wrap px-2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                            <svg class="mr-1" width="14" height="12" viewBox="0 0 14 12" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.25 5.14286C6.69975 5.14286 7.875 3.99159 7.875 2.57143C7.875 1.15127 6.69975 0 5.25 0C3.80025 0 2.625 1.15127 2.625 2.57143C2.625 3.99159 3.80025 5.14286 5.25 5.14286Z" fill="currentColor"/>
                                <path d="M5.25 6.85714C8.1495 6.85714 10.5 9.15968 10.5 12H0C0 9.15968 2.35051 6.85714 5.25 6.85714Z" fill="currentColor"/>
                                <path d="M12.25 3.42857C12.25 2.95518 11.8582 2.57143 11.375 2.57143C10.8918 2.57143 10.5 2.95518 10.5 3.42857V4.28571H9.625C9.14175 4.28571 8.75 4.66947 8.75 5.14286C8.75 5.61624 9.14175 6 9.625 6H10.5V6.85714C10.5 7.33053 10.8918 7.71429 11.375 7.71429C11.8582 7.71429 12.25 7.33053 12.25 6.85714V6H13.125C13.6082 6 14 5.61624 14 5.14286C14 4.66947 13.6082 4.28571 13.125 4.28571H12.25V3.42857Z" fill="currentColor"/>
                            </svg>
                            <?php esc_html_e("Add Agents", "chaty"); ?>
                            <div class="pro-button">
                                <span class="pro-btn bg-cht-primary text-white hover:text-white h-full w-full rounded-md">
                                    <?php esc_html_e('Activate your key', 'chaty'); ?>
                                </span>
                            </div>
                        </a>
                    </div>
                <?php } else { ?>
                    <div class="channels__agent-box relative transparent hidden">
                        <a class="pro-button-wrap" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>" class="agent-button-action">
                            <svg width="14" height="12" viewBox="0 0 14 12" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.25 5.14286C6.69975 5.14286 7.875 3.99159 7.875 2.57143C7.875 1.15127 6.69975 0 5.25 0C3.80025 0 2.625 1.15127 2.625 2.57143C2.625 3.99159 3.80025 5.14286 5.25 5.14286Z" fill="currentColor"/>
                                <path d="M5.25 6.85714C8.1495 6.85714 10.5 9.15968 10.5 12H0C0 9.15968 2.35051 6.85714 5.25 6.85714Z" fill="currentColor"/>
                                <path d="M12.25 3.42857C12.25 2.95518 11.8582 2.57143 11.375 2.57143C10.8918 2.57143 10.5 2.95518 10.5 3.42857V4.28571H9.625C9.14175 4.28571 8.75 4.66947 8.75 5.14286C8.75 5.61624 9.14175 6 9.625 6H10.5V6.85714C10.5 7.33053 10.8918 7.71429 11.375 7.71429C11.8582 7.71429 12.25 7.33053 12.25 6.85714V6H13.125C13.6082 6 14 5.61624 14 5.14286C14 4.66947 13.6082 4.28571 13.125 4.28571H12.25V3.42857Z" fill="currentColor"/>
                            </svg> <?php esc_html_e("Add Agents", "chaty"); ?>
                            <div class="pro-button">
                                <span class="pro-btn bg-cht-primary text-white hover:text-white h-full w-full rounded-md">
                                    <?php esc_html_e('Activate your key', 'chaty'); ?>
                                </span>
                            </div>
                        </a>
                    </div>
                <?php }//end if
                ?>
            <?php }//end if
            ?>

            <?php
            $close_class = "active";
            if ($social['slug'] == 'Contact_Us') {
                $setting_status = get_option("chaty_contact_us_setting");
                if ($setting_status === false) {
                    $close_class = "";
                }
            }
            ?>

            <!-- button for advance setting -->
            <div class="chaty-settings <?php echo esc_attr($close_class) ?>" data-nonce="<?php echo esc_attr(wp_create_nonce($social['slug'] . "-settings")) ?>" id="<?php echo esc_attr($social['slug']); ?>-close-btn" onclick="toggle_chaty_setting('<?php echo esc_attr($social['slug']); ?>')">
                <a class="flex items-center space-x-1.5" href="#">
                    <span>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M8 10C9.10457 10 10 9.10457 10 8C10 6.89543 9.10457 6 8 6C6.89543 6 6 6.89543 6 8C6 9.10457 6.89543 10 8 10Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12.9332 9.99984C12.8444 10.2009 12.818 10.424 12.8572 10.6402C12.8964 10.8565 12.9995 11.056 13.1532 11.2132L13.1932 11.2532C13.3171 11.377 13.4155 11.5241 13.4826 11.6859C13.5497 11.8478 13.5842 12.0213 13.5842 12.1965C13.5842 12.3717 13.5497 12.5452 13.4826 12.7071C13.4155 12.869 13.3171 13.016 13.1932 13.1398C13.0693 13.2638 12.9223 13.3621 12.7604 13.4292C12.5986 13.4963 12.4251 13.5309 12.2498 13.5309C12.0746 13.5309 11.9011 13.4963 11.7392 13.4292C11.5774 13.3621 11.4303 13.2638 11.3065 13.1398L11.2665 13.0998C11.1094 12.9461 10.9098 12.843 10.6936 12.8038C10.4773 12.7646 10.2542 12.7911 10.0532 12.8798C9.85599 12.9643 9.68782 13.1047 9.56937 13.2835C9.45092 13.4624 9.38736 13.672 9.3865 13.8865V13.9998C9.3865 14.3535 9.24603 14.6926 8.99598 14.9426C8.74593 15.1927 8.40679 15.3332 8.05317 15.3332C7.69955 15.3332 7.36041 15.1927 7.11036 14.9426C6.86031 14.6926 6.71984 14.3535 6.71984 13.9998V13.9398C6.71467 13.7192 6.64325 13.5052 6.51484 13.3256C6.38644 13.1461 6.20699 13.0094 5.99984 12.9332C5.79876 12.8444 5.57571 12.818 5.35944 12.8572C5.14318 12.8964 4.94362 12.9995 4.7865 13.1532L4.7465 13.1932C4.62267 13.3171 4.47562 13.4155 4.31376 13.4826C4.15189 13.5497 3.97839 13.5842 3.80317 13.5842C3.62795 13.5842 3.45445 13.5497 3.29258 13.4826C3.13072 13.4155 2.98367 13.3171 2.85984 13.1932C2.73587 13.0693 2.63752 12.9223 2.57042 12.7604C2.50332 12.5986 2.46879 12.4251 2.46879 12.2498C2.46879 12.0746 2.50332 11.9011 2.57042 11.7392C2.63752 11.5774 2.73587 11.4303 2.85984 11.3065L2.89984 11.2665C3.05353 11.1094 3.15663 10.9098 3.19584 10.6936C3.23505 10.4773 3.20858 10.2542 3.11984 10.0532C3.03533 9.85599 2.89501 9.68782 2.71615 9.56937C2.53729 9.45092 2.32769 9.38736 2.11317 9.3865H1.99984C1.64622 9.3865 1.30708 9.24603 1.05703 8.99598C0.80698 8.74593 0.666504 8.40679 0.666504 8.05317C0.666504 7.69955 0.80698 7.36041 1.05703 7.11036C1.30708 6.86031 1.64622 6.71984 1.99984 6.71984H2.05984C2.2805 6.71467 2.49451 6.64325 2.67404 6.51484C2.85357 6.38644 2.99031 6.20699 3.0665 5.99984C3.15525 5.79876 3.18172 5.57571 3.14251 5.35944C3.10329 5.14318 3.00019 4.94362 2.8465 4.7865L2.8065 4.7465C2.68254 4.62267 2.58419 4.47562 2.51709 4.31376C2.44999 4.15189 2.41545 3.97839 2.41545 3.80317C2.41545 3.62795 2.44999 3.45445 2.51709 3.29258C2.58419 3.13072 2.68254 2.98367 2.8065 2.85984C2.93033 2.73587 3.07739 2.63752 3.23925 2.57042C3.40111 2.50332 3.57462 2.46879 3.74984 2.46879C3.92506 2.46879 4.09856 2.50332 4.26042 2.57042C4.42229 2.63752 4.56934 2.73587 4.69317 2.85984L4.73317 2.89984C4.89029 3.05353 5.08985 3.15663 5.30611 3.19584C5.52237 3.23505 5.74543 3.20858 5.9465 3.11984H5.99984C6.19702 3.03533 6.36518 2.89501 6.48363 2.71615C6.60208 2.53729 6.66565 2.32769 6.6665 2.11317V1.99984C6.6665 1.64622 6.80698 1.30708 7.05703 1.05703C7.30708 0.80698 7.64621 0.666504 7.99984 0.666504C8.35346 0.666504 8.6926 0.80698 8.94264 1.05703C9.19269 1.30708 9.33317 1.64622 9.33317 1.99984V2.05984C9.33402 2.27436 9.39759 2.48395 9.51604 2.66281C9.63449 2.84167 9.80266 2.98199 9.99984 3.0665C10.2009 3.15525 10.424 3.18172 10.6402 3.14251C10.8565 3.10329 11.056 3.00019 11.2132 2.8465L11.2532 2.8065C11.377 2.68254 11.5241 2.58419 11.6859 2.51709C11.8478 2.44999 12.0213 2.41545 12.1965 2.41545C12.3717 2.41545 12.5452 2.44999 12.7071 2.51709C12.869 2.58419 13.016 2.68254 13.1398 2.8065C13.2638 2.93033 13.3621 3.07739 13.4292 3.23925C13.4963 3.40111 13.5309 3.57462 13.5309 3.74984C13.5309 3.92506 13.4963 4.09856 13.4292 4.26042C13.3621 4.42229 13.2638 4.56934 13.1398 4.69317L13.0998 4.73317C12.9461 4.89029 12.843 5.08985 12.8038 5.30611C12.7646 5.52237 12.7911 5.74543 12.8798 5.9465V5.99984C12.9643 6.19702 13.1047 6.36518 13.2835 6.48363C13.4624 6.60208 13.672 6.66565 13.8865 6.6665H13.9998C14.3535 6.6665 14.6926 6.80698 14.9426 7.05703C15.1927 7.30708 15.3332 7.64621 15.3332 7.99984C15.3332 8.35346 15.1927 8.6926 14.9426 8.94264C14.6926 9.19269 14.3535 9.33317 13.9998 9.33317H13.9398C13.7253 9.33402 13.5157 9.39759 13.3369 9.51604C13.158 9.63449 13.0177 9.80266 12.9332 9.99984V9.99984Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span><?php esc_html_e("Settings", "chaty") ?></span>
                </a>
            </div>
        </div>

        <!-- advance setting fields: start -->
        <?php $class_name = !$this->is_pro() ? "not-is-pro" : ""; ?>
        <div class="chaty-advance-settings <?php echo esc_attr($class_name); ?>" style="<?php echo (empty($close_class) && $social['slug'] == 'Contact_Us') ? "display:block" : ""; ?>">
            <div class="chaty-channel-setting space-y-4">
                <!-- Settings for custom icon and color -->
                <div class="chaty-setting-col flex flex-col gap-1">
                    <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("Icon Appearance", "chaty") ?></label>
                    <div class="flex items-center">
                        <!-- input for custom color -->
                        <input type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[bg_color]" id="cht_social_<?php echo esc_attr($social['slug']); ?>_bg_color" class="chaty-color-field chaty-bg-color" value="<?php echo esc_attr($value['bg_color']) ?>"/>

                        <div class="flex items-center space-x-2">
                            <!-- button to upload custom image -->
                            <?php if ($this->is_pro()) { ?>
                                <!-- hidden input value for image -->
                                <input id="cht_social_image_<?php echo esc_attr($social['slug']); ?>" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[image_id]" value="<?php echo esc_attr($imageId) ?>"/>

                                <a onclick="upload_chaty_image('<?php echo esc_attr($social['slug']); ?>')" href="#" class="upload-chaty-icon flex items-center px-2"><span class="dashicons dashicons-upload"></span> <span class="hidden sm:inline-block ml-1"><?php esc_html_e("Custom Image", "chaty") ?></span></a>

                                <div class="icon-picker-wrap" id="icon-picker-<?php echo esc_attr($social['slug']); ?>" data-slug="<?php echo esc_attr($social['slug']); ?>">
                                    <div id='select-icon-<?php echo esc_attr($social['slug']); ?>' class="select-icon">
                                        <span class="custom-icon">Change Icon</span>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="pro-features ml-2">
                                    <div class="pro-item">
                                        <a target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>" class="upload-chaty-icon flex items-center px-2"><span class="dashicons dashicons-upload"></span> <span class="hidden sm:inline-block ml-1"><?php esc_html_e("Custom Image", "chaty") ?></span></a>
                                    </div>
                                    <div class="pro-button">
                                        <a class="pro-btn bg-cht-primary text-white hover:text-white h-full w-full rounded-md" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>"><?php esc_html_e('Activate your key', 'chaty'); ?></a>
                                    </div>
                                </div>
                                <div class="pro-features">
                                    <div class="pro-item">
                                        <a target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>" class="upload-chaty-icon upload-icon inline-block px-2"><?php esc_html_e("Change Icon", "chaty") ?></a>
                                    </div>
                                    <div class="pro-button">
                                        <a target="_blank" class="pro-btn bg-cht-primary text-white hover:text-white h-full w-full rounded-md" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>"><?php esc_html_e('Activate your key', 'chaty'); ?></a>
                                    </div>
                                </div>
                            <?php }//end if
                            ?>
                        </div>

                    </div>
                </div>
                <div class="clear clearfix"></div>

                <?php if ($social['slug'] == "Link" || $social['slug'] == "Custom_Link" || $social['slug'] == "Custom_Link_3" || $social['slug'] == "Custom_Link_4" || $social['slug'] == "Custom_Link_5") {
                    $channel_type = "";
                    if (isset($value['channel_type'])) {
                        $channel_type = esc_attr(wp_unslash($value['channel_type']));
                    } else {
                        $channel_type = $social['slug'];
                    }

                    $socials = $this->socials;
                    ?>
                    <div class="chaty-setting-col flex flex-col gap-1">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("Channel type", "chaty") ?></label>
                        <div>
                            <!-- input for custom title -->
                            <select class="channel-select-input min-h-1 !w-full !max-w-[320px]" name="cht_social_<?php echo esc_attr($social['slug']); ?>[channel_type]" value="<?php echo esc_attr($value['channel_type']) ?>">
                                <option value="<?php echo esc_attr($social['slug']) ?>"><?php esc_html_e("Custom channel", "chaty") ?></option>
                                <?php foreach ($socials as $social_icon) {
                                    $selected = ($social_icon['slug'] == $channel_type) ? "selected" : "";
                                    if ($social_icon['slug'] != 'Custom_Link' && $social_icon['slug'] != 'Link' && $social_icon['slug'] != 'Custom_Link_3' && $social_icon['slug'] != 'Custom_Link_4' && $social_icon['slug'] != 'Custom_Link_5' && $social_icon['slug'] != 'Contact_Us' && $social_icon['slug'] != 'Chatway') { ?>
                                        <option <?php echo esc_attr($selected) ?> value="<?php echo esc_attr($social_icon['slug']) ?>"><?php echo esc_attr($social_icon['title']) ?></option>
                                    <?php }
                                } ?>
                            </select>
                        </div>
                    </div>
                    <div class="clear clearfix"></div>
                <?php }//end if
                ?>

                <!-- Settings for custom title -->
                <?php if ($social['slug'] != "WeChat") { ?>
                    <div class="chaty-setting-col flex flex-col gap-1">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("On Hover Text", "chaty") ?>
                            <span class="header-tooltip">
                                <span class="header-tooltip-text text-center"><?php esc_html_e('The text that will appear next to your channel when a visitor hovers over it', 'chaty'); ?></span>
                                <span class="ml-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </span>
                            </span>
                        </label>
                        <div>
                            <!-- input for custom title -->
                            <input type="text" class="chaty-title" name="cht_social_<?php echo esc_attr($social['slug']); ?>[title]" value="<?php echo esc_attr($value['title']) ?>">
                        </div>
                    </div>
                <?php } ?>

                <div class="YouTube-settings advanced-settings">
                    <?php
                    $disabled = !$this->is_pro() ? "disabled" : "";
                    $embedded_video_player = isset($value['embedded_video_player']) ? $value['embedded_video_player'] : "no";
                    $embedded_video_player = ($disabled === 'disabled') ? "" : $embedded_video_player;
                    ?>
                    <div class="chaty-setting-col">
                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[embedded_video_player]" value="no">
                        <label class="chaty-switch chaty-embedded-window font-primary text-cht-gray-150 mt-2 mb-1" for="youtube_embedded_video_player_<?php echo esc_attr($social['slug']); ?>">
                            <input type="checkbox" class="embedded_video_player-checkbox" <?php echo esc_attr($disabled) ?> name="cht_social_<?php echo esc_attr($social['slug']); ?>[embedded_video_player]" id="youtube_embedded_video_player_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($embedded_video_player, "yes") ?> >
                            <div class="chaty-slider round"></div>
                            <div>
                                <?php esc_html_e("Embedded video player", "chaty") ?>
                                <span class="header-tooltip">
                                    <span class="header-tooltip-text text-center"><?php esc_html_e('Play videos directly inside the widget instead of opening a new tab.', 'chaty'); ?></span>
                                    <span class="ml-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                </span>
                            </div>
                            <?php if (!$this->is_pro()) { ?>
                                <a class="pro-btn bg-cht-primary inline-flex items-center gap-1 px-2 py-1 text-white hover:text-white h-full rounded-md" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                    <?php esc_html_e('Activate your key', 'chaty'); ?>
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.33301 8H12.6663" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8 3.33301L12.6667 7.99968L8 12.6663" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                            <?php } ?>
                        </label>
                    </div>
                </div>

                <?php $embedded_window = isset($value['embedded_window']) ? $value['embedded_window'] : "no"; ?>
                <div class="Whatsapp-settings advanced-settings">
                    <div class="chaty-setting-col flex flex-col gap-1 hide-prefilled-setting <?php echo ($embedded_window == "yes") ? "" : "active" ?>">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                            <span><?php esc_html_e("Pre Set Message", "chaty") ?></span>
                            <span class="icon label-tooltip inline-tooltip" data-title="Add your own pre-set message that's automatically added to the user's message. You can also use merge tags and add the URL or the title of the current visitor's page. E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you">
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="inline-block" width="20" height="27" viewBox="0 0 20 20" fill="none"> <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/> <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/> <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/> </svg>
                                </span>
                            </span>
                        </label>
                        <div class="group-custom custom-input-tags relative">
                            <div class="pre-message-whatsapp inline-flex relative w-full max-w-[320px]">
                                <?php $pre_set_message = isset($value['pre_set_message']) ? $value['pre_set_message'] : ""; ?>
                                <input id="cht_social_message_<?php echo esc_attr($social['slug']); ?>_pre_set_message" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[pre_set_message]" class="pre-set-message-whatsapp add-custom-tags chaty-input-text <?php echo esc_attr(!$this->is_pro() ? 'pointer-events-none' : '') ?>" value="<?php echo esc_attr($pre_set_message) ?>" <?php echo esc_attr(!$this->is_pro() ? 'disabled' : '') ?> >
                                <button data-button="cht_social_message_<?php echo esc_attr($social['slug']); ?>" class="wp-pre-set-emoji" id="wp_pre_set_emoji" type="button"> <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/icon-picker.png"); ?>" alt="icon picker"> </button>
                            </div>

                            <?php include "custom-tags.php" ?>
                            <?php if (!$this->is_pro()) : ?>
                                <div class="backdrop-blur-sm absolute left-0 top-0 w-full h-full opacity-0 group-custom-hover:opacity-100">
                                    <a class="bg-cht-primary focus:text-white text-base py-1.5 px-2 rounded-[4px] text-white hover:text-white text-center w-[208px] absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="SMS-settings advanced-settings">
                    <div class="chaty-setting-col flex flex-col gap-1">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                            <span><?php esc_html_e("Pre Set Message", "chaty") ?></span>
                            <span class="icon label-tooltip inline-tooltip" data-title="Add your own pre-set message that's automatically added to the user's message. You can also use merge tags and add the URL or the title of the current visitor's page. E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you">
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="inline-block" width="20" height="27" viewBox="0 0 20 20" fill="none">
                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </span>
                            </span>
                        </label>
                        <div class="group-custom custom-input-tags relative w-full">
                            <div class="pre-message-whatsapp flex relative w-full max-w-[320px]">
                                <?php $sms_pre_set_message = isset($value['sms_pre_set_message']) ? $value['sms_pre_set_message'] : ""; ?>
                                <input id="cht_social_message_<?php echo esc_attr($social['slug']); ?>_sms_pre_set_message" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[sms_pre_set_message]" class="pre-set-message-whatsapp add-custom-tags <?php echo esc_attr(!$this->is_pro() ? 'pointer-events-none' : '') ?>" value="<?php echo esc_attr($sms_pre_set_message) ?>" <?php echo esc_attr(!$this->is_pro() ? 'disabled' : '') ?> >
                            </div>

                            <?php include "custom-tags.php" ?>
                            <?php if (!$this->is_pro()) : ?>
                                <div class="backdrop-blur-sm absolute left-0 top-0 w-full h-full opacity-0 group-custom-hover:opacity-100">
                                    <a class="bg-cht-primary focus:text-white text-base py-1.5 px-2 rounded-[4px] text-white hover:text-white text-center w-[208px] absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php $use_whatsapp_web = isset($value['use_whatsapp_web']) ? $value['use_whatsapp_web'] : "yes"; ?>
                <?php $embedded_window = isset($value['embedded_window']) ? $value['embedded_window'] : "no"; ?>
                <div class="Whatsapp-settings advanced-settings">
                    <div class="chaty-setting-col">
                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[use_whatsapp_web]" value="no">
                        <label class="flex mt-1 items-center chaty-switch text-sm text-cht-gray-150 full-width" for="use_whatsapp_web_<?php echo esc_attr($social['slug']); ?>">
                            <input type="checkbox" class="sr-only" name="cht_social_<?php echo esc_attr($social['slug']); ?>[use_whatsapp_web]" id="use_whatsapp_web_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php echo checked($use_whatsapp_web, "yes") ?> />
                            <div class="chaty-slider round"></div>
                            <?php esc_html_e("Use Whatsapp Web directly on desktop", "chaty") ?>
                            <span class="header-tooltip">
                                <span class="header-tooltip-text text-center"><?php esc_html_e("If unchecked, visitors will be redirected to chat with you via the WhatsApp desktop app. Please note if they don't have it installed, they'll be redirected to WhatsApp Web", 'chaty');?></span>
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </span>
                            </span>
                        </label>
                    </div>
                </div>
                <?php if ($social['slug'] == "Contact_Us") {
                    include 'contact-form.php';
                }//end if
                ?> <?php if ($this->is_pro()) { ?>
                    <div class="Email-settings advanced-settings">
                        <!-- advance setting for Email -->
                        <div class="chaty-setting-col sm:flex items-start sm:space-x-3">
                            <label class="font-primary text-sm text-cht-gray-150 sm:w-44 flex">
                                <?php esc_html_e("Mail Subject", "chaty") ?>
                                <span class="icon label-tooltip inline-tooltip" data-title="<?php esc_html_e("Add your own pre-set message that's automatically added to the user's message. You can also use merge tags and add the URL or the title of the current visitor's page. E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you", "chaty") ?>">
                                    <span class="ml-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                </span>
                            </label>
                            <div>
                                <?php $mail_subject = isset($value['mail_subject']) ? $value['mail_subject'] : ""; ?>
                                <input class="w-full" id="cht_social_message_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[mail_subject]" value="<?php echo esc_attr($mail_subject) ?>">
                                <span class="supported-tags">
                                    <span class="icon label-tooltip support-tooltip" data-title="{title} tag grabs the page title of the webpage">{title}</span>
                                    and
                                    <span class="icon label-tooltip support-tooltip" data-title="{url} tag grabs the URL of the page">{url}</span> tags are supported
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="WeChat-settings advanced-settings">
                        <!-- advance setting for WeChat --> <?php
                        $qr_code = isset($value['qr_code']) ? $value['qr_code'] : "";
                        // Initialize QR code value if not exists. 2.1.0 change
                        $imageUrl = "";
                        $status = 0;
                        if ($qr_code != "") {
                            $imageUrl = wp_get_attachment_image_src($qr_code, "full")[0];
                            // get custom Image URL if exists
                        }

                        if ($imageUrl == "") {
                            $value['qr_code'] = "";
                            // Initialize with default image URL if URL is not exists
                        } else {
                            $status = 1;
                        }
                        ?>
                        <div class="clear clearfix"></div>
                        <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                            <?php $wechat_header = isset($value['wechat_header']) ? $value['wechat_header'] : esc_html__("WeChat ID", "chaty") ?>
                            <div class="chaty-setting-col inline-options">
                                <label class="font-primary text-sm text-cht-gray-150 sm:w-44"> <?php esc_html_e("Heading", "chaty") ?> </label>
                                <div>
                                    <input type="text" class="qr-header-title" id="<?php echo esc_attr($social['slug']); ?>_header_title" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wechat_header]" value="<?php echo esc_attr($wechat_header) ?>">
                                </div>
                            </div>
                            <div class="chaty-setting-col inline-options">
                                <?php
                                $wechat_header_color = isset($value['wechat_header_color']) ? $value['wechat_header_color'] : "#A886CD";
                                $wechat_header_color = $this->validate_color($wechat_header_color, "#A886CD");
                                ?>
                                <label class="font-primary text-sm text-cht-gray-150 sm:w-44"> <?php esc_html_e("Header Background", "chaty") ?> </label>
                                <div>
                                    <input type="text" id="<?php echo esc_attr($social['slug']); ?>_header_color" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wechat_header_color]" class="chaty-color-field button-color wechat-header-color" value="<?php echo esc_attr($wechat_header_color) ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                            <?php $wechat_qr_code_title = isset($value['wechat_qr_code_title']) ? $value['wechat_qr_code_title'] : esc_html__("Scan QR Code", "chaty") ?>
                            <div class="chaty-setting-col inline-options">
                                <label class="font-primary text-sm text-cht-gray-150 sm:w-44"> <?php esc_html_e("QR code heading", "chaty") ?> </label>
                                <div>
                                    <input type="text" class="qr-code-header-title" id="<?php echo esc_attr($social['slug']); ?>_qr_code_title" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wechat_qr_code_title]" value="<?php echo esc_attr($wechat_qr_code_title) ?>">
                                </div>
                            </div>
                        </div>
                        <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                            <div class="chaty-setting-col ">
                                <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("Upload QR Code", "chaty") ?></label>
                                <div class="relative qr-code-setting <?php echo esc_attr($social['slug']); ?>-qr-code-setting <?php echo esc_attr($status ? "active" : "") ?>">
                                    <span class="qr-code-img" id="<?php echo esc_attr($social['slug']); ?>-qr-code-image"> <?php if ($status) { ?>
                                            <img src="<?php echo esc_url($imageUrl) ?>"/> <?php } ?>
                                    </span> <!-- Button to upload QR Code image -->
                                    <a class="cht-upload-image" id="upload_qr_code" href="#" onclick="upload_qr_code('<?php echo esc_attr($social['slug']); ?>')"> <?php esc_html_e("Upload", "chaty") ?> </a>
                                    <!-- Button to remove QR Code image -->
                                    <a href="#" class="remove-qr-code remove-setting-btn remove-qr-code-<?php echo esc_attr($social['slug']); ?>" onclick="remove_qr_code('<?php echo esc_attr($social['slug']); ?>')"> <?php esc_html_e("Remove", "chaty") ?> </a>
                                    <!-- input hidden field for QR Code -->
                                    <input id="upload_qr_code_val-<?php echo esc_attr($social['slug']); ?>" type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[qr_code]" value="<?php echo esc_attr($qr_code) ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Link-settings Custom_Link-settings Custom_Link_3-settings Custom_Link_4-settings Custom_Link_5-settings advanced-settings">
                        <?php $is_checked = (!isset($value['new_window']) || $value['new_window'] == 1) ? 1 : 0; ?>
                        <!-- Advance setting for Custom Link -->
                        <div class="clear clearfix"></div>
                        <div class="chaty-setting-col">
                            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[new_window]" value="0">
                            <label class="chaty-switch chaty-embedded-window font-primary text-sm text-cht-gray-150 mt-2 mb-1" for="cht_social_window_<?php echo esc_attr($social['slug']); ?>">
                                <input type="checkbox" class="embedded_video_player-checkbox" <?php echo esc_attr($disabled) ?> name="cht_social_<?php echo esc_attr($social['slug']); ?>[new_window]" id="cht_social_window_<?php echo esc_attr($social['slug']); ?>" value="1" <?php checked($is_checked, 1) ?> >
                                <div class="chaty-slider round"></div>
                                <span class="text-sm">
                                    <?php esc_html_e("Open in a new tab", "chaty") ?>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="Linkedin-settings advanced-settings">
                        <?php $is_checked = isset($value['link_type']) ? $value['link_type'] : "personal"; ?>
                        <!-- Advance setting for Custom Link -->
                        <div class="chaty-setting-col flex flex-col gap-1">
                            <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("LinkedIn", "chaty") ?></label>
                            <div>
                                <div class="cta-action-radio tab-tab-select bg-cht-gray-50 inline-block rounded-md p-1">
                                    <div class="i-block" for="all_time-cht_cta_action">
                                        <label class="custom-control custom-radio">
                                            <input type="radio" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_type]" class="custom-control-input" <?php checked($is_checked, "personal") ?> value="personal"/>
                                            <span class="custom-control-label px-2 py-1 inline-block text-cht-gray-150 rounded-[3px]"><?php esc_html_e("Personal", "chaty") ?></span>
                                        </label>
                                    </div>
                                    <div class="i-block" for="all_time-cht_cta_action">
                                        <label class="custom-control custom-radio">
                                            <input type="radio" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_type]" class="custom-control-input" <?php checked($is_checked, "company") ?> value="company"/>
                                            <span class="custom-control-label px-2 py-1 inline-block text-cht-gray-150 rounded-[3px]"><?php esc_html_e("Company", "chaty") ?></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="clear clearfix"></div>
                    <div class="Email-settings advanced-settings">
                        <div class="clear clearfix"></div>
                        <div class="chaty-setting-col flex items-start space-x-3">
                            <label class="font-primary text-sm text-cht-gray-150 sm:w-44"><?php esc_html_e("Mail Subject", "chaty") ?>
                                <span class="icon label-tooltip inline-tooltip" data-title="<?php esc_html_e("Add your own pre-set message that's automatically added to the user's message. You can also use merge tags and add the URL or the title of the current visitor's page. E.g. you can add the current URL of a product to the message so you know which product the visitor is talking about when the visitor messages you", "chaty") ?>">
                                    <span class="dashicons dashicons-editor-help"></span>
                                </span>
                            </label>
                            <div>
                                <div class="pro-features">
                                    <div class="pro-item">
                                        <input disabled id="cht_social_message_<?php echo esc_attr($social['slug']); ?>" type="text" name="" value="">
                                        <span class="supported-tags">
                                            <span class="icon label-tooltip support-tooltip" data-title="{title} tag grabs the page title of the webpage">{title}</span>
                                            and
                                            <span class="icon label-tooltip support-tooltip" data-title="{url} tag grabs the URL of the page">{url}</span> tags are supported
                                        </span>
                                    </div>
                                    <div class="pro-button">
                                        <a target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                            <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="WeChat-settings advanced-settings">
                        <div class="clear clearfix"></div>
                        <div class="chaty-setting-col flex items-center space-x-3">
                            <label class="font-primary text-cht-gray-150 text-base w-44">
                                <?php esc_html_e("Upload QR Code", "chaty") ?>
                            </label>
                            <div>
                                <a target="_blank" class="cht-upload-image-pro text-base" id="upload_qr_code" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                    <span class="dashicons dashicons-upload"></span>
                                </a>
                                <a class="text-base text-cht-gray-150 ml-2" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                                    <?php esc_html_e('Activate your license key', 'chaty'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="Link-settings Custom_Link-settings Custom_Link_3-settings Custom_Link_4-settings Custom_Link_5-settings advanced-settings"> <?php $is_checked = 1; ?>
                        <div class="clear clearfix"></div>
                        <div class="chaty-setting-col flex items-center space-x-3">
                            <label class="font-primary text-cht-gray-150 text-base sm:w-44" for="cht_social_window_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Open In a New Tab", "chaty") ?></label>
                            <div class="l-height">
                                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[new_window]" value="0">
                                <label class="channels__view" for="cht_social_window_<?php echo esc_attr($social['slug']); ?>">
                                    <input id="cht_social_window_<?php echo esc_attr($social['slug']); ?>" type="checkbox" class="channels__view-check" name="cht_social_<?php echo esc_attr($social['slug']); ?>[new_window]" value="1" checked>
                                    <span class="channels__view-txt">&nbsp;</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="Linkedin-settings advanced-settings">
                        <?php $is_checked = "personal"; ?>
                        <!-- Advance setting for Custom Link -->
                        <div class="chaty-setting-col flex flex-col gap-1">
                            <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                                <?php esc_html_e("LinkedIn", "chaty") ?>
                            </label>
                            <div class="cta-action-radio tab-tab-select bg-cht-gray-50 inline-block rounded-md p-1">
                                <div for="all_time-cht_cta_action">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_type]" class="custom-control-input" <?php checked($is_checked, "personal") ?> value="personal"/>
                                        <span class="custom-control-label px-2 py-1 inline-block text-cht-gray-150 rounded-[3px]">
                                            <?php esc_html_e("Personal", "chaty") ?>
                                        </span>
                                    </label>
                                </div>
                                <div>
                                    <label class="custom-control custom-radio"> <input type="radio" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_type]" class="custom-control-input" <?php checked($is_checked, "company") ?> value="company"/>
                                    <span class="custom-control-label px-2 py-1 inline-block text-cht-gray-150 rounded-[3px]"><?php esc_html_e("Company", "chaty") ?></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }//end if
                ?>
            </div>
            <!-- advance setting fields: end -->
            <input type="hidden" class="is-agent-active" id="<?php echo esc_attr($social['slug']); ?>_agent" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_agent]" value="<?php echo esc_attr($is_agent) ?>">
            <!-- remove social media setting button: start -->
        </div>
    </div>
    <?php include 'channel-agent.php'; ?>
    <!-- remove button start -->
    <button type="button" class="btn-cancel" data-social="<?php echo esc_attr($social['slug']); ?>">
        <svg class="pointer-events-none" data-v-1cf7b632="" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" svg-inline="" focusable="false" tabindex="-1">
            <path data-v-1cf7b632="" d="M2 4h12M5.333 4V2.667a1.333 1.333 0 011.334-1.334h2.666a1.333 1.333 0 011.334 1.334V4m2 0v9.333a1.334 1.334 0 01-1.334 1.334H4.667a1.334 1.334 0 01-1.334-1.334V4h9.334z" stroke="#49687E" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </button>
    <!-- remove button end -->
</li>
<!-- Social media setting box: end -->


<div class="test-popup" id="Whatsapp_popup" data-label="Whatsapp">
    <div class="test-popup-bg"></div>
    <div class="test-popup-content">
        <button class="test-popup-close-btn" type="button">
            <span class="svg-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M310.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 210.7 54.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L114.7 256 9.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 301.3 265.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L205.3 256 310.6 150.6z"></path></svg>
            </span>
        </button>
        <div class="test-popup-header">
            <span class="divider"></span>
            <span class="title"><?php esc_html_e('WhatsApp test', 'chaty') ?></span>
        </div>
        <div class="test-popup-body">
            <div class="title"><?php esc_html_e('Did we redirect you to the correct Whatsapp link for this number?', 'chaty') ?></div>
            <div class="phone-value"><?php esc_html_e('+91-7485963214', 'chaty') ?></div>
            <div class="popup-btn">
                <button type="button" class="edit-number"><?php esc_html_e('Edit Number', 'chaty') ?></button>
                <button type="button" class="save-btn"><?php esc_html_e('Yes, Correct', 'chaty') ?></button>
            </div>
            <div class="contact-link"><?php esc_html_e('Having trouble? Contact ', 'chaty') ?><a href="#"><?php esc_html_e('Support', 'chaty') ?></a></div>
        </div>
    </div>
</div>

<div class="test-popup" id="Facebook_Messenger_popup" data-label="Facebook_Messenger">
    <div class="test-popup-bg"></div>
    <div class="test-popup-content">
        <button class="test-popup-close-btn" type="button">
            <span class="svg-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M310.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 210.7 54.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L114.7 256 9.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 301.3 265.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L205.3 256 310.6 150.6z"></path></svg>
            </span>
        </button>
        <div class="test-popup-header">
            <span class="divider"></span>
            <span class="title"><?php esc_html_e('Facebook Messenger test', 'chaty') ?></span>
        </div>
        <div class="test-popup-body">
            <div class="title"><?php esc_html_e('Did we redirect you to the correct Facebook Messenger link?', 'chaty') ?></div>
            <div class="phone-value"><?php esc_html_e('m.me/coca-cola', 'chaty') ?></div>
            <div class="popup-btn">
                <button type="button" class="edit-number"><?php esc_html_e('Edit Link', 'chaty') ?></button>
                <button type="button" class="save-btn"><?php esc_html_e('Yes, Correct', 'chaty') ?></button>
            </div>
            <div class="contact-link"><?php esc_html_e('Having trouble? Contact ', 'chaty') ?><a href="#"><?php esc_html_e('Support', 'chaty') ?></a></div>
        </div>
    </div>
</div>
