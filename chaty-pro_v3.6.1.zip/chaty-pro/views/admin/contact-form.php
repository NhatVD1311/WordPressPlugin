<div class="Contact_Us-settings advanced-settings">
    <div class="clear clearfix"></div>
    <div class="form-field-setting-col my-3 space-y-4">
        <div class="chaty-setting-col flex flex-col gap-1">
            <label class="font-primary text-cht-gray-150 text-sm w-44 "><?php esc_html_e("Contact Form Title", "chaty") ?></label>
            <div>
                <?php $contact_form_title = isset($value['contact_form_title']) ? $value['contact_form_title'] : esc_html__("Contact Us", "chaty"); ?>
                <input class="chaty-input-text" id="cht_social_message_<?php echo esc_attr($social['slug']); ?>_form_title" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[contact_form_title]" value="<?php echo esc_attr($contact_form_title) ?>">
            </div>
        </div>
        <?php
        $field_value = isset($value['contact_form_title_bg_color']) ? $value['contact_form_title_bg_color'] : "#A886CD";
        $field_value = $this->validate_color($field_value, "#A886CD");
        ?>
        <div class="chaty-setting-col flex flex-col gap-1">
            <label class="font-primary text-sm text-cht-gray-150 sm:w-44" for="title_bg_color_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Title background color", "chaty") ?></label>
            <div>
                <input id="title_bg_color_for_<?php echo esc_attr($social['slug']); ?>" class="chaty-color-field button-color" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[contact_form_title_bg_color]" value="<?php echo esc_attr($field_value); ?>">
            </div>
        </div>
    </div>
    <div class="field-separator"></div>

    <div class="form-field-setting-col my-3 space-y-4">
        <div class="form-field-title"><?php esc_html_e("Submit Button", "chaty") ?></div>
        <div class="color-box !mt-0">
            <div class="clr-setting">
                <?php
                $field_value = isset($value['button_text_color']) ? $value['button_text_color'] : "#ffffff";
                $field_value = $this->validate_color($field_value, "#ffffff");
                ?>
                <div class="chaty-setting-col flex flex-col gap-1">
                    <label class="font-primary text-sm text-cht-gray-150 sm:w-44" for="button_text_color_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Text color", "chaty") ?></label>
                    <div>
                        <input id="button_text_color_for_<?php echo esc_attr($social['slug']); ?>" class="chaty-color-field button-color" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[button_text_color]" value="<?php echo esc_attr($field_value); ?>">
                    </div>
                </div>
            </div>
            <?php
            $field_value = isset($value['button_bg_color']) ? $value['button_bg_color'] : "#A886CD";
            $field_value = $this->validate_color($field_value, "#A886CD");
            ?>
            <div class="clr-setting mt-2.5">
                <div class="chaty-setting-col flex flex-col gap-1">
                    <label class="font-primary text-sm text-cht-gray-150 sm:w-44" for="button_bg_color_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Background color", "chaty") ?></label>
                    <div>
                        <input id="button_bg_color_for_<?php echo esc_attr($social['slug']); ?>" class="chaty-color-field button-color" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[button_bg_color]" value="<?php echo esc_attr($field_value); ?>">
                    </div>
                </div>
            </div>
        </div>
        <?php $field_value = isset($value['button_text']) ? $value['button_text'] : "Chat" ?>
        <div class="chaty-setting-col flex flex-col gap-1">
            <label class="font-primary text-cht-gray-150 text-sm w-44 " for="button_text_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Button text", "chaty") ?></label>
            <div>
                <input class="chaty-input-text" id="button_text_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[button_text]" value="<?php echo esc_attr($field_value); ?>">
            </div>
        </div>
        <?php $field_value = isset($value['thanks_message']) ? $value['thanks_message'] : "Your message was sent successfully" ?>
        <div class="chaty-setting-col flex flex-col gap-1">
            <label class="font-primary text-cht-gray-150 text-sm w-44 " for="thanks_message_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Thank you message", "chaty") ?></label>
            <div>
                <input class="chaty-input-text" id="thanks_message_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[thanks_message]" value="<?php echo esc_attr($field_value); ?>">
            </div>
        </div>
        <div class="chaty-separator"></div>
        <?php $field_value = isset($value['redirect_action']) ? $value['redirect_action'] : "no" ?>
        <div class="chaty-setting-col">
            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[redirect_action]" value="no">
            <label class="chaty-switch flex items-center" for="redirect_action_<?php echo esc_attr($social['slug']); ?>">
                <input type="checkbox" class="chaty-redirect-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[redirect_action]" id="redirect_action_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($field_value, "yes") ?> >
                <div class="chaty-slider round"></div>
                <span class="font-primary text-cht-gray-150 text-sm"><?php esc_html_e("Redirect visitors after submission", "chaty") ?></span>
            </label>
        </div>
        <div class="redirect_action-settings <?php echo ($field_value == "yes") ? "active" : "" ?>">
            <?php $field_value = isset($value['redirect_link']) ? $value['redirect_link'] : "" ?>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="redirect_link_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Redirect link", "chaty") ?></label>
                <div class="mb-2">
                    <input class="w-full" id="redirect_link_for_<?php echo esc_attr($social['slug']); ?>" placeholder="<?php echo esc_url(site_url("/")) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[redirect_link]" value="<?php echo esc_attr($field_value); ?>">
                </div>
            </div>
            <?php $field_value = isset($value['link_in_new_tab']) ? $value['link_in_new_tab'] : "no" ?>
            <div class="chaty-setting-col">
                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_in_new_tab]" value="no">
                <label class="chaty-switch text-sm text-cht-gray-150" for="link_in_new_tab_<?php echo esc_attr($social['slug']); ?>">
                    <input type="checkbox" class="chaty-field-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[link_in_new_tab]" id="link_in_new_tab_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($field_value, "yes") ?> >
                    <div class="chaty-slider round"></div>
                    <?php esc_html_e("Open in a new tab", "chaty") ?>
                </label>
            </div>
        </div>
        <div class="chaty-separator"></div>
        <?php $field_value = isset($value['close_form_after']) ? $value['close_form_after'] : "no" ?>
        <div class="chaty-setting-col">
            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[close_form_after]" value="no">
            <label class="chaty-switch flex items-center" for="close_form_after_<?php echo esc_attr($social['slug']); ?>">
                <input type="checkbox" class="chaty-close_form_after-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[close_form_after]" id="close_form_after_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($field_value, "yes") ?> >
                <div class="chaty-slider round"></div>
                <span class="font-primary text-cht-gray-150 text-sm"><?php esc_html_e("Close form automatically after submission", "chaty") ?></span>
                <span class="icon label-tooltip inline-message" data-title="<?php esc_html_e("Close the form automatically after a few seconds based on your choice", "chaty") ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
            </label>
        </div>
        <div class="close_form_after-settings <?php echo ($field_value == "yes") ? "active" : "" ?>">
            <?php $field_value = isset($value['close_form_after_seconds']) ? $value['close_form_after_seconds'] : "3" ?>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="close_form_after_seconds_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Close after (Seconds)", "chaty") ?></label>
                <div>
                    <input class="w-full" id="close_form_after_seconds_<?php echo esc_attr($social['slug']); ?>" type="number" name="cht_social_<?php echo esc_attr($social['slug']); ?>[close_form_after_seconds]" value="<?php echo esc_attr($field_value); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="form-field-setting-col no-margin">
        <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_in_email]">
        <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[save_leads_locally]">
        <?php $field_value = isset($value['save_leads_locally']) ? $value['save_leads_locally'] : "yes" ?>
        <div class="chaty-setting-col">
            <label for="save_leads_locally_<?php echo esc_attr($social['slug']); ?>" class="full-width chaty-switch flex items-center text-cht-gray-150 text-sm">
                <input type="checkbox" id="save_leads_locally_<?php echo esc_attr($social['slug']); ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[save_leads_locally]" <?php checked($field_value, "yes") ?> >
                <div class="chaty-slider round"></div>
                Save leads to <a class="text-cht-primary underline" href="<?php echo esc_url(admin_url("admin.php?page=chaty-contact-form-feed")) ?>" target="_blank">this site</a>
                <div class="html-tooltip top no-position">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                    <span class="tooltip-text top">Your leads will be saved in your local database, you'll be able to find them <a target="_blank" href="<?php echo esc_url(admin_url("admin.php?page=chaty-contact-form-feed")) ?>">here</a></span>
                </div>
            </label>
        </div>
        <?php $field_value = isset($value['send_leads_in_email']) ? $value['send_leads_in_email'] : "no" ?>
        <div class="chaty-setting-col mt-3">
            <label for="save_leads_to_email_<?php echo esc_attr($social['slug']); ?>" class="email-setting full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom">
                <input class="email-setting-field" type="checkbox" id="save_leads_to_email_<?php echo esc_attr($social['slug']); ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_in_email]" <?php checked($field_value, "yes") ?> <?php echo esc_attr($disabled) ?>>
                <div class="chaty-slider round"></div>
                <?php esc_html_e("Send leads to your email", "chaty") ?>
                <span class="icon label-tooltip email-tooltip" data-title="Get your leads by email, whenever you get a new email you'll get an email notification">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </span>
                <?php if (!$is_pro) { ?>
                    <a class="opacity-0 px-5 py-1.5 group-custom-hover:opacity-100 ml-4 pro-btn bg-cht-primary inline-block rounded-[6px] text-white hover:text-white" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                    </a>
                <?php } ?>
            </label>
        </div>
        <div class="email-settings <?php echo ($field_value == "yes") ? "active" : "" ?>">
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="email_for_<?php echo esc_attr($social['slug']); ?>">
                    <span><?php esc_html_e("Email address", "chaty") ?></span>
                    <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("If you want to send leads to more than one email address, please add your email addresses separated by commas", "chaty") ?>">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </span>
                </label>
                <div class="pos-relative">
                    <?php $field_value = isset($value['email_address']) ? $value['email_address'] : "" ?>
                    <input class="w-full" id="email_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[email_address]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>>
                    <button type="button" class="more-btn" <?php echo esc_attr($disabled) ?>>CC/BCC
                        <i class='fas fa-arrow-down up-down-arrow'></i></button>
                </div>
            </div>
            <div class="cc-bcc-field <?php echo((!empty($value['cc_email_address']) || !empty($value['bcc_email_address'])) ? "active" : "") ?>">
                <?php $field_value = isset($value['cc_email_address']) ? $value['cc_email_address'] : "" ?>
                <div class="chaty-setting-col cc-field">
                    <label class="font-primary text-cht-gray-150 text-sm" for="cc_email_for_<?php echo esc_attr($social['slug']); ?>">
                        <span><?php esc_html_e("Email address (CC)", "chaty") ?></span>
                        <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("Add emails (comma separated)  to whom you want to send the emails as CC", "chaty") ?>">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </span>
                        </span>
                    </label>
                    <div>
                        <input class="w-full" id="cc_email_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[cc_email_address]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>>
                    </div>
                </div>
                <?php $field_value = isset($value['bcc_email_address']) ? $value['bcc_email_address'] : "" ?>
                <div class="chaty-setting-col bcc-field">
                    <label class="font-primary text-cht-gray-150 text-sm" for="bcc_email_for_<?php echo esc_attr($social['slug']); ?>">
                        <span><?php esc_html_e("Email address (BCC)", "chaty") ?></span>
                        <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("Add emails (comma separated) to whom you want to send the emails as BCC", "chaty") ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </label>
                    <div>
                        <input class="w-full" id="bcc_email_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[bcc_email_address]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>>
                    </div>
                </div>
            </div>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="sender_email_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Sender's email", "chaty") ?>
                    <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("This is the email address from which you will receive each contact form submission email. By default, it is sent from the user's email address. To avoid email rejection, change it to an email address that includes your website domain.", "chaty") ?>"><span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </label>
                <div>
                    <?php $field_value = isset($value['sender_email']) ? $value['sender_email'] : "{email}" ?>
                    <input class="w-full" id="sender_email_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[sender_email]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>>
                </div>
            </div>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="sender_name_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Sender's name", "chaty") ?>
                    <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("The name that will appear as the sender name in your email. Use {name} to dynamically use the name from form submission.", "chaty") ?>"><span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </label>
                <div>
                    <?php $field_value = isset($value['sender_name']) ? $value['sender_name'] : "" ?>
                    <input class="w-full" id="sender_name_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[sender_name]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>>
                </div>
            </div>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="email_subject_for_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Email subject", "chaty") ?>
                    <span class="icon label-tooltip email-tooltip -mt-[9px]" data-title="<?php esc_html_e("The subject line of the emails that you'll receive from each contact form submission. You can use dynamic tags", "chaty") ?>">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </span>
                </label>
                <div>
                    <?php $field_value = isset($value['email_subject']) ? $value['email_subject'] : "New lead from Chaty - {name} - {date} {hour}" ?>
                    <input class="w-full" id="email_subject_for_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[email_subject]" value="<?php echo esc_attr($field_value); ?>" <?php echo esc_attr($disabled) ?>> <div class="mail-merge-tags mt-2"><span>{name}</span><span>{phone}</span><span>{email}</span><span>{date}</span><span>{hour}</span>
                    </div>
                </div>
            </div>
            <div class="chaty-setting-col">
                <?php $field_value = isset($value['has_custom_mail_content']) ? $value['has_custom_mail_content'] : "no" ?>
                <label for="has_custom_mail_content_<?php echo esc_attr($social['slug']); ?>" class="full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom">
                    <input class="email-content-switch" type="checkbox" id="has_custom_mail_content_<?php echo esc_attr($social['slug']); ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[has_custom_mail_content]" <?php checked($field_value, "yes") ?> <?php echo esc_attr($disabled) ?>>
                    <div class="chaty-slider round"></div>
                    <?php esc_html_e("Add more info to the body ✉️", "chaty"); ?>
                    <span class="icon label-tooltip email-tooltip" data-title="Add dynamic information to the beginning of the email body automatically for more convenience">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </label>
                <div class="email-body-content <?php echo ($field_value == "yes") ? "active" : "" ?>">
                    <?php $field_value = isset($value['mail_content']) ? $value['mail_content'] : "{title}\n{url}" ?>
                    <textarea class="custom-email-body" id="email_body_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[mail_content]"><?php echo esc_attr($field_value) ?></textarea>
                    <div class="mt-3"> <?php include "custom-tags.php" ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $field_value = isset($value['enable_recaptcha']) ? $value['enable_recaptcha'] : "no" ?>
        <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[enable_recaptcha]">
        <div class="chaty-setting-col mt-3">
            <label for="enable_recaptcha_<?php echo esc_attr($social['slug']); ?>" class="email-setting full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom">
                <input class="captcha-setting-field" type="checkbox" id="enable_recaptcha_<?php echo esc_attr($social['slug']); ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[enable_recaptcha]" <?php checked($field_value, "yes") ?> <?php echo esc_attr($disabled) ?>>
                <div class="chaty-slider round"></div>
                <?php esc_html_e("Enable reCAPTCHA", "chaty") ?>
                <span class="header-tooltip">
                    <span class="header-tooltip-text text-center">
                        <?php printf(esc_html__("Click %1\$s to add your website. (please make sure you select V3). After adding your website you'll get your site Key and secret key.", "chaty"), "<a target='_blank' class='infotip-link' href='https://www.google.com/recaptcha/admin/create'>" . esc_html__("here", "chaty") . "</a>") ?>
                    </span>
                    <span class="ml-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </span>
                <?php if (!$is_pro) { ?>
                    <a class="opacity-0 px-5 py-1.5 group-custom-hover:opacity-100 ml-4 pro-btn bg-cht-primary inline-block rounded-[6px] text-white hover:text-white" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                    </a>
                <?php } ?>
            </label>
        </div>
        <div class="captcha-settings <?php echo ($field_value == "yes") ? "active" : "" ?>">
            <?php $captcha_type = isset($value['captcha_type']) ? $value['captcha_type'] : "v3" ?>
            <div class="form-horizontal__item">
                <label class="align-top form-horizontal__item-label font-primary text-cht-gray-150 block text-sm">
                    <?php esc_html_e('reCAPTCHA type', 'chaty'); ?>
                </label>
                <div>
                    <div class="tab-tab-select bg-cht-gray-50 rounded-md p-1 inline-flex flex-wrap items-center">
                        <label class="custom-control custom-radio" for="captcha_type-v3">
                            <input type="radio" id="captcha_type-v3" name="cht_social_<?php echo esc_attr($social['slug']); ?>[captcha_type]" class="custom-control-input recaptcha-type" <?php checked($captcha_type, "v3") ?> value="v3" <?php echo esc_attr($disabled) ?> />
                            <span class="custom-control-label !text-sm">
                                <?php esc_html_e('reCAPTCHA v3', 'chaty'); ?>
                            </span>
                        </label>
                        <label class="custom-control custom-radio" for="captcha_type-v2">
                            <input type="radio" id="captcha_type-v2" name="cht_social_<?php echo esc_attr($social['slug']); ?>[captcha_type]" class="custom-control-input recaptcha-type" <?php checked($captcha_type, "v2") ?> value="v2" <?php echo esc_attr($disabled) ?> />
                            <span class="custom-control-label !text-sm">
                                <?php esc_html_e('reCAPTCHA v2', 'chaty'); ?>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="site_key_<?php echo esc_attr($social['slug']); ?>">
                    <span><?php esc_html_e("Site Key", "chaty") ?></span>
                    <span class="header-tooltip recaptcha-tooltip">
                        <span class="header-tooltip-text text-center">
                            <?php esc_html_e("Click COPY SITE KEY from Google reCAPTCHA and paste it here.", "chaty"); ?>
                            <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/google-site-key.png") ?>" alt="<?php esc_html_e("Google Site Key", "chaty"); ?>"/>
                        </span>
                        <span class="ml-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </span>
                </label>
                <div class="<?php echo esc_attr($captcha_type) ?>-key recaptcha-input">
                    <?php $v2_site_key = isset($value['v2_site_key']) ? $value['v2_site_key'] : "" ?>
                    <?php $v3_site_key = isset($value['v3_site_key']) ? $value['v3_site_key'] : "" ?>
                    <input class="w-full v2-input" id="v2_site_key_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[v2_site_key]" value="<?php echo esc_attr($v2_site_key); ?>" <?php echo esc_attr($disabled) ?> >
                    <input class="w-full v3-input" id="v3_site_key_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[v3_site_key]" value="<?php echo esc_attr($v3_site_key); ?>" <?php echo esc_attr($disabled) ?> >
                </div>
            </div>
            <div class="chaty-setting-col">
                <label class="font-primary text-cht-gray-150 text-sm" for="secret_key_<?php echo esc_attr($social['slug']); ?>">
                    <span><?php esc_html_e("Secret Key", "chaty") ?></span>
                    <span class="header-tooltip recaptcha-tooltip">
                        <span class="header-tooltip-text text-center">
                            <?php esc_html_e("Click the COPY SECRET KEY from Google reCAPTCHA and paste it here.", "chaty"); ?>
                            <img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/google-secret-key.png") ?>" alt="<?php esc_html_e("Google Secret Key", "chaty"); ?>"/>
                        </span>
                        <span class="ml-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>
                    </span>
                </label>
                <div class="<?php echo esc_attr($captcha_type) ?>-key recaptcha-input">
                    <?php $v2_secret_key = isset($value['v2_secret_key']) ? $value['v2_secret_key'] : "" ?>
                    <?php $v3_secret_key = isset($value['v3_secret_key']) ? $value['v3_secret_key'] : "" ?>
                    <input class="w-full v2-input" id="v2_secret_key_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[v2_secret_key]" value="<?php echo esc_attr($v2_secret_key); ?>" <?php echo esc_attr($disabled) ?> >
                    <input class="w-full v3-input" id="v3_secret_key_<?php echo esc_attr($social['slug']); ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[v3_secret_key]" value="<?php echo esc_attr($v3_secret_key); ?>" <?php echo esc_attr($disabled) ?> >
                </div>
            </div>
            <div class="recaptcha-badge"> <?php $field_value = isset($value['hide_recaptcha_badge']) ? $value['hide_recaptcha_badge'] : "no" ?>
                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[hide_recaptcha_badge]" value="no"/>
                <div class="flex items-center space-x-2">
                    <div class="checkbox">
                        <label for="cht_social_<?php echo esc_attr($social['slug']); ?>_hide_recaptcha_badge" class="chaty-checkbox text-cht-gray-150 text-base">
                            <input class="sr-only" type="checkbox" id="cht_social_<?php echo esc_attr($social['slug']); ?>_hide_recaptcha_badge" name="cht_social_<?php echo esc_attr($social['slug']); ?>[hide_recaptcha_badge]" value="yes" <?php checked(isset($value['hide_recaptcha_badge']) ? $value['hide_recaptcha_badge'] : "no", "yes") ?> <?php echo esc_attr($disabled) ?> />
                            <span></span>
                            <?php esc_html_e("Hide reCAPTCHA badge", "chaty") ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <?php $field_value = isset($value['capture_ip_address']) ? $value['capture_ip_address'] : "no" ?>
        <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[capture_ip_address]">
        <div class="chaty-setting-col mt-3">
            <label for="capture_ip_address_<?php echo esc_attr($social['slug']); ?>" class="full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom">
                <input class="capture-ip-address-field" type="checkbox" id="capture_ip_address_<?php echo esc_attr($social['slug']); ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[capture_ip_address]" <?php checked($field_value, "yes") ?> <?php echo esc_attr($disabled) ?>>
                <div class="chaty-slider round"></div>
                <?php esc_html_e("Capture IP address", "chaty") ?>
                <span class="header-tooltip">
                    <span class="header-tooltip-text text-center">
                        <?php printf(esc_html__("Capture the visitor's IP address when they submit the form.", 'chaty')) ?>
                    </span>
                    <span class="ml-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </span>
                <?php if (!$is_pro) { ?>
                    <a class="opacity-0 px-5 py-1.5 group-custom-hover:opacity-100 ml-4 pro-btn bg-cht-primary inline-block rounded-[6px] text-white hover:text-white" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                    </a>
                <?php } ?>
            </label>
        </div>
        <?php
        $mailchimp_enable = isset($value['send_leads_mailchimp']) ? $value['send_leads_mailchimp'] : "no";
        $chaty_mc_api_key = get_option('chaty_mc_api_key');
        ?>
        <div class="chaty-setting-col mt-3">
            <label for="send_leads_mailchimp" class="email-setting full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom">
                <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_mailchimp]">
                <input class="<?php echo (isset($chaty_mc_api_key) && $chaty_mc_api_key != '') ? "" : "has-mailchimp-integration"; ?>" type="checkbox" id="send_leads_mailchimp" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_mailchimp]" <?php checked($mailchimp_enable, "yes") ?> <?php echo esc_attr($disabled) ?>>
                <div class="chaty-slider round"></div>
                <?php esc_html_e("Send leads to Mailchimp", "chaty") ?>
                <span class="header-tooltip">
                    <span class="header-tooltip-text text-center">
                        <?php printf(esc_html__("Integrate Mailchimp to directly sync email leads on Mailchimp", "chaty")) ?>
                    </span>
                    <span class="ml-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </span>
                <?php if (!$is_pro) { ?>
                    <a class="opacity-0 px-5 py-1.5 group-custom-hover:opacity-100 ml-4 pro-btn bg-cht-primary inline-block rounded-[6px] text-white hover:text-white" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>">
                        <?php esc_html_e('Activate your license key', 'chaty'); ?>
                    </a>
                <?php } ?>
            </label>
        </div>
        <?php
        if (isset($chaty_mc_api_key) && $chaty_mc_api_key != '') {
            include('mailchimp-integration.php');
        }
        ?> <?php $klaviyo_enable = isset($value['send_leads_klaviyo']) ? $value['send_leads_klaviyo'] : "no";
        $elements_klaviyo_connect = get_option('chaty_klaviyo_detail');
        $status = 0;
        $list = '';
        if (!empty($elements_klaviyo_connect)) {
            $status = (int)$elements_klaviyo_connect['status'];
            $list = $elements_klaviyo_connect['list'];
        }
        ?> <div class="chaty-setting-col mt-3"> <label for="send_leads_klaviyo" class="email-setting full-width chaty-switch text-sm text-cht-gray-150 flex items-center group-custom"> <input type="hidden" value="no" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_klaviyo]"> <input type="checkbox" id="send_leads_klaviyo" class="<?php echo ($status == 1) ? "" : "has-klaviyo-integration"; ?>" value="yes" name="cht_social_<?php echo esc_attr($social['slug']); ?>[send_leads_klaviyo]" <?php checked($klaviyo_enable, "yes") ?> <?php echo esc_attr($disabled) ?>> <div class="chaty-slider round"></div> <?php esc_html_e("Send leads to Klaviyo", "chaty") ?> <span class="header-tooltip"> <span class="header-tooltip-text text-center"> <?php printf(esc_html__("Integrate Klaviyo to directly sync email leads on Klaviyo", "chaty")) ?> </span> <span class="ml-1"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"> <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path> </svg> </span> </span> <?php if (!$is_pro) { ?> <a class="opacity-0 px-5 py-1.5 group-custom-hover:opacity-100 ml-4 pro-btn bg-cht-primary inline-block rounded-[6px] text-white hover:text-white" target="_blank" href="<?php echo esc_url($this->getUpgradeMenuItemUrl()); ?>"> <?php esc_html_e('Activate your license key', 'chaty'); ?> </a> <?php } ?> </label> </div> <?php
        if (isset($elements_klaviyo_connect) && $status == 1) {
            include('klaviyo-integration.php');
        }
        ?>
    </div>
</div>