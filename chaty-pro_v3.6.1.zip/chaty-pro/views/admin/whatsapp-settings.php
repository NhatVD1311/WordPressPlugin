<?php if ($social['slug'] == "Whatsapp" || $social['slug'] == "Link" || $social['slug'] == "Custom_Link" || $social['slug'] == "Custom_Link_3" || $social['slug'] == "Custom_Link_4" || $social['slug'] == "Custom_Link_5") { ?>
    <div class="Whatsapp-settings advanced-settings extra-chaty-settings">
        <?php $embedded_window = isset($value['embedded_window']) ? $value['embedded_window'] : "no"; ?>
        <div class="chaty-setting-col">
            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[embedded_window]" value="no">
            <label class="chaty-switch chaty-embedded-window font-primary text-cht-gray-150 mt-2 mb-1" for="whatsapp_embedded_window_<?php echo esc_attr($social['slug']); ?>">
                <input type="checkbox" class="embedded_window-checkbox" name="cht_social_<?php echo esc_attr($social['slug']); ?>[embedded_window]" id="whatsapp_embedded_window_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($embedded_window, "yes") ?> >
                <div class="chaty-slider round"></div>
                <?php esc_html_e("Enable WhatsApp Chat Widget &#128172;", "chaty") ?>
                <div class="html-tooltip top">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span class="tooltip-text top">
                        <?php esc_html_e("Engage visitors with a WhatsApp-style chat window with a welcome message. Visitors can start conversations by typing messages and  clicking on 'Send' will redirect them to WhatsApp.", "chaty") ?>
                        <img alt="chaty" src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/chaty-wa-widget-ez.gif" loading="lazy"/>
                    </span>
                </div>
            </label>
        </div>
        <!-- advance setting for Whatsapp -->
        <div class="whatsapp-welcome-message mt-4 <?php echo ($embedded_window == "yes") ? "active" : "" ?>">
            <div class="chaty-setting-col">
                <label class="text-cht-gray-150 text-sm pb-1.5 w-full flex" for="cht_social_embedded_message_<?php echo esc_attr($social['slug']); ?>"><?php esc_html_e("Welcome message", "chaty") ?></label>
                <div class="w-full">
                    <div class="w-full">
                        <?php $unique_id = uniqid(); ?>
                        <?php $embedded_message = isset($value['embedded_message']) ? $value['embedded_message'] : esc_html__("How can we help you? :)", "chaty"); ?>
                        <textarea class="chaty-setting-textarea chaty-whatsapp-setting-textarea" data-id="<?php echo esc_attr($unique_id) ?>" id="cht_social_embedded_message_<?php echo esc_attr($unique_id) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[embedded_message]"><?php echo esc_textarea($embedded_message) ?></textarea>
                    </div>
                </div>
            </div>
            <div class="chaty-setting-col mt-4 hide-prefilled-setting">
                <?php $is_default_open = isset($value['is_default_open']) ? $value['is_default_open'] : "no"; ?>
                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_default_open]" value="no">
                <label class="chaty-switch text-base font-primary text-cht-gray-150" for="whatsapp_default_open_embedded_window_<?php echo esc_attr($social['slug']); ?>">
                    <input type="checkbox" name="cht_social_<?php echo esc_attr($social['slug']); ?>[is_default_open]" id="whatsapp_default_open_embedded_window_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($is_default_open, "yes") ?> >
                    <div class="chaty-slider round"></div>
                    <span class="text-cht-gray-150 text-sm">
                                <?php esc_html_e("Open the chat widget on page load", "chaty") ?>
                            </span>
                    <span class="icon label-tooltip" data-title="<?php esc_html_e("Open the WhatsApp chat popup on page load, after the user sends a message or closes the window, the window will stay closed to avoid disruption", "chaty") ?>">
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </span>
                            </span>
                </label>
            </div>
            <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                <?php $wp_popup_headline = isset($value['wp_popup_headline']) ? $value['wp_popup_headline'] : esc_html__("Let's chat on WhatsApp", "chaty") ?>
                <div class="chaty-setting-col inline-options">
                    <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                        <?php esc_html_e("Headline", "chaty") ?>
                    </label>
                    <div>
                        <input type="text" id="wp_popup_headline" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wp_popup_headline]" value="<?php echo esc_attr($wp_popup_headline) ?>">
                    </div>
                </div>
                <div class="chaty-setting-col inline-options">
                    <?php
                    $wp_popup_head_bg_color = isset($value['wp_popup_head_bg_color']) ? $value['wp_popup_head_bg_color'] : "#4AA485";
                    $wp_popup_head_bg_color = $this->validate_color($wp_popup_head_bg_color, "#4AA485");
                    ?>
                    <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                        <?php esc_html_e("Header Background", "chaty") ?>
                    </label>
                    <div>
                        <input type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wp_popup_head_bg_color]" class="chaty-color-field button-color" value="<?php echo esc_attr($wp_popup_head_bg_color) ?>"/>
                    </div>
                </div>
            </div>

            <div class="hide-prefilled-setting">
                <?php $wp_popup_nickname = isset($value['wp_popup_nickname']) ? $value['wp_popup_nickname'] : "" ?>
                <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                    <div class="chaty-setting-col inline-options">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                            <?php esc_html_e("Nickname", "chaty") ?>
                        </label>
                        <div>
                            <input type="text" id="wp_popup_nickname" placeholder="Micheal" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wp_popup_nickname]" value="<?php echo esc_attr($wp_popup_nickname) ?>">
                        </div>
                    </div>
                </div>
                <?php $wp_popup_profile = isset($value['wp_popup_profile']) ? $value['wp_popup_profile'] : "" ?>
                <div class="chaty-setting-col sm:flex sm:items-center sm:space-x-3 mt-4">
                    <div class="chaty-setting-col">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                            <?php esc_html_e("Add a profile image", "chaty") ?>
                        </label>
                        <div class="sm:flex sm:items-center custom-img-upload <?php echo esc_attr(!empty($wp_popup_profile) ? "active" : "") ?>" id="<?php echo esc_attr($social['slug']); ?>-custom-image-upload">
                            <div class="image-info">
                                <?php if (!empty($wp_popup_profile)) { ?>
                                    <img src="<?php echo esc_url($wp_popup_profile) ?>" alt="<?php esc_html_e("Profile image", "chaty"); ?>"/>
                                <?php } ?>
                            </div>
                            <a href="#" class="upload-chaty-icon flex items-center px-2 upload-wp-profile bg-white img-upload-btn" data-for="<?php echo esc_attr($social['slug']); ?>">
                                <?php esc_html_e('Upload Image', 'chaty') ?>
                            </a>
                            <a href="#" class="remove-custom-img bg-white" data-for="<?php echo esc_attr($social['slug']); ?>">
                                <?php esc_html_e('Remove', 'chaty') ?>
                            </a>
                            <input class="img-value" type="hidden" id="wp_popup_profile" name="cht_social_<?php echo esc_attr($social['slug']); ?>[wp_popup_profile]" value="<?php echo esc_attr($wp_popup_profile) ?>">
                        </div>
                    </div>
                </div>
                <?php $input_placeholder = isset($value['input_placeholder']) ? $value['input_placeholder'] : esc_html__("Write your message...", "chaty") ?>
                <div class="sm:flex sm:items-center sm:space-x-3 mt-4">
                    <div class="chaty-setting-col inline-options">
                        <label class="font-primary text-sm text-cht-gray-150 sm:w-44">
                            <?php esc_html_e("Text input placeholder", "chaty") ?>
                        </label>
                        <div>
                            <input type="text" class="whatsapp-placeholder" id="input_placeholder_<?php echo esc_attr($social['slug']); ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[input_placeholder]" value="<?php echo esc_attr($input_placeholder) ?>">
                        </div>
                    </div>
                </div>
                <div class="chaty-setting-col mt-4">
                    <?php $emoji_picker = isset($value['emoji_picker']) ? $value['emoji_picker'] : "yes"; ?>
                    <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[emoji_picker]" value="no">
                    <label class="chaty-switch text-base font-primary text-cht-gray-150" for="whatsapp_emoji_picker_<?php echo esc_attr($social['slug']); ?>">
                        <input type="checkbox" class="whatsapp-emoji" name="cht_social_<?php echo esc_attr($social['slug']); ?>[emoji_picker]" id="whatsapp_emoji_picker_<?php echo esc_attr($social['slug']); ?>" value="yes" <?php checked($emoji_picker, "yes") ?> >
                        <div class="chaty-slider round"></div>
                        <span class="text-cht-gray-150 text-sm">
                                    <?php esc_html_e("Enable emoji picker", "chaty") ?>
                                </span>

                        <div class="html-tooltip top">
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M8.00004 14.6654C11.6819 14.6654 14.6667 11.6806 14.6667 7.9987C14.6667 4.3168 11.6819 1.33203 8.00004 1.33203C4.31814 1.33203 1.33337 4.3168 1.33337 7.9987C1.33337 11.6806 4.31814 14.6654 8.00004 14.6654Z" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M8 10.6667V8" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M8 5.33203H8.00667" stroke="#72777c" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                    </span>
                            <span class="tooltip-text top">
                                        <?php esc_html_e("Allow visitors to pick emoji from the emoji picker and enter them into the message input field", "chaty") ?>
                                        <img alt="chaty" src="<?php echo esc_url(CHT_PLUGIN_URL) ?>/admin/assets/images/chaty-emoji.png" loading="lazy"/>
                                    </span>
                        </div>
                    </label>
                </div>
            </div>
        </div>
    </div>
<?php }//end if
?>