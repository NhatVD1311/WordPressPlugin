<?php if ($social['slug'] == 'Contact_Us') {
    $fields = [
        'name' => [
            'title' => esc_html__("Name", "chaty"),
            'placeholder' => esc_html__("Enter your name", "chaty"),
            'is_required' => 1,
            'type' => 'input',
            'is_enabled' => 1,
        ],
        'email' => [
            'title' => esc_html__("Email", "chaty"),
            'placeholder' => esc_html__("Enter your email address", "chaty"),
            'is_required' => 1,
            'type' => 'email',
            'is_enabled' => 1,
        ],
        'phone' => [
            'title' => esc_html__("Phone", "chaty"),
            'placeholder' => esc_html__("Enter your phone number", "chaty"),
            'is_required' => 1,
            'type' => 'input',
            'is_enabled' => 1,
        ],
        'message' => [
            'title' => esc_html__("Message", "chaty"),
            'placeholder' => esc_html__("Enter your message", "chaty"),
            'is_required' => 1,
            'type' => 'textarea',
            'is_enabled' => 1,
        ],
        'consent' => [
            'title' => esc_html__("Consent", "chaty"),
            'placeholder' => esc_html__("I consent to having this website store my submitted information so they can respond to my inquiry", "chaty"),
            'is_required' => 1,
            'type' => 'checkbox',
            'is_enabled' => 1,
        ]
    ];
    $contactFormOrder = isset($value['contact_form_field_order']) ? $value['contact_form_field_order'] : "";
    ?>
    <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[contact_form_field_order]" id="contact_form_field_order" value="<?php echo esc_attr($contactFormOrder) ?>">
    <?php
    echo '<div class="form-field-setting-col">';
    if (empty($contactFormOrder)) {
        foreach ($fields as $label => $field) {
            $saved_value = isset($value[$label]) ? $value[$label] : [];
            $field_value = [
                'is_active' => (isset($saved_value['is_active'])) ? $saved_value['is_active'] : 'yes',
                'is_required' => (isset($saved_value['is_required'])) ? $saved_value['is_required'] : 'yes',
                'placeholder' => (isset($saved_value['placeholder'])) ? $saved_value['placeholder'] : $field['placeholder'],
                'field_label' => (isset($saved_value['field_label'])) ? $saved_value['field_label'] : $field['title'],
            ];
            ?>
            <div class="field-setting-col mt-2.5 chaty-field-<?php echo esc_attr($label); ?> <?php echo ($field_value['is_active'] == "yes") ? "" : "hide-label-setting" ?>" data-title="<?php echo esc_attr($field['title']) ?>" data-order="<?php echo esc_attr($label) ?>">
                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_active]" value="no">
                <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_required]" value="no">

                <div class="label-flex mb-4">
                    <label class="chaty-switch chaty-switch-toggle text-cht-gray-150 text-base" for="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>">
                        <input type="checkbox" class="chaty-field-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_active]" id="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" value="yes" <?php checked($field_value['is_active'], "yes") ?>>
                        <div class="chaty-slider round"></div>
                        <span class="field-label"><?php echo esc_attr($field_value['field_label']) ?>
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_8719_30645)">
                                    <path d="M7.33398 2.66699H2.66732C2.3137 2.66699 1.97456 2.80747 1.72451 3.05752C1.47446 3.30756 1.33398 3.6467 1.33398 4.00033V13.3337C1.33398 13.6873 1.47446 14.0264 1.72451 14.2765C1.97456 14.5265 2.3137 14.667 2.66732 14.667H12.0006C12.3543 14.667 12.6934 14.5265 12.9435 14.2765C13.1935 14.0264 13.334 13.6873 13.334 13.3337V8.66699" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M12.334 1.66617C12.5992 1.40095 12.9589 1.25195 13.334 1.25195C13.7091 1.25195 14.0688 1.40095 14.334 1.66617C14.5992 1.93138 14.7482 2.29109 14.7482 2.66617C14.7482 3.04124 14.5992 3.40095 14.334 3.66617L8.00065 9.9995L5.33398 10.6662L6.00065 7.9995L12.334 1.66617Z" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                </g>
                                <defs>
                                    <clipPath id="clip0_8719_30645">
                                        <rect width="16" height="16" fill="white"/>
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                    </label>
                    <div class="label-input">
                        <input type="text" class="label-input-field chaty-input-text contact-form-field-text" value="<?php echo esc_attr($field_value['field_label']) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][field_label]"/>
                    </div>
                    <?php if($label != 'consent') { ?>
                        <div class="sort-contact-form-field"><img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>" alt="Move Icon"/></div>
                    <?php } ?>
                </div>
                <div class="field-settings <?php echo ($field_value['is_active'] == "yes") ? "active" : "" ?>">
                    <div class="chaty-setting-col sm:grid grid-cols-2 items-center gap-3">
                        <div>
                            <?php if($label == 'consent') { ?>
                                <textarea maxlength="200" class="rounded-lg w-full chaty-input-text contact_form_custom_value" data-type="<?php echo esc_attr($field['type']) ?>" id="placeholder_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][placeholder]"><?php echo esc_attr($field_value['placeholder']) ?></textarea>
                            <?php } else { ?>
                                <input class="rounded-lg w-full chaty-input-text contact_form_custom_value" data-type="<?php echo esc_attr($field['type']) ?>" id="placeholder_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][placeholder]" value="<?php echo esc_attr($field_value['placeholder']) ?>">
                            <?php } ?>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="checkbox">
                                <label for="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" class="chaty-checkbox text-cht-gray-150 text-base flex items-center">
                                    <input class="sr-only" type="checkbox" id="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_required]" value="yes" <?php checked($field_value['is_required'], "yes") ?> />
                                    <span class="mr-2"></span>
                                    <?php esc_html_e("Required?", "chaty") ?>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }//end foreach
    } else {
        $orderField = explode(",", $contactFormOrder);
        foreach ($orderField as $orderKey => $orderValue) {
            $custom_fields = [];
            if (isset($value['custom_fields']) && is_array($value['custom_fields'])) {
                foreach ($value['custom_fields'] as $key => $val) {
                    $custom_fields[] = $key;
                }
            }
            if (!empty($custom_fields)) {
                $custom_fields = max($custom_fields) + 1;
            } else {
                $custom_fields = 1;
            }
            ?>
            <input type="hidden" id="chaty-custom-fields-length" value="<?php echo esc_attr($custom_fields); ?>"/>
            <?php if (isset($value['custom_fields']) && is_array($value['custom_fields'])) {
                foreach ($value['custom_fields'] as $label => $field) {
                    if ($field['unique_id'] == $orderValue) {
                        $uniqueId = isset($field['unique_id']) ? $field['unique_id'] : '';
                        ?>
                        <div class="field-setting-col mt-2.5 chaty-field-<?php echo esc_attr($label); ?> chaty-custom-field <?php echo ($field['is_active'] == "yes") ? "" : "hide-label-setting" ?> custom-<?php echo esc_attr($field['field_dropdown']) ?>" data-order="<?php echo esc_attr($uniqueId); ?>" data-custom="true">
                            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][is_active]" value="no">
                            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][is_required]" value="no">
                            <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][unique_id]" value="<?php echo esc_attr($uniqueId) ?>">
                            <div class="label-flex mb-4">
                                <label class="chaty-switch chaty-switch-toggle text-cht-gray-150 text-base" for="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>">
                                    <input type="checkbox" class="chaty-field-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][is_active]" id="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" value="yes" <?php checked($field['is_active'], "yes") ?>>
                                    <div class="chaty-slider round"></div>
                                    <span class="field-label"><?php echo esc_attr($field['field_label']) ?>
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_8719_30645)">
                                                <path d="M7.33398 2.66699H2.66732C2.3137 2.66699 1.97456 2.80747 1.72451 3.05752C1.47446 3.30756 1.33398 3.6467 1.33398 4.00033V13.3337C1.33398 13.6873 1.47446 14.0264 1.72451 14.2765C1.97456 14.5265 2.3137 14.667 2.66732 14.667H12.0006C12.3543 14.667 12.6934 14.5265 12.9435 14.2765C13.1935 14.0264 13.334 13.6873 13.334 13.3337V8.66699" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M12.334 1.66617C12.5992 1.40095 12.9589 1.25195 13.334 1.25195C13.7091 1.25195 14.0688 1.40095 14.334 1.66617C14.5992 1.93138 14.7482 2.29109 14.7482 2.66617C14.7482 3.04124 14.5992 3.40095 14.334 3.66617L8.00065 9.9995L5.33398 10.6662L6.00065 7.9995L12.334 1.66617Z" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_8719_30645">
                                                    <rect width="16" height="16" fill="white"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </span>
                                </label>
                                <div class="label-input">
                                    <input type="text" class="label-input-field chaty-input-text contact-form-field-text" value="<?php echo esc_attr($field['field_label']) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][field_label]"/>
                                </div>
                                <?php if($label != 'consent') { ?>
                                    <div class="sort-contact-form-field"><img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>" alt="Move Icon"/></div>
                                <?php } ?>
                            </div>
                            <div class="field-settings <?php echo ($field['is_active'] == "yes") ? "active" : "" ?>">
                                <?php
                                $field_dropdown = (isset($field['field_dropdown']) && $field['field_dropdown'] != '') ? $field['field_dropdown'] : 'text';
                                ?>
                                <div class="chaty-setting-col sm:grid <?php echo ($field_dropdown == 'textblock') ? "has-field-flex" : "grid-cols-2" ?> items-center gap-3">
                                    <div class="flex-first">
                                        <?php
                                        $cutom_field_val = (isset ($field['placeholder']) && $field['placeholder'] != '') ? stripslashes($field['placeholder']) : '';

                                        if ($field_dropdown != 'textarea' && $field_dropdown != 'dropdown' && $field_dropdown != 'textblock') {
                                            if ($field_dropdown == 'text') {
                                                $custom_field_dropdown = "Enter your message";
                                            } elseif ($field_dropdown == 'number') {
                                                $custom_field_dropdown = "Enter a number";
                                            } elseif ($field_dropdown == 'url') {
                                                $custom_field_dropdown = "Enter your website";
                                            } elseif ($field_dropdown == 'date') {
                                                $custom_field_dropdown = "mm/dd/yyyy";
                                            }
                                            if ($field_dropdown == 'file') { ?>
                                                <input type="file" data-type="file" class="contact_form_custom_value" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label); ?>][placeholder]" value="<?php echo esc_attr($cutom_field_val); ?>" data-id="<?php echo esc_attr($label); ?>" style="pointer-events: none;"/>

                                            <?php } else {
                                                ?>
                                                <input type="text" data-type="text" class="contact_form_custom_value" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label); ?>][placeholder]" value="<?php echo esc_attr($cutom_field_val); ?>" data-id="<?php echo esc_attr($label); ?>"/>
                                            <?php }
                                            ?>
                                            <?php
                                        } elseif ($field_dropdown == 'textarea') { ?>
                                            <textarea name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label); ?>][placeholder]" data-type="textarea" class="contact_form_custom_value" rows="5" cols="50" data-id="<?php echo esc_attr($label); ?>" placeholder="<?php esc_html_e('Enter your Message', 'chaty'); ?>"><?php echo esc_attr($cutom_field_val); ?></textarea>
                                            <?php
                                        } elseif ($field_dropdown == 'textblock') { ?>
                                            <textarea id="textblock_editor" class="contact_form_custom_value textblock_custom_editor" name="cht_social_Contact_Us[custom_fields][<?php echo esc_attr($label) ?>][placeholder]"><?php echo stripslashes($field['placeholder']) ?></textarea>
                                            <?php
                                        } else { ?>
                                            <select name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label); ?>][placeholder]" data-type="select" class="contact_form_custom_value" data-id="<?php echo esc_attr($label); ?>">
                                                <?php if (!empty($field['dropdown_placeholder'])) { ?>
                                                    <option value=""><?php echo esc_attr($field['dropdown_placeholder']); ?></option>
                                                <?php } ?>
                                                <?php if (isset($field['dropdown_option']) && !empty($field['dropdown_option'])) :
                                                    foreach ($field['dropdown_option'] as $option) :
                                                        if ($option == '') {
                                                            continue;
                                                        }
                                                        echo "<option value=" . esc_html($option) . " >" . esc_html($option) . "</option>";
                                                    endforeach;
                                                endif;
                                                ?>
                                            </select>
                                            <?php
                                        }
                                        ?>
                                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][field_dropdown]" value="<?php echo esc_attr($field['field_dropdown']) ?>">
                                    </div>
                                    <div class="flex items-center space-x-3 flex-second">
                                        <?php if ($field_dropdown != 'textblock') { ?>
                                            <div class="checkbox">
                                                <label for="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" class="chaty-checkbox text-cht-gray-150 text-base flex items-center">
                                                    <input class="sr-only" type="checkbox" id="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[custom_fields][<?php echo esc_attr($label) ?>][is_required]" value="yes" <?php checked($field['is_required'], "yes") ?> />
                                                    <span class="mr-2"></span>
                                                    <?php esc_html_e("Required?", "chaty") ?>
                                                </label>
                                            </div>
                                        <?php } ?>
                                        <div id="setting_label<?php echo esc_attr($label) ?>" class="dropdown-setting-label" style="<?php echo ($field['field_dropdown'] != 'dropdown') ? "display: none" : "" ?>;">
                                            <a class="flex items-center space-x-1.5 contact-form-dropdown-popup" href="#">
                                                                <span>
                                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"> <path d="M8 10C9.10457 10 10 9.10457 10 8C10 6.89543 9.10457 6 8 6C6.89543 6 6 6.89543 6 8C6 9.10457 6.89543 10 8 10Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M12.9332 9.99984C12.8444 10.2009 12.818 10.424 12.8572 10.6402C12.8964 10.8565 12.9995 11.056 13.1532 11.2132L13.1932 11.2532C13.3171 11.377 13.4155 11.5241 13.4826 11.6859C13.5497 11.8478 13.5842 12.0213 13.5842 12.1965C13.5842 12.3717 13.5497 12.5452 13.4826 12.7071C13.4155 12.869 13.3171 13.016 13.1932 13.1398C13.0693 13.2638 12.9223 13.3621 12.7604 13.4292C12.5986 13.4963 12.4251 13.5309 12.2498 13.5309C12.0746 13.5309 11.9011 13.4963 11.7392 13.4292C11.5774 13.3621 11.4303 13.2638 11.3065 13.1398L11.2665 13.0998C11.1094 12.9461 10.9098 12.843 10.6936 12.8038C10.4773 12.7646 10.2542 12.7911 10.0532 12.8798C9.85599 12.9643 9.68782 13.1047 9.56937 13.2835C9.45092 13.4624 9.38736 13.672 9.3865 13.8865V13.9998C9.3865 14.3535 9.24603 14.6926 8.99598 14.9426C8.74593 15.1927 8.40679 15.3332 8.05317 15.3332C7.69955 15.3332 7.36041 15.1927 7.11036 14.9426C6.86031 14.6926 6.71984 14.3535 6.71984 13.9998V13.9398C6.71467 13.7192 6.64325 13.5052 6.51484 13.3256C6.38644 13.1461 6.20699 13.0094 5.99984 12.9332C5.79876 12.8444 5.57571 12.818 5.35944 12.8572C5.14318 12.8964 4.94362 12.9995 4.7865 13.1532L4.7465 13.1932C4.62267 13.3171 4.47562 13.4155 4.31376 13.4826C4.15189 13.5497 3.97839 13.5842 3.80317 13.5842C3.62795 13.5842 3.45445 13.5497 3.29258 13.4826C3.13072 13.4155 2.98367 13.3171 2.85984 13.1932C2.73587 13.0693 2.63752 12.9223 2.57042 12.7604C2.50332 12.5986 2.46879 12.4251 2.46879 12.2498C2.46879 12.0746 2.50332 11.9011 2.57042 11.7392C2.63752 11.5774 2.73587 11.4303 2.85984 11.3065L2.89984 11.2665C3.05353 11.1094 3.15663 10.9098 3.19584 10.6936C3.23505 10.4773 3.20858 10.2542 3.11984 10.0532C3.03533 9.85599 2.89501 9.68782 2.71615 9.56937C2.53729 9.45092 2.32769 9.38736 2.11317 9.3865H1.99984C1.64622 9.3865 1.30708 9.24603 1.05703 8.99598C0.80698 8.74593 0.666504 8.40679 0.666504 8.05317C0.666504 7.69955 0.80698 7.36041 1.05703 7.11036C1.30708 6.86031 1.64622 6.71984 1.99984 6.71984H2.05984C2.2805 6.71467 2.49451 6.64325 2.67404 6.51484C2.85357 6.38644 2.99031 6.20699 3.0665 5.99984C3.15525 5.79876 3.18172 5.57571 3.14251 5.35944C3.10329 5.14318 3.00019 4.94362 2.8465 4.7865L2.8065 4.7465C2.68254 4.62267 2.58419 4.47562 2.51709 4.31376C2.44999 4.15189 2.41545 3.97839 2.41545 3.80317C2.41545 3.62795 2.44999 3.45445 2.51709 3.29258C2.58419 3.13072 2.68254 2.98367 2.8065 2.85984C2.93033 2.73587 3.07739 2.63752 3.23925 2.57042C3.40111 2.50332 3.57462 2.46879 3.74984 2.46879C3.92506 2.46879 4.09856 2.50332 4.26042 2.57042C4.42229 2.63752 4.56934 2.73587 4.69317 2.85984L4.73317 2.89984C4.89029 3.05353 5.08985 3.15663 5.30611 3.19584C5.52237 3.23505 5.74543 3.20858 5.9465 3.11984H5.99984C6.19702 3.03533 6.36518 2.89501 6.48363 2.71615C6.60208 2.53729 6.66565 2.32769 6.6665 2.11317V1.99984C6.6665 1.64622 6.80698 1.30708 7.05703 1.05703C7.30708 0.80698 7.64621 0.666504 7.99984 0.666504C8.35346 0.666504 8.6926 0.80698 8.94264 1.05703C9.19269 1.30708 9.33317 1.64622 9.33317 1.99984V2.05984C9.33402 2.27436 9.39759 2.48395 9.51604 2.66281C9.63449 2.84167 9.80266 2.98199 9.99984 3.0665C10.2009 3.15525 10.424 3.18172 10.6402 3.14251C10.8565 3.10329 11.056 3.00019 11.2132 2.8465L11.2532 2.8065C11.377 2.68254 11.5241 2.58419 11.6859 2.51709C11.8478 2.44999 12.0213 2.41545 12.1965 2.41545C12.3717 2.41545 12.5452 2.44999 12.7071 2.51709C12.869 2.58419 13.016 2.68254 13.1398 2.8065C13.2638 2.93033 13.3621 3.07739 13.4292 3.23925C13.4963 3.40111 13.5309 3.57462 13.5309 3.74984C13.5309 3.92506 13.4963 4.09856 13.4292 4.26042C13.3621 4.42229 13.2638 4.56934 13.1398 4.69317L13.0998 4.73317C12.9461 4.89029 12.843 5.08985 12.8038 5.30611C12.7646 5.52237 12.7911 5.74543 12.8798 5.9465V5.99984C12.9643 6.19702 13.1047 6.36518 13.2835 6.48363C13.4624 6.60208 13.672 6.66565 13.8865 6.6665H13.9998C14.3535 6.6665 14.6926 6.80698 14.9426 7.05703C15.1927 7.30708 15.3332 7.64621 15.3332 7.99984C15.3332 8.35346 15.1927 8.6926 14.9426 8.94264C14.6926 9.19269 14.3535 9.33317 13.9998 9.33317H13.9398C13.7253 9.33402 13.5157 9.39759 13.3369 9.51604C13.158 9.63449 13.0177 9.80266 12.9332 9.99984V9.99984Z" stroke="currentColor" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path> </svg>
                                                                </span>
                                                <span>Settings</span>
                                            </a>
                                        </div>
                                        <div class="custom-field-remove">
                                                            <span class="custom-stickyelement-delete" delete-id="<?php echo esc_attr($label) ?>">
                                                                <i class="fas fa-trash-alt stickyelement-delete"></i>
                                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if ($field['field_dropdown'] == 'dropdown') { ?>
                                <div class="chaty-popup contact-form-dropdown-open contact-form-setting-popup-open">
                                    <div class="chaty-popup-outer"></div>
                                    <div class="chaty-popup-inner popup-pos-bottom">
                                        <div class="chaty-popup-content">
                                            <div class="chaty-popup-close">
                                                <a href="#" class="close-delete-pop close-chaty-popup-btn right-2 top-2 relative">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
                                                        <path d="M15.6 15.5c-.53.53-1.38.53-1.91 0L8.05 9.87 2.31 15.6c-.53.53-1.38.53-1.91 0s-.53-1.38 0-1.9l5.65-5.64L.4 2.4C-.13 1.87-.13 1.02.4.49s1.38-.53 1.91 0l5.64 5.63L13.69.39c.53-.53 1.38-.53 1.91 0s.53 1.38 0 1.91L9.94 7.94l5.66 5.65c.52.53.52 1.38 0 1.91z"/>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="a-card a-card--normal">
                                                <div class="chaty-popup-header text-left font-primary text-cht-gray-150 font-medium p-5 relative">
                                                    Add Option
                                                </div>
                                                <div class="chaty-popup-body text-cht-gray-150 text-base px-5 py-6">
                                                    <div class="contact-form-dropdown-main">
                                                        <input type="text" name="cht_social_Contact_Us[custom_fields][<?php echo esc_attr($label) ?>][dropdown_placeholder]" class="contact-form-dropdown-select" value="<?php echo esc_attr($field['dropdown_placeholder']) ?>" placeholder="Select...">
                                                        <div class="contact-form-dropdown-option ui-sortable">
                                                            <div class="option-value-field ui-sortable-handle">
                                                                <input type="text" data-id="<?php echo esc_attr($label) ?>" name="cht_social_Contact_Us[custom_fields][<?php echo esc_attr($label) ?>][dropdown_option][]" value="">
                                                                <span class="add-customfield-dropdown-option" data-field="<?php echo esc_attr($label) ?>">Add</span>
                                                            </div>
                                                            <?php if (isset($field['dropdown_option']) && !empty($field['dropdown_option'])) :
                                                                foreach ($field['dropdown_option'] as $option) :
                                                                    if ($option == '') {
                                                                        continue;
                                                                    }
                                                                    ?>
                                                                    <div class="option-value-field">
                                                                        <span class="move-icon"></span>
                                                                        <input type="text" data-id="<?php echo esc_attr($label) ?>" name="cht_social_Contact_Us[custom_fields][<?php echo esc_attr($label); ?>][dropdown_option][]" value="<?php echo esc_attr($option); ?>"/>
                                                                        <span class="delete-dropdown-option">
                                                                                            <i class="fas fa-times"></i>
                                                                                        </span>
                                                                    </div>
                                                                <?php
                                                                endforeach;
                                                            endif; ?>
                                                        </div>
                                                    </div>
                                                    <span class="contact-form-dropdfown-close"><i
                                                            class="fas fa-times"></i></span>
                                                </div>
                                                <div class="chaty-popup-footer flex px-5">
                                                    <button type="button" class="btn rounded-lg btn-dropdown-save">
                                                        Save
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            <?php } ?>
                        </div>
                        <?php
                    }
                }
            }
            foreach ($fields as $label => $field) {
                $fieldLabel = isset($value[$label]['field_label']) && !empty($value[$label]['field_label']) ? $value[$label]['field_label'] : $field['title'];
                if ($label == $orderValue || $field['title'] == $orderValue) {
                    $saved_value = isset($value[$label]) ? $value[$label] : [];
                    $field_value = [
                        'is_active' => (isset($saved_value['is_active'])) ? $saved_value['is_active'] : 'yes',
                        'is_required' => (isset($saved_value['is_required'])) ? $saved_value['is_required'] : 'yes',
                        'placeholder' => (isset($saved_value['placeholder'])) ? $saved_value['placeholder'] : $field['placeholder'],
                        'field_label' => (isset($saved_value['field_label'])) ? $saved_value['field_label'] : $field['title'],
                    ];
                    ?>
                    <div class="field-setting-col mt-2.5 chaty-field-<?php echo esc_attr($label); ?> <?php echo ($field_value['is_active'] == "yes") ? "" : "hide-label-setting" ?>" data-title="<?php echo esc_attr($field['title']) ?>" data-order="<?php echo esc_attr($label) ?>" data-custom="false">
                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_active]" value="no">
                        <input type="hidden" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_required]" value="no">
                        <div class="label-flex mb-4">
                            <label class="chaty-switch chaty-switch-toggle text-cht-gray-150 text-base" for="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>">
                                <input type="checkbox" class="chaty-field-setting" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_active]" id="field_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" value="yes" <?php checked($field_value['is_active'], "yes") ?>>
                                <div class="chaty-slider round"></div>
                                <span class="field-label"><?php echo esc_attr($field_value['field_label']) ?>
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"> <g clip-path="url(#clip0_8719_30645)"> <path d="M7.33398 2.66699H2.66732C2.3137 2.66699 1.97456 2.80747 1.72451 3.05752C1.47446 3.30756 1.33398 3.6467 1.33398 4.00033V13.3337C1.33398 13.6873 1.47446 14.0264 1.72451 14.2765C1.97456 14.5265 2.3137 14.667 2.66732 14.667H12.0006C12.3543 14.667 12.6934 14.5265 12.9435 14.2765C13.1935 14.0264 13.334 13.6873 13.334 13.3337V8.66699" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/> <path d="M12.334 1.66617C12.5992 1.40095 12.9589 1.25195 13.334 1.25195C13.7091 1.25195 14.0688 1.40095 14.334 1.66617C14.5992 1.93138 14.7482 2.29109 14.7482 2.66617C14.7482 3.04124 14.5992 3.40095 14.334 3.66617L8.00065 9.9995L5.33398 10.6662L6.00065 7.9995L12.334 1.66617Z" stroke="#C6D7E3" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/> </g> <defs> <clipPath id="clip0_8719_30645"> <rect width="16" height="16" fill="white"/> </clipPath> </defs> </svg>
                                </span>
                            </label>
                            <div class="label-input">
                                <input type="text" class="label-input-field chaty-input-text contact-form-field-text" value="<?php echo esc_attr($field_value['field_label']) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][field_label]"/>
                            </div>
                            <?php if($label != 'consent') { ?>
                                <div class="sort-contact-form-field"><img src="<?php echo esc_url(CHT_PLUGIN_URL . "admin/assets/images/move-icon.png") ?>" alt="Move Icon"/></div>
                            <?php } ?>
                        </div>
                        <div class="field-settings <?php echo ($field_value['is_active'] == "yes") ? "active" : "" ?>">
                            <div class="chaty-setting-col sm:grid grid-cols-2 items-center gap-3">
                                <div>
                                    <?php if($label == 'consent') { ?>
                                        <textarea maxlength="200" class="rounded-lg w-full chaty-input-text contact_form_custom_value h-24" data-type="<?php echo esc_attr($field['type']) ?>" id="placeholder_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][placeholder]"><?php echo esc_attr($field_value['placeholder']) ?></textarea>
                                    <?php } else { ?>
                                        <input class="rounded-lg w-full chaty-input-text contact_form_custom_value" data-type="<?php echo esc_attr($field['type']) ?>" id="placeholder_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" type="text" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][placeholder]" value="<?php echo esc_attr($field_value['placeholder']) ?>">
                                    <?php } ?>
                                </div>
                                <div class="flex items-center space-x-3">
                                    <div class="checkbox">
                                        <label for="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" class="chaty-checkbox text-cht-gray-150 text-base flex items-center">
                                            <input class="sr-only" type="checkbox" id="field_required_for_<?php echo esc_attr($social['slug']); ?>_<?php echo esc_attr($label) ?>" name="cht_social_<?php echo esc_attr($social['slug']); ?>[<?php echo esc_attr($label) ?>][is_required]" value="yes" <?php checked($field_value['is_required'], "yes") ?> />
                                            <span class="mr-2"></span>
                                            <?php esc_html_e("Required?", "chaty") ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
            }
            //end foreach
        }
    }
    echo '</div>';
    ?>
<?php } ?>