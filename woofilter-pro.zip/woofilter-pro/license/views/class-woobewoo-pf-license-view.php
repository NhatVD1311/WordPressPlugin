<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_License_View Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_License_View extends WooBeWoo_PF_View {

	/**
	 * getTabContent.
	 *
	 * @version 3.4.0
	 */
	public function getTabContent() {
		WooBeWoo_PF_Frame::_()->addScript( 'wpf.admin.license', $this->getModule()->getModPath() . 'js/admin.license.js' );
		WooBeWoo_PF_Frame::_()->getModule( 'templates' )->loadJqueryUi();
		$credentials = $this->getModel()->getCredentials();
		if ( empty( $credentials['key'] ) ) {
			$credentials = array_merge( $credentials, $this->getModule()->pluginData );
		}
		$this->assign( 'credentials', $credentials );
		$this->assign( 'licenseType', $this->getModule()->licenseType );
		$this->assign( 'isActive', $this->getModel()->isActive() );
		$this->assign( 'isExpired', $this->getModel()->isExpired() );
		$this->assign( 'extendUrl', $this->getModel()->getExtendUrl() );
		return parent::getContent( 'licenseAdmin' );
	}
}
