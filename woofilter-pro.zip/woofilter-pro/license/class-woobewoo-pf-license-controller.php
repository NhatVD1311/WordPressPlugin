<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_License_Controller Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_License_Controller extends WooBeWoo_PF_Controller {

	/**
	 * activate.
	 *
	 * @version 3.4.0
	 */
	public function activate() {
		$res = new WooBeWoo_PF_Response();
		if ( $this->getModel()->activate( WooBeWoo_PF_Req::get( 'post' ) ) ) {
			$res->addMessage( esc_html__( 'Done', 'woo-product-filter' ) );
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		$res->ajaxExec();
	}

	/**
	 * dismissNotice.
	 *
	 * @version 3.4.0
	 */
	public function dismissNotice() {
		$res = new WooBeWoo_PF_Response();
		WooBeWoo_PF_Frame::_()->getModule( 'options' )->getModel()->save( 'dismiss_pro_opt', 1 );
		$res->ajaxExec();
	}

	/**
	 * getPermissions.
	 */
	public function getPermissions() {
		return array(
			WPF_USERLEVELS => array(
				WPF_ADMIN => array( 'activate', 'dismissNotice' ),
			),
		);
	}
}
