=== Product Filter for WooCommerce by WBW - PRO ===
Contributors: woobewoo
Tags: product filter, WooCommerce product filter, shop filter, e-commerce filter, WooCommerce filter
Requires at least: 5.0
Tested up to: 7.1
Stable tag: 3.4.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Product Filter for WooCommerce by WBW - PRO. Best plugins from WBW!

== Description ==

To upgrade Product Filter for WooCommerce by WBW plugin free version to the commercial you need to
1. Install latest free version of the plugin here: https://wordpress.org/plugins/woofilter

2. Then download commercial version from your personal account: https://woobewoo.com/my-account/

!Important! You need both versions to be installed. Free and commercial one.

== Changelog ==

= 3.4.7 - 20/10/2026 =
* Fix - Fixed JSON parsing error during filter import.
* Fix - Corrected input unslashing before Base64 encoding settings data.
* Fix - Fixed the range slider background color.
* Fix - Fixed the margin issue with color selection after filtering.
* WC tested up to: 11.2.

= 3.4.6 - 06/10/2026 =
* Fix - Fixed button and "Block styles" font settings (size, color, weight) not being applied.
* Fix - Fixed missing PRO styles and Google fonts with other Free 3.4.x versions.
* Fix - Custom CSS/JS - Only users allowed to post unfiltered HTML can edit the code.
* Fix - Security - Escaped statistics values.
* Fix - Fixed rating filter SVG icon color.
* Dev - Updated required free plugin version.

= 3.4.5 - 21/09/2026 =
* Dev - Security - Improved output escaping.
* Dev - Added custom JS and CSS editor.

= 3.4.4 - 09/09/2026 =
* Dev - Updated required free plugin version.

= 3.4.3 - 08/09/2026 =
* Fix - Filter - Appearance - Blocks - Fixed checkbox border issue.
* WC tested up to: 11.1.

= 3.4.2 - 01/09/2026 =
* Dev - Updated required free plugin version.

= 3.4.1 - 01/09/2026 =
* Dev - Prefixed constants with `WOOBEWOO_PF_`.
* Dev - Renamed AJAX object.

= 3.4.0 - 31/08/2026 =
* Dev - Prefixed PHP class names with `WooBeWoo_PF_`.
* Dev - Prefixed class file names with `class-woobewoo-pf-`.
* Dev - Code refactoring.
* Tested up to: 7.1.

= 3.3.1 - 13/08/2026 =
* Dev - Code refactoring.

= 3.3.0 - 12/08/2026 =
* Fix - Fixed mismatched text domain.
* Fix - Unslashed before sanitization.
* Dev - Replaced outdated library `chosen` with `tom-select`.
* Dev - Improved coding standards.
* Dev - Code refactoring.
* WC tested up to: 11.0.

= 3.1.8 - 01/06/2026 =
* Fix - Fixed Brizy editor shortcode render issue.
* Fix - Fixed apply loader settings to all filters option's permission error.
* Fix - Fixed search text autocomplete permission error.
* Fix - Fixed ranger slider selection bug when handling values with m³ units.
* Dev - Coding standards improved.
* Tested up to: 7.0.
* WC tested up to: 10.8.

= 3.1.7 - 22/04/2026 =
* Fix - Fixed "save statistics" permission error.
* Dev - Coding standards improved.
* WC tested up to: 10.7.

= 3.1.6 - 09/04/2026 =
* Fix - Reverted to v3.1.3 due to stability issues introduced in v3.1.4.

= 3.1.5 - 09/04/2026 =
* Dev - Improved deploy mechanism.
* Dev - Added plugin info to readme.txt.

= 3.1.3 - 20/03/2026 =
* Fix - Security - Missing authorization vulnerability fixed.
* WC tested up to: 10.6.

= 3.1.2 - 10/03/2026 =
* Dev - Admin settings titles updated.

= 3.1.1 - 18/02/2026 =
* Dev - Coding standards improved.

= 3.1.0 - 12/02/2026 =
* Readme.txt - Rename plugin from "WBW Product Filter PRO" to "Product Filter for WooCommerce by WBW - PRO".

= 3.0.9 - 05/02/2026 =
* Dev - Coding standards improved.
* Dev - Rename plugin from "WBW Product Filter PRO" to "Product Filter for WooCommerce by WBW - PRO".

= 3.0.8 - 23/01/2026 =
* Dev - Coding standards improved.

= 3.0.7 - 12/01/2026 =
* Dev - License - Logging - More data added.

= 3.0.6 - 24/12/2025 =
* Dev - "Check for updates" - Action updated (from `wp` to `init`).

= 3.0.5 - 23/12/2025 =
* Dev - "Check for updates" - Action updated (from `admin_init` to `wp`).
* WC tested up to: 10.4.

= 3.0.4 - 28/11/2025 =
* Dev - Coding standards improved.

= 3.0.3 - 25/11/2025 =
* Dev - Changed `curl_setopt()` `$value` parameter to `CURL_SSLVERSION_TLSv1_2` in order to avoid errors such as "cURL error 4: OpenSSL was built without TLS 1.3 support".

= 3.0.2 - 19/11/2025 =
* WC tested up to: 10.3.

= 3.0.1 - 22/10/2025 =
* Fix - Text typo fixed.

= 3.0.0 - 17/10/2025 =
* Dev - Coding standards improved.

= 2.9.9 - 10/10/2025 =
* Dev - Added new option "Discourage search engines from indexing" (free plugin version).

= 2.9.8 - 30/09/2025 =
* WC tested up to: 10.2.

= 2.9.7 - 06/09/2025 =
* Dev - Coding standards improved.

= 2.9.6 - 22/08/2025 =
* Fix - Text typo fixed.
* Dev - License - Logging authentication error.
* Dev - Coding standards improved.

= 2.9.5 - 20/08/2025 =
* Dev - WP Updater - Server address updated.
* Dev - WP Updater - Reduce the number of requests - Option names updated.
* Dev - "Check for updates" link added (to the Plugins list table).

= 2.9.4 - 15/08/2025 =
* Dev - WP Updater - Server address updated.
* Dev - Alternative licensing server removed.
* Dev - Coding standards improved.
* WC tested up to: 10.1.

= 2.9.3 - 07/08/2025 =
* Dev - Coding standards improved.

= 2.9.2 - 05/08/2025 =
* Dev - Coding standards improved.

= 2.9.1 - 31/07/2025 =
* Dev - Coding standards improved.

= 2.9.0 - 29/07/2025 =
* Dev - Coding standards improved.

= 2.8.9 - 29/07/2025 =
* Dev - WP Updater - Reduce the number of requests.

= 2.8.8 - 24/07/2025 =
* Dev - Coding standards improved.

= 2.8.7 - 22/07/2025 =
* Dev - Coding standards improved.

= 2.8.6 - 21/07/2025 =
* Dev - Added alternative server for license activation.
* Dev - Added `aria-label` ("Product Brands").
* Dev - Disable Colors tooltip.
* WC tested up to: 10.0.

= 2.8.5 - 11/07/2025 =
* WC tested up to: 9.9.

= 2.8.4 =
* Fix joint use 'open_one_by_one' and 'display_only_children_category'
* Added option Check product category
* Fixed compatibility with Advanced Woo Search PRO
* Fixed admin filtration by brand
* Added single selection for Text-type blocks
* Added indexing for meta-fields with custom separators
* Added for category preselect possibility to exclude children categories
* Added compatibility with WooCommerce Product Search

= 2.8.3 =
* Update integration with Dynamic Content for Elementor
* Minor issues fix

= 2.8.2 =
* Fixed display subcategories
* Minor issues fix

= 2.8.1 =
* Fix elementor pagination
* Fixed link View details
* Added compatibility with WooCommerce B2B and Multi Currency for WooCommerce plugins
* Fixed Clone filter option
* Hierarchical open_one_by_one added

= 2.8.0 =
* Fixed conflict with custom-woocommerce-enhancements
* Fix open_one_by_one filter functionality
* Add space between taxonomy attributes
* Fix subcategory display
* Fix elementor pagination compatibility
* Add warning for invalid default ID in categories
* Fix add duplicate filter dialog
* Fix AWS Plugin Integration
* Fix if FiboSearch is active with Divi theme
* Fix custom attribute sorting
* Fixed conflict with jet-woo-builder
* Fixed compatibility with Flatsome+UX Builder
* Fix pagination reset with JetSmartFilters
* Fix early loader hiding

= 2.7.8 =
* Added options Show/initialise filter immediately
* Fixed option Hide filter with single item for sliders
* Fixed order by woocommerce select-block
* Fixed option Display Only Children Of Current Category by simple ajax
* Fixed compatibility with Advanced Woo Search
* Minor issues fix

= 2.7.6 =
* Added compatibility with Theme Elford + Advanced Layout Builder Product Slider and Product Grid
* Added for shortcode ordering by title and rand
* Minor issues fix

= 2.7.5 =
* Disabled option Move Sidebar To Top For Mobile for Neve Theme
* Added REST API notice
* Fixed compatibility with Elementor widget premium-woo-product
* Fixed option Check page category
* Fixed option Display a message about not found products
* Minor issues fix

= 2.7.4 =
* Fixed Close Floating Popup & Clear button
* Minor issues fix

= 2.7.3 =
* Added compatibility ElementorPro Loop Load More
* Added option Display preselected variation and fix compatibility with theme Betheme

= 2.7.2 =
* Fixed preselect stockstatus
* Fixed checkboxes by goback action
* Code fix for GoBack
* Fixed store page for Dokan

= 2.7.1 =
* Fixed count products by preselects
* Added option Unlimited colors/buttons filter
* Minor issues fix

= 2.7.0 =
* Added compatibility for Woo Product Grid by Essential Addons
* Added limit for buttons filter
* Fixed compatibility with theme Sydney
* Added hook for item display name
* Added option in Search Number filter

= 2.6.9 =
* Added compatibility with Beaver Builder block Posts
* Added compatibility for ACF-attributes type Number
* Fixed autoscrolling
* Added option Check page category for Button Filter
* Added limit for color filter
* Fixed autocomplete
* Added compatibility with theme TheGem

= 2.6.8 =
* Added option Use max variations price for sorting
* Fixed default price block opening

= 2.6.7 =
* Added compatibility with Woocommerce block Product Collection
* Added compatibility with AVADA infinitescroll
* Fixed date and popularity sorting
* Minor issues fix

= 2.6.6 =
* Minor issues fix
* Fixed floating popup visibility
* Added option Display one variation price

= 2.6.5 =
* Minor issues fix

= 2.6.4 =
* Added Colors Filter for Tags
* Price filter load fix
* Minor issues fix

= 2.6.3 =
* Fixed Avade infinite scroll for products pagination
* Added preselect for Price slider filter
* Fixed conflict with YITH Request a Quote for WooCommerce
* Fixed conflict with WP Statistics
* Added compatibility with WooCommerce Mix and Match Products
* Minor issues fix

= 2.6.2 =
* Render fix
* Missing meta fix

= 2.6.1 =
* Fixed fatal by deactivation and uninstall
* Added option Keep Min/Max Price By Reload
* Fixed refreshing of price slider
* Fixed ACF-labels for select-fields
* Minor issues fix

= 2.6.0 =
* Fixed style conflict with Elementor
* Fixed conflict with WPML Multilingual CMS
* Added compatibility with Product Table for WooCommerce by CodeAstrology

= 2.5.9 =
* Added compatibility with plugin WooCommerce Multilingual & Multicurrency
* Fixed selected parameters by filter synchronization
* Fixed redirect
* Minor issues fix

= 2.5.8 =
* Added compatibility with pagination from Essential Addons Product Grid
* Fixed shortcode elementor-template
* Minor issues fix

= 2.5.7 =
* Added compatibility with Woo-products from PowerPack Pro for Elementor
* Added dropdown to choose the number of products per page
* Added custom orderby
* Minor issues fix

= 2.5.6 =
* Readme fix
* Minor issues fix

= 2.5.5 =
* Added option Сollapse all when deleting by search for Category filter
* Fixed option Instock always show first
* Fixed compatibility with Fusion Builder

= 2.5.4 =
* Added compatibility with Divi Filter Loadmore
* Fixed statistics for Menu mode
* Fixed reseting of button filters
* Minor issues fix

= 2.5.3 =
* Fixed overlay for floating filter
* Fixed filter overlay for several filters on page
* Fixed option Check page category
* Fixed indexing for attributes with Emojis in slugs
* Fixed Alphabetical index

= 2.5.2 =
* Fixed Alphabetical index for Meta fields
* Fixed default stock status
* Fixed export/import
* Fixed option Checked Items To The Top by Back button
* Fixed option Count products per page
* Added opportunity for force filter refresh
* Added multiple default option for StockStatus Filter
* Add default sorting for custom meta attribute
* Added multiple attributes for Search by Number filter
* Added option Unfolding collapsed by search for Category filter
* Fixed double ajax-filtering
* Minor issues fix

= 2.5.1 =
* Added compatibility with Woocommerce blocks for preselected parameters
* Fixed conflict with WooCommerce Google Product Feed plugin
* Added equals logic for SearchNumber filter
* Added flag for Woocommerce Load More Products
* Fixed option Filter synchronization for color-filters
* Added option Сheck category hierarchy for One by One mode
* Added compatibitity with WooCommerce Measurement Price Calculator
* Added compatibitity with Variation Swatches for WooCommerce - Pro
* Fixed preselects for multilanguage sites
* Added search by the list of attributes for the text filter
* Minor issues fix

= 2.5.0 =
* Fixed count products recalc for list filters
* Added compatibility with Phone Orders for WooCommerce Plugin
* Fixed Not In logic for attributes
* Added compatibility with Divi Archive Loop
* Added hierarchical options for attributes filter
* Minor issues fix

= 2.4.9 =
* Added fix for the ability to filter WBW-tables
* Added formatting for Date Picker type ACF-fields
* Added compatibility with Product Grid by Woo Essential plugin
* Fixed option Show search for attributes
* Fixed attributes labels

= 2.4.8 =
* Added translation for Show More/Show Fewer
* Fixed defaults and preselects
* Added compatibility with YayCurrency Plugin
* Fixed FontAwesome for group colors option
* Minor issues fix

= 2.4.7 =
* Updated custom order for attributes
* Added filter Search by Number
* Fixed Menu mode
* Added decimal step for Price filter
* Added compatibility with theme Total for option Display variation
* Minor issues fix

= 2.4.6 =
* Added updating attribute slider by selected filters
* Minor issues fix

= 2.4.5 =
* Fixed CSV Export Problem
* Fixed Divi load more

= 2.4.4 =
* Fixed bulk activate by TGM Plugin Activation
* Added compatibility with Avada Builder Woo Product Grid
* Fixed Floating filter button
* Fixed default sorting
* Fixed Reset button & default StockStatus option

= 2.4.3 =
* Fixed compatibility with Elementor widget Posts
* Fixed rtl-styles
* Fixed compatibility with Essential Addons Elementor
* Minor issues fix

= 2.4.2 =
* Fixed default filters by not empty url parameters
* Fixed compatibility with plugin CoDesigner
* Fixed count products for Always Filtering By All Products
* Fixed char + in uri with search filter
* Fixed Crear button by redirect
* Added option By default сreate filters for all products
* Fixed pagination for Elementor widget woocommerce-products
* Fixed custom order for attributes
* Fixed Force Theme templates for grid/list display mode
* Fixed bulk plugins activate
* Fixed option Form attribute filters by variations
* Minor issues fix

= 2.4.1 =
* Increased range for Price Slider
* Fixed products count for compatibility with Essential Addons Elementor
* Added selection of filter blocks by creating a new product filter
* Fixed Clear All button
* Minor issues fix

= 2.4.0 =
* Fixed loader style
* Fixed count products for Always Filtering By All Products
* Added compatibility with plugin CoDesigner (Formerly Woolementor)
* Minor issues fix

= 2.3.9 =
* Fixed processing many parallel ajax-requests
* Fixed order by price
* Fixed option Display Variations Instead Of Variable Product for shortcodes
* Added compatibility for Divi Plus pagination
* Added hook for default settings
* Fix for multisite

= 2.3.8 =
* Fixed autocomplete for several TextSearch fields on page
* Added compatibility with widget Premium Woo Products from Premium Addons for Elementor
* Fixed compatibility with Advanced Woo Search
* Added hook for Dokan
* Fixed default params for Visual Builders products block
* Added the ability to select child attributes in the list of displayed
* Minor issues fix

= 2.3.7 =
* Fixed admin area for iphone
* Fixed checkboxes in Firefox
* Added option Hide filter with single item
* Fixed option Close popup after action

= 2.3.6 =
* Fixed deprecated functions

= 2.3.5 =
* Delete PhpMailer
* Added Perfect brands to autocomplete for Search Filter
* Fixed decimals for Numeric Attributes Slider
* Added translatable strings
* Fix for Elementor
* Added option to prevent redirect when product is missing
* Minor issues fix

= 2.3.4 =
* Added compatibility with Royal Addons widget Woo Grid
* Added compatibility for widget Advance Products by Phlox Shop plugin
* Fixed option Don't Use Shortcode Settings
* Fixed products widget from UX Builder by Flatsome Theme
* Fixed attributes filter for variations
* Added compatibility for Besa Theme
* Minor issues fix

= 2.3.3 =
* Fixed Autocomplete search filter
* Added compatibility with plugin Woocommerce Products Per Page and added option Display on Perfect Brands Page
* Minor issues fix

= 2.3.2 =
* Fixed call button in floating mode
* Added compatibility with Qi Addons For Elementor
* Added option for disable loading Fontawesome library
* Fixed bug when temporary tables not allowed in DB
* Hid last license error
* Rebranding

= 2.3.1 =
* Added option for Hide price slider if there are no products with price
* Fixed compatibility with Elementor
* Added compatibility with Flatsome UXBuilder
* Added compatibility with Relevanssi Plugin
* Added compatibility with Perfect Brands in the Search Text Filter
* Declaring compatibility with HPOS
* Minor issues fix

= 2.3.0 =
* Minor issues fix

= 2.2.9 =
* Fixed Hide Filter Button on mobile
* Minor issues fix

= 2.2.8 =
* Added for Hide Filters Button option Show as open if filtered
* Added custom order for ACF-attributes

= 2.2.7 =
* Fixed option Recount Products By Selected Filter by page reload
* Minor issues fix

= 2.2.6 =
* Added compatibility with CURCY plugin
* Minor issues fix

= 2.2.5 =
* Added the filtering variations by stock status
* Minor issues fix

= 2.2.4 =
* Fix for Woocommerce Loockup table regeneration
* Minor issues fix

= 2.2.3 =
* Fixed brands filter
* Fixed expired license msg

= 2.2.2 =
* Fixed categories hierarchy
* Minor issues fix

= 2.2.1 =
* Fixed color group
* Fixed floating mode
* Fixed scroll for Floating mode
* Minor issues fix

= 2.2.0 =
* Added Overview
* Added Single select for Colors
* Fixed hide empty block
* Minor issues fix

= 2.1.9 =
* Added dynamic loading of color groups
* Fix color group && encode get meta value
* Minor issues fix

= 2.1.8 =
* Added clear & reset onebyone
* Added Floating mode customization
* Fixed get meta value
* Added scroll top for option 'Checked Items To The Top'
* Added alternative update server
* Minor issues fix

= 2.1.7 =
* Fixed buttons filter && autoscroll
* Fixed OR logic
* Added Statistics
* Added loader icon on filter during automatic filter update
* Minor issues fix

= 2.1.6 =
* Fixed color group
* Fixed Sorting Oldest first
* Minor issues fix

= 2.1.5 =
* Added option 'Disable Instead Of Hiding Following'
* Added synchronization of multiple filters
* Floating filter mode added
* Fixed display of hierarchy icons
* Fixed slider output with OR logic
* Added option "Display Only Children Of Current Category"
* Added reset counters
* Minor issues fix

= 2.1.4 =
* Added option Sort In stock first
* Fixed activation license using the second site
* Added option Exclude variations on backorder
* Minor issues fix

= 2.1.3 =
* Added option "Hide current page category"
* Fixed forced query for elementor

= 2.1.2 =
* Added support for product_id when defining photo for displaying variation
* Fixed filter change event handler
* Added check woocommerce option "woocommerce_hide_out_of_stock_items"
* Fixed work group color

= 2.1.1 =
* Fixed WCAG + text filter type
* Added hide expired license notification
* Fixed undefined variable: metaKeyId
* Fixed css & notice
* Added option "display variation image"
* Fixed SearchText Filter
* Added compatibility with DynamicPostsBase
* Changed prefix from filter_ to wpf_filter
* Added wpf_ prefix for max_price and min_price
* Minor issues fix

= 2.1.0 =
* Fixed attributes slider
* Add class `needsclick` to multiselect
* Minor issues fix

= 2.0.9 =
* Added option 'show all slider attributes'
* Added optiona to show widget on all site pages
* Fixed meta attributes slider after Clear
* Added option "Do not remove products on loading"

= 2.0.8 =
* Fixed default Price filter for rtl
* Added variation links and fixed variation image
* Minor issues fix

= 2.0.7 =
* Added settings to attribute color
* Added filter import/export
* Moved "wcag" option to the free version
* Add option "open filters one by one" for step by step filer
* Added "Menu mode" for category filter
* Improved WPML compatibility

= 2.0.6 =
* Fixed option Unfolding children
* Added style options for the selected item
* Added "default id" options for views mul_dropdown, buttons, text
* Fixed price maxvalue && restore query
* Added bold for selected items
* Added custom styling for Hide Button
* Added tooltip to "Floating button on mobile" checkbox
* Minor code fixes

= 2.0.5 =
* Fixed search in multy-dropdowm
* Optimized option Include children for category
* Fixed option "apply parameters from the address bar ..."
* Minor code fixes

= 2.0.4 =
* Fixed search filter
* Fixed tax for Price filter
* Added option 'unfolding all nesting levels' && collapse other radioboxes
* Fixed group colors for variations
* Minor code fixes

= 2.0.3 =
* Meta-indexing optimization for DB with many variable products and many attributes
* Added advertising of the pro version to the free version
* Fixed adding an event handler to the filter button
* Fixed bug with multiple blocks in force template
* Fixed query if active plugins essential-addons-for-elementor-lite

= 2.0.2 =
* Fixed brand select
* Add show currency in slider
* Added option in search filter 'disable auto filtering when focus out'
* Fixed selection default value in the stock filter
* Plugin rename
* Minor code fixes

= 2.0.1 =
* Fixed display of child filter items
* Added new display mode "Brand Page"
* Fixed update after deactivation
* Added Default for Sort Filter
* Fixed color group
* Added last check license errors
* Fixed output with empty parent categories
* Minor code fixes

= 2.0.0 =
* Performance optimizations
* Added option "Checkbox list (multiple select)" and "Layout" in Product Brands
* Fixed meta data filter
* Fixed filtering by variations
* Fixed color group with variations, etc
* Fixed meta sliders
* Fixed untranslatable links "Show more" and "Show fewer" for German language
* Added multiselect brand selection
