/**
 * WBW Product Filter PRO  - Admin WooFilters List Pro JS
 *
 * @version 3.4.7
 * @since   3.3.0
 *
 * @author WBW
 */
jQuery( document ).ready( function ( $ ) {
	"use strict";

	// Fallback for case if library was not loaded
	if ( ! $.fn.jqGrid ) {
		return;
	}

	// `#wpfTableExportBtn` on click
	$( '#wpfTableExportBtn' ).on( 'click', function ( e ) {
		e.preventDefault();

		var selectedRowIds = $( '#wpfTableTbl' ).jqGrid( 'getGridParam', 'selarrrow' ),
			listIds = [];
		for ( var i in selectedRowIds ) {
			var rowData = $( '#wpfTableTbl' ).jqGrid( 'getRowData', selectedRowIds[ i ] );
			listIds.push( rowData.id );
		}

		if ( listIds.length ) {
			$.sendFormWpf( {
				btn: this,
				data: {
					mod: 'woofilterpro',
					action: 'woobewoo_pf_export_group',
					listIds: listIds,
					wpfNonce: woobewoo_pf_admin_ajax_object.nonce
				},
				onSuccess: function ( res ) {
					if ( ! res.error ) {
						var blob = new Blob(
							[ res.data.tables ],
							{ type: 'text/sql' }
						);
						var fileName = 'wpf_export.sql';
						var link = document.createElement( 'a' );
						link.href = window.URL.createObjectURL( blob );
						link.download = fileName;
						link.click();

						$( '#wpfTableTbl' ).trigger( 'reloadGrid' );
						link.remove();
					}
				}
			} );
		}
		return false;
	} );

	// *******  import filters START  *******
	var $importForm = $( '#wpfImportForm' );
	$( '<input type="hidden" name="wpfNonce" value="' + woobewoo_pf_admin_ajax_object.nonce + '">' ).appendTo( $importForm );
	var $importWnd = $( '#wpfImportWnd' ).dialog( {
		modal: true,
		autoOpen: false,
		width: 500,
		height: 250,
		buttons: {
			'Import': function () {
				$importForm.submit();
			}
		},
		create: function () {
			$( this ).closest( '.ui-dialog' ).addClass( 'woobewoo-plugin' );
			if ( WPF_DATA.isWCLicense ) {
				$( this ).closest( '.ui-dialog' ).find( '.ui-dialog-buttonset button' ).addClass( 'button button-primary' );
			}
		}
	} );
	var $importSubmitBtn = $importWnd.parents( '.ui-dialog:first' ).find( '.ui-dialog-buttonpane .ui-dialog-buttonset' ).find( 'button:first' );

	$importForm.submit( function () {
		$importSubmitBtn.width( $importSubmitBtn.width() );
		$importSubmitBtn.showLoaderWpf();
		var url = '';
		if ( typeof (
			ajaxurl
		) == 'undefined' || typeof (
			ajaxurl
		) !== 'string' ) {
			url = WPF_DATA.ajaxurl;
		} else {
			url = ajaxurl;
		}

		var formData = new FormData( $importForm.get( 0 ) );

		$.ajax( {
			url: woobewoo_pf_admin_ajax_object.ajaxurl,
			data: formData,
			type: 'POST',
			processData: false,
			contentType: false,
			dataType: 'json',
			success: function ( res ) {
				if ( ! res.error ) {
					$importWnd.dialog( 'close' );
					$( '#wpfImportInput' ).val( '' );
					$( '#wpfTableTbl' ).trigger( 'reloadGrid' );

					$.sNotify( {
						'icon': 'fa fa-check',
						'content': ' <span>' + res.messages[0] + '</span>',
						'delay': 2500
					} );
				} else {
					$.sNotify( {
						'icon': 'fa fa-exclamation',
						'content': ' <span>' + res.errors[0] + '</span>',
						'delay': 2500
					} );
				}

				$importSubmitBtn.html( 'Import' );
			}
		} );
		return false;
	} );

	$( '#wpfTableImportBtn' ).on( 'click', function ( e ) {
		e.preventDefault();
		$importWnd.dialog( 'open' );
		return false;
	} );
	// *******  import filters END  *******

	// *******  enable/disable statistics  *******
	var $statEForm = $( '#wpfStatsEForm' ),
		$statDForm = $( '#wpfStatsDForm' ),
		$statEWnd = $( '#wpfStatsEWnd' ).dialog( {
			modal: true,
			autoOpen: false,
			width: 500,
			height: 300,
			buttons: [
				{
					text: $statEForm.attr( 'data-submit' ),
					click: function () {
						$statEForm.submit();
					}
				}
			],
			create: function () {
				$( this ).closest( '.ui-dialog' ).addClass( 'woobewoo-plugin' );
				if ( WPF_DATA.isWCLicense ) {
					$( this ).closest( '.ui-dialog' ).find( '.ui-dialog-buttonset button' ).addClass( 'button button-primary' );
				}
			}
		} ), $statDWnd = $( '#wpfStatsDWnd' ).dialog( {
			modal: true,
			autoOpen: false,
			width: 500,
			height: 250,
			buttons: [
				{
					text: $statDForm.attr( 'data-submit' ),
					click: function () {
						$statDForm.submit();
					}
				}
			],
			create: function () {
				$( this ).closest( '.ui-dialog' ).addClass( 'woobewoo-plugin' );
				if ( WPF_DATA.isWCLicense ) {
					$( this ).closest( '.ui-dialog' ).find( '.ui-dialog-buttonset button' ).addClass( 'button button-primary' );
				}
			}
		} );

	var tblId = 'wpfTableTbl',
		tableObj = $( '#' + tblId );
	tableObj.on( 'click', '.wpf-statistics', function ( e ) {
		e.preventDefault();
		console.log( 'you are here' );
		var $this = $( this ),
			id = $this.attr( 'data-id' );
		if ( $this.hasClass( 'wpf-action-on' ) ) {
			$statDWnd.dialog( 'open' );
			$statDWnd.find( 'input[name="id"]' ).val( id );
		} else {
			$statEWnd.dialog( 'open' );
			$statEWnd.find( 'input[name="id"]' ).val( id );
		}
		return false;
	} );

	$( '#wpfStatsEForm, #wpfStatsDForm' ).on( 'submit', function ( e ) {
		e.preventDefault();
		var $form = $( this ),
			$submitButton = $form.parents( '.ui-dialog:first' ).find( '.ui-dialog-buttonpane .ui-dialog-buttonset' ).find( 'button:first' );
		$submitButton.width( $submitButton.width() );
		$submitButton.showLoaderWpf();
		$form.sendFormWpf( {
			btn: $submitButton,
			data: {
				mod: 'statistics',
				action: $form.find( '[name="action"]' ).val(),
				id: $form.find( '[name="id"]' ).val(),
				wpfNonce: woobewoo_pf_admin_ajax_object.nonce
			},
			onSuccess: function ( res ) {
				if ( ! res.error ) {
					var $icon = tableObj.find( '.wpf-statistics[data-id="' + $form.find( 'input[name="id"]' ).val() + '"]' );
					if ( $form.is( '#wpfStatsEForm' ) ) {
						$statEWnd.dialog( 'close' );
						$icon.addClass( 'wpf-action-on' ).removeClass( 'wpf-action-off' );
					} else {
						$statDWnd.dialog( 'close' );
						$icon.addClass( 'wpf-action-off' ).removeClass( 'wpf-action-on' );
					}
					$submitButton.html( $form.attr( 'data-submit' ) );
					$icon.blur();
				}
			}
		} );
		return false;
	} );
} );
