<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Woofilterpro_Controller Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_Woofilterpro_Controller extends WooBeWoo_PF_Controller {

	/**
	 * autocompliteSearchText.
	 *
	 * @version 3.4.0
	 */
	public function autocompliteSearchText() {
		$res      = new WooBeWoo_PF_Response();
		$keyword  = WooBeWoo_PF_Req::getVar( 'keyword' );
		$filterId = WooBeWoo_PF_Req::getVar( 'filterId' );

		$autocomplete =
			WooBeWoo_PF_Frame::_()->
			getModule( 'woofilterpro' )->
			getModel( 'autocomplete' )->
			init( $keyword, $filterId );

		$autocompleteData = $autocomplete->getData();

		$res->addData( 'autocompleteData', $autocompleteData );
		return $res->ajaxExec();
	}

	/**
	 * applyLoader.
	 *
	 * @version 3.4.0
	 */
	public function applyLoader() {
		$res      = new WooBeWoo_PF_Response();
		$id       = WooBeWoo_PF_Req::getVar( 'id' );
		$settings = WooBeWoo_PF_Req::getVar( 'settings' );

		$model   = WooBeWoo_PF_Frame::_()->getModule( 'woofilters' )->getModel( 'woofilters' );
		$filters = $model->getFromTbl();
		$cnt     = 0;
		foreach ( $filters as $filter ) {
			$current = unserialize( $filter['setting_data'] );
			if ( $filter['id'] != $id && isset( $current['settings'] ) ) {
				$filter['settings'] = array_merge( $current['settings'], $settings );
				unset( $filter['setting_data'] );
				$model->save( $filter );
				++$cnt;
			}
		}
		$res->addData( 'message', $cnt . esc_html__( ' filters have been changed', 'woo-product-filter' ) );
		return $res->ajaxExec();
	}

	/**
	 * woobewoo_pf_export_group.
	 *
	 * @version 3.4.0
	 */
	public function woobewoo_pf_export_group() {
		WooBeWoo_PF_Req::verifyRequest();
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die();
		}
		$res  = new WooBeWoo_PF_Response();
		$data = WooBeWoo_PF_Frame::_()->getModule( 'woofilterpro' )->exportGroup( WooBeWoo_PF_Req::getVar( 'listIds', 'post' ) );
		if ( $data ) {
			$res->addData( 'tables', $data );
			$res->addMessage( esc_html__( 'Done', 'woo-product-filter' ) );
		} else {
			$res->pushError( $this->getModel( 'woofilters' )->getErrors() );
		}
		$res->ajaxExec();
	}

	/**
	 * importGroup.
	 *
	 * @version 3.4.0
	 */
	public function importGroup() {
		WooBeWoo_PF_Req::verifyRequest();

		$res  = new WooBeWoo_PF_Response();
		$file = WooBeWoo_PF_Req::getVar( 'import_file', 'files' );

		if ( empty( $file['tmp_name'] ) ) {
			$res->pushError( esc_html__( 'No file selected.', 'woo-product-filter' ) );
			return $res->ajaxExec( true );
		}

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		global $wp_filesystem;

		WP_Filesystem();

		if ( ! $wp_filesystem->exists( $file['tmp_name'] ) ) {
			$res->pushError( esc_html__( 'Uploaded file not found.', 'woo-product-filter' ) );
			return $res->ajaxExec( true );
		}

		$sql = $wp_filesystem->get_contents( $file['tmp_name'] );
		if ( false === $sql ) {
			$res->pushError( esc_html__( 'Unable to read the uploaded file.', 'woo-product-filter' ) );
			return $res->ajaxExec( true );
		}

		$imported = WooBeWoo_PF_Db::query( $sql );

		if ( $imported ) {
			$res->addMessage( esc_html__( 'Done.', 'woo-product-filter' ) );
		} else {
			$res->pushError( esc_html__( 'Error importing file.', 'woo-product-filter' ) );
		}

		return $res->ajaxExec( true );
	}

	/**
	 * getPermissions.
	 *
	 * @version 3.3.0
	 * @since   3.1.3
	 *
	 * @return array
	 */
	public function getPermissions() {
		return array(
			WPF_METHODS => array(
				'woobewoo_pf_export_group' => array(
					WPF_ADMIN,
				),
				'importGroup'              => array(
					WPF_ADMIN,
				),
				'applyLoader'              => array(
					WPF_ADMIN,
				),
				'autocompliteSearchText'   => array(
					WPF_ADMIN,
					WPF_LOGGED,
					WPF_GUEST,
				),
			),
		);
	}
}
