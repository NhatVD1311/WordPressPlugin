<?php
/**
 * WBW Product Filter PRO - Part Edit Tab Design General Custom CSS/JS
 *
 * @version 3.4.6
 * @since   3.4.5
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

$settings = $this->getFilterSetting( $this->settings, 'settings', array() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$can_edit = current_user_can( 'unfiltered_html' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
if ( ! $can_edit ) {
	?>
	<div class="woobewoo_row row-settings-block">
		<div class="settings-block-values settings-w100 col-xs-12">
			<?php esc_html_e( 'Only users allowed to post unfiltered HTML can change the custom CSS and JS. The saved code is kept.', 'woo-product-filter' ); ?>
		</div>
	</div>
	<?php
}
?>
<div class="woobewoo_row row-settings-block">
	<div class="settings-block-label col-xs-4 col-sm-3">
		<?php esc_html_e( 'CSS editor', 'woo-product-filter' ); ?>
		<i
			class="fa fa-question woobewoo-tooltip"
			title="<?php echo esc_attr__( 'Custom CSS', 'woo-product-filter' ); ?>"
		></i>
	</div>
	<div class="settings-block-values settings-w100 col-xs-12 col-sm-9">
		<?php
		WooBeWoo_PF_Html::textarea( 'settings[css_editor]', array(
			'value'      => wp_unslash( base64_decode( $this->settings['settings']['css_editor'] ?? '' ) ),
			'auto_width' => true,
			'disabled'   => ! $can_edit,
		) );
		?>
	</div>
</div>
<div class="woobewoo_row row-settings-block" data-no-preview="1">
	<div class="settings-block-label col-xs-4 col-sm-3">
		<?php esc_html_e( 'JS editor', 'woo-product-filter' ); ?>
		<i
			class="fa fa-question woobewoo-tooltip"
			title="<?php echo esc_attr__( 'Custom JS', 'woo-product-filter' ); ?>"
		></i>
	</div>
	<div class="settings-block-values settings-w100 col-xs-12 col-sm-9">
		<?php
		WooBeWoo_PF_Html::textarea( 'settings[js_editor]', array(
			'value'      => wp_unslash( base64_decode( $this->settings['settings']['js_editor'] ?? '' ) ),
			'auto_width' => true,
			'disabled'   => ! $can_edit,
		) );
		?>
	</div>
</div>
<?php
