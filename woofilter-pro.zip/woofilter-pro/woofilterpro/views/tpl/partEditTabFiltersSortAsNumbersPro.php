<?php
/**
 * WBW Product Filter PRO - Part Edit Tab Filters Sort As Numbers Pro
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="settings-value settings-w100" data-parent="f_sort_by" data-no-values="default">
	<div class="settings-value-label" >
		<?php esc_html_e( 'Sort as numbers', 'woo-product-filter' ); ?>
		<i class="fa fa-question woobewoo-tooltip no-tooltip" title="<?php echo esc_attr__( 'Turn this on if you want to sort the values as numbers.', 'woo-product-filter' ); ?>"></i>
	</div>
	<?php WooBeWoo_PF_Html::checkboxToggle( 'f_sort_as_numbers', array() ); ?>
</div>
