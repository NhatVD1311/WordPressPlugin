<?php
/**
 * WBW Product Filter PRO - Part Edit Tab Filters Search List Pro
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="settings-value settings-w100" data-parent="f_show_search_input">
	<div class="settings-value-label">
		<?php esc_html_e( 'Position', 'woo-product-filter' ); ?>
	</div>
	<?php
	WooBeWoo_PF_Html::selectbox(
		'f_search_position',
		array(
			'options' => array(
				'before' => esc_attr__( 'Before', 'woo-product-filter' ),
				'after'  => esc_attr__( 'After', 'woo-product-filter' ),
			),
			'attrs'   => 'class="woobewoo-flat-input"',
		)
	);
	?>
</div>
<div class="settings-value settings-w100" data-parent="f_show_search_input">
	<div class="settings-value-label">
		<?php esc_html_e( 'Search button', 'woo-product-filter' ); ?>
	</div>
	<?php WooBeWoo_PF_Html::checkboxToggle( 'f_show_search_button', array() ); ?>
</div>
