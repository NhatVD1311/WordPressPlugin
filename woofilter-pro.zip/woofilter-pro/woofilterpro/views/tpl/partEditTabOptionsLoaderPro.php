<?php
/**
 * WBW Product Filter PRO - Part Edit Tab Options Loader Pro
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="clear"></div>
<div class="settings-value wpfSelectFile settings-w100">
	<?php
	WooBeWoo_PF_Html::hidden(
		'settings[filter_loader_custom_icon]',
		array(
			'value' => ( isset( $this->settings['settings']['filter_loader_custom_icon'] ) ? $this->settings['settings']['filter_loader_custom_icon'] : '' ),
			'attrs' => ' data-loader-settings="1"',
		)
	);
	WooBeWoo_PF_Html::buttonA(
		array(
			'value' => esc_attr__( 'Select icon', 'woo-product-filter' ),
			'attrs' => 'id="wpfSelectLoaderButton" data-type="image"',
		)
	);
	?>
</div>
<div class="settings-value">
	<div class="settings-value-label">
		<?php esc_html_e( 'animation', 'woo-product-filter' ); ?>
	</div>
	<?php
	WooBeWoo_PF_Html::selectbox(
		'settings[filter_loader_custom_animation]',
		array(
			'options' => array(
				''       => esc_attr__( 'none', 'woo-product-filter' ),
				'flip'   => esc_attr__( 'flip', 'woo-product-filter' ),
				'jump'   => esc_attr__( 'jump', 'woo-product-filter' ),
				'rotate' => esc_attr__( 'rotate', 'woo-product-filter' ),
			),
			'value'   => ( isset( $this->settings['settings']['filter_loader_custom_animation'] ) ? $this->settings['settings']['filter_loader_custom_animation'] : '' ),
			'attrs'   => 'class="woobewoo-flat-input"',
		)
	);
	?>
</div>
