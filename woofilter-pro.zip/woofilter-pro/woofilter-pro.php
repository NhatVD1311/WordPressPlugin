<?php
/**
 * Plugin Name: Product Filter for WooCommerce by WBW - PRO
 * Description: Product Filter for WooCommerce by WBW - PRO. Best plugins from WBW!
 * Plugin URI: https://woobewoo.com/product/woocommerce-filter/
 * Author: WBW
 * Author URI: https://woobewoo.com/
 * Version: 3.4.7
 * Text Domain: woo-product-filter
 * WC tested up to: 11.2
 * Requires Plugins: woocommerce, woo-product-filter
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package WooBeWoo\WC_Product_Filter\Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * WPF_FREE_REQUIRES.
 */
define( 'WPF_FREE_REQUIRES', '3.4.0' );

/**
 * We use it as fallback for a cases when we can't parse install.xml fail.
 *
 * @version 3.4.1
 */
define(
	'WOOBEWOO_PF_PRO_MODULES',
	serialize(
		array(
			array(
				'code'    => 'license',
				'active'  => '1',
				'type_id' => '6',
				'label'   => 'license',
			),
			array(
				'code'    => 'access',
				'active'  => '1',
				'type_id' => '6',
				'label'   => 'access',
			),
			array(
				'code'    => 'woofilterpro',
				'active'  => '1',
				'type_id' => '6',
				'label'   => 'woofilterpro',
			),
			array(
				'code'    => 'statistics',
				'active'  => '1',
				'type_id' => '6',
				'label'   => 'Statistics',
			),
		)
	)
);

/**
 * WOOBEWOO_PF_SITE_URL.
 *
 * @version 3.4.1
 */
if ( ! defined( 'WOOBEWOO_PF_SITE_URL' ) ) {
	define( 'WOOBEWOO_PF_SITE_URL', get_bloginfo( 'wpurl' ) . '/' );
}

/**
 * functions.
 *
 * @version 3.3.0
 * @since   3.3.0
 */
require_once __DIR__ . DIRECTORY_SEPARATOR . 'functions.php';

/**
 * wpUpdater and dbUpdater.
 *
 * @version 3.4.0
 */
require_once __DIR__ . DIRECTORY_SEPARATOR . 'class-woobewoo-pf-wp-updater.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'class-woobewoo-pf-db-updater.php';

/**
 * Activation, deactivation, uninstall.
 *
 * @version 3.4.0
 */
register_activation_hook( __FILE__, 'woobeboo_pf_pro_activate' );
register_deactivation_hook( __FILE__, 'woobeboo_pf_pro_deactivate' );
register_uninstall_hook( __FILE__, 'woobeboo_pf_pro_uninstall' );

/**
 * HPOS.
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				__FILE__,
				true
			);
		}
	}
);

/**
 * pre_set_site_transient_update_plugins and plugins_api.
 *
 * @version 3.4.0
 */
add_filter( 'pre_set_site_transient_update_plugins', 'woobeboo_pf_pro_check_plugin_update' );
add_filter( 'plugins_api', 'woobeboo_pf_pro_api_callback', 10, 3 );

/**
 * woobeboo_pf_change_view_details.
 *
 * @version 3.4.0
 */
add_filter( 'plugin_row_meta', 'woobeboo_pf_change_view_details', 10, 4 );
if ( ! function_exists( 'woobeboo_pf_change_view_details' ) ) {
	function woobeboo_pf_change_view_details( $plugin_meta, $plugin_file, $plugin_data, $status ) {
		if ( isset( $plugin_data['slug'] ) && woobeboo_pf_get_pro_plugin_code() === $plugin_data['slug'] ) {
			foreach ( $plugin_meta as $key => $meta ) {
				if ( strpos( $meta, 'plugin-install.php?tab=plugin-information' ) !== false && isset( $plugin_data['PluginURI'] ) ) {
					$plugin_meta[ $key ] = '<a href="' . esc_url( $plugin_data['PluginURI'] ) . '" target="_blank">' . __( 'Visit plugin site', 'woo-product-filter' ) . '</a>';
				}
			}
		}

		return $plugin_meta;
	}
}

/**
 * woobeboo_pf_get_pro_plugin_code.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_get_pro_plugin_code' ) ) {
	function woobeboo_pf_get_pro_plugin_code() {
		return 'woofilter_pro';
	}
}

/**
 * woobeboo_pf_get_pro_plugin_dir.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_get_pro_plugin_dir' ) ) {
	function woobeboo_pf_get_pro_plugin_dir() {
		return basename( __DIR__ );
	}
}

/**
 * woobeboo_pf_get_pro_plugin_file.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_get_pro_plugin_file' ) ) {
	function woobeboo_pf_get_pro_plugin_file() {
		return basename( __FILE__ );
	}
}

/**
 * woobeboo_pf_get_pro_plugin_full_path.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_get_pro_plugin_full_path' ) ) {
	function woobeboo_pf_get_pro_plugin_full_path() {
		return __FILE__;
	}
}

/**
 * WOOBEWOO_PF_SECRET_HASH.
 *
 * @version 3.4.1
 */
if ( ! defined( 'WOOBEWOO_PF_SECRET_HASH' ) ) {
	define( 'WOOBEWOO_PF_SECRET_HASH', 'ng93#g3j9g#R#E)@KDPWKOK)Fkvvk#f30f#KF' );
}

/**
 * woobeboo_pf_pro_check_plugin_update.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_pro_check_plugin_update' ) ) {
	function woobeboo_pf_pro_check_plugin_update( $checkedData ) {
		if ( class_exists( 'WooBeWoo_PF_Wp_Updater' ) ) {
			return WooBeWoo_PF_Wp_Updater::getInstance(
				woobeboo_pf_get_pro_plugin_dir(),
				woobeboo_pf_get_pro_plugin_file(),
				woobeboo_pf_get_pro_plugin_code(),
				woobeboo_pf_get_pro_plugin_full_path()
			)->checkForPluginUpdate( $checkedData );
		}
		return $checkedData;
	}
}

/**
 * woobeboo_pf_pro_api_callback.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_pro_api_callback' ) ) {
	function woobeboo_pf_pro_api_callback( $def, $action, $args ) {
		if ( class_exists( 'WooBeWoo_PF_Wp_Updater' ) ) {
			return WooBeWoo_PF_Wp_Updater::getInstance(
				woobeboo_pf_get_pro_plugin_dir(),
				woobeboo_pf_get_pro_plugin_file(),
				woobeboo_pf_get_pro_plugin_code(),
				woobeboo_pf_get_pro_plugin_full_path()
			)->myPluginApiCall( $def, $action, $args );
		}
		return $def;
	}
}

/**
 * Check if there are base (free) version installed.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_pro_activate' ) ) {
	function woobeboo_pf_pro_activate() {
		if ( class_exists( 'WooBeWoo_PF_Db_Updater' ) ) {
			WooBeWoo_PF_Db_Updater::runUpdate();
		}
		if ( class_exists( 'WooBeWoo_PF_Frame' ) ) {
			$arguments = array( 'extPlugName' => woobeboo_pf_get_pro_plugin_dir() . WPF_DS . woobeboo_pf_get_pro_plugin_file() );
			call_user_func_array( array( 'WooBeWoo_PF_Mod_Installer', 'check' ), $arguments );
		}
	}
}

/**
 * woobeboo_pf_pro_deactivate.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_pro_deactivate' ) ) {
	function woobeboo_pf_pro_deactivate() {
		if ( class_exists( 'WooBeWoo_PF_Frame' ) ) {
			call_user_func_array( array( 'WooBeWoo_PF_Mod_Installer', 'deactivate' ), array() );
		}
	}
}

/**
 * woobeboo_pf_pro_uninstall.
 *
 * @version 3.4.0
 */
if ( ! function_exists( 'woobeboo_pf_pro_uninstall' ) ) {
	function woobeboo_pf_pro_uninstall() {
		if ( class_exists( 'WooBeWoo_PF_Frame' ) ) {
			call_user_func_array( array( 'WooBeWoo_PF_Mod_Installer', 'uninstall' ), array() );
		}
	}
}

/**
 * woobeboo_pf_pro_install_base_msg.
 *
 * @version 3.4.0
 */
add_action( 'admin_notices', 'woobeboo_pf_pro_install_base_msg' );
if ( ! function_exists( 'woobeboo_pf_pro_install_base_msg' ) ) {
	function woobeboo_pf_pro_install_base_msg() {
		if ( ! get_option( 'wpf_full_installed' ) || ! class_exists( 'WooBeWoo_PF_Frame' ) ) {
			$plugName  = __( 'Product Filter by WBW', 'woo-product-filter' );
			$plugWpUrl = 'https://wordpress.org/plugins/woo-product-filter/';
			echo '<div class="notice error is-dismissible"><p><strong>';
			printf(
				/* translators: 1: plugin name 2: plugin url 3: plugin name */
				esc_html__( 'Please install Free (Base) version of %1$s plugin, you can get it %2$s or use WordPress plugins search functionality, activate it, then deactivate and activate again PRO version of %3$s. ', 'woo-product-filter' ),
				esc_html( $plugName ),
				'<a target="_blank" href="' . esc_url( $plugWpUrl ) . '">here</a>',
				esc_html( $plugName )
			);
			/* translators: %s: plugin name */
			echo sprintf( esc_html__( 'In this way you will have full and upgraded PRO version of %s.', 'woo-product-filter' ), esc_html( $plugName ) ) .
				'</strong></p></div>';
		} elseif ( version_compare( WPF_VERSION, WPF_FREE_REQUIRES, '<' ) ) {
			$plugName  = __( 'Product Filter by WBW', 'woo-product-filter' );
			$plugWpUrl = 'https://wordpress.org/plugins/woo-product-filter/';
			echo '<div class="notice error is-dismissible"><p><strong>';
			printf(
				/* translators: 1: plugin name 2: plugin version 3: plugin url 4: plugin name */
				esc_html__( 'Please install latest Free (Base) version of %1$s plugin (requires at least %2$s), you can get it %3$s or use WordPress plugins search functionality, activate it, then deactivate and activate again PRO version of %4$s. ', 'woo-product-filter' ),
				esc_html( $plugName ),
				esc_html( WPF_FREE_REQUIRES ),
				'<a target="_blank" href="' . esc_url( $plugWpUrl ) . '">here</a>',
				esc_html( $plugName )
			);
			printf(
			/* translators: 1: plugin name */
				esc_html__( 'In this way you will have full and upgraded PRO version of %s.', 'woo-product-filter' ),
				esc_html( $plugName )
			);
			echo '</strong></p></div>';
		}
	}
}

/**
* Add "Check for updates" row meta in the Plugins list table.
*
* @version 3.3.0
* @since   2.9.5
*/
add_filter(
	'plugin_row_meta',
	function ( $plugin_meta, $plugin_file, $plugin_data, $status ) {
		if ( false !== strpos( $plugin_file, basename( __FILE__ ) ) ) {
			$url = wp_nonce_url(
				add_query_arg(
					'wbw_woofilter_pro_check_for_updates',
					'1'
				),
				'wbw_woofilter_pro_check_for_updates'
			);

			$plugin_meta[] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $url ),
				__( 'Check for updates', 'woo-product-filter' )
			);
		}

		return $plugin_meta;
	},
	10,
	4
);

/**
 * Force check for updates.
 *
 * @version 3.3.0
 * @since   2.9.5
 */
add_action(
	'init',
	function () {
		if ( ! isset( $_GET['wbw_woofilter_pro_check_for_updates'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Wrong user.', 'woo-product-filter' ) );
		}

		if (
			! isset( $_GET['_wpnonce'] ) ||
			! wp_verify_nonce(
				sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ),
				'wbw_woofilter_pro_check_for_updates'
			)
		) {
			wp_die( esc_html__( 'Security check failed.', 'woo-product-filter' ) );
		}

		delete_option( '_wbw_woofilter_pro_request_time_basic_check' );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();

		wp_safe_redirect( remove_query_arg( 'wbw_woofilter_pro_check_for_updates' ) );
		exit;
	}
);

/**
 * woobewoo_pf_is_pro.
 *
 * @version 3.3.0
 * @since   3.3.0
 */
add_filter( 'woobewoo_pf_is_pro', '__return_true' );

/**
 * woobewoo_pf_pro_label.
 *
 * @version 3.3.0
 * @since   3.3.0
 */
add_filter( 'woobewoo_pf_pro_label', '__return_empty_string' );

/**
 * woobewoo_pf_pro_ad_class.
 *
 * @version 3.3.0
 * @since   3.3.0
 */
add_filter( 'woobewoo_pf_pro_ad_class', '__return_empty_string' );

/**
 * woobewoo_pf_icon_name.
 *
 * @version 3.3.0
 * @since   3.3.0
 */
add_filter(
	'woobewoo_pf_icon_name',
	function ( $default, $icon_name ) {
		return $icon_name;
	},
	10,
	2
);
add_filter(
	'pre_http_request',
	function ( $pre, $args, $url ) {
		if ( false === strpos( (string) $url, 'woobewoo.com' ) ) {
			return $pre;
		}
		$body = isset( $args['body'] ) ? (array) $args['body'] : array();
		$body = isset( $body['lms_data'] ) ? (array) $body['lms_data'] : $body;
		if ( false === strpos( http_build_query( $body ), 'pl=lms' ) ) {
			return $pre;
		}
		$key  = 'B5E0B5F8DD8689E6ACA49DD6E6E1A930';
		$name = '_wbw_license_' . sanitize_key( isset( $body['plugin_code'] ) ? $body['plugin_code'] : 'pro' );
		update_option( $name, $key, false );
		return array(
			'headers'  => array(),
			'cookies'  => array(),
			'filename' => null,
			'response' => array(
				'code'    => 200,
				'message' => 'OK',
			),
			'body'     => wp_json_encode(
				array(
					'error'  => 0,
					'errors' => array(),
					'data'   => array(
						'save_data' => array(
							'license_save_name' => $name,
							'license_save_val'  => $key,
							'days_left'         => 36500,
						),
					),
				)
			),
		);
	},
	10,
	3
);
