<?php
/**
 * WBW Product Filter PRO - Functions
 *
 * @version 3.4.0
 * @since   3.3.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

/**
 * woobewoo_pf_show_pro_notice.
 *
 * @version 3.4.0
 * @since   3.3.0
 */
add_filter( 'woobewoo_pf_show_pro_notice', 'woobewoo_pf_show_pro_notice' );
if ( ! function_exists( 'woobewoo_pf_show_pro_notice' ) ) {
	function woobewoo_pf_show_pro_notice( $show ) {
		if ( ! class_exists( 'WooBeWoo_PF_Frame' ) || ! defined( 'WPF_PRO_REQUIRES' ) ) {
			return false;
		}

		return ! WooBeWoo_PF_Frame::_()->proVersionCompare( WPF_PRO_REQUIRES, '>=' );
	}
}

/**
 * woobewoo_pf_install_base_msg_pro.
 *
 * @version 3.4.0
 * @since   3.3.0
 */
add_action( 'admin_notices', 'woobewoo_pf_install_base_msg_pro' );
if ( ! function_exists( 'woobewoo_pf_install_base_msg_pro' ) ) {
	function woobewoo_pf_install_base_msg_pro() {
		if ( ! apply_filters( 'woobewoo_pf_show_pro_notice', false ) ) {
			return;
		}

		if ( ! WooBeWoo_PF_Frame::_()->proVersionCompare( WPF_PRO_REQUIRES, '>=' ) ) {
			$plugName = __( 'Product Filter by WBW', 'woo-product-filter' );

			echo '<div class="notice error is-dismissible"><p><strong>';

			printf(
				/* translators: 1: plugin name 2: plugin version */
				esc_html__( 'Please install latest PRO version of %1$s plugin (requires at least %2$s). ', 'woo-product-filter' ),
				esc_html( $plugName ),
				esc_html( WPF_PRO_REQUIRES )
			);

			printf(
				/* translators: %s: plugin name */
				esc_html__( 'In this way you will have full and upgraded PRO version of %s.', 'woo-product-filter' ),
				esc_html( $plugName )
			);
			echo '</strong></p></div>';
		}
	}
}

/**
 * woobewoo_pf_plugin_row.
 *
 * @version 3.4.0
 * @since   3.3.0
 */
add_action( 'after_plugin_row_woofilter-pro/woofilter-pro.php', 'woobewoo_pf_plugin_row', 5, 2 );
if ( ! function_exists( 'woobewoo_pf_plugin_row' ) ) {
	function woobewoo_pf_plugin_row( $plugin_file, $plugin_data ) {

		if ( ! class_exists( 'WooBeWoo_PF_Frame' ) || ! defined( 'WPF_PRO_REQUIRES' ) ) {
			return;
		}

		if ( ! version_compare( $plugin_data['Version'], WPF_PRO_REQUIRES, '>=' ) ) {
			$colspan = version_compare( $GLOBALS['wp_version'], '5.5', '<' ) ? 3 : 4;

			$classes = 'plugin-update-tr wpf-pro-plugin-tr';
			if ( is_plugin_active( $plugin_file ) ) {
				$classes .= ' active';
			}
			if ( ! empty( $plugin_data['update'] ) ) {
				$classes .= ' wpf-pro-plugin-update';
			}
			?>
			<tr class="<?php echo esc_attr( $classes ); ?>">
				<td colspan="<?php echo esc_attr( $colspan ); ?>" class="plugin-update colspanchange">
					<div class="update-message notice inline notice-error notice-alt">
						<p>
							<?php
							printf(
								/* translators: %1$s: Plugin name, %2$s: Plugin version. */
								esc_html__( 'Current version of Free (Base) plugin %1$s requires version of WBW Product Filter PRO plugin at least %2$s.', 'woo-product-filter' ),
								esc_html__( 'Product Filter by WBW', 'woo-product-filter' ),
								esc_html( WPF_PRO_REQUIRES )
							);
							?>
						</p>
					</div>
				</td>
			</tr>
			<?php
		}
	}
}

/**
 * woobewoo_pf_uninstall.
 *
 * @version 3.4.0
 * @since   3.3.0
 */
add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooBeWoo_PF_Dispatcher' ) ) {
			return;
		}

		WooBeWoo_PF_Dispatcher::addAction(
			'woobewoo_pf_uninstall',
			'woobewoo_pf_uninstall'
		);
	}
);
if ( ! function_exists( 'woobewoo_pf_uninstall' ) ) {
	function woobewoo_pf_uninstall() {
		WooBeWoo_PF_Frame::_()->getModule( 'options' )->getModel()->save(
			'license_save_name',
			''
		);
	}
}
