<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Statistics Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_Statistics extends WooBeWoo_PF_Module {

	/**
	 * init.
	 *
	 * @version 3.4.0
	 */
	public function init() {
		parent::init();
		WooBeWoo_PF_Dispatcher::addFilter( 'mainAdminTabs', array( $this, 'addAdminTab' ) );
		WooBeWoo_PF_Dispatcher::addFilter( 'prepareFilterListTitle', array( $this, 'prepareFilterListTitle' ), 10, 2 );
		WooBeWoo_PF_Dispatcher::addAction( 'saveStatistics', array( $this, 'saveStatistics' ), 10, 2 );
	}

	/**
	 * addAdminTab.
	 */
	public function addAdminTab( $tabs ) {
		$show = true;
		if ( function_exists( 'is_multisite' ) && is_multisite() && get_option( 'wpmuclone_default_blog' ) ) {
			$availableSites = array( SITE_ID_CURRENT_SITE, get_option( 'wpmuclone_default_blog' ) );
			if ( ! in_array( get_current_blog_id(), $availableSites ) ) {
				$show = false;
			}
		}
		if ( $show ) {
			$tabs[ $this->getCode() ] = array(
				'label'      => esc_html__( 'Statistics', 'woo-product-filter' ),
				'callback'   => array( $this, 'getTabContent' ),
				'fa_icon'    => 'fa-line-chart',
				'sort_order' => 990,
			);
		}
		return $tabs;
	}
	public function getTabContent() {
		return $this->getView()->getTabContent();
	}
	public function prepareFilterListTitle( $title, $filter ) {
		if ( isset( $filter['is_stats'] ) ) {
			$title .= ' <a href="#" data-id="' . $filter['id'] . '" class="wpf-statistics wpf-action-' . ( empty( $filter['is_stats'] ) ? 'off' : 'on' ) . '" title="' . ( empty( $filter['is_stats'] ) ? esc_attr__( 'Enable statistics collection', 'woo-product-filter' ) : esc_attr__( 'Disable statistics collection', 'woo-product-filter' ) ) . '"><i class="fa fa-line-chart"></i> </a>';
		}
		return $title;
	}

	public function getReportsTypes( $key = false ) {
		$types = array(
			'requests'  => esc_html__( 'Count of filter requests', 'woo-product-filter' ),
			'users'     => esc_html__( 'Count of unique users who used filtering', 'woo-product-filter' ),
			'blocks'    => esc_html__( 'What blocks were used for filtering', 'woo-product-filter' ),
			'values'    => esc_html__( 'What values ​​were chosen for a particular block', 'woo-product-filter' ),
			'no_result' => esc_html__( 'No result', 'woo-product-filter' ),
		);
		return $key ? ( isset( $types[ $key ] ) ? $types[ $key ] : '???' ) : $types;
	}

	/**
	 * getReportsPeriods.
	 *
	 * @version 3.3.0
	 */
	public function getReportsPeriods() {
		return array(
			'week'      => __( 'Last 7 days', 'woo-product-filter' ),
			'month'     => __( 'Last Month', 'woo-product-filter' ),
			'cur_month' => __( 'This Month', 'woo-product-filter' ),
			'year'      => __( 'Last Year', 'woo-product-filter' ),
			'cur_year'  => __( 'This Year', 'woo-product-filter' ),
			'custom'    => __( 'Custom', 'woo-product-filter' ),
		);
	}

	/**
	 * saveStatistics.
	 *
	 * @version 3.4.0
	 */
	public function saveStatistics( $isFound ) {
		$statistics = WooBeWoo_PF_Req::getVar( 'statistics' );
		$statistics = WooBeWoo_PF_Utils::jsonDecode( stripslashes( $statistics ) );
		if ( ! empty( $statistics ) ) {
			$statistics['found'] = $isFound;
			$this->getModel()->saveStatistics( $statistics );
		}
	}
}
