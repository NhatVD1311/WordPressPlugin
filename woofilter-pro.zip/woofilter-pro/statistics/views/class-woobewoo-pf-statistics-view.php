<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Statistics_View Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_Statistics_View extends WooBeWoo_PF_View {

	/**
	 * getTabContent.
	 *
	 * @version 3.4.0
	 */
	public function getTabContent() {
		$modPath = $this->getModule()->getModPath();
		WooBeWoo_PF_Frame::_()->getModule( 'templates' )->loadJqGrid();
		WooBeWoo_PF_Frame::_()->addScript( 'wpf.admin.statistics', $modPath . 'js/admin.statistics.js' );
		WooBeWoo_PF_Frame::_()->addStyle( 'wpf.admin.statistics', $modPath . 'css/admin.statistics.css' );
		WooBeWoo_PF_Frame::_()->addScript( 'wpf.plotly', $modPath . 'js/plotly.min.js' );
		WooBeWoo_PF_Frame::_()->getModule( 'templates' )->loadBootstrap();
		WooBeWoo_PF_Frame::_()->getModule( 'templates' )->loadJqueryUi();
		WooBeWoo_PF_Frame::_()->getModule( 'templates' )->loadDatePicker();

		$this->assign( 'reports', $this->getModule()->getReportsTypes() );
		$this->assign( 'filters', $this->getModel()->getFiltersBlocksList() );
		$this->assign( 'pages', array( '' ) + WooBeWoo_PF_Frame::_()->getModule( 'woofilters' )->getAllPages() );
		$this->assign( 'periods', $this->getModule()->getReportsPeriods() );
		$this->assign(
			'typesBlocks',
			array(
				'pie'   => __( 'Pie', 'woo-product-filter' ),
				'bar'   => __( 'Bar', 'woo-product-filter' ),
				'table' => __( 'Table', 'woo-product-filter' ),
			)
		);
		$this->assign(
			'typesValues',
			array(
				'pie'    => __( 'Pie', 'woo-product-filter' ),
				'bar'    => __( 'Bar', 'woo-product-filter' ),
				'bubble' => __( 'Bubble', 'woo-product-filter' ),
				'table'  => __( 'Table', 'woo-product-filter' ),
			)
		);

		$this->assign(
			'tops',
			array(
				10   => 10,
				20   => 20,
				50   => 50,
				1000 => __( 'All', 'woo-product-filter' ),
			)
		);
		$this->assign( 'from', $this->getModel()->addPeriod( -7 ) );
		$this->assign( 'to', gmdate( 'Y-m-d' ) );

		$langs = array(
			'col-values'  => esc_html__( 'Value', 'woo-product-filter' ),
			'col-users'   => esc_html__( 'Unique users', 'woo-product-filter' ),
			'col-count'   => esc_html__( 'Count requests', 'woo-product-filter' ),
			'col-not'     => esc_html__( 'Not found', 'woo-product-filter' ),
			'empty-table' => esc_html__( 'You have no data for now.', 'woo-product-filter' ),
		);
		$this->assign( 'langs', $langs );

		return parent::getContent( 'statisticsAdmin' );
	}
}
