<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Statistics_Controller Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_Statistics_Controller extends WooBeWoo_PF_Controller {

	/**
	 * enableStats.
	 *
	 * @version 3.4.0
	 */
	public function enableStats() {
		$res = new WooBeWoo_PF_Response();
		$id  = WooBeWoo_PF_Req::getVar( 'id' );
		if ( $this->getModel()->enableStatistics( $id, 1 ) ) {
			$res->addMessage( esc_html__( 'Done', 'woo-product-filter' ) );
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		$res->ajaxExec( true );
	}

	/**
	 * disableStats.
	 *
	 * @version 3.4.0
	 */
	public function disableStats() {
		$res = new WooBeWoo_PF_Response();
		$id  = WooBeWoo_PF_Req::getVar( 'id' );
		if ( $this->getModel()->enableStatistics( $id, 0 ) ) {
			$res->addMessage( esc_html__( 'Done', 'woo-product-filter' ) );
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		$res->ajaxExec( true );
	}

	/**
	 * saveStatistics.
	 *
	 * @version 3.4.0
	 */
	public function saveStatistics() {
		$res        = new WooBeWoo_PF_Response();
		$statistics = WooBeWoo_PF_Req::getVar( 'statistics' );
		$statistics = WooBeWoo_PF_Utils::jsonDecode( stripslashes( $statistics ) );

		if ( $this->getModel()->saveStatistics( $statistics ) ) {
			$res->addMessage( esc_html__( 'Done', 'woo-product-filter' ) );
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		$res->ajaxExec( true );
	}

	/**
	 * getDiagramData.
	 *
	 * @version 3.4.0
	 */
	public function getDiagramData() {
		$res = new WooBeWoo_PF_Response();
		$res->ignoreShellData();

		$params = WooBeWoo_PF_Req::get( 'post' );
		$result = $this->getModel()->getDiagramData( $params );

		if ( $result ) {
			$res->values = $result;
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		return $res->ajaxExec();
	}

	/**
	 * getTableData.
	 *
	 * @version 3.4.0
	 */
	public function getTableData() {
		$res = new WooBeWoo_PF_Response();
		$res->ignoreShellData();

		$params = array();
		parse_str( WooBeWoo_PF_Req::getVar( 'params' ), $params );
		if ( ! is_array( $params ) ) {
			$params = array();
		}
		$params['order'] = WooBeWoo_PF_Req::getVar( 'sidx' );
		$params['dir']   = WooBeWoo_PF_Req::getVar( 'sord' );
		$result          = $this->getModel()->getTableData( $params );

		if ( $result ) {
			$res->addData( 'page', 1 );
			$res->addData( 'total', $result['total'] );
			$res->addData( 'rows', $result['rows'] );
			$res->addData( 'records', $result['total'] );
		} else {
			$res->pushError( $this->getModel()->getErrors() );
		}
		return $res->ajaxExec();
	}

	/**
	 * getPermissions.
	 *
	 * @version 3.1.7
	 * @since   3.1.3
	 *
	 * @return array
	 */
	public function getPermissions() {
		return array(
			WPF_METHODS    => array(
				'saveStatistics' => array(
					WPF_ADMIN,
					WPF_LOGGED,
					WPF_GUEST,
				),
			),
			WPF_USERLEVELS => array(
				WPF_ADMIN => array(
					'enableStats',
					'disableStats',
					'getTableData',
					'getDiagramData',
				),
			),
		);
	}
}
