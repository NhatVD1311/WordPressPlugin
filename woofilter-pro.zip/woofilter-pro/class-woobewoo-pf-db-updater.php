<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Db_Updater Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WooBeWoo_PF_Db_Updater' ) ) {

	class WooBeWoo_PF_Db_Updater {

		/**
		 * versionOption.
		 */
		private static $versionOption = 'wpf_pro_db_version';

		/**
		 * update.
		 */
		public static function update( $path ) {
			global $wpdb;
			$wpPrefix = $wpdb->prefix;
			if ( ! function_exists( 'get_plugin_data' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$plugin_data    = get_file_data( $path, array( 'Version' => 'Version' ) );
			$currentVersion = $plugin_data['Version'];
			$saveVersion    = get_option( $wpPrefix . self::$versionOption, 0 );
			if ( ! $saveVersion || version_compare( $currentVersion, $saveVersion, '>' ) ) {
				self::runUpdate();
				update_option( $wpPrefix . self::$versionOption, $currentVersion );
			}
		}

		/**
		 * runUpdate.
		 *
		 * @version 3.4.0
		 */
		public static function runUpdate() {
			if ( ! class_exists( 'WooBeWoo_PF_Db' ) ) {
				return;
			}
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			if ( ! WooBeWoo_PF_Db::existsTableColumn( '@__filters', 'is_stats' ) ) {
				WooBeWoo_PF_Db::query( 'ALTER TABLE `@__filters` ADD COLUMN `is_stats` smallint(3) NOT NULL DEFAULT 0 AFTER `setting_data`' );
			}
			if ( ! WooBeWoo_PF_Db::exist( '@__statistics' ) ) {
				dbDelta(
					WooBeWoo_PF_Db::prepareQuery(
						'CREATE TABLE IF NOT EXISTS `@__statistics` (
				  `id` bigint NOT NULL AUTO_INCREMENT,
				  `filter_id` INT(11) NOT NULL,
				  `page_id` INT(11) NOT NULL,
				  `user_id` INT(11) NOT NULL,
				  `filter_date` DATE NOT NULL,
				  `is_found` smallint(3) NOT NULL,
				  PRIMARY KEY (`id`),
				  INDEX `filter_id` (`filter_id`, `filter_date`)
				) DEFAULT CHARSET=utf8;'
					)
				);
			}
			if ( ! WooBeWoo_PF_Db::exist( '@__statistics_det' ) ) {
				dbDelta(
					WooBeWoo_PF_Db::prepareQuery(
						'CREATE TABLE IF NOT EXISTS `@__statistics_det` (
				  `id` bigint NOT NULL AUTO_INCREMENT,
				  `st_id` INT(11) NOT NULL,
				  `block_id` varchar(9) NOT NULL,
				  `val1` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin,
				  `val2` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin,
				  PRIMARY KEY (`id`),
				  INDEX `st_id` (`st_id`)
				) DEFAULT CHARSET=utf8;'
					)
				);
			}
			if ( ! WooBeWoo_PF_Db::exist( '@__statistics_val' ) ) {
				dbDelta(
					WooBeWoo_PF_Db::prepareQuery(
						'CREATE TABLE IF NOT EXISTS `@__statistics_val` (
				  `id` bigint NOT NULL AUTO_INCREMENT,
				  `value` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin,
				  PRIMARY KEY (`id`),
				  UNIQUE INDEX `value` (`value`)
				) DEFAULT CHARSET=utf8;'
					)
				);
			}
			if ( ! WooBeWoo_PF_Db::exist( '@__statistics_sum' ) ) {
				dbDelta(
					WooBeWoo_PF_Db::prepareQuery(
						"CREATE TABLE IF NOT EXISTS `@__statistics_sum` (
				  `id` bigint NOT NULL AUTO_INCREMENT,
				  `filter_date` DATE NOT NULL,
				  `filter_id` INT(11) NOT NULL DEFAULT '0',
				  `page_id` INT(11) NOT NULL DEFAULT '0',
				  `block_id` varchar(9) NOT NULL DEFAULT '',
				  `users` INT(11) NOT NULL DEFAULT '0',
				  `is_max` smallint(11) NOT NULL DEFAULT '0',
				  `val_id` INT(11) NOT NULL DEFAULT '0',
				  `cnt_ok` INT(11) NOT NULL DEFAULT '0',
				  `cnt_no` INT(11) NOT NULL DEFAULT '0',
				  PRIMARY KEY (`id`),
				  INDEX `filter_id` (`filter_id`, `filter_date`)
				) DEFAULT CHARSET=utf8;"
					)
				);
			}
		}
	}

}
