<?php
/**
 * WBW Product Filter PRO - WooBeWoo_PF_Access Class
 *
 * @version 3.4.0
 *
 * @author WBW
 */

defined( 'ABSPATH' ) || exit;

class WooBeWoo_PF_Access extends WooBeWoo_PF_Module {

	/**
	 * _accessRoles.
	 */
	private $_accessRoles = array();

	/**
	 * init.
	 *
	 * @version 3.4.0
	 */
	public function init() {
		parent::init();
		WooBeWoo_PF_Dispatcher::addFilter( 'adminMenuAccessCap', array( $this, 'modifyAccessCap' ) );
		if (
			class_exists( 'WooBeWoo_PF_Db_Updater' ) &&
			function_exists( 'trueRequestWpf' ) &&
			trueRequestWpf()
		) {
			WooBeWoo_PF_Db_Updater::update( woobeboo_pf_get_pro_plugin_full_path() );
		}
	}

	/**
	 * modifyAccessCap.
	 */
	public function modifyAccessCap( $mainCap ) {
		if ( $this->onlyForAdmin() ) {
			return $mainCap;
		}
		$accessRoles = $this->getAccessRolesList();
		$inCaps      = array();
		foreach ( $accessRoles as $role ) {
			$allRoleData = get_role( $role );
			if ( $allRoleData && $allRoleData->capabilities ) {
				$roleInCaps = array();
				foreach ( $allRoleData->capabilities as $cKey => $cVal ) {
					if ( $cVal ) {
						$roleInCaps[] = $cKey;
					}
				}
				if ( empty( $inCaps ) ) {
					$inCaps = $roleInCaps;
				} else {
					$inCaps = array_intersect( $inCaps, $roleInCaps );
				}
			}
		}
		if ( ! empty( $inCaps ) ) {
			return array_shift( $inCaps );
		}
		return false;
	}

	/**
	 * onlyForAdmin.
	 */
	public function onlyForAdmin() {
		$accessRoles = $this->getAccessRolesList();
		if (
			empty( $accessRoles ) ||
			(
				count( $accessRoles ) == 1 &&
				in_array( 'administrator', $accessRoles )
			)
		) {
			return true;
		}
		return false;
	}

	/**
	 * getAccessRolesList.
	 *
	 * @version 3.4.0
	 */
	public function getAccessRolesList() {
		if ( empty( $this->_accessRoles ) ) {
			$this->_accessRoles = WooBeWoo_PF_Frame::_()->getModule( 'options' )->get( 'access_roles' );
			if ( empty( $this->_accessRoles ) || ! is_array( $this->_accessRoles ) ) {
				$this->_accessRoles = array();
			}
			if ( ! in_array( 'administrator', $this->_accessRoles ) ) {
				$this->_accessRoles[] = 'administrator';
			}
		}
		return $this->_accessRoles;
	}
}
