const defaultConfig = require('@wordpress/scripts/config/webpack.config');

module.exports = {
    ...defaultConfig,
    entry: {
        "vanilla-calendar": "./assets/js/public/src/vanilla-calendar.js"
    },
    output: {
        filename: "[name].min.js",
        path: __dirname + "/assets/js/public",
    }
};
