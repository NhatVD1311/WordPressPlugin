<?php return array('dependencies' => array('react'), 'version' => 'b1c367a026ccb7b864a6');
