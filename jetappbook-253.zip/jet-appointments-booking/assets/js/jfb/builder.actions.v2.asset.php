<?php return array('dependencies' => array('react', 'wp-components', 'wp-data', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-primitives'), 'version' => '5e118c791dc0f1aff47a');
