<?php return array('dependencies' => array('react', 'wp-hooks'), 'version' => '936e787f890ba2122bd3');
