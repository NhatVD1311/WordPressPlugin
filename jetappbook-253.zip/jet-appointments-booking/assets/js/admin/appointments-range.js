Vue.component( 'jet-apb-appointments-range', {
	template: '#jet-apb-appointments-range',
	props: [ 'value', 'single-page' ],
	data: function() {
		return {
			range: {
				type: 'all',
				range_num: 60,
				range_unit: 'days',
			},
		};
	},
	created: function() {
		if ( this.value ) {
			this.range = JSON.parse( JSON.stringify( this.value ) );
		} else if ( this.singlePage ) {
			this.$set( this.range, 'type', 'inherit' );
		}
	},
	methods: {
		normalizeNumericEvent: function( event, key ) {
			const config = window.JetAPBConfig || window.jetApbPostMeta || {};
			const constraints = config.numeric_constraints && config.numeric_constraints[ key ]
				? config.numeric_constraints[ key ]
				: {};
			const min = undefined !== constraints.min ? Number( constraints.min ) : 0;
			const max = undefined !== constraints.max ? Number( constraints.max ) : null;
			const step = undefined !== constraints.step ? Number( constraints.step ) : 1;
			let value = Number( event.target.value );

			if ( ! Number.isFinite( value ) ) {
				value = min;
			}

			value = Math.max( min, value );

			if ( null !== max ) {
				value = Math.min( max, value );
			}

			value = Math.round( ( value - min ) / step ) * step + min;
			value = 1 <= step ? Math.round( value ) : Number( value.toFixed( 10 ) );
			event.target.value = value;

			return value;
		},
		updateNumericValue: function( event, key ) {
			this.setValue( this.normalizeNumericEvent( event, key ), key );
		},
		rangesList: function() {
			const rangesList = [
				{
					value: 'all',
					label: window.JetAPBRange.anyDate,
				},
				{
					value: 'range',
					label: window.JetAPBRange.rangeLabel,
				},
			];

			if ( this.singlePage ) {
				rangesList.unshift( {
					value: 'inherit',
					label: 'Inherit from global',
				} );
			}
			
			return rangesList;
			
		},
		setValue( value, key ) {
			
			this.$set( this.range, key, value );

			this.$nextTick( () => {
				this.$emit( 'input', this.range );
			} );

		}
	}
} );
