<?php return array('dependencies' => array(), 'version' => 'a376d61420b2908da1e8');
