export function getInitialControlValues( controls = {} ) {
	return Object.fromEntries(
		Object.entries( controls ).map( ( [ name, control ] ) => [
			name,
			control?.default ?? '',
		] ),
	);
}

export function isControlVisible( control = {}, values ) {
	const condition = control.condition ?? {};

	return Object.entries( condition ).every( ( [ name, expected ] ) => {
		const current = values[ name ];

		if ( Array.isArray( expected ) ) {
			return expected.map( String ).includes( String( current ) );
		}

		return String( expected ) === String( current );
	} );
}

function normalizeOptions( options = {} ) {
	if ( Array.isArray( options ) ) {
		return options.filter( option => null !== option ).map( option => (
			'object' === typeof option
				? option
				: { value: option, label: option }
		) );
	}

	if ( !options || 'object' !== typeof options ) {
		return [];
	}

	return Object.entries( options ).map( ( [ value, label ] ) => ( {
		value,
		label,
	} ) );
}

export function normalizeControlOptions( control ) {
	if ( control.groups ) {
		const groups = Array.isArray( control.groups )
		               ? control.groups
		               : Object.values( control.groups );

		return groups.filter(
			group => group && 'object' === typeof group,
		).map( group => ( {
			label: group.label ?? '',
			options: normalizeOptions( group.options ),
		} ) );
	}

	return normalizeOptions( control.options );
}

export function formatAppointmentMacro( macro, values = {} ) {
	const args = Object.keys( macro.controls ?? {} ).map(
		name => values[ name ] ?? '',
	);

	return `%${ macro.id }${ args.map( value => `|${ value }` ).join( '' ) }%`;
}
