import { addFilter, removeFilter } from '@wordpress/hooks';
import AppointmentMacrosFields from './AppointmentMacrosFields';

const hookName = 'jet.fb.macros.fields.additional-groups';
const namespace = 'jet-appointments-booking/send-email-macros';
const groupId = 'jet-apb-appointment-macros';

function registerAppointmentMacros() {
	const editorData = window.JetAPBFormBuilderData ?? {};
	const macros     = Array.isArray( editorData.appointmentMacros )
	                   ? editorData.appointmentMacros
	                   : [];
	const labels     = editorData.labels ?? {};

	removeFilter( hookName, namespace );

	if ( !macros.length ) {
		return;
	}

	addFilter(
		hookName,
		namespace,
		( groups, context = {} ) => {
			if (
				!context.macroScope?.startsWith( 'send-email.' ) ||
				'function' !== typeof context.onClick ||
				!Array.isArray( groups ) ||
				groups.some( group => groupId === group?.key )
			) {
				return groups;
			}

			return [
				...groups,
				<AppointmentMacrosFields
					key={ groupId }
					macros={ macros }
					labels={ labels }
					onClick={ context.onClick }
				/>,
			];
		},
	);
}

export default registerAppointmentMacros;
