import { formatAppointmentMacro } from './helpers';

const {
	      Button,
      } = wp.components;

function AppointmentMacroItem( { macro, onClick, onEdit } ) {
	const hasControls = Object.values( macro.controls ?? {} ).some(
		control => control && 'object' === typeof control,
	);
	const selectMacro = () => {
		if ( hasControls ) {
			onEdit( macro );
			return;
		}

		onClick( formatAppointmentMacro( macro ) );
	};

	return <li>
		<Button
			style={ { whiteSpace: 'nowrap' } }
			isLink
			onClick={ selectMacro }
		>
			{ macro.name ?? macro.id }
		</Button>
	</li>;
}

export default AppointmentMacroItem;
