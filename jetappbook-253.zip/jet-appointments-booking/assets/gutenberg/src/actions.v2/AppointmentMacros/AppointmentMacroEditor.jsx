import {
	formatAppointmentMacro,
	getInitialControlValues,
	isControlVisible,
	normalizeControlOptions,
} from './helpers';

const {
	      useState,
      } = wp.element;
const {
	      Button,
	      SelectControl,
	      TextControl,
      } = wp.components;
const {
	      __,
      } = wp.i18n;

function MacroControl( {
	name,
	control,
	value,
	onChange,
} ) {
	const props = {
		label: control.label ?? name,
		value: value ?? '',
		onChange,
	};

	if ( 'select' === control.type ) {
		return <SelectControl
			{ ...props }
			options={ normalizeControlOptions( control ) }
		/>;
	}

	return <TextControl { ...props }/>;
}

function AppointmentMacroEditor( {
	macro,
	labels = {},
	onApply,
	onBack,
} ) {
	const controls       = macro.controls ?? {};
	const controlEntries = Object.entries( controls ).filter(
		( [ , control ] ) => control && 'object' === typeof control,
	);
	const [ values, setValues ] = useState(
		() => getInitialControlValues( controls ),
	);
	const insertAppointmentMacro = () => {
		onApply( formatAppointmentMacro( macro, values ) );
	};

	return <div style={ {
		minWidth: '240px',
		padding: '0 0.5em 0.5em',
	} }>
		<div style={ {
			marginBottom: '1em',
		} }>
			<Button isLink onClick={ onBack }>
				{ labels.allMacros ?? __(
					'All Macros',
					'jet-appointments-booking',
				) }
			</Button>
			<span> &gt; { macro.name ?? macro.id }:</span>
		</div>
		{ controlEntries.map( ( [ name, control ] ) => (
			isControlVisible( control, values ) && <MacroControl
				key={ name }
				name={ name }
				control={ control }
				value={ values[ name ] }
				onChange={ value => setValues( current => ( {
					...current,
					[ name ]: value,
				} ) ) }
			/>
		) ) }
		<div style={ { marginTop: '1em' } }>
			<Button isPrimary isSmall onClick={ insertAppointmentMacro }>
				{ labels.apply ?? __(
					'Apply',
					'jet-appointments-booking',
				) }
			</Button>
		</div>
	</div>;
}

export default AppointmentMacroEditor;
