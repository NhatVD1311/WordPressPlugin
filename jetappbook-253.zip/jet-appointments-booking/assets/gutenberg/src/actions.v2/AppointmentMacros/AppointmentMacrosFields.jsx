import AppointmentMacroItem from './AppointmentMacroItem';
import AppointmentMacroEditor from './AppointmentMacroEditor';

const {
	      PanelBody,
      } = wp.components;
const {
	      useState,
      } = wp.element;
const {
	      __,
      } = wp.i18n;

function AppointmentMacrosFields( {
	macros,
	labels = {},
	onClick = () => {},
} ) {
	const [ selectedMacro, setSelectedMacro ] = useState( null );
	const applyMacro = macro => {
		onClick( macro );
		setSelectedMacro( null );
	};

	return <PanelBody
		title={ labels.appointmentMacros ?? __(
			'Appointment Macros:',
			'jet-appointments-booking',
		) }
		initialOpen={ false }
	>
		{ selectedMacro
			? <AppointmentMacroEditor
				key={ selectedMacro.id }
				macro={ selectedMacro }
				labels={ labels }
				onApply={ applyMacro }
				onBack={ () => setSelectedMacro( null ) }
			/>
			: <ul style={ {
				margin: 0,
				padding: '0 0.5em',
			} }>
				{ macros.map( macro => <AppointmentMacroItem
					key={ macro.id }
					macro={ macro }
					onClick={ onClick }
					onEdit={ setSelectedMacro }
				/> ) }
			</ul>
		}
	</PanelBody>;
}

export default AppointmentMacrosFields;
