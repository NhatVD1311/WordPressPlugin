import action from './InsertAppointment';
import registerAppointmentMacros from './AppointmentMacros';
import { registerAction } from 'jet-form-builder-actions';

registerAppointmentMacros();
registerAction( action );
