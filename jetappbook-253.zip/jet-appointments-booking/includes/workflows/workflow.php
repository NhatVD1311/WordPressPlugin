<?php
namespace JET_APB\Workflows;

use JET_APB\Plugin;
use JET_APB\Numeric_Input;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Workflow {

	private $enabled	= false;
	private $items		= [];
	private $hash		= 'default';

	public function __construct( $data ) {

		$this->hash    = ! empty( $data['hash'] ) ? $data['hash'] : $this->hash;
		$this->enabled = ! empty( $data['enabled'] ) ? filter_var( $data['enabled'], FILTER_VALIDATE_BOOLEAN ) : false;
		$this->items   = ! empty( $data['items'] ) ? $data['items'] : [];

		$this->ensure_items_hash();
		$this->sanitize_numeric_fields();
		
	}

	public function ensure_items_hash() {
		foreach ( $this->items as $index => $item ) {
			if ( empty( $item['hash'] ) ) {
				$this->items[ $index ]['hash'] = rand( 100000, 999999 );
			}
		}
	}

	/**
	 * Enforce the same limits used by workflow number inputs before storage/use.
	 */
	public function sanitize_numeric_fields() {
		$legacy_keys = [
			'days_before'  => 'days_schedule',
			'hours_before' => 'hours_schedule',
		];

		foreach ( $this->items as $index => $item ) {
			foreach ( Numeric_Input::get_constraints( 'workflow' ) as $key => $constraints ) {
				if ( isset( $item[ $key ] ) ) {
					$this->items[ $index ][ $key ] = Numeric_Input::sanitize( $item[ $key ], 'workflow', $key );
				}
			}

			foreach ( $legacy_keys as $legacy_key => $constraint_key ) {
				if ( isset( $item[ $legacy_key ] ) ) {
					$this->items[ $index ][ $legacy_key ] = Numeric_Input::sanitize(
						$item[ $legacy_key ],
						'workflow',
						$constraint_key
					);
				}
			}
		}
	}

	public function to_array() {
		return [
			'enabled' => $this->enabled,
			'items'   => $this->items,
		];
	}

	public function dispatch_workflow( $scheduled = false ) {

		if ( ! $this->enabled ) {
			return;
		}

		foreach ( $this->items as $item ) {
			
			$this->dispatch_event( $item, $scheduled );
			
		}

	}

	public function dispatch_event( $workflow_item = [], $scheduled = false ) {

		if ( empty( $workflow_item['event'] ) ) {
			return;
		}

		$event_object = Plugin::instance()->workflows->get_event( $workflow_item['event'] );

		if ( $event_object ) {
			if ( $scheduled ) {
				$event_object->dispatch_scheduled( $workflow_item );
			} else {
				$event_object->dispatch( $workflow_item );
			}
		}

	}

	public function has_hours_schedule() {

		if ( ! $this->enabled ) {
			return false;
		}

		foreach ( $this->items as $item ) {
			$schedule = isset( $item['schedule'] ) ? $item['schedule'] : 'immediately';

			if ( ! empty( $item['hours_schedule'] ) && 'immediately' !== $schedule ) {
				return true;
			}
		}

		return false;
	}

}
