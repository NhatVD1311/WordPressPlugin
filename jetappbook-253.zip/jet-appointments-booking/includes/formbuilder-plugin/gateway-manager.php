<?php


namespace JET_APB\Formbuilder_Plugin;


use JET_APB\Formbuilder_Plugin\Actions\Insert_Appointment_Action;
use JET_APB\Plugin;
use Jet_Form_Builder\Actions\Events\Base_Gateway_Event;
use Jet_Form_Builder\Actions\Types\Base;
use Jet_Form_Builder\Classes\Tools;
use Jet_Form_Builder\Gateways\Base_Gateway;

class Gateway_Manager {

	private $gateway_appointments = array();

	public function __construct() {
		add_filter(
			'jet-form-builder/gateways/notifications-before',
			array( $this, 'before_form_gateway' ), 0, 2
		);
		add_action(
			'jet-form-builder/before-trigger-event',
			array( $this, 'before_gateway_event' )
		);
		add_action(
			'jet-form-builder/gateways/on-payment-success',
			array( $this, 'on_gateway_success' )
		);

		new Trusted_Price_Handler();
	}

	public function before_form_gateway( $actions_ids, $actions_all ) {
		foreach ( $actions_all as $action ) {
			/** @var Base $action */
			if ( 'insert_appointment' === $action->get_id() && ! in_array( $action->_id, $actions_ids ) ) {
				$actions_ids[ $action->_id ] = array( 'active' => true );
			}
		}

		return $actions_ids;
	}

	/**
	 * Restore appointment context before any gateway event actions are executed.
	 *
	 * @param object $event JetFormBuilder event instance.
	 *
	 * @return void
	 */
	public function before_gateway_event( $event ) {
		if ( ! $event instanceof Base_Gateway_Event ) {
			return;
		}

		$this->prepare_gateway_appointments();
	}

	/**
	 * Finalize booking on internal JetFormBuilder form gateway success
	 *
	 * @param Base_Gateway $gateway
	 *
	 * @return void
	 */
	public function on_gateway_success( Base_Gateway $gateway ) {
		$appointments = $this->gateway_appointments;

		if ( ! $appointments ) {
			$appointments = $this->prepare_gateway_appointments( $gateway );
		}

		foreach ( $appointments as &$appointment ) {
			Plugin::instance()->db->appointments->update(
				array( 'status' => 'completed' ),
				array( 'ID'     => $appointment['ID'] )
			);
			Plugin::instance()->db->maybe_exclude_appointment_date( $appointment );

			$appointment['status'] = 'completed';
		}

		unset( $appointment );

		if ( $appointments ) {
			Insert_Appointment_Action::save_appointments( $appointments );
		}
	}

	/**
	 * Restore appointments used by actions assigned to a gateway event.
	 *
	 * @param Base_Gateway|null $gateway Gateway instance for legacy form data.
	 *
	 * @return array
	 */
	private function prepare_gateway_appointments( $gateway = null ): array {
		if ( ! $gateway && function_exists( 'jet_fb_gateway_current' ) ) {
			$gateway = jet_fb_gateway_current();
		}

		$form_data                 = $this->get_gateway_form_data( $gateway );
		$appointment_ids           = $this->get_appointment_ids( $form_data );
		$this->gateway_appointments = $this->get_appointments_by_ids( $appointment_ids );

		if ( $this->gateway_appointments ) {
			Insert_Appointment_Action::save_appointments( $this->gateway_appointments );
		}

		return $this->gateway_appointments;
	}

	/**
	 * Load appointments and restore all members of multi-booking groups.
	 *
	 * Some JetFormBuilder payment records retain only the parent appointment ID.
	 * Use its group ID to rebuild the full collection required by appointment
	 * list macros and payment completion.
	 *
	 * @param int[] $appointment_ids Appointment IDs from the form record.
	 *
	 * @return array
	 */
	private function get_appointments_by_ids( array $appointment_ids ): array {
		$appointments = array();
		$loaded_groups = array();

		foreach ( $appointment_ids as $id ) {
			$appointment = Plugin::instance()->db->get_appointment_by( 'ID', $id );

			if ( ! $appointment ) {
				continue;
			}

			$group_id = absint( $appointment['group_ID'] ?? 0 );

			if ( $group_id && ! isset( $loaded_groups[ $group_id ] ) ) {
				$group = Plugin::instance()->db->get_appointments_by( 'group_ID', $group_id );

				if ( $group ) {
					foreach ( $group as $group_appointment ) {
						$group_appointment_id = absint( $group_appointment['ID'] ?? 0 );

						if ( $group_appointment_id ) {
							$appointments[ $group_appointment_id ] = $group_appointment;
						}
					}
				}

				$loaded_groups[ $group_id ] = true;
			}

			$appointments[ $id ] = $appointment;
		}

		return array_values( $appointments );
	}

	/**
	 * Get submitted form data restored for the payment result request.
	 *
	 * Current JetFormBuilder scenario gateways restore the saved submission into
	 * the form context. Keep the gateway property as a fallback for legacy flows.
	 *
	 * @param Base_Gateway|null $gateway Gateway instance.
	 *
	 * @return array
	 */
	private function get_gateway_form_data( $gateway = null ): array {
		$gateway_data = is_object( $gateway ) && is_callable( array( $gateway, 'property' ) )
			? $gateway->property( 'data' )
			: array();
		$form_data    = array();

		if (
			is_array( $gateway_data )
			&& isset( $gateway_data['form_data'] )
			&& is_array( $gateway_data['form_data'] )
		) {
			$form_data = $gateway_data['form_data'];
		}

		if ( function_exists( 'jet_fb_context' ) ) {
			$context = jet_fb_context();

			if ( is_object( $context ) && is_callable( array( $context, 'resolve_request' ) ) ) {
				$request = $context->resolve_request();

				if ( is_array( $request ) ) {
					$form_data = array_merge( $form_data, $request );
				}
			}
		}

		return $form_data;
	}

	/**
	 * Normalize appointment IDs stored by JetFormBuilder.
	 *
	 * Form records can restore computed array values as JSON strings depending
	 * on the JetFormBuilder version that created the payment record.
	 *
	 * @param array $form_data Submitted form data.
	 *
	 * @return int[]
	 */
	private function get_appointment_ids( array $form_data ): array {
		$appointment_ids = $form_data['appointment_id_list'] ?? array();

		if ( is_string( $appointment_ids ) ) {
			$appointment_ids = Tools::decode_json( $appointment_ids );
		}

		if ( ! is_array( $appointment_ids ) ) {
			$appointment_ids = array( $appointment_ids );
		}

		$appointment_ids = array_values(
			array_unique(
				array_filter( array_map( 'absint', $appointment_ids ) )
			)
		);

		if ( empty( $appointment_ids ) ) {
			$appointment_id = absint( $form_data['appointment_id'] ?? 0 );

			if ( $appointment_id ) {
				$appointment_ids[] = $appointment_id;
			}
		}

		return $appointment_ids;
	}

}
