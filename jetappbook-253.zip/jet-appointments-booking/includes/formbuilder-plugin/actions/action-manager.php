<?php


namespace JET_APB\Formbuilder_Plugin\Actions;


use JET_APB\Plugin;
use JET_APB\Formbuilder_Plugin\With_Form_Builder;

/**
 * The script for registering the action
 * is displayed in the
 * JET_APB\Formbuilder_Plugin\Blocks\Blocks_Manager class
 *
 * Class Action_Manager
 * @package JET_ABAF\Formbuilder_Plugin\Actions
 */
class Action_Manager {

	use With_Form_Builder;

	public function manager_init() {
		add_action(
			'jet-form-builder/actions/register',
			array( $this, 'register_actions' )
		);
		add_action(
			'jet-form-builder/editor-assets/before',
			array( $this, 'editor_assets' )
		);
		add_filter(
			'jet-form-builder/actions/send-email/custom-macros',
			array( $this, 'add_legacy_email_macros' )
		);
	}

	public function register_actions( $manager ) {
		$manager->register_action_type( new Insert_Appointment_Action() );
	}

	public function editor_assets() {
		$script_asset = require_once JET_APB_PATH . 'assets/js/jfb/builder.blocks.asset.php';

		wp_enqueue_script(
			'jet-app-booking-form-builder-fields',
			JET_APB_URL . 'assets/js/jfb/builder.blocks.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		$script_name  = class_exists( '\JFB_Modules\Actions_V2\Module' ) ? 'actions.v2' : 'actions';
		$script_asset = require_once JET_APB_PATH . "assets/js/jfb/builder.{$script_name}.asset.php";

		wp_enqueue_script(
			'jet-app-booking-form-builder-actions',
			JET_APB_URL . "assets/js/jfb/builder.{$script_name}.js",
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		wp_set_script_translations(
			'jet-app-booking-form-builder-actions',
			'jet-appointments-booking',
			JET_APB_PATH . 'languages'
		);

		if ( 'actions.v2' === $script_name ) {
			wp_localize_script(
				'jet-app-booking-form-builder-actions',
				'JetAPBFormBuilderData',
				array(
					'appointmentMacros' => Plugin::instance()->macros->get_macros_for_js(),
					'labels'            => array(
						'appointmentMacros' => __( 'Appointment Macros:', 'jet-appointments-booking' ),
						'allMacros'         => __( 'All Macros', 'jet-appointments-booking' ),
						'apply'             => __( 'Apply', 'jet-appointments-booking' ),
					),
				)
			);
		}
	}

	/**
	 * Add appointment macros to the legacy Send Email action editor.
	 *
	 * @param array|false $macros Existing custom macros.
	 *
	 * @return array
	 */
	public function add_legacy_email_macros( $macros ) {

		$macros = is_array( $macros ) ? $macros : array();

		foreach ( Plugin::instance()->macros->get_macros_for_js() as $macro ) {
			if ( ! in_array( $macro['id'], $macros, true ) ) {
				$macros[] = $macro['id'];
			}
		}

		return array_values( $macros );
	}
}
