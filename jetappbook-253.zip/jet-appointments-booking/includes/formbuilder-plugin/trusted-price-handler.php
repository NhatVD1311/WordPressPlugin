<?php


namespace JET_APB\Formbuilder_Plugin;

use JET_APB\Appointment_Price;
use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB_Modules\Gateways\Trusted_Price_Resolver;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Trusted_Price_Handler {

	public function __construct() {
		add_filter(
			// phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
			'jet-form-builder/gateways/trusted-price/resolve-block',
			array( $this, 'resolve_appointment_price' ),
			10,
			5
		);
	}

	/**
	 * Resolve trusted price for appointment-date blocks.
	 *
	 * Parses the submitted appointment JSON to extract service/provider IDs,
	 * then calculates the price from server-side post meta via Appointment_Price.
	 * The client-submitted price value is completely ignored.
	 *
	 * @param float|null             $price      Current resolved price (null if unresolved).
	 * @param string                 $field_name The field name.
	 * @param string                 $type       Block type without namespace.
	 * @param array                  $block      Full block definition.
	 * @param Trusted_Price_Resolver $resolver   The resolver instance.
	 *
	 * @return float|null Resolved price or null if not an appointment block.
	 * @throws Gateway_Exception When appointment data is invalid or missing.
	 */
	public function resolve_appointment_price( $price, $field_name, $type, $block, $resolver ) {
		if ( 'appointment-date' !== $type ) {
			return $price;
		}

		$appointments = $this->parse_appointments_from_request( $field_name );

		if ( empty( $appointments ) ) {
			throw new Gateway_Exception(
				'Cannot resolve appointment price: no appointment data found in the submitted form.'
			);
		}

		$total_price = 0.0;

		foreach ( $appointments as $appointment ) {
			$service_id  = absint( $appointment['service'] ?? 0 );
			$provider_id = absint( $appointment['provider'] ?? 0 );
			$count       = max( 1, absint( $appointment['count'] ?? 1 ) );

			if ( ! $service_id || ! get_post( $service_id ) ) {
				throw new Gateway_Exception(
					sprintf(
						'Cannot resolve appointment price: service post #%d not found.',
						$service_id
					)
				);
			}

			if ( $provider_id && ! get_post( $provider_id ) ) {
				throw new Gateway_Exception(
					sprintf(
						'Cannot resolve appointment price: provider post #%d not found.',
						$provider_id
					)
				);
			}

			$price_calculator = new Appointment_Price(
				array(
					'service'  => $service_id,
					'provider' => $provider_id,
				)
			);

			$price_data   = $price_calculator->get_price();
			$total_price += (float) ( $price_data['price'] ?? 0 ) * $count;
		}

		return $total_price;
	}

	/**
	 * Parse appointment slots from the submitted form data.
	 *
	 * The appointment-date field submits a JSON-encoded array of slot objects,
	 * each containing service, provider, date, slot, slot_end, count, etc.
	 *
	 * @param string $field_name The appointment date field name.
	 *
	 * @return array List of appointment slot arrays.
	 * @throws Gateway_Exception When JSON is malformed.
	 */
	private function parse_appointments_from_request( string $field_name ): array {
		$raw = jet_fb_context()->get_value( $field_name );

		if ( empty( $raw ) ) {
			return array();
		}

		if ( is_array( $raw ) ) {
			return $raw;
		}

		$decoded = json_decode(
			wp_specialchars_decode( (string) $raw, ENT_QUOTES ),
			true
		);

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$decoded = json_decode(
				wp_specialchars_decode( wp_unslash( (string) $raw ), ENT_QUOTES ),
				true
			);
		}

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			throw new Gateway_Exception(
				'Cannot resolve appointment price: invalid appointment data format.'
			);
		}

		return $decoded;
	}
}
