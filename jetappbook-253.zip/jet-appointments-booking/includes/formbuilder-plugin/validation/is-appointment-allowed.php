<?php

namespace JET_APB\Formbuilder_Plugin\Validation;

use \Jet_Form_Builder\Request\Parser_Context;
use \JFB_Modules\Validation\Ssr\Base_Validation_Callback;
use JET_APB\Time_Types;
use JET_APB\Plugin;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Appointment_Allowed extends Base_Validation_Callback {

	public function get_id(): string {
		return 'is_appointment_allowed';
	}

	public function get_label(): string {
		return __( 'Is appointment allowed', 'jet-appointments-booking' );
	}

	public function is_valid( $value, Parser_Context $context ): bool {

		if ( $value && is_string( $value ) ) {

			$appointments = json_decode( $value, true );

			if ( ! empty( $appointments ) ) {

				foreach ( $appointments as $appointment ) {
					if ( ! Time_Types::is_allowed_time( $appointment ) ) {
						return false;
						break;
					}
					if ( ! Plugin::instance()->db->appointment_available( $appointment ) ) {
						return false;
						break;
					}
				}

			}

		}
		
        return true;

	}
	
}
