<?php
namespace JET_APB\DB;

/**
 * Database manager class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define DB class
 */
class External_Meta extends Base {

	/**
	 * Return table slug
	 * 
	 * @return [type] [description]
	 */
	public function table_slug() {
		return 'external_meta';
	}

	/**
	 * Try to recreate DB table by request
	 *
	 * @return void
	 */
	public function install_table() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$table_recreated = get_option( 'jet_booking_external_meta_table_recreated', false );

		if ( ! $table_recreated ) {
			$this->create_table( true );
			update_option( 'jet_booking_external_meta_table_recreated', true, true );
		}

	}

	/**
	 * Set external meta data
	 *
	 * @param int    $external_id Local external appointment ID.
	 * @param string $meta_key    Single key.
	 * @param mixed  $meta_value  Value to store.
	 * @return false|void False for an invalid ID or key.
	 */
	public function set_meta( $external_id, $meta_key, $meta_value ) {

		$external_id = absint( $external_id );

		if ( ! $external_id || ! is_scalar( $meta_key ) ) {
			return false;
		}

		$table    = $this->table();
		$meta_key = (string) $meta_key;
		$exists   = $this->wpdb()->get_var(
			$this->wpdb()->prepare(
				"SELECT ID FROM $table WHERE external_id = %d AND meta_key = %s LIMIT 1",
				$external_id,
				$meta_key
			)
		);

		if ( null !== $exists ) {
			$this->update( [ 'meta_value' => $meta_value ], [ 'ID' => absint( $exists ) ] );
		} else {
			$this->insert( [ 'external_id' => $external_id, 'meta_key' => $meta_key, 'meta_value' => $meta_value ] );
		}

	}

	/**
	 * Get external meta data
	 *
	 * @param int    $external_id Local external appointment ID.
	 * @param string $meta_key Single key.
	 * @return mixed|false Stored value, or false when it is not found or invalid.
	 */
	public function get_meta( $external_id, $meta_key ) {

		$external_id = absint( $external_id );

		if ( ! $external_id || ! is_scalar( $meta_key ) ) {
			return false;
		}

		$table    = $this->table();
		$meta_key = (string) $meta_key;
		$item     = $this->wpdb()->get_results(
			$this->wpdb()->prepare(
				"SELECT meta_value FROM $table WHERE external_id = %d AND meta_key = %s LIMIT 1",
				$external_id,
				$meta_key
			)
		);

		if ( empty( $item ) ) {
			return false;
		} else {
			return $item[0]->meta_value;
		}

	}

	/**
	 * Returns columns schema
	 * @return [type] [description]
	 */
	public function schema() {
		return array(
			'ID'             => 'bigint(20) NOT NULL AUTO_INCREMENT',
			'external_id'    => 'bigint(20)',
			'meta_key'       => 'text',
			'meta_value'     => 'longtext',
		);
	}

	/**
	 * Create DB table for apartment units
	 *
	 * @return [type] [description]
	 */
	public function get_table_schema() {

		$charset_collate = $this->wpdb()->get_charset_collate();
		$table           = $this->table();
		$default_columns = $this->schema();
		$columns_schema  = '';

		foreach ( $default_columns as $column => $desc ) {
			$columns_schema .= $column . ' ' . $desc . ',';
		}

		return "CREATE TABLE $table (
			$columns_schema
			PRIMARY KEY (ID)
		) $charset_collate;";

	}

}
