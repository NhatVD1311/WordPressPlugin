<?php
namespace JET_APB\Rest_API;

use JET_APB\Plugin;

class Endpoint_Appointment_Meta extends \Jet_Engine_Base_API_Endpoint {

	/**
	 * Returns route name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'appointment-meta';
	}

	/**
	 * API callback
	 *
	 * @return void
	 */
	public function callback( $request ) {

		$params       = $request->get_params();
		$item_id      = ! empty( $params['id'] ) ? absint( $params['id'] ) : 0;
		$allowed_meta = $this->get_allowed_meta_fields();
		
		return rest_ensure_response( array(
			'success' => true,
			'fields'  => $this->get_meta( 'appointment_id', $item_id, $allowed_meta ),
		) );

	}

	/**
	 * Get allowed meta data for selected table 
	 *
	 * @param string $column_id
	 * @param int    $item_id
	 * @param array  $allowed_meta 
	 * @return array
	 */
	public function get_meta( $column_id, $item_id, $allowed_meta ) {

		$result = [];
		$item_id = absint( $item_id );

		// This method is shared with the external metadata endpoint.
		if ( ! $item_id || ! in_array( $column_id, array( 'appointment_id', 'external_id' ), true ) || ! is_array( $allowed_meta ) ) {
			return $result;
		}

		$meta_keys = array_values( array_filter( array_keys( $allowed_meta ), 'is_scalar' ) );

		if ( empty( $meta_keys ) ) {
			return $result;
		}

		$table        = $this->get_table();
		$placeholders = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
		$query        = "SELECT * FROM $table WHERE $column_id = %d AND meta_key IN ( $placeholders );";
		$query_args   = array_merge( array( $query, $item_id ), $meta_keys );
		$wpdb         = Plugin::instance()->db->appointments_meta->wpdb();
		$raw_meta     = call_user_func_array( array( $wpdb, 'prepare' ), $query_args );
		$raw_meta     = $wpdb->get_results( $raw_meta );

		foreach ( $raw_meta as $row ) {
			
			$meta_value = maybe_unserialize( $row->meta_value );
			$data       = $allowed_meta[ $row->meta_key ];
			
			if ( ! empty( $data['cb'] ) && is_callable( $data['cb'] ) ) {
				$meta_value = call_user_func( $data['cb'], $meta_value, $row->meta_key );
			}

			// Meta values are rendered in the admin with v-html, so only return safe markup.
			if ( is_string( $meta_value ) ) {
				$meta_value = wp_kses_post( $meta_value );
			}

			$result[] = [
				'label' => ! empty( $data['label'] ) ? $data['label'] : ucfirst( str_replace( '_', ' ', $row->meta_key ) ),
				'value' => $meta_value,
				'key'   => trim( $row->meta_key, '-_' ),
			];

		}

		return $result;

	}

	/**
	 * Returns table name
	 *
	 * @return string
	 */
    public function get_table() {
        return Plugin::instance()->db->appointments_meta->table();
    }

	/**
	 * Returns array of allowed meta fields to display
	 *
	 * @return array
	 */
	public function get_allowed_meta_fields() {
		return Plugin::instance()->settings->get_appointment_fields();
	}

	/**
	 * Check user access to current end-popint
	 *
	 * @return bool
	 */
	public function permission_callback( $request ) {
		return Plugin::instance()->current_user_can( $this->get_name() );
	}

	/**
	 * Returns endpoint request method - GET/POST/PUT/DELTE
	 *
	 * @return string
	 */
	public function get_method() {
		return 'GET';
	}

	/**
	 * Get query param. Regex with query parameters
	 *
	 * @return string
	 */
	public function get_query_params() {
		return '(?P<id>[\d]+)';
	}

}
