<?php
namespace JET_APB\Elementor_Integration\Dynamic_Tags;

use Elementor\Modules\DynamicTags\Module as Tags_Module;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Module extends Tags_Module {

	const JET_GROUP = 'jet_appointments';

	public function get_tag_classes_names() {
		return [
			'Appointment_Service_Provider_Meta',
		];
	}

	public function get_groups() {
		return [
			self::JET_GROUP => [
				'title' => __( 'JetAppointments', 'jet-appointments-booking' ),
			],
		];
	}

	public function register_tags( $dynamic_tags ) {
		foreach ( $this->get_tag_classes_names() as $tag_class ) {
			$class_name = '\JET_APB\Elementor_Integration\Dynamic_Tags\Tags\\' . $tag_class;

			$dynamic_tags->register( new $class_name() );
		}
	}
}
