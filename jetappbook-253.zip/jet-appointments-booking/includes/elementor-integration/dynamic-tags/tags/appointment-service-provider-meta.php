<?php
namespace JET_APB\Elementor_Integration\Dynamic_Tags\Tags;

use Elementor\Controls_Manager;
use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module as Parent_Module;
use JET_APB\Elementor_Integration\Dynamic_Tags\Module as Child_Module;
use JET_APB\Plugin;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Appointment_Service_Provider_Meta extends Tag {

	public function get_name() {
		return 'jet-appointment-service-provider-meta';
	}

	public function get_title() {
		return __( 'Appointment Service/Provider Meta', 'jet-appointments-booking' );
	}

	public function get_group() {
		return Child_Module::JET_GROUP;
	}

	public function get_categories() {
		return [
			Parent_Module::TEXT_CATEGORY,
			Parent_Module::NUMBER_CATEGORY,
			Parent_Module::POST_META_CATEGORY,
		];
	}

	public function is_settings_required() {
		return true;
	}

	protected function register_controls() {
		$this->add_control(
			'meta_field',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => __( 'Field', 'jet-appointments-booking' ),
				'default' => 'meta_settings.price_type',
				'options' => $this->get_meta_field_options(),
			]
		);

		$this->add_control(
			'currency',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Currency', 'jet-appointments-booking' ),
				'default'   => __( '$', 'jet-appointments-booking' ),
				'condition' => [
					'meta_field' => [
						'meta_settings.current_price',
					],
				],
			]
		);

		$this->add_control(
			'currency_position',
			[
				'type'      => Controls_Manager::SELECT,
				'label'     => __( 'Currency Position', 'jet-appointments-booking' ),
				'default'   => 'before',
				'options'   => [
					'before' => __( 'Before', 'jet-appointments-booking' ),
					'after'  => __( 'After', 'jet-appointments-booking' ),
				],
				'condition' => [
					'meta_field' => [
						'meta_settings.current_price',
					],
				],
			]
		);

		$this->add_control(
			'time_format',
			[
				'type'      => Controls_Manager::TEXT,
				'label'     => __( 'Output Format', 'jet-appointments-booking' ),
				'default'   => 'H:i',
				'condition' => [
					'meta_field' => [
						'custom_schedule.default_slot',
						'custom_schedule.max_duration',
						'custom_schedule.step_duration',
						'custom_schedule.buffer_before',
						'custom_schedule.buffer_after',
						'custom_schedule.locked_time',
					],
				],
			]
		);
	}

	public function render() {
		$field = $this->get_settings( 'meta_field' );
		$value = $this->get_meta_value( get_the_ID(), $field );

		echo wp_kses_post( $this->format_value( $field, $value ) );
	}

	protected function get_meta_field_options() {
		$booking_type = Plugin::instance()->settings->get( 'booking_type' );
		$multi_booking = Plugin::instance()->settings->get( 'multi_booking' );

		$options = [
			'meta_settings.price_type'     => __( 'Price per', 'jet-appointments-booking' ),
			'meta_settings.current_price'  => __( 'Current Price', 'jet-appointments-booking' ),
			'custom_schedule.default_slot' => __( 'Duration', 'jet-appointments-booking' ),
		];

		if ( Plugin::instance()->settings->get( 'manage_capacity' ) && in_array( $booking_type, [ 'slot', 'recurring' ], true ) ) {
			$options = array_merge(
				array_slice( $options, 0, 2, true ),
				[ 'meta_settings._app_capacity' => __( 'Capacity', 'jet-appointments-booking' ) ],
				array_slice( $options, 2, null, true )
			);
		}

		if ( 'range' === $booking_type ) {
			$options['custom_schedule.max_duration'] = __( 'Max Duration', 'jet-appointments-booking' );
			$options['custom_schedule.step_duration'] = __( 'Duration Step', 'jet-appointments-booking' );
			$options['custom_schedule.only_start'] = __( 'Only start time', 'jet-appointments-booking' );
		}

		$options = array_merge( $options, [
			'custom_schedule.buffer_before'      => __( 'Buffer Time Before', 'jet-appointments-booking' ),
			'custom_schedule.buffer_after'       => __( 'Buffer Time After', 'jet-appointments-booking' ),
			'custom_schedule.locked_time'        => __( 'Locked Time Before', 'jet-appointments-booking' ),
			'custom_schedule.appointments_range' => __( 'Appointments Range', 'jet-appointments-booking' ),
			'custom_schedule.working_hours'      => __( 'Work Hours', 'jet-appointments-booking' ),
			'custom_schedule.working_days_mode'  => __( 'Working Days Mode', 'jet-appointments-booking' ),
			'custom_schedule.working_days'       => __( 'Working Days', 'jet-appointments-booking' ),
			'custom_schedule.days_off'           => __( 'Days Off', 'jet-appointments-booking' ),
		] );

		if ( 'slot' === $booking_type && $multi_booking ) {
			$options['custom_schedule.min_slot_count'] = __( 'Min Slot Count', 'jet-appointments-booking' );
			$options['custom_schedule.max_slot_count'] = __( 'Max Slot Count', 'jet-appointments-booking' );
		}

		if ( 'recurring' === $booking_type ) {
			$options['custom_schedule.re_booking'] = __( 'Book Every', 'jet-appointments-booking' );
			$options['custom_schedule.min_recurring_count'] = __( 'Min Recurring Count', 'jet-appointments-booking' );
			$options['custom_schedule.max_recurring_count'] = __( 'Max Recurring Count', 'jet-appointments-booking' );
		}

		return apply_filters( 'jet-apb/elementor/dynamic-tags/service-provider-meta/options', $options );
	}

	protected function get_meta_value( $post_id, $field ) {
		if ( ! $post_id || ! $this->is_supported_post( $post_id ) ) {
			return '';
		}

		$post_meta = get_post_meta( $post_id, 'jet_apb_post_meta', true );

		if ( ! is_array( $post_meta ) ) {
			$post_meta = [];
		}

		$post_meta = wp_parse_args(
			$post_meta,
			[
				'meta_settings'   => $this->get_default_meta_settings( $post_id ),
				'custom_schedule' => $this->get_default_custom_schedule(),
			]
		);

		$post_meta['meta_settings'] = wp_parse_args( $post_meta['meta_settings'], $this->get_default_meta_settings( $post_id ) );
		$post_meta['custom_schedule'] = wp_parse_args( $post_meta['custom_schedule'], $this->get_default_custom_schedule() );

		if ( 'meta_settings.current_price' === $field ) {
			return $this->get_current_price_value( $post_meta['meta_settings'] );
		}

		return $this->get_array_value( $post_meta, $field );
	}

	protected function is_supported_post( $post_id ) {
		$post_type = get_post_type( $post_id );
		$post_types = array_filter( [
			Plugin::instance()->settings->get( 'services_cpt' ),
			Plugin::instance()->settings->get( 'providers_cpt' ),
		] );

		return in_array( $post_type, $post_types, true );
	}

	protected function get_default_meta_settings( $post_id ) {
		$capacity     = get_post_meta( $post_id, '_app_capacity', true );
		$price        = get_post_meta( $post_id, '_app_price', true );
		$price_hour   = get_post_meta( $post_id, '_app_price_hour', true );
		$price_minute = get_post_meta( $post_id, '_app_price_minute', true );
		$providers_cpt = Plugin::instance()->settings->get( 'providers_cpt' );
		$is_provider   = $providers_cpt && get_post_type( $post_id ) === $providers_cpt;

		$defaults = [
			'price_type'        => '_app_price',
			'_app_price'        => '' !== $price ? $price : 10,
			'_app_price_hour'   => '' !== $price_hour ? $price_hour : 5,
			'_app_price_minute' => '' !== $price_minute ? $price_minute : 1,
		];

		if ( ! $is_provider && Plugin::instance()->settings->get( 'manage_capacity' ) ) {
			$defaults['_app_capacity'] = '' !== $capacity ? $capacity : 1;
		}

		if ( $is_provider ) {
			$defaults['price_type'] = '_app_price_service';
		}

		return $defaults;
	}

	protected function get_default_custom_schedule() {
		$settings = Plugin::instance()->settings;

		$defaults = array_merge(
			$settings->working_hours,
			[ 'use_custom_schedule' => false ]
		);

		$defaults['appointments_range'] = $settings->get( 'appointments_range' );
		$defaults['min_slot_count'] = $settings->get( 'min_slot_count' );
		$defaults['max_slot_count'] = $settings->get( 'max_slot_count' );

		return $defaults;
	}

	protected function get_array_value( $array, $path ) {
		$keys = explode( '.', $path );

		foreach ( $keys as $key ) {
			if ( ! is_array( $array ) || ! array_key_exists( $key, $array ) ) {
				return '';
			}

			$array = $array[ $key ];
		}

		return $array;
	}

	protected function get_current_price_value( $meta_settings ) {
		$price_type = ! empty( $meta_settings['price_type'] ) ? $meta_settings['price_type'] : '_app_price';

		if ( '_app_price_service' === $price_type ) {
			$value = $price_type;
		} else {
			$value = isset( $meta_settings[ $price_type ] ) ? $meta_settings[ $price_type ] : '';
		}

		return apply_filters(
			'jet-apb/elementor/dynamic-tags/service-provider-meta/current-price',
			$value,
			$meta_settings,
			$price_type
		);
	}

	protected function format_value( $field, $value ) {
		switch ( $field ) {
			case 'meta_settings.price_type':
				return $this->format_option_label( $value, $this->get_price_type_labels() );

			case 'meta_settings.current_price':
				return $this->format_current_price( $value );

			case 'custom_schedule.working_days_mode':
				return $this->format_option_label( $value, $this->get_working_days_mode_labels() );

			case 'custom_schedule.default_slot':
			case 'custom_schedule.max_duration':
			case 'custom_schedule.step_duration':
			case 'custom_schedule.buffer_before':
			case 'custom_schedule.buffer_after':
			case 'custom_schedule.locked_time':
				return $this->format_time( $value );

			case 'custom_schedule.appointments_range':
				return $this->format_appointments_range( $value );

			case 'custom_schedule.working_hours':
				return $this->format_working_hours( $value );

			case 'custom_schedule.working_days':
			case 'custom_schedule.days_off':
				return $this->format_days_list( $value );

			case 'custom_schedule.re_booking':
				return $this->format_options_list( $value, $this->get_rebooking_labels() );
		}

		if ( is_bool( $value ) ) {
			return $value ? __( 'Yes', 'jet-appointments-booking' ) : __( 'No', 'jet-appointments-booking' );
		}

		if ( is_array( $value ) ) {
			return $this->format_flat_list( $value );
		}

		return esc_html( $value );
	}

	protected function format_option_label( $value, $labels ) {
		return isset( $labels[ $value ] ) ? esc_html( $labels[ $value ] ) : esc_html( $value );
	}

	protected function format_options_list( $values, $labels ) {
		if ( empty( $values ) || ! is_array( $values ) ) {
			return '';
		}

		$result = [];

		foreach ( $values as $value ) {
			$result[] = $this->format_option_label( $value, $labels );
		}

		return implode( ', ', $result );
	}

	protected function format_flat_list( $value ) {
		$result = [];

		foreach ( $value as $item ) {
			if ( is_array( $item ) ) {
				$item = $this->format_flat_list( $item );
			}

			if ( '' !== (string) $item ) {
				$result[] = esc_html( $item );
			}
		}

		return implode( ', ', $result );
	}

	protected function format_time( $value ) {
		$format = $this->get_settings( 'time_format' );
		$format = $format ? $format : 'H:i';

		return esc_html( gmdate( $format, absint( $value ) ) );
	}

	protected function format_price( $value ) {
		if ( '' === (string) $value ) {
			return '';
		}

		$value = esc_html( $value );
		$currency = $this->get_settings( 'currency' );

		if ( '' === $currency ) {
			return $value;
		}

		if ( 'after' === $this->get_settings( 'currency_position' ) ) {
			return $value . esc_html( $currency );
		}

		return esc_html( $currency ) . $value;
	}

	protected function format_current_price( $value ) {
		if ( '_app_price_service' === $value ) {
			return $this->format_option_label( $value, $this->get_price_type_labels() );
		}

		return $this->format_price( $value );
	}

	protected function format_appointments_range( $value ) {
		if ( empty( $value ) || ! is_array( $value ) ) {
			return '';
		}

		if ( empty( $value['type'] ) || 'all' === $value['type'] ) {
			return esc_html__( 'Any date in the future', 'jet-appointments-booking' );
		}

		$range_num = ! empty( $value['range_num'] ) ? absint( $value['range_num'] ) : 60;
		$range_unit = ! empty( $value['range_unit'] ) ? $value['range_unit'] : 'days';

		return sprintf(
			'%1$s: %2$s %3$s',
			esc_html__( 'Limited range from current date', 'jet-appointments-booking' ),
			esc_html( $range_num ),
			esc_html( $range_unit )
		);
	}

	protected function format_working_hours( $value ) {
		if ( empty( $value ) || ! is_array( $value ) ) {
			return '';
		}

		$weekdays = $this->get_weekday_labels();
		$result = [];

		foreach ( $weekdays as $day => $label ) {
			if ( empty( $value[ $day ] ) || ! is_array( $value[ $day ] ) ) {
				continue;
			}

			$slots = [];

			foreach ( $value[ $day ] as $slot ) {
				if ( empty( $slot['from'] ) || empty( $slot['to'] ) ) {
					continue;
				}

				$slots[] = esc_html( $slot['from'] . '-' . $slot['to'] );
			}

			if ( $slots ) {
				$result[] = esc_html( $label ) . ': ' . implode( ', ', $slots );
			}
		}

		return implode( '; ', $result );
	}

	protected function format_days_list( $value ) {
		if ( empty( $value ) || ! is_array( $value ) ) {
			return '';
		}

		$result = [];

		foreach ( $value as $date ) {
			if ( ! is_array( $date ) ) {
				continue;
			}

			$label = ! empty( $date['start'] ) ? $date['start'] : '';

			if ( ! empty( $date['end'] ) && $date['end'] !== $label ) {
				$label .= ' - ' . $date['end'];
			}

			if ( ! empty( $date['name'] ) ) {
				$label .= ' ' . $date['name'];
			}

			if ( $label ) {
				$result[] = esc_html( trim( $label ) );
			}
		}

		return implode( '; ', $result );
	}

	protected function get_price_type_labels() {
		return [
			'_app_price_service' => __( 'Inherit Service Price', 'jet-appointments-booking' ),
			'_app_price'         => __( 'Slot', 'jet-appointments-booking' ),
			'_app_price_hour'    => __( 'Hour', 'jet-appointments-booking' ),
			'_app_price_minute'  => __( 'Minute', 'jet-appointments-booking' ),
		];
	}

	protected function get_working_days_mode_labels() {
		return [
			'override_full' => __( 'Override all schedule with new days', 'jet-appointments-booking' ),
			'override_days' => __( 'Override only days added below', 'jet-appointments-booking' ),
		];
	}

	protected function get_rebooking_labels() {
		return [
			'day'   => __( 'Day', 'jet-appointments-booking' ),
			'week'  => __( 'Week', 'jet-appointments-booking' ),
			'month' => __( 'Month', 'jet-appointments-booking' ),
			'year'  => __( 'Year', 'jet-appointments-booking' ),
		];
	}

	protected function get_weekday_labels() {
		return [
			'monday'    => __( 'Monday', 'jet-appointments-booking' ),
			'tuesday'   => __( 'Tuesday', 'jet-appointments-booking' ),
			'wednesday' => __( 'Wednesday', 'jet-appointments-booking' ),
			'thursday'  => __( 'Thursday', 'jet-appointments-booking' ),
			'friday'    => __( 'Friday', 'jet-appointments-booking' ),
			'saturday'  => __( 'Saturday', 'jet-appointments-booking' ),
			'sunday'    => __( 'Sunday', 'jet-appointments-booking' ),
		];
	}
}
