<?php
namespace JET_APB\Elementor_Integration;

use Elementor\Core\Files\CSS\Post;
use JET_APB\Plugin;

class Manager {

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'init_components' ] );

		$init_action = 'elementor/init';

		if ( is_admin() && ( isset( $_GET['elementor_updater'] ) || isset( $_GET['elementor_pro_updater'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$init_action = 'elementor/documents/register';
		}

		add_action( $init_action, [ $this, 'init_dynamic_tags' ] );
	}

	public function init_components() {
		add_filter( 'jet-engine/elementor-view/dynamic-link/generel-options', [ $this, 'register_dynamic_link_option' ] );
		add_filter( 'jet-apb/settings/templates-post-types', [ $this, 'add_template_post_type' ] );
	}

	public function add_template_post_type( $post_types = [] ) {
		$post_types[] = 'elementor_library';
		return $post_types;
	}

	public function register_dynamic_link_option( $options ) {
		$options[ Plugin::instance()->google_cal->query_var ] = __( 'Jet Appointments Booking: add booking to Google calendar', 'jet-appointments-booking' );
		return $options;
	}

	public function init_dynamic_tags() {
		if ( ! class_exists( '\Elementor\Modules\DynamicTags\Module' ) ) {
			return;
		}

		new Dynamic_Tags\Module();
	}

	public function has_template_runtime() {
		return class_exists( Post::class );
	}

	public function prepare_template( $template_id ) {
		jet_apb()->form->enqueue_deps( $template_id );
		jet_engine()->frontend->set_listing( $template_id );
	}

	public function enqueue_template_css( $template_id ) {
		$css_file = new Post( $template_id );
		$css_file->enqueue();
	}

	public function print_template_css( $template_id ) {
		$css_file = new Post( $template_id );
		$css_file->print_css();
	}

}
