<?php
/**
 * Class for parameter-based Appointment querying.
 */

namespace JET_APB\Resources;

use JET_APB\Plugin;
use JET_APB\Resources\Appointment_Model;

defined( 'ABSPATH' ) || exit;

class Appointment_Query {

	protected $query_vars = [];

	public function __construct( $args = [] ) {
		$this->query_vars = wp_parse_args( $args, $this->get_default_query_vars() );
	}

	/**
	 * Get the current query vars.
	 *
	 * @return array
	 */
	public function get_query_vars() {
		return $this->query_vars;
	}

	/**
	 * Get default query vars.
	 *
	 * Returns list of default valid query variables for appointments.
	 *
	 * @return array
	 */
	protected function get_default_query_vars() {
		return [
			'status'     => '',
			'type'       => '',
			'include'    => '',
			'exclude'    => '',
			'group_ID'   => '',
			'service'    => '',
			'provider'   => '',
			'order_id'   => '',
			'user_id'    => '',
			'date_query' => [],
			'meta_query' => [],
			'sorting'    => [],
			'limit'      => 0,
			'offset'     => 0,
			'return'     => 'objects',
		];
	}

	/**
	 * Get appointments.
	 *
	 * Returns appointments matching the current query vars.
	 *
	 * @return array|object of Appointments objects.
	 */
	public function get_appointments() {
		return $this->query( $this->get_query_vars() );
	}

    /**
	 * Return current appointments table name
	 *
	 * @return string
	 */
	protected function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'jet_appointments';
	}

	/**
	 * Return appointment table columns that are safe to use as SQL identifiers.
	 *
	 * SQL identifiers cannot be passed to $wpdb->prepare(), so they must always
	 * come from the table schema or the configured additional columns.
	 *
	 * @return array
	 */
	protected function get_allowed_columns() {
		return Plugin::instance()->db->appointments->get_physical_columns();
	}

	/**
	 * Check whether a value is an allowed appointment table column.
	 *
	 * @param mixed $column Column name.
	 *
	 * @return bool
	 */
	protected function is_allowed_column( $column ) {
		return is_string( $column )
			&& preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/', $column )
			&& in_array( $column, $this->get_allowed_columns(), true );
	}

	/**
	 * Check whether a value is an additional appointment table column.
	 *
	 * @param mixed $column Column name.
	 *
	 * @return bool
	 */
	protected function is_allowed_meta_column( $column ) {
		return $this->is_allowed_column( $column ) && in_array( $column, Plugin::instance()->db->appointments->get_available_custom_columns(), true );
	}

	/**
	 * Return a supported SQL comparison operator or false for invalid input.
	 *
	 * @param mixed $operator Operator value.
	 * @param array $allowed  Allowed operators.
	 *
	 * @return string|false
	 */
	protected function get_operator( $operator, $allowed ) {
		$operator = strtoupper( trim( (string) $operator ) );

		return in_array( $operator, $allowed, true ) ? $operator : false;
	}

	/**
	 * Return a safe SQL sort direction.
	 *
	 * @param mixed $order Sort direction.
	 *
	 * @return string|false
	 */
	protected function get_sort_order( $order ) {
		$order = strtoupper( trim( (string) $order ) );

		return in_array( $order, [ 'ASC', 'DESC' ], true ) ? $order : false;
	}

	/**
	 * Convert a scalar or list of IDs to SQL-safe integer values.
	 *
	 * @param mixed $value ID value or values.
	 *
	 * @return array
	 */
	protected function get_integer_values( $value ) {
		$value = is_array( $value ) ? $value : [ $value ];

		return array_map( 'intval', $value );
	}

	/**
	 * Query for appointments matching specific criteria.
	 *
	 * @param array $query_vars Query variables.
	 *
	 * @return array
	 */
	public function query( $query_vars ) {

		global $wpdb;

		$query_clause = [];

		if ( ! empty( $query_vars['include'] ) ) {
			$query_clause[] = sprintf( "ID IN ( %s )", implode( ', ', $this->get_integer_values( $query_vars['include'] ) ) );
		} else {
			if ( ! empty( $query_vars['exclude'] ) ) {
				$query_clause[] = sprintf( "ID NOT IN ( %s )", implode( ', ', $this->get_integer_values( $query_vars['exclude'] ) ) );
			}
		}

		foreach ( [ 'order_id', 'service', 'provider' ] as $col ) {
			if ( ! empty( $query_vars[ $col ] ) ) {
				$query_clause[] = sprintf( "%s IN ( %s )", $col, implode( ', ', $this->get_integer_values( $query_vars[ $col ] ) ) );
			}
		}

		foreach ([ 'group_ID', 'user_id' ] as $col ) {

			if ( ! isset( $query_vars[ $col ] ) || '' === $query_vars[ $col ] || [] === $query_vars[ $col ] ) {
				continue;
			}

			$raw = is_array( $query_vars[ $col ] ) ? $query_vars[ $col ] : [ $query_vars[ $col ] ];

			$include_null = false;
			$ids          = [];

			foreach ( $raw as $single ) {

				if ( null === $single || 'NULL' === $single || 'null' === $single || '0' === $single || 0 === $single ) {
					$include_null = true;
					continue;
				}

				if ( is_numeric( $single ) ) {
					$ids[] = intval( $single );
				}
			}

			$ids = array_values( array_unique( $ids ) );

			$parts = [];

			if ( ! empty( $ids ) ) {
				$parts[] = sprintf( "%s IN ( %s )", $col, implode( ', ', $ids ) );
			}

			if ( $include_null ) {
				$parts[] = sprintf( "%s IS NULL", $col );
			}

			if ( ! empty( $parts ) ) {
				$query_clause[] = '( ' . implode( ' OR ', $parts ) . ' )';
			}
		}
		
		foreach ( [ 'type', 'status' ] as $col ) {
			if ( ! empty( $query_vars[ $col ] ) ) {
				$val = is_array( $query_vars[ $col ] )
					? implode( "', '", array_map( 'esc_sql', $query_vars[ $col ] ) )
					: esc_sql( $query_vars[ $col ] );

				$query_clause[] = sprintf( "%s IN ( '%s' )", $col, $val );
			}
		}

		if ( ! empty( $query_vars['date_query'] ) ) {
			$date_query_clause = [];
			$date_query_rel    = 'AND';

			foreach ( $query_vars['date_query'] as $key => $clause ) {
				if ( 'relation' === $key ) {
					$date_query_rel = 'OR' === strtoupper( $clause ) ? 'OR' : 'AND';
					continue;
				}

				if ( ! is_array( $clause ) || empty( $clause['column'] ) ) {
					continue;
				}

				$col      = $clause['column'];
				$operator = $this->get_operator( ! empty( $clause['operator'] ) ? $clause['operator'] : '=', [ '=', '!=', '>', '>=', '<', '<=' ] );
				$value    = $clause['value'];

				if ( ! in_array( $col, [ 'date', 'slot', 'slot_end' ], true ) || ! $operator || '' === $value || null === $value ) {
					continue;
				}

				$ts = is_numeric( $value ) ? (int) $value : strtotime( (string) $value );

				if ( ! $ts ) {
					continue;
				}

				$val_sql = (string) $ts;

				$date_query_clause[] = sprintf( "%s %s %s", $col, $operator, $val_sql );
			}

			if ( ! empty( $date_query_clause ) ) {
				$query_clause[] = sprintf( "( %s )", implode( ' ' . $date_query_rel . ' ', $date_query_clause ) );
			}
		}

		if ( ! empty( $query_vars['meta_query'] ) ) {
			$meta_query_clause = [];
			$meta_query_rel    = 'AND';
			$invalid_custom_columns = [];

			$allowed_casts = [
				'CHAR'      => 'CHAR',
				'NUMERIC'   => 'SIGNED',
				'DECIMAL'   => 'DECIMAL',
				'SIGNED'    => 'SIGNED',
				'UNSIGNED'  => 'UNSIGNED',
				'DATE'      => 'DATE',
				'DATETIME'  => 'DATETIME',
				'TIME'      => 'TIME',
				'TIMESTAMP' => 'UNSIGNED',
				'BINARY'    => 'BINARY',
			];

			foreach ( $query_vars['meta_query'] as $key => $clause ) {
				if ( 'relation' === $key ) {
					$meta_query_rel = 'OR' === strtoupper( $clause ) ? 'OR' : 'AND';
					continue;
				}

				if ( ! is_array( $clause ) || empty( $clause['column'] ) ) {
					continue;
				}

				$operator = $this->get_operator(
					! empty( $clause['operator'] ) ? $clause['operator'] : '=',
					[ '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN', 'EXISTS', 'NOT EXISTS', 'REGEXP', 'NOT REGEXP' ]
				);
				$value    = $clause['value'] ?? false;

				$column_sql = $clause['column'];

				if ( ! $operator ) {
					continue;
				}

				if ( ! $this->is_allowed_meta_column( $column_sql ) ) {
					if ( Plugin::instance()->db->appointments->is_configured_custom_column( $column_sql ) ) {
						$invalid_custom_columns[ $column_sql ] = true;
					}

					continue;
				}

				if ( ! empty( $clause['type'] ) ) {
					if ( isset( $allowed_casts[ $clause['type'] ] ) ) {
						$column_sql = sprintf( "CAST(%s AS %s)", $clause['column'], $allowed_casts[ $clause['type'] ] );
					}
				}

				if ( false === $value ) {
					$meta_query_clause[] = sprintf( "%s %s", $column_sql, $operator );
				} else {
					$value = is_array( $value ) ? implode( ',', array_map( 'strval', $value ) ) : (string) $value;

					switch ( $operator ) {
						case 'LIKE':
						case 'NOT LIKE':
							$value_sql = "'" . '%' . esc_sql( $wpdb->esc_like( $value ) ) . '%' . "'";
							break;

						case 'IN':
						case 'NOT IN':
							$parts = array_filter( array_map( 'trim', explode( ',', $value ) ) );

							if ( count( $parts ) > 1 ) {
								$escaped = array_map( function( $item ) {
									return "'" . esc_sql( $item ) . "'";
								}, $parts );

								$value_sql = '( ' . implode( ', ', $escaped ) . ' )';
							} else {
								$single = "'" . esc_sql( reset( $parts ) ) . "'";

								if ( 'NOT IN' === $operator ) {
									$operator = '!=';
								} else {
									$operator = '=';
								}

								$value_sql = $single;
							}
							break;

						case 'BETWEEN':
						case 'NOT BETWEEN':
							$parts = array_values( array_filter( array_map( 'trim', explode( ',', $value ) ) ) );

							$first_part  = $parts[0] ?? '';
							$second_part = $parts[1] ?? '';

							if ( ! empty( $first_part ) && ! empty( $second_part ) ) {

								$value_sql = sprintf(
									"'%s' AND '%s'",
									esc_sql( $first_part ),
									esc_sql( $second_part )
								);

							} else {

								$value_sql = "'" . esc_sql( $value ) . "'";

								if ( 'NOT BETWEEN' === $operator ) {
									$operator = '!=';
								} else {
									$operator = '=';
								}

							}
							break;

						default:
							$value_sql = "'" . esc_sql( $value ) . "'";
					}

					$meta_query_clause[] = sprintf( "%s %s %s", $column_sql, $operator, $value_sql );
				}
			}

			if ( ! empty( $meta_query_clause ) ) {
				$query_clause[] = sprintf( "( %s )", implode( ' ' . $meta_query_rel . ' ', $meta_query_clause ) );
			}

			if ( ! empty( $invalid_custom_columns ) ) {
				// A stale configured column must never turn a restrictive query into a broader one.
				$query_clause[] = '0 = 1';

				foreach ( array_keys( $invalid_custom_columns ) as $column ) {
					/**
					 * Fires when a configured custom appointment column is missing from the table.
					 *
					 * @param string $column     Missing custom column name.
					 * @param array  $query_vars Appointment query arguments.
					 */
					do_action( 'jet-apb/query/invalid-custom-column', $column, $query_vars );
				}
			}
		}

		$query = sprintf( "SELECT * FROM %s", $this->table_name() );

		if ( ! empty( $query_clause ) ) {
			$query .= sprintf( " WHERE %s", implode( ' AND ', $query_clause ) );
		}

		if ( ! empty( $query_vars['sorting'] ) ) {
			$sorting_query_clause = [];

			foreach ( $query_vars['sorting'] as $sorting ) {
				if ( ! is_array( $sorting ) || empty( $sorting['orderby'] ) || ! $this->is_allowed_column( $sorting['orderby'] ) ) {
					continue;
				}
				$order = $this->get_sort_order( ! empty( $sorting['order'] ) ? $sorting['order'] : 'ASC' );

				if ( ! $order ) {
					continue;
				}

				$sorting_query_clause[] = sprintf( "%s %s", $sorting['orderby'], $order );
			}

			if ( ! empty( $sorting_query_clause ) ) {
				$query .= sprintf( " ORDER BY %s", implode( ', ', $sorting_query_clause ) );
			}
		}

		if ( ! empty( $query_vars['limit'] ) && intval( $query_vars['limit'] ) > 0 ) {
			$query .= sprintf( " LIMIT %d", intval( $query_vars['limit'] ) );
			if ( ! empty( $query_vars['offset'] ) ) {
				$query .= sprintf( " OFFSET %d", intval( $query_vars['offset'] ) );
			}
		}

		$results = $wpdb->get_results( $query, ARRAY_A );

		return array_values(
			array_filter(
				array_map(
					function ( $item ) use ( $query_vars ) {
						$obj = new Appointment_Model( $item );

						return ( isset( $query_vars['return'] ) && 'arrays' === $query_vars['return'] )
							? $obj->to_array()
							: $obj;
					},
					$results
				)
			)
		);
	}
}
