<?php
namespace JET_APB;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Keeps numeric admin input constraints and server-side normalization in sync.
 */
class Numeric_Input {

	/**
	 * Numeric input constraints grouped by their storage context.
	 *
	 * @var array
	 */
	private static $constraints = [
		'meta_settings' => [
			'_app_capacity'     => [ 'min' => 0, 'max' => 100000, 'step' => 1 ],
			'_app_price'        => [ 'min' => 0, 'max' => 100000, 'step' => 0.1 ],
			'_app_price_hour'   => [ 'min' => 0, 'max' => 100000, 'step' => 0.1 ],
			'_app_price_minute' => [ 'min' => 0, 'max' => 100000, 'step' => 0.1 ],
		],
		'global_settings' => [
			'min_recurring_count'    => [ 'min' => 2, 'max' => 1000, 'step' => 1 ],
			'max_recurring_count'    => [ 'min' => 1, 'max' => 1000, 'step' => 1 ],
			'min_slot_count'         => [ 'min' => 1, 'max' => 1000, 'step' => 1 ],
			'max_slot_count'         => [ 'min' => 1, 'max' => 1000, 'step' => 1 ],
			'confirm_deadline_limit' => [ 'min' => 1, 'step' => 1 ],
			'cancel_deadline_limit'  => [ 'min' => 1, 'step' => 1 ],
			'range_num'              => [ 'min' => 1, 'step' => 1 ],
		],
		'workflow' => [
			'days_schedule'  => [ 'min' => 0, 'max' => 15, 'step' => 1 ],
			'hours_schedule' => [ 'min' => 0, 'max' => 23, 'step' => 1 ],
		],
	];

	/**
	 * Return constraints for a context or for a single field.
	 *
	 * @param string $context Context name.
	 * @param string $key     Optional field name.
	 *
	 * @return array
	 */
	public static function get_constraints( $context, $key = '' ) {
		$constraints = isset( self::$constraints[ $context ] ) ? self::$constraints[ $context ] : [];

		if ( ! $key ) {
			return $constraints;
		}

		return isset( $constraints[ $key ] ) ? $constraints[ $key ] : [];
	}

	/**
	 * Normalize a field value according to its registered constraints.
	 *
	 * @param mixed  $value   Input value.
	 * @param string $context Context name.
	 * @param string $key     Field name.
	 *
	 * @return int|float|mixed
	 */
	public static function sanitize( $value, $context, $key ) {
		$constraints = self::get_constraints( $context, $key );

		if ( empty( $constraints ) ) {
			return $value;
		}

		$min    = isset( $constraints['min'] ) ? $constraints['min'] : 0;
		$max    = isset( $constraints['max'] ) ? $constraints['max'] : null;
		$step   = isset( $constraints['step'] ) ? $constraints['step'] : 1;
		$number = is_numeric( $value ) ? (float) $value : (float) $min;

		if ( ! is_finite( $number ) ) {
			$number = (float) $min;
		}

		$number = max( $min, $number );

		if ( null !== $max ) {
			$number = min( $max, $number );
		}

		$number = round( ( $number - $min ) / $step ) * $step + $min;

		if ( 1 <= $step ) {
			return (int) round( $number );
		}

		$precision = strlen( rtrim( substr( strrchr( (string) $step, '.' ), 1 ), '0' ) );

		return round( $number, $precision );
	}
}
