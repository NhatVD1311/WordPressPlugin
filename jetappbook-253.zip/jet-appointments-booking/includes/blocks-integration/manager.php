<?php
namespace JET_APB\Blocks_Integration;

class Manager {

	public function __construct() {
		$this->init_components();
	}

	public function init_components() {
		return;
	}

	public function is_blocks_template( $template_id ) {
		return function_exists( 'jet_engine' ) && jet_engine()->blocks_views->is_blocks_listing( $template_id );
	}

	public function get_template_css( $template_id ) {
		if ( ! class_exists( 'JET_SM\Gutenberg\Style_Manager' ) ) {
			return '';
		}

		return ( new \JET_SM\Gutenberg\Style_Manager() )->get_blocks_style( $template_id );
	}

	public function print_template_styles( $template_id ) {
		do_action( 'jet-engine/blocks-views/print-template-styles', $template_id );
	}

}
