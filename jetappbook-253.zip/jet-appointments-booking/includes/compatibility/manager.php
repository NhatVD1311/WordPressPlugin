<?php

namespace JET_APB\Compatibility;

defined( 'ABSPATH' ) || exit;

class Manager {

	public function __construct() {
		$this->load_compatibility_packages();
	}

	/**
	 * Load compatibility packages.
	 *
	 * Includes all available compatibility packages for provided plugins.
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function load_compatibility_packages() {

		$packages_list = [
			'jet-engine/jet-engine.php' => [
				'cb'   => 'class_exists',
				'args' => 'Jet_Engine',
			],
			'jet-smart-filters/jet-smart-filters.php' => [
				'cb'   => 'function_exists',
				'args' => 'jet_smart_filters',
			],
		];

		foreach ( $packages_list as $file => $condition ) {
			if ( true === call_user_func( $condition['cb'], $condition['args'] ) ) {
				require JET_APB_PATH . 'includes/compatibility/packages/' . $file;
			}
		}

	}

}
