<?php
/**
 * JetEngine compatibility package Query Builder Editor class.
 *
 * @package JET_APB\Compatibility\Packages\Jet_Engine\Query_Builder
 */

namespace JET_APB\Compatibility\Packages\Jet_Engine\Query_Builder;

use \Jet_Engine\Query_Builder\Query_Editor\Base_Query;
use \JET_APB\Compatibility\Packages\Jet_Engine;
use JET_APB\Plugin;

class Editor extends Base_Query {

	/**
	 * Get ID.
	 *
	 * Returns query type ID.
	 *
	 * @access public
	 *
	 * @return mixed
	 */
	public function get_id() {
		return Manager::instance()->slug;
	}

	/**
	 * Get name.
	 *
	 * Returns name of the query type.
	 *
	 * @access public
	 *
	 * @return string|null
	 */
	public function get_name() {
		return __( 'Jet Appointments Booking Query', 'jet-appointments-booking' );
	}

	/**
	 * Editor component_name.
	 *
	 * Returns Vue component name of the Query editor for the current type.
	 *
	 * @access public
	 *
	 * @return string
	 */
	public function editor_component_name() {
		return 'jet-appointment-query';
	}

	/**
	 * Editor component template.
	 *
	 * Returns Vue component template of the Query editor for the current type.
	 *
	 * @access public
	 *
	 * @return false|string
	 */
	public function editor_component_template() {

		ob_start();
		include Jet_Engine::instance()->package_path( 'templates/admin/query-editor.php' );

		return ob_get_clean();

	}

	/**
	 * Editor component data.
	 *
	 * Returns Vue component data of the Query editor for the current type.
	 *
	 * @access public
	 *
	 * @return mixed|void
	 */
	public function editor_component_data() {

		$statuses           = Plugin::instance()->statuses->get_statuses();
		$columns            = array_keys( Plugin::instance()->db->appointments->schema() );
		$additional_columns = array_values( Plugin::instance()->settings->get( 'db_columns' ) );
        $types              = $this->get_types();

		return apply_filters( 'jet-engine/query-builder/types/jet-appointment-query/data', [
			'statuses'           => \Jet_Engine_Tools::prepare_list_for_js( $statuses, ARRAY_A ),
			'columns'            => \Jet_Engine_Tools::prepare_list_for_js( $columns ),
			'additional_columns' => \Jet_Engine_Tools::prepare_list_for_js( $additional_columns ),
            'types'              => \Jet_Engine_Tools::prepare_list_for_js( $types, ARRAY_A ),  
		] );

	}

	/**
	 * Get appointments types.
	 *
	 * @return array
	 */
    public function get_types() {
        return [
            'slot' => esc_html__( 'Slot', 'jet-appointments-booking' ),
            'range' => esc_html__( 'Time Picker', 'jet-appointments-booking' ),
            'recurring' => esc_html__( 'Recurring', 'jet-appointments-booking' ),
		];
    }

	/**
	 * Editor component file.
	 *
	 * Returns Vue component template file of the Query editor for the current type.
	 *
	 * @access public
	 *
	 * @return string
	 */
	public function editor_component_file() {
		return Jet_Engine::instance()->package_url( 'assets/js/admin/query-editor.js' );
	}

}
