<?php
/**
 * JetEngine compatibility package manager.
 *
 * @package JET_ABAF\Compatibility\Packages
 */

namespace JET_APB\Compatibility\Packages;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

class Jet_Engine {

	/**
	 * A reference to an instance of this class.
	 *
	 * @var object
	 */
	private static $instance = null;

	public function __construct() {
		Jet_Engine\Query_Builder\Manager::instance();
	}

    /**
	 * Package path.
	 *
	 * Return path inside package.
	 *
	 * @access public
	 *
	 * @param string $path Relative package path.
	 *
	 * @return string
	 */
	public function package_path( $path = '' ) {
		return JET_APB_PATH . 'includes/compatibility/packages/jet-engine/' . $path;
	}

	/**
	 * Package URL.
	 *
	 * Return URL inside package.
	 *
	 * @access public
	 *
	 * @param string $url Relative package URL.
	 *
	 * @return string
	 */
	public function package_url( $url = '' ) {
		return JET_APB_URL . 'includes/compatibility/packages/jet-engine/' . $url;
	}

	/**
	 * Returns the instance.
	 *
	 * @access public
	 *
	 * @return object
	 */
	public static function instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;

	}

}

new Jet_Engine();
