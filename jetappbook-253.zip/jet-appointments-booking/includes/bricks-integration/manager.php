<?php
namespace JET_APB\Bricks_Integration;

use JET_APB\Plugin;

class Manager {

	public function __construct() {
        if ( function_exists( 'bricks_is_builder_main' ) ) {
			$this->init_components();
		}
	}

	public function init_components() {
		add_filter( 'jet-apb/settings/bricks-templates-post-types', [ $this, 'add_template_post_type' ] );
	}

	public function add_template_post_type( $post_types = [] ) {
		$post_types[] = 'bricks_template';
		return $post_types;
	}

	public function is_bricks_template( $template_id ) {
		return class_exists( '\Bricks\Theme' )
			&& function_exists( 'jet_engine' )
			&& 'bricks' === jet_engine()->listings->data->get_listing_type( $template_id );
	}

}
